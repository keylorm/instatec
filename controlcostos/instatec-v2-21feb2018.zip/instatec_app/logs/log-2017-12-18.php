<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-12-18 06:45:43 --> Config Class Initialized
INFO - 2017-12-18 06:45:43 --> Hooks Class Initialized
DEBUG - 2017-12-18 06:45:43 --> UTF-8 Support Enabled
INFO - 2017-12-18 06:45:43 --> Utf8 Class Initialized
INFO - 2017-12-18 06:45:43 --> URI Class Initialized
INFO - 2017-12-18 06:45:43 --> Router Class Initialized
INFO - 2017-12-18 06:45:43 --> Output Class Initialized
INFO - 2017-12-18 06:45:43 --> Security Class Initialized
DEBUG - 2017-12-18 06:45:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 06:45:43 --> Input Class Initialized
INFO - 2017-12-18 06:45:43 --> Language Class Initialized
INFO - 2017-12-18 06:45:43 --> Loader Class Initialized
INFO - 2017-12-18 06:45:43 --> Helper loaded: url_helper
INFO - 2017-12-18 06:45:44 --> Helper loaded: form_helper
INFO - 2017-12-18 06:45:44 --> Database Driver Class Initialized
DEBUG - 2017-12-18 06:45:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-18 06:45:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-18 06:45:44 --> Form Validation Class Initialized
INFO - 2017-12-18 06:45:44 --> Model Class Initialized
INFO - 2017-12-18 06:45:44 --> Controller Class Initialized
INFO - 2017-12-18 06:45:44 --> Model Class Initialized
INFO - 2017-12-18 06:45:44 --> Model Class Initialized
INFO - 2017-12-18 06:45:44 --> Model Class Initialized
DEBUG - 2017-12-18 06:45:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-18 06:45:44 --> Config Class Initialized
INFO - 2017-12-18 06:45:44 --> Hooks Class Initialized
DEBUG - 2017-12-18 06:45:44 --> UTF-8 Support Enabled
INFO - 2017-12-18 06:45:44 --> Utf8 Class Initialized
INFO - 2017-12-18 06:45:44 --> URI Class Initialized
INFO - 2017-12-18 06:45:44 --> Router Class Initialized
INFO - 2017-12-18 06:45:44 --> Output Class Initialized
INFO - 2017-12-18 06:45:44 --> Security Class Initialized
DEBUG - 2017-12-18 06:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 06:45:44 --> Input Class Initialized
INFO - 2017-12-18 06:45:44 --> Language Class Initialized
INFO - 2017-12-18 06:45:44 --> Loader Class Initialized
INFO - 2017-12-18 06:45:44 --> Helper loaded: url_helper
INFO - 2017-12-18 06:45:44 --> Helper loaded: form_helper
INFO - 2017-12-18 06:45:44 --> Database Driver Class Initialized
DEBUG - 2017-12-18 06:45:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-18 06:45:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-18 06:45:44 --> Form Validation Class Initialized
INFO - 2017-12-18 06:45:44 --> Model Class Initialized
INFO - 2017-12-18 06:45:44 --> Controller Class Initialized
INFO - 2017-12-18 06:45:44 --> Model Class Initialized
DEBUG - 2017-12-18 06:45:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-18 06:45:44 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-18 06:45:44 --> Final output sent to browser
DEBUG - 2017-12-18 06:45:44 --> Total execution time: 0.1219
INFO - 2017-12-18 06:45:45 --> Config Class Initialized
INFO - 2017-12-18 06:45:45 --> Hooks Class Initialized
DEBUG - 2017-12-18 06:45:45 --> UTF-8 Support Enabled
INFO - 2017-12-18 06:45:45 --> Utf8 Class Initialized
INFO - 2017-12-18 06:45:45 --> URI Class Initialized
INFO - 2017-12-18 06:45:45 --> Router Class Initialized
INFO - 2017-12-18 06:45:45 --> Output Class Initialized
INFO - 2017-12-18 06:45:45 --> Security Class Initialized
DEBUG - 2017-12-18 06:45:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 06:45:45 --> Input Class Initialized
INFO - 2017-12-18 06:45:45 --> Language Class Initialized
INFO - 2017-12-18 06:45:45 --> Loader Class Initialized
INFO - 2017-12-18 06:45:45 --> Helper loaded: url_helper
INFO - 2017-12-18 06:45:45 --> Helper loaded: form_helper
INFO - 2017-12-18 06:45:45 --> Database Driver Class Initialized
DEBUG - 2017-12-18 06:45:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-18 06:45:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-18 06:45:45 --> Form Validation Class Initialized
INFO - 2017-12-18 06:45:45 --> Model Class Initialized
INFO - 2017-12-18 06:45:45 --> Controller Class Initialized
INFO - 2017-12-18 06:45:45 --> Model Class Initialized
DEBUG - 2017-12-18 06:45:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-18 06:45:45 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-12-18 06:45:45 --> Config Class Initialized
INFO - 2017-12-18 06:45:45 --> Hooks Class Initialized
DEBUG - 2017-12-18 06:45:45 --> UTF-8 Support Enabled
INFO - 2017-12-18 06:45:45 --> Utf8 Class Initialized
INFO - 2017-12-18 06:45:45 --> URI Class Initialized
DEBUG - 2017-12-18 06:45:45 --> No URI present. Default controller set.
INFO - 2017-12-18 06:45:45 --> Router Class Initialized
INFO - 2017-12-18 06:45:45 --> Output Class Initialized
INFO - 2017-12-18 06:45:45 --> Security Class Initialized
DEBUG - 2017-12-18 06:45:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 06:45:45 --> Input Class Initialized
INFO - 2017-12-18 06:45:45 --> Language Class Initialized
INFO - 2017-12-18 06:45:45 --> Loader Class Initialized
INFO - 2017-12-18 06:45:45 --> Helper loaded: url_helper
INFO - 2017-12-18 06:45:45 --> Helper loaded: form_helper
INFO - 2017-12-18 06:45:45 --> Database Driver Class Initialized
DEBUG - 2017-12-18 06:45:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-18 06:45:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-18 06:45:45 --> Form Validation Class Initialized
INFO - 2017-12-18 06:45:45 --> Model Class Initialized
INFO - 2017-12-18 06:45:45 --> Controller Class Initialized
INFO - 2017-12-18 06:45:45 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-18 06:45:45 --> Final output sent to browser
DEBUG - 2017-12-18 06:45:45 --> Total execution time: 0.0539
INFO - 2017-12-18 06:45:47 --> Config Class Initialized
INFO - 2017-12-18 06:45:47 --> Hooks Class Initialized
DEBUG - 2017-12-18 06:45:47 --> UTF-8 Support Enabled
INFO - 2017-12-18 06:45:47 --> Utf8 Class Initialized
INFO - 2017-12-18 06:45:47 --> URI Class Initialized
INFO - 2017-12-18 06:45:47 --> Router Class Initialized
INFO - 2017-12-18 06:45:47 --> Output Class Initialized
INFO - 2017-12-18 06:45:47 --> Security Class Initialized
DEBUG - 2017-12-18 06:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 06:45:47 --> Input Class Initialized
INFO - 2017-12-18 06:45:47 --> Language Class Initialized
INFO - 2017-12-18 06:45:47 --> Loader Class Initialized
INFO - 2017-12-18 06:45:47 --> Helper loaded: url_helper
INFO - 2017-12-18 06:45:47 --> Helper loaded: form_helper
INFO - 2017-12-18 06:45:47 --> Database Driver Class Initialized
DEBUG - 2017-12-18 06:45:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-18 06:45:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-18 06:45:47 --> Form Validation Class Initialized
INFO - 2017-12-18 06:45:47 --> Model Class Initialized
INFO - 2017-12-18 06:45:47 --> Controller Class Initialized
INFO - 2017-12-18 06:45:47 --> Model Class Initialized
INFO - 2017-12-18 06:45:47 --> Model Class Initialized
INFO - 2017-12-18 06:45:47 --> Model Class Initialized
DEBUG - 2017-12-18 06:45:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-18 06:45:47 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-18 06:45:47 --> Final output sent to browser
DEBUG - 2017-12-18 06:45:47 --> Total execution time: 0.0648
INFO - 2017-12-18 06:45:47 --> Config Class Initialized
INFO - 2017-12-18 06:45:47 --> Hooks Class Initialized
DEBUG - 2017-12-18 06:45:47 --> UTF-8 Support Enabled
INFO - 2017-12-18 06:45:47 --> Utf8 Class Initialized
INFO - 2017-12-18 06:45:47 --> URI Class Initialized
INFO - 2017-12-18 06:45:47 --> Router Class Initialized
INFO - 2017-12-18 06:45:47 --> Output Class Initialized
INFO - 2017-12-18 06:45:47 --> Security Class Initialized
DEBUG - 2017-12-18 06:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 06:45:47 --> Input Class Initialized
INFO - 2017-12-18 06:45:47 --> Language Class Initialized
INFO - 2017-12-18 06:45:47 --> Loader Class Initialized
INFO - 2017-12-18 06:45:47 --> Helper loaded: url_helper
INFO - 2017-12-18 06:45:47 --> Helper loaded: form_helper
INFO - 2017-12-18 06:45:47 --> Database Driver Class Initialized
DEBUG - 2017-12-18 06:45:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-18 06:45:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-18 06:45:47 --> Form Validation Class Initialized
INFO - 2017-12-18 06:45:47 --> Model Class Initialized
INFO - 2017-12-18 06:45:47 --> Controller Class Initialized
INFO - 2017-12-18 06:45:47 --> Model Class Initialized
INFO - 2017-12-18 06:45:47 --> Model Class Initialized
INFO - 2017-12-18 06:45:47 --> Model Class Initialized
DEBUG - 2017-12-18 06:45:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-18 06:45:54 --> Config Class Initialized
INFO - 2017-12-18 06:45:54 --> Hooks Class Initialized
DEBUG - 2017-12-18 06:45:54 --> UTF-8 Support Enabled
INFO - 2017-12-18 06:45:54 --> Utf8 Class Initialized
INFO - 2017-12-18 06:45:54 --> URI Class Initialized
INFO - 2017-12-18 06:45:54 --> Router Class Initialized
INFO - 2017-12-18 06:45:54 --> Output Class Initialized
INFO - 2017-12-18 06:45:54 --> Security Class Initialized
DEBUG - 2017-12-18 06:45:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 06:45:54 --> Input Class Initialized
INFO - 2017-12-18 06:45:54 --> Language Class Initialized
INFO - 2017-12-18 06:45:54 --> Loader Class Initialized
INFO - 2017-12-18 06:45:54 --> Helper loaded: url_helper
INFO - 2017-12-18 06:45:54 --> Helper loaded: form_helper
INFO - 2017-12-18 06:45:54 --> Database Driver Class Initialized
DEBUG - 2017-12-18 06:45:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-18 06:45:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-18 06:45:55 --> Form Validation Class Initialized
INFO - 2017-12-18 06:45:55 --> Model Class Initialized
INFO - 2017-12-18 06:45:55 --> Controller Class Initialized
INFO - 2017-12-18 06:45:55 --> Model Class Initialized
INFO - 2017-12-18 06:45:55 --> Model Class Initialized
INFO - 2017-12-18 06:45:55 --> Model Class Initialized
DEBUG - 2017-12-18 06:45:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-18 06:45:55 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-18 06:45:55 --> Final output sent to browser
DEBUG - 2017-12-18 06:45:55 --> Total execution time: 0.0843
INFO - 2017-12-18 06:45:55 --> Config Class Initialized
INFO - 2017-12-18 06:45:55 --> Hooks Class Initialized
INFO - 2017-12-18 06:45:55 --> Config Class Initialized
INFO - 2017-12-18 06:45:55 --> Hooks Class Initialized
DEBUG - 2017-12-18 06:45:55 --> UTF-8 Support Enabled
INFO - 2017-12-18 06:45:55 --> Utf8 Class Initialized
INFO - 2017-12-18 06:45:55 --> URI Class Initialized
DEBUG - 2017-12-18 06:45:55 --> UTF-8 Support Enabled
INFO - 2017-12-18 06:45:55 --> Utf8 Class Initialized
INFO - 2017-12-18 06:45:55 --> Router Class Initialized
INFO - 2017-12-18 06:45:55 --> URI Class Initialized
INFO - 2017-12-18 06:45:55 --> Output Class Initialized
INFO - 2017-12-18 06:45:55 --> Router Class Initialized
INFO - 2017-12-18 06:45:55 --> Security Class Initialized
INFO - 2017-12-18 06:45:55 --> Output Class Initialized
DEBUG - 2017-12-18 06:45:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 06:45:55 --> Input Class Initialized
INFO - 2017-12-18 06:45:55 --> Security Class Initialized
INFO - 2017-12-18 06:45:55 --> Language Class Initialized
DEBUG - 2017-12-18 06:45:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 06:45:55 --> Input Class Initialized
INFO - 2017-12-18 06:45:55 --> Language Class Initialized
INFO - 2017-12-18 06:45:55 --> Loader Class Initialized
INFO - 2017-12-18 06:45:55 --> Helper loaded: url_helper
INFO - 2017-12-18 06:45:55 --> Loader Class Initialized
INFO - 2017-12-18 06:45:55 --> Helper loaded: form_helper
INFO - 2017-12-18 06:45:55 --> Helper loaded: url_helper
INFO - 2017-12-18 06:45:55 --> Helper loaded: form_helper
INFO - 2017-12-18 06:45:55 --> Database Driver Class Initialized
INFO - 2017-12-18 06:45:55 --> Database Driver Class Initialized
DEBUG - 2017-12-18 06:45:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-18 06:45:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-18 06:45:55 --> Form Validation Class Initialized
INFO - 2017-12-18 06:45:55 --> Model Class Initialized
INFO - 2017-12-18 06:45:55 --> Controller Class Initialized
INFO - 2017-12-18 06:45:55 --> Model Class Initialized
INFO - 2017-12-18 06:45:55 --> Model Class Initialized
INFO - 2017-12-18 06:45:55 --> Model Class Initialized
DEBUG - 2017-12-18 06:45:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2017-12-18 06:45:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-18 06:45:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-18 06:45:55 --> Form Validation Class Initialized
INFO - 2017-12-18 06:45:55 --> Model Class Initialized
INFO - 2017-12-18 06:45:55 --> Controller Class Initialized
INFO - 2017-12-18 06:45:55 --> Model Class Initialized
INFO - 2017-12-18 06:45:55 --> Model Class Initialized
INFO - 2017-12-18 06:45:55 --> Model Class Initialized
DEBUG - 2017-12-18 06:45:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-18 06:48:36 --> Config Class Initialized
INFO - 2017-12-18 06:48:36 --> Hooks Class Initialized
DEBUG - 2017-12-18 06:48:36 --> UTF-8 Support Enabled
INFO - 2017-12-18 06:48:36 --> Utf8 Class Initialized
INFO - 2017-12-18 06:48:36 --> URI Class Initialized
INFO - 2017-12-18 06:48:36 --> Router Class Initialized
INFO - 2017-12-18 06:48:36 --> Output Class Initialized
INFO - 2017-12-18 06:48:36 --> Security Class Initialized
DEBUG - 2017-12-18 06:48:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 06:48:36 --> Input Class Initialized
INFO - 2017-12-18 06:48:36 --> Language Class Initialized
INFO - 2017-12-18 06:48:36 --> Loader Class Initialized
INFO - 2017-12-18 06:48:36 --> Helper loaded: url_helper
INFO - 2017-12-18 06:48:36 --> Helper loaded: form_helper
INFO - 2017-12-18 06:48:36 --> Database Driver Class Initialized
DEBUG - 2017-12-18 06:48:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-18 06:48:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-18 06:48:36 --> Form Validation Class Initialized
INFO - 2017-12-18 06:48:36 --> Model Class Initialized
INFO - 2017-12-18 06:48:36 --> Controller Class Initialized
INFO - 2017-12-18 06:48:36 --> Model Class Initialized
INFO - 2017-12-18 06:48:36 --> Model Class Initialized
INFO - 2017-12-18 06:48:36 --> Model Class Initialized
DEBUG - 2017-12-18 06:48:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-18 06:48:36 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-18 06:48:36 --> Final output sent to browser
DEBUG - 2017-12-18 06:48:36 --> Total execution time: 0.1139
INFO - 2017-12-18 06:48:37 --> Config Class Initialized
INFO - 2017-12-18 06:48:37 --> Hooks Class Initialized
INFO - 2017-12-18 06:48:37 --> Config Class Initialized
INFO - 2017-12-18 06:48:37 --> Hooks Class Initialized
DEBUG - 2017-12-18 06:48:37 --> UTF-8 Support Enabled
INFO - 2017-12-18 06:48:37 --> Utf8 Class Initialized
DEBUG - 2017-12-18 06:48:37 --> UTF-8 Support Enabled
INFO - 2017-12-18 06:48:37 --> Utf8 Class Initialized
INFO - 2017-12-18 06:48:37 --> URI Class Initialized
INFO - 2017-12-18 06:48:37 --> URI Class Initialized
INFO - 2017-12-18 06:48:37 --> Router Class Initialized
INFO - 2017-12-18 06:48:37 --> Router Class Initialized
INFO - 2017-12-18 06:48:37 --> Output Class Initialized
INFO - 2017-12-18 06:48:37 --> Output Class Initialized
INFO - 2017-12-18 06:48:37 --> Security Class Initialized
INFO - 2017-12-18 06:48:37 --> Security Class Initialized
DEBUG - 2017-12-18 06:48:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-18 06:48:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 06:48:37 --> Input Class Initialized
INFO - 2017-12-18 06:48:37 --> Input Class Initialized
INFO - 2017-12-18 06:48:37 --> Language Class Initialized
INFO - 2017-12-18 06:48:37 --> Language Class Initialized
INFO - 2017-12-18 06:48:37 --> Loader Class Initialized
INFO - 2017-12-18 06:48:37 --> Loader Class Initialized
INFO - 2017-12-18 06:48:37 --> Helper loaded: url_helper
INFO - 2017-12-18 06:48:37 --> Helper loaded: url_helper
INFO - 2017-12-18 06:48:37 --> Helper loaded: form_helper
INFO - 2017-12-18 06:48:37 --> Helper loaded: form_helper
INFO - 2017-12-18 06:48:37 --> Database Driver Class Initialized
INFO - 2017-12-18 06:48:37 --> Database Driver Class Initialized
DEBUG - 2017-12-18 06:48:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2017-12-18 06:48:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-18 06:48:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-18 06:48:37 --> Form Validation Class Initialized
INFO - 2017-12-18 06:48:37 --> Model Class Initialized
INFO - 2017-12-18 06:48:37 --> Controller Class Initialized
INFO - 2017-12-18 06:48:37 --> Model Class Initialized
INFO - 2017-12-18 06:48:37 --> Model Class Initialized
INFO - 2017-12-18 06:48:37 --> Model Class Initialized
DEBUG - 2017-12-18 06:48:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-18 06:48:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-18 06:48:37 --> Form Validation Class Initialized
INFO - 2017-12-18 06:48:37 --> Model Class Initialized
INFO - 2017-12-18 06:48:37 --> Controller Class Initialized
INFO - 2017-12-18 06:48:37 --> Model Class Initialized
INFO - 2017-12-18 06:48:37 --> Model Class Initialized
INFO - 2017-12-18 06:48:37 --> Model Class Initialized
DEBUG - 2017-12-18 06:48:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-18 06:49:55 --> Config Class Initialized
INFO - 2017-12-18 06:49:55 --> Hooks Class Initialized
DEBUG - 2017-12-18 06:49:55 --> UTF-8 Support Enabled
INFO - 2017-12-18 06:49:55 --> Utf8 Class Initialized
INFO - 2017-12-18 06:49:55 --> URI Class Initialized
INFO - 2017-12-18 06:49:55 --> Router Class Initialized
INFO - 2017-12-18 06:49:55 --> Output Class Initialized
INFO - 2017-12-18 06:49:55 --> Security Class Initialized
DEBUG - 2017-12-18 06:49:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 06:49:55 --> Input Class Initialized
INFO - 2017-12-18 06:49:55 --> Language Class Initialized
INFO - 2017-12-18 06:49:55 --> Loader Class Initialized
INFO - 2017-12-18 06:49:55 --> Helper loaded: url_helper
INFO - 2017-12-18 06:49:55 --> Helper loaded: form_helper
INFO - 2017-12-18 06:49:55 --> Database Driver Class Initialized
DEBUG - 2017-12-18 06:49:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-18 06:49:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-18 06:49:55 --> Form Validation Class Initialized
INFO - 2017-12-18 06:49:55 --> Model Class Initialized
INFO - 2017-12-18 06:49:55 --> Controller Class Initialized
INFO - 2017-12-18 06:49:55 --> Model Class Initialized
INFO - 2017-12-18 06:49:55 --> Model Class Initialized
INFO - 2017-12-18 06:49:55 --> Model Class Initialized
DEBUG - 2017-12-18 06:49:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-18 06:49:55 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-18 06:49:55 --> Final output sent to browser
DEBUG - 2017-12-18 06:49:55 --> Total execution time: 0.1463
INFO - 2017-12-18 06:49:55 --> Config Class Initialized
INFO - 2017-12-18 06:49:55 --> Hooks Class Initialized
INFO - 2017-12-18 06:49:55 --> Config Class Initialized
INFO - 2017-12-18 06:49:55 --> Hooks Class Initialized
DEBUG - 2017-12-18 06:49:55 --> UTF-8 Support Enabled
INFO - 2017-12-18 06:49:55 --> Utf8 Class Initialized
DEBUG - 2017-12-18 06:49:55 --> UTF-8 Support Enabled
INFO - 2017-12-18 06:49:55 --> Utf8 Class Initialized
INFO - 2017-12-18 06:49:55 --> URI Class Initialized
INFO - 2017-12-18 06:49:55 --> URI Class Initialized
INFO - 2017-12-18 06:49:55 --> Router Class Initialized
INFO - 2017-12-18 06:49:55 --> Router Class Initialized
INFO - 2017-12-18 06:49:55 --> Output Class Initialized
INFO - 2017-12-18 06:49:55 --> Output Class Initialized
INFO - 2017-12-18 06:49:55 --> Security Class Initialized
INFO - 2017-12-18 06:49:55 --> Security Class Initialized
DEBUG - 2017-12-18 06:49:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 06:49:55 --> Input Class Initialized
DEBUG - 2017-12-18 06:49:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 06:49:55 --> Language Class Initialized
INFO - 2017-12-18 06:49:55 --> Input Class Initialized
INFO - 2017-12-18 06:49:55 --> Language Class Initialized
INFO - 2017-12-18 06:49:55 --> Loader Class Initialized
INFO - 2017-12-18 06:49:55 --> Loader Class Initialized
INFO - 2017-12-18 06:49:55 --> Helper loaded: url_helper
INFO - 2017-12-18 06:49:55 --> Helper loaded: url_helper
INFO - 2017-12-18 06:49:55 --> Helper loaded: form_helper
INFO - 2017-12-18 06:49:55 --> Helper loaded: form_helper
INFO - 2017-12-18 06:49:55 --> Database Driver Class Initialized
INFO - 2017-12-18 06:49:55 --> Database Driver Class Initialized
DEBUG - 2017-12-18 06:49:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2017-12-18 06:49:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-18 06:49:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-18 06:49:55 --> Form Validation Class Initialized
INFO - 2017-12-18 06:49:55 --> Model Class Initialized
INFO - 2017-12-18 06:49:55 --> Controller Class Initialized
INFO - 2017-12-18 06:49:55 --> Model Class Initialized
INFO - 2017-12-18 06:49:55 --> Model Class Initialized
INFO - 2017-12-18 06:49:55 --> Model Class Initialized
DEBUG - 2017-12-18 06:49:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-18 06:49:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-18 06:49:55 --> Form Validation Class Initialized
INFO - 2017-12-18 06:49:55 --> Model Class Initialized
INFO - 2017-12-18 06:49:55 --> Controller Class Initialized
INFO - 2017-12-18 06:49:55 --> Model Class Initialized
INFO - 2017-12-18 06:49:55 --> Model Class Initialized
INFO - 2017-12-18 06:49:55 --> Model Class Initialized
DEBUG - 2017-12-18 06:49:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-18 06:50:56 --> Config Class Initialized
INFO - 2017-12-18 06:50:56 --> Hooks Class Initialized
DEBUG - 2017-12-18 06:50:56 --> UTF-8 Support Enabled
INFO - 2017-12-18 06:50:56 --> Utf8 Class Initialized
INFO - 2017-12-18 06:50:56 --> URI Class Initialized
INFO - 2017-12-18 06:50:56 --> Router Class Initialized
INFO - 2017-12-18 06:50:56 --> Output Class Initialized
INFO - 2017-12-18 06:50:56 --> Security Class Initialized
DEBUG - 2017-12-18 06:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 06:50:56 --> Input Class Initialized
INFO - 2017-12-18 06:50:56 --> Language Class Initialized
INFO - 2017-12-18 06:50:56 --> Loader Class Initialized
INFO - 2017-12-18 06:50:56 --> Helper loaded: url_helper
INFO - 2017-12-18 06:50:56 --> Helper loaded: form_helper
INFO - 2017-12-18 06:50:56 --> Database Driver Class Initialized
DEBUG - 2017-12-18 06:50:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-18 06:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-18 06:50:56 --> Form Validation Class Initialized
INFO - 2017-12-18 06:50:56 --> Model Class Initialized
INFO - 2017-12-18 06:50:56 --> Controller Class Initialized
INFO - 2017-12-18 06:50:56 --> Model Class Initialized
INFO - 2017-12-18 06:50:56 --> Model Class Initialized
INFO - 2017-12-18 06:50:56 --> Model Class Initialized
DEBUG - 2017-12-18 06:50:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-18 06:50:56 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-18 06:50:56 --> Final output sent to browser
DEBUG - 2017-12-18 06:50:56 --> Total execution time: 0.0924
INFO - 2017-12-18 06:50:56 --> Config Class Initialized
INFO - 2017-12-18 06:50:56 --> Hooks Class Initialized
INFO - 2017-12-18 06:50:56 --> Config Class Initialized
INFO - 2017-12-18 06:50:56 --> Hooks Class Initialized
DEBUG - 2017-12-18 06:50:56 --> UTF-8 Support Enabled
INFO - 2017-12-18 06:50:56 --> Utf8 Class Initialized
DEBUG - 2017-12-18 06:50:56 --> UTF-8 Support Enabled
INFO - 2017-12-18 06:50:56 --> Utf8 Class Initialized
INFO - 2017-12-18 06:50:56 --> URI Class Initialized
INFO - 2017-12-18 06:50:56 --> URI Class Initialized
INFO - 2017-12-18 06:50:56 --> Router Class Initialized
INFO - 2017-12-18 06:50:56 --> Router Class Initialized
INFO - 2017-12-18 06:50:56 --> Output Class Initialized
INFO - 2017-12-18 06:50:56 --> Output Class Initialized
INFO - 2017-12-18 06:50:56 --> Security Class Initialized
INFO - 2017-12-18 06:50:56 --> Security Class Initialized
DEBUG - 2017-12-18 06:50:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-18 06:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 06:50:56 --> Input Class Initialized
INFO - 2017-12-18 06:50:56 --> Input Class Initialized
INFO - 2017-12-18 06:50:56 --> Language Class Initialized
INFO - 2017-12-18 06:50:56 --> Language Class Initialized
INFO - 2017-12-18 06:50:56 --> Loader Class Initialized
INFO - 2017-12-18 06:50:56 --> Loader Class Initialized
INFO - 2017-12-18 06:50:56 --> Helper loaded: url_helper
INFO - 2017-12-18 06:50:56 --> Helper loaded: url_helper
INFO - 2017-12-18 06:50:56 --> Helper loaded: form_helper
INFO - 2017-12-18 06:50:56 --> Helper loaded: form_helper
INFO - 2017-12-18 06:50:56 --> Database Driver Class Initialized
INFO - 2017-12-18 06:50:56 --> Database Driver Class Initialized
DEBUG - 2017-12-18 06:50:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2017-12-18 06:50:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-18 06:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-18 06:50:56 --> Form Validation Class Initialized
INFO - 2017-12-18 06:50:56 --> Model Class Initialized
INFO - 2017-12-18 06:50:56 --> Controller Class Initialized
INFO - 2017-12-18 06:50:56 --> Model Class Initialized
INFO - 2017-12-18 06:50:56 --> Model Class Initialized
INFO - 2017-12-18 06:50:56 --> Model Class Initialized
DEBUG - 2017-12-18 06:50:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-18 06:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-18 06:50:56 --> Form Validation Class Initialized
INFO - 2017-12-18 06:50:56 --> Model Class Initialized
INFO - 2017-12-18 06:50:56 --> Controller Class Initialized
INFO - 2017-12-18 06:50:56 --> Model Class Initialized
INFO - 2017-12-18 06:50:56 --> Model Class Initialized
INFO - 2017-12-18 06:50:56 --> Model Class Initialized
DEBUG - 2017-12-18 06:50:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-18 06:51:19 --> Config Class Initialized
INFO - 2017-12-18 06:51:19 --> Hooks Class Initialized
DEBUG - 2017-12-18 06:51:19 --> UTF-8 Support Enabled
INFO - 2017-12-18 06:51:19 --> Utf8 Class Initialized
INFO - 2017-12-18 06:51:19 --> URI Class Initialized
INFO - 2017-12-18 06:51:19 --> Router Class Initialized
INFO - 2017-12-18 06:51:19 --> Output Class Initialized
INFO - 2017-12-18 06:51:19 --> Security Class Initialized
DEBUG - 2017-12-18 06:51:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 06:51:19 --> Input Class Initialized
INFO - 2017-12-18 06:51:19 --> Language Class Initialized
INFO - 2017-12-18 06:51:19 --> Loader Class Initialized
INFO - 2017-12-18 06:51:19 --> Helper loaded: url_helper
INFO - 2017-12-18 06:51:19 --> Helper loaded: form_helper
INFO - 2017-12-18 06:51:19 --> Database Driver Class Initialized
DEBUG - 2017-12-18 06:51:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-18 06:51:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-18 06:51:19 --> Form Validation Class Initialized
INFO - 2017-12-18 06:51:19 --> Model Class Initialized
INFO - 2017-12-18 06:51:19 --> Controller Class Initialized
INFO - 2017-12-18 06:51:19 --> Model Class Initialized
INFO - 2017-12-18 06:51:19 --> Model Class Initialized
INFO - 2017-12-18 06:51:19 --> Model Class Initialized
DEBUG - 2017-12-18 06:51:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-18 06:51:19 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-18 06:51:19 --> Final output sent to browser
DEBUG - 2017-12-18 06:51:19 --> Total execution time: 0.0553
INFO - 2017-12-18 06:51:19 --> Config Class Initialized
INFO - 2017-12-18 06:51:19 --> Hooks Class Initialized
INFO - 2017-12-18 06:51:19 --> Config Class Initialized
INFO - 2017-12-18 06:51:19 --> Hooks Class Initialized
DEBUG - 2017-12-18 06:51:20 --> UTF-8 Support Enabled
INFO - 2017-12-18 06:51:20 --> Utf8 Class Initialized
DEBUG - 2017-12-18 06:51:20 --> UTF-8 Support Enabled
INFO - 2017-12-18 06:51:20 --> Utf8 Class Initialized
INFO - 2017-12-18 06:51:20 --> URI Class Initialized
INFO - 2017-12-18 06:51:20 --> URI Class Initialized
INFO - 2017-12-18 06:51:20 --> Router Class Initialized
INFO - 2017-12-18 06:51:20 --> Router Class Initialized
INFO - 2017-12-18 06:51:20 --> Output Class Initialized
INFO - 2017-12-18 06:51:20 --> Output Class Initialized
INFO - 2017-12-18 06:51:20 --> Security Class Initialized
INFO - 2017-12-18 06:51:20 --> Security Class Initialized
DEBUG - 2017-12-18 06:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 06:51:20 --> Input Class Initialized
DEBUG - 2017-12-18 06:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 06:51:20 --> Input Class Initialized
INFO - 2017-12-18 06:51:20 --> Language Class Initialized
INFO - 2017-12-18 06:51:20 --> Language Class Initialized
INFO - 2017-12-18 06:51:20 --> Loader Class Initialized
INFO - 2017-12-18 06:51:20 --> Loader Class Initialized
INFO - 2017-12-18 06:51:20 --> Helper loaded: url_helper
INFO - 2017-12-18 06:51:20 --> Helper loaded: url_helper
INFO - 2017-12-18 06:51:20 --> Helper loaded: form_helper
INFO - 2017-12-18 06:51:20 --> Helper loaded: form_helper
INFO - 2017-12-18 06:51:20 --> Database Driver Class Initialized
INFO - 2017-12-18 06:51:20 --> Database Driver Class Initialized
DEBUG - 2017-12-18 06:51:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2017-12-18 06:51:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-18 06:51:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-18 06:51:20 --> Form Validation Class Initialized
INFO - 2017-12-18 06:51:20 --> Model Class Initialized
INFO - 2017-12-18 06:51:20 --> Controller Class Initialized
INFO - 2017-12-18 06:51:20 --> Model Class Initialized
INFO - 2017-12-18 06:51:20 --> Model Class Initialized
INFO - 2017-12-18 06:51:20 --> Model Class Initialized
DEBUG - 2017-12-18 06:51:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-18 06:51:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-18 06:51:20 --> Form Validation Class Initialized
INFO - 2017-12-18 06:51:20 --> Model Class Initialized
INFO - 2017-12-18 06:51:20 --> Controller Class Initialized
INFO - 2017-12-18 06:51:20 --> Model Class Initialized
INFO - 2017-12-18 06:51:20 --> Model Class Initialized
INFO - 2017-12-18 06:51:20 --> Model Class Initialized
DEBUG - 2017-12-18 06:51:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-18 06:51:29 --> Config Class Initialized
INFO - 2017-12-18 06:51:29 --> Config Class Initialized
INFO - 2017-12-18 06:51:29 --> Hooks Class Initialized
INFO - 2017-12-18 06:51:29 --> Hooks Class Initialized
DEBUG - 2017-12-18 06:51:29 --> UTF-8 Support Enabled
DEBUG - 2017-12-18 06:51:29 --> UTF-8 Support Enabled
INFO - 2017-12-18 06:51:29 --> Utf8 Class Initialized
INFO - 2017-12-18 06:51:29 --> Utf8 Class Initialized
INFO - 2017-12-18 06:51:29 --> URI Class Initialized
INFO - 2017-12-18 06:51:29 --> URI Class Initialized
INFO - 2017-12-18 06:51:29 --> Router Class Initialized
INFO - 2017-12-18 06:51:29 --> Router Class Initialized
INFO - 2017-12-18 06:51:29 --> Output Class Initialized
INFO - 2017-12-18 06:51:29 --> Output Class Initialized
INFO - 2017-12-18 06:51:29 --> Security Class Initialized
INFO - 2017-12-18 06:51:29 --> Security Class Initialized
DEBUG - 2017-12-18 06:51:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-18 06:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 06:51:29 --> Input Class Initialized
INFO - 2017-12-18 06:51:29 --> Input Class Initialized
INFO - 2017-12-18 06:51:29 --> Language Class Initialized
INFO - 2017-12-18 06:51:29 --> Language Class Initialized
ERROR - 2017-12-18 06:51:29 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-18 06:51:29 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-18 06:52:24 --> Config Class Initialized
INFO - 2017-12-18 06:52:24 --> Hooks Class Initialized
DEBUG - 2017-12-18 06:52:24 --> UTF-8 Support Enabled
INFO - 2017-12-18 06:52:24 --> Utf8 Class Initialized
INFO - 2017-12-18 06:52:24 --> URI Class Initialized
INFO - 2017-12-18 06:52:24 --> Router Class Initialized
INFO - 2017-12-18 06:52:24 --> Output Class Initialized
INFO - 2017-12-18 06:52:24 --> Security Class Initialized
DEBUG - 2017-12-18 06:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 06:52:24 --> Input Class Initialized
INFO - 2017-12-18 06:52:24 --> Language Class Initialized
INFO - 2017-12-18 06:52:24 --> Loader Class Initialized
INFO - 2017-12-18 06:52:24 --> Helper loaded: url_helper
INFO - 2017-12-18 06:52:24 --> Helper loaded: form_helper
INFO - 2017-12-18 06:52:24 --> Database Driver Class Initialized
DEBUG - 2017-12-18 06:52:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-18 06:52:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-18 06:52:24 --> Form Validation Class Initialized
INFO - 2017-12-18 06:52:24 --> Model Class Initialized
INFO - 2017-12-18 06:52:24 --> Controller Class Initialized
INFO - 2017-12-18 06:52:24 --> Model Class Initialized
INFO - 2017-12-18 06:52:24 --> Model Class Initialized
INFO - 2017-12-18 06:52:24 --> Model Class Initialized
DEBUG - 2017-12-18 06:52:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-18 06:52:24 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-18 06:52:24 --> Final output sent to browser
DEBUG - 2017-12-18 06:52:24 --> Total execution time: 0.1209
INFO - 2017-12-18 06:52:24 --> Config Class Initialized
INFO - 2017-12-18 06:52:24 --> Hooks Class Initialized
INFO - 2017-12-18 06:52:24 --> Config Class Initialized
INFO - 2017-12-18 06:52:24 --> Hooks Class Initialized
DEBUG - 2017-12-18 06:52:24 --> UTF-8 Support Enabled
INFO - 2017-12-18 06:52:24 --> Utf8 Class Initialized
INFO - 2017-12-18 06:52:24 --> URI Class Initialized
DEBUG - 2017-12-18 06:52:24 --> UTF-8 Support Enabled
INFO - 2017-12-18 06:52:24 --> Utf8 Class Initialized
INFO - 2017-12-18 06:52:24 --> Router Class Initialized
INFO - 2017-12-18 06:52:24 --> URI Class Initialized
INFO - 2017-12-18 06:52:24 --> Output Class Initialized
INFO - 2017-12-18 06:52:24 --> Router Class Initialized
INFO - 2017-12-18 06:52:24 --> Security Class Initialized
INFO - 2017-12-18 06:52:24 --> Output Class Initialized
DEBUG - 2017-12-18 06:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 06:52:24 --> Input Class Initialized
INFO - 2017-12-18 06:52:24 --> Security Class Initialized
INFO - 2017-12-18 06:52:24 --> Language Class Initialized
DEBUG - 2017-12-18 06:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 06:52:24 --> Input Class Initialized
ERROR - 2017-12-18 06:52:24 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-18 06:52:24 --> Language Class Initialized
ERROR - 2017-12-18 06:52:24 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-18 06:52:24 --> Config Class Initialized
INFO - 2017-12-18 06:52:24 --> Hooks Class Initialized
INFO - 2017-12-18 06:52:24 --> Config Class Initialized
INFO - 2017-12-18 06:52:24 --> Hooks Class Initialized
DEBUG - 2017-12-18 06:52:24 --> UTF-8 Support Enabled
INFO - 2017-12-18 06:52:24 --> Utf8 Class Initialized
DEBUG - 2017-12-18 06:52:24 --> UTF-8 Support Enabled
INFO - 2017-12-18 06:52:24 --> URI Class Initialized
INFO - 2017-12-18 06:52:24 --> Utf8 Class Initialized
INFO - 2017-12-18 06:52:24 --> URI Class Initialized
INFO - 2017-12-18 06:52:24 --> Router Class Initialized
INFO - 2017-12-18 06:52:24 --> Router Class Initialized
INFO - 2017-12-18 06:52:24 --> Output Class Initialized
INFO - 2017-12-18 06:52:24 --> Output Class Initialized
INFO - 2017-12-18 06:52:24 --> Security Class Initialized
INFO - 2017-12-18 06:52:24 --> Security Class Initialized
DEBUG - 2017-12-18 06:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 06:52:24 --> Input Class Initialized
DEBUG - 2017-12-18 06:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 06:52:24 --> Language Class Initialized
INFO - 2017-12-18 06:52:24 --> Input Class Initialized
INFO - 2017-12-18 06:52:24 --> Language Class Initialized
INFO - 2017-12-18 06:52:24 --> Loader Class Initialized
INFO - 2017-12-18 06:52:24 --> Loader Class Initialized
INFO - 2017-12-18 06:52:24 --> Helper loaded: url_helper
INFO - 2017-12-18 06:52:24 --> Helper loaded: url_helper
INFO - 2017-12-18 06:52:24 --> Helper loaded: form_helper
INFO - 2017-12-18 06:52:24 --> Helper loaded: form_helper
INFO - 2017-12-18 06:52:24 --> Database Driver Class Initialized
INFO - 2017-12-18 06:52:24 --> Database Driver Class Initialized
DEBUG - 2017-12-18 06:52:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-18 06:52:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-18 06:52:24 --> Form Validation Class Initialized
DEBUG - 2017-12-18 06:52:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-18 06:52:24 --> Model Class Initialized
INFO - 2017-12-18 06:52:24 --> Controller Class Initialized
INFO - 2017-12-18 06:52:24 --> Model Class Initialized
INFO - 2017-12-18 06:52:24 --> Model Class Initialized
INFO - 2017-12-18 06:52:24 --> Model Class Initialized
DEBUG - 2017-12-18 06:52:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-18 06:52:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-18 06:52:24 --> Form Validation Class Initialized
INFO - 2017-12-18 06:52:24 --> Model Class Initialized
INFO - 2017-12-18 06:52:24 --> Controller Class Initialized
INFO - 2017-12-18 06:52:24 --> Model Class Initialized
INFO - 2017-12-18 06:52:24 --> Model Class Initialized
INFO - 2017-12-18 06:52:24 --> Model Class Initialized
DEBUG - 2017-12-18 06:52:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-18 06:52:35 --> Config Class Initialized
INFO - 2017-12-18 06:52:35 --> Hooks Class Initialized
DEBUG - 2017-12-18 06:52:35 --> UTF-8 Support Enabled
INFO - 2017-12-18 06:52:35 --> Utf8 Class Initialized
INFO - 2017-12-18 06:52:35 --> URI Class Initialized
INFO - 2017-12-18 06:52:35 --> Router Class Initialized
INFO - 2017-12-18 06:52:35 --> Output Class Initialized
INFO - 2017-12-18 06:52:35 --> Security Class Initialized
DEBUG - 2017-12-18 06:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 06:52:35 --> Input Class Initialized
INFO - 2017-12-18 06:52:35 --> Language Class Initialized
INFO - 2017-12-18 06:52:35 --> Loader Class Initialized
INFO - 2017-12-18 06:52:35 --> Helper loaded: url_helper
INFO - 2017-12-18 06:52:35 --> Helper loaded: form_helper
INFO - 2017-12-18 06:52:35 --> Database Driver Class Initialized
DEBUG - 2017-12-18 06:52:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-18 06:52:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-18 06:52:35 --> Form Validation Class Initialized
INFO - 2017-12-18 06:52:35 --> Model Class Initialized
INFO - 2017-12-18 06:52:35 --> Controller Class Initialized
INFO - 2017-12-18 06:52:35 --> Model Class Initialized
INFO - 2017-12-18 06:52:35 --> Model Class Initialized
INFO - 2017-12-18 06:52:35 --> Model Class Initialized
DEBUG - 2017-12-18 06:52:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-18 06:52:35 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-18 06:52:35 --> Final output sent to browser
DEBUG - 2017-12-18 06:52:35 --> Total execution time: 0.1087
INFO - 2017-12-18 06:52:35 --> Config Class Initialized
INFO - 2017-12-18 06:52:35 --> Hooks Class Initialized
INFO - 2017-12-18 06:52:35 --> Config Class Initialized
INFO - 2017-12-18 06:52:35 --> Hooks Class Initialized
DEBUG - 2017-12-18 06:52:35 --> UTF-8 Support Enabled
INFO - 2017-12-18 06:52:35 --> Utf8 Class Initialized
DEBUG - 2017-12-18 06:52:35 --> UTF-8 Support Enabled
INFO - 2017-12-18 06:52:35 --> Utf8 Class Initialized
INFO - 2017-12-18 06:52:35 --> URI Class Initialized
INFO - 2017-12-18 06:52:35 --> URI Class Initialized
INFO - 2017-12-18 06:52:35 --> Router Class Initialized
INFO - 2017-12-18 06:52:35 --> Router Class Initialized
INFO - 2017-12-18 06:52:35 --> Output Class Initialized
INFO - 2017-12-18 06:52:35 --> Output Class Initialized
INFO - 2017-12-18 06:52:35 --> Security Class Initialized
INFO - 2017-12-18 06:52:35 --> Security Class Initialized
DEBUG - 2017-12-18 06:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 06:52:35 --> Input Class Initialized
DEBUG - 2017-12-18 06:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 06:52:35 --> Input Class Initialized
INFO - 2017-12-18 06:52:35 --> Language Class Initialized
INFO - 2017-12-18 06:52:35 --> Language Class Initialized
ERROR - 2017-12-18 06:52:35 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-18 06:52:35 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-18 06:52:36 --> Config Class Initialized
INFO - 2017-12-18 06:52:36 --> Hooks Class Initialized
INFO - 2017-12-18 06:52:36 --> Config Class Initialized
INFO - 2017-12-18 06:52:36 --> Hooks Class Initialized
DEBUG - 2017-12-18 06:52:36 --> UTF-8 Support Enabled
INFO - 2017-12-18 06:52:36 --> Utf8 Class Initialized
DEBUG - 2017-12-18 06:52:36 --> UTF-8 Support Enabled
INFO - 2017-12-18 06:52:36 --> Utf8 Class Initialized
INFO - 2017-12-18 06:52:36 --> URI Class Initialized
INFO - 2017-12-18 06:52:36 --> URI Class Initialized
INFO - 2017-12-18 06:52:36 --> Router Class Initialized
INFO - 2017-12-18 06:52:36 --> Router Class Initialized
INFO - 2017-12-18 06:52:36 --> Output Class Initialized
INFO - 2017-12-18 06:52:36 --> Output Class Initialized
INFO - 2017-12-18 06:52:36 --> Security Class Initialized
INFO - 2017-12-18 06:52:36 --> Security Class Initialized
DEBUG - 2017-12-18 06:52:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-18 06:52:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 06:52:36 --> Input Class Initialized
INFO - 2017-12-18 06:52:36 --> Input Class Initialized
INFO - 2017-12-18 06:52:36 --> Language Class Initialized
INFO - 2017-12-18 06:52:36 --> Language Class Initialized
INFO - 2017-12-18 06:52:36 --> Loader Class Initialized
INFO - 2017-12-18 06:52:36 --> Loader Class Initialized
INFO - 2017-12-18 06:52:36 --> Helper loaded: url_helper
INFO - 2017-12-18 06:52:36 --> Helper loaded: url_helper
INFO - 2017-12-18 06:52:36 --> Helper loaded: form_helper
INFO - 2017-12-18 06:52:36 --> Helper loaded: form_helper
INFO - 2017-12-18 06:52:36 --> Database Driver Class Initialized
INFO - 2017-12-18 06:52:36 --> Database Driver Class Initialized
DEBUG - 2017-12-18 06:52:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2017-12-18 06:52:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-18 06:52:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-18 06:52:36 --> Form Validation Class Initialized
INFO - 2017-12-18 06:52:36 --> Model Class Initialized
INFO - 2017-12-18 06:52:36 --> Controller Class Initialized
INFO - 2017-12-18 06:52:36 --> Model Class Initialized
INFO - 2017-12-18 06:52:36 --> Model Class Initialized
INFO - 2017-12-18 06:52:36 --> Model Class Initialized
DEBUG - 2017-12-18 06:52:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-18 06:52:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-18 06:52:36 --> Form Validation Class Initialized
INFO - 2017-12-18 06:52:36 --> Model Class Initialized
INFO - 2017-12-18 06:52:36 --> Controller Class Initialized
INFO - 2017-12-18 06:52:36 --> Model Class Initialized
INFO - 2017-12-18 06:52:36 --> Model Class Initialized
INFO - 2017-12-18 06:52:36 --> Model Class Initialized
DEBUG - 2017-12-18 06:52:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-18 06:52:47 --> Config Class Initialized
INFO - 2017-12-18 06:52:47 --> Hooks Class Initialized
DEBUG - 2017-12-18 06:52:47 --> UTF-8 Support Enabled
INFO - 2017-12-18 06:52:47 --> Utf8 Class Initialized
INFO - 2017-12-18 06:52:48 --> URI Class Initialized
INFO - 2017-12-18 06:52:48 --> Router Class Initialized
INFO - 2017-12-18 06:52:48 --> Output Class Initialized
INFO - 2017-12-18 06:52:48 --> Security Class Initialized
DEBUG - 2017-12-18 06:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 06:52:48 --> Input Class Initialized
INFO - 2017-12-18 06:52:48 --> Language Class Initialized
INFO - 2017-12-18 06:52:48 --> Loader Class Initialized
INFO - 2017-12-18 06:52:48 --> Helper loaded: url_helper
INFO - 2017-12-18 06:52:48 --> Helper loaded: form_helper
INFO - 2017-12-18 06:52:48 --> Database Driver Class Initialized
DEBUG - 2017-12-18 06:52:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-18 06:52:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-18 06:52:48 --> Form Validation Class Initialized
INFO - 2017-12-18 06:52:48 --> Model Class Initialized
INFO - 2017-12-18 06:52:48 --> Controller Class Initialized
INFO - 2017-12-18 06:52:48 --> Model Class Initialized
INFO - 2017-12-18 06:52:48 --> Model Class Initialized
INFO - 2017-12-18 06:52:48 --> Model Class Initialized
DEBUG - 2017-12-18 06:52:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-18 06:52:48 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-18 06:52:48 --> Final output sent to browser
DEBUG - 2017-12-18 06:52:48 --> Total execution time: 0.1272
INFO - 2017-12-18 06:52:48 --> Config Class Initialized
INFO - 2017-12-18 06:52:48 --> Hooks Class Initialized
INFO - 2017-12-18 06:52:48 --> Config Class Initialized
INFO - 2017-12-18 06:52:48 --> Hooks Class Initialized
DEBUG - 2017-12-18 06:52:48 --> UTF-8 Support Enabled
INFO - 2017-12-18 06:52:48 --> Utf8 Class Initialized
DEBUG - 2017-12-18 06:52:48 --> UTF-8 Support Enabled
INFO - 2017-12-18 06:52:48 --> Utf8 Class Initialized
INFO - 2017-12-18 06:52:48 --> URI Class Initialized
INFO - 2017-12-18 06:52:48 --> URI Class Initialized
INFO - 2017-12-18 06:52:48 --> Router Class Initialized
INFO - 2017-12-18 06:52:48 --> Router Class Initialized
INFO - 2017-12-18 06:52:48 --> Output Class Initialized
INFO - 2017-12-18 06:52:48 --> Output Class Initialized
INFO - 2017-12-18 06:52:48 --> Security Class Initialized
INFO - 2017-12-18 06:52:48 --> Security Class Initialized
DEBUG - 2017-12-18 06:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 06:52:48 --> Input Class Initialized
DEBUG - 2017-12-18 06:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 06:52:48 --> Input Class Initialized
INFO - 2017-12-18 06:52:48 --> Language Class Initialized
INFO - 2017-12-18 06:52:48 --> Language Class Initialized
ERROR - 2017-12-18 06:52:48 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-18 06:52:48 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-18 06:52:48 --> Config Class Initialized
INFO - 2017-12-18 06:52:48 --> Hooks Class Initialized
INFO - 2017-12-18 06:52:48 --> Config Class Initialized
INFO - 2017-12-18 06:52:48 --> Hooks Class Initialized
DEBUG - 2017-12-18 06:52:48 --> UTF-8 Support Enabled
INFO - 2017-12-18 06:52:48 --> Utf8 Class Initialized
DEBUG - 2017-12-18 06:52:48 --> UTF-8 Support Enabled
INFO - 2017-12-18 06:52:48 --> Utf8 Class Initialized
INFO - 2017-12-18 06:52:48 --> URI Class Initialized
INFO - 2017-12-18 06:52:48 --> URI Class Initialized
INFO - 2017-12-18 06:52:48 --> Router Class Initialized
INFO - 2017-12-18 06:52:48 --> Router Class Initialized
INFO - 2017-12-18 06:52:48 --> Output Class Initialized
INFO - 2017-12-18 06:52:48 --> Output Class Initialized
INFO - 2017-12-18 06:52:48 --> Security Class Initialized
INFO - 2017-12-18 06:52:48 --> Security Class Initialized
DEBUG - 2017-12-18 06:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 06:52:48 --> Input Class Initialized
INFO - 2017-12-18 06:52:48 --> Language Class Initialized
DEBUG - 2017-12-18 06:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 06:52:48 --> Input Class Initialized
INFO - 2017-12-18 06:52:48 --> Language Class Initialized
INFO - 2017-12-18 06:52:48 --> Loader Class Initialized
INFO - 2017-12-18 06:52:48 --> Helper loaded: url_helper
INFO - 2017-12-18 06:52:48 --> Loader Class Initialized
INFO - 2017-12-18 06:52:48 --> Helper loaded: form_helper
INFO - 2017-12-18 06:52:48 --> Helper loaded: url_helper
INFO - 2017-12-18 06:52:48 --> Helper loaded: form_helper
INFO - 2017-12-18 06:52:48 --> Database Driver Class Initialized
INFO - 2017-12-18 06:52:48 --> Database Driver Class Initialized
DEBUG - 2017-12-18 06:52:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-18 06:52:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-18 06:52:48 --> Form Validation Class Initialized
INFO - 2017-12-18 06:52:48 --> Model Class Initialized
INFO - 2017-12-18 06:52:48 --> Controller Class Initialized
DEBUG - 2017-12-18 06:52:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-18 06:52:48 --> Model Class Initialized
INFO - 2017-12-18 06:52:48 --> Model Class Initialized
INFO - 2017-12-18 06:52:48 --> Model Class Initialized
DEBUG - 2017-12-18 06:52:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-18 06:52:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-18 06:52:48 --> Form Validation Class Initialized
INFO - 2017-12-18 06:52:48 --> Model Class Initialized
INFO - 2017-12-18 06:52:48 --> Controller Class Initialized
INFO - 2017-12-18 06:52:48 --> Model Class Initialized
INFO - 2017-12-18 06:52:48 --> Model Class Initialized
INFO - 2017-12-18 06:52:48 --> Model Class Initialized
DEBUG - 2017-12-18 06:52:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-18 06:53:35 --> Config Class Initialized
INFO - 2017-12-18 06:53:35 --> Hooks Class Initialized
DEBUG - 2017-12-18 06:53:35 --> UTF-8 Support Enabled
INFO - 2017-12-18 06:53:35 --> Utf8 Class Initialized
INFO - 2017-12-18 06:53:35 --> URI Class Initialized
INFO - 2017-12-18 06:53:35 --> Router Class Initialized
INFO - 2017-12-18 06:53:35 --> Output Class Initialized
INFO - 2017-12-18 06:53:35 --> Security Class Initialized
DEBUG - 2017-12-18 06:53:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 06:53:35 --> Input Class Initialized
INFO - 2017-12-18 06:53:35 --> Language Class Initialized
INFO - 2017-12-18 06:53:35 --> Loader Class Initialized
INFO - 2017-12-18 06:53:35 --> Helper loaded: url_helper
INFO - 2017-12-18 06:53:35 --> Helper loaded: form_helper
INFO - 2017-12-18 06:53:35 --> Database Driver Class Initialized
DEBUG - 2017-12-18 06:53:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-18 06:53:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-18 06:53:35 --> Form Validation Class Initialized
INFO - 2017-12-18 06:53:35 --> Model Class Initialized
INFO - 2017-12-18 06:53:35 --> Controller Class Initialized
INFO - 2017-12-18 06:53:35 --> Model Class Initialized
INFO - 2017-12-18 06:53:35 --> Model Class Initialized
INFO - 2017-12-18 06:53:35 --> Model Class Initialized
DEBUG - 2017-12-18 06:53:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-18 06:53:36 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-18 06:53:36 --> Final output sent to browser
DEBUG - 2017-12-18 06:53:36 --> Total execution time: 0.1852
INFO - 2017-12-18 06:53:36 --> Config Class Initialized
INFO - 2017-12-18 06:53:36 --> Hooks Class Initialized
INFO - 2017-12-18 06:53:36 --> Config Class Initialized
INFO - 2017-12-18 06:53:36 --> Hooks Class Initialized
DEBUG - 2017-12-18 06:53:36 --> UTF-8 Support Enabled
INFO - 2017-12-18 06:53:36 --> Utf8 Class Initialized
DEBUG - 2017-12-18 06:53:36 --> UTF-8 Support Enabled
INFO - 2017-12-18 06:53:36 --> Utf8 Class Initialized
INFO - 2017-12-18 06:53:36 --> URI Class Initialized
INFO - 2017-12-18 06:53:36 --> URI Class Initialized
INFO - 2017-12-18 06:53:36 --> Router Class Initialized
INFO - 2017-12-18 06:53:36 --> Router Class Initialized
INFO - 2017-12-18 06:53:36 --> Output Class Initialized
INFO - 2017-12-18 06:53:36 --> Output Class Initialized
INFO - 2017-12-18 06:53:36 --> Security Class Initialized
INFO - 2017-12-18 06:53:36 --> Security Class Initialized
DEBUG - 2017-12-18 06:53:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 06:53:36 --> Input Class Initialized
DEBUG - 2017-12-18 06:53:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 06:53:36 --> Input Class Initialized
INFO - 2017-12-18 06:53:36 --> Language Class Initialized
INFO - 2017-12-18 06:53:36 --> Language Class Initialized
INFO - 2017-12-18 06:53:36 --> Loader Class Initialized
INFO - 2017-12-18 06:53:36 --> Loader Class Initialized
INFO - 2017-12-18 06:53:36 --> Helper loaded: url_helper
INFO - 2017-12-18 06:53:36 --> Helper loaded: url_helper
INFO - 2017-12-18 06:53:36 --> Helper loaded: form_helper
INFO - 2017-12-18 06:53:36 --> Helper loaded: form_helper
INFO - 2017-12-18 06:53:36 --> Database Driver Class Initialized
INFO - 2017-12-18 06:53:36 --> Database Driver Class Initialized
DEBUG - 2017-12-18 06:53:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2017-12-18 06:53:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-18 06:53:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-18 06:53:36 --> Form Validation Class Initialized
INFO - 2017-12-18 06:53:36 --> Model Class Initialized
INFO - 2017-12-18 06:53:36 --> Controller Class Initialized
INFO - 2017-12-18 06:53:36 --> Model Class Initialized
INFO - 2017-12-18 06:53:36 --> Model Class Initialized
INFO - 2017-12-18 06:53:36 --> Model Class Initialized
DEBUG - 2017-12-18 06:53:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-18 06:53:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-18 06:53:36 --> Form Validation Class Initialized
INFO - 2017-12-18 06:53:36 --> Model Class Initialized
INFO - 2017-12-18 06:53:36 --> Controller Class Initialized
INFO - 2017-12-18 06:53:36 --> Model Class Initialized
INFO - 2017-12-18 06:53:36 --> Model Class Initialized
INFO - 2017-12-18 06:53:36 --> Model Class Initialized
DEBUG - 2017-12-18 06:53:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-18 06:57:39 --> Config Class Initialized
INFO - 2017-12-18 06:57:39 --> Hooks Class Initialized
DEBUG - 2017-12-18 06:57:39 --> UTF-8 Support Enabled
INFO - 2017-12-18 06:57:39 --> Utf8 Class Initialized
INFO - 2017-12-18 06:57:39 --> URI Class Initialized
INFO - 2017-12-18 06:57:39 --> Router Class Initialized
INFO - 2017-12-18 06:57:39 --> Output Class Initialized
INFO - 2017-12-18 06:57:39 --> Security Class Initialized
DEBUG - 2017-12-18 06:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 06:57:39 --> Input Class Initialized
INFO - 2017-12-18 06:57:39 --> Language Class Initialized
INFO - 2017-12-18 06:57:39 --> Loader Class Initialized
INFO - 2017-12-18 06:57:39 --> Helper loaded: url_helper
INFO - 2017-12-18 06:57:39 --> Helper loaded: form_helper
INFO - 2017-12-18 06:57:39 --> Database Driver Class Initialized
DEBUG - 2017-12-18 06:57:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-18 06:57:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-18 06:57:39 --> Form Validation Class Initialized
INFO - 2017-12-18 06:57:39 --> Model Class Initialized
INFO - 2017-12-18 06:57:39 --> Controller Class Initialized
INFO - 2017-12-18 06:57:39 --> Model Class Initialized
INFO - 2017-12-18 06:57:39 --> Model Class Initialized
INFO - 2017-12-18 06:57:39 --> Model Class Initialized
DEBUG - 2017-12-18 06:57:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-18 06:57:39 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-18 06:57:39 --> Final output sent to browser
DEBUG - 2017-12-18 06:57:39 --> Total execution time: 0.0801
INFO - 2017-12-18 06:57:40 --> Config Class Initialized
INFO - 2017-12-18 06:57:40 --> Hooks Class Initialized
INFO - 2017-12-18 06:57:40 --> Config Class Initialized
INFO - 2017-12-18 06:57:40 --> Hooks Class Initialized
DEBUG - 2017-12-18 06:57:40 --> UTF-8 Support Enabled
INFO - 2017-12-18 06:57:40 --> Utf8 Class Initialized
DEBUG - 2017-12-18 06:57:40 --> UTF-8 Support Enabled
INFO - 2017-12-18 06:57:40 --> Utf8 Class Initialized
INFO - 2017-12-18 06:57:40 --> URI Class Initialized
INFO - 2017-12-18 06:57:40 --> URI Class Initialized
INFO - 2017-12-18 06:57:40 --> Router Class Initialized
INFO - 2017-12-18 06:57:40 --> Router Class Initialized
INFO - 2017-12-18 06:57:40 --> Output Class Initialized
INFO - 2017-12-18 06:57:40 --> Output Class Initialized
INFO - 2017-12-18 06:57:40 --> Security Class Initialized
INFO - 2017-12-18 06:57:40 --> Security Class Initialized
DEBUG - 2017-12-18 06:57:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 06:57:40 --> Input Class Initialized
DEBUG - 2017-12-18 06:57:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 06:57:40 --> Input Class Initialized
INFO - 2017-12-18 06:57:40 --> Language Class Initialized
INFO - 2017-12-18 06:57:40 --> Language Class Initialized
INFO - 2017-12-18 06:57:40 --> Loader Class Initialized
INFO - 2017-12-18 06:57:40 --> Loader Class Initialized
INFO - 2017-12-18 06:57:40 --> Helper loaded: url_helper
INFO - 2017-12-18 06:57:40 --> Helper loaded: url_helper
INFO - 2017-12-18 06:57:40 --> Helper loaded: form_helper
INFO - 2017-12-18 06:57:40 --> Helper loaded: form_helper
INFO - 2017-12-18 06:57:40 --> Database Driver Class Initialized
INFO - 2017-12-18 06:57:40 --> Database Driver Class Initialized
DEBUG - 2017-12-18 06:57:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2017-12-18 06:57:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-18 06:57:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-18 06:57:40 --> Form Validation Class Initialized
INFO - 2017-12-18 06:57:40 --> Model Class Initialized
INFO - 2017-12-18 06:57:40 --> Controller Class Initialized
INFO - 2017-12-18 06:57:40 --> Model Class Initialized
INFO - 2017-12-18 06:57:40 --> Model Class Initialized
INFO - 2017-12-18 06:57:40 --> Model Class Initialized
DEBUG - 2017-12-18 06:57:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-18 06:57:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-18 06:57:40 --> Form Validation Class Initialized
INFO - 2017-12-18 06:57:40 --> Model Class Initialized
INFO - 2017-12-18 06:57:40 --> Controller Class Initialized
INFO - 2017-12-18 06:57:40 --> Model Class Initialized
INFO - 2017-12-18 06:57:40 --> Model Class Initialized
INFO - 2017-12-18 06:57:40 --> Model Class Initialized
DEBUG - 2017-12-18 06:57:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-18 06:57:43 --> Config Class Initialized
INFO - 2017-12-18 06:57:43 --> Hooks Class Initialized
DEBUG - 2017-12-18 06:57:43 --> UTF-8 Support Enabled
INFO - 2017-12-18 06:57:43 --> Utf8 Class Initialized
INFO - 2017-12-18 06:57:43 --> URI Class Initialized
INFO - 2017-12-18 06:57:43 --> Router Class Initialized
INFO - 2017-12-18 06:57:43 --> Output Class Initialized
INFO - 2017-12-18 06:57:43 --> Security Class Initialized
DEBUG - 2017-12-18 06:57:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 06:57:43 --> Input Class Initialized
INFO - 2017-12-18 06:57:43 --> Language Class Initialized
INFO - 2017-12-18 06:57:43 --> Loader Class Initialized
INFO - 2017-12-18 06:57:43 --> Helper loaded: url_helper
INFO - 2017-12-18 06:57:43 --> Helper loaded: form_helper
INFO - 2017-12-18 06:57:43 --> Database Driver Class Initialized
DEBUG - 2017-12-18 06:57:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-18 06:57:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-18 06:57:43 --> Form Validation Class Initialized
INFO - 2017-12-18 06:57:43 --> Model Class Initialized
INFO - 2017-12-18 06:57:43 --> Controller Class Initialized
INFO - 2017-12-18 06:57:43 --> Model Class Initialized
INFO - 2017-12-18 06:57:43 --> Model Class Initialized
INFO - 2017-12-18 06:57:43 --> Model Class Initialized
DEBUG - 2017-12-18 06:57:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-18 06:57:43 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-18 06:57:43 --> Final output sent to browser
DEBUG - 2017-12-18 06:57:43 --> Total execution time: 0.0502
INFO - 2017-12-18 06:57:43 --> Config Class Initialized
INFO - 2017-12-18 06:57:43 --> Hooks Class Initialized
DEBUG - 2017-12-18 06:57:43 --> UTF-8 Support Enabled
INFO - 2017-12-18 06:57:43 --> Utf8 Class Initialized
INFO - 2017-12-18 06:57:43 --> URI Class Initialized
INFO - 2017-12-18 06:57:43 --> Router Class Initialized
INFO - 2017-12-18 06:57:43 --> Output Class Initialized
INFO - 2017-12-18 06:57:43 --> Security Class Initialized
DEBUG - 2017-12-18 06:57:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 06:57:43 --> Input Class Initialized
INFO - 2017-12-18 06:57:43 --> Language Class Initialized
INFO - 2017-12-18 06:57:43 --> Loader Class Initialized
INFO - 2017-12-18 06:57:43 --> Helper loaded: url_helper
INFO - 2017-12-18 06:57:43 --> Helper loaded: form_helper
INFO - 2017-12-18 06:57:43 --> Database Driver Class Initialized
DEBUG - 2017-12-18 06:57:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-18 06:57:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-18 06:57:43 --> Form Validation Class Initialized
INFO - 2017-12-18 06:57:43 --> Model Class Initialized
INFO - 2017-12-18 06:57:43 --> Controller Class Initialized
INFO - 2017-12-18 06:57:43 --> Model Class Initialized
INFO - 2017-12-18 06:57:43 --> Model Class Initialized
INFO - 2017-12-18 06:57:43 --> Model Class Initialized
DEBUG - 2017-12-18 06:57:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-18 06:57:44 --> Config Class Initialized
INFO - 2017-12-18 06:57:44 --> Hooks Class Initialized
DEBUG - 2017-12-18 06:57:44 --> UTF-8 Support Enabled
INFO - 2017-12-18 06:57:44 --> Utf8 Class Initialized
INFO - 2017-12-18 06:57:44 --> URI Class Initialized
INFO - 2017-12-18 06:57:44 --> Router Class Initialized
INFO - 2017-12-18 06:57:44 --> Output Class Initialized
INFO - 2017-12-18 06:57:44 --> Security Class Initialized
DEBUG - 2017-12-18 06:57:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 06:57:44 --> Input Class Initialized
INFO - 2017-12-18 06:57:44 --> Language Class Initialized
INFO - 2017-12-18 06:57:44 --> Loader Class Initialized
INFO - 2017-12-18 06:57:44 --> Helper loaded: url_helper
INFO - 2017-12-18 06:57:44 --> Helper loaded: form_helper
INFO - 2017-12-18 06:57:44 --> Database Driver Class Initialized
DEBUG - 2017-12-18 06:57:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-18 06:57:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-18 06:57:44 --> Form Validation Class Initialized
INFO - 2017-12-18 06:57:44 --> Model Class Initialized
INFO - 2017-12-18 06:57:44 --> Controller Class Initialized
INFO - 2017-12-18 06:57:44 --> Model Class Initialized
INFO - 2017-12-18 06:57:44 --> Model Class Initialized
INFO - 2017-12-18 06:57:44 --> Model Class Initialized
DEBUG - 2017-12-18 06:57:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-18 06:57:44 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-18 06:57:44 --> Final output sent to browser
DEBUG - 2017-12-18 06:57:44 --> Total execution time: 0.0602
INFO - 2017-12-18 06:57:55 --> Config Class Initialized
INFO - 2017-12-18 06:57:55 --> Hooks Class Initialized
DEBUG - 2017-12-18 06:57:55 --> UTF-8 Support Enabled
INFO - 2017-12-18 06:57:55 --> Utf8 Class Initialized
INFO - 2017-12-18 06:57:55 --> URI Class Initialized
INFO - 2017-12-18 06:57:55 --> Router Class Initialized
INFO - 2017-12-18 06:57:55 --> Output Class Initialized
INFO - 2017-12-18 06:57:55 --> Security Class Initialized
DEBUG - 2017-12-18 06:57:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 06:57:55 --> Input Class Initialized
INFO - 2017-12-18 06:57:55 --> Language Class Initialized
INFO - 2017-12-18 06:57:55 --> Loader Class Initialized
INFO - 2017-12-18 06:57:55 --> Helper loaded: url_helper
INFO - 2017-12-18 06:57:55 --> Helper loaded: form_helper
INFO - 2017-12-18 06:57:55 --> Database Driver Class Initialized
DEBUG - 2017-12-18 06:57:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-18 06:57:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-18 06:57:55 --> Form Validation Class Initialized
INFO - 2017-12-18 06:57:55 --> Model Class Initialized
INFO - 2017-12-18 06:57:55 --> Controller Class Initialized
INFO - 2017-12-18 06:57:55 --> Model Class Initialized
INFO - 2017-12-18 06:57:55 --> Model Class Initialized
INFO - 2017-12-18 06:57:55 --> Model Class Initialized
DEBUG - 2017-12-18 06:57:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-18 06:57:55 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-18 06:57:55 --> Final output sent to browser
DEBUG - 2017-12-18 06:57:55 --> Total execution time: 0.0615
INFO - 2017-12-18 06:57:55 --> Config Class Initialized
INFO - 2017-12-18 06:57:55 --> Hooks Class Initialized
DEBUG - 2017-12-18 06:57:55 --> UTF-8 Support Enabled
INFO - 2017-12-18 06:57:55 --> Utf8 Class Initialized
INFO - 2017-12-18 06:57:55 --> URI Class Initialized
INFO - 2017-12-18 06:57:55 --> Router Class Initialized
INFO - 2017-12-18 06:57:55 --> Output Class Initialized
INFO - 2017-12-18 06:57:55 --> Security Class Initialized
DEBUG - 2017-12-18 06:57:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 06:57:55 --> Input Class Initialized
INFO - 2017-12-18 06:57:55 --> Language Class Initialized
INFO - 2017-12-18 06:57:55 --> Loader Class Initialized
INFO - 2017-12-18 06:57:55 --> Helper loaded: url_helper
INFO - 2017-12-18 06:57:55 --> Helper loaded: form_helper
INFO - 2017-12-18 06:57:55 --> Database Driver Class Initialized
DEBUG - 2017-12-18 06:57:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-18 06:57:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-18 06:57:55 --> Form Validation Class Initialized
INFO - 2017-12-18 06:57:55 --> Model Class Initialized
INFO - 2017-12-18 06:57:55 --> Controller Class Initialized
INFO - 2017-12-18 06:57:55 --> Model Class Initialized
INFO - 2017-12-18 06:57:55 --> Model Class Initialized
INFO - 2017-12-18 06:57:55 --> Model Class Initialized
DEBUG - 2017-12-18 06:57:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-18 06:59:57 --> Config Class Initialized
INFO - 2017-12-18 06:59:57 --> Hooks Class Initialized
DEBUG - 2017-12-18 06:59:57 --> UTF-8 Support Enabled
INFO - 2017-12-18 06:59:57 --> Utf8 Class Initialized
INFO - 2017-12-18 06:59:57 --> URI Class Initialized
INFO - 2017-12-18 06:59:57 --> Router Class Initialized
INFO - 2017-12-18 06:59:57 --> Output Class Initialized
INFO - 2017-12-18 06:59:57 --> Security Class Initialized
DEBUG - 2017-12-18 06:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 06:59:57 --> Input Class Initialized
INFO - 2017-12-18 06:59:57 --> Language Class Initialized
INFO - 2017-12-18 06:59:57 --> Loader Class Initialized
INFO - 2017-12-18 06:59:57 --> Helper loaded: url_helper
INFO - 2017-12-18 06:59:57 --> Helper loaded: form_helper
INFO - 2017-12-18 06:59:57 --> Database Driver Class Initialized
DEBUG - 2017-12-18 06:59:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-18 06:59:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-18 06:59:57 --> Form Validation Class Initialized
INFO - 2017-12-18 06:59:57 --> Model Class Initialized
INFO - 2017-12-18 06:59:57 --> Controller Class Initialized
INFO - 2017-12-18 06:59:57 --> Model Class Initialized
INFO - 2017-12-18 06:59:57 --> Model Class Initialized
DEBUG - 2017-12-18 06:59:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-18 06:59:57 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-18 06:59:57 --> Final output sent to browser
DEBUG - 2017-12-18 06:59:57 --> Total execution time: 0.3342
INFO - 2017-12-18 06:59:58 --> Config Class Initialized
INFO - 2017-12-18 06:59:58 --> Hooks Class Initialized
DEBUG - 2017-12-18 06:59:58 --> UTF-8 Support Enabled
INFO - 2017-12-18 06:59:58 --> Utf8 Class Initialized
INFO - 2017-12-18 06:59:58 --> URI Class Initialized
INFO - 2017-12-18 06:59:58 --> Router Class Initialized
INFO - 2017-12-18 06:59:58 --> Output Class Initialized
INFO - 2017-12-18 06:59:58 --> Security Class Initialized
DEBUG - 2017-12-18 06:59:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 06:59:58 --> Input Class Initialized
INFO - 2017-12-18 06:59:58 --> Language Class Initialized
INFO - 2017-12-18 06:59:58 --> Loader Class Initialized
INFO - 2017-12-18 06:59:58 --> Helper loaded: url_helper
INFO - 2017-12-18 06:59:58 --> Helper loaded: form_helper
INFO - 2017-12-18 06:59:58 --> Database Driver Class Initialized
DEBUG - 2017-12-18 06:59:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-18 06:59:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-18 06:59:58 --> Form Validation Class Initialized
INFO - 2017-12-18 06:59:58 --> Model Class Initialized
INFO - 2017-12-18 06:59:58 --> Controller Class Initialized
INFO - 2017-12-18 06:59:58 --> Model Class Initialized
INFO - 2017-12-18 06:59:58 --> Model Class Initialized
DEBUG - 2017-12-18 06:59:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-18 06:59:59 --> Config Class Initialized
INFO - 2017-12-18 06:59:59 --> Hooks Class Initialized
DEBUG - 2017-12-18 06:59:59 --> UTF-8 Support Enabled
INFO - 2017-12-18 06:59:59 --> Utf8 Class Initialized
INFO - 2017-12-18 06:59:59 --> URI Class Initialized
INFO - 2017-12-18 06:59:59 --> Router Class Initialized
INFO - 2017-12-18 06:59:59 --> Output Class Initialized
INFO - 2017-12-18 06:59:59 --> Security Class Initialized
DEBUG - 2017-12-18 06:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 06:59:59 --> Input Class Initialized
INFO - 2017-12-18 06:59:59 --> Language Class Initialized
INFO - 2017-12-18 06:59:59 --> Loader Class Initialized
INFO - 2017-12-18 06:59:59 --> Helper loaded: url_helper
INFO - 2017-12-18 06:59:59 --> Helper loaded: form_helper
INFO - 2017-12-18 06:59:59 --> Database Driver Class Initialized
DEBUG - 2017-12-18 06:59:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-18 06:59:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-18 06:59:59 --> Form Validation Class Initialized
INFO - 2017-12-18 06:59:59 --> Model Class Initialized
INFO - 2017-12-18 06:59:59 --> Controller Class Initialized
INFO - 2017-12-18 06:59:59 --> Model Class Initialized
INFO - 2017-12-18 06:59:59 --> Model Class Initialized
DEBUG - 2017-12-18 06:59:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-18 06:59:59 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-18 06:59:59 --> Final output sent to browser
DEBUG - 2017-12-18 06:59:59 --> Total execution time: 0.0967
INFO - 2017-12-18 07:11:48 --> Config Class Initialized
INFO - 2017-12-18 07:11:48 --> Hooks Class Initialized
DEBUG - 2017-12-18 07:11:48 --> UTF-8 Support Enabled
INFO - 2017-12-18 07:11:48 --> Utf8 Class Initialized
INFO - 2017-12-18 07:11:48 --> URI Class Initialized
INFO - 2017-12-18 07:11:48 --> Router Class Initialized
INFO - 2017-12-18 07:11:48 --> Output Class Initialized
INFO - 2017-12-18 07:11:48 --> Security Class Initialized
DEBUG - 2017-12-18 07:11:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 07:11:48 --> Input Class Initialized
INFO - 2017-12-18 07:11:48 --> Language Class Initialized
INFO - 2017-12-18 07:11:48 --> Loader Class Initialized
INFO - 2017-12-18 07:11:48 --> Helper loaded: url_helper
INFO - 2017-12-18 07:11:48 --> Helper loaded: form_helper
INFO - 2017-12-18 07:11:48 --> Database Driver Class Initialized
DEBUG - 2017-12-18 07:11:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-18 07:11:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-18 07:11:48 --> Form Validation Class Initialized
INFO - 2017-12-18 07:11:48 --> Model Class Initialized
INFO - 2017-12-18 07:11:48 --> Controller Class Initialized
INFO - 2017-12-18 07:11:48 --> Model Class Initialized
INFO - 2017-12-18 07:11:48 --> Model Class Initialized
INFO - 2017-12-18 07:11:48 --> Model Class Initialized
DEBUG - 2017-12-18 07:11:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-18 07:11:48 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-18 07:11:48 --> Final output sent to browser
DEBUG - 2017-12-18 07:11:48 --> Total execution time: 0.0585
INFO - 2017-12-18 07:11:48 --> Config Class Initialized
INFO - 2017-12-18 07:11:48 --> Hooks Class Initialized
DEBUG - 2017-12-18 07:11:48 --> UTF-8 Support Enabled
INFO - 2017-12-18 07:11:48 --> Utf8 Class Initialized
INFO - 2017-12-18 07:11:48 --> URI Class Initialized
INFO - 2017-12-18 07:11:48 --> Router Class Initialized
INFO - 2017-12-18 07:11:48 --> Output Class Initialized
INFO - 2017-12-18 07:11:48 --> Security Class Initialized
DEBUG - 2017-12-18 07:11:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 07:11:48 --> Input Class Initialized
INFO - 2017-12-18 07:11:48 --> Language Class Initialized
INFO - 2017-12-18 07:11:48 --> Loader Class Initialized
INFO - 2017-12-18 07:11:48 --> Helper loaded: url_helper
INFO - 2017-12-18 07:11:48 --> Helper loaded: form_helper
INFO - 2017-12-18 07:11:48 --> Database Driver Class Initialized
DEBUG - 2017-12-18 07:11:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-18 07:11:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-18 07:11:48 --> Form Validation Class Initialized
INFO - 2017-12-18 07:11:48 --> Model Class Initialized
INFO - 2017-12-18 07:11:48 --> Controller Class Initialized
INFO - 2017-12-18 07:11:48 --> Model Class Initialized
INFO - 2017-12-18 07:11:48 --> Model Class Initialized
INFO - 2017-12-18 07:11:48 --> Model Class Initialized
DEBUG - 2017-12-18 07:11:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-18 07:11:51 --> Config Class Initialized
INFO - 2017-12-18 07:11:51 --> Hooks Class Initialized
DEBUG - 2017-12-18 07:11:51 --> UTF-8 Support Enabled
INFO - 2017-12-18 07:11:51 --> Utf8 Class Initialized
INFO - 2017-12-18 07:11:51 --> URI Class Initialized
INFO - 2017-12-18 07:11:51 --> Router Class Initialized
INFO - 2017-12-18 07:11:51 --> Output Class Initialized
INFO - 2017-12-18 07:11:51 --> Security Class Initialized
DEBUG - 2017-12-18 07:11:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 07:11:51 --> Input Class Initialized
INFO - 2017-12-18 07:11:51 --> Language Class Initialized
INFO - 2017-12-18 07:11:51 --> Loader Class Initialized
INFO - 2017-12-18 07:11:51 --> Helper loaded: url_helper
INFO - 2017-12-18 07:11:51 --> Helper loaded: form_helper
INFO - 2017-12-18 07:11:51 --> Database Driver Class Initialized
DEBUG - 2017-12-18 07:11:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-18 07:11:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-18 07:11:51 --> Form Validation Class Initialized
INFO - 2017-12-18 07:11:51 --> Model Class Initialized
INFO - 2017-12-18 07:11:51 --> Controller Class Initialized
INFO - 2017-12-18 07:11:51 --> Model Class Initialized
INFO - 2017-12-18 07:11:51 --> Model Class Initialized
INFO - 2017-12-18 07:11:51 --> Model Class Initialized
DEBUG - 2017-12-18 07:11:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-18 07:11:51 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-18 07:11:51 --> Final output sent to browser
DEBUG - 2017-12-18 07:11:51 --> Total execution time: 0.0574
INFO - 2017-12-18 07:11:53 --> Config Class Initialized
INFO - 2017-12-18 07:11:53 --> Hooks Class Initialized
DEBUG - 2017-12-18 07:11:53 --> UTF-8 Support Enabled
INFO - 2017-12-18 07:11:53 --> Utf8 Class Initialized
INFO - 2017-12-18 07:11:53 --> URI Class Initialized
INFO - 2017-12-18 07:11:53 --> Router Class Initialized
INFO - 2017-12-18 07:11:53 --> Output Class Initialized
INFO - 2017-12-18 07:11:53 --> Security Class Initialized
DEBUG - 2017-12-18 07:11:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 07:11:53 --> Input Class Initialized
INFO - 2017-12-18 07:11:53 --> Language Class Initialized
INFO - 2017-12-18 07:11:53 --> Loader Class Initialized
INFO - 2017-12-18 07:11:53 --> Helper loaded: url_helper
INFO - 2017-12-18 07:11:53 --> Helper loaded: form_helper
INFO - 2017-12-18 07:11:53 --> Database Driver Class Initialized
DEBUG - 2017-12-18 07:11:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-18 07:11:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-18 07:11:53 --> Form Validation Class Initialized
INFO - 2017-12-18 07:11:53 --> Model Class Initialized
INFO - 2017-12-18 07:11:53 --> Controller Class Initialized
INFO - 2017-12-18 07:11:53 --> Model Class Initialized
INFO - 2017-12-18 07:11:53 --> Model Class Initialized
INFO - 2017-12-18 07:11:53 --> Model Class Initialized
DEBUG - 2017-12-18 07:11:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-18 07:11:53 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-18 07:11:53 --> Final output sent to browser
DEBUG - 2017-12-18 07:11:53 --> Total execution time: 0.0519
INFO - 2017-12-18 07:11:53 --> Config Class Initialized
INFO - 2017-12-18 07:11:53 --> Hooks Class Initialized
DEBUG - 2017-12-18 07:11:53 --> UTF-8 Support Enabled
INFO - 2017-12-18 07:11:53 --> Utf8 Class Initialized
INFO - 2017-12-18 07:11:53 --> URI Class Initialized
INFO - 2017-12-18 07:11:53 --> Router Class Initialized
INFO - 2017-12-18 07:11:53 --> Output Class Initialized
INFO - 2017-12-18 07:11:53 --> Security Class Initialized
DEBUG - 2017-12-18 07:11:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 07:11:53 --> Input Class Initialized
INFO - 2017-12-18 07:11:53 --> Language Class Initialized
INFO - 2017-12-18 07:11:53 --> Loader Class Initialized
INFO - 2017-12-18 07:11:53 --> Helper loaded: url_helper
INFO - 2017-12-18 07:11:53 --> Helper loaded: form_helper
INFO - 2017-12-18 07:11:53 --> Database Driver Class Initialized
DEBUG - 2017-12-18 07:11:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-18 07:11:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-18 07:11:53 --> Form Validation Class Initialized
INFO - 2017-12-18 07:11:53 --> Model Class Initialized
INFO - 2017-12-18 07:11:53 --> Controller Class Initialized
INFO - 2017-12-18 07:11:53 --> Model Class Initialized
INFO - 2017-12-18 07:11:53 --> Model Class Initialized
INFO - 2017-12-18 07:11:53 --> Model Class Initialized
DEBUG - 2017-12-18 07:11:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-18 07:13:12 --> Config Class Initialized
INFO - 2017-12-18 07:13:12 --> Hooks Class Initialized
DEBUG - 2017-12-18 07:13:12 --> UTF-8 Support Enabled
INFO - 2017-12-18 07:13:12 --> Utf8 Class Initialized
INFO - 2017-12-18 07:13:12 --> URI Class Initialized
INFO - 2017-12-18 07:13:12 --> Router Class Initialized
INFO - 2017-12-18 07:13:12 --> Output Class Initialized
INFO - 2017-12-18 07:13:12 --> Security Class Initialized
DEBUG - 2017-12-18 07:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 07:13:12 --> Input Class Initialized
INFO - 2017-12-18 07:13:12 --> Language Class Initialized
INFO - 2017-12-18 07:13:12 --> Loader Class Initialized
INFO - 2017-12-18 07:13:12 --> Helper loaded: url_helper
INFO - 2017-12-18 07:13:12 --> Helper loaded: form_helper
INFO - 2017-12-18 07:13:12 --> Database Driver Class Initialized
DEBUG - 2017-12-18 07:13:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-18 07:13:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-18 07:13:12 --> Form Validation Class Initialized
INFO - 2017-12-18 07:13:12 --> Model Class Initialized
INFO - 2017-12-18 07:13:12 --> Controller Class Initialized
INFO - 2017-12-18 07:13:12 --> Model Class Initialized
INFO - 2017-12-18 07:13:12 --> Model Class Initialized
INFO - 2017-12-18 07:13:12 --> Model Class Initialized
DEBUG - 2017-12-18 07:13:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-18 07:13:12 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-18 07:13:12 --> Final output sent to browser
DEBUG - 2017-12-18 07:13:12 --> Total execution time: 0.0540
INFO - 2017-12-18 07:13:14 --> Config Class Initialized
INFO - 2017-12-18 07:13:14 --> Hooks Class Initialized
DEBUG - 2017-12-18 07:13:14 --> UTF-8 Support Enabled
INFO - 2017-12-18 07:13:14 --> Utf8 Class Initialized
INFO - 2017-12-18 07:13:14 --> URI Class Initialized
INFO - 2017-12-18 07:13:14 --> Router Class Initialized
INFO - 2017-12-18 07:13:14 --> Output Class Initialized
INFO - 2017-12-18 07:13:14 --> Security Class Initialized
DEBUG - 2017-12-18 07:13:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 07:13:14 --> Input Class Initialized
INFO - 2017-12-18 07:13:14 --> Language Class Initialized
INFO - 2017-12-18 07:13:14 --> Loader Class Initialized
INFO - 2017-12-18 07:13:14 --> Helper loaded: url_helper
INFO - 2017-12-18 07:13:14 --> Helper loaded: form_helper
INFO - 2017-12-18 07:13:14 --> Database Driver Class Initialized
DEBUG - 2017-12-18 07:13:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-18 07:13:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-18 07:13:14 --> Form Validation Class Initialized
INFO - 2017-12-18 07:13:14 --> Model Class Initialized
INFO - 2017-12-18 07:13:14 --> Controller Class Initialized
INFO - 2017-12-18 07:13:14 --> Model Class Initialized
INFO - 2017-12-18 07:13:14 --> Model Class Initialized
INFO - 2017-12-18 07:13:14 --> Model Class Initialized
DEBUG - 2017-12-18 07:13:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-18 07:13:14 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-18 07:13:14 --> Final output sent to browser
DEBUG - 2017-12-18 07:13:14 --> Total execution time: 0.0530
INFO - 2017-12-18 07:13:14 --> Config Class Initialized
INFO - 2017-12-18 07:13:14 --> Hooks Class Initialized
INFO - 2017-12-18 07:13:14 --> Config Class Initialized
INFO - 2017-12-18 07:13:14 --> Hooks Class Initialized
DEBUG - 2017-12-18 07:13:14 --> UTF-8 Support Enabled
INFO - 2017-12-18 07:13:14 --> Utf8 Class Initialized
DEBUG - 2017-12-18 07:13:14 --> UTF-8 Support Enabled
INFO - 2017-12-18 07:13:14 --> Utf8 Class Initialized
INFO - 2017-12-18 07:13:14 --> URI Class Initialized
INFO - 2017-12-18 07:13:14 --> URI Class Initialized
INFO - 2017-12-18 07:13:14 --> Router Class Initialized
INFO - 2017-12-18 07:13:14 --> Router Class Initialized
INFO - 2017-12-18 07:13:14 --> Output Class Initialized
INFO - 2017-12-18 07:13:14 --> Output Class Initialized
INFO - 2017-12-18 07:13:14 --> Security Class Initialized
INFO - 2017-12-18 07:13:14 --> Security Class Initialized
DEBUG - 2017-12-18 07:13:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 07:13:14 --> Input Class Initialized
DEBUG - 2017-12-18 07:13:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 07:13:14 --> Language Class Initialized
INFO - 2017-12-18 07:13:14 --> Input Class Initialized
INFO - 2017-12-18 07:13:14 --> Language Class Initialized
INFO - 2017-12-18 07:13:14 --> Loader Class Initialized
INFO - 2017-12-18 07:13:14 --> Loader Class Initialized
INFO - 2017-12-18 07:13:14 --> Helper loaded: url_helper
INFO - 2017-12-18 07:13:14 --> Helper loaded: url_helper
INFO - 2017-12-18 07:13:14 --> Helper loaded: form_helper
INFO - 2017-12-18 07:13:14 --> Helper loaded: form_helper
INFO - 2017-12-18 07:13:14 --> Database Driver Class Initialized
INFO - 2017-12-18 07:13:14 --> Database Driver Class Initialized
DEBUG - 2017-12-18 07:13:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-18 07:13:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-18 07:13:14 --> Form Validation Class Initialized
DEBUG - 2017-12-18 07:13:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-18 07:13:14 --> Model Class Initialized
INFO - 2017-12-18 07:13:14 --> Controller Class Initialized
INFO - 2017-12-18 07:13:14 --> Model Class Initialized
INFO - 2017-12-18 07:13:14 --> Model Class Initialized
INFO - 2017-12-18 07:13:14 --> Model Class Initialized
DEBUG - 2017-12-18 07:13:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-18 07:13:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-18 07:13:14 --> Form Validation Class Initialized
INFO - 2017-12-18 07:13:14 --> Model Class Initialized
INFO - 2017-12-18 07:13:14 --> Controller Class Initialized
INFO - 2017-12-18 07:13:14 --> Model Class Initialized
INFO - 2017-12-18 07:13:14 --> Model Class Initialized
INFO - 2017-12-18 07:13:14 --> Model Class Initialized
DEBUG - 2017-12-18 07:13:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-18 07:13:16 --> Config Class Initialized
INFO - 2017-12-18 07:13:16 --> Hooks Class Initialized
DEBUG - 2017-12-18 07:13:16 --> UTF-8 Support Enabled
INFO - 2017-12-18 07:13:16 --> Utf8 Class Initialized
INFO - 2017-12-18 07:13:16 --> URI Class Initialized
INFO - 2017-12-18 07:13:16 --> Router Class Initialized
INFO - 2017-12-18 07:13:16 --> Output Class Initialized
INFO - 2017-12-18 07:13:16 --> Security Class Initialized
DEBUG - 2017-12-18 07:13:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 07:13:16 --> Input Class Initialized
INFO - 2017-12-18 07:13:16 --> Language Class Initialized
INFO - 2017-12-18 07:13:16 --> Loader Class Initialized
INFO - 2017-12-18 07:13:16 --> Helper loaded: url_helper
INFO - 2017-12-18 07:13:16 --> Helper loaded: form_helper
INFO - 2017-12-18 07:13:16 --> Database Driver Class Initialized
DEBUG - 2017-12-18 07:13:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-18 07:13:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-18 07:13:16 --> Form Validation Class Initialized
INFO - 2017-12-18 07:13:16 --> Model Class Initialized
INFO - 2017-12-18 07:13:16 --> Controller Class Initialized
INFO - 2017-12-18 07:13:16 --> Model Class Initialized
INFO - 2017-12-18 07:13:16 --> Model Class Initialized
INFO - 2017-12-18 07:13:16 --> Model Class Initialized
DEBUG - 2017-12-18 07:13:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-18 07:13:16 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-18 07:13:16 --> Final output sent to browser
DEBUG - 2017-12-18 07:13:16 --> Total execution time: 0.0651
INFO - 2017-12-18 07:15:25 --> Config Class Initialized
INFO - 2017-12-18 07:15:25 --> Hooks Class Initialized
DEBUG - 2017-12-18 07:15:25 --> UTF-8 Support Enabled
INFO - 2017-12-18 07:15:25 --> Utf8 Class Initialized
INFO - 2017-12-18 07:15:25 --> URI Class Initialized
INFO - 2017-12-18 07:15:25 --> Router Class Initialized
INFO - 2017-12-18 07:15:25 --> Output Class Initialized
INFO - 2017-12-18 07:15:25 --> Security Class Initialized
DEBUG - 2017-12-18 07:15:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 07:15:25 --> Input Class Initialized
INFO - 2017-12-18 07:15:25 --> Language Class Initialized
INFO - 2017-12-18 07:15:25 --> Loader Class Initialized
INFO - 2017-12-18 07:15:25 --> Helper loaded: url_helper
INFO - 2017-12-18 07:15:25 --> Helper loaded: form_helper
INFO - 2017-12-18 07:15:25 --> Database Driver Class Initialized
DEBUG - 2017-12-18 07:15:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-18 07:15:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-18 07:15:25 --> Form Validation Class Initialized
INFO - 2017-12-18 07:15:25 --> Model Class Initialized
INFO - 2017-12-18 07:15:25 --> Controller Class Initialized
INFO - 2017-12-18 07:15:25 --> Model Class Initialized
INFO - 2017-12-18 07:15:25 --> Model Class Initialized
INFO - 2017-12-18 07:15:25 --> Model Class Initialized
DEBUG - 2017-12-18 07:15:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-18 07:15:25 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-18 07:15:25 --> Final output sent to browser
DEBUG - 2017-12-18 07:15:25 --> Total execution time: 0.0581
INFO - 2017-12-18 07:15:25 --> Config Class Initialized
INFO - 2017-12-18 07:15:25 --> Hooks Class Initialized
DEBUG - 2017-12-18 07:15:25 --> UTF-8 Support Enabled
INFO - 2017-12-18 07:15:25 --> Utf8 Class Initialized
INFO - 2017-12-18 07:15:25 --> URI Class Initialized
INFO - 2017-12-18 07:15:25 --> Router Class Initialized
INFO - 2017-12-18 07:15:25 --> Output Class Initialized
INFO - 2017-12-18 07:15:25 --> Security Class Initialized
DEBUG - 2017-12-18 07:15:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 07:15:25 --> Input Class Initialized
INFO - 2017-12-18 07:15:25 --> Language Class Initialized
INFO - 2017-12-18 07:15:25 --> Loader Class Initialized
INFO - 2017-12-18 07:15:25 --> Helper loaded: url_helper
INFO - 2017-12-18 07:15:25 --> Helper loaded: form_helper
INFO - 2017-12-18 07:15:25 --> Database Driver Class Initialized
DEBUG - 2017-12-18 07:15:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-18 07:15:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-18 07:15:25 --> Form Validation Class Initialized
INFO - 2017-12-18 07:15:25 --> Model Class Initialized
INFO - 2017-12-18 07:15:25 --> Controller Class Initialized
INFO - 2017-12-18 07:15:25 --> Model Class Initialized
INFO - 2017-12-18 07:15:25 --> Model Class Initialized
INFO - 2017-12-18 07:15:25 --> Model Class Initialized
DEBUG - 2017-12-18 07:15:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-18 07:15:28 --> Config Class Initialized
INFO - 2017-12-18 07:15:28 --> Hooks Class Initialized
DEBUG - 2017-12-18 07:15:28 --> UTF-8 Support Enabled
INFO - 2017-12-18 07:15:28 --> Utf8 Class Initialized
INFO - 2017-12-18 07:15:28 --> URI Class Initialized
INFO - 2017-12-18 07:15:28 --> Router Class Initialized
INFO - 2017-12-18 07:15:28 --> Output Class Initialized
INFO - 2017-12-18 07:15:28 --> Security Class Initialized
DEBUG - 2017-12-18 07:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 07:15:28 --> Input Class Initialized
INFO - 2017-12-18 07:15:28 --> Language Class Initialized
INFO - 2017-12-18 07:15:28 --> Loader Class Initialized
INFO - 2017-12-18 07:15:28 --> Helper loaded: url_helper
INFO - 2017-12-18 07:15:28 --> Helper loaded: form_helper
INFO - 2017-12-18 07:15:28 --> Database Driver Class Initialized
DEBUG - 2017-12-18 07:15:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-18 07:15:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-18 07:15:28 --> Form Validation Class Initialized
INFO - 2017-12-18 07:15:28 --> Model Class Initialized
INFO - 2017-12-18 07:15:28 --> Controller Class Initialized
INFO - 2017-12-18 07:15:28 --> Model Class Initialized
INFO - 2017-12-18 07:15:28 --> Model Class Initialized
INFO - 2017-12-18 07:15:28 --> Model Class Initialized
DEBUG - 2017-12-18 07:15:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-18 07:15:28 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-18 07:15:28 --> Final output sent to browser
DEBUG - 2017-12-18 07:15:28 --> Total execution time: 0.0556
INFO - 2017-12-18 07:15:31 --> Config Class Initialized
INFO - 2017-12-18 07:15:31 --> Hooks Class Initialized
DEBUG - 2017-12-18 07:15:31 --> UTF-8 Support Enabled
INFO - 2017-12-18 07:15:31 --> Utf8 Class Initialized
INFO - 2017-12-18 07:15:31 --> URI Class Initialized
INFO - 2017-12-18 07:15:31 --> Router Class Initialized
INFO - 2017-12-18 07:15:31 --> Output Class Initialized
INFO - 2017-12-18 07:15:31 --> Security Class Initialized
DEBUG - 2017-12-18 07:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 07:15:31 --> Input Class Initialized
INFO - 2017-12-18 07:15:31 --> Language Class Initialized
INFO - 2017-12-18 07:15:31 --> Loader Class Initialized
INFO - 2017-12-18 07:15:31 --> Helper loaded: url_helper
INFO - 2017-12-18 07:15:31 --> Helper loaded: form_helper
INFO - 2017-12-18 07:15:31 --> Database Driver Class Initialized
DEBUG - 2017-12-18 07:15:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-18 07:15:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-18 07:15:31 --> Form Validation Class Initialized
INFO - 2017-12-18 07:15:31 --> Model Class Initialized
INFO - 2017-12-18 07:15:31 --> Controller Class Initialized
INFO - 2017-12-18 07:15:31 --> Model Class Initialized
INFO - 2017-12-18 07:15:31 --> Model Class Initialized
INFO - 2017-12-18 07:15:31 --> Model Class Initialized
DEBUG - 2017-12-18 07:15:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-18 07:15:31 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-18 07:15:31 --> Final output sent to browser
DEBUG - 2017-12-18 07:15:31 --> Total execution time: 0.0571
INFO - 2017-12-18 07:15:31 --> Config Class Initialized
INFO - 2017-12-18 07:15:31 --> Hooks Class Initialized
INFO - 2017-12-18 07:15:31 --> Config Class Initialized
INFO - 2017-12-18 07:15:31 --> Hooks Class Initialized
DEBUG - 2017-12-18 07:15:31 --> UTF-8 Support Enabled
DEBUG - 2017-12-18 07:15:31 --> UTF-8 Support Enabled
INFO - 2017-12-18 07:15:31 --> Utf8 Class Initialized
INFO - 2017-12-18 07:15:31 --> Utf8 Class Initialized
INFO - 2017-12-18 07:15:31 --> URI Class Initialized
INFO - 2017-12-18 07:15:31 --> URI Class Initialized
INFO - 2017-12-18 07:15:31 --> Router Class Initialized
INFO - 2017-12-18 07:15:31 --> Router Class Initialized
INFO - 2017-12-18 07:15:31 --> Output Class Initialized
INFO - 2017-12-18 07:15:31 --> Output Class Initialized
INFO - 2017-12-18 07:15:31 --> Security Class Initialized
INFO - 2017-12-18 07:15:31 --> Security Class Initialized
DEBUG - 2017-12-18 07:15:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-18 07:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 07:15:31 --> Input Class Initialized
INFO - 2017-12-18 07:15:31 --> Input Class Initialized
INFO - 2017-12-18 07:15:31 --> Language Class Initialized
INFO - 2017-12-18 07:15:31 --> Language Class Initialized
INFO - 2017-12-18 07:15:31 --> Loader Class Initialized
INFO - 2017-12-18 07:15:31 --> Loader Class Initialized
INFO - 2017-12-18 07:15:31 --> Helper loaded: url_helper
INFO - 2017-12-18 07:15:31 --> Helper loaded: url_helper
INFO - 2017-12-18 07:15:31 --> Helper loaded: form_helper
INFO - 2017-12-18 07:15:31 --> Helper loaded: form_helper
INFO - 2017-12-18 07:15:31 --> Database Driver Class Initialized
INFO - 2017-12-18 07:15:31 --> Database Driver Class Initialized
DEBUG - 2017-12-18 07:15:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2017-12-18 07:15:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-18 07:15:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-18 07:15:31 --> Form Validation Class Initialized
INFO - 2017-12-18 07:15:31 --> Model Class Initialized
INFO - 2017-12-18 07:15:31 --> Controller Class Initialized
INFO - 2017-12-18 07:15:31 --> Model Class Initialized
INFO - 2017-12-18 07:15:31 --> Model Class Initialized
INFO - 2017-12-18 07:15:31 --> Model Class Initialized
DEBUG - 2017-12-18 07:15:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-18 07:15:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-18 07:15:31 --> Form Validation Class Initialized
INFO - 2017-12-18 07:15:31 --> Model Class Initialized
INFO - 2017-12-18 07:15:31 --> Controller Class Initialized
INFO - 2017-12-18 07:15:31 --> Model Class Initialized
INFO - 2017-12-18 07:15:31 --> Model Class Initialized
INFO - 2017-12-18 07:15:31 --> Model Class Initialized
DEBUG - 2017-12-18 07:15:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-18 07:15:32 --> Config Class Initialized
INFO - 2017-12-18 07:15:32 --> Hooks Class Initialized
DEBUG - 2017-12-18 07:15:32 --> UTF-8 Support Enabled
INFO - 2017-12-18 07:15:32 --> Utf8 Class Initialized
INFO - 2017-12-18 07:15:32 --> URI Class Initialized
INFO - 2017-12-18 07:15:32 --> Router Class Initialized
INFO - 2017-12-18 07:15:32 --> Output Class Initialized
INFO - 2017-12-18 07:15:32 --> Security Class Initialized
DEBUG - 2017-12-18 07:15:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 07:15:32 --> Input Class Initialized
INFO - 2017-12-18 07:15:32 --> Language Class Initialized
INFO - 2017-12-18 07:15:32 --> Loader Class Initialized
INFO - 2017-12-18 07:15:32 --> Helper loaded: url_helper
INFO - 2017-12-18 07:15:32 --> Helper loaded: form_helper
INFO - 2017-12-18 07:15:32 --> Database Driver Class Initialized
DEBUG - 2017-12-18 07:15:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-18 07:15:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-18 07:15:32 --> Form Validation Class Initialized
INFO - 2017-12-18 07:15:32 --> Model Class Initialized
INFO - 2017-12-18 07:15:32 --> Controller Class Initialized
INFO - 2017-12-18 07:15:32 --> Model Class Initialized
INFO - 2017-12-18 07:15:32 --> Model Class Initialized
INFO - 2017-12-18 07:15:32 --> Model Class Initialized
DEBUG - 2017-12-18 07:15:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-18 07:15:32 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-18 07:15:32 --> Final output sent to browser
DEBUG - 2017-12-18 07:15:32 --> Total execution time: 0.0590
INFO - 2017-12-18 07:15:53 --> Config Class Initialized
INFO - 2017-12-18 07:15:53 --> Hooks Class Initialized
DEBUG - 2017-12-18 07:15:53 --> UTF-8 Support Enabled
INFO - 2017-12-18 07:15:53 --> Utf8 Class Initialized
INFO - 2017-12-18 07:15:53 --> URI Class Initialized
INFO - 2017-12-18 07:15:53 --> Router Class Initialized
INFO - 2017-12-18 07:15:53 --> Output Class Initialized
INFO - 2017-12-18 07:15:53 --> Security Class Initialized
DEBUG - 2017-12-18 07:15:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 07:15:53 --> Input Class Initialized
INFO - 2017-12-18 07:15:53 --> Language Class Initialized
INFO - 2017-12-18 07:15:53 --> Loader Class Initialized
INFO - 2017-12-18 07:15:53 --> Helper loaded: url_helper
INFO - 2017-12-18 07:15:53 --> Helper loaded: form_helper
INFO - 2017-12-18 07:15:53 --> Database Driver Class Initialized
DEBUG - 2017-12-18 07:15:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-18 07:15:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-18 07:15:53 --> Form Validation Class Initialized
INFO - 2017-12-18 07:15:53 --> Model Class Initialized
INFO - 2017-12-18 07:15:53 --> Controller Class Initialized
INFO - 2017-12-18 07:15:53 --> Model Class Initialized
INFO - 2017-12-18 07:15:53 --> Model Class Initialized
INFO - 2017-12-18 07:15:53 --> Model Class Initialized
DEBUG - 2017-12-18 07:15:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-18 07:15:53 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-18 07:15:53 --> Final output sent to browser
DEBUG - 2017-12-18 07:15:53 --> Total execution time: 0.1042
INFO - 2017-12-18 07:17:29 --> Config Class Initialized
INFO - 2017-12-18 07:17:29 --> Hooks Class Initialized
DEBUG - 2017-12-18 07:17:29 --> UTF-8 Support Enabled
INFO - 2017-12-18 07:17:29 --> Utf8 Class Initialized
INFO - 2017-12-18 07:17:29 --> URI Class Initialized
INFO - 2017-12-18 07:17:29 --> Router Class Initialized
INFO - 2017-12-18 07:17:29 --> Output Class Initialized
INFO - 2017-12-18 07:17:29 --> Security Class Initialized
DEBUG - 2017-12-18 07:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 07:17:29 --> Input Class Initialized
INFO - 2017-12-18 07:17:29 --> Language Class Initialized
INFO - 2017-12-18 07:17:29 --> Loader Class Initialized
INFO - 2017-12-18 07:17:29 --> Helper loaded: url_helper
INFO - 2017-12-18 07:17:29 --> Helper loaded: form_helper
INFO - 2017-12-18 07:17:29 --> Database Driver Class Initialized
DEBUG - 2017-12-18 07:17:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-18 07:17:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-18 07:17:29 --> Form Validation Class Initialized
INFO - 2017-12-18 07:17:29 --> Model Class Initialized
INFO - 2017-12-18 07:17:29 --> Controller Class Initialized
INFO - 2017-12-18 07:17:29 --> Model Class Initialized
INFO - 2017-12-18 07:17:29 --> Model Class Initialized
INFO - 2017-12-18 07:17:29 --> Model Class Initialized
DEBUG - 2017-12-18 07:17:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-18 07:17:29 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-18 07:17:29 --> Final output sent to browser
DEBUG - 2017-12-18 07:17:29 --> Total execution time: 0.1099
INFO - 2017-12-18 07:17:31 --> Config Class Initialized
INFO - 2017-12-18 07:17:31 --> Hooks Class Initialized
INFO - 2017-12-18 07:17:31 --> Config Class Initialized
INFO - 2017-12-18 07:17:31 --> Hooks Class Initialized
DEBUG - 2017-12-18 07:17:31 --> UTF-8 Support Enabled
DEBUG - 2017-12-18 07:17:31 --> UTF-8 Support Enabled
INFO - 2017-12-18 07:17:31 --> Utf8 Class Initialized
INFO - 2017-12-18 07:17:31 --> Utf8 Class Initialized
INFO - 2017-12-18 07:17:31 --> URI Class Initialized
INFO - 2017-12-18 07:17:31 --> URI Class Initialized
INFO - 2017-12-18 07:17:31 --> Router Class Initialized
INFO - 2017-12-18 07:17:31 --> Router Class Initialized
INFO - 2017-12-18 07:17:31 --> Output Class Initialized
INFO - 2017-12-18 07:17:31 --> Output Class Initialized
INFO - 2017-12-18 07:17:31 --> Security Class Initialized
INFO - 2017-12-18 07:17:31 --> Security Class Initialized
DEBUG - 2017-12-18 07:17:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 07:17:31 --> Input Class Initialized
DEBUG - 2017-12-18 07:17:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 07:17:31 --> Input Class Initialized
INFO - 2017-12-18 07:17:31 --> Language Class Initialized
INFO - 2017-12-18 07:17:31 --> Language Class Initialized
ERROR - 2017-12-18 07:17:31 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-18 07:17:31 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-18 07:17:33 --> Config Class Initialized
INFO - 2017-12-18 07:17:33 --> Hooks Class Initialized
DEBUG - 2017-12-18 07:17:33 --> UTF-8 Support Enabled
INFO - 2017-12-18 07:17:33 --> Utf8 Class Initialized
INFO - 2017-12-18 07:17:33 --> URI Class Initialized
INFO - 2017-12-18 07:17:33 --> Router Class Initialized
INFO - 2017-12-18 07:17:33 --> Output Class Initialized
INFO - 2017-12-18 07:17:33 --> Security Class Initialized
DEBUG - 2017-12-18 07:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 07:17:33 --> Input Class Initialized
INFO - 2017-12-18 07:17:33 --> Language Class Initialized
INFO - 2017-12-18 07:17:33 --> Loader Class Initialized
INFO - 2017-12-18 07:17:33 --> Helper loaded: url_helper
INFO - 2017-12-18 07:17:33 --> Helper loaded: form_helper
INFO - 2017-12-18 07:17:33 --> Database Driver Class Initialized
DEBUG - 2017-12-18 07:17:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-18 07:17:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-18 07:17:33 --> Form Validation Class Initialized
INFO - 2017-12-18 07:17:33 --> Model Class Initialized
INFO - 2017-12-18 07:17:33 --> Controller Class Initialized
INFO - 2017-12-18 07:17:33 --> Model Class Initialized
INFO - 2017-12-18 07:17:33 --> Model Class Initialized
INFO - 2017-12-18 07:17:33 --> Model Class Initialized
DEBUG - 2017-12-18 07:17:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-18 07:17:33 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-18 07:17:33 --> Final output sent to browser
DEBUG - 2017-12-18 07:17:33 --> Total execution time: 0.1513
INFO - 2017-12-18 07:17:34 --> Config Class Initialized
INFO - 2017-12-18 07:17:34 --> Config Class Initialized
INFO - 2017-12-18 07:17:34 --> Hooks Class Initialized
INFO - 2017-12-18 07:17:34 --> Hooks Class Initialized
DEBUG - 2017-12-18 07:17:34 --> UTF-8 Support Enabled
DEBUG - 2017-12-18 07:17:34 --> UTF-8 Support Enabled
INFO - 2017-12-18 07:17:34 --> Utf8 Class Initialized
INFO - 2017-12-18 07:17:34 --> Utf8 Class Initialized
INFO - 2017-12-18 07:17:34 --> URI Class Initialized
INFO - 2017-12-18 07:17:34 --> URI Class Initialized
INFO - 2017-12-18 07:17:34 --> Router Class Initialized
INFO - 2017-12-18 07:17:34 --> Router Class Initialized
INFO - 2017-12-18 07:17:34 --> Output Class Initialized
INFO - 2017-12-18 07:17:34 --> Output Class Initialized
INFO - 2017-12-18 07:17:34 --> Security Class Initialized
INFO - 2017-12-18 07:17:34 --> Security Class Initialized
DEBUG - 2017-12-18 07:17:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 07:17:34 --> Input Class Initialized
DEBUG - 2017-12-18 07:17:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 07:17:34 --> Input Class Initialized
INFO - 2017-12-18 07:17:34 --> Language Class Initialized
INFO - 2017-12-18 07:17:34 --> Language Class Initialized
ERROR - 2017-12-18 07:17:34 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-18 07:17:34 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-18 07:17:47 --> Config Class Initialized
INFO - 2017-12-18 07:17:47 --> Hooks Class Initialized
DEBUG - 2017-12-18 07:17:47 --> UTF-8 Support Enabled
INFO - 2017-12-18 07:17:47 --> Utf8 Class Initialized
INFO - 2017-12-18 07:17:47 --> URI Class Initialized
INFO - 2017-12-18 07:17:47 --> Router Class Initialized
INFO - 2017-12-18 07:17:47 --> Output Class Initialized
INFO - 2017-12-18 07:17:47 --> Security Class Initialized
DEBUG - 2017-12-18 07:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 07:17:47 --> Input Class Initialized
INFO - 2017-12-18 07:17:47 --> Language Class Initialized
INFO - 2017-12-18 07:17:47 --> Loader Class Initialized
INFO - 2017-12-18 07:17:47 --> Helper loaded: url_helper
INFO - 2017-12-18 07:17:47 --> Helper loaded: form_helper
INFO - 2017-12-18 07:17:47 --> Database Driver Class Initialized
DEBUG - 2017-12-18 07:17:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-18 07:17:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-18 07:17:47 --> Form Validation Class Initialized
INFO - 2017-12-18 07:17:47 --> Model Class Initialized
INFO - 2017-12-18 07:17:47 --> Controller Class Initialized
INFO - 2017-12-18 07:17:47 --> Model Class Initialized
INFO - 2017-12-18 07:17:47 --> Model Class Initialized
INFO - 2017-12-18 07:17:47 --> Model Class Initialized
DEBUG - 2017-12-18 07:17:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-18 07:17:47 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-18 07:17:47 --> Final output sent to browser
DEBUG - 2017-12-18 07:17:47 --> Total execution time: 0.1149
INFO - 2017-12-18 07:17:48 --> Config Class Initialized
INFO - 2017-12-18 07:17:48 --> Hooks Class Initialized
INFO - 2017-12-18 07:17:48 --> Config Class Initialized
INFO - 2017-12-18 07:17:48 --> Hooks Class Initialized
DEBUG - 2017-12-18 07:17:48 --> UTF-8 Support Enabled
INFO - 2017-12-18 07:17:48 --> Utf8 Class Initialized
DEBUG - 2017-12-18 07:17:48 --> UTF-8 Support Enabled
INFO - 2017-12-18 07:17:48 --> URI Class Initialized
INFO - 2017-12-18 07:17:48 --> Utf8 Class Initialized
INFO - 2017-12-18 07:17:48 --> URI Class Initialized
INFO - 2017-12-18 07:17:48 --> Router Class Initialized
INFO - 2017-12-18 07:17:48 --> Router Class Initialized
INFO - 2017-12-18 07:17:48 --> Output Class Initialized
INFO - 2017-12-18 07:17:48 --> Security Class Initialized
INFO - 2017-12-18 07:17:48 --> Output Class Initialized
DEBUG - 2017-12-18 07:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 07:17:48 --> Input Class Initialized
INFO - 2017-12-18 07:17:48 --> Security Class Initialized
INFO - 2017-12-18 07:17:48 --> Language Class Initialized
DEBUG - 2017-12-18 07:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 07:17:48 --> Input Class Initialized
ERROR - 2017-12-18 07:17:48 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-18 07:17:48 --> Language Class Initialized
ERROR - 2017-12-18 07:17:48 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-18 07:18:04 --> Config Class Initialized
INFO - 2017-12-18 07:18:04 --> Hooks Class Initialized
DEBUG - 2017-12-18 07:18:04 --> UTF-8 Support Enabled
INFO - 2017-12-18 07:18:04 --> Utf8 Class Initialized
INFO - 2017-12-18 07:18:04 --> URI Class Initialized
INFO - 2017-12-18 07:18:04 --> Router Class Initialized
INFO - 2017-12-18 07:18:04 --> Output Class Initialized
INFO - 2017-12-18 07:18:04 --> Security Class Initialized
DEBUG - 2017-12-18 07:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 07:18:04 --> Input Class Initialized
INFO - 2017-12-18 07:18:04 --> Language Class Initialized
INFO - 2017-12-18 07:18:04 --> Loader Class Initialized
INFO - 2017-12-18 07:18:04 --> Helper loaded: url_helper
INFO - 2017-12-18 07:18:04 --> Helper loaded: form_helper
INFO - 2017-12-18 07:18:04 --> Database Driver Class Initialized
DEBUG - 2017-12-18 07:18:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-18 07:18:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-18 07:18:04 --> Form Validation Class Initialized
INFO - 2017-12-18 07:18:05 --> Model Class Initialized
INFO - 2017-12-18 07:18:05 --> Controller Class Initialized
INFO - 2017-12-18 07:18:05 --> Model Class Initialized
INFO - 2017-12-18 07:18:05 --> Model Class Initialized
INFO - 2017-12-18 07:18:05 --> Model Class Initialized
DEBUG - 2017-12-18 07:18:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-18 07:18:05 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-18 07:18:05 --> Final output sent to browser
DEBUG - 2017-12-18 07:18:05 --> Total execution time: 0.1191
INFO - 2017-12-18 07:18:05 --> Config Class Initialized
INFO - 2017-12-18 07:18:05 --> Hooks Class Initialized
INFO - 2017-12-18 07:18:05 --> Config Class Initialized
INFO - 2017-12-18 07:18:05 --> Hooks Class Initialized
DEBUG - 2017-12-18 07:18:05 --> UTF-8 Support Enabled
INFO - 2017-12-18 07:18:05 --> Utf8 Class Initialized
DEBUG - 2017-12-18 07:18:05 --> UTF-8 Support Enabled
INFO - 2017-12-18 07:18:05 --> Utf8 Class Initialized
INFO - 2017-12-18 07:18:05 --> URI Class Initialized
INFO - 2017-12-18 07:18:05 --> URI Class Initialized
INFO - 2017-12-18 07:18:05 --> Router Class Initialized
INFO - 2017-12-18 07:18:05 --> Router Class Initialized
INFO - 2017-12-18 07:18:05 --> Output Class Initialized
INFO - 2017-12-18 07:18:05 --> Output Class Initialized
INFO - 2017-12-18 07:18:05 --> Security Class Initialized
INFO - 2017-12-18 07:18:05 --> Security Class Initialized
DEBUG - 2017-12-18 07:18:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 07:18:05 --> Input Class Initialized
DEBUG - 2017-12-18 07:18:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 07:18:05 --> Input Class Initialized
INFO - 2017-12-18 07:18:05 --> Language Class Initialized
INFO - 2017-12-18 07:18:05 --> Language Class Initialized
ERROR - 2017-12-18 07:18:05 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-18 07:18:05 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-18 07:18:06 --> Config Class Initialized
INFO - 2017-12-18 07:18:06 --> Hooks Class Initialized
DEBUG - 2017-12-18 07:18:06 --> UTF-8 Support Enabled
INFO - 2017-12-18 07:18:06 --> Utf8 Class Initialized
INFO - 2017-12-18 07:18:06 --> URI Class Initialized
INFO - 2017-12-18 07:18:06 --> Router Class Initialized
INFO - 2017-12-18 07:18:06 --> Output Class Initialized
INFO - 2017-12-18 07:18:06 --> Security Class Initialized
DEBUG - 2017-12-18 07:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 07:18:06 --> Input Class Initialized
INFO - 2017-12-18 07:18:06 --> Language Class Initialized
INFO - 2017-12-18 07:18:06 --> Loader Class Initialized
INFO - 2017-12-18 07:18:06 --> Helper loaded: url_helper
INFO - 2017-12-18 07:18:06 --> Helper loaded: form_helper
INFO - 2017-12-18 07:18:06 --> Database Driver Class Initialized
DEBUG - 2017-12-18 07:18:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-18 07:18:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-18 07:18:06 --> Form Validation Class Initialized
INFO - 2017-12-18 07:18:06 --> Model Class Initialized
INFO - 2017-12-18 07:18:06 --> Controller Class Initialized
INFO - 2017-12-18 07:18:06 --> Model Class Initialized
INFO - 2017-12-18 07:18:06 --> Model Class Initialized
INFO - 2017-12-18 07:18:06 --> Model Class Initialized
DEBUG - 2017-12-18 07:18:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-18 07:18:06 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-18 07:18:06 --> Final output sent to browser
DEBUG - 2017-12-18 07:18:06 --> Total execution time: 0.1131
INFO - 2017-12-18 07:18:07 --> Config Class Initialized
INFO - 2017-12-18 07:18:07 --> Hooks Class Initialized
INFO - 2017-12-18 07:18:07 --> Config Class Initialized
INFO - 2017-12-18 07:18:07 --> Hooks Class Initialized
DEBUG - 2017-12-18 07:18:07 --> UTF-8 Support Enabled
INFO - 2017-12-18 07:18:07 --> Utf8 Class Initialized
INFO - 2017-12-18 07:18:07 --> URI Class Initialized
INFO - 2017-12-18 07:18:07 --> Router Class Initialized
DEBUG - 2017-12-18 07:18:07 --> UTF-8 Support Enabled
INFO - 2017-12-18 07:18:07 --> Utf8 Class Initialized
INFO - 2017-12-18 07:18:07 --> Output Class Initialized
INFO - 2017-12-18 07:18:07 --> URI Class Initialized
INFO - 2017-12-18 07:18:07 --> Security Class Initialized
INFO - 2017-12-18 07:18:07 --> Router Class Initialized
DEBUG - 2017-12-18 07:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 07:18:07 --> Input Class Initialized
INFO - 2017-12-18 07:18:07 --> Output Class Initialized
INFO - 2017-12-18 07:18:07 --> Language Class Initialized
INFO - 2017-12-18 07:18:07 --> Security Class Initialized
ERROR - 2017-12-18 07:18:07 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2017-12-18 07:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 07:18:07 --> Input Class Initialized
INFO - 2017-12-18 07:18:07 --> Language Class Initialized
ERROR - 2017-12-18 07:18:07 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-18 07:18:35 --> Config Class Initialized
INFO - 2017-12-18 07:18:35 --> Hooks Class Initialized
DEBUG - 2017-12-18 07:18:35 --> UTF-8 Support Enabled
INFO - 2017-12-18 07:18:35 --> Utf8 Class Initialized
INFO - 2017-12-18 07:18:35 --> URI Class Initialized
INFO - 2017-12-18 07:18:35 --> Router Class Initialized
INFO - 2017-12-18 07:18:35 --> Output Class Initialized
INFO - 2017-12-18 07:18:35 --> Security Class Initialized
DEBUG - 2017-12-18 07:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 07:18:35 --> Input Class Initialized
INFO - 2017-12-18 07:18:35 --> Language Class Initialized
INFO - 2017-12-18 07:18:35 --> Loader Class Initialized
INFO - 2017-12-18 07:18:35 --> Helper loaded: url_helper
INFO - 2017-12-18 07:18:35 --> Helper loaded: form_helper
INFO - 2017-12-18 07:18:35 --> Database Driver Class Initialized
DEBUG - 2017-12-18 07:18:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-18 07:18:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-18 07:18:35 --> Form Validation Class Initialized
INFO - 2017-12-18 07:18:35 --> Model Class Initialized
INFO - 2017-12-18 07:18:35 --> Controller Class Initialized
INFO - 2017-12-18 07:18:35 --> Model Class Initialized
INFO - 2017-12-18 07:18:35 --> Model Class Initialized
INFO - 2017-12-18 07:18:36 --> Model Class Initialized
DEBUG - 2017-12-18 07:18:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-18 07:18:36 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-18 07:18:36 --> Final output sent to browser
DEBUG - 2017-12-18 07:18:36 --> Total execution time: 0.1496
INFO - 2017-12-18 07:18:36 --> Config Class Initialized
INFO - 2017-12-18 07:18:36 --> Hooks Class Initialized
INFO - 2017-12-18 07:18:36 --> Config Class Initialized
INFO - 2017-12-18 07:18:36 --> Hooks Class Initialized
DEBUG - 2017-12-18 07:18:36 --> UTF-8 Support Enabled
INFO - 2017-12-18 07:18:36 --> Utf8 Class Initialized
INFO - 2017-12-18 07:18:36 --> URI Class Initialized
DEBUG - 2017-12-18 07:18:36 --> UTF-8 Support Enabled
INFO - 2017-12-18 07:18:36 --> Utf8 Class Initialized
INFO - 2017-12-18 07:18:36 --> Router Class Initialized
INFO - 2017-12-18 07:18:36 --> URI Class Initialized
INFO - 2017-12-18 07:18:36 --> Output Class Initialized
INFO - 2017-12-18 07:18:36 --> Router Class Initialized
INFO - 2017-12-18 07:18:36 --> Security Class Initialized
INFO - 2017-12-18 07:18:36 --> Output Class Initialized
DEBUG - 2017-12-18 07:18:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 07:18:36 --> Input Class Initialized
INFO - 2017-12-18 07:18:36 --> Security Class Initialized
INFO - 2017-12-18 07:18:36 --> Language Class Initialized
DEBUG - 2017-12-18 07:18:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 07:18:36 --> Input Class Initialized
ERROR - 2017-12-18 07:18:36 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-18 07:18:36 --> Language Class Initialized
ERROR - 2017-12-18 07:18:36 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-18 07:18:37 --> Config Class Initialized
INFO - 2017-12-18 07:18:37 --> Hooks Class Initialized
DEBUG - 2017-12-18 07:18:37 --> UTF-8 Support Enabled
INFO - 2017-12-18 07:18:37 --> Utf8 Class Initialized
INFO - 2017-12-18 07:18:37 --> URI Class Initialized
INFO - 2017-12-18 07:18:37 --> Router Class Initialized
INFO - 2017-12-18 07:18:37 --> Output Class Initialized
INFO - 2017-12-18 07:18:37 --> Security Class Initialized
DEBUG - 2017-12-18 07:18:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 07:18:37 --> Input Class Initialized
INFO - 2017-12-18 07:18:37 --> Language Class Initialized
INFO - 2017-12-18 07:18:37 --> Loader Class Initialized
INFO - 2017-12-18 07:18:37 --> Helper loaded: url_helper
INFO - 2017-12-18 07:18:37 --> Helper loaded: form_helper
INFO - 2017-12-18 07:18:37 --> Database Driver Class Initialized
DEBUG - 2017-12-18 07:18:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-18 07:18:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-18 07:18:37 --> Form Validation Class Initialized
INFO - 2017-12-18 07:18:37 --> Model Class Initialized
INFO - 2017-12-18 07:18:37 --> Controller Class Initialized
INFO - 2017-12-18 07:18:37 --> Model Class Initialized
INFO - 2017-12-18 07:18:37 --> Model Class Initialized
INFO - 2017-12-18 07:18:37 --> Model Class Initialized
DEBUG - 2017-12-18 07:18:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-18 07:18:37 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-18 07:18:37 --> Final output sent to browser
DEBUG - 2017-12-18 07:18:37 --> Total execution time: 0.1465
INFO - 2017-12-18 07:18:38 --> Config Class Initialized
INFO - 2017-12-18 07:18:38 --> Hooks Class Initialized
INFO - 2017-12-18 07:18:38 --> Config Class Initialized
INFO - 2017-12-18 07:18:38 --> Hooks Class Initialized
DEBUG - 2017-12-18 07:18:38 --> UTF-8 Support Enabled
INFO - 2017-12-18 07:18:38 --> Utf8 Class Initialized
INFO - 2017-12-18 07:18:38 --> URI Class Initialized
DEBUG - 2017-12-18 07:18:38 --> UTF-8 Support Enabled
INFO - 2017-12-18 07:18:38 --> Utf8 Class Initialized
INFO - 2017-12-18 07:18:38 --> Router Class Initialized
INFO - 2017-12-18 07:18:38 --> URI Class Initialized
INFO - 2017-12-18 07:18:38 --> Output Class Initialized
INFO - 2017-12-18 07:18:38 --> Router Class Initialized
INFO - 2017-12-18 07:18:38 --> Security Class Initialized
INFO - 2017-12-18 07:18:38 --> Output Class Initialized
DEBUG - 2017-12-18 07:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 07:18:38 --> Input Class Initialized
INFO - 2017-12-18 07:18:38 --> Language Class Initialized
INFO - 2017-12-18 07:18:38 --> Security Class Initialized
ERROR - 2017-12-18 07:18:38 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2017-12-18 07:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 07:18:38 --> Input Class Initialized
INFO - 2017-12-18 07:18:38 --> Language Class Initialized
ERROR - 2017-12-18 07:18:38 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-18 07:19:03 --> Config Class Initialized
INFO - 2017-12-18 07:19:03 --> Hooks Class Initialized
DEBUG - 2017-12-18 07:19:03 --> UTF-8 Support Enabled
INFO - 2017-12-18 07:19:03 --> Utf8 Class Initialized
INFO - 2017-12-18 07:19:03 --> URI Class Initialized
INFO - 2017-12-18 07:19:03 --> Router Class Initialized
INFO - 2017-12-18 07:19:03 --> Output Class Initialized
INFO - 2017-12-18 07:19:03 --> Security Class Initialized
DEBUG - 2017-12-18 07:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 07:19:03 --> Input Class Initialized
INFO - 2017-12-18 07:19:03 --> Language Class Initialized
INFO - 2017-12-18 07:19:03 --> Loader Class Initialized
INFO - 2017-12-18 07:19:03 --> Helper loaded: url_helper
INFO - 2017-12-18 07:19:03 --> Helper loaded: form_helper
INFO - 2017-12-18 07:19:03 --> Database Driver Class Initialized
DEBUG - 2017-12-18 07:19:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-18 07:19:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-18 07:19:03 --> Form Validation Class Initialized
INFO - 2017-12-18 07:19:03 --> Model Class Initialized
INFO - 2017-12-18 07:19:03 --> Controller Class Initialized
INFO - 2017-12-18 07:19:03 --> Model Class Initialized
INFO - 2017-12-18 07:19:03 --> Model Class Initialized
DEBUG - 2017-12-18 07:19:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-18 07:19:03 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-18 07:19:03 --> Final output sent to browser
DEBUG - 2017-12-18 07:19:03 --> Total execution time: 0.0520
INFO - 2017-12-18 07:19:04 --> Config Class Initialized
INFO - 2017-12-18 07:19:04 --> Hooks Class Initialized
DEBUG - 2017-12-18 07:19:04 --> UTF-8 Support Enabled
INFO - 2017-12-18 07:19:04 --> Utf8 Class Initialized
INFO - 2017-12-18 07:19:04 --> URI Class Initialized
INFO - 2017-12-18 07:19:04 --> Router Class Initialized
INFO - 2017-12-18 07:19:04 --> Output Class Initialized
INFO - 2017-12-18 07:19:04 --> Security Class Initialized
DEBUG - 2017-12-18 07:19:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 07:19:04 --> Input Class Initialized
INFO - 2017-12-18 07:19:04 --> Language Class Initialized
INFO - 2017-12-18 07:19:04 --> Loader Class Initialized
INFO - 2017-12-18 07:19:04 --> Helper loaded: url_helper
INFO - 2017-12-18 07:19:04 --> Helper loaded: form_helper
INFO - 2017-12-18 07:19:04 --> Database Driver Class Initialized
DEBUG - 2017-12-18 07:19:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-18 07:19:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-18 07:19:04 --> Form Validation Class Initialized
INFO - 2017-12-18 07:19:04 --> Model Class Initialized
INFO - 2017-12-18 07:19:04 --> Controller Class Initialized
INFO - 2017-12-18 07:19:04 --> Model Class Initialized
INFO - 2017-12-18 07:19:04 --> Model Class Initialized
DEBUG - 2017-12-18 07:19:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-18 07:19:08 --> Config Class Initialized
INFO - 2017-12-18 07:19:08 --> Hooks Class Initialized
DEBUG - 2017-12-18 07:19:08 --> UTF-8 Support Enabled
INFO - 2017-12-18 07:19:08 --> Utf8 Class Initialized
INFO - 2017-12-18 07:19:08 --> URI Class Initialized
INFO - 2017-12-18 07:19:08 --> Router Class Initialized
INFO - 2017-12-18 07:19:08 --> Output Class Initialized
INFO - 2017-12-18 07:19:08 --> Security Class Initialized
DEBUG - 2017-12-18 07:19:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 07:19:08 --> Input Class Initialized
INFO - 2017-12-18 07:19:08 --> Language Class Initialized
INFO - 2017-12-18 07:19:08 --> Loader Class Initialized
INFO - 2017-12-18 07:19:08 --> Helper loaded: url_helper
INFO - 2017-12-18 07:19:08 --> Helper loaded: form_helper
INFO - 2017-12-18 07:19:08 --> Database Driver Class Initialized
DEBUG - 2017-12-18 07:19:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-18 07:19:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-18 07:19:08 --> Form Validation Class Initialized
INFO - 2017-12-18 07:19:08 --> Model Class Initialized
INFO - 2017-12-18 07:19:08 --> Controller Class Initialized
INFO - 2017-12-18 07:19:08 --> Model Class Initialized
INFO - 2017-12-18 07:19:08 --> Model Class Initialized
DEBUG - 2017-12-18 07:19:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-18 07:19:08 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-18 07:19:08 --> Final output sent to browser
DEBUG - 2017-12-18 07:19:08 --> Total execution time: 0.0573
INFO - 2017-12-18 07:19:08 --> Config Class Initialized
INFO - 2017-12-18 07:19:08 --> Hooks Class Initialized
DEBUG - 2017-12-18 07:19:08 --> UTF-8 Support Enabled
INFO - 2017-12-18 07:19:08 --> Utf8 Class Initialized
INFO - 2017-12-18 07:19:08 --> URI Class Initialized
INFO - 2017-12-18 07:19:08 --> Router Class Initialized
INFO - 2017-12-18 07:19:08 --> Output Class Initialized
INFO - 2017-12-18 07:19:08 --> Security Class Initialized
DEBUG - 2017-12-18 07:19:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 07:19:08 --> Input Class Initialized
INFO - 2017-12-18 07:19:08 --> Language Class Initialized
INFO - 2017-12-18 07:19:08 --> Loader Class Initialized
INFO - 2017-12-18 07:19:08 --> Helper loaded: url_helper
INFO - 2017-12-18 07:19:08 --> Helper loaded: form_helper
INFO - 2017-12-18 07:19:08 --> Database Driver Class Initialized
DEBUG - 2017-12-18 07:19:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-18 07:19:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-18 07:19:08 --> Form Validation Class Initialized
INFO - 2017-12-18 07:19:08 --> Model Class Initialized
INFO - 2017-12-18 07:19:08 --> Controller Class Initialized
INFO - 2017-12-18 07:19:08 --> Model Class Initialized
INFO - 2017-12-18 07:19:08 --> Model Class Initialized
DEBUG - 2017-12-18 07:19:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-18 07:19:10 --> Config Class Initialized
INFO - 2017-12-18 07:19:10 --> Hooks Class Initialized
DEBUG - 2017-12-18 07:19:10 --> UTF-8 Support Enabled
INFO - 2017-12-18 07:19:10 --> Utf8 Class Initialized
INFO - 2017-12-18 07:19:10 --> URI Class Initialized
INFO - 2017-12-18 07:19:10 --> Router Class Initialized
INFO - 2017-12-18 07:19:10 --> Output Class Initialized
INFO - 2017-12-18 07:19:10 --> Security Class Initialized
DEBUG - 2017-12-18 07:19:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 07:19:10 --> Input Class Initialized
INFO - 2017-12-18 07:19:10 --> Language Class Initialized
INFO - 2017-12-18 07:19:10 --> Loader Class Initialized
INFO - 2017-12-18 07:19:10 --> Helper loaded: url_helper
INFO - 2017-12-18 07:19:10 --> Helper loaded: form_helper
INFO - 2017-12-18 07:19:10 --> Database Driver Class Initialized
DEBUG - 2017-12-18 07:19:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-18 07:19:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-18 07:19:10 --> Form Validation Class Initialized
INFO - 2017-12-18 07:19:10 --> Model Class Initialized
INFO - 2017-12-18 07:19:10 --> Controller Class Initialized
INFO - 2017-12-18 07:19:10 --> Model Class Initialized
INFO - 2017-12-18 07:19:10 --> Model Class Initialized
INFO - 2017-12-18 07:19:10 --> Model Class Initialized
DEBUG - 2017-12-18 07:19:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-18 07:19:10 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-18 07:19:10 --> Final output sent to browser
DEBUG - 2017-12-18 07:19:10 --> Total execution time: 0.0508
INFO - 2017-12-18 07:19:11 --> Config Class Initialized
INFO - 2017-12-18 07:19:11 --> Hooks Class Initialized
DEBUG - 2017-12-18 07:19:11 --> UTF-8 Support Enabled
INFO - 2017-12-18 07:19:11 --> Utf8 Class Initialized
INFO - 2017-12-18 07:19:11 --> URI Class Initialized
INFO - 2017-12-18 07:19:11 --> Router Class Initialized
INFO - 2017-12-18 07:19:11 --> Output Class Initialized
INFO - 2017-12-18 07:19:11 --> Security Class Initialized
DEBUG - 2017-12-18 07:19:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 07:19:11 --> Input Class Initialized
INFO - 2017-12-18 07:19:11 --> Language Class Initialized
INFO - 2017-12-18 07:19:11 --> Loader Class Initialized
INFO - 2017-12-18 07:19:11 --> Helper loaded: url_helper
INFO - 2017-12-18 07:19:11 --> Helper loaded: form_helper
INFO - 2017-12-18 07:19:11 --> Database Driver Class Initialized
DEBUG - 2017-12-18 07:19:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-18 07:19:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-18 07:19:11 --> Form Validation Class Initialized
INFO - 2017-12-18 07:19:11 --> Model Class Initialized
INFO - 2017-12-18 07:19:11 --> Controller Class Initialized
INFO - 2017-12-18 07:19:11 --> Model Class Initialized
INFO - 2017-12-18 07:19:11 --> Model Class Initialized
INFO - 2017-12-18 07:19:11 --> Model Class Initialized
DEBUG - 2017-12-18 07:19:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-18 07:19:20 --> Config Class Initialized
INFO - 2017-12-18 07:19:20 --> Hooks Class Initialized
DEBUG - 2017-12-18 07:19:20 --> UTF-8 Support Enabled
INFO - 2017-12-18 07:19:20 --> Utf8 Class Initialized
INFO - 2017-12-18 07:19:20 --> URI Class Initialized
INFO - 2017-12-18 07:19:20 --> Router Class Initialized
INFO - 2017-12-18 07:19:20 --> Output Class Initialized
INFO - 2017-12-18 07:19:20 --> Security Class Initialized
DEBUG - 2017-12-18 07:19:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 07:19:20 --> Input Class Initialized
INFO - 2017-12-18 07:19:20 --> Language Class Initialized
INFO - 2017-12-18 07:19:20 --> Loader Class Initialized
INFO - 2017-12-18 07:19:20 --> Helper loaded: url_helper
INFO - 2017-12-18 07:19:20 --> Helper loaded: form_helper
INFO - 2017-12-18 07:19:20 --> Database Driver Class Initialized
DEBUG - 2017-12-18 07:19:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-18 07:19:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-18 07:19:20 --> Form Validation Class Initialized
INFO - 2017-12-18 07:19:20 --> Model Class Initialized
INFO - 2017-12-18 07:19:20 --> Controller Class Initialized
INFO - 2017-12-18 07:19:20 --> Model Class Initialized
INFO - 2017-12-18 07:19:20 --> Model Class Initialized
DEBUG - 2017-12-18 07:19:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-18 07:19:20 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-18 07:19:20 --> Final output sent to browser
DEBUG - 2017-12-18 07:19:20 --> Total execution time: 0.0546
INFO - 2017-12-18 07:19:20 --> Config Class Initialized
INFO - 2017-12-18 07:19:20 --> Hooks Class Initialized
DEBUG - 2017-12-18 07:19:20 --> UTF-8 Support Enabled
INFO - 2017-12-18 07:19:20 --> Utf8 Class Initialized
INFO - 2017-12-18 07:19:20 --> URI Class Initialized
INFO - 2017-12-18 07:19:20 --> Router Class Initialized
INFO - 2017-12-18 07:19:20 --> Output Class Initialized
INFO - 2017-12-18 07:19:20 --> Security Class Initialized
DEBUG - 2017-12-18 07:19:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 07:19:20 --> Input Class Initialized
INFO - 2017-12-18 07:19:20 --> Language Class Initialized
INFO - 2017-12-18 07:19:20 --> Loader Class Initialized
INFO - 2017-12-18 07:19:20 --> Helper loaded: url_helper
INFO - 2017-12-18 07:19:20 --> Helper loaded: form_helper
INFO - 2017-12-18 07:19:20 --> Database Driver Class Initialized
DEBUG - 2017-12-18 07:19:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-18 07:19:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-18 07:19:20 --> Form Validation Class Initialized
INFO - 2017-12-18 07:19:20 --> Model Class Initialized
INFO - 2017-12-18 07:19:20 --> Controller Class Initialized
INFO - 2017-12-18 07:19:20 --> Model Class Initialized
INFO - 2017-12-18 07:19:20 --> Model Class Initialized
DEBUG - 2017-12-18 07:19:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-18 07:19:32 --> Config Class Initialized
INFO - 2017-12-18 07:19:32 --> Hooks Class Initialized
DEBUG - 2017-12-18 07:19:32 --> UTF-8 Support Enabled
INFO - 2017-12-18 07:19:32 --> Utf8 Class Initialized
INFO - 2017-12-18 07:19:32 --> URI Class Initialized
INFO - 2017-12-18 07:19:32 --> Router Class Initialized
INFO - 2017-12-18 07:19:32 --> Output Class Initialized
INFO - 2017-12-18 07:19:32 --> Security Class Initialized
DEBUG - 2017-12-18 07:19:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 07:19:32 --> Input Class Initialized
INFO - 2017-12-18 07:19:32 --> Language Class Initialized
INFO - 2017-12-18 07:19:32 --> Loader Class Initialized
INFO - 2017-12-18 07:19:32 --> Helper loaded: url_helper
INFO - 2017-12-18 07:19:32 --> Helper loaded: form_helper
INFO - 2017-12-18 07:19:32 --> Database Driver Class Initialized
DEBUG - 2017-12-18 07:19:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-18 07:19:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-18 07:19:32 --> Form Validation Class Initialized
INFO - 2017-12-18 07:19:32 --> Model Class Initialized
INFO - 2017-12-18 07:19:32 --> Controller Class Initialized
INFO - 2017-12-18 07:19:32 --> Model Class Initialized
INFO - 2017-12-18 07:19:32 --> Model Class Initialized
DEBUG - 2017-12-18 07:19:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-18 07:19:34 --> Config Class Initialized
INFO - 2017-12-18 07:19:34 --> Hooks Class Initialized
DEBUG - 2017-12-18 07:19:34 --> UTF-8 Support Enabled
INFO - 2017-12-18 07:19:34 --> Utf8 Class Initialized
INFO - 2017-12-18 07:19:34 --> URI Class Initialized
INFO - 2017-12-18 07:19:34 --> Router Class Initialized
INFO - 2017-12-18 07:19:34 --> Output Class Initialized
INFO - 2017-12-18 07:19:34 --> Security Class Initialized
DEBUG - 2017-12-18 07:19:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 07:19:34 --> Input Class Initialized
INFO - 2017-12-18 07:19:34 --> Language Class Initialized
INFO - 2017-12-18 07:19:34 --> Loader Class Initialized
INFO - 2017-12-18 07:19:34 --> Helper loaded: url_helper
INFO - 2017-12-18 07:19:34 --> Helper loaded: form_helper
INFO - 2017-12-18 07:19:34 --> Database Driver Class Initialized
DEBUG - 2017-12-18 07:19:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-18 07:19:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-18 07:19:34 --> Form Validation Class Initialized
INFO - 2017-12-18 07:19:34 --> Model Class Initialized
INFO - 2017-12-18 07:19:34 --> Controller Class Initialized
INFO - 2017-12-18 07:19:34 --> Model Class Initialized
INFO - 2017-12-18 07:19:34 --> Model Class Initialized
DEBUG - 2017-12-18 07:19:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-18 07:19:37 --> Config Class Initialized
INFO - 2017-12-18 07:19:37 --> Hooks Class Initialized
DEBUG - 2017-12-18 07:19:37 --> UTF-8 Support Enabled
INFO - 2017-12-18 07:19:37 --> Utf8 Class Initialized
INFO - 2017-12-18 07:19:37 --> URI Class Initialized
INFO - 2017-12-18 07:19:37 --> Router Class Initialized
INFO - 2017-12-18 07:19:37 --> Output Class Initialized
INFO - 2017-12-18 07:19:37 --> Security Class Initialized
DEBUG - 2017-12-18 07:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 07:19:37 --> Input Class Initialized
INFO - 2017-12-18 07:19:37 --> Language Class Initialized
INFO - 2017-12-18 07:19:37 --> Loader Class Initialized
INFO - 2017-12-18 07:19:37 --> Helper loaded: url_helper
INFO - 2017-12-18 07:19:37 --> Helper loaded: form_helper
INFO - 2017-12-18 07:19:37 --> Database Driver Class Initialized
DEBUG - 2017-12-18 07:19:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-18 07:19:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-18 07:19:37 --> Form Validation Class Initialized
INFO - 2017-12-18 07:19:37 --> Model Class Initialized
INFO - 2017-12-18 07:19:37 --> Controller Class Initialized
INFO - 2017-12-18 07:19:37 --> Model Class Initialized
INFO - 2017-12-18 07:19:37 --> Model Class Initialized
DEBUG - 2017-12-18 07:19:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-18 07:19:37 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-18 07:19:37 --> Final output sent to browser
DEBUG - 2017-12-18 07:19:37 --> Total execution time: 0.1182
INFO - 2017-12-18 07:19:37 --> Config Class Initialized
INFO - 2017-12-18 07:19:37 --> Hooks Class Initialized
DEBUG - 2017-12-18 07:19:37 --> UTF-8 Support Enabled
INFO - 2017-12-18 07:19:37 --> Utf8 Class Initialized
INFO - 2017-12-18 07:19:37 --> URI Class Initialized
INFO - 2017-12-18 07:19:37 --> Router Class Initialized
INFO - 2017-12-18 07:19:37 --> Output Class Initialized
INFO - 2017-12-18 07:19:37 --> Security Class Initialized
DEBUG - 2017-12-18 07:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 07:19:37 --> Input Class Initialized
INFO - 2017-12-18 07:19:37 --> Language Class Initialized
INFO - 2017-12-18 07:19:37 --> Loader Class Initialized
INFO - 2017-12-18 07:19:37 --> Helper loaded: url_helper
INFO - 2017-12-18 07:19:37 --> Helper loaded: form_helper
INFO - 2017-12-18 07:19:37 --> Database Driver Class Initialized
DEBUG - 2017-12-18 07:19:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-18 07:19:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-18 07:19:37 --> Form Validation Class Initialized
INFO - 2017-12-18 07:19:37 --> Model Class Initialized
INFO - 2017-12-18 07:19:37 --> Controller Class Initialized
INFO - 2017-12-18 07:19:37 --> Model Class Initialized
INFO - 2017-12-18 07:19:37 --> Model Class Initialized
DEBUG - 2017-12-18 07:19:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-18 07:19:38 --> Config Class Initialized
INFO - 2017-12-18 07:19:38 --> Hooks Class Initialized
DEBUG - 2017-12-18 07:19:38 --> UTF-8 Support Enabled
INFO - 2017-12-18 07:19:38 --> Utf8 Class Initialized
INFO - 2017-12-18 07:19:38 --> URI Class Initialized
INFO - 2017-12-18 07:19:38 --> Router Class Initialized
INFO - 2017-12-18 07:19:38 --> Output Class Initialized
INFO - 2017-12-18 07:19:38 --> Security Class Initialized
DEBUG - 2017-12-18 07:19:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 07:19:38 --> Input Class Initialized
INFO - 2017-12-18 07:19:38 --> Language Class Initialized
INFO - 2017-12-18 07:19:38 --> Loader Class Initialized
INFO - 2017-12-18 07:19:38 --> Helper loaded: url_helper
INFO - 2017-12-18 07:19:38 --> Helper loaded: form_helper
INFO - 2017-12-18 07:19:38 --> Database Driver Class Initialized
DEBUG - 2017-12-18 07:19:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-18 07:19:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-18 07:19:38 --> Form Validation Class Initialized
INFO - 2017-12-18 07:19:38 --> Model Class Initialized
INFO - 2017-12-18 07:19:38 --> Controller Class Initialized
INFO - 2017-12-18 07:19:38 --> Model Class Initialized
INFO - 2017-12-18 07:19:38 --> Model Class Initialized
INFO - 2017-12-18 07:19:38 --> Model Class Initialized
DEBUG - 2017-12-18 07:19:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-18 07:19:38 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-18 07:19:38 --> Final output sent to browser
DEBUG - 2017-12-18 07:19:38 --> Total execution time: 0.0622
INFO - 2017-12-18 07:19:38 --> Config Class Initialized
INFO - 2017-12-18 07:19:38 --> Hooks Class Initialized
DEBUG - 2017-12-18 07:19:38 --> UTF-8 Support Enabled
INFO - 2017-12-18 07:19:38 --> Utf8 Class Initialized
INFO - 2017-12-18 07:19:38 --> URI Class Initialized
INFO - 2017-12-18 07:19:38 --> Router Class Initialized
INFO - 2017-12-18 07:19:38 --> Output Class Initialized
INFO - 2017-12-18 07:19:38 --> Security Class Initialized
DEBUG - 2017-12-18 07:19:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 07:19:38 --> Input Class Initialized
INFO - 2017-12-18 07:19:38 --> Language Class Initialized
INFO - 2017-12-18 07:19:38 --> Loader Class Initialized
INFO - 2017-12-18 07:19:38 --> Helper loaded: url_helper
INFO - 2017-12-18 07:19:38 --> Helper loaded: form_helper
INFO - 2017-12-18 07:19:38 --> Database Driver Class Initialized
DEBUG - 2017-12-18 07:19:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-18 07:19:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-18 07:19:38 --> Form Validation Class Initialized
INFO - 2017-12-18 07:19:38 --> Model Class Initialized
INFO - 2017-12-18 07:19:38 --> Controller Class Initialized
INFO - 2017-12-18 07:19:38 --> Model Class Initialized
INFO - 2017-12-18 07:19:38 --> Model Class Initialized
INFO - 2017-12-18 07:19:38 --> Model Class Initialized
DEBUG - 2017-12-18 07:19:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-18 07:19:40 --> Config Class Initialized
INFO - 2017-12-18 07:19:40 --> Hooks Class Initialized
DEBUG - 2017-12-18 07:19:40 --> UTF-8 Support Enabled
INFO - 2017-12-18 07:19:40 --> Utf8 Class Initialized
INFO - 2017-12-18 07:19:40 --> URI Class Initialized
INFO - 2017-12-18 07:19:40 --> Router Class Initialized
INFO - 2017-12-18 07:19:40 --> Output Class Initialized
INFO - 2017-12-18 07:19:40 --> Security Class Initialized
DEBUG - 2017-12-18 07:19:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 07:19:40 --> Input Class Initialized
INFO - 2017-12-18 07:19:40 --> Language Class Initialized
INFO - 2017-12-18 07:19:40 --> Loader Class Initialized
INFO - 2017-12-18 07:19:40 --> Helper loaded: url_helper
INFO - 2017-12-18 07:19:40 --> Helper loaded: form_helper
INFO - 2017-12-18 07:19:40 --> Database Driver Class Initialized
DEBUG - 2017-12-18 07:19:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-18 07:19:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-18 07:19:40 --> Form Validation Class Initialized
INFO - 2017-12-18 07:19:40 --> Model Class Initialized
INFO - 2017-12-18 07:19:40 --> Controller Class Initialized
INFO - 2017-12-18 07:19:40 --> Model Class Initialized
INFO - 2017-12-18 07:19:40 --> Model Class Initialized
INFO - 2017-12-18 07:19:40 --> Model Class Initialized
DEBUG - 2017-12-18 07:19:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-18 07:19:40 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-18 07:19:40 --> Final output sent to browser
DEBUG - 2017-12-18 07:19:40 --> Total execution time: 0.0552
INFO - 2017-12-18 07:19:44 --> Config Class Initialized
INFO - 2017-12-18 07:19:44 --> Hooks Class Initialized
DEBUG - 2017-12-18 07:19:44 --> UTF-8 Support Enabled
INFO - 2017-12-18 07:19:44 --> Utf8 Class Initialized
INFO - 2017-12-18 07:19:44 --> URI Class Initialized
INFO - 2017-12-18 07:19:44 --> Router Class Initialized
INFO - 2017-12-18 07:19:44 --> Output Class Initialized
INFO - 2017-12-18 07:19:44 --> Security Class Initialized
DEBUG - 2017-12-18 07:19:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 07:19:44 --> Input Class Initialized
INFO - 2017-12-18 07:19:44 --> Language Class Initialized
INFO - 2017-12-18 07:19:44 --> Loader Class Initialized
INFO - 2017-12-18 07:19:44 --> Helper loaded: url_helper
INFO - 2017-12-18 07:19:44 --> Helper loaded: form_helper
INFO - 2017-12-18 07:19:44 --> Database Driver Class Initialized
DEBUG - 2017-12-18 07:19:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-18 07:19:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-18 07:19:44 --> Form Validation Class Initialized
INFO - 2017-12-18 07:19:44 --> Model Class Initialized
INFO - 2017-12-18 07:19:44 --> Controller Class Initialized
INFO - 2017-12-18 07:19:44 --> Model Class Initialized
INFO - 2017-12-18 07:19:44 --> Model Class Initialized
INFO - 2017-12-18 07:19:44 --> Model Class Initialized
DEBUG - 2017-12-18 07:19:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-18 07:19:44 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-18 07:19:44 --> Final output sent to browser
DEBUG - 2017-12-18 07:19:44 --> Total execution time: 0.0550
INFO - 2017-12-18 07:19:44 --> Config Class Initialized
INFO - 2017-12-18 07:19:44 --> Hooks Class Initialized
DEBUG - 2017-12-18 07:19:44 --> UTF-8 Support Enabled
INFO - 2017-12-18 07:19:44 --> Utf8 Class Initialized
INFO - 2017-12-18 07:19:44 --> URI Class Initialized
INFO - 2017-12-18 07:19:44 --> Router Class Initialized
INFO - 2017-12-18 07:19:44 --> Output Class Initialized
INFO - 2017-12-18 07:19:44 --> Security Class Initialized
DEBUG - 2017-12-18 07:19:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 07:19:44 --> Input Class Initialized
INFO - 2017-12-18 07:19:44 --> Language Class Initialized
INFO - 2017-12-18 07:19:44 --> Loader Class Initialized
INFO - 2017-12-18 07:19:44 --> Helper loaded: url_helper
INFO - 2017-12-18 07:19:44 --> Helper loaded: form_helper
INFO - 2017-12-18 07:19:44 --> Database Driver Class Initialized
DEBUG - 2017-12-18 07:19:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-18 07:19:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-18 07:19:44 --> Form Validation Class Initialized
INFO - 2017-12-18 07:19:44 --> Model Class Initialized
INFO - 2017-12-18 07:19:44 --> Controller Class Initialized
INFO - 2017-12-18 07:19:44 --> Model Class Initialized
INFO - 2017-12-18 07:19:44 --> Model Class Initialized
INFO - 2017-12-18 07:19:44 --> Model Class Initialized
DEBUG - 2017-12-18 07:19:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-18 07:19:46 --> Config Class Initialized
INFO - 2017-12-18 07:19:46 --> Hooks Class Initialized
DEBUG - 2017-12-18 07:19:46 --> UTF-8 Support Enabled
INFO - 2017-12-18 07:19:46 --> Utf8 Class Initialized
INFO - 2017-12-18 07:19:46 --> URI Class Initialized
INFO - 2017-12-18 07:19:46 --> Router Class Initialized
INFO - 2017-12-18 07:19:46 --> Output Class Initialized
INFO - 2017-12-18 07:19:46 --> Security Class Initialized
DEBUG - 2017-12-18 07:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 07:19:46 --> Input Class Initialized
INFO - 2017-12-18 07:19:46 --> Language Class Initialized
INFO - 2017-12-18 07:19:46 --> Loader Class Initialized
INFO - 2017-12-18 07:19:46 --> Helper loaded: url_helper
INFO - 2017-12-18 07:19:46 --> Helper loaded: form_helper
INFO - 2017-12-18 07:19:46 --> Database Driver Class Initialized
DEBUG - 2017-12-18 07:19:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-18 07:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-18 07:19:46 --> Form Validation Class Initialized
INFO - 2017-12-18 07:19:46 --> Model Class Initialized
INFO - 2017-12-18 07:19:46 --> Controller Class Initialized
INFO - 2017-12-18 07:19:46 --> Model Class Initialized
INFO - 2017-12-18 07:19:46 --> Model Class Initialized
INFO - 2017-12-18 07:19:46 --> Model Class Initialized
DEBUG - 2017-12-18 07:19:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-18 07:19:46 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-18 07:19:46 --> Final output sent to browser
DEBUG - 2017-12-18 07:19:46 --> Total execution time: 0.0557
INFO - 2017-12-18 07:19:46 --> Config Class Initialized
INFO - 2017-12-18 07:19:46 --> Hooks Class Initialized
INFO - 2017-12-18 07:19:46 --> Config Class Initialized
INFO - 2017-12-18 07:19:46 --> Hooks Class Initialized
DEBUG - 2017-12-18 07:19:46 --> UTF-8 Support Enabled
INFO - 2017-12-18 07:19:46 --> Utf8 Class Initialized
DEBUG - 2017-12-18 07:19:46 --> UTF-8 Support Enabled
INFO - 2017-12-18 07:19:46 --> Utf8 Class Initialized
INFO - 2017-12-18 07:19:46 --> URI Class Initialized
INFO - 2017-12-18 07:19:46 --> URI Class Initialized
INFO - 2017-12-18 07:19:46 --> Router Class Initialized
INFO - 2017-12-18 07:19:46 --> Router Class Initialized
INFO - 2017-12-18 07:19:46 --> Output Class Initialized
INFO - 2017-12-18 07:19:46 --> Output Class Initialized
INFO - 2017-12-18 07:19:46 --> Security Class Initialized
INFO - 2017-12-18 07:19:46 --> Security Class Initialized
DEBUG - 2017-12-18 07:19:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-18 07:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 07:19:46 --> Input Class Initialized
INFO - 2017-12-18 07:19:46 --> Input Class Initialized
INFO - 2017-12-18 07:19:46 --> Language Class Initialized
INFO - 2017-12-18 07:19:46 --> Language Class Initialized
INFO - 2017-12-18 07:19:46 --> Loader Class Initialized
INFO - 2017-12-18 07:19:46 --> Loader Class Initialized
INFO - 2017-12-18 07:19:46 --> Helper loaded: url_helper
INFO - 2017-12-18 07:19:46 --> Helper loaded: url_helper
INFO - 2017-12-18 07:19:46 --> Helper loaded: form_helper
INFO - 2017-12-18 07:19:46 --> Helper loaded: form_helper
INFO - 2017-12-18 07:19:46 --> Database Driver Class Initialized
INFO - 2017-12-18 07:19:46 --> Database Driver Class Initialized
DEBUG - 2017-12-18 07:19:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-18 07:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-18 07:19:46 --> Form Validation Class Initialized
DEBUG - 2017-12-18 07:19:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-18 07:19:46 --> Model Class Initialized
INFO - 2017-12-18 07:19:46 --> Controller Class Initialized
INFO - 2017-12-18 07:19:46 --> Model Class Initialized
INFO - 2017-12-18 07:19:46 --> Model Class Initialized
INFO - 2017-12-18 07:19:46 --> Model Class Initialized
DEBUG - 2017-12-18 07:19:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-18 07:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-18 07:19:46 --> Form Validation Class Initialized
INFO - 2017-12-18 07:19:46 --> Model Class Initialized
INFO - 2017-12-18 07:19:46 --> Controller Class Initialized
INFO - 2017-12-18 07:19:46 --> Model Class Initialized
INFO - 2017-12-18 07:19:46 --> Model Class Initialized
INFO - 2017-12-18 07:19:46 --> Model Class Initialized
DEBUG - 2017-12-18 07:19:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-18 07:19:48 --> Config Class Initialized
INFO - 2017-12-18 07:19:48 --> Hooks Class Initialized
DEBUG - 2017-12-18 07:19:48 --> UTF-8 Support Enabled
INFO - 2017-12-18 07:19:48 --> Utf8 Class Initialized
INFO - 2017-12-18 07:19:48 --> URI Class Initialized
INFO - 2017-12-18 07:19:48 --> Router Class Initialized
INFO - 2017-12-18 07:19:48 --> Output Class Initialized
INFO - 2017-12-18 07:19:48 --> Security Class Initialized
DEBUG - 2017-12-18 07:19:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 07:19:48 --> Input Class Initialized
INFO - 2017-12-18 07:19:48 --> Language Class Initialized
INFO - 2017-12-18 07:19:48 --> Loader Class Initialized
INFO - 2017-12-18 07:19:48 --> Helper loaded: url_helper
INFO - 2017-12-18 07:19:48 --> Helper loaded: form_helper
INFO - 2017-12-18 07:19:48 --> Database Driver Class Initialized
DEBUG - 2017-12-18 07:19:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-18 07:19:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-18 07:19:48 --> Form Validation Class Initialized
INFO - 2017-12-18 07:19:48 --> Model Class Initialized
INFO - 2017-12-18 07:19:48 --> Controller Class Initialized
INFO - 2017-12-18 07:19:48 --> Model Class Initialized
INFO - 2017-12-18 07:19:48 --> Model Class Initialized
INFO - 2017-12-18 07:19:48 --> Model Class Initialized
DEBUG - 2017-12-18 07:19:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-18 07:19:48 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-18 07:19:48 --> Final output sent to browser
DEBUG - 2017-12-18 07:19:48 --> Total execution time: 0.0533
INFO - 2017-12-18 07:19:48 --> Config Class Initialized
INFO - 2017-12-18 07:19:48 --> Hooks Class Initialized
DEBUG - 2017-12-18 07:19:48 --> UTF-8 Support Enabled
INFO - 2017-12-18 07:19:48 --> Utf8 Class Initialized
INFO - 2017-12-18 07:19:48 --> URI Class Initialized
INFO - 2017-12-18 07:19:48 --> Router Class Initialized
INFO - 2017-12-18 07:19:48 --> Output Class Initialized
INFO - 2017-12-18 07:19:48 --> Security Class Initialized
DEBUG - 2017-12-18 07:19:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 07:19:48 --> Input Class Initialized
INFO - 2017-12-18 07:19:48 --> Language Class Initialized
INFO - 2017-12-18 07:19:48 --> Loader Class Initialized
INFO - 2017-12-18 07:19:48 --> Helper loaded: url_helper
INFO - 2017-12-18 07:19:48 --> Helper loaded: form_helper
INFO - 2017-12-18 07:19:48 --> Database Driver Class Initialized
DEBUG - 2017-12-18 07:19:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-18 07:19:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-18 07:19:49 --> Form Validation Class Initialized
INFO - 2017-12-18 07:19:49 --> Model Class Initialized
INFO - 2017-12-18 07:19:49 --> Controller Class Initialized
INFO - 2017-12-18 07:19:49 --> Model Class Initialized
INFO - 2017-12-18 07:19:49 --> Model Class Initialized
INFO - 2017-12-18 07:19:49 --> Model Class Initialized
DEBUG - 2017-12-18 07:19:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-18 07:19:50 --> Config Class Initialized
INFO - 2017-12-18 07:19:50 --> Hooks Class Initialized
DEBUG - 2017-12-18 07:19:50 --> UTF-8 Support Enabled
INFO - 2017-12-18 07:19:50 --> Utf8 Class Initialized
INFO - 2017-12-18 07:19:50 --> URI Class Initialized
INFO - 2017-12-18 07:19:50 --> Router Class Initialized
INFO - 2017-12-18 07:19:50 --> Output Class Initialized
INFO - 2017-12-18 07:19:50 --> Security Class Initialized
DEBUG - 2017-12-18 07:19:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 07:19:50 --> Input Class Initialized
INFO - 2017-12-18 07:19:50 --> Language Class Initialized
INFO - 2017-12-18 07:19:50 --> Loader Class Initialized
INFO - 2017-12-18 07:19:50 --> Helper loaded: url_helper
INFO - 2017-12-18 07:19:50 --> Helper loaded: form_helper
INFO - 2017-12-18 07:19:50 --> Database Driver Class Initialized
DEBUG - 2017-12-18 07:19:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-18 07:19:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-18 07:19:50 --> Form Validation Class Initialized
INFO - 2017-12-18 07:19:50 --> Model Class Initialized
INFO - 2017-12-18 07:19:50 --> Controller Class Initialized
INFO - 2017-12-18 07:19:50 --> Model Class Initialized
INFO - 2017-12-18 07:19:50 --> Model Class Initialized
INFO - 2017-12-18 07:19:50 --> Model Class Initialized
DEBUG - 2017-12-18 07:19:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-18 07:19:50 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-18 07:19:50 --> Final output sent to browser
DEBUG - 2017-12-18 07:19:50 --> Total execution time: 0.0529
INFO - 2017-12-18 07:24:46 --> Config Class Initialized
INFO - 2017-12-18 07:24:46 --> Hooks Class Initialized
DEBUG - 2017-12-18 07:24:46 --> UTF-8 Support Enabled
INFO - 2017-12-18 07:24:46 --> Utf8 Class Initialized
INFO - 2017-12-18 07:24:46 --> URI Class Initialized
INFO - 2017-12-18 07:24:46 --> Router Class Initialized
INFO - 2017-12-18 07:24:46 --> Output Class Initialized
INFO - 2017-12-18 07:24:46 --> Security Class Initialized
DEBUG - 2017-12-18 07:24:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-18 07:24:46 --> Input Class Initialized
INFO - 2017-12-18 07:24:46 --> Language Class Initialized
INFO - 2017-12-18 07:24:46 --> Loader Class Initialized
INFO - 2017-12-18 07:24:46 --> Helper loaded: url_helper
INFO - 2017-12-18 07:24:46 --> Helper loaded: form_helper
INFO - 2017-12-18 07:24:46 --> Database Driver Class Initialized
DEBUG - 2017-12-18 07:24:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-18 07:24:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-18 07:24:46 --> Form Validation Class Initialized
INFO - 2017-12-18 07:24:46 --> Model Class Initialized
INFO - 2017-12-18 07:24:46 --> Controller Class Initialized
INFO - 2017-12-18 07:24:46 --> Model Class Initialized
INFO - 2017-12-18 07:24:46 --> Model Class Initialized
INFO - 2017-12-18 07:24:46 --> Model Class Initialized
DEBUG - 2017-12-18 07:24:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-18 07:24:46 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-18 07:24:46 --> Final output sent to browser
DEBUG - 2017-12-18 07:24:46 --> Total execution time: 0.1444
