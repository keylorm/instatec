<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-01-01 02:52:26 --> Config Class Initialized
INFO - 2018-01-01 02:52:26 --> Hooks Class Initialized
DEBUG - 2018-01-01 02:52:26 --> UTF-8 Support Enabled
INFO - 2018-01-01 02:52:26 --> Utf8 Class Initialized
INFO - 2018-01-01 02:52:26 --> URI Class Initialized
INFO - 2018-01-01 02:52:26 --> Router Class Initialized
INFO - 2018-01-01 02:52:26 --> Output Class Initialized
INFO - 2018-01-01 02:52:26 --> Security Class Initialized
DEBUG - 2018-01-01 02:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-01 02:52:26 --> Input Class Initialized
INFO - 2018-01-01 02:52:26 --> Language Class Initialized
INFO - 2018-01-01 02:52:26 --> Loader Class Initialized
INFO - 2018-01-01 02:52:26 --> Helper loaded: url_helper
INFO - 2018-01-01 02:52:26 --> Helper loaded: form_helper
INFO - 2018-01-01 02:52:26 --> Database Driver Class Initialized
DEBUG - 2018-01-01 02:52:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-01 02:52:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-01 02:52:26 --> Form Validation Class Initialized
INFO - 2018-01-01 02:52:26 --> Model Class Initialized
INFO - 2018-01-01 02:52:26 --> Controller Class Initialized
INFO - 2018-01-01 02:52:26 --> Model Class Initialized
INFO - 2018-01-01 02:52:26 --> Model Class Initialized
INFO - 2018-01-01 02:52:26 --> Model Class Initialized
INFO - 2018-01-01 02:52:26 --> Model Class Initialized
DEBUG - 2018-01-01 02:52:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-01 02:52:26 --> Config Class Initialized
INFO - 2018-01-01 02:52:26 --> Hooks Class Initialized
DEBUG - 2018-01-01 02:52:26 --> UTF-8 Support Enabled
INFO - 2018-01-01 02:52:26 --> Utf8 Class Initialized
INFO - 2018-01-01 02:52:26 --> URI Class Initialized
INFO - 2018-01-01 02:52:26 --> Router Class Initialized
INFO - 2018-01-01 02:52:26 --> Output Class Initialized
INFO - 2018-01-01 02:52:26 --> Security Class Initialized
DEBUG - 2018-01-01 02:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-01 02:52:26 --> Input Class Initialized
INFO - 2018-01-01 02:52:26 --> Language Class Initialized
INFO - 2018-01-01 02:52:26 --> Config Class Initialized
INFO - 2018-01-01 02:52:26 --> Hooks Class Initialized
INFO - 2018-01-01 02:52:26 --> Loader Class Initialized
DEBUG - 2018-01-01 02:52:26 --> UTF-8 Support Enabled
INFO - 2018-01-01 02:52:26 --> Helper loaded: url_helper
INFO - 2018-01-01 02:52:26 --> Utf8 Class Initialized
INFO - 2018-01-01 02:52:26 --> URI Class Initialized
INFO - 2018-01-01 02:52:26 --> Helper loaded: form_helper
INFO - 2018-01-01 02:52:26 --> Router Class Initialized
INFO - 2018-01-01 02:52:26 --> Output Class Initialized
INFO - 2018-01-01 02:52:26 --> Security Class Initialized
INFO - 2018-01-01 02:52:26 --> Database Driver Class Initialized
DEBUG - 2018-01-01 02:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-01 02:52:26 --> Input Class Initialized
INFO - 2018-01-01 02:52:26 --> Language Class Initialized
ERROR - 2018-01-01 02:52:26 --> 404 Page Not Found: Faviconico/index
DEBUG - 2018-01-01 02:52:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-01 02:52:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-01 02:52:26 --> Form Validation Class Initialized
INFO - 2018-01-01 02:52:26 --> Model Class Initialized
INFO - 2018-01-01 02:52:26 --> Controller Class Initialized
INFO - 2018-01-01 02:52:26 --> Model Class Initialized
DEBUG - 2018-01-01 02:52:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-01 02:52:26 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-01 02:52:26 --> Final output sent to browser
DEBUG - 2018-01-01 02:52:26 --> Total execution time: 0.0433
