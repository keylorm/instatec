<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-02-06 06:05:28 --> Config Class Initialized
INFO - 2018-02-06 06:05:28 --> Hooks Class Initialized
DEBUG - 2018-02-06 06:05:28 --> UTF-8 Support Enabled
INFO - 2018-02-06 06:05:28 --> Utf8 Class Initialized
INFO - 2018-02-06 06:05:28 --> URI Class Initialized
INFO - 2018-02-06 06:05:28 --> Router Class Initialized
INFO - 2018-02-06 06:05:28 --> Output Class Initialized
INFO - 2018-02-06 06:05:28 --> Security Class Initialized
DEBUG - 2018-02-06 06:05:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 06:05:28 --> Input Class Initialized
INFO - 2018-02-06 06:05:28 --> Language Class Initialized
INFO - 2018-02-06 06:05:28 --> Loader Class Initialized
INFO - 2018-02-06 06:05:28 --> Helper loaded: url_helper
INFO - 2018-02-06 06:05:28 --> Helper loaded: form_helper
INFO - 2018-02-06 06:05:28 --> Database Driver Class Initialized
DEBUG - 2018-02-06 06:05:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 06:05:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 06:05:28 --> Form Validation Class Initialized
INFO - 2018-02-06 06:05:28 --> Model Class Initialized
INFO - 2018-02-06 06:05:28 --> Controller Class Initialized
INFO - 2018-02-06 06:05:28 --> Model Class Initialized
DEBUG - 2018-02-06 06:05:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 06:05:28 --> Config Class Initialized
INFO - 2018-02-06 06:05:28 --> Hooks Class Initialized
DEBUG - 2018-02-06 06:05:28 --> UTF-8 Support Enabled
INFO - 2018-02-06 06:05:28 --> Utf8 Class Initialized
INFO - 2018-02-06 06:05:28 --> URI Class Initialized
INFO - 2018-02-06 06:05:28 --> Router Class Initialized
INFO - 2018-02-06 06:05:28 --> Output Class Initialized
INFO - 2018-02-06 06:05:28 --> Security Class Initialized
DEBUG - 2018-02-06 06:05:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 06:05:28 --> Input Class Initialized
INFO - 2018-02-06 06:05:28 --> Language Class Initialized
INFO - 2018-02-06 06:05:28 --> Loader Class Initialized
INFO - 2018-02-06 06:05:28 --> Helper loaded: url_helper
INFO - 2018-02-06 06:05:28 --> Helper loaded: form_helper
INFO - 2018-02-06 06:05:28 --> Database Driver Class Initialized
DEBUG - 2018-02-06 06:05:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 06:05:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 06:05:28 --> Form Validation Class Initialized
INFO - 2018-02-06 06:05:28 --> Model Class Initialized
INFO - 2018-02-06 06:05:28 --> Controller Class Initialized
INFO - 2018-02-06 06:05:28 --> Model Class Initialized
DEBUG - 2018-02-06 06:05:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 06:05:28 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 06:05:28 --> Final output sent to browser
DEBUG - 2018-02-06 06:05:28 --> Total execution time: 0.0536
INFO - 2018-02-06 06:05:30 --> Config Class Initialized
INFO - 2018-02-06 06:05:30 --> Hooks Class Initialized
DEBUG - 2018-02-06 06:05:30 --> UTF-8 Support Enabled
INFO - 2018-02-06 06:05:30 --> Utf8 Class Initialized
INFO - 2018-02-06 06:05:30 --> URI Class Initialized
INFO - 2018-02-06 06:05:30 --> Router Class Initialized
INFO - 2018-02-06 06:05:30 --> Output Class Initialized
INFO - 2018-02-06 06:05:30 --> Security Class Initialized
DEBUG - 2018-02-06 06:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 06:05:30 --> Input Class Initialized
INFO - 2018-02-06 06:05:30 --> Language Class Initialized
INFO - 2018-02-06 06:05:30 --> Loader Class Initialized
INFO - 2018-02-06 06:05:30 --> Helper loaded: url_helper
INFO - 2018-02-06 06:05:30 --> Helper loaded: form_helper
INFO - 2018-02-06 06:05:30 --> Database Driver Class Initialized
DEBUG - 2018-02-06 06:05:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 06:05:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 06:05:30 --> Form Validation Class Initialized
INFO - 2018-02-06 06:05:30 --> Model Class Initialized
INFO - 2018-02-06 06:05:30 --> Controller Class Initialized
INFO - 2018-02-06 06:05:30 --> Model Class Initialized
DEBUG - 2018-02-06 06:05:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 06:05:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-06 06:05:30 --> Config Class Initialized
INFO - 2018-02-06 06:05:30 --> Hooks Class Initialized
DEBUG - 2018-02-06 06:05:30 --> UTF-8 Support Enabled
INFO - 2018-02-06 06:05:30 --> Utf8 Class Initialized
INFO - 2018-02-06 06:05:30 --> URI Class Initialized
DEBUG - 2018-02-06 06:05:30 --> No URI present. Default controller set.
INFO - 2018-02-06 06:05:30 --> Router Class Initialized
INFO - 2018-02-06 06:05:30 --> Output Class Initialized
INFO - 2018-02-06 06:05:30 --> Security Class Initialized
DEBUG - 2018-02-06 06:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 06:05:30 --> Input Class Initialized
INFO - 2018-02-06 06:05:30 --> Language Class Initialized
INFO - 2018-02-06 06:05:30 --> Loader Class Initialized
INFO - 2018-02-06 06:05:30 --> Helper loaded: url_helper
INFO - 2018-02-06 06:05:30 --> Helper loaded: form_helper
INFO - 2018-02-06 06:05:30 --> Database Driver Class Initialized
DEBUG - 2018-02-06 06:05:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 06:05:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 06:05:30 --> Form Validation Class Initialized
INFO - 2018-02-06 06:05:30 --> Model Class Initialized
INFO - 2018-02-06 06:05:30 --> Controller Class Initialized
INFO - 2018-02-06 06:05:30 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 06:05:30 --> Final output sent to browser
DEBUG - 2018-02-06 06:05:30 --> Total execution time: 0.0454
INFO - 2018-02-06 06:05:30 --> Config Class Initialized
INFO - 2018-02-06 06:05:30 --> Hooks Class Initialized
DEBUG - 2018-02-06 06:05:30 --> UTF-8 Support Enabled
INFO - 2018-02-06 06:05:30 --> Utf8 Class Initialized
INFO - 2018-02-06 06:05:30 --> URI Class Initialized
INFO - 2018-02-06 06:05:30 --> Router Class Initialized
INFO - 2018-02-06 06:05:30 --> Output Class Initialized
INFO - 2018-02-06 06:05:30 --> Security Class Initialized
DEBUG - 2018-02-06 06:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 06:05:30 --> Input Class Initialized
INFO - 2018-02-06 06:05:30 --> Language Class Initialized
INFO - 2018-02-06 06:05:30 --> Loader Class Initialized
INFO - 2018-02-06 06:05:30 --> Helper loaded: url_helper
INFO - 2018-02-06 06:05:30 --> Helper loaded: form_helper
INFO - 2018-02-06 06:05:30 --> Database Driver Class Initialized
DEBUG - 2018-02-06 06:05:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 06:05:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 06:05:30 --> Form Validation Class Initialized
INFO - 2018-02-06 06:05:30 --> Model Class Initialized
INFO - 2018-02-06 06:05:30 --> Controller Class Initialized
INFO - 2018-02-06 06:05:30 --> Model Class Initialized
INFO - 2018-02-06 06:05:30 --> Model Class Initialized
INFO - 2018-02-06 06:05:30 --> Model Class Initialized
INFO - 2018-02-06 06:05:30 --> Model Class Initialized
DEBUG - 2018-02-06 06:05:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 06:05:32 --> Config Class Initialized
INFO - 2018-02-06 06:05:32 --> Hooks Class Initialized
DEBUG - 2018-02-06 06:05:32 --> UTF-8 Support Enabled
INFO - 2018-02-06 06:05:32 --> Utf8 Class Initialized
INFO - 2018-02-06 06:05:32 --> URI Class Initialized
INFO - 2018-02-06 06:05:32 --> Router Class Initialized
INFO - 2018-02-06 06:05:32 --> Output Class Initialized
INFO - 2018-02-06 06:05:32 --> Security Class Initialized
DEBUG - 2018-02-06 06:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 06:05:32 --> Input Class Initialized
INFO - 2018-02-06 06:05:32 --> Language Class Initialized
INFO - 2018-02-06 06:05:32 --> Loader Class Initialized
INFO - 2018-02-06 06:05:32 --> Helper loaded: url_helper
INFO - 2018-02-06 06:05:32 --> Helper loaded: form_helper
INFO - 2018-02-06 06:05:32 --> Database Driver Class Initialized
DEBUG - 2018-02-06 06:05:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 06:05:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 06:05:32 --> Form Validation Class Initialized
INFO - 2018-02-06 06:05:32 --> Model Class Initialized
INFO - 2018-02-06 06:05:32 --> Controller Class Initialized
INFO - 2018-02-06 06:05:32 --> Model Class Initialized
DEBUG - 2018-02-06 06:05:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 06:05:32 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 06:05:32 --> Final output sent to browser
DEBUG - 2018-02-06 06:05:32 --> Total execution time: 0.0398
INFO - 2018-02-06 06:05:32 --> Config Class Initialized
INFO - 2018-02-06 06:05:32 --> Hooks Class Initialized
DEBUG - 2018-02-06 06:05:32 --> UTF-8 Support Enabled
INFO - 2018-02-06 06:05:32 --> Utf8 Class Initialized
INFO - 2018-02-06 06:05:32 --> URI Class Initialized
INFO - 2018-02-06 06:05:32 --> Router Class Initialized
INFO - 2018-02-06 06:05:32 --> Output Class Initialized
INFO - 2018-02-06 06:05:32 --> Security Class Initialized
DEBUG - 2018-02-06 06:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 06:05:32 --> Input Class Initialized
INFO - 2018-02-06 06:05:32 --> Language Class Initialized
INFO - 2018-02-06 06:05:32 --> Loader Class Initialized
INFO - 2018-02-06 06:05:32 --> Helper loaded: url_helper
INFO - 2018-02-06 06:05:32 --> Helper loaded: form_helper
INFO - 2018-02-06 06:05:32 --> Database Driver Class Initialized
DEBUG - 2018-02-06 06:05:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 06:05:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 06:05:32 --> Form Validation Class Initialized
INFO - 2018-02-06 06:05:32 --> Model Class Initialized
INFO - 2018-02-06 06:05:32 --> Controller Class Initialized
INFO - 2018-02-06 06:05:32 --> Model Class Initialized
DEBUG - 2018-02-06 06:05:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 06:05:33 --> Config Class Initialized
INFO - 2018-02-06 06:05:33 --> Hooks Class Initialized
DEBUG - 2018-02-06 06:05:33 --> UTF-8 Support Enabled
INFO - 2018-02-06 06:05:33 --> Utf8 Class Initialized
INFO - 2018-02-06 06:05:33 --> URI Class Initialized
INFO - 2018-02-06 06:05:33 --> Router Class Initialized
INFO - 2018-02-06 06:05:33 --> Output Class Initialized
INFO - 2018-02-06 06:05:33 --> Security Class Initialized
DEBUG - 2018-02-06 06:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 06:05:33 --> Input Class Initialized
INFO - 2018-02-06 06:05:33 --> Language Class Initialized
INFO - 2018-02-06 06:05:33 --> Loader Class Initialized
INFO - 2018-02-06 06:05:33 --> Helper loaded: url_helper
INFO - 2018-02-06 06:05:33 --> Helper loaded: form_helper
INFO - 2018-02-06 06:05:33 --> Database Driver Class Initialized
DEBUG - 2018-02-06 06:05:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 06:05:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 06:05:33 --> Form Validation Class Initialized
INFO - 2018-02-06 06:05:33 --> Model Class Initialized
INFO - 2018-02-06 06:05:33 --> Controller Class Initialized
INFO - 2018-02-06 06:05:33 --> Model Class Initialized
DEBUG - 2018-02-06 06:05:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 06:05:33 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 06:05:33 --> Final output sent to browser
DEBUG - 2018-02-06 06:05:33 --> Total execution time: 0.0385
INFO - 2018-02-06 06:05:33 --> Config Class Initialized
INFO - 2018-02-06 06:05:33 --> Hooks Class Initialized
DEBUG - 2018-02-06 06:05:33 --> UTF-8 Support Enabled
INFO - 2018-02-06 06:05:33 --> Utf8 Class Initialized
INFO - 2018-02-06 06:05:33 --> URI Class Initialized
INFO - 2018-02-06 06:05:33 --> Router Class Initialized
INFO - 2018-02-06 06:05:33 --> Output Class Initialized
INFO - 2018-02-06 06:05:33 --> Security Class Initialized
DEBUG - 2018-02-06 06:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 06:05:33 --> Input Class Initialized
INFO - 2018-02-06 06:05:33 --> Language Class Initialized
INFO - 2018-02-06 06:05:33 --> Loader Class Initialized
INFO - 2018-02-06 06:05:33 --> Helper loaded: url_helper
INFO - 2018-02-06 06:05:33 --> Helper loaded: form_helper
INFO - 2018-02-06 06:05:33 --> Database Driver Class Initialized
DEBUG - 2018-02-06 06:05:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 06:05:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 06:05:33 --> Form Validation Class Initialized
INFO - 2018-02-06 06:05:33 --> Model Class Initialized
INFO - 2018-02-06 06:05:33 --> Controller Class Initialized
INFO - 2018-02-06 06:05:33 --> Model Class Initialized
DEBUG - 2018-02-06 06:05:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 06:05:35 --> Config Class Initialized
INFO - 2018-02-06 06:05:35 --> Hooks Class Initialized
DEBUG - 2018-02-06 06:05:35 --> UTF-8 Support Enabled
INFO - 2018-02-06 06:05:35 --> Utf8 Class Initialized
INFO - 2018-02-06 06:05:35 --> URI Class Initialized
INFO - 2018-02-06 06:05:35 --> Router Class Initialized
INFO - 2018-02-06 06:05:35 --> Output Class Initialized
INFO - 2018-02-06 06:05:35 --> Security Class Initialized
DEBUG - 2018-02-06 06:05:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 06:05:35 --> Input Class Initialized
INFO - 2018-02-06 06:05:35 --> Language Class Initialized
INFO - 2018-02-06 06:05:35 --> Loader Class Initialized
INFO - 2018-02-06 06:05:35 --> Helper loaded: url_helper
INFO - 2018-02-06 06:05:35 --> Helper loaded: form_helper
INFO - 2018-02-06 06:05:35 --> Database Driver Class Initialized
DEBUG - 2018-02-06 06:05:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 06:05:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 06:05:35 --> Form Validation Class Initialized
INFO - 2018-02-06 06:05:35 --> Model Class Initialized
INFO - 2018-02-06 06:05:35 --> Controller Class Initialized
INFO - 2018-02-06 06:05:35 --> Model Class Initialized
DEBUG - 2018-02-06 06:05:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 06:05:35 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 06:05:35 --> Final output sent to browser
DEBUG - 2018-02-06 06:05:35 --> Total execution time: 0.0414
INFO - 2018-02-06 06:06:11 --> Config Class Initialized
INFO - 2018-02-06 06:06:11 --> Hooks Class Initialized
DEBUG - 2018-02-06 06:06:11 --> UTF-8 Support Enabled
INFO - 2018-02-06 06:06:11 --> Utf8 Class Initialized
INFO - 2018-02-06 06:06:11 --> URI Class Initialized
INFO - 2018-02-06 06:06:11 --> Router Class Initialized
INFO - 2018-02-06 06:06:11 --> Output Class Initialized
INFO - 2018-02-06 06:06:11 --> Security Class Initialized
DEBUG - 2018-02-06 06:06:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 06:06:11 --> Input Class Initialized
INFO - 2018-02-06 06:06:11 --> Language Class Initialized
INFO - 2018-02-06 06:06:11 --> Loader Class Initialized
INFO - 2018-02-06 06:06:11 --> Helper loaded: url_helper
INFO - 2018-02-06 06:06:11 --> Helper loaded: form_helper
INFO - 2018-02-06 06:06:11 --> Database Driver Class Initialized
DEBUG - 2018-02-06 06:06:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 06:06:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 06:06:11 --> Form Validation Class Initialized
INFO - 2018-02-06 06:06:11 --> Model Class Initialized
INFO - 2018-02-06 06:06:11 --> Controller Class Initialized
INFO - 2018-02-06 06:06:11 --> Model Class Initialized
DEBUG - 2018-02-06 06:06:11 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 06:06:11 --> Query error: Unknown column 'estado_id' in 'field list' - Invalid query: INSERT INTO `colaborador` (`nombre`, `apellidos`, `cedula`, `correo_electronico`, `telefono`, `seguro_social`, `identificador_interno`, `colaborador_puesto_id`, `estado_id`, `estado_cliente`, `estado_row`, `fecha_registro`) VALUES ('Carlos', 'Mora', '302550556', 'carlos@instateccr.com', '6516548', '75345345', '10', '2', '1', 1, 1, '2018-02-06 06:06:11')
INFO - 2018-02-06 06:06:12 --> Language file loaded: language/english/db_lang.php
INFO - 2018-02-06 06:07:30 --> Config Class Initialized
INFO - 2018-02-06 06:07:30 --> Hooks Class Initialized
DEBUG - 2018-02-06 06:07:30 --> UTF-8 Support Enabled
INFO - 2018-02-06 06:07:30 --> Utf8 Class Initialized
INFO - 2018-02-06 06:07:30 --> URI Class Initialized
INFO - 2018-02-06 06:07:30 --> Router Class Initialized
INFO - 2018-02-06 06:07:30 --> Output Class Initialized
INFO - 2018-02-06 06:07:30 --> Security Class Initialized
DEBUG - 2018-02-06 06:07:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 06:07:30 --> Input Class Initialized
INFO - 2018-02-06 06:07:30 --> Language Class Initialized
INFO - 2018-02-06 06:07:30 --> Loader Class Initialized
INFO - 2018-02-06 06:07:30 --> Helper loaded: url_helper
INFO - 2018-02-06 06:07:30 --> Helper loaded: form_helper
INFO - 2018-02-06 06:07:30 --> Database Driver Class Initialized
DEBUG - 2018-02-06 06:07:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 06:07:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 06:07:30 --> Form Validation Class Initialized
INFO - 2018-02-06 06:07:30 --> Model Class Initialized
INFO - 2018-02-06 06:07:30 --> Controller Class Initialized
INFO - 2018-02-06 06:07:30 --> Model Class Initialized
DEBUG - 2018-02-06 06:07:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 06:07:30 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 06:07:30 --> Final output sent to browser
DEBUG - 2018-02-06 06:07:30 --> Total execution time: 0.0463
INFO - 2018-02-06 06:07:39 --> Config Class Initialized
INFO - 2018-02-06 06:07:39 --> Hooks Class Initialized
DEBUG - 2018-02-06 06:07:39 --> UTF-8 Support Enabled
INFO - 2018-02-06 06:07:39 --> Utf8 Class Initialized
INFO - 2018-02-06 06:07:39 --> URI Class Initialized
INFO - 2018-02-06 06:07:39 --> Router Class Initialized
INFO - 2018-02-06 06:07:39 --> Output Class Initialized
INFO - 2018-02-06 06:07:39 --> Security Class Initialized
DEBUG - 2018-02-06 06:07:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 06:07:39 --> Input Class Initialized
INFO - 2018-02-06 06:07:39 --> Language Class Initialized
INFO - 2018-02-06 06:07:39 --> Loader Class Initialized
INFO - 2018-02-06 06:07:39 --> Helper loaded: url_helper
INFO - 2018-02-06 06:07:39 --> Helper loaded: form_helper
INFO - 2018-02-06 06:07:39 --> Database Driver Class Initialized
DEBUG - 2018-02-06 06:07:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 06:07:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 06:07:39 --> Form Validation Class Initialized
INFO - 2018-02-06 06:07:39 --> Model Class Initialized
INFO - 2018-02-06 06:07:39 --> Controller Class Initialized
INFO - 2018-02-06 06:07:39 --> Model Class Initialized
DEBUG - 2018-02-06 06:07:39 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 06:07:39 --> Query error: Unknown column 'estado_cliente' in 'field list' - Invalid query: INSERT INTO `colaborador` (`nombre`, `apellidos`, `cedula`, `correo_electronico`, `telefono`, `seguro_social`, `identificador_interno`, `colaborador_puesto_id`, `estado`, `estado_cliente`, `estado_row`, `fecha_registro`) VALUES ('Carlos', 'Mora', '302550556', 'carlos@instateccr.com', '6516516', '75345345', '10', '2', '1', 1, 1, '2018-02-06 06:07:39')
INFO - 2018-02-06 06:07:39 --> Language file loaded: language/english/db_lang.php
INFO - 2018-02-06 06:08:30 --> Config Class Initialized
INFO - 2018-02-06 06:08:30 --> Hooks Class Initialized
DEBUG - 2018-02-06 06:08:30 --> UTF-8 Support Enabled
INFO - 2018-02-06 06:08:30 --> Utf8 Class Initialized
INFO - 2018-02-06 06:08:30 --> URI Class Initialized
INFO - 2018-02-06 06:08:30 --> Router Class Initialized
INFO - 2018-02-06 06:08:30 --> Output Class Initialized
INFO - 2018-02-06 06:08:30 --> Security Class Initialized
DEBUG - 2018-02-06 06:08:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 06:08:30 --> Input Class Initialized
INFO - 2018-02-06 06:08:30 --> Language Class Initialized
INFO - 2018-02-06 06:08:30 --> Loader Class Initialized
INFO - 2018-02-06 06:08:30 --> Helper loaded: url_helper
INFO - 2018-02-06 06:08:30 --> Helper loaded: form_helper
INFO - 2018-02-06 06:08:30 --> Database Driver Class Initialized
DEBUG - 2018-02-06 06:08:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 06:08:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 06:08:30 --> Form Validation Class Initialized
INFO - 2018-02-06 06:08:30 --> Model Class Initialized
INFO - 2018-02-06 06:08:30 --> Controller Class Initialized
INFO - 2018-02-06 06:08:30 --> Model Class Initialized
DEBUG - 2018-02-06 06:08:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 06:08:30 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 06:08:30 --> Final output sent to browser
DEBUG - 2018-02-06 06:08:30 --> Total execution time: 0.1399
INFO - 2018-02-06 06:08:34 --> Config Class Initialized
INFO - 2018-02-06 06:08:34 --> Hooks Class Initialized
DEBUG - 2018-02-06 06:08:34 --> UTF-8 Support Enabled
INFO - 2018-02-06 06:08:34 --> Utf8 Class Initialized
INFO - 2018-02-06 06:08:34 --> URI Class Initialized
INFO - 2018-02-06 06:08:34 --> Router Class Initialized
INFO - 2018-02-06 06:08:34 --> Output Class Initialized
INFO - 2018-02-06 06:08:34 --> Security Class Initialized
DEBUG - 2018-02-06 06:08:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 06:08:34 --> Input Class Initialized
INFO - 2018-02-06 06:08:34 --> Language Class Initialized
INFO - 2018-02-06 06:08:34 --> Loader Class Initialized
INFO - 2018-02-06 06:08:34 --> Helper loaded: url_helper
INFO - 2018-02-06 06:08:34 --> Helper loaded: form_helper
INFO - 2018-02-06 06:08:34 --> Database Driver Class Initialized
DEBUG - 2018-02-06 06:08:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 06:08:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 06:08:34 --> Form Validation Class Initialized
INFO - 2018-02-06 06:08:34 --> Model Class Initialized
INFO - 2018-02-06 06:08:34 --> Controller Class Initialized
INFO - 2018-02-06 06:08:34 --> Model Class Initialized
DEBUG - 2018-02-06 06:08:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 06:08:34 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 06:08:34 --> Final output sent to browser
DEBUG - 2018-02-06 06:08:34 --> Total execution time: 0.0510
INFO - 2018-02-06 06:08:34 --> Config Class Initialized
INFO - 2018-02-06 06:08:34 --> Hooks Class Initialized
DEBUG - 2018-02-06 06:08:34 --> UTF-8 Support Enabled
INFO - 2018-02-06 06:08:34 --> Utf8 Class Initialized
INFO - 2018-02-06 06:08:34 --> URI Class Initialized
INFO - 2018-02-06 06:08:34 --> Router Class Initialized
INFO - 2018-02-06 06:08:34 --> Output Class Initialized
INFO - 2018-02-06 06:08:34 --> Security Class Initialized
DEBUG - 2018-02-06 06:08:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 06:08:34 --> Input Class Initialized
INFO - 2018-02-06 06:08:34 --> Language Class Initialized
INFO - 2018-02-06 06:08:34 --> Loader Class Initialized
INFO - 2018-02-06 06:08:34 --> Helper loaded: url_helper
INFO - 2018-02-06 06:08:34 --> Helper loaded: form_helper
INFO - 2018-02-06 06:08:34 --> Database Driver Class Initialized
DEBUG - 2018-02-06 06:08:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 06:08:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 06:08:34 --> Form Validation Class Initialized
INFO - 2018-02-06 06:08:34 --> Model Class Initialized
INFO - 2018-02-06 06:08:34 --> Controller Class Initialized
INFO - 2018-02-06 06:08:34 --> Model Class Initialized
DEBUG - 2018-02-06 06:08:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 06:09:55 --> Config Class Initialized
INFO - 2018-02-06 06:09:55 --> Hooks Class Initialized
DEBUG - 2018-02-06 06:09:55 --> UTF-8 Support Enabled
INFO - 2018-02-06 06:09:55 --> Utf8 Class Initialized
INFO - 2018-02-06 06:09:55 --> URI Class Initialized
INFO - 2018-02-06 06:09:55 --> Router Class Initialized
INFO - 2018-02-06 06:09:55 --> Output Class Initialized
INFO - 2018-02-06 06:09:55 --> Security Class Initialized
DEBUG - 2018-02-06 06:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 06:09:55 --> Input Class Initialized
INFO - 2018-02-06 06:09:55 --> Language Class Initialized
INFO - 2018-02-06 06:09:55 --> Loader Class Initialized
INFO - 2018-02-06 06:09:55 --> Helper loaded: url_helper
INFO - 2018-02-06 06:09:55 --> Helper loaded: form_helper
INFO - 2018-02-06 06:09:55 --> Database Driver Class Initialized
DEBUG - 2018-02-06 06:09:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 06:09:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 06:09:55 --> Form Validation Class Initialized
INFO - 2018-02-06 06:09:55 --> Model Class Initialized
INFO - 2018-02-06 06:09:55 --> Controller Class Initialized
INFO - 2018-02-06 06:09:55 --> Model Class Initialized
DEBUG - 2018-02-06 06:09:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 06:09:55 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 06:09:55 --> Final output sent to browser
DEBUG - 2018-02-06 06:09:55 --> Total execution time: 0.0530
INFO - 2018-02-06 06:10:21 --> Config Class Initialized
INFO - 2018-02-06 06:10:21 --> Hooks Class Initialized
DEBUG - 2018-02-06 06:10:21 --> UTF-8 Support Enabled
INFO - 2018-02-06 06:10:21 --> Utf8 Class Initialized
INFO - 2018-02-06 06:10:21 --> URI Class Initialized
INFO - 2018-02-06 06:10:21 --> Router Class Initialized
INFO - 2018-02-06 06:10:21 --> Output Class Initialized
INFO - 2018-02-06 06:10:21 --> Security Class Initialized
DEBUG - 2018-02-06 06:10:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 06:10:21 --> Input Class Initialized
INFO - 2018-02-06 06:10:21 --> Language Class Initialized
INFO - 2018-02-06 06:10:21 --> Loader Class Initialized
INFO - 2018-02-06 06:10:21 --> Helper loaded: url_helper
INFO - 2018-02-06 06:10:21 --> Helper loaded: form_helper
INFO - 2018-02-06 06:10:21 --> Database Driver Class Initialized
DEBUG - 2018-02-06 06:10:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 06:10:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 06:10:21 --> Form Validation Class Initialized
INFO - 2018-02-06 06:10:21 --> Model Class Initialized
INFO - 2018-02-06 06:10:21 --> Controller Class Initialized
INFO - 2018-02-06 06:10:21 --> Model Class Initialized
DEBUG - 2018-02-06 06:10:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 06:10:22 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 06:10:22 --> Final output sent to browser
DEBUG - 2018-02-06 06:10:22 --> Total execution time: 0.4171
INFO - 2018-02-06 06:10:24 --> Config Class Initialized
INFO - 2018-02-06 06:10:24 --> Hooks Class Initialized
DEBUG - 2018-02-06 06:10:24 --> UTF-8 Support Enabled
INFO - 2018-02-06 06:10:24 --> Utf8 Class Initialized
INFO - 2018-02-06 06:10:24 --> URI Class Initialized
INFO - 2018-02-06 06:10:24 --> Router Class Initialized
INFO - 2018-02-06 06:10:24 --> Output Class Initialized
INFO - 2018-02-06 06:10:24 --> Security Class Initialized
DEBUG - 2018-02-06 06:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 06:10:24 --> Input Class Initialized
INFO - 2018-02-06 06:10:24 --> Language Class Initialized
INFO - 2018-02-06 06:10:24 --> Loader Class Initialized
INFO - 2018-02-06 06:10:24 --> Helper loaded: url_helper
INFO - 2018-02-06 06:10:24 --> Helper loaded: form_helper
INFO - 2018-02-06 06:10:24 --> Database Driver Class Initialized
DEBUG - 2018-02-06 06:10:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 06:10:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 06:10:24 --> Form Validation Class Initialized
INFO - 2018-02-06 06:10:24 --> Model Class Initialized
INFO - 2018-02-06 06:10:24 --> Controller Class Initialized
INFO - 2018-02-06 06:10:24 --> Model Class Initialized
DEBUG - 2018-02-06 06:10:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 06:10:24 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 06:10:24 --> Final output sent to browser
DEBUG - 2018-02-06 06:10:24 --> Total execution time: 0.0502
INFO - 2018-02-06 06:10:24 --> Config Class Initialized
INFO - 2018-02-06 06:10:24 --> Hooks Class Initialized
DEBUG - 2018-02-06 06:10:24 --> UTF-8 Support Enabled
INFO - 2018-02-06 06:10:24 --> Utf8 Class Initialized
INFO - 2018-02-06 06:10:24 --> URI Class Initialized
INFO - 2018-02-06 06:10:24 --> Router Class Initialized
INFO - 2018-02-06 06:10:24 --> Output Class Initialized
INFO - 2018-02-06 06:10:24 --> Security Class Initialized
DEBUG - 2018-02-06 06:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 06:10:24 --> Input Class Initialized
INFO - 2018-02-06 06:10:24 --> Language Class Initialized
INFO - 2018-02-06 06:10:24 --> Loader Class Initialized
INFO - 2018-02-06 06:10:24 --> Helper loaded: url_helper
INFO - 2018-02-06 06:10:24 --> Helper loaded: form_helper
INFO - 2018-02-06 06:10:24 --> Database Driver Class Initialized
DEBUG - 2018-02-06 06:10:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 06:10:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 06:10:24 --> Form Validation Class Initialized
INFO - 2018-02-06 06:10:24 --> Model Class Initialized
INFO - 2018-02-06 06:10:24 --> Controller Class Initialized
INFO - 2018-02-06 06:10:24 --> Model Class Initialized
DEBUG - 2018-02-06 06:10:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 06:10:32 --> Config Class Initialized
INFO - 2018-02-06 06:10:32 --> Hooks Class Initialized
DEBUG - 2018-02-06 06:10:32 --> UTF-8 Support Enabled
INFO - 2018-02-06 06:10:32 --> Utf8 Class Initialized
INFO - 2018-02-06 06:10:32 --> URI Class Initialized
INFO - 2018-02-06 06:10:32 --> Router Class Initialized
INFO - 2018-02-06 06:10:32 --> Output Class Initialized
INFO - 2018-02-06 06:10:32 --> Security Class Initialized
DEBUG - 2018-02-06 06:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 06:10:32 --> Input Class Initialized
INFO - 2018-02-06 06:10:32 --> Language Class Initialized
INFO - 2018-02-06 06:10:32 --> Loader Class Initialized
INFO - 2018-02-06 06:10:32 --> Helper loaded: url_helper
INFO - 2018-02-06 06:10:32 --> Helper loaded: form_helper
INFO - 2018-02-06 06:10:32 --> Database Driver Class Initialized
DEBUG - 2018-02-06 06:10:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 06:10:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 06:10:32 --> Form Validation Class Initialized
INFO - 2018-02-06 06:10:32 --> Model Class Initialized
INFO - 2018-02-06 06:10:32 --> Controller Class Initialized
INFO - 2018-02-06 06:10:32 --> Model Class Initialized
DEBUG - 2018-02-06 06:10:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 06:10:32 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 06:10:32 --> Final output sent to browser
DEBUG - 2018-02-06 06:10:32 --> Total execution time: 0.0376
INFO - 2018-02-06 06:10:32 --> Config Class Initialized
INFO - 2018-02-06 06:10:32 --> Hooks Class Initialized
DEBUG - 2018-02-06 06:10:32 --> UTF-8 Support Enabled
INFO - 2018-02-06 06:10:32 --> Utf8 Class Initialized
INFO - 2018-02-06 06:10:32 --> URI Class Initialized
INFO - 2018-02-06 06:10:32 --> Router Class Initialized
INFO - 2018-02-06 06:10:32 --> Output Class Initialized
INFO - 2018-02-06 06:10:32 --> Security Class Initialized
DEBUG - 2018-02-06 06:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 06:10:32 --> Input Class Initialized
INFO - 2018-02-06 06:10:32 --> Language Class Initialized
INFO - 2018-02-06 06:10:32 --> Loader Class Initialized
INFO - 2018-02-06 06:10:32 --> Helper loaded: url_helper
INFO - 2018-02-06 06:10:32 --> Helper loaded: form_helper
INFO - 2018-02-06 06:10:32 --> Database Driver Class Initialized
DEBUG - 2018-02-06 06:10:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 06:10:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 06:10:32 --> Form Validation Class Initialized
INFO - 2018-02-06 06:10:32 --> Model Class Initialized
INFO - 2018-02-06 06:10:32 --> Controller Class Initialized
INFO - 2018-02-06 06:10:32 --> Model Class Initialized
DEBUG - 2018-02-06 06:10:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 06:10:34 --> Config Class Initialized
INFO - 2018-02-06 06:10:34 --> Hooks Class Initialized
DEBUG - 2018-02-06 06:10:34 --> UTF-8 Support Enabled
INFO - 2018-02-06 06:10:34 --> Utf8 Class Initialized
INFO - 2018-02-06 06:10:34 --> URI Class Initialized
INFO - 2018-02-06 06:10:34 --> Router Class Initialized
INFO - 2018-02-06 06:10:34 --> Output Class Initialized
INFO - 2018-02-06 06:10:34 --> Security Class Initialized
DEBUG - 2018-02-06 06:10:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 06:10:34 --> Input Class Initialized
INFO - 2018-02-06 06:10:34 --> Language Class Initialized
INFO - 2018-02-06 06:10:34 --> Loader Class Initialized
INFO - 2018-02-06 06:10:34 --> Helper loaded: url_helper
INFO - 2018-02-06 06:10:34 --> Helper loaded: form_helper
INFO - 2018-02-06 06:10:34 --> Database Driver Class Initialized
DEBUG - 2018-02-06 06:10:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 06:10:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 06:10:34 --> Form Validation Class Initialized
INFO - 2018-02-06 06:10:34 --> Model Class Initialized
INFO - 2018-02-06 06:10:34 --> Controller Class Initialized
INFO - 2018-02-06 06:10:34 --> Model Class Initialized
DEBUG - 2018-02-06 06:10:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 06:10:34 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 06:10:34 --> Final output sent to browser
DEBUG - 2018-02-06 06:10:34 --> Total execution time: 0.0482
INFO - 2018-02-06 06:10:34 --> Config Class Initialized
INFO - 2018-02-06 06:10:34 --> Hooks Class Initialized
DEBUG - 2018-02-06 06:10:34 --> UTF-8 Support Enabled
INFO - 2018-02-06 06:10:34 --> Utf8 Class Initialized
INFO - 2018-02-06 06:10:34 --> URI Class Initialized
INFO - 2018-02-06 06:10:34 --> Router Class Initialized
INFO - 2018-02-06 06:10:34 --> Output Class Initialized
INFO - 2018-02-06 06:10:34 --> Security Class Initialized
DEBUG - 2018-02-06 06:10:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 06:10:34 --> Input Class Initialized
INFO - 2018-02-06 06:10:34 --> Language Class Initialized
INFO - 2018-02-06 06:10:34 --> Loader Class Initialized
INFO - 2018-02-06 06:10:34 --> Helper loaded: url_helper
INFO - 2018-02-06 06:10:34 --> Helper loaded: form_helper
INFO - 2018-02-06 06:10:34 --> Database Driver Class Initialized
DEBUG - 2018-02-06 06:10:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 06:10:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 06:10:34 --> Form Validation Class Initialized
INFO - 2018-02-06 06:10:34 --> Model Class Initialized
INFO - 2018-02-06 06:10:34 --> Controller Class Initialized
INFO - 2018-02-06 06:10:34 --> Model Class Initialized
DEBUG - 2018-02-06 06:10:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 06:10:35 --> Config Class Initialized
INFO - 2018-02-06 06:10:35 --> Hooks Class Initialized
DEBUG - 2018-02-06 06:10:35 --> UTF-8 Support Enabled
INFO - 2018-02-06 06:10:35 --> Utf8 Class Initialized
INFO - 2018-02-06 06:10:35 --> URI Class Initialized
INFO - 2018-02-06 06:10:35 --> Router Class Initialized
INFO - 2018-02-06 06:10:35 --> Output Class Initialized
INFO - 2018-02-06 06:10:35 --> Security Class Initialized
DEBUG - 2018-02-06 06:10:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 06:10:35 --> Input Class Initialized
INFO - 2018-02-06 06:10:35 --> Language Class Initialized
INFO - 2018-02-06 06:10:35 --> Loader Class Initialized
INFO - 2018-02-06 06:10:35 --> Helper loaded: url_helper
INFO - 2018-02-06 06:10:35 --> Helper loaded: form_helper
INFO - 2018-02-06 06:10:35 --> Database Driver Class Initialized
DEBUG - 2018-02-06 06:10:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 06:10:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 06:10:35 --> Form Validation Class Initialized
INFO - 2018-02-06 06:10:35 --> Model Class Initialized
INFO - 2018-02-06 06:10:35 --> Controller Class Initialized
INFO - 2018-02-06 06:10:35 --> Model Class Initialized
DEBUG - 2018-02-06 06:10:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 06:10:35 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 06:10:35 --> Final output sent to browser
DEBUG - 2018-02-06 06:10:35 --> Total execution time: 0.0491
INFO - 2018-02-06 06:10:35 --> Config Class Initialized
INFO - 2018-02-06 06:10:35 --> Hooks Class Initialized
DEBUG - 2018-02-06 06:10:35 --> UTF-8 Support Enabled
INFO - 2018-02-06 06:10:35 --> Utf8 Class Initialized
INFO - 2018-02-06 06:10:35 --> URI Class Initialized
INFO - 2018-02-06 06:10:35 --> Router Class Initialized
INFO - 2018-02-06 06:10:35 --> Output Class Initialized
INFO - 2018-02-06 06:10:35 --> Security Class Initialized
DEBUG - 2018-02-06 06:10:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 06:10:35 --> Input Class Initialized
INFO - 2018-02-06 06:10:35 --> Language Class Initialized
INFO - 2018-02-06 06:10:35 --> Loader Class Initialized
INFO - 2018-02-06 06:10:35 --> Helper loaded: url_helper
INFO - 2018-02-06 06:10:35 --> Helper loaded: form_helper
INFO - 2018-02-06 06:10:35 --> Database Driver Class Initialized
DEBUG - 2018-02-06 06:10:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 06:10:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 06:10:35 --> Form Validation Class Initialized
INFO - 2018-02-06 06:10:35 --> Model Class Initialized
INFO - 2018-02-06 06:10:35 --> Controller Class Initialized
INFO - 2018-02-06 06:10:35 --> Model Class Initialized
DEBUG - 2018-02-06 06:10:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 06:10:37 --> Config Class Initialized
INFO - 2018-02-06 06:10:37 --> Hooks Class Initialized
DEBUG - 2018-02-06 06:10:37 --> UTF-8 Support Enabled
INFO - 2018-02-06 06:10:37 --> Utf8 Class Initialized
INFO - 2018-02-06 06:10:37 --> URI Class Initialized
INFO - 2018-02-06 06:10:37 --> Router Class Initialized
INFO - 2018-02-06 06:10:37 --> Output Class Initialized
INFO - 2018-02-06 06:10:37 --> Security Class Initialized
DEBUG - 2018-02-06 06:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 06:10:37 --> Input Class Initialized
INFO - 2018-02-06 06:10:37 --> Language Class Initialized
INFO - 2018-02-06 06:10:37 --> Loader Class Initialized
INFO - 2018-02-06 06:10:37 --> Helper loaded: url_helper
INFO - 2018-02-06 06:10:37 --> Helper loaded: form_helper
INFO - 2018-02-06 06:10:37 --> Database Driver Class Initialized
DEBUG - 2018-02-06 06:10:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 06:10:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 06:10:37 --> Form Validation Class Initialized
INFO - 2018-02-06 06:10:37 --> Model Class Initialized
INFO - 2018-02-06 06:10:37 --> Controller Class Initialized
INFO - 2018-02-06 06:10:37 --> Model Class Initialized
DEBUG - 2018-02-06 06:10:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 06:10:37 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 06:10:37 --> Final output sent to browser
DEBUG - 2018-02-06 06:10:37 --> Total execution time: 0.0431
INFO - 2018-02-06 06:32:54 --> Config Class Initialized
INFO - 2018-02-06 06:32:54 --> Hooks Class Initialized
DEBUG - 2018-02-06 06:32:54 --> UTF-8 Support Enabled
INFO - 2018-02-06 06:32:54 --> Utf8 Class Initialized
INFO - 2018-02-06 06:32:54 --> URI Class Initialized
INFO - 2018-02-06 06:32:54 --> Router Class Initialized
INFO - 2018-02-06 06:32:54 --> Output Class Initialized
INFO - 2018-02-06 06:32:54 --> Security Class Initialized
DEBUG - 2018-02-06 06:32:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 06:32:54 --> Input Class Initialized
INFO - 2018-02-06 06:32:54 --> Language Class Initialized
INFO - 2018-02-06 06:32:54 --> Loader Class Initialized
INFO - 2018-02-06 06:32:54 --> Helper loaded: url_helper
INFO - 2018-02-06 06:32:54 --> Helper loaded: form_helper
INFO - 2018-02-06 06:32:54 --> Database Driver Class Initialized
DEBUG - 2018-02-06 06:32:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 06:32:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 06:32:54 --> Form Validation Class Initialized
INFO - 2018-02-06 06:32:54 --> Model Class Initialized
INFO - 2018-02-06 06:32:54 --> Controller Class Initialized
INFO - 2018-02-06 06:32:54 --> Model Class Initialized
DEBUG - 2018-02-06 06:32:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 06:32:55 --> Model Class Initialized
ERROR - 2018-02-06 06:32:55 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\instateccr\controlcostos\instatec_sys\database\DB_driver.php 1477
ERROR - 2018-02-06 06:32:55 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: INSERT INTO `usuario_colaborador` (`usuario_id`, `colaborador_id`) VALUES (Array, 8)
INFO - 2018-02-06 06:32:55 --> Language file loaded: language/english/db_lang.php
INFO - 2018-02-06 06:40:47 --> Config Class Initialized
INFO - 2018-02-06 06:40:47 --> Hooks Class Initialized
DEBUG - 2018-02-06 06:40:47 --> UTF-8 Support Enabled
INFO - 2018-02-06 06:40:47 --> Utf8 Class Initialized
INFO - 2018-02-06 06:40:47 --> URI Class Initialized
INFO - 2018-02-06 06:40:47 --> Router Class Initialized
INFO - 2018-02-06 06:40:47 --> Output Class Initialized
INFO - 2018-02-06 06:40:47 --> Security Class Initialized
DEBUG - 2018-02-06 06:40:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 06:40:47 --> Input Class Initialized
INFO - 2018-02-06 06:40:47 --> Language Class Initialized
INFO - 2018-02-06 06:40:47 --> Loader Class Initialized
INFO - 2018-02-06 06:40:47 --> Helper loaded: url_helper
INFO - 2018-02-06 06:40:47 --> Helper loaded: form_helper
INFO - 2018-02-06 06:40:47 --> Database Driver Class Initialized
DEBUG - 2018-02-06 06:40:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 06:40:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 06:40:47 --> Form Validation Class Initialized
INFO - 2018-02-06 06:40:47 --> Model Class Initialized
INFO - 2018-02-06 06:40:47 --> Controller Class Initialized
INFO - 2018-02-06 06:40:47 --> Model Class Initialized
DEBUG - 2018-02-06 06:40:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 06:40:47 --> Model Class Initialized
INFO - 2018-02-06 06:40:47 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 06:40:47 --> Final output sent to browser
DEBUG - 2018-02-06 06:40:47 --> Total execution time: 0.1332
INFO - 2018-02-06 06:43:10 --> Config Class Initialized
INFO - 2018-02-06 06:43:10 --> Hooks Class Initialized
DEBUG - 2018-02-06 06:43:10 --> UTF-8 Support Enabled
INFO - 2018-02-06 06:43:10 --> Utf8 Class Initialized
INFO - 2018-02-06 06:43:10 --> URI Class Initialized
INFO - 2018-02-06 06:43:10 --> Router Class Initialized
INFO - 2018-02-06 06:43:10 --> Output Class Initialized
INFO - 2018-02-06 06:43:10 --> Security Class Initialized
DEBUG - 2018-02-06 06:43:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 06:43:10 --> Input Class Initialized
INFO - 2018-02-06 06:43:10 --> Language Class Initialized
INFO - 2018-02-06 06:43:10 --> Loader Class Initialized
INFO - 2018-02-06 06:43:10 --> Helper loaded: url_helper
INFO - 2018-02-06 06:43:10 --> Helper loaded: form_helper
INFO - 2018-02-06 06:43:10 --> Database Driver Class Initialized
DEBUG - 2018-02-06 06:43:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 06:43:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 06:43:10 --> Form Validation Class Initialized
INFO - 2018-02-06 06:43:10 --> Model Class Initialized
INFO - 2018-02-06 06:43:10 --> Controller Class Initialized
INFO - 2018-02-06 06:43:10 --> Model Class Initialized
DEBUG - 2018-02-06 06:43:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 06:43:10 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 06:43:10 --> Final output sent to browser
DEBUG - 2018-02-06 06:43:10 --> Total execution time: 0.0394
INFO - 2018-02-06 06:43:10 --> Config Class Initialized
INFO - 2018-02-06 06:43:10 --> Hooks Class Initialized
DEBUG - 2018-02-06 06:43:10 --> UTF-8 Support Enabled
INFO - 2018-02-06 06:43:10 --> Utf8 Class Initialized
INFO - 2018-02-06 06:43:10 --> URI Class Initialized
INFO - 2018-02-06 06:43:10 --> Router Class Initialized
INFO - 2018-02-06 06:43:10 --> Output Class Initialized
INFO - 2018-02-06 06:43:10 --> Security Class Initialized
DEBUG - 2018-02-06 06:43:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 06:43:10 --> Input Class Initialized
INFO - 2018-02-06 06:43:10 --> Language Class Initialized
INFO - 2018-02-06 06:43:10 --> Loader Class Initialized
INFO - 2018-02-06 06:43:10 --> Helper loaded: url_helper
INFO - 2018-02-06 06:43:10 --> Helper loaded: form_helper
INFO - 2018-02-06 06:43:10 --> Database Driver Class Initialized
DEBUG - 2018-02-06 06:43:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 06:43:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 06:43:10 --> Form Validation Class Initialized
INFO - 2018-02-06 06:43:10 --> Model Class Initialized
INFO - 2018-02-06 06:43:10 --> Controller Class Initialized
INFO - 2018-02-06 06:43:10 --> Model Class Initialized
DEBUG - 2018-02-06 06:43:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 06:43:14 --> Config Class Initialized
INFO - 2018-02-06 06:43:14 --> Hooks Class Initialized
DEBUG - 2018-02-06 06:43:14 --> UTF-8 Support Enabled
INFO - 2018-02-06 06:43:14 --> Utf8 Class Initialized
INFO - 2018-02-06 06:43:14 --> URI Class Initialized
INFO - 2018-02-06 06:43:14 --> Router Class Initialized
INFO - 2018-02-06 06:43:14 --> Output Class Initialized
INFO - 2018-02-06 06:43:14 --> Security Class Initialized
DEBUG - 2018-02-06 06:43:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 06:43:14 --> Input Class Initialized
INFO - 2018-02-06 06:43:14 --> Language Class Initialized
INFO - 2018-02-06 06:43:14 --> Loader Class Initialized
INFO - 2018-02-06 06:43:14 --> Helper loaded: url_helper
INFO - 2018-02-06 06:43:14 --> Helper loaded: form_helper
INFO - 2018-02-06 06:43:14 --> Database Driver Class Initialized
DEBUG - 2018-02-06 06:43:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 06:43:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 06:43:14 --> Form Validation Class Initialized
INFO - 2018-02-06 06:43:14 --> Model Class Initialized
INFO - 2018-02-06 06:43:14 --> Controller Class Initialized
INFO - 2018-02-06 06:43:14 --> Model Class Initialized
DEBUG - 2018-02-06 06:43:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 06:43:14 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 06:43:14 --> Final output sent to browser
DEBUG - 2018-02-06 06:43:14 --> Total execution time: 0.0494
INFO - 2018-02-06 06:43:14 --> Config Class Initialized
INFO - 2018-02-06 06:43:14 --> Hooks Class Initialized
DEBUG - 2018-02-06 06:43:14 --> UTF-8 Support Enabled
INFO - 2018-02-06 06:43:14 --> Utf8 Class Initialized
INFO - 2018-02-06 06:43:14 --> URI Class Initialized
INFO - 2018-02-06 06:43:14 --> Router Class Initialized
INFO - 2018-02-06 06:43:14 --> Output Class Initialized
INFO - 2018-02-06 06:43:14 --> Security Class Initialized
DEBUG - 2018-02-06 06:43:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 06:43:14 --> Input Class Initialized
INFO - 2018-02-06 06:43:14 --> Language Class Initialized
INFO - 2018-02-06 06:43:14 --> Loader Class Initialized
INFO - 2018-02-06 06:43:14 --> Helper loaded: url_helper
INFO - 2018-02-06 06:43:14 --> Helper loaded: form_helper
INFO - 2018-02-06 06:43:14 --> Database Driver Class Initialized
DEBUG - 2018-02-06 06:43:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 06:43:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 06:43:14 --> Form Validation Class Initialized
INFO - 2018-02-06 06:43:14 --> Model Class Initialized
INFO - 2018-02-06 06:43:14 --> Controller Class Initialized
INFO - 2018-02-06 06:43:14 --> Model Class Initialized
DEBUG - 2018-02-06 06:43:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 06:43:18 --> Config Class Initialized
INFO - 2018-02-06 06:43:18 --> Hooks Class Initialized
DEBUG - 2018-02-06 06:43:18 --> UTF-8 Support Enabled
INFO - 2018-02-06 06:43:18 --> Utf8 Class Initialized
INFO - 2018-02-06 06:43:18 --> URI Class Initialized
INFO - 2018-02-06 06:43:18 --> Router Class Initialized
INFO - 2018-02-06 06:43:18 --> Output Class Initialized
INFO - 2018-02-06 06:43:18 --> Security Class Initialized
DEBUG - 2018-02-06 06:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 06:43:18 --> Input Class Initialized
INFO - 2018-02-06 06:43:18 --> Language Class Initialized
INFO - 2018-02-06 06:43:18 --> Loader Class Initialized
INFO - 2018-02-06 06:43:18 --> Helper loaded: url_helper
INFO - 2018-02-06 06:43:18 --> Helper loaded: form_helper
INFO - 2018-02-06 06:43:18 --> Database Driver Class Initialized
DEBUG - 2018-02-06 06:43:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 06:43:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 06:43:18 --> Form Validation Class Initialized
INFO - 2018-02-06 06:43:18 --> Model Class Initialized
INFO - 2018-02-06 06:43:18 --> Controller Class Initialized
INFO - 2018-02-06 06:43:18 --> Model Class Initialized
DEBUG - 2018-02-06 06:43:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 06:43:18 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 06:43:18 --> Final output sent to browser
DEBUG - 2018-02-06 06:43:18 --> Total execution time: 0.0369
INFO - 2018-02-06 06:43:19 --> Config Class Initialized
INFO - 2018-02-06 06:43:19 --> Hooks Class Initialized
DEBUG - 2018-02-06 06:43:19 --> UTF-8 Support Enabled
INFO - 2018-02-06 06:43:19 --> Utf8 Class Initialized
INFO - 2018-02-06 06:43:19 --> URI Class Initialized
INFO - 2018-02-06 06:43:19 --> Router Class Initialized
INFO - 2018-02-06 06:43:19 --> Output Class Initialized
INFO - 2018-02-06 06:43:19 --> Security Class Initialized
DEBUG - 2018-02-06 06:43:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 06:43:19 --> Input Class Initialized
INFO - 2018-02-06 06:43:19 --> Language Class Initialized
INFO - 2018-02-06 06:43:19 --> Loader Class Initialized
INFO - 2018-02-06 06:43:19 --> Helper loaded: url_helper
INFO - 2018-02-06 06:43:19 --> Helper loaded: form_helper
INFO - 2018-02-06 06:43:19 --> Database Driver Class Initialized
DEBUG - 2018-02-06 06:43:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 06:43:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 06:43:19 --> Form Validation Class Initialized
INFO - 2018-02-06 06:43:19 --> Model Class Initialized
INFO - 2018-02-06 06:43:19 --> Controller Class Initialized
INFO - 2018-02-06 06:43:19 --> Model Class Initialized
DEBUG - 2018-02-06 06:43:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 06:45:20 --> Config Class Initialized
INFO - 2018-02-06 06:45:20 --> Hooks Class Initialized
DEBUG - 2018-02-06 06:45:20 --> UTF-8 Support Enabled
INFO - 2018-02-06 06:45:20 --> Utf8 Class Initialized
INFO - 2018-02-06 06:45:20 --> URI Class Initialized
INFO - 2018-02-06 06:45:20 --> Router Class Initialized
INFO - 2018-02-06 06:45:20 --> Output Class Initialized
INFO - 2018-02-06 06:45:20 --> Security Class Initialized
DEBUG - 2018-02-06 06:45:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 06:45:20 --> Input Class Initialized
INFO - 2018-02-06 06:45:20 --> Language Class Initialized
INFO - 2018-02-06 06:45:20 --> Loader Class Initialized
INFO - 2018-02-06 06:45:20 --> Helper loaded: url_helper
INFO - 2018-02-06 06:45:20 --> Helper loaded: form_helper
INFO - 2018-02-06 06:45:20 --> Database Driver Class Initialized
DEBUG - 2018-02-06 06:45:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 06:45:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 06:45:20 --> Form Validation Class Initialized
INFO - 2018-02-06 06:45:20 --> Model Class Initialized
INFO - 2018-02-06 06:45:20 --> Controller Class Initialized
INFO - 2018-02-06 06:45:20 --> Model Class Initialized
DEBUG - 2018-02-06 06:45:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 06:45:20 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 06:45:20 --> Final output sent to browser
DEBUG - 2018-02-06 06:45:20 --> Total execution time: 0.0490
INFO - 2018-02-06 06:45:20 --> Config Class Initialized
INFO - 2018-02-06 06:45:20 --> Hooks Class Initialized
DEBUG - 2018-02-06 06:45:20 --> UTF-8 Support Enabled
INFO - 2018-02-06 06:45:20 --> Utf8 Class Initialized
INFO - 2018-02-06 06:45:20 --> URI Class Initialized
INFO - 2018-02-06 06:45:20 --> Router Class Initialized
INFO - 2018-02-06 06:45:20 --> Output Class Initialized
INFO - 2018-02-06 06:45:20 --> Security Class Initialized
DEBUG - 2018-02-06 06:45:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 06:45:20 --> Input Class Initialized
INFO - 2018-02-06 06:45:20 --> Language Class Initialized
INFO - 2018-02-06 06:45:20 --> Loader Class Initialized
INFO - 2018-02-06 06:45:20 --> Helper loaded: url_helper
INFO - 2018-02-06 06:45:20 --> Helper loaded: form_helper
INFO - 2018-02-06 06:45:20 --> Database Driver Class Initialized
DEBUG - 2018-02-06 06:45:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 06:45:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 06:45:20 --> Form Validation Class Initialized
INFO - 2018-02-06 06:45:20 --> Model Class Initialized
INFO - 2018-02-06 06:45:20 --> Controller Class Initialized
INFO - 2018-02-06 06:45:20 --> Model Class Initialized
DEBUG - 2018-02-06 06:45:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 06:45:22 --> Config Class Initialized
INFO - 2018-02-06 06:45:22 --> Hooks Class Initialized
DEBUG - 2018-02-06 06:45:22 --> UTF-8 Support Enabled
INFO - 2018-02-06 06:45:22 --> Utf8 Class Initialized
INFO - 2018-02-06 06:45:22 --> URI Class Initialized
INFO - 2018-02-06 06:45:22 --> Router Class Initialized
INFO - 2018-02-06 06:45:22 --> Output Class Initialized
INFO - 2018-02-06 06:45:22 --> Security Class Initialized
DEBUG - 2018-02-06 06:45:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 06:45:22 --> Input Class Initialized
INFO - 2018-02-06 06:45:22 --> Language Class Initialized
INFO - 2018-02-06 06:45:22 --> Loader Class Initialized
INFO - 2018-02-06 06:45:22 --> Helper loaded: url_helper
INFO - 2018-02-06 06:45:22 --> Helper loaded: form_helper
INFO - 2018-02-06 06:45:23 --> Database Driver Class Initialized
DEBUG - 2018-02-06 06:45:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 06:45:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 06:45:23 --> Form Validation Class Initialized
INFO - 2018-02-06 06:45:23 --> Model Class Initialized
INFO - 2018-02-06 06:45:23 --> Controller Class Initialized
INFO - 2018-02-06 06:45:23 --> Model Class Initialized
DEBUG - 2018-02-06 06:45:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 06:45:23 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 06:45:23 --> Final output sent to browser
DEBUG - 2018-02-06 06:45:23 --> Total execution time: 0.0505
INFO - 2018-02-06 06:45:59 --> Config Class Initialized
INFO - 2018-02-06 06:45:59 --> Hooks Class Initialized
DEBUG - 2018-02-06 06:45:59 --> UTF-8 Support Enabled
INFO - 2018-02-06 06:45:59 --> Utf8 Class Initialized
INFO - 2018-02-06 06:45:59 --> URI Class Initialized
INFO - 2018-02-06 06:45:59 --> Router Class Initialized
INFO - 2018-02-06 06:45:59 --> Output Class Initialized
INFO - 2018-02-06 06:45:59 --> Security Class Initialized
DEBUG - 2018-02-06 06:45:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 06:45:59 --> Input Class Initialized
INFO - 2018-02-06 06:45:59 --> Language Class Initialized
INFO - 2018-02-06 06:45:59 --> Loader Class Initialized
INFO - 2018-02-06 06:45:59 --> Helper loaded: url_helper
INFO - 2018-02-06 06:45:59 --> Helper loaded: form_helper
INFO - 2018-02-06 06:45:59 --> Database Driver Class Initialized
DEBUG - 2018-02-06 06:45:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 06:45:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 06:45:59 --> Form Validation Class Initialized
INFO - 2018-02-06 06:45:59 --> Model Class Initialized
INFO - 2018-02-06 06:45:59 --> Controller Class Initialized
INFO - 2018-02-06 06:45:59 --> Model Class Initialized
DEBUG - 2018-02-06 06:45:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 06:46:00 --> Model Class Initialized
INFO - 2018-02-06 06:46:00 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 06:46:00 --> Final output sent to browser
DEBUG - 2018-02-06 06:46:00 --> Total execution time: 0.6872
INFO - 2018-02-06 06:46:02 --> Config Class Initialized
INFO - 2018-02-06 06:46:02 --> Hooks Class Initialized
DEBUG - 2018-02-06 06:46:02 --> UTF-8 Support Enabled
INFO - 2018-02-06 06:46:02 --> Utf8 Class Initialized
INFO - 2018-02-06 06:46:02 --> URI Class Initialized
INFO - 2018-02-06 06:46:02 --> Router Class Initialized
INFO - 2018-02-06 06:46:02 --> Output Class Initialized
INFO - 2018-02-06 06:46:02 --> Security Class Initialized
DEBUG - 2018-02-06 06:46:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 06:46:02 --> Input Class Initialized
INFO - 2018-02-06 06:46:02 --> Language Class Initialized
INFO - 2018-02-06 06:46:02 --> Loader Class Initialized
INFO - 2018-02-06 06:46:02 --> Helper loaded: url_helper
INFO - 2018-02-06 06:46:02 --> Helper loaded: form_helper
INFO - 2018-02-06 06:46:02 --> Database Driver Class Initialized
DEBUG - 2018-02-06 06:46:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 06:46:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 06:46:02 --> Form Validation Class Initialized
INFO - 2018-02-06 06:46:02 --> Model Class Initialized
INFO - 2018-02-06 06:46:02 --> Controller Class Initialized
INFO - 2018-02-06 06:46:02 --> Model Class Initialized
DEBUG - 2018-02-06 06:46:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 06:46:02 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 06:46:02 --> Final output sent to browser
DEBUG - 2018-02-06 06:46:02 --> Total execution time: 0.0421
INFO - 2018-02-06 06:46:02 --> Config Class Initialized
INFO - 2018-02-06 06:46:02 --> Hooks Class Initialized
DEBUG - 2018-02-06 06:46:02 --> UTF-8 Support Enabled
INFO - 2018-02-06 06:46:02 --> Utf8 Class Initialized
INFO - 2018-02-06 06:46:02 --> URI Class Initialized
INFO - 2018-02-06 06:46:02 --> Router Class Initialized
INFO - 2018-02-06 06:46:02 --> Output Class Initialized
INFO - 2018-02-06 06:46:02 --> Security Class Initialized
DEBUG - 2018-02-06 06:46:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 06:46:02 --> Input Class Initialized
INFO - 2018-02-06 06:46:02 --> Language Class Initialized
INFO - 2018-02-06 06:46:02 --> Loader Class Initialized
INFO - 2018-02-06 06:46:02 --> Helper loaded: url_helper
INFO - 2018-02-06 06:46:02 --> Helper loaded: form_helper
INFO - 2018-02-06 06:46:02 --> Database Driver Class Initialized
DEBUG - 2018-02-06 06:46:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 06:46:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 06:46:02 --> Form Validation Class Initialized
INFO - 2018-02-06 06:46:02 --> Model Class Initialized
INFO - 2018-02-06 06:46:02 --> Controller Class Initialized
INFO - 2018-02-06 06:46:02 --> Model Class Initialized
DEBUG - 2018-02-06 06:46:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 06:46:06 --> Config Class Initialized
INFO - 2018-02-06 06:46:06 --> Hooks Class Initialized
DEBUG - 2018-02-06 06:46:06 --> UTF-8 Support Enabled
INFO - 2018-02-06 06:46:06 --> Utf8 Class Initialized
INFO - 2018-02-06 06:46:06 --> URI Class Initialized
INFO - 2018-02-06 06:46:06 --> Router Class Initialized
INFO - 2018-02-06 06:46:06 --> Output Class Initialized
INFO - 2018-02-06 06:46:06 --> Security Class Initialized
DEBUG - 2018-02-06 06:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 06:46:06 --> Input Class Initialized
INFO - 2018-02-06 06:46:06 --> Language Class Initialized
INFO - 2018-02-06 06:46:06 --> Loader Class Initialized
INFO - 2018-02-06 06:46:06 --> Helper loaded: url_helper
INFO - 2018-02-06 06:46:06 --> Helper loaded: form_helper
INFO - 2018-02-06 06:46:06 --> Database Driver Class Initialized
DEBUG - 2018-02-06 06:46:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 06:46:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 06:46:06 --> Form Validation Class Initialized
INFO - 2018-02-06 06:46:06 --> Model Class Initialized
INFO - 2018-02-06 06:46:06 --> Controller Class Initialized
INFO - 2018-02-06 06:46:06 --> Model Class Initialized
DEBUG - 2018-02-06 06:46:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 06:46:06 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 06:46:06 --> Final output sent to browser
DEBUG - 2018-02-06 06:46:06 --> Total execution time: 0.0519
INFO - 2018-02-06 06:46:06 --> Config Class Initialized
INFO - 2018-02-06 06:46:06 --> Hooks Class Initialized
DEBUG - 2018-02-06 06:46:06 --> UTF-8 Support Enabled
INFO - 2018-02-06 06:46:06 --> Utf8 Class Initialized
INFO - 2018-02-06 06:46:06 --> URI Class Initialized
INFO - 2018-02-06 06:46:06 --> Router Class Initialized
INFO - 2018-02-06 06:46:06 --> Output Class Initialized
INFO - 2018-02-06 06:46:06 --> Security Class Initialized
DEBUG - 2018-02-06 06:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 06:46:06 --> Input Class Initialized
INFO - 2018-02-06 06:46:06 --> Language Class Initialized
INFO - 2018-02-06 06:46:06 --> Loader Class Initialized
INFO - 2018-02-06 06:46:06 --> Helper loaded: url_helper
INFO - 2018-02-06 06:46:06 --> Helper loaded: form_helper
INFO - 2018-02-06 06:46:06 --> Database Driver Class Initialized
DEBUG - 2018-02-06 06:46:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 06:46:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 06:46:06 --> Form Validation Class Initialized
INFO - 2018-02-06 06:46:06 --> Model Class Initialized
INFO - 2018-02-06 06:46:06 --> Controller Class Initialized
INFO - 2018-02-06 06:46:06 --> Model Class Initialized
DEBUG - 2018-02-06 06:46:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 06:55:36 --> Config Class Initialized
INFO - 2018-02-06 06:55:36 --> Hooks Class Initialized
DEBUG - 2018-02-06 06:55:36 --> UTF-8 Support Enabled
INFO - 2018-02-06 06:55:36 --> Utf8 Class Initialized
INFO - 2018-02-06 06:55:36 --> URI Class Initialized
INFO - 2018-02-06 06:55:36 --> Router Class Initialized
INFO - 2018-02-06 06:55:36 --> Output Class Initialized
INFO - 2018-02-06 06:55:36 --> Security Class Initialized
DEBUG - 2018-02-06 06:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 06:55:36 --> Input Class Initialized
INFO - 2018-02-06 06:55:36 --> Language Class Initialized
INFO - 2018-02-06 06:55:36 --> Loader Class Initialized
INFO - 2018-02-06 06:55:36 --> Helper loaded: url_helper
INFO - 2018-02-06 06:55:36 --> Helper loaded: form_helper
INFO - 2018-02-06 06:55:36 --> Database Driver Class Initialized
DEBUG - 2018-02-06 06:55:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 06:55:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 06:55:36 --> Form Validation Class Initialized
INFO - 2018-02-06 06:55:36 --> Model Class Initialized
INFO - 2018-02-06 06:55:36 --> Controller Class Initialized
INFO - 2018-02-06 06:55:36 --> Model Class Initialized
DEBUG - 2018-02-06 06:55:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 06:55:36 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 06:55:36 --> Final output sent to browser
DEBUG - 2018-02-06 06:55:36 --> Total execution time: 0.0401
INFO - 2018-02-06 06:55:36 --> Config Class Initialized
INFO - 2018-02-06 06:55:36 --> Hooks Class Initialized
DEBUG - 2018-02-06 06:55:36 --> UTF-8 Support Enabled
INFO - 2018-02-06 06:55:36 --> Utf8 Class Initialized
INFO - 2018-02-06 06:55:36 --> URI Class Initialized
INFO - 2018-02-06 06:55:36 --> Router Class Initialized
INFO - 2018-02-06 06:55:36 --> Output Class Initialized
INFO - 2018-02-06 06:55:36 --> Security Class Initialized
DEBUG - 2018-02-06 06:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 06:55:36 --> Input Class Initialized
INFO - 2018-02-06 06:55:36 --> Language Class Initialized
INFO - 2018-02-06 06:55:36 --> Loader Class Initialized
INFO - 2018-02-06 06:55:36 --> Helper loaded: url_helper
INFO - 2018-02-06 06:55:36 --> Helper loaded: form_helper
INFO - 2018-02-06 06:55:36 --> Database Driver Class Initialized
DEBUG - 2018-02-06 06:55:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 06:55:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 06:55:36 --> Form Validation Class Initialized
INFO - 2018-02-06 06:55:36 --> Model Class Initialized
INFO - 2018-02-06 06:55:36 --> Controller Class Initialized
INFO - 2018-02-06 06:55:36 --> Model Class Initialized
DEBUG - 2018-02-06 06:55:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 06:55:38 --> Config Class Initialized
INFO - 2018-02-06 06:55:38 --> Hooks Class Initialized
DEBUG - 2018-02-06 06:55:38 --> UTF-8 Support Enabled
INFO - 2018-02-06 06:55:38 --> Utf8 Class Initialized
INFO - 2018-02-06 06:55:38 --> URI Class Initialized
INFO - 2018-02-06 06:55:38 --> Router Class Initialized
INFO - 2018-02-06 06:55:38 --> Output Class Initialized
INFO - 2018-02-06 06:55:38 --> Security Class Initialized
DEBUG - 2018-02-06 06:55:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 06:55:38 --> Input Class Initialized
INFO - 2018-02-06 06:55:38 --> Language Class Initialized
INFO - 2018-02-06 06:55:38 --> Loader Class Initialized
INFO - 2018-02-06 06:55:38 --> Helper loaded: url_helper
INFO - 2018-02-06 06:55:38 --> Helper loaded: form_helper
INFO - 2018-02-06 06:55:38 --> Database Driver Class Initialized
DEBUG - 2018-02-06 06:55:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 06:55:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 06:55:38 --> Form Validation Class Initialized
INFO - 2018-02-06 06:55:38 --> Model Class Initialized
INFO - 2018-02-06 06:55:38 --> Controller Class Initialized
INFO - 2018-02-06 06:55:38 --> Model Class Initialized
DEBUG - 2018-02-06 06:55:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 06:55:38 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 06:55:38 --> Final output sent to browser
DEBUG - 2018-02-06 06:55:38 --> Total execution time: 0.0385
INFO - 2018-02-06 06:55:38 --> Config Class Initialized
INFO - 2018-02-06 06:55:38 --> Hooks Class Initialized
DEBUG - 2018-02-06 06:55:38 --> UTF-8 Support Enabled
INFO - 2018-02-06 06:55:38 --> Utf8 Class Initialized
INFO - 2018-02-06 06:55:38 --> URI Class Initialized
INFO - 2018-02-06 06:55:38 --> Router Class Initialized
INFO - 2018-02-06 06:55:38 --> Output Class Initialized
INFO - 2018-02-06 06:55:38 --> Security Class Initialized
DEBUG - 2018-02-06 06:55:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 06:55:38 --> Input Class Initialized
INFO - 2018-02-06 06:55:38 --> Language Class Initialized
INFO - 2018-02-06 06:55:38 --> Loader Class Initialized
INFO - 2018-02-06 06:55:38 --> Helper loaded: url_helper
INFO - 2018-02-06 06:55:38 --> Helper loaded: form_helper
INFO - 2018-02-06 06:55:38 --> Database Driver Class Initialized
DEBUG - 2018-02-06 06:55:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 06:55:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 06:55:38 --> Form Validation Class Initialized
INFO - 2018-02-06 06:55:38 --> Model Class Initialized
INFO - 2018-02-06 06:55:38 --> Controller Class Initialized
INFO - 2018-02-06 06:55:38 --> Model Class Initialized
DEBUG - 2018-02-06 06:55:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 06:55:45 --> Config Class Initialized
INFO - 2018-02-06 06:55:45 --> Hooks Class Initialized
DEBUG - 2018-02-06 06:55:45 --> UTF-8 Support Enabled
INFO - 2018-02-06 06:55:45 --> Utf8 Class Initialized
INFO - 2018-02-06 06:55:45 --> URI Class Initialized
INFO - 2018-02-06 06:55:45 --> Router Class Initialized
INFO - 2018-02-06 06:55:45 --> Output Class Initialized
INFO - 2018-02-06 06:55:45 --> Security Class Initialized
DEBUG - 2018-02-06 06:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 06:55:45 --> Input Class Initialized
INFO - 2018-02-06 06:55:45 --> Language Class Initialized
INFO - 2018-02-06 06:55:45 --> Loader Class Initialized
INFO - 2018-02-06 06:55:45 --> Helper loaded: url_helper
INFO - 2018-02-06 06:55:45 --> Helper loaded: form_helper
INFO - 2018-02-06 06:55:45 --> Database Driver Class Initialized
DEBUG - 2018-02-06 06:55:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 06:55:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 06:55:45 --> Form Validation Class Initialized
INFO - 2018-02-06 06:55:45 --> Model Class Initialized
INFO - 2018-02-06 06:55:45 --> Controller Class Initialized
INFO - 2018-02-06 06:55:45 --> Model Class Initialized
DEBUG - 2018-02-06 06:55:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 06:55:45 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 06:55:45 --> Final output sent to browser
DEBUG - 2018-02-06 06:55:45 --> Total execution time: 0.0398
INFO - 2018-02-06 06:55:45 --> Config Class Initialized
INFO - 2018-02-06 06:55:45 --> Hooks Class Initialized
DEBUG - 2018-02-06 06:55:45 --> UTF-8 Support Enabled
INFO - 2018-02-06 06:55:45 --> Utf8 Class Initialized
INFO - 2018-02-06 06:55:45 --> URI Class Initialized
INFO - 2018-02-06 06:55:45 --> Router Class Initialized
INFO - 2018-02-06 06:55:45 --> Output Class Initialized
INFO - 2018-02-06 06:55:45 --> Security Class Initialized
DEBUG - 2018-02-06 06:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 06:55:45 --> Input Class Initialized
INFO - 2018-02-06 06:55:45 --> Language Class Initialized
INFO - 2018-02-06 06:55:45 --> Loader Class Initialized
INFO - 2018-02-06 06:55:45 --> Helper loaded: url_helper
INFO - 2018-02-06 06:55:45 --> Helper loaded: form_helper
INFO - 2018-02-06 06:55:45 --> Database Driver Class Initialized
DEBUG - 2018-02-06 06:55:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 06:55:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 06:55:45 --> Form Validation Class Initialized
INFO - 2018-02-06 06:55:45 --> Model Class Initialized
INFO - 2018-02-06 06:55:45 --> Controller Class Initialized
INFO - 2018-02-06 06:55:45 --> Model Class Initialized
DEBUG - 2018-02-06 06:55:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 06:55:50 --> Config Class Initialized
INFO - 2018-02-06 06:55:50 --> Hooks Class Initialized
DEBUG - 2018-02-06 06:55:50 --> UTF-8 Support Enabled
INFO - 2018-02-06 06:55:50 --> Utf8 Class Initialized
INFO - 2018-02-06 06:55:50 --> URI Class Initialized
INFO - 2018-02-06 06:55:50 --> Router Class Initialized
INFO - 2018-02-06 06:55:50 --> Output Class Initialized
INFO - 2018-02-06 06:55:50 --> Security Class Initialized
DEBUG - 2018-02-06 06:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 06:55:50 --> Input Class Initialized
INFO - 2018-02-06 06:55:50 --> Language Class Initialized
INFO - 2018-02-06 06:55:50 --> Loader Class Initialized
INFO - 2018-02-06 06:55:50 --> Helper loaded: url_helper
INFO - 2018-02-06 06:55:50 --> Helper loaded: form_helper
INFO - 2018-02-06 06:55:50 --> Database Driver Class Initialized
DEBUG - 2018-02-06 06:55:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 06:55:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 06:55:50 --> Form Validation Class Initialized
INFO - 2018-02-06 06:55:50 --> Model Class Initialized
INFO - 2018-02-06 06:55:50 --> Controller Class Initialized
INFO - 2018-02-06 06:55:50 --> Model Class Initialized
DEBUG - 2018-02-06 06:55:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 06:55:50 --> Model Class Initialized
INFO - 2018-02-06 06:55:50 --> Config Class Initialized
INFO - 2018-02-06 06:55:50 --> Hooks Class Initialized
DEBUG - 2018-02-06 06:55:50 --> UTF-8 Support Enabled
INFO - 2018-02-06 06:55:50 --> Utf8 Class Initialized
INFO - 2018-02-06 06:55:50 --> URI Class Initialized
INFO - 2018-02-06 06:55:50 --> Router Class Initialized
INFO - 2018-02-06 06:55:50 --> Output Class Initialized
INFO - 2018-02-06 06:55:50 --> Security Class Initialized
DEBUG - 2018-02-06 06:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 06:55:50 --> Input Class Initialized
INFO - 2018-02-06 06:55:50 --> Language Class Initialized
INFO - 2018-02-06 06:55:50 --> Loader Class Initialized
INFO - 2018-02-06 06:55:50 --> Helper loaded: url_helper
INFO - 2018-02-06 06:55:50 --> Helper loaded: form_helper
INFO - 2018-02-06 06:55:50 --> Database Driver Class Initialized
DEBUG - 2018-02-06 06:55:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 06:55:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 06:55:50 --> Form Validation Class Initialized
INFO - 2018-02-06 06:55:50 --> Model Class Initialized
INFO - 2018-02-06 06:55:50 --> Controller Class Initialized
INFO - 2018-02-06 06:55:50 --> Model Class Initialized
DEBUG - 2018-02-06 06:55:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 06:55:50 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 06:55:50 --> Final output sent to browser
DEBUG - 2018-02-06 06:55:50 --> Total execution time: 0.0398
INFO - 2018-02-06 06:55:50 --> Config Class Initialized
INFO - 2018-02-06 06:55:50 --> Hooks Class Initialized
DEBUG - 2018-02-06 06:55:50 --> UTF-8 Support Enabled
INFO - 2018-02-06 06:55:50 --> Utf8 Class Initialized
INFO - 2018-02-06 06:55:50 --> URI Class Initialized
INFO - 2018-02-06 06:55:50 --> Router Class Initialized
INFO - 2018-02-06 06:55:50 --> Output Class Initialized
INFO - 2018-02-06 06:55:50 --> Security Class Initialized
DEBUG - 2018-02-06 06:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 06:55:50 --> Input Class Initialized
INFO - 2018-02-06 06:55:50 --> Language Class Initialized
INFO - 2018-02-06 06:55:50 --> Loader Class Initialized
INFO - 2018-02-06 06:55:50 --> Helper loaded: url_helper
INFO - 2018-02-06 06:55:50 --> Helper loaded: form_helper
INFO - 2018-02-06 06:55:50 --> Database Driver Class Initialized
DEBUG - 2018-02-06 06:55:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 06:55:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 06:55:50 --> Form Validation Class Initialized
INFO - 2018-02-06 06:55:50 --> Model Class Initialized
INFO - 2018-02-06 06:55:50 --> Controller Class Initialized
INFO - 2018-02-06 06:55:50 --> Model Class Initialized
DEBUG - 2018-02-06 06:55:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 06:55:52 --> Config Class Initialized
INFO - 2018-02-06 06:55:52 --> Hooks Class Initialized
DEBUG - 2018-02-06 06:55:52 --> UTF-8 Support Enabled
INFO - 2018-02-06 06:55:52 --> Utf8 Class Initialized
INFO - 2018-02-06 06:55:52 --> URI Class Initialized
INFO - 2018-02-06 06:55:52 --> Router Class Initialized
INFO - 2018-02-06 06:55:52 --> Output Class Initialized
INFO - 2018-02-06 06:55:52 --> Security Class Initialized
DEBUG - 2018-02-06 06:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 06:55:52 --> Input Class Initialized
INFO - 2018-02-06 06:55:52 --> Language Class Initialized
INFO - 2018-02-06 06:55:52 --> Loader Class Initialized
INFO - 2018-02-06 06:55:52 --> Helper loaded: url_helper
INFO - 2018-02-06 06:55:52 --> Helper loaded: form_helper
INFO - 2018-02-06 06:55:52 --> Database Driver Class Initialized
DEBUG - 2018-02-06 06:55:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 06:55:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 06:55:52 --> Form Validation Class Initialized
INFO - 2018-02-06 06:55:52 --> Model Class Initialized
INFO - 2018-02-06 06:55:52 --> Controller Class Initialized
INFO - 2018-02-06 06:55:52 --> Model Class Initialized
DEBUG - 2018-02-06 06:55:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 06:55:52 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 06:55:52 --> Final output sent to browser
DEBUG - 2018-02-06 06:55:52 --> Total execution time: 0.0393
INFO - 2018-02-06 06:55:52 --> Config Class Initialized
INFO - 2018-02-06 06:55:52 --> Hooks Class Initialized
DEBUG - 2018-02-06 06:55:52 --> UTF-8 Support Enabled
INFO - 2018-02-06 06:55:52 --> Utf8 Class Initialized
INFO - 2018-02-06 06:55:52 --> URI Class Initialized
INFO - 2018-02-06 06:55:52 --> Router Class Initialized
INFO - 2018-02-06 06:55:52 --> Output Class Initialized
INFO - 2018-02-06 06:55:52 --> Security Class Initialized
DEBUG - 2018-02-06 06:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 06:55:52 --> Input Class Initialized
INFO - 2018-02-06 06:55:52 --> Language Class Initialized
INFO - 2018-02-06 06:55:52 --> Loader Class Initialized
INFO - 2018-02-06 06:55:52 --> Helper loaded: url_helper
INFO - 2018-02-06 06:55:52 --> Helper loaded: form_helper
INFO - 2018-02-06 06:55:52 --> Database Driver Class Initialized
DEBUG - 2018-02-06 06:55:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 06:55:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 06:55:52 --> Form Validation Class Initialized
INFO - 2018-02-06 06:55:52 --> Model Class Initialized
INFO - 2018-02-06 06:55:52 --> Controller Class Initialized
INFO - 2018-02-06 06:55:52 --> Model Class Initialized
DEBUG - 2018-02-06 06:55:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 06:55:54 --> Config Class Initialized
INFO - 2018-02-06 06:55:54 --> Hooks Class Initialized
DEBUG - 2018-02-06 06:55:54 --> UTF-8 Support Enabled
INFO - 2018-02-06 06:55:54 --> Utf8 Class Initialized
INFO - 2018-02-06 06:55:54 --> URI Class Initialized
INFO - 2018-02-06 06:55:54 --> Router Class Initialized
INFO - 2018-02-06 06:55:54 --> Output Class Initialized
INFO - 2018-02-06 06:55:54 --> Security Class Initialized
DEBUG - 2018-02-06 06:55:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 06:55:54 --> Input Class Initialized
INFO - 2018-02-06 06:55:54 --> Language Class Initialized
INFO - 2018-02-06 06:55:54 --> Loader Class Initialized
INFO - 2018-02-06 06:55:54 --> Helper loaded: url_helper
INFO - 2018-02-06 06:55:54 --> Helper loaded: form_helper
INFO - 2018-02-06 06:55:54 --> Database Driver Class Initialized
DEBUG - 2018-02-06 06:55:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 06:55:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 06:55:54 --> Form Validation Class Initialized
INFO - 2018-02-06 06:55:54 --> Model Class Initialized
INFO - 2018-02-06 06:55:54 --> Controller Class Initialized
INFO - 2018-02-06 06:55:54 --> Model Class Initialized
DEBUG - 2018-02-06 06:55:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 06:55:54 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 06:55:54 --> Final output sent to browser
DEBUG - 2018-02-06 06:55:54 --> Total execution time: 0.0390
INFO - 2018-02-06 06:55:54 --> Config Class Initialized
INFO - 2018-02-06 06:55:54 --> Hooks Class Initialized
DEBUG - 2018-02-06 06:55:54 --> UTF-8 Support Enabled
INFO - 2018-02-06 06:55:54 --> Utf8 Class Initialized
INFO - 2018-02-06 06:55:54 --> URI Class Initialized
INFO - 2018-02-06 06:55:54 --> Router Class Initialized
INFO - 2018-02-06 06:55:54 --> Output Class Initialized
INFO - 2018-02-06 06:55:54 --> Security Class Initialized
DEBUG - 2018-02-06 06:55:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 06:55:54 --> Input Class Initialized
INFO - 2018-02-06 06:55:54 --> Language Class Initialized
INFO - 2018-02-06 06:55:54 --> Loader Class Initialized
INFO - 2018-02-06 06:55:54 --> Helper loaded: url_helper
INFO - 2018-02-06 06:55:54 --> Helper loaded: form_helper
INFO - 2018-02-06 06:55:54 --> Database Driver Class Initialized
DEBUG - 2018-02-06 06:55:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 06:55:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 06:55:54 --> Form Validation Class Initialized
INFO - 2018-02-06 06:55:54 --> Model Class Initialized
INFO - 2018-02-06 06:55:54 --> Controller Class Initialized
INFO - 2018-02-06 06:55:54 --> Model Class Initialized
DEBUG - 2018-02-06 06:55:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 06:55:54 --> Config Class Initialized
INFO - 2018-02-06 06:55:54 --> Hooks Class Initialized
DEBUG - 2018-02-06 06:55:54 --> UTF-8 Support Enabled
INFO - 2018-02-06 06:55:54 --> Utf8 Class Initialized
INFO - 2018-02-06 06:55:54 --> URI Class Initialized
INFO - 2018-02-06 06:55:54 --> Router Class Initialized
INFO - 2018-02-06 06:55:54 --> Output Class Initialized
INFO - 2018-02-06 06:55:54 --> Security Class Initialized
DEBUG - 2018-02-06 06:55:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 06:55:54 --> Input Class Initialized
INFO - 2018-02-06 06:55:54 --> Language Class Initialized
INFO - 2018-02-06 06:55:54 --> Loader Class Initialized
INFO - 2018-02-06 06:55:54 --> Helper loaded: url_helper
INFO - 2018-02-06 06:55:54 --> Helper loaded: form_helper
INFO - 2018-02-06 06:55:54 --> Database Driver Class Initialized
DEBUG - 2018-02-06 06:55:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 06:55:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 06:55:54 --> Form Validation Class Initialized
INFO - 2018-02-06 06:55:54 --> Model Class Initialized
INFO - 2018-02-06 06:55:54 --> Controller Class Initialized
INFO - 2018-02-06 06:55:54 --> Model Class Initialized
DEBUG - 2018-02-06 06:55:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 06:55:54 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 06:55:54 --> Final output sent to browser
DEBUG - 2018-02-06 06:55:54 --> Total execution time: 0.0482
INFO - 2018-02-06 06:55:54 --> Config Class Initialized
INFO - 2018-02-06 06:55:54 --> Hooks Class Initialized
DEBUG - 2018-02-06 06:55:54 --> UTF-8 Support Enabled
INFO - 2018-02-06 06:55:54 --> Utf8 Class Initialized
INFO - 2018-02-06 06:55:54 --> URI Class Initialized
INFO - 2018-02-06 06:55:54 --> Router Class Initialized
INFO - 2018-02-06 06:55:54 --> Output Class Initialized
INFO - 2018-02-06 06:55:54 --> Security Class Initialized
DEBUG - 2018-02-06 06:55:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 06:55:54 --> Input Class Initialized
INFO - 2018-02-06 06:55:54 --> Language Class Initialized
INFO - 2018-02-06 06:55:54 --> Loader Class Initialized
INFO - 2018-02-06 06:55:54 --> Helper loaded: url_helper
INFO - 2018-02-06 06:55:54 --> Helper loaded: form_helper
INFO - 2018-02-06 06:55:54 --> Database Driver Class Initialized
DEBUG - 2018-02-06 06:55:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 06:55:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 06:55:54 --> Form Validation Class Initialized
INFO - 2018-02-06 06:55:54 --> Model Class Initialized
INFO - 2018-02-06 06:55:54 --> Controller Class Initialized
INFO - 2018-02-06 06:55:54 --> Model Class Initialized
DEBUG - 2018-02-06 06:55:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:06:04 --> Config Class Initialized
INFO - 2018-02-06 07:06:04 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:06:04 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:06:04 --> Utf8 Class Initialized
INFO - 2018-02-06 07:06:04 --> URI Class Initialized
INFO - 2018-02-06 07:06:04 --> Router Class Initialized
INFO - 2018-02-06 07:06:04 --> Output Class Initialized
INFO - 2018-02-06 07:06:04 --> Security Class Initialized
DEBUG - 2018-02-06 07:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:06:04 --> Input Class Initialized
INFO - 2018-02-06 07:06:04 --> Language Class Initialized
INFO - 2018-02-06 07:06:04 --> Loader Class Initialized
INFO - 2018-02-06 07:06:04 --> Helper loaded: url_helper
INFO - 2018-02-06 07:06:04 --> Helper loaded: form_helper
INFO - 2018-02-06 07:06:04 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:06:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:06:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:06:04 --> Form Validation Class Initialized
INFO - 2018-02-06 07:06:04 --> Model Class Initialized
INFO - 2018-02-06 07:06:04 --> Controller Class Initialized
INFO - 2018-02-06 07:06:04 --> Model Class Initialized
DEBUG - 2018-02-06 07:06:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:06:04 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:06:04 --> Final output sent to browser
DEBUG - 2018-02-06 07:06:04 --> Total execution time: 0.0455
INFO - 2018-02-06 07:06:40 --> Config Class Initialized
INFO - 2018-02-06 07:06:40 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:06:40 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:06:40 --> Utf8 Class Initialized
INFO - 2018-02-06 07:06:40 --> URI Class Initialized
INFO - 2018-02-06 07:06:40 --> Router Class Initialized
INFO - 2018-02-06 07:06:40 --> Output Class Initialized
INFO - 2018-02-06 07:06:40 --> Security Class Initialized
DEBUG - 2018-02-06 07:06:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:06:40 --> Input Class Initialized
INFO - 2018-02-06 07:06:40 --> Language Class Initialized
INFO - 2018-02-06 07:06:40 --> Loader Class Initialized
INFO - 2018-02-06 07:06:40 --> Helper loaded: url_helper
INFO - 2018-02-06 07:06:40 --> Helper loaded: form_helper
INFO - 2018-02-06 07:06:40 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:06:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:06:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:06:40 --> Form Validation Class Initialized
INFO - 2018-02-06 07:06:40 --> Model Class Initialized
INFO - 2018-02-06 07:06:40 --> Controller Class Initialized
INFO - 2018-02-06 07:06:40 --> Model Class Initialized
DEBUG - 2018-02-06 07:06:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:06:41 --> Model Class Initialized
INFO - 2018-02-06 07:06:41 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:06:41 --> Final output sent to browser
DEBUG - 2018-02-06 07:06:41 --> Total execution time: 0.4645
INFO - 2018-02-06 07:06:43 --> Config Class Initialized
INFO - 2018-02-06 07:06:43 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:06:43 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:06:43 --> Utf8 Class Initialized
INFO - 2018-02-06 07:06:43 --> URI Class Initialized
INFO - 2018-02-06 07:06:43 --> Router Class Initialized
INFO - 2018-02-06 07:06:43 --> Output Class Initialized
INFO - 2018-02-06 07:06:43 --> Security Class Initialized
DEBUG - 2018-02-06 07:06:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:06:43 --> Input Class Initialized
INFO - 2018-02-06 07:06:43 --> Language Class Initialized
INFO - 2018-02-06 07:06:43 --> Loader Class Initialized
INFO - 2018-02-06 07:06:43 --> Helper loaded: url_helper
INFO - 2018-02-06 07:06:43 --> Helper loaded: form_helper
INFO - 2018-02-06 07:06:43 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:06:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:06:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:06:43 --> Form Validation Class Initialized
INFO - 2018-02-06 07:06:43 --> Model Class Initialized
INFO - 2018-02-06 07:06:43 --> Controller Class Initialized
INFO - 2018-02-06 07:06:43 --> Model Class Initialized
DEBUG - 2018-02-06 07:06:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:06:43 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:06:43 --> Final output sent to browser
DEBUG - 2018-02-06 07:06:43 --> Total execution time: 0.0514
INFO - 2018-02-06 07:06:43 --> Config Class Initialized
INFO - 2018-02-06 07:06:43 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:06:43 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:06:43 --> Utf8 Class Initialized
INFO - 2018-02-06 07:06:43 --> URI Class Initialized
INFO - 2018-02-06 07:06:43 --> Router Class Initialized
INFO - 2018-02-06 07:06:43 --> Output Class Initialized
INFO - 2018-02-06 07:06:43 --> Security Class Initialized
DEBUG - 2018-02-06 07:06:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:06:43 --> Input Class Initialized
INFO - 2018-02-06 07:06:43 --> Language Class Initialized
INFO - 2018-02-06 07:06:43 --> Loader Class Initialized
INFO - 2018-02-06 07:06:43 --> Helper loaded: url_helper
INFO - 2018-02-06 07:06:43 --> Helper loaded: form_helper
INFO - 2018-02-06 07:06:43 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:06:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:06:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:06:43 --> Form Validation Class Initialized
INFO - 2018-02-06 07:06:43 --> Model Class Initialized
INFO - 2018-02-06 07:06:43 --> Controller Class Initialized
INFO - 2018-02-06 07:06:43 --> Model Class Initialized
DEBUG - 2018-02-06 07:06:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:06:54 --> Config Class Initialized
INFO - 2018-02-06 07:06:54 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:06:54 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:06:54 --> Utf8 Class Initialized
INFO - 2018-02-06 07:06:54 --> URI Class Initialized
INFO - 2018-02-06 07:06:54 --> Router Class Initialized
INFO - 2018-02-06 07:06:54 --> Output Class Initialized
INFO - 2018-02-06 07:06:54 --> Security Class Initialized
DEBUG - 2018-02-06 07:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:06:54 --> Input Class Initialized
INFO - 2018-02-06 07:06:54 --> Language Class Initialized
INFO - 2018-02-06 07:06:54 --> Loader Class Initialized
INFO - 2018-02-06 07:06:54 --> Helper loaded: url_helper
INFO - 2018-02-06 07:06:54 --> Helper loaded: form_helper
INFO - 2018-02-06 07:06:54 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:06:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:06:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:06:54 --> Form Validation Class Initialized
INFO - 2018-02-06 07:06:54 --> Model Class Initialized
INFO - 2018-02-06 07:06:54 --> Controller Class Initialized
INFO - 2018-02-06 07:06:54 --> Model Class Initialized
DEBUG - 2018-02-06 07:06:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:06:56 --> Config Class Initialized
INFO - 2018-02-06 07:06:56 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:06:56 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:06:56 --> Utf8 Class Initialized
INFO - 2018-02-06 07:06:56 --> URI Class Initialized
INFO - 2018-02-06 07:06:56 --> Router Class Initialized
INFO - 2018-02-06 07:06:56 --> Output Class Initialized
INFO - 2018-02-06 07:06:56 --> Security Class Initialized
DEBUG - 2018-02-06 07:06:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:06:56 --> Input Class Initialized
INFO - 2018-02-06 07:06:56 --> Language Class Initialized
INFO - 2018-02-06 07:06:56 --> Loader Class Initialized
INFO - 2018-02-06 07:06:56 --> Helper loaded: url_helper
INFO - 2018-02-06 07:06:56 --> Helper loaded: form_helper
INFO - 2018-02-06 07:06:56 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:06:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:06:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:06:56 --> Form Validation Class Initialized
INFO - 2018-02-06 07:06:56 --> Model Class Initialized
INFO - 2018-02-06 07:06:56 --> Controller Class Initialized
INFO - 2018-02-06 07:06:56 --> Model Class Initialized
DEBUG - 2018-02-06 07:06:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:06:59 --> Config Class Initialized
INFO - 2018-02-06 07:06:59 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:06:59 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:06:59 --> Utf8 Class Initialized
INFO - 2018-02-06 07:06:59 --> URI Class Initialized
INFO - 2018-02-06 07:06:59 --> Router Class Initialized
INFO - 2018-02-06 07:06:59 --> Output Class Initialized
INFO - 2018-02-06 07:06:59 --> Security Class Initialized
DEBUG - 2018-02-06 07:06:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:06:59 --> Input Class Initialized
INFO - 2018-02-06 07:06:59 --> Language Class Initialized
INFO - 2018-02-06 07:06:59 --> Loader Class Initialized
INFO - 2018-02-06 07:06:59 --> Helper loaded: url_helper
INFO - 2018-02-06 07:06:59 --> Helper loaded: form_helper
INFO - 2018-02-06 07:06:59 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:06:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:06:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:06:59 --> Form Validation Class Initialized
INFO - 2018-02-06 07:06:59 --> Model Class Initialized
INFO - 2018-02-06 07:06:59 --> Controller Class Initialized
INFO - 2018-02-06 07:06:59 --> Model Class Initialized
DEBUG - 2018-02-06 07:06:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:07:02 --> Config Class Initialized
INFO - 2018-02-06 07:07:02 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:07:02 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:07:02 --> Utf8 Class Initialized
INFO - 2018-02-06 07:07:02 --> URI Class Initialized
INFO - 2018-02-06 07:07:02 --> Router Class Initialized
INFO - 2018-02-06 07:07:02 --> Output Class Initialized
INFO - 2018-02-06 07:07:02 --> Security Class Initialized
DEBUG - 2018-02-06 07:07:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:07:02 --> Input Class Initialized
INFO - 2018-02-06 07:07:02 --> Language Class Initialized
INFO - 2018-02-06 07:07:02 --> Loader Class Initialized
INFO - 2018-02-06 07:07:02 --> Helper loaded: url_helper
INFO - 2018-02-06 07:07:02 --> Helper loaded: form_helper
INFO - 2018-02-06 07:07:02 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:07:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:07:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:07:02 --> Form Validation Class Initialized
INFO - 2018-02-06 07:07:02 --> Model Class Initialized
INFO - 2018-02-06 07:07:02 --> Controller Class Initialized
INFO - 2018-02-06 07:07:02 --> Model Class Initialized
DEBUG - 2018-02-06 07:07:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:07:05 --> Config Class Initialized
INFO - 2018-02-06 07:07:05 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:07:05 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:07:05 --> Utf8 Class Initialized
INFO - 2018-02-06 07:07:05 --> URI Class Initialized
INFO - 2018-02-06 07:07:05 --> Router Class Initialized
INFO - 2018-02-06 07:07:05 --> Output Class Initialized
INFO - 2018-02-06 07:07:05 --> Security Class Initialized
DEBUG - 2018-02-06 07:07:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:07:05 --> Input Class Initialized
INFO - 2018-02-06 07:07:05 --> Language Class Initialized
INFO - 2018-02-06 07:07:05 --> Loader Class Initialized
INFO - 2018-02-06 07:07:05 --> Helper loaded: url_helper
INFO - 2018-02-06 07:07:05 --> Helper loaded: form_helper
INFO - 2018-02-06 07:07:05 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:07:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:07:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:07:05 --> Form Validation Class Initialized
INFO - 2018-02-06 07:07:05 --> Model Class Initialized
INFO - 2018-02-06 07:07:05 --> Controller Class Initialized
INFO - 2018-02-06 07:07:05 --> Model Class Initialized
DEBUG - 2018-02-06 07:07:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:07:07 --> Config Class Initialized
INFO - 2018-02-06 07:07:07 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:07:07 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:07:07 --> Utf8 Class Initialized
INFO - 2018-02-06 07:07:07 --> URI Class Initialized
INFO - 2018-02-06 07:07:07 --> Router Class Initialized
INFO - 2018-02-06 07:07:07 --> Output Class Initialized
INFO - 2018-02-06 07:07:07 --> Security Class Initialized
DEBUG - 2018-02-06 07:07:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:07:07 --> Input Class Initialized
INFO - 2018-02-06 07:07:07 --> Language Class Initialized
INFO - 2018-02-06 07:07:07 --> Loader Class Initialized
INFO - 2018-02-06 07:07:07 --> Helper loaded: url_helper
INFO - 2018-02-06 07:07:07 --> Helper loaded: form_helper
INFO - 2018-02-06 07:07:07 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:07:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:07:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:07:07 --> Form Validation Class Initialized
INFO - 2018-02-06 07:07:07 --> Model Class Initialized
INFO - 2018-02-06 07:07:07 --> Controller Class Initialized
INFO - 2018-02-06 07:07:07 --> Model Class Initialized
DEBUG - 2018-02-06 07:07:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:07:09 --> Config Class Initialized
INFO - 2018-02-06 07:07:09 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:07:09 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:07:09 --> Utf8 Class Initialized
INFO - 2018-02-06 07:07:09 --> URI Class Initialized
INFO - 2018-02-06 07:07:09 --> Router Class Initialized
INFO - 2018-02-06 07:07:09 --> Output Class Initialized
INFO - 2018-02-06 07:07:09 --> Security Class Initialized
DEBUG - 2018-02-06 07:07:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:07:09 --> Input Class Initialized
INFO - 2018-02-06 07:07:09 --> Language Class Initialized
INFO - 2018-02-06 07:07:09 --> Loader Class Initialized
INFO - 2018-02-06 07:07:09 --> Helper loaded: url_helper
INFO - 2018-02-06 07:07:09 --> Helper loaded: form_helper
INFO - 2018-02-06 07:07:09 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:07:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:07:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:07:09 --> Form Validation Class Initialized
INFO - 2018-02-06 07:07:09 --> Model Class Initialized
INFO - 2018-02-06 07:07:09 --> Controller Class Initialized
INFO - 2018-02-06 07:07:09 --> Model Class Initialized
DEBUG - 2018-02-06 07:07:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:07:11 --> Config Class Initialized
INFO - 2018-02-06 07:07:11 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:07:11 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:07:11 --> Utf8 Class Initialized
INFO - 2018-02-06 07:07:11 --> URI Class Initialized
INFO - 2018-02-06 07:07:11 --> Router Class Initialized
INFO - 2018-02-06 07:07:11 --> Output Class Initialized
INFO - 2018-02-06 07:07:11 --> Security Class Initialized
DEBUG - 2018-02-06 07:07:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:07:11 --> Input Class Initialized
INFO - 2018-02-06 07:07:11 --> Language Class Initialized
INFO - 2018-02-06 07:07:11 --> Loader Class Initialized
INFO - 2018-02-06 07:07:11 --> Helper loaded: url_helper
INFO - 2018-02-06 07:07:11 --> Helper loaded: form_helper
INFO - 2018-02-06 07:07:11 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:07:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:07:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:07:11 --> Form Validation Class Initialized
INFO - 2018-02-06 07:07:11 --> Model Class Initialized
INFO - 2018-02-06 07:07:11 --> Controller Class Initialized
INFO - 2018-02-06 07:07:11 --> Model Class Initialized
DEBUG - 2018-02-06 07:07:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:07:14 --> Config Class Initialized
INFO - 2018-02-06 07:07:14 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:07:14 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:07:14 --> Utf8 Class Initialized
INFO - 2018-02-06 07:07:14 --> URI Class Initialized
INFO - 2018-02-06 07:07:14 --> Router Class Initialized
INFO - 2018-02-06 07:07:14 --> Output Class Initialized
INFO - 2018-02-06 07:07:14 --> Security Class Initialized
DEBUG - 2018-02-06 07:07:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:07:14 --> Input Class Initialized
INFO - 2018-02-06 07:07:14 --> Language Class Initialized
INFO - 2018-02-06 07:07:14 --> Loader Class Initialized
INFO - 2018-02-06 07:07:14 --> Helper loaded: url_helper
INFO - 2018-02-06 07:07:14 --> Helper loaded: form_helper
INFO - 2018-02-06 07:07:14 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:07:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:07:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:07:14 --> Form Validation Class Initialized
INFO - 2018-02-06 07:07:14 --> Model Class Initialized
INFO - 2018-02-06 07:07:14 --> Controller Class Initialized
INFO - 2018-02-06 07:07:14 --> Model Class Initialized
DEBUG - 2018-02-06 07:07:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:07:19 --> Config Class Initialized
INFO - 2018-02-06 07:07:19 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:07:19 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:07:19 --> Utf8 Class Initialized
INFO - 2018-02-06 07:07:19 --> URI Class Initialized
INFO - 2018-02-06 07:07:19 --> Router Class Initialized
INFO - 2018-02-06 07:07:19 --> Output Class Initialized
INFO - 2018-02-06 07:07:19 --> Security Class Initialized
DEBUG - 2018-02-06 07:07:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:07:19 --> Input Class Initialized
INFO - 2018-02-06 07:07:19 --> Language Class Initialized
INFO - 2018-02-06 07:07:19 --> Loader Class Initialized
INFO - 2018-02-06 07:07:19 --> Helper loaded: url_helper
INFO - 2018-02-06 07:07:19 --> Helper loaded: form_helper
INFO - 2018-02-06 07:07:19 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:07:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:07:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:07:19 --> Form Validation Class Initialized
INFO - 2018-02-06 07:07:19 --> Model Class Initialized
INFO - 2018-02-06 07:07:19 --> Controller Class Initialized
INFO - 2018-02-06 07:07:19 --> Model Class Initialized
DEBUG - 2018-02-06 07:07:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:07:21 --> Config Class Initialized
INFO - 2018-02-06 07:07:21 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:07:21 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:07:21 --> Utf8 Class Initialized
INFO - 2018-02-06 07:07:21 --> URI Class Initialized
INFO - 2018-02-06 07:07:21 --> Router Class Initialized
INFO - 2018-02-06 07:07:21 --> Output Class Initialized
INFO - 2018-02-06 07:07:21 --> Security Class Initialized
DEBUG - 2018-02-06 07:07:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:07:21 --> Input Class Initialized
INFO - 2018-02-06 07:07:21 --> Language Class Initialized
INFO - 2018-02-06 07:07:21 --> Loader Class Initialized
INFO - 2018-02-06 07:07:21 --> Helper loaded: url_helper
INFO - 2018-02-06 07:07:21 --> Helper loaded: form_helper
INFO - 2018-02-06 07:07:21 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:07:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:07:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:07:21 --> Form Validation Class Initialized
INFO - 2018-02-06 07:07:21 --> Model Class Initialized
INFO - 2018-02-06 07:07:21 --> Controller Class Initialized
INFO - 2018-02-06 07:07:21 --> Model Class Initialized
DEBUG - 2018-02-06 07:07:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:07:26 --> Config Class Initialized
INFO - 2018-02-06 07:07:26 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:07:26 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:07:26 --> Utf8 Class Initialized
INFO - 2018-02-06 07:07:26 --> URI Class Initialized
INFO - 2018-02-06 07:07:26 --> Router Class Initialized
INFO - 2018-02-06 07:07:26 --> Output Class Initialized
INFO - 2018-02-06 07:07:26 --> Security Class Initialized
DEBUG - 2018-02-06 07:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:07:26 --> Input Class Initialized
INFO - 2018-02-06 07:07:26 --> Language Class Initialized
INFO - 2018-02-06 07:07:26 --> Loader Class Initialized
INFO - 2018-02-06 07:07:26 --> Helper loaded: url_helper
INFO - 2018-02-06 07:07:26 --> Helper loaded: form_helper
INFO - 2018-02-06 07:07:26 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:07:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:07:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:07:26 --> Form Validation Class Initialized
INFO - 2018-02-06 07:07:26 --> Model Class Initialized
INFO - 2018-02-06 07:07:26 --> Controller Class Initialized
INFO - 2018-02-06 07:07:26 --> Model Class Initialized
DEBUG - 2018-02-06 07:07:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:07:28 --> Config Class Initialized
INFO - 2018-02-06 07:07:28 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:07:28 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:07:28 --> Utf8 Class Initialized
INFO - 2018-02-06 07:07:28 --> URI Class Initialized
INFO - 2018-02-06 07:07:28 --> Router Class Initialized
INFO - 2018-02-06 07:07:28 --> Output Class Initialized
INFO - 2018-02-06 07:07:28 --> Security Class Initialized
DEBUG - 2018-02-06 07:07:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:07:28 --> Input Class Initialized
INFO - 2018-02-06 07:07:28 --> Language Class Initialized
INFO - 2018-02-06 07:07:28 --> Loader Class Initialized
INFO - 2018-02-06 07:07:28 --> Helper loaded: url_helper
INFO - 2018-02-06 07:07:28 --> Helper loaded: form_helper
INFO - 2018-02-06 07:07:28 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:07:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:07:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:07:28 --> Form Validation Class Initialized
INFO - 2018-02-06 07:07:28 --> Model Class Initialized
INFO - 2018-02-06 07:07:28 --> Controller Class Initialized
INFO - 2018-02-06 07:07:28 --> Model Class Initialized
DEBUG - 2018-02-06 07:07:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:07:29 --> Config Class Initialized
INFO - 2018-02-06 07:07:29 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:07:29 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:07:29 --> Utf8 Class Initialized
INFO - 2018-02-06 07:07:29 --> URI Class Initialized
INFO - 2018-02-06 07:07:29 --> Router Class Initialized
INFO - 2018-02-06 07:07:29 --> Output Class Initialized
INFO - 2018-02-06 07:07:29 --> Security Class Initialized
DEBUG - 2018-02-06 07:07:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:07:29 --> Input Class Initialized
INFO - 2018-02-06 07:07:29 --> Language Class Initialized
INFO - 2018-02-06 07:07:29 --> Loader Class Initialized
INFO - 2018-02-06 07:07:29 --> Helper loaded: url_helper
INFO - 2018-02-06 07:07:29 --> Helper loaded: form_helper
INFO - 2018-02-06 07:07:29 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:07:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:07:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:07:29 --> Form Validation Class Initialized
INFO - 2018-02-06 07:07:29 --> Model Class Initialized
INFO - 2018-02-06 07:07:29 --> Controller Class Initialized
INFO - 2018-02-06 07:07:29 --> Model Class Initialized
DEBUG - 2018-02-06 07:07:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:07:33 --> Config Class Initialized
INFO - 2018-02-06 07:07:33 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:07:33 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:07:33 --> Utf8 Class Initialized
INFO - 2018-02-06 07:07:33 --> URI Class Initialized
INFO - 2018-02-06 07:07:33 --> Router Class Initialized
INFO - 2018-02-06 07:07:33 --> Output Class Initialized
INFO - 2018-02-06 07:07:33 --> Security Class Initialized
DEBUG - 2018-02-06 07:07:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:07:33 --> Input Class Initialized
INFO - 2018-02-06 07:07:33 --> Language Class Initialized
INFO - 2018-02-06 07:07:33 --> Loader Class Initialized
INFO - 2018-02-06 07:07:33 --> Helper loaded: url_helper
INFO - 2018-02-06 07:07:33 --> Helper loaded: form_helper
INFO - 2018-02-06 07:07:33 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:07:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:07:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:07:33 --> Form Validation Class Initialized
INFO - 2018-02-06 07:07:33 --> Model Class Initialized
INFO - 2018-02-06 07:07:33 --> Controller Class Initialized
INFO - 2018-02-06 07:07:33 --> Model Class Initialized
DEBUG - 2018-02-06 07:07:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:07:37 --> Config Class Initialized
INFO - 2018-02-06 07:07:37 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:07:37 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:07:37 --> Utf8 Class Initialized
INFO - 2018-02-06 07:07:37 --> URI Class Initialized
INFO - 2018-02-06 07:07:37 --> Router Class Initialized
INFO - 2018-02-06 07:07:37 --> Output Class Initialized
INFO - 2018-02-06 07:07:37 --> Security Class Initialized
DEBUG - 2018-02-06 07:07:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:07:37 --> Input Class Initialized
INFO - 2018-02-06 07:07:37 --> Language Class Initialized
INFO - 2018-02-06 07:07:37 --> Loader Class Initialized
INFO - 2018-02-06 07:07:37 --> Helper loaded: url_helper
INFO - 2018-02-06 07:07:37 --> Helper loaded: form_helper
INFO - 2018-02-06 07:07:37 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:07:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:07:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:07:37 --> Form Validation Class Initialized
INFO - 2018-02-06 07:07:37 --> Model Class Initialized
INFO - 2018-02-06 07:07:37 --> Controller Class Initialized
INFO - 2018-02-06 07:07:37 --> Model Class Initialized
DEBUG - 2018-02-06 07:07:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:07:39 --> Config Class Initialized
INFO - 2018-02-06 07:07:39 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:07:39 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:07:39 --> Utf8 Class Initialized
INFO - 2018-02-06 07:07:39 --> URI Class Initialized
INFO - 2018-02-06 07:07:39 --> Router Class Initialized
INFO - 2018-02-06 07:07:39 --> Output Class Initialized
INFO - 2018-02-06 07:07:39 --> Security Class Initialized
DEBUG - 2018-02-06 07:07:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:07:39 --> Input Class Initialized
INFO - 2018-02-06 07:07:39 --> Language Class Initialized
INFO - 2018-02-06 07:07:39 --> Loader Class Initialized
INFO - 2018-02-06 07:07:39 --> Helper loaded: url_helper
INFO - 2018-02-06 07:07:39 --> Helper loaded: form_helper
INFO - 2018-02-06 07:07:39 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:07:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:07:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:07:39 --> Form Validation Class Initialized
INFO - 2018-02-06 07:07:39 --> Model Class Initialized
INFO - 2018-02-06 07:07:39 --> Controller Class Initialized
INFO - 2018-02-06 07:07:39 --> Model Class Initialized
DEBUG - 2018-02-06 07:07:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:07:42 --> Config Class Initialized
INFO - 2018-02-06 07:07:42 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:07:42 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:07:42 --> Utf8 Class Initialized
INFO - 2018-02-06 07:07:42 --> URI Class Initialized
INFO - 2018-02-06 07:07:42 --> Router Class Initialized
INFO - 2018-02-06 07:07:42 --> Output Class Initialized
INFO - 2018-02-06 07:07:42 --> Security Class Initialized
DEBUG - 2018-02-06 07:07:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:07:42 --> Input Class Initialized
INFO - 2018-02-06 07:07:42 --> Language Class Initialized
INFO - 2018-02-06 07:07:42 --> Loader Class Initialized
INFO - 2018-02-06 07:07:42 --> Helper loaded: url_helper
INFO - 2018-02-06 07:07:42 --> Helper loaded: form_helper
INFO - 2018-02-06 07:07:42 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:07:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:07:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:07:42 --> Form Validation Class Initialized
INFO - 2018-02-06 07:07:42 --> Model Class Initialized
INFO - 2018-02-06 07:07:42 --> Controller Class Initialized
INFO - 2018-02-06 07:07:42 --> Model Class Initialized
DEBUG - 2018-02-06 07:07:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:07:46 --> Config Class Initialized
INFO - 2018-02-06 07:07:46 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:07:46 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:07:46 --> Utf8 Class Initialized
INFO - 2018-02-06 07:07:46 --> URI Class Initialized
INFO - 2018-02-06 07:07:46 --> Router Class Initialized
INFO - 2018-02-06 07:07:46 --> Output Class Initialized
INFO - 2018-02-06 07:07:46 --> Security Class Initialized
DEBUG - 2018-02-06 07:07:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:07:46 --> Input Class Initialized
INFO - 2018-02-06 07:07:46 --> Language Class Initialized
INFO - 2018-02-06 07:07:46 --> Loader Class Initialized
INFO - 2018-02-06 07:07:46 --> Helper loaded: url_helper
INFO - 2018-02-06 07:07:46 --> Helper loaded: form_helper
INFO - 2018-02-06 07:07:46 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:07:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:07:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:07:46 --> Form Validation Class Initialized
INFO - 2018-02-06 07:07:46 --> Model Class Initialized
INFO - 2018-02-06 07:07:46 --> Controller Class Initialized
INFO - 2018-02-06 07:07:46 --> Model Class Initialized
DEBUG - 2018-02-06 07:07:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:08:51 --> Config Class Initialized
INFO - 2018-02-06 07:08:51 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:08:51 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:08:51 --> Utf8 Class Initialized
INFO - 2018-02-06 07:08:51 --> URI Class Initialized
INFO - 2018-02-06 07:08:51 --> Router Class Initialized
INFO - 2018-02-06 07:08:51 --> Output Class Initialized
INFO - 2018-02-06 07:08:51 --> Security Class Initialized
DEBUG - 2018-02-06 07:08:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:08:51 --> Input Class Initialized
INFO - 2018-02-06 07:08:51 --> Language Class Initialized
INFO - 2018-02-06 07:08:51 --> Loader Class Initialized
INFO - 2018-02-06 07:08:51 --> Helper loaded: url_helper
INFO - 2018-02-06 07:08:51 --> Helper loaded: form_helper
INFO - 2018-02-06 07:08:51 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:08:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:08:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:08:51 --> Form Validation Class Initialized
INFO - 2018-02-06 07:08:51 --> Model Class Initialized
INFO - 2018-02-06 07:08:51 --> Controller Class Initialized
INFO - 2018-02-06 07:08:51 --> Model Class Initialized
DEBUG - 2018-02-06 07:08:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:08:51 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:08:51 --> Final output sent to browser
DEBUG - 2018-02-06 07:08:51 --> Total execution time: 0.0574
INFO - 2018-02-06 07:08:51 --> Config Class Initialized
INFO - 2018-02-06 07:08:51 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:08:51 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:08:51 --> Utf8 Class Initialized
INFO - 2018-02-06 07:08:51 --> URI Class Initialized
INFO - 2018-02-06 07:08:51 --> Router Class Initialized
INFO - 2018-02-06 07:08:51 --> Output Class Initialized
INFO - 2018-02-06 07:08:51 --> Security Class Initialized
DEBUG - 2018-02-06 07:08:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:08:51 --> Input Class Initialized
INFO - 2018-02-06 07:08:51 --> Language Class Initialized
INFO - 2018-02-06 07:08:51 --> Loader Class Initialized
INFO - 2018-02-06 07:08:51 --> Helper loaded: url_helper
INFO - 2018-02-06 07:08:51 --> Helper loaded: form_helper
INFO - 2018-02-06 07:08:51 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:08:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:08:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:08:51 --> Form Validation Class Initialized
INFO - 2018-02-06 07:08:51 --> Model Class Initialized
INFO - 2018-02-06 07:08:51 --> Controller Class Initialized
INFO - 2018-02-06 07:08:51 --> Model Class Initialized
DEBUG - 2018-02-06 07:08:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:08:56 --> Config Class Initialized
INFO - 2018-02-06 07:08:56 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:08:56 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:08:56 --> Utf8 Class Initialized
INFO - 2018-02-06 07:08:56 --> URI Class Initialized
INFO - 2018-02-06 07:08:56 --> Router Class Initialized
INFO - 2018-02-06 07:08:56 --> Output Class Initialized
INFO - 2018-02-06 07:08:56 --> Security Class Initialized
DEBUG - 2018-02-06 07:08:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:08:56 --> Input Class Initialized
INFO - 2018-02-06 07:08:56 --> Language Class Initialized
INFO - 2018-02-06 07:08:56 --> Loader Class Initialized
INFO - 2018-02-06 07:08:56 --> Helper loaded: url_helper
INFO - 2018-02-06 07:08:56 --> Helper loaded: form_helper
INFO - 2018-02-06 07:08:56 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:08:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:08:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:08:56 --> Form Validation Class Initialized
INFO - 2018-02-06 07:08:56 --> Model Class Initialized
INFO - 2018-02-06 07:08:56 --> Controller Class Initialized
INFO - 2018-02-06 07:08:56 --> Model Class Initialized
DEBUG - 2018-02-06 07:08:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:08:58 --> Config Class Initialized
INFO - 2018-02-06 07:08:58 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:08:58 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:08:58 --> Utf8 Class Initialized
INFO - 2018-02-06 07:08:58 --> URI Class Initialized
INFO - 2018-02-06 07:08:58 --> Router Class Initialized
INFO - 2018-02-06 07:08:58 --> Output Class Initialized
INFO - 2018-02-06 07:08:58 --> Security Class Initialized
DEBUG - 2018-02-06 07:08:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:08:58 --> Input Class Initialized
INFO - 2018-02-06 07:08:58 --> Language Class Initialized
INFO - 2018-02-06 07:08:58 --> Loader Class Initialized
INFO - 2018-02-06 07:08:58 --> Helper loaded: url_helper
INFO - 2018-02-06 07:08:58 --> Helper loaded: form_helper
INFO - 2018-02-06 07:08:58 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:08:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:08:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:08:58 --> Form Validation Class Initialized
INFO - 2018-02-06 07:08:58 --> Model Class Initialized
INFO - 2018-02-06 07:08:58 --> Controller Class Initialized
INFO - 2018-02-06 07:08:58 --> Model Class Initialized
DEBUG - 2018-02-06 07:08:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:09:02 --> Config Class Initialized
INFO - 2018-02-06 07:09:02 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:09:02 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:09:02 --> Utf8 Class Initialized
INFO - 2018-02-06 07:09:02 --> URI Class Initialized
INFO - 2018-02-06 07:09:02 --> Router Class Initialized
INFO - 2018-02-06 07:09:02 --> Output Class Initialized
INFO - 2018-02-06 07:09:02 --> Security Class Initialized
DEBUG - 2018-02-06 07:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:09:02 --> Input Class Initialized
INFO - 2018-02-06 07:09:02 --> Language Class Initialized
INFO - 2018-02-06 07:09:02 --> Loader Class Initialized
INFO - 2018-02-06 07:09:02 --> Helper loaded: url_helper
INFO - 2018-02-06 07:09:02 --> Helper loaded: form_helper
INFO - 2018-02-06 07:09:02 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:09:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:09:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:09:02 --> Form Validation Class Initialized
INFO - 2018-02-06 07:09:02 --> Model Class Initialized
INFO - 2018-02-06 07:09:02 --> Controller Class Initialized
INFO - 2018-02-06 07:09:02 --> Model Class Initialized
DEBUG - 2018-02-06 07:09:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:09:08 --> Config Class Initialized
INFO - 2018-02-06 07:09:08 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:09:08 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:09:08 --> Utf8 Class Initialized
INFO - 2018-02-06 07:09:08 --> URI Class Initialized
INFO - 2018-02-06 07:09:08 --> Router Class Initialized
INFO - 2018-02-06 07:09:08 --> Output Class Initialized
INFO - 2018-02-06 07:09:08 --> Security Class Initialized
DEBUG - 2018-02-06 07:09:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:09:08 --> Input Class Initialized
INFO - 2018-02-06 07:09:08 --> Language Class Initialized
INFO - 2018-02-06 07:09:08 --> Loader Class Initialized
INFO - 2018-02-06 07:09:08 --> Helper loaded: url_helper
INFO - 2018-02-06 07:09:08 --> Helper loaded: form_helper
INFO - 2018-02-06 07:09:08 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:09:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:09:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:09:08 --> Form Validation Class Initialized
INFO - 2018-02-06 07:09:08 --> Model Class Initialized
INFO - 2018-02-06 07:09:08 --> Controller Class Initialized
INFO - 2018-02-06 07:09:08 --> Model Class Initialized
DEBUG - 2018-02-06 07:09:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:09:08 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:09:08 --> Final output sent to browser
DEBUG - 2018-02-06 07:09:08 --> Total execution time: 0.0526
INFO - 2018-02-06 07:09:08 --> Config Class Initialized
INFO - 2018-02-06 07:09:08 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:09:08 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:09:08 --> Utf8 Class Initialized
INFO - 2018-02-06 07:09:08 --> URI Class Initialized
INFO - 2018-02-06 07:09:08 --> Router Class Initialized
INFO - 2018-02-06 07:09:08 --> Output Class Initialized
INFO - 2018-02-06 07:09:08 --> Security Class Initialized
DEBUG - 2018-02-06 07:09:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:09:08 --> Input Class Initialized
INFO - 2018-02-06 07:09:08 --> Language Class Initialized
INFO - 2018-02-06 07:09:08 --> Loader Class Initialized
INFO - 2018-02-06 07:09:08 --> Helper loaded: url_helper
INFO - 2018-02-06 07:09:08 --> Helper loaded: form_helper
INFO - 2018-02-06 07:09:08 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:09:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:09:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:09:08 --> Form Validation Class Initialized
INFO - 2018-02-06 07:09:08 --> Model Class Initialized
INFO - 2018-02-06 07:09:08 --> Controller Class Initialized
INFO - 2018-02-06 07:09:08 --> Model Class Initialized
DEBUG - 2018-02-06 07:09:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:09:12 --> Config Class Initialized
INFO - 2018-02-06 07:09:12 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:09:12 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:09:12 --> Utf8 Class Initialized
INFO - 2018-02-06 07:09:12 --> URI Class Initialized
INFO - 2018-02-06 07:09:12 --> Router Class Initialized
INFO - 2018-02-06 07:09:12 --> Output Class Initialized
INFO - 2018-02-06 07:09:12 --> Security Class Initialized
DEBUG - 2018-02-06 07:09:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:09:12 --> Input Class Initialized
INFO - 2018-02-06 07:09:12 --> Language Class Initialized
INFO - 2018-02-06 07:09:12 --> Loader Class Initialized
INFO - 2018-02-06 07:09:12 --> Helper loaded: url_helper
INFO - 2018-02-06 07:09:12 --> Helper loaded: form_helper
INFO - 2018-02-06 07:09:12 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:09:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:09:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:09:12 --> Form Validation Class Initialized
INFO - 2018-02-06 07:09:12 --> Model Class Initialized
INFO - 2018-02-06 07:09:12 --> Controller Class Initialized
INFO - 2018-02-06 07:09:12 --> Model Class Initialized
DEBUG - 2018-02-06 07:09:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:09:12 --> Config Class Initialized
INFO - 2018-02-06 07:09:12 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:09:12 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:09:12 --> Utf8 Class Initialized
INFO - 2018-02-06 07:09:12 --> URI Class Initialized
INFO - 2018-02-06 07:09:12 --> Router Class Initialized
INFO - 2018-02-06 07:09:12 --> Output Class Initialized
INFO - 2018-02-06 07:09:12 --> Security Class Initialized
DEBUG - 2018-02-06 07:09:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:09:12 --> Input Class Initialized
INFO - 2018-02-06 07:09:12 --> Language Class Initialized
INFO - 2018-02-06 07:09:12 --> Loader Class Initialized
INFO - 2018-02-06 07:09:12 --> Helper loaded: url_helper
INFO - 2018-02-06 07:09:12 --> Helper loaded: form_helper
INFO - 2018-02-06 07:09:12 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:09:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:09:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:09:12 --> Form Validation Class Initialized
INFO - 2018-02-06 07:09:12 --> Model Class Initialized
INFO - 2018-02-06 07:09:12 --> Controller Class Initialized
INFO - 2018-02-06 07:09:12 --> Model Class Initialized
DEBUG - 2018-02-06 07:09:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:09:13 --> Config Class Initialized
INFO - 2018-02-06 07:09:13 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:09:13 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:09:13 --> Utf8 Class Initialized
INFO - 2018-02-06 07:09:13 --> URI Class Initialized
INFO - 2018-02-06 07:09:13 --> Router Class Initialized
INFO - 2018-02-06 07:09:13 --> Output Class Initialized
INFO - 2018-02-06 07:09:13 --> Security Class Initialized
DEBUG - 2018-02-06 07:09:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:09:13 --> Input Class Initialized
INFO - 2018-02-06 07:09:13 --> Language Class Initialized
INFO - 2018-02-06 07:09:13 --> Loader Class Initialized
INFO - 2018-02-06 07:09:13 --> Helper loaded: url_helper
INFO - 2018-02-06 07:09:13 --> Helper loaded: form_helper
INFO - 2018-02-06 07:09:13 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:09:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:09:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:09:13 --> Form Validation Class Initialized
INFO - 2018-02-06 07:09:13 --> Model Class Initialized
INFO - 2018-02-06 07:09:13 --> Controller Class Initialized
INFO - 2018-02-06 07:09:13 --> Model Class Initialized
DEBUG - 2018-02-06 07:09:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:09:15 --> Config Class Initialized
INFO - 2018-02-06 07:09:15 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:09:15 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:09:15 --> Utf8 Class Initialized
INFO - 2018-02-06 07:09:15 --> URI Class Initialized
INFO - 2018-02-06 07:09:15 --> Router Class Initialized
INFO - 2018-02-06 07:09:15 --> Output Class Initialized
INFO - 2018-02-06 07:09:15 --> Security Class Initialized
DEBUG - 2018-02-06 07:09:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:09:15 --> Input Class Initialized
INFO - 2018-02-06 07:09:15 --> Language Class Initialized
INFO - 2018-02-06 07:09:15 --> Loader Class Initialized
INFO - 2018-02-06 07:09:15 --> Helper loaded: url_helper
INFO - 2018-02-06 07:09:15 --> Helper loaded: form_helper
INFO - 2018-02-06 07:09:15 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:09:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:09:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:09:15 --> Form Validation Class Initialized
INFO - 2018-02-06 07:09:15 --> Model Class Initialized
INFO - 2018-02-06 07:09:15 --> Controller Class Initialized
INFO - 2018-02-06 07:09:15 --> Model Class Initialized
DEBUG - 2018-02-06 07:09:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:09:17 --> Config Class Initialized
INFO - 2018-02-06 07:09:17 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:09:17 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:09:17 --> Utf8 Class Initialized
INFO - 2018-02-06 07:09:17 --> URI Class Initialized
INFO - 2018-02-06 07:09:17 --> Router Class Initialized
INFO - 2018-02-06 07:09:17 --> Output Class Initialized
INFO - 2018-02-06 07:09:17 --> Security Class Initialized
DEBUG - 2018-02-06 07:09:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:09:17 --> Input Class Initialized
INFO - 2018-02-06 07:09:17 --> Language Class Initialized
INFO - 2018-02-06 07:09:17 --> Loader Class Initialized
INFO - 2018-02-06 07:09:17 --> Helper loaded: url_helper
INFO - 2018-02-06 07:09:17 --> Helper loaded: form_helper
INFO - 2018-02-06 07:09:17 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:09:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:09:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:09:17 --> Form Validation Class Initialized
INFO - 2018-02-06 07:09:17 --> Model Class Initialized
INFO - 2018-02-06 07:09:17 --> Controller Class Initialized
INFO - 2018-02-06 07:09:17 --> Model Class Initialized
DEBUG - 2018-02-06 07:09:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:09:19 --> Config Class Initialized
INFO - 2018-02-06 07:09:19 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:09:19 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:09:19 --> Utf8 Class Initialized
INFO - 2018-02-06 07:09:19 --> URI Class Initialized
INFO - 2018-02-06 07:09:19 --> Router Class Initialized
INFO - 2018-02-06 07:09:19 --> Output Class Initialized
INFO - 2018-02-06 07:09:19 --> Security Class Initialized
DEBUG - 2018-02-06 07:09:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:09:19 --> Input Class Initialized
INFO - 2018-02-06 07:09:19 --> Language Class Initialized
INFO - 2018-02-06 07:09:19 --> Loader Class Initialized
INFO - 2018-02-06 07:09:19 --> Helper loaded: url_helper
INFO - 2018-02-06 07:09:19 --> Helper loaded: form_helper
INFO - 2018-02-06 07:09:19 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:09:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:09:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:09:19 --> Form Validation Class Initialized
INFO - 2018-02-06 07:09:19 --> Model Class Initialized
INFO - 2018-02-06 07:09:19 --> Controller Class Initialized
INFO - 2018-02-06 07:09:19 --> Model Class Initialized
DEBUG - 2018-02-06 07:09:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:09:34 --> Config Class Initialized
INFO - 2018-02-06 07:09:34 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:09:34 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:09:34 --> Utf8 Class Initialized
INFO - 2018-02-06 07:09:34 --> URI Class Initialized
INFO - 2018-02-06 07:09:34 --> Router Class Initialized
INFO - 2018-02-06 07:09:34 --> Output Class Initialized
INFO - 2018-02-06 07:09:34 --> Security Class Initialized
DEBUG - 2018-02-06 07:09:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:09:34 --> Input Class Initialized
INFO - 2018-02-06 07:09:34 --> Language Class Initialized
INFO - 2018-02-06 07:09:34 --> Loader Class Initialized
INFO - 2018-02-06 07:09:34 --> Helper loaded: url_helper
INFO - 2018-02-06 07:09:34 --> Helper loaded: form_helper
INFO - 2018-02-06 07:09:34 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:09:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:09:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:09:34 --> Form Validation Class Initialized
INFO - 2018-02-06 07:09:34 --> Model Class Initialized
INFO - 2018-02-06 07:09:34 --> Controller Class Initialized
INFO - 2018-02-06 07:09:34 --> Model Class Initialized
DEBUG - 2018-02-06 07:09:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:09:34 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:09:34 --> Final output sent to browser
DEBUG - 2018-02-06 07:09:34 --> Total execution time: 0.0528
INFO - 2018-02-06 07:09:34 --> Config Class Initialized
INFO - 2018-02-06 07:09:34 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:09:34 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:09:34 --> Utf8 Class Initialized
INFO - 2018-02-06 07:09:34 --> URI Class Initialized
INFO - 2018-02-06 07:09:34 --> Router Class Initialized
INFO - 2018-02-06 07:09:34 --> Output Class Initialized
INFO - 2018-02-06 07:09:34 --> Security Class Initialized
DEBUG - 2018-02-06 07:09:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:09:34 --> Input Class Initialized
INFO - 2018-02-06 07:09:34 --> Language Class Initialized
INFO - 2018-02-06 07:09:34 --> Loader Class Initialized
INFO - 2018-02-06 07:09:34 --> Helper loaded: url_helper
INFO - 2018-02-06 07:09:34 --> Helper loaded: form_helper
INFO - 2018-02-06 07:09:34 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:09:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:09:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:09:34 --> Form Validation Class Initialized
INFO - 2018-02-06 07:09:34 --> Model Class Initialized
INFO - 2018-02-06 07:09:34 --> Controller Class Initialized
INFO - 2018-02-06 07:09:34 --> Model Class Initialized
DEBUG - 2018-02-06 07:09:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:09:35 --> Config Class Initialized
INFO - 2018-02-06 07:09:35 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:09:35 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:09:35 --> Utf8 Class Initialized
INFO - 2018-02-06 07:09:35 --> URI Class Initialized
INFO - 2018-02-06 07:09:35 --> Router Class Initialized
INFO - 2018-02-06 07:09:35 --> Output Class Initialized
INFO - 2018-02-06 07:09:35 --> Security Class Initialized
DEBUG - 2018-02-06 07:09:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:09:35 --> Input Class Initialized
INFO - 2018-02-06 07:09:35 --> Language Class Initialized
INFO - 2018-02-06 07:09:35 --> Loader Class Initialized
INFO - 2018-02-06 07:09:35 --> Helper loaded: url_helper
INFO - 2018-02-06 07:09:35 --> Helper loaded: form_helper
INFO - 2018-02-06 07:09:35 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:09:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:09:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:09:35 --> Form Validation Class Initialized
INFO - 2018-02-06 07:09:35 --> Model Class Initialized
INFO - 2018-02-06 07:09:35 --> Controller Class Initialized
INFO - 2018-02-06 07:09:35 --> Model Class Initialized
DEBUG - 2018-02-06 07:09:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:09:35 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:09:35 --> Final output sent to browser
DEBUG - 2018-02-06 07:09:35 --> Total execution time: 0.0392
INFO - 2018-02-06 07:09:36 --> Config Class Initialized
INFO - 2018-02-06 07:09:36 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:09:36 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:09:36 --> Utf8 Class Initialized
INFO - 2018-02-06 07:09:36 --> URI Class Initialized
INFO - 2018-02-06 07:09:36 --> Router Class Initialized
INFO - 2018-02-06 07:09:36 --> Output Class Initialized
INFO - 2018-02-06 07:09:36 --> Security Class Initialized
DEBUG - 2018-02-06 07:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:09:36 --> Input Class Initialized
INFO - 2018-02-06 07:09:36 --> Language Class Initialized
INFO - 2018-02-06 07:09:36 --> Loader Class Initialized
INFO - 2018-02-06 07:09:36 --> Helper loaded: url_helper
INFO - 2018-02-06 07:09:36 --> Helper loaded: form_helper
INFO - 2018-02-06 07:09:36 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:09:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:09:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:09:36 --> Form Validation Class Initialized
INFO - 2018-02-06 07:09:36 --> Model Class Initialized
INFO - 2018-02-06 07:09:36 --> Controller Class Initialized
INFO - 2018-02-06 07:09:36 --> Model Class Initialized
DEBUG - 2018-02-06 07:09:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:09:36 --> Config Class Initialized
INFO - 2018-02-06 07:09:36 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:09:36 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:09:36 --> Utf8 Class Initialized
INFO - 2018-02-06 07:09:36 --> URI Class Initialized
INFO - 2018-02-06 07:09:36 --> Router Class Initialized
INFO - 2018-02-06 07:09:36 --> Output Class Initialized
INFO - 2018-02-06 07:09:36 --> Security Class Initialized
DEBUG - 2018-02-06 07:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:09:36 --> Input Class Initialized
INFO - 2018-02-06 07:09:36 --> Language Class Initialized
INFO - 2018-02-06 07:09:36 --> Loader Class Initialized
INFO - 2018-02-06 07:09:36 --> Helper loaded: url_helper
INFO - 2018-02-06 07:09:36 --> Helper loaded: form_helper
INFO - 2018-02-06 07:09:36 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:09:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:09:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:09:36 --> Form Validation Class Initialized
INFO - 2018-02-06 07:09:36 --> Model Class Initialized
INFO - 2018-02-06 07:09:36 --> Controller Class Initialized
INFO - 2018-02-06 07:09:36 --> Model Class Initialized
DEBUG - 2018-02-06 07:09:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:09:36 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:09:36 --> Final output sent to browser
DEBUG - 2018-02-06 07:09:36 --> Total execution time: 0.0491
INFO - 2018-02-06 07:09:36 --> Config Class Initialized
INFO - 2018-02-06 07:09:36 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:09:36 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:09:36 --> Utf8 Class Initialized
INFO - 2018-02-06 07:09:36 --> URI Class Initialized
INFO - 2018-02-06 07:09:36 --> Router Class Initialized
INFO - 2018-02-06 07:09:36 --> Output Class Initialized
INFO - 2018-02-06 07:09:36 --> Security Class Initialized
DEBUG - 2018-02-06 07:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:09:36 --> Input Class Initialized
INFO - 2018-02-06 07:09:36 --> Language Class Initialized
INFO - 2018-02-06 07:09:36 --> Loader Class Initialized
INFO - 2018-02-06 07:09:36 --> Helper loaded: url_helper
INFO - 2018-02-06 07:09:36 --> Helper loaded: form_helper
INFO - 2018-02-06 07:09:36 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:09:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:09:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:09:36 --> Form Validation Class Initialized
INFO - 2018-02-06 07:09:36 --> Model Class Initialized
INFO - 2018-02-06 07:09:36 --> Controller Class Initialized
INFO - 2018-02-06 07:09:36 --> Model Class Initialized
DEBUG - 2018-02-06 07:09:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:11:28 --> Config Class Initialized
INFO - 2018-02-06 07:11:28 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:11:28 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:11:28 --> Utf8 Class Initialized
INFO - 2018-02-06 07:11:28 --> URI Class Initialized
INFO - 2018-02-06 07:11:28 --> Router Class Initialized
INFO - 2018-02-06 07:11:28 --> Output Class Initialized
INFO - 2018-02-06 07:11:28 --> Security Class Initialized
DEBUG - 2018-02-06 07:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:11:28 --> Input Class Initialized
INFO - 2018-02-06 07:11:28 --> Language Class Initialized
INFO - 2018-02-06 07:11:28 --> Loader Class Initialized
INFO - 2018-02-06 07:11:28 --> Helper loaded: url_helper
INFO - 2018-02-06 07:11:28 --> Helper loaded: form_helper
INFO - 2018-02-06 07:11:28 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:11:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:11:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:11:28 --> Form Validation Class Initialized
INFO - 2018-02-06 07:11:28 --> Model Class Initialized
INFO - 2018-02-06 07:11:28 --> Controller Class Initialized
INFO - 2018-02-06 07:11:28 --> Model Class Initialized
DEBUG - 2018-02-06 07:11:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:11:28 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:11:28 --> Final output sent to browser
DEBUG - 2018-02-06 07:11:28 --> Total execution time: 0.0484
INFO - 2018-02-06 07:11:28 --> Config Class Initialized
INFO - 2018-02-06 07:11:28 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:11:28 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:11:28 --> Utf8 Class Initialized
INFO - 2018-02-06 07:11:28 --> URI Class Initialized
INFO - 2018-02-06 07:11:28 --> Router Class Initialized
INFO - 2018-02-06 07:11:28 --> Output Class Initialized
INFO - 2018-02-06 07:11:28 --> Security Class Initialized
DEBUG - 2018-02-06 07:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:11:28 --> Input Class Initialized
INFO - 2018-02-06 07:11:28 --> Language Class Initialized
INFO - 2018-02-06 07:11:28 --> Loader Class Initialized
INFO - 2018-02-06 07:11:28 --> Helper loaded: url_helper
INFO - 2018-02-06 07:11:28 --> Helper loaded: form_helper
INFO - 2018-02-06 07:11:28 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:11:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:11:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:11:28 --> Form Validation Class Initialized
INFO - 2018-02-06 07:11:28 --> Model Class Initialized
INFO - 2018-02-06 07:11:28 --> Controller Class Initialized
INFO - 2018-02-06 07:11:28 --> Model Class Initialized
DEBUG - 2018-02-06 07:11:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:11:29 --> Config Class Initialized
INFO - 2018-02-06 07:11:29 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:11:29 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:11:29 --> Utf8 Class Initialized
INFO - 2018-02-06 07:11:29 --> URI Class Initialized
INFO - 2018-02-06 07:11:29 --> Router Class Initialized
INFO - 2018-02-06 07:11:29 --> Output Class Initialized
INFO - 2018-02-06 07:11:29 --> Security Class Initialized
DEBUG - 2018-02-06 07:11:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:11:29 --> Input Class Initialized
INFO - 2018-02-06 07:11:29 --> Language Class Initialized
INFO - 2018-02-06 07:11:29 --> Loader Class Initialized
INFO - 2018-02-06 07:11:29 --> Helper loaded: url_helper
INFO - 2018-02-06 07:11:29 --> Helper loaded: form_helper
INFO - 2018-02-06 07:11:29 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:11:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:11:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:11:29 --> Form Validation Class Initialized
INFO - 2018-02-06 07:11:29 --> Model Class Initialized
INFO - 2018-02-06 07:11:29 --> Controller Class Initialized
INFO - 2018-02-06 07:11:29 --> Model Class Initialized
DEBUG - 2018-02-06 07:11:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:11:29 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:11:29 --> Final output sent to browser
DEBUG - 2018-02-06 07:11:29 --> Total execution time: 0.0509
INFO - 2018-02-06 07:11:29 --> Config Class Initialized
INFO - 2018-02-06 07:11:29 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:11:29 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:11:29 --> Utf8 Class Initialized
INFO - 2018-02-06 07:11:29 --> URI Class Initialized
INFO - 2018-02-06 07:11:29 --> Router Class Initialized
INFO - 2018-02-06 07:11:29 --> Output Class Initialized
INFO - 2018-02-06 07:11:29 --> Security Class Initialized
DEBUG - 2018-02-06 07:11:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:11:29 --> Input Class Initialized
INFO - 2018-02-06 07:11:29 --> Language Class Initialized
INFO - 2018-02-06 07:11:29 --> Loader Class Initialized
INFO - 2018-02-06 07:11:29 --> Helper loaded: url_helper
INFO - 2018-02-06 07:11:29 --> Helper loaded: form_helper
INFO - 2018-02-06 07:11:29 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:11:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:11:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:11:29 --> Form Validation Class Initialized
INFO - 2018-02-06 07:11:29 --> Model Class Initialized
INFO - 2018-02-06 07:11:29 --> Controller Class Initialized
INFO - 2018-02-06 07:11:29 --> Model Class Initialized
DEBUG - 2018-02-06 07:11:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:11:29 --> Config Class Initialized
INFO - 2018-02-06 07:11:29 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:11:29 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:11:29 --> Utf8 Class Initialized
INFO - 2018-02-06 07:11:29 --> URI Class Initialized
INFO - 2018-02-06 07:11:29 --> Router Class Initialized
INFO - 2018-02-06 07:11:29 --> Output Class Initialized
INFO - 2018-02-06 07:11:29 --> Security Class Initialized
DEBUG - 2018-02-06 07:11:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:11:29 --> Input Class Initialized
INFO - 2018-02-06 07:11:29 --> Language Class Initialized
INFO - 2018-02-06 07:11:29 --> Loader Class Initialized
INFO - 2018-02-06 07:11:29 --> Helper loaded: url_helper
INFO - 2018-02-06 07:11:29 --> Helper loaded: form_helper
INFO - 2018-02-06 07:11:29 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:11:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:11:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:11:29 --> Form Validation Class Initialized
INFO - 2018-02-06 07:11:29 --> Model Class Initialized
INFO - 2018-02-06 07:11:29 --> Controller Class Initialized
INFO - 2018-02-06 07:11:29 --> Model Class Initialized
DEBUG - 2018-02-06 07:11:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:11:29 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:11:29 --> Final output sent to browser
DEBUG - 2018-02-06 07:11:29 --> Total execution time: 0.0391
INFO - 2018-02-06 07:11:29 --> Config Class Initialized
INFO - 2018-02-06 07:11:29 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:11:29 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:11:29 --> Utf8 Class Initialized
INFO - 2018-02-06 07:11:29 --> URI Class Initialized
INFO - 2018-02-06 07:11:29 --> Router Class Initialized
INFO - 2018-02-06 07:11:29 --> Output Class Initialized
INFO - 2018-02-06 07:11:29 --> Security Class Initialized
DEBUG - 2018-02-06 07:11:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:11:29 --> Input Class Initialized
INFO - 2018-02-06 07:11:29 --> Language Class Initialized
INFO - 2018-02-06 07:11:29 --> Loader Class Initialized
INFO - 2018-02-06 07:11:29 --> Helper loaded: url_helper
INFO - 2018-02-06 07:11:29 --> Helper loaded: form_helper
INFO - 2018-02-06 07:11:29 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:11:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:11:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:11:29 --> Form Validation Class Initialized
INFO - 2018-02-06 07:11:29 --> Model Class Initialized
INFO - 2018-02-06 07:11:29 --> Controller Class Initialized
INFO - 2018-02-06 07:11:29 --> Model Class Initialized
DEBUG - 2018-02-06 07:11:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:11:30 --> Config Class Initialized
INFO - 2018-02-06 07:11:30 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:11:30 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:11:30 --> Utf8 Class Initialized
INFO - 2018-02-06 07:11:30 --> URI Class Initialized
INFO - 2018-02-06 07:11:30 --> Router Class Initialized
INFO - 2018-02-06 07:11:30 --> Output Class Initialized
INFO - 2018-02-06 07:11:30 --> Security Class Initialized
DEBUG - 2018-02-06 07:11:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:11:30 --> Input Class Initialized
INFO - 2018-02-06 07:11:30 --> Language Class Initialized
INFO - 2018-02-06 07:11:30 --> Loader Class Initialized
INFO - 2018-02-06 07:11:30 --> Helper loaded: url_helper
INFO - 2018-02-06 07:11:30 --> Helper loaded: form_helper
INFO - 2018-02-06 07:11:30 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:11:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:11:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:11:30 --> Form Validation Class Initialized
INFO - 2018-02-06 07:11:30 --> Model Class Initialized
INFO - 2018-02-06 07:11:30 --> Controller Class Initialized
INFO - 2018-02-06 07:11:30 --> Model Class Initialized
INFO - 2018-02-06 07:11:30 --> Model Class Initialized
INFO - 2018-02-06 07:11:30 --> Model Class Initialized
INFO - 2018-02-06 07:11:30 --> Model Class Initialized
DEBUG - 2018-02-06 07:11:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:11:30 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:11:30 --> Final output sent to browser
DEBUG - 2018-02-06 07:11:30 --> Total execution time: 0.0457
INFO - 2018-02-06 07:11:30 --> Config Class Initialized
INFO - 2018-02-06 07:11:30 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:11:30 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:11:30 --> Utf8 Class Initialized
INFO - 2018-02-06 07:11:30 --> URI Class Initialized
INFO - 2018-02-06 07:11:30 --> Router Class Initialized
INFO - 2018-02-06 07:11:30 --> Output Class Initialized
INFO - 2018-02-06 07:11:30 --> Security Class Initialized
DEBUG - 2018-02-06 07:11:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:11:30 --> Input Class Initialized
INFO - 2018-02-06 07:11:30 --> Language Class Initialized
INFO - 2018-02-06 07:11:30 --> Loader Class Initialized
INFO - 2018-02-06 07:11:30 --> Helper loaded: url_helper
INFO - 2018-02-06 07:11:30 --> Helper loaded: form_helper
INFO - 2018-02-06 07:11:30 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:11:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:11:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:11:30 --> Form Validation Class Initialized
INFO - 2018-02-06 07:11:30 --> Model Class Initialized
INFO - 2018-02-06 07:11:30 --> Controller Class Initialized
INFO - 2018-02-06 07:11:30 --> Model Class Initialized
DEBUG - 2018-02-06 07:11:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:11:30 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:11:30 --> Final output sent to browser
DEBUG - 2018-02-06 07:11:30 --> Total execution time: 0.0461
INFO - 2018-02-06 07:11:31 --> Config Class Initialized
INFO - 2018-02-06 07:11:31 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:11:31 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:11:31 --> Utf8 Class Initialized
INFO - 2018-02-06 07:11:31 --> URI Class Initialized
INFO - 2018-02-06 07:11:31 --> Router Class Initialized
INFO - 2018-02-06 07:11:31 --> Output Class Initialized
INFO - 2018-02-06 07:11:31 --> Security Class Initialized
DEBUG - 2018-02-06 07:11:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:11:31 --> Input Class Initialized
INFO - 2018-02-06 07:11:31 --> Language Class Initialized
INFO - 2018-02-06 07:11:31 --> Loader Class Initialized
INFO - 2018-02-06 07:11:31 --> Helper loaded: url_helper
INFO - 2018-02-06 07:11:31 --> Helper loaded: form_helper
INFO - 2018-02-06 07:11:31 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:11:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:11:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:11:31 --> Form Validation Class Initialized
INFO - 2018-02-06 07:11:31 --> Model Class Initialized
INFO - 2018-02-06 07:11:31 --> Controller Class Initialized
INFO - 2018-02-06 07:11:31 --> Model Class Initialized
DEBUG - 2018-02-06 07:11:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:27:50 --> Config Class Initialized
INFO - 2018-02-06 07:27:50 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:27:50 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:27:50 --> Utf8 Class Initialized
INFO - 2018-02-06 07:27:50 --> URI Class Initialized
INFO - 2018-02-06 07:27:50 --> Router Class Initialized
INFO - 2018-02-06 07:27:50 --> Output Class Initialized
INFO - 2018-02-06 07:27:50 --> Security Class Initialized
DEBUG - 2018-02-06 07:27:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:27:50 --> Input Class Initialized
INFO - 2018-02-06 07:27:50 --> Language Class Initialized
INFO - 2018-02-06 07:27:50 --> Loader Class Initialized
INFO - 2018-02-06 07:27:50 --> Helper loaded: url_helper
INFO - 2018-02-06 07:27:50 --> Helper loaded: form_helper
INFO - 2018-02-06 07:27:50 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:27:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:27:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:27:50 --> Form Validation Class Initialized
INFO - 2018-02-06 07:27:50 --> Model Class Initialized
INFO - 2018-02-06 07:27:50 --> Controller Class Initialized
INFO - 2018-02-06 07:27:50 --> Model Class Initialized
DEBUG - 2018-02-06 07:27:50 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:27:50 --> Severity: Warning --> Missing argument 2 for CI_DB_query_builder::join(), called in D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_colaborador.php on line 183 and defined D:\xampp\htdocs\instateccr\controlcostos\instatec_sys\database\DB_query_builder.php 526
ERROR - 2018-02-06 07:27:50 --> Severity: Notice --> Undefined variable: cond D:\xampp\htdocs\instateccr\controlcostos\instatec_sys\database\DB_query_builder.php 548
ERROR - 2018-02-06 07:27:50 --> Severity: Notice --> Undefined variable: cond D:\xampp\htdocs\instateccr\controlcostos\instatec_sys\database\DB_query_builder.php 550
ERROR - 2018-02-06 07:27:50 --> Severity: Notice --> Undefined property: Colaborador::$t_colabort_usuario_colaboradorador D:\xampp\htdocs\instateccr\controlcostos\instatec_sys\core\Model.php 77
ERROR - 2018-02-06 07:27:50 --> Severity: Warning --> Missing argument 2 for CI_DB_query_builder::join(), called in D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_colaborador.php on line 184 and defined D:\xampp\htdocs\instateccr\controlcostos\instatec_sys\database\DB_query_builder.php 526
ERROR - 2018-02-06 07:27:50 --> Severity: Notice --> Undefined variable: cond D:\xampp\htdocs\instateccr\controlcostos\instatec_sys\database\DB_query_builder.php 548
ERROR - 2018-02-06 07:27:50 --> Severity: Notice --> Undefined variable: cond D:\xampp\htdocs\instateccr\controlcostos\instatec_sys\database\DB_query_builder.php 550
ERROR - 2018-02-06 07:27:50 --> Severity: Warning --> Missing argument 2 for CI_DB_query_builder::join(), called in D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_colaborador.php on line 186 and defined D:\xampp\htdocs\instateccr\controlcostos\instatec_sys\database\DB_query_builder.php 526
ERROR - 2018-02-06 07:27:50 --> Severity: Notice --> Undefined variable: cond D:\xampp\htdocs\instateccr\controlcostos\instatec_sys\database\DB_query_builder.php 548
ERROR - 2018-02-06 07:27:50 --> Severity: Notice --> Undefined variable: cond D:\xampp\htdocs\instateccr\controlcostos\instatec_sys\database\DB_query_builder.php 550
ERROR - 2018-02-06 07:27:50 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '.`colaborador_id` USING ()
JOIN `usuario`.`usuario_id =` .`usuario_id` USING ()
' at line 3 - Invalid query: SELECT *
FROM `colaborador`
JOIN `usuario_colaborador`.`colaborador_id =` `colaborador`.`colaborador_id` USING ()
JOIN `usuario`.`usuario_id =` .`usuario_id` USING ()
JOIN `colaborador_costo_hora`.`colaborador_id = colaborador`.`colaborador_id AND colaborador_costo_hora`.`estado_costo =` 1 USING ()
WHERE `colaborador_id` = '1'
INFO - 2018-02-06 07:27:50 --> Language file loaded: language/english/db_lang.php
ERROR - 2018-02-06 07:27:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\instateccr\controlcostos\instatec_sys\core\Exceptions.php:271) D:\xampp\htdocs\instateccr\controlcostos\instatec_sys\core\Common.php 570
INFO - 2018-02-06 07:28:36 --> Config Class Initialized
INFO - 2018-02-06 07:28:36 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:28:36 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:28:36 --> Utf8 Class Initialized
INFO - 2018-02-06 07:28:36 --> URI Class Initialized
INFO - 2018-02-06 07:28:36 --> Router Class Initialized
INFO - 2018-02-06 07:28:36 --> Output Class Initialized
INFO - 2018-02-06 07:28:36 --> Security Class Initialized
DEBUG - 2018-02-06 07:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:28:36 --> Input Class Initialized
INFO - 2018-02-06 07:28:36 --> Language Class Initialized
INFO - 2018-02-06 07:28:36 --> Loader Class Initialized
INFO - 2018-02-06 07:28:36 --> Helper loaded: url_helper
INFO - 2018-02-06 07:28:36 --> Helper loaded: form_helper
INFO - 2018-02-06 07:28:36 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:28:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:28:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:28:36 --> Form Validation Class Initialized
INFO - 2018-02-06 07:28:36 --> Model Class Initialized
INFO - 2018-02-06 07:28:36 --> Controller Class Initialized
INFO - 2018-02-06 07:28:36 --> Model Class Initialized
DEBUG - 2018-02-06 07:28:36 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:28:36 --> Severity: Notice --> Undefined property: Colaborador::$t_colabort_usuario_colaboradorador D:\xampp\htdocs\instateccr\controlcostos\instatec_sys\core\Model.php 77
ERROR - 2018-02-06 07:28:36 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'JOIN `colaborador_costo_hora` ON `colaborador_costo_hora`.`colaborador_id` = `co' at line 5 - Invalid query: SELECT *
FROM `colaborador`
JOIN `usuario_colaborador` ON `usuario_colaborador`.`colaborador_id` = `colaborador`.`colaborador_id`
JOIN `usuario` ON `usuario`.`usuario_id` = .`usuario_id`
JOIN `colaborador_costo_hora` ON `colaborador_costo_hora`.`colaborador_id` = `colaborador`.`colaborador_id` AND `colaborador_costo_hora`.`estado_costo` = 1
WHERE `colaborador_id` = '1'
INFO - 2018-02-06 07:28:36 --> Language file loaded: language/english/db_lang.php
INFO - 2018-02-06 07:28:56 --> Config Class Initialized
INFO - 2018-02-06 07:28:56 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:28:56 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:28:56 --> Utf8 Class Initialized
INFO - 2018-02-06 07:28:56 --> URI Class Initialized
INFO - 2018-02-06 07:28:56 --> Router Class Initialized
INFO - 2018-02-06 07:28:56 --> Output Class Initialized
INFO - 2018-02-06 07:28:56 --> Security Class Initialized
DEBUG - 2018-02-06 07:28:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:28:56 --> Input Class Initialized
INFO - 2018-02-06 07:28:56 --> Language Class Initialized
INFO - 2018-02-06 07:28:56 --> Loader Class Initialized
INFO - 2018-02-06 07:28:56 --> Helper loaded: url_helper
INFO - 2018-02-06 07:28:56 --> Helper loaded: form_helper
INFO - 2018-02-06 07:28:56 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:28:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:28:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:28:56 --> Form Validation Class Initialized
INFO - 2018-02-06 07:28:56 --> Model Class Initialized
INFO - 2018-02-06 07:28:56 --> Controller Class Initialized
INFO - 2018-02-06 07:28:56 --> Model Class Initialized
DEBUG - 2018-02-06 07:28:56 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:28:56 --> Query error: Column 'colaborador_id' in where clause is ambiguous - Invalid query: SELECT *
FROM `colaborador`
JOIN `usuario_colaborador` ON `usuario_colaborador`.`colaborador_id` = `colaborador`.`colaborador_id`
JOIN `usuario` ON `usuario`.`usuario_id` = `usuario_colaborador`.`usuario_id`
JOIN `colaborador_costo_hora` ON `colaborador_costo_hora`.`colaborador_id` = `colaborador`.`colaborador_id` AND `colaborador_costo_hora`.`estado_costo` = 1
WHERE `colaborador_id` = '1'
INFO - 2018-02-06 07:28:56 --> Language file loaded: language/english/db_lang.php
INFO - 2018-02-06 07:28:57 --> Config Class Initialized
INFO - 2018-02-06 07:28:57 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:28:57 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:28:57 --> Utf8 Class Initialized
INFO - 2018-02-06 07:28:57 --> URI Class Initialized
INFO - 2018-02-06 07:28:57 --> Router Class Initialized
INFO - 2018-02-06 07:28:57 --> Output Class Initialized
INFO - 2018-02-06 07:28:57 --> Security Class Initialized
DEBUG - 2018-02-06 07:28:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:28:57 --> Input Class Initialized
INFO - 2018-02-06 07:28:57 --> Language Class Initialized
INFO - 2018-02-06 07:28:57 --> Loader Class Initialized
INFO - 2018-02-06 07:28:57 --> Helper loaded: url_helper
INFO - 2018-02-06 07:28:57 --> Helper loaded: form_helper
INFO - 2018-02-06 07:28:57 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:28:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:28:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:28:57 --> Form Validation Class Initialized
INFO - 2018-02-06 07:28:57 --> Model Class Initialized
INFO - 2018-02-06 07:28:57 --> Controller Class Initialized
INFO - 2018-02-06 07:28:57 --> Model Class Initialized
DEBUG - 2018-02-06 07:28:57 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:28:57 --> Query error: Column 'colaborador_id' in where clause is ambiguous - Invalid query: SELECT *
FROM `colaborador`
JOIN `usuario_colaborador` ON `usuario_colaborador`.`colaborador_id` = `colaborador`.`colaborador_id`
JOIN `usuario` ON `usuario`.`usuario_id` = `usuario_colaborador`.`usuario_id`
JOIN `colaborador_costo_hora` ON `colaborador_costo_hora`.`colaborador_id` = `colaborador`.`colaborador_id` AND `colaborador_costo_hora`.`estado_costo` = 1
WHERE `colaborador_id` = '1'
INFO - 2018-02-06 07:28:57 --> Language file loaded: language/english/db_lang.php
INFO - 2018-02-06 07:28:57 --> Config Class Initialized
INFO - 2018-02-06 07:28:57 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:28:57 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:28:57 --> Utf8 Class Initialized
INFO - 2018-02-06 07:28:57 --> URI Class Initialized
INFO - 2018-02-06 07:28:57 --> Router Class Initialized
INFO - 2018-02-06 07:28:57 --> Output Class Initialized
INFO - 2018-02-06 07:28:57 --> Security Class Initialized
DEBUG - 2018-02-06 07:28:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:28:57 --> Input Class Initialized
INFO - 2018-02-06 07:28:57 --> Language Class Initialized
INFO - 2018-02-06 07:28:57 --> Loader Class Initialized
INFO - 2018-02-06 07:28:57 --> Helper loaded: url_helper
INFO - 2018-02-06 07:28:57 --> Helper loaded: form_helper
INFO - 2018-02-06 07:28:57 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:28:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:28:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:28:57 --> Form Validation Class Initialized
INFO - 2018-02-06 07:28:57 --> Model Class Initialized
INFO - 2018-02-06 07:28:57 --> Controller Class Initialized
INFO - 2018-02-06 07:28:57 --> Model Class Initialized
DEBUG - 2018-02-06 07:28:57 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:28:57 --> Query error: Column 'colaborador_id' in where clause is ambiguous - Invalid query: SELECT *
FROM `colaborador`
JOIN `usuario_colaborador` ON `usuario_colaborador`.`colaborador_id` = `colaborador`.`colaborador_id`
JOIN `usuario` ON `usuario`.`usuario_id` = `usuario_colaborador`.`usuario_id`
JOIN `colaborador_costo_hora` ON `colaborador_costo_hora`.`colaborador_id` = `colaborador`.`colaborador_id` AND `colaborador_costo_hora`.`estado_costo` = 1
WHERE `colaborador_id` = '1'
INFO - 2018-02-06 07:28:57 --> Language file loaded: language/english/db_lang.php
INFO - 2018-02-06 07:29:20 --> Config Class Initialized
INFO - 2018-02-06 07:29:20 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:29:20 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:29:20 --> Utf8 Class Initialized
INFO - 2018-02-06 07:29:20 --> URI Class Initialized
INFO - 2018-02-06 07:29:20 --> Router Class Initialized
INFO - 2018-02-06 07:29:20 --> Output Class Initialized
INFO - 2018-02-06 07:29:20 --> Security Class Initialized
DEBUG - 2018-02-06 07:29:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:29:20 --> Input Class Initialized
INFO - 2018-02-06 07:29:20 --> Language Class Initialized
INFO - 2018-02-06 07:29:20 --> Loader Class Initialized
INFO - 2018-02-06 07:29:20 --> Helper loaded: url_helper
INFO - 2018-02-06 07:29:20 --> Helper loaded: form_helper
INFO - 2018-02-06 07:29:20 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:29:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:29:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:29:20 --> Form Validation Class Initialized
INFO - 2018-02-06 07:29:20 --> Model Class Initialized
INFO - 2018-02-06 07:29:20 --> Controller Class Initialized
INFO - 2018-02-06 07:29:20 --> Model Class Initialized
DEBUG - 2018-02-06 07:29:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:29:20 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:29:20 --> Final output sent to browser
DEBUG - 2018-02-06 07:29:20 --> Total execution time: 0.0439
INFO - 2018-02-06 07:29:24 --> Config Class Initialized
INFO - 2018-02-06 07:29:24 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:29:24 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:29:24 --> Utf8 Class Initialized
INFO - 2018-02-06 07:29:24 --> URI Class Initialized
INFO - 2018-02-06 07:29:24 --> Router Class Initialized
INFO - 2018-02-06 07:29:24 --> Output Class Initialized
INFO - 2018-02-06 07:29:24 --> Security Class Initialized
DEBUG - 2018-02-06 07:29:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:29:24 --> Input Class Initialized
INFO - 2018-02-06 07:29:24 --> Language Class Initialized
INFO - 2018-02-06 07:29:24 --> Loader Class Initialized
INFO - 2018-02-06 07:29:24 --> Helper loaded: url_helper
INFO - 2018-02-06 07:29:24 --> Helper loaded: form_helper
INFO - 2018-02-06 07:29:24 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:29:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:29:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:29:24 --> Form Validation Class Initialized
INFO - 2018-02-06 07:29:24 --> Model Class Initialized
INFO - 2018-02-06 07:29:24 --> Controller Class Initialized
INFO - 2018-02-06 07:29:24 --> Model Class Initialized
DEBUG - 2018-02-06 07:29:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:29:24 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:29:24 --> Final output sent to browser
DEBUG - 2018-02-06 07:29:24 --> Total execution time: 0.0662
INFO - 2018-02-06 07:29:24 --> Config Class Initialized
INFO - 2018-02-06 07:29:24 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:29:24 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:29:24 --> Utf8 Class Initialized
INFO - 2018-02-06 07:29:24 --> URI Class Initialized
INFO - 2018-02-06 07:29:24 --> Router Class Initialized
INFO - 2018-02-06 07:29:24 --> Output Class Initialized
INFO - 2018-02-06 07:29:24 --> Security Class Initialized
DEBUG - 2018-02-06 07:29:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:29:24 --> Input Class Initialized
INFO - 2018-02-06 07:29:24 --> Language Class Initialized
INFO - 2018-02-06 07:29:24 --> Loader Class Initialized
INFO - 2018-02-06 07:29:24 --> Helper loaded: url_helper
INFO - 2018-02-06 07:29:24 --> Helper loaded: form_helper
INFO - 2018-02-06 07:29:24 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:29:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:29:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:29:24 --> Form Validation Class Initialized
INFO - 2018-02-06 07:29:24 --> Model Class Initialized
INFO - 2018-02-06 07:29:24 --> Controller Class Initialized
INFO - 2018-02-06 07:29:24 --> Model Class Initialized
DEBUG - 2018-02-06 07:29:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:29:24 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:29:24 --> Final output sent to browser
DEBUG - 2018-02-06 07:29:24 --> Total execution time: 0.0486
INFO - 2018-02-06 07:30:22 --> Config Class Initialized
INFO - 2018-02-06 07:30:22 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:30:22 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:30:22 --> Utf8 Class Initialized
INFO - 2018-02-06 07:30:22 --> URI Class Initialized
INFO - 2018-02-06 07:30:22 --> Router Class Initialized
INFO - 2018-02-06 07:30:22 --> Output Class Initialized
INFO - 2018-02-06 07:30:22 --> Security Class Initialized
DEBUG - 2018-02-06 07:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:30:22 --> Input Class Initialized
INFO - 2018-02-06 07:30:22 --> Language Class Initialized
INFO - 2018-02-06 07:30:22 --> Loader Class Initialized
INFO - 2018-02-06 07:30:22 --> Helper loaded: url_helper
INFO - 2018-02-06 07:30:22 --> Helper loaded: form_helper
INFO - 2018-02-06 07:30:22 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:30:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:30:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:30:22 --> Form Validation Class Initialized
INFO - 2018-02-06 07:30:22 --> Model Class Initialized
INFO - 2018-02-06 07:30:22 --> Controller Class Initialized
INFO - 2018-02-06 07:30:22 --> Model Class Initialized
DEBUG - 2018-02-06 07:30:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:30:22 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:30:22 --> Final output sent to browser
DEBUG - 2018-02-06 07:30:22 --> Total execution time: 0.0394
INFO - 2018-02-06 07:30:24 --> Config Class Initialized
INFO - 2018-02-06 07:30:24 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:30:24 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:30:24 --> Utf8 Class Initialized
INFO - 2018-02-06 07:30:24 --> URI Class Initialized
INFO - 2018-02-06 07:30:24 --> Router Class Initialized
INFO - 2018-02-06 07:30:24 --> Output Class Initialized
INFO - 2018-02-06 07:30:24 --> Security Class Initialized
DEBUG - 2018-02-06 07:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:30:24 --> Input Class Initialized
INFO - 2018-02-06 07:30:24 --> Language Class Initialized
INFO - 2018-02-06 07:30:24 --> Loader Class Initialized
INFO - 2018-02-06 07:30:24 --> Helper loaded: url_helper
INFO - 2018-02-06 07:30:24 --> Helper loaded: form_helper
INFO - 2018-02-06 07:30:24 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:30:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:30:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:30:24 --> Form Validation Class Initialized
INFO - 2018-02-06 07:30:24 --> Model Class Initialized
INFO - 2018-02-06 07:30:24 --> Controller Class Initialized
INFO - 2018-02-06 07:30:24 --> Model Class Initialized
DEBUG - 2018-02-06 07:30:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:30:24 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:30:24 --> Final output sent to browser
DEBUG - 2018-02-06 07:30:24 --> Total execution time: 0.0679
INFO - 2018-02-06 07:30:28 --> Config Class Initialized
INFO - 2018-02-06 07:30:28 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:30:28 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:30:28 --> Utf8 Class Initialized
INFO - 2018-02-06 07:30:28 --> URI Class Initialized
INFO - 2018-02-06 07:30:28 --> Router Class Initialized
INFO - 2018-02-06 07:30:28 --> Output Class Initialized
INFO - 2018-02-06 07:30:28 --> Security Class Initialized
DEBUG - 2018-02-06 07:30:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:30:28 --> Input Class Initialized
INFO - 2018-02-06 07:30:28 --> Language Class Initialized
INFO - 2018-02-06 07:30:28 --> Loader Class Initialized
INFO - 2018-02-06 07:30:28 --> Helper loaded: url_helper
INFO - 2018-02-06 07:30:28 --> Helper loaded: form_helper
INFO - 2018-02-06 07:30:28 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:30:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:30:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:30:28 --> Form Validation Class Initialized
INFO - 2018-02-06 07:30:28 --> Model Class Initialized
INFO - 2018-02-06 07:30:28 --> Controller Class Initialized
INFO - 2018-02-06 07:30:28 --> Model Class Initialized
DEBUG - 2018-02-06 07:30:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:31:06 --> Config Class Initialized
INFO - 2018-02-06 07:31:06 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:31:06 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:31:06 --> Utf8 Class Initialized
INFO - 2018-02-06 07:31:06 --> URI Class Initialized
INFO - 2018-02-06 07:31:06 --> Router Class Initialized
INFO - 2018-02-06 07:31:06 --> Output Class Initialized
INFO - 2018-02-06 07:31:06 --> Security Class Initialized
DEBUG - 2018-02-06 07:31:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:31:06 --> Input Class Initialized
INFO - 2018-02-06 07:31:06 --> Language Class Initialized
INFO - 2018-02-06 07:31:06 --> Loader Class Initialized
INFO - 2018-02-06 07:31:06 --> Helper loaded: url_helper
INFO - 2018-02-06 07:31:06 --> Helper loaded: form_helper
INFO - 2018-02-06 07:31:06 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:31:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:31:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:31:06 --> Form Validation Class Initialized
INFO - 2018-02-06 07:31:06 --> Model Class Initialized
INFO - 2018-02-06 07:31:06 --> Controller Class Initialized
INFO - 2018-02-06 07:31:06 --> Model Class Initialized
DEBUG - 2018-02-06 07:31:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:31:14 --> Config Class Initialized
INFO - 2018-02-06 07:31:14 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:31:14 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:31:14 --> Utf8 Class Initialized
INFO - 2018-02-06 07:31:14 --> URI Class Initialized
INFO - 2018-02-06 07:31:14 --> Router Class Initialized
INFO - 2018-02-06 07:31:14 --> Output Class Initialized
INFO - 2018-02-06 07:31:14 --> Security Class Initialized
DEBUG - 2018-02-06 07:31:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:31:14 --> Input Class Initialized
INFO - 2018-02-06 07:31:14 --> Language Class Initialized
INFO - 2018-02-06 07:31:14 --> Loader Class Initialized
INFO - 2018-02-06 07:31:14 --> Helper loaded: url_helper
INFO - 2018-02-06 07:31:14 --> Helper loaded: form_helper
INFO - 2018-02-06 07:31:14 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:31:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:31:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:31:14 --> Form Validation Class Initialized
INFO - 2018-02-06 07:31:14 --> Model Class Initialized
INFO - 2018-02-06 07:31:14 --> Controller Class Initialized
INFO - 2018-02-06 07:31:14 --> Model Class Initialized
DEBUG - 2018-02-06 07:31:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:31:16 --> Config Class Initialized
INFO - 2018-02-06 07:31:16 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:31:16 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:31:16 --> Utf8 Class Initialized
INFO - 2018-02-06 07:31:16 --> URI Class Initialized
INFO - 2018-02-06 07:31:16 --> Router Class Initialized
INFO - 2018-02-06 07:31:16 --> Output Class Initialized
INFO - 2018-02-06 07:31:16 --> Security Class Initialized
DEBUG - 2018-02-06 07:31:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:31:16 --> Input Class Initialized
INFO - 2018-02-06 07:31:16 --> Language Class Initialized
INFO - 2018-02-06 07:31:16 --> Loader Class Initialized
INFO - 2018-02-06 07:31:16 --> Helper loaded: url_helper
INFO - 2018-02-06 07:31:16 --> Helper loaded: form_helper
INFO - 2018-02-06 07:31:16 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:31:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:31:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:31:16 --> Form Validation Class Initialized
INFO - 2018-02-06 07:31:16 --> Model Class Initialized
INFO - 2018-02-06 07:31:16 --> Controller Class Initialized
INFO - 2018-02-06 07:31:16 --> Model Class Initialized
DEBUG - 2018-02-06 07:31:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:31:16 --> Config Class Initialized
INFO - 2018-02-06 07:31:16 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:31:16 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:31:16 --> Utf8 Class Initialized
INFO - 2018-02-06 07:31:16 --> URI Class Initialized
INFO - 2018-02-06 07:31:16 --> Router Class Initialized
INFO - 2018-02-06 07:31:16 --> Output Class Initialized
INFO - 2018-02-06 07:31:16 --> Security Class Initialized
DEBUG - 2018-02-06 07:31:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:31:16 --> Input Class Initialized
INFO - 2018-02-06 07:31:16 --> Language Class Initialized
INFO - 2018-02-06 07:31:16 --> Loader Class Initialized
INFO - 2018-02-06 07:31:16 --> Helper loaded: url_helper
INFO - 2018-02-06 07:31:16 --> Helper loaded: form_helper
INFO - 2018-02-06 07:31:16 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:31:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:31:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:31:16 --> Form Validation Class Initialized
INFO - 2018-02-06 07:31:16 --> Model Class Initialized
INFO - 2018-02-06 07:31:16 --> Controller Class Initialized
INFO - 2018-02-06 07:31:16 --> Model Class Initialized
DEBUG - 2018-02-06 07:31:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:31:17 --> Config Class Initialized
INFO - 2018-02-06 07:31:17 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:31:17 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:31:17 --> Utf8 Class Initialized
INFO - 2018-02-06 07:31:17 --> URI Class Initialized
INFO - 2018-02-06 07:31:17 --> Router Class Initialized
INFO - 2018-02-06 07:31:17 --> Output Class Initialized
INFO - 2018-02-06 07:31:17 --> Security Class Initialized
DEBUG - 2018-02-06 07:31:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:31:17 --> Input Class Initialized
INFO - 2018-02-06 07:31:17 --> Language Class Initialized
INFO - 2018-02-06 07:31:17 --> Loader Class Initialized
INFO - 2018-02-06 07:31:17 --> Helper loaded: url_helper
INFO - 2018-02-06 07:31:17 --> Helper loaded: form_helper
INFO - 2018-02-06 07:31:17 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:31:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:31:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:31:17 --> Form Validation Class Initialized
INFO - 2018-02-06 07:31:17 --> Model Class Initialized
INFO - 2018-02-06 07:31:17 --> Controller Class Initialized
INFO - 2018-02-06 07:31:17 --> Model Class Initialized
DEBUG - 2018-02-06 07:31:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:31:26 --> Config Class Initialized
INFO - 2018-02-06 07:31:26 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:31:26 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:31:26 --> Utf8 Class Initialized
INFO - 2018-02-06 07:31:26 --> URI Class Initialized
INFO - 2018-02-06 07:31:26 --> Router Class Initialized
INFO - 2018-02-06 07:31:26 --> Output Class Initialized
INFO - 2018-02-06 07:31:26 --> Security Class Initialized
DEBUG - 2018-02-06 07:31:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:31:26 --> Input Class Initialized
INFO - 2018-02-06 07:31:26 --> Language Class Initialized
INFO - 2018-02-06 07:31:26 --> Loader Class Initialized
INFO - 2018-02-06 07:31:26 --> Helper loaded: url_helper
INFO - 2018-02-06 07:31:26 --> Helper loaded: form_helper
INFO - 2018-02-06 07:31:26 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:31:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:31:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:31:26 --> Form Validation Class Initialized
INFO - 2018-02-06 07:31:26 --> Model Class Initialized
INFO - 2018-02-06 07:31:26 --> Controller Class Initialized
INFO - 2018-02-06 07:31:26 --> Model Class Initialized
DEBUG - 2018-02-06 07:31:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:32:37 --> Config Class Initialized
INFO - 2018-02-06 07:32:37 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:32:37 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:32:37 --> Utf8 Class Initialized
INFO - 2018-02-06 07:32:37 --> URI Class Initialized
INFO - 2018-02-06 07:32:37 --> Router Class Initialized
INFO - 2018-02-06 07:32:37 --> Output Class Initialized
INFO - 2018-02-06 07:32:37 --> Security Class Initialized
DEBUG - 2018-02-06 07:32:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:32:37 --> Input Class Initialized
INFO - 2018-02-06 07:32:37 --> Language Class Initialized
INFO - 2018-02-06 07:32:37 --> Loader Class Initialized
INFO - 2018-02-06 07:32:37 --> Helper loaded: url_helper
INFO - 2018-02-06 07:32:37 --> Helper loaded: form_helper
INFO - 2018-02-06 07:32:37 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:32:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:32:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:32:37 --> Form Validation Class Initialized
INFO - 2018-02-06 07:32:37 --> Model Class Initialized
INFO - 2018-02-06 07:32:37 --> Controller Class Initialized
INFO - 2018-02-06 07:32:37 --> Model Class Initialized
DEBUG - 2018-02-06 07:32:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:33:08 --> Config Class Initialized
INFO - 2018-02-06 07:33:08 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:33:08 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:33:08 --> Utf8 Class Initialized
INFO - 2018-02-06 07:33:08 --> URI Class Initialized
INFO - 2018-02-06 07:33:08 --> Router Class Initialized
INFO - 2018-02-06 07:33:08 --> Output Class Initialized
INFO - 2018-02-06 07:33:08 --> Security Class Initialized
DEBUG - 2018-02-06 07:33:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:33:08 --> Input Class Initialized
INFO - 2018-02-06 07:33:08 --> Language Class Initialized
INFO - 2018-02-06 07:33:08 --> Loader Class Initialized
INFO - 2018-02-06 07:33:08 --> Helper loaded: url_helper
INFO - 2018-02-06 07:33:08 --> Helper loaded: form_helper
INFO - 2018-02-06 07:33:08 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:33:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:33:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:33:08 --> Form Validation Class Initialized
INFO - 2018-02-06 07:33:08 --> Model Class Initialized
INFO - 2018-02-06 07:33:08 --> Controller Class Initialized
INFO - 2018-02-06 07:33:08 --> Model Class Initialized
DEBUG - 2018-02-06 07:33:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:33:24 --> Config Class Initialized
INFO - 2018-02-06 07:33:24 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:33:24 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:33:24 --> Utf8 Class Initialized
INFO - 2018-02-06 07:33:24 --> URI Class Initialized
INFO - 2018-02-06 07:33:24 --> Router Class Initialized
INFO - 2018-02-06 07:33:24 --> Output Class Initialized
INFO - 2018-02-06 07:33:24 --> Security Class Initialized
DEBUG - 2018-02-06 07:33:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:33:24 --> Input Class Initialized
INFO - 2018-02-06 07:33:24 --> Language Class Initialized
INFO - 2018-02-06 07:33:24 --> Loader Class Initialized
INFO - 2018-02-06 07:33:24 --> Helper loaded: url_helper
INFO - 2018-02-06 07:33:24 --> Helper loaded: form_helper
INFO - 2018-02-06 07:33:24 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:33:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:33:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:33:24 --> Form Validation Class Initialized
INFO - 2018-02-06 07:33:24 --> Model Class Initialized
INFO - 2018-02-06 07:33:24 --> Controller Class Initialized
INFO - 2018-02-06 07:33:24 --> Model Class Initialized
DEBUG - 2018-02-06 07:33:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:33:24 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:33:24 --> Final output sent to browser
DEBUG - 2018-02-06 07:33:24 --> Total execution time: 0.0395
INFO - 2018-02-06 07:33:59 --> Config Class Initialized
INFO - 2018-02-06 07:33:59 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:33:59 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:33:59 --> Utf8 Class Initialized
INFO - 2018-02-06 07:33:59 --> URI Class Initialized
INFO - 2018-02-06 07:33:59 --> Router Class Initialized
INFO - 2018-02-06 07:33:59 --> Output Class Initialized
INFO - 2018-02-06 07:33:59 --> Security Class Initialized
DEBUG - 2018-02-06 07:33:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:33:59 --> Input Class Initialized
INFO - 2018-02-06 07:33:59 --> Language Class Initialized
INFO - 2018-02-06 07:33:59 --> Loader Class Initialized
INFO - 2018-02-06 07:33:59 --> Helper loaded: url_helper
INFO - 2018-02-06 07:33:59 --> Helper loaded: form_helper
INFO - 2018-02-06 07:33:59 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:33:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:33:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:33:59 --> Form Validation Class Initialized
INFO - 2018-02-06 07:33:59 --> Model Class Initialized
INFO - 2018-02-06 07:33:59 --> Controller Class Initialized
INFO - 2018-02-06 07:33:59 --> Model Class Initialized
DEBUG - 2018-02-06 07:33:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:33:59 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:33:59 --> Final output sent to browser
DEBUG - 2018-02-06 07:33:59 --> Total execution time: 0.0689
INFO - 2018-02-06 07:34:00 --> Config Class Initialized
INFO - 2018-02-06 07:34:00 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:34:00 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:34:00 --> Utf8 Class Initialized
INFO - 2018-02-06 07:34:00 --> URI Class Initialized
INFO - 2018-02-06 07:34:00 --> Router Class Initialized
INFO - 2018-02-06 07:34:00 --> Output Class Initialized
INFO - 2018-02-06 07:34:00 --> Security Class Initialized
DEBUG - 2018-02-06 07:34:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:34:00 --> Input Class Initialized
INFO - 2018-02-06 07:34:00 --> Language Class Initialized
INFO - 2018-02-06 07:34:00 --> Loader Class Initialized
INFO - 2018-02-06 07:34:00 --> Helper loaded: url_helper
INFO - 2018-02-06 07:34:00 --> Helper loaded: form_helper
INFO - 2018-02-06 07:34:00 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:34:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:34:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:34:00 --> Form Validation Class Initialized
INFO - 2018-02-06 07:34:00 --> Model Class Initialized
INFO - 2018-02-06 07:34:00 --> Controller Class Initialized
INFO - 2018-02-06 07:34:00 --> Model Class Initialized
DEBUG - 2018-02-06 07:34:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:34:00 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:34:00 --> Final output sent to browser
DEBUG - 2018-02-06 07:34:00 --> Total execution time: 0.0600
INFO - 2018-02-06 07:34:03 --> Config Class Initialized
INFO - 2018-02-06 07:34:03 --> Hooks Class Initialized
INFO - 2018-02-06 07:34:03 --> Config Class Initialized
INFO - 2018-02-06 07:34:03 --> Hooks Class Initialized
INFO - 2018-02-06 07:34:03 --> Config Class Initialized
INFO - 2018-02-06 07:34:03 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:34:03 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:34:03 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:34:03 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:34:03 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:34:03 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:34:03 --> URI Class Initialized
INFO - 2018-02-06 07:34:03 --> Utf8 Class Initialized
INFO - 2018-02-06 07:34:03 --> URI Class Initialized
INFO - 2018-02-06 07:34:03 --> URI Class Initialized
INFO - 2018-02-06 07:34:03 --> Router Class Initialized
INFO - 2018-02-06 07:34:03 --> Router Class Initialized
INFO - 2018-02-06 07:34:03 --> Router Class Initialized
INFO - 2018-02-06 07:34:03 --> Output Class Initialized
INFO - 2018-02-06 07:34:03 --> Output Class Initialized
INFO - 2018-02-06 07:34:03 --> Security Class Initialized
INFO - 2018-02-06 07:34:03 --> Output Class Initialized
INFO - 2018-02-06 07:34:03 --> Security Class Initialized
DEBUG - 2018-02-06 07:34:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:34:03 --> Input Class Initialized
INFO - 2018-02-06 07:34:03 --> Security Class Initialized
DEBUG - 2018-02-06 07:34:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:34:03 --> Language Class Initialized
INFO - 2018-02-06 07:34:03 --> Input Class Initialized
INFO - 2018-02-06 07:34:03 --> Language Class Initialized
ERROR - 2018-02-06 07:34:03 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-02-06 07:34:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:34:03 --> Input Class Initialized
ERROR - 2018-02-06 07:34:03 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-06 07:34:03 --> Language Class Initialized
ERROR - 2018-02-06 07:34:03 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-06 07:34:37 --> Config Class Initialized
INFO - 2018-02-06 07:34:37 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:34:37 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:34:37 --> Utf8 Class Initialized
INFO - 2018-02-06 07:34:37 --> URI Class Initialized
INFO - 2018-02-06 07:34:37 --> Router Class Initialized
INFO - 2018-02-06 07:34:37 --> Output Class Initialized
INFO - 2018-02-06 07:34:37 --> Security Class Initialized
DEBUG - 2018-02-06 07:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:34:37 --> Input Class Initialized
INFO - 2018-02-06 07:34:37 --> Language Class Initialized
INFO - 2018-02-06 07:34:37 --> Loader Class Initialized
INFO - 2018-02-06 07:34:37 --> Helper loaded: url_helper
INFO - 2018-02-06 07:34:37 --> Helper loaded: form_helper
INFO - 2018-02-06 07:34:37 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:34:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:34:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:34:37 --> Form Validation Class Initialized
INFO - 2018-02-06 07:34:37 --> Model Class Initialized
INFO - 2018-02-06 07:34:37 --> Controller Class Initialized
INFO - 2018-02-06 07:34:37 --> Model Class Initialized
DEBUG - 2018-02-06 07:34:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:34:37 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:34:37 --> Final output sent to browser
DEBUG - 2018-02-06 07:34:37 --> Total execution time: 0.0661
INFO - 2018-02-06 07:34:37 --> Config Class Initialized
INFO - 2018-02-06 07:34:37 --> Hooks Class Initialized
INFO - 2018-02-06 07:34:37 --> Config Class Initialized
INFO - 2018-02-06 07:34:37 --> Hooks Class Initialized
INFO - 2018-02-06 07:34:37 --> Config Class Initialized
INFO - 2018-02-06 07:34:37 --> Hooks Class Initialized
INFO - 2018-02-06 07:34:37 --> Config Class Initialized
INFO - 2018-02-06 07:34:37 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:34:37 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:34:37 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:34:37 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:34:37 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:34:37 --> Utf8 Class Initialized
INFO - 2018-02-06 07:34:37 --> Utf8 Class Initialized
INFO - 2018-02-06 07:34:37 --> URI Class Initialized
DEBUG - 2018-02-06 07:34:37 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:34:37 --> URI Class Initialized
INFO - 2018-02-06 07:34:37 --> URI Class Initialized
INFO - 2018-02-06 07:34:37 --> Utf8 Class Initialized
INFO - 2018-02-06 07:34:37 --> Router Class Initialized
INFO - 2018-02-06 07:34:37 --> URI Class Initialized
INFO - 2018-02-06 07:34:37 --> Router Class Initialized
INFO - 2018-02-06 07:34:37 --> Output Class Initialized
INFO - 2018-02-06 07:34:37 --> Output Class Initialized
INFO - 2018-02-06 07:34:37 --> Router Class Initialized
INFO - 2018-02-06 07:34:37 --> Security Class Initialized
INFO - 2018-02-06 07:34:37 --> Security Class Initialized
DEBUG - 2018-02-06 07:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:34:37 --> Output Class Initialized
INFO - 2018-02-06 07:34:37 --> Input Class Initialized
INFO - 2018-02-06 07:34:37 --> Language Class Initialized
DEBUG - 2018-02-06 07:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:34:37 --> Input Class Initialized
INFO - 2018-02-06 07:34:37 --> Security Class Initialized
INFO - 2018-02-06 07:34:37 --> Router Class Initialized
INFO - 2018-02-06 07:34:37 --> Language Class Initialized
ERROR - 2018-02-06 07:34:37 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-02-06 07:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:34:37 --> Input Class Initialized
ERROR - 2018-02-06 07:34:37 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:34:37 --> Output Class Initialized
INFO - 2018-02-06 07:34:37 --> Language Class Initialized
ERROR - 2018-02-06 07:34:37 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:34:37 --> Security Class Initialized
DEBUG - 2018-02-06 07:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:34:37 --> Input Class Initialized
INFO - 2018-02-06 07:34:37 --> Language Class Initialized
ERROR - 2018-02-06 07:34:37 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:34:37 --> Config Class Initialized
INFO - 2018-02-06 07:34:37 --> Config Class Initialized
INFO - 2018-02-06 07:34:37 --> Hooks Class Initialized
INFO - 2018-02-06 07:34:37 --> Hooks Class Initialized
INFO - 2018-02-06 07:34:37 --> Config Class Initialized
INFO - 2018-02-06 07:34:37 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:34:37 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:34:37 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:34:37 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:34:37 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:34:37 --> Utf8 Class Initialized
INFO - 2018-02-06 07:34:37 --> Utf8 Class Initialized
INFO - 2018-02-06 07:34:37 --> URI Class Initialized
INFO - 2018-02-06 07:34:37 --> URI Class Initialized
INFO - 2018-02-06 07:34:37 --> URI Class Initialized
INFO - 2018-02-06 07:34:37 --> Router Class Initialized
INFO - 2018-02-06 07:34:37 --> Router Class Initialized
INFO - 2018-02-06 07:34:37 --> Router Class Initialized
INFO - 2018-02-06 07:34:37 --> Output Class Initialized
INFO - 2018-02-06 07:34:37 --> Output Class Initialized
INFO - 2018-02-06 07:34:37 --> Output Class Initialized
INFO - 2018-02-06 07:34:37 --> Security Class Initialized
INFO - 2018-02-06 07:34:37 --> Security Class Initialized
INFO - 2018-02-06 07:34:37 --> Security Class Initialized
DEBUG - 2018-02-06 07:34:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:34:37 --> Input Class Initialized
INFO - 2018-02-06 07:34:37 --> Input Class Initialized
DEBUG - 2018-02-06 07:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:34:37 --> Input Class Initialized
INFO - 2018-02-06 07:34:37 --> Language Class Initialized
INFO - 2018-02-06 07:34:37 --> Language Class Initialized
INFO - 2018-02-06 07:34:37 --> Language Class Initialized
ERROR - 2018-02-06 07:34:37 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-06 07:34:37 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-06 07:34:37 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-06 07:34:38 --> Config Class Initialized
INFO - 2018-02-06 07:34:38 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:34:38 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:34:38 --> Utf8 Class Initialized
INFO - 2018-02-06 07:34:38 --> URI Class Initialized
INFO - 2018-02-06 07:34:38 --> Router Class Initialized
INFO - 2018-02-06 07:34:38 --> Output Class Initialized
INFO - 2018-02-06 07:34:38 --> Security Class Initialized
DEBUG - 2018-02-06 07:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:34:38 --> Input Class Initialized
INFO - 2018-02-06 07:34:38 --> Language Class Initialized
INFO - 2018-02-06 07:34:38 --> Loader Class Initialized
INFO - 2018-02-06 07:34:38 --> Helper loaded: url_helper
INFO - 2018-02-06 07:34:38 --> Helper loaded: form_helper
INFO - 2018-02-06 07:34:38 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:34:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:34:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:34:38 --> Form Validation Class Initialized
INFO - 2018-02-06 07:34:38 --> Model Class Initialized
INFO - 2018-02-06 07:34:38 --> Controller Class Initialized
INFO - 2018-02-06 07:34:38 --> Model Class Initialized
DEBUG - 2018-02-06 07:34:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:34:38 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:34:38 --> Final output sent to browser
DEBUG - 2018-02-06 07:34:38 --> Total execution time: 0.0571
INFO - 2018-02-06 07:34:38 --> Config Class Initialized
INFO - 2018-02-06 07:34:38 --> Config Class Initialized
INFO - 2018-02-06 07:34:38 --> Hooks Class Initialized
INFO - 2018-02-06 07:34:38 --> Hooks Class Initialized
INFO - 2018-02-06 07:34:38 --> Config Class Initialized
INFO - 2018-02-06 07:34:38 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:34:38 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:34:38 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:34:38 --> Utf8 Class Initialized
INFO - 2018-02-06 07:34:38 --> Utf8 Class Initialized
INFO - 2018-02-06 07:34:38 --> Config Class Initialized
INFO - 2018-02-06 07:34:38 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:34:38 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:34:38 --> URI Class Initialized
INFO - 2018-02-06 07:34:38 --> Utf8 Class Initialized
INFO - 2018-02-06 07:34:38 --> URI Class Initialized
INFO - 2018-02-06 07:34:38 --> URI Class Initialized
INFO - 2018-02-06 07:34:38 --> Router Class Initialized
INFO - 2018-02-06 07:34:38 --> Router Class Initialized
DEBUG - 2018-02-06 07:34:38 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:34:38 --> Utf8 Class Initialized
INFO - 2018-02-06 07:34:38 --> Router Class Initialized
INFO - 2018-02-06 07:34:38 --> Output Class Initialized
INFO - 2018-02-06 07:34:38 --> URI Class Initialized
INFO - 2018-02-06 07:34:38 --> Output Class Initialized
INFO - 2018-02-06 07:34:38 --> Security Class Initialized
INFO - 2018-02-06 07:34:38 --> Output Class Initialized
INFO - 2018-02-06 07:34:38 --> Router Class Initialized
INFO - 2018-02-06 07:34:38 --> Security Class Initialized
DEBUG - 2018-02-06 07:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:34:38 --> Input Class Initialized
INFO - 2018-02-06 07:34:38 --> Security Class Initialized
INFO - 2018-02-06 07:34:38 --> Language Class Initialized
DEBUG - 2018-02-06 07:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:34:38 --> Output Class Initialized
INFO - 2018-02-06 07:34:38 --> Input Class Initialized
DEBUG - 2018-02-06 07:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:34:38 --> Input Class Initialized
INFO - 2018-02-06 07:34:38 --> Language Class Initialized
ERROR - 2018-02-06 07:34:38 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:34:38 --> Security Class Initialized
INFO - 2018-02-06 07:34:38 --> Language Class Initialized
ERROR - 2018-02-06 07:34:38 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-06 07:34:38 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-02-06 07:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:34:38 --> Input Class Initialized
INFO - 2018-02-06 07:34:38 --> Language Class Initialized
ERROR - 2018-02-06 07:34:38 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:34:38 --> Config Class Initialized
INFO - 2018-02-06 07:34:38 --> Config Class Initialized
INFO - 2018-02-06 07:34:38 --> Hooks Class Initialized
INFO - 2018-02-06 07:34:38 --> Hooks Class Initialized
INFO - 2018-02-06 07:34:38 --> Config Class Initialized
INFO - 2018-02-06 07:34:38 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:34:38 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:34:38 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:34:38 --> Utf8 Class Initialized
INFO - 2018-02-06 07:34:38 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:34:38 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:34:38 --> Utf8 Class Initialized
INFO - 2018-02-06 07:34:38 --> URI Class Initialized
INFO - 2018-02-06 07:34:38 --> URI Class Initialized
INFO - 2018-02-06 07:34:38 --> URI Class Initialized
INFO - 2018-02-06 07:34:38 --> Router Class Initialized
INFO - 2018-02-06 07:34:38 --> Router Class Initialized
INFO - 2018-02-06 07:34:38 --> Router Class Initialized
INFO - 2018-02-06 07:34:38 --> Output Class Initialized
INFO - 2018-02-06 07:34:38 --> Output Class Initialized
INFO - 2018-02-06 07:34:38 --> Output Class Initialized
INFO - 2018-02-06 07:34:38 --> Security Class Initialized
INFO - 2018-02-06 07:34:38 --> Security Class Initialized
INFO - 2018-02-06 07:34:38 --> Security Class Initialized
DEBUG - 2018-02-06 07:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:34:38 --> Input Class Initialized
DEBUG - 2018-02-06 07:34:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:34:38 --> Language Class Initialized
INFO - 2018-02-06 07:34:38 --> Input Class Initialized
INFO - 2018-02-06 07:34:38 --> Input Class Initialized
INFO - 2018-02-06 07:34:38 --> Language Class Initialized
INFO - 2018-02-06 07:34:38 --> Language Class Initialized
ERROR - 2018-02-06 07:34:38 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-06 07:34:38 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-06 07:34:38 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-06 07:34:38 --> Config Class Initialized
INFO - 2018-02-06 07:34:38 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:34:38 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:34:38 --> Utf8 Class Initialized
INFO - 2018-02-06 07:34:38 --> URI Class Initialized
INFO - 2018-02-06 07:34:38 --> Router Class Initialized
INFO - 2018-02-06 07:34:38 --> Output Class Initialized
INFO - 2018-02-06 07:34:38 --> Security Class Initialized
DEBUG - 2018-02-06 07:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:34:38 --> Input Class Initialized
INFO - 2018-02-06 07:34:38 --> Language Class Initialized
INFO - 2018-02-06 07:34:38 --> Loader Class Initialized
INFO - 2018-02-06 07:34:38 --> Helper loaded: url_helper
INFO - 2018-02-06 07:34:38 --> Helper loaded: form_helper
INFO - 2018-02-06 07:34:38 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:34:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:34:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:34:38 --> Form Validation Class Initialized
INFO - 2018-02-06 07:34:38 --> Model Class Initialized
INFO - 2018-02-06 07:34:38 --> Controller Class Initialized
INFO - 2018-02-06 07:34:38 --> Model Class Initialized
DEBUG - 2018-02-06 07:34:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:34:38 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:34:38 --> Final output sent to browser
DEBUG - 2018-02-06 07:34:38 --> Total execution time: 0.0429
INFO - 2018-02-06 07:34:38 --> Config Class Initialized
INFO - 2018-02-06 07:34:38 --> Hooks Class Initialized
INFO - 2018-02-06 07:34:38 --> Config Class Initialized
INFO - 2018-02-06 07:34:38 --> Config Class Initialized
INFO - 2018-02-06 07:34:38 --> Hooks Class Initialized
INFO - 2018-02-06 07:34:38 --> Hooks Class Initialized
INFO - 2018-02-06 07:34:38 --> Config Class Initialized
INFO - 2018-02-06 07:34:38 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:34:38 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:34:38 --> Utf8 Class Initialized
INFO - 2018-02-06 07:34:38 --> URI Class Initialized
DEBUG - 2018-02-06 07:34:38 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:34:38 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:34:38 --> Utf8 Class Initialized
INFO - 2018-02-06 07:34:38 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:34:38 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:34:38 --> Utf8 Class Initialized
INFO - 2018-02-06 07:34:38 --> Router Class Initialized
INFO - 2018-02-06 07:34:38 --> URI Class Initialized
INFO - 2018-02-06 07:34:38 --> URI Class Initialized
INFO - 2018-02-06 07:34:38 --> URI Class Initialized
INFO - 2018-02-06 07:34:38 --> Router Class Initialized
INFO - 2018-02-06 07:34:38 --> Output Class Initialized
INFO - 2018-02-06 07:34:38 --> Router Class Initialized
INFO - 2018-02-06 07:34:38 --> Router Class Initialized
INFO - 2018-02-06 07:34:38 --> Security Class Initialized
INFO - 2018-02-06 07:34:38 --> Output Class Initialized
INFO - 2018-02-06 07:34:38 --> Output Class Initialized
INFO - 2018-02-06 07:34:38 --> Output Class Initialized
DEBUG - 2018-02-06 07:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:34:38 --> Input Class Initialized
INFO - 2018-02-06 07:34:38 --> Security Class Initialized
INFO - 2018-02-06 07:34:38 --> Security Class Initialized
INFO - 2018-02-06 07:34:38 --> Language Class Initialized
INFO - 2018-02-06 07:34:38 --> Security Class Initialized
DEBUG - 2018-02-06 07:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:34:38 --> Input Class Initialized
DEBUG - 2018-02-06 07:34:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:34:38 --> Language Class Initialized
INFO - 2018-02-06 07:34:38 --> Input Class Initialized
INFO - 2018-02-06 07:34:38 --> Input Class Initialized
ERROR - 2018-02-06 07:34:38 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:34:38 --> Language Class Initialized
INFO - 2018-02-06 07:34:38 --> Language Class Initialized
ERROR - 2018-02-06 07:34:38 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-06 07:34:38 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-06 07:34:38 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:34:39 --> Config Class Initialized
INFO - 2018-02-06 07:34:39 --> Hooks Class Initialized
INFO - 2018-02-06 07:34:39 --> Config Class Initialized
INFO - 2018-02-06 07:34:39 --> Hooks Class Initialized
INFO - 2018-02-06 07:34:39 --> Config Class Initialized
INFO - 2018-02-06 07:34:39 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:34:39 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:34:39 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:34:39 --> Utf8 Class Initialized
INFO - 2018-02-06 07:34:39 --> Utf8 Class Initialized
INFO - 2018-02-06 07:34:39 --> URI Class Initialized
INFO - 2018-02-06 07:34:39 --> URI Class Initialized
DEBUG - 2018-02-06 07:34:39 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:34:39 --> Utf8 Class Initialized
INFO - 2018-02-06 07:34:39 --> Router Class Initialized
INFO - 2018-02-06 07:34:39 --> URI Class Initialized
INFO - 2018-02-06 07:34:39 --> Router Class Initialized
INFO - 2018-02-06 07:34:39 --> Output Class Initialized
INFO - 2018-02-06 07:34:39 --> Output Class Initialized
INFO - 2018-02-06 07:34:39 --> Router Class Initialized
INFO - 2018-02-06 07:34:39 --> Security Class Initialized
INFO - 2018-02-06 07:34:39 --> Security Class Initialized
INFO - 2018-02-06 07:34:39 --> Output Class Initialized
DEBUG - 2018-02-06 07:34:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:34:39 --> Input Class Initialized
INFO - 2018-02-06 07:34:39 --> Input Class Initialized
INFO - 2018-02-06 07:34:39 --> Security Class Initialized
INFO - 2018-02-06 07:34:39 --> Language Class Initialized
INFO - 2018-02-06 07:34:39 --> Language Class Initialized
DEBUG - 2018-02-06 07:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:34:39 --> Input Class Initialized
ERROR - 2018-02-06 07:34:39 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-06 07:34:39 --> Language Class Initialized
ERROR - 2018-02-06 07:34:39 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-06 07:34:39 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-06 07:34:39 --> Config Class Initialized
INFO - 2018-02-06 07:34:39 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:34:39 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:34:39 --> Utf8 Class Initialized
INFO - 2018-02-06 07:34:39 --> URI Class Initialized
INFO - 2018-02-06 07:34:39 --> Router Class Initialized
INFO - 2018-02-06 07:34:39 --> Output Class Initialized
INFO - 2018-02-06 07:34:39 --> Security Class Initialized
DEBUG - 2018-02-06 07:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:34:39 --> Input Class Initialized
INFO - 2018-02-06 07:34:39 --> Language Class Initialized
INFO - 2018-02-06 07:34:39 --> Loader Class Initialized
INFO - 2018-02-06 07:34:39 --> Helper loaded: url_helper
INFO - 2018-02-06 07:34:39 --> Helper loaded: form_helper
INFO - 2018-02-06 07:34:39 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:34:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:34:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:34:39 --> Form Validation Class Initialized
INFO - 2018-02-06 07:34:39 --> Model Class Initialized
INFO - 2018-02-06 07:34:39 --> Controller Class Initialized
INFO - 2018-02-06 07:34:39 --> Model Class Initialized
DEBUG - 2018-02-06 07:34:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:34:39 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:34:39 --> Final output sent to browser
DEBUG - 2018-02-06 07:34:39 --> Total execution time: 0.0658
INFO - 2018-02-06 07:34:39 --> Config Class Initialized
INFO - 2018-02-06 07:34:39 --> Hooks Class Initialized
INFO - 2018-02-06 07:34:39 --> Config Class Initialized
INFO - 2018-02-06 07:34:39 --> Config Class Initialized
INFO - 2018-02-06 07:34:39 --> Hooks Class Initialized
INFO - 2018-02-06 07:34:39 --> Hooks Class Initialized
INFO - 2018-02-06 07:34:39 --> Config Class Initialized
DEBUG - 2018-02-06 07:34:39 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:34:39 --> Hooks Class Initialized
INFO - 2018-02-06 07:34:39 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:34:39 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:34:39 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:34:39 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:34:39 --> URI Class Initialized
INFO - 2018-02-06 07:34:39 --> Utf8 Class Initialized
INFO - 2018-02-06 07:34:39 --> URI Class Initialized
DEBUG - 2018-02-06 07:34:39 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:34:39 --> URI Class Initialized
INFO - 2018-02-06 07:34:39 --> Utf8 Class Initialized
INFO - 2018-02-06 07:34:39 --> Router Class Initialized
INFO - 2018-02-06 07:34:39 --> Router Class Initialized
INFO - 2018-02-06 07:34:39 --> URI Class Initialized
INFO - 2018-02-06 07:34:39 --> Output Class Initialized
INFO - 2018-02-06 07:34:39 --> Router Class Initialized
INFO - 2018-02-06 07:34:39 --> Output Class Initialized
INFO - 2018-02-06 07:34:39 --> Router Class Initialized
INFO - 2018-02-06 07:34:39 --> Security Class Initialized
INFO - 2018-02-06 07:34:39 --> Security Class Initialized
INFO - 2018-02-06 07:34:39 --> Output Class Initialized
INFO - 2018-02-06 07:34:39 --> Output Class Initialized
DEBUG - 2018-02-06 07:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:34:39 --> Input Class Initialized
DEBUG - 2018-02-06 07:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:34:39 --> Security Class Initialized
INFO - 2018-02-06 07:34:39 --> Security Class Initialized
INFO - 2018-02-06 07:34:39 --> Input Class Initialized
INFO - 2018-02-06 07:34:39 --> Language Class Initialized
INFO - 2018-02-06 07:34:39 --> Language Class Initialized
DEBUG - 2018-02-06 07:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:34:39 --> Input Class Initialized
DEBUG - 2018-02-06 07:34:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-06 07:34:39 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:34:39 --> Input Class Initialized
INFO - 2018-02-06 07:34:39 --> Language Class Initialized
ERROR - 2018-02-06 07:34:39 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:34:39 --> Language Class Initialized
ERROR - 2018-02-06 07:34:39 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-06 07:34:39 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:34:39 --> Config Class Initialized
INFO - 2018-02-06 07:34:39 --> Hooks Class Initialized
INFO - 2018-02-06 07:34:39 --> Config Class Initialized
INFO - 2018-02-06 07:34:39 --> Hooks Class Initialized
INFO - 2018-02-06 07:34:39 --> Config Class Initialized
INFO - 2018-02-06 07:34:39 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:34:39 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:34:39 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:34:39 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:34:39 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:34:39 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:34:39 --> URI Class Initialized
INFO - 2018-02-06 07:34:39 --> Utf8 Class Initialized
INFO - 2018-02-06 07:34:39 --> URI Class Initialized
INFO - 2018-02-06 07:34:39 --> URI Class Initialized
INFO - 2018-02-06 07:34:39 --> Router Class Initialized
INFO - 2018-02-06 07:34:39 --> Router Class Initialized
INFO - 2018-02-06 07:34:39 --> Router Class Initialized
INFO - 2018-02-06 07:34:39 --> Output Class Initialized
INFO - 2018-02-06 07:34:39 --> Output Class Initialized
INFO - 2018-02-06 07:34:39 --> Security Class Initialized
INFO - 2018-02-06 07:34:39 --> Output Class Initialized
INFO - 2018-02-06 07:34:39 --> Security Class Initialized
DEBUG - 2018-02-06 07:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:34:39 --> Input Class Initialized
DEBUG - 2018-02-06 07:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:34:39 --> Security Class Initialized
INFO - 2018-02-06 07:34:39 --> Input Class Initialized
INFO - 2018-02-06 07:34:39 --> Language Class Initialized
INFO - 2018-02-06 07:34:39 --> Language Class Initialized
DEBUG - 2018-02-06 07:34:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-06 07:34:39 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-06 07:34:39 --> Input Class Initialized
ERROR - 2018-02-06 07:34:39 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-06 07:34:39 --> Language Class Initialized
ERROR - 2018-02-06 07:34:39 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-06 07:34:41 --> Config Class Initialized
INFO - 2018-02-06 07:34:41 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:34:41 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:34:41 --> Utf8 Class Initialized
INFO - 2018-02-06 07:34:41 --> URI Class Initialized
INFO - 2018-02-06 07:34:41 --> Router Class Initialized
INFO - 2018-02-06 07:34:41 --> Output Class Initialized
INFO - 2018-02-06 07:34:41 --> Security Class Initialized
DEBUG - 2018-02-06 07:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:34:41 --> Input Class Initialized
INFO - 2018-02-06 07:34:41 --> Language Class Initialized
INFO - 2018-02-06 07:34:41 --> Loader Class Initialized
INFO - 2018-02-06 07:34:41 --> Helper loaded: url_helper
INFO - 2018-02-06 07:34:41 --> Helper loaded: form_helper
INFO - 2018-02-06 07:34:41 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:34:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:34:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:34:41 --> Form Validation Class Initialized
INFO - 2018-02-06 07:34:41 --> Model Class Initialized
INFO - 2018-02-06 07:34:41 --> Controller Class Initialized
INFO - 2018-02-06 07:34:41 --> Model Class Initialized
DEBUG - 2018-02-06 07:34:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:34:41 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:34:41 --> Final output sent to browser
DEBUG - 2018-02-06 07:34:41 --> Total execution time: 0.0738
INFO - 2018-02-06 07:34:41 --> Config Class Initialized
INFO - 2018-02-06 07:34:41 --> Config Class Initialized
INFO - 2018-02-06 07:34:41 --> Hooks Class Initialized
INFO - 2018-02-06 07:34:41 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:34:41 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:34:41 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:34:41 --> Utf8 Class Initialized
INFO - 2018-02-06 07:34:41 --> Utf8 Class Initialized
INFO - 2018-02-06 07:34:41 --> URI Class Initialized
INFO - 2018-02-06 07:34:41 --> URI Class Initialized
INFO - 2018-02-06 07:34:41 --> Router Class Initialized
INFO - 2018-02-06 07:34:41 --> Router Class Initialized
INFO - 2018-02-06 07:34:41 --> Output Class Initialized
INFO - 2018-02-06 07:34:41 --> Output Class Initialized
INFO - 2018-02-06 07:34:41 --> Security Class Initialized
INFO - 2018-02-06 07:34:41 --> Security Class Initialized
DEBUG - 2018-02-06 07:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:34:41 --> Input Class Initialized
DEBUG - 2018-02-06 07:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:34:41 --> Input Class Initialized
INFO - 2018-02-06 07:34:41 --> Language Class Initialized
INFO - 2018-02-06 07:34:41 --> Language Class Initialized
ERROR - 2018-02-06 07:34:41 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-06 07:34:41 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:34:41 --> Config Class Initialized
INFO - 2018-02-06 07:34:41 --> Hooks Class Initialized
INFO - 2018-02-06 07:34:41 --> Config Class Initialized
INFO - 2018-02-06 07:34:41 --> Hooks Class Initialized
INFO - 2018-02-06 07:34:41 --> Config Class Initialized
INFO - 2018-02-06 07:34:41 --> Config Class Initialized
INFO - 2018-02-06 07:34:41 --> Hooks Class Initialized
INFO - 2018-02-06 07:34:41 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:34:41 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:34:41 --> Config Class Initialized
DEBUG - 2018-02-06 07:34:41 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:34:41 --> Hooks Class Initialized
INFO - 2018-02-06 07:34:41 --> Utf8 Class Initialized
INFO - 2018-02-06 07:34:41 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:34:41 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:34:41 --> Utf8 Class Initialized
INFO - 2018-02-06 07:34:41 --> URI Class Initialized
INFO - 2018-02-06 07:34:41 --> URI Class Initialized
INFO - 2018-02-06 07:34:41 --> URI Class Initialized
DEBUG - 2018-02-06 07:34:41 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:34:41 --> Router Class Initialized
INFO - 2018-02-06 07:34:41 --> Utf8 Class Initialized
INFO - 2018-02-06 07:34:41 --> Router Class Initialized
INFO - 2018-02-06 07:34:41 --> Router Class Initialized
INFO - 2018-02-06 07:34:41 --> URI Class Initialized
DEBUG - 2018-02-06 07:34:41 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:34:41 --> Output Class Initialized
INFO - 2018-02-06 07:34:41 --> Output Class Initialized
INFO - 2018-02-06 07:34:41 --> Utf8 Class Initialized
INFO - 2018-02-06 07:34:41 --> Output Class Initialized
INFO - 2018-02-06 07:34:41 --> Security Class Initialized
INFO - 2018-02-06 07:34:41 --> Router Class Initialized
INFO - 2018-02-06 07:34:41 --> Security Class Initialized
INFO - 2018-02-06 07:34:41 --> URI Class Initialized
INFO - 2018-02-06 07:34:41 --> Security Class Initialized
DEBUG - 2018-02-06 07:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:34:41 --> Input Class Initialized
DEBUG - 2018-02-06 07:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:34:41 --> Output Class Initialized
INFO - 2018-02-06 07:34:41 --> Router Class Initialized
INFO - 2018-02-06 07:34:41 --> Input Class Initialized
INFO - 2018-02-06 07:34:41 --> Language Class Initialized
DEBUG - 2018-02-06 07:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:34:41 --> Input Class Initialized
INFO - 2018-02-06 07:34:41 --> Language Class Initialized
INFO - 2018-02-06 07:34:41 --> Security Class Initialized
INFO - 2018-02-06 07:34:41 --> Language Class Initialized
ERROR - 2018-02-06 07:34:41 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-06 07:34:41 --> Output Class Initialized
DEBUG - 2018-02-06 07:34:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-06 07:34:41 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-06 07:34:41 --> Input Class Initialized
ERROR - 2018-02-06 07:34:41 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:34:41 --> Security Class Initialized
INFO - 2018-02-06 07:34:41 --> Language Class Initialized
DEBUG - 2018-02-06 07:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:34:41 --> Input Class Initialized
ERROR - 2018-02-06 07:34:41 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-06 07:34:41 --> Language Class Initialized
ERROR - 2018-02-06 07:34:41 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:35:07 --> Config Class Initialized
INFO - 2018-02-06 07:35:07 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:35:07 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:35:07 --> Utf8 Class Initialized
INFO - 2018-02-06 07:35:07 --> URI Class Initialized
INFO - 2018-02-06 07:35:07 --> Router Class Initialized
INFO - 2018-02-06 07:35:07 --> Output Class Initialized
INFO - 2018-02-06 07:35:07 --> Security Class Initialized
DEBUG - 2018-02-06 07:35:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:35:07 --> Input Class Initialized
INFO - 2018-02-06 07:35:07 --> Language Class Initialized
INFO - 2018-02-06 07:35:07 --> Loader Class Initialized
INFO - 2018-02-06 07:35:07 --> Helper loaded: url_helper
INFO - 2018-02-06 07:35:07 --> Helper loaded: form_helper
INFO - 2018-02-06 07:35:07 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:35:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:35:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:35:07 --> Form Validation Class Initialized
INFO - 2018-02-06 07:35:07 --> Model Class Initialized
INFO - 2018-02-06 07:35:07 --> Controller Class Initialized
INFO - 2018-02-06 07:35:07 --> Model Class Initialized
DEBUG - 2018-02-06 07:35:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:35:07 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:35:07 --> Final output sent to browser
DEBUG - 2018-02-06 07:35:07 --> Total execution time: 0.0485
INFO - 2018-02-06 07:35:07 --> Config Class Initialized
INFO - 2018-02-06 07:35:07 --> Config Class Initialized
INFO - 2018-02-06 07:35:07 --> Hooks Class Initialized
INFO - 2018-02-06 07:35:07 --> Config Class Initialized
INFO - 2018-02-06 07:35:07 --> Hooks Class Initialized
INFO - 2018-02-06 07:35:07 --> Hooks Class Initialized
INFO - 2018-02-06 07:35:07 --> Config Class Initialized
INFO - 2018-02-06 07:35:07 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:35:07 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:35:07 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:35:07 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:35:07 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:35:07 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:35:07 --> Utf8 Class Initialized
INFO - 2018-02-06 07:35:07 --> Utf8 Class Initialized
INFO - 2018-02-06 07:35:07 --> Utf8 Class Initialized
INFO - 2018-02-06 07:35:07 --> URI Class Initialized
INFO - 2018-02-06 07:35:07 --> URI Class Initialized
INFO - 2018-02-06 07:35:07 --> URI Class Initialized
INFO - 2018-02-06 07:35:07 --> URI Class Initialized
INFO - 2018-02-06 07:35:07 --> Router Class Initialized
INFO - 2018-02-06 07:35:07 --> Router Class Initialized
INFO - 2018-02-06 07:35:07 --> Router Class Initialized
INFO - 2018-02-06 07:35:07 --> Router Class Initialized
INFO - 2018-02-06 07:35:07 --> Output Class Initialized
INFO - 2018-02-06 07:35:07 --> Output Class Initialized
INFO - 2018-02-06 07:35:07 --> Output Class Initialized
INFO - 2018-02-06 07:35:07 --> Security Class Initialized
INFO - 2018-02-06 07:35:07 --> Output Class Initialized
INFO - 2018-02-06 07:35:07 --> Security Class Initialized
INFO - 2018-02-06 07:35:07 --> Security Class Initialized
DEBUG - 2018-02-06 07:35:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:35:07 --> Input Class Initialized
INFO - 2018-02-06 07:35:07 --> Security Class Initialized
DEBUG - 2018-02-06 07:35:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:35:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:35:07 --> Input Class Initialized
INFO - 2018-02-06 07:35:07 --> Language Class Initialized
INFO - 2018-02-06 07:35:07 --> Input Class Initialized
DEBUG - 2018-02-06 07:35:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:35:07 --> Input Class Initialized
INFO - 2018-02-06 07:35:07 --> Language Class Initialized
INFO - 2018-02-06 07:35:07 --> Language Class Initialized
ERROR - 2018-02-06 07:35:07 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:35:07 --> Language Class Initialized
ERROR - 2018-02-06 07:35:07 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-06 07:35:07 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-06 07:35:07 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:35:07 --> Config Class Initialized
INFO - 2018-02-06 07:35:07 --> Hooks Class Initialized
INFO - 2018-02-06 07:35:07 --> Config Class Initialized
INFO - 2018-02-06 07:35:07 --> Hooks Class Initialized
INFO - 2018-02-06 07:35:07 --> Config Class Initialized
INFO - 2018-02-06 07:35:07 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:35:07 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:35:07 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:35:07 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:35:07 --> Utf8 Class Initialized
INFO - 2018-02-06 07:35:07 --> URI Class Initialized
INFO - 2018-02-06 07:35:07 --> URI Class Initialized
DEBUG - 2018-02-06 07:35:07 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:35:07 --> Utf8 Class Initialized
INFO - 2018-02-06 07:35:07 --> Router Class Initialized
INFO - 2018-02-06 07:35:07 --> Router Class Initialized
INFO - 2018-02-06 07:35:07 --> URI Class Initialized
INFO - 2018-02-06 07:35:07 --> Output Class Initialized
INFO - 2018-02-06 07:35:07 --> Output Class Initialized
INFO - 2018-02-06 07:35:07 --> Security Class Initialized
INFO - 2018-02-06 07:35:07 --> Security Class Initialized
INFO - 2018-02-06 07:35:07 --> Router Class Initialized
DEBUG - 2018-02-06 07:35:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:35:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:35:07 --> Input Class Initialized
INFO - 2018-02-06 07:35:07 --> Input Class Initialized
INFO - 2018-02-06 07:35:07 --> Output Class Initialized
INFO - 2018-02-06 07:35:07 --> Language Class Initialized
INFO - 2018-02-06 07:35:07 --> Language Class Initialized
INFO - 2018-02-06 07:35:07 --> Security Class Initialized
ERROR - 2018-02-06 07:35:07 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-06 07:35:07 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-02-06 07:35:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:35:07 --> Input Class Initialized
INFO - 2018-02-06 07:35:07 --> Language Class Initialized
ERROR - 2018-02-06 07:35:07 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-06 07:35:07 --> Config Class Initialized
INFO - 2018-02-06 07:35:07 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:35:07 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:35:07 --> Utf8 Class Initialized
INFO - 2018-02-06 07:35:07 --> URI Class Initialized
INFO - 2018-02-06 07:35:07 --> Router Class Initialized
INFO - 2018-02-06 07:35:07 --> Output Class Initialized
INFO - 2018-02-06 07:35:07 --> Security Class Initialized
DEBUG - 2018-02-06 07:35:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:35:07 --> Input Class Initialized
INFO - 2018-02-06 07:35:07 --> Language Class Initialized
INFO - 2018-02-06 07:35:07 --> Loader Class Initialized
INFO - 2018-02-06 07:35:07 --> Helper loaded: url_helper
INFO - 2018-02-06 07:35:07 --> Helper loaded: form_helper
INFO - 2018-02-06 07:35:07 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:35:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:35:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:35:07 --> Form Validation Class Initialized
INFO - 2018-02-06 07:35:07 --> Model Class Initialized
INFO - 2018-02-06 07:35:07 --> Controller Class Initialized
INFO - 2018-02-06 07:35:07 --> Model Class Initialized
DEBUG - 2018-02-06 07:35:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:35:10 --> Config Class Initialized
INFO - 2018-02-06 07:35:10 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:35:10 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:35:10 --> Utf8 Class Initialized
INFO - 2018-02-06 07:35:10 --> URI Class Initialized
INFO - 2018-02-06 07:35:10 --> Router Class Initialized
INFO - 2018-02-06 07:35:10 --> Output Class Initialized
INFO - 2018-02-06 07:35:10 --> Security Class Initialized
DEBUG - 2018-02-06 07:35:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:35:10 --> Input Class Initialized
INFO - 2018-02-06 07:35:10 --> Language Class Initialized
INFO - 2018-02-06 07:35:10 --> Loader Class Initialized
INFO - 2018-02-06 07:35:10 --> Helper loaded: url_helper
INFO - 2018-02-06 07:35:10 --> Helper loaded: form_helper
INFO - 2018-02-06 07:35:10 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:35:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:35:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:35:10 --> Form Validation Class Initialized
INFO - 2018-02-06 07:35:10 --> Model Class Initialized
INFO - 2018-02-06 07:35:10 --> Controller Class Initialized
INFO - 2018-02-06 07:35:10 --> Model Class Initialized
DEBUG - 2018-02-06 07:35:10 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:35:10 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:35:10 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:35:10 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:35:10 --> Final output sent to browser
DEBUG - 2018-02-06 07:35:10 --> Total execution time: 0.0558
INFO - 2018-02-06 07:35:15 --> Config Class Initialized
INFO - 2018-02-06 07:35:15 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:35:15 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:35:15 --> Utf8 Class Initialized
INFO - 2018-02-06 07:35:15 --> URI Class Initialized
INFO - 2018-02-06 07:35:15 --> Router Class Initialized
INFO - 2018-02-06 07:35:15 --> Output Class Initialized
INFO - 2018-02-06 07:35:15 --> Security Class Initialized
DEBUG - 2018-02-06 07:35:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:35:15 --> Input Class Initialized
INFO - 2018-02-06 07:35:15 --> Language Class Initialized
INFO - 2018-02-06 07:35:15 --> Loader Class Initialized
INFO - 2018-02-06 07:35:15 --> Helper loaded: url_helper
INFO - 2018-02-06 07:35:15 --> Helper loaded: form_helper
INFO - 2018-02-06 07:35:15 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:35:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:35:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:35:15 --> Form Validation Class Initialized
INFO - 2018-02-06 07:35:15 --> Model Class Initialized
INFO - 2018-02-06 07:35:15 --> Controller Class Initialized
INFO - 2018-02-06 07:35:15 --> Model Class Initialized
DEBUG - 2018-02-06 07:35:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:35:15 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:35:15 --> Final output sent to browser
DEBUG - 2018-02-06 07:35:15 --> Total execution time: 0.0490
INFO - 2018-02-06 07:35:15 --> Config Class Initialized
INFO - 2018-02-06 07:35:15 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:35:15 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:35:15 --> Utf8 Class Initialized
INFO - 2018-02-06 07:35:15 --> URI Class Initialized
INFO - 2018-02-06 07:35:15 --> Router Class Initialized
INFO - 2018-02-06 07:35:15 --> Output Class Initialized
INFO - 2018-02-06 07:35:15 --> Security Class Initialized
DEBUG - 2018-02-06 07:35:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:35:15 --> Input Class Initialized
INFO - 2018-02-06 07:35:15 --> Language Class Initialized
INFO - 2018-02-06 07:35:15 --> Loader Class Initialized
INFO - 2018-02-06 07:35:15 --> Helper loaded: url_helper
INFO - 2018-02-06 07:35:15 --> Helper loaded: form_helper
INFO - 2018-02-06 07:35:15 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:35:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:35:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:35:15 --> Form Validation Class Initialized
INFO - 2018-02-06 07:35:15 --> Model Class Initialized
INFO - 2018-02-06 07:35:15 --> Controller Class Initialized
INFO - 2018-02-06 07:35:15 --> Model Class Initialized
DEBUG - 2018-02-06 07:35:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:35:17 --> Config Class Initialized
INFO - 2018-02-06 07:35:17 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:35:17 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:35:17 --> Utf8 Class Initialized
INFO - 2018-02-06 07:35:17 --> URI Class Initialized
INFO - 2018-02-06 07:35:17 --> Router Class Initialized
INFO - 2018-02-06 07:35:17 --> Output Class Initialized
INFO - 2018-02-06 07:35:17 --> Security Class Initialized
DEBUG - 2018-02-06 07:35:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:35:17 --> Input Class Initialized
INFO - 2018-02-06 07:35:17 --> Language Class Initialized
INFO - 2018-02-06 07:35:17 --> Loader Class Initialized
INFO - 2018-02-06 07:35:17 --> Helper loaded: url_helper
INFO - 2018-02-06 07:35:17 --> Helper loaded: form_helper
INFO - 2018-02-06 07:35:17 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:35:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:35:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:35:17 --> Form Validation Class Initialized
INFO - 2018-02-06 07:35:17 --> Model Class Initialized
INFO - 2018-02-06 07:35:17 --> Controller Class Initialized
INFO - 2018-02-06 07:35:17 --> Model Class Initialized
DEBUG - 2018-02-06 07:35:17 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:35:17 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:35:17 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:35:17 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:35:17 --> Final output sent to browser
DEBUG - 2018-02-06 07:35:17 --> Total execution time: 0.0422
INFO - 2018-02-06 07:35:18 --> Config Class Initialized
INFO - 2018-02-06 07:35:18 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:35:18 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:35:18 --> Utf8 Class Initialized
INFO - 2018-02-06 07:35:18 --> URI Class Initialized
INFO - 2018-02-06 07:35:18 --> Router Class Initialized
INFO - 2018-02-06 07:35:18 --> Output Class Initialized
INFO - 2018-02-06 07:35:18 --> Security Class Initialized
DEBUG - 2018-02-06 07:35:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:35:18 --> Input Class Initialized
INFO - 2018-02-06 07:35:18 --> Language Class Initialized
INFO - 2018-02-06 07:35:18 --> Loader Class Initialized
INFO - 2018-02-06 07:35:18 --> Helper loaded: url_helper
INFO - 2018-02-06 07:35:18 --> Helper loaded: form_helper
INFO - 2018-02-06 07:35:18 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:35:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:35:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:35:18 --> Form Validation Class Initialized
INFO - 2018-02-06 07:35:18 --> Model Class Initialized
INFO - 2018-02-06 07:35:18 --> Controller Class Initialized
INFO - 2018-02-06 07:35:18 --> Model Class Initialized
DEBUG - 2018-02-06 07:35:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:35:18 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:35:18 --> Final output sent to browser
DEBUG - 2018-02-06 07:35:18 --> Total execution time: 0.0486
INFO - 2018-02-06 07:35:19 --> Config Class Initialized
INFO - 2018-02-06 07:35:19 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:35:19 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:35:19 --> Utf8 Class Initialized
INFO - 2018-02-06 07:35:19 --> URI Class Initialized
INFO - 2018-02-06 07:35:19 --> Router Class Initialized
INFO - 2018-02-06 07:35:19 --> Output Class Initialized
INFO - 2018-02-06 07:35:19 --> Security Class Initialized
DEBUG - 2018-02-06 07:35:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:35:19 --> Input Class Initialized
INFO - 2018-02-06 07:35:19 --> Language Class Initialized
INFO - 2018-02-06 07:35:19 --> Loader Class Initialized
INFO - 2018-02-06 07:35:19 --> Helper loaded: url_helper
INFO - 2018-02-06 07:35:19 --> Helper loaded: form_helper
INFO - 2018-02-06 07:35:19 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:35:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:35:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:35:19 --> Form Validation Class Initialized
INFO - 2018-02-06 07:35:19 --> Model Class Initialized
INFO - 2018-02-06 07:35:19 --> Controller Class Initialized
INFO - 2018-02-06 07:35:19 --> Model Class Initialized
DEBUG - 2018-02-06 07:35:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:35:20 --> Config Class Initialized
INFO - 2018-02-06 07:35:20 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:35:20 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:35:20 --> Utf8 Class Initialized
INFO - 2018-02-06 07:35:20 --> URI Class Initialized
INFO - 2018-02-06 07:35:20 --> Router Class Initialized
INFO - 2018-02-06 07:35:20 --> Output Class Initialized
INFO - 2018-02-06 07:35:20 --> Security Class Initialized
DEBUG - 2018-02-06 07:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:35:20 --> Input Class Initialized
INFO - 2018-02-06 07:35:20 --> Language Class Initialized
INFO - 2018-02-06 07:35:20 --> Loader Class Initialized
INFO - 2018-02-06 07:35:20 --> Helper loaded: url_helper
INFO - 2018-02-06 07:35:20 --> Helper loaded: form_helper
INFO - 2018-02-06 07:35:20 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:35:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:35:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:35:20 --> Form Validation Class Initialized
INFO - 2018-02-06 07:35:20 --> Model Class Initialized
INFO - 2018-02-06 07:35:20 --> Controller Class Initialized
INFO - 2018-02-06 07:35:20 --> Model Class Initialized
DEBUG - 2018-02-06 07:35:20 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:35:20 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:35:20 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:35:20 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:35:20 --> Final output sent to browser
DEBUG - 2018-02-06 07:35:20 --> Total execution time: 0.0453
INFO - 2018-02-06 07:35:20 --> Config Class Initialized
INFO - 2018-02-06 07:35:20 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:35:20 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:35:20 --> Utf8 Class Initialized
INFO - 2018-02-06 07:35:20 --> URI Class Initialized
INFO - 2018-02-06 07:35:20 --> Router Class Initialized
INFO - 2018-02-06 07:35:20 --> Output Class Initialized
INFO - 2018-02-06 07:35:20 --> Security Class Initialized
DEBUG - 2018-02-06 07:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:35:20 --> Input Class Initialized
INFO - 2018-02-06 07:35:20 --> Language Class Initialized
INFO - 2018-02-06 07:35:20 --> Loader Class Initialized
INFO - 2018-02-06 07:35:20 --> Helper loaded: url_helper
INFO - 2018-02-06 07:35:20 --> Helper loaded: form_helper
INFO - 2018-02-06 07:35:21 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:35:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:35:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:35:21 --> Form Validation Class Initialized
INFO - 2018-02-06 07:35:21 --> Model Class Initialized
INFO - 2018-02-06 07:35:21 --> Controller Class Initialized
INFO - 2018-02-06 07:35:21 --> Model Class Initialized
DEBUG - 2018-02-06 07:35:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:35:21 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:35:21 --> Final output sent to browser
DEBUG - 2018-02-06 07:35:21 --> Total execution time: 0.0480
INFO - 2018-02-06 07:35:21 --> Config Class Initialized
INFO - 2018-02-06 07:35:21 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:35:21 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:35:21 --> Utf8 Class Initialized
INFO - 2018-02-06 07:35:21 --> URI Class Initialized
INFO - 2018-02-06 07:35:21 --> Router Class Initialized
INFO - 2018-02-06 07:35:21 --> Output Class Initialized
INFO - 2018-02-06 07:35:21 --> Security Class Initialized
DEBUG - 2018-02-06 07:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:35:21 --> Input Class Initialized
INFO - 2018-02-06 07:35:21 --> Language Class Initialized
INFO - 2018-02-06 07:35:21 --> Loader Class Initialized
INFO - 2018-02-06 07:35:21 --> Helper loaded: url_helper
INFO - 2018-02-06 07:35:21 --> Helper loaded: form_helper
INFO - 2018-02-06 07:35:21 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:35:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:35:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:35:21 --> Form Validation Class Initialized
INFO - 2018-02-06 07:35:21 --> Model Class Initialized
INFO - 2018-02-06 07:35:21 --> Controller Class Initialized
INFO - 2018-02-06 07:35:21 --> Model Class Initialized
DEBUG - 2018-02-06 07:35:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:35:47 --> Config Class Initialized
INFO - 2018-02-06 07:35:47 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:35:47 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:35:47 --> Utf8 Class Initialized
INFO - 2018-02-06 07:35:47 --> URI Class Initialized
INFO - 2018-02-06 07:35:47 --> Router Class Initialized
INFO - 2018-02-06 07:35:47 --> Output Class Initialized
INFO - 2018-02-06 07:35:47 --> Security Class Initialized
DEBUG - 2018-02-06 07:35:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:35:47 --> Input Class Initialized
INFO - 2018-02-06 07:35:47 --> Language Class Initialized
INFO - 2018-02-06 07:35:47 --> Loader Class Initialized
INFO - 2018-02-06 07:35:47 --> Helper loaded: url_helper
INFO - 2018-02-06 07:35:47 --> Helper loaded: form_helper
INFO - 2018-02-06 07:35:47 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:35:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:35:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:35:47 --> Form Validation Class Initialized
INFO - 2018-02-06 07:35:47 --> Model Class Initialized
INFO - 2018-02-06 07:35:47 --> Controller Class Initialized
INFO - 2018-02-06 07:35:47 --> Model Class Initialized
DEBUG - 2018-02-06 07:35:47 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:35:47 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:35:47 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:35:47 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:35:47 --> Final output sent to browser
DEBUG - 2018-02-06 07:35:47 --> Total execution time: 0.0429
INFO - 2018-02-06 07:35:51 --> Config Class Initialized
INFO - 2018-02-06 07:35:51 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:35:51 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:35:51 --> Utf8 Class Initialized
INFO - 2018-02-06 07:35:51 --> URI Class Initialized
INFO - 2018-02-06 07:35:51 --> Router Class Initialized
INFO - 2018-02-06 07:35:51 --> Output Class Initialized
INFO - 2018-02-06 07:35:51 --> Security Class Initialized
DEBUG - 2018-02-06 07:35:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:35:51 --> Input Class Initialized
INFO - 2018-02-06 07:35:51 --> Language Class Initialized
INFO - 2018-02-06 07:35:51 --> Loader Class Initialized
INFO - 2018-02-06 07:35:51 --> Helper loaded: url_helper
INFO - 2018-02-06 07:35:51 --> Helper loaded: form_helper
INFO - 2018-02-06 07:35:51 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:35:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:35:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:35:51 --> Form Validation Class Initialized
INFO - 2018-02-06 07:35:51 --> Model Class Initialized
INFO - 2018-02-06 07:35:51 --> Controller Class Initialized
INFO - 2018-02-06 07:35:51 --> Model Class Initialized
DEBUG - 2018-02-06 07:35:51 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:35:51 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:35:51 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:35:51 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:35:51 --> Final output sent to browser
DEBUG - 2018-02-06 07:35:51 --> Total execution time: 0.0512
INFO - 2018-02-06 07:35:51 --> Config Class Initialized
INFO - 2018-02-06 07:35:51 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:35:51 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:35:51 --> Utf8 Class Initialized
INFO - 2018-02-06 07:35:51 --> URI Class Initialized
INFO - 2018-02-06 07:35:51 --> Router Class Initialized
INFO - 2018-02-06 07:35:51 --> Output Class Initialized
INFO - 2018-02-06 07:35:51 --> Security Class Initialized
DEBUG - 2018-02-06 07:35:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:35:51 --> Input Class Initialized
INFO - 2018-02-06 07:35:51 --> Language Class Initialized
INFO - 2018-02-06 07:35:51 --> Loader Class Initialized
INFO - 2018-02-06 07:35:51 --> Helper loaded: url_helper
INFO - 2018-02-06 07:35:51 --> Helper loaded: form_helper
INFO - 2018-02-06 07:35:51 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:35:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:35:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:35:51 --> Form Validation Class Initialized
INFO - 2018-02-06 07:35:51 --> Model Class Initialized
INFO - 2018-02-06 07:35:51 --> Controller Class Initialized
INFO - 2018-02-06 07:35:51 --> Model Class Initialized
DEBUG - 2018-02-06 07:35:51 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:35:51 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:35:51 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:35:51 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:35:51 --> Final output sent to browser
DEBUG - 2018-02-06 07:35:51 --> Total execution time: 0.0520
INFO - 2018-02-06 07:35:52 --> Config Class Initialized
INFO - 2018-02-06 07:35:52 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:35:52 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:35:52 --> Utf8 Class Initialized
INFO - 2018-02-06 07:35:52 --> URI Class Initialized
INFO - 2018-02-06 07:35:52 --> Router Class Initialized
INFO - 2018-02-06 07:35:52 --> Output Class Initialized
INFO - 2018-02-06 07:35:52 --> Security Class Initialized
DEBUG - 2018-02-06 07:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:35:52 --> Input Class Initialized
INFO - 2018-02-06 07:35:52 --> Language Class Initialized
INFO - 2018-02-06 07:35:52 --> Loader Class Initialized
INFO - 2018-02-06 07:35:52 --> Helper loaded: url_helper
INFO - 2018-02-06 07:35:52 --> Helper loaded: form_helper
INFO - 2018-02-06 07:35:52 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:35:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:35:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:35:52 --> Form Validation Class Initialized
INFO - 2018-02-06 07:35:52 --> Model Class Initialized
INFO - 2018-02-06 07:35:52 --> Controller Class Initialized
INFO - 2018-02-06 07:35:52 --> Model Class Initialized
DEBUG - 2018-02-06 07:35:52 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:35:52 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:35:52 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:35:52 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:35:52 --> Final output sent to browser
DEBUG - 2018-02-06 07:35:52 --> Total execution time: 0.0428
INFO - 2018-02-06 07:36:50 --> Config Class Initialized
INFO - 2018-02-06 07:36:50 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:36:50 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:36:50 --> Utf8 Class Initialized
INFO - 2018-02-06 07:36:50 --> URI Class Initialized
INFO - 2018-02-06 07:36:50 --> Router Class Initialized
INFO - 2018-02-06 07:36:50 --> Output Class Initialized
INFO - 2018-02-06 07:36:50 --> Security Class Initialized
DEBUG - 2018-02-06 07:36:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:36:50 --> Input Class Initialized
INFO - 2018-02-06 07:36:50 --> Language Class Initialized
INFO - 2018-02-06 07:36:50 --> Loader Class Initialized
INFO - 2018-02-06 07:36:50 --> Helper loaded: url_helper
INFO - 2018-02-06 07:36:50 --> Helper loaded: form_helper
INFO - 2018-02-06 07:36:50 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:36:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:36:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:36:50 --> Form Validation Class Initialized
INFO - 2018-02-06 07:36:50 --> Model Class Initialized
INFO - 2018-02-06 07:36:50 --> Controller Class Initialized
INFO - 2018-02-06 07:36:50 --> Model Class Initialized
DEBUG - 2018-02-06 07:36:50 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:36:50 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:36:50 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:36:50 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:36:50 --> Final output sent to browser
DEBUG - 2018-02-06 07:36:50 --> Total execution time: 0.0662
INFO - 2018-02-06 07:36:51 --> Config Class Initialized
INFO - 2018-02-06 07:36:51 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:36:51 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:36:51 --> Utf8 Class Initialized
INFO - 2018-02-06 07:36:51 --> URI Class Initialized
INFO - 2018-02-06 07:36:51 --> Router Class Initialized
INFO - 2018-02-06 07:36:51 --> Output Class Initialized
INFO - 2018-02-06 07:36:51 --> Security Class Initialized
DEBUG - 2018-02-06 07:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:36:51 --> Input Class Initialized
INFO - 2018-02-06 07:36:51 --> Language Class Initialized
INFO - 2018-02-06 07:36:51 --> Loader Class Initialized
INFO - 2018-02-06 07:36:51 --> Helper loaded: url_helper
INFO - 2018-02-06 07:36:51 --> Helper loaded: form_helper
INFO - 2018-02-06 07:36:51 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:36:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:36:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:36:51 --> Form Validation Class Initialized
INFO - 2018-02-06 07:36:51 --> Model Class Initialized
INFO - 2018-02-06 07:36:51 --> Controller Class Initialized
INFO - 2018-02-06 07:36:51 --> Model Class Initialized
DEBUG - 2018-02-06 07:36:51 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:36:51 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:36:51 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:36:51 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:36:51 --> Final output sent to browser
DEBUG - 2018-02-06 07:36:51 --> Total execution time: 0.0702
INFO - 2018-02-06 07:36:57 --> Config Class Initialized
INFO - 2018-02-06 07:36:57 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:36:57 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:36:57 --> Utf8 Class Initialized
INFO - 2018-02-06 07:36:57 --> URI Class Initialized
INFO - 2018-02-06 07:36:57 --> Router Class Initialized
INFO - 2018-02-06 07:36:57 --> Output Class Initialized
INFO - 2018-02-06 07:36:57 --> Security Class Initialized
DEBUG - 2018-02-06 07:36:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:36:57 --> Input Class Initialized
INFO - 2018-02-06 07:36:57 --> Language Class Initialized
INFO - 2018-02-06 07:36:57 --> Loader Class Initialized
INFO - 2018-02-06 07:36:57 --> Helper loaded: url_helper
INFO - 2018-02-06 07:36:57 --> Helper loaded: form_helper
INFO - 2018-02-06 07:36:57 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:36:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:36:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:36:57 --> Form Validation Class Initialized
INFO - 2018-02-06 07:36:57 --> Model Class Initialized
INFO - 2018-02-06 07:36:57 --> Controller Class Initialized
INFO - 2018-02-06 07:36:57 --> Model Class Initialized
DEBUG - 2018-02-06 07:36:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:36:57 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:36:57 --> Final output sent to browser
DEBUG - 2018-02-06 07:36:57 --> Total execution time: 0.0485
INFO - 2018-02-06 07:36:57 --> Config Class Initialized
INFO - 2018-02-06 07:36:57 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:36:57 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:36:57 --> Utf8 Class Initialized
INFO - 2018-02-06 07:36:57 --> URI Class Initialized
INFO - 2018-02-06 07:36:57 --> Router Class Initialized
INFO - 2018-02-06 07:36:57 --> Output Class Initialized
INFO - 2018-02-06 07:36:57 --> Security Class Initialized
DEBUG - 2018-02-06 07:36:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:36:57 --> Input Class Initialized
INFO - 2018-02-06 07:36:57 --> Language Class Initialized
INFO - 2018-02-06 07:36:57 --> Loader Class Initialized
INFO - 2018-02-06 07:36:57 --> Helper loaded: url_helper
INFO - 2018-02-06 07:36:57 --> Helper loaded: form_helper
INFO - 2018-02-06 07:36:57 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:36:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:36:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:36:57 --> Form Validation Class Initialized
INFO - 2018-02-06 07:36:57 --> Model Class Initialized
INFO - 2018-02-06 07:36:57 --> Controller Class Initialized
INFO - 2018-02-06 07:36:57 --> Model Class Initialized
DEBUG - 2018-02-06 07:36:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:36:58 --> Config Class Initialized
INFO - 2018-02-06 07:36:58 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:36:58 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:36:58 --> Utf8 Class Initialized
INFO - 2018-02-06 07:36:58 --> URI Class Initialized
INFO - 2018-02-06 07:36:58 --> Router Class Initialized
INFO - 2018-02-06 07:36:58 --> Output Class Initialized
INFO - 2018-02-06 07:36:58 --> Security Class Initialized
DEBUG - 2018-02-06 07:36:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:36:58 --> Input Class Initialized
INFO - 2018-02-06 07:36:58 --> Language Class Initialized
INFO - 2018-02-06 07:36:58 --> Loader Class Initialized
INFO - 2018-02-06 07:36:58 --> Helper loaded: url_helper
INFO - 2018-02-06 07:36:58 --> Helper loaded: form_helper
INFO - 2018-02-06 07:36:58 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:36:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:36:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:36:58 --> Form Validation Class Initialized
INFO - 2018-02-06 07:36:58 --> Model Class Initialized
INFO - 2018-02-06 07:36:58 --> Controller Class Initialized
INFO - 2018-02-06 07:36:58 --> Model Class Initialized
DEBUG - 2018-02-06 07:36:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:36:58 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:36:58 --> Final output sent to browser
DEBUG - 2018-02-06 07:36:58 --> Total execution time: 0.0430
INFO - 2018-02-06 07:39:12 --> Config Class Initialized
INFO - 2018-02-06 07:39:12 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:39:12 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:39:12 --> Utf8 Class Initialized
INFO - 2018-02-06 07:39:12 --> URI Class Initialized
INFO - 2018-02-06 07:39:12 --> Router Class Initialized
INFO - 2018-02-06 07:39:12 --> Output Class Initialized
INFO - 2018-02-06 07:39:12 --> Security Class Initialized
DEBUG - 2018-02-06 07:39:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:39:12 --> Input Class Initialized
INFO - 2018-02-06 07:39:12 --> Language Class Initialized
INFO - 2018-02-06 07:39:12 --> Loader Class Initialized
INFO - 2018-02-06 07:39:12 --> Helper loaded: url_helper
INFO - 2018-02-06 07:39:12 --> Helper loaded: form_helper
INFO - 2018-02-06 07:39:12 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:39:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:39:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:39:12 --> Form Validation Class Initialized
INFO - 2018-02-06 07:39:12 --> Model Class Initialized
INFO - 2018-02-06 07:39:12 --> Controller Class Initialized
INFO - 2018-02-06 07:39:12 --> Model Class Initialized
DEBUG - 2018-02-06 07:39:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:39:12 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:39:12 --> Final output sent to browser
DEBUG - 2018-02-06 07:39:12 --> Total execution time: 0.0575
INFO - 2018-02-06 07:39:35 --> Config Class Initialized
INFO - 2018-02-06 07:39:35 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:39:35 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:39:35 --> Utf8 Class Initialized
INFO - 2018-02-06 07:39:35 --> URI Class Initialized
INFO - 2018-02-06 07:39:35 --> Router Class Initialized
INFO - 2018-02-06 07:39:35 --> Output Class Initialized
INFO - 2018-02-06 07:39:35 --> Security Class Initialized
DEBUG - 2018-02-06 07:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:39:35 --> Input Class Initialized
INFO - 2018-02-06 07:39:35 --> Language Class Initialized
INFO - 2018-02-06 07:39:35 --> Loader Class Initialized
INFO - 2018-02-06 07:39:35 --> Helper loaded: url_helper
INFO - 2018-02-06 07:39:35 --> Helper loaded: form_helper
INFO - 2018-02-06 07:39:35 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:39:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:39:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:39:35 --> Form Validation Class Initialized
INFO - 2018-02-06 07:39:35 --> Model Class Initialized
INFO - 2018-02-06 07:39:35 --> Controller Class Initialized
INFO - 2018-02-06 07:39:35 --> Model Class Initialized
DEBUG - 2018-02-06 07:39:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:39:35 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:39:35 --> Final output sent to browser
DEBUG - 2018-02-06 07:39:35 --> Total execution time: 0.0582
INFO - 2018-02-06 07:39:37 --> Config Class Initialized
INFO - 2018-02-06 07:39:37 --> Hooks Class Initialized
INFO - 2018-02-06 07:39:37 --> Config Class Initialized
INFO - 2018-02-06 07:39:37 --> Hooks Class Initialized
INFO - 2018-02-06 07:39:37 --> Config Class Initialized
INFO - 2018-02-06 07:39:37 --> Config Class Initialized
INFO - 2018-02-06 07:39:37 --> Hooks Class Initialized
INFO - 2018-02-06 07:39:37 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:39:37 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:39:37 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:39:37 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:39:37 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:39:37 --> Utf8 Class Initialized
INFO - 2018-02-06 07:39:37 --> URI Class Initialized
INFO - 2018-02-06 07:39:37 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:39:37 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:39:37 --> Utf8 Class Initialized
INFO - 2018-02-06 07:39:37 --> URI Class Initialized
INFO - 2018-02-06 07:39:37 --> URI Class Initialized
INFO - 2018-02-06 07:39:37 --> URI Class Initialized
INFO - 2018-02-06 07:39:37 --> Router Class Initialized
INFO - 2018-02-06 07:39:37 --> Router Class Initialized
INFO - 2018-02-06 07:39:37 --> Router Class Initialized
INFO - 2018-02-06 07:39:37 --> Router Class Initialized
INFO - 2018-02-06 07:39:37 --> Output Class Initialized
INFO - 2018-02-06 07:39:37 --> Output Class Initialized
INFO - 2018-02-06 07:39:37 --> Output Class Initialized
INFO - 2018-02-06 07:39:37 --> Output Class Initialized
INFO - 2018-02-06 07:39:37 --> Security Class Initialized
INFO - 2018-02-06 07:39:37 --> Security Class Initialized
INFO - 2018-02-06 07:39:37 --> Security Class Initialized
INFO - 2018-02-06 07:39:37 --> Security Class Initialized
DEBUG - 2018-02-06 07:39:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:39:37 --> Input Class Initialized
DEBUG - 2018-02-06 07:39:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:39:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:39:37 --> Language Class Initialized
INFO - 2018-02-06 07:39:37 --> Input Class Initialized
INFO - 2018-02-06 07:39:37 --> Input Class Initialized
DEBUG - 2018-02-06 07:39:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:39:37 --> Input Class Initialized
INFO - 2018-02-06 07:39:37 --> Language Class Initialized
INFO - 2018-02-06 07:39:37 --> Language Class Initialized
INFO - 2018-02-06 07:39:37 --> Language Class Initialized
ERROR - 2018-02-06 07:39:37 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-06 07:39:37 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-06 07:39:37 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-06 07:39:37 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:39:37 --> Config Class Initialized
INFO - 2018-02-06 07:39:37 --> Hooks Class Initialized
INFO - 2018-02-06 07:39:37 --> Config Class Initialized
INFO - 2018-02-06 07:39:37 --> Config Class Initialized
INFO - 2018-02-06 07:39:37 --> Hooks Class Initialized
INFO - 2018-02-06 07:39:37 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:39:37 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:39:37 --> Utf8 Class Initialized
INFO - 2018-02-06 07:39:37 --> URI Class Initialized
DEBUG - 2018-02-06 07:39:37 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:39:37 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:39:37 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:39:37 --> Utf8 Class Initialized
INFO - 2018-02-06 07:39:37 --> Router Class Initialized
INFO - 2018-02-06 07:39:37 --> URI Class Initialized
INFO - 2018-02-06 07:39:37 --> URI Class Initialized
INFO - 2018-02-06 07:39:37 --> Output Class Initialized
INFO - 2018-02-06 07:39:37 --> Router Class Initialized
INFO - 2018-02-06 07:39:37 --> Router Class Initialized
INFO - 2018-02-06 07:39:37 --> Security Class Initialized
INFO - 2018-02-06 07:39:37 --> Output Class Initialized
DEBUG - 2018-02-06 07:39:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:39:37 --> Input Class Initialized
INFO - 2018-02-06 07:39:37 --> Output Class Initialized
INFO - 2018-02-06 07:39:37 --> Language Class Initialized
INFO - 2018-02-06 07:39:37 --> Security Class Initialized
INFO - 2018-02-06 07:39:37 --> Security Class Initialized
DEBUG - 2018-02-06 07:39:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-06 07:39:37 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-06 07:39:37 --> Input Class Initialized
INFO - 2018-02-06 07:39:37 --> Language Class Initialized
DEBUG - 2018-02-06 07:39:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:39:37 --> Input Class Initialized
ERROR - 2018-02-06 07:39:37 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-06 07:39:37 --> Language Class Initialized
ERROR - 2018-02-06 07:39:37 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-06 07:39:43 --> Config Class Initialized
INFO - 2018-02-06 07:39:43 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:39:43 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:39:43 --> Utf8 Class Initialized
INFO - 2018-02-06 07:39:43 --> URI Class Initialized
INFO - 2018-02-06 07:39:43 --> Router Class Initialized
INFO - 2018-02-06 07:39:43 --> Output Class Initialized
INFO - 2018-02-06 07:39:43 --> Security Class Initialized
DEBUG - 2018-02-06 07:39:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:39:43 --> Input Class Initialized
INFO - 2018-02-06 07:39:43 --> Language Class Initialized
INFO - 2018-02-06 07:39:43 --> Loader Class Initialized
INFO - 2018-02-06 07:39:43 --> Helper loaded: url_helper
INFO - 2018-02-06 07:39:43 --> Helper loaded: form_helper
INFO - 2018-02-06 07:39:43 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:39:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:39:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:39:43 --> Form Validation Class Initialized
INFO - 2018-02-06 07:39:43 --> Model Class Initialized
INFO - 2018-02-06 07:39:43 --> Controller Class Initialized
INFO - 2018-02-06 07:39:43 --> Model Class Initialized
DEBUG - 2018-02-06 07:39:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:39:43 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:39:43 --> Final output sent to browser
DEBUG - 2018-02-06 07:39:43 --> Total execution time: 0.0460
INFO - 2018-02-06 07:39:44 --> Config Class Initialized
INFO - 2018-02-06 07:39:44 --> Hooks Class Initialized
INFO - 2018-02-06 07:39:44 --> Config Class Initialized
INFO - 2018-02-06 07:39:44 --> Hooks Class Initialized
INFO - 2018-02-06 07:39:44 --> Config Class Initialized
INFO - 2018-02-06 07:39:44 --> Hooks Class Initialized
INFO - 2018-02-06 07:39:44 --> Config Class Initialized
INFO - 2018-02-06 07:39:44 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:39:44 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:39:44 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:39:44 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:39:44 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:39:44 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:39:44 --> URI Class Initialized
INFO - 2018-02-06 07:39:44 --> Utf8 Class Initialized
INFO - 2018-02-06 07:39:44 --> URI Class Initialized
DEBUG - 2018-02-06 07:39:44 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:39:44 --> Utf8 Class Initialized
INFO - 2018-02-06 07:39:44 --> URI Class Initialized
INFO - 2018-02-06 07:39:44 --> Router Class Initialized
INFO - 2018-02-06 07:39:44 --> URI Class Initialized
INFO - 2018-02-06 07:39:44 --> Router Class Initialized
INFO - 2018-02-06 07:39:44 --> Router Class Initialized
INFO - 2018-02-06 07:39:44 --> Output Class Initialized
INFO - 2018-02-06 07:39:44 --> Router Class Initialized
INFO - 2018-02-06 07:39:44 --> Output Class Initialized
INFO - 2018-02-06 07:39:44 --> Output Class Initialized
INFO - 2018-02-06 07:39:44 --> Security Class Initialized
INFO - 2018-02-06 07:39:44 --> Output Class Initialized
INFO - 2018-02-06 07:39:44 --> Security Class Initialized
INFO - 2018-02-06 07:39:44 --> Security Class Initialized
DEBUG - 2018-02-06 07:39:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:39:44 --> Input Class Initialized
INFO - 2018-02-06 07:39:44 --> Security Class Initialized
DEBUG - 2018-02-06 07:39:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:39:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:39:44 --> Language Class Initialized
INFO - 2018-02-06 07:39:44 --> Input Class Initialized
INFO - 2018-02-06 07:39:44 --> Input Class Initialized
DEBUG - 2018-02-06 07:39:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:39:44 --> Language Class Initialized
INFO - 2018-02-06 07:39:44 --> Input Class Initialized
INFO - 2018-02-06 07:39:44 --> Language Class Initialized
ERROR - 2018-02-06 07:39:44 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:39:44 --> Language Class Initialized
ERROR - 2018-02-06 07:39:44 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-06 07:39:44 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-06 07:39:44 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:39:44 --> Config Class Initialized
INFO - 2018-02-06 07:39:44 --> Config Class Initialized
INFO - 2018-02-06 07:39:44 --> Config Class Initialized
INFO - 2018-02-06 07:39:44 --> Hooks Class Initialized
INFO - 2018-02-06 07:39:44 --> Hooks Class Initialized
INFO - 2018-02-06 07:39:44 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:39:44 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:39:44 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:39:44 --> Utf8 Class Initialized
INFO - 2018-02-06 07:39:44 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:39:44 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:39:44 --> Utf8 Class Initialized
INFO - 2018-02-06 07:39:44 --> URI Class Initialized
INFO - 2018-02-06 07:39:44 --> URI Class Initialized
INFO - 2018-02-06 07:39:44 --> URI Class Initialized
INFO - 2018-02-06 07:39:44 --> Router Class Initialized
INFO - 2018-02-06 07:39:44 --> Router Class Initialized
INFO - 2018-02-06 07:39:44 --> Router Class Initialized
INFO - 2018-02-06 07:39:44 --> Output Class Initialized
INFO - 2018-02-06 07:39:44 --> Output Class Initialized
INFO - 2018-02-06 07:39:44 --> Output Class Initialized
INFO - 2018-02-06 07:39:44 --> Security Class Initialized
INFO - 2018-02-06 07:39:44 --> Security Class Initialized
INFO - 2018-02-06 07:39:44 --> Security Class Initialized
DEBUG - 2018-02-06 07:39:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:39:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:39:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:39:44 --> Input Class Initialized
INFO - 2018-02-06 07:39:44 --> Input Class Initialized
INFO - 2018-02-06 07:39:44 --> Input Class Initialized
INFO - 2018-02-06 07:39:44 --> Language Class Initialized
INFO - 2018-02-06 07:39:44 --> Language Class Initialized
INFO - 2018-02-06 07:39:44 --> Language Class Initialized
ERROR - 2018-02-06 07:39:44 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-06 07:39:44 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-06 07:39:44 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-06 07:39:50 --> Config Class Initialized
INFO - 2018-02-06 07:39:50 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:39:50 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:39:50 --> Utf8 Class Initialized
INFO - 2018-02-06 07:39:50 --> URI Class Initialized
INFO - 2018-02-06 07:39:50 --> Router Class Initialized
INFO - 2018-02-06 07:39:50 --> Output Class Initialized
INFO - 2018-02-06 07:39:50 --> Security Class Initialized
DEBUG - 2018-02-06 07:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:39:50 --> Input Class Initialized
INFO - 2018-02-06 07:39:50 --> Language Class Initialized
INFO - 2018-02-06 07:39:50 --> Loader Class Initialized
INFO - 2018-02-06 07:39:50 --> Helper loaded: url_helper
INFO - 2018-02-06 07:39:50 --> Helper loaded: form_helper
INFO - 2018-02-06 07:39:50 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:39:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:39:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:39:50 --> Form Validation Class Initialized
INFO - 2018-02-06 07:39:50 --> Model Class Initialized
INFO - 2018-02-06 07:39:50 --> Controller Class Initialized
INFO - 2018-02-06 07:39:50 --> Model Class Initialized
DEBUG - 2018-02-06 07:39:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:39:50 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:39:50 --> Final output sent to browser
DEBUG - 2018-02-06 07:39:50 --> Total execution time: 0.0485
INFO - 2018-02-06 07:39:50 --> Config Class Initialized
INFO - 2018-02-06 07:39:50 --> Hooks Class Initialized
INFO - 2018-02-06 07:39:50 --> Config Class Initialized
INFO - 2018-02-06 07:39:50 --> Config Class Initialized
INFO - 2018-02-06 07:39:50 --> Hooks Class Initialized
INFO - 2018-02-06 07:39:50 --> Config Class Initialized
INFO - 2018-02-06 07:39:50 --> Hooks Class Initialized
INFO - 2018-02-06 07:39:50 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:39:50 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:39:50 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:39:50 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:39:50 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:39:50 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:39:50 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:39:50 --> Utf8 Class Initialized
INFO - 2018-02-06 07:39:50 --> URI Class Initialized
INFO - 2018-02-06 07:39:50 --> Utf8 Class Initialized
INFO - 2018-02-06 07:39:50 --> URI Class Initialized
INFO - 2018-02-06 07:39:50 --> URI Class Initialized
INFO - 2018-02-06 07:39:50 --> URI Class Initialized
INFO - 2018-02-06 07:39:50 --> Router Class Initialized
INFO - 2018-02-06 07:39:50 --> Router Class Initialized
INFO - 2018-02-06 07:39:50 --> Router Class Initialized
INFO - 2018-02-06 07:39:50 --> Router Class Initialized
INFO - 2018-02-06 07:39:50 --> Output Class Initialized
INFO - 2018-02-06 07:39:50 --> Output Class Initialized
INFO - 2018-02-06 07:39:50 --> Output Class Initialized
INFO - 2018-02-06 07:39:50 --> Output Class Initialized
INFO - 2018-02-06 07:39:50 --> Security Class Initialized
INFO - 2018-02-06 07:39:50 --> Security Class Initialized
INFO - 2018-02-06 07:39:50 --> Security Class Initialized
INFO - 2018-02-06 07:39:50 --> Security Class Initialized
DEBUG - 2018-02-06 07:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:39:50 --> Input Class Initialized
DEBUG - 2018-02-06 07:39:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:39:50 --> Input Class Initialized
INFO - 2018-02-06 07:39:50 --> Input Class Initialized
INFO - 2018-02-06 07:39:50 --> Language Class Initialized
DEBUG - 2018-02-06 07:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:39:50 --> Input Class Initialized
INFO - 2018-02-06 07:39:50 --> Language Class Initialized
INFO - 2018-02-06 07:39:50 --> Language Class Initialized
ERROR - 2018-02-06 07:39:50 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:39:50 --> Language Class Initialized
ERROR - 2018-02-06 07:39:50 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-06 07:39:50 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-06 07:39:50 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:39:50 --> Config Class Initialized
INFO - 2018-02-06 07:39:50 --> Hooks Class Initialized
INFO - 2018-02-06 07:39:50 --> Config Class Initialized
INFO - 2018-02-06 07:39:50 --> Hooks Class Initialized
INFO - 2018-02-06 07:39:50 --> Config Class Initialized
INFO - 2018-02-06 07:39:50 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:39:50 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:39:50 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:39:50 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:39:50 --> Utf8 Class Initialized
INFO - 2018-02-06 07:39:50 --> URI Class Initialized
DEBUG - 2018-02-06 07:39:50 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:39:50 --> Utf8 Class Initialized
INFO - 2018-02-06 07:39:50 --> URI Class Initialized
INFO - 2018-02-06 07:39:50 --> URI Class Initialized
INFO - 2018-02-06 07:39:50 --> Router Class Initialized
INFO - 2018-02-06 07:39:50 --> Router Class Initialized
INFO - 2018-02-06 07:39:50 --> Router Class Initialized
INFO - 2018-02-06 07:39:50 --> Output Class Initialized
INFO - 2018-02-06 07:39:50 --> Output Class Initialized
INFO - 2018-02-06 07:39:50 --> Output Class Initialized
INFO - 2018-02-06 07:39:50 --> Security Class Initialized
INFO - 2018-02-06 07:39:50 --> Security Class Initialized
INFO - 2018-02-06 07:39:50 --> Security Class Initialized
DEBUG - 2018-02-06 07:39:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:39:50 --> Input Class Initialized
INFO - 2018-02-06 07:39:50 --> Input Class Initialized
DEBUG - 2018-02-06 07:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:39:50 --> Input Class Initialized
INFO - 2018-02-06 07:39:50 --> Language Class Initialized
INFO - 2018-02-06 07:39:50 --> Language Class Initialized
INFO - 2018-02-06 07:39:50 --> Language Class Initialized
ERROR - 2018-02-06 07:39:50 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-06 07:39:50 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-06 07:39:50 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-06 07:39:50 --> Config Class Initialized
INFO - 2018-02-06 07:39:50 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:39:50 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:39:50 --> Utf8 Class Initialized
INFO - 2018-02-06 07:39:50 --> URI Class Initialized
INFO - 2018-02-06 07:39:50 --> Router Class Initialized
INFO - 2018-02-06 07:39:50 --> Output Class Initialized
INFO - 2018-02-06 07:39:50 --> Security Class Initialized
DEBUG - 2018-02-06 07:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:39:50 --> Input Class Initialized
INFO - 2018-02-06 07:39:50 --> Language Class Initialized
INFO - 2018-02-06 07:39:50 --> Loader Class Initialized
INFO - 2018-02-06 07:39:50 --> Helper loaded: url_helper
INFO - 2018-02-06 07:39:50 --> Helper loaded: form_helper
INFO - 2018-02-06 07:39:50 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:39:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:39:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:39:50 --> Form Validation Class Initialized
INFO - 2018-02-06 07:39:50 --> Model Class Initialized
INFO - 2018-02-06 07:39:50 --> Controller Class Initialized
INFO - 2018-02-06 07:39:50 --> Model Class Initialized
DEBUG - 2018-02-06 07:39:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:39:51 --> Config Class Initialized
INFO - 2018-02-06 07:39:51 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:39:51 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:39:51 --> Utf8 Class Initialized
INFO - 2018-02-06 07:39:51 --> URI Class Initialized
INFO - 2018-02-06 07:39:51 --> Router Class Initialized
INFO - 2018-02-06 07:39:51 --> Output Class Initialized
INFO - 2018-02-06 07:39:51 --> Security Class Initialized
DEBUG - 2018-02-06 07:39:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:39:51 --> Input Class Initialized
INFO - 2018-02-06 07:39:51 --> Language Class Initialized
INFO - 2018-02-06 07:39:51 --> Loader Class Initialized
INFO - 2018-02-06 07:39:51 --> Helper loaded: url_helper
INFO - 2018-02-06 07:39:51 --> Helper loaded: form_helper
INFO - 2018-02-06 07:39:51 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:39:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:39:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:39:51 --> Form Validation Class Initialized
INFO - 2018-02-06 07:39:51 --> Model Class Initialized
INFO - 2018-02-06 07:39:51 --> Controller Class Initialized
INFO - 2018-02-06 07:39:51 --> Model Class Initialized
DEBUG - 2018-02-06 07:39:51 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:39:51 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:39:51 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:39:51 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:39:51 --> Final output sent to browser
DEBUG - 2018-02-06 07:39:51 --> Total execution time: 0.0427
INFO - 2018-02-06 07:39:52 --> Config Class Initialized
INFO - 2018-02-06 07:39:52 --> Config Class Initialized
INFO - 2018-02-06 07:39:52 --> Hooks Class Initialized
INFO - 2018-02-06 07:39:52 --> Hooks Class Initialized
INFO - 2018-02-06 07:39:52 --> Config Class Initialized
INFO - 2018-02-06 07:39:52 --> Config Class Initialized
INFO - 2018-02-06 07:39:52 --> Hooks Class Initialized
INFO - 2018-02-06 07:39:52 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:39:52 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:39:52 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:39:52 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:39:52 --> Utf8 Class Initialized
INFO - 2018-02-06 07:39:52 --> URI Class Initialized
INFO - 2018-02-06 07:39:52 --> URI Class Initialized
DEBUG - 2018-02-06 07:39:52 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:39:52 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:39:52 --> Utf8 Class Initialized
INFO - 2018-02-06 07:39:52 --> Utf8 Class Initialized
INFO - 2018-02-06 07:39:52 --> Router Class Initialized
INFO - 2018-02-06 07:39:52 --> Router Class Initialized
INFO - 2018-02-06 07:39:52 --> URI Class Initialized
INFO - 2018-02-06 07:39:52 --> URI Class Initialized
INFO - 2018-02-06 07:39:52 --> Output Class Initialized
INFO - 2018-02-06 07:39:52 --> Output Class Initialized
INFO - 2018-02-06 07:39:52 --> Router Class Initialized
INFO - 2018-02-06 07:39:52 --> Router Class Initialized
INFO - 2018-02-06 07:39:52 --> Security Class Initialized
INFO - 2018-02-06 07:39:52 --> Security Class Initialized
DEBUG - 2018-02-06 07:39:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:39:52 --> Output Class Initialized
INFO - 2018-02-06 07:39:52 --> Input Class Initialized
INFO - 2018-02-06 07:39:52 --> Output Class Initialized
DEBUG - 2018-02-06 07:39:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:39:52 --> Security Class Initialized
INFO - 2018-02-06 07:39:52 --> Input Class Initialized
INFO - 2018-02-06 07:39:52 --> Language Class Initialized
INFO - 2018-02-06 07:39:52 --> Security Class Initialized
INFO - 2018-02-06 07:39:52 --> Language Class Initialized
DEBUG - 2018-02-06 07:39:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-06 07:39:52 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:39:52 --> Input Class Initialized
DEBUG - 2018-02-06 07:39:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:39:52 --> Input Class Initialized
ERROR - 2018-02-06 07:39:52 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:39:52 --> Language Class Initialized
INFO - 2018-02-06 07:39:52 --> Language Class Initialized
ERROR - 2018-02-06 07:39:52 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-06 07:39:52 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:39:52 --> Config Class Initialized
INFO - 2018-02-06 07:39:52 --> Hooks Class Initialized
INFO - 2018-02-06 07:39:52 --> Config Class Initialized
INFO - 2018-02-06 07:39:52 --> Hooks Class Initialized
INFO - 2018-02-06 07:39:52 --> Config Class Initialized
INFO - 2018-02-06 07:39:52 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:39:52 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:39:52 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:39:52 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:39:52 --> Utf8 Class Initialized
INFO - 2018-02-06 07:39:52 --> URI Class Initialized
DEBUG - 2018-02-06 07:39:52 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:39:52 --> URI Class Initialized
INFO - 2018-02-06 07:39:52 --> Utf8 Class Initialized
INFO - 2018-02-06 07:39:52 --> Router Class Initialized
INFO - 2018-02-06 07:39:52 --> URI Class Initialized
INFO - 2018-02-06 07:39:52 --> Router Class Initialized
INFO - 2018-02-06 07:39:52 --> Output Class Initialized
INFO - 2018-02-06 07:39:52 --> Router Class Initialized
INFO - 2018-02-06 07:39:52 --> Output Class Initialized
INFO - 2018-02-06 07:39:52 --> Security Class Initialized
INFO - 2018-02-06 07:39:52 --> Security Class Initialized
INFO - 2018-02-06 07:39:52 --> Output Class Initialized
DEBUG - 2018-02-06 07:39:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:39:52 --> Input Class Initialized
DEBUG - 2018-02-06 07:39:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:39:52 --> Security Class Initialized
INFO - 2018-02-06 07:39:52 --> Input Class Initialized
INFO - 2018-02-06 07:39:52 --> Language Class Initialized
INFO - 2018-02-06 07:39:52 --> Language Class Initialized
DEBUG - 2018-02-06 07:39:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:39:52 --> Input Class Initialized
ERROR - 2018-02-06 07:39:52 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-06 07:39:52 --> Language Class Initialized
ERROR - 2018-02-06 07:39:52 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-06 07:39:52 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-06 07:39:53 --> Config Class Initialized
INFO - 2018-02-06 07:39:53 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:39:53 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:39:53 --> Utf8 Class Initialized
INFO - 2018-02-06 07:39:53 --> URI Class Initialized
INFO - 2018-02-06 07:39:53 --> Router Class Initialized
INFO - 2018-02-06 07:39:53 --> Output Class Initialized
INFO - 2018-02-06 07:39:53 --> Security Class Initialized
DEBUG - 2018-02-06 07:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:39:53 --> Input Class Initialized
INFO - 2018-02-06 07:39:53 --> Language Class Initialized
INFO - 2018-02-06 07:39:53 --> Loader Class Initialized
INFO - 2018-02-06 07:39:53 --> Helper loaded: url_helper
INFO - 2018-02-06 07:39:53 --> Helper loaded: form_helper
INFO - 2018-02-06 07:39:53 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:39:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:39:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:39:53 --> Form Validation Class Initialized
INFO - 2018-02-06 07:39:53 --> Model Class Initialized
INFO - 2018-02-06 07:39:53 --> Controller Class Initialized
INFO - 2018-02-06 07:39:53 --> Model Class Initialized
DEBUG - 2018-02-06 07:39:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:39:53 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:39:53 --> Final output sent to browser
DEBUG - 2018-02-06 07:39:53 --> Total execution time: 0.0465
INFO - 2018-02-06 07:39:53 --> Config Class Initialized
INFO - 2018-02-06 07:39:53 --> Config Class Initialized
INFO - 2018-02-06 07:39:53 --> Hooks Class Initialized
INFO - 2018-02-06 07:39:53 --> Hooks Class Initialized
INFO - 2018-02-06 07:39:53 --> Config Class Initialized
INFO - 2018-02-06 07:39:53 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:39:53 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:39:53 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:39:53 --> Config Class Initialized
INFO - 2018-02-06 07:39:53 --> Utf8 Class Initialized
INFO - 2018-02-06 07:39:53 --> Utf8 Class Initialized
INFO - 2018-02-06 07:39:53 --> Hooks Class Initialized
INFO - 2018-02-06 07:39:53 --> URI Class Initialized
INFO - 2018-02-06 07:39:53 --> URI Class Initialized
DEBUG - 2018-02-06 07:39:53 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:39:53 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:39:53 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:39:53 --> Router Class Initialized
INFO - 2018-02-06 07:39:53 --> Router Class Initialized
INFO - 2018-02-06 07:39:53 --> Utf8 Class Initialized
INFO - 2018-02-06 07:39:53 --> URI Class Initialized
INFO - 2018-02-06 07:39:53 --> URI Class Initialized
INFO - 2018-02-06 07:39:53 --> Output Class Initialized
INFO - 2018-02-06 07:39:53 --> Output Class Initialized
INFO - 2018-02-06 07:39:53 --> Router Class Initialized
INFO - 2018-02-06 07:39:53 --> Security Class Initialized
INFO - 2018-02-06 07:39:53 --> Security Class Initialized
INFO - 2018-02-06 07:39:53 --> Router Class Initialized
INFO - 2018-02-06 07:39:53 --> Output Class Initialized
DEBUG - 2018-02-06 07:39:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:39:53 --> Input Class Initialized
INFO - 2018-02-06 07:39:53 --> Input Class Initialized
INFO - 2018-02-06 07:39:53 --> Output Class Initialized
INFO - 2018-02-06 07:39:53 --> Security Class Initialized
INFO - 2018-02-06 07:39:53 --> Language Class Initialized
INFO - 2018-02-06 07:39:53 --> Language Class Initialized
INFO - 2018-02-06 07:39:53 --> Security Class Initialized
DEBUG - 2018-02-06 07:39:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-06 07:39:53 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:39:53 --> Input Class Initialized
ERROR - 2018-02-06 07:39:53 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:39:53 --> Language Class Initialized
DEBUG - 2018-02-06 07:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:39:53 --> Input Class Initialized
ERROR - 2018-02-06 07:39:53 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:39:53 --> Language Class Initialized
ERROR - 2018-02-06 07:39:53 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:39:53 --> Config Class Initialized
INFO - 2018-02-06 07:39:53 --> Hooks Class Initialized
INFO - 2018-02-06 07:39:53 --> Config Class Initialized
INFO - 2018-02-06 07:39:53 --> Hooks Class Initialized
INFO - 2018-02-06 07:39:53 --> Config Class Initialized
INFO - 2018-02-06 07:39:53 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:39:53 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:39:53 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:39:53 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:39:53 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:39:53 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:39:53 --> URI Class Initialized
INFO - 2018-02-06 07:39:53 --> Utf8 Class Initialized
INFO - 2018-02-06 07:39:53 --> URI Class Initialized
INFO - 2018-02-06 07:39:53 --> URI Class Initialized
INFO - 2018-02-06 07:39:53 --> Router Class Initialized
INFO - 2018-02-06 07:39:53 --> Router Class Initialized
INFO - 2018-02-06 07:39:53 --> Router Class Initialized
INFO - 2018-02-06 07:39:53 --> Output Class Initialized
INFO - 2018-02-06 07:39:53 --> Output Class Initialized
INFO - 2018-02-06 07:39:53 --> Security Class Initialized
INFO - 2018-02-06 07:39:53 --> Output Class Initialized
INFO - 2018-02-06 07:39:53 --> Security Class Initialized
DEBUG - 2018-02-06 07:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:39:53 --> Security Class Initialized
INFO - 2018-02-06 07:39:53 --> Input Class Initialized
DEBUG - 2018-02-06 07:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:39:53 --> Input Class Initialized
INFO - 2018-02-06 07:39:53 --> Language Class Initialized
DEBUG - 2018-02-06 07:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:39:53 --> Language Class Initialized
INFO - 2018-02-06 07:39:53 --> Input Class Initialized
ERROR - 2018-02-06 07:39:53 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-06 07:39:53 --> Language Class Initialized
ERROR - 2018-02-06 07:39:53 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-06 07:39:53 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-06 07:39:53 --> Config Class Initialized
INFO - 2018-02-06 07:39:53 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:39:53 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:39:53 --> Utf8 Class Initialized
INFO - 2018-02-06 07:39:53 --> URI Class Initialized
INFO - 2018-02-06 07:39:53 --> Router Class Initialized
INFO - 2018-02-06 07:39:53 --> Output Class Initialized
INFO - 2018-02-06 07:39:53 --> Security Class Initialized
DEBUG - 2018-02-06 07:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:39:53 --> Input Class Initialized
INFO - 2018-02-06 07:39:53 --> Language Class Initialized
INFO - 2018-02-06 07:39:53 --> Loader Class Initialized
INFO - 2018-02-06 07:39:53 --> Helper loaded: url_helper
INFO - 2018-02-06 07:39:53 --> Helper loaded: form_helper
INFO - 2018-02-06 07:39:53 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:39:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:39:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:39:53 --> Form Validation Class Initialized
INFO - 2018-02-06 07:39:53 --> Model Class Initialized
INFO - 2018-02-06 07:39:53 --> Controller Class Initialized
INFO - 2018-02-06 07:39:53 --> Model Class Initialized
DEBUG - 2018-02-06 07:39:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:39:55 --> Config Class Initialized
INFO - 2018-02-06 07:39:55 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:39:55 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:39:55 --> Utf8 Class Initialized
INFO - 2018-02-06 07:39:55 --> URI Class Initialized
INFO - 2018-02-06 07:39:55 --> Router Class Initialized
INFO - 2018-02-06 07:39:55 --> Output Class Initialized
INFO - 2018-02-06 07:39:55 --> Security Class Initialized
DEBUG - 2018-02-06 07:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:39:55 --> Input Class Initialized
INFO - 2018-02-06 07:39:55 --> Language Class Initialized
INFO - 2018-02-06 07:39:55 --> Loader Class Initialized
INFO - 2018-02-06 07:39:55 --> Helper loaded: url_helper
INFO - 2018-02-06 07:39:55 --> Helper loaded: form_helper
INFO - 2018-02-06 07:39:55 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:39:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:39:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:39:55 --> Form Validation Class Initialized
INFO - 2018-02-06 07:39:55 --> Model Class Initialized
INFO - 2018-02-06 07:39:55 --> Controller Class Initialized
INFO - 2018-02-06 07:39:55 --> Model Class Initialized
DEBUG - 2018-02-06 07:39:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:39:55 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:39:55 --> Final output sent to browser
DEBUG - 2018-02-06 07:39:55 --> Total execution time: 0.0401
INFO - 2018-02-06 07:39:55 --> Config Class Initialized
INFO - 2018-02-06 07:39:55 --> Config Class Initialized
INFO - 2018-02-06 07:39:55 --> Hooks Class Initialized
INFO - 2018-02-06 07:39:55 --> Hooks Class Initialized
INFO - 2018-02-06 07:39:55 --> Config Class Initialized
INFO - 2018-02-06 07:39:55 --> Config Class Initialized
INFO - 2018-02-06 07:39:55 --> Hooks Class Initialized
INFO - 2018-02-06 07:39:55 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:39:55 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:39:55 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:39:55 --> Utf8 Class Initialized
INFO - 2018-02-06 07:39:55 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:39:55 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:39:55 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:39:55 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:39:55 --> Utf8 Class Initialized
INFO - 2018-02-06 07:39:55 --> URI Class Initialized
INFO - 2018-02-06 07:39:55 --> URI Class Initialized
INFO - 2018-02-06 07:39:55 --> URI Class Initialized
INFO - 2018-02-06 07:39:55 --> URI Class Initialized
INFO - 2018-02-06 07:39:55 --> Router Class Initialized
INFO - 2018-02-06 07:39:55 --> Router Class Initialized
INFO - 2018-02-06 07:39:55 --> Router Class Initialized
INFO - 2018-02-06 07:39:55 --> Router Class Initialized
INFO - 2018-02-06 07:39:55 --> Output Class Initialized
INFO - 2018-02-06 07:39:55 --> Output Class Initialized
INFO - 2018-02-06 07:39:55 --> Output Class Initialized
INFO - 2018-02-06 07:39:55 --> Output Class Initialized
INFO - 2018-02-06 07:39:55 --> Security Class Initialized
INFO - 2018-02-06 07:39:55 --> Security Class Initialized
INFO - 2018-02-06 07:39:55 --> Security Class Initialized
INFO - 2018-02-06 07:39:55 --> Security Class Initialized
DEBUG - 2018-02-06 07:39:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:39:55 --> Input Class Initialized
INFO - 2018-02-06 07:39:55 --> Input Class Initialized
DEBUG - 2018-02-06 07:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:39:55 --> Input Class Initialized
INFO - 2018-02-06 07:39:55 --> Language Class Initialized
DEBUG - 2018-02-06 07:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:39:55 --> Language Class Initialized
INFO - 2018-02-06 07:39:55 --> Input Class Initialized
INFO - 2018-02-06 07:39:55 --> Language Class Initialized
INFO - 2018-02-06 07:39:55 --> Language Class Initialized
ERROR - 2018-02-06 07:39:55 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-06 07:39:55 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-06 07:39:55 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-06 07:39:55 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:39:55 --> Config Class Initialized
INFO - 2018-02-06 07:39:55 --> Hooks Class Initialized
INFO - 2018-02-06 07:39:55 --> Config Class Initialized
INFO - 2018-02-06 07:39:55 --> Config Class Initialized
INFO - 2018-02-06 07:39:55 --> Hooks Class Initialized
INFO - 2018-02-06 07:39:55 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:39:55 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:39:55 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:39:55 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:39:55 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:39:55 --> Utf8 Class Initialized
INFO - 2018-02-06 07:39:55 --> Utf8 Class Initialized
INFO - 2018-02-06 07:39:55 --> URI Class Initialized
INFO - 2018-02-06 07:39:55 --> URI Class Initialized
INFO - 2018-02-06 07:39:55 --> URI Class Initialized
INFO - 2018-02-06 07:39:55 --> Router Class Initialized
INFO - 2018-02-06 07:39:55 --> Router Class Initialized
INFO - 2018-02-06 07:39:55 --> Router Class Initialized
INFO - 2018-02-06 07:39:55 --> Output Class Initialized
INFO - 2018-02-06 07:39:55 --> Output Class Initialized
INFO - 2018-02-06 07:39:55 --> Output Class Initialized
INFO - 2018-02-06 07:39:55 --> Security Class Initialized
INFO - 2018-02-06 07:39:55 --> Security Class Initialized
INFO - 2018-02-06 07:39:55 --> Security Class Initialized
DEBUG - 2018-02-06 07:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:39:55 --> Input Class Initialized
DEBUG - 2018-02-06 07:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:39:55 --> Input Class Initialized
DEBUG - 2018-02-06 07:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:39:55 --> Language Class Initialized
INFO - 2018-02-06 07:39:55 --> Input Class Initialized
INFO - 2018-02-06 07:39:55 --> Language Class Initialized
INFO - 2018-02-06 07:39:55 --> Language Class Initialized
ERROR - 2018-02-06 07:39:55 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-06 07:39:55 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-06 07:39:55 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-06 07:40:20 --> Config Class Initialized
INFO - 2018-02-06 07:40:20 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:40:20 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:20 --> Utf8 Class Initialized
INFO - 2018-02-06 07:40:21 --> URI Class Initialized
INFO - 2018-02-06 07:40:21 --> Router Class Initialized
INFO - 2018-02-06 07:40:21 --> Output Class Initialized
INFO - 2018-02-06 07:40:21 --> Security Class Initialized
DEBUG - 2018-02-06 07:40:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:40:21 --> Input Class Initialized
INFO - 2018-02-06 07:40:21 --> Language Class Initialized
INFO - 2018-02-06 07:40:21 --> Loader Class Initialized
INFO - 2018-02-06 07:40:21 --> Helper loaded: url_helper
INFO - 2018-02-06 07:40:21 --> Helper loaded: form_helper
INFO - 2018-02-06 07:40:21 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:40:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:40:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:40:21 --> Form Validation Class Initialized
INFO - 2018-02-06 07:40:21 --> Model Class Initialized
INFO - 2018-02-06 07:40:21 --> Controller Class Initialized
INFO - 2018-02-06 07:40:21 --> Model Class Initialized
DEBUG - 2018-02-06 07:40:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:40:21 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:40:21 --> Final output sent to browser
DEBUG - 2018-02-06 07:40:21 --> Total execution time: 0.0560
INFO - 2018-02-06 07:40:21 --> Config Class Initialized
INFO - 2018-02-06 07:40:21 --> Config Class Initialized
INFO - 2018-02-06 07:40:21 --> Hooks Class Initialized
INFO - 2018-02-06 07:40:21 --> Hooks Class Initialized
INFO - 2018-02-06 07:40:21 --> Config Class Initialized
INFO - 2018-02-06 07:40:21 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:40:21 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:21 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:40:21 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:21 --> Utf8 Class Initialized
INFO - 2018-02-06 07:40:21 --> URI Class Initialized
DEBUG - 2018-02-06 07:40:21 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:21 --> Utf8 Class Initialized
INFO - 2018-02-06 07:40:21 --> Config Class Initialized
INFO - 2018-02-06 07:40:21 --> URI Class Initialized
INFO - 2018-02-06 07:40:21 --> Hooks Class Initialized
INFO - 2018-02-06 07:40:21 --> URI Class Initialized
INFO - 2018-02-06 07:40:21 --> Router Class Initialized
INFO - 2018-02-06 07:40:21 --> Router Class Initialized
INFO - 2018-02-06 07:40:21 --> Router Class Initialized
DEBUG - 2018-02-06 07:40:21 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:21 --> Utf8 Class Initialized
INFO - 2018-02-06 07:40:21 --> Output Class Initialized
INFO - 2018-02-06 07:40:21 --> Output Class Initialized
INFO - 2018-02-06 07:40:21 --> URI Class Initialized
INFO - 2018-02-06 07:40:21 --> Output Class Initialized
INFO - 2018-02-06 07:40:21 --> Security Class Initialized
INFO - 2018-02-06 07:40:21 --> Security Class Initialized
INFO - 2018-02-06 07:40:21 --> Router Class Initialized
INFO - 2018-02-06 07:40:21 --> Security Class Initialized
DEBUG - 2018-02-06 07:40:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:40:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:40:21 --> Input Class Initialized
INFO - 2018-02-06 07:40:21 --> Input Class Initialized
DEBUG - 2018-02-06 07:40:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:40:21 --> Language Class Initialized
INFO - 2018-02-06 07:40:21 --> Language Class Initialized
INFO - 2018-02-06 07:40:21 --> Output Class Initialized
INFO - 2018-02-06 07:40:21 --> Input Class Initialized
INFO - 2018-02-06 07:40:21 --> Language Class Initialized
ERROR - 2018-02-06 07:40:21 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:40:21 --> Security Class Initialized
ERROR - 2018-02-06 07:40:21 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-06 07:40:21 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-02-06 07:40:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:40:21 --> Input Class Initialized
INFO - 2018-02-06 07:40:21 --> Language Class Initialized
ERROR - 2018-02-06 07:40:21 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:40:21 --> Config Class Initialized
INFO - 2018-02-06 07:40:21 --> Hooks Class Initialized
INFO - 2018-02-06 07:40:21 --> Config Class Initialized
INFO - 2018-02-06 07:40:21 --> Config Class Initialized
INFO - 2018-02-06 07:40:21 --> Hooks Class Initialized
INFO - 2018-02-06 07:40:21 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:40:21 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:21 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:40:21 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:21 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:40:21 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:21 --> URI Class Initialized
INFO - 2018-02-06 07:40:21 --> Utf8 Class Initialized
INFO - 2018-02-06 07:40:21 --> URI Class Initialized
INFO - 2018-02-06 07:40:21 --> URI Class Initialized
INFO - 2018-02-06 07:40:21 --> Router Class Initialized
INFO - 2018-02-06 07:40:21 --> Router Class Initialized
INFO - 2018-02-06 07:40:21 --> Router Class Initialized
INFO - 2018-02-06 07:40:21 --> Output Class Initialized
INFO - 2018-02-06 07:40:21 --> Output Class Initialized
INFO - 2018-02-06 07:40:21 --> Output Class Initialized
INFO - 2018-02-06 07:40:21 --> Security Class Initialized
INFO - 2018-02-06 07:40:21 --> Security Class Initialized
INFO - 2018-02-06 07:40:21 --> Security Class Initialized
DEBUG - 2018-02-06 07:40:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:40:21 --> Input Class Initialized
DEBUG - 2018-02-06 07:40:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:40:21 --> Input Class Initialized
DEBUG - 2018-02-06 07:40:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:40:21 --> Input Class Initialized
INFO - 2018-02-06 07:40:21 --> Language Class Initialized
INFO - 2018-02-06 07:40:21 --> Language Class Initialized
INFO - 2018-02-06 07:40:21 --> Language Class Initialized
ERROR - 2018-02-06 07:40:21 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-06 07:40:21 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-06 07:40:21 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-06 07:40:22 --> Config Class Initialized
INFO - 2018-02-06 07:40:22 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:40:22 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:22 --> Utf8 Class Initialized
INFO - 2018-02-06 07:40:22 --> URI Class Initialized
INFO - 2018-02-06 07:40:22 --> Router Class Initialized
INFO - 2018-02-06 07:40:22 --> Output Class Initialized
INFO - 2018-02-06 07:40:22 --> Security Class Initialized
DEBUG - 2018-02-06 07:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:40:22 --> Input Class Initialized
INFO - 2018-02-06 07:40:22 --> Language Class Initialized
INFO - 2018-02-06 07:40:22 --> Loader Class Initialized
INFO - 2018-02-06 07:40:22 --> Helper loaded: url_helper
INFO - 2018-02-06 07:40:22 --> Helper loaded: form_helper
INFO - 2018-02-06 07:40:22 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:40:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:40:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:40:22 --> Form Validation Class Initialized
INFO - 2018-02-06 07:40:22 --> Model Class Initialized
INFO - 2018-02-06 07:40:22 --> Controller Class Initialized
INFO - 2018-02-06 07:40:22 --> Model Class Initialized
DEBUG - 2018-02-06 07:40:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:40:22 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:40:22 --> Final output sent to browser
DEBUG - 2018-02-06 07:40:22 --> Total execution time: 0.0523
INFO - 2018-02-06 07:40:22 --> Config Class Initialized
INFO - 2018-02-06 07:40:22 --> Hooks Class Initialized
INFO - 2018-02-06 07:40:22 --> Config Class Initialized
INFO - 2018-02-06 07:40:22 --> Hooks Class Initialized
INFO - 2018-02-06 07:40:22 --> Config Class Initialized
INFO - 2018-02-06 07:40:22 --> Hooks Class Initialized
INFO - 2018-02-06 07:40:22 --> Config Class Initialized
INFO - 2018-02-06 07:40:22 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:40:22 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:40:22 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:22 --> Utf8 Class Initialized
INFO - 2018-02-06 07:40:22 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:40:22 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:22 --> Utf8 Class Initialized
INFO - 2018-02-06 07:40:22 --> URI Class Initialized
INFO - 2018-02-06 07:40:22 --> URI Class Initialized
DEBUG - 2018-02-06 07:40:22 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:22 --> Utf8 Class Initialized
INFO - 2018-02-06 07:40:22 --> URI Class Initialized
INFO - 2018-02-06 07:40:22 --> Router Class Initialized
INFO - 2018-02-06 07:40:22 --> URI Class Initialized
INFO - 2018-02-06 07:40:22 --> Router Class Initialized
INFO - 2018-02-06 07:40:22 --> Router Class Initialized
INFO - 2018-02-06 07:40:22 --> Output Class Initialized
INFO - 2018-02-06 07:40:22 --> Router Class Initialized
INFO - 2018-02-06 07:40:22 --> Output Class Initialized
INFO - 2018-02-06 07:40:22 --> Output Class Initialized
INFO - 2018-02-06 07:40:22 --> Security Class Initialized
INFO - 2018-02-06 07:40:22 --> Security Class Initialized
INFO - 2018-02-06 07:40:22 --> Output Class Initialized
INFO - 2018-02-06 07:40:22 --> Security Class Initialized
DEBUG - 2018-02-06 07:40:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:40:22 --> Input Class Initialized
INFO - 2018-02-06 07:40:22 --> Security Class Initialized
INFO - 2018-02-06 07:40:22 --> Input Class Initialized
DEBUG - 2018-02-06 07:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:40:22 --> Input Class Initialized
INFO - 2018-02-06 07:40:22 --> Language Class Initialized
INFO - 2018-02-06 07:40:22 --> Language Class Initialized
DEBUG - 2018-02-06 07:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:40:22 --> Language Class Initialized
INFO - 2018-02-06 07:40:22 --> Input Class Initialized
ERROR - 2018-02-06 07:40:22 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-06 07:40:22 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:40:22 --> Language Class Initialized
ERROR - 2018-02-06 07:40:22 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-06 07:40:22 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:40:22 --> Config Class Initialized
INFO - 2018-02-06 07:40:22 --> Config Class Initialized
INFO - 2018-02-06 07:40:22 --> Hooks Class Initialized
INFO - 2018-02-06 07:40:22 --> Hooks Class Initialized
INFO - 2018-02-06 07:40:22 --> Config Class Initialized
INFO - 2018-02-06 07:40:22 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:40:22 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:40:22 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:40:22 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:22 --> Utf8 Class Initialized
INFO - 2018-02-06 07:40:22 --> Utf8 Class Initialized
INFO - 2018-02-06 07:40:22 --> Utf8 Class Initialized
INFO - 2018-02-06 07:40:22 --> URI Class Initialized
INFO - 2018-02-06 07:40:22 --> URI Class Initialized
INFO - 2018-02-06 07:40:22 --> URI Class Initialized
INFO - 2018-02-06 07:40:22 --> Router Class Initialized
INFO - 2018-02-06 07:40:22 --> Router Class Initialized
INFO - 2018-02-06 07:40:22 --> Router Class Initialized
INFO - 2018-02-06 07:40:22 --> Output Class Initialized
INFO - 2018-02-06 07:40:22 --> Output Class Initialized
INFO - 2018-02-06 07:40:22 --> Output Class Initialized
INFO - 2018-02-06 07:40:22 --> Security Class Initialized
INFO - 2018-02-06 07:40:22 --> Security Class Initialized
INFO - 2018-02-06 07:40:22 --> Security Class Initialized
DEBUG - 2018-02-06 07:40:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:40:22 --> Input Class Initialized
INFO - 2018-02-06 07:40:22 --> Input Class Initialized
DEBUG - 2018-02-06 07:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:40:22 --> Input Class Initialized
INFO - 2018-02-06 07:40:22 --> Language Class Initialized
INFO - 2018-02-06 07:40:22 --> Language Class Initialized
INFO - 2018-02-06 07:40:22 --> Language Class Initialized
ERROR - 2018-02-06 07:40:22 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-06 07:40:22 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-06 07:40:22 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-06 07:40:22 --> Config Class Initialized
INFO - 2018-02-06 07:40:22 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:40:22 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:22 --> Utf8 Class Initialized
INFO - 2018-02-06 07:40:22 --> URI Class Initialized
INFO - 2018-02-06 07:40:22 --> Router Class Initialized
INFO - 2018-02-06 07:40:22 --> Output Class Initialized
INFO - 2018-02-06 07:40:22 --> Security Class Initialized
DEBUG - 2018-02-06 07:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:40:22 --> Input Class Initialized
INFO - 2018-02-06 07:40:22 --> Language Class Initialized
INFO - 2018-02-06 07:40:22 --> Loader Class Initialized
INFO - 2018-02-06 07:40:22 --> Helper loaded: url_helper
INFO - 2018-02-06 07:40:22 --> Helper loaded: form_helper
INFO - 2018-02-06 07:40:22 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:40:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:40:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:40:22 --> Form Validation Class Initialized
INFO - 2018-02-06 07:40:22 --> Model Class Initialized
INFO - 2018-02-06 07:40:22 --> Controller Class Initialized
INFO - 2018-02-06 07:40:22 --> Model Class Initialized
DEBUG - 2018-02-06 07:40:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:40:23 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:40:23 --> Final output sent to browser
DEBUG - 2018-02-06 07:40:23 --> Total execution time: 0.0405
INFO - 2018-02-06 07:40:23 --> Config Class Initialized
INFO - 2018-02-06 07:40:23 --> Hooks Class Initialized
INFO - 2018-02-06 07:40:23 --> Config Class Initialized
INFO - 2018-02-06 07:40:23 --> Hooks Class Initialized
INFO - 2018-02-06 07:40:23 --> Config Class Initialized
INFO - 2018-02-06 07:40:23 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:40:23 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:23 --> Config Class Initialized
INFO - 2018-02-06 07:40:23 --> Utf8 Class Initialized
INFO - 2018-02-06 07:40:23 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:40:23 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:23 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:40:23 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:23 --> URI Class Initialized
INFO - 2018-02-06 07:40:23 --> Utf8 Class Initialized
INFO - 2018-02-06 07:40:23 --> URI Class Initialized
INFO - 2018-02-06 07:40:23 --> URI Class Initialized
DEBUG - 2018-02-06 07:40:23 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:23 --> Utf8 Class Initialized
INFO - 2018-02-06 07:40:23 --> Router Class Initialized
INFO - 2018-02-06 07:40:23 --> Router Class Initialized
INFO - 2018-02-06 07:40:23 --> URI Class Initialized
INFO - 2018-02-06 07:40:23 --> Router Class Initialized
INFO - 2018-02-06 07:40:23 --> Output Class Initialized
INFO - 2018-02-06 07:40:23 --> Output Class Initialized
INFO - 2018-02-06 07:40:23 --> Router Class Initialized
INFO - 2018-02-06 07:40:23 --> Output Class Initialized
INFO - 2018-02-06 07:40:23 --> Security Class Initialized
INFO - 2018-02-06 07:40:23 --> Security Class Initialized
INFO - 2018-02-06 07:40:23 --> Output Class Initialized
INFO - 2018-02-06 07:40:23 --> Security Class Initialized
DEBUG - 2018-02-06 07:40:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:40:23 --> Input Class Initialized
INFO - 2018-02-06 07:40:23 --> Input Class Initialized
INFO - 2018-02-06 07:40:23 --> Security Class Initialized
INFO - 2018-02-06 07:40:23 --> Language Class Initialized
DEBUG - 2018-02-06 07:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:40:23 --> Language Class Initialized
INFO - 2018-02-06 07:40:23 --> Input Class Initialized
DEBUG - 2018-02-06 07:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:40:23 --> Language Class Initialized
ERROR - 2018-02-06 07:40:23 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:40:23 --> Input Class Initialized
ERROR - 2018-02-06 07:40:23 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:40:23 --> Language Class Initialized
ERROR - 2018-02-06 07:40:23 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-06 07:40:23 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:40:23 --> Config Class Initialized
INFO - 2018-02-06 07:40:23 --> Config Class Initialized
INFO - 2018-02-06 07:40:23 --> Hooks Class Initialized
INFO - 2018-02-06 07:40:23 --> Config Class Initialized
INFO - 2018-02-06 07:40:23 --> Hooks Class Initialized
INFO - 2018-02-06 07:40:23 --> Hooks Class Initialized
INFO - 2018-02-06 07:40:23 --> Config Class Initialized
DEBUG - 2018-02-06 07:40:23 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:23 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:40:23 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:23 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:40:23 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:23 --> Utf8 Class Initialized
INFO - 2018-02-06 07:40:23 --> Utf8 Class Initialized
INFO - 2018-02-06 07:40:23 --> URI Class Initialized
INFO - 2018-02-06 07:40:23 --> URI Class Initialized
INFO - 2018-02-06 07:40:23 --> URI Class Initialized
DEBUG - 2018-02-06 07:40:23 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:23 --> Router Class Initialized
INFO - 2018-02-06 07:40:23 --> Router Class Initialized
INFO - 2018-02-06 07:40:23 --> Utf8 Class Initialized
INFO - 2018-02-06 07:40:23 --> Router Class Initialized
INFO - 2018-02-06 07:40:23 --> URI Class Initialized
INFO - 2018-02-06 07:40:23 --> Output Class Initialized
INFO - 2018-02-06 07:40:23 --> Output Class Initialized
INFO - 2018-02-06 07:40:23 --> Output Class Initialized
INFO - 2018-02-06 07:40:23 --> Router Class Initialized
INFO - 2018-02-06 07:40:23 --> Security Class Initialized
INFO - 2018-02-06 07:40:23 --> Security Class Initialized
INFO - 2018-02-06 07:40:23 --> Security Class Initialized
DEBUG - 2018-02-06 07:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:40:23 --> Input Class Initialized
INFO - 2018-02-06 07:40:23 --> Output Class Initialized
DEBUG - 2018-02-06 07:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:40:23 --> Input Class Initialized
DEBUG - 2018-02-06 07:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:40:23 --> Input Class Initialized
INFO - 2018-02-06 07:40:23 --> Language Class Initialized
INFO - 2018-02-06 07:40:23 --> Language Class Initialized
INFO - 2018-02-06 07:40:23 --> Security Class Initialized
INFO - 2018-02-06 07:40:23 --> Language Class Initialized
ERROR - 2018-02-06 07:40:23 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-06 07:40:23 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-02-06 07:40:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-06 07:40:23 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-06 07:40:23 --> Input Class Initialized
INFO - 2018-02-06 07:40:23 --> Language Class Initialized
INFO - 2018-02-06 07:40:23 --> Loader Class Initialized
INFO - 2018-02-06 07:40:23 --> Helper loaded: url_helper
INFO - 2018-02-06 07:40:23 --> Helper loaded: form_helper
INFO - 2018-02-06 07:40:23 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:40:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:40:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:40:23 --> Form Validation Class Initialized
INFO - 2018-02-06 07:40:23 --> Model Class Initialized
INFO - 2018-02-06 07:40:23 --> Controller Class Initialized
INFO - 2018-02-06 07:40:23 --> Model Class Initialized
DEBUG - 2018-02-06 07:40:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:40:23 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:40:23 --> Final output sent to browser
DEBUG - 2018-02-06 07:40:23 --> Total execution time: 0.0492
INFO - 2018-02-06 07:40:23 --> Config Class Initialized
INFO - 2018-02-06 07:40:23 --> Hooks Class Initialized
INFO - 2018-02-06 07:40:23 --> Config Class Initialized
INFO - 2018-02-06 07:40:23 --> Hooks Class Initialized
INFO - 2018-02-06 07:40:23 --> Config Class Initialized
INFO - 2018-02-06 07:40:23 --> Hooks Class Initialized
INFO - 2018-02-06 07:40:23 --> Config Class Initialized
INFO - 2018-02-06 07:40:23 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:40:23 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:23 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:40:23 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:40:23 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:23 --> Utf8 Class Initialized
INFO - 2018-02-06 07:40:23 --> Utf8 Class Initialized
INFO - 2018-02-06 07:40:23 --> URI Class Initialized
DEBUG - 2018-02-06 07:40:23 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:23 --> Utf8 Class Initialized
INFO - 2018-02-06 07:40:23 --> URI Class Initialized
INFO - 2018-02-06 07:40:23 --> URI Class Initialized
INFO - 2018-02-06 07:40:23 --> URI Class Initialized
INFO - 2018-02-06 07:40:23 --> Router Class Initialized
INFO - 2018-02-06 07:40:23 --> Router Class Initialized
INFO - 2018-02-06 07:40:23 --> Router Class Initialized
INFO - 2018-02-06 07:40:23 --> Router Class Initialized
INFO - 2018-02-06 07:40:23 --> Output Class Initialized
INFO - 2018-02-06 07:40:23 --> Output Class Initialized
INFO - 2018-02-06 07:40:23 --> Output Class Initialized
INFO - 2018-02-06 07:40:23 --> Output Class Initialized
INFO - 2018-02-06 07:40:23 --> Security Class Initialized
INFO - 2018-02-06 07:40:23 --> Security Class Initialized
INFO - 2018-02-06 07:40:23 --> Security Class Initialized
INFO - 2018-02-06 07:40:23 --> Security Class Initialized
DEBUG - 2018-02-06 07:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:40:23 --> Input Class Initialized
DEBUG - 2018-02-06 07:40:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:40:23 --> Language Class Initialized
INFO - 2018-02-06 07:40:23 --> Input Class Initialized
INFO - 2018-02-06 07:40:23 --> Input Class Initialized
DEBUG - 2018-02-06 07:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:40:23 --> Input Class Initialized
INFO - 2018-02-06 07:40:23 --> Language Class Initialized
INFO - 2018-02-06 07:40:23 --> Language Class Initialized
ERROR - 2018-02-06 07:40:23 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:40:23 --> Language Class Initialized
ERROR - 2018-02-06 07:40:23 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-06 07:40:23 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-06 07:40:23 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:40:23 --> Config Class Initialized
INFO - 2018-02-06 07:40:23 --> Hooks Class Initialized
INFO - 2018-02-06 07:40:23 --> Config Class Initialized
INFO - 2018-02-06 07:40:23 --> Hooks Class Initialized
INFO - 2018-02-06 07:40:23 --> Config Class Initialized
INFO - 2018-02-06 07:40:23 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:40:23 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:23 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:40:23 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:23 --> Utf8 Class Initialized
INFO - 2018-02-06 07:40:23 --> URI Class Initialized
DEBUG - 2018-02-06 07:40:23 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:23 --> Utf8 Class Initialized
INFO - 2018-02-06 07:40:23 --> URI Class Initialized
INFO - 2018-02-06 07:40:23 --> Router Class Initialized
INFO - 2018-02-06 07:40:23 --> URI Class Initialized
INFO - 2018-02-06 07:40:23 --> Router Class Initialized
INFO - 2018-02-06 07:40:23 --> Output Class Initialized
INFO - 2018-02-06 07:40:23 --> Router Class Initialized
INFO - 2018-02-06 07:40:23 --> Output Class Initialized
INFO - 2018-02-06 07:40:23 --> Security Class Initialized
INFO - 2018-02-06 07:40:23 --> Output Class Initialized
INFO - 2018-02-06 07:40:23 --> Security Class Initialized
DEBUG - 2018-02-06 07:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:40:23 --> Input Class Initialized
INFO - 2018-02-06 07:40:23 --> Language Class Initialized
INFO - 2018-02-06 07:40:23 --> Security Class Initialized
DEBUG - 2018-02-06 07:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:40:23 --> Input Class Initialized
ERROR - 2018-02-06 07:40:23 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-06 07:40:23 --> Language Class Initialized
DEBUG - 2018-02-06 07:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:40:23 --> Input Class Initialized
INFO - 2018-02-06 07:40:23 --> Language Class Initialized
ERROR - 2018-02-06 07:40:23 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-06 07:40:23 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-06 07:40:23 --> Config Class Initialized
INFO - 2018-02-06 07:40:23 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:40:23 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:23 --> Utf8 Class Initialized
INFO - 2018-02-06 07:40:23 --> URI Class Initialized
INFO - 2018-02-06 07:40:23 --> Router Class Initialized
INFO - 2018-02-06 07:40:23 --> Output Class Initialized
INFO - 2018-02-06 07:40:23 --> Security Class Initialized
DEBUG - 2018-02-06 07:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:40:23 --> Input Class Initialized
INFO - 2018-02-06 07:40:23 --> Language Class Initialized
INFO - 2018-02-06 07:40:23 --> Loader Class Initialized
INFO - 2018-02-06 07:40:23 --> Helper loaded: url_helper
INFO - 2018-02-06 07:40:23 --> Helper loaded: form_helper
INFO - 2018-02-06 07:40:23 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:40:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:40:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:40:23 --> Form Validation Class Initialized
INFO - 2018-02-06 07:40:23 --> Model Class Initialized
INFO - 2018-02-06 07:40:23 --> Controller Class Initialized
INFO - 2018-02-06 07:40:23 --> Model Class Initialized
DEBUG - 2018-02-06 07:40:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:40:23 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:40:23 --> Final output sent to browser
DEBUG - 2018-02-06 07:40:23 --> Total execution time: 0.0397
INFO - 2018-02-06 07:40:23 --> Config Class Initialized
INFO - 2018-02-06 07:40:23 --> Config Class Initialized
INFO - 2018-02-06 07:40:23 --> Hooks Class Initialized
INFO - 2018-02-06 07:40:23 --> Hooks Class Initialized
INFO - 2018-02-06 07:40:23 --> Config Class Initialized
INFO - 2018-02-06 07:40:23 --> Hooks Class Initialized
INFO - 2018-02-06 07:40:23 --> Config Class Initialized
INFO - 2018-02-06 07:40:23 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:40:23 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:40:23 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:23 --> Utf8 Class Initialized
INFO - 2018-02-06 07:40:23 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:40:23 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:23 --> Utf8 Class Initialized
INFO - 2018-02-06 07:40:23 --> URI Class Initialized
INFO - 2018-02-06 07:40:23 --> URI Class Initialized
DEBUG - 2018-02-06 07:40:23 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:23 --> URI Class Initialized
INFO - 2018-02-06 07:40:23 --> Utf8 Class Initialized
INFO - 2018-02-06 07:40:23 --> Router Class Initialized
INFO - 2018-02-06 07:40:23 --> Router Class Initialized
INFO - 2018-02-06 07:40:23 --> URI Class Initialized
INFO - 2018-02-06 07:40:23 --> Router Class Initialized
INFO - 2018-02-06 07:40:23 --> Output Class Initialized
INFO - 2018-02-06 07:40:23 --> Output Class Initialized
INFO - 2018-02-06 07:40:23 --> Router Class Initialized
INFO - 2018-02-06 07:40:23 --> Output Class Initialized
INFO - 2018-02-06 07:40:23 --> Security Class Initialized
INFO - 2018-02-06 07:40:23 --> Security Class Initialized
INFO - 2018-02-06 07:40:23 --> Security Class Initialized
INFO - 2018-02-06 07:40:23 --> Output Class Initialized
DEBUG - 2018-02-06 07:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:40:23 --> Input Class Initialized
DEBUG - 2018-02-06 07:40:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:40:23 --> Security Class Initialized
INFO - 2018-02-06 07:40:23 --> Input Class Initialized
INFO - 2018-02-06 07:40:23 --> Input Class Initialized
INFO - 2018-02-06 07:40:23 --> Language Class Initialized
INFO - 2018-02-06 07:40:23 --> Language Class Initialized
INFO - 2018-02-06 07:40:23 --> Language Class Initialized
DEBUG - 2018-02-06 07:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:40:23 --> Input Class Initialized
ERROR - 2018-02-06 07:40:23 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-06 07:40:23 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:40:23 --> Language Class Initialized
ERROR - 2018-02-06 07:40:23 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-06 07:40:23 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:40:23 --> Config Class Initialized
INFO - 2018-02-06 07:40:23 --> Config Class Initialized
INFO - 2018-02-06 07:40:23 --> Hooks Class Initialized
INFO - 2018-02-06 07:40:23 --> Hooks Class Initialized
INFO - 2018-02-06 07:40:23 --> Config Class Initialized
INFO - 2018-02-06 07:40:23 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:40:23 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:40:23 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:40:23 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:23 --> Utf8 Class Initialized
INFO - 2018-02-06 07:40:23 --> Utf8 Class Initialized
INFO - 2018-02-06 07:40:23 --> Utf8 Class Initialized
INFO - 2018-02-06 07:40:23 --> URI Class Initialized
INFO - 2018-02-06 07:40:23 --> URI Class Initialized
INFO - 2018-02-06 07:40:23 --> URI Class Initialized
INFO - 2018-02-06 07:40:23 --> Router Class Initialized
INFO - 2018-02-06 07:40:23 --> Router Class Initialized
INFO - 2018-02-06 07:40:23 --> Router Class Initialized
INFO - 2018-02-06 07:40:23 --> Output Class Initialized
INFO - 2018-02-06 07:40:23 --> Output Class Initialized
INFO - 2018-02-06 07:40:23 --> Output Class Initialized
INFO - 2018-02-06 07:40:23 --> Security Class Initialized
INFO - 2018-02-06 07:40:23 --> Security Class Initialized
INFO - 2018-02-06 07:40:23 --> Security Class Initialized
DEBUG - 2018-02-06 07:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:40:23 --> Input Class Initialized
DEBUG - 2018-02-06 07:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:40:23 --> Input Class Initialized
DEBUG - 2018-02-06 07:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:40:23 --> Input Class Initialized
INFO - 2018-02-06 07:40:23 --> Language Class Initialized
INFO - 2018-02-06 07:40:23 --> Language Class Initialized
INFO - 2018-02-06 07:40:23 --> Language Class Initialized
ERROR - 2018-02-06 07:40:23 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-06 07:40:23 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-06 07:40:23 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-06 07:40:23 --> Config Class Initialized
INFO - 2018-02-06 07:40:23 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:40:23 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:23 --> Utf8 Class Initialized
INFO - 2018-02-06 07:40:23 --> URI Class Initialized
INFO - 2018-02-06 07:40:23 --> Router Class Initialized
INFO - 2018-02-06 07:40:23 --> Output Class Initialized
INFO - 2018-02-06 07:40:23 --> Security Class Initialized
DEBUG - 2018-02-06 07:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:40:23 --> Input Class Initialized
INFO - 2018-02-06 07:40:23 --> Language Class Initialized
INFO - 2018-02-06 07:40:23 --> Loader Class Initialized
INFO - 2018-02-06 07:40:23 --> Helper loaded: url_helper
INFO - 2018-02-06 07:40:23 --> Helper loaded: form_helper
INFO - 2018-02-06 07:40:23 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:40:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:40:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:40:23 --> Form Validation Class Initialized
INFO - 2018-02-06 07:40:23 --> Model Class Initialized
INFO - 2018-02-06 07:40:23 --> Controller Class Initialized
INFO - 2018-02-06 07:40:23 --> Model Class Initialized
DEBUG - 2018-02-06 07:40:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:40:23 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:40:23 --> Final output sent to browser
DEBUG - 2018-02-06 07:40:23 --> Total execution time: 0.0521
INFO - 2018-02-06 07:40:24 --> Config Class Initialized
INFO - 2018-02-06 07:40:24 --> Hooks Class Initialized
INFO - 2018-02-06 07:40:24 --> Config Class Initialized
INFO - 2018-02-06 07:40:24 --> Hooks Class Initialized
INFO - 2018-02-06 07:40:24 --> Config Class Initialized
INFO - 2018-02-06 07:40:24 --> Hooks Class Initialized
INFO - 2018-02-06 07:40:24 --> Config Class Initialized
INFO - 2018-02-06 07:40:24 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:40:24 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:24 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:40:24 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:40:24 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:24 --> URI Class Initialized
INFO - 2018-02-06 07:40:24 --> Utf8 Class Initialized
INFO - 2018-02-06 07:40:24 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:40:24 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:24 --> Utf8 Class Initialized
INFO - 2018-02-06 07:40:24 --> URI Class Initialized
INFO - 2018-02-06 07:40:24 --> URI Class Initialized
INFO - 2018-02-06 07:40:24 --> Router Class Initialized
INFO - 2018-02-06 07:40:24 --> URI Class Initialized
INFO - 2018-02-06 07:40:24 --> Router Class Initialized
INFO - 2018-02-06 07:40:24 --> Router Class Initialized
INFO - 2018-02-06 07:40:24 --> Output Class Initialized
INFO - 2018-02-06 07:40:24 --> Router Class Initialized
INFO - 2018-02-06 07:40:24 --> Output Class Initialized
INFO - 2018-02-06 07:40:24 --> Output Class Initialized
INFO - 2018-02-06 07:40:24 --> Security Class Initialized
INFO - 2018-02-06 07:40:24 --> Security Class Initialized
INFO - 2018-02-06 07:40:24 --> Security Class Initialized
INFO - 2018-02-06 07:40:24 --> Output Class Initialized
DEBUG - 2018-02-06 07:40:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:40:24 --> Input Class Initialized
DEBUG - 2018-02-06 07:40:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:40:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:40:24 --> Language Class Initialized
INFO - 2018-02-06 07:40:24 --> Input Class Initialized
INFO - 2018-02-06 07:40:24 --> Security Class Initialized
INFO - 2018-02-06 07:40:24 --> Input Class Initialized
INFO - 2018-02-06 07:40:24 --> Language Class Initialized
INFO - 2018-02-06 07:40:24 --> Language Class Initialized
ERROR - 2018-02-06 07:40:24 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-02-06 07:40:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:40:24 --> Input Class Initialized
ERROR - 2018-02-06 07:40:24 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-06 07:40:24 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:40:24 --> Language Class Initialized
ERROR - 2018-02-06 07:40:24 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:40:24 --> Config Class Initialized
INFO - 2018-02-06 07:40:24 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:40:24 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:24 --> Utf8 Class Initialized
INFO - 2018-02-06 07:40:24 --> Config Class Initialized
INFO - 2018-02-06 07:40:24 --> Config Class Initialized
INFO - 2018-02-06 07:40:24 --> Hooks Class Initialized
INFO - 2018-02-06 07:40:24 --> Hooks Class Initialized
INFO - 2018-02-06 07:40:24 --> URI Class Initialized
INFO - 2018-02-06 07:40:24 --> Router Class Initialized
DEBUG - 2018-02-06 07:40:24 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:40:24 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:24 --> Utf8 Class Initialized
INFO - 2018-02-06 07:40:24 --> Utf8 Class Initialized
INFO - 2018-02-06 07:40:24 --> Output Class Initialized
INFO - 2018-02-06 07:40:24 --> URI Class Initialized
INFO - 2018-02-06 07:40:24 --> URI Class Initialized
INFO - 2018-02-06 07:40:24 --> Security Class Initialized
INFO - 2018-02-06 07:40:24 --> Router Class Initialized
INFO - 2018-02-06 07:40:24 --> Router Class Initialized
DEBUG - 2018-02-06 07:40:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:40:24 --> Input Class Initialized
INFO - 2018-02-06 07:40:24 --> Output Class Initialized
INFO - 2018-02-06 07:40:24 --> Output Class Initialized
INFO - 2018-02-06 07:40:24 --> Language Class Initialized
INFO - 2018-02-06 07:40:24 --> Security Class Initialized
INFO - 2018-02-06 07:40:24 --> Security Class Initialized
ERROR - 2018-02-06 07:40:24 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-02-06 07:40:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:40:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:40:24 --> Input Class Initialized
INFO - 2018-02-06 07:40:24 --> Input Class Initialized
INFO - 2018-02-06 07:40:24 --> Language Class Initialized
INFO - 2018-02-06 07:40:24 --> Language Class Initialized
ERROR - 2018-02-06 07:40:24 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-06 07:40:24 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-06 07:40:24 --> Config Class Initialized
INFO - 2018-02-06 07:40:24 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:40:24 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:24 --> Utf8 Class Initialized
INFO - 2018-02-06 07:40:24 --> URI Class Initialized
INFO - 2018-02-06 07:40:24 --> Router Class Initialized
INFO - 2018-02-06 07:40:24 --> Output Class Initialized
INFO - 2018-02-06 07:40:24 --> Security Class Initialized
DEBUG - 2018-02-06 07:40:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:40:24 --> Input Class Initialized
INFO - 2018-02-06 07:40:24 --> Language Class Initialized
INFO - 2018-02-06 07:40:24 --> Loader Class Initialized
INFO - 2018-02-06 07:40:24 --> Helper loaded: url_helper
INFO - 2018-02-06 07:40:24 --> Helper loaded: form_helper
INFO - 2018-02-06 07:40:24 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:40:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:40:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:40:24 --> Form Validation Class Initialized
INFO - 2018-02-06 07:40:24 --> Model Class Initialized
INFO - 2018-02-06 07:40:24 --> Controller Class Initialized
INFO - 2018-02-06 07:40:24 --> Model Class Initialized
DEBUG - 2018-02-06 07:40:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:40:24 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:40:24 --> Final output sent to browser
DEBUG - 2018-02-06 07:40:24 --> Total execution time: 0.0421
INFO - 2018-02-06 07:40:24 --> Config Class Initialized
INFO - 2018-02-06 07:40:24 --> Hooks Class Initialized
INFO - 2018-02-06 07:40:24 --> Config Class Initialized
INFO - 2018-02-06 07:40:24 --> Config Class Initialized
INFO - 2018-02-06 07:40:24 --> Hooks Class Initialized
INFO - 2018-02-06 07:40:24 --> Hooks Class Initialized
INFO - 2018-02-06 07:40:24 --> Config Class Initialized
INFO - 2018-02-06 07:40:24 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:40:24 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:24 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:40:24 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:24 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:40:24 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:24 --> Utf8 Class Initialized
INFO - 2018-02-06 07:40:24 --> URI Class Initialized
DEBUG - 2018-02-06 07:40:24 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:24 --> URI Class Initialized
INFO - 2018-02-06 07:40:24 --> Utf8 Class Initialized
INFO - 2018-02-06 07:40:24 --> URI Class Initialized
INFO - 2018-02-06 07:40:24 --> URI Class Initialized
INFO - 2018-02-06 07:40:24 --> Router Class Initialized
INFO - 2018-02-06 07:40:24 --> Router Class Initialized
INFO - 2018-02-06 07:40:24 --> Router Class Initialized
INFO - 2018-02-06 07:40:24 --> Router Class Initialized
INFO - 2018-02-06 07:40:24 --> Output Class Initialized
INFO - 2018-02-06 07:40:24 --> Output Class Initialized
INFO - 2018-02-06 07:40:24 --> Output Class Initialized
INFO - 2018-02-06 07:40:24 --> Output Class Initialized
INFO - 2018-02-06 07:40:24 --> Security Class Initialized
INFO - 2018-02-06 07:40:24 --> Security Class Initialized
INFO - 2018-02-06 07:40:24 --> Security Class Initialized
INFO - 2018-02-06 07:40:24 --> Security Class Initialized
DEBUG - 2018-02-06 07:40:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:40:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:40:24 --> Input Class Initialized
INFO - 2018-02-06 07:40:24 --> Input Class Initialized
DEBUG - 2018-02-06 07:40:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:40:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:40:24 --> Input Class Initialized
INFO - 2018-02-06 07:40:24 --> Language Class Initialized
INFO - 2018-02-06 07:40:24 --> Input Class Initialized
INFO - 2018-02-06 07:40:24 --> Language Class Initialized
INFO - 2018-02-06 07:40:24 --> Language Class Initialized
INFO - 2018-02-06 07:40:24 --> Language Class Initialized
ERROR - 2018-02-06 07:40:24 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-06 07:40:24 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-06 07:40:24 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-06 07:40:24 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:40:24 --> Config Class Initialized
INFO - 2018-02-06 07:40:24 --> Hooks Class Initialized
INFO - 2018-02-06 07:40:24 --> Config Class Initialized
INFO - 2018-02-06 07:40:24 --> Config Class Initialized
INFO - 2018-02-06 07:40:24 --> Hooks Class Initialized
INFO - 2018-02-06 07:40:24 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:40:24 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:24 --> Utf8 Class Initialized
INFO - 2018-02-06 07:40:24 --> URI Class Initialized
DEBUG - 2018-02-06 07:40:24 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:40:24 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:24 --> Utf8 Class Initialized
INFO - 2018-02-06 07:40:24 --> Utf8 Class Initialized
INFO - 2018-02-06 07:40:24 --> URI Class Initialized
INFO - 2018-02-06 07:40:24 --> Router Class Initialized
INFO - 2018-02-06 07:40:24 --> URI Class Initialized
INFO - 2018-02-06 07:40:24 --> Router Class Initialized
INFO - 2018-02-06 07:40:24 --> Output Class Initialized
INFO - 2018-02-06 07:40:24 --> Router Class Initialized
INFO - 2018-02-06 07:40:24 --> Security Class Initialized
INFO - 2018-02-06 07:40:24 --> Output Class Initialized
INFO - 2018-02-06 07:40:24 --> Output Class Initialized
DEBUG - 2018-02-06 07:40:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:40:24 --> Input Class Initialized
INFO - 2018-02-06 07:40:24 --> Security Class Initialized
INFO - 2018-02-06 07:40:24 --> Security Class Initialized
INFO - 2018-02-06 07:40:24 --> Language Class Initialized
DEBUG - 2018-02-06 07:40:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:40:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:40:24 --> Input Class Initialized
ERROR - 2018-02-06 07:40:24 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-06 07:40:24 --> Input Class Initialized
INFO - 2018-02-06 07:40:24 --> Language Class Initialized
INFO - 2018-02-06 07:40:24 --> Language Class Initialized
ERROR - 2018-02-06 07:40:24 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-06 07:40:24 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-06 07:40:24 --> Config Class Initialized
INFO - 2018-02-06 07:40:24 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:40:24 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:24 --> Utf8 Class Initialized
INFO - 2018-02-06 07:40:24 --> URI Class Initialized
INFO - 2018-02-06 07:40:24 --> Router Class Initialized
INFO - 2018-02-06 07:40:24 --> Output Class Initialized
INFO - 2018-02-06 07:40:24 --> Security Class Initialized
DEBUG - 2018-02-06 07:40:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:40:24 --> Input Class Initialized
INFO - 2018-02-06 07:40:24 --> Language Class Initialized
INFO - 2018-02-06 07:40:24 --> Loader Class Initialized
INFO - 2018-02-06 07:40:24 --> Helper loaded: url_helper
INFO - 2018-02-06 07:40:24 --> Helper loaded: form_helper
INFO - 2018-02-06 07:40:24 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:40:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:40:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:40:24 --> Form Validation Class Initialized
INFO - 2018-02-06 07:40:24 --> Model Class Initialized
INFO - 2018-02-06 07:40:24 --> Controller Class Initialized
INFO - 2018-02-06 07:40:24 --> Model Class Initialized
DEBUG - 2018-02-06 07:40:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:40:24 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:40:24 --> Final output sent to browser
DEBUG - 2018-02-06 07:40:24 --> Total execution time: 0.0419
INFO - 2018-02-06 07:40:24 --> Config Class Initialized
INFO - 2018-02-06 07:40:24 --> Config Class Initialized
INFO - 2018-02-06 07:40:24 --> Config Class Initialized
INFO - 2018-02-06 07:40:24 --> Config Class Initialized
INFO - 2018-02-06 07:40:24 --> Hooks Class Initialized
INFO - 2018-02-06 07:40:24 --> Hooks Class Initialized
INFO - 2018-02-06 07:40:24 --> Hooks Class Initialized
INFO - 2018-02-06 07:40:24 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:40:24 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:40:24 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:40:24 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:40:24 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:24 --> Utf8 Class Initialized
INFO - 2018-02-06 07:40:24 --> Utf8 Class Initialized
INFO - 2018-02-06 07:40:24 --> Utf8 Class Initialized
INFO - 2018-02-06 07:40:24 --> Utf8 Class Initialized
INFO - 2018-02-06 07:40:24 --> URI Class Initialized
INFO - 2018-02-06 07:40:24 --> URI Class Initialized
INFO - 2018-02-06 07:40:24 --> URI Class Initialized
INFO - 2018-02-06 07:40:24 --> URI Class Initialized
INFO - 2018-02-06 07:40:24 --> Router Class Initialized
INFO - 2018-02-06 07:40:24 --> Router Class Initialized
INFO - 2018-02-06 07:40:24 --> Router Class Initialized
INFO - 2018-02-06 07:40:24 --> Router Class Initialized
INFO - 2018-02-06 07:40:24 --> Output Class Initialized
INFO - 2018-02-06 07:40:24 --> Output Class Initialized
INFO - 2018-02-06 07:40:24 --> Output Class Initialized
INFO - 2018-02-06 07:40:24 --> Output Class Initialized
INFO - 2018-02-06 07:40:24 --> Security Class Initialized
INFO - 2018-02-06 07:40:24 --> Security Class Initialized
INFO - 2018-02-06 07:40:24 --> Security Class Initialized
INFO - 2018-02-06 07:40:24 --> Security Class Initialized
DEBUG - 2018-02-06 07:40:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:40:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:40:24 --> Input Class Initialized
INFO - 2018-02-06 07:40:24 --> Input Class Initialized
DEBUG - 2018-02-06 07:40:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:40:24 --> Language Class Initialized
INFO - 2018-02-06 07:40:24 --> Language Class Initialized
DEBUG - 2018-02-06 07:40:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:40:24 --> Input Class Initialized
INFO - 2018-02-06 07:40:24 --> Input Class Initialized
INFO - 2018-02-06 07:40:24 --> Language Class Initialized
ERROR - 2018-02-06 07:40:24 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:40:24 --> Language Class Initialized
ERROR - 2018-02-06 07:40:24 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-06 07:40:24 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-06 07:40:24 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:40:24 --> Config Class Initialized
INFO - 2018-02-06 07:40:24 --> Config Class Initialized
INFO - 2018-02-06 07:40:24 --> Hooks Class Initialized
INFO - 2018-02-06 07:40:24 --> Hooks Class Initialized
INFO - 2018-02-06 07:40:24 --> Config Class Initialized
INFO - 2018-02-06 07:40:24 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:40:24 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:24 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:40:24 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:40:24 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:24 --> Utf8 Class Initialized
INFO - 2018-02-06 07:40:24 --> Utf8 Class Initialized
INFO - 2018-02-06 07:40:24 --> URI Class Initialized
INFO - 2018-02-06 07:40:24 --> URI Class Initialized
INFO - 2018-02-06 07:40:24 --> URI Class Initialized
INFO - 2018-02-06 07:40:24 --> Router Class Initialized
INFO - 2018-02-06 07:40:24 --> Router Class Initialized
INFO - 2018-02-06 07:40:24 --> Router Class Initialized
INFO - 2018-02-06 07:40:24 --> Output Class Initialized
INFO - 2018-02-06 07:40:24 --> Output Class Initialized
INFO - 2018-02-06 07:40:24 --> Output Class Initialized
INFO - 2018-02-06 07:40:24 --> Security Class Initialized
INFO - 2018-02-06 07:40:24 --> Security Class Initialized
INFO - 2018-02-06 07:40:24 --> Security Class Initialized
DEBUG - 2018-02-06 07:40:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:40:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:40:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:40:24 --> Input Class Initialized
INFO - 2018-02-06 07:40:24 --> Input Class Initialized
INFO - 2018-02-06 07:40:24 --> Input Class Initialized
INFO - 2018-02-06 07:40:24 --> Language Class Initialized
INFO - 2018-02-06 07:40:24 --> Language Class Initialized
INFO - 2018-02-06 07:40:24 --> Language Class Initialized
ERROR - 2018-02-06 07:40:24 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-06 07:40:24 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-06 07:40:24 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-06 07:40:25 --> Config Class Initialized
INFO - 2018-02-06 07:40:25 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:40:25 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:25 --> Utf8 Class Initialized
INFO - 2018-02-06 07:40:25 --> URI Class Initialized
INFO - 2018-02-06 07:40:25 --> Router Class Initialized
INFO - 2018-02-06 07:40:25 --> Output Class Initialized
INFO - 2018-02-06 07:40:25 --> Security Class Initialized
DEBUG - 2018-02-06 07:40:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:40:25 --> Input Class Initialized
INFO - 2018-02-06 07:40:25 --> Language Class Initialized
INFO - 2018-02-06 07:40:25 --> Loader Class Initialized
INFO - 2018-02-06 07:40:25 --> Helper loaded: url_helper
INFO - 2018-02-06 07:40:25 --> Helper loaded: form_helper
INFO - 2018-02-06 07:40:25 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:40:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:40:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:40:25 --> Form Validation Class Initialized
INFO - 2018-02-06 07:40:25 --> Model Class Initialized
INFO - 2018-02-06 07:40:25 --> Controller Class Initialized
INFO - 2018-02-06 07:40:25 --> Model Class Initialized
DEBUG - 2018-02-06 07:40:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:40:25 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:40:25 --> Final output sent to browser
DEBUG - 2018-02-06 07:40:25 --> Total execution time: 0.0521
INFO - 2018-02-06 07:40:25 --> Config Class Initialized
INFO - 2018-02-06 07:40:25 --> Config Class Initialized
INFO - 2018-02-06 07:40:25 --> Hooks Class Initialized
INFO - 2018-02-06 07:40:25 --> Hooks Class Initialized
INFO - 2018-02-06 07:40:25 --> Config Class Initialized
INFO - 2018-02-06 07:40:25 --> Hooks Class Initialized
INFO - 2018-02-06 07:40:25 --> Config Class Initialized
INFO - 2018-02-06 07:40:25 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:40:25 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:40:25 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:25 --> Utf8 Class Initialized
INFO - 2018-02-06 07:40:25 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:40:25 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:25 --> Utf8 Class Initialized
INFO - 2018-02-06 07:40:25 --> URI Class Initialized
INFO - 2018-02-06 07:40:25 --> URI Class Initialized
DEBUG - 2018-02-06 07:40:25 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:25 --> URI Class Initialized
INFO - 2018-02-06 07:40:25 --> Utf8 Class Initialized
INFO - 2018-02-06 07:40:25 --> URI Class Initialized
INFO - 2018-02-06 07:40:25 --> Router Class Initialized
INFO - 2018-02-06 07:40:25 --> Router Class Initialized
INFO - 2018-02-06 07:40:25 --> Router Class Initialized
INFO - 2018-02-06 07:40:25 --> Router Class Initialized
INFO - 2018-02-06 07:40:25 --> Output Class Initialized
INFO - 2018-02-06 07:40:25 --> Output Class Initialized
INFO - 2018-02-06 07:40:25 --> Output Class Initialized
INFO - 2018-02-06 07:40:25 --> Output Class Initialized
INFO - 2018-02-06 07:40:25 --> Security Class Initialized
INFO - 2018-02-06 07:40:25 --> Security Class Initialized
INFO - 2018-02-06 07:40:25 --> Security Class Initialized
INFO - 2018-02-06 07:40:25 --> Security Class Initialized
DEBUG - 2018-02-06 07:40:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:40:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:40:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:40:25 --> Input Class Initialized
INFO - 2018-02-06 07:40:25 --> Input Class Initialized
INFO - 2018-02-06 07:40:25 --> Input Class Initialized
DEBUG - 2018-02-06 07:40:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:40:25 --> Language Class Initialized
INFO - 2018-02-06 07:40:25 --> Language Class Initialized
INFO - 2018-02-06 07:40:25 --> Input Class Initialized
INFO - 2018-02-06 07:40:25 --> Language Class Initialized
INFO - 2018-02-06 07:40:25 --> Language Class Initialized
ERROR - 2018-02-06 07:40:25 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-06 07:40:25 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-06 07:40:25 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-06 07:40:25 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:40:25 --> Config Class Initialized
INFO - 2018-02-06 07:40:25 --> Hooks Class Initialized
INFO - 2018-02-06 07:40:25 --> Config Class Initialized
INFO - 2018-02-06 07:40:25 --> Config Class Initialized
INFO - 2018-02-06 07:40:25 --> Hooks Class Initialized
INFO - 2018-02-06 07:40:25 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:40:25 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:25 --> Utf8 Class Initialized
INFO - 2018-02-06 07:40:25 --> URI Class Initialized
DEBUG - 2018-02-06 07:40:25 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:40:25 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:25 --> Utf8 Class Initialized
INFO - 2018-02-06 07:40:25 --> Utf8 Class Initialized
INFO - 2018-02-06 07:40:25 --> Router Class Initialized
INFO - 2018-02-06 07:40:25 --> URI Class Initialized
INFO - 2018-02-06 07:40:25 --> URI Class Initialized
INFO - 2018-02-06 07:40:25 --> Output Class Initialized
INFO - 2018-02-06 07:40:25 --> Router Class Initialized
INFO - 2018-02-06 07:40:25 --> Router Class Initialized
INFO - 2018-02-06 07:40:25 --> Security Class Initialized
INFO - 2018-02-06 07:40:25 --> Output Class Initialized
INFO - 2018-02-06 07:40:25 --> Output Class Initialized
DEBUG - 2018-02-06 07:40:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:40:25 --> Input Class Initialized
INFO - 2018-02-06 07:40:25 --> Language Class Initialized
INFO - 2018-02-06 07:40:25 --> Security Class Initialized
INFO - 2018-02-06 07:40:25 --> Security Class Initialized
ERROR - 2018-02-06 07:40:25 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-02-06 07:40:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:40:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:40:25 --> Input Class Initialized
INFO - 2018-02-06 07:40:25 --> Input Class Initialized
INFO - 2018-02-06 07:40:25 --> Language Class Initialized
INFO - 2018-02-06 07:40:25 --> Language Class Initialized
ERROR - 2018-02-06 07:40:25 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-06 07:40:25 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-06 07:40:27 --> Config Class Initialized
INFO - 2018-02-06 07:40:27 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:40:27 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:27 --> Utf8 Class Initialized
INFO - 2018-02-06 07:40:27 --> URI Class Initialized
INFO - 2018-02-06 07:40:27 --> Router Class Initialized
INFO - 2018-02-06 07:40:27 --> Output Class Initialized
INFO - 2018-02-06 07:40:27 --> Security Class Initialized
DEBUG - 2018-02-06 07:40:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:40:27 --> Input Class Initialized
INFO - 2018-02-06 07:40:27 --> Language Class Initialized
INFO - 2018-02-06 07:40:27 --> Loader Class Initialized
INFO - 2018-02-06 07:40:27 --> Helper loaded: url_helper
INFO - 2018-02-06 07:40:27 --> Helper loaded: form_helper
INFO - 2018-02-06 07:40:27 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:40:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:40:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:40:27 --> Form Validation Class Initialized
INFO - 2018-02-06 07:40:27 --> Model Class Initialized
INFO - 2018-02-06 07:40:27 --> Controller Class Initialized
INFO - 2018-02-06 07:40:27 --> Model Class Initialized
DEBUG - 2018-02-06 07:40:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:40:27 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:40:27 --> Final output sent to browser
DEBUG - 2018-02-06 07:40:27 --> Total execution time: 0.0390
INFO - 2018-02-06 07:40:28 --> Config Class Initialized
INFO - 2018-02-06 07:40:28 --> Hooks Class Initialized
INFO - 2018-02-06 07:40:28 --> Config Class Initialized
INFO - 2018-02-06 07:40:28 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:40:28 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:28 --> Utf8 Class Initialized
INFO - 2018-02-06 07:40:28 --> Config Class Initialized
INFO - 2018-02-06 07:40:28 --> Hooks Class Initialized
INFO - 2018-02-06 07:40:28 --> URI Class Initialized
INFO - 2018-02-06 07:40:28 --> Config Class Initialized
INFO - 2018-02-06 07:40:28 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:40:28 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:28 --> Utf8 Class Initialized
INFO - 2018-02-06 07:40:28 --> Router Class Initialized
INFO - 2018-02-06 07:40:28 --> URI Class Initialized
DEBUG - 2018-02-06 07:40:28 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:28 --> Output Class Initialized
INFO - 2018-02-06 07:40:28 --> Utf8 Class Initialized
INFO - 2018-02-06 07:40:28 --> Router Class Initialized
DEBUG - 2018-02-06 07:40:28 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:28 --> URI Class Initialized
INFO - 2018-02-06 07:40:28 --> Security Class Initialized
INFO - 2018-02-06 07:40:28 --> Utf8 Class Initialized
INFO - 2018-02-06 07:40:28 --> Output Class Initialized
DEBUG - 2018-02-06 07:40:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:40:28 --> Input Class Initialized
INFO - 2018-02-06 07:40:28 --> Router Class Initialized
INFO - 2018-02-06 07:40:28 --> Security Class Initialized
INFO - 2018-02-06 07:40:28 --> Language Class Initialized
INFO - 2018-02-06 07:40:28 --> URI Class Initialized
ERROR - 2018-02-06 07:40:28 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:40:28 --> Output Class Initialized
DEBUG - 2018-02-06 07:40:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:40:28 --> Router Class Initialized
INFO - 2018-02-06 07:40:28 --> Input Class Initialized
INFO - 2018-02-06 07:40:28 --> Security Class Initialized
INFO - 2018-02-06 07:40:28 --> Language Class Initialized
DEBUG - 2018-02-06 07:40:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:40:28 --> Config Class Initialized
INFO - 2018-02-06 07:40:28 --> Output Class Initialized
INFO - 2018-02-06 07:40:28 --> Input Class Initialized
INFO - 2018-02-06 07:40:28 --> Hooks Class Initialized
ERROR - 2018-02-06 07:40:28 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:40:28 --> Config Class Initialized
INFO - 2018-02-06 07:40:28 --> Hooks Class Initialized
INFO - 2018-02-06 07:40:28 --> Language Class Initialized
INFO - 2018-02-06 07:40:28 --> Security Class Initialized
ERROR - 2018-02-06 07:40:28 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-02-06 07:40:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:40:28 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:28 --> Input Class Initialized
INFO - 2018-02-06 07:40:28 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:40:28 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:28 --> Language Class Initialized
INFO - 2018-02-06 07:40:28 --> Utf8 Class Initialized
INFO - 2018-02-06 07:40:28 --> URI Class Initialized
ERROR - 2018-02-06 07:40:28 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:40:28 --> URI Class Initialized
INFO - 2018-02-06 07:40:28 --> Router Class Initialized
INFO - 2018-02-06 07:40:28 --> Config Class Initialized
INFO - 2018-02-06 07:40:28 --> Hooks Class Initialized
INFO - 2018-02-06 07:40:28 --> Router Class Initialized
INFO - 2018-02-06 07:40:28 --> Output Class Initialized
INFO - 2018-02-06 07:40:28 --> Security Class Initialized
DEBUG - 2018-02-06 07:40:28 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:28 --> Output Class Initialized
INFO - 2018-02-06 07:40:28 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:40:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:40:28 --> URI Class Initialized
INFO - 2018-02-06 07:40:28 --> Input Class Initialized
INFO - 2018-02-06 07:40:28 --> Security Class Initialized
INFO - 2018-02-06 07:40:28 --> Language Class Initialized
INFO - 2018-02-06 07:40:28 --> Router Class Initialized
DEBUG - 2018-02-06 07:40:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:40:28 --> Input Class Initialized
ERROR - 2018-02-06 07:40:28 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-06 07:40:28 --> Language Class Initialized
INFO - 2018-02-06 07:40:28 --> Output Class Initialized
ERROR - 2018-02-06 07:40:28 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-06 07:40:28 --> Security Class Initialized
DEBUG - 2018-02-06 07:40:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:40:28 --> Input Class Initialized
INFO - 2018-02-06 07:40:28 --> Language Class Initialized
ERROR - 2018-02-06 07:40:28 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-06 07:40:28 --> Config Class Initialized
INFO - 2018-02-06 07:40:28 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:40:28 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:28 --> Utf8 Class Initialized
INFO - 2018-02-06 07:40:28 --> URI Class Initialized
INFO - 2018-02-06 07:40:28 --> Router Class Initialized
INFO - 2018-02-06 07:40:28 --> Output Class Initialized
INFO - 2018-02-06 07:40:28 --> Security Class Initialized
DEBUG - 2018-02-06 07:40:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:40:28 --> Input Class Initialized
INFO - 2018-02-06 07:40:28 --> Language Class Initialized
INFO - 2018-02-06 07:40:28 --> Loader Class Initialized
INFO - 2018-02-06 07:40:28 --> Helper loaded: url_helper
INFO - 2018-02-06 07:40:28 --> Helper loaded: form_helper
INFO - 2018-02-06 07:40:28 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:40:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:40:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:40:28 --> Form Validation Class Initialized
INFO - 2018-02-06 07:40:28 --> Model Class Initialized
INFO - 2018-02-06 07:40:28 --> Controller Class Initialized
INFO - 2018-02-06 07:40:28 --> Model Class Initialized
DEBUG - 2018-02-06 07:40:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:40:29 --> Config Class Initialized
INFO - 2018-02-06 07:40:29 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:40:29 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:29 --> Utf8 Class Initialized
INFO - 2018-02-06 07:40:29 --> URI Class Initialized
INFO - 2018-02-06 07:40:29 --> Router Class Initialized
INFO - 2018-02-06 07:40:29 --> Output Class Initialized
INFO - 2018-02-06 07:40:29 --> Security Class Initialized
DEBUG - 2018-02-06 07:40:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:40:29 --> Input Class Initialized
INFO - 2018-02-06 07:40:29 --> Language Class Initialized
INFO - 2018-02-06 07:40:29 --> Loader Class Initialized
INFO - 2018-02-06 07:40:29 --> Helper loaded: url_helper
INFO - 2018-02-06 07:40:29 --> Helper loaded: form_helper
INFO - 2018-02-06 07:40:29 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:40:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:40:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:40:29 --> Form Validation Class Initialized
INFO - 2018-02-06 07:40:29 --> Model Class Initialized
INFO - 2018-02-06 07:40:29 --> Controller Class Initialized
INFO - 2018-02-06 07:40:29 --> Model Class Initialized
DEBUG - 2018-02-06 07:40:29 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:40:29 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:40:29 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:40:29 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:40:29 --> Final output sent to browser
DEBUG - 2018-02-06 07:40:29 --> Total execution time: 0.0522
INFO - 2018-02-06 07:40:29 --> Config Class Initialized
INFO - 2018-02-06 07:40:29 --> Hooks Class Initialized
INFO - 2018-02-06 07:40:29 --> Config Class Initialized
INFO - 2018-02-06 07:40:29 --> Config Class Initialized
INFO - 2018-02-06 07:40:29 --> Hooks Class Initialized
INFO - 2018-02-06 07:40:29 --> Hooks Class Initialized
INFO - 2018-02-06 07:40:29 --> Config Class Initialized
INFO - 2018-02-06 07:40:29 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:40:29 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:29 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:40:29 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:29 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:40:29 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:29 --> Utf8 Class Initialized
INFO - 2018-02-06 07:40:29 --> URI Class Initialized
INFO - 2018-02-06 07:40:29 --> URI Class Initialized
DEBUG - 2018-02-06 07:40:29 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:29 --> URI Class Initialized
INFO - 2018-02-06 07:40:29 --> Utf8 Class Initialized
INFO - 2018-02-06 07:40:29 --> Router Class Initialized
INFO - 2018-02-06 07:40:29 --> Router Class Initialized
INFO - 2018-02-06 07:40:29 --> URI Class Initialized
INFO - 2018-02-06 07:40:29 --> Router Class Initialized
INFO - 2018-02-06 07:40:29 --> Output Class Initialized
INFO - 2018-02-06 07:40:29 --> Output Class Initialized
INFO - 2018-02-06 07:40:29 --> Router Class Initialized
INFO - 2018-02-06 07:40:29 --> Output Class Initialized
INFO - 2018-02-06 07:40:29 --> Security Class Initialized
INFO - 2018-02-06 07:40:29 --> Security Class Initialized
INFO - 2018-02-06 07:40:29 --> Security Class Initialized
INFO - 2018-02-06 07:40:29 --> Output Class Initialized
DEBUG - 2018-02-06 07:40:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:40:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:40:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:40:29 --> Security Class Initialized
INFO - 2018-02-06 07:40:29 --> Input Class Initialized
INFO - 2018-02-06 07:40:29 --> Input Class Initialized
INFO - 2018-02-06 07:40:29 --> Input Class Initialized
INFO - 2018-02-06 07:40:29 --> Language Class Initialized
INFO - 2018-02-06 07:40:29 --> Language Class Initialized
INFO - 2018-02-06 07:40:29 --> Language Class Initialized
DEBUG - 2018-02-06 07:40:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:40:29 --> Input Class Initialized
ERROR - 2018-02-06 07:40:29 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-06 07:40:29 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-06 07:40:29 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:40:29 --> Language Class Initialized
ERROR - 2018-02-06 07:40:29 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:40:30 --> Config Class Initialized
INFO - 2018-02-06 07:40:30 --> Config Class Initialized
INFO - 2018-02-06 07:40:30 --> Config Class Initialized
INFO - 2018-02-06 07:40:30 --> Hooks Class Initialized
INFO - 2018-02-06 07:40:30 --> Hooks Class Initialized
INFO - 2018-02-06 07:40:30 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:40:30 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:30 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:40:30 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:40:30 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:30 --> Utf8 Class Initialized
INFO - 2018-02-06 07:40:30 --> Utf8 Class Initialized
INFO - 2018-02-06 07:40:30 --> URI Class Initialized
INFO - 2018-02-06 07:40:30 --> URI Class Initialized
INFO - 2018-02-06 07:40:30 --> URI Class Initialized
INFO - 2018-02-06 07:40:30 --> Router Class Initialized
INFO - 2018-02-06 07:40:30 --> Router Class Initialized
INFO - 2018-02-06 07:40:30 --> Router Class Initialized
INFO - 2018-02-06 07:40:30 --> Output Class Initialized
INFO - 2018-02-06 07:40:30 --> Output Class Initialized
INFO - 2018-02-06 07:40:30 --> Output Class Initialized
INFO - 2018-02-06 07:40:30 --> Security Class Initialized
INFO - 2018-02-06 07:40:30 --> Security Class Initialized
INFO - 2018-02-06 07:40:30 --> Security Class Initialized
DEBUG - 2018-02-06 07:40:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:40:30 --> Input Class Initialized
DEBUG - 2018-02-06 07:40:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:40:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:40:30 --> Input Class Initialized
INFO - 2018-02-06 07:40:30 --> Input Class Initialized
INFO - 2018-02-06 07:40:30 --> Language Class Initialized
INFO - 2018-02-06 07:40:30 --> Language Class Initialized
INFO - 2018-02-06 07:40:30 --> Language Class Initialized
ERROR - 2018-02-06 07:40:30 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-06 07:40:30 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-06 07:40:30 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-06 07:40:31 --> Config Class Initialized
INFO - 2018-02-06 07:40:31 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:40:31 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:31 --> Utf8 Class Initialized
INFO - 2018-02-06 07:40:31 --> URI Class Initialized
INFO - 2018-02-06 07:40:31 --> Router Class Initialized
INFO - 2018-02-06 07:40:31 --> Output Class Initialized
INFO - 2018-02-06 07:40:31 --> Security Class Initialized
DEBUG - 2018-02-06 07:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:40:31 --> Input Class Initialized
INFO - 2018-02-06 07:40:31 --> Language Class Initialized
INFO - 2018-02-06 07:40:31 --> Loader Class Initialized
INFO - 2018-02-06 07:40:31 --> Helper loaded: url_helper
INFO - 2018-02-06 07:40:31 --> Helper loaded: form_helper
INFO - 2018-02-06 07:40:31 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:40:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:40:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:40:31 --> Form Validation Class Initialized
INFO - 2018-02-06 07:40:31 --> Model Class Initialized
INFO - 2018-02-06 07:40:31 --> Controller Class Initialized
INFO - 2018-02-06 07:40:31 --> Model Class Initialized
DEBUG - 2018-02-06 07:40:31 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:40:31 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:40:31 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:40:31 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:40:31 --> Final output sent to browser
DEBUG - 2018-02-06 07:40:31 --> Total execution time: 0.0862
INFO - 2018-02-06 07:40:31 --> Config Class Initialized
INFO - 2018-02-06 07:40:31 --> Hooks Class Initialized
INFO - 2018-02-06 07:40:31 --> Config Class Initialized
INFO - 2018-02-06 07:40:31 --> Hooks Class Initialized
INFO - 2018-02-06 07:40:31 --> Config Class Initialized
INFO - 2018-02-06 07:40:31 --> Hooks Class Initialized
INFO - 2018-02-06 07:40:31 --> Config Class Initialized
DEBUG - 2018-02-06 07:40:31 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:31 --> Hooks Class Initialized
INFO - 2018-02-06 07:40:31 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:40:31 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:31 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:40:31 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:31 --> Utf8 Class Initialized
INFO - 2018-02-06 07:40:31 --> URI Class Initialized
INFO - 2018-02-06 07:40:31 --> URI Class Initialized
INFO - 2018-02-06 07:40:31 --> URI Class Initialized
DEBUG - 2018-02-06 07:40:31 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:31 --> Utf8 Class Initialized
INFO - 2018-02-06 07:40:31 --> Router Class Initialized
INFO - 2018-02-06 07:40:31 --> Router Class Initialized
INFO - 2018-02-06 07:40:31 --> URI Class Initialized
INFO - 2018-02-06 07:40:31 --> Router Class Initialized
INFO - 2018-02-06 07:40:31 --> Output Class Initialized
INFO - 2018-02-06 07:40:31 --> Router Class Initialized
INFO - 2018-02-06 07:40:31 --> Output Class Initialized
INFO - 2018-02-06 07:40:31 --> Output Class Initialized
INFO - 2018-02-06 07:40:31 --> Security Class Initialized
INFO - 2018-02-06 07:40:31 --> Security Class Initialized
INFO - 2018-02-06 07:40:31 --> Output Class Initialized
INFO - 2018-02-06 07:40:31 --> Security Class Initialized
DEBUG - 2018-02-06 07:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:40:31 --> Input Class Initialized
DEBUG - 2018-02-06 07:40:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:40:31 --> Security Class Initialized
INFO - 2018-02-06 07:40:31 --> Language Class Initialized
INFO - 2018-02-06 07:40:31 --> Input Class Initialized
INFO - 2018-02-06 07:40:31 --> Input Class Initialized
INFO - 2018-02-06 07:40:31 --> Language Class Initialized
INFO - 2018-02-06 07:40:31 --> Language Class Initialized
DEBUG - 2018-02-06 07:40:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-06 07:40:31 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:40:31 --> Input Class Initialized
ERROR - 2018-02-06 07:40:31 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-06 07:40:31 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:40:31 --> Language Class Initialized
ERROR - 2018-02-06 07:40:31 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:40:31 --> Config Class Initialized
INFO - 2018-02-06 07:40:31 --> Hooks Class Initialized
INFO - 2018-02-06 07:40:31 --> Config Class Initialized
INFO - 2018-02-06 07:40:31 --> Hooks Class Initialized
INFO - 2018-02-06 07:40:31 --> Config Class Initialized
INFO - 2018-02-06 07:40:31 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:40:31 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:31 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:40:31 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:31 --> URI Class Initialized
INFO - 2018-02-06 07:40:31 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:40:31 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:31 --> Utf8 Class Initialized
INFO - 2018-02-06 07:40:31 --> URI Class Initialized
INFO - 2018-02-06 07:40:31 --> Router Class Initialized
INFO - 2018-02-06 07:40:31 --> URI Class Initialized
INFO - 2018-02-06 07:40:31 --> Router Class Initialized
INFO - 2018-02-06 07:40:31 --> Output Class Initialized
INFO - 2018-02-06 07:40:31 --> Router Class Initialized
INFO - 2018-02-06 07:40:31 --> Output Class Initialized
INFO - 2018-02-06 07:40:31 --> Security Class Initialized
INFO - 2018-02-06 07:40:31 --> Output Class Initialized
DEBUG - 2018-02-06 07:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:40:31 --> Security Class Initialized
INFO - 2018-02-06 07:40:31 --> Input Class Initialized
INFO - 2018-02-06 07:40:31 --> Security Class Initialized
INFO - 2018-02-06 07:40:31 --> Language Class Initialized
DEBUG - 2018-02-06 07:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:40:31 --> Input Class Initialized
INFO - 2018-02-06 07:40:31 --> Language Class Initialized
DEBUG - 2018-02-06 07:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:40:31 --> Input Class Initialized
ERROR - 2018-02-06 07:40:31 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-06 07:40:31 --> Language Class Initialized
ERROR - 2018-02-06 07:40:31 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-06 07:40:31 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-06 07:40:31 --> Config Class Initialized
INFO - 2018-02-06 07:40:31 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:40:31 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:31 --> Utf8 Class Initialized
INFO - 2018-02-06 07:40:31 --> URI Class Initialized
INFO - 2018-02-06 07:40:31 --> Router Class Initialized
INFO - 2018-02-06 07:40:31 --> Output Class Initialized
INFO - 2018-02-06 07:40:31 --> Security Class Initialized
DEBUG - 2018-02-06 07:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:40:31 --> Input Class Initialized
INFO - 2018-02-06 07:40:31 --> Language Class Initialized
INFO - 2018-02-06 07:40:31 --> Loader Class Initialized
INFO - 2018-02-06 07:40:31 --> Helper loaded: url_helper
INFO - 2018-02-06 07:40:31 --> Helper loaded: form_helper
INFO - 2018-02-06 07:40:31 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:40:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:40:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:40:31 --> Form Validation Class Initialized
INFO - 2018-02-06 07:40:31 --> Model Class Initialized
INFO - 2018-02-06 07:40:31 --> Controller Class Initialized
INFO - 2018-02-06 07:40:31 --> Model Class Initialized
DEBUG - 2018-02-06 07:40:31 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:40:31 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:40:31 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:40:31 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:40:31 --> Final output sent to browser
DEBUG - 2018-02-06 07:40:31 --> Total execution time: 0.0570
INFO - 2018-02-06 07:40:32 --> Config Class Initialized
INFO - 2018-02-06 07:40:32 --> Config Class Initialized
INFO - 2018-02-06 07:40:32 --> Hooks Class Initialized
INFO - 2018-02-06 07:40:32 --> Config Class Initialized
INFO - 2018-02-06 07:40:32 --> Hooks Class Initialized
INFO - 2018-02-06 07:40:32 --> Hooks Class Initialized
INFO - 2018-02-06 07:40:32 --> Config Class Initialized
INFO - 2018-02-06 07:40:32 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:40:32 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:32 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:40:32 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:40:32 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:32 --> Utf8 Class Initialized
INFO - 2018-02-06 07:40:32 --> Utf8 Class Initialized
INFO - 2018-02-06 07:40:32 --> URI Class Initialized
INFO - 2018-02-06 07:40:32 --> URI Class Initialized
INFO - 2018-02-06 07:40:32 --> URI Class Initialized
DEBUG - 2018-02-06 07:40:32 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:32 --> Utf8 Class Initialized
INFO - 2018-02-06 07:40:32 --> Router Class Initialized
INFO - 2018-02-06 07:40:32 --> Router Class Initialized
INFO - 2018-02-06 07:40:32 --> URI Class Initialized
INFO - 2018-02-06 07:40:32 --> Router Class Initialized
INFO - 2018-02-06 07:40:32 --> Output Class Initialized
INFO - 2018-02-06 07:40:32 --> Security Class Initialized
INFO - 2018-02-06 07:40:32 --> Output Class Initialized
INFO - 2018-02-06 07:40:32 --> Router Class Initialized
INFO - 2018-02-06 07:40:32 --> Output Class Initialized
DEBUG - 2018-02-06 07:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:40:32 --> Input Class Initialized
INFO - 2018-02-06 07:40:32 --> Security Class Initialized
INFO - 2018-02-06 07:40:32 --> Security Class Initialized
INFO - 2018-02-06 07:40:32 --> Output Class Initialized
INFO - 2018-02-06 07:40:32 --> Language Class Initialized
DEBUG - 2018-02-06 07:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:40:32 --> Input Class Initialized
DEBUG - 2018-02-06 07:40:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-06 07:40:32 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:40:32 --> Security Class Initialized
INFO - 2018-02-06 07:40:32 --> Input Class Initialized
INFO - 2018-02-06 07:40:32 --> Language Class Initialized
INFO - 2018-02-06 07:40:32 --> Language Class Initialized
DEBUG - 2018-02-06 07:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:40:32 --> Input Class Initialized
ERROR - 2018-02-06 07:40:32 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:40:32 --> Language Class Initialized
ERROR - 2018-02-06 07:40:32 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-06 07:40:32 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:40:32 --> Config Class Initialized
INFO - 2018-02-06 07:40:32 --> Hooks Class Initialized
INFO - 2018-02-06 07:40:32 --> Config Class Initialized
INFO - 2018-02-06 07:40:32 --> Config Class Initialized
INFO - 2018-02-06 07:40:32 --> Hooks Class Initialized
INFO - 2018-02-06 07:40:32 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:40:32 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:32 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:40:32 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:32 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:40:32 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:32 --> URI Class Initialized
INFO - 2018-02-06 07:40:32 --> Utf8 Class Initialized
INFO - 2018-02-06 07:40:32 --> URI Class Initialized
INFO - 2018-02-06 07:40:32 --> URI Class Initialized
INFO - 2018-02-06 07:40:32 --> Router Class Initialized
INFO - 2018-02-06 07:40:32 --> Router Class Initialized
INFO - 2018-02-06 07:40:32 --> Router Class Initialized
INFO - 2018-02-06 07:40:32 --> Output Class Initialized
INFO - 2018-02-06 07:40:32 --> Output Class Initialized
INFO - 2018-02-06 07:40:32 --> Output Class Initialized
INFO - 2018-02-06 07:40:32 --> Security Class Initialized
INFO - 2018-02-06 07:40:32 --> Security Class Initialized
INFO - 2018-02-06 07:40:32 --> Security Class Initialized
DEBUG - 2018-02-06 07:40:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:40:32 --> Input Class Initialized
INFO - 2018-02-06 07:40:32 --> Input Class Initialized
DEBUG - 2018-02-06 07:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:40:32 --> Input Class Initialized
INFO - 2018-02-06 07:40:32 --> Language Class Initialized
INFO - 2018-02-06 07:40:32 --> Language Class Initialized
INFO - 2018-02-06 07:40:32 --> Language Class Initialized
ERROR - 2018-02-06 07:40:32 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-06 07:40:32 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-06 07:40:32 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-06 07:40:32 --> Config Class Initialized
INFO - 2018-02-06 07:40:32 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:40:32 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:32 --> Utf8 Class Initialized
INFO - 2018-02-06 07:40:32 --> URI Class Initialized
INFO - 2018-02-06 07:40:32 --> Router Class Initialized
INFO - 2018-02-06 07:40:32 --> Output Class Initialized
INFO - 2018-02-06 07:40:32 --> Security Class Initialized
DEBUG - 2018-02-06 07:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:40:32 --> Input Class Initialized
INFO - 2018-02-06 07:40:32 --> Language Class Initialized
INFO - 2018-02-06 07:40:32 --> Loader Class Initialized
INFO - 2018-02-06 07:40:32 --> Helper loaded: url_helper
INFO - 2018-02-06 07:40:32 --> Helper loaded: form_helper
INFO - 2018-02-06 07:40:32 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:40:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:40:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:40:32 --> Form Validation Class Initialized
INFO - 2018-02-06 07:40:32 --> Model Class Initialized
INFO - 2018-02-06 07:40:32 --> Controller Class Initialized
INFO - 2018-02-06 07:40:32 --> Model Class Initialized
DEBUG - 2018-02-06 07:40:32 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:40:32 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:40:32 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:40:32 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:40:32 --> Final output sent to browser
DEBUG - 2018-02-06 07:40:32 --> Total execution time: 0.0422
INFO - 2018-02-06 07:40:32 --> Config Class Initialized
INFO - 2018-02-06 07:40:32 --> Config Class Initialized
INFO - 2018-02-06 07:40:32 --> Hooks Class Initialized
INFO - 2018-02-06 07:40:32 --> Hooks Class Initialized
INFO - 2018-02-06 07:40:32 --> Config Class Initialized
INFO - 2018-02-06 07:40:32 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:40:32 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:40:32 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:32 --> Utf8 Class Initialized
INFO - 2018-02-06 07:40:32 --> Utf8 Class Initialized
INFO - 2018-02-06 07:40:32 --> Config Class Initialized
DEBUG - 2018-02-06 07:40:32 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:32 --> Hooks Class Initialized
INFO - 2018-02-06 07:40:32 --> Utf8 Class Initialized
INFO - 2018-02-06 07:40:32 --> URI Class Initialized
INFO - 2018-02-06 07:40:32 --> URI Class Initialized
INFO - 2018-02-06 07:40:32 --> URI Class Initialized
INFO - 2018-02-06 07:40:32 --> Router Class Initialized
DEBUG - 2018-02-06 07:40:32 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:32 --> Router Class Initialized
INFO - 2018-02-06 07:40:32 --> Utf8 Class Initialized
INFO - 2018-02-06 07:40:32 --> Router Class Initialized
INFO - 2018-02-06 07:40:32 --> Output Class Initialized
INFO - 2018-02-06 07:40:32 --> URI Class Initialized
INFO - 2018-02-06 07:40:32 --> Output Class Initialized
INFO - 2018-02-06 07:40:32 --> Output Class Initialized
INFO - 2018-02-06 07:40:32 --> Security Class Initialized
INFO - 2018-02-06 07:40:32 --> Router Class Initialized
INFO - 2018-02-06 07:40:32 --> Security Class Initialized
INFO - 2018-02-06 07:40:32 --> Security Class Initialized
DEBUG - 2018-02-06 07:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:40:32 --> Input Class Initialized
INFO - 2018-02-06 07:40:32 --> Output Class Initialized
DEBUG - 2018-02-06 07:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:40:32 --> Language Class Initialized
DEBUG - 2018-02-06 07:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:40:32 --> Input Class Initialized
INFO - 2018-02-06 07:40:32 --> Input Class Initialized
INFO - 2018-02-06 07:40:32 --> Security Class Initialized
INFO - 2018-02-06 07:40:32 --> Language Class Initialized
ERROR - 2018-02-06 07:40:32 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:40:32 --> Language Class Initialized
DEBUG - 2018-02-06 07:40:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-06 07:40:32 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-06 07:40:32 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:40:32 --> Input Class Initialized
INFO - 2018-02-06 07:40:32 --> Language Class Initialized
ERROR - 2018-02-06 07:40:32 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:40:32 --> Config Class Initialized
INFO - 2018-02-06 07:40:32 --> Config Class Initialized
INFO - 2018-02-06 07:40:32 --> Config Class Initialized
INFO - 2018-02-06 07:40:32 --> Hooks Class Initialized
INFO - 2018-02-06 07:40:32 --> Hooks Class Initialized
INFO - 2018-02-06 07:40:32 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:40:32 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:40:32 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:32 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:40:32 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:32 --> Utf8 Class Initialized
INFO - 2018-02-06 07:40:32 --> Utf8 Class Initialized
INFO - 2018-02-06 07:40:32 --> URI Class Initialized
INFO - 2018-02-06 07:40:32 --> URI Class Initialized
INFO - 2018-02-06 07:40:32 --> URI Class Initialized
INFO - 2018-02-06 07:40:32 --> Router Class Initialized
INFO - 2018-02-06 07:40:32 --> Router Class Initialized
INFO - 2018-02-06 07:40:32 --> Router Class Initialized
INFO - 2018-02-06 07:40:32 --> Output Class Initialized
INFO - 2018-02-06 07:40:32 --> Output Class Initialized
INFO - 2018-02-06 07:40:32 --> Output Class Initialized
INFO - 2018-02-06 07:40:32 --> Security Class Initialized
INFO - 2018-02-06 07:40:32 --> Security Class Initialized
INFO - 2018-02-06 07:40:32 --> Security Class Initialized
DEBUG - 2018-02-06 07:40:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:40:32 --> Input Class Initialized
INFO - 2018-02-06 07:40:32 --> Input Class Initialized
DEBUG - 2018-02-06 07:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:40:32 --> Input Class Initialized
INFO - 2018-02-06 07:40:32 --> Language Class Initialized
INFO - 2018-02-06 07:40:32 --> Language Class Initialized
INFO - 2018-02-06 07:40:32 --> Language Class Initialized
ERROR - 2018-02-06 07:40:32 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-06 07:40:32 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-06 07:40:32 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-06 07:40:32 --> Config Class Initialized
INFO - 2018-02-06 07:40:32 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:40:32 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:32 --> Utf8 Class Initialized
INFO - 2018-02-06 07:40:32 --> URI Class Initialized
INFO - 2018-02-06 07:40:32 --> Router Class Initialized
INFO - 2018-02-06 07:40:32 --> Output Class Initialized
INFO - 2018-02-06 07:40:32 --> Security Class Initialized
DEBUG - 2018-02-06 07:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:40:32 --> Input Class Initialized
INFO - 2018-02-06 07:40:32 --> Language Class Initialized
INFO - 2018-02-06 07:40:32 --> Loader Class Initialized
INFO - 2018-02-06 07:40:32 --> Helper loaded: url_helper
INFO - 2018-02-06 07:40:32 --> Helper loaded: form_helper
INFO - 2018-02-06 07:40:32 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:40:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:40:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:40:32 --> Form Validation Class Initialized
INFO - 2018-02-06 07:40:32 --> Model Class Initialized
INFO - 2018-02-06 07:40:32 --> Controller Class Initialized
INFO - 2018-02-06 07:40:32 --> Model Class Initialized
DEBUG - 2018-02-06 07:40:32 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:40:32 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:40:32 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:40:32 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:40:32 --> Final output sent to browser
DEBUG - 2018-02-06 07:40:32 --> Total execution time: 0.0621
INFO - 2018-02-06 07:40:32 --> Config Class Initialized
INFO - 2018-02-06 07:40:32 --> Hooks Class Initialized
INFO - 2018-02-06 07:40:32 --> Config Class Initialized
INFO - 2018-02-06 07:40:32 --> Config Class Initialized
INFO - 2018-02-06 07:40:32 --> Hooks Class Initialized
INFO - 2018-02-06 07:40:32 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:40:32 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:32 --> Utf8 Class Initialized
INFO - 2018-02-06 07:40:32 --> Config Class Initialized
INFO - 2018-02-06 07:40:32 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:40:32 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:40:32 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:32 --> Utf8 Class Initialized
INFO - 2018-02-06 07:40:32 --> Utf8 Class Initialized
INFO - 2018-02-06 07:40:32 --> URI Class Initialized
INFO - 2018-02-06 07:40:32 --> URI Class Initialized
INFO - 2018-02-06 07:40:32 --> URI Class Initialized
INFO - 2018-02-06 07:40:32 --> Router Class Initialized
DEBUG - 2018-02-06 07:40:32 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:32 --> Utf8 Class Initialized
INFO - 2018-02-06 07:40:32 --> Router Class Initialized
INFO - 2018-02-06 07:40:32 --> Router Class Initialized
INFO - 2018-02-06 07:40:32 --> URI Class Initialized
INFO - 2018-02-06 07:40:32 --> Output Class Initialized
INFO - 2018-02-06 07:40:32 --> Output Class Initialized
INFO - 2018-02-06 07:40:32 --> Output Class Initialized
INFO - 2018-02-06 07:40:32 --> Security Class Initialized
INFO - 2018-02-06 07:40:32 --> Router Class Initialized
INFO - 2018-02-06 07:40:32 --> Security Class Initialized
DEBUG - 2018-02-06 07:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:40:32 --> Input Class Initialized
INFO - 2018-02-06 07:40:32 --> Security Class Initialized
INFO - 2018-02-06 07:40:32 --> Output Class Initialized
DEBUG - 2018-02-06 07:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:40:32 --> Input Class Initialized
INFO - 2018-02-06 07:40:32 --> Language Class Initialized
DEBUG - 2018-02-06 07:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:40:32 --> Security Class Initialized
INFO - 2018-02-06 07:40:32 --> Language Class Initialized
INFO - 2018-02-06 07:40:32 --> Input Class Initialized
ERROR - 2018-02-06 07:40:32 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:40:32 --> Language Class Initialized
ERROR - 2018-02-06 07:40:32 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-02-06 07:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:40:32 --> Input Class Initialized
ERROR - 2018-02-06 07:40:32 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:40:32 --> Language Class Initialized
ERROR - 2018-02-06 07:40:32 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:40:32 --> Config Class Initialized
INFO - 2018-02-06 07:40:32 --> Hooks Class Initialized
INFO - 2018-02-06 07:40:32 --> Config Class Initialized
INFO - 2018-02-06 07:40:32 --> Hooks Class Initialized
INFO - 2018-02-06 07:40:32 --> Config Class Initialized
INFO - 2018-02-06 07:40:32 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:40:32 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:32 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:40:32 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:32 --> Utf8 Class Initialized
INFO - 2018-02-06 07:40:32 --> URI Class Initialized
DEBUG - 2018-02-06 07:40:32 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:40:32 --> Utf8 Class Initialized
INFO - 2018-02-06 07:40:32 --> URI Class Initialized
INFO - 2018-02-06 07:40:32 --> URI Class Initialized
INFO - 2018-02-06 07:40:32 --> Router Class Initialized
INFO - 2018-02-06 07:40:32 --> Router Class Initialized
INFO - 2018-02-06 07:40:32 --> Router Class Initialized
INFO - 2018-02-06 07:40:32 --> Output Class Initialized
INFO - 2018-02-06 07:40:32 --> Output Class Initialized
INFO - 2018-02-06 07:40:32 --> Security Class Initialized
INFO - 2018-02-06 07:40:32 --> Output Class Initialized
INFO - 2018-02-06 07:40:32 --> Security Class Initialized
INFO - 2018-02-06 07:40:32 --> Security Class Initialized
DEBUG - 2018-02-06 07:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:40:32 --> Input Class Initialized
DEBUG - 2018-02-06 07:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:40:32 --> Input Class Initialized
INFO - 2018-02-06 07:40:32 --> Language Class Initialized
DEBUG - 2018-02-06 07:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:40:32 --> Input Class Initialized
INFO - 2018-02-06 07:40:32 --> Language Class Initialized
INFO - 2018-02-06 07:40:32 --> Language Class Initialized
ERROR - 2018-02-06 07:40:32 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-06 07:40:32 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-06 07:40:32 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-06 07:43:46 --> Config Class Initialized
INFO - 2018-02-06 07:43:46 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:43:46 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:43:46 --> Utf8 Class Initialized
INFO - 2018-02-06 07:43:46 --> URI Class Initialized
INFO - 2018-02-06 07:43:46 --> Router Class Initialized
INFO - 2018-02-06 07:43:46 --> Output Class Initialized
INFO - 2018-02-06 07:43:46 --> Security Class Initialized
DEBUG - 2018-02-06 07:43:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:43:46 --> Input Class Initialized
INFO - 2018-02-06 07:43:46 --> Language Class Initialized
INFO - 2018-02-06 07:43:46 --> Loader Class Initialized
INFO - 2018-02-06 07:43:46 --> Helper loaded: url_helper
INFO - 2018-02-06 07:43:46 --> Helper loaded: form_helper
INFO - 2018-02-06 07:43:46 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:43:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:43:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:43:46 --> Form Validation Class Initialized
INFO - 2018-02-06 07:43:46 --> Model Class Initialized
INFO - 2018-02-06 07:43:46 --> Controller Class Initialized
INFO - 2018-02-06 07:43:46 --> Model Class Initialized
DEBUG - 2018-02-06 07:43:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:43:46 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:43:46 --> Final output sent to browser
DEBUG - 2018-02-06 07:43:46 --> Total execution time: 0.0437
INFO - 2018-02-06 07:43:46 --> Config Class Initialized
INFO - 2018-02-06 07:43:46 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:43:46 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:43:46 --> Config Class Initialized
INFO - 2018-02-06 07:43:46 --> Config Class Initialized
INFO - 2018-02-06 07:43:46 --> Utf8 Class Initialized
INFO - 2018-02-06 07:43:46 --> Hooks Class Initialized
INFO - 2018-02-06 07:43:46 --> Hooks Class Initialized
INFO - 2018-02-06 07:43:46 --> Config Class Initialized
INFO - 2018-02-06 07:43:46 --> Hooks Class Initialized
INFO - 2018-02-06 07:43:46 --> URI Class Initialized
DEBUG - 2018-02-06 07:43:46 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:43:46 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:43:46 --> Router Class Initialized
DEBUG - 2018-02-06 07:43:46 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:43:46 --> Utf8 Class Initialized
INFO - 2018-02-06 07:43:46 --> Utf8 Class Initialized
INFO - 2018-02-06 07:43:46 --> Utf8 Class Initialized
INFO - 2018-02-06 07:43:46 --> URI Class Initialized
INFO - 2018-02-06 07:43:46 --> URI Class Initialized
INFO - 2018-02-06 07:43:46 --> URI Class Initialized
INFO - 2018-02-06 07:43:46 --> Output Class Initialized
INFO - 2018-02-06 07:43:46 --> Router Class Initialized
INFO - 2018-02-06 07:43:46 --> Router Class Initialized
INFO - 2018-02-06 07:43:46 --> Security Class Initialized
INFO - 2018-02-06 07:43:46 --> Router Class Initialized
DEBUG - 2018-02-06 07:43:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:43:46 --> Output Class Initialized
INFO - 2018-02-06 07:43:46 --> Output Class Initialized
INFO - 2018-02-06 07:43:46 --> Input Class Initialized
INFO - 2018-02-06 07:43:46 --> Output Class Initialized
INFO - 2018-02-06 07:43:46 --> Language Class Initialized
INFO - 2018-02-06 07:43:46 --> Security Class Initialized
INFO - 2018-02-06 07:43:46 --> Security Class Initialized
INFO - 2018-02-06 07:43:46 --> Security Class Initialized
ERROR - 2018-02-06 07:43:46 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-02-06 07:43:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:43:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:43:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:43:46 --> Input Class Initialized
INFO - 2018-02-06 07:43:46 --> Input Class Initialized
INFO - 2018-02-06 07:43:46 --> Input Class Initialized
INFO - 2018-02-06 07:43:46 --> Language Class Initialized
INFO - 2018-02-06 07:43:46 --> Language Class Initialized
INFO - 2018-02-06 07:43:46 --> Language Class Initialized
ERROR - 2018-02-06 07:43:46 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-06 07:43:46 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-06 07:43:46 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:43:46 --> Config Class Initialized
INFO - 2018-02-06 07:43:46 --> Hooks Class Initialized
INFO - 2018-02-06 07:43:46 --> Config Class Initialized
INFO - 2018-02-06 07:43:46 --> Hooks Class Initialized
INFO - 2018-02-06 07:43:46 --> Config Class Initialized
INFO - 2018-02-06 07:43:46 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:43:46 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:43:46 --> Utf8 Class Initialized
INFO - 2018-02-06 07:43:46 --> URI Class Initialized
DEBUG - 2018-02-06 07:43:46 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:43:46 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:43:46 --> Utf8 Class Initialized
INFO - 2018-02-06 07:43:46 --> Utf8 Class Initialized
INFO - 2018-02-06 07:43:46 --> URI Class Initialized
INFO - 2018-02-06 07:43:46 --> Router Class Initialized
INFO - 2018-02-06 07:43:46 --> URI Class Initialized
INFO - 2018-02-06 07:43:46 --> Router Class Initialized
INFO - 2018-02-06 07:43:46 --> Output Class Initialized
INFO - 2018-02-06 07:43:46 --> Router Class Initialized
INFO - 2018-02-06 07:43:46 --> Output Class Initialized
INFO - 2018-02-06 07:43:46 --> Security Class Initialized
INFO - 2018-02-06 07:43:46 --> Output Class Initialized
INFO - 2018-02-06 07:43:46 --> Security Class Initialized
DEBUG - 2018-02-06 07:43:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:43:46 --> Input Class Initialized
INFO - 2018-02-06 07:43:46 --> Security Class Initialized
INFO - 2018-02-06 07:43:46 --> Language Class Initialized
DEBUG - 2018-02-06 07:43:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:43:46 --> Input Class Initialized
DEBUG - 2018-02-06 07:43:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:43:46 --> Input Class Initialized
ERROR - 2018-02-06 07:43:46 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-06 07:43:46 --> Language Class Initialized
INFO - 2018-02-06 07:43:46 --> Language Class Initialized
ERROR - 2018-02-06 07:43:46 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-06 07:43:46 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-06 07:43:46 --> Config Class Initialized
INFO - 2018-02-06 07:43:46 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:43:46 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:43:46 --> Utf8 Class Initialized
INFO - 2018-02-06 07:43:46 --> URI Class Initialized
INFO - 2018-02-06 07:43:46 --> Router Class Initialized
INFO - 2018-02-06 07:43:46 --> Output Class Initialized
INFO - 2018-02-06 07:43:46 --> Security Class Initialized
DEBUG - 2018-02-06 07:43:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:43:46 --> Input Class Initialized
INFO - 2018-02-06 07:43:46 --> Language Class Initialized
INFO - 2018-02-06 07:43:46 --> Loader Class Initialized
INFO - 2018-02-06 07:43:46 --> Helper loaded: url_helper
INFO - 2018-02-06 07:43:46 --> Helper loaded: form_helper
INFO - 2018-02-06 07:43:46 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:43:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:43:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:43:46 --> Form Validation Class Initialized
INFO - 2018-02-06 07:43:46 --> Model Class Initialized
INFO - 2018-02-06 07:43:46 --> Controller Class Initialized
INFO - 2018-02-06 07:43:46 --> Model Class Initialized
DEBUG - 2018-02-06 07:43:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:43:49 --> Config Class Initialized
INFO - 2018-02-06 07:43:49 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:43:49 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:43:49 --> Utf8 Class Initialized
INFO - 2018-02-06 07:43:49 --> URI Class Initialized
INFO - 2018-02-06 07:43:49 --> Router Class Initialized
INFO - 2018-02-06 07:43:49 --> Output Class Initialized
INFO - 2018-02-06 07:43:49 --> Security Class Initialized
DEBUG - 2018-02-06 07:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:43:49 --> Input Class Initialized
INFO - 2018-02-06 07:43:49 --> Language Class Initialized
INFO - 2018-02-06 07:43:49 --> Loader Class Initialized
INFO - 2018-02-06 07:43:49 --> Helper loaded: url_helper
INFO - 2018-02-06 07:43:49 --> Helper loaded: form_helper
INFO - 2018-02-06 07:43:49 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:43:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:43:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:43:49 --> Form Validation Class Initialized
INFO - 2018-02-06 07:43:49 --> Model Class Initialized
INFO - 2018-02-06 07:43:49 --> Controller Class Initialized
INFO - 2018-02-06 07:43:49 --> Model Class Initialized
DEBUG - 2018-02-06 07:43:49 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:43:49 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:43:49 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:43:49 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:43:49 --> Final output sent to browser
DEBUG - 2018-02-06 07:43:49 --> Total execution time: 0.0447
INFO - 2018-02-06 07:43:49 --> Config Class Initialized
INFO - 2018-02-06 07:43:49 --> Hooks Class Initialized
INFO - 2018-02-06 07:43:49 --> Config Class Initialized
INFO - 2018-02-06 07:43:49 --> Hooks Class Initialized
INFO - 2018-02-06 07:43:49 --> Config Class Initialized
INFO - 2018-02-06 07:43:49 --> Hooks Class Initialized
INFO - 2018-02-06 07:43:49 --> Config Class Initialized
INFO - 2018-02-06 07:43:49 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:43:49 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:43:49 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:43:49 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:43:49 --> Utf8 Class Initialized
INFO - 2018-02-06 07:43:49 --> Utf8 Class Initialized
INFO - 2018-02-06 07:43:49 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:43:49 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:43:49 --> URI Class Initialized
INFO - 2018-02-06 07:43:49 --> Utf8 Class Initialized
INFO - 2018-02-06 07:43:49 --> URI Class Initialized
INFO - 2018-02-06 07:43:49 --> URI Class Initialized
INFO - 2018-02-06 07:43:49 --> URI Class Initialized
INFO - 2018-02-06 07:43:49 --> Router Class Initialized
INFO - 2018-02-06 07:43:49 --> Router Class Initialized
INFO - 2018-02-06 07:43:49 --> Router Class Initialized
INFO - 2018-02-06 07:43:49 --> Router Class Initialized
INFO - 2018-02-06 07:43:49 --> Output Class Initialized
INFO - 2018-02-06 07:43:49 --> Output Class Initialized
INFO - 2018-02-06 07:43:49 --> Output Class Initialized
INFO - 2018-02-06 07:43:49 --> Output Class Initialized
INFO - 2018-02-06 07:43:49 --> Security Class Initialized
INFO - 2018-02-06 07:43:49 --> Security Class Initialized
INFO - 2018-02-06 07:43:49 --> Security Class Initialized
INFO - 2018-02-06 07:43:49 --> Security Class Initialized
DEBUG - 2018-02-06 07:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:43:49 --> Input Class Initialized
DEBUG - 2018-02-06 07:43:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:43:49 --> Input Class Initialized
INFO - 2018-02-06 07:43:49 --> Input Class Initialized
INFO - 2018-02-06 07:43:49 --> Language Class Initialized
DEBUG - 2018-02-06 07:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:43:49 --> Input Class Initialized
INFO - 2018-02-06 07:43:49 --> Language Class Initialized
INFO - 2018-02-06 07:43:49 --> Language Class Initialized
ERROR - 2018-02-06 07:43:49 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:43:49 --> Language Class Initialized
ERROR - 2018-02-06 07:43:49 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-06 07:43:49 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-06 07:43:49 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:43:49 --> Config Class Initialized
INFO - 2018-02-06 07:43:49 --> Hooks Class Initialized
INFO - 2018-02-06 07:43:49 --> Config Class Initialized
INFO - 2018-02-06 07:43:49 --> Hooks Class Initialized
INFO - 2018-02-06 07:43:49 --> Config Class Initialized
INFO - 2018-02-06 07:43:49 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:43:49 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:43:49 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:43:49 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:43:49 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:43:49 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:43:49 --> URI Class Initialized
INFO - 2018-02-06 07:43:49 --> Utf8 Class Initialized
INFO - 2018-02-06 07:43:49 --> URI Class Initialized
INFO - 2018-02-06 07:43:49 --> URI Class Initialized
INFO - 2018-02-06 07:43:49 --> Router Class Initialized
INFO - 2018-02-06 07:43:49 --> Router Class Initialized
INFO - 2018-02-06 07:43:49 --> Router Class Initialized
INFO - 2018-02-06 07:43:49 --> Output Class Initialized
INFO - 2018-02-06 07:43:49 --> Output Class Initialized
INFO - 2018-02-06 07:43:49 --> Output Class Initialized
INFO - 2018-02-06 07:43:49 --> Security Class Initialized
INFO - 2018-02-06 07:43:49 --> Security Class Initialized
DEBUG - 2018-02-06 07:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:43:49 --> Security Class Initialized
INFO - 2018-02-06 07:43:49 --> Input Class Initialized
DEBUG - 2018-02-06 07:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:43:49 --> Language Class Initialized
DEBUG - 2018-02-06 07:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:43:49 --> Input Class Initialized
INFO - 2018-02-06 07:43:49 --> Input Class Initialized
INFO - 2018-02-06 07:43:49 --> Language Class Initialized
INFO - 2018-02-06 07:43:49 --> Language Class Initialized
ERROR - 2018-02-06 07:43:49 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-06 07:43:49 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-06 07:43:49 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-06 07:44:49 --> Config Class Initialized
INFO - 2018-02-06 07:44:49 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:44:49 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:44:49 --> Utf8 Class Initialized
INFO - 2018-02-06 07:44:49 --> URI Class Initialized
INFO - 2018-02-06 07:44:49 --> Router Class Initialized
INFO - 2018-02-06 07:44:49 --> Output Class Initialized
INFO - 2018-02-06 07:44:49 --> Security Class Initialized
DEBUG - 2018-02-06 07:44:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:44:49 --> Input Class Initialized
INFO - 2018-02-06 07:44:49 --> Language Class Initialized
INFO - 2018-02-06 07:44:49 --> Loader Class Initialized
INFO - 2018-02-06 07:44:49 --> Helper loaded: url_helper
INFO - 2018-02-06 07:44:49 --> Helper loaded: form_helper
INFO - 2018-02-06 07:44:49 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:44:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:44:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:44:49 --> Form Validation Class Initialized
INFO - 2018-02-06 07:44:49 --> Model Class Initialized
INFO - 2018-02-06 07:44:49 --> Controller Class Initialized
INFO - 2018-02-06 07:44:49 --> Model Class Initialized
DEBUG - 2018-02-06 07:44:49 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:44:49 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:44:49 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:44:49 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:44:49 --> Final output sent to browser
DEBUG - 2018-02-06 07:44:49 --> Total execution time: 0.0725
INFO - 2018-02-06 07:44:49 --> Config Class Initialized
INFO - 2018-02-06 07:44:49 --> Config Class Initialized
INFO - 2018-02-06 07:44:49 --> Hooks Class Initialized
INFO - 2018-02-06 07:44:49 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:44:49 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:44:49 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:44:49 --> Utf8 Class Initialized
INFO - 2018-02-06 07:44:49 --> Utf8 Class Initialized
INFO - 2018-02-06 07:44:49 --> Config Class Initialized
INFO - 2018-02-06 07:44:49 --> Hooks Class Initialized
INFO - 2018-02-06 07:44:49 --> URI Class Initialized
INFO - 2018-02-06 07:44:49 --> URI Class Initialized
INFO - 2018-02-06 07:44:49 --> Config Class Initialized
INFO - 2018-02-06 07:44:49 --> Router Class Initialized
INFO - 2018-02-06 07:44:49 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:44:49 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:44:49 --> Router Class Initialized
INFO - 2018-02-06 07:44:49 --> Utf8 Class Initialized
INFO - 2018-02-06 07:44:49 --> Output Class Initialized
INFO - 2018-02-06 07:44:49 --> URI Class Initialized
INFO - 2018-02-06 07:44:49 --> Output Class Initialized
INFO - 2018-02-06 07:44:49 --> Security Class Initialized
DEBUG - 2018-02-06 07:44:49 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:44:49 --> Router Class Initialized
INFO - 2018-02-06 07:44:49 --> Utf8 Class Initialized
INFO - 2018-02-06 07:44:49 --> Security Class Initialized
DEBUG - 2018-02-06 07:44:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:44:49 --> Input Class Initialized
INFO - 2018-02-06 07:44:49 --> URI Class Initialized
DEBUG - 2018-02-06 07:44:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:44:49 --> Language Class Initialized
INFO - 2018-02-06 07:44:49 --> Input Class Initialized
INFO - 2018-02-06 07:44:49 --> Output Class Initialized
INFO - 2018-02-06 07:44:49 --> Language Class Initialized
INFO - 2018-02-06 07:44:49 --> Router Class Initialized
ERROR - 2018-02-06 07:44:49 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:44:49 --> Security Class Initialized
ERROR - 2018-02-06 07:44:49 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-02-06 07:44:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:44:49 --> Output Class Initialized
INFO - 2018-02-06 07:44:49 --> Input Class Initialized
INFO - 2018-02-06 07:44:49 --> Language Class Initialized
INFO - 2018-02-06 07:44:49 --> Security Class Initialized
ERROR - 2018-02-06 07:44:49 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-02-06 07:44:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:44:49 --> Input Class Initialized
INFO - 2018-02-06 07:44:49 --> Language Class Initialized
ERROR - 2018-02-06 07:44:49 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:44:49 --> Config Class Initialized
INFO - 2018-02-06 07:44:49 --> Hooks Class Initialized
INFO - 2018-02-06 07:44:49 --> Config Class Initialized
INFO - 2018-02-06 07:44:49 --> Hooks Class Initialized
INFO - 2018-02-06 07:44:49 --> Config Class Initialized
INFO - 2018-02-06 07:44:49 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:44:49 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:44:49 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:44:49 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:44:49 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:44:49 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:44:49 --> Utf8 Class Initialized
INFO - 2018-02-06 07:44:49 --> URI Class Initialized
INFO - 2018-02-06 07:44:49 --> URI Class Initialized
INFO - 2018-02-06 07:44:49 --> URI Class Initialized
INFO - 2018-02-06 07:44:49 --> Router Class Initialized
INFO - 2018-02-06 07:44:49 --> Router Class Initialized
INFO - 2018-02-06 07:44:49 --> Router Class Initialized
INFO - 2018-02-06 07:44:49 --> Output Class Initialized
INFO - 2018-02-06 07:44:49 --> Output Class Initialized
INFO - 2018-02-06 07:44:49 --> Output Class Initialized
INFO - 2018-02-06 07:44:49 --> Security Class Initialized
INFO - 2018-02-06 07:44:49 --> Security Class Initialized
INFO - 2018-02-06 07:44:49 --> Security Class Initialized
DEBUG - 2018-02-06 07:44:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:44:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:44:49 --> Input Class Initialized
INFO - 2018-02-06 07:44:49 --> Input Class Initialized
DEBUG - 2018-02-06 07:44:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:44:49 --> Language Class Initialized
INFO - 2018-02-06 07:44:49 --> Language Class Initialized
INFO - 2018-02-06 07:44:49 --> Input Class Initialized
INFO - 2018-02-06 07:44:49 --> Language Class Initialized
ERROR - 2018-02-06 07:44:49 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-06 07:44:49 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-06 07:44:49 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-06 07:44:53 --> Config Class Initialized
INFO - 2018-02-06 07:44:53 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:44:53 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:44:53 --> Utf8 Class Initialized
INFO - 2018-02-06 07:44:53 --> URI Class Initialized
INFO - 2018-02-06 07:44:53 --> Router Class Initialized
INFO - 2018-02-06 07:44:53 --> Output Class Initialized
INFO - 2018-02-06 07:44:53 --> Security Class Initialized
DEBUG - 2018-02-06 07:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:44:53 --> Input Class Initialized
INFO - 2018-02-06 07:44:53 --> Language Class Initialized
INFO - 2018-02-06 07:44:53 --> Loader Class Initialized
INFO - 2018-02-06 07:44:53 --> Helper loaded: url_helper
INFO - 2018-02-06 07:44:53 --> Helper loaded: form_helper
INFO - 2018-02-06 07:44:53 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:44:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:44:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:44:53 --> Form Validation Class Initialized
INFO - 2018-02-06 07:44:53 --> Model Class Initialized
INFO - 2018-02-06 07:44:53 --> Controller Class Initialized
INFO - 2018-02-06 07:44:53 --> Model Class Initialized
DEBUG - 2018-02-06 07:44:53 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:44:53 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:44:53 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:44:53 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:44:53 --> Final output sent to browser
DEBUG - 2018-02-06 07:44:53 --> Total execution time: 0.0574
INFO - 2018-02-06 07:44:53 --> Config Class Initialized
INFO - 2018-02-06 07:44:53 --> Config Class Initialized
INFO - 2018-02-06 07:44:53 --> Config Class Initialized
INFO - 2018-02-06 07:44:53 --> Hooks Class Initialized
INFO - 2018-02-06 07:44:53 --> Hooks Class Initialized
INFO - 2018-02-06 07:44:53 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:44:53 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:44:53 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:44:53 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:44:53 --> Utf8 Class Initialized
INFO - 2018-02-06 07:44:53 --> Utf8 Class Initialized
INFO - 2018-02-06 07:44:53 --> Utf8 Class Initialized
INFO - 2018-02-06 07:44:53 --> Config Class Initialized
INFO - 2018-02-06 07:44:53 --> Hooks Class Initialized
INFO - 2018-02-06 07:44:53 --> URI Class Initialized
INFO - 2018-02-06 07:44:53 --> URI Class Initialized
INFO - 2018-02-06 07:44:53 --> URI Class Initialized
INFO - 2018-02-06 07:44:53 --> Router Class Initialized
INFO - 2018-02-06 07:44:53 --> Router Class Initialized
INFO - 2018-02-06 07:44:53 --> Router Class Initialized
DEBUG - 2018-02-06 07:44:53 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:44:53 --> Utf8 Class Initialized
INFO - 2018-02-06 07:44:53 --> Output Class Initialized
INFO - 2018-02-06 07:44:53 --> URI Class Initialized
INFO - 2018-02-06 07:44:53 --> Output Class Initialized
INFO - 2018-02-06 07:44:53 --> Output Class Initialized
INFO - 2018-02-06 07:44:53 --> Security Class Initialized
INFO - 2018-02-06 07:44:53 --> Security Class Initialized
INFO - 2018-02-06 07:44:53 --> Router Class Initialized
INFO - 2018-02-06 07:44:53 --> Security Class Initialized
DEBUG - 2018-02-06 07:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:44:53 --> Input Class Initialized
DEBUG - 2018-02-06 07:44:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:44:53 --> Input Class Initialized
INFO - 2018-02-06 07:44:53 --> Input Class Initialized
INFO - 2018-02-06 07:44:53 --> Language Class Initialized
INFO - 2018-02-06 07:44:53 --> Output Class Initialized
INFO - 2018-02-06 07:44:53 --> Language Class Initialized
INFO - 2018-02-06 07:44:53 --> Language Class Initialized
INFO - 2018-02-06 07:44:53 --> Security Class Initialized
ERROR - 2018-02-06 07:44:53 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-06 07:44:53 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-06 07:44:53 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-02-06 07:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:44:53 --> Input Class Initialized
INFO - 2018-02-06 07:44:53 --> Language Class Initialized
ERROR - 2018-02-06 07:44:53 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:44:53 --> Config Class Initialized
INFO - 2018-02-06 07:44:53 --> Config Class Initialized
INFO - 2018-02-06 07:44:53 --> Config Class Initialized
INFO - 2018-02-06 07:44:53 --> Hooks Class Initialized
INFO - 2018-02-06 07:44:53 --> Hooks Class Initialized
INFO - 2018-02-06 07:44:53 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:44:53 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:44:53 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:44:53 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:44:53 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:44:53 --> Utf8 Class Initialized
INFO - 2018-02-06 07:44:53 --> Utf8 Class Initialized
INFO - 2018-02-06 07:44:53 --> URI Class Initialized
INFO - 2018-02-06 07:44:53 --> URI Class Initialized
INFO - 2018-02-06 07:44:53 --> URI Class Initialized
INFO - 2018-02-06 07:44:53 --> Router Class Initialized
INFO - 2018-02-06 07:44:53 --> Router Class Initialized
INFO - 2018-02-06 07:44:53 --> Router Class Initialized
INFO - 2018-02-06 07:44:53 --> Output Class Initialized
INFO - 2018-02-06 07:44:53 --> Output Class Initialized
INFO - 2018-02-06 07:44:53 --> Output Class Initialized
INFO - 2018-02-06 07:44:53 --> Security Class Initialized
INFO - 2018-02-06 07:44:53 --> Security Class Initialized
INFO - 2018-02-06 07:44:53 --> Security Class Initialized
DEBUG - 2018-02-06 07:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:44:53 --> Input Class Initialized
DEBUG - 2018-02-06 07:44:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:44:53 --> Input Class Initialized
INFO - 2018-02-06 07:44:53 --> Language Class Initialized
INFO - 2018-02-06 07:44:53 --> Input Class Initialized
INFO - 2018-02-06 07:44:53 --> Language Class Initialized
INFO - 2018-02-06 07:44:53 --> Language Class Initialized
ERROR - 2018-02-06 07:44:53 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-06 07:44:53 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-06 07:44:53 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-06 07:44:53 --> Config Class Initialized
INFO - 2018-02-06 07:44:53 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:44:53 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:44:53 --> Utf8 Class Initialized
INFO - 2018-02-06 07:44:53 --> URI Class Initialized
INFO - 2018-02-06 07:44:53 --> Router Class Initialized
INFO - 2018-02-06 07:44:53 --> Output Class Initialized
INFO - 2018-02-06 07:44:53 --> Security Class Initialized
DEBUG - 2018-02-06 07:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:44:53 --> Input Class Initialized
INFO - 2018-02-06 07:44:53 --> Language Class Initialized
INFO - 2018-02-06 07:44:53 --> Loader Class Initialized
INFO - 2018-02-06 07:44:53 --> Helper loaded: url_helper
INFO - 2018-02-06 07:44:53 --> Helper loaded: form_helper
INFO - 2018-02-06 07:44:53 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:44:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:44:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:44:53 --> Form Validation Class Initialized
INFO - 2018-02-06 07:44:53 --> Model Class Initialized
INFO - 2018-02-06 07:44:53 --> Controller Class Initialized
INFO - 2018-02-06 07:44:53 --> Model Class Initialized
DEBUG - 2018-02-06 07:44:53 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:44:53 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:44:53 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:44:53 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:44:53 --> Final output sent to browser
DEBUG - 2018-02-06 07:44:53 --> Total execution time: 0.0487
INFO - 2018-02-06 07:44:53 --> Config Class Initialized
INFO - 2018-02-06 07:44:53 --> Hooks Class Initialized
INFO - 2018-02-06 07:44:53 --> Config Class Initialized
INFO - 2018-02-06 07:44:53 --> Config Class Initialized
INFO - 2018-02-06 07:44:53 --> Hooks Class Initialized
INFO - 2018-02-06 07:44:53 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:44:53 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:44:53 --> Utf8 Class Initialized
INFO - 2018-02-06 07:44:53 --> URI Class Initialized
DEBUG - 2018-02-06 07:44:53 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:44:53 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:44:53 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:44:53 --> Utf8 Class Initialized
INFO - 2018-02-06 07:44:53 --> Router Class Initialized
INFO - 2018-02-06 07:44:53 --> Config Class Initialized
INFO - 2018-02-06 07:44:53 --> URI Class Initialized
INFO - 2018-02-06 07:44:53 --> Hooks Class Initialized
INFO - 2018-02-06 07:44:53 --> URI Class Initialized
INFO - 2018-02-06 07:44:53 --> Output Class Initialized
INFO - 2018-02-06 07:44:53 --> Router Class Initialized
INFO - 2018-02-06 07:44:53 --> Router Class Initialized
DEBUG - 2018-02-06 07:44:53 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:44:54 --> Security Class Initialized
INFO - 2018-02-06 07:44:54 --> Utf8 Class Initialized
INFO - 2018-02-06 07:44:54 --> Output Class Initialized
INFO - 2018-02-06 07:44:54 --> Output Class Initialized
INFO - 2018-02-06 07:44:54 --> URI Class Initialized
DEBUG - 2018-02-06 07:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:44:54 --> Input Class Initialized
INFO - 2018-02-06 07:44:54 --> Security Class Initialized
INFO - 2018-02-06 07:44:54 --> Security Class Initialized
INFO - 2018-02-06 07:44:54 --> Language Class Initialized
INFO - 2018-02-06 07:44:54 --> Router Class Initialized
DEBUG - 2018-02-06 07:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:44:54 --> Input Class Initialized
DEBUG - 2018-02-06 07:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:44:54 --> Input Class Initialized
ERROR - 2018-02-06 07:44:54 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:44:54 --> Language Class Initialized
INFO - 2018-02-06 07:44:54 --> Language Class Initialized
INFO - 2018-02-06 07:44:54 --> Output Class Initialized
ERROR - 2018-02-06 07:44:54 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-06 07:44:54 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:44:54 --> Security Class Initialized
DEBUG - 2018-02-06 07:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:44:54 --> Input Class Initialized
INFO - 2018-02-06 07:44:54 --> Language Class Initialized
ERROR - 2018-02-06 07:44:54 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:44:54 --> Config Class Initialized
INFO - 2018-02-06 07:44:54 --> Hooks Class Initialized
INFO - 2018-02-06 07:44:54 --> Config Class Initialized
INFO - 2018-02-06 07:44:54 --> Hooks Class Initialized
INFO - 2018-02-06 07:44:54 --> Config Class Initialized
INFO - 2018-02-06 07:44:54 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:44:54 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:44:54 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:44:54 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:44:54 --> URI Class Initialized
INFO - 2018-02-06 07:44:54 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:44:54 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:44:54 --> Utf8 Class Initialized
INFO - 2018-02-06 07:44:54 --> URI Class Initialized
INFO - 2018-02-06 07:44:54 --> Router Class Initialized
INFO - 2018-02-06 07:44:54 --> URI Class Initialized
INFO - 2018-02-06 07:44:54 --> Router Class Initialized
INFO - 2018-02-06 07:44:54 --> Output Class Initialized
INFO - 2018-02-06 07:44:54 --> Router Class Initialized
INFO - 2018-02-06 07:44:54 --> Output Class Initialized
INFO - 2018-02-06 07:44:54 --> Security Class Initialized
INFO - 2018-02-06 07:44:54 --> Output Class Initialized
INFO - 2018-02-06 07:44:54 --> Security Class Initialized
DEBUG - 2018-02-06 07:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:44:54 --> Input Class Initialized
INFO - 2018-02-06 07:44:54 --> Security Class Initialized
INFO - 2018-02-06 07:44:54 --> Language Class Initialized
DEBUG - 2018-02-06 07:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:44:54 --> Input Class Initialized
DEBUG - 2018-02-06 07:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:44:54 --> Input Class Initialized
INFO - 2018-02-06 07:44:54 --> Language Class Initialized
ERROR - 2018-02-06 07:44:54 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-06 07:44:54 --> Language Class Initialized
ERROR - 2018-02-06 07:44:54 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-06 07:44:54 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-06 07:44:54 --> Config Class Initialized
INFO - 2018-02-06 07:44:54 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:44:54 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:44:54 --> Utf8 Class Initialized
INFO - 2018-02-06 07:44:54 --> URI Class Initialized
INFO - 2018-02-06 07:44:54 --> Router Class Initialized
INFO - 2018-02-06 07:44:54 --> Output Class Initialized
INFO - 2018-02-06 07:44:54 --> Security Class Initialized
DEBUG - 2018-02-06 07:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:44:54 --> Input Class Initialized
INFO - 2018-02-06 07:44:54 --> Language Class Initialized
INFO - 2018-02-06 07:44:54 --> Loader Class Initialized
INFO - 2018-02-06 07:44:54 --> Helper loaded: url_helper
INFO - 2018-02-06 07:44:54 --> Helper loaded: form_helper
INFO - 2018-02-06 07:44:54 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:44:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:44:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:44:54 --> Form Validation Class Initialized
INFO - 2018-02-06 07:44:54 --> Model Class Initialized
INFO - 2018-02-06 07:44:54 --> Controller Class Initialized
INFO - 2018-02-06 07:44:54 --> Model Class Initialized
DEBUG - 2018-02-06 07:44:54 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:44:54 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:44:54 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:44:54 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:44:54 --> Final output sent to browser
DEBUG - 2018-02-06 07:44:54 --> Total execution time: 0.0582
INFO - 2018-02-06 07:44:54 --> Config Class Initialized
INFO - 2018-02-06 07:44:54 --> Config Class Initialized
INFO - 2018-02-06 07:44:54 --> Hooks Class Initialized
INFO - 2018-02-06 07:44:54 --> Hooks Class Initialized
INFO - 2018-02-06 07:44:54 --> Config Class Initialized
INFO - 2018-02-06 07:44:54 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:44:54 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:44:54 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:44:54 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:44:54 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:44:54 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:44:54 --> Utf8 Class Initialized
INFO - 2018-02-06 07:44:54 --> URI Class Initialized
INFO - 2018-02-06 07:44:54 --> URI Class Initialized
INFO - 2018-02-06 07:44:54 --> URI Class Initialized
INFO - 2018-02-06 07:44:54 --> Config Class Initialized
INFO - 2018-02-06 07:44:54 --> Hooks Class Initialized
INFO - 2018-02-06 07:44:54 --> Router Class Initialized
INFO - 2018-02-06 07:44:54 --> Router Class Initialized
INFO - 2018-02-06 07:44:54 --> Router Class Initialized
INFO - 2018-02-06 07:44:54 --> Output Class Initialized
DEBUG - 2018-02-06 07:44:54 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:44:54 --> Output Class Initialized
INFO - 2018-02-06 07:44:54 --> Utf8 Class Initialized
INFO - 2018-02-06 07:44:54 --> Output Class Initialized
INFO - 2018-02-06 07:44:54 --> Security Class Initialized
INFO - 2018-02-06 07:44:54 --> Security Class Initialized
INFO - 2018-02-06 07:44:54 --> URI Class Initialized
INFO - 2018-02-06 07:44:54 --> Security Class Initialized
DEBUG - 2018-02-06 07:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:44:54 --> Input Class Initialized
INFO - 2018-02-06 07:44:54 --> Language Class Initialized
INFO - 2018-02-06 07:44:54 --> Router Class Initialized
DEBUG - 2018-02-06 07:44:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:44:54 --> Input Class Initialized
INFO - 2018-02-06 07:44:54 --> Input Class Initialized
ERROR - 2018-02-06 07:44:54 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:44:54 --> Language Class Initialized
INFO - 2018-02-06 07:44:54 --> Language Class Initialized
INFO - 2018-02-06 07:44:54 --> Output Class Initialized
ERROR - 2018-02-06 07:44:54 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:44:54 --> Security Class Initialized
ERROR - 2018-02-06 07:44:54 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-02-06 07:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:44:54 --> Input Class Initialized
INFO - 2018-02-06 07:44:54 --> Language Class Initialized
ERROR - 2018-02-06 07:44:54 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:44:54 --> Config Class Initialized
INFO - 2018-02-06 07:44:54 --> Hooks Class Initialized
INFO - 2018-02-06 07:44:54 --> Config Class Initialized
INFO - 2018-02-06 07:44:54 --> Hooks Class Initialized
INFO - 2018-02-06 07:44:54 --> Config Class Initialized
INFO - 2018-02-06 07:44:54 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:44:54 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:44:54 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:44:54 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:44:54 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:44:54 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:44:54 --> URI Class Initialized
INFO - 2018-02-06 07:44:54 --> Utf8 Class Initialized
INFO - 2018-02-06 07:44:54 --> URI Class Initialized
INFO - 2018-02-06 07:44:54 --> URI Class Initialized
INFO - 2018-02-06 07:44:54 --> Router Class Initialized
INFO - 2018-02-06 07:44:54 --> Router Class Initialized
INFO - 2018-02-06 07:44:54 --> Router Class Initialized
INFO - 2018-02-06 07:44:54 --> Output Class Initialized
INFO - 2018-02-06 07:44:54 --> Output Class Initialized
INFO - 2018-02-06 07:44:54 --> Security Class Initialized
INFO - 2018-02-06 07:44:54 --> Output Class Initialized
INFO - 2018-02-06 07:44:54 --> Security Class Initialized
DEBUG - 2018-02-06 07:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:44:54 --> Input Class Initialized
INFO - 2018-02-06 07:44:54 --> Language Class Initialized
INFO - 2018-02-06 07:44:54 --> Security Class Initialized
DEBUG - 2018-02-06 07:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:44:54 --> Input Class Initialized
INFO - 2018-02-06 07:44:54 --> Language Class Initialized
ERROR - 2018-02-06 07:44:54 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-02-06 07:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:44:54 --> Input Class Initialized
ERROR - 2018-02-06 07:44:54 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-06 07:44:54 --> Language Class Initialized
ERROR - 2018-02-06 07:44:54 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-06 07:44:54 --> Config Class Initialized
INFO - 2018-02-06 07:44:54 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:44:54 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:44:54 --> Utf8 Class Initialized
INFO - 2018-02-06 07:44:54 --> URI Class Initialized
INFO - 2018-02-06 07:44:54 --> Router Class Initialized
INFO - 2018-02-06 07:44:54 --> Output Class Initialized
INFO - 2018-02-06 07:44:54 --> Security Class Initialized
DEBUG - 2018-02-06 07:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:44:54 --> Input Class Initialized
INFO - 2018-02-06 07:44:54 --> Language Class Initialized
INFO - 2018-02-06 07:44:54 --> Loader Class Initialized
INFO - 2018-02-06 07:44:54 --> Helper loaded: url_helper
INFO - 2018-02-06 07:44:54 --> Helper loaded: form_helper
INFO - 2018-02-06 07:44:54 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:44:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:44:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:44:54 --> Form Validation Class Initialized
INFO - 2018-02-06 07:44:54 --> Model Class Initialized
INFO - 2018-02-06 07:44:54 --> Controller Class Initialized
INFO - 2018-02-06 07:44:54 --> Model Class Initialized
DEBUG - 2018-02-06 07:44:54 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:44:54 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:44:54 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:44:54 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:44:54 --> Final output sent to browser
DEBUG - 2018-02-06 07:44:54 --> Total execution time: 0.0499
INFO - 2018-02-06 07:44:54 --> Config Class Initialized
INFO - 2018-02-06 07:44:54 --> Config Class Initialized
INFO - 2018-02-06 07:44:54 --> Hooks Class Initialized
INFO - 2018-02-06 07:44:54 --> Hooks Class Initialized
INFO - 2018-02-06 07:44:54 --> Config Class Initialized
INFO - 2018-02-06 07:44:54 --> Hooks Class Initialized
INFO - 2018-02-06 07:44:54 --> Config Class Initialized
DEBUG - 2018-02-06 07:44:54 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:44:54 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:44:54 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:44:54 --> Utf8 Class Initialized
INFO - 2018-02-06 07:44:54 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:44:54 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:44:54 --> Utf8 Class Initialized
INFO - 2018-02-06 07:44:54 --> URI Class Initialized
INFO - 2018-02-06 07:44:54 --> URI Class Initialized
INFO - 2018-02-06 07:44:54 --> URI Class Initialized
DEBUG - 2018-02-06 07:44:54 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:44:54 --> Utf8 Class Initialized
INFO - 2018-02-06 07:44:54 --> Router Class Initialized
INFO - 2018-02-06 07:44:54 --> Router Class Initialized
INFO - 2018-02-06 07:44:54 --> Router Class Initialized
INFO - 2018-02-06 07:44:54 --> Output Class Initialized
INFO - 2018-02-06 07:44:54 --> URI Class Initialized
INFO - 2018-02-06 07:44:54 --> Config Class Initialized
INFO - 2018-02-06 07:44:54 --> Hooks Class Initialized
INFO - 2018-02-06 07:44:54 --> Output Class Initialized
INFO - 2018-02-06 07:44:54 --> Output Class Initialized
INFO - 2018-02-06 07:44:54 --> Security Class Initialized
INFO - 2018-02-06 07:44:54 --> Config Class Initialized
INFO - 2018-02-06 07:44:54 --> Router Class Initialized
INFO - 2018-02-06 07:44:54 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:44:54 --> Security Class Initialized
INFO - 2018-02-06 07:44:54 --> Input Class Initialized
INFO - 2018-02-06 07:44:54 --> Security Class Initialized
DEBUG - 2018-02-06 07:44:54 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:44:54 --> Output Class Initialized
INFO - 2018-02-06 07:44:54 --> Utf8 Class Initialized
INFO - 2018-02-06 07:44:54 --> Language Class Initialized
DEBUG - 2018-02-06 07:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:44:54 --> Input Class Initialized
DEBUG - 2018-02-06 07:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:44:54 --> URI Class Initialized
INFO - 2018-02-06 07:44:54 --> Input Class Initialized
INFO - 2018-02-06 07:44:54 --> Security Class Initialized
DEBUG - 2018-02-06 07:44:54 --> UTF-8 Support Enabled
ERROR - 2018-02-06 07:44:54 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:44:54 --> Language Class Initialized
INFO - 2018-02-06 07:44:54 --> Utf8 Class Initialized
INFO - 2018-02-06 07:44:54 --> Language Class Initialized
DEBUG - 2018-02-06 07:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:44:54 --> Input Class Initialized
INFO - 2018-02-06 07:44:54 --> Router Class Initialized
INFO - 2018-02-06 07:44:54 --> URI Class Initialized
ERROR - 2018-02-06 07:44:54 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-06 07:44:54 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:44:54 --> Language Class Initialized
INFO - 2018-02-06 07:44:54 --> Output Class Initialized
INFO - 2018-02-06 07:44:54 --> Router Class Initialized
ERROR - 2018-02-06 07:44:54 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:44:54 --> Security Class Initialized
INFO - 2018-02-06 07:44:54 --> Output Class Initialized
DEBUG - 2018-02-06 07:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:44:54 --> Input Class Initialized
INFO - 2018-02-06 07:44:54 --> Security Class Initialized
INFO - 2018-02-06 07:44:54 --> Language Class Initialized
DEBUG - 2018-02-06 07:44:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-06 07:44:55 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-06 07:44:55 --> Input Class Initialized
INFO - 2018-02-06 07:44:55 --> Config Class Initialized
INFO - 2018-02-06 07:44:55 --> Hooks Class Initialized
INFO - 2018-02-06 07:44:55 --> Language Class Initialized
ERROR - 2018-02-06 07:44:55 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-02-06 07:44:55 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:44:55 --> Utf8 Class Initialized
INFO - 2018-02-06 07:44:55 --> URI Class Initialized
INFO - 2018-02-06 07:44:55 --> Router Class Initialized
INFO - 2018-02-06 07:44:55 --> Output Class Initialized
INFO - 2018-02-06 07:44:55 --> Security Class Initialized
DEBUG - 2018-02-06 07:44:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:44:55 --> Input Class Initialized
INFO - 2018-02-06 07:44:55 --> Language Class Initialized
ERROR - 2018-02-06 07:44:55 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-06 07:45:12 --> Config Class Initialized
INFO - 2018-02-06 07:45:12 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:45:12 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:45:12 --> Utf8 Class Initialized
INFO - 2018-02-06 07:45:12 --> URI Class Initialized
INFO - 2018-02-06 07:45:12 --> Router Class Initialized
INFO - 2018-02-06 07:45:12 --> Output Class Initialized
INFO - 2018-02-06 07:45:12 --> Security Class Initialized
DEBUG - 2018-02-06 07:45:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:45:12 --> Input Class Initialized
INFO - 2018-02-06 07:45:12 --> Language Class Initialized
INFO - 2018-02-06 07:45:12 --> Loader Class Initialized
INFO - 2018-02-06 07:45:12 --> Helper loaded: url_helper
INFO - 2018-02-06 07:45:12 --> Helper loaded: form_helper
INFO - 2018-02-06 07:45:12 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:45:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:45:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:45:12 --> Form Validation Class Initialized
INFO - 2018-02-06 07:45:12 --> Model Class Initialized
INFO - 2018-02-06 07:45:12 --> Controller Class Initialized
INFO - 2018-02-06 07:45:12 --> Model Class Initialized
DEBUG - 2018-02-06 07:45:12 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:45:12 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:45:12 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:45:12 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:45:12 --> Final output sent to browser
DEBUG - 2018-02-06 07:45:12 --> Total execution time: 0.0609
INFO - 2018-02-06 07:45:12 --> Config Class Initialized
INFO - 2018-02-06 07:45:12 --> Hooks Class Initialized
INFO - 2018-02-06 07:45:12 --> Config Class Initialized
INFO - 2018-02-06 07:45:12 --> Hooks Class Initialized
INFO - 2018-02-06 07:45:12 --> Config Class Initialized
INFO - 2018-02-06 07:45:12 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:45:12 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:45:12 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:45:12 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:45:12 --> Config Class Initialized
INFO - 2018-02-06 07:45:12 --> Utf8 Class Initialized
INFO - 2018-02-06 07:45:12 --> Hooks Class Initialized
INFO - 2018-02-06 07:45:12 --> URI Class Initialized
INFO - 2018-02-06 07:45:12 --> URI Class Initialized
DEBUG - 2018-02-06 07:45:12 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:45:12 --> Utf8 Class Initialized
INFO - 2018-02-06 07:45:12 --> Router Class Initialized
DEBUG - 2018-02-06 07:45:12 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:45:12 --> Utf8 Class Initialized
INFO - 2018-02-06 07:45:12 --> Router Class Initialized
INFO - 2018-02-06 07:45:12 --> URI Class Initialized
INFO - 2018-02-06 07:45:12 --> URI Class Initialized
INFO - 2018-02-06 07:45:12 --> Output Class Initialized
INFO - 2018-02-06 07:45:12 --> Output Class Initialized
INFO - 2018-02-06 07:45:12 --> Router Class Initialized
INFO - 2018-02-06 07:45:12 --> Security Class Initialized
INFO - 2018-02-06 07:45:12 --> Router Class Initialized
INFO - 2018-02-06 07:45:12 --> Security Class Initialized
DEBUG - 2018-02-06 07:45:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:45:12 --> Input Class Initialized
DEBUG - 2018-02-06 07:45:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:45:12 --> Output Class Initialized
INFO - 2018-02-06 07:45:12 --> Input Class Initialized
INFO - 2018-02-06 07:45:12 --> Output Class Initialized
INFO - 2018-02-06 07:45:12 --> Language Class Initialized
INFO - 2018-02-06 07:45:12 --> Language Class Initialized
INFO - 2018-02-06 07:45:12 --> Security Class Initialized
ERROR - 2018-02-06 07:45:12 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:45:12 --> Security Class Initialized
ERROR - 2018-02-06 07:45:12 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-02-06 07:45:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:45:12 --> Input Class Initialized
DEBUG - 2018-02-06 07:45:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:45:12 --> Input Class Initialized
INFO - 2018-02-06 07:45:12 --> Language Class Initialized
INFO - 2018-02-06 07:45:12 --> Language Class Initialized
ERROR - 2018-02-06 07:45:12 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-06 07:45:12 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:45:12 --> Config Class Initialized
INFO - 2018-02-06 07:45:12 --> Config Class Initialized
INFO - 2018-02-06 07:45:12 --> Hooks Class Initialized
INFO - 2018-02-06 07:45:12 --> Hooks Class Initialized
INFO - 2018-02-06 07:45:12 --> Config Class Initialized
INFO - 2018-02-06 07:45:12 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:45:12 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:45:12 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:45:12 --> Utf8 Class Initialized
INFO - 2018-02-06 07:45:12 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:45:12 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:45:12 --> Utf8 Class Initialized
INFO - 2018-02-06 07:45:12 --> URI Class Initialized
INFO - 2018-02-06 07:45:12 --> URI Class Initialized
INFO - 2018-02-06 07:45:12 --> URI Class Initialized
INFO - 2018-02-06 07:45:12 --> Router Class Initialized
INFO - 2018-02-06 07:45:12 --> Router Class Initialized
INFO - 2018-02-06 07:45:12 --> Router Class Initialized
INFO - 2018-02-06 07:45:12 --> Output Class Initialized
INFO - 2018-02-06 07:45:12 --> Output Class Initialized
INFO - 2018-02-06 07:45:12 --> Output Class Initialized
INFO - 2018-02-06 07:45:12 --> Security Class Initialized
INFO - 2018-02-06 07:45:12 --> Security Class Initialized
INFO - 2018-02-06 07:45:12 --> Security Class Initialized
DEBUG - 2018-02-06 07:45:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:45:12 --> Input Class Initialized
DEBUG - 2018-02-06 07:45:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:45:12 --> Language Class Initialized
INFO - 2018-02-06 07:45:12 --> Input Class Initialized
DEBUG - 2018-02-06 07:45:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:45:12 --> Input Class Initialized
INFO - 2018-02-06 07:45:12 --> Language Class Initialized
INFO - 2018-02-06 07:45:12 --> Language Class Initialized
ERROR - 2018-02-06 07:45:12 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-06 07:45:12 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-06 07:45:12 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-06 07:45:15 --> Config Class Initialized
INFO - 2018-02-06 07:45:15 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:45:15 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:45:15 --> Utf8 Class Initialized
INFO - 2018-02-06 07:45:15 --> URI Class Initialized
INFO - 2018-02-06 07:45:15 --> Router Class Initialized
INFO - 2018-02-06 07:45:15 --> Output Class Initialized
INFO - 2018-02-06 07:45:15 --> Security Class Initialized
DEBUG - 2018-02-06 07:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:45:15 --> Input Class Initialized
INFO - 2018-02-06 07:45:15 --> Language Class Initialized
INFO - 2018-02-06 07:45:15 --> Loader Class Initialized
INFO - 2018-02-06 07:45:15 --> Helper loaded: url_helper
INFO - 2018-02-06 07:45:15 --> Helper loaded: form_helper
INFO - 2018-02-06 07:45:15 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:45:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:45:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:45:15 --> Form Validation Class Initialized
INFO - 2018-02-06 07:45:15 --> Model Class Initialized
INFO - 2018-02-06 07:45:15 --> Controller Class Initialized
INFO - 2018-02-06 07:45:15 --> Model Class Initialized
DEBUG - 2018-02-06 07:45:15 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:45:15 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:45:15 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:45:15 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:45:15 --> Final output sent to browser
DEBUG - 2018-02-06 07:45:15 --> Total execution time: 0.0735
INFO - 2018-02-06 07:45:15 --> Config Class Initialized
INFO - 2018-02-06 07:45:15 --> Hooks Class Initialized
INFO - 2018-02-06 07:45:15 --> Config Class Initialized
INFO - 2018-02-06 07:45:15 --> Config Class Initialized
INFO - 2018-02-06 07:45:15 --> Hooks Class Initialized
INFO - 2018-02-06 07:45:15 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:45:15 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:45:15 --> Utf8 Class Initialized
INFO - 2018-02-06 07:45:15 --> URI Class Initialized
DEBUG - 2018-02-06 07:45:15 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:45:15 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:45:15 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:45:15 --> Utf8 Class Initialized
INFO - 2018-02-06 07:45:15 --> URI Class Initialized
INFO - 2018-02-06 07:45:15 --> Router Class Initialized
INFO - 2018-02-06 07:45:15 --> URI Class Initialized
INFO - 2018-02-06 07:45:15 --> Router Class Initialized
INFO - 2018-02-06 07:45:15 --> Output Class Initialized
INFO - 2018-02-06 07:45:15 --> Router Class Initialized
INFO - 2018-02-06 07:45:15 --> Security Class Initialized
INFO - 2018-02-06 07:45:15 --> Output Class Initialized
INFO - 2018-02-06 07:45:15 --> Output Class Initialized
DEBUG - 2018-02-06 07:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:45:15 --> Security Class Initialized
INFO - 2018-02-06 07:45:15 --> Input Class Initialized
INFO - 2018-02-06 07:45:15 --> Security Class Initialized
INFO - 2018-02-06 07:45:15 --> Language Class Initialized
DEBUG - 2018-02-06 07:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:45:15 --> Input Class Initialized
DEBUG - 2018-02-06 07:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:45:15 --> Input Class Initialized
ERROR - 2018-02-06 07:45:15 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:45:15 --> Language Class Initialized
INFO - 2018-02-06 07:45:15 --> Language Class Initialized
ERROR - 2018-02-06 07:45:15 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-06 07:45:15 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:45:15 --> Config Class Initialized
INFO - 2018-02-06 07:45:15 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:45:15 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:45:15 --> Utf8 Class Initialized
INFO - 2018-02-06 07:45:15 --> URI Class Initialized
INFO - 2018-02-06 07:45:15 --> Router Class Initialized
INFO - 2018-02-06 07:45:15 --> Output Class Initialized
INFO - 2018-02-06 07:45:15 --> Security Class Initialized
DEBUG - 2018-02-06 07:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:45:15 --> Input Class Initialized
INFO - 2018-02-06 07:45:15 --> Language Class Initialized
ERROR - 2018-02-06 07:45:15 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:45:15 --> Config Class Initialized
INFO - 2018-02-06 07:45:15 --> Hooks Class Initialized
INFO - 2018-02-06 07:45:15 --> Config Class Initialized
INFO - 2018-02-06 07:45:15 --> Config Class Initialized
INFO - 2018-02-06 07:45:15 --> Hooks Class Initialized
INFO - 2018-02-06 07:45:15 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:45:15 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:45:15 --> Utf8 Class Initialized
INFO - 2018-02-06 07:45:15 --> URI Class Initialized
DEBUG - 2018-02-06 07:45:15 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:45:15 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:45:15 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:45:15 --> Router Class Initialized
INFO - 2018-02-06 07:45:15 --> URI Class Initialized
INFO - 2018-02-06 07:45:15 --> Utf8 Class Initialized
INFO - 2018-02-06 07:45:15 --> URI Class Initialized
INFO - 2018-02-06 07:45:15 --> Router Class Initialized
INFO - 2018-02-06 07:45:15 --> Output Class Initialized
INFO - 2018-02-06 07:45:15 --> Security Class Initialized
INFO - 2018-02-06 07:45:15 --> Router Class Initialized
INFO - 2018-02-06 07:45:15 --> Output Class Initialized
DEBUG - 2018-02-06 07:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:45:15 --> Input Class Initialized
INFO - 2018-02-06 07:45:15 --> Security Class Initialized
INFO - 2018-02-06 07:45:15 --> Output Class Initialized
INFO - 2018-02-06 07:45:15 --> Language Class Initialized
INFO - 2018-02-06 07:45:15 --> Security Class Initialized
DEBUG - 2018-02-06 07:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:45:15 --> Input Class Initialized
ERROR - 2018-02-06 07:45:15 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-06 07:45:15 --> Language Class Initialized
DEBUG - 2018-02-06 07:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:45:15 --> Input Class Initialized
ERROR - 2018-02-06 07:45:15 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-06 07:45:15 --> Language Class Initialized
ERROR - 2018-02-06 07:45:15 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-06 07:45:19 --> Config Class Initialized
INFO - 2018-02-06 07:45:19 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:45:19 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:45:19 --> Utf8 Class Initialized
INFO - 2018-02-06 07:45:19 --> URI Class Initialized
INFO - 2018-02-06 07:45:19 --> Router Class Initialized
INFO - 2018-02-06 07:45:19 --> Output Class Initialized
INFO - 2018-02-06 07:45:19 --> Security Class Initialized
DEBUG - 2018-02-06 07:45:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:45:19 --> Input Class Initialized
INFO - 2018-02-06 07:45:19 --> Language Class Initialized
INFO - 2018-02-06 07:45:19 --> Loader Class Initialized
INFO - 2018-02-06 07:45:19 --> Helper loaded: url_helper
INFO - 2018-02-06 07:45:19 --> Helper loaded: form_helper
INFO - 2018-02-06 07:45:20 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:45:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:45:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:45:20 --> Form Validation Class Initialized
INFO - 2018-02-06 07:45:20 --> Model Class Initialized
INFO - 2018-02-06 07:45:20 --> Controller Class Initialized
INFO - 2018-02-06 07:45:20 --> Model Class Initialized
DEBUG - 2018-02-06 07:45:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:45:20 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:45:20 --> Final output sent to browser
DEBUG - 2018-02-06 07:45:20 --> Total execution time: 0.0397
INFO - 2018-02-06 07:45:20 --> Config Class Initialized
INFO - 2018-02-06 07:45:20 --> Hooks Class Initialized
INFO - 2018-02-06 07:45:20 --> Config Class Initialized
INFO - 2018-02-06 07:45:20 --> Hooks Class Initialized
INFO - 2018-02-06 07:45:20 --> Config Class Initialized
DEBUG - 2018-02-06 07:45:20 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:45:20 --> Hooks Class Initialized
INFO - 2018-02-06 07:45:20 --> Utf8 Class Initialized
INFO - 2018-02-06 07:45:20 --> URI Class Initialized
INFO - 2018-02-06 07:45:20 --> Config Class Initialized
INFO - 2018-02-06 07:45:20 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:45:20 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:45:20 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:45:20 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:45:20 --> Router Class Initialized
INFO - 2018-02-06 07:45:20 --> Utf8 Class Initialized
INFO - 2018-02-06 07:45:20 --> URI Class Initialized
INFO - 2018-02-06 07:45:20 --> URI Class Initialized
INFO - 2018-02-06 07:45:20 --> Output Class Initialized
DEBUG - 2018-02-06 07:45:20 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:45:20 --> Utf8 Class Initialized
INFO - 2018-02-06 07:45:20 --> Router Class Initialized
INFO - 2018-02-06 07:45:20 --> Router Class Initialized
INFO - 2018-02-06 07:45:20 --> Security Class Initialized
INFO - 2018-02-06 07:45:20 --> URI Class Initialized
INFO - 2018-02-06 07:45:20 --> Output Class Initialized
INFO - 2018-02-06 07:45:20 --> Output Class Initialized
DEBUG - 2018-02-06 07:45:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:45:20 --> Input Class Initialized
INFO - 2018-02-06 07:45:20 --> Router Class Initialized
INFO - 2018-02-06 07:45:20 --> Security Class Initialized
INFO - 2018-02-06 07:45:20 --> Security Class Initialized
INFO - 2018-02-06 07:45:20 --> Language Class Initialized
INFO - 2018-02-06 07:45:20 --> Output Class Initialized
DEBUG - 2018-02-06 07:45:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:45:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:45:20 --> Input Class Initialized
ERROR - 2018-02-06 07:45:20 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:45:20 --> Input Class Initialized
INFO - 2018-02-06 07:45:20 --> Language Class Initialized
INFO - 2018-02-06 07:45:20 --> Security Class Initialized
INFO - 2018-02-06 07:45:20 --> Language Class Initialized
DEBUG - 2018-02-06 07:45:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-06 07:45:20 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-06 07:45:20 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:45:20 --> Input Class Initialized
INFO - 2018-02-06 07:45:20 --> Language Class Initialized
ERROR - 2018-02-06 07:45:20 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:45:20 --> Config Class Initialized
INFO - 2018-02-06 07:45:20 --> Hooks Class Initialized
INFO - 2018-02-06 07:45:20 --> Config Class Initialized
INFO - 2018-02-06 07:45:20 --> Config Class Initialized
INFO - 2018-02-06 07:45:20 --> Hooks Class Initialized
INFO - 2018-02-06 07:45:20 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:45:20 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:45:20 --> Utf8 Class Initialized
INFO - 2018-02-06 07:45:20 --> URI Class Initialized
DEBUG - 2018-02-06 07:45:20 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:45:20 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:45:20 --> Utf8 Class Initialized
INFO - 2018-02-06 07:45:20 --> Utf8 Class Initialized
INFO - 2018-02-06 07:45:20 --> Router Class Initialized
INFO - 2018-02-06 07:45:20 --> URI Class Initialized
INFO - 2018-02-06 07:45:20 --> URI Class Initialized
INFO - 2018-02-06 07:45:20 --> Output Class Initialized
INFO - 2018-02-06 07:45:20 --> Router Class Initialized
INFO - 2018-02-06 07:45:20 --> Router Class Initialized
INFO - 2018-02-06 07:45:20 --> Security Class Initialized
INFO - 2018-02-06 07:45:20 --> Output Class Initialized
INFO - 2018-02-06 07:45:20 --> Output Class Initialized
DEBUG - 2018-02-06 07:45:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:45:20 --> Input Class Initialized
INFO - 2018-02-06 07:45:20 --> Security Class Initialized
INFO - 2018-02-06 07:45:20 --> Language Class Initialized
INFO - 2018-02-06 07:45:20 --> Security Class Initialized
DEBUG - 2018-02-06 07:45:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:45:20 --> Input Class Initialized
ERROR - 2018-02-06 07:45:20 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-02-06 07:45:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:45:20 --> Input Class Initialized
INFO - 2018-02-06 07:45:20 --> Language Class Initialized
INFO - 2018-02-06 07:45:20 --> Language Class Initialized
ERROR - 2018-02-06 07:45:20 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-06 07:45:20 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-06 07:45:20 --> Config Class Initialized
INFO - 2018-02-06 07:45:20 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:45:20 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:45:20 --> Utf8 Class Initialized
INFO - 2018-02-06 07:45:20 --> URI Class Initialized
INFO - 2018-02-06 07:45:20 --> Router Class Initialized
INFO - 2018-02-06 07:45:20 --> Output Class Initialized
INFO - 2018-02-06 07:45:20 --> Security Class Initialized
DEBUG - 2018-02-06 07:45:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:45:20 --> Input Class Initialized
INFO - 2018-02-06 07:45:20 --> Language Class Initialized
INFO - 2018-02-06 07:45:20 --> Loader Class Initialized
INFO - 2018-02-06 07:45:20 --> Helper loaded: url_helper
INFO - 2018-02-06 07:45:20 --> Helper loaded: form_helper
INFO - 2018-02-06 07:45:20 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:45:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:45:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:45:20 --> Form Validation Class Initialized
INFO - 2018-02-06 07:45:20 --> Model Class Initialized
INFO - 2018-02-06 07:45:20 --> Controller Class Initialized
INFO - 2018-02-06 07:45:20 --> Model Class Initialized
DEBUG - 2018-02-06 07:45:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:45:21 --> Config Class Initialized
INFO - 2018-02-06 07:45:21 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:45:21 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:45:21 --> Utf8 Class Initialized
INFO - 2018-02-06 07:45:21 --> URI Class Initialized
INFO - 2018-02-06 07:45:21 --> Router Class Initialized
INFO - 2018-02-06 07:45:21 --> Output Class Initialized
INFO - 2018-02-06 07:45:21 --> Security Class Initialized
DEBUG - 2018-02-06 07:45:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:45:21 --> Input Class Initialized
INFO - 2018-02-06 07:45:21 --> Language Class Initialized
INFO - 2018-02-06 07:45:21 --> Loader Class Initialized
INFO - 2018-02-06 07:45:21 --> Helper loaded: url_helper
INFO - 2018-02-06 07:45:21 --> Helper loaded: form_helper
INFO - 2018-02-06 07:45:21 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:45:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:45:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:45:21 --> Form Validation Class Initialized
INFO - 2018-02-06 07:45:21 --> Model Class Initialized
INFO - 2018-02-06 07:45:21 --> Controller Class Initialized
INFO - 2018-02-06 07:45:21 --> Model Class Initialized
DEBUG - 2018-02-06 07:45:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:45:21 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:45:21 --> Final output sent to browser
DEBUG - 2018-02-06 07:45:21 --> Total execution time: 0.0516
INFO - 2018-02-06 07:45:21 --> Config Class Initialized
INFO - 2018-02-06 07:45:21 --> Hooks Class Initialized
INFO - 2018-02-06 07:45:21 --> Config Class Initialized
INFO - 2018-02-06 07:45:21 --> Config Class Initialized
INFO - 2018-02-06 07:45:21 --> Hooks Class Initialized
INFO - 2018-02-06 07:45:21 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:45:21 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:45:21 --> Utf8 Class Initialized
INFO - 2018-02-06 07:45:21 --> Config Class Initialized
INFO - 2018-02-06 07:45:21 --> Hooks Class Initialized
INFO - 2018-02-06 07:45:21 --> URI Class Initialized
DEBUG - 2018-02-06 07:45:21 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:45:21 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:45:21 --> Utf8 Class Initialized
INFO - 2018-02-06 07:45:21 --> Utf8 Class Initialized
INFO - 2018-02-06 07:45:21 --> Router Class Initialized
INFO - 2018-02-06 07:45:21 --> URI Class Initialized
DEBUG - 2018-02-06 07:45:21 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:45:21 --> URI Class Initialized
INFO - 2018-02-06 07:45:21 --> Utf8 Class Initialized
INFO - 2018-02-06 07:45:21 --> URI Class Initialized
INFO - 2018-02-06 07:45:21 --> Output Class Initialized
INFO - 2018-02-06 07:45:21 --> Router Class Initialized
INFO - 2018-02-06 07:45:21 --> Router Class Initialized
INFO - 2018-02-06 07:45:21 --> Security Class Initialized
INFO - 2018-02-06 07:45:21 --> Router Class Initialized
INFO - 2018-02-06 07:45:21 --> Output Class Initialized
INFO - 2018-02-06 07:45:21 --> Output Class Initialized
DEBUG - 2018-02-06 07:45:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:45:21 --> Input Class Initialized
INFO - 2018-02-06 07:45:21 --> Output Class Initialized
INFO - 2018-02-06 07:45:21 --> Security Class Initialized
INFO - 2018-02-06 07:45:21 --> Language Class Initialized
INFO - 2018-02-06 07:45:21 --> Security Class Initialized
INFO - 2018-02-06 07:45:21 --> Security Class Initialized
DEBUG - 2018-02-06 07:45:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-06 07:45:21 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:45:21 --> Input Class Initialized
DEBUG - 2018-02-06 07:45:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:45:21 --> Input Class Initialized
DEBUG - 2018-02-06 07:45:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:45:21 --> Language Class Initialized
INFO - 2018-02-06 07:45:21 --> Input Class Initialized
INFO - 2018-02-06 07:45:21 --> Language Class Initialized
INFO - 2018-02-06 07:45:21 --> Language Class Initialized
ERROR - 2018-02-06 07:45:21 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-06 07:45:21 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-06 07:45:21 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:45:21 --> Config Class Initialized
INFO - 2018-02-06 07:45:21 --> Hooks Class Initialized
INFO - 2018-02-06 07:45:21 --> Config Class Initialized
INFO - 2018-02-06 07:45:21 --> Hooks Class Initialized
INFO - 2018-02-06 07:45:21 --> Config Class Initialized
INFO - 2018-02-06 07:45:21 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:45:21 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:45:21 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:45:21 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:45:21 --> Utf8 Class Initialized
INFO - 2018-02-06 07:45:21 --> URI Class Initialized
DEBUG - 2018-02-06 07:45:21 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:45:21 --> URI Class Initialized
INFO - 2018-02-06 07:45:21 --> Utf8 Class Initialized
INFO - 2018-02-06 07:45:21 --> Router Class Initialized
INFO - 2018-02-06 07:45:21 --> URI Class Initialized
INFO - 2018-02-06 07:45:21 --> Router Class Initialized
INFO - 2018-02-06 07:45:21 --> Output Class Initialized
INFO - 2018-02-06 07:45:21 --> Output Class Initialized
INFO - 2018-02-06 07:45:21 --> Router Class Initialized
INFO - 2018-02-06 07:45:21 --> Security Class Initialized
INFO - 2018-02-06 07:45:21 --> Security Class Initialized
INFO - 2018-02-06 07:45:21 --> Output Class Initialized
DEBUG - 2018-02-06 07:45:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:45:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:45:21 --> Input Class Initialized
INFO - 2018-02-06 07:45:21 --> Input Class Initialized
INFO - 2018-02-06 07:45:21 --> Security Class Initialized
INFO - 2018-02-06 07:45:21 --> Language Class Initialized
INFO - 2018-02-06 07:45:21 --> Language Class Initialized
DEBUG - 2018-02-06 07:45:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:45:21 --> Input Class Initialized
ERROR - 2018-02-06 07:45:21 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-06 07:45:21 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-06 07:45:21 --> Language Class Initialized
ERROR - 2018-02-06 07:45:21 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-06 07:45:44 --> Config Class Initialized
INFO - 2018-02-06 07:45:44 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:45:44 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:45:44 --> Utf8 Class Initialized
INFO - 2018-02-06 07:45:44 --> URI Class Initialized
INFO - 2018-02-06 07:45:44 --> Router Class Initialized
INFO - 2018-02-06 07:45:44 --> Output Class Initialized
INFO - 2018-02-06 07:45:44 --> Security Class Initialized
DEBUG - 2018-02-06 07:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:45:44 --> Input Class Initialized
INFO - 2018-02-06 07:45:44 --> Language Class Initialized
INFO - 2018-02-06 07:45:44 --> Loader Class Initialized
INFO - 2018-02-06 07:45:44 --> Helper loaded: url_helper
INFO - 2018-02-06 07:45:44 --> Helper loaded: form_helper
INFO - 2018-02-06 07:45:44 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:45:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:45:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:45:44 --> Form Validation Class Initialized
INFO - 2018-02-06 07:45:44 --> Model Class Initialized
INFO - 2018-02-06 07:45:44 --> Controller Class Initialized
INFO - 2018-02-06 07:45:44 --> Model Class Initialized
DEBUG - 2018-02-06 07:45:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:45:44 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:45:44 --> Final output sent to browser
DEBUG - 2018-02-06 07:45:44 --> Total execution time: 0.0412
INFO - 2018-02-06 07:45:44 --> Config Class Initialized
INFO - 2018-02-06 07:45:44 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:45:44 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:45:44 --> Utf8 Class Initialized
INFO - 2018-02-06 07:45:44 --> URI Class Initialized
INFO - 2018-02-06 07:45:44 --> Router Class Initialized
INFO - 2018-02-06 07:45:44 --> Output Class Initialized
INFO - 2018-02-06 07:45:44 --> Security Class Initialized
DEBUG - 2018-02-06 07:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:45:44 --> Input Class Initialized
INFO - 2018-02-06 07:45:44 --> Language Class Initialized
INFO - 2018-02-06 07:45:44 --> Loader Class Initialized
INFO - 2018-02-06 07:45:44 --> Helper loaded: url_helper
INFO - 2018-02-06 07:45:44 --> Helper loaded: form_helper
INFO - 2018-02-06 07:45:44 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:45:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:45:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:45:44 --> Form Validation Class Initialized
INFO - 2018-02-06 07:45:44 --> Model Class Initialized
INFO - 2018-02-06 07:45:44 --> Controller Class Initialized
INFO - 2018-02-06 07:45:44 --> Model Class Initialized
DEBUG - 2018-02-06 07:45:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:45:46 --> Config Class Initialized
INFO - 2018-02-06 07:45:46 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:45:46 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:45:46 --> Utf8 Class Initialized
INFO - 2018-02-06 07:45:46 --> URI Class Initialized
INFO - 2018-02-06 07:45:46 --> Router Class Initialized
INFO - 2018-02-06 07:45:46 --> Output Class Initialized
INFO - 2018-02-06 07:45:46 --> Security Class Initialized
DEBUG - 2018-02-06 07:45:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:45:46 --> Input Class Initialized
INFO - 2018-02-06 07:45:46 --> Language Class Initialized
INFO - 2018-02-06 07:45:46 --> Loader Class Initialized
INFO - 2018-02-06 07:45:46 --> Helper loaded: url_helper
INFO - 2018-02-06 07:45:46 --> Helper loaded: form_helper
INFO - 2018-02-06 07:45:46 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:45:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:45:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:45:46 --> Form Validation Class Initialized
INFO - 2018-02-06 07:45:46 --> Model Class Initialized
INFO - 2018-02-06 07:45:46 --> Controller Class Initialized
INFO - 2018-02-06 07:45:46 --> Model Class Initialized
DEBUG - 2018-02-06 07:45:46 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:45:46 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:45:46 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:45:46 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:45:46 --> Final output sent to browser
DEBUG - 2018-02-06 07:45:46 --> Total execution time: 0.0579
INFO - 2018-02-06 07:45:51 --> Config Class Initialized
INFO - 2018-02-06 07:45:51 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:45:51 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:45:51 --> Utf8 Class Initialized
INFO - 2018-02-06 07:45:51 --> URI Class Initialized
INFO - 2018-02-06 07:45:51 --> Router Class Initialized
INFO - 2018-02-06 07:45:51 --> Output Class Initialized
INFO - 2018-02-06 07:45:51 --> Security Class Initialized
DEBUG - 2018-02-06 07:45:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:45:51 --> Input Class Initialized
INFO - 2018-02-06 07:45:51 --> Language Class Initialized
INFO - 2018-02-06 07:45:51 --> Loader Class Initialized
INFO - 2018-02-06 07:45:51 --> Helper loaded: url_helper
INFO - 2018-02-06 07:45:51 --> Helper loaded: form_helper
INFO - 2018-02-06 07:45:51 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:45:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:45:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:45:51 --> Form Validation Class Initialized
INFO - 2018-02-06 07:45:51 --> Model Class Initialized
INFO - 2018-02-06 07:45:51 --> Controller Class Initialized
INFO - 2018-02-06 07:45:51 --> Model Class Initialized
DEBUG - 2018-02-06 07:45:51 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:45:51 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:45:51 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:45:51 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:45:51 --> Final output sent to browser
DEBUG - 2018-02-06 07:45:51 --> Total execution time: 0.0527
INFO - 2018-02-06 07:45:52 --> Config Class Initialized
INFO - 2018-02-06 07:45:52 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:45:52 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:45:52 --> Utf8 Class Initialized
INFO - 2018-02-06 07:45:52 --> URI Class Initialized
INFO - 2018-02-06 07:45:52 --> Router Class Initialized
INFO - 2018-02-06 07:45:52 --> Output Class Initialized
INFO - 2018-02-06 07:45:52 --> Security Class Initialized
DEBUG - 2018-02-06 07:45:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:45:52 --> Input Class Initialized
INFO - 2018-02-06 07:45:52 --> Language Class Initialized
INFO - 2018-02-06 07:45:52 --> Loader Class Initialized
INFO - 2018-02-06 07:45:52 --> Helper loaded: url_helper
INFO - 2018-02-06 07:45:52 --> Helper loaded: form_helper
INFO - 2018-02-06 07:45:52 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:45:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:45:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:45:52 --> Form Validation Class Initialized
INFO - 2018-02-06 07:45:52 --> Model Class Initialized
INFO - 2018-02-06 07:45:52 --> Controller Class Initialized
INFO - 2018-02-06 07:45:52 --> Model Class Initialized
DEBUG - 2018-02-06 07:45:52 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:45:52 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:45:52 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:45:52 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:45:52 --> Final output sent to browser
DEBUG - 2018-02-06 07:45:52 --> Total execution time: 0.0521
INFO - 2018-02-06 07:45:52 --> Config Class Initialized
INFO - 2018-02-06 07:45:52 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:45:52 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:45:52 --> Utf8 Class Initialized
INFO - 2018-02-06 07:45:52 --> URI Class Initialized
INFO - 2018-02-06 07:45:52 --> Router Class Initialized
INFO - 2018-02-06 07:45:52 --> Output Class Initialized
INFO - 2018-02-06 07:45:52 --> Security Class Initialized
DEBUG - 2018-02-06 07:45:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:45:52 --> Input Class Initialized
INFO - 2018-02-06 07:45:52 --> Language Class Initialized
INFO - 2018-02-06 07:45:52 --> Loader Class Initialized
INFO - 2018-02-06 07:45:52 --> Helper loaded: url_helper
INFO - 2018-02-06 07:45:52 --> Helper loaded: form_helper
INFO - 2018-02-06 07:45:52 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:45:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:45:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:45:52 --> Form Validation Class Initialized
INFO - 2018-02-06 07:45:52 --> Model Class Initialized
INFO - 2018-02-06 07:45:52 --> Controller Class Initialized
INFO - 2018-02-06 07:45:52 --> Model Class Initialized
DEBUG - 2018-02-06 07:45:52 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:45:52 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:45:52 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:45:52 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:45:52 --> Final output sent to browser
DEBUG - 2018-02-06 07:45:52 --> Total execution time: 0.0414
INFO - 2018-02-06 07:45:52 --> Config Class Initialized
INFO - 2018-02-06 07:45:52 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:45:52 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:45:52 --> Utf8 Class Initialized
INFO - 2018-02-06 07:45:52 --> URI Class Initialized
INFO - 2018-02-06 07:45:52 --> Router Class Initialized
INFO - 2018-02-06 07:45:52 --> Output Class Initialized
INFO - 2018-02-06 07:45:52 --> Security Class Initialized
DEBUG - 2018-02-06 07:45:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:45:52 --> Input Class Initialized
INFO - 2018-02-06 07:45:52 --> Language Class Initialized
INFO - 2018-02-06 07:45:52 --> Loader Class Initialized
INFO - 2018-02-06 07:45:52 --> Helper loaded: url_helper
INFO - 2018-02-06 07:45:52 --> Helper loaded: form_helper
INFO - 2018-02-06 07:45:52 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:45:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:45:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:45:52 --> Form Validation Class Initialized
INFO - 2018-02-06 07:45:52 --> Model Class Initialized
INFO - 2018-02-06 07:45:52 --> Controller Class Initialized
INFO - 2018-02-06 07:45:52 --> Model Class Initialized
DEBUG - 2018-02-06 07:45:52 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:45:52 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:45:52 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:45:52 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:45:52 --> Final output sent to browser
DEBUG - 2018-02-06 07:45:52 --> Total execution time: 0.0410
INFO - 2018-02-06 07:45:53 --> Config Class Initialized
INFO - 2018-02-06 07:45:53 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:45:53 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:45:53 --> Utf8 Class Initialized
INFO - 2018-02-06 07:45:53 --> URI Class Initialized
INFO - 2018-02-06 07:45:53 --> Router Class Initialized
INFO - 2018-02-06 07:45:53 --> Output Class Initialized
INFO - 2018-02-06 07:45:53 --> Security Class Initialized
DEBUG - 2018-02-06 07:45:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:45:53 --> Input Class Initialized
INFO - 2018-02-06 07:45:53 --> Language Class Initialized
INFO - 2018-02-06 07:45:53 --> Loader Class Initialized
INFO - 2018-02-06 07:45:53 --> Helper loaded: url_helper
INFO - 2018-02-06 07:45:53 --> Helper loaded: form_helper
INFO - 2018-02-06 07:45:53 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:45:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:45:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:45:53 --> Form Validation Class Initialized
INFO - 2018-02-06 07:45:53 --> Model Class Initialized
INFO - 2018-02-06 07:45:53 --> Controller Class Initialized
INFO - 2018-02-06 07:45:53 --> Model Class Initialized
DEBUG - 2018-02-06 07:45:53 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:45:53 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:45:53 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:45:53 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:45:53 --> Final output sent to browser
DEBUG - 2018-02-06 07:45:53 --> Total execution time: 0.0501
INFO - 2018-02-06 07:45:53 --> Config Class Initialized
INFO - 2018-02-06 07:45:53 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:45:53 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:45:53 --> Utf8 Class Initialized
INFO - 2018-02-06 07:45:53 --> URI Class Initialized
INFO - 2018-02-06 07:45:53 --> Router Class Initialized
INFO - 2018-02-06 07:45:53 --> Output Class Initialized
INFO - 2018-02-06 07:45:53 --> Security Class Initialized
DEBUG - 2018-02-06 07:45:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:45:53 --> Input Class Initialized
INFO - 2018-02-06 07:45:53 --> Language Class Initialized
INFO - 2018-02-06 07:45:53 --> Loader Class Initialized
INFO - 2018-02-06 07:45:53 --> Helper loaded: url_helper
INFO - 2018-02-06 07:45:53 --> Helper loaded: form_helper
INFO - 2018-02-06 07:45:53 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:45:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:45:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:45:53 --> Form Validation Class Initialized
INFO - 2018-02-06 07:45:53 --> Model Class Initialized
INFO - 2018-02-06 07:45:53 --> Controller Class Initialized
INFO - 2018-02-06 07:45:53 --> Model Class Initialized
DEBUG - 2018-02-06 07:45:53 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:45:53 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:45:53 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:45:53 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:45:53 --> Final output sent to browser
DEBUG - 2018-02-06 07:45:53 --> Total execution time: 0.0503
INFO - 2018-02-06 07:45:53 --> Config Class Initialized
INFO - 2018-02-06 07:45:53 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:45:53 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:45:53 --> Utf8 Class Initialized
INFO - 2018-02-06 07:45:53 --> URI Class Initialized
INFO - 2018-02-06 07:45:53 --> Router Class Initialized
INFO - 2018-02-06 07:45:53 --> Output Class Initialized
INFO - 2018-02-06 07:45:53 --> Security Class Initialized
DEBUG - 2018-02-06 07:45:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:45:53 --> Input Class Initialized
INFO - 2018-02-06 07:45:53 --> Language Class Initialized
INFO - 2018-02-06 07:45:53 --> Loader Class Initialized
INFO - 2018-02-06 07:45:53 --> Helper loaded: url_helper
INFO - 2018-02-06 07:45:53 --> Helper loaded: form_helper
INFO - 2018-02-06 07:45:53 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:45:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:45:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:45:53 --> Form Validation Class Initialized
INFO - 2018-02-06 07:45:53 --> Model Class Initialized
INFO - 2018-02-06 07:45:53 --> Controller Class Initialized
INFO - 2018-02-06 07:45:53 --> Model Class Initialized
DEBUG - 2018-02-06 07:45:53 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:45:53 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:45:53 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:45:53 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:45:53 --> Final output sent to browser
DEBUG - 2018-02-06 07:45:53 --> Total execution time: 0.0407
INFO - 2018-02-06 07:45:53 --> Config Class Initialized
INFO - 2018-02-06 07:45:53 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:45:53 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:45:53 --> Utf8 Class Initialized
INFO - 2018-02-06 07:45:53 --> URI Class Initialized
INFO - 2018-02-06 07:45:53 --> Router Class Initialized
INFO - 2018-02-06 07:45:53 --> Output Class Initialized
INFO - 2018-02-06 07:45:53 --> Security Class Initialized
DEBUG - 2018-02-06 07:45:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:45:53 --> Input Class Initialized
INFO - 2018-02-06 07:45:53 --> Language Class Initialized
INFO - 2018-02-06 07:45:53 --> Loader Class Initialized
INFO - 2018-02-06 07:45:53 --> Helper loaded: url_helper
INFO - 2018-02-06 07:45:53 --> Helper loaded: form_helper
INFO - 2018-02-06 07:45:53 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:45:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:45:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:45:53 --> Form Validation Class Initialized
INFO - 2018-02-06 07:45:53 --> Model Class Initialized
INFO - 2018-02-06 07:45:53 --> Controller Class Initialized
INFO - 2018-02-06 07:45:53 --> Model Class Initialized
DEBUG - 2018-02-06 07:45:53 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:45:53 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:45:53 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:45:53 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:45:53 --> Final output sent to browser
DEBUG - 2018-02-06 07:45:53 --> Total execution time: 0.0503
INFO - 2018-02-06 07:45:54 --> Config Class Initialized
INFO - 2018-02-06 07:45:54 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:45:54 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:45:54 --> Utf8 Class Initialized
INFO - 2018-02-06 07:45:54 --> URI Class Initialized
INFO - 2018-02-06 07:45:54 --> Router Class Initialized
INFO - 2018-02-06 07:45:54 --> Output Class Initialized
INFO - 2018-02-06 07:45:54 --> Security Class Initialized
DEBUG - 2018-02-06 07:45:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:45:54 --> Input Class Initialized
INFO - 2018-02-06 07:45:54 --> Language Class Initialized
INFO - 2018-02-06 07:45:54 --> Loader Class Initialized
INFO - 2018-02-06 07:45:54 --> Helper loaded: url_helper
INFO - 2018-02-06 07:45:54 --> Helper loaded: form_helper
INFO - 2018-02-06 07:45:54 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:45:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:45:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:45:54 --> Form Validation Class Initialized
INFO - 2018-02-06 07:45:54 --> Model Class Initialized
INFO - 2018-02-06 07:45:54 --> Controller Class Initialized
INFO - 2018-02-06 07:45:54 --> Model Class Initialized
DEBUG - 2018-02-06 07:45:54 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:45:54 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:45:54 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:45:54 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:45:54 --> Final output sent to browser
DEBUG - 2018-02-06 07:45:54 --> Total execution time: 0.0411
INFO - 2018-02-06 07:46:40 --> Config Class Initialized
INFO - 2018-02-06 07:46:40 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:46:40 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:46:40 --> Utf8 Class Initialized
INFO - 2018-02-06 07:46:40 --> URI Class Initialized
INFO - 2018-02-06 07:46:40 --> Router Class Initialized
INFO - 2018-02-06 07:46:40 --> Output Class Initialized
INFO - 2018-02-06 07:46:40 --> Security Class Initialized
DEBUG - 2018-02-06 07:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:46:40 --> Input Class Initialized
INFO - 2018-02-06 07:46:40 --> Language Class Initialized
INFO - 2018-02-06 07:46:40 --> Loader Class Initialized
INFO - 2018-02-06 07:46:40 --> Helper loaded: url_helper
INFO - 2018-02-06 07:46:40 --> Helper loaded: form_helper
INFO - 2018-02-06 07:46:40 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:46:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:46:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:46:40 --> Form Validation Class Initialized
INFO - 2018-02-06 07:46:40 --> Model Class Initialized
INFO - 2018-02-06 07:46:40 --> Controller Class Initialized
INFO - 2018-02-06 07:46:40 --> Model Class Initialized
DEBUG - 2018-02-06 07:46:40 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:46:40 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:46:40 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:46:40 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:46:40 --> Final output sent to browser
DEBUG - 2018-02-06 07:46:40 --> Total execution time: 0.0668
INFO - 2018-02-06 07:46:40 --> Config Class Initialized
INFO - 2018-02-06 07:46:40 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:46:40 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:46:40 --> Utf8 Class Initialized
INFO - 2018-02-06 07:46:40 --> URI Class Initialized
INFO - 2018-02-06 07:46:40 --> Router Class Initialized
INFO - 2018-02-06 07:46:40 --> Output Class Initialized
INFO - 2018-02-06 07:46:40 --> Security Class Initialized
DEBUG - 2018-02-06 07:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:46:40 --> Input Class Initialized
INFO - 2018-02-06 07:46:40 --> Language Class Initialized
INFO - 2018-02-06 07:46:40 --> Loader Class Initialized
INFO - 2018-02-06 07:46:40 --> Helper loaded: url_helper
INFO - 2018-02-06 07:46:40 --> Helper loaded: form_helper
INFO - 2018-02-06 07:46:40 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:46:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:46:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:46:40 --> Form Validation Class Initialized
INFO - 2018-02-06 07:46:40 --> Model Class Initialized
INFO - 2018-02-06 07:46:40 --> Controller Class Initialized
INFO - 2018-02-06 07:46:40 --> Model Class Initialized
DEBUG - 2018-02-06 07:46:40 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:46:40 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:46:40 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:46:40 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:46:40 --> Final output sent to browser
DEBUG - 2018-02-06 07:46:40 --> Total execution time: 0.0755
INFO - 2018-02-06 07:46:41 --> Config Class Initialized
INFO - 2018-02-06 07:46:41 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:46:41 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:46:41 --> Utf8 Class Initialized
INFO - 2018-02-06 07:46:41 --> URI Class Initialized
INFO - 2018-02-06 07:46:41 --> Router Class Initialized
INFO - 2018-02-06 07:46:41 --> Output Class Initialized
INFO - 2018-02-06 07:46:41 --> Security Class Initialized
DEBUG - 2018-02-06 07:46:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:46:41 --> Input Class Initialized
INFO - 2018-02-06 07:46:41 --> Language Class Initialized
INFO - 2018-02-06 07:46:41 --> Loader Class Initialized
INFO - 2018-02-06 07:46:41 --> Helper loaded: url_helper
INFO - 2018-02-06 07:46:41 --> Helper loaded: form_helper
INFO - 2018-02-06 07:46:41 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:46:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:46:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:46:41 --> Form Validation Class Initialized
INFO - 2018-02-06 07:46:41 --> Model Class Initialized
INFO - 2018-02-06 07:46:41 --> Controller Class Initialized
INFO - 2018-02-06 07:46:41 --> Model Class Initialized
DEBUG - 2018-02-06 07:46:41 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:46:41 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:46:41 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:46:41 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:46:41 --> Final output sent to browser
DEBUG - 2018-02-06 07:46:41 --> Total execution time: 0.0592
INFO - 2018-02-06 07:46:41 --> Config Class Initialized
INFO - 2018-02-06 07:46:41 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:46:41 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:46:41 --> Utf8 Class Initialized
INFO - 2018-02-06 07:46:41 --> URI Class Initialized
INFO - 2018-02-06 07:46:41 --> Router Class Initialized
INFO - 2018-02-06 07:46:41 --> Output Class Initialized
INFO - 2018-02-06 07:46:41 --> Security Class Initialized
DEBUG - 2018-02-06 07:46:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:46:41 --> Input Class Initialized
INFO - 2018-02-06 07:46:41 --> Language Class Initialized
INFO - 2018-02-06 07:46:41 --> Loader Class Initialized
INFO - 2018-02-06 07:46:41 --> Helper loaded: url_helper
INFO - 2018-02-06 07:46:41 --> Helper loaded: form_helper
INFO - 2018-02-06 07:46:41 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:46:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:46:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:46:41 --> Form Validation Class Initialized
INFO - 2018-02-06 07:46:41 --> Model Class Initialized
INFO - 2018-02-06 07:46:41 --> Controller Class Initialized
INFO - 2018-02-06 07:46:41 --> Model Class Initialized
DEBUG - 2018-02-06 07:46:41 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:46:41 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:46:41 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:46:41 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:46:41 --> Final output sent to browser
DEBUG - 2018-02-06 07:46:41 --> Total execution time: 0.0675
INFO - 2018-02-06 07:46:41 --> Config Class Initialized
INFO - 2018-02-06 07:46:41 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:46:41 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:46:41 --> Utf8 Class Initialized
INFO - 2018-02-06 07:46:41 --> URI Class Initialized
INFO - 2018-02-06 07:46:41 --> Router Class Initialized
INFO - 2018-02-06 07:46:41 --> Output Class Initialized
INFO - 2018-02-06 07:46:41 --> Security Class Initialized
DEBUG - 2018-02-06 07:46:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:46:41 --> Input Class Initialized
INFO - 2018-02-06 07:46:41 --> Language Class Initialized
INFO - 2018-02-06 07:46:41 --> Loader Class Initialized
INFO - 2018-02-06 07:46:41 --> Helper loaded: url_helper
INFO - 2018-02-06 07:46:41 --> Helper loaded: form_helper
INFO - 2018-02-06 07:46:41 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:46:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:46:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:46:41 --> Form Validation Class Initialized
INFO - 2018-02-06 07:46:41 --> Model Class Initialized
INFO - 2018-02-06 07:46:41 --> Controller Class Initialized
INFO - 2018-02-06 07:46:41 --> Model Class Initialized
DEBUG - 2018-02-06 07:46:41 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:46:41 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:46:41 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:46:41 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:46:41 --> Final output sent to browser
DEBUG - 2018-02-06 07:46:41 --> Total execution time: 0.0392
INFO - 2018-02-06 07:46:41 --> Config Class Initialized
INFO - 2018-02-06 07:46:41 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:46:41 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:46:41 --> Utf8 Class Initialized
INFO - 2018-02-06 07:46:41 --> URI Class Initialized
INFO - 2018-02-06 07:46:41 --> Router Class Initialized
INFO - 2018-02-06 07:46:41 --> Output Class Initialized
INFO - 2018-02-06 07:46:41 --> Security Class Initialized
DEBUG - 2018-02-06 07:46:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:46:41 --> Input Class Initialized
INFO - 2018-02-06 07:46:41 --> Language Class Initialized
INFO - 2018-02-06 07:46:41 --> Loader Class Initialized
INFO - 2018-02-06 07:46:42 --> Helper loaded: url_helper
INFO - 2018-02-06 07:46:42 --> Helper loaded: form_helper
INFO - 2018-02-06 07:46:42 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:46:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:46:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:46:42 --> Form Validation Class Initialized
INFO - 2018-02-06 07:46:42 --> Model Class Initialized
INFO - 2018-02-06 07:46:42 --> Controller Class Initialized
INFO - 2018-02-06 07:46:42 --> Model Class Initialized
DEBUG - 2018-02-06 07:46:42 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:46:42 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:46:42 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:46:42 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:46:42 --> Final output sent to browser
DEBUG - 2018-02-06 07:46:42 --> Total execution time: 0.0729
INFO - 2018-02-06 07:46:42 --> Config Class Initialized
INFO - 2018-02-06 07:46:42 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:46:42 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:46:42 --> Utf8 Class Initialized
INFO - 2018-02-06 07:46:42 --> URI Class Initialized
INFO - 2018-02-06 07:46:42 --> Router Class Initialized
INFO - 2018-02-06 07:46:42 --> Output Class Initialized
INFO - 2018-02-06 07:46:42 --> Security Class Initialized
DEBUG - 2018-02-06 07:46:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:46:42 --> Input Class Initialized
INFO - 2018-02-06 07:46:42 --> Language Class Initialized
INFO - 2018-02-06 07:46:42 --> Loader Class Initialized
INFO - 2018-02-06 07:46:42 --> Helper loaded: url_helper
INFO - 2018-02-06 07:46:42 --> Helper loaded: form_helper
INFO - 2018-02-06 07:46:42 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:46:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:46:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:46:42 --> Form Validation Class Initialized
INFO - 2018-02-06 07:46:42 --> Model Class Initialized
INFO - 2018-02-06 07:46:42 --> Controller Class Initialized
INFO - 2018-02-06 07:46:42 --> Model Class Initialized
DEBUG - 2018-02-06 07:46:42 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:46:42 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:46:42 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:46:42 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:46:42 --> Final output sent to browser
DEBUG - 2018-02-06 07:46:42 --> Total execution time: 0.0705
INFO - 2018-02-06 07:47:17 --> Config Class Initialized
INFO - 2018-02-06 07:47:17 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:47:17 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:47:17 --> Utf8 Class Initialized
INFO - 2018-02-06 07:47:17 --> URI Class Initialized
INFO - 2018-02-06 07:47:17 --> Router Class Initialized
INFO - 2018-02-06 07:47:17 --> Output Class Initialized
INFO - 2018-02-06 07:47:17 --> Security Class Initialized
DEBUG - 2018-02-06 07:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:47:17 --> Input Class Initialized
INFO - 2018-02-06 07:47:17 --> Language Class Initialized
INFO - 2018-02-06 07:47:17 --> Loader Class Initialized
INFO - 2018-02-06 07:47:17 --> Helper loaded: url_helper
INFO - 2018-02-06 07:47:17 --> Helper loaded: form_helper
INFO - 2018-02-06 07:47:17 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:47:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:47:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:47:17 --> Form Validation Class Initialized
INFO - 2018-02-06 07:47:17 --> Model Class Initialized
INFO - 2018-02-06 07:47:17 --> Controller Class Initialized
INFO - 2018-02-06 07:47:17 --> Model Class Initialized
DEBUG - 2018-02-06 07:47:17 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:47:17 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:47:17 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:47:17 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:47:17 --> Final output sent to browser
DEBUG - 2018-02-06 07:47:17 --> Total execution time: 0.0745
INFO - 2018-02-06 07:47:17 --> Config Class Initialized
INFO - 2018-02-06 07:47:17 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:47:17 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:47:17 --> Utf8 Class Initialized
INFO - 2018-02-06 07:47:17 --> URI Class Initialized
INFO - 2018-02-06 07:47:17 --> Router Class Initialized
INFO - 2018-02-06 07:47:17 --> Output Class Initialized
INFO - 2018-02-06 07:47:17 --> Security Class Initialized
DEBUG - 2018-02-06 07:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:47:17 --> Input Class Initialized
INFO - 2018-02-06 07:47:17 --> Language Class Initialized
INFO - 2018-02-06 07:47:17 --> Loader Class Initialized
INFO - 2018-02-06 07:47:17 --> Helper loaded: url_helper
INFO - 2018-02-06 07:47:17 --> Helper loaded: form_helper
INFO - 2018-02-06 07:47:17 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:47:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:47:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:47:17 --> Form Validation Class Initialized
INFO - 2018-02-06 07:47:17 --> Model Class Initialized
INFO - 2018-02-06 07:47:17 --> Controller Class Initialized
INFO - 2018-02-06 07:47:17 --> Model Class Initialized
DEBUG - 2018-02-06 07:47:17 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:47:17 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:47:17 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:47:17 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:47:17 --> Final output sent to browser
DEBUG - 2018-02-06 07:47:17 --> Total execution time: 0.0627
INFO - 2018-02-06 07:47:18 --> Config Class Initialized
INFO - 2018-02-06 07:47:18 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:47:18 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:47:18 --> Utf8 Class Initialized
INFO - 2018-02-06 07:47:18 --> URI Class Initialized
INFO - 2018-02-06 07:47:18 --> Router Class Initialized
INFO - 2018-02-06 07:47:18 --> Output Class Initialized
INFO - 2018-02-06 07:47:18 --> Security Class Initialized
DEBUG - 2018-02-06 07:47:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:47:18 --> Input Class Initialized
INFO - 2018-02-06 07:47:18 --> Language Class Initialized
INFO - 2018-02-06 07:47:18 --> Loader Class Initialized
INFO - 2018-02-06 07:47:18 --> Helper loaded: url_helper
INFO - 2018-02-06 07:47:18 --> Helper loaded: form_helper
INFO - 2018-02-06 07:47:18 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:47:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:47:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:47:18 --> Form Validation Class Initialized
INFO - 2018-02-06 07:47:18 --> Model Class Initialized
INFO - 2018-02-06 07:47:18 --> Controller Class Initialized
INFO - 2018-02-06 07:47:18 --> Model Class Initialized
DEBUG - 2018-02-06 07:47:18 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:47:18 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:47:18 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:47:18 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:47:18 --> Final output sent to browser
DEBUG - 2018-02-06 07:47:18 --> Total execution time: 0.0702
INFO - 2018-02-06 07:47:18 --> Config Class Initialized
INFO - 2018-02-06 07:47:18 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:47:18 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:47:18 --> Utf8 Class Initialized
INFO - 2018-02-06 07:47:18 --> URI Class Initialized
INFO - 2018-02-06 07:47:18 --> Router Class Initialized
INFO - 2018-02-06 07:47:18 --> Output Class Initialized
INFO - 2018-02-06 07:47:18 --> Security Class Initialized
DEBUG - 2018-02-06 07:47:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:47:18 --> Input Class Initialized
INFO - 2018-02-06 07:47:18 --> Language Class Initialized
INFO - 2018-02-06 07:47:18 --> Loader Class Initialized
INFO - 2018-02-06 07:47:18 --> Helper loaded: url_helper
INFO - 2018-02-06 07:47:18 --> Helper loaded: form_helper
INFO - 2018-02-06 07:47:18 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:47:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:47:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:47:18 --> Form Validation Class Initialized
INFO - 2018-02-06 07:47:18 --> Model Class Initialized
INFO - 2018-02-06 07:47:18 --> Controller Class Initialized
INFO - 2018-02-06 07:47:18 --> Model Class Initialized
DEBUG - 2018-02-06 07:47:18 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:47:18 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:47:18 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:47:18 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:47:18 --> Final output sent to browser
DEBUG - 2018-02-06 07:47:18 --> Total execution time: 0.0719
INFO - 2018-02-06 07:47:18 --> Config Class Initialized
INFO - 2018-02-06 07:47:18 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:47:18 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:47:18 --> Utf8 Class Initialized
INFO - 2018-02-06 07:47:18 --> URI Class Initialized
INFO - 2018-02-06 07:47:18 --> Router Class Initialized
INFO - 2018-02-06 07:47:18 --> Output Class Initialized
INFO - 2018-02-06 07:47:18 --> Security Class Initialized
DEBUG - 2018-02-06 07:47:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:47:18 --> Input Class Initialized
INFO - 2018-02-06 07:47:18 --> Language Class Initialized
INFO - 2018-02-06 07:47:18 --> Loader Class Initialized
INFO - 2018-02-06 07:47:18 --> Helper loaded: url_helper
INFO - 2018-02-06 07:47:18 --> Helper loaded: form_helper
INFO - 2018-02-06 07:47:18 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:47:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:47:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:47:18 --> Form Validation Class Initialized
INFO - 2018-02-06 07:47:18 --> Model Class Initialized
INFO - 2018-02-06 07:47:18 --> Controller Class Initialized
INFO - 2018-02-06 07:47:18 --> Model Class Initialized
DEBUG - 2018-02-06 07:47:18 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:47:18 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:47:18 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:47:18 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:47:18 --> Final output sent to browser
DEBUG - 2018-02-06 07:47:18 --> Total execution time: 0.0454
INFO - 2018-02-06 07:47:45 --> Config Class Initialized
INFO - 2018-02-06 07:47:45 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:47:45 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:47:45 --> Utf8 Class Initialized
INFO - 2018-02-06 07:47:45 --> URI Class Initialized
INFO - 2018-02-06 07:47:45 --> Router Class Initialized
INFO - 2018-02-06 07:47:45 --> Output Class Initialized
INFO - 2018-02-06 07:47:45 --> Security Class Initialized
DEBUG - 2018-02-06 07:47:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:47:45 --> Input Class Initialized
INFO - 2018-02-06 07:47:45 --> Language Class Initialized
INFO - 2018-02-06 07:47:45 --> Loader Class Initialized
INFO - 2018-02-06 07:47:45 --> Helper loaded: url_helper
INFO - 2018-02-06 07:47:45 --> Helper loaded: form_helper
INFO - 2018-02-06 07:47:45 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:47:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:47:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:47:45 --> Form Validation Class Initialized
INFO - 2018-02-06 07:47:45 --> Model Class Initialized
INFO - 2018-02-06 07:47:45 --> Controller Class Initialized
INFO - 2018-02-06 07:47:45 --> Model Class Initialized
DEBUG - 2018-02-06 07:47:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:47:45 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:47:45 --> Final output sent to browser
DEBUG - 2018-02-06 07:47:45 --> Total execution time: 0.0375
INFO - 2018-02-06 07:47:46 --> Config Class Initialized
INFO - 2018-02-06 07:47:46 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:47:46 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:47:46 --> Utf8 Class Initialized
INFO - 2018-02-06 07:47:46 --> URI Class Initialized
INFO - 2018-02-06 07:47:46 --> Router Class Initialized
INFO - 2018-02-06 07:47:46 --> Output Class Initialized
INFO - 2018-02-06 07:47:46 --> Security Class Initialized
DEBUG - 2018-02-06 07:47:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:47:46 --> Input Class Initialized
INFO - 2018-02-06 07:47:46 --> Language Class Initialized
INFO - 2018-02-06 07:47:46 --> Loader Class Initialized
INFO - 2018-02-06 07:47:46 --> Helper loaded: url_helper
INFO - 2018-02-06 07:47:46 --> Helper loaded: form_helper
INFO - 2018-02-06 07:47:46 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:47:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:47:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:47:46 --> Form Validation Class Initialized
INFO - 2018-02-06 07:47:46 --> Model Class Initialized
INFO - 2018-02-06 07:47:46 --> Controller Class Initialized
INFO - 2018-02-06 07:47:46 --> Model Class Initialized
DEBUG - 2018-02-06 07:47:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:47:50 --> Config Class Initialized
INFO - 2018-02-06 07:47:50 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:47:50 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:47:50 --> Utf8 Class Initialized
INFO - 2018-02-06 07:47:50 --> URI Class Initialized
INFO - 2018-02-06 07:47:50 --> Router Class Initialized
INFO - 2018-02-06 07:47:50 --> Output Class Initialized
INFO - 2018-02-06 07:47:50 --> Security Class Initialized
DEBUG - 2018-02-06 07:47:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:47:50 --> Input Class Initialized
INFO - 2018-02-06 07:47:50 --> Language Class Initialized
INFO - 2018-02-06 07:47:50 --> Loader Class Initialized
INFO - 2018-02-06 07:47:50 --> Helper loaded: url_helper
INFO - 2018-02-06 07:47:50 --> Helper loaded: form_helper
INFO - 2018-02-06 07:47:50 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:47:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:47:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:47:50 --> Form Validation Class Initialized
INFO - 2018-02-06 07:47:50 --> Model Class Initialized
INFO - 2018-02-06 07:47:50 --> Controller Class Initialized
INFO - 2018-02-06 07:47:50 --> Model Class Initialized
DEBUG - 2018-02-06 07:47:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:47:50 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:47:50 --> Final output sent to browser
DEBUG - 2018-02-06 07:47:50 --> Total execution time: 0.0470
INFO - 2018-02-06 07:47:50 --> Config Class Initialized
INFO - 2018-02-06 07:47:50 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:47:50 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:47:50 --> Utf8 Class Initialized
INFO - 2018-02-06 07:47:50 --> URI Class Initialized
INFO - 2018-02-06 07:47:50 --> Router Class Initialized
INFO - 2018-02-06 07:47:50 --> Output Class Initialized
INFO - 2018-02-06 07:47:50 --> Security Class Initialized
DEBUG - 2018-02-06 07:47:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:47:50 --> Input Class Initialized
INFO - 2018-02-06 07:47:50 --> Language Class Initialized
INFO - 2018-02-06 07:47:50 --> Loader Class Initialized
INFO - 2018-02-06 07:47:50 --> Helper loaded: url_helper
INFO - 2018-02-06 07:47:50 --> Helper loaded: form_helper
INFO - 2018-02-06 07:47:50 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:47:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:47:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:47:50 --> Form Validation Class Initialized
INFO - 2018-02-06 07:47:50 --> Model Class Initialized
INFO - 2018-02-06 07:47:50 --> Controller Class Initialized
INFO - 2018-02-06 07:47:50 --> Model Class Initialized
DEBUG - 2018-02-06 07:47:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:47:52 --> Config Class Initialized
INFO - 2018-02-06 07:47:52 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:47:52 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:47:52 --> Utf8 Class Initialized
INFO - 2018-02-06 07:47:52 --> URI Class Initialized
INFO - 2018-02-06 07:47:52 --> Router Class Initialized
INFO - 2018-02-06 07:47:52 --> Output Class Initialized
INFO - 2018-02-06 07:47:52 --> Security Class Initialized
DEBUG - 2018-02-06 07:47:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:47:52 --> Input Class Initialized
INFO - 2018-02-06 07:47:52 --> Language Class Initialized
INFO - 2018-02-06 07:47:52 --> Loader Class Initialized
INFO - 2018-02-06 07:47:52 --> Helper loaded: url_helper
INFO - 2018-02-06 07:47:52 --> Helper loaded: form_helper
INFO - 2018-02-06 07:47:52 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:47:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:47:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:47:52 --> Form Validation Class Initialized
INFO - 2018-02-06 07:47:52 --> Model Class Initialized
INFO - 2018-02-06 07:47:52 --> Controller Class Initialized
INFO - 2018-02-06 07:47:52 --> Model Class Initialized
DEBUG - 2018-02-06 07:47:52 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:47:52 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:47:52 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:47:52 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:47:52 --> Final output sent to browser
DEBUG - 2018-02-06 07:47:52 --> Total execution time: 0.0531
INFO - 2018-02-06 07:47:59 --> Config Class Initialized
INFO - 2018-02-06 07:47:59 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:47:59 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:47:59 --> Utf8 Class Initialized
INFO - 2018-02-06 07:47:59 --> URI Class Initialized
INFO - 2018-02-06 07:47:59 --> Router Class Initialized
INFO - 2018-02-06 07:47:59 --> Output Class Initialized
INFO - 2018-02-06 07:47:59 --> Security Class Initialized
DEBUG - 2018-02-06 07:47:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:47:59 --> Input Class Initialized
INFO - 2018-02-06 07:47:59 --> Language Class Initialized
INFO - 2018-02-06 07:47:59 --> Loader Class Initialized
INFO - 2018-02-06 07:47:59 --> Helper loaded: url_helper
INFO - 2018-02-06 07:47:59 --> Helper loaded: form_helper
INFO - 2018-02-06 07:47:59 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:47:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:47:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:47:59 --> Form Validation Class Initialized
INFO - 2018-02-06 07:47:59 --> Model Class Initialized
INFO - 2018-02-06 07:47:59 --> Controller Class Initialized
INFO - 2018-02-06 07:47:59 --> Model Class Initialized
DEBUG - 2018-02-06 07:47:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:47:59 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:47:59 --> Final output sent to browser
DEBUG - 2018-02-06 07:47:59 --> Total execution time: 0.0478
INFO - 2018-02-06 07:47:59 --> Config Class Initialized
INFO - 2018-02-06 07:47:59 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:47:59 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:47:59 --> Utf8 Class Initialized
INFO - 2018-02-06 07:47:59 --> URI Class Initialized
INFO - 2018-02-06 07:47:59 --> Router Class Initialized
INFO - 2018-02-06 07:47:59 --> Output Class Initialized
INFO - 2018-02-06 07:47:59 --> Security Class Initialized
DEBUG - 2018-02-06 07:47:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:47:59 --> Input Class Initialized
INFO - 2018-02-06 07:47:59 --> Language Class Initialized
INFO - 2018-02-06 07:47:59 --> Loader Class Initialized
INFO - 2018-02-06 07:47:59 --> Helper loaded: url_helper
INFO - 2018-02-06 07:47:59 --> Helper loaded: form_helper
INFO - 2018-02-06 07:47:59 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:47:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:47:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:47:59 --> Form Validation Class Initialized
INFO - 2018-02-06 07:47:59 --> Model Class Initialized
INFO - 2018-02-06 07:47:59 --> Controller Class Initialized
INFO - 2018-02-06 07:47:59 --> Model Class Initialized
DEBUG - 2018-02-06 07:47:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:48:28 --> Config Class Initialized
INFO - 2018-02-06 07:48:28 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:48:28 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:48:28 --> Utf8 Class Initialized
INFO - 2018-02-06 07:48:28 --> URI Class Initialized
INFO - 2018-02-06 07:48:28 --> Router Class Initialized
INFO - 2018-02-06 07:48:28 --> Output Class Initialized
INFO - 2018-02-06 07:48:28 --> Security Class Initialized
DEBUG - 2018-02-06 07:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:48:28 --> Input Class Initialized
INFO - 2018-02-06 07:48:28 --> Language Class Initialized
INFO - 2018-02-06 07:48:28 --> Loader Class Initialized
INFO - 2018-02-06 07:48:28 --> Helper loaded: url_helper
INFO - 2018-02-06 07:48:28 --> Helper loaded: form_helper
INFO - 2018-02-06 07:48:28 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:48:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:48:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:48:28 --> Form Validation Class Initialized
INFO - 2018-02-06 07:48:28 --> Model Class Initialized
INFO - 2018-02-06 07:48:28 --> Controller Class Initialized
INFO - 2018-02-06 07:48:28 --> Model Class Initialized
INFO - 2018-02-06 07:48:28 --> Model Class Initialized
INFO - 2018-02-06 07:48:28 --> Model Class Initialized
INFO - 2018-02-06 07:48:28 --> Model Class Initialized
DEBUG - 2018-02-06 07:48:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:48:28 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:48:28 --> Final output sent to browser
DEBUG - 2018-02-06 07:48:28 --> Total execution time: 0.0423
INFO - 2018-02-06 07:48:28 --> Config Class Initialized
INFO - 2018-02-06 07:48:28 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:48:28 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:48:28 --> Utf8 Class Initialized
INFO - 2018-02-06 07:48:28 --> URI Class Initialized
INFO - 2018-02-06 07:48:28 --> Router Class Initialized
INFO - 2018-02-06 07:48:28 --> Output Class Initialized
INFO - 2018-02-06 07:48:28 --> Security Class Initialized
DEBUG - 2018-02-06 07:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:48:28 --> Input Class Initialized
INFO - 2018-02-06 07:48:28 --> Language Class Initialized
INFO - 2018-02-06 07:48:28 --> Loader Class Initialized
INFO - 2018-02-06 07:48:28 --> Helper loaded: url_helper
INFO - 2018-02-06 07:48:28 --> Helper loaded: form_helper
INFO - 2018-02-06 07:48:28 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:48:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:48:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:48:28 --> Form Validation Class Initialized
INFO - 2018-02-06 07:48:28 --> Model Class Initialized
INFO - 2018-02-06 07:48:28 --> Controller Class Initialized
INFO - 2018-02-06 07:48:28 --> Model Class Initialized
INFO - 2018-02-06 07:48:28 --> Model Class Initialized
INFO - 2018-02-06 07:48:28 --> Model Class Initialized
INFO - 2018-02-06 07:48:28 --> Model Class Initialized
DEBUG - 2018-02-06 07:48:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:48:30 --> Config Class Initialized
INFO - 2018-02-06 07:48:30 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:48:30 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:48:30 --> Utf8 Class Initialized
INFO - 2018-02-06 07:48:30 --> URI Class Initialized
INFO - 2018-02-06 07:48:30 --> Router Class Initialized
INFO - 2018-02-06 07:48:30 --> Output Class Initialized
INFO - 2018-02-06 07:48:30 --> Security Class Initialized
DEBUG - 2018-02-06 07:48:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:48:30 --> Input Class Initialized
INFO - 2018-02-06 07:48:30 --> Language Class Initialized
INFO - 2018-02-06 07:48:30 --> Loader Class Initialized
INFO - 2018-02-06 07:48:30 --> Helper loaded: url_helper
INFO - 2018-02-06 07:48:30 --> Helper loaded: form_helper
INFO - 2018-02-06 07:48:30 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:48:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:48:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:48:30 --> Form Validation Class Initialized
INFO - 2018-02-06 07:48:30 --> Model Class Initialized
INFO - 2018-02-06 07:48:30 --> Controller Class Initialized
INFO - 2018-02-06 07:48:30 --> Model Class Initialized
INFO - 2018-02-06 07:48:30 --> Model Class Initialized
INFO - 2018-02-06 07:48:30 --> Model Class Initialized
INFO - 2018-02-06 07:48:30 --> Model Class Initialized
DEBUG - 2018-02-06 07:48:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:48:30 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:48:30 --> Final output sent to browser
DEBUG - 2018-02-06 07:48:30 --> Total execution time: 0.0498
INFO - 2018-02-06 07:48:30 --> Config Class Initialized
INFO - 2018-02-06 07:48:30 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:48:30 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:48:30 --> Utf8 Class Initialized
INFO - 2018-02-06 07:48:30 --> URI Class Initialized
INFO - 2018-02-06 07:48:30 --> Router Class Initialized
INFO - 2018-02-06 07:48:30 --> Output Class Initialized
INFO - 2018-02-06 07:48:30 --> Security Class Initialized
DEBUG - 2018-02-06 07:48:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:48:30 --> Input Class Initialized
INFO - 2018-02-06 07:48:30 --> Language Class Initialized
INFO - 2018-02-06 07:48:30 --> Loader Class Initialized
INFO - 2018-02-06 07:48:30 --> Helper loaded: url_helper
INFO - 2018-02-06 07:48:30 --> Helper loaded: form_helper
INFO - 2018-02-06 07:48:30 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:48:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:48:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:48:30 --> Form Validation Class Initialized
INFO - 2018-02-06 07:48:30 --> Model Class Initialized
INFO - 2018-02-06 07:48:30 --> Controller Class Initialized
INFO - 2018-02-06 07:48:30 --> Model Class Initialized
INFO - 2018-02-06 07:48:30 --> Model Class Initialized
INFO - 2018-02-06 07:48:30 --> Model Class Initialized
INFO - 2018-02-06 07:48:30 --> Model Class Initialized
DEBUG - 2018-02-06 07:48:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:48:32 --> Config Class Initialized
INFO - 2018-02-06 07:48:32 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:48:32 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:48:32 --> Utf8 Class Initialized
INFO - 2018-02-06 07:48:32 --> URI Class Initialized
INFO - 2018-02-06 07:48:32 --> Router Class Initialized
INFO - 2018-02-06 07:48:32 --> Output Class Initialized
INFO - 2018-02-06 07:48:32 --> Security Class Initialized
DEBUG - 2018-02-06 07:48:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:48:32 --> Input Class Initialized
INFO - 2018-02-06 07:48:32 --> Language Class Initialized
INFO - 2018-02-06 07:48:32 --> Loader Class Initialized
INFO - 2018-02-06 07:48:32 --> Helper loaded: url_helper
INFO - 2018-02-06 07:48:32 --> Helper loaded: form_helper
INFO - 2018-02-06 07:48:32 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:48:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:48:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:48:32 --> Form Validation Class Initialized
INFO - 2018-02-06 07:48:32 --> Model Class Initialized
INFO - 2018-02-06 07:48:32 --> Controller Class Initialized
INFO - 2018-02-06 07:48:32 --> Model Class Initialized
INFO - 2018-02-06 07:48:32 --> Model Class Initialized
INFO - 2018-02-06 07:48:32 --> Model Class Initialized
INFO - 2018-02-06 07:48:32 --> Model Class Initialized
DEBUG - 2018-02-06 07:48:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:48:32 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:48:32 --> Final output sent to browser
DEBUG - 2018-02-06 07:48:32 --> Total execution time: 0.0607
INFO - 2018-02-06 07:48:32 --> Config Class Initialized
INFO - 2018-02-06 07:48:32 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:48:32 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:48:32 --> Utf8 Class Initialized
INFO - 2018-02-06 07:48:32 --> URI Class Initialized
INFO - 2018-02-06 07:48:32 --> Router Class Initialized
INFO - 2018-02-06 07:48:32 --> Output Class Initialized
INFO - 2018-02-06 07:48:32 --> Security Class Initialized
DEBUG - 2018-02-06 07:48:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:48:32 --> Input Class Initialized
INFO - 2018-02-06 07:48:32 --> Language Class Initialized
INFO - 2018-02-06 07:48:32 --> Loader Class Initialized
INFO - 2018-02-06 07:48:32 --> Helper loaded: url_helper
INFO - 2018-02-06 07:48:32 --> Helper loaded: form_helper
INFO - 2018-02-06 07:48:32 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:48:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:48:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:48:32 --> Form Validation Class Initialized
INFO - 2018-02-06 07:48:32 --> Model Class Initialized
INFO - 2018-02-06 07:48:32 --> Controller Class Initialized
INFO - 2018-02-06 07:48:32 --> Model Class Initialized
INFO - 2018-02-06 07:48:32 --> Model Class Initialized
INFO - 2018-02-06 07:48:32 --> Model Class Initialized
INFO - 2018-02-06 07:48:32 --> Model Class Initialized
DEBUG - 2018-02-06 07:48:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:48:33 --> Config Class Initialized
INFO - 2018-02-06 07:48:33 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:48:33 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:48:33 --> Utf8 Class Initialized
INFO - 2018-02-06 07:48:33 --> URI Class Initialized
INFO - 2018-02-06 07:48:33 --> Router Class Initialized
INFO - 2018-02-06 07:48:33 --> Output Class Initialized
INFO - 2018-02-06 07:48:33 --> Security Class Initialized
DEBUG - 2018-02-06 07:48:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:48:33 --> Input Class Initialized
INFO - 2018-02-06 07:48:33 --> Language Class Initialized
INFO - 2018-02-06 07:48:33 --> Loader Class Initialized
INFO - 2018-02-06 07:48:33 --> Helper loaded: url_helper
INFO - 2018-02-06 07:48:33 --> Helper loaded: form_helper
INFO - 2018-02-06 07:48:33 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:48:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:48:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:48:33 --> Form Validation Class Initialized
INFO - 2018-02-06 07:48:33 --> Model Class Initialized
INFO - 2018-02-06 07:48:33 --> Controller Class Initialized
INFO - 2018-02-06 07:48:33 --> Model Class Initialized
INFO - 2018-02-06 07:48:33 --> Model Class Initialized
INFO - 2018-02-06 07:48:33 --> Model Class Initialized
INFO - 2018-02-06 07:48:33 --> Model Class Initialized
DEBUG - 2018-02-06 07:48:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:48:33 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:48:33 --> Final output sent to browser
DEBUG - 2018-02-06 07:48:33 --> Total execution time: 0.0494
INFO - 2018-02-06 07:49:50 --> Config Class Initialized
INFO - 2018-02-06 07:49:50 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:49:50 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:49:50 --> Utf8 Class Initialized
INFO - 2018-02-06 07:49:50 --> URI Class Initialized
INFO - 2018-02-06 07:49:50 --> Router Class Initialized
INFO - 2018-02-06 07:49:50 --> Output Class Initialized
INFO - 2018-02-06 07:49:50 --> Security Class Initialized
DEBUG - 2018-02-06 07:49:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:49:50 --> Input Class Initialized
INFO - 2018-02-06 07:49:50 --> Language Class Initialized
INFO - 2018-02-06 07:49:50 --> Loader Class Initialized
INFO - 2018-02-06 07:49:50 --> Helper loaded: url_helper
INFO - 2018-02-06 07:49:50 --> Helper loaded: form_helper
INFO - 2018-02-06 07:49:50 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:49:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:49:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:49:50 --> Form Validation Class Initialized
INFO - 2018-02-06 07:49:50 --> Model Class Initialized
INFO - 2018-02-06 07:49:50 --> Controller Class Initialized
INFO - 2018-02-06 07:49:50 --> Model Class Initialized
DEBUG - 2018-02-06 07:49:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:49:50 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:49:50 --> Final output sent to browser
DEBUG - 2018-02-06 07:49:50 --> Total execution time: 0.0391
INFO - 2018-02-06 07:49:50 --> Config Class Initialized
INFO - 2018-02-06 07:49:50 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:49:50 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:49:50 --> Utf8 Class Initialized
INFO - 2018-02-06 07:49:50 --> URI Class Initialized
INFO - 2018-02-06 07:49:50 --> Router Class Initialized
INFO - 2018-02-06 07:49:50 --> Output Class Initialized
INFO - 2018-02-06 07:49:50 --> Security Class Initialized
DEBUG - 2018-02-06 07:49:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:49:50 --> Input Class Initialized
INFO - 2018-02-06 07:49:50 --> Language Class Initialized
INFO - 2018-02-06 07:49:50 --> Loader Class Initialized
INFO - 2018-02-06 07:49:50 --> Helper loaded: url_helper
INFO - 2018-02-06 07:49:50 --> Helper loaded: form_helper
INFO - 2018-02-06 07:49:50 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:49:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:49:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:49:50 --> Form Validation Class Initialized
INFO - 2018-02-06 07:49:50 --> Model Class Initialized
INFO - 2018-02-06 07:49:50 --> Controller Class Initialized
INFO - 2018-02-06 07:49:50 --> Model Class Initialized
DEBUG - 2018-02-06 07:49:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-06 07:49:51 --> Config Class Initialized
INFO - 2018-02-06 07:49:52 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:49:52 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:49:52 --> Utf8 Class Initialized
INFO - 2018-02-06 07:49:52 --> URI Class Initialized
INFO - 2018-02-06 07:49:52 --> Router Class Initialized
INFO - 2018-02-06 07:49:52 --> Output Class Initialized
INFO - 2018-02-06 07:49:52 --> Security Class Initialized
DEBUG - 2018-02-06 07:49:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:49:52 --> Input Class Initialized
INFO - 2018-02-06 07:49:52 --> Language Class Initialized
INFO - 2018-02-06 07:49:52 --> Loader Class Initialized
INFO - 2018-02-06 07:49:52 --> Helper loaded: url_helper
INFO - 2018-02-06 07:49:52 --> Helper loaded: form_helper
INFO - 2018-02-06 07:49:52 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:49:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:49:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:49:52 --> Form Validation Class Initialized
INFO - 2018-02-06 07:49:52 --> Model Class Initialized
INFO - 2018-02-06 07:49:52 --> Controller Class Initialized
INFO - 2018-02-06 07:49:52 --> Model Class Initialized
DEBUG - 2018-02-06 07:49:52 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:49:52 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:49:52 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:49:52 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:49:52 --> Final output sent to browser
DEBUG - 2018-02-06 07:49:52 --> Total execution time: 0.0464
INFO - 2018-02-06 07:49:55 --> Config Class Initialized
INFO - 2018-02-06 07:49:55 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:49:55 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:49:55 --> Utf8 Class Initialized
INFO - 2018-02-06 07:49:55 --> URI Class Initialized
INFO - 2018-02-06 07:49:55 --> Router Class Initialized
INFO - 2018-02-06 07:49:55 --> Output Class Initialized
INFO - 2018-02-06 07:49:55 --> Security Class Initialized
DEBUG - 2018-02-06 07:49:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:49:55 --> Input Class Initialized
INFO - 2018-02-06 07:49:55 --> Language Class Initialized
INFO - 2018-02-06 07:49:55 --> Loader Class Initialized
INFO - 2018-02-06 07:49:55 --> Helper loaded: url_helper
INFO - 2018-02-06 07:49:55 --> Helper loaded: form_helper
INFO - 2018-02-06 07:49:55 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:49:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:49:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:49:55 --> Form Validation Class Initialized
INFO - 2018-02-06 07:49:55 --> Model Class Initialized
INFO - 2018-02-06 07:49:55 --> Controller Class Initialized
INFO - 2018-02-06 07:49:55 --> Model Class Initialized
DEBUG - 2018-02-06 07:49:55 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:49:55 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:49:55 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:49:55 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:49:55 --> Final output sent to browser
DEBUG - 2018-02-06 07:49:55 --> Total execution time: 0.0404
INFO - 2018-02-06 07:49:55 --> Config Class Initialized
INFO - 2018-02-06 07:49:55 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:49:55 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:49:55 --> Utf8 Class Initialized
INFO - 2018-02-06 07:49:55 --> URI Class Initialized
INFO - 2018-02-06 07:49:55 --> Router Class Initialized
INFO - 2018-02-06 07:49:55 --> Output Class Initialized
INFO - 2018-02-06 07:49:55 --> Security Class Initialized
DEBUG - 2018-02-06 07:49:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:49:55 --> Input Class Initialized
INFO - 2018-02-06 07:49:55 --> Language Class Initialized
INFO - 2018-02-06 07:49:55 --> Loader Class Initialized
INFO - 2018-02-06 07:49:55 --> Helper loaded: url_helper
INFO - 2018-02-06 07:49:55 --> Helper loaded: form_helper
INFO - 2018-02-06 07:49:55 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:49:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:49:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:49:55 --> Form Validation Class Initialized
INFO - 2018-02-06 07:49:55 --> Model Class Initialized
INFO - 2018-02-06 07:49:55 --> Controller Class Initialized
INFO - 2018-02-06 07:49:55 --> Model Class Initialized
DEBUG - 2018-02-06 07:49:55 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:49:55 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:49:55 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:49:55 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:49:55 --> Final output sent to browser
DEBUG - 2018-02-06 07:49:56 --> Total execution time: 0.0411
INFO - 2018-02-06 07:49:56 --> Config Class Initialized
INFO - 2018-02-06 07:49:56 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:49:56 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:49:56 --> Utf8 Class Initialized
INFO - 2018-02-06 07:49:56 --> URI Class Initialized
INFO - 2018-02-06 07:49:56 --> Router Class Initialized
INFO - 2018-02-06 07:49:56 --> Output Class Initialized
INFO - 2018-02-06 07:49:56 --> Security Class Initialized
DEBUG - 2018-02-06 07:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:49:56 --> Input Class Initialized
INFO - 2018-02-06 07:49:56 --> Language Class Initialized
INFO - 2018-02-06 07:49:56 --> Loader Class Initialized
INFO - 2018-02-06 07:49:56 --> Helper loaded: url_helper
INFO - 2018-02-06 07:49:56 --> Helper loaded: form_helper
INFO - 2018-02-06 07:49:56 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:49:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:49:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:49:56 --> Form Validation Class Initialized
INFO - 2018-02-06 07:49:56 --> Model Class Initialized
INFO - 2018-02-06 07:49:56 --> Controller Class Initialized
INFO - 2018-02-06 07:49:56 --> Model Class Initialized
DEBUG - 2018-02-06 07:49:56 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:49:56 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:49:56 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:49:56 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:49:56 --> Final output sent to browser
DEBUG - 2018-02-06 07:49:56 --> Total execution time: 0.0423
INFO - 2018-02-06 07:49:56 --> Config Class Initialized
INFO - 2018-02-06 07:49:56 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:49:56 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:49:56 --> Utf8 Class Initialized
INFO - 2018-02-06 07:49:56 --> URI Class Initialized
INFO - 2018-02-06 07:49:56 --> Router Class Initialized
INFO - 2018-02-06 07:49:56 --> Output Class Initialized
INFO - 2018-02-06 07:49:56 --> Security Class Initialized
DEBUG - 2018-02-06 07:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:49:56 --> Input Class Initialized
INFO - 2018-02-06 07:49:56 --> Language Class Initialized
INFO - 2018-02-06 07:49:56 --> Loader Class Initialized
INFO - 2018-02-06 07:49:56 --> Helper loaded: url_helper
INFO - 2018-02-06 07:49:56 --> Helper loaded: form_helper
INFO - 2018-02-06 07:49:56 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:49:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:49:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:49:56 --> Form Validation Class Initialized
INFO - 2018-02-06 07:49:56 --> Model Class Initialized
INFO - 2018-02-06 07:49:56 --> Controller Class Initialized
INFO - 2018-02-06 07:49:56 --> Model Class Initialized
DEBUG - 2018-02-06 07:49:56 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:49:56 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:49:56 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:49:56 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:49:56 --> Final output sent to browser
DEBUG - 2018-02-06 07:49:56 --> Total execution time: 0.0411
INFO - 2018-02-06 07:49:56 --> Config Class Initialized
INFO - 2018-02-06 07:49:56 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:49:56 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:49:56 --> Utf8 Class Initialized
INFO - 2018-02-06 07:49:56 --> URI Class Initialized
INFO - 2018-02-06 07:49:56 --> Router Class Initialized
INFO - 2018-02-06 07:49:56 --> Output Class Initialized
INFO - 2018-02-06 07:49:56 --> Security Class Initialized
DEBUG - 2018-02-06 07:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:49:56 --> Input Class Initialized
INFO - 2018-02-06 07:49:56 --> Language Class Initialized
INFO - 2018-02-06 07:49:56 --> Loader Class Initialized
INFO - 2018-02-06 07:49:56 --> Helper loaded: url_helper
INFO - 2018-02-06 07:49:56 --> Helper loaded: form_helper
INFO - 2018-02-06 07:49:56 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:49:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:49:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:49:56 --> Form Validation Class Initialized
INFO - 2018-02-06 07:49:56 --> Model Class Initialized
INFO - 2018-02-06 07:49:56 --> Controller Class Initialized
INFO - 2018-02-06 07:49:56 --> Model Class Initialized
DEBUG - 2018-02-06 07:49:56 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:49:56 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:49:56 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:49:56 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:49:56 --> Final output sent to browser
DEBUG - 2018-02-06 07:49:56 --> Total execution time: 0.0438
INFO - 2018-02-06 07:49:56 --> Config Class Initialized
INFO - 2018-02-06 07:49:56 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:49:56 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:49:56 --> Utf8 Class Initialized
INFO - 2018-02-06 07:49:56 --> URI Class Initialized
INFO - 2018-02-06 07:49:56 --> Router Class Initialized
INFO - 2018-02-06 07:49:56 --> Output Class Initialized
INFO - 2018-02-06 07:49:56 --> Security Class Initialized
DEBUG - 2018-02-06 07:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:49:56 --> Input Class Initialized
INFO - 2018-02-06 07:49:56 --> Language Class Initialized
INFO - 2018-02-06 07:49:56 --> Loader Class Initialized
INFO - 2018-02-06 07:49:56 --> Helper loaded: url_helper
INFO - 2018-02-06 07:49:56 --> Helper loaded: form_helper
INFO - 2018-02-06 07:49:56 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:49:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:49:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:49:56 --> Form Validation Class Initialized
INFO - 2018-02-06 07:49:56 --> Model Class Initialized
INFO - 2018-02-06 07:49:56 --> Controller Class Initialized
INFO - 2018-02-06 07:49:56 --> Model Class Initialized
DEBUG - 2018-02-06 07:49:56 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:49:56 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:49:56 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:49:56 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:49:56 --> Final output sent to browser
DEBUG - 2018-02-06 07:49:56 --> Total execution time: 0.0420
INFO - 2018-02-06 07:49:57 --> Config Class Initialized
INFO - 2018-02-06 07:49:57 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:49:57 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:49:57 --> Utf8 Class Initialized
INFO - 2018-02-06 07:49:57 --> URI Class Initialized
INFO - 2018-02-06 07:49:57 --> Router Class Initialized
INFO - 2018-02-06 07:49:57 --> Output Class Initialized
INFO - 2018-02-06 07:49:57 --> Security Class Initialized
DEBUG - 2018-02-06 07:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:49:57 --> Input Class Initialized
INFO - 2018-02-06 07:49:57 --> Language Class Initialized
INFO - 2018-02-06 07:49:57 --> Loader Class Initialized
INFO - 2018-02-06 07:49:57 --> Helper loaded: url_helper
INFO - 2018-02-06 07:49:57 --> Helper loaded: form_helper
INFO - 2018-02-06 07:49:57 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:49:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:49:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:49:57 --> Form Validation Class Initialized
INFO - 2018-02-06 07:49:57 --> Model Class Initialized
INFO - 2018-02-06 07:49:57 --> Controller Class Initialized
INFO - 2018-02-06 07:49:57 --> Model Class Initialized
DEBUG - 2018-02-06 07:49:57 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:49:57 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:49:57 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:49:57 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:49:57 --> Final output sent to browser
DEBUG - 2018-02-06 07:49:57 --> Total execution time: 0.0506
INFO - 2018-02-06 07:49:57 --> Config Class Initialized
INFO - 2018-02-06 07:49:57 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:49:57 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:49:57 --> Utf8 Class Initialized
INFO - 2018-02-06 07:49:57 --> URI Class Initialized
INFO - 2018-02-06 07:49:57 --> Router Class Initialized
INFO - 2018-02-06 07:49:57 --> Output Class Initialized
INFO - 2018-02-06 07:49:57 --> Security Class Initialized
DEBUG - 2018-02-06 07:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:49:57 --> Input Class Initialized
INFO - 2018-02-06 07:49:57 --> Language Class Initialized
INFO - 2018-02-06 07:49:57 --> Loader Class Initialized
INFO - 2018-02-06 07:49:57 --> Helper loaded: url_helper
INFO - 2018-02-06 07:49:57 --> Helper loaded: form_helper
INFO - 2018-02-06 07:49:57 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:49:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:49:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:49:57 --> Form Validation Class Initialized
INFO - 2018-02-06 07:49:57 --> Model Class Initialized
INFO - 2018-02-06 07:49:57 --> Controller Class Initialized
INFO - 2018-02-06 07:49:57 --> Model Class Initialized
DEBUG - 2018-02-06 07:49:57 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:49:57 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:49:57 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:49:57 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:49:57 --> Final output sent to browser
DEBUG - 2018-02-06 07:49:57 --> Total execution time: 0.0422
INFO - 2018-02-06 07:49:57 --> Config Class Initialized
INFO - 2018-02-06 07:49:57 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:49:57 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:49:57 --> Utf8 Class Initialized
INFO - 2018-02-06 07:49:57 --> URI Class Initialized
INFO - 2018-02-06 07:49:57 --> Router Class Initialized
INFO - 2018-02-06 07:49:57 --> Output Class Initialized
INFO - 2018-02-06 07:49:57 --> Security Class Initialized
DEBUG - 2018-02-06 07:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:49:57 --> Input Class Initialized
INFO - 2018-02-06 07:49:57 --> Language Class Initialized
INFO - 2018-02-06 07:49:57 --> Loader Class Initialized
INFO - 2018-02-06 07:49:57 --> Helper loaded: url_helper
INFO - 2018-02-06 07:49:57 --> Helper loaded: form_helper
INFO - 2018-02-06 07:49:57 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:49:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:49:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:49:57 --> Form Validation Class Initialized
INFO - 2018-02-06 07:49:57 --> Model Class Initialized
INFO - 2018-02-06 07:49:57 --> Controller Class Initialized
INFO - 2018-02-06 07:49:57 --> Model Class Initialized
DEBUG - 2018-02-06 07:49:57 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:49:57 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:49:57 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:49:57 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:49:57 --> Final output sent to browser
DEBUG - 2018-02-06 07:49:57 --> Total execution time: 0.0893
INFO - 2018-02-06 07:49:57 --> Config Class Initialized
INFO - 2018-02-06 07:49:57 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:49:57 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:49:57 --> Utf8 Class Initialized
INFO - 2018-02-06 07:49:57 --> URI Class Initialized
INFO - 2018-02-06 07:49:57 --> Router Class Initialized
INFO - 2018-02-06 07:49:57 --> Output Class Initialized
INFO - 2018-02-06 07:49:57 --> Security Class Initialized
DEBUG - 2018-02-06 07:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:49:57 --> Input Class Initialized
INFO - 2018-02-06 07:49:57 --> Language Class Initialized
INFO - 2018-02-06 07:49:57 --> Loader Class Initialized
INFO - 2018-02-06 07:49:57 --> Helper loaded: url_helper
INFO - 2018-02-06 07:49:57 --> Helper loaded: form_helper
INFO - 2018-02-06 07:49:57 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:49:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:49:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:49:57 --> Form Validation Class Initialized
INFO - 2018-02-06 07:49:57 --> Model Class Initialized
INFO - 2018-02-06 07:49:57 --> Controller Class Initialized
INFO - 2018-02-06 07:49:57 --> Model Class Initialized
DEBUG - 2018-02-06 07:49:57 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:49:57 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:49:57 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:49:57 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:49:57 --> Final output sent to browser
DEBUG - 2018-02-06 07:49:57 --> Total execution time: 0.0445
INFO - 2018-02-06 07:49:58 --> Config Class Initialized
INFO - 2018-02-06 07:49:58 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:49:58 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:49:58 --> Utf8 Class Initialized
INFO - 2018-02-06 07:49:58 --> URI Class Initialized
INFO - 2018-02-06 07:49:58 --> Router Class Initialized
INFO - 2018-02-06 07:49:58 --> Output Class Initialized
INFO - 2018-02-06 07:49:58 --> Security Class Initialized
DEBUG - 2018-02-06 07:49:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:49:58 --> Input Class Initialized
INFO - 2018-02-06 07:49:58 --> Language Class Initialized
INFO - 2018-02-06 07:49:58 --> Loader Class Initialized
INFO - 2018-02-06 07:49:58 --> Helper loaded: url_helper
INFO - 2018-02-06 07:49:58 --> Helper loaded: form_helper
INFO - 2018-02-06 07:49:58 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:49:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:49:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:49:58 --> Form Validation Class Initialized
INFO - 2018-02-06 07:49:58 --> Model Class Initialized
INFO - 2018-02-06 07:49:58 --> Controller Class Initialized
INFO - 2018-02-06 07:49:58 --> Model Class Initialized
DEBUG - 2018-02-06 07:49:58 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:49:58 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:49:58 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:49:58 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:49:58 --> Final output sent to browser
DEBUG - 2018-02-06 07:49:58 --> Total execution time: 0.0424
INFO - 2018-02-06 07:49:58 --> Config Class Initialized
INFO - 2018-02-06 07:49:58 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:49:58 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:49:58 --> Utf8 Class Initialized
INFO - 2018-02-06 07:49:58 --> URI Class Initialized
INFO - 2018-02-06 07:49:58 --> Router Class Initialized
INFO - 2018-02-06 07:49:58 --> Output Class Initialized
INFO - 2018-02-06 07:49:58 --> Security Class Initialized
DEBUG - 2018-02-06 07:49:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:49:58 --> Input Class Initialized
INFO - 2018-02-06 07:49:58 --> Language Class Initialized
INFO - 2018-02-06 07:49:58 --> Loader Class Initialized
INFO - 2018-02-06 07:49:58 --> Helper loaded: url_helper
INFO - 2018-02-06 07:49:58 --> Helper loaded: form_helper
INFO - 2018-02-06 07:49:58 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:49:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:49:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:49:58 --> Form Validation Class Initialized
INFO - 2018-02-06 07:49:58 --> Model Class Initialized
INFO - 2018-02-06 07:49:58 --> Controller Class Initialized
INFO - 2018-02-06 07:49:58 --> Model Class Initialized
DEBUG - 2018-02-06 07:49:58 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:49:58 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:49:58 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:49:58 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:49:58 --> Final output sent to browser
DEBUG - 2018-02-06 07:49:58 --> Total execution time: 0.0421
INFO - 2018-02-06 07:49:58 --> Config Class Initialized
INFO - 2018-02-06 07:49:58 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:49:58 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:49:58 --> Utf8 Class Initialized
INFO - 2018-02-06 07:49:58 --> URI Class Initialized
INFO - 2018-02-06 07:49:58 --> Router Class Initialized
INFO - 2018-02-06 07:49:58 --> Output Class Initialized
INFO - 2018-02-06 07:49:58 --> Security Class Initialized
DEBUG - 2018-02-06 07:49:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:49:58 --> Input Class Initialized
INFO - 2018-02-06 07:49:58 --> Language Class Initialized
INFO - 2018-02-06 07:49:58 --> Loader Class Initialized
INFO - 2018-02-06 07:49:58 --> Helper loaded: url_helper
INFO - 2018-02-06 07:49:58 --> Helper loaded: form_helper
INFO - 2018-02-06 07:49:58 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:49:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:49:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:49:58 --> Form Validation Class Initialized
INFO - 2018-02-06 07:49:58 --> Model Class Initialized
INFO - 2018-02-06 07:49:58 --> Controller Class Initialized
INFO - 2018-02-06 07:49:58 --> Model Class Initialized
DEBUG - 2018-02-06 07:49:58 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:49:58 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:49:58 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:49:58 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:49:58 --> Final output sent to browser
DEBUG - 2018-02-06 07:49:58 --> Total execution time: 0.0428
INFO - 2018-02-06 07:49:59 --> Config Class Initialized
INFO - 2018-02-06 07:49:59 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:49:59 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:49:59 --> Utf8 Class Initialized
INFO - 2018-02-06 07:49:59 --> URI Class Initialized
INFO - 2018-02-06 07:49:59 --> Router Class Initialized
INFO - 2018-02-06 07:49:59 --> Output Class Initialized
INFO - 2018-02-06 07:49:59 --> Security Class Initialized
DEBUG - 2018-02-06 07:49:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:49:59 --> Input Class Initialized
INFO - 2018-02-06 07:49:59 --> Language Class Initialized
INFO - 2018-02-06 07:49:59 --> Loader Class Initialized
INFO - 2018-02-06 07:49:59 --> Helper loaded: url_helper
INFO - 2018-02-06 07:49:59 --> Helper loaded: form_helper
INFO - 2018-02-06 07:49:59 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:49:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:49:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:49:59 --> Form Validation Class Initialized
INFO - 2018-02-06 07:49:59 --> Model Class Initialized
INFO - 2018-02-06 07:49:59 --> Controller Class Initialized
INFO - 2018-02-06 07:49:59 --> Model Class Initialized
DEBUG - 2018-02-06 07:49:59 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:49:59 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:49:59 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:49:59 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:49:59 --> Final output sent to browser
DEBUG - 2018-02-06 07:49:59 --> Total execution time: 0.0498
INFO - 2018-02-06 07:50:00 --> Config Class Initialized
INFO - 2018-02-06 07:50:00 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:50:00 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:50:00 --> Utf8 Class Initialized
INFO - 2018-02-06 07:50:00 --> URI Class Initialized
INFO - 2018-02-06 07:50:00 --> Router Class Initialized
INFO - 2018-02-06 07:50:00 --> Output Class Initialized
INFO - 2018-02-06 07:50:00 --> Security Class Initialized
DEBUG - 2018-02-06 07:50:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:50:00 --> Input Class Initialized
INFO - 2018-02-06 07:50:00 --> Language Class Initialized
INFO - 2018-02-06 07:50:00 --> Loader Class Initialized
INFO - 2018-02-06 07:50:00 --> Helper loaded: url_helper
INFO - 2018-02-06 07:50:00 --> Helper loaded: form_helper
INFO - 2018-02-06 07:50:00 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:50:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:50:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:50:00 --> Form Validation Class Initialized
INFO - 2018-02-06 07:50:00 --> Model Class Initialized
INFO - 2018-02-06 07:50:00 --> Controller Class Initialized
INFO - 2018-02-06 07:50:00 --> Model Class Initialized
DEBUG - 2018-02-06 07:50:00 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:50:00 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:50:00 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:50:00 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:50:00 --> Final output sent to browser
DEBUG - 2018-02-06 07:50:00 --> Total execution time: 0.0538
INFO - 2018-02-06 07:50:00 --> Config Class Initialized
INFO - 2018-02-06 07:50:00 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:50:00 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:50:00 --> Utf8 Class Initialized
INFO - 2018-02-06 07:50:00 --> URI Class Initialized
INFO - 2018-02-06 07:50:00 --> Router Class Initialized
INFO - 2018-02-06 07:50:00 --> Output Class Initialized
INFO - 2018-02-06 07:50:00 --> Security Class Initialized
DEBUG - 2018-02-06 07:50:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:50:00 --> Input Class Initialized
INFO - 2018-02-06 07:50:00 --> Language Class Initialized
INFO - 2018-02-06 07:50:00 --> Loader Class Initialized
INFO - 2018-02-06 07:50:00 --> Helper loaded: url_helper
INFO - 2018-02-06 07:50:00 --> Helper loaded: form_helper
INFO - 2018-02-06 07:50:00 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:50:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:50:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:50:00 --> Form Validation Class Initialized
INFO - 2018-02-06 07:50:00 --> Model Class Initialized
INFO - 2018-02-06 07:50:00 --> Controller Class Initialized
INFO - 2018-02-06 07:50:00 --> Model Class Initialized
DEBUG - 2018-02-06 07:50:00 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:50:00 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:50:00 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:50:00 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:50:00 --> Final output sent to browser
DEBUG - 2018-02-06 07:50:00 --> Total execution time: 0.0485
INFO - 2018-02-06 07:50:00 --> Config Class Initialized
INFO - 2018-02-06 07:50:00 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:50:00 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:50:00 --> Utf8 Class Initialized
INFO - 2018-02-06 07:50:00 --> URI Class Initialized
INFO - 2018-02-06 07:50:00 --> Router Class Initialized
INFO - 2018-02-06 07:50:00 --> Output Class Initialized
INFO - 2018-02-06 07:50:00 --> Security Class Initialized
DEBUG - 2018-02-06 07:50:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:50:00 --> Input Class Initialized
INFO - 2018-02-06 07:50:00 --> Language Class Initialized
INFO - 2018-02-06 07:50:00 --> Loader Class Initialized
INFO - 2018-02-06 07:50:00 --> Helper loaded: url_helper
INFO - 2018-02-06 07:50:00 --> Helper loaded: form_helper
INFO - 2018-02-06 07:50:00 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:50:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:50:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:50:01 --> Form Validation Class Initialized
INFO - 2018-02-06 07:50:01 --> Model Class Initialized
INFO - 2018-02-06 07:50:01 --> Controller Class Initialized
INFO - 2018-02-06 07:50:01 --> Model Class Initialized
DEBUG - 2018-02-06 07:50:01 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:50:01 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:50:01 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:50:01 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:50:01 --> Final output sent to browser
DEBUG - 2018-02-06 07:50:01 --> Total execution time: 0.0422
INFO - 2018-02-06 07:50:01 --> Config Class Initialized
INFO - 2018-02-06 07:50:01 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:50:01 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:50:01 --> Utf8 Class Initialized
INFO - 2018-02-06 07:50:01 --> URI Class Initialized
INFO - 2018-02-06 07:50:01 --> Router Class Initialized
INFO - 2018-02-06 07:50:01 --> Output Class Initialized
INFO - 2018-02-06 07:50:01 --> Security Class Initialized
DEBUG - 2018-02-06 07:50:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:50:01 --> Input Class Initialized
INFO - 2018-02-06 07:50:01 --> Language Class Initialized
INFO - 2018-02-06 07:50:01 --> Loader Class Initialized
INFO - 2018-02-06 07:50:01 --> Helper loaded: url_helper
INFO - 2018-02-06 07:50:01 --> Helper loaded: form_helper
INFO - 2018-02-06 07:50:01 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:50:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:50:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:50:01 --> Form Validation Class Initialized
INFO - 2018-02-06 07:50:01 --> Model Class Initialized
INFO - 2018-02-06 07:50:01 --> Controller Class Initialized
INFO - 2018-02-06 07:50:01 --> Model Class Initialized
DEBUG - 2018-02-06 07:50:01 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:50:01 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:50:01 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:50:01 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:50:01 --> Final output sent to browser
DEBUG - 2018-02-06 07:50:01 --> Total execution time: 0.0420
INFO - 2018-02-06 07:50:01 --> Config Class Initialized
INFO - 2018-02-06 07:50:01 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:50:01 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:50:01 --> Utf8 Class Initialized
INFO - 2018-02-06 07:50:01 --> URI Class Initialized
INFO - 2018-02-06 07:50:01 --> Router Class Initialized
INFO - 2018-02-06 07:50:01 --> Output Class Initialized
INFO - 2018-02-06 07:50:01 --> Security Class Initialized
DEBUG - 2018-02-06 07:50:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:50:01 --> Input Class Initialized
INFO - 2018-02-06 07:50:01 --> Language Class Initialized
INFO - 2018-02-06 07:50:01 --> Loader Class Initialized
INFO - 2018-02-06 07:50:01 --> Helper loaded: url_helper
INFO - 2018-02-06 07:50:01 --> Helper loaded: form_helper
INFO - 2018-02-06 07:50:01 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:50:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:50:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:50:01 --> Form Validation Class Initialized
INFO - 2018-02-06 07:50:01 --> Model Class Initialized
INFO - 2018-02-06 07:50:01 --> Controller Class Initialized
INFO - 2018-02-06 07:50:01 --> Model Class Initialized
DEBUG - 2018-02-06 07:50:01 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:50:01 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:50:01 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:50:01 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:50:01 --> Final output sent to browser
DEBUG - 2018-02-06 07:50:01 --> Total execution time: 0.0413
INFO - 2018-02-06 07:50:01 --> Config Class Initialized
INFO - 2018-02-06 07:50:01 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:50:01 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:50:01 --> Utf8 Class Initialized
INFO - 2018-02-06 07:50:01 --> URI Class Initialized
INFO - 2018-02-06 07:50:01 --> Router Class Initialized
INFO - 2018-02-06 07:50:01 --> Output Class Initialized
INFO - 2018-02-06 07:50:01 --> Security Class Initialized
DEBUG - 2018-02-06 07:50:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:50:01 --> Input Class Initialized
INFO - 2018-02-06 07:50:01 --> Language Class Initialized
INFO - 2018-02-06 07:50:01 --> Loader Class Initialized
INFO - 2018-02-06 07:50:01 --> Helper loaded: url_helper
INFO - 2018-02-06 07:50:01 --> Helper loaded: form_helper
INFO - 2018-02-06 07:50:01 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:50:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:50:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:50:01 --> Form Validation Class Initialized
INFO - 2018-02-06 07:50:01 --> Model Class Initialized
INFO - 2018-02-06 07:50:01 --> Controller Class Initialized
INFO - 2018-02-06 07:50:01 --> Model Class Initialized
DEBUG - 2018-02-06 07:50:01 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:50:01 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:50:01 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:50:01 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:50:01 --> Final output sent to browser
DEBUG - 2018-02-06 07:50:01 --> Total execution time: 0.0412
INFO - 2018-02-06 07:50:01 --> Config Class Initialized
INFO - 2018-02-06 07:50:01 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:50:01 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:50:01 --> Utf8 Class Initialized
INFO - 2018-02-06 07:50:01 --> URI Class Initialized
INFO - 2018-02-06 07:50:01 --> Router Class Initialized
INFO - 2018-02-06 07:50:01 --> Output Class Initialized
INFO - 2018-02-06 07:50:01 --> Security Class Initialized
DEBUG - 2018-02-06 07:50:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:50:01 --> Input Class Initialized
INFO - 2018-02-06 07:50:01 --> Language Class Initialized
INFO - 2018-02-06 07:50:01 --> Loader Class Initialized
INFO - 2018-02-06 07:50:01 --> Helper loaded: url_helper
INFO - 2018-02-06 07:50:01 --> Helper loaded: form_helper
INFO - 2018-02-06 07:50:01 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:50:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:50:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:50:01 --> Form Validation Class Initialized
INFO - 2018-02-06 07:50:01 --> Model Class Initialized
INFO - 2018-02-06 07:50:01 --> Controller Class Initialized
INFO - 2018-02-06 07:50:01 --> Model Class Initialized
DEBUG - 2018-02-06 07:50:01 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:50:01 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:50:01 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:50:01 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:50:01 --> Final output sent to browser
DEBUG - 2018-02-06 07:50:01 --> Total execution time: 0.0421
INFO - 2018-02-06 07:50:01 --> Config Class Initialized
INFO - 2018-02-06 07:50:01 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:50:01 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:50:01 --> Utf8 Class Initialized
INFO - 2018-02-06 07:50:01 --> URI Class Initialized
INFO - 2018-02-06 07:50:01 --> Router Class Initialized
INFO - 2018-02-06 07:50:01 --> Output Class Initialized
INFO - 2018-02-06 07:50:01 --> Security Class Initialized
DEBUG - 2018-02-06 07:50:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:50:01 --> Input Class Initialized
INFO - 2018-02-06 07:50:01 --> Language Class Initialized
INFO - 2018-02-06 07:50:01 --> Loader Class Initialized
INFO - 2018-02-06 07:50:01 --> Helper loaded: url_helper
INFO - 2018-02-06 07:50:01 --> Helper loaded: form_helper
INFO - 2018-02-06 07:50:01 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:50:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:50:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:50:01 --> Form Validation Class Initialized
INFO - 2018-02-06 07:50:01 --> Model Class Initialized
INFO - 2018-02-06 07:50:01 --> Controller Class Initialized
INFO - 2018-02-06 07:50:01 --> Model Class Initialized
DEBUG - 2018-02-06 07:50:01 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:50:01 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:50:01 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:50:01 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:50:01 --> Final output sent to browser
DEBUG - 2018-02-06 07:50:01 --> Total execution time: 0.0523
INFO - 2018-02-06 07:50:03 --> Config Class Initialized
INFO - 2018-02-06 07:50:03 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:50:03 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:50:03 --> Utf8 Class Initialized
INFO - 2018-02-06 07:50:03 --> URI Class Initialized
INFO - 2018-02-06 07:50:03 --> Router Class Initialized
INFO - 2018-02-06 07:50:03 --> Output Class Initialized
INFO - 2018-02-06 07:50:03 --> Security Class Initialized
DEBUG - 2018-02-06 07:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:50:03 --> Input Class Initialized
INFO - 2018-02-06 07:50:03 --> Language Class Initialized
INFO - 2018-02-06 07:50:03 --> Loader Class Initialized
INFO - 2018-02-06 07:50:03 --> Helper loaded: url_helper
INFO - 2018-02-06 07:50:03 --> Helper loaded: form_helper
INFO - 2018-02-06 07:50:03 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:50:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:50:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:50:03 --> Form Validation Class Initialized
INFO - 2018-02-06 07:50:03 --> Model Class Initialized
INFO - 2018-02-06 07:50:03 --> Controller Class Initialized
INFO - 2018-02-06 07:50:03 --> Model Class Initialized
DEBUG - 2018-02-06 07:50:03 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:50:03 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:50:03 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:50:03 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:50:03 --> Final output sent to browser
DEBUG - 2018-02-06 07:50:03 --> Total execution time: 0.0428
INFO - 2018-02-06 07:50:30 --> Config Class Initialized
INFO - 2018-02-06 07:50:30 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:50:30 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:50:30 --> Utf8 Class Initialized
INFO - 2018-02-06 07:50:30 --> URI Class Initialized
INFO - 2018-02-06 07:50:30 --> Router Class Initialized
INFO - 2018-02-06 07:50:30 --> Output Class Initialized
INFO - 2018-02-06 07:50:30 --> Security Class Initialized
DEBUG - 2018-02-06 07:50:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:50:30 --> Input Class Initialized
INFO - 2018-02-06 07:50:30 --> Language Class Initialized
INFO - 2018-02-06 07:50:30 --> Loader Class Initialized
INFO - 2018-02-06 07:50:30 --> Helper loaded: url_helper
INFO - 2018-02-06 07:50:30 --> Helper loaded: form_helper
INFO - 2018-02-06 07:50:30 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:50:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:50:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:50:30 --> Form Validation Class Initialized
INFO - 2018-02-06 07:50:30 --> Model Class Initialized
INFO - 2018-02-06 07:50:30 --> Controller Class Initialized
INFO - 2018-02-06 07:50:30 --> Model Class Initialized
DEBUG - 2018-02-06 07:50:30 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:50:30 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:50:30 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:50:30 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:50:30 --> Final output sent to browser
DEBUG - 2018-02-06 07:50:30 --> Total execution time: 0.0551
INFO - 2018-02-06 07:50:30 --> Config Class Initialized
INFO - 2018-02-06 07:50:30 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:50:30 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:50:30 --> Utf8 Class Initialized
INFO - 2018-02-06 07:50:30 --> URI Class Initialized
INFO - 2018-02-06 07:50:30 --> Router Class Initialized
INFO - 2018-02-06 07:50:30 --> Output Class Initialized
INFO - 2018-02-06 07:50:30 --> Security Class Initialized
DEBUG - 2018-02-06 07:50:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:50:30 --> Input Class Initialized
INFO - 2018-02-06 07:50:30 --> Language Class Initialized
INFO - 2018-02-06 07:50:30 --> Loader Class Initialized
INFO - 2018-02-06 07:50:30 --> Helper loaded: url_helper
INFO - 2018-02-06 07:50:30 --> Helper loaded: form_helper
INFO - 2018-02-06 07:50:30 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:50:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:50:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:50:30 --> Form Validation Class Initialized
INFO - 2018-02-06 07:50:30 --> Model Class Initialized
INFO - 2018-02-06 07:50:30 --> Controller Class Initialized
INFO - 2018-02-06 07:50:30 --> Model Class Initialized
DEBUG - 2018-02-06 07:50:30 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:50:30 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:50:30 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:50:30 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:50:30 --> Final output sent to browser
DEBUG - 2018-02-06 07:50:30 --> Total execution time: 0.0630
INFO - 2018-02-06 07:50:30 --> Config Class Initialized
INFO - 2018-02-06 07:50:30 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:50:30 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:50:30 --> Utf8 Class Initialized
INFO - 2018-02-06 07:50:30 --> URI Class Initialized
INFO - 2018-02-06 07:50:30 --> Router Class Initialized
INFO - 2018-02-06 07:50:30 --> Output Class Initialized
INFO - 2018-02-06 07:50:30 --> Security Class Initialized
DEBUG - 2018-02-06 07:50:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:50:30 --> Input Class Initialized
INFO - 2018-02-06 07:50:30 --> Language Class Initialized
INFO - 2018-02-06 07:50:30 --> Loader Class Initialized
INFO - 2018-02-06 07:50:30 --> Helper loaded: url_helper
INFO - 2018-02-06 07:50:30 --> Helper loaded: form_helper
INFO - 2018-02-06 07:50:30 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:50:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:50:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:50:30 --> Form Validation Class Initialized
INFO - 2018-02-06 07:50:30 --> Model Class Initialized
INFO - 2018-02-06 07:50:30 --> Controller Class Initialized
INFO - 2018-02-06 07:50:30 --> Model Class Initialized
DEBUG - 2018-02-06 07:50:30 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:50:30 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:50:30 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:50:30 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:50:30 --> Final output sent to browser
DEBUG - 2018-02-06 07:50:30 --> Total execution time: 0.0739
INFO - 2018-02-06 07:50:32 --> Config Class Initialized
INFO - 2018-02-06 07:50:32 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:50:32 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:50:32 --> Utf8 Class Initialized
INFO - 2018-02-06 07:50:32 --> URI Class Initialized
INFO - 2018-02-06 07:50:32 --> Router Class Initialized
INFO - 2018-02-06 07:50:32 --> Output Class Initialized
INFO - 2018-02-06 07:50:32 --> Security Class Initialized
DEBUG - 2018-02-06 07:50:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:50:32 --> Input Class Initialized
INFO - 2018-02-06 07:50:32 --> Language Class Initialized
INFO - 2018-02-06 07:50:32 --> Loader Class Initialized
INFO - 2018-02-06 07:50:32 --> Helper loaded: url_helper
INFO - 2018-02-06 07:50:32 --> Helper loaded: form_helper
INFO - 2018-02-06 07:50:32 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:50:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:50:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:50:32 --> Form Validation Class Initialized
INFO - 2018-02-06 07:50:32 --> Model Class Initialized
INFO - 2018-02-06 07:50:32 --> Controller Class Initialized
INFO - 2018-02-06 07:50:32 --> Model Class Initialized
DEBUG - 2018-02-06 07:50:32 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:50:32 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:50:32 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:50:32 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:50:32 --> Final output sent to browser
DEBUG - 2018-02-06 07:50:32 --> Total execution time: 0.0511
INFO - 2018-02-06 07:50:32 --> Config Class Initialized
INFO - 2018-02-06 07:50:32 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:50:32 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:50:32 --> Utf8 Class Initialized
INFO - 2018-02-06 07:50:32 --> URI Class Initialized
INFO - 2018-02-06 07:50:32 --> Router Class Initialized
INFO - 2018-02-06 07:50:32 --> Output Class Initialized
INFO - 2018-02-06 07:50:32 --> Security Class Initialized
DEBUG - 2018-02-06 07:50:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:50:32 --> Input Class Initialized
INFO - 2018-02-06 07:50:32 --> Language Class Initialized
INFO - 2018-02-06 07:50:32 --> Loader Class Initialized
INFO - 2018-02-06 07:50:32 --> Helper loaded: url_helper
INFO - 2018-02-06 07:50:32 --> Helper loaded: form_helper
INFO - 2018-02-06 07:50:32 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:50:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:50:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:50:32 --> Form Validation Class Initialized
INFO - 2018-02-06 07:50:32 --> Model Class Initialized
INFO - 2018-02-06 07:50:32 --> Controller Class Initialized
INFO - 2018-02-06 07:50:32 --> Model Class Initialized
DEBUG - 2018-02-06 07:50:32 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:50:32 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:50:32 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:50:32 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:50:32 --> Final output sent to browser
DEBUG - 2018-02-06 07:50:32 --> Total execution time: 0.0556
INFO - 2018-02-06 07:50:32 --> Config Class Initialized
INFO - 2018-02-06 07:50:32 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:50:32 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:50:32 --> Utf8 Class Initialized
INFO - 2018-02-06 07:50:32 --> URI Class Initialized
INFO - 2018-02-06 07:50:32 --> Router Class Initialized
INFO - 2018-02-06 07:50:32 --> Output Class Initialized
INFO - 2018-02-06 07:50:32 --> Security Class Initialized
DEBUG - 2018-02-06 07:50:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:50:32 --> Input Class Initialized
INFO - 2018-02-06 07:50:32 --> Language Class Initialized
INFO - 2018-02-06 07:50:33 --> Loader Class Initialized
INFO - 2018-02-06 07:50:33 --> Helper loaded: url_helper
INFO - 2018-02-06 07:50:33 --> Helper loaded: form_helper
INFO - 2018-02-06 07:50:33 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:50:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:50:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:50:33 --> Form Validation Class Initialized
INFO - 2018-02-06 07:50:33 --> Model Class Initialized
INFO - 2018-02-06 07:50:33 --> Controller Class Initialized
INFO - 2018-02-06 07:50:33 --> Model Class Initialized
DEBUG - 2018-02-06 07:50:33 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:50:33 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:50:33 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:50:33 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:50:33 --> Final output sent to browser
DEBUG - 2018-02-06 07:50:33 --> Total execution time: 0.0538
INFO - 2018-02-06 07:50:33 --> Config Class Initialized
INFO - 2018-02-06 07:50:33 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:50:33 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:50:33 --> Utf8 Class Initialized
INFO - 2018-02-06 07:50:33 --> URI Class Initialized
INFO - 2018-02-06 07:50:33 --> Router Class Initialized
INFO - 2018-02-06 07:50:33 --> Output Class Initialized
INFO - 2018-02-06 07:50:33 --> Security Class Initialized
DEBUG - 2018-02-06 07:50:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:50:33 --> Input Class Initialized
INFO - 2018-02-06 07:50:33 --> Language Class Initialized
INFO - 2018-02-06 07:50:33 --> Loader Class Initialized
INFO - 2018-02-06 07:50:33 --> Helper loaded: url_helper
INFO - 2018-02-06 07:50:33 --> Helper loaded: form_helper
INFO - 2018-02-06 07:50:33 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:50:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:50:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:50:33 --> Form Validation Class Initialized
INFO - 2018-02-06 07:50:33 --> Model Class Initialized
INFO - 2018-02-06 07:50:33 --> Controller Class Initialized
INFO - 2018-02-06 07:50:33 --> Model Class Initialized
DEBUG - 2018-02-06 07:50:33 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:50:33 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:50:33 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:50:33 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:50:33 --> Final output sent to browser
DEBUG - 2018-02-06 07:50:33 --> Total execution time: 0.0527
INFO - 2018-02-06 07:50:33 --> Config Class Initialized
INFO - 2018-02-06 07:50:33 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:50:33 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:50:33 --> Utf8 Class Initialized
INFO - 2018-02-06 07:50:33 --> URI Class Initialized
INFO - 2018-02-06 07:50:33 --> Router Class Initialized
INFO - 2018-02-06 07:50:33 --> Output Class Initialized
INFO - 2018-02-06 07:50:33 --> Security Class Initialized
DEBUG - 2018-02-06 07:50:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:50:33 --> Input Class Initialized
INFO - 2018-02-06 07:50:33 --> Language Class Initialized
INFO - 2018-02-06 07:50:33 --> Loader Class Initialized
INFO - 2018-02-06 07:50:33 --> Helper loaded: url_helper
INFO - 2018-02-06 07:50:33 --> Helper loaded: form_helper
INFO - 2018-02-06 07:50:33 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:50:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:50:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:50:33 --> Form Validation Class Initialized
INFO - 2018-02-06 07:50:33 --> Model Class Initialized
INFO - 2018-02-06 07:50:33 --> Controller Class Initialized
INFO - 2018-02-06 07:50:33 --> Model Class Initialized
DEBUG - 2018-02-06 07:50:33 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:50:33 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:50:33 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:50:33 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:50:33 --> Final output sent to browser
DEBUG - 2018-02-06 07:50:33 --> Total execution time: 0.0787
INFO - 2018-02-06 07:50:33 --> Config Class Initialized
INFO - 2018-02-06 07:50:33 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:50:33 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:50:33 --> Utf8 Class Initialized
INFO - 2018-02-06 07:50:33 --> URI Class Initialized
INFO - 2018-02-06 07:50:33 --> Router Class Initialized
INFO - 2018-02-06 07:50:33 --> Output Class Initialized
INFO - 2018-02-06 07:50:33 --> Security Class Initialized
DEBUG - 2018-02-06 07:50:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:50:33 --> Input Class Initialized
INFO - 2018-02-06 07:50:33 --> Language Class Initialized
INFO - 2018-02-06 07:50:33 --> Loader Class Initialized
INFO - 2018-02-06 07:50:33 --> Helper loaded: url_helper
INFO - 2018-02-06 07:50:33 --> Helper loaded: form_helper
INFO - 2018-02-06 07:50:33 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:50:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:50:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:50:33 --> Form Validation Class Initialized
INFO - 2018-02-06 07:50:33 --> Model Class Initialized
INFO - 2018-02-06 07:50:33 --> Controller Class Initialized
INFO - 2018-02-06 07:50:33 --> Model Class Initialized
DEBUG - 2018-02-06 07:50:33 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:50:33 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:50:33 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:50:33 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:50:33 --> Final output sent to browser
DEBUG - 2018-02-06 07:50:33 --> Total execution time: 0.0482
INFO - 2018-02-06 07:50:33 --> Config Class Initialized
INFO - 2018-02-06 07:50:33 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:50:33 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:50:33 --> Utf8 Class Initialized
INFO - 2018-02-06 07:50:33 --> URI Class Initialized
INFO - 2018-02-06 07:50:33 --> Router Class Initialized
INFO - 2018-02-06 07:50:33 --> Output Class Initialized
INFO - 2018-02-06 07:50:33 --> Security Class Initialized
DEBUG - 2018-02-06 07:50:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:50:33 --> Input Class Initialized
INFO - 2018-02-06 07:50:33 --> Language Class Initialized
INFO - 2018-02-06 07:50:33 --> Loader Class Initialized
INFO - 2018-02-06 07:50:33 --> Helper loaded: url_helper
INFO - 2018-02-06 07:50:33 --> Helper loaded: form_helper
INFO - 2018-02-06 07:50:33 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:50:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:50:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:50:33 --> Form Validation Class Initialized
INFO - 2018-02-06 07:50:33 --> Model Class Initialized
INFO - 2018-02-06 07:50:33 --> Controller Class Initialized
INFO - 2018-02-06 07:50:33 --> Model Class Initialized
DEBUG - 2018-02-06 07:50:33 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:50:33 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:50:33 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:50:33 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:50:33 --> Final output sent to browser
DEBUG - 2018-02-06 07:50:33 --> Total execution time: 0.0544
INFO - 2018-02-06 07:50:33 --> Config Class Initialized
INFO - 2018-02-06 07:50:33 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:50:33 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:50:33 --> Utf8 Class Initialized
INFO - 2018-02-06 07:50:33 --> URI Class Initialized
INFO - 2018-02-06 07:50:33 --> Router Class Initialized
INFO - 2018-02-06 07:50:33 --> Output Class Initialized
INFO - 2018-02-06 07:50:33 --> Security Class Initialized
DEBUG - 2018-02-06 07:50:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:50:33 --> Input Class Initialized
INFO - 2018-02-06 07:50:33 --> Language Class Initialized
INFO - 2018-02-06 07:50:33 --> Loader Class Initialized
INFO - 2018-02-06 07:50:33 --> Helper loaded: url_helper
INFO - 2018-02-06 07:50:33 --> Helper loaded: form_helper
INFO - 2018-02-06 07:50:33 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:50:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:50:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:50:33 --> Form Validation Class Initialized
INFO - 2018-02-06 07:50:33 --> Model Class Initialized
INFO - 2018-02-06 07:50:33 --> Controller Class Initialized
INFO - 2018-02-06 07:50:33 --> Model Class Initialized
DEBUG - 2018-02-06 07:50:33 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:50:33 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:50:33 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:50:33 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:50:33 --> Final output sent to browser
DEBUG - 2018-02-06 07:50:33 --> Total execution time: 0.0467
INFO - 2018-02-06 07:50:34 --> Config Class Initialized
INFO - 2018-02-06 07:50:34 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:50:34 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:50:34 --> Utf8 Class Initialized
INFO - 2018-02-06 07:50:34 --> URI Class Initialized
INFO - 2018-02-06 07:50:34 --> Router Class Initialized
INFO - 2018-02-06 07:50:34 --> Output Class Initialized
INFO - 2018-02-06 07:50:34 --> Security Class Initialized
DEBUG - 2018-02-06 07:50:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:50:34 --> Input Class Initialized
INFO - 2018-02-06 07:50:34 --> Language Class Initialized
INFO - 2018-02-06 07:50:34 --> Loader Class Initialized
INFO - 2018-02-06 07:50:34 --> Helper loaded: url_helper
INFO - 2018-02-06 07:50:34 --> Helper loaded: form_helper
INFO - 2018-02-06 07:50:34 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:50:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:50:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:50:34 --> Form Validation Class Initialized
INFO - 2018-02-06 07:50:34 --> Model Class Initialized
INFO - 2018-02-06 07:50:34 --> Controller Class Initialized
INFO - 2018-02-06 07:50:34 --> Model Class Initialized
DEBUG - 2018-02-06 07:50:34 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:50:34 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:50:34 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:50:34 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:50:34 --> Final output sent to browser
DEBUG - 2018-02-06 07:50:34 --> Total execution time: 0.0492
INFO - 2018-02-06 07:50:34 --> Config Class Initialized
INFO - 2018-02-06 07:50:34 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:50:34 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:50:34 --> Utf8 Class Initialized
INFO - 2018-02-06 07:50:34 --> URI Class Initialized
INFO - 2018-02-06 07:50:34 --> Router Class Initialized
INFO - 2018-02-06 07:50:34 --> Output Class Initialized
INFO - 2018-02-06 07:50:34 --> Security Class Initialized
DEBUG - 2018-02-06 07:50:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:50:34 --> Input Class Initialized
INFO - 2018-02-06 07:50:34 --> Language Class Initialized
INFO - 2018-02-06 07:50:34 --> Loader Class Initialized
INFO - 2018-02-06 07:50:34 --> Helper loaded: url_helper
INFO - 2018-02-06 07:50:34 --> Helper loaded: form_helper
INFO - 2018-02-06 07:50:34 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:50:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:50:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:50:34 --> Form Validation Class Initialized
INFO - 2018-02-06 07:50:34 --> Model Class Initialized
INFO - 2018-02-06 07:50:34 --> Controller Class Initialized
INFO - 2018-02-06 07:50:34 --> Model Class Initialized
DEBUG - 2018-02-06 07:50:34 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:50:34 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:50:34 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:50:34 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:50:34 --> Final output sent to browser
DEBUG - 2018-02-06 07:50:34 --> Total execution time: 0.0553
INFO - 2018-02-06 07:50:34 --> Config Class Initialized
INFO - 2018-02-06 07:50:34 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:50:34 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:50:34 --> Utf8 Class Initialized
INFO - 2018-02-06 07:50:34 --> URI Class Initialized
INFO - 2018-02-06 07:50:34 --> Router Class Initialized
INFO - 2018-02-06 07:50:34 --> Output Class Initialized
INFO - 2018-02-06 07:50:34 --> Security Class Initialized
DEBUG - 2018-02-06 07:50:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:50:34 --> Input Class Initialized
INFO - 2018-02-06 07:50:34 --> Language Class Initialized
INFO - 2018-02-06 07:50:34 --> Loader Class Initialized
INFO - 2018-02-06 07:50:34 --> Helper loaded: url_helper
INFO - 2018-02-06 07:50:34 --> Helper loaded: form_helper
INFO - 2018-02-06 07:50:34 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:50:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:50:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:50:34 --> Form Validation Class Initialized
INFO - 2018-02-06 07:50:34 --> Model Class Initialized
INFO - 2018-02-06 07:50:34 --> Controller Class Initialized
INFO - 2018-02-06 07:50:34 --> Model Class Initialized
DEBUG - 2018-02-06 07:50:34 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:50:34 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:50:34 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:50:34 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:50:34 --> Final output sent to browser
DEBUG - 2018-02-06 07:50:34 --> Total execution time: 0.0448
INFO - 2018-02-06 07:50:34 --> Config Class Initialized
INFO - 2018-02-06 07:50:34 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:50:34 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:50:34 --> Utf8 Class Initialized
INFO - 2018-02-06 07:50:34 --> URI Class Initialized
INFO - 2018-02-06 07:50:34 --> Router Class Initialized
INFO - 2018-02-06 07:50:34 --> Output Class Initialized
INFO - 2018-02-06 07:50:34 --> Security Class Initialized
DEBUG - 2018-02-06 07:50:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:50:34 --> Input Class Initialized
INFO - 2018-02-06 07:50:34 --> Language Class Initialized
INFO - 2018-02-06 07:50:34 --> Loader Class Initialized
INFO - 2018-02-06 07:50:34 --> Helper loaded: url_helper
INFO - 2018-02-06 07:50:34 --> Helper loaded: form_helper
INFO - 2018-02-06 07:50:34 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:50:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:50:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:50:34 --> Form Validation Class Initialized
INFO - 2018-02-06 07:50:34 --> Model Class Initialized
INFO - 2018-02-06 07:50:34 --> Controller Class Initialized
INFO - 2018-02-06 07:50:34 --> Model Class Initialized
DEBUG - 2018-02-06 07:50:34 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:50:34 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:50:34 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:50:34 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:50:34 --> Final output sent to browser
DEBUG - 2018-02-06 07:50:34 --> Total execution time: 0.0445
INFO - 2018-02-06 07:50:34 --> Config Class Initialized
INFO - 2018-02-06 07:50:34 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:50:34 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:50:34 --> Utf8 Class Initialized
INFO - 2018-02-06 07:50:34 --> URI Class Initialized
INFO - 2018-02-06 07:50:34 --> Router Class Initialized
INFO - 2018-02-06 07:50:34 --> Output Class Initialized
INFO - 2018-02-06 07:50:34 --> Security Class Initialized
DEBUG - 2018-02-06 07:50:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:50:34 --> Input Class Initialized
INFO - 2018-02-06 07:50:34 --> Language Class Initialized
INFO - 2018-02-06 07:50:34 --> Loader Class Initialized
INFO - 2018-02-06 07:50:34 --> Helper loaded: url_helper
INFO - 2018-02-06 07:50:34 --> Helper loaded: form_helper
INFO - 2018-02-06 07:50:34 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:50:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:50:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:50:34 --> Form Validation Class Initialized
INFO - 2018-02-06 07:50:34 --> Model Class Initialized
INFO - 2018-02-06 07:50:34 --> Controller Class Initialized
INFO - 2018-02-06 07:50:34 --> Model Class Initialized
DEBUG - 2018-02-06 07:50:34 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:50:34 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:50:34 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:50:34 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:50:34 --> Final output sent to browser
DEBUG - 2018-02-06 07:50:34 --> Total execution time: 0.0453
INFO - 2018-02-06 07:50:35 --> Config Class Initialized
INFO - 2018-02-06 07:50:35 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:50:35 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:50:35 --> Utf8 Class Initialized
INFO - 2018-02-06 07:50:35 --> URI Class Initialized
INFO - 2018-02-06 07:50:35 --> Router Class Initialized
INFO - 2018-02-06 07:50:35 --> Output Class Initialized
INFO - 2018-02-06 07:50:35 --> Security Class Initialized
DEBUG - 2018-02-06 07:50:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:50:35 --> Input Class Initialized
INFO - 2018-02-06 07:50:35 --> Language Class Initialized
INFO - 2018-02-06 07:50:35 --> Loader Class Initialized
INFO - 2018-02-06 07:50:35 --> Helper loaded: url_helper
INFO - 2018-02-06 07:50:35 --> Helper loaded: form_helper
INFO - 2018-02-06 07:50:35 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:50:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:50:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:50:35 --> Form Validation Class Initialized
INFO - 2018-02-06 07:50:35 --> Model Class Initialized
INFO - 2018-02-06 07:50:35 --> Controller Class Initialized
INFO - 2018-02-06 07:50:35 --> Model Class Initialized
DEBUG - 2018-02-06 07:50:35 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:50:35 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:50:35 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:50:35 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:50:35 --> Final output sent to browser
DEBUG - 2018-02-06 07:50:35 --> Total execution time: 0.0426
INFO - 2018-02-06 07:50:35 --> Config Class Initialized
INFO - 2018-02-06 07:50:35 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:50:35 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:50:35 --> Utf8 Class Initialized
INFO - 2018-02-06 07:50:35 --> URI Class Initialized
INFO - 2018-02-06 07:50:35 --> Router Class Initialized
INFO - 2018-02-06 07:50:35 --> Output Class Initialized
INFO - 2018-02-06 07:50:35 --> Security Class Initialized
DEBUG - 2018-02-06 07:50:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:50:35 --> Input Class Initialized
INFO - 2018-02-06 07:50:35 --> Language Class Initialized
INFO - 2018-02-06 07:50:35 --> Loader Class Initialized
INFO - 2018-02-06 07:50:35 --> Helper loaded: url_helper
INFO - 2018-02-06 07:50:35 --> Helper loaded: form_helper
INFO - 2018-02-06 07:50:35 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:50:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:50:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:50:35 --> Form Validation Class Initialized
INFO - 2018-02-06 07:50:35 --> Model Class Initialized
INFO - 2018-02-06 07:50:35 --> Controller Class Initialized
INFO - 2018-02-06 07:50:35 --> Model Class Initialized
DEBUG - 2018-02-06 07:50:35 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:50:35 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:50:35 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:50:35 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:50:35 --> Final output sent to browser
DEBUG - 2018-02-06 07:50:35 --> Total execution time: 0.0450
INFO - 2018-02-06 07:50:36 --> Config Class Initialized
INFO - 2018-02-06 07:50:36 --> Hooks Class Initialized
INFO - 2018-02-06 07:50:36 --> Config Class Initialized
INFO - 2018-02-06 07:50:36 --> Hooks Class Initialized
INFO - 2018-02-06 07:50:36 --> Config Class Initialized
INFO - 2018-02-06 07:50:36 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:50:36 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:50:36 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:50:36 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:50:36 --> URI Class Initialized
INFO - 2018-02-06 07:50:36 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:50:36 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:50:36 --> Utf8 Class Initialized
INFO - 2018-02-06 07:50:36 --> Router Class Initialized
INFO - 2018-02-06 07:50:36 --> URI Class Initialized
INFO - 2018-02-06 07:50:36 --> URI Class Initialized
INFO - 2018-02-06 07:50:36 --> Output Class Initialized
INFO - 2018-02-06 07:50:36 --> Router Class Initialized
INFO - 2018-02-06 07:50:36 --> Router Class Initialized
INFO - 2018-02-06 07:50:36 --> Security Class Initialized
INFO - 2018-02-06 07:50:36 --> Output Class Initialized
INFO - 2018-02-06 07:50:36 --> Output Class Initialized
DEBUG - 2018-02-06 07:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:50:36 --> Input Class Initialized
INFO - 2018-02-06 07:50:36 --> Language Class Initialized
INFO - 2018-02-06 07:50:36 --> Security Class Initialized
INFO - 2018-02-06 07:50:36 --> Security Class Initialized
ERROR - 2018-02-06 07:50:36 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-02-06 07:50:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:50:36 --> Input Class Initialized
INFO - 2018-02-06 07:50:36 --> Input Class Initialized
INFO - 2018-02-06 07:50:36 --> Language Class Initialized
INFO - 2018-02-06 07:50:36 --> Language Class Initialized
ERROR - 2018-02-06 07:50:36 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-06 07:50:36 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-06 07:50:39 --> Config Class Initialized
INFO - 2018-02-06 07:50:39 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:50:39 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:50:39 --> Utf8 Class Initialized
INFO - 2018-02-06 07:50:39 --> URI Class Initialized
INFO - 2018-02-06 07:50:39 --> Router Class Initialized
INFO - 2018-02-06 07:50:39 --> Output Class Initialized
INFO - 2018-02-06 07:50:39 --> Security Class Initialized
DEBUG - 2018-02-06 07:50:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:50:39 --> Input Class Initialized
INFO - 2018-02-06 07:50:39 --> Language Class Initialized
INFO - 2018-02-06 07:50:39 --> Loader Class Initialized
INFO - 2018-02-06 07:50:39 --> Helper loaded: url_helper
INFO - 2018-02-06 07:50:39 --> Helper loaded: form_helper
INFO - 2018-02-06 07:50:39 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:50:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:50:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:50:39 --> Form Validation Class Initialized
INFO - 2018-02-06 07:50:39 --> Model Class Initialized
INFO - 2018-02-06 07:50:39 --> Controller Class Initialized
INFO - 2018-02-06 07:50:39 --> Model Class Initialized
DEBUG - 2018-02-06 07:50:39 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:50:39 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:50:39 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:50:39 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:50:39 --> Final output sent to browser
DEBUG - 2018-02-06 07:50:39 --> Total execution time: 0.0578
INFO - 2018-02-06 07:50:39 --> Config Class Initialized
INFO - 2018-02-06 07:50:39 --> Hooks Class Initialized
INFO - 2018-02-06 07:50:39 --> Config Class Initialized
INFO - 2018-02-06 07:50:39 --> Hooks Class Initialized
INFO - 2018-02-06 07:50:39 --> Config Class Initialized
INFO - 2018-02-06 07:50:39 --> Hooks Class Initialized
INFO - 2018-02-06 07:50:39 --> Config Class Initialized
INFO - 2018-02-06 07:50:39 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:50:39 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:50:39 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:50:39 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:50:39 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:50:39 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:50:39 --> Utf8 Class Initialized
INFO - 2018-02-06 07:50:39 --> URI Class Initialized
INFO - 2018-02-06 07:50:39 --> URI Class Initialized
INFO - 2018-02-06 07:50:39 --> URI Class Initialized
DEBUG - 2018-02-06 07:50:39 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:50:39 --> Router Class Initialized
INFO - 2018-02-06 07:50:39 --> Utf8 Class Initialized
INFO - 2018-02-06 07:50:39 --> Router Class Initialized
INFO - 2018-02-06 07:50:39 --> URI Class Initialized
INFO - 2018-02-06 07:50:39 --> Router Class Initialized
INFO - 2018-02-06 07:50:39 --> Output Class Initialized
INFO - 2018-02-06 07:50:39 --> Router Class Initialized
INFO - 2018-02-06 07:50:39 --> Output Class Initialized
INFO - 2018-02-06 07:50:39 --> Security Class Initialized
INFO - 2018-02-06 07:50:39 --> Output Class Initialized
DEBUG - 2018-02-06 07:50:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:50:39 --> Output Class Initialized
INFO - 2018-02-06 07:50:39 --> Security Class Initialized
INFO - 2018-02-06 07:50:39 --> Security Class Initialized
INFO - 2018-02-06 07:50:39 --> Input Class Initialized
INFO - 2018-02-06 07:50:39 --> Language Class Initialized
DEBUG - 2018-02-06 07:50:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:50:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:50:39 --> Security Class Initialized
INFO - 2018-02-06 07:50:39 --> Input Class Initialized
INFO - 2018-02-06 07:50:39 --> Input Class Initialized
ERROR - 2018-02-06 07:50:39 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:50:39 --> Language Class Initialized
INFO - 2018-02-06 07:50:39 --> Language Class Initialized
DEBUG - 2018-02-06 07:50:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:50:39 --> Input Class Initialized
ERROR - 2018-02-06 07:50:39 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:50:39 --> Language Class Initialized
ERROR - 2018-02-06 07:50:39 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-06 07:50:39 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:50:39 --> Config Class Initialized
INFO - 2018-02-06 07:50:39 --> Hooks Class Initialized
INFO - 2018-02-06 07:50:39 --> Config Class Initialized
INFO - 2018-02-06 07:50:39 --> Config Class Initialized
INFO - 2018-02-06 07:50:39 --> Hooks Class Initialized
INFO - 2018-02-06 07:50:39 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:50:39 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:50:39 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:50:39 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:50:39 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:50:39 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:50:39 --> Utf8 Class Initialized
INFO - 2018-02-06 07:50:39 --> URI Class Initialized
INFO - 2018-02-06 07:50:39 --> URI Class Initialized
INFO - 2018-02-06 07:50:39 --> URI Class Initialized
INFO - 2018-02-06 07:50:39 --> Router Class Initialized
INFO - 2018-02-06 07:50:39 --> Router Class Initialized
INFO - 2018-02-06 07:50:39 --> Router Class Initialized
INFO - 2018-02-06 07:50:39 --> Output Class Initialized
INFO - 2018-02-06 07:50:39 --> Output Class Initialized
INFO - 2018-02-06 07:50:39 --> Security Class Initialized
INFO - 2018-02-06 07:50:39 --> Output Class Initialized
INFO - 2018-02-06 07:50:39 --> Security Class Initialized
DEBUG - 2018-02-06 07:50:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:50:39 --> Security Class Initialized
INFO - 2018-02-06 07:50:39 --> Input Class Initialized
DEBUG - 2018-02-06 07:50:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:50:39 --> Input Class Initialized
INFO - 2018-02-06 07:50:39 --> Language Class Initialized
DEBUG - 2018-02-06 07:50:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:50:39 --> Input Class Initialized
INFO - 2018-02-06 07:50:39 --> Language Class Initialized
INFO - 2018-02-06 07:50:39 --> Language Class Initialized
ERROR - 2018-02-06 07:50:39 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-06 07:50:39 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-06 07:50:39 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-06 07:50:40 --> Config Class Initialized
INFO - 2018-02-06 07:50:40 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:50:40 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:50:40 --> Utf8 Class Initialized
INFO - 2018-02-06 07:50:40 --> URI Class Initialized
INFO - 2018-02-06 07:50:40 --> Router Class Initialized
INFO - 2018-02-06 07:50:40 --> Output Class Initialized
INFO - 2018-02-06 07:50:40 --> Security Class Initialized
DEBUG - 2018-02-06 07:50:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:50:40 --> Input Class Initialized
INFO - 2018-02-06 07:50:40 --> Language Class Initialized
INFO - 2018-02-06 07:50:40 --> Loader Class Initialized
INFO - 2018-02-06 07:50:40 --> Helper loaded: url_helper
INFO - 2018-02-06 07:50:40 --> Helper loaded: form_helper
INFO - 2018-02-06 07:50:40 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:50:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:50:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:50:40 --> Form Validation Class Initialized
INFO - 2018-02-06 07:50:40 --> Model Class Initialized
INFO - 2018-02-06 07:50:40 --> Controller Class Initialized
INFO - 2018-02-06 07:50:40 --> Model Class Initialized
DEBUG - 2018-02-06 07:50:40 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:50:40 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:50:40 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:50:40 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:50:40 --> Final output sent to browser
DEBUG - 2018-02-06 07:50:40 --> Total execution time: 0.0607
INFO - 2018-02-06 07:50:40 --> Config Class Initialized
INFO - 2018-02-06 07:50:40 --> Hooks Class Initialized
INFO - 2018-02-06 07:50:40 --> Config Class Initialized
INFO - 2018-02-06 07:50:40 --> Hooks Class Initialized
INFO - 2018-02-06 07:50:40 --> Config Class Initialized
INFO - 2018-02-06 07:50:40 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:50:40 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:50:40 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:50:40 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:50:40 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:50:40 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:50:40 --> Utf8 Class Initialized
INFO - 2018-02-06 07:50:40 --> Config Class Initialized
INFO - 2018-02-06 07:50:40 --> URI Class Initialized
INFO - 2018-02-06 07:50:40 --> Hooks Class Initialized
INFO - 2018-02-06 07:50:40 --> URI Class Initialized
INFO - 2018-02-06 07:50:40 --> URI Class Initialized
INFO - 2018-02-06 07:50:40 --> Router Class Initialized
INFO - 2018-02-06 07:50:40 --> Router Class Initialized
INFO - 2018-02-06 07:50:40 --> Router Class Initialized
DEBUG - 2018-02-06 07:50:40 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:50:40 --> Utf8 Class Initialized
INFO - 2018-02-06 07:50:40 --> Output Class Initialized
INFO - 2018-02-06 07:50:40 --> Output Class Initialized
INFO - 2018-02-06 07:50:40 --> Output Class Initialized
INFO - 2018-02-06 07:50:40 --> URI Class Initialized
INFO - 2018-02-06 07:50:40 --> Security Class Initialized
INFO - 2018-02-06 07:50:40 --> Security Class Initialized
INFO - 2018-02-06 07:50:40 --> Security Class Initialized
INFO - 2018-02-06 07:50:40 --> Router Class Initialized
DEBUG - 2018-02-06 07:50:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:50:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:50:40 --> Input Class Initialized
DEBUG - 2018-02-06 07:50:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:50:40 --> Input Class Initialized
INFO - 2018-02-06 07:50:40 --> Input Class Initialized
INFO - 2018-02-06 07:50:40 --> Language Class Initialized
INFO - 2018-02-06 07:50:40 --> Language Class Initialized
INFO - 2018-02-06 07:50:40 --> Language Class Initialized
INFO - 2018-02-06 07:50:40 --> Output Class Initialized
ERROR - 2018-02-06 07:50:40 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-06 07:50:40 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-06 07:50:40 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:50:40 --> Security Class Initialized
DEBUG - 2018-02-06 07:50:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:50:40 --> Input Class Initialized
INFO - 2018-02-06 07:50:40 --> Language Class Initialized
ERROR - 2018-02-06 07:50:40 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:50:41 --> Config Class Initialized
INFO - 2018-02-06 07:50:41 --> Hooks Class Initialized
INFO - 2018-02-06 07:50:41 --> Config Class Initialized
INFO - 2018-02-06 07:50:41 --> Hooks Class Initialized
INFO - 2018-02-06 07:50:41 --> Config Class Initialized
INFO - 2018-02-06 07:50:41 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:50:41 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:50:41 --> Utf8 Class Initialized
INFO - 2018-02-06 07:50:41 --> URI Class Initialized
DEBUG - 2018-02-06 07:50:41 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:50:41 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:50:41 --> Utf8 Class Initialized
INFO - 2018-02-06 07:50:41 --> Utf8 Class Initialized
INFO - 2018-02-06 07:50:41 --> Router Class Initialized
INFO - 2018-02-06 07:50:41 --> URI Class Initialized
INFO - 2018-02-06 07:50:41 --> URI Class Initialized
INFO - 2018-02-06 07:50:41 --> Output Class Initialized
INFO - 2018-02-06 07:50:41 --> Router Class Initialized
INFO - 2018-02-06 07:50:41 --> Router Class Initialized
INFO - 2018-02-06 07:50:41 --> Security Class Initialized
INFO - 2018-02-06 07:50:41 --> Output Class Initialized
INFO - 2018-02-06 07:50:41 --> Output Class Initialized
DEBUG - 2018-02-06 07:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:50:41 --> Input Class Initialized
INFO - 2018-02-06 07:50:41 --> Security Class Initialized
INFO - 2018-02-06 07:50:41 --> Language Class Initialized
INFO - 2018-02-06 07:50:41 --> Security Class Initialized
DEBUG - 2018-02-06 07:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:50:41 --> Input Class Initialized
ERROR - 2018-02-06 07:50:41 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-02-06 07:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:50:41 --> Input Class Initialized
INFO - 2018-02-06 07:50:41 --> Language Class Initialized
INFO - 2018-02-06 07:50:41 --> Language Class Initialized
ERROR - 2018-02-06 07:50:41 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-06 07:50:41 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-06 07:50:47 --> Config Class Initialized
INFO - 2018-02-06 07:50:47 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:50:47 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:50:47 --> Utf8 Class Initialized
INFO - 2018-02-06 07:50:47 --> URI Class Initialized
INFO - 2018-02-06 07:50:47 --> Router Class Initialized
INFO - 2018-02-06 07:50:47 --> Output Class Initialized
INFO - 2018-02-06 07:50:47 --> Security Class Initialized
DEBUG - 2018-02-06 07:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:50:47 --> Input Class Initialized
INFO - 2018-02-06 07:50:47 --> Language Class Initialized
INFO - 2018-02-06 07:50:47 --> Loader Class Initialized
INFO - 2018-02-06 07:50:47 --> Helper loaded: url_helper
INFO - 2018-02-06 07:50:47 --> Helper loaded: form_helper
INFO - 2018-02-06 07:50:47 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:50:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:50:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:50:47 --> Form Validation Class Initialized
INFO - 2018-02-06 07:50:47 --> Model Class Initialized
INFO - 2018-02-06 07:50:47 --> Controller Class Initialized
INFO - 2018-02-06 07:50:47 --> Model Class Initialized
DEBUG - 2018-02-06 07:50:47 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:50:47 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:50:47 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:50:47 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:50:47 --> Final output sent to browser
DEBUG - 2018-02-06 07:50:47 --> Total execution time: 0.0700
INFO - 2018-02-06 07:50:47 --> Config Class Initialized
INFO - 2018-02-06 07:50:47 --> Hooks Class Initialized
INFO - 2018-02-06 07:50:47 --> Config Class Initialized
INFO - 2018-02-06 07:50:47 --> Hooks Class Initialized
INFO - 2018-02-06 07:50:47 --> Config Class Initialized
INFO - 2018-02-06 07:50:47 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:50:47 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:50:47 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:50:47 --> Utf8 Class Initialized
INFO - 2018-02-06 07:50:47 --> Utf8 Class Initialized
INFO - 2018-02-06 07:50:47 --> Config Class Initialized
INFO - 2018-02-06 07:50:47 --> URI Class Initialized
INFO - 2018-02-06 07:50:47 --> Hooks Class Initialized
INFO - 2018-02-06 07:50:47 --> URI Class Initialized
DEBUG - 2018-02-06 07:50:47 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:50:47 --> Utf8 Class Initialized
INFO - 2018-02-06 07:50:47 --> Router Class Initialized
INFO - 2018-02-06 07:50:47 --> URI Class Initialized
INFO - 2018-02-06 07:50:47 --> Router Class Initialized
DEBUG - 2018-02-06 07:50:47 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:50:47 --> Utf8 Class Initialized
INFO - 2018-02-06 07:50:47 --> Output Class Initialized
INFO - 2018-02-06 07:50:47 --> Router Class Initialized
INFO - 2018-02-06 07:50:47 --> Output Class Initialized
INFO - 2018-02-06 07:50:47 --> URI Class Initialized
INFO - 2018-02-06 07:50:47 --> Security Class Initialized
INFO - 2018-02-06 07:50:47 --> Security Class Initialized
INFO - 2018-02-06 07:50:47 --> Router Class Initialized
INFO - 2018-02-06 07:50:47 --> Output Class Initialized
DEBUG - 2018-02-06 07:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:50:47 --> Input Class Initialized
DEBUG - 2018-02-06 07:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:50:47 --> Input Class Initialized
INFO - 2018-02-06 07:50:47 --> Language Class Initialized
INFO - 2018-02-06 07:50:47 --> Output Class Initialized
INFO - 2018-02-06 07:50:47 --> Language Class Initialized
INFO - 2018-02-06 07:50:47 --> Security Class Initialized
ERROR - 2018-02-06 07:50:47 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:50:47 --> Security Class Initialized
ERROR - 2018-02-06 07:50:47 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-02-06 07:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:50:47 --> Input Class Initialized
DEBUG - 2018-02-06 07:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:50:47 --> Input Class Initialized
INFO - 2018-02-06 07:50:47 --> Language Class Initialized
INFO - 2018-02-06 07:50:47 --> Language Class Initialized
ERROR - 2018-02-06 07:50:47 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-06 07:50:47 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:50:47 --> Config Class Initialized
INFO - 2018-02-06 07:50:47 --> Hooks Class Initialized
INFO - 2018-02-06 07:50:47 --> Config Class Initialized
INFO - 2018-02-06 07:50:47 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:50:47 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:50:47 --> Config Class Initialized
INFO - 2018-02-06 07:50:47 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:50:47 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:50:47 --> Hooks Class Initialized
INFO - 2018-02-06 07:50:47 --> Utf8 Class Initialized
INFO - 2018-02-06 07:50:47 --> URI Class Initialized
INFO - 2018-02-06 07:50:47 --> URI Class Initialized
INFO - 2018-02-06 07:50:47 --> Router Class Initialized
INFO - 2018-02-06 07:50:47 --> Router Class Initialized
DEBUG - 2018-02-06 07:50:47 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:50:47 --> Utf8 Class Initialized
INFO - 2018-02-06 07:50:47 --> Output Class Initialized
INFO - 2018-02-06 07:50:47 --> Output Class Initialized
INFO - 2018-02-06 07:50:47 --> URI Class Initialized
INFO - 2018-02-06 07:50:47 --> Security Class Initialized
INFO - 2018-02-06 07:50:47 --> Security Class Initialized
INFO - 2018-02-06 07:50:47 --> Router Class Initialized
DEBUG - 2018-02-06 07:50:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:50:47 --> Input Class Initialized
INFO - 2018-02-06 07:50:47 --> Input Class Initialized
INFO - 2018-02-06 07:50:47 --> Output Class Initialized
INFO - 2018-02-06 07:50:47 --> Language Class Initialized
INFO - 2018-02-06 07:50:47 --> Language Class Initialized
INFO - 2018-02-06 07:50:47 --> Security Class Initialized
ERROR - 2018-02-06 07:50:47 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-06 07:50:47 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-02-06 07:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:50:47 --> Input Class Initialized
INFO - 2018-02-06 07:50:47 --> Language Class Initialized
ERROR - 2018-02-06 07:50:47 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-06 07:50:56 --> Config Class Initialized
INFO - 2018-02-06 07:50:56 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:50:56 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:50:56 --> Utf8 Class Initialized
INFO - 2018-02-06 07:50:56 --> URI Class Initialized
INFO - 2018-02-06 07:50:56 --> Router Class Initialized
INFO - 2018-02-06 07:50:56 --> Output Class Initialized
INFO - 2018-02-06 07:50:56 --> Security Class Initialized
DEBUG - 2018-02-06 07:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:50:56 --> Input Class Initialized
INFO - 2018-02-06 07:50:56 --> Language Class Initialized
INFO - 2018-02-06 07:50:56 --> Loader Class Initialized
INFO - 2018-02-06 07:50:56 --> Helper loaded: url_helper
INFO - 2018-02-06 07:50:56 --> Helper loaded: form_helper
INFO - 2018-02-06 07:50:56 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:50:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:50:56 --> Form Validation Class Initialized
INFO - 2018-02-06 07:50:56 --> Model Class Initialized
INFO - 2018-02-06 07:50:56 --> Controller Class Initialized
INFO - 2018-02-06 07:50:56 --> Model Class Initialized
DEBUG - 2018-02-06 07:50:56 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:50:56 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:50:56 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:50:56 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:50:56 --> Final output sent to browser
DEBUG - 2018-02-06 07:50:56 --> Total execution time: 0.0455
INFO - 2018-02-06 07:50:56 --> Config Class Initialized
INFO - 2018-02-06 07:50:56 --> Hooks Class Initialized
INFO - 2018-02-06 07:50:56 --> Config Class Initialized
INFO - 2018-02-06 07:50:56 --> Hooks Class Initialized
INFO - 2018-02-06 07:50:56 --> Config Class Initialized
INFO - 2018-02-06 07:50:56 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:50:56 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:50:56 --> Config Class Initialized
INFO - 2018-02-06 07:50:56 --> Utf8 Class Initialized
INFO - 2018-02-06 07:50:56 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:50:56 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:50:56 --> Utf8 Class Initialized
INFO - 2018-02-06 07:50:56 --> URI Class Initialized
DEBUG - 2018-02-06 07:50:56 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:50:56 --> URI Class Initialized
INFO - 2018-02-06 07:50:56 --> Utf8 Class Initialized
INFO - 2018-02-06 07:50:56 --> Router Class Initialized
DEBUG - 2018-02-06 07:50:56 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:50:56 --> Utf8 Class Initialized
INFO - 2018-02-06 07:50:56 --> URI Class Initialized
INFO - 2018-02-06 07:50:56 --> Router Class Initialized
INFO - 2018-02-06 07:50:56 --> Output Class Initialized
INFO - 2018-02-06 07:50:56 --> URI Class Initialized
INFO - 2018-02-06 07:50:56 --> Router Class Initialized
INFO - 2018-02-06 07:50:56 --> Output Class Initialized
INFO - 2018-02-06 07:50:56 --> Security Class Initialized
INFO - 2018-02-06 07:50:56 --> Router Class Initialized
INFO - 2018-02-06 07:50:56 --> Security Class Initialized
INFO - 2018-02-06 07:50:56 --> Output Class Initialized
DEBUG - 2018-02-06 07:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:50:56 --> Input Class Initialized
INFO - 2018-02-06 07:50:56 --> Language Class Initialized
INFO - 2018-02-06 07:50:56 --> Security Class Initialized
DEBUG - 2018-02-06 07:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:50:56 --> Input Class Initialized
INFO - 2018-02-06 07:50:56 --> Output Class Initialized
ERROR - 2018-02-06 07:50:56 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-02-06 07:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:50:56 --> Language Class Initialized
INFO - 2018-02-06 07:50:56 --> Input Class Initialized
INFO - 2018-02-06 07:50:56 --> Security Class Initialized
INFO - 2018-02-06 07:50:56 --> Language Class Initialized
ERROR - 2018-02-06 07:50:56 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-02-06 07:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:50:56 --> Input Class Initialized
ERROR - 2018-02-06 07:50:56 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:50:56 --> Language Class Initialized
ERROR - 2018-02-06 07:50:56 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:50:56 --> Config Class Initialized
INFO - 2018-02-06 07:50:56 --> Hooks Class Initialized
INFO - 2018-02-06 07:50:56 --> Config Class Initialized
INFO - 2018-02-06 07:50:56 --> Hooks Class Initialized
INFO - 2018-02-06 07:50:56 --> Config Class Initialized
INFO - 2018-02-06 07:50:56 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:50:56 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:50:56 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:50:56 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:50:56 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:50:56 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:50:56 --> URI Class Initialized
INFO - 2018-02-06 07:50:56 --> Utf8 Class Initialized
INFO - 2018-02-06 07:50:56 --> URI Class Initialized
INFO - 2018-02-06 07:50:56 --> URI Class Initialized
INFO - 2018-02-06 07:50:56 --> Router Class Initialized
INFO - 2018-02-06 07:50:56 --> Router Class Initialized
INFO - 2018-02-06 07:50:56 --> Router Class Initialized
INFO - 2018-02-06 07:50:56 --> Output Class Initialized
INFO - 2018-02-06 07:50:56 --> Output Class Initialized
INFO - 2018-02-06 07:50:56 --> Output Class Initialized
INFO - 2018-02-06 07:50:56 --> Security Class Initialized
INFO - 2018-02-06 07:50:56 --> Security Class Initialized
INFO - 2018-02-06 07:50:56 --> Security Class Initialized
DEBUG - 2018-02-06 07:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:50:56 --> Input Class Initialized
DEBUG - 2018-02-06 07:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:50:56 --> Input Class Initialized
DEBUG - 2018-02-06 07:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:50:56 --> Language Class Initialized
INFO - 2018-02-06 07:50:56 --> Input Class Initialized
INFO - 2018-02-06 07:50:56 --> Language Class Initialized
ERROR - 2018-02-06 07:50:56 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-06 07:50:56 --> Language Class Initialized
ERROR - 2018-02-06 07:50:56 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-06 07:50:56 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-06 07:50:57 --> Config Class Initialized
INFO - 2018-02-06 07:50:57 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:50:57 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:50:57 --> Utf8 Class Initialized
INFO - 2018-02-06 07:50:57 --> URI Class Initialized
INFO - 2018-02-06 07:50:57 --> Router Class Initialized
INFO - 2018-02-06 07:50:57 --> Output Class Initialized
INFO - 2018-02-06 07:50:57 --> Security Class Initialized
DEBUG - 2018-02-06 07:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:50:57 --> Input Class Initialized
INFO - 2018-02-06 07:50:57 --> Language Class Initialized
INFO - 2018-02-06 07:50:57 --> Loader Class Initialized
INFO - 2018-02-06 07:50:57 --> Helper loaded: url_helper
INFO - 2018-02-06 07:50:57 --> Helper loaded: form_helper
INFO - 2018-02-06 07:50:57 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:50:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:50:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:50:57 --> Form Validation Class Initialized
INFO - 2018-02-06 07:50:57 --> Model Class Initialized
INFO - 2018-02-06 07:50:57 --> Controller Class Initialized
INFO - 2018-02-06 07:50:57 --> Model Class Initialized
DEBUG - 2018-02-06 07:50:57 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:50:57 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:50:57 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:50:57 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:50:57 --> Final output sent to browser
DEBUG - 2018-02-06 07:50:57 --> Total execution time: 0.0500
INFO - 2018-02-06 07:50:57 --> Config Class Initialized
INFO - 2018-02-06 07:50:57 --> Config Class Initialized
INFO - 2018-02-06 07:50:57 --> Hooks Class Initialized
INFO - 2018-02-06 07:50:57 --> Hooks Class Initialized
INFO - 2018-02-06 07:50:57 --> Config Class Initialized
INFO - 2018-02-06 07:50:57 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:50:57 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:50:57 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:50:57 --> Utf8 Class Initialized
INFO - 2018-02-06 07:50:57 --> Utf8 Class Initialized
INFO - 2018-02-06 07:50:57 --> Config Class Initialized
INFO - 2018-02-06 07:50:57 --> URI Class Initialized
INFO - 2018-02-06 07:50:57 --> Hooks Class Initialized
INFO - 2018-02-06 07:50:57 --> URI Class Initialized
DEBUG - 2018-02-06 07:50:57 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:50:57 --> Router Class Initialized
INFO - 2018-02-06 07:50:57 --> Utf8 Class Initialized
INFO - 2018-02-06 07:50:57 --> URI Class Initialized
INFO - 2018-02-06 07:50:57 --> Router Class Initialized
INFO - 2018-02-06 07:50:57 --> Output Class Initialized
DEBUG - 2018-02-06 07:50:57 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:50:57 --> Utf8 Class Initialized
INFO - 2018-02-06 07:50:57 --> Router Class Initialized
INFO - 2018-02-06 07:50:57 --> Security Class Initialized
INFO - 2018-02-06 07:50:57 --> Output Class Initialized
INFO - 2018-02-06 07:50:57 --> URI Class Initialized
DEBUG - 2018-02-06 07:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:50:57 --> Security Class Initialized
INFO - 2018-02-06 07:50:57 --> Input Class Initialized
INFO - 2018-02-06 07:50:57 --> Router Class Initialized
INFO - 2018-02-06 07:50:57 --> Output Class Initialized
INFO - 2018-02-06 07:50:57 --> Config Class Initialized
INFO - 2018-02-06 07:50:57 --> Language Class Initialized
INFO - 2018-02-06 07:50:57 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:50:57 --> Security Class Initialized
INFO - 2018-02-06 07:50:57 --> Input Class Initialized
INFO - 2018-02-06 07:50:57 --> Config Class Initialized
INFO - 2018-02-06 07:50:57 --> Hooks Class Initialized
INFO - 2018-02-06 07:50:57 --> Output Class Initialized
INFO - 2018-02-06 07:50:57 --> Language Class Initialized
ERROR - 2018-02-06 07:50:57 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-02-06 07:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:50:57 --> Input Class Initialized
DEBUG - 2018-02-06 07:50:57 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:50:57 --> Utf8 Class Initialized
INFO - 2018-02-06 07:50:57 --> Security Class Initialized
ERROR - 2018-02-06 07:50:57 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:50:57 --> Language Class Initialized
DEBUG - 2018-02-06 07:50:57 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:50:57 --> URI Class Initialized
INFO - 2018-02-06 07:50:57 --> Utf8 Class Initialized
ERROR - 2018-02-06 07:50:57 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-02-06 07:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:50:57 --> URI Class Initialized
INFO - 2018-02-06 07:50:57 --> Input Class Initialized
INFO - 2018-02-06 07:50:57 --> Router Class Initialized
INFO - 2018-02-06 07:50:57 --> Language Class Initialized
INFO - 2018-02-06 07:50:57 --> Output Class Initialized
INFO - 2018-02-06 07:50:57 --> Router Class Initialized
ERROR - 2018-02-06 07:50:57 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:50:57 --> Security Class Initialized
INFO - 2018-02-06 07:50:57 --> Output Class Initialized
DEBUG - 2018-02-06 07:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:50:57 --> Input Class Initialized
INFO - 2018-02-06 07:50:57 --> Language Class Initialized
INFO - 2018-02-06 07:50:57 --> Security Class Initialized
INFO - 2018-02-06 07:50:57 --> Config Class Initialized
INFO - 2018-02-06 07:50:57 --> Hooks Class Initialized
ERROR - 2018-02-06 07:50:57 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-02-06 07:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:50:57 --> Input Class Initialized
DEBUG - 2018-02-06 07:50:57 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:50:57 --> Language Class Initialized
INFO - 2018-02-06 07:50:57 --> Utf8 Class Initialized
INFO - 2018-02-06 07:50:57 --> URI Class Initialized
ERROR - 2018-02-06 07:50:57 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-06 07:50:57 --> Router Class Initialized
INFO - 2018-02-06 07:50:57 --> Output Class Initialized
INFO - 2018-02-06 07:50:57 --> Security Class Initialized
DEBUG - 2018-02-06 07:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:50:57 --> Input Class Initialized
INFO - 2018-02-06 07:50:57 --> Language Class Initialized
ERROR - 2018-02-06 07:50:57 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-06 07:50:58 --> Config Class Initialized
INFO - 2018-02-06 07:50:58 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:50:58 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:50:58 --> Utf8 Class Initialized
INFO - 2018-02-06 07:50:58 --> URI Class Initialized
INFO - 2018-02-06 07:50:58 --> Router Class Initialized
INFO - 2018-02-06 07:50:58 --> Output Class Initialized
INFO - 2018-02-06 07:50:58 --> Security Class Initialized
DEBUG - 2018-02-06 07:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:50:58 --> Input Class Initialized
INFO - 2018-02-06 07:50:58 --> Language Class Initialized
INFO - 2018-02-06 07:50:58 --> Loader Class Initialized
INFO - 2018-02-06 07:50:58 --> Helper loaded: url_helper
INFO - 2018-02-06 07:50:58 --> Helper loaded: form_helper
INFO - 2018-02-06 07:50:58 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:50:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:50:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:50:58 --> Form Validation Class Initialized
INFO - 2018-02-06 07:50:58 --> Model Class Initialized
INFO - 2018-02-06 07:50:58 --> Controller Class Initialized
INFO - 2018-02-06 07:50:58 --> Model Class Initialized
DEBUG - 2018-02-06 07:50:58 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:50:58 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:50:58 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:50:58 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:50:58 --> Final output sent to browser
DEBUG - 2018-02-06 07:50:58 --> Total execution time: 0.0502
INFO - 2018-02-06 07:50:58 --> Config Class Initialized
INFO - 2018-02-06 07:50:58 --> Hooks Class Initialized
INFO - 2018-02-06 07:50:58 --> Config Class Initialized
INFO - 2018-02-06 07:50:58 --> Hooks Class Initialized
INFO - 2018-02-06 07:50:58 --> Config Class Initialized
INFO - 2018-02-06 07:50:58 --> Hooks Class Initialized
INFO - 2018-02-06 07:50:58 --> Config Class Initialized
DEBUG - 2018-02-06 07:50:58 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:50:58 --> Hooks Class Initialized
INFO - 2018-02-06 07:50:58 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:50:58 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:50:58 --> Utf8 Class Initialized
INFO - 2018-02-06 07:50:58 --> URI Class Initialized
DEBUG - 2018-02-06 07:50:58 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:50:58 --> Utf8 Class Initialized
INFO - 2018-02-06 07:50:58 --> URI Class Initialized
DEBUG - 2018-02-06 07:50:58 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:50:58 --> URI Class Initialized
INFO - 2018-02-06 07:50:58 --> Router Class Initialized
INFO - 2018-02-06 07:50:58 --> Utf8 Class Initialized
INFO - 2018-02-06 07:50:58 --> Router Class Initialized
INFO - 2018-02-06 07:50:58 --> URI Class Initialized
INFO - 2018-02-06 07:50:58 --> Router Class Initialized
INFO - 2018-02-06 07:50:58 --> Output Class Initialized
INFO - 2018-02-06 07:50:58 --> Output Class Initialized
INFO - 2018-02-06 07:50:58 --> Router Class Initialized
INFO - 2018-02-06 07:50:58 --> Security Class Initialized
INFO - 2018-02-06 07:50:58 --> Security Class Initialized
INFO - 2018-02-06 07:50:58 --> Output Class Initialized
INFO - 2018-02-06 07:50:58 --> Output Class Initialized
DEBUG - 2018-02-06 07:50:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:50:58 --> Input Class Initialized
INFO - 2018-02-06 07:50:58 --> Input Class Initialized
INFO - 2018-02-06 07:50:58 --> Security Class Initialized
INFO - 2018-02-06 07:50:58 --> Security Class Initialized
INFO - 2018-02-06 07:50:58 --> Language Class Initialized
INFO - 2018-02-06 07:50:58 --> Language Class Initialized
DEBUG - 2018-02-06 07:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:50:58 --> Input Class Initialized
DEBUG - 2018-02-06 07:50:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-06 07:50:58 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:50:58 --> Input Class Initialized
ERROR - 2018-02-06 07:50:58 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:50:58 --> Language Class Initialized
INFO - 2018-02-06 07:50:58 --> Language Class Initialized
ERROR - 2018-02-06 07:50:58 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-06 07:50:58 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:50:58 --> Config Class Initialized
INFO - 2018-02-06 07:50:58 --> Hooks Class Initialized
INFO - 2018-02-06 07:50:58 --> Config Class Initialized
INFO - 2018-02-06 07:50:58 --> Hooks Class Initialized
INFO - 2018-02-06 07:50:58 --> Config Class Initialized
INFO - 2018-02-06 07:50:58 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:50:58 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:50:58 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:50:58 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:50:58 --> Utf8 Class Initialized
INFO - 2018-02-06 07:50:58 --> URI Class Initialized
DEBUG - 2018-02-06 07:50:58 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:50:58 --> Utf8 Class Initialized
INFO - 2018-02-06 07:50:58 --> URI Class Initialized
INFO - 2018-02-06 07:50:58 --> URI Class Initialized
INFO - 2018-02-06 07:50:58 --> Router Class Initialized
INFO - 2018-02-06 07:50:58 --> Router Class Initialized
INFO - 2018-02-06 07:50:58 --> Router Class Initialized
INFO - 2018-02-06 07:50:58 --> Output Class Initialized
INFO - 2018-02-06 07:50:58 --> Output Class Initialized
INFO - 2018-02-06 07:50:58 --> Security Class Initialized
INFO - 2018-02-06 07:50:58 --> Output Class Initialized
INFO - 2018-02-06 07:50:58 --> Security Class Initialized
DEBUG - 2018-02-06 07:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:50:58 --> Security Class Initialized
INFO - 2018-02-06 07:50:58 --> Input Class Initialized
DEBUG - 2018-02-06 07:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:50:58 --> Input Class Initialized
INFO - 2018-02-06 07:50:58 --> Language Class Initialized
DEBUG - 2018-02-06 07:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:50:58 --> Input Class Initialized
INFO - 2018-02-06 07:50:58 --> Language Class Initialized
INFO - 2018-02-06 07:50:58 --> Language Class Initialized
ERROR - 2018-02-06 07:50:58 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-06 07:50:58 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-06 07:50:58 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-06 07:50:58 --> Config Class Initialized
INFO - 2018-02-06 07:50:58 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:50:58 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:50:58 --> Utf8 Class Initialized
INFO - 2018-02-06 07:50:58 --> URI Class Initialized
INFO - 2018-02-06 07:50:58 --> Router Class Initialized
INFO - 2018-02-06 07:50:58 --> Output Class Initialized
INFO - 2018-02-06 07:50:58 --> Security Class Initialized
DEBUG - 2018-02-06 07:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:50:58 --> Input Class Initialized
INFO - 2018-02-06 07:50:58 --> Language Class Initialized
INFO - 2018-02-06 07:50:58 --> Loader Class Initialized
INFO - 2018-02-06 07:50:58 --> Helper loaded: url_helper
INFO - 2018-02-06 07:50:58 --> Helper loaded: form_helper
INFO - 2018-02-06 07:50:58 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:50:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:50:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:50:58 --> Form Validation Class Initialized
INFO - 2018-02-06 07:50:58 --> Model Class Initialized
INFO - 2018-02-06 07:50:58 --> Controller Class Initialized
INFO - 2018-02-06 07:50:58 --> Model Class Initialized
DEBUG - 2018-02-06 07:50:58 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:50:58 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:50:58 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:50:58 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:50:58 --> Final output sent to browser
DEBUG - 2018-02-06 07:50:58 --> Total execution time: 0.0388
INFO - 2018-02-06 07:50:59 --> Config Class Initialized
INFO - 2018-02-06 07:50:59 --> Hooks Class Initialized
INFO - 2018-02-06 07:50:59 --> Config Class Initialized
INFO - 2018-02-06 07:50:59 --> Config Class Initialized
INFO - 2018-02-06 07:50:59 --> Hooks Class Initialized
INFO - 2018-02-06 07:50:59 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:50:59 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:50:59 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:50:59 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:50:59 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:50:59 --> Utf8 Class Initialized
INFO - 2018-02-06 07:50:59 --> Utf8 Class Initialized
INFO - 2018-02-06 07:50:59 --> Config Class Initialized
INFO - 2018-02-06 07:50:59 --> Hooks Class Initialized
INFO - 2018-02-06 07:50:59 --> URI Class Initialized
INFO - 2018-02-06 07:50:59 --> URI Class Initialized
INFO - 2018-02-06 07:50:59 --> URI Class Initialized
INFO - 2018-02-06 07:50:59 --> Router Class Initialized
DEBUG - 2018-02-06 07:50:59 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:50:59 --> Router Class Initialized
INFO - 2018-02-06 07:50:59 --> Utf8 Class Initialized
INFO - 2018-02-06 07:50:59 --> Router Class Initialized
INFO - 2018-02-06 07:50:59 --> Output Class Initialized
INFO - 2018-02-06 07:50:59 --> URI Class Initialized
INFO - 2018-02-06 07:50:59 --> Output Class Initialized
INFO - 2018-02-06 07:50:59 --> Output Class Initialized
INFO - 2018-02-06 07:50:59 --> Security Class Initialized
INFO - 2018-02-06 07:50:59 --> Router Class Initialized
DEBUG - 2018-02-06 07:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:50:59 --> Security Class Initialized
INFO - 2018-02-06 07:50:59 --> Security Class Initialized
INFO - 2018-02-06 07:50:59 --> Input Class Initialized
INFO - 2018-02-06 07:50:59 --> Language Class Initialized
INFO - 2018-02-06 07:50:59 --> Output Class Initialized
DEBUG - 2018-02-06 07:50:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:50:59 --> Input Class Initialized
INFO - 2018-02-06 07:50:59 --> Input Class Initialized
ERROR - 2018-02-06 07:50:59 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:50:59 --> Security Class Initialized
INFO - 2018-02-06 07:50:59 --> Language Class Initialized
INFO - 2018-02-06 07:50:59 --> Language Class Initialized
DEBUG - 2018-02-06 07:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:50:59 --> Input Class Initialized
ERROR - 2018-02-06 07:50:59 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-06 07:50:59 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:50:59 --> Language Class Initialized
ERROR - 2018-02-06 07:50:59 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:50:59 --> Config Class Initialized
INFO - 2018-02-06 07:50:59 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:50:59 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:50:59 --> Config Class Initialized
INFO - 2018-02-06 07:50:59 --> Utf8 Class Initialized
INFO - 2018-02-06 07:50:59 --> Hooks Class Initialized
INFO - 2018-02-06 07:50:59 --> Config Class Initialized
INFO - 2018-02-06 07:50:59 --> Hooks Class Initialized
INFO - 2018-02-06 07:50:59 --> URI Class Initialized
INFO - 2018-02-06 07:50:59 --> Router Class Initialized
DEBUG - 2018-02-06 07:50:59 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:50:59 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:50:59 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:50:59 --> Utf8 Class Initialized
INFO - 2018-02-06 07:50:59 --> URI Class Initialized
INFO - 2018-02-06 07:50:59 --> Output Class Initialized
INFO - 2018-02-06 07:50:59 --> URI Class Initialized
INFO - 2018-02-06 07:50:59 --> Security Class Initialized
INFO - 2018-02-06 07:50:59 --> Router Class Initialized
INFO - 2018-02-06 07:50:59 --> Router Class Initialized
DEBUG - 2018-02-06 07:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:50:59 --> Input Class Initialized
INFO - 2018-02-06 07:50:59 --> Language Class Initialized
INFO - 2018-02-06 07:50:59 --> Output Class Initialized
INFO - 2018-02-06 07:50:59 --> Output Class Initialized
ERROR - 2018-02-06 07:50:59 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-06 07:50:59 --> Security Class Initialized
INFO - 2018-02-06 07:50:59 --> Security Class Initialized
DEBUG - 2018-02-06 07:50:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:50:59 --> Input Class Initialized
INFO - 2018-02-06 07:50:59 --> Input Class Initialized
INFO - 2018-02-06 07:50:59 --> Language Class Initialized
INFO - 2018-02-06 07:50:59 --> Language Class Initialized
ERROR - 2018-02-06 07:50:59 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-06 07:50:59 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-06 07:50:59 --> Config Class Initialized
INFO - 2018-02-06 07:50:59 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:50:59 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:50:59 --> Utf8 Class Initialized
INFO - 2018-02-06 07:50:59 --> URI Class Initialized
INFO - 2018-02-06 07:50:59 --> Router Class Initialized
INFO - 2018-02-06 07:50:59 --> Output Class Initialized
INFO - 2018-02-06 07:50:59 --> Security Class Initialized
DEBUG - 2018-02-06 07:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:50:59 --> Input Class Initialized
INFO - 2018-02-06 07:50:59 --> Language Class Initialized
INFO - 2018-02-06 07:50:59 --> Loader Class Initialized
INFO - 2018-02-06 07:50:59 --> Helper loaded: url_helper
INFO - 2018-02-06 07:50:59 --> Helper loaded: form_helper
INFO - 2018-02-06 07:50:59 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:50:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:50:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:50:59 --> Form Validation Class Initialized
INFO - 2018-02-06 07:50:59 --> Model Class Initialized
INFO - 2018-02-06 07:50:59 --> Controller Class Initialized
INFO - 2018-02-06 07:50:59 --> Model Class Initialized
DEBUG - 2018-02-06 07:50:59 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:50:59 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:50:59 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:50:59 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:50:59 --> Final output sent to browser
DEBUG - 2018-02-06 07:50:59 --> Total execution time: 0.0516
INFO - 2018-02-06 07:50:59 --> Config Class Initialized
INFO - 2018-02-06 07:50:59 --> Config Class Initialized
INFO - 2018-02-06 07:50:59 --> Hooks Class Initialized
INFO - 2018-02-06 07:50:59 --> Config Class Initialized
INFO - 2018-02-06 07:50:59 --> Hooks Class Initialized
INFO - 2018-02-06 07:50:59 --> Hooks Class Initialized
INFO - 2018-02-06 07:50:59 --> Config Class Initialized
INFO - 2018-02-06 07:50:59 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:50:59 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:50:59 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:50:59 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:50:59 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:50:59 --> Utf8 Class Initialized
INFO - 2018-02-06 07:50:59 --> Utf8 Class Initialized
INFO - 2018-02-06 07:50:59 --> URI Class Initialized
INFO - 2018-02-06 07:50:59 --> URI Class Initialized
INFO - 2018-02-06 07:50:59 --> URI Class Initialized
DEBUG - 2018-02-06 07:50:59 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:50:59 --> Utf8 Class Initialized
INFO - 2018-02-06 07:50:59 --> Router Class Initialized
INFO - 2018-02-06 07:50:59 --> Router Class Initialized
INFO - 2018-02-06 07:50:59 --> URI Class Initialized
INFO - 2018-02-06 07:50:59 --> Router Class Initialized
INFO - 2018-02-06 07:50:59 --> Output Class Initialized
INFO - 2018-02-06 07:50:59 --> Router Class Initialized
INFO - 2018-02-06 07:50:59 --> Output Class Initialized
INFO - 2018-02-06 07:50:59 --> Output Class Initialized
INFO - 2018-02-06 07:50:59 --> Security Class Initialized
INFO - 2018-02-06 07:50:59 --> Output Class Initialized
INFO - 2018-02-06 07:50:59 --> Security Class Initialized
INFO - 2018-02-06 07:50:59 --> Security Class Initialized
DEBUG - 2018-02-06 07:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:50:59 --> Input Class Initialized
DEBUG - 2018-02-06 07:50:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:50:59 --> Input Class Initialized
INFO - 2018-02-06 07:50:59 --> Security Class Initialized
INFO - 2018-02-06 07:50:59 --> Language Class Initialized
INFO - 2018-02-06 07:50:59 --> Input Class Initialized
INFO - 2018-02-06 07:50:59 --> Language Class Initialized
INFO - 2018-02-06 07:50:59 --> Language Class Initialized
DEBUG - 2018-02-06 07:50:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-06 07:50:59 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:50:59 --> Input Class Initialized
ERROR - 2018-02-06 07:50:59 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:50:59 --> Language Class Initialized
ERROR - 2018-02-06 07:50:59 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-06 07:50:59 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:50:59 --> Config Class Initialized
INFO - 2018-02-06 07:50:59 --> Hooks Class Initialized
INFO - 2018-02-06 07:50:59 --> Config Class Initialized
INFO - 2018-02-06 07:50:59 --> Config Class Initialized
INFO - 2018-02-06 07:50:59 --> Hooks Class Initialized
INFO - 2018-02-06 07:50:59 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:50:59 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:50:59 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:50:59 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:50:59 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:50:59 --> Utf8 Class Initialized
INFO - 2018-02-06 07:50:59 --> Utf8 Class Initialized
INFO - 2018-02-06 07:50:59 --> URI Class Initialized
INFO - 2018-02-06 07:50:59 --> URI Class Initialized
INFO - 2018-02-06 07:50:59 --> URI Class Initialized
INFO - 2018-02-06 07:50:59 --> Router Class Initialized
INFO - 2018-02-06 07:50:59 --> Router Class Initialized
INFO - 2018-02-06 07:50:59 --> Router Class Initialized
INFO - 2018-02-06 07:50:59 --> Output Class Initialized
INFO - 2018-02-06 07:50:59 --> Output Class Initialized
INFO - 2018-02-06 07:50:59 --> Output Class Initialized
INFO - 2018-02-06 07:50:59 --> Security Class Initialized
INFO - 2018-02-06 07:50:59 --> Security Class Initialized
INFO - 2018-02-06 07:50:59 --> Security Class Initialized
DEBUG - 2018-02-06 07:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:50:59 --> Input Class Initialized
DEBUG - 2018-02-06 07:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:50:59 --> Language Class Initialized
INFO - 2018-02-06 07:50:59 --> Input Class Initialized
DEBUG - 2018-02-06 07:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:50:59 --> Input Class Initialized
INFO - 2018-02-06 07:50:59 --> Language Class Initialized
INFO - 2018-02-06 07:50:59 --> Language Class Initialized
ERROR - 2018-02-06 07:50:59 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-06 07:50:59 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-06 07:50:59 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-06 07:51:00 --> Config Class Initialized
INFO - 2018-02-06 07:51:00 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:51:00 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:51:00 --> Utf8 Class Initialized
INFO - 2018-02-06 07:51:00 --> URI Class Initialized
INFO - 2018-02-06 07:51:00 --> Router Class Initialized
INFO - 2018-02-06 07:51:00 --> Output Class Initialized
INFO - 2018-02-06 07:51:00 --> Security Class Initialized
DEBUG - 2018-02-06 07:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:51:00 --> Input Class Initialized
INFO - 2018-02-06 07:51:00 --> Language Class Initialized
INFO - 2018-02-06 07:51:00 --> Loader Class Initialized
INFO - 2018-02-06 07:51:00 --> Helper loaded: url_helper
INFO - 2018-02-06 07:51:00 --> Helper loaded: form_helper
INFO - 2018-02-06 07:51:00 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:51:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:51:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:51:00 --> Form Validation Class Initialized
INFO - 2018-02-06 07:51:00 --> Model Class Initialized
INFO - 2018-02-06 07:51:00 --> Controller Class Initialized
INFO - 2018-02-06 07:51:00 --> Model Class Initialized
DEBUG - 2018-02-06 07:51:00 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:51:00 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:51:00 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:51:00 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:51:00 --> Final output sent to browser
DEBUG - 2018-02-06 07:51:00 --> Total execution time: 0.0534
INFO - 2018-02-06 07:51:00 --> Config Class Initialized
INFO - 2018-02-06 07:51:00 --> Hooks Class Initialized
INFO - 2018-02-06 07:51:00 --> Config Class Initialized
INFO - 2018-02-06 07:51:00 --> Hooks Class Initialized
INFO - 2018-02-06 07:51:00 --> Config Class Initialized
INFO - 2018-02-06 07:51:00 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:51:00 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:51:00 --> Utf8 Class Initialized
INFO - 2018-02-06 07:51:00 --> Config Class Initialized
INFO - 2018-02-06 07:51:00 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:51:00 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:51:00 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:51:00 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:51:00 --> URI Class Initialized
INFO - 2018-02-06 07:51:00 --> Utf8 Class Initialized
INFO - 2018-02-06 07:51:00 --> URI Class Initialized
INFO - 2018-02-06 07:51:00 --> URI Class Initialized
INFO - 2018-02-06 07:51:00 --> Router Class Initialized
DEBUG - 2018-02-06 07:51:00 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:51:00 --> Utf8 Class Initialized
INFO - 2018-02-06 07:51:00 --> Router Class Initialized
INFO - 2018-02-06 07:51:00 --> Router Class Initialized
INFO - 2018-02-06 07:51:00 --> URI Class Initialized
INFO - 2018-02-06 07:51:00 --> Output Class Initialized
INFO - 2018-02-06 07:51:00 --> Output Class Initialized
INFO - 2018-02-06 07:51:00 --> Output Class Initialized
INFO - 2018-02-06 07:51:00 --> Security Class Initialized
INFO - 2018-02-06 07:51:00 --> Router Class Initialized
INFO - 2018-02-06 07:51:00 --> Security Class Initialized
INFO - 2018-02-06 07:51:00 --> Security Class Initialized
DEBUG - 2018-02-06 07:51:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:51:00 --> Input Class Initialized
DEBUG - 2018-02-06 07:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:51:00 --> Input Class Initialized
INFO - 2018-02-06 07:51:00 --> Output Class Initialized
INFO - 2018-02-06 07:51:00 --> Input Class Initialized
INFO - 2018-02-06 07:51:00 --> Language Class Initialized
INFO - 2018-02-06 07:51:00 --> Language Class Initialized
INFO - 2018-02-06 07:51:00 --> Language Class Initialized
INFO - 2018-02-06 07:51:00 --> Security Class Initialized
ERROR - 2018-02-06 07:51:00 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-06 07:51:00 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-06 07:51:00 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-02-06 07:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:51:00 --> Input Class Initialized
INFO - 2018-02-06 07:51:00 --> Language Class Initialized
ERROR - 2018-02-06 07:51:00 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:51:00 --> Config Class Initialized
INFO - 2018-02-06 07:51:00 --> Config Class Initialized
INFO - 2018-02-06 07:51:00 --> Hooks Class Initialized
INFO - 2018-02-06 07:51:00 --> Hooks Class Initialized
INFO - 2018-02-06 07:51:00 --> Config Class Initialized
INFO - 2018-02-06 07:51:00 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:51:00 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:51:00 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:51:00 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:51:00 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:51:00 --> Utf8 Class Initialized
INFO - 2018-02-06 07:51:00 --> Utf8 Class Initialized
INFO - 2018-02-06 07:51:00 --> URI Class Initialized
INFO - 2018-02-06 07:51:00 --> URI Class Initialized
INFO - 2018-02-06 07:51:00 --> URI Class Initialized
INFO - 2018-02-06 07:51:00 --> Router Class Initialized
INFO - 2018-02-06 07:51:00 --> Router Class Initialized
INFO - 2018-02-06 07:51:00 --> Router Class Initialized
INFO - 2018-02-06 07:51:00 --> Output Class Initialized
INFO - 2018-02-06 07:51:00 --> Output Class Initialized
INFO - 2018-02-06 07:51:00 --> Security Class Initialized
INFO - 2018-02-06 07:51:00 --> Output Class Initialized
INFO - 2018-02-06 07:51:00 --> Security Class Initialized
DEBUG - 2018-02-06 07:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:51:00 --> Input Class Initialized
DEBUG - 2018-02-06 07:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:51:00 --> Security Class Initialized
INFO - 2018-02-06 07:51:00 --> Input Class Initialized
INFO - 2018-02-06 07:51:00 --> Language Class Initialized
INFO - 2018-02-06 07:51:00 --> Language Class Initialized
DEBUG - 2018-02-06 07:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:51:00 --> Input Class Initialized
ERROR - 2018-02-06 07:51:00 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-06 07:51:00 --> Language Class Initialized
ERROR - 2018-02-06 07:51:00 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-06 07:51:00 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-06 07:51:01 --> Config Class Initialized
INFO - 2018-02-06 07:51:01 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:51:01 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:51:01 --> Utf8 Class Initialized
INFO - 2018-02-06 07:51:01 --> URI Class Initialized
INFO - 2018-02-06 07:51:01 --> Router Class Initialized
INFO - 2018-02-06 07:51:01 --> Output Class Initialized
INFO - 2018-02-06 07:51:01 --> Security Class Initialized
DEBUG - 2018-02-06 07:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:51:01 --> Input Class Initialized
INFO - 2018-02-06 07:51:01 --> Language Class Initialized
INFO - 2018-02-06 07:51:01 --> Loader Class Initialized
INFO - 2018-02-06 07:51:01 --> Helper loaded: url_helper
INFO - 2018-02-06 07:51:01 --> Helper loaded: form_helper
INFO - 2018-02-06 07:51:01 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:51:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:51:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:51:01 --> Form Validation Class Initialized
INFO - 2018-02-06 07:51:01 --> Model Class Initialized
INFO - 2018-02-06 07:51:01 --> Controller Class Initialized
INFO - 2018-02-06 07:51:01 --> Model Class Initialized
DEBUG - 2018-02-06 07:51:01 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:51:01 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:51:01 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:51:01 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:51:01 --> Final output sent to browser
DEBUG - 2018-02-06 07:51:01 --> Total execution time: 0.0427
INFO - 2018-02-06 07:51:01 --> Config Class Initialized
INFO - 2018-02-06 07:51:01 --> Hooks Class Initialized
INFO - 2018-02-06 07:51:01 --> Config Class Initialized
INFO - 2018-02-06 07:51:01 --> Config Class Initialized
INFO - 2018-02-06 07:51:01 --> Hooks Class Initialized
INFO - 2018-02-06 07:51:01 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:51:01 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:51:01 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:51:01 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:51:01 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:51:01 --> Config Class Initialized
INFO - 2018-02-06 07:51:01 --> Utf8 Class Initialized
INFO - 2018-02-06 07:51:01 --> Utf8 Class Initialized
INFO - 2018-02-06 07:51:01 --> URI Class Initialized
INFO - 2018-02-06 07:51:01 --> Hooks Class Initialized
INFO - 2018-02-06 07:51:01 --> URI Class Initialized
INFO - 2018-02-06 07:51:01 --> URI Class Initialized
INFO - 2018-02-06 07:51:01 --> Router Class Initialized
INFO - 2018-02-06 07:51:01 --> Router Class Initialized
INFO - 2018-02-06 07:51:01 --> Router Class Initialized
DEBUG - 2018-02-06 07:51:01 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:51:01 --> Utf8 Class Initialized
INFO - 2018-02-06 07:51:01 --> Output Class Initialized
INFO - 2018-02-06 07:51:01 --> URI Class Initialized
INFO - 2018-02-06 07:51:01 --> Output Class Initialized
INFO - 2018-02-06 07:51:01 --> Output Class Initialized
INFO - 2018-02-06 07:51:01 --> Security Class Initialized
INFO - 2018-02-06 07:51:01 --> Router Class Initialized
INFO - 2018-02-06 07:51:01 --> Security Class Initialized
INFO - 2018-02-06 07:51:01 --> Security Class Initialized
DEBUG - 2018-02-06 07:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:51:01 --> Input Class Initialized
DEBUG - 2018-02-06 07:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:51:01 --> Input Class Initialized
DEBUG - 2018-02-06 07:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:51:01 --> Output Class Initialized
INFO - 2018-02-06 07:51:01 --> Language Class Initialized
INFO - 2018-02-06 07:51:01 --> Input Class Initialized
INFO - 2018-02-06 07:51:01 --> Language Class Initialized
INFO - 2018-02-06 07:51:01 --> Language Class Initialized
INFO - 2018-02-06 07:51:01 --> Security Class Initialized
ERROR - 2018-02-06 07:51:01 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-06 07:51:01 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-06 07:51:01 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-02-06 07:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:51:01 --> Input Class Initialized
INFO - 2018-02-06 07:51:01 --> Language Class Initialized
ERROR - 2018-02-06 07:51:01 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:51:01 --> Config Class Initialized
INFO - 2018-02-06 07:51:01 --> Hooks Class Initialized
INFO - 2018-02-06 07:51:01 --> Config Class Initialized
INFO - 2018-02-06 07:51:01 --> Config Class Initialized
INFO - 2018-02-06 07:51:01 --> Hooks Class Initialized
INFO - 2018-02-06 07:51:01 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:51:01 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:51:01 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:51:01 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:51:01 --> URI Class Initialized
INFO - 2018-02-06 07:51:01 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:51:01 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:51:01 --> Utf8 Class Initialized
INFO - 2018-02-06 07:51:01 --> URI Class Initialized
INFO - 2018-02-06 07:51:01 --> Router Class Initialized
INFO - 2018-02-06 07:51:01 --> URI Class Initialized
INFO - 2018-02-06 07:51:01 --> Router Class Initialized
INFO - 2018-02-06 07:51:01 --> Output Class Initialized
INFO - 2018-02-06 07:51:01 --> Router Class Initialized
INFO - 2018-02-06 07:51:01 --> Security Class Initialized
INFO - 2018-02-06 07:51:01 --> Output Class Initialized
INFO - 2018-02-06 07:51:01 --> Output Class Initialized
DEBUG - 2018-02-06 07:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:51:01 --> Input Class Initialized
INFO - 2018-02-06 07:51:01 --> Security Class Initialized
INFO - 2018-02-06 07:51:01 --> Security Class Initialized
INFO - 2018-02-06 07:51:01 --> Language Class Initialized
DEBUG - 2018-02-06 07:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:51:01 --> Input Class Initialized
ERROR - 2018-02-06 07:51:01 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-02-06 07:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:51:01 --> Input Class Initialized
INFO - 2018-02-06 07:51:01 --> Language Class Initialized
INFO - 2018-02-06 07:51:01 --> Language Class Initialized
ERROR - 2018-02-06 07:51:01 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-06 07:51:01 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-06 07:51:05 --> Config Class Initialized
INFO - 2018-02-06 07:51:05 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:51:05 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:51:05 --> Utf8 Class Initialized
INFO - 2018-02-06 07:51:05 --> URI Class Initialized
INFO - 2018-02-06 07:51:05 --> Router Class Initialized
INFO - 2018-02-06 07:51:05 --> Output Class Initialized
INFO - 2018-02-06 07:51:05 --> Security Class Initialized
DEBUG - 2018-02-06 07:51:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:51:05 --> Input Class Initialized
INFO - 2018-02-06 07:51:05 --> Language Class Initialized
INFO - 2018-02-06 07:51:05 --> Loader Class Initialized
INFO - 2018-02-06 07:51:05 --> Helper loaded: url_helper
INFO - 2018-02-06 07:51:05 --> Helper loaded: form_helper
INFO - 2018-02-06 07:51:05 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:51:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:51:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:51:05 --> Form Validation Class Initialized
INFO - 2018-02-06 07:51:05 --> Model Class Initialized
INFO - 2018-02-06 07:51:05 --> Controller Class Initialized
INFO - 2018-02-06 07:51:05 --> Model Class Initialized
DEBUG - 2018-02-06 07:51:05 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:51:05 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:51:05 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:51:05 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:51:05 --> Final output sent to browser
DEBUG - 2018-02-06 07:51:05 --> Total execution time: 0.0424
INFO - 2018-02-06 07:51:05 --> Config Class Initialized
INFO - 2018-02-06 07:51:05 --> Hooks Class Initialized
INFO - 2018-02-06 07:51:05 --> Config Class Initialized
INFO - 2018-02-06 07:51:05 --> Config Class Initialized
INFO - 2018-02-06 07:51:05 --> Hooks Class Initialized
INFO - 2018-02-06 07:51:05 --> Hooks Class Initialized
INFO - 2018-02-06 07:51:05 --> Config Class Initialized
INFO - 2018-02-06 07:51:05 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:51:05 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:51:05 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:51:05 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:51:05 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:51:05 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:51:05 --> Utf8 Class Initialized
INFO - 2018-02-06 07:51:05 --> URI Class Initialized
INFO - 2018-02-06 07:51:05 --> URI Class Initialized
INFO - 2018-02-06 07:51:05 --> URI Class Initialized
DEBUG - 2018-02-06 07:51:05 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:51:05 --> Utf8 Class Initialized
INFO - 2018-02-06 07:51:05 --> Router Class Initialized
INFO - 2018-02-06 07:51:05 --> Router Class Initialized
INFO - 2018-02-06 07:51:05 --> URI Class Initialized
INFO - 2018-02-06 07:51:05 --> Router Class Initialized
INFO - 2018-02-06 07:51:05 --> Output Class Initialized
INFO - 2018-02-06 07:51:05 --> Router Class Initialized
INFO - 2018-02-06 07:51:05 --> Output Class Initialized
INFO - 2018-02-06 07:51:05 --> Output Class Initialized
INFO - 2018-02-06 07:51:05 --> Security Class Initialized
INFO - 2018-02-06 07:51:05 --> Security Class Initialized
INFO - 2018-02-06 07:51:05 --> Output Class Initialized
INFO - 2018-02-06 07:51:05 --> Security Class Initialized
DEBUG - 2018-02-06 07:51:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:51:05 --> Input Class Initialized
DEBUG - 2018-02-06 07:51:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:51:05 --> Input Class Initialized
DEBUG - 2018-02-06 07:51:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:51:05 --> Security Class Initialized
INFO - 2018-02-06 07:51:05 --> Input Class Initialized
INFO - 2018-02-06 07:51:05 --> Language Class Initialized
INFO - 2018-02-06 07:51:05 --> Language Class Initialized
DEBUG - 2018-02-06 07:51:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:51:05 --> Language Class Initialized
INFO - 2018-02-06 07:51:05 --> Input Class Initialized
ERROR - 2018-02-06 07:51:05 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-06 07:51:05 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:51:05 --> Language Class Initialized
ERROR - 2018-02-06 07:51:05 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-06 07:51:05 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:51:05 --> Config Class Initialized
INFO - 2018-02-06 07:51:05 --> Hooks Class Initialized
INFO - 2018-02-06 07:51:05 --> Config Class Initialized
INFO - 2018-02-06 07:51:05 --> Hooks Class Initialized
INFO - 2018-02-06 07:51:05 --> Config Class Initialized
INFO - 2018-02-06 07:51:05 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:51:05 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:51:05 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:51:05 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:51:05 --> Utf8 Class Initialized
INFO - 2018-02-06 07:51:05 --> URI Class Initialized
DEBUG - 2018-02-06 07:51:05 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:51:05 --> Utf8 Class Initialized
INFO - 2018-02-06 07:51:05 --> URI Class Initialized
INFO - 2018-02-06 07:51:05 --> Router Class Initialized
INFO - 2018-02-06 07:51:05 --> URI Class Initialized
INFO - 2018-02-06 07:51:05 --> Router Class Initialized
INFO - 2018-02-06 07:51:05 --> Output Class Initialized
INFO - 2018-02-06 07:51:05 --> Router Class Initialized
INFO - 2018-02-06 07:51:05 --> Output Class Initialized
INFO - 2018-02-06 07:51:05 --> Security Class Initialized
INFO - 2018-02-06 07:51:05 --> Output Class Initialized
INFO - 2018-02-06 07:51:05 --> Security Class Initialized
DEBUG - 2018-02-06 07:51:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:51:05 --> Input Class Initialized
INFO - 2018-02-06 07:51:05 --> Security Class Initialized
DEBUG - 2018-02-06 07:51:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:51:05 --> Language Class Initialized
INFO - 2018-02-06 07:51:05 --> Input Class Initialized
DEBUG - 2018-02-06 07:51:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:51:05 --> Language Class Initialized
INFO - 2018-02-06 07:51:05 --> Input Class Initialized
ERROR - 2018-02-06 07:51:05 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-06 07:51:05 --> Language Class Initialized
ERROR - 2018-02-06 07:51:05 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-06 07:51:05 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-06 07:51:05 --> Config Class Initialized
INFO - 2018-02-06 07:51:05 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:51:05 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:51:05 --> Utf8 Class Initialized
INFO - 2018-02-06 07:51:05 --> URI Class Initialized
INFO - 2018-02-06 07:51:05 --> Router Class Initialized
INFO - 2018-02-06 07:51:05 --> Output Class Initialized
INFO - 2018-02-06 07:51:05 --> Security Class Initialized
DEBUG - 2018-02-06 07:51:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:51:05 --> Input Class Initialized
INFO - 2018-02-06 07:51:05 --> Language Class Initialized
INFO - 2018-02-06 07:51:05 --> Loader Class Initialized
INFO - 2018-02-06 07:51:05 --> Helper loaded: url_helper
INFO - 2018-02-06 07:51:05 --> Helper loaded: form_helper
INFO - 2018-02-06 07:51:05 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:51:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:51:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:51:05 --> Form Validation Class Initialized
INFO - 2018-02-06 07:51:05 --> Model Class Initialized
INFO - 2018-02-06 07:51:05 --> Controller Class Initialized
INFO - 2018-02-06 07:51:05 --> Model Class Initialized
DEBUG - 2018-02-06 07:51:05 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:51:05 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:51:05 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:51:05 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:51:05 --> Final output sent to browser
DEBUG - 2018-02-06 07:51:05 --> Total execution time: 0.0519
INFO - 2018-02-06 07:51:06 --> Config Class Initialized
INFO - 2018-02-06 07:51:06 --> Hooks Class Initialized
INFO - 2018-02-06 07:51:06 --> Config Class Initialized
INFO - 2018-02-06 07:51:06 --> Config Class Initialized
INFO - 2018-02-06 07:51:06 --> Hooks Class Initialized
INFO - 2018-02-06 07:51:06 --> Hooks Class Initialized
INFO - 2018-02-06 07:51:06 --> Config Class Initialized
INFO - 2018-02-06 07:51:06 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:51:06 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:51:06 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:51:06 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:51:06 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:51:06 --> Utf8 Class Initialized
INFO - 2018-02-06 07:51:06 --> Utf8 Class Initialized
INFO - 2018-02-06 07:51:06 --> URI Class Initialized
INFO - 2018-02-06 07:51:06 --> URI Class Initialized
DEBUG - 2018-02-06 07:51:06 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:51:06 --> URI Class Initialized
INFO - 2018-02-06 07:51:06 --> Utf8 Class Initialized
INFO - 2018-02-06 07:51:06 --> Router Class Initialized
INFO - 2018-02-06 07:51:06 --> Router Class Initialized
INFO - 2018-02-06 07:51:06 --> URI Class Initialized
INFO - 2018-02-06 07:51:06 --> Router Class Initialized
INFO - 2018-02-06 07:51:06 --> Output Class Initialized
INFO - 2018-02-06 07:51:06 --> Router Class Initialized
INFO - 2018-02-06 07:51:06 --> Output Class Initialized
INFO - 2018-02-06 07:51:06 --> Security Class Initialized
INFO - 2018-02-06 07:51:06 --> Output Class Initialized
INFO - 2018-02-06 07:51:06 --> Output Class Initialized
INFO - 2018-02-06 07:51:06 --> Security Class Initialized
DEBUG - 2018-02-06 07:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:51:06 --> Input Class Initialized
INFO - 2018-02-06 07:51:06 --> Security Class Initialized
INFO - 2018-02-06 07:51:06 --> Security Class Initialized
INFO - 2018-02-06 07:51:06 --> Language Class Initialized
DEBUG - 2018-02-06 07:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:51:06 --> Input Class Initialized
DEBUG - 2018-02-06 07:51:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:51:06 --> Language Class Initialized
INFO - 2018-02-06 07:51:06 --> Input Class Initialized
INFO - 2018-02-06 07:51:06 --> Input Class Initialized
ERROR - 2018-02-06 07:51:06 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:51:06 --> Language Class Initialized
INFO - 2018-02-06 07:51:06 --> Language Class Initialized
ERROR - 2018-02-06 07:51:06 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-06 07:51:06 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-06 07:51:06 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:51:06 --> Config Class Initialized
INFO - 2018-02-06 07:51:06 --> Hooks Class Initialized
INFO - 2018-02-06 07:51:06 --> Config Class Initialized
INFO - 2018-02-06 07:51:06 --> Config Class Initialized
INFO - 2018-02-06 07:51:06 --> Hooks Class Initialized
INFO - 2018-02-06 07:51:06 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:51:06 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:51:06 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:51:06 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:51:06 --> Utf8 Class Initialized
INFO - 2018-02-06 07:51:06 --> URI Class Initialized
DEBUG - 2018-02-06 07:51:06 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:51:06 --> URI Class Initialized
INFO - 2018-02-06 07:51:06 --> Utf8 Class Initialized
INFO - 2018-02-06 07:51:06 --> Router Class Initialized
INFO - 2018-02-06 07:51:06 --> URI Class Initialized
INFO - 2018-02-06 07:51:06 --> Router Class Initialized
INFO - 2018-02-06 07:51:06 --> Output Class Initialized
INFO - 2018-02-06 07:51:06 --> Router Class Initialized
INFO - 2018-02-06 07:51:06 --> Output Class Initialized
INFO - 2018-02-06 07:51:06 --> Security Class Initialized
INFO - 2018-02-06 07:51:06 --> Security Class Initialized
INFO - 2018-02-06 07:51:06 --> Output Class Initialized
DEBUG - 2018-02-06 07:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:51:06 --> Input Class Initialized
DEBUG - 2018-02-06 07:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:51:06 --> Language Class Initialized
INFO - 2018-02-06 07:51:06 --> Security Class Initialized
INFO - 2018-02-06 07:51:06 --> Input Class Initialized
INFO - 2018-02-06 07:51:06 --> Language Class Initialized
DEBUG - 2018-02-06 07:51:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-06 07:51:06 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-06 07:51:06 --> Input Class Initialized
INFO - 2018-02-06 07:51:06 --> Language Class Initialized
ERROR - 2018-02-06 07:51:06 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-06 07:51:06 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-06 07:51:06 --> Config Class Initialized
INFO - 2018-02-06 07:51:06 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:51:06 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:51:06 --> Utf8 Class Initialized
INFO - 2018-02-06 07:51:06 --> URI Class Initialized
INFO - 2018-02-06 07:51:06 --> Router Class Initialized
INFO - 2018-02-06 07:51:06 --> Output Class Initialized
INFO - 2018-02-06 07:51:06 --> Security Class Initialized
DEBUG - 2018-02-06 07:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:51:06 --> Input Class Initialized
INFO - 2018-02-06 07:51:06 --> Language Class Initialized
INFO - 2018-02-06 07:51:06 --> Loader Class Initialized
INFO - 2018-02-06 07:51:06 --> Helper loaded: url_helper
INFO - 2018-02-06 07:51:06 --> Helper loaded: form_helper
INFO - 2018-02-06 07:51:06 --> Database Driver Class Initialized
DEBUG - 2018-02-06 07:51:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-06 07:51:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-06 07:51:06 --> Form Validation Class Initialized
INFO - 2018-02-06 07:51:06 --> Model Class Initialized
INFO - 2018-02-06 07:51:06 --> Controller Class Initialized
INFO - 2018-02-06 07:51:06 --> Model Class Initialized
DEBUG - 2018-02-06 07:51:06 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-06 07:51:06 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
ERROR - 2018-02-06 07:51:06 --> Severity: Notice --> Undefined property: stdClass::$moneda_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\colaborador\editarColaborador.php 122
INFO - 2018-02-06 07:51:06 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-06 07:51:06 --> Final output sent to browser
DEBUG - 2018-02-06 07:51:06 --> Total execution time: 0.0509
INFO - 2018-02-06 07:51:06 --> Config Class Initialized
INFO - 2018-02-06 07:51:06 --> Config Class Initialized
INFO - 2018-02-06 07:51:06 --> Hooks Class Initialized
INFO - 2018-02-06 07:51:06 --> Config Class Initialized
INFO - 2018-02-06 07:51:06 --> Hooks Class Initialized
INFO - 2018-02-06 07:51:06 --> Hooks Class Initialized
INFO - 2018-02-06 07:51:06 --> Config Class Initialized
INFO - 2018-02-06 07:51:06 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:51:06 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:51:06 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:51:06 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:51:06 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:51:06 --> Utf8 Class Initialized
INFO - 2018-02-06 07:51:06 --> Utf8 Class Initialized
DEBUG - 2018-02-06 07:51:06 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:51:06 --> Utf8 Class Initialized
INFO - 2018-02-06 07:51:06 --> URI Class Initialized
INFO - 2018-02-06 07:51:06 --> URI Class Initialized
INFO - 2018-02-06 07:51:06 --> URI Class Initialized
INFO - 2018-02-06 07:51:06 --> URI Class Initialized
INFO - 2018-02-06 07:51:06 --> Router Class Initialized
INFO - 2018-02-06 07:51:06 --> Router Class Initialized
INFO - 2018-02-06 07:51:06 --> Router Class Initialized
INFO - 2018-02-06 07:51:06 --> Router Class Initialized
INFO - 2018-02-06 07:51:06 --> Output Class Initialized
INFO - 2018-02-06 07:51:06 --> Output Class Initialized
INFO - 2018-02-06 07:51:06 --> Security Class Initialized
INFO - 2018-02-06 07:51:06 --> Output Class Initialized
INFO - 2018-02-06 07:51:06 --> Output Class Initialized
INFO - 2018-02-06 07:51:06 --> Security Class Initialized
DEBUG - 2018-02-06 07:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:51:06 --> Input Class Initialized
INFO - 2018-02-06 07:51:06 --> Security Class Initialized
INFO - 2018-02-06 07:51:06 --> Security Class Initialized
DEBUG - 2018-02-06 07:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:51:06 --> Language Class Initialized
INFO - 2018-02-06 07:51:06 --> Input Class Initialized
DEBUG - 2018-02-06 07:51:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:51:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-06 07:51:06 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:51:06 --> Input Class Initialized
INFO - 2018-02-06 07:51:06 --> Language Class Initialized
INFO - 2018-02-06 07:51:06 --> Input Class Initialized
INFO - 2018-02-06 07:51:06 --> Language Class Initialized
INFO - 2018-02-06 07:51:06 --> Language Class Initialized
ERROR - 2018-02-06 07:51:06 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-06 07:51:06 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-06 07:51:06 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-06 07:51:06 --> Config Class Initialized
INFO - 2018-02-06 07:51:06 --> Hooks Class Initialized
INFO - 2018-02-06 07:51:06 --> Config Class Initialized
INFO - 2018-02-06 07:51:06 --> Hooks Class Initialized
DEBUG - 2018-02-06 07:51:06 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:51:06 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:51:06 --> Utf8 Class Initialized
INFO - 2018-02-06 07:51:06 --> Utf8 Class Initialized
INFO - 2018-02-06 07:51:06 --> Config Class Initialized
INFO - 2018-02-06 07:51:06 --> Hooks Class Initialized
INFO - 2018-02-06 07:51:06 --> URI Class Initialized
INFO - 2018-02-06 07:51:06 --> URI Class Initialized
INFO - 2018-02-06 07:51:06 --> Router Class Initialized
INFO - 2018-02-06 07:51:06 --> Router Class Initialized
DEBUG - 2018-02-06 07:51:06 --> UTF-8 Support Enabled
INFO - 2018-02-06 07:51:06 --> Utf8 Class Initialized
INFO - 2018-02-06 07:51:06 --> Output Class Initialized
INFO - 2018-02-06 07:51:06 --> Output Class Initialized
INFO - 2018-02-06 07:51:06 --> URI Class Initialized
INFO - 2018-02-06 07:51:06 --> Security Class Initialized
INFO - 2018-02-06 07:51:06 --> Security Class Initialized
INFO - 2018-02-06 07:51:06 --> Router Class Initialized
DEBUG - 2018-02-06 07:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:51:06 --> Input Class Initialized
DEBUG - 2018-02-06 07:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:51:06 --> Input Class Initialized
INFO - 2018-02-06 07:51:06 --> Language Class Initialized
INFO - 2018-02-06 07:51:06 --> Output Class Initialized
INFO - 2018-02-06 07:51:06 --> Language Class Initialized
ERROR - 2018-02-06 07:51:06 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-06 07:51:06 --> Security Class Initialized
ERROR - 2018-02-06 07:51:06 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-02-06 07:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-06 07:51:06 --> Input Class Initialized
INFO - 2018-02-06 07:51:06 --> Language Class Initialized
ERROR - 2018-02-06 07:51:06 --> 404 Page Not Found: Instatec_pub/css
