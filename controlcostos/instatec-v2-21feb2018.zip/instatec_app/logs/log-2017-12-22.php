<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-12-22 03:27:45 --> Config Class Initialized
INFO - 2017-12-22 03:27:45 --> Hooks Class Initialized
DEBUG - 2017-12-22 03:27:45 --> UTF-8 Support Enabled
INFO - 2017-12-22 03:27:45 --> Utf8 Class Initialized
INFO - 2017-12-22 03:27:45 --> URI Class Initialized
DEBUG - 2017-12-22 03:27:45 --> No URI present. Default controller set.
INFO - 2017-12-22 03:27:45 --> Router Class Initialized
INFO - 2017-12-22 03:27:46 --> Output Class Initialized
INFO - 2017-12-22 03:27:46 --> Security Class Initialized
DEBUG - 2017-12-22 03:27:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 03:27:46 --> Input Class Initialized
INFO - 2017-12-22 03:27:46 --> Language Class Initialized
INFO - 2017-12-22 03:27:46 --> Loader Class Initialized
INFO - 2017-12-22 03:27:46 --> Helper loaded: url_helper
INFO - 2017-12-22 03:27:46 --> Helper loaded: form_helper
INFO - 2017-12-22 03:27:46 --> Database Driver Class Initialized
DEBUG - 2017-12-22 03:27:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 03:27:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 03:27:46 --> Form Validation Class Initialized
INFO - 2017-12-22 03:27:46 --> Model Class Initialized
INFO - 2017-12-22 03:27:46 --> Controller Class Initialized
INFO - 2017-12-22 03:27:46 --> Config Class Initialized
INFO - 2017-12-22 03:27:46 --> Hooks Class Initialized
DEBUG - 2017-12-22 03:27:46 --> UTF-8 Support Enabled
INFO - 2017-12-22 03:27:46 --> Utf8 Class Initialized
INFO - 2017-12-22 03:27:46 --> URI Class Initialized
INFO - 2017-12-22 03:27:46 --> Config Class Initialized
INFO - 2017-12-22 03:27:46 --> Hooks Class Initialized
DEBUG - 2017-12-22 03:27:46 --> UTF-8 Support Enabled
INFO - 2017-12-22 03:27:46 --> Utf8 Class Initialized
INFO - 2017-12-22 03:27:46 --> Router Class Initialized
INFO - 2017-12-22 03:27:46 --> URI Class Initialized
INFO - 2017-12-22 03:27:46 --> Output Class Initialized
INFO - 2017-12-22 03:27:46 --> Security Class Initialized
INFO - 2017-12-22 03:27:46 --> Router Class Initialized
DEBUG - 2017-12-22 03:27:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 03:27:46 --> Input Class Initialized
INFO - 2017-12-22 03:27:46 --> Language Class Initialized
INFO - 2017-12-22 03:27:46 --> Output Class Initialized
INFO - 2017-12-22 03:27:46 --> Security Class Initialized
DEBUG - 2017-12-22 03:27:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 03:27:46 --> Input Class Initialized
INFO - 2017-12-22 03:27:46 --> Language Class Initialized
INFO - 2017-12-22 03:27:46 --> Loader Class Initialized
INFO - 2017-12-22 03:27:46 --> Helper loaded: url_helper
INFO - 2017-12-22 03:27:46 --> Helper loaded: form_helper
ERROR - 2017-12-22 03:27:46 --> 404 Page Not Found: Faviconico/index
INFO - 2017-12-22 03:27:46 --> Database Driver Class Initialized
DEBUG - 2017-12-22 03:27:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 03:27:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 03:27:46 --> Form Validation Class Initialized
INFO - 2017-12-22 03:27:46 --> Model Class Initialized
INFO - 2017-12-22 03:27:46 --> Controller Class Initialized
INFO - 2017-12-22 03:27:46 --> Model Class Initialized
DEBUG - 2017-12-22 03:27:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 03:27:46 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 03:27:46 --> Final output sent to browser
DEBUG - 2017-12-22 03:27:46 --> Total execution time: 0.2006
INFO - 2017-12-22 03:27:48 --> Config Class Initialized
INFO - 2017-12-22 03:27:48 --> Hooks Class Initialized
DEBUG - 2017-12-22 03:27:48 --> UTF-8 Support Enabled
INFO - 2017-12-22 03:27:48 --> Utf8 Class Initialized
INFO - 2017-12-22 03:27:48 --> URI Class Initialized
INFO - 2017-12-22 03:27:48 --> Router Class Initialized
INFO - 2017-12-22 03:27:48 --> Output Class Initialized
INFO - 2017-12-22 03:27:48 --> Security Class Initialized
DEBUG - 2017-12-22 03:27:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 03:27:48 --> Input Class Initialized
INFO - 2017-12-22 03:27:48 --> Language Class Initialized
INFO - 2017-12-22 03:27:48 --> Loader Class Initialized
INFO - 2017-12-22 03:27:48 --> Helper loaded: url_helper
INFO - 2017-12-22 03:27:48 --> Helper loaded: form_helper
INFO - 2017-12-22 03:27:48 --> Database Driver Class Initialized
DEBUG - 2017-12-22 03:27:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 03:27:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 03:27:48 --> Form Validation Class Initialized
INFO - 2017-12-22 03:27:48 --> Model Class Initialized
INFO - 2017-12-22 03:27:48 --> Controller Class Initialized
INFO - 2017-12-22 03:27:48 --> Model Class Initialized
DEBUG - 2017-12-22 03:27:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 03:27:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-12-22 03:27:48 --> Config Class Initialized
INFO - 2017-12-22 03:27:48 --> Hooks Class Initialized
DEBUG - 2017-12-22 03:27:48 --> UTF-8 Support Enabled
INFO - 2017-12-22 03:27:48 --> Utf8 Class Initialized
INFO - 2017-12-22 03:27:48 --> URI Class Initialized
DEBUG - 2017-12-22 03:27:48 --> No URI present. Default controller set.
INFO - 2017-12-22 03:27:48 --> Router Class Initialized
INFO - 2017-12-22 03:27:48 --> Output Class Initialized
INFO - 2017-12-22 03:27:48 --> Security Class Initialized
DEBUG - 2017-12-22 03:27:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 03:27:48 --> Input Class Initialized
INFO - 2017-12-22 03:27:48 --> Language Class Initialized
INFO - 2017-12-22 03:27:48 --> Loader Class Initialized
INFO - 2017-12-22 03:27:48 --> Helper loaded: url_helper
INFO - 2017-12-22 03:27:48 --> Helper loaded: form_helper
INFO - 2017-12-22 03:27:48 --> Database Driver Class Initialized
DEBUG - 2017-12-22 03:27:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 03:27:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 03:27:48 --> Form Validation Class Initialized
INFO - 2017-12-22 03:27:48 --> Model Class Initialized
INFO - 2017-12-22 03:27:48 --> Controller Class Initialized
INFO - 2017-12-22 03:27:48 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 03:27:48 --> Final output sent to browser
DEBUG - 2017-12-22 03:27:48 --> Total execution time: 0.1031
INFO - 2017-12-22 05:30:48 --> Config Class Initialized
INFO - 2017-12-22 05:30:48 --> Hooks Class Initialized
DEBUG - 2017-12-22 05:30:48 --> UTF-8 Support Enabled
INFO - 2017-12-22 05:30:48 --> Utf8 Class Initialized
INFO - 2017-12-22 05:30:48 --> URI Class Initialized
INFO - 2017-12-22 05:30:48 --> Router Class Initialized
INFO - 2017-12-22 05:30:48 --> Output Class Initialized
INFO - 2017-12-22 05:30:48 --> Security Class Initialized
DEBUG - 2017-12-22 05:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 05:30:48 --> Input Class Initialized
INFO - 2017-12-22 05:30:48 --> Language Class Initialized
INFO - 2017-12-22 05:30:48 --> Loader Class Initialized
INFO - 2017-12-22 05:30:48 --> Helper loaded: url_helper
INFO - 2017-12-22 05:30:48 --> Helper loaded: form_helper
INFO - 2017-12-22 05:30:48 --> Database Driver Class Initialized
DEBUG - 2017-12-22 05:30:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 05:30:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 05:30:48 --> Form Validation Class Initialized
INFO - 2017-12-22 05:30:48 --> Model Class Initialized
INFO - 2017-12-22 05:30:48 --> Controller Class Initialized
INFO - 2017-12-22 05:30:48 --> Model Class Initialized
INFO - 2017-12-22 05:30:48 --> Model Class Initialized
INFO - 2017-12-22 05:30:48 --> Model Class Initialized
DEBUG - 2017-12-22 05:30:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 05:30:48 --> Config Class Initialized
INFO - 2017-12-22 05:30:48 --> Hooks Class Initialized
DEBUG - 2017-12-22 05:30:48 --> UTF-8 Support Enabled
INFO - 2017-12-22 05:30:48 --> Utf8 Class Initialized
INFO - 2017-12-22 05:30:48 --> URI Class Initialized
INFO - 2017-12-22 05:30:48 --> Router Class Initialized
INFO - 2017-12-22 05:30:48 --> Output Class Initialized
INFO - 2017-12-22 05:30:48 --> Security Class Initialized
DEBUG - 2017-12-22 05:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 05:30:48 --> Input Class Initialized
INFO - 2017-12-22 05:30:48 --> Language Class Initialized
INFO - 2017-12-22 05:30:48 --> Loader Class Initialized
INFO - 2017-12-22 05:30:48 --> Helper loaded: url_helper
INFO - 2017-12-22 05:30:48 --> Helper loaded: form_helper
INFO - 2017-12-22 05:30:48 --> Database Driver Class Initialized
DEBUG - 2017-12-22 05:30:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 05:30:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 05:30:48 --> Form Validation Class Initialized
INFO - 2017-12-22 05:30:48 --> Model Class Initialized
INFO - 2017-12-22 05:30:48 --> Controller Class Initialized
INFO - 2017-12-22 05:30:48 --> Model Class Initialized
DEBUG - 2017-12-22 05:30:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 05:30:48 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 05:30:48 --> Final output sent to browser
DEBUG - 2017-12-22 05:30:48 --> Total execution time: 0.0512
INFO - 2017-12-22 05:30:50 --> Config Class Initialized
INFO - 2017-12-22 05:30:50 --> Hooks Class Initialized
DEBUG - 2017-12-22 05:30:50 --> UTF-8 Support Enabled
INFO - 2017-12-22 05:30:50 --> Utf8 Class Initialized
INFO - 2017-12-22 05:30:50 --> URI Class Initialized
INFO - 2017-12-22 05:30:50 --> Router Class Initialized
INFO - 2017-12-22 05:30:50 --> Output Class Initialized
INFO - 2017-12-22 05:30:50 --> Security Class Initialized
DEBUG - 2017-12-22 05:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 05:30:50 --> Input Class Initialized
INFO - 2017-12-22 05:30:50 --> Language Class Initialized
INFO - 2017-12-22 05:30:50 --> Loader Class Initialized
INFO - 2017-12-22 05:30:50 --> Helper loaded: url_helper
INFO - 2017-12-22 05:30:50 --> Helper loaded: form_helper
INFO - 2017-12-22 05:30:50 --> Database Driver Class Initialized
DEBUG - 2017-12-22 05:30:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 05:30:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 05:30:50 --> Form Validation Class Initialized
INFO - 2017-12-22 05:30:50 --> Model Class Initialized
INFO - 2017-12-22 05:30:50 --> Controller Class Initialized
INFO - 2017-12-22 05:30:50 --> Model Class Initialized
DEBUG - 2017-12-22 05:30:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 05:30:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-12-22 05:30:50 --> Config Class Initialized
INFO - 2017-12-22 05:30:50 --> Hooks Class Initialized
DEBUG - 2017-12-22 05:30:50 --> UTF-8 Support Enabled
INFO - 2017-12-22 05:30:50 --> Utf8 Class Initialized
INFO - 2017-12-22 05:30:50 --> URI Class Initialized
DEBUG - 2017-12-22 05:30:50 --> No URI present. Default controller set.
INFO - 2017-12-22 05:30:50 --> Router Class Initialized
INFO - 2017-12-22 05:30:50 --> Output Class Initialized
INFO - 2017-12-22 05:30:50 --> Security Class Initialized
DEBUG - 2017-12-22 05:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 05:30:50 --> Input Class Initialized
INFO - 2017-12-22 05:30:50 --> Language Class Initialized
INFO - 2017-12-22 05:30:50 --> Loader Class Initialized
INFO - 2017-12-22 05:30:50 --> Helper loaded: url_helper
INFO - 2017-12-22 05:30:50 --> Helper loaded: form_helper
INFO - 2017-12-22 05:30:50 --> Database Driver Class Initialized
DEBUG - 2017-12-22 05:30:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 05:30:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 05:30:50 --> Form Validation Class Initialized
INFO - 2017-12-22 05:30:50 --> Model Class Initialized
INFO - 2017-12-22 05:30:50 --> Controller Class Initialized
INFO - 2017-12-22 05:30:50 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 05:30:50 --> Final output sent to browser
DEBUG - 2017-12-22 05:30:50 --> Total execution time: 0.0428
INFO - 2017-12-22 05:30:51 --> Config Class Initialized
INFO - 2017-12-22 05:30:51 --> Hooks Class Initialized
DEBUG - 2017-12-22 05:30:51 --> UTF-8 Support Enabled
INFO - 2017-12-22 05:30:51 --> Utf8 Class Initialized
INFO - 2017-12-22 05:30:51 --> URI Class Initialized
INFO - 2017-12-22 05:30:51 --> Router Class Initialized
INFO - 2017-12-22 05:30:51 --> Output Class Initialized
INFO - 2017-12-22 05:30:51 --> Security Class Initialized
DEBUG - 2017-12-22 05:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 05:30:51 --> Input Class Initialized
INFO - 2017-12-22 05:30:51 --> Language Class Initialized
INFO - 2017-12-22 05:30:51 --> Loader Class Initialized
INFO - 2017-12-22 05:30:51 --> Helper loaded: url_helper
INFO - 2017-12-22 05:30:51 --> Helper loaded: form_helper
INFO - 2017-12-22 05:30:51 --> Database Driver Class Initialized
DEBUG - 2017-12-22 05:30:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 05:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 05:30:51 --> Form Validation Class Initialized
INFO - 2017-12-22 05:30:51 --> Model Class Initialized
INFO - 2017-12-22 05:30:51 --> Controller Class Initialized
INFO - 2017-12-22 05:30:51 --> Model Class Initialized
INFO - 2017-12-22 05:30:51 --> Model Class Initialized
INFO - 2017-12-22 05:30:51 --> Model Class Initialized
DEBUG - 2017-12-22 05:30:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 05:30:51 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 05:30:51 --> Final output sent to browser
DEBUG - 2017-12-22 05:30:51 --> Total execution time: 0.0942
INFO - 2017-12-22 05:30:51 --> Config Class Initialized
INFO - 2017-12-22 05:30:51 --> Hooks Class Initialized
DEBUG - 2017-12-22 05:30:51 --> UTF-8 Support Enabled
INFO - 2017-12-22 05:30:51 --> Utf8 Class Initialized
INFO - 2017-12-22 05:30:51 --> URI Class Initialized
INFO - 2017-12-22 05:30:51 --> Router Class Initialized
INFO - 2017-12-22 05:30:51 --> Output Class Initialized
INFO - 2017-12-22 05:30:51 --> Security Class Initialized
DEBUG - 2017-12-22 05:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 05:30:51 --> Input Class Initialized
INFO - 2017-12-22 05:30:51 --> Language Class Initialized
INFO - 2017-12-22 05:30:51 --> Loader Class Initialized
INFO - 2017-12-22 05:30:51 --> Helper loaded: url_helper
INFO - 2017-12-22 05:30:51 --> Helper loaded: form_helper
INFO - 2017-12-22 05:30:51 --> Database Driver Class Initialized
DEBUG - 2017-12-22 05:30:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 05:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 05:30:51 --> Form Validation Class Initialized
INFO - 2017-12-22 05:30:51 --> Model Class Initialized
INFO - 2017-12-22 05:30:51 --> Controller Class Initialized
INFO - 2017-12-22 05:30:51 --> Model Class Initialized
INFO - 2017-12-22 05:30:51 --> Model Class Initialized
INFO - 2017-12-22 05:30:51 --> Model Class Initialized
DEBUG - 2017-12-22 05:30:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 05:30:54 --> Config Class Initialized
INFO - 2017-12-22 05:30:54 --> Hooks Class Initialized
DEBUG - 2017-12-22 05:30:54 --> UTF-8 Support Enabled
INFO - 2017-12-22 05:30:54 --> Utf8 Class Initialized
INFO - 2017-12-22 05:30:54 --> URI Class Initialized
INFO - 2017-12-22 05:30:54 --> Router Class Initialized
INFO - 2017-12-22 05:30:54 --> Output Class Initialized
INFO - 2017-12-22 05:30:54 --> Security Class Initialized
DEBUG - 2017-12-22 05:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 05:30:54 --> Input Class Initialized
INFO - 2017-12-22 05:30:54 --> Language Class Initialized
INFO - 2017-12-22 05:30:54 --> Loader Class Initialized
INFO - 2017-12-22 05:30:54 --> Helper loaded: url_helper
INFO - 2017-12-22 05:30:54 --> Helper loaded: form_helper
INFO - 2017-12-22 05:30:54 --> Database Driver Class Initialized
DEBUG - 2017-12-22 05:30:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 05:30:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 05:30:54 --> Form Validation Class Initialized
INFO - 2017-12-22 05:30:54 --> Model Class Initialized
INFO - 2017-12-22 05:30:54 --> Controller Class Initialized
INFO - 2017-12-22 05:30:54 --> Model Class Initialized
INFO - 2017-12-22 05:30:54 --> Model Class Initialized
INFO - 2017-12-22 05:30:54 --> Model Class Initialized
DEBUG - 2017-12-22 05:30:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 05:30:54 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 05:30:54 --> Final output sent to browser
DEBUG - 2017-12-22 05:30:54 --> Total execution time: 0.1245
INFO - 2017-12-22 05:30:54 --> Config Class Initialized
INFO - 2017-12-22 05:30:54 --> Hooks Class Initialized
DEBUG - 2017-12-22 05:30:54 --> UTF-8 Support Enabled
INFO - 2017-12-22 05:30:54 --> Utf8 Class Initialized
INFO - 2017-12-22 05:30:54 --> URI Class Initialized
INFO - 2017-12-22 05:30:54 --> Router Class Initialized
INFO - 2017-12-22 05:30:54 --> Output Class Initialized
INFO - 2017-12-22 05:30:54 --> Security Class Initialized
DEBUG - 2017-12-22 05:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 05:30:54 --> Input Class Initialized
INFO - 2017-12-22 05:30:54 --> Language Class Initialized
INFO - 2017-12-22 05:30:54 --> Loader Class Initialized
INFO - 2017-12-22 05:30:54 --> Helper loaded: url_helper
INFO - 2017-12-22 05:30:54 --> Helper loaded: form_helper
INFO - 2017-12-22 05:30:54 --> Database Driver Class Initialized
DEBUG - 2017-12-22 05:30:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 05:30:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 05:30:54 --> Form Validation Class Initialized
INFO - 2017-12-22 05:30:54 --> Model Class Initialized
INFO - 2017-12-22 05:30:54 --> Controller Class Initialized
INFO - 2017-12-22 05:30:54 --> Model Class Initialized
INFO - 2017-12-22 05:30:54 --> Model Class Initialized
INFO - 2017-12-22 05:30:54 --> Model Class Initialized
DEBUG - 2017-12-22 05:30:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 05:37:43 --> Config Class Initialized
INFO - 2017-12-22 05:37:43 --> Hooks Class Initialized
DEBUG - 2017-12-22 05:37:43 --> UTF-8 Support Enabled
INFO - 2017-12-22 05:37:43 --> Utf8 Class Initialized
INFO - 2017-12-22 05:37:43 --> URI Class Initialized
INFO - 2017-12-22 05:37:43 --> Router Class Initialized
INFO - 2017-12-22 05:37:43 --> Output Class Initialized
INFO - 2017-12-22 05:37:43 --> Security Class Initialized
DEBUG - 2017-12-22 05:37:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 05:37:43 --> Input Class Initialized
INFO - 2017-12-22 05:37:43 --> Language Class Initialized
INFO - 2017-12-22 05:37:43 --> Loader Class Initialized
INFO - 2017-12-22 05:37:43 --> Helper loaded: url_helper
INFO - 2017-12-22 05:37:43 --> Helper loaded: form_helper
INFO - 2017-12-22 05:37:43 --> Database Driver Class Initialized
DEBUG - 2017-12-22 05:37:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 05:37:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 05:37:43 --> Form Validation Class Initialized
INFO - 2017-12-22 05:37:43 --> Model Class Initialized
INFO - 2017-12-22 05:37:43 --> Controller Class Initialized
INFO - 2017-12-22 05:37:43 --> Model Class Initialized
INFO - 2017-12-22 05:37:43 --> Model Class Initialized
INFO - 2017-12-22 05:37:43 --> Model Class Initialized
DEBUG - 2017-12-22 05:37:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 05:37:43 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 05:37:43 --> Final output sent to browser
DEBUG - 2017-12-22 05:37:43 --> Total execution time: 0.0469
INFO - 2017-12-22 05:37:44 --> Config Class Initialized
INFO - 2017-12-22 05:37:44 --> Hooks Class Initialized
DEBUG - 2017-12-22 05:37:44 --> UTF-8 Support Enabled
INFO - 2017-12-22 05:37:44 --> Utf8 Class Initialized
INFO - 2017-12-22 05:37:44 --> URI Class Initialized
INFO - 2017-12-22 05:37:44 --> Router Class Initialized
INFO - 2017-12-22 05:37:44 --> Output Class Initialized
INFO - 2017-12-22 05:37:44 --> Security Class Initialized
DEBUG - 2017-12-22 05:37:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 05:37:44 --> Input Class Initialized
INFO - 2017-12-22 05:37:44 --> Language Class Initialized
INFO - 2017-12-22 05:37:44 --> Loader Class Initialized
INFO - 2017-12-22 05:37:44 --> Helper loaded: url_helper
INFO - 2017-12-22 05:37:44 --> Helper loaded: form_helper
INFO - 2017-12-22 05:37:44 --> Database Driver Class Initialized
DEBUG - 2017-12-22 05:37:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 05:37:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 05:37:44 --> Form Validation Class Initialized
INFO - 2017-12-22 05:37:44 --> Model Class Initialized
INFO - 2017-12-22 05:37:44 --> Controller Class Initialized
INFO - 2017-12-22 05:37:44 --> Model Class Initialized
INFO - 2017-12-22 05:37:44 --> Model Class Initialized
INFO - 2017-12-22 05:37:44 --> Model Class Initialized
DEBUG - 2017-12-22 05:37:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 05:37:44 --> Config Class Initialized
INFO - 2017-12-22 05:37:44 --> Hooks Class Initialized
DEBUG - 2017-12-22 05:37:44 --> UTF-8 Support Enabled
INFO - 2017-12-22 05:37:44 --> Utf8 Class Initialized
INFO - 2017-12-22 05:37:44 --> URI Class Initialized
INFO - 2017-12-22 05:37:44 --> Router Class Initialized
INFO - 2017-12-22 05:37:44 --> Output Class Initialized
INFO - 2017-12-22 05:37:44 --> Security Class Initialized
DEBUG - 2017-12-22 05:37:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 05:37:44 --> Input Class Initialized
INFO - 2017-12-22 05:37:44 --> Language Class Initialized
INFO - 2017-12-22 05:37:44 --> Loader Class Initialized
INFO - 2017-12-22 05:37:44 --> Helper loaded: url_helper
INFO - 2017-12-22 05:37:44 --> Helper loaded: form_helper
INFO - 2017-12-22 05:37:44 --> Database Driver Class Initialized
DEBUG - 2017-12-22 05:37:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 05:37:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 05:37:44 --> Form Validation Class Initialized
INFO - 2017-12-22 05:37:44 --> Model Class Initialized
INFO - 2017-12-22 05:37:44 --> Controller Class Initialized
INFO - 2017-12-22 05:37:44 --> Model Class Initialized
INFO - 2017-12-22 05:37:44 --> Model Class Initialized
INFO - 2017-12-22 05:37:44 --> Model Class Initialized
DEBUG - 2017-12-22 05:37:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 05:37:44 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 05:37:44 --> Final output sent to browser
DEBUG - 2017-12-22 05:37:44 --> Total execution time: 0.0567
INFO - 2017-12-22 05:37:44 --> Config Class Initialized
INFO - 2017-12-22 05:37:44 --> Hooks Class Initialized
INFO - 2017-12-22 05:37:44 --> Config Class Initialized
INFO - 2017-12-22 05:37:44 --> Hooks Class Initialized
DEBUG - 2017-12-22 05:37:44 --> UTF-8 Support Enabled
INFO - 2017-12-22 05:37:44 --> Utf8 Class Initialized
DEBUG - 2017-12-22 05:37:44 --> UTF-8 Support Enabled
INFO - 2017-12-22 05:37:44 --> Utf8 Class Initialized
INFO - 2017-12-22 05:37:44 --> URI Class Initialized
INFO - 2017-12-22 05:37:44 --> URI Class Initialized
INFO - 2017-12-22 05:37:44 --> Router Class Initialized
INFO - 2017-12-22 05:37:44 --> Output Class Initialized
INFO - 2017-12-22 05:37:44 --> Router Class Initialized
INFO - 2017-12-22 05:37:44 --> Security Class Initialized
INFO - 2017-12-22 05:37:45 --> Output Class Initialized
DEBUG - 2017-12-22 05:37:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 05:37:45 --> Input Class Initialized
INFO - 2017-12-22 05:37:45 --> Security Class Initialized
INFO - 2017-12-22 05:37:45 --> Language Class Initialized
DEBUG - 2017-12-22 05:37:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 05:37:45 --> Input Class Initialized
INFO - 2017-12-22 05:37:45 --> Language Class Initialized
INFO - 2017-12-22 05:37:45 --> Loader Class Initialized
INFO - 2017-12-22 05:37:45 --> Loader Class Initialized
INFO - 2017-12-22 05:37:45 --> Helper loaded: url_helper
INFO - 2017-12-22 05:37:45 --> Helper loaded: url_helper
INFO - 2017-12-22 05:37:45 --> Helper loaded: form_helper
INFO - 2017-12-22 05:37:45 --> Helper loaded: form_helper
INFO - 2017-12-22 05:37:45 --> Database Driver Class Initialized
INFO - 2017-12-22 05:37:45 --> Database Driver Class Initialized
DEBUG - 2017-12-22 05:37:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 05:37:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2017-12-22 05:37:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 05:37:45 --> Form Validation Class Initialized
INFO - 2017-12-22 05:37:45 --> Model Class Initialized
INFO - 2017-12-22 05:37:45 --> Controller Class Initialized
INFO - 2017-12-22 05:37:45 --> Model Class Initialized
INFO - 2017-12-22 05:37:45 --> Model Class Initialized
INFO - 2017-12-22 05:37:45 --> Model Class Initialized
DEBUG - 2017-12-22 05:37:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 05:37:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 05:37:45 --> Form Validation Class Initialized
INFO - 2017-12-22 05:37:45 --> Model Class Initialized
INFO - 2017-12-22 05:37:45 --> Controller Class Initialized
INFO - 2017-12-22 05:37:45 --> Model Class Initialized
INFO - 2017-12-22 05:37:45 --> Model Class Initialized
INFO - 2017-12-22 05:37:45 --> Model Class Initialized
DEBUG - 2017-12-22 05:37:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 05:37:45 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 05:37:45 --> Final output sent to browser
DEBUG - 2017-12-22 05:37:45 --> Total execution time: 0.0964
INFO - 2017-12-22 05:37:45 --> Config Class Initialized
INFO - 2017-12-22 05:37:45 --> Hooks Class Initialized
DEBUG - 2017-12-22 05:37:45 --> UTF-8 Support Enabled
INFO - 2017-12-22 05:37:45 --> Utf8 Class Initialized
INFO - 2017-12-22 05:37:45 --> URI Class Initialized
INFO - 2017-12-22 05:37:45 --> Router Class Initialized
INFO - 2017-12-22 05:37:45 --> Output Class Initialized
INFO - 2017-12-22 05:37:45 --> Security Class Initialized
DEBUG - 2017-12-22 05:37:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 05:37:45 --> Input Class Initialized
INFO - 2017-12-22 05:37:45 --> Language Class Initialized
INFO - 2017-12-22 05:37:45 --> Loader Class Initialized
INFO - 2017-12-22 05:37:45 --> Helper loaded: url_helper
INFO - 2017-12-22 05:37:45 --> Helper loaded: form_helper
INFO - 2017-12-22 05:37:45 --> Database Driver Class Initialized
DEBUG - 2017-12-22 05:37:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 05:37:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 05:37:45 --> Form Validation Class Initialized
INFO - 2017-12-22 05:37:45 --> Model Class Initialized
INFO - 2017-12-22 05:37:45 --> Controller Class Initialized
INFO - 2017-12-22 05:37:45 --> Model Class Initialized
INFO - 2017-12-22 05:37:45 --> Model Class Initialized
INFO - 2017-12-22 05:37:45 --> Model Class Initialized
DEBUG - 2017-12-22 05:37:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 05:37:45 --> Config Class Initialized
INFO - 2017-12-22 05:37:45 --> Hooks Class Initialized
DEBUG - 2017-12-22 05:37:45 --> UTF-8 Support Enabled
INFO - 2017-12-22 05:37:45 --> Utf8 Class Initialized
INFO - 2017-12-22 05:37:45 --> URI Class Initialized
INFO - 2017-12-22 05:37:45 --> Router Class Initialized
INFO - 2017-12-22 05:37:45 --> Output Class Initialized
INFO - 2017-12-22 05:37:45 --> Security Class Initialized
DEBUG - 2017-12-22 05:37:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 05:37:45 --> Input Class Initialized
INFO - 2017-12-22 05:37:45 --> Language Class Initialized
INFO - 2017-12-22 05:37:45 --> Loader Class Initialized
INFO - 2017-12-22 05:37:45 --> Helper loaded: url_helper
INFO - 2017-12-22 05:37:45 --> Helper loaded: form_helper
INFO - 2017-12-22 05:37:45 --> Database Driver Class Initialized
DEBUG - 2017-12-22 05:37:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 05:37:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 05:37:45 --> Form Validation Class Initialized
INFO - 2017-12-22 05:37:45 --> Model Class Initialized
INFO - 2017-12-22 05:37:45 --> Controller Class Initialized
INFO - 2017-12-22 05:37:45 --> Model Class Initialized
INFO - 2017-12-22 05:37:45 --> Model Class Initialized
INFO - 2017-12-22 05:37:45 --> Model Class Initialized
DEBUG - 2017-12-22 05:37:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 05:37:45 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 05:37:45 --> Final output sent to browser
DEBUG - 2017-12-22 05:37:45 --> Total execution time: 0.0866
INFO - 2017-12-22 05:37:46 --> Config Class Initialized
INFO - 2017-12-22 05:37:46 --> Hooks Class Initialized
DEBUG - 2017-12-22 05:37:46 --> UTF-8 Support Enabled
INFO - 2017-12-22 05:37:46 --> Utf8 Class Initialized
INFO - 2017-12-22 05:37:46 --> URI Class Initialized
INFO - 2017-12-22 05:37:46 --> Router Class Initialized
INFO - 2017-12-22 05:37:46 --> Output Class Initialized
INFO - 2017-12-22 05:37:46 --> Security Class Initialized
DEBUG - 2017-12-22 05:37:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 05:37:46 --> Input Class Initialized
INFO - 2017-12-22 05:37:46 --> Language Class Initialized
INFO - 2017-12-22 05:37:46 --> Loader Class Initialized
INFO - 2017-12-22 05:37:46 --> Helper loaded: url_helper
INFO - 2017-12-22 05:37:46 --> Helper loaded: form_helper
INFO - 2017-12-22 05:37:46 --> Database Driver Class Initialized
DEBUG - 2017-12-22 05:37:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 05:37:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 05:37:46 --> Form Validation Class Initialized
INFO - 2017-12-22 05:37:46 --> Model Class Initialized
INFO - 2017-12-22 05:37:46 --> Controller Class Initialized
INFO - 2017-12-22 05:37:46 --> Model Class Initialized
INFO - 2017-12-22 05:37:46 --> Model Class Initialized
INFO - 2017-12-22 05:37:46 --> Model Class Initialized
DEBUG - 2017-12-22 05:37:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 05:37:47 --> Config Class Initialized
INFO - 2017-12-22 05:37:47 --> Hooks Class Initialized
DEBUG - 2017-12-22 05:37:47 --> UTF-8 Support Enabled
INFO - 2017-12-22 05:37:47 --> Utf8 Class Initialized
INFO - 2017-12-22 05:37:47 --> URI Class Initialized
INFO - 2017-12-22 05:37:47 --> Router Class Initialized
INFO - 2017-12-22 05:37:47 --> Output Class Initialized
INFO - 2017-12-22 05:37:47 --> Security Class Initialized
DEBUG - 2017-12-22 05:37:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 05:37:47 --> Input Class Initialized
INFO - 2017-12-22 05:37:47 --> Language Class Initialized
ERROR - 2017-12-22 05:37:47 --> 404 Page Not Found: Faviconico/index
INFO - 2017-12-22 05:38:09 --> Config Class Initialized
INFO - 2017-12-22 05:38:09 --> Hooks Class Initialized
INFO - 2017-12-22 05:38:09 --> Config Class Initialized
INFO - 2017-12-22 05:38:09 --> Hooks Class Initialized
DEBUG - 2017-12-22 05:38:09 --> UTF-8 Support Enabled
INFO - 2017-12-22 05:38:09 --> Utf8 Class Initialized
DEBUG - 2017-12-22 05:38:09 --> UTF-8 Support Enabled
INFO - 2017-12-22 05:38:09 --> Utf8 Class Initialized
INFO - 2017-12-22 05:38:09 --> URI Class Initialized
INFO - 2017-12-22 05:38:09 --> URI Class Initialized
INFO - 2017-12-22 05:38:09 --> Router Class Initialized
INFO - 2017-12-22 05:38:09 --> Router Class Initialized
INFO - 2017-12-22 05:38:09 --> Output Class Initialized
INFO - 2017-12-22 05:38:09 --> Output Class Initialized
INFO - 2017-12-22 05:38:09 --> Security Class Initialized
INFO - 2017-12-22 05:38:09 --> Security Class Initialized
DEBUG - 2017-12-22 05:38:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-22 05:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 05:38:09 --> Input Class Initialized
INFO - 2017-12-22 05:38:09 --> Input Class Initialized
INFO - 2017-12-22 05:38:09 --> Language Class Initialized
INFO - 2017-12-22 05:38:09 --> Language Class Initialized
ERROR - 2017-12-22 05:38:09 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-22 05:38:09 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-22 05:38:42 --> Config Class Initialized
INFO - 2017-12-22 05:38:42 --> Hooks Class Initialized
DEBUG - 2017-12-22 05:38:42 --> UTF-8 Support Enabled
INFO - 2017-12-22 05:38:42 --> Utf8 Class Initialized
INFO - 2017-12-22 05:38:42 --> URI Class Initialized
INFO - 2017-12-22 05:38:42 --> Router Class Initialized
INFO - 2017-12-22 05:38:42 --> Output Class Initialized
INFO - 2017-12-22 05:38:42 --> Security Class Initialized
DEBUG - 2017-12-22 05:38:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 05:38:42 --> Input Class Initialized
INFO - 2017-12-22 05:38:42 --> Language Class Initialized
INFO - 2017-12-22 05:38:42 --> Loader Class Initialized
INFO - 2017-12-22 05:38:42 --> Helper loaded: url_helper
INFO - 2017-12-22 05:38:42 --> Helper loaded: form_helper
INFO - 2017-12-22 05:38:42 --> Database Driver Class Initialized
DEBUG - 2017-12-22 05:38:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 05:38:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 05:38:42 --> Form Validation Class Initialized
INFO - 2017-12-22 05:38:42 --> Model Class Initialized
INFO - 2017-12-22 05:38:42 --> Controller Class Initialized
INFO - 2017-12-22 05:38:42 --> Model Class Initialized
INFO - 2017-12-22 05:38:42 --> Model Class Initialized
INFO - 2017-12-22 05:38:42 --> Model Class Initialized
DEBUG - 2017-12-22 05:38:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 05:38:42 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 05:38:42 --> Final output sent to browser
DEBUG - 2017-12-22 05:38:42 --> Total execution time: 0.0697
INFO - 2017-12-22 05:38:42 --> Config Class Initialized
INFO - 2017-12-22 05:38:42 --> Hooks Class Initialized
DEBUG - 2017-12-22 05:38:42 --> UTF-8 Support Enabled
INFO - 2017-12-22 05:38:42 --> Utf8 Class Initialized
INFO - 2017-12-22 05:38:42 --> URI Class Initialized
INFO - 2017-12-22 05:38:42 --> Router Class Initialized
INFO - 2017-12-22 05:38:42 --> Output Class Initialized
INFO - 2017-12-22 05:38:42 --> Security Class Initialized
DEBUG - 2017-12-22 05:38:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 05:38:42 --> Input Class Initialized
INFO - 2017-12-22 05:38:42 --> Language Class Initialized
ERROR - 2017-12-22 05:38:42 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-22 05:38:42 --> Config Class Initialized
INFO - 2017-12-22 05:38:42 --> Hooks Class Initialized
INFO - 2017-12-22 05:38:42 --> Config Class Initialized
INFO - 2017-12-22 05:38:42 --> Hooks Class Initialized
DEBUG - 2017-12-22 05:38:42 --> UTF-8 Support Enabled
INFO - 2017-12-22 05:38:42 --> Utf8 Class Initialized
DEBUG - 2017-12-22 05:38:42 --> UTF-8 Support Enabled
INFO - 2017-12-22 05:38:42 --> URI Class Initialized
INFO - 2017-12-22 05:38:42 --> Utf8 Class Initialized
INFO - 2017-12-22 05:38:42 --> URI Class Initialized
INFO - 2017-12-22 05:38:42 --> Router Class Initialized
INFO - 2017-12-22 05:38:42 --> Router Class Initialized
INFO - 2017-12-22 05:38:42 --> Output Class Initialized
INFO - 2017-12-22 05:38:42 --> Output Class Initialized
INFO - 2017-12-22 05:38:42 --> Security Class Initialized
INFO - 2017-12-22 05:38:42 --> Security Class Initialized
DEBUG - 2017-12-22 05:38:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 05:38:42 --> Input Class Initialized
DEBUG - 2017-12-22 05:38:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 05:38:42 --> Input Class Initialized
INFO - 2017-12-22 05:38:42 --> Language Class Initialized
INFO - 2017-12-22 05:38:42 --> Language Class Initialized
ERROR - 2017-12-22 05:38:42 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-22 05:38:42 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-22 05:38:42 --> Config Class Initialized
INFO - 2017-12-22 05:38:42 --> Hooks Class Initialized
DEBUG - 2017-12-22 05:38:42 --> UTF-8 Support Enabled
INFO - 2017-12-22 05:38:42 --> Utf8 Class Initialized
INFO - 2017-12-22 05:38:42 --> URI Class Initialized
INFO - 2017-12-22 05:38:42 --> Router Class Initialized
INFO - 2017-12-22 05:38:42 --> Output Class Initialized
INFO - 2017-12-22 05:38:42 --> Security Class Initialized
DEBUG - 2017-12-22 05:38:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 05:38:42 --> Input Class Initialized
INFO - 2017-12-22 05:38:42 --> Language Class Initialized
INFO - 2017-12-22 05:38:43 --> Loader Class Initialized
INFO - 2017-12-22 05:38:43 --> Helper loaded: url_helper
INFO - 2017-12-22 05:38:43 --> Helper loaded: form_helper
INFO - 2017-12-22 05:38:43 --> Database Driver Class Initialized
DEBUG - 2017-12-22 05:38:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 05:38:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 05:38:43 --> Form Validation Class Initialized
INFO - 2017-12-22 05:38:43 --> Model Class Initialized
INFO - 2017-12-22 05:38:43 --> Controller Class Initialized
INFO - 2017-12-22 05:38:43 --> Model Class Initialized
INFO - 2017-12-22 05:38:43 --> Model Class Initialized
INFO - 2017-12-22 05:38:43 --> Model Class Initialized
DEBUG - 2017-12-22 05:38:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 05:41:19 --> Config Class Initialized
INFO - 2017-12-22 05:41:19 --> Hooks Class Initialized
DEBUG - 2017-12-22 05:41:19 --> UTF-8 Support Enabled
INFO - 2017-12-22 05:41:19 --> Utf8 Class Initialized
INFO - 2017-12-22 05:41:19 --> URI Class Initialized
INFO - 2017-12-22 05:41:19 --> Router Class Initialized
INFO - 2017-12-22 05:41:19 --> Output Class Initialized
INFO - 2017-12-22 05:41:19 --> Security Class Initialized
DEBUG - 2017-12-22 05:41:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 05:41:19 --> Input Class Initialized
INFO - 2017-12-22 05:41:19 --> Language Class Initialized
INFO - 2017-12-22 05:41:19 --> Loader Class Initialized
INFO - 2017-12-22 05:41:19 --> Helper loaded: url_helper
INFO - 2017-12-22 05:41:19 --> Helper loaded: form_helper
INFO - 2017-12-22 05:41:19 --> Database Driver Class Initialized
DEBUG - 2017-12-22 05:41:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 05:41:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 05:41:19 --> Form Validation Class Initialized
INFO - 2017-12-22 05:41:19 --> Model Class Initialized
INFO - 2017-12-22 05:41:19 --> Controller Class Initialized
INFO - 2017-12-22 05:41:19 --> Model Class Initialized
INFO - 2017-12-22 05:41:19 --> Model Class Initialized
INFO - 2017-12-22 05:41:19 --> Model Class Initialized
DEBUG - 2017-12-22 05:41:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 05:41:19 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 05:41:19 --> Final output sent to browser
DEBUG - 2017-12-22 05:41:19 --> Total execution time: 0.0568
INFO - 2017-12-22 05:41:19 --> Config Class Initialized
INFO - 2017-12-22 05:41:19 --> Hooks Class Initialized
DEBUG - 2017-12-22 05:41:19 --> UTF-8 Support Enabled
INFO - 2017-12-22 05:41:19 --> Utf8 Class Initialized
INFO - 2017-12-22 05:41:19 --> URI Class Initialized
INFO - 2017-12-22 05:41:19 --> Router Class Initialized
INFO - 2017-12-22 05:41:19 --> Output Class Initialized
INFO - 2017-12-22 05:41:19 --> Security Class Initialized
DEBUG - 2017-12-22 05:41:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 05:41:19 --> Input Class Initialized
INFO - 2017-12-22 05:41:19 --> Language Class Initialized
INFO - 2017-12-22 05:41:19 --> Loader Class Initialized
INFO - 2017-12-22 05:41:19 --> Helper loaded: url_helper
INFO - 2017-12-22 05:41:19 --> Helper loaded: form_helper
INFO - 2017-12-22 05:41:19 --> Database Driver Class Initialized
DEBUG - 2017-12-22 05:41:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 05:41:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 05:41:19 --> Form Validation Class Initialized
INFO - 2017-12-22 05:41:19 --> Model Class Initialized
INFO - 2017-12-22 05:41:19 --> Controller Class Initialized
INFO - 2017-12-22 05:41:19 --> Model Class Initialized
INFO - 2017-12-22 05:41:19 --> Model Class Initialized
INFO - 2017-12-22 05:41:19 --> Model Class Initialized
DEBUG - 2017-12-22 05:41:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 05:41:21 --> Config Class Initialized
INFO - 2017-12-22 05:41:21 --> Hooks Class Initialized
DEBUG - 2017-12-22 05:41:21 --> UTF-8 Support Enabled
INFO - 2017-12-22 05:41:21 --> Utf8 Class Initialized
INFO - 2017-12-22 05:41:21 --> URI Class Initialized
INFO - 2017-12-22 05:41:21 --> Router Class Initialized
INFO - 2017-12-22 05:41:21 --> Output Class Initialized
INFO - 2017-12-22 05:41:21 --> Security Class Initialized
DEBUG - 2017-12-22 05:41:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 05:41:21 --> Input Class Initialized
INFO - 2017-12-22 05:41:21 --> Language Class Initialized
ERROR - 2017-12-22 05:41:21 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-22 05:41:21 --> Config Class Initialized
INFO - 2017-12-22 05:41:21 --> Config Class Initialized
INFO - 2017-12-22 05:41:21 --> Hooks Class Initialized
INFO - 2017-12-22 05:41:21 --> Hooks Class Initialized
DEBUG - 2017-12-22 05:41:21 --> UTF-8 Support Enabled
DEBUG - 2017-12-22 05:41:21 --> UTF-8 Support Enabled
INFO - 2017-12-22 05:41:21 --> Utf8 Class Initialized
INFO - 2017-12-22 05:41:21 --> Utf8 Class Initialized
INFO - 2017-12-22 05:41:21 --> URI Class Initialized
INFO - 2017-12-22 05:41:21 --> URI Class Initialized
INFO - 2017-12-22 05:41:21 --> Router Class Initialized
INFO - 2017-12-22 05:41:21 --> Router Class Initialized
INFO - 2017-12-22 05:41:21 --> Output Class Initialized
INFO - 2017-12-22 05:41:21 --> Output Class Initialized
INFO - 2017-12-22 05:41:21 --> Security Class Initialized
INFO - 2017-12-22 05:41:21 --> Security Class Initialized
DEBUG - 2017-12-22 05:41:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 05:41:21 --> Input Class Initialized
DEBUG - 2017-12-22 05:41:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 05:41:21 --> Language Class Initialized
INFO - 2017-12-22 05:41:21 --> Input Class Initialized
INFO - 2017-12-22 05:41:21 --> Language Class Initialized
ERROR - 2017-12-22 05:41:21 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-22 05:41:21 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-22 05:41:22 --> Config Class Initialized
INFO - 2017-12-22 05:41:22 --> Hooks Class Initialized
DEBUG - 2017-12-22 05:41:22 --> UTF-8 Support Enabled
INFO - 2017-12-22 05:41:22 --> Utf8 Class Initialized
INFO - 2017-12-22 05:41:22 --> URI Class Initialized
INFO - 2017-12-22 05:41:22 --> Router Class Initialized
INFO - 2017-12-22 05:41:22 --> Output Class Initialized
INFO - 2017-12-22 05:41:22 --> Security Class Initialized
DEBUG - 2017-12-22 05:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 05:41:22 --> Input Class Initialized
INFO - 2017-12-22 05:41:22 --> Language Class Initialized
INFO - 2017-12-22 05:41:22 --> Loader Class Initialized
INFO - 2017-12-22 05:41:22 --> Helper loaded: url_helper
INFO - 2017-12-22 05:41:22 --> Helper loaded: form_helper
INFO - 2017-12-22 05:41:22 --> Database Driver Class Initialized
DEBUG - 2017-12-22 05:41:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 05:41:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 05:41:22 --> Form Validation Class Initialized
INFO - 2017-12-22 05:41:22 --> Model Class Initialized
INFO - 2017-12-22 05:41:22 --> Controller Class Initialized
INFO - 2017-12-22 05:41:22 --> Model Class Initialized
INFO - 2017-12-22 05:41:22 --> Model Class Initialized
INFO - 2017-12-22 05:41:22 --> Model Class Initialized
DEBUG - 2017-12-22 05:41:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 05:41:22 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 05:41:22 --> Final output sent to browser
DEBUG - 2017-12-22 05:41:22 --> Total execution time: 0.0547
INFO - 2017-12-22 05:41:23 --> Config Class Initialized
INFO - 2017-12-22 05:41:23 --> Hooks Class Initialized
DEBUG - 2017-12-22 05:41:23 --> UTF-8 Support Enabled
INFO - 2017-12-22 05:41:23 --> Utf8 Class Initialized
INFO - 2017-12-22 05:41:23 --> URI Class Initialized
INFO - 2017-12-22 05:41:23 --> Router Class Initialized
INFO - 2017-12-22 05:41:23 --> Output Class Initialized
INFO - 2017-12-22 05:41:23 --> Security Class Initialized
DEBUG - 2017-12-22 05:41:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 05:41:23 --> Input Class Initialized
INFO - 2017-12-22 05:41:23 --> Language Class Initialized
INFO - 2017-12-22 05:41:23 --> Config Class Initialized
INFO - 2017-12-22 05:41:23 --> Hooks Class Initialized
ERROR - 2017-12-22 05:41:23 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-22 05:41:23 --> Config Class Initialized
INFO - 2017-12-22 05:41:23 --> Hooks Class Initialized
DEBUG - 2017-12-22 05:41:23 --> UTF-8 Support Enabled
INFO - 2017-12-22 05:41:23 --> Utf8 Class Initialized
DEBUG - 2017-12-22 05:41:23 --> UTF-8 Support Enabled
INFO - 2017-12-22 05:41:23 --> Utf8 Class Initialized
INFO - 2017-12-22 05:41:23 --> URI Class Initialized
INFO - 2017-12-22 05:41:23 --> URI Class Initialized
INFO - 2017-12-22 05:41:23 --> Router Class Initialized
INFO - 2017-12-22 05:41:23 --> Router Class Initialized
INFO - 2017-12-22 05:41:23 --> Output Class Initialized
INFO - 2017-12-22 05:41:23 --> Output Class Initialized
INFO - 2017-12-22 05:41:23 --> Security Class Initialized
INFO - 2017-12-22 05:41:23 --> Security Class Initialized
DEBUG - 2017-12-22 05:41:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-22 05:41:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 05:41:23 --> Input Class Initialized
INFO - 2017-12-22 05:41:23 --> Input Class Initialized
INFO - 2017-12-22 05:41:23 --> Language Class Initialized
INFO - 2017-12-22 05:41:23 --> Language Class Initialized
ERROR - 2017-12-22 05:41:23 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-22 05:41:23 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-22 05:41:23 --> Config Class Initialized
INFO - 2017-12-22 05:41:23 --> Hooks Class Initialized
DEBUG - 2017-12-22 05:41:23 --> UTF-8 Support Enabled
INFO - 2017-12-22 05:41:23 --> Utf8 Class Initialized
INFO - 2017-12-22 05:41:23 --> URI Class Initialized
INFO - 2017-12-22 05:41:23 --> Router Class Initialized
INFO - 2017-12-22 05:41:23 --> Output Class Initialized
INFO - 2017-12-22 05:41:23 --> Security Class Initialized
DEBUG - 2017-12-22 05:41:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 05:41:23 --> Input Class Initialized
INFO - 2017-12-22 05:41:23 --> Language Class Initialized
INFO - 2017-12-22 05:41:23 --> Loader Class Initialized
INFO - 2017-12-22 05:41:23 --> Helper loaded: url_helper
INFO - 2017-12-22 05:41:23 --> Helper loaded: form_helper
INFO - 2017-12-22 05:41:23 --> Database Driver Class Initialized
DEBUG - 2017-12-22 05:41:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 05:41:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 05:41:23 --> Form Validation Class Initialized
INFO - 2017-12-22 05:41:23 --> Model Class Initialized
INFO - 2017-12-22 05:41:23 --> Controller Class Initialized
INFO - 2017-12-22 05:41:23 --> Model Class Initialized
INFO - 2017-12-22 05:41:23 --> Model Class Initialized
INFO - 2017-12-22 05:41:23 --> Model Class Initialized
DEBUG - 2017-12-22 05:41:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 05:44:33 --> Config Class Initialized
INFO - 2017-12-22 05:44:33 --> Hooks Class Initialized
DEBUG - 2017-12-22 05:44:33 --> UTF-8 Support Enabled
INFO - 2017-12-22 05:44:33 --> Utf8 Class Initialized
INFO - 2017-12-22 05:44:33 --> URI Class Initialized
INFO - 2017-12-22 05:44:33 --> Router Class Initialized
INFO - 2017-12-22 05:44:33 --> Output Class Initialized
INFO - 2017-12-22 05:44:33 --> Security Class Initialized
DEBUG - 2017-12-22 05:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 05:44:33 --> Input Class Initialized
INFO - 2017-12-22 05:44:33 --> Language Class Initialized
INFO - 2017-12-22 05:44:33 --> Loader Class Initialized
INFO - 2017-12-22 05:44:33 --> Helper loaded: url_helper
INFO - 2017-12-22 05:44:33 --> Helper loaded: form_helper
INFO - 2017-12-22 05:44:33 --> Database Driver Class Initialized
DEBUG - 2017-12-22 05:44:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 05:44:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 05:44:33 --> Form Validation Class Initialized
INFO - 2017-12-22 05:44:33 --> Model Class Initialized
INFO - 2017-12-22 05:44:33 --> Controller Class Initialized
INFO - 2017-12-22 05:44:33 --> Model Class Initialized
INFO - 2017-12-22 05:44:33 --> Model Class Initialized
INFO - 2017-12-22 05:44:33 --> Model Class Initialized
DEBUG - 2017-12-22 05:44:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 05:44:33 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 05:44:33 --> Final output sent to browser
DEBUG - 2017-12-22 05:44:33 --> Total execution time: 0.0818
INFO - 2017-12-22 05:44:35 --> Config Class Initialized
INFO - 2017-12-22 05:44:35 --> Hooks Class Initialized
DEBUG - 2017-12-22 05:44:35 --> UTF-8 Support Enabled
INFO - 2017-12-22 05:44:35 --> Utf8 Class Initialized
INFO - 2017-12-22 05:44:35 --> URI Class Initialized
INFO - 2017-12-22 05:44:35 --> Router Class Initialized
INFO - 2017-12-22 05:44:35 --> Output Class Initialized
INFO - 2017-12-22 05:44:35 --> Security Class Initialized
DEBUG - 2017-12-22 05:44:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 05:44:35 --> Input Class Initialized
INFO - 2017-12-22 05:44:35 --> Language Class Initialized
ERROR - 2017-12-22 05:44:35 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-22 05:44:35 --> Config Class Initialized
INFO - 2017-12-22 05:44:35 --> Hooks Class Initialized
INFO - 2017-12-22 05:44:35 --> Config Class Initialized
DEBUG - 2017-12-22 05:44:35 --> UTF-8 Support Enabled
INFO - 2017-12-22 05:44:35 --> Hooks Class Initialized
INFO - 2017-12-22 05:44:35 --> Utf8 Class Initialized
INFO - 2017-12-22 05:44:35 --> URI Class Initialized
DEBUG - 2017-12-22 05:44:35 --> UTF-8 Support Enabled
INFO - 2017-12-22 05:44:35 --> Utf8 Class Initialized
INFO - 2017-12-22 05:44:35 --> Router Class Initialized
INFO - 2017-12-22 05:44:35 --> URI Class Initialized
INFO - 2017-12-22 05:44:35 --> Output Class Initialized
INFO - 2017-12-22 05:44:35 --> Security Class Initialized
INFO - 2017-12-22 05:44:35 --> Router Class Initialized
DEBUG - 2017-12-22 05:44:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 05:44:35 --> Input Class Initialized
INFO - 2017-12-22 05:44:35 --> Language Class Initialized
INFO - 2017-12-22 05:44:35 --> Output Class Initialized
ERROR - 2017-12-22 05:44:35 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-22 05:44:35 --> Security Class Initialized
DEBUG - 2017-12-22 05:44:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 05:44:35 --> Input Class Initialized
INFO - 2017-12-22 05:44:35 --> Language Class Initialized
ERROR - 2017-12-22 05:44:35 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-22 05:44:35 --> Config Class Initialized
INFO - 2017-12-22 05:44:35 --> Hooks Class Initialized
DEBUG - 2017-12-22 05:44:35 --> UTF-8 Support Enabled
INFO - 2017-12-22 05:44:35 --> Utf8 Class Initialized
INFO - 2017-12-22 05:44:35 --> URI Class Initialized
INFO - 2017-12-22 05:44:35 --> Router Class Initialized
INFO - 2017-12-22 05:44:35 --> Output Class Initialized
INFO - 2017-12-22 05:44:35 --> Security Class Initialized
DEBUG - 2017-12-22 05:44:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 05:44:35 --> Input Class Initialized
INFO - 2017-12-22 05:44:35 --> Language Class Initialized
INFO - 2017-12-22 05:44:35 --> Loader Class Initialized
INFO - 2017-12-22 05:44:35 --> Helper loaded: url_helper
INFO - 2017-12-22 05:44:35 --> Helper loaded: form_helper
INFO - 2017-12-22 05:44:35 --> Database Driver Class Initialized
DEBUG - 2017-12-22 05:44:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 05:44:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 05:44:35 --> Form Validation Class Initialized
INFO - 2017-12-22 05:44:35 --> Model Class Initialized
INFO - 2017-12-22 05:44:35 --> Controller Class Initialized
INFO - 2017-12-22 05:44:35 --> Model Class Initialized
INFO - 2017-12-22 05:44:35 --> Model Class Initialized
INFO - 2017-12-22 05:44:35 --> Model Class Initialized
DEBUG - 2017-12-22 05:44:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 05:45:32 --> Config Class Initialized
INFO - 2017-12-22 05:45:32 --> Hooks Class Initialized
DEBUG - 2017-12-22 05:45:32 --> UTF-8 Support Enabled
INFO - 2017-12-22 05:45:32 --> Utf8 Class Initialized
INFO - 2017-12-22 05:45:32 --> URI Class Initialized
INFO - 2017-12-22 05:45:32 --> Router Class Initialized
INFO - 2017-12-22 05:45:32 --> Output Class Initialized
INFO - 2017-12-22 05:45:32 --> Security Class Initialized
DEBUG - 2017-12-22 05:45:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 05:45:32 --> Input Class Initialized
INFO - 2017-12-22 05:45:32 --> Language Class Initialized
INFO - 2017-12-22 05:45:32 --> Loader Class Initialized
INFO - 2017-12-22 05:45:32 --> Helper loaded: url_helper
INFO - 2017-12-22 05:45:32 --> Helper loaded: form_helper
INFO - 2017-12-22 05:45:32 --> Database Driver Class Initialized
DEBUG - 2017-12-22 05:45:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 05:45:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 05:45:32 --> Form Validation Class Initialized
INFO - 2017-12-22 05:45:32 --> Model Class Initialized
INFO - 2017-12-22 05:45:32 --> Controller Class Initialized
INFO - 2017-12-22 05:45:32 --> Model Class Initialized
INFO - 2017-12-22 05:45:32 --> Model Class Initialized
INFO - 2017-12-22 05:45:32 --> Model Class Initialized
DEBUG - 2017-12-22 05:45:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 05:45:33 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 05:45:33 --> Final output sent to browser
DEBUG - 2017-12-22 05:45:33 --> Total execution time: 0.0912
INFO - 2017-12-22 05:45:33 --> Config Class Initialized
INFO - 2017-12-22 05:45:33 --> Hooks Class Initialized
INFO - 2017-12-22 05:45:33 --> Config Class Initialized
INFO - 2017-12-22 05:45:33 --> Hooks Class Initialized
DEBUG - 2017-12-22 05:45:33 --> UTF-8 Support Enabled
INFO - 2017-12-22 05:45:33 --> Utf8 Class Initialized
DEBUG - 2017-12-22 05:45:33 --> UTF-8 Support Enabled
INFO - 2017-12-22 05:45:33 --> Utf8 Class Initialized
INFO - 2017-12-22 05:45:33 --> URI Class Initialized
INFO - 2017-12-22 05:45:33 --> URI Class Initialized
INFO - 2017-12-22 05:45:33 --> Router Class Initialized
INFO - 2017-12-22 05:45:33 --> Router Class Initialized
INFO - 2017-12-22 05:45:33 --> Output Class Initialized
INFO - 2017-12-22 05:45:33 --> Output Class Initialized
INFO - 2017-12-22 05:45:33 --> Security Class Initialized
INFO - 2017-12-22 05:45:33 --> Security Class Initialized
DEBUG - 2017-12-22 05:45:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 05:45:33 --> Input Class Initialized
DEBUG - 2017-12-22 05:45:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 05:45:33 --> Language Class Initialized
INFO - 2017-12-22 05:45:33 --> Input Class Initialized
INFO - 2017-12-22 05:45:33 --> Language Class Initialized
ERROR - 2017-12-22 05:45:33 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-22 05:45:33 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-22 05:45:33 --> Config Class Initialized
INFO - 2017-12-22 05:45:33 --> Hooks Class Initialized
DEBUG - 2017-12-22 05:45:33 --> UTF-8 Support Enabled
INFO - 2017-12-22 05:45:33 --> Utf8 Class Initialized
INFO - 2017-12-22 05:45:33 --> URI Class Initialized
INFO - 2017-12-22 05:45:33 --> Router Class Initialized
INFO - 2017-12-22 05:45:33 --> Output Class Initialized
INFO - 2017-12-22 05:45:33 --> Security Class Initialized
DEBUG - 2017-12-22 05:45:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 05:45:33 --> Input Class Initialized
INFO - 2017-12-22 05:45:33 --> Language Class Initialized
ERROR - 2017-12-22 05:45:33 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-22 05:45:33 --> Config Class Initialized
INFO - 2017-12-22 05:45:33 --> Hooks Class Initialized
DEBUG - 2017-12-22 05:45:33 --> UTF-8 Support Enabled
INFO - 2017-12-22 05:45:33 --> Utf8 Class Initialized
INFO - 2017-12-22 05:45:33 --> URI Class Initialized
INFO - 2017-12-22 05:45:33 --> Router Class Initialized
INFO - 2017-12-22 05:45:33 --> Output Class Initialized
INFO - 2017-12-22 05:45:33 --> Security Class Initialized
DEBUG - 2017-12-22 05:45:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 05:45:33 --> Input Class Initialized
INFO - 2017-12-22 05:45:33 --> Language Class Initialized
INFO - 2017-12-22 05:45:33 --> Loader Class Initialized
INFO - 2017-12-22 05:45:33 --> Helper loaded: url_helper
INFO - 2017-12-22 05:45:33 --> Helper loaded: form_helper
INFO - 2017-12-22 05:45:33 --> Database Driver Class Initialized
DEBUG - 2017-12-22 05:45:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 05:45:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 05:45:33 --> Form Validation Class Initialized
INFO - 2017-12-22 05:45:33 --> Model Class Initialized
INFO - 2017-12-22 05:45:33 --> Controller Class Initialized
INFO - 2017-12-22 05:45:33 --> Model Class Initialized
INFO - 2017-12-22 05:45:33 --> Model Class Initialized
INFO - 2017-12-22 05:45:33 --> Model Class Initialized
DEBUG - 2017-12-22 05:45:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 05:46:00 --> Config Class Initialized
INFO - 2017-12-22 05:46:00 --> Hooks Class Initialized
DEBUG - 2017-12-22 05:46:00 --> UTF-8 Support Enabled
INFO - 2017-12-22 05:46:00 --> Utf8 Class Initialized
INFO - 2017-12-22 05:46:00 --> URI Class Initialized
INFO - 2017-12-22 05:46:00 --> Router Class Initialized
INFO - 2017-12-22 05:46:00 --> Output Class Initialized
INFO - 2017-12-22 05:46:00 --> Security Class Initialized
DEBUG - 2017-12-22 05:46:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 05:46:00 --> Input Class Initialized
INFO - 2017-12-22 05:46:00 --> Language Class Initialized
INFO - 2017-12-22 05:46:00 --> Loader Class Initialized
INFO - 2017-12-22 05:46:00 --> Helper loaded: url_helper
INFO - 2017-12-22 05:46:00 --> Helper loaded: form_helper
INFO - 2017-12-22 05:46:00 --> Database Driver Class Initialized
DEBUG - 2017-12-22 05:46:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 05:46:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 05:46:00 --> Form Validation Class Initialized
INFO - 2017-12-22 05:46:00 --> Model Class Initialized
INFO - 2017-12-22 05:46:00 --> Controller Class Initialized
INFO - 2017-12-22 05:46:00 --> Model Class Initialized
INFO - 2017-12-22 05:46:00 --> Model Class Initialized
INFO - 2017-12-22 05:46:00 --> Model Class Initialized
DEBUG - 2017-12-22 05:46:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 05:46:00 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 05:46:00 --> Final output sent to browser
DEBUG - 2017-12-22 05:46:00 --> Total execution time: 0.0746
INFO - 2017-12-22 05:46:00 --> Config Class Initialized
INFO - 2017-12-22 05:46:00 --> Hooks Class Initialized
INFO - 2017-12-22 05:46:00 --> Config Class Initialized
INFO - 2017-12-22 05:46:00 --> Hooks Class Initialized
DEBUG - 2017-12-22 05:46:00 --> UTF-8 Support Enabled
INFO - 2017-12-22 05:46:00 --> Utf8 Class Initialized
DEBUG - 2017-12-22 05:46:00 --> UTF-8 Support Enabled
INFO - 2017-12-22 05:46:00 --> Utf8 Class Initialized
INFO - 2017-12-22 05:46:00 --> URI Class Initialized
INFO - 2017-12-22 05:46:00 --> URI Class Initialized
INFO - 2017-12-22 05:46:00 --> Router Class Initialized
INFO - 2017-12-22 05:46:00 --> Router Class Initialized
INFO - 2017-12-22 05:46:00 --> Output Class Initialized
INFO - 2017-12-22 05:46:00 --> Output Class Initialized
INFO - 2017-12-22 05:46:00 --> Security Class Initialized
INFO - 2017-12-22 05:46:00 --> Security Class Initialized
DEBUG - 2017-12-22 05:46:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-22 05:46:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 05:46:00 --> Input Class Initialized
INFO - 2017-12-22 05:46:00 --> Input Class Initialized
INFO - 2017-12-22 05:46:00 --> Language Class Initialized
INFO - 2017-12-22 05:46:00 --> Language Class Initialized
ERROR - 2017-12-22 05:46:00 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-22 05:46:00 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-22 05:46:00 --> Config Class Initialized
INFO - 2017-12-22 05:46:00 --> Hooks Class Initialized
DEBUG - 2017-12-22 05:46:00 --> UTF-8 Support Enabled
INFO - 2017-12-22 05:46:00 --> Utf8 Class Initialized
INFO - 2017-12-22 05:46:00 --> URI Class Initialized
INFO - 2017-12-22 05:46:00 --> Router Class Initialized
INFO - 2017-12-22 05:46:00 --> Output Class Initialized
INFO - 2017-12-22 05:46:00 --> Security Class Initialized
DEBUG - 2017-12-22 05:46:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 05:46:00 --> Input Class Initialized
INFO - 2017-12-22 05:46:00 --> Language Class Initialized
ERROR - 2017-12-22 05:46:00 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-22 05:46:00 --> Config Class Initialized
INFO - 2017-12-22 05:46:00 --> Hooks Class Initialized
DEBUG - 2017-12-22 05:46:00 --> UTF-8 Support Enabled
INFO - 2017-12-22 05:46:00 --> Utf8 Class Initialized
INFO - 2017-12-22 05:46:00 --> URI Class Initialized
INFO - 2017-12-22 05:46:00 --> Router Class Initialized
INFO - 2017-12-22 05:46:00 --> Output Class Initialized
INFO - 2017-12-22 05:46:00 --> Security Class Initialized
DEBUG - 2017-12-22 05:46:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 05:46:00 --> Input Class Initialized
INFO - 2017-12-22 05:46:00 --> Language Class Initialized
INFO - 2017-12-22 05:46:00 --> Loader Class Initialized
INFO - 2017-12-22 05:46:00 --> Helper loaded: url_helper
INFO - 2017-12-22 05:46:00 --> Helper loaded: form_helper
INFO - 2017-12-22 05:46:00 --> Database Driver Class Initialized
DEBUG - 2017-12-22 05:46:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 05:46:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 05:46:00 --> Form Validation Class Initialized
INFO - 2017-12-22 05:46:00 --> Model Class Initialized
INFO - 2017-12-22 05:46:00 --> Controller Class Initialized
INFO - 2017-12-22 05:46:00 --> Model Class Initialized
INFO - 2017-12-22 05:46:00 --> Model Class Initialized
INFO - 2017-12-22 05:46:00 --> Model Class Initialized
DEBUG - 2017-12-22 05:46:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 05:51:41 --> Config Class Initialized
INFO - 2017-12-22 05:51:41 --> Hooks Class Initialized
DEBUG - 2017-12-22 05:51:41 --> UTF-8 Support Enabled
INFO - 2017-12-22 05:51:41 --> Utf8 Class Initialized
INFO - 2017-12-22 05:51:41 --> URI Class Initialized
INFO - 2017-12-22 05:51:41 --> Router Class Initialized
INFO - 2017-12-22 05:51:41 --> Output Class Initialized
INFO - 2017-12-22 05:51:41 --> Security Class Initialized
DEBUG - 2017-12-22 05:51:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 05:51:41 --> Input Class Initialized
INFO - 2017-12-22 05:51:41 --> Language Class Initialized
INFO - 2017-12-22 05:51:41 --> Loader Class Initialized
INFO - 2017-12-22 05:51:41 --> Helper loaded: url_helper
INFO - 2017-12-22 05:51:41 --> Helper loaded: form_helper
INFO - 2017-12-22 05:51:41 --> Database Driver Class Initialized
DEBUG - 2017-12-22 05:51:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 05:51:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 05:51:41 --> Form Validation Class Initialized
INFO - 2017-12-22 05:51:41 --> Model Class Initialized
INFO - 2017-12-22 05:51:41 --> Controller Class Initialized
INFO - 2017-12-22 05:51:41 --> Model Class Initialized
INFO - 2017-12-22 05:51:41 --> Model Class Initialized
INFO - 2017-12-22 05:51:41 --> Model Class Initialized
DEBUG - 2017-12-22 05:51:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 05:51:41 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 05:51:41 --> Final output sent to browser
DEBUG - 2017-12-22 05:51:41 --> Total execution time: 0.0701
INFO - 2017-12-22 05:51:42 --> Config Class Initialized
INFO - 2017-12-22 05:51:42 --> Hooks Class Initialized
INFO - 2017-12-22 05:51:42 --> Config Class Initialized
INFO - 2017-12-22 05:51:42 --> Hooks Class Initialized
DEBUG - 2017-12-22 05:51:42 --> UTF-8 Support Enabled
INFO - 2017-12-22 05:51:42 --> Utf8 Class Initialized
DEBUG - 2017-12-22 05:51:42 --> UTF-8 Support Enabled
INFO - 2017-12-22 05:51:42 --> Utf8 Class Initialized
INFO - 2017-12-22 05:51:42 --> URI Class Initialized
INFO - 2017-12-22 05:51:42 --> URI Class Initialized
INFO - 2017-12-22 05:51:42 --> Router Class Initialized
INFO - 2017-12-22 05:51:42 --> Router Class Initialized
INFO - 2017-12-22 05:51:42 --> Output Class Initialized
INFO - 2017-12-22 05:51:42 --> Output Class Initialized
INFO - 2017-12-22 05:51:42 --> Security Class Initialized
INFO - 2017-12-22 05:51:42 --> Security Class Initialized
DEBUG - 2017-12-22 05:51:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 05:51:42 --> Input Class Initialized
DEBUG - 2017-12-22 05:51:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 05:51:42 --> Language Class Initialized
INFO - 2017-12-22 05:51:42 --> Input Class Initialized
INFO - 2017-12-22 05:51:42 --> Language Class Initialized
ERROR - 2017-12-22 05:51:42 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-22 05:51:42 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-22 05:51:42 --> Config Class Initialized
INFO - 2017-12-22 05:51:42 --> Hooks Class Initialized
DEBUG - 2017-12-22 05:51:42 --> UTF-8 Support Enabled
INFO - 2017-12-22 05:51:42 --> Utf8 Class Initialized
INFO - 2017-12-22 05:51:42 --> URI Class Initialized
INFO - 2017-12-22 05:51:42 --> Router Class Initialized
INFO - 2017-12-22 05:51:42 --> Output Class Initialized
INFO - 2017-12-22 05:51:42 --> Security Class Initialized
DEBUG - 2017-12-22 05:51:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 05:51:42 --> Input Class Initialized
INFO - 2017-12-22 05:51:42 --> Language Class Initialized
ERROR - 2017-12-22 05:51:42 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-22 05:52:22 --> Config Class Initialized
INFO - 2017-12-22 05:52:22 --> Hooks Class Initialized
DEBUG - 2017-12-22 05:52:22 --> UTF-8 Support Enabled
INFO - 2017-12-22 05:52:22 --> Utf8 Class Initialized
INFO - 2017-12-22 05:52:22 --> URI Class Initialized
INFO - 2017-12-22 05:52:22 --> Router Class Initialized
INFO - 2017-12-22 05:52:22 --> Output Class Initialized
INFO - 2017-12-22 05:52:22 --> Security Class Initialized
DEBUG - 2017-12-22 05:52:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 05:52:22 --> Input Class Initialized
INFO - 2017-12-22 05:52:22 --> Language Class Initialized
INFO - 2017-12-22 05:52:22 --> Loader Class Initialized
INFO - 2017-12-22 05:52:22 --> Helper loaded: url_helper
INFO - 2017-12-22 05:52:22 --> Helper loaded: form_helper
INFO - 2017-12-22 05:52:22 --> Database Driver Class Initialized
DEBUG - 2017-12-22 05:52:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 05:52:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 05:52:22 --> Form Validation Class Initialized
INFO - 2017-12-22 05:52:22 --> Model Class Initialized
INFO - 2017-12-22 05:52:22 --> Controller Class Initialized
INFO - 2017-12-22 05:52:22 --> Model Class Initialized
INFO - 2017-12-22 05:52:22 --> Model Class Initialized
INFO - 2017-12-22 05:52:22 --> Model Class Initialized
DEBUG - 2017-12-22 05:52:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 05:52:22 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 05:52:22 --> Final output sent to browser
DEBUG - 2017-12-22 05:52:22 --> Total execution time: 0.0867
INFO - 2017-12-22 05:52:23 --> Config Class Initialized
INFO - 2017-12-22 05:52:23 --> Hooks Class Initialized
DEBUG - 2017-12-22 05:52:23 --> UTF-8 Support Enabled
INFO - 2017-12-22 05:52:23 --> Utf8 Class Initialized
INFO - 2017-12-22 05:52:23 --> URI Class Initialized
INFO - 2017-12-22 05:52:23 --> Router Class Initialized
INFO - 2017-12-22 05:52:23 --> Output Class Initialized
INFO - 2017-12-22 05:52:23 --> Security Class Initialized
DEBUG - 2017-12-22 05:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 05:52:23 --> Input Class Initialized
INFO - 2017-12-22 05:52:23 --> Language Class Initialized
ERROR - 2017-12-22 05:52:23 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-22 05:52:23 --> Config Class Initialized
INFO - 2017-12-22 05:52:23 --> Config Class Initialized
INFO - 2017-12-22 05:52:23 --> Hooks Class Initialized
INFO - 2017-12-22 05:52:23 --> Hooks Class Initialized
DEBUG - 2017-12-22 05:52:23 --> UTF-8 Support Enabled
DEBUG - 2017-12-22 05:52:23 --> UTF-8 Support Enabled
INFO - 2017-12-22 05:52:23 --> Utf8 Class Initialized
INFO - 2017-12-22 05:52:23 --> Utf8 Class Initialized
INFO - 2017-12-22 05:52:23 --> URI Class Initialized
INFO - 2017-12-22 05:52:23 --> URI Class Initialized
INFO - 2017-12-22 05:52:23 --> Router Class Initialized
INFO - 2017-12-22 05:52:23 --> Router Class Initialized
INFO - 2017-12-22 05:52:23 --> Output Class Initialized
INFO - 2017-12-22 05:52:23 --> Output Class Initialized
INFO - 2017-12-22 05:52:23 --> Security Class Initialized
INFO - 2017-12-22 05:52:23 --> Security Class Initialized
DEBUG - 2017-12-22 05:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 05:52:23 --> Input Class Initialized
DEBUG - 2017-12-22 05:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 05:52:23 --> Input Class Initialized
INFO - 2017-12-22 05:52:23 --> Language Class Initialized
INFO - 2017-12-22 05:52:23 --> Language Class Initialized
ERROR - 2017-12-22 05:52:23 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-22 05:52:23 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-22 05:52:24 --> Config Class Initialized
INFO - 2017-12-22 05:52:24 --> Hooks Class Initialized
DEBUG - 2017-12-22 05:52:24 --> UTF-8 Support Enabled
INFO - 2017-12-22 05:52:24 --> Utf8 Class Initialized
INFO - 2017-12-22 05:52:24 --> URI Class Initialized
INFO - 2017-12-22 05:52:24 --> Router Class Initialized
INFO - 2017-12-22 05:52:24 --> Output Class Initialized
INFO - 2017-12-22 05:52:24 --> Security Class Initialized
DEBUG - 2017-12-22 05:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 05:52:24 --> Input Class Initialized
INFO - 2017-12-22 05:52:24 --> Language Class Initialized
INFO - 2017-12-22 05:52:24 --> Loader Class Initialized
INFO - 2017-12-22 05:52:24 --> Helper loaded: url_helper
INFO - 2017-12-22 05:52:24 --> Helper loaded: form_helper
INFO - 2017-12-22 05:52:24 --> Database Driver Class Initialized
DEBUG - 2017-12-22 05:52:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 05:52:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 05:52:24 --> Form Validation Class Initialized
INFO - 2017-12-22 05:52:24 --> Model Class Initialized
INFO - 2017-12-22 05:52:24 --> Controller Class Initialized
INFO - 2017-12-22 05:52:24 --> Model Class Initialized
INFO - 2017-12-22 05:52:24 --> Model Class Initialized
INFO - 2017-12-22 05:52:24 --> Model Class Initialized
DEBUG - 2017-12-22 05:52:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 05:52:24 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 05:52:24 --> Final output sent to browser
DEBUG - 2017-12-22 05:52:24 --> Total execution time: 0.0507
INFO - 2017-12-22 05:52:25 --> Config Class Initialized
INFO - 2017-12-22 05:52:25 --> Hooks Class Initialized
DEBUG - 2017-12-22 05:52:25 --> UTF-8 Support Enabled
INFO - 2017-12-22 05:52:25 --> Utf8 Class Initialized
INFO - 2017-12-22 05:52:25 --> URI Class Initialized
INFO - 2017-12-22 05:52:25 --> Router Class Initialized
INFO - 2017-12-22 05:52:25 --> Output Class Initialized
INFO - 2017-12-22 05:52:25 --> Security Class Initialized
DEBUG - 2017-12-22 05:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 05:52:25 --> Input Class Initialized
INFO - 2017-12-22 05:52:25 --> Language Class Initialized
ERROR - 2017-12-22 05:52:25 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-22 05:52:25 --> Config Class Initialized
INFO - 2017-12-22 05:52:25 --> Config Class Initialized
INFO - 2017-12-22 05:52:25 --> Hooks Class Initialized
INFO - 2017-12-22 05:52:25 --> Hooks Class Initialized
DEBUG - 2017-12-22 05:52:25 --> UTF-8 Support Enabled
INFO - 2017-12-22 05:52:25 --> Utf8 Class Initialized
DEBUG - 2017-12-22 05:52:25 --> UTF-8 Support Enabled
INFO - 2017-12-22 05:52:25 --> Utf8 Class Initialized
INFO - 2017-12-22 05:52:25 --> URI Class Initialized
INFO - 2017-12-22 05:52:25 --> URI Class Initialized
INFO - 2017-12-22 05:52:25 --> Router Class Initialized
INFO - 2017-12-22 05:52:25 --> Router Class Initialized
INFO - 2017-12-22 05:52:25 --> Output Class Initialized
INFO - 2017-12-22 05:52:25 --> Output Class Initialized
INFO - 2017-12-22 05:52:25 --> Security Class Initialized
INFO - 2017-12-22 05:52:25 --> Security Class Initialized
DEBUG - 2017-12-22 05:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 05:52:25 --> Input Class Initialized
DEBUG - 2017-12-22 05:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 05:52:25 --> Input Class Initialized
INFO - 2017-12-22 05:52:25 --> Language Class Initialized
INFO - 2017-12-22 05:52:25 --> Language Class Initialized
ERROR - 2017-12-22 05:52:25 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-22 05:52:25 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-22 05:52:50 --> Config Class Initialized
INFO - 2017-12-22 05:52:50 --> Hooks Class Initialized
DEBUG - 2017-12-22 05:52:50 --> UTF-8 Support Enabled
INFO - 2017-12-22 05:52:50 --> Utf8 Class Initialized
INFO - 2017-12-22 05:52:50 --> URI Class Initialized
INFO - 2017-12-22 05:52:50 --> Router Class Initialized
INFO - 2017-12-22 05:52:50 --> Output Class Initialized
INFO - 2017-12-22 05:52:50 --> Security Class Initialized
DEBUG - 2017-12-22 05:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 05:52:50 --> Input Class Initialized
INFO - 2017-12-22 05:52:50 --> Language Class Initialized
INFO - 2017-12-22 05:52:50 --> Loader Class Initialized
INFO - 2017-12-22 05:52:51 --> Helper loaded: url_helper
INFO - 2017-12-22 05:52:51 --> Helper loaded: form_helper
INFO - 2017-12-22 05:52:51 --> Database Driver Class Initialized
DEBUG - 2017-12-22 05:52:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 05:52:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 05:52:51 --> Form Validation Class Initialized
INFO - 2017-12-22 05:52:51 --> Model Class Initialized
INFO - 2017-12-22 05:52:51 --> Controller Class Initialized
INFO - 2017-12-22 05:52:51 --> Model Class Initialized
INFO - 2017-12-22 05:52:51 --> Model Class Initialized
INFO - 2017-12-22 05:52:51 --> Model Class Initialized
DEBUG - 2017-12-22 05:52:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 05:52:51 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 05:52:51 --> Final output sent to browser
DEBUG - 2017-12-22 05:52:51 --> Total execution time: 0.0755
INFO - 2017-12-22 05:52:51 --> Config Class Initialized
INFO - 2017-12-22 05:52:51 --> Hooks Class Initialized
DEBUG - 2017-12-22 05:52:51 --> UTF-8 Support Enabled
INFO - 2017-12-22 05:52:51 --> Utf8 Class Initialized
INFO - 2017-12-22 05:52:51 --> URI Class Initialized
INFO - 2017-12-22 05:52:51 --> Router Class Initialized
INFO - 2017-12-22 05:52:51 --> Output Class Initialized
INFO - 2017-12-22 05:52:51 --> Security Class Initialized
DEBUG - 2017-12-22 05:52:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 05:52:51 --> Input Class Initialized
INFO - 2017-12-22 05:52:51 --> Language Class Initialized
ERROR - 2017-12-22 05:52:51 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-22 05:52:51 --> Config Class Initialized
INFO - 2017-12-22 05:52:51 --> Hooks Class Initialized
INFO - 2017-12-22 05:52:51 --> Config Class Initialized
INFO - 2017-12-22 05:52:51 --> Hooks Class Initialized
DEBUG - 2017-12-22 05:52:51 --> UTF-8 Support Enabled
INFO - 2017-12-22 05:52:51 --> Utf8 Class Initialized
DEBUG - 2017-12-22 05:52:51 --> UTF-8 Support Enabled
INFO - 2017-12-22 05:52:51 --> Utf8 Class Initialized
INFO - 2017-12-22 05:52:51 --> URI Class Initialized
INFO - 2017-12-22 05:52:51 --> URI Class Initialized
INFO - 2017-12-22 05:52:51 --> Router Class Initialized
INFO - 2017-12-22 05:52:51 --> Router Class Initialized
INFO - 2017-12-22 05:52:51 --> Output Class Initialized
INFO - 2017-12-22 05:52:51 --> Output Class Initialized
INFO - 2017-12-22 05:52:51 --> Security Class Initialized
INFO - 2017-12-22 05:52:51 --> Security Class Initialized
DEBUG - 2017-12-22 05:52:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 05:52:51 --> Input Class Initialized
DEBUG - 2017-12-22 05:52:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 05:52:51 --> Input Class Initialized
INFO - 2017-12-22 05:52:51 --> Language Class Initialized
INFO - 2017-12-22 05:52:51 --> Language Class Initialized
ERROR - 2017-12-22 05:52:51 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-22 05:52:51 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-22 05:53:20 --> Config Class Initialized
INFO - 2017-12-22 05:53:20 --> Hooks Class Initialized
DEBUG - 2017-12-22 05:53:20 --> UTF-8 Support Enabled
INFO - 2017-12-22 05:53:20 --> Utf8 Class Initialized
INFO - 2017-12-22 05:53:20 --> URI Class Initialized
INFO - 2017-12-22 05:53:20 --> Router Class Initialized
INFO - 2017-12-22 05:53:20 --> Output Class Initialized
INFO - 2017-12-22 05:53:20 --> Security Class Initialized
DEBUG - 2017-12-22 05:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 05:53:20 --> Input Class Initialized
INFO - 2017-12-22 05:53:20 --> Language Class Initialized
INFO - 2017-12-22 05:53:20 --> Loader Class Initialized
INFO - 2017-12-22 05:53:20 --> Helper loaded: url_helper
INFO - 2017-12-22 05:53:20 --> Helper loaded: form_helper
INFO - 2017-12-22 05:53:20 --> Database Driver Class Initialized
DEBUG - 2017-12-22 05:53:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 05:53:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 05:53:20 --> Form Validation Class Initialized
INFO - 2017-12-22 05:53:20 --> Model Class Initialized
INFO - 2017-12-22 05:53:20 --> Controller Class Initialized
INFO - 2017-12-22 05:53:20 --> Model Class Initialized
INFO - 2017-12-22 05:53:20 --> Model Class Initialized
INFO - 2017-12-22 05:53:20 --> Model Class Initialized
DEBUG - 2017-12-22 05:53:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 05:53:20 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 05:53:20 --> Final output sent to browser
DEBUG - 2017-12-22 05:53:20 --> Total execution time: 0.0790
INFO - 2017-12-22 05:53:21 --> Config Class Initialized
INFO - 2017-12-22 05:53:21 --> Hooks Class Initialized
DEBUG - 2017-12-22 05:53:21 --> UTF-8 Support Enabled
INFO - 2017-12-22 05:53:21 --> Utf8 Class Initialized
INFO - 2017-12-22 05:53:21 --> URI Class Initialized
INFO - 2017-12-22 05:53:21 --> Router Class Initialized
INFO - 2017-12-22 05:53:21 --> Output Class Initialized
INFO - 2017-12-22 05:53:21 --> Security Class Initialized
DEBUG - 2017-12-22 05:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 05:53:21 --> Input Class Initialized
INFO - 2017-12-22 05:53:21 --> Language Class Initialized
ERROR - 2017-12-22 05:53:21 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-22 05:53:21 --> Config Class Initialized
INFO - 2017-12-22 05:53:21 --> Hooks Class Initialized
INFO - 2017-12-22 05:53:21 --> Config Class Initialized
INFO - 2017-12-22 05:53:21 --> Hooks Class Initialized
DEBUG - 2017-12-22 05:53:21 --> UTF-8 Support Enabled
DEBUG - 2017-12-22 05:53:21 --> UTF-8 Support Enabled
INFO - 2017-12-22 05:53:21 --> Utf8 Class Initialized
INFO - 2017-12-22 05:53:21 --> Utf8 Class Initialized
INFO - 2017-12-22 05:53:21 --> URI Class Initialized
INFO - 2017-12-22 05:53:21 --> URI Class Initialized
INFO - 2017-12-22 05:53:21 --> Router Class Initialized
INFO - 2017-12-22 05:53:21 --> Router Class Initialized
INFO - 2017-12-22 05:53:21 --> Output Class Initialized
INFO - 2017-12-22 05:53:21 --> Security Class Initialized
INFO - 2017-12-22 05:53:21 --> Output Class Initialized
DEBUG - 2017-12-22 05:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 05:53:21 --> Security Class Initialized
INFO - 2017-12-22 05:53:21 --> Input Class Initialized
INFO - 2017-12-22 05:53:21 --> Language Class Initialized
DEBUG - 2017-12-22 05:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 05:53:21 --> Input Class Initialized
ERROR - 2017-12-22 05:53:21 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-22 05:53:21 --> Language Class Initialized
ERROR - 2017-12-22 05:53:21 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-22 05:53:21 --> Config Class Initialized
INFO - 2017-12-22 05:53:21 --> Hooks Class Initialized
DEBUG - 2017-12-22 05:53:21 --> UTF-8 Support Enabled
INFO - 2017-12-22 05:53:21 --> Utf8 Class Initialized
INFO - 2017-12-22 05:53:21 --> URI Class Initialized
INFO - 2017-12-22 05:53:21 --> Router Class Initialized
INFO - 2017-12-22 05:53:21 --> Output Class Initialized
INFO - 2017-12-22 05:53:21 --> Security Class Initialized
DEBUG - 2017-12-22 05:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 05:53:21 --> Input Class Initialized
INFO - 2017-12-22 05:53:21 --> Language Class Initialized
INFO - 2017-12-22 05:53:21 --> Loader Class Initialized
INFO - 2017-12-22 05:53:21 --> Helper loaded: url_helper
INFO - 2017-12-22 05:53:21 --> Helper loaded: form_helper
INFO - 2017-12-22 05:53:21 --> Database Driver Class Initialized
DEBUG - 2017-12-22 05:53:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 05:53:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 05:53:21 --> Form Validation Class Initialized
INFO - 2017-12-22 05:53:21 --> Model Class Initialized
INFO - 2017-12-22 05:53:21 --> Controller Class Initialized
INFO - 2017-12-22 05:53:21 --> Model Class Initialized
INFO - 2017-12-22 05:53:21 --> Model Class Initialized
INFO - 2017-12-22 05:53:21 --> Model Class Initialized
DEBUG - 2017-12-22 05:53:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 05:54:11 --> Config Class Initialized
INFO - 2017-12-22 05:54:11 --> Hooks Class Initialized
DEBUG - 2017-12-22 05:54:11 --> UTF-8 Support Enabled
INFO - 2017-12-22 05:54:11 --> Utf8 Class Initialized
INFO - 2017-12-22 05:54:11 --> URI Class Initialized
INFO - 2017-12-22 05:54:11 --> Router Class Initialized
INFO - 2017-12-22 05:54:11 --> Output Class Initialized
INFO - 2017-12-22 05:54:11 --> Security Class Initialized
DEBUG - 2017-12-22 05:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 05:54:11 --> Input Class Initialized
INFO - 2017-12-22 05:54:11 --> Language Class Initialized
INFO - 2017-12-22 05:54:11 --> Loader Class Initialized
INFO - 2017-12-22 05:54:11 --> Helper loaded: url_helper
INFO - 2017-12-22 05:54:11 --> Helper loaded: form_helper
INFO - 2017-12-22 05:54:11 --> Database Driver Class Initialized
DEBUG - 2017-12-22 05:54:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 05:54:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 05:54:11 --> Form Validation Class Initialized
INFO - 2017-12-22 05:54:11 --> Model Class Initialized
INFO - 2017-12-22 05:54:11 --> Controller Class Initialized
INFO - 2017-12-22 05:54:11 --> Model Class Initialized
INFO - 2017-12-22 05:54:11 --> Model Class Initialized
INFO - 2017-12-22 05:54:11 --> Model Class Initialized
DEBUG - 2017-12-22 05:54:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 05:54:11 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 05:54:11 --> Final output sent to browser
DEBUG - 2017-12-22 05:54:11 --> Total execution time: 0.0707
INFO - 2017-12-22 05:54:11 --> Config Class Initialized
INFO - 2017-12-22 05:54:11 --> Hooks Class Initialized
DEBUG - 2017-12-22 05:54:11 --> UTF-8 Support Enabled
INFO - 2017-12-22 05:54:11 --> Utf8 Class Initialized
INFO - 2017-12-22 05:54:11 --> URI Class Initialized
INFO - 2017-12-22 05:54:11 --> Router Class Initialized
INFO - 2017-12-22 05:54:11 --> Output Class Initialized
INFO - 2017-12-22 05:54:11 --> Security Class Initialized
DEBUG - 2017-12-22 05:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 05:54:11 --> Input Class Initialized
INFO - 2017-12-22 05:54:11 --> Language Class Initialized
ERROR - 2017-12-22 05:54:11 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-22 05:54:11 --> Config Class Initialized
INFO - 2017-12-22 05:54:11 --> Hooks Class Initialized
INFO - 2017-12-22 05:54:11 --> Config Class Initialized
INFO - 2017-12-22 05:54:11 --> Hooks Class Initialized
DEBUG - 2017-12-22 05:54:11 --> UTF-8 Support Enabled
DEBUG - 2017-12-22 05:54:11 --> UTF-8 Support Enabled
INFO - 2017-12-22 05:54:11 --> Utf8 Class Initialized
INFO - 2017-12-22 05:54:11 --> Utf8 Class Initialized
INFO - 2017-12-22 05:54:11 --> URI Class Initialized
INFO - 2017-12-22 05:54:11 --> URI Class Initialized
INFO - 2017-12-22 05:54:11 --> Router Class Initialized
INFO - 2017-12-22 05:54:11 --> Router Class Initialized
INFO - 2017-12-22 05:54:11 --> Output Class Initialized
INFO - 2017-12-22 05:54:11 --> Output Class Initialized
INFO - 2017-12-22 05:54:11 --> Security Class Initialized
INFO - 2017-12-22 05:54:11 --> Security Class Initialized
DEBUG - 2017-12-22 05:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 05:54:11 --> Input Class Initialized
DEBUG - 2017-12-22 05:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 05:54:11 --> Input Class Initialized
INFO - 2017-12-22 05:54:11 --> Language Class Initialized
INFO - 2017-12-22 05:54:11 --> Language Class Initialized
ERROR - 2017-12-22 05:54:11 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-22 05:54:11 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-22 05:54:29 --> Config Class Initialized
INFO - 2017-12-22 05:54:29 --> Hooks Class Initialized
DEBUG - 2017-12-22 05:54:29 --> UTF-8 Support Enabled
INFO - 2017-12-22 05:54:29 --> Utf8 Class Initialized
INFO - 2017-12-22 05:54:29 --> URI Class Initialized
INFO - 2017-12-22 05:54:29 --> Router Class Initialized
INFO - 2017-12-22 05:54:29 --> Output Class Initialized
INFO - 2017-12-22 05:54:29 --> Security Class Initialized
DEBUG - 2017-12-22 05:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 05:54:29 --> Input Class Initialized
INFO - 2017-12-22 05:54:29 --> Language Class Initialized
INFO - 2017-12-22 05:54:29 --> Loader Class Initialized
INFO - 2017-12-22 05:54:29 --> Helper loaded: url_helper
INFO - 2017-12-22 05:54:29 --> Helper loaded: form_helper
INFO - 2017-12-22 05:54:29 --> Database Driver Class Initialized
DEBUG - 2017-12-22 05:54:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 05:54:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 05:54:29 --> Form Validation Class Initialized
INFO - 2017-12-22 05:54:29 --> Model Class Initialized
INFO - 2017-12-22 05:54:29 --> Controller Class Initialized
INFO - 2017-12-22 05:54:29 --> Model Class Initialized
INFO - 2017-12-22 05:54:29 --> Model Class Initialized
INFO - 2017-12-22 05:54:29 --> Model Class Initialized
DEBUG - 2017-12-22 05:54:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 05:54:29 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 05:54:29 --> Final output sent to browser
DEBUG - 2017-12-22 05:54:29 --> Total execution time: 0.0752
INFO - 2017-12-22 05:54:29 --> Config Class Initialized
INFO - 2017-12-22 05:54:29 --> Hooks Class Initialized
DEBUG - 2017-12-22 05:54:29 --> UTF-8 Support Enabled
INFO - 2017-12-22 05:54:29 --> Utf8 Class Initialized
INFO - 2017-12-22 05:54:29 --> URI Class Initialized
INFO - 2017-12-22 05:54:29 --> Router Class Initialized
INFO - 2017-12-22 05:54:29 --> Output Class Initialized
INFO - 2017-12-22 05:54:29 --> Security Class Initialized
DEBUG - 2017-12-22 05:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 05:54:29 --> Input Class Initialized
INFO - 2017-12-22 05:54:29 --> Language Class Initialized
ERROR - 2017-12-22 05:54:29 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-22 05:54:29 --> Config Class Initialized
INFO - 2017-12-22 05:54:29 --> Hooks Class Initialized
INFO - 2017-12-22 05:54:29 --> Config Class Initialized
INFO - 2017-12-22 05:54:29 --> Hooks Class Initialized
DEBUG - 2017-12-22 05:54:29 --> UTF-8 Support Enabled
INFO - 2017-12-22 05:54:29 --> Utf8 Class Initialized
DEBUG - 2017-12-22 05:54:29 --> UTF-8 Support Enabled
INFO - 2017-12-22 05:54:29 --> Utf8 Class Initialized
INFO - 2017-12-22 05:54:29 --> URI Class Initialized
INFO - 2017-12-22 05:54:29 --> URI Class Initialized
INFO - 2017-12-22 05:54:29 --> Router Class Initialized
INFO - 2017-12-22 05:54:29 --> Router Class Initialized
INFO - 2017-12-22 05:54:29 --> Output Class Initialized
INFO - 2017-12-22 05:54:29 --> Output Class Initialized
INFO - 2017-12-22 05:54:29 --> Security Class Initialized
INFO - 2017-12-22 05:54:29 --> Security Class Initialized
DEBUG - 2017-12-22 05:54:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-22 05:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 05:54:29 --> Input Class Initialized
INFO - 2017-12-22 05:54:29 --> Input Class Initialized
INFO - 2017-12-22 05:54:29 --> Language Class Initialized
INFO - 2017-12-22 05:54:29 --> Language Class Initialized
ERROR - 2017-12-22 05:54:29 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-22 05:54:29 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-22 05:54:29 --> Config Class Initialized
INFO - 2017-12-22 05:54:29 --> Hooks Class Initialized
DEBUG - 2017-12-22 05:54:29 --> UTF-8 Support Enabled
INFO - 2017-12-22 05:54:29 --> Utf8 Class Initialized
INFO - 2017-12-22 05:54:29 --> URI Class Initialized
INFO - 2017-12-22 05:54:29 --> Router Class Initialized
INFO - 2017-12-22 05:54:29 --> Output Class Initialized
INFO - 2017-12-22 05:54:29 --> Security Class Initialized
DEBUG - 2017-12-22 05:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 05:54:29 --> Input Class Initialized
INFO - 2017-12-22 05:54:29 --> Language Class Initialized
INFO - 2017-12-22 05:54:29 --> Loader Class Initialized
INFO - 2017-12-22 05:54:29 --> Helper loaded: url_helper
INFO - 2017-12-22 05:54:29 --> Helper loaded: form_helper
INFO - 2017-12-22 05:54:30 --> Database Driver Class Initialized
DEBUG - 2017-12-22 05:54:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 05:54:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 05:54:30 --> Form Validation Class Initialized
INFO - 2017-12-22 05:54:30 --> Model Class Initialized
INFO - 2017-12-22 05:54:30 --> Controller Class Initialized
INFO - 2017-12-22 05:54:30 --> Model Class Initialized
INFO - 2017-12-22 05:54:30 --> Model Class Initialized
INFO - 2017-12-22 05:54:30 --> Model Class Initialized
DEBUG - 2017-12-22 05:54:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 05:58:56 --> Config Class Initialized
INFO - 2017-12-22 05:58:56 --> Hooks Class Initialized
DEBUG - 2017-12-22 05:58:56 --> UTF-8 Support Enabled
INFO - 2017-12-22 05:58:56 --> Utf8 Class Initialized
INFO - 2017-12-22 05:58:56 --> URI Class Initialized
INFO - 2017-12-22 05:58:56 --> Router Class Initialized
INFO - 2017-12-22 05:58:56 --> Output Class Initialized
INFO - 2017-12-22 05:58:56 --> Security Class Initialized
DEBUG - 2017-12-22 05:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 05:58:56 --> Input Class Initialized
INFO - 2017-12-22 05:58:56 --> Language Class Initialized
INFO - 2017-12-22 05:58:56 --> Loader Class Initialized
INFO - 2017-12-22 05:58:56 --> Helper loaded: url_helper
INFO - 2017-12-22 05:58:56 --> Helper loaded: form_helper
INFO - 2017-12-22 05:58:56 --> Database Driver Class Initialized
DEBUG - 2017-12-22 05:58:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 05:58:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 05:58:56 --> Form Validation Class Initialized
INFO - 2017-12-22 05:58:56 --> Model Class Initialized
INFO - 2017-12-22 05:58:56 --> Controller Class Initialized
INFO - 2017-12-22 05:58:56 --> Model Class Initialized
INFO - 2017-12-22 05:58:56 --> Model Class Initialized
INFO - 2017-12-22 05:58:56 --> Model Class Initialized
DEBUG - 2017-12-22 05:58:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 05:58:56 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 05:58:56 --> Final output sent to browser
DEBUG - 2017-12-22 05:58:56 --> Total execution time: 0.0705
INFO - 2017-12-22 05:58:57 --> Config Class Initialized
INFO - 2017-12-22 05:58:57 --> Hooks Class Initialized
DEBUG - 2017-12-22 05:58:57 --> UTF-8 Support Enabled
INFO - 2017-12-22 05:58:57 --> Utf8 Class Initialized
INFO - 2017-12-22 05:58:57 --> URI Class Initialized
INFO - 2017-12-22 05:58:57 --> Router Class Initialized
INFO - 2017-12-22 05:58:57 --> Output Class Initialized
INFO - 2017-12-22 05:58:57 --> Security Class Initialized
DEBUG - 2017-12-22 05:58:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 05:58:57 --> Input Class Initialized
INFO - 2017-12-22 05:58:57 --> Language Class Initialized
ERROR - 2017-12-22 05:58:57 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-22 05:58:57 --> Config Class Initialized
INFO - 2017-12-22 05:58:57 --> Config Class Initialized
INFO - 2017-12-22 05:58:57 --> Hooks Class Initialized
INFO - 2017-12-22 05:58:57 --> Hooks Class Initialized
DEBUG - 2017-12-22 05:58:57 --> UTF-8 Support Enabled
DEBUG - 2017-12-22 05:58:57 --> UTF-8 Support Enabled
INFO - 2017-12-22 05:58:57 --> Utf8 Class Initialized
INFO - 2017-12-22 05:58:57 --> Utf8 Class Initialized
INFO - 2017-12-22 05:58:57 --> URI Class Initialized
INFO - 2017-12-22 05:58:57 --> URI Class Initialized
INFO - 2017-12-22 05:58:57 --> Router Class Initialized
INFO - 2017-12-22 05:58:57 --> Router Class Initialized
INFO - 2017-12-22 05:58:57 --> Output Class Initialized
INFO - 2017-12-22 05:58:57 --> Output Class Initialized
INFO - 2017-12-22 05:58:57 --> Security Class Initialized
INFO - 2017-12-22 05:58:57 --> Security Class Initialized
DEBUG - 2017-12-22 05:58:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-22 05:58:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 05:58:57 --> Input Class Initialized
INFO - 2017-12-22 05:58:57 --> Input Class Initialized
INFO - 2017-12-22 05:58:57 --> Language Class Initialized
INFO - 2017-12-22 05:58:57 --> Language Class Initialized
ERROR - 2017-12-22 05:58:57 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-22 05:58:57 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-22 05:58:57 --> Config Class Initialized
INFO - 2017-12-22 05:58:57 --> Hooks Class Initialized
DEBUG - 2017-12-22 05:58:57 --> UTF-8 Support Enabled
INFO - 2017-12-22 05:58:57 --> Utf8 Class Initialized
INFO - 2017-12-22 05:58:57 --> URI Class Initialized
INFO - 2017-12-22 05:58:57 --> Router Class Initialized
INFO - 2017-12-22 05:58:57 --> Output Class Initialized
INFO - 2017-12-22 05:58:57 --> Security Class Initialized
DEBUG - 2017-12-22 05:58:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 05:58:57 --> Input Class Initialized
INFO - 2017-12-22 05:58:57 --> Language Class Initialized
INFO - 2017-12-22 05:58:57 --> Loader Class Initialized
INFO - 2017-12-22 05:58:57 --> Helper loaded: url_helper
INFO - 2017-12-22 05:58:57 --> Helper loaded: form_helper
INFO - 2017-12-22 05:58:57 --> Database Driver Class Initialized
DEBUG - 2017-12-22 05:58:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 05:58:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 05:58:57 --> Form Validation Class Initialized
INFO - 2017-12-22 05:58:57 --> Model Class Initialized
INFO - 2017-12-22 05:58:57 --> Controller Class Initialized
INFO - 2017-12-22 05:58:57 --> Model Class Initialized
INFO - 2017-12-22 05:58:57 --> Model Class Initialized
INFO - 2017-12-22 05:58:57 --> Model Class Initialized
DEBUG - 2017-12-22 05:58:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 06:00:15 --> Config Class Initialized
INFO - 2017-12-22 06:00:15 --> Hooks Class Initialized
DEBUG - 2017-12-22 06:00:15 --> UTF-8 Support Enabled
INFO - 2017-12-22 06:00:15 --> Utf8 Class Initialized
INFO - 2017-12-22 06:00:15 --> URI Class Initialized
INFO - 2017-12-22 06:00:15 --> Router Class Initialized
INFO - 2017-12-22 06:00:15 --> Output Class Initialized
INFO - 2017-12-22 06:00:15 --> Security Class Initialized
DEBUG - 2017-12-22 06:00:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 06:00:15 --> Input Class Initialized
INFO - 2017-12-22 06:00:15 --> Language Class Initialized
INFO - 2017-12-22 06:00:15 --> Loader Class Initialized
INFO - 2017-12-22 06:00:15 --> Helper loaded: url_helper
INFO - 2017-12-22 06:00:15 --> Helper loaded: form_helper
INFO - 2017-12-22 06:00:15 --> Database Driver Class Initialized
DEBUG - 2017-12-22 06:00:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 06:00:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 06:00:15 --> Form Validation Class Initialized
INFO - 2017-12-22 06:00:15 --> Model Class Initialized
INFO - 2017-12-22 06:00:15 --> Controller Class Initialized
INFO - 2017-12-22 06:00:15 --> Model Class Initialized
INFO - 2017-12-22 06:00:15 --> Model Class Initialized
INFO - 2017-12-22 06:00:15 --> Model Class Initialized
DEBUG - 2017-12-22 06:00:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 06:00:15 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 06:00:15 --> Final output sent to browser
DEBUG - 2017-12-22 06:00:15 --> Total execution time: 0.0809
INFO - 2017-12-22 06:00:15 --> Config Class Initialized
INFO - 2017-12-22 06:00:15 --> Hooks Class Initialized
DEBUG - 2017-12-22 06:00:15 --> UTF-8 Support Enabled
INFO - 2017-12-22 06:00:15 --> Utf8 Class Initialized
INFO - 2017-12-22 06:00:15 --> URI Class Initialized
INFO - 2017-12-22 06:00:15 --> Router Class Initialized
INFO - 2017-12-22 06:00:15 --> Output Class Initialized
INFO - 2017-12-22 06:00:15 --> Security Class Initialized
DEBUG - 2017-12-22 06:00:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 06:00:15 --> Input Class Initialized
INFO - 2017-12-22 06:00:15 --> Language Class Initialized
ERROR - 2017-12-22 06:00:15 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-22 06:00:15 --> Config Class Initialized
INFO - 2017-12-22 06:00:15 --> Hooks Class Initialized
INFO - 2017-12-22 06:00:15 --> Config Class Initialized
INFO - 2017-12-22 06:00:15 --> Hooks Class Initialized
DEBUG - 2017-12-22 06:00:15 --> UTF-8 Support Enabled
INFO - 2017-12-22 06:00:15 --> Utf8 Class Initialized
INFO - 2017-12-22 06:00:15 --> URI Class Initialized
DEBUG - 2017-12-22 06:00:15 --> UTF-8 Support Enabled
INFO - 2017-12-22 06:00:15 --> Utf8 Class Initialized
INFO - 2017-12-22 06:00:15 --> Router Class Initialized
INFO - 2017-12-22 06:00:15 --> URI Class Initialized
INFO - 2017-12-22 06:00:15 --> Output Class Initialized
INFO - 2017-12-22 06:00:15 --> Router Class Initialized
INFO - 2017-12-22 06:00:15 --> Security Class Initialized
DEBUG - 2017-12-22 06:00:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 06:00:15 --> Input Class Initialized
INFO - 2017-12-22 06:00:15 --> Output Class Initialized
INFO - 2017-12-22 06:00:15 --> Language Class Initialized
INFO - 2017-12-22 06:00:15 --> Security Class Initialized
ERROR - 2017-12-22 06:00:15 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2017-12-22 06:00:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 06:00:15 --> Input Class Initialized
INFO - 2017-12-22 06:00:15 --> Language Class Initialized
ERROR - 2017-12-22 06:00:15 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-22 06:00:15 --> Config Class Initialized
INFO - 2017-12-22 06:00:15 --> Hooks Class Initialized
DEBUG - 2017-12-22 06:00:15 --> UTF-8 Support Enabled
INFO - 2017-12-22 06:00:15 --> Utf8 Class Initialized
INFO - 2017-12-22 06:00:15 --> URI Class Initialized
INFO - 2017-12-22 06:00:15 --> Router Class Initialized
INFO - 2017-12-22 06:00:15 --> Output Class Initialized
INFO - 2017-12-22 06:00:15 --> Security Class Initialized
DEBUG - 2017-12-22 06:00:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 06:00:15 --> Input Class Initialized
INFO - 2017-12-22 06:00:15 --> Language Class Initialized
INFO - 2017-12-22 06:00:15 --> Loader Class Initialized
INFO - 2017-12-22 06:00:15 --> Helper loaded: url_helper
INFO - 2017-12-22 06:00:15 --> Helper loaded: form_helper
INFO - 2017-12-22 06:00:15 --> Database Driver Class Initialized
DEBUG - 2017-12-22 06:00:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 06:00:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 06:00:15 --> Form Validation Class Initialized
INFO - 2017-12-22 06:00:15 --> Model Class Initialized
INFO - 2017-12-22 06:00:15 --> Controller Class Initialized
INFO - 2017-12-22 06:00:15 --> Model Class Initialized
INFO - 2017-12-22 06:00:15 --> Model Class Initialized
INFO - 2017-12-22 06:00:15 --> Model Class Initialized
DEBUG - 2017-12-22 06:00:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 06:00:17 --> Config Class Initialized
INFO - 2017-12-22 06:00:17 --> Hooks Class Initialized
DEBUG - 2017-12-22 06:00:17 --> UTF-8 Support Enabled
INFO - 2017-12-22 06:00:17 --> Utf8 Class Initialized
INFO - 2017-12-22 06:00:17 --> URI Class Initialized
INFO - 2017-12-22 06:00:17 --> Router Class Initialized
INFO - 2017-12-22 06:00:17 --> Output Class Initialized
INFO - 2017-12-22 06:00:17 --> Security Class Initialized
DEBUG - 2017-12-22 06:00:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 06:00:17 --> Input Class Initialized
INFO - 2017-12-22 06:00:17 --> Language Class Initialized
INFO - 2017-12-22 06:00:17 --> Loader Class Initialized
INFO - 2017-12-22 06:00:17 --> Helper loaded: url_helper
INFO - 2017-12-22 06:00:17 --> Helper loaded: form_helper
INFO - 2017-12-22 06:00:17 --> Database Driver Class Initialized
DEBUG - 2017-12-22 06:00:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 06:00:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 06:00:17 --> Form Validation Class Initialized
INFO - 2017-12-22 06:00:17 --> Model Class Initialized
INFO - 2017-12-22 06:00:17 --> Controller Class Initialized
INFO - 2017-12-22 06:00:17 --> Model Class Initialized
INFO - 2017-12-22 06:00:17 --> Model Class Initialized
INFO - 2017-12-22 06:00:17 --> Model Class Initialized
DEBUG - 2017-12-22 06:00:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 06:00:17 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 06:00:17 --> Final output sent to browser
DEBUG - 2017-12-22 06:00:17 --> Total execution time: 0.0467
INFO - 2017-12-22 06:00:17 --> Config Class Initialized
INFO - 2017-12-22 06:00:17 --> Hooks Class Initialized
DEBUG - 2017-12-22 06:00:17 --> UTF-8 Support Enabled
INFO - 2017-12-22 06:00:17 --> Utf8 Class Initialized
INFO - 2017-12-22 06:00:17 --> URI Class Initialized
INFO - 2017-12-22 06:00:17 --> Router Class Initialized
INFO - 2017-12-22 06:00:17 --> Output Class Initialized
INFO - 2017-12-22 06:00:17 --> Security Class Initialized
DEBUG - 2017-12-22 06:00:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 06:00:17 --> Input Class Initialized
INFO - 2017-12-22 06:00:17 --> Language Class Initialized
ERROR - 2017-12-22 06:00:17 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-22 06:00:17 --> Config Class Initialized
INFO - 2017-12-22 06:00:17 --> Hooks Class Initialized
INFO - 2017-12-22 06:00:17 --> Config Class Initialized
INFO - 2017-12-22 06:00:17 --> Hooks Class Initialized
DEBUG - 2017-12-22 06:00:17 --> UTF-8 Support Enabled
INFO - 2017-12-22 06:00:17 --> Utf8 Class Initialized
DEBUG - 2017-12-22 06:00:17 --> UTF-8 Support Enabled
INFO - 2017-12-22 06:00:17 --> Utf8 Class Initialized
INFO - 2017-12-22 06:00:17 --> URI Class Initialized
INFO - 2017-12-22 06:00:17 --> URI Class Initialized
INFO - 2017-12-22 06:00:17 --> Router Class Initialized
INFO - 2017-12-22 06:00:17 --> Router Class Initialized
INFO - 2017-12-22 06:00:17 --> Output Class Initialized
INFO - 2017-12-22 06:00:17 --> Output Class Initialized
INFO - 2017-12-22 06:00:17 --> Security Class Initialized
INFO - 2017-12-22 06:00:17 --> Security Class Initialized
DEBUG - 2017-12-22 06:00:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-22 06:00:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 06:00:17 --> Input Class Initialized
INFO - 2017-12-22 06:00:17 --> Input Class Initialized
INFO - 2017-12-22 06:00:17 --> Language Class Initialized
INFO - 2017-12-22 06:00:17 --> Language Class Initialized
ERROR - 2017-12-22 06:00:17 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-22 06:00:17 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-22 06:00:17 --> Config Class Initialized
INFO - 2017-12-22 06:00:17 --> Hooks Class Initialized
DEBUG - 2017-12-22 06:00:17 --> UTF-8 Support Enabled
INFO - 2017-12-22 06:00:17 --> Utf8 Class Initialized
INFO - 2017-12-22 06:00:17 --> URI Class Initialized
INFO - 2017-12-22 06:00:17 --> Router Class Initialized
INFO - 2017-12-22 06:00:17 --> Output Class Initialized
INFO - 2017-12-22 06:00:17 --> Security Class Initialized
DEBUG - 2017-12-22 06:00:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 06:00:17 --> Input Class Initialized
INFO - 2017-12-22 06:00:17 --> Language Class Initialized
INFO - 2017-12-22 06:00:17 --> Loader Class Initialized
INFO - 2017-12-22 06:00:17 --> Helper loaded: url_helper
INFO - 2017-12-22 06:00:17 --> Helper loaded: form_helper
INFO - 2017-12-22 06:00:17 --> Database Driver Class Initialized
DEBUG - 2017-12-22 06:00:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 06:00:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 06:00:17 --> Form Validation Class Initialized
INFO - 2017-12-22 06:00:17 --> Model Class Initialized
INFO - 2017-12-22 06:00:17 --> Controller Class Initialized
INFO - 2017-12-22 06:00:17 --> Model Class Initialized
INFO - 2017-12-22 06:00:17 --> Model Class Initialized
INFO - 2017-12-22 06:00:17 --> Model Class Initialized
DEBUG - 2017-12-22 06:00:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 06:04:28 --> Config Class Initialized
INFO - 2017-12-22 06:04:28 --> Hooks Class Initialized
DEBUG - 2017-12-22 06:04:28 --> UTF-8 Support Enabled
INFO - 2017-12-22 06:04:28 --> Utf8 Class Initialized
INFO - 2017-12-22 06:04:28 --> URI Class Initialized
INFO - 2017-12-22 06:04:28 --> Router Class Initialized
INFO - 2017-12-22 06:04:28 --> Output Class Initialized
INFO - 2017-12-22 06:04:28 --> Security Class Initialized
DEBUG - 2017-12-22 06:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 06:04:28 --> Input Class Initialized
INFO - 2017-12-22 06:04:28 --> Language Class Initialized
INFO - 2017-12-22 06:04:28 --> Loader Class Initialized
INFO - 2017-12-22 06:04:28 --> Helper loaded: url_helper
INFO - 2017-12-22 06:04:28 --> Helper loaded: form_helper
INFO - 2017-12-22 06:04:28 --> Database Driver Class Initialized
DEBUG - 2017-12-22 06:04:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 06:04:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 06:04:28 --> Form Validation Class Initialized
INFO - 2017-12-22 06:04:28 --> Model Class Initialized
INFO - 2017-12-22 06:04:28 --> Controller Class Initialized
INFO - 2017-12-22 06:04:28 --> Model Class Initialized
INFO - 2017-12-22 06:04:28 --> Model Class Initialized
INFO - 2017-12-22 06:04:28 --> Model Class Initialized
DEBUG - 2017-12-22 06:04:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 06:04:28 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 06:04:28 --> Final output sent to browser
DEBUG - 2017-12-22 06:04:28 --> Total execution time: 0.0617
INFO - 2017-12-22 06:04:29 --> Config Class Initialized
INFO - 2017-12-22 06:04:29 --> Hooks Class Initialized
DEBUG - 2017-12-22 06:04:29 --> UTF-8 Support Enabled
INFO - 2017-12-22 06:04:29 --> Utf8 Class Initialized
INFO - 2017-12-22 06:04:29 --> URI Class Initialized
INFO - 2017-12-22 06:04:29 --> Router Class Initialized
INFO - 2017-12-22 06:04:29 --> Output Class Initialized
INFO - 2017-12-22 06:04:29 --> Security Class Initialized
DEBUG - 2017-12-22 06:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 06:04:29 --> Input Class Initialized
INFO - 2017-12-22 06:04:29 --> Language Class Initialized
ERROR - 2017-12-22 06:04:29 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-22 06:04:29 --> Config Class Initialized
INFO - 2017-12-22 06:04:29 --> Hooks Class Initialized
INFO - 2017-12-22 06:04:29 --> Config Class Initialized
INFO - 2017-12-22 06:04:29 --> Hooks Class Initialized
DEBUG - 2017-12-22 06:04:29 --> UTF-8 Support Enabled
DEBUG - 2017-12-22 06:04:29 --> UTF-8 Support Enabled
INFO - 2017-12-22 06:04:29 --> Utf8 Class Initialized
INFO - 2017-12-22 06:04:29 --> Utf8 Class Initialized
INFO - 2017-12-22 06:04:29 --> URI Class Initialized
INFO - 2017-12-22 06:04:29 --> URI Class Initialized
INFO - 2017-12-22 06:04:29 --> Router Class Initialized
INFO - 2017-12-22 06:04:29 --> Router Class Initialized
INFO - 2017-12-22 06:04:29 --> Output Class Initialized
INFO - 2017-12-22 06:04:29 --> Output Class Initialized
INFO - 2017-12-22 06:04:29 --> Security Class Initialized
INFO - 2017-12-22 06:04:29 --> Security Class Initialized
DEBUG - 2017-12-22 06:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 06:04:29 --> Input Class Initialized
DEBUG - 2017-12-22 06:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 06:04:29 --> Language Class Initialized
INFO - 2017-12-22 06:04:29 --> Input Class Initialized
INFO - 2017-12-22 06:04:29 --> Language Class Initialized
ERROR - 2017-12-22 06:04:29 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-22 06:04:29 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-22 06:04:29 --> Config Class Initialized
INFO - 2017-12-22 06:04:29 --> Hooks Class Initialized
DEBUG - 2017-12-22 06:04:29 --> UTF-8 Support Enabled
INFO - 2017-12-22 06:04:29 --> Utf8 Class Initialized
INFO - 2017-12-22 06:04:29 --> URI Class Initialized
INFO - 2017-12-22 06:04:29 --> Router Class Initialized
INFO - 2017-12-22 06:04:29 --> Output Class Initialized
INFO - 2017-12-22 06:04:29 --> Security Class Initialized
DEBUG - 2017-12-22 06:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 06:04:29 --> Input Class Initialized
INFO - 2017-12-22 06:04:29 --> Language Class Initialized
INFO - 2017-12-22 06:04:29 --> Loader Class Initialized
INFO - 2017-12-22 06:04:29 --> Helper loaded: url_helper
INFO - 2017-12-22 06:04:29 --> Helper loaded: form_helper
INFO - 2017-12-22 06:04:29 --> Database Driver Class Initialized
DEBUG - 2017-12-22 06:04:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 06:04:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 06:04:29 --> Form Validation Class Initialized
INFO - 2017-12-22 06:04:29 --> Model Class Initialized
INFO - 2017-12-22 06:04:29 --> Controller Class Initialized
INFO - 2017-12-22 06:04:29 --> Model Class Initialized
INFO - 2017-12-22 06:04:29 --> Model Class Initialized
INFO - 2017-12-22 06:04:29 --> Model Class Initialized
DEBUG - 2017-12-22 06:04:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 06:08:17 --> Config Class Initialized
INFO - 2017-12-22 06:08:17 --> Hooks Class Initialized
DEBUG - 2017-12-22 06:08:17 --> UTF-8 Support Enabled
INFO - 2017-12-22 06:08:17 --> Utf8 Class Initialized
INFO - 2017-12-22 06:08:17 --> URI Class Initialized
INFO - 2017-12-22 06:08:17 --> Router Class Initialized
INFO - 2017-12-22 06:08:17 --> Output Class Initialized
INFO - 2017-12-22 06:08:17 --> Security Class Initialized
DEBUG - 2017-12-22 06:08:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 06:08:17 --> Input Class Initialized
INFO - 2017-12-22 06:08:17 --> Language Class Initialized
INFO - 2017-12-22 06:08:17 --> Loader Class Initialized
INFO - 2017-12-22 06:08:17 --> Helper loaded: url_helper
INFO - 2017-12-22 06:08:17 --> Helper loaded: form_helper
INFO - 2017-12-22 06:08:17 --> Database Driver Class Initialized
DEBUG - 2017-12-22 06:08:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 06:08:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 06:08:17 --> Form Validation Class Initialized
INFO - 2017-12-22 06:08:17 --> Model Class Initialized
INFO - 2017-12-22 06:08:17 --> Controller Class Initialized
INFO - 2017-12-22 06:08:17 --> Model Class Initialized
INFO - 2017-12-22 06:08:17 --> Model Class Initialized
INFO - 2017-12-22 06:08:17 --> Model Class Initialized
DEBUG - 2017-12-22 06:08:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 06:08:17 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 06:08:17 --> Final output sent to browser
DEBUG - 2017-12-22 06:08:17 --> Total execution time: 0.0747
INFO - 2017-12-22 06:08:18 --> Config Class Initialized
INFO - 2017-12-22 06:08:18 --> Hooks Class Initialized
DEBUG - 2017-12-22 06:08:18 --> UTF-8 Support Enabled
INFO - 2017-12-22 06:08:18 --> Utf8 Class Initialized
INFO - 2017-12-22 06:08:18 --> URI Class Initialized
INFO - 2017-12-22 06:08:18 --> Router Class Initialized
INFO - 2017-12-22 06:08:18 --> Output Class Initialized
INFO - 2017-12-22 06:08:18 --> Security Class Initialized
DEBUG - 2017-12-22 06:08:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 06:08:18 --> Input Class Initialized
INFO - 2017-12-22 06:08:18 --> Language Class Initialized
ERROR - 2017-12-22 06:08:18 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-22 06:08:18 --> Config Class Initialized
INFO - 2017-12-22 06:08:18 --> Hooks Class Initialized
INFO - 2017-12-22 06:08:18 --> Config Class Initialized
INFO - 2017-12-22 06:08:18 --> Hooks Class Initialized
DEBUG - 2017-12-22 06:08:18 --> UTF-8 Support Enabled
INFO - 2017-12-22 06:08:18 --> Utf8 Class Initialized
DEBUG - 2017-12-22 06:08:18 --> UTF-8 Support Enabled
INFO - 2017-12-22 06:08:18 --> Utf8 Class Initialized
INFO - 2017-12-22 06:08:18 --> URI Class Initialized
INFO - 2017-12-22 06:08:18 --> URI Class Initialized
INFO - 2017-12-22 06:08:18 --> Router Class Initialized
INFO - 2017-12-22 06:08:18 --> Router Class Initialized
INFO - 2017-12-22 06:08:18 --> Output Class Initialized
INFO - 2017-12-22 06:08:18 --> Output Class Initialized
INFO - 2017-12-22 06:08:18 --> Security Class Initialized
INFO - 2017-12-22 06:08:18 --> Security Class Initialized
DEBUG - 2017-12-22 06:08:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 06:08:18 --> Input Class Initialized
DEBUG - 2017-12-22 06:08:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 06:08:18 --> Input Class Initialized
INFO - 2017-12-22 06:08:18 --> Language Class Initialized
INFO - 2017-12-22 06:08:18 --> Language Class Initialized
ERROR - 2017-12-22 06:08:18 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-22 06:08:18 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-22 06:09:02 --> Config Class Initialized
INFO - 2017-12-22 06:09:02 --> Hooks Class Initialized
DEBUG - 2017-12-22 06:09:02 --> UTF-8 Support Enabled
INFO - 2017-12-22 06:09:02 --> Utf8 Class Initialized
INFO - 2017-12-22 06:09:02 --> URI Class Initialized
INFO - 2017-12-22 06:09:02 --> Router Class Initialized
INFO - 2017-12-22 06:09:02 --> Output Class Initialized
INFO - 2017-12-22 06:09:02 --> Security Class Initialized
DEBUG - 2017-12-22 06:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 06:09:02 --> Input Class Initialized
INFO - 2017-12-22 06:09:02 --> Language Class Initialized
INFO - 2017-12-22 06:09:02 --> Loader Class Initialized
INFO - 2017-12-22 06:09:02 --> Helper loaded: url_helper
INFO - 2017-12-22 06:09:02 --> Helper loaded: form_helper
INFO - 2017-12-22 06:09:02 --> Database Driver Class Initialized
DEBUG - 2017-12-22 06:09:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 06:09:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 06:09:02 --> Form Validation Class Initialized
INFO - 2017-12-22 06:09:02 --> Model Class Initialized
INFO - 2017-12-22 06:09:02 --> Controller Class Initialized
INFO - 2017-12-22 06:09:02 --> Model Class Initialized
INFO - 2017-12-22 06:09:02 --> Model Class Initialized
INFO - 2017-12-22 06:09:02 --> Model Class Initialized
DEBUG - 2017-12-22 06:09:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 06:09:02 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 06:09:02 --> Final output sent to browser
DEBUG - 2017-12-22 06:09:02 --> Total execution time: 0.0685
INFO - 2017-12-22 06:09:03 --> Config Class Initialized
INFO - 2017-12-22 06:09:03 --> Hooks Class Initialized
DEBUG - 2017-12-22 06:09:03 --> UTF-8 Support Enabled
INFO - 2017-12-22 06:09:03 --> Utf8 Class Initialized
INFO - 2017-12-22 06:09:03 --> URI Class Initialized
INFO - 2017-12-22 06:09:03 --> Router Class Initialized
INFO - 2017-12-22 06:09:03 --> Output Class Initialized
INFO - 2017-12-22 06:09:03 --> Security Class Initialized
DEBUG - 2017-12-22 06:09:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 06:09:03 --> Input Class Initialized
INFO - 2017-12-22 06:09:03 --> Language Class Initialized
ERROR - 2017-12-22 06:09:03 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-22 06:09:03 --> Config Class Initialized
INFO - 2017-12-22 06:09:03 --> Config Class Initialized
INFO - 2017-12-22 06:09:03 --> Hooks Class Initialized
INFO - 2017-12-22 06:09:03 --> Hooks Class Initialized
DEBUG - 2017-12-22 06:09:03 --> UTF-8 Support Enabled
DEBUG - 2017-12-22 06:09:03 --> UTF-8 Support Enabled
INFO - 2017-12-22 06:09:03 --> Utf8 Class Initialized
INFO - 2017-12-22 06:09:03 --> Utf8 Class Initialized
INFO - 2017-12-22 06:09:03 --> URI Class Initialized
INFO - 2017-12-22 06:09:03 --> URI Class Initialized
INFO - 2017-12-22 06:09:03 --> Router Class Initialized
INFO - 2017-12-22 06:09:03 --> Router Class Initialized
INFO - 2017-12-22 06:09:03 --> Output Class Initialized
INFO - 2017-12-22 06:09:03 --> Output Class Initialized
INFO - 2017-12-22 06:09:03 --> Security Class Initialized
DEBUG - 2017-12-22 06:09:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 06:09:03 --> Security Class Initialized
INFO - 2017-12-22 06:09:03 --> Input Class Initialized
INFO - 2017-12-22 06:09:03 --> Language Class Initialized
DEBUG - 2017-12-22 06:09:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 06:09:03 --> Input Class Initialized
INFO - 2017-12-22 06:09:03 --> Language Class Initialized
ERROR - 2017-12-22 06:09:03 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-22 06:09:03 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-22 06:09:03 --> Config Class Initialized
INFO - 2017-12-22 06:09:03 --> Hooks Class Initialized
DEBUG - 2017-12-22 06:09:03 --> UTF-8 Support Enabled
INFO - 2017-12-22 06:09:03 --> Utf8 Class Initialized
INFO - 2017-12-22 06:09:03 --> URI Class Initialized
INFO - 2017-12-22 06:09:03 --> Router Class Initialized
INFO - 2017-12-22 06:09:03 --> Output Class Initialized
INFO - 2017-12-22 06:09:03 --> Security Class Initialized
DEBUG - 2017-12-22 06:09:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 06:09:03 --> Input Class Initialized
INFO - 2017-12-22 06:09:03 --> Language Class Initialized
INFO - 2017-12-22 06:09:03 --> Loader Class Initialized
INFO - 2017-12-22 06:09:03 --> Helper loaded: url_helper
INFO - 2017-12-22 06:09:03 --> Helper loaded: form_helper
INFO - 2017-12-22 06:09:03 --> Database Driver Class Initialized
DEBUG - 2017-12-22 06:09:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 06:09:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 06:09:03 --> Form Validation Class Initialized
INFO - 2017-12-22 06:09:03 --> Model Class Initialized
INFO - 2017-12-22 06:09:03 --> Controller Class Initialized
INFO - 2017-12-22 06:09:03 --> Model Class Initialized
INFO - 2017-12-22 06:09:03 --> Model Class Initialized
INFO - 2017-12-22 06:09:03 --> Model Class Initialized
DEBUG - 2017-12-22 06:09:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 06:09:32 --> Config Class Initialized
INFO - 2017-12-22 06:09:32 --> Hooks Class Initialized
DEBUG - 2017-12-22 06:09:32 --> UTF-8 Support Enabled
INFO - 2017-12-22 06:09:32 --> Utf8 Class Initialized
INFO - 2017-12-22 06:09:32 --> URI Class Initialized
INFO - 2017-12-22 06:09:32 --> Router Class Initialized
INFO - 2017-12-22 06:09:32 --> Output Class Initialized
INFO - 2017-12-22 06:09:32 --> Security Class Initialized
DEBUG - 2017-12-22 06:09:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 06:09:32 --> Input Class Initialized
INFO - 2017-12-22 06:09:32 --> Language Class Initialized
INFO - 2017-12-22 06:09:32 --> Loader Class Initialized
INFO - 2017-12-22 06:09:32 --> Helper loaded: url_helper
INFO - 2017-12-22 06:09:32 --> Helper loaded: form_helper
INFO - 2017-12-22 06:09:32 --> Database Driver Class Initialized
DEBUG - 2017-12-22 06:09:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 06:09:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 06:09:32 --> Form Validation Class Initialized
INFO - 2017-12-22 06:09:32 --> Model Class Initialized
INFO - 2017-12-22 06:09:32 --> Controller Class Initialized
INFO - 2017-12-22 06:09:32 --> Model Class Initialized
INFO - 2017-12-22 06:09:32 --> Model Class Initialized
INFO - 2017-12-22 06:09:32 --> Model Class Initialized
DEBUG - 2017-12-22 06:09:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 06:09:32 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 06:09:32 --> Final output sent to browser
DEBUG - 2017-12-22 06:09:32 --> Total execution time: 0.0470
INFO - 2017-12-22 06:09:33 --> Config Class Initialized
INFO - 2017-12-22 06:09:33 --> Hooks Class Initialized
DEBUG - 2017-12-22 06:09:33 --> UTF-8 Support Enabled
INFO - 2017-12-22 06:09:33 --> Utf8 Class Initialized
INFO - 2017-12-22 06:09:33 --> URI Class Initialized
INFO - 2017-12-22 06:09:33 --> Router Class Initialized
INFO - 2017-12-22 06:09:33 --> Output Class Initialized
INFO - 2017-12-22 06:09:33 --> Security Class Initialized
DEBUG - 2017-12-22 06:09:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 06:09:33 --> Input Class Initialized
INFO - 2017-12-22 06:09:33 --> Language Class Initialized
ERROR - 2017-12-22 06:09:33 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-22 06:09:33 --> Config Class Initialized
INFO - 2017-12-22 06:09:33 --> Hooks Class Initialized
INFO - 2017-12-22 06:09:33 --> Config Class Initialized
INFO - 2017-12-22 06:09:33 --> Hooks Class Initialized
DEBUG - 2017-12-22 06:09:33 --> UTF-8 Support Enabled
INFO - 2017-12-22 06:09:33 --> Utf8 Class Initialized
DEBUG - 2017-12-22 06:09:33 --> UTF-8 Support Enabled
INFO - 2017-12-22 06:09:33 --> URI Class Initialized
INFO - 2017-12-22 06:09:33 --> Utf8 Class Initialized
INFO - 2017-12-22 06:09:33 --> URI Class Initialized
INFO - 2017-12-22 06:09:33 --> Router Class Initialized
INFO - 2017-12-22 06:09:33 --> Output Class Initialized
INFO - 2017-12-22 06:09:33 --> Router Class Initialized
INFO - 2017-12-22 06:09:33 --> Security Class Initialized
INFO - 2017-12-22 06:09:33 --> Output Class Initialized
DEBUG - 2017-12-22 06:09:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 06:09:33 --> Input Class Initialized
INFO - 2017-12-22 06:09:33 --> Language Class Initialized
INFO - 2017-12-22 06:09:33 --> Security Class Initialized
DEBUG - 2017-12-22 06:09:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2017-12-22 06:09:33 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-22 06:09:33 --> Input Class Initialized
INFO - 2017-12-22 06:09:33 --> Language Class Initialized
ERROR - 2017-12-22 06:09:33 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-22 06:09:33 --> Config Class Initialized
INFO - 2017-12-22 06:09:33 --> Hooks Class Initialized
DEBUG - 2017-12-22 06:09:33 --> UTF-8 Support Enabled
INFO - 2017-12-22 06:09:33 --> Utf8 Class Initialized
INFO - 2017-12-22 06:09:33 --> URI Class Initialized
INFO - 2017-12-22 06:09:33 --> Router Class Initialized
INFO - 2017-12-22 06:09:33 --> Output Class Initialized
INFO - 2017-12-22 06:09:33 --> Security Class Initialized
DEBUG - 2017-12-22 06:09:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 06:09:33 --> Input Class Initialized
INFO - 2017-12-22 06:09:33 --> Language Class Initialized
INFO - 2017-12-22 06:09:33 --> Loader Class Initialized
INFO - 2017-12-22 06:09:33 --> Helper loaded: url_helper
INFO - 2017-12-22 06:09:33 --> Helper loaded: form_helper
INFO - 2017-12-22 06:09:33 --> Database Driver Class Initialized
DEBUG - 2017-12-22 06:09:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 06:09:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 06:09:33 --> Form Validation Class Initialized
INFO - 2017-12-22 06:09:33 --> Model Class Initialized
INFO - 2017-12-22 06:09:33 --> Controller Class Initialized
INFO - 2017-12-22 06:09:33 --> Model Class Initialized
INFO - 2017-12-22 06:09:33 --> Model Class Initialized
INFO - 2017-12-22 06:09:33 --> Model Class Initialized
DEBUG - 2017-12-22 06:09:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 06:09:45 --> Config Class Initialized
INFO - 2017-12-22 06:09:45 --> Hooks Class Initialized
DEBUG - 2017-12-22 06:09:45 --> UTF-8 Support Enabled
INFO - 2017-12-22 06:09:45 --> Utf8 Class Initialized
INFO - 2017-12-22 06:09:45 --> URI Class Initialized
INFO - 2017-12-22 06:09:45 --> Router Class Initialized
INFO - 2017-12-22 06:09:45 --> Output Class Initialized
INFO - 2017-12-22 06:09:45 --> Security Class Initialized
DEBUG - 2017-12-22 06:09:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 06:09:45 --> Input Class Initialized
INFO - 2017-12-22 06:09:45 --> Language Class Initialized
INFO - 2017-12-22 06:09:45 --> Loader Class Initialized
INFO - 2017-12-22 06:09:45 --> Helper loaded: url_helper
INFO - 2017-12-22 06:09:45 --> Helper loaded: form_helper
INFO - 2017-12-22 06:09:45 --> Database Driver Class Initialized
DEBUG - 2017-12-22 06:09:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 06:09:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 06:09:45 --> Form Validation Class Initialized
INFO - 2017-12-22 06:09:45 --> Model Class Initialized
INFO - 2017-12-22 06:09:45 --> Controller Class Initialized
INFO - 2017-12-22 06:09:45 --> Model Class Initialized
INFO - 2017-12-22 06:09:45 --> Model Class Initialized
INFO - 2017-12-22 06:09:45 --> Model Class Initialized
DEBUG - 2017-12-22 06:09:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 06:09:45 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 06:09:45 --> Final output sent to browser
DEBUG - 2017-12-22 06:09:45 --> Total execution time: 0.0700
INFO - 2017-12-22 06:09:46 --> Config Class Initialized
INFO - 2017-12-22 06:09:46 --> Hooks Class Initialized
DEBUG - 2017-12-22 06:09:46 --> UTF-8 Support Enabled
INFO - 2017-12-22 06:09:46 --> Utf8 Class Initialized
INFO - 2017-12-22 06:09:46 --> URI Class Initialized
INFO - 2017-12-22 06:09:46 --> Router Class Initialized
INFO - 2017-12-22 06:09:46 --> Output Class Initialized
INFO - 2017-12-22 06:09:46 --> Security Class Initialized
DEBUG - 2017-12-22 06:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 06:09:46 --> Input Class Initialized
INFO - 2017-12-22 06:09:46 --> Language Class Initialized
ERROR - 2017-12-22 06:09:46 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-22 06:09:46 --> Config Class Initialized
INFO - 2017-12-22 06:09:46 --> Config Class Initialized
INFO - 2017-12-22 06:09:46 --> Hooks Class Initialized
INFO - 2017-12-22 06:09:46 --> Hooks Class Initialized
DEBUG - 2017-12-22 06:09:46 --> UTF-8 Support Enabled
DEBUG - 2017-12-22 06:09:46 --> UTF-8 Support Enabled
INFO - 2017-12-22 06:09:46 --> Utf8 Class Initialized
INFO - 2017-12-22 06:09:46 --> Utf8 Class Initialized
INFO - 2017-12-22 06:09:46 --> URI Class Initialized
INFO - 2017-12-22 06:09:46 --> URI Class Initialized
INFO - 2017-12-22 06:09:46 --> Router Class Initialized
INFO - 2017-12-22 06:09:46 --> Router Class Initialized
INFO - 2017-12-22 06:09:46 --> Output Class Initialized
INFO - 2017-12-22 06:09:46 --> Output Class Initialized
INFO - 2017-12-22 06:09:46 --> Security Class Initialized
INFO - 2017-12-22 06:09:46 --> Security Class Initialized
DEBUG - 2017-12-22 06:09:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-22 06:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 06:09:46 --> Input Class Initialized
INFO - 2017-12-22 06:09:46 --> Input Class Initialized
INFO - 2017-12-22 06:09:46 --> Language Class Initialized
INFO - 2017-12-22 06:09:46 --> Language Class Initialized
ERROR - 2017-12-22 06:09:46 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-22 06:09:46 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-22 06:09:46 --> Config Class Initialized
INFO - 2017-12-22 06:09:46 --> Hooks Class Initialized
DEBUG - 2017-12-22 06:09:46 --> UTF-8 Support Enabled
INFO - 2017-12-22 06:09:46 --> Utf8 Class Initialized
INFO - 2017-12-22 06:09:46 --> URI Class Initialized
INFO - 2017-12-22 06:09:46 --> Router Class Initialized
INFO - 2017-12-22 06:09:46 --> Output Class Initialized
INFO - 2017-12-22 06:09:46 --> Security Class Initialized
DEBUG - 2017-12-22 06:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 06:09:46 --> Input Class Initialized
INFO - 2017-12-22 06:09:46 --> Language Class Initialized
INFO - 2017-12-22 06:09:46 --> Loader Class Initialized
INFO - 2017-12-22 06:09:46 --> Helper loaded: url_helper
INFO - 2017-12-22 06:09:46 --> Helper loaded: form_helper
INFO - 2017-12-22 06:09:46 --> Database Driver Class Initialized
DEBUG - 2017-12-22 06:09:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 06:09:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 06:09:46 --> Form Validation Class Initialized
INFO - 2017-12-22 06:09:46 --> Model Class Initialized
INFO - 2017-12-22 06:09:46 --> Controller Class Initialized
INFO - 2017-12-22 06:09:46 --> Model Class Initialized
INFO - 2017-12-22 06:09:46 --> Model Class Initialized
INFO - 2017-12-22 06:09:46 --> Model Class Initialized
DEBUG - 2017-12-22 06:09:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 06:10:29 --> Config Class Initialized
INFO - 2017-12-22 06:10:29 --> Hooks Class Initialized
DEBUG - 2017-12-22 06:10:29 --> UTF-8 Support Enabled
INFO - 2017-12-22 06:10:29 --> Utf8 Class Initialized
INFO - 2017-12-22 06:10:29 --> URI Class Initialized
INFO - 2017-12-22 06:10:29 --> Router Class Initialized
INFO - 2017-12-22 06:10:29 --> Output Class Initialized
INFO - 2017-12-22 06:10:29 --> Security Class Initialized
DEBUG - 2017-12-22 06:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 06:10:29 --> Input Class Initialized
INFO - 2017-12-22 06:10:29 --> Language Class Initialized
INFO - 2017-12-22 06:10:29 --> Loader Class Initialized
INFO - 2017-12-22 06:10:29 --> Helper loaded: url_helper
INFO - 2017-12-22 06:10:29 --> Helper loaded: form_helper
INFO - 2017-12-22 06:10:29 --> Database Driver Class Initialized
DEBUG - 2017-12-22 06:10:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 06:10:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 06:10:29 --> Form Validation Class Initialized
INFO - 2017-12-22 06:10:29 --> Model Class Initialized
INFO - 2017-12-22 06:10:29 --> Controller Class Initialized
INFO - 2017-12-22 06:10:29 --> Model Class Initialized
INFO - 2017-12-22 06:10:29 --> Model Class Initialized
INFO - 2017-12-22 06:10:29 --> Model Class Initialized
DEBUG - 2017-12-22 06:10:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 06:10:29 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 06:10:29 --> Final output sent to browser
DEBUG - 2017-12-22 06:10:29 --> Total execution time: 0.0549
INFO - 2017-12-22 06:10:29 --> Config Class Initialized
INFO - 2017-12-22 06:10:29 --> Hooks Class Initialized
DEBUG - 2017-12-22 06:10:29 --> UTF-8 Support Enabled
INFO - 2017-12-22 06:10:29 --> Utf8 Class Initialized
INFO - 2017-12-22 06:10:29 --> URI Class Initialized
INFO - 2017-12-22 06:10:29 --> Router Class Initialized
INFO - 2017-12-22 06:10:29 --> Output Class Initialized
INFO - 2017-12-22 06:10:29 --> Security Class Initialized
DEBUG - 2017-12-22 06:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 06:10:29 --> Input Class Initialized
INFO - 2017-12-22 06:10:29 --> Language Class Initialized
ERROR - 2017-12-22 06:10:29 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-22 06:10:29 --> Config Class Initialized
INFO - 2017-12-22 06:10:29 --> Config Class Initialized
INFO - 2017-12-22 06:10:29 --> Hooks Class Initialized
INFO - 2017-12-22 06:10:29 --> Hooks Class Initialized
DEBUG - 2017-12-22 06:10:29 --> UTF-8 Support Enabled
INFO - 2017-12-22 06:10:29 --> Utf8 Class Initialized
DEBUG - 2017-12-22 06:10:29 --> UTF-8 Support Enabled
INFO - 2017-12-22 06:10:29 --> Utf8 Class Initialized
INFO - 2017-12-22 06:10:29 --> URI Class Initialized
INFO - 2017-12-22 06:10:29 --> URI Class Initialized
INFO - 2017-12-22 06:10:29 --> Router Class Initialized
INFO - 2017-12-22 06:10:29 --> Router Class Initialized
INFO - 2017-12-22 06:10:29 --> Output Class Initialized
INFO - 2017-12-22 06:10:29 --> Output Class Initialized
INFO - 2017-12-22 06:10:29 --> Security Class Initialized
INFO - 2017-12-22 06:10:29 --> Security Class Initialized
DEBUG - 2017-12-22 06:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 06:10:29 --> Input Class Initialized
DEBUG - 2017-12-22 06:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 06:10:29 --> Input Class Initialized
INFO - 2017-12-22 06:10:29 --> Language Class Initialized
INFO - 2017-12-22 06:10:29 --> Language Class Initialized
ERROR - 2017-12-22 06:10:29 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-22 06:10:29 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-22 06:10:29 --> Config Class Initialized
INFO - 2017-12-22 06:10:29 --> Hooks Class Initialized
DEBUG - 2017-12-22 06:10:29 --> UTF-8 Support Enabled
INFO - 2017-12-22 06:10:29 --> Utf8 Class Initialized
INFO - 2017-12-22 06:10:29 --> URI Class Initialized
INFO - 2017-12-22 06:10:29 --> Router Class Initialized
INFO - 2017-12-22 06:10:29 --> Output Class Initialized
INFO - 2017-12-22 06:10:29 --> Security Class Initialized
DEBUG - 2017-12-22 06:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 06:10:29 --> Input Class Initialized
INFO - 2017-12-22 06:10:29 --> Language Class Initialized
INFO - 2017-12-22 06:10:29 --> Loader Class Initialized
INFO - 2017-12-22 06:10:29 --> Helper loaded: url_helper
INFO - 2017-12-22 06:10:29 --> Helper loaded: form_helper
INFO - 2017-12-22 06:10:29 --> Database Driver Class Initialized
DEBUG - 2017-12-22 06:10:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 06:10:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 06:10:29 --> Form Validation Class Initialized
INFO - 2017-12-22 06:10:29 --> Model Class Initialized
INFO - 2017-12-22 06:10:29 --> Controller Class Initialized
INFO - 2017-12-22 06:10:29 --> Model Class Initialized
INFO - 2017-12-22 06:10:29 --> Model Class Initialized
INFO - 2017-12-22 06:10:29 --> Model Class Initialized
DEBUG - 2017-12-22 06:10:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 06:16:19 --> Config Class Initialized
INFO - 2017-12-22 06:16:19 --> Hooks Class Initialized
DEBUG - 2017-12-22 06:16:19 --> UTF-8 Support Enabled
INFO - 2017-12-22 06:16:19 --> Utf8 Class Initialized
INFO - 2017-12-22 06:16:19 --> URI Class Initialized
INFO - 2017-12-22 06:16:19 --> Router Class Initialized
INFO - 2017-12-22 06:16:19 --> Output Class Initialized
INFO - 2017-12-22 06:16:19 --> Security Class Initialized
DEBUG - 2017-12-22 06:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 06:16:19 --> Input Class Initialized
INFO - 2017-12-22 06:16:19 --> Language Class Initialized
INFO - 2017-12-22 06:16:19 --> Loader Class Initialized
INFO - 2017-12-22 06:16:19 --> Helper loaded: url_helper
INFO - 2017-12-22 06:16:19 --> Helper loaded: form_helper
INFO - 2017-12-22 06:16:19 --> Database Driver Class Initialized
DEBUG - 2017-12-22 06:16:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 06:16:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 06:16:19 --> Form Validation Class Initialized
INFO - 2017-12-22 06:16:19 --> Model Class Initialized
INFO - 2017-12-22 06:16:19 --> Controller Class Initialized
INFO - 2017-12-22 06:16:19 --> Model Class Initialized
INFO - 2017-12-22 06:16:19 --> Model Class Initialized
INFO - 2017-12-22 06:16:19 --> Model Class Initialized
DEBUG - 2017-12-22 06:16:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 06:16:19 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 06:16:19 --> Final output sent to browser
DEBUG - 2017-12-22 06:16:19 --> Total execution time: 0.0940
INFO - 2017-12-22 06:16:19 --> Config Class Initialized
INFO - 2017-12-22 06:16:19 --> Hooks Class Initialized
DEBUG - 2017-12-22 06:16:19 --> UTF-8 Support Enabled
INFO - 2017-12-22 06:16:19 --> Utf8 Class Initialized
INFO - 2017-12-22 06:16:19 --> URI Class Initialized
INFO - 2017-12-22 06:16:19 --> Router Class Initialized
INFO - 2017-12-22 06:16:19 --> Output Class Initialized
INFO - 2017-12-22 06:16:19 --> Security Class Initialized
DEBUG - 2017-12-22 06:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 06:16:19 --> Input Class Initialized
INFO - 2017-12-22 06:16:19 --> Language Class Initialized
ERROR - 2017-12-22 06:16:19 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-22 06:16:19 --> Config Class Initialized
INFO - 2017-12-22 06:16:19 --> Config Class Initialized
INFO - 2017-12-22 06:16:19 --> Hooks Class Initialized
INFO - 2017-12-22 06:16:19 --> Hooks Class Initialized
DEBUG - 2017-12-22 06:16:19 --> UTF-8 Support Enabled
DEBUG - 2017-12-22 06:16:19 --> UTF-8 Support Enabled
INFO - 2017-12-22 06:16:19 --> Utf8 Class Initialized
INFO - 2017-12-22 06:16:19 --> Utf8 Class Initialized
INFO - 2017-12-22 06:16:19 --> URI Class Initialized
INFO - 2017-12-22 06:16:19 --> URI Class Initialized
INFO - 2017-12-22 06:16:19 --> Router Class Initialized
INFO - 2017-12-22 06:16:19 --> Router Class Initialized
INFO - 2017-12-22 06:16:19 --> Output Class Initialized
INFO - 2017-12-22 06:16:19 --> Output Class Initialized
INFO - 2017-12-22 06:16:19 --> Security Class Initialized
INFO - 2017-12-22 06:16:19 --> Security Class Initialized
DEBUG - 2017-12-22 06:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 06:16:19 --> Input Class Initialized
INFO - 2017-12-22 06:16:19 --> Language Class Initialized
DEBUG - 2017-12-22 06:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 06:16:19 --> Input Class Initialized
INFO - 2017-12-22 06:16:19 --> Language Class Initialized
ERROR - 2017-12-22 06:16:19 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-22 06:16:19 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-22 06:16:19 --> Config Class Initialized
INFO - 2017-12-22 06:16:19 --> Hooks Class Initialized
DEBUG - 2017-12-22 06:16:19 --> UTF-8 Support Enabled
INFO - 2017-12-22 06:16:19 --> Utf8 Class Initialized
INFO - 2017-12-22 06:16:19 --> URI Class Initialized
INFO - 2017-12-22 06:16:19 --> Router Class Initialized
INFO - 2017-12-22 06:16:19 --> Output Class Initialized
INFO - 2017-12-22 06:16:19 --> Security Class Initialized
DEBUG - 2017-12-22 06:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 06:16:19 --> Input Class Initialized
INFO - 2017-12-22 06:16:19 --> Language Class Initialized
INFO - 2017-12-22 06:16:19 --> Loader Class Initialized
INFO - 2017-12-22 06:16:19 --> Helper loaded: url_helper
INFO - 2017-12-22 06:16:19 --> Helper loaded: form_helper
INFO - 2017-12-22 06:16:19 --> Database Driver Class Initialized
DEBUG - 2017-12-22 06:16:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 06:16:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 06:16:19 --> Form Validation Class Initialized
INFO - 2017-12-22 06:16:19 --> Model Class Initialized
INFO - 2017-12-22 06:16:19 --> Controller Class Initialized
INFO - 2017-12-22 06:16:19 --> Model Class Initialized
INFO - 2017-12-22 06:16:19 --> Model Class Initialized
INFO - 2017-12-22 06:16:19 --> Model Class Initialized
DEBUG - 2017-12-22 06:16:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 06:21:11 --> Config Class Initialized
INFO - 2017-12-22 06:21:11 --> Hooks Class Initialized
DEBUG - 2017-12-22 06:21:11 --> UTF-8 Support Enabled
INFO - 2017-12-22 06:21:11 --> Utf8 Class Initialized
INFO - 2017-12-22 06:21:11 --> URI Class Initialized
INFO - 2017-12-22 06:21:11 --> Router Class Initialized
INFO - 2017-12-22 06:21:11 --> Output Class Initialized
INFO - 2017-12-22 06:21:11 --> Security Class Initialized
DEBUG - 2017-12-22 06:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 06:21:11 --> Input Class Initialized
INFO - 2017-12-22 06:21:11 --> Language Class Initialized
INFO - 2017-12-22 06:21:11 --> Loader Class Initialized
INFO - 2017-12-22 06:21:11 --> Helper loaded: url_helper
INFO - 2017-12-22 06:21:11 --> Helper loaded: form_helper
INFO - 2017-12-22 06:21:11 --> Database Driver Class Initialized
DEBUG - 2017-12-22 06:21:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 06:21:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 06:21:11 --> Form Validation Class Initialized
INFO - 2017-12-22 06:21:11 --> Model Class Initialized
INFO - 2017-12-22 06:21:11 --> Controller Class Initialized
INFO - 2017-12-22 06:21:11 --> Model Class Initialized
INFO - 2017-12-22 06:21:11 --> Model Class Initialized
INFO - 2017-12-22 06:21:11 --> Model Class Initialized
DEBUG - 2017-12-22 06:21:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 06:21:11 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 06:21:11 --> Final output sent to browser
DEBUG - 2017-12-22 06:21:11 --> Total execution time: 0.0479
INFO - 2017-12-22 06:21:11 --> Config Class Initialized
INFO - 2017-12-22 06:21:11 --> Hooks Class Initialized
DEBUG - 2017-12-22 06:21:11 --> UTF-8 Support Enabled
INFO - 2017-12-22 06:21:11 --> Utf8 Class Initialized
INFO - 2017-12-22 06:21:11 --> URI Class Initialized
INFO - 2017-12-22 06:21:11 --> Router Class Initialized
INFO - 2017-12-22 06:21:11 --> Output Class Initialized
INFO - 2017-12-22 06:21:11 --> Security Class Initialized
DEBUG - 2017-12-22 06:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 06:21:11 --> Input Class Initialized
INFO - 2017-12-22 06:21:11 --> Language Class Initialized
ERROR - 2017-12-22 06:21:11 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-22 06:21:11 --> Config Class Initialized
INFO - 2017-12-22 06:21:11 --> Hooks Class Initialized
INFO - 2017-12-22 06:21:11 --> Config Class Initialized
INFO - 2017-12-22 06:21:11 --> Hooks Class Initialized
DEBUG - 2017-12-22 06:21:11 --> UTF-8 Support Enabled
INFO - 2017-12-22 06:21:11 --> Utf8 Class Initialized
DEBUG - 2017-12-22 06:21:11 --> UTF-8 Support Enabled
INFO - 2017-12-22 06:21:11 --> Utf8 Class Initialized
INFO - 2017-12-22 06:21:11 --> URI Class Initialized
INFO - 2017-12-22 06:21:11 --> URI Class Initialized
INFO - 2017-12-22 06:21:11 --> Router Class Initialized
INFO - 2017-12-22 06:21:11 --> Router Class Initialized
INFO - 2017-12-22 06:21:11 --> Output Class Initialized
INFO - 2017-12-22 06:21:11 --> Output Class Initialized
INFO - 2017-12-22 06:21:11 --> Security Class Initialized
INFO - 2017-12-22 06:21:11 --> Security Class Initialized
DEBUG - 2017-12-22 06:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 06:21:11 --> Input Class Initialized
DEBUG - 2017-12-22 06:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 06:21:11 --> Input Class Initialized
INFO - 2017-12-22 06:21:11 --> Language Class Initialized
INFO - 2017-12-22 06:21:11 --> Language Class Initialized
ERROR - 2017-12-22 06:21:11 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-22 06:21:11 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-22 06:21:11 --> Config Class Initialized
INFO - 2017-12-22 06:21:11 --> Hooks Class Initialized
DEBUG - 2017-12-22 06:21:11 --> UTF-8 Support Enabled
INFO - 2017-12-22 06:21:11 --> Utf8 Class Initialized
INFO - 2017-12-22 06:21:11 --> URI Class Initialized
INFO - 2017-12-22 06:21:11 --> Router Class Initialized
INFO - 2017-12-22 06:21:11 --> Output Class Initialized
INFO - 2017-12-22 06:21:11 --> Security Class Initialized
DEBUG - 2017-12-22 06:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 06:21:11 --> Input Class Initialized
INFO - 2017-12-22 06:21:11 --> Language Class Initialized
INFO - 2017-12-22 06:21:11 --> Loader Class Initialized
INFO - 2017-12-22 06:21:11 --> Helper loaded: url_helper
INFO - 2017-12-22 06:21:11 --> Helper loaded: form_helper
INFO - 2017-12-22 06:21:11 --> Database Driver Class Initialized
DEBUG - 2017-12-22 06:21:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 06:21:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 06:21:11 --> Form Validation Class Initialized
INFO - 2017-12-22 06:21:11 --> Model Class Initialized
INFO - 2017-12-22 06:21:11 --> Controller Class Initialized
INFO - 2017-12-22 06:21:11 --> Model Class Initialized
INFO - 2017-12-22 06:21:11 --> Model Class Initialized
INFO - 2017-12-22 06:21:11 --> Model Class Initialized
DEBUG - 2017-12-22 06:21:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 06:21:32 --> Config Class Initialized
INFO - 2017-12-22 06:21:32 --> Hooks Class Initialized
DEBUG - 2017-12-22 06:21:32 --> UTF-8 Support Enabled
INFO - 2017-12-22 06:21:32 --> Utf8 Class Initialized
INFO - 2017-12-22 06:21:32 --> URI Class Initialized
INFO - 2017-12-22 06:21:32 --> Router Class Initialized
INFO - 2017-12-22 06:21:32 --> Output Class Initialized
INFO - 2017-12-22 06:21:32 --> Security Class Initialized
DEBUG - 2017-12-22 06:21:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 06:21:32 --> Input Class Initialized
INFO - 2017-12-22 06:21:32 --> Language Class Initialized
INFO - 2017-12-22 06:21:32 --> Loader Class Initialized
INFO - 2017-12-22 06:21:32 --> Helper loaded: url_helper
INFO - 2017-12-22 06:21:32 --> Helper loaded: form_helper
INFO - 2017-12-22 06:21:32 --> Database Driver Class Initialized
DEBUG - 2017-12-22 06:21:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 06:21:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 06:21:33 --> Form Validation Class Initialized
INFO - 2017-12-22 06:21:33 --> Model Class Initialized
INFO - 2017-12-22 06:21:33 --> Controller Class Initialized
INFO - 2017-12-22 06:21:33 --> Model Class Initialized
INFO - 2017-12-22 06:21:33 --> Model Class Initialized
INFO - 2017-12-22 06:21:33 --> Model Class Initialized
DEBUG - 2017-12-22 06:21:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 06:21:33 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 06:21:33 --> Final output sent to browser
DEBUG - 2017-12-22 06:21:33 --> Total execution time: 0.0640
INFO - 2017-12-22 06:21:33 --> Config Class Initialized
INFO - 2017-12-22 06:21:33 --> Hooks Class Initialized
DEBUG - 2017-12-22 06:21:33 --> UTF-8 Support Enabled
INFO - 2017-12-22 06:21:33 --> Utf8 Class Initialized
INFO - 2017-12-22 06:21:33 --> URI Class Initialized
INFO - 2017-12-22 06:21:33 --> Router Class Initialized
INFO - 2017-12-22 06:21:33 --> Output Class Initialized
INFO - 2017-12-22 06:21:33 --> Security Class Initialized
DEBUG - 2017-12-22 06:21:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 06:21:33 --> Input Class Initialized
INFO - 2017-12-22 06:21:33 --> Language Class Initialized
ERROR - 2017-12-22 06:21:33 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-22 06:21:33 --> Config Class Initialized
INFO - 2017-12-22 06:21:33 --> Hooks Class Initialized
INFO - 2017-12-22 06:21:33 --> Config Class Initialized
INFO - 2017-12-22 06:21:33 --> Hooks Class Initialized
DEBUG - 2017-12-22 06:21:33 --> UTF-8 Support Enabled
DEBUG - 2017-12-22 06:21:33 --> UTF-8 Support Enabled
INFO - 2017-12-22 06:21:33 --> Utf8 Class Initialized
INFO - 2017-12-22 06:21:33 --> Utf8 Class Initialized
INFO - 2017-12-22 06:21:33 --> URI Class Initialized
INFO - 2017-12-22 06:21:33 --> URI Class Initialized
INFO - 2017-12-22 06:21:33 --> Router Class Initialized
INFO - 2017-12-22 06:21:33 --> Router Class Initialized
INFO - 2017-12-22 06:21:33 --> Output Class Initialized
INFO - 2017-12-22 06:21:33 --> Output Class Initialized
INFO - 2017-12-22 06:21:33 --> Security Class Initialized
INFO - 2017-12-22 06:21:33 --> Security Class Initialized
DEBUG - 2017-12-22 06:21:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-22 06:21:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 06:21:33 --> Input Class Initialized
INFO - 2017-12-22 06:21:33 --> Input Class Initialized
INFO - 2017-12-22 06:21:33 --> Language Class Initialized
INFO - 2017-12-22 06:21:33 --> Language Class Initialized
ERROR - 2017-12-22 06:21:33 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-22 06:21:33 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-22 06:21:33 --> Config Class Initialized
INFO - 2017-12-22 06:21:33 --> Hooks Class Initialized
DEBUG - 2017-12-22 06:21:33 --> UTF-8 Support Enabled
INFO - 2017-12-22 06:21:33 --> Utf8 Class Initialized
INFO - 2017-12-22 06:21:33 --> URI Class Initialized
INFO - 2017-12-22 06:21:33 --> Router Class Initialized
INFO - 2017-12-22 06:21:33 --> Output Class Initialized
INFO - 2017-12-22 06:21:33 --> Security Class Initialized
DEBUG - 2017-12-22 06:21:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 06:21:33 --> Input Class Initialized
INFO - 2017-12-22 06:21:33 --> Language Class Initialized
INFO - 2017-12-22 06:21:33 --> Loader Class Initialized
INFO - 2017-12-22 06:21:33 --> Helper loaded: url_helper
INFO - 2017-12-22 06:21:33 --> Helper loaded: form_helper
INFO - 2017-12-22 06:21:33 --> Database Driver Class Initialized
DEBUG - 2017-12-22 06:21:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 06:21:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 06:21:33 --> Form Validation Class Initialized
INFO - 2017-12-22 06:21:33 --> Model Class Initialized
INFO - 2017-12-22 06:21:33 --> Controller Class Initialized
INFO - 2017-12-22 06:21:33 --> Model Class Initialized
INFO - 2017-12-22 06:21:33 --> Model Class Initialized
INFO - 2017-12-22 06:21:33 --> Model Class Initialized
DEBUG - 2017-12-22 06:21:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 06:22:18 --> Config Class Initialized
INFO - 2017-12-22 06:22:18 --> Hooks Class Initialized
DEBUG - 2017-12-22 06:22:18 --> UTF-8 Support Enabled
INFO - 2017-12-22 06:22:18 --> Utf8 Class Initialized
INFO - 2017-12-22 06:22:18 --> URI Class Initialized
INFO - 2017-12-22 06:22:18 --> Router Class Initialized
INFO - 2017-12-22 06:22:18 --> Output Class Initialized
INFO - 2017-12-22 06:22:18 --> Security Class Initialized
DEBUG - 2017-12-22 06:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 06:22:18 --> Input Class Initialized
INFO - 2017-12-22 06:22:18 --> Language Class Initialized
INFO - 2017-12-22 06:22:18 --> Loader Class Initialized
INFO - 2017-12-22 06:22:18 --> Helper loaded: url_helper
INFO - 2017-12-22 06:22:18 --> Helper loaded: form_helper
INFO - 2017-12-22 06:22:18 --> Database Driver Class Initialized
DEBUG - 2017-12-22 06:22:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 06:22:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 06:22:18 --> Form Validation Class Initialized
INFO - 2017-12-22 06:22:18 --> Model Class Initialized
INFO - 2017-12-22 06:22:18 --> Controller Class Initialized
INFO - 2017-12-22 06:22:18 --> Model Class Initialized
INFO - 2017-12-22 06:22:18 --> Model Class Initialized
INFO - 2017-12-22 06:22:18 --> Model Class Initialized
DEBUG - 2017-12-22 06:22:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 06:22:18 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 06:22:18 --> Final output sent to browser
DEBUG - 2017-12-22 06:22:18 --> Total execution time: 0.0507
INFO - 2017-12-22 06:22:18 --> Config Class Initialized
INFO - 2017-12-22 06:22:18 --> Hooks Class Initialized
DEBUG - 2017-12-22 06:22:18 --> UTF-8 Support Enabled
INFO - 2017-12-22 06:22:18 --> Utf8 Class Initialized
INFO - 2017-12-22 06:22:18 --> URI Class Initialized
INFO - 2017-12-22 06:22:18 --> Router Class Initialized
INFO - 2017-12-22 06:22:18 --> Output Class Initialized
INFO - 2017-12-22 06:22:18 --> Security Class Initialized
DEBUG - 2017-12-22 06:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 06:22:18 --> Input Class Initialized
INFO - 2017-12-22 06:22:18 --> Language Class Initialized
ERROR - 2017-12-22 06:22:18 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-22 06:22:18 --> Config Class Initialized
INFO - 2017-12-22 06:22:18 --> Config Class Initialized
INFO - 2017-12-22 06:22:18 --> Hooks Class Initialized
INFO - 2017-12-22 06:22:18 --> Hooks Class Initialized
DEBUG - 2017-12-22 06:22:18 --> UTF-8 Support Enabled
INFO - 2017-12-22 06:22:18 --> Utf8 Class Initialized
DEBUG - 2017-12-22 06:22:18 --> UTF-8 Support Enabled
INFO - 2017-12-22 06:22:18 --> Utf8 Class Initialized
INFO - 2017-12-22 06:22:18 --> URI Class Initialized
INFO - 2017-12-22 06:22:18 --> URI Class Initialized
INFO - 2017-12-22 06:22:18 --> Router Class Initialized
INFO - 2017-12-22 06:22:18 --> Router Class Initialized
INFO - 2017-12-22 06:22:18 --> Output Class Initialized
INFO - 2017-12-22 06:22:18 --> Output Class Initialized
INFO - 2017-12-22 06:22:18 --> Security Class Initialized
INFO - 2017-12-22 06:22:18 --> Security Class Initialized
DEBUG - 2017-12-22 06:22:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-22 06:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 06:22:18 --> Input Class Initialized
INFO - 2017-12-22 06:22:18 --> Input Class Initialized
INFO - 2017-12-22 06:22:18 --> Language Class Initialized
INFO - 2017-12-22 06:22:18 --> Language Class Initialized
ERROR - 2017-12-22 06:22:18 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-22 06:22:18 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-22 06:22:18 --> Config Class Initialized
INFO - 2017-12-22 06:22:18 --> Hooks Class Initialized
DEBUG - 2017-12-22 06:22:18 --> UTF-8 Support Enabled
INFO - 2017-12-22 06:22:18 --> Utf8 Class Initialized
INFO - 2017-12-22 06:22:18 --> URI Class Initialized
INFO - 2017-12-22 06:22:18 --> Router Class Initialized
INFO - 2017-12-22 06:22:18 --> Output Class Initialized
INFO - 2017-12-22 06:22:18 --> Security Class Initialized
DEBUG - 2017-12-22 06:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 06:22:18 --> Input Class Initialized
INFO - 2017-12-22 06:22:18 --> Language Class Initialized
INFO - 2017-12-22 06:22:18 --> Loader Class Initialized
INFO - 2017-12-22 06:22:18 --> Helper loaded: url_helper
INFO - 2017-12-22 06:22:18 --> Helper loaded: form_helper
INFO - 2017-12-22 06:22:18 --> Database Driver Class Initialized
DEBUG - 2017-12-22 06:22:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 06:22:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 06:22:18 --> Form Validation Class Initialized
INFO - 2017-12-22 06:22:18 --> Model Class Initialized
INFO - 2017-12-22 06:22:18 --> Controller Class Initialized
INFO - 2017-12-22 06:22:18 --> Model Class Initialized
INFO - 2017-12-22 06:22:18 --> Model Class Initialized
INFO - 2017-12-22 06:22:18 --> Model Class Initialized
DEBUG - 2017-12-22 06:22:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:41:17 --> Config Class Initialized
INFO - 2017-12-22 19:41:17 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:41:17 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:41:17 --> Utf8 Class Initialized
INFO - 2017-12-22 19:41:17 --> URI Class Initialized
INFO - 2017-12-22 19:41:17 --> Router Class Initialized
INFO - 2017-12-22 19:41:17 --> Output Class Initialized
INFO - 2017-12-22 19:41:17 --> Security Class Initialized
DEBUG - 2017-12-22 19:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:41:17 --> Input Class Initialized
INFO - 2017-12-22 19:41:17 --> Language Class Initialized
INFO - 2017-12-22 19:41:17 --> Loader Class Initialized
INFO - 2017-12-22 19:41:17 --> Helper loaded: url_helper
INFO - 2017-12-22 19:41:17 --> Helper loaded: form_helper
INFO - 2017-12-22 19:41:18 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:41:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:41:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:41:18 --> Form Validation Class Initialized
INFO - 2017-12-22 19:41:18 --> Model Class Initialized
INFO - 2017-12-22 19:41:18 --> Controller Class Initialized
INFO - 2017-12-22 19:41:18 --> Model Class Initialized
INFO - 2017-12-22 19:41:18 --> Model Class Initialized
INFO - 2017-12-22 19:41:18 --> Model Class Initialized
DEBUG - 2017-12-22 19:41:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:41:18 --> Config Class Initialized
INFO - 2017-12-22 19:41:18 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:41:18 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:41:18 --> Utf8 Class Initialized
INFO - 2017-12-22 19:41:18 --> URI Class Initialized
INFO - 2017-12-22 19:41:18 --> Router Class Initialized
INFO - 2017-12-22 19:41:18 --> Output Class Initialized
INFO - 2017-12-22 19:41:18 --> Security Class Initialized
DEBUG - 2017-12-22 19:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:41:18 --> Input Class Initialized
INFO - 2017-12-22 19:41:18 --> Language Class Initialized
INFO - 2017-12-22 19:41:18 --> Loader Class Initialized
INFO - 2017-12-22 19:41:18 --> Helper loaded: url_helper
INFO - 2017-12-22 19:41:18 --> Helper loaded: form_helper
INFO - 2017-12-22 19:41:18 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:41:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:41:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:41:18 --> Form Validation Class Initialized
INFO - 2017-12-22 19:41:18 --> Model Class Initialized
INFO - 2017-12-22 19:41:18 --> Controller Class Initialized
INFO - 2017-12-22 19:41:18 --> Model Class Initialized
DEBUG - 2017-12-22 19:41:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:41:18 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 19:41:18 --> Final output sent to browser
DEBUG - 2017-12-22 19:41:18 --> Total execution time: 0.1017
INFO - 2017-12-22 19:41:18 --> Config Class Initialized
INFO - 2017-12-22 19:41:18 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:41:18 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:41:18 --> Utf8 Class Initialized
INFO - 2017-12-22 19:41:18 --> Config Class Initialized
INFO - 2017-12-22 19:41:18 --> Hooks Class Initialized
INFO - 2017-12-22 19:41:18 --> URI Class Initialized
INFO - 2017-12-22 19:41:18 --> Config Class Initialized
INFO - 2017-12-22 19:41:18 --> Hooks Class Initialized
INFO - 2017-12-22 19:41:18 --> Router Class Initialized
DEBUG - 2017-12-22 19:41:18 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:41:18 --> Utf8 Class Initialized
INFO - 2017-12-22 19:41:18 --> URI Class Initialized
INFO - 2017-12-22 19:41:18 --> Output Class Initialized
DEBUG - 2017-12-22 19:41:18 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:41:18 --> Utf8 Class Initialized
INFO - 2017-12-22 19:41:18 --> Security Class Initialized
INFO - 2017-12-22 19:41:18 --> Router Class Initialized
INFO - 2017-12-22 19:41:18 --> URI Class Initialized
DEBUG - 2017-12-22 19:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:41:18 --> Input Class Initialized
INFO - 2017-12-22 19:41:18 --> Output Class Initialized
INFO - 2017-12-22 19:41:18 --> Router Class Initialized
INFO - 2017-12-22 19:41:18 --> Language Class Initialized
INFO - 2017-12-22 19:41:18 --> Security Class Initialized
INFO - 2017-12-22 19:41:18 --> Output Class Initialized
DEBUG - 2017-12-22 19:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:41:18 --> Input Class Initialized
INFO - 2017-12-22 19:41:18 --> Security Class Initialized
INFO - 2017-12-22 19:41:18 --> Language Class Initialized
DEBUG - 2017-12-22 19:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:41:18 --> Input Class Initialized
INFO - 2017-12-22 19:41:18 --> Language Class Initialized
ERROR - 2017-12-22 19:41:18 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2017-12-22 19:41:18 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-22 19:41:18 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-22 19:41:19 --> Config Class Initialized
INFO - 2017-12-22 19:41:19 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:41:19 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:41:19 --> Utf8 Class Initialized
INFO - 2017-12-22 19:41:19 --> URI Class Initialized
INFO - 2017-12-22 19:41:19 --> Router Class Initialized
INFO - 2017-12-22 19:41:19 --> Output Class Initialized
INFO - 2017-12-22 19:41:19 --> Security Class Initialized
DEBUG - 2017-12-22 19:41:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:41:19 --> Input Class Initialized
INFO - 2017-12-22 19:41:19 --> Language Class Initialized
INFO - 2017-12-22 19:41:19 --> Loader Class Initialized
INFO - 2017-12-22 19:41:19 --> Helper loaded: url_helper
INFO - 2017-12-22 19:41:19 --> Helper loaded: form_helper
INFO - 2017-12-22 19:41:19 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:41:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:41:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:41:19 --> Form Validation Class Initialized
INFO - 2017-12-22 19:41:19 --> Model Class Initialized
INFO - 2017-12-22 19:41:19 --> Controller Class Initialized
INFO - 2017-12-22 19:41:19 --> Model Class Initialized
DEBUG - 2017-12-22 19:41:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:41:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-12-22 19:41:20 --> Config Class Initialized
INFO - 2017-12-22 19:41:20 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:41:20 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:41:20 --> Utf8 Class Initialized
INFO - 2017-12-22 19:41:20 --> URI Class Initialized
DEBUG - 2017-12-22 19:41:20 --> No URI present. Default controller set.
INFO - 2017-12-22 19:41:20 --> Router Class Initialized
INFO - 2017-12-22 19:41:20 --> Output Class Initialized
INFO - 2017-12-22 19:41:20 --> Security Class Initialized
DEBUG - 2017-12-22 19:41:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:41:20 --> Input Class Initialized
INFO - 2017-12-22 19:41:20 --> Language Class Initialized
INFO - 2017-12-22 19:41:20 --> Loader Class Initialized
INFO - 2017-12-22 19:41:20 --> Helper loaded: url_helper
INFO - 2017-12-22 19:41:20 --> Helper loaded: form_helper
INFO - 2017-12-22 19:41:20 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:41:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:41:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:41:20 --> Form Validation Class Initialized
INFO - 2017-12-22 19:41:20 --> Model Class Initialized
INFO - 2017-12-22 19:41:20 --> Controller Class Initialized
INFO - 2017-12-22 19:41:20 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 19:41:20 --> Final output sent to browser
DEBUG - 2017-12-22 19:41:20 --> Total execution time: 0.0759
INFO - 2017-12-22 19:41:20 --> Config Class Initialized
INFO - 2017-12-22 19:41:20 --> Hooks Class Initialized
INFO - 2017-12-22 19:41:20 --> Config Class Initialized
INFO - 2017-12-22 19:41:20 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:41:20 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:41:20 --> Utf8 Class Initialized
INFO - 2017-12-22 19:41:20 --> Config Class Initialized
DEBUG - 2017-12-22 19:41:20 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:41:20 --> URI Class Initialized
INFO - 2017-12-22 19:41:20 --> Hooks Class Initialized
INFO - 2017-12-22 19:41:20 --> Utf8 Class Initialized
INFO - 2017-12-22 19:41:20 --> URI Class Initialized
INFO - 2017-12-22 19:41:20 --> Router Class Initialized
INFO - 2017-12-22 19:41:20 --> Output Class Initialized
INFO - 2017-12-22 19:41:20 --> Router Class Initialized
DEBUG - 2017-12-22 19:41:20 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:41:20 --> Utf8 Class Initialized
INFO - 2017-12-22 19:41:20 --> Security Class Initialized
INFO - 2017-12-22 19:41:20 --> Output Class Initialized
INFO - 2017-12-22 19:41:20 --> URI Class Initialized
DEBUG - 2017-12-22 19:41:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:41:20 --> Input Class Initialized
INFO - 2017-12-22 19:41:20 --> Security Class Initialized
INFO - 2017-12-22 19:41:20 --> Router Class Initialized
INFO - 2017-12-22 19:41:20 --> Language Class Initialized
DEBUG - 2017-12-22 19:41:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:41:20 --> Input Class Initialized
ERROR - 2017-12-22 19:41:20 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-22 19:41:20 --> Output Class Initialized
INFO - 2017-12-22 19:41:20 --> Language Class Initialized
INFO - 2017-12-22 19:41:20 --> Security Class Initialized
ERROR - 2017-12-22 19:41:20 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2017-12-22 19:41:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:41:20 --> Input Class Initialized
INFO - 2017-12-22 19:41:20 --> Language Class Initialized
ERROR - 2017-12-22 19:41:20 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-22 19:41:21 --> Config Class Initialized
INFO - 2017-12-22 19:41:21 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:41:21 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:41:21 --> Utf8 Class Initialized
INFO - 2017-12-22 19:41:21 --> URI Class Initialized
INFO - 2017-12-22 19:41:21 --> Router Class Initialized
INFO - 2017-12-22 19:41:21 --> Output Class Initialized
INFO - 2017-12-22 19:41:21 --> Security Class Initialized
DEBUG - 2017-12-22 19:41:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:41:21 --> Input Class Initialized
INFO - 2017-12-22 19:41:21 --> Language Class Initialized
INFO - 2017-12-22 19:41:21 --> Loader Class Initialized
INFO - 2017-12-22 19:41:21 --> Helper loaded: url_helper
INFO - 2017-12-22 19:41:21 --> Helper loaded: form_helper
INFO - 2017-12-22 19:41:21 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:41:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:41:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:41:21 --> Form Validation Class Initialized
INFO - 2017-12-22 19:41:21 --> Model Class Initialized
INFO - 2017-12-22 19:41:21 --> Controller Class Initialized
INFO - 2017-12-22 19:41:21 --> Model Class Initialized
INFO - 2017-12-22 19:41:21 --> Model Class Initialized
INFO - 2017-12-22 19:41:21 --> Model Class Initialized
DEBUG - 2017-12-22 19:41:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:41:21 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 19:41:21 --> Final output sent to browser
DEBUG - 2017-12-22 19:41:21 --> Total execution time: 0.0716
INFO - 2017-12-22 19:41:22 --> Config Class Initialized
INFO - 2017-12-22 19:41:22 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:41:22 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:41:22 --> Utf8 Class Initialized
INFO - 2017-12-22 19:41:22 --> URI Class Initialized
INFO - 2017-12-22 19:41:22 --> Router Class Initialized
INFO - 2017-12-22 19:41:22 --> Output Class Initialized
INFO - 2017-12-22 19:41:22 --> Security Class Initialized
DEBUG - 2017-12-22 19:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:41:22 --> Input Class Initialized
INFO - 2017-12-22 19:41:22 --> Language Class Initialized
ERROR - 2017-12-22 19:41:22 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-22 19:41:22 --> Config Class Initialized
INFO - 2017-12-22 19:41:22 --> Hooks Class Initialized
INFO - 2017-12-22 19:41:22 --> Config Class Initialized
INFO - 2017-12-22 19:41:22 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:41:22 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:41:22 --> Utf8 Class Initialized
INFO - 2017-12-22 19:41:22 --> URI Class Initialized
DEBUG - 2017-12-22 19:41:22 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:41:22 --> Router Class Initialized
INFO - 2017-12-22 19:41:22 --> Utf8 Class Initialized
INFO - 2017-12-22 19:41:22 --> URI Class Initialized
INFO - 2017-12-22 19:41:22 --> Output Class Initialized
INFO - 2017-12-22 19:41:22 --> Security Class Initialized
INFO - 2017-12-22 19:41:22 --> Router Class Initialized
DEBUG - 2017-12-22 19:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:41:22 --> Input Class Initialized
INFO - 2017-12-22 19:41:22 --> Output Class Initialized
INFO - 2017-12-22 19:41:22 --> Language Class Initialized
INFO - 2017-12-22 19:41:22 --> Security Class Initialized
ERROR - 2017-12-22 19:41:22 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2017-12-22 19:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:41:22 --> Input Class Initialized
INFO - 2017-12-22 19:41:22 --> Language Class Initialized
ERROR - 2017-12-22 19:41:22 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-22 19:41:22 --> Config Class Initialized
INFO - 2017-12-22 19:41:22 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:41:22 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:41:22 --> Utf8 Class Initialized
INFO - 2017-12-22 19:41:22 --> URI Class Initialized
INFO - 2017-12-22 19:41:22 --> Router Class Initialized
INFO - 2017-12-22 19:41:22 --> Output Class Initialized
INFO - 2017-12-22 19:41:22 --> Security Class Initialized
DEBUG - 2017-12-22 19:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:41:22 --> Input Class Initialized
INFO - 2017-12-22 19:41:22 --> Language Class Initialized
INFO - 2017-12-22 19:41:22 --> Loader Class Initialized
INFO - 2017-12-22 19:41:22 --> Helper loaded: url_helper
INFO - 2017-12-22 19:41:22 --> Helper loaded: form_helper
INFO - 2017-12-22 19:41:22 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:41:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:41:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:41:22 --> Form Validation Class Initialized
INFO - 2017-12-22 19:41:22 --> Model Class Initialized
INFO - 2017-12-22 19:41:22 --> Controller Class Initialized
INFO - 2017-12-22 19:41:22 --> Model Class Initialized
INFO - 2017-12-22 19:41:22 --> Model Class Initialized
INFO - 2017-12-22 19:41:22 --> Model Class Initialized
DEBUG - 2017-12-22 19:41:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:41:24 --> Config Class Initialized
INFO - 2017-12-22 19:41:24 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:41:24 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:41:24 --> Utf8 Class Initialized
INFO - 2017-12-22 19:41:24 --> URI Class Initialized
INFO - 2017-12-22 19:41:24 --> Router Class Initialized
INFO - 2017-12-22 19:41:24 --> Output Class Initialized
INFO - 2017-12-22 19:41:24 --> Security Class Initialized
DEBUG - 2017-12-22 19:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:41:24 --> Input Class Initialized
INFO - 2017-12-22 19:41:24 --> Language Class Initialized
INFO - 2017-12-22 19:41:24 --> Loader Class Initialized
INFO - 2017-12-22 19:41:24 --> Helper loaded: url_helper
INFO - 2017-12-22 19:41:24 --> Helper loaded: form_helper
INFO - 2017-12-22 19:41:24 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:41:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:41:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:41:24 --> Form Validation Class Initialized
INFO - 2017-12-22 19:41:24 --> Model Class Initialized
INFO - 2017-12-22 19:41:24 --> Controller Class Initialized
INFO - 2017-12-22 19:41:24 --> Model Class Initialized
INFO - 2017-12-22 19:41:24 --> Model Class Initialized
INFO - 2017-12-22 19:41:24 --> Model Class Initialized
DEBUG - 2017-12-22 19:41:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:41:24 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 19:41:24 --> Final output sent to browser
DEBUG - 2017-12-22 19:41:24 --> Total execution time: 0.0579
INFO - 2017-12-22 19:41:24 --> Config Class Initialized
INFO - 2017-12-22 19:41:24 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:41:24 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:41:24 --> Utf8 Class Initialized
INFO - 2017-12-22 19:41:24 --> URI Class Initialized
INFO - 2017-12-22 19:41:24 --> Router Class Initialized
INFO - 2017-12-22 19:41:24 --> Output Class Initialized
INFO - 2017-12-22 19:41:24 --> Security Class Initialized
DEBUG - 2017-12-22 19:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:41:24 --> Input Class Initialized
INFO - 2017-12-22 19:41:24 --> Language Class Initialized
ERROR - 2017-12-22 19:41:24 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-22 19:41:24 --> Config Class Initialized
INFO - 2017-12-22 19:41:24 --> Hooks Class Initialized
INFO - 2017-12-22 19:41:24 --> Config Class Initialized
INFO - 2017-12-22 19:41:24 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:41:24 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:41:24 --> Utf8 Class Initialized
DEBUG - 2017-12-22 19:41:24 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:41:24 --> Utf8 Class Initialized
INFO - 2017-12-22 19:41:24 --> URI Class Initialized
INFO - 2017-12-22 19:41:24 --> URI Class Initialized
INFO - 2017-12-22 19:41:24 --> Router Class Initialized
INFO - 2017-12-22 19:41:24 --> Router Class Initialized
INFO - 2017-12-22 19:41:24 --> Output Class Initialized
INFO - 2017-12-22 19:41:24 --> Output Class Initialized
INFO - 2017-12-22 19:41:24 --> Security Class Initialized
INFO - 2017-12-22 19:41:24 --> Security Class Initialized
DEBUG - 2017-12-22 19:41:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-22 19:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:41:24 --> Input Class Initialized
INFO - 2017-12-22 19:41:24 --> Input Class Initialized
INFO - 2017-12-22 19:41:24 --> Language Class Initialized
INFO - 2017-12-22 19:41:24 --> Language Class Initialized
ERROR - 2017-12-22 19:41:24 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-22 19:41:24 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-22 19:41:24 --> Config Class Initialized
INFO - 2017-12-22 19:41:24 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:41:24 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:41:24 --> Utf8 Class Initialized
INFO - 2017-12-22 19:41:24 --> URI Class Initialized
INFO - 2017-12-22 19:41:24 --> Router Class Initialized
INFO - 2017-12-22 19:41:24 --> Output Class Initialized
INFO - 2017-12-22 19:41:24 --> Security Class Initialized
DEBUG - 2017-12-22 19:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:41:24 --> Input Class Initialized
INFO - 2017-12-22 19:41:24 --> Language Class Initialized
INFO - 2017-12-22 19:41:24 --> Loader Class Initialized
INFO - 2017-12-22 19:41:24 --> Helper loaded: url_helper
INFO - 2017-12-22 19:41:24 --> Helper loaded: form_helper
INFO - 2017-12-22 19:41:24 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:41:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:41:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:41:24 --> Form Validation Class Initialized
INFO - 2017-12-22 19:41:24 --> Model Class Initialized
INFO - 2017-12-22 19:41:24 --> Controller Class Initialized
INFO - 2017-12-22 19:41:24 --> Model Class Initialized
INFO - 2017-12-22 19:41:24 --> Model Class Initialized
INFO - 2017-12-22 19:41:24 --> Model Class Initialized
DEBUG - 2017-12-22 19:41:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:41:35 --> Config Class Initialized
INFO - 2017-12-22 19:41:35 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:41:35 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:41:35 --> Utf8 Class Initialized
INFO - 2017-12-22 19:41:35 --> URI Class Initialized
INFO - 2017-12-22 19:41:35 --> Router Class Initialized
INFO - 2017-12-22 19:41:35 --> Output Class Initialized
INFO - 2017-12-22 19:41:35 --> Security Class Initialized
DEBUG - 2017-12-22 19:41:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:41:35 --> Input Class Initialized
INFO - 2017-12-22 19:41:35 --> Language Class Initialized
INFO - 2017-12-22 19:41:35 --> Loader Class Initialized
INFO - 2017-12-22 19:41:35 --> Helper loaded: url_helper
INFO - 2017-12-22 19:41:35 --> Helper loaded: form_helper
INFO - 2017-12-22 19:41:35 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:41:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:41:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:41:35 --> Form Validation Class Initialized
INFO - 2017-12-22 19:41:35 --> Model Class Initialized
INFO - 2017-12-22 19:41:35 --> Controller Class Initialized
INFO - 2017-12-22 19:41:35 --> Model Class Initialized
INFO - 2017-12-22 19:41:35 --> Model Class Initialized
INFO - 2017-12-22 19:41:35 --> Model Class Initialized
DEBUG - 2017-12-22 19:41:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:41:36 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 19:41:36 --> Final output sent to browser
DEBUG - 2017-12-22 19:41:36 --> Total execution time: 0.0693
INFO - 2017-12-22 19:41:36 --> Config Class Initialized
INFO - 2017-12-22 19:41:36 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:41:36 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:41:36 --> Utf8 Class Initialized
INFO - 2017-12-22 19:41:36 --> URI Class Initialized
INFO - 2017-12-22 19:41:36 --> Router Class Initialized
INFO - 2017-12-22 19:41:36 --> Output Class Initialized
INFO - 2017-12-22 19:41:36 --> Security Class Initialized
DEBUG - 2017-12-22 19:41:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:41:36 --> Input Class Initialized
INFO - 2017-12-22 19:41:36 --> Language Class Initialized
ERROR - 2017-12-22 19:41:36 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-22 19:41:36 --> Config Class Initialized
INFO - 2017-12-22 19:41:36 --> Hooks Class Initialized
INFO - 2017-12-22 19:41:36 --> Config Class Initialized
INFO - 2017-12-22 19:41:36 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:41:36 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:41:36 --> Utf8 Class Initialized
INFO - 2017-12-22 19:41:36 --> URI Class Initialized
DEBUG - 2017-12-22 19:41:36 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:41:36 --> Utf8 Class Initialized
INFO - 2017-12-22 19:41:36 --> Router Class Initialized
INFO - 2017-12-22 19:41:36 --> URI Class Initialized
INFO - 2017-12-22 19:41:36 --> Output Class Initialized
INFO - 2017-12-22 19:41:36 --> Security Class Initialized
INFO - 2017-12-22 19:41:36 --> Router Class Initialized
DEBUG - 2017-12-22 19:41:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:41:36 --> Input Class Initialized
INFO - 2017-12-22 19:41:36 --> Language Class Initialized
INFO - 2017-12-22 19:41:36 --> Output Class Initialized
ERROR - 2017-12-22 19:41:36 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-22 19:41:36 --> Security Class Initialized
DEBUG - 2017-12-22 19:41:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:41:36 --> Input Class Initialized
INFO - 2017-12-22 19:41:36 --> Language Class Initialized
ERROR - 2017-12-22 19:41:36 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-22 19:41:36 --> Config Class Initialized
INFO - 2017-12-22 19:41:36 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:41:36 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:41:36 --> Utf8 Class Initialized
INFO - 2017-12-22 19:41:36 --> URI Class Initialized
INFO - 2017-12-22 19:41:36 --> Router Class Initialized
INFO - 2017-12-22 19:41:36 --> Output Class Initialized
INFO - 2017-12-22 19:41:36 --> Security Class Initialized
DEBUG - 2017-12-22 19:41:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:41:36 --> Input Class Initialized
INFO - 2017-12-22 19:41:36 --> Language Class Initialized
INFO - 2017-12-22 19:41:36 --> Loader Class Initialized
INFO - 2017-12-22 19:41:36 --> Helper loaded: url_helper
INFO - 2017-12-22 19:41:36 --> Helper loaded: form_helper
INFO - 2017-12-22 19:41:36 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:41:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:41:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:41:36 --> Form Validation Class Initialized
INFO - 2017-12-22 19:41:36 --> Model Class Initialized
INFO - 2017-12-22 19:41:36 --> Controller Class Initialized
INFO - 2017-12-22 19:41:36 --> Model Class Initialized
INFO - 2017-12-22 19:41:36 --> Model Class Initialized
INFO - 2017-12-22 19:41:36 --> Model Class Initialized
DEBUG - 2017-12-22 19:41:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:41:43 --> Config Class Initialized
INFO - 2017-12-22 19:41:43 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:41:44 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:41:44 --> Utf8 Class Initialized
INFO - 2017-12-22 19:41:44 --> URI Class Initialized
INFO - 2017-12-22 19:41:44 --> Router Class Initialized
INFO - 2017-12-22 19:41:44 --> Output Class Initialized
INFO - 2017-12-22 19:41:44 --> Security Class Initialized
DEBUG - 2017-12-22 19:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:41:44 --> Input Class Initialized
INFO - 2017-12-22 19:41:44 --> Language Class Initialized
INFO - 2017-12-22 19:41:44 --> Loader Class Initialized
INFO - 2017-12-22 19:41:44 --> Helper loaded: url_helper
INFO - 2017-12-22 19:41:44 --> Helper loaded: form_helper
INFO - 2017-12-22 19:41:44 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:41:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:41:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:41:44 --> Form Validation Class Initialized
INFO - 2017-12-22 19:41:44 --> Model Class Initialized
INFO - 2017-12-22 19:41:44 --> Controller Class Initialized
INFO - 2017-12-22 19:41:44 --> Model Class Initialized
INFO - 2017-12-22 19:41:44 --> Model Class Initialized
INFO - 2017-12-22 19:41:44 --> Model Class Initialized
DEBUG - 2017-12-22 19:41:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:41:44 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 19:41:44 --> Final output sent to browser
DEBUG - 2017-12-22 19:41:44 --> Total execution time: 0.0771
INFO - 2017-12-22 19:41:44 --> Config Class Initialized
INFO - 2017-12-22 19:41:44 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:41:44 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:41:44 --> Utf8 Class Initialized
INFO - 2017-12-22 19:41:44 --> URI Class Initialized
INFO - 2017-12-22 19:41:44 --> Router Class Initialized
INFO - 2017-12-22 19:41:44 --> Output Class Initialized
INFO - 2017-12-22 19:41:44 --> Security Class Initialized
DEBUG - 2017-12-22 19:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:41:44 --> Input Class Initialized
INFO - 2017-12-22 19:41:44 --> Language Class Initialized
ERROR - 2017-12-22 19:41:44 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-22 19:41:44 --> Config Class Initialized
INFO - 2017-12-22 19:41:44 --> Hooks Class Initialized
INFO - 2017-12-22 19:41:44 --> Config Class Initialized
INFO - 2017-12-22 19:41:44 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:41:44 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:41:44 --> Utf8 Class Initialized
INFO - 2017-12-22 19:41:44 --> URI Class Initialized
DEBUG - 2017-12-22 19:41:44 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:41:44 --> Utf8 Class Initialized
INFO - 2017-12-22 19:41:44 --> URI Class Initialized
INFO - 2017-12-22 19:41:44 --> Router Class Initialized
INFO - 2017-12-22 19:41:44 --> Router Class Initialized
INFO - 2017-12-22 19:41:44 --> Output Class Initialized
INFO - 2017-12-22 19:41:44 --> Security Class Initialized
INFO - 2017-12-22 19:41:44 --> Output Class Initialized
DEBUG - 2017-12-22 19:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:41:44 --> Input Class Initialized
INFO - 2017-12-22 19:41:44 --> Language Class Initialized
INFO - 2017-12-22 19:41:44 --> Security Class Initialized
ERROR - 2017-12-22 19:41:44 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2017-12-22 19:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:41:44 --> Input Class Initialized
INFO - 2017-12-22 19:41:44 --> Language Class Initialized
ERROR - 2017-12-22 19:41:44 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-22 19:41:44 --> Config Class Initialized
INFO - 2017-12-22 19:41:44 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:41:44 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:41:44 --> Utf8 Class Initialized
INFO - 2017-12-22 19:41:44 --> URI Class Initialized
INFO - 2017-12-22 19:41:44 --> Router Class Initialized
INFO - 2017-12-22 19:41:44 --> Output Class Initialized
INFO - 2017-12-22 19:41:44 --> Security Class Initialized
DEBUG - 2017-12-22 19:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:41:44 --> Input Class Initialized
INFO - 2017-12-22 19:41:44 --> Language Class Initialized
INFO - 2017-12-22 19:41:44 --> Loader Class Initialized
INFO - 2017-12-22 19:41:44 --> Helper loaded: url_helper
INFO - 2017-12-22 19:41:44 --> Helper loaded: form_helper
INFO - 2017-12-22 19:41:44 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:41:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:41:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:41:44 --> Form Validation Class Initialized
INFO - 2017-12-22 19:41:44 --> Model Class Initialized
INFO - 2017-12-22 19:41:44 --> Controller Class Initialized
INFO - 2017-12-22 19:41:44 --> Model Class Initialized
INFO - 2017-12-22 19:41:44 --> Model Class Initialized
INFO - 2017-12-22 19:41:44 --> Model Class Initialized
DEBUG - 2017-12-22 19:41:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:41:53 --> Config Class Initialized
INFO - 2017-12-22 19:41:53 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:41:53 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:41:53 --> Utf8 Class Initialized
INFO - 2017-12-22 19:41:53 --> URI Class Initialized
INFO - 2017-12-22 19:41:53 --> Router Class Initialized
INFO - 2017-12-22 19:41:53 --> Output Class Initialized
INFO - 2017-12-22 19:41:53 --> Security Class Initialized
DEBUG - 2017-12-22 19:41:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:41:53 --> Input Class Initialized
INFO - 2017-12-22 19:41:53 --> Language Class Initialized
INFO - 2017-12-22 19:41:53 --> Loader Class Initialized
INFO - 2017-12-22 19:41:53 --> Helper loaded: url_helper
INFO - 2017-12-22 19:41:53 --> Helper loaded: form_helper
INFO - 2017-12-22 19:41:53 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:41:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:41:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:41:53 --> Form Validation Class Initialized
INFO - 2017-12-22 19:41:53 --> Model Class Initialized
INFO - 2017-12-22 19:41:53 --> Controller Class Initialized
INFO - 2017-12-22 19:41:53 --> Model Class Initialized
INFO - 2017-12-22 19:41:53 --> Model Class Initialized
INFO - 2017-12-22 19:41:53 --> Model Class Initialized
DEBUG - 2017-12-22 19:41:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:41:53 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 19:41:53 --> Final output sent to browser
DEBUG - 2017-12-22 19:41:53 --> Total execution time: 0.0622
INFO - 2017-12-22 19:41:53 --> Config Class Initialized
INFO - 2017-12-22 19:41:53 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:41:53 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:41:53 --> Utf8 Class Initialized
INFO - 2017-12-22 19:41:53 --> URI Class Initialized
INFO - 2017-12-22 19:41:53 --> Router Class Initialized
INFO - 2017-12-22 19:41:53 --> Output Class Initialized
INFO - 2017-12-22 19:41:53 --> Security Class Initialized
DEBUG - 2017-12-22 19:41:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:41:53 --> Input Class Initialized
INFO - 2017-12-22 19:41:53 --> Language Class Initialized
ERROR - 2017-12-22 19:41:53 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-22 19:41:53 --> Config Class Initialized
INFO - 2017-12-22 19:41:53 --> Hooks Class Initialized
INFO - 2017-12-22 19:41:53 --> Config Class Initialized
INFO - 2017-12-22 19:41:53 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:41:53 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:41:53 --> Utf8 Class Initialized
INFO - 2017-12-22 19:41:53 --> URI Class Initialized
DEBUG - 2017-12-22 19:41:53 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:41:53 --> Utf8 Class Initialized
INFO - 2017-12-22 19:41:53 --> Router Class Initialized
INFO - 2017-12-22 19:41:53 --> URI Class Initialized
INFO - 2017-12-22 19:41:53 --> Router Class Initialized
INFO - 2017-12-22 19:41:53 --> Output Class Initialized
INFO - 2017-12-22 19:41:53 --> Output Class Initialized
INFO - 2017-12-22 19:41:53 --> Security Class Initialized
INFO - 2017-12-22 19:41:53 --> Security Class Initialized
DEBUG - 2017-12-22 19:41:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:41:53 --> Input Class Initialized
DEBUG - 2017-12-22 19:41:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:41:53 --> Language Class Initialized
INFO - 2017-12-22 19:41:53 --> Input Class Initialized
INFO - 2017-12-22 19:41:53 --> Language Class Initialized
ERROR - 2017-12-22 19:41:53 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-22 19:41:53 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-22 19:41:53 --> Config Class Initialized
INFO - 2017-12-22 19:41:53 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:41:53 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:41:53 --> Utf8 Class Initialized
INFO - 2017-12-22 19:41:53 --> URI Class Initialized
INFO - 2017-12-22 19:41:53 --> Router Class Initialized
INFO - 2017-12-22 19:41:53 --> Output Class Initialized
INFO - 2017-12-22 19:41:53 --> Security Class Initialized
DEBUG - 2017-12-22 19:41:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:41:53 --> Input Class Initialized
INFO - 2017-12-22 19:41:53 --> Language Class Initialized
INFO - 2017-12-22 19:41:53 --> Loader Class Initialized
INFO - 2017-12-22 19:41:53 --> Helper loaded: url_helper
INFO - 2017-12-22 19:41:53 --> Helper loaded: form_helper
INFO - 2017-12-22 19:41:53 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:41:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:41:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:41:53 --> Form Validation Class Initialized
INFO - 2017-12-22 19:41:53 --> Model Class Initialized
INFO - 2017-12-22 19:41:53 --> Controller Class Initialized
INFO - 2017-12-22 19:41:53 --> Model Class Initialized
INFO - 2017-12-22 19:41:53 --> Model Class Initialized
INFO - 2017-12-22 19:41:53 --> Model Class Initialized
DEBUG - 2017-12-22 19:41:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:42:04 --> Config Class Initialized
INFO - 2017-12-22 19:42:04 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:42:04 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:42:04 --> Utf8 Class Initialized
INFO - 2017-12-22 19:42:04 --> URI Class Initialized
INFO - 2017-12-22 19:42:04 --> Router Class Initialized
INFO - 2017-12-22 19:42:04 --> Output Class Initialized
INFO - 2017-12-22 19:42:04 --> Security Class Initialized
DEBUG - 2017-12-22 19:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:42:04 --> Input Class Initialized
INFO - 2017-12-22 19:42:04 --> Language Class Initialized
INFO - 2017-12-22 19:42:04 --> Loader Class Initialized
INFO - 2017-12-22 19:42:04 --> Helper loaded: url_helper
INFO - 2017-12-22 19:42:04 --> Helper loaded: form_helper
INFO - 2017-12-22 19:42:04 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:42:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:42:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:42:04 --> Form Validation Class Initialized
INFO - 2017-12-22 19:42:04 --> Model Class Initialized
INFO - 2017-12-22 19:42:04 --> Controller Class Initialized
INFO - 2017-12-22 19:42:04 --> Model Class Initialized
INFO - 2017-12-22 19:42:04 --> Model Class Initialized
INFO - 2017-12-22 19:42:04 --> Model Class Initialized
DEBUG - 2017-12-22 19:42:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:42:04 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 19:42:04 --> Final output sent to browser
DEBUG - 2017-12-22 19:42:04 --> Total execution time: 0.0764
INFO - 2017-12-22 19:42:05 --> Config Class Initialized
INFO - 2017-12-22 19:42:05 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:42:05 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:42:05 --> Utf8 Class Initialized
INFO - 2017-12-22 19:42:05 --> URI Class Initialized
INFO - 2017-12-22 19:42:05 --> Router Class Initialized
INFO - 2017-12-22 19:42:05 --> Output Class Initialized
INFO - 2017-12-22 19:42:05 --> Security Class Initialized
DEBUG - 2017-12-22 19:42:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:42:05 --> Input Class Initialized
INFO - 2017-12-22 19:42:05 --> Language Class Initialized
ERROR - 2017-12-22 19:42:05 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-22 19:42:05 --> Config Class Initialized
INFO - 2017-12-22 19:42:05 --> Hooks Class Initialized
INFO - 2017-12-22 19:42:05 --> Config Class Initialized
INFO - 2017-12-22 19:42:05 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:42:05 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:42:05 --> Utf8 Class Initialized
DEBUG - 2017-12-22 19:42:05 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:42:05 --> Utf8 Class Initialized
INFO - 2017-12-22 19:42:05 --> URI Class Initialized
INFO - 2017-12-22 19:42:05 --> URI Class Initialized
INFO - 2017-12-22 19:42:05 --> Router Class Initialized
INFO - 2017-12-22 19:42:05 --> Router Class Initialized
INFO - 2017-12-22 19:42:05 --> Output Class Initialized
INFO - 2017-12-22 19:42:05 --> Output Class Initialized
INFO - 2017-12-22 19:42:05 --> Security Class Initialized
INFO - 2017-12-22 19:42:05 --> Security Class Initialized
DEBUG - 2017-12-22 19:42:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:42:05 --> Input Class Initialized
DEBUG - 2017-12-22 19:42:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:42:05 --> Language Class Initialized
INFO - 2017-12-22 19:42:05 --> Input Class Initialized
INFO - 2017-12-22 19:42:05 --> Language Class Initialized
ERROR - 2017-12-22 19:42:05 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-22 19:42:05 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-22 19:42:05 --> Config Class Initialized
INFO - 2017-12-22 19:42:05 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:42:05 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:42:05 --> Utf8 Class Initialized
INFO - 2017-12-22 19:42:05 --> URI Class Initialized
INFO - 2017-12-22 19:42:05 --> Router Class Initialized
INFO - 2017-12-22 19:42:05 --> Output Class Initialized
INFO - 2017-12-22 19:42:05 --> Security Class Initialized
DEBUG - 2017-12-22 19:42:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:42:05 --> Input Class Initialized
INFO - 2017-12-22 19:42:05 --> Language Class Initialized
INFO - 2017-12-22 19:42:05 --> Loader Class Initialized
INFO - 2017-12-22 19:42:05 --> Helper loaded: url_helper
INFO - 2017-12-22 19:42:05 --> Helper loaded: form_helper
INFO - 2017-12-22 19:42:05 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:42:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:42:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:42:05 --> Form Validation Class Initialized
INFO - 2017-12-22 19:42:05 --> Model Class Initialized
INFO - 2017-12-22 19:42:05 --> Controller Class Initialized
INFO - 2017-12-22 19:42:05 --> Model Class Initialized
INFO - 2017-12-22 19:42:05 --> Model Class Initialized
INFO - 2017-12-22 19:42:05 --> Model Class Initialized
DEBUG - 2017-12-22 19:42:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:43:30 --> Config Class Initialized
INFO - 2017-12-22 19:43:30 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:43:30 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:43:30 --> Utf8 Class Initialized
INFO - 2017-12-22 19:43:30 --> URI Class Initialized
INFO - 2017-12-22 19:43:30 --> Router Class Initialized
INFO - 2017-12-22 19:43:30 --> Output Class Initialized
INFO - 2017-12-22 19:43:30 --> Security Class Initialized
DEBUG - 2017-12-22 19:43:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:43:30 --> Input Class Initialized
INFO - 2017-12-22 19:43:30 --> Language Class Initialized
INFO - 2017-12-22 19:43:30 --> Loader Class Initialized
INFO - 2017-12-22 19:43:30 --> Helper loaded: url_helper
INFO - 2017-12-22 19:43:30 --> Helper loaded: form_helper
INFO - 2017-12-22 19:43:30 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:43:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:43:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:43:30 --> Form Validation Class Initialized
INFO - 2017-12-22 19:43:30 --> Model Class Initialized
INFO - 2017-12-22 19:43:30 --> Controller Class Initialized
INFO - 2017-12-22 19:43:30 --> Model Class Initialized
INFO - 2017-12-22 19:43:30 --> Model Class Initialized
INFO - 2017-12-22 19:43:30 --> Model Class Initialized
DEBUG - 2017-12-22 19:43:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:43:30 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 19:43:30 --> Final output sent to browser
DEBUG - 2017-12-22 19:43:30 --> Total execution time: 0.0597
INFO - 2017-12-22 19:43:31 --> Config Class Initialized
INFO - 2017-12-22 19:43:31 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:43:31 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:43:31 --> Utf8 Class Initialized
INFO - 2017-12-22 19:43:31 --> URI Class Initialized
INFO - 2017-12-22 19:43:31 --> Router Class Initialized
INFO - 2017-12-22 19:43:31 --> Output Class Initialized
INFO - 2017-12-22 19:43:31 --> Security Class Initialized
DEBUG - 2017-12-22 19:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:43:31 --> Input Class Initialized
INFO - 2017-12-22 19:43:31 --> Language Class Initialized
ERROR - 2017-12-22 19:43:31 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-22 19:43:31 --> Config Class Initialized
INFO - 2017-12-22 19:43:31 --> Hooks Class Initialized
INFO - 2017-12-22 19:43:31 --> Config Class Initialized
INFO - 2017-12-22 19:43:31 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:43:31 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:43:31 --> Utf8 Class Initialized
DEBUG - 2017-12-22 19:43:31 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:43:31 --> URI Class Initialized
INFO - 2017-12-22 19:43:31 --> Utf8 Class Initialized
INFO - 2017-12-22 19:43:31 --> URI Class Initialized
INFO - 2017-12-22 19:43:31 --> Router Class Initialized
INFO - 2017-12-22 19:43:31 --> Router Class Initialized
INFO - 2017-12-22 19:43:31 --> Output Class Initialized
INFO - 2017-12-22 19:43:31 --> Security Class Initialized
INFO - 2017-12-22 19:43:31 --> Output Class Initialized
DEBUG - 2017-12-22 19:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:43:31 --> Security Class Initialized
INFO - 2017-12-22 19:43:31 --> Input Class Initialized
DEBUG - 2017-12-22 19:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:43:31 --> Language Class Initialized
INFO - 2017-12-22 19:43:31 --> Input Class Initialized
INFO - 2017-12-22 19:43:31 --> Language Class Initialized
ERROR - 2017-12-22 19:43:31 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-22 19:43:31 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-22 19:43:31 --> Config Class Initialized
INFO - 2017-12-22 19:43:31 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:43:31 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:43:31 --> Utf8 Class Initialized
INFO - 2017-12-22 19:43:31 --> URI Class Initialized
INFO - 2017-12-22 19:43:31 --> Router Class Initialized
INFO - 2017-12-22 19:43:31 --> Output Class Initialized
INFO - 2017-12-22 19:43:31 --> Security Class Initialized
DEBUG - 2017-12-22 19:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:43:31 --> Input Class Initialized
INFO - 2017-12-22 19:43:31 --> Language Class Initialized
INFO - 2017-12-22 19:43:31 --> Loader Class Initialized
INFO - 2017-12-22 19:43:31 --> Helper loaded: url_helper
INFO - 2017-12-22 19:43:31 --> Helper loaded: form_helper
INFO - 2017-12-22 19:43:31 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:43:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:43:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:43:31 --> Form Validation Class Initialized
INFO - 2017-12-22 19:43:31 --> Model Class Initialized
INFO - 2017-12-22 19:43:31 --> Controller Class Initialized
INFO - 2017-12-22 19:43:31 --> Model Class Initialized
INFO - 2017-12-22 19:43:31 --> Model Class Initialized
INFO - 2017-12-22 19:43:31 --> Model Class Initialized
DEBUG - 2017-12-22 19:43:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:44:32 --> Config Class Initialized
INFO - 2017-12-22 19:44:32 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:44:32 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:44:32 --> Utf8 Class Initialized
INFO - 2017-12-22 19:44:32 --> URI Class Initialized
INFO - 2017-12-22 19:44:32 --> Router Class Initialized
INFO - 2017-12-22 19:44:32 --> Output Class Initialized
INFO - 2017-12-22 19:44:32 --> Security Class Initialized
DEBUG - 2017-12-22 19:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:44:32 --> Input Class Initialized
INFO - 2017-12-22 19:44:32 --> Language Class Initialized
INFO - 2017-12-22 19:44:32 --> Loader Class Initialized
INFO - 2017-12-22 19:44:32 --> Helper loaded: url_helper
INFO - 2017-12-22 19:44:32 --> Helper loaded: form_helper
INFO - 2017-12-22 19:44:32 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:44:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:44:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:44:32 --> Form Validation Class Initialized
INFO - 2017-12-22 19:44:32 --> Model Class Initialized
INFO - 2017-12-22 19:44:32 --> Controller Class Initialized
INFO - 2017-12-22 19:44:32 --> Model Class Initialized
INFO - 2017-12-22 19:44:32 --> Model Class Initialized
INFO - 2017-12-22 19:44:32 --> Model Class Initialized
DEBUG - 2017-12-22 19:44:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:44:32 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 19:44:32 --> Final output sent to browser
DEBUG - 2017-12-22 19:44:32 --> Total execution time: 0.0570
INFO - 2017-12-22 19:44:32 --> Config Class Initialized
INFO - 2017-12-22 19:44:32 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:44:32 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:44:32 --> Utf8 Class Initialized
INFO - 2017-12-22 19:44:32 --> URI Class Initialized
INFO - 2017-12-22 19:44:32 --> Router Class Initialized
INFO - 2017-12-22 19:44:32 --> Output Class Initialized
INFO - 2017-12-22 19:44:32 --> Security Class Initialized
DEBUG - 2017-12-22 19:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:44:32 --> Input Class Initialized
INFO - 2017-12-22 19:44:32 --> Language Class Initialized
ERROR - 2017-12-22 19:44:32 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-22 19:44:32 --> Config Class Initialized
INFO - 2017-12-22 19:44:32 --> Hooks Class Initialized
INFO - 2017-12-22 19:44:32 --> Config Class Initialized
INFO - 2017-12-22 19:44:32 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:44:32 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:44:32 --> Utf8 Class Initialized
INFO - 2017-12-22 19:44:32 --> URI Class Initialized
DEBUG - 2017-12-22 19:44:32 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:44:32 --> Utf8 Class Initialized
INFO - 2017-12-22 19:44:32 --> URI Class Initialized
INFO - 2017-12-22 19:44:32 --> Router Class Initialized
INFO - 2017-12-22 19:44:32 --> Router Class Initialized
INFO - 2017-12-22 19:44:32 --> Output Class Initialized
INFO - 2017-12-22 19:44:32 --> Output Class Initialized
INFO - 2017-12-22 19:44:32 --> Security Class Initialized
DEBUG - 2017-12-22 19:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:44:32 --> Security Class Initialized
INFO - 2017-12-22 19:44:32 --> Input Class Initialized
INFO - 2017-12-22 19:44:32 --> Language Class Initialized
DEBUG - 2017-12-22 19:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:44:32 --> Input Class Initialized
INFO - 2017-12-22 19:44:32 --> Language Class Initialized
ERROR - 2017-12-22 19:44:32 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-22 19:44:32 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-22 19:44:32 --> Config Class Initialized
INFO - 2017-12-22 19:44:32 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:44:32 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:44:32 --> Utf8 Class Initialized
INFO - 2017-12-22 19:44:32 --> URI Class Initialized
INFO - 2017-12-22 19:44:32 --> Router Class Initialized
INFO - 2017-12-22 19:44:32 --> Output Class Initialized
INFO - 2017-12-22 19:44:32 --> Security Class Initialized
DEBUG - 2017-12-22 19:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:44:32 --> Input Class Initialized
INFO - 2017-12-22 19:44:32 --> Language Class Initialized
INFO - 2017-12-22 19:44:32 --> Loader Class Initialized
INFO - 2017-12-22 19:44:32 --> Helper loaded: url_helper
INFO - 2017-12-22 19:44:32 --> Helper loaded: form_helper
INFO - 2017-12-22 19:44:32 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:44:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:44:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:44:32 --> Form Validation Class Initialized
INFO - 2017-12-22 19:44:32 --> Model Class Initialized
INFO - 2017-12-22 19:44:32 --> Controller Class Initialized
INFO - 2017-12-22 19:44:32 --> Model Class Initialized
INFO - 2017-12-22 19:44:32 --> Model Class Initialized
INFO - 2017-12-22 19:44:32 --> Model Class Initialized
DEBUG - 2017-12-22 19:44:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:44:43 --> Config Class Initialized
INFO - 2017-12-22 19:44:43 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:44:43 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:44:43 --> Utf8 Class Initialized
INFO - 2017-12-22 19:44:43 --> URI Class Initialized
INFO - 2017-12-22 19:44:43 --> Router Class Initialized
INFO - 2017-12-22 19:44:43 --> Output Class Initialized
INFO - 2017-12-22 19:44:43 --> Security Class Initialized
DEBUG - 2017-12-22 19:44:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:44:43 --> Input Class Initialized
INFO - 2017-12-22 19:44:43 --> Language Class Initialized
INFO - 2017-12-22 19:44:43 --> Loader Class Initialized
INFO - 2017-12-22 19:44:43 --> Helper loaded: url_helper
INFO - 2017-12-22 19:44:43 --> Helper loaded: form_helper
INFO - 2017-12-22 19:44:43 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:44:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:44:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:44:43 --> Form Validation Class Initialized
INFO - 2017-12-22 19:44:43 --> Model Class Initialized
INFO - 2017-12-22 19:44:43 --> Controller Class Initialized
INFO - 2017-12-22 19:44:43 --> Model Class Initialized
INFO - 2017-12-22 19:44:43 --> Model Class Initialized
INFO - 2017-12-22 19:44:43 --> Model Class Initialized
DEBUG - 2017-12-22 19:44:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:44:43 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 19:44:43 --> Final output sent to browser
DEBUG - 2017-12-22 19:44:43 --> Total execution time: 0.0795
INFO - 2017-12-22 19:44:43 --> Config Class Initialized
INFO - 2017-12-22 19:44:43 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:44:43 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:44:43 --> Utf8 Class Initialized
INFO - 2017-12-22 19:44:43 --> URI Class Initialized
INFO - 2017-12-22 19:44:43 --> Router Class Initialized
INFO - 2017-12-22 19:44:43 --> Output Class Initialized
INFO - 2017-12-22 19:44:43 --> Security Class Initialized
DEBUG - 2017-12-22 19:44:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:44:43 --> Input Class Initialized
INFO - 2017-12-22 19:44:43 --> Language Class Initialized
ERROR - 2017-12-22 19:44:43 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-22 19:44:43 --> Config Class Initialized
INFO - 2017-12-22 19:44:43 --> Hooks Class Initialized
INFO - 2017-12-22 19:44:43 --> Config Class Initialized
INFO - 2017-12-22 19:44:43 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:44:43 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:44:43 --> Utf8 Class Initialized
INFO - 2017-12-22 19:44:43 --> URI Class Initialized
DEBUG - 2017-12-22 19:44:43 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:44:43 --> Utf8 Class Initialized
INFO - 2017-12-22 19:44:43 --> Router Class Initialized
INFO - 2017-12-22 19:44:43 --> URI Class Initialized
INFO - 2017-12-22 19:44:43 --> Output Class Initialized
INFO - 2017-12-22 19:44:43 --> Router Class Initialized
INFO - 2017-12-22 19:44:43 --> Security Class Initialized
INFO - 2017-12-22 19:44:43 --> Output Class Initialized
DEBUG - 2017-12-22 19:44:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:44:43 --> Security Class Initialized
INFO - 2017-12-22 19:44:43 --> Input Class Initialized
INFO - 2017-12-22 19:44:43 --> Language Class Initialized
DEBUG - 2017-12-22 19:44:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:44:43 --> Input Class Initialized
ERROR - 2017-12-22 19:44:43 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-22 19:44:43 --> Language Class Initialized
ERROR - 2017-12-22 19:44:43 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-22 19:44:44 --> Config Class Initialized
INFO - 2017-12-22 19:44:44 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:44:44 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:44:44 --> Utf8 Class Initialized
INFO - 2017-12-22 19:44:44 --> URI Class Initialized
INFO - 2017-12-22 19:44:44 --> Router Class Initialized
INFO - 2017-12-22 19:44:44 --> Output Class Initialized
INFO - 2017-12-22 19:44:44 --> Security Class Initialized
DEBUG - 2017-12-22 19:44:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:44:44 --> Input Class Initialized
INFO - 2017-12-22 19:44:44 --> Language Class Initialized
INFO - 2017-12-22 19:44:44 --> Loader Class Initialized
INFO - 2017-12-22 19:44:44 --> Helper loaded: url_helper
INFO - 2017-12-22 19:44:44 --> Helper loaded: form_helper
INFO - 2017-12-22 19:44:44 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:44:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:44:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:44:44 --> Form Validation Class Initialized
INFO - 2017-12-22 19:44:44 --> Model Class Initialized
INFO - 2017-12-22 19:44:44 --> Controller Class Initialized
INFO - 2017-12-22 19:44:44 --> Model Class Initialized
INFO - 2017-12-22 19:44:44 --> Model Class Initialized
INFO - 2017-12-22 19:44:44 --> Model Class Initialized
DEBUG - 2017-12-22 19:44:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:44:56 --> Config Class Initialized
INFO - 2017-12-22 19:44:56 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:44:56 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:44:56 --> Utf8 Class Initialized
INFO - 2017-12-22 19:44:56 --> URI Class Initialized
INFO - 2017-12-22 19:44:56 --> Router Class Initialized
INFO - 2017-12-22 19:44:56 --> Output Class Initialized
INFO - 2017-12-22 19:44:56 --> Security Class Initialized
DEBUG - 2017-12-22 19:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:44:56 --> Input Class Initialized
INFO - 2017-12-22 19:44:56 --> Language Class Initialized
INFO - 2017-12-22 19:44:56 --> Loader Class Initialized
INFO - 2017-12-22 19:44:56 --> Helper loaded: url_helper
INFO - 2017-12-22 19:44:56 --> Helper loaded: form_helper
INFO - 2017-12-22 19:44:56 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:44:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:44:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:44:56 --> Form Validation Class Initialized
INFO - 2017-12-22 19:44:56 --> Model Class Initialized
INFO - 2017-12-22 19:44:56 --> Controller Class Initialized
INFO - 2017-12-22 19:44:56 --> Model Class Initialized
INFO - 2017-12-22 19:44:56 --> Model Class Initialized
INFO - 2017-12-22 19:44:56 --> Model Class Initialized
DEBUG - 2017-12-22 19:44:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:44:56 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 19:44:56 --> Final output sent to browser
DEBUG - 2017-12-22 19:44:56 --> Total execution time: 0.0799
INFO - 2017-12-22 19:44:56 --> Config Class Initialized
INFO - 2017-12-22 19:44:56 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:44:56 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:44:56 --> Utf8 Class Initialized
INFO - 2017-12-22 19:44:56 --> URI Class Initialized
INFO - 2017-12-22 19:44:56 --> Router Class Initialized
INFO - 2017-12-22 19:44:56 --> Output Class Initialized
INFO - 2017-12-22 19:44:56 --> Security Class Initialized
DEBUG - 2017-12-22 19:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:44:56 --> Input Class Initialized
INFO - 2017-12-22 19:44:56 --> Language Class Initialized
ERROR - 2017-12-22 19:44:56 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-22 19:44:56 --> Config Class Initialized
INFO - 2017-12-22 19:44:56 --> Hooks Class Initialized
INFO - 2017-12-22 19:44:56 --> Config Class Initialized
INFO - 2017-12-22 19:44:56 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:44:56 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:44:56 --> Utf8 Class Initialized
DEBUG - 2017-12-22 19:44:56 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:44:56 --> Utf8 Class Initialized
INFO - 2017-12-22 19:44:56 --> URI Class Initialized
INFO - 2017-12-22 19:44:56 --> URI Class Initialized
INFO - 2017-12-22 19:44:56 --> Router Class Initialized
INFO - 2017-12-22 19:44:56 --> Output Class Initialized
INFO - 2017-12-22 19:44:56 --> Router Class Initialized
INFO - 2017-12-22 19:44:56 --> Security Class Initialized
INFO - 2017-12-22 19:44:56 --> Output Class Initialized
DEBUG - 2017-12-22 19:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:44:56 --> Input Class Initialized
INFO - 2017-12-22 19:44:56 --> Language Class Initialized
INFO - 2017-12-22 19:44:56 --> Security Class Initialized
ERROR - 2017-12-22 19:44:56 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2017-12-22 19:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:44:56 --> Input Class Initialized
INFO - 2017-12-22 19:44:56 --> Language Class Initialized
ERROR - 2017-12-22 19:44:56 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-22 19:44:56 --> Config Class Initialized
INFO - 2017-12-22 19:44:56 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:44:56 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:44:56 --> Utf8 Class Initialized
INFO - 2017-12-22 19:44:56 --> URI Class Initialized
INFO - 2017-12-22 19:44:56 --> Router Class Initialized
INFO - 2017-12-22 19:44:57 --> Output Class Initialized
INFO - 2017-12-22 19:44:57 --> Security Class Initialized
DEBUG - 2017-12-22 19:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:44:57 --> Input Class Initialized
INFO - 2017-12-22 19:44:57 --> Language Class Initialized
INFO - 2017-12-22 19:44:57 --> Loader Class Initialized
INFO - 2017-12-22 19:44:57 --> Helper loaded: url_helper
INFO - 2017-12-22 19:44:57 --> Helper loaded: form_helper
INFO - 2017-12-22 19:44:57 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:44:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:44:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:44:57 --> Form Validation Class Initialized
INFO - 2017-12-22 19:44:57 --> Model Class Initialized
INFO - 2017-12-22 19:44:57 --> Controller Class Initialized
INFO - 2017-12-22 19:44:57 --> Model Class Initialized
INFO - 2017-12-22 19:44:57 --> Model Class Initialized
INFO - 2017-12-22 19:44:57 --> Model Class Initialized
DEBUG - 2017-12-22 19:44:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:45:14 --> Config Class Initialized
INFO - 2017-12-22 19:45:14 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:45:14 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:45:14 --> Utf8 Class Initialized
INFO - 2017-12-22 19:45:14 --> URI Class Initialized
INFO - 2017-12-22 19:45:14 --> Router Class Initialized
INFO - 2017-12-22 19:45:14 --> Output Class Initialized
INFO - 2017-12-22 19:45:14 --> Security Class Initialized
DEBUG - 2017-12-22 19:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:45:14 --> Input Class Initialized
INFO - 2017-12-22 19:45:14 --> Language Class Initialized
INFO - 2017-12-22 19:45:14 --> Loader Class Initialized
INFO - 2017-12-22 19:45:14 --> Helper loaded: url_helper
INFO - 2017-12-22 19:45:14 --> Helper loaded: form_helper
INFO - 2017-12-22 19:45:14 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:45:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:45:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:45:14 --> Form Validation Class Initialized
INFO - 2017-12-22 19:45:14 --> Model Class Initialized
INFO - 2017-12-22 19:45:14 --> Controller Class Initialized
INFO - 2017-12-22 19:45:14 --> Model Class Initialized
INFO - 2017-12-22 19:45:14 --> Model Class Initialized
INFO - 2017-12-22 19:45:14 --> Model Class Initialized
DEBUG - 2017-12-22 19:45:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:45:14 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 19:45:14 --> Final output sent to browser
DEBUG - 2017-12-22 19:45:14 --> Total execution time: 0.0830
INFO - 2017-12-22 19:45:15 --> Config Class Initialized
INFO - 2017-12-22 19:45:15 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:45:15 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:45:15 --> Utf8 Class Initialized
INFO - 2017-12-22 19:45:15 --> URI Class Initialized
INFO - 2017-12-22 19:45:15 --> Router Class Initialized
INFO - 2017-12-22 19:45:15 --> Output Class Initialized
INFO - 2017-12-22 19:45:15 --> Security Class Initialized
DEBUG - 2017-12-22 19:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:45:15 --> Input Class Initialized
INFO - 2017-12-22 19:45:15 --> Language Class Initialized
ERROR - 2017-12-22 19:45:15 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-22 19:45:15 --> Config Class Initialized
INFO - 2017-12-22 19:45:15 --> Hooks Class Initialized
INFO - 2017-12-22 19:45:15 --> Config Class Initialized
INFO - 2017-12-22 19:45:15 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:45:15 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:45:15 --> Utf8 Class Initialized
DEBUG - 2017-12-22 19:45:15 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:45:15 --> Utf8 Class Initialized
INFO - 2017-12-22 19:45:15 --> URI Class Initialized
INFO - 2017-12-22 19:45:15 --> URI Class Initialized
INFO - 2017-12-22 19:45:15 --> Router Class Initialized
INFO - 2017-12-22 19:45:15 --> Router Class Initialized
INFO - 2017-12-22 19:45:15 --> Output Class Initialized
INFO - 2017-12-22 19:45:15 --> Output Class Initialized
INFO - 2017-12-22 19:45:15 --> Security Class Initialized
INFO - 2017-12-22 19:45:15 --> Security Class Initialized
DEBUG - 2017-12-22 19:45:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-22 19:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:45:15 --> Input Class Initialized
INFO - 2017-12-22 19:45:15 --> Input Class Initialized
INFO - 2017-12-22 19:45:15 --> Language Class Initialized
INFO - 2017-12-22 19:45:15 --> Language Class Initialized
ERROR - 2017-12-22 19:45:15 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-22 19:45:15 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-22 19:45:15 --> Config Class Initialized
INFO - 2017-12-22 19:45:15 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:45:15 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:45:15 --> Utf8 Class Initialized
INFO - 2017-12-22 19:45:15 --> URI Class Initialized
INFO - 2017-12-22 19:45:15 --> Router Class Initialized
INFO - 2017-12-22 19:45:15 --> Output Class Initialized
INFO - 2017-12-22 19:45:15 --> Security Class Initialized
DEBUG - 2017-12-22 19:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:45:15 --> Input Class Initialized
INFO - 2017-12-22 19:45:15 --> Language Class Initialized
INFO - 2017-12-22 19:45:15 --> Loader Class Initialized
INFO - 2017-12-22 19:45:15 --> Helper loaded: url_helper
INFO - 2017-12-22 19:45:15 --> Helper loaded: form_helper
INFO - 2017-12-22 19:45:15 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:45:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:45:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:45:15 --> Form Validation Class Initialized
INFO - 2017-12-22 19:45:15 --> Model Class Initialized
INFO - 2017-12-22 19:45:15 --> Controller Class Initialized
INFO - 2017-12-22 19:45:15 --> Model Class Initialized
INFO - 2017-12-22 19:45:15 --> Model Class Initialized
INFO - 2017-12-22 19:45:15 --> Model Class Initialized
DEBUG - 2017-12-22 19:45:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:45:52 --> Config Class Initialized
INFO - 2017-12-22 19:45:52 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:45:52 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:45:52 --> Utf8 Class Initialized
INFO - 2017-12-22 19:45:52 --> URI Class Initialized
INFO - 2017-12-22 19:45:52 --> Router Class Initialized
INFO - 2017-12-22 19:45:52 --> Output Class Initialized
INFO - 2017-12-22 19:45:52 --> Security Class Initialized
DEBUG - 2017-12-22 19:45:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:45:52 --> Input Class Initialized
INFO - 2017-12-22 19:45:52 --> Language Class Initialized
INFO - 2017-12-22 19:45:52 --> Loader Class Initialized
INFO - 2017-12-22 19:45:52 --> Helper loaded: url_helper
INFO - 2017-12-22 19:45:52 --> Helper loaded: form_helper
INFO - 2017-12-22 19:45:52 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:45:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:45:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:45:52 --> Form Validation Class Initialized
INFO - 2017-12-22 19:45:52 --> Model Class Initialized
INFO - 2017-12-22 19:45:52 --> Controller Class Initialized
INFO - 2017-12-22 19:45:52 --> Model Class Initialized
INFO - 2017-12-22 19:45:52 --> Model Class Initialized
INFO - 2017-12-22 19:45:52 --> Model Class Initialized
DEBUG - 2017-12-22 19:45:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:45:52 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 19:45:52 --> Final output sent to browser
DEBUG - 2017-12-22 19:45:52 --> Total execution time: 0.0627
INFO - 2017-12-22 19:45:52 --> Config Class Initialized
INFO - 2017-12-22 19:45:52 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:45:52 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:45:52 --> Utf8 Class Initialized
INFO - 2017-12-22 19:45:52 --> URI Class Initialized
INFO - 2017-12-22 19:45:52 --> Router Class Initialized
INFO - 2017-12-22 19:45:52 --> Output Class Initialized
INFO - 2017-12-22 19:45:52 --> Security Class Initialized
DEBUG - 2017-12-22 19:45:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:45:52 --> Input Class Initialized
INFO - 2017-12-22 19:45:52 --> Language Class Initialized
ERROR - 2017-12-22 19:45:52 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-22 19:45:52 --> Config Class Initialized
INFO - 2017-12-22 19:45:52 --> Hooks Class Initialized
INFO - 2017-12-22 19:45:52 --> Config Class Initialized
INFO - 2017-12-22 19:45:52 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:45:52 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:45:52 --> Utf8 Class Initialized
DEBUG - 2017-12-22 19:45:52 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:45:52 --> Utf8 Class Initialized
INFO - 2017-12-22 19:45:52 --> URI Class Initialized
INFO - 2017-12-22 19:45:52 --> URI Class Initialized
INFO - 2017-12-22 19:45:52 --> Router Class Initialized
INFO - 2017-12-22 19:45:52 --> Router Class Initialized
INFO - 2017-12-22 19:45:52 --> Output Class Initialized
INFO - 2017-12-22 19:45:52 --> Output Class Initialized
INFO - 2017-12-22 19:45:52 --> Security Class Initialized
INFO - 2017-12-22 19:45:52 --> Security Class Initialized
DEBUG - 2017-12-22 19:45:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-22 19:45:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:45:52 --> Input Class Initialized
INFO - 2017-12-22 19:45:52 --> Input Class Initialized
INFO - 2017-12-22 19:45:52 --> Language Class Initialized
INFO - 2017-12-22 19:45:52 --> Language Class Initialized
ERROR - 2017-12-22 19:45:52 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-22 19:45:52 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-22 19:45:52 --> Config Class Initialized
INFO - 2017-12-22 19:45:52 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:45:52 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:45:52 --> Utf8 Class Initialized
INFO - 2017-12-22 19:45:52 --> URI Class Initialized
INFO - 2017-12-22 19:45:52 --> Router Class Initialized
INFO - 2017-12-22 19:45:52 --> Output Class Initialized
INFO - 2017-12-22 19:45:52 --> Security Class Initialized
DEBUG - 2017-12-22 19:45:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:45:52 --> Input Class Initialized
INFO - 2017-12-22 19:45:52 --> Language Class Initialized
INFO - 2017-12-22 19:45:52 --> Loader Class Initialized
INFO - 2017-12-22 19:45:52 --> Helper loaded: url_helper
INFO - 2017-12-22 19:45:52 --> Helper loaded: form_helper
INFO - 2017-12-22 19:45:52 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:45:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:45:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:45:52 --> Form Validation Class Initialized
INFO - 2017-12-22 19:45:52 --> Model Class Initialized
INFO - 2017-12-22 19:45:52 --> Controller Class Initialized
INFO - 2017-12-22 19:45:52 --> Model Class Initialized
INFO - 2017-12-22 19:45:52 --> Model Class Initialized
INFO - 2017-12-22 19:45:52 --> Model Class Initialized
DEBUG - 2017-12-22 19:45:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:46:07 --> Config Class Initialized
INFO - 2017-12-22 19:46:07 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:46:07 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:46:07 --> Utf8 Class Initialized
INFO - 2017-12-22 19:46:07 --> URI Class Initialized
INFO - 2017-12-22 19:46:07 --> Router Class Initialized
INFO - 2017-12-22 19:46:07 --> Output Class Initialized
INFO - 2017-12-22 19:46:07 --> Security Class Initialized
DEBUG - 2017-12-22 19:46:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:46:07 --> Input Class Initialized
INFO - 2017-12-22 19:46:07 --> Language Class Initialized
INFO - 2017-12-22 19:46:07 --> Loader Class Initialized
INFO - 2017-12-22 19:46:07 --> Helper loaded: url_helper
INFO - 2017-12-22 19:46:07 --> Helper loaded: form_helper
INFO - 2017-12-22 19:46:07 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:46:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:46:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:46:07 --> Form Validation Class Initialized
INFO - 2017-12-22 19:46:07 --> Model Class Initialized
INFO - 2017-12-22 19:46:07 --> Controller Class Initialized
INFO - 2017-12-22 19:46:07 --> Model Class Initialized
INFO - 2017-12-22 19:46:07 --> Model Class Initialized
INFO - 2017-12-22 19:46:07 --> Model Class Initialized
DEBUG - 2017-12-22 19:46:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:46:07 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 19:46:07 --> Final output sent to browser
DEBUG - 2017-12-22 19:46:07 --> Total execution time: 0.0733
INFO - 2017-12-22 19:46:07 --> Config Class Initialized
INFO - 2017-12-22 19:46:07 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:46:07 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:46:07 --> Utf8 Class Initialized
INFO - 2017-12-22 19:46:07 --> URI Class Initialized
INFO - 2017-12-22 19:46:07 --> Router Class Initialized
INFO - 2017-12-22 19:46:07 --> Output Class Initialized
INFO - 2017-12-22 19:46:07 --> Security Class Initialized
DEBUG - 2017-12-22 19:46:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:46:07 --> Input Class Initialized
INFO - 2017-12-22 19:46:07 --> Language Class Initialized
ERROR - 2017-12-22 19:46:07 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-22 19:46:07 --> Config Class Initialized
INFO - 2017-12-22 19:46:07 --> Hooks Class Initialized
INFO - 2017-12-22 19:46:07 --> Config Class Initialized
INFO - 2017-12-22 19:46:07 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:46:07 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:46:07 --> Utf8 Class Initialized
DEBUG - 2017-12-22 19:46:07 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:46:07 --> Utf8 Class Initialized
INFO - 2017-12-22 19:46:07 --> URI Class Initialized
INFO - 2017-12-22 19:46:07 --> URI Class Initialized
INFO - 2017-12-22 19:46:07 --> Router Class Initialized
INFO - 2017-12-22 19:46:07 --> Router Class Initialized
INFO - 2017-12-22 19:46:07 --> Output Class Initialized
INFO - 2017-12-22 19:46:07 --> Security Class Initialized
INFO - 2017-12-22 19:46:07 --> Output Class Initialized
INFO - 2017-12-22 19:46:07 --> Security Class Initialized
DEBUG - 2017-12-22 19:46:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:46:07 --> Input Class Initialized
INFO - 2017-12-22 19:46:07 --> Language Class Initialized
DEBUG - 2017-12-22 19:46:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:46:07 --> Input Class Initialized
INFO - 2017-12-22 19:46:07 --> Language Class Initialized
ERROR - 2017-12-22 19:46:07 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-22 19:46:07 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-22 19:46:07 --> Config Class Initialized
INFO - 2017-12-22 19:46:07 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:46:07 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:46:07 --> Utf8 Class Initialized
INFO - 2017-12-22 19:46:07 --> URI Class Initialized
INFO - 2017-12-22 19:46:07 --> Router Class Initialized
INFO - 2017-12-22 19:46:07 --> Output Class Initialized
INFO - 2017-12-22 19:46:07 --> Security Class Initialized
DEBUG - 2017-12-22 19:46:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:46:07 --> Input Class Initialized
INFO - 2017-12-22 19:46:07 --> Language Class Initialized
INFO - 2017-12-22 19:46:07 --> Loader Class Initialized
INFO - 2017-12-22 19:46:07 --> Helper loaded: url_helper
INFO - 2017-12-22 19:46:07 --> Helper loaded: form_helper
INFO - 2017-12-22 19:46:07 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:46:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:46:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:46:07 --> Form Validation Class Initialized
INFO - 2017-12-22 19:46:07 --> Model Class Initialized
INFO - 2017-12-22 19:46:07 --> Controller Class Initialized
INFO - 2017-12-22 19:46:07 --> Model Class Initialized
INFO - 2017-12-22 19:46:07 --> Model Class Initialized
INFO - 2017-12-22 19:46:07 --> Model Class Initialized
DEBUG - 2017-12-22 19:46:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:47:19 --> Config Class Initialized
INFO - 2017-12-22 19:47:19 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:47:19 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:47:19 --> Utf8 Class Initialized
INFO - 2017-12-22 19:47:19 --> URI Class Initialized
INFO - 2017-12-22 19:47:19 --> Router Class Initialized
INFO - 2017-12-22 19:47:19 --> Output Class Initialized
INFO - 2017-12-22 19:47:19 --> Security Class Initialized
DEBUG - 2017-12-22 19:47:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:47:19 --> Input Class Initialized
INFO - 2017-12-22 19:47:19 --> Language Class Initialized
INFO - 2017-12-22 19:47:19 --> Loader Class Initialized
INFO - 2017-12-22 19:47:19 --> Helper loaded: url_helper
INFO - 2017-12-22 19:47:19 --> Helper loaded: form_helper
INFO - 2017-12-22 19:47:19 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:47:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:47:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:47:19 --> Form Validation Class Initialized
INFO - 2017-12-22 19:47:19 --> Model Class Initialized
INFO - 2017-12-22 19:47:19 --> Controller Class Initialized
INFO - 2017-12-22 19:47:19 --> Model Class Initialized
INFO - 2017-12-22 19:47:19 --> Model Class Initialized
INFO - 2017-12-22 19:47:19 --> Model Class Initialized
DEBUG - 2017-12-22 19:47:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:47:19 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 19:47:19 --> Final output sent to browser
DEBUG - 2017-12-22 19:47:19 --> Total execution time: 0.0577
INFO - 2017-12-22 19:47:19 --> Config Class Initialized
INFO - 2017-12-22 19:47:19 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:47:19 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:47:19 --> Utf8 Class Initialized
INFO - 2017-12-22 19:47:19 --> URI Class Initialized
INFO - 2017-12-22 19:47:19 --> Router Class Initialized
INFO - 2017-12-22 19:47:19 --> Output Class Initialized
INFO - 2017-12-22 19:47:19 --> Security Class Initialized
DEBUG - 2017-12-22 19:47:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:47:19 --> Input Class Initialized
INFO - 2017-12-22 19:47:19 --> Language Class Initialized
INFO - 2017-12-22 19:47:19 --> Loader Class Initialized
INFO - 2017-12-22 19:47:19 --> Helper loaded: url_helper
INFO - 2017-12-22 19:47:19 --> Helper loaded: form_helper
INFO - 2017-12-22 19:47:19 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:47:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:47:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:47:19 --> Form Validation Class Initialized
INFO - 2017-12-22 19:47:19 --> Model Class Initialized
INFO - 2017-12-22 19:47:19 --> Controller Class Initialized
INFO - 2017-12-22 19:47:19 --> Model Class Initialized
INFO - 2017-12-22 19:47:19 --> Model Class Initialized
INFO - 2017-12-22 19:47:19 --> Model Class Initialized
DEBUG - 2017-12-22 19:47:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:47:30 --> Config Class Initialized
INFO - 2017-12-22 19:47:30 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:47:30 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:47:30 --> Utf8 Class Initialized
INFO - 2017-12-22 19:47:30 --> URI Class Initialized
INFO - 2017-12-22 19:47:30 --> Router Class Initialized
INFO - 2017-12-22 19:47:30 --> Output Class Initialized
INFO - 2017-12-22 19:47:30 --> Security Class Initialized
DEBUG - 2017-12-22 19:47:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:47:30 --> Input Class Initialized
INFO - 2017-12-22 19:47:30 --> Language Class Initialized
INFO - 2017-12-22 19:47:30 --> Loader Class Initialized
INFO - 2017-12-22 19:47:30 --> Helper loaded: url_helper
INFO - 2017-12-22 19:47:30 --> Helper loaded: form_helper
INFO - 2017-12-22 19:47:30 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:47:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:47:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:47:30 --> Form Validation Class Initialized
INFO - 2017-12-22 19:47:30 --> Model Class Initialized
INFO - 2017-12-22 19:47:30 --> Controller Class Initialized
INFO - 2017-12-22 19:47:30 --> Model Class Initialized
INFO - 2017-12-22 19:47:30 --> Model Class Initialized
INFO - 2017-12-22 19:47:30 --> Model Class Initialized
DEBUG - 2017-12-22 19:47:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:47:31 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 19:47:31 --> Final output sent to browser
DEBUG - 2017-12-22 19:47:31 --> Total execution time: 0.3552
INFO - 2017-12-22 19:47:31 --> Config Class Initialized
INFO - 2017-12-22 19:47:31 --> Hooks Class Initialized
INFO - 2017-12-22 19:47:31 --> Config Class Initialized
INFO - 2017-12-22 19:47:31 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:47:31 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:47:31 --> Utf8 Class Initialized
DEBUG - 2017-12-22 19:47:31 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:47:31 --> Utf8 Class Initialized
INFO - 2017-12-22 19:47:31 --> URI Class Initialized
INFO - 2017-12-22 19:47:31 --> URI Class Initialized
INFO - 2017-12-22 19:47:31 --> Router Class Initialized
INFO - 2017-12-22 19:47:31 --> Router Class Initialized
INFO - 2017-12-22 19:47:31 --> Output Class Initialized
INFO - 2017-12-22 19:47:31 --> Output Class Initialized
INFO - 2017-12-22 19:47:31 --> Security Class Initialized
INFO - 2017-12-22 19:47:31 --> Security Class Initialized
DEBUG - 2017-12-22 19:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:47:31 --> Input Class Initialized
DEBUG - 2017-12-22 19:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:47:31 --> Language Class Initialized
INFO - 2017-12-22 19:47:31 --> Input Class Initialized
INFO - 2017-12-22 19:47:31 --> Language Class Initialized
INFO - 2017-12-22 19:47:31 --> Loader Class Initialized
INFO - 2017-12-22 19:47:31 --> Loader Class Initialized
INFO - 2017-12-22 19:47:31 --> Helper loaded: url_helper
INFO - 2017-12-22 19:47:31 --> Helper loaded: url_helper
INFO - 2017-12-22 19:47:31 --> Helper loaded: form_helper
INFO - 2017-12-22 19:47:31 --> Helper loaded: form_helper
INFO - 2017-12-22 19:47:31 --> Database Driver Class Initialized
INFO - 2017-12-22 19:47:31 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:47:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:47:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2017-12-22 19:47:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:47:31 --> Form Validation Class Initialized
INFO - 2017-12-22 19:47:31 --> Model Class Initialized
INFO - 2017-12-22 19:47:31 --> Controller Class Initialized
INFO - 2017-12-22 19:47:31 --> Model Class Initialized
INFO - 2017-12-22 19:47:31 --> Model Class Initialized
INFO - 2017-12-22 19:47:31 --> Model Class Initialized
DEBUG - 2017-12-22 19:47:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:47:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:47:31 --> Form Validation Class Initialized
INFO - 2017-12-22 19:47:31 --> Model Class Initialized
INFO - 2017-12-22 19:47:31 --> Controller Class Initialized
INFO - 2017-12-22 19:47:31 --> Model Class Initialized
INFO - 2017-12-22 19:47:31 --> Model Class Initialized
INFO - 2017-12-22 19:47:31 --> Model Class Initialized
DEBUG - 2017-12-22 19:47:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:47:32 --> Config Class Initialized
INFO - 2017-12-22 19:47:32 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:47:32 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:47:32 --> Utf8 Class Initialized
INFO - 2017-12-22 19:47:32 --> URI Class Initialized
INFO - 2017-12-22 19:47:32 --> Router Class Initialized
INFO - 2017-12-22 19:47:32 --> Output Class Initialized
INFO - 2017-12-22 19:47:32 --> Security Class Initialized
DEBUG - 2017-12-22 19:47:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:47:32 --> Input Class Initialized
INFO - 2017-12-22 19:47:32 --> Language Class Initialized
INFO - 2017-12-22 19:47:32 --> Loader Class Initialized
INFO - 2017-12-22 19:47:32 --> Helper loaded: url_helper
INFO - 2017-12-22 19:47:32 --> Helper loaded: form_helper
INFO - 2017-12-22 19:47:32 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:47:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:47:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:47:32 --> Form Validation Class Initialized
INFO - 2017-12-22 19:47:32 --> Model Class Initialized
INFO - 2017-12-22 19:47:32 --> Controller Class Initialized
INFO - 2017-12-22 19:47:32 --> Model Class Initialized
INFO - 2017-12-22 19:47:32 --> Model Class Initialized
INFO - 2017-12-22 19:47:32 --> Model Class Initialized
DEBUG - 2017-12-22 19:47:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:47:32 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 19:47:32 --> Final output sent to browser
DEBUG - 2017-12-22 19:47:32 --> Total execution time: 0.0568
INFO - 2017-12-22 19:47:32 --> Config Class Initialized
INFO - 2017-12-22 19:47:32 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:47:32 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:47:32 --> Utf8 Class Initialized
INFO - 2017-12-22 19:47:32 --> URI Class Initialized
INFO - 2017-12-22 19:47:32 --> Router Class Initialized
INFO - 2017-12-22 19:47:32 --> Output Class Initialized
INFO - 2017-12-22 19:47:32 --> Security Class Initialized
DEBUG - 2017-12-22 19:47:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:47:32 --> Input Class Initialized
INFO - 2017-12-22 19:47:32 --> Language Class Initialized
INFO - 2017-12-22 19:47:32 --> Loader Class Initialized
INFO - 2017-12-22 19:47:32 --> Helper loaded: url_helper
INFO - 2017-12-22 19:47:32 --> Helper loaded: form_helper
INFO - 2017-12-22 19:47:32 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:47:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:47:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:47:32 --> Form Validation Class Initialized
INFO - 2017-12-22 19:47:32 --> Model Class Initialized
INFO - 2017-12-22 19:47:32 --> Controller Class Initialized
INFO - 2017-12-22 19:47:32 --> Model Class Initialized
INFO - 2017-12-22 19:47:32 --> Model Class Initialized
INFO - 2017-12-22 19:47:32 --> Model Class Initialized
DEBUG - 2017-12-22 19:47:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:47:33 --> Config Class Initialized
INFO - 2017-12-22 19:47:33 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:47:33 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:47:33 --> Utf8 Class Initialized
INFO - 2017-12-22 19:47:33 --> URI Class Initialized
INFO - 2017-12-22 19:47:33 --> Router Class Initialized
INFO - 2017-12-22 19:47:33 --> Output Class Initialized
INFO - 2017-12-22 19:47:33 --> Security Class Initialized
DEBUG - 2017-12-22 19:47:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:47:33 --> Input Class Initialized
INFO - 2017-12-22 19:47:33 --> Language Class Initialized
INFO - 2017-12-22 19:47:33 --> Loader Class Initialized
INFO - 2017-12-22 19:47:33 --> Helper loaded: url_helper
INFO - 2017-12-22 19:47:33 --> Helper loaded: form_helper
INFO - 2017-12-22 19:47:33 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:47:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:47:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:47:33 --> Form Validation Class Initialized
INFO - 2017-12-22 19:47:33 --> Model Class Initialized
INFO - 2017-12-22 19:47:33 --> Controller Class Initialized
INFO - 2017-12-22 19:47:33 --> Model Class Initialized
INFO - 2017-12-22 19:47:33 --> Model Class Initialized
INFO - 2017-12-22 19:47:33 --> Model Class Initialized
DEBUG - 2017-12-22 19:47:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:47:33 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 19:47:33 --> Final output sent to browser
DEBUG - 2017-12-22 19:47:33 --> Total execution time: 0.0541
INFO - 2017-12-22 19:47:33 --> Config Class Initialized
INFO - 2017-12-22 19:47:33 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:47:33 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:47:33 --> Utf8 Class Initialized
INFO - 2017-12-22 19:47:33 --> URI Class Initialized
INFO - 2017-12-22 19:47:33 --> Router Class Initialized
INFO - 2017-12-22 19:47:33 --> Output Class Initialized
INFO - 2017-12-22 19:47:33 --> Security Class Initialized
DEBUG - 2017-12-22 19:47:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:47:33 --> Input Class Initialized
INFO - 2017-12-22 19:47:33 --> Language Class Initialized
INFO - 2017-12-22 19:47:33 --> Loader Class Initialized
INFO - 2017-12-22 19:47:33 --> Helper loaded: url_helper
INFO - 2017-12-22 19:47:33 --> Helper loaded: form_helper
INFO - 2017-12-22 19:47:33 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:47:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:47:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:47:33 --> Form Validation Class Initialized
INFO - 2017-12-22 19:47:33 --> Model Class Initialized
INFO - 2017-12-22 19:47:33 --> Controller Class Initialized
INFO - 2017-12-22 19:47:33 --> Model Class Initialized
INFO - 2017-12-22 19:47:33 --> Model Class Initialized
INFO - 2017-12-22 19:47:33 --> Model Class Initialized
DEBUG - 2017-12-22 19:47:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:47:34 --> Config Class Initialized
INFO - 2017-12-22 19:47:34 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:47:34 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:47:34 --> Utf8 Class Initialized
INFO - 2017-12-22 19:47:34 --> URI Class Initialized
INFO - 2017-12-22 19:47:34 --> Router Class Initialized
INFO - 2017-12-22 19:47:34 --> Output Class Initialized
INFO - 2017-12-22 19:47:34 --> Security Class Initialized
DEBUG - 2017-12-22 19:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:47:34 --> Input Class Initialized
INFO - 2017-12-22 19:47:34 --> Language Class Initialized
INFO - 2017-12-22 19:47:34 --> Loader Class Initialized
INFO - 2017-12-22 19:47:34 --> Helper loaded: url_helper
INFO - 2017-12-22 19:47:34 --> Helper loaded: form_helper
INFO - 2017-12-22 19:47:34 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:47:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:47:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:47:34 --> Form Validation Class Initialized
INFO - 2017-12-22 19:47:34 --> Model Class Initialized
INFO - 2017-12-22 19:47:34 --> Controller Class Initialized
INFO - 2017-12-22 19:47:34 --> Model Class Initialized
INFO - 2017-12-22 19:47:34 --> Model Class Initialized
INFO - 2017-12-22 19:47:34 --> Model Class Initialized
DEBUG - 2017-12-22 19:47:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:47:34 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 19:47:34 --> Final output sent to browser
DEBUG - 2017-12-22 19:47:34 --> Total execution time: 0.0550
INFO - 2017-12-22 19:47:34 --> Config Class Initialized
INFO - 2017-12-22 19:47:34 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:47:34 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:47:34 --> Utf8 Class Initialized
INFO - 2017-12-22 19:47:34 --> URI Class Initialized
INFO - 2017-12-22 19:47:34 --> Router Class Initialized
INFO - 2017-12-22 19:47:34 --> Output Class Initialized
INFO - 2017-12-22 19:47:34 --> Security Class Initialized
DEBUG - 2017-12-22 19:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:47:34 --> Input Class Initialized
INFO - 2017-12-22 19:47:34 --> Language Class Initialized
INFO - 2017-12-22 19:47:34 --> Loader Class Initialized
INFO - 2017-12-22 19:47:34 --> Helper loaded: url_helper
INFO - 2017-12-22 19:47:34 --> Helper loaded: form_helper
INFO - 2017-12-22 19:47:34 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:47:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:47:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:47:34 --> Form Validation Class Initialized
INFO - 2017-12-22 19:47:34 --> Model Class Initialized
INFO - 2017-12-22 19:47:34 --> Controller Class Initialized
INFO - 2017-12-22 19:47:34 --> Model Class Initialized
INFO - 2017-12-22 19:47:34 --> Model Class Initialized
INFO - 2017-12-22 19:47:34 --> Model Class Initialized
DEBUG - 2017-12-22 19:47:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:47:36 --> Config Class Initialized
INFO - 2017-12-22 19:47:36 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:47:36 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:47:36 --> Utf8 Class Initialized
INFO - 2017-12-22 19:47:36 --> URI Class Initialized
INFO - 2017-12-22 19:47:36 --> Router Class Initialized
INFO - 2017-12-22 19:47:36 --> Output Class Initialized
INFO - 2017-12-22 19:47:36 --> Security Class Initialized
DEBUG - 2017-12-22 19:47:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:47:36 --> Input Class Initialized
INFO - 2017-12-22 19:47:36 --> Language Class Initialized
INFO - 2017-12-22 19:47:36 --> Loader Class Initialized
INFO - 2017-12-22 19:47:36 --> Helper loaded: url_helper
INFO - 2017-12-22 19:47:36 --> Helper loaded: form_helper
INFO - 2017-12-22 19:47:36 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:47:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:47:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:47:36 --> Form Validation Class Initialized
INFO - 2017-12-22 19:47:36 --> Model Class Initialized
INFO - 2017-12-22 19:47:36 --> Controller Class Initialized
INFO - 2017-12-22 19:47:36 --> Model Class Initialized
INFO - 2017-12-22 19:47:36 --> Model Class Initialized
INFO - 2017-12-22 19:47:36 --> Model Class Initialized
DEBUG - 2017-12-22 19:47:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:47:36 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 19:47:36 --> Final output sent to browser
DEBUG - 2017-12-22 19:47:36 --> Total execution time: 0.0541
INFO - 2017-12-22 19:47:36 --> Config Class Initialized
INFO - 2017-12-22 19:47:36 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:47:36 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:47:36 --> Utf8 Class Initialized
INFO - 2017-12-22 19:47:36 --> URI Class Initialized
INFO - 2017-12-22 19:47:36 --> Router Class Initialized
INFO - 2017-12-22 19:47:36 --> Output Class Initialized
INFO - 2017-12-22 19:47:36 --> Security Class Initialized
DEBUG - 2017-12-22 19:47:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:47:36 --> Input Class Initialized
INFO - 2017-12-22 19:47:36 --> Language Class Initialized
INFO - 2017-12-22 19:47:36 --> Loader Class Initialized
INFO - 2017-12-22 19:47:36 --> Helper loaded: url_helper
INFO - 2017-12-22 19:47:36 --> Helper loaded: form_helper
INFO - 2017-12-22 19:47:36 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:47:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:47:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:47:36 --> Form Validation Class Initialized
INFO - 2017-12-22 19:47:36 --> Model Class Initialized
INFO - 2017-12-22 19:47:36 --> Controller Class Initialized
INFO - 2017-12-22 19:47:36 --> Model Class Initialized
INFO - 2017-12-22 19:47:36 --> Model Class Initialized
INFO - 2017-12-22 19:47:36 --> Model Class Initialized
DEBUG - 2017-12-22 19:47:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:47:37 --> Config Class Initialized
INFO - 2017-12-22 19:47:37 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:47:37 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:47:37 --> Utf8 Class Initialized
INFO - 2017-12-22 19:47:37 --> URI Class Initialized
INFO - 2017-12-22 19:47:37 --> Router Class Initialized
INFO - 2017-12-22 19:47:37 --> Output Class Initialized
INFO - 2017-12-22 19:47:37 --> Security Class Initialized
DEBUG - 2017-12-22 19:47:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:47:37 --> Input Class Initialized
INFO - 2017-12-22 19:47:37 --> Language Class Initialized
INFO - 2017-12-22 19:47:37 --> Loader Class Initialized
INFO - 2017-12-22 19:47:37 --> Helper loaded: url_helper
INFO - 2017-12-22 19:47:37 --> Helper loaded: form_helper
INFO - 2017-12-22 19:47:37 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:47:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:47:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:47:37 --> Form Validation Class Initialized
INFO - 2017-12-22 19:47:37 --> Model Class Initialized
INFO - 2017-12-22 19:47:37 --> Controller Class Initialized
INFO - 2017-12-22 19:47:37 --> Model Class Initialized
INFO - 2017-12-22 19:47:37 --> Model Class Initialized
INFO - 2017-12-22 19:47:37 --> Model Class Initialized
DEBUG - 2017-12-22 19:47:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:47:37 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 19:47:37 --> Final output sent to browser
DEBUG - 2017-12-22 19:47:37 --> Total execution time: 0.0633
INFO - 2017-12-22 19:47:37 --> Config Class Initialized
INFO - 2017-12-22 19:47:37 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:47:37 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:47:37 --> Utf8 Class Initialized
INFO - 2017-12-22 19:47:37 --> URI Class Initialized
INFO - 2017-12-22 19:47:37 --> Router Class Initialized
INFO - 2017-12-22 19:47:37 --> Output Class Initialized
INFO - 2017-12-22 19:47:37 --> Security Class Initialized
DEBUG - 2017-12-22 19:47:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:47:37 --> Input Class Initialized
INFO - 2017-12-22 19:47:37 --> Language Class Initialized
INFO - 2017-12-22 19:47:37 --> Loader Class Initialized
INFO - 2017-12-22 19:47:37 --> Helper loaded: url_helper
INFO - 2017-12-22 19:47:37 --> Helper loaded: form_helper
INFO - 2017-12-22 19:47:37 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:47:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:47:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:47:37 --> Form Validation Class Initialized
INFO - 2017-12-22 19:47:37 --> Model Class Initialized
INFO - 2017-12-22 19:47:37 --> Controller Class Initialized
INFO - 2017-12-22 19:47:37 --> Model Class Initialized
INFO - 2017-12-22 19:47:37 --> Model Class Initialized
INFO - 2017-12-22 19:47:37 --> Model Class Initialized
DEBUG - 2017-12-22 19:47:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:47:39 --> Config Class Initialized
INFO - 2017-12-22 19:47:39 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:47:39 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:47:39 --> Utf8 Class Initialized
INFO - 2017-12-22 19:47:39 --> URI Class Initialized
INFO - 2017-12-22 19:47:39 --> Router Class Initialized
INFO - 2017-12-22 19:47:39 --> Output Class Initialized
INFO - 2017-12-22 19:47:39 --> Security Class Initialized
DEBUG - 2017-12-22 19:47:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:47:39 --> Input Class Initialized
INFO - 2017-12-22 19:47:39 --> Language Class Initialized
INFO - 2017-12-22 19:47:39 --> Loader Class Initialized
INFO - 2017-12-22 19:47:39 --> Helper loaded: url_helper
INFO - 2017-12-22 19:47:39 --> Helper loaded: form_helper
INFO - 2017-12-22 19:47:39 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:47:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:47:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:47:39 --> Form Validation Class Initialized
INFO - 2017-12-22 19:47:39 --> Model Class Initialized
INFO - 2017-12-22 19:47:39 --> Controller Class Initialized
INFO - 2017-12-22 19:47:39 --> Model Class Initialized
INFO - 2017-12-22 19:47:39 --> Model Class Initialized
INFO - 2017-12-22 19:47:39 --> Model Class Initialized
DEBUG - 2017-12-22 19:47:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:47:39 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 19:47:39 --> Final output sent to browser
DEBUG - 2017-12-22 19:47:39 --> Total execution time: 0.0447
INFO - 2017-12-22 19:47:39 --> Config Class Initialized
INFO - 2017-12-22 19:47:39 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:47:39 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:47:39 --> Utf8 Class Initialized
INFO - 2017-12-22 19:47:39 --> URI Class Initialized
INFO - 2017-12-22 19:47:39 --> Router Class Initialized
INFO - 2017-12-22 19:47:39 --> Output Class Initialized
INFO - 2017-12-22 19:47:39 --> Security Class Initialized
DEBUG - 2017-12-22 19:47:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:47:39 --> Input Class Initialized
INFO - 2017-12-22 19:47:39 --> Language Class Initialized
INFO - 2017-12-22 19:47:39 --> Loader Class Initialized
INFO - 2017-12-22 19:47:39 --> Helper loaded: url_helper
INFO - 2017-12-22 19:47:39 --> Helper loaded: form_helper
INFO - 2017-12-22 19:47:39 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:47:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:47:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:47:39 --> Form Validation Class Initialized
INFO - 2017-12-22 19:47:39 --> Model Class Initialized
INFO - 2017-12-22 19:47:39 --> Controller Class Initialized
INFO - 2017-12-22 19:47:39 --> Model Class Initialized
INFO - 2017-12-22 19:47:39 --> Model Class Initialized
INFO - 2017-12-22 19:47:39 --> Model Class Initialized
DEBUG - 2017-12-22 19:47:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:47:41 --> Config Class Initialized
INFO - 2017-12-22 19:47:41 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:47:41 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:47:41 --> Utf8 Class Initialized
INFO - 2017-12-22 19:47:41 --> URI Class Initialized
INFO - 2017-12-22 19:47:41 --> Router Class Initialized
INFO - 2017-12-22 19:47:41 --> Output Class Initialized
INFO - 2017-12-22 19:47:41 --> Security Class Initialized
DEBUG - 2017-12-22 19:47:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:47:41 --> Input Class Initialized
INFO - 2017-12-22 19:47:41 --> Language Class Initialized
INFO - 2017-12-22 19:47:41 --> Loader Class Initialized
INFO - 2017-12-22 19:47:41 --> Helper loaded: url_helper
INFO - 2017-12-22 19:47:41 --> Helper loaded: form_helper
INFO - 2017-12-22 19:47:41 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:47:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:47:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:47:41 --> Form Validation Class Initialized
INFO - 2017-12-22 19:47:41 --> Model Class Initialized
INFO - 2017-12-22 19:47:41 --> Controller Class Initialized
INFO - 2017-12-22 19:47:41 --> Model Class Initialized
INFO - 2017-12-22 19:47:41 --> Model Class Initialized
INFO - 2017-12-22 19:47:41 --> Model Class Initialized
DEBUG - 2017-12-22 19:47:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:47:41 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 19:47:41 --> Final output sent to browser
DEBUG - 2017-12-22 19:47:41 --> Total execution time: 0.0517
INFO - 2017-12-22 19:47:41 --> Config Class Initialized
INFO - 2017-12-22 19:47:41 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:47:41 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:47:41 --> Utf8 Class Initialized
INFO - 2017-12-22 19:47:41 --> URI Class Initialized
INFO - 2017-12-22 19:47:41 --> Router Class Initialized
INFO - 2017-12-22 19:47:41 --> Output Class Initialized
INFO - 2017-12-22 19:47:41 --> Security Class Initialized
DEBUG - 2017-12-22 19:47:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:47:41 --> Input Class Initialized
INFO - 2017-12-22 19:47:41 --> Language Class Initialized
INFO - 2017-12-22 19:47:41 --> Loader Class Initialized
INFO - 2017-12-22 19:47:41 --> Helper loaded: url_helper
INFO - 2017-12-22 19:47:41 --> Helper loaded: form_helper
INFO - 2017-12-22 19:47:41 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:47:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:47:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:47:41 --> Form Validation Class Initialized
INFO - 2017-12-22 19:47:41 --> Model Class Initialized
INFO - 2017-12-22 19:47:41 --> Controller Class Initialized
INFO - 2017-12-22 19:47:41 --> Model Class Initialized
INFO - 2017-12-22 19:47:41 --> Model Class Initialized
INFO - 2017-12-22 19:47:41 --> Model Class Initialized
DEBUG - 2017-12-22 19:47:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:47:43 --> Config Class Initialized
INFO - 2017-12-22 19:47:43 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:47:43 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:47:43 --> Utf8 Class Initialized
INFO - 2017-12-22 19:47:43 --> URI Class Initialized
INFO - 2017-12-22 19:47:43 --> Router Class Initialized
INFO - 2017-12-22 19:47:43 --> Output Class Initialized
INFO - 2017-12-22 19:47:43 --> Security Class Initialized
DEBUG - 2017-12-22 19:47:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:47:43 --> Input Class Initialized
INFO - 2017-12-22 19:47:43 --> Language Class Initialized
INFO - 2017-12-22 19:47:43 --> Loader Class Initialized
INFO - 2017-12-22 19:47:43 --> Helper loaded: url_helper
INFO - 2017-12-22 19:47:43 --> Helper loaded: form_helper
INFO - 2017-12-22 19:47:43 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:47:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:47:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:47:43 --> Form Validation Class Initialized
INFO - 2017-12-22 19:47:43 --> Model Class Initialized
INFO - 2017-12-22 19:47:43 --> Controller Class Initialized
INFO - 2017-12-22 19:47:43 --> Model Class Initialized
INFO - 2017-12-22 19:47:43 --> Model Class Initialized
INFO - 2017-12-22 19:47:43 --> Model Class Initialized
DEBUG - 2017-12-22 19:47:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:47:43 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 19:47:43 --> Final output sent to browser
DEBUG - 2017-12-22 19:47:43 --> Total execution time: 0.0568
INFO - 2017-12-22 19:47:43 --> Config Class Initialized
INFO - 2017-12-22 19:47:43 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:47:43 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:47:43 --> Utf8 Class Initialized
INFO - 2017-12-22 19:47:43 --> URI Class Initialized
INFO - 2017-12-22 19:47:43 --> Router Class Initialized
INFO - 2017-12-22 19:47:43 --> Output Class Initialized
INFO - 2017-12-22 19:47:43 --> Security Class Initialized
DEBUG - 2017-12-22 19:47:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:47:43 --> Input Class Initialized
INFO - 2017-12-22 19:47:43 --> Language Class Initialized
INFO - 2017-12-22 19:47:43 --> Loader Class Initialized
INFO - 2017-12-22 19:47:43 --> Helper loaded: url_helper
INFO - 2017-12-22 19:47:43 --> Helper loaded: form_helper
INFO - 2017-12-22 19:47:43 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:47:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:47:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:47:43 --> Form Validation Class Initialized
INFO - 2017-12-22 19:47:43 --> Model Class Initialized
INFO - 2017-12-22 19:47:43 --> Controller Class Initialized
INFO - 2017-12-22 19:47:43 --> Model Class Initialized
INFO - 2017-12-22 19:47:43 --> Model Class Initialized
INFO - 2017-12-22 19:47:43 --> Model Class Initialized
DEBUG - 2017-12-22 19:47:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:47:47 --> Config Class Initialized
INFO - 2017-12-22 19:47:47 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:47:47 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:47:47 --> Utf8 Class Initialized
INFO - 2017-12-22 19:47:47 --> URI Class Initialized
INFO - 2017-12-22 19:47:47 --> Router Class Initialized
INFO - 2017-12-22 19:47:47 --> Output Class Initialized
INFO - 2017-12-22 19:47:47 --> Security Class Initialized
DEBUG - 2017-12-22 19:47:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:47:47 --> Input Class Initialized
INFO - 2017-12-22 19:47:47 --> Language Class Initialized
INFO - 2017-12-22 19:47:47 --> Loader Class Initialized
INFO - 2017-12-22 19:47:47 --> Helper loaded: url_helper
INFO - 2017-12-22 19:47:47 --> Helper loaded: form_helper
INFO - 2017-12-22 19:47:47 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:47:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:47:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:47:47 --> Form Validation Class Initialized
INFO - 2017-12-22 19:47:47 --> Model Class Initialized
INFO - 2017-12-22 19:47:47 --> Controller Class Initialized
INFO - 2017-12-22 19:47:47 --> Model Class Initialized
INFO - 2017-12-22 19:47:47 --> Model Class Initialized
INFO - 2017-12-22 19:47:47 --> Model Class Initialized
DEBUG - 2017-12-22 19:47:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:47:47 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 19:47:47 --> Final output sent to browser
DEBUG - 2017-12-22 19:47:47 --> Total execution time: 0.0618
INFO - 2017-12-22 19:47:47 --> Config Class Initialized
INFO - 2017-12-22 19:47:47 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:47:47 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:47:47 --> Utf8 Class Initialized
INFO - 2017-12-22 19:47:47 --> URI Class Initialized
INFO - 2017-12-22 19:47:47 --> Router Class Initialized
INFO - 2017-12-22 19:47:47 --> Output Class Initialized
INFO - 2017-12-22 19:47:47 --> Security Class Initialized
DEBUG - 2017-12-22 19:47:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:47:47 --> Input Class Initialized
INFO - 2017-12-22 19:47:47 --> Language Class Initialized
INFO - 2017-12-22 19:47:47 --> Loader Class Initialized
INFO - 2017-12-22 19:47:47 --> Helper loaded: url_helper
INFO - 2017-12-22 19:47:47 --> Helper loaded: form_helper
INFO - 2017-12-22 19:47:47 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:47:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:47:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:47:47 --> Form Validation Class Initialized
INFO - 2017-12-22 19:47:47 --> Model Class Initialized
INFO - 2017-12-22 19:47:47 --> Controller Class Initialized
INFO - 2017-12-22 19:47:47 --> Model Class Initialized
INFO - 2017-12-22 19:47:47 --> Model Class Initialized
INFO - 2017-12-22 19:47:47 --> Model Class Initialized
DEBUG - 2017-12-22 19:47:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:47:49 --> Config Class Initialized
INFO - 2017-12-22 19:47:49 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:47:49 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:47:49 --> Utf8 Class Initialized
INFO - 2017-12-22 19:47:49 --> URI Class Initialized
INFO - 2017-12-22 19:47:49 --> Router Class Initialized
INFO - 2017-12-22 19:47:49 --> Output Class Initialized
INFO - 2017-12-22 19:47:49 --> Security Class Initialized
DEBUG - 2017-12-22 19:47:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:47:49 --> Input Class Initialized
INFO - 2017-12-22 19:47:49 --> Language Class Initialized
INFO - 2017-12-22 19:47:49 --> Loader Class Initialized
INFO - 2017-12-22 19:47:49 --> Helper loaded: url_helper
INFO - 2017-12-22 19:47:49 --> Helper loaded: form_helper
INFO - 2017-12-22 19:47:49 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:47:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:47:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:47:49 --> Form Validation Class Initialized
INFO - 2017-12-22 19:47:49 --> Model Class Initialized
INFO - 2017-12-22 19:47:49 --> Controller Class Initialized
INFO - 2017-12-22 19:47:49 --> Model Class Initialized
INFO - 2017-12-22 19:47:49 --> Model Class Initialized
INFO - 2017-12-22 19:47:49 --> Model Class Initialized
DEBUG - 2017-12-22 19:47:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:47:49 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 19:47:49 --> Final output sent to browser
DEBUG - 2017-12-22 19:47:49 --> Total execution time: 0.0556
INFO - 2017-12-22 19:47:49 --> Config Class Initialized
INFO - 2017-12-22 19:47:49 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:47:49 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:47:49 --> Utf8 Class Initialized
INFO - 2017-12-22 19:47:49 --> URI Class Initialized
INFO - 2017-12-22 19:47:49 --> Router Class Initialized
INFO - 2017-12-22 19:47:49 --> Output Class Initialized
INFO - 2017-12-22 19:47:49 --> Security Class Initialized
DEBUG - 2017-12-22 19:47:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:47:49 --> Input Class Initialized
INFO - 2017-12-22 19:47:49 --> Language Class Initialized
INFO - 2017-12-22 19:47:49 --> Loader Class Initialized
INFO - 2017-12-22 19:47:49 --> Helper loaded: url_helper
INFO - 2017-12-22 19:47:49 --> Helper loaded: form_helper
INFO - 2017-12-22 19:47:49 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:47:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:47:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:47:49 --> Form Validation Class Initialized
INFO - 2017-12-22 19:47:49 --> Model Class Initialized
INFO - 2017-12-22 19:47:49 --> Controller Class Initialized
INFO - 2017-12-22 19:47:49 --> Model Class Initialized
INFO - 2017-12-22 19:47:49 --> Model Class Initialized
INFO - 2017-12-22 19:47:49 --> Model Class Initialized
DEBUG - 2017-12-22 19:47:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:47:51 --> Config Class Initialized
INFO - 2017-12-22 19:47:51 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:47:51 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:47:51 --> Utf8 Class Initialized
INFO - 2017-12-22 19:47:51 --> URI Class Initialized
INFO - 2017-12-22 19:47:51 --> Router Class Initialized
INFO - 2017-12-22 19:47:51 --> Output Class Initialized
INFO - 2017-12-22 19:47:51 --> Security Class Initialized
DEBUG - 2017-12-22 19:47:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:47:51 --> Input Class Initialized
INFO - 2017-12-22 19:47:51 --> Language Class Initialized
INFO - 2017-12-22 19:47:51 --> Loader Class Initialized
INFO - 2017-12-22 19:47:51 --> Helper loaded: url_helper
INFO - 2017-12-22 19:47:51 --> Helper loaded: form_helper
INFO - 2017-12-22 19:47:51 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:47:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:47:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:47:51 --> Form Validation Class Initialized
INFO - 2017-12-22 19:47:51 --> Model Class Initialized
INFO - 2017-12-22 19:47:51 --> Controller Class Initialized
INFO - 2017-12-22 19:47:51 --> Model Class Initialized
INFO - 2017-12-22 19:47:51 --> Model Class Initialized
INFO - 2017-12-22 19:47:51 --> Model Class Initialized
DEBUG - 2017-12-22 19:47:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:47:51 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 19:47:51 --> Final output sent to browser
DEBUG - 2017-12-22 19:47:51 --> Total execution time: 0.0692
INFO - 2017-12-22 19:47:51 --> Config Class Initialized
INFO - 2017-12-22 19:47:51 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:47:51 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:47:51 --> Utf8 Class Initialized
INFO - 2017-12-22 19:47:51 --> URI Class Initialized
INFO - 2017-12-22 19:47:51 --> Router Class Initialized
INFO - 2017-12-22 19:47:51 --> Output Class Initialized
INFO - 2017-12-22 19:47:51 --> Security Class Initialized
DEBUG - 2017-12-22 19:47:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:47:51 --> Input Class Initialized
INFO - 2017-12-22 19:47:51 --> Language Class Initialized
INFO - 2017-12-22 19:47:51 --> Loader Class Initialized
INFO - 2017-12-22 19:47:51 --> Helper loaded: url_helper
INFO - 2017-12-22 19:47:51 --> Helper loaded: form_helper
INFO - 2017-12-22 19:47:51 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:47:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:47:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:47:51 --> Form Validation Class Initialized
INFO - 2017-12-22 19:47:51 --> Model Class Initialized
INFO - 2017-12-22 19:47:51 --> Controller Class Initialized
INFO - 2017-12-22 19:47:51 --> Model Class Initialized
INFO - 2017-12-22 19:47:51 --> Model Class Initialized
INFO - 2017-12-22 19:47:51 --> Model Class Initialized
DEBUG - 2017-12-22 19:47:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:47:52 --> Config Class Initialized
INFO - 2017-12-22 19:47:52 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:47:52 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:47:52 --> Utf8 Class Initialized
INFO - 2017-12-22 19:47:52 --> URI Class Initialized
INFO - 2017-12-22 19:47:52 --> Router Class Initialized
INFO - 2017-12-22 19:47:52 --> Output Class Initialized
INFO - 2017-12-22 19:47:52 --> Security Class Initialized
DEBUG - 2017-12-22 19:47:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:47:52 --> Input Class Initialized
INFO - 2017-12-22 19:47:52 --> Language Class Initialized
INFO - 2017-12-22 19:47:52 --> Loader Class Initialized
INFO - 2017-12-22 19:47:52 --> Helper loaded: url_helper
INFO - 2017-12-22 19:47:52 --> Helper loaded: form_helper
INFO - 2017-12-22 19:47:52 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:47:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:47:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:47:52 --> Form Validation Class Initialized
INFO - 2017-12-22 19:47:52 --> Model Class Initialized
INFO - 2017-12-22 19:47:52 --> Controller Class Initialized
INFO - 2017-12-22 19:47:52 --> Model Class Initialized
INFO - 2017-12-22 19:47:52 --> Model Class Initialized
INFO - 2017-12-22 19:47:52 --> Model Class Initialized
DEBUG - 2017-12-22 19:47:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:47:52 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 19:47:52 --> Final output sent to browser
DEBUG - 2017-12-22 19:47:52 --> Total execution time: 0.0544
INFO - 2017-12-22 19:47:52 --> Config Class Initialized
INFO - 2017-12-22 19:47:52 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:47:52 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:47:52 --> Utf8 Class Initialized
INFO - 2017-12-22 19:47:52 --> URI Class Initialized
INFO - 2017-12-22 19:47:52 --> Router Class Initialized
INFO - 2017-12-22 19:47:52 --> Output Class Initialized
INFO - 2017-12-22 19:47:52 --> Security Class Initialized
DEBUG - 2017-12-22 19:47:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:47:52 --> Input Class Initialized
INFO - 2017-12-22 19:47:52 --> Language Class Initialized
INFO - 2017-12-22 19:47:52 --> Loader Class Initialized
INFO - 2017-12-22 19:47:52 --> Helper loaded: url_helper
INFO - 2017-12-22 19:47:52 --> Helper loaded: form_helper
INFO - 2017-12-22 19:47:52 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:47:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:47:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:47:52 --> Form Validation Class Initialized
INFO - 2017-12-22 19:47:52 --> Model Class Initialized
INFO - 2017-12-22 19:47:52 --> Controller Class Initialized
INFO - 2017-12-22 19:47:52 --> Model Class Initialized
INFO - 2017-12-22 19:47:52 --> Model Class Initialized
INFO - 2017-12-22 19:47:52 --> Model Class Initialized
DEBUG - 2017-12-22 19:47:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:47:53 --> Config Class Initialized
INFO - 2017-12-22 19:47:53 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:47:53 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:47:53 --> Utf8 Class Initialized
INFO - 2017-12-22 19:47:53 --> URI Class Initialized
INFO - 2017-12-22 19:47:53 --> Router Class Initialized
INFO - 2017-12-22 19:47:53 --> Output Class Initialized
INFO - 2017-12-22 19:47:53 --> Security Class Initialized
DEBUG - 2017-12-22 19:47:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:47:53 --> Input Class Initialized
INFO - 2017-12-22 19:47:53 --> Language Class Initialized
INFO - 2017-12-22 19:47:53 --> Loader Class Initialized
INFO - 2017-12-22 19:47:53 --> Helper loaded: url_helper
INFO - 2017-12-22 19:47:53 --> Helper loaded: form_helper
INFO - 2017-12-22 19:47:53 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:47:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:47:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:47:53 --> Form Validation Class Initialized
INFO - 2017-12-22 19:47:53 --> Model Class Initialized
INFO - 2017-12-22 19:47:53 --> Controller Class Initialized
INFO - 2017-12-22 19:47:53 --> Model Class Initialized
INFO - 2017-12-22 19:47:53 --> Model Class Initialized
INFO - 2017-12-22 19:47:53 --> Model Class Initialized
DEBUG - 2017-12-22 19:47:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:47:53 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 19:47:53 --> Final output sent to browser
DEBUG - 2017-12-22 19:47:53 --> Total execution time: 0.0589
INFO - 2017-12-22 19:47:53 --> Config Class Initialized
INFO - 2017-12-22 19:47:53 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:47:53 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:47:53 --> Utf8 Class Initialized
INFO - 2017-12-22 19:47:53 --> URI Class Initialized
INFO - 2017-12-22 19:47:53 --> Router Class Initialized
INFO - 2017-12-22 19:47:53 --> Output Class Initialized
INFO - 2017-12-22 19:47:53 --> Security Class Initialized
DEBUG - 2017-12-22 19:47:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:47:53 --> Input Class Initialized
INFO - 2017-12-22 19:47:53 --> Language Class Initialized
INFO - 2017-12-22 19:47:53 --> Loader Class Initialized
INFO - 2017-12-22 19:47:53 --> Helper loaded: url_helper
INFO - 2017-12-22 19:47:53 --> Helper loaded: form_helper
INFO - 2017-12-22 19:47:53 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:47:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:47:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:47:53 --> Form Validation Class Initialized
INFO - 2017-12-22 19:47:53 --> Model Class Initialized
INFO - 2017-12-22 19:47:53 --> Controller Class Initialized
INFO - 2017-12-22 19:47:53 --> Model Class Initialized
INFO - 2017-12-22 19:47:53 --> Model Class Initialized
INFO - 2017-12-22 19:47:53 --> Model Class Initialized
DEBUG - 2017-12-22 19:47:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:47:54 --> Config Class Initialized
INFO - 2017-12-22 19:47:54 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:47:54 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:47:54 --> Utf8 Class Initialized
INFO - 2017-12-22 19:47:54 --> URI Class Initialized
INFO - 2017-12-22 19:47:54 --> Router Class Initialized
INFO - 2017-12-22 19:47:54 --> Output Class Initialized
INFO - 2017-12-22 19:47:54 --> Security Class Initialized
DEBUG - 2017-12-22 19:47:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:47:54 --> Input Class Initialized
INFO - 2017-12-22 19:47:54 --> Language Class Initialized
INFO - 2017-12-22 19:47:54 --> Loader Class Initialized
INFO - 2017-12-22 19:47:54 --> Helper loaded: url_helper
INFO - 2017-12-22 19:47:54 --> Helper loaded: form_helper
INFO - 2017-12-22 19:47:54 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:47:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:47:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:47:54 --> Form Validation Class Initialized
INFO - 2017-12-22 19:47:54 --> Model Class Initialized
INFO - 2017-12-22 19:47:54 --> Controller Class Initialized
INFO - 2017-12-22 19:47:54 --> Model Class Initialized
INFO - 2017-12-22 19:47:54 --> Model Class Initialized
INFO - 2017-12-22 19:47:54 --> Model Class Initialized
DEBUG - 2017-12-22 19:47:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:47:54 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 19:47:54 --> Final output sent to browser
DEBUG - 2017-12-22 19:47:54 --> Total execution time: 0.0540
INFO - 2017-12-22 19:47:54 --> Config Class Initialized
INFO - 2017-12-22 19:47:54 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:47:54 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:47:54 --> Utf8 Class Initialized
INFO - 2017-12-22 19:47:54 --> URI Class Initialized
INFO - 2017-12-22 19:47:54 --> Router Class Initialized
INFO - 2017-12-22 19:47:54 --> Output Class Initialized
INFO - 2017-12-22 19:47:54 --> Security Class Initialized
DEBUG - 2017-12-22 19:47:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:47:54 --> Input Class Initialized
INFO - 2017-12-22 19:47:54 --> Language Class Initialized
INFO - 2017-12-22 19:47:54 --> Loader Class Initialized
INFO - 2017-12-22 19:47:54 --> Helper loaded: url_helper
INFO - 2017-12-22 19:47:54 --> Helper loaded: form_helper
INFO - 2017-12-22 19:47:54 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:47:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:47:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:47:54 --> Form Validation Class Initialized
INFO - 2017-12-22 19:47:54 --> Model Class Initialized
INFO - 2017-12-22 19:47:54 --> Controller Class Initialized
INFO - 2017-12-22 19:47:54 --> Model Class Initialized
INFO - 2017-12-22 19:47:54 --> Model Class Initialized
INFO - 2017-12-22 19:47:54 --> Model Class Initialized
DEBUG - 2017-12-22 19:47:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:47:55 --> Config Class Initialized
INFO - 2017-12-22 19:47:55 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:47:55 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:47:55 --> Utf8 Class Initialized
INFO - 2017-12-22 19:47:55 --> URI Class Initialized
INFO - 2017-12-22 19:47:55 --> Router Class Initialized
INFO - 2017-12-22 19:47:55 --> Output Class Initialized
INFO - 2017-12-22 19:47:55 --> Security Class Initialized
DEBUG - 2017-12-22 19:47:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:47:55 --> Input Class Initialized
INFO - 2017-12-22 19:47:55 --> Language Class Initialized
INFO - 2017-12-22 19:47:55 --> Loader Class Initialized
INFO - 2017-12-22 19:47:55 --> Helper loaded: url_helper
INFO - 2017-12-22 19:47:55 --> Helper loaded: form_helper
INFO - 2017-12-22 19:47:55 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:47:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:47:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:47:55 --> Form Validation Class Initialized
INFO - 2017-12-22 19:47:55 --> Model Class Initialized
INFO - 2017-12-22 19:47:55 --> Controller Class Initialized
INFO - 2017-12-22 19:47:55 --> Model Class Initialized
INFO - 2017-12-22 19:47:55 --> Model Class Initialized
INFO - 2017-12-22 19:47:55 --> Model Class Initialized
DEBUG - 2017-12-22 19:47:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:47:55 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 19:47:55 --> Final output sent to browser
DEBUG - 2017-12-22 19:47:55 --> Total execution time: 0.0625
INFO - 2017-12-22 19:47:56 --> Config Class Initialized
INFO - 2017-12-22 19:47:56 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:47:56 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:47:56 --> Utf8 Class Initialized
INFO - 2017-12-22 19:47:56 --> URI Class Initialized
INFO - 2017-12-22 19:47:56 --> Router Class Initialized
INFO - 2017-12-22 19:47:56 --> Output Class Initialized
INFO - 2017-12-22 19:47:56 --> Security Class Initialized
DEBUG - 2017-12-22 19:47:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:47:56 --> Input Class Initialized
INFO - 2017-12-22 19:47:56 --> Language Class Initialized
INFO - 2017-12-22 19:47:56 --> Loader Class Initialized
INFO - 2017-12-22 19:47:56 --> Helper loaded: url_helper
INFO - 2017-12-22 19:47:56 --> Helper loaded: form_helper
INFO - 2017-12-22 19:47:56 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:47:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:47:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:47:56 --> Form Validation Class Initialized
INFO - 2017-12-22 19:47:56 --> Model Class Initialized
INFO - 2017-12-22 19:47:56 --> Controller Class Initialized
INFO - 2017-12-22 19:47:56 --> Model Class Initialized
INFO - 2017-12-22 19:47:56 --> Model Class Initialized
INFO - 2017-12-22 19:47:56 --> Model Class Initialized
DEBUG - 2017-12-22 19:47:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:48:00 --> Config Class Initialized
INFO - 2017-12-22 19:48:00 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:48:00 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:48:00 --> Utf8 Class Initialized
INFO - 2017-12-22 19:48:00 --> URI Class Initialized
INFO - 2017-12-22 19:48:00 --> Router Class Initialized
INFO - 2017-12-22 19:48:00 --> Output Class Initialized
INFO - 2017-12-22 19:48:00 --> Security Class Initialized
DEBUG - 2017-12-22 19:48:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:48:00 --> Input Class Initialized
INFO - 2017-12-22 19:48:00 --> Language Class Initialized
INFO - 2017-12-22 19:48:00 --> Loader Class Initialized
INFO - 2017-12-22 19:48:00 --> Helper loaded: url_helper
INFO - 2017-12-22 19:48:00 --> Helper loaded: form_helper
INFO - 2017-12-22 19:48:00 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:48:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:48:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:48:00 --> Form Validation Class Initialized
INFO - 2017-12-22 19:48:00 --> Model Class Initialized
INFO - 2017-12-22 19:48:00 --> Controller Class Initialized
INFO - 2017-12-22 19:48:00 --> Model Class Initialized
INFO - 2017-12-22 19:48:00 --> Model Class Initialized
INFO - 2017-12-22 19:48:00 --> Model Class Initialized
DEBUG - 2017-12-22 19:48:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:48:00 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 19:48:00 --> Final output sent to browser
DEBUG - 2017-12-22 19:48:00 --> Total execution time: 0.0566
INFO - 2017-12-22 19:48:00 --> Config Class Initialized
INFO - 2017-12-22 19:48:00 --> Hooks Class Initialized
INFO - 2017-12-22 19:48:00 --> Config Class Initialized
INFO - 2017-12-22 19:48:00 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:48:00 --> UTF-8 Support Enabled
DEBUG - 2017-12-22 19:48:00 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:48:00 --> Utf8 Class Initialized
INFO - 2017-12-22 19:48:00 --> Utf8 Class Initialized
INFO - 2017-12-22 19:48:00 --> URI Class Initialized
INFO - 2017-12-22 19:48:00 --> URI Class Initialized
INFO - 2017-12-22 19:48:00 --> Router Class Initialized
INFO - 2017-12-22 19:48:00 --> Router Class Initialized
INFO - 2017-12-22 19:48:00 --> Output Class Initialized
INFO - 2017-12-22 19:48:00 --> Output Class Initialized
INFO - 2017-12-22 19:48:00 --> Security Class Initialized
INFO - 2017-12-22 19:48:00 --> Security Class Initialized
DEBUG - 2017-12-22 19:48:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:48:00 --> Input Class Initialized
DEBUG - 2017-12-22 19:48:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:48:00 --> Input Class Initialized
INFO - 2017-12-22 19:48:00 --> Language Class Initialized
INFO - 2017-12-22 19:48:00 --> Language Class Initialized
INFO - 2017-12-22 19:48:00 --> Loader Class Initialized
INFO - 2017-12-22 19:48:00 --> Loader Class Initialized
INFO - 2017-12-22 19:48:00 --> Helper loaded: url_helper
INFO - 2017-12-22 19:48:00 --> Helper loaded: url_helper
INFO - 2017-12-22 19:48:00 --> Helper loaded: form_helper
INFO - 2017-12-22 19:48:00 --> Helper loaded: form_helper
INFO - 2017-12-22 19:48:00 --> Database Driver Class Initialized
INFO - 2017-12-22 19:48:00 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:48:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2017-12-22 19:48:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:48:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:48:00 --> Form Validation Class Initialized
INFO - 2017-12-22 19:48:00 --> Model Class Initialized
INFO - 2017-12-22 19:48:00 --> Controller Class Initialized
INFO - 2017-12-22 19:48:00 --> Model Class Initialized
INFO - 2017-12-22 19:48:00 --> Model Class Initialized
INFO - 2017-12-22 19:48:00 --> Model Class Initialized
DEBUG - 2017-12-22 19:48:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:48:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:48:00 --> Form Validation Class Initialized
INFO - 2017-12-22 19:48:00 --> Model Class Initialized
INFO - 2017-12-22 19:48:00 --> Controller Class Initialized
INFO - 2017-12-22 19:48:00 --> Model Class Initialized
INFO - 2017-12-22 19:48:00 --> Model Class Initialized
INFO - 2017-12-22 19:48:00 --> Model Class Initialized
DEBUG - 2017-12-22 19:48:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:48:06 --> Config Class Initialized
INFO - 2017-12-22 19:48:06 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:48:06 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:48:06 --> Utf8 Class Initialized
INFO - 2017-12-22 19:48:06 --> URI Class Initialized
INFO - 2017-12-22 19:48:06 --> Router Class Initialized
INFO - 2017-12-22 19:48:06 --> Output Class Initialized
INFO - 2017-12-22 19:48:06 --> Security Class Initialized
DEBUG - 2017-12-22 19:48:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:48:06 --> Input Class Initialized
INFO - 2017-12-22 19:48:06 --> Language Class Initialized
INFO - 2017-12-22 19:48:06 --> Loader Class Initialized
INFO - 2017-12-22 19:48:06 --> Helper loaded: url_helper
INFO - 2017-12-22 19:48:06 --> Helper loaded: form_helper
INFO - 2017-12-22 19:48:06 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:48:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:48:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:48:06 --> Form Validation Class Initialized
INFO - 2017-12-22 19:48:06 --> Model Class Initialized
INFO - 2017-12-22 19:48:06 --> Controller Class Initialized
INFO - 2017-12-22 19:48:06 --> Model Class Initialized
INFO - 2017-12-22 19:48:06 --> Model Class Initialized
INFO - 2017-12-22 19:48:06 --> Model Class Initialized
DEBUG - 2017-12-22 19:48:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:48:06 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 19:48:06 --> Final output sent to browser
DEBUG - 2017-12-22 19:48:06 --> Total execution time: 0.0555
INFO - 2017-12-22 19:48:06 --> Config Class Initialized
INFO - 2017-12-22 19:48:06 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:48:06 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:48:06 --> Utf8 Class Initialized
INFO - 2017-12-22 19:48:06 --> URI Class Initialized
INFO - 2017-12-22 19:48:06 --> Router Class Initialized
INFO - 2017-12-22 19:48:06 --> Output Class Initialized
INFO - 2017-12-22 19:48:06 --> Security Class Initialized
DEBUG - 2017-12-22 19:48:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:48:06 --> Input Class Initialized
INFO - 2017-12-22 19:48:06 --> Language Class Initialized
INFO - 2017-12-22 19:48:06 --> Loader Class Initialized
INFO - 2017-12-22 19:48:06 --> Helper loaded: url_helper
INFO - 2017-12-22 19:48:06 --> Helper loaded: form_helper
INFO - 2017-12-22 19:48:06 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:48:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:48:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:48:06 --> Form Validation Class Initialized
INFO - 2017-12-22 19:48:06 --> Model Class Initialized
INFO - 2017-12-22 19:48:06 --> Controller Class Initialized
INFO - 2017-12-22 19:48:06 --> Model Class Initialized
INFO - 2017-12-22 19:48:06 --> Model Class Initialized
INFO - 2017-12-22 19:48:06 --> Model Class Initialized
DEBUG - 2017-12-22 19:48:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:48:07 --> Config Class Initialized
INFO - 2017-12-22 19:48:07 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:48:07 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:48:07 --> Utf8 Class Initialized
INFO - 2017-12-22 19:48:07 --> URI Class Initialized
INFO - 2017-12-22 19:48:07 --> Router Class Initialized
INFO - 2017-12-22 19:48:07 --> Output Class Initialized
INFO - 2017-12-22 19:48:07 --> Security Class Initialized
DEBUG - 2017-12-22 19:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:48:07 --> Input Class Initialized
INFO - 2017-12-22 19:48:07 --> Language Class Initialized
INFO - 2017-12-22 19:48:07 --> Loader Class Initialized
INFO - 2017-12-22 19:48:07 --> Helper loaded: url_helper
INFO - 2017-12-22 19:48:07 --> Helper loaded: form_helper
INFO - 2017-12-22 19:48:07 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:48:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:48:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:48:07 --> Form Validation Class Initialized
INFO - 2017-12-22 19:48:07 --> Model Class Initialized
INFO - 2017-12-22 19:48:07 --> Controller Class Initialized
INFO - 2017-12-22 19:48:07 --> Model Class Initialized
INFO - 2017-12-22 19:48:07 --> Model Class Initialized
INFO - 2017-12-22 19:48:07 --> Model Class Initialized
DEBUG - 2017-12-22 19:48:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:48:07 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 19:48:07 --> Final output sent to browser
DEBUG - 2017-12-22 19:48:07 --> Total execution time: 0.0559
INFO - 2017-12-22 19:48:07 --> Config Class Initialized
INFO - 2017-12-22 19:48:07 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:48:07 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:48:07 --> Utf8 Class Initialized
INFO - 2017-12-22 19:48:07 --> URI Class Initialized
INFO - 2017-12-22 19:48:07 --> Router Class Initialized
INFO - 2017-12-22 19:48:07 --> Output Class Initialized
INFO - 2017-12-22 19:48:07 --> Security Class Initialized
DEBUG - 2017-12-22 19:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:48:07 --> Input Class Initialized
INFO - 2017-12-22 19:48:07 --> Language Class Initialized
INFO - 2017-12-22 19:48:07 --> Loader Class Initialized
INFO - 2017-12-22 19:48:07 --> Helper loaded: url_helper
INFO - 2017-12-22 19:48:07 --> Helper loaded: form_helper
INFO - 2017-12-22 19:48:07 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:48:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:48:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:48:07 --> Form Validation Class Initialized
INFO - 2017-12-22 19:48:07 --> Model Class Initialized
INFO - 2017-12-22 19:48:07 --> Controller Class Initialized
INFO - 2017-12-22 19:48:07 --> Model Class Initialized
INFO - 2017-12-22 19:48:07 --> Model Class Initialized
INFO - 2017-12-22 19:48:07 --> Model Class Initialized
DEBUG - 2017-12-22 19:48:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:48:25 --> Config Class Initialized
INFO - 2017-12-22 19:48:25 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:48:25 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:48:25 --> Utf8 Class Initialized
INFO - 2017-12-22 19:48:25 --> URI Class Initialized
INFO - 2017-12-22 19:48:25 --> Router Class Initialized
INFO - 2017-12-22 19:48:25 --> Output Class Initialized
INFO - 2017-12-22 19:48:25 --> Security Class Initialized
DEBUG - 2017-12-22 19:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:48:25 --> Input Class Initialized
INFO - 2017-12-22 19:48:25 --> Language Class Initialized
INFO - 2017-12-22 19:48:25 --> Loader Class Initialized
INFO - 2017-12-22 19:48:25 --> Helper loaded: url_helper
INFO - 2017-12-22 19:48:25 --> Helper loaded: form_helper
INFO - 2017-12-22 19:48:25 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:48:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:48:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:48:25 --> Form Validation Class Initialized
INFO - 2017-12-22 19:48:25 --> Model Class Initialized
INFO - 2017-12-22 19:48:25 --> Controller Class Initialized
INFO - 2017-12-22 19:48:25 --> Model Class Initialized
INFO - 2017-12-22 19:48:25 --> Model Class Initialized
INFO - 2017-12-22 19:48:25 --> Model Class Initialized
DEBUG - 2017-12-22 19:48:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:48:25 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 19:48:25 --> Final output sent to browser
DEBUG - 2017-12-22 19:48:25 --> Total execution time: 0.0588
INFO - 2017-12-22 19:48:25 --> Config Class Initialized
INFO - 2017-12-22 19:48:25 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:48:25 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:48:25 --> Utf8 Class Initialized
INFO - 2017-12-22 19:48:25 --> URI Class Initialized
INFO - 2017-12-22 19:48:25 --> Router Class Initialized
INFO - 2017-12-22 19:48:25 --> Output Class Initialized
INFO - 2017-12-22 19:48:25 --> Security Class Initialized
DEBUG - 2017-12-22 19:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:48:25 --> Input Class Initialized
INFO - 2017-12-22 19:48:25 --> Language Class Initialized
INFO - 2017-12-22 19:48:25 --> Loader Class Initialized
INFO - 2017-12-22 19:48:25 --> Helper loaded: url_helper
INFO - 2017-12-22 19:48:25 --> Helper loaded: form_helper
INFO - 2017-12-22 19:48:25 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:48:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:48:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:48:25 --> Form Validation Class Initialized
INFO - 2017-12-22 19:48:25 --> Model Class Initialized
INFO - 2017-12-22 19:48:25 --> Controller Class Initialized
INFO - 2017-12-22 19:48:25 --> Model Class Initialized
INFO - 2017-12-22 19:48:25 --> Model Class Initialized
INFO - 2017-12-22 19:48:25 --> Model Class Initialized
DEBUG - 2017-12-22 19:48:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:48:27 --> Config Class Initialized
INFO - 2017-12-22 19:48:27 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:48:27 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:48:27 --> Utf8 Class Initialized
INFO - 2017-12-22 19:48:27 --> URI Class Initialized
INFO - 2017-12-22 19:48:27 --> Router Class Initialized
INFO - 2017-12-22 19:48:27 --> Output Class Initialized
INFO - 2017-12-22 19:48:27 --> Security Class Initialized
DEBUG - 2017-12-22 19:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:48:27 --> Input Class Initialized
INFO - 2017-12-22 19:48:27 --> Language Class Initialized
INFO - 2017-12-22 19:48:27 --> Loader Class Initialized
INFO - 2017-12-22 19:48:27 --> Helper loaded: url_helper
INFO - 2017-12-22 19:48:27 --> Helper loaded: form_helper
INFO - 2017-12-22 19:48:27 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:48:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:48:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:48:27 --> Form Validation Class Initialized
INFO - 2017-12-22 19:48:27 --> Model Class Initialized
INFO - 2017-12-22 19:48:27 --> Controller Class Initialized
INFO - 2017-12-22 19:48:27 --> Model Class Initialized
INFO - 2017-12-22 19:48:27 --> Model Class Initialized
INFO - 2017-12-22 19:48:27 --> Model Class Initialized
DEBUG - 2017-12-22 19:48:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:48:27 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 19:48:27 --> Final output sent to browser
DEBUG - 2017-12-22 19:48:27 --> Total execution time: 0.0452
INFO - 2017-12-22 19:48:27 --> Config Class Initialized
INFO - 2017-12-22 19:48:27 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:48:27 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:48:27 --> Utf8 Class Initialized
INFO - 2017-12-22 19:48:27 --> URI Class Initialized
INFO - 2017-12-22 19:48:27 --> Router Class Initialized
INFO - 2017-12-22 19:48:27 --> Output Class Initialized
INFO - 2017-12-22 19:48:27 --> Security Class Initialized
DEBUG - 2017-12-22 19:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:48:27 --> Input Class Initialized
INFO - 2017-12-22 19:48:27 --> Language Class Initialized
INFO - 2017-12-22 19:48:27 --> Loader Class Initialized
INFO - 2017-12-22 19:48:27 --> Helper loaded: url_helper
INFO - 2017-12-22 19:48:27 --> Helper loaded: form_helper
INFO - 2017-12-22 19:48:27 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:48:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:48:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:48:27 --> Form Validation Class Initialized
INFO - 2017-12-22 19:48:27 --> Model Class Initialized
INFO - 2017-12-22 19:48:27 --> Controller Class Initialized
INFO - 2017-12-22 19:48:27 --> Model Class Initialized
INFO - 2017-12-22 19:48:27 --> Model Class Initialized
INFO - 2017-12-22 19:48:27 --> Model Class Initialized
DEBUG - 2017-12-22 19:48:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:48:29 --> Config Class Initialized
INFO - 2017-12-22 19:48:29 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:48:29 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:48:29 --> Utf8 Class Initialized
INFO - 2017-12-22 19:48:29 --> URI Class Initialized
INFO - 2017-12-22 19:48:29 --> Router Class Initialized
INFO - 2017-12-22 19:48:29 --> Output Class Initialized
INFO - 2017-12-22 19:48:29 --> Security Class Initialized
DEBUG - 2017-12-22 19:48:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:48:29 --> Input Class Initialized
INFO - 2017-12-22 19:48:29 --> Language Class Initialized
INFO - 2017-12-22 19:48:29 --> Loader Class Initialized
INFO - 2017-12-22 19:48:29 --> Helper loaded: url_helper
INFO - 2017-12-22 19:48:29 --> Helper loaded: form_helper
INFO - 2017-12-22 19:48:29 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:48:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:48:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:48:29 --> Form Validation Class Initialized
INFO - 2017-12-22 19:48:29 --> Model Class Initialized
INFO - 2017-12-22 19:48:29 --> Controller Class Initialized
INFO - 2017-12-22 19:48:29 --> Model Class Initialized
INFO - 2017-12-22 19:48:29 --> Model Class Initialized
INFO - 2017-12-22 19:48:29 --> Model Class Initialized
DEBUG - 2017-12-22 19:48:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:48:29 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 19:48:29 --> Final output sent to browser
DEBUG - 2017-12-22 19:48:29 --> Total execution time: 0.0483
INFO - 2017-12-22 19:48:29 --> Config Class Initialized
INFO - 2017-12-22 19:48:29 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:48:29 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:48:29 --> Utf8 Class Initialized
INFO - 2017-12-22 19:48:29 --> URI Class Initialized
INFO - 2017-12-22 19:48:29 --> Router Class Initialized
INFO - 2017-12-22 19:48:29 --> Output Class Initialized
INFO - 2017-12-22 19:48:29 --> Security Class Initialized
DEBUG - 2017-12-22 19:48:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:48:29 --> Input Class Initialized
INFO - 2017-12-22 19:48:29 --> Language Class Initialized
INFO - 2017-12-22 19:48:29 --> Loader Class Initialized
INFO - 2017-12-22 19:48:29 --> Helper loaded: url_helper
INFO - 2017-12-22 19:48:29 --> Helper loaded: form_helper
INFO - 2017-12-22 19:48:29 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:48:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:48:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:48:29 --> Form Validation Class Initialized
INFO - 2017-12-22 19:48:29 --> Model Class Initialized
INFO - 2017-12-22 19:48:29 --> Controller Class Initialized
INFO - 2017-12-22 19:48:29 --> Model Class Initialized
INFO - 2017-12-22 19:48:29 --> Model Class Initialized
INFO - 2017-12-22 19:48:29 --> Model Class Initialized
DEBUG - 2017-12-22 19:48:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:48:34 --> Config Class Initialized
INFO - 2017-12-22 19:48:34 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:48:34 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:48:34 --> Utf8 Class Initialized
INFO - 2017-12-22 19:48:34 --> URI Class Initialized
INFO - 2017-12-22 19:48:34 --> Router Class Initialized
INFO - 2017-12-22 19:48:34 --> Output Class Initialized
INFO - 2017-12-22 19:48:34 --> Security Class Initialized
DEBUG - 2017-12-22 19:48:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:48:34 --> Input Class Initialized
INFO - 2017-12-22 19:48:34 --> Language Class Initialized
INFO - 2017-12-22 19:48:34 --> Loader Class Initialized
INFO - 2017-12-22 19:48:34 --> Helper loaded: url_helper
INFO - 2017-12-22 19:48:34 --> Helper loaded: form_helper
INFO - 2017-12-22 19:48:34 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:48:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:48:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:48:34 --> Form Validation Class Initialized
INFO - 2017-12-22 19:48:34 --> Model Class Initialized
INFO - 2017-12-22 19:48:34 --> Controller Class Initialized
INFO - 2017-12-22 19:48:34 --> Model Class Initialized
INFO - 2017-12-22 19:48:34 --> Model Class Initialized
INFO - 2017-12-22 19:48:34 --> Model Class Initialized
DEBUG - 2017-12-22 19:48:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:48:34 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 19:48:34 --> Final output sent to browser
DEBUG - 2017-12-22 19:48:34 --> Total execution time: 0.0589
INFO - 2017-12-22 19:48:34 --> Config Class Initialized
INFO - 2017-12-22 19:48:34 --> Hooks Class Initialized
INFO - 2017-12-22 19:48:34 --> Config Class Initialized
INFO - 2017-12-22 19:48:34 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:48:34 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:48:34 --> Utf8 Class Initialized
DEBUG - 2017-12-22 19:48:34 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:48:34 --> Utf8 Class Initialized
INFO - 2017-12-22 19:48:34 --> URI Class Initialized
INFO - 2017-12-22 19:48:34 --> URI Class Initialized
INFO - 2017-12-22 19:48:34 --> Router Class Initialized
INFO - 2017-12-22 19:48:34 --> Router Class Initialized
INFO - 2017-12-22 19:48:34 --> Output Class Initialized
INFO - 2017-12-22 19:48:34 --> Output Class Initialized
INFO - 2017-12-22 19:48:34 --> Security Class Initialized
INFO - 2017-12-22 19:48:34 --> Security Class Initialized
DEBUG - 2017-12-22 19:48:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:48:34 --> Input Class Initialized
DEBUG - 2017-12-22 19:48:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:48:34 --> Language Class Initialized
INFO - 2017-12-22 19:48:34 --> Input Class Initialized
INFO - 2017-12-22 19:48:34 --> Language Class Initialized
INFO - 2017-12-22 19:48:34 --> Loader Class Initialized
INFO - 2017-12-22 19:48:34 --> Loader Class Initialized
INFO - 2017-12-22 19:48:34 --> Helper loaded: url_helper
INFO - 2017-12-22 19:48:34 --> Helper loaded: url_helper
INFO - 2017-12-22 19:48:34 --> Helper loaded: form_helper
INFO - 2017-12-22 19:48:34 --> Helper loaded: form_helper
INFO - 2017-12-22 19:48:34 --> Database Driver Class Initialized
INFO - 2017-12-22 19:48:34 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:48:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2017-12-22 19:48:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:48:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:48:34 --> Form Validation Class Initialized
INFO - 2017-12-22 19:48:34 --> Model Class Initialized
INFO - 2017-12-22 19:48:34 --> Controller Class Initialized
INFO - 2017-12-22 19:48:34 --> Model Class Initialized
INFO - 2017-12-22 19:48:34 --> Model Class Initialized
INFO - 2017-12-22 19:48:34 --> Model Class Initialized
DEBUG - 2017-12-22 19:48:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:48:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:48:34 --> Form Validation Class Initialized
INFO - 2017-12-22 19:48:34 --> Model Class Initialized
INFO - 2017-12-22 19:48:34 --> Controller Class Initialized
INFO - 2017-12-22 19:48:34 --> Model Class Initialized
INFO - 2017-12-22 19:48:34 --> Model Class Initialized
INFO - 2017-12-22 19:48:34 --> Model Class Initialized
DEBUG - 2017-12-22 19:48:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:48:56 --> Config Class Initialized
INFO - 2017-12-22 19:48:56 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:48:56 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:48:56 --> Utf8 Class Initialized
INFO - 2017-12-22 19:48:56 --> URI Class Initialized
INFO - 2017-12-22 19:48:56 --> Router Class Initialized
INFO - 2017-12-22 19:48:56 --> Output Class Initialized
INFO - 2017-12-22 19:48:56 --> Security Class Initialized
DEBUG - 2017-12-22 19:48:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:48:56 --> Input Class Initialized
INFO - 2017-12-22 19:48:56 --> Language Class Initialized
INFO - 2017-12-22 19:48:56 --> Loader Class Initialized
INFO - 2017-12-22 19:48:56 --> Helper loaded: url_helper
INFO - 2017-12-22 19:48:56 --> Helper loaded: form_helper
INFO - 2017-12-22 19:48:56 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:48:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:48:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:48:56 --> Form Validation Class Initialized
INFO - 2017-12-22 19:48:56 --> Model Class Initialized
INFO - 2017-12-22 19:48:56 --> Controller Class Initialized
INFO - 2017-12-22 19:48:56 --> Model Class Initialized
INFO - 2017-12-22 19:48:56 --> Model Class Initialized
INFO - 2017-12-22 19:48:56 --> Model Class Initialized
DEBUG - 2017-12-22 19:48:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:48:56 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 19:48:56 --> Final output sent to browser
DEBUG - 2017-12-22 19:48:56 --> Total execution time: 0.2870
INFO - 2017-12-22 19:48:57 --> Config Class Initialized
INFO - 2017-12-22 19:48:57 --> Hooks Class Initialized
INFO - 2017-12-22 19:48:57 --> Config Class Initialized
INFO - 2017-12-22 19:48:57 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:48:57 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:48:57 --> Utf8 Class Initialized
DEBUG - 2017-12-22 19:48:57 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:48:57 --> Utf8 Class Initialized
INFO - 2017-12-22 19:48:57 --> URI Class Initialized
INFO - 2017-12-22 19:48:57 --> URI Class Initialized
INFO - 2017-12-22 19:48:57 --> Router Class Initialized
INFO - 2017-12-22 19:48:57 --> Router Class Initialized
INFO - 2017-12-22 19:48:57 --> Output Class Initialized
INFO - 2017-12-22 19:48:57 --> Output Class Initialized
INFO - 2017-12-22 19:48:57 --> Security Class Initialized
INFO - 2017-12-22 19:48:57 --> Security Class Initialized
DEBUG - 2017-12-22 19:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:48:57 --> Input Class Initialized
DEBUG - 2017-12-22 19:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:48:57 --> Input Class Initialized
INFO - 2017-12-22 19:48:57 --> Language Class Initialized
INFO - 2017-12-22 19:48:57 --> Language Class Initialized
INFO - 2017-12-22 19:48:57 --> Loader Class Initialized
INFO - 2017-12-22 19:48:57 --> Loader Class Initialized
INFO - 2017-12-22 19:48:57 --> Helper loaded: url_helper
INFO - 2017-12-22 19:48:57 --> Helper loaded: url_helper
INFO - 2017-12-22 19:48:57 --> Helper loaded: form_helper
INFO - 2017-12-22 19:48:57 --> Helper loaded: form_helper
INFO - 2017-12-22 19:48:57 --> Database Driver Class Initialized
INFO - 2017-12-22 19:48:57 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:48:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2017-12-22 19:48:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:48:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:48:57 --> Form Validation Class Initialized
INFO - 2017-12-22 19:48:57 --> Model Class Initialized
INFO - 2017-12-22 19:48:57 --> Controller Class Initialized
INFO - 2017-12-22 19:48:57 --> Model Class Initialized
INFO - 2017-12-22 19:48:57 --> Model Class Initialized
INFO - 2017-12-22 19:48:57 --> Model Class Initialized
DEBUG - 2017-12-22 19:48:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:48:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:48:57 --> Form Validation Class Initialized
INFO - 2017-12-22 19:48:57 --> Model Class Initialized
INFO - 2017-12-22 19:48:57 --> Controller Class Initialized
INFO - 2017-12-22 19:48:57 --> Model Class Initialized
INFO - 2017-12-22 19:48:57 --> Model Class Initialized
INFO - 2017-12-22 19:48:57 --> Model Class Initialized
DEBUG - 2017-12-22 19:48:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:48:59 --> Config Class Initialized
INFO - 2017-12-22 19:48:59 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:48:59 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:48:59 --> Utf8 Class Initialized
INFO - 2017-12-22 19:48:59 --> URI Class Initialized
INFO - 2017-12-22 19:48:59 --> Router Class Initialized
INFO - 2017-12-22 19:48:59 --> Output Class Initialized
INFO - 2017-12-22 19:48:59 --> Security Class Initialized
DEBUG - 2017-12-22 19:48:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:48:59 --> Input Class Initialized
INFO - 2017-12-22 19:48:59 --> Language Class Initialized
INFO - 2017-12-22 19:48:59 --> Loader Class Initialized
INFO - 2017-12-22 19:48:59 --> Helper loaded: url_helper
INFO - 2017-12-22 19:48:59 --> Helper loaded: form_helper
INFO - 2017-12-22 19:48:59 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:48:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:48:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:48:59 --> Form Validation Class Initialized
INFO - 2017-12-22 19:48:59 --> Model Class Initialized
INFO - 2017-12-22 19:48:59 --> Controller Class Initialized
INFO - 2017-12-22 19:48:59 --> Model Class Initialized
INFO - 2017-12-22 19:48:59 --> Model Class Initialized
INFO - 2017-12-22 19:48:59 --> Model Class Initialized
DEBUG - 2017-12-22 19:48:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:48:59 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 19:48:59 --> Final output sent to browser
DEBUG - 2017-12-22 19:48:59 --> Total execution time: 0.0556
INFO - 2017-12-22 19:48:59 --> Config Class Initialized
INFO - 2017-12-22 19:48:59 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:48:59 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:48:59 --> Utf8 Class Initialized
INFO - 2017-12-22 19:48:59 --> URI Class Initialized
INFO - 2017-12-22 19:48:59 --> Router Class Initialized
INFO - 2017-12-22 19:48:59 --> Output Class Initialized
INFO - 2017-12-22 19:48:59 --> Security Class Initialized
DEBUG - 2017-12-22 19:48:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:48:59 --> Input Class Initialized
INFO - 2017-12-22 19:48:59 --> Language Class Initialized
INFO - 2017-12-22 19:48:59 --> Loader Class Initialized
INFO - 2017-12-22 19:48:59 --> Helper loaded: url_helper
INFO - 2017-12-22 19:48:59 --> Helper loaded: form_helper
INFO - 2017-12-22 19:48:59 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:48:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:48:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:48:59 --> Form Validation Class Initialized
INFO - 2017-12-22 19:48:59 --> Model Class Initialized
INFO - 2017-12-22 19:48:59 --> Controller Class Initialized
INFO - 2017-12-22 19:48:59 --> Model Class Initialized
INFO - 2017-12-22 19:48:59 --> Model Class Initialized
INFO - 2017-12-22 19:48:59 --> Model Class Initialized
DEBUG - 2017-12-22 19:48:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:49:01 --> Config Class Initialized
INFO - 2017-12-22 19:49:01 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:49:01 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:49:01 --> Utf8 Class Initialized
INFO - 2017-12-22 19:49:01 --> URI Class Initialized
INFO - 2017-12-22 19:49:01 --> Router Class Initialized
INFO - 2017-12-22 19:49:01 --> Output Class Initialized
INFO - 2017-12-22 19:49:01 --> Security Class Initialized
DEBUG - 2017-12-22 19:49:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:49:01 --> Input Class Initialized
INFO - 2017-12-22 19:49:01 --> Language Class Initialized
INFO - 2017-12-22 19:49:01 --> Loader Class Initialized
INFO - 2017-12-22 19:49:01 --> Helper loaded: url_helper
INFO - 2017-12-22 19:49:01 --> Helper loaded: form_helper
INFO - 2017-12-22 19:49:01 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:49:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:49:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:49:01 --> Form Validation Class Initialized
INFO - 2017-12-22 19:49:01 --> Model Class Initialized
INFO - 2017-12-22 19:49:01 --> Controller Class Initialized
INFO - 2017-12-22 19:49:01 --> Model Class Initialized
INFO - 2017-12-22 19:49:01 --> Model Class Initialized
INFO - 2017-12-22 19:49:01 --> Model Class Initialized
DEBUG - 2017-12-22 19:49:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:49:01 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 19:49:01 --> Final output sent to browser
DEBUG - 2017-12-22 19:49:01 --> Total execution time: 0.0555
INFO - 2017-12-22 19:49:01 --> Config Class Initialized
INFO - 2017-12-22 19:49:01 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:49:01 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:49:01 --> Utf8 Class Initialized
INFO - 2017-12-22 19:49:01 --> URI Class Initialized
INFO - 2017-12-22 19:49:01 --> Router Class Initialized
INFO - 2017-12-22 19:49:01 --> Output Class Initialized
INFO - 2017-12-22 19:49:01 --> Security Class Initialized
DEBUG - 2017-12-22 19:49:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:49:01 --> Input Class Initialized
INFO - 2017-12-22 19:49:01 --> Language Class Initialized
INFO - 2017-12-22 19:49:01 --> Loader Class Initialized
INFO - 2017-12-22 19:49:01 --> Helper loaded: url_helper
INFO - 2017-12-22 19:49:01 --> Helper loaded: form_helper
INFO - 2017-12-22 19:49:01 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:49:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:49:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:49:01 --> Form Validation Class Initialized
INFO - 2017-12-22 19:49:01 --> Model Class Initialized
INFO - 2017-12-22 19:49:01 --> Controller Class Initialized
INFO - 2017-12-22 19:49:01 --> Model Class Initialized
INFO - 2017-12-22 19:49:01 --> Model Class Initialized
INFO - 2017-12-22 19:49:01 --> Model Class Initialized
DEBUG - 2017-12-22 19:49:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:49:04 --> Config Class Initialized
INFO - 2017-12-22 19:49:04 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:49:04 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:49:04 --> Utf8 Class Initialized
INFO - 2017-12-22 19:49:04 --> URI Class Initialized
INFO - 2017-12-22 19:49:04 --> Router Class Initialized
INFO - 2017-12-22 19:49:04 --> Output Class Initialized
INFO - 2017-12-22 19:49:04 --> Security Class Initialized
DEBUG - 2017-12-22 19:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:49:04 --> Input Class Initialized
INFO - 2017-12-22 19:49:04 --> Language Class Initialized
INFO - 2017-12-22 19:49:04 --> Loader Class Initialized
INFO - 2017-12-22 19:49:04 --> Helper loaded: url_helper
INFO - 2017-12-22 19:49:04 --> Helper loaded: form_helper
INFO - 2017-12-22 19:49:04 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:49:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:49:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:49:04 --> Form Validation Class Initialized
INFO - 2017-12-22 19:49:04 --> Model Class Initialized
INFO - 2017-12-22 19:49:04 --> Controller Class Initialized
INFO - 2017-12-22 19:49:04 --> Model Class Initialized
INFO - 2017-12-22 19:49:04 --> Model Class Initialized
INFO - 2017-12-22 19:49:04 --> Model Class Initialized
DEBUG - 2017-12-22 19:49:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:49:04 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 19:49:04 --> Final output sent to browser
DEBUG - 2017-12-22 19:49:04 --> Total execution time: 0.0587
INFO - 2017-12-22 19:49:05 --> Config Class Initialized
INFO - 2017-12-22 19:49:05 --> Hooks Class Initialized
INFO - 2017-12-22 19:49:05 --> Config Class Initialized
INFO - 2017-12-22 19:49:05 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:49:05 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:49:05 --> Utf8 Class Initialized
DEBUG - 2017-12-22 19:49:05 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:49:05 --> Utf8 Class Initialized
INFO - 2017-12-22 19:49:05 --> URI Class Initialized
INFO - 2017-12-22 19:49:05 --> URI Class Initialized
INFO - 2017-12-22 19:49:05 --> Router Class Initialized
INFO - 2017-12-22 19:49:05 --> Router Class Initialized
INFO - 2017-12-22 19:49:05 --> Output Class Initialized
INFO - 2017-12-22 19:49:05 --> Output Class Initialized
INFO - 2017-12-22 19:49:05 --> Security Class Initialized
INFO - 2017-12-22 19:49:05 --> Security Class Initialized
DEBUG - 2017-12-22 19:49:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-22 19:49:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:49:05 --> Input Class Initialized
INFO - 2017-12-22 19:49:05 --> Input Class Initialized
INFO - 2017-12-22 19:49:05 --> Language Class Initialized
INFO - 2017-12-22 19:49:05 --> Language Class Initialized
INFO - 2017-12-22 19:49:05 --> Loader Class Initialized
INFO - 2017-12-22 19:49:05 --> Loader Class Initialized
INFO - 2017-12-22 19:49:05 --> Helper loaded: url_helper
INFO - 2017-12-22 19:49:05 --> Helper loaded: url_helper
INFO - 2017-12-22 19:49:05 --> Helper loaded: form_helper
INFO - 2017-12-22 19:49:05 --> Helper loaded: form_helper
INFO - 2017-12-22 19:49:05 --> Database Driver Class Initialized
INFO - 2017-12-22 19:49:05 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:49:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2017-12-22 19:49:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:49:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:49:05 --> Form Validation Class Initialized
INFO - 2017-12-22 19:49:05 --> Model Class Initialized
INFO - 2017-12-22 19:49:05 --> Controller Class Initialized
INFO - 2017-12-22 19:49:05 --> Model Class Initialized
INFO - 2017-12-22 19:49:05 --> Model Class Initialized
INFO - 2017-12-22 19:49:05 --> Model Class Initialized
DEBUG - 2017-12-22 19:49:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:49:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:49:05 --> Form Validation Class Initialized
INFO - 2017-12-22 19:49:05 --> Model Class Initialized
INFO - 2017-12-22 19:49:05 --> Controller Class Initialized
INFO - 2017-12-22 19:49:05 --> Model Class Initialized
INFO - 2017-12-22 19:49:05 --> Model Class Initialized
INFO - 2017-12-22 19:49:05 --> Model Class Initialized
DEBUG - 2017-12-22 19:49:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:52:43 --> Config Class Initialized
INFO - 2017-12-22 19:52:43 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:52:43 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:52:43 --> Utf8 Class Initialized
INFO - 2017-12-22 19:52:43 --> URI Class Initialized
INFO - 2017-12-22 19:52:43 --> Router Class Initialized
INFO - 2017-12-22 19:52:43 --> Output Class Initialized
INFO - 2017-12-22 19:52:43 --> Security Class Initialized
DEBUG - 2017-12-22 19:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:52:43 --> Input Class Initialized
INFO - 2017-12-22 19:52:43 --> Language Class Initialized
INFO - 2017-12-22 19:52:43 --> Loader Class Initialized
INFO - 2017-12-22 19:52:43 --> Helper loaded: url_helper
INFO - 2017-12-22 19:52:43 --> Helper loaded: form_helper
INFO - 2017-12-22 19:52:43 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:52:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:52:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:52:43 --> Form Validation Class Initialized
INFO - 2017-12-22 19:52:43 --> Model Class Initialized
INFO - 2017-12-22 19:52:43 --> Controller Class Initialized
INFO - 2017-12-22 19:52:43 --> Model Class Initialized
INFO - 2017-12-22 19:52:43 --> Model Class Initialized
INFO - 2017-12-22 19:52:43 --> Model Class Initialized
DEBUG - 2017-12-22 19:52:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:52:43 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 19:52:43 --> Final output sent to browser
DEBUG - 2017-12-22 19:52:43 --> Total execution time: 0.0459
INFO - 2017-12-22 19:52:43 --> Config Class Initialized
INFO - 2017-12-22 19:52:43 --> Hooks Class Initialized
INFO - 2017-12-22 19:52:43 --> Config Class Initialized
INFO - 2017-12-22 19:52:43 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:52:43 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:52:43 --> Utf8 Class Initialized
DEBUG - 2017-12-22 19:52:43 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:52:43 --> Utf8 Class Initialized
INFO - 2017-12-22 19:52:43 --> URI Class Initialized
INFO - 2017-12-22 19:52:43 --> URI Class Initialized
INFO - 2017-12-22 19:52:43 --> Router Class Initialized
INFO - 2017-12-22 19:52:43 --> Router Class Initialized
INFO - 2017-12-22 19:52:43 --> Output Class Initialized
INFO - 2017-12-22 19:52:43 --> Output Class Initialized
INFO - 2017-12-22 19:52:43 --> Security Class Initialized
INFO - 2017-12-22 19:52:43 --> Security Class Initialized
DEBUG - 2017-12-22 19:52:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-22 19:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:52:43 --> Input Class Initialized
INFO - 2017-12-22 19:52:43 --> Input Class Initialized
INFO - 2017-12-22 19:52:43 --> Language Class Initialized
INFO - 2017-12-22 19:52:43 --> Language Class Initialized
INFO - 2017-12-22 19:52:43 --> Loader Class Initialized
INFO - 2017-12-22 19:52:43 --> Loader Class Initialized
INFO - 2017-12-22 19:52:43 --> Helper loaded: url_helper
INFO - 2017-12-22 19:52:43 --> Helper loaded: url_helper
INFO - 2017-12-22 19:52:43 --> Helper loaded: form_helper
INFO - 2017-12-22 19:52:43 --> Helper loaded: form_helper
INFO - 2017-12-22 19:52:43 --> Database Driver Class Initialized
INFO - 2017-12-22 19:52:43 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:52:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:52:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:52:43 --> Form Validation Class Initialized
INFO - 2017-12-22 19:52:43 --> Model Class Initialized
INFO - 2017-12-22 19:52:43 --> Controller Class Initialized
INFO - 2017-12-22 19:52:43 --> Model Class Initialized
INFO - 2017-12-22 19:52:43 --> Model Class Initialized
DEBUG - 2017-12-22 19:52:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:52:43 --> Model Class Initialized
DEBUG - 2017-12-22 19:52:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:52:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:52:43 --> Form Validation Class Initialized
INFO - 2017-12-22 19:52:43 --> Model Class Initialized
INFO - 2017-12-22 19:52:43 --> Controller Class Initialized
INFO - 2017-12-22 19:52:43 --> Model Class Initialized
INFO - 2017-12-22 19:52:43 --> Model Class Initialized
INFO - 2017-12-22 19:52:43 --> Model Class Initialized
DEBUG - 2017-12-22 19:52:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:52:45 --> Config Class Initialized
INFO - 2017-12-22 19:52:45 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:52:45 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:52:45 --> Utf8 Class Initialized
INFO - 2017-12-22 19:52:45 --> URI Class Initialized
INFO - 2017-12-22 19:52:45 --> Router Class Initialized
INFO - 2017-12-22 19:52:45 --> Output Class Initialized
INFO - 2017-12-22 19:52:45 --> Security Class Initialized
DEBUG - 2017-12-22 19:52:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:52:45 --> Input Class Initialized
INFO - 2017-12-22 19:52:45 --> Language Class Initialized
INFO - 2017-12-22 19:52:45 --> Loader Class Initialized
INFO - 2017-12-22 19:52:45 --> Helper loaded: url_helper
INFO - 2017-12-22 19:52:45 --> Helper loaded: form_helper
INFO - 2017-12-22 19:52:45 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:52:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:52:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:52:45 --> Form Validation Class Initialized
INFO - 2017-12-22 19:52:45 --> Model Class Initialized
INFO - 2017-12-22 19:52:45 --> Controller Class Initialized
INFO - 2017-12-22 19:52:45 --> Model Class Initialized
INFO - 2017-12-22 19:52:45 --> Model Class Initialized
INFO - 2017-12-22 19:52:45 --> Model Class Initialized
DEBUG - 2017-12-22 19:52:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:52:45 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 19:52:45 --> Final output sent to browser
DEBUG - 2017-12-22 19:52:45 --> Total execution time: 0.0577
INFO - 2017-12-22 19:52:45 --> Config Class Initialized
INFO - 2017-12-22 19:52:45 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:52:45 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:52:45 --> Utf8 Class Initialized
INFO - 2017-12-22 19:52:45 --> URI Class Initialized
INFO - 2017-12-22 19:52:45 --> Router Class Initialized
INFO - 2017-12-22 19:52:45 --> Output Class Initialized
INFO - 2017-12-22 19:52:45 --> Security Class Initialized
DEBUG - 2017-12-22 19:52:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:52:45 --> Input Class Initialized
INFO - 2017-12-22 19:52:45 --> Language Class Initialized
INFO - 2017-12-22 19:52:45 --> Loader Class Initialized
INFO - 2017-12-22 19:52:45 --> Helper loaded: url_helper
INFO - 2017-12-22 19:52:45 --> Helper loaded: form_helper
INFO - 2017-12-22 19:52:45 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:52:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:52:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:52:45 --> Form Validation Class Initialized
INFO - 2017-12-22 19:52:45 --> Model Class Initialized
INFO - 2017-12-22 19:52:45 --> Controller Class Initialized
INFO - 2017-12-22 19:52:45 --> Model Class Initialized
INFO - 2017-12-22 19:52:45 --> Model Class Initialized
INFO - 2017-12-22 19:52:45 --> Model Class Initialized
DEBUG - 2017-12-22 19:52:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:52:47 --> Config Class Initialized
INFO - 2017-12-22 19:52:47 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:52:47 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:52:47 --> Utf8 Class Initialized
INFO - 2017-12-22 19:52:47 --> URI Class Initialized
INFO - 2017-12-22 19:52:47 --> Router Class Initialized
INFO - 2017-12-22 19:52:47 --> Output Class Initialized
INFO - 2017-12-22 19:52:47 --> Security Class Initialized
DEBUG - 2017-12-22 19:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:52:47 --> Input Class Initialized
INFO - 2017-12-22 19:52:47 --> Language Class Initialized
INFO - 2017-12-22 19:52:47 --> Loader Class Initialized
INFO - 2017-12-22 19:52:47 --> Helper loaded: url_helper
INFO - 2017-12-22 19:52:47 --> Helper loaded: form_helper
INFO - 2017-12-22 19:52:47 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:52:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:52:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:52:47 --> Form Validation Class Initialized
INFO - 2017-12-22 19:52:47 --> Model Class Initialized
INFO - 2017-12-22 19:52:47 --> Controller Class Initialized
INFO - 2017-12-22 19:52:47 --> Model Class Initialized
INFO - 2017-12-22 19:52:47 --> Model Class Initialized
INFO - 2017-12-22 19:52:47 --> Model Class Initialized
DEBUG - 2017-12-22 19:52:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:52:47 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 19:52:47 --> Final output sent to browser
DEBUG - 2017-12-22 19:52:47 --> Total execution time: 0.0564
INFO - 2017-12-22 19:52:47 --> Config Class Initialized
INFO - 2017-12-22 19:52:47 --> Hooks Class Initialized
INFO - 2017-12-22 19:52:47 --> Config Class Initialized
INFO - 2017-12-22 19:52:47 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:52:47 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:52:47 --> Utf8 Class Initialized
INFO - 2017-12-22 19:52:47 --> URI Class Initialized
INFO - 2017-12-22 19:52:47 --> Router Class Initialized
DEBUG - 2017-12-22 19:52:47 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:52:47 --> Utf8 Class Initialized
INFO - 2017-12-22 19:52:47 --> Output Class Initialized
INFO - 2017-12-22 19:52:47 --> URI Class Initialized
INFO - 2017-12-22 19:52:47 --> Security Class Initialized
DEBUG - 2017-12-22 19:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:52:47 --> Input Class Initialized
INFO - 2017-12-22 19:52:47 --> Router Class Initialized
INFO - 2017-12-22 19:52:47 --> Language Class Initialized
INFO - 2017-12-22 19:52:47 --> Output Class Initialized
INFO - 2017-12-22 19:52:47 --> Loader Class Initialized
INFO - 2017-12-22 19:52:47 --> Security Class Initialized
INFO - 2017-12-22 19:52:47 --> Helper loaded: url_helper
DEBUG - 2017-12-22 19:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:52:47 --> Helper loaded: form_helper
INFO - 2017-12-22 19:52:47 --> Input Class Initialized
INFO - 2017-12-22 19:52:47 --> Language Class Initialized
INFO - 2017-12-22 19:52:47 --> Loader Class Initialized
INFO - 2017-12-22 19:52:47 --> Database Driver Class Initialized
INFO - 2017-12-22 19:52:47 --> Helper loaded: url_helper
INFO - 2017-12-22 19:52:47 --> Helper loaded: form_helper
INFO - 2017-12-22 19:52:47 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:52:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:52:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:52:47 --> Form Validation Class Initialized
INFO - 2017-12-22 19:52:47 --> Model Class Initialized
INFO - 2017-12-22 19:52:47 --> Controller Class Initialized
INFO - 2017-12-22 19:52:47 --> Model Class Initialized
INFO - 2017-12-22 19:52:47 --> Model Class Initialized
INFO - 2017-12-22 19:52:47 --> Model Class Initialized
DEBUG - 2017-12-22 19:52:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2017-12-22 19:52:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:52:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:52:47 --> Form Validation Class Initialized
INFO - 2017-12-22 19:52:47 --> Model Class Initialized
INFO - 2017-12-22 19:52:47 --> Controller Class Initialized
INFO - 2017-12-22 19:52:47 --> Model Class Initialized
INFO - 2017-12-22 19:52:47 --> Model Class Initialized
INFO - 2017-12-22 19:52:47 --> Model Class Initialized
DEBUG - 2017-12-22 19:52:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:52:48 --> Config Class Initialized
INFO - 2017-12-22 19:52:48 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:52:48 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:52:48 --> Utf8 Class Initialized
INFO - 2017-12-22 19:52:48 --> URI Class Initialized
INFO - 2017-12-22 19:52:48 --> Router Class Initialized
INFO - 2017-12-22 19:52:48 --> Output Class Initialized
INFO - 2017-12-22 19:52:48 --> Security Class Initialized
DEBUG - 2017-12-22 19:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:52:48 --> Input Class Initialized
INFO - 2017-12-22 19:52:48 --> Language Class Initialized
INFO - 2017-12-22 19:52:48 --> Loader Class Initialized
INFO - 2017-12-22 19:52:48 --> Helper loaded: url_helper
INFO - 2017-12-22 19:52:48 --> Helper loaded: form_helper
INFO - 2017-12-22 19:52:48 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:52:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:52:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:52:48 --> Form Validation Class Initialized
INFO - 2017-12-22 19:52:48 --> Model Class Initialized
INFO - 2017-12-22 19:52:48 --> Controller Class Initialized
INFO - 2017-12-22 19:52:48 --> Model Class Initialized
INFO - 2017-12-22 19:52:48 --> Model Class Initialized
INFO - 2017-12-22 19:52:48 --> Model Class Initialized
DEBUG - 2017-12-22 19:52:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:52:48 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 19:52:48 --> Final output sent to browser
DEBUG - 2017-12-22 19:52:48 --> Total execution time: 0.0613
INFO - 2017-12-22 19:52:48 --> Config Class Initialized
INFO - 2017-12-22 19:52:48 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:52:48 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:52:48 --> Utf8 Class Initialized
INFO - 2017-12-22 19:52:48 --> URI Class Initialized
INFO - 2017-12-22 19:52:48 --> Router Class Initialized
INFO - 2017-12-22 19:52:48 --> Output Class Initialized
INFO - 2017-12-22 19:52:48 --> Security Class Initialized
DEBUG - 2017-12-22 19:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:52:48 --> Input Class Initialized
INFO - 2017-12-22 19:52:48 --> Language Class Initialized
INFO - 2017-12-22 19:52:48 --> Loader Class Initialized
INFO - 2017-12-22 19:52:48 --> Helper loaded: url_helper
INFO - 2017-12-22 19:52:48 --> Helper loaded: form_helper
INFO - 2017-12-22 19:52:48 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:52:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:52:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:52:48 --> Form Validation Class Initialized
INFO - 2017-12-22 19:52:48 --> Model Class Initialized
INFO - 2017-12-22 19:52:48 --> Controller Class Initialized
INFO - 2017-12-22 19:52:48 --> Model Class Initialized
INFO - 2017-12-22 19:52:48 --> Model Class Initialized
INFO - 2017-12-22 19:52:48 --> Model Class Initialized
DEBUG - 2017-12-22 19:52:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:52:48 --> Config Class Initialized
INFO - 2017-12-22 19:52:48 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:52:48 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:52:48 --> Utf8 Class Initialized
INFO - 2017-12-22 19:52:48 --> URI Class Initialized
INFO - 2017-12-22 19:52:48 --> Router Class Initialized
INFO - 2017-12-22 19:52:48 --> Output Class Initialized
INFO - 2017-12-22 19:52:48 --> Security Class Initialized
DEBUG - 2017-12-22 19:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:52:48 --> Input Class Initialized
INFO - 2017-12-22 19:52:48 --> Language Class Initialized
INFO - 2017-12-22 19:52:48 --> Loader Class Initialized
INFO - 2017-12-22 19:52:48 --> Helper loaded: url_helper
INFO - 2017-12-22 19:52:48 --> Helper loaded: form_helper
INFO - 2017-12-22 19:52:48 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:52:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:52:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:52:48 --> Form Validation Class Initialized
INFO - 2017-12-22 19:52:48 --> Model Class Initialized
INFO - 2017-12-22 19:52:48 --> Controller Class Initialized
INFO - 2017-12-22 19:52:48 --> Model Class Initialized
INFO - 2017-12-22 19:52:48 --> Model Class Initialized
INFO - 2017-12-22 19:52:48 --> Model Class Initialized
DEBUG - 2017-12-22 19:52:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:52:48 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 19:52:48 --> Final output sent to browser
DEBUG - 2017-12-22 19:52:48 --> Total execution time: 0.0601
INFO - 2017-12-22 19:52:48 --> Config Class Initialized
INFO - 2017-12-22 19:52:48 --> Hooks Class Initialized
INFO - 2017-12-22 19:52:48 --> Config Class Initialized
INFO - 2017-12-22 19:52:48 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:52:48 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:52:48 --> Utf8 Class Initialized
DEBUG - 2017-12-22 19:52:48 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:52:48 --> Utf8 Class Initialized
INFO - 2017-12-22 19:52:48 --> URI Class Initialized
INFO - 2017-12-22 19:52:48 --> URI Class Initialized
INFO - 2017-12-22 19:52:48 --> Router Class Initialized
INFO - 2017-12-22 19:52:48 --> Router Class Initialized
INFO - 2017-12-22 19:52:48 --> Output Class Initialized
INFO - 2017-12-22 19:52:48 --> Output Class Initialized
INFO - 2017-12-22 19:52:48 --> Security Class Initialized
INFO - 2017-12-22 19:52:48 --> Security Class Initialized
DEBUG - 2017-12-22 19:52:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-22 19:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:52:48 --> Input Class Initialized
INFO - 2017-12-22 19:52:48 --> Input Class Initialized
INFO - 2017-12-22 19:52:48 --> Language Class Initialized
INFO - 2017-12-22 19:52:48 --> Language Class Initialized
INFO - 2017-12-22 19:52:48 --> Loader Class Initialized
INFO - 2017-12-22 19:52:48 --> Loader Class Initialized
INFO - 2017-12-22 19:52:48 --> Helper loaded: url_helper
INFO - 2017-12-22 19:52:48 --> Helper loaded: url_helper
INFO - 2017-12-22 19:52:48 --> Helper loaded: form_helper
INFO - 2017-12-22 19:52:48 --> Helper loaded: form_helper
INFO - 2017-12-22 19:52:48 --> Database Driver Class Initialized
INFO - 2017-12-22 19:52:48 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:52:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:52:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:52:48 --> Form Validation Class Initialized
INFO - 2017-12-22 19:52:48 --> Model Class Initialized
INFO - 2017-12-22 19:52:48 --> Controller Class Initialized
INFO - 2017-12-22 19:52:48 --> Model Class Initialized
INFO - 2017-12-22 19:52:48 --> Model Class Initialized
INFO - 2017-12-22 19:52:48 --> Model Class Initialized
DEBUG - 2017-12-22 19:52:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2017-12-22 19:52:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:52:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:52:48 --> Form Validation Class Initialized
INFO - 2017-12-22 19:52:48 --> Model Class Initialized
INFO - 2017-12-22 19:52:48 --> Controller Class Initialized
INFO - 2017-12-22 19:52:48 --> Model Class Initialized
INFO - 2017-12-22 19:52:48 --> Model Class Initialized
INFO - 2017-12-22 19:52:48 --> Model Class Initialized
DEBUG - 2017-12-22 19:52:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:56:55 --> Config Class Initialized
INFO - 2017-12-22 19:56:55 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:56:55 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:56:55 --> Utf8 Class Initialized
INFO - 2017-12-22 19:56:55 --> URI Class Initialized
INFO - 2017-12-22 19:56:55 --> Router Class Initialized
INFO - 2017-12-22 19:56:55 --> Output Class Initialized
INFO - 2017-12-22 19:56:55 --> Security Class Initialized
DEBUG - 2017-12-22 19:56:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:56:55 --> Input Class Initialized
INFO - 2017-12-22 19:56:55 --> Language Class Initialized
INFO - 2017-12-22 19:56:55 --> Loader Class Initialized
INFO - 2017-12-22 19:56:55 --> Helper loaded: url_helper
INFO - 2017-12-22 19:56:55 --> Helper loaded: form_helper
INFO - 2017-12-22 19:56:55 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:56:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:56:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:56:55 --> Form Validation Class Initialized
INFO - 2017-12-22 19:56:55 --> Model Class Initialized
INFO - 2017-12-22 19:56:55 --> Controller Class Initialized
INFO - 2017-12-22 19:56:55 --> Model Class Initialized
INFO - 2017-12-22 19:56:55 --> Model Class Initialized
INFO - 2017-12-22 19:56:55 --> Model Class Initialized
DEBUG - 2017-12-22 19:56:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:56:55 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 19:56:55 --> Final output sent to browser
DEBUG - 2017-12-22 19:56:55 --> Total execution time: 0.0766
INFO - 2017-12-22 19:56:56 --> Config Class Initialized
INFO - 2017-12-22 19:56:56 --> Hooks Class Initialized
INFO - 2017-12-22 19:56:56 --> Config Class Initialized
INFO - 2017-12-22 19:56:56 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:56:56 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:56:56 --> Utf8 Class Initialized
INFO - 2017-12-22 19:56:56 --> URI Class Initialized
DEBUG - 2017-12-22 19:56:56 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:56:56 --> Utf8 Class Initialized
INFO - 2017-12-22 19:56:56 --> Router Class Initialized
INFO - 2017-12-22 19:56:56 --> URI Class Initialized
INFO - 2017-12-22 19:56:56 --> Output Class Initialized
INFO - 2017-12-22 19:56:56 --> Router Class Initialized
INFO - 2017-12-22 19:56:56 --> Security Class Initialized
DEBUG - 2017-12-22 19:56:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:56:56 --> Input Class Initialized
INFO - 2017-12-22 19:56:56 --> Output Class Initialized
INFO - 2017-12-22 19:56:56 --> Language Class Initialized
INFO - 2017-12-22 19:56:56 --> Security Class Initialized
DEBUG - 2017-12-22 19:56:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:56:56 --> Input Class Initialized
INFO - 2017-12-22 19:56:56 --> Loader Class Initialized
INFO - 2017-12-22 19:56:56 --> Language Class Initialized
INFO - 2017-12-22 19:56:56 --> Helper loaded: url_helper
INFO - 2017-12-22 19:56:56 --> Helper loaded: form_helper
INFO - 2017-12-22 19:56:56 --> Loader Class Initialized
INFO - 2017-12-22 19:56:56 --> Helper loaded: url_helper
INFO - 2017-12-22 19:56:56 --> Helper loaded: form_helper
INFO - 2017-12-22 19:56:56 --> Database Driver Class Initialized
INFO - 2017-12-22 19:56:56 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:56:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:56:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:56:56 --> Form Validation Class Initialized
DEBUG - 2017-12-22 19:56:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:56:56 --> Model Class Initialized
INFO - 2017-12-22 19:56:56 --> Controller Class Initialized
INFO - 2017-12-22 19:56:56 --> Model Class Initialized
INFO - 2017-12-22 19:56:56 --> Model Class Initialized
INFO - 2017-12-22 19:56:56 --> Model Class Initialized
DEBUG - 2017-12-22 19:56:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:56:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:56:56 --> Form Validation Class Initialized
INFO - 2017-12-22 19:56:56 --> Model Class Initialized
INFO - 2017-12-22 19:56:56 --> Controller Class Initialized
INFO - 2017-12-22 19:56:56 --> Model Class Initialized
INFO - 2017-12-22 19:56:56 --> Model Class Initialized
INFO - 2017-12-22 19:56:56 --> Model Class Initialized
DEBUG - 2017-12-22 19:56:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:56:58 --> Config Class Initialized
INFO - 2017-12-22 19:56:58 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:56:58 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:56:58 --> Utf8 Class Initialized
INFO - 2017-12-22 19:56:58 --> URI Class Initialized
INFO - 2017-12-22 19:56:58 --> Router Class Initialized
INFO - 2017-12-22 19:56:58 --> Output Class Initialized
INFO - 2017-12-22 19:56:58 --> Security Class Initialized
DEBUG - 2017-12-22 19:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:56:58 --> Input Class Initialized
INFO - 2017-12-22 19:56:58 --> Language Class Initialized
INFO - 2017-12-22 19:56:58 --> Loader Class Initialized
INFO - 2017-12-22 19:56:58 --> Helper loaded: url_helper
INFO - 2017-12-22 19:56:58 --> Helper loaded: form_helper
INFO - 2017-12-22 19:56:58 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:56:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:56:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:56:58 --> Form Validation Class Initialized
INFO - 2017-12-22 19:56:58 --> Model Class Initialized
INFO - 2017-12-22 19:56:58 --> Controller Class Initialized
INFO - 2017-12-22 19:56:58 --> Model Class Initialized
INFO - 2017-12-22 19:56:58 --> Model Class Initialized
INFO - 2017-12-22 19:56:58 --> Model Class Initialized
DEBUG - 2017-12-22 19:56:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:56:58 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 19:56:58 --> Final output sent to browser
DEBUG - 2017-12-22 19:56:58 --> Total execution time: 0.0611
INFO - 2017-12-22 19:56:58 --> Config Class Initialized
INFO - 2017-12-22 19:56:58 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:56:58 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:56:58 --> Utf8 Class Initialized
INFO - 2017-12-22 19:56:58 --> URI Class Initialized
INFO - 2017-12-22 19:56:58 --> Router Class Initialized
INFO - 2017-12-22 19:56:58 --> Output Class Initialized
INFO - 2017-12-22 19:56:58 --> Security Class Initialized
DEBUG - 2017-12-22 19:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:56:58 --> Input Class Initialized
INFO - 2017-12-22 19:56:58 --> Language Class Initialized
INFO - 2017-12-22 19:56:58 --> Loader Class Initialized
INFO - 2017-12-22 19:56:58 --> Helper loaded: url_helper
INFO - 2017-12-22 19:56:58 --> Helper loaded: form_helper
INFO - 2017-12-22 19:56:58 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:56:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:56:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:56:58 --> Form Validation Class Initialized
INFO - 2017-12-22 19:56:58 --> Model Class Initialized
INFO - 2017-12-22 19:56:58 --> Controller Class Initialized
INFO - 2017-12-22 19:56:58 --> Model Class Initialized
INFO - 2017-12-22 19:56:58 --> Model Class Initialized
INFO - 2017-12-22 19:56:58 --> Model Class Initialized
DEBUG - 2017-12-22 19:56:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:57:00 --> Config Class Initialized
INFO - 2017-12-22 19:57:00 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:57:00 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:57:00 --> Utf8 Class Initialized
INFO - 2017-12-22 19:57:00 --> URI Class Initialized
INFO - 2017-12-22 19:57:00 --> Router Class Initialized
INFO - 2017-12-22 19:57:00 --> Output Class Initialized
INFO - 2017-12-22 19:57:00 --> Security Class Initialized
DEBUG - 2017-12-22 19:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:57:00 --> Input Class Initialized
INFO - 2017-12-22 19:57:00 --> Language Class Initialized
INFO - 2017-12-22 19:57:00 --> Loader Class Initialized
INFO - 2017-12-22 19:57:00 --> Helper loaded: url_helper
INFO - 2017-12-22 19:57:00 --> Helper loaded: form_helper
INFO - 2017-12-22 19:57:00 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:57:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:57:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:57:00 --> Form Validation Class Initialized
INFO - 2017-12-22 19:57:00 --> Model Class Initialized
INFO - 2017-12-22 19:57:00 --> Controller Class Initialized
INFO - 2017-12-22 19:57:00 --> Model Class Initialized
INFO - 2017-12-22 19:57:00 --> Model Class Initialized
INFO - 2017-12-22 19:57:00 --> Model Class Initialized
DEBUG - 2017-12-22 19:57:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:57:00 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 19:57:00 --> Final output sent to browser
DEBUG - 2017-12-22 19:57:00 --> Total execution time: 0.0617
INFO - 2017-12-22 19:57:00 --> Config Class Initialized
INFO - 2017-12-22 19:57:00 --> Config Class Initialized
INFO - 2017-12-22 19:57:00 --> Hooks Class Initialized
INFO - 2017-12-22 19:57:00 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:57:00 --> UTF-8 Support Enabled
DEBUG - 2017-12-22 19:57:00 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:57:00 --> Utf8 Class Initialized
INFO - 2017-12-22 19:57:00 --> Utf8 Class Initialized
INFO - 2017-12-22 19:57:00 --> URI Class Initialized
INFO - 2017-12-22 19:57:00 --> URI Class Initialized
INFO - 2017-12-22 19:57:00 --> Router Class Initialized
INFO - 2017-12-22 19:57:00 --> Router Class Initialized
INFO - 2017-12-22 19:57:00 --> Output Class Initialized
INFO - 2017-12-22 19:57:00 --> Output Class Initialized
INFO - 2017-12-22 19:57:00 --> Security Class Initialized
INFO - 2017-12-22 19:57:00 --> Security Class Initialized
DEBUG - 2017-12-22 19:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:57:00 --> Input Class Initialized
DEBUG - 2017-12-22 19:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:57:00 --> Input Class Initialized
INFO - 2017-12-22 19:57:00 --> Language Class Initialized
INFO - 2017-12-22 19:57:00 --> Language Class Initialized
INFO - 2017-12-22 19:57:00 --> Loader Class Initialized
INFO - 2017-12-22 19:57:00 --> Loader Class Initialized
INFO - 2017-12-22 19:57:00 --> Helper loaded: url_helper
INFO - 2017-12-22 19:57:00 --> Helper loaded: url_helper
INFO - 2017-12-22 19:57:00 --> Helper loaded: form_helper
INFO - 2017-12-22 19:57:00 --> Helper loaded: form_helper
INFO - 2017-12-22 19:57:00 --> Database Driver Class Initialized
INFO - 2017-12-22 19:57:00 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:57:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:57:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:57:00 --> Form Validation Class Initialized
INFO - 2017-12-22 19:57:00 --> Model Class Initialized
INFO - 2017-12-22 19:57:00 --> Controller Class Initialized
INFO - 2017-12-22 19:57:00 --> Model Class Initialized
INFO - 2017-12-22 19:57:00 --> Model Class Initialized
INFO - 2017-12-22 19:57:00 --> Model Class Initialized
DEBUG - 2017-12-22 19:57:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2017-12-22 19:57:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:57:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:57:00 --> Form Validation Class Initialized
INFO - 2017-12-22 19:57:00 --> Model Class Initialized
INFO - 2017-12-22 19:57:00 --> Controller Class Initialized
INFO - 2017-12-22 19:57:00 --> Model Class Initialized
INFO - 2017-12-22 19:57:00 --> Model Class Initialized
INFO - 2017-12-22 19:57:00 --> Model Class Initialized
DEBUG - 2017-12-22 19:57:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:57:01 --> Config Class Initialized
INFO - 2017-12-22 19:57:01 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:57:01 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:57:01 --> Utf8 Class Initialized
INFO - 2017-12-22 19:57:01 --> URI Class Initialized
INFO - 2017-12-22 19:57:01 --> Router Class Initialized
INFO - 2017-12-22 19:57:01 --> Output Class Initialized
INFO - 2017-12-22 19:57:01 --> Security Class Initialized
DEBUG - 2017-12-22 19:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:57:01 --> Input Class Initialized
INFO - 2017-12-22 19:57:01 --> Language Class Initialized
INFO - 2017-12-22 19:57:01 --> Loader Class Initialized
INFO - 2017-12-22 19:57:01 --> Helper loaded: url_helper
INFO - 2017-12-22 19:57:01 --> Helper loaded: form_helper
INFO - 2017-12-22 19:57:01 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:57:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:57:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:57:01 --> Form Validation Class Initialized
INFO - 2017-12-22 19:57:01 --> Model Class Initialized
INFO - 2017-12-22 19:57:01 --> Controller Class Initialized
INFO - 2017-12-22 19:57:01 --> Model Class Initialized
INFO - 2017-12-22 19:57:01 --> Model Class Initialized
INFO - 2017-12-22 19:57:01 --> Model Class Initialized
DEBUG - 2017-12-22 19:57:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:57:01 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 19:57:01 --> Final output sent to browser
DEBUG - 2017-12-22 19:57:01 --> Total execution time: 0.0580
INFO - 2017-12-22 19:57:01 --> Config Class Initialized
INFO - 2017-12-22 19:57:01 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:57:01 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:57:01 --> Utf8 Class Initialized
INFO - 2017-12-22 19:57:01 --> URI Class Initialized
INFO - 2017-12-22 19:57:01 --> Router Class Initialized
INFO - 2017-12-22 19:57:01 --> Output Class Initialized
INFO - 2017-12-22 19:57:01 --> Security Class Initialized
DEBUG - 2017-12-22 19:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:57:01 --> Input Class Initialized
INFO - 2017-12-22 19:57:01 --> Language Class Initialized
INFO - 2017-12-22 19:57:01 --> Loader Class Initialized
INFO - 2017-12-22 19:57:01 --> Helper loaded: url_helper
INFO - 2017-12-22 19:57:01 --> Helper loaded: form_helper
INFO - 2017-12-22 19:57:01 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:57:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:57:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:57:01 --> Form Validation Class Initialized
INFO - 2017-12-22 19:57:01 --> Model Class Initialized
INFO - 2017-12-22 19:57:01 --> Controller Class Initialized
INFO - 2017-12-22 19:57:01 --> Model Class Initialized
INFO - 2017-12-22 19:57:01 --> Model Class Initialized
INFO - 2017-12-22 19:57:01 --> Model Class Initialized
DEBUG - 2017-12-22 19:57:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:57:04 --> Config Class Initialized
INFO - 2017-12-22 19:57:04 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:57:04 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:57:04 --> Utf8 Class Initialized
INFO - 2017-12-22 19:57:04 --> URI Class Initialized
INFO - 2017-12-22 19:57:04 --> Router Class Initialized
INFO - 2017-12-22 19:57:04 --> Output Class Initialized
INFO - 2017-12-22 19:57:04 --> Security Class Initialized
DEBUG - 2017-12-22 19:57:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:57:04 --> Input Class Initialized
INFO - 2017-12-22 19:57:04 --> Language Class Initialized
INFO - 2017-12-22 19:57:04 --> Loader Class Initialized
INFO - 2017-12-22 19:57:04 --> Helper loaded: url_helper
INFO - 2017-12-22 19:57:04 --> Helper loaded: form_helper
INFO - 2017-12-22 19:57:04 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:57:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:57:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:57:04 --> Form Validation Class Initialized
INFO - 2017-12-22 19:57:04 --> Model Class Initialized
INFO - 2017-12-22 19:57:04 --> Controller Class Initialized
INFO - 2017-12-22 19:57:04 --> Model Class Initialized
INFO - 2017-12-22 19:57:04 --> Model Class Initialized
INFO - 2017-12-22 19:57:04 --> Model Class Initialized
DEBUG - 2017-12-22 19:57:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:57:04 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 19:57:04 --> Final output sent to browser
DEBUG - 2017-12-22 19:57:04 --> Total execution time: 0.0582
INFO - 2017-12-22 19:57:04 --> Config Class Initialized
INFO - 2017-12-22 19:57:04 --> Hooks Class Initialized
INFO - 2017-12-22 19:57:04 --> Config Class Initialized
INFO - 2017-12-22 19:57:04 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:57:04 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:57:04 --> Utf8 Class Initialized
DEBUG - 2017-12-22 19:57:04 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:57:04 --> Utf8 Class Initialized
INFO - 2017-12-22 19:57:04 --> URI Class Initialized
INFO - 2017-12-22 19:57:04 --> URI Class Initialized
INFO - 2017-12-22 19:57:04 --> Router Class Initialized
INFO - 2017-12-22 19:57:04 --> Router Class Initialized
INFO - 2017-12-22 19:57:04 --> Output Class Initialized
INFO - 2017-12-22 19:57:04 --> Output Class Initialized
INFO - 2017-12-22 19:57:04 --> Security Class Initialized
INFO - 2017-12-22 19:57:04 --> Security Class Initialized
DEBUG - 2017-12-22 19:57:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:57:04 --> Input Class Initialized
INFO - 2017-12-22 19:57:04 --> Language Class Initialized
DEBUG - 2017-12-22 19:57:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:57:04 --> Input Class Initialized
INFO - 2017-12-22 19:57:04 --> Language Class Initialized
INFO - 2017-12-22 19:57:04 --> Loader Class Initialized
INFO - 2017-12-22 19:57:04 --> Helper loaded: url_helper
INFO - 2017-12-22 19:57:04 --> Loader Class Initialized
INFO - 2017-12-22 19:57:04 --> Helper loaded: url_helper
INFO - 2017-12-22 19:57:04 --> Helper loaded: form_helper
INFO - 2017-12-22 19:57:04 --> Helper loaded: form_helper
INFO - 2017-12-22 19:57:04 --> Database Driver Class Initialized
INFO - 2017-12-22 19:57:04 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:57:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2017-12-22 19:57:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:57:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:57:04 --> Form Validation Class Initialized
INFO - 2017-12-22 19:57:04 --> Model Class Initialized
INFO - 2017-12-22 19:57:04 --> Controller Class Initialized
INFO - 2017-12-22 19:57:04 --> Model Class Initialized
INFO - 2017-12-22 19:57:04 --> Model Class Initialized
INFO - 2017-12-22 19:57:04 --> Model Class Initialized
DEBUG - 2017-12-22 19:57:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:57:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:57:04 --> Form Validation Class Initialized
INFO - 2017-12-22 19:57:04 --> Model Class Initialized
INFO - 2017-12-22 19:57:04 --> Controller Class Initialized
INFO - 2017-12-22 19:57:04 --> Model Class Initialized
INFO - 2017-12-22 19:57:04 --> Model Class Initialized
INFO - 2017-12-22 19:57:04 --> Model Class Initialized
DEBUG - 2017-12-22 19:57:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:57:09 --> Config Class Initialized
INFO - 2017-12-22 19:57:09 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:57:09 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:57:09 --> Utf8 Class Initialized
INFO - 2017-12-22 19:57:09 --> URI Class Initialized
INFO - 2017-12-22 19:57:09 --> Router Class Initialized
INFO - 2017-12-22 19:57:09 --> Output Class Initialized
INFO - 2017-12-22 19:57:09 --> Security Class Initialized
DEBUG - 2017-12-22 19:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:57:09 --> Input Class Initialized
INFO - 2017-12-22 19:57:09 --> Language Class Initialized
INFO - 2017-12-22 19:57:09 --> Loader Class Initialized
INFO - 2017-12-22 19:57:09 --> Helper loaded: url_helper
INFO - 2017-12-22 19:57:09 --> Helper loaded: form_helper
INFO - 2017-12-22 19:57:09 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:57:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:57:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:57:09 --> Form Validation Class Initialized
INFO - 2017-12-22 19:57:09 --> Model Class Initialized
INFO - 2017-12-22 19:57:09 --> Controller Class Initialized
INFO - 2017-12-22 19:57:09 --> Model Class Initialized
INFO - 2017-12-22 19:57:09 --> Model Class Initialized
INFO - 2017-12-22 19:57:09 --> Model Class Initialized
DEBUG - 2017-12-22 19:57:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:57:09 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 19:57:09 --> Final output sent to browser
DEBUG - 2017-12-22 19:57:09 --> Total execution time: 0.0600
INFO - 2017-12-22 19:57:09 --> Config Class Initialized
INFO - 2017-12-22 19:57:09 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:57:09 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:57:09 --> Utf8 Class Initialized
INFO - 2017-12-22 19:57:09 --> URI Class Initialized
INFO - 2017-12-22 19:57:09 --> Router Class Initialized
INFO - 2017-12-22 19:57:09 --> Output Class Initialized
INFO - 2017-12-22 19:57:09 --> Security Class Initialized
DEBUG - 2017-12-22 19:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:57:09 --> Input Class Initialized
INFO - 2017-12-22 19:57:09 --> Language Class Initialized
INFO - 2017-12-22 19:57:09 --> Loader Class Initialized
INFO - 2017-12-22 19:57:09 --> Helper loaded: url_helper
INFO - 2017-12-22 19:57:09 --> Helper loaded: form_helper
INFO - 2017-12-22 19:57:09 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:57:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:57:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:57:09 --> Form Validation Class Initialized
INFO - 2017-12-22 19:57:09 --> Model Class Initialized
INFO - 2017-12-22 19:57:09 --> Controller Class Initialized
INFO - 2017-12-22 19:57:09 --> Model Class Initialized
INFO - 2017-12-22 19:57:09 --> Model Class Initialized
INFO - 2017-12-22 19:57:09 --> Model Class Initialized
DEBUG - 2017-12-22 19:57:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:57:11 --> Config Class Initialized
INFO - 2017-12-22 19:57:11 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:57:11 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:57:11 --> Utf8 Class Initialized
INFO - 2017-12-22 19:57:11 --> URI Class Initialized
INFO - 2017-12-22 19:57:11 --> Router Class Initialized
INFO - 2017-12-22 19:57:11 --> Output Class Initialized
INFO - 2017-12-22 19:57:11 --> Security Class Initialized
DEBUG - 2017-12-22 19:57:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:57:11 --> Input Class Initialized
INFO - 2017-12-22 19:57:11 --> Language Class Initialized
INFO - 2017-12-22 19:57:11 --> Loader Class Initialized
INFO - 2017-12-22 19:57:11 --> Helper loaded: url_helper
INFO - 2017-12-22 19:57:11 --> Helper loaded: form_helper
INFO - 2017-12-22 19:57:11 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:57:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:57:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:57:11 --> Form Validation Class Initialized
INFO - 2017-12-22 19:57:11 --> Model Class Initialized
INFO - 2017-12-22 19:57:11 --> Controller Class Initialized
INFO - 2017-12-22 19:57:11 --> Model Class Initialized
INFO - 2017-12-22 19:57:11 --> Model Class Initialized
INFO - 2017-12-22 19:57:11 --> Model Class Initialized
DEBUG - 2017-12-22 19:57:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:57:11 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 19:57:11 --> Final output sent to browser
DEBUG - 2017-12-22 19:57:11 --> Total execution time: 0.0592
INFO - 2017-12-22 19:57:11 --> Config Class Initialized
INFO - 2017-12-22 19:57:11 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:57:11 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:57:11 --> Utf8 Class Initialized
INFO - 2017-12-22 19:57:11 --> URI Class Initialized
INFO - 2017-12-22 19:57:11 --> Router Class Initialized
INFO - 2017-12-22 19:57:11 --> Output Class Initialized
INFO - 2017-12-22 19:57:11 --> Security Class Initialized
DEBUG - 2017-12-22 19:57:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:57:11 --> Input Class Initialized
INFO - 2017-12-22 19:57:11 --> Language Class Initialized
INFO - 2017-12-22 19:57:11 --> Loader Class Initialized
INFO - 2017-12-22 19:57:11 --> Helper loaded: url_helper
INFO - 2017-12-22 19:57:11 --> Helper loaded: form_helper
INFO - 2017-12-22 19:57:11 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:57:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:57:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:57:11 --> Form Validation Class Initialized
INFO - 2017-12-22 19:57:11 --> Model Class Initialized
INFO - 2017-12-22 19:57:11 --> Controller Class Initialized
INFO - 2017-12-22 19:57:11 --> Model Class Initialized
INFO - 2017-12-22 19:57:11 --> Model Class Initialized
INFO - 2017-12-22 19:57:11 --> Model Class Initialized
DEBUG - 2017-12-22 19:57:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:57:14 --> Config Class Initialized
INFO - 2017-12-22 19:57:14 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:57:14 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:57:14 --> Utf8 Class Initialized
INFO - 2017-12-22 19:57:14 --> URI Class Initialized
INFO - 2017-12-22 19:57:14 --> Router Class Initialized
INFO - 2017-12-22 19:57:14 --> Output Class Initialized
INFO - 2017-12-22 19:57:14 --> Security Class Initialized
DEBUG - 2017-12-22 19:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:57:14 --> Input Class Initialized
INFO - 2017-12-22 19:57:14 --> Language Class Initialized
INFO - 2017-12-22 19:57:14 --> Loader Class Initialized
INFO - 2017-12-22 19:57:14 --> Helper loaded: url_helper
INFO - 2017-12-22 19:57:14 --> Helper loaded: form_helper
INFO - 2017-12-22 19:57:14 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:57:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:57:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:57:14 --> Form Validation Class Initialized
INFO - 2017-12-22 19:57:14 --> Model Class Initialized
INFO - 2017-12-22 19:57:14 --> Controller Class Initialized
INFO - 2017-12-22 19:57:14 --> Model Class Initialized
INFO - 2017-12-22 19:57:14 --> Model Class Initialized
INFO - 2017-12-22 19:57:14 --> Model Class Initialized
DEBUG - 2017-12-22 19:57:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:57:14 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 19:57:14 --> Final output sent to browser
DEBUG - 2017-12-22 19:57:14 --> Total execution time: 0.0580
INFO - 2017-12-22 19:57:14 --> Config Class Initialized
INFO - 2017-12-22 19:57:14 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:57:14 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:57:14 --> Utf8 Class Initialized
INFO - 2017-12-22 19:57:14 --> URI Class Initialized
INFO - 2017-12-22 19:57:14 --> Router Class Initialized
INFO - 2017-12-22 19:57:14 --> Output Class Initialized
INFO - 2017-12-22 19:57:14 --> Security Class Initialized
DEBUG - 2017-12-22 19:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:57:14 --> Input Class Initialized
INFO - 2017-12-22 19:57:14 --> Language Class Initialized
INFO - 2017-12-22 19:57:14 --> Loader Class Initialized
INFO - 2017-12-22 19:57:14 --> Helper loaded: url_helper
INFO - 2017-12-22 19:57:14 --> Helper loaded: form_helper
INFO - 2017-12-22 19:57:14 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:57:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:57:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:57:14 --> Form Validation Class Initialized
INFO - 2017-12-22 19:57:14 --> Model Class Initialized
INFO - 2017-12-22 19:57:14 --> Controller Class Initialized
INFO - 2017-12-22 19:57:14 --> Model Class Initialized
INFO - 2017-12-22 19:57:14 --> Model Class Initialized
INFO - 2017-12-22 19:57:14 --> Model Class Initialized
DEBUG - 2017-12-22 19:57:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:57:16 --> Config Class Initialized
INFO - 2017-12-22 19:57:16 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:57:16 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:57:16 --> Utf8 Class Initialized
INFO - 2017-12-22 19:57:16 --> URI Class Initialized
INFO - 2017-12-22 19:57:16 --> Router Class Initialized
INFO - 2017-12-22 19:57:16 --> Output Class Initialized
INFO - 2017-12-22 19:57:16 --> Security Class Initialized
DEBUG - 2017-12-22 19:57:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:57:16 --> Input Class Initialized
INFO - 2017-12-22 19:57:16 --> Language Class Initialized
INFO - 2017-12-22 19:57:16 --> Loader Class Initialized
INFO - 2017-12-22 19:57:16 --> Helper loaded: url_helper
INFO - 2017-12-22 19:57:16 --> Helper loaded: form_helper
INFO - 2017-12-22 19:57:16 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:57:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:57:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:57:16 --> Form Validation Class Initialized
INFO - 2017-12-22 19:57:16 --> Model Class Initialized
INFO - 2017-12-22 19:57:16 --> Controller Class Initialized
INFO - 2017-12-22 19:57:16 --> Model Class Initialized
INFO - 2017-12-22 19:57:16 --> Model Class Initialized
INFO - 2017-12-22 19:57:16 --> Model Class Initialized
DEBUG - 2017-12-22 19:57:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:57:16 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 19:57:16 --> Final output sent to browser
DEBUG - 2017-12-22 19:57:16 --> Total execution time: 0.0470
INFO - 2017-12-22 19:57:16 --> Config Class Initialized
INFO - 2017-12-22 19:57:16 --> Hooks Class Initialized
INFO - 2017-12-22 19:57:16 --> Config Class Initialized
INFO - 2017-12-22 19:57:16 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:57:16 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:57:16 --> Utf8 Class Initialized
INFO - 2017-12-22 19:57:16 --> URI Class Initialized
INFO - 2017-12-22 19:57:16 --> Router Class Initialized
DEBUG - 2017-12-22 19:57:16 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:57:16 --> Utf8 Class Initialized
INFO - 2017-12-22 19:57:16 --> Output Class Initialized
INFO - 2017-12-22 19:57:16 --> URI Class Initialized
INFO - 2017-12-22 19:57:16 --> Security Class Initialized
DEBUG - 2017-12-22 19:57:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:57:16 --> Input Class Initialized
INFO - 2017-12-22 19:57:16 --> Router Class Initialized
INFO - 2017-12-22 19:57:16 --> Language Class Initialized
INFO - 2017-12-22 19:57:16 --> Output Class Initialized
INFO - 2017-12-22 19:57:16 --> Loader Class Initialized
INFO - 2017-12-22 19:57:16 --> Security Class Initialized
INFO - 2017-12-22 19:57:16 --> Helper loaded: url_helper
DEBUG - 2017-12-22 19:57:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:57:16 --> Input Class Initialized
INFO - 2017-12-22 19:57:16 --> Helper loaded: form_helper
INFO - 2017-12-22 19:57:16 --> Language Class Initialized
INFO - 2017-12-22 19:57:16 --> Loader Class Initialized
INFO - 2017-12-22 19:57:16 --> Helper loaded: url_helper
INFO - 2017-12-22 19:57:16 --> Database Driver Class Initialized
INFO - 2017-12-22 19:57:16 --> Helper loaded: form_helper
DEBUG - 2017-12-22 19:57:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:57:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:57:16 --> Database Driver Class Initialized
INFO - 2017-12-22 19:57:16 --> Form Validation Class Initialized
INFO - 2017-12-22 19:57:16 --> Model Class Initialized
INFO - 2017-12-22 19:57:16 --> Controller Class Initialized
INFO - 2017-12-22 19:57:16 --> Model Class Initialized
INFO - 2017-12-22 19:57:16 --> Model Class Initialized
DEBUG - 2017-12-22 19:57:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:57:16 --> Model Class Initialized
DEBUG - 2017-12-22 19:57:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:57:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:57:16 --> Form Validation Class Initialized
INFO - 2017-12-22 19:57:16 --> Model Class Initialized
INFO - 2017-12-22 19:57:16 --> Controller Class Initialized
INFO - 2017-12-22 19:57:16 --> Model Class Initialized
INFO - 2017-12-22 19:57:16 --> Model Class Initialized
INFO - 2017-12-22 19:57:16 --> Model Class Initialized
DEBUG - 2017-12-22 19:57:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:57:20 --> Config Class Initialized
INFO - 2017-12-22 19:57:20 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:57:20 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:57:20 --> Utf8 Class Initialized
INFO - 2017-12-22 19:57:20 --> URI Class Initialized
INFO - 2017-12-22 19:57:20 --> Router Class Initialized
INFO - 2017-12-22 19:57:20 --> Output Class Initialized
INFO - 2017-12-22 19:57:20 --> Security Class Initialized
DEBUG - 2017-12-22 19:57:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:57:20 --> Input Class Initialized
INFO - 2017-12-22 19:57:20 --> Language Class Initialized
INFO - 2017-12-22 19:57:20 --> Loader Class Initialized
INFO - 2017-12-22 19:57:20 --> Helper loaded: url_helper
INFO - 2017-12-22 19:57:20 --> Helper loaded: form_helper
INFO - 2017-12-22 19:57:20 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:57:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:57:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:57:20 --> Form Validation Class Initialized
INFO - 2017-12-22 19:57:20 --> Model Class Initialized
INFO - 2017-12-22 19:57:20 --> Controller Class Initialized
INFO - 2017-12-22 19:57:20 --> Model Class Initialized
INFO - 2017-12-22 19:57:20 --> Model Class Initialized
INFO - 2017-12-22 19:57:20 --> Model Class Initialized
DEBUG - 2017-12-22 19:57:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:57:20 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 19:57:20 --> Final output sent to browser
DEBUG - 2017-12-22 19:57:20 --> Total execution time: 0.0500
INFO - 2017-12-22 19:57:20 --> Config Class Initialized
INFO - 2017-12-22 19:57:20 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:57:20 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:57:20 --> Utf8 Class Initialized
INFO - 2017-12-22 19:57:20 --> URI Class Initialized
INFO - 2017-12-22 19:57:20 --> Router Class Initialized
INFO - 2017-12-22 19:57:20 --> Output Class Initialized
INFO - 2017-12-22 19:57:20 --> Security Class Initialized
DEBUG - 2017-12-22 19:57:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:57:20 --> Input Class Initialized
INFO - 2017-12-22 19:57:20 --> Language Class Initialized
INFO - 2017-12-22 19:57:20 --> Loader Class Initialized
INFO - 2017-12-22 19:57:20 --> Helper loaded: url_helper
INFO - 2017-12-22 19:57:20 --> Helper loaded: form_helper
INFO - 2017-12-22 19:57:20 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:57:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:57:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:57:20 --> Form Validation Class Initialized
INFO - 2017-12-22 19:57:20 --> Model Class Initialized
INFO - 2017-12-22 19:57:20 --> Controller Class Initialized
INFO - 2017-12-22 19:57:20 --> Model Class Initialized
INFO - 2017-12-22 19:57:20 --> Model Class Initialized
INFO - 2017-12-22 19:57:20 --> Model Class Initialized
DEBUG - 2017-12-22 19:57:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:58:39 --> Config Class Initialized
INFO - 2017-12-22 19:58:39 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:58:39 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:58:39 --> Utf8 Class Initialized
INFO - 2017-12-22 19:58:39 --> URI Class Initialized
INFO - 2017-12-22 19:58:39 --> Router Class Initialized
INFO - 2017-12-22 19:58:39 --> Output Class Initialized
INFO - 2017-12-22 19:58:39 --> Security Class Initialized
DEBUG - 2017-12-22 19:58:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:58:39 --> Input Class Initialized
INFO - 2017-12-22 19:58:39 --> Language Class Initialized
INFO - 2017-12-22 19:58:39 --> Loader Class Initialized
INFO - 2017-12-22 19:58:39 --> Helper loaded: url_helper
INFO - 2017-12-22 19:58:39 --> Helper loaded: form_helper
INFO - 2017-12-22 19:58:39 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:58:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:58:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:58:39 --> Form Validation Class Initialized
INFO - 2017-12-22 19:58:39 --> Model Class Initialized
INFO - 2017-12-22 19:58:39 --> Controller Class Initialized
INFO - 2017-12-22 19:58:39 --> Model Class Initialized
INFO - 2017-12-22 19:58:39 --> Model Class Initialized
INFO - 2017-12-22 19:58:39 --> Model Class Initialized
DEBUG - 2017-12-22 19:58:39 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2017-12-22 19:58:39 --> Severity: Notice --> Undefined property: stdClass::$nombre_cliente D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verProyecto.php 24
INFO - 2017-12-22 19:58:39 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 19:58:39 --> Final output sent to browser
DEBUG - 2017-12-22 19:58:39 --> Total execution time: 0.0859
INFO - 2017-12-22 19:58:39 --> Config Class Initialized
INFO - 2017-12-22 19:58:39 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:58:39 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:58:39 --> Utf8 Class Initialized
INFO - 2017-12-22 19:58:39 --> URI Class Initialized
INFO - 2017-12-22 19:58:39 --> Router Class Initialized
INFO - 2017-12-22 19:58:39 --> Output Class Initialized
INFO - 2017-12-22 19:58:39 --> Security Class Initialized
DEBUG - 2017-12-22 19:58:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:58:39 --> Input Class Initialized
INFO - 2017-12-22 19:58:39 --> Language Class Initialized
INFO - 2017-12-22 19:58:39 --> Loader Class Initialized
INFO - 2017-12-22 19:58:39 --> Helper loaded: url_helper
INFO - 2017-12-22 19:58:39 --> Helper loaded: form_helper
INFO - 2017-12-22 19:58:39 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:58:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:58:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:58:39 --> Form Validation Class Initialized
INFO - 2017-12-22 19:58:39 --> Model Class Initialized
INFO - 2017-12-22 19:58:39 --> Controller Class Initialized
INFO - 2017-12-22 19:58:39 --> Model Class Initialized
INFO - 2017-12-22 19:58:39 --> Model Class Initialized
INFO - 2017-12-22 19:58:39 --> Model Class Initialized
DEBUG - 2017-12-22 19:58:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:59:18 --> Config Class Initialized
INFO - 2017-12-22 19:59:18 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:59:18 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:59:18 --> Utf8 Class Initialized
INFO - 2017-12-22 19:59:18 --> URI Class Initialized
INFO - 2017-12-22 19:59:18 --> Router Class Initialized
INFO - 2017-12-22 19:59:18 --> Output Class Initialized
INFO - 2017-12-22 19:59:18 --> Security Class Initialized
DEBUG - 2017-12-22 19:59:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:59:18 --> Input Class Initialized
INFO - 2017-12-22 19:59:18 --> Language Class Initialized
INFO - 2017-12-22 19:59:18 --> Loader Class Initialized
INFO - 2017-12-22 19:59:18 --> Helper loaded: url_helper
INFO - 2017-12-22 19:59:18 --> Helper loaded: form_helper
INFO - 2017-12-22 19:59:18 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:59:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:59:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:59:18 --> Form Validation Class Initialized
INFO - 2017-12-22 19:59:18 --> Model Class Initialized
INFO - 2017-12-22 19:59:18 --> Controller Class Initialized
INFO - 2017-12-22 19:59:18 --> Model Class Initialized
INFO - 2017-12-22 19:59:18 --> Model Class Initialized
INFO - 2017-12-22 19:59:18 --> Model Class Initialized
DEBUG - 2017-12-22 19:59:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:59:18 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 19:59:18 --> Final output sent to browser
DEBUG - 2017-12-22 19:59:18 --> Total execution time: 0.0585
INFO - 2017-12-22 19:59:18 --> Config Class Initialized
INFO - 2017-12-22 19:59:18 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:59:18 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:59:18 --> Utf8 Class Initialized
INFO - 2017-12-22 19:59:18 --> URI Class Initialized
INFO - 2017-12-22 19:59:18 --> Router Class Initialized
INFO - 2017-12-22 19:59:18 --> Output Class Initialized
INFO - 2017-12-22 19:59:18 --> Security Class Initialized
DEBUG - 2017-12-22 19:59:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:59:18 --> Input Class Initialized
INFO - 2017-12-22 19:59:18 --> Language Class Initialized
INFO - 2017-12-22 19:59:18 --> Loader Class Initialized
INFO - 2017-12-22 19:59:18 --> Helper loaded: url_helper
INFO - 2017-12-22 19:59:18 --> Helper loaded: form_helper
INFO - 2017-12-22 19:59:18 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:59:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:59:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:59:18 --> Form Validation Class Initialized
INFO - 2017-12-22 19:59:18 --> Model Class Initialized
INFO - 2017-12-22 19:59:18 --> Controller Class Initialized
INFO - 2017-12-22 19:59:18 --> Model Class Initialized
INFO - 2017-12-22 19:59:18 --> Model Class Initialized
INFO - 2017-12-22 19:59:18 --> Model Class Initialized
DEBUG - 2017-12-22 19:59:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:59:22 --> Config Class Initialized
INFO - 2017-12-22 19:59:22 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:59:22 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:59:22 --> Utf8 Class Initialized
INFO - 2017-12-22 19:59:22 --> URI Class Initialized
INFO - 2017-12-22 19:59:22 --> Router Class Initialized
INFO - 2017-12-22 19:59:22 --> Output Class Initialized
INFO - 2017-12-22 19:59:22 --> Security Class Initialized
DEBUG - 2017-12-22 19:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:59:22 --> Input Class Initialized
INFO - 2017-12-22 19:59:22 --> Language Class Initialized
INFO - 2017-12-22 19:59:22 --> Loader Class Initialized
INFO - 2017-12-22 19:59:22 --> Helper loaded: url_helper
INFO - 2017-12-22 19:59:22 --> Helper loaded: form_helper
INFO - 2017-12-22 19:59:22 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:59:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:59:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:59:22 --> Form Validation Class Initialized
INFO - 2017-12-22 19:59:22 --> Model Class Initialized
INFO - 2017-12-22 19:59:22 --> Controller Class Initialized
INFO - 2017-12-22 19:59:22 --> Model Class Initialized
INFO - 2017-12-22 19:59:22 --> Model Class Initialized
INFO - 2017-12-22 19:59:22 --> Model Class Initialized
DEBUG - 2017-12-22 19:59:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:59:22 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 19:59:22 --> Final output sent to browser
DEBUG - 2017-12-22 19:59:22 --> Total execution time: 0.0475
INFO - 2017-12-22 19:59:23 --> Config Class Initialized
INFO - 2017-12-22 19:59:23 --> Hooks Class Initialized
INFO - 2017-12-22 19:59:23 --> Config Class Initialized
INFO - 2017-12-22 19:59:23 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:59:23 --> UTF-8 Support Enabled
DEBUG - 2017-12-22 19:59:23 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:59:23 --> Utf8 Class Initialized
INFO - 2017-12-22 19:59:23 --> Utf8 Class Initialized
INFO - 2017-12-22 19:59:23 --> URI Class Initialized
INFO - 2017-12-22 19:59:23 --> URI Class Initialized
INFO - 2017-12-22 19:59:23 --> Router Class Initialized
INFO - 2017-12-22 19:59:23 --> Router Class Initialized
INFO - 2017-12-22 19:59:23 --> Output Class Initialized
INFO - 2017-12-22 19:59:23 --> Output Class Initialized
INFO - 2017-12-22 19:59:23 --> Security Class Initialized
INFO - 2017-12-22 19:59:23 --> Security Class Initialized
DEBUG - 2017-12-22 19:59:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-22 19:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:59:23 --> Input Class Initialized
INFO - 2017-12-22 19:59:23 --> Input Class Initialized
INFO - 2017-12-22 19:59:23 --> Language Class Initialized
INFO - 2017-12-22 19:59:23 --> Language Class Initialized
INFO - 2017-12-22 19:59:23 --> Loader Class Initialized
INFO - 2017-12-22 19:59:23 --> Loader Class Initialized
INFO - 2017-12-22 19:59:23 --> Helper loaded: url_helper
INFO - 2017-12-22 19:59:23 --> Helper loaded: url_helper
INFO - 2017-12-22 19:59:23 --> Helper loaded: form_helper
INFO - 2017-12-22 19:59:23 --> Helper loaded: form_helper
INFO - 2017-12-22 19:59:23 --> Database Driver Class Initialized
INFO - 2017-12-22 19:59:23 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:59:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:59:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2017-12-22 19:59:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:59:23 --> Form Validation Class Initialized
INFO - 2017-12-22 19:59:23 --> Model Class Initialized
INFO - 2017-12-22 19:59:23 --> Controller Class Initialized
INFO - 2017-12-22 19:59:23 --> Model Class Initialized
INFO - 2017-12-22 19:59:23 --> Model Class Initialized
INFO - 2017-12-22 19:59:23 --> Model Class Initialized
DEBUG - 2017-12-22 19:59:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:59:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:59:23 --> Form Validation Class Initialized
INFO - 2017-12-22 19:59:23 --> Model Class Initialized
INFO - 2017-12-22 19:59:23 --> Controller Class Initialized
INFO - 2017-12-22 19:59:23 --> Model Class Initialized
INFO - 2017-12-22 19:59:23 --> Model Class Initialized
INFO - 2017-12-22 19:59:23 --> Model Class Initialized
DEBUG - 2017-12-22 19:59:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:59:25 --> Config Class Initialized
INFO - 2017-12-22 19:59:25 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:59:25 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:59:25 --> Utf8 Class Initialized
INFO - 2017-12-22 19:59:25 --> URI Class Initialized
INFO - 2017-12-22 19:59:25 --> Router Class Initialized
INFO - 2017-12-22 19:59:25 --> Output Class Initialized
INFO - 2017-12-22 19:59:25 --> Security Class Initialized
DEBUG - 2017-12-22 19:59:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:59:25 --> Input Class Initialized
INFO - 2017-12-22 19:59:25 --> Language Class Initialized
INFO - 2017-12-22 19:59:25 --> Loader Class Initialized
INFO - 2017-12-22 19:59:25 --> Helper loaded: url_helper
INFO - 2017-12-22 19:59:25 --> Helper loaded: form_helper
INFO - 2017-12-22 19:59:25 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:59:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:59:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:59:25 --> Form Validation Class Initialized
INFO - 2017-12-22 19:59:25 --> Model Class Initialized
INFO - 2017-12-22 19:59:25 --> Controller Class Initialized
INFO - 2017-12-22 19:59:25 --> Model Class Initialized
INFO - 2017-12-22 19:59:25 --> Model Class Initialized
INFO - 2017-12-22 19:59:25 --> Model Class Initialized
DEBUG - 2017-12-22 19:59:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 19:59:25 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 19:59:25 --> Final output sent to browser
DEBUG - 2017-12-22 19:59:25 --> Total execution time: 0.0575
INFO - 2017-12-22 19:59:25 --> Config Class Initialized
INFO - 2017-12-22 19:59:25 --> Hooks Class Initialized
DEBUG - 2017-12-22 19:59:25 --> UTF-8 Support Enabled
INFO - 2017-12-22 19:59:25 --> Utf8 Class Initialized
INFO - 2017-12-22 19:59:25 --> URI Class Initialized
INFO - 2017-12-22 19:59:25 --> Router Class Initialized
INFO - 2017-12-22 19:59:25 --> Output Class Initialized
INFO - 2017-12-22 19:59:25 --> Security Class Initialized
DEBUG - 2017-12-22 19:59:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 19:59:25 --> Input Class Initialized
INFO - 2017-12-22 19:59:25 --> Language Class Initialized
INFO - 2017-12-22 19:59:25 --> Loader Class Initialized
INFO - 2017-12-22 19:59:25 --> Helper loaded: url_helper
INFO - 2017-12-22 19:59:25 --> Helper loaded: form_helper
INFO - 2017-12-22 19:59:25 --> Database Driver Class Initialized
DEBUG - 2017-12-22 19:59:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 19:59:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 19:59:25 --> Form Validation Class Initialized
INFO - 2017-12-22 19:59:25 --> Model Class Initialized
INFO - 2017-12-22 19:59:25 --> Controller Class Initialized
INFO - 2017-12-22 19:59:25 --> Model Class Initialized
INFO - 2017-12-22 19:59:25 --> Model Class Initialized
INFO - 2017-12-22 19:59:25 --> Model Class Initialized
DEBUG - 2017-12-22 19:59:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 20:00:33 --> Config Class Initialized
INFO - 2017-12-22 20:00:33 --> Hooks Class Initialized
DEBUG - 2017-12-22 20:00:33 --> UTF-8 Support Enabled
INFO - 2017-12-22 20:00:33 --> Utf8 Class Initialized
INFO - 2017-12-22 20:00:33 --> URI Class Initialized
INFO - 2017-12-22 20:00:33 --> Router Class Initialized
INFO - 2017-12-22 20:00:33 --> Output Class Initialized
INFO - 2017-12-22 20:00:33 --> Security Class Initialized
DEBUG - 2017-12-22 20:00:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 20:00:33 --> Input Class Initialized
INFO - 2017-12-22 20:00:33 --> Language Class Initialized
INFO - 2017-12-22 20:00:33 --> Loader Class Initialized
INFO - 2017-12-22 20:00:33 --> Helper loaded: url_helper
INFO - 2017-12-22 20:00:33 --> Helper loaded: form_helper
INFO - 2017-12-22 20:00:33 --> Database Driver Class Initialized
DEBUG - 2017-12-22 20:00:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 20:00:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 20:00:33 --> Form Validation Class Initialized
INFO - 2017-12-22 20:00:33 --> Model Class Initialized
INFO - 2017-12-22 20:00:33 --> Controller Class Initialized
INFO - 2017-12-22 20:00:33 --> Model Class Initialized
INFO - 2017-12-22 20:00:33 --> Model Class Initialized
INFO - 2017-12-22 20:00:33 --> Model Class Initialized
DEBUG - 2017-12-22 20:00:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 20:00:33 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 20:00:33 --> Final output sent to browser
DEBUG - 2017-12-22 20:00:33 --> Total execution time: 0.0604
INFO - 2017-12-22 20:00:34 --> Config Class Initialized
INFO - 2017-12-22 20:00:34 --> Hooks Class Initialized
INFO - 2017-12-22 20:00:34 --> Config Class Initialized
INFO - 2017-12-22 20:00:34 --> Hooks Class Initialized
DEBUG - 2017-12-22 20:00:34 --> UTF-8 Support Enabled
INFO - 2017-12-22 20:00:34 --> Utf8 Class Initialized
DEBUG - 2017-12-22 20:00:34 --> UTF-8 Support Enabled
INFO - 2017-12-22 20:00:34 --> Utf8 Class Initialized
INFO - 2017-12-22 20:00:34 --> URI Class Initialized
INFO - 2017-12-22 20:00:34 --> URI Class Initialized
INFO - 2017-12-22 20:00:34 --> Router Class Initialized
INFO - 2017-12-22 20:00:34 --> Router Class Initialized
INFO - 2017-12-22 20:00:34 --> Output Class Initialized
INFO - 2017-12-22 20:00:34 --> Output Class Initialized
INFO - 2017-12-22 20:00:34 --> Security Class Initialized
INFO - 2017-12-22 20:00:34 --> Security Class Initialized
DEBUG - 2017-12-22 20:00:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 20:00:34 --> Input Class Initialized
DEBUG - 2017-12-22 20:00:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 20:00:34 --> Language Class Initialized
INFO - 2017-12-22 20:00:34 --> Input Class Initialized
INFO - 2017-12-22 20:00:34 --> Language Class Initialized
INFO - 2017-12-22 20:00:34 --> Loader Class Initialized
INFO - 2017-12-22 20:00:34 --> Helper loaded: url_helper
INFO - 2017-12-22 20:00:34 --> Loader Class Initialized
INFO - 2017-12-22 20:00:34 --> Helper loaded: form_helper
INFO - 2017-12-22 20:00:34 --> Helper loaded: url_helper
INFO - 2017-12-22 20:00:34 --> Helper loaded: form_helper
INFO - 2017-12-22 20:00:34 --> Database Driver Class Initialized
INFO - 2017-12-22 20:00:34 --> Database Driver Class Initialized
DEBUG - 2017-12-22 20:00:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 20:00:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 20:00:34 --> Form Validation Class Initialized
DEBUG - 2017-12-22 20:00:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 20:00:34 --> Model Class Initialized
INFO - 2017-12-22 20:00:34 --> Controller Class Initialized
INFO - 2017-12-22 20:00:34 --> Model Class Initialized
INFO - 2017-12-22 20:00:34 --> Model Class Initialized
INFO - 2017-12-22 20:00:34 --> Model Class Initialized
DEBUG - 2017-12-22 20:00:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 20:00:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 20:00:34 --> Form Validation Class Initialized
INFO - 2017-12-22 20:00:34 --> Model Class Initialized
INFO - 2017-12-22 20:00:34 --> Controller Class Initialized
INFO - 2017-12-22 20:00:34 --> Model Class Initialized
INFO - 2017-12-22 20:00:34 --> Model Class Initialized
INFO - 2017-12-22 20:00:34 --> Model Class Initialized
DEBUG - 2017-12-22 20:00:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 20:03:54 --> Config Class Initialized
INFO - 2017-12-22 20:03:54 --> Hooks Class Initialized
DEBUG - 2017-12-22 20:03:54 --> UTF-8 Support Enabled
INFO - 2017-12-22 20:03:54 --> Utf8 Class Initialized
INFO - 2017-12-22 20:03:54 --> URI Class Initialized
INFO - 2017-12-22 20:03:54 --> Router Class Initialized
INFO - 2017-12-22 20:03:54 --> Output Class Initialized
INFO - 2017-12-22 20:03:54 --> Security Class Initialized
DEBUG - 2017-12-22 20:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 20:03:54 --> Input Class Initialized
INFO - 2017-12-22 20:03:54 --> Language Class Initialized
INFO - 2017-12-22 20:03:54 --> Loader Class Initialized
INFO - 2017-12-22 20:03:54 --> Helper loaded: url_helper
INFO - 2017-12-22 20:03:54 --> Helper loaded: form_helper
INFO - 2017-12-22 20:03:54 --> Database Driver Class Initialized
DEBUG - 2017-12-22 20:03:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 20:03:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 20:03:54 --> Form Validation Class Initialized
INFO - 2017-12-22 20:03:54 --> Model Class Initialized
INFO - 2017-12-22 20:03:54 --> Controller Class Initialized
INFO - 2017-12-22 20:03:55 --> Model Class Initialized
INFO - 2017-12-22 20:03:55 --> Model Class Initialized
INFO - 2017-12-22 20:03:55 --> Model Class Initialized
DEBUG - 2017-12-22 20:03:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 20:03:55 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 20:03:55 --> Final output sent to browser
DEBUG - 2017-12-22 20:03:55 --> Total execution time: 0.0582
INFO - 2017-12-22 20:03:55 --> Config Class Initialized
INFO - 2017-12-22 20:03:55 --> Hooks Class Initialized
DEBUG - 2017-12-22 20:03:55 --> UTF-8 Support Enabled
INFO - 2017-12-22 20:03:55 --> Utf8 Class Initialized
INFO - 2017-12-22 20:03:55 --> URI Class Initialized
INFO - 2017-12-22 20:03:55 --> Router Class Initialized
INFO - 2017-12-22 20:03:55 --> Output Class Initialized
INFO - 2017-12-22 20:03:55 --> Security Class Initialized
DEBUG - 2017-12-22 20:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 20:03:55 --> Input Class Initialized
INFO - 2017-12-22 20:03:55 --> Language Class Initialized
INFO - 2017-12-22 20:03:55 --> Loader Class Initialized
INFO - 2017-12-22 20:03:55 --> Helper loaded: url_helper
INFO - 2017-12-22 20:03:55 --> Helper loaded: form_helper
INFO - 2017-12-22 20:03:55 --> Database Driver Class Initialized
DEBUG - 2017-12-22 20:03:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 20:03:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 20:03:55 --> Form Validation Class Initialized
INFO - 2017-12-22 20:03:55 --> Model Class Initialized
INFO - 2017-12-22 20:03:55 --> Controller Class Initialized
INFO - 2017-12-22 20:03:55 --> Model Class Initialized
INFO - 2017-12-22 20:03:55 --> Model Class Initialized
INFO - 2017-12-22 20:03:55 --> Model Class Initialized
DEBUG - 2017-12-22 20:03:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 20:04:01 --> Config Class Initialized
INFO - 2017-12-22 20:04:01 --> Hooks Class Initialized
DEBUG - 2017-12-22 20:04:01 --> UTF-8 Support Enabled
INFO - 2017-12-22 20:04:01 --> Utf8 Class Initialized
INFO - 2017-12-22 20:04:01 --> URI Class Initialized
INFO - 2017-12-22 20:04:01 --> Router Class Initialized
INFO - 2017-12-22 20:04:01 --> Output Class Initialized
INFO - 2017-12-22 20:04:01 --> Security Class Initialized
DEBUG - 2017-12-22 20:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 20:04:01 --> Input Class Initialized
INFO - 2017-12-22 20:04:01 --> Language Class Initialized
INFO - 2017-12-22 20:04:01 --> Loader Class Initialized
INFO - 2017-12-22 20:04:01 --> Helper loaded: url_helper
INFO - 2017-12-22 20:04:01 --> Helper loaded: form_helper
INFO - 2017-12-22 20:04:01 --> Database Driver Class Initialized
DEBUG - 2017-12-22 20:04:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 20:04:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 20:04:01 --> Form Validation Class Initialized
INFO - 2017-12-22 20:04:01 --> Model Class Initialized
INFO - 2017-12-22 20:04:01 --> Controller Class Initialized
INFO - 2017-12-22 20:04:01 --> Model Class Initialized
INFO - 2017-12-22 20:04:01 --> Model Class Initialized
INFO - 2017-12-22 20:04:01 --> Model Class Initialized
DEBUG - 2017-12-22 20:04:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 20:04:01 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 20:04:01 --> Final output sent to browser
DEBUG - 2017-12-22 20:04:01 --> Total execution time: 0.0630
INFO - 2017-12-22 20:04:01 --> Config Class Initialized
INFO - 2017-12-22 20:04:01 --> Hooks Class Initialized
INFO - 2017-12-22 20:04:01 --> Config Class Initialized
INFO - 2017-12-22 20:04:01 --> Hooks Class Initialized
DEBUG - 2017-12-22 20:04:01 --> UTF-8 Support Enabled
DEBUG - 2017-12-22 20:04:01 --> UTF-8 Support Enabled
INFO - 2017-12-22 20:04:01 --> Utf8 Class Initialized
INFO - 2017-12-22 20:04:01 --> Utf8 Class Initialized
INFO - 2017-12-22 20:04:01 --> URI Class Initialized
INFO - 2017-12-22 20:04:01 --> URI Class Initialized
INFO - 2017-12-22 20:04:01 --> Router Class Initialized
INFO - 2017-12-22 20:04:01 --> Router Class Initialized
INFO - 2017-12-22 20:04:01 --> Output Class Initialized
INFO - 2017-12-22 20:04:01 --> Output Class Initialized
INFO - 2017-12-22 20:04:01 --> Security Class Initialized
INFO - 2017-12-22 20:04:01 --> Security Class Initialized
DEBUG - 2017-12-22 20:04:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-22 20:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 20:04:01 --> Input Class Initialized
INFO - 2017-12-22 20:04:01 --> Input Class Initialized
INFO - 2017-12-22 20:04:01 --> Language Class Initialized
INFO - 2017-12-22 20:04:01 --> Language Class Initialized
INFO - 2017-12-22 20:04:01 --> Loader Class Initialized
INFO - 2017-12-22 20:04:01 --> Loader Class Initialized
INFO - 2017-12-22 20:04:01 --> Helper loaded: url_helper
INFO - 2017-12-22 20:04:01 --> Helper loaded: url_helper
INFO - 2017-12-22 20:04:01 --> Helper loaded: form_helper
INFO - 2017-12-22 20:04:01 --> Helper loaded: form_helper
INFO - 2017-12-22 20:04:01 --> Database Driver Class Initialized
INFO - 2017-12-22 20:04:01 --> Database Driver Class Initialized
DEBUG - 2017-12-22 20:04:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2017-12-22 20:04:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 20:04:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 20:04:02 --> Form Validation Class Initialized
INFO - 2017-12-22 20:04:02 --> Model Class Initialized
INFO - 2017-12-22 20:04:02 --> Controller Class Initialized
INFO - 2017-12-22 20:04:02 --> Model Class Initialized
INFO - 2017-12-22 20:04:02 --> Model Class Initialized
INFO - 2017-12-22 20:04:02 --> Model Class Initialized
DEBUG - 2017-12-22 20:04:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 20:04:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 20:04:02 --> Form Validation Class Initialized
INFO - 2017-12-22 20:04:02 --> Model Class Initialized
INFO - 2017-12-22 20:04:02 --> Controller Class Initialized
INFO - 2017-12-22 20:04:02 --> Model Class Initialized
INFO - 2017-12-22 20:04:02 --> Model Class Initialized
INFO - 2017-12-22 20:04:02 --> Model Class Initialized
DEBUG - 2017-12-22 20:04:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 20:04:05 --> Config Class Initialized
INFO - 2017-12-22 20:04:05 --> Hooks Class Initialized
DEBUG - 2017-12-22 20:04:05 --> UTF-8 Support Enabled
INFO - 2017-12-22 20:04:05 --> Utf8 Class Initialized
INFO - 2017-12-22 20:04:05 --> URI Class Initialized
INFO - 2017-12-22 20:04:05 --> Router Class Initialized
INFO - 2017-12-22 20:04:05 --> Output Class Initialized
INFO - 2017-12-22 20:04:05 --> Security Class Initialized
DEBUG - 2017-12-22 20:04:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 20:04:05 --> Input Class Initialized
INFO - 2017-12-22 20:04:05 --> Language Class Initialized
INFO - 2017-12-22 20:04:05 --> Loader Class Initialized
INFO - 2017-12-22 20:04:05 --> Helper loaded: url_helper
INFO - 2017-12-22 20:04:05 --> Helper loaded: form_helper
INFO - 2017-12-22 20:04:05 --> Database Driver Class Initialized
DEBUG - 2017-12-22 20:04:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 20:04:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 20:04:05 --> Form Validation Class Initialized
INFO - 2017-12-22 20:04:05 --> Model Class Initialized
INFO - 2017-12-22 20:04:05 --> Controller Class Initialized
INFO - 2017-12-22 20:04:05 --> Model Class Initialized
INFO - 2017-12-22 20:04:05 --> Model Class Initialized
INFO - 2017-12-22 20:04:05 --> Model Class Initialized
DEBUG - 2017-12-22 20:04:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 20:04:05 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 20:04:05 --> Final output sent to browser
DEBUG - 2017-12-22 20:04:05 --> Total execution time: 0.0462
INFO - 2017-12-22 20:04:05 --> Config Class Initialized
INFO - 2017-12-22 20:04:05 --> Hooks Class Initialized
DEBUG - 2017-12-22 20:04:05 --> UTF-8 Support Enabled
INFO - 2017-12-22 20:04:05 --> Utf8 Class Initialized
INFO - 2017-12-22 20:04:05 --> URI Class Initialized
INFO - 2017-12-22 20:04:05 --> Router Class Initialized
INFO - 2017-12-22 20:04:05 --> Output Class Initialized
INFO - 2017-12-22 20:04:05 --> Security Class Initialized
DEBUG - 2017-12-22 20:04:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 20:04:05 --> Input Class Initialized
INFO - 2017-12-22 20:04:05 --> Language Class Initialized
INFO - 2017-12-22 20:04:05 --> Loader Class Initialized
INFO - 2017-12-22 20:04:05 --> Helper loaded: url_helper
INFO - 2017-12-22 20:04:05 --> Helper loaded: form_helper
INFO - 2017-12-22 20:04:05 --> Database Driver Class Initialized
DEBUG - 2017-12-22 20:04:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 20:04:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 20:04:05 --> Form Validation Class Initialized
INFO - 2017-12-22 20:04:05 --> Model Class Initialized
INFO - 2017-12-22 20:04:05 --> Controller Class Initialized
INFO - 2017-12-22 20:04:05 --> Model Class Initialized
INFO - 2017-12-22 20:04:05 --> Model Class Initialized
INFO - 2017-12-22 20:04:05 --> Model Class Initialized
DEBUG - 2017-12-22 20:04:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 20:04:13 --> Config Class Initialized
INFO - 2017-12-22 20:04:13 --> Hooks Class Initialized
DEBUG - 2017-12-22 20:04:13 --> UTF-8 Support Enabled
INFO - 2017-12-22 20:04:13 --> Utf8 Class Initialized
INFO - 2017-12-22 20:04:13 --> URI Class Initialized
INFO - 2017-12-22 20:04:13 --> Router Class Initialized
INFO - 2017-12-22 20:04:13 --> Output Class Initialized
INFO - 2017-12-22 20:04:13 --> Security Class Initialized
DEBUG - 2017-12-22 20:04:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 20:04:13 --> Input Class Initialized
INFO - 2017-12-22 20:04:13 --> Language Class Initialized
INFO - 2017-12-22 20:04:13 --> Loader Class Initialized
INFO - 2017-12-22 20:04:13 --> Helper loaded: url_helper
INFO - 2017-12-22 20:04:13 --> Helper loaded: form_helper
INFO - 2017-12-22 20:04:13 --> Database Driver Class Initialized
DEBUG - 2017-12-22 20:04:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 20:04:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 20:04:13 --> Form Validation Class Initialized
INFO - 2017-12-22 20:04:13 --> Model Class Initialized
INFO - 2017-12-22 20:04:13 --> Controller Class Initialized
INFO - 2017-12-22 20:04:13 --> Model Class Initialized
INFO - 2017-12-22 20:04:13 --> Model Class Initialized
INFO - 2017-12-22 20:04:13 --> Model Class Initialized
DEBUG - 2017-12-22 20:04:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 20:04:13 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 20:04:13 --> Final output sent to browser
DEBUG - 2017-12-22 20:04:13 --> Total execution time: 0.0752
INFO - 2017-12-22 20:04:13 --> Config Class Initialized
INFO - 2017-12-22 20:04:13 --> Hooks Class Initialized
DEBUG - 2017-12-22 20:04:13 --> UTF-8 Support Enabled
INFO - 2017-12-22 20:04:13 --> Utf8 Class Initialized
INFO - 2017-12-22 20:04:13 --> URI Class Initialized
INFO - 2017-12-22 20:04:13 --> Router Class Initialized
INFO - 2017-12-22 20:04:13 --> Output Class Initialized
INFO - 2017-12-22 20:04:13 --> Security Class Initialized
DEBUG - 2017-12-22 20:04:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 20:04:13 --> Input Class Initialized
INFO - 2017-12-22 20:04:13 --> Language Class Initialized
INFO - 2017-12-22 20:04:13 --> Loader Class Initialized
INFO - 2017-12-22 20:04:13 --> Helper loaded: url_helper
INFO - 2017-12-22 20:04:13 --> Helper loaded: form_helper
INFO - 2017-12-22 20:04:13 --> Database Driver Class Initialized
DEBUG - 2017-12-22 20:04:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 20:04:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 20:04:14 --> Form Validation Class Initialized
INFO - 2017-12-22 20:04:14 --> Model Class Initialized
INFO - 2017-12-22 20:04:14 --> Controller Class Initialized
INFO - 2017-12-22 20:04:14 --> Model Class Initialized
INFO - 2017-12-22 20:04:14 --> Model Class Initialized
INFO - 2017-12-22 20:04:14 --> Model Class Initialized
DEBUG - 2017-12-22 20:04:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 20:05:27 --> Config Class Initialized
INFO - 2017-12-22 20:05:27 --> Hooks Class Initialized
DEBUG - 2017-12-22 20:05:27 --> UTF-8 Support Enabled
INFO - 2017-12-22 20:05:27 --> Utf8 Class Initialized
INFO - 2017-12-22 20:05:27 --> URI Class Initialized
INFO - 2017-12-22 20:05:27 --> Router Class Initialized
INFO - 2017-12-22 20:05:27 --> Output Class Initialized
INFO - 2017-12-22 20:05:27 --> Security Class Initialized
DEBUG - 2017-12-22 20:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 20:05:27 --> Input Class Initialized
INFO - 2017-12-22 20:05:27 --> Language Class Initialized
INFO - 2017-12-22 20:05:27 --> Loader Class Initialized
INFO - 2017-12-22 20:05:27 --> Helper loaded: url_helper
INFO - 2017-12-22 20:05:27 --> Helper loaded: form_helper
INFO - 2017-12-22 20:05:27 --> Database Driver Class Initialized
DEBUG - 2017-12-22 20:05:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 20:05:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 20:05:27 --> Form Validation Class Initialized
INFO - 2017-12-22 20:05:27 --> Model Class Initialized
INFO - 2017-12-22 20:05:27 --> Controller Class Initialized
INFO - 2017-12-22 20:05:27 --> Model Class Initialized
INFO - 2017-12-22 20:05:27 --> Model Class Initialized
INFO - 2017-12-22 20:05:27 --> Model Class Initialized
DEBUG - 2017-12-22 20:05:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 20:05:27 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 20:05:27 --> Final output sent to browser
DEBUG - 2017-12-22 20:05:27 --> Total execution time: 0.0670
INFO - 2017-12-22 20:05:27 --> Config Class Initialized
INFO - 2017-12-22 20:05:27 --> Hooks Class Initialized
DEBUG - 2017-12-22 20:05:27 --> UTF-8 Support Enabled
INFO - 2017-12-22 20:05:27 --> Utf8 Class Initialized
INFO - 2017-12-22 20:05:27 --> URI Class Initialized
INFO - 2017-12-22 20:05:27 --> Router Class Initialized
INFO - 2017-12-22 20:05:27 --> Output Class Initialized
INFO - 2017-12-22 20:05:27 --> Security Class Initialized
DEBUG - 2017-12-22 20:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 20:05:27 --> Input Class Initialized
INFO - 2017-12-22 20:05:27 --> Language Class Initialized
INFO - 2017-12-22 20:05:27 --> Loader Class Initialized
INFO - 2017-12-22 20:05:27 --> Helper loaded: url_helper
INFO - 2017-12-22 20:05:27 --> Helper loaded: form_helper
INFO - 2017-12-22 20:05:27 --> Database Driver Class Initialized
DEBUG - 2017-12-22 20:05:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 20:05:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 20:05:27 --> Form Validation Class Initialized
INFO - 2017-12-22 20:05:27 --> Model Class Initialized
INFO - 2017-12-22 20:05:27 --> Controller Class Initialized
INFO - 2017-12-22 20:05:27 --> Model Class Initialized
INFO - 2017-12-22 20:05:27 --> Model Class Initialized
INFO - 2017-12-22 20:05:27 --> Model Class Initialized
DEBUG - 2017-12-22 20:05:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 20:06:05 --> Config Class Initialized
INFO - 2017-12-22 20:06:05 --> Hooks Class Initialized
DEBUG - 2017-12-22 20:06:05 --> UTF-8 Support Enabled
INFO - 2017-12-22 20:06:05 --> Utf8 Class Initialized
INFO - 2017-12-22 20:06:05 --> URI Class Initialized
INFO - 2017-12-22 20:06:06 --> Router Class Initialized
INFO - 2017-12-22 20:06:06 --> Output Class Initialized
INFO - 2017-12-22 20:06:06 --> Security Class Initialized
DEBUG - 2017-12-22 20:06:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 20:06:06 --> Input Class Initialized
INFO - 2017-12-22 20:06:06 --> Language Class Initialized
INFO - 2017-12-22 20:06:06 --> Loader Class Initialized
INFO - 2017-12-22 20:06:06 --> Helper loaded: url_helper
INFO - 2017-12-22 20:06:06 --> Helper loaded: form_helper
INFO - 2017-12-22 20:06:06 --> Database Driver Class Initialized
DEBUG - 2017-12-22 20:06:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 20:06:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 20:06:06 --> Form Validation Class Initialized
INFO - 2017-12-22 20:06:06 --> Model Class Initialized
INFO - 2017-12-22 20:06:06 --> Controller Class Initialized
INFO - 2017-12-22 20:06:06 --> Model Class Initialized
INFO - 2017-12-22 20:06:06 --> Model Class Initialized
INFO - 2017-12-22 20:06:06 --> Model Class Initialized
DEBUG - 2017-12-22 20:06:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 20:06:06 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 20:06:06 --> Final output sent to browser
DEBUG - 2017-12-22 20:06:06 --> Total execution time: 0.0723
INFO - 2017-12-22 20:06:06 --> Config Class Initialized
INFO - 2017-12-22 20:06:06 --> Hooks Class Initialized
DEBUG - 2017-12-22 20:06:06 --> UTF-8 Support Enabled
INFO - 2017-12-22 20:06:06 --> Utf8 Class Initialized
INFO - 2017-12-22 20:06:06 --> URI Class Initialized
INFO - 2017-12-22 20:06:06 --> Router Class Initialized
INFO - 2017-12-22 20:06:06 --> Output Class Initialized
INFO - 2017-12-22 20:06:06 --> Security Class Initialized
DEBUG - 2017-12-22 20:06:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 20:06:06 --> Input Class Initialized
INFO - 2017-12-22 20:06:06 --> Language Class Initialized
INFO - 2017-12-22 20:06:06 --> Loader Class Initialized
INFO - 2017-12-22 20:06:06 --> Helper loaded: url_helper
INFO - 2017-12-22 20:06:06 --> Helper loaded: form_helper
INFO - 2017-12-22 20:06:06 --> Database Driver Class Initialized
DEBUG - 2017-12-22 20:06:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 20:06:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 20:06:06 --> Form Validation Class Initialized
INFO - 2017-12-22 20:06:06 --> Model Class Initialized
INFO - 2017-12-22 20:06:06 --> Controller Class Initialized
INFO - 2017-12-22 20:06:06 --> Model Class Initialized
INFO - 2017-12-22 20:06:06 --> Model Class Initialized
INFO - 2017-12-22 20:06:06 --> Model Class Initialized
DEBUG - 2017-12-22 20:06:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 20:06:31 --> Config Class Initialized
INFO - 2017-12-22 20:06:31 --> Hooks Class Initialized
DEBUG - 2017-12-22 20:06:31 --> UTF-8 Support Enabled
INFO - 2017-12-22 20:06:31 --> Utf8 Class Initialized
INFO - 2017-12-22 20:06:31 --> URI Class Initialized
INFO - 2017-12-22 20:06:31 --> Router Class Initialized
INFO - 2017-12-22 20:06:31 --> Output Class Initialized
INFO - 2017-12-22 20:06:31 --> Security Class Initialized
DEBUG - 2017-12-22 20:06:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 20:06:31 --> Input Class Initialized
INFO - 2017-12-22 20:06:31 --> Language Class Initialized
INFO - 2017-12-22 20:06:31 --> Loader Class Initialized
INFO - 2017-12-22 20:06:31 --> Helper loaded: url_helper
INFO - 2017-12-22 20:06:31 --> Helper loaded: form_helper
INFO - 2017-12-22 20:06:31 --> Database Driver Class Initialized
DEBUG - 2017-12-22 20:06:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 20:06:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 20:06:31 --> Form Validation Class Initialized
INFO - 2017-12-22 20:06:31 --> Model Class Initialized
INFO - 2017-12-22 20:06:31 --> Controller Class Initialized
INFO - 2017-12-22 20:06:31 --> Model Class Initialized
INFO - 2017-12-22 20:06:31 --> Model Class Initialized
INFO - 2017-12-22 20:06:31 --> Model Class Initialized
DEBUG - 2017-12-22 20:06:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 20:06:31 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 20:06:31 --> Final output sent to browser
DEBUG - 2017-12-22 20:06:31 --> Total execution time: 0.0717
INFO - 2017-12-22 20:06:32 --> Config Class Initialized
INFO - 2017-12-22 20:06:32 --> Hooks Class Initialized
DEBUG - 2017-12-22 20:06:32 --> UTF-8 Support Enabled
INFO - 2017-12-22 20:06:32 --> Utf8 Class Initialized
INFO - 2017-12-22 20:06:32 --> URI Class Initialized
INFO - 2017-12-22 20:06:32 --> Router Class Initialized
INFO - 2017-12-22 20:06:32 --> Output Class Initialized
INFO - 2017-12-22 20:06:32 --> Security Class Initialized
DEBUG - 2017-12-22 20:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 20:06:32 --> Input Class Initialized
INFO - 2017-12-22 20:06:32 --> Language Class Initialized
INFO - 2017-12-22 20:06:32 --> Loader Class Initialized
INFO - 2017-12-22 20:06:32 --> Helper loaded: url_helper
INFO - 2017-12-22 20:06:32 --> Helper loaded: form_helper
INFO - 2017-12-22 20:06:32 --> Database Driver Class Initialized
DEBUG - 2017-12-22 20:06:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 20:06:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 20:06:32 --> Form Validation Class Initialized
INFO - 2017-12-22 20:06:32 --> Model Class Initialized
INFO - 2017-12-22 20:06:32 --> Controller Class Initialized
INFO - 2017-12-22 20:06:32 --> Model Class Initialized
INFO - 2017-12-22 20:06:32 --> Model Class Initialized
INFO - 2017-12-22 20:06:32 --> Model Class Initialized
DEBUG - 2017-12-22 20:06:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 20:06:58 --> Config Class Initialized
INFO - 2017-12-22 20:06:58 --> Hooks Class Initialized
DEBUG - 2017-12-22 20:06:58 --> UTF-8 Support Enabled
INFO - 2017-12-22 20:06:58 --> Utf8 Class Initialized
INFO - 2017-12-22 20:06:58 --> URI Class Initialized
INFO - 2017-12-22 20:06:58 --> Router Class Initialized
INFO - 2017-12-22 20:06:58 --> Output Class Initialized
INFO - 2017-12-22 20:06:58 --> Security Class Initialized
DEBUG - 2017-12-22 20:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 20:06:58 --> Input Class Initialized
INFO - 2017-12-22 20:06:58 --> Language Class Initialized
INFO - 2017-12-22 20:06:58 --> Loader Class Initialized
INFO - 2017-12-22 20:06:58 --> Helper loaded: url_helper
INFO - 2017-12-22 20:06:58 --> Helper loaded: form_helper
INFO - 2017-12-22 20:06:58 --> Database Driver Class Initialized
DEBUG - 2017-12-22 20:06:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 20:06:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 20:06:58 --> Form Validation Class Initialized
INFO - 2017-12-22 20:06:58 --> Model Class Initialized
INFO - 2017-12-22 20:06:58 --> Controller Class Initialized
INFO - 2017-12-22 20:06:58 --> Model Class Initialized
INFO - 2017-12-22 20:06:58 --> Model Class Initialized
INFO - 2017-12-22 20:06:58 --> Model Class Initialized
DEBUG - 2017-12-22 20:06:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 20:06:58 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 20:06:58 --> Final output sent to browser
DEBUG - 2017-12-22 20:06:58 --> Total execution time: 0.0820
INFO - 2017-12-22 20:06:58 --> Config Class Initialized
INFO - 2017-12-22 20:06:58 --> Hooks Class Initialized
DEBUG - 2017-12-22 20:06:58 --> UTF-8 Support Enabled
INFO - 2017-12-22 20:06:58 --> Utf8 Class Initialized
INFO - 2017-12-22 20:06:58 --> URI Class Initialized
INFO - 2017-12-22 20:06:58 --> Router Class Initialized
INFO - 2017-12-22 20:06:58 --> Output Class Initialized
INFO - 2017-12-22 20:06:58 --> Security Class Initialized
DEBUG - 2017-12-22 20:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 20:06:58 --> Input Class Initialized
INFO - 2017-12-22 20:06:58 --> Language Class Initialized
INFO - 2017-12-22 20:06:58 --> Loader Class Initialized
INFO - 2017-12-22 20:06:58 --> Helper loaded: url_helper
INFO - 2017-12-22 20:06:58 --> Helper loaded: form_helper
INFO - 2017-12-22 20:06:58 --> Database Driver Class Initialized
DEBUG - 2017-12-22 20:06:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 20:06:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 20:06:58 --> Form Validation Class Initialized
INFO - 2017-12-22 20:06:58 --> Model Class Initialized
INFO - 2017-12-22 20:06:58 --> Controller Class Initialized
INFO - 2017-12-22 20:06:58 --> Model Class Initialized
INFO - 2017-12-22 20:06:58 --> Model Class Initialized
INFO - 2017-12-22 20:06:58 --> Model Class Initialized
DEBUG - 2017-12-22 20:06:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 20:07:05 --> Config Class Initialized
INFO - 2017-12-22 20:07:05 --> Hooks Class Initialized
DEBUG - 2017-12-22 20:07:05 --> UTF-8 Support Enabled
INFO - 2017-12-22 20:07:05 --> Utf8 Class Initialized
INFO - 2017-12-22 20:07:05 --> URI Class Initialized
INFO - 2017-12-22 20:07:05 --> Router Class Initialized
INFO - 2017-12-22 20:07:05 --> Output Class Initialized
INFO - 2017-12-22 20:07:05 --> Security Class Initialized
DEBUG - 2017-12-22 20:07:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 20:07:05 --> Input Class Initialized
INFO - 2017-12-22 20:07:05 --> Language Class Initialized
INFO - 2017-12-22 20:07:05 --> Loader Class Initialized
INFO - 2017-12-22 20:07:05 --> Helper loaded: url_helper
INFO - 2017-12-22 20:07:05 --> Helper loaded: form_helper
INFO - 2017-12-22 20:07:05 --> Database Driver Class Initialized
DEBUG - 2017-12-22 20:07:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 20:07:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 20:07:05 --> Form Validation Class Initialized
INFO - 2017-12-22 20:07:05 --> Model Class Initialized
INFO - 2017-12-22 20:07:05 --> Controller Class Initialized
INFO - 2017-12-22 20:07:05 --> Model Class Initialized
INFO - 2017-12-22 20:07:05 --> Model Class Initialized
INFO - 2017-12-22 20:07:05 --> Model Class Initialized
DEBUG - 2017-12-22 20:07:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 20:07:05 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 20:07:05 --> Final output sent to browser
DEBUG - 2017-12-22 20:07:05 --> Total execution time: 0.0925
INFO - 2017-12-22 20:07:05 --> Config Class Initialized
INFO - 2017-12-22 20:07:05 --> Hooks Class Initialized
DEBUG - 2017-12-22 20:07:05 --> UTF-8 Support Enabled
INFO - 2017-12-22 20:07:05 --> Utf8 Class Initialized
INFO - 2017-12-22 20:07:05 --> URI Class Initialized
INFO - 2017-12-22 20:07:05 --> Router Class Initialized
INFO - 2017-12-22 20:07:05 --> Output Class Initialized
INFO - 2017-12-22 20:07:05 --> Security Class Initialized
DEBUG - 2017-12-22 20:07:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 20:07:05 --> Input Class Initialized
INFO - 2017-12-22 20:07:05 --> Language Class Initialized
INFO - 2017-12-22 20:07:05 --> Loader Class Initialized
INFO - 2017-12-22 20:07:05 --> Helper loaded: url_helper
INFO - 2017-12-22 20:07:05 --> Helper loaded: form_helper
INFO - 2017-12-22 20:07:05 --> Database Driver Class Initialized
DEBUG - 2017-12-22 20:07:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 20:07:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 20:07:05 --> Form Validation Class Initialized
INFO - 2017-12-22 20:07:05 --> Model Class Initialized
INFO - 2017-12-22 20:07:05 --> Controller Class Initialized
INFO - 2017-12-22 20:07:05 --> Model Class Initialized
INFO - 2017-12-22 20:07:05 --> Model Class Initialized
INFO - 2017-12-22 20:07:05 --> Model Class Initialized
DEBUG - 2017-12-22 20:07:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 20:08:07 --> Config Class Initialized
INFO - 2017-12-22 20:08:07 --> Hooks Class Initialized
DEBUG - 2017-12-22 20:08:07 --> UTF-8 Support Enabled
INFO - 2017-12-22 20:08:07 --> Utf8 Class Initialized
INFO - 2017-12-22 20:08:07 --> URI Class Initialized
INFO - 2017-12-22 20:08:07 --> Router Class Initialized
INFO - 2017-12-22 20:08:07 --> Output Class Initialized
INFO - 2017-12-22 20:08:07 --> Security Class Initialized
DEBUG - 2017-12-22 20:08:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 20:08:07 --> Input Class Initialized
INFO - 2017-12-22 20:08:07 --> Language Class Initialized
INFO - 2017-12-22 20:08:07 --> Loader Class Initialized
INFO - 2017-12-22 20:08:07 --> Helper loaded: url_helper
INFO - 2017-12-22 20:08:07 --> Helper loaded: form_helper
INFO - 2017-12-22 20:08:07 --> Database Driver Class Initialized
DEBUG - 2017-12-22 20:08:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 20:08:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 20:08:07 --> Form Validation Class Initialized
INFO - 2017-12-22 20:08:07 --> Model Class Initialized
INFO - 2017-12-22 20:08:07 --> Controller Class Initialized
INFO - 2017-12-22 20:08:07 --> Model Class Initialized
INFO - 2017-12-22 20:08:07 --> Model Class Initialized
INFO - 2017-12-22 20:08:07 --> Model Class Initialized
DEBUG - 2017-12-22 20:08:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 20:08:07 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 20:08:07 --> Final output sent to browser
DEBUG - 2017-12-22 20:08:07 --> Total execution time: 0.0640
INFO - 2017-12-22 20:08:08 --> Config Class Initialized
INFO - 2017-12-22 20:08:08 --> Hooks Class Initialized
DEBUG - 2017-12-22 20:08:08 --> UTF-8 Support Enabled
INFO - 2017-12-22 20:08:08 --> Utf8 Class Initialized
INFO - 2017-12-22 20:08:08 --> URI Class Initialized
INFO - 2017-12-22 20:08:08 --> Router Class Initialized
INFO - 2017-12-22 20:08:08 --> Output Class Initialized
INFO - 2017-12-22 20:08:08 --> Security Class Initialized
DEBUG - 2017-12-22 20:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 20:08:08 --> Input Class Initialized
INFO - 2017-12-22 20:08:08 --> Language Class Initialized
INFO - 2017-12-22 20:08:08 --> Loader Class Initialized
INFO - 2017-12-22 20:08:08 --> Helper loaded: url_helper
INFO - 2017-12-22 20:08:08 --> Helper loaded: form_helper
INFO - 2017-12-22 20:08:08 --> Database Driver Class Initialized
DEBUG - 2017-12-22 20:08:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 20:08:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 20:08:08 --> Form Validation Class Initialized
INFO - 2017-12-22 20:08:08 --> Model Class Initialized
INFO - 2017-12-22 20:08:08 --> Controller Class Initialized
INFO - 2017-12-22 20:08:08 --> Model Class Initialized
INFO - 2017-12-22 20:08:08 --> Model Class Initialized
INFO - 2017-12-22 20:08:08 --> Model Class Initialized
DEBUG - 2017-12-22 20:08:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 20:12:15 --> Config Class Initialized
INFO - 2017-12-22 20:12:15 --> Hooks Class Initialized
DEBUG - 2017-12-22 20:12:15 --> UTF-8 Support Enabled
INFO - 2017-12-22 20:12:15 --> Utf8 Class Initialized
INFO - 2017-12-22 20:12:15 --> URI Class Initialized
INFO - 2017-12-22 20:12:15 --> Router Class Initialized
INFO - 2017-12-22 20:12:15 --> Output Class Initialized
INFO - 2017-12-22 20:12:15 --> Security Class Initialized
DEBUG - 2017-12-22 20:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 20:12:15 --> Input Class Initialized
INFO - 2017-12-22 20:12:15 --> Language Class Initialized
INFO - 2017-12-22 20:12:15 --> Loader Class Initialized
INFO - 2017-12-22 20:12:15 --> Helper loaded: url_helper
INFO - 2017-12-22 20:12:15 --> Helper loaded: form_helper
INFO - 2017-12-22 20:12:15 --> Database Driver Class Initialized
DEBUG - 2017-12-22 20:12:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 20:12:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 20:12:15 --> Form Validation Class Initialized
INFO - 2017-12-22 20:12:15 --> Model Class Initialized
INFO - 2017-12-22 20:12:15 --> Controller Class Initialized
INFO - 2017-12-22 20:12:15 --> Model Class Initialized
INFO - 2017-12-22 20:12:15 --> Model Class Initialized
INFO - 2017-12-22 20:12:15 --> Model Class Initialized
DEBUG - 2017-12-22 20:12:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 20:12:15 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 20:12:15 --> Final output sent to browser
DEBUG - 2017-12-22 20:12:15 --> Total execution time: 0.0786
INFO - 2017-12-22 20:12:15 --> Config Class Initialized
INFO - 2017-12-22 20:12:15 --> Hooks Class Initialized
DEBUG - 2017-12-22 20:12:15 --> UTF-8 Support Enabled
INFO - 2017-12-22 20:12:15 --> Utf8 Class Initialized
INFO - 2017-12-22 20:12:15 --> URI Class Initialized
INFO - 2017-12-22 20:12:15 --> Router Class Initialized
INFO - 2017-12-22 20:12:15 --> Output Class Initialized
INFO - 2017-12-22 20:12:15 --> Security Class Initialized
DEBUG - 2017-12-22 20:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 20:12:15 --> Input Class Initialized
INFO - 2017-12-22 20:12:15 --> Language Class Initialized
INFO - 2017-12-22 20:12:15 --> Loader Class Initialized
INFO - 2017-12-22 20:12:15 --> Helper loaded: url_helper
INFO - 2017-12-22 20:12:15 --> Helper loaded: form_helper
INFO - 2017-12-22 20:12:15 --> Database Driver Class Initialized
DEBUG - 2017-12-22 20:12:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 20:12:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 20:12:15 --> Form Validation Class Initialized
INFO - 2017-12-22 20:12:15 --> Model Class Initialized
INFO - 2017-12-22 20:12:15 --> Controller Class Initialized
INFO - 2017-12-22 20:12:15 --> Model Class Initialized
INFO - 2017-12-22 20:12:15 --> Model Class Initialized
INFO - 2017-12-22 20:12:15 --> Model Class Initialized
DEBUG - 2017-12-22 20:12:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 20:12:20 --> Config Class Initialized
INFO - 2017-12-22 20:12:20 --> Hooks Class Initialized
DEBUG - 2017-12-22 20:12:20 --> UTF-8 Support Enabled
INFO - 2017-12-22 20:12:20 --> Utf8 Class Initialized
INFO - 2017-12-22 20:12:20 --> URI Class Initialized
INFO - 2017-12-22 20:12:20 --> Router Class Initialized
INFO - 2017-12-22 20:12:20 --> Output Class Initialized
INFO - 2017-12-22 20:12:20 --> Security Class Initialized
DEBUG - 2017-12-22 20:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 20:12:20 --> Input Class Initialized
INFO - 2017-12-22 20:12:20 --> Language Class Initialized
INFO - 2017-12-22 20:12:20 --> Loader Class Initialized
INFO - 2017-12-22 20:12:20 --> Helper loaded: url_helper
INFO - 2017-12-22 20:12:20 --> Helper loaded: form_helper
INFO - 2017-12-22 20:12:20 --> Database Driver Class Initialized
DEBUG - 2017-12-22 20:12:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 20:12:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 20:12:20 --> Form Validation Class Initialized
INFO - 2017-12-22 20:12:20 --> Model Class Initialized
INFO - 2017-12-22 20:12:20 --> Controller Class Initialized
INFO - 2017-12-22 20:12:20 --> Model Class Initialized
INFO - 2017-12-22 20:12:20 --> Model Class Initialized
INFO - 2017-12-22 20:12:20 --> Model Class Initialized
DEBUG - 2017-12-22 20:12:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 20:12:20 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 20:12:20 --> Final output sent to browser
DEBUG - 2017-12-22 20:12:20 --> Total execution time: 0.0460
INFO - 2017-12-22 20:12:20 --> Config Class Initialized
INFO - 2017-12-22 20:12:20 --> Hooks Class Initialized
DEBUG - 2017-12-22 20:12:20 --> UTF-8 Support Enabled
INFO - 2017-12-22 20:12:20 --> Utf8 Class Initialized
INFO - 2017-12-22 20:12:20 --> URI Class Initialized
INFO - 2017-12-22 20:12:20 --> Router Class Initialized
INFO - 2017-12-22 20:12:20 --> Output Class Initialized
INFO - 2017-12-22 20:12:20 --> Security Class Initialized
DEBUG - 2017-12-22 20:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 20:12:20 --> Input Class Initialized
INFO - 2017-12-22 20:12:20 --> Language Class Initialized
INFO - 2017-12-22 20:12:20 --> Loader Class Initialized
INFO - 2017-12-22 20:12:20 --> Helper loaded: url_helper
INFO - 2017-12-22 20:12:20 --> Helper loaded: form_helper
INFO - 2017-12-22 20:12:20 --> Database Driver Class Initialized
DEBUG - 2017-12-22 20:12:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 20:12:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 20:12:20 --> Form Validation Class Initialized
INFO - 2017-12-22 20:12:20 --> Model Class Initialized
INFO - 2017-12-22 20:12:20 --> Controller Class Initialized
INFO - 2017-12-22 20:12:20 --> Model Class Initialized
INFO - 2017-12-22 20:12:20 --> Model Class Initialized
INFO - 2017-12-22 20:12:20 --> Model Class Initialized
DEBUG - 2017-12-22 20:12:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 20:12:32 --> Config Class Initialized
INFO - 2017-12-22 20:12:32 --> Hooks Class Initialized
DEBUG - 2017-12-22 20:12:32 --> UTF-8 Support Enabled
INFO - 2017-12-22 20:12:32 --> Utf8 Class Initialized
INFO - 2017-12-22 20:12:32 --> URI Class Initialized
INFO - 2017-12-22 20:12:32 --> Router Class Initialized
INFO - 2017-12-22 20:12:32 --> Output Class Initialized
INFO - 2017-12-22 20:12:32 --> Security Class Initialized
DEBUG - 2017-12-22 20:12:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 20:12:32 --> Input Class Initialized
INFO - 2017-12-22 20:12:32 --> Language Class Initialized
INFO - 2017-12-22 20:12:32 --> Loader Class Initialized
INFO - 2017-12-22 20:12:32 --> Helper loaded: url_helper
INFO - 2017-12-22 20:12:32 --> Helper loaded: form_helper
INFO - 2017-12-22 20:12:32 --> Database Driver Class Initialized
DEBUG - 2017-12-22 20:12:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 20:12:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 20:12:32 --> Form Validation Class Initialized
INFO - 2017-12-22 20:12:32 --> Model Class Initialized
INFO - 2017-12-22 20:12:32 --> Controller Class Initialized
INFO - 2017-12-22 20:12:32 --> Model Class Initialized
INFO - 2017-12-22 20:12:32 --> Model Class Initialized
INFO - 2017-12-22 20:12:32 --> Model Class Initialized
DEBUG - 2017-12-22 20:12:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 20:12:32 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 20:12:32 --> Final output sent to browser
DEBUG - 2017-12-22 20:12:32 --> Total execution time: 0.0733
INFO - 2017-12-22 20:12:32 --> Config Class Initialized
INFO - 2017-12-22 20:12:32 --> Hooks Class Initialized
DEBUG - 2017-12-22 20:12:32 --> UTF-8 Support Enabled
INFO - 2017-12-22 20:12:32 --> Utf8 Class Initialized
INFO - 2017-12-22 20:12:32 --> URI Class Initialized
INFO - 2017-12-22 20:12:32 --> Router Class Initialized
INFO - 2017-12-22 20:12:32 --> Output Class Initialized
INFO - 2017-12-22 20:12:32 --> Security Class Initialized
DEBUG - 2017-12-22 20:12:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 20:12:32 --> Input Class Initialized
INFO - 2017-12-22 20:12:32 --> Language Class Initialized
INFO - 2017-12-22 20:12:32 --> Loader Class Initialized
INFO - 2017-12-22 20:12:32 --> Helper loaded: url_helper
INFO - 2017-12-22 20:12:32 --> Helper loaded: form_helper
INFO - 2017-12-22 20:12:32 --> Database Driver Class Initialized
DEBUG - 2017-12-22 20:12:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 20:12:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 20:12:32 --> Form Validation Class Initialized
INFO - 2017-12-22 20:12:32 --> Model Class Initialized
INFO - 2017-12-22 20:12:32 --> Controller Class Initialized
INFO - 2017-12-22 20:12:32 --> Model Class Initialized
INFO - 2017-12-22 20:12:32 --> Model Class Initialized
INFO - 2017-12-22 20:12:32 --> Model Class Initialized
DEBUG - 2017-12-22 20:12:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 20:12:37 --> Config Class Initialized
INFO - 2017-12-22 20:12:37 --> Hooks Class Initialized
DEBUG - 2017-12-22 20:12:37 --> UTF-8 Support Enabled
INFO - 2017-12-22 20:12:37 --> Utf8 Class Initialized
INFO - 2017-12-22 20:12:37 --> URI Class Initialized
INFO - 2017-12-22 20:12:37 --> Router Class Initialized
INFO - 2017-12-22 20:12:37 --> Output Class Initialized
INFO - 2017-12-22 20:12:37 --> Security Class Initialized
DEBUG - 2017-12-22 20:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 20:12:37 --> Input Class Initialized
INFO - 2017-12-22 20:12:37 --> Language Class Initialized
INFO - 2017-12-22 20:12:37 --> Loader Class Initialized
INFO - 2017-12-22 20:12:37 --> Helper loaded: url_helper
INFO - 2017-12-22 20:12:37 --> Helper loaded: form_helper
INFO - 2017-12-22 20:12:37 --> Database Driver Class Initialized
DEBUG - 2017-12-22 20:12:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 20:12:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 20:12:37 --> Form Validation Class Initialized
INFO - 2017-12-22 20:12:37 --> Model Class Initialized
INFO - 2017-12-22 20:12:37 --> Controller Class Initialized
INFO - 2017-12-22 20:12:37 --> Model Class Initialized
INFO - 2017-12-22 20:12:37 --> Model Class Initialized
INFO - 2017-12-22 20:12:37 --> Model Class Initialized
DEBUG - 2017-12-22 20:12:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 20:12:37 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 20:12:37 --> Final output sent to browser
DEBUG - 2017-12-22 20:12:37 --> Total execution time: 0.0701
INFO - 2017-12-22 20:12:37 --> Config Class Initialized
INFO - 2017-12-22 20:12:37 --> Hooks Class Initialized
DEBUG - 2017-12-22 20:12:37 --> UTF-8 Support Enabled
INFO - 2017-12-22 20:12:37 --> Utf8 Class Initialized
INFO - 2017-12-22 20:12:37 --> URI Class Initialized
INFO - 2017-12-22 20:12:37 --> Router Class Initialized
INFO - 2017-12-22 20:12:37 --> Output Class Initialized
INFO - 2017-12-22 20:12:37 --> Security Class Initialized
DEBUG - 2017-12-22 20:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 20:12:37 --> Input Class Initialized
INFO - 2017-12-22 20:12:37 --> Language Class Initialized
INFO - 2017-12-22 20:12:37 --> Loader Class Initialized
INFO - 2017-12-22 20:12:37 --> Helper loaded: url_helper
INFO - 2017-12-22 20:12:37 --> Helper loaded: form_helper
INFO - 2017-12-22 20:12:37 --> Database Driver Class Initialized
DEBUG - 2017-12-22 20:12:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 20:12:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 20:12:37 --> Form Validation Class Initialized
INFO - 2017-12-22 20:12:37 --> Model Class Initialized
INFO - 2017-12-22 20:12:37 --> Controller Class Initialized
INFO - 2017-12-22 20:12:37 --> Model Class Initialized
INFO - 2017-12-22 20:12:37 --> Model Class Initialized
INFO - 2017-12-22 20:12:37 --> Model Class Initialized
DEBUG - 2017-12-22 20:12:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 20:52:24 --> Config Class Initialized
INFO - 2017-12-22 20:52:24 --> Hooks Class Initialized
DEBUG - 2017-12-22 20:52:24 --> UTF-8 Support Enabled
INFO - 2017-12-22 20:52:24 --> Utf8 Class Initialized
INFO - 2017-12-22 20:52:24 --> URI Class Initialized
INFO - 2017-12-22 20:52:24 --> Router Class Initialized
INFO - 2017-12-22 20:52:24 --> Output Class Initialized
INFO - 2017-12-22 20:52:24 --> Security Class Initialized
DEBUG - 2017-12-22 20:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 20:52:24 --> Input Class Initialized
INFO - 2017-12-22 20:52:24 --> Language Class Initialized
INFO - 2017-12-22 20:52:24 --> Loader Class Initialized
INFO - 2017-12-22 20:52:24 --> Helper loaded: url_helper
INFO - 2017-12-22 20:52:24 --> Helper loaded: form_helper
INFO - 2017-12-22 20:52:24 --> Database Driver Class Initialized
DEBUG - 2017-12-22 20:52:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 20:52:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 20:52:24 --> Form Validation Class Initialized
INFO - 2017-12-22 20:52:24 --> Model Class Initialized
INFO - 2017-12-22 20:52:24 --> Controller Class Initialized
INFO - 2017-12-22 20:52:24 --> Model Class Initialized
INFO - 2017-12-22 20:52:24 --> Model Class Initialized
INFO - 2017-12-22 20:52:24 --> Model Class Initialized
DEBUG - 2017-12-22 20:52:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 20:52:24 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 20:52:24 --> Final output sent to browser
DEBUG - 2017-12-22 20:52:24 --> Total execution time: 0.0791
INFO - 2017-12-22 20:52:25 --> Config Class Initialized
INFO - 2017-12-22 20:52:25 --> Hooks Class Initialized
DEBUG - 2017-12-22 20:52:25 --> UTF-8 Support Enabled
INFO - 2017-12-22 20:52:25 --> Utf8 Class Initialized
INFO - 2017-12-22 20:52:25 --> URI Class Initialized
INFO - 2017-12-22 20:52:25 --> Router Class Initialized
INFO - 2017-12-22 20:52:25 --> Output Class Initialized
INFO - 2017-12-22 20:52:25 --> Security Class Initialized
DEBUG - 2017-12-22 20:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 20:52:25 --> Input Class Initialized
INFO - 2017-12-22 20:52:25 --> Language Class Initialized
INFO - 2017-12-22 20:52:25 --> Loader Class Initialized
INFO - 2017-12-22 20:52:25 --> Helper loaded: url_helper
INFO - 2017-12-22 20:52:25 --> Helper loaded: form_helper
INFO - 2017-12-22 20:52:25 --> Database Driver Class Initialized
DEBUG - 2017-12-22 20:52:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 20:52:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 20:52:25 --> Form Validation Class Initialized
INFO - 2017-12-22 20:52:25 --> Model Class Initialized
INFO - 2017-12-22 20:52:25 --> Controller Class Initialized
INFO - 2017-12-22 20:52:25 --> Model Class Initialized
INFO - 2017-12-22 20:52:25 --> Model Class Initialized
INFO - 2017-12-22 20:52:25 --> Model Class Initialized
DEBUG - 2017-12-22 20:52:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 20:52:38 --> Config Class Initialized
INFO - 2017-12-22 20:52:38 --> Hooks Class Initialized
DEBUG - 2017-12-22 20:52:38 --> UTF-8 Support Enabled
INFO - 2017-12-22 20:52:38 --> Utf8 Class Initialized
INFO - 2017-12-22 20:52:38 --> URI Class Initialized
INFO - 2017-12-22 20:52:38 --> Router Class Initialized
INFO - 2017-12-22 20:52:38 --> Output Class Initialized
INFO - 2017-12-22 20:52:38 --> Security Class Initialized
DEBUG - 2017-12-22 20:52:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 20:52:38 --> Input Class Initialized
INFO - 2017-12-22 20:52:38 --> Language Class Initialized
INFO - 2017-12-22 20:52:38 --> Loader Class Initialized
INFO - 2017-12-22 20:52:38 --> Helper loaded: url_helper
INFO - 2017-12-22 20:52:38 --> Helper loaded: form_helper
INFO - 2017-12-22 20:52:38 --> Database Driver Class Initialized
DEBUG - 2017-12-22 20:52:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 20:52:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 20:52:38 --> Form Validation Class Initialized
INFO - 2017-12-22 20:52:38 --> Model Class Initialized
INFO - 2017-12-22 20:52:38 --> Controller Class Initialized
INFO - 2017-12-22 20:52:38 --> Model Class Initialized
INFO - 2017-12-22 20:52:38 --> Model Class Initialized
INFO - 2017-12-22 20:52:38 --> Model Class Initialized
DEBUG - 2017-12-22 20:52:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 20:52:38 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 20:52:38 --> Final output sent to browser
DEBUG - 2017-12-22 20:52:38 --> Total execution time: 0.0595
INFO - 2017-12-22 20:52:38 --> Config Class Initialized
INFO - 2017-12-22 20:52:38 --> Hooks Class Initialized
DEBUG - 2017-12-22 20:52:38 --> UTF-8 Support Enabled
INFO - 2017-12-22 20:52:38 --> Utf8 Class Initialized
INFO - 2017-12-22 20:52:38 --> URI Class Initialized
INFO - 2017-12-22 20:52:38 --> Router Class Initialized
INFO - 2017-12-22 20:52:38 --> Output Class Initialized
INFO - 2017-12-22 20:52:38 --> Security Class Initialized
DEBUG - 2017-12-22 20:52:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 20:52:38 --> Input Class Initialized
INFO - 2017-12-22 20:52:38 --> Language Class Initialized
INFO - 2017-12-22 20:52:38 --> Loader Class Initialized
INFO - 2017-12-22 20:52:38 --> Helper loaded: url_helper
INFO - 2017-12-22 20:52:38 --> Helper loaded: form_helper
INFO - 2017-12-22 20:52:38 --> Database Driver Class Initialized
DEBUG - 2017-12-22 20:52:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 20:52:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 20:52:38 --> Form Validation Class Initialized
INFO - 2017-12-22 20:52:38 --> Model Class Initialized
INFO - 2017-12-22 20:52:38 --> Controller Class Initialized
INFO - 2017-12-22 20:52:38 --> Model Class Initialized
INFO - 2017-12-22 20:52:38 --> Model Class Initialized
INFO - 2017-12-22 20:52:38 --> Model Class Initialized
DEBUG - 2017-12-22 20:52:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 20:53:53 --> Config Class Initialized
INFO - 2017-12-22 20:53:53 --> Hooks Class Initialized
DEBUG - 2017-12-22 20:53:53 --> UTF-8 Support Enabled
INFO - 2017-12-22 20:53:53 --> Utf8 Class Initialized
INFO - 2017-12-22 20:53:53 --> URI Class Initialized
INFO - 2017-12-22 20:53:53 --> Router Class Initialized
INFO - 2017-12-22 20:53:53 --> Output Class Initialized
INFO - 2017-12-22 20:53:53 --> Security Class Initialized
DEBUG - 2017-12-22 20:53:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 20:53:53 --> Input Class Initialized
INFO - 2017-12-22 20:53:53 --> Language Class Initialized
INFO - 2017-12-22 20:53:53 --> Loader Class Initialized
INFO - 2017-12-22 20:53:53 --> Helper loaded: url_helper
INFO - 2017-12-22 20:53:53 --> Helper loaded: form_helper
INFO - 2017-12-22 20:53:53 --> Database Driver Class Initialized
DEBUG - 2017-12-22 20:53:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 20:53:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 20:53:53 --> Form Validation Class Initialized
INFO - 2017-12-22 20:53:53 --> Model Class Initialized
INFO - 2017-12-22 20:53:53 --> Controller Class Initialized
INFO - 2017-12-22 20:53:53 --> Model Class Initialized
INFO - 2017-12-22 20:53:53 --> Model Class Initialized
INFO - 2017-12-22 20:53:53 --> Model Class Initialized
DEBUG - 2017-12-22 20:53:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 20:53:53 --> Config Class Initialized
INFO - 2017-12-22 20:53:53 --> Hooks Class Initialized
DEBUG - 2017-12-22 20:53:53 --> UTF-8 Support Enabled
INFO - 2017-12-22 20:53:53 --> Utf8 Class Initialized
INFO - 2017-12-22 20:53:53 --> URI Class Initialized
INFO - 2017-12-22 20:53:53 --> Router Class Initialized
INFO - 2017-12-22 20:53:53 --> Output Class Initialized
INFO - 2017-12-22 20:53:53 --> Security Class Initialized
DEBUG - 2017-12-22 20:53:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 20:53:53 --> Input Class Initialized
INFO - 2017-12-22 20:53:53 --> Language Class Initialized
INFO - 2017-12-22 20:53:53 --> Loader Class Initialized
INFO - 2017-12-22 20:53:53 --> Helper loaded: url_helper
INFO - 2017-12-22 20:53:53 --> Helper loaded: form_helper
INFO - 2017-12-22 20:53:53 --> Database Driver Class Initialized
DEBUG - 2017-12-22 20:53:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 20:53:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 20:53:53 --> Form Validation Class Initialized
INFO - 2017-12-22 20:53:53 --> Model Class Initialized
INFO - 2017-12-22 20:53:53 --> Controller Class Initialized
INFO - 2017-12-22 20:53:53 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 20:53:53 --> Final output sent to browser
DEBUG - 2017-12-22 20:53:53 --> Total execution time: 0.0888
INFO - 2017-12-22 20:53:55 --> Config Class Initialized
INFO - 2017-12-22 20:53:55 --> Hooks Class Initialized
DEBUG - 2017-12-22 20:53:55 --> UTF-8 Support Enabled
INFO - 2017-12-22 20:53:55 --> Utf8 Class Initialized
INFO - 2017-12-22 20:53:55 --> URI Class Initialized
INFO - 2017-12-22 20:53:55 --> Router Class Initialized
INFO - 2017-12-22 20:53:55 --> Output Class Initialized
INFO - 2017-12-22 20:53:55 --> Security Class Initialized
DEBUG - 2017-12-22 20:53:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 20:53:55 --> Input Class Initialized
INFO - 2017-12-22 20:53:55 --> Language Class Initialized
INFO - 2017-12-22 20:53:55 --> Loader Class Initialized
INFO - 2017-12-22 20:53:55 --> Helper loaded: url_helper
INFO - 2017-12-22 20:53:55 --> Helper loaded: form_helper
INFO - 2017-12-22 20:53:55 --> Database Driver Class Initialized
DEBUG - 2017-12-22 20:53:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 20:53:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 20:53:55 --> Form Validation Class Initialized
INFO - 2017-12-22 20:53:55 --> Model Class Initialized
INFO - 2017-12-22 20:53:55 --> Controller Class Initialized
INFO - 2017-12-22 20:53:55 --> Model Class Initialized
INFO - 2017-12-22 20:53:55 --> Model Class Initialized
INFO - 2017-12-22 20:53:55 --> Model Class Initialized
DEBUG - 2017-12-22 20:53:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 20:53:55 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 20:53:55 --> Final output sent to browser
DEBUG - 2017-12-22 20:53:55 --> Total execution time: 0.0502
INFO - 2017-12-22 20:53:55 --> Config Class Initialized
INFO - 2017-12-22 20:53:55 --> Hooks Class Initialized
DEBUG - 2017-12-22 20:53:55 --> UTF-8 Support Enabled
INFO - 2017-12-22 20:53:55 --> Utf8 Class Initialized
INFO - 2017-12-22 20:53:55 --> URI Class Initialized
INFO - 2017-12-22 20:53:55 --> Router Class Initialized
INFO - 2017-12-22 20:53:55 --> Output Class Initialized
INFO - 2017-12-22 20:53:55 --> Security Class Initialized
DEBUG - 2017-12-22 20:53:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 20:53:55 --> Input Class Initialized
INFO - 2017-12-22 20:53:55 --> Language Class Initialized
INFO - 2017-12-22 20:53:55 --> Loader Class Initialized
INFO - 2017-12-22 20:53:55 --> Helper loaded: url_helper
INFO - 2017-12-22 20:53:55 --> Helper loaded: form_helper
INFO - 2017-12-22 20:53:55 --> Database Driver Class Initialized
DEBUG - 2017-12-22 20:53:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 20:53:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 20:53:55 --> Form Validation Class Initialized
INFO - 2017-12-22 20:53:55 --> Model Class Initialized
INFO - 2017-12-22 20:53:55 --> Controller Class Initialized
INFO - 2017-12-22 20:53:55 --> Model Class Initialized
INFO - 2017-12-22 20:53:55 --> Model Class Initialized
INFO - 2017-12-22 20:53:55 --> Model Class Initialized
DEBUG - 2017-12-22 20:53:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 20:58:33 --> Config Class Initialized
INFO - 2017-12-22 20:58:33 --> Hooks Class Initialized
DEBUG - 2017-12-22 20:58:33 --> UTF-8 Support Enabled
INFO - 2017-12-22 20:58:33 --> Utf8 Class Initialized
INFO - 2017-12-22 20:58:33 --> URI Class Initialized
INFO - 2017-12-22 20:58:33 --> Router Class Initialized
INFO - 2017-12-22 20:58:33 --> Output Class Initialized
INFO - 2017-12-22 20:58:33 --> Security Class Initialized
DEBUG - 2017-12-22 20:58:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 20:58:33 --> Input Class Initialized
INFO - 2017-12-22 20:58:33 --> Language Class Initialized
INFO - 2017-12-22 20:58:33 --> Loader Class Initialized
INFO - 2017-12-22 20:58:33 --> Helper loaded: url_helper
INFO - 2017-12-22 20:58:33 --> Helper loaded: form_helper
INFO - 2017-12-22 20:58:33 --> Database Driver Class Initialized
DEBUG - 2017-12-22 20:58:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 20:58:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 20:58:33 --> Form Validation Class Initialized
INFO - 2017-12-22 20:58:33 --> Model Class Initialized
INFO - 2017-12-22 20:58:33 --> Controller Class Initialized
INFO - 2017-12-22 20:58:33 --> Model Class Initialized
INFO - 2017-12-22 20:58:33 --> Model Class Initialized
INFO - 2017-12-22 20:58:33 --> Model Class Initialized
DEBUG - 2017-12-22 20:58:33 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2017-12-22 20:58:33 --> Severity: Error --> Call to undefined method M_Proyecto::consultaAllExtensiones() D:\xampp\htdocs\instateccr\instatec_app\controllers\Proyecto.php 163
INFO - 2017-12-22 20:58:35 --> Config Class Initialized
INFO - 2017-12-22 20:58:35 --> Hooks Class Initialized
DEBUG - 2017-12-22 20:58:35 --> UTF-8 Support Enabled
INFO - 2017-12-22 20:58:35 --> Utf8 Class Initialized
INFO - 2017-12-22 20:58:35 --> URI Class Initialized
INFO - 2017-12-22 20:58:35 --> Router Class Initialized
INFO - 2017-12-22 20:58:35 --> Output Class Initialized
INFO - 2017-12-22 20:58:35 --> Security Class Initialized
DEBUG - 2017-12-22 20:58:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 20:58:35 --> Input Class Initialized
INFO - 2017-12-22 20:58:35 --> Language Class Initialized
INFO - 2017-12-22 20:58:35 --> Loader Class Initialized
INFO - 2017-12-22 20:58:35 --> Helper loaded: url_helper
INFO - 2017-12-22 20:58:35 --> Helper loaded: form_helper
INFO - 2017-12-22 20:58:35 --> Database Driver Class Initialized
DEBUG - 2017-12-22 20:58:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 20:58:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 20:58:35 --> Form Validation Class Initialized
INFO - 2017-12-22 20:58:35 --> Model Class Initialized
INFO - 2017-12-22 20:58:35 --> Controller Class Initialized
INFO - 2017-12-22 20:58:35 --> Model Class Initialized
INFO - 2017-12-22 20:58:35 --> Model Class Initialized
INFO - 2017-12-22 20:58:35 --> Model Class Initialized
DEBUG - 2017-12-22 20:58:35 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2017-12-22 20:58:35 --> Severity: Error --> Call to undefined method M_Proyecto::consultaAllExtensiones() D:\xampp\htdocs\instateccr\instatec_app\controllers\Proyecto.php 163
INFO - 2017-12-22 22:06:19 --> Config Class Initialized
INFO - 2017-12-22 22:06:19 --> Hooks Class Initialized
DEBUG - 2017-12-22 22:06:19 --> UTF-8 Support Enabled
INFO - 2017-12-22 22:06:19 --> Utf8 Class Initialized
INFO - 2017-12-22 22:06:19 --> URI Class Initialized
INFO - 2017-12-22 22:06:19 --> Router Class Initialized
INFO - 2017-12-22 22:06:19 --> Output Class Initialized
INFO - 2017-12-22 22:06:19 --> Security Class Initialized
DEBUG - 2017-12-22 22:06:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 22:06:19 --> Input Class Initialized
INFO - 2017-12-22 22:06:19 --> Language Class Initialized
INFO - 2017-12-22 22:06:19 --> Loader Class Initialized
INFO - 2017-12-22 22:06:19 --> Helper loaded: url_helper
INFO - 2017-12-22 22:06:19 --> Helper loaded: form_helper
INFO - 2017-12-22 22:06:19 --> Database Driver Class Initialized
DEBUG - 2017-12-22 22:06:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 22:06:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 22:06:19 --> Form Validation Class Initialized
INFO - 2017-12-22 22:06:19 --> Model Class Initialized
INFO - 2017-12-22 22:06:19 --> Controller Class Initialized
INFO - 2017-12-22 22:06:19 --> Model Class Initialized
INFO - 2017-12-22 22:06:19 --> Model Class Initialized
INFO - 2017-12-22 22:06:19 --> Model Class Initialized
DEBUG - 2017-12-22 22:06:19 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2017-12-22 22:06:19 --> Query error: Unknown column 'proyecto_valor_oferta_tipo_id' in 'where clause' - Invalid query: SELECT *
FROM `proyecto`
LEFT JOIN `proyecto_valor_oferta_extension_detalle` ON `proyecto_valor_oferta_extension_detalle`.`proyecto_valor_oferta_id` = `proyecto_valor_oferta`.`proyecto_valor_oferta_id`
LEFT JOIN `proyecto_valor_oferta_extension_tipo` ON `proyecto_valor_oferta_extension_tipo`.`proyecto_valor_oferta_extension_tipo_id` = `proyecto_valor_oferta_extension_detalle`.`proyecto_valor_oferta_extension_tipo_id`
WHERE `proyecto_id` = '5'
AND `proyecto_valor_oferta_tipo_id` = 6
INFO - 2017-12-22 22:06:19 --> Language file loaded: language/english/db_lang.php
INFO - 2017-12-22 22:07:22 --> Config Class Initialized
INFO - 2017-12-22 22:07:22 --> Hooks Class Initialized
DEBUG - 2017-12-22 22:07:22 --> UTF-8 Support Enabled
INFO - 2017-12-22 22:07:22 --> Utf8 Class Initialized
INFO - 2017-12-22 22:07:22 --> URI Class Initialized
INFO - 2017-12-22 22:07:22 --> Router Class Initialized
INFO - 2017-12-22 22:07:22 --> Output Class Initialized
INFO - 2017-12-22 22:07:22 --> Security Class Initialized
DEBUG - 2017-12-22 22:07:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 22:07:22 --> Input Class Initialized
INFO - 2017-12-22 22:07:22 --> Language Class Initialized
INFO - 2017-12-22 22:07:22 --> Loader Class Initialized
INFO - 2017-12-22 22:07:22 --> Helper loaded: url_helper
INFO - 2017-12-22 22:07:22 --> Helper loaded: form_helper
INFO - 2017-12-22 22:07:22 --> Database Driver Class Initialized
DEBUG - 2017-12-22 22:07:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 22:07:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 22:07:22 --> Form Validation Class Initialized
INFO - 2017-12-22 22:07:22 --> Model Class Initialized
INFO - 2017-12-22 22:07:22 --> Controller Class Initialized
INFO - 2017-12-22 22:07:22 --> Model Class Initialized
INFO - 2017-12-22 22:07:22 --> Model Class Initialized
INFO - 2017-12-22 22:07:22 --> Model Class Initialized
DEBUG - 2017-12-22 22:07:22 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2017-12-22 22:07:22 --> Query error: Unknown column 'proyecto.proyecto_valor_oferta_tipo_id' in 'where clause' - Invalid query: SELECT *
FROM `proyecto`
LEFT JOIN `proyecto_valor_oferta_extension_detalle` ON `proyecto_valor_oferta_extension_detalle`.`proyecto_valor_oferta_id` = `proyecto_valor_oferta`.`proyecto_valor_oferta_id`
LEFT JOIN `proyecto_valor_oferta_extension_tipo` ON `proyecto_valor_oferta_extension_tipo`.`proyecto_valor_oferta_extension_tipo_id` = `proyecto_valor_oferta_extension_detalle`.`proyecto_valor_oferta_extension_tipo_id`
WHERE `proyecto`.`proyecto_id` = '5'
AND `proyecto`.`proyecto_valor_oferta_tipo_id` = 6
INFO - 2017-12-22 22:07:22 --> Language file loaded: language/english/db_lang.php
INFO - 2017-12-22 22:07:23 --> Config Class Initialized
INFO - 2017-12-22 22:07:23 --> Hooks Class Initialized
DEBUG - 2017-12-22 22:07:23 --> UTF-8 Support Enabled
INFO - 2017-12-22 22:07:23 --> Utf8 Class Initialized
INFO - 2017-12-22 22:07:23 --> URI Class Initialized
INFO - 2017-12-22 22:07:23 --> Router Class Initialized
INFO - 2017-12-22 22:07:23 --> Output Class Initialized
INFO - 2017-12-22 22:07:23 --> Security Class Initialized
DEBUG - 2017-12-22 22:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 22:07:23 --> Input Class Initialized
INFO - 2017-12-22 22:07:23 --> Language Class Initialized
INFO - 2017-12-22 22:07:23 --> Loader Class Initialized
INFO - 2017-12-22 22:07:23 --> Helper loaded: url_helper
INFO - 2017-12-22 22:07:23 --> Helper loaded: form_helper
INFO - 2017-12-22 22:07:23 --> Database Driver Class Initialized
DEBUG - 2017-12-22 22:07:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 22:07:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 22:07:23 --> Form Validation Class Initialized
INFO - 2017-12-22 22:07:23 --> Model Class Initialized
INFO - 2017-12-22 22:07:23 --> Controller Class Initialized
INFO - 2017-12-22 22:07:23 --> Model Class Initialized
INFO - 2017-12-22 22:07:23 --> Model Class Initialized
INFO - 2017-12-22 22:07:23 --> Model Class Initialized
DEBUG - 2017-12-22 22:07:23 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2017-12-22 22:07:23 --> Query error: Unknown column 'proyecto.proyecto_valor_oferta_tipo_id' in 'where clause' - Invalid query: SELECT *
FROM `proyecto`
LEFT JOIN `proyecto_valor_oferta_extension_detalle` ON `proyecto_valor_oferta_extension_detalle`.`proyecto_valor_oferta_id` = `proyecto_valor_oferta`.`proyecto_valor_oferta_id`
LEFT JOIN `proyecto_valor_oferta_extension_tipo` ON `proyecto_valor_oferta_extension_tipo`.`proyecto_valor_oferta_extension_tipo_id` = `proyecto_valor_oferta_extension_detalle`.`proyecto_valor_oferta_extension_tipo_id`
WHERE `proyecto`.`proyecto_id` = '5'
AND `proyecto`.`proyecto_valor_oferta_tipo_id` = 6
INFO - 2017-12-22 22:07:23 --> Language file loaded: language/english/db_lang.php
INFO - 2017-12-22 22:07:23 --> Config Class Initialized
INFO - 2017-12-22 22:07:23 --> Hooks Class Initialized
DEBUG - 2017-12-22 22:07:23 --> UTF-8 Support Enabled
INFO - 2017-12-22 22:07:23 --> Utf8 Class Initialized
INFO - 2017-12-22 22:07:23 --> URI Class Initialized
INFO - 2017-12-22 22:07:23 --> Router Class Initialized
INFO - 2017-12-22 22:07:23 --> Output Class Initialized
INFO - 2017-12-22 22:07:23 --> Security Class Initialized
DEBUG - 2017-12-22 22:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 22:07:23 --> Input Class Initialized
INFO - 2017-12-22 22:07:23 --> Language Class Initialized
INFO - 2017-12-22 22:07:23 --> Loader Class Initialized
INFO - 2017-12-22 22:07:23 --> Helper loaded: url_helper
INFO - 2017-12-22 22:07:23 --> Helper loaded: form_helper
INFO - 2017-12-22 22:07:23 --> Database Driver Class Initialized
DEBUG - 2017-12-22 22:07:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 22:07:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 22:07:23 --> Form Validation Class Initialized
INFO - 2017-12-22 22:07:23 --> Model Class Initialized
INFO - 2017-12-22 22:07:23 --> Controller Class Initialized
INFO - 2017-12-22 22:07:23 --> Model Class Initialized
INFO - 2017-12-22 22:07:23 --> Model Class Initialized
INFO - 2017-12-22 22:07:23 --> Model Class Initialized
DEBUG - 2017-12-22 22:07:23 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2017-12-22 22:07:23 --> Query error: Unknown column 'proyecto.proyecto_valor_oferta_tipo_id' in 'where clause' - Invalid query: SELECT *
FROM `proyecto`
LEFT JOIN `proyecto_valor_oferta_extension_detalle` ON `proyecto_valor_oferta_extension_detalle`.`proyecto_valor_oferta_id` = `proyecto_valor_oferta`.`proyecto_valor_oferta_id`
LEFT JOIN `proyecto_valor_oferta_extension_tipo` ON `proyecto_valor_oferta_extension_tipo`.`proyecto_valor_oferta_extension_tipo_id` = `proyecto_valor_oferta_extension_detalle`.`proyecto_valor_oferta_extension_tipo_id`
WHERE `proyecto`.`proyecto_id` = '5'
AND `proyecto`.`proyecto_valor_oferta_tipo_id` = 6
INFO - 2017-12-22 22:07:23 --> Language file loaded: language/english/db_lang.php
INFO - 2017-12-22 22:07:49 --> Config Class Initialized
INFO - 2017-12-22 22:07:49 --> Hooks Class Initialized
DEBUG - 2017-12-22 22:07:49 --> UTF-8 Support Enabled
INFO - 2017-12-22 22:07:49 --> Utf8 Class Initialized
INFO - 2017-12-22 22:07:49 --> URI Class Initialized
INFO - 2017-12-22 22:07:49 --> Router Class Initialized
INFO - 2017-12-22 22:07:49 --> Output Class Initialized
INFO - 2017-12-22 22:07:49 --> Security Class Initialized
DEBUG - 2017-12-22 22:07:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 22:07:49 --> Input Class Initialized
INFO - 2017-12-22 22:07:49 --> Language Class Initialized
INFO - 2017-12-22 22:07:49 --> Loader Class Initialized
INFO - 2017-12-22 22:07:49 --> Helper loaded: url_helper
INFO - 2017-12-22 22:07:49 --> Helper loaded: form_helper
INFO - 2017-12-22 22:07:49 --> Database Driver Class Initialized
DEBUG - 2017-12-22 22:07:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 22:07:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 22:07:49 --> Form Validation Class Initialized
INFO - 2017-12-22 22:07:49 --> Model Class Initialized
INFO - 2017-12-22 22:07:49 --> Controller Class Initialized
INFO - 2017-12-22 22:07:49 --> Model Class Initialized
INFO - 2017-12-22 22:07:49 --> Model Class Initialized
INFO - 2017-12-22 22:07:49 --> Model Class Initialized
DEBUG - 2017-12-22 22:07:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 22:07:50 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 22:07:50 --> Final output sent to browser
DEBUG - 2017-12-22 22:07:50 --> Total execution time: 0.0503
INFO - 2017-12-22 22:33:45 --> Config Class Initialized
INFO - 2017-12-22 22:33:45 --> Hooks Class Initialized
DEBUG - 2017-12-22 22:33:45 --> UTF-8 Support Enabled
INFO - 2017-12-22 22:33:45 --> Utf8 Class Initialized
INFO - 2017-12-22 22:33:45 --> URI Class Initialized
INFO - 2017-12-22 22:33:45 --> Router Class Initialized
INFO - 2017-12-22 22:33:46 --> Output Class Initialized
INFO - 2017-12-22 22:33:46 --> Security Class Initialized
DEBUG - 2017-12-22 22:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 22:33:46 --> Input Class Initialized
INFO - 2017-12-22 22:33:46 --> Language Class Initialized
INFO - 2017-12-22 22:33:46 --> Loader Class Initialized
INFO - 2017-12-22 22:33:46 --> Helper loaded: url_helper
INFO - 2017-12-22 22:33:46 --> Helper loaded: form_helper
INFO - 2017-12-22 22:33:46 --> Database Driver Class Initialized
DEBUG - 2017-12-22 22:33:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 22:33:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 22:33:46 --> Form Validation Class Initialized
INFO - 2017-12-22 22:33:46 --> Model Class Initialized
INFO - 2017-12-22 22:33:46 --> Controller Class Initialized
INFO - 2017-12-22 22:33:46 --> Model Class Initialized
INFO - 2017-12-22 22:33:46 --> Model Class Initialized
INFO - 2017-12-22 22:33:46 --> Model Class Initialized
DEBUG - 2017-12-22 22:33:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 22:33:46 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 22:33:46 --> Final output sent to browser
DEBUG - 2017-12-22 22:33:46 --> Total execution time: 0.0640
INFO - 2017-12-22 22:33:46 --> Config Class Initialized
INFO - 2017-12-22 22:33:46 --> Hooks Class Initialized
DEBUG - 2017-12-22 22:33:46 --> UTF-8 Support Enabled
INFO - 2017-12-22 22:33:46 --> Utf8 Class Initialized
INFO - 2017-12-22 22:33:46 --> URI Class Initialized
INFO - 2017-12-22 22:33:46 --> Router Class Initialized
INFO - 2017-12-22 22:33:46 --> Output Class Initialized
INFO - 2017-12-22 22:33:46 --> Security Class Initialized
DEBUG - 2017-12-22 22:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 22:33:46 --> Input Class Initialized
INFO - 2017-12-22 22:33:46 --> Language Class Initialized
INFO - 2017-12-22 22:33:46 --> Loader Class Initialized
INFO - 2017-12-22 22:33:46 --> Helper loaded: url_helper
INFO - 2017-12-22 22:33:46 --> Helper loaded: form_helper
INFO - 2017-12-22 22:33:46 --> Database Driver Class Initialized
DEBUG - 2017-12-22 22:33:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 22:33:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 22:33:46 --> Form Validation Class Initialized
INFO - 2017-12-22 22:33:46 --> Model Class Initialized
INFO - 2017-12-22 22:33:46 --> Controller Class Initialized
INFO - 2017-12-22 22:33:46 --> Model Class Initialized
INFO - 2017-12-22 22:33:46 --> Model Class Initialized
INFO - 2017-12-22 22:33:46 --> Model Class Initialized
DEBUG - 2017-12-22 22:33:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 22:33:48 --> Config Class Initialized
INFO - 2017-12-22 22:33:48 --> Hooks Class Initialized
DEBUG - 2017-12-22 22:33:48 --> UTF-8 Support Enabled
INFO - 2017-12-22 22:33:48 --> Utf8 Class Initialized
INFO - 2017-12-22 22:33:48 --> URI Class Initialized
INFO - 2017-12-22 22:33:48 --> Router Class Initialized
INFO - 2017-12-22 22:33:48 --> Output Class Initialized
INFO - 2017-12-22 22:33:48 --> Security Class Initialized
DEBUG - 2017-12-22 22:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 22:33:48 --> Input Class Initialized
INFO - 2017-12-22 22:33:48 --> Language Class Initialized
INFO - 2017-12-22 22:33:48 --> Loader Class Initialized
INFO - 2017-12-22 22:33:48 --> Helper loaded: url_helper
INFO - 2017-12-22 22:33:48 --> Helper loaded: form_helper
INFO - 2017-12-22 22:33:48 --> Database Driver Class Initialized
DEBUG - 2017-12-22 22:33:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 22:33:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 22:33:48 --> Form Validation Class Initialized
INFO - 2017-12-22 22:33:48 --> Model Class Initialized
INFO - 2017-12-22 22:33:48 --> Controller Class Initialized
INFO - 2017-12-22 22:33:48 --> Model Class Initialized
INFO - 2017-12-22 22:33:48 --> Model Class Initialized
INFO - 2017-12-22 22:33:48 --> Model Class Initialized
DEBUG - 2017-12-22 22:33:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 22:33:48 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 22:33:48 --> Final output sent to browser
DEBUG - 2017-12-22 22:33:48 --> Total execution time: 0.0681
INFO - 2017-12-22 23:02:14 --> Config Class Initialized
INFO - 2017-12-22 23:02:14 --> Hooks Class Initialized
DEBUG - 2017-12-22 23:02:14 --> UTF-8 Support Enabled
INFO - 2017-12-22 23:02:14 --> Utf8 Class Initialized
INFO - 2017-12-22 23:02:14 --> URI Class Initialized
INFO - 2017-12-22 23:02:14 --> Router Class Initialized
INFO - 2017-12-22 23:02:14 --> Output Class Initialized
INFO - 2017-12-22 23:02:14 --> Security Class Initialized
DEBUG - 2017-12-22 23:02:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 23:02:14 --> Input Class Initialized
INFO - 2017-12-22 23:02:14 --> Language Class Initialized
INFO - 2017-12-22 23:02:14 --> Loader Class Initialized
INFO - 2017-12-22 23:02:14 --> Helper loaded: url_helper
INFO - 2017-12-22 23:02:14 --> Helper loaded: form_helper
INFO - 2017-12-22 23:02:14 --> Database Driver Class Initialized
DEBUG - 2017-12-22 23:02:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 23:02:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 23:02:14 --> Form Validation Class Initialized
INFO - 2017-12-22 23:02:14 --> Model Class Initialized
INFO - 2017-12-22 23:02:14 --> Controller Class Initialized
INFO - 2017-12-22 23:02:14 --> Model Class Initialized
INFO - 2017-12-22 23:02:14 --> Model Class Initialized
INFO - 2017-12-22 23:02:14 --> Model Class Initialized
DEBUG - 2017-12-22 23:02:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 23:02:14 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 23:02:14 --> Final output sent to browser
DEBUG - 2017-12-22 23:02:14 --> Total execution time: 0.0650
INFO - 2017-12-22 23:02:15 --> Config Class Initialized
INFO - 2017-12-22 23:02:15 --> Hooks Class Initialized
DEBUG - 2017-12-22 23:02:15 --> UTF-8 Support Enabled
INFO - 2017-12-22 23:02:15 --> Utf8 Class Initialized
INFO - 2017-12-22 23:02:15 --> URI Class Initialized
INFO - 2017-12-22 23:02:15 --> Router Class Initialized
INFO - 2017-12-22 23:02:15 --> Output Class Initialized
INFO - 2017-12-22 23:02:15 --> Security Class Initialized
DEBUG - 2017-12-22 23:02:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 23:02:15 --> Input Class Initialized
INFO - 2017-12-22 23:02:15 --> Language Class Initialized
ERROR - 2017-12-22 23:02:15 --> 404 Page Not Found: Proyectos/extensiones
INFO - 2017-12-22 23:02:18 --> Config Class Initialized
INFO - 2017-12-22 23:02:18 --> Hooks Class Initialized
DEBUG - 2017-12-22 23:02:18 --> UTF-8 Support Enabled
INFO - 2017-12-22 23:02:18 --> Utf8 Class Initialized
INFO - 2017-12-22 23:02:18 --> URI Class Initialized
INFO - 2017-12-22 23:02:18 --> Router Class Initialized
INFO - 2017-12-22 23:02:18 --> Output Class Initialized
INFO - 2017-12-22 23:02:18 --> Security Class Initialized
DEBUG - 2017-12-22 23:02:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 23:02:18 --> Input Class Initialized
INFO - 2017-12-22 23:02:18 --> Language Class Initialized
ERROR - 2017-12-22 23:02:18 --> 404 Page Not Found: Proyectos/extensiones
INFO - 2017-12-22 23:02:56 --> Config Class Initialized
INFO - 2017-12-22 23:02:56 --> Hooks Class Initialized
DEBUG - 2017-12-22 23:02:56 --> UTF-8 Support Enabled
INFO - 2017-12-22 23:02:56 --> Utf8 Class Initialized
INFO - 2017-12-22 23:02:56 --> URI Class Initialized
INFO - 2017-12-22 23:02:56 --> Router Class Initialized
INFO - 2017-12-22 23:02:56 --> Output Class Initialized
INFO - 2017-12-22 23:02:56 --> Security Class Initialized
DEBUG - 2017-12-22 23:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 23:02:56 --> Input Class Initialized
INFO - 2017-12-22 23:02:56 --> Language Class Initialized
INFO - 2017-12-22 23:02:56 --> Loader Class Initialized
INFO - 2017-12-22 23:02:56 --> Helper loaded: url_helper
INFO - 2017-12-22 23:02:56 --> Helper loaded: form_helper
INFO - 2017-12-22 23:02:56 --> Database Driver Class Initialized
DEBUG - 2017-12-22 23:02:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 23:02:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 23:02:56 --> Form Validation Class Initialized
INFO - 2017-12-22 23:02:56 --> Model Class Initialized
INFO - 2017-12-22 23:02:56 --> Controller Class Initialized
INFO - 2017-12-22 23:02:56 --> Model Class Initialized
INFO - 2017-12-22 23:02:56 --> Model Class Initialized
INFO - 2017-12-22 23:02:56 --> Model Class Initialized
DEBUG - 2017-12-22 23:02:56 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2017-12-22 23:02:56 --> Severity: Notice --> Undefined variable: proyecto D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\agregarExtensionProyecto.php 11
ERROR - 2017-12-22 23:02:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\agregarExtensionProyecto.php 11
ERROR - 2017-12-22 23:02:56 --> Severity: Notice --> Undefined variable: proyecto D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\agregarExtensionProyecto.php 21
ERROR - 2017-12-22 23:02:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\agregarExtensionProyecto.php 21
INFO - 2017-12-22 23:02:56 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 23:02:56 --> Final output sent to browser
DEBUG - 2017-12-22 23:02:56 --> Total execution time: 0.0664
INFO - 2017-12-22 23:02:57 --> Config Class Initialized
INFO - 2017-12-22 23:02:57 --> Hooks Class Initialized
DEBUG - 2017-12-22 23:02:57 --> UTF-8 Support Enabled
INFO - 2017-12-22 23:02:57 --> Utf8 Class Initialized
INFO - 2017-12-22 23:02:57 --> URI Class Initialized
INFO - 2017-12-22 23:02:57 --> Router Class Initialized
INFO - 2017-12-22 23:02:57 --> Output Class Initialized
INFO - 2017-12-22 23:02:57 --> Security Class Initialized
DEBUG - 2017-12-22 23:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 23:02:57 --> Input Class Initialized
INFO - 2017-12-22 23:02:57 --> Language Class Initialized
INFO - 2017-12-22 23:02:57 --> Loader Class Initialized
INFO - 2017-12-22 23:02:57 --> Helper loaded: url_helper
INFO - 2017-12-22 23:02:57 --> Helper loaded: form_helper
INFO - 2017-12-22 23:02:57 --> Database Driver Class Initialized
DEBUG - 2017-12-22 23:02:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 23:02:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 23:02:57 --> Form Validation Class Initialized
INFO - 2017-12-22 23:02:57 --> Model Class Initialized
INFO - 2017-12-22 23:02:57 --> Controller Class Initialized
INFO - 2017-12-22 23:02:57 --> Model Class Initialized
INFO - 2017-12-22 23:02:57 --> Model Class Initialized
INFO - 2017-12-22 23:02:57 --> Model Class Initialized
DEBUG - 2017-12-22 23:02:57 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2017-12-22 23:02:57 --> Severity: Notice --> Undefined variable: proyecto D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\agregarExtensionProyecto.php 11
ERROR - 2017-12-22 23:02:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\agregarExtensionProyecto.php 11
ERROR - 2017-12-22 23:02:57 --> Severity: Notice --> Undefined variable: proyecto D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\agregarExtensionProyecto.php 21
ERROR - 2017-12-22 23:02:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\agregarExtensionProyecto.php 21
INFO - 2017-12-22 23:02:57 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 23:02:57 --> Final output sent to browser
DEBUG - 2017-12-22 23:02:57 --> Total execution time: 0.0748
INFO - 2017-12-22 23:03:50 --> Config Class Initialized
INFO - 2017-12-22 23:03:50 --> Hooks Class Initialized
DEBUG - 2017-12-22 23:03:50 --> UTF-8 Support Enabled
INFO - 2017-12-22 23:03:50 --> Utf8 Class Initialized
INFO - 2017-12-22 23:03:50 --> URI Class Initialized
INFO - 2017-12-22 23:03:50 --> Router Class Initialized
INFO - 2017-12-22 23:03:50 --> Output Class Initialized
INFO - 2017-12-22 23:03:50 --> Security Class Initialized
DEBUG - 2017-12-22 23:03:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 23:03:50 --> Input Class Initialized
INFO - 2017-12-22 23:03:50 --> Language Class Initialized
INFO - 2017-12-22 23:03:50 --> Loader Class Initialized
INFO - 2017-12-22 23:03:50 --> Helper loaded: url_helper
INFO - 2017-12-22 23:03:50 --> Helper loaded: form_helper
INFO - 2017-12-22 23:03:50 --> Database Driver Class Initialized
DEBUG - 2017-12-22 23:03:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 23:03:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 23:03:50 --> Form Validation Class Initialized
INFO - 2017-12-22 23:03:50 --> Model Class Initialized
INFO - 2017-12-22 23:03:50 --> Controller Class Initialized
INFO - 2017-12-22 23:03:50 --> Model Class Initialized
INFO - 2017-12-22 23:03:50 --> Model Class Initialized
INFO - 2017-12-22 23:03:50 --> Model Class Initialized
DEBUG - 2017-12-22 23:03:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 23:03:50 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 23:03:50 --> Final output sent to browser
DEBUG - 2017-12-22 23:03:50 --> Total execution time: 0.0595
INFO - 2017-12-22 23:03:52 --> Config Class Initialized
INFO - 2017-12-22 23:03:52 --> Hooks Class Initialized
DEBUG - 2017-12-22 23:03:52 --> UTF-8 Support Enabled
INFO - 2017-12-22 23:03:52 --> Utf8 Class Initialized
INFO - 2017-12-22 23:03:52 --> URI Class Initialized
INFO - 2017-12-22 23:03:52 --> Router Class Initialized
INFO - 2017-12-22 23:03:52 --> Output Class Initialized
INFO - 2017-12-22 23:03:52 --> Security Class Initialized
DEBUG - 2017-12-22 23:03:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 23:03:52 --> Input Class Initialized
INFO - 2017-12-22 23:03:52 --> Language Class Initialized
INFO - 2017-12-22 23:03:52 --> Loader Class Initialized
INFO - 2017-12-22 23:03:52 --> Helper loaded: url_helper
INFO - 2017-12-22 23:03:52 --> Helper loaded: form_helper
INFO - 2017-12-22 23:03:52 --> Database Driver Class Initialized
DEBUG - 2017-12-22 23:03:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 23:03:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 23:03:52 --> Form Validation Class Initialized
INFO - 2017-12-22 23:03:52 --> Model Class Initialized
INFO - 2017-12-22 23:03:52 --> Controller Class Initialized
INFO - 2017-12-22 23:03:52 --> Model Class Initialized
INFO - 2017-12-22 23:03:52 --> Model Class Initialized
INFO - 2017-12-22 23:03:52 --> Model Class Initialized
DEBUG - 2017-12-22 23:03:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 23:03:52 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 23:03:52 --> Final output sent to browser
DEBUG - 2017-12-22 23:03:52 --> Total execution time: 0.0548
INFO - 2017-12-22 23:03:53 --> Config Class Initialized
INFO - 2017-12-22 23:03:53 --> Hooks Class Initialized
DEBUG - 2017-12-22 23:03:53 --> UTF-8 Support Enabled
INFO - 2017-12-22 23:03:53 --> Utf8 Class Initialized
INFO - 2017-12-22 23:03:53 --> URI Class Initialized
INFO - 2017-12-22 23:03:53 --> Router Class Initialized
INFO - 2017-12-22 23:03:53 --> Output Class Initialized
INFO - 2017-12-22 23:03:53 --> Security Class Initialized
DEBUG - 2017-12-22 23:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 23:03:53 --> Input Class Initialized
INFO - 2017-12-22 23:03:53 --> Language Class Initialized
INFO - 2017-12-22 23:03:53 --> Loader Class Initialized
INFO - 2017-12-22 23:03:53 --> Helper loaded: url_helper
INFO - 2017-12-22 23:03:53 --> Helper loaded: form_helper
INFO - 2017-12-22 23:03:53 --> Database Driver Class Initialized
DEBUG - 2017-12-22 23:03:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 23:03:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 23:03:53 --> Form Validation Class Initialized
INFO - 2017-12-22 23:03:53 --> Model Class Initialized
INFO - 2017-12-22 23:03:53 --> Controller Class Initialized
INFO - 2017-12-22 23:03:53 --> Model Class Initialized
INFO - 2017-12-22 23:03:53 --> Model Class Initialized
INFO - 2017-12-22 23:03:53 --> Model Class Initialized
DEBUG - 2017-12-22 23:03:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 23:03:53 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 23:03:53 --> Final output sent to browser
DEBUG - 2017-12-22 23:03:53 --> Total execution time: 0.0535
INFO - 2017-12-22 23:05:22 --> Config Class Initialized
INFO - 2017-12-22 23:05:22 --> Hooks Class Initialized
DEBUG - 2017-12-22 23:05:22 --> UTF-8 Support Enabled
INFO - 2017-12-22 23:05:22 --> Utf8 Class Initialized
INFO - 2017-12-22 23:05:22 --> URI Class Initialized
INFO - 2017-12-22 23:05:22 --> Router Class Initialized
INFO - 2017-12-22 23:05:22 --> Output Class Initialized
INFO - 2017-12-22 23:05:22 --> Security Class Initialized
DEBUG - 2017-12-22 23:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 23:05:22 --> Input Class Initialized
INFO - 2017-12-22 23:05:22 --> Language Class Initialized
INFO - 2017-12-22 23:05:22 --> Loader Class Initialized
INFO - 2017-12-22 23:05:23 --> Helper loaded: url_helper
INFO - 2017-12-22 23:05:23 --> Helper loaded: form_helper
INFO - 2017-12-22 23:05:23 --> Database Driver Class Initialized
DEBUG - 2017-12-22 23:05:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 23:05:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 23:05:23 --> Form Validation Class Initialized
INFO - 2017-12-22 23:05:23 --> Model Class Initialized
INFO - 2017-12-22 23:05:23 --> Controller Class Initialized
INFO - 2017-12-22 23:05:23 --> Model Class Initialized
INFO - 2017-12-22 23:05:23 --> Model Class Initialized
INFO - 2017-12-22 23:05:23 --> Model Class Initialized
DEBUG - 2017-12-22 23:05:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 23:05:23 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 23:05:23 --> Final output sent to browser
DEBUG - 2017-12-22 23:05:23 --> Total execution time: 0.0605
INFO - 2017-12-22 23:05:23 --> Config Class Initialized
INFO - 2017-12-22 23:05:23 --> Hooks Class Initialized
DEBUG - 2017-12-22 23:05:23 --> UTF-8 Support Enabled
INFO - 2017-12-22 23:05:23 --> Utf8 Class Initialized
INFO - 2017-12-22 23:05:23 --> URI Class Initialized
INFO - 2017-12-22 23:05:23 --> Router Class Initialized
INFO - 2017-12-22 23:05:23 --> Output Class Initialized
INFO - 2017-12-22 23:05:23 --> Security Class Initialized
DEBUG - 2017-12-22 23:05:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 23:05:23 --> Input Class Initialized
INFO - 2017-12-22 23:05:23 --> Language Class Initialized
INFO - 2017-12-22 23:05:23 --> Loader Class Initialized
INFO - 2017-12-22 23:05:23 --> Helper loaded: url_helper
INFO - 2017-12-22 23:05:23 --> Helper loaded: form_helper
INFO - 2017-12-22 23:05:23 --> Database Driver Class Initialized
DEBUG - 2017-12-22 23:05:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 23:05:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 23:05:23 --> Form Validation Class Initialized
INFO - 2017-12-22 23:05:23 --> Model Class Initialized
INFO - 2017-12-22 23:05:23 --> Controller Class Initialized
INFO - 2017-12-22 23:05:23 --> Model Class Initialized
INFO - 2017-12-22 23:05:23 --> Model Class Initialized
INFO - 2017-12-22 23:05:23 --> Model Class Initialized
DEBUG - 2017-12-22 23:05:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 23:05:23 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 23:05:23 --> Final output sent to browser
DEBUG - 2017-12-22 23:05:23 --> Total execution time: 0.0879
INFO - 2017-12-22 23:07:09 --> Config Class Initialized
INFO - 2017-12-22 23:07:09 --> Hooks Class Initialized
DEBUG - 2017-12-22 23:07:09 --> UTF-8 Support Enabled
INFO - 2017-12-22 23:07:09 --> Utf8 Class Initialized
INFO - 2017-12-22 23:07:09 --> URI Class Initialized
INFO - 2017-12-22 23:07:09 --> Router Class Initialized
INFO - 2017-12-22 23:07:09 --> Output Class Initialized
INFO - 2017-12-22 23:07:09 --> Security Class Initialized
DEBUG - 2017-12-22 23:07:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 23:07:09 --> Input Class Initialized
INFO - 2017-12-22 23:07:09 --> Language Class Initialized
INFO - 2017-12-22 23:07:09 --> Loader Class Initialized
INFO - 2017-12-22 23:07:09 --> Helper loaded: url_helper
INFO - 2017-12-22 23:07:09 --> Helper loaded: form_helper
INFO - 2017-12-22 23:07:09 --> Database Driver Class Initialized
DEBUG - 2017-12-22 23:07:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 23:07:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 23:07:09 --> Form Validation Class Initialized
INFO - 2017-12-22 23:07:09 --> Model Class Initialized
INFO - 2017-12-22 23:07:09 --> Controller Class Initialized
INFO - 2017-12-22 23:07:09 --> Model Class Initialized
INFO - 2017-12-22 23:07:09 --> Model Class Initialized
INFO - 2017-12-22 23:07:09 --> Model Class Initialized
DEBUG - 2017-12-22 23:07:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 23:07:09 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 23:07:09 --> Final output sent to browser
DEBUG - 2017-12-22 23:07:09 --> Total execution time: 0.0603
INFO - 2017-12-22 23:07:26 --> Config Class Initialized
INFO - 2017-12-22 23:07:26 --> Hooks Class Initialized
DEBUG - 2017-12-22 23:07:26 --> UTF-8 Support Enabled
INFO - 2017-12-22 23:07:26 --> Utf8 Class Initialized
INFO - 2017-12-22 23:07:26 --> URI Class Initialized
INFO - 2017-12-22 23:07:26 --> Router Class Initialized
INFO - 2017-12-22 23:07:26 --> Output Class Initialized
INFO - 2017-12-22 23:07:26 --> Security Class Initialized
DEBUG - 2017-12-22 23:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 23:07:26 --> Input Class Initialized
INFO - 2017-12-22 23:07:26 --> Language Class Initialized
INFO - 2017-12-22 23:07:26 --> Loader Class Initialized
INFO - 2017-12-22 23:07:26 --> Helper loaded: url_helper
INFO - 2017-12-22 23:07:26 --> Helper loaded: form_helper
INFO - 2017-12-22 23:07:26 --> Database Driver Class Initialized
DEBUG - 2017-12-22 23:07:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 23:07:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 23:07:26 --> Form Validation Class Initialized
INFO - 2017-12-22 23:07:26 --> Model Class Initialized
INFO - 2017-12-22 23:07:26 --> Controller Class Initialized
INFO - 2017-12-22 23:07:26 --> Model Class Initialized
INFO - 2017-12-22 23:07:26 --> Model Class Initialized
INFO - 2017-12-22 23:07:26 --> Model Class Initialized
DEBUG - 2017-12-22 23:07:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 23:07:26 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 23:07:26 --> Final output sent to browser
DEBUG - 2017-12-22 23:07:26 --> Total execution time: 0.0523
INFO - 2017-12-22 23:07:28 --> Config Class Initialized
INFO - 2017-12-22 23:07:28 --> Hooks Class Initialized
DEBUG - 2017-12-22 23:07:28 --> UTF-8 Support Enabled
INFO - 2017-12-22 23:07:28 --> Utf8 Class Initialized
INFO - 2017-12-22 23:07:28 --> URI Class Initialized
INFO - 2017-12-22 23:07:28 --> Router Class Initialized
INFO - 2017-12-22 23:07:28 --> Output Class Initialized
INFO - 2017-12-22 23:07:28 --> Security Class Initialized
DEBUG - 2017-12-22 23:07:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 23:07:28 --> Input Class Initialized
INFO - 2017-12-22 23:07:28 --> Language Class Initialized
INFO - 2017-12-22 23:07:28 --> Loader Class Initialized
INFO - 2017-12-22 23:07:28 --> Helper loaded: url_helper
INFO - 2017-12-22 23:07:28 --> Helper loaded: form_helper
INFO - 2017-12-22 23:07:28 --> Database Driver Class Initialized
DEBUG - 2017-12-22 23:07:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 23:07:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 23:07:28 --> Form Validation Class Initialized
INFO - 2017-12-22 23:07:28 --> Model Class Initialized
INFO - 2017-12-22 23:07:28 --> Controller Class Initialized
INFO - 2017-12-22 23:07:28 --> Model Class Initialized
INFO - 2017-12-22 23:07:28 --> Model Class Initialized
INFO - 2017-12-22 23:07:28 --> Model Class Initialized
DEBUG - 2017-12-22 23:07:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 23:07:28 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 23:07:28 --> Final output sent to browser
DEBUG - 2017-12-22 23:07:28 --> Total execution time: 0.0639
INFO - 2017-12-22 23:07:30 --> Config Class Initialized
INFO - 2017-12-22 23:07:30 --> Hooks Class Initialized
DEBUG - 2017-12-22 23:07:30 --> UTF-8 Support Enabled
INFO - 2017-12-22 23:07:30 --> Utf8 Class Initialized
INFO - 2017-12-22 23:07:30 --> URI Class Initialized
INFO - 2017-12-22 23:07:30 --> Router Class Initialized
INFO - 2017-12-22 23:07:30 --> Output Class Initialized
INFO - 2017-12-22 23:07:30 --> Security Class Initialized
DEBUG - 2017-12-22 23:07:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 23:07:30 --> Input Class Initialized
INFO - 2017-12-22 23:07:30 --> Language Class Initialized
INFO - 2017-12-22 23:07:30 --> Loader Class Initialized
INFO - 2017-12-22 23:07:30 --> Helper loaded: url_helper
INFO - 2017-12-22 23:07:30 --> Helper loaded: form_helper
INFO - 2017-12-22 23:07:30 --> Database Driver Class Initialized
DEBUG - 2017-12-22 23:07:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 23:07:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 23:07:30 --> Form Validation Class Initialized
INFO - 2017-12-22 23:07:30 --> Model Class Initialized
INFO - 2017-12-22 23:07:30 --> Controller Class Initialized
INFO - 2017-12-22 23:07:30 --> Model Class Initialized
INFO - 2017-12-22 23:07:30 --> Model Class Initialized
INFO - 2017-12-22 23:07:30 --> Model Class Initialized
DEBUG - 2017-12-22 23:07:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 23:07:30 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 23:07:30 --> Final output sent to browser
DEBUG - 2017-12-22 23:07:30 --> Total execution time: 0.0559
INFO - 2017-12-22 23:07:32 --> Config Class Initialized
INFO - 2017-12-22 23:07:32 --> Hooks Class Initialized
DEBUG - 2017-12-22 23:07:32 --> UTF-8 Support Enabled
INFO - 2017-12-22 23:07:32 --> Utf8 Class Initialized
INFO - 2017-12-22 23:07:32 --> URI Class Initialized
INFO - 2017-12-22 23:07:32 --> Router Class Initialized
INFO - 2017-12-22 23:07:32 --> Output Class Initialized
INFO - 2017-12-22 23:07:32 --> Security Class Initialized
DEBUG - 2017-12-22 23:07:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 23:07:32 --> Input Class Initialized
INFO - 2017-12-22 23:07:32 --> Language Class Initialized
INFO - 2017-12-22 23:07:32 --> Loader Class Initialized
INFO - 2017-12-22 23:07:32 --> Helper loaded: url_helper
INFO - 2017-12-22 23:07:32 --> Helper loaded: form_helper
INFO - 2017-12-22 23:07:32 --> Database Driver Class Initialized
DEBUG - 2017-12-22 23:07:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 23:07:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 23:07:32 --> Form Validation Class Initialized
INFO - 2017-12-22 23:07:32 --> Model Class Initialized
INFO - 2017-12-22 23:07:32 --> Controller Class Initialized
INFO - 2017-12-22 23:07:32 --> Model Class Initialized
INFO - 2017-12-22 23:07:32 --> Model Class Initialized
INFO - 2017-12-22 23:07:32 --> Model Class Initialized
DEBUG - 2017-12-22 23:07:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 23:07:32 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 23:07:32 --> Final output sent to browser
DEBUG - 2017-12-22 23:07:32 --> Total execution time: 0.0612
INFO - 2017-12-22 23:07:35 --> Config Class Initialized
INFO - 2017-12-22 23:07:35 --> Hooks Class Initialized
DEBUG - 2017-12-22 23:07:35 --> UTF-8 Support Enabled
INFO - 2017-12-22 23:07:35 --> Utf8 Class Initialized
INFO - 2017-12-22 23:07:35 --> URI Class Initialized
INFO - 2017-12-22 23:07:35 --> Router Class Initialized
INFO - 2017-12-22 23:07:35 --> Output Class Initialized
INFO - 2017-12-22 23:07:35 --> Security Class Initialized
DEBUG - 2017-12-22 23:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 23:07:35 --> Input Class Initialized
INFO - 2017-12-22 23:07:35 --> Language Class Initialized
INFO - 2017-12-22 23:07:35 --> Loader Class Initialized
INFO - 2017-12-22 23:07:35 --> Helper loaded: url_helper
INFO - 2017-12-22 23:07:35 --> Helper loaded: form_helper
INFO - 2017-12-22 23:07:35 --> Database Driver Class Initialized
DEBUG - 2017-12-22 23:07:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 23:07:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 23:07:35 --> Form Validation Class Initialized
INFO - 2017-12-22 23:07:35 --> Model Class Initialized
INFO - 2017-12-22 23:07:35 --> Controller Class Initialized
INFO - 2017-12-22 23:07:35 --> Model Class Initialized
INFO - 2017-12-22 23:07:35 --> Model Class Initialized
INFO - 2017-12-22 23:07:35 --> Model Class Initialized
DEBUG - 2017-12-22 23:07:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 23:07:35 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 23:07:35 --> Final output sent to browser
DEBUG - 2017-12-22 23:07:35 --> Total execution time: 0.0605
INFO - 2017-12-22 23:07:35 --> Config Class Initialized
INFO - 2017-12-22 23:07:35 --> Hooks Class Initialized
DEBUG - 2017-12-22 23:07:35 --> UTF-8 Support Enabled
INFO - 2017-12-22 23:07:35 --> Utf8 Class Initialized
INFO - 2017-12-22 23:07:35 --> URI Class Initialized
INFO - 2017-12-22 23:07:35 --> Router Class Initialized
INFO - 2017-12-22 23:07:35 --> Output Class Initialized
INFO - 2017-12-22 23:07:35 --> Security Class Initialized
DEBUG - 2017-12-22 23:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 23:07:35 --> Input Class Initialized
INFO - 2017-12-22 23:07:35 --> Language Class Initialized
INFO - 2017-12-22 23:07:35 --> Loader Class Initialized
INFO - 2017-12-22 23:07:35 --> Helper loaded: url_helper
INFO - 2017-12-22 23:07:35 --> Helper loaded: form_helper
INFO - 2017-12-22 23:07:35 --> Database Driver Class Initialized
DEBUG - 2017-12-22 23:07:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 23:07:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 23:07:35 --> Form Validation Class Initialized
INFO - 2017-12-22 23:07:35 --> Model Class Initialized
INFO - 2017-12-22 23:07:35 --> Controller Class Initialized
INFO - 2017-12-22 23:07:35 --> Model Class Initialized
INFO - 2017-12-22 23:07:35 --> Model Class Initialized
INFO - 2017-12-22 23:07:35 --> Model Class Initialized
DEBUG - 2017-12-22 23:07:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 23:07:42 --> Config Class Initialized
INFO - 2017-12-22 23:07:42 --> Hooks Class Initialized
DEBUG - 2017-12-22 23:07:42 --> UTF-8 Support Enabled
INFO - 2017-12-22 23:07:42 --> Utf8 Class Initialized
INFO - 2017-12-22 23:07:42 --> URI Class Initialized
INFO - 2017-12-22 23:07:42 --> Router Class Initialized
INFO - 2017-12-22 23:07:42 --> Output Class Initialized
INFO - 2017-12-22 23:07:42 --> Security Class Initialized
DEBUG - 2017-12-22 23:07:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 23:07:42 --> Input Class Initialized
INFO - 2017-12-22 23:07:42 --> Language Class Initialized
INFO - 2017-12-22 23:07:42 --> Loader Class Initialized
INFO - 2017-12-22 23:07:42 --> Helper loaded: url_helper
INFO - 2017-12-22 23:07:42 --> Helper loaded: form_helper
INFO - 2017-12-22 23:07:42 --> Database Driver Class Initialized
DEBUG - 2017-12-22 23:07:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 23:07:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 23:07:42 --> Form Validation Class Initialized
INFO - 2017-12-22 23:07:42 --> Model Class Initialized
INFO - 2017-12-22 23:07:42 --> Controller Class Initialized
INFO - 2017-12-22 23:07:42 --> Model Class Initialized
INFO - 2017-12-22 23:07:42 --> Model Class Initialized
INFO - 2017-12-22 23:07:42 --> Model Class Initialized
DEBUG - 2017-12-22 23:07:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 23:07:42 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 23:07:42 --> Final output sent to browser
DEBUG - 2017-12-22 23:07:42 --> Total execution time: 0.0624
INFO - 2017-12-22 23:07:42 --> Config Class Initialized
INFO - 2017-12-22 23:07:42 --> Hooks Class Initialized
DEBUG - 2017-12-22 23:07:42 --> UTF-8 Support Enabled
INFO - 2017-12-22 23:07:42 --> Utf8 Class Initialized
INFO - 2017-12-22 23:07:42 --> URI Class Initialized
INFO - 2017-12-22 23:07:42 --> Router Class Initialized
INFO - 2017-12-22 23:07:42 --> Output Class Initialized
INFO - 2017-12-22 23:07:42 --> Security Class Initialized
DEBUG - 2017-12-22 23:07:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 23:07:42 --> Input Class Initialized
INFO - 2017-12-22 23:07:42 --> Language Class Initialized
INFO - 2017-12-22 23:07:42 --> Loader Class Initialized
INFO - 2017-12-22 23:07:42 --> Helper loaded: url_helper
INFO - 2017-12-22 23:07:42 --> Helper loaded: form_helper
INFO - 2017-12-22 23:07:42 --> Database Driver Class Initialized
DEBUG - 2017-12-22 23:07:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 23:07:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 23:07:42 --> Form Validation Class Initialized
INFO - 2017-12-22 23:07:42 --> Model Class Initialized
INFO - 2017-12-22 23:07:42 --> Controller Class Initialized
INFO - 2017-12-22 23:07:42 --> Model Class Initialized
INFO - 2017-12-22 23:07:42 --> Model Class Initialized
INFO - 2017-12-22 23:07:42 --> Model Class Initialized
DEBUG - 2017-12-22 23:07:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 23:07:48 --> Config Class Initialized
INFO - 2017-12-22 23:07:48 --> Hooks Class Initialized
DEBUG - 2017-12-22 23:07:48 --> UTF-8 Support Enabled
INFO - 2017-12-22 23:07:48 --> Utf8 Class Initialized
INFO - 2017-12-22 23:07:48 --> URI Class Initialized
INFO - 2017-12-22 23:07:48 --> Router Class Initialized
INFO - 2017-12-22 23:07:48 --> Output Class Initialized
INFO - 2017-12-22 23:07:48 --> Security Class Initialized
DEBUG - 2017-12-22 23:07:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 23:07:48 --> Input Class Initialized
INFO - 2017-12-22 23:07:48 --> Language Class Initialized
INFO - 2017-12-22 23:07:48 --> Loader Class Initialized
INFO - 2017-12-22 23:07:48 --> Helper loaded: url_helper
INFO - 2017-12-22 23:07:48 --> Helper loaded: form_helper
INFO - 2017-12-22 23:07:48 --> Database Driver Class Initialized
DEBUG - 2017-12-22 23:07:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 23:07:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 23:07:48 --> Form Validation Class Initialized
INFO - 2017-12-22 23:07:48 --> Model Class Initialized
INFO - 2017-12-22 23:07:48 --> Controller Class Initialized
INFO - 2017-12-22 23:07:48 --> Model Class Initialized
INFO - 2017-12-22 23:07:48 --> Model Class Initialized
INFO - 2017-12-22 23:07:48 --> Model Class Initialized
DEBUG - 2017-12-22 23:07:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 23:07:48 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 23:07:48 --> Final output sent to browser
DEBUG - 2017-12-22 23:07:48 --> Total execution time: 0.0539
INFO - 2017-12-22 23:08:00 --> Config Class Initialized
INFO - 2017-12-22 23:08:00 --> Hooks Class Initialized
DEBUG - 2017-12-22 23:08:00 --> UTF-8 Support Enabled
INFO - 2017-12-22 23:08:00 --> Utf8 Class Initialized
INFO - 2017-12-22 23:08:00 --> URI Class Initialized
INFO - 2017-12-22 23:08:00 --> Router Class Initialized
INFO - 2017-12-22 23:08:00 --> Output Class Initialized
INFO - 2017-12-22 23:08:00 --> Security Class Initialized
DEBUG - 2017-12-22 23:08:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 23:08:00 --> Input Class Initialized
INFO - 2017-12-22 23:08:00 --> Language Class Initialized
INFO - 2017-12-22 23:08:00 --> Loader Class Initialized
INFO - 2017-12-22 23:08:00 --> Helper loaded: url_helper
INFO - 2017-12-22 23:08:00 --> Helper loaded: form_helper
INFO - 2017-12-22 23:08:00 --> Database Driver Class Initialized
DEBUG - 2017-12-22 23:08:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 23:08:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 23:08:00 --> Form Validation Class Initialized
INFO - 2017-12-22 23:08:00 --> Model Class Initialized
INFO - 2017-12-22 23:08:00 --> Controller Class Initialized
INFO - 2017-12-22 23:08:00 --> Model Class Initialized
INFO - 2017-12-22 23:08:00 --> Model Class Initialized
INFO - 2017-12-22 23:08:00 --> Model Class Initialized
DEBUG - 2017-12-22 23:08:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 23:08:00 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 23:08:00 --> Final output sent to browser
DEBUG - 2017-12-22 23:08:00 --> Total execution time: 0.0729
INFO - 2017-12-22 23:08:00 --> Config Class Initialized
INFO - 2017-12-22 23:08:00 --> Hooks Class Initialized
DEBUG - 2017-12-22 23:08:00 --> UTF-8 Support Enabled
INFO - 2017-12-22 23:08:00 --> Utf8 Class Initialized
INFO - 2017-12-22 23:08:00 --> URI Class Initialized
INFO - 2017-12-22 23:08:00 --> Router Class Initialized
INFO - 2017-12-22 23:08:00 --> Output Class Initialized
INFO - 2017-12-22 23:08:00 --> Security Class Initialized
DEBUG - 2017-12-22 23:08:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 23:08:00 --> Input Class Initialized
INFO - 2017-12-22 23:08:00 --> Language Class Initialized
INFO - 2017-12-22 23:08:00 --> Loader Class Initialized
INFO - 2017-12-22 23:08:00 --> Helper loaded: url_helper
INFO - 2017-12-22 23:08:00 --> Helper loaded: form_helper
INFO - 2017-12-22 23:08:00 --> Database Driver Class Initialized
DEBUG - 2017-12-22 23:08:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 23:08:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 23:08:00 --> Form Validation Class Initialized
INFO - 2017-12-22 23:08:00 --> Model Class Initialized
INFO - 2017-12-22 23:08:00 --> Controller Class Initialized
INFO - 2017-12-22 23:08:00 --> Model Class Initialized
INFO - 2017-12-22 23:08:00 --> Model Class Initialized
INFO - 2017-12-22 23:08:00 --> Model Class Initialized
DEBUG - 2017-12-22 23:08:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 23:34:38 --> Config Class Initialized
INFO - 2017-12-22 23:34:38 --> Hooks Class Initialized
DEBUG - 2017-12-22 23:34:38 --> UTF-8 Support Enabled
INFO - 2017-12-22 23:34:38 --> Utf8 Class Initialized
INFO - 2017-12-22 23:34:38 --> URI Class Initialized
INFO - 2017-12-22 23:34:38 --> Router Class Initialized
INFO - 2017-12-22 23:34:38 --> Output Class Initialized
INFO - 2017-12-22 23:34:38 --> Security Class Initialized
DEBUG - 2017-12-22 23:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 23:34:38 --> Input Class Initialized
INFO - 2017-12-22 23:34:38 --> Language Class Initialized
INFO - 2017-12-22 23:34:38 --> Loader Class Initialized
INFO - 2017-12-22 23:34:38 --> Helper loaded: url_helper
INFO - 2017-12-22 23:34:38 --> Helper loaded: form_helper
INFO - 2017-12-22 23:34:38 --> Database Driver Class Initialized
DEBUG - 2017-12-22 23:34:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 23:34:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 23:34:38 --> Form Validation Class Initialized
INFO - 2017-12-22 23:34:38 --> Model Class Initialized
INFO - 2017-12-22 23:34:38 --> Controller Class Initialized
INFO - 2017-12-22 23:34:38 --> Model Class Initialized
INFO - 2017-12-22 23:34:38 --> Model Class Initialized
INFO - 2017-12-22 23:34:38 --> Model Class Initialized
DEBUG - 2017-12-22 23:34:38 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2017-12-22 23:34:38 --> Severity: Error --> Call to undefined method M_Proyecto::consultarTiposExtensiones() D:\xampp\htdocs\instateccr\instatec_app\controllers\Proyecto.php 186
INFO - 2017-12-22 23:34:39 --> Config Class Initialized
INFO - 2017-12-22 23:34:39 --> Hooks Class Initialized
DEBUG - 2017-12-22 23:34:39 --> UTF-8 Support Enabled
INFO - 2017-12-22 23:34:39 --> Utf8 Class Initialized
INFO - 2017-12-22 23:34:39 --> URI Class Initialized
INFO - 2017-12-22 23:34:39 --> Router Class Initialized
INFO - 2017-12-22 23:34:39 --> Output Class Initialized
INFO - 2017-12-22 23:34:39 --> Security Class Initialized
DEBUG - 2017-12-22 23:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 23:34:39 --> Input Class Initialized
INFO - 2017-12-22 23:34:39 --> Language Class Initialized
INFO - 2017-12-22 23:34:39 --> Loader Class Initialized
INFO - 2017-12-22 23:34:39 --> Helper loaded: url_helper
INFO - 2017-12-22 23:34:39 --> Helper loaded: form_helper
INFO - 2017-12-22 23:34:39 --> Database Driver Class Initialized
DEBUG - 2017-12-22 23:34:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 23:34:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 23:34:39 --> Form Validation Class Initialized
INFO - 2017-12-22 23:34:39 --> Model Class Initialized
INFO - 2017-12-22 23:34:39 --> Controller Class Initialized
INFO - 2017-12-22 23:34:39 --> Model Class Initialized
INFO - 2017-12-22 23:34:39 --> Model Class Initialized
INFO - 2017-12-22 23:34:39 --> Model Class Initialized
DEBUG - 2017-12-22 23:34:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 23:34:39 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 23:34:39 --> Final output sent to browser
DEBUG - 2017-12-22 23:34:39 --> Total execution time: 0.0593
INFO - 2017-12-22 23:34:41 --> Config Class Initialized
INFO - 2017-12-22 23:34:41 --> Hooks Class Initialized
DEBUG - 2017-12-22 23:34:41 --> UTF-8 Support Enabled
INFO - 2017-12-22 23:34:41 --> Utf8 Class Initialized
INFO - 2017-12-22 23:34:41 --> URI Class Initialized
INFO - 2017-12-22 23:34:41 --> Router Class Initialized
INFO - 2017-12-22 23:34:41 --> Output Class Initialized
INFO - 2017-12-22 23:34:41 --> Security Class Initialized
DEBUG - 2017-12-22 23:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 23:34:41 --> Input Class Initialized
INFO - 2017-12-22 23:34:41 --> Language Class Initialized
INFO - 2017-12-22 23:34:41 --> Loader Class Initialized
INFO - 2017-12-22 23:34:41 --> Helper loaded: url_helper
INFO - 2017-12-22 23:34:41 --> Helper loaded: form_helper
INFO - 2017-12-22 23:34:41 --> Database Driver Class Initialized
DEBUG - 2017-12-22 23:34:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 23:34:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 23:34:41 --> Form Validation Class Initialized
INFO - 2017-12-22 23:34:41 --> Model Class Initialized
INFO - 2017-12-22 23:34:41 --> Controller Class Initialized
INFO - 2017-12-22 23:34:41 --> Model Class Initialized
INFO - 2017-12-22 23:34:41 --> Model Class Initialized
INFO - 2017-12-22 23:34:41 --> Model Class Initialized
DEBUG - 2017-12-22 23:34:41 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2017-12-22 23:34:41 --> Severity: Error --> Call to undefined method M_Proyecto::consultarTiposExtensiones() D:\xampp\htdocs\instateccr\instatec_app\controllers\Proyecto.php 186
INFO - 2017-12-22 23:39:31 --> Config Class Initialized
INFO - 2017-12-22 23:39:31 --> Hooks Class Initialized
DEBUG - 2017-12-22 23:39:31 --> UTF-8 Support Enabled
INFO - 2017-12-22 23:39:31 --> Utf8 Class Initialized
INFO - 2017-12-22 23:39:31 --> URI Class Initialized
INFO - 2017-12-22 23:39:31 --> Router Class Initialized
INFO - 2017-12-22 23:39:31 --> Output Class Initialized
INFO - 2017-12-22 23:39:31 --> Security Class Initialized
DEBUG - 2017-12-22 23:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-22 23:39:31 --> Input Class Initialized
INFO - 2017-12-22 23:39:31 --> Language Class Initialized
INFO - 2017-12-22 23:39:31 --> Loader Class Initialized
INFO - 2017-12-22 23:39:31 --> Helper loaded: url_helper
INFO - 2017-12-22 23:39:31 --> Helper loaded: form_helper
INFO - 2017-12-22 23:39:31 --> Database Driver Class Initialized
DEBUG - 2017-12-22 23:39:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-22 23:39:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-22 23:39:31 --> Form Validation Class Initialized
INFO - 2017-12-22 23:39:31 --> Model Class Initialized
INFO - 2017-12-22 23:39:31 --> Controller Class Initialized
INFO - 2017-12-22 23:39:31 --> Model Class Initialized
INFO - 2017-12-22 23:39:31 --> Model Class Initialized
INFO - 2017-12-22 23:39:31 --> Model Class Initialized
DEBUG - 2017-12-22 23:39:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-22 23:39:31 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-22 23:39:31 --> Final output sent to browser
DEBUG - 2017-12-22 23:39:31 --> Total execution time: 0.1617
