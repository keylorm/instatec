<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-01-03 07:27:04 --> Config Class Initialized
INFO - 2018-01-03 07:27:04 --> Hooks Class Initialized
DEBUG - 2018-01-03 07:27:04 --> UTF-8 Support Enabled
INFO - 2018-01-03 07:27:04 --> Utf8 Class Initialized
INFO - 2018-01-03 07:27:04 --> URI Class Initialized
DEBUG - 2018-01-03 07:27:04 --> No URI present. Default controller set.
INFO - 2018-01-03 07:27:04 --> Router Class Initialized
INFO - 2018-01-03 07:27:04 --> Output Class Initialized
INFO - 2018-01-03 07:27:04 --> Security Class Initialized
DEBUG - 2018-01-03 07:27:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-03 07:27:04 --> Input Class Initialized
INFO - 2018-01-03 07:27:04 --> Language Class Initialized
INFO - 2018-01-03 07:27:04 --> Loader Class Initialized
INFO - 2018-01-03 07:27:05 --> Helper loaded: url_helper
INFO - 2018-01-03 07:27:05 --> Helper loaded: form_helper
INFO - 2018-01-03 07:27:05 --> Database Driver Class Initialized
DEBUG - 2018-01-03 07:27:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-03 07:27:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-03 07:27:05 --> Form Validation Class Initialized
INFO - 2018-01-03 07:27:05 --> Model Class Initialized
INFO - 2018-01-03 07:27:05 --> Controller Class Initialized
INFO - 2018-01-03 07:27:05 --> Config Class Initialized
INFO - 2018-01-03 07:27:05 --> Hooks Class Initialized
DEBUG - 2018-01-03 07:27:05 --> UTF-8 Support Enabled
INFO - 2018-01-03 07:27:05 --> Utf8 Class Initialized
INFO - 2018-01-03 07:27:05 --> URI Class Initialized
INFO - 2018-01-03 07:27:05 --> Config Class Initialized
INFO - 2018-01-03 07:27:05 --> Router Class Initialized
INFO - 2018-01-03 07:27:05 --> Hooks Class Initialized
INFO - 2018-01-03 07:27:05 --> Output Class Initialized
DEBUG - 2018-01-03 07:27:05 --> UTF-8 Support Enabled
INFO - 2018-01-03 07:27:05 --> Security Class Initialized
INFO - 2018-01-03 07:27:05 --> Utf8 Class Initialized
DEBUG - 2018-01-03 07:27:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-03 07:27:05 --> URI Class Initialized
INFO - 2018-01-03 07:27:05 --> Input Class Initialized
INFO - 2018-01-03 07:27:05 --> Language Class Initialized
INFO - 2018-01-03 07:27:05 --> Router Class Initialized
INFO - 2018-01-03 07:27:05 --> Output Class Initialized
INFO - 2018-01-03 07:27:05 --> Security Class Initialized
DEBUG - 2018-01-03 07:27:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-03 07:27:05 --> Input Class Initialized
INFO - 2018-01-03 07:27:05 --> Language Class Initialized
INFO - 2018-01-03 07:27:05 --> Loader Class Initialized
INFO - 2018-01-03 07:27:05 --> Helper loaded: url_helper
INFO - 2018-01-03 07:27:05 --> Helper loaded: form_helper
INFO - 2018-01-03 07:27:05 --> Database Driver Class Initialized
DEBUG - 2018-01-03 07:27:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-03 07:27:05 --> Session: Class initialized using 'files' driver.
ERROR - 2018-01-03 07:27:05 --> 404 Page Not Found: Faviconico/index
INFO - 2018-01-03 07:27:05 --> Form Validation Class Initialized
INFO - 2018-01-03 07:27:05 --> Model Class Initialized
INFO - 2018-01-03 07:27:05 --> Controller Class Initialized
INFO - 2018-01-03 07:27:05 --> Model Class Initialized
DEBUG - 2018-01-03 07:27:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-03 07:27:05 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-03 07:27:05 --> Final output sent to browser
DEBUG - 2018-01-03 07:27:05 --> Total execution time: 0.1045
INFO - 2018-01-03 07:27:06 --> Config Class Initialized
INFO - 2018-01-03 07:27:06 --> Hooks Class Initialized
DEBUG - 2018-01-03 07:27:06 --> UTF-8 Support Enabled
INFO - 2018-01-03 07:27:06 --> Utf8 Class Initialized
INFO - 2018-01-03 07:27:06 --> URI Class Initialized
INFO - 2018-01-03 07:27:06 --> Router Class Initialized
INFO - 2018-01-03 07:27:06 --> Output Class Initialized
INFO - 2018-01-03 07:27:06 --> Security Class Initialized
DEBUG - 2018-01-03 07:27:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-03 07:27:06 --> Input Class Initialized
INFO - 2018-01-03 07:27:06 --> Language Class Initialized
INFO - 2018-01-03 07:27:06 --> Loader Class Initialized
INFO - 2018-01-03 07:27:06 --> Helper loaded: url_helper
INFO - 2018-01-03 07:27:06 --> Helper loaded: form_helper
INFO - 2018-01-03 07:27:06 --> Database Driver Class Initialized
DEBUG - 2018-01-03 07:27:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-03 07:27:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-03 07:27:06 --> Form Validation Class Initialized
INFO - 2018-01-03 07:27:06 --> Model Class Initialized
INFO - 2018-01-03 07:27:06 --> Controller Class Initialized
INFO - 2018-01-03 07:27:06 --> Model Class Initialized
DEBUG - 2018-01-03 07:27:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-03 07:27:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-01-03 07:27:06 --> Config Class Initialized
INFO - 2018-01-03 07:27:06 --> Hooks Class Initialized
DEBUG - 2018-01-03 07:27:06 --> UTF-8 Support Enabled
INFO - 2018-01-03 07:27:06 --> Utf8 Class Initialized
INFO - 2018-01-03 07:27:06 --> URI Class Initialized
DEBUG - 2018-01-03 07:27:06 --> No URI present. Default controller set.
INFO - 2018-01-03 07:27:06 --> Router Class Initialized
INFO - 2018-01-03 07:27:06 --> Output Class Initialized
INFO - 2018-01-03 07:27:06 --> Security Class Initialized
DEBUG - 2018-01-03 07:27:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-03 07:27:06 --> Input Class Initialized
INFO - 2018-01-03 07:27:06 --> Language Class Initialized
INFO - 2018-01-03 07:27:06 --> Loader Class Initialized
INFO - 2018-01-03 07:27:06 --> Helper loaded: url_helper
INFO - 2018-01-03 07:27:06 --> Helper loaded: form_helper
INFO - 2018-01-03 07:27:06 --> Database Driver Class Initialized
DEBUG - 2018-01-03 07:27:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-03 07:27:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-03 07:27:06 --> Form Validation Class Initialized
INFO - 2018-01-03 07:27:06 --> Model Class Initialized
INFO - 2018-01-03 07:27:06 --> Controller Class Initialized
INFO - 2018-01-03 07:27:06 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-03 07:27:06 --> Final output sent to browser
DEBUG - 2018-01-03 07:27:06 --> Total execution time: 0.0384
INFO - 2018-01-03 07:27:06 --> Config Class Initialized
INFO - 2018-01-03 07:27:06 --> Hooks Class Initialized
DEBUG - 2018-01-03 07:27:07 --> UTF-8 Support Enabled
INFO - 2018-01-03 07:27:07 --> Utf8 Class Initialized
INFO - 2018-01-03 07:27:07 --> URI Class Initialized
INFO - 2018-01-03 07:27:07 --> Router Class Initialized
INFO - 2018-01-03 07:27:07 --> Output Class Initialized
INFO - 2018-01-03 07:27:07 --> Security Class Initialized
DEBUG - 2018-01-03 07:27:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-03 07:27:07 --> Input Class Initialized
INFO - 2018-01-03 07:27:07 --> Language Class Initialized
INFO - 2018-01-03 07:27:07 --> Loader Class Initialized
INFO - 2018-01-03 07:27:07 --> Helper loaded: url_helper
INFO - 2018-01-03 07:27:07 --> Helper loaded: form_helper
INFO - 2018-01-03 07:27:07 --> Database Driver Class Initialized
DEBUG - 2018-01-03 07:27:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-03 07:27:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-03 07:27:07 --> Form Validation Class Initialized
INFO - 2018-01-03 07:27:07 --> Model Class Initialized
INFO - 2018-01-03 07:27:07 --> Controller Class Initialized
INFO - 2018-01-03 07:27:07 --> Model Class Initialized
INFO - 2018-01-03 07:27:07 --> Model Class Initialized
INFO - 2018-01-03 07:27:07 --> Model Class Initialized
INFO - 2018-01-03 07:27:07 --> Model Class Initialized
DEBUG - 2018-01-03 07:27:07 --> Form_validation class already loaded. Second attempt ignored.
