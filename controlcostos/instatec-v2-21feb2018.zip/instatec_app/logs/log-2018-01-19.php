<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-01-19 06:07:59 --> Config Class Initialized
INFO - 2018-01-19 06:07:59 --> Hooks Class Initialized
DEBUG - 2018-01-19 06:07:59 --> UTF-8 Support Enabled
INFO - 2018-01-19 06:07:59 --> Utf8 Class Initialized
INFO - 2018-01-19 06:07:59 --> URI Class Initialized
DEBUG - 2018-01-19 06:07:59 --> No URI present. Default controller set.
INFO - 2018-01-19 06:07:59 --> Router Class Initialized
INFO - 2018-01-19 06:08:00 --> Output Class Initialized
INFO - 2018-01-19 06:08:00 --> Security Class Initialized
DEBUG - 2018-01-19 06:08:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 06:08:00 --> Input Class Initialized
INFO - 2018-01-19 06:08:00 --> Language Class Initialized
INFO - 2018-01-19 06:08:00 --> Loader Class Initialized
INFO - 2018-01-19 06:08:00 --> Helper loaded: url_helper
INFO - 2018-01-19 06:08:00 --> Helper loaded: form_helper
INFO - 2018-01-19 06:08:00 --> Database Driver Class Initialized
DEBUG - 2018-01-19 06:08:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 06:08:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 06:08:00 --> Form Validation Class Initialized
INFO - 2018-01-19 06:08:00 --> Model Class Initialized
INFO - 2018-01-19 06:08:00 --> Controller Class Initialized
INFO - 2018-01-19 06:08:00 --> Config Class Initialized
INFO - 2018-01-19 06:08:00 --> Hooks Class Initialized
DEBUG - 2018-01-19 06:08:00 --> UTF-8 Support Enabled
INFO - 2018-01-19 06:08:00 --> Utf8 Class Initialized
INFO - 2018-01-19 06:08:00 --> URI Class Initialized
INFO - 2018-01-19 06:08:00 --> Router Class Initialized
INFO - 2018-01-19 06:08:00 --> Output Class Initialized
INFO - 2018-01-19 06:08:00 --> Security Class Initialized
DEBUG - 2018-01-19 06:08:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 06:08:00 --> Input Class Initialized
INFO - 2018-01-19 06:08:00 --> Language Class Initialized
INFO - 2018-01-19 06:08:00 --> Loader Class Initialized
INFO - 2018-01-19 06:08:00 --> Helper loaded: url_helper
INFO - 2018-01-19 06:08:00 --> Helper loaded: form_helper
INFO - 2018-01-19 06:08:00 --> Database Driver Class Initialized
DEBUG - 2018-01-19 06:08:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 06:08:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 06:08:00 --> Form Validation Class Initialized
INFO - 2018-01-19 06:08:00 --> Model Class Initialized
INFO - 2018-01-19 06:08:00 --> Controller Class Initialized
INFO - 2018-01-19 06:08:00 --> Model Class Initialized
DEBUG - 2018-01-19 06:08:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 06:08:00 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 06:08:00 --> Final output sent to browser
DEBUG - 2018-01-19 06:08:00 --> Total execution time: 0.0484
INFO - 2018-01-19 06:09:09 --> Config Class Initialized
INFO - 2018-01-19 06:09:09 --> Hooks Class Initialized
DEBUG - 2018-01-19 06:09:09 --> UTF-8 Support Enabled
INFO - 2018-01-19 06:09:09 --> Utf8 Class Initialized
INFO - 2018-01-19 06:09:09 --> URI Class Initialized
INFO - 2018-01-19 06:09:09 --> Router Class Initialized
INFO - 2018-01-19 06:09:09 --> Output Class Initialized
INFO - 2018-01-19 06:09:09 --> Security Class Initialized
DEBUG - 2018-01-19 06:09:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 06:09:09 --> Input Class Initialized
INFO - 2018-01-19 06:09:09 --> Language Class Initialized
INFO - 2018-01-19 06:09:09 --> Loader Class Initialized
INFO - 2018-01-19 06:09:09 --> Helper loaded: url_helper
INFO - 2018-01-19 06:09:09 --> Helper loaded: form_helper
INFO - 2018-01-19 06:09:09 --> Database Driver Class Initialized
DEBUG - 2018-01-19 06:09:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 06:09:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 06:09:09 --> Form Validation Class Initialized
INFO - 2018-01-19 06:09:09 --> Model Class Initialized
INFO - 2018-01-19 06:09:09 --> Controller Class Initialized
INFO - 2018-01-19 06:09:09 --> Model Class Initialized
DEBUG - 2018-01-19 06:09:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 06:09:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-01-19 06:09:12 --> Config Class Initialized
INFO - 2018-01-19 06:09:12 --> Hooks Class Initialized
DEBUG - 2018-01-19 06:09:12 --> UTF-8 Support Enabled
INFO - 2018-01-19 06:09:12 --> Utf8 Class Initialized
INFO - 2018-01-19 06:09:12 --> URI Class Initialized
DEBUG - 2018-01-19 06:09:12 --> No URI present. Default controller set.
INFO - 2018-01-19 06:09:12 --> Router Class Initialized
INFO - 2018-01-19 06:09:12 --> Output Class Initialized
INFO - 2018-01-19 06:09:12 --> Security Class Initialized
DEBUG - 2018-01-19 06:09:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 06:09:12 --> Input Class Initialized
INFO - 2018-01-19 06:09:12 --> Language Class Initialized
INFO - 2018-01-19 06:09:12 --> Loader Class Initialized
INFO - 2018-01-19 06:09:12 --> Helper loaded: url_helper
INFO - 2018-01-19 06:09:12 --> Helper loaded: form_helper
INFO - 2018-01-19 06:09:12 --> Database Driver Class Initialized
DEBUG - 2018-01-19 06:09:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 06:09:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 06:09:12 --> Form Validation Class Initialized
INFO - 2018-01-19 06:09:12 --> Model Class Initialized
INFO - 2018-01-19 06:09:12 --> Controller Class Initialized
INFO - 2018-01-19 06:09:12 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 06:09:12 --> Final output sent to browser
DEBUG - 2018-01-19 06:09:12 --> Total execution time: 0.0349
INFO - 2018-01-19 06:09:34 --> Config Class Initialized
INFO - 2018-01-19 06:09:34 --> Hooks Class Initialized
DEBUG - 2018-01-19 06:09:34 --> UTF-8 Support Enabled
INFO - 2018-01-19 06:09:34 --> Utf8 Class Initialized
INFO - 2018-01-19 06:09:34 --> URI Class Initialized
INFO - 2018-01-19 06:09:34 --> Router Class Initialized
INFO - 2018-01-19 06:09:34 --> Output Class Initialized
INFO - 2018-01-19 06:09:34 --> Security Class Initialized
DEBUG - 2018-01-19 06:09:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 06:09:34 --> Input Class Initialized
INFO - 2018-01-19 06:09:34 --> Language Class Initialized
INFO - 2018-01-19 06:09:34 --> Loader Class Initialized
INFO - 2018-01-19 06:09:34 --> Helper loaded: url_helper
INFO - 2018-01-19 06:09:34 --> Helper loaded: form_helper
INFO - 2018-01-19 06:09:34 --> Database Driver Class Initialized
DEBUG - 2018-01-19 06:09:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 06:09:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 06:09:34 --> Form Validation Class Initialized
INFO - 2018-01-19 06:09:34 --> Model Class Initialized
INFO - 2018-01-19 06:09:34 --> Controller Class Initialized
INFO - 2018-01-19 06:09:34 --> Model Class Initialized
INFO - 2018-01-19 06:09:34 --> Model Class Initialized
INFO - 2018-01-19 06:09:34 --> Model Class Initialized
INFO - 2018-01-19 06:09:36 --> Model Class Initialized
DEBUG - 2018-01-19 06:09:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 06:09:37 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 06:09:37 --> Final output sent to browser
DEBUG - 2018-01-19 06:09:37 --> Total execution time: 2.2067
INFO - 2018-01-19 06:09:39 --> Config Class Initialized
INFO - 2018-01-19 06:09:39 --> Hooks Class Initialized
DEBUG - 2018-01-19 06:09:39 --> UTF-8 Support Enabled
INFO - 2018-01-19 06:09:39 --> Utf8 Class Initialized
INFO - 2018-01-19 06:09:39 --> URI Class Initialized
INFO - 2018-01-19 06:09:39 --> Router Class Initialized
INFO - 2018-01-19 06:09:39 --> Output Class Initialized
INFO - 2018-01-19 06:09:39 --> Security Class Initialized
DEBUG - 2018-01-19 06:09:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 06:09:39 --> Input Class Initialized
INFO - 2018-01-19 06:09:39 --> Language Class Initialized
INFO - 2018-01-19 06:09:39 --> Loader Class Initialized
INFO - 2018-01-19 06:09:39 --> Helper loaded: url_helper
INFO - 2018-01-19 06:09:39 --> Helper loaded: form_helper
INFO - 2018-01-19 06:09:39 --> Database Driver Class Initialized
DEBUG - 2018-01-19 06:09:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 06:09:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 06:09:39 --> Form Validation Class Initialized
INFO - 2018-01-19 06:09:39 --> Model Class Initialized
INFO - 2018-01-19 06:09:39 --> Controller Class Initialized
INFO - 2018-01-19 06:09:39 --> Model Class Initialized
INFO - 2018-01-19 06:09:39 --> Model Class Initialized
INFO - 2018-01-19 06:09:39 --> Model Class Initialized
INFO - 2018-01-19 06:09:39 --> Model Class Initialized
DEBUG - 2018-01-19 06:09:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 06:09:39 --> Config Class Initialized
INFO - 2018-01-19 06:09:39 --> Hooks Class Initialized
DEBUG - 2018-01-19 06:09:39 --> UTF-8 Support Enabled
INFO - 2018-01-19 06:09:39 --> Utf8 Class Initialized
INFO - 2018-01-19 06:09:39 --> URI Class Initialized
DEBUG - 2018-01-19 06:09:39 --> No URI present. Default controller set.
INFO - 2018-01-19 06:09:39 --> Router Class Initialized
INFO - 2018-01-19 06:09:39 --> Output Class Initialized
INFO - 2018-01-19 06:09:39 --> Security Class Initialized
DEBUG - 2018-01-19 06:09:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 06:09:39 --> Input Class Initialized
INFO - 2018-01-19 06:09:39 --> Language Class Initialized
INFO - 2018-01-19 06:09:39 --> Loader Class Initialized
INFO - 2018-01-19 06:09:39 --> Helper loaded: url_helper
INFO - 2018-01-19 06:09:39 --> Helper loaded: form_helper
INFO - 2018-01-19 06:09:39 --> Database Driver Class Initialized
DEBUG - 2018-01-19 06:09:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 06:09:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 06:09:39 --> Form Validation Class Initialized
INFO - 2018-01-19 06:09:39 --> Model Class Initialized
INFO - 2018-01-19 06:09:39 --> Controller Class Initialized
INFO - 2018-01-19 06:09:39 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 06:09:39 --> Final output sent to browser
DEBUG - 2018-01-19 06:09:39 --> Total execution time: 0.0398
INFO - 2018-01-19 06:09:46 --> Config Class Initialized
INFO - 2018-01-19 06:09:46 --> Hooks Class Initialized
DEBUG - 2018-01-19 06:09:46 --> UTF-8 Support Enabled
INFO - 2018-01-19 06:09:46 --> Utf8 Class Initialized
INFO - 2018-01-19 06:09:46 --> URI Class Initialized
INFO - 2018-01-19 06:09:46 --> Router Class Initialized
INFO - 2018-01-19 06:09:46 --> Output Class Initialized
INFO - 2018-01-19 06:09:46 --> Security Class Initialized
DEBUG - 2018-01-19 06:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 06:09:46 --> Input Class Initialized
INFO - 2018-01-19 06:09:46 --> Language Class Initialized
INFO - 2018-01-19 06:09:46 --> Loader Class Initialized
INFO - 2018-01-19 06:09:46 --> Helper loaded: url_helper
INFO - 2018-01-19 06:09:46 --> Helper loaded: form_helper
INFO - 2018-01-19 06:09:46 --> Database Driver Class Initialized
DEBUG - 2018-01-19 06:09:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 06:09:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 06:09:46 --> Form Validation Class Initialized
INFO - 2018-01-19 06:09:46 --> Model Class Initialized
INFO - 2018-01-19 06:09:46 --> Controller Class Initialized
INFO - 2018-01-19 06:09:46 --> Model Class Initialized
INFO - 2018-01-19 06:09:46 --> Model Class Initialized
INFO - 2018-01-19 06:09:46 --> Model Class Initialized
INFO - 2018-01-19 06:09:46 --> Model Class Initialized
DEBUG - 2018-01-19 06:09:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 06:09:46 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 06:09:46 --> Final output sent to browser
DEBUG - 2018-01-19 06:09:46 --> Total execution time: 0.0515
INFO - 2018-01-19 06:09:47 --> Config Class Initialized
INFO - 2018-01-19 06:09:47 --> Hooks Class Initialized
DEBUG - 2018-01-19 06:09:47 --> UTF-8 Support Enabled
INFO - 2018-01-19 06:09:47 --> Utf8 Class Initialized
INFO - 2018-01-19 06:09:47 --> URI Class Initialized
INFO - 2018-01-19 06:09:47 --> Router Class Initialized
INFO - 2018-01-19 06:09:47 --> Output Class Initialized
INFO - 2018-01-19 06:09:47 --> Security Class Initialized
DEBUG - 2018-01-19 06:09:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 06:09:47 --> Input Class Initialized
INFO - 2018-01-19 06:09:47 --> Language Class Initialized
INFO - 2018-01-19 06:09:47 --> Loader Class Initialized
INFO - 2018-01-19 06:09:47 --> Helper loaded: url_helper
INFO - 2018-01-19 06:09:47 --> Helper loaded: form_helper
INFO - 2018-01-19 06:09:47 --> Database Driver Class Initialized
DEBUG - 2018-01-19 06:09:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 06:09:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 06:09:47 --> Form Validation Class Initialized
INFO - 2018-01-19 06:09:47 --> Model Class Initialized
INFO - 2018-01-19 06:09:47 --> Controller Class Initialized
INFO - 2018-01-19 06:09:47 --> Model Class Initialized
INFO - 2018-01-19 06:09:47 --> Model Class Initialized
INFO - 2018-01-19 06:09:47 --> Model Class Initialized
INFO - 2018-01-19 06:09:47 --> Model Class Initialized
DEBUG - 2018-01-19 06:09:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 06:09:51 --> Config Class Initialized
INFO - 2018-01-19 06:09:51 --> Hooks Class Initialized
DEBUG - 2018-01-19 06:09:51 --> UTF-8 Support Enabled
INFO - 2018-01-19 06:09:51 --> Utf8 Class Initialized
INFO - 2018-01-19 06:09:51 --> URI Class Initialized
INFO - 2018-01-19 06:09:51 --> Router Class Initialized
INFO - 2018-01-19 06:09:51 --> Output Class Initialized
INFO - 2018-01-19 06:09:51 --> Security Class Initialized
DEBUG - 2018-01-19 06:09:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 06:09:51 --> Input Class Initialized
INFO - 2018-01-19 06:09:51 --> Language Class Initialized
INFO - 2018-01-19 06:09:51 --> Loader Class Initialized
INFO - 2018-01-19 06:09:51 --> Helper loaded: url_helper
INFO - 2018-01-19 06:09:51 --> Helper loaded: form_helper
INFO - 2018-01-19 06:09:51 --> Database Driver Class Initialized
DEBUG - 2018-01-19 06:09:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 06:09:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 06:09:51 --> Form Validation Class Initialized
INFO - 2018-01-19 06:09:51 --> Model Class Initialized
INFO - 2018-01-19 06:09:51 --> Controller Class Initialized
INFO - 2018-01-19 06:09:51 --> Model Class Initialized
INFO - 2018-01-19 06:09:51 --> Model Class Initialized
INFO - 2018-01-19 06:09:51 --> Model Class Initialized
INFO - 2018-01-19 06:09:51 --> Model Class Initialized
DEBUG - 2018-01-19 06:09:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 06:09:51 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 06:09:51 --> Final output sent to browser
DEBUG - 2018-01-19 06:09:51 --> Total execution time: 0.0741
INFO - 2018-01-19 06:09:52 --> Config Class Initialized
INFO - 2018-01-19 06:09:52 --> Hooks Class Initialized
DEBUG - 2018-01-19 06:09:52 --> UTF-8 Support Enabled
INFO - 2018-01-19 06:09:52 --> Utf8 Class Initialized
INFO - 2018-01-19 06:09:52 --> URI Class Initialized
INFO - 2018-01-19 06:09:52 --> Router Class Initialized
INFO - 2018-01-19 06:09:52 --> Output Class Initialized
INFO - 2018-01-19 06:09:52 --> Security Class Initialized
DEBUG - 2018-01-19 06:09:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 06:09:52 --> Input Class Initialized
INFO - 2018-01-19 06:09:52 --> Language Class Initialized
INFO - 2018-01-19 06:09:52 --> Loader Class Initialized
INFO - 2018-01-19 06:09:52 --> Helper loaded: url_helper
INFO - 2018-01-19 06:09:52 --> Helper loaded: form_helper
INFO - 2018-01-19 06:09:52 --> Database Driver Class Initialized
DEBUG - 2018-01-19 06:09:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 06:09:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 06:09:52 --> Form Validation Class Initialized
INFO - 2018-01-19 06:09:52 --> Model Class Initialized
INFO - 2018-01-19 06:09:52 --> Controller Class Initialized
INFO - 2018-01-19 06:09:52 --> Model Class Initialized
INFO - 2018-01-19 06:09:52 --> Model Class Initialized
INFO - 2018-01-19 06:09:52 --> Model Class Initialized
INFO - 2018-01-19 06:09:52 --> Model Class Initialized
DEBUG - 2018-01-19 06:09:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 06:09:54 --> Config Class Initialized
INFO - 2018-01-19 06:09:54 --> Hooks Class Initialized
DEBUG - 2018-01-19 06:09:54 --> UTF-8 Support Enabled
INFO - 2018-01-19 06:09:54 --> Utf8 Class Initialized
INFO - 2018-01-19 06:09:54 --> URI Class Initialized
INFO - 2018-01-19 06:09:54 --> Router Class Initialized
INFO - 2018-01-19 06:09:54 --> Output Class Initialized
INFO - 2018-01-19 06:09:54 --> Security Class Initialized
DEBUG - 2018-01-19 06:09:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 06:09:54 --> Input Class Initialized
INFO - 2018-01-19 06:09:54 --> Language Class Initialized
INFO - 2018-01-19 06:09:54 --> Loader Class Initialized
INFO - 2018-01-19 06:09:54 --> Helper loaded: url_helper
INFO - 2018-01-19 06:09:54 --> Helper loaded: form_helper
INFO - 2018-01-19 06:09:54 --> Database Driver Class Initialized
DEBUG - 2018-01-19 06:09:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 06:09:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 06:09:54 --> Form Validation Class Initialized
INFO - 2018-01-19 06:09:54 --> Model Class Initialized
INFO - 2018-01-19 06:09:54 --> Controller Class Initialized
INFO - 2018-01-19 06:09:54 --> Model Class Initialized
INFO - 2018-01-19 06:09:54 --> Model Class Initialized
INFO - 2018-01-19 06:09:54 --> Model Class Initialized
INFO - 2018-01-19 06:09:54 --> Model Class Initialized
DEBUG - 2018-01-19 06:09:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 06:09:54 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 06:09:54 --> Final output sent to browser
DEBUG - 2018-01-19 06:09:54 --> Total execution time: 0.0503
INFO - 2018-01-19 06:09:55 --> Config Class Initialized
INFO - 2018-01-19 06:09:55 --> Hooks Class Initialized
DEBUG - 2018-01-19 06:09:55 --> UTF-8 Support Enabled
INFO - 2018-01-19 06:09:55 --> Utf8 Class Initialized
INFO - 2018-01-19 06:09:55 --> URI Class Initialized
INFO - 2018-01-19 06:09:55 --> Router Class Initialized
INFO - 2018-01-19 06:09:55 --> Output Class Initialized
INFO - 2018-01-19 06:09:55 --> Security Class Initialized
DEBUG - 2018-01-19 06:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 06:09:55 --> Input Class Initialized
INFO - 2018-01-19 06:09:55 --> Language Class Initialized
INFO - 2018-01-19 06:09:55 --> Loader Class Initialized
INFO - 2018-01-19 06:09:55 --> Helper loaded: url_helper
INFO - 2018-01-19 06:09:55 --> Helper loaded: form_helper
INFO - 2018-01-19 06:09:55 --> Database Driver Class Initialized
DEBUG - 2018-01-19 06:09:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 06:09:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 06:09:55 --> Form Validation Class Initialized
INFO - 2018-01-19 06:09:55 --> Model Class Initialized
INFO - 2018-01-19 06:09:55 --> Controller Class Initialized
INFO - 2018-01-19 06:09:55 --> Model Class Initialized
INFO - 2018-01-19 06:09:55 --> Model Class Initialized
INFO - 2018-01-19 06:09:55 --> Model Class Initialized
INFO - 2018-01-19 06:09:55 --> Model Class Initialized
DEBUG - 2018-01-19 06:09:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 06:09:55 --> Config Class Initialized
INFO - 2018-01-19 06:09:55 --> Hooks Class Initialized
DEBUG - 2018-01-19 06:09:55 --> UTF-8 Support Enabled
INFO - 2018-01-19 06:09:55 --> Utf8 Class Initialized
INFO - 2018-01-19 06:09:55 --> URI Class Initialized
INFO - 2018-01-19 06:09:55 --> Router Class Initialized
INFO - 2018-01-19 06:09:55 --> Output Class Initialized
INFO - 2018-01-19 06:09:55 --> Security Class Initialized
DEBUG - 2018-01-19 06:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 06:09:55 --> Input Class Initialized
INFO - 2018-01-19 06:09:55 --> Language Class Initialized
INFO - 2018-01-19 06:09:55 --> Loader Class Initialized
INFO - 2018-01-19 06:09:55 --> Helper loaded: url_helper
INFO - 2018-01-19 06:09:55 --> Helper loaded: form_helper
INFO - 2018-01-19 06:09:55 --> Database Driver Class Initialized
DEBUG - 2018-01-19 06:09:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 06:09:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 06:09:56 --> Form Validation Class Initialized
INFO - 2018-01-19 06:09:56 --> Model Class Initialized
INFO - 2018-01-19 06:09:56 --> Controller Class Initialized
INFO - 2018-01-19 06:09:56 --> Model Class Initialized
INFO - 2018-01-19 06:09:56 --> Model Class Initialized
INFO - 2018-01-19 06:09:56 --> Model Class Initialized
INFO - 2018-01-19 06:09:56 --> Model Class Initialized
DEBUG - 2018-01-19 06:09:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 06:10:08 --> Config Class Initialized
INFO - 2018-01-19 06:10:08 --> Hooks Class Initialized
DEBUG - 2018-01-19 06:10:08 --> UTF-8 Support Enabled
INFO - 2018-01-19 06:10:08 --> Utf8 Class Initialized
INFO - 2018-01-19 06:10:08 --> URI Class Initialized
INFO - 2018-01-19 06:10:08 --> Router Class Initialized
INFO - 2018-01-19 06:10:08 --> Output Class Initialized
INFO - 2018-01-19 06:10:08 --> Security Class Initialized
DEBUG - 2018-01-19 06:10:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 06:10:08 --> Input Class Initialized
INFO - 2018-01-19 06:10:08 --> Language Class Initialized
INFO - 2018-01-19 06:10:08 --> Loader Class Initialized
INFO - 2018-01-19 06:10:08 --> Helper loaded: url_helper
INFO - 2018-01-19 06:10:08 --> Helper loaded: form_helper
INFO - 2018-01-19 06:10:08 --> Database Driver Class Initialized
DEBUG - 2018-01-19 06:10:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 06:10:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 06:10:08 --> Form Validation Class Initialized
INFO - 2018-01-19 06:10:08 --> Model Class Initialized
INFO - 2018-01-19 06:10:08 --> Controller Class Initialized
INFO - 2018-01-19 06:10:08 --> Model Class Initialized
INFO - 2018-01-19 06:10:08 --> Model Class Initialized
INFO - 2018-01-19 06:10:08 --> Model Class Initialized
INFO - 2018-01-19 06:10:08 --> Model Class Initialized
DEBUG - 2018-01-19 06:10:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 06:10:29 --> Config Class Initialized
INFO - 2018-01-19 06:10:29 --> Hooks Class Initialized
DEBUG - 2018-01-19 06:10:29 --> UTF-8 Support Enabled
INFO - 2018-01-19 06:10:29 --> Utf8 Class Initialized
INFO - 2018-01-19 06:10:29 --> URI Class Initialized
INFO - 2018-01-19 06:10:29 --> Router Class Initialized
INFO - 2018-01-19 06:10:29 --> Output Class Initialized
INFO - 2018-01-19 06:10:29 --> Security Class Initialized
DEBUG - 2018-01-19 06:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 06:10:29 --> Input Class Initialized
INFO - 2018-01-19 06:10:29 --> Language Class Initialized
INFO - 2018-01-19 06:10:29 --> Loader Class Initialized
INFO - 2018-01-19 06:10:29 --> Helper loaded: url_helper
INFO - 2018-01-19 06:10:29 --> Helper loaded: form_helper
INFO - 2018-01-19 06:10:29 --> Database Driver Class Initialized
DEBUG - 2018-01-19 06:10:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 06:10:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 06:10:29 --> Form Validation Class Initialized
INFO - 2018-01-19 06:10:29 --> Model Class Initialized
INFO - 2018-01-19 06:10:29 --> Controller Class Initialized
INFO - 2018-01-19 06:10:29 --> Model Class Initialized
INFO - 2018-01-19 06:10:29 --> Model Class Initialized
INFO - 2018-01-19 06:10:29 --> Model Class Initialized
INFO - 2018-01-19 06:10:29 --> Model Class Initialized
DEBUG - 2018-01-19 06:10:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 06:11:18 --> Config Class Initialized
INFO - 2018-01-19 06:11:18 --> Hooks Class Initialized
DEBUG - 2018-01-19 06:11:18 --> UTF-8 Support Enabled
INFO - 2018-01-19 06:11:18 --> Utf8 Class Initialized
INFO - 2018-01-19 06:11:18 --> URI Class Initialized
INFO - 2018-01-19 06:11:18 --> Router Class Initialized
INFO - 2018-01-19 06:11:18 --> Output Class Initialized
INFO - 2018-01-19 06:11:18 --> Security Class Initialized
DEBUG - 2018-01-19 06:11:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 06:11:18 --> Input Class Initialized
INFO - 2018-01-19 06:11:18 --> Language Class Initialized
INFO - 2018-01-19 06:11:18 --> Loader Class Initialized
INFO - 2018-01-19 06:11:18 --> Helper loaded: url_helper
INFO - 2018-01-19 06:11:18 --> Helper loaded: form_helper
INFO - 2018-01-19 06:11:18 --> Database Driver Class Initialized
DEBUG - 2018-01-19 06:11:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 06:11:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 06:11:18 --> Form Validation Class Initialized
INFO - 2018-01-19 06:11:18 --> Model Class Initialized
INFO - 2018-01-19 06:11:18 --> Controller Class Initialized
INFO - 2018-01-19 06:11:18 --> Model Class Initialized
INFO - 2018-01-19 06:11:18 --> Model Class Initialized
INFO - 2018-01-19 06:11:18 --> Model Class Initialized
INFO - 2018-01-19 06:11:18 --> Model Class Initialized
DEBUG - 2018-01-19 06:11:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 06:19:16 --> Config Class Initialized
INFO - 2018-01-19 06:19:16 --> Hooks Class Initialized
DEBUG - 2018-01-19 06:19:16 --> UTF-8 Support Enabled
INFO - 2018-01-19 06:19:16 --> Utf8 Class Initialized
INFO - 2018-01-19 06:19:16 --> URI Class Initialized
INFO - 2018-01-19 06:19:16 --> Router Class Initialized
INFO - 2018-01-19 06:19:16 --> Output Class Initialized
INFO - 2018-01-19 06:19:16 --> Security Class Initialized
DEBUG - 2018-01-19 06:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 06:19:16 --> Input Class Initialized
INFO - 2018-01-19 06:19:16 --> Language Class Initialized
INFO - 2018-01-19 06:19:16 --> Loader Class Initialized
INFO - 2018-01-19 06:19:16 --> Helper loaded: url_helper
INFO - 2018-01-19 06:19:16 --> Helper loaded: form_helper
INFO - 2018-01-19 06:19:16 --> Database Driver Class Initialized
DEBUG - 2018-01-19 06:19:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 06:19:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 06:19:16 --> Form Validation Class Initialized
INFO - 2018-01-19 06:19:16 --> Model Class Initialized
INFO - 2018-01-19 06:19:16 --> Controller Class Initialized
INFO - 2018-01-19 06:19:16 --> Model Class Initialized
INFO - 2018-01-19 06:19:16 --> Model Class Initialized
INFO - 2018-01-19 06:19:16 --> Model Class Initialized
INFO - 2018-01-19 06:19:16 --> Model Class Initialized
DEBUG - 2018-01-19 06:19:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 06:19:16 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 06:19:16 --> Final output sent to browser
DEBUG - 2018-01-19 06:19:16 --> Total execution time: 0.1134
INFO - 2018-01-19 06:19:21 --> Config Class Initialized
INFO - 2018-01-19 06:19:21 --> Hooks Class Initialized
DEBUG - 2018-01-19 06:19:21 --> UTF-8 Support Enabled
INFO - 2018-01-19 06:19:21 --> Utf8 Class Initialized
INFO - 2018-01-19 06:19:21 --> URI Class Initialized
INFO - 2018-01-19 06:19:21 --> Router Class Initialized
INFO - 2018-01-19 06:19:21 --> Output Class Initialized
INFO - 2018-01-19 06:19:21 --> Security Class Initialized
DEBUG - 2018-01-19 06:19:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 06:19:21 --> Input Class Initialized
INFO - 2018-01-19 06:19:21 --> Language Class Initialized
INFO - 2018-01-19 06:19:21 --> Loader Class Initialized
INFO - 2018-01-19 06:19:21 --> Helper loaded: url_helper
INFO - 2018-01-19 06:19:21 --> Helper loaded: form_helper
INFO - 2018-01-19 06:19:21 --> Database Driver Class Initialized
DEBUG - 2018-01-19 06:19:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 06:19:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 06:19:21 --> Form Validation Class Initialized
INFO - 2018-01-19 06:19:21 --> Model Class Initialized
INFO - 2018-01-19 06:19:21 --> Controller Class Initialized
INFO - 2018-01-19 06:19:21 --> Model Class Initialized
INFO - 2018-01-19 06:19:21 --> Model Class Initialized
INFO - 2018-01-19 06:19:21 --> Model Class Initialized
INFO - 2018-01-19 06:19:21 --> Model Class Initialized
DEBUG - 2018-01-19 06:19:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 06:19:21 --> Config Class Initialized
INFO - 2018-01-19 06:19:21 --> Hooks Class Initialized
DEBUG - 2018-01-19 06:19:21 --> UTF-8 Support Enabled
INFO - 2018-01-19 06:19:21 --> Utf8 Class Initialized
INFO - 2018-01-19 06:19:21 --> URI Class Initialized
INFO - 2018-01-19 06:19:21 --> Router Class Initialized
INFO - 2018-01-19 06:19:21 --> Output Class Initialized
INFO - 2018-01-19 06:19:21 --> Security Class Initialized
DEBUG - 2018-01-19 06:19:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 06:19:21 --> Input Class Initialized
INFO - 2018-01-19 06:19:21 --> Language Class Initialized
INFO - 2018-01-19 06:19:21 --> Loader Class Initialized
INFO - 2018-01-19 06:19:21 --> Helper loaded: url_helper
INFO - 2018-01-19 06:19:21 --> Helper loaded: form_helper
INFO - 2018-01-19 06:19:21 --> Database Driver Class Initialized
DEBUG - 2018-01-19 06:19:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 06:19:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 06:19:21 --> Form Validation Class Initialized
INFO - 2018-01-19 06:19:21 --> Model Class Initialized
INFO - 2018-01-19 06:19:21 --> Controller Class Initialized
INFO - 2018-01-19 06:19:21 --> Model Class Initialized
INFO - 2018-01-19 06:19:21 --> Model Class Initialized
INFO - 2018-01-19 06:19:21 --> Model Class Initialized
INFO - 2018-01-19 06:19:21 --> Model Class Initialized
DEBUG - 2018-01-19 06:19:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 06:19:24 --> Config Class Initialized
INFO - 2018-01-19 06:19:24 --> Hooks Class Initialized
DEBUG - 2018-01-19 06:19:24 --> UTF-8 Support Enabled
INFO - 2018-01-19 06:19:24 --> Utf8 Class Initialized
INFO - 2018-01-19 06:19:24 --> URI Class Initialized
INFO - 2018-01-19 06:19:24 --> Router Class Initialized
INFO - 2018-01-19 06:19:24 --> Output Class Initialized
INFO - 2018-01-19 06:19:24 --> Security Class Initialized
DEBUG - 2018-01-19 06:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 06:19:24 --> Input Class Initialized
INFO - 2018-01-19 06:19:24 --> Language Class Initialized
INFO - 2018-01-19 06:19:24 --> Loader Class Initialized
INFO - 2018-01-19 06:19:24 --> Helper loaded: url_helper
INFO - 2018-01-19 06:19:24 --> Helper loaded: form_helper
INFO - 2018-01-19 06:19:24 --> Database Driver Class Initialized
DEBUG - 2018-01-19 06:19:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 06:19:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 06:19:24 --> Form Validation Class Initialized
INFO - 2018-01-19 06:19:24 --> Model Class Initialized
INFO - 2018-01-19 06:19:24 --> Controller Class Initialized
INFO - 2018-01-19 06:19:24 --> Model Class Initialized
INFO - 2018-01-19 06:19:24 --> Model Class Initialized
INFO - 2018-01-19 06:19:24 --> Model Class Initialized
INFO - 2018-01-19 06:19:24 --> Model Class Initialized
DEBUG - 2018-01-19 06:19:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 06:19:24 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 06:19:24 --> Final output sent to browser
DEBUG - 2018-01-19 06:19:24 --> Total execution time: 0.0532
INFO - 2018-01-19 06:19:25 --> Config Class Initialized
INFO - 2018-01-19 06:19:25 --> Hooks Class Initialized
DEBUG - 2018-01-19 06:19:25 --> UTF-8 Support Enabled
INFO - 2018-01-19 06:19:25 --> Utf8 Class Initialized
INFO - 2018-01-19 06:19:25 --> URI Class Initialized
INFO - 2018-01-19 06:19:25 --> Router Class Initialized
INFO - 2018-01-19 06:19:25 --> Output Class Initialized
INFO - 2018-01-19 06:19:25 --> Security Class Initialized
DEBUG - 2018-01-19 06:19:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 06:19:25 --> Input Class Initialized
INFO - 2018-01-19 06:19:25 --> Language Class Initialized
INFO - 2018-01-19 06:19:25 --> Loader Class Initialized
INFO - 2018-01-19 06:19:25 --> Helper loaded: url_helper
INFO - 2018-01-19 06:19:25 --> Helper loaded: form_helper
INFO - 2018-01-19 06:19:25 --> Database Driver Class Initialized
DEBUG - 2018-01-19 06:19:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 06:19:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 06:19:25 --> Form Validation Class Initialized
INFO - 2018-01-19 06:19:25 --> Model Class Initialized
INFO - 2018-01-19 06:19:25 --> Controller Class Initialized
INFO - 2018-01-19 06:19:25 --> Model Class Initialized
INFO - 2018-01-19 06:19:25 --> Model Class Initialized
INFO - 2018-01-19 06:19:25 --> Model Class Initialized
INFO - 2018-01-19 06:19:25 --> Model Class Initialized
DEBUG - 2018-01-19 06:19:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 06:21:41 --> Config Class Initialized
INFO - 2018-01-19 06:21:41 --> Hooks Class Initialized
DEBUG - 2018-01-19 06:21:41 --> UTF-8 Support Enabled
INFO - 2018-01-19 06:21:41 --> Utf8 Class Initialized
INFO - 2018-01-19 06:21:41 --> URI Class Initialized
INFO - 2018-01-19 06:21:41 --> Router Class Initialized
INFO - 2018-01-19 06:21:41 --> Output Class Initialized
INFO - 2018-01-19 06:21:41 --> Security Class Initialized
DEBUG - 2018-01-19 06:21:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 06:21:41 --> Input Class Initialized
INFO - 2018-01-19 06:21:41 --> Language Class Initialized
INFO - 2018-01-19 06:21:41 --> Loader Class Initialized
INFO - 2018-01-19 06:21:41 --> Helper loaded: url_helper
INFO - 2018-01-19 06:21:41 --> Helper loaded: form_helper
INFO - 2018-01-19 06:21:41 --> Database Driver Class Initialized
DEBUG - 2018-01-19 06:21:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 06:21:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 06:21:41 --> Form Validation Class Initialized
INFO - 2018-01-19 06:21:41 --> Model Class Initialized
INFO - 2018-01-19 06:21:41 --> Controller Class Initialized
INFO - 2018-01-19 06:21:41 --> Model Class Initialized
INFO - 2018-01-19 06:21:41 --> Model Class Initialized
INFO - 2018-01-19 06:21:41 --> Model Class Initialized
INFO - 2018-01-19 06:21:41 --> Model Class Initialized
DEBUG - 2018-01-19 06:21:41 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-01-19 06:21:41 --> Severity: Notice --> Undefined variable: proveedores /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 85
ERROR - 2018-01-19 06:21:41 --> Severity: Warning --> Invalid argument supplied for foreach() /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 85
INFO - 2018-01-19 06:21:41 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 06:21:41 --> Final output sent to browser
DEBUG - 2018-01-19 06:21:41 --> Total execution time: 0.0641
INFO - 2018-01-19 06:21:44 --> Config Class Initialized
INFO - 2018-01-19 06:21:44 --> Hooks Class Initialized
DEBUG - 2018-01-19 06:21:44 --> UTF-8 Support Enabled
INFO - 2018-01-19 06:21:44 --> Utf8 Class Initialized
INFO - 2018-01-19 06:21:44 --> URI Class Initialized
INFO - 2018-01-19 06:21:44 --> Router Class Initialized
INFO - 2018-01-19 06:21:44 --> Output Class Initialized
INFO - 2018-01-19 06:21:44 --> Security Class Initialized
DEBUG - 2018-01-19 06:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 06:21:44 --> Input Class Initialized
INFO - 2018-01-19 06:21:44 --> Language Class Initialized
INFO - 2018-01-19 06:21:44 --> Loader Class Initialized
INFO - 2018-01-19 06:21:44 --> Helper loaded: url_helper
INFO - 2018-01-19 06:21:44 --> Helper loaded: form_helper
INFO - 2018-01-19 06:21:44 --> Database Driver Class Initialized
DEBUG - 2018-01-19 06:21:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 06:21:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 06:21:44 --> Form Validation Class Initialized
INFO - 2018-01-19 06:21:44 --> Model Class Initialized
INFO - 2018-01-19 06:21:44 --> Controller Class Initialized
INFO - 2018-01-19 06:21:44 --> Model Class Initialized
INFO - 2018-01-19 06:21:44 --> Model Class Initialized
INFO - 2018-01-19 06:21:44 --> Model Class Initialized
INFO - 2018-01-19 06:21:44 --> Model Class Initialized
DEBUG - 2018-01-19 06:21:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 06:21:55 --> Config Class Initialized
INFO - 2018-01-19 06:21:55 --> Hooks Class Initialized
DEBUG - 2018-01-19 06:21:55 --> UTF-8 Support Enabled
INFO - 2018-01-19 06:21:55 --> Utf8 Class Initialized
INFO - 2018-01-19 06:21:55 --> URI Class Initialized
INFO - 2018-01-19 06:21:55 --> Router Class Initialized
INFO - 2018-01-19 06:21:55 --> Output Class Initialized
INFO - 2018-01-19 06:21:55 --> Security Class Initialized
DEBUG - 2018-01-19 06:21:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 06:21:55 --> Input Class Initialized
INFO - 2018-01-19 06:21:55 --> Language Class Initialized
INFO - 2018-01-19 06:21:55 --> Loader Class Initialized
INFO - 2018-01-19 06:21:55 --> Helper loaded: url_helper
INFO - 2018-01-19 06:21:55 --> Helper loaded: form_helper
INFO - 2018-01-19 06:21:55 --> Database Driver Class Initialized
DEBUG - 2018-01-19 06:21:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 06:21:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 06:21:55 --> Form Validation Class Initialized
INFO - 2018-01-19 06:21:55 --> Model Class Initialized
INFO - 2018-01-19 06:21:55 --> Controller Class Initialized
INFO - 2018-01-19 06:21:55 --> Model Class Initialized
INFO - 2018-01-19 06:21:55 --> Model Class Initialized
INFO - 2018-01-19 06:21:55 --> Model Class Initialized
INFO - 2018-01-19 06:21:55 --> Model Class Initialized
DEBUG - 2018-01-19 06:21:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 06:21:55 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 06:21:55 --> Final output sent to browser
DEBUG - 2018-01-19 06:21:55 --> Total execution time: 0.0559
INFO - 2018-01-19 06:22:26 --> Config Class Initialized
INFO - 2018-01-19 06:22:26 --> Hooks Class Initialized
DEBUG - 2018-01-19 06:22:26 --> UTF-8 Support Enabled
INFO - 2018-01-19 06:22:26 --> Utf8 Class Initialized
INFO - 2018-01-19 06:22:26 --> URI Class Initialized
INFO - 2018-01-19 06:22:26 --> Router Class Initialized
INFO - 2018-01-19 06:22:26 --> Output Class Initialized
INFO - 2018-01-19 06:22:26 --> Security Class Initialized
DEBUG - 2018-01-19 06:22:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 06:22:26 --> Input Class Initialized
INFO - 2018-01-19 06:22:26 --> Language Class Initialized
INFO - 2018-01-19 06:22:26 --> Loader Class Initialized
INFO - 2018-01-19 06:22:26 --> Helper loaded: url_helper
INFO - 2018-01-19 06:22:26 --> Helper loaded: form_helper
INFO - 2018-01-19 06:22:26 --> Database Driver Class Initialized
DEBUG - 2018-01-19 06:22:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 06:22:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 06:22:26 --> Form Validation Class Initialized
INFO - 2018-01-19 06:22:26 --> Model Class Initialized
INFO - 2018-01-19 06:22:26 --> Controller Class Initialized
INFO - 2018-01-19 06:22:26 --> Model Class Initialized
INFO - 2018-01-19 06:22:26 --> Model Class Initialized
INFO - 2018-01-19 06:22:26 --> Model Class Initialized
INFO - 2018-01-19 06:22:26 --> Model Class Initialized
DEBUG - 2018-01-19 06:22:26 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-01-19 06:22:26 --> Severity: Notice --> Undefined variable: proveedores /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 85
ERROR - 2018-01-19 06:22:26 --> Severity: Warning --> Invalid argument supplied for foreach() /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/verGastosProyecto.php 85
INFO - 2018-01-19 06:22:26 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 06:22:26 --> Final output sent to browser
DEBUG - 2018-01-19 06:22:26 --> Total execution time: 0.0553
INFO - 2018-01-19 06:22:28 --> Config Class Initialized
INFO - 2018-01-19 06:22:28 --> Hooks Class Initialized
DEBUG - 2018-01-19 06:22:28 --> UTF-8 Support Enabled
INFO - 2018-01-19 06:22:28 --> Utf8 Class Initialized
INFO - 2018-01-19 06:22:28 --> URI Class Initialized
INFO - 2018-01-19 06:22:28 --> Router Class Initialized
INFO - 2018-01-19 06:22:28 --> Output Class Initialized
INFO - 2018-01-19 06:22:28 --> Security Class Initialized
DEBUG - 2018-01-19 06:22:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 06:22:28 --> Input Class Initialized
INFO - 2018-01-19 06:22:28 --> Language Class Initialized
INFO - 2018-01-19 06:22:28 --> Loader Class Initialized
INFO - 2018-01-19 06:22:28 --> Helper loaded: url_helper
INFO - 2018-01-19 06:22:28 --> Helper loaded: form_helper
INFO - 2018-01-19 06:22:28 --> Database Driver Class Initialized
DEBUG - 2018-01-19 06:22:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 06:22:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 06:22:28 --> Form Validation Class Initialized
INFO - 2018-01-19 06:22:28 --> Model Class Initialized
INFO - 2018-01-19 06:22:28 --> Controller Class Initialized
INFO - 2018-01-19 06:22:28 --> Model Class Initialized
INFO - 2018-01-19 06:22:28 --> Model Class Initialized
INFO - 2018-01-19 06:22:28 --> Model Class Initialized
INFO - 2018-01-19 06:22:28 --> Model Class Initialized
DEBUG - 2018-01-19 06:22:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 06:22:31 --> Config Class Initialized
INFO - 2018-01-19 06:22:31 --> Hooks Class Initialized
DEBUG - 2018-01-19 06:22:31 --> UTF-8 Support Enabled
INFO - 2018-01-19 06:22:31 --> Utf8 Class Initialized
INFO - 2018-01-19 06:22:31 --> URI Class Initialized
DEBUG - 2018-01-19 06:22:31 --> No URI present. Default controller set.
INFO - 2018-01-19 06:22:31 --> Router Class Initialized
INFO - 2018-01-19 06:22:31 --> Output Class Initialized
INFO - 2018-01-19 06:22:31 --> Security Class Initialized
DEBUG - 2018-01-19 06:22:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 06:22:31 --> Input Class Initialized
INFO - 2018-01-19 06:22:31 --> Language Class Initialized
INFO - 2018-01-19 06:22:31 --> Loader Class Initialized
INFO - 2018-01-19 06:22:31 --> Helper loaded: url_helper
INFO - 2018-01-19 06:22:31 --> Helper loaded: form_helper
INFO - 2018-01-19 06:22:31 --> Database Driver Class Initialized
DEBUG - 2018-01-19 06:22:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 06:22:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 06:22:31 --> Form Validation Class Initialized
INFO - 2018-01-19 06:22:31 --> Model Class Initialized
INFO - 2018-01-19 06:22:31 --> Controller Class Initialized
INFO - 2018-01-19 06:22:31 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 06:22:31 --> Final output sent to browser
DEBUG - 2018-01-19 06:22:31 --> Total execution time: 0.0347
INFO - 2018-01-19 06:22:46 --> Config Class Initialized
INFO - 2018-01-19 06:22:46 --> Hooks Class Initialized
DEBUG - 2018-01-19 06:22:46 --> UTF-8 Support Enabled
INFO - 2018-01-19 06:22:46 --> Utf8 Class Initialized
INFO - 2018-01-19 06:22:46 --> URI Class Initialized
INFO - 2018-01-19 06:22:46 --> Router Class Initialized
INFO - 2018-01-19 06:22:46 --> Output Class Initialized
INFO - 2018-01-19 06:22:46 --> Security Class Initialized
DEBUG - 2018-01-19 06:22:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 06:22:46 --> Input Class Initialized
INFO - 2018-01-19 06:22:46 --> Language Class Initialized
INFO - 2018-01-19 06:22:46 --> Loader Class Initialized
INFO - 2018-01-19 06:22:46 --> Helper loaded: url_helper
INFO - 2018-01-19 06:22:46 --> Helper loaded: form_helper
INFO - 2018-01-19 06:22:46 --> Database Driver Class Initialized
DEBUG - 2018-01-19 06:22:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 06:22:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 06:22:46 --> Form Validation Class Initialized
INFO - 2018-01-19 06:22:46 --> Model Class Initialized
INFO - 2018-01-19 06:22:46 --> Controller Class Initialized
INFO - 2018-01-19 06:22:46 --> Model Class Initialized
INFO - 2018-01-19 06:22:46 --> Model Class Initialized
DEBUG - 2018-01-19 06:22:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 06:22:46 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 06:22:46 --> Final output sent to browser
DEBUG - 2018-01-19 06:22:46 --> Total execution time: 0.0416
INFO - 2018-01-19 06:22:47 --> Config Class Initialized
INFO - 2018-01-19 06:22:47 --> Hooks Class Initialized
DEBUG - 2018-01-19 06:22:47 --> UTF-8 Support Enabled
INFO - 2018-01-19 06:22:47 --> Utf8 Class Initialized
INFO - 2018-01-19 06:22:47 --> URI Class Initialized
INFO - 2018-01-19 06:22:47 --> Router Class Initialized
INFO - 2018-01-19 06:22:47 --> Output Class Initialized
INFO - 2018-01-19 06:22:47 --> Security Class Initialized
DEBUG - 2018-01-19 06:22:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 06:22:47 --> Input Class Initialized
INFO - 2018-01-19 06:22:47 --> Language Class Initialized
INFO - 2018-01-19 06:22:47 --> Loader Class Initialized
INFO - 2018-01-19 06:22:47 --> Helper loaded: url_helper
INFO - 2018-01-19 06:22:47 --> Helper loaded: form_helper
INFO - 2018-01-19 06:22:47 --> Database Driver Class Initialized
DEBUG - 2018-01-19 06:22:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 06:22:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 06:22:47 --> Form Validation Class Initialized
INFO - 2018-01-19 06:22:47 --> Model Class Initialized
INFO - 2018-01-19 06:22:47 --> Controller Class Initialized
INFO - 2018-01-19 06:22:47 --> Model Class Initialized
INFO - 2018-01-19 06:22:47 --> Model Class Initialized
DEBUG - 2018-01-19 06:22:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 06:22:51 --> Config Class Initialized
INFO - 2018-01-19 06:22:51 --> Hooks Class Initialized
DEBUG - 2018-01-19 06:22:51 --> UTF-8 Support Enabled
INFO - 2018-01-19 06:22:51 --> Utf8 Class Initialized
INFO - 2018-01-19 06:22:51 --> URI Class Initialized
INFO - 2018-01-19 06:22:51 --> Router Class Initialized
INFO - 2018-01-19 06:22:51 --> Output Class Initialized
INFO - 2018-01-19 06:22:51 --> Security Class Initialized
DEBUG - 2018-01-19 06:22:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 06:22:51 --> Input Class Initialized
INFO - 2018-01-19 06:22:51 --> Language Class Initialized
INFO - 2018-01-19 06:22:51 --> Loader Class Initialized
INFO - 2018-01-19 06:22:51 --> Helper loaded: url_helper
INFO - 2018-01-19 06:22:51 --> Helper loaded: form_helper
INFO - 2018-01-19 06:22:52 --> Database Driver Class Initialized
DEBUG - 2018-01-19 06:22:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 06:22:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 06:22:52 --> Form Validation Class Initialized
INFO - 2018-01-19 06:22:52 --> Model Class Initialized
INFO - 2018-01-19 06:22:52 --> Controller Class Initialized
INFO - 2018-01-19 06:22:52 --> Model Class Initialized
INFO - 2018-01-19 06:22:52 --> Model Class Initialized
DEBUG - 2018-01-19 06:22:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 06:22:52 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 06:22:52 --> Final output sent to browser
DEBUG - 2018-01-19 06:22:52 --> Total execution time: 0.0394
INFO - 2018-01-19 06:23:46 --> Config Class Initialized
INFO - 2018-01-19 06:23:46 --> Hooks Class Initialized
DEBUG - 2018-01-19 06:23:46 --> UTF-8 Support Enabled
INFO - 2018-01-19 06:23:46 --> Utf8 Class Initialized
INFO - 2018-01-19 06:23:46 --> URI Class Initialized
INFO - 2018-01-19 06:23:46 --> Router Class Initialized
INFO - 2018-01-19 06:23:46 --> Output Class Initialized
INFO - 2018-01-19 06:23:46 --> Security Class Initialized
DEBUG - 2018-01-19 06:23:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 06:23:46 --> Input Class Initialized
INFO - 2018-01-19 06:23:46 --> Language Class Initialized
INFO - 2018-01-19 06:23:46 --> Loader Class Initialized
INFO - 2018-01-19 06:23:46 --> Helper loaded: url_helper
INFO - 2018-01-19 06:23:46 --> Helper loaded: form_helper
INFO - 2018-01-19 06:23:46 --> Database Driver Class Initialized
DEBUG - 2018-01-19 06:23:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 06:23:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 06:23:46 --> Form Validation Class Initialized
INFO - 2018-01-19 06:23:46 --> Model Class Initialized
INFO - 2018-01-19 06:23:46 --> Controller Class Initialized
INFO - 2018-01-19 06:23:46 --> Model Class Initialized
INFO - 2018-01-19 06:23:46 --> Model Class Initialized
DEBUG - 2018-01-19 06:23:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 06:23:46 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 06:23:46 --> Final output sent to browser
DEBUG - 2018-01-19 06:23:46 --> Total execution time: 0.0458
INFO - 2018-01-19 06:24:01 --> Config Class Initialized
INFO - 2018-01-19 06:24:01 --> Hooks Class Initialized
DEBUG - 2018-01-19 06:24:01 --> UTF-8 Support Enabled
INFO - 2018-01-19 06:24:01 --> Utf8 Class Initialized
INFO - 2018-01-19 06:24:01 --> URI Class Initialized
INFO - 2018-01-19 06:24:01 --> Router Class Initialized
INFO - 2018-01-19 06:24:01 --> Output Class Initialized
INFO - 2018-01-19 06:24:01 --> Security Class Initialized
DEBUG - 2018-01-19 06:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 06:24:01 --> Input Class Initialized
INFO - 2018-01-19 06:24:01 --> Language Class Initialized
INFO - 2018-01-19 06:24:01 --> Loader Class Initialized
INFO - 2018-01-19 06:24:01 --> Helper loaded: url_helper
INFO - 2018-01-19 06:24:01 --> Helper loaded: form_helper
INFO - 2018-01-19 06:24:01 --> Database Driver Class Initialized
DEBUG - 2018-01-19 06:24:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 06:24:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 06:24:01 --> Form Validation Class Initialized
INFO - 2018-01-19 06:24:01 --> Model Class Initialized
INFO - 2018-01-19 06:24:01 --> Controller Class Initialized
INFO - 2018-01-19 06:24:01 --> Model Class Initialized
INFO - 2018-01-19 06:24:01 --> Model Class Initialized
INFO - 2018-01-19 06:24:01 --> Model Class Initialized
INFO - 2018-01-19 06:24:01 --> Model Class Initialized
DEBUG - 2018-01-19 06:24:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 06:24:01 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 06:24:01 --> Final output sent to browser
DEBUG - 2018-01-19 06:24:01 --> Total execution time: 0.0575
INFO - 2018-01-19 06:24:04 --> Config Class Initialized
INFO - 2018-01-19 06:24:04 --> Hooks Class Initialized
DEBUG - 2018-01-19 06:24:04 --> UTF-8 Support Enabled
INFO - 2018-01-19 06:24:04 --> Utf8 Class Initialized
INFO - 2018-01-19 06:24:04 --> URI Class Initialized
INFO - 2018-01-19 06:24:04 --> Router Class Initialized
INFO - 2018-01-19 06:24:04 --> Output Class Initialized
INFO - 2018-01-19 06:24:05 --> Security Class Initialized
DEBUG - 2018-01-19 06:24:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 06:24:05 --> Input Class Initialized
INFO - 2018-01-19 06:24:05 --> Language Class Initialized
INFO - 2018-01-19 06:24:05 --> Loader Class Initialized
INFO - 2018-01-19 06:24:05 --> Helper loaded: url_helper
INFO - 2018-01-19 06:24:05 --> Helper loaded: form_helper
INFO - 2018-01-19 06:24:05 --> Database Driver Class Initialized
DEBUG - 2018-01-19 06:24:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 06:24:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 06:24:05 --> Form Validation Class Initialized
INFO - 2018-01-19 06:24:05 --> Model Class Initialized
INFO - 2018-01-19 06:24:05 --> Controller Class Initialized
INFO - 2018-01-19 06:24:05 --> Model Class Initialized
INFO - 2018-01-19 06:24:05 --> Model Class Initialized
INFO - 2018-01-19 06:24:05 --> Model Class Initialized
INFO - 2018-01-19 06:24:05 --> Model Class Initialized
DEBUG - 2018-01-19 06:24:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 06:24:09 --> Config Class Initialized
INFO - 2018-01-19 06:24:09 --> Hooks Class Initialized
DEBUG - 2018-01-19 06:24:09 --> UTF-8 Support Enabled
INFO - 2018-01-19 06:24:09 --> Utf8 Class Initialized
INFO - 2018-01-19 06:24:09 --> URI Class Initialized
INFO - 2018-01-19 06:24:09 --> Router Class Initialized
INFO - 2018-01-19 06:24:09 --> Output Class Initialized
INFO - 2018-01-19 06:24:09 --> Security Class Initialized
DEBUG - 2018-01-19 06:24:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 06:24:09 --> Input Class Initialized
INFO - 2018-01-19 06:24:09 --> Language Class Initialized
INFO - 2018-01-19 06:24:09 --> Loader Class Initialized
INFO - 2018-01-19 06:24:09 --> Helper loaded: url_helper
INFO - 2018-01-19 06:24:09 --> Helper loaded: form_helper
INFO - 2018-01-19 06:24:09 --> Database Driver Class Initialized
DEBUG - 2018-01-19 06:24:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 06:24:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 06:24:09 --> Form Validation Class Initialized
INFO - 2018-01-19 06:24:09 --> Model Class Initialized
INFO - 2018-01-19 06:24:09 --> Controller Class Initialized
INFO - 2018-01-19 06:24:09 --> Model Class Initialized
INFO - 2018-01-19 06:24:09 --> Model Class Initialized
INFO - 2018-01-19 06:24:09 --> Model Class Initialized
INFO - 2018-01-19 06:24:09 --> Model Class Initialized
DEBUG - 2018-01-19 06:24:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 06:24:09 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 06:24:09 --> Final output sent to browser
DEBUG - 2018-01-19 06:24:09 --> Total execution time: 0.0506
INFO - 2018-01-19 06:24:09 --> Config Class Initialized
INFO - 2018-01-19 06:24:09 --> Hooks Class Initialized
DEBUG - 2018-01-19 06:24:09 --> UTF-8 Support Enabled
INFO - 2018-01-19 06:24:09 --> Utf8 Class Initialized
INFO - 2018-01-19 06:24:10 --> URI Class Initialized
INFO - 2018-01-19 06:24:10 --> Router Class Initialized
INFO - 2018-01-19 06:24:10 --> Output Class Initialized
INFO - 2018-01-19 06:24:10 --> Security Class Initialized
DEBUG - 2018-01-19 06:24:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 06:24:10 --> Input Class Initialized
INFO - 2018-01-19 06:24:10 --> Language Class Initialized
INFO - 2018-01-19 06:24:10 --> Loader Class Initialized
INFO - 2018-01-19 06:24:10 --> Helper loaded: url_helper
INFO - 2018-01-19 06:24:10 --> Helper loaded: form_helper
INFO - 2018-01-19 06:24:10 --> Database Driver Class Initialized
DEBUG - 2018-01-19 06:24:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 06:24:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 06:24:10 --> Form Validation Class Initialized
INFO - 2018-01-19 06:24:10 --> Model Class Initialized
INFO - 2018-01-19 06:24:10 --> Controller Class Initialized
INFO - 2018-01-19 06:24:10 --> Model Class Initialized
INFO - 2018-01-19 06:24:10 --> Model Class Initialized
INFO - 2018-01-19 06:24:10 --> Model Class Initialized
INFO - 2018-01-19 06:24:10 --> Model Class Initialized
DEBUG - 2018-01-19 06:24:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 06:24:13 --> Config Class Initialized
INFO - 2018-01-19 06:24:13 --> Hooks Class Initialized
DEBUG - 2018-01-19 06:24:13 --> UTF-8 Support Enabled
INFO - 2018-01-19 06:24:13 --> Utf8 Class Initialized
INFO - 2018-01-19 06:24:13 --> URI Class Initialized
INFO - 2018-01-19 06:24:13 --> Router Class Initialized
INFO - 2018-01-19 06:24:13 --> Output Class Initialized
INFO - 2018-01-19 06:24:13 --> Security Class Initialized
DEBUG - 2018-01-19 06:24:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 06:24:13 --> Input Class Initialized
INFO - 2018-01-19 06:24:13 --> Language Class Initialized
INFO - 2018-01-19 06:24:13 --> Loader Class Initialized
INFO - 2018-01-19 06:24:13 --> Helper loaded: url_helper
INFO - 2018-01-19 06:24:13 --> Helper loaded: form_helper
INFO - 2018-01-19 06:24:13 --> Database Driver Class Initialized
DEBUG - 2018-01-19 06:24:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 06:24:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 06:24:13 --> Form Validation Class Initialized
INFO - 2018-01-19 06:24:13 --> Model Class Initialized
INFO - 2018-01-19 06:24:13 --> Controller Class Initialized
INFO - 2018-01-19 06:24:13 --> Model Class Initialized
INFO - 2018-01-19 06:24:13 --> Model Class Initialized
INFO - 2018-01-19 06:24:13 --> Model Class Initialized
INFO - 2018-01-19 06:24:13 --> Model Class Initialized
DEBUG - 2018-01-19 06:24:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 06:24:13 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 06:24:13 --> Final output sent to browser
DEBUG - 2018-01-19 06:24:13 --> Total execution time: 0.0531
INFO - 2018-01-19 06:24:15 --> Config Class Initialized
INFO - 2018-01-19 06:24:15 --> Hooks Class Initialized
DEBUG - 2018-01-19 06:24:15 --> UTF-8 Support Enabled
INFO - 2018-01-19 06:24:15 --> Utf8 Class Initialized
INFO - 2018-01-19 06:24:15 --> URI Class Initialized
INFO - 2018-01-19 06:24:15 --> Router Class Initialized
INFO - 2018-01-19 06:24:15 --> Output Class Initialized
INFO - 2018-01-19 06:24:15 --> Security Class Initialized
DEBUG - 2018-01-19 06:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 06:24:15 --> Input Class Initialized
INFO - 2018-01-19 06:24:15 --> Language Class Initialized
INFO - 2018-01-19 06:24:15 --> Loader Class Initialized
INFO - 2018-01-19 06:24:15 --> Helper loaded: url_helper
INFO - 2018-01-19 06:24:15 --> Helper loaded: form_helper
INFO - 2018-01-19 06:24:15 --> Database Driver Class Initialized
DEBUG - 2018-01-19 06:24:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 06:24:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 06:24:15 --> Form Validation Class Initialized
INFO - 2018-01-19 06:24:15 --> Model Class Initialized
INFO - 2018-01-19 06:24:15 --> Controller Class Initialized
INFO - 2018-01-19 06:24:15 --> Model Class Initialized
INFO - 2018-01-19 06:24:15 --> Model Class Initialized
INFO - 2018-01-19 06:24:15 --> Model Class Initialized
INFO - 2018-01-19 06:24:15 --> Model Class Initialized
DEBUG - 2018-01-19 06:24:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 06:24:21 --> Config Class Initialized
INFO - 2018-01-19 06:24:21 --> Hooks Class Initialized
DEBUG - 2018-01-19 06:24:21 --> UTF-8 Support Enabled
INFO - 2018-01-19 06:24:21 --> Utf8 Class Initialized
INFO - 2018-01-19 06:24:21 --> URI Class Initialized
INFO - 2018-01-19 06:24:21 --> Router Class Initialized
INFO - 2018-01-19 06:24:21 --> Output Class Initialized
INFO - 2018-01-19 06:24:21 --> Security Class Initialized
DEBUG - 2018-01-19 06:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 06:24:21 --> Input Class Initialized
INFO - 2018-01-19 06:24:21 --> Language Class Initialized
INFO - 2018-01-19 06:24:21 --> Loader Class Initialized
INFO - 2018-01-19 06:24:21 --> Helper loaded: url_helper
INFO - 2018-01-19 06:24:21 --> Helper loaded: form_helper
INFO - 2018-01-19 06:24:21 --> Database Driver Class Initialized
DEBUG - 2018-01-19 06:24:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 06:24:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 06:24:21 --> Form Validation Class Initialized
INFO - 2018-01-19 06:24:21 --> Model Class Initialized
INFO - 2018-01-19 06:24:21 --> Controller Class Initialized
INFO - 2018-01-19 06:24:21 --> Model Class Initialized
INFO - 2018-01-19 06:24:21 --> Model Class Initialized
INFO - 2018-01-19 06:24:21 --> Model Class Initialized
INFO - 2018-01-19 06:24:21 --> Model Class Initialized
DEBUG - 2018-01-19 06:24:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 06:24:21 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 06:24:21 --> Final output sent to browser
DEBUG - 2018-01-19 06:24:21 --> Total execution time: 0.0510
INFO - 2018-01-19 06:24:59 --> Config Class Initialized
INFO - 2018-01-19 06:24:59 --> Hooks Class Initialized
DEBUG - 2018-01-19 06:24:59 --> UTF-8 Support Enabled
INFO - 2018-01-19 06:24:59 --> Utf8 Class Initialized
INFO - 2018-01-19 06:24:59 --> URI Class Initialized
INFO - 2018-01-19 06:24:59 --> Router Class Initialized
INFO - 2018-01-19 06:24:59 --> Output Class Initialized
INFO - 2018-01-19 06:24:59 --> Security Class Initialized
DEBUG - 2018-01-19 06:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 06:24:59 --> Input Class Initialized
INFO - 2018-01-19 06:24:59 --> Language Class Initialized
INFO - 2018-01-19 06:24:59 --> Loader Class Initialized
INFO - 2018-01-19 06:24:59 --> Helper loaded: url_helper
INFO - 2018-01-19 06:24:59 --> Helper loaded: form_helper
INFO - 2018-01-19 06:24:59 --> Database Driver Class Initialized
DEBUG - 2018-01-19 06:24:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 06:24:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 06:24:59 --> Form Validation Class Initialized
INFO - 2018-01-19 06:24:59 --> Model Class Initialized
INFO - 2018-01-19 06:24:59 --> Controller Class Initialized
INFO - 2018-01-19 06:24:59 --> Model Class Initialized
INFO - 2018-01-19 06:24:59 --> Model Class Initialized
INFO - 2018-01-19 06:24:59 --> Model Class Initialized
INFO - 2018-01-19 06:24:59 --> Model Class Initialized
DEBUG - 2018-01-19 06:24:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 06:24:59 --> Config Class Initialized
INFO - 2018-01-19 06:24:59 --> Hooks Class Initialized
DEBUG - 2018-01-19 06:24:59 --> UTF-8 Support Enabled
INFO - 2018-01-19 06:24:59 --> Utf8 Class Initialized
INFO - 2018-01-19 06:24:59 --> URI Class Initialized
INFO - 2018-01-19 06:24:59 --> Router Class Initialized
INFO - 2018-01-19 06:24:59 --> Output Class Initialized
INFO - 2018-01-19 06:24:59 --> Security Class Initialized
DEBUG - 2018-01-19 06:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 06:24:59 --> Input Class Initialized
INFO - 2018-01-19 06:24:59 --> Language Class Initialized
INFO - 2018-01-19 06:24:59 --> Loader Class Initialized
INFO - 2018-01-19 06:24:59 --> Helper loaded: url_helper
INFO - 2018-01-19 06:24:59 --> Helper loaded: form_helper
INFO - 2018-01-19 06:24:59 --> Database Driver Class Initialized
DEBUG - 2018-01-19 06:24:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 06:24:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 06:24:59 --> Form Validation Class Initialized
INFO - 2018-01-19 06:24:59 --> Model Class Initialized
INFO - 2018-01-19 06:24:59 --> Controller Class Initialized
INFO - 2018-01-19 06:24:59 --> Model Class Initialized
INFO - 2018-01-19 06:24:59 --> Model Class Initialized
INFO - 2018-01-19 06:24:59 --> Model Class Initialized
INFO - 2018-01-19 06:24:59 --> Model Class Initialized
DEBUG - 2018-01-19 06:24:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 06:24:59 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 06:24:59 --> Final output sent to browser
DEBUG - 2018-01-19 06:24:59 --> Total execution time: 0.0497
INFO - 2018-01-19 06:25:01 --> Config Class Initialized
INFO - 2018-01-19 06:25:01 --> Hooks Class Initialized
DEBUG - 2018-01-19 06:25:01 --> UTF-8 Support Enabled
INFO - 2018-01-19 06:25:01 --> Utf8 Class Initialized
INFO - 2018-01-19 06:25:01 --> URI Class Initialized
INFO - 2018-01-19 06:25:01 --> Router Class Initialized
INFO - 2018-01-19 06:25:01 --> Output Class Initialized
INFO - 2018-01-19 06:25:01 --> Security Class Initialized
DEBUG - 2018-01-19 06:25:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 06:25:01 --> Input Class Initialized
INFO - 2018-01-19 06:25:01 --> Language Class Initialized
INFO - 2018-01-19 06:25:01 --> Loader Class Initialized
INFO - 2018-01-19 06:25:01 --> Helper loaded: url_helper
INFO - 2018-01-19 06:25:01 --> Helper loaded: form_helper
INFO - 2018-01-19 06:25:01 --> Database Driver Class Initialized
DEBUG - 2018-01-19 06:25:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 06:25:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 06:25:01 --> Form Validation Class Initialized
INFO - 2018-01-19 06:25:01 --> Model Class Initialized
INFO - 2018-01-19 06:25:01 --> Controller Class Initialized
INFO - 2018-01-19 06:25:01 --> Model Class Initialized
INFO - 2018-01-19 06:25:01 --> Model Class Initialized
INFO - 2018-01-19 06:25:01 --> Model Class Initialized
INFO - 2018-01-19 06:25:01 --> Model Class Initialized
DEBUG - 2018-01-19 06:25:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 06:25:08 --> Config Class Initialized
INFO - 2018-01-19 06:25:08 --> Hooks Class Initialized
DEBUG - 2018-01-19 06:25:08 --> UTF-8 Support Enabled
INFO - 2018-01-19 06:25:08 --> Utf8 Class Initialized
INFO - 2018-01-19 06:25:08 --> URI Class Initialized
INFO - 2018-01-19 06:25:08 --> Router Class Initialized
INFO - 2018-01-19 06:25:08 --> Output Class Initialized
INFO - 2018-01-19 06:25:08 --> Security Class Initialized
DEBUG - 2018-01-19 06:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 06:25:08 --> Input Class Initialized
INFO - 2018-01-19 06:25:08 --> Language Class Initialized
INFO - 2018-01-19 06:25:08 --> Loader Class Initialized
INFO - 2018-01-19 06:25:08 --> Helper loaded: url_helper
INFO - 2018-01-19 06:25:08 --> Helper loaded: form_helper
INFO - 2018-01-19 06:25:08 --> Database Driver Class Initialized
DEBUG - 2018-01-19 06:25:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 06:25:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 06:25:08 --> Form Validation Class Initialized
INFO - 2018-01-19 06:25:08 --> Model Class Initialized
INFO - 2018-01-19 06:25:08 --> Controller Class Initialized
INFO - 2018-01-19 06:25:08 --> Model Class Initialized
INFO - 2018-01-19 06:25:08 --> Model Class Initialized
INFO - 2018-01-19 06:25:08 --> Model Class Initialized
INFO - 2018-01-19 06:25:08 --> Model Class Initialized
DEBUG - 2018-01-19 06:25:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 06:25:08 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 06:25:08 --> Final output sent to browser
DEBUG - 2018-01-19 06:25:08 --> Total execution time: 0.0518
INFO - 2018-01-19 06:25:09 --> Config Class Initialized
INFO - 2018-01-19 06:25:09 --> Hooks Class Initialized
DEBUG - 2018-01-19 06:25:09 --> UTF-8 Support Enabled
INFO - 2018-01-19 06:25:09 --> Utf8 Class Initialized
INFO - 2018-01-19 06:25:09 --> URI Class Initialized
INFO - 2018-01-19 06:25:09 --> Router Class Initialized
INFO - 2018-01-19 06:25:09 --> Output Class Initialized
INFO - 2018-01-19 06:25:09 --> Security Class Initialized
DEBUG - 2018-01-19 06:25:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 06:25:09 --> Input Class Initialized
INFO - 2018-01-19 06:25:09 --> Language Class Initialized
INFO - 2018-01-19 06:25:09 --> Loader Class Initialized
INFO - 2018-01-19 06:25:09 --> Helper loaded: url_helper
INFO - 2018-01-19 06:25:09 --> Helper loaded: form_helper
INFO - 2018-01-19 06:25:09 --> Database Driver Class Initialized
DEBUG - 2018-01-19 06:25:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 06:25:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 06:25:09 --> Form Validation Class Initialized
INFO - 2018-01-19 06:25:09 --> Model Class Initialized
INFO - 2018-01-19 06:25:09 --> Controller Class Initialized
INFO - 2018-01-19 06:25:09 --> Model Class Initialized
INFO - 2018-01-19 06:25:09 --> Model Class Initialized
INFO - 2018-01-19 06:25:09 --> Model Class Initialized
INFO - 2018-01-19 06:25:09 --> Model Class Initialized
DEBUG - 2018-01-19 06:25:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 06:25:58 --> Config Class Initialized
INFO - 2018-01-19 06:25:58 --> Hooks Class Initialized
DEBUG - 2018-01-19 06:25:58 --> UTF-8 Support Enabled
INFO - 2018-01-19 06:25:58 --> Utf8 Class Initialized
INFO - 2018-01-19 06:25:58 --> URI Class Initialized
INFO - 2018-01-19 06:25:58 --> Router Class Initialized
INFO - 2018-01-19 06:25:58 --> Output Class Initialized
INFO - 2018-01-19 06:25:58 --> Security Class Initialized
DEBUG - 2018-01-19 06:25:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 06:25:58 --> Input Class Initialized
INFO - 2018-01-19 06:25:58 --> Language Class Initialized
INFO - 2018-01-19 06:25:58 --> Loader Class Initialized
INFO - 2018-01-19 06:25:58 --> Helper loaded: url_helper
INFO - 2018-01-19 06:25:58 --> Helper loaded: form_helper
INFO - 2018-01-19 06:25:58 --> Database Driver Class Initialized
DEBUG - 2018-01-19 06:25:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 06:25:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 06:25:58 --> Form Validation Class Initialized
INFO - 2018-01-19 06:25:58 --> Model Class Initialized
INFO - 2018-01-19 06:25:58 --> Controller Class Initialized
INFO - 2018-01-19 06:25:58 --> Model Class Initialized
DEBUG - 2018-01-19 06:25:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 06:25:59 --> Config Class Initialized
INFO - 2018-01-19 06:25:59 --> Hooks Class Initialized
DEBUG - 2018-01-19 06:25:59 --> UTF-8 Support Enabled
INFO - 2018-01-19 06:25:59 --> Utf8 Class Initialized
INFO - 2018-01-19 06:25:59 --> URI Class Initialized
INFO - 2018-01-19 06:25:59 --> Router Class Initialized
INFO - 2018-01-19 06:25:59 --> Output Class Initialized
INFO - 2018-01-19 06:25:59 --> Security Class Initialized
DEBUG - 2018-01-19 06:25:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 06:25:59 --> Input Class Initialized
INFO - 2018-01-19 06:25:59 --> Language Class Initialized
INFO - 2018-01-19 06:25:59 --> Loader Class Initialized
INFO - 2018-01-19 06:25:59 --> Helper loaded: url_helper
INFO - 2018-01-19 06:25:59 --> Helper loaded: form_helper
INFO - 2018-01-19 06:25:59 --> Database Driver Class Initialized
DEBUG - 2018-01-19 06:25:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 06:25:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 06:25:59 --> Form Validation Class Initialized
INFO - 2018-01-19 06:25:59 --> Model Class Initialized
INFO - 2018-01-19 06:25:59 --> Controller Class Initialized
INFO - 2018-01-19 06:25:59 --> Model Class Initialized
DEBUG - 2018-01-19 06:25:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 06:25:59 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 06:25:59 --> Final output sent to browser
DEBUG - 2018-01-19 06:25:59 --> Total execution time: 0.0339
INFO - 2018-01-19 06:28:56 --> Config Class Initialized
INFO - 2018-01-19 06:28:56 --> Hooks Class Initialized
DEBUG - 2018-01-19 06:28:56 --> UTF-8 Support Enabled
INFO - 2018-01-19 06:28:56 --> Utf8 Class Initialized
INFO - 2018-01-19 06:28:56 --> URI Class Initialized
DEBUG - 2018-01-19 06:28:56 --> No URI present. Default controller set.
INFO - 2018-01-19 06:28:56 --> Router Class Initialized
INFO - 2018-01-19 06:28:56 --> Output Class Initialized
INFO - 2018-01-19 06:28:56 --> Security Class Initialized
DEBUG - 2018-01-19 06:28:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 06:28:56 --> Input Class Initialized
INFO - 2018-01-19 06:28:56 --> Language Class Initialized
INFO - 2018-01-19 06:28:56 --> Loader Class Initialized
INFO - 2018-01-19 06:28:56 --> Helper loaded: url_helper
INFO - 2018-01-19 06:28:56 --> Helper loaded: form_helper
INFO - 2018-01-19 06:28:56 --> Database Driver Class Initialized
DEBUG - 2018-01-19 06:28:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 06:28:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 06:28:56 --> Form Validation Class Initialized
INFO - 2018-01-19 06:28:56 --> Model Class Initialized
INFO - 2018-01-19 06:28:56 --> Controller Class Initialized
INFO - 2018-01-19 06:28:57 --> Config Class Initialized
INFO - 2018-01-19 06:28:57 --> Hooks Class Initialized
DEBUG - 2018-01-19 06:28:57 --> UTF-8 Support Enabled
INFO - 2018-01-19 06:28:57 --> Utf8 Class Initialized
INFO - 2018-01-19 06:28:57 --> URI Class Initialized
INFO - 2018-01-19 06:28:57 --> Router Class Initialized
INFO - 2018-01-19 06:28:57 --> Output Class Initialized
INFO - 2018-01-19 06:28:57 --> Security Class Initialized
DEBUG - 2018-01-19 06:28:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 06:28:57 --> Input Class Initialized
INFO - 2018-01-19 06:28:57 --> Language Class Initialized
INFO - 2018-01-19 06:28:57 --> Loader Class Initialized
INFO - 2018-01-19 06:28:57 --> Helper loaded: url_helper
INFO - 2018-01-19 06:28:57 --> Helper loaded: form_helper
INFO - 2018-01-19 06:28:57 --> Database Driver Class Initialized
DEBUG - 2018-01-19 06:28:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 06:28:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 06:28:57 --> Form Validation Class Initialized
INFO - 2018-01-19 06:28:57 --> Model Class Initialized
INFO - 2018-01-19 06:28:57 --> Controller Class Initialized
INFO - 2018-01-19 06:28:57 --> Model Class Initialized
DEBUG - 2018-01-19 06:28:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 06:28:57 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 06:28:57 --> Final output sent to browser
DEBUG - 2018-01-19 06:28:57 --> Total execution time: 0.0375
INFO - 2018-01-19 06:29:22 --> Config Class Initialized
INFO - 2018-01-19 06:29:22 --> Hooks Class Initialized
DEBUG - 2018-01-19 06:29:22 --> UTF-8 Support Enabled
INFO - 2018-01-19 06:29:22 --> Utf8 Class Initialized
INFO - 2018-01-19 06:29:22 --> URI Class Initialized
INFO - 2018-01-19 06:29:22 --> Router Class Initialized
INFO - 2018-01-19 06:29:22 --> Output Class Initialized
INFO - 2018-01-19 06:29:22 --> Security Class Initialized
DEBUG - 2018-01-19 06:29:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 06:29:22 --> Input Class Initialized
INFO - 2018-01-19 06:29:22 --> Language Class Initialized
INFO - 2018-01-19 06:29:22 --> Loader Class Initialized
INFO - 2018-01-19 06:29:22 --> Helper loaded: url_helper
INFO - 2018-01-19 06:29:22 --> Helper loaded: form_helper
INFO - 2018-01-19 06:29:22 --> Database Driver Class Initialized
DEBUG - 2018-01-19 06:29:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 06:29:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 06:29:22 --> Form Validation Class Initialized
INFO - 2018-01-19 06:29:22 --> Model Class Initialized
INFO - 2018-01-19 06:29:22 --> Controller Class Initialized
INFO - 2018-01-19 06:29:22 --> Model Class Initialized
DEBUG - 2018-01-19 06:29:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 06:29:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-01-19 06:29:22 --> Config Class Initialized
INFO - 2018-01-19 06:29:22 --> Hooks Class Initialized
DEBUG - 2018-01-19 06:29:22 --> UTF-8 Support Enabled
INFO - 2018-01-19 06:29:22 --> Utf8 Class Initialized
INFO - 2018-01-19 06:29:22 --> URI Class Initialized
DEBUG - 2018-01-19 06:29:22 --> No URI present. Default controller set.
INFO - 2018-01-19 06:29:22 --> Router Class Initialized
INFO - 2018-01-19 06:29:22 --> Output Class Initialized
INFO - 2018-01-19 06:29:22 --> Security Class Initialized
DEBUG - 2018-01-19 06:29:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 06:29:22 --> Input Class Initialized
INFO - 2018-01-19 06:29:22 --> Language Class Initialized
INFO - 2018-01-19 06:29:22 --> Loader Class Initialized
INFO - 2018-01-19 06:29:22 --> Helper loaded: url_helper
INFO - 2018-01-19 06:29:22 --> Helper loaded: form_helper
INFO - 2018-01-19 06:29:22 --> Database Driver Class Initialized
DEBUG - 2018-01-19 06:29:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 06:29:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 06:29:22 --> Form Validation Class Initialized
INFO - 2018-01-19 06:29:22 --> Model Class Initialized
INFO - 2018-01-19 06:29:22 --> Controller Class Initialized
INFO - 2018-01-19 06:29:22 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 06:29:22 --> Final output sent to browser
DEBUG - 2018-01-19 06:29:22 --> Total execution time: 0.0365
INFO - 2018-01-19 06:29:27 --> Config Class Initialized
INFO - 2018-01-19 06:29:27 --> Hooks Class Initialized
DEBUG - 2018-01-19 06:29:27 --> UTF-8 Support Enabled
INFO - 2018-01-19 06:29:27 --> Utf8 Class Initialized
INFO - 2018-01-19 06:29:27 --> URI Class Initialized
INFO - 2018-01-19 06:29:27 --> Router Class Initialized
INFO - 2018-01-19 06:29:27 --> Output Class Initialized
INFO - 2018-01-19 06:29:27 --> Security Class Initialized
DEBUG - 2018-01-19 06:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 06:29:27 --> Input Class Initialized
INFO - 2018-01-19 06:29:27 --> Language Class Initialized
INFO - 2018-01-19 06:29:27 --> Loader Class Initialized
INFO - 2018-01-19 06:29:27 --> Helper loaded: url_helper
INFO - 2018-01-19 06:29:27 --> Helper loaded: form_helper
INFO - 2018-01-19 06:29:27 --> Database Driver Class Initialized
DEBUG - 2018-01-19 06:29:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 06:29:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 06:29:27 --> Form Validation Class Initialized
INFO - 2018-01-19 06:29:27 --> Model Class Initialized
INFO - 2018-01-19 06:29:27 --> Controller Class Initialized
INFO - 2018-01-19 06:29:27 --> Model Class Initialized
INFO - 2018-01-19 06:29:27 --> Model Class Initialized
INFO - 2018-01-19 06:29:27 --> Model Class Initialized
INFO - 2018-01-19 06:29:27 --> Model Class Initialized
DEBUG - 2018-01-19 06:29:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 06:29:27 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 06:29:27 --> Final output sent to browser
DEBUG - 2018-01-19 06:29:27 --> Total execution time: 0.0603
INFO - 2018-01-19 06:29:28 --> Config Class Initialized
INFO - 2018-01-19 06:29:28 --> Hooks Class Initialized
DEBUG - 2018-01-19 06:29:28 --> UTF-8 Support Enabled
INFO - 2018-01-19 06:29:28 --> Utf8 Class Initialized
INFO - 2018-01-19 06:29:28 --> URI Class Initialized
INFO - 2018-01-19 06:29:28 --> Router Class Initialized
INFO - 2018-01-19 06:29:28 --> Output Class Initialized
INFO - 2018-01-19 06:29:28 --> Security Class Initialized
DEBUG - 2018-01-19 06:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 06:29:28 --> Input Class Initialized
INFO - 2018-01-19 06:29:28 --> Language Class Initialized
INFO - 2018-01-19 06:29:28 --> Loader Class Initialized
INFO - 2018-01-19 06:29:28 --> Helper loaded: url_helper
INFO - 2018-01-19 06:29:28 --> Helper loaded: form_helper
INFO - 2018-01-19 06:29:28 --> Database Driver Class Initialized
DEBUG - 2018-01-19 06:29:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 06:29:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 06:29:28 --> Form Validation Class Initialized
INFO - 2018-01-19 06:29:28 --> Model Class Initialized
INFO - 2018-01-19 06:29:28 --> Controller Class Initialized
INFO - 2018-01-19 06:29:28 --> Model Class Initialized
INFO - 2018-01-19 06:29:28 --> Model Class Initialized
INFO - 2018-01-19 06:29:28 --> Model Class Initialized
INFO - 2018-01-19 06:29:28 --> Model Class Initialized
DEBUG - 2018-01-19 06:29:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 06:31:21 --> Config Class Initialized
INFO - 2018-01-19 06:31:21 --> Hooks Class Initialized
DEBUG - 2018-01-19 06:31:21 --> UTF-8 Support Enabled
INFO - 2018-01-19 06:31:21 --> Utf8 Class Initialized
INFO - 2018-01-19 06:31:21 --> URI Class Initialized
INFO - 2018-01-19 06:31:21 --> Router Class Initialized
INFO - 2018-01-19 06:31:21 --> Output Class Initialized
INFO - 2018-01-19 06:31:21 --> Security Class Initialized
DEBUG - 2018-01-19 06:31:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 06:31:21 --> Input Class Initialized
INFO - 2018-01-19 06:31:21 --> Language Class Initialized
INFO - 2018-01-19 06:31:21 --> Loader Class Initialized
INFO - 2018-01-19 06:31:21 --> Helper loaded: url_helper
INFO - 2018-01-19 06:31:21 --> Helper loaded: form_helper
INFO - 2018-01-19 06:31:21 --> Database Driver Class Initialized
DEBUG - 2018-01-19 06:31:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 06:31:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 06:31:21 --> Form Validation Class Initialized
INFO - 2018-01-19 06:31:21 --> Model Class Initialized
INFO - 2018-01-19 06:31:21 --> Controller Class Initialized
INFO - 2018-01-19 06:31:21 --> Model Class Initialized
INFO - 2018-01-19 06:31:21 --> Model Class Initialized
INFO - 2018-01-19 06:31:21 --> Model Class Initialized
INFO - 2018-01-19 06:31:21 --> Model Class Initialized
DEBUG - 2018-01-19 06:31:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 06:31:27 --> Config Class Initialized
INFO - 2018-01-19 06:31:27 --> Hooks Class Initialized
DEBUG - 2018-01-19 06:31:27 --> UTF-8 Support Enabled
INFO - 2018-01-19 06:31:27 --> Utf8 Class Initialized
INFO - 2018-01-19 06:31:27 --> URI Class Initialized
INFO - 2018-01-19 06:31:27 --> Router Class Initialized
INFO - 2018-01-19 06:31:27 --> Output Class Initialized
INFO - 2018-01-19 06:31:27 --> Security Class Initialized
DEBUG - 2018-01-19 06:31:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 06:31:27 --> Input Class Initialized
INFO - 2018-01-19 06:31:27 --> Language Class Initialized
INFO - 2018-01-19 06:31:27 --> Loader Class Initialized
INFO - 2018-01-19 06:31:27 --> Helper loaded: url_helper
INFO - 2018-01-19 06:31:27 --> Helper loaded: form_helper
INFO - 2018-01-19 06:31:27 --> Database Driver Class Initialized
DEBUG - 2018-01-19 06:31:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 06:31:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 06:31:27 --> Form Validation Class Initialized
INFO - 2018-01-19 06:31:27 --> Model Class Initialized
INFO - 2018-01-19 06:31:27 --> Controller Class Initialized
INFO - 2018-01-19 06:31:27 --> Model Class Initialized
INFO - 2018-01-19 06:31:27 --> Model Class Initialized
INFO - 2018-01-19 06:31:27 --> Model Class Initialized
INFO - 2018-01-19 06:31:27 --> Model Class Initialized
DEBUG - 2018-01-19 06:31:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 06:31:27 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 06:31:27 --> Final output sent to browser
DEBUG - 2018-01-19 06:31:27 --> Total execution time: 0.0447
INFO - 2018-01-19 06:31:28 --> Config Class Initialized
INFO - 2018-01-19 06:31:28 --> Hooks Class Initialized
DEBUG - 2018-01-19 06:31:28 --> UTF-8 Support Enabled
INFO - 2018-01-19 06:31:28 --> Utf8 Class Initialized
INFO - 2018-01-19 06:31:28 --> URI Class Initialized
INFO - 2018-01-19 06:31:28 --> Router Class Initialized
INFO - 2018-01-19 06:31:28 --> Output Class Initialized
INFO - 2018-01-19 06:31:28 --> Security Class Initialized
DEBUG - 2018-01-19 06:31:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 06:31:28 --> Input Class Initialized
INFO - 2018-01-19 06:31:28 --> Language Class Initialized
INFO - 2018-01-19 06:31:28 --> Loader Class Initialized
INFO - 2018-01-19 06:31:28 --> Helper loaded: url_helper
INFO - 2018-01-19 06:31:28 --> Helper loaded: form_helper
INFO - 2018-01-19 06:31:28 --> Database Driver Class Initialized
DEBUG - 2018-01-19 06:31:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 06:31:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 06:31:28 --> Form Validation Class Initialized
INFO - 2018-01-19 06:31:28 --> Model Class Initialized
INFO - 2018-01-19 06:31:28 --> Controller Class Initialized
INFO - 2018-01-19 06:31:28 --> Model Class Initialized
INFO - 2018-01-19 06:31:28 --> Model Class Initialized
INFO - 2018-01-19 06:31:28 --> Model Class Initialized
INFO - 2018-01-19 06:31:28 --> Model Class Initialized
DEBUG - 2018-01-19 06:31:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 06:31:32 --> Config Class Initialized
INFO - 2018-01-19 06:31:32 --> Hooks Class Initialized
DEBUG - 2018-01-19 06:31:32 --> UTF-8 Support Enabled
INFO - 2018-01-19 06:31:32 --> Utf8 Class Initialized
INFO - 2018-01-19 06:31:32 --> URI Class Initialized
INFO - 2018-01-19 06:31:32 --> Router Class Initialized
INFO - 2018-01-19 06:31:32 --> Output Class Initialized
INFO - 2018-01-19 06:31:32 --> Security Class Initialized
DEBUG - 2018-01-19 06:31:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 06:31:32 --> Input Class Initialized
INFO - 2018-01-19 06:31:32 --> Language Class Initialized
INFO - 2018-01-19 06:31:32 --> Loader Class Initialized
INFO - 2018-01-19 06:31:32 --> Helper loaded: url_helper
INFO - 2018-01-19 06:31:32 --> Helper loaded: form_helper
INFO - 2018-01-19 06:31:32 --> Database Driver Class Initialized
DEBUG - 2018-01-19 06:31:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 06:31:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 06:31:32 --> Form Validation Class Initialized
INFO - 2018-01-19 06:31:32 --> Model Class Initialized
INFO - 2018-01-19 06:31:32 --> Controller Class Initialized
INFO - 2018-01-19 06:31:32 --> Model Class Initialized
INFO - 2018-01-19 06:31:32 --> Model Class Initialized
INFO - 2018-01-19 06:31:32 --> Model Class Initialized
INFO - 2018-01-19 06:31:32 --> Model Class Initialized
DEBUG - 2018-01-19 06:31:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 06:31:32 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 06:31:32 --> Final output sent to browser
DEBUG - 2018-01-19 06:31:32 --> Total execution time: 0.0646
INFO - 2018-01-19 06:31:33 --> Config Class Initialized
INFO - 2018-01-19 06:31:33 --> Hooks Class Initialized
DEBUG - 2018-01-19 06:31:33 --> UTF-8 Support Enabled
INFO - 2018-01-19 06:31:33 --> Utf8 Class Initialized
INFO - 2018-01-19 06:31:33 --> URI Class Initialized
INFO - 2018-01-19 06:31:33 --> Router Class Initialized
INFO - 2018-01-19 06:31:33 --> Output Class Initialized
INFO - 2018-01-19 06:31:33 --> Security Class Initialized
DEBUG - 2018-01-19 06:31:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 06:31:33 --> Input Class Initialized
INFO - 2018-01-19 06:31:33 --> Language Class Initialized
INFO - 2018-01-19 06:31:33 --> Loader Class Initialized
INFO - 2018-01-19 06:31:33 --> Helper loaded: url_helper
INFO - 2018-01-19 06:31:33 --> Helper loaded: form_helper
INFO - 2018-01-19 06:31:33 --> Database Driver Class Initialized
DEBUG - 2018-01-19 06:31:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 06:31:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 06:31:33 --> Form Validation Class Initialized
INFO - 2018-01-19 06:31:33 --> Model Class Initialized
INFO - 2018-01-19 06:31:33 --> Controller Class Initialized
INFO - 2018-01-19 06:31:33 --> Model Class Initialized
INFO - 2018-01-19 06:31:33 --> Model Class Initialized
INFO - 2018-01-19 06:31:33 --> Model Class Initialized
INFO - 2018-01-19 06:31:33 --> Model Class Initialized
DEBUG - 2018-01-19 06:31:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 06:31:45 --> Config Class Initialized
INFO - 2018-01-19 06:31:45 --> Hooks Class Initialized
DEBUG - 2018-01-19 06:31:45 --> UTF-8 Support Enabled
INFO - 2018-01-19 06:31:45 --> Utf8 Class Initialized
INFO - 2018-01-19 06:31:45 --> URI Class Initialized
INFO - 2018-01-19 06:31:45 --> Router Class Initialized
INFO - 2018-01-19 06:31:45 --> Output Class Initialized
INFO - 2018-01-19 06:31:45 --> Security Class Initialized
DEBUG - 2018-01-19 06:31:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 06:31:45 --> Input Class Initialized
INFO - 2018-01-19 06:31:45 --> Language Class Initialized
INFO - 2018-01-19 06:31:45 --> Loader Class Initialized
INFO - 2018-01-19 06:31:45 --> Helper loaded: url_helper
INFO - 2018-01-19 06:31:45 --> Helper loaded: form_helper
INFO - 2018-01-19 06:31:45 --> Database Driver Class Initialized
DEBUG - 2018-01-19 06:31:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 06:31:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 06:31:45 --> Form Validation Class Initialized
INFO - 2018-01-19 06:31:45 --> Model Class Initialized
INFO - 2018-01-19 06:31:45 --> Controller Class Initialized
INFO - 2018-01-19 06:31:45 --> Model Class Initialized
INFO - 2018-01-19 06:31:45 --> Model Class Initialized
INFO - 2018-01-19 06:31:45 --> Model Class Initialized
INFO - 2018-01-19 06:31:45 --> Model Class Initialized
DEBUG - 2018-01-19 06:31:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 06:31:45 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 06:31:45 --> Final output sent to browser
DEBUG - 2018-01-19 06:31:45 --> Total execution time: 0.0523
INFO - 2018-01-19 06:31:45 --> Config Class Initialized
INFO - 2018-01-19 06:31:45 --> Hooks Class Initialized
DEBUG - 2018-01-19 06:31:45 --> UTF-8 Support Enabled
INFO - 2018-01-19 06:31:45 --> Utf8 Class Initialized
INFO - 2018-01-19 06:31:45 --> URI Class Initialized
INFO - 2018-01-19 06:31:45 --> Router Class Initialized
INFO - 2018-01-19 06:31:45 --> Output Class Initialized
INFO - 2018-01-19 06:31:45 --> Security Class Initialized
DEBUG - 2018-01-19 06:31:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 06:31:45 --> Input Class Initialized
INFO - 2018-01-19 06:31:45 --> Language Class Initialized
INFO - 2018-01-19 06:31:45 --> Loader Class Initialized
INFO - 2018-01-19 06:31:45 --> Helper loaded: url_helper
INFO - 2018-01-19 06:31:45 --> Helper loaded: form_helper
INFO - 2018-01-19 06:31:45 --> Database Driver Class Initialized
DEBUG - 2018-01-19 06:31:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 06:31:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 06:31:45 --> Form Validation Class Initialized
INFO - 2018-01-19 06:31:45 --> Model Class Initialized
INFO - 2018-01-19 06:31:45 --> Controller Class Initialized
INFO - 2018-01-19 06:31:45 --> Model Class Initialized
INFO - 2018-01-19 06:31:45 --> Model Class Initialized
INFO - 2018-01-19 06:31:45 --> Model Class Initialized
INFO - 2018-01-19 06:31:45 --> Model Class Initialized
DEBUG - 2018-01-19 06:31:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 06:31:52 --> Config Class Initialized
INFO - 2018-01-19 06:31:52 --> Hooks Class Initialized
DEBUG - 2018-01-19 06:31:52 --> UTF-8 Support Enabled
INFO - 2018-01-19 06:31:52 --> Utf8 Class Initialized
INFO - 2018-01-19 06:31:52 --> URI Class Initialized
INFO - 2018-01-19 06:31:52 --> Router Class Initialized
INFO - 2018-01-19 06:31:52 --> Output Class Initialized
INFO - 2018-01-19 06:31:52 --> Security Class Initialized
DEBUG - 2018-01-19 06:31:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 06:31:52 --> Input Class Initialized
INFO - 2018-01-19 06:31:52 --> Language Class Initialized
INFO - 2018-01-19 06:31:52 --> Loader Class Initialized
INFO - 2018-01-19 06:31:52 --> Helper loaded: url_helper
INFO - 2018-01-19 06:31:52 --> Helper loaded: form_helper
INFO - 2018-01-19 06:31:52 --> Database Driver Class Initialized
DEBUG - 2018-01-19 06:31:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 06:31:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 06:31:52 --> Form Validation Class Initialized
INFO - 2018-01-19 06:31:52 --> Model Class Initialized
INFO - 2018-01-19 06:31:52 --> Controller Class Initialized
INFO - 2018-01-19 06:31:52 --> Model Class Initialized
INFO - 2018-01-19 06:31:52 --> Model Class Initialized
INFO - 2018-01-19 06:31:52 --> Model Class Initialized
INFO - 2018-01-19 06:31:52 --> Model Class Initialized
DEBUG - 2018-01-19 06:31:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 06:31:52 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 06:31:52 --> Final output sent to browser
DEBUG - 2018-01-19 06:31:52 --> Total execution time: 0.0543
INFO - 2018-01-19 06:32:25 --> Config Class Initialized
INFO - 2018-01-19 06:32:25 --> Hooks Class Initialized
DEBUG - 2018-01-19 06:32:25 --> UTF-8 Support Enabled
INFO - 2018-01-19 06:32:25 --> Utf8 Class Initialized
INFO - 2018-01-19 06:32:25 --> URI Class Initialized
INFO - 2018-01-19 06:32:25 --> Router Class Initialized
INFO - 2018-01-19 06:32:25 --> Output Class Initialized
INFO - 2018-01-19 06:32:25 --> Security Class Initialized
DEBUG - 2018-01-19 06:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 06:32:25 --> Input Class Initialized
INFO - 2018-01-19 06:32:25 --> Language Class Initialized
INFO - 2018-01-19 06:32:25 --> Loader Class Initialized
INFO - 2018-01-19 06:32:25 --> Helper loaded: url_helper
INFO - 2018-01-19 06:32:25 --> Helper loaded: form_helper
INFO - 2018-01-19 06:32:25 --> Database Driver Class Initialized
DEBUG - 2018-01-19 06:32:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 06:32:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 06:32:25 --> Form Validation Class Initialized
INFO - 2018-01-19 06:32:25 --> Model Class Initialized
INFO - 2018-01-19 06:32:25 --> Controller Class Initialized
INFO - 2018-01-19 06:32:25 --> Model Class Initialized
INFO - 2018-01-19 06:32:25 --> Model Class Initialized
INFO - 2018-01-19 06:32:25 --> Model Class Initialized
INFO - 2018-01-19 06:32:25 --> Model Class Initialized
DEBUG - 2018-01-19 06:32:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 06:32:25 --> Config Class Initialized
INFO - 2018-01-19 06:32:25 --> Hooks Class Initialized
DEBUG - 2018-01-19 06:32:25 --> UTF-8 Support Enabled
INFO - 2018-01-19 06:32:25 --> Utf8 Class Initialized
INFO - 2018-01-19 06:32:25 --> URI Class Initialized
INFO - 2018-01-19 06:32:25 --> Router Class Initialized
INFO - 2018-01-19 06:32:25 --> Output Class Initialized
INFO - 2018-01-19 06:32:25 --> Security Class Initialized
DEBUG - 2018-01-19 06:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 06:32:25 --> Input Class Initialized
INFO - 2018-01-19 06:32:25 --> Language Class Initialized
INFO - 2018-01-19 06:32:25 --> Loader Class Initialized
INFO - 2018-01-19 06:32:25 --> Helper loaded: url_helper
INFO - 2018-01-19 06:32:25 --> Helper loaded: form_helper
INFO - 2018-01-19 06:32:25 --> Database Driver Class Initialized
DEBUG - 2018-01-19 06:32:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 06:32:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 06:32:25 --> Form Validation Class Initialized
INFO - 2018-01-19 06:32:25 --> Model Class Initialized
INFO - 2018-01-19 06:32:25 --> Controller Class Initialized
INFO - 2018-01-19 06:32:25 --> Model Class Initialized
INFO - 2018-01-19 06:32:25 --> Model Class Initialized
INFO - 2018-01-19 06:32:25 --> Model Class Initialized
INFO - 2018-01-19 06:32:25 --> Model Class Initialized
DEBUG - 2018-01-19 06:32:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 06:32:25 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 06:32:25 --> Final output sent to browser
DEBUG - 2018-01-19 06:32:25 --> Total execution time: 0.0579
INFO - 2018-01-19 06:32:26 --> Config Class Initialized
INFO - 2018-01-19 06:32:26 --> Hooks Class Initialized
DEBUG - 2018-01-19 06:32:26 --> UTF-8 Support Enabled
INFO - 2018-01-19 06:32:26 --> Utf8 Class Initialized
INFO - 2018-01-19 06:32:26 --> URI Class Initialized
INFO - 2018-01-19 06:32:26 --> Router Class Initialized
INFO - 2018-01-19 06:32:26 --> Output Class Initialized
INFO - 2018-01-19 06:32:26 --> Security Class Initialized
DEBUG - 2018-01-19 06:32:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 06:32:26 --> Input Class Initialized
INFO - 2018-01-19 06:32:26 --> Language Class Initialized
INFO - 2018-01-19 06:32:26 --> Loader Class Initialized
INFO - 2018-01-19 06:32:26 --> Helper loaded: url_helper
INFO - 2018-01-19 06:32:26 --> Helper loaded: form_helper
INFO - 2018-01-19 06:32:26 --> Database Driver Class Initialized
DEBUG - 2018-01-19 06:32:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 06:32:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 06:32:26 --> Form Validation Class Initialized
INFO - 2018-01-19 06:32:26 --> Model Class Initialized
INFO - 2018-01-19 06:32:26 --> Controller Class Initialized
INFO - 2018-01-19 06:32:26 --> Model Class Initialized
INFO - 2018-01-19 06:32:26 --> Model Class Initialized
INFO - 2018-01-19 06:32:26 --> Model Class Initialized
INFO - 2018-01-19 06:32:26 --> Model Class Initialized
DEBUG - 2018-01-19 06:32:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 06:32:35 --> Config Class Initialized
INFO - 2018-01-19 06:32:35 --> Hooks Class Initialized
DEBUG - 2018-01-19 06:32:35 --> UTF-8 Support Enabled
INFO - 2018-01-19 06:32:35 --> Utf8 Class Initialized
INFO - 2018-01-19 06:32:35 --> URI Class Initialized
INFO - 2018-01-19 06:32:35 --> Router Class Initialized
INFO - 2018-01-19 06:32:35 --> Output Class Initialized
INFO - 2018-01-19 06:32:35 --> Security Class Initialized
DEBUG - 2018-01-19 06:32:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 06:32:35 --> Input Class Initialized
INFO - 2018-01-19 06:32:35 --> Language Class Initialized
INFO - 2018-01-19 06:32:35 --> Loader Class Initialized
INFO - 2018-01-19 06:32:35 --> Helper loaded: url_helper
INFO - 2018-01-19 06:32:35 --> Helper loaded: form_helper
INFO - 2018-01-19 06:32:35 --> Database Driver Class Initialized
DEBUG - 2018-01-19 06:32:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 06:32:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 06:32:35 --> Form Validation Class Initialized
INFO - 2018-01-19 06:32:35 --> Model Class Initialized
INFO - 2018-01-19 06:32:35 --> Controller Class Initialized
INFO - 2018-01-19 06:32:35 --> Model Class Initialized
INFO - 2018-01-19 06:32:35 --> Model Class Initialized
INFO - 2018-01-19 06:32:35 --> Model Class Initialized
INFO - 2018-01-19 06:32:35 --> Model Class Initialized
DEBUG - 2018-01-19 06:32:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 06:32:35 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 06:32:35 --> Final output sent to browser
DEBUG - 2018-01-19 06:32:35 --> Total execution time: 0.0549
INFO - 2018-01-19 06:32:35 --> Config Class Initialized
INFO - 2018-01-19 06:32:35 --> Hooks Class Initialized
DEBUG - 2018-01-19 06:32:35 --> UTF-8 Support Enabled
INFO - 2018-01-19 06:32:35 --> Utf8 Class Initialized
INFO - 2018-01-19 06:32:35 --> URI Class Initialized
INFO - 2018-01-19 06:32:35 --> Router Class Initialized
INFO - 2018-01-19 06:32:35 --> Output Class Initialized
INFO - 2018-01-19 06:32:35 --> Security Class Initialized
DEBUG - 2018-01-19 06:32:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 06:32:35 --> Input Class Initialized
INFO - 2018-01-19 06:32:35 --> Language Class Initialized
INFO - 2018-01-19 06:32:35 --> Loader Class Initialized
INFO - 2018-01-19 06:32:35 --> Helper loaded: url_helper
INFO - 2018-01-19 06:32:35 --> Helper loaded: form_helper
INFO - 2018-01-19 06:32:35 --> Database Driver Class Initialized
DEBUG - 2018-01-19 06:32:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 06:32:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 06:32:35 --> Form Validation Class Initialized
INFO - 2018-01-19 06:32:35 --> Model Class Initialized
INFO - 2018-01-19 06:32:35 --> Controller Class Initialized
INFO - 2018-01-19 06:32:35 --> Model Class Initialized
INFO - 2018-01-19 06:32:35 --> Model Class Initialized
INFO - 2018-01-19 06:32:35 --> Model Class Initialized
INFO - 2018-01-19 06:32:35 --> Model Class Initialized
DEBUG - 2018-01-19 06:32:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 06:32:56 --> Config Class Initialized
INFO - 2018-01-19 06:32:56 --> Hooks Class Initialized
DEBUG - 2018-01-19 06:32:56 --> UTF-8 Support Enabled
INFO - 2018-01-19 06:32:56 --> Utf8 Class Initialized
INFO - 2018-01-19 06:32:56 --> URI Class Initialized
INFO - 2018-01-19 06:32:56 --> Router Class Initialized
INFO - 2018-01-19 06:32:56 --> Output Class Initialized
INFO - 2018-01-19 06:32:56 --> Security Class Initialized
DEBUG - 2018-01-19 06:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 06:32:56 --> Input Class Initialized
INFO - 2018-01-19 06:32:56 --> Language Class Initialized
INFO - 2018-01-19 06:32:56 --> Loader Class Initialized
INFO - 2018-01-19 06:32:56 --> Helper loaded: url_helper
INFO - 2018-01-19 06:32:56 --> Helper loaded: form_helper
INFO - 2018-01-19 06:32:56 --> Database Driver Class Initialized
DEBUG - 2018-01-19 06:32:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 06:32:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 06:32:56 --> Form Validation Class Initialized
INFO - 2018-01-19 06:32:56 --> Model Class Initialized
INFO - 2018-01-19 06:32:56 --> Controller Class Initialized
INFO - 2018-01-19 06:32:56 --> Model Class Initialized
INFO - 2018-01-19 06:32:56 --> Model Class Initialized
INFO - 2018-01-19 06:32:56 --> Model Class Initialized
INFO - 2018-01-19 06:32:56 --> Model Class Initialized
DEBUG - 2018-01-19 06:32:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 06:32:56 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 06:32:56 --> Final output sent to browser
DEBUG - 2018-01-19 06:32:56 --> Total execution time: 0.0683
INFO - 2018-01-19 06:32:56 --> Config Class Initialized
INFO - 2018-01-19 06:32:56 --> Hooks Class Initialized
DEBUG - 2018-01-19 06:32:56 --> UTF-8 Support Enabled
INFO - 2018-01-19 06:32:56 --> Utf8 Class Initialized
INFO - 2018-01-19 06:32:56 --> URI Class Initialized
INFO - 2018-01-19 06:32:56 --> Router Class Initialized
INFO - 2018-01-19 06:32:56 --> Output Class Initialized
INFO - 2018-01-19 06:32:56 --> Security Class Initialized
DEBUG - 2018-01-19 06:32:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 06:32:57 --> Input Class Initialized
INFO - 2018-01-19 06:32:57 --> Language Class Initialized
INFO - 2018-01-19 06:32:57 --> Loader Class Initialized
INFO - 2018-01-19 06:32:57 --> Helper loaded: url_helper
INFO - 2018-01-19 06:32:57 --> Helper loaded: form_helper
INFO - 2018-01-19 06:32:57 --> Database Driver Class Initialized
DEBUG - 2018-01-19 06:32:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 06:32:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 06:32:57 --> Form Validation Class Initialized
INFO - 2018-01-19 06:32:57 --> Model Class Initialized
INFO - 2018-01-19 06:32:57 --> Controller Class Initialized
INFO - 2018-01-19 06:32:57 --> Model Class Initialized
INFO - 2018-01-19 06:32:57 --> Model Class Initialized
INFO - 2018-01-19 06:32:57 --> Model Class Initialized
INFO - 2018-01-19 06:32:57 --> Model Class Initialized
DEBUG - 2018-01-19 06:32:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 07:55:13 --> Config Class Initialized
INFO - 2018-01-19 07:55:13 --> Hooks Class Initialized
DEBUG - 2018-01-19 07:55:13 --> UTF-8 Support Enabled
INFO - 2018-01-19 07:55:13 --> Utf8 Class Initialized
INFO - 2018-01-19 07:55:13 --> URI Class Initialized
INFO - 2018-01-19 07:55:13 --> Router Class Initialized
INFO - 2018-01-19 07:55:13 --> Output Class Initialized
INFO - 2018-01-19 07:55:13 --> Security Class Initialized
DEBUG - 2018-01-19 07:55:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 07:55:13 --> Input Class Initialized
INFO - 2018-01-19 07:55:13 --> Language Class Initialized
INFO - 2018-01-19 07:55:13 --> Loader Class Initialized
INFO - 2018-01-19 07:55:13 --> Helper loaded: url_helper
INFO - 2018-01-19 07:55:13 --> Helper loaded: form_helper
INFO - 2018-01-19 07:55:13 --> Database Driver Class Initialized
DEBUG - 2018-01-19 07:55:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 07:55:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 07:55:13 --> Form Validation Class Initialized
INFO - 2018-01-19 07:55:13 --> Model Class Initialized
INFO - 2018-01-19 07:55:13 --> Controller Class Initialized
INFO - 2018-01-19 07:55:13 --> Model Class Initialized
INFO - 2018-01-19 07:55:13 --> Model Class Initialized
INFO - 2018-01-19 07:55:13 --> Model Class Initialized
INFO - 2018-01-19 07:55:13 --> Model Class Initialized
DEBUG - 2018-01-19 07:55:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 07:55:13 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 07:55:13 --> Final output sent to browser
DEBUG - 2018-01-19 07:55:13 --> Total execution time: 0.0814
INFO - 2018-01-19 07:55:15 --> Config Class Initialized
INFO - 2018-01-19 07:55:15 --> Hooks Class Initialized
DEBUG - 2018-01-19 07:55:15 --> UTF-8 Support Enabled
INFO - 2018-01-19 07:55:15 --> Utf8 Class Initialized
INFO - 2018-01-19 07:55:15 --> URI Class Initialized
INFO - 2018-01-19 07:55:15 --> Router Class Initialized
INFO - 2018-01-19 07:55:15 --> Output Class Initialized
INFO - 2018-01-19 07:55:15 --> Security Class Initialized
DEBUG - 2018-01-19 07:55:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 07:55:15 --> Input Class Initialized
INFO - 2018-01-19 07:55:15 --> Language Class Initialized
INFO - 2018-01-19 07:55:15 --> Loader Class Initialized
INFO - 2018-01-19 07:55:15 --> Helper loaded: url_helper
INFO - 2018-01-19 07:55:15 --> Helper loaded: form_helper
INFO - 2018-01-19 07:55:15 --> Database Driver Class Initialized
DEBUG - 2018-01-19 07:55:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 07:55:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 07:55:15 --> Form Validation Class Initialized
INFO - 2018-01-19 07:55:15 --> Model Class Initialized
INFO - 2018-01-19 07:55:15 --> Controller Class Initialized
INFO - 2018-01-19 07:55:15 --> Model Class Initialized
INFO - 2018-01-19 07:55:15 --> Model Class Initialized
INFO - 2018-01-19 07:55:15 --> Model Class Initialized
INFO - 2018-01-19 07:55:15 --> Model Class Initialized
DEBUG - 2018-01-19 07:55:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 08:53:47 --> Config Class Initialized
INFO - 2018-01-19 08:53:47 --> Hooks Class Initialized
DEBUG - 2018-01-19 08:53:47 --> UTF-8 Support Enabled
INFO - 2018-01-19 08:53:47 --> Utf8 Class Initialized
INFO - 2018-01-19 08:53:47 --> URI Class Initialized
INFO - 2018-01-19 08:53:47 --> Router Class Initialized
INFO - 2018-01-19 08:53:47 --> Output Class Initialized
INFO - 2018-01-19 08:53:47 --> Security Class Initialized
DEBUG - 2018-01-19 08:53:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 08:53:47 --> Input Class Initialized
INFO - 2018-01-19 08:53:47 --> Language Class Initialized
INFO - 2018-01-19 08:53:47 --> Loader Class Initialized
INFO - 2018-01-19 08:53:47 --> Helper loaded: url_helper
INFO - 2018-01-19 08:53:47 --> Helper loaded: form_helper
INFO - 2018-01-19 08:53:47 --> Database Driver Class Initialized
DEBUG - 2018-01-19 08:53:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 08:53:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 08:53:47 --> Form Validation Class Initialized
INFO - 2018-01-19 08:53:47 --> Model Class Initialized
INFO - 2018-01-19 08:53:47 --> Controller Class Initialized
INFO - 2018-01-19 08:53:47 --> Model Class Initialized
DEBUG - 2018-01-19 08:53:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 08:53:47 --> Config Class Initialized
INFO - 2018-01-19 08:53:47 --> Hooks Class Initialized
DEBUG - 2018-01-19 08:53:47 --> UTF-8 Support Enabled
INFO - 2018-01-19 08:53:47 --> Utf8 Class Initialized
INFO - 2018-01-19 08:53:47 --> URI Class Initialized
INFO - 2018-01-19 08:53:47 --> Router Class Initialized
INFO - 2018-01-19 08:53:47 --> Output Class Initialized
INFO - 2018-01-19 08:53:47 --> Security Class Initialized
DEBUG - 2018-01-19 08:53:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 08:53:47 --> Input Class Initialized
INFO - 2018-01-19 08:53:47 --> Language Class Initialized
INFO - 2018-01-19 08:53:47 --> Loader Class Initialized
INFO - 2018-01-19 08:53:47 --> Helper loaded: url_helper
INFO - 2018-01-19 08:53:47 --> Helper loaded: form_helper
INFO - 2018-01-19 08:53:47 --> Database Driver Class Initialized
DEBUG - 2018-01-19 08:53:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 08:53:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 08:53:47 --> Form Validation Class Initialized
INFO - 2018-01-19 08:53:47 --> Model Class Initialized
INFO - 2018-01-19 08:53:47 --> Controller Class Initialized
INFO - 2018-01-19 08:53:47 --> Model Class Initialized
DEBUG - 2018-01-19 08:53:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 08:53:47 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 08:53:47 --> Final output sent to browser
DEBUG - 2018-01-19 08:53:47 --> Total execution time: 0.0392
INFO - 2018-01-19 10:50:29 --> Config Class Initialized
INFO - 2018-01-19 10:50:29 --> Hooks Class Initialized
DEBUG - 2018-01-19 10:50:29 --> UTF-8 Support Enabled
INFO - 2018-01-19 10:50:29 --> Utf8 Class Initialized
INFO - 2018-01-19 10:50:29 --> URI Class Initialized
INFO - 2018-01-19 10:50:29 --> Router Class Initialized
INFO - 2018-01-19 10:50:29 --> Output Class Initialized
INFO - 2018-01-19 10:50:29 --> Security Class Initialized
DEBUG - 2018-01-19 10:50:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 10:50:29 --> Input Class Initialized
INFO - 2018-01-19 10:50:29 --> Language Class Initialized
INFO - 2018-01-19 10:50:29 --> Loader Class Initialized
INFO - 2018-01-19 10:50:29 --> Helper loaded: url_helper
INFO - 2018-01-19 10:50:29 --> Helper loaded: form_helper
INFO - 2018-01-19 10:50:29 --> Database Driver Class Initialized
DEBUG - 2018-01-19 10:50:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 10:50:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 10:50:29 --> Form Validation Class Initialized
INFO - 2018-01-19 10:50:29 --> Model Class Initialized
INFO - 2018-01-19 10:50:29 --> Controller Class Initialized
INFO - 2018-01-19 10:50:29 --> Model Class Initialized
INFO - 2018-01-19 10:50:29 --> Model Class Initialized
INFO - 2018-01-19 10:50:29 --> Model Class Initialized
INFO - 2018-01-19 10:50:29 --> Model Class Initialized
DEBUG - 2018-01-19 10:50:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 10:50:30 --> Config Class Initialized
INFO - 2018-01-19 10:50:30 --> Hooks Class Initialized
DEBUG - 2018-01-19 10:50:30 --> UTF-8 Support Enabled
INFO - 2018-01-19 10:50:30 --> Utf8 Class Initialized
INFO - 2018-01-19 10:50:30 --> URI Class Initialized
INFO - 2018-01-19 10:50:30 --> Router Class Initialized
INFO - 2018-01-19 10:50:30 --> Output Class Initialized
INFO - 2018-01-19 10:50:30 --> Security Class Initialized
DEBUG - 2018-01-19 10:50:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 10:50:30 --> Input Class Initialized
INFO - 2018-01-19 10:50:30 --> Language Class Initialized
INFO - 2018-01-19 10:50:30 --> Loader Class Initialized
INFO - 2018-01-19 10:50:30 --> Helper loaded: url_helper
INFO - 2018-01-19 10:50:30 --> Helper loaded: form_helper
INFO - 2018-01-19 10:50:30 --> Database Driver Class Initialized
DEBUG - 2018-01-19 10:50:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 10:50:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 10:50:30 --> Form Validation Class Initialized
INFO - 2018-01-19 10:50:30 --> Model Class Initialized
INFO - 2018-01-19 10:50:30 --> Controller Class Initialized
INFO - 2018-01-19 10:50:30 --> Model Class Initialized
DEBUG - 2018-01-19 10:50:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 10:50:30 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 10:50:30 --> Final output sent to browser
DEBUG - 2018-01-19 10:50:30 --> Total execution time: 0.0504
INFO - 2018-01-19 12:10:16 --> Config Class Initialized
INFO - 2018-01-19 12:10:16 --> Hooks Class Initialized
DEBUG - 2018-01-19 12:10:16 --> UTF-8 Support Enabled
INFO - 2018-01-19 12:10:16 --> Utf8 Class Initialized
INFO - 2018-01-19 12:10:16 --> URI Class Initialized
INFO - 2018-01-19 12:10:16 --> Router Class Initialized
INFO - 2018-01-19 12:10:16 --> Output Class Initialized
INFO - 2018-01-19 12:10:16 --> Security Class Initialized
DEBUG - 2018-01-19 12:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 12:10:16 --> Input Class Initialized
INFO - 2018-01-19 12:10:16 --> Language Class Initialized
INFO - 2018-01-19 12:10:16 --> Loader Class Initialized
INFO - 2018-01-19 12:10:16 --> Helper loaded: url_helper
INFO - 2018-01-19 12:10:16 --> Helper loaded: form_helper
INFO - 2018-01-19 12:10:16 --> Database Driver Class Initialized
DEBUG - 2018-01-19 12:10:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 12:10:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 12:10:16 --> Form Validation Class Initialized
INFO - 2018-01-19 12:10:16 --> Model Class Initialized
INFO - 2018-01-19 12:10:16 --> Controller Class Initialized
INFO - 2018-01-19 12:10:16 --> Model Class Initialized
INFO - 2018-01-19 12:10:16 --> Model Class Initialized
INFO - 2018-01-19 12:10:16 --> Model Class Initialized
INFO - 2018-01-19 12:10:16 --> Model Class Initialized
DEBUG - 2018-01-19 12:10:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 12:10:17 --> Config Class Initialized
INFO - 2018-01-19 12:10:17 --> Hooks Class Initialized
DEBUG - 2018-01-19 12:10:17 --> UTF-8 Support Enabled
INFO - 2018-01-19 12:10:17 --> Utf8 Class Initialized
INFO - 2018-01-19 12:10:17 --> URI Class Initialized
INFO - 2018-01-19 12:10:17 --> Router Class Initialized
INFO - 2018-01-19 12:10:17 --> Output Class Initialized
INFO - 2018-01-19 12:10:17 --> Security Class Initialized
DEBUG - 2018-01-19 12:10:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 12:10:17 --> Input Class Initialized
INFO - 2018-01-19 12:10:17 --> Language Class Initialized
INFO - 2018-01-19 12:10:17 --> Loader Class Initialized
INFO - 2018-01-19 12:10:17 --> Helper loaded: url_helper
INFO - 2018-01-19 12:10:17 --> Helper loaded: form_helper
INFO - 2018-01-19 12:10:17 --> Database Driver Class Initialized
DEBUG - 2018-01-19 12:10:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 12:10:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 12:10:17 --> Form Validation Class Initialized
INFO - 2018-01-19 12:10:17 --> Model Class Initialized
INFO - 2018-01-19 12:10:17 --> Controller Class Initialized
INFO - 2018-01-19 12:10:17 --> Model Class Initialized
DEBUG - 2018-01-19 12:10:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 12:10:17 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 12:10:17 --> Final output sent to browser
DEBUG - 2018-01-19 12:10:17 --> Total execution time: 0.0369
INFO - 2018-01-19 12:12:58 --> Config Class Initialized
INFO - 2018-01-19 12:12:58 --> Hooks Class Initialized
DEBUG - 2018-01-19 12:12:58 --> UTF-8 Support Enabled
INFO - 2018-01-19 12:12:58 --> Utf8 Class Initialized
INFO - 2018-01-19 12:12:58 --> URI Class Initialized
INFO - 2018-01-19 12:12:58 --> Router Class Initialized
INFO - 2018-01-19 12:12:58 --> Output Class Initialized
INFO - 2018-01-19 12:12:58 --> Security Class Initialized
DEBUG - 2018-01-19 12:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 12:12:58 --> Input Class Initialized
INFO - 2018-01-19 12:12:58 --> Language Class Initialized
INFO - 2018-01-19 12:12:58 --> Loader Class Initialized
INFO - 2018-01-19 12:12:58 --> Helper loaded: url_helper
INFO - 2018-01-19 12:12:58 --> Helper loaded: form_helper
INFO - 2018-01-19 12:12:58 --> Database Driver Class Initialized
DEBUG - 2018-01-19 12:12:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 12:12:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 12:12:58 --> Form Validation Class Initialized
INFO - 2018-01-19 12:12:58 --> Model Class Initialized
INFO - 2018-01-19 12:12:58 --> Controller Class Initialized
INFO - 2018-01-19 12:12:58 --> Model Class Initialized
DEBUG - 2018-01-19 12:12:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 12:12:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-01-19 12:12:59 --> Config Class Initialized
INFO - 2018-01-19 12:12:59 --> Hooks Class Initialized
DEBUG - 2018-01-19 12:12:59 --> UTF-8 Support Enabled
INFO - 2018-01-19 12:12:59 --> Utf8 Class Initialized
INFO - 2018-01-19 12:12:59 --> URI Class Initialized
DEBUG - 2018-01-19 12:12:59 --> No URI present. Default controller set.
INFO - 2018-01-19 12:12:59 --> Router Class Initialized
INFO - 2018-01-19 12:12:59 --> Output Class Initialized
INFO - 2018-01-19 12:12:59 --> Security Class Initialized
DEBUG - 2018-01-19 12:12:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 12:12:59 --> Input Class Initialized
INFO - 2018-01-19 12:12:59 --> Language Class Initialized
INFO - 2018-01-19 12:12:59 --> Loader Class Initialized
INFO - 2018-01-19 12:12:59 --> Helper loaded: url_helper
INFO - 2018-01-19 12:12:59 --> Helper loaded: form_helper
INFO - 2018-01-19 12:12:59 --> Database Driver Class Initialized
DEBUG - 2018-01-19 12:12:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 12:12:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 12:12:59 --> Form Validation Class Initialized
INFO - 2018-01-19 12:12:59 --> Model Class Initialized
INFO - 2018-01-19 12:12:59 --> Controller Class Initialized
INFO - 2018-01-19 12:12:59 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 12:12:59 --> Final output sent to browser
DEBUG - 2018-01-19 12:12:59 --> Total execution time: 0.0428
INFO - 2018-01-19 12:13:03 --> Config Class Initialized
INFO - 2018-01-19 12:13:03 --> Hooks Class Initialized
DEBUG - 2018-01-19 12:13:03 --> UTF-8 Support Enabled
INFO - 2018-01-19 12:13:03 --> Utf8 Class Initialized
INFO - 2018-01-19 12:13:03 --> URI Class Initialized
INFO - 2018-01-19 12:13:03 --> Router Class Initialized
INFO - 2018-01-19 12:13:03 --> Output Class Initialized
INFO - 2018-01-19 12:13:03 --> Security Class Initialized
DEBUG - 2018-01-19 12:13:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 12:13:03 --> Input Class Initialized
INFO - 2018-01-19 12:13:03 --> Language Class Initialized
INFO - 2018-01-19 12:13:03 --> Loader Class Initialized
INFO - 2018-01-19 12:13:03 --> Helper loaded: url_helper
INFO - 2018-01-19 12:13:03 --> Helper loaded: form_helper
INFO - 2018-01-19 12:13:03 --> Database Driver Class Initialized
DEBUG - 2018-01-19 12:13:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 12:13:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 12:13:03 --> Form Validation Class Initialized
INFO - 2018-01-19 12:13:03 --> Model Class Initialized
INFO - 2018-01-19 12:13:03 --> Controller Class Initialized
INFO - 2018-01-19 12:13:03 --> Model Class Initialized
INFO - 2018-01-19 12:13:03 --> Model Class Initialized
INFO - 2018-01-19 12:13:03 --> Model Class Initialized
INFO - 2018-01-19 12:13:03 --> Model Class Initialized
DEBUG - 2018-01-19 12:13:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 12:13:03 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 12:13:03 --> Final output sent to browser
DEBUG - 2018-01-19 12:13:03 --> Total execution time: 0.0487
INFO - 2018-01-19 12:13:04 --> Config Class Initialized
INFO - 2018-01-19 12:13:04 --> Hooks Class Initialized
DEBUG - 2018-01-19 12:13:04 --> UTF-8 Support Enabled
INFO - 2018-01-19 12:13:04 --> Utf8 Class Initialized
INFO - 2018-01-19 12:13:04 --> URI Class Initialized
INFO - 2018-01-19 12:13:04 --> Router Class Initialized
INFO - 2018-01-19 12:13:04 --> Output Class Initialized
INFO - 2018-01-19 12:13:04 --> Security Class Initialized
DEBUG - 2018-01-19 12:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 12:13:04 --> Input Class Initialized
INFO - 2018-01-19 12:13:04 --> Language Class Initialized
INFO - 2018-01-19 12:13:04 --> Loader Class Initialized
INFO - 2018-01-19 12:13:04 --> Helper loaded: url_helper
INFO - 2018-01-19 12:13:04 --> Helper loaded: form_helper
INFO - 2018-01-19 12:13:04 --> Database Driver Class Initialized
DEBUG - 2018-01-19 12:13:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 12:13:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 12:13:04 --> Form Validation Class Initialized
INFO - 2018-01-19 12:13:04 --> Model Class Initialized
INFO - 2018-01-19 12:13:04 --> Controller Class Initialized
INFO - 2018-01-19 12:13:04 --> Model Class Initialized
INFO - 2018-01-19 12:13:04 --> Model Class Initialized
INFO - 2018-01-19 12:13:04 --> Model Class Initialized
INFO - 2018-01-19 12:13:04 --> Model Class Initialized
DEBUG - 2018-01-19 12:13:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 14:49:17 --> Config Class Initialized
INFO - 2018-01-19 14:49:17 --> Hooks Class Initialized
DEBUG - 2018-01-19 14:49:17 --> UTF-8 Support Enabled
INFO - 2018-01-19 14:49:17 --> Utf8 Class Initialized
INFO - 2018-01-19 14:49:17 --> URI Class Initialized
INFO - 2018-01-19 14:49:17 --> Router Class Initialized
INFO - 2018-01-19 14:49:17 --> Output Class Initialized
INFO - 2018-01-19 14:49:17 --> Security Class Initialized
DEBUG - 2018-01-19 14:49:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 14:49:17 --> Input Class Initialized
INFO - 2018-01-19 14:49:17 --> Language Class Initialized
INFO - 2018-01-19 14:49:17 --> Loader Class Initialized
INFO - 2018-01-19 14:49:17 --> Helper loaded: url_helper
INFO - 2018-01-19 14:49:17 --> Helper loaded: form_helper
INFO - 2018-01-19 14:49:17 --> Database Driver Class Initialized
DEBUG - 2018-01-19 14:49:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 14:49:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 14:49:17 --> Form Validation Class Initialized
INFO - 2018-01-19 14:49:17 --> Model Class Initialized
INFO - 2018-01-19 14:49:17 --> Controller Class Initialized
INFO - 2018-01-19 14:49:17 --> Model Class Initialized
INFO - 2018-01-19 14:49:17 --> Model Class Initialized
INFO - 2018-01-19 14:49:17 --> Model Class Initialized
INFO - 2018-01-19 14:49:17 --> Model Class Initialized
DEBUG - 2018-01-19 14:49:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 14:49:17 --> Config Class Initialized
INFO - 2018-01-19 14:49:17 --> Hooks Class Initialized
DEBUG - 2018-01-19 14:49:17 --> UTF-8 Support Enabled
INFO - 2018-01-19 14:49:17 --> Utf8 Class Initialized
INFO - 2018-01-19 14:49:17 --> URI Class Initialized
INFO - 2018-01-19 14:49:17 --> Router Class Initialized
INFO - 2018-01-19 14:49:17 --> Output Class Initialized
INFO - 2018-01-19 14:49:17 --> Security Class Initialized
DEBUG - 2018-01-19 14:49:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 14:49:17 --> Input Class Initialized
INFO - 2018-01-19 14:49:17 --> Language Class Initialized
INFO - 2018-01-19 14:49:17 --> Loader Class Initialized
INFO - 2018-01-19 14:49:17 --> Helper loaded: url_helper
INFO - 2018-01-19 14:49:17 --> Helper loaded: form_helper
INFO - 2018-01-19 14:49:18 --> Database Driver Class Initialized
DEBUG - 2018-01-19 14:49:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 14:49:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 14:49:18 --> Form Validation Class Initialized
INFO - 2018-01-19 14:49:18 --> Model Class Initialized
INFO - 2018-01-19 14:49:18 --> Controller Class Initialized
INFO - 2018-01-19 14:49:18 --> Model Class Initialized
DEBUG - 2018-01-19 14:49:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 14:49:18 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 14:49:18 --> Final output sent to browser
DEBUG - 2018-01-19 14:49:18 --> Total execution time: 0.0510
INFO - 2018-01-19 14:49:42 --> Config Class Initialized
INFO - 2018-01-19 14:49:42 --> Hooks Class Initialized
DEBUG - 2018-01-19 14:49:42 --> UTF-8 Support Enabled
INFO - 2018-01-19 14:49:42 --> Utf8 Class Initialized
INFO - 2018-01-19 14:49:42 --> URI Class Initialized
INFO - 2018-01-19 14:49:42 --> Router Class Initialized
INFO - 2018-01-19 14:49:42 --> Output Class Initialized
INFO - 2018-01-19 14:49:42 --> Security Class Initialized
DEBUG - 2018-01-19 14:49:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 14:49:42 --> Input Class Initialized
INFO - 2018-01-19 14:49:42 --> Language Class Initialized
INFO - 2018-01-19 14:49:42 --> Loader Class Initialized
INFO - 2018-01-19 14:49:42 --> Helper loaded: url_helper
INFO - 2018-01-19 14:49:42 --> Helper loaded: form_helper
INFO - 2018-01-19 14:49:42 --> Database Driver Class Initialized
DEBUG - 2018-01-19 14:49:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 14:49:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 14:49:42 --> Form Validation Class Initialized
INFO - 2018-01-19 14:49:42 --> Model Class Initialized
INFO - 2018-01-19 14:49:42 --> Controller Class Initialized
INFO - 2018-01-19 14:49:42 --> Model Class Initialized
DEBUG - 2018-01-19 14:49:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 14:49:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-01-19 14:49:44 --> Config Class Initialized
INFO - 2018-01-19 14:49:44 --> Hooks Class Initialized
DEBUG - 2018-01-19 14:49:44 --> UTF-8 Support Enabled
INFO - 2018-01-19 14:49:44 --> Utf8 Class Initialized
INFO - 2018-01-19 14:49:44 --> URI Class Initialized
DEBUG - 2018-01-19 14:49:44 --> No URI present. Default controller set.
INFO - 2018-01-19 14:49:44 --> Router Class Initialized
INFO - 2018-01-19 14:49:44 --> Output Class Initialized
INFO - 2018-01-19 14:49:44 --> Security Class Initialized
DEBUG - 2018-01-19 14:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 14:49:44 --> Input Class Initialized
INFO - 2018-01-19 14:49:44 --> Language Class Initialized
INFO - 2018-01-19 14:49:44 --> Loader Class Initialized
INFO - 2018-01-19 14:49:44 --> Helper loaded: url_helper
INFO - 2018-01-19 14:49:44 --> Helper loaded: form_helper
INFO - 2018-01-19 14:49:44 --> Database Driver Class Initialized
DEBUG - 2018-01-19 14:49:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 14:49:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 14:49:44 --> Form Validation Class Initialized
INFO - 2018-01-19 14:49:44 --> Model Class Initialized
INFO - 2018-01-19 14:49:44 --> Controller Class Initialized
INFO - 2018-01-19 14:49:44 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 14:49:44 --> Final output sent to browser
DEBUG - 2018-01-19 14:49:44 --> Total execution time: 0.0446
INFO - 2018-01-19 14:51:30 --> Config Class Initialized
INFO - 2018-01-19 14:51:30 --> Hooks Class Initialized
DEBUG - 2018-01-19 14:51:30 --> UTF-8 Support Enabled
INFO - 2018-01-19 14:51:30 --> Utf8 Class Initialized
INFO - 2018-01-19 14:51:30 --> URI Class Initialized
INFO - 2018-01-19 14:51:30 --> Router Class Initialized
INFO - 2018-01-19 14:51:30 --> Output Class Initialized
INFO - 2018-01-19 14:51:30 --> Security Class Initialized
DEBUG - 2018-01-19 14:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 14:51:30 --> Input Class Initialized
INFO - 2018-01-19 14:51:30 --> Language Class Initialized
INFO - 2018-01-19 14:51:30 --> Loader Class Initialized
INFO - 2018-01-19 14:51:30 --> Helper loaded: url_helper
INFO - 2018-01-19 14:51:30 --> Helper loaded: form_helper
INFO - 2018-01-19 14:51:30 --> Database Driver Class Initialized
DEBUG - 2018-01-19 14:51:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 14:51:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 14:51:30 --> Form Validation Class Initialized
INFO - 2018-01-19 14:51:30 --> Model Class Initialized
INFO - 2018-01-19 14:51:30 --> Controller Class Initialized
INFO - 2018-01-19 14:51:30 --> Model Class Initialized
INFO - 2018-01-19 14:51:30 --> Model Class Initialized
INFO - 2018-01-19 14:51:30 --> Model Class Initialized
INFO - 2018-01-19 14:51:30 --> Model Class Initialized
DEBUG - 2018-01-19 14:51:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 14:51:33 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 14:51:33 --> Final output sent to browser
DEBUG - 2018-01-19 14:51:33 --> Total execution time: 2.4626
INFO - 2018-01-19 14:58:26 --> Config Class Initialized
INFO - 2018-01-19 14:58:26 --> Hooks Class Initialized
DEBUG - 2018-01-19 14:58:26 --> UTF-8 Support Enabled
INFO - 2018-01-19 14:58:26 --> Utf8 Class Initialized
INFO - 2018-01-19 14:58:26 --> URI Class Initialized
INFO - 2018-01-19 14:58:26 --> Router Class Initialized
INFO - 2018-01-19 14:58:26 --> Output Class Initialized
INFO - 2018-01-19 14:58:26 --> Security Class Initialized
DEBUG - 2018-01-19 14:58:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 14:58:26 --> Input Class Initialized
INFO - 2018-01-19 14:58:26 --> Language Class Initialized
INFO - 2018-01-19 14:58:26 --> Loader Class Initialized
INFO - 2018-01-19 14:58:26 --> Helper loaded: url_helper
INFO - 2018-01-19 14:58:26 --> Helper loaded: form_helper
INFO - 2018-01-19 14:58:26 --> Database Driver Class Initialized
DEBUG - 2018-01-19 14:58:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 14:58:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 14:58:26 --> Form Validation Class Initialized
INFO - 2018-01-19 14:58:26 --> Model Class Initialized
INFO - 2018-01-19 14:58:26 --> Controller Class Initialized
INFO - 2018-01-19 14:58:26 --> Model Class Initialized
DEBUG - 2018-01-19 14:58:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 14:58:26 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 14:58:26 --> Final output sent to browser
DEBUG - 2018-01-19 14:58:26 --> Total execution time: 0.0373
INFO - 2018-01-19 15:01:07 --> Config Class Initialized
INFO - 2018-01-19 15:01:07 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:01:07 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:01:07 --> Utf8 Class Initialized
INFO - 2018-01-19 15:01:07 --> URI Class Initialized
INFO - 2018-01-19 15:01:07 --> Router Class Initialized
INFO - 2018-01-19 15:01:07 --> Output Class Initialized
INFO - 2018-01-19 15:01:07 --> Security Class Initialized
DEBUG - 2018-01-19 15:01:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:01:07 --> Input Class Initialized
INFO - 2018-01-19 15:01:07 --> Language Class Initialized
INFO - 2018-01-19 15:01:07 --> Loader Class Initialized
INFO - 2018-01-19 15:01:07 --> Helper loaded: url_helper
INFO - 2018-01-19 15:01:07 --> Helper loaded: form_helper
INFO - 2018-01-19 15:01:07 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:01:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:01:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:01:07 --> Form Validation Class Initialized
INFO - 2018-01-19 15:01:07 --> Model Class Initialized
INFO - 2018-01-19 15:01:07 --> Controller Class Initialized
INFO - 2018-01-19 15:01:07 --> Model Class Initialized
DEBUG - 2018-01-19 15:01:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:01:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-01-19 15:01:07 --> Config Class Initialized
INFO - 2018-01-19 15:01:07 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:01:07 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:01:07 --> Utf8 Class Initialized
INFO - 2018-01-19 15:01:07 --> URI Class Initialized
DEBUG - 2018-01-19 15:01:07 --> No URI present. Default controller set.
INFO - 2018-01-19 15:01:07 --> Router Class Initialized
INFO - 2018-01-19 15:01:07 --> Output Class Initialized
INFO - 2018-01-19 15:01:07 --> Security Class Initialized
DEBUG - 2018-01-19 15:01:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:01:07 --> Input Class Initialized
INFO - 2018-01-19 15:01:07 --> Language Class Initialized
INFO - 2018-01-19 15:01:07 --> Loader Class Initialized
INFO - 2018-01-19 15:01:07 --> Helper loaded: url_helper
INFO - 2018-01-19 15:01:07 --> Helper loaded: form_helper
INFO - 2018-01-19 15:01:07 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:01:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:01:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:01:07 --> Form Validation Class Initialized
INFO - 2018-01-19 15:01:07 --> Model Class Initialized
INFO - 2018-01-19 15:01:07 --> Controller Class Initialized
INFO - 2018-01-19 15:01:07 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 15:01:07 --> Final output sent to browser
DEBUG - 2018-01-19 15:01:07 --> Total execution time: 0.0344
INFO - 2018-01-19 15:02:27 --> Config Class Initialized
INFO - 2018-01-19 15:02:27 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:02:27 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:02:27 --> Utf8 Class Initialized
INFO - 2018-01-19 15:02:27 --> URI Class Initialized
INFO - 2018-01-19 15:02:27 --> Router Class Initialized
INFO - 2018-01-19 15:02:27 --> Output Class Initialized
INFO - 2018-01-19 15:02:27 --> Security Class Initialized
DEBUG - 2018-01-19 15:02:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:02:27 --> Input Class Initialized
INFO - 2018-01-19 15:02:27 --> Language Class Initialized
INFO - 2018-01-19 15:02:27 --> Loader Class Initialized
INFO - 2018-01-19 15:02:27 --> Helper loaded: url_helper
INFO - 2018-01-19 15:02:27 --> Helper loaded: form_helper
INFO - 2018-01-19 15:02:27 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:02:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:02:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:02:27 --> Form Validation Class Initialized
INFO - 2018-01-19 15:02:27 --> Model Class Initialized
INFO - 2018-01-19 15:02:27 --> Controller Class Initialized
INFO - 2018-01-19 15:02:27 --> Model Class Initialized
INFO - 2018-01-19 15:02:27 --> Model Class Initialized
INFO - 2018-01-19 15:02:27 --> Model Class Initialized
INFO - 2018-01-19 15:02:27 --> Model Class Initialized
DEBUG - 2018-01-19 15:02:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:02:27 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 15:02:27 --> Final output sent to browser
DEBUG - 2018-01-19 15:02:27 --> Total execution time: 0.0561
INFO - 2018-01-19 15:02:28 --> Config Class Initialized
INFO - 2018-01-19 15:02:28 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:02:28 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:02:28 --> Utf8 Class Initialized
INFO - 2018-01-19 15:02:28 --> URI Class Initialized
INFO - 2018-01-19 15:02:28 --> Router Class Initialized
INFO - 2018-01-19 15:02:28 --> Output Class Initialized
INFO - 2018-01-19 15:02:28 --> Security Class Initialized
DEBUG - 2018-01-19 15:02:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:02:28 --> Input Class Initialized
INFO - 2018-01-19 15:02:28 --> Language Class Initialized
INFO - 2018-01-19 15:02:28 --> Loader Class Initialized
INFO - 2018-01-19 15:02:28 --> Helper loaded: url_helper
INFO - 2018-01-19 15:02:28 --> Helper loaded: form_helper
INFO - 2018-01-19 15:02:28 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:02:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:02:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:02:28 --> Form Validation Class Initialized
INFO - 2018-01-19 15:02:28 --> Model Class Initialized
INFO - 2018-01-19 15:02:28 --> Controller Class Initialized
INFO - 2018-01-19 15:02:28 --> Model Class Initialized
INFO - 2018-01-19 15:02:28 --> Model Class Initialized
INFO - 2018-01-19 15:02:28 --> Model Class Initialized
INFO - 2018-01-19 15:02:28 --> Model Class Initialized
DEBUG - 2018-01-19 15:02:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:02:40 --> Config Class Initialized
INFO - 2018-01-19 15:02:40 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:02:40 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:02:40 --> Utf8 Class Initialized
INFO - 2018-01-19 15:02:40 --> URI Class Initialized
INFO - 2018-01-19 15:02:40 --> Router Class Initialized
INFO - 2018-01-19 15:02:40 --> Output Class Initialized
INFO - 2018-01-19 15:02:40 --> Security Class Initialized
DEBUG - 2018-01-19 15:02:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:02:40 --> Input Class Initialized
INFO - 2018-01-19 15:02:40 --> Language Class Initialized
INFO - 2018-01-19 15:02:40 --> Loader Class Initialized
INFO - 2018-01-19 15:02:40 --> Helper loaded: url_helper
INFO - 2018-01-19 15:02:40 --> Helper loaded: form_helper
INFO - 2018-01-19 15:02:40 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:02:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:02:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:02:40 --> Form Validation Class Initialized
INFO - 2018-01-19 15:02:40 --> Model Class Initialized
INFO - 2018-01-19 15:02:40 --> Controller Class Initialized
INFO - 2018-01-19 15:02:40 --> Model Class Initialized
INFO - 2018-01-19 15:02:40 --> Model Class Initialized
INFO - 2018-01-19 15:02:40 --> Model Class Initialized
INFO - 2018-01-19 15:02:40 --> Model Class Initialized
DEBUG - 2018-01-19 15:02:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:02:40 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 15:02:40 --> Final output sent to browser
DEBUG - 2018-01-19 15:02:40 --> Total execution time: 0.1850
INFO - 2018-01-19 15:02:41 --> Config Class Initialized
INFO - 2018-01-19 15:02:41 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:02:41 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:02:41 --> Utf8 Class Initialized
INFO - 2018-01-19 15:02:41 --> URI Class Initialized
INFO - 2018-01-19 15:02:41 --> Router Class Initialized
INFO - 2018-01-19 15:02:41 --> Output Class Initialized
INFO - 2018-01-19 15:02:41 --> Security Class Initialized
DEBUG - 2018-01-19 15:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:02:41 --> Input Class Initialized
INFO - 2018-01-19 15:02:41 --> Language Class Initialized
INFO - 2018-01-19 15:02:41 --> Loader Class Initialized
INFO - 2018-01-19 15:02:41 --> Helper loaded: url_helper
INFO - 2018-01-19 15:02:41 --> Helper loaded: form_helper
INFO - 2018-01-19 15:02:41 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:02:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:02:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:02:41 --> Form Validation Class Initialized
INFO - 2018-01-19 15:02:41 --> Model Class Initialized
INFO - 2018-01-19 15:02:41 --> Controller Class Initialized
INFO - 2018-01-19 15:02:41 --> Model Class Initialized
INFO - 2018-01-19 15:02:41 --> Model Class Initialized
INFO - 2018-01-19 15:02:41 --> Model Class Initialized
INFO - 2018-01-19 15:02:41 --> Model Class Initialized
DEBUG - 2018-01-19 15:02:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:04:01 --> Config Class Initialized
INFO - 2018-01-19 15:04:01 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:04:01 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:04:01 --> Utf8 Class Initialized
INFO - 2018-01-19 15:04:01 --> URI Class Initialized
INFO - 2018-01-19 15:04:01 --> Router Class Initialized
INFO - 2018-01-19 15:04:01 --> Output Class Initialized
INFO - 2018-01-19 15:04:01 --> Security Class Initialized
DEBUG - 2018-01-19 15:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:04:01 --> Input Class Initialized
INFO - 2018-01-19 15:04:01 --> Language Class Initialized
INFO - 2018-01-19 15:04:01 --> Loader Class Initialized
INFO - 2018-01-19 15:04:01 --> Helper loaded: url_helper
INFO - 2018-01-19 15:04:01 --> Helper loaded: form_helper
INFO - 2018-01-19 15:04:01 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:04:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:04:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:04:01 --> Form Validation Class Initialized
INFO - 2018-01-19 15:04:01 --> Model Class Initialized
INFO - 2018-01-19 15:04:01 --> Controller Class Initialized
INFO - 2018-01-19 15:04:01 --> Model Class Initialized
INFO - 2018-01-19 15:04:01 --> Model Class Initialized
INFO - 2018-01-19 15:04:01 --> Model Class Initialized
INFO - 2018-01-19 15:04:01 --> Model Class Initialized
DEBUG - 2018-01-19 15:04:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:04:01 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 15:04:01 --> Final output sent to browser
DEBUG - 2018-01-19 15:04:01 --> Total execution time: 0.0688
INFO - 2018-01-19 15:04:02 --> Config Class Initialized
INFO - 2018-01-19 15:04:02 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:04:02 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:04:02 --> Utf8 Class Initialized
INFO - 2018-01-19 15:04:02 --> URI Class Initialized
INFO - 2018-01-19 15:04:02 --> Router Class Initialized
INFO - 2018-01-19 15:04:02 --> Output Class Initialized
INFO - 2018-01-19 15:04:02 --> Security Class Initialized
DEBUG - 2018-01-19 15:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:04:02 --> Input Class Initialized
INFO - 2018-01-19 15:04:02 --> Language Class Initialized
INFO - 2018-01-19 15:04:02 --> Loader Class Initialized
INFO - 2018-01-19 15:04:02 --> Helper loaded: url_helper
INFO - 2018-01-19 15:04:02 --> Helper loaded: form_helper
INFO - 2018-01-19 15:04:02 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:04:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:04:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:04:02 --> Form Validation Class Initialized
INFO - 2018-01-19 15:04:02 --> Model Class Initialized
INFO - 2018-01-19 15:04:02 --> Controller Class Initialized
INFO - 2018-01-19 15:04:02 --> Model Class Initialized
INFO - 2018-01-19 15:04:02 --> Model Class Initialized
INFO - 2018-01-19 15:04:02 --> Model Class Initialized
INFO - 2018-01-19 15:04:02 --> Model Class Initialized
DEBUG - 2018-01-19 15:04:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:04:02 --> Config Class Initialized
INFO - 2018-01-19 15:04:02 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:04:02 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:04:02 --> Utf8 Class Initialized
INFO - 2018-01-19 15:04:02 --> URI Class Initialized
INFO - 2018-01-19 15:04:02 --> Router Class Initialized
INFO - 2018-01-19 15:04:02 --> Output Class Initialized
INFO - 2018-01-19 15:04:02 --> Security Class Initialized
DEBUG - 2018-01-19 15:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:04:02 --> Input Class Initialized
INFO - 2018-01-19 15:04:02 --> Language Class Initialized
INFO - 2018-01-19 15:04:02 --> Loader Class Initialized
INFO - 2018-01-19 15:04:02 --> Helper loaded: url_helper
INFO - 2018-01-19 15:04:02 --> Helper loaded: form_helper
INFO - 2018-01-19 15:04:02 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:04:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:04:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:04:02 --> Form Validation Class Initialized
INFO - 2018-01-19 15:04:02 --> Model Class Initialized
INFO - 2018-01-19 15:04:02 --> Controller Class Initialized
INFO - 2018-01-19 15:04:02 --> Model Class Initialized
INFO - 2018-01-19 15:04:02 --> Model Class Initialized
INFO - 2018-01-19 15:04:02 --> Model Class Initialized
INFO - 2018-01-19 15:04:02 --> Model Class Initialized
DEBUG - 2018-01-19 15:04:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:21:42 --> Config Class Initialized
INFO - 2018-01-19 15:21:42 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:21:42 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:21:42 --> Utf8 Class Initialized
INFO - 2018-01-19 15:21:42 --> URI Class Initialized
INFO - 2018-01-19 15:21:42 --> Router Class Initialized
INFO - 2018-01-19 15:21:42 --> Output Class Initialized
INFO - 2018-01-19 15:21:42 --> Security Class Initialized
DEBUG - 2018-01-19 15:21:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:21:42 --> Input Class Initialized
INFO - 2018-01-19 15:21:42 --> Language Class Initialized
INFO - 2018-01-19 15:21:42 --> Loader Class Initialized
INFO - 2018-01-19 15:21:42 --> Helper loaded: url_helper
INFO - 2018-01-19 15:21:42 --> Helper loaded: form_helper
INFO - 2018-01-19 15:21:42 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:21:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:21:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:21:42 --> Form Validation Class Initialized
INFO - 2018-01-19 15:21:42 --> Model Class Initialized
INFO - 2018-01-19 15:21:42 --> Controller Class Initialized
INFO - 2018-01-19 15:21:42 --> Model Class Initialized
INFO - 2018-01-19 15:21:42 --> Model Class Initialized
DEBUG - 2018-01-19 15:21:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:21:42 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 15:21:42 --> Final output sent to browser
DEBUG - 2018-01-19 15:21:42 --> Total execution time: 0.0416
INFO - 2018-01-19 15:21:43 --> Config Class Initialized
INFO - 2018-01-19 15:21:43 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:21:43 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:21:43 --> Utf8 Class Initialized
INFO - 2018-01-19 15:21:43 --> URI Class Initialized
INFO - 2018-01-19 15:21:43 --> Router Class Initialized
INFO - 2018-01-19 15:21:43 --> Output Class Initialized
INFO - 2018-01-19 15:21:43 --> Security Class Initialized
DEBUG - 2018-01-19 15:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:21:43 --> Input Class Initialized
INFO - 2018-01-19 15:21:43 --> Language Class Initialized
INFO - 2018-01-19 15:21:43 --> Loader Class Initialized
INFO - 2018-01-19 15:21:43 --> Helper loaded: url_helper
INFO - 2018-01-19 15:21:43 --> Helper loaded: form_helper
INFO - 2018-01-19 15:21:43 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:21:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:21:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:21:43 --> Form Validation Class Initialized
INFO - 2018-01-19 15:21:43 --> Model Class Initialized
INFO - 2018-01-19 15:21:43 --> Controller Class Initialized
INFO - 2018-01-19 15:21:43 --> Model Class Initialized
INFO - 2018-01-19 15:21:43 --> Model Class Initialized
DEBUG - 2018-01-19 15:21:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:21:47 --> Config Class Initialized
INFO - 2018-01-19 15:21:47 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:21:47 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:21:47 --> Utf8 Class Initialized
INFO - 2018-01-19 15:21:47 --> URI Class Initialized
INFO - 2018-01-19 15:21:47 --> Router Class Initialized
INFO - 2018-01-19 15:21:47 --> Output Class Initialized
INFO - 2018-01-19 15:21:47 --> Security Class Initialized
DEBUG - 2018-01-19 15:21:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:21:47 --> Input Class Initialized
INFO - 2018-01-19 15:21:47 --> Language Class Initialized
INFO - 2018-01-19 15:21:47 --> Loader Class Initialized
INFO - 2018-01-19 15:21:47 --> Helper loaded: url_helper
INFO - 2018-01-19 15:21:47 --> Helper loaded: form_helper
INFO - 2018-01-19 15:21:47 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:21:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:21:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:21:47 --> Form Validation Class Initialized
INFO - 2018-01-19 15:21:47 --> Model Class Initialized
INFO - 2018-01-19 15:21:47 --> Controller Class Initialized
INFO - 2018-01-19 15:21:47 --> Model Class Initialized
INFO - 2018-01-19 15:21:47 --> Model Class Initialized
DEBUG - 2018-01-19 15:21:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:21:47 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 15:21:47 --> Final output sent to browser
DEBUG - 2018-01-19 15:21:47 --> Total execution time: 0.0435
INFO - 2018-01-19 15:30:26 --> Config Class Initialized
INFO - 2018-01-19 15:30:26 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:30:26 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:30:26 --> Utf8 Class Initialized
INFO - 2018-01-19 15:30:26 --> URI Class Initialized
INFO - 2018-01-19 15:30:26 --> Router Class Initialized
INFO - 2018-01-19 15:30:26 --> Output Class Initialized
INFO - 2018-01-19 15:30:26 --> Security Class Initialized
DEBUG - 2018-01-19 15:30:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:30:26 --> Input Class Initialized
INFO - 2018-01-19 15:30:26 --> Language Class Initialized
INFO - 2018-01-19 15:30:26 --> Loader Class Initialized
INFO - 2018-01-19 15:30:26 --> Helper loaded: url_helper
INFO - 2018-01-19 15:30:26 --> Helper loaded: form_helper
INFO - 2018-01-19 15:30:26 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:30:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:30:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:30:26 --> Form Validation Class Initialized
INFO - 2018-01-19 15:30:26 --> Model Class Initialized
INFO - 2018-01-19 15:30:26 --> Controller Class Initialized
INFO - 2018-01-19 15:30:26 --> Model Class Initialized
INFO - 2018-01-19 15:30:26 --> Model Class Initialized
DEBUG - 2018-01-19 15:30:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:30:26 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 15:30:26 --> Final output sent to browser
DEBUG - 2018-01-19 15:30:26 --> Total execution time: 0.0692
INFO - 2018-01-19 15:30:31 --> Config Class Initialized
INFO - 2018-01-19 15:30:31 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:30:31 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:30:31 --> Utf8 Class Initialized
INFO - 2018-01-19 15:30:31 --> URI Class Initialized
INFO - 2018-01-19 15:30:31 --> Router Class Initialized
INFO - 2018-01-19 15:30:31 --> Output Class Initialized
INFO - 2018-01-19 15:30:31 --> Security Class Initialized
DEBUG - 2018-01-19 15:30:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:30:31 --> Input Class Initialized
INFO - 2018-01-19 15:30:31 --> Language Class Initialized
INFO - 2018-01-19 15:30:31 --> Loader Class Initialized
INFO - 2018-01-19 15:30:31 --> Helper loaded: url_helper
INFO - 2018-01-19 15:30:31 --> Helper loaded: form_helper
INFO - 2018-01-19 15:30:31 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:30:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:30:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:30:31 --> Form Validation Class Initialized
INFO - 2018-01-19 15:30:31 --> Model Class Initialized
INFO - 2018-01-19 15:30:31 --> Controller Class Initialized
INFO - 2018-01-19 15:30:31 --> Model Class Initialized
INFO - 2018-01-19 15:30:31 --> Model Class Initialized
DEBUG - 2018-01-19 15:30:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:30:31 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 15:30:31 --> Final output sent to browser
DEBUG - 2018-01-19 15:30:31 --> Total execution time: 0.0419
INFO - 2018-01-19 15:30:32 --> Config Class Initialized
INFO - 2018-01-19 15:30:32 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:30:32 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:30:32 --> Utf8 Class Initialized
INFO - 2018-01-19 15:30:32 --> URI Class Initialized
INFO - 2018-01-19 15:30:32 --> Router Class Initialized
INFO - 2018-01-19 15:30:32 --> Output Class Initialized
INFO - 2018-01-19 15:30:32 --> Security Class Initialized
DEBUG - 2018-01-19 15:30:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:30:32 --> Input Class Initialized
INFO - 2018-01-19 15:30:32 --> Language Class Initialized
INFO - 2018-01-19 15:30:32 --> Loader Class Initialized
INFO - 2018-01-19 15:30:32 --> Helper loaded: url_helper
INFO - 2018-01-19 15:30:32 --> Helper loaded: form_helper
INFO - 2018-01-19 15:30:32 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:30:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:30:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:30:32 --> Form Validation Class Initialized
INFO - 2018-01-19 15:30:32 --> Model Class Initialized
INFO - 2018-01-19 15:30:32 --> Controller Class Initialized
INFO - 2018-01-19 15:30:32 --> Model Class Initialized
INFO - 2018-01-19 15:30:32 --> Model Class Initialized
DEBUG - 2018-01-19 15:30:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:30:41 --> Config Class Initialized
INFO - 2018-01-19 15:30:41 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:30:41 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:30:41 --> Utf8 Class Initialized
INFO - 2018-01-19 15:30:41 --> URI Class Initialized
INFO - 2018-01-19 15:30:41 --> Router Class Initialized
INFO - 2018-01-19 15:30:41 --> Output Class Initialized
INFO - 2018-01-19 15:30:41 --> Security Class Initialized
DEBUG - 2018-01-19 15:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:30:41 --> Input Class Initialized
INFO - 2018-01-19 15:30:41 --> Language Class Initialized
INFO - 2018-01-19 15:30:41 --> Loader Class Initialized
INFO - 2018-01-19 15:30:41 --> Helper loaded: url_helper
INFO - 2018-01-19 15:30:41 --> Helper loaded: form_helper
INFO - 2018-01-19 15:30:41 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:30:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:30:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:30:41 --> Form Validation Class Initialized
INFO - 2018-01-19 15:30:41 --> Model Class Initialized
INFO - 2018-01-19 15:30:41 --> Controller Class Initialized
INFO - 2018-01-19 15:30:41 --> Model Class Initialized
INFO - 2018-01-19 15:30:41 --> Model Class Initialized
INFO - 2018-01-19 15:30:41 --> Model Class Initialized
INFO - 2018-01-19 15:30:41 --> Model Class Initialized
DEBUG - 2018-01-19 15:30:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:30:41 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 15:30:41 --> Final output sent to browser
DEBUG - 2018-01-19 15:30:41 --> Total execution time: 0.0461
INFO - 2018-01-19 15:30:41 --> Config Class Initialized
INFO - 2018-01-19 15:30:41 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:30:41 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:30:41 --> Utf8 Class Initialized
INFO - 2018-01-19 15:30:41 --> URI Class Initialized
INFO - 2018-01-19 15:30:41 --> Router Class Initialized
INFO - 2018-01-19 15:30:41 --> Output Class Initialized
INFO - 2018-01-19 15:30:41 --> Security Class Initialized
DEBUG - 2018-01-19 15:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:30:41 --> Input Class Initialized
INFO - 2018-01-19 15:30:41 --> Language Class Initialized
INFO - 2018-01-19 15:30:41 --> Loader Class Initialized
INFO - 2018-01-19 15:30:41 --> Helper loaded: url_helper
INFO - 2018-01-19 15:30:41 --> Helper loaded: form_helper
INFO - 2018-01-19 15:30:41 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:30:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:30:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:30:41 --> Form Validation Class Initialized
INFO - 2018-01-19 15:30:41 --> Model Class Initialized
INFO - 2018-01-19 15:30:41 --> Controller Class Initialized
INFO - 2018-01-19 15:30:41 --> Model Class Initialized
INFO - 2018-01-19 15:30:41 --> Model Class Initialized
INFO - 2018-01-19 15:30:41 --> Model Class Initialized
INFO - 2018-01-19 15:30:41 --> Model Class Initialized
DEBUG - 2018-01-19 15:30:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:30:43 --> Config Class Initialized
INFO - 2018-01-19 15:30:43 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:30:43 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:30:43 --> Utf8 Class Initialized
INFO - 2018-01-19 15:30:43 --> URI Class Initialized
INFO - 2018-01-19 15:30:43 --> Router Class Initialized
INFO - 2018-01-19 15:30:43 --> Output Class Initialized
INFO - 2018-01-19 15:30:43 --> Security Class Initialized
DEBUG - 2018-01-19 15:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:30:43 --> Input Class Initialized
INFO - 2018-01-19 15:30:43 --> Language Class Initialized
INFO - 2018-01-19 15:30:43 --> Loader Class Initialized
INFO - 2018-01-19 15:30:43 --> Helper loaded: url_helper
INFO - 2018-01-19 15:30:43 --> Helper loaded: form_helper
INFO - 2018-01-19 15:30:43 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:30:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:30:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:30:43 --> Form Validation Class Initialized
INFO - 2018-01-19 15:30:43 --> Model Class Initialized
INFO - 2018-01-19 15:30:43 --> Controller Class Initialized
INFO - 2018-01-19 15:30:43 --> Model Class Initialized
INFO - 2018-01-19 15:30:43 --> Model Class Initialized
INFO - 2018-01-19 15:30:43 --> Model Class Initialized
INFO - 2018-01-19 15:30:43 --> Model Class Initialized
DEBUG - 2018-01-19 15:30:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:30:43 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 15:30:43 --> Final output sent to browser
DEBUG - 2018-01-19 15:30:43 --> Total execution time: 0.0474
INFO - 2018-01-19 15:33:35 --> Config Class Initialized
INFO - 2018-01-19 15:33:35 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:33:35 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:33:35 --> Utf8 Class Initialized
INFO - 2018-01-19 15:33:35 --> URI Class Initialized
INFO - 2018-01-19 15:33:35 --> Router Class Initialized
INFO - 2018-01-19 15:33:35 --> Output Class Initialized
INFO - 2018-01-19 15:33:35 --> Security Class Initialized
DEBUG - 2018-01-19 15:33:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:33:35 --> Input Class Initialized
INFO - 2018-01-19 15:33:35 --> Language Class Initialized
INFO - 2018-01-19 15:33:35 --> Loader Class Initialized
INFO - 2018-01-19 15:33:35 --> Helper loaded: url_helper
INFO - 2018-01-19 15:33:35 --> Helper loaded: form_helper
INFO - 2018-01-19 15:33:35 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:33:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:33:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:33:35 --> Form Validation Class Initialized
INFO - 2018-01-19 15:33:35 --> Model Class Initialized
INFO - 2018-01-19 15:33:35 --> Controller Class Initialized
INFO - 2018-01-19 15:33:35 --> Model Class Initialized
INFO - 2018-01-19 15:33:35 --> Model Class Initialized
INFO - 2018-01-19 15:33:35 --> Model Class Initialized
INFO - 2018-01-19 15:33:35 --> Model Class Initialized
DEBUG - 2018-01-19 15:33:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:33:35 --> Final output sent to browser
DEBUG - 2018-01-19 15:33:35 --> Total execution time: 0.0546
INFO - 2018-01-19 15:33:36 --> Config Class Initialized
INFO - 2018-01-19 15:33:36 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:33:36 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:33:36 --> Utf8 Class Initialized
INFO - 2018-01-19 15:33:36 --> URI Class Initialized
INFO - 2018-01-19 15:33:36 --> Router Class Initialized
INFO - 2018-01-19 15:33:36 --> Output Class Initialized
INFO - 2018-01-19 15:33:36 --> Security Class Initialized
DEBUG - 2018-01-19 15:33:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:33:36 --> Input Class Initialized
INFO - 2018-01-19 15:33:36 --> Language Class Initialized
INFO - 2018-01-19 15:33:36 --> Loader Class Initialized
INFO - 2018-01-19 15:33:36 --> Helper loaded: url_helper
INFO - 2018-01-19 15:33:36 --> Helper loaded: form_helper
INFO - 2018-01-19 15:33:36 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:33:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:33:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:33:36 --> Form Validation Class Initialized
INFO - 2018-01-19 15:33:36 --> Model Class Initialized
INFO - 2018-01-19 15:33:36 --> Controller Class Initialized
INFO - 2018-01-19 15:33:36 --> Model Class Initialized
INFO - 2018-01-19 15:33:36 --> Model Class Initialized
INFO - 2018-01-19 15:33:36 --> Model Class Initialized
INFO - 2018-01-19 15:33:36 --> Model Class Initialized
DEBUG - 2018-01-19 15:33:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:33:38 --> Config Class Initialized
INFO - 2018-01-19 15:33:38 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:33:38 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:33:38 --> Utf8 Class Initialized
INFO - 2018-01-19 15:33:38 --> URI Class Initialized
INFO - 2018-01-19 15:33:38 --> Router Class Initialized
INFO - 2018-01-19 15:33:38 --> Output Class Initialized
INFO - 2018-01-19 15:33:38 --> Security Class Initialized
DEBUG - 2018-01-19 15:33:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:33:38 --> Input Class Initialized
INFO - 2018-01-19 15:33:38 --> Language Class Initialized
INFO - 2018-01-19 15:33:38 --> Loader Class Initialized
INFO - 2018-01-19 15:33:38 --> Helper loaded: url_helper
INFO - 2018-01-19 15:33:38 --> Helper loaded: form_helper
INFO - 2018-01-19 15:33:38 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:33:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:33:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:33:38 --> Form Validation Class Initialized
INFO - 2018-01-19 15:33:38 --> Model Class Initialized
INFO - 2018-01-19 15:33:38 --> Controller Class Initialized
INFO - 2018-01-19 15:33:38 --> Model Class Initialized
INFO - 2018-01-19 15:33:38 --> Model Class Initialized
INFO - 2018-01-19 15:33:38 --> Model Class Initialized
INFO - 2018-01-19 15:33:38 --> Model Class Initialized
DEBUG - 2018-01-19 15:33:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:33:40 --> Config Class Initialized
INFO - 2018-01-19 15:33:40 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:33:40 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:33:40 --> Utf8 Class Initialized
INFO - 2018-01-19 15:33:40 --> URI Class Initialized
INFO - 2018-01-19 15:33:40 --> Router Class Initialized
INFO - 2018-01-19 15:33:40 --> Output Class Initialized
INFO - 2018-01-19 15:33:40 --> Security Class Initialized
DEBUG - 2018-01-19 15:33:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:33:40 --> Input Class Initialized
INFO - 2018-01-19 15:33:40 --> Language Class Initialized
INFO - 2018-01-19 15:33:40 --> Loader Class Initialized
INFO - 2018-01-19 15:33:40 --> Helper loaded: url_helper
INFO - 2018-01-19 15:33:40 --> Helper loaded: form_helper
INFO - 2018-01-19 15:33:40 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:33:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:33:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:33:40 --> Form Validation Class Initialized
INFO - 2018-01-19 15:33:40 --> Model Class Initialized
INFO - 2018-01-19 15:33:40 --> Controller Class Initialized
INFO - 2018-01-19 15:33:40 --> Model Class Initialized
INFO - 2018-01-19 15:33:40 --> Model Class Initialized
INFO - 2018-01-19 15:33:40 --> Model Class Initialized
INFO - 2018-01-19 15:33:40 --> Model Class Initialized
DEBUG - 2018-01-19 15:33:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:36:46 --> Config Class Initialized
INFO - 2018-01-19 15:36:46 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:36:46 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:36:46 --> Utf8 Class Initialized
INFO - 2018-01-19 15:36:46 --> URI Class Initialized
INFO - 2018-01-19 15:36:46 --> Router Class Initialized
INFO - 2018-01-19 15:36:46 --> Output Class Initialized
INFO - 2018-01-19 15:36:46 --> Security Class Initialized
DEBUG - 2018-01-19 15:36:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:36:46 --> Input Class Initialized
INFO - 2018-01-19 15:36:46 --> Language Class Initialized
INFO - 2018-01-19 15:36:46 --> Loader Class Initialized
INFO - 2018-01-19 15:36:46 --> Helper loaded: url_helper
INFO - 2018-01-19 15:36:46 --> Helper loaded: form_helper
INFO - 2018-01-19 15:36:46 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:36:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:36:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:36:46 --> Form Validation Class Initialized
INFO - 2018-01-19 15:36:46 --> Model Class Initialized
INFO - 2018-01-19 15:36:46 --> Controller Class Initialized
INFO - 2018-01-19 15:36:46 --> Model Class Initialized
INFO - 2018-01-19 15:36:46 --> Model Class Initialized
INFO - 2018-01-19 15:36:46 --> Model Class Initialized
INFO - 2018-01-19 15:36:46 --> Model Class Initialized
DEBUG - 2018-01-19 15:36:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:36:46 --> Config Class Initialized
INFO - 2018-01-19 15:36:46 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:36:46 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:36:46 --> Utf8 Class Initialized
INFO - 2018-01-19 15:36:46 --> URI Class Initialized
INFO - 2018-01-19 15:36:46 --> Router Class Initialized
INFO - 2018-01-19 15:36:46 --> Output Class Initialized
INFO - 2018-01-19 15:36:46 --> Security Class Initialized
DEBUG - 2018-01-19 15:36:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:36:46 --> Input Class Initialized
INFO - 2018-01-19 15:36:46 --> Language Class Initialized
INFO - 2018-01-19 15:36:46 --> Loader Class Initialized
INFO - 2018-01-19 15:36:46 --> Helper loaded: url_helper
INFO - 2018-01-19 15:36:46 --> Helper loaded: form_helper
INFO - 2018-01-19 15:36:46 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:36:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:36:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:36:46 --> Form Validation Class Initialized
INFO - 2018-01-19 15:36:46 --> Model Class Initialized
INFO - 2018-01-19 15:36:46 --> Controller Class Initialized
INFO - 2018-01-19 15:36:46 --> Model Class Initialized
INFO - 2018-01-19 15:36:46 --> Model Class Initialized
INFO - 2018-01-19 15:36:46 --> Model Class Initialized
INFO - 2018-01-19 15:36:46 --> Model Class Initialized
DEBUG - 2018-01-19 15:36:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:36:46 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 15:36:46 --> Final output sent to browser
DEBUG - 2018-01-19 15:36:46 --> Total execution time: 0.0564
INFO - 2018-01-19 15:36:47 --> Config Class Initialized
INFO - 2018-01-19 15:36:47 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:36:47 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:36:47 --> Utf8 Class Initialized
INFO - 2018-01-19 15:36:47 --> URI Class Initialized
INFO - 2018-01-19 15:36:47 --> Router Class Initialized
INFO - 2018-01-19 15:36:47 --> Output Class Initialized
INFO - 2018-01-19 15:36:47 --> Security Class Initialized
DEBUG - 2018-01-19 15:36:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:36:47 --> Input Class Initialized
INFO - 2018-01-19 15:36:47 --> Language Class Initialized
INFO - 2018-01-19 15:36:47 --> Loader Class Initialized
INFO - 2018-01-19 15:36:47 --> Helper loaded: url_helper
INFO - 2018-01-19 15:36:47 --> Helper loaded: form_helper
INFO - 2018-01-19 15:36:47 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:36:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:36:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:36:47 --> Form Validation Class Initialized
INFO - 2018-01-19 15:36:47 --> Model Class Initialized
INFO - 2018-01-19 15:36:47 --> Controller Class Initialized
INFO - 2018-01-19 15:36:47 --> Model Class Initialized
INFO - 2018-01-19 15:36:47 --> Model Class Initialized
INFO - 2018-01-19 15:36:47 --> Model Class Initialized
INFO - 2018-01-19 15:36:47 --> Model Class Initialized
DEBUG - 2018-01-19 15:36:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:36:54 --> Config Class Initialized
INFO - 2018-01-19 15:36:54 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:36:54 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:36:54 --> Utf8 Class Initialized
INFO - 2018-01-19 15:36:54 --> URI Class Initialized
INFO - 2018-01-19 15:36:54 --> Router Class Initialized
INFO - 2018-01-19 15:36:54 --> Output Class Initialized
INFO - 2018-01-19 15:36:54 --> Security Class Initialized
DEBUG - 2018-01-19 15:36:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:36:54 --> Input Class Initialized
INFO - 2018-01-19 15:36:54 --> Language Class Initialized
INFO - 2018-01-19 15:36:54 --> Loader Class Initialized
INFO - 2018-01-19 15:36:54 --> Helper loaded: url_helper
INFO - 2018-01-19 15:36:54 --> Helper loaded: form_helper
INFO - 2018-01-19 15:36:54 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:36:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:36:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:36:54 --> Form Validation Class Initialized
INFO - 2018-01-19 15:36:54 --> Model Class Initialized
INFO - 2018-01-19 15:36:54 --> Controller Class Initialized
INFO - 2018-01-19 15:36:54 --> Model Class Initialized
INFO - 2018-01-19 15:36:54 --> Model Class Initialized
INFO - 2018-01-19 15:36:54 --> Model Class Initialized
INFO - 2018-01-19 15:36:54 --> Model Class Initialized
DEBUG - 2018-01-19 15:36:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:36:54 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 15:36:54 --> Final output sent to browser
DEBUG - 2018-01-19 15:36:54 --> Total execution time: 0.0536
INFO - 2018-01-19 15:36:55 --> Config Class Initialized
INFO - 2018-01-19 15:36:55 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:36:55 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:36:55 --> Utf8 Class Initialized
INFO - 2018-01-19 15:36:55 --> URI Class Initialized
INFO - 2018-01-19 15:36:55 --> Router Class Initialized
INFO - 2018-01-19 15:36:55 --> Output Class Initialized
INFO - 2018-01-19 15:36:55 --> Security Class Initialized
DEBUG - 2018-01-19 15:36:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:36:55 --> Input Class Initialized
INFO - 2018-01-19 15:36:55 --> Language Class Initialized
INFO - 2018-01-19 15:36:55 --> Loader Class Initialized
INFO - 2018-01-19 15:36:55 --> Helper loaded: url_helper
INFO - 2018-01-19 15:36:55 --> Helper loaded: form_helper
INFO - 2018-01-19 15:36:55 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:36:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:36:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:36:55 --> Form Validation Class Initialized
INFO - 2018-01-19 15:36:55 --> Model Class Initialized
INFO - 2018-01-19 15:36:55 --> Controller Class Initialized
INFO - 2018-01-19 15:36:55 --> Model Class Initialized
INFO - 2018-01-19 15:36:55 --> Model Class Initialized
INFO - 2018-01-19 15:36:55 --> Model Class Initialized
INFO - 2018-01-19 15:36:55 --> Model Class Initialized
DEBUG - 2018-01-19 15:36:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:36:55 --> Config Class Initialized
INFO - 2018-01-19 15:36:55 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:36:55 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:36:55 --> Utf8 Class Initialized
INFO - 2018-01-19 15:36:55 --> URI Class Initialized
INFO - 2018-01-19 15:36:55 --> Router Class Initialized
INFO - 2018-01-19 15:36:55 --> Output Class Initialized
INFO - 2018-01-19 15:36:55 --> Security Class Initialized
DEBUG - 2018-01-19 15:36:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:36:55 --> Input Class Initialized
INFO - 2018-01-19 15:36:55 --> Language Class Initialized
INFO - 2018-01-19 15:36:55 --> Loader Class Initialized
INFO - 2018-01-19 15:36:55 --> Helper loaded: url_helper
INFO - 2018-01-19 15:36:55 --> Helper loaded: form_helper
INFO - 2018-01-19 15:36:55 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:36:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:36:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:36:55 --> Form Validation Class Initialized
INFO - 2018-01-19 15:36:55 --> Model Class Initialized
INFO - 2018-01-19 15:36:55 --> Controller Class Initialized
INFO - 2018-01-19 15:36:55 --> Model Class Initialized
INFO - 2018-01-19 15:36:55 --> Model Class Initialized
INFO - 2018-01-19 15:36:55 --> Model Class Initialized
INFO - 2018-01-19 15:36:55 --> Model Class Initialized
DEBUG - 2018-01-19 15:36:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:38:13 --> Config Class Initialized
INFO - 2018-01-19 15:38:13 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:38:13 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:38:13 --> Utf8 Class Initialized
INFO - 2018-01-19 15:38:13 --> URI Class Initialized
INFO - 2018-01-19 15:38:13 --> Router Class Initialized
INFO - 2018-01-19 15:38:13 --> Output Class Initialized
INFO - 2018-01-19 15:38:13 --> Security Class Initialized
DEBUG - 2018-01-19 15:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:38:13 --> Input Class Initialized
INFO - 2018-01-19 15:38:13 --> Language Class Initialized
INFO - 2018-01-19 15:38:13 --> Loader Class Initialized
INFO - 2018-01-19 15:38:13 --> Helper loaded: url_helper
INFO - 2018-01-19 15:38:13 --> Helper loaded: form_helper
INFO - 2018-01-19 15:38:13 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:38:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:38:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:38:13 --> Form Validation Class Initialized
INFO - 2018-01-19 15:38:13 --> Model Class Initialized
INFO - 2018-01-19 15:38:13 --> Controller Class Initialized
INFO - 2018-01-19 15:38:13 --> Model Class Initialized
INFO - 2018-01-19 15:38:13 --> Model Class Initialized
INFO - 2018-01-19 15:38:13 --> Model Class Initialized
INFO - 2018-01-19 15:38:13 --> Model Class Initialized
DEBUG - 2018-01-19 15:38:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:38:15 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 15:38:15 --> Final output sent to browser
DEBUG - 2018-01-19 15:38:15 --> Total execution time: 1.5427
INFO - 2018-01-19 15:38:15 --> Config Class Initialized
INFO - 2018-01-19 15:38:15 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:38:15 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:38:15 --> Utf8 Class Initialized
INFO - 2018-01-19 15:38:15 --> URI Class Initialized
INFO - 2018-01-19 15:38:15 --> Router Class Initialized
INFO - 2018-01-19 15:38:15 --> Output Class Initialized
INFO - 2018-01-19 15:38:15 --> Security Class Initialized
DEBUG - 2018-01-19 15:38:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:38:15 --> Input Class Initialized
INFO - 2018-01-19 15:38:15 --> Language Class Initialized
INFO - 2018-01-19 15:38:15 --> Loader Class Initialized
INFO - 2018-01-19 15:38:15 --> Helper loaded: url_helper
INFO - 2018-01-19 15:38:15 --> Helper loaded: form_helper
INFO - 2018-01-19 15:38:15 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:38:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:38:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:38:15 --> Form Validation Class Initialized
INFO - 2018-01-19 15:38:15 --> Model Class Initialized
INFO - 2018-01-19 15:38:15 --> Controller Class Initialized
INFO - 2018-01-19 15:38:15 --> Model Class Initialized
INFO - 2018-01-19 15:38:15 --> Model Class Initialized
INFO - 2018-01-19 15:38:15 --> Model Class Initialized
INFO - 2018-01-19 15:38:15 --> Model Class Initialized
DEBUG - 2018-01-19 15:38:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:38:15 --> Config Class Initialized
INFO - 2018-01-19 15:38:15 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:38:15 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:38:15 --> Utf8 Class Initialized
INFO - 2018-01-19 15:38:16 --> URI Class Initialized
INFO - 2018-01-19 15:38:16 --> Router Class Initialized
INFO - 2018-01-19 15:38:16 --> Output Class Initialized
INFO - 2018-01-19 15:38:16 --> Security Class Initialized
DEBUG - 2018-01-19 15:38:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:38:16 --> Input Class Initialized
INFO - 2018-01-19 15:38:16 --> Language Class Initialized
INFO - 2018-01-19 15:38:16 --> Loader Class Initialized
INFO - 2018-01-19 15:38:16 --> Helper loaded: url_helper
INFO - 2018-01-19 15:38:16 --> Helper loaded: form_helper
INFO - 2018-01-19 15:38:16 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:38:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:38:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:38:16 --> Form Validation Class Initialized
INFO - 2018-01-19 15:38:16 --> Model Class Initialized
INFO - 2018-01-19 15:38:16 --> Controller Class Initialized
INFO - 2018-01-19 15:38:16 --> Model Class Initialized
INFO - 2018-01-19 15:38:16 --> Model Class Initialized
INFO - 2018-01-19 15:38:16 --> Model Class Initialized
INFO - 2018-01-19 15:38:16 --> Model Class Initialized
DEBUG - 2018-01-19 15:38:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:39:16 --> Config Class Initialized
INFO - 2018-01-19 15:39:16 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:39:16 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:39:16 --> Utf8 Class Initialized
INFO - 2018-01-19 15:39:16 --> URI Class Initialized
INFO - 2018-01-19 15:39:16 --> Router Class Initialized
INFO - 2018-01-19 15:39:16 --> Output Class Initialized
INFO - 2018-01-19 15:39:16 --> Security Class Initialized
DEBUG - 2018-01-19 15:39:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:39:16 --> Input Class Initialized
INFO - 2018-01-19 15:39:16 --> Language Class Initialized
INFO - 2018-01-19 15:39:16 --> Loader Class Initialized
INFO - 2018-01-19 15:39:16 --> Helper loaded: url_helper
INFO - 2018-01-19 15:39:16 --> Helper loaded: form_helper
INFO - 2018-01-19 15:39:16 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:39:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:39:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:39:16 --> Form Validation Class Initialized
INFO - 2018-01-19 15:39:16 --> Model Class Initialized
INFO - 2018-01-19 15:39:16 --> Controller Class Initialized
INFO - 2018-01-19 15:39:16 --> Model Class Initialized
INFO - 2018-01-19 15:39:16 --> Model Class Initialized
INFO - 2018-01-19 15:39:16 --> Model Class Initialized
INFO - 2018-01-19 15:39:16 --> Model Class Initialized
DEBUG - 2018-01-19 15:39:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:39:16 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 15:39:16 --> Final output sent to browser
DEBUG - 2018-01-19 15:39:16 --> Total execution time: 0.1051
INFO - 2018-01-19 15:39:16 --> Config Class Initialized
INFO - 2018-01-19 15:39:16 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:39:16 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:39:16 --> Utf8 Class Initialized
INFO - 2018-01-19 15:39:16 --> URI Class Initialized
INFO - 2018-01-19 15:39:16 --> Router Class Initialized
INFO - 2018-01-19 15:39:16 --> Output Class Initialized
INFO - 2018-01-19 15:39:16 --> Security Class Initialized
DEBUG - 2018-01-19 15:39:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:39:16 --> Input Class Initialized
INFO - 2018-01-19 15:39:16 --> Language Class Initialized
INFO - 2018-01-19 15:39:16 --> Loader Class Initialized
INFO - 2018-01-19 15:39:16 --> Helper loaded: url_helper
INFO - 2018-01-19 15:39:16 --> Helper loaded: form_helper
INFO - 2018-01-19 15:39:16 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:39:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:39:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:39:16 --> Form Validation Class Initialized
INFO - 2018-01-19 15:39:16 --> Model Class Initialized
INFO - 2018-01-19 15:39:16 --> Controller Class Initialized
INFO - 2018-01-19 15:39:16 --> Model Class Initialized
INFO - 2018-01-19 15:39:16 --> Model Class Initialized
INFO - 2018-01-19 15:39:16 --> Model Class Initialized
INFO - 2018-01-19 15:39:16 --> Model Class Initialized
DEBUG - 2018-01-19 15:39:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:39:16 --> Config Class Initialized
INFO - 2018-01-19 15:39:16 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:39:16 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:39:16 --> Utf8 Class Initialized
INFO - 2018-01-19 15:39:16 --> URI Class Initialized
INFO - 2018-01-19 15:39:16 --> Router Class Initialized
INFO - 2018-01-19 15:39:16 --> Output Class Initialized
INFO - 2018-01-19 15:39:16 --> Security Class Initialized
DEBUG - 2018-01-19 15:39:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:39:16 --> Input Class Initialized
INFO - 2018-01-19 15:39:16 --> Language Class Initialized
INFO - 2018-01-19 15:39:16 --> Loader Class Initialized
INFO - 2018-01-19 15:39:16 --> Helper loaded: url_helper
INFO - 2018-01-19 15:39:16 --> Helper loaded: form_helper
INFO - 2018-01-19 15:39:16 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:39:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:39:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:39:16 --> Form Validation Class Initialized
INFO - 2018-01-19 15:39:16 --> Model Class Initialized
INFO - 2018-01-19 15:39:16 --> Controller Class Initialized
INFO - 2018-01-19 15:39:16 --> Model Class Initialized
INFO - 2018-01-19 15:39:16 --> Model Class Initialized
INFO - 2018-01-19 15:39:16 --> Model Class Initialized
INFO - 2018-01-19 15:39:16 --> Model Class Initialized
DEBUG - 2018-01-19 15:39:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:39:45 --> Config Class Initialized
INFO - 2018-01-19 15:39:45 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:39:45 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:39:45 --> Utf8 Class Initialized
INFO - 2018-01-19 15:39:45 --> URI Class Initialized
INFO - 2018-01-19 15:39:45 --> Router Class Initialized
INFO - 2018-01-19 15:39:45 --> Output Class Initialized
INFO - 2018-01-19 15:39:45 --> Security Class Initialized
DEBUG - 2018-01-19 15:39:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:39:45 --> Input Class Initialized
INFO - 2018-01-19 15:39:45 --> Language Class Initialized
INFO - 2018-01-19 15:39:45 --> Loader Class Initialized
INFO - 2018-01-19 15:39:45 --> Helper loaded: url_helper
INFO - 2018-01-19 15:39:45 --> Helper loaded: form_helper
INFO - 2018-01-19 15:39:45 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:39:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:39:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:39:45 --> Form Validation Class Initialized
INFO - 2018-01-19 15:39:45 --> Model Class Initialized
INFO - 2018-01-19 15:39:45 --> Controller Class Initialized
INFO - 2018-01-19 15:39:45 --> Model Class Initialized
INFO - 2018-01-19 15:39:45 --> Model Class Initialized
INFO - 2018-01-19 15:39:45 --> Model Class Initialized
INFO - 2018-01-19 15:39:45 --> Model Class Initialized
DEBUG - 2018-01-19 15:39:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:39:45 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 15:39:45 --> Final output sent to browser
DEBUG - 2018-01-19 15:39:45 --> Total execution time: 0.1037
INFO - 2018-01-19 15:39:45 --> Config Class Initialized
INFO - 2018-01-19 15:39:45 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:39:45 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:39:45 --> Utf8 Class Initialized
INFO - 2018-01-19 15:39:45 --> URI Class Initialized
INFO - 2018-01-19 15:39:45 --> Router Class Initialized
INFO - 2018-01-19 15:39:45 --> Output Class Initialized
INFO - 2018-01-19 15:39:45 --> Security Class Initialized
DEBUG - 2018-01-19 15:39:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:39:45 --> Input Class Initialized
INFO - 2018-01-19 15:39:45 --> Language Class Initialized
INFO - 2018-01-19 15:39:45 --> Loader Class Initialized
INFO - 2018-01-19 15:39:45 --> Helper loaded: url_helper
INFO - 2018-01-19 15:39:45 --> Helper loaded: form_helper
INFO - 2018-01-19 15:39:45 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:39:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:39:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:39:45 --> Form Validation Class Initialized
INFO - 2018-01-19 15:39:45 --> Model Class Initialized
INFO - 2018-01-19 15:39:45 --> Controller Class Initialized
INFO - 2018-01-19 15:39:45 --> Model Class Initialized
INFO - 2018-01-19 15:39:45 --> Model Class Initialized
INFO - 2018-01-19 15:39:45 --> Model Class Initialized
INFO - 2018-01-19 15:39:45 --> Model Class Initialized
DEBUG - 2018-01-19 15:39:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:39:45 --> Config Class Initialized
INFO - 2018-01-19 15:39:45 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:39:45 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:39:45 --> Utf8 Class Initialized
INFO - 2018-01-19 15:39:45 --> URI Class Initialized
INFO - 2018-01-19 15:39:45 --> Router Class Initialized
INFO - 2018-01-19 15:39:45 --> Output Class Initialized
INFO - 2018-01-19 15:39:45 --> Security Class Initialized
DEBUG - 2018-01-19 15:39:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:39:45 --> Input Class Initialized
INFO - 2018-01-19 15:39:45 --> Language Class Initialized
INFO - 2018-01-19 15:39:45 --> Loader Class Initialized
INFO - 2018-01-19 15:39:45 --> Helper loaded: url_helper
INFO - 2018-01-19 15:39:45 --> Helper loaded: form_helper
INFO - 2018-01-19 15:39:45 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:39:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:39:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:39:45 --> Form Validation Class Initialized
INFO - 2018-01-19 15:39:45 --> Model Class Initialized
INFO - 2018-01-19 15:39:45 --> Controller Class Initialized
INFO - 2018-01-19 15:39:45 --> Model Class Initialized
INFO - 2018-01-19 15:39:45 --> Model Class Initialized
INFO - 2018-01-19 15:39:45 --> Model Class Initialized
INFO - 2018-01-19 15:39:45 --> Model Class Initialized
DEBUG - 2018-01-19 15:39:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:39:49 --> Config Class Initialized
INFO - 2018-01-19 15:39:49 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:39:49 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:39:49 --> Utf8 Class Initialized
INFO - 2018-01-19 15:39:49 --> URI Class Initialized
INFO - 2018-01-19 15:39:49 --> Router Class Initialized
INFO - 2018-01-19 15:39:49 --> Output Class Initialized
INFO - 2018-01-19 15:39:49 --> Security Class Initialized
DEBUG - 2018-01-19 15:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:39:49 --> Input Class Initialized
INFO - 2018-01-19 15:39:49 --> Language Class Initialized
INFO - 2018-01-19 15:39:49 --> Loader Class Initialized
INFO - 2018-01-19 15:39:49 --> Helper loaded: url_helper
INFO - 2018-01-19 15:39:49 --> Helper loaded: form_helper
INFO - 2018-01-19 15:39:49 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:39:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:39:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:39:49 --> Form Validation Class Initialized
INFO - 2018-01-19 15:39:49 --> Model Class Initialized
INFO - 2018-01-19 15:39:49 --> Controller Class Initialized
INFO - 2018-01-19 15:39:49 --> Model Class Initialized
INFO - 2018-01-19 15:39:49 --> Model Class Initialized
INFO - 2018-01-19 15:39:49 --> Model Class Initialized
INFO - 2018-01-19 15:39:49 --> Model Class Initialized
DEBUG - 2018-01-19 15:39:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:39:49 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 15:39:49 --> Final output sent to browser
DEBUG - 2018-01-19 15:39:49 --> Total execution time: 0.1218
INFO - 2018-01-19 15:39:50 --> Config Class Initialized
INFO - 2018-01-19 15:39:50 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:39:50 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:39:50 --> Utf8 Class Initialized
INFO - 2018-01-19 15:39:50 --> URI Class Initialized
INFO - 2018-01-19 15:39:50 --> Router Class Initialized
INFO - 2018-01-19 15:39:50 --> Output Class Initialized
INFO - 2018-01-19 15:39:50 --> Security Class Initialized
DEBUG - 2018-01-19 15:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:39:50 --> Input Class Initialized
INFO - 2018-01-19 15:39:50 --> Language Class Initialized
INFO - 2018-01-19 15:39:50 --> Loader Class Initialized
INFO - 2018-01-19 15:39:50 --> Helper loaded: url_helper
INFO - 2018-01-19 15:39:50 --> Helper loaded: form_helper
INFO - 2018-01-19 15:39:50 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:39:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:39:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:39:50 --> Form Validation Class Initialized
INFO - 2018-01-19 15:39:50 --> Model Class Initialized
INFO - 2018-01-19 15:39:50 --> Controller Class Initialized
INFO - 2018-01-19 15:39:50 --> Model Class Initialized
INFO - 2018-01-19 15:39:50 --> Model Class Initialized
INFO - 2018-01-19 15:39:50 --> Model Class Initialized
INFO - 2018-01-19 15:39:50 --> Model Class Initialized
DEBUG - 2018-01-19 15:39:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:39:51 --> Config Class Initialized
INFO - 2018-01-19 15:39:51 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:39:51 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:39:51 --> Utf8 Class Initialized
INFO - 2018-01-19 15:39:51 --> URI Class Initialized
INFO - 2018-01-19 15:39:51 --> Router Class Initialized
INFO - 2018-01-19 15:39:51 --> Output Class Initialized
INFO - 2018-01-19 15:39:51 --> Security Class Initialized
DEBUG - 2018-01-19 15:39:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:39:51 --> Input Class Initialized
INFO - 2018-01-19 15:39:51 --> Language Class Initialized
INFO - 2018-01-19 15:39:51 --> Loader Class Initialized
INFO - 2018-01-19 15:39:51 --> Helper loaded: url_helper
INFO - 2018-01-19 15:39:51 --> Helper loaded: form_helper
INFO - 2018-01-19 15:39:51 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:39:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:39:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:39:51 --> Form Validation Class Initialized
INFO - 2018-01-19 15:39:51 --> Model Class Initialized
INFO - 2018-01-19 15:39:51 --> Controller Class Initialized
INFO - 2018-01-19 15:39:51 --> Model Class Initialized
INFO - 2018-01-19 15:39:51 --> Model Class Initialized
INFO - 2018-01-19 15:39:51 --> Model Class Initialized
INFO - 2018-01-19 15:39:51 --> Model Class Initialized
DEBUG - 2018-01-19 15:39:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:39:57 --> Config Class Initialized
INFO - 2018-01-19 15:39:57 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:39:57 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:39:57 --> Utf8 Class Initialized
INFO - 2018-01-19 15:39:57 --> URI Class Initialized
INFO - 2018-01-19 15:39:57 --> Router Class Initialized
INFO - 2018-01-19 15:39:57 --> Output Class Initialized
INFO - 2018-01-19 15:39:57 --> Security Class Initialized
DEBUG - 2018-01-19 15:39:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:39:57 --> Input Class Initialized
INFO - 2018-01-19 15:39:57 --> Language Class Initialized
INFO - 2018-01-19 15:39:57 --> Loader Class Initialized
INFO - 2018-01-19 15:39:57 --> Helper loaded: url_helper
INFO - 2018-01-19 15:39:57 --> Helper loaded: form_helper
INFO - 2018-01-19 15:39:57 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:39:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:39:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:39:57 --> Form Validation Class Initialized
INFO - 2018-01-19 15:39:57 --> Model Class Initialized
INFO - 2018-01-19 15:39:57 --> Controller Class Initialized
INFO - 2018-01-19 15:39:57 --> Model Class Initialized
INFO - 2018-01-19 15:39:57 --> Model Class Initialized
INFO - 2018-01-19 15:39:57 --> Model Class Initialized
INFO - 2018-01-19 15:39:57 --> Model Class Initialized
DEBUG - 2018-01-19 15:39:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:39:57 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 15:39:57 --> Final output sent to browser
DEBUG - 2018-01-19 15:39:57 --> Total execution time: 0.0490
INFO - 2018-01-19 15:39:58 --> Config Class Initialized
INFO - 2018-01-19 15:39:58 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:39:58 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:39:58 --> Utf8 Class Initialized
INFO - 2018-01-19 15:39:58 --> URI Class Initialized
INFO - 2018-01-19 15:39:58 --> Router Class Initialized
INFO - 2018-01-19 15:39:58 --> Output Class Initialized
INFO - 2018-01-19 15:39:58 --> Security Class Initialized
DEBUG - 2018-01-19 15:39:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:39:58 --> Input Class Initialized
INFO - 2018-01-19 15:39:58 --> Language Class Initialized
INFO - 2018-01-19 15:39:58 --> Loader Class Initialized
INFO - 2018-01-19 15:39:58 --> Helper loaded: url_helper
INFO - 2018-01-19 15:39:58 --> Helper loaded: form_helper
INFO - 2018-01-19 15:39:58 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:39:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:39:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:39:58 --> Form Validation Class Initialized
INFO - 2018-01-19 15:39:58 --> Model Class Initialized
INFO - 2018-01-19 15:39:58 --> Controller Class Initialized
INFO - 2018-01-19 15:39:58 --> Model Class Initialized
INFO - 2018-01-19 15:39:58 --> Model Class Initialized
INFO - 2018-01-19 15:39:58 --> Model Class Initialized
INFO - 2018-01-19 15:39:58 --> Model Class Initialized
DEBUG - 2018-01-19 15:39:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:40:00 --> Config Class Initialized
INFO - 2018-01-19 15:40:00 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:40:00 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:40:00 --> Utf8 Class Initialized
INFO - 2018-01-19 15:40:00 --> URI Class Initialized
INFO - 2018-01-19 15:40:00 --> Router Class Initialized
INFO - 2018-01-19 15:40:00 --> Output Class Initialized
INFO - 2018-01-19 15:40:00 --> Security Class Initialized
DEBUG - 2018-01-19 15:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:40:00 --> Input Class Initialized
INFO - 2018-01-19 15:40:00 --> Language Class Initialized
INFO - 2018-01-19 15:40:00 --> Loader Class Initialized
INFO - 2018-01-19 15:40:00 --> Helper loaded: url_helper
INFO - 2018-01-19 15:40:00 --> Helper loaded: form_helper
INFO - 2018-01-19 15:40:00 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:40:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:40:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:40:00 --> Form Validation Class Initialized
INFO - 2018-01-19 15:40:00 --> Model Class Initialized
INFO - 2018-01-19 15:40:00 --> Controller Class Initialized
INFO - 2018-01-19 15:40:00 --> Model Class Initialized
INFO - 2018-01-19 15:40:00 --> Model Class Initialized
INFO - 2018-01-19 15:40:00 --> Model Class Initialized
INFO - 2018-01-19 15:40:00 --> Model Class Initialized
DEBUG - 2018-01-19 15:40:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:40:00 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 15:40:00 --> Final output sent to browser
DEBUG - 2018-01-19 15:40:00 --> Total execution time: 0.0535
INFO - 2018-01-19 15:40:00 --> Config Class Initialized
INFO - 2018-01-19 15:40:00 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:40:00 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:40:00 --> Utf8 Class Initialized
INFO - 2018-01-19 15:40:00 --> URI Class Initialized
INFO - 2018-01-19 15:40:00 --> Router Class Initialized
INFO - 2018-01-19 15:40:00 --> Output Class Initialized
INFO - 2018-01-19 15:40:00 --> Security Class Initialized
DEBUG - 2018-01-19 15:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:40:00 --> Input Class Initialized
INFO - 2018-01-19 15:40:00 --> Language Class Initialized
INFO - 2018-01-19 15:40:00 --> Loader Class Initialized
INFO - 2018-01-19 15:40:00 --> Helper loaded: url_helper
INFO - 2018-01-19 15:40:00 --> Helper loaded: form_helper
INFO - 2018-01-19 15:40:00 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:40:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:40:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:40:00 --> Form Validation Class Initialized
INFO - 2018-01-19 15:40:00 --> Model Class Initialized
INFO - 2018-01-19 15:40:00 --> Controller Class Initialized
INFO - 2018-01-19 15:40:00 --> Model Class Initialized
INFO - 2018-01-19 15:40:00 --> Model Class Initialized
INFO - 2018-01-19 15:40:00 --> Model Class Initialized
INFO - 2018-01-19 15:40:00 --> Model Class Initialized
DEBUG - 2018-01-19 15:40:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:40:06 --> Config Class Initialized
INFO - 2018-01-19 15:40:06 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:40:06 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:40:06 --> Utf8 Class Initialized
INFO - 2018-01-19 15:40:06 --> URI Class Initialized
INFO - 2018-01-19 15:40:06 --> Router Class Initialized
INFO - 2018-01-19 15:40:06 --> Output Class Initialized
INFO - 2018-01-19 15:40:06 --> Security Class Initialized
DEBUG - 2018-01-19 15:40:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:40:06 --> Input Class Initialized
INFO - 2018-01-19 15:40:06 --> Language Class Initialized
INFO - 2018-01-19 15:40:06 --> Loader Class Initialized
INFO - 2018-01-19 15:40:06 --> Helper loaded: url_helper
INFO - 2018-01-19 15:40:06 --> Helper loaded: form_helper
INFO - 2018-01-19 15:40:06 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:40:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:40:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:40:06 --> Form Validation Class Initialized
INFO - 2018-01-19 15:40:06 --> Model Class Initialized
INFO - 2018-01-19 15:40:06 --> Controller Class Initialized
INFO - 2018-01-19 15:40:06 --> Model Class Initialized
INFO - 2018-01-19 15:40:06 --> Model Class Initialized
INFO - 2018-01-19 15:40:06 --> Model Class Initialized
INFO - 2018-01-19 15:40:06 --> Model Class Initialized
DEBUG - 2018-01-19 15:40:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:40:06 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 15:40:06 --> Final output sent to browser
DEBUG - 2018-01-19 15:40:06 --> Total execution time: 0.0593
INFO - 2018-01-19 15:40:40 --> Config Class Initialized
INFO - 2018-01-19 15:40:40 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:40:40 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:40:40 --> Utf8 Class Initialized
INFO - 2018-01-19 15:40:40 --> URI Class Initialized
INFO - 2018-01-19 15:40:40 --> Router Class Initialized
INFO - 2018-01-19 15:40:40 --> Output Class Initialized
INFO - 2018-01-19 15:40:40 --> Security Class Initialized
DEBUG - 2018-01-19 15:40:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:40:40 --> Input Class Initialized
INFO - 2018-01-19 15:40:40 --> Language Class Initialized
INFO - 2018-01-19 15:40:40 --> Loader Class Initialized
INFO - 2018-01-19 15:40:40 --> Helper loaded: url_helper
INFO - 2018-01-19 15:40:40 --> Helper loaded: form_helper
INFO - 2018-01-19 15:40:40 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:40:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:40:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:40:40 --> Form Validation Class Initialized
INFO - 2018-01-19 15:40:40 --> Model Class Initialized
INFO - 2018-01-19 15:40:40 --> Controller Class Initialized
INFO - 2018-01-19 15:40:40 --> Model Class Initialized
INFO - 2018-01-19 15:40:40 --> Model Class Initialized
INFO - 2018-01-19 15:40:40 --> Model Class Initialized
INFO - 2018-01-19 15:40:40 --> Model Class Initialized
DEBUG - 2018-01-19 15:40:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:40:41 --> Config Class Initialized
INFO - 2018-01-19 15:40:41 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:40:41 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:40:41 --> Utf8 Class Initialized
INFO - 2018-01-19 15:40:41 --> URI Class Initialized
INFO - 2018-01-19 15:40:41 --> Router Class Initialized
INFO - 2018-01-19 15:40:41 --> Output Class Initialized
INFO - 2018-01-19 15:40:41 --> Security Class Initialized
DEBUG - 2018-01-19 15:40:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:40:41 --> Input Class Initialized
INFO - 2018-01-19 15:40:41 --> Language Class Initialized
INFO - 2018-01-19 15:40:41 --> Loader Class Initialized
INFO - 2018-01-19 15:40:41 --> Helper loaded: url_helper
INFO - 2018-01-19 15:40:41 --> Helper loaded: form_helper
INFO - 2018-01-19 15:40:41 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:40:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:40:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:40:41 --> Form Validation Class Initialized
INFO - 2018-01-19 15:40:41 --> Model Class Initialized
INFO - 2018-01-19 15:40:41 --> Controller Class Initialized
INFO - 2018-01-19 15:40:41 --> Model Class Initialized
INFO - 2018-01-19 15:40:41 --> Model Class Initialized
INFO - 2018-01-19 15:40:41 --> Model Class Initialized
INFO - 2018-01-19 15:40:41 --> Model Class Initialized
DEBUG - 2018-01-19 15:40:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:40:41 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 15:40:41 --> Final output sent to browser
DEBUG - 2018-01-19 15:40:41 --> Total execution time: 0.0555
INFO - 2018-01-19 15:40:41 --> Config Class Initialized
INFO - 2018-01-19 15:40:41 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:40:41 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:40:41 --> Utf8 Class Initialized
INFO - 2018-01-19 15:40:41 --> URI Class Initialized
INFO - 2018-01-19 15:40:41 --> Router Class Initialized
INFO - 2018-01-19 15:40:41 --> Output Class Initialized
INFO - 2018-01-19 15:40:41 --> Security Class Initialized
DEBUG - 2018-01-19 15:40:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:40:41 --> Input Class Initialized
INFO - 2018-01-19 15:40:41 --> Language Class Initialized
INFO - 2018-01-19 15:40:41 --> Loader Class Initialized
INFO - 2018-01-19 15:40:41 --> Helper loaded: url_helper
INFO - 2018-01-19 15:40:41 --> Helper loaded: form_helper
INFO - 2018-01-19 15:40:41 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:40:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:40:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:40:41 --> Form Validation Class Initialized
INFO - 2018-01-19 15:40:41 --> Model Class Initialized
INFO - 2018-01-19 15:40:41 --> Controller Class Initialized
INFO - 2018-01-19 15:40:41 --> Model Class Initialized
INFO - 2018-01-19 15:40:41 --> Model Class Initialized
INFO - 2018-01-19 15:40:41 --> Model Class Initialized
INFO - 2018-01-19 15:40:41 --> Model Class Initialized
DEBUG - 2018-01-19 15:40:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:40:47 --> Config Class Initialized
INFO - 2018-01-19 15:40:47 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:40:47 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:40:47 --> Utf8 Class Initialized
INFO - 2018-01-19 15:40:47 --> URI Class Initialized
INFO - 2018-01-19 15:40:47 --> Router Class Initialized
INFO - 2018-01-19 15:40:47 --> Output Class Initialized
INFO - 2018-01-19 15:40:47 --> Security Class Initialized
DEBUG - 2018-01-19 15:40:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:40:47 --> Input Class Initialized
INFO - 2018-01-19 15:40:47 --> Language Class Initialized
INFO - 2018-01-19 15:40:47 --> Loader Class Initialized
INFO - 2018-01-19 15:40:47 --> Helper loaded: url_helper
INFO - 2018-01-19 15:40:47 --> Helper loaded: form_helper
INFO - 2018-01-19 15:40:47 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:40:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:40:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:40:47 --> Form Validation Class Initialized
INFO - 2018-01-19 15:40:47 --> Model Class Initialized
INFO - 2018-01-19 15:40:47 --> Controller Class Initialized
INFO - 2018-01-19 15:40:47 --> Model Class Initialized
INFO - 2018-01-19 15:40:47 --> Model Class Initialized
INFO - 2018-01-19 15:40:47 --> Model Class Initialized
INFO - 2018-01-19 15:40:47 --> Model Class Initialized
DEBUG - 2018-01-19 15:40:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:40:47 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 15:40:47 --> Final output sent to browser
DEBUG - 2018-01-19 15:40:47 --> Total execution time: 0.0505
INFO - 2018-01-19 15:41:34 --> Config Class Initialized
INFO - 2018-01-19 15:41:34 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:41:34 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:41:34 --> Utf8 Class Initialized
INFO - 2018-01-19 15:41:34 --> URI Class Initialized
INFO - 2018-01-19 15:41:34 --> Router Class Initialized
INFO - 2018-01-19 15:41:34 --> Output Class Initialized
INFO - 2018-01-19 15:41:34 --> Security Class Initialized
DEBUG - 2018-01-19 15:41:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:41:34 --> Input Class Initialized
INFO - 2018-01-19 15:41:34 --> Language Class Initialized
INFO - 2018-01-19 15:41:34 --> Loader Class Initialized
INFO - 2018-01-19 15:41:34 --> Helper loaded: url_helper
INFO - 2018-01-19 15:41:34 --> Helper loaded: form_helper
INFO - 2018-01-19 15:41:34 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:41:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:41:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:41:34 --> Form Validation Class Initialized
INFO - 2018-01-19 15:41:34 --> Model Class Initialized
INFO - 2018-01-19 15:41:34 --> Controller Class Initialized
INFO - 2018-01-19 15:41:34 --> Model Class Initialized
INFO - 2018-01-19 15:41:34 --> Model Class Initialized
INFO - 2018-01-19 15:41:34 --> Model Class Initialized
INFO - 2018-01-19 15:41:34 --> Model Class Initialized
DEBUG - 2018-01-19 15:41:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:41:35 --> Config Class Initialized
INFO - 2018-01-19 15:41:35 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:41:35 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:41:35 --> Utf8 Class Initialized
INFO - 2018-01-19 15:41:35 --> URI Class Initialized
INFO - 2018-01-19 15:41:35 --> Router Class Initialized
INFO - 2018-01-19 15:41:35 --> Output Class Initialized
INFO - 2018-01-19 15:41:35 --> Security Class Initialized
DEBUG - 2018-01-19 15:41:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:41:35 --> Input Class Initialized
INFO - 2018-01-19 15:41:35 --> Language Class Initialized
INFO - 2018-01-19 15:41:35 --> Loader Class Initialized
INFO - 2018-01-19 15:41:35 --> Helper loaded: url_helper
INFO - 2018-01-19 15:41:35 --> Helper loaded: form_helper
INFO - 2018-01-19 15:41:35 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:41:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:41:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:41:35 --> Form Validation Class Initialized
INFO - 2018-01-19 15:41:35 --> Model Class Initialized
INFO - 2018-01-19 15:41:35 --> Controller Class Initialized
INFO - 2018-01-19 15:41:35 --> Model Class Initialized
INFO - 2018-01-19 15:41:35 --> Model Class Initialized
INFO - 2018-01-19 15:41:35 --> Model Class Initialized
INFO - 2018-01-19 15:41:35 --> Model Class Initialized
DEBUG - 2018-01-19 15:41:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:41:35 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 15:41:35 --> Final output sent to browser
DEBUG - 2018-01-19 15:41:35 --> Total execution time: 0.0567
INFO - 2018-01-19 15:41:35 --> Config Class Initialized
INFO - 2018-01-19 15:41:35 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:41:35 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:41:35 --> Utf8 Class Initialized
INFO - 2018-01-19 15:41:35 --> URI Class Initialized
INFO - 2018-01-19 15:41:35 --> Router Class Initialized
INFO - 2018-01-19 15:41:35 --> Output Class Initialized
INFO - 2018-01-19 15:41:35 --> Security Class Initialized
DEBUG - 2018-01-19 15:41:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:41:35 --> Input Class Initialized
INFO - 2018-01-19 15:41:35 --> Language Class Initialized
INFO - 2018-01-19 15:41:35 --> Loader Class Initialized
INFO - 2018-01-19 15:41:35 --> Helper loaded: url_helper
INFO - 2018-01-19 15:41:35 --> Helper loaded: form_helper
INFO - 2018-01-19 15:41:35 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:41:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:41:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:41:35 --> Form Validation Class Initialized
INFO - 2018-01-19 15:41:35 --> Model Class Initialized
INFO - 2018-01-19 15:41:35 --> Controller Class Initialized
INFO - 2018-01-19 15:41:35 --> Model Class Initialized
INFO - 2018-01-19 15:41:35 --> Model Class Initialized
INFO - 2018-01-19 15:41:35 --> Model Class Initialized
INFO - 2018-01-19 15:41:35 --> Model Class Initialized
DEBUG - 2018-01-19 15:41:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:41:39 --> Config Class Initialized
INFO - 2018-01-19 15:41:39 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:41:39 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:41:39 --> Utf8 Class Initialized
INFO - 2018-01-19 15:41:39 --> URI Class Initialized
INFO - 2018-01-19 15:41:39 --> Router Class Initialized
INFO - 2018-01-19 15:41:39 --> Output Class Initialized
INFO - 2018-01-19 15:41:39 --> Security Class Initialized
DEBUG - 2018-01-19 15:41:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:41:39 --> Input Class Initialized
INFO - 2018-01-19 15:41:39 --> Language Class Initialized
INFO - 2018-01-19 15:41:39 --> Loader Class Initialized
INFO - 2018-01-19 15:41:39 --> Helper loaded: url_helper
INFO - 2018-01-19 15:41:39 --> Helper loaded: form_helper
INFO - 2018-01-19 15:41:39 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:41:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:41:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:41:39 --> Form Validation Class Initialized
INFO - 2018-01-19 15:41:39 --> Model Class Initialized
INFO - 2018-01-19 15:41:39 --> Controller Class Initialized
INFO - 2018-01-19 15:41:39 --> Model Class Initialized
INFO - 2018-01-19 15:41:39 --> Model Class Initialized
INFO - 2018-01-19 15:41:39 --> Model Class Initialized
INFO - 2018-01-19 15:41:39 --> Model Class Initialized
DEBUG - 2018-01-19 15:41:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:41:39 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 15:41:39 --> Final output sent to browser
DEBUG - 2018-01-19 15:41:39 --> Total execution time: 0.0512
INFO - 2018-01-19 15:42:14 --> Config Class Initialized
INFO - 2018-01-19 15:42:14 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:42:14 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:42:14 --> Utf8 Class Initialized
INFO - 2018-01-19 15:42:14 --> URI Class Initialized
INFO - 2018-01-19 15:42:14 --> Router Class Initialized
INFO - 2018-01-19 15:42:14 --> Output Class Initialized
INFO - 2018-01-19 15:42:14 --> Security Class Initialized
DEBUG - 2018-01-19 15:42:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:42:14 --> Input Class Initialized
INFO - 2018-01-19 15:42:14 --> Language Class Initialized
INFO - 2018-01-19 15:42:14 --> Loader Class Initialized
INFO - 2018-01-19 15:42:14 --> Helper loaded: url_helper
INFO - 2018-01-19 15:42:14 --> Helper loaded: form_helper
INFO - 2018-01-19 15:42:14 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:42:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:42:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:42:14 --> Form Validation Class Initialized
INFO - 2018-01-19 15:42:14 --> Model Class Initialized
INFO - 2018-01-19 15:42:14 --> Controller Class Initialized
INFO - 2018-01-19 15:42:14 --> Model Class Initialized
INFO - 2018-01-19 15:42:14 --> Model Class Initialized
DEBUG - 2018-01-19 15:42:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:42:14 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 15:42:14 --> Final output sent to browser
DEBUG - 2018-01-19 15:42:14 --> Total execution time: 0.0418
INFO - 2018-01-19 15:42:15 --> Config Class Initialized
INFO - 2018-01-19 15:42:15 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:42:15 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:42:15 --> Utf8 Class Initialized
INFO - 2018-01-19 15:42:15 --> URI Class Initialized
INFO - 2018-01-19 15:42:15 --> Router Class Initialized
INFO - 2018-01-19 15:42:15 --> Output Class Initialized
INFO - 2018-01-19 15:42:15 --> Security Class Initialized
DEBUG - 2018-01-19 15:42:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:42:15 --> Input Class Initialized
INFO - 2018-01-19 15:42:15 --> Language Class Initialized
INFO - 2018-01-19 15:42:15 --> Loader Class Initialized
INFO - 2018-01-19 15:42:15 --> Helper loaded: url_helper
INFO - 2018-01-19 15:42:15 --> Helper loaded: form_helper
INFO - 2018-01-19 15:42:15 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:42:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:42:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:42:15 --> Form Validation Class Initialized
INFO - 2018-01-19 15:42:15 --> Model Class Initialized
INFO - 2018-01-19 15:42:15 --> Controller Class Initialized
INFO - 2018-01-19 15:42:15 --> Model Class Initialized
INFO - 2018-01-19 15:42:15 --> Model Class Initialized
DEBUG - 2018-01-19 15:42:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:42:18 --> Config Class Initialized
INFO - 2018-01-19 15:42:18 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:42:18 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:42:18 --> Utf8 Class Initialized
INFO - 2018-01-19 15:42:18 --> URI Class Initialized
INFO - 2018-01-19 15:42:18 --> Router Class Initialized
INFO - 2018-01-19 15:42:18 --> Output Class Initialized
INFO - 2018-01-19 15:42:18 --> Security Class Initialized
DEBUG - 2018-01-19 15:42:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:42:18 --> Input Class Initialized
INFO - 2018-01-19 15:42:18 --> Language Class Initialized
INFO - 2018-01-19 15:42:18 --> Loader Class Initialized
INFO - 2018-01-19 15:42:18 --> Helper loaded: url_helper
INFO - 2018-01-19 15:42:18 --> Helper loaded: form_helper
INFO - 2018-01-19 15:42:18 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:42:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:42:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:42:18 --> Form Validation Class Initialized
INFO - 2018-01-19 15:42:18 --> Model Class Initialized
INFO - 2018-01-19 15:42:18 --> Controller Class Initialized
INFO - 2018-01-19 15:42:18 --> Model Class Initialized
INFO - 2018-01-19 15:42:18 --> Model Class Initialized
DEBUG - 2018-01-19 15:42:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:42:18 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 15:42:18 --> Final output sent to browser
DEBUG - 2018-01-19 15:42:18 --> Total execution time: 0.0397
INFO - 2018-01-19 15:42:34 --> Config Class Initialized
INFO - 2018-01-19 15:42:34 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:42:34 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:42:34 --> Utf8 Class Initialized
INFO - 2018-01-19 15:42:34 --> URI Class Initialized
INFO - 2018-01-19 15:42:34 --> Router Class Initialized
INFO - 2018-01-19 15:42:34 --> Output Class Initialized
INFO - 2018-01-19 15:42:34 --> Security Class Initialized
DEBUG - 2018-01-19 15:42:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:42:34 --> Input Class Initialized
INFO - 2018-01-19 15:42:34 --> Language Class Initialized
INFO - 2018-01-19 15:42:34 --> Loader Class Initialized
INFO - 2018-01-19 15:42:34 --> Helper loaded: url_helper
INFO - 2018-01-19 15:42:34 --> Helper loaded: form_helper
INFO - 2018-01-19 15:42:34 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:42:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:42:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:42:34 --> Form Validation Class Initialized
INFO - 2018-01-19 15:42:34 --> Model Class Initialized
INFO - 2018-01-19 15:42:34 --> Controller Class Initialized
INFO - 2018-01-19 15:42:34 --> Model Class Initialized
INFO - 2018-01-19 15:42:34 --> Model Class Initialized
DEBUG - 2018-01-19 15:42:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:42:34 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 15:42:34 --> Final output sent to browser
DEBUG - 2018-01-19 15:42:34 --> Total execution time: 0.0464
INFO - 2018-01-19 15:42:39 --> Config Class Initialized
INFO - 2018-01-19 15:42:39 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:42:39 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:42:39 --> Utf8 Class Initialized
INFO - 2018-01-19 15:42:39 --> URI Class Initialized
INFO - 2018-01-19 15:42:39 --> Router Class Initialized
INFO - 2018-01-19 15:42:39 --> Output Class Initialized
INFO - 2018-01-19 15:42:39 --> Security Class Initialized
DEBUG - 2018-01-19 15:42:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:42:39 --> Input Class Initialized
INFO - 2018-01-19 15:42:39 --> Language Class Initialized
INFO - 2018-01-19 15:42:39 --> Loader Class Initialized
INFO - 2018-01-19 15:42:39 --> Helper loaded: url_helper
INFO - 2018-01-19 15:42:39 --> Helper loaded: form_helper
INFO - 2018-01-19 15:42:39 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:42:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:42:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:42:39 --> Form Validation Class Initialized
INFO - 2018-01-19 15:42:39 --> Model Class Initialized
INFO - 2018-01-19 15:42:39 --> Controller Class Initialized
INFO - 2018-01-19 15:42:39 --> Model Class Initialized
INFO - 2018-01-19 15:42:39 --> Model Class Initialized
INFO - 2018-01-19 15:42:39 --> Model Class Initialized
INFO - 2018-01-19 15:42:39 --> Model Class Initialized
DEBUG - 2018-01-19 15:42:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:42:39 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 15:42:39 --> Final output sent to browser
DEBUG - 2018-01-19 15:42:39 --> Total execution time: 0.0462
INFO - 2018-01-19 15:42:40 --> Config Class Initialized
INFO - 2018-01-19 15:42:40 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:42:40 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:42:40 --> Utf8 Class Initialized
INFO - 2018-01-19 15:42:40 --> URI Class Initialized
INFO - 2018-01-19 15:42:40 --> Router Class Initialized
INFO - 2018-01-19 15:42:40 --> Output Class Initialized
INFO - 2018-01-19 15:42:40 --> Security Class Initialized
DEBUG - 2018-01-19 15:42:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:42:40 --> Input Class Initialized
INFO - 2018-01-19 15:42:40 --> Language Class Initialized
INFO - 2018-01-19 15:42:40 --> Loader Class Initialized
INFO - 2018-01-19 15:42:40 --> Helper loaded: url_helper
INFO - 2018-01-19 15:42:40 --> Helper loaded: form_helper
INFO - 2018-01-19 15:42:40 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:42:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:42:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:42:40 --> Form Validation Class Initialized
INFO - 2018-01-19 15:42:40 --> Model Class Initialized
INFO - 2018-01-19 15:42:40 --> Controller Class Initialized
INFO - 2018-01-19 15:42:40 --> Model Class Initialized
INFO - 2018-01-19 15:42:40 --> Model Class Initialized
INFO - 2018-01-19 15:42:40 --> Model Class Initialized
INFO - 2018-01-19 15:42:40 --> Model Class Initialized
DEBUG - 2018-01-19 15:42:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:42:43 --> Config Class Initialized
INFO - 2018-01-19 15:42:43 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:42:43 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:42:43 --> Utf8 Class Initialized
INFO - 2018-01-19 15:42:43 --> URI Class Initialized
INFO - 2018-01-19 15:42:43 --> Router Class Initialized
INFO - 2018-01-19 15:42:43 --> Output Class Initialized
INFO - 2018-01-19 15:42:43 --> Security Class Initialized
DEBUG - 2018-01-19 15:42:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:42:43 --> Input Class Initialized
INFO - 2018-01-19 15:42:43 --> Language Class Initialized
INFO - 2018-01-19 15:42:43 --> Loader Class Initialized
INFO - 2018-01-19 15:42:43 --> Helper loaded: url_helper
INFO - 2018-01-19 15:42:43 --> Helper loaded: form_helper
INFO - 2018-01-19 15:42:43 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:42:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:42:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:42:43 --> Form Validation Class Initialized
INFO - 2018-01-19 15:42:43 --> Model Class Initialized
INFO - 2018-01-19 15:42:43 --> Controller Class Initialized
INFO - 2018-01-19 15:42:43 --> Model Class Initialized
INFO - 2018-01-19 15:42:43 --> Model Class Initialized
INFO - 2018-01-19 15:42:43 --> Model Class Initialized
INFO - 2018-01-19 15:42:43 --> Model Class Initialized
DEBUG - 2018-01-19 15:42:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:42:43 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 15:42:43 --> Final output sent to browser
DEBUG - 2018-01-19 15:42:43 --> Total execution time: 0.0548
INFO - 2018-01-19 15:42:43 --> Config Class Initialized
INFO - 2018-01-19 15:42:43 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:42:43 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:42:43 --> Utf8 Class Initialized
INFO - 2018-01-19 15:42:43 --> URI Class Initialized
INFO - 2018-01-19 15:42:43 --> Router Class Initialized
INFO - 2018-01-19 15:42:43 --> Output Class Initialized
INFO - 2018-01-19 15:42:43 --> Security Class Initialized
DEBUG - 2018-01-19 15:42:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:42:43 --> Input Class Initialized
INFO - 2018-01-19 15:42:43 --> Language Class Initialized
INFO - 2018-01-19 15:42:43 --> Loader Class Initialized
INFO - 2018-01-19 15:42:43 --> Helper loaded: url_helper
INFO - 2018-01-19 15:42:43 --> Helper loaded: form_helper
INFO - 2018-01-19 15:42:43 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:42:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:42:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:42:43 --> Form Validation Class Initialized
INFO - 2018-01-19 15:42:43 --> Model Class Initialized
INFO - 2018-01-19 15:42:43 --> Controller Class Initialized
INFO - 2018-01-19 15:42:43 --> Model Class Initialized
INFO - 2018-01-19 15:42:43 --> Model Class Initialized
INFO - 2018-01-19 15:42:43 --> Model Class Initialized
INFO - 2018-01-19 15:42:43 --> Model Class Initialized
DEBUG - 2018-01-19 15:42:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:42:46 --> Config Class Initialized
INFO - 2018-01-19 15:42:46 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:42:46 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:42:46 --> Utf8 Class Initialized
INFO - 2018-01-19 15:42:46 --> URI Class Initialized
INFO - 2018-01-19 15:42:46 --> Router Class Initialized
INFO - 2018-01-19 15:42:46 --> Output Class Initialized
INFO - 2018-01-19 15:42:46 --> Security Class Initialized
DEBUG - 2018-01-19 15:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:42:46 --> Input Class Initialized
INFO - 2018-01-19 15:42:46 --> Language Class Initialized
INFO - 2018-01-19 15:42:46 --> Loader Class Initialized
INFO - 2018-01-19 15:42:46 --> Helper loaded: url_helper
INFO - 2018-01-19 15:42:46 --> Helper loaded: form_helper
INFO - 2018-01-19 15:42:46 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:42:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:42:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:42:46 --> Form Validation Class Initialized
INFO - 2018-01-19 15:42:46 --> Model Class Initialized
INFO - 2018-01-19 15:42:46 --> Controller Class Initialized
INFO - 2018-01-19 15:42:46 --> Model Class Initialized
INFO - 2018-01-19 15:42:46 --> Model Class Initialized
INFO - 2018-01-19 15:42:46 --> Model Class Initialized
INFO - 2018-01-19 15:42:46 --> Model Class Initialized
DEBUG - 2018-01-19 15:42:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:42:46 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 15:42:46 --> Final output sent to browser
DEBUG - 2018-01-19 15:42:46 --> Total execution time: 0.0546
INFO - 2018-01-19 15:42:46 --> Config Class Initialized
INFO - 2018-01-19 15:42:46 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:42:46 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:42:46 --> Utf8 Class Initialized
INFO - 2018-01-19 15:42:46 --> URI Class Initialized
INFO - 2018-01-19 15:42:46 --> Router Class Initialized
INFO - 2018-01-19 15:42:46 --> Output Class Initialized
INFO - 2018-01-19 15:42:46 --> Security Class Initialized
DEBUG - 2018-01-19 15:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:42:46 --> Input Class Initialized
INFO - 2018-01-19 15:42:46 --> Language Class Initialized
INFO - 2018-01-19 15:42:46 --> Loader Class Initialized
INFO - 2018-01-19 15:42:46 --> Helper loaded: url_helper
INFO - 2018-01-19 15:42:46 --> Helper loaded: form_helper
INFO - 2018-01-19 15:42:46 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:42:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:42:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:42:46 --> Form Validation Class Initialized
INFO - 2018-01-19 15:42:46 --> Model Class Initialized
INFO - 2018-01-19 15:42:46 --> Controller Class Initialized
INFO - 2018-01-19 15:42:46 --> Model Class Initialized
INFO - 2018-01-19 15:42:46 --> Model Class Initialized
INFO - 2018-01-19 15:42:46 --> Model Class Initialized
INFO - 2018-01-19 15:42:46 --> Model Class Initialized
DEBUG - 2018-01-19 15:42:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:42:51 --> Config Class Initialized
INFO - 2018-01-19 15:42:51 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:42:51 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:42:51 --> Utf8 Class Initialized
INFO - 2018-01-19 15:42:51 --> URI Class Initialized
INFO - 2018-01-19 15:42:51 --> Router Class Initialized
INFO - 2018-01-19 15:42:51 --> Output Class Initialized
INFO - 2018-01-19 15:42:51 --> Security Class Initialized
DEBUG - 2018-01-19 15:42:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:42:51 --> Input Class Initialized
INFO - 2018-01-19 15:42:51 --> Language Class Initialized
INFO - 2018-01-19 15:42:51 --> Loader Class Initialized
INFO - 2018-01-19 15:42:51 --> Helper loaded: url_helper
INFO - 2018-01-19 15:42:51 --> Helper loaded: form_helper
INFO - 2018-01-19 15:42:51 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:42:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:42:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:42:51 --> Form Validation Class Initialized
INFO - 2018-01-19 15:42:51 --> Model Class Initialized
INFO - 2018-01-19 15:42:51 --> Controller Class Initialized
INFO - 2018-01-19 15:42:51 --> Model Class Initialized
INFO - 2018-01-19 15:42:51 --> Model Class Initialized
INFO - 2018-01-19 15:42:51 --> Model Class Initialized
INFO - 2018-01-19 15:42:51 --> Model Class Initialized
DEBUG - 2018-01-19 15:42:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:42:51 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 15:42:51 --> Final output sent to browser
DEBUG - 2018-01-19 15:42:51 --> Total execution time: 0.0585
INFO - 2018-01-19 15:43:10 --> Config Class Initialized
INFO - 2018-01-19 15:43:10 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:43:10 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:43:10 --> Utf8 Class Initialized
INFO - 2018-01-19 15:43:10 --> URI Class Initialized
INFO - 2018-01-19 15:43:10 --> Router Class Initialized
INFO - 2018-01-19 15:43:10 --> Output Class Initialized
INFO - 2018-01-19 15:43:10 --> Security Class Initialized
DEBUG - 2018-01-19 15:43:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:43:10 --> Input Class Initialized
INFO - 2018-01-19 15:43:10 --> Language Class Initialized
INFO - 2018-01-19 15:43:10 --> Loader Class Initialized
INFO - 2018-01-19 15:43:10 --> Helper loaded: url_helper
INFO - 2018-01-19 15:43:10 --> Helper loaded: form_helper
INFO - 2018-01-19 15:43:10 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:43:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:43:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:43:10 --> Form Validation Class Initialized
INFO - 2018-01-19 15:43:10 --> Model Class Initialized
INFO - 2018-01-19 15:43:10 --> Controller Class Initialized
INFO - 2018-01-19 15:43:10 --> Model Class Initialized
INFO - 2018-01-19 15:43:10 --> Model Class Initialized
INFO - 2018-01-19 15:43:10 --> Model Class Initialized
INFO - 2018-01-19 15:43:10 --> Model Class Initialized
DEBUG - 2018-01-19 15:43:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:43:11 --> Config Class Initialized
INFO - 2018-01-19 15:43:11 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:43:11 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:43:11 --> Utf8 Class Initialized
INFO - 2018-01-19 15:43:11 --> URI Class Initialized
INFO - 2018-01-19 15:43:11 --> Router Class Initialized
INFO - 2018-01-19 15:43:11 --> Output Class Initialized
INFO - 2018-01-19 15:43:11 --> Security Class Initialized
DEBUG - 2018-01-19 15:43:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:43:11 --> Input Class Initialized
INFO - 2018-01-19 15:43:11 --> Language Class Initialized
INFO - 2018-01-19 15:43:11 --> Loader Class Initialized
INFO - 2018-01-19 15:43:11 --> Helper loaded: url_helper
INFO - 2018-01-19 15:43:11 --> Helper loaded: form_helper
INFO - 2018-01-19 15:43:11 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:43:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:43:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:43:11 --> Form Validation Class Initialized
INFO - 2018-01-19 15:43:11 --> Model Class Initialized
INFO - 2018-01-19 15:43:11 --> Controller Class Initialized
INFO - 2018-01-19 15:43:11 --> Model Class Initialized
INFO - 2018-01-19 15:43:11 --> Model Class Initialized
INFO - 2018-01-19 15:43:11 --> Model Class Initialized
INFO - 2018-01-19 15:43:11 --> Model Class Initialized
DEBUG - 2018-01-19 15:43:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:43:11 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 15:43:11 --> Final output sent to browser
DEBUG - 2018-01-19 15:43:11 --> Total execution time: 0.0537
INFO - 2018-01-19 15:43:11 --> Config Class Initialized
INFO - 2018-01-19 15:43:11 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:43:11 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:43:11 --> Utf8 Class Initialized
INFO - 2018-01-19 15:43:11 --> URI Class Initialized
INFO - 2018-01-19 15:43:11 --> Router Class Initialized
INFO - 2018-01-19 15:43:11 --> Output Class Initialized
INFO - 2018-01-19 15:43:11 --> Security Class Initialized
DEBUG - 2018-01-19 15:43:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:43:11 --> Input Class Initialized
INFO - 2018-01-19 15:43:11 --> Language Class Initialized
INFO - 2018-01-19 15:43:11 --> Loader Class Initialized
INFO - 2018-01-19 15:43:11 --> Helper loaded: url_helper
INFO - 2018-01-19 15:43:11 --> Helper loaded: form_helper
INFO - 2018-01-19 15:43:11 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:43:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:43:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:43:11 --> Form Validation Class Initialized
INFO - 2018-01-19 15:43:11 --> Model Class Initialized
INFO - 2018-01-19 15:43:11 --> Controller Class Initialized
INFO - 2018-01-19 15:43:11 --> Model Class Initialized
INFO - 2018-01-19 15:43:11 --> Model Class Initialized
INFO - 2018-01-19 15:43:11 --> Model Class Initialized
INFO - 2018-01-19 15:43:11 --> Model Class Initialized
DEBUG - 2018-01-19 15:43:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:43:25 --> Config Class Initialized
INFO - 2018-01-19 15:43:25 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:43:25 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:43:25 --> Utf8 Class Initialized
INFO - 2018-01-19 15:43:25 --> URI Class Initialized
INFO - 2018-01-19 15:43:25 --> Router Class Initialized
INFO - 2018-01-19 15:43:25 --> Output Class Initialized
INFO - 2018-01-19 15:43:25 --> Security Class Initialized
DEBUG - 2018-01-19 15:43:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:43:25 --> Input Class Initialized
INFO - 2018-01-19 15:43:25 --> Language Class Initialized
INFO - 2018-01-19 15:43:25 --> Loader Class Initialized
INFO - 2018-01-19 15:43:25 --> Helper loaded: url_helper
INFO - 2018-01-19 15:43:25 --> Helper loaded: form_helper
INFO - 2018-01-19 15:43:25 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:43:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:43:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:43:25 --> Form Validation Class Initialized
INFO - 2018-01-19 15:43:25 --> Model Class Initialized
INFO - 2018-01-19 15:43:25 --> Controller Class Initialized
INFO - 2018-01-19 15:43:25 --> Model Class Initialized
INFO - 2018-01-19 15:43:26 --> Model Class Initialized
INFO - 2018-01-19 15:43:26 --> Model Class Initialized
INFO - 2018-01-19 15:43:26 --> Model Class Initialized
DEBUG - 2018-01-19 15:43:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:43:26 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 15:43:26 --> Final output sent to browser
DEBUG - 2018-01-19 15:43:26 --> Total execution time: 0.0528
INFO - 2018-01-19 15:43:30 --> Config Class Initialized
INFO - 2018-01-19 15:43:30 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:43:30 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:43:30 --> Utf8 Class Initialized
INFO - 2018-01-19 15:43:30 --> URI Class Initialized
INFO - 2018-01-19 15:43:30 --> Router Class Initialized
INFO - 2018-01-19 15:43:30 --> Output Class Initialized
INFO - 2018-01-19 15:43:30 --> Security Class Initialized
DEBUG - 2018-01-19 15:43:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:43:30 --> Input Class Initialized
INFO - 2018-01-19 15:43:30 --> Language Class Initialized
INFO - 2018-01-19 15:43:30 --> Loader Class Initialized
INFO - 2018-01-19 15:43:30 --> Helper loaded: url_helper
INFO - 2018-01-19 15:43:30 --> Helper loaded: form_helper
INFO - 2018-01-19 15:43:30 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:43:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:43:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:43:30 --> Form Validation Class Initialized
INFO - 2018-01-19 15:43:30 --> Model Class Initialized
INFO - 2018-01-19 15:43:30 --> Controller Class Initialized
INFO - 2018-01-19 15:43:30 --> Model Class Initialized
INFO - 2018-01-19 15:43:30 --> Model Class Initialized
DEBUG - 2018-01-19 15:43:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:43:30 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 15:43:30 --> Final output sent to browser
DEBUG - 2018-01-19 15:43:30 --> Total execution time: 0.0395
INFO - 2018-01-19 15:43:31 --> Config Class Initialized
INFO - 2018-01-19 15:43:31 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:43:31 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:43:31 --> Utf8 Class Initialized
INFO - 2018-01-19 15:43:31 --> URI Class Initialized
INFO - 2018-01-19 15:43:31 --> Router Class Initialized
INFO - 2018-01-19 15:43:31 --> Output Class Initialized
INFO - 2018-01-19 15:43:31 --> Security Class Initialized
DEBUG - 2018-01-19 15:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:43:31 --> Input Class Initialized
INFO - 2018-01-19 15:43:31 --> Language Class Initialized
INFO - 2018-01-19 15:43:31 --> Loader Class Initialized
INFO - 2018-01-19 15:43:31 --> Helper loaded: url_helper
INFO - 2018-01-19 15:43:31 --> Helper loaded: form_helper
INFO - 2018-01-19 15:43:31 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:43:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:43:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:43:31 --> Form Validation Class Initialized
INFO - 2018-01-19 15:43:31 --> Model Class Initialized
INFO - 2018-01-19 15:43:31 --> Controller Class Initialized
INFO - 2018-01-19 15:43:31 --> Model Class Initialized
INFO - 2018-01-19 15:43:31 --> Model Class Initialized
DEBUG - 2018-01-19 15:43:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:43:37 --> Config Class Initialized
INFO - 2018-01-19 15:43:37 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:43:37 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:43:37 --> Utf8 Class Initialized
INFO - 2018-01-19 15:43:37 --> URI Class Initialized
INFO - 2018-01-19 15:43:37 --> Router Class Initialized
INFO - 2018-01-19 15:43:37 --> Output Class Initialized
INFO - 2018-01-19 15:43:37 --> Security Class Initialized
DEBUG - 2018-01-19 15:43:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:43:37 --> Input Class Initialized
INFO - 2018-01-19 15:43:37 --> Language Class Initialized
INFO - 2018-01-19 15:43:37 --> Loader Class Initialized
INFO - 2018-01-19 15:43:37 --> Helper loaded: url_helper
INFO - 2018-01-19 15:43:37 --> Helper loaded: form_helper
INFO - 2018-01-19 15:43:37 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:43:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:43:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:43:37 --> Form Validation Class Initialized
INFO - 2018-01-19 15:43:37 --> Model Class Initialized
INFO - 2018-01-19 15:43:37 --> Controller Class Initialized
INFO - 2018-01-19 15:43:37 --> Model Class Initialized
INFO - 2018-01-19 15:43:37 --> Model Class Initialized
DEBUG - 2018-01-19 15:43:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:43:37 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 15:43:37 --> Final output sent to browser
DEBUG - 2018-01-19 15:43:37 --> Total execution time: 0.0387
INFO - 2018-01-19 15:44:29 --> Config Class Initialized
INFO - 2018-01-19 15:44:29 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:44:29 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:44:29 --> Utf8 Class Initialized
INFO - 2018-01-19 15:44:29 --> URI Class Initialized
INFO - 2018-01-19 15:44:29 --> Router Class Initialized
INFO - 2018-01-19 15:44:29 --> Output Class Initialized
INFO - 2018-01-19 15:44:29 --> Security Class Initialized
DEBUG - 2018-01-19 15:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:44:29 --> Input Class Initialized
INFO - 2018-01-19 15:44:29 --> Language Class Initialized
INFO - 2018-01-19 15:44:29 --> Loader Class Initialized
INFO - 2018-01-19 15:44:29 --> Helper loaded: url_helper
INFO - 2018-01-19 15:44:29 --> Helper loaded: form_helper
INFO - 2018-01-19 15:44:29 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:44:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:44:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:44:29 --> Form Validation Class Initialized
INFO - 2018-01-19 15:44:29 --> Model Class Initialized
INFO - 2018-01-19 15:44:29 --> Controller Class Initialized
INFO - 2018-01-19 15:44:29 --> Model Class Initialized
INFO - 2018-01-19 15:44:29 --> Model Class Initialized
DEBUG - 2018-01-19 15:44:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:44:29 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 15:44:29 --> Final output sent to browser
DEBUG - 2018-01-19 15:44:29 --> Total execution time: 0.0547
INFO - 2018-01-19 15:44:34 --> Config Class Initialized
INFO - 2018-01-19 15:44:34 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:44:34 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:44:34 --> Utf8 Class Initialized
INFO - 2018-01-19 15:44:34 --> URI Class Initialized
INFO - 2018-01-19 15:44:34 --> Router Class Initialized
INFO - 2018-01-19 15:44:34 --> Output Class Initialized
INFO - 2018-01-19 15:44:34 --> Security Class Initialized
DEBUG - 2018-01-19 15:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:44:34 --> Input Class Initialized
INFO - 2018-01-19 15:44:34 --> Language Class Initialized
INFO - 2018-01-19 15:44:34 --> Loader Class Initialized
INFO - 2018-01-19 15:44:34 --> Helper loaded: url_helper
INFO - 2018-01-19 15:44:34 --> Helper loaded: form_helper
INFO - 2018-01-19 15:44:34 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:44:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:44:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:44:34 --> Form Validation Class Initialized
INFO - 2018-01-19 15:44:34 --> Model Class Initialized
INFO - 2018-01-19 15:44:34 --> Controller Class Initialized
INFO - 2018-01-19 15:44:34 --> Model Class Initialized
INFO - 2018-01-19 15:44:34 --> Model Class Initialized
INFO - 2018-01-19 15:44:34 --> Model Class Initialized
INFO - 2018-01-19 15:44:34 --> Model Class Initialized
DEBUG - 2018-01-19 15:44:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:44:34 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 15:44:34 --> Final output sent to browser
DEBUG - 2018-01-19 15:44:34 --> Total execution time: 0.0468
INFO - 2018-01-19 15:44:34 --> Config Class Initialized
INFO - 2018-01-19 15:44:34 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:44:34 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:44:34 --> Utf8 Class Initialized
INFO - 2018-01-19 15:44:34 --> URI Class Initialized
INFO - 2018-01-19 15:44:34 --> Router Class Initialized
INFO - 2018-01-19 15:44:34 --> Output Class Initialized
INFO - 2018-01-19 15:44:34 --> Security Class Initialized
DEBUG - 2018-01-19 15:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:44:34 --> Input Class Initialized
INFO - 2018-01-19 15:44:34 --> Language Class Initialized
INFO - 2018-01-19 15:44:34 --> Loader Class Initialized
INFO - 2018-01-19 15:44:34 --> Helper loaded: url_helper
INFO - 2018-01-19 15:44:34 --> Helper loaded: form_helper
INFO - 2018-01-19 15:44:34 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:44:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:44:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:44:34 --> Form Validation Class Initialized
INFO - 2018-01-19 15:44:34 --> Model Class Initialized
INFO - 2018-01-19 15:44:34 --> Controller Class Initialized
INFO - 2018-01-19 15:44:34 --> Model Class Initialized
INFO - 2018-01-19 15:44:34 --> Model Class Initialized
INFO - 2018-01-19 15:44:34 --> Model Class Initialized
INFO - 2018-01-19 15:44:34 --> Model Class Initialized
DEBUG - 2018-01-19 15:44:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:44:36 --> Config Class Initialized
INFO - 2018-01-19 15:44:36 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:44:36 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:44:36 --> Utf8 Class Initialized
INFO - 2018-01-19 15:44:36 --> URI Class Initialized
INFO - 2018-01-19 15:44:36 --> Router Class Initialized
INFO - 2018-01-19 15:44:36 --> Output Class Initialized
INFO - 2018-01-19 15:44:36 --> Security Class Initialized
DEBUG - 2018-01-19 15:44:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:44:36 --> Input Class Initialized
INFO - 2018-01-19 15:44:36 --> Language Class Initialized
INFO - 2018-01-19 15:44:36 --> Loader Class Initialized
INFO - 2018-01-19 15:44:36 --> Helper loaded: url_helper
INFO - 2018-01-19 15:44:36 --> Helper loaded: form_helper
INFO - 2018-01-19 15:44:36 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:44:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:44:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:44:36 --> Form Validation Class Initialized
INFO - 2018-01-19 15:44:36 --> Model Class Initialized
INFO - 2018-01-19 15:44:36 --> Controller Class Initialized
INFO - 2018-01-19 15:44:36 --> Model Class Initialized
INFO - 2018-01-19 15:44:36 --> Model Class Initialized
INFO - 2018-01-19 15:44:36 --> Model Class Initialized
INFO - 2018-01-19 15:44:36 --> Model Class Initialized
DEBUG - 2018-01-19 15:44:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:44:36 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 15:44:36 --> Final output sent to browser
DEBUG - 2018-01-19 15:44:36 --> Total execution time: 0.0539
INFO - 2018-01-19 15:44:37 --> Config Class Initialized
INFO - 2018-01-19 15:44:37 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:44:37 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:44:37 --> Utf8 Class Initialized
INFO - 2018-01-19 15:44:37 --> URI Class Initialized
INFO - 2018-01-19 15:44:37 --> Router Class Initialized
INFO - 2018-01-19 15:44:37 --> Output Class Initialized
INFO - 2018-01-19 15:44:37 --> Security Class Initialized
DEBUG - 2018-01-19 15:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:44:37 --> Input Class Initialized
INFO - 2018-01-19 15:44:37 --> Language Class Initialized
INFO - 2018-01-19 15:44:37 --> Loader Class Initialized
INFO - 2018-01-19 15:44:37 --> Helper loaded: url_helper
INFO - 2018-01-19 15:44:37 --> Helper loaded: form_helper
INFO - 2018-01-19 15:44:37 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:44:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:44:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:44:37 --> Form Validation Class Initialized
INFO - 2018-01-19 15:44:37 --> Model Class Initialized
INFO - 2018-01-19 15:44:37 --> Controller Class Initialized
INFO - 2018-01-19 15:44:37 --> Model Class Initialized
INFO - 2018-01-19 15:44:37 --> Model Class Initialized
INFO - 2018-01-19 15:44:37 --> Model Class Initialized
INFO - 2018-01-19 15:44:37 --> Model Class Initialized
DEBUG - 2018-01-19 15:44:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:44:39 --> Config Class Initialized
INFO - 2018-01-19 15:44:39 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:44:39 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:44:39 --> Utf8 Class Initialized
INFO - 2018-01-19 15:44:39 --> URI Class Initialized
INFO - 2018-01-19 15:44:39 --> Router Class Initialized
INFO - 2018-01-19 15:44:39 --> Output Class Initialized
INFO - 2018-01-19 15:44:39 --> Security Class Initialized
DEBUG - 2018-01-19 15:44:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:44:39 --> Input Class Initialized
INFO - 2018-01-19 15:44:39 --> Language Class Initialized
INFO - 2018-01-19 15:44:39 --> Loader Class Initialized
INFO - 2018-01-19 15:44:39 --> Helper loaded: url_helper
INFO - 2018-01-19 15:44:39 --> Helper loaded: form_helper
INFO - 2018-01-19 15:44:39 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:44:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:44:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:44:39 --> Form Validation Class Initialized
INFO - 2018-01-19 15:44:39 --> Model Class Initialized
INFO - 2018-01-19 15:44:39 --> Controller Class Initialized
INFO - 2018-01-19 15:44:39 --> Model Class Initialized
INFO - 2018-01-19 15:44:39 --> Model Class Initialized
INFO - 2018-01-19 15:44:39 --> Model Class Initialized
INFO - 2018-01-19 15:44:39 --> Model Class Initialized
DEBUG - 2018-01-19 15:44:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:44:39 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 15:44:39 --> Final output sent to browser
DEBUG - 2018-01-19 15:44:39 --> Total execution time: 0.0579
INFO - 2018-01-19 15:44:39 --> Config Class Initialized
INFO - 2018-01-19 15:44:39 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:44:39 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:44:39 --> Utf8 Class Initialized
INFO - 2018-01-19 15:44:39 --> URI Class Initialized
INFO - 2018-01-19 15:44:39 --> Router Class Initialized
INFO - 2018-01-19 15:44:39 --> Output Class Initialized
INFO - 2018-01-19 15:44:39 --> Security Class Initialized
DEBUG - 2018-01-19 15:44:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:44:39 --> Input Class Initialized
INFO - 2018-01-19 15:44:39 --> Language Class Initialized
INFO - 2018-01-19 15:44:39 --> Loader Class Initialized
INFO - 2018-01-19 15:44:39 --> Helper loaded: url_helper
INFO - 2018-01-19 15:44:39 --> Helper loaded: form_helper
INFO - 2018-01-19 15:44:39 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:44:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:44:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:44:39 --> Form Validation Class Initialized
INFO - 2018-01-19 15:44:39 --> Model Class Initialized
INFO - 2018-01-19 15:44:39 --> Controller Class Initialized
INFO - 2018-01-19 15:44:39 --> Model Class Initialized
INFO - 2018-01-19 15:44:39 --> Model Class Initialized
INFO - 2018-01-19 15:44:39 --> Model Class Initialized
INFO - 2018-01-19 15:44:39 --> Model Class Initialized
DEBUG - 2018-01-19 15:44:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:44:42 --> Config Class Initialized
INFO - 2018-01-19 15:44:42 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:44:42 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:44:42 --> Utf8 Class Initialized
INFO - 2018-01-19 15:44:42 --> URI Class Initialized
INFO - 2018-01-19 15:44:42 --> Router Class Initialized
INFO - 2018-01-19 15:44:42 --> Output Class Initialized
INFO - 2018-01-19 15:44:42 --> Security Class Initialized
DEBUG - 2018-01-19 15:44:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:44:42 --> Input Class Initialized
INFO - 2018-01-19 15:44:42 --> Language Class Initialized
INFO - 2018-01-19 15:44:42 --> Loader Class Initialized
INFO - 2018-01-19 15:44:42 --> Helper loaded: url_helper
INFO - 2018-01-19 15:44:42 --> Helper loaded: form_helper
INFO - 2018-01-19 15:44:42 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:44:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:44:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:44:42 --> Form Validation Class Initialized
INFO - 2018-01-19 15:44:42 --> Model Class Initialized
INFO - 2018-01-19 15:44:42 --> Controller Class Initialized
INFO - 2018-01-19 15:44:42 --> Model Class Initialized
INFO - 2018-01-19 15:44:42 --> Model Class Initialized
INFO - 2018-01-19 15:44:42 --> Model Class Initialized
INFO - 2018-01-19 15:44:42 --> Model Class Initialized
DEBUG - 2018-01-19 15:44:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:44:42 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 15:44:42 --> Final output sent to browser
DEBUG - 2018-01-19 15:44:42 --> Total execution time: 0.0572
INFO - 2018-01-19 15:45:12 --> Config Class Initialized
INFO - 2018-01-19 15:45:12 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:45:12 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:45:12 --> Utf8 Class Initialized
INFO - 2018-01-19 15:45:12 --> URI Class Initialized
INFO - 2018-01-19 15:45:12 --> Router Class Initialized
INFO - 2018-01-19 15:45:12 --> Output Class Initialized
INFO - 2018-01-19 15:45:12 --> Security Class Initialized
DEBUG - 2018-01-19 15:45:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:45:12 --> Input Class Initialized
INFO - 2018-01-19 15:45:12 --> Language Class Initialized
INFO - 2018-01-19 15:45:12 --> Loader Class Initialized
INFO - 2018-01-19 15:45:12 --> Helper loaded: url_helper
INFO - 2018-01-19 15:45:12 --> Helper loaded: form_helper
INFO - 2018-01-19 15:45:12 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:45:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:45:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:45:12 --> Form Validation Class Initialized
INFO - 2018-01-19 15:45:12 --> Model Class Initialized
INFO - 2018-01-19 15:45:12 --> Controller Class Initialized
INFO - 2018-01-19 15:45:12 --> Model Class Initialized
INFO - 2018-01-19 15:45:12 --> Model Class Initialized
INFO - 2018-01-19 15:45:12 --> Model Class Initialized
INFO - 2018-01-19 15:45:12 --> Model Class Initialized
DEBUG - 2018-01-19 15:45:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:45:12 --> Config Class Initialized
INFO - 2018-01-19 15:45:12 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:45:12 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:45:12 --> Utf8 Class Initialized
INFO - 2018-01-19 15:45:12 --> URI Class Initialized
INFO - 2018-01-19 15:45:12 --> Router Class Initialized
INFO - 2018-01-19 15:45:12 --> Output Class Initialized
INFO - 2018-01-19 15:45:12 --> Security Class Initialized
DEBUG - 2018-01-19 15:45:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:45:12 --> Input Class Initialized
INFO - 2018-01-19 15:45:12 --> Language Class Initialized
INFO - 2018-01-19 15:45:12 --> Loader Class Initialized
INFO - 2018-01-19 15:45:12 --> Helper loaded: url_helper
INFO - 2018-01-19 15:45:12 --> Helper loaded: form_helper
INFO - 2018-01-19 15:45:12 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:45:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:45:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:45:12 --> Form Validation Class Initialized
INFO - 2018-01-19 15:45:12 --> Model Class Initialized
INFO - 2018-01-19 15:45:12 --> Controller Class Initialized
INFO - 2018-01-19 15:45:12 --> Model Class Initialized
INFO - 2018-01-19 15:45:12 --> Model Class Initialized
INFO - 2018-01-19 15:45:12 --> Model Class Initialized
INFO - 2018-01-19 15:45:12 --> Model Class Initialized
DEBUG - 2018-01-19 15:45:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:45:12 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 15:45:12 --> Final output sent to browser
DEBUG - 2018-01-19 15:45:12 --> Total execution time: 0.0519
INFO - 2018-01-19 15:45:13 --> Config Class Initialized
INFO - 2018-01-19 15:45:13 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:45:13 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:45:13 --> Utf8 Class Initialized
INFO - 2018-01-19 15:45:13 --> URI Class Initialized
INFO - 2018-01-19 15:45:13 --> Router Class Initialized
INFO - 2018-01-19 15:45:13 --> Output Class Initialized
INFO - 2018-01-19 15:45:13 --> Security Class Initialized
DEBUG - 2018-01-19 15:45:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:45:13 --> Input Class Initialized
INFO - 2018-01-19 15:45:13 --> Language Class Initialized
INFO - 2018-01-19 15:45:13 --> Loader Class Initialized
INFO - 2018-01-19 15:45:13 --> Helper loaded: url_helper
INFO - 2018-01-19 15:45:13 --> Helper loaded: form_helper
INFO - 2018-01-19 15:45:13 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:45:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:45:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:45:13 --> Form Validation Class Initialized
INFO - 2018-01-19 15:45:13 --> Model Class Initialized
INFO - 2018-01-19 15:45:13 --> Controller Class Initialized
INFO - 2018-01-19 15:45:13 --> Model Class Initialized
INFO - 2018-01-19 15:45:13 --> Model Class Initialized
INFO - 2018-01-19 15:45:13 --> Model Class Initialized
INFO - 2018-01-19 15:45:13 --> Model Class Initialized
DEBUG - 2018-01-19 15:45:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:45:19 --> Config Class Initialized
INFO - 2018-01-19 15:45:19 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:45:19 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:45:19 --> Utf8 Class Initialized
INFO - 2018-01-19 15:45:19 --> URI Class Initialized
INFO - 2018-01-19 15:45:19 --> Router Class Initialized
INFO - 2018-01-19 15:45:19 --> Output Class Initialized
INFO - 2018-01-19 15:45:19 --> Security Class Initialized
DEBUG - 2018-01-19 15:45:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:45:19 --> Input Class Initialized
INFO - 2018-01-19 15:45:19 --> Language Class Initialized
INFO - 2018-01-19 15:45:19 --> Loader Class Initialized
INFO - 2018-01-19 15:45:19 --> Helper loaded: url_helper
INFO - 2018-01-19 15:45:19 --> Helper loaded: form_helper
INFO - 2018-01-19 15:45:19 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:45:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:45:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:45:19 --> Form Validation Class Initialized
INFO - 2018-01-19 15:45:19 --> Model Class Initialized
INFO - 2018-01-19 15:45:19 --> Controller Class Initialized
INFO - 2018-01-19 15:45:19 --> Model Class Initialized
INFO - 2018-01-19 15:45:19 --> Model Class Initialized
DEBUG - 2018-01-19 15:45:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:45:19 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 15:45:19 --> Final output sent to browser
DEBUG - 2018-01-19 15:45:19 --> Total execution time: 0.0488
INFO - 2018-01-19 15:45:19 --> Config Class Initialized
INFO - 2018-01-19 15:45:19 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:45:19 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:45:19 --> Utf8 Class Initialized
INFO - 2018-01-19 15:45:19 --> URI Class Initialized
INFO - 2018-01-19 15:45:19 --> Router Class Initialized
INFO - 2018-01-19 15:45:19 --> Output Class Initialized
INFO - 2018-01-19 15:45:19 --> Security Class Initialized
DEBUG - 2018-01-19 15:45:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:45:19 --> Input Class Initialized
INFO - 2018-01-19 15:45:19 --> Language Class Initialized
INFO - 2018-01-19 15:45:19 --> Loader Class Initialized
INFO - 2018-01-19 15:45:20 --> Helper loaded: url_helper
INFO - 2018-01-19 15:45:20 --> Helper loaded: form_helper
INFO - 2018-01-19 15:45:20 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:45:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:45:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:45:20 --> Form Validation Class Initialized
INFO - 2018-01-19 15:45:20 --> Model Class Initialized
INFO - 2018-01-19 15:45:20 --> Controller Class Initialized
INFO - 2018-01-19 15:45:20 --> Model Class Initialized
INFO - 2018-01-19 15:45:20 --> Model Class Initialized
DEBUG - 2018-01-19 15:45:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:45:27 --> Config Class Initialized
INFO - 2018-01-19 15:45:27 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:45:27 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:45:27 --> Utf8 Class Initialized
INFO - 2018-01-19 15:45:27 --> URI Class Initialized
INFO - 2018-01-19 15:45:27 --> Router Class Initialized
INFO - 2018-01-19 15:45:27 --> Output Class Initialized
INFO - 2018-01-19 15:45:27 --> Security Class Initialized
DEBUG - 2018-01-19 15:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:45:27 --> Input Class Initialized
INFO - 2018-01-19 15:45:27 --> Language Class Initialized
INFO - 2018-01-19 15:45:27 --> Loader Class Initialized
INFO - 2018-01-19 15:45:27 --> Helper loaded: url_helper
INFO - 2018-01-19 15:45:27 --> Helper loaded: form_helper
INFO - 2018-01-19 15:45:27 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:45:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:45:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:45:27 --> Form Validation Class Initialized
INFO - 2018-01-19 15:45:27 --> Model Class Initialized
INFO - 2018-01-19 15:45:27 --> Controller Class Initialized
INFO - 2018-01-19 15:45:27 --> Model Class Initialized
INFO - 2018-01-19 15:45:27 --> Model Class Initialized
DEBUG - 2018-01-19 15:45:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:45:27 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 15:45:27 --> Final output sent to browser
DEBUG - 2018-01-19 15:45:27 --> Total execution time: 0.0402
INFO - 2018-01-19 15:45:58 --> Config Class Initialized
INFO - 2018-01-19 15:45:58 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:45:58 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:45:58 --> Utf8 Class Initialized
INFO - 2018-01-19 15:45:58 --> URI Class Initialized
INFO - 2018-01-19 15:45:58 --> Router Class Initialized
INFO - 2018-01-19 15:45:58 --> Output Class Initialized
INFO - 2018-01-19 15:45:58 --> Security Class Initialized
DEBUG - 2018-01-19 15:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:45:58 --> Input Class Initialized
INFO - 2018-01-19 15:45:58 --> Language Class Initialized
INFO - 2018-01-19 15:45:58 --> Loader Class Initialized
INFO - 2018-01-19 15:45:58 --> Helper loaded: url_helper
INFO - 2018-01-19 15:45:58 --> Helper loaded: form_helper
INFO - 2018-01-19 15:45:58 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:45:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:45:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:45:58 --> Form Validation Class Initialized
INFO - 2018-01-19 15:45:58 --> Model Class Initialized
INFO - 2018-01-19 15:45:58 --> Controller Class Initialized
INFO - 2018-01-19 15:45:58 --> Model Class Initialized
INFO - 2018-01-19 15:45:58 --> Model Class Initialized
DEBUG - 2018-01-19 15:45:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:45:58 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 15:45:58 --> Final output sent to browser
DEBUG - 2018-01-19 15:45:58 --> Total execution time: 0.0508
INFO - 2018-01-19 15:45:59 --> Config Class Initialized
INFO - 2018-01-19 15:45:59 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:45:59 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:45:59 --> Utf8 Class Initialized
INFO - 2018-01-19 15:45:59 --> URI Class Initialized
INFO - 2018-01-19 15:45:59 --> Router Class Initialized
INFO - 2018-01-19 15:45:59 --> Output Class Initialized
INFO - 2018-01-19 15:45:59 --> Security Class Initialized
DEBUG - 2018-01-19 15:45:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:45:59 --> Input Class Initialized
INFO - 2018-01-19 15:45:59 --> Language Class Initialized
INFO - 2018-01-19 15:45:59 --> Loader Class Initialized
INFO - 2018-01-19 15:45:59 --> Helper loaded: url_helper
INFO - 2018-01-19 15:45:59 --> Helper loaded: form_helper
INFO - 2018-01-19 15:45:59 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:45:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:45:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:45:59 --> Form Validation Class Initialized
INFO - 2018-01-19 15:45:59 --> Model Class Initialized
INFO - 2018-01-19 15:45:59 --> Controller Class Initialized
INFO - 2018-01-19 15:45:59 --> Model Class Initialized
INFO - 2018-01-19 15:45:59 --> Model Class Initialized
DEBUG - 2018-01-19 15:45:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:45:59 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 15:45:59 --> Final output sent to browser
DEBUG - 2018-01-19 15:45:59 --> Total execution time: 0.0537
INFO - 2018-01-19 15:46:02 --> Config Class Initialized
INFO - 2018-01-19 15:46:02 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:46:02 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:46:02 --> Utf8 Class Initialized
INFO - 2018-01-19 15:46:02 --> URI Class Initialized
INFO - 2018-01-19 15:46:02 --> Router Class Initialized
INFO - 2018-01-19 15:46:02 --> Output Class Initialized
INFO - 2018-01-19 15:46:02 --> Security Class Initialized
DEBUG - 2018-01-19 15:46:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:46:02 --> Input Class Initialized
INFO - 2018-01-19 15:46:02 --> Language Class Initialized
INFO - 2018-01-19 15:46:02 --> Loader Class Initialized
INFO - 2018-01-19 15:46:02 --> Helper loaded: url_helper
INFO - 2018-01-19 15:46:02 --> Helper loaded: form_helper
INFO - 2018-01-19 15:46:02 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:46:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:46:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:46:02 --> Form Validation Class Initialized
INFO - 2018-01-19 15:46:02 --> Model Class Initialized
INFO - 2018-01-19 15:46:02 --> Controller Class Initialized
INFO - 2018-01-19 15:46:02 --> Model Class Initialized
INFO - 2018-01-19 15:46:02 --> Model Class Initialized
INFO - 2018-01-19 15:46:02 --> Model Class Initialized
INFO - 2018-01-19 15:46:02 --> Model Class Initialized
DEBUG - 2018-01-19 15:46:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:46:02 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 15:46:02 --> Final output sent to browser
DEBUG - 2018-01-19 15:46:02 --> Total execution time: 0.0516
INFO - 2018-01-19 15:46:02 --> Config Class Initialized
INFO - 2018-01-19 15:46:02 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:46:02 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:46:02 --> Utf8 Class Initialized
INFO - 2018-01-19 15:46:02 --> URI Class Initialized
INFO - 2018-01-19 15:46:02 --> Router Class Initialized
INFO - 2018-01-19 15:46:02 --> Output Class Initialized
INFO - 2018-01-19 15:46:02 --> Security Class Initialized
DEBUG - 2018-01-19 15:46:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:46:02 --> Input Class Initialized
INFO - 2018-01-19 15:46:02 --> Language Class Initialized
INFO - 2018-01-19 15:46:02 --> Loader Class Initialized
INFO - 2018-01-19 15:46:02 --> Helper loaded: url_helper
INFO - 2018-01-19 15:46:02 --> Helper loaded: form_helper
INFO - 2018-01-19 15:46:02 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:46:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:46:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:46:02 --> Form Validation Class Initialized
INFO - 2018-01-19 15:46:02 --> Model Class Initialized
INFO - 2018-01-19 15:46:02 --> Controller Class Initialized
INFO - 2018-01-19 15:46:02 --> Model Class Initialized
INFO - 2018-01-19 15:46:02 --> Model Class Initialized
INFO - 2018-01-19 15:46:02 --> Model Class Initialized
INFO - 2018-01-19 15:46:02 --> Model Class Initialized
DEBUG - 2018-01-19 15:46:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:46:05 --> Config Class Initialized
INFO - 2018-01-19 15:46:05 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:46:05 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:46:05 --> Utf8 Class Initialized
INFO - 2018-01-19 15:46:05 --> URI Class Initialized
INFO - 2018-01-19 15:46:05 --> Router Class Initialized
INFO - 2018-01-19 15:46:05 --> Output Class Initialized
INFO - 2018-01-19 15:46:05 --> Security Class Initialized
DEBUG - 2018-01-19 15:46:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:46:05 --> Input Class Initialized
INFO - 2018-01-19 15:46:05 --> Language Class Initialized
INFO - 2018-01-19 15:46:05 --> Loader Class Initialized
INFO - 2018-01-19 15:46:05 --> Helper loaded: url_helper
INFO - 2018-01-19 15:46:05 --> Helper loaded: form_helper
INFO - 2018-01-19 15:46:05 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:46:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:46:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:46:05 --> Form Validation Class Initialized
INFO - 2018-01-19 15:46:05 --> Model Class Initialized
INFO - 2018-01-19 15:46:05 --> Controller Class Initialized
INFO - 2018-01-19 15:46:05 --> Model Class Initialized
INFO - 2018-01-19 15:46:05 --> Model Class Initialized
INFO - 2018-01-19 15:46:05 --> Model Class Initialized
INFO - 2018-01-19 15:46:05 --> Model Class Initialized
DEBUG - 2018-01-19 15:46:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:46:05 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 15:46:05 --> Final output sent to browser
DEBUG - 2018-01-19 15:46:05 --> Total execution time: 0.0531
INFO - 2018-01-19 15:46:05 --> Config Class Initialized
INFO - 2018-01-19 15:46:05 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:46:05 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:46:05 --> Utf8 Class Initialized
INFO - 2018-01-19 15:46:05 --> URI Class Initialized
INFO - 2018-01-19 15:46:05 --> Router Class Initialized
INFO - 2018-01-19 15:46:05 --> Output Class Initialized
INFO - 2018-01-19 15:46:05 --> Security Class Initialized
DEBUG - 2018-01-19 15:46:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:46:05 --> Input Class Initialized
INFO - 2018-01-19 15:46:05 --> Language Class Initialized
INFO - 2018-01-19 15:46:05 --> Loader Class Initialized
INFO - 2018-01-19 15:46:05 --> Helper loaded: url_helper
INFO - 2018-01-19 15:46:05 --> Helper loaded: form_helper
INFO - 2018-01-19 15:46:05 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:46:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:46:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:46:05 --> Form Validation Class Initialized
INFO - 2018-01-19 15:46:05 --> Model Class Initialized
INFO - 2018-01-19 15:46:05 --> Controller Class Initialized
INFO - 2018-01-19 15:46:05 --> Model Class Initialized
INFO - 2018-01-19 15:46:05 --> Model Class Initialized
INFO - 2018-01-19 15:46:05 --> Model Class Initialized
INFO - 2018-01-19 15:46:05 --> Model Class Initialized
DEBUG - 2018-01-19 15:46:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:46:08 --> Config Class Initialized
INFO - 2018-01-19 15:46:08 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:46:08 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:46:08 --> Utf8 Class Initialized
INFO - 2018-01-19 15:46:08 --> URI Class Initialized
INFO - 2018-01-19 15:46:08 --> Router Class Initialized
INFO - 2018-01-19 15:46:08 --> Output Class Initialized
INFO - 2018-01-19 15:46:08 --> Security Class Initialized
DEBUG - 2018-01-19 15:46:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:46:08 --> Input Class Initialized
INFO - 2018-01-19 15:46:08 --> Language Class Initialized
INFO - 2018-01-19 15:46:08 --> Loader Class Initialized
INFO - 2018-01-19 15:46:08 --> Helper loaded: url_helper
INFO - 2018-01-19 15:46:08 --> Helper loaded: form_helper
INFO - 2018-01-19 15:46:08 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:46:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:46:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:46:08 --> Form Validation Class Initialized
INFO - 2018-01-19 15:46:08 --> Model Class Initialized
INFO - 2018-01-19 15:46:08 --> Controller Class Initialized
INFO - 2018-01-19 15:46:08 --> Model Class Initialized
INFO - 2018-01-19 15:46:08 --> Model Class Initialized
INFO - 2018-01-19 15:46:08 --> Model Class Initialized
INFO - 2018-01-19 15:46:08 --> Model Class Initialized
DEBUG - 2018-01-19 15:46:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:46:08 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 15:46:08 --> Final output sent to browser
DEBUG - 2018-01-19 15:46:08 --> Total execution time: 0.0541
INFO - 2018-01-19 15:46:08 --> Config Class Initialized
INFO - 2018-01-19 15:46:08 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:46:08 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:46:08 --> Utf8 Class Initialized
INFO - 2018-01-19 15:46:08 --> URI Class Initialized
INFO - 2018-01-19 15:46:08 --> Router Class Initialized
INFO - 2018-01-19 15:46:08 --> Output Class Initialized
INFO - 2018-01-19 15:46:08 --> Security Class Initialized
DEBUG - 2018-01-19 15:46:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:46:08 --> Input Class Initialized
INFO - 2018-01-19 15:46:08 --> Language Class Initialized
INFO - 2018-01-19 15:46:08 --> Loader Class Initialized
INFO - 2018-01-19 15:46:08 --> Helper loaded: url_helper
INFO - 2018-01-19 15:46:08 --> Helper loaded: form_helper
INFO - 2018-01-19 15:46:08 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:46:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:46:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:46:08 --> Form Validation Class Initialized
INFO - 2018-01-19 15:46:08 --> Model Class Initialized
INFO - 2018-01-19 15:46:08 --> Controller Class Initialized
INFO - 2018-01-19 15:46:08 --> Model Class Initialized
INFO - 2018-01-19 15:46:08 --> Model Class Initialized
INFO - 2018-01-19 15:46:08 --> Model Class Initialized
INFO - 2018-01-19 15:46:08 --> Model Class Initialized
DEBUG - 2018-01-19 15:46:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:46:09 --> Config Class Initialized
INFO - 2018-01-19 15:46:09 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:46:09 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:46:09 --> Utf8 Class Initialized
INFO - 2018-01-19 15:46:09 --> URI Class Initialized
INFO - 2018-01-19 15:46:09 --> Router Class Initialized
INFO - 2018-01-19 15:46:09 --> Output Class Initialized
INFO - 2018-01-19 15:46:09 --> Security Class Initialized
DEBUG - 2018-01-19 15:46:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:46:09 --> Input Class Initialized
INFO - 2018-01-19 15:46:09 --> Language Class Initialized
INFO - 2018-01-19 15:46:09 --> Loader Class Initialized
INFO - 2018-01-19 15:46:09 --> Helper loaded: url_helper
INFO - 2018-01-19 15:46:09 --> Helper loaded: form_helper
INFO - 2018-01-19 15:46:09 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:46:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:46:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:46:09 --> Form Validation Class Initialized
INFO - 2018-01-19 15:46:09 --> Model Class Initialized
INFO - 2018-01-19 15:46:09 --> Controller Class Initialized
INFO - 2018-01-19 15:46:09 --> Model Class Initialized
INFO - 2018-01-19 15:46:09 --> Model Class Initialized
INFO - 2018-01-19 15:46:09 --> Model Class Initialized
INFO - 2018-01-19 15:46:09 --> Model Class Initialized
DEBUG - 2018-01-19 15:46:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:46:09 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 15:46:09 --> Final output sent to browser
DEBUG - 2018-01-19 15:46:09 --> Total execution time: 0.0499
INFO - 2018-01-19 15:46:45 --> Config Class Initialized
INFO - 2018-01-19 15:46:45 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:46:45 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:46:45 --> Utf8 Class Initialized
INFO - 2018-01-19 15:46:45 --> URI Class Initialized
INFO - 2018-01-19 15:46:45 --> Router Class Initialized
INFO - 2018-01-19 15:46:45 --> Output Class Initialized
INFO - 2018-01-19 15:46:45 --> Security Class Initialized
DEBUG - 2018-01-19 15:46:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:46:45 --> Input Class Initialized
INFO - 2018-01-19 15:46:45 --> Language Class Initialized
INFO - 2018-01-19 15:46:45 --> Loader Class Initialized
INFO - 2018-01-19 15:46:45 --> Helper loaded: url_helper
INFO - 2018-01-19 15:46:45 --> Helper loaded: form_helper
INFO - 2018-01-19 15:46:45 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:46:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:46:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:46:45 --> Form Validation Class Initialized
INFO - 2018-01-19 15:46:45 --> Model Class Initialized
INFO - 2018-01-19 15:46:45 --> Controller Class Initialized
INFO - 2018-01-19 15:46:45 --> Model Class Initialized
INFO - 2018-01-19 15:46:45 --> Model Class Initialized
INFO - 2018-01-19 15:46:45 --> Model Class Initialized
INFO - 2018-01-19 15:46:45 --> Model Class Initialized
DEBUG - 2018-01-19 15:46:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:46:45 --> Config Class Initialized
INFO - 2018-01-19 15:46:45 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:46:45 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:46:45 --> Utf8 Class Initialized
INFO - 2018-01-19 15:46:45 --> URI Class Initialized
INFO - 2018-01-19 15:46:45 --> Router Class Initialized
INFO - 2018-01-19 15:46:45 --> Output Class Initialized
INFO - 2018-01-19 15:46:45 --> Security Class Initialized
DEBUG - 2018-01-19 15:46:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:46:45 --> Input Class Initialized
INFO - 2018-01-19 15:46:45 --> Language Class Initialized
INFO - 2018-01-19 15:46:45 --> Loader Class Initialized
INFO - 2018-01-19 15:46:45 --> Helper loaded: url_helper
INFO - 2018-01-19 15:46:45 --> Helper loaded: form_helper
INFO - 2018-01-19 15:46:45 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:46:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:46:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:46:45 --> Form Validation Class Initialized
INFO - 2018-01-19 15:46:45 --> Model Class Initialized
INFO - 2018-01-19 15:46:45 --> Controller Class Initialized
INFO - 2018-01-19 15:46:45 --> Model Class Initialized
INFO - 2018-01-19 15:46:45 --> Model Class Initialized
INFO - 2018-01-19 15:46:45 --> Model Class Initialized
INFO - 2018-01-19 15:46:45 --> Model Class Initialized
DEBUG - 2018-01-19 15:46:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:46:45 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 15:46:45 --> Final output sent to browser
DEBUG - 2018-01-19 15:46:45 --> Total execution time: 0.0530
INFO - 2018-01-19 15:46:45 --> Config Class Initialized
INFO - 2018-01-19 15:46:45 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:46:46 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:46:46 --> Utf8 Class Initialized
INFO - 2018-01-19 15:46:46 --> URI Class Initialized
INFO - 2018-01-19 15:46:46 --> Router Class Initialized
INFO - 2018-01-19 15:46:46 --> Output Class Initialized
INFO - 2018-01-19 15:46:46 --> Security Class Initialized
DEBUG - 2018-01-19 15:46:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:46:46 --> Input Class Initialized
INFO - 2018-01-19 15:46:46 --> Language Class Initialized
INFO - 2018-01-19 15:46:46 --> Loader Class Initialized
INFO - 2018-01-19 15:46:46 --> Helper loaded: url_helper
INFO - 2018-01-19 15:46:46 --> Helper loaded: form_helper
INFO - 2018-01-19 15:46:46 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:46:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:46:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:46:46 --> Form Validation Class Initialized
INFO - 2018-01-19 15:46:46 --> Model Class Initialized
INFO - 2018-01-19 15:46:46 --> Controller Class Initialized
INFO - 2018-01-19 15:46:46 --> Model Class Initialized
INFO - 2018-01-19 15:46:46 --> Model Class Initialized
INFO - 2018-01-19 15:46:46 --> Model Class Initialized
INFO - 2018-01-19 15:46:46 --> Model Class Initialized
DEBUG - 2018-01-19 15:46:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:47:05 --> Config Class Initialized
INFO - 2018-01-19 15:47:05 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:47:05 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:47:05 --> Utf8 Class Initialized
INFO - 2018-01-19 15:47:05 --> URI Class Initialized
INFO - 2018-01-19 15:47:05 --> Router Class Initialized
INFO - 2018-01-19 15:47:05 --> Output Class Initialized
INFO - 2018-01-19 15:47:05 --> Security Class Initialized
DEBUG - 2018-01-19 15:47:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:47:05 --> Input Class Initialized
INFO - 2018-01-19 15:47:05 --> Language Class Initialized
INFO - 2018-01-19 15:47:05 --> Loader Class Initialized
INFO - 2018-01-19 15:47:05 --> Helper loaded: url_helper
INFO - 2018-01-19 15:47:05 --> Helper loaded: form_helper
INFO - 2018-01-19 15:47:05 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:47:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:47:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:47:05 --> Form Validation Class Initialized
INFO - 2018-01-19 15:47:05 --> Model Class Initialized
INFO - 2018-01-19 15:47:05 --> Controller Class Initialized
INFO - 2018-01-19 15:47:05 --> Model Class Initialized
INFO - 2018-01-19 15:47:05 --> Model Class Initialized
INFO - 2018-01-19 15:47:05 --> Model Class Initialized
INFO - 2018-01-19 15:47:05 --> Model Class Initialized
DEBUG - 2018-01-19 15:47:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:47:05 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 15:47:05 --> Final output sent to browser
DEBUG - 2018-01-19 15:47:05 --> Total execution time: 0.0495
INFO - 2018-01-19 15:47:06 --> Config Class Initialized
INFO - 2018-01-19 15:47:06 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:47:06 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:47:06 --> Utf8 Class Initialized
INFO - 2018-01-19 15:47:06 --> URI Class Initialized
INFO - 2018-01-19 15:47:06 --> Router Class Initialized
INFO - 2018-01-19 15:47:06 --> Output Class Initialized
INFO - 2018-01-19 15:47:06 --> Security Class Initialized
DEBUG - 2018-01-19 15:47:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:47:06 --> Input Class Initialized
INFO - 2018-01-19 15:47:06 --> Language Class Initialized
INFO - 2018-01-19 15:47:06 --> Loader Class Initialized
INFO - 2018-01-19 15:47:06 --> Helper loaded: url_helper
INFO - 2018-01-19 15:47:06 --> Helper loaded: form_helper
INFO - 2018-01-19 15:47:06 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:47:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:47:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:47:06 --> Form Validation Class Initialized
INFO - 2018-01-19 15:47:06 --> Model Class Initialized
INFO - 2018-01-19 15:47:06 --> Controller Class Initialized
INFO - 2018-01-19 15:47:06 --> Model Class Initialized
INFO - 2018-01-19 15:47:06 --> Model Class Initialized
INFO - 2018-01-19 15:47:06 --> Model Class Initialized
INFO - 2018-01-19 15:47:06 --> Model Class Initialized
DEBUG - 2018-01-19 15:47:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:47:09 --> Config Class Initialized
INFO - 2018-01-19 15:47:09 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:47:09 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:47:09 --> Utf8 Class Initialized
INFO - 2018-01-19 15:47:09 --> URI Class Initialized
INFO - 2018-01-19 15:47:09 --> Router Class Initialized
INFO - 2018-01-19 15:47:09 --> Output Class Initialized
INFO - 2018-01-19 15:47:09 --> Security Class Initialized
DEBUG - 2018-01-19 15:47:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:47:09 --> Input Class Initialized
INFO - 2018-01-19 15:47:09 --> Language Class Initialized
INFO - 2018-01-19 15:47:09 --> Loader Class Initialized
INFO - 2018-01-19 15:47:09 --> Helper loaded: url_helper
INFO - 2018-01-19 15:47:09 --> Helper loaded: form_helper
INFO - 2018-01-19 15:47:09 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:47:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:47:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:47:09 --> Form Validation Class Initialized
INFO - 2018-01-19 15:47:09 --> Model Class Initialized
INFO - 2018-01-19 15:47:09 --> Controller Class Initialized
INFO - 2018-01-19 15:47:09 --> Model Class Initialized
INFO - 2018-01-19 15:47:09 --> Model Class Initialized
INFO - 2018-01-19 15:47:09 --> Model Class Initialized
INFO - 2018-01-19 15:47:09 --> Model Class Initialized
DEBUG - 2018-01-19 15:47:09 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-01-19 15:47:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/instateccr/public_html/controlcostos/vendor/phpoffice/phpspreadsheet/src/PhpSpreadsheet/Calculation/Calculation.php:3030) /home/instateccr/public_html/controlcostos/instatec_sys/core/Common.php 564
ERROR - 2018-01-19 15:47:09 --> Severity: Parsing Error --> syntax error, unexpected '.', expecting '&' or variable (T_VARIABLE) /home/instateccr/public_html/controlcostos/vendor/phpoffice/phpspreadsheet/src/PhpSpreadsheet/Calculation/Calculation.php 3030
INFO - 2018-01-19 15:47:17 --> Config Class Initialized
INFO - 2018-01-19 15:47:17 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:47:17 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:47:17 --> Utf8 Class Initialized
INFO - 2018-01-19 15:47:17 --> URI Class Initialized
INFO - 2018-01-19 15:47:17 --> Router Class Initialized
INFO - 2018-01-19 15:47:17 --> Output Class Initialized
INFO - 2018-01-19 15:47:17 --> Security Class Initialized
DEBUG - 2018-01-19 15:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:47:17 --> Input Class Initialized
INFO - 2018-01-19 15:47:17 --> Language Class Initialized
INFO - 2018-01-19 15:47:17 --> Loader Class Initialized
INFO - 2018-01-19 15:47:17 --> Helper loaded: url_helper
INFO - 2018-01-19 15:47:17 --> Helper loaded: form_helper
INFO - 2018-01-19 15:47:17 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:47:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:47:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:47:17 --> Form Validation Class Initialized
INFO - 2018-01-19 15:47:17 --> Model Class Initialized
INFO - 2018-01-19 15:47:17 --> Controller Class Initialized
INFO - 2018-01-19 15:47:17 --> Model Class Initialized
INFO - 2018-01-19 15:47:17 --> Model Class Initialized
INFO - 2018-01-19 15:47:17 --> Model Class Initialized
INFO - 2018-01-19 15:47:17 --> Model Class Initialized
DEBUG - 2018-01-19 15:47:17 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-01-19 15:47:17 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/instateccr/public_html/controlcostos/vendor/phpoffice/phpspreadsheet/src/PhpSpreadsheet/Calculation/Calculation.php:3030) /home/instateccr/public_html/controlcostos/instatec_sys/core/Common.php 564
ERROR - 2018-01-19 15:47:17 --> Severity: Parsing Error --> syntax error, unexpected '.', expecting '&' or variable (T_VARIABLE) /home/instateccr/public_html/controlcostos/vendor/phpoffice/phpspreadsheet/src/PhpSpreadsheet/Calculation/Calculation.php 3030
INFO - 2018-01-19 15:49:17 --> Config Class Initialized
INFO - 2018-01-19 15:49:17 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:49:17 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:49:17 --> Utf8 Class Initialized
INFO - 2018-01-19 15:49:17 --> URI Class Initialized
INFO - 2018-01-19 15:49:17 --> Router Class Initialized
INFO - 2018-01-19 15:49:17 --> Output Class Initialized
INFO - 2018-01-19 15:49:17 --> Security Class Initialized
DEBUG - 2018-01-19 15:49:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:49:17 --> Input Class Initialized
INFO - 2018-01-19 15:49:17 --> Language Class Initialized
INFO - 2018-01-19 15:49:17 --> Loader Class Initialized
INFO - 2018-01-19 15:49:17 --> Helper loaded: url_helper
INFO - 2018-01-19 15:49:17 --> Helper loaded: form_helper
INFO - 2018-01-19 15:49:17 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:49:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:49:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:49:17 --> Form Validation Class Initialized
INFO - 2018-01-19 15:49:17 --> Model Class Initialized
INFO - 2018-01-19 15:49:17 --> Controller Class Initialized
INFO - 2018-01-19 15:49:17 --> Model Class Initialized
INFO - 2018-01-19 15:49:17 --> Model Class Initialized
INFO - 2018-01-19 15:49:17 --> Model Class Initialized
INFO - 2018-01-19 15:49:17 --> Model Class Initialized
DEBUG - 2018-01-19 15:49:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:49:18 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 15:49:18 --> Final output sent to browser
DEBUG - 2018-01-19 15:49:18 --> Total execution time: 0.1187
INFO - 2018-01-19 15:49:29 --> Config Class Initialized
INFO - 2018-01-19 15:49:29 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:49:29 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:49:29 --> Utf8 Class Initialized
INFO - 2018-01-19 15:49:29 --> URI Class Initialized
INFO - 2018-01-19 15:49:29 --> Router Class Initialized
INFO - 2018-01-19 15:49:29 --> Output Class Initialized
INFO - 2018-01-19 15:49:29 --> Config Class Initialized
INFO - 2018-01-19 15:49:29 --> Hooks Class Initialized
INFO - 2018-01-19 15:49:29 --> Security Class Initialized
DEBUG - 2018-01-19 15:49:29 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:49:29 --> Utf8 Class Initialized
DEBUG - 2018-01-19 15:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:49:29 --> Input Class Initialized
INFO - 2018-01-19 15:49:29 --> URI Class Initialized
INFO - 2018-01-19 15:49:29 --> Language Class Initialized
INFO - 2018-01-19 15:49:29 --> Router Class Initialized
INFO - 2018-01-19 15:49:29 --> Output Class Initialized
INFO - 2018-01-19 15:49:29 --> Loader Class Initialized
INFO - 2018-01-19 15:49:29 --> Security Class Initialized
INFO - 2018-01-19 15:49:29 --> Helper loaded: url_helper
DEBUG - 2018-01-19 15:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:49:29 --> Input Class Initialized
INFO - 2018-01-19 15:49:29 --> Helper loaded: form_helper
INFO - 2018-01-19 15:49:29 --> Language Class Initialized
INFO - 2018-01-19 15:49:29 --> Loader Class Initialized
INFO - 2018-01-19 15:49:29 --> Helper loaded: url_helper
INFO - 2018-01-19 15:49:29 --> Helper loaded: form_helper
INFO - 2018-01-19 15:49:29 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:49:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:49:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:49:29 --> Form Validation Class Initialized
INFO - 2018-01-19 15:49:29 --> Database Driver Class Initialized
INFO - 2018-01-19 15:49:29 --> Model Class Initialized
INFO - 2018-01-19 15:49:29 --> Controller Class Initialized
DEBUG - 2018-01-19 15:49:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:49:29 --> Model Class Initialized
INFO - 2018-01-19 15:49:29 --> Model Class Initialized
INFO - 2018-01-19 15:49:29 --> Model Class Initialized
INFO - 2018-01-19 15:49:29 --> Model Class Initialized
DEBUG - 2018-01-19 15:49:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:49:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:49:29 --> Form Validation Class Initialized
INFO - 2018-01-19 15:49:29 --> Model Class Initialized
INFO - 2018-01-19 15:49:29 --> Controller Class Initialized
INFO - 2018-01-19 15:49:29 --> Model Class Initialized
INFO - 2018-01-19 15:49:29 --> Model Class Initialized
INFO - 2018-01-19 15:49:29 --> Model Class Initialized
INFO - 2018-01-19 15:49:29 --> Model Class Initialized
DEBUG - 2018-01-19 15:49:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:49:45 --> Config Class Initialized
INFO - 2018-01-19 15:49:45 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:49:45 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:49:45 --> Utf8 Class Initialized
INFO - 2018-01-19 15:49:45 --> URI Class Initialized
INFO - 2018-01-19 15:49:45 --> Router Class Initialized
INFO - 2018-01-19 15:49:45 --> Output Class Initialized
INFO - 2018-01-19 15:49:45 --> Security Class Initialized
DEBUG - 2018-01-19 15:49:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:49:45 --> Input Class Initialized
INFO - 2018-01-19 15:49:45 --> Language Class Initialized
INFO - 2018-01-19 15:49:45 --> Loader Class Initialized
INFO - 2018-01-19 15:49:45 --> Helper loaded: url_helper
INFO - 2018-01-19 15:49:45 --> Helper loaded: form_helper
INFO - 2018-01-19 15:49:45 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:49:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:49:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:49:45 --> Form Validation Class Initialized
INFO - 2018-01-19 15:49:45 --> Model Class Initialized
INFO - 2018-01-19 15:49:45 --> Controller Class Initialized
INFO - 2018-01-19 15:49:45 --> Model Class Initialized
INFO - 2018-01-19 15:49:45 --> Model Class Initialized
INFO - 2018-01-19 15:49:45 --> Model Class Initialized
INFO - 2018-01-19 15:49:45 --> Model Class Initialized
DEBUG - 2018-01-19 15:49:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:49:46 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 15:49:46 --> Final output sent to browser
DEBUG - 2018-01-19 15:49:46 --> Total execution time: 0.0982
INFO - 2018-01-19 15:49:46 --> Config Class Initialized
INFO - 2018-01-19 15:49:46 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:49:46 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:49:46 --> Utf8 Class Initialized
INFO - 2018-01-19 15:49:46 --> URI Class Initialized
INFO - 2018-01-19 15:49:46 --> Router Class Initialized
INFO - 2018-01-19 15:49:46 --> Output Class Initialized
INFO - 2018-01-19 15:49:46 --> Security Class Initialized
DEBUG - 2018-01-19 15:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:49:46 --> Input Class Initialized
INFO - 2018-01-19 15:49:46 --> Language Class Initialized
INFO - 2018-01-19 15:49:46 --> Loader Class Initialized
INFO - 2018-01-19 15:49:46 --> Helper loaded: url_helper
INFO - 2018-01-19 15:49:46 --> Helper loaded: form_helper
INFO - 2018-01-19 15:49:46 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:49:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:49:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:49:46 --> Form Validation Class Initialized
INFO - 2018-01-19 15:49:46 --> Model Class Initialized
INFO - 2018-01-19 15:49:46 --> Controller Class Initialized
INFO - 2018-01-19 15:49:46 --> Model Class Initialized
INFO - 2018-01-19 15:49:46 --> Model Class Initialized
INFO - 2018-01-19 15:49:46 --> Model Class Initialized
INFO - 2018-01-19 15:49:46 --> Model Class Initialized
DEBUG - 2018-01-19 15:49:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:49:46 --> Config Class Initialized
INFO - 2018-01-19 15:49:46 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:49:46 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:49:46 --> Utf8 Class Initialized
INFO - 2018-01-19 15:49:46 --> URI Class Initialized
INFO - 2018-01-19 15:49:46 --> Router Class Initialized
INFO - 2018-01-19 15:49:46 --> Output Class Initialized
INFO - 2018-01-19 15:49:46 --> Security Class Initialized
DEBUG - 2018-01-19 15:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:49:46 --> Input Class Initialized
INFO - 2018-01-19 15:49:46 --> Language Class Initialized
INFO - 2018-01-19 15:49:46 --> Loader Class Initialized
INFO - 2018-01-19 15:49:46 --> Helper loaded: url_helper
INFO - 2018-01-19 15:49:46 --> Helper loaded: form_helper
INFO - 2018-01-19 15:49:46 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:49:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:49:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:49:46 --> Form Validation Class Initialized
INFO - 2018-01-19 15:49:46 --> Model Class Initialized
INFO - 2018-01-19 15:49:46 --> Controller Class Initialized
INFO - 2018-01-19 15:49:46 --> Model Class Initialized
INFO - 2018-01-19 15:49:46 --> Model Class Initialized
INFO - 2018-01-19 15:49:46 --> Model Class Initialized
INFO - 2018-01-19 15:49:46 --> Model Class Initialized
DEBUG - 2018-01-19 15:49:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:50:33 --> Config Class Initialized
INFO - 2018-01-19 15:50:33 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:50:33 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:50:33 --> Utf8 Class Initialized
INFO - 2018-01-19 15:50:33 --> URI Class Initialized
DEBUG - 2018-01-19 15:50:33 --> No URI present. Default controller set.
INFO - 2018-01-19 15:50:33 --> Router Class Initialized
INFO - 2018-01-19 15:50:33 --> Output Class Initialized
INFO - 2018-01-19 15:50:33 --> Security Class Initialized
DEBUG - 2018-01-19 15:50:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:50:33 --> Input Class Initialized
INFO - 2018-01-19 15:50:33 --> Language Class Initialized
INFO - 2018-01-19 15:50:33 --> Loader Class Initialized
INFO - 2018-01-19 15:50:33 --> Helper loaded: url_helper
INFO - 2018-01-19 15:50:33 --> Helper loaded: form_helper
INFO - 2018-01-19 15:50:33 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:50:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:50:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:50:33 --> Form Validation Class Initialized
INFO - 2018-01-19 15:50:33 --> Model Class Initialized
INFO - 2018-01-19 15:50:33 --> Controller Class Initialized
INFO - 2018-01-19 15:50:33 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 15:50:33 --> Final output sent to browser
DEBUG - 2018-01-19 15:50:33 --> Total execution time: 0.0347
INFO - 2018-01-19 15:50:37 --> Config Class Initialized
INFO - 2018-01-19 15:50:37 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:50:37 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:50:37 --> Utf8 Class Initialized
INFO - 2018-01-19 15:50:37 --> URI Class Initialized
INFO - 2018-01-19 15:50:37 --> Router Class Initialized
INFO - 2018-01-19 15:50:37 --> Output Class Initialized
INFO - 2018-01-19 15:50:37 --> Security Class Initialized
DEBUG - 2018-01-19 15:50:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:50:37 --> Input Class Initialized
INFO - 2018-01-19 15:50:37 --> Language Class Initialized
INFO - 2018-01-19 15:50:37 --> Loader Class Initialized
INFO - 2018-01-19 15:50:37 --> Helper loaded: url_helper
INFO - 2018-01-19 15:50:37 --> Helper loaded: form_helper
INFO - 2018-01-19 15:50:37 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:50:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:50:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:50:37 --> Form Validation Class Initialized
INFO - 2018-01-19 15:50:37 --> Model Class Initialized
INFO - 2018-01-19 15:50:37 --> Controller Class Initialized
INFO - 2018-01-19 15:50:37 --> Model Class Initialized
INFO - 2018-01-19 15:50:37 --> Model Class Initialized
INFO - 2018-01-19 15:50:37 --> Model Class Initialized
INFO - 2018-01-19 15:50:37 --> Model Class Initialized
DEBUG - 2018-01-19 15:50:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:50:37 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 15:50:37 --> Final output sent to browser
DEBUG - 2018-01-19 15:50:37 --> Total execution time: 0.0445
INFO - 2018-01-19 15:50:37 --> Config Class Initialized
INFO - 2018-01-19 15:50:37 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:50:37 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:50:37 --> Utf8 Class Initialized
INFO - 2018-01-19 15:50:37 --> URI Class Initialized
INFO - 2018-01-19 15:50:37 --> Router Class Initialized
INFO - 2018-01-19 15:50:37 --> Output Class Initialized
INFO - 2018-01-19 15:50:37 --> Security Class Initialized
DEBUG - 2018-01-19 15:50:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:50:37 --> Input Class Initialized
INFO - 2018-01-19 15:50:37 --> Language Class Initialized
INFO - 2018-01-19 15:50:37 --> Loader Class Initialized
INFO - 2018-01-19 15:50:37 --> Helper loaded: url_helper
INFO - 2018-01-19 15:50:37 --> Helper loaded: form_helper
INFO - 2018-01-19 15:50:37 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:50:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:50:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:50:37 --> Form Validation Class Initialized
INFO - 2018-01-19 15:50:37 --> Model Class Initialized
INFO - 2018-01-19 15:50:37 --> Controller Class Initialized
INFO - 2018-01-19 15:50:37 --> Model Class Initialized
INFO - 2018-01-19 15:50:37 --> Model Class Initialized
INFO - 2018-01-19 15:50:37 --> Model Class Initialized
INFO - 2018-01-19 15:50:37 --> Model Class Initialized
DEBUG - 2018-01-19 15:50:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:50:47 --> Config Class Initialized
INFO - 2018-01-19 15:50:47 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:50:47 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:50:47 --> Utf8 Class Initialized
INFO - 2018-01-19 15:50:47 --> URI Class Initialized
INFO - 2018-01-19 15:50:47 --> Router Class Initialized
INFO - 2018-01-19 15:50:47 --> Output Class Initialized
INFO - 2018-01-19 15:50:47 --> Security Class Initialized
DEBUG - 2018-01-19 15:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:50:47 --> Input Class Initialized
INFO - 2018-01-19 15:50:47 --> Language Class Initialized
INFO - 2018-01-19 15:50:47 --> Loader Class Initialized
INFO - 2018-01-19 15:50:47 --> Helper loaded: url_helper
INFO - 2018-01-19 15:50:47 --> Helper loaded: form_helper
INFO - 2018-01-19 15:50:47 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:50:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:50:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:50:47 --> Form Validation Class Initialized
INFO - 2018-01-19 15:50:47 --> Model Class Initialized
INFO - 2018-01-19 15:50:47 --> Controller Class Initialized
INFO - 2018-01-19 15:50:47 --> Model Class Initialized
INFO - 2018-01-19 15:50:47 --> Model Class Initialized
INFO - 2018-01-19 15:50:47 --> Model Class Initialized
INFO - 2018-01-19 15:50:47 --> Model Class Initialized
DEBUG - 2018-01-19 15:50:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:50:47 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 15:50:47 --> Final output sent to browser
DEBUG - 2018-01-19 15:50:47 --> Total execution time: 0.0531
INFO - 2018-01-19 15:50:47 --> Config Class Initialized
INFO - 2018-01-19 15:50:47 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:50:47 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:50:47 --> Utf8 Class Initialized
INFO - 2018-01-19 15:50:47 --> URI Class Initialized
INFO - 2018-01-19 15:50:47 --> Router Class Initialized
INFO - 2018-01-19 15:50:47 --> Output Class Initialized
INFO - 2018-01-19 15:50:47 --> Security Class Initialized
DEBUG - 2018-01-19 15:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:50:47 --> Input Class Initialized
INFO - 2018-01-19 15:50:47 --> Language Class Initialized
INFO - 2018-01-19 15:50:47 --> Loader Class Initialized
INFO - 2018-01-19 15:50:48 --> Helper loaded: url_helper
INFO - 2018-01-19 15:50:48 --> Helper loaded: form_helper
INFO - 2018-01-19 15:50:48 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:50:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:50:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:50:48 --> Form Validation Class Initialized
INFO - 2018-01-19 15:50:48 --> Model Class Initialized
INFO - 2018-01-19 15:50:48 --> Controller Class Initialized
INFO - 2018-01-19 15:50:48 --> Model Class Initialized
INFO - 2018-01-19 15:50:48 --> Model Class Initialized
INFO - 2018-01-19 15:50:48 --> Model Class Initialized
INFO - 2018-01-19 15:50:48 --> Model Class Initialized
DEBUG - 2018-01-19 15:50:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:51:39 --> Config Class Initialized
INFO - 2018-01-19 15:51:39 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:51:39 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:51:39 --> Utf8 Class Initialized
INFO - 2018-01-19 15:51:39 --> URI Class Initialized
INFO - 2018-01-19 15:51:39 --> Router Class Initialized
INFO - 2018-01-19 15:51:39 --> Output Class Initialized
INFO - 2018-01-19 15:51:39 --> Security Class Initialized
DEBUG - 2018-01-19 15:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:51:39 --> Input Class Initialized
INFO - 2018-01-19 15:51:39 --> Language Class Initialized
INFO - 2018-01-19 15:51:39 --> Loader Class Initialized
INFO - 2018-01-19 15:51:39 --> Helper loaded: url_helper
INFO - 2018-01-19 15:51:39 --> Helper loaded: form_helper
INFO - 2018-01-19 15:51:39 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:51:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:51:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:51:39 --> Form Validation Class Initialized
INFO - 2018-01-19 15:51:39 --> Model Class Initialized
INFO - 2018-01-19 15:51:39 --> Controller Class Initialized
INFO - 2018-01-19 15:51:39 --> Model Class Initialized
INFO - 2018-01-19 15:51:39 --> Model Class Initialized
INFO - 2018-01-19 15:51:39 --> Model Class Initialized
INFO - 2018-01-19 15:51:39 --> Model Class Initialized
DEBUG - 2018-01-19 15:51:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:51:39 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 15:51:39 --> Final output sent to browser
DEBUG - 2018-01-19 15:51:39 --> Total execution time: 0.0511
INFO - 2018-01-19 15:51:40 --> Config Class Initialized
INFO - 2018-01-19 15:51:40 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:51:40 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:51:40 --> Utf8 Class Initialized
INFO - 2018-01-19 15:51:40 --> URI Class Initialized
INFO - 2018-01-19 15:51:40 --> Router Class Initialized
INFO - 2018-01-19 15:51:40 --> Output Class Initialized
INFO - 2018-01-19 15:51:40 --> Security Class Initialized
DEBUG - 2018-01-19 15:51:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:51:40 --> Input Class Initialized
INFO - 2018-01-19 15:51:40 --> Language Class Initialized
INFO - 2018-01-19 15:51:40 --> Loader Class Initialized
INFO - 2018-01-19 15:51:40 --> Helper loaded: url_helper
INFO - 2018-01-19 15:51:40 --> Helper loaded: form_helper
INFO - 2018-01-19 15:51:40 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:51:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:51:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:51:40 --> Form Validation Class Initialized
INFO - 2018-01-19 15:51:40 --> Model Class Initialized
INFO - 2018-01-19 15:51:40 --> Controller Class Initialized
INFO - 2018-01-19 15:51:40 --> Model Class Initialized
INFO - 2018-01-19 15:51:40 --> Model Class Initialized
INFO - 2018-01-19 15:51:40 --> Model Class Initialized
INFO - 2018-01-19 15:51:40 --> Model Class Initialized
DEBUG - 2018-01-19 15:51:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:51:40 --> Config Class Initialized
INFO - 2018-01-19 15:51:40 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:51:40 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:51:40 --> Utf8 Class Initialized
INFO - 2018-01-19 15:51:40 --> URI Class Initialized
INFO - 2018-01-19 15:51:40 --> Router Class Initialized
INFO - 2018-01-19 15:51:40 --> Output Class Initialized
INFO - 2018-01-19 15:51:40 --> Security Class Initialized
DEBUG - 2018-01-19 15:51:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:51:40 --> Input Class Initialized
INFO - 2018-01-19 15:51:40 --> Language Class Initialized
INFO - 2018-01-19 15:51:40 --> Loader Class Initialized
INFO - 2018-01-19 15:51:40 --> Helper loaded: url_helper
INFO - 2018-01-19 15:51:40 --> Helper loaded: form_helper
INFO - 2018-01-19 15:51:40 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:51:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:51:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:51:40 --> Form Validation Class Initialized
INFO - 2018-01-19 15:51:40 --> Model Class Initialized
INFO - 2018-01-19 15:51:40 --> Controller Class Initialized
INFO - 2018-01-19 15:51:40 --> Model Class Initialized
INFO - 2018-01-19 15:51:40 --> Model Class Initialized
INFO - 2018-01-19 15:51:40 --> Model Class Initialized
INFO - 2018-01-19 15:51:40 --> Model Class Initialized
DEBUG - 2018-01-19 15:51:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:55:26 --> Config Class Initialized
INFO - 2018-01-19 15:55:26 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:55:26 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:55:26 --> Utf8 Class Initialized
INFO - 2018-01-19 15:55:26 --> URI Class Initialized
INFO - 2018-01-19 15:55:26 --> Router Class Initialized
INFO - 2018-01-19 15:55:26 --> Output Class Initialized
INFO - 2018-01-19 15:55:26 --> Security Class Initialized
DEBUG - 2018-01-19 15:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:55:26 --> Input Class Initialized
INFO - 2018-01-19 15:55:26 --> Language Class Initialized
INFO - 2018-01-19 15:55:26 --> Loader Class Initialized
INFO - 2018-01-19 15:55:26 --> Helper loaded: url_helper
INFO - 2018-01-19 15:55:26 --> Helper loaded: form_helper
INFO - 2018-01-19 15:55:26 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:55:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:55:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:55:26 --> Form Validation Class Initialized
INFO - 2018-01-19 15:55:26 --> Model Class Initialized
INFO - 2018-01-19 15:55:26 --> Controller Class Initialized
INFO - 2018-01-19 15:55:26 --> Model Class Initialized
INFO - 2018-01-19 15:55:26 --> Model Class Initialized
INFO - 2018-01-19 15:55:26 --> Model Class Initialized
INFO - 2018-01-19 15:55:26 --> Model Class Initialized
DEBUG - 2018-01-19 15:55:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:55:28 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 15:55:28 --> Final output sent to browser
DEBUG - 2018-01-19 15:55:28 --> Total execution time: 2.2056
INFO - 2018-01-19 15:55:30 --> Config Class Initialized
INFO - 2018-01-19 15:55:30 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:55:30 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:55:30 --> Utf8 Class Initialized
INFO - 2018-01-19 15:55:30 --> URI Class Initialized
INFO - 2018-01-19 15:55:30 --> Router Class Initialized
INFO - 2018-01-19 15:55:30 --> Output Class Initialized
INFO - 2018-01-19 15:55:30 --> Security Class Initialized
DEBUG - 2018-01-19 15:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:55:30 --> Input Class Initialized
INFO - 2018-01-19 15:55:30 --> Language Class Initialized
INFO - 2018-01-19 15:55:30 --> Loader Class Initialized
INFO - 2018-01-19 15:55:30 --> Helper loaded: url_helper
INFO - 2018-01-19 15:55:30 --> Helper loaded: form_helper
INFO - 2018-01-19 15:55:30 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:55:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:55:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:55:30 --> Form Validation Class Initialized
INFO - 2018-01-19 15:55:30 --> Model Class Initialized
INFO - 2018-01-19 15:55:30 --> Controller Class Initialized
INFO - 2018-01-19 15:55:30 --> Model Class Initialized
INFO - 2018-01-19 15:55:30 --> Model Class Initialized
INFO - 2018-01-19 15:55:30 --> Model Class Initialized
INFO - 2018-01-19 15:55:30 --> Model Class Initialized
DEBUG - 2018-01-19 15:55:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:55:30 --> Config Class Initialized
INFO - 2018-01-19 15:55:30 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:55:30 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:55:30 --> Utf8 Class Initialized
INFO - 2018-01-19 15:55:30 --> URI Class Initialized
INFO - 2018-01-19 15:55:30 --> Router Class Initialized
INFO - 2018-01-19 15:55:30 --> Output Class Initialized
INFO - 2018-01-19 15:55:30 --> Security Class Initialized
DEBUG - 2018-01-19 15:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:55:30 --> Input Class Initialized
INFO - 2018-01-19 15:55:30 --> Language Class Initialized
INFO - 2018-01-19 15:55:30 --> Loader Class Initialized
INFO - 2018-01-19 15:55:30 --> Helper loaded: url_helper
INFO - 2018-01-19 15:55:30 --> Helper loaded: form_helper
INFO - 2018-01-19 15:55:30 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:55:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:55:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:55:30 --> Form Validation Class Initialized
INFO - 2018-01-19 15:55:30 --> Model Class Initialized
INFO - 2018-01-19 15:55:30 --> Controller Class Initialized
INFO - 2018-01-19 15:55:30 --> Model Class Initialized
INFO - 2018-01-19 15:55:30 --> Model Class Initialized
INFO - 2018-01-19 15:55:30 --> Model Class Initialized
INFO - 2018-01-19 15:55:30 --> Model Class Initialized
DEBUG - 2018-01-19 15:55:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:55:44 --> Config Class Initialized
INFO - 2018-01-19 15:55:44 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:55:44 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:55:44 --> Utf8 Class Initialized
INFO - 2018-01-19 15:55:44 --> URI Class Initialized
INFO - 2018-01-19 15:55:44 --> Router Class Initialized
INFO - 2018-01-19 15:55:44 --> Output Class Initialized
INFO - 2018-01-19 15:55:44 --> Security Class Initialized
DEBUG - 2018-01-19 15:55:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:55:44 --> Input Class Initialized
INFO - 2018-01-19 15:55:44 --> Language Class Initialized
INFO - 2018-01-19 15:55:44 --> Loader Class Initialized
INFO - 2018-01-19 15:55:44 --> Helper loaded: url_helper
INFO - 2018-01-19 15:55:44 --> Helper loaded: form_helper
INFO - 2018-01-19 15:55:44 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:55:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:55:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:55:44 --> Form Validation Class Initialized
INFO - 2018-01-19 15:55:44 --> Model Class Initialized
INFO - 2018-01-19 15:55:44 --> Controller Class Initialized
INFO - 2018-01-19 15:55:44 --> Model Class Initialized
INFO - 2018-01-19 15:55:44 --> Model Class Initialized
INFO - 2018-01-19 15:55:44 --> Model Class Initialized
INFO - 2018-01-19 15:55:44 --> Model Class Initialized
DEBUG - 2018-01-19 15:55:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:55:44 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 15:55:44 --> Final output sent to browser
DEBUG - 2018-01-19 15:55:44 --> Total execution time: 0.0498
INFO - 2018-01-19 15:55:51 --> Config Class Initialized
INFO - 2018-01-19 15:55:51 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:55:51 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:55:51 --> Utf8 Class Initialized
INFO - 2018-01-19 15:55:51 --> URI Class Initialized
INFO - 2018-01-19 15:55:51 --> Router Class Initialized
INFO - 2018-01-19 15:55:51 --> Output Class Initialized
INFO - 2018-01-19 15:55:51 --> Security Class Initialized
DEBUG - 2018-01-19 15:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:55:51 --> Input Class Initialized
INFO - 2018-01-19 15:55:51 --> Language Class Initialized
INFO - 2018-01-19 15:55:51 --> Loader Class Initialized
INFO - 2018-01-19 15:55:51 --> Helper loaded: url_helper
INFO - 2018-01-19 15:55:51 --> Helper loaded: form_helper
INFO - 2018-01-19 15:55:51 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:55:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:55:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:55:51 --> Form Validation Class Initialized
INFO - 2018-01-19 15:55:51 --> Model Class Initialized
INFO - 2018-01-19 15:55:51 --> Controller Class Initialized
INFO - 2018-01-19 15:55:51 --> Model Class Initialized
INFO - 2018-01-19 15:55:51 --> Model Class Initialized
INFO - 2018-01-19 15:55:51 --> Model Class Initialized
INFO - 2018-01-19 15:55:51 --> Model Class Initialized
DEBUG - 2018-01-19 15:55:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:55:51 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 15:55:51 --> Final output sent to browser
DEBUG - 2018-01-19 15:55:51 --> Total execution time: 0.0446
INFO - 2018-01-19 15:55:51 --> Config Class Initialized
INFO - 2018-01-19 15:55:51 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:55:51 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:55:51 --> Utf8 Class Initialized
INFO - 2018-01-19 15:55:51 --> URI Class Initialized
INFO - 2018-01-19 15:55:51 --> Router Class Initialized
INFO - 2018-01-19 15:55:51 --> Output Class Initialized
INFO - 2018-01-19 15:55:51 --> Security Class Initialized
DEBUG - 2018-01-19 15:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:55:51 --> Input Class Initialized
INFO - 2018-01-19 15:55:51 --> Language Class Initialized
INFO - 2018-01-19 15:55:51 --> Loader Class Initialized
INFO - 2018-01-19 15:55:51 --> Helper loaded: url_helper
INFO - 2018-01-19 15:55:51 --> Helper loaded: form_helper
INFO - 2018-01-19 15:55:51 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:55:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:55:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:55:51 --> Form Validation Class Initialized
INFO - 2018-01-19 15:55:51 --> Model Class Initialized
INFO - 2018-01-19 15:55:51 --> Controller Class Initialized
INFO - 2018-01-19 15:55:51 --> Model Class Initialized
INFO - 2018-01-19 15:55:51 --> Model Class Initialized
INFO - 2018-01-19 15:55:51 --> Model Class Initialized
INFO - 2018-01-19 15:55:51 --> Model Class Initialized
DEBUG - 2018-01-19 15:55:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:55:56 --> Config Class Initialized
INFO - 2018-01-19 15:55:56 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:55:57 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:55:57 --> Utf8 Class Initialized
INFO - 2018-01-19 15:55:57 --> URI Class Initialized
INFO - 2018-01-19 15:55:57 --> Router Class Initialized
INFO - 2018-01-19 15:55:57 --> Output Class Initialized
INFO - 2018-01-19 15:55:57 --> Security Class Initialized
DEBUG - 2018-01-19 15:55:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:55:57 --> Input Class Initialized
INFO - 2018-01-19 15:55:57 --> Language Class Initialized
INFO - 2018-01-19 15:55:57 --> Loader Class Initialized
INFO - 2018-01-19 15:55:57 --> Helper loaded: url_helper
INFO - 2018-01-19 15:55:57 --> Helper loaded: form_helper
INFO - 2018-01-19 15:55:57 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:55:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:55:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:55:57 --> Form Validation Class Initialized
INFO - 2018-01-19 15:55:57 --> Model Class Initialized
INFO - 2018-01-19 15:55:57 --> Controller Class Initialized
INFO - 2018-01-19 15:55:57 --> Model Class Initialized
INFO - 2018-01-19 15:55:57 --> Model Class Initialized
INFO - 2018-01-19 15:55:57 --> Model Class Initialized
INFO - 2018-01-19 15:55:57 --> Model Class Initialized
DEBUG - 2018-01-19 15:55:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 15:55:57 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 15:55:57 --> Final output sent to browser
DEBUG - 2018-01-19 15:55:57 --> Total execution time: 0.0577
INFO - 2018-01-19 15:55:58 --> Config Class Initialized
INFO - 2018-01-19 15:55:58 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:55:58 --> UTF-8 Support Enabled
INFO - 2018-01-19 15:55:58 --> Utf8 Class Initialized
INFO - 2018-01-19 15:55:58 --> URI Class Initialized
INFO - 2018-01-19 15:55:58 --> Router Class Initialized
INFO - 2018-01-19 15:55:58 --> Output Class Initialized
INFO - 2018-01-19 15:55:58 --> Security Class Initialized
DEBUG - 2018-01-19 15:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 15:55:58 --> Input Class Initialized
INFO - 2018-01-19 15:55:58 --> Language Class Initialized
INFO - 2018-01-19 15:55:58 --> Loader Class Initialized
INFO - 2018-01-19 15:55:58 --> Helper loaded: url_helper
INFO - 2018-01-19 15:55:58 --> Helper loaded: form_helper
INFO - 2018-01-19 15:55:58 --> Database Driver Class Initialized
DEBUG - 2018-01-19 15:55:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 15:55:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 15:55:58 --> Form Validation Class Initialized
INFO - 2018-01-19 15:55:58 --> Model Class Initialized
INFO - 2018-01-19 15:55:58 --> Controller Class Initialized
INFO - 2018-01-19 15:55:58 --> Model Class Initialized
INFO - 2018-01-19 15:55:58 --> Model Class Initialized
INFO - 2018-01-19 15:55:58 --> Model Class Initialized
INFO - 2018-01-19 15:55:58 --> Model Class Initialized
DEBUG - 2018-01-19 15:55:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 16:04:37 --> Config Class Initialized
INFO - 2018-01-19 16:04:37 --> Hooks Class Initialized
DEBUG - 2018-01-19 16:04:37 --> UTF-8 Support Enabled
INFO - 2018-01-19 16:04:37 --> Utf8 Class Initialized
INFO - 2018-01-19 16:04:37 --> URI Class Initialized
INFO - 2018-01-19 16:04:37 --> Router Class Initialized
INFO - 2018-01-19 16:04:37 --> Output Class Initialized
INFO - 2018-01-19 16:04:37 --> Security Class Initialized
DEBUG - 2018-01-19 16:04:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 16:04:37 --> Input Class Initialized
INFO - 2018-01-19 16:04:37 --> Language Class Initialized
INFO - 2018-01-19 16:04:37 --> Loader Class Initialized
INFO - 2018-01-19 16:04:37 --> Helper loaded: url_helper
INFO - 2018-01-19 16:04:37 --> Helper loaded: form_helper
INFO - 2018-01-19 16:04:37 --> Database Driver Class Initialized
DEBUG - 2018-01-19 16:04:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 16:04:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 16:04:37 --> Form Validation Class Initialized
INFO - 2018-01-19 16:04:37 --> Model Class Initialized
INFO - 2018-01-19 16:04:37 --> Controller Class Initialized
INFO - 2018-01-19 16:04:37 --> Model Class Initialized
INFO - 2018-01-19 16:04:37 --> Model Class Initialized
INFO - 2018-01-19 16:04:37 --> Model Class Initialized
INFO - 2018-01-19 16:04:37 --> Model Class Initialized
DEBUG - 2018-01-19 16:04:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 16:04:39 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 16:04:39 --> Final output sent to browser
DEBUG - 2018-01-19 16:04:39 --> Total execution time: 2.0197
INFO - 2018-01-19 16:04:41 --> Config Class Initialized
INFO - 2018-01-19 16:04:41 --> Hooks Class Initialized
DEBUG - 2018-01-19 16:04:41 --> UTF-8 Support Enabled
INFO - 2018-01-19 16:04:41 --> Utf8 Class Initialized
INFO - 2018-01-19 16:04:41 --> URI Class Initialized
INFO - 2018-01-19 16:04:41 --> Router Class Initialized
INFO - 2018-01-19 16:04:41 --> Output Class Initialized
INFO - 2018-01-19 16:04:41 --> Security Class Initialized
DEBUG - 2018-01-19 16:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 16:04:41 --> Input Class Initialized
INFO - 2018-01-19 16:04:41 --> Language Class Initialized
INFO - 2018-01-19 16:04:41 --> Loader Class Initialized
INFO - 2018-01-19 16:04:41 --> Helper loaded: url_helper
INFO - 2018-01-19 16:04:41 --> Helper loaded: form_helper
INFO - 2018-01-19 16:04:41 --> Database Driver Class Initialized
DEBUG - 2018-01-19 16:04:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 16:04:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 16:04:41 --> Form Validation Class Initialized
INFO - 2018-01-19 16:04:41 --> Model Class Initialized
INFO - 2018-01-19 16:04:41 --> Controller Class Initialized
INFO - 2018-01-19 16:04:41 --> Model Class Initialized
INFO - 2018-01-19 16:04:41 --> Model Class Initialized
INFO - 2018-01-19 16:04:41 --> Model Class Initialized
INFO - 2018-01-19 16:04:41 --> Model Class Initialized
DEBUG - 2018-01-19 16:04:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 16:05:58 --> Config Class Initialized
INFO - 2018-01-19 16:05:58 --> Hooks Class Initialized
DEBUG - 2018-01-19 16:05:58 --> UTF-8 Support Enabled
INFO - 2018-01-19 16:05:58 --> Utf8 Class Initialized
INFO - 2018-01-19 16:05:58 --> URI Class Initialized
INFO - 2018-01-19 16:05:58 --> Router Class Initialized
INFO - 2018-01-19 16:05:58 --> Output Class Initialized
INFO - 2018-01-19 16:05:58 --> Security Class Initialized
DEBUG - 2018-01-19 16:05:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 16:05:58 --> Input Class Initialized
INFO - 2018-01-19 16:05:58 --> Language Class Initialized
INFO - 2018-01-19 16:05:58 --> Loader Class Initialized
INFO - 2018-01-19 16:05:58 --> Helper loaded: url_helper
INFO - 2018-01-19 16:05:58 --> Helper loaded: form_helper
INFO - 2018-01-19 16:05:58 --> Database Driver Class Initialized
DEBUG - 2018-01-19 16:05:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 16:05:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 16:05:58 --> Form Validation Class Initialized
INFO - 2018-01-19 16:05:58 --> Model Class Initialized
INFO - 2018-01-19 16:05:58 --> Controller Class Initialized
INFO - 2018-01-19 16:05:58 --> Model Class Initialized
INFO - 2018-01-19 16:05:58 --> Model Class Initialized
INFO - 2018-01-19 16:05:58 --> Model Class Initialized
INFO - 2018-01-19 16:05:58 --> Model Class Initialized
DEBUG - 2018-01-19 16:05:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 16:05:58 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 16:05:58 --> Final output sent to browser
DEBUG - 2018-01-19 16:05:58 --> Total execution time: 0.0512
INFO - 2018-01-19 16:05:59 --> Config Class Initialized
INFO - 2018-01-19 16:05:59 --> Hooks Class Initialized
DEBUG - 2018-01-19 16:05:59 --> UTF-8 Support Enabled
INFO - 2018-01-19 16:05:59 --> Utf8 Class Initialized
INFO - 2018-01-19 16:05:59 --> URI Class Initialized
INFO - 2018-01-19 16:05:59 --> Router Class Initialized
INFO - 2018-01-19 16:05:59 --> Output Class Initialized
INFO - 2018-01-19 16:05:59 --> Security Class Initialized
DEBUG - 2018-01-19 16:05:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 16:05:59 --> Input Class Initialized
INFO - 2018-01-19 16:05:59 --> Language Class Initialized
INFO - 2018-01-19 16:05:59 --> Loader Class Initialized
INFO - 2018-01-19 16:05:59 --> Helper loaded: url_helper
INFO - 2018-01-19 16:05:59 --> Helper loaded: form_helper
INFO - 2018-01-19 16:05:59 --> Database Driver Class Initialized
DEBUG - 2018-01-19 16:05:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 16:05:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 16:05:59 --> Form Validation Class Initialized
INFO - 2018-01-19 16:05:59 --> Model Class Initialized
INFO - 2018-01-19 16:05:59 --> Controller Class Initialized
INFO - 2018-01-19 16:05:59 --> Model Class Initialized
INFO - 2018-01-19 16:05:59 --> Model Class Initialized
INFO - 2018-01-19 16:05:59 --> Model Class Initialized
INFO - 2018-01-19 16:05:59 --> Model Class Initialized
DEBUG - 2018-01-19 16:05:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 16:06:04 --> Config Class Initialized
INFO - 2018-01-19 16:06:04 --> Hooks Class Initialized
DEBUG - 2018-01-19 16:06:04 --> UTF-8 Support Enabled
INFO - 2018-01-19 16:06:04 --> Utf8 Class Initialized
INFO - 2018-01-19 16:06:04 --> URI Class Initialized
INFO - 2018-01-19 16:06:04 --> Router Class Initialized
INFO - 2018-01-19 16:06:04 --> Output Class Initialized
INFO - 2018-01-19 16:06:04 --> Security Class Initialized
DEBUG - 2018-01-19 16:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 16:06:04 --> Input Class Initialized
INFO - 2018-01-19 16:06:04 --> Language Class Initialized
INFO - 2018-01-19 16:06:04 --> Loader Class Initialized
INFO - 2018-01-19 16:06:04 --> Helper loaded: url_helper
INFO - 2018-01-19 16:06:04 --> Helper loaded: form_helper
INFO - 2018-01-19 16:06:04 --> Database Driver Class Initialized
DEBUG - 2018-01-19 16:06:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 16:06:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 16:06:04 --> Form Validation Class Initialized
INFO - 2018-01-19 16:06:04 --> Model Class Initialized
INFO - 2018-01-19 16:06:04 --> Controller Class Initialized
INFO - 2018-01-19 16:06:04 --> Model Class Initialized
INFO - 2018-01-19 16:06:04 --> Model Class Initialized
INFO - 2018-01-19 16:06:04 --> Model Class Initialized
INFO - 2018-01-19 16:06:04 --> Model Class Initialized
DEBUG - 2018-01-19 16:06:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 16:06:04 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 16:06:04 --> Final output sent to browser
DEBUG - 2018-01-19 16:06:04 --> Total execution time: 0.0508
INFO - 2018-01-19 16:06:05 --> Config Class Initialized
INFO - 2018-01-19 16:06:05 --> Hooks Class Initialized
DEBUG - 2018-01-19 16:06:05 --> UTF-8 Support Enabled
INFO - 2018-01-19 16:06:05 --> Utf8 Class Initialized
INFO - 2018-01-19 16:06:05 --> URI Class Initialized
INFO - 2018-01-19 16:06:05 --> Router Class Initialized
INFO - 2018-01-19 16:06:05 --> Output Class Initialized
INFO - 2018-01-19 16:06:05 --> Security Class Initialized
DEBUG - 2018-01-19 16:06:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 16:06:05 --> Input Class Initialized
INFO - 2018-01-19 16:06:05 --> Language Class Initialized
INFO - 2018-01-19 16:06:05 --> Loader Class Initialized
INFO - 2018-01-19 16:06:05 --> Helper loaded: url_helper
INFO - 2018-01-19 16:06:05 --> Helper loaded: form_helper
INFO - 2018-01-19 16:06:05 --> Database Driver Class Initialized
DEBUG - 2018-01-19 16:06:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 16:06:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 16:06:05 --> Form Validation Class Initialized
INFO - 2018-01-19 16:06:05 --> Model Class Initialized
INFO - 2018-01-19 16:06:05 --> Controller Class Initialized
INFO - 2018-01-19 16:06:05 --> Model Class Initialized
INFO - 2018-01-19 16:06:05 --> Model Class Initialized
INFO - 2018-01-19 16:06:05 --> Model Class Initialized
INFO - 2018-01-19 16:06:05 --> Model Class Initialized
DEBUG - 2018-01-19 16:06:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 16:07:20 --> Config Class Initialized
INFO - 2018-01-19 16:07:20 --> Hooks Class Initialized
DEBUG - 2018-01-19 16:07:20 --> UTF-8 Support Enabled
INFO - 2018-01-19 16:07:20 --> Utf8 Class Initialized
INFO - 2018-01-19 16:07:20 --> URI Class Initialized
INFO - 2018-01-19 16:07:20 --> Router Class Initialized
INFO - 2018-01-19 16:07:20 --> Output Class Initialized
INFO - 2018-01-19 16:07:20 --> Security Class Initialized
DEBUG - 2018-01-19 16:07:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 16:07:20 --> Input Class Initialized
INFO - 2018-01-19 16:07:20 --> Language Class Initialized
INFO - 2018-01-19 16:07:20 --> Loader Class Initialized
INFO - 2018-01-19 16:07:20 --> Helper loaded: url_helper
INFO - 2018-01-19 16:07:20 --> Helper loaded: form_helper
INFO - 2018-01-19 16:07:20 --> Database Driver Class Initialized
DEBUG - 2018-01-19 16:07:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 16:07:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 16:07:20 --> Form Validation Class Initialized
INFO - 2018-01-19 16:07:20 --> Model Class Initialized
INFO - 2018-01-19 16:07:20 --> Controller Class Initialized
INFO - 2018-01-19 16:07:20 --> Model Class Initialized
INFO - 2018-01-19 16:07:20 --> Model Class Initialized
INFO - 2018-01-19 16:07:20 --> Model Class Initialized
INFO - 2018-01-19 16:07:20 --> Model Class Initialized
DEBUG - 2018-01-19 16:07:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 16:07:20 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 16:07:20 --> Final output sent to browser
DEBUG - 2018-01-19 16:07:20 --> Total execution time: 0.0545
INFO - 2018-01-19 16:07:21 --> Config Class Initialized
INFO - 2018-01-19 16:07:21 --> Hooks Class Initialized
DEBUG - 2018-01-19 16:07:21 --> UTF-8 Support Enabled
INFO - 2018-01-19 16:07:21 --> Utf8 Class Initialized
INFO - 2018-01-19 16:07:21 --> URI Class Initialized
INFO - 2018-01-19 16:07:21 --> Router Class Initialized
INFO - 2018-01-19 16:07:21 --> Output Class Initialized
INFO - 2018-01-19 16:07:21 --> Security Class Initialized
DEBUG - 2018-01-19 16:07:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 16:07:21 --> Input Class Initialized
INFO - 2018-01-19 16:07:21 --> Language Class Initialized
INFO - 2018-01-19 16:07:21 --> Loader Class Initialized
INFO - 2018-01-19 16:07:21 --> Helper loaded: url_helper
INFO - 2018-01-19 16:07:21 --> Helper loaded: form_helper
INFO - 2018-01-19 16:07:21 --> Database Driver Class Initialized
DEBUG - 2018-01-19 16:07:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 16:07:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 16:07:21 --> Form Validation Class Initialized
INFO - 2018-01-19 16:07:21 --> Model Class Initialized
INFO - 2018-01-19 16:07:21 --> Controller Class Initialized
INFO - 2018-01-19 16:07:21 --> Model Class Initialized
INFO - 2018-01-19 16:07:21 --> Model Class Initialized
INFO - 2018-01-19 16:07:21 --> Model Class Initialized
INFO - 2018-01-19 16:07:21 --> Model Class Initialized
DEBUG - 2018-01-19 16:07:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 16:07:36 --> Config Class Initialized
INFO - 2018-01-19 16:07:36 --> Hooks Class Initialized
DEBUG - 2018-01-19 16:07:36 --> UTF-8 Support Enabled
INFO - 2018-01-19 16:07:36 --> Utf8 Class Initialized
INFO - 2018-01-19 16:07:36 --> URI Class Initialized
INFO - 2018-01-19 16:07:36 --> Router Class Initialized
INFO - 2018-01-19 16:07:36 --> Output Class Initialized
INFO - 2018-01-19 16:07:36 --> Security Class Initialized
DEBUG - 2018-01-19 16:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 16:07:36 --> Input Class Initialized
INFO - 2018-01-19 16:07:36 --> Language Class Initialized
INFO - 2018-01-19 16:07:36 --> Loader Class Initialized
INFO - 2018-01-19 16:07:36 --> Helper loaded: url_helper
INFO - 2018-01-19 16:07:36 --> Helper loaded: form_helper
INFO - 2018-01-19 16:07:36 --> Database Driver Class Initialized
DEBUG - 2018-01-19 16:07:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 16:07:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 16:07:36 --> Form Validation Class Initialized
INFO - 2018-01-19 16:07:36 --> Model Class Initialized
INFO - 2018-01-19 16:07:36 --> Controller Class Initialized
INFO - 2018-01-19 16:07:36 --> Model Class Initialized
INFO - 2018-01-19 16:07:36 --> Model Class Initialized
INFO - 2018-01-19 16:07:36 --> Model Class Initialized
INFO - 2018-01-19 16:07:36 --> Model Class Initialized
DEBUG - 2018-01-19 16:07:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 16:07:36 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 16:07:36 --> Final output sent to browser
DEBUG - 2018-01-19 16:07:36 --> Total execution time: 0.0510
INFO - 2018-01-19 16:08:16 --> Config Class Initialized
INFO - 2018-01-19 16:08:16 --> Hooks Class Initialized
DEBUG - 2018-01-19 16:08:16 --> UTF-8 Support Enabled
INFO - 2018-01-19 16:08:16 --> Utf8 Class Initialized
INFO - 2018-01-19 16:08:16 --> URI Class Initialized
INFO - 2018-01-19 16:08:16 --> Router Class Initialized
INFO - 2018-01-19 16:08:16 --> Output Class Initialized
INFO - 2018-01-19 16:08:16 --> Security Class Initialized
DEBUG - 2018-01-19 16:08:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 16:08:16 --> Input Class Initialized
INFO - 2018-01-19 16:08:16 --> Language Class Initialized
INFO - 2018-01-19 16:08:16 --> Loader Class Initialized
INFO - 2018-01-19 16:08:16 --> Helper loaded: url_helper
INFO - 2018-01-19 16:08:16 --> Helper loaded: form_helper
INFO - 2018-01-19 16:08:16 --> Database Driver Class Initialized
DEBUG - 2018-01-19 16:08:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 16:08:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 16:08:16 --> Form Validation Class Initialized
INFO - 2018-01-19 16:08:16 --> Model Class Initialized
INFO - 2018-01-19 16:08:16 --> Controller Class Initialized
INFO - 2018-01-19 16:08:16 --> Model Class Initialized
INFO - 2018-01-19 16:08:16 --> Model Class Initialized
INFO - 2018-01-19 16:08:16 --> Model Class Initialized
INFO - 2018-01-19 16:08:16 --> Model Class Initialized
DEBUG - 2018-01-19 16:08:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 16:08:16 --> Config Class Initialized
INFO - 2018-01-19 16:08:16 --> Hooks Class Initialized
DEBUG - 2018-01-19 16:08:16 --> UTF-8 Support Enabled
INFO - 2018-01-19 16:08:16 --> Utf8 Class Initialized
INFO - 2018-01-19 16:08:16 --> URI Class Initialized
INFO - 2018-01-19 16:08:16 --> Router Class Initialized
INFO - 2018-01-19 16:08:16 --> Output Class Initialized
INFO - 2018-01-19 16:08:16 --> Security Class Initialized
DEBUG - 2018-01-19 16:08:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 16:08:16 --> Input Class Initialized
INFO - 2018-01-19 16:08:16 --> Language Class Initialized
INFO - 2018-01-19 16:08:16 --> Loader Class Initialized
INFO - 2018-01-19 16:08:16 --> Helper loaded: url_helper
INFO - 2018-01-19 16:08:16 --> Helper loaded: form_helper
INFO - 2018-01-19 16:08:16 --> Database Driver Class Initialized
DEBUG - 2018-01-19 16:08:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 16:08:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 16:08:16 --> Form Validation Class Initialized
INFO - 2018-01-19 16:08:16 --> Model Class Initialized
INFO - 2018-01-19 16:08:16 --> Controller Class Initialized
INFO - 2018-01-19 16:08:16 --> Model Class Initialized
INFO - 2018-01-19 16:08:16 --> Model Class Initialized
INFO - 2018-01-19 16:08:16 --> Model Class Initialized
INFO - 2018-01-19 16:08:16 --> Model Class Initialized
DEBUG - 2018-01-19 16:08:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 16:08:16 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 16:08:16 --> Final output sent to browser
DEBUG - 2018-01-19 16:08:16 --> Total execution time: 0.0547
INFO - 2018-01-19 16:08:17 --> Config Class Initialized
INFO - 2018-01-19 16:08:17 --> Hooks Class Initialized
DEBUG - 2018-01-19 16:08:17 --> UTF-8 Support Enabled
INFO - 2018-01-19 16:08:17 --> Utf8 Class Initialized
INFO - 2018-01-19 16:08:17 --> URI Class Initialized
INFO - 2018-01-19 16:08:17 --> Router Class Initialized
INFO - 2018-01-19 16:08:17 --> Output Class Initialized
INFO - 2018-01-19 16:08:17 --> Security Class Initialized
DEBUG - 2018-01-19 16:08:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 16:08:17 --> Input Class Initialized
INFO - 2018-01-19 16:08:17 --> Language Class Initialized
INFO - 2018-01-19 16:08:17 --> Loader Class Initialized
INFO - 2018-01-19 16:08:17 --> Helper loaded: url_helper
INFO - 2018-01-19 16:08:17 --> Helper loaded: form_helper
INFO - 2018-01-19 16:08:17 --> Database Driver Class Initialized
DEBUG - 2018-01-19 16:08:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 16:08:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 16:08:17 --> Form Validation Class Initialized
INFO - 2018-01-19 16:08:17 --> Model Class Initialized
INFO - 2018-01-19 16:08:17 --> Controller Class Initialized
INFO - 2018-01-19 16:08:17 --> Model Class Initialized
INFO - 2018-01-19 16:08:17 --> Model Class Initialized
INFO - 2018-01-19 16:08:17 --> Model Class Initialized
INFO - 2018-01-19 16:08:17 --> Model Class Initialized
DEBUG - 2018-01-19 16:08:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 16:08:21 --> Config Class Initialized
INFO - 2018-01-19 16:08:21 --> Hooks Class Initialized
DEBUG - 2018-01-19 16:08:21 --> UTF-8 Support Enabled
INFO - 2018-01-19 16:08:21 --> Utf8 Class Initialized
INFO - 2018-01-19 16:08:21 --> URI Class Initialized
INFO - 2018-01-19 16:08:21 --> Router Class Initialized
INFO - 2018-01-19 16:08:21 --> Output Class Initialized
INFO - 2018-01-19 16:08:21 --> Security Class Initialized
DEBUG - 2018-01-19 16:08:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 16:08:21 --> Input Class Initialized
INFO - 2018-01-19 16:08:21 --> Language Class Initialized
INFO - 2018-01-19 16:08:21 --> Loader Class Initialized
INFO - 2018-01-19 16:08:21 --> Helper loaded: url_helper
INFO - 2018-01-19 16:08:21 --> Helper loaded: form_helper
INFO - 2018-01-19 16:08:21 --> Database Driver Class Initialized
DEBUG - 2018-01-19 16:08:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 16:08:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 16:08:21 --> Form Validation Class Initialized
INFO - 2018-01-19 16:08:21 --> Model Class Initialized
INFO - 2018-01-19 16:08:21 --> Controller Class Initialized
INFO - 2018-01-19 16:08:21 --> Model Class Initialized
INFO - 2018-01-19 16:08:21 --> Model Class Initialized
INFO - 2018-01-19 16:08:21 --> Model Class Initialized
INFO - 2018-01-19 16:08:21 --> Model Class Initialized
DEBUG - 2018-01-19 16:08:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 16:08:21 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 16:08:21 --> Final output sent to browser
DEBUG - 2018-01-19 16:08:21 --> Total execution time: 0.0503
INFO - 2018-01-19 16:08:22 --> Config Class Initialized
INFO - 2018-01-19 16:08:22 --> Hooks Class Initialized
DEBUG - 2018-01-19 16:08:22 --> UTF-8 Support Enabled
INFO - 2018-01-19 16:08:22 --> Utf8 Class Initialized
INFO - 2018-01-19 16:08:22 --> URI Class Initialized
INFO - 2018-01-19 16:08:22 --> Router Class Initialized
INFO - 2018-01-19 16:08:22 --> Output Class Initialized
INFO - 2018-01-19 16:08:22 --> Security Class Initialized
DEBUG - 2018-01-19 16:08:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 16:08:22 --> Input Class Initialized
INFO - 2018-01-19 16:08:22 --> Language Class Initialized
INFO - 2018-01-19 16:08:22 --> Loader Class Initialized
INFO - 2018-01-19 16:08:22 --> Helper loaded: url_helper
INFO - 2018-01-19 16:08:22 --> Helper loaded: form_helper
INFO - 2018-01-19 16:08:22 --> Database Driver Class Initialized
DEBUG - 2018-01-19 16:08:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 16:08:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 16:08:22 --> Form Validation Class Initialized
INFO - 2018-01-19 16:08:22 --> Model Class Initialized
INFO - 2018-01-19 16:08:22 --> Controller Class Initialized
INFO - 2018-01-19 16:08:22 --> Model Class Initialized
INFO - 2018-01-19 16:08:22 --> Model Class Initialized
INFO - 2018-01-19 16:08:22 --> Model Class Initialized
INFO - 2018-01-19 16:08:22 --> Model Class Initialized
DEBUG - 2018-01-19 16:08:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 16:12:47 --> Config Class Initialized
INFO - 2018-01-19 16:12:47 --> Hooks Class Initialized
DEBUG - 2018-01-19 16:12:47 --> UTF-8 Support Enabled
INFO - 2018-01-19 16:12:47 --> Utf8 Class Initialized
INFO - 2018-01-19 16:12:47 --> URI Class Initialized
INFO - 2018-01-19 16:12:47 --> Router Class Initialized
INFO - 2018-01-19 16:12:47 --> Output Class Initialized
INFO - 2018-01-19 16:12:47 --> Security Class Initialized
DEBUG - 2018-01-19 16:12:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 16:12:47 --> Input Class Initialized
INFO - 2018-01-19 16:12:47 --> Language Class Initialized
INFO - 2018-01-19 16:12:47 --> Loader Class Initialized
INFO - 2018-01-19 16:12:47 --> Helper loaded: url_helper
INFO - 2018-01-19 16:12:47 --> Helper loaded: form_helper
INFO - 2018-01-19 16:12:47 --> Database Driver Class Initialized
DEBUG - 2018-01-19 16:12:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 16:12:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 16:12:47 --> Form Validation Class Initialized
INFO - 2018-01-19 16:12:47 --> Model Class Initialized
INFO - 2018-01-19 16:12:47 --> Controller Class Initialized
INFO - 2018-01-19 16:12:47 --> Model Class Initialized
INFO - 2018-01-19 16:12:47 --> Model Class Initialized
INFO - 2018-01-19 16:12:47 --> Model Class Initialized
INFO - 2018-01-19 16:12:47 --> Model Class Initialized
DEBUG - 2018-01-19 16:12:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 16:12:47 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 16:12:47 --> Final output sent to browser
DEBUG - 2018-01-19 16:12:47 --> Total execution time: 0.0531
INFO - 2018-01-19 16:12:49 --> Config Class Initialized
INFO - 2018-01-19 16:12:49 --> Hooks Class Initialized
DEBUG - 2018-01-19 16:12:49 --> UTF-8 Support Enabled
INFO - 2018-01-19 16:12:49 --> Utf8 Class Initialized
INFO - 2018-01-19 16:12:49 --> URI Class Initialized
INFO - 2018-01-19 16:12:49 --> Router Class Initialized
INFO - 2018-01-19 16:12:49 --> Output Class Initialized
INFO - 2018-01-19 16:12:49 --> Security Class Initialized
DEBUG - 2018-01-19 16:12:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 16:12:49 --> Input Class Initialized
INFO - 2018-01-19 16:12:49 --> Language Class Initialized
INFO - 2018-01-19 16:12:49 --> Loader Class Initialized
INFO - 2018-01-19 16:12:49 --> Helper loaded: url_helper
INFO - 2018-01-19 16:12:49 --> Helper loaded: form_helper
INFO - 2018-01-19 16:12:49 --> Database Driver Class Initialized
DEBUG - 2018-01-19 16:12:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 16:12:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 16:12:49 --> Form Validation Class Initialized
INFO - 2018-01-19 16:12:49 --> Model Class Initialized
INFO - 2018-01-19 16:12:49 --> Controller Class Initialized
INFO - 2018-01-19 16:12:49 --> Model Class Initialized
INFO - 2018-01-19 16:12:49 --> Model Class Initialized
INFO - 2018-01-19 16:12:49 --> Model Class Initialized
INFO - 2018-01-19 16:12:49 --> Model Class Initialized
DEBUG - 2018-01-19 16:12:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 16:12:49 --> Config Class Initialized
INFO - 2018-01-19 16:12:49 --> Hooks Class Initialized
DEBUG - 2018-01-19 16:12:49 --> UTF-8 Support Enabled
INFO - 2018-01-19 16:12:49 --> Utf8 Class Initialized
INFO - 2018-01-19 16:12:49 --> URI Class Initialized
INFO - 2018-01-19 16:12:49 --> Router Class Initialized
INFO - 2018-01-19 16:12:49 --> Output Class Initialized
INFO - 2018-01-19 16:12:49 --> Security Class Initialized
DEBUG - 2018-01-19 16:12:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 16:12:49 --> Input Class Initialized
INFO - 2018-01-19 16:12:49 --> Language Class Initialized
INFO - 2018-01-19 16:12:49 --> Loader Class Initialized
INFO - 2018-01-19 16:12:49 --> Helper loaded: url_helper
INFO - 2018-01-19 16:12:49 --> Helper loaded: form_helper
INFO - 2018-01-19 16:12:49 --> Database Driver Class Initialized
DEBUG - 2018-01-19 16:12:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 16:12:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 16:12:49 --> Form Validation Class Initialized
INFO - 2018-01-19 16:12:49 --> Model Class Initialized
INFO - 2018-01-19 16:12:49 --> Controller Class Initialized
INFO - 2018-01-19 16:12:49 --> Model Class Initialized
INFO - 2018-01-19 16:12:49 --> Model Class Initialized
INFO - 2018-01-19 16:12:49 --> Model Class Initialized
INFO - 2018-01-19 16:12:49 --> Model Class Initialized
DEBUG - 2018-01-19 16:12:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 16:13:06 --> Config Class Initialized
INFO - 2018-01-19 16:13:06 --> Hooks Class Initialized
DEBUG - 2018-01-19 16:13:06 --> UTF-8 Support Enabled
INFO - 2018-01-19 16:13:06 --> Utf8 Class Initialized
INFO - 2018-01-19 16:13:06 --> URI Class Initialized
INFO - 2018-01-19 16:13:06 --> Router Class Initialized
INFO - 2018-01-19 16:13:06 --> Output Class Initialized
INFO - 2018-01-19 16:13:06 --> Security Class Initialized
DEBUG - 2018-01-19 16:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 16:13:06 --> Input Class Initialized
INFO - 2018-01-19 16:13:06 --> Language Class Initialized
INFO - 2018-01-19 16:13:06 --> Loader Class Initialized
INFO - 2018-01-19 16:13:06 --> Helper loaded: url_helper
INFO - 2018-01-19 16:13:06 --> Helper loaded: form_helper
INFO - 2018-01-19 16:13:06 --> Database Driver Class Initialized
DEBUG - 2018-01-19 16:13:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 16:13:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 16:13:06 --> Form Validation Class Initialized
INFO - 2018-01-19 16:13:06 --> Model Class Initialized
INFO - 2018-01-19 16:13:06 --> Controller Class Initialized
INFO - 2018-01-19 16:13:06 --> Model Class Initialized
INFO - 2018-01-19 16:13:06 --> Model Class Initialized
INFO - 2018-01-19 16:13:06 --> Model Class Initialized
INFO - 2018-01-19 16:13:06 --> Model Class Initialized
DEBUG - 2018-01-19 16:13:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 16:13:06 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 16:13:06 --> Final output sent to browser
DEBUG - 2018-01-19 16:13:06 --> Total execution time: 0.0516
INFO - 2018-01-19 16:13:07 --> Config Class Initialized
INFO - 2018-01-19 16:13:07 --> Hooks Class Initialized
DEBUG - 2018-01-19 16:13:07 --> UTF-8 Support Enabled
INFO - 2018-01-19 16:13:07 --> Utf8 Class Initialized
INFO - 2018-01-19 16:13:07 --> URI Class Initialized
INFO - 2018-01-19 16:13:07 --> Router Class Initialized
INFO - 2018-01-19 16:13:07 --> Output Class Initialized
INFO - 2018-01-19 16:13:07 --> Security Class Initialized
DEBUG - 2018-01-19 16:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 16:13:07 --> Input Class Initialized
INFO - 2018-01-19 16:13:07 --> Language Class Initialized
INFO - 2018-01-19 16:13:07 --> Loader Class Initialized
INFO - 2018-01-19 16:13:07 --> Helper loaded: url_helper
INFO - 2018-01-19 16:13:07 --> Helper loaded: form_helper
INFO - 2018-01-19 16:13:07 --> Database Driver Class Initialized
DEBUG - 2018-01-19 16:13:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 16:13:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 16:13:07 --> Form Validation Class Initialized
INFO - 2018-01-19 16:13:07 --> Model Class Initialized
INFO - 2018-01-19 16:13:07 --> Controller Class Initialized
INFO - 2018-01-19 16:13:07 --> Model Class Initialized
INFO - 2018-01-19 16:13:07 --> Model Class Initialized
INFO - 2018-01-19 16:13:07 --> Model Class Initialized
INFO - 2018-01-19 16:13:07 --> Model Class Initialized
DEBUG - 2018-01-19 16:13:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 16:13:16 --> Config Class Initialized
INFO - 2018-01-19 16:13:16 --> Hooks Class Initialized
DEBUG - 2018-01-19 16:13:16 --> UTF-8 Support Enabled
INFO - 2018-01-19 16:13:16 --> Utf8 Class Initialized
INFO - 2018-01-19 16:13:16 --> URI Class Initialized
INFO - 2018-01-19 16:13:16 --> Router Class Initialized
INFO - 2018-01-19 16:13:16 --> Output Class Initialized
INFO - 2018-01-19 16:13:16 --> Security Class Initialized
DEBUG - 2018-01-19 16:13:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 16:13:16 --> Input Class Initialized
INFO - 2018-01-19 16:13:16 --> Language Class Initialized
INFO - 2018-01-19 16:13:16 --> Loader Class Initialized
INFO - 2018-01-19 16:13:16 --> Helper loaded: url_helper
INFO - 2018-01-19 16:13:16 --> Helper loaded: form_helper
INFO - 2018-01-19 16:13:16 --> Database Driver Class Initialized
DEBUG - 2018-01-19 16:13:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 16:13:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 16:13:16 --> Form Validation Class Initialized
INFO - 2018-01-19 16:13:16 --> Model Class Initialized
INFO - 2018-01-19 16:13:16 --> Controller Class Initialized
INFO - 2018-01-19 16:13:16 --> Model Class Initialized
INFO - 2018-01-19 16:13:16 --> Model Class Initialized
INFO - 2018-01-19 16:13:16 --> Model Class Initialized
INFO - 2018-01-19 16:13:16 --> Model Class Initialized
DEBUG - 2018-01-19 16:13:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 16:13:16 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 16:13:16 --> Final output sent to browser
DEBUG - 2018-01-19 16:13:16 --> Total execution time: 0.0533
INFO - 2018-01-19 16:13:17 --> Config Class Initialized
INFO - 2018-01-19 16:13:17 --> Hooks Class Initialized
DEBUG - 2018-01-19 16:13:17 --> UTF-8 Support Enabled
INFO - 2018-01-19 16:13:17 --> Utf8 Class Initialized
INFO - 2018-01-19 16:13:17 --> URI Class Initialized
INFO - 2018-01-19 16:13:17 --> Router Class Initialized
INFO - 2018-01-19 16:13:17 --> Output Class Initialized
INFO - 2018-01-19 16:13:17 --> Security Class Initialized
DEBUG - 2018-01-19 16:13:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 16:13:17 --> Input Class Initialized
INFO - 2018-01-19 16:13:17 --> Language Class Initialized
INFO - 2018-01-19 16:13:17 --> Loader Class Initialized
INFO - 2018-01-19 16:13:17 --> Helper loaded: url_helper
INFO - 2018-01-19 16:13:17 --> Helper loaded: form_helper
INFO - 2018-01-19 16:13:17 --> Database Driver Class Initialized
DEBUG - 2018-01-19 16:13:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 16:13:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 16:13:17 --> Form Validation Class Initialized
INFO - 2018-01-19 16:13:17 --> Model Class Initialized
INFO - 2018-01-19 16:13:17 --> Controller Class Initialized
INFO - 2018-01-19 16:13:17 --> Model Class Initialized
INFO - 2018-01-19 16:13:17 --> Model Class Initialized
INFO - 2018-01-19 16:13:17 --> Model Class Initialized
INFO - 2018-01-19 16:13:17 --> Model Class Initialized
DEBUG - 2018-01-19 16:13:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 16:13:20 --> Config Class Initialized
INFO - 2018-01-19 16:13:20 --> Hooks Class Initialized
DEBUG - 2018-01-19 16:13:20 --> UTF-8 Support Enabled
INFO - 2018-01-19 16:13:20 --> Utf8 Class Initialized
INFO - 2018-01-19 16:13:20 --> URI Class Initialized
INFO - 2018-01-19 16:13:20 --> Router Class Initialized
INFO - 2018-01-19 16:13:20 --> Output Class Initialized
INFO - 2018-01-19 16:13:20 --> Security Class Initialized
DEBUG - 2018-01-19 16:13:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 16:13:21 --> Input Class Initialized
INFO - 2018-01-19 16:13:21 --> Language Class Initialized
INFO - 2018-01-19 16:13:21 --> Loader Class Initialized
INFO - 2018-01-19 16:13:21 --> Helper loaded: url_helper
INFO - 2018-01-19 16:13:21 --> Helper loaded: form_helper
INFO - 2018-01-19 16:13:21 --> Database Driver Class Initialized
DEBUG - 2018-01-19 16:13:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 16:13:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 16:13:21 --> Form Validation Class Initialized
INFO - 2018-01-19 16:13:21 --> Model Class Initialized
INFO - 2018-01-19 16:13:21 --> Controller Class Initialized
INFO - 2018-01-19 16:13:21 --> Model Class Initialized
INFO - 2018-01-19 16:13:21 --> Model Class Initialized
INFO - 2018-01-19 16:13:21 --> Model Class Initialized
INFO - 2018-01-19 16:13:21 --> Model Class Initialized
DEBUG - 2018-01-19 16:13:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 16:13:21 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 16:13:21 --> Final output sent to browser
DEBUG - 2018-01-19 16:13:21 --> Total execution time: 0.0548
INFO - 2018-01-19 16:14:22 --> Config Class Initialized
INFO - 2018-01-19 16:14:22 --> Hooks Class Initialized
DEBUG - 2018-01-19 16:14:22 --> UTF-8 Support Enabled
INFO - 2018-01-19 16:14:22 --> Utf8 Class Initialized
INFO - 2018-01-19 16:14:22 --> URI Class Initialized
INFO - 2018-01-19 16:14:22 --> Router Class Initialized
INFO - 2018-01-19 16:14:22 --> Output Class Initialized
INFO - 2018-01-19 16:14:22 --> Security Class Initialized
DEBUG - 2018-01-19 16:14:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 16:14:22 --> Input Class Initialized
INFO - 2018-01-19 16:14:22 --> Language Class Initialized
INFO - 2018-01-19 16:14:22 --> Loader Class Initialized
INFO - 2018-01-19 16:14:22 --> Helper loaded: url_helper
INFO - 2018-01-19 16:14:22 --> Helper loaded: form_helper
INFO - 2018-01-19 16:14:22 --> Database Driver Class Initialized
DEBUG - 2018-01-19 16:14:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 16:14:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 16:14:22 --> Form Validation Class Initialized
INFO - 2018-01-19 16:14:22 --> Model Class Initialized
INFO - 2018-01-19 16:14:22 --> Controller Class Initialized
INFO - 2018-01-19 16:14:22 --> Model Class Initialized
INFO - 2018-01-19 16:14:22 --> Model Class Initialized
INFO - 2018-01-19 16:14:22 --> Model Class Initialized
INFO - 2018-01-19 16:14:22 --> Model Class Initialized
DEBUG - 2018-01-19 16:14:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 16:14:22 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 16:14:22 --> Final output sent to browser
DEBUG - 2018-01-19 16:14:22 --> Total execution time: 0.0547
INFO - 2018-01-19 16:14:22 --> Config Class Initialized
INFO - 2018-01-19 16:14:22 --> Hooks Class Initialized
DEBUG - 2018-01-19 16:14:22 --> UTF-8 Support Enabled
INFO - 2018-01-19 16:14:22 --> Utf8 Class Initialized
INFO - 2018-01-19 16:14:22 --> URI Class Initialized
INFO - 2018-01-19 16:14:22 --> Router Class Initialized
INFO - 2018-01-19 16:14:22 --> Output Class Initialized
INFO - 2018-01-19 16:14:22 --> Security Class Initialized
DEBUG - 2018-01-19 16:14:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 16:14:22 --> Input Class Initialized
INFO - 2018-01-19 16:14:22 --> Language Class Initialized
INFO - 2018-01-19 16:14:22 --> Loader Class Initialized
INFO - 2018-01-19 16:14:22 --> Helper loaded: url_helper
INFO - 2018-01-19 16:14:22 --> Helper loaded: form_helper
INFO - 2018-01-19 16:14:22 --> Database Driver Class Initialized
DEBUG - 2018-01-19 16:14:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 16:14:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 16:14:22 --> Form Validation Class Initialized
INFO - 2018-01-19 16:14:22 --> Model Class Initialized
INFO - 2018-01-19 16:14:22 --> Controller Class Initialized
INFO - 2018-01-19 16:14:22 --> Model Class Initialized
INFO - 2018-01-19 16:14:22 --> Model Class Initialized
INFO - 2018-01-19 16:14:22 --> Model Class Initialized
INFO - 2018-01-19 16:14:22 --> Model Class Initialized
DEBUG - 2018-01-19 16:14:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 16:15:13 --> Config Class Initialized
INFO - 2018-01-19 16:15:13 --> Hooks Class Initialized
DEBUG - 2018-01-19 16:15:13 --> UTF-8 Support Enabled
INFO - 2018-01-19 16:15:13 --> Utf8 Class Initialized
INFO - 2018-01-19 16:15:13 --> URI Class Initialized
INFO - 2018-01-19 16:15:13 --> Router Class Initialized
INFO - 2018-01-19 16:15:13 --> Output Class Initialized
INFO - 2018-01-19 16:15:13 --> Security Class Initialized
DEBUG - 2018-01-19 16:15:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 16:15:13 --> Input Class Initialized
INFO - 2018-01-19 16:15:13 --> Language Class Initialized
INFO - 2018-01-19 16:15:13 --> Loader Class Initialized
INFO - 2018-01-19 16:15:13 --> Helper loaded: url_helper
INFO - 2018-01-19 16:15:13 --> Helper loaded: form_helper
INFO - 2018-01-19 16:15:13 --> Database Driver Class Initialized
DEBUG - 2018-01-19 16:15:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 16:15:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 16:15:13 --> Form Validation Class Initialized
INFO - 2018-01-19 16:15:13 --> Model Class Initialized
INFO - 2018-01-19 16:15:13 --> Controller Class Initialized
INFO - 2018-01-19 16:15:13 --> Model Class Initialized
INFO - 2018-01-19 16:15:13 --> Model Class Initialized
INFO - 2018-01-19 16:15:13 --> Model Class Initialized
INFO - 2018-01-19 16:15:13 --> Model Class Initialized
DEBUG - 2018-01-19 16:15:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 16:15:13 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 16:15:13 --> Final output sent to browser
DEBUG - 2018-01-19 16:15:13 --> Total execution time: 0.0573
INFO - 2018-01-19 16:15:27 --> Config Class Initialized
INFO - 2018-01-19 16:15:27 --> Hooks Class Initialized
DEBUG - 2018-01-19 16:15:27 --> UTF-8 Support Enabled
INFO - 2018-01-19 16:15:27 --> Utf8 Class Initialized
INFO - 2018-01-19 16:15:27 --> URI Class Initialized
INFO - 2018-01-19 16:15:27 --> Router Class Initialized
INFO - 2018-01-19 16:15:27 --> Output Class Initialized
INFO - 2018-01-19 16:15:27 --> Security Class Initialized
DEBUG - 2018-01-19 16:15:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 16:15:27 --> Input Class Initialized
INFO - 2018-01-19 16:15:27 --> Language Class Initialized
INFO - 2018-01-19 16:15:27 --> Loader Class Initialized
INFO - 2018-01-19 16:15:27 --> Helper loaded: url_helper
INFO - 2018-01-19 16:15:27 --> Helper loaded: form_helper
INFO - 2018-01-19 16:15:27 --> Database Driver Class Initialized
DEBUG - 2018-01-19 16:15:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 16:15:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 16:15:27 --> Form Validation Class Initialized
INFO - 2018-01-19 16:15:27 --> Model Class Initialized
INFO - 2018-01-19 16:15:27 --> Controller Class Initialized
INFO - 2018-01-19 16:15:27 --> Model Class Initialized
INFO - 2018-01-19 16:15:27 --> Model Class Initialized
INFO - 2018-01-19 16:15:27 --> Model Class Initialized
INFO - 2018-01-19 16:15:27 --> Model Class Initialized
DEBUG - 2018-01-19 16:15:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 16:15:27 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 16:15:27 --> Final output sent to browser
DEBUG - 2018-01-19 16:15:27 --> Total execution time: 0.0531
INFO - 2018-01-19 16:15:28 --> Config Class Initialized
INFO - 2018-01-19 16:15:28 --> Hooks Class Initialized
DEBUG - 2018-01-19 16:15:28 --> UTF-8 Support Enabled
INFO - 2018-01-19 16:15:28 --> Utf8 Class Initialized
INFO - 2018-01-19 16:15:28 --> URI Class Initialized
INFO - 2018-01-19 16:15:28 --> Router Class Initialized
INFO - 2018-01-19 16:15:28 --> Output Class Initialized
INFO - 2018-01-19 16:15:28 --> Security Class Initialized
DEBUG - 2018-01-19 16:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 16:15:28 --> Input Class Initialized
INFO - 2018-01-19 16:15:28 --> Language Class Initialized
INFO - 2018-01-19 16:15:28 --> Loader Class Initialized
INFO - 2018-01-19 16:15:28 --> Helper loaded: url_helper
INFO - 2018-01-19 16:15:28 --> Helper loaded: form_helper
INFO - 2018-01-19 16:15:28 --> Database Driver Class Initialized
DEBUG - 2018-01-19 16:15:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 16:15:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 16:15:28 --> Form Validation Class Initialized
INFO - 2018-01-19 16:15:28 --> Model Class Initialized
INFO - 2018-01-19 16:15:28 --> Controller Class Initialized
INFO - 2018-01-19 16:15:28 --> Model Class Initialized
INFO - 2018-01-19 16:15:28 --> Model Class Initialized
INFO - 2018-01-19 16:15:28 --> Model Class Initialized
INFO - 2018-01-19 16:15:28 --> Model Class Initialized
DEBUG - 2018-01-19 16:15:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 16:15:32 --> Config Class Initialized
INFO - 2018-01-19 16:15:32 --> Hooks Class Initialized
DEBUG - 2018-01-19 16:15:32 --> UTF-8 Support Enabled
INFO - 2018-01-19 16:15:32 --> Utf8 Class Initialized
INFO - 2018-01-19 16:15:32 --> URI Class Initialized
INFO - 2018-01-19 16:15:32 --> Router Class Initialized
INFO - 2018-01-19 16:15:32 --> Output Class Initialized
INFO - 2018-01-19 16:15:32 --> Security Class Initialized
DEBUG - 2018-01-19 16:15:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 16:15:32 --> Input Class Initialized
INFO - 2018-01-19 16:15:32 --> Language Class Initialized
INFO - 2018-01-19 16:15:32 --> Loader Class Initialized
INFO - 2018-01-19 16:15:32 --> Helper loaded: url_helper
INFO - 2018-01-19 16:15:32 --> Helper loaded: form_helper
INFO - 2018-01-19 16:15:32 --> Database Driver Class Initialized
DEBUG - 2018-01-19 16:15:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 16:15:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 16:15:32 --> Form Validation Class Initialized
INFO - 2018-01-19 16:15:32 --> Model Class Initialized
INFO - 2018-01-19 16:15:32 --> Controller Class Initialized
INFO - 2018-01-19 16:15:32 --> Model Class Initialized
INFO - 2018-01-19 16:15:32 --> Model Class Initialized
INFO - 2018-01-19 16:15:32 --> Model Class Initialized
INFO - 2018-01-19 16:15:32 --> Model Class Initialized
DEBUG - 2018-01-19 16:15:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 16:15:32 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 16:15:32 --> Final output sent to browser
DEBUG - 2018-01-19 16:15:32 --> Total execution time: 0.0542
INFO - 2018-01-19 16:16:25 --> Config Class Initialized
INFO - 2018-01-19 16:16:25 --> Hooks Class Initialized
DEBUG - 2018-01-19 16:16:25 --> UTF-8 Support Enabled
INFO - 2018-01-19 16:16:25 --> Utf8 Class Initialized
INFO - 2018-01-19 16:16:25 --> URI Class Initialized
INFO - 2018-01-19 16:16:25 --> Router Class Initialized
INFO - 2018-01-19 16:16:25 --> Output Class Initialized
INFO - 2018-01-19 16:16:25 --> Security Class Initialized
DEBUG - 2018-01-19 16:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 16:16:25 --> Input Class Initialized
INFO - 2018-01-19 16:16:25 --> Language Class Initialized
INFO - 2018-01-19 16:16:25 --> Loader Class Initialized
INFO - 2018-01-19 16:16:25 --> Helper loaded: url_helper
INFO - 2018-01-19 16:16:25 --> Helper loaded: form_helper
INFO - 2018-01-19 16:16:25 --> Database Driver Class Initialized
DEBUG - 2018-01-19 16:16:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 16:16:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 16:16:25 --> Form Validation Class Initialized
INFO - 2018-01-19 16:16:25 --> Model Class Initialized
INFO - 2018-01-19 16:16:25 --> Controller Class Initialized
INFO - 2018-01-19 16:16:25 --> Model Class Initialized
INFO - 2018-01-19 16:16:25 --> Model Class Initialized
INFO - 2018-01-19 16:16:25 --> Model Class Initialized
INFO - 2018-01-19 16:16:25 --> Model Class Initialized
DEBUG - 2018-01-19 16:16:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 16:16:26 --> Config Class Initialized
INFO - 2018-01-19 16:16:26 --> Hooks Class Initialized
DEBUG - 2018-01-19 16:16:26 --> UTF-8 Support Enabled
INFO - 2018-01-19 16:16:26 --> Utf8 Class Initialized
INFO - 2018-01-19 16:16:26 --> URI Class Initialized
INFO - 2018-01-19 16:16:26 --> Router Class Initialized
INFO - 2018-01-19 16:16:26 --> Output Class Initialized
INFO - 2018-01-19 16:16:26 --> Security Class Initialized
DEBUG - 2018-01-19 16:16:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 16:16:26 --> Input Class Initialized
INFO - 2018-01-19 16:16:26 --> Language Class Initialized
INFO - 2018-01-19 16:16:26 --> Loader Class Initialized
INFO - 2018-01-19 16:16:26 --> Helper loaded: url_helper
INFO - 2018-01-19 16:16:26 --> Helper loaded: form_helper
INFO - 2018-01-19 16:16:26 --> Database Driver Class Initialized
DEBUG - 2018-01-19 16:16:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 16:16:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 16:16:26 --> Form Validation Class Initialized
INFO - 2018-01-19 16:16:26 --> Model Class Initialized
INFO - 2018-01-19 16:16:26 --> Controller Class Initialized
INFO - 2018-01-19 16:16:26 --> Model Class Initialized
INFO - 2018-01-19 16:16:26 --> Model Class Initialized
INFO - 2018-01-19 16:16:26 --> Model Class Initialized
INFO - 2018-01-19 16:16:26 --> Model Class Initialized
DEBUG - 2018-01-19 16:16:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 16:16:26 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 16:16:26 --> Final output sent to browser
DEBUG - 2018-01-19 16:16:26 --> Total execution time: 0.0526
INFO - 2018-01-19 16:16:27 --> Config Class Initialized
INFO - 2018-01-19 16:16:27 --> Hooks Class Initialized
DEBUG - 2018-01-19 16:16:27 --> UTF-8 Support Enabled
INFO - 2018-01-19 16:16:27 --> Utf8 Class Initialized
INFO - 2018-01-19 16:16:27 --> URI Class Initialized
INFO - 2018-01-19 16:16:27 --> Router Class Initialized
INFO - 2018-01-19 16:16:27 --> Output Class Initialized
INFO - 2018-01-19 16:16:27 --> Security Class Initialized
DEBUG - 2018-01-19 16:16:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 16:16:27 --> Input Class Initialized
INFO - 2018-01-19 16:16:27 --> Language Class Initialized
INFO - 2018-01-19 16:16:27 --> Loader Class Initialized
INFO - 2018-01-19 16:16:27 --> Helper loaded: url_helper
INFO - 2018-01-19 16:16:27 --> Helper loaded: form_helper
INFO - 2018-01-19 16:16:27 --> Database Driver Class Initialized
DEBUG - 2018-01-19 16:16:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 16:16:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 16:16:27 --> Form Validation Class Initialized
INFO - 2018-01-19 16:16:27 --> Model Class Initialized
INFO - 2018-01-19 16:16:27 --> Controller Class Initialized
INFO - 2018-01-19 16:16:27 --> Model Class Initialized
INFO - 2018-01-19 16:16:27 --> Model Class Initialized
INFO - 2018-01-19 16:16:27 --> Model Class Initialized
INFO - 2018-01-19 16:16:27 --> Model Class Initialized
DEBUG - 2018-01-19 16:16:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 16:16:36 --> Config Class Initialized
INFO - 2018-01-19 16:16:36 --> Hooks Class Initialized
DEBUG - 2018-01-19 16:16:36 --> UTF-8 Support Enabled
INFO - 2018-01-19 16:16:36 --> Utf8 Class Initialized
INFO - 2018-01-19 16:16:36 --> URI Class Initialized
INFO - 2018-01-19 16:16:36 --> Router Class Initialized
INFO - 2018-01-19 16:16:36 --> Output Class Initialized
INFO - 2018-01-19 16:16:36 --> Security Class Initialized
DEBUG - 2018-01-19 16:16:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 16:16:36 --> Input Class Initialized
INFO - 2018-01-19 16:16:36 --> Language Class Initialized
INFO - 2018-01-19 16:16:36 --> Loader Class Initialized
INFO - 2018-01-19 16:16:36 --> Helper loaded: url_helper
INFO - 2018-01-19 16:16:36 --> Helper loaded: form_helper
INFO - 2018-01-19 16:16:36 --> Database Driver Class Initialized
DEBUG - 2018-01-19 16:16:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 16:16:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 16:16:36 --> Form Validation Class Initialized
INFO - 2018-01-19 16:16:36 --> Model Class Initialized
INFO - 2018-01-19 16:16:36 --> Controller Class Initialized
INFO - 2018-01-19 16:16:36 --> Model Class Initialized
INFO - 2018-01-19 16:16:36 --> Model Class Initialized
INFO - 2018-01-19 16:16:36 --> Model Class Initialized
INFO - 2018-01-19 16:16:36 --> Model Class Initialized
DEBUG - 2018-01-19 16:16:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 16:16:36 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 16:16:36 --> Final output sent to browser
DEBUG - 2018-01-19 16:16:36 --> Total execution time: 0.0583
INFO - 2018-01-19 16:16:49 --> Config Class Initialized
INFO - 2018-01-19 16:16:49 --> Hooks Class Initialized
DEBUG - 2018-01-19 16:16:49 --> UTF-8 Support Enabled
INFO - 2018-01-19 16:16:49 --> Utf8 Class Initialized
INFO - 2018-01-19 16:16:49 --> URI Class Initialized
INFO - 2018-01-19 16:16:49 --> Router Class Initialized
INFO - 2018-01-19 16:16:49 --> Output Class Initialized
INFO - 2018-01-19 16:16:49 --> Security Class Initialized
DEBUG - 2018-01-19 16:16:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 16:16:49 --> Input Class Initialized
INFO - 2018-01-19 16:16:49 --> Language Class Initialized
INFO - 2018-01-19 16:16:49 --> Loader Class Initialized
INFO - 2018-01-19 16:16:49 --> Helper loaded: url_helper
INFO - 2018-01-19 16:16:49 --> Helper loaded: form_helper
INFO - 2018-01-19 16:16:49 --> Database Driver Class Initialized
DEBUG - 2018-01-19 16:16:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 16:16:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 16:16:49 --> Form Validation Class Initialized
INFO - 2018-01-19 16:16:49 --> Model Class Initialized
INFO - 2018-01-19 16:16:49 --> Controller Class Initialized
INFO - 2018-01-19 16:16:49 --> Model Class Initialized
INFO - 2018-01-19 16:16:49 --> Model Class Initialized
INFO - 2018-01-19 16:16:49 --> Model Class Initialized
INFO - 2018-01-19 16:16:49 --> Model Class Initialized
DEBUG - 2018-01-19 16:16:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 16:16:50 --> Config Class Initialized
INFO - 2018-01-19 16:16:50 --> Hooks Class Initialized
DEBUG - 2018-01-19 16:16:50 --> UTF-8 Support Enabled
INFO - 2018-01-19 16:16:50 --> Utf8 Class Initialized
INFO - 2018-01-19 16:16:50 --> URI Class Initialized
INFO - 2018-01-19 16:16:50 --> Router Class Initialized
INFO - 2018-01-19 16:16:50 --> Output Class Initialized
INFO - 2018-01-19 16:16:50 --> Security Class Initialized
DEBUG - 2018-01-19 16:16:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 16:16:50 --> Input Class Initialized
INFO - 2018-01-19 16:16:50 --> Language Class Initialized
INFO - 2018-01-19 16:16:50 --> Loader Class Initialized
INFO - 2018-01-19 16:16:50 --> Helper loaded: url_helper
INFO - 2018-01-19 16:16:50 --> Helper loaded: form_helper
INFO - 2018-01-19 16:16:50 --> Database Driver Class Initialized
DEBUG - 2018-01-19 16:16:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 16:16:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 16:16:50 --> Form Validation Class Initialized
INFO - 2018-01-19 16:16:50 --> Model Class Initialized
INFO - 2018-01-19 16:16:50 --> Controller Class Initialized
INFO - 2018-01-19 16:16:50 --> Model Class Initialized
INFO - 2018-01-19 16:16:50 --> Model Class Initialized
INFO - 2018-01-19 16:16:50 --> Model Class Initialized
INFO - 2018-01-19 16:16:50 --> Model Class Initialized
DEBUG - 2018-01-19 16:16:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 16:16:50 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 16:16:50 --> Final output sent to browser
DEBUG - 2018-01-19 16:16:50 --> Total execution time: 0.0520
INFO - 2018-01-19 16:16:50 --> Config Class Initialized
INFO - 2018-01-19 16:16:50 --> Hooks Class Initialized
DEBUG - 2018-01-19 16:16:50 --> UTF-8 Support Enabled
INFO - 2018-01-19 16:16:50 --> Utf8 Class Initialized
INFO - 2018-01-19 16:16:50 --> URI Class Initialized
INFO - 2018-01-19 16:16:50 --> Router Class Initialized
INFO - 2018-01-19 16:16:50 --> Output Class Initialized
INFO - 2018-01-19 16:16:50 --> Security Class Initialized
DEBUG - 2018-01-19 16:16:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 16:16:50 --> Input Class Initialized
INFO - 2018-01-19 16:16:50 --> Language Class Initialized
INFO - 2018-01-19 16:16:50 --> Loader Class Initialized
INFO - 2018-01-19 16:16:50 --> Helper loaded: url_helper
INFO - 2018-01-19 16:16:50 --> Helper loaded: form_helper
INFO - 2018-01-19 16:16:50 --> Database Driver Class Initialized
DEBUG - 2018-01-19 16:16:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 16:16:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 16:16:50 --> Form Validation Class Initialized
INFO - 2018-01-19 16:16:50 --> Model Class Initialized
INFO - 2018-01-19 16:16:50 --> Controller Class Initialized
INFO - 2018-01-19 16:16:50 --> Model Class Initialized
INFO - 2018-01-19 16:16:50 --> Model Class Initialized
INFO - 2018-01-19 16:16:50 --> Model Class Initialized
INFO - 2018-01-19 16:16:50 --> Model Class Initialized
DEBUG - 2018-01-19 16:16:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 16:16:59 --> Config Class Initialized
INFO - 2018-01-19 16:16:59 --> Hooks Class Initialized
DEBUG - 2018-01-19 16:16:59 --> UTF-8 Support Enabled
INFO - 2018-01-19 16:16:59 --> Utf8 Class Initialized
INFO - 2018-01-19 16:16:59 --> URI Class Initialized
INFO - 2018-01-19 16:16:59 --> Router Class Initialized
INFO - 2018-01-19 16:16:59 --> Output Class Initialized
INFO - 2018-01-19 16:16:59 --> Security Class Initialized
DEBUG - 2018-01-19 16:16:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 16:16:59 --> Input Class Initialized
INFO - 2018-01-19 16:16:59 --> Language Class Initialized
INFO - 2018-01-19 16:16:59 --> Loader Class Initialized
INFO - 2018-01-19 16:16:59 --> Helper loaded: url_helper
INFO - 2018-01-19 16:16:59 --> Helper loaded: form_helper
INFO - 2018-01-19 16:16:59 --> Database Driver Class Initialized
DEBUG - 2018-01-19 16:16:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 16:16:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 16:16:59 --> Form Validation Class Initialized
INFO - 2018-01-19 16:16:59 --> Model Class Initialized
INFO - 2018-01-19 16:16:59 --> Controller Class Initialized
INFO - 2018-01-19 16:16:59 --> Model Class Initialized
INFO - 2018-01-19 16:16:59 --> Model Class Initialized
INFO - 2018-01-19 16:16:59 --> Model Class Initialized
INFO - 2018-01-19 16:16:59 --> Model Class Initialized
DEBUG - 2018-01-19 16:16:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 16:16:59 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 16:16:59 --> Final output sent to browser
DEBUG - 2018-01-19 16:16:59 --> Total execution time: 0.0557
INFO - 2018-01-19 16:17:07 --> Config Class Initialized
INFO - 2018-01-19 16:17:07 --> Hooks Class Initialized
DEBUG - 2018-01-19 16:17:07 --> UTF-8 Support Enabled
INFO - 2018-01-19 16:17:07 --> Utf8 Class Initialized
INFO - 2018-01-19 16:17:07 --> URI Class Initialized
INFO - 2018-01-19 16:17:07 --> Router Class Initialized
INFO - 2018-01-19 16:17:07 --> Output Class Initialized
INFO - 2018-01-19 16:17:07 --> Security Class Initialized
DEBUG - 2018-01-19 16:17:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 16:17:07 --> Input Class Initialized
INFO - 2018-01-19 16:17:07 --> Language Class Initialized
INFO - 2018-01-19 16:17:07 --> Loader Class Initialized
INFO - 2018-01-19 16:17:07 --> Helper loaded: url_helper
INFO - 2018-01-19 16:17:07 --> Helper loaded: form_helper
INFO - 2018-01-19 16:17:07 --> Database Driver Class Initialized
DEBUG - 2018-01-19 16:17:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 16:17:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 16:17:07 --> Form Validation Class Initialized
INFO - 2018-01-19 16:17:07 --> Model Class Initialized
INFO - 2018-01-19 16:17:07 --> Controller Class Initialized
INFO - 2018-01-19 16:17:07 --> Model Class Initialized
INFO - 2018-01-19 16:17:07 --> Model Class Initialized
INFO - 2018-01-19 16:17:07 --> Model Class Initialized
INFO - 2018-01-19 16:17:07 --> Model Class Initialized
DEBUG - 2018-01-19 16:17:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 16:17:07 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 16:17:07 --> Final output sent to browser
DEBUG - 2018-01-19 16:17:07 --> Total execution time: 0.0526
INFO - 2018-01-19 16:17:07 --> Config Class Initialized
INFO - 2018-01-19 16:17:07 --> Hooks Class Initialized
DEBUG - 2018-01-19 16:17:07 --> UTF-8 Support Enabled
INFO - 2018-01-19 16:17:07 --> Utf8 Class Initialized
INFO - 2018-01-19 16:17:07 --> URI Class Initialized
INFO - 2018-01-19 16:17:07 --> Router Class Initialized
INFO - 2018-01-19 16:17:07 --> Output Class Initialized
INFO - 2018-01-19 16:17:07 --> Security Class Initialized
DEBUG - 2018-01-19 16:17:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 16:17:07 --> Input Class Initialized
INFO - 2018-01-19 16:17:07 --> Language Class Initialized
INFO - 2018-01-19 16:17:07 --> Loader Class Initialized
INFO - 2018-01-19 16:17:07 --> Helper loaded: url_helper
INFO - 2018-01-19 16:17:07 --> Helper loaded: form_helper
INFO - 2018-01-19 16:17:07 --> Database Driver Class Initialized
DEBUG - 2018-01-19 16:17:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 16:17:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 16:17:07 --> Form Validation Class Initialized
INFO - 2018-01-19 16:17:07 --> Model Class Initialized
INFO - 2018-01-19 16:17:07 --> Controller Class Initialized
INFO - 2018-01-19 16:17:07 --> Model Class Initialized
INFO - 2018-01-19 16:17:07 --> Model Class Initialized
INFO - 2018-01-19 16:17:07 --> Model Class Initialized
INFO - 2018-01-19 16:17:07 --> Model Class Initialized
DEBUG - 2018-01-19 16:17:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 16:17:15 --> Config Class Initialized
INFO - 2018-01-19 16:17:15 --> Hooks Class Initialized
DEBUG - 2018-01-19 16:17:15 --> UTF-8 Support Enabled
INFO - 2018-01-19 16:17:15 --> Utf8 Class Initialized
INFO - 2018-01-19 16:17:15 --> URI Class Initialized
DEBUG - 2018-01-19 16:17:15 --> No URI present. Default controller set.
INFO - 2018-01-19 16:17:15 --> Router Class Initialized
INFO - 2018-01-19 16:17:15 --> Output Class Initialized
INFO - 2018-01-19 16:17:15 --> Security Class Initialized
DEBUG - 2018-01-19 16:17:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 16:17:15 --> Input Class Initialized
INFO - 2018-01-19 16:17:15 --> Language Class Initialized
INFO - 2018-01-19 16:17:15 --> Loader Class Initialized
INFO - 2018-01-19 16:17:15 --> Helper loaded: url_helper
INFO - 2018-01-19 16:17:15 --> Helper loaded: form_helper
INFO - 2018-01-19 16:17:15 --> Database Driver Class Initialized
DEBUG - 2018-01-19 16:17:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 16:17:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 16:17:15 --> Form Validation Class Initialized
INFO - 2018-01-19 16:17:15 --> Model Class Initialized
INFO - 2018-01-19 16:17:15 --> Controller Class Initialized
INFO - 2018-01-19 16:17:15 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 16:17:15 --> Final output sent to browser
DEBUG - 2018-01-19 16:17:15 --> Total execution time: 0.0350
INFO - 2018-01-19 16:17:20 --> Config Class Initialized
INFO - 2018-01-19 16:17:20 --> Hooks Class Initialized
DEBUG - 2018-01-19 16:17:20 --> UTF-8 Support Enabled
INFO - 2018-01-19 16:17:20 --> Utf8 Class Initialized
INFO - 2018-01-19 16:17:20 --> URI Class Initialized
INFO - 2018-01-19 16:17:20 --> Router Class Initialized
INFO - 2018-01-19 16:17:20 --> Output Class Initialized
INFO - 2018-01-19 16:17:20 --> Security Class Initialized
DEBUG - 2018-01-19 16:17:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 16:17:20 --> Input Class Initialized
INFO - 2018-01-19 16:17:20 --> Language Class Initialized
INFO - 2018-01-19 16:17:20 --> Loader Class Initialized
INFO - 2018-01-19 16:17:20 --> Helper loaded: url_helper
INFO - 2018-01-19 16:17:20 --> Helper loaded: form_helper
INFO - 2018-01-19 16:17:20 --> Database Driver Class Initialized
DEBUG - 2018-01-19 16:17:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 16:17:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 16:17:20 --> Form Validation Class Initialized
INFO - 2018-01-19 16:17:20 --> Model Class Initialized
INFO - 2018-01-19 16:17:20 --> Controller Class Initialized
INFO - 2018-01-19 16:17:20 --> Model Class Initialized
INFO - 2018-01-19 16:17:20 --> Model Class Initialized
INFO - 2018-01-19 16:17:20 --> Model Class Initialized
INFO - 2018-01-19 16:17:20 --> Model Class Initialized
DEBUG - 2018-01-19 16:17:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 16:17:20 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 16:17:20 --> Final output sent to browser
DEBUG - 2018-01-19 16:17:20 --> Total execution time: 0.0458
INFO - 2018-01-19 16:17:21 --> Config Class Initialized
INFO - 2018-01-19 16:17:21 --> Hooks Class Initialized
DEBUG - 2018-01-19 16:17:21 --> UTF-8 Support Enabled
INFO - 2018-01-19 16:17:21 --> Utf8 Class Initialized
INFO - 2018-01-19 16:17:21 --> URI Class Initialized
INFO - 2018-01-19 16:17:21 --> Router Class Initialized
INFO - 2018-01-19 16:17:21 --> Output Class Initialized
INFO - 2018-01-19 16:17:21 --> Security Class Initialized
DEBUG - 2018-01-19 16:17:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 16:17:21 --> Input Class Initialized
INFO - 2018-01-19 16:17:21 --> Language Class Initialized
INFO - 2018-01-19 16:17:21 --> Loader Class Initialized
INFO - 2018-01-19 16:17:21 --> Helper loaded: url_helper
INFO - 2018-01-19 16:17:21 --> Helper loaded: form_helper
INFO - 2018-01-19 16:17:21 --> Database Driver Class Initialized
DEBUG - 2018-01-19 16:17:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 16:17:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 16:17:21 --> Form Validation Class Initialized
INFO - 2018-01-19 16:17:21 --> Model Class Initialized
INFO - 2018-01-19 16:17:21 --> Controller Class Initialized
INFO - 2018-01-19 16:17:21 --> Model Class Initialized
INFO - 2018-01-19 16:17:21 --> Model Class Initialized
INFO - 2018-01-19 16:17:21 --> Model Class Initialized
INFO - 2018-01-19 16:17:21 --> Model Class Initialized
DEBUG - 2018-01-19 16:17:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 16:17:29 --> Config Class Initialized
INFO - 2018-01-19 16:17:29 --> Hooks Class Initialized
DEBUG - 2018-01-19 16:17:29 --> UTF-8 Support Enabled
INFO - 2018-01-19 16:17:29 --> Utf8 Class Initialized
INFO - 2018-01-19 16:17:29 --> URI Class Initialized
INFO - 2018-01-19 16:17:29 --> Router Class Initialized
INFO - 2018-01-19 16:17:29 --> Output Class Initialized
INFO - 2018-01-19 16:17:29 --> Security Class Initialized
DEBUG - 2018-01-19 16:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 16:17:29 --> Input Class Initialized
INFO - 2018-01-19 16:17:29 --> Language Class Initialized
INFO - 2018-01-19 16:17:29 --> Loader Class Initialized
INFO - 2018-01-19 16:17:29 --> Helper loaded: url_helper
INFO - 2018-01-19 16:17:29 --> Helper loaded: form_helper
INFO - 2018-01-19 16:17:29 --> Database Driver Class Initialized
DEBUG - 2018-01-19 16:17:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 16:17:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 16:17:29 --> Form Validation Class Initialized
INFO - 2018-01-19 16:17:29 --> Model Class Initialized
INFO - 2018-01-19 16:17:29 --> Controller Class Initialized
INFO - 2018-01-19 16:17:29 --> Model Class Initialized
INFO - 2018-01-19 16:17:29 --> Model Class Initialized
INFO - 2018-01-19 16:17:29 --> Model Class Initialized
INFO - 2018-01-19 16:17:29 --> Model Class Initialized
DEBUG - 2018-01-19 16:17:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 16:17:29 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 16:17:29 --> Final output sent to browser
DEBUG - 2018-01-19 16:17:29 --> Total execution time: 0.0566
INFO - 2018-01-19 16:17:29 --> Config Class Initialized
INFO - 2018-01-19 16:17:29 --> Hooks Class Initialized
DEBUG - 2018-01-19 16:17:29 --> UTF-8 Support Enabled
INFO - 2018-01-19 16:17:29 --> Utf8 Class Initialized
INFO - 2018-01-19 16:17:29 --> URI Class Initialized
INFO - 2018-01-19 16:17:29 --> Router Class Initialized
INFO - 2018-01-19 16:17:29 --> Output Class Initialized
INFO - 2018-01-19 16:17:29 --> Security Class Initialized
DEBUG - 2018-01-19 16:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 16:17:29 --> Input Class Initialized
INFO - 2018-01-19 16:17:29 --> Language Class Initialized
INFO - 2018-01-19 16:17:29 --> Loader Class Initialized
INFO - 2018-01-19 16:17:29 --> Helper loaded: url_helper
INFO - 2018-01-19 16:17:29 --> Helper loaded: form_helper
INFO - 2018-01-19 16:17:29 --> Database Driver Class Initialized
DEBUG - 2018-01-19 16:17:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 16:17:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 16:17:29 --> Form Validation Class Initialized
INFO - 2018-01-19 16:17:29 --> Model Class Initialized
INFO - 2018-01-19 16:17:29 --> Controller Class Initialized
INFO - 2018-01-19 16:17:29 --> Model Class Initialized
INFO - 2018-01-19 16:17:29 --> Model Class Initialized
INFO - 2018-01-19 16:17:29 --> Model Class Initialized
INFO - 2018-01-19 16:17:29 --> Model Class Initialized
DEBUG - 2018-01-19 16:17:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 16:17:55 --> Config Class Initialized
INFO - 2018-01-19 16:17:55 --> Hooks Class Initialized
DEBUG - 2018-01-19 16:17:55 --> UTF-8 Support Enabled
INFO - 2018-01-19 16:17:55 --> Utf8 Class Initialized
INFO - 2018-01-19 16:17:55 --> URI Class Initialized
INFO - 2018-01-19 16:17:55 --> Router Class Initialized
INFO - 2018-01-19 16:17:55 --> Output Class Initialized
INFO - 2018-01-19 16:17:55 --> Security Class Initialized
DEBUG - 2018-01-19 16:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 16:17:55 --> Input Class Initialized
INFO - 2018-01-19 16:17:55 --> Language Class Initialized
INFO - 2018-01-19 16:17:55 --> Loader Class Initialized
INFO - 2018-01-19 16:17:55 --> Helper loaded: url_helper
INFO - 2018-01-19 16:17:55 --> Helper loaded: form_helper
INFO - 2018-01-19 16:17:55 --> Database Driver Class Initialized
DEBUG - 2018-01-19 16:17:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 16:17:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 16:17:55 --> Form Validation Class Initialized
INFO - 2018-01-19 16:17:55 --> Model Class Initialized
INFO - 2018-01-19 16:17:55 --> Controller Class Initialized
INFO - 2018-01-19 16:17:55 --> Model Class Initialized
INFO - 2018-01-19 16:17:55 --> Model Class Initialized
INFO - 2018-01-19 16:17:55 --> Model Class Initialized
INFO - 2018-01-19 16:17:55 --> Model Class Initialized
DEBUG - 2018-01-19 16:17:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 16:17:55 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 16:17:55 --> Final output sent to browser
DEBUG - 2018-01-19 16:17:55 --> Total execution time: 0.0515
INFO - 2018-01-19 16:17:55 --> Config Class Initialized
INFO - 2018-01-19 16:17:55 --> Hooks Class Initialized
DEBUG - 2018-01-19 16:17:55 --> UTF-8 Support Enabled
INFO - 2018-01-19 16:17:55 --> Utf8 Class Initialized
INFO - 2018-01-19 16:17:55 --> URI Class Initialized
INFO - 2018-01-19 16:17:55 --> Router Class Initialized
INFO - 2018-01-19 16:17:55 --> Output Class Initialized
INFO - 2018-01-19 16:17:55 --> Security Class Initialized
DEBUG - 2018-01-19 16:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 16:17:55 --> Input Class Initialized
INFO - 2018-01-19 16:17:55 --> Language Class Initialized
INFO - 2018-01-19 16:17:55 --> Loader Class Initialized
INFO - 2018-01-19 16:17:55 --> Helper loaded: url_helper
INFO - 2018-01-19 16:17:55 --> Helper loaded: form_helper
INFO - 2018-01-19 16:17:55 --> Database Driver Class Initialized
DEBUG - 2018-01-19 16:17:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 16:17:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 16:17:55 --> Form Validation Class Initialized
INFO - 2018-01-19 16:17:55 --> Model Class Initialized
INFO - 2018-01-19 16:17:55 --> Controller Class Initialized
INFO - 2018-01-19 16:17:55 --> Model Class Initialized
INFO - 2018-01-19 16:17:55 --> Model Class Initialized
INFO - 2018-01-19 16:17:55 --> Model Class Initialized
INFO - 2018-01-19 16:17:55 --> Model Class Initialized
DEBUG - 2018-01-19 16:17:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 16:17:59 --> Config Class Initialized
INFO - 2018-01-19 16:17:59 --> Hooks Class Initialized
DEBUG - 2018-01-19 16:17:59 --> UTF-8 Support Enabled
INFO - 2018-01-19 16:17:59 --> Utf8 Class Initialized
INFO - 2018-01-19 16:17:59 --> URI Class Initialized
INFO - 2018-01-19 16:17:59 --> Router Class Initialized
INFO - 2018-01-19 16:17:59 --> Output Class Initialized
INFO - 2018-01-19 16:17:59 --> Security Class Initialized
DEBUG - 2018-01-19 16:17:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 16:17:59 --> Input Class Initialized
INFO - 2018-01-19 16:17:59 --> Language Class Initialized
INFO - 2018-01-19 16:17:59 --> Loader Class Initialized
INFO - 2018-01-19 16:17:59 --> Helper loaded: url_helper
INFO - 2018-01-19 16:17:59 --> Helper loaded: form_helper
INFO - 2018-01-19 16:17:59 --> Database Driver Class Initialized
DEBUG - 2018-01-19 16:17:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 16:17:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 16:17:59 --> Form Validation Class Initialized
INFO - 2018-01-19 16:17:59 --> Model Class Initialized
INFO - 2018-01-19 16:17:59 --> Controller Class Initialized
INFO - 2018-01-19 16:17:59 --> Model Class Initialized
INFO - 2018-01-19 16:17:59 --> Model Class Initialized
INFO - 2018-01-19 16:17:59 --> Model Class Initialized
INFO - 2018-01-19 16:17:59 --> Model Class Initialized
DEBUG - 2018-01-19 16:17:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 16:18:02 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 16:18:02 --> Final output sent to browser
DEBUG - 2018-01-19 16:18:02 --> Total execution time: 2.7215
INFO - 2018-01-19 16:18:18 --> Config Class Initialized
INFO - 2018-01-19 16:18:18 --> Hooks Class Initialized
DEBUG - 2018-01-19 16:18:18 --> UTF-8 Support Enabled
INFO - 2018-01-19 16:18:18 --> Utf8 Class Initialized
INFO - 2018-01-19 16:18:18 --> URI Class Initialized
INFO - 2018-01-19 16:18:18 --> Router Class Initialized
INFO - 2018-01-19 16:18:18 --> Output Class Initialized
INFO - 2018-01-19 16:18:18 --> Security Class Initialized
DEBUG - 2018-01-19 16:18:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 16:18:18 --> Input Class Initialized
INFO - 2018-01-19 16:18:18 --> Language Class Initialized
INFO - 2018-01-19 16:18:18 --> Loader Class Initialized
INFO - 2018-01-19 16:18:18 --> Helper loaded: url_helper
INFO - 2018-01-19 16:18:18 --> Helper loaded: form_helper
INFO - 2018-01-19 16:18:18 --> Database Driver Class Initialized
DEBUG - 2018-01-19 16:18:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 16:18:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 16:18:18 --> Form Validation Class Initialized
INFO - 2018-01-19 16:18:18 --> Model Class Initialized
INFO - 2018-01-19 16:18:18 --> Controller Class Initialized
INFO - 2018-01-19 16:18:18 --> Model Class Initialized
INFO - 2018-01-19 16:18:18 --> Model Class Initialized
INFO - 2018-01-19 16:18:18 --> Model Class Initialized
INFO - 2018-01-19 16:18:18 --> Model Class Initialized
DEBUG - 2018-01-19 16:18:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 16:18:19 --> Config Class Initialized
INFO - 2018-01-19 16:18:19 --> Hooks Class Initialized
DEBUG - 2018-01-19 16:18:19 --> UTF-8 Support Enabled
INFO - 2018-01-19 16:18:19 --> Utf8 Class Initialized
INFO - 2018-01-19 16:18:19 --> URI Class Initialized
INFO - 2018-01-19 16:18:19 --> Router Class Initialized
INFO - 2018-01-19 16:18:19 --> Output Class Initialized
INFO - 2018-01-19 16:18:19 --> Security Class Initialized
DEBUG - 2018-01-19 16:18:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 16:18:19 --> Input Class Initialized
INFO - 2018-01-19 16:18:19 --> Language Class Initialized
INFO - 2018-01-19 16:18:19 --> Loader Class Initialized
INFO - 2018-01-19 16:18:19 --> Helper loaded: url_helper
INFO - 2018-01-19 16:18:19 --> Helper loaded: form_helper
INFO - 2018-01-19 16:18:19 --> Database Driver Class Initialized
DEBUG - 2018-01-19 16:18:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 16:18:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 16:18:19 --> Form Validation Class Initialized
INFO - 2018-01-19 16:18:19 --> Model Class Initialized
INFO - 2018-01-19 16:18:19 --> Controller Class Initialized
INFO - 2018-01-19 16:18:19 --> Model Class Initialized
INFO - 2018-01-19 16:18:19 --> Model Class Initialized
INFO - 2018-01-19 16:18:19 --> Model Class Initialized
INFO - 2018-01-19 16:18:19 --> Model Class Initialized
DEBUG - 2018-01-19 16:18:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 16:18:19 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 16:18:19 --> Final output sent to browser
DEBUG - 2018-01-19 16:18:19 --> Total execution time: 0.0617
INFO - 2018-01-19 16:18:19 --> Config Class Initialized
INFO - 2018-01-19 16:18:19 --> Hooks Class Initialized
DEBUG - 2018-01-19 16:18:19 --> UTF-8 Support Enabled
INFO - 2018-01-19 16:18:19 --> Utf8 Class Initialized
INFO - 2018-01-19 16:18:19 --> URI Class Initialized
INFO - 2018-01-19 16:18:19 --> Router Class Initialized
INFO - 2018-01-19 16:18:19 --> Output Class Initialized
INFO - 2018-01-19 16:18:19 --> Security Class Initialized
DEBUG - 2018-01-19 16:18:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 16:18:19 --> Input Class Initialized
INFO - 2018-01-19 16:18:19 --> Language Class Initialized
INFO - 2018-01-19 16:18:19 --> Loader Class Initialized
INFO - 2018-01-19 16:18:19 --> Helper loaded: url_helper
INFO - 2018-01-19 16:18:19 --> Helper loaded: form_helper
INFO - 2018-01-19 16:18:19 --> Database Driver Class Initialized
DEBUG - 2018-01-19 16:18:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 16:18:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 16:18:19 --> Form Validation Class Initialized
INFO - 2018-01-19 16:18:19 --> Model Class Initialized
INFO - 2018-01-19 16:18:19 --> Controller Class Initialized
INFO - 2018-01-19 16:18:19 --> Model Class Initialized
INFO - 2018-01-19 16:18:19 --> Model Class Initialized
INFO - 2018-01-19 16:18:19 --> Model Class Initialized
INFO - 2018-01-19 16:18:19 --> Model Class Initialized
DEBUG - 2018-01-19 16:18:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 16:18:22 --> Config Class Initialized
INFO - 2018-01-19 16:18:22 --> Hooks Class Initialized
DEBUG - 2018-01-19 16:18:22 --> UTF-8 Support Enabled
INFO - 2018-01-19 16:18:22 --> Utf8 Class Initialized
INFO - 2018-01-19 16:18:22 --> URI Class Initialized
INFO - 2018-01-19 16:18:22 --> Router Class Initialized
INFO - 2018-01-19 16:18:22 --> Output Class Initialized
INFO - 2018-01-19 16:18:22 --> Security Class Initialized
DEBUG - 2018-01-19 16:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 16:18:22 --> Input Class Initialized
INFO - 2018-01-19 16:18:22 --> Language Class Initialized
INFO - 2018-01-19 16:18:22 --> Loader Class Initialized
INFO - 2018-01-19 16:18:22 --> Helper loaded: url_helper
INFO - 2018-01-19 16:18:22 --> Helper loaded: form_helper
INFO - 2018-01-19 16:18:22 --> Database Driver Class Initialized
DEBUG - 2018-01-19 16:18:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 16:18:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 16:18:22 --> Form Validation Class Initialized
INFO - 2018-01-19 16:18:22 --> Model Class Initialized
INFO - 2018-01-19 16:18:22 --> Controller Class Initialized
INFO - 2018-01-19 16:18:22 --> Model Class Initialized
INFO - 2018-01-19 16:18:22 --> Model Class Initialized
INFO - 2018-01-19 16:18:22 --> Model Class Initialized
INFO - 2018-01-19 16:18:22 --> Model Class Initialized
DEBUG - 2018-01-19 16:18:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 16:18:22 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 16:18:22 --> Final output sent to browser
DEBUG - 2018-01-19 16:18:22 --> Total execution time: 0.0507
INFO - 2018-01-19 16:18:23 --> Config Class Initialized
INFO - 2018-01-19 16:18:23 --> Hooks Class Initialized
DEBUG - 2018-01-19 16:18:23 --> UTF-8 Support Enabled
INFO - 2018-01-19 16:18:23 --> Utf8 Class Initialized
INFO - 2018-01-19 16:18:23 --> URI Class Initialized
INFO - 2018-01-19 16:18:23 --> Router Class Initialized
INFO - 2018-01-19 16:18:23 --> Output Class Initialized
INFO - 2018-01-19 16:18:23 --> Security Class Initialized
DEBUG - 2018-01-19 16:18:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 16:18:23 --> Input Class Initialized
INFO - 2018-01-19 16:18:23 --> Language Class Initialized
INFO - 2018-01-19 16:18:23 --> Loader Class Initialized
INFO - 2018-01-19 16:18:23 --> Helper loaded: url_helper
INFO - 2018-01-19 16:18:23 --> Helper loaded: form_helper
INFO - 2018-01-19 16:18:23 --> Database Driver Class Initialized
DEBUG - 2018-01-19 16:18:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 16:18:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 16:18:23 --> Form Validation Class Initialized
INFO - 2018-01-19 16:18:23 --> Model Class Initialized
INFO - 2018-01-19 16:18:23 --> Controller Class Initialized
INFO - 2018-01-19 16:18:23 --> Model Class Initialized
INFO - 2018-01-19 16:18:23 --> Model Class Initialized
INFO - 2018-01-19 16:18:23 --> Model Class Initialized
INFO - 2018-01-19 16:18:23 --> Model Class Initialized
DEBUG - 2018-01-19 16:18:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 16:18:37 --> Config Class Initialized
INFO - 2018-01-19 16:18:37 --> Hooks Class Initialized
DEBUG - 2018-01-19 16:18:37 --> UTF-8 Support Enabled
INFO - 2018-01-19 16:18:37 --> Utf8 Class Initialized
INFO - 2018-01-19 16:18:37 --> URI Class Initialized
INFO - 2018-01-19 16:18:37 --> Router Class Initialized
INFO - 2018-01-19 16:18:37 --> Output Class Initialized
INFO - 2018-01-19 16:18:37 --> Security Class Initialized
DEBUG - 2018-01-19 16:18:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 16:18:37 --> Input Class Initialized
INFO - 2018-01-19 16:18:37 --> Language Class Initialized
INFO - 2018-01-19 16:18:37 --> Loader Class Initialized
INFO - 2018-01-19 16:18:37 --> Helper loaded: url_helper
INFO - 2018-01-19 16:18:37 --> Helper loaded: form_helper
INFO - 2018-01-19 16:18:37 --> Database Driver Class Initialized
DEBUG - 2018-01-19 16:18:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 16:18:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 16:18:37 --> Form Validation Class Initialized
INFO - 2018-01-19 16:18:37 --> Model Class Initialized
INFO - 2018-01-19 16:18:37 --> Controller Class Initialized
INFO - 2018-01-19 16:18:37 --> Model Class Initialized
INFO - 2018-01-19 16:18:37 --> Model Class Initialized
INFO - 2018-01-19 16:18:37 --> Model Class Initialized
INFO - 2018-01-19 16:18:37 --> Model Class Initialized
DEBUG - 2018-01-19 16:18:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 16:18:37 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 16:18:37 --> Final output sent to browser
DEBUG - 2018-01-19 16:18:37 --> Total execution time: 0.0638
INFO - 2018-01-19 16:18:37 --> Config Class Initialized
INFO - 2018-01-19 16:18:37 --> Hooks Class Initialized
DEBUG - 2018-01-19 16:18:37 --> UTF-8 Support Enabled
INFO - 2018-01-19 16:18:37 --> Utf8 Class Initialized
INFO - 2018-01-19 16:18:37 --> URI Class Initialized
INFO - 2018-01-19 16:18:37 --> Router Class Initialized
INFO - 2018-01-19 16:18:37 --> Output Class Initialized
INFO - 2018-01-19 16:18:37 --> Security Class Initialized
DEBUG - 2018-01-19 16:18:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 16:18:37 --> Input Class Initialized
INFO - 2018-01-19 16:18:37 --> Language Class Initialized
INFO - 2018-01-19 16:18:37 --> Loader Class Initialized
INFO - 2018-01-19 16:18:37 --> Helper loaded: url_helper
INFO - 2018-01-19 16:18:37 --> Helper loaded: form_helper
INFO - 2018-01-19 16:18:37 --> Database Driver Class Initialized
DEBUG - 2018-01-19 16:18:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 16:18:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 16:18:37 --> Form Validation Class Initialized
INFO - 2018-01-19 16:18:37 --> Model Class Initialized
INFO - 2018-01-19 16:18:37 --> Controller Class Initialized
INFO - 2018-01-19 16:18:37 --> Model Class Initialized
INFO - 2018-01-19 16:18:37 --> Model Class Initialized
INFO - 2018-01-19 16:18:37 --> Model Class Initialized
INFO - 2018-01-19 16:18:37 --> Model Class Initialized
DEBUG - 2018-01-19 16:18:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 16:18:41 --> Config Class Initialized
INFO - 2018-01-19 16:18:41 --> Hooks Class Initialized
DEBUG - 2018-01-19 16:18:41 --> UTF-8 Support Enabled
INFO - 2018-01-19 16:18:41 --> Utf8 Class Initialized
INFO - 2018-01-19 16:18:41 --> URI Class Initialized
INFO - 2018-01-19 16:18:41 --> Router Class Initialized
INFO - 2018-01-19 16:18:41 --> Output Class Initialized
INFO - 2018-01-19 16:18:41 --> Security Class Initialized
DEBUG - 2018-01-19 16:18:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 16:18:41 --> Input Class Initialized
INFO - 2018-01-19 16:18:41 --> Language Class Initialized
INFO - 2018-01-19 16:18:41 --> Loader Class Initialized
INFO - 2018-01-19 16:18:41 --> Helper loaded: url_helper
INFO - 2018-01-19 16:18:41 --> Helper loaded: form_helper
INFO - 2018-01-19 16:18:41 --> Database Driver Class Initialized
DEBUG - 2018-01-19 16:18:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 16:18:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 16:18:41 --> Form Validation Class Initialized
INFO - 2018-01-19 16:18:41 --> Model Class Initialized
INFO - 2018-01-19 16:18:41 --> Controller Class Initialized
INFO - 2018-01-19 16:18:41 --> Model Class Initialized
INFO - 2018-01-19 16:18:41 --> Model Class Initialized
INFO - 2018-01-19 16:18:41 --> Model Class Initialized
INFO - 2018-01-19 16:18:41 --> Model Class Initialized
DEBUG - 2018-01-19 16:18:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 16:18:41 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 16:18:41 --> Final output sent to browser
DEBUG - 2018-01-19 16:18:41 --> Total execution time: 0.0556
INFO - 2018-01-19 16:18:54 --> Config Class Initialized
INFO - 2018-01-19 16:18:54 --> Hooks Class Initialized
DEBUG - 2018-01-19 16:18:54 --> UTF-8 Support Enabled
INFO - 2018-01-19 16:18:54 --> Utf8 Class Initialized
INFO - 2018-01-19 16:18:54 --> URI Class Initialized
INFO - 2018-01-19 16:18:54 --> Router Class Initialized
INFO - 2018-01-19 16:18:54 --> Output Class Initialized
INFO - 2018-01-19 16:18:54 --> Security Class Initialized
DEBUG - 2018-01-19 16:18:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 16:18:54 --> Input Class Initialized
INFO - 2018-01-19 16:18:54 --> Language Class Initialized
INFO - 2018-01-19 16:18:54 --> Loader Class Initialized
INFO - 2018-01-19 16:18:54 --> Helper loaded: url_helper
INFO - 2018-01-19 16:18:54 --> Helper loaded: form_helper
INFO - 2018-01-19 16:18:54 --> Database Driver Class Initialized
DEBUG - 2018-01-19 16:18:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 16:18:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 16:18:54 --> Form Validation Class Initialized
INFO - 2018-01-19 16:18:54 --> Model Class Initialized
INFO - 2018-01-19 16:18:54 --> Controller Class Initialized
INFO - 2018-01-19 16:18:54 --> Model Class Initialized
INFO - 2018-01-19 16:18:54 --> Model Class Initialized
INFO - 2018-01-19 16:18:54 --> Model Class Initialized
INFO - 2018-01-19 16:18:54 --> Model Class Initialized
DEBUG - 2018-01-19 16:18:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 16:18:56 --> Config Class Initialized
INFO - 2018-01-19 16:18:56 --> Hooks Class Initialized
DEBUG - 2018-01-19 16:18:56 --> UTF-8 Support Enabled
INFO - 2018-01-19 16:18:56 --> Utf8 Class Initialized
INFO - 2018-01-19 16:18:56 --> URI Class Initialized
INFO - 2018-01-19 16:18:56 --> Router Class Initialized
INFO - 2018-01-19 16:18:56 --> Output Class Initialized
INFO - 2018-01-19 16:18:56 --> Security Class Initialized
DEBUG - 2018-01-19 16:18:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 16:18:56 --> Input Class Initialized
INFO - 2018-01-19 16:18:56 --> Language Class Initialized
INFO - 2018-01-19 16:18:56 --> Loader Class Initialized
INFO - 2018-01-19 16:18:56 --> Helper loaded: url_helper
INFO - 2018-01-19 16:18:56 --> Helper loaded: form_helper
INFO - 2018-01-19 16:18:56 --> Database Driver Class Initialized
DEBUG - 2018-01-19 16:18:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 16:18:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 16:18:56 --> Form Validation Class Initialized
INFO - 2018-01-19 16:18:56 --> Model Class Initialized
INFO - 2018-01-19 16:18:56 --> Controller Class Initialized
INFO - 2018-01-19 16:18:56 --> Model Class Initialized
INFO - 2018-01-19 16:18:56 --> Model Class Initialized
INFO - 2018-01-19 16:18:56 --> Model Class Initialized
INFO - 2018-01-19 16:18:56 --> Model Class Initialized
DEBUG - 2018-01-19 16:18:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 16:18:56 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 16:18:56 --> Final output sent to browser
DEBUG - 2018-01-19 16:18:56 --> Total execution time: 0.0497
INFO - 2018-01-19 16:18:56 --> Config Class Initialized
INFO - 2018-01-19 16:18:56 --> Hooks Class Initialized
DEBUG - 2018-01-19 16:18:56 --> UTF-8 Support Enabled
INFO - 2018-01-19 16:18:56 --> Utf8 Class Initialized
INFO - 2018-01-19 16:18:56 --> URI Class Initialized
INFO - 2018-01-19 16:18:56 --> Router Class Initialized
INFO - 2018-01-19 16:18:56 --> Output Class Initialized
INFO - 2018-01-19 16:18:56 --> Security Class Initialized
DEBUG - 2018-01-19 16:18:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 16:18:56 --> Input Class Initialized
INFO - 2018-01-19 16:18:56 --> Language Class Initialized
INFO - 2018-01-19 16:18:56 --> Loader Class Initialized
INFO - 2018-01-19 16:18:56 --> Helper loaded: url_helper
INFO - 2018-01-19 16:18:56 --> Helper loaded: form_helper
INFO - 2018-01-19 16:18:56 --> Database Driver Class Initialized
DEBUG - 2018-01-19 16:18:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 16:18:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 16:18:56 --> Form Validation Class Initialized
INFO - 2018-01-19 16:18:56 --> Model Class Initialized
INFO - 2018-01-19 16:18:56 --> Controller Class Initialized
INFO - 2018-01-19 16:18:56 --> Model Class Initialized
INFO - 2018-01-19 16:18:56 --> Model Class Initialized
INFO - 2018-01-19 16:18:56 --> Model Class Initialized
INFO - 2018-01-19 16:18:56 --> Model Class Initialized
DEBUG - 2018-01-19 16:18:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 16:19:08 --> Config Class Initialized
INFO - 2018-01-19 16:19:08 --> Hooks Class Initialized
DEBUG - 2018-01-19 16:19:08 --> UTF-8 Support Enabled
INFO - 2018-01-19 16:19:08 --> Utf8 Class Initialized
INFO - 2018-01-19 16:19:08 --> URI Class Initialized
INFO - 2018-01-19 16:19:08 --> Router Class Initialized
INFO - 2018-01-19 16:19:08 --> Output Class Initialized
INFO - 2018-01-19 16:19:08 --> Security Class Initialized
DEBUG - 2018-01-19 16:19:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 16:19:08 --> Input Class Initialized
INFO - 2018-01-19 16:19:08 --> Language Class Initialized
INFO - 2018-01-19 16:19:08 --> Loader Class Initialized
INFO - 2018-01-19 16:19:08 --> Helper loaded: url_helper
INFO - 2018-01-19 16:19:08 --> Helper loaded: form_helper
INFO - 2018-01-19 16:19:08 --> Database Driver Class Initialized
DEBUG - 2018-01-19 16:19:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 16:19:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 16:19:08 --> Form Validation Class Initialized
INFO - 2018-01-19 16:19:08 --> Model Class Initialized
INFO - 2018-01-19 16:19:08 --> Controller Class Initialized
INFO - 2018-01-19 16:19:08 --> Model Class Initialized
INFO - 2018-01-19 16:19:08 --> Model Class Initialized
INFO - 2018-01-19 16:19:08 --> Model Class Initialized
INFO - 2018-01-19 16:19:08 --> Model Class Initialized
DEBUG - 2018-01-19 16:19:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 16:19:08 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 16:19:08 --> Final output sent to browser
DEBUG - 2018-01-19 16:19:08 --> Total execution time: 0.0501
INFO - 2018-01-19 16:19:08 --> Config Class Initialized
INFO - 2018-01-19 16:19:08 --> Hooks Class Initialized
DEBUG - 2018-01-19 16:19:08 --> UTF-8 Support Enabled
INFO - 2018-01-19 16:19:08 --> Utf8 Class Initialized
INFO - 2018-01-19 16:19:08 --> URI Class Initialized
INFO - 2018-01-19 16:19:08 --> Router Class Initialized
INFO - 2018-01-19 16:19:08 --> Output Class Initialized
INFO - 2018-01-19 16:19:08 --> Security Class Initialized
DEBUG - 2018-01-19 16:19:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 16:19:08 --> Input Class Initialized
INFO - 2018-01-19 16:19:08 --> Language Class Initialized
INFO - 2018-01-19 16:19:08 --> Loader Class Initialized
INFO - 2018-01-19 16:19:08 --> Helper loaded: url_helper
INFO - 2018-01-19 16:19:08 --> Helper loaded: form_helper
INFO - 2018-01-19 16:19:08 --> Database Driver Class Initialized
DEBUG - 2018-01-19 16:19:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 16:19:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 16:19:08 --> Form Validation Class Initialized
INFO - 2018-01-19 16:19:08 --> Model Class Initialized
INFO - 2018-01-19 16:19:08 --> Controller Class Initialized
INFO - 2018-01-19 16:19:08 --> Model Class Initialized
INFO - 2018-01-19 16:19:08 --> Model Class Initialized
INFO - 2018-01-19 16:19:08 --> Model Class Initialized
INFO - 2018-01-19 16:19:08 --> Model Class Initialized
DEBUG - 2018-01-19 16:19:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 17:30:35 --> Config Class Initialized
INFO - 2018-01-19 17:30:35 --> Hooks Class Initialized
DEBUG - 2018-01-19 17:30:35 --> UTF-8 Support Enabled
INFO - 2018-01-19 17:30:35 --> Utf8 Class Initialized
INFO - 2018-01-19 17:30:35 --> URI Class Initialized
DEBUG - 2018-01-19 17:30:35 --> No URI present. Default controller set.
INFO - 2018-01-19 17:30:35 --> Router Class Initialized
INFO - 2018-01-19 17:30:35 --> Output Class Initialized
INFO - 2018-01-19 17:30:35 --> Security Class Initialized
DEBUG - 2018-01-19 17:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 17:30:35 --> Input Class Initialized
INFO - 2018-01-19 17:30:35 --> Language Class Initialized
INFO - 2018-01-19 17:30:35 --> Loader Class Initialized
INFO - 2018-01-19 17:30:35 --> Helper loaded: url_helper
INFO - 2018-01-19 17:30:35 --> Helper loaded: form_helper
INFO - 2018-01-19 17:30:35 --> Database Driver Class Initialized
DEBUG - 2018-01-19 17:30:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 17:30:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 17:30:35 --> Form Validation Class Initialized
INFO - 2018-01-19 17:30:35 --> Model Class Initialized
INFO - 2018-01-19 17:30:35 --> Controller Class Initialized
INFO - 2018-01-19 17:30:35 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 17:30:35 --> Final output sent to browser
DEBUG - 2018-01-19 17:30:35 --> Total execution time: 0.0349
INFO - 2018-01-19 17:30:39 --> Config Class Initialized
INFO - 2018-01-19 17:30:39 --> Hooks Class Initialized
DEBUG - 2018-01-19 17:30:39 --> UTF-8 Support Enabled
INFO - 2018-01-19 17:30:39 --> Utf8 Class Initialized
INFO - 2018-01-19 17:30:39 --> URI Class Initialized
INFO - 2018-01-19 17:30:39 --> Router Class Initialized
INFO - 2018-01-19 17:30:39 --> Output Class Initialized
INFO - 2018-01-19 17:30:39 --> Security Class Initialized
DEBUG - 2018-01-19 17:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 17:30:39 --> Input Class Initialized
INFO - 2018-01-19 17:30:39 --> Language Class Initialized
INFO - 2018-01-19 17:30:39 --> Loader Class Initialized
INFO - 2018-01-19 17:30:39 --> Helper loaded: url_helper
INFO - 2018-01-19 17:30:39 --> Helper loaded: form_helper
INFO - 2018-01-19 17:30:39 --> Database Driver Class Initialized
DEBUG - 2018-01-19 17:30:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 17:30:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 17:30:39 --> Form Validation Class Initialized
INFO - 2018-01-19 17:30:39 --> Model Class Initialized
INFO - 2018-01-19 17:30:39 --> Controller Class Initialized
INFO - 2018-01-19 17:30:39 --> Model Class Initialized
INFO - 2018-01-19 17:30:39 --> Model Class Initialized
INFO - 2018-01-19 17:30:39 --> Model Class Initialized
INFO - 2018-01-19 17:30:39 --> Model Class Initialized
DEBUG - 2018-01-19 17:30:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 17:30:39 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 17:30:39 --> Final output sent to browser
DEBUG - 2018-01-19 17:30:39 --> Total execution time: 0.0998
INFO - 2018-01-19 17:30:40 --> Config Class Initialized
INFO - 2018-01-19 17:30:40 --> Hooks Class Initialized
DEBUG - 2018-01-19 17:30:40 --> UTF-8 Support Enabled
INFO - 2018-01-19 17:30:40 --> Utf8 Class Initialized
INFO - 2018-01-19 17:30:40 --> URI Class Initialized
INFO - 2018-01-19 17:30:40 --> Router Class Initialized
INFO - 2018-01-19 17:30:40 --> Output Class Initialized
INFO - 2018-01-19 17:30:40 --> Security Class Initialized
DEBUG - 2018-01-19 17:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 17:30:40 --> Input Class Initialized
INFO - 2018-01-19 17:30:40 --> Language Class Initialized
INFO - 2018-01-19 17:30:40 --> Loader Class Initialized
INFO - 2018-01-19 17:30:40 --> Helper loaded: url_helper
INFO - 2018-01-19 17:30:40 --> Helper loaded: form_helper
INFO - 2018-01-19 17:30:40 --> Database Driver Class Initialized
DEBUG - 2018-01-19 17:30:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 17:30:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 17:30:40 --> Form Validation Class Initialized
INFO - 2018-01-19 17:30:40 --> Model Class Initialized
INFO - 2018-01-19 17:30:40 --> Controller Class Initialized
INFO - 2018-01-19 17:30:40 --> Model Class Initialized
INFO - 2018-01-19 17:30:40 --> Model Class Initialized
INFO - 2018-01-19 17:30:40 --> Model Class Initialized
INFO - 2018-01-19 17:30:40 --> Model Class Initialized
DEBUG - 2018-01-19 17:30:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 17:30:48 --> Config Class Initialized
INFO - 2018-01-19 17:30:48 --> Hooks Class Initialized
DEBUG - 2018-01-19 17:30:48 --> UTF-8 Support Enabled
INFO - 2018-01-19 17:30:48 --> Utf8 Class Initialized
INFO - 2018-01-19 17:30:48 --> URI Class Initialized
INFO - 2018-01-19 17:30:48 --> Router Class Initialized
INFO - 2018-01-19 17:30:48 --> Output Class Initialized
INFO - 2018-01-19 17:30:48 --> Security Class Initialized
DEBUG - 2018-01-19 17:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 17:30:48 --> Input Class Initialized
INFO - 2018-01-19 17:30:48 --> Language Class Initialized
INFO - 2018-01-19 17:30:48 --> Loader Class Initialized
INFO - 2018-01-19 17:30:48 --> Helper loaded: url_helper
INFO - 2018-01-19 17:30:48 --> Helper loaded: form_helper
INFO - 2018-01-19 17:30:48 --> Database Driver Class Initialized
DEBUG - 2018-01-19 17:30:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 17:30:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 17:30:48 --> Form Validation Class Initialized
INFO - 2018-01-19 17:30:48 --> Model Class Initialized
INFO - 2018-01-19 17:30:48 --> Controller Class Initialized
INFO - 2018-01-19 17:30:48 --> Model Class Initialized
INFO - 2018-01-19 17:30:48 --> Model Class Initialized
INFO - 2018-01-19 17:30:48 --> Model Class Initialized
INFO - 2018-01-19 17:30:48 --> Model Class Initialized
DEBUG - 2018-01-19 17:30:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 17:30:48 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 17:30:48 --> Final output sent to browser
DEBUG - 2018-01-19 17:30:48 --> Total execution time: 0.0536
INFO - 2018-01-19 17:30:49 --> Config Class Initialized
INFO - 2018-01-19 17:30:49 --> Hooks Class Initialized
DEBUG - 2018-01-19 17:30:49 --> UTF-8 Support Enabled
INFO - 2018-01-19 17:30:49 --> Utf8 Class Initialized
INFO - 2018-01-19 17:30:49 --> URI Class Initialized
INFO - 2018-01-19 17:30:49 --> Router Class Initialized
INFO - 2018-01-19 17:30:49 --> Output Class Initialized
INFO - 2018-01-19 17:30:49 --> Security Class Initialized
DEBUG - 2018-01-19 17:30:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 17:30:49 --> Input Class Initialized
INFO - 2018-01-19 17:30:49 --> Language Class Initialized
INFO - 2018-01-19 17:30:49 --> Loader Class Initialized
INFO - 2018-01-19 17:30:49 --> Helper loaded: url_helper
INFO - 2018-01-19 17:30:49 --> Helper loaded: form_helper
INFO - 2018-01-19 17:30:49 --> Database Driver Class Initialized
DEBUG - 2018-01-19 17:30:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 17:30:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 17:30:49 --> Form Validation Class Initialized
INFO - 2018-01-19 17:30:49 --> Model Class Initialized
INFO - 2018-01-19 17:30:49 --> Controller Class Initialized
INFO - 2018-01-19 17:30:49 --> Model Class Initialized
INFO - 2018-01-19 17:30:49 --> Model Class Initialized
INFO - 2018-01-19 17:30:49 --> Model Class Initialized
INFO - 2018-01-19 17:30:49 --> Model Class Initialized
DEBUG - 2018-01-19 17:30:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 17:31:14 --> Config Class Initialized
INFO - 2018-01-19 17:31:14 --> Hooks Class Initialized
DEBUG - 2018-01-19 17:31:14 --> UTF-8 Support Enabled
INFO - 2018-01-19 17:31:14 --> Utf8 Class Initialized
INFO - 2018-01-19 17:31:14 --> URI Class Initialized
INFO - 2018-01-19 17:31:14 --> Router Class Initialized
INFO - 2018-01-19 17:31:14 --> Output Class Initialized
INFO - 2018-01-19 17:31:14 --> Security Class Initialized
DEBUG - 2018-01-19 17:31:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 17:31:14 --> Input Class Initialized
INFO - 2018-01-19 17:31:14 --> Language Class Initialized
INFO - 2018-01-19 17:31:14 --> Loader Class Initialized
INFO - 2018-01-19 17:31:14 --> Helper loaded: url_helper
INFO - 2018-01-19 17:31:14 --> Helper loaded: form_helper
INFO - 2018-01-19 17:31:14 --> Database Driver Class Initialized
DEBUG - 2018-01-19 17:31:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 17:31:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 17:31:14 --> Form Validation Class Initialized
INFO - 2018-01-19 17:31:14 --> Model Class Initialized
INFO - 2018-01-19 17:31:14 --> Controller Class Initialized
INFO - 2018-01-19 17:31:14 --> Model Class Initialized
INFO - 2018-01-19 17:31:14 --> Model Class Initialized
INFO - 2018-01-19 17:31:14 --> Model Class Initialized
INFO - 2018-01-19 17:31:14 --> Model Class Initialized
DEBUG - 2018-01-19 17:31:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 17:31:14 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 17:31:14 --> Final output sent to browser
DEBUG - 2018-01-19 17:31:14 --> Total execution time: 0.0526
INFO - 2018-01-19 17:31:14 --> Config Class Initialized
INFO - 2018-01-19 17:31:14 --> Hooks Class Initialized
DEBUG - 2018-01-19 17:31:14 --> UTF-8 Support Enabled
INFO - 2018-01-19 17:31:14 --> Utf8 Class Initialized
INFO - 2018-01-19 17:31:14 --> URI Class Initialized
INFO - 2018-01-19 17:31:14 --> Router Class Initialized
INFO - 2018-01-19 17:31:14 --> Output Class Initialized
INFO - 2018-01-19 17:31:14 --> Security Class Initialized
DEBUG - 2018-01-19 17:31:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 17:31:14 --> Input Class Initialized
INFO - 2018-01-19 17:31:14 --> Language Class Initialized
INFO - 2018-01-19 17:31:14 --> Loader Class Initialized
INFO - 2018-01-19 17:31:14 --> Helper loaded: url_helper
INFO - 2018-01-19 17:31:14 --> Helper loaded: form_helper
INFO - 2018-01-19 17:31:14 --> Database Driver Class Initialized
DEBUG - 2018-01-19 17:31:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 17:31:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 17:31:14 --> Form Validation Class Initialized
INFO - 2018-01-19 17:31:14 --> Model Class Initialized
INFO - 2018-01-19 17:31:14 --> Controller Class Initialized
INFO - 2018-01-19 17:31:14 --> Model Class Initialized
INFO - 2018-01-19 17:31:14 --> Model Class Initialized
INFO - 2018-01-19 17:31:14 --> Model Class Initialized
INFO - 2018-01-19 17:31:14 --> Model Class Initialized
DEBUG - 2018-01-19 17:31:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 17:31:18 --> Config Class Initialized
INFO - 2018-01-19 17:31:18 --> Hooks Class Initialized
DEBUG - 2018-01-19 17:31:18 --> UTF-8 Support Enabled
INFO - 2018-01-19 17:31:18 --> Utf8 Class Initialized
INFO - 2018-01-19 17:31:18 --> URI Class Initialized
INFO - 2018-01-19 17:31:18 --> Router Class Initialized
INFO - 2018-01-19 17:31:18 --> Output Class Initialized
INFO - 2018-01-19 17:31:18 --> Security Class Initialized
DEBUG - 2018-01-19 17:31:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 17:31:18 --> Input Class Initialized
INFO - 2018-01-19 17:31:18 --> Language Class Initialized
INFO - 2018-01-19 17:31:18 --> Loader Class Initialized
INFO - 2018-01-19 17:31:18 --> Helper loaded: url_helper
INFO - 2018-01-19 17:31:18 --> Helper loaded: form_helper
INFO - 2018-01-19 17:31:18 --> Database Driver Class Initialized
DEBUG - 2018-01-19 17:31:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 17:31:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 17:31:18 --> Form Validation Class Initialized
INFO - 2018-01-19 17:31:18 --> Model Class Initialized
INFO - 2018-01-19 17:31:18 --> Controller Class Initialized
INFO - 2018-01-19 17:31:18 --> Model Class Initialized
INFO - 2018-01-19 17:31:18 --> Model Class Initialized
INFO - 2018-01-19 17:31:18 --> Model Class Initialized
INFO - 2018-01-19 17:31:18 --> Model Class Initialized
DEBUG - 2018-01-19 17:31:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 17:31:18 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 17:31:18 --> Final output sent to browser
DEBUG - 2018-01-19 17:31:18 --> Total execution time: 0.0558
INFO - 2018-01-19 17:31:52 --> Config Class Initialized
INFO - 2018-01-19 17:31:52 --> Hooks Class Initialized
DEBUG - 2018-01-19 17:31:52 --> UTF-8 Support Enabled
INFO - 2018-01-19 17:31:52 --> Utf8 Class Initialized
INFO - 2018-01-19 17:31:52 --> URI Class Initialized
INFO - 2018-01-19 17:31:52 --> Router Class Initialized
INFO - 2018-01-19 17:31:52 --> Output Class Initialized
INFO - 2018-01-19 17:31:52 --> Security Class Initialized
DEBUG - 2018-01-19 17:31:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 17:31:52 --> Input Class Initialized
INFO - 2018-01-19 17:31:52 --> Language Class Initialized
INFO - 2018-01-19 17:31:52 --> Loader Class Initialized
INFO - 2018-01-19 17:31:52 --> Helper loaded: url_helper
INFO - 2018-01-19 17:31:52 --> Helper loaded: form_helper
INFO - 2018-01-19 17:31:52 --> Database Driver Class Initialized
DEBUG - 2018-01-19 17:31:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 17:31:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 17:31:52 --> Form Validation Class Initialized
INFO - 2018-01-19 17:31:52 --> Model Class Initialized
INFO - 2018-01-19 17:31:52 --> Controller Class Initialized
INFO - 2018-01-19 17:31:52 --> Model Class Initialized
INFO - 2018-01-19 17:31:52 --> Model Class Initialized
INFO - 2018-01-19 17:31:52 --> Model Class Initialized
INFO - 2018-01-19 17:31:52 --> Model Class Initialized
DEBUG - 2018-01-19 17:31:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 17:31:52 --> Config Class Initialized
INFO - 2018-01-19 17:31:52 --> Hooks Class Initialized
DEBUG - 2018-01-19 17:31:52 --> UTF-8 Support Enabled
INFO - 2018-01-19 17:31:52 --> Utf8 Class Initialized
INFO - 2018-01-19 17:31:52 --> URI Class Initialized
INFO - 2018-01-19 17:31:52 --> Router Class Initialized
INFO - 2018-01-19 17:31:52 --> Output Class Initialized
INFO - 2018-01-19 17:31:52 --> Security Class Initialized
DEBUG - 2018-01-19 17:31:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 17:31:52 --> Input Class Initialized
INFO - 2018-01-19 17:31:52 --> Language Class Initialized
INFO - 2018-01-19 17:31:52 --> Loader Class Initialized
INFO - 2018-01-19 17:31:52 --> Helper loaded: url_helper
INFO - 2018-01-19 17:31:52 --> Helper loaded: form_helper
INFO - 2018-01-19 17:31:52 --> Database Driver Class Initialized
DEBUG - 2018-01-19 17:31:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 17:31:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 17:31:52 --> Form Validation Class Initialized
INFO - 2018-01-19 17:31:52 --> Model Class Initialized
INFO - 2018-01-19 17:31:52 --> Controller Class Initialized
INFO - 2018-01-19 17:31:52 --> Model Class Initialized
INFO - 2018-01-19 17:31:52 --> Model Class Initialized
INFO - 2018-01-19 17:31:52 --> Model Class Initialized
INFO - 2018-01-19 17:31:52 --> Model Class Initialized
DEBUG - 2018-01-19 17:31:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 17:31:52 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 17:31:52 --> Final output sent to browser
DEBUG - 2018-01-19 17:31:52 --> Total execution time: 0.0504
INFO - 2018-01-19 17:31:53 --> Config Class Initialized
INFO - 2018-01-19 17:31:53 --> Hooks Class Initialized
DEBUG - 2018-01-19 17:31:53 --> UTF-8 Support Enabled
INFO - 2018-01-19 17:31:53 --> Utf8 Class Initialized
INFO - 2018-01-19 17:31:53 --> URI Class Initialized
INFO - 2018-01-19 17:31:53 --> Router Class Initialized
INFO - 2018-01-19 17:31:53 --> Output Class Initialized
INFO - 2018-01-19 17:31:53 --> Security Class Initialized
DEBUG - 2018-01-19 17:31:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 17:31:53 --> Input Class Initialized
INFO - 2018-01-19 17:31:53 --> Language Class Initialized
INFO - 2018-01-19 17:31:53 --> Loader Class Initialized
INFO - 2018-01-19 17:31:53 --> Helper loaded: url_helper
INFO - 2018-01-19 17:31:53 --> Helper loaded: form_helper
INFO - 2018-01-19 17:31:53 --> Database Driver Class Initialized
DEBUG - 2018-01-19 17:31:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 17:31:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 17:31:53 --> Form Validation Class Initialized
INFO - 2018-01-19 17:31:53 --> Model Class Initialized
INFO - 2018-01-19 17:31:53 --> Controller Class Initialized
INFO - 2018-01-19 17:31:53 --> Model Class Initialized
INFO - 2018-01-19 17:31:53 --> Model Class Initialized
INFO - 2018-01-19 17:31:53 --> Model Class Initialized
INFO - 2018-01-19 17:31:53 --> Model Class Initialized
DEBUG - 2018-01-19 17:31:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 17:31:58 --> Config Class Initialized
INFO - 2018-01-19 17:31:58 --> Hooks Class Initialized
DEBUG - 2018-01-19 17:31:58 --> UTF-8 Support Enabled
INFO - 2018-01-19 17:31:58 --> Utf8 Class Initialized
INFO - 2018-01-19 17:31:58 --> URI Class Initialized
INFO - 2018-01-19 17:31:58 --> Router Class Initialized
INFO - 2018-01-19 17:31:58 --> Output Class Initialized
INFO - 2018-01-19 17:31:58 --> Security Class Initialized
DEBUG - 2018-01-19 17:31:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 17:31:58 --> Input Class Initialized
INFO - 2018-01-19 17:31:58 --> Language Class Initialized
INFO - 2018-01-19 17:31:58 --> Loader Class Initialized
INFO - 2018-01-19 17:31:58 --> Helper loaded: url_helper
INFO - 2018-01-19 17:31:58 --> Helper loaded: form_helper
INFO - 2018-01-19 17:31:58 --> Database Driver Class Initialized
DEBUG - 2018-01-19 17:31:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 17:31:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 17:31:58 --> Form Validation Class Initialized
INFO - 2018-01-19 17:31:58 --> Model Class Initialized
INFO - 2018-01-19 17:31:58 --> Controller Class Initialized
INFO - 2018-01-19 17:31:58 --> Model Class Initialized
INFO - 2018-01-19 17:31:58 --> Model Class Initialized
INFO - 2018-01-19 17:31:58 --> Model Class Initialized
INFO - 2018-01-19 17:31:58 --> Model Class Initialized
DEBUG - 2018-01-19 17:31:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 17:31:58 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 17:31:58 --> Final output sent to browser
DEBUG - 2018-01-19 17:31:58 --> Total execution time: 0.0534
INFO - 2018-01-19 17:31:58 --> Config Class Initialized
INFO - 2018-01-19 17:31:58 --> Hooks Class Initialized
DEBUG - 2018-01-19 17:31:58 --> UTF-8 Support Enabled
INFO - 2018-01-19 17:31:58 --> Utf8 Class Initialized
INFO - 2018-01-19 17:31:58 --> URI Class Initialized
INFO - 2018-01-19 17:31:58 --> Router Class Initialized
INFO - 2018-01-19 17:31:58 --> Output Class Initialized
INFO - 2018-01-19 17:31:58 --> Security Class Initialized
DEBUG - 2018-01-19 17:31:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 17:31:58 --> Input Class Initialized
INFO - 2018-01-19 17:31:58 --> Language Class Initialized
INFO - 2018-01-19 17:31:58 --> Loader Class Initialized
INFO - 2018-01-19 17:31:58 --> Helper loaded: url_helper
INFO - 2018-01-19 17:31:58 --> Helper loaded: form_helper
INFO - 2018-01-19 17:31:58 --> Database Driver Class Initialized
DEBUG - 2018-01-19 17:31:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 17:31:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 17:31:58 --> Form Validation Class Initialized
INFO - 2018-01-19 17:31:58 --> Model Class Initialized
INFO - 2018-01-19 17:31:58 --> Controller Class Initialized
INFO - 2018-01-19 17:31:58 --> Model Class Initialized
INFO - 2018-01-19 17:31:58 --> Model Class Initialized
INFO - 2018-01-19 17:31:58 --> Model Class Initialized
INFO - 2018-01-19 17:31:58 --> Model Class Initialized
DEBUG - 2018-01-19 17:31:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 17:32:40 --> Config Class Initialized
INFO - 2018-01-19 17:32:40 --> Hooks Class Initialized
DEBUG - 2018-01-19 17:32:40 --> UTF-8 Support Enabled
INFO - 2018-01-19 17:32:40 --> Utf8 Class Initialized
INFO - 2018-01-19 17:32:40 --> URI Class Initialized
INFO - 2018-01-19 17:32:40 --> Router Class Initialized
INFO - 2018-01-19 17:32:40 --> Output Class Initialized
INFO - 2018-01-19 17:32:40 --> Security Class Initialized
DEBUG - 2018-01-19 17:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 17:32:40 --> Input Class Initialized
INFO - 2018-01-19 17:32:40 --> Language Class Initialized
INFO - 2018-01-19 17:32:40 --> Loader Class Initialized
INFO - 2018-01-19 17:32:40 --> Helper loaded: url_helper
INFO - 2018-01-19 17:32:40 --> Helper loaded: form_helper
INFO - 2018-01-19 17:32:40 --> Database Driver Class Initialized
DEBUG - 2018-01-19 17:32:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 17:32:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 17:32:40 --> Form Validation Class Initialized
INFO - 2018-01-19 17:32:40 --> Model Class Initialized
INFO - 2018-01-19 17:32:40 --> Controller Class Initialized
INFO - 2018-01-19 17:32:40 --> Model Class Initialized
INFO - 2018-01-19 17:32:40 --> Model Class Initialized
INFO - 2018-01-19 17:32:40 --> Model Class Initialized
INFO - 2018-01-19 17:32:40 --> Model Class Initialized
DEBUG - 2018-01-19 17:32:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 17:32:40 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 17:32:40 --> Final output sent to browser
DEBUG - 2018-01-19 17:32:40 --> Total execution time: 0.0588
INFO - 2018-01-19 17:32:41 --> Config Class Initialized
INFO - 2018-01-19 17:32:41 --> Hooks Class Initialized
DEBUG - 2018-01-19 17:32:41 --> UTF-8 Support Enabled
INFO - 2018-01-19 17:32:41 --> Utf8 Class Initialized
INFO - 2018-01-19 17:32:41 --> URI Class Initialized
INFO - 2018-01-19 17:32:41 --> Router Class Initialized
INFO - 2018-01-19 17:32:41 --> Output Class Initialized
INFO - 2018-01-19 17:32:41 --> Security Class Initialized
DEBUG - 2018-01-19 17:32:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 17:32:41 --> Input Class Initialized
INFO - 2018-01-19 17:32:41 --> Language Class Initialized
INFO - 2018-01-19 17:32:41 --> Loader Class Initialized
INFO - 2018-01-19 17:32:41 --> Helper loaded: url_helper
INFO - 2018-01-19 17:32:41 --> Helper loaded: form_helper
INFO - 2018-01-19 17:32:41 --> Database Driver Class Initialized
DEBUG - 2018-01-19 17:32:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 17:32:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 17:32:41 --> Form Validation Class Initialized
INFO - 2018-01-19 17:32:41 --> Model Class Initialized
INFO - 2018-01-19 17:32:41 --> Controller Class Initialized
INFO - 2018-01-19 17:32:41 --> Model Class Initialized
INFO - 2018-01-19 17:32:41 --> Model Class Initialized
INFO - 2018-01-19 17:32:41 --> Model Class Initialized
INFO - 2018-01-19 17:32:41 --> Model Class Initialized
DEBUG - 2018-01-19 17:32:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 17:32:45 --> Config Class Initialized
INFO - 2018-01-19 17:32:45 --> Hooks Class Initialized
DEBUG - 2018-01-19 17:32:45 --> UTF-8 Support Enabled
INFO - 2018-01-19 17:32:45 --> Utf8 Class Initialized
INFO - 2018-01-19 17:32:45 --> URI Class Initialized
INFO - 2018-01-19 17:32:45 --> Router Class Initialized
INFO - 2018-01-19 17:32:45 --> Output Class Initialized
INFO - 2018-01-19 17:32:45 --> Security Class Initialized
DEBUG - 2018-01-19 17:32:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 17:32:45 --> Input Class Initialized
INFO - 2018-01-19 17:32:45 --> Language Class Initialized
INFO - 2018-01-19 17:32:45 --> Loader Class Initialized
INFO - 2018-01-19 17:32:45 --> Helper loaded: url_helper
INFO - 2018-01-19 17:32:45 --> Helper loaded: form_helper
INFO - 2018-01-19 17:32:45 --> Database Driver Class Initialized
DEBUG - 2018-01-19 17:32:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 17:32:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 17:32:45 --> Form Validation Class Initialized
INFO - 2018-01-19 17:32:45 --> Model Class Initialized
INFO - 2018-01-19 17:32:45 --> Controller Class Initialized
INFO - 2018-01-19 17:32:45 --> Model Class Initialized
INFO - 2018-01-19 17:32:45 --> Model Class Initialized
INFO - 2018-01-19 17:32:45 --> Model Class Initialized
INFO - 2018-01-19 17:32:45 --> Model Class Initialized
DEBUG - 2018-01-19 17:32:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 17:32:45 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 17:32:45 --> Final output sent to browser
DEBUG - 2018-01-19 17:32:45 --> Total execution time: 0.0534
INFO - 2018-01-19 17:37:56 --> Config Class Initialized
INFO - 2018-01-19 17:37:56 --> Hooks Class Initialized
DEBUG - 2018-01-19 17:37:56 --> UTF-8 Support Enabled
INFO - 2018-01-19 17:37:56 --> Utf8 Class Initialized
INFO - 2018-01-19 17:37:56 --> URI Class Initialized
INFO - 2018-01-19 17:37:56 --> Router Class Initialized
INFO - 2018-01-19 17:37:56 --> Output Class Initialized
INFO - 2018-01-19 17:37:56 --> Security Class Initialized
DEBUG - 2018-01-19 17:37:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 17:37:56 --> Input Class Initialized
INFO - 2018-01-19 17:37:56 --> Language Class Initialized
INFO - 2018-01-19 17:37:56 --> Loader Class Initialized
INFO - 2018-01-19 17:37:56 --> Helper loaded: url_helper
INFO - 2018-01-19 17:37:56 --> Helper loaded: form_helper
INFO - 2018-01-19 17:37:56 --> Database Driver Class Initialized
DEBUG - 2018-01-19 17:37:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 17:37:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 17:37:56 --> Form Validation Class Initialized
INFO - 2018-01-19 17:37:56 --> Model Class Initialized
INFO - 2018-01-19 17:37:56 --> Controller Class Initialized
INFO - 2018-01-19 17:37:56 --> Model Class Initialized
INFO - 2018-01-19 17:37:56 --> Model Class Initialized
INFO - 2018-01-19 17:37:56 --> Model Class Initialized
INFO - 2018-01-19 17:37:56 --> Model Class Initialized
DEBUG - 2018-01-19 17:37:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 17:37:56 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 17:37:56 --> Final output sent to browser
DEBUG - 2018-01-19 17:37:56 --> Total execution time: 0.0554
INFO - 2018-01-19 17:37:57 --> Config Class Initialized
INFO - 2018-01-19 17:37:57 --> Hooks Class Initialized
DEBUG - 2018-01-19 17:37:57 --> UTF-8 Support Enabled
INFO - 2018-01-19 17:37:57 --> Utf8 Class Initialized
INFO - 2018-01-19 17:37:57 --> URI Class Initialized
INFO - 2018-01-19 17:37:57 --> Router Class Initialized
INFO - 2018-01-19 17:37:57 --> Output Class Initialized
INFO - 2018-01-19 17:37:57 --> Security Class Initialized
DEBUG - 2018-01-19 17:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 17:37:57 --> Input Class Initialized
INFO - 2018-01-19 17:37:57 --> Language Class Initialized
INFO - 2018-01-19 17:37:57 --> Loader Class Initialized
INFO - 2018-01-19 17:37:57 --> Helper loaded: url_helper
INFO - 2018-01-19 17:37:57 --> Helper loaded: form_helper
INFO - 2018-01-19 17:37:57 --> Database Driver Class Initialized
DEBUG - 2018-01-19 17:37:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 17:37:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 17:37:57 --> Form Validation Class Initialized
INFO - 2018-01-19 17:37:57 --> Model Class Initialized
INFO - 2018-01-19 17:37:57 --> Controller Class Initialized
INFO - 2018-01-19 17:37:57 --> Model Class Initialized
INFO - 2018-01-19 17:37:57 --> Model Class Initialized
INFO - 2018-01-19 17:37:57 --> Model Class Initialized
INFO - 2018-01-19 17:37:57 --> Model Class Initialized
DEBUG - 2018-01-19 17:37:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 17:38:00 --> Config Class Initialized
INFO - 2018-01-19 17:38:00 --> Hooks Class Initialized
DEBUG - 2018-01-19 17:38:00 --> UTF-8 Support Enabled
INFO - 2018-01-19 17:38:00 --> Utf8 Class Initialized
INFO - 2018-01-19 17:38:00 --> URI Class Initialized
INFO - 2018-01-19 17:38:00 --> Router Class Initialized
INFO - 2018-01-19 17:38:00 --> Output Class Initialized
INFO - 2018-01-19 17:38:00 --> Security Class Initialized
DEBUG - 2018-01-19 17:38:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 17:38:00 --> Input Class Initialized
INFO - 2018-01-19 17:38:00 --> Language Class Initialized
INFO - 2018-01-19 17:38:00 --> Loader Class Initialized
INFO - 2018-01-19 17:38:00 --> Helper loaded: url_helper
INFO - 2018-01-19 17:38:00 --> Helper loaded: form_helper
INFO - 2018-01-19 17:38:00 --> Database Driver Class Initialized
DEBUG - 2018-01-19 17:38:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 17:38:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 17:38:00 --> Form Validation Class Initialized
INFO - 2018-01-19 17:38:00 --> Model Class Initialized
INFO - 2018-01-19 17:38:00 --> Controller Class Initialized
INFO - 2018-01-19 17:38:00 --> Model Class Initialized
INFO - 2018-01-19 17:38:00 --> Model Class Initialized
INFO - 2018-01-19 17:38:00 --> Model Class Initialized
INFO - 2018-01-19 17:38:00 --> Model Class Initialized
DEBUG - 2018-01-19 17:38:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 17:38:00 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 17:38:00 --> Final output sent to browser
DEBUG - 2018-01-19 17:38:00 --> Total execution time: 0.0529
INFO - 2018-01-19 17:38:20 --> Config Class Initialized
INFO - 2018-01-19 17:38:20 --> Hooks Class Initialized
DEBUG - 2018-01-19 17:38:20 --> UTF-8 Support Enabled
INFO - 2018-01-19 17:38:20 --> Utf8 Class Initialized
INFO - 2018-01-19 17:38:20 --> URI Class Initialized
INFO - 2018-01-19 17:38:20 --> Router Class Initialized
INFO - 2018-01-19 17:38:20 --> Output Class Initialized
INFO - 2018-01-19 17:38:20 --> Security Class Initialized
DEBUG - 2018-01-19 17:38:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 17:38:20 --> Input Class Initialized
INFO - 2018-01-19 17:38:20 --> Language Class Initialized
INFO - 2018-01-19 17:38:20 --> Loader Class Initialized
INFO - 2018-01-19 17:38:20 --> Helper loaded: url_helper
INFO - 2018-01-19 17:38:20 --> Helper loaded: form_helper
INFO - 2018-01-19 17:38:20 --> Database Driver Class Initialized
DEBUG - 2018-01-19 17:38:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 17:38:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 17:38:20 --> Form Validation Class Initialized
INFO - 2018-01-19 17:38:20 --> Model Class Initialized
INFO - 2018-01-19 17:38:20 --> Controller Class Initialized
INFO - 2018-01-19 17:38:20 --> Model Class Initialized
INFO - 2018-01-19 17:38:20 --> Model Class Initialized
INFO - 2018-01-19 17:38:20 --> Model Class Initialized
INFO - 2018-01-19 17:38:20 --> Model Class Initialized
DEBUG - 2018-01-19 17:38:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 17:38:20 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 17:38:20 --> Final output sent to browser
DEBUG - 2018-01-19 17:38:20 --> Total execution time: 0.0638
INFO - 2018-01-19 17:38:52 --> Config Class Initialized
INFO - 2018-01-19 17:38:52 --> Hooks Class Initialized
DEBUG - 2018-01-19 17:38:52 --> UTF-8 Support Enabled
INFO - 2018-01-19 17:38:52 --> Utf8 Class Initialized
INFO - 2018-01-19 17:38:52 --> URI Class Initialized
DEBUG - 2018-01-19 17:38:52 --> No URI present. Default controller set.
INFO - 2018-01-19 17:38:52 --> Router Class Initialized
INFO - 2018-01-19 17:38:52 --> Output Class Initialized
INFO - 2018-01-19 17:38:52 --> Security Class Initialized
DEBUG - 2018-01-19 17:38:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 17:38:52 --> Input Class Initialized
INFO - 2018-01-19 17:38:52 --> Language Class Initialized
INFO - 2018-01-19 17:38:52 --> Loader Class Initialized
INFO - 2018-01-19 17:38:52 --> Helper loaded: url_helper
INFO - 2018-01-19 17:38:52 --> Helper loaded: form_helper
INFO - 2018-01-19 17:38:52 --> Database Driver Class Initialized
DEBUG - 2018-01-19 17:38:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 17:38:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 17:38:52 --> Form Validation Class Initialized
INFO - 2018-01-19 17:38:52 --> Model Class Initialized
INFO - 2018-01-19 17:38:52 --> Controller Class Initialized
INFO - 2018-01-19 17:38:52 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 17:38:52 --> Final output sent to browser
DEBUG - 2018-01-19 17:38:52 --> Total execution time: 0.0400
INFO - 2018-01-19 17:39:00 --> Config Class Initialized
INFO - 2018-01-19 17:39:00 --> Hooks Class Initialized
DEBUG - 2018-01-19 17:39:00 --> UTF-8 Support Enabled
INFO - 2018-01-19 17:39:00 --> Utf8 Class Initialized
INFO - 2018-01-19 17:39:00 --> URI Class Initialized
INFO - 2018-01-19 17:39:00 --> Router Class Initialized
INFO - 2018-01-19 17:39:00 --> Output Class Initialized
INFO - 2018-01-19 17:39:00 --> Security Class Initialized
DEBUG - 2018-01-19 17:39:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 17:39:00 --> Input Class Initialized
INFO - 2018-01-19 17:39:00 --> Language Class Initialized
INFO - 2018-01-19 17:39:00 --> Loader Class Initialized
INFO - 2018-01-19 17:39:00 --> Helper loaded: url_helper
INFO - 2018-01-19 17:39:00 --> Helper loaded: form_helper
INFO - 2018-01-19 17:39:00 --> Database Driver Class Initialized
DEBUG - 2018-01-19 17:39:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 17:39:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 17:39:00 --> Form Validation Class Initialized
INFO - 2018-01-19 17:39:00 --> Model Class Initialized
INFO - 2018-01-19 17:39:00 --> Controller Class Initialized
INFO - 2018-01-19 17:39:00 --> Model Class Initialized
INFO - 2018-01-19 17:39:00 --> Model Class Initialized
DEBUG - 2018-01-19 17:39:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 17:39:00 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 17:39:00 --> Final output sent to browser
DEBUG - 2018-01-19 17:39:00 --> Total execution time: 0.0528
INFO - 2018-01-19 17:39:01 --> Config Class Initialized
INFO - 2018-01-19 17:39:01 --> Hooks Class Initialized
DEBUG - 2018-01-19 17:39:01 --> UTF-8 Support Enabled
INFO - 2018-01-19 17:39:01 --> Utf8 Class Initialized
INFO - 2018-01-19 17:39:01 --> URI Class Initialized
INFO - 2018-01-19 17:39:01 --> Router Class Initialized
INFO - 2018-01-19 17:39:01 --> Output Class Initialized
INFO - 2018-01-19 17:39:01 --> Security Class Initialized
DEBUG - 2018-01-19 17:39:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 17:39:01 --> Input Class Initialized
INFO - 2018-01-19 17:39:01 --> Language Class Initialized
INFO - 2018-01-19 17:39:01 --> Loader Class Initialized
INFO - 2018-01-19 17:39:01 --> Helper loaded: url_helper
INFO - 2018-01-19 17:39:01 --> Helper loaded: form_helper
INFO - 2018-01-19 17:39:01 --> Database Driver Class Initialized
DEBUG - 2018-01-19 17:39:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 17:39:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 17:39:01 --> Form Validation Class Initialized
INFO - 2018-01-19 17:39:01 --> Model Class Initialized
INFO - 2018-01-19 17:39:01 --> Controller Class Initialized
INFO - 2018-01-19 17:39:01 --> Model Class Initialized
INFO - 2018-01-19 17:39:01 --> Model Class Initialized
DEBUG - 2018-01-19 17:39:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 17:39:13 --> Config Class Initialized
INFO - 2018-01-19 17:39:13 --> Hooks Class Initialized
DEBUG - 2018-01-19 17:39:13 --> UTF-8 Support Enabled
INFO - 2018-01-19 17:39:13 --> Utf8 Class Initialized
INFO - 2018-01-19 17:39:13 --> URI Class Initialized
INFO - 2018-01-19 17:39:13 --> Router Class Initialized
INFO - 2018-01-19 17:39:13 --> Output Class Initialized
INFO - 2018-01-19 17:39:13 --> Security Class Initialized
DEBUG - 2018-01-19 17:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 17:39:13 --> Input Class Initialized
INFO - 2018-01-19 17:39:13 --> Language Class Initialized
INFO - 2018-01-19 17:39:13 --> Loader Class Initialized
INFO - 2018-01-19 17:39:13 --> Helper loaded: url_helper
INFO - 2018-01-19 17:39:13 --> Helper loaded: form_helper
INFO - 2018-01-19 17:39:13 --> Database Driver Class Initialized
DEBUG - 2018-01-19 17:39:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 17:39:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 17:39:13 --> Form Validation Class Initialized
INFO - 2018-01-19 17:39:13 --> Model Class Initialized
INFO - 2018-01-19 17:39:13 --> Controller Class Initialized
INFO - 2018-01-19 17:39:13 --> Model Class Initialized
INFO - 2018-01-19 17:39:13 --> Model Class Initialized
DEBUG - 2018-01-19 17:39:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 17:39:13 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 17:39:13 --> Final output sent to browser
DEBUG - 2018-01-19 17:39:13 --> Total execution time: 0.0387
INFO - 2018-01-19 17:42:16 --> Config Class Initialized
INFO - 2018-01-19 17:42:16 --> Hooks Class Initialized
DEBUG - 2018-01-19 17:42:16 --> UTF-8 Support Enabled
INFO - 2018-01-19 17:42:16 --> Utf8 Class Initialized
INFO - 2018-01-19 17:42:16 --> URI Class Initialized
INFO - 2018-01-19 17:42:16 --> Router Class Initialized
INFO - 2018-01-19 17:42:16 --> Output Class Initialized
INFO - 2018-01-19 17:42:16 --> Security Class Initialized
DEBUG - 2018-01-19 17:42:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 17:42:16 --> Input Class Initialized
INFO - 2018-01-19 17:42:16 --> Language Class Initialized
INFO - 2018-01-19 17:42:16 --> Loader Class Initialized
INFO - 2018-01-19 17:42:16 --> Helper loaded: url_helper
INFO - 2018-01-19 17:42:16 --> Helper loaded: form_helper
INFO - 2018-01-19 17:42:16 --> Database Driver Class Initialized
DEBUG - 2018-01-19 17:42:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 17:42:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 17:42:16 --> Form Validation Class Initialized
INFO - 2018-01-19 17:42:16 --> Model Class Initialized
INFO - 2018-01-19 17:42:16 --> Controller Class Initialized
INFO - 2018-01-19 17:42:16 --> Model Class Initialized
INFO - 2018-01-19 17:42:16 --> Model Class Initialized
DEBUG - 2018-01-19 17:42:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 17:42:17 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 17:42:17 --> Final output sent to browser
DEBUG - 2018-01-19 17:42:17 --> Total execution time: 0.4824
INFO - 2018-01-19 17:43:39 --> Config Class Initialized
INFO - 2018-01-19 17:43:39 --> Hooks Class Initialized
DEBUG - 2018-01-19 17:43:39 --> UTF-8 Support Enabled
INFO - 2018-01-19 17:43:39 --> Utf8 Class Initialized
INFO - 2018-01-19 17:43:39 --> URI Class Initialized
INFO - 2018-01-19 17:43:39 --> Router Class Initialized
INFO - 2018-01-19 17:43:39 --> Output Class Initialized
INFO - 2018-01-19 17:43:39 --> Security Class Initialized
DEBUG - 2018-01-19 17:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 17:43:39 --> Input Class Initialized
INFO - 2018-01-19 17:43:39 --> Language Class Initialized
INFO - 2018-01-19 17:43:39 --> Loader Class Initialized
INFO - 2018-01-19 17:43:39 --> Helper loaded: url_helper
INFO - 2018-01-19 17:43:39 --> Helper loaded: form_helper
INFO - 2018-01-19 17:43:39 --> Database Driver Class Initialized
DEBUG - 2018-01-19 17:43:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 17:43:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 17:43:39 --> Form Validation Class Initialized
INFO - 2018-01-19 17:43:39 --> Model Class Initialized
INFO - 2018-01-19 17:43:39 --> Controller Class Initialized
INFO - 2018-01-19 17:43:39 --> Model Class Initialized
INFO - 2018-01-19 17:43:39 --> Model Class Initialized
DEBUG - 2018-01-19 17:43:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 17:43:39 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 17:43:39 --> Final output sent to browser
DEBUG - 2018-01-19 17:43:39 --> Total execution time: 0.3360
INFO - 2018-01-19 17:44:13 --> Config Class Initialized
INFO - 2018-01-19 17:44:13 --> Hooks Class Initialized
DEBUG - 2018-01-19 17:44:13 --> UTF-8 Support Enabled
INFO - 2018-01-19 17:44:13 --> Utf8 Class Initialized
INFO - 2018-01-19 17:44:13 --> URI Class Initialized
INFO - 2018-01-19 17:44:13 --> Router Class Initialized
INFO - 2018-01-19 17:44:13 --> Output Class Initialized
INFO - 2018-01-19 17:44:13 --> Security Class Initialized
DEBUG - 2018-01-19 17:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 17:44:13 --> Input Class Initialized
INFO - 2018-01-19 17:44:13 --> Language Class Initialized
INFO - 2018-01-19 17:44:13 --> Loader Class Initialized
INFO - 2018-01-19 17:44:13 --> Helper loaded: url_helper
INFO - 2018-01-19 17:44:13 --> Helper loaded: form_helper
INFO - 2018-01-19 17:44:13 --> Database Driver Class Initialized
DEBUG - 2018-01-19 17:44:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 17:44:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 17:44:13 --> Form Validation Class Initialized
INFO - 2018-01-19 17:44:13 --> Model Class Initialized
INFO - 2018-01-19 17:44:13 --> Controller Class Initialized
INFO - 2018-01-19 17:44:13 --> Model Class Initialized
INFO - 2018-01-19 17:44:13 --> Model Class Initialized
INFO - 2018-01-19 17:44:13 --> Model Class Initialized
INFO - 2018-01-19 17:44:13 --> Model Class Initialized
DEBUG - 2018-01-19 17:44:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 17:44:13 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 17:44:13 --> Final output sent to browser
DEBUG - 2018-01-19 17:44:13 --> Total execution time: 0.0466
INFO - 2018-01-19 17:44:14 --> Config Class Initialized
INFO - 2018-01-19 17:44:14 --> Hooks Class Initialized
DEBUG - 2018-01-19 17:44:14 --> UTF-8 Support Enabled
INFO - 2018-01-19 17:44:14 --> Utf8 Class Initialized
INFO - 2018-01-19 17:44:14 --> URI Class Initialized
INFO - 2018-01-19 17:44:14 --> Router Class Initialized
INFO - 2018-01-19 17:44:14 --> Output Class Initialized
INFO - 2018-01-19 17:44:14 --> Security Class Initialized
DEBUG - 2018-01-19 17:44:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 17:44:14 --> Input Class Initialized
INFO - 2018-01-19 17:44:14 --> Language Class Initialized
INFO - 2018-01-19 17:44:14 --> Loader Class Initialized
INFO - 2018-01-19 17:44:14 --> Helper loaded: url_helper
INFO - 2018-01-19 17:44:14 --> Helper loaded: form_helper
INFO - 2018-01-19 17:44:14 --> Database Driver Class Initialized
DEBUG - 2018-01-19 17:44:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 17:44:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 17:44:14 --> Form Validation Class Initialized
INFO - 2018-01-19 17:44:14 --> Model Class Initialized
INFO - 2018-01-19 17:44:14 --> Controller Class Initialized
INFO - 2018-01-19 17:44:14 --> Model Class Initialized
INFO - 2018-01-19 17:44:14 --> Model Class Initialized
INFO - 2018-01-19 17:44:14 --> Model Class Initialized
INFO - 2018-01-19 17:44:14 --> Model Class Initialized
DEBUG - 2018-01-19 17:44:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 17:44:21 --> Config Class Initialized
INFO - 2018-01-19 17:44:21 --> Hooks Class Initialized
DEBUG - 2018-01-19 17:44:21 --> UTF-8 Support Enabled
INFO - 2018-01-19 17:44:21 --> Utf8 Class Initialized
INFO - 2018-01-19 17:44:21 --> URI Class Initialized
INFO - 2018-01-19 17:44:21 --> Router Class Initialized
INFO - 2018-01-19 17:44:21 --> Output Class Initialized
INFO - 2018-01-19 17:44:21 --> Security Class Initialized
DEBUG - 2018-01-19 17:44:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 17:44:21 --> Input Class Initialized
INFO - 2018-01-19 17:44:21 --> Language Class Initialized
INFO - 2018-01-19 17:44:21 --> Loader Class Initialized
INFO - 2018-01-19 17:44:21 --> Helper loaded: url_helper
INFO - 2018-01-19 17:44:21 --> Helper loaded: form_helper
INFO - 2018-01-19 17:44:21 --> Database Driver Class Initialized
DEBUG - 2018-01-19 17:44:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 17:44:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 17:44:21 --> Form Validation Class Initialized
INFO - 2018-01-19 17:44:21 --> Model Class Initialized
INFO - 2018-01-19 17:44:21 --> Controller Class Initialized
INFO - 2018-01-19 17:44:21 --> Model Class Initialized
INFO - 2018-01-19 17:44:21 --> Model Class Initialized
INFO - 2018-01-19 17:44:21 --> Model Class Initialized
INFO - 2018-01-19 17:44:21 --> Model Class Initialized
DEBUG - 2018-01-19 17:44:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 17:44:21 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 17:44:21 --> Final output sent to browser
DEBUG - 2018-01-19 17:44:21 --> Total execution time: 0.0526
INFO - 2018-01-19 17:44:22 --> Config Class Initialized
INFO - 2018-01-19 17:44:22 --> Hooks Class Initialized
DEBUG - 2018-01-19 17:44:22 --> UTF-8 Support Enabled
INFO - 2018-01-19 17:44:22 --> Utf8 Class Initialized
INFO - 2018-01-19 17:44:22 --> URI Class Initialized
INFO - 2018-01-19 17:44:22 --> Router Class Initialized
INFO - 2018-01-19 17:44:22 --> Output Class Initialized
INFO - 2018-01-19 17:44:22 --> Security Class Initialized
DEBUG - 2018-01-19 17:44:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 17:44:22 --> Input Class Initialized
INFO - 2018-01-19 17:44:22 --> Language Class Initialized
INFO - 2018-01-19 17:44:22 --> Loader Class Initialized
INFO - 2018-01-19 17:44:22 --> Helper loaded: url_helper
INFO - 2018-01-19 17:44:22 --> Helper loaded: form_helper
INFO - 2018-01-19 17:44:22 --> Database Driver Class Initialized
DEBUG - 2018-01-19 17:44:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 17:44:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 17:44:22 --> Form Validation Class Initialized
INFO - 2018-01-19 17:44:22 --> Model Class Initialized
INFO - 2018-01-19 17:44:22 --> Controller Class Initialized
INFO - 2018-01-19 17:44:22 --> Model Class Initialized
INFO - 2018-01-19 17:44:22 --> Model Class Initialized
INFO - 2018-01-19 17:44:22 --> Model Class Initialized
INFO - 2018-01-19 17:44:22 --> Model Class Initialized
DEBUG - 2018-01-19 17:44:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 17:46:36 --> Config Class Initialized
INFO - 2018-01-19 17:46:36 --> Hooks Class Initialized
DEBUG - 2018-01-19 17:46:36 --> UTF-8 Support Enabled
INFO - 2018-01-19 17:46:36 --> Utf8 Class Initialized
INFO - 2018-01-19 17:46:36 --> URI Class Initialized
INFO - 2018-01-19 17:46:36 --> Router Class Initialized
INFO - 2018-01-19 17:46:36 --> Output Class Initialized
INFO - 2018-01-19 17:46:36 --> Security Class Initialized
DEBUG - 2018-01-19 17:46:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 17:46:36 --> Input Class Initialized
INFO - 2018-01-19 17:46:36 --> Language Class Initialized
INFO - 2018-01-19 17:46:36 --> Loader Class Initialized
INFO - 2018-01-19 17:46:36 --> Helper loaded: url_helper
INFO - 2018-01-19 17:46:36 --> Helper loaded: form_helper
INFO - 2018-01-19 17:46:36 --> Database Driver Class Initialized
DEBUG - 2018-01-19 17:46:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 17:46:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 17:46:36 --> Form Validation Class Initialized
INFO - 2018-01-19 17:46:36 --> Model Class Initialized
INFO - 2018-01-19 17:46:36 --> Controller Class Initialized
INFO - 2018-01-19 17:46:36 --> Model Class Initialized
INFO - 2018-01-19 17:46:36 --> Model Class Initialized
INFO - 2018-01-19 17:46:36 --> Model Class Initialized
INFO - 2018-01-19 17:46:36 --> Model Class Initialized
DEBUG - 2018-01-19 17:46:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 17:46:36 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 17:46:36 --> Final output sent to browser
DEBUG - 2018-01-19 17:46:36 --> Total execution time: 0.0539
INFO - 2018-01-19 17:46:36 --> Config Class Initialized
INFO - 2018-01-19 17:46:36 --> Hooks Class Initialized
DEBUG - 2018-01-19 17:46:36 --> UTF-8 Support Enabled
INFO - 2018-01-19 17:46:36 --> Utf8 Class Initialized
INFO - 2018-01-19 17:46:36 --> URI Class Initialized
INFO - 2018-01-19 17:46:36 --> Router Class Initialized
INFO - 2018-01-19 17:46:36 --> Output Class Initialized
INFO - 2018-01-19 17:46:36 --> Security Class Initialized
DEBUG - 2018-01-19 17:46:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 17:46:36 --> Input Class Initialized
INFO - 2018-01-19 17:46:36 --> Language Class Initialized
INFO - 2018-01-19 17:46:36 --> Loader Class Initialized
INFO - 2018-01-19 17:46:36 --> Helper loaded: url_helper
INFO - 2018-01-19 17:46:36 --> Helper loaded: form_helper
INFO - 2018-01-19 17:46:36 --> Database Driver Class Initialized
DEBUG - 2018-01-19 17:46:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 17:46:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 17:46:37 --> Form Validation Class Initialized
INFO - 2018-01-19 17:46:37 --> Model Class Initialized
INFO - 2018-01-19 17:46:37 --> Controller Class Initialized
INFO - 2018-01-19 17:46:37 --> Model Class Initialized
INFO - 2018-01-19 17:46:37 --> Model Class Initialized
INFO - 2018-01-19 17:46:37 --> Model Class Initialized
INFO - 2018-01-19 17:46:37 --> Model Class Initialized
DEBUG - 2018-01-19 17:46:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 17:47:03 --> Config Class Initialized
INFO - 2018-01-19 17:47:03 --> Hooks Class Initialized
DEBUG - 2018-01-19 17:47:03 --> UTF-8 Support Enabled
INFO - 2018-01-19 17:47:03 --> Utf8 Class Initialized
INFO - 2018-01-19 17:47:03 --> URI Class Initialized
INFO - 2018-01-19 17:47:03 --> Router Class Initialized
INFO - 2018-01-19 17:47:03 --> Output Class Initialized
INFO - 2018-01-19 17:47:03 --> Security Class Initialized
DEBUG - 2018-01-19 17:47:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 17:47:03 --> Input Class Initialized
INFO - 2018-01-19 17:47:03 --> Language Class Initialized
INFO - 2018-01-19 17:47:03 --> Loader Class Initialized
INFO - 2018-01-19 17:47:03 --> Helper loaded: url_helper
INFO - 2018-01-19 17:47:03 --> Helper loaded: form_helper
INFO - 2018-01-19 17:47:03 --> Database Driver Class Initialized
DEBUG - 2018-01-19 17:47:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 17:47:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 17:47:03 --> Form Validation Class Initialized
INFO - 2018-01-19 17:47:03 --> Model Class Initialized
INFO - 2018-01-19 17:47:03 --> Controller Class Initialized
INFO - 2018-01-19 17:47:03 --> Model Class Initialized
INFO - 2018-01-19 17:47:03 --> Model Class Initialized
INFO - 2018-01-19 17:47:03 --> Model Class Initialized
INFO - 2018-01-19 17:47:03 --> Model Class Initialized
DEBUG - 2018-01-19 17:47:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 17:47:03 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 17:47:03 --> Final output sent to browser
DEBUG - 2018-01-19 17:47:03 --> Total execution time: 0.0531
INFO - 2018-01-19 17:50:55 --> Config Class Initialized
INFO - 2018-01-19 17:50:55 --> Hooks Class Initialized
DEBUG - 2018-01-19 17:50:55 --> UTF-8 Support Enabled
INFO - 2018-01-19 17:50:55 --> Utf8 Class Initialized
INFO - 2018-01-19 17:50:55 --> URI Class Initialized
INFO - 2018-01-19 17:50:55 --> Router Class Initialized
INFO - 2018-01-19 17:50:55 --> Output Class Initialized
INFO - 2018-01-19 17:50:55 --> Security Class Initialized
DEBUG - 2018-01-19 17:50:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 17:50:55 --> Input Class Initialized
INFO - 2018-01-19 17:50:55 --> Language Class Initialized
INFO - 2018-01-19 17:50:55 --> Loader Class Initialized
INFO - 2018-01-19 17:50:55 --> Helper loaded: url_helper
INFO - 2018-01-19 17:50:55 --> Helper loaded: form_helper
INFO - 2018-01-19 17:50:55 --> Database Driver Class Initialized
DEBUG - 2018-01-19 17:50:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 17:50:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 17:50:55 --> Form Validation Class Initialized
INFO - 2018-01-19 17:50:55 --> Model Class Initialized
INFO - 2018-01-19 17:50:55 --> Controller Class Initialized
INFO - 2018-01-19 17:50:55 --> Model Class Initialized
INFO - 2018-01-19 17:50:55 --> Model Class Initialized
INFO - 2018-01-19 17:50:55 --> Model Class Initialized
INFO - 2018-01-19 17:50:55 --> Model Class Initialized
DEBUG - 2018-01-19 17:50:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 17:50:56 --> Config Class Initialized
INFO - 2018-01-19 17:50:56 --> Hooks Class Initialized
DEBUG - 2018-01-19 17:50:56 --> UTF-8 Support Enabled
INFO - 2018-01-19 17:50:56 --> Utf8 Class Initialized
INFO - 2018-01-19 17:50:56 --> URI Class Initialized
INFO - 2018-01-19 17:50:56 --> Router Class Initialized
INFO - 2018-01-19 17:50:56 --> Output Class Initialized
INFO - 2018-01-19 17:50:56 --> Security Class Initialized
DEBUG - 2018-01-19 17:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 17:50:56 --> Input Class Initialized
INFO - 2018-01-19 17:50:56 --> Language Class Initialized
INFO - 2018-01-19 17:50:56 --> Loader Class Initialized
INFO - 2018-01-19 17:50:56 --> Helper loaded: url_helper
INFO - 2018-01-19 17:50:56 --> Helper loaded: form_helper
INFO - 2018-01-19 17:50:56 --> Database Driver Class Initialized
DEBUG - 2018-01-19 17:50:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 17:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 17:50:56 --> Form Validation Class Initialized
INFO - 2018-01-19 17:50:56 --> Model Class Initialized
INFO - 2018-01-19 17:50:56 --> Controller Class Initialized
INFO - 2018-01-19 17:50:56 --> Model Class Initialized
INFO - 2018-01-19 17:50:56 --> Model Class Initialized
INFO - 2018-01-19 17:50:56 --> Model Class Initialized
INFO - 2018-01-19 17:50:56 --> Model Class Initialized
DEBUG - 2018-01-19 17:50:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 17:50:56 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 17:50:56 --> Final output sent to browser
DEBUG - 2018-01-19 17:50:56 --> Total execution time: 0.0560
INFO - 2018-01-19 17:50:57 --> Config Class Initialized
INFO - 2018-01-19 17:50:57 --> Hooks Class Initialized
DEBUG - 2018-01-19 17:50:57 --> UTF-8 Support Enabled
INFO - 2018-01-19 17:50:57 --> Utf8 Class Initialized
INFO - 2018-01-19 17:50:57 --> URI Class Initialized
INFO - 2018-01-19 17:50:57 --> Router Class Initialized
INFO - 2018-01-19 17:50:57 --> Output Class Initialized
INFO - 2018-01-19 17:50:57 --> Security Class Initialized
DEBUG - 2018-01-19 17:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 17:50:57 --> Input Class Initialized
INFO - 2018-01-19 17:50:57 --> Language Class Initialized
INFO - 2018-01-19 17:50:57 --> Loader Class Initialized
INFO - 2018-01-19 17:50:57 --> Helper loaded: url_helper
INFO - 2018-01-19 17:50:57 --> Helper loaded: form_helper
INFO - 2018-01-19 17:50:57 --> Database Driver Class Initialized
DEBUG - 2018-01-19 17:50:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 17:50:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 17:50:57 --> Form Validation Class Initialized
INFO - 2018-01-19 17:50:57 --> Model Class Initialized
INFO - 2018-01-19 17:50:57 --> Controller Class Initialized
INFO - 2018-01-19 17:50:57 --> Model Class Initialized
INFO - 2018-01-19 17:50:57 --> Model Class Initialized
INFO - 2018-01-19 17:50:57 --> Model Class Initialized
INFO - 2018-01-19 17:50:57 --> Model Class Initialized
DEBUG - 2018-01-19 17:50:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 17:51:23 --> Config Class Initialized
INFO - 2018-01-19 17:51:23 --> Hooks Class Initialized
DEBUG - 2018-01-19 17:51:23 --> UTF-8 Support Enabled
INFO - 2018-01-19 17:51:23 --> Utf8 Class Initialized
INFO - 2018-01-19 17:51:23 --> URI Class Initialized
INFO - 2018-01-19 17:51:23 --> Router Class Initialized
INFO - 2018-01-19 17:51:23 --> Output Class Initialized
INFO - 2018-01-19 17:51:23 --> Security Class Initialized
DEBUG - 2018-01-19 17:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 17:51:23 --> Input Class Initialized
INFO - 2018-01-19 17:51:23 --> Language Class Initialized
INFO - 2018-01-19 17:51:23 --> Loader Class Initialized
INFO - 2018-01-19 17:51:23 --> Helper loaded: url_helper
INFO - 2018-01-19 17:51:23 --> Helper loaded: form_helper
INFO - 2018-01-19 17:51:23 --> Database Driver Class Initialized
DEBUG - 2018-01-19 17:51:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 17:51:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 17:51:23 --> Form Validation Class Initialized
INFO - 2018-01-19 17:51:23 --> Model Class Initialized
INFO - 2018-01-19 17:51:23 --> Controller Class Initialized
INFO - 2018-01-19 17:51:23 --> Model Class Initialized
INFO - 2018-01-19 17:51:23 --> Model Class Initialized
INFO - 2018-01-19 17:51:23 --> Model Class Initialized
INFO - 2018-01-19 17:51:23 --> Model Class Initialized
DEBUG - 2018-01-19 17:51:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 17:51:23 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 17:51:23 --> Final output sent to browser
DEBUG - 2018-01-19 17:51:23 --> Total execution time: 0.0526
INFO - 2018-01-19 17:51:24 --> Config Class Initialized
INFO - 2018-01-19 17:51:24 --> Hooks Class Initialized
DEBUG - 2018-01-19 17:51:24 --> UTF-8 Support Enabled
INFO - 2018-01-19 17:51:24 --> Utf8 Class Initialized
INFO - 2018-01-19 17:51:24 --> URI Class Initialized
INFO - 2018-01-19 17:51:24 --> Router Class Initialized
INFO - 2018-01-19 17:51:24 --> Output Class Initialized
INFO - 2018-01-19 17:51:24 --> Security Class Initialized
DEBUG - 2018-01-19 17:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 17:51:24 --> Input Class Initialized
INFO - 2018-01-19 17:51:24 --> Language Class Initialized
INFO - 2018-01-19 17:51:24 --> Loader Class Initialized
INFO - 2018-01-19 17:51:24 --> Helper loaded: url_helper
INFO - 2018-01-19 17:51:24 --> Helper loaded: form_helper
INFO - 2018-01-19 17:51:24 --> Database Driver Class Initialized
DEBUG - 2018-01-19 17:51:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 17:51:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 17:51:24 --> Form Validation Class Initialized
INFO - 2018-01-19 17:51:24 --> Model Class Initialized
INFO - 2018-01-19 17:51:24 --> Controller Class Initialized
INFO - 2018-01-19 17:51:24 --> Model Class Initialized
INFO - 2018-01-19 17:51:24 --> Model Class Initialized
INFO - 2018-01-19 17:51:24 --> Model Class Initialized
INFO - 2018-01-19 17:51:24 --> Model Class Initialized
DEBUG - 2018-01-19 17:51:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 17:52:12 --> Config Class Initialized
INFO - 2018-01-19 17:52:12 --> Hooks Class Initialized
DEBUG - 2018-01-19 17:52:12 --> UTF-8 Support Enabled
INFO - 2018-01-19 17:52:12 --> Utf8 Class Initialized
INFO - 2018-01-19 17:52:12 --> URI Class Initialized
INFO - 2018-01-19 17:52:12 --> Router Class Initialized
INFO - 2018-01-19 17:52:12 --> Output Class Initialized
INFO - 2018-01-19 17:52:12 --> Security Class Initialized
DEBUG - 2018-01-19 17:52:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 17:52:12 --> Input Class Initialized
INFO - 2018-01-19 17:52:12 --> Language Class Initialized
INFO - 2018-01-19 17:52:12 --> Loader Class Initialized
INFO - 2018-01-19 17:52:12 --> Helper loaded: url_helper
INFO - 2018-01-19 17:52:12 --> Helper loaded: form_helper
INFO - 2018-01-19 17:52:12 --> Database Driver Class Initialized
DEBUG - 2018-01-19 17:52:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 17:52:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 17:52:12 --> Form Validation Class Initialized
INFO - 2018-01-19 17:52:12 --> Model Class Initialized
INFO - 2018-01-19 17:52:12 --> Controller Class Initialized
INFO - 2018-01-19 17:52:12 --> Model Class Initialized
INFO - 2018-01-19 17:52:12 --> Model Class Initialized
INFO - 2018-01-19 17:52:12 --> Model Class Initialized
INFO - 2018-01-19 17:52:12 --> Model Class Initialized
DEBUG - 2018-01-19 17:52:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 17:52:12 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 17:52:12 --> Final output sent to browser
DEBUG - 2018-01-19 17:52:12 --> Total execution time: 0.0510
INFO - 2018-01-19 17:52:12 --> Config Class Initialized
INFO - 2018-01-19 17:52:12 --> Hooks Class Initialized
DEBUG - 2018-01-19 17:52:12 --> UTF-8 Support Enabled
INFO - 2018-01-19 17:52:12 --> Utf8 Class Initialized
INFO - 2018-01-19 17:52:12 --> URI Class Initialized
INFO - 2018-01-19 17:52:12 --> Router Class Initialized
INFO - 2018-01-19 17:52:12 --> Output Class Initialized
INFO - 2018-01-19 17:52:12 --> Security Class Initialized
DEBUG - 2018-01-19 17:52:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 17:52:12 --> Input Class Initialized
INFO - 2018-01-19 17:52:12 --> Language Class Initialized
INFO - 2018-01-19 17:52:12 --> Loader Class Initialized
INFO - 2018-01-19 17:52:12 --> Helper loaded: url_helper
INFO - 2018-01-19 17:52:12 --> Helper loaded: form_helper
INFO - 2018-01-19 17:52:12 --> Database Driver Class Initialized
DEBUG - 2018-01-19 17:52:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 17:52:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 17:52:12 --> Form Validation Class Initialized
INFO - 2018-01-19 17:52:12 --> Model Class Initialized
INFO - 2018-01-19 17:52:12 --> Controller Class Initialized
INFO - 2018-01-19 17:52:12 --> Model Class Initialized
INFO - 2018-01-19 17:52:12 --> Model Class Initialized
INFO - 2018-01-19 17:52:12 --> Model Class Initialized
INFO - 2018-01-19 17:52:12 --> Model Class Initialized
DEBUG - 2018-01-19 17:52:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 17:52:24 --> Config Class Initialized
INFO - 2018-01-19 17:52:24 --> Hooks Class Initialized
DEBUG - 2018-01-19 17:52:24 --> UTF-8 Support Enabled
INFO - 2018-01-19 17:52:24 --> Utf8 Class Initialized
INFO - 2018-01-19 17:52:24 --> URI Class Initialized
INFO - 2018-01-19 17:52:24 --> Router Class Initialized
INFO - 2018-01-19 17:52:24 --> Output Class Initialized
INFO - 2018-01-19 17:52:24 --> Security Class Initialized
DEBUG - 2018-01-19 17:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 17:52:24 --> Input Class Initialized
INFO - 2018-01-19 17:52:24 --> Language Class Initialized
INFO - 2018-01-19 17:52:24 --> Loader Class Initialized
INFO - 2018-01-19 17:52:24 --> Helper loaded: url_helper
INFO - 2018-01-19 17:52:24 --> Helper loaded: form_helper
INFO - 2018-01-19 17:52:24 --> Database Driver Class Initialized
DEBUG - 2018-01-19 17:52:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 17:52:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 17:52:24 --> Form Validation Class Initialized
INFO - 2018-01-19 17:52:24 --> Model Class Initialized
INFO - 2018-01-19 17:52:24 --> Controller Class Initialized
INFO - 2018-01-19 17:52:24 --> Model Class Initialized
INFO - 2018-01-19 17:52:24 --> Model Class Initialized
INFO - 2018-01-19 17:52:24 --> Model Class Initialized
INFO - 2018-01-19 17:52:24 --> Model Class Initialized
DEBUG - 2018-01-19 17:52:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 17:52:24 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 17:52:24 --> Final output sent to browser
DEBUG - 2018-01-19 17:52:24 --> Total execution time: 0.0525
INFO - 2018-01-19 17:52:42 --> Config Class Initialized
INFO - 2018-01-19 17:52:42 --> Hooks Class Initialized
DEBUG - 2018-01-19 17:52:42 --> UTF-8 Support Enabled
INFO - 2018-01-19 17:52:42 --> Utf8 Class Initialized
INFO - 2018-01-19 17:52:42 --> URI Class Initialized
INFO - 2018-01-19 17:52:42 --> Router Class Initialized
INFO - 2018-01-19 17:52:42 --> Output Class Initialized
INFO - 2018-01-19 17:52:42 --> Security Class Initialized
DEBUG - 2018-01-19 17:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 17:52:42 --> Input Class Initialized
INFO - 2018-01-19 17:52:42 --> Language Class Initialized
INFO - 2018-01-19 17:52:42 --> Loader Class Initialized
INFO - 2018-01-19 17:52:42 --> Helper loaded: url_helper
INFO - 2018-01-19 17:52:42 --> Helper loaded: form_helper
INFO - 2018-01-19 17:52:42 --> Database Driver Class Initialized
DEBUG - 2018-01-19 17:52:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 17:52:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 17:52:42 --> Form Validation Class Initialized
INFO - 2018-01-19 17:52:42 --> Model Class Initialized
INFO - 2018-01-19 17:52:42 --> Controller Class Initialized
INFO - 2018-01-19 17:52:42 --> Model Class Initialized
INFO - 2018-01-19 17:52:42 --> Model Class Initialized
INFO - 2018-01-19 17:52:42 --> Model Class Initialized
INFO - 2018-01-19 17:52:42 --> Model Class Initialized
DEBUG - 2018-01-19 17:52:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 17:52:42 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 17:52:42 --> Final output sent to browser
DEBUG - 2018-01-19 17:52:42 --> Total execution time: 0.0516
INFO - 2018-01-19 17:52:43 --> Config Class Initialized
INFO - 2018-01-19 17:52:43 --> Hooks Class Initialized
DEBUG - 2018-01-19 17:52:43 --> UTF-8 Support Enabled
INFO - 2018-01-19 17:52:43 --> Utf8 Class Initialized
INFO - 2018-01-19 17:52:43 --> URI Class Initialized
INFO - 2018-01-19 17:52:43 --> Router Class Initialized
INFO - 2018-01-19 17:52:43 --> Output Class Initialized
INFO - 2018-01-19 17:52:43 --> Security Class Initialized
DEBUG - 2018-01-19 17:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 17:52:43 --> Input Class Initialized
INFO - 2018-01-19 17:52:43 --> Language Class Initialized
INFO - 2018-01-19 17:52:43 --> Loader Class Initialized
INFO - 2018-01-19 17:52:43 --> Helper loaded: url_helper
INFO - 2018-01-19 17:52:43 --> Helper loaded: form_helper
INFO - 2018-01-19 17:52:43 --> Database Driver Class Initialized
DEBUG - 2018-01-19 17:52:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 17:52:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 17:52:43 --> Form Validation Class Initialized
INFO - 2018-01-19 17:52:43 --> Model Class Initialized
INFO - 2018-01-19 17:52:43 --> Controller Class Initialized
INFO - 2018-01-19 17:52:43 --> Model Class Initialized
INFO - 2018-01-19 17:52:43 --> Model Class Initialized
INFO - 2018-01-19 17:52:43 --> Model Class Initialized
INFO - 2018-01-19 17:52:43 --> Model Class Initialized
DEBUG - 2018-01-19 17:52:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 20:09:06 --> Config Class Initialized
INFO - 2018-01-19 20:09:06 --> Hooks Class Initialized
DEBUG - 2018-01-19 20:09:06 --> UTF-8 Support Enabled
INFO - 2018-01-19 20:09:06 --> Utf8 Class Initialized
INFO - 2018-01-19 20:09:06 --> URI Class Initialized
DEBUG - 2018-01-19 20:09:06 --> No URI present. Default controller set.
INFO - 2018-01-19 20:09:06 --> Router Class Initialized
INFO - 2018-01-19 20:09:06 --> Output Class Initialized
INFO - 2018-01-19 20:09:06 --> Security Class Initialized
DEBUG - 2018-01-19 20:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 20:09:06 --> Input Class Initialized
INFO - 2018-01-19 20:09:06 --> Language Class Initialized
INFO - 2018-01-19 20:09:06 --> Loader Class Initialized
INFO - 2018-01-19 20:09:06 --> Helper loaded: url_helper
INFO - 2018-01-19 20:09:06 --> Helper loaded: form_helper
INFO - 2018-01-19 20:09:06 --> Database Driver Class Initialized
DEBUG - 2018-01-19 20:09:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 20:09:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 20:09:06 --> Form Validation Class Initialized
INFO - 2018-01-19 20:09:06 --> Model Class Initialized
INFO - 2018-01-19 20:09:06 --> Controller Class Initialized
INFO - 2018-01-19 20:09:09 --> Config Class Initialized
INFO - 2018-01-19 20:09:09 --> Hooks Class Initialized
DEBUG - 2018-01-19 20:09:09 --> UTF-8 Support Enabled
INFO - 2018-01-19 20:09:09 --> Utf8 Class Initialized
INFO - 2018-01-19 20:09:09 --> URI Class Initialized
INFO - 2018-01-19 20:09:09 --> Router Class Initialized
INFO - 2018-01-19 20:09:09 --> Output Class Initialized
INFO - 2018-01-19 20:09:09 --> Security Class Initialized
DEBUG - 2018-01-19 20:09:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 20:09:09 --> Input Class Initialized
INFO - 2018-01-19 20:09:09 --> Language Class Initialized
INFO - 2018-01-19 20:09:09 --> Loader Class Initialized
INFO - 2018-01-19 20:09:09 --> Helper loaded: url_helper
INFO - 2018-01-19 20:09:09 --> Helper loaded: form_helper
INFO - 2018-01-19 20:09:09 --> Database Driver Class Initialized
DEBUG - 2018-01-19 20:09:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 20:09:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 20:09:09 --> Form Validation Class Initialized
INFO - 2018-01-19 20:09:09 --> Model Class Initialized
INFO - 2018-01-19 20:09:09 --> Controller Class Initialized
INFO - 2018-01-19 20:09:09 --> Model Class Initialized
DEBUG - 2018-01-19 20:09:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 20:09:09 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 20:09:09 --> Final output sent to browser
DEBUG - 2018-01-19 20:09:09 --> Total execution time: 0.0477
INFO - 2018-01-19 20:10:33 --> Config Class Initialized
INFO - 2018-01-19 20:10:33 --> Hooks Class Initialized
DEBUG - 2018-01-19 20:10:33 --> UTF-8 Support Enabled
INFO - 2018-01-19 20:10:33 --> Utf8 Class Initialized
INFO - 2018-01-19 20:10:33 --> URI Class Initialized
INFO - 2018-01-19 20:10:33 --> Router Class Initialized
INFO - 2018-01-19 20:10:33 --> Output Class Initialized
INFO - 2018-01-19 20:10:33 --> Security Class Initialized
DEBUG - 2018-01-19 20:10:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 20:10:33 --> Input Class Initialized
INFO - 2018-01-19 20:10:33 --> Language Class Initialized
INFO - 2018-01-19 20:10:33 --> Loader Class Initialized
INFO - 2018-01-19 20:10:33 --> Helper loaded: url_helper
INFO - 2018-01-19 20:10:33 --> Helper loaded: form_helper
INFO - 2018-01-19 20:10:33 --> Database Driver Class Initialized
DEBUG - 2018-01-19 20:10:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 20:10:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 20:10:33 --> Form Validation Class Initialized
INFO - 2018-01-19 20:10:33 --> Model Class Initialized
INFO - 2018-01-19 20:10:33 --> Controller Class Initialized
INFO - 2018-01-19 20:10:33 --> Model Class Initialized
DEBUG - 2018-01-19 20:10:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 20:10:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-01-19 20:10:34 --> Config Class Initialized
INFO - 2018-01-19 20:10:34 --> Hooks Class Initialized
DEBUG - 2018-01-19 20:10:34 --> UTF-8 Support Enabled
INFO - 2018-01-19 20:10:34 --> Utf8 Class Initialized
INFO - 2018-01-19 20:10:34 --> URI Class Initialized
DEBUG - 2018-01-19 20:10:34 --> No URI present. Default controller set.
INFO - 2018-01-19 20:10:34 --> Router Class Initialized
INFO - 2018-01-19 20:10:34 --> Output Class Initialized
INFO - 2018-01-19 20:10:34 --> Security Class Initialized
DEBUG - 2018-01-19 20:10:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 20:10:34 --> Input Class Initialized
INFO - 2018-01-19 20:10:34 --> Language Class Initialized
INFO - 2018-01-19 20:10:34 --> Loader Class Initialized
INFO - 2018-01-19 20:10:34 --> Helper loaded: url_helper
INFO - 2018-01-19 20:10:34 --> Helper loaded: form_helper
INFO - 2018-01-19 20:10:34 --> Database Driver Class Initialized
DEBUG - 2018-01-19 20:10:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 20:10:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 20:10:34 --> Form Validation Class Initialized
INFO - 2018-01-19 20:10:34 --> Model Class Initialized
INFO - 2018-01-19 20:10:34 --> Controller Class Initialized
INFO - 2018-01-19 20:10:34 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 20:10:34 --> Final output sent to browser
DEBUG - 2018-01-19 20:10:34 --> Total execution time: 0.0350
INFO - 2018-01-19 20:10:50 --> Config Class Initialized
INFO - 2018-01-19 20:10:50 --> Hooks Class Initialized
DEBUG - 2018-01-19 20:10:50 --> UTF-8 Support Enabled
INFO - 2018-01-19 20:10:50 --> Utf8 Class Initialized
INFO - 2018-01-19 20:10:50 --> URI Class Initialized
INFO - 2018-01-19 20:10:50 --> Router Class Initialized
INFO - 2018-01-19 20:10:50 --> Output Class Initialized
INFO - 2018-01-19 20:10:50 --> Security Class Initialized
DEBUG - 2018-01-19 20:10:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 20:10:50 --> Input Class Initialized
INFO - 2018-01-19 20:10:50 --> Language Class Initialized
INFO - 2018-01-19 20:10:50 --> Loader Class Initialized
INFO - 2018-01-19 20:10:50 --> Helper loaded: url_helper
INFO - 2018-01-19 20:10:50 --> Helper loaded: form_helper
INFO - 2018-01-19 20:10:50 --> Database Driver Class Initialized
DEBUG - 2018-01-19 20:10:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 20:10:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 20:10:50 --> Form Validation Class Initialized
INFO - 2018-01-19 20:10:50 --> Model Class Initialized
INFO - 2018-01-19 20:10:50 --> Controller Class Initialized
INFO - 2018-01-19 20:10:50 --> Model Class Initialized
INFO - 2018-01-19 20:10:50 --> Model Class Initialized
INFO - 2018-01-19 20:10:50 --> Model Class Initialized
INFO - 2018-01-19 20:10:50 --> Model Class Initialized
DEBUG - 2018-01-19 20:10:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 20:10:50 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 20:10:50 --> Final output sent to browser
DEBUG - 2018-01-19 20:10:50 --> Total execution time: 0.0473
INFO - 2018-01-19 20:10:51 --> Config Class Initialized
INFO - 2018-01-19 20:10:51 --> Hooks Class Initialized
DEBUG - 2018-01-19 20:10:51 --> UTF-8 Support Enabled
INFO - 2018-01-19 20:10:51 --> Utf8 Class Initialized
INFO - 2018-01-19 20:10:51 --> URI Class Initialized
INFO - 2018-01-19 20:10:51 --> Router Class Initialized
INFO - 2018-01-19 20:10:51 --> Output Class Initialized
INFO - 2018-01-19 20:10:51 --> Security Class Initialized
DEBUG - 2018-01-19 20:10:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 20:10:51 --> Input Class Initialized
INFO - 2018-01-19 20:10:51 --> Language Class Initialized
INFO - 2018-01-19 20:10:51 --> Loader Class Initialized
INFO - 2018-01-19 20:10:51 --> Helper loaded: url_helper
INFO - 2018-01-19 20:10:51 --> Helper loaded: form_helper
INFO - 2018-01-19 20:10:51 --> Database Driver Class Initialized
DEBUG - 2018-01-19 20:10:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 20:10:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 20:10:51 --> Form Validation Class Initialized
INFO - 2018-01-19 20:10:51 --> Model Class Initialized
INFO - 2018-01-19 20:10:51 --> Controller Class Initialized
INFO - 2018-01-19 20:10:51 --> Model Class Initialized
INFO - 2018-01-19 20:10:51 --> Model Class Initialized
INFO - 2018-01-19 20:10:51 --> Model Class Initialized
INFO - 2018-01-19 20:10:51 --> Model Class Initialized
DEBUG - 2018-01-19 20:10:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 20:11:06 --> Config Class Initialized
INFO - 2018-01-19 20:11:06 --> Hooks Class Initialized
DEBUG - 2018-01-19 20:11:06 --> UTF-8 Support Enabled
INFO - 2018-01-19 20:11:06 --> Utf8 Class Initialized
INFO - 2018-01-19 20:11:06 --> URI Class Initialized
INFO - 2018-01-19 20:11:06 --> Router Class Initialized
INFO - 2018-01-19 20:11:06 --> Output Class Initialized
INFO - 2018-01-19 20:11:06 --> Security Class Initialized
DEBUG - 2018-01-19 20:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 20:11:06 --> Input Class Initialized
INFO - 2018-01-19 20:11:06 --> Language Class Initialized
INFO - 2018-01-19 20:11:06 --> Loader Class Initialized
INFO - 2018-01-19 20:11:06 --> Helper loaded: url_helper
INFO - 2018-01-19 20:11:06 --> Helper loaded: form_helper
INFO - 2018-01-19 20:11:06 --> Database Driver Class Initialized
DEBUG - 2018-01-19 20:11:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 20:11:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 20:11:07 --> Form Validation Class Initialized
INFO - 2018-01-19 20:11:07 --> Model Class Initialized
INFO - 2018-01-19 20:11:07 --> Controller Class Initialized
INFO - 2018-01-19 20:11:07 --> Model Class Initialized
INFO - 2018-01-19 20:11:07 --> Model Class Initialized
INFO - 2018-01-19 20:11:07 --> Model Class Initialized
INFO - 2018-01-19 20:11:07 --> Model Class Initialized
DEBUG - 2018-01-19 20:11:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 20:11:07 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 20:11:07 --> Final output sent to browser
DEBUG - 2018-01-19 20:11:07 --> Total execution time: 1.2336
INFO - 2018-01-19 20:11:08 --> Config Class Initialized
INFO - 2018-01-19 20:11:08 --> Hooks Class Initialized
DEBUG - 2018-01-19 20:11:08 --> UTF-8 Support Enabled
INFO - 2018-01-19 20:11:08 --> Utf8 Class Initialized
INFO - 2018-01-19 20:11:08 --> URI Class Initialized
INFO - 2018-01-19 20:11:08 --> Router Class Initialized
INFO - 2018-01-19 20:11:08 --> Output Class Initialized
INFO - 2018-01-19 20:11:08 --> Security Class Initialized
DEBUG - 2018-01-19 20:11:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 20:11:08 --> Input Class Initialized
INFO - 2018-01-19 20:11:08 --> Language Class Initialized
INFO - 2018-01-19 20:11:08 --> Loader Class Initialized
INFO - 2018-01-19 20:11:08 --> Helper loaded: url_helper
INFO - 2018-01-19 20:11:08 --> Helper loaded: form_helper
INFO - 2018-01-19 20:11:08 --> Database Driver Class Initialized
DEBUG - 2018-01-19 20:11:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 20:11:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 20:11:08 --> Form Validation Class Initialized
INFO - 2018-01-19 20:11:08 --> Model Class Initialized
INFO - 2018-01-19 20:11:08 --> Controller Class Initialized
INFO - 2018-01-19 20:11:08 --> Model Class Initialized
INFO - 2018-01-19 20:11:08 --> Model Class Initialized
INFO - 2018-01-19 20:11:08 --> Model Class Initialized
INFO - 2018-01-19 20:11:08 --> Model Class Initialized
DEBUG - 2018-01-19 20:11:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 20:31:03 --> Config Class Initialized
INFO - 2018-01-19 20:31:03 --> Hooks Class Initialized
DEBUG - 2018-01-19 20:31:03 --> UTF-8 Support Enabled
INFO - 2018-01-19 20:31:03 --> Utf8 Class Initialized
INFO - 2018-01-19 20:31:03 --> URI Class Initialized
INFO - 2018-01-19 20:31:03 --> Router Class Initialized
INFO - 2018-01-19 20:31:03 --> Output Class Initialized
INFO - 2018-01-19 20:31:03 --> Security Class Initialized
DEBUG - 2018-01-19 20:31:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 20:31:03 --> Input Class Initialized
INFO - 2018-01-19 20:31:03 --> Language Class Initialized
INFO - 2018-01-19 20:31:03 --> Loader Class Initialized
INFO - 2018-01-19 20:31:03 --> Helper loaded: url_helper
INFO - 2018-01-19 20:31:03 --> Helper loaded: form_helper
INFO - 2018-01-19 20:31:03 --> Database Driver Class Initialized
DEBUG - 2018-01-19 20:31:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 20:31:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 20:31:03 --> Form Validation Class Initialized
INFO - 2018-01-19 20:31:03 --> Model Class Initialized
INFO - 2018-01-19 20:31:03 --> Controller Class Initialized
INFO - 2018-01-19 20:31:03 --> Model Class Initialized
INFO - 2018-01-19 20:31:03 --> Model Class Initialized
INFO - 2018-01-19 20:31:03 --> Model Class Initialized
INFO - 2018-01-19 20:31:03 --> Model Class Initialized
DEBUG - 2018-01-19 20:31:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 20:31:03 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 20:31:03 --> Final output sent to browser
DEBUG - 2018-01-19 20:31:03 --> Total execution time: 0.0612
INFO - 2018-01-19 20:31:04 --> Config Class Initialized
INFO - 2018-01-19 20:31:04 --> Hooks Class Initialized
DEBUG - 2018-01-19 20:31:04 --> UTF-8 Support Enabled
INFO - 2018-01-19 20:31:04 --> Utf8 Class Initialized
INFO - 2018-01-19 20:31:04 --> URI Class Initialized
INFO - 2018-01-19 20:31:04 --> Router Class Initialized
INFO - 2018-01-19 20:31:04 --> Output Class Initialized
INFO - 2018-01-19 20:31:05 --> Security Class Initialized
DEBUG - 2018-01-19 20:31:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 20:31:05 --> Input Class Initialized
INFO - 2018-01-19 20:31:05 --> Language Class Initialized
INFO - 2018-01-19 20:31:05 --> Loader Class Initialized
INFO - 2018-01-19 20:31:05 --> Helper loaded: url_helper
INFO - 2018-01-19 20:31:05 --> Helper loaded: form_helper
INFO - 2018-01-19 20:31:05 --> Database Driver Class Initialized
DEBUG - 2018-01-19 20:31:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 20:31:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 20:31:05 --> Form Validation Class Initialized
INFO - 2018-01-19 20:31:05 --> Model Class Initialized
INFO - 2018-01-19 20:31:05 --> Controller Class Initialized
INFO - 2018-01-19 20:31:05 --> Model Class Initialized
INFO - 2018-01-19 20:31:05 --> Model Class Initialized
INFO - 2018-01-19 20:31:05 --> Model Class Initialized
INFO - 2018-01-19 20:31:05 --> Model Class Initialized
DEBUG - 2018-01-19 20:31:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 20:31:37 --> Config Class Initialized
INFO - 2018-01-19 20:31:37 --> Hooks Class Initialized
DEBUG - 2018-01-19 20:31:37 --> UTF-8 Support Enabled
INFO - 2018-01-19 20:31:37 --> Utf8 Class Initialized
INFO - 2018-01-19 20:31:37 --> URI Class Initialized
INFO - 2018-01-19 20:31:37 --> Router Class Initialized
INFO - 2018-01-19 20:31:37 --> Output Class Initialized
INFO - 2018-01-19 20:31:37 --> Security Class Initialized
DEBUG - 2018-01-19 20:31:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 20:31:37 --> Input Class Initialized
INFO - 2018-01-19 20:31:37 --> Language Class Initialized
INFO - 2018-01-19 20:31:37 --> Loader Class Initialized
INFO - 2018-01-19 20:31:37 --> Helper loaded: url_helper
INFO - 2018-01-19 20:31:37 --> Helper loaded: form_helper
INFO - 2018-01-19 20:31:37 --> Database Driver Class Initialized
DEBUG - 2018-01-19 20:31:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 20:31:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 20:31:37 --> Form Validation Class Initialized
INFO - 2018-01-19 20:31:37 --> Model Class Initialized
INFO - 2018-01-19 20:31:37 --> Controller Class Initialized
INFO - 2018-01-19 20:31:37 --> Model Class Initialized
INFO - 2018-01-19 20:31:37 --> Model Class Initialized
INFO - 2018-01-19 20:31:37 --> Model Class Initialized
INFO - 2018-01-19 20:31:37 --> Model Class Initialized
DEBUG - 2018-01-19 20:31:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 20:31:37 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 20:31:37 --> Final output sent to browser
DEBUG - 2018-01-19 20:31:37 --> Total execution time: 0.0549
INFO - 2018-01-19 20:32:43 --> Config Class Initialized
INFO - 2018-01-19 20:32:43 --> Hooks Class Initialized
DEBUG - 2018-01-19 20:32:43 --> UTF-8 Support Enabled
INFO - 2018-01-19 20:32:43 --> Utf8 Class Initialized
INFO - 2018-01-19 20:32:43 --> URI Class Initialized
INFO - 2018-01-19 20:32:43 --> Router Class Initialized
INFO - 2018-01-19 20:32:43 --> Output Class Initialized
INFO - 2018-01-19 20:32:43 --> Security Class Initialized
DEBUG - 2018-01-19 20:32:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 20:32:43 --> Input Class Initialized
INFO - 2018-01-19 20:32:43 --> Language Class Initialized
INFO - 2018-01-19 20:32:43 --> Loader Class Initialized
INFO - 2018-01-19 20:32:43 --> Helper loaded: url_helper
INFO - 2018-01-19 20:32:43 --> Helper loaded: form_helper
INFO - 2018-01-19 20:32:43 --> Database Driver Class Initialized
DEBUG - 2018-01-19 20:32:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 20:32:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 20:32:43 --> Form Validation Class Initialized
INFO - 2018-01-19 20:32:43 --> Model Class Initialized
INFO - 2018-01-19 20:32:43 --> Controller Class Initialized
INFO - 2018-01-19 20:32:43 --> Model Class Initialized
INFO - 2018-01-19 20:32:43 --> Model Class Initialized
INFO - 2018-01-19 20:32:43 --> Model Class Initialized
INFO - 2018-01-19 20:32:43 --> Model Class Initialized
DEBUG - 2018-01-19 20:32:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 20:32:43 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 20:32:43 --> Final output sent to browser
DEBUG - 2018-01-19 20:32:43 --> Total execution time: 0.0497
INFO - 2018-01-19 20:32:44 --> Config Class Initialized
INFO - 2018-01-19 20:32:44 --> Hooks Class Initialized
DEBUG - 2018-01-19 20:32:44 --> UTF-8 Support Enabled
INFO - 2018-01-19 20:32:44 --> Utf8 Class Initialized
INFO - 2018-01-19 20:32:44 --> URI Class Initialized
INFO - 2018-01-19 20:32:44 --> Router Class Initialized
INFO - 2018-01-19 20:32:44 --> Output Class Initialized
INFO - 2018-01-19 20:32:44 --> Security Class Initialized
DEBUG - 2018-01-19 20:32:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 20:32:44 --> Input Class Initialized
INFO - 2018-01-19 20:32:44 --> Language Class Initialized
INFO - 2018-01-19 20:32:44 --> Loader Class Initialized
INFO - 2018-01-19 20:32:44 --> Helper loaded: url_helper
INFO - 2018-01-19 20:32:44 --> Helper loaded: form_helper
INFO - 2018-01-19 20:32:44 --> Database Driver Class Initialized
DEBUG - 2018-01-19 20:32:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 20:32:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 20:32:44 --> Form Validation Class Initialized
INFO - 2018-01-19 20:32:44 --> Model Class Initialized
INFO - 2018-01-19 20:32:44 --> Controller Class Initialized
INFO - 2018-01-19 20:32:44 --> Model Class Initialized
INFO - 2018-01-19 20:32:44 --> Model Class Initialized
INFO - 2018-01-19 20:32:44 --> Model Class Initialized
INFO - 2018-01-19 20:32:44 --> Model Class Initialized
DEBUG - 2018-01-19 20:32:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 20:32:50 --> Config Class Initialized
INFO - 2018-01-19 20:32:50 --> Hooks Class Initialized
DEBUG - 2018-01-19 20:32:50 --> UTF-8 Support Enabled
INFO - 2018-01-19 20:32:50 --> Utf8 Class Initialized
INFO - 2018-01-19 20:32:50 --> URI Class Initialized
INFO - 2018-01-19 20:32:50 --> Router Class Initialized
INFO - 2018-01-19 20:32:50 --> Output Class Initialized
INFO - 2018-01-19 20:32:50 --> Security Class Initialized
DEBUG - 2018-01-19 20:32:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 20:32:50 --> Input Class Initialized
INFO - 2018-01-19 20:32:50 --> Language Class Initialized
INFO - 2018-01-19 20:32:50 --> Loader Class Initialized
INFO - 2018-01-19 20:32:50 --> Helper loaded: url_helper
INFO - 2018-01-19 20:32:50 --> Helper loaded: form_helper
INFO - 2018-01-19 20:32:50 --> Database Driver Class Initialized
DEBUG - 2018-01-19 20:32:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 20:32:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 20:32:50 --> Form Validation Class Initialized
INFO - 2018-01-19 20:32:50 --> Model Class Initialized
INFO - 2018-01-19 20:32:50 --> Controller Class Initialized
INFO - 2018-01-19 20:32:50 --> Model Class Initialized
INFO - 2018-01-19 20:32:50 --> Model Class Initialized
INFO - 2018-01-19 20:32:50 --> Model Class Initialized
INFO - 2018-01-19 20:32:50 --> Model Class Initialized
DEBUG - 2018-01-19 20:32:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 20:32:50 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 20:32:50 --> Final output sent to browser
DEBUG - 2018-01-19 20:32:50 --> Total execution time: 0.0535
INFO - 2018-01-19 20:32:52 --> Config Class Initialized
INFO - 2018-01-19 20:32:52 --> Hooks Class Initialized
DEBUG - 2018-01-19 20:32:52 --> UTF-8 Support Enabled
INFO - 2018-01-19 20:32:52 --> Utf8 Class Initialized
INFO - 2018-01-19 20:32:52 --> URI Class Initialized
INFO - 2018-01-19 20:32:52 --> Router Class Initialized
INFO - 2018-01-19 20:32:52 --> Output Class Initialized
INFO - 2018-01-19 20:32:52 --> Security Class Initialized
DEBUG - 2018-01-19 20:32:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 20:32:52 --> Input Class Initialized
INFO - 2018-01-19 20:32:52 --> Language Class Initialized
INFO - 2018-01-19 20:32:52 --> Loader Class Initialized
INFO - 2018-01-19 20:32:52 --> Helper loaded: url_helper
INFO - 2018-01-19 20:32:52 --> Helper loaded: form_helper
INFO - 2018-01-19 20:32:52 --> Database Driver Class Initialized
DEBUG - 2018-01-19 20:32:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 20:32:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 20:32:52 --> Form Validation Class Initialized
INFO - 2018-01-19 20:32:52 --> Model Class Initialized
INFO - 2018-01-19 20:32:52 --> Controller Class Initialized
INFO - 2018-01-19 20:32:52 --> Model Class Initialized
INFO - 2018-01-19 20:32:52 --> Model Class Initialized
INFO - 2018-01-19 20:32:52 --> Model Class Initialized
INFO - 2018-01-19 20:32:52 --> Model Class Initialized
DEBUG - 2018-01-19 20:32:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 20:33:03 --> Config Class Initialized
INFO - 2018-01-19 20:33:03 --> Hooks Class Initialized
DEBUG - 2018-01-19 20:33:03 --> UTF-8 Support Enabled
INFO - 2018-01-19 20:33:03 --> Utf8 Class Initialized
INFO - 2018-01-19 20:33:03 --> URI Class Initialized
INFO - 2018-01-19 20:33:03 --> Router Class Initialized
INFO - 2018-01-19 20:33:03 --> Output Class Initialized
INFO - 2018-01-19 20:33:03 --> Security Class Initialized
DEBUG - 2018-01-19 20:33:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 20:33:03 --> Input Class Initialized
INFO - 2018-01-19 20:33:03 --> Language Class Initialized
INFO - 2018-01-19 20:33:03 --> Loader Class Initialized
INFO - 2018-01-19 20:33:03 --> Helper loaded: url_helper
INFO - 2018-01-19 20:33:03 --> Helper loaded: form_helper
INFO - 2018-01-19 20:33:03 --> Database Driver Class Initialized
DEBUG - 2018-01-19 20:33:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 20:33:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 20:33:03 --> Form Validation Class Initialized
INFO - 2018-01-19 20:33:03 --> Model Class Initialized
INFO - 2018-01-19 20:33:03 --> Controller Class Initialized
INFO - 2018-01-19 20:33:03 --> Model Class Initialized
INFO - 2018-01-19 20:33:03 --> Model Class Initialized
INFO - 2018-01-19 20:33:03 --> Model Class Initialized
INFO - 2018-01-19 20:33:03 --> Model Class Initialized
DEBUG - 2018-01-19 20:33:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 20:33:04 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 20:33:04 --> Final output sent to browser
DEBUG - 2018-01-19 20:33:04 --> Total execution time: 0.9858
INFO - 2018-01-19 20:33:04 --> Config Class Initialized
INFO - 2018-01-19 20:33:04 --> Hooks Class Initialized
DEBUG - 2018-01-19 20:33:04 --> UTF-8 Support Enabled
INFO - 2018-01-19 20:33:04 --> Utf8 Class Initialized
INFO - 2018-01-19 20:33:04 --> URI Class Initialized
INFO - 2018-01-19 20:33:04 --> Router Class Initialized
INFO - 2018-01-19 20:33:04 --> Output Class Initialized
INFO - 2018-01-19 20:33:04 --> Security Class Initialized
DEBUG - 2018-01-19 20:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 20:33:04 --> Input Class Initialized
INFO - 2018-01-19 20:33:04 --> Language Class Initialized
INFO - 2018-01-19 20:33:04 --> Loader Class Initialized
INFO - 2018-01-19 20:33:04 --> Helper loaded: url_helper
INFO - 2018-01-19 20:33:04 --> Helper loaded: form_helper
INFO - 2018-01-19 20:33:04 --> Database Driver Class Initialized
DEBUG - 2018-01-19 20:33:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 20:33:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 20:33:04 --> Form Validation Class Initialized
INFO - 2018-01-19 20:33:04 --> Model Class Initialized
INFO - 2018-01-19 20:33:04 --> Controller Class Initialized
INFO - 2018-01-19 20:33:04 --> Model Class Initialized
INFO - 2018-01-19 20:33:04 --> Model Class Initialized
INFO - 2018-01-19 20:33:04 --> Model Class Initialized
INFO - 2018-01-19 20:33:04 --> Model Class Initialized
DEBUG - 2018-01-19 20:33:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 20:33:10 --> Config Class Initialized
INFO - 2018-01-19 20:33:10 --> Hooks Class Initialized
DEBUG - 2018-01-19 20:33:10 --> UTF-8 Support Enabled
INFO - 2018-01-19 20:33:10 --> Utf8 Class Initialized
INFO - 2018-01-19 20:33:10 --> URI Class Initialized
INFO - 2018-01-19 20:33:10 --> Router Class Initialized
INFO - 2018-01-19 20:33:10 --> Output Class Initialized
INFO - 2018-01-19 20:33:11 --> Security Class Initialized
DEBUG - 2018-01-19 20:33:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 20:33:11 --> Input Class Initialized
INFO - 2018-01-19 20:33:11 --> Language Class Initialized
INFO - 2018-01-19 20:33:11 --> Loader Class Initialized
INFO - 2018-01-19 20:33:11 --> Helper loaded: url_helper
INFO - 2018-01-19 20:33:11 --> Helper loaded: form_helper
INFO - 2018-01-19 20:33:11 --> Database Driver Class Initialized
DEBUG - 2018-01-19 20:33:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 20:33:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 20:33:11 --> Form Validation Class Initialized
INFO - 2018-01-19 20:33:11 --> Model Class Initialized
INFO - 2018-01-19 20:33:11 --> Controller Class Initialized
INFO - 2018-01-19 20:33:11 --> Model Class Initialized
INFO - 2018-01-19 20:33:11 --> Model Class Initialized
INFO - 2018-01-19 20:33:11 --> Model Class Initialized
INFO - 2018-01-19 20:33:11 --> Model Class Initialized
DEBUG - 2018-01-19 20:33:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 20:33:11 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 20:33:11 --> Final output sent to browser
DEBUG - 2018-01-19 20:33:11 --> Total execution time: 0.0499
INFO - 2018-01-19 20:33:27 --> Config Class Initialized
INFO - 2018-01-19 20:33:27 --> Hooks Class Initialized
DEBUG - 2018-01-19 20:33:27 --> UTF-8 Support Enabled
INFO - 2018-01-19 20:33:27 --> Utf8 Class Initialized
INFO - 2018-01-19 20:33:27 --> URI Class Initialized
INFO - 2018-01-19 20:33:27 --> Router Class Initialized
INFO - 2018-01-19 20:33:27 --> Output Class Initialized
INFO - 2018-01-19 20:33:27 --> Security Class Initialized
DEBUG - 2018-01-19 20:33:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 20:33:27 --> Input Class Initialized
INFO - 2018-01-19 20:33:27 --> Language Class Initialized
INFO - 2018-01-19 20:33:27 --> Loader Class Initialized
INFO - 2018-01-19 20:33:27 --> Helper loaded: url_helper
INFO - 2018-01-19 20:33:27 --> Helper loaded: form_helper
INFO - 2018-01-19 20:33:27 --> Database Driver Class Initialized
DEBUG - 2018-01-19 20:33:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 20:33:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 20:33:27 --> Form Validation Class Initialized
INFO - 2018-01-19 20:33:27 --> Model Class Initialized
INFO - 2018-01-19 20:33:27 --> Controller Class Initialized
INFO - 2018-01-19 20:33:27 --> Model Class Initialized
INFO - 2018-01-19 20:33:27 --> Model Class Initialized
INFO - 2018-01-19 20:33:27 --> Model Class Initialized
INFO - 2018-01-19 20:33:27 --> Model Class Initialized
DEBUG - 2018-01-19 20:33:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 20:33:27 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 20:33:27 --> Final output sent to browser
DEBUG - 2018-01-19 20:33:27 --> Total execution time: 0.0538
INFO - 2018-01-19 20:33:27 --> Config Class Initialized
INFO - 2018-01-19 20:33:27 --> Hooks Class Initialized
DEBUG - 2018-01-19 20:33:27 --> UTF-8 Support Enabled
INFO - 2018-01-19 20:33:27 --> Utf8 Class Initialized
INFO - 2018-01-19 20:33:27 --> URI Class Initialized
INFO - 2018-01-19 20:33:27 --> Router Class Initialized
INFO - 2018-01-19 20:33:27 --> Output Class Initialized
INFO - 2018-01-19 20:33:27 --> Security Class Initialized
DEBUG - 2018-01-19 20:33:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 20:33:27 --> Input Class Initialized
INFO - 2018-01-19 20:33:27 --> Language Class Initialized
INFO - 2018-01-19 20:33:27 --> Loader Class Initialized
INFO - 2018-01-19 20:33:27 --> Helper loaded: url_helper
INFO - 2018-01-19 20:33:27 --> Helper loaded: form_helper
INFO - 2018-01-19 20:33:27 --> Database Driver Class Initialized
DEBUG - 2018-01-19 20:33:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 20:33:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 20:33:27 --> Form Validation Class Initialized
INFO - 2018-01-19 20:33:27 --> Model Class Initialized
INFO - 2018-01-19 20:33:27 --> Controller Class Initialized
INFO - 2018-01-19 20:33:27 --> Model Class Initialized
INFO - 2018-01-19 20:33:27 --> Model Class Initialized
INFO - 2018-01-19 20:33:27 --> Model Class Initialized
INFO - 2018-01-19 20:33:27 --> Model Class Initialized
DEBUG - 2018-01-19 20:33:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 20:33:27 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 20:33:27 --> Final output sent to browser
DEBUG - 2018-01-19 20:33:27 --> Total execution time: 0.0509
INFO - 2018-01-19 20:33:28 --> Config Class Initialized
INFO - 2018-01-19 20:33:28 --> Hooks Class Initialized
DEBUG - 2018-01-19 20:33:28 --> UTF-8 Support Enabled
INFO - 2018-01-19 20:33:28 --> Utf8 Class Initialized
INFO - 2018-01-19 20:33:28 --> URI Class Initialized
INFO - 2018-01-19 20:33:28 --> Router Class Initialized
INFO - 2018-01-19 20:33:28 --> Output Class Initialized
INFO - 2018-01-19 20:33:28 --> Security Class Initialized
DEBUG - 2018-01-19 20:33:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 20:33:28 --> Input Class Initialized
INFO - 2018-01-19 20:33:28 --> Language Class Initialized
INFO - 2018-01-19 20:33:28 --> Loader Class Initialized
INFO - 2018-01-19 20:33:28 --> Helper loaded: url_helper
INFO - 2018-01-19 20:33:28 --> Helper loaded: form_helper
INFO - 2018-01-19 20:33:28 --> Database Driver Class Initialized
DEBUG - 2018-01-19 20:33:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 20:33:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 20:33:28 --> Form Validation Class Initialized
INFO - 2018-01-19 20:33:28 --> Model Class Initialized
INFO - 2018-01-19 20:33:28 --> Controller Class Initialized
INFO - 2018-01-19 20:33:28 --> Model Class Initialized
INFO - 2018-01-19 20:33:28 --> Model Class Initialized
INFO - 2018-01-19 20:33:28 --> Model Class Initialized
INFO - 2018-01-19 20:33:28 --> Model Class Initialized
DEBUG - 2018-01-19 20:33:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 20:33:29 --> Config Class Initialized
INFO - 2018-01-19 20:33:29 --> Hooks Class Initialized
DEBUG - 2018-01-19 20:33:29 --> UTF-8 Support Enabled
INFO - 2018-01-19 20:33:29 --> Utf8 Class Initialized
INFO - 2018-01-19 20:33:29 --> URI Class Initialized
INFO - 2018-01-19 20:33:29 --> Router Class Initialized
INFO - 2018-01-19 20:33:29 --> Output Class Initialized
INFO - 2018-01-19 20:33:29 --> Security Class Initialized
DEBUG - 2018-01-19 20:33:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 20:33:29 --> Input Class Initialized
INFO - 2018-01-19 20:33:29 --> Language Class Initialized
INFO - 2018-01-19 20:33:29 --> Loader Class Initialized
INFO - 2018-01-19 20:33:29 --> Helper loaded: url_helper
INFO - 2018-01-19 20:33:29 --> Helper loaded: form_helper
INFO - 2018-01-19 20:33:29 --> Database Driver Class Initialized
DEBUG - 2018-01-19 20:33:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 20:33:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 20:33:29 --> Form Validation Class Initialized
INFO - 2018-01-19 20:33:29 --> Model Class Initialized
INFO - 2018-01-19 20:33:29 --> Controller Class Initialized
INFO - 2018-01-19 20:33:29 --> Model Class Initialized
INFO - 2018-01-19 20:33:29 --> Model Class Initialized
INFO - 2018-01-19 20:33:29 --> Model Class Initialized
INFO - 2018-01-19 20:33:29 --> Model Class Initialized
DEBUG - 2018-01-19 20:33:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 20:33:29 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 20:33:29 --> Final output sent to browser
DEBUG - 2018-01-19 20:33:29 --> Total execution time: 0.0520
INFO - 2018-01-19 20:33:30 --> Config Class Initialized
INFO - 2018-01-19 20:33:30 --> Hooks Class Initialized
DEBUG - 2018-01-19 20:33:30 --> UTF-8 Support Enabled
INFO - 2018-01-19 20:33:30 --> Utf8 Class Initialized
INFO - 2018-01-19 20:33:30 --> URI Class Initialized
INFO - 2018-01-19 20:33:30 --> Router Class Initialized
INFO - 2018-01-19 20:33:30 --> Output Class Initialized
INFO - 2018-01-19 20:33:30 --> Security Class Initialized
DEBUG - 2018-01-19 20:33:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 20:33:30 --> Input Class Initialized
INFO - 2018-01-19 20:33:30 --> Language Class Initialized
INFO - 2018-01-19 20:33:30 --> Loader Class Initialized
INFO - 2018-01-19 20:33:30 --> Helper loaded: url_helper
INFO - 2018-01-19 20:33:30 --> Helper loaded: form_helper
INFO - 2018-01-19 20:33:30 --> Database Driver Class Initialized
DEBUG - 2018-01-19 20:33:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 20:33:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 20:33:30 --> Form Validation Class Initialized
INFO - 2018-01-19 20:33:30 --> Model Class Initialized
INFO - 2018-01-19 20:33:30 --> Controller Class Initialized
INFO - 2018-01-19 20:33:30 --> Model Class Initialized
INFO - 2018-01-19 20:33:30 --> Model Class Initialized
INFO - 2018-01-19 20:33:30 --> Model Class Initialized
INFO - 2018-01-19 20:33:30 --> Model Class Initialized
DEBUG - 2018-01-19 20:33:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 20:33:31 --> Config Class Initialized
INFO - 2018-01-19 20:33:31 --> Hooks Class Initialized
DEBUG - 2018-01-19 20:33:31 --> UTF-8 Support Enabled
INFO - 2018-01-19 20:33:31 --> Utf8 Class Initialized
INFO - 2018-01-19 20:33:31 --> URI Class Initialized
INFO - 2018-01-19 20:33:31 --> Router Class Initialized
INFO - 2018-01-19 20:33:31 --> Output Class Initialized
INFO - 2018-01-19 20:33:31 --> Security Class Initialized
DEBUG - 2018-01-19 20:33:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 20:33:31 --> Input Class Initialized
INFO - 2018-01-19 20:33:31 --> Language Class Initialized
INFO - 2018-01-19 20:33:31 --> Loader Class Initialized
INFO - 2018-01-19 20:33:31 --> Helper loaded: url_helper
INFO - 2018-01-19 20:33:31 --> Helper loaded: form_helper
INFO - 2018-01-19 20:33:31 --> Database Driver Class Initialized
DEBUG - 2018-01-19 20:33:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 20:33:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 20:33:31 --> Form Validation Class Initialized
INFO - 2018-01-19 20:33:31 --> Model Class Initialized
INFO - 2018-01-19 20:33:31 --> Controller Class Initialized
INFO - 2018-01-19 20:33:31 --> Model Class Initialized
INFO - 2018-01-19 20:33:31 --> Model Class Initialized
INFO - 2018-01-19 20:33:31 --> Model Class Initialized
INFO - 2018-01-19 20:33:31 --> Model Class Initialized
DEBUG - 2018-01-19 20:33:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 20:33:31 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 20:33:31 --> Final output sent to browser
DEBUG - 2018-01-19 20:33:31 --> Total execution time: 0.0508
INFO - 2018-01-19 20:33:32 --> Config Class Initialized
INFO - 2018-01-19 20:33:32 --> Hooks Class Initialized
DEBUG - 2018-01-19 20:33:32 --> UTF-8 Support Enabled
INFO - 2018-01-19 20:33:32 --> Utf8 Class Initialized
INFO - 2018-01-19 20:33:32 --> URI Class Initialized
INFO - 2018-01-19 20:33:32 --> Router Class Initialized
INFO - 2018-01-19 20:33:32 --> Output Class Initialized
INFO - 2018-01-19 20:33:32 --> Security Class Initialized
DEBUG - 2018-01-19 20:33:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 20:33:32 --> Input Class Initialized
INFO - 2018-01-19 20:33:32 --> Language Class Initialized
INFO - 2018-01-19 20:33:32 --> Loader Class Initialized
INFO - 2018-01-19 20:33:32 --> Helper loaded: url_helper
INFO - 2018-01-19 20:33:32 --> Helper loaded: form_helper
INFO - 2018-01-19 20:33:32 --> Database Driver Class Initialized
DEBUG - 2018-01-19 20:33:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 20:33:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 20:33:32 --> Form Validation Class Initialized
INFO - 2018-01-19 20:33:32 --> Model Class Initialized
INFO - 2018-01-19 20:33:32 --> Controller Class Initialized
INFO - 2018-01-19 20:33:32 --> Model Class Initialized
INFO - 2018-01-19 20:33:32 --> Model Class Initialized
INFO - 2018-01-19 20:33:32 --> Model Class Initialized
INFO - 2018-01-19 20:33:32 --> Model Class Initialized
DEBUG - 2018-01-19 20:33:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 20:33:32 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 20:33:32 --> Final output sent to browser
DEBUG - 2018-01-19 20:33:32 --> Total execution time: 0.0674
INFO - 2018-01-19 20:33:32 --> Config Class Initialized
INFO - 2018-01-19 20:33:32 --> Hooks Class Initialized
DEBUG - 2018-01-19 20:33:32 --> UTF-8 Support Enabled
INFO - 2018-01-19 20:33:32 --> Utf8 Class Initialized
INFO - 2018-01-19 20:33:32 --> URI Class Initialized
INFO - 2018-01-19 20:33:32 --> Router Class Initialized
INFO - 2018-01-19 20:33:32 --> Output Class Initialized
INFO - 2018-01-19 20:33:32 --> Security Class Initialized
DEBUG - 2018-01-19 20:33:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 20:33:32 --> Input Class Initialized
INFO - 2018-01-19 20:33:32 --> Language Class Initialized
INFO - 2018-01-19 20:33:32 --> Loader Class Initialized
INFO - 2018-01-19 20:33:32 --> Helper loaded: url_helper
INFO - 2018-01-19 20:33:32 --> Helper loaded: form_helper
INFO - 2018-01-19 20:33:32 --> Database Driver Class Initialized
DEBUG - 2018-01-19 20:33:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 20:33:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 20:33:32 --> Form Validation Class Initialized
INFO - 2018-01-19 20:33:32 --> Model Class Initialized
INFO - 2018-01-19 20:33:32 --> Controller Class Initialized
INFO - 2018-01-19 20:33:32 --> Model Class Initialized
INFO - 2018-01-19 20:33:32 --> Model Class Initialized
INFO - 2018-01-19 20:33:32 --> Model Class Initialized
INFO - 2018-01-19 20:33:32 --> Model Class Initialized
DEBUG - 2018-01-19 20:33:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 20:33:37 --> Config Class Initialized
INFO - 2018-01-19 20:33:37 --> Hooks Class Initialized
DEBUG - 2018-01-19 20:33:37 --> UTF-8 Support Enabled
INFO - 2018-01-19 20:33:37 --> Utf8 Class Initialized
INFO - 2018-01-19 20:33:37 --> URI Class Initialized
INFO - 2018-01-19 20:33:37 --> Router Class Initialized
INFO - 2018-01-19 20:33:37 --> Output Class Initialized
INFO - 2018-01-19 20:33:37 --> Security Class Initialized
DEBUG - 2018-01-19 20:33:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 20:33:37 --> Input Class Initialized
INFO - 2018-01-19 20:33:37 --> Language Class Initialized
INFO - 2018-01-19 20:33:37 --> Loader Class Initialized
INFO - 2018-01-19 20:33:37 --> Helper loaded: url_helper
INFO - 2018-01-19 20:33:37 --> Helper loaded: form_helper
INFO - 2018-01-19 20:33:37 --> Database Driver Class Initialized
DEBUG - 2018-01-19 20:33:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 20:33:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 20:33:37 --> Form Validation Class Initialized
INFO - 2018-01-19 20:33:37 --> Model Class Initialized
INFO - 2018-01-19 20:33:37 --> Controller Class Initialized
INFO - 2018-01-19 20:33:38 --> Model Class Initialized
INFO - 2018-01-19 20:33:38 --> Model Class Initialized
INFO - 2018-01-19 20:33:38 --> Model Class Initialized
INFO - 2018-01-19 20:33:38 --> Model Class Initialized
DEBUG - 2018-01-19 20:33:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 20:33:38 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 20:33:38 --> Final output sent to browser
DEBUG - 2018-01-19 20:33:38 --> Total execution time: 0.7931
INFO - 2018-01-19 20:33:46 --> Config Class Initialized
INFO - 2018-01-19 20:33:46 --> Hooks Class Initialized
DEBUG - 2018-01-19 20:33:46 --> UTF-8 Support Enabled
INFO - 2018-01-19 20:33:46 --> Utf8 Class Initialized
INFO - 2018-01-19 20:33:46 --> URI Class Initialized
INFO - 2018-01-19 20:33:46 --> Router Class Initialized
INFO - 2018-01-19 20:33:46 --> Output Class Initialized
INFO - 2018-01-19 20:33:46 --> Security Class Initialized
DEBUG - 2018-01-19 20:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 20:33:46 --> Input Class Initialized
INFO - 2018-01-19 20:33:46 --> Language Class Initialized
INFO - 2018-01-19 20:33:46 --> Loader Class Initialized
INFO - 2018-01-19 20:33:46 --> Helper loaded: url_helper
INFO - 2018-01-19 20:33:46 --> Helper loaded: form_helper
INFO - 2018-01-19 20:33:46 --> Database Driver Class Initialized
DEBUG - 2018-01-19 20:33:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 20:33:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 20:33:46 --> Form Validation Class Initialized
INFO - 2018-01-19 20:33:46 --> Model Class Initialized
INFO - 2018-01-19 20:33:46 --> Controller Class Initialized
INFO - 2018-01-19 20:33:46 --> Model Class Initialized
INFO - 2018-01-19 20:33:46 --> Model Class Initialized
INFO - 2018-01-19 20:33:46 --> Model Class Initialized
INFO - 2018-01-19 20:33:46 --> Model Class Initialized
DEBUG - 2018-01-19 20:33:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 20:33:46 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 20:33:46 --> Final output sent to browser
DEBUG - 2018-01-19 20:33:46 --> Total execution time: 0.0537
INFO - 2018-01-19 20:34:00 --> Config Class Initialized
INFO - 2018-01-19 20:34:00 --> Hooks Class Initialized
DEBUG - 2018-01-19 20:34:00 --> UTF-8 Support Enabled
INFO - 2018-01-19 20:34:00 --> Utf8 Class Initialized
INFO - 2018-01-19 20:34:00 --> URI Class Initialized
INFO - 2018-01-19 20:34:00 --> Router Class Initialized
INFO - 2018-01-19 20:34:00 --> Output Class Initialized
INFO - 2018-01-19 20:34:00 --> Security Class Initialized
DEBUG - 2018-01-19 20:34:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 20:34:00 --> Input Class Initialized
INFO - 2018-01-19 20:34:00 --> Language Class Initialized
INFO - 2018-01-19 20:34:00 --> Loader Class Initialized
INFO - 2018-01-19 20:34:00 --> Helper loaded: url_helper
INFO - 2018-01-19 20:34:00 --> Helper loaded: form_helper
INFO - 2018-01-19 20:34:00 --> Database Driver Class Initialized
DEBUG - 2018-01-19 20:34:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 20:34:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 20:34:00 --> Form Validation Class Initialized
INFO - 2018-01-19 20:34:00 --> Model Class Initialized
INFO - 2018-01-19 20:34:00 --> Controller Class Initialized
INFO - 2018-01-19 20:34:00 --> Model Class Initialized
INFO - 2018-01-19 20:34:00 --> Model Class Initialized
INFO - 2018-01-19 20:34:00 --> Model Class Initialized
INFO - 2018-01-19 20:34:00 --> Model Class Initialized
DEBUG - 2018-01-19 20:34:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 20:34:00 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 20:34:00 --> Final output sent to browser
DEBUG - 2018-01-19 20:34:00 --> Total execution time: 0.0601
INFO - 2018-01-19 20:34:02 --> Config Class Initialized
INFO - 2018-01-19 20:34:02 --> Hooks Class Initialized
DEBUG - 2018-01-19 20:34:02 --> UTF-8 Support Enabled
INFO - 2018-01-19 20:34:02 --> Utf8 Class Initialized
INFO - 2018-01-19 20:34:02 --> URI Class Initialized
INFO - 2018-01-19 20:34:02 --> Router Class Initialized
INFO - 2018-01-19 20:34:02 --> Output Class Initialized
INFO - 2018-01-19 20:34:02 --> Security Class Initialized
DEBUG - 2018-01-19 20:34:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 20:34:02 --> Input Class Initialized
INFO - 2018-01-19 20:34:02 --> Language Class Initialized
INFO - 2018-01-19 20:34:02 --> Loader Class Initialized
INFO - 2018-01-19 20:34:02 --> Helper loaded: url_helper
INFO - 2018-01-19 20:34:02 --> Helper loaded: form_helper
INFO - 2018-01-19 20:34:02 --> Database Driver Class Initialized
DEBUG - 2018-01-19 20:34:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 20:34:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 20:34:02 --> Form Validation Class Initialized
INFO - 2018-01-19 20:34:02 --> Model Class Initialized
INFO - 2018-01-19 20:34:02 --> Controller Class Initialized
INFO - 2018-01-19 20:34:02 --> Model Class Initialized
INFO - 2018-01-19 20:34:02 --> Model Class Initialized
INFO - 2018-01-19 20:34:02 --> Model Class Initialized
INFO - 2018-01-19 20:34:02 --> Model Class Initialized
DEBUG - 2018-01-19 20:34:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 20:34:02 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 20:34:02 --> Final output sent to browser
DEBUG - 2018-01-19 20:34:02 --> Total execution time: 0.0496
INFO - 2018-01-19 20:34:02 --> Config Class Initialized
INFO - 2018-01-19 20:34:02 --> Hooks Class Initialized
DEBUG - 2018-01-19 20:34:02 --> UTF-8 Support Enabled
INFO - 2018-01-19 20:34:02 --> Utf8 Class Initialized
INFO - 2018-01-19 20:34:02 --> URI Class Initialized
INFO - 2018-01-19 20:34:02 --> Router Class Initialized
INFO - 2018-01-19 20:34:02 --> Output Class Initialized
INFO - 2018-01-19 20:34:02 --> Security Class Initialized
DEBUG - 2018-01-19 20:34:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 20:34:02 --> Input Class Initialized
INFO - 2018-01-19 20:34:02 --> Language Class Initialized
INFO - 2018-01-19 20:34:02 --> Loader Class Initialized
INFO - 2018-01-19 20:34:02 --> Helper loaded: url_helper
INFO - 2018-01-19 20:34:02 --> Helper loaded: form_helper
INFO - 2018-01-19 20:34:02 --> Database Driver Class Initialized
DEBUG - 2018-01-19 20:34:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 20:34:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 20:34:02 --> Form Validation Class Initialized
INFO - 2018-01-19 20:34:02 --> Model Class Initialized
INFO - 2018-01-19 20:34:02 --> Controller Class Initialized
INFO - 2018-01-19 20:34:02 --> Model Class Initialized
INFO - 2018-01-19 20:34:02 --> Model Class Initialized
INFO - 2018-01-19 20:34:02 --> Model Class Initialized
INFO - 2018-01-19 20:34:02 --> Model Class Initialized
DEBUG - 2018-01-19 20:34:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 20:34:03 --> Config Class Initialized
INFO - 2018-01-19 20:34:03 --> Hooks Class Initialized
DEBUG - 2018-01-19 20:34:03 --> UTF-8 Support Enabled
INFO - 2018-01-19 20:34:03 --> Utf8 Class Initialized
INFO - 2018-01-19 20:34:03 --> URI Class Initialized
INFO - 2018-01-19 20:34:03 --> Router Class Initialized
INFO - 2018-01-19 20:34:03 --> Output Class Initialized
INFO - 2018-01-19 20:34:03 --> Security Class Initialized
DEBUG - 2018-01-19 20:34:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 20:34:03 --> Input Class Initialized
INFO - 2018-01-19 20:34:03 --> Language Class Initialized
INFO - 2018-01-19 20:34:04 --> Loader Class Initialized
INFO - 2018-01-19 20:34:04 --> Helper loaded: url_helper
INFO - 2018-01-19 20:34:04 --> Helper loaded: form_helper
INFO - 2018-01-19 20:34:04 --> Database Driver Class Initialized
DEBUG - 2018-01-19 20:34:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 20:34:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 20:34:04 --> Form Validation Class Initialized
INFO - 2018-01-19 20:34:04 --> Model Class Initialized
INFO - 2018-01-19 20:34:04 --> Controller Class Initialized
INFO - 2018-01-19 20:34:04 --> Model Class Initialized
INFO - 2018-01-19 20:34:04 --> Model Class Initialized
INFO - 2018-01-19 20:34:04 --> Model Class Initialized
INFO - 2018-01-19 20:34:04 --> Model Class Initialized
DEBUG - 2018-01-19 20:34:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 20:34:04 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 20:34:04 --> Final output sent to browser
DEBUG - 2018-01-19 20:34:04 --> Total execution time: 0.0731
INFO - 2018-01-19 20:34:04 --> Config Class Initialized
INFO - 2018-01-19 20:34:04 --> Hooks Class Initialized
DEBUG - 2018-01-19 20:34:04 --> UTF-8 Support Enabled
INFO - 2018-01-19 20:34:04 --> Utf8 Class Initialized
INFO - 2018-01-19 20:34:04 --> URI Class Initialized
INFO - 2018-01-19 20:34:04 --> Router Class Initialized
INFO - 2018-01-19 20:34:04 --> Output Class Initialized
INFO - 2018-01-19 20:34:04 --> Security Class Initialized
DEBUG - 2018-01-19 20:34:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 20:34:04 --> Input Class Initialized
INFO - 2018-01-19 20:34:04 --> Language Class Initialized
INFO - 2018-01-19 20:34:04 --> Loader Class Initialized
INFO - 2018-01-19 20:34:04 --> Helper loaded: url_helper
INFO - 2018-01-19 20:34:04 --> Helper loaded: form_helper
INFO - 2018-01-19 20:34:04 --> Database Driver Class Initialized
DEBUG - 2018-01-19 20:34:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 20:34:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 20:34:04 --> Form Validation Class Initialized
INFO - 2018-01-19 20:34:04 --> Model Class Initialized
INFO - 2018-01-19 20:34:04 --> Controller Class Initialized
INFO - 2018-01-19 20:34:04 --> Model Class Initialized
INFO - 2018-01-19 20:34:04 --> Model Class Initialized
INFO - 2018-01-19 20:34:04 --> Model Class Initialized
INFO - 2018-01-19 20:34:04 --> Model Class Initialized
DEBUG - 2018-01-19 20:34:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 20:34:05 --> Config Class Initialized
INFO - 2018-01-19 20:34:05 --> Hooks Class Initialized
DEBUG - 2018-01-19 20:34:05 --> UTF-8 Support Enabled
INFO - 2018-01-19 20:34:05 --> Utf8 Class Initialized
INFO - 2018-01-19 20:34:05 --> URI Class Initialized
INFO - 2018-01-19 20:34:05 --> Router Class Initialized
INFO - 2018-01-19 20:34:05 --> Output Class Initialized
INFO - 2018-01-19 20:34:05 --> Security Class Initialized
DEBUG - 2018-01-19 20:34:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 20:34:05 --> Input Class Initialized
INFO - 2018-01-19 20:34:05 --> Language Class Initialized
INFO - 2018-01-19 20:34:05 --> Loader Class Initialized
INFO - 2018-01-19 20:34:05 --> Helper loaded: url_helper
INFO - 2018-01-19 20:34:05 --> Helper loaded: form_helper
INFO - 2018-01-19 20:34:05 --> Database Driver Class Initialized
DEBUG - 2018-01-19 20:34:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 20:34:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 20:34:05 --> Form Validation Class Initialized
INFO - 2018-01-19 20:34:05 --> Model Class Initialized
INFO - 2018-01-19 20:34:05 --> Controller Class Initialized
INFO - 2018-01-19 20:34:05 --> Model Class Initialized
INFO - 2018-01-19 20:34:05 --> Model Class Initialized
INFO - 2018-01-19 20:34:05 --> Model Class Initialized
INFO - 2018-01-19 20:34:05 --> Model Class Initialized
DEBUG - 2018-01-19 20:34:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 20:34:05 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 20:34:05 --> Final output sent to browser
DEBUG - 2018-01-19 20:34:05 --> Total execution time: 0.0458
INFO - 2018-01-19 20:34:06 --> Config Class Initialized
INFO - 2018-01-19 20:34:06 --> Hooks Class Initialized
DEBUG - 2018-01-19 20:34:06 --> UTF-8 Support Enabled
INFO - 2018-01-19 20:34:06 --> Utf8 Class Initialized
INFO - 2018-01-19 20:34:06 --> URI Class Initialized
INFO - 2018-01-19 20:34:06 --> Router Class Initialized
INFO - 2018-01-19 20:34:06 --> Output Class Initialized
INFO - 2018-01-19 20:34:06 --> Security Class Initialized
DEBUG - 2018-01-19 20:34:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 20:34:06 --> Input Class Initialized
INFO - 2018-01-19 20:34:06 --> Language Class Initialized
INFO - 2018-01-19 20:34:06 --> Loader Class Initialized
INFO - 2018-01-19 20:34:06 --> Helper loaded: url_helper
INFO - 2018-01-19 20:34:06 --> Helper loaded: form_helper
INFO - 2018-01-19 20:34:06 --> Database Driver Class Initialized
DEBUG - 2018-01-19 20:34:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 20:34:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 20:34:06 --> Form Validation Class Initialized
INFO - 2018-01-19 20:34:06 --> Model Class Initialized
INFO - 2018-01-19 20:34:06 --> Controller Class Initialized
INFO - 2018-01-19 20:34:06 --> Model Class Initialized
INFO - 2018-01-19 20:34:06 --> Model Class Initialized
INFO - 2018-01-19 20:34:06 --> Model Class Initialized
INFO - 2018-01-19 20:34:06 --> Model Class Initialized
DEBUG - 2018-01-19 20:34:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 20:34:06 --> Config Class Initialized
INFO - 2018-01-19 20:34:06 --> Hooks Class Initialized
DEBUG - 2018-01-19 20:34:06 --> UTF-8 Support Enabled
INFO - 2018-01-19 20:34:06 --> Utf8 Class Initialized
INFO - 2018-01-19 20:34:06 --> URI Class Initialized
DEBUG - 2018-01-19 20:34:06 --> No URI present. Default controller set.
INFO - 2018-01-19 20:34:06 --> Router Class Initialized
INFO - 2018-01-19 20:34:06 --> Output Class Initialized
INFO - 2018-01-19 20:34:06 --> Security Class Initialized
DEBUG - 2018-01-19 20:34:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 20:34:06 --> Input Class Initialized
INFO - 2018-01-19 20:34:06 --> Language Class Initialized
INFO - 2018-01-19 20:34:06 --> Loader Class Initialized
INFO - 2018-01-19 20:34:06 --> Helper loaded: url_helper
INFO - 2018-01-19 20:34:06 --> Helper loaded: form_helper
INFO - 2018-01-19 20:34:06 --> Database Driver Class Initialized
DEBUG - 2018-01-19 20:34:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 20:34:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 20:34:06 --> Form Validation Class Initialized
INFO - 2018-01-19 20:34:06 --> Model Class Initialized
INFO - 2018-01-19 20:34:06 --> Controller Class Initialized
INFO - 2018-01-19 20:34:06 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 20:34:06 --> Final output sent to browser
DEBUG - 2018-01-19 20:34:06 --> Total execution time: 0.0336
INFO - 2018-01-19 20:34:08 --> Config Class Initialized
INFO - 2018-01-19 20:34:08 --> Hooks Class Initialized
DEBUG - 2018-01-19 20:34:08 --> UTF-8 Support Enabled
INFO - 2018-01-19 20:34:08 --> Utf8 Class Initialized
INFO - 2018-01-19 20:34:08 --> URI Class Initialized
INFO - 2018-01-19 20:34:08 --> Router Class Initialized
INFO - 2018-01-19 20:34:08 --> Output Class Initialized
INFO - 2018-01-19 20:34:08 --> Security Class Initialized
DEBUG - 2018-01-19 20:34:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-19 20:34:08 --> Input Class Initialized
INFO - 2018-01-19 20:34:08 --> Language Class Initialized
INFO - 2018-01-19 20:34:08 --> Loader Class Initialized
INFO - 2018-01-19 20:34:08 --> Helper loaded: url_helper
INFO - 2018-01-19 20:34:08 --> Helper loaded: form_helper
INFO - 2018-01-19 20:34:08 --> Database Driver Class Initialized
DEBUG - 2018-01-19 20:34:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-19 20:34:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-19 20:34:08 --> Form Validation Class Initialized
INFO - 2018-01-19 20:34:08 --> Model Class Initialized
INFO - 2018-01-19 20:34:08 --> Controller Class Initialized
INFO - 2018-01-19 20:34:08 --> Model Class Initialized
DEBUG - 2018-01-19 20:34:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-19 20:34:08 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-19 20:34:08 --> Final output sent to browser
DEBUG - 2018-01-19 20:34:08 --> Total execution time: 0.0401
