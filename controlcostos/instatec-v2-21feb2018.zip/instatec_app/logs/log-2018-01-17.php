<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-01-17 20:14:44 --> Config Class Initialized
INFO - 2018-01-17 20:14:44 --> Hooks Class Initialized
DEBUG - 2018-01-17 20:14:44 --> UTF-8 Support Enabled
INFO - 2018-01-17 20:14:44 --> Utf8 Class Initialized
INFO - 2018-01-17 20:14:44 --> URI Class Initialized
DEBUG - 2018-01-17 20:14:44 --> No URI present. Default controller set.
INFO - 2018-01-17 20:14:44 --> Router Class Initialized
INFO - 2018-01-17 20:14:44 --> Output Class Initialized
INFO - 2018-01-17 20:14:44 --> Security Class Initialized
DEBUG - 2018-01-17 20:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 20:14:44 --> Input Class Initialized
INFO - 2018-01-17 20:14:44 --> Language Class Initialized
INFO - 2018-01-17 20:14:44 --> Loader Class Initialized
INFO - 2018-01-17 20:14:44 --> Helper loaded: url_helper
INFO - 2018-01-17 20:14:44 --> Helper loaded: form_helper
INFO - 2018-01-17 20:14:44 --> Database Driver Class Initialized
DEBUG - 2018-01-17 20:14:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-17 20:14:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-17 20:14:44 --> Form Validation Class Initialized
ERROR - 2018-01-17 20:14:44 --> Severity: error --> Exception: Unable to locate the model you have specified: M_general /home/instateccr/public_html/controlcostos/instatec_sys/core/Loader.php 344
INFO - 2018-01-17 20:16:01 --> Config Class Initialized
INFO - 2018-01-17 20:16:01 --> Hooks Class Initialized
DEBUG - 2018-01-17 20:16:01 --> UTF-8 Support Enabled
INFO - 2018-01-17 20:16:01 --> Utf8 Class Initialized
INFO - 2018-01-17 20:16:01 --> URI Class Initialized
DEBUG - 2018-01-17 20:16:01 --> No URI present. Default controller set.
INFO - 2018-01-17 20:16:01 --> Router Class Initialized
INFO - 2018-01-17 20:16:01 --> Output Class Initialized
INFO - 2018-01-17 20:16:01 --> Security Class Initialized
DEBUG - 2018-01-17 20:16:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 20:16:01 --> Input Class Initialized
INFO - 2018-01-17 20:16:01 --> Language Class Initialized
INFO - 2018-01-17 20:16:01 --> Loader Class Initialized
INFO - 2018-01-17 20:16:01 --> Helper loaded: url_helper
INFO - 2018-01-17 20:16:01 --> Helper loaded: form_helper
INFO - 2018-01-17 20:16:01 --> Database Driver Class Initialized
DEBUG - 2018-01-17 20:16:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-17 20:16:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-17 20:16:01 --> Form Validation Class Initialized
ERROR - 2018-01-17 20:16:01 --> Severity: error --> Exception: Unable to locate the model you have specified: M_general /home/instateccr/public_html/controlcostos/instatec_sys/core/Loader.php 344
INFO - 2018-01-17 20:16:09 --> Config Class Initialized
INFO - 2018-01-17 20:16:09 --> Hooks Class Initialized
DEBUG - 2018-01-17 20:16:09 --> UTF-8 Support Enabled
INFO - 2018-01-17 20:16:09 --> Utf8 Class Initialized
INFO - 2018-01-17 20:16:09 --> URI Class Initialized
DEBUG - 2018-01-17 20:16:09 --> No URI present. Default controller set.
INFO - 2018-01-17 20:16:09 --> Router Class Initialized
INFO - 2018-01-17 20:16:09 --> Output Class Initialized
INFO - 2018-01-17 20:16:09 --> Security Class Initialized
DEBUG - 2018-01-17 20:16:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 20:16:09 --> Input Class Initialized
INFO - 2018-01-17 20:16:09 --> Language Class Initialized
INFO - 2018-01-17 20:16:09 --> Loader Class Initialized
INFO - 2018-01-17 20:16:09 --> Helper loaded: url_helper
INFO - 2018-01-17 20:16:09 --> Helper loaded: form_helper
INFO - 2018-01-17 20:16:09 --> Database Driver Class Initialized
DEBUG - 2018-01-17 20:16:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-17 20:16:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-17 20:16:09 --> Form Validation Class Initialized
ERROR - 2018-01-17 20:16:09 --> Severity: error --> Exception: Unable to locate the model you have specified: M_general /home/instateccr/public_html/controlcostos/instatec_sys/core/Loader.php 344
INFO - 2018-01-17 20:16:10 --> Config Class Initialized
INFO - 2018-01-17 20:16:10 --> Hooks Class Initialized
DEBUG - 2018-01-17 20:16:10 --> UTF-8 Support Enabled
INFO - 2018-01-17 20:16:10 --> Utf8 Class Initialized
INFO - 2018-01-17 20:16:10 --> URI Class Initialized
DEBUG - 2018-01-17 20:16:10 --> No URI present. Default controller set.
INFO - 2018-01-17 20:16:10 --> Router Class Initialized
INFO - 2018-01-17 20:16:10 --> Output Class Initialized
INFO - 2018-01-17 20:16:10 --> Security Class Initialized
DEBUG - 2018-01-17 20:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 20:16:10 --> Input Class Initialized
INFO - 2018-01-17 20:16:10 --> Language Class Initialized
INFO - 2018-01-17 20:16:10 --> Loader Class Initialized
INFO - 2018-01-17 20:16:10 --> Helper loaded: url_helper
INFO - 2018-01-17 20:16:10 --> Helper loaded: form_helper
INFO - 2018-01-17 20:16:10 --> Database Driver Class Initialized
DEBUG - 2018-01-17 20:16:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-17 20:16:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-17 20:16:10 --> Form Validation Class Initialized
ERROR - 2018-01-17 20:16:10 --> Severity: error --> Exception: Unable to locate the model you have specified: M_general /home/instateccr/public_html/controlcostos/instatec_sys/core/Loader.php 344
INFO - 2018-01-17 20:16:10 --> Config Class Initialized
INFO - 2018-01-17 20:16:10 --> Hooks Class Initialized
DEBUG - 2018-01-17 20:16:10 --> UTF-8 Support Enabled
INFO - 2018-01-17 20:16:10 --> Utf8 Class Initialized
INFO - 2018-01-17 20:16:10 --> URI Class Initialized
DEBUG - 2018-01-17 20:16:10 --> No URI present. Default controller set.
INFO - 2018-01-17 20:16:10 --> Router Class Initialized
INFO - 2018-01-17 20:16:10 --> Output Class Initialized
INFO - 2018-01-17 20:16:10 --> Security Class Initialized
DEBUG - 2018-01-17 20:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 20:16:10 --> Input Class Initialized
INFO - 2018-01-17 20:16:10 --> Language Class Initialized
INFO - 2018-01-17 20:16:10 --> Loader Class Initialized
INFO - 2018-01-17 20:16:10 --> Helper loaded: url_helper
INFO - 2018-01-17 20:16:10 --> Helper loaded: form_helper
INFO - 2018-01-17 20:16:11 --> Database Driver Class Initialized
DEBUG - 2018-01-17 20:16:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-17 20:16:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-17 20:16:11 --> Form Validation Class Initialized
ERROR - 2018-01-17 20:16:11 --> Severity: error --> Exception: Unable to locate the model you have specified: M_general /home/instateccr/public_html/controlcostos/instatec_sys/core/Loader.php 344
INFO - 2018-01-17 20:16:11 --> Config Class Initialized
INFO - 2018-01-17 20:16:11 --> Hooks Class Initialized
DEBUG - 2018-01-17 20:16:11 --> UTF-8 Support Enabled
INFO - 2018-01-17 20:16:11 --> Utf8 Class Initialized
INFO - 2018-01-17 20:16:11 --> URI Class Initialized
DEBUG - 2018-01-17 20:16:11 --> No URI present. Default controller set.
INFO - 2018-01-17 20:16:11 --> Router Class Initialized
INFO - 2018-01-17 20:16:11 --> Output Class Initialized
INFO - 2018-01-17 20:16:11 --> Security Class Initialized
DEBUG - 2018-01-17 20:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 20:16:11 --> Input Class Initialized
INFO - 2018-01-17 20:16:11 --> Language Class Initialized
INFO - 2018-01-17 20:16:11 --> Loader Class Initialized
INFO - 2018-01-17 20:16:11 --> Helper loaded: url_helper
INFO - 2018-01-17 20:16:11 --> Helper loaded: form_helper
INFO - 2018-01-17 20:16:11 --> Database Driver Class Initialized
DEBUG - 2018-01-17 20:16:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-17 20:16:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-17 20:16:11 --> Form Validation Class Initialized
ERROR - 2018-01-17 20:16:11 --> Severity: error --> Exception: Unable to locate the model you have specified: M_general /home/instateccr/public_html/controlcostos/instatec_sys/core/Loader.php 344
INFO - 2018-01-17 20:18:10 --> Config Class Initialized
INFO - 2018-01-17 20:18:10 --> Hooks Class Initialized
DEBUG - 2018-01-17 20:18:10 --> UTF-8 Support Enabled
INFO - 2018-01-17 20:18:10 --> Utf8 Class Initialized
INFO - 2018-01-17 20:18:10 --> URI Class Initialized
DEBUG - 2018-01-17 20:18:10 --> No URI present. Default controller set.
INFO - 2018-01-17 20:18:10 --> Router Class Initialized
INFO - 2018-01-17 20:18:10 --> Output Class Initialized
INFO - 2018-01-17 20:18:10 --> Security Class Initialized
DEBUG - 2018-01-17 20:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 20:18:10 --> Input Class Initialized
INFO - 2018-01-17 20:18:10 --> Language Class Initialized
INFO - 2018-01-17 20:18:10 --> Loader Class Initialized
INFO - 2018-01-17 20:18:10 --> Helper loaded: url_helper
INFO - 2018-01-17 20:18:10 --> Helper loaded: form_helper
INFO - 2018-01-17 20:18:10 --> Database Driver Class Initialized
DEBUG - 2018-01-17 20:18:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-17 20:18:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-17 20:18:10 --> Form Validation Class Initialized
ERROR - 2018-01-17 20:18:10 --> Severity: error --> Exception: Unable to locate the model you have specified: M_general /home/instateccr/public_html/controlcostos/instatec_sys/core/Loader.php 344
INFO - 2018-01-17 20:20:48 --> Config Class Initialized
INFO - 2018-01-17 20:20:48 --> Hooks Class Initialized
DEBUG - 2018-01-17 20:20:48 --> UTF-8 Support Enabled
INFO - 2018-01-17 20:20:48 --> Utf8 Class Initialized
INFO - 2018-01-17 20:20:48 --> URI Class Initialized
DEBUG - 2018-01-17 20:20:48 --> No URI present. Default controller set.
INFO - 2018-01-17 20:20:48 --> Router Class Initialized
INFO - 2018-01-17 20:20:48 --> Output Class Initialized
INFO - 2018-01-17 20:20:48 --> Security Class Initialized
DEBUG - 2018-01-17 20:20:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 20:20:48 --> Input Class Initialized
INFO - 2018-01-17 20:20:48 --> Language Class Initialized
INFO - 2018-01-17 20:20:48 --> Loader Class Initialized
INFO - 2018-01-17 20:20:48 --> Helper loaded: url_helper
INFO - 2018-01-17 20:20:48 --> Helper loaded: form_helper
INFO - 2018-01-17 20:20:49 --> Database Driver Class Initialized
DEBUG - 2018-01-17 20:20:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-17 20:20:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-17 20:20:49 --> Form Validation Class Initialized
ERROR - 2018-01-17 20:20:49 --> Severity: error --> Exception: Unable to locate the model you have specified: M_general /home/instateccr/public_html/controlcostos/instatec_sys/core/Loader.php 344
INFO - 2018-01-17 20:34:30 --> Config Class Initialized
INFO - 2018-01-17 20:34:30 --> Hooks Class Initialized
DEBUG - 2018-01-17 20:34:30 --> UTF-8 Support Enabled
INFO - 2018-01-17 20:34:30 --> Utf8 Class Initialized
INFO - 2018-01-17 20:34:30 --> URI Class Initialized
DEBUG - 2018-01-17 20:34:30 --> No URI present. Default controller set.
INFO - 2018-01-17 20:34:30 --> Router Class Initialized
INFO - 2018-01-17 20:34:30 --> Output Class Initialized
INFO - 2018-01-17 20:34:30 --> Security Class Initialized
DEBUG - 2018-01-17 20:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 20:34:30 --> Input Class Initialized
INFO - 2018-01-17 20:34:30 --> Language Class Initialized
INFO - 2018-01-17 20:34:30 --> Loader Class Initialized
INFO - 2018-01-17 20:34:30 --> Helper loaded: url_helper
INFO - 2018-01-17 20:34:30 --> Helper loaded: form_helper
INFO - 2018-01-17 20:34:30 --> Database Driver Class Initialized
DEBUG - 2018-01-17 20:34:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-17 20:34:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-17 20:34:30 --> Form Validation Class Initialized
ERROR - 2018-01-17 20:34:30 --> Severity: error --> Exception: Unable to locate the model you have specified: M_general /home/instateccr/public_html/controlcostos/instatec_sys/core/Loader.php 344
INFO - 2018-01-17 20:34:32 --> Config Class Initialized
INFO - 2018-01-17 20:34:32 --> Hooks Class Initialized
DEBUG - 2018-01-17 20:34:32 --> UTF-8 Support Enabled
INFO - 2018-01-17 20:34:32 --> Utf8 Class Initialized
INFO - 2018-01-17 20:34:32 --> URI Class Initialized
DEBUG - 2018-01-17 20:34:32 --> No URI present. Default controller set.
INFO - 2018-01-17 20:34:32 --> Router Class Initialized
INFO - 2018-01-17 20:34:32 --> Output Class Initialized
INFO - 2018-01-17 20:34:32 --> Security Class Initialized
DEBUG - 2018-01-17 20:34:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 20:34:32 --> Input Class Initialized
INFO - 2018-01-17 20:34:32 --> Language Class Initialized
INFO - 2018-01-17 20:34:32 --> Loader Class Initialized
INFO - 2018-01-17 20:34:32 --> Helper loaded: url_helper
INFO - 2018-01-17 20:34:32 --> Helper loaded: form_helper
INFO - 2018-01-17 20:34:32 --> Database Driver Class Initialized
DEBUG - 2018-01-17 20:34:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-17 20:34:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-17 20:34:32 --> Form Validation Class Initialized
ERROR - 2018-01-17 20:34:32 --> Severity: error --> Exception: Unable to locate the model you have specified: M_general /home/instateccr/public_html/controlcostos/instatec_sys/core/Loader.php 344
INFO - 2018-01-17 20:41:36 --> Config Class Initialized
INFO - 2018-01-17 20:41:36 --> Hooks Class Initialized
DEBUG - 2018-01-17 20:41:36 --> UTF-8 Support Enabled
INFO - 2018-01-17 20:41:36 --> Utf8 Class Initialized
INFO - 2018-01-17 20:41:36 --> URI Class Initialized
DEBUG - 2018-01-17 20:41:36 --> No URI present. Default controller set.
INFO - 2018-01-17 20:41:36 --> Router Class Initialized
INFO - 2018-01-17 20:41:36 --> Output Class Initialized
INFO - 2018-01-17 20:41:36 --> Security Class Initialized
DEBUG - 2018-01-17 20:41:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 20:41:36 --> Input Class Initialized
INFO - 2018-01-17 20:41:36 --> Language Class Initialized
INFO - 2018-01-17 20:41:36 --> Loader Class Initialized
INFO - 2018-01-17 20:41:36 --> Helper loaded: url_helper
INFO - 2018-01-17 20:41:36 --> Helper loaded: form_helper
INFO - 2018-01-17 20:41:36 --> Database Driver Class Initialized
DEBUG - 2018-01-17 20:41:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-17 20:41:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-17 20:41:36 --> Form Validation Class Initialized
ERROR - 2018-01-17 20:41:36 --> Severity: error --> Exception: Unable to locate the model you have specified: M_general /home/instateccr/public_html/controlcostos/instatec_sys/core/Loader.php 344
INFO - 2018-01-17 20:44:21 --> Config Class Initialized
INFO - 2018-01-17 20:44:21 --> Hooks Class Initialized
DEBUG - 2018-01-17 20:44:21 --> UTF-8 Support Enabled
INFO - 2018-01-17 20:44:21 --> Utf8 Class Initialized
INFO - 2018-01-17 20:44:21 --> URI Class Initialized
DEBUG - 2018-01-17 20:44:21 --> No URI present. Default controller set.
INFO - 2018-01-17 20:44:21 --> Router Class Initialized
INFO - 2018-01-17 20:44:21 --> Output Class Initialized
INFO - 2018-01-17 20:44:21 --> Security Class Initialized
DEBUG - 2018-01-17 20:44:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 20:44:21 --> Input Class Initialized
INFO - 2018-01-17 20:44:21 --> Language Class Initialized
INFO - 2018-01-17 20:44:21 --> Loader Class Initialized
INFO - 2018-01-17 20:44:21 --> Helper loaded: url_helper
INFO - 2018-01-17 20:44:21 --> Helper loaded: form_helper
INFO - 2018-01-17 20:44:21 --> Database Driver Class Initialized
DEBUG - 2018-01-17 20:44:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-17 20:44:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-17 20:44:21 --> Form Validation Class Initialized
ERROR - 2018-01-17 20:44:21 --> Severity: error --> Exception: Unable to locate the model you have specified: M_general /home/instateccr/public_html/controlcostos/instatec_sys/core/Loader.php 344
INFO - 2018-01-17 20:44:21 --> Config Class Initialized
INFO - 2018-01-17 20:44:21 --> Hooks Class Initialized
DEBUG - 2018-01-17 20:44:21 --> UTF-8 Support Enabled
INFO - 2018-01-17 20:44:21 --> Utf8 Class Initialized
INFO - 2018-01-17 20:44:21 --> URI Class Initialized
DEBUG - 2018-01-17 20:44:21 --> No URI present. Default controller set.
INFO - 2018-01-17 20:44:21 --> Router Class Initialized
INFO - 2018-01-17 20:44:21 --> Output Class Initialized
INFO - 2018-01-17 20:44:21 --> Security Class Initialized
DEBUG - 2018-01-17 20:44:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 20:44:21 --> Input Class Initialized
INFO - 2018-01-17 20:44:21 --> Language Class Initialized
INFO - 2018-01-17 20:44:21 --> Loader Class Initialized
INFO - 2018-01-17 20:44:21 --> Helper loaded: url_helper
INFO - 2018-01-17 20:44:21 --> Helper loaded: form_helper
INFO - 2018-01-17 20:44:21 --> Database Driver Class Initialized
DEBUG - 2018-01-17 20:44:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-17 20:44:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-17 20:44:21 --> Form Validation Class Initialized
ERROR - 2018-01-17 20:44:21 --> Severity: error --> Exception: Unable to locate the model you have specified: M_general /home/instateccr/public_html/controlcostos/instatec_sys/core/Loader.php 344
INFO - 2018-01-17 20:44:22 --> Config Class Initialized
INFO - 2018-01-17 20:44:22 --> Hooks Class Initialized
DEBUG - 2018-01-17 20:44:22 --> UTF-8 Support Enabled
INFO - 2018-01-17 20:44:22 --> Utf8 Class Initialized
INFO - 2018-01-17 20:44:22 --> URI Class Initialized
DEBUG - 2018-01-17 20:44:22 --> No URI present. Default controller set.
INFO - 2018-01-17 20:44:22 --> Router Class Initialized
INFO - 2018-01-17 20:44:22 --> Output Class Initialized
INFO - 2018-01-17 20:44:22 --> Security Class Initialized
DEBUG - 2018-01-17 20:44:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 20:44:22 --> Input Class Initialized
INFO - 2018-01-17 20:44:22 --> Language Class Initialized
INFO - 2018-01-17 20:44:22 --> Loader Class Initialized
INFO - 2018-01-17 20:44:22 --> Helper loaded: url_helper
INFO - 2018-01-17 20:44:22 --> Helper loaded: form_helper
INFO - 2018-01-17 20:44:22 --> Database Driver Class Initialized
DEBUG - 2018-01-17 20:44:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-17 20:44:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-17 20:44:22 --> Form Validation Class Initialized
ERROR - 2018-01-17 20:44:22 --> Severity: error --> Exception: Unable to locate the model you have specified: M_general /home/instateccr/public_html/controlcostos/instatec_sys/core/Loader.php 344
INFO - 2018-01-17 20:44:22 --> Config Class Initialized
INFO - 2018-01-17 20:44:22 --> Hooks Class Initialized
DEBUG - 2018-01-17 20:44:22 --> UTF-8 Support Enabled
INFO - 2018-01-17 20:44:22 --> Utf8 Class Initialized
INFO - 2018-01-17 20:44:22 --> URI Class Initialized
DEBUG - 2018-01-17 20:44:22 --> No URI present. Default controller set.
INFO - 2018-01-17 20:44:22 --> Router Class Initialized
INFO - 2018-01-17 20:44:22 --> Output Class Initialized
INFO - 2018-01-17 20:44:22 --> Security Class Initialized
DEBUG - 2018-01-17 20:44:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 20:44:22 --> Input Class Initialized
INFO - 2018-01-17 20:44:22 --> Language Class Initialized
INFO - 2018-01-17 20:44:22 --> Loader Class Initialized
INFO - 2018-01-17 20:44:22 --> Helper loaded: url_helper
INFO - 2018-01-17 20:44:22 --> Helper loaded: form_helper
INFO - 2018-01-17 20:44:22 --> Database Driver Class Initialized
DEBUG - 2018-01-17 20:44:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-17 20:44:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-17 20:44:22 --> Form Validation Class Initialized
ERROR - 2018-01-17 20:44:22 --> Severity: error --> Exception: Unable to locate the model you have specified: M_general /home/instateccr/public_html/controlcostos/instatec_sys/core/Loader.php 344
INFO - 2018-01-17 20:44:23 --> Config Class Initialized
INFO - 2018-01-17 20:44:23 --> Hooks Class Initialized
DEBUG - 2018-01-17 20:44:23 --> UTF-8 Support Enabled
INFO - 2018-01-17 20:44:23 --> Utf8 Class Initialized
INFO - 2018-01-17 20:44:23 --> URI Class Initialized
DEBUG - 2018-01-17 20:44:23 --> No URI present. Default controller set.
INFO - 2018-01-17 20:44:23 --> Router Class Initialized
INFO - 2018-01-17 20:44:23 --> Output Class Initialized
INFO - 2018-01-17 20:44:23 --> Security Class Initialized
DEBUG - 2018-01-17 20:44:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 20:44:23 --> Input Class Initialized
INFO - 2018-01-17 20:44:23 --> Language Class Initialized
INFO - 2018-01-17 20:44:23 --> Loader Class Initialized
INFO - 2018-01-17 20:44:23 --> Helper loaded: url_helper
INFO - 2018-01-17 20:44:23 --> Helper loaded: form_helper
INFO - 2018-01-17 20:44:23 --> Database Driver Class Initialized
DEBUG - 2018-01-17 20:44:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-17 20:44:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-17 20:44:23 --> Form Validation Class Initialized
ERROR - 2018-01-17 20:44:23 --> Severity: error --> Exception: Unable to locate the model you have specified: M_general /home/instateccr/public_html/controlcostos/instatec_sys/core/Loader.php 344
INFO - 2018-01-17 20:44:24 --> Config Class Initialized
INFO - 2018-01-17 20:44:24 --> Hooks Class Initialized
DEBUG - 2018-01-17 20:44:24 --> UTF-8 Support Enabled
INFO - 2018-01-17 20:44:24 --> Utf8 Class Initialized
INFO - 2018-01-17 20:44:24 --> URI Class Initialized
DEBUG - 2018-01-17 20:44:24 --> No URI present. Default controller set.
INFO - 2018-01-17 20:44:24 --> Router Class Initialized
INFO - 2018-01-17 20:44:24 --> Output Class Initialized
INFO - 2018-01-17 20:44:24 --> Security Class Initialized
DEBUG - 2018-01-17 20:44:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 20:44:24 --> Input Class Initialized
INFO - 2018-01-17 20:44:24 --> Language Class Initialized
INFO - 2018-01-17 20:44:24 --> Loader Class Initialized
INFO - 2018-01-17 20:44:24 --> Helper loaded: url_helper
INFO - 2018-01-17 20:44:24 --> Helper loaded: form_helper
INFO - 2018-01-17 20:44:24 --> Database Driver Class Initialized
DEBUG - 2018-01-17 20:44:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-17 20:44:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-17 20:44:24 --> Form Validation Class Initialized
ERROR - 2018-01-17 20:44:24 --> Severity: error --> Exception: Unable to locate the model you have specified: M_general /home/instateccr/public_html/controlcostos/instatec_sys/core/Loader.php 344
INFO - 2018-01-17 20:44:24 --> Config Class Initialized
INFO - 2018-01-17 20:44:24 --> Hooks Class Initialized
DEBUG - 2018-01-17 20:44:24 --> UTF-8 Support Enabled
INFO - 2018-01-17 20:44:24 --> Utf8 Class Initialized
INFO - 2018-01-17 20:44:24 --> URI Class Initialized
DEBUG - 2018-01-17 20:44:24 --> No URI present. Default controller set.
INFO - 2018-01-17 20:44:24 --> Router Class Initialized
INFO - 2018-01-17 20:44:24 --> Output Class Initialized
INFO - 2018-01-17 20:44:24 --> Security Class Initialized
DEBUG - 2018-01-17 20:44:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 20:44:24 --> Input Class Initialized
INFO - 2018-01-17 20:44:24 --> Language Class Initialized
INFO - 2018-01-17 20:44:24 --> Loader Class Initialized
INFO - 2018-01-17 20:44:24 --> Helper loaded: url_helper
INFO - 2018-01-17 20:44:24 --> Helper loaded: form_helper
INFO - 2018-01-17 20:44:24 --> Database Driver Class Initialized
DEBUG - 2018-01-17 20:44:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-17 20:44:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-17 20:44:24 --> Form Validation Class Initialized
ERROR - 2018-01-17 20:44:24 --> Severity: error --> Exception: Unable to locate the model you have specified: M_general /home/instateccr/public_html/controlcostos/instatec_sys/core/Loader.php 344
INFO - 2018-01-17 20:44:25 --> Config Class Initialized
INFO - 2018-01-17 20:44:25 --> Hooks Class Initialized
DEBUG - 2018-01-17 20:44:25 --> UTF-8 Support Enabled
INFO - 2018-01-17 20:44:25 --> Utf8 Class Initialized
INFO - 2018-01-17 20:44:25 --> URI Class Initialized
DEBUG - 2018-01-17 20:44:25 --> No URI present. Default controller set.
INFO - 2018-01-17 20:44:25 --> Router Class Initialized
INFO - 2018-01-17 20:44:25 --> Output Class Initialized
INFO - 2018-01-17 20:44:25 --> Security Class Initialized
DEBUG - 2018-01-17 20:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 20:44:25 --> Input Class Initialized
INFO - 2018-01-17 20:44:25 --> Language Class Initialized
INFO - 2018-01-17 20:44:25 --> Loader Class Initialized
INFO - 2018-01-17 20:44:25 --> Helper loaded: url_helper
INFO - 2018-01-17 20:44:25 --> Helper loaded: form_helper
INFO - 2018-01-17 20:44:25 --> Database Driver Class Initialized
DEBUG - 2018-01-17 20:44:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-17 20:44:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-17 20:44:25 --> Form Validation Class Initialized
ERROR - 2018-01-17 20:44:25 --> Severity: error --> Exception: Unable to locate the model you have specified: M_general /home/instateccr/public_html/controlcostos/instatec_sys/core/Loader.php 344
INFO - 2018-01-17 20:44:25 --> Config Class Initialized
INFO - 2018-01-17 20:44:25 --> Hooks Class Initialized
DEBUG - 2018-01-17 20:44:25 --> UTF-8 Support Enabled
INFO - 2018-01-17 20:44:25 --> Utf8 Class Initialized
INFO - 2018-01-17 20:44:25 --> URI Class Initialized
DEBUG - 2018-01-17 20:44:25 --> No URI present. Default controller set.
INFO - 2018-01-17 20:44:25 --> Router Class Initialized
INFO - 2018-01-17 20:44:25 --> Output Class Initialized
INFO - 2018-01-17 20:44:25 --> Security Class Initialized
DEBUG - 2018-01-17 20:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 20:44:25 --> Input Class Initialized
INFO - 2018-01-17 20:44:25 --> Language Class Initialized
INFO - 2018-01-17 20:44:25 --> Loader Class Initialized
INFO - 2018-01-17 20:44:25 --> Helper loaded: url_helper
INFO - 2018-01-17 20:44:25 --> Helper loaded: form_helper
INFO - 2018-01-17 20:44:25 --> Database Driver Class Initialized
DEBUG - 2018-01-17 20:44:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-17 20:44:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-17 20:44:25 --> Form Validation Class Initialized
ERROR - 2018-01-17 20:44:25 --> Severity: error --> Exception: Unable to locate the model you have specified: M_general /home/instateccr/public_html/controlcostos/instatec_sys/core/Loader.php 344
INFO - 2018-01-17 20:44:48 --> Config Class Initialized
INFO - 2018-01-17 20:44:48 --> Hooks Class Initialized
DEBUG - 2018-01-17 20:44:48 --> UTF-8 Support Enabled
INFO - 2018-01-17 20:44:48 --> Utf8 Class Initialized
INFO - 2018-01-17 20:44:48 --> URI Class Initialized
DEBUG - 2018-01-17 20:44:48 --> No URI present. Default controller set.
INFO - 2018-01-17 20:44:48 --> Router Class Initialized
INFO - 2018-01-17 20:44:48 --> Output Class Initialized
INFO - 2018-01-17 20:44:48 --> Security Class Initialized
DEBUG - 2018-01-17 20:44:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 20:44:48 --> Input Class Initialized
INFO - 2018-01-17 20:44:48 --> Language Class Initialized
INFO - 2018-01-17 20:44:48 --> Loader Class Initialized
INFO - 2018-01-17 20:44:48 --> Helper loaded: url_helper
INFO - 2018-01-17 20:44:48 --> Helper loaded: form_helper
INFO - 2018-01-17 20:44:48 --> Database Driver Class Initialized
DEBUG - 2018-01-17 20:44:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-17 20:44:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-17 20:44:48 --> Form Validation Class Initialized
ERROR - 2018-01-17 20:44:48 --> Severity: error --> Exception: Unable to locate the model you have specified: M_general /home/instateccr/public_html/controlcostos/instatec_sys/core/Loader.php 344
INFO - 2018-01-17 20:44:49 --> Config Class Initialized
INFO - 2018-01-17 20:44:49 --> Hooks Class Initialized
DEBUG - 2018-01-17 20:44:49 --> UTF-8 Support Enabled
INFO - 2018-01-17 20:44:49 --> Utf8 Class Initialized
INFO - 2018-01-17 20:44:49 --> URI Class Initialized
DEBUG - 2018-01-17 20:44:49 --> No URI present. Default controller set.
INFO - 2018-01-17 20:44:49 --> Router Class Initialized
INFO - 2018-01-17 20:44:49 --> Output Class Initialized
INFO - 2018-01-17 20:44:49 --> Security Class Initialized
DEBUG - 2018-01-17 20:44:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 20:44:49 --> Input Class Initialized
INFO - 2018-01-17 20:44:49 --> Language Class Initialized
INFO - 2018-01-17 20:44:49 --> Loader Class Initialized
INFO - 2018-01-17 20:44:49 --> Helper loaded: url_helper
INFO - 2018-01-17 20:44:49 --> Helper loaded: form_helper
INFO - 2018-01-17 20:44:49 --> Database Driver Class Initialized
DEBUG - 2018-01-17 20:44:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-17 20:44:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-17 20:44:49 --> Form Validation Class Initialized
ERROR - 2018-01-17 20:44:49 --> Severity: error --> Exception: Unable to locate the model you have specified: M_general /home/instateccr/public_html/controlcostos/instatec_sys/core/Loader.php 344
INFO - 2018-01-17 20:48:11 --> Config Class Initialized
INFO - 2018-01-17 20:48:11 --> Hooks Class Initialized
DEBUG - 2018-01-17 20:48:11 --> UTF-8 Support Enabled
INFO - 2018-01-17 20:48:11 --> Utf8 Class Initialized
INFO - 2018-01-17 20:48:11 --> URI Class Initialized
DEBUG - 2018-01-17 20:48:11 --> No URI present. Default controller set.
INFO - 2018-01-17 20:48:11 --> Router Class Initialized
INFO - 2018-01-17 20:48:11 --> Output Class Initialized
INFO - 2018-01-17 20:48:11 --> Security Class Initialized
DEBUG - 2018-01-17 20:48:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 20:48:11 --> Input Class Initialized
INFO - 2018-01-17 20:48:11 --> Language Class Initialized
INFO - 2018-01-17 20:48:11 --> Loader Class Initialized
INFO - 2018-01-17 20:48:11 --> Helper loaded: url_helper
INFO - 2018-01-17 20:48:11 --> Helper loaded: form_helper
INFO - 2018-01-17 20:48:11 --> Database Driver Class Initialized
DEBUG - 2018-01-17 20:48:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-17 20:48:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-17 20:48:11 --> Form Validation Class Initialized
ERROR - 2018-01-17 20:48:11 --> Severity: error --> Exception: Unable to locate the model you have specified: M_general /home/instateccr/public_html/controlcostos/instatec_sys/core/Loader.php 344
INFO - 2018-01-17 20:48:12 --> Config Class Initialized
INFO - 2018-01-17 20:48:12 --> Hooks Class Initialized
DEBUG - 2018-01-17 20:48:12 --> UTF-8 Support Enabled
INFO - 2018-01-17 20:48:12 --> Utf8 Class Initialized
INFO - 2018-01-17 20:48:12 --> URI Class Initialized
DEBUG - 2018-01-17 20:48:12 --> No URI present. Default controller set.
INFO - 2018-01-17 20:48:12 --> Router Class Initialized
INFO - 2018-01-17 20:48:12 --> Output Class Initialized
INFO - 2018-01-17 20:48:12 --> Security Class Initialized
DEBUG - 2018-01-17 20:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 20:48:12 --> Input Class Initialized
INFO - 2018-01-17 20:48:12 --> Language Class Initialized
INFO - 2018-01-17 20:48:12 --> Loader Class Initialized
INFO - 2018-01-17 20:48:12 --> Helper loaded: url_helper
INFO - 2018-01-17 20:48:12 --> Helper loaded: form_helper
INFO - 2018-01-17 20:48:12 --> Database Driver Class Initialized
DEBUG - 2018-01-17 20:48:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-17 20:48:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-17 20:48:12 --> Form Validation Class Initialized
ERROR - 2018-01-17 20:48:12 --> Severity: error --> Exception: Unable to locate the model you have specified: M_general /home/instateccr/public_html/controlcostos/instatec_sys/core/Loader.php 344
INFO - 2018-01-17 20:48:38 --> Config Class Initialized
INFO - 2018-01-17 20:48:38 --> Hooks Class Initialized
DEBUG - 2018-01-17 20:48:38 --> UTF-8 Support Enabled
INFO - 2018-01-17 20:48:38 --> Utf8 Class Initialized
INFO - 2018-01-17 20:48:38 --> URI Class Initialized
DEBUG - 2018-01-17 20:48:38 --> No URI present. Default controller set.
INFO - 2018-01-17 20:48:38 --> Router Class Initialized
INFO - 2018-01-17 20:48:38 --> Output Class Initialized
INFO - 2018-01-17 20:48:38 --> Security Class Initialized
DEBUG - 2018-01-17 20:48:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 20:48:38 --> Input Class Initialized
INFO - 2018-01-17 20:48:38 --> Language Class Initialized
INFO - 2018-01-17 20:48:38 --> Loader Class Initialized
INFO - 2018-01-17 20:48:38 --> Helper loaded: url_helper
INFO - 2018-01-17 20:48:38 --> Helper loaded: form_helper
INFO - 2018-01-17 20:48:38 --> Database Driver Class Initialized
DEBUG - 2018-01-17 20:48:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-17 20:48:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-17 20:48:38 --> Form Validation Class Initialized
ERROR - 2018-01-17 20:48:38 --> Severity: error --> Exception: Unable to locate the model you have specified: M_general /home/instateccr/public_html/controlcostos/instatec_sys/core/Loader.php 344
INFO - 2018-01-17 20:49:28 --> Config Class Initialized
INFO - 2018-01-17 20:49:28 --> Hooks Class Initialized
DEBUG - 2018-01-17 20:49:28 --> UTF-8 Support Enabled
INFO - 2018-01-17 20:49:28 --> Utf8 Class Initialized
INFO - 2018-01-17 20:49:28 --> URI Class Initialized
DEBUG - 2018-01-17 20:49:28 --> No URI present. Default controller set.
INFO - 2018-01-17 20:49:28 --> Router Class Initialized
INFO - 2018-01-17 20:49:28 --> Output Class Initialized
INFO - 2018-01-17 20:49:28 --> Security Class Initialized
DEBUG - 2018-01-17 20:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 20:49:28 --> Input Class Initialized
INFO - 2018-01-17 20:49:28 --> Language Class Initialized
INFO - 2018-01-17 20:49:28 --> Loader Class Initialized
INFO - 2018-01-17 20:49:28 --> Helper loaded: url_helper
INFO - 2018-01-17 20:49:28 --> Helper loaded: form_helper
INFO - 2018-01-17 20:49:28 --> Database Driver Class Initialized
DEBUG - 2018-01-17 20:49:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-17 20:49:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-17 20:49:28 --> Form Validation Class Initialized
INFO - 2018-01-17 20:49:28 --> Model Class Initialized
INFO - 2018-01-17 20:49:28 --> Controller Class Initialized
INFO - 2018-01-17 20:50:41 --> Config Class Initialized
INFO - 2018-01-17 20:50:41 --> Hooks Class Initialized
DEBUG - 2018-01-17 20:50:41 --> UTF-8 Support Enabled
INFO - 2018-01-17 20:50:41 --> Utf8 Class Initialized
INFO - 2018-01-17 20:50:41 --> URI Class Initialized
INFO - 2018-01-17 20:50:41 --> Router Class Initialized
INFO - 2018-01-17 20:50:41 --> Output Class Initialized
INFO - 2018-01-17 20:50:41 --> Security Class Initialized
DEBUG - 2018-01-17 20:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 20:50:41 --> Input Class Initialized
INFO - 2018-01-17 20:50:41 --> Language Class Initialized
INFO - 2018-01-17 20:50:41 --> Loader Class Initialized
INFO - 2018-01-17 20:50:41 --> Helper loaded: url_helper
INFO - 2018-01-17 20:50:41 --> Helper loaded: form_helper
INFO - 2018-01-17 20:50:41 --> Database Driver Class Initialized
DEBUG - 2018-01-17 20:50:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-17 20:50:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-17 20:50:41 --> Form Validation Class Initialized
INFO - 2018-01-17 20:50:41 --> Model Class Initialized
INFO - 2018-01-17 20:50:41 --> Controller Class Initialized
INFO - 2018-01-17 20:50:41 --> Model Class Initialized
DEBUG - 2018-01-17 20:50:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-17 20:50:41 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-17 20:50:41 --> Final output sent to browser
DEBUG - 2018-01-17 20:50:41 --> Total execution time: 0.0340
INFO - 2018-01-17 20:51:46 --> Config Class Initialized
INFO - 2018-01-17 20:51:46 --> Hooks Class Initialized
DEBUG - 2018-01-17 20:51:46 --> UTF-8 Support Enabled
INFO - 2018-01-17 20:51:46 --> Utf8 Class Initialized
INFO - 2018-01-17 20:51:46 --> URI Class Initialized
INFO - 2018-01-17 20:51:46 --> Router Class Initialized
INFO - 2018-01-17 20:51:46 --> Output Class Initialized
INFO - 2018-01-17 20:51:46 --> Security Class Initialized
DEBUG - 2018-01-17 20:51:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 20:51:46 --> Input Class Initialized
INFO - 2018-01-17 20:51:46 --> Language Class Initialized
INFO - 2018-01-17 20:51:46 --> Loader Class Initialized
INFO - 2018-01-17 20:51:46 --> Helper loaded: url_helper
INFO - 2018-01-17 20:51:46 --> Helper loaded: form_helper
INFO - 2018-01-17 20:51:46 --> Database Driver Class Initialized
DEBUG - 2018-01-17 20:51:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-17 20:51:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-17 20:51:46 --> Form Validation Class Initialized
INFO - 2018-01-17 20:51:46 --> Model Class Initialized
INFO - 2018-01-17 20:51:46 --> Controller Class Initialized
INFO - 2018-01-17 20:51:46 --> Model Class Initialized
DEBUG - 2018-01-17 20:51:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-17 20:51:46 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-17 20:51:46 --> Final output sent to browser
DEBUG - 2018-01-17 20:51:46 --> Total execution time: 0.0352
INFO - 2018-01-17 20:51:47 --> Config Class Initialized
INFO - 2018-01-17 20:51:47 --> Hooks Class Initialized
DEBUG - 2018-01-17 20:51:47 --> UTF-8 Support Enabled
INFO - 2018-01-17 20:51:47 --> Utf8 Class Initialized
INFO - 2018-01-17 20:51:47 --> URI Class Initialized
INFO - 2018-01-17 20:51:47 --> Router Class Initialized
INFO - 2018-01-17 20:51:47 --> Output Class Initialized
INFO - 2018-01-17 20:51:47 --> Security Class Initialized
DEBUG - 2018-01-17 20:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 20:51:47 --> Input Class Initialized
INFO - 2018-01-17 20:51:47 --> Language Class Initialized
ERROR - 2018-01-17 20:51:47 --> 404 Page Not Found: Login/instatec_pub
INFO - 2018-01-17 20:51:47 --> Config Class Initialized
INFO - 2018-01-17 20:51:47 --> Hooks Class Initialized
DEBUG - 2018-01-17 20:51:47 --> UTF-8 Support Enabled
INFO - 2018-01-17 20:51:47 --> Utf8 Class Initialized
INFO - 2018-01-17 20:51:47 --> Config Class Initialized
INFO - 2018-01-17 20:51:47 --> Hooks Class Initialized
INFO - 2018-01-17 20:51:47 --> URI Class Initialized
INFO - 2018-01-17 20:51:47 --> Router Class Initialized
DEBUG - 2018-01-17 20:51:47 --> UTF-8 Support Enabled
INFO - 2018-01-17 20:51:47 --> Utf8 Class Initialized
INFO - 2018-01-17 20:51:47 --> URI Class Initialized
INFO - 2018-01-17 20:51:47 --> Output Class Initialized
INFO - 2018-01-17 20:51:47 --> Router Class Initialized
INFO - 2018-01-17 20:51:47 --> Security Class Initialized
DEBUG - 2018-01-17 20:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 20:51:47 --> Output Class Initialized
INFO - 2018-01-17 20:51:47 --> Input Class Initialized
INFO - 2018-01-17 20:51:47 --> Language Class Initialized
ERROR - 2018-01-17 20:51:47 --> 404 Page Not Found: Login/instatec_pub
INFO - 2018-01-17 20:51:47 --> Security Class Initialized
DEBUG - 2018-01-17 20:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 20:51:47 --> Input Class Initialized
INFO - 2018-01-17 20:51:47 --> Language Class Initialized
INFO - 2018-01-17 20:51:47 --> Config Class Initialized
INFO - 2018-01-17 20:51:47 --> Hooks Class Initialized
ERROR - 2018-01-17 20:51:47 --> 404 Page Not Found: Login/instatec_pub
DEBUG - 2018-01-17 20:51:47 --> UTF-8 Support Enabled
INFO - 2018-01-17 20:51:47 --> Utf8 Class Initialized
INFO - 2018-01-17 20:51:47 --> URI Class Initialized
INFO - 2018-01-17 20:51:47 --> Router Class Initialized
INFO - 2018-01-17 20:51:47 --> Output Class Initialized
INFO - 2018-01-17 20:51:47 --> Security Class Initialized
DEBUG - 2018-01-17 20:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 20:51:47 --> Input Class Initialized
INFO - 2018-01-17 20:51:47 --> Language Class Initialized
ERROR - 2018-01-17 20:51:47 --> 404 Page Not Found: Login/instatec_pub
INFO - 2018-01-17 20:51:47 --> Config Class Initialized
INFO - 2018-01-17 20:51:47 --> Hooks Class Initialized
DEBUG - 2018-01-17 20:51:47 --> UTF-8 Support Enabled
INFO - 2018-01-17 20:51:47 --> Utf8 Class Initialized
INFO - 2018-01-17 20:51:47 --> URI Class Initialized
INFO - 2018-01-17 20:51:47 --> Router Class Initialized
INFO - 2018-01-17 20:51:47 --> Output Class Initialized
INFO - 2018-01-17 20:51:47 --> Security Class Initialized
DEBUG - 2018-01-17 20:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 20:51:47 --> Input Class Initialized
INFO - 2018-01-17 20:51:47 --> Language Class Initialized
ERROR - 2018-01-17 20:51:47 --> 404 Page Not Found: Login/instatec_pub
INFO - 2018-01-17 20:51:47 --> Config Class Initialized
INFO - 2018-01-17 20:51:47 --> Hooks Class Initialized
DEBUG - 2018-01-17 20:51:47 --> UTF-8 Support Enabled
INFO - 2018-01-17 20:51:47 --> Utf8 Class Initialized
INFO - 2018-01-17 20:51:47 --> URI Class Initialized
INFO - 2018-01-17 20:51:47 --> Router Class Initialized
INFO - 2018-01-17 20:51:47 --> Output Class Initialized
INFO - 2018-01-17 20:51:47 --> Security Class Initialized
DEBUG - 2018-01-17 20:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 20:51:47 --> Input Class Initialized
INFO - 2018-01-17 20:51:47 --> Language Class Initialized
ERROR - 2018-01-17 20:51:47 --> 404 Page Not Found: Login/instatec_pub
INFO - 2018-01-17 20:51:48 --> Config Class Initialized
INFO - 2018-01-17 20:51:48 --> Hooks Class Initialized
DEBUG - 2018-01-17 20:51:48 --> UTF-8 Support Enabled
INFO - 2018-01-17 20:51:48 --> Utf8 Class Initialized
INFO - 2018-01-17 20:51:48 --> URI Class Initialized
INFO - 2018-01-17 20:51:48 --> Router Class Initialized
INFO - 2018-01-17 20:51:48 --> Output Class Initialized
INFO - 2018-01-17 20:51:48 --> Config Class Initialized
INFO - 2018-01-17 20:51:48 --> Hooks Class Initialized
INFO - 2018-01-17 20:51:48 --> Security Class Initialized
DEBUG - 2018-01-17 20:51:48 --> UTF-8 Support Enabled
INFO - 2018-01-17 20:51:48 --> Utf8 Class Initialized
DEBUG - 2018-01-17 20:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 20:51:48 --> Input Class Initialized
INFO - 2018-01-17 20:51:48 --> URI Class Initialized
INFO - 2018-01-17 20:51:48 --> Language Class Initialized
ERROR - 2018-01-17 20:51:48 --> 404 Page Not Found: Login/instatec_pub
INFO - 2018-01-17 20:51:48 --> Router Class Initialized
INFO - 2018-01-17 20:51:48 --> Output Class Initialized
INFO - 2018-01-17 20:51:48 --> Security Class Initialized
DEBUG - 2018-01-17 20:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 20:51:48 --> Input Class Initialized
INFO - 2018-01-17 20:51:48 --> Language Class Initialized
ERROR - 2018-01-17 20:51:48 --> 404 Page Not Found: Login/instatec_pub
INFO - 2018-01-17 20:51:48 --> Config Class Initialized
INFO - 2018-01-17 20:51:48 --> Hooks Class Initialized
DEBUG - 2018-01-17 20:51:48 --> UTF-8 Support Enabled
INFO - 2018-01-17 20:51:48 --> Utf8 Class Initialized
INFO - 2018-01-17 20:51:48 --> URI Class Initialized
INFO - 2018-01-17 20:51:48 --> Router Class Initialized
INFO - 2018-01-17 20:51:48 --> Output Class Initialized
INFO - 2018-01-17 20:51:48 --> Security Class Initialized
INFO - 2018-01-17 20:51:48 --> Config Class Initialized
INFO - 2018-01-17 20:51:48 --> Hooks Class Initialized
DEBUG - 2018-01-17 20:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 20:51:48 --> Input Class Initialized
INFO - 2018-01-17 20:51:48 --> Language Class Initialized
ERROR - 2018-01-17 20:51:48 --> 404 Page Not Found: Login/instatec_pub
INFO - 2018-01-17 20:51:48 --> Config Class Initialized
INFO - 2018-01-17 20:51:48 --> Hooks Class Initialized
DEBUG - 2018-01-17 20:51:48 --> UTF-8 Support Enabled
INFO - 2018-01-17 20:51:48 --> Utf8 Class Initialized
INFO - 2018-01-17 20:51:48 --> URI Class Initialized
DEBUG - 2018-01-17 20:51:48 --> UTF-8 Support Enabled
INFO - 2018-01-17 20:51:48 --> Utf8 Class Initialized
INFO - 2018-01-17 20:51:48 --> Router Class Initialized
INFO - 2018-01-17 20:51:48 --> URI Class Initialized
INFO - 2018-01-17 20:51:48 --> Router Class Initialized
INFO - 2018-01-17 20:51:48 --> Output Class Initialized
INFO - 2018-01-17 20:51:48 --> Security Class Initialized
INFO - 2018-01-17 20:51:48 --> Output Class Initialized
DEBUG - 2018-01-17 20:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 20:51:48 --> Input Class Initialized
INFO - 2018-01-17 20:51:48 --> Security Class Initialized
INFO - 2018-01-17 20:51:48 --> Language Class Initialized
ERROR - 2018-01-17 20:51:48 --> 404 Page Not Found: Login/instatec_pub
DEBUG - 2018-01-17 20:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 20:51:48 --> Input Class Initialized
INFO - 2018-01-17 20:51:48 --> Language Class Initialized
ERROR - 2018-01-17 20:51:48 --> 404 Page Not Found: Login/instatec_pub
INFO - 2018-01-17 20:51:48 --> Config Class Initialized
INFO - 2018-01-17 20:51:48 --> Hooks Class Initialized
DEBUG - 2018-01-17 20:51:48 --> UTF-8 Support Enabled
INFO - 2018-01-17 20:51:48 --> Utf8 Class Initialized
INFO - 2018-01-17 20:51:48 --> URI Class Initialized
INFO - 2018-01-17 20:51:48 --> Router Class Initialized
INFO - 2018-01-17 20:51:48 --> Output Class Initialized
INFO - 2018-01-17 20:51:48 --> Security Class Initialized
DEBUG - 2018-01-17 20:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 20:51:48 --> Input Class Initialized
INFO - 2018-01-17 20:51:48 --> Language Class Initialized
ERROR - 2018-01-17 20:51:48 --> 404 Page Not Found: Login/instatec_pub
INFO - 2018-01-17 20:51:48 --> Config Class Initialized
INFO - 2018-01-17 20:51:48 --> Hooks Class Initialized
DEBUG - 2018-01-17 20:51:48 --> UTF-8 Support Enabled
INFO - 2018-01-17 20:51:48 --> Utf8 Class Initialized
INFO - 2018-01-17 20:51:48 --> URI Class Initialized
INFO - 2018-01-17 20:51:48 --> Router Class Initialized
INFO - 2018-01-17 20:51:48 --> Output Class Initialized
INFO - 2018-01-17 20:51:48 --> Security Class Initialized
DEBUG - 2018-01-17 20:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 20:51:48 --> Input Class Initialized
INFO - 2018-01-17 20:51:48 --> Language Class Initialized
ERROR - 2018-01-17 20:51:48 --> 404 Page Not Found: Login/instatec_pub
INFO - 2018-01-17 20:51:48 --> Config Class Initialized
INFO - 2018-01-17 20:51:48 --> Config Class Initialized
INFO - 2018-01-17 20:51:48 --> Hooks Class Initialized
INFO - 2018-01-17 20:51:48 --> Hooks Class Initialized
DEBUG - 2018-01-17 20:51:48 --> UTF-8 Support Enabled
DEBUG - 2018-01-17 20:51:48 --> UTF-8 Support Enabled
INFO - 2018-01-17 20:51:48 --> Utf8 Class Initialized
INFO - 2018-01-17 20:51:48 --> Utf8 Class Initialized
INFO - 2018-01-17 20:51:48 --> URI Class Initialized
INFO - 2018-01-17 20:51:48 --> URI Class Initialized
INFO - 2018-01-17 20:51:48 --> Router Class Initialized
INFO - 2018-01-17 20:51:48 --> Router Class Initialized
INFO - 2018-01-17 20:51:48 --> Output Class Initialized
INFO - 2018-01-17 20:51:48 --> Output Class Initialized
INFO - 2018-01-17 20:51:48 --> Security Class Initialized
INFO - 2018-01-17 20:51:48 --> Security Class Initialized
DEBUG - 2018-01-17 20:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 20:51:48 --> Input Class Initialized
INFO - 2018-01-17 20:51:48 --> Language Class Initialized
ERROR - 2018-01-17 20:51:48 --> 404 Page Not Found: Login/instatec_pub
DEBUG - 2018-01-17 20:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 20:51:48 --> Input Class Initialized
INFO - 2018-01-17 20:51:48 --> Language Class Initialized
ERROR - 2018-01-17 20:51:48 --> 404 Page Not Found: Login/instatec_pub
INFO - 2018-01-17 20:51:48 --> Config Class Initialized
INFO - 2018-01-17 20:51:48 --> Hooks Class Initialized
DEBUG - 2018-01-17 20:51:48 --> UTF-8 Support Enabled
INFO - 2018-01-17 20:51:48 --> Utf8 Class Initialized
INFO - 2018-01-17 20:51:48 --> URI Class Initialized
INFO - 2018-01-17 20:51:48 --> Router Class Initialized
INFO - 2018-01-17 20:51:48 --> Output Class Initialized
INFO - 2018-01-17 20:51:48 --> Security Class Initialized
DEBUG - 2018-01-17 20:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 20:51:48 --> Input Class Initialized
INFO - 2018-01-17 20:51:48 --> Language Class Initialized
ERROR - 2018-01-17 20:51:48 --> 404 Page Not Found: Login/instatec_pub
INFO - 2018-01-17 20:51:48 --> Config Class Initialized
INFO - 2018-01-17 20:51:48 --> Hooks Class Initialized
DEBUG - 2018-01-17 20:51:48 --> UTF-8 Support Enabled
INFO - 2018-01-17 20:51:48 --> Utf8 Class Initialized
INFO - 2018-01-17 20:51:48 --> URI Class Initialized
INFO - 2018-01-17 20:51:48 --> Router Class Initialized
INFO - 2018-01-17 20:51:48 --> Output Class Initialized
INFO - 2018-01-17 20:51:48 --> Security Class Initialized
DEBUG - 2018-01-17 20:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 20:51:48 --> Input Class Initialized
INFO - 2018-01-17 20:51:48 --> Language Class Initialized
ERROR - 2018-01-17 20:51:48 --> 404 Page Not Found: Login/instatec_pub
INFO - 2018-01-17 20:51:48 --> Config Class Initialized
INFO - 2018-01-17 20:51:48 --> Hooks Class Initialized
DEBUG - 2018-01-17 20:51:48 --> UTF-8 Support Enabled
INFO - 2018-01-17 20:51:48 --> Utf8 Class Initialized
INFO - 2018-01-17 20:51:48 --> URI Class Initialized
INFO - 2018-01-17 20:51:48 --> Router Class Initialized
INFO - 2018-01-17 20:51:48 --> Output Class Initialized
INFO - 2018-01-17 20:51:48 --> Security Class Initialized
DEBUG - 2018-01-17 20:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 20:51:48 --> Input Class Initialized
INFO - 2018-01-17 20:51:48 --> Language Class Initialized
ERROR - 2018-01-17 20:51:48 --> 404 Page Not Found: Login/instatec_pub
INFO - 2018-01-17 20:51:48 --> Config Class Initialized
INFO - 2018-01-17 20:51:48 --> Hooks Class Initialized
DEBUG - 2018-01-17 20:51:48 --> UTF-8 Support Enabled
INFO - 2018-01-17 20:51:48 --> Utf8 Class Initialized
INFO - 2018-01-17 20:51:48 --> URI Class Initialized
INFO - 2018-01-17 20:51:48 --> Router Class Initialized
INFO - 2018-01-17 20:51:48 --> Output Class Initialized
INFO - 2018-01-17 20:51:48 --> Security Class Initialized
DEBUG - 2018-01-17 20:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 20:51:48 --> Input Class Initialized
INFO - 2018-01-17 20:51:48 --> Language Class Initialized
ERROR - 2018-01-17 20:51:48 --> 404 Page Not Found: Login/instatec_pub
INFO - 2018-01-17 20:51:48 --> Config Class Initialized
INFO - 2018-01-17 20:51:48 --> Hooks Class Initialized
DEBUG - 2018-01-17 20:51:48 --> UTF-8 Support Enabled
INFO - 2018-01-17 20:51:48 --> Utf8 Class Initialized
INFO - 2018-01-17 20:51:48 --> URI Class Initialized
INFO - 2018-01-17 20:51:48 --> Router Class Initialized
INFO - 2018-01-17 20:51:48 --> Output Class Initialized
INFO - 2018-01-17 20:51:48 --> Security Class Initialized
DEBUG - 2018-01-17 20:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 20:51:48 --> Input Class Initialized
INFO - 2018-01-17 20:51:48 --> Language Class Initialized
ERROR - 2018-01-17 20:51:48 --> 404 Page Not Found: Login/instatec_pub
INFO - 2018-01-17 20:51:49 --> Config Class Initialized
INFO - 2018-01-17 20:51:49 --> Hooks Class Initialized
DEBUG - 2018-01-17 20:51:49 --> UTF-8 Support Enabled
INFO - 2018-01-17 20:51:49 --> Utf8 Class Initialized
INFO - 2018-01-17 20:51:49 --> URI Class Initialized
INFO - 2018-01-17 20:51:49 --> Router Class Initialized
INFO - 2018-01-17 20:51:49 --> Output Class Initialized
INFO - 2018-01-17 20:51:49 --> Security Class Initialized
DEBUG - 2018-01-17 20:51:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 20:51:49 --> Input Class Initialized
INFO - 2018-01-17 20:51:49 --> Language Class Initialized
ERROR - 2018-01-17 20:51:49 --> 404 Page Not Found: Login/instatec_pub
INFO - 2018-01-17 20:51:49 --> Config Class Initialized
INFO - 2018-01-17 20:51:49 --> Hooks Class Initialized
DEBUG - 2018-01-17 20:51:49 --> UTF-8 Support Enabled
INFO - 2018-01-17 20:51:49 --> Utf8 Class Initialized
INFO - 2018-01-17 20:51:49 --> URI Class Initialized
INFO - 2018-01-17 20:51:49 --> Router Class Initialized
INFO - 2018-01-17 20:51:49 --> Output Class Initialized
INFO - 2018-01-17 20:51:49 --> Security Class Initialized
DEBUG - 2018-01-17 20:51:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 20:51:49 --> Input Class Initialized
INFO - 2018-01-17 20:51:49 --> Language Class Initialized
ERROR - 2018-01-17 20:51:49 --> 404 Page Not Found: Login/instatec_pub
INFO - 2018-01-17 20:51:50 --> Config Class Initialized
INFO - 2018-01-17 20:51:50 --> Hooks Class Initialized
DEBUG - 2018-01-17 20:51:50 --> UTF-8 Support Enabled
INFO - 2018-01-17 20:51:50 --> Utf8 Class Initialized
INFO - 2018-01-17 20:51:50 --> URI Class Initialized
INFO - 2018-01-17 20:51:50 --> Router Class Initialized
INFO - 2018-01-17 20:51:50 --> Output Class Initialized
INFO - 2018-01-17 20:51:50 --> Security Class Initialized
DEBUG - 2018-01-17 20:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 20:51:50 --> Input Class Initialized
INFO - 2018-01-17 20:51:50 --> Language Class Initialized
ERROR - 2018-01-17 20:51:50 --> 404 Page Not Found: Login/instatec_pub
INFO - 2018-01-17 20:51:51 --> Config Class Initialized
INFO - 2018-01-17 20:51:51 --> Hooks Class Initialized
DEBUG - 2018-01-17 20:51:51 --> UTF-8 Support Enabled
INFO - 2018-01-17 20:51:51 --> Utf8 Class Initialized
INFO - 2018-01-17 20:51:51 --> URI Class Initialized
INFO - 2018-01-17 20:51:51 --> Router Class Initialized
INFO - 2018-01-17 20:51:51 --> Output Class Initialized
INFO - 2018-01-17 20:51:51 --> Security Class Initialized
DEBUG - 2018-01-17 20:51:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 20:51:51 --> Input Class Initialized
INFO - 2018-01-17 20:51:51 --> Language Class Initialized
ERROR - 2018-01-17 20:51:51 --> 404 Page Not Found: Login/instatec_pub
INFO - 2018-01-17 20:51:54 --> Config Class Initialized
INFO - 2018-01-17 20:51:54 --> Hooks Class Initialized
DEBUG - 2018-01-17 20:51:54 --> UTF-8 Support Enabled
INFO - 2018-01-17 20:51:54 --> Utf8 Class Initialized
INFO - 2018-01-17 20:51:54 --> URI Class Initialized
INFO - 2018-01-17 20:51:54 --> Router Class Initialized
INFO - 2018-01-17 20:51:54 --> Output Class Initialized
INFO - 2018-01-17 20:51:54 --> Security Class Initialized
DEBUG - 2018-01-17 20:51:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 20:51:54 --> Input Class Initialized
INFO - 2018-01-17 20:51:54 --> Language Class Initialized
INFO - 2018-01-17 20:51:54 --> Loader Class Initialized
INFO - 2018-01-17 20:51:54 --> Helper loaded: url_helper
INFO - 2018-01-17 20:51:54 --> Helper loaded: form_helper
INFO - 2018-01-17 20:51:54 --> Database Driver Class Initialized
DEBUG - 2018-01-17 20:51:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-17 20:51:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-17 20:51:54 --> Form Validation Class Initialized
INFO - 2018-01-17 20:51:54 --> Model Class Initialized
INFO - 2018-01-17 20:51:54 --> Controller Class Initialized
INFO - 2018-01-17 20:51:54 --> Model Class Initialized
DEBUG - 2018-01-17 20:51:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-17 20:51:54 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-17 20:51:54 --> Final output sent to browser
DEBUG - 2018-01-17 20:51:54 --> Total execution time: 0.0364
INFO - 2018-01-17 20:51:54 --> Config Class Initialized
INFO - 2018-01-17 20:51:54 --> Hooks Class Initialized
DEBUG - 2018-01-17 20:51:54 --> UTF-8 Support Enabled
INFO - 2018-01-17 20:51:54 --> Utf8 Class Initialized
INFO - 2018-01-17 20:51:54 --> URI Class Initialized
INFO - 2018-01-17 20:51:54 --> Router Class Initialized
INFO - 2018-01-17 20:51:54 --> Output Class Initialized
INFO - 2018-01-17 20:51:54 --> Security Class Initialized
DEBUG - 2018-01-17 20:51:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 20:51:54 --> Input Class Initialized
INFO - 2018-01-17 20:51:54 --> Language Class Initialized
ERROR - 2018-01-17 20:51:54 --> 404 Page Not Found: Login/instatec_pub
INFO - 2018-01-17 20:51:54 --> Config Class Initialized
INFO - 2018-01-17 20:51:54 --> Hooks Class Initialized
DEBUG - 2018-01-17 20:51:54 --> UTF-8 Support Enabled
INFO - 2018-01-17 20:51:54 --> Utf8 Class Initialized
INFO - 2018-01-17 20:51:54 --> URI Class Initialized
INFO - 2018-01-17 20:51:54 --> Router Class Initialized
INFO - 2018-01-17 20:51:54 --> Output Class Initialized
INFO - 2018-01-17 20:51:54 --> Security Class Initialized
DEBUG - 2018-01-17 20:51:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 20:51:54 --> Input Class Initialized
INFO - 2018-01-17 20:51:54 --> Language Class Initialized
ERROR - 2018-01-17 20:51:54 --> 404 Page Not Found: Login/instatec_pub
INFO - 2018-01-17 20:51:54 --> Config Class Initialized
INFO - 2018-01-17 20:51:54 --> Hooks Class Initialized
DEBUG - 2018-01-17 20:51:54 --> UTF-8 Support Enabled
INFO - 2018-01-17 20:51:54 --> Utf8 Class Initialized
INFO - 2018-01-17 20:51:54 --> URI Class Initialized
INFO - 2018-01-17 20:51:54 --> Router Class Initialized
INFO - 2018-01-17 20:51:55 --> Output Class Initialized
INFO - 2018-01-17 20:51:55 --> Security Class Initialized
DEBUG - 2018-01-17 20:51:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 20:51:55 --> Input Class Initialized
INFO - 2018-01-17 20:51:55 --> Language Class Initialized
ERROR - 2018-01-17 20:51:55 --> 404 Page Not Found: Login/instatec_pub
INFO - 2018-01-17 20:51:55 --> Config Class Initialized
INFO - 2018-01-17 20:51:55 --> Hooks Class Initialized
DEBUG - 2018-01-17 20:51:55 --> UTF-8 Support Enabled
INFO - 2018-01-17 20:51:55 --> Utf8 Class Initialized
INFO - 2018-01-17 20:51:55 --> URI Class Initialized
INFO - 2018-01-17 20:51:55 --> Router Class Initialized
INFO - 2018-01-17 20:51:55 --> Config Class Initialized
INFO - 2018-01-17 20:51:55 --> Hooks Class Initialized
INFO - 2018-01-17 20:51:55 --> Output Class Initialized
DEBUG - 2018-01-17 20:51:55 --> UTF-8 Support Enabled
INFO - 2018-01-17 20:51:55 --> Utf8 Class Initialized
INFO - 2018-01-17 20:51:55 --> URI Class Initialized
INFO - 2018-01-17 20:51:55 --> Security Class Initialized
INFO - 2018-01-17 20:51:55 --> Router Class Initialized
DEBUG - 2018-01-17 20:51:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 20:51:55 --> Input Class Initialized
INFO - 2018-01-17 20:51:55 --> Language Class Initialized
ERROR - 2018-01-17 20:51:55 --> 404 Page Not Found: Login/instatec_pub
INFO - 2018-01-17 20:51:55 --> Output Class Initialized
INFO - 2018-01-17 20:51:55 --> Security Class Initialized
DEBUG - 2018-01-17 20:51:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 20:51:55 --> Input Class Initialized
INFO - 2018-01-17 20:51:55 --> Language Class Initialized
ERROR - 2018-01-17 20:51:55 --> 404 Page Not Found: Login/instatec_pub
INFO - 2018-01-17 20:51:55 --> Config Class Initialized
INFO - 2018-01-17 20:51:55 --> Hooks Class Initialized
DEBUG - 2018-01-17 20:51:55 --> UTF-8 Support Enabled
INFO - 2018-01-17 20:51:55 --> Utf8 Class Initialized
INFO - 2018-01-17 20:51:55 --> URI Class Initialized
INFO - 2018-01-17 20:51:55 --> Router Class Initialized
INFO - 2018-01-17 20:51:55 --> Output Class Initialized
INFO - 2018-01-17 20:51:55 --> Security Class Initialized
DEBUG - 2018-01-17 20:51:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 20:51:55 --> Input Class Initialized
INFO - 2018-01-17 20:51:55 --> Language Class Initialized
ERROR - 2018-01-17 20:51:55 --> 404 Page Not Found: Login/instatec_pub
INFO - 2018-01-17 20:51:55 --> Config Class Initialized
INFO - 2018-01-17 20:51:55 --> Hooks Class Initialized
DEBUG - 2018-01-17 20:51:55 --> UTF-8 Support Enabled
INFO - 2018-01-17 20:51:55 --> Utf8 Class Initialized
INFO - 2018-01-17 20:51:55 --> URI Class Initialized
INFO - 2018-01-17 20:51:55 --> Router Class Initialized
INFO - 2018-01-17 20:51:55 --> Output Class Initialized
INFO - 2018-01-17 20:51:55 --> Security Class Initialized
DEBUG - 2018-01-17 20:51:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 20:51:55 --> Input Class Initialized
INFO - 2018-01-17 20:51:55 --> Language Class Initialized
ERROR - 2018-01-17 20:51:55 --> 404 Page Not Found: Login/instatec_pub
INFO - 2018-01-17 20:51:55 --> Config Class Initialized
INFO - 2018-01-17 20:51:55 --> Hooks Class Initialized
DEBUG - 2018-01-17 20:51:55 --> UTF-8 Support Enabled
INFO - 2018-01-17 20:51:55 --> Utf8 Class Initialized
INFO - 2018-01-17 20:51:55 --> URI Class Initialized
INFO - 2018-01-17 20:51:55 --> Router Class Initialized
INFO - 2018-01-17 20:51:55 --> Output Class Initialized
INFO - 2018-01-17 20:51:55 --> Security Class Initialized
DEBUG - 2018-01-17 20:51:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 20:51:55 --> Input Class Initialized
INFO - 2018-01-17 20:51:55 --> Language Class Initialized
ERROR - 2018-01-17 20:51:55 --> 404 Page Not Found: Login/instatec_pub
INFO - 2018-01-17 20:51:55 --> Config Class Initialized
INFO - 2018-01-17 20:51:55 --> Hooks Class Initialized
DEBUG - 2018-01-17 20:51:55 --> UTF-8 Support Enabled
INFO - 2018-01-17 20:51:55 --> Utf8 Class Initialized
INFO - 2018-01-17 20:51:55 --> URI Class Initialized
INFO - 2018-01-17 20:51:55 --> Router Class Initialized
INFO - 2018-01-17 20:51:55 --> Output Class Initialized
INFO - 2018-01-17 20:51:55 --> Security Class Initialized
DEBUG - 2018-01-17 20:51:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 20:51:55 --> Input Class Initialized
INFO - 2018-01-17 20:51:55 --> Language Class Initialized
ERROR - 2018-01-17 20:51:55 --> 404 Page Not Found: Login/instatec_pub
INFO - 2018-01-17 20:51:55 --> Config Class Initialized
INFO - 2018-01-17 20:51:55 --> Hooks Class Initialized
INFO - 2018-01-17 20:51:55 --> Config Class Initialized
INFO - 2018-01-17 20:51:55 --> Hooks Class Initialized
DEBUG - 2018-01-17 20:51:55 --> UTF-8 Support Enabled
INFO - 2018-01-17 20:51:55 --> Utf8 Class Initialized
INFO - 2018-01-17 20:51:55 --> URI Class Initialized
INFO - 2018-01-17 20:51:55 --> Router Class Initialized
DEBUG - 2018-01-17 20:51:55 --> UTF-8 Support Enabled
INFO - 2018-01-17 20:51:55 --> Utf8 Class Initialized
INFO - 2018-01-17 20:51:55 --> URI Class Initialized
INFO - 2018-01-17 20:51:55 --> Output Class Initialized
INFO - 2018-01-17 20:51:55 --> Router Class Initialized
INFO - 2018-01-17 20:51:55 --> Security Class Initialized
INFO - 2018-01-17 20:51:55 --> Output Class Initialized
DEBUG - 2018-01-17 20:51:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 20:51:55 --> Input Class Initialized
INFO - 2018-01-17 20:51:55 --> Language Class Initialized
INFO - 2018-01-17 20:51:55 --> Security Class Initialized
ERROR - 2018-01-17 20:51:55 --> 404 Page Not Found: Login/instatec_pub
DEBUG - 2018-01-17 20:51:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 20:51:55 --> Input Class Initialized
INFO - 2018-01-17 20:51:55 --> Language Class Initialized
ERROR - 2018-01-17 20:51:55 --> 404 Page Not Found: Login/instatec_pub
INFO - 2018-01-17 20:51:55 --> Config Class Initialized
INFO - 2018-01-17 20:51:55 --> Hooks Class Initialized
DEBUG - 2018-01-17 20:51:55 --> UTF-8 Support Enabled
INFO - 2018-01-17 20:51:55 --> Utf8 Class Initialized
INFO - 2018-01-17 20:51:55 --> URI Class Initialized
INFO - 2018-01-17 20:51:55 --> Router Class Initialized
INFO - 2018-01-17 20:51:55 --> Output Class Initialized
INFO - 2018-01-17 20:51:55 --> Security Class Initialized
DEBUG - 2018-01-17 20:51:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 20:51:55 --> Input Class Initialized
INFO - 2018-01-17 20:51:55 --> Language Class Initialized
ERROR - 2018-01-17 20:51:55 --> 404 Page Not Found: Login/instatec_pub
INFO - 2018-01-17 20:51:55 --> Config Class Initialized
INFO - 2018-01-17 20:51:55 --> Hooks Class Initialized
INFO - 2018-01-17 20:51:55 --> Config Class Initialized
INFO - 2018-01-17 20:51:55 --> Hooks Class Initialized
DEBUG - 2018-01-17 20:51:55 --> UTF-8 Support Enabled
INFO - 2018-01-17 20:51:55 --> Utf8 Class Initialized
DEBUG - 2018-01-17 20:51:55 --> UTF-8 Support Enabled
INFO - 2018-01-17 20:51:55 --> Utf8 Class Initialized
INFO - 2018-01-17 20:51:55 --> URI Class Initialized
INFO - 2018-01-17 20:51:55 --> URI Class Initialized
INFO - 2018-01-17 20:51:55 --> Router Class Initialized
INFO - 2018-01-17 20:51:55 --> Router Class Initialized
INFO - 2018-01-17 20:51:55 --> Output Class Initialized
INFO - 2018-01-17 20:51:55 --> Output Class Initialized
INFO - 2018-01-17 20:51:55 --> Security Class Initialized
INFO - 2018-01-17 20:51:55 --> Security Class Initialized
DEBUG - 2018-01-17 20:51:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 20:51:55 --> Input Class Initialized
INFO - 2018-01-17 20:51:55 --> Language Class Initialized
DEBUG - 2018-01-17 20:51:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 20:51:55 --> Input Class Initialized
ERROR - 2018-01-17 20:51:55 --> 404 Page Not Found: Login/instatec_pub
INFO - 2018-01-17 20:51:55 --> Language Class Initialized
ERROR - 2018-01-17 20:51:55 --> 404 Page Not Found: Login/instatec_pub
INFO - 2018-01-17 20:51:55 --> Config Class Initialized
INFO - 2018-01-17 20:51:55 --> Hooks Class Initialized
DEBUG - 2018-01-17 20:51:55 --> UTF-8 Support Enabled
INFO - 2018-01-17 20:51:55 --> Utf8 Class Initialized
INFO - 2018-01-17 20:51:55 --> URI Class Initialized
INFO - 2018-01-17 20:51:55 --> Router Class Initialized
INFO - 2018-01-17 20:51:55 --> Output Class Initialized
INFO - 2018-01-17 20:51:55 --> Security Class Initialized
DEBUG - 2018-01-17 20:51:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 20:51:55 --> Input Class Initialized
INFO - 2018-01-17 20:51:55 --> Language Class Initialized
ERROR - 2018-01-17 20:51:55 --> 404 Page Not Found: Login/instatec_pub
INFO - 2018-01-17 20:51:56 --> Config Class Initialized
INFO - 2018-01-17 20:51:56 --> Hooks Class Initialized
DEBUG - 2018-01-17 20:51:56 --> UTF-8 Support Enabled
INFO - 2018-01-17 20:51:56 --> Utf8 Class Initialized
INFO - 2018-01-17 20:51:56 --> URI Class Initialized
INFO - 2018-01-17 20:51:56 --> Router Class Initialized
INFO - 2018-01-17 20:51:56 --> Output Class Initialized
INFO - 2018-01-17 20:51:56 --> Security Class Initialized
DEBUG - 2018-01-17 20:51:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 20:51:56 --> Input Class Initialized
INFO - 2018-01-17 20:51:56 --> Language Class Initialized
ERROR - 2018-01-17 20:51:56 --> 404 Page Not Found: Login/instatec_pub
INFO - 2018-01-17 20:51:56 --> Config Class Initialized
INFO - 2018-01-17 20:51:56 --> Hooks Class Initialized
DEBUG - 2018-01-17 20:51:56 --> UTF-8 Support Enabled
INFO - 2018-01-17 20:51:56 --> Utf8 Class Initialized
INFO - 2018-01-17 20:51:56 --> URI Class Initialized
INFO - 2018-01-17 20:51:56 --> Router Class Initialized
INFO - 2018-01-17 20:51:56 --> Output Class Initialized
INFO - 2018-01-17 20:51:56 --> Security Class Initialized
DEBUG - 2018-01-17 20:51:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 20:51:56 --> Input Class Initialized
INFO - 2018-01-17 20:51:56 --> Language Class Initialized
ERROR - 2018-01-17 20:51:56 --> 404 Page Not Found: Login/instatec_pub
INFO - 2018-01-17 20:51:56 --> Config Class Initialized
INFO - 2018-01-17 20:51:56 --> Hooks Class Initialized
DEBUG - 2018-01-17 20:51:56 --> UTF-8 Support Enabled
INFO - 2018-01-17 20:51:56 --> Utf8 Class Initialized
INFO - 2018-01-17 20:51:56 --> URI Class Initialized
INFO - 2018-01-17 20:51:56 --> Router Class Initialized
INFO - 2018-01-17 20:51:56 --> Output Class Initialized
INFO - 2018-01-17 20:51:56 --> Security Class Initialized
DEBUG - 2018-01-17 20:51:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 20:51:56 --> Input Class Initialized
INFO - 2018-01-17 20:51:56 --> Language Class Initialized
ERROR - 2018-01-17 20:51:56 --> 404 Page Not Found: Login/instatec_pub
INFO - 2018-01-17 20:51:56 --> Config Class Initialized
INFO - 2018-01-17 20:51:56 --> Hooks Class Initialized
DEBUG - 2018-01-17 20:51:56 --> UTF-8 Support Enabled
INFO - 2018-01-17 20:51:56 --> Utf8 Class Initialized
INFO - 2018-01-17 20:51:56 --> URI Class Initialized
INFO - 2018-01-17 20:51:56 --> Router Class Initialized
INFO - 2018-01-17 20:51:56 --> Output Class Initialized
INFO - 2018-01-17 20:51:56 --> Security Class Initialized
DEBUG - 2018-01-17 20:51:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 20:51:56 --> Input Class Initialized
INFO - 2018-01-17 20:51:56 --> Language Class Initialized
ERROR - 2018-01-17 20:51:56 --> 404 Page Not Found: Login/instatec_pub
INFO - 2018-01-17 20:52:03 --> Config Class Initialized
INFO - 2018-01-17 20:52:03 --> Hooks Class Initialized
DEBUG - 2018-01-17 20:52:03 --> UTF-8 Support Enabled
INFO - 2018-01-17 20:52:03 --> Utf8 Class Initialized
INFO - 2018-01-17 20:52:03 --> URI Class Initialized
INFO - 2018-01-17 20:52:03 --> Router Class Initialized
INFO - 2018-01-17 20:52:03 --> Output Class Initialized
INFO - 2018-01-17 20:52:03 --> Security Class Initialized
DEBUG - 2018-01-17 20:52:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 20:52:03 --> Input Class Initialized
INFO - 2018-01-17 20:52:03 --> Language Class Initialized
ERROR - 2018-01-17 20:52:03 --> 404 Page Not Found: Login/instatec_pub
INFO - 2018-01-17 20:52:03 --> Config Class Initialized
INFO - 2018-01-17 20:52:03 --> Hooks Class Initialized
DEBUG - 2018-01-17 20:52:03 --> UTF-8 Support Enabled
INFO - 2018-01-17 20:52:03 --> Utf8 Class Initialized
INFO - 2018-01-17 20:52:03 --> URI Class Initialized
INFO - 2018-01-17 20:52:03 --> Router Class Initialized
INFO - 2018-01-17 20:52:03 --> Output Class Initialized
INFO - 2018-01-17 20:52:03 --> Security Class Initialized
DEBUG - 2018-01-17 20:52:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 20:52:03 --> Input Class Initialized
INFO - 2018-01-17 20:52:03 --> Language Class Initialized
ERROR - 2018-01-17 20:52:03 --> 404 Page Not Found: Login/instatec_pub
INFO - 2018-01-17 20:52:03 --> Config Class Initialized
INFO - 2018-01-17 20:52:03 --> Hooks Class Initialized
INFO - 2018-01-17 20:52:03 --> Config Class Initialized
INFO - 2018-01-17 20:52:03 --> Hooks Class Initialized
DEBUG - 2018-01-17 20:52:03 --> UTF-8 Support Enabled
INFO - 2018-01-17 20:52:03 --> Utf8 Class Initialized
DEBUG - 2018-01-17 20:52:03 --> UTF-8 Support Enabled
INFO - 2018-01-17 20:52:03 --> Utf8 Class Initialized
INFO - 2018-01-17 20:52:03 --> URI Class Initialized
INFO - 2018-01-17 20:52:03 --> Config Class Initialized
INFO - 2018-01-17 20:52:03 --> URI Class Initialized
INFO - 2018-01-17 20:52:03 --> Hooks Class Initialized
INFO - 2018-01-17 20:52:03 --> Config Class Initialized
INFO - 2018-01-17 20:52:03 --> Hooks Class Initialized
INFO - 2018-01-17 20:52:03 --> Router Class Initialized
INFO - 2018-01-17 20:52:03 --> Router Class Initialized
DEBUG - 2018-01-17 20:52:03 --> UTF-8 Support Enabled
INFO - 2018-01-17 20:52:03 --> Utf8 Class Initialized
DEBUG - 2018-01-17 20:52:03 --> UTF-8 Support Enabled
INFO - 2018-01-17 20:52:03 --> Utf8 Class Initialized
INFO - 2018-01-17 20:52:03 --> Output Class Initialized
INFO - 2018-01-17 20:52:03 --> Output Class Initialized
INFO - 2018-01-17 20:52:03 --> URI Class Initialized
INFO - 2018-01-17 20:52:03 --> URI Class Initialized
INFO - 2018-01-17 20:52:03 --> Security Class Initialized
INFO - 2018-01-17 20:52:03 --> Router Class Initialized
INFO - 2018-01-17 20:52:03 --> Security Class Initialized
INFO - 2018-01-17 20:52:03 --> Router Class Initialized
DEBUG - 2018-01-17 20:52:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-01-17 20:52:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 20:52:03 --> Input Class Initialized
INFO - 2018-01-17 20:52:03 --> Input Class Initialized
INFO - 2018-01-17 20:52:03 --> Language Class Initialized
INFO - 2018-01-17 20:52:03 --> Output Class Initialized
INFO - 2018-01-17 20:52:03 --> Language Class Initialized
INFO - 2018-01-17 20:52:03 --> Output Class Initialized
ERROR - 2018-01-17 20:52:03 --> 404 Page Not Found: Login/instatec_pub
ERROR - 2018-01-17 20:52:03 --> 404 Page Not Found: Login/instatec_pub
INFO - 2018-01-17 20:52:03 --> Security Class Initialized
INFO - 2018-01-17 20:52:03 --> Security Class Initialized
DEBUG - 2018-01-17 20:52:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 20:52:03 --> Input Class Initialized
INFO - 2018-01-17 20:52:03 --> Language Class Initialized
DEBUG - 2018-01-17 20:52:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 20:52:03 --> Input Class Initialized
ERROR - 2018-01-17 20:52:03 --> 404 Page Not Found: Login/instatec_pub
INFO - 2018-01-17 20:52:03 --> Language Class Initialized
ERROR - 2018-01-17 20:52:03 --> 404 Page Not Found: Login/instatec_pub
INFO - 2018-01-17 20:52:04 --> Config Class Initialized
INFO - 2018-01-17 20:52:04 --> Hooks Class Initialized
DEBUG - 2018-01-17 20:52:04 --> UTF-8 Support Enabled
INFO - 2018-01-17 20:52:04 --> Utf8 Class Initialized
INFO - 2018-01-17 20:52:04 --> URI Class Initialized
INFO - 2018-01-17 20:52:04 --> Router Class Initialized
INFO - 2018-01-17 20:52:04 --> Output Class Initialized
INFO - 2018-01-17 20:52:04 --> Security Class Initialized
DEBUG - 2018-01-17 20:52:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 20:52:04 --> Input Class Initialized
INFO - 2018-01-17 20:52:04 --> Language Class Initialized
ERROR - 2018-01-17 20:52:04 --> 404 Page Not Found: Login/instatec_pub
INFO - 2018-01-17 20:52:04 --> Config Class Initialized
INFO - 2018-01-17 20:52:04 --> Hooks Class Initialized
DEBUG - 2018-01-17 20:52:04 --> UTF-8 Support Enabled
INFO - 2018-01-17 20:52:04 --> Utf8 Class Initialized
INFO - 2018-01-17 20:52:04 --> URI Class Initialized
INFO - 2018-01-17 20:52:04 --> Router Class Initialized
INFO - 2018-01-17 20:52:04 --> Output Class Initialized
INFO - 2018-01-17 20:52:04 --> Security Class Initialized
DEBUG - 2018-01-17 20:52:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 20:52:04 --> Input Class Initialized
INFO - 2018-01-17 20:52:04 --> Language Class Initialized
INFO - 2018-01-17 20:52:04 --> Config Class Initialized
INFO - 2018-01-17 20:52:04 --> Hooks Class Initialized
ERROR - 2018-01-17 20:52:04 --> 404 Page Not Found: Login/instatec_pub
DEBUG - 2018-01-17 20:52:04 --> UTF-8 Support Enabled
INFO - 2018-01-17 20:52:04 --> Utf8 Class Initialized
INFO - 2018-01-17 20:52:04 --> URI Class Initialized
INFO - 2018-01-17 20:52:04 --> Router Class Initialized
INFO - 2018-01-17 20:52:04 --> Output Class Initialized
INFO - 2018-01-17 20:52:04 --> Security Class Initialized
DEBUG - 2018-01-17 20:52:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 20:52:04 --> Input Class Initialized
INFO - 2018-01-17 20:52:04 --> Language Class Initialized
ERROR - 2018-01-17 20:52:04 --> 404 Page Not Found: Login/instatec_pub
INFO - 2018-01-17 20:52:04 --> Config Class Initialized
INFO - 2018-01-17 20:52:04 --> Hooks Class Initialized
DEBUG - 2018-01-17 20:52:04 --> UTF-8 Support Enabled
INFO - 2018-01-17 20:52:04 --> Utf8 Class Initialized
INFO - 2018-01-17 20:52:04 --> URI Class Initialized
INFO - 2018-01-17 20:52:04 --> Router Class Initialized
INFO - 2018-01-17 20:52:04 --> Output Class Initialized
INFO - 2018-01-17 20:52:04 --> Security Class Initialized
DEBUG - 2018-01-17 20:52:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 20:52:04 --> Input Class Initialized
INFO - 2018-01-17 20:52:04 --> Language Class Initialized
ERROR - 2018-01-17 20:52:04 --> 404 Page Not Found: Login/instatec_pub
INFO - 2018-01-17 20:52:04 --> Config Class Initialized
INFO - 2018-01-17 20:52:04 --> Hooks Class Initialized
DEBUG - 2018-01-17 20:52:04 --> UTF-8 Support Enabled
INFO - 2018-01-17 20:52:04 --> Utf8 Class Initialized
INFO - 2018-01-17 20:52:04 --> Config Class Initialized
INFO - 2018-01-17 20:52:04 --> URI Class Initialized
INFO - 2018-01-17 20:52:04 --> Hooks Class Initialized
INFO - 2018-01-17 20:52:04 --> Router Class Initialized
DEBUG - 2018-01-17 20:52:04 --> UTF-8 Support Enabled
INFO - 2018-01-17 20:52:04 --> Utf8 Class Initialized
INFO - 2018-01-17 20:52:04 --> URI Class Initialized
INFO - 2018-01-17 20:52:04 --> Output Class Initialized
INFO - 2018-01-17 20:52:04 --> Router Class Initialized
INFO - 2018-01-17 20:52:04 --> Security Class Initialized
DEBUG - 2018-01-17 20:52:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 20:52:04 --> Output Class Initialized
INFO - 2018-01-17 20:52:04 --> Input Class Initialized
INFO - 2018-01-17 20:52:04 --> Language Class Initialized
ERROR - 2018-01-17 20:52:04 --> 404 Page Not Found: Login/instatec_pub
INFO - 2018-01-17 20:52:04 --> Security Class Initialized
DEBUG - 2018-01-17 20:52:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 20:52:04 --> Input Class Initialized
INFO - 2018-01-17 20:52:04 --> Language Class Initialized
ERROR - 2018-01-17 20:52:04 --> 404 Page Not Found: Login/instatec_pub
INFO - 2018-01-17 20:52:47 --> Config Class Initialized
INFO - 2018-01-17 20:52:47 --> Hooks Class Initialized
DEBUG - 2018-01-17 20:52:47 --> UTF-8 Support Enabled
INFO - 2018-01-17 20:52:47 --> Utf8 Class Initialized
INFO - 2018-01-17 20:52:47 --> URI Class Initialized
INFO - 2018-01-17 20:52:47 --> Router Class Initialized
INFO - 2018-01-17 20:52:47 --> Output Class Initialized
INFO - 2018-01-17 20:52:47 --> Security Class Initialized
DEBUG - 2018-01-17 20:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 20:52:47 --> Input Class Initialized
INFO - 2018-01-17 20:52:47 --> Language Class Initialized
INFO - 2018-01-17 20:52:47 --> Loader Class Initialized
INFO - 2018-01-17 20:52:47 --> Helper loaded: url_helper
INFO - 2018-01-17 20:52:47 --> Helper loaded: form_helper
INFO - 2018-01-17 20:52:47 --> Database Driver Class Initialized
DEBUG - 2018-01-17 20:52:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-17 20:52:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-17 20:52:47 --> Form Validation Class Initialized
INFO - 2018-01-17 20:52:47 --> Model Class Initialized
INFO - 2018-01-17 20:52:47 --> Controller Class Initialized
INFO - 2018-01-17 20:52:47 --> Model Class Initialized
DEBUG - 2018-01-17 20:52:47 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-01-17 20:52:47 --> Severity: Error --> Call to undefined function baseurl() /home/instateccr/public_html/controlcostos/instatec_app/views/master/header.php 19
INFO - 2018-01-17 20:53:06 --> Config Class Initialized
INFO - 2018-01-17 20:53:06 --> Hooks Class Initialized
DEBUG - 2018-01-17 20:53:06 --> UTF-8 Support Enabled
INFO - 2018-01-17 20:53:06 --> Utf8 Class Initialized
INFO - 2018-01-17 20:53:06 --> URI Class Initialized
INFO - 2018-01-17 20:53:06 --> Router Class Initialized
INFO - 2018-01-17 20:53:06 --> Output Class Initialized
INFO - 2018-01-17 20:53:06 --> Security Class Initialized
DEBUG - 2018-01-17 20:53:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 20:53:06 --> Input Class Initialized
INFO - 2018-01-17 20:53:06 --> Language Class Initialized
INFO - 2018-01-17 20:53:06 --> Loader Class Initialized
INFO - 2018-01-17 20:53:06 --> Helper loaded: url_helper
INFO - 2018-01-17 20:53:06 --> Helper loaded: form_helper
INFO - 2018-01-17 20:53:06 --> Database Driver Class Initialized
DEBUG - 2018-01-17 20:53:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-17 20:53:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-17 20:53:06 --> Form Validation Class Initialized
INFO - 2018-01-17 20:53:06 --> Model Class Initialized
INFO - 2018-01-17 20:53:06 --> Controller Class Initialized
INFO - 2018-01-17 20:53:06 --> Model Class Initialized
DEBUG - 2018-01-17 20:53:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-17 20:53:06 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-17 20:53:06 --> Final output sent to browser
DEBUG - 2018-01-17 20:53:06 --> Total execution time: 0.0351
INFO - 2018-01-17 20:53:08 --> Config Class Initialized
INFO - 2018-01-17 20:53:08 --> Hooks Class Initialized
DEBUG - 2018-01-17 20:53:08 --> UTF-8 Support Enabled
INFO - 2018-01-17 20:53:08 --> Utf8 Class Initialized
INFO - 2018-01-17 20:53:08 --> URI Class Initialized
INFO - 2018-01-17 20:53:08 --> Router Class Initialized
INFO - 2018-01-17 20:53:08 --> Output Class Initialized
INFO - 2018-01-17 20:53:08 --> Security Class Initialized
DEBUG - 2018-01-17 20:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 20:53:08 --> Input Class Initialized
INFO - 2018-01-17 20:53:08 --> Language Class Initialized
ERROR - 2018-01-17 20:53:08 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-01-17 20:53:08 --> Config Class Initialized
INFO - 2018-01-17 20:53:08 --> Hooks Class Initialized
DEBUG - 2018-01-17 20:53:08 --> UTF-8 Support Enabled
INFO - 2018-01-17 20:53:08 --> Utf8 Class Initialized
INFO - 2018-01-17 20:53:08 --> URI Class Initialized
INFO - 2018-01-17 20:53:08 --> Router Class Initialized
INFO - 2018-01-17 20:53:08 --> Output Class Initialized
INFO - 2018-01-17 20:53:08 --> Security Class Initialized
DEBUG - 2018-01-17 20:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 20:53:08 --> Input Class Initialized
INFO - 2018-01-17 20:53:08 --> Language Class Initialized
ERROR - 2018-01-17 20:53:08 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-01-17 20:53:09 --> Config Class Initialized
INFO - 2018-01-17 20:53:09 --> Hooks Class Initialized
DEBUG - 2018-01-17 20:53:09 --> UTF-8 Support Enabled
INFO - 2018-01-17 20:53:09 --> Utf8 Class Initialized
INFO - 2018-01-17 20:53:09 --> URI Class Initialized
INFO - 2018-01-17 20:53:09 --> Router Class Initialized
INFO - 2018-01-17 20:53:09 --> Output Class Initialized
INFO - 2018-01-17 20:53:09 --> Security Class Initialized
DEBUG - 2018-01-17 20:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 20:53:09 --> Input Class Initialized
INFO - 2018-01-17 20:53:09 --> Language Class Initialized
ERROR - 2018-01-17 20:53:09 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-01-17 21:00:57 --> Config Class Initialized
INFO - 2018-01-17 21:00:57 --> Hooks Class Initialized
DEBUG - 2018-01-17 21:00:57 --> UTF-8 Support Enabled
INFO - 2018-01-17 21:00:57 --> Utf8 Class Initialized
INFO - 2018-01-17 21:00:57 --> URI Class Initialized
INFO - 2018-01-17 21:00:57 --> Router Class Initialized
INFO - 2018-01-17 21:00:57 --> Output Class Initialized
INFO - 2018-01-17 21:00:57 --> Security Class Initialized
DEBUG - 2018-01-17 21:00:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 21:00:57 --> Input Class Initialized
INFO - 2018-01-17 21:00:57 --> Language Class Initialized
INFO - 2018-01-17 21:00:57 --> Loader Class Initialized
INFO - 2018-01-17 21:00:57 --> Helper loaded: url_helper
INFO - 2018-01-17 21:00:57 --> Helper loaded: form_helper
INFO - 2018-01-17 21:00:57 --> Database Driver Class Initialized
DEBUG - 2018-01-17 21:00:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-17 21:00:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-17 21:00:57 --> Form Validation Class Initialized
INFO - 2018-01-17 21:00:57 --> Model Class Initialized
INFO - 2018-01-17 21:00:57 --> Controller Class Initialized
INFO - 2018-01-17 21:00:57 --> Model Class Initialized
DEBUG - 2018-01-17 21:00:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-17 21:00:57 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-17 21:00:57 --> Final output sent to browser
DEBUG - 2018-01-17 21:00:57 --> Total execution time: 0.0369
INFO - 2018-01-17 21:00:58 --> Config Class Initialized
INFO - 2018-01-17 21:00:58 --> Hooks Class Initialized
DEBUG - 2018-01-17 21:00:58 --> UTF-8 Support Enabled
INFO - 2018-01-17 21:00:58 --> Utf8 Class Initialized
INFO - 2018-01-17 21:00:58 --> URI Class Initialized
INFO - 2018-01-17 21:00:58 --> Router Class Initialized
INFO - 2018-01-17 21:00:58 --> Output Class Initialized
INFO - 2018-01-17 21:00:58 --> Security Class Initialized
INFO - 2018-01-17 21:00:58 --> Config Class Initialized
INFO - 2018-01-17 21:00:58 --> Hooks Class Initialized
DEBUG - 2018-01-17 21:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 21:00:58 --> Input Class Initialized
INFO - 2018-01-17 21:00:58 --> Language Class Initialized
ERROR - 2018-01-17 21:00:58 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-01-17 21:00:58 --> UTF-8 Support Enabled
INFO - 2018-01-17 21:00:58 --> Utf8 Class Initialized
INFO - 2018-01-17 21:00:58 --> URI Class Initialized
INFO - 2018-01-17 21:00:58 --> Router Class Initialized
INFO - 2018-01-17 21:00:58 --> Output Class Initialized
INFO - 2018-01-17 21:00:58 --> Security Class Initialized
DEBUG - 2018-01-17 21:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 21:00:58 --> Input Class Initialized
INFO - 2018-01-17 21:00:58 --> Language Class Initialized
ERROR - 2018-01-17 21:00:58 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-01-17 21:00:58 --> Config Class Initialized
INFO - 2018-01-17 21:00:58 --> Hooks Class Initialized
DEBUG - 2018-01-17 21:00:58 --> UTF-8 Support Enabled
INFO - 2018-01-17 21:00:58 --> Utf8 Class Initialized
INFO - 2018-01-17 21:00:58 --> URI Class Initialized
INFO - 2018-01-17 21:00:58 --> Router Class Initialized
INFO - 2018-01-17 21:00:58 --> Output Class Initialized
INFO - 2018-01-17 21:00:58 --> Security Class Initialized
DEBUG - 2018-01-17 21:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 21:00:58 --> Input Class Initialized
INFO - 2018-01-17 21:00:58 --> Language Class Initialized
ERROR - 2018-01-17 21:00:58 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-01-17 21:01:21 --> Config Class Initialized
INFO - 2018-01-17 21:01:21 --> Hooks Class Initialized
DEBUG - 2018-01-17 21:01:21 --> UTF-8 Support Enabled
INFO - 2018-01-17 21:01:21 --> Utf8 Class Initialized
INFO - 2018-01-17 21:01:21 --> URI Class Initialized
INFO - 2018-01-17 21:01:21 --> Router Class Initialized
INFO - 2018-01-17 21:01:21 --> Output Class Initialized
INFO - 2018-01-17 21:01:21 --> Security Class Initialized
DEBUG - 2018-01-17 21:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 21:01:21 --> Input Class Initialized
INFO - 2018-01-17 21:01:21 --> Language Class Initialized
INFO - 2018-01-17 21:01:21 --> Loader Class Initialized
INFO - 2018-01-17 21:01:21 --> Helper loaded: url_helper
INFO - 2018-01-17 21:01:21 --> Helper loaded: form_helper
INFO - 2018-01-17 21:01:21 --> Database Driver Class Initialized
DEBUG - 2018-01-17 21:01:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-17 21:01:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-17 21:01:21 --> Form Validation Class Initialized
INFO - 2018-01-17 21:01:21 --> Model Class Initialized
INFO - 2018-01-17 21:01:21 --> Controller Class Initialized
INFO - 2018-01-17 21:01:21 --> Model Class Initialized
DEBUG - 2018-01-17 21:01:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-17 21:01:21 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-17 21:01:21 --> Final output sent to browser
DEBUG - 2018-01-17 21:01:21 --> Total execution time: 0.0355
INFO - 2018-01-17 21:01:49 --> Config Class Initialized
INFO - 2018-01-17 21:01:49 --> Hooks Class Initialized
DEBUG - 2018-01-17 21:01:49 --> UTF-8 Support Enabled
INFO - 2018-01-17 21:01:49 --> Utf8 Class Initialized
INFO - 2018-01-17 21:01:49 --> URI Class Initialized
INFO - 2018-01-17 21:01:49 --> Router Class Initialized
INFO - 2018-01-17 21:01:49 --> Output Class Initialized
INFO - 2018-01-17 21:01:49 --> Security Class Initialized
DEBUG - 2018-01-17 21:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 21:01:49 --> Input Class Initialized
INFO - 2018-01-17 21:01:49 --> Language Class Initialized
INFO - 2018-01-17 21:01:49 --> Loader Class Initialized
INFO - 2018-01-17 21:01:49 --> Helper loaded: url_helper
INFO - 2018-01-17 21:01:49 --> Helper loaded: form_helper
INFO - 2018-01-17 21:01:49 --> Database Driver Class Initialized
DEBUG - 2018-01-17 21:01:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-17 21:01:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-17 21:01:49 --> Form Validation Class Initialized
INFO - 2018-01-17 21:01:49 --> Model Class Initialized
INFO - 2018-01-17 21:01:49 --> Controller Class Initialized
INFO - 2018-01-17 21:01:49 --> Model Class Initialized
DEBUG - 2018-01-17 21:01:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-17 21:01:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-01-17 21:01:50 --> Config Class Initialized
INFO - 2018-01-17 21:01:50 --> Hooks Class Initialized
DEBUG - 2018-01-17 21:01:50 --> UTF-8 Support Enabled
INFO - 2018-01-17 21:01:50 --> Utf8 Class Initialized
INFO - 2018-01-17 21:01:50 --> URI Class Initialized
DEBUG - 2018-01-17 21:01:50 --> No URI present. Default controller set.
INFO - 2018-01-17 21:01:50 --> Router Class Initialized
INFO - 2018-01-17 21:01:50 --> Output Class Initialized
INFO - 2018-01-17 21:01:50 --> Security Class Initialized
DEBUG - 2018-01-17 21:01:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 21:01:50 --> Input Class Initialized
INFO - 2018-01-17 21:01:50 --> Language Class Initialized
INFO - 2018-01-17 21:01:50 --> Loader Class Initialized
INFO - 2018-01-17 21:01:50 --> Helper loaded: url_helper
INFO - 2018-01-17 21:01:50 --> Helper loaded: form_helper
INFO - 2018-01-17 21:01:50 --> Database Driver Class Initialized
DEBUG - 2018-01-17 21:01:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-17 21:01:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-17 21:01:50 --> Form Validation Class Initialized
INFO - 2018-01-17 21:01:50 --> Model Class Initialized
INFO - 2018-01-17 21:01:50 --> Controller Class Initialized
INFO - 2018-01-17 21:01:50 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-17 21:01:50 --> Final output sent to browser
DEBUG - 2018-01-17 21:01:50 --> Total execution time: 0.0359
INFO - 2018-01-17 21:02:01 --> Config Class Initialized
INFO - 2018-01-17 21:02:01 --> Hooks Class Initialized
DEBUG - 2018-01-17 21:02:01 --> UTF-8 Support Enabled
INFO - 2018-01-17 21:02:01 --> Utf8 Class Initialized
INFO - 2018-01-17 21:02:01 --> URI Class Initialized
INFO - 2018-01-17 21:02:01 --> Router Class Initialized
INFO - 2018-01-17 21:02:01 --> Output Class Initialized
INFO - 2018-01-17 21:02:01 --> Security Class Initialized
DEBUG - 2018-01-17 21:02:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 21:02:01 --> Input Class Initialized
INFO - 2018-01-17 21:02:01 --> Language Class Initialized
INFO - 2018-01-17 21:02:01 --> Loader Class Initialized
INFO - 2018-01-17 21:02:01 --> Helper loaded: url_helper
INFO - 2018-01-17 21:02:01 --> Helper loaded: form_helper
INFO - 2018-01-17 21:02:01 --> Database Driver Class Initialized
DEBUG - 2018-01-17 21:02:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-17 21:02:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-17 21:02:01 --> Form Validation Class Initialized
INFO - 2018-01-17 21:02:01 --> Model Class Initialized
INFO - 2018-01-17 21:02:01 --> Controller Class Initialized
INFO - 2018-01-17 21:02:01 --> Model Class Initialized
INFO - 2018-01-17 21:02:01 --> Model Class Initialized
INFO - 2018-01-17 21:02:01 --> Model Class Initialized
INFO - 2018-01-17 21:02:01 --> Model Class Initialized
DEBUG - 2018-01-17 21:02:01 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-01-17 21:02:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/index.php 45
ERROR - 2018-01-17 21:02:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/index.php 58
INFO - 2018-01-17 21:02:01 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-17 21:02:01 --> Final output sent to browser
DEBUG - 2018-01-17 21:02:01 --> Total execution time: 0.0561
INFO - 2018-01-17 21:02:03 --> Config Class Initialized
INFO - 2018-01-17 21:02:03 --> Hooks Class Initialized
DEBUG - 2018-01-17 21:02:03 --> UTF-8 Support Enabled
INFO - 2018-01-17 21:02:03 --> Utf8 Class Initialized
INFO - 2018-01-17 21:02:03 --> URI Class Initialized
INFO - 2018-01-17 21:02:03 --> Router Class Initialized
INFO - 2018-01-17 21:02:03 --> Output Class Initialized
INFO - 2018-01-17 21:02:03 --> Security Class Initialized
DEBUG - 2018-01-17 21:02:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 21:02:03 --> Input Class Initialized
INFO - 2018-01-17 21:02:03 --> Language Class Initialized
INFO - 2018-01-17 21:02:03 --> Loader Class Initialized
INFO - 2018-01-17 21:02:03 --> Helper loaded: url_helper
INFO - 2018-01-17 21:02:03 --> Helper loaded: form_helper
INFO - 2018-01-17 21:02:03 --> Database Driver Class Initialized
DEBUG - 2018-01-17 21:02:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-17 21:02:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-17 21:02:03 --> Form Validation Class Initialized
INFO - 2018-01-17 21:02:03 --> Model Class Initialized
INFO - 2018-01-17 21:02:03 --> Controller Class Initialized
INFO - 2018-01-17 21:02:03 --> Model Class Initialized
INFO - 2018-01-17 21:02:03 --> Model Class Initialized
DEBUG - 2018-01-17 21:02:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-17 21:02:03 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-17 21:02:03 --> Final output sent to browser
DEBUG - 2018-01-17 21:02:03 --> Total execution time: 0.0383
INFO - 2018-01-17 21:02:05 --> Config Class Initialized
INFO - 2018-01-17 21:02:05 --> Hooks Class Initialized
DEBUG - 2018-01-17 21:02:05 --> UTF-8 Support Enabled
INFO - 2018-01-17 21:02:05 --> Utf8 Class Initialized
INFO - 2018-01-17 21:02:05 --> URI Class Initialized
INFO - 2018-01-17 21:02:05 --> Router Class Initialized
INFO - 2018-01-17 21:02:05 --> Output Class Initialized
INFO - 2018-01-17 21:02:05 --> Security Class Initialized
DEBUG - 2018-01-17 21:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 21:02:05 --> Input Class Initialized
INFO - 2018-01-17 21:02:05 --> Language Class Initialized
INFO - 2018-01-17 21:02:05 --> Loader Class Initialized
INFO - 2018-01-17 21:02:05 --> Helper loaded: url_helper
INFO - 2018-01-17 21:02:05 --> Helper loaded: form_helper
INFO - 2018-01-17 21:02:05 --> Database Driver Class Initialized
DEBUG - 2018-01-17 21:02:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-17 21:02:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-17 21:02:05 --> Form Validation Class Initialized
INFO - 2018-01-17 21:02:05 --> Model Class Initialized
INFO - 2018-01-17 21:02:05 --> Controller Class Initialized
INFO - 2018-01-17 21:02:05 --> Model Class Initialized
INFO - 2018-01-17 21:02:05 --> Model Class Initialized
DEBUG - 2018-01-17 21:02:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-17 21:02:05 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-17 21:02:05 --> Final output sent to browser
DEBUG - 2018-01-17 21:02:05 --> Total execution time: 0.0383
INFO - 2018-01-17 21:02:07 --> Config Class Initialized
INFO - 2018-01-17 21:02:07 --> Hooks Class Initialized
DEBUG - 2018-01-17 21:02:07 --> UTF-8 Support Enabled
INFO - 2018-01-17 21:02:07 --> Utf8 Class Initialized
INFO - 2018-01-17 21:02:07 --> URI Class Initialized
INFO - 2018-01-17 21:02:07 --> Router Class Initialized
INFO - 2018-01-17 21:02:07 --> Output Class Initialized
INFO - 2018-01-17 21:02:07 --> Security Class Initialized
DEBUG - 2018-01-17 21:02:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 21:02:07 --> Input Class Initialized
INFO - 2018-01-17 21:02:07 --> Language Class Initialized
INFO - 2018-01-17 21:02:07 --> Loader Class Initialized
INFO - 2018-01-17 21:02:07 --> Helper loaded: url_helper
INFO - 2018-01-17 21:02:07 --> Helper loaded: form_helper
INFO - 2018-01-17 21:02:07 --> Database Driver Class Initialized
DEBUG - 2018-01-17 21:02:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-17 21:02:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-17 21:02:07 --> Form Validation Class Initialized
INFO - 2018-01-17 21:02:07 --> Model Class Initialized
INFO - 2018-01-17 21:02:07 --> Controller Class Initialized
INFO - 2018-01-17 21:02:07 --> Model Class Initialized
INFO - 2018-01-17 21:02:07 --> Model Class Initialized
DEBUG - 2018-01-17 21:02:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-17 21:02:07 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-17 21:02:07 --> Final output sent to browser
DEBUG - 2018-01-17 21:02:07 --> Total execution time: 0.0377
INFO - 2018-01-17 21:02:09 --> Config Class Initialized
INFO - 2018-01-17 21:02:09 --> Hooks Class Initialized
DEBUG - 2018-01-17 21:02:09 --> UTF-8 Support Enabled
INFO - 2018-01-17 21:02:09 --> Utf8 Class Initialized
INFO - 2018-01-17 21:02:09 --> URI Class Initialized
INFO - 2018-01-17 21:02:09 --> Router Class Initialized
INFO - 2018-01-17 21:02:09 --> Output Class Initialized
INFO - 2018-01-17 21:02:09 --> Security Class Initialized
DEBUG - 2018-01-17 21:02:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 21:02:09 --> Input Class Initialized
INFO - 2018-01-17 21:02:09 --> Language Class Initialized
INFO - 2018-01-17 21:02:09 --> Loader Class Initialized
INFO - 2018-01-17 21:02:09 --> Helper loaded: url_helper
INFO - 2018-01-17 21:02:09 --> Helper loaded: form_helper
INFO - 2018-01-17 21:02:09 --> Database Driver Class Initialized
DEBUG - 2018-01-17 21:02:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-17 21:02:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-17 21:02:09 --> Form Validation Class Initialized
INFO - 2018-01-17 21:02:09 --> Model Class Initialized
INFO - 2018-01-17 21:02:09 --> Controller Class Initialized
INFO - 2018-01-17 21:02:09 --> Model Class Initialized
INFO - 2018-01-17 21:02:09 --> Model Class Initialized
INFO - 2018-01-17 21:02:09 --> Model Class Initialized
INFO - 2018-01-17 21:02:09 --> Model Class Initialized
DEBUG - 2018-01-17 21:02:09 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-01-17 21:02:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/index.php 45
ERROR - 2018-01-17 21:02:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/index.php 58
INFO - 2018-01-17 21:02:09 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-17 21:02:09 --> Final output sent to browser
DEBUG - 2018-01-17 21:02:09 --> Total execution time: 0.0601
INFO - 2018-01-17 21:02:10 --> Config Class Initialized
INFO - 2018-01-17 21:02:10 --> Hooks Class Initialized
DEBUG - 2018-01-17 21:02:10 --> UTF-8 Support Enabled
INFO - 2018-01-17 21:02:10 --> Utf8 Class Initialized
INFO - 2018-01-17 21:02:10 --> URI Class Initialized
DEBUG - 2018-01-17 21:02:10 --> No URI present. Default controller set.
INFO - 2018-01-17 21:02:10 --> Router Class Initialized
INFO - 2018-01-17 21:02:10 --> Output Class Initialized
INFO - 2018-01-17 21:02:10 --> Security Class Initialized
DEBUG - 2018-01-17 21:02:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 21:02:10 --> Input Class Initialized
INFO - 2018-01-17 21:02:10 --> Language Class Initialized
INFO - 2018-01-17 21:02:10 --> Loader Class Initialized
INFO - 2018-01-17 21:02:10 --> Helper loaded: url_helper
INFO - 2018-01-17 21:02:10 --> Helper loaded: form_helper
INFO - 2018-01-17 21:02:10 --> Database Driver Class Initialized
DEBUG - 2018-01-17 21:02:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-17 21:02:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-17 21:02:10 --> Form Validation Class Initialized
INFO - 2018-01-17 21:02:10 --> Model Class Initialized
INFO - 2018-01-17 21:02:10 --> Controller Class Initialized
INFO - 2018-01-17 21:02:10 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-17 21:02:10 --> Final output sent to browser
DEBUG - 2018-01-17 21:02:10 --> Total execution time: 0.0338
INFO - 2018-01-17 21:02:14 --> Config Class Initialized
INFO - 2018-01-17 21:02:14 --> Hooks Class Initialized
DEBUG - 2018-01-17 21:02:14 --> UTF-8 Support Enabled
INFO - 2018-01-17 21:02:14 --> Utf8 Class Initialized
INFO - 2018-01-17 21:02:14 --> URI Class Initialized
INFO - 2018-01-17 21:02:14 --> Router Class Initialized
INFO - 2018-01-17 21:02:14 --> Output Class Initialized
INFO - 2018-01-17 21:02:14 --> Security Class Initialized
DEBUG - 2018-01-17 21:02:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 21:02:14 --> Input Class Initialized
INFO - 2018-01-17 21:02:14 --> Language Class Initialized
INFO - 2018-01-17 21:02:14 --> Loader Class Initialized
INFO - 2018-01-17 21:02:14 --> Helper loaded: url_helper
INFO - 2018-01-17 21:02:14 --> Helper loaded: form_helper
INFO - 2018-01-17 21:02:14 --> Database Driver Class Initialized
DEBUG - 2018-01-17 21:02:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-17 21:02:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-17 21:02:14 --> Form Validation Class Initialized
INFO - 2018-01-17 21:02:14 --> Model Class Initialized
INFO - 2018-01-17 21:02:14 --> Controller Class Initialized
INFO - 2018-01-17 21:02:14 --> Model Class Initialized
INFO - 2018-01-17 21:02:14 --> Model Class Initialized
DEBUG - 2018-01-17 21:02:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-17 21:02:14 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-17 21:02:14 --> Final output sent to browser
DEBUG - 2018-01-17 21:02:14 --> Total execution time: 0.0390
INFO - 2018-01-17 21:02:15 --> Config Class Initialized
INFO - 2018-01-17 21:02:15 --> Hooks Class Initialized
DEBUG - 2018-01-17 21:02:15 --> UTF-8 Support Enabled
INFO - 2018-01-17 21:02:15 --> Utf8 Class Initialized
INFO - 2018-01-17 21:02:15 --> URI Class Initialized
INFO - 2018-01-17 21:02:15 --> Router Class Initialized
INFO - 2018-01-17 21:02:15 --> Output Class Initialized
INFO - 2018-01-17 21:02:15 --> Security Class Initialized
DEBUG - 2018-01-17 21:02:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 21:02:15 --> Input Class Initialized
INFO - 2018-01-17 21:02:15 --> Language Class Initialized
INFO - 2018-01-17 21:02:15 --> Loader Class Initialized
INFO - 2018-01-17 21:02:15 --> Helper loaded: url_helper
INFO - 2018-01-17 21:02:15 --> Helper loaded: form_helper
INFO - 2018-01-17 21:02:15 --> Database Driver Class Initialized
DEBUG - 2018-01-17 21:02:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-17 21:02:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-17 21:02:15 --> Form Validation Class Initialized
INFO - 2018-01-17 21:02:15 --> Model Class Initialized
INFO - 2018-01-17 21:02:15 --> Controller Class Initialized
INFO - 2018-01-17 21:02:15 --> Model Class Initialized
INFO - 2018-01-17 21:02:15 --> Model Class Initialized
DEBUG - 2018-01-17 21:02:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-17 21:02:15 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-17 21:02:15 --> Final output sent to browser
DEBUG - 2018-01-17 21:02:15 --> Total execution time: 0.0384
INFO - 2018-01-17 21:02:17 --> Config Class Initialized
INFO - 2018-01-17 21:02:17 --> Hooks Class Initialized
DEBUG - 2018-01-17 21:02:17 --> UTF-8 Support Enabled
INFO - 2018-01-17 21:02:17 --> Utf8 Class Initialized
INFO - 2018-01-17 21:02:17 --> URI Class Initialized
INFO - 2018-01-17 21:02:17 --> Router Class Initialized
INFO - 2018-01-17 21:02:17 --> Output Class Initialized
INFO - 2018-01-17 21:02:17 --> Security Class Initialized
DEBUG - 2018-01-17 21:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 21:02:17 --> Input Class Initialized
INFO - 2018-01-17 21:02:17 --> Language Class Initialized
INFO - 2018-01-17 21:02:17 --> Loader Class Initialized
INFO - 2018-01-17 21:02:17 --> Helper loaded: url_helper
INFO - 2018-01-17 21:02:17 --> Helper loaded: form_helper
INFO - 2018-01-17 21:02:17 --> Database Driver Class Initialized
DEBUG - 2018-01-17 21:02:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-17 21:02:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-17 21:02:17 --> Form Validation Class Initialized
INFO - 2018-01-17 21:02:17 --> Model Class Initialized
INFO - 2018-01-17 21:02:17 --> Controller Class Initialized
INFO - 2018-01-17 21:02:17 --> Model Class Initialized
INFO - 2018-01-17 21:02:17 --> Model Class Initialized
INFO - 2018-01-17 21:02:17 --> Model Class Initialized
INFO - 2018-01-17 21:02:17 --> Model Class Initialized
DEBUG - 2018-01-17 21:02:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-17 21:02:17 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-17 21:02:17 --> Final output sent to browser
DEBUG - 2018-01-17 21:02:17 --> Total execution time: 0.0667
INFO - 2018-01-17 21:02:20 --> Config Class Initialized
INFO - 2018-01-17 21:02:20 --> Hooks Class Initialized
DEBUG - 2018-01-17 21:02:20 --> UTF-8 Support Enabled
INFO - 2018-01-17 21:02:20 --> Utf8 Class Initialized
INFO - 2018-01-17 21:02:20 --> URI Class Initialized
INFO - 2018-01-17 21:02:20 --> Router Class Initialized
INFO - 2018-01-17 21:02:20 --> Output Class Initialized
INFO - 2018-01-17 21:02:20 --> Security Class Initialized
DEBUG - 2018-01-17 21:02:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 21:02:20 --> Input Class Initialized
INFO - 2018-01-17 21:02:20 --> Language Class Initialized
INFO - 2018-01-17 21:02:20 --> Loader Class Initialized
INFO - 2018-01-17 21:02:20 --> Helper loaded: url_helper
INFO - 2018-01-17 21:02:20 --> Helper loaded: form_helper
INFO - 2018-01-17 21:02:20 --> Database Driver Class Initialized
DEBUG - 2018-01-17 21:02:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-17 21:02:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-17 21:02:20 --> Form Validation Class Initialized
INFO - 2018-01-17 21:02:20 --> Model Class Initialized
INFO - 2018-01-17 21:02:20 --> Controller Class Initialized
INFO - 2018-01-17 21:02:20 --> Model Class Initialized
INFO - 2018-01-17 21:02:20 --> Model Class Initialized
INFO - 2018-01-17 21:02:20 --> Model Class Initialized
INFO - 2018-01-17 21:02:20 --> Model Class Initialized
DEBUG - 2018-01-17 21:02:20 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-01-17 21:02:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/instateccr/public_html/controlcostos/instatec_app/views/reporte/reporteProyectoEspecifico.php 46
ERROR - 2018-01-17 21:02:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/instateccr/public_html/controlcostos/instatec_app/views/reporte/reporteProyectoEspecifico.php 59
INFO - 2018-01-17 21:02:20 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-17 21:02:20 --> Final output sent to browser
DEBUG - 2018-01-17 21:02:20 --> Total execution time: 0.0507
INFO - 2018-01-17 21:02:23 --> Config Class Initialized
INFO - 2018-01-17 21:02:23 --> Hooks Class Initialized
DEBUG - 2018-01-17 21:02:23 --> UTF-8 Support Enabled
INFO - 2018-01-17 21:02:23 --> Utf8 Class Initialized
INFO - 2018-01-17 21:02:23 --> URI Class Initialized
INFO - 2018-01-17 21:02:23 --> Router Class Initialized
INFO - 2018-01-17 21:02:23 --> Output Class Initialized
INFO - 2018-01-17 21:02:23 --> Security Class Initialized
DEBUG - 2018-01-17 21:02:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 21:02:23 --> Input Class Initialized
INFO - 2018-01-17 21:02:23 --> Language Class Initialized
INFO - 2018-01-17 21:02:23 --> Loader Class Initialized
INFO - 2018-01-17 21:02:23 --> Helper loaded: url_helper
INFO - 2018-01-17 21:02:23 --> Helper loaded: form_helper
INFO - 2018-01-17 21:02:23 --> Database Driver Class Initialized
DEBUG - 2018-01-17 21:02:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-17 21:02:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-17 21:02:23 --> Form Validation Class Initialized
INFO - 2018-01-17 21:02:23 --> Model Class Initialized
INFO - 2018-01-17 21:02:23 --> Controller Class Initialized
INFO - 2018-01-17 21:02:23 --> Model Class Initialized
INFO - 2018-01-17 21:02:23 --> Model Class Initialized
DEBUG - 2018-01-17 21:02:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-17 21:02:23 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-17 21:02:23 --> Final output sent to browser
DEBUG - 2018-01-17 21:02:23 --> Total execution time: 0.0386
INFO - 2018-01-17 21:02:24 --> Config Class Initialized
INFO - 2018-01-17 21:02:24 --> Hooks Class Initialized
DEBUG - 2018-01-17 21:02:24 --> UTF-8 Support Enabled
INFO - 2018-01-17 21:02:24 --> Utf8 Class Initialized
INFO - 2018-01-17 21:02:24 --> URI Class Initialized
INFO - 2018-01-17 21:02:24 --> Router Class Initialized
INFO - 2018-01-17 21:02:24 --> Output Class Initialized
INFO - 2018-01-17 21:02:24 --> Security Class Initialized
DEBUG - 2018-01-17 21:02:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 21:02:24 --> Input Class Initialized
INFO - 2018-01-17 21:02:24 --> Language Class Initialized
INFO - 2018-01-17 21:02:24 --> Loader Class Initialized
INFO - 2018-01-17 21:02:24 --> Helper loaded: url_helper
INFO - 2018-01-17 21:02:24 --> Helper loaded: form_helper
INFO - 2018-01-17 21:02:24 --> Database Driver Class Initialized
DEBUG - 2018-01-17 21:02:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-17 21:02:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-17 21:02:24 --> Form Validation Class Initialized
INFO - 2018-01-17 21:02:24 --> Model Class Initialized
INFO - 2018-01-17 21:02:24 --> Controller Class Initialized
INFO - 2018-01-17 21:02:24 --> Model Class Initialized
INFO - 2018-01-17 21:02:24 --> Model Class Initialized
DEBUG - 2018-01-17 21:02:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-17 21:02:24 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-17 21:02:24 --> Final output sent to browser
DEBUG - 2018-01-17 21:02:24 --> Total execution time: 0.0405
INFO - 2018-01-17 21:02:27 --> Config Class Initialized
INFO - 2018-01-17 21:02:27 --> Hooks Class Initialized
DEBUG - 2018-01-17 21:02:27 --> UTF-8 Support Enabled
INFO - 2018-01-17 21:02:27 --> Utf8 Class Initialized
INFO - 2018-01-17 21:02:27 --> URI Class Initialized
INFO - 2018-01-17 21:02:27 --> Router Class Initialized
INFO - 2018-01-17 21:02:27 --> Output Class Initialized
INFO - 2018-01-17 21:02:27 --> Security Class Initialized
DEBUG - 2018-01-17 21:02:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 21:02:27 --> Input Class Initialized
INFO - 2018-01-17 21:02:27 --> Language Class Initialized
INFO - 2018-01-17 21:02:27 --> Loader Class Initialized
INFO - 2018-01-17 21:02:27 --> Helper loaded: url_helper
INFO - 2018-01-17 21:02:27 --> Helper loaded: form_helper
INFO - 2018-01-17 21:02:27 --> Database Driver Class Initialized
DEBUG - 2018-01-17 21:02:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-17 21:02:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-17 21:02:27 --> Form Validation Class Initialized
INFO - 2018-01-17 21:02:27 --> Model Class Initialized
INFO - 2018-01-17 21:02:27 --> Controller Class Initialized
INFO - 2018-01-17 21:02:27 --> Model Class Initialized
INFO - 2018-01-17 21:02:27 --> Model Class Initialized
INFO - 2018-01-17 21:02:27 --> Model Class Initialized
INFO - 2018-01-17 21:02:27 --> Model Class Initialized
DEBUG - 2018-01-17 21:02:27 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-01-17 21:02:27 --> Severity: Warning --> Invalid argument supplied for foreach() /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/index.php 45
ERROR - 2018-01-17 21:02:27 --> Severity: Warning --> Invalid argument supplied for foreach() /home/instateccr/public_html/controlcostos/instatec_app/views/proyecto/index.php 58
INFO - 2018-01-17 21:02:27 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-17 21:02:27 --> Final output sent to browser
DEBUG - 2018-01-17 21:02:27 --> Total execution time: 0.0478
INFO - 2018-01-17 21:02:33 --> Config Class Initialized
INFO - 2018-01-17 21:02:33 --> Hooks Class Initialized
DEBUG - 2018-01-17 21:02:33 --> UTF-8 Support Enabled
INFO - 2018-01-17 21:02:33 --> Utf8 Class Initialized
INFO - 2018-01-17 21:02:33 --> URI Class Initialized
DEBUG - 2018-01-17 21:02:33 --> No URI present. Default controller set.
INFO - 2018-01-17 21:02:33 --> Router Class Initialized
INFO - 2018-01-17 21:02:33 --> Output Class Initialized
INFO - 2018-01-17 21:02:33 --> Security Class Initialized
DEBUG - 2018-01-17 21:02:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-17 21:02:33 --> Input Class Initialized
INFO - 2018-01-17 21:02:33 --> Language Class Initialized
INFO - 2018-01-17 21:02:33 --> Loader Class Initialized
INFO - 2018-01-17 21:02:33 --> Helper loaded: url_helper
INFO - 2018-01-17 21:02:33 --> Helper loaded: form_helper
INFO - 2018-01-17 21:02:33 --> Database Driver Class Initialized
DEBUG - 2018-01-17 21:02:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-17 21:02:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-17 21:02:33 --> Form Validation Class Initialized
INFO - 2018-01-17 21:02:33 --> Model Class Initialized
INFO - 2018-01-17 21:02:33 --> Controller Class Initialized
INFO - 2018-01-17 21:02:33 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-17 21:02:33 --> Final output sent to browser
DEBUG - 2018-01-17 21:02:33 --> Total execution time: 0.0475
