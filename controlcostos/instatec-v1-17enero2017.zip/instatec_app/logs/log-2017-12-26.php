<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-12-26 20:07:56 --> Config Class Initialized
INFO - 2017-12-26 20:07:56 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:07:56 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:07:56 --> Utf8 Class Initialized
INFO - 2017-12-26 20:07:57 --> URI Class Initialized
INFO - 2017-12-26 20:07:57 --> Router Class Initialized
INFO - 2017-12-26 20:07:57 --> Output Class Initialized
INFO - 2017-12-26 20:07:57 --> Security Class Initialized
DEBUG - 2017-12-26 20:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:07:57 --> Input Class Initialized
INFO - 2017-12-26 20:07:57 --> Language Class Initialized
INFO - 2017-12-26 20:07:57 --> Loader Class Initialized
INFO - 2017-12-26 20:07:57 --> Helper loaded: url_helper
INFO - 2017-12-26 20:07:57 --> Helper loaded: form_helper
INFO - 2017-12-26 20:07:57 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:07:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:07:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:07:57 --> Form Validation Class Initialized
INFO - 2017-12-26 20:07:57 --> Model Class Initialized
INFO - 2017-12-26 20:07:57 --> Controller Class Initialized
INFO - 2017-12-26 20:07:57 --> Model Class Initialized
INFO - 2017-12-26 20:07:57 --> Model Class Initialized
INFO - 2017-12-26 20:07:57 --> Model Class Initialized
DEBUG - 2017-12-26 20:07:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:07:57 --> Config Class Initialized
INFO - 2017-12-26 20:07:57 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:07:57 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:07:57 --> Utf8 Class Initialized
INFO - 2017-12-26 20:07:57 --> URI Class Initialized
INFO - 2017-12-26 20:07:57 --> Router Class Initialized
INFO - 2017-12-26 20:07:57 --> Output Class Initialized
INFO - 2017-12-26 20:07:57 --> Security Class Initialized
DEBUG - 2017-12-26 20:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:07:57 --> Input Class Initialized
INFO - 2017-12-26 20:07:57 --> Language Class Initialized
INFO - 2017-12-26 20:07:57 --> Loader Class Initialized
INFO - 2017-12-26 20:07:57 --> Config Class Initialized
INFO - 2017-12-26 20:07:57 --> Hooks Class Initialized
INFO - 2017-12-26 20:07:57 --> Helper loaded: url_helper
INFO - 2017-12-26 20:07:57 --> Helper loaded: form_helper
DEBUG - 2017-12-26 20:07:57 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:07:57 --> Utf8 Class Initialized
INFO - 2017-12-26 20:07:57 --> URI Class Initialized
INFO - 2017-12-26 20:07:57 --> Router Class Initialized
INFO - 2017-12-26 20:07:57 --> Database Driver Class Initialized
INFO - 2017-12-26 20:07:57 --> Output Class Initialized
INFO - 2017-12-26 20:07:57 --> Security Class Initialized
DEBUG - 2017-12-26 20:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:07:57 --> Input Class Initialized
INFO - 2017-12-26 20:07:57 --> Language Class Initialized
DEBUG - 2017-12-26 20:07:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:07:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:07:57 --> Form Validation Class Initialized
INFO - 2017-12-26 20:07:57 --> Model Class Initialized
INFO - 2017-12-26 20:07:57 --> Controller Class Initialized
INFO - 2017-12-26 20:07:57 --> Model Class Initialized
INFO - 2017-12-26 20:07:57 --> Model Class Initialized
INFO - 2017-12-26 20:07:57 --> Model Class Initialized
DEBUG - 2017-12-26 20:07:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:07:57 --> Loader Class Initialized
INFO - 2017-12-26 20:07:57 --> Helper loaded: url_helper
INFO - 2017-12-26 20:07:57 --> Helper loaded: form_helper
INFO - 2017-12-26 20:07:57 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:07:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:07:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:07:57 --> Form Validation Class Initialized
INFO - 2017-12-26 20:07:57 --> Model Class Initialized
INFO - 2017-12-26 20:07:57 --> Controller Class Initialized
INFO - 2017-12-26 20:07:57 --> Model Class Initialized
DEBUG - 2017-12-26 20:07:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:07:57 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-26 20:07:57 --> Final output sent to browser
DEBUG - 2017-12-26 20:07:57 --> Total execution time: 0.1433
INFO - 2017-12-26 20:07:57 --> Config Class Initialized
INFO - 2017-12-26 20:07:57 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:07:57 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:07:57 --> Utf8 Class Initialized
INFO - 2017-12-26 20:07:57 --> URI Class Initialized
INFO - 2017-12-26 20:07:57 --> Router Class Initialized
INFO - 2017-12-26 20:07:57 --> Output Class Initialized
INFO - 2017-12-26 20:07:57 --> Security Class Initialized
DEBUG - 2017-12-26 20:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:07:57 --> Input Class Initialized
INFO - 2017-12-26 20:07:57 --> Language Class Initialized
INFO - 2017-12-26 20:07:57 --> Loader Class Initialized
INFO - 2017-12-26 20:07:57 --> Helper loaded: url_helper
INFO - 2017-12-26 20:07:57 --> Helper loaded: form_helper
INFO - 2017-12-26 20:07:57 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:07:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:07:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:07:57 --> Form Validation Class Initialized
INFO - 2017-12-26 20:07:57 --> Model Class Initialized
INFO - 2017-12-26 20:07:57 --> Controller Class Initialized
INFO - 2017-12-26 20:07:57 --> Model Class Initialized
DEBUG - 2017-12-26 20:07:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:07:57 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-26 20:07:57 --> Final output sent to browser
DEBUG - 2017-12-26 20:07:57 --> Total execution time: 0.0541
INFO - 2017-12-26 20:08:00 --> Config Class Initialized
INFO - 2017-12-26 20:08:00 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:08:00 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:08:00 --> Utf8 Class Initialized
INFO - 2017-12-26 20:08:00 --> URI Class Initialized
INFO - 2017-12-26 20:08:00 --> Router Class Initialized
INFO - 2017-12-26 20:08:00 --> Output Class Initialized
INFO - 2017-12-26 20:08:00 --> Security Class Initialized
DEBUG - 2017-12-26 20:08:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:08:00 --> Input Class Initialized
INFO - 2017-12-26 20:08:00 --> Language Class Initialized
INFO - 2017-12-26 20:08:00 --> Loader Class Initialized
INFO - 2017-12-26 20:08:00 --> Helper loaded: url_helper
INFO - 2017-12-26 20:08:00 --> Helper loaded: form_helper
INFO - 2017-12-26 20:08:00 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:08:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:08:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:08:00 --> Form Validation Class Initialized
INFO - 2017-12-26 20:08:00 --> Model Class Initialized
INFO - 2017-12-26 20:08:00 --> Controller Class Initialized
INFO - 2017-12-26 20:08:00 --> Model Class Initialized
DEBUG - 2017-12-26 20:08:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:08:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-12-26 20:08:00 --> Config Class Initialized
INFO - 2017-12-26 20:08:00 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:08:00 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:08:00 --> Utf8 Class Initialized
INFO - 2017-12-26 20:08:00 --> URI Class Initialized
DEBUG - 2017-12-26 20:08:00 --> No URI present. Default controller set.
INFO - 2017-12-26 20:08:00 --> Router Class Initialized
INFO - 2017-12-26 20:08:00 --> Output Class Initialized
INFO - 2017-12-26 20:08:00 --> Security Class Initialized
DEBUG - 2017-12-26 20:08:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:08:00 --> Input Class Initialized
INFO - 2017-12-26 20:08:00 --> Language Class Initialized
INFO - 2017-12-26 20:08:00 --> Loader Class Initialized
INFO - 2017-12-26 20:08:01 --> Helper loaded: url_helper
INFO - 2017-12-26 20:08:01 --> Helper loaded: form_helper
INFO - 2017-12-26 20:08:01 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:08:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:08:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:08:01 --> Form Validation Class Initialized
INFO - 2017-12-26 20:08:01 --> Model Class Initialized
INFO - 2017-12-26 20:08:01 --> Controller Class Initialized
INFO - 2017-12-26 20:08:01 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-26 20:08:01 --> Final output sent to browser
DEBUG - 2017-12-26 20:08:01 --> Total execution time: 0.1198
INFO - 2017-12-26 20:08:01 --> Config Class Initialized
INFO - 2017-12-26 20:08:01 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:08:01 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:08:01 --> Utf8 Class Initialized
INFO - 2017-12-26 20:08:01 --> URI Class Initialized
INFO - 2017-12-26 20:08:01 --> Router Class Initialized
INFO - 2017-12-26 20:08:01 --> Output Class Initialized
INFO - 2017-12-26 20:08:01 --> Security Class Initialized
DEBUG - 2017-12-26 20:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:08:01 --> Input Class Initialized
INFO - 2017-12-26 20:08:01 --> Language Class Initialized
INFO - 2017-12-26 20:08:01 --> Loader Class Initialized
INFO - 2017-12-26 20:08:01 --> Helper loaded: url_helper
INFO - 2017-12-26 20:08:01 --> Helper loaded: form_helper
INFO - 2017-12-26 20:08:01 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:08:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:08:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:08:01 --> Form Validation Class Initialized
INFO - 2017-12-26 20:08:01 --> Model Class Initialized
INFO - 2017-12-26 20:08:01 --> Controller Class Initialized
INFO - 2017-12-26 20:08:01 --> Model Class Initialized
DEBUG - 2017-12-26 20:08:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:08:01 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-26 20:08:01 --> Final output sent to browser
DEBUG - 2017-12-26 20:08:01 --> Total execution time: 0.0872
INFO - 2017-12-26 20:08:03 --> Config Class Initialized
INFO - 2017-12-26 20:08:03 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:08:03 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:08:03 --> Utf8 Class Initialized
INFO - 2017-12-26 20:08:03 --> URI Class Initialized
INFO - 2017-12-26 20:08:03 --> Router Class Initialized
INFO - 2017-12-26 20:08:03 --> Output Class Initialized
INFO - 2017-12-26 20:08:03 --> Security Class Initialized
DEBUG - 2017-12-26 20:08:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:08:03 --> Input Class Initialized
INFO - 2017-12-26 20:08:03 --> Language Class Initialized
INFO - 2017-12-26 20:08:03 --> Loader Class Initialized
INFO - 2017-12-26 20:08:03 --> Helper loaded: url_helper
INFO - 2017-12-26 20:08:03 --> Helper loaded: form_helper
INFO - 2017-12-26 20:08:03 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:08:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:08:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:08:03 --> Form Validation Class Initialized
INFO - 2017-12-26 20:08:03 --> Model Class Initialized
INFO - 2017-12-26 20:08:03 --> Controller Class Initialized
INFO - 2017-12-26 20:08:03 --> Model Class Initialized
DEBUG - 2017-12-26 20:08:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:08:03 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-26 20:08:03 --> Final output sent to browser
DEBUG - 2017-12-26 20:08:03 --> Total execution time: 0.0522
INFO - 2017-12-26 20:08:07 --> Config Class Initialized
INFO - 2017-12-26 20:08:07 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:08:07 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:08:07 --> Utf8 Class Initialized
INFO - 2017-12-26 20:08:07 --> URI Class Initialized
INFO - 2017-12-26 20:08:07 --> Router Class Initialized
INFO - 2017-12-26 20:08:07 --> Output Class Initialized
INFO - 2017-12-26 20:08:07 --> Security Class Initialized
DEBUG - 2017-12-26 20:08:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:08:07 --> Input Class Initialized
INFO - 2017-12-26 20:08:07 --> Language Class Initialized
INFO - 2017-12-26 20:08:07 --> Loader Class Initialized
INFO - 2017-12-26 20:08:07 --> Helper loaded: url_helper
INFO - 2017-12-26 20:08:07 --> Helper loaded: form_helper
INFO - 2017-12-26 20:08:07 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:08:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:08:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:08:07 --> Form Validation Class Initialized
INFO - 2017-12-26 20:08:07 --> Model Class Initialized
INFO - 2017-12-26 20:08:07 --> Controller Class Initialized
INFO - 2017-12-26 20:08:07 --> Model Class Initialized
DEBUG - 2017-12-26 20:08:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:08:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-12-26 20:08:07 --> Config Class Initialized
INFO - 2017-12-26 20:08:07 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:08:07 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:08:07 --> Utf8 Class Initialized
INFO - 2017-12-26 20:08:07 --> URI Class Initialized
DEBUG - 2017-12-26 20:08:07 --> No URI present. Default controller set.
INFO - 2017-12-26 20:08:07 --> Router Class Initialized
INFO - 2017-12-26 20:08:07 --> Output Class Initialized
INFO - 2017-12-26 20:08:07 --> Security Class Initialized
DEBUG - 2017-12-26 20:08:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:08:07 --> Input Class Initialized
INFO - 2017-12-26 20:08:07 --> Language Class Initialized
INFO - 2017-12-26 20:08:07 --> Loader Class Initialized
INFO - 2017-12-26 20:08:07 --> Helper loaded: url_helper
INFO - 2017-12-26 20:08:07 --> Helper loaded: form_helper
INFO - 2017-12-26 20:08:07 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:08:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:08:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:08:07 --> Form Validation Class Initialized
INFO - 2017-12-26 20:08:07 --> Model Class Initialized
INFO - 2017-12-26 20:08:07 --> Controller Class Initialized
INFO - 2017-12-26 20:08:07 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-26 20:08:07 --> Final output sent to browser
DEBUG - 2017-12-26 20:08:07 --> Total execution time: 0.0860
INFO - 2017-12-26 20:08:11 --> Config Class Initialized
INFO - 2017-12-26 20:08:11 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:08:11 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:08:11 --> Utf8 Class Initialized
INFO - 2017-12-26 20:08:11 --> URI Class Initialized
INFO - 2017-12-26 20:08:11 --> Router Class Initialized
INFO - 2017-12-26 20:08:11 --> Output Class Initialized
INFO - 2017-12-26 20:08:11 --> Security Class Initialized
DEBUG - 2017-12-26 20:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:08:11 --> Input Class Initialized
INFO - 2017-12-26 20:08:11 --> Language Class Initialized
INFO - 2017-12-26 20:08:11 --> Loader Class Initialized
INFO - 2017-12-26 20:08:11 --> Helper loaded: url_helper
INFO - 2017-12-26 20:08:11 --> Helper loaded: form_helper
INFO - 2017-12-26 20:08:11 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:08:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:08:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:08:11 --> Form Validation Class Initialized
INFO - 2017-12-26 20:08:11 --> Model Class Initialized
INFO - 2017-12-26 20:08:11 --> Controller Class Initialized
INFO - 2017-12-26 20:08:11 --> Model Class Initialized
INFO - 2017-12-26 20:08:11 --> Model Class Initialized
INFO - 2017-12-26 20:08:11 --> Model Class Initialized
DEBUG - 2017-12-26 20:08:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:08:11 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-26 20:08:11 --> Final output sent to browser
DEBUG - 2017-12-26 20:08:11 --> Total execution time: 0.0733
INFO - 2017-12-26 20:08:11 --> Config Class Initialized
INFO - 2017-12-26 20:08:11 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:08:11 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:08:11 --> Utf8 Class Initialized
INFO - 2017-12-26 20:08:11 --> URI Class Initialized
INFO - 2017-12-26 20:08:11 --> Router Class Initialized
INFO - 2017-12-26 20:08:11 --> Output Class Initialized
INFO - 2017-12-26 20:08:11 --> Security Class Initialized
DEBUG - 2017-12-26 20:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:08:11 --> Input Class Initialized
INFO - 2017-12-26 20:08:11 --> Language Class Initialized
INFO - 2017-12-26 20:08:11 --> Loader Class Initialized
INFO - 2017-12-26 20:08:11 --> Helper loaded: url_helper
INFO - 2017-12-26 20:08:11 --> Helper loaded: form_helper
INFO - 2017-12-26 20:08:11 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:08:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:08:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:08:11 --> Form Validation Class Initialized
INFO - 2017-12-26 20:08:11 --> Model Class Initialized
INFO - 2017-12-26 20:08:11 --> Controller Class Initialized
INFO - 2017-12-26 20:08:11 --> Model Class Initialized
INFO - 2017-12-26 20:08:11 --> Model Class Initialized
INFO - 2017-12-26 20:08:11 --> Model Class Initialized
DEBUG - 2017-12-26 20:08:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:08:14 --> Config Class Initialized
INFO - 2017-12-26 20:08:14 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:08:14 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:08:14 --> Utf8 Class Initialized
INFO - 2017-12-26 20:08:14 --> URI Class Initialized
INFO - 2017-12-26 20:08:14 --> Router Class Initialized
INFO - 2017-12-26 20:08:14 --> Output Class Initialized
INFO - 2017-12-26 20:08:14 --> Security Class Initialized
DEBUG - 2017-12-26 20:08:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:08:14 --> Input Class Initialized
INFO - 2017-12-26 20:08:14 --> Language Class Initialized
INFO - 2017-12-26 20:08:14 --> Loader Class Initialized
INFO - 2017-12-26 20:08:14 --> Helper loaded: url_helper
INFO - 2017-12-26 20:08:14 --> Helper loaded: form_helper
INFO - 2017-12-26 20:08:14 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:08:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:08:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:08:14 --> Form Validation Class Initialized
INFO - 2017-12-26 20:08:14 --> Model Class Initialized
INFO - 2017-12-26 20:08:14 --> Controller Class Initialized
INFO - 2017-12-26 20:08:14 --> Model Class Initialized
INFO - 2017-12-26 20:08:14 --> Model Class Initialized
INFO - 2017-12-26 20:08:14 --> Model Class Initialized
DEBUG - 2017-12-26 20:08:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:08:14 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-26 20:08:14 --> Final output sent to browser
DEBUG - 2017-12-26 20:08:14 --> Total execution time: 0.0982
INFO - 2017-12-26 20:08:14 --> Config Class Initialized
INFO - 2017-12-26 20:08:14 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:08:14 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:08:14 --> Utf8 Class Initialized
INFO - 2017-12-26 20:08:14 --> URI Class Initialized
INFO - 2017-12-26 20:08:14 --> Router Class Initialized
INFO - 2017-12-26 20:08:14 --> Output Class Initialized
INFO - 2017-12-26 20:08:14 --> Security Class Initialized
DEBUG - 2017-12-26 20:08:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:08:14 --> Input Class Initialized
INFO - 2017-12-26 20:08:14 --> Language Class Initialized
INFO - 2017-12-26 20:08:14 --> Loader Class Initialized
INFO - 2017-12-26 20:08:14 --> Helper loaded: url_helper
INFO - 2017-12-26 20:08:14 --> Helper loaded: form_helper
INFO - 2017-12-26 20:08:14 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:08:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:08:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:08:14 --> Form Validation Class Initialized
INFO - 2017-12-26 20:08:14 --> Model Class Initialized
INFO - 2017-12-26 20:08:14 --> Controller Class Initialized
INFO - 2017-12-26 20:08:14 --> Model Class Initialized
INFO - 2017-12-26 20:08:14 --> Model Class Initialized
INFO - 2017-12-26 20:08:14 --> Model Class Initialized
DEBUG - 2017-12-26 20:08:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:08:16 --> Config Class Initialized
INFO - 2017-12-26 20:08:16 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:08:16 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:08:16 --> Utf8 Class Initialized
INFO - 2017-12-26 20:08:16 --> URI Class Initialized
INFO - 2017-12-26 20:08:16 --> Router Class Initialized
INFO - 2017-12-26 20:08:16 --> Output Class Initialized
INFO - 2017-12-26 20:08:16 --> Security Class Initialized
DEBUG - 2017-12-26 20:08:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:08:16 --> Input Class Initialized
INFO - 2017-12-26 20:08:16 --> Language Class Initialized
INFO - 2017-12-26 20:08:16 --> Loader Class Initialized
INFO - 2017-12-26 20:08:16 --> Helper loaded: url_helper
INFO - 2017-12-26 20:08:16 --> Helper loaded: form_helper
INFO - 2017-12-26 20:08:16 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:08:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:08:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:08:16 --> Form Validation Class Initialized
INFO - 2017-12-26 20:08:16 --> Model Class Initialized
INFO - 2017-12-26 20:08:16 --> Controller Class Initialized
INFO - 2017-12-26 20:08:16 --> Model Class Initialized
INFO - 2017-12-26 20:08:16 --> Model Class Initialized
INFO - 2017-12-26 20:08:16 --> Model Class Initialized
DEBUG - 2017-12-26 20:08:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:08:16 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-26 20:08:16 --> Final output sent to browser
DEBUG - 2017-12-26 20:08:16 --> Total execution time: 0.0852
INFO - 2017-12-26 20:08:31 --> Config Class Initialized
INFO - 2017-12-26 20:08:31 --> Hooks Class Initialized
INFO - 2017-12-26 20:08:31 --> Config Class Initialized
INFO - 2017-12-26 20:08:31 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:08:31 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:08:31 --> Utf8 Class Initialized
INFO - 2017-12-26 20:08:31 --> URI Class Initialized
DEBUG - 2017-12-26 20:08:31 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:08:31 --> Router Class Initialized
INFO - 2017-12-26 20:08:31 --> Utf8 Class Initialized
INFO - 2017-12-26 20:08:31 --> URI Class Initialized
INFO - 2017-12-26 20:08:31 --> Output Class Initialized
INFO - 2017-12-26 20:08:31 --> Router Class Initialized
INFO - 2017-12-26 20:08:31 --> Security Class Initialized
DEBUG - 2017-12-26 20:08:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:08:31 --> Output Class Initialized
INFO - 2017-12-26 20:08:31 --> Input Class Initialized
INFO - 2017-12-26 20:08:31 --> Language Class Initialized
INFO - 2017-12-26 20:08:31 --> Security Class Initialized
DEBUG - 2017-12-26 20:08:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:08:31 --> Input Class Initialized
INFO - 2017-12-26 20:08:31 --> Language Class Initialized
ERROR - 2017-12-26 20:08:31 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-26 20:08:31 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-26 20:09:05 --> Config Class Initialized
INFO - 2017-12-26 20:09:05 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:09:05 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:09:05 --> Utf8 Class Initialized
INFO - 2017-12-26 20:09:05 --> URI Class Initialized
INFO - 2017-12-26 20:09:05 --> Router Class Initialized
INFO - 2017-12-26 20:09:05 --> Output Class Initialized
INFO - 2017-12-26 20:09:05 --> Security Class Initialized
DEBUG - 2017-12-26 20:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:09:05 --> Input Class Initialized
INFO - 2017-12-26 20:09:05 --> Language Class Initialized
INFO - 2017-12-26 20:09:05 --> Loader Class Initialized
INFO - 2017-12-26 20:09:05 --> Helper loaded: url_helper
INFO - 2017-12-26 20:09:05 --> Helper loaded: form_helper
INFO - 2017-12-26 20:09:05 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:09:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:09:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:09:05 --> Form Validation Class Initialized
INFO - 2017-12-26 20:09:05 --> Model Class Initialized
INFO - 2017-12-26 20:09:05 --> Controller Class Initialized
INFO - 2017-12-26 20:09:05 --> Model Class Initialized
INFO - 2017-12-26 20:09:05 --> Model Class Initialized
INFO - 2017-12-26 20:09:05 --> Model Class Initialized
DEBUG - 2017-12-26 20:09:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:09:05 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-26 20:09:05 --> Final output sent to browser
DEBUG - 2017-12-26 20:09:05 --> Total execution time: 0.0831
INFO - 2017-12-26 20:09:05 --> Config Class Initialized
INFO - 2017-12-26 20:09:05 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:09:05 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:09:05 --> Utf8 Class Initialized
INFO - 2017-12-26 20:09:05 --> URI Class Initialized
INFO - 2017-12-26 20:09:05 --> Router Class Initialized
INFO - 2017-12-26 20:09:05 --> Output Class Initialized
INFO - 2017-12-26 20:09:05 --> Security Class Initialized
DEBUG - 2017-12-26 20:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:09:05 --> Input Class Initialized
INFO - 2017-12-26 20:09:05 --> Language Class Initialized
ERROR - 2017-12-26 20:09:05 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-26 20:09:05 --> Config Class Initialized
INFO - 2017-12-26 20:09:05 --> Hooks Class Initialized
INFO - 2017-12-26 20:09:05 --> Config Class Initialized
INFO - 2017-12-26 20:09:05 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:09:05 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:09:05 --> Utf8 Class Initialized
DEBUG - 2017-12-26 20:09:05 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:09:05 --> Utf8 Class Initialized
INFO - 2017-12-26 20:09:05 --> URI Class Initialized
INFO - 2017-12-26 20:09:05 --> URI Class Initialized
INFO - 2017-12-26 20:09:05 --> Router Class Initialized
INFO - 2017-12-26 20:09:05 --> Router Class Initialized
INFO - 2017-12-26 20:09:05 --> Output Class Initialized
INFO - 2017-12-26 20:09:05 --> Output Class Initialized
INFO - 2017-12-26 20:09:05 --> Security Class Initialized
INFO - 2017-12-26 20:09:05 --> Security Class Initialized
DEBUG - 2017-12-26 20:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:09:05 --> Input Class Initialized
DEBUG - 2017-12-26 20:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:09:05 --> Language Class Initialized
INFO - 2017-12-26 20:09:05 --> Input Class Initialized
INFO - 2017-12-26 20:09:05 --> Language Class Initialized
ERROR - 2017-12-26 20:09:05 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-26 20:09:05 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-26 20:29:27 --> Config Class Initialized
INFO - 2017-12-26 20:29:27 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:29:27 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:29:27 --> Utf8 Class Initialized
INFO - 2017-12-26 20:29:27 --> URI Class Initialized
INFO - 2017-12-26 20:29:27 --> Router Class Initialized
INFO - 2017-12-26 20:29:27 --> Output Class Initialized
INFO - 2017-12-26 20:29:27 --> Security Class Initialized
DEBUG - 2017-12-26 20:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:29:27 --> Input Class Initialized
INFO - 2017-12-26 20:29:27 --> Language Class Initialized
INFO - 2017-12-26 20:29:27 --> Loader Class Initialized
INFO - 2017-12-26 20:29:27 --> Helper loaded: url_helper
INFO - 2017-12-26 20:29:27 --> Helper loaded: form_helper
INFO - 2017-12-26 20:29:27 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:29:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:29:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:29:27 --> Form Validation Class Initialized
INFO - 2017-12-26 20:29:27 --> Model Class Initialized
INFO - 2017-12-26 20:29:27 --> Controller Class Initialized
INFO - 2017-12-26 20:29:27 --> Model Class Initialized
INFO - 2017-12-26 20:29:27 --> Model Class Initialized
INFO - 2017-12-26 20:29:27 --> Model Class Initialized
DEBUG - 2017-12-26 20:29:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:29:27 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-26 20:29:27 --> Final output sent to browser
DEBUG - 2017-12-26 20:29:27 --> Total execution time: 0.1426
INFO - 2017-12-26 20:29:28 --> Config Class Initialized
INFO - 2017-12-26 20:29:28 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:29:28 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:29:28 --> Utf8 Class Initialized
INFO - 2017-12-26 20:29:28 --> URI Class Initialized
INFO - 2017-12-26 20:29:28 --> Router Class Initialized
INFO - 2017-12-26 20:29:28 --> Output Class Initialized
INFO - 2017-12-26 20:29:28 --> Security Class Initialized
DEBUG - 2017-12-26 20:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:29:28 --> Input Class Initialized
INFO - 2017-12-26 20:29:28 --> Language Class Initialized
INFO - 2017-12-26 20:29:28 --> Loader Class Initialized
INFO - 2017-12-26 20:29:28 --> Helper loaded: url_helper
INFO - 2017-12-26 20:29:28 --> Helper loaded: form_helper
INFO - 2017-12-26 20:29:28 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:29:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:29:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:29:28 --> Form Validation Class Initialized
INFO - 2017-12-26 20:29:28 --> Model Class Initialized
INFO - 2017-12-26 20:29:28 --> Controller Class Initialized
INFO - 2017-12-26 20:29:28 --> Model Class Initialized
INFO - 2017-12-26 20:29:28 --> Model Class Initialized
INFO - 2017-12-26 20:29:28 --> Model Class Initialized
DEBUG - 2017-12-26 20:29:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:29:28 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-26 20:29:28 --> Final output sent to browser
DEBUG - 2017-12-26 20:29:28 --> Total execution time: 0.1501
INFO - 2017-12-26 20:29:28 --> Config Class Initialized
INFO - 2017-12-26 20:29:28 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:29:28 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:29:28 --> Utf8 Class Initialized
INFO - 2017-12-26 20:29:28 --> URI Class Initialized
INFO - 2017-12-26 20:29:28 --> Router Class Initialized
INFO - 2017-12-26 20:29:28 --> Output Class Initialized
INFO - 2017-12-26 20:29:28 --> Security Class Initialized
DEBUG - 2017-12-26 20:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:29:28 --> Input Class Initialized
INFO - 2017-12-26 20:29:28 --> Language Class Initialized
INFO - 2017-12-26 20:29:28 --> Loader Class Initialized
INFO - 2017-12-26 20:29:28 --> Helper loaded: url_helper
INFO - 2017-12-26 20:29:28 --> Helper loaded: form_helper
INFO - 2017-12-26 20:29:28 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:29:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:29:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:29:28 --> Form Validation Class Initialized
INFO - 2017-12-26 20:29:28 --> Model Class Initialized
INFO - 2017-12-26 20:29:28 --> Controller Class Initialized
INFO - 2017-12-26 20:29:28 --> Model Class Initialized
INFO - 2017-12-26 20:29:28 --> Model Class Initialized
INFO - 2017-12-26 20:29:28 --> Model Class Initialized
DEBUG - 2017-12-26 20:29:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:29:28 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-26 20:29:28 --> Final output sent to browser
DEBUG - 2017-12-26 20:29:28 --> Total execution time: 0.1018
INFO - 2017-12-26 20:29:29 --> Config Class Initialized
INFO - 2017-12-26 20:29:29 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:29:29 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:29:29 --> Utf8 Class Initialized
INFO - 2017-12-26 20:29:29 --> URI Class Initialized
INFO - 2017-12-26 20:29:29 --> Router Class Initialized
INFO - 2017-12-26 20:29:29 --> Output Class Initialized
INFO - 2017-12-26 20:29:29 --> Security Class Initialized
DEBUG - 2017-12-26 20:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:29:29 --> Input Class Initialized
INFO - 2017-12-26 20:29:29 --> Language Class Initialized
INFO - 2017-12-26 20:29:29 --> Loader Class Initialized
INFO - 2017-12-26 20:29:29 --> Helper loaded: url_helper
INFO - 2017-12-26 20:29:29 --> Helper loaded: form_helper
INFO - 2017-12-26 20:29:29 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:29:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:29:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:29:29 --> Form Validation Class Initialized
INFO - 2017-12-26 20:29:29 --> Model Class Initialized
INFO - 2017-12-26 20:29:29 --> Controller Class Initialized
INFO - 2017-12-26 20:29:29 --> Model Class Initialized
INFO - 2017-12-26 20:29:29 --> Model Class Initialized
INFO - 2017-12-26 20:29:29 --> Model Class Initialized
DEBUG - 2017-12-26 20:29:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:29:29 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-26 20:29:29 --> Final output sent to browser
DEBUG - 2017-12-26 20:29:29 --> Total execution time: 0.1019
INFO - 2017-12-26 20:29:29 --> Config Class Initialized
INFO - 2017-12-26 20:29:29 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:29:29 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:29:29 --> Utf8 Class Initialized
INFO - 2017-12-26 20:29:29 --> URI Class Initialized
INFO - 2017-12-26 20:29:29 --> Router Class Initialized
INFO - 2017-12-26 20:29:29 --> Output Class Initialized
INFO - 2017-12-26 20:29:29 --> Security Class Initialized
DEBUG - 2017-12-26 20:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:29:29 --> Input Class Initialized
INFO - 2017-12-26 20:29:29 --> Language Class Initialized
INFO - 2017-12-26 20:29:29 --> Loader Class Initialized
INFO - 2017-12-26 20:29:29 --> Helper loaded: url_helper
INFO - 2017-12-26 20:29:29 --> Helper loaded: form_helper
INFO - 2017-12-26 20:29:29 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:29:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:29:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:29:29 --> Form Validation Class Initialized
INFO - 2017-12-26 20:29:29 --> Model Class Initialized
INFO - 2017-12-26 20:29:29 --> Controller Class Initialized
INFO - 2017-12-26 20:29:29 --> Model Class Initialized
INFO - 2017-12-26 20:29:29 --> Model Class Initialized
INFO - 2017-12-26 20:29:29 --> Model Class Initialized
DEBUG - 2017-12-26 20:29:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:29:29 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-26 20:29:29 --> Final output sent to browser
DEBUG - 2017-12-26 20:29:29 --> Total execution time: 0.1037
INFO - 2017-12-26 20:29:29 --> Config Class Initialized
INFO - 2017-12-26 20:29:29 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:29:29 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:29:29 --> Utf8 Class Initialized
INFO - 2017-12-26 20:29:29 --> URI Class Initialized
INFO - 2017-12-26 20:29:29 --> Router Class Initialized
INFO - 2017-12-26 20:29:29 --> Output Class Initialized
INFO - 2017-12-26 20:29:29 --> Security Class Initialized
DEBUG - 2017-12-26 20:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:29:29 --> Input Class Initialized
INFO - 2017-12-26 20:29:29 --> Language Class Initialized
INFO - 2017-12-26 20:29:29 --> Loader Class Initialized
INFO - 2017-12-26 20:29:29 --> Helper loaded: url_helper
INFO - 2017-12-26 20:29:29 --> Helper loaded: form_helper
INFO - 2017-12-26 20:29:29 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:29:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:29:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:29:29 --> Form Validation Class Initialized
INFO - 2017-12-26 20:29:29 --> Model Class Initialized
INFO - 2017-12-26 20:29:29 --> Controller Class Initialized
INFO - 2017-12-26 20:29:29 --> Model Class Initialized
INFO - 2017-12-26 20:29:29 --> Model Class Initialized
INFO - 2017-12-26 20:29:29 --> Model Class Initialized
DEBUG - 2017-12-26 20:29:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:29:29 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-26 20:29:29 --> Final output sent to browser
DEBUG - 2017-12-26 20:29:29 --> Total execution time: 0.1038
INFO - 2017-12-26 20:29:30 --> Config Class Initialized
INFO - 2017-12-26 20:29:30 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:29:30 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:29:30 --> Utf8 Class Initialized
INFO - 2017-12-26 20:29:30 --> URI Class Initialized
INFO - 2017-12-26 20:29:30 --> Router Class Initialized
INFO - 2017-12-26 20:29:30 --> Output Class Initialized
INFO - 2017-12-26 20:29:30 --> Security Class Initialized
DEBUG - 2017-12-26 20:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:29:30 --> Input Class Initialized
INFO - 2017-12-26 20:29:30 --> Language Class Initialized
INFO - 2017-12-26 20:29:30 --> Loader Class Initialized
INFO - 2017-12-26 20:29:30 --> Helper loaded: url_helper
INFO - 2017-12-26 20:29:30 --> Helper loaded: form_helper
INFO - 2017-12-26 20:29:30 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:29:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:29:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:29:30 --> Form Validation Class Initialized
INFO - 2017-12-26 20:29:30 --> Model Class Initialized
INFO - 2017-12-26 20:29:30 --> Controller Class Initialized
INFO - 2017-12-26 20:29:30 --> Model Class Initialized
INFO - 2017-12-26 20:29:30 --> Model Class Initialized
INFO - 2017-12-26 20:29:30 --> Model Class Initialized
DEBUG - 2017-12-26 20:29:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:29:30 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-26 20:29:30 --> Final output sent to browser
DEBUG - 2017-12-26 20:29:30 --> Total execution time: 0.1185
INFO - 2017-12-26 20:29:31 --> Config Class Initialized
INFO - 2017-12-26 20:29:31 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:29:31 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:29:31 --> Utf8 Class Initialized
INFO - 2017-12-26 20:29:31 --> URI Class Initialized
INFO - 2017-12-26 20:29:31 --> Router Class Initialized
INFO - 2017-12-26 20:29:31 --> Output Class Initialized
INFO - 2017-12-26 20:29:31 --> Security Class Initialized
DEBUG - 2017-12-26 20:29:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:29:31 --> Input Class Initialized
INFO - 2017-12-26 20:29:31 --> Language Class Initialized
INFO - 2017-12-26 20:29:31 --> Loader Class Initialized
INFO - 2017-12-26 20:29:31 --> Helper loaded: url_helper
INFO - 2017-12-26 20:29:31 --> Helper loaded: form_helper
INFO - 2017-12-26 20:29:31 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:29:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:29:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:29:31 --> Form Validation Class Initialized
INFO - 2017-12-26 20:29:31 --> Model Class Initialized
INFO - 2017-12-26 20:29:31 --> Controller Class Initialized
INFO - 2017-12-26 20:29:31 --> Model Class Initialized
INFO - 2017-12-26 20:29:31 --> Model Class Initialized
INFO - 2017-12-26 20:29:31 --> Model Class Initialized
DEBUG - 2017-12-26 20:29:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:29:31 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-26 20:29:31 --> Final output sent to browser
DEBUG - 2017-12-26 20:29:31 --> Total execution time: 0.0618
INFO - 2017-12-26 20:29:31 --> Config Class Initialized
INFO - 2017-12-26 20:29:31 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:29:31 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:29:31 --> Utf8 Class Initialized
INFO - 2017-12-26 20:29:31 --> URI Class Initialized
INFO - 2017-12-26 20:29:31 --> Router Class Initialized
INFO - 2017-12-26 20:29:31 --> Output Class Initialized
INFO - 2017-12-26 20:29:31 --> Security Class Initialized
DEBUG - 2017-12-26 20:29:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:29:31 --> Input Class Initialized
INFO - 2017-12-26 20:29:31 --> Language Class Initialized
INFO - 2017-12-26 20:29:31 --> Loader Class Initialized
INFO - 2017-12-26 20:29:31 --> Helper loaded: url_helper
INFO - 2017-12-26 20:29:31 --> Helper loaded: form_helper
INFO - 2017-12-26 20:29:31 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:29:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:29:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:29:31 --> Form Validation Class Initialized
INFO - 2017-12-26 20:29:31 --> Model Class Initialized
INFO - 2017-12-26 20:29:31 --> Controller Class Initialized
INFO - 2017-12-26 20:29:31 --> Model Class Initialized
INFO - 2017-12-26 20:29:31 --> Model Class Initialized
INFO - 2017-12-26 20:29:31 --> Model Class Initialized
DEBUG - 2017-12-26 20:29:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:29:32 --> Config Class Initialized
INFO - 2017-12-26 20:29:32 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:29:33 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:29:33 --> Utf8 Class Initialized
INFO - 2017-12-26 20:29:33 --> URI Class Initialized
INFO - 2017-12-26 20:29:33 --> Router Class Initialized
INFO - 2017-12-26 20:29:33 --> Output Class Initialized
INFO - 2017-12-26 20:29:33 --> Security Class Initialized
DEBUG - 2017-12-26 20:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:29:33 --> Input Class Initialized
INFO - 2017-12-26 20:29:33 --> Language Class Initialized
INFO - 2017-12-26 20:29:33 --> Loader Class Initialized
INFO - 2017-12-26 20:29:33 --> Helper loaded: url_helper
INFO - 2017-12-26 20:29:33 --> Helper loaded: form_helper
INFO - 2017-12-26 20:29:33 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:29:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:29:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:29:33 --> Form Validation Class Initialized
INFO - 2017-12-26 20:29:33 --> Model Class Initialized
INFO - 2017-12-26 20:29:33 --> Controller Class Initialized
INFO - 2017-12-26 20:29:33 --> Model Class Initialized
INFO - 2017-12-26 20:29:33 --> Model Class Initialized
INFO - 2017-12-26 20:29:33 --> Model Class Initialized
DEBUG - 2017-12-26 20:29:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:29:33 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-26 20:29:33 --> Final output sent to browser
DEBUG - 2017-12-26 20:29:33 --> Total execution time: 0.0689
INFO - 2017-12-26 20:32:10 --> Config Class Initialized
INFO - 2017-12-26 20:32:10 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:32:10 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:32:10 --> Utf8 Class Initialized
INFO - 2017-12-26 20:32:10 --> URI Class Initialized
INFO - 2017-12-26 20:32:10 --> Router Class Initialized
INFO - 2017-12-26 20:32:10 --> Output Class Initialized
INFO - 2017-12-26 20:32:10 --> Security Class Initialized
DEBUG - 2017-12-26 20:32:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:32:10 --> Input Class Initialized
INFO - 2017-12-26 20:32:10 --> Language Class Initialized
INFO - 2017-12-26 20:32:10 --> Loader Class Initialized
INFO - 2017-12-26 20:32:10 --> Helper loaded: url_helper
INFO - 2017-12-26 20:32:10 --> Helper loaded: form_helper
INFO - 2017-12-26 20:32:10 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:32:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:32:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:32:10 --> Form Validation Class Initialized
INFO - 2017-12-26 20:32:10 --> Model Class Initialized
INFO - 2017-12-26 20:32:10 --> Controller Class Initialized
INFO - 2017-12-26 20:32:10 --> Model Class Initialized
INFO - 2017-12-26 20:32:10 --> Model Class Initialized
INFO - 2017-12-26 20:32:10 --> Model Class Initialized
DEBUG - 2017-12-26 20:32:10 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2017-12-26 20:32:10 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 40
ERROR - 2017-12-26 20:32:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 40
ERROR - 2017-12-26 20:32:10 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 40
ERROR - 2017-12-26 20:32:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 40
ERROR - 2017-12-26 20:32:10 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 41
ERROR - 2017-12-26 20:32:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 41
ERROR - 2017-12-26 20:32:10 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 41
ERROR - 2017-12-26 20:32:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 41
ERROR - 2017-12-26 20:32:10 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 42
ERROR - 2017-12-26 20:32:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 42
ERROR - 2017-12-26 20:32:10 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 42
ERROR - 2017-12-26 20:32:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 42
ERROR - 2017-12-26 20:32:10 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 44
ERROR - 2017-12-26 20:32:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 44
INFO - 2017-12-26 20:32:10 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-26 20:32:10 --> Final output sent to browser
DEBUG - 2017-12-26 20:32:10 --> Total execution time: 0.1619
INFO - 2017-12-26 20:32:11 --> Config Class Initialized
INFO - 2017-12-26 20:32:11 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:32:11 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:32:11 --> Utf8 Class Initialized
INFO - 2017-12-26 20:32:11 --> URI Class Initialized
INFO - 2017-12-26 20:32:11 --> Router Class Initialized
INFO - 2017-12-26 20:32:11 --> Output Class Initialized
INFO - 2017-12-26 20:32:11 --> Security Class Initialized
DEBUG - 2017-12-26 20:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:32:11 --> Input Class Initialized
INFO - 2017-12-26 20:32:11 --> Language Class Initialized
INFO - 2017-12-26 20:32:11 --> Loader Class Initialized
INFO - 2017-12-26 20:32:11 --> Helper loaded: url_helper
INFO - 2017-12-26 20:32:11 --> Helper loaded: form_helper
INFO - 2017-12-26 20:32:11 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:32:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:32:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:32:11 --> Form Validation Class Initialized
INFO - 2017-12-26 20:32:11 --> Model Class Initialized
INFO - 2017-12-26 20:32:11 --> Controller Class Initialized
INFO - 2017-12-26 20:32:11 --> Model Class Initialized
INFO - 2017-12-26 20:32:11 --> Model Class Initialized
INFO - 2017-12-26 20:32:11 --> Model Class Initialized
DEBUG - 2017-12-26 20:32:11 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2017-12-26 20:32:11 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 40
ERROR - 2017-12-26 20:32:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 40
ERROR - 2017-12-26 20:32:11 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 40
ERROR - 2017-12-26 20:32:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 40
ERROR - 2017-12-26 20:32:11 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 41
ERROR - 2017-12-26 20:32:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 41
ERROR - 2017-12-26 20:32:11 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 41
ERROR - 2017-12-26 20:32:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 41
ERROR - 2017-12-26 20:32:11 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 42
ERROR - 2017-12-26 20:32:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 42
ERROR - 2017-12-26 20:32:11 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 42
ERROR - 2017-12-26 20:32:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 42
ERROR - 2017-12-26 20:32:11 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 44
ERROR - 2017-12-26 20:32:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 44
INFO - 2017-12-26 20:32:11 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-26 20:32:11 --> Final output sent to browser
DEBUG - 2017-12-26 20:32:11 --> Total execution time: 0.1574
INFO - 2017-12-26 20:32:12 --> Config Class Initialized
INFO - 2017-12-26 20:32:12 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:32:12 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:32:12 --> Utf8 Class Initialized
INFO - 2017-12-26 20:32:12 --> URI Class Initialized
INFO - 2017-12-26 20:32:12 --> Router Class Initialized
INFO - 2017-12-26 20:32:12 --> Output Class Initialized
INFO - 2017-12-26 20:32:12 --> Security Class Initialized
DEBUG - 2017-12-26 20:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:32:12 --> Input Class Initialized
INFO - 2017-12-26 20:32:12 --> Language Class Initialized
INFO - 2017-12-26 20:32:12 --> Loader Class Initialized
INFO - 2017-12-26 20:32:12 --> Helper loaded: url_helper
INFO - 2017-12-26 20:32:12 --> Helper loaded: form_helper
INFO - 2017-12-26 20:32:12 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:32:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:32:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:32:12 --> Form Validation Class Initialized
INFO - 2017-12-26 20:32:12 --> Model Class Initialized
INFO - 2017-12-26 20:32:12 --> Controller Class Initialized
INFO - 2017-12-26 20:32:12 --> Model Class Initialized
INFO - 2017-12-26 20:32:12 --> Model Class Initialized
INFO - 2017-12-26 20:32:12 --> Model Class Initialized
DEBUG - 2017-12-26 20:32:12 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2017-12-26 20:32:12 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 40
ERROR - 2017-12-26 20:32:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 40
ERROR - 2017-12-26 20:32:12 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 40
ERROR - 2017-12-26 20:32:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 40
ERROR - 2017-12-26 20:32:12 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 41
ERROR - 2017-12-26 20:32:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 41
ERROR - 2017-12-26 20:32:12 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 41
ERROR - 2017-12-26 20:32:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 41
ERROR - 2017-12-26 20:32:12 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 42
ERROR - 2017-12-26 20:32:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 42
ERROR - 2017-12-26 20:32:12 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 42
ERROR - 2017-12-26 20:32:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 42
ERROR - 2017-12-26 20:32:12 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 44
ERROR - 2017-12-26 20:32:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 44
INFO - 2017-12-26 20:32:12 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-26 20:32:12 --> Final output sent to browser
DEBUG - 2017-12-26 20:32:12 --> Total execution time: 0.1581
INFO - 2017-12-26 20:32:12 --> Config Class Initialized
INFO - 2017-12-26 20:32:12 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:32:12 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:32:12 --> Utf8 Class Initialized
INFO - 2017-12-26 20:32:12 --> URI Class Initialized
INFO - 2017-12-26 20:32:12 --> Router Class Initialized
INFO - 2017-12-26 20:32:12 --> Output Class Initialized
INFO - 2017-12-26 20:32:12 --> Security Class Initialized
DEBUG - 2017-12-26 20:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:32:12 --> Input Class Initialized
INFO - 2017-12-26 20:32:12 --> Language Class Initialized
INFO - 2017-12-26 20:32:12 --> Loader Class Initialized
INFO - 2017-12-26 20:32:12 --> Helper loaded: url_helper
INFO - 2017-12-26 20:32:12 --> Helper loaded: form_helper
INFO - 2017-12-26 20:32:12 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:32:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:32:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:32:12 --> Form Validation Class Initialized
INFO - 2017-12-26 20:32:12 --> Model Class Initialized
INFO - 2017-12-26 20:32:12 --> Controller Class Initialized
INFO - 2017-12-26 20:32:12 --> Model Class Initialized
INFO - 2017-12-26 20:32:12 --> Model Class Initialized
INFO - 2017-12-26 20:32:12 --> Model Class Initialized
DEBUG - 2017-12-26 20:32:12 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2017-12-26 20:32:12 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 40
ERROR - 2017-12-26 20:32:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 40
ERROR - 2017-12-26 20:32:12 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 40
ERROR - 2017-12-26 20:32:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 40
ERROR - 2017-12-26 20:32:12 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 41
ERROR - 2017-12-26 20:32:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 41
ERROR - 2017-12-26 20:32:12 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 41
ERROR - 2017-12-26 20:32:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 41
ERROR - 2017-12-26 20:32:12 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 42
ERROR - 2017-12-26 20:32:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 42
ERROR - 2017-12-26 20:32:12 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 42
ERROR - 2017-12-26 20:32:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 42
ERROR - 2017-12-26 20:32:12 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 44
ERROR - 2017-12-26 20:32:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 44
INFO - 2017-12-26 20:32:12 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-26 20:32:12 --> Final output sent to browser
DEBUG - 2017-12-26 20:32:12 --> Total execution time: 0.1535
INFO - 2017-12-26 20:32:12 --> Config Class Initialized
INFO - 2017-12-26 20:32:12 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:32:12 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:32:12 --> Utf8 Class Initialized
INFO - 2017-12-26 20:32:12 --> URI Class Initialized
INFO - 2017-12-26 20:32:12 --> Router Class Initialized
INFO - 2017-12-26 20:32:12 --> Output Class Initialized
INFO - 2017-12-26 20:32:12 --> Security Class Initialized
DEBUG - 2017-12-26 20:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:32:12 --> Input Class Initialized
INFO - 2017-12-26 20:32:12 --> Language Class Initialized
INFO - 2017-12-26 20:32:12 --> Loader Class Initialized
INFO - 2017-12-26 20:32:12 --> Helper loaded: url_helper
INFO - 2017-12-26 20:32:12 --> Helper loaded: form_helper
INFO - 2017-12-26 20:32:12 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:32:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:32:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:32:12 --> Form Validation Class Initialized
INFO - 2017-12-26 20:32:12 --> Model Class Initialized
INFO - 2017-12-26 20:32:12 --> Controller Class Initialized
INFO - 2017-12-26 20:32:12 --> Model Class Initialized
INFO - 2017-12-26 20:32:12 --> Model Class Initialized
INFO - 2017-12-26 20:32:12 --> Model Class Initialized
DEBUG - 2017-12-26 20:32:12 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2017-12-26 20:32:12 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 40
ERROR - 2017-12-26 20:32:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 40
ERROR - 2017-12-26 20:32:12 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 40
ERROR - 2017-12-26 20:32:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 40
ERROR - 2017-12-26 20:32:12 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 41
ERROR - 2017-12-26 20:32:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 41
ERROR - 2017-12-26 20:32:12 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 41
ERROR - 2017-12-26 20:32:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 41
ERROR - 2017-12-26 20:32:12 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 42
ERROR - 2017-12-26 20:32:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 42
ERROR - 2017-12-26 20:32:12 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 42
ERROR - 2017-12-26 20:32:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 42
ERROR - 2017-12-26 20:32:12 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 44
ERROR - 2017-12-26 20:32:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 44
INFO - 2017-12-26 20:32:12 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-26 20:32:12 --> Final output sent to browser
DEBUG - 2017-12-26 20:32:12 --> Total execution time: 0.1024
INFO - 2017-12-26 20:32:13 --> Config Class Initialized
INFO - 2017-12-26 20:32:13 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:32:13 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:32:13 --> Utf8 Class Initialized
INFO - 2017-12-26 20:32:13 --> URI Class Initialized
INFO - 2017-12-26 20:32:13 --> Router Class Initialized
INFO - 2017-12-26 20:32:13 --> Output Class Initialized
INFO - 2017-12-26 20:32:13 --> Security Class Initialized
DEBUG - 2017-12-26 20:32:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:32:13 --> Input Class Initialized
INFO - 2017-12-26 20:32:13 --> Language Class Initialized
INFO - 2017-12-26 20:32:13 --> Loader Class Initialized
INFO - 2017-12-26 20:32:13 --> Helper loaded: url_helper
INFO - 2017-12-26 20:32:13 --> Helper loaded: form_helper
INFO - 2017-12-26 20:32:13 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:32:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:32:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:32:13 --> Form Validation Class Initialized
INFO - 2017-12-26 20:32:13 --> Model Class Initialized
INFO - 2017-12-26 20:32:13 --> Controller Class Initialized
INFO - 2017-12-26 20:32:13 --> Model Class Initialized
INFO - 2017-12-26 20:32:13 --> Model Class Initialized
INFO - 2017-12-26 20:32:13 --> Model Class Initialized
DEBUG - 2017-12-26 20:32:13 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2017-12-26 20:32:13 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 40
ERROR - 2017-12-26 20:32:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 40
ERROR - 2017-12-26 20:32:13 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 40
ERROR - 2017-12-26 20:32:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 40
ERROR - 2017-12-26 20:32:13 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 41
ERROR - 2017-12-26 20:32:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 41
ERROR - 2017-12-26 20:32:13 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 41
ERROR - 2017-12-26 20:32:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 41
ERROR - 2017-12-26 20:32:13 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 42
ERROR - 2017-12-26 20:32:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 42
ERROR - 2017-12-26 20:32:13 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 42
ERROR - 2017-12-26 20:32:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 42
ERROR - 2017-12-26 20:32:13 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 44
ERROR - 2017-12-26 20:32:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 44
INFO - 2017-12-26 20:32:13 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-26 20:32:13 --> Final output sent to browser
DEBUG - 2017-12-26 20:32:13 --> Total execution time: 0.1069
INFO - 2017-12-26 20:32:13 --> Config Class Initialized
INFO - 2017-12-26 20:32:13 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:32:13 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:32:13 --> Utf8 Class Initialized
INFO - 2017-12-26 20:32:13 --> URI Class Initialized
INFO - 2017-12-26 20:32:13 --> Router Class Initialized
INFO - 2017-12-26 20:32:13 --> Output Class Initialized
INFO - 2017-12-26 20:32:13 --> Security Class Initialized
DEBUG - 2017-12-26 20:32:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:32:13 --> Input Class Initialized
INFO - 2017-12-26 20:32:13 --> Language Class Initialized
INFO - 2017-12-26 20:32:13 --> Loader Class Initialized
INFO - 2017-12-26 20:32:13 --> Helper loaded: url_helper
INFO - 2017-12-26 20:32:13 --> Helper loaded: form_helper
INFO - 2017-12-26 20:32:13 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:32:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:32:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:32:13 --> Form Validation Class Initialized
INFO - 2017-12-26 20:32:13 --> Model Class Initialized
INFO - 2017-12-26 20:32:13 --> Controller Class Initialized
INFO - 2017-12-26 20:32:13 --> Model Class Initialized
INFO - 2017-12-26 20:32:13 --> Model Class Initialized
INFO - 2017-12-26 20:32:13 --> Model Class Initialized
DEBUG - 2017-12-26 20:32:13 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2017-12-26 20:32:13 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 40
ERROR - 2017-12-26 20:32:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 40
ERROR - 2017-12-26 20:32:13 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 40
ERROR - 2017-12-26 20:32:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 40
ERROR - 2017-12-26 20:32:13 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 41
ERROR - 2017-12-26 20:32:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 41
ERROR - 2017-12-26 20:32:13 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 41
ERROR - 2017-12-26 20:32:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 41
ERROR - 2017-12-26 20:32:13 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 42
ERROR - 2017-12-26 20:32:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 42
ERROR - 2017-12-26 20:32:13 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 42
ERROR - 2017-12-26 20:32:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 42
ERROR - 2017-12-26 20:32:13 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 44
ERROR - 2017-12-26 20:32:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 44
INFO - 2017-12-26 20:32:13 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-26 20:32:13 --> Final output sent to browser
DEBUG - 2017-12-26 20:32:13 --> Total execution time: 0.1138
INFO - 2017-12-26 20:32:13 --> Config Class Initialized
INFO - 2017-12-26 20:32:13 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:32:13 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:32:13 --> Utf8 Class Initialized
INFO - 2017-12-26 20:32:13 --> URI Class Initialized
INFO - 2017-12-26 20:32:13 --> Router Class Initialized
INFO - 2017-12-26 20:32:13 --> Output Class Initialized
INFO - 2017-12-26 20:32:13 --> Security Class Initialized
DEBUG - 2017-12-26 20:32:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:32:13 --> Input Class Initialized
INFO - 2017-12-26 20:32:13 --> Language Class Initialized
INFO - 2017-12-26 20:32:13 --> Loader Class Initialized
INFO - 2017-12-26 20:32:13 --> Helper loaded: url_helper
INFO - 2017-12-26 20:32:13 --> Helper loaded: form_helper
INFO - 2017-12-26 20:32:13 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:32:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:32:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:32:13 --> Form Validation Class Initialized
INFO - 2017-12-26 20:32:13 --> Model Class Initialized
INFO - 2017-12-26 20:32:13 --> Controller Class Initialized
INFO - 2017-12-26 20:32:13 --> Model Class Initialized
INFO - 2017-12-26 20:32:13 --> Model Class Initialized
INFO - 2017-12-26 20:32:13 --> Model Class Initialized
DEBUG - 2017-12-26 20:32:13 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2017-12-26 20:32:13 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 40
ERROR - 2017-12-26 20:32:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 40
ERROR - 2017-12-26 20:32:13 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 40
ERROR - 2017-12-26 20:32:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 40
ERROR - 2017-12-26 20:32:13 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 41
ERROR - 2017-12-26 20:32:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 41
ERROR - 2017-12-26 20:32:13 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 41
ERROR - 2017-12-26 20:32:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 41
ERROR - 2017-12-26 20:32:13 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 42
ERROR - 2017-12-26 20:32:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 42
ERROR - 2017-12-26 20:32:13 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 42
ERROR - 2017-12-26 20:32:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 42
ERROR - 2017-12-26 20:32:13 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 44
ERROR - 2017-12-26 20:32:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 44
INFO - 2017-12-26 20:32:13 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-26 20:32:13 --> Final output sent to browser
DEBUG - 2017-12-26 20:32:13 --> Total execution time: 0.0834
INFO - 2017-12-26 20:32:13 --> Config Class Initialized
INFO - 2017-12-26 20:32:13 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:32:13 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:32:13 --> Utf8 Class Initialized
INFO - 2017-12-26 20:32:13 --> URI Class Initialized
INFO - 2017-12-26 20:32:13 --> Router Class Initialized
INFO - 2017-12-26 20:32:13 --> Output Class Initialized
INFO - 2017-12-26 20:32:13 --> Security Class Initialized
DEBUG - 2017-12-26 20:32:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:32:13 --> Input Class Initialized
INFO - 2017-12-26 20:32:13 --> Language Class Initialized
INFO - 2017-12-26 20:32:13 --> Loader Class Initialized
INFO - 2017-12-26 20:32:13 --> Helper loaded: url_helper
INFO - 2017-12-26 20:32:13 --> Helper loaded: form_helper
INFO - 2017-12-26 20:32:13 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:32:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:32:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:32:13 --> Form Validation Class Initialized
INFO - 2017-12-26 20:32:13 --> Model Class Initialized
INFO - 2017-12-26 20:32:13 --> Controller Class Initialized
INFO - 2017-12-26 20:32:13 --> Model Class Initialized
INFO - 2017-12-26 20:32:13 --> Model Class Initialized
INFO - 2017-12-26 20:32:13 --> Model Class Initialized
DEBUG - 2017-12-26 20:32:13 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2017-12-26 20:32:13 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 40
ERROR - 2017-12-26 20:32:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 40
ERROR - 2017-12-26 20:32:13 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 40
ERROR - 2017-12-26 20:32:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 40
ERROR - 2017-12-26 20:32:13 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 41
ERROR - 2017-12-26 20:32:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 41
ERROR - 2017-12-26 20:32:13 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 41
ERROR - 2017-12-26 20:32:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 41
ERROR - 2017-12-26 20:32:13 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 42
ERROR - 2017-12-26 20:32:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 42
ERROR - 2017-12-26 20:32:13 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 42
ERROR - 2017-12-26 20:32:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 42
ERROR - 2017-12-26 20:32:13 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 44
ERROR - 2017-12-26 20:32:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 44
INFO - 2017-12-26 20:32:13 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-26 20:32:13 --> Final output sent to browser
DEBUG - 2017-12-26 20:32:13 --> Total execution time: 0.1015
INFO - 2017-12-26 20:32:14 --> Config Class Initialized
INFO - 2017-12-26 20:32:14 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:32:14 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:32:14 --> Utf8 Class Initialized
INFO - 2017-12-26 20:32:14 --> URI Class Initialized
INFO - 2017-12-26 20:32:14 --> Router Class Initialized
INFO - 2017-12-26 20:32:14 --> Output Class Initialized
INFO - 2017-12-26 20:32:14 --> Security Class Initialized
DEBUG - 2017-12-26 20:32:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:32:14 --> Input Class Initialized
INFO - 2017-12-26 20:32:14 --> Language Class Initialized
INFO - 2017-12-26 20:32:14 --> Loader Class Initialized
INFO - 2017-12-26 20:32:14 --> Helper loaded: url_helper
INFO - 2017-12-26 20:32:14 --> Helper loaded: form_helper
INFO - 2017-12-26 20:32:14 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:32:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:32:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:32:14 --> Form Validation Class Initialized
INFO - 2017-12-26 20:32:14 --> Model Class Initialized
INFO - 2017-12-26 20:32:14 --> Controller Class Initialized
INFO - 2017-12-26 20:32:14 --> Model Class Initialized
INFO - 2017-12-26 20:32:14 --> Model Class Initialized
INFO - 2017-12-26 20:32:14 --> Model Class Initialized
DEBUG - 2017-12-26 20:32:14 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2017-12-26 20:32:14 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 40
ERROR - 2017-12-26 20:32:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 40
ERROR - 2017-12-26 20:32:14 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 40
ERROR - 2017-12-26 20:32:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 40
ERROR - 2017-12-26 20:32:14 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 41
ERROR - 2017-12-26 20:32:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 41
ERROR - 2017-12-26 20:32:14 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 41
ERROR - 2017-12-26 20:32:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 41
ERROR - 2017-12-26 20:32:14 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 42
ERROR - 2017-12-26 20:32:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 42
ERROR - 2017-12-26 20:32:14 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 42
ERROR - 2017-12-26 20:32:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 42
ERROR - 2017-12-26 20:32:14 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 44
ERROR - 2017-12-26 20:32:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 44
INFO - 2017-12-26 20:32:14 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-26 20:32:14 --> Final output sent to browser
DEBUG - 2017-12-26 20:32:14 --> Total execution time: 0.1161
INFO - 2017-12-26 20:32:14 --> Config Class Initialized
INFO - 2017-12-26 20:32:14 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:32:14 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:32:14 --> Utf8 Class Initialized
INFO - 2017-12-26 20:32:14 --> URI Class Initialized
INFO - 2017-12-26 20:32:14 --> Router Class Initialized
INFO - 2017-12-26 20:32:14 --> Output Class Initialized
INFO - 2017-12-26 20:32:14 --> Security Class Initialized
DEBUG - 2017-12-26 20:32:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:32:14 --> Input Class Initialized
INFO - 2017-12-26 20:32:14 --> Language Class Initialized
INFO - 2017-12-26 20:32:14 --> Loader Class Initialized
INFO - 2017-12-26 20:32:14 --> Helper loaded: url_helper
INFO - 2017-12-26 20:32:14 --> Helper loaded: form_helper
INFO - 2017-12-26 20:32:14 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:32:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:32:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:32:14 --> Form Validation Class Initialized
INFO - 2017-12-26 20:32:14 --> Model Class Initialized
INFO - 2017-12-26 20:32:14 --> Controller Class Initialized
INFO - 2017-12-26 20:32:14 --> Model Class Initialized
INFO - 2017-12-26 20:32:14 --> Model Class Initialized
INFO - 2017-12-26 20:32:14 --> Model Class Initialized
DEBUG - 2017-12-26 20:32:14 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2017-12-26 20:32:14 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 40
ERROR - 2017-12-26 20:32:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 40
ERROR - 2017-12-26 20:32:14 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 40
ERROR - 2017-12-26 20:32:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 40
ERROR - 2017-12-26 20:32:14 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 41
ERROR - 2017-12-26 20:32:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 41
ERROR - 2017-12-26 20:32:14 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 41
ERROR - 2017-12-26 20:32:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 41
ERROR - 2017-12-26 20:32:14 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 42
ERROR - 2017-12-26 20:32:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 42
ERROR - 2017-12-26 20:32:14 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 42
ERROR - 2017-12-26 20:32:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 42
ERROR - 2017-12-26 20:32:14 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 44
ERROR - 2017-12-26 20:32:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 44
INFO - 2017-12-26 20:32:14 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-26 20:32:14 --> Final output sent to browser
DEBUG - 2017-12-26 20:32:14 --> Total execution time: 0.1262
INFO - 2017-12-26 20:32:14 --> Config Class Initialized
INFO - 2017-12-26 20:32:14 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:32:14 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:32:14 --> Utf8 Class Initialized
INFO - 2017-12-26 20:32:14 --> URI Class Initialized
INFO - 2017-12-26 20:32:14 --> Router Class Initialized
INFO - 2017-12-26 20:32:14 --> Output Class Initialized
INFO - 2017-12-26 20:32:14 --> Security Class Initialized
DEBUG - 2017-12-26 20:32:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:32:14 --> Input Class Initialized
INFO - 2017-12-26 20:32:14 --> Language Class Initialized
INFO - 2017-12-26 20:32:14 --> Loader Class Initialized
INFO - 2017-12-26 20:32:14 --> Helper loaded: url_helper
INFO - 2017-12-26 20:32:14 --> Helper loaded: form_helper
INFO - 2017-12-26 20:32:14 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:32:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:32:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:32:14 --> Form Validation Class Initialized
INFO - 2017-12-26 20:32:14 --> Model Class Initialized
INFO - 2017-12-26 20:32:14 --> Controller Class Initialized
INFO - 2017-12-26 20:32:14 --> Model Class Initialized
INFO - 2017-12-26 20:32:14 --> Model Class Initialized
INFO - 2017-12-26 20:32:14 --> Model Class Initialized
DEBUG - 2017-12-26 20:32:14 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2017-12-26 20:32:14 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 40
ERROR - 2017-12-26 20:32:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 40
ERROR - 2017-12-26 20:32:14 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 40
ERROR - 2017-12-26 20:32:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 40
ERROR - 2017-12-26 20:32:14 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 41
ERROR - 2017-12-26 20:32:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 41
ERROR - 2017-12-26 20:32:14 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 41
ERROR - 2017-12-26 20:32:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 41
ERROR - 2017-12-26 20:32:14 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 42
ERROR - 2017-12-26 20:32:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 42
ERROR - 2017-12-26 20:32:14 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 42
ERROR - 2017-12-26 20:32:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 42
ERROR - 2017-12-26 20:32:14 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 44
ERROR - 2017-12-26 20:32:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 44
INFO - 2017-12-26 20:32:14 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-26 20:32:14 --> Final output sent to browser
DEBUG - 2017-12-26 20:32:14 --> Total execution time: 0.1418
INFO - 2017-12-26 20:32:14 --> Config Class Initialized
INFO - 2017-12-26 20:32:14 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:32:14 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:32:14 --> Utf8 Class Initialized
INFO - 2017-12-26 20:32:14 --> URI Class Initialized
INFO - 2017-12-26 20:32:14 --> Router Class Initialized
INFO - 2017-12-26 20:32:14 --> Output Class Initialized
INFO - 2017-12-26 20:32:14 --> Security Class Initialized
DEBUG - 2017-12-26 20:32:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:32:14 --> Input Class Initialized
INFO - 2017-12-26 20:32:14 --> Language Class Initialized
INFO - 2017-12-26 20:32:14 --> Loader Class Initialized
INFO - 2017-12-26 20:32:14 --> Helper loaded: url_helper
INFO - 2017-12-26 20:32:14 --> Helper loaded: form_helper
INFO - 2017-12-26 20:32:14 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:32:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:32:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:32:14 --> Form Validation Class Initialized
INFO - 2017-12-26 20:32:14 --> Model Class Initialized
INFO - 2017-12-26 20:32:14 --> Controller Class Initialized
INFO - 2017-12-26 20:32:14 --> Model Class Initialized
INFO - 2017-12-26 20:32:14 --> Model Class Initialized
INFO - 2017-12-26 20:32:14 --> Model Class Initialized
DEBUG - 2017-12-26 20:32:14 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2017-12-26 20:32:14 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 40
ERROR - 2017-12-26 20:32:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 40
ERROR - 2017-12-26 20:32:14 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 40
ERROR - 2017-12-26 20:32:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 40
ERROR - 2017-12-26 20:32:14 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 41
ERROR - 2017-12-26 20:32:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 41
ERROR - 2017-12-26 20:32:14 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 41
ERROR - 2017-12-26 20:32:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 41
ERROR - 2017-12-26 20:32:14 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 42
ERROR - 2017-12-26 20:32:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 42
ERROR - 2017-12-26 20:32:14 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 42
ERROR - 2017-12-26 20:32:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 42
ERROR - 2017-12-26 20:32:14 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 44
ERROR - 2017-12-26 20:32:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 44
INFO - 2017-12-26 20:32:14 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-26 20:32:14 --> Final output sent to browser
DEBUG - 2017-12-26 20:32:14 --> Total execution time: 0.0906
INFO - 2017-12-26 20:32:20 --> Config Class Initialized
INFO - 2017-12-26 20:32:20 --> Config Class Initialized
INFO - 2017-12-26 20:32:20 --> Hooks Class Initialized
INFO - 2017-12-26 20:32:20 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:32:20 --> UTF-8 Support Enabled
DEBUG - 2017-12-26 20:32:20 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:32:20 --> Utf8 Class Initialized
INFO - 2017-12-26 20:32:20 --> Utf8 Class Initialized
INFO - 2017-12-26 20:32:20 --> URI Class Initialized
INFO - 2017-12-26 20:32:20 --> URI Class Initialized
INFO - 2017-12-26 20:32:20 --> Router Class Initialized
INFO - 2017-12-26 20:32:20 --> Router Class Initialized
INFO - 2017-12-26 20:32:20 --> Output Class Initialized
INFO - 2017-12-26 20:32:20 --> Output Class Initialized
INFO - 2017-12-26 20:32:20 --> Security Class Initialized
INFO - 2017-12-26 20:32:20 --> Security Class Initialized
DEBUG - 2017-12-26 20:32:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-26 20:32:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:32:20 --> Input Class Initialized
INFO - 2017-12-26 20:32:20 --> Input Class Initialized
INFO - 2017-12-26 20:32:20 --> Language Class Initialized
INFO - 2017-12-26 20:32:20 --> Language Class Initialized
ERROR - 2017-12-26 20:32:20 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-26 20:32:20 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-26 20:32:24 --> Config Class Initialized
INFO - 2017-12-26 20:32:24 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:32:24 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:32:24 --> Utf8 Class Initialized
INFO - 2017-12-26 20:32:24 --> URI Class Initialized
INFO - 2017-12-26 20:32:24 --> Router Class Initialized
INFO - 2017-12-26 20:32:24 --> Output Class Initialized
INFO - 2017-12-26 20:32:24 --> Security Class Initialized
DEBUG - 2017-12-26 20:32:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:32:24 --> Input Class Initialized
INFO - 2017-12-26 20:32:24 --> Language Class Initialized
INFO - 2017-12-26 20:32:24 --> Loader Class Initialized
INFO - 2017-12-26 20:32:24 --> Helper loaded: url_helper
INFO - 2017-12-26 20:32:24 --> Helper loaded: form_helper
INFO - 2017-12-26 20:32:24 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:32:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:32:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:32:24 --> Form Validation Class Initialized
INFO - 2017-12-26 20:32:24 --> Model Class Initialized
INFO - 2017-12-26 20:32:24 --> Controller Class Initialized
INFO - 2017-12-26 20:32:24 --> Model Class Initialized
INFO - 2017-12-26 20:32:24 --> Model Class Initialized
INFO - 2017-12-26 20:32:24 --> Model Class Initialized
DEBUG - 2017-12-26 20:32:24 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2017-12-26 20:32:24 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 40
ERROR - 2017-12-26 20:32:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 40
ERROR - 2017-12-26 20:32:24 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 40
ERROR - 2017-12-26 20:32:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 40
ERROR - 2017-12-26 20:32:24 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 41
ERROR - 2017-12-26 20:32:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 41
ERROR - 2017-12-26 20:32:24 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 41
ERROR - 2017-12-26 20:32:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 41
ERROR - 2017-12-26 20:32:24 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 42
ERROR - 2017-12-26 20:32:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 42
ERROR - 2017-12-26 20:32:24 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 42
ERROR - 2017-12-26 20:32:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 42
ERROR - 2017-12-26 20:32:24 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 44
ERROR - 2017-12-26 20:32:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 44
INFO - 2017-12-26 20:32:24 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-26 20:32:24 --> Final output sent to browser
DEBUG - 2017-12-26 20:32:24 --> Total execution time: 0.1061
INFO - 2017-12-26 20:32:26 --> Config Class Initialized
INFO - 2017-12-26 20:32:26 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:32:26 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:32:26 --> Utf8 Class Initialized
INFO - 2017-12-26 20:32:26 --> URI Class Initialized
INFO - 2017-12-26 20:32:26 --> Router Class Initialized
INFO - 2017-12-26 20:32:26 --> Output Class Initialized
INFO - 2017-12-26 20:32:26 --> Security Class Initialized
DEBUG - 2017-12-26 20:32:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:32:26 --> Input Class Initialized
INFO - 2017-12-26 20:32:26 --> Language Class Initialized
ERROR - 2017-12-26 20:32:26 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-26 20:32:27 --> Config Class Initialized
INFO - 2017-12-26 20:32:27 --> Config Class Initialized
INFO - 2017-12-26 20:32:27 --> Hooks Class Initialized
INFO - 2017-12-26 20:32:27 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:32:27 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:32:27 --> Utf8 Class Initialized
DEBUG - 2017-12-26 20:32:27 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:32:27 --> Utf8 Class Initialized
INFO - 2017-12-26 20:32:27 --> URI Class Initialized
INFO - 2017-12-26 20:32:27 --> URI Class Initialized
INFO - 2017-12-26 20:32:27 --> Router Class Initialized
INFO - 2017-12-26 20:32:27 --> Router Class Initialized
INFO - 2017-12-26 20:32:27 --> Output Class Initialized
INFO - 2017-12-26 20:32:27 --> Output Class Initialized
INFO - 2017-12-26 20:32:27 --> Security Class Initialized
INFO - 2017-12-26 20:32:27 --> Security Class Initialized
DEBUG - 2017-12-26 20:32:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:32:27 --> Input Class Initialized
DEBUG - 2017-12-26 20:32:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:32:27 --> Input Class Initialized
INFO - 2017-12-26 20:32:27 --> Language Class Initialized
INFO - 2017-12-26 20:32:27 --> Language Class Initialized
ERROR - 2017-12-26 20:32:27 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-26 20:32:27 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-26 20:32:27 --> Config Class Initialized
INFO - 2017-12-26 20:32:27 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:32:27 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:32:27 --> Utf8 Class Initialized
INFO - 2017-12-26 20:32:27 --> URI Class Initialized
INFO - 2017-12-26 20:32:27 --> Router Class Initialized
INFO - 2017-12-26 20:32:27 --> Output Class Initialized
INFO - 2017-12-26 20:32:27 --> Security Class Initialized
DEBUG - 2017-12-26 20:32:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:32:27 --> Input Class Initialized
INFO - 2017-12-26 20:32:27 --> Language Class Initialized
INFO - 2017-12-26 20:32:27 --> Loader Class Initialized
INFO - 2017-12-26 20:32:27 --> Helper loaded: url_helper
INFO - 2017-12-26 20:32:27 --> Helper loaded: form_helper
INFO - 2017-12-26 20:32:27 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:32:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:32:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:32:27 --> Form Validation Class Initialized
INFO - 2017-12-26 20:32:27 --> Model Class Initialized
INFO - 2017-12-26 20:32:27 --> Controller Class Initialized
INFO - 2017-12-26 20:32:27 --> Model Class Initialized
INFO - 2017-12-26 20:32:27 --> Model Class Initialized
INFO - 2017-12-26 20:32:27 --> Model Class Initialized
DEBUG - 2017-12-26 20:32:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:32:49 --> Config Class Initialized
INFO - 2017-12-26 20:32:49 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:32:49 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:32:49 --> Utf8 Class Initialized
INFO - 2017-12-26 20:32:49 --> URI Class Initialized
INFO - 2017-12-26 20:32:49 --> Router Class Initialized
INFO - 2017-12-26 20:32:49 --> Output Class Initialized
INFO - 2017-12-26 20:32:49 --> Security Class Initialized
DEBUG - 2017-12-26 20:32:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:32:49 --> Input Class Initialized
INFO - 2017-12-26 20:32:49 --> Language Class Initialized
INFO - 2017-12-26 20:32:49 --> Loader Class Initialized
INFO - 2017-12-26 20:32:49 --> Helper loaded: url_helper
INFO - 2017-12-26 20:32:49 --> Helper loaded: form_helper
INFO - 2017-12-26 20:32:49 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:32:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:32:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:32:49 --> Form Validation Class Initialized
INFO - 2017-12-26 20:32:49 --> Model Class Initialized
INFO - 2017-12-26 20:32:49 --> Controller Class Initialized
INFO - 2017-12-26 20:32:49 --> Model Class Initialized
INFO - 2017-12-26 20:32:49 --> Model Class Initialized
INFO - 2017-12-26 20:32:49 --> Model Class Initialized
DEBUG - 2017-12-26 20:32:49 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2017-12-26 20:32:49 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 40
ERROR - 2017-12-26 20:32:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 40
ERROR - 2017-12-26 20:32:49 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 40
ERROR - 2017-12-26 20:32:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 40
ERROR - 2017-12-26 20:32:49 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 41
ERROR - 2017-12-26 20:32:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 41
ERROR - 2017-12-26 20:32:49 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 41
ERROR - 2017-12-26 20:32:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 41
ERROR - 2017-12-26 20:32:49 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 42
ERROR - 2017-12-26 20:32:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 42
ERROR - 2017-12-26 20:32:49 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 42
ERROR - 2017-12-26 20:32:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 42
ERROR - 2017-12-26 20:32:49 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 44
ERROR - 2017-12-26 20:32:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 44
INFO - 2017-12-26 20:32:49 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-26 20:32:49 --> Final output sent to browser
DEBUG - 2017-12-26 20:32:49 --> Total execution time: 0.1143
INFO - 2017-12-26 20:32:51 --> Config Class Initialized
INFO - 2017-12-26 20:32:51 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:32:51 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:32:51 --> Utf8 Class Initialized
INFO - 2017-12-26 20:32:51 --> URI Class Initialized
INFO - 2017-12-26 20:32:51 --> Router Class Initialized
INFO - 2017-12-26 20:32:51 --> Output Class Initialized
INFO - 2017-12-26 20:32:51 --> Security Class Initialized
DEBUG - 2017-12-26 20:32:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:32:51 --> Input Class Initialized
INFO - 2017-12-26 20:32:51 --> Language Class Initialized
ERROR - 2017-12-26 20:32:51 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-26 20:32:51 --> Config Class Initialized
INFO - 2017-12-26 20:32:51 --> Hooks Class Initialized
INFO - 2017-12-26 20:32:51 --> Config Class Initialized
INFO - 2017-12-26 20:32:51 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:32:51 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:32:51 --> Utf8 Class Initialized
DEBUG - 2017-12-26 20:32:51 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:32:51 --> Utf8 Class Initialized
INFO - 2017-12-26 20:32:51 --> URI Class Initialized
INFO - 2017-12-26 20:32:51 --> URI Class Initialized
INFO - 2017-12-26 20:32:51 --> Router Class Initialized
INFO - 2017-12-26 20:32:51 --> Router Class Initialized
INFO - 2017-12-26 20:32:51 --> Output Class Initialized
INFO - 2017-12-26 20:32:51 --> Output Class Initialized
INFO - 2017-12-26 20:32:51 --> Security Class Initialized
INFO - 2017-12-26 20:32:51 --> Security Class Initialized
DEBUG - 2017-12-26 20:32:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:32:51 --> Input Class Initialized
DEBUG - 2017-12-26 20:32:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:32:51 --> Input Class Initialized
INFO - 2017-12-26 20:32:51 --> Language Class Initialized
INFO - 2017-12-26 20:32:51 --> Language Class Initialized
ERROR - 2017-12-26 20:32:51 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-26 20:32:51 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-26 20:32:51 --> Config Class Initialized
INFO - 2017-12-26 20:32:51 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:32:51 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:32:51 --> Utf8 Class Initialized
INFO - 2017-12-26 20:32:51 --> URI Class Initialized
INFO - 2017-12-26 20:32:51 --> Router Class Initialized
INFO - 2017-12-26 20:32:51 --> Output Class Initialized
INFO - 2017-12-26 20:32:51 --> Security Class Initialized
DEBUG - 2017-12-26 20:32:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:32:51 --> Input Class Initialized
INFO - 2017-12-26 20:32:51 --> Language Class Initialized
INFO - 2017-12-26 20:32:51 --> Loader Class Initialized
INFO - 2017-12-26 20:32:51 --> Helper loaded: url_helper
INFO - 2017-12-26 20:32:51 --> Helper loaded: form_helper
INFO - 2017-12-26 20:32:51 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:32:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:32:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:32:51 --> Form Validation Class Initialized
INFO - 2017-12-26 20:32:51 --> Model Class Initialized
INFO - 2017-12-26 20:32:51 --> Controller Class Initialized
INFO - 2017-12-26 20:32:51 --> Model Class Initialized
INFO - 2017-12-26 20:32:51 --> Model Class Initialized
INFO - 2017-12-26 20:32:51 --> Model Class Initialized
DEBUG - 2017-12-26 20:32:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:33:58 --> Config Class Initialized
INFO - 2017-12-26 20:33:58 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:33:58 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:33:58 --> Utf8 Class Initialized
INFO - 2017-12-26 20:33:58 --> URI Class Initialized
INFO - 2017-12-26 20:33:58 --> Router Class Initialized
INFO - 2017-12-26 20:33:58 --> Output Class Initialized
INFO - 2017-12-26 20:33:58 --> Security Class Initialized
DEBUG - 2017-12-26 20:33:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:33:58 --> Input Class Initialized
INFO - 2017-12-26 20:33:58 --> Language Class Initialized
INFO - 2017-12-26 20:33:58 --> Loader Class Initialized
INFO - 2017-12-26 20:33:58 --> Helper loaded: url_helper
INFO - 2017-12-26 20:33:58 --> Helper loaded: form_helper
INFO - 2017-12-26 20:33:58 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:33:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:33:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:33:58 --> Form Validation Class Initialized
INFO - 2017-12-26 20:33:58 --> Model Class Initialized
INFO - 2017-12-26 20:33:58 --> Controller Class Initialized
INFO - 2017-12-26 20:33:58 --> Model Class Initialized
INFO - 2017-12-26 20:33:58 --> Model Class Initialized
INFO - 2017-12-26 20:33:58 --> Model Class Initialized
DEBUG - 2017-12-26 20:33:58 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2017-12-26 20:33:58 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 40
ERROR - 2017-12-26 20:33:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 40
ERROR - 2017-12-26 20:33:58 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 40
ERROR - 2017-12-26 20:33:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 40
ERROR - 2017-12-26 20:33:58 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 41
ERROR - 2017-12-26 20:33:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 41
ERROR - 2017-12-26 20:33:58 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 41
ERROR - 2017-12-26 20:33:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 41
ERROR - 2017-12-26 20:33:58 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 42
ERROR - 2017-12-26 20:33:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 42
ERROR - 2017-12-26 20:33:58 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 42
ERROR - 2017-12-26 20:33:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 42
ERROR - 2017-12-26 20:33:58 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 44
ERROR - 2017-12-26 20:33:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 44
INFO - 2017-12-26 20:33:58 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-26 20:33:58 --> Final output sent to browser
DEBUG - 2017-12-26 20:33:58 --> Total execution time: 0.0691
INFO - 2017-12-26 20:33:58 --> Config Class Initialized
INFO - 2017-12-26 20:33:58 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:33:58 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:33:58 --> Utf8 Class Initialized
INFO - 2017-12-26 20:33:58 --> URI Class Initialized
INFO - 2017-12-26 20:33:58 --> Router Class Initialized
INFO - 2017-12-26 20:33:58 --> Output Class Initialized
INFO - 2017-12-26 20:33:58 --> Security Class Initialized
DEBUG - 2017-12-26 20:33:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:33:58 --> Input Class Initialized
INFO - 2017-12-26 20:33:58 --> Language Class Initialized
ERROR - 2017-12-26 20:33:58 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-26 20:33:58 --> Config Class Initialized
INFO - 2017-12-26 20:33:58 --> Hooks Class Initialized
INFO - 2017-12-26 20:33:58 --> Config Class Initialized
INFO - 2017-12-26 20:33:58 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:33:58 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:33:58 --> Utf8 Class Initialized
DEBUG - 2017-12-26 20:33:58 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:33:58 --> URI Class Initialized
INFO - 2017-12-26 20:33:58 --> Utf8 Class Initialized
INFO - 2017-12-26 20:33:58 --> URI Class Initialized
INFO - 2017-12-26 20:33:58 --> Router Class Initialized
INFO - 2017-12-26 20:33:58 --> Router Class Initialized
INFO - 2017-12-26 20:33:58 --> Output Class Initialized
INFO - 2017-12-26 20:33:58 --> Output Class Initialized
INFO - 2017-12-26 20:33:58 --> Security Class Initialized
INFO - 2017-12-26 20:33:58 --> Security Class Initialized
DEBUG - 2017-12-26 20:33:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:33:58 --> Input Class Initialized
INFO - 2017-12-26 20:33:58 --> Language Class Initialized
DEBUG - 2017-12-26 20:33:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:33:58 --> Input Class Initialized
INFO - 2017-12-26 20:33:58 --> Language Class Initialized
ERROR - 2017-12-26 20:33:58 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-26 20:33:58 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-26 20:33:58 --> Config Class Initialized
INFO - 2017-12-26 20:33:58 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:33:58 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:33:58 --> Utf8 Class Initialized
INFO - 2017-12-26 20:33:58 --> URI Class Initialized
INFO - 2017-12-26 20:33:58 --> Router Class Initialized
INFO - 2017-12-26 20:33:58 --> Output Class Initialized
INFO - 2017-12-26 20:33:58 --> Security Class Initialized
DEBUG - 2017-12-26 20:33:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:33:58 --> Input Class Initialized
INFO - 2017-12-26 20:33:58 --> Language Class Initialized
INFO - 2017-12-26 20:33:58 --> Loader Class Initialized
INFO - 2017-12-26 20:33:58 --> Helper loaded: url_helper
INFO - 2017-12-26 20:33:58 --> Helper loaded: form_helper
INFO - 2017-12-26 20:33:58 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:33:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:33:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:33:58 --> Form Validation Class Initialized
INFO - 2017-12-26 20:33:58 --> Model Class Initialized
INFO - 2017-12-26 20:33:58 --> Controller Class Initialized
INFO - 2017-12-26 20:33:58 --> Model Class Initialized
INFO - 2017-12-26 20:33:58 --> Model Class Initialized
INFO - 2017-12-26 20:33:58 --> Model Class Initialized
DEBUG - 2017-12-26 20:33:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:34:00 --> Config Class Initialized
INFO - 2017-12-26 20:34:00 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:34:00 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:34:00 --> Utf8 Class Initialized
INFO - 2017-12-26 20:34:00 --> URI Class Initialized
INFO - 2017-12-26 20:34:00 --> Router Class Initialized
INFO - 2017-12-26 20:34:00 --> Output Class Initialized
INFO - 2017-12-26 20:34:00 --> Security Class Initialized
DEBUG - 2017-12-26 20:34:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:34:00 --> Input Class Initialized
INFO - 2017-12-26 20:34:00 --> Language Class Initialized
INFO - 2017-12-26 20:34:00 --> Loader Class Initialized
INFO - 2017-12-26 20:34:00 --> Helper loaded: url_helper
INFO - 2017-12-26 20:34:00 --> Helper loaded: form_helper
INFO - 2017-12-26 20:34:00 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:34:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:34:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:34:00 --> Form Validation Class Initialized
INFO - 2017-12-26 20:34:00 --> Model Class Initialized
INFO - 2017-12-26 20:34:00 --> Controller Class Initialized
INFO - 2017-12-26 20:34:00 --> Model Class Initialized
INFO - 2017-12-26 20:34:00 --> Model Class Initialized
INFO - 2017-12-26 20:34:00 --> Model Class Initialized
DEBUG - 2017-12-26 20:34:00 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2017-12-26 20:34:00 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 40
ERROR - 2017-12-26 20:34:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 40
ERROR - 2017-12-26 20:34:00 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 40
ERROR - 2017-12-26 20:34:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 40
ERROR - 2017-12-26 20:34:00 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 41
ERROR - 2017-12-26 20:34:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 41
ERROR - 2017-12-26 20:34:00 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 41
ERROR - 2017-12-26 20:34:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 41
ERROR - 2017-12-26 20:34:00 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 42
ERROR - 2017-12-26 20:34:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 42
ERROR - 2017-12-26 20:34:00 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 42
ERROR - 2017-12-26 20:34:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 42
ERROR - 2017-12-26 20:34:00 --> Severity: Notice --> Undefined variable: vextension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 44
ERROR - 2017-12-26 20:34:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 44
INFO - 2017-12-26 20:34:00 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-26 20:34:00 --> Final output sent to browser
DEBUG - 2017-12-26 20:34:00 --> Total execution time: 0.0886
INFO - 2017-12-26 20:34:00 --> Config Class Initialized
INFO - 2017-12-26 20:34:00 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:34:00 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:34:00 --> Utf8 Class Initialized
INFO - 2017-12-26 20:34:00 --> URI Class Initialized
INFO - 2017-12-26 20:34:00 --> Router Class Initialized
INFO - 2017-12-26 20:34:00 --> Output Class Initialized
INFO - 2017-12-26 20:34:00 --> Security Class Initialized
DEBUG - 2017-12-26 20:34:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:34:00 --> Input Class Initialized
INFO - 2017-12-26 20:34:00 --> Language Class Initialized
ERROR - 2017-12-26 20:34:00 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-26 20:34:00 --> Config Class Initialized
INFO - 2017-12-26 20:34:00 --> Config Class Initialized
INFO - 2017-12-26 20:34:00 --> Hooks Class Initialized
INFO - 2017-12-26 20:34:00 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:34:00 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:34:00 --> Utf8 Class Initialized
INFO - 2017-12-26 20:34:00 --> URI Class Initialized
DEBUG - 2017-12-26 20:34:00 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:34:00 --> Utf8 Class Initialized
INFO - 2017-12-26 20:34:00 --> Router Class Initialized
INFO - 2017-12-26 20:34:00 --> URI Class Initialized
INFO - 2017-12-26 20:34:00 --> Output Class Initialized
INFO - 2017-12-26 20:34:00 --> Router Class Initialized
INFO - 2017-12-26 20:34:00 --> Security Class Initialized
INFO - 2017-12-26 20:34:00 --> Output Class Initialized
DEBUG - 2017-12-26 20:34:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:34:00 --> Input Class Initialized
INFO - 2017-12-26 20:34:00 --> Language Class Initialized
INFO - 2017-12-26 20:34:00 --> Security Class Initialized
ERROR - 2017-12-26 20:34:00 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2017-12-26 20:34:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:34:00 --> Input Class Initialized
INFO - 2017-12-26 20:34:00 --> Language Class Initialized
ERROR - 2017-12-26 20:34:00 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-26 20:34:00 --> Config Class Initialized
INFO - 2017-12-26 20:34:00 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:34:00 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:34:00 --> Utf8 Class Initialized
INFO - 2017-12-26 20:34:00 --> URI Class Initialized
INFO - 2017-12-26 20:34:00 --> Router Class Initialized
INFO - 2017-12-26 20:34:00 --> Output Class Initialized
INFO - 2017-12-26 20:34:00 --> Security Class Initialized
DEBUG - 2017-12-26 20:34:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:34:00 --> Input Class Initialized
INFO - 2017-12-26 20:34:00 --> Language Class Initialized
INFO - 2017-12-26 20:34:00 --> Loader Class Initialized
INFO - 2017-12-26 20:34:00 --> Helper loaded: url_helper
INFO - 2017-12-26 20:34:00 --> Helper loaded: form_helper
INFO - 2017-12-26 20:34:00 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:34:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:34:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:34:00 --> Form Validation Class Initialized
INFO - 2017-12-26 20:34:00 --> Model Class Initialized
INFO - 2017-12-26 20:34:00 --> Controller Class Initialized
INFO - 2017-12-26 20:34:00 --> Model Class Initialized
INFO - 2017-12-26 20:34:00 --> Model Class Initialized
INFO - 2017-12-26 20:34:00 --> Model Class Initialized
DEBUG - 2017-12-26 20:34:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:36:02 --> Config Class Initialized
INFO - 2017-12-26 20:36:02 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:36:02 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:36:02 --> Utf8 Class Initialized
INFO - 2017-12-26 20:36:02 --> URI Class Initialized
INFO - 2017-12-26 20:36:02 --> Router Class Initialized
INFO - 2017-12-26 20:36:02 --> Output Class Initialized
INFO - 2017-12-26 20:36:02 --> Security Class Initialized
DEBUG - 2017-12-26 20:36:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:36:02 --> Input Class Initialized
INFO - 2017-12-26 20:36:02 --> Language Class Initialized
INFO - 2017-12-26 20:36:02 --> Loader Class Initialized
INFO - 2017-12-26 20:36:02 --> Helper loaded: url_helper
INFO - 2017-12-26 20:36:02 --> Helper loaded: form_helper
INFO - 2017-12-26 20:36:02 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:36:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:36:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:36:02 --> Form Validation Class Initialized
INFO - 2017-12-26 20:36:02 --> Model Class Initialized
INFO - 2017-12-26 20:36:02 --> Controller Class Initialized
INFO - 2017-12-26 20:36:02 --> Model Class Initialized
INFO - 2017-12-26 20:36:02 --> Model Class Initialized
INFO - 2017-12-26 20:36:02 --> Model Class Initialized
DEBUG - 2017-12-26 20:36:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:36:02 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-26 20:36:02 --> Final output sent to browser
DEBUG - 2017-12-26 20:36:02 --> Total execution time: 0.0599
INFO - 2017-12-26 20:36:02 --> Config Class Initialized
INFO - 2017-12-26 20:36:02 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:36:02 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:36:02 --> Utf8 Class Initialized
INFO - 2017-12-26 20:36:02 --> URI Class Initialized
INFO - 2017-12-26 20:36:02 --> Router Class Initialized
INFO - 2017-12-26 20:36:02 --> Output Class Initialized
INFO - 2017-12-26 20:36:02 --> Security Class Initialized
DEBUG - 2017-12-26 20:36:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:36:02 --> Input Class Initialized
INFO - 2017-12-26 20:36:02 --> Language Class Initialized
ERROR - 2017-12-26 20:36:02 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-26 20:36:02 --> Config Class Initialized
INFO - 2017-12-26 20:36:02 --> Hooks Class Initialized
INFO - 2017-12-26 20:36:02 --> Config Class Initialized
INFO - 2017-12-26 20:36:02 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:36:02 --> UTF-8 Support Enabled
DEBUG - 2017-12-26 20:36:02 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:36:02 --> Utf8 Class Initialized
INFO - 2017-12-26 20:36:02 --> Utf8 Class Initialized
INFO - 2017-12-26 20:36:02 --> URI Class Initialized
INFO - 2017-12-26 20:36:02 --> URI Class Initialized
INFO - 2017-12-26 20:36:02 --> Router Class Initialized
INFO - 2017-12-26 20:36:02 --> Router Class Initialized
INFO - 2017-12-26 20:36:02 --> Output Class Initialized
INFO - 2017-12-26 20:36:02 --> Output Class Initialized
INFO - 2017-12-26 20:36:02 --> Security Class Initialized
INFO - 2017-12-26 20:36:02 --> Security Class Initialized
DEBUG - 2017-12-26 20:36:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:36:02 --> Input Class Initialized
DEBUG - 2017-12-26 20:36:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:36:02 --> Language Class Initialized
INFO - 2017-12-26 20:36:02 --> Input Class Initialized
INFO - 2017-12-26 20:36:02 --> Language Class Initialized
ERROR - 2017-12-26 20:36:02 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-26 20:36:02 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-26 20:36:02 --> Config Class Initialized
INFO - 2017-12-26 20:36:02 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:36:02 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:36:02 --> Utf8 Class Initialized
INFO - 2017-12-26 20:36:02 --> URI Class Initialized
INFO - 2017-12-26 20:36:02 --> Router Class Initialized
INFO - 2017-12-26 20:36:02 --> Output Class Initialized
INFO - 2017-12-26 20:36:02 --> Security Class Initialized
DEBUG - 2017-12-26 20:36:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:36:02 --> Input Class Initialized
INFO - 2017-12-26 20:36:02 --> Language Class Initialized
INFO - 2017-12-26 20:36:02 --> Loader Class Initialized
INFO - 2017-12-26 20:36:02 --> Helper loaded: url_helper
INFO - 2017-12-26 20:36:02 --> Helper loaded: form_helper
INFO - 2017-12-26 20:36:02 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:36:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:36:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:36:02 --> Form Validation Class Initialized
INFO - 2017-12-26 20:36:02 --> Model Class Initialized
INFO - 2017-12-26 20:36:02 --> Controller Class Initialized
INFO - 2017-12-26 20:36:02 --> Model Class Initialized
INFO - 2017-12-26 20:36:02 --> Model Class Initialized
INFO - 2017-12-26 20:36:02 --> Model Class Initialized
DEBUG - 2017-12-26 20:36:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:36:04 --> Config Class Initialized
INFO - 2017-12-26 20:36:04 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:36:04 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:36:04 --> Utf8 Class Initialized
INFO - 2017-12-26 20:36:04 --> URI Class Initialized
INFO - 2017-12-26 20:36:04 --> Router Class Initialized
INFO - 2017-12-26 20:36:04 --> Output Class Initialized
INFO - 2017-12-26 20:36:04 --> Security Class Initialized
DEBUG - 2017-12-26 20:36:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:36:04 --> Input Class Initialized
INFO - 2017-12-26 20:36:04 --> Language Class Initialized
INFO - 2017-12-26 20:36:04 --> Loader Class Initialized
INFO - 2017-12-26 20:36:04 --> Helper loaded: url_helper
INFO - 2017-12-26 20:36:04 --> Helper loaded: form_helper
INFO - 2017-12-26 20:36:04 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:36:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:36:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:36:04 --> Form Validation Class Initialized
INFO - 2017-12-26 20:36:04 --> Model Class Initialized
INFO - 2017-12-26 20:36:04 --> Controller Class Initialized
INFO - 2017-12-26 20:36:04 --> Model Class Initialized
INFO - 2017-12-26 20:36:04 --> Model Class Initialized
INFO - 2017-12-26 20:36:04 --> Model Class Initialized
DEBUG - 2017-12-26 20:36:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:36:04 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-26 20:36:04 --> Final output sent to browser
DEBUG - 2017-12-26 20:36:04 --> Total execution time: 0.0534
INFO - 2017-12-26 20:36:04 --> Config Class Initialized
INFO - 2017-12-26 20:36:04 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:36:04 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:36:04 --> Utf8 Class Initialized
INFO - 2017-12-26 20:36:04 --> URI Class Initialized
INFO - 2017-12-26 20:36:04 --> Router Class Initialized
INFO - 2017-12-26 20:36:04 --> Output Class Initialized
INFO - 2017-12-26 20:36:04 --> Security Class Initialized
DEBUG - 2017-12-26 20:36:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:36:04 --> Input Class Initialized
INFO - 2017-12-26 20:36:04 --> Language Class Initialized
ERROR - 2017-12-26 20:36:04 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-26 20:36:04 --> Config Class Initialized
INFO - 2017-12-26 20:36:04 --> Hooks Class Initialized
INFO - 2017-12-26 20:36:04 --> Config Class Initialized
INFO - 2017-12-26 20:36:04 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:36:04 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:36:04 --> Utf8 Class Initialized
DEBUG - 2017-12-26 20:36:04 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:36:04 --> Utf8 Class Initialized
INFO - 2017-12-26 20:36:04 --> URI Class Initialized
INFO - 2017-12-26 20:36:04 --> URI Class Initialized
INFO - 2017-12-26 20:36:04 --> Router Class Initialized
INFO - 2017-12-26 20:36:04 --> Router Class Initialized
INFO - 2017-12-26 20:36:04 --> Output Class Initialized
INFO - 2017-12-26 20:36:04 --> Output Class Initialized
INFO - 2017-12-26 20:36:04 --> Security Class Initialized
INFO - 2017-12-26 20:36:04 --> Security Class Initialized
DEBUG - 2017-12-26 20:36:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:36:04 --> Input Class Initialized
DEBUG - 2017-12-26 20:36:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:36:04 --> Input Class Initialized
INFO - 2017-12-26 20:36:04 --> Language Class Initialized
INFO - 2017-12-26 20:36:04 --> Language Class Initialized
ERROR - 2017-12-26 20:36:04 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-26 20:36:04 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-26 20:36:04 --> Config Class Initialized
INFO - 2017-12-26 20:36:04 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:36:04 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:36:04 --> Utf8 Class Initialized
INFO - 2017-12-26 20:36:04 --> URI Class Initialized
INFO - 2017-12-26 20:36:04 --> Router Class Initialized
INFO - 2017-12-26 20:36:04 --> Output Class Initialized
INFO - 2017-12-26 20:36:04 --> Security Class Initialized
DEBUG - 2017-12-26 20:36:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:36:04 --> Input Class Initialized
INFO - 2017-12-26 20:36:04 --> Language Class Initialized
INFO - 2017-12-26 20:36:04 --> Loader Class Initialized
INFO - 2017-12-26 20:36:04 --> Helper loaded: url_helper
INFO - 2017-12-26 20:36:04 --> Helper loaded: form_helper
INFO - 2017-12-26 20:36:04 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:36:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:36:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:36:04 --> Form Validation Class Initialized
INFO - 2017-12-26 20:36:04 --> Model Class Initialized
INFO - 2017-12-26 20:36:04 --> Controller Class Initialized
INFO - 2017-12-26 20:36:04 --> Model Class Initialized
INFO - 2017-12-26 20:36:04 --> Model Class Initialized
INFO - 2017-12-26 20:36:04 --> Model Class Initialized
DEBUG - 2017-12-26 20:36:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:36:09 --> Config Class Initialized
INFO - 2017-12-26 20:36:09 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:36:09 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:36:09 --> Utf8 Class Initialized
INFO - 2017-12-26 20:36:09 --> URI Class Initialized
INFO - 2017-12-26 20:36:09 --> Router Class Initialized
INFO - 2017-12-26 20:36:09 --> Output Class Initialized
INFO - 2017-12-26 20:36:09 --> Security Class Initialized
DEBUG - 2017-12-26 20:36:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:36:09 --> Input Class Initialized
INFO - 2017-12-26 20:36:09 --> Language Class Initialized
INFO - 2017-12-26 20:36:09 --> Loader Class Initialized
INFO - 2017-12-26 20:36:09 --> Helper loaded: url_helper
INFO - 2017-12-26 20:36:09 --> Helper loaded: form_helper
INFO - 2017-12-26 20:36:09 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:36:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:36:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:36:09 --> Form Validation Class Initialized
INFO - 2017-12-26 20:36:09 --> Model Class Initialized
INFO - 2017-12-26 20:36:09 --> Controller Class Initialized
INFO - 2017-12-26 20:36:09 --> Model Class Initialized
INFO - 2017-12-26 20:36:09 --> Model Class Initialized
INFO - 2017-12-26 20:36:09 --> Model Class Initialized
DEBUG - 2017-12-26 20:36:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:36:09 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-26 20:36:09 --> Final output sent to browser
DEBUG - 2017-12-26 20:36:09 --> Total execution time: 0.0525
INFO - 2017-12-26 20:36:09 --> Config Class Initialized
INFO - 2017-12-26 20:36:09 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:36:09 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:36:09 --> Utf8 Class Initialized
INFO - 2017-12-26 20:36:09 --> URI Class Initialized
INFO - 2017-12-26 20:36:09 --> Router Class Initialized
INFO - 2017-12-26 20:36:09 --> Output Class Initialized
INFO - 2017-12-26 20:36:09 --> Security Class Initialized
DEBUG - 2017-12-26 20:36:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:36:09 --> Input Class Initialized
INFO - 2017-12-26 20:36:09 --> Language Class Initialized
ERROR - 2017-12-26 20:36:09 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-26 20:36:09 --> Config Class Initialized
INFO - 2017-12-26 20:36:09 --> Hooks Class Initialized
INFO - 2017-12-26 20:36:09 --> Config Class Initialized
INFO - 2017-12-26 20:36:09 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:36:09 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:36:09 --> Utf8 Class Initialized
DEBUG - 2017-12-26 20:36:09 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:36:09 --> URI Class Initialized
INFO - 2017-12-26 20:36:09 --> Utf8 Class Initialized
INFO - 2017-12-26 20:36:09 --> URI Class Initialized
INFO - 2017-12-26 20:36:09 --> Router Class Initialized
INFO - 2017-12-26 20:36:09 --> Router Class Initialized
INFO - 2017-12-26 20:36:09 --> Output Class Initialized
INFO - 2017-12-26 20:36:09 --> Security Class Initialized
INFO - 2017-12-26 20:36:09 --> Output Class Initialized
DEBUG - 2017-12-26 20:36:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:36:09 --> Input Class Initialized
INFO - 2017-12-26 20:36:09 --> Security Class Initialized
INFO - 2017-12-26 20:36:09 --> Language Class Initialized
DEBUG - 2017-12-26 20:36:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:36:09 --> Input Class Initialized
ERROR - 2017-12-26 20:36:09 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-26 20:36:09 --> Language Class Initialized
ERROR - 2017-12-26 20:36:09 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-26 20:36:09 --> Config Class Initialized
INFO - 2017-12-26 20:36:09 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:36:09 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:36:09 --> Utf8 Class Initialized
INFO - 2017-12-26 20:36:09 --> URI Class Initialized
INFO - 2017-12-26 20:36:09 --> Router Class Initialized
INFO - 2017-12-26 20:36:09 --> Output Class Initialized
INFO - 2017-12-26 20:36:09 --> Security Class Initialized
DEBUG - 2017-12-26 20:36:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:36:09 --> Input Class Initialized
INFO - 2017-12-26 20:36:09 --> Language Class Initialized
INFO - 2017-12-26 20:36:09 --> Loader Class Initialized
INFO - 2017-12-26 20:36:09 --> Helper loaded: url_helper
INFO - 2017-12-26 20:36:09 --> Helper loaded: form_helper
INFO - 2017-12-26 20:36:09 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:36:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:36:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:36:09 --> Form Validation Class Initialized
INFO - 2017-12-26 20:36:09 --> Model Class Initialized
INFO - 2017-12-26 20:36:09 --> Controller Class Initialized
INFO - 2017-12-26 20:36:09 --> Model Class Initialized
INFO - 2017-12-26 20:36:09 --> Model Class Initialized
INFO - 2017-12-26 20:36:09 --> Model Class Initialized
DEBUG - 2017-12-26 20:36:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:36:10 --> Config Class Initialized
INFO - 2017-12-26 20:36:10 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:36:10 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:36:10 --> Utf8 Class Initialized
INFO - 2017-12-26 20:36:10 --> URI Class Initialized
INFO - 2017-12-26 20:36:10 --> Router Class Initialized
INFO - 2017-12-26 20:36:10 --> Output Class Initialized
INFO - 2017-12-26 20:36:10 --> Security Class Initialized
DEBUG - 2017-12-26 20:36:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:36:10 --> Input Class Initialized
INFO - 2017-12-26 20:36:10 --> Language Class Initialized
INFO - 2017-12-26 20:36:10 --> Loader Class Initialized
INFO - 2017-12-26 20:36:10 --> Helper loaded: url_helper
INFO - 2017-12-26 20:36:10 --> Helper loaded: form_helper
INFO - 2017-12-26 20:36:10 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:36:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:36:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:36:11 --> Form Validation Class Initialized
INFO - 2017-12-26 20:36:11 --> Model Class Initialized
INFO - 2017-12-26 20:36:11 --> Controller Class Initialized
INFO - 2017-12-26 20:36:11 --> Model Class Initialized
INFO - 2017-12-26 20:36:11 --> Model Class Initialized
INFO - 2017-12-26 20:36:11 --> Model Class Initialized
DEBUG - 2017-12-26 20:36:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:36:11 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-26 20:36:11 --> Final output sent to browser
DEBUG - 2017-12-26 20:36:11 --> Total execution time: 0.1038
INFO - 2017-12-26 20:36:11 --> Config Class Initialized
INFO - 2017-12-26 20:36:11 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:36:11 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:36:11 --> Utf8 Class Initialized
INFO - 2017-12-26 20:36:11 --> URI Class Initialized
INFO - 2017-12-26 20:36:11 --> Router Class Initialized
INFO - 2017-12-26 20:36:11 --> Output Class Initialized
INFO - 2017-12-26 20:36:11 --> Security Class Initialized
DEBUG - 2017-12-26 20:36:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:36:11 --> Input Class Initialized
INFO - 2017-12-26 20:36:11 --> Language Class Initialized
ERROR - 2017-12-26 20:36:11 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-26 20:36:11 --> Config Class Initialized
INFO - 2017-12-26 20:36:11 --> Hooks Class Initialized
INFO - 2017-12-26 20:36:11 --> Config Class Initialized
INFO - 2017-12-26 20:36:11 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:36:11 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:36:11 --> Utf8 Class Initialized
INFO - 2017-12-26 20:36:11 --> URI Class Initialized
DEBUG - 2017-12-26 20:36:11 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:36:11 --> Utf8 Class Initialized
INFO - 2017-12-26 20:36:11 --> Router Class Initialized
INFO - 2017-12-26 20:36:11 --> URI Class Initialized
INFO - 2017-12-26 20:36:11 --> Output Class Initialized
INFO - 2017-12-26 20:36:11 --> Router Class Initialized
INFO - 2017-12-26 20:36:11 --> Security Class Initialized
INFO - 2017-12-26 20:36:11 --> Output Class Initialized
DEBUG - 2017-12-26 20:36:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:36:11 --> Input Class Initialized
INFO - 2017-12-26 20:36:11 --> Security Class Initialized
INFO - 2017-12-26 20:36:11 --> Language Class Initialized
DEBUG - 2017-12-26 20:36:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:36:11 --> Input Class Initialized
ERROR - 2017-12-26 20:36:11 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-26 20:36:11 --> Language Class Initialized
ERROR - 2017-12-26 20:36:11 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-26 20:36:11 --> Config Class Initialized
INFO - 2017-12-26 20:36:11 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:36:11 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:36:11 --> Utf8 Class Initialized
INFO - 2017-12-26 20:36:11 --> URI Class Initialized
INFO - 2017-12-26 20:36:11 --> Router Class Initialized
INFO - 2017-12-26 20:36:11 --> Output Class Initialized
INFO - 2017-12-26 20:36:11 --> Security Class Initialized
DEBUG - 2017-12-26 20:36:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:36:11 --> Input Class Initialized
INFO - 2017-12-26 20:36:11 --> Language Class Initialized
INFO - 2017-12-26 20:36:11 --> Loader Class Initialized
INFO - 2017-12-26 20:36:11 --> Helper loaded: url_helper
INFO - 2017-12-26 20:36:11 --> Helper loaded: form_helper
INFO - 2017-12-26 20:36:11 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:36:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:36:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:36:11 --> Form Validation Class Initialized
INFO - 2017-12-26 20:36:11 --> Model Class Initialized
INFO - 2017-12-26 20:36:11 --> Controller Class Initialized
INFO - 2017-12-26 20:36:11 --> Model Class Initialized
INFO - 2017-12-26 20:36:11 --> Model Class Initialized
INFO - 2017-12-26 20:36:11 --> Model Class Initialized
DEBUG - 2017-12-26 20:36:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:36:11 --> Config Class Initialized
INFO - 2017-12-26 20:36:11 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:36:11 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:36:11 --> Utf8 Class Initialized
INFO - 2017-12-26 20:36:12 --> URI Class Initialized
INFO - 2017-12-26 20:36:12 --> Router Class Initialized
INFO - 2017-12-26 20:36:12 --> Output Class Initialized
INFO - 2017-12-26 20:36:12 --> Security Class Initialized
DEBUG - 2017-12-26 20:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:36:12 --> Input Class Initialized
INFO - 2017-12-26 20:36:12 --> Language Class Initialized
INFO - 2017-12-26 20:36:12 --> Loader Class Initialized
INFO - 2017-12-26 20:36:12 --> Helper loaded: url_helper
INFO - 2017-12-26 20:36:12 --> Helper loaded: form_helper
INFO - 2017-12-26 20:36:12 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:36:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:36:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:36:12 --> Form Validation Class Initialized
INFO - 2017-12-26 20:36:12 --> Model Class Initialized
INFO - 2017-12-26 20:36:12 --> Controller Class Initialized
INFO - 2017-12-26 20:36:12 --> Model Class Initialized
INFO - 2017-12-26 20:36:12 --> Model Class Initialized
INFO - 2017-12-26 20:36:12 --> Model Class Initialized
DEBUG - 2017-12-26 20:36:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:36:12 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-26 20:36:12 --> Final output sent to browser
DEBUG - 2017-12-26 20:36:12 --> Total execution time: 0.0808
INFO - 2017-12-26 20:36:12 --> Config Class Initialized
INFO - 2017-12-26 20:36:12 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:36:12 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:36:12 --> Utf8 Class Initialized
INFO - 2017-12-26 20:36:12 --> URI Class Initialized
INFO - 2017-12-26 20:36:12 --> Router Class Initialized
INFO - 2017-12-26 20:36:12 --> Output Class Initialized
INFO - 2017-12-26 20:36:12 --> Security Class Initialized
DEBUG - 2017-12-26 20:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:36:12 --> Input Class Initialized
INFO - 2017-12-26 20:36:12 --> Language Class Initialized
ERROR - 2017-12-26 20:36:12 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-26 20:36:12 --> Config Class Initialized
INFO - 2017-12-26 20:36:12 --> Config Class Initialized
INFO - 2017-12-26 20:36:12 --> Hooks Class Initialized
INFO - 2017-12-26 20:36:12 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:36:12 --> UTF-8 Support Enabled
DEBUG - 2017-12-26 20:36:12 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:36:12 --> Utf8 Class Initialized
INFO - 2017-12-26 20:36:12 --> Utf8 Class Initialized
INFO - 2017-12-26 20:36:12 --> URI Class Initialized
INFO - 2017-12-26 20:36:12 --> URI Class Initialized
INFO - 2017-12-26 20:36:12 --> Router Class Initialized
INFO - 2017-12-26 20:36:12 --> Router Class Initialized
INFO - 2017-12-26 20:36:12 --> Output Class Initialized
INFO - 2017-12-26 20:36:12 --> Output Class Initialized
INFO - 2017-12-26 20:36:12 --> Security Class Initialized
INFO - 2017-12-26 20:36:12 --> Security Class Initialized
DEBUG - 2017-12-26 20:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:36:12 --> Input Class Initialized
DEBUG - 2017-12-26 20:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:36:12 --> Input Class Initialized
INFO - 2017-12-26 20:36:12 --> Language Class Initialized
INFO - 2017-12-26 20:36:12 --> Language Class Initialized
ERROR - 2017-12-26 20:36:12 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-26 20:36:12 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-26 20:36:12 --> Config Class Initialized
INFO - 2017-12-26 20:36:12 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:36:12 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:36:12 --> Utf8 Class Initialized
INFO - 2017-12-26 20:36:12 --> URI Class Initialized
INFO - 2017-12-26 20:36:12 --> Router Class Initialized
INFO - 2017-12-26 20:36:12 --> Output Class Initialized
INFO - 2017-12-26 20:36:12 --> Security Class Initialized
DEBUG - 2017-12-26 20:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:36:12 --> Input Class Initialized
INFO - 2017-12-26 20:36:12 --> Language Class Initialized
INFO - 2017-12-26 20:36:12 --> Loader Class Initialized
INFO - 2017-12-26 20:36:12 --> Helper loaded: url_helper
INFO - 2017-12-26 20:36:12 --> Helper loaded: form_helper
INFO - 2017-12-26 20:36:12 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:36:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:36:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:36:12 --> Form Validation Class Initialized
INFO - 2017-12-26 20:36:12 --> Model Class Initialized
INFO - 2017-12-26 20:36:12 --> Controller Class Initialized
INFO - 2017-12-26 20:36:12 --> Model Class Initialized
INFO - 2017-12-26 20:36:12 --> Model Class Initialized
INFO - 2017-12-26 20:36:12 --> Model Class Initialized
DEBUG - 2017-12-26 20:36:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:36:12 --> Config Class Initialized
INFO - 2017-12-26 20:36:12 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:36:12 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:36:12 --> Utf8 Class Initialized
INFO - 2017-12-26 20:36:12 --> URI Class Initialized
INFO - 2017-12-26 20:36:12 --> Router Class Initialized
INFO - 2017-12-26 20:36:12 --> Output Class Initialized
INFO - 2017-12-26 20:36:12 --> Security Class Initialized
DEBUG - 2017-12-26 20:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:36:12 --> Input Class Initialized
INFO - 2017-12-26 20:36:12 --> Language Class Initialized
INFO - 2017-12-26 20:36:12 --> Loader Class Initialized
INFO - 2017-12-26 20:36:12 --> Helper loaded: url_helper
INFO - 2017-12-26 20:36:12 --> Helper loaded: form_helper
INFO - 2017-12-26 20:36:12 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:36:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:36:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:36:12 --> Form Validation Class Initialized
INFO - 2017-12-26 20:36:12 --> Model Class Initialized
INFO - 2017-12-26 20:36:12 --> Controller Class Initialized
INFO - 2017-12-26 20:36:12 --> Model Class Initialized
INFO - 2017-12-26 20:36:12 --> Model Class Initialized
INFO - 2017-12-26 20:36:12 --> Model Class Initialized
DEBUG - 2017-12-26 20:36:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:36:12 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-26 20:36:12 --> Final output sent to browser
DEBUG - 2017-12-26 20:36:12 --> Total execution time: 0.0493
INFO - 2017-12-26 20:36:12 --> Config Class Initialized
INFO - 2017-12-26 20:36:12 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:36:12 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:36:12 --> Utf8 Class Initialized
INFO - 2017-12-26 20:36:12 --> URI Class Initialized
INFO - 2017-12-26 20:36:12 --> Router Class Initialized
INFO - 2017-12-26 20:36:12 --> Output Class Initialized
INFO - 2017-12-26 20:36:12 --> Security Class Initialized
DEBUG - 2017-12-26 20:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:36:12 --> Input Class Initialized
INFO - 2017-12-26 20:36:12 --> Language Class Initialized
ERROR - 2017-12-26 20:36:12 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-26 20:36:12 --> Config Class Initialized
INFO - 2017-12-26 20:36:12 --> Hooks Class Initialized
INFO - 2017-12-26 20:36:12 --> Config Class Initialized
INFO - 2017-12-26 20:36:12 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:36:12 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:36:12 --> Utf8 Class Initialized
DEBUG - 2017-12-26 20:36:12 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:36:12 --> URI Class Initialized
INFO - 2017-12-26 20:36:12 --> Utf8 Class Initialized
INFO - 2017-12-26 20:36:12 --> URI Class Initialized
INFO - 2017-12-26 20:36:12 --> Router Class Initialized
INFO - 2017-12-26 20:36:12 --> Router Class Initialized
INFO - 2017-12-26 20:36:12 --> Output Class Initialized
INFO - 2017-12-26 20:36:12 --> Output Class Initialized
INFO - 2017-12-26 20:36:12 --> Security Class Initialized
INFO - 2017-12-26 20:36:12 --> Security Class Initialized
DEBUG - 2017-12-26 20:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:36:12 --> Input Class Initialized
DEBUG - 2017-12-26 20:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:36:12 --> Input Class Initialized
INFO - 2017-12-26 20:36:12 --> Language Class Initialized
INFO - 2017-12-26 20:36:12 --> Language Class Initialized
ERROR - 2017-12-26 20:36:12 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-26 20:36:12 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-26 20:36:12 --> Config Class Initialized
INFO - 2017-12-26 20:36:12 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:36:12 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:36:12 --> Utf8 Class Initialized
INFO - 2017-12-26 20:36:12 --> URI Class Initialized
INFO - 2017-12-26 20:36:12 --> Router Class Initialized
INFO - 2017-12-26 20:36:12 --> Output Class Initialized
INFO - 2017-12-26 20:36:12 --> Security Class Initialized
DEBUG - 2017-12-26 20:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:36:12 --> Input Class Initialized
INFO - 2017-12-26 20:36:12 --> Language Class Initialized
INFO - 2017-12-26 20:36:12 --> Loader Class Initialized
INFO - 2017-12-26 20:36:12 --> Helper loaded: url_helper
INFO - 2017-12-26 20:36:12 --> Helper loaded: form_helper
INFO - 2017-12-26 20:36:12 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:36:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:36:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:36:12 --> Form Validation Class Initialized
INFO - 2017-12-26 20:36:12 --> Model Class Initialized
INFO - 2017-12-26 20:36:12 --> Controller Class Initialized
INFO - 2017-12-26 20:36:12 --> Model Class Initialized
INFO - 2017-12-26 20:36:12 --> Model Class Initialized
INFO - 2017-12-26 20:36:12 --> Model Class Initialized
DEBUG - 2017-12-26 20:36:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:36:13 --> Config Class Initialized
INFO - 2017-12-26 20:36:13 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:36:13 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:36:13 --> Utf8 Class Initialized
INFO - 2017-12-26 20:36:13 --> URI Class Initialized
INFO - 2017-12-26 20:36:13 --> Router Class Initialized
INFO - 2017-12-26 20:36:13 --> Output Class Initialized
INFO - 2017-12-26 20:36:13 --> Security Class Initialized
DEBUG - 2017-12-26 20:36:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:36:13 --> Input Class Initialized
INFO - 2017-12-26 20:36:13 --> Language Class Initialized
INFO - 2017-12-26 20:36:13 --> Loader Class Initialized
INFO - 2017-12-26 20:36:13 --> Helper loaded: url_helper
INFO - 2017-12-26 20:36:13 --> Helper loaded: form_helper
INFO - 2017-12-26 20:36:13 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:36:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:36:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:36:13 --> Form Validation Class Initialized
INFO - 2017-12-26 20:36:13 --> Model Class Initialized
INFO - 2017-12-26 20:36:13 --> Controller Class Initialized
INFO - 2017-12-26 20:36:13 --> Model Class Initialized
INFO - 2017-12-26 20:36:13 --> Model Class Initialized
INFO - 2017-12-26 20:36:13 --> Model Class Initialized
DEBUG - 2017-12-26 20:36:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:36:13 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-26 20:36:13 --> Final output sent to browser
DEBUG - 2017-12-26 20:36:13 --> Total execution time: 0.0790
INFO - 2017-12-26 20:36:13 --> Config Class Initialized
INFO - 2017-12-26 20:36:13 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:36:13 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:36:13 --> Utf8 Class Initialized
INFO - 2017-12-26 20:36:13 --> URI Class Initialized
INFO - 2017-12-26 20:36:13 --> Router Class Initialized
INFO - 2017-12-26 20:36:13 --> Output Class Initialized
INFO - 2017-12-26 20:36:13 --> Security Class Initialized
DEBUG - 2017-12-26 20:36:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:36:13 --> Input Class Initialized
INFO - 2017-12-26 20:36:13 --> Language Class Initialized
ERROR - 2017-12-26 20:36:13 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-26 20:36:13 --> Config Class Initialized
INFO - 2017-12-26 20:36:13 --> Hooks Class Initialized
INFO - 2017-12-26 20:36:13 --> Config Class Initialized
INFO - 2017-12-26 20:36:13 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:36:13 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:36:13 --> Utf8 Class Initialized
DEBUG - 2017-12-26 20:36:13 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:36:13 --> URI Class Initialized
INFO - 2017-12-26 20:36:13 --> Utf8 Class Initialized
INFO - 2017-12-26 20:36:13 --> URI Class Initialized
INFO - 2017-12-26 20:36:13 --> Router Class Initialized
INFO - 2017-12-26 20:36:13 --> Router Class Initialized
INFO - 2017-12-26 20:36:13 --> Output Class Initialized
INFO - 2017-12-26 20:36:13 --> Output Class Initialized
INFO - 2017-12-26 20:36:13 --> Security Class Initialized
INFO - 2017-12-26 20:36:13 --> Security Class Initialized
DEBUG - 2017-12-26 20:36:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:36:13 --> Input Class Initialized
DEBUG - 2017-12-26 20:36:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:36:13 --> Input Class Initialized
INFO - 2017-12-26 20:36:13 --> Language Class Initialized
INFO - 2017-12-26 20:36:13 --> Language Class Initialized
ERROR - 2017-12-26 20:36:13 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-26 20:36:13 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-26 20:36:13 --> Config Class Initialized
INFO - 2017-12-26 20:36:13 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:36:13 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:36:13 --> Utf8 Class Initialized
INFO - 2017-12-26 20:36:13 --> URI Class Initialized
INFO - 2017-12-26 20:36:13 --> Router Class Initialized
INFO - 2017-12-26 20:36:13 --> Output Class Initialized
INFO - 2017-12-26 20:36:13 --> Security Class Initialized
DEBUG - 2017-12-26 20:36:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:36:13 --> Input Class Initialized
INFO - 2017-12-26 20:36:13 --> Language Class Initialized
INFO - 2017-12-26 20:36:13 --> Loader Class Initialized
INFO - 2017-12-26 20:36:13 --> Helper loaded: url_helper
INFO - 2017-12-26 20:36:13 --> Helper loaded: form_helper
INFO - 2017-12-26 20:36:13 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:36:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:36:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:36:14 --> Form Validation Class Initialized
INFO - 2017-12-26 20:36:14 --> Model Class Initialized
INFO - 2017-12-26 20:36:14 --> Controller Class Initialized
INFO - 2017-12-26 20:36:14 --> Model Class Initialized
INFO - 2017-12-26 20:36:14 --> Model Class Initialized
INFO - 2017-12-26 20:36:14 --> Model Class Initialized
DEBUG - 2017-12-26 20:36:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:36:14 --> Config Class Initialized
INFO - 2017-12-26 20:36:14 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:36:14 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:36:14 --> Utf8 Class Initialized
INFO - 2017-12-26 20:36:14 --> URI Class Initialized
INFO - 2017-12-26 20:36:14 --> Router Class Initialized
INFO - 2017-12-26 20:36:14 --> Output Class Initialized
INFO - 2017-12-26 20:36:14 --> Security Class Initialized
DEBUG - 2017-12-26 20:36:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:36:14 --> Input Class Initialized
INFO - 2017-12-26 20:36:14 --> Language Class Initialized
INFO - 2017-12-26 20:36:14 --> Loader Class Initialized
INFO - 2017-12-26 20:36:14 --> Helper loaded: url_helper
INFO - 2017-12-26 20:36:14 --> Helper loaded: form_helper
INFO - 2017-12-26 20:36:14 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:36:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:36:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:36:14 --> Form Validation Class Initialized
INFO - 2017-12-26 20:36:14 --> Model Class Initialized
INFO - 2017-12-26 20:36:14 --> Controller Class Initialized
INFO - 2017-12-26 20:36:14 --> Model Class Initialized
INFO - 2017-12-26 20:36:14 --> Model Class Initialized
INFO - 2017-12-26 20:36:14 --> Model Class Initialized
DEBUG - 2017-12-26 20:36:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:36:14 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-26 20:36:14 --> Final output sent to browser
DEBUG - 2017-12-26 20:36:14 --> Total execution time: 0.0803
INFO - 2017-12-26 20:36:14 --> Config Class Initialized
INFO - 2017-12-26 20:36:14 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:36:14 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:36:14 --> Utf8 Class Initialized
INFO - 2017-12-26 20:36:14 --> URI Class Initialized
INFO - 2017-12-26 20:36:14 --> Router Class Initialized
INFO - 2017-12-26 20:36:14 --> Output Class Initialized
INFO - 2017-12-26 20:36:14 --> Security Class Initialized
DEBUG - 2017-12-26 20:36:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:36:14 --> Input Class Initialized
INFO - 2017-12-26 20:36:14 --> Language Class Initialized
ERROR - 2017-12-26 20:36:14 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-26 20:36:14 --> Config Class Initialized
INFO - 2017-12-26 20:36:14 --> Config Class Initialized
INFO - 2017-12-26 20:36:14 --> Hooks Class Initialized
INFO - 2017-12-26 20:36:14 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:36:14 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:36:14 --> Utf8 Class Initialized
DEBUG - 2017-12-26 20:36:14 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:36:14 --> Utf8 Class Initialized
INFO - 2017-12-26 20:36:14 --> URI Class Initialized
INFO - 2017-12-26 20:36:14 --> URI Class Initialized
INFO - 2017-12-26 20:36:14 --> Router Class Initialized
INFO - 2017-12-26 20:36:14 --> Router Class Initialized
INFO - 2017-12-26 20:36:14 --> Output Class Initialized
INFO - 2017-12-26 20:36:14 --> Output Class Initialized
INFO - 2017-12-26 20:36:14 --> Security Class Initialized
INFO - 2017-12-26 20:36:14 --> Security Class Initialized
DEBUG - 2017-12-26 20:36:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-26 20:36:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:36:14 --> Input Class Initialized
INFO - 2017-12-26 20:36:14 --> Input Class Initialized
INFO - 2017-12-26 20:36:14 --> Language Class Initialized
INFO - 2017-12-26 20:36:14 --> Language Class Initialized
ERROR - 2017-12-26 20:36:14 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-26 20:36:14 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-26 20:36:14 --> Config Class Initialized
INFO - 2017-12-26 20:36:14 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:36:14 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:36:14 --> Utf8 Class Initialized
INFO - 2017-12-26 20:36:14 --> URI Class Initialized
INFO - 2017-12-26 20:36:14 --> Router Class Initialized
INFO - 2017-12-26 20:36:14 --> Output Class Initialized
INFO - 2017-12-26 20:36:14 --> Security Class Initialized
DEBUG - 2017-12-26 20:36:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:36:14 --> Input Class Initialized
INFO - 2017-12-26 20:36:14 --> Language Class Initialized
INFO - 2017-12-26 20:36:14 --> Loader Class Initialized
INFO - 2017-12-26 20:36:14 --> Helper loaded: url_helper
INFO - 2017-12-26 20:36:14 --> Helper loaded: form_helper
INFO - 2017-12-26 20:36:14 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:36:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:36:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:36:14 --> Form Validation Class Initialized
INFO - 2017-12-26 20:36:14 --> Model Class Initialized
INFO - 2017-12-26 20:36:14 --> Controller Class Initialized
INFO - 2017-12-26 20:36:14 --> Model Class Initialized
INFO - 2017-12-26 20:36:14 --> Model Class Initialized
INFO - 2017-12-26 20:36:14 --> Model Class Initialized
DEBUG - 2017-12-26 20:36:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:36:15 --> Config Class Initialized
INFO - 2017-12-26 20:36:15 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:36:15 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:36:15 --> Utf8 Class Initialized
INFO - 2017-12-26 20:36:15 --> URI Class Initialized
INFO - 2017-12-26 20:36:15 --> Router Class Initialized
INFO - 2017-12-26 20:36:15 --> Output Class Initialized
INFO - 2017-12-26 20:36:15 --> Security Class Initialized
DEBUG - 2017-12-26 20:36:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:36:15 --> Input Class Initialized
INFO - 2017-12-26 20:36:15 --> Language Class Initialized
INFO - 2017-12-26 20:36:15 --> Loader Class Initialized
INFO - 2017-12-26 20:36:15 --> Helper loaded: url_helper
INFO - 2017-12-26 20:36:15 --> Helper loaded: form_helper
INFO - 2017-12-26 20:36:15 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:36:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:36:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:36:15 --> Form Validation Class Initialized
INFO - 2017-12-26 20:36:15 --> Model Class Initialized
INFO - 2017-12-26 20:36:15 --> Controller Class Initialized
INFO - 2017-12-26 20:36:15 --> Model Class Initialized
INFO - 2017-12-26 20:36:15 --> Model Class Initialized
INFO - 2017-12-26 20:36:15 --> Model Class Initialized
DEBUG - 2017-12-26 20:36:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:36:15 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-26 20:36:15 --> Final output sent to browser
DEBUG - 2017-12-26 20:36:15 --> Total execution time: 0.1267
INFO - 2017-12-26 20:36:15 --> Config Class Initialized
INFO - 2017-12-26 20:36:15 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:36:15 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:36:15 --> Utf8 Class Initialized
INFO - 2017-12-26 20:36:15 --> URI Class Initialized
INFO - 2017-12-26 20:36:15 --> Router Class Initialized
INFO - 2017-12-26 20:36:15 --> Output Class Initialized
INFO - 2017-12-26 20:36:15 --> Security Class Initialized
DEBUG - 2017-12-26 20:36:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:36:15 --> Input Class Initialized
INFO - 2017-12-26 20:36:15 --> Language Class Initialized
ERROR - 2017-12-26 20:36:15 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-26 20:36:15 --> Config Class Initialized
INFO - 2017-12-26 20:36:15 --> Hooks Class Initialized
INFO - 2017-12-26 20:36:15 --> Config Class Initialized
INFO - 2017-12-26 20:36:15 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:36:15 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:36:15 --> Utf8 Class Initialized
DEBUG - 2017-12-26 20:36:15 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:36:15 --> Utf8 Class Initialized
INFO - 2017-12-26 20:36:15 --> URI Class Initialized
INFO - 2017-12-26 20:36:15 --> URI Class Initialized
INFO - 2017-12-26 20:36:15 --> Router Class Initialized
INFO - 2017-12-26 20:36:15 --> Router Class Initialized
INFO - 2017-12-26 20:36:15 --> Output Class Initialized
INFO - 2017-12-26 20:36:15 --> Output Class Initialized
INFO - 2017-12-26 20:36:15 --> Security Class Initialized
INFO - 2017-12-26 20:36:15 --> Security Class Initialized
DEBUG - 2017-12-26 20:36:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:36:15 --> Input Class Initialized
DEBUG - 2017-12-26 20:36:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:36:15 --> Input Class Initialized
INFO - 2017-12-26 20:36:15 --> Language Class Initialized
INFO - 2017-12-26 20:36:15 --> Language Class Initialized
ERROR - 2017-12-26 20:36:15 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-26 20:36:15 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-26 20:36:15 --> Config Class Initialized
INFO - 2017-12-26 20:36:15 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:36:15 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:36:15 --> Utf8 Class Initialized
INFO - 2017-12-26 20:36:15 --> URI Class Initialized
INFO - 2017-12-26 20:36:15 --> Router Class Initialized
INFO - 2017-12-26 20:36:15 --> Output Class Initialized
INFO - 2017-12-26 20:36:15 --> Security Class Initialized
DEBUG - 2017-12-26 20:36:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:36:15 --> Input Class Initialized
INFO - 2017-12-26 20:36:15 --> Language Class Initialized
INFO - 2017-12-26 20:36:15 --> Loader Class Initialized
INFO - 2017-12-26 20:36:15 --> Helper loaded: url_helper
INFO - 2017-12-26 20:36:15 --> Helper loaded: form_helper
INFO - 2017-12-26 20:36:15 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:36:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:36:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:36:15 --> Form Validation Class Initialized
INFO - 2017-12-26 20:36:15 --> Model Class Initialized
INFO - 2017-12-26 20:36:15 --> Controller Class Initialized
INFO - 2017-12-26 20:36:15 --> Model Class Initialized
INFO - 2017-12-26 20:36:15 --> Model Class Initialized
INFO - 2017-12-26 20:36:15 --> Model Class Initialized
DEBUG - 2017-12-26 20:36:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:36:23 --> Config Class Initialized
INFO - 2017-12-26 20:36:23 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:36:23 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:36:23 --> Utf8 Class Initialized
INFO - 2017-12-26 20:36:23 --> URI Class Initialized
INFO - 2017-12-26 20:36:23 --> Router Class Initialized
INFO - 2017-12-26 20:36:23 --> Output Class Initialized
INFO - 2017-12-26 20:36:23 --> Security Class Initialized
DEBUG - 2017-12-26 20:36:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:36:23 --> Input Class Initialized
INFO - 2017-12-26 20:36:23 --> Language Class Initialized
INFO - 2017-12-26 20:36:23 --> Loader Class Initialized
INFO - 2017-12-26 20:36:23 --> Helper loaded: url_helper
INFO - 2017-12-26 20:36:23 --> Helper loaded: form_helper
INFO - 2017-12-26 20:36:23 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:36:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:36:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:36:23 --> Form Validation Class Initialized
INFO - 2017-12-26 20:36:23 --> Model Class Initialized
INFO - 2017-12-26 20:36:23 --> Controller Class Initialized
INFO - 2017-12-26 20:36:23 --> Model Class Initialized
INFO - 2017-12-26 20:36:23 --> Model Class Initialized
INFO - 2017-12-26 20:36:23 --> Model Class Initialized
DEBUG - 2017-12-26 20:36:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:36:23 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-26 20:36:23 --> Final output sent to browser
DEBUG - 2017-12-26 20:36:23 --> Total execution time: 0.0506
INFO - 2017-12-26 20:36:23 --> Config Class Initialized
INFO - 2017-12-26 20:36:23 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:36:23 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:36:23 --> Utf8 Class Initialized
INFO - 2017-12-26 20:36:23 --> URI Class Initialized
INFO - 2017-12-26 20:36:23 --> Router Class Initialized
INFO - 2017-12-26 20:36:23 --> Output Class Initialized
INFO - 2017-12-26 20:36:23 --> Security Class Initialized
DEBUG - 2017-12-26 20:36:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:36:23 --> Input Class Initialized
INFO - 2017-12-26 20:36:23 --> Language Class Initialized
ERROR - 2017-12-26 20:36:23 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-26 20:36:23 --> Config Class Initialized
INFO - 2017-12-26 20:36:23 --> Hooks Class Initialized
INFO - 2017-12-26 20:36:23 --> Config Class Initialized
INFO - 2017-12-26 20:36:23 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:36:23 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:36:23 --> Utf8 Class Initialized
INFO - 2017-12-26 20:36:23 --> URI Class Initialized
DEBUG - 2017-12-26 20:36:23 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:36:23 --> Utf8 Class Initialized
INFO - 2017-12-26 20:36:23 --> Router Class Initialized
INFO - 2017-12-26 20:36:23 --> URI Class Initialized
INFO - 2017-12-26 20:36:23 --> Output Class Initialized
INFO - 2017-12-26 20:36:23 --> Router Class Initialized
INFO - 2017-12-26 20:36:23 --> Security Class Initialized
DEBUG - 2017-12-26 20:36:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:36:23 --> Input Class Initialized
INFO - 2017-12-26 20:36:23 --> Output Class Initialized
INFO - 2017-12-26 20:36:23 --> Language Class Initialized
INFO - 2017-12-26 20:36:23 --> Security Class Initialized
ERROR - 2017-12-26 20:36:23 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2017-12-26 20:36:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:36:23 --> Input Class Initialized
INFO - 2017-12-26 20:36:23 --> Language Class Initialized
ERROR - 2017-12-26 20:36:23 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-26 20:36:23 --> Config Class Initialized
INFO - 2017-12-26 20:36:23 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:36:23 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:36:23 --> Utf8 Class Initialized
INFO - 2017-12-26 20:36:23 --> URI Class Initialized
INFO - 2017-12-26 20:36:23 --> Router Class Initialized
INFO - 2017-12-26 20:36:23 --> Output Class Initialized
INFO - 2017-12-26 20:36:23 --> Security Class Initialized
DEBUG - 2017-12-26 20:36:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:36:23 --> Input Class Initialized
INFO - 2017-12-26 20:36:23 --> Language Class Initialized
INFO - 2017-12-26 20:36:23 --> Loader Class Initialized
INFO - 2017-12-26 20:36:23 --> Helper loaded: url_helper
INFO - 2017-12-26 20:36:23 --> Helper loaded: form_helper
INFO - 2017-12-26 20:36:23 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:36:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:36:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:36:23 --> Form Validation Class Initialized
INFO - 2017-12-26 20:36:23 --> Model Class Initialized
INFO - 2017-12-26 20:36:23 --> Controller Class Initialized
INFO - 2017-12-26 20:36:23 --> Model Class Initialized
INFO - 2017-12-26 20:36:23 --> Model Class Initialized
INFO - 2017-12-26 20:36:23 --> Model Class Initialized
DEBUG - 2017-12-26 20:36:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:36:28 --> Config Class Initialized
INFO - 2017-12-26 20:36:28 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:36:28 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:36:28 --> Utf8 Class Initialized
INFO - 2017-12-26 20:36:28 --> URI Class Initialized
INFO - 2017-12-26 20:36:28 --> Router Class Initialized
INFO - 2017-12-26 20:36:28 --> Output Class Initialized
INFO - 2017-12-26 20:36:28 --> Security Class Initialized
DEBUG - 2017-12-26 20:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:36:28 --> Input Class Initialized
INFO - 2017-12-26 20:36:28 --> Language Class Initialized
INFO - 2017-12-26 20:36:28 --> Loader Class Initialized
INFO - 2017-12-26 20:36:28 --> Helper loaded: url_helper
INFO - 2017-12-26 20:36:28 --> Helper loaded: form_helper
INFO - 2017-12-26 20:36:28 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:36:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:36:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:36:28 --> Form Validation Class Initialized
INFO - 2017-12-26 20:36:28 --> Model Class Initialized
INFO - 2017-12-26 20:36:28 --> Controller Class Initialized
INFO - 2017-12-26 20:36:28 --> Model Class Initialized
INFO - 2017-12-26 20:36:28 --> Model Class Initialized
INFO - 2017-12-26 20:36:28 --> Model Class Initialized
DEBUG - 2017-12-26 20:36:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:36:28 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-26 20:36:28 --> Final output sent to browser
DEBUG - 2017-12-26 20:36:28 --> Total execution time: 0.1004
INFO - 2017-12-26 20:36:28 --> Config Class Initialized
INFO - 2017-12-26 20:36:28 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:36:28 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:36:28 --> Utf8 Class Initialized
INFO - 2017-12-26 20:36:28 --> URI Class Initialized
INFO - 2017-12-26 20:36:28 --> Router Class Initialized
INFO - 2017-12-26 20:36:28 --> Output Class Initialized
INFO - 2017-12-26 20:36:28 --> Security Class Initialized
DEBUG - 2017-12-26 20:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:36:28 --> Input Class Initialized
INFO - 2017-12-26 20:36:28 --> Language Class Initialized
INFO - 2017-12-26 20:36:28 --> Loader Class Initialized
INFO - 2017-12-26 20:36:28 --> Helper loaded: url_helper
INFO - 2017-12-26 20:36:28 --> Helper loaded: form_helper
INFO - 2017-12-26 20:36:28 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:36:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:36:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:36:28 --> Form Validation Class Initialized
INFO - 2017-12-26 20:36:28 --> Model Class Initialized
INFO - 2017-12-26 20:36:28 --> Controller Class Initialized
INFO - 2017-12-26 20:36:28 --> Model Class Initialized
INFO - 2017-12-26 20:36:28 --> Model Class Initialized
INFO - 2017-12-26 20:36:28 --> Model Class Initialized
DEBUG - 2017-12-26 20:36:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:36:28 --> Config Class Initialized
INFO - 2017-12-26 20:36:28 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:36:28 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:36:28 --> Utf8 Class Initialized
INFO - 2017-12-26 20:36:28 --> URI Class Initialized
INFO - 2017-12-26 20:36:28 --> Router Class Initialized
INFO - 2017-12-26 20:36:28 --> Output Class Initialized
INFO - 2017-12-26 20:36:28 --> Security Class Initialized
DEBUG - 2017-12-26 20:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:36:28 --> Input Class Initialized
INFO - 2017-12-26 20:36:28 --> Language Class Initialized
INFO - 2017-12-26 20:36:28 --> Loader Class Initialized
INFO - 2017-12-26 20:36:28 --> Helper loaded: url_helper
INFO - 2017-12-26 20:36:28 --> Helper loaded: form_helper
INFO - 2017-12-26 20:36:28 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:36:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:36:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:36:28 --> Form Validation Class Initialized
INFO - 2017-12-26 20:36:28 --> Model Class Initialized
INFO - 2017-12-26 20:36:28 --> Controller Class Initialized
INFO - 2017-12-26 20:36:28 --> Model Class Initialized
INFO - 2017-12-26 20:36:28 --> Model Class Initialized
INFO - 2017-12-26 20:36:28 --> Model Class Initialized
DEBUG - 2017-12-26 20:36:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:36:28 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-26 20:36:28 --> Final output sent to browser
DEBUG - 2017-12-26 20:36:28 --> Total execution time: 0.0963
INFO - 2017-12-26 20:36:29 --> Config Class Initialized
INFO - 2017-12-26 20:36:29 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:36:29 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:36:29 --> Utf8 Class Initialized
INFO - 2017-12-26 20:36:29 --> URI Class Initialized
INFO - 2017-12-26 20:36:29 --> Router Class Initialized
INFO - 2017-12-26 20:36:29 --> Output Class Initialized
INFO - 2017-12-26 20:36:29 --> Security Class Initialized
DEBUG - 2017-12-26 20:36:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:36:29 --> Input Class Initialized
INFO - 2017-12-26 20:36:29 --> Language Class Initialized
INFO - 2017-12-26 20:36:29 --> Loader Class Initialized
INFO - 2017-12-26 20:36:29 --> Helper loaded: url_helper
INFO - 2017-12-26 20:36:29 --> Helper loaded: form_helper
INFO - 2017-12-26 20:36:29 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:36:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:36:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:36:29 --> Form Validation Class Initialized
INFO - 2017-12-26 20:36:29 --> Model Class Initialized
INFO - 2017-12-26 20:36:29 --> Controller Class Initialized
INFO - 2017-12-26 20:36:29 --> Model Class Initialized
INFO - 2017-12-26 20:36:29 --> Model Class Initialized
INFO - 2017-12-26 20:36:29 --> Model Class Initialized
DEBUG - 2017-12-26 20:36:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:36:29 --> Config Class Initialized
INFO - 2017-12-26 20:36:29 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:36:29 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:36:29 --> Utf8 Class Initialized
INFO - 2017-12-26 20:36:29 --> URI Class Initialized
INFO - 2017-12-26 20:36:29 --> Router Class Initialized
INFO - 2017-12-26 20:36:29 --> Output Class Initialized
INFO - 2017-12-26 20:36:29 --> Security Class Initialized
DEBUG - 2017-12-26 20:36:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:36:29 --> Input Class Initialized
INFO - 2017-12-26 20:36:29 --> Language Class Initialized
INFO - 2017-12-26 20:36:29 --> Loader Class Initialized
INFO - 2017-12-26 20:36:29 --> Helper loaded: url_helper
INFO - 2017-12-26 20:36:29 --> Helper loaded: form_helper
INFO - 2017-12-26 20:36:29 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:36:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:36:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:36:29 --> Form Validation Class Initialized
INFO - 2017-12-26 20:36:29 --> Model Class Initialized
INFO - 2017-12-26 20:36:29 --> Controller Class Initialized
INFO - 2017-12-26 20:36:29 --> Model Class Initialized
INFO - 2017-12-26 20:36:29 --> Model Class Initialized
INFO - 2017-12-26 20:36:29 --> Model Class Initialized
DEBUG - 2017-12-26 20:36:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:36:30 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-26 20:36:30 --> Final output sent to browser
DEBUG - 2017-12-26 20:36:30 --> Total execution time: 0.1150
INFO - 2017-12-26 20:36:30 --> Config Class Initialized
INFO - 2017-12-26 20:36:30 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:36:30 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:36:30 --> Utf8 Class Initialized
INFO - 2017-12-26 20:36:30 --> URI Class Initialized
INFO - 2017-12-26 20:36:30 --> Router Class Initialized
INFO - 2017-12-26 20:36:30 --> Output Class Initialized
INFO - 2017-12-26 20:36:30 --> Security Class Initialized
DEBUG - 2017-12-26 20:36:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:36:30 --> Input Class Initialized
INFO - 2017-12-26 20:36:30 --> Language Class Initialized
INFO - 2017-12-26 20:36:30 --> Loader Class Initialized
INFO - 2017-12-26 20:36:30 --> Helper loaded: url_helper
INFO - 2017-12-26 20:36:30 --> Helper loaded: form_helper
INFO - 2017-12-26 20:36:30 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:36:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:36:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:36:30 --> Form Validation Class Initialized
INFO - 2017-12-26 20:36:30 --> Model Class Initialized
INFO - 2017-12-26 20:36:30 --> Controller Class Initialized
INFO - 2017-12-26 20:36:30 --> Model Class Initialized
INFO - 2017-12-26 20:36:30 --> Model Class Initialized
INFO - 2017-12-26 20:36:30 --> Model Class Initialized
DEBUG - 2017-12-26 20:36:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:36:31 --> Config Class Initialized
INFO - 2017-12-26 20:36:31 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:36:31 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:36:31 --> Utf8 Class Initialized
INFO - 2017-12-26 20:36:31 --> URI Class Initialized
INFO - 2017-12-26 20:36:31 --> Router Class Initialized
INFO - 2017-12-26 20:36:31 --> Output Class Initialized
INFO - 2017-12-26 20:36:31 --> Security Class Initialized
DEBUG - 2017-12-26 20:36:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:36:31 --> Input Class Initialized
INFO - 2017-12-26 20:36:31 --> Language Class Initialized
INFO - 2017-12-26 20:36:31 --> Loader Class Initialized
INFO - 2017-12-26 20:36:31 --> Helper loaded: url_helper
INFO - 2017-12-26 20:36:31 --> Helper loaded: form_helper
INFO - 2017-12-26 20:36:31 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:36:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:36:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:36:31 --> Form Validation Class Initialized
INFO - 2017-12-26 20:36:31 --> Model Class Initialized
INFO - 2017-12-26 20:36:31 --> Controller Class Initialized
INFO - 2017-12-26 20:36:31 --> Model Class Initialized
INFO - 2017-12-26 20:36:31 --> Model Class Initialized
INFO - 2017-12-26 20:36:31 --> Model Class Initialized
DEBUG - 2017-12-26 20:36:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:36:31 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-26 20:36:31 --> Final output sent to browser
DEBUG - 2017-12-26 20:36:31 --> Total execution time: 0.0968
INFO - 2017-12-26 20:36:31 --> Config Class Initialized
INFO - 2017-12-26 20:36:31 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:36:31 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:36:31 --> Utf8 Class Initialized
INFO - 2017-12-26 20:36:31 --> URI Class Initialized
INFO - 2017-12-26 20:36:31 --> Router Class Initialized
INFO - 2017-12-26 20:36:31 --> Output Class Initialized
INFO - 2017-12-26 20:36:31 --> Security Class Initialized
DEBUG - 2017-12-26 20:36:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:36:31 --> Input Class Initialized
INFO - 2017-12-26 20:36:31 --> Language Class Initialized
INFO - 2017-12-26 20:36:31 --> Loader Class Initialized
INFO - 2017-12-26 20:36:31 --> Helper loaded: url_helper
INFO - 2017-12-26 20:36:31 --> Helper loaded: form_helper
INFO - 2017-12-26 20:36:31 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:36:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:36:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:36:31 --> Form Validation Class Initialized
INFO - 2017-12-26 20:36:31 --> Model Class Initialized
INFO - 2017-12-26 20:36:31 --> Controller Class Initialized
INFO - 2017-12-26 20:36:31 --> Model Class Initialized
INFO - 2017-12-26 20:36:31 --> Model Class Initialized
INFO - 2017-12-26 20:36:31 --> Model Class Initialized
DEBUG - 2017-12-26 20:36:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:36:32 --> Config Class Initialized
INFO - 2017-12-26 20:36:32 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:36:32 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:36:32 --> Utf8 Class Initialized
INFO - 2017-12-26 20:36:32 --> URI Class Initialized
INFO - 2017-12-26 20:36:32 --> Router Class Initialized
INFO - 2017-12-26 20:36:32 --> Output Class Initialized
INFO - 2017-12-26 20:36:32 --> Security Class Initialized
DEBUG - 2017-12-26 20:36:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:36:32 --> Input Class Initialized
INFO - 2017-12-26 20:36:32 --> Language Class Initialized
INFO - 2017-12-26 20:36:32 --> Loader Class Initialized
INFO - 2017-12-26 20:36:32 --> Helper loaded: url_helper
INFO - 2017-12-26 20:36:32 --> Helper loaded: form_helper
INFO - 2017-12-26 20:36:32 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:36:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:36:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:36:32 --> Form Validation Class Initialized
INFO - 2017-12-26 20:36:32 --> Model Class Initialized
INFO - 2017-12-26 20:36:32 --> Controller Class Initialized
INFO - 2017-12-26 20:36:32 --> Model Class Initialized
INFO - 2017-12-26 20:36:32 --> Model Class Initialized
INFO - 2017-12-26 20:36:32 --> Model Class Initialized
DEBUG - 2017-12-26 20:36:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:36:32 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-26 20:36:32 --> Final output sent to browser
DEBUG - 2017-12-26 20:36:32 --> Total execution time: 0.0961
INFO - 2017-12-26 20:36:32 --> Config Class Initialized
INFO - 2017-12-26 20:36:32 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:36:32 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:36:32 --> Utf8 Class Initialized
INFO - 2017-12-26 20:36:32 --> URI Class Initialized
INFO - 2017-12-26 20:36:32 --> Router Class Initialized
INFO - 2017-12-26 20:36:32 --> Output Class Initialized
INFO - 2017-12-26 20:36:32 --> Security Class Initialized
DEBUG - 2017-12-26 20:36:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:36:32 --> Input Class Initialized
INFO - 2017-12-26 20:36:32 --> Language Class Initialized
INFO - 2017-12-26 20:36:32 --> Loader Class Initialized
INFO - 2017-12-26 20:36:32 --> Helper loaded: url_helper
INFO - 2017-12-26 20:36:32 --> Helper loaded: form_helper
INFO - 2017-12-26 20:36:32 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:36:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:36:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:36:32 --> Form Validation Class Initialized
INFO - 2017-12-26 20:36:32 --> Model Class Initialized
INFO - 2017-12-26 20:36:32 --> Controller Class Initialized
INFO - 2017-12-26 20:36:32 --> Model Class Initialized
INFO - 2017-12-26 20:36:32 --> Model Class Initialized
INFO - 2017-12-26 20:36:32 --> Model Class Initialized
DEBUG - 2017-12-26 20:36:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:36:51 --> Config Class Initialized
INFO - 2017-12-26 20:36:51 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:36:51 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:36:51 --> Utf8 Class Initialized
INFO - 2017-12-26 20:36:51 --> URI Class Initialized
INFO - 2017-12-26 20:36:51 --> Router Class Initialized
INFO - 2017-12-26 20:36:51 --> Output Class Initialized
INFO - 2017-12-26 20:36:51 --> Security Class Initialized
DEBUG - 2017-12-26 20:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:36:51 --> Input Class Initialized
INFO - 2017-12-26 20:36:51 --> Language Class Initialized
INFO - 2017-12-26 20:36:51 --> Loader Class Initialized
INFO - 2017-12-26 20:36:51 --> Helper loaded: url_helper
INFO - 2017-12-26 20:36:51 --> Helper loaded: form_helper
INFO - 2017-12-26 20:36:51 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:36:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:36:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:36:51 --> Form Validation Class Initialized
INFO - 2017-12-26 20:36:51 --> Model Class Initialized
INFO - 2017-12-26 20:36:51 --> Controller Class Initialized
INFO - 2017-12-26 20:36:51 --> Model Class Initialized
INFO - 2017-12-26 20:36:51 --> Model Class Initialized
INFO - 2017-12-26 20:36:51 --> Model Class Initialized
DEBUG - 2017-12-26 20:36:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:36:51 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-26 20:36:51 --> Final output sent to browser
DEBUG - 2017-12-26 20:36:51 --> Total execution time: 0.0570
INFO - 2017-12-26 20:36:51 --> Config Class Initialized
INFO - 2017-12-26 20:36:51 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:36:51 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:36:51 --> Utf8 Class Initialized
INFO - 2017-12-26 20:36:51 --> URI Class Initialized
INFO - 2017-12-26 20:36:51 --> Router Class Initialized
INFO - 2017-12-26 20:36:51 --> Output Class Initialized
INFO - 2017-12-26 20:36:51 --> Security Class Initialized
DEBUG - 2017-12-26 20:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:36:51 --> Input Class Initialized
INFO - 2017-12-26 20:36:51 --> Language Class Initialized
INFO - 2017-12-26 20:36:51 --> Loader Class Initialized
INFO - 2017-12-26 20:36:51 --> Helper loaded: url_helper
INFO - 2017-12-26 20:36:51 --> Helper loaded: form_helper
INFO - 2017-12-26 20:36:51 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:36:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:36:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:36:51 --> Form Validation Class Initialized
INFO - 2017-12-26 20:36:51 --> Model Class Initialized
INFO - 2017-12-26 20:36:51 --> Controller Class Initialized
INFO - 2017-12-26 20:36:51 --> Model Class Initialized
INFO - 2017-12-26 20:36:51 --> Model Class Initialized
INFO - 2017-12-26 20:36:51 --> Model Class Initialized
DEBUG - 2017-12-26 20:36:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:37:34 --> Config Class Initialized
INFO - 2017-12-26 20:37:34 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:37:34 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:37:34 --> Utf8 Class Initialized
INFO - 2017-12-26 20:37:34 --> URI Class Initialized
INFO - 2017-12-26 20:37:34 --> Router Class Initialized
INFO - 2017-12-26 20:37:34 --> Output Class Initialized
INFO - 2017-12-26 20:37:34 --> Security Class Initialized
DEBUG - 2017-12-26 20:37:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:37:34 --> Input Class Initialized
INFO - 2017-12-26 20:37:34 --> Language Class Initialized
INFO - 2017-12-26 20:37:34 --> Loader Class Initialized
INFO - 2017-12-26 20:37:34 --> Helper loaded: url_helper
INFO - 2017-12-26 20:37:34 --> Helper loaded: form_helper
INFO - 2017-12-26 20:37:34 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:37:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:37:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:37:34 --> Form Validation Class Initialized
INFO - 2017-12-26 20:37:34 --> Model Class Initialized
INFO - 2017-12-26 20:37:34 --> Controller Class Initialized
INFO - 2017-12-26 20:37:34 --> Model Class Initialized
INFO - 2017-12-26 20:37:34 --> Model Class Initialized
INFO - 2017-12-26 20:37:34 --> Model Class Initialized
DEBUG - 2017-12-26 20:37:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:37:34 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-26 20:37:34 --> Final output sent to browser
DEBUG - 2017-12-26 20:37:34 --> Total execution time: 0.0488
INFO - 2017-12-26 20:37:34 --> Config Class Initialized
INFO - 2017-12-26 20:37:34 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:37:34 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:37:34 --> Utf8 Class Initialized
INFO - 2017-12-26 20:37:34 --> URI Class Initialized
INFO - 2017-12-26 20:37:34 --> Router Class Initialized
INFO - 2017-12-26 20:37:34 --> Output Class Initialized
INFO - 2017-12-26 20:37:34 --> Security Class Initialized
DEBUG - 2017-12-26 20:37:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:37:34 --> Input Class Initialized
INFO - 2017-12-26 20:37:34 --> Language Class Initialized
INFO - 2017-12-26 20:37:34 --> Loader Class Initialized
INFO - 2017-12-26 20:37:34 --> Helper loaded: url_helper
INFO - 2017-12-26 20:37:34 --> Helper loaded: form_helper
INFO - 2017-12-26 20:37:34 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:37:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:37:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:37:34 --> Form Validation Class Initialized
INFO - 2017-12-26 20:37:34 --> Model Class Initialized
INFO - 2017-12-26 20:37:34 --> Controller Class Initialized
INFO - 2017-12-26 20:37:34 --> Model Class Initialized
INFO - 2017-12-26 20:37:34 --> Model Class Initialized
INFO - 2017-12-26 20:37:34 --> Model Class Initialized
DEBUG - 2017-12-26 20:37:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:37:34 --> Config Class Initialized
INFO - 2017-12-26 20:37:34 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:37:35 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:37:35 --> Utf8 Class Initialized
INFO - 2017-12-26 20:37:35 --> URI Class Initialized
INFO - 2017-12-26 20:37:35 --> Router Class Initialized
INFO - 2017-12-26 20:37:35 --> Output Class Initialized
INFO - 2017-12-26 20:37:35 --> Security Class Initialized
DEBUG - 2017-12-26 20:37:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:37:35 --> Input Class Initialized
INFO - 2017-12-26 20:37:35 --> Language Class Initialized
INFO - 2017-12-26 20:37:35 --> Loader Class Initialized
INFO - 2017-12-26 20:37:35 --> Helper loaded: url_helper
INFO - 2017-12-26 20:37:35 --> Helper loaded: form_helper
INFO - 2017-12-26 20:37:35 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:37:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:37:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:37:35 --> Form Validation Class Initialized
INFO - 2017-12-26 20:37:35 --> Model Class Initialized
INFO - 2017-12-26 20:37:35 --> Controller Class Initialized
INFO - 2017-12-26 20:37:35 --> Model Class Initialized
INFO - 2017-12-26 20:37:35 --> Model Class Initialized
INFO - 2017-12-26 20:37:35 --> Model Class Initialized
DEBUG - 2017-12-26 20:37:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:37:35 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-26 20:37:35 --> Final output sent to browser
DEBUG - 2017-12-26 20:37:35 --> Total execution time: 0.1122
INFO - 2017-12-26 20:37:36 --> Config Class Initialized
INFO - 2017-12-26 20:37:36 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:37:36 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:37:36 --> Utf8 Class Initialized
INFO - 2017-12-26 20:37:36 --> URI Class Initialized
INFO - 2017-12-26 20:37:36 --> Router Class Initialized
INFO - 2017-12-26 20:37:36 --> Output Class Initialized
INFO - 2017-12-26 20:37:36 --> Security Class Initialized
DEBUG - 2017-12-26 20:37:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:37:36 --> Input Class Initialized
INFO - 2017-12-26 20:37:36 --> Language Class Initialized
INFO - 2017-12-26 20:37:36 --> Loader Class Initialized
INFO - 2017-12-26 20:37:36 --> Helper loaded: url_helper
INFO - 2017-12-26 20:37:36 --> Helper loaded: form_helper
INFO - 2017-12-26 20:37:36 --> Database Driver Class Initialized
INFO - 2017-12-26 20:37:36 --> Config Class Initialized
INFO - 2017-12-26 20:37:36 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:37:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2017-12-26 20:37:36 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:37:36 --> Utf8 Class Initialized
INFO - 2017-12-26 20:37:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:37:36 --> URI Class Initialized
INFO - 2017-12-26 20:37:36 --> Form Validation Class Initialized
INFO - 2017-12-26 20:37:36 --> Router Class Initialized
INFO - 2017-12-26 20:37:36 --> Model Class Initialized
INFO - 2017-12-26 20:37:36 --> Controller Class Initialized
INFO - 2017-12-26 20:37:36 --> Output Class Initialized
INFO - 2017-12-26 20:37:36 --> Model Class Initialized
INFO - 2017-12-26 20:37:36 --> Model Class Initialized
INFO - 2017-12-26 20:37:36 --> Security Class Initialized
INFO - 2017-12-26 20:37:36 --> Model Class Initialized
DEBUG - 2017-12-26 20:37:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2017-12-26 20:37:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:37:36 --> Input Class Initialized
INFO - 2017-12-26 20:37:36 --> Language Class Initialized
ERROR - 2017-12-26 20:37:36 --> 404 Page Not Found: Faviconico/index
INFO - 2017-12-26 20:37:41 --> Config Class Initialized
INFO - 2017-12-26 20:37:41 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:37:41 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:37:41 --> Utf8 Class Initialized
INFO - 2017-12-26 20:37:41 --> URI Class Initialized
INFO - 2017-12-26 20:37:41 --> Router Class Initialized
INFO - 2017-12-26 20:37:41 --> Output Class Initialized
INFO - 2017-12-26 20:37:41 --> Security Class Initialized
DEBUG - 2017-12-26 20:37:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:37:41 --> Input Class Initialized
INFO - 2017-12-26 20:37:41 --> Language Class Initialized
INFO - 2017-12-26 20:37:41 --> Loader Class Initialized
INFO - 2017-12-26 20:37:41 --> Helper loaded: url_helper
INFO - 2017-12-26 20:37:41 --> Helper loaded: form_helper
INFO - 2017-12-26 20:37:41 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:37:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:37:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:37:41 --> Form Validation Class Initialized
INFO - 2017-12-26 20:37:41 --> Model Class Initialized
INFO - 2017-12-26 20:37:41 --> Controller Class Initialized
INFO - 2017-12-26 20:37:41 --> Model Class Initialized
INFO - 2017-12-26 20:37:41 --> Model Class Initialized
INFO - 2017-12-26 20:37:41 --> Model Class Initialized
DEBUG - 2017-12-26 20:37:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:37:41 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-26 20:37:41 --> Final output sent to browser
DEBUG - 2017-12-26 20:37:41 --> Total execution time: 0.0936
INFO - 2017-12-26 20:37:41 --> Config Class Initialized
INFO - 2017-12-26 20:37:41 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:37:41 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:37:41 --> Utf8 Class Initialized
INFO - 2017-12-26 20:37:41 --> URI Class Initialized
INFO - 2017-12-26 20:37:41 --> Router Class Initialized
INFO - 2017-12-26 20:37:41 --> Output Class Initialized
INFO - 2017-12-26 20:37:41 --> Security Class Initialized
DEBUG - 2017-12-26 20:37:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:37:41 --> Input Class Initialized
INFO - 2017-12-26 20:37:41 --> Language Class Initialized
INFO - 2017-12-26 20:37:41 --> Loader Class Initialized
INFO - 2017-12-26 20:37:41 --> Helper loaded: url_helper
INFO - 2017-12-26 20:37:41 --> Helper loaded: form_helper
INFO - 2017-12-26 20:37:41 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:37:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:37:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:37:41 --> Form Validation Class Initialized
INFO - 2017-12-26 20:37:41 --> Model Class Initialized
INFO - 2017-12-26 20:37:41 --> Controller Class Initialized
INFO - 2017-12-26 20:37:41 --> Model Class Initialized
INFO - 2017-12-26 20:37:41 --> Model Class Initialized
INFO - 2017-12-26 20:37:41 --> Model Class Initialized
DEBUG - 2017-12-26 20:37:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:38:26 --> Config Class Initialized
INFO - 2017-12-26 20:38:26 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:38:26 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:38:26 --> Utf8 Class Initialized
INFO - 2017-12-26 20:38:26 --> URI Class Initialized
INFO - 2017-12-26 20:38:26 --> Router Class Initialized
INFO - 2017-12-26 20:38:26 --> Output Class Initialized
INFO - 2017-12-26 20:38:26 --> Security Class Initialized
DEBUG - 2017-12-26 20:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:38:26 --> Input Class Initialized
INFO - 2017-12-26 20:38:26 --> Language Class Initialized
INFO - 2017-12-26 20:38:26 --> Loader Class Initialized
INFO - 2017-12-26 20:38:26 --> Helper loaded: url_helper
INFO - 2017-12-26 20:38:26 --> Helper loaded: form_helper
INFO - 2017-12-26 20:38:26 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:38:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:38:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:38:26 --> Form Validation Class Initialized
INFO - 2017-12-26 20:38:26 --> Model Class Initialized
INFO - 2017-12-26 20:38:26 --> Controller Class Initialized
INFO - 2017-12-26 20:38:26 --> Model Class Initialized
INFO - 2017-12-26 20:38:26 --> Model Class Initialized
INFO - 2017-12-26 20:38:26 --> Model Class Initialized
DEBUG - 2017-12-26 20:38:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:38:26 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-26 20:38:26 --> Final output sent to browser
DEBUG - 2017-12-26 20:38:26 --> Total execution time: 0.0753
INFO - 2017-12-26 20:38:26 --> Config Class Initialized
INFO - 2017-12-26 20:38:26 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:38:26 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:38:26 --> Utf8 Class Initialized
INFO - 2017-12-26 20:38:26 --> URI Class Initialized
INFO - 2017-12-26 20:38:26 --> Router Class Initialized
INFO - 2017-12-26 20:38:26 --> Output Class Initialized
INFO - 2017-12-26 20:38:26 --> Security Class Initialized
DEBUG - 2017-12-26 20:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:38:26 --> Input Class Initialized
INFO - 2017-12-26 20:38:26 --> Language Class Initialized
INFO - 2017-12-26 20:38:26 --> Loader Class Initialized
INFO - 2017-12-26 20:38:26 --> Helper loaded: url_helper
INFO - 2017-12-26 20:38:26 --> Helper loaded: form_helper
INFO - 2017-12-26 20:38:26 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:38:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:38:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:38:26 --> Form Validation Class Initialized
INFO - 2017-12-26 20:38:26 --> Model Class Initialized
INFO - 2017-12-26 20:38:26 --> Controller Class Initialized
INFO - 2017-12-26 20:38:26 --> Model Class Initialized
INFO - 2017-12-26 20:38:26 --> Model Class Initialized
INFO - 2017-12-26 20:38:26 --> Model Class Initialized
DEBUG - 2017-12-26 20:38:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:38:27 --> Config Class Initialized
INFO - 2017-12-26 20:38:27 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:38:27 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:38:27 --> Utf8 Class Initialized
INFO - 2017-12-26 20:38:27 --> URI Class Initialized
INFO - 2017-12-26 20:38:27 --> Router Class Initialized
INFO - 2017-12-26 20:38:27 --> Output Class Initialized
INFO - 2017-12-26 20:38:27 --> Security Class Initialized
DEBUG - 2017-12-26 20:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:38:27 --> Input Class Initialized
INFO - 2017-12-26 20:38:27 --> Language Class Initialized
INFO - 2017-12-26 20:38:27 --> Loader Class Initialized
INFO - 2017-12-26 20:38:27 --> Helper loaded: url_helper
INFO - 2017-12-26 20:38:27 --> Helper loaded: form_helper
INFO - 2017-12-26 20:38:27 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:38:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:38:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:38:27 --> Form Validation Class Initialized
INFO - 2017-12-26 20:38:27 --> Model Class Initialized
INFO - 2017-12-26 20:38:27 --> Controller Class Initialized
INFO - 2017-12-26 20:38:27 --> Model Class Initialized
INFO - 2017-12-26 20:38:27 --> Model Class Initialized
INFO - 2017-12-26 20:38:27 --> Model Class Initialized
DEBUG - 2017-12-26 20:38:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:38:27 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-26 20:38:27 --> Final output sent to browser
DEBUG - 2017-12-26 20:38:27 --> Total execution time: 0.0923
INFO - 2017-12-26 20:38:27 --> Config Class Initialized
INFO - 2017-12-26 20:38:27 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:38:27 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:38:27 --> Utf8 Class Initialized
INFO - 2017-12-26 20:38:27 --> URI Class Initialized
INFO - 2017-12-26 20:38:27 --> Router Class Initialized
INFO - 2017-12-26 20:38:27 --> Output Class Initialized
INFO - 2017-12-26 20:38:27 --> Security Class Initialized
DEBUG - 2017-12-26 20:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:38:27 --> Input Class Initialized
INFO - 2017-12-26 20:38:27 --> Language Class Initialized
INFO - 2017-12-26 20:38:27 --> Loader Class Initialized
INFO - 2017-12-26 20:38:27 --> Helper loaded: url_helper
INFO - 2017-12-26 20:38:27 --> Helper loaded: form_helper
INFO - 2017-12-26 20:38:27 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:38:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:38:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:38:27 --> Form Validation Class Initialized
INFO - 2017-12-26 20:38:27 --> Model Class Initialized
INFO - 2017-12-26 20:38:27 --> Controller Class Initialized
INFO - 2017-12-26 20:38:27 --> Model Class Initialized
INFO - 2017-12-26 20:38:27 --> Model Class Initialized
INFO - 2017-12-26 20:38:27 --> Model Class Initialized
DEBUG - 2017-12-26 20:38:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:38:27 --> Config Class Initialized
INFO - 2017-12-26 20:38:27 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:38:27 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:38:27 --> Utf8 Class Initialized
INFO - 2017-12-26 20:38:27 --> URI Class Initialized
INFO - 2017-12-26 20:38:27 --> Router Class Initialized
INFO - 2017-12-26 20:38:27 --> Output Class Initialized
INFO - 2017-12-26 20:38:27 --> Security Class Initialized
DEBUG - 2017-12-26 20:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:38:27 --> Input Class Initialized
INFO - 2017-12-26 20:38:27 --> Language Class Initialized
INFO - 2017-12-26 20:38:27 --> Loader Class Initialized
INFO - 2017-12-26 20:38:27 --> Helper loaded: url_helper
INFO - 2017-12-26 20:38:27 --> Helper loaded: form_helper
INFO - 2017-12-26 20:38:27 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:38:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:38:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:38:27 --> Form Validation Class Initialized
INFO - 2017-12-26 20:38:27 --> Model Class Initialized
INFO - 2017-12-26 20:38:27 --> Controller Class Initialized
INFO - 2017-12-26 20:38:27 --> Model Class Initialized
INFO - 2017-12-26 20:38:27 --> Model Class Initialized
INFO - 2017-12-26 20:38:27 --> Model Class Initialized
DEBUG - 2017-12-26 20:38:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:38:27 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-26 20:38:27 --> Final output sent to browser
DEBUG - 2017-12-26 20:38:27 --> Total execution time: 0.0939
INFO - 2017-12-26 20:38:27 --> Config Class Initialized
INFO - 2017-12-26 20:38:27 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:38:27 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:38:27 --> Utf8 Class Initialized
INFO - 2017-12-26 20:38:27 --> URI Class Initialized
INFO - 2017-12-26 20:38:27 --> Router Class Initialized
INFO - 2017-12-26 20:38:27 --> Output Class Initialized
INFO - 2017-12-26 20:38:27 --> Security Class Initialized
DEBUG - 2017-12-26 20:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:38:27 --> Input Class Initialized
INFO - 2017-12-26 20:38:27 --> Language Class Initialized
INFO - 2017-12-26 20:38:27 --> Loader Class Initialized
INFO - 2017-12-26 20:38:27 --> Helper loaded: url_helper
INFO - 2017-12-26 20:38:27 --> Helper loaded: form_helper
INFO - 2017-12-26 20:38:27 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:38:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:38:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:38:27 --> Form Validation Class Initialized
INFO - 2017-12-26 20:38:27 --> Model Class Initialized
INFO - 2017-12-26 20:38:27 --> Controller Class Initialized
INFO - 2017-12-26 20:38:27 --> Model Class Initialized
INFO - 2017-12-26 20:38:27 --> Model Class Initialized
INFO - 2017-12-26 20:38:27 --> Model Class Initialized
DEBUG - 2017-12-26 20:38:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:38:28 --> Config Class Initialized
INFO - 2017-12-26 20:38:28 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:38:28 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:38:28 --> Utf8 Class Initialized
INFO - 2017-12-26 20:38:28 --> URI Class Initialized
INFO - 2017-12-26 20:38:28 --> Router Class Initialized
INFO - 2017-12-26 20:38:28 --> Output Class Initialized
INFO - 2017-12-26 20:38:28 --> Security Class Initialized
DEBUG - 2017-12-26 20:38:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:38:28 --> Input Class Initialized
INFO - 2017-12-26 20:38:28 --> Language Class Initialized
INFO - 2017-12-26 20:38:28 --> Loader Class Initialized
INFO - 2017-12-26 20:38:28 --> Helper loaded: url_helper
INFO - 2017-12-26 20:38:28 --> Helper loaded: form_helper
INFO - 2017-12-26 20:38:28 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:38:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:38:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:38:28 --> Form Validation Class Initialized
INFO - 2017-12-26 20:38:28 --> Model Class Initialized
INFO - 2017-12-26 20:38:28 --> Controller Class Initialized
INFO - 2017-12-26 20:38:28 --> Model Class Initialized
INFO - 2017-12-26 20:38:28 --> Model Class Initialized
INFO - 2017-12-26 20:38:28 --> Model Class Initialized
DEBUG - 2017-12-26 20:38:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:38:28 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-26 20:38:28 --> Final output sent to browser
DEBUG - 2017-12-26 20:38:28 --> Total execution time: 0.0900
INFO - 2017-12-26 20:38:28 --> Config Class Initialized
INFO - 2017-12-26 20:38:28 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:38:28 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:38:28 --> Utf8 Class Initialized
INFO - 2017-12-26 20:38:28 --> URI Class Initialized
INFO - 2017-12-26 20:38:28 --> Router Class Initialized
INFO - 2017-12-26 20:38:28 --> Output Class Initialized
INFO - 2017-12-26 20:38:28 --> Security Class Initialized
DEBUG - 2017-12-26 20:38:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:38:28 --> Input Class Initialized
INFO - 2017-12-26 20:38:28 --> Language Class Initialized
INFO - 2017-12-26 20:38:28 --> Loader Class Initialized
INFO - 2017-12-26 20:38:28 --> Helper loaded: url_helper
INFO - 2017-12-26 20:38:28 --> Helper loaded: form_helper
INFO - 2017-12-26 20:38:28 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:38:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:38:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:38:28 --> Form Validation Class Initialized
INFO - 2017-12-26 20:38:28 --> Model Class Initialized
INFO - 2017-12-26 20:38:28 --> Controller Class Initialized
INFO - 2017-12-26 20:38:28 --> Model Class Initialized
INFO - 2017-12-26 20:38:28 --> Model Class Initialized
INFO - 2017-12-26 20:38:28 --> Model Class Initialized
DEBUG - 2017-12-26 20:38:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:38:29 --> Config Class Initialized
INFO - 2017-12-26 20:38:29 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:38:29 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:38:29 --> Utf8 Class Initialized
INFO - 2017-12-26 20:38:29 --> URI Class Initialized
INFO - 2017-12-26 20:38:29 --> Router Class Initialized
INFO - 2017-12-26 20:38:29 --> Output Class Initialized
INFO - 2017-12-26 20:38:29 --> Security Class Initialized
DEBUG - 2017-12-26 20:38:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:38:29 --> Input Class Initialized
INFO - 2017-12-26 20:38:29 --> Language Class Initialized
INFO - 2017-12-26 20:38:29 --> Loader Class Initialized
INFO - 2017-12-26 20:38:29 --> Helper loaded: url_helper
INFO - 2017-12-26 20:38:29 --> Helper loaded: form_helper
INFO - 2017-12-26 20:38:29 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:38:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:38:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:38:29 --> Form Validation Class Initialized
INFO - 2017-12-26 20:38:29 --> Model Class Initialized
INFO - 2017-12-26 20:38:29 --> Controller Class Initialized
INFO - 2017-12-26 20:38:29 --> Model Class Initialized
INFO - 2017-12-26 20:38:29 --> Model Class Initialized
INFO - 2017-12-26 20:38:29 --> Model Class Initialized
DEBUG - 2017-12-26 20:38:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:38:29 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-26 20:38:29 --> Final output sent to browser
DEBUG - 2017-12-26 20:38:29 --> Total execution time: 0.0931
INFO - 2017-12-26 20:38:29 --> Config Class Initialized
INFO - 2017-12-26 20:38:29 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:38:29 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:38:29 --> Utf8 Class Initialized
INFO - 2017-12-26 20:38:29 --> URI Class Initialized
INFO - 2017-12-26 20:38:29 --> Router Class Initialized
INFO - 2017-12-26 20:38:29 --> Output Class Initialized
INFO - 2017-12-26 20:38:29 --> Security Class Initialized
DEBUG - 2017-12-26 20:38:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:38:29 --> Input Class Initialized
INFO - 2017-12-26 20:38:29 --> Language Class Initialized
INFO - 2017-12-26 20:38:29 --> Loader Class Initialized
INFO - 2017-12-26 20:38:29 --> Helper loaded: url_helper
INFO - 2017-12-26 20:38:29 --> Helper loaded: form_helper
INFO - 2017-12-26 20:38:29 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:38:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:38:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:38:29 --> Form Validation Class Initialized
INFO - 2017-12-26 20:38:29 --> Model Class Initialized
INFO - 2017-12-26 20:38:29 --> Controller Class Initialized
INFO - 2017-12-26 20:38:29 --> Model Class Initialized
INFO - 2017-12-26 20:38:29 --> Model Class Initialized
INFO - 2017-12-26 20:38:29 --> Model Class Initialized
DEBUG - 2017-12-26 20:38:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:38:31 --> Config Class Initialized
INFO - 2017-12-26 20:38:31 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:38:31 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:38:31 --> Utf8 Class Initialized
INFO - 2017-12-26 20:38:31 --> URI Class Initialized
INFO - 2017-12-26 20:38:31 --> Router Class Initialized
INFO - 2017-12-26 20:38:31 --> Output Class Initialized
INFO - 2017-12-26 20:38:31 --> Security Class Initialized
DEBUG - 2017-12-26 20:38:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:38:31 --> Input Class Initialized
INFO - 2017-12-26 20:38:31 --> Language Class Initialized
INFO - 2017-12-26 20:38:31 --> Loader Class Initialized
INFO - 2017-12-26 20:38:31 --> Helper loaded: url_helper
INFO - 2017-12-26 20:38:31 --> Helper loaded: form_helper
INFO - 2017-12-26 20:38:31 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:38:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:38:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:38:31 --> Form Validation Class Initialized
INFO - 2017-12-26 20:38:31 --> Model Class Initialized
INFO - 2017-12-26 20:38:31 --> Controller Class Initialized
INFO - 2017-12-26 20:38:31 --> Model Class Initialized
INFO - 2017-12-26 20:38:31 --> Model Class Initialized
INFO - 2017-12-26 20:38:31 --> Model Class Initialized
DEBUG - 2017-12-26 20:38:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:38:31 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-26 20:38:31 --> Final output sent to browser
DEBUG - 2017-12-26 20:38:31 --> Total execution time: 0.0919
INFO - 2017-12-26 20:38:31 --> Config Class Initialized
INFO - 2017-12-26 20:38:31 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:38:31 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:38:31 --> Utf8 Class Initialized
INFO - 2017-12-26 20:38:31 --> URI Class Initialized
INFO - 2017-12-26 20:38:31 --> Router Class Initialized
INFO - 2017-12-26 20:38:31 --> Output Class Initialized
INFO - 2017-12-26 20:38:31 --> Security Class Initialized
DEBUG - 2017-12-26 20:38:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:38:31 --> Input Class Initialized
INFO - 2017-12-26 20:38:31 --> Language Class Initialized
INFO - 2017-12-26 20:38:31 --> Loader Class Initialized
INFO - 2017-12-26 20:38:31 --> Helper loaded: url_helper
INFO - 2017-12-26 20:38:31 --> Helper loaded: form_helper
INFO - 2017-12-26 20:38:31 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:38:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:38:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:38:31 --> Form Validation Class Initialized
INFO - 2017-12-26 20:38:31 --> Model Class Initialized
INFO - 2017-12-26 20:38:31 --> Controller Class Initialized
INFO - 2017-12-26 20:38:31 --> Model Class Initialized
INFO - 2017-12-26 20:38:31 --> Model Class Initialized
INFO - 2017-12-26 20:38:31 --> Model Class Initialized
DEBUG - 2017-12-26 20:38:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:38:52 --> Config Class Initialized
INFO - 2017-12-26 20:38:52 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:38:52 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:38:52 --> Utf8 Class Initialized
INFO - 2017-12-26 20:38:52 --> URI Class Initialized
INFO - 2017-12-26 20:38:52 --> Router Class Initialized
INFO - 2017-12-26 20:38:52 --> Output Class Initialized
INFO - 2017-12-26 20:38:52 --> Security Class Initialized
DEBUG - 2017-12-26 20:38:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:38:52 --> Input Class Initialized
INFO - 2017-12-26 20:38:52 --> Language Class Initialized
INFO - 2017-12-26 20:38:52 --> Loader Class Initialized
INFO - 2017-12-26 20:38:52 --> Helper loaded: url_helper
INFO - 2017-12-26 20:38:52 --> Helper loaded: form_helper
INFO - 2017-12-26 20:38:52 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:38:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:38:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:38:52 --> Form Validation Class Initialized
INFO - 2017-12-26 20:38:52 --> Model Class Initialized
INFO - 2017-12-26 20:38:52 --> Controller Class Initialized
INFO - 2017-12-26 20:38:52 --> Model Class Initialized
INFO - 2017-12-26 20:38:52 --> Model Class Initialized
INFO - 2017-12-26 20:38:52 --> Model Class Initialized
DEBUG - 2017-12-26 20:38:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:38:52 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-26 20:38:52 --> Final output sent to browser
DEBUG - 2017-12-26 20:38:52 --> Total execution time: 0.0943
INFO - 2017-12-26 20:38:54 --> Config Class Initialized
INFO - 2017-12-26 20:38:54 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:38:54 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:38:54 --> Utf8 Class Initialized
INFO - 2017-12-26 20:38:54 --> URI Class Initialized
INFO - 2017-12-26 20:38:54 --> Router Class Initialized
INFO - 2017-12-26 20:38:54 --> Output Class Initialized
INFO - 2017-12-26 20:38:54 --> Security Class Initialized
DEBUG - 2017-12-26 20:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:38:54 --> Input Class Initialized
INFO - 2017-12-26 20:38:54 --> Language Class Initialized
INFO - 2017-12-26 20:38:54 --> Loader Class Initialized
INFO - 2017-12-26 20:38:54 --> Helper loaded: url_helper
INFO - 2017-12-26 20:38:54 --> Helper loaded: form_helper
INFO - 2017-12-26 20:38:54 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:38:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:38:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:38:54 --> Config Class Initialized
INFO - 2017-12-26 20:38:54 --> Hooks Class Initialized
INFO - 2017-12-26 20:38:54 --> Form Validation Class Initialized
INFO - 2017-12-26 20:38:54 --> Model Class Initialized
INFO - 2017-12-26 20:38:54 --> Controller Class Initialized
DEBUG - 2017-12-26 20:38:54 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:38:54 --> Utf8 Class Initialized
INFO - 2017-12-26 20:38:54 --> Model Class Initialized
INFO - 2017-12-26 20:38:54 --> Model Class Initialized
INFO - 2017-12-26 20:38:54 --> URI Class Initialized
INFO - 2017-12-26 20:38:54 --> Model Class Initialized
DEBUG - 2017-12-26 20:38:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:38:54 --> Router Class Initialized
INFO - 2017-12-26 20:38:54 --> Output Class Initialized
INFO - 2017-12-26 20:38:54 --> Security Class Initialized
DEBUG - 2017-12-26 20:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:38:54 --> Input Class Initialized
INFO - 2017-12-26 20:38:54 --> Language Class Initialized
ERROR - 2017-12-26 20:38:54 --> 404 Page Not Found: Faviconico/index
INFO - 2017-12-26 20:39:10 --> Config Class Initialized
INFO - 2017-12-26 20:39:10 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:39:10 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:39:10 --> Utf8 Class Initialized
INFO - 2017-12-26 20:39:10 --> URI Class Initialized
INFO - 2017-12-26 20:39:10 --> Router Class Initialized
INFO - 2017-12-26 20:39:10 --> Output Class Initialized
INFO - 2017-12-26 20:39:10 --> Security Class Initialized
DEBUG - 2017-12-26 20:39:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:39:10 --> Input Class Initialized
INFO - 2017-12-26 20:39:10 --> Language Class Initialized
INFO - 2017-12-26 20:39:10 --> Loader Class Initialized
INFO - 2017-12-26 20:39:10 --> Helper loaded: url_helper
INFO - 2017-12-26 20:39:10 --> Helper loaded: form_helper
INFO - 2017-12-26 20:39:10 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:39:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:39:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:39:10 --> Form Validation Class Initialized
INFO - 2017-12-26 20:39:10 --> Model Class Initialized
INFO - 2017-12-26 20:39:10 --> Controller Class Initialized
INFO - 2017-12-26 20:39:10 --> Model Class Initialized
INFO - 2017-12-26 20:39:10 --> Model Class Initialized
INFO - 2017-12-26 20:39:10 --> Model Class Initialized
DEBUG - 2017-12-26 20:39:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:39:10 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-26 20:39:10 --> Final output sent to browser
DEBUG - 2017-12-26 20:39:10 --> Total execution time: 0.0746
INFO - 2017-12-26 20:39:11 --> Config Class Initialized
INFO - 2017-12-26 20:39:11 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:39:11 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:39:11 --> Utf8 Class Initialized
INFO - 2017-12-26 20:39:11 --> URI Class Initialized
INFO - 2017-12-26 20:39:11 --> Router Class Initialized
INFO - 2017-12-26 20:39:11 --> Output Class Initialized
INFO - 2017-12-26 20:39:11 --> Security Class Initialized
DEBUG - 2017-12-26 20:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:39:11 --> Input Class Initialized
INFO - 2017-12-26 20:39:11 --> Language Class Initialized
INFO - 2017-12-26 20:39:11 --> Loader Class Initialized
INFO - 2017-12-26 20:39:11 --> Helper loaded: url_helper
INFO - 2017-12-26 20:39:11 --> Helper loaded: form_helper
INFO - 2017-12-26 20:39:11 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:39:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:39:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:39:11 --> Form Validation Class Initialized
INFO - 2017-12-26 20:39:11 --> Model Class Initialized
INFO - 2017-12-26 20:39:11 --> Controller Class Initialized
INFO - 2017-12-26 20:39:11 --> Model Class Initialized
INFO - 2017-12-26 20:39:11 --> Model Class Initialized
INFO - 2017-12-26 20:39:11 --> Model Class Initialized
DEBUG - 2017-12-26 20:39:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:39:12 --> Config Class Initialized
INFO - 2017-12-26 20:39:12 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:39:12 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:39:12 --> Utf8 Class Initialized
INFO - 2017-12-26 20:39:12 --> URI Class Initialized
INFO - 2017-12-26 20:39:12 --> Router Class Initialized
INFO - 2017-12-26 20:39:12 --> Output Class Initialized
INFO - 2017-12-26 20:39:12 --> Security Class Initialized
DEBUG - 2017-12-26 20:39:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:39:12 --> Input Class Initialized
INFO - 2017-12-26 20:39:12 --> Language Class Initialized
INFO - 2017-12-26 20:39:12 --> Loader Class Initialized
INFO - 2017-12-26 20:39:12 --> Helper loaded: url_helper
INFO - 2017-12-26 20:39:12 --> Helper loaded: form_helper
INFO - 2017-12-26 20:39:12 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:39:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:39:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:39:12 --> Form Validation Class Initialized
INFO - 2017-12-26 20:39:12 --> Model Class Initialized
INFO - 2017-12-26 20:39:12 --> Controller Class Initialized
INFO - 2017-12-26 20:39:12 --> Model Class Initialized
INFO - 2017-12-26 20:39:12 --> Model Class Initialized
INFO - 2017-12-26 20:39:12 --> Model Class Initialized
DEBUG - 2017-12-26 20:39:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:39:12 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-26 20:39:12 --> Final output sent to browser
DEBUG - 2017-12-26 20:39:12 --> Total execution time: 0.0526
INFO - 2017-12-26 20:39:12 --> Config Class Initialized
INFO - 2017-12-26 20:39:12 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:39:12 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:39:12 --> Utf8 Class Initialized
INFO - 2017-12-26 20:39:12 --> URI Class Initialized
INFO - 2017-12-26 20:39:12 --> Router Class Initialized
INFO - 2017-12-26 20:39:12 --> Output Class Initialized
INFO - 2017-12-26 20:39:12 --> Security Class Initialized
DEBUG - 2017-12-26 20:39:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:39:12 --> Input Class Initialized
INFO - 2017-12-26 20:39:12 --> Language Class Initialized
INFO - 2017-12-26 20:39:12 --> Loader Class Initialized
INFO - 2017-12-26 20:39:12 --> Helper loaded: url_helper
INFO - 2017-12-26 20:39:12 --> Helper loaded: form_helper
INFO - 2017-12-26 20:39:12 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:39:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:39:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:39:12 --> Form Validation Class Initialized
INFO - 2017-12-26 20:39:12 --> Model Class Initialized
INFO - 2017-12-26 20:39:12 --> Controller Class Initialized
INFO - 2017-12-26 20:39:12 --> Model Class Initialized
INFO - 2017-12-26 20:39:12 --> Model Class Initialized
INFO - 2017-12-26 20:39:12 --> Model Class Initialized
DEBUG - 2017-12-26 20:39:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:39:14 --> Config Class Initialized
INFO - 2017-12-26 20:39:14 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:39:14 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:39:14 --> Utf8 Class Initialized
INFO - 2017-12-26 20:39:14 --> URI Class Initialized
INFO - 2017-12-26 20:39:14 --> Router Class Initialized
INFO - 2017-12-26 20:39:14 --> Output Class Initialized
INFO - 2017-12-26 20:39:14 --> Security Class Initialized
DEBUG - 2017-12-26 20:39:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:39:14 --> Input Class Initialized
INFO - 2017-12-26 20:39:14 --> Language Class Initialized
INFO - 2017-12-26 20:39:14 --> Loader Class Initialized
INFO - 2017-12-26 20:39:14 --> Helper loaded: url_helper
INFO - 2017-12-26 20:39:14 --> Helper loaded: form_helper
INFO - 2017-12-26 20:39:14 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:39:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:39:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:39:14 --> Form Validation Class Initialized
INFO - 2017-12-26 20:39:14 --> Model Class Initialized
INFO - 2017-12-26 20:39:14 --> Controller Class Initialized
INFO - 2017-12-26 20:39:14 --> Model Class Initialized
INFO - 2017-12-26 20:39:14 --> Model Class Initialized
INFO - 2017-12-26 20:39:14 --> Model Class Initialized
DEBUG - 2017-12-26 20:39:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:39:14 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-26 20:39:14 --> Final output sent to browser
DEBUG - 2017-12-26 20:39:14 --> Total execution time: 0.0638
INFO - 2017-12-26 20:39:14 --> Config Class Initialized
INFO - 2017-12-26 20:39:14 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:39:14 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:39:14 --> Utf8 Class Initialized
INFO - 2017-12-26 20:39:14 --> URI Class Initialized
INFO - 2017-12-26 20:39:14 --> Router Class Initialized
INFO - 2017-12-26 20:39:14 --> Output Class Initialized
INFO - 2017-12-26 20:39:14 --> Security Class Initialized
DEBUG - 2017-12-26 20:39:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:39:14 --> Input Class Initialized
INFO - 2017-12-26 20:39:14 --> Language Class Initialized
INFO - 2017-12-26 20:39:14 --> Loader Class Initialized
INFO - 2017-12-26 20:39:14 --> Helper loaded: url_helper
INFO - 2017-12-26 20:39:14 --> Helper loaded: form_helper
INFO - 2017-12-26 20:39:14 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:39:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:39:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:39:14 --> Form Validation Class Initialized
INFO - 2017-12-26 20:39:14 --> Model Class Initialized
INFO - 2017-12-26 20:39:14 --> Controller Class Initialized
INFO - 2017-12-26 20:39:14 --> Model Class Initialized
INFO - 2017-12-26 20:39:14 --> Model Class Initialized
INFO - 2017-12-26 20:39:14 --> Model Class Initialized
DEBUG - 2017-12-26 20:39:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:39:17 --> Config Class Initialized
INFO - 2017-12-26 20:39:17 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:39:17 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:39:17 --> Utf8 Class Initialized
INFO - 2017-12-26 20:39:17 --> URI Class Initialized
INFO - 2017-12-26 20:39:17 --> Router Class Initialized
INFO - 2017-12-26 20:39:17 --> Output Class Initialized
INFO - 2017-12-26 20:39:18 --> Security Class Initialized
DEBUG - 2017-12-26 20:39:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:39:18 --> Input Class Initialized
INFO - 2017-12-26 20:39:18 --> Language Class Initialized
INFO - 2017-12-26 20:39:18 --> Loader Class Initialized
INFO - 2017-12-26 20:39:18 --> Helper loaded: url_helper
INFO - 2017-12-26 20:39:18 --> Helper loaded: form_helper
INFO - 2017-12-26 20:39:18 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:39:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:39:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:39:18 --> Form Validation Class Initialized
INFO - 2017-12-26 20:39:18 --> Model Class Initialized
INFO - 2017-12-26 20:39:18 --> Controller Class Initialized
INFO - 2017-12-26 20:39:18 --> Model Class Initialized
INFO - 2017-12-26 20:39:18 --> Model Class Initialized
INFO - 2017-12-26 20:39:18 --> Model Class Initialized
DEBUG - 2017-12-26 20:39:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:39:18 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-26 20:39:18 --> Final output sent to browser
DEBUG - 2017-12-26 20:39:18 --> Total execution time: 0.0670
INFO - 2017-12-26 20:39:18 --> Config Class Initialized
INFO - 2017-12-26 20:39:18 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:39:18 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:39:18 --> Utf8 Class Initialized
INFO - 2017-12-26 20:39:18 --> URI Class Initialized
INFO - 2017-12-26 20:39:18 --> Router Class Initialized
INFO - 2017-12-26 20:39:18 --> Output Class Initialized
INFO - 2017-12-26 20:39:18 --> Security Class Initialized
DEBUG - 2017-12-26 20:39:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:39:18 --> Input Class Initialized
INFO - 2017-12-26 20:39:18 --> Language Class Initialized
INFO - 2017-12-26 20:39:18 --> Loader Class Initialized
INFO - 2017-12-26 20:39:18 --> Helper loaded: url_helper
INFO - 2017-12-26 20:39:18 --> Helper loaded: form_helper
INFO - 2017-12-26 20:39:18 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:39:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:39:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:39:18 --> Form Validation Class Initialized
INFO - 2017-12-26 20:39:18 --> Model Class Initialized
INFO - 2017-12-26 20:39:18 --> Controller Class Initialized
INFO - 2017-12-26 20:39:18 --> Model Class Initialized
INFO - 2017-12-26 20:39:18 --> Model Class Initialized
INFO - 2017-12-26 20:39:18 --> Model Class Initialized
DEBUG - 2017-12-26 20:39:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:39:19 --> Config Class Initialized
INFO - 2017-12-26 20:39:19 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:39:19 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:39:19 --> Utf8 Class Initialized
INFO - 2017-12-26 20:39:19 --> URI Class Initialized
INFO - 2017-12-26 20:39:19 --> Router Class Initialized
INFO - 2017-12-26 20:39:19 --> Output Class Initialized
INFO - 2017-12-26 20:39:19 --> Security Class Initialized
DEBUG - 2017-12-26 20:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:39:19 --> Input Class Initialized
INFO - 2017-12-26 20:39:19 --> Language Class Initialized
INFO - 2017-12-26 20:39:19 --> Loader Class Initialized
INFO - 2017-12-26 20:39:19 --> Helper loaded: url_helper
INFO - 2017-12-26 20:39:19 --> Helper loaded: form_helper
INFO - 2017-12-26 20:39:19 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:39:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:39:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:39:19 --> Form Validation Class Initialized
INFO - 2017-12-26 20:39:19 --> Model Class Initialized
INFO - 2017-12-26 20:39:19 --> Controller Class Initialized
INFO - 2017-12-26 20:39:19 --> Model Class Initialized
INFO - 2017-12-26 20:39:19 --> Model Class Initialized
INFO - 2017-12-26 20:39:19 --> Model Class Initialized
DEBUG - 2017-12-26 20:39:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:39:19 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-26 20:39:19 --> Final output sent to browser
DEBUG - 2017-12-26 20:39:19 --> Total execution time: 0.0630
INFO - 2017-12-26 20:39:19 --> Config Class Initialized
INFO - 2017-12-26 20:39:19 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:39:19 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:39:19 --> Utf8 Class Initialized
INFO - 2017-12-26 20:39:19 --> URI Class Initialized
INFO - 2017-12-26 20:39:19 --> Router Class Initialized
INFO - 2017-12-26 20:39:19 --> Output Class Initialized
INFO - 2017-12-26 20:39:19 --> Security Class Initialized
DEBUG - 2017-12-26 20:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:39:19 --> Input Class Initialized
INFO - 2017-12-26 20:39:19 --> Language Class Initialized
INFO - 2017-12-26 20:39:19 --> Loader Class Initialized
INFO - 2017-12-26 20:39:19 --> Helper loaded: url_helper
INFO - 2017-12-26 20:39:19 --> Helper loaded: form_helper
INFO - 2017-12-26 20:39:19 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:39:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:39:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:39:19 --> Form Validation Class Initialized
INFO - 2017-12-26 20:39:19 --> Model Class Initialized
INFO - 2017-12-26 20:39:19 --> Controller Class Initialized
INFO - 2017-12-26 20:39:19 --> Model Class Initialized
INFO - 2017-12-26 20:39:19 --> Model Class Initialized
INFO - 2017-12-26 20:39:19 --> Model Class Initialized
DEBUG - 2017-12-26 20:39:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:39:20 --> Config Class Initialized
INFO - 2017-12-26 20:39:20 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:39:20 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:39:20 --> Utf8 Class Initialized
INFO - 2017-12-26 20:39:20 --> URI Class Initialized
INFO - 2017-12-26 20:39:20 --> Router Class Initialized
INFO - 2017-12-26 20:39:20 --> Output Class Initialized
INFO - 2017-12-26 20:39:20 --> Security Class Initialized
DEBUG - 2017-12-26 20:39:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:39:20 --> Input Class Initialized
INFO - 2017-12-26 20:39:20 --> Language Class Initialized
INFO - 2017-12-26 20:39:20 --> Loader Class Initialized
INFO - 2017-12-26 20:39:20 --> Helper loaded: url_helper
INFO - 2017-12-26 20:39:20 --> Helper loaded: form_helper
INFO - 2017-12-26 20:39:20 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:39:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:39:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:39:20 --> Form Validation Class Initialized
INFO - 2017-12-26 20:39:20 --> Model Class Initialized
INFO - 2017-12-26 20:39:20 --> Controller Class Initialized
INFO - 2017-12-26 20:39:20 --> Model Class Initialized
INFO - 2017-12-26 20:39:20 --> Model Class Initialized
INFO - 2017-12-26 20:39:20 --> Model Class Initialized
DEBUG - 2017-12-26 20:39:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:39:20 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-26 20:39:20 --> Final output sent to browser
DEBUG - 2017-12-26 20:39:20 --> Total execution time: 0.0568
INFO - 2017-12-26 20:39:20 --> Config Class Initialized
INFO - 2017-12-26 20:39:20 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:39:20 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:39:20 --> Utf8 Class Initialized
INFO - 2017-12-26 20:39:20 --> URI Class Initialized
INFO - 2017-12-26 20:39:20 --> Router Class Initialized
INFO - 2017-12-26 20:39:20 --> Output Class Initialized
INFO - 2017-12-26 20:39:20 --> Security Class Initialized
DEBUG - 2017-12-26 20:39:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:39:20 --> Input Class Initialized
INFO - 2017-12-26 20:39:20 --> Language Class Initialized
INFO - 2017-12-26 20:39:20 --> Loader Class Initialized
INFO - 2017-12-26 20:39:20 --> Helper loaded: url_helper
INFO - 2017-12-26 20:39:20 --> Helper loaded: form_helper
INFO - 2017-12-26 20:39:21 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:39:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:39:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:39:21 --> Form Validation Class Initialized
INFO - 2017-12-26 20:39:21 --> Model Class Initialized
INFO - 2017-12-26 20:39:21 --> Controller Class Initialized
INFO - 2017-12-26 20:39:21 --> Model Class Initialized
INFO - 2017-12-26 20:39:21 --> Model Class Initialized
INFO - 2017-12-26 20:39:21 --> Model Class Initialized
DEBUG - 2017-12-26 20:39:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:39:22 --> Config Class Initialized
INFO - 2017-12-26 20:39:22 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:39:22 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:39:22 --> Utf8 Class Initialized
INFO - 2017-12-26 20:39:22 --> URI Class Initialized
INFO - 2017-12-26 20:39:22 --> Router Class Initialized
INFO - 2017-12-26 20:39:22 --> Output Class Initialized
INFO - 2017-12-26 20:39:22 --> Security Class Initialized
DEBUG - 2017-12-26 20:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:39:22 --> Input Class Initialized
INFO - 2017-12-26 20:39:22 --> Language Class Initialized
INFO - 2017-12-26 20:39:22 --> Loader Class Initialized
INFO - 2017-12-26 20:39:22 --> Helper loaded: url_helper
INFO - 2017-12-26 20:39:22 --> Helper loaded: form_helper
INFO - 2017-12-26 20:39:22 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:39:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:39:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:39:22 --> Form Validation Class Initialized
INFO - 2017-12-26 20:39:22 --> Model Class Initialized
INFO - 2017-12-26 20:39:22 --> Controller Class Initialized
INFO - 2017-12-26 20:39:22 --> Model Class Initialized
INFO - 2017-12-26 20:39:22 --> Model Class Initialized
INFO - 2017-12-26 20:39:22 --> Model Class Initialized
DEBUG - 2017-12-26 20:39:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:39:22 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-26 20:39:22 --> Final output sent to browser
DEBUG - 2017-12-26 20:39:22 --> Total execution time: 0.0579
INFO - 2017-12-26 20:39:22 --> Config Class Initialized
INFO - 2017-12-26 20:39:22 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:39:22 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:39:22 --> Utf8 Class Initialized
INFO - 2017-12-26 20:39:22 --> URI Class Initialized
INFO - 2017-12-26 20:39:22 --> Router Class Initialized
INFO - 2017-12-26 20:39:22 --> Output Class Initialized
INFO - 2017-12-26 20:39:22 --> Security Class Initialized
DEBUG - 2017-12-26 20:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:39:22 --> Input Class Initialized
INFO - 2017-12-26 20:39:22 --> Language Class Initialized
INFO - 2017-12-26 20:39:22 --> Loader Class Initialized
INFO - 2017-12-26 20:39:22 --> Helper loaded: url_helper
INFO - 2017-12-26 20:39:22 --> Helper loaded: form_helper
INFO - 2017-12-26 20:39:22 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:39:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:39:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:39:22 --> Form Validation Class Initialized
INFO - 2017-12-26 20:39:22 --> Model Class Initialized
INFO - 2017-12-26 20:39:22 --> Controller Class Initialized
INFO - 2017-12-26 20:39:22 --> Model Class Initialized
INFO - 2017-12-26 20:39:22 --> Model Class Initialized
INFO - 2017-12-26 20:39:22 --> Model Class Initialized
DEBUG - 2017-12-26 20:39:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:39:37 --> Config Class Initialized
INFO - 2017-12-26 20:39:37 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:39:37 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:39:37 --> Utf8 Class Initialized
INFO - 2017-12-26 20:39:37 --> URI Class Initialized
INFO - 2017-12-26 20:39:37 --> Router Class Initialized
INFO - 2017-12-26 20:39:37 --> Output Class Initialized
INFO - 2017-12-26 20:39:37 --> Security Class Initialized
DEBUG - 2017-12-26 20:39:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:39:37 --> Input Class Initialized
INFO - 2017-12-26 20:39:37 --> Language Class Initialized
INFO - 2017-12-26 20:39:37 --> Loader Class Initialized
INFO - 2017-12-26 20:39:37 --> Helper loaded: url_helper
INFO - 2017-12-26 20:39:37 --> Helper loaded: form_helper
INFO - 2017-12-26 20:39:37 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:39:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:39:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:39:37 --> Form Validation Class Initialized
INFO - 2017-12-26 20:39:37 --> Model Class Initialized
INFO - 2017-12-26 20:39:37 --> Controller Class Initialized
INFO - 2017-12-26 20:39:37 --> Model Class Initialized
INFO - 2017-12-26 20:39:37 --> Model Class Initialized
INFO - 2017-12-26 20:39:37 --> Model Class Initialized
DEBUG - 2017-12-26 20:39:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:39:37 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-26 20:39:37 --> Final output sent to browser
DEBUG - 2017-12-26 20:39:37 --> Total execution time: 0.1235
INFO - 2017-12-26 20:39:39 --> Config Class Initialized
INFO - 2017-12-26 20:39:39 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:39:39 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:39:39 --> Utf8 Class Initialized
INFO - 2017-12-26 20:39:39 --> URI Class Initialized
INFO - 2017-12-26 20:39:39 --> Router Class Initialized
INFO - 2017-12-26 20:39:39 --> Output Class Initialized
INFO - 2017-12-26 20:39:39 --> Security Class Initialized
DEBUG - 2017-12-26 20:39:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:39:39 --> Input Class Initialized
INFO - 2017-12-26 20:39:39 --> Language Class Initialized
INFO - 2017-12-26 20:39:39 --> Loader Class Initialized
INFO - 2017-12-26 20:39:39 --> Helper loaded: url_helper
INFO - 2017-12-26 20:39:39 --> Helper loaded: form_helper
INFO - 2017-12-26 20:39:39 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:39:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:39:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:39:39 --> Form Validation Class Initialized
INFO - 2017-12-26 20:39:39 --> Model Class Initialized
INFO - 2017-12-26 20:39:39 --> Controller Class Initialized
INFO - 2017-12-26 20:39:39 --> Model Class Initialized
INFO - 2017-12-26 20:39:39 --> Model Class Initialized
INFO - 2017-12-26 20:39:39 --> Model Class Initialized
DEBUG - 2017-12-26 20:39:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:39:40 --> Config Class Initialized
INFO - 2017-12-26 20:39:40 --> Hooks Class Initialized
INFO - 2017-12-26 20:39:40 --> Config Class Initialized
INFO - 2017-12-26 20:39:40 --> Hooks Class Initialized
INFO - 2017-12-26 20:39:40 --> Config Class Initialized
INFO - 2017-12-26 20:39:40 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:39:40 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:39:40 --> Utf8 Class Initialized
DEBUG - 2017-12-26 20:39:40 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:39:40 --> Utf8 Class Initialized
INFO - 2017-12-26 20:39:40 --> URI Class Initialized
INFO - 2017-12-26 20:39:40 --> URI Class Initialized
DEBUG - 2017-12-26 20:39:40 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:39:40 --> Utf8 Class Initialized
INFO - 2017-12-26 20:39:40 --> Router Class Initialized
INFO - 2017-12-26 20:39:40 --> Router Class Initialized
INFO - 2017-12-26 20:39:40 --> URI Class Initialized
INFO - 2017-12-26 20:39:40 --> Output Class Initialized
INFO - 2017-12-26 20:39:40 --> Router Class Initialized
INFO - 2017-12-26 20:39:40 --> Output Class Initialized
INFO - 2017-12-26 20:39:40 --> Security Class Initialized
INFO - 2017-12-26 20:39:40 --> Security Class Initialized
INFO - 2017-12-26 20:39:40 --> Output Class Initialized
DEBUG - 2017-12-26 20:39:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:39:40 --> Input Class Initialized
DEBUG - 2017-12-26 20:39:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:39:40 --> Input Class Initialized
INFO - 2017-12-26 20:39:40 --> Security Class Initialized
INFO - 2017-12-26 20:39:40 --> Language Class Initialized
INFO - 2017-12-26 20:39:40 --> Language Class Initialized
DEBUG - 2017-12-26 20:39:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:39:40 --> Input Class Initialized
ERROR - 2017-12-26 20:39:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-12-26 20:39:40 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-26 20:39:40 --> Language Class Initialized
ERROR - 2017-12-26 20:39:40 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-26 20:39:54 --> Config Class Initialized
INFO - 2017-12-26 20:39:54 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:39:54 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:39:54 --> Utf8 Class Initialized
INFO - 2017-12-26 20:39:54 --> URI Class Initialized
INFO - 2017-12-26 20:39:54 --> Router Class Initialized
INFO - 2017-12-26 20:39:54 --> Output Class Initialized
INFO - 2017-12-26 20:39:54 --> Security Class Initialized
DEBUG - 2017-12-26 20:39:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:39:54 --> Input Class Initialized
INFO - 2017-12-26 20:39:54 --> Language Class Initialized
INFO - 2017-12-26 20:39:54 --> Loader Class Initialized
INFO - 2017-12-26 20:39:54 --> Helper loaded: url_helper
INFO - 2017-12-26 20:39:54 --> Helper loaded: form_helper
INFO - 2017-12-26 20:39:54 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:39:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:39:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:39:54 --> Form Validation Class Initialized
INFO - 2017-12-26 20:39:54 --> Model Class Initialized
INFO - 2017-12-26 20:39:54 --> Controller Class Initialized
INFO - 2017-12-26 20:39:54 --> Model Class Initialized
INFO - 2017-12-26 20:39:54 --> Model Class Initialized
INFO - 2017-12-26 20:39:54 --> Model Class Initialized
DEBUG - 2017-12-26 20:39:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:39:54 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-26 20:39:54 --> Final output sent to browser
DEBUG - 2017-12-26 20:39:54 --> Total execution time: 0.0900
INFO - 2017-12-26 20:39:55 --> Config Class Initialized
INFO - 2017-12-26 20:39:55 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:39:55 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:39:55 --> Utf8 Class Initialized
INFO - 2017-12-26 20:39:55 --> URI Class Initialized
INFO - 2017-12-26 20:39:55 --> Router Class Initialized
INFO - 2017-12-26 20:39:55 --> Output Class Initialized
INFO - 2017-12-26 20:39:55 --> Security Class Initialized
DEBUG - 2017-12-26 20:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:39:55 --> Input Class Initialized
INFO - 2017-12-26 20:39:55 --> Language Class Initialized
ERROR - 2017-12-26 20:39:55 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-26 20:39:55 --> Config Class Initialized
INFO - 2017-12-26 20:39:55 --> Hooks Class Initialized
INFO - 2017-12-26 20:39:55 --> Config Class Initialized
INFO - 2017-12-26 20:39:55 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:39:55 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:39:55 --> Utf8 Class Initialized
INFO - 2017-12-26 20:39:55 --> URI Class Initialized
DEBUG - 2017-12-26 20:39:55 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:39:55 --> Utf8 Class Initialized
INFO - 2017-12-26 20:39:55 --> Router Class Initialized
INFO - 2017-12-26 20:39:55 --> URI Class Initialized
INFO - 2017-12-26 20:39:55 --> Router Class Initialized
INFO - 2017-12-26 20:39:55 --> Output Class Initialized
INFO - 2017-12-26 20:39:55 --> Output Class Initialized
INFO - 2017-12-26 20:39:55 --> Security Class Initialized
INFO - 2017-12-26 20:39:55 --> Security Class Initialized
DEBUG - 2017-12-26 20:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:39:55 --> Input Class Initialized
DEBUG - 2017-12-26 20:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:39:55 --> Input Class Initialized
INFO - 2017-12-26 20:39:55 --> Language Class Initialized
INFO - 2017-12-26 20:39:55 --> Language Class Initialized
ERROR - 2017-12-26 20:39:55 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-26 20:39:55 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-26 20:39:55 --> Config Class Initialized
INFO - 2017-12-26 20:39:55 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:39:55 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:39:55 --> Utf8 Class Initialized
INFO - 2017-12-26 20:39:55 --> URI Class Initialized
INFO - 2017-12-26 20:39:55 --> Router Class Initialized
INFO - 2017-12-26 20:39:55 --> Output Class Initialized
INFO - 2017-12-26 20:39:55 --> Security Class Initialized
DEBUG - 2017-12-26 20:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:39:55 --> Input Class Initialized
INFO - 2017-12-26 20:39:55 --> Language Class Initialized
INFO - 2017-12-26 20:39:55 --> Loader Class Initialized
INFO - 2017-12-26 20:39:55 --> Helper loaded: url_helper
INFO - 2017-12-26 20:39:55 --> Helper loaded: form_helper
INFO - 2017-12-26 20:39:55 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:39:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:39:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:39:55 --> Form Validation Class Initialized
INFO - 2017-12-26 20:39:55 --> Model Class Initialized
INFO - 2017-12-26 20:39:55 --> Controller Class Initialized
INFO - 2017-12-26 20:39:55 --> Model Class Initialized
INFO - 2017-12-26 20:39:55 --> Model Class Initialized
INFO - 2017-12-26 20:39:55 --> Model Class Initialized
DEBUG - 2017-12-26 20:39:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:40:10 --> Config Class Initialized
INFO - 2017-12-26 20:40:10 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:40:10 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:40:10 --> Utf8 Class Initialized
INFO - 2017-12-26 20:40:10 --> URI Class Initialized
INFO - 2017-12-26 20:40:10 --> Router Class Initialized
INFO - 2017-12-26 20:40:10 --> Output Class Initialized
INFO - 2017-12-26 20:40:10 --> Security Class Initialized
DEBUG - 2017-12-26 20:40:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:40:10 --> Input Class Initialized
INFO - 2017-12-26 20:40:10 --> Language Class Initialized
INFO - 2017-12-26 20:40:10 --> Loader Class Initialized
INFO - 2017-12-26 20:40:10 --> Helper loaded: url_helper
INFO - 2017-12-26 20:40:10 --> Helper loaded: form_helper
INFO - 2017-12-26 20:40:10 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:40:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:40:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:40:10 --> Form Validation Class Initialized
INFO - 2017-12-26 20:40:10 --> Model Class Initialized
INFO - 2017-12-26 20:40:10 --> Controller Class Initialized
INFO - 2017-12-26 20:40:10 --> Model Class Initialized
INFO - 2017-12-26 20:40:10 --> Model Class Initialized
INFO - 2017-12-26 20:40:10 --> Model Class Initialized
DEBUG - 2017-12-26 20:40:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:40:11 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-26 20:40:11 --> Final output sent to browser
DEBUG - 2017-12-26 20:40:11 --> Total execution time: 0.0597
INFO - 2017-12-26 20:40:11 --> Config Class Initialized
INFO - 2017-12-26 20:40:11 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:40:11 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:40:11 --> Utf8 Class Initialized
INFO - 2017-12-26 20:40:11 --> URI Class Initialized
INFO - 2017-12-26 20:40:11 --> Router Class Initialized
INFO - 2017-12-26 20:40:11 --> Output Class Initialized
INFO - 2017-12-26 20:40:11 --> Security Class Initialized
DEBUG - 2017-12-26 20:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:40:11 --> Input Class Initialized
INFO - 2017-12-26 20:40:11 --> Language Class Initialized
ERROR - 2017-12-26 20:40:11 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-26 20:40:11 --> Config Class Initialized
INFO - 2017-12-26 20:40:11 --> Hooks Class Initialized
INFO - 2017-12-26 20:40:11 --> Config Class Initialized
INFO - 2017-12-26 20:40:11 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:40:11 --> UTF-8 Support Enabled
DEBUG - 2017-12-26 20:40:11 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:40:11 --> Utf8 Class Initialized
INFO - 2017-12-26 20:40:11 --> Utf8 Class Initialized
INFO - 2017-12-26 20:40:11 --> URI Class Initialized
INFO - 2017-12-26 20:40:11 --> URI Class Initialized
INFO - 2017-12-26 20:40:11 --> Router Class Initialized
INFO - 2017-12-26 20:40:11 --> Router Class Initialized
INFO - 2017-12-26 20:40:11 --> Output Class Initialized
INFO - 2017-12-26 20:40:11 --> Output Class Initialized
INFO - 2017-12-26 20:40:11 --> Security Class Initialized
INFO - 2017-12-26 20:40:11 --> Security Class Initialized
DEBUG - 2017-12-26 20:40:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-26 20:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:40:11 --> Input Class Initialized
INFO - 2017-12-26 20:40:11 --> Input Class Initialized
INFO - 2017-12-26 20:40:11 --> Language Class Initialized
INFO - 2017-12-26 20:40:11 --> Language Class Initialized
ERROR - 2017-12-26 20:40:11 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-26 20:40:11 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-26 20:40:11 --> Config Class Initialized
INFO - 2017-12-26 20:40:11 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:40:11 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:40:11 --> Utf8 Class Initialized
INFO - 2017-12-26 20:40:11 --> URI Class Initialized
INFO - 2017-12-26 20:40:11 --> Router Class Initialized
INFO - 2017-12-26 20:40:11 --> Output Class Initialized
INFO - 2017-12-26 20:40:11 --> Security Class Initialized
DEBUG - 2017-12-26 20:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:40:11 --> Input Class Initialized
INFO - 2017-12-26 20:40:11 --> Language Class Initialized
INFO - 2017-12-26 20:40:11 --> Loader Class Initialized
INFO - 2017-12-26 20:40:11 --> Helper loaded: url_helper
INFO - 2017-12-26 20:40:11 --> Helper loaded: form_helper
INFO - 2017-12-26 20:40:11 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:40:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:40:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:40:11 --> Form Validation Class Initialized
INFO - 2017-12-26 20:40:11 --> Model Class Initialized
INFO - 2017-12-26 20:40:11 --> Controller Class Initialized
INFO - 2017-12-26 20:40:11 --> Model Class Initialized
INFO - 2017-12-26 20:40:11 --> Model Class Initialized
INFO - 2017-12-26 20:40:11 --> Model Class Initialized
DEBUG - 2017-12-26 20:40:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:40:15 --> Config Class Initialized
INFO - 2017-12-26 20:40:15 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:40:15 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:40:15 --> Utf8 Class Initialized
INFO - 2017-12-26 20:40:15 --> URI Class Initialized
INFO - 2017-12-26 20:40:15 --> Router Class Initialized
INFO - 2017-12-26 20:40:15 --> Output Class Initialized
INFO - 2017-12-26 20:40:15 --> Security Class Initialized
DEBUG - 2017-12-26 20:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:40:15 --> Input Class Initialized
INFO - 2017-12-26 20:40:15 --> Language Class Initialized
INFO - 2017-12-26 20:40:15 --> Loader Class Initialized
INFO - 2017-12-26 20:40:15 --> Helper loaded: url_helper
INFO - 2017-12-26 20:40:15 --> Helper loaded: form_helper
INFO - 2017-12-26 20:40:15 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:40:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:40:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:40:15 --> Form Validation Class Initialized
INFO - 2017-12-26 20:40:15 --> Model Class Initialized
INFO - 2017-12-26 20:40:15 --> Controller Class Initialized
INFO - 2017-12-26 20:40:15 --> Model Class Initialized
INFO - 2017-12-26 20:40:15 --> Model Class Initialized
INFO - 2017-12-26 20:40:15 --> Model Class Initialized
DEBUG - 2017-12-26 20:40:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:40:15 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-26 20:40:15 --> Final output sent to browser
DEBUG - 2017-12-26 20:40:15 --> Total execution time: 0.0677
INFO - 2017-12-26 20:40:15 --> Config Class Initialized
INFO - 2017-12-26 20:40:15 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:40:15 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:40:15 --> Utf8 Class Initialized
INFO - 2017-12-26 20:40:15 --> URI Class Initialized
INFO - 2017-12-26 20:40:15 --> Router Class Initialized
INFO - 2017-12-26 20:40:15 --> Output Class Initialized
INFO - 2017-12-26 20:40:15 --> Security Class Initialized
DEBUG - 2017-12-26 20:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:40:15 --> Input Class Initialized
INFO - 2017-12-26 20:40:15 --> Language Class Initialized
ERROR - 2017-12-26 20:40:15 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-26 20:40:15 --> Config Class Initialized
INFO - 2017-12-26 20:40:15 --> Hooks Class Initialized
INFO - 2017-12-26 20:40:15 --> Config Class Initialized
INFO - 2017-12-26 20:40:15 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:40:15 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:40:15 --> Utf8 Class Initialized
DEBUG - 2017-12-26 20:40:15 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:40:15 --> Utf8 Class Initialized
INFO - 2017-12-26 20:40:15 --> URI Class Initialized
INFO - 2017-12-26 20:40:15 --> URI Class Initialized
INFO - 2017-12-26 20:40:15 --> Router Class Initialized
INFO - 2017-12-26 20:40:15 --> Router Class Initialized
INFO - 2017-12-26 20:40:15 --> Output Class Initialized
INFO - 2017-12-26 20:40:15 --> Output Class Initialized
INFO - 2017-12-26 20:40:15 --> Security Class Initialized
INFO - 2017-12-26 20:40:15 --> Security Class Initialized
DEBUG - 2017-12-26 20:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:40:15 --> Input Class Initialized
DEBUG - 2017-12-26 20:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:40:15 --> Input Class Initialized
INFO - 2017-12-26 20:40:15 --> Language Class Initialized
INFO - 2017-12-26 20:40:15 --> Language Class Initialized
ERROR - 2017-12-26 20:40:15 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-26 20:40:15 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-26 20:40:15 --> Config Class Initialized
INFO - 2017-12-26 20:40:15 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:40:15 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:40:15 --> Utf8 Class Initialized
INFO - 2017-12-26 20:40:15 --> URI Class Initialized
INFO - 2017-12-26 20:40:15 --> Router Class Initialized
INFO - 2017-12-26 20:40:15 --> Output Class Initialized
INFO - 2017-12-26 20:40:15 --> Security Class Initialized
DEBUG - 2017-12-26 20:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:40:15 --> Input Class Initialized
INFO - 2017-12-26 20:40:15 --> Language Class Initialized
INFO - 2017-12-26 20:40:15 --> Loader Class Initialized
INFO - 2017-12-26 20:40:15 --> Helper loaded: url_helper
INFO - 2017-12-26 20:40:15 --> Helper loaded: form_helper
INFO - 2017-12-26 20:40:15 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:40:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:40:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:40:15 --> Form Validation Class Initialized
INFO - 2017-12-26 20:40:15 --> Model Class Initialized
INFO - 2017-12-26 20:40:15 --> Controller Class Initialized
INFO - 2017-12-26 20:40:15 --> Model Class Initialized
INFO - 2017-12-26 20:40:15 --> Model Class Initialized
INFO - 2017-12-26 20:40:15 --> Model Class Initialized
DEBUG - 2017-12-26 20:40:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:41:05 --> Config Class Initialized
INFO - 2017-12-26 20:41:05 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:41:05 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:41:05 --> Utf8 Class Initialized
INFO - 2017-12-26 20:41:05 --> URI Class Initialized
INFO - 2017-12-26 20:41:05 --> Router Class Initialized
INFO - 2017-12-26 20:41:05 --> Output Class Initialized
INFO - 2017-12-26 20:41:05 --> Security Class Initialized
DEBUG - 2017-12-26 20:41:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:41:05 --> Input Class Initialized
INFO - 2017-12-26 20:41:05 --> Language Class Initialized
INFO - 2017-12-26 20:41:05 --> Loader Class Initialized
INFO - 2017-12-26 20:41:05 --> Helper loaded: url_helper
INFO - 2017-12-26 20:41:05 --> Helper loaded: form_helper
INFO - 2017-12-26 20:41:05 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:41:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:41:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:41:05 --> Form Validation Class Initialized
INFO - 2017-12-26 20:41:05 --> Model Class Initialized
INFO - 2017-12-26 20:41:05 --> Controller Class Initialized
INFO - 2017-12-26 20:41:05 --> Model Class Initialized
INFO - 2017-12-26 20:41:05 --> Model Class Initialized
INFO - 2017-12-26 20:41:05 --> Model Class Initialized
DEBUG - 2017-12-26 20:41:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:41:05 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-26 20:41:05 --> Final output sent to browser
DEBUG - 2017-12-26 20:41:05 --> Total execution time: 0.0866
INFO - 2017-12-26 20:41:05 --> Config Class Initialized
INFO - 2017-12-26 20:41:05 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:41:05 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:41:05 --> Utf8 Class Initialized
INFO - 2017-12-26 20:41:05 --> URI Class Initialized
INFO - 2017-12-26 20:41:05 --> Router Class Initialized
INFO - 2017-12-26 20:41:05 --> Output Class Initialized
INFO - 2017-12-26 20:41:05 --> Security Class Initialized
DEBUG - 2017-12-26 20:41:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:41:05 --> Input Class Initialized
INFO - 2017-12-26 20:41:05 --> Language Class Initialized
INFO - 2017-12-26 20:41:05 --> Loader Class Initialized
INFO - 2017-12-26 20:41:05 --> Helper loaded: url_helper
INFO - 2017-12-26 20:41:05 --> Helper loaded: form_helper
INFO - 2017-12-26 20:41:05 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:41:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:41:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:41:05 --> Form Validation Class Initialized
INFO - 2017-12-26 20:41:05 --> Model Class Initialized
INFO - 2017-12-26 20:41:05 --> Controller Class Initialized
INFO - 2017-12-26 20:41:05 --> Model Class Initialized
INFO - 2017-12-26 20:41:05 --> Model Class Initialized
INFO - 2017-12-26 20:41:05 --> Model Class Initialized
DEBUG - 2017-12-26 20:41:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:41:16 --> Config Class Initialized
INFO - 2017-12-26 20:41:16 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:41:16 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:41:16 --> Utf8 Class Initialized
INFO - 2017-12-26 20:41:16 --> URI Class Initialized
INFO - 2017-12-26 20:41:16 --> Router Class Initialized
INFO - 2017-12-26 20:41:16 --> Config Class Initialized
INFO - 2017-12-26 20:41:16 --> Hooks Class Initialized
INFO - 2017-12-26 20:41:16 --> Output Class Initialized
INFO - 2017-12-26 20:41:16 --> Config Class Initialized
INFO - 2017-12-26 20:41:16 --> Hooks Class Initialized
INFO - 2017-12-26 20:41:16 --> Security Class Initialized
DEBUG - 2017-12-26 20:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:41:16 --> Input Class Initialized
DEBUG - 2017-12-26 20:41:16 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:41:16 --> Utf8 Class Initialized
DEBUG - 2017-12-26 20:41:16 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:41:16 --> Language Class Initialized
INFO - 2017-12-26 20:41:16 --> Utf8 Class Initialized
INFO - 2017-12-26 20:41:16 --> URI Class Initialized
ERROR - 2017-12-26 20:41:16 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-26 20:41:16 --> URI Class Initialized
INFO - 2017-12-26 20:41:16 --> Router Class Initialized
INFO - 2017-12-26 20:41:16 --> Router Class Initialized
INFO - 2017-12-26 20:41:16 --> Output Class Initialized
INFO - 2017-12-26 20:41:16 --> Output Class Initialized
INFO - 2017-12-26 20:41:16 --> Security Class Initialized
INFO - 2017-12-26 20:41:16 --> Security Class Initialized
DEBUG - 2017-12-26 20:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:41:16 --> Input Class Initialized
DEBUG - 2017-12-26 20:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:41:16 --> Input Class Initialized
INFO - 2017-12-26 20:41:16 --> Language Class Initialized
INFO - 2017-12-26 20:41:16 --> Language Class Initialized
ERROR - 2017-12-26 20:41:16 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-26 20:41:16 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-26 20:42:10 --> Config Class Initialized
INFO - 2017-12-26 20:42:10 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:42:10 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:42:10 --> Utf8 Class Initialized
INFO - 2017-12-26 20:42:10 --> URI Class Initialized
INFO - 2017-12-26 20:42:10 --> Router Class Initialized
INFO - 2017-12-26 20:42:10 --> Output Class Initialized
INFO - 2017-12-26 20:42:10 --> Security Class Initialized
DEBUG - 2017-12-26 20:42:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:42:10 --> Input Class Initialized
INFO - 2017-12-26 20:42:10 --> Language Class Initialized
INFO - 2017-12-26 20:42:10 --> Loader Class Initialized
INFO - 2017-12-26 20:42:10 --> Helper loaded: url_helper
INFO - 2017-12-26 20:42:10 --> Helper loaded: form_helper
INFO - 2017-12-26 20:42:10 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:42:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:42:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:42:10 --> Form Validation Class Initialized
INFO - 2017-12-26 20:42:10 --> Model Class Initialized
INFO - 2017-12-26 20:42:10 --> Controller Class Initialized
INFO - 2017-12-26 20:42:10 --> Model Class Initialized
INFO - 2017-12-26 20:42:10 --> Model Class Initialized
INFO - 2017-12-26 20:42:10 --> Model Class Initialized
DEBUG - 2017-12-26 20:42:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:42:10 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-26 20:42:10 --> Final output sent to browser
DEBUG - 2017-12-26 20:42:10 --> Total execution time: 0.0621
INFO - 2017-12-26 20:42:12 --> Config Class Initialized
INFO - 2017-12-26 20:42:12 --> Hooks Class Initialized
INFO - 2017-12-26 20:42:12 --> Config Class Initialized
INFO - 2017-12-26 20:42:12 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:42:12 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:42:12 --> Utf8 Class Initialized
DEBUG - 2017-12-26 20:42:12 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:42:12 --> Utf8 Class Initialized
INFO - 2017-12-26 20:42:12 --> URI Class Initialized
INFO - 2017-12-26 20:42:12 --> URI Class Initialized
INFO - 2017-12-26 20:42:12 --> Router Class Initialized
INFO - 2017-12-26 20:42:12 --> Router Class Initialized
INFO - 2017-12-26 20:42:12 --> Output Class Initialized
INFO - 2017-12-26 20:42:12 --> Output Class Initialized
INFO - 2017-12-26 20:42:12 --> Security Class Initialized
INFO - 2017-12-26 20:42:12 --> Security Class Initialized
DEBUG - 2017-12-26 20:42:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:42:12 --> Input Class Initialized
DEBUG - 2017-12-26 20:42:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:42:12 --> Input Class Initialized
INFO - 2017-12-26 20:42:12 --> Language Class Initialized
INFO - 2017-12-26 20:42:12 --> Language Class Initialized
ERROR - 2017-12-26 20:42:12 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-26 20:42:12 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-26 20:42:15 --> Config Class Initialized
INFO - 2017-12-26 20:42:15 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:42:15 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:42:15 --> Utf8 Class Initialized
INFO - 2017-12-26 20:42:15 --> URI Class Initialized
INFO - 2017-12-26 20:42:15 --> Router Class Initialized
INFO - 2017-12-26 20:42:15 --> Output Class Initialized
INFO - 2017-12-26 20:42:15 --> Security Class Initialized
DEBUG - 2017-12-26 20:42:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:42:15 --> Input Class Initialized
INFO - 2017-12-26 20:42:15 --> Language Class Initialized
INFO - 2017-12-26 20:42:15 --> Loader Class Initialized
INFO - 2017-12-26 20:42:15 --> Helper loaded: url_helper
INFO - 2017-12-26 20:42:15 --> Helper loaded: form_helper
INFO - 2017-12-26 20:42:15 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:42:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:42:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:42:15 --> Form Validation Class Initialized
INFO - 2017-12-26 20:42:15 --> Model Class Initialized
INFO - 2017-12-26 20:42:15 --> Controller Class Initialized
INFO - 2017-12-26 20:42:15 --> Model Class Initialized
INFO - 2017-12-26 20:42:15 --> Model Class Initialized
INFO - 2017-12-26 20:42:15 --> Model Class Initialized
DEBUG - 2017-12-26 20:42:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:42:23 --> Config Class Initialized
INFO - 2017-12-26 20:42:23 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:42:23 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:42:23 --> Utf8 Class Initialized
INFO - 2017-12-26 20:42:23 --> URI Class Initialized
INFO - 2017-12-26 20:42:23 --> Router Class Initialized
INFO - 2017-12-26 20:42:23 --> Output Class Initialized
INFO - 2017-12-26 20:42:23 --> Security Class Initialized
DEBUG - 2017-12-26 20:42:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:42:23 --> Input Class Initialized
INFO - 2017-12-26 20:42:23 --> Language Class Initialized
INFO - 2017-12-26 20:42:23 --> Loader Class Initialized
INFO - 2017-12-26 20:42:23 --> Helper loaded: url_helper
INFO - 2017-12-26 20:42:23 --> Helper loaded: form_helper
INFO - 2017-12-26 20:42:23 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:42:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:42:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:42:23 --> Form Validation Class Initialized
INFO - 2017-12-26 20:42:23 --> Model Class Initialized
INFO - 2017-12-26 20:42:23 --> Controller Class Initialized
INFO - 2017-12-26 20:42:23 --> Model Class Initialized
INFO - 2017-12-26 20:42:23 --> Model Class Initialized
INFO - 2017-12-26 20:42:23 --> Model Class Initialized
DEBUG - 2017-12-26 20:42:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:42:23 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-26 20:42:23 --> Final output sent to browser
DEBUG - 2017-12-26 20:42:23 --> Total execution time: 0.0510
INFO - 2017-12-26 20:42:28 --> Config Class Initialized
INFO - 2017-12-26 20:42:28 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:42:28 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:42:28 --> Utf8 Class Initialized
INFO - 2017-12-26 20:42:28 --> URI Class Initialized
INFO - 2017-12-26 20:42:28 --> Router Class Initialized
INFO - 2017-12-26 20:42:28 --> Output Class Initialized
INFO - 2017-12-26 20:42:28 --> Security Class Initialized
DEBUG - 2017-12-26 20:42:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:42:28 --> Input Class Initialized
INFO - 2017-12-26 20:42:28 --> Language Class Initialized
INFO - 2017-12-26 20:42:28 --> Loader Class Initialized
INFO - 2017-12-26 20:42:28 --> Helper loaded: url_helper
INFO - 2017-12-26 20:42:28 --> Helper loaded: form_helper
INFO - 2017-12-26 20:42:28 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:42:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:42:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:42:28 --> Form Validation Class Initialized
INFO - 2017-12-26 20:42:28 --> Config Class Initialized
INFO - 2017-12-26 20:42:28 --> Hooks Class Initialized
INFO - 2017-12-26 20:42:28 --> Model Class Initialized
INFO - 2017-12-26 20:42:28 --> Controller Class Initialized
INFO - 2017-12-26 20:42:28 --> Model Class Initialized
INFO - 2017-12-26 20:42:28 --> Model Class Initialized
DEBUG - 2017-12-26 20:42:28 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:42:28 --> Utf8 Class Initialized
INFO - 2017-12-26 20:42:28 --> Model Class Initialized
DEBUG - 2017-12-26 20:42:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:42:28 --> URI Class Initialized
INFO - 2017-12-26 20:42:28 --> Router Class Initialized
INFO - 2017-12-26 20:42:28 --> Output Class Initialized
INFO - 2017-12-26 20:42:28 --> Security Class Initialized
DEBUG - 2017-12-26 20:42:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:42:28 --> Input Class Initialized
INFO - 2017-12-26 20:42:28 --> Language Class Initialized
ERROR - 2017-12-26 20:42:28 --> 404 Page Not Found: Faviconico/index
INFO - 2017-12-26 20:43:11 --> Config Class Initialized
INFO - 2017-12-26 20:43:11 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:43:11 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:43:11 --> Utf8 Class Initialized
INFO - 2017-12-26 20:43:11 --> URI Class Initialized
INFO - 2017-12-26 20:43:11 --> Router Class Initialized
INFO - 2017-12-26 20:43:11 --> Output Class Initialized
INFO - 2017-12-26 20:43:11 --> Security Class Initialized
DEBUG - 2017-12-26 20:43:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:43:11 --> Input Class Initialized
INFO - 2017-12-26 20:43:11 --> Language Class Initialized
INFO - 2017-12-26 20:43:12 --> Loader Class Initialized
INFO - 2017-12-26 20:43:12 --> Helper loaded: url_helper
INFO - 2017-12-26 20:43:12 --> Helper loaded: form_helper
INFO - 2017-12-26 20:43:12 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:43:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:43:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:43:12 --> Form Validation Class Initialized
INFO - 2017-12-26 20:43:12 --> Model Class Initialized
INFO - 2017-12-26 20:43:12 --> Controller Class Initialized
INFO - 2017-12-26 20:43:12 --> Model Class Initialized
INFO - 2017-12-26 20:43:12 --> Model Class Initialized
INFO - 2017-12-26 20:43:12 --> Model Class Initialized
DEBUG - 2017-12-26 20:43:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:43:12 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-26 20:43:12 --> Final output sent to browser
DEBUG - 2017-12-26 20:43:12 --> Total execution time: 0.0919
INFO - 2017-12-26 20:43:12 --> Config Class Initialized
INFO - 2017-12-26 20:43:12 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:43:12 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:43:12 --> Utf8 Class Initialized
INFO - 2017-12-26 20:43:12 --> URI Class Initialized
INFO - 2017-12-26 20:43:12 --> Router Class Initialized
INFO - 2017-12-26 20:43:12 --> Output Class Initialized
INFO - 2017-12-26 20:43:12 --> Security Class Initialized
DEBUG - 2017-12-26 20:43:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:43:12 --> Input Class Initialized
INFO - 2017-12-26 20:43:12 --> Language Class Initialized
INFO - 2017-12-26 20:43:12 --> Loader Class Initialized
INFO - 2017-12-26 20:43:12 --> Helper loaded: url_helper
INFO - 2017-12-26 20:43:12 --> Helper loaded: form_helper
INFO - 2017-12-26 20:43:12 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:43:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:43:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:43:12 --> Form Validation Class Initialized
INFO - 2017-12-26 20:43:12 --> Model Class Initialized
INFO - 2017-12-26 20:43:12 --> Controller Class Initialized
INFO - 2017-12-26 20:43:12 --> Model Class Initialized
INFO - 2017-12-26 20:43:12 --> Model Class Initialized
INFO - 2017-12-26 20:43:12 --> Model Class Initialized
DEBUG - 2017-12-26 20:43:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:43:21 --> Config Class Initialized
INFO - 2017-12-26 20:43:21 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:43:21 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:43:21 --> Utf8 Class Initialized
INFO - 2017-12-26 20:43:21 --> URI Class Initialized
INFO - 2017-12-26 20:43:21 --> Router Class Initialized
INFO - 2017-12-26 20:43:21 --> Output Class Initialized
INFO - 2017-12-26 20:43:21 --> Security Class Initialized
DEBUG - 2017-12-26 20:43:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:43:21 --> Input Class Initialized
INFO - 2017-12-26 20:43:21 --> Language Class Initialized
INFO - 2017-12-26 20:43:21 --> Loader Class Initialized
INFO - 2017-12-26 20:43:21 --> Helper loaded: url_helper
INFO - 2017-12-26 20:43:21 --> Helper loaded: form_helper
INFO - 2017-12-26 20:43:21 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:43:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:43:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:43:21 --> Form Validation Class Initialized
INFO - 2017-12-26 20:43:21 --> Model Class Initialized
INFO - 2017-12-26 20:43:21 --> Controller Class Initialized
INFO - 2017-12-26 20:43:21 --> Model Class Initialized
INFO - 2017-12-26 20:43:21 --> Model Class Initialized
INFO - 2017-12-26 20:43:21 --> Model Class Initialized
DEBUG - 2017-12-26 20:43:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:43:21 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-26 20:43:21 --> Final output sent to browser
DEBUG - 2017-12-26 20:43:21 --> Total execution time: 0.1174
INFO - 2017-12-26 20:43:23 --> Config Class Initialized
INFO - 2017-12-26 20:43:23 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:43:23 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:43:23 --> Utf8 Class Initialized
INFO - 2017-12-26 20:43:23 --> URI Class Initialized
INFO - 2017-12-26 20:43:23 --> Router Class Initialized
INFO - 2017-12-26 20:43:23 --> Output Class Initialized
INFO - 2017-12-26 20:43:23 --> Security Class Initialized
DEBUG - 2017-12-26 20:43:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:43:23 --> Input Class Initialized
INFO - 2017-12-26 20:43:23 --> Language Class Initialized
INFO - 2017-12-26 20:43:23 --> Loader Class Initialized
INFO - 2017-12-26 20:43:23 --> Helper loaded: url_helper
INFO - 2017-12-26 20:43:23 --> Helper loaded: form_helper
INFO - 2017-12-26 20:43:23 --> Database Driver Class Initialized
INFO - 2017-12-26 20:43:23 --> Config Class Initialized
INFO - 2017-12-26 20:43:23 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:43:23 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:43:23 --> Utf8 Class Initialized
INFO - 2017-12-26 20:43:23 --> URI Class Initialized
INFO - 2017-12-26 20:43:23 --> Router Class Initialized
INFO - 2017-12-26 20:43:23 --> Output Class Initialized
DEBUG - 2017-12-26 20:43:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:43:23 --> Security Class Initialized
INFO - 2017-12-26 20:43:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2017-12-26 20:43:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:43:23 --> Input Class Initialized
INFO - 2017-12-26 20:43:23 --> Form Validation Class Initialized
INFO - 2017-12-26 20:43:23 --> Language Class Initialized
INFO - 2017-12-26 20:43:23 --> Model Class Initialized
INFO - 2017-12-26 20:43:23 --> Controller Class Initialized
ERROR - 2017-12-26 20:43:23 --> 404 Page Not Found: Faviconico/index
INFO - 2017-12-26 20:43:23 --> Model Class Initialized
INFO - 2017-12-26 20:43:23 --> Model Class Initialized
INFO - 2017-12-26 20:43:23 --> Model Class Initialized
DEBUG - 2017-12-26 20:43:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:44:17 --> Config Class Initialized
INFO - 2017-12-26 20:44:17 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:44:17 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:44:17 --> Utf8 Class Initialized
INFO - 2017-12-26 20:44:17 --> URI Class Initialized
INFO - 2017-12-26 20:44:17 --> Router Class Initialized
INFO - 2017-12-26 20:44:17 --> Output Class Initialized
INFO - 2017-12-26 20:44:17 --> Security Class Initialized
DEBUG - 2017-12-26 20:44:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:44:17 --> Input Class Initialized
INFO - 2017-12-26 20:44:17 --> Language Class Initialized
INFO - 2017-12-26 20:44:17 --> Loader Class Initialized
INFO - 2017-12-26 20:44:17 --> Helper loaded: url_helper
INFO - 2017-12-26 20:44:17 --> Helper loaded: form_helper
INFO - 2017-12-26 20:44:17 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:44:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:44:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:44:17 --> Form Validation Class Initialized
INFO - 2017-12-26 20:44:17 --> Model Class Initialized
INFO - 2017-12-26 20:44:17 --> Controller Class Initialized
INFO - 2017-12-26 20:44:17 --> Model Class Initialized
INFO - 2017-12-26 20:44:17 --> Model Class Initialized
INFO - 2017-12-26 20:44:17 --> Model Class Initialized
DEBUG - 2017-12-26 20:44:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:44:17 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-26 20:44:17 --> Final output sent to browser
DEBUG - 2017-12-26 20:44:17 --> Total execution time: 0.0945
INFO - 2017-12-26 20:44:18 --> Config Class Initialized
INFO - 2017-12-26 20:44:18 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:44:18 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:44:18 --> Utf8 Class Initialized
INFO - 2017-12-26 20:44:18 --> URI Class Initialized
INFO - 2017-12-26 20:44:18 --> Router Class Initialized
INFO - 2017-12-26 20:44:18 --> Output Class Initialized
INFO - 2017-12-26 20:44:18 --> Security Class Initialized
DEBUG - 2017-12-26 20:44:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:44:18 --> Input Class Initialized
INFO - 2017-12-26 20:44:18 --> Language Class Initialized
INFO - 2017-12-26 20:44:18 --> Loader Class Initialized
INFO - 2017-12-26 20:44:18 --> Helper loaded: url_helper
INFO - 2017-12-26 20:44:18 --> Helper loaded: form_helper
INFO - 2017-12-26 20:44:18 --> Database Driver Class Initialized
DEBUG - 2017-12-26 20:44:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 20:44:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 20:44:18 --> Form Validation Class Initialized
INFO - 2017-12-26 20:44:18 --> Model Class Initialized
INFO - 2017-12-26 20:44:18 --> Controller Class Initialized
INFO - 2017-12-26 20:44:18 --> Model Class Initialized
INFO - 2017-12-26 20:44:18 --> Model Class Initialized
INFO - 2017-12-26 20:44:18 --> Model Class Initialized
DEBUG - 2017-12-26 20:44:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 20:44:22 --> Config Class Initialized
INFO - 2017-12-26 20:44:22 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:44:22 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:44:22 --> Utf8 Class Initialized
INFO - 2017-12-26 20:44:22 --> URI Class Initialized
INFO - 2017-12-26 20:44:22 --> Router Class Initialized
INFO - 2017-12-26 20:44:22 --> Output Class Initialized
INFO - 2017-12-26 20:44:22 --> Security Class Initialized
DEBUG - 2017-12-26 20:44:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:44:22 --> Input Class Initialized
INFO - 2017-12-26 20:44:22 --> Language Class Initialized
ERROR - 2017-12-26 20:44:22 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-26 20:44:23 --> Config Class Initialized
INFO - 2017-12-26 20:44:23 --> Config Class Initialized
INFO - 2017-12-26 20:44:23 --> Hooks Class Initialized
INFO - 2017-12-26 20:44:23 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:44:23 --> UTF-8 Support Enabled
DEBUG - 2017-12-26 20:44:23 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:44:23 --> Utf8 Class Initialized
INFO - 2017-12-26 20:44:23 --> Utf8 Class Initialized
INFO - 2017-12-26 20:44:23 --> URI Class Initialized
INFO - 2017-12-26 20:44:23 --> URI Class Initialized
INFO - 2017-12-26 20:44:23 --> Router Class Initialized
INFO - 2017-12-26 20:44:23 --> Router Class Initialized
INFO - 2017-12-26 20:44:23 --> Output Class Initialized
INFO - 2017-12-26 20:44:23 --> Output Class Initialized
INFO - 2017-12-26 20:44:23 --> Security Class Initialized
INFO - 2017-12-26 20:44:23 --> Security Class Initialized
DEBUG - 2017-12-26 20:44:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-26 20:44:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:44:23 --> Input Class Initialized
INFO - 2017-12-26 20:44:23 --> Input Class Initialized
INFO - 2017-12-26 20:44:23 --> Language Class Initialized
INFO - 2017-12-26 20:44:23 --> Language Class Initialized
ERROR - 2017-12-26 20:44:23 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-26 20:44:23 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-26 20:44:32 --> Config Class Initialized
INFO - 2017-12-26 20:44:32 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:44:32 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:44:32 --> Utf8 Class Initialized
INFO - 2017-12-26 20:44:32 --> URI Class Initialized
INFO - 2017-12-26 20:44:32 --> Router Class Initialized
INFO - 2017-12-26 20:44:32 --> Output Class Initialized
INFO - 2017-12-26 20:44:32 --> Security Class Initialized
DEBUG - 2017-12-26 20:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:44:32 --> Input Class Initialized
INFO - 2017-12-26 20:44:32 --> Language Class Initialized
ERROR - 2017-12-26 20:44:32 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-26 20:44:32 --> Config Class Initialized
INFO - 2017-12-26 20:44:32 --> Hooks Class Initialized
INFO - 2017-12-26 20:44:32 --> Config Class Initialized
INFO - 2017-12-26 20:44:32 --> Hooks Class Initialized
DEBUG - 2017-12-26 20:44:32 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:44:32 --> Utf8 Class Initialized
DEBUG - 2017-12-26 20:44:32 --> UTF-8 Support Enabled
INFO - 2017-12-26 20:44:32 --> Utf8 Class Initialized
INFO - 2017-12-26 20:44:32 --> URI Class Initialized
INFO - 2017-12-26 20:44:32 --> URI Class Initialized
INFO - 2017-12-26 20:44:32 --> Router Class Initialized
INFO - 2017-12-26 20:44:32 --> Router Class Initialized
INFO - 2017-12-26 20:44:32 --> Output Class Initialized
INFO - 2017-12-26 20:44:32 --> Output Class Initialized
INFO - 2017-12-26 20:44:32 --> Security Class Initialized
DEBUG - 2017-12-26 20:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:44:32 --> Security Class Initialized
INFO - 2017-12-26 20:44:32 --> Input Class Initialized
INFO - 2017-12-26 20:44:32 --> Language Class Initialized
DEBUG - 2017-12-26 20:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 20:44:32 --> Input Class Initialized
INFO - 2017-12-26 20:44:32 --> Language Class Initialized
ERROR - 2017-12-26 20:44:32 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-26 20:44:32 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-26 21:00:39 --> Config Class Initialized
INFO - 2017-12-26 21:00:39 --> Hooks Class Initialized
DEBUG - 2017-12-26 21:00:39 --> UTF-8 Support Enabled
INFO - 2017-12-26 21:00:39 --> Utf8 Class Initialized
INFO - 2017-12-26 21:00:39 --> URI Class Initialized
INFO - 2017-12-26 21:00:39 --> Router Class Initialized
INFO - 2017-12-26 21:00:39 --> Output Class Initialized
INFO - 2017-12-26 21:00:39 --> Security Class Initialized
DEBUG - 2017-12-26 21:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 21:00:39 --> Input Class Initialized
INFO - 2017-12-26 21:00:39 --> Language Class Initialized
INFO - 2017-12-26 21:00:39 --> Loader Class Initialized
INFO - 2017-12-26 21:00:39 --> Helper loaded: url_helper
INFO - 2017-12-26 21:00:39 --> Helper loaded: form_helper
INFO - 2017-12-26 21:00:39 --> Database Driver Class Initialized
DEBUG - 2017-12-26 21:00:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 21:00:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 21:00:39 --> Form Validation Class Initialized
INFO - 2017-12-26 21:00:39 --> Model Class Initialized
INFO - 2017-12-26 21:00:39 --> Controller Class Initialized
INFO - 2017-12-26 21:00:39 --> Model Class Initialized
INFO - 2017-12-26 21:00:39 --> Model Class Initialized
INFO - 2017-12-26 21:00:39 --> Model Class Initialized
DEBUG - 2017-12-26 21:00:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 21:00:39 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-26 21:00:39 --> Final output sent to browser
DEBUG - 2017-12-26 21:00:39 --> Total execution time: 0.0835
INFO - 2017-12-26 21:00:39 --> Config Class Initialized
INFO - 2017-12-26 21:00:39 --> Hooks Class Initialized
DEBUG - 2017-12-26 21:00:39 --> UTF-8 Support Enabled
INFO - 2017-12-26 21:00:39 --> Utf8 Class Initialized
INFO - 2017-12-26 21:00:39 --> URI Class Initialized
INFO - 2017-12-26 21:00:39 --> Router Class Initialized
INFO - 2017-12-26 21:00:39 --> Output Class Initialized
INFO - 2017-12-26 21:00:39 --> Security Class Initialized
DEBUG - 2017-12-26 21:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 21:00:39 --> Input Class Initialized
INFO - 2017-12-26 21:00:39 --> Language Class Initialized
INFO - 2017-12-26 21:00:39 --> Loader Class Initialized
INFO - 2017-12-26 21:00:39 --> Helper loaded: url_helper
INFO - 2017-12-26 21:00:39 --> Helper loaded: form_helper
INFO - 2017-12-26 21:00:39 --> Database Driver Class Initialized
DEBUG - 2017-12-26 21:00:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 21:00:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 21:00:39 --> Form Validation Class Initialized
INFO - 2017-12-26 21:00:39 --> Model Class Initialized
INFO - 2017-12-26 21:00:39 --> Controller Class Initialized
INFO - 2017-12-26 21:00:39 --> Model Class Initialized
INFO - 2017-12-26 21:00:39 --> Model Class Initialized
INFO - 2017-12-26 21:00:39 --> Model Class Initialized
DEBUG - 2017-12-26 21:00:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 21:00:40 --> Config Class Initialized
INFO - 2017-12-26 21:00:40 --> Hooks Class Initialized
DEBUG - 2017-12-26 21:00:40 --> UTF-8 Support Enabled
INFO - 2017-12-26 21:00:40 --> Utf8 Class Initialized
INFO - 2017-12-26 21:00:40 --> URI Class Initialized
INFO - 2017-12-26 21:00:40 --> Router Class Initialized
INFO - 2017-12-26 21:00:40 --> Output Class Initialized
INFO - 2017-12-26 21:00:40 --> Security Class Initialized
DEBUG - 2017-12-26 21:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 21:00:40 --> Input Class Initialized
INFO - 2017-12-26 21:00:40 --> Language Class Initialized
INFO - 2017-12-26 21:00:40 --> Loader Class Initialized
INFO - 2017-12-26 21:00:40 --> Helper loaded: url_helper
INFO - 2017-12-26 21:00:40 --> Helper loaded: form_helper
INFO - 2017-12-26 21:00:40 --> Database Driver Class Initialized
DEBUG - 2017-12-26 21:00:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 21:00:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 21:00:40 --> Form Validation Class Initialized
INFO - 2017-12-26 21:00:40 --> Model Class Initialized
INFO - 2017-12-26 21:00:40 --> Controller Class Initialized
INFO - 2017-12-26 21:00:40 --> Model Class Initialized
INFO - 2017-12-26 21:00:40 --> Model Class Initialized
INFO - 2017-12-26 21:00:40 --> Model Class Initialized
DEBUG - 2017-12-26 21:00:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 21:00:40 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-26 21:00:40 --> Final output sent to browser
DEBUG - 2017-12-26 21:00:40 --> Total execution time: 0.0822
INFO - 2017-12-26 21:00:42 --> Config Class Initialized
INFO - 2017-12-26 21:00:42 --> Hooks Class Initialized
DEBUG - 2017-12-26 21:00:42 --> UTF-8 Support Enabled
INFO - 2017-12-26 21:00:42 --> Utf8 Class Initialized
INFO - 2017-12-26 21:00:42 --> URI Class Initialized
INFO - 2017-12-26 21:00:42 --> Router Class Initialized
INFO - 2017-12-26 21:00:42 --> Output Class Initialized
INFO - 2017-12-26 21:00:42 --> Security Class Initialized
DEBUG - 2017-12-26 21:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 21:00:42 --> Input Class Initialized
INFO - 2017-12-26 21:00:42 --> Language Class Initialized
INFO - 2017-12-26 21:00:42 --> Loader Class Initialized
INFO - 2017-12-26 21:00:42 --> Helper loaded: url_helper
INFO - 2017-12-26 21:00:42 --> Helper loaded: form_helper
INFO - 2017-12-26 21:00:42 --> Config Class Initialized
INFO - 2017-12-26 21:00:42 --> Hooks Class Initialized
DEBUG - 2017-12-26 21:00:42 --> UTF-8 Support Enabled
INFO - 2017-12-26 21:00:42 --> Utf8 Class Initialized
INFO - 2017-12-26 21:00:42 --> URI Class Initialized
INFO - 2017-12-26 21:00:42 --> Database Driver Class Initialized
INFO - 2017-12-26 21:00:42 --> Router Class Initialized
INFO - 2017-12-26 21:00:42 --> Output Class Initialized
INFO - 2017-12-26 21:00:42 --> Security Class Initialized
DEBUG - 2017-12-26 21:00:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 21:00:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2017-12-26 21:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 21:00:42 --> Input Class Initialized
INFO - 2017-12-26 21:00:42 --> Language Class Initialized
INFO - 2017-12-26 21:00:42 --> Form Validation Class Initialized
ERROR - 2017-12-26 21:00:42 --> 404 Page Not Found: Faviconico/index
INFO - 2017-12-26 21:00:42 --> Model Class Initialized
INFO - 2017-12-26 21:00:42 --> Controller Class Initialized
INFO - 2017-12-26 21:00:42 --> Model Class Initialized
INFO - 2017-12-26 21:00:42 --> Model Class Initialized
INFO - 2017-12-26 21:00:42 --> Model Class Initialized
DEBUG - 2017-12-26 21:00:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 21:00:50 --> Config Class Initialized
INFO - 2017-12-26 21:00:50 --> Hooks Class Initialized
INFO - 2017-12-26 21:00:50 --> Config Class Initialized
INFO - 2017-12-26 21:00:50 --> Hooks Class Initialized
DEBUG - 2017-12-26 21:00:50 --> UTF-8 Support Enabled
INFO - 2017-12-26 21:00:50 --> Utf8 Class Initialized
DEBUG - 2017-12-26 21:00:50 --> UTF-8 Support Enabled
INFO - 2017-12-26 21:00:50 --> Utf8 Class Initialized
INFO - 2017-12-26 21:00:50 --> URI Class Initialized
INFO - 2017-12-26 21:00:50 --> URI Class Initialized
INFO - 2017-12-26 21:00:50 --> Router Class Initialized
INFO - 2017-12-26 21:00:50 --> Router Class Initialized
INFO - 2017-12-26 21:00:50 --> Output Class Initialized
INFO - 2017-12-26 21:00:50 --> Output Class Initialized
INFO - 2017-12-26 21:00:50 --> Security Class Initialized
INFO - 2017-12-26 21:00:50 --> Security Class Initialized
DEBUG - 2017-12-26 21:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 21:00:50 --> Input Class Initialized
DEBUG - 2017-12-26 21:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 21:00:50 --> Input Class Initialized
INFO - 2017-12-26 21:00:50 --> Language Class Initialized
INFO - 2017-12-26 21:00:50 --> Language Class Initialized
ERROR - 2017-12-26 21:00:50 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-26 21:00:50 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-26 21:01:22 --> Config Class Initialized
INFO - 2017-12-26 21:01:22 --> Hooks Class Initialized
DEBUG - 2017-12-26 21:01:22 --> UTF-8 Support Enabled
INFO - 2017-12-26 21:01:22 --> Utf8 Class Initialized
INFO - 2017-12-26 21:01:22 --> URI Class Initialized
INFO - 2017-12-26 21:01:22 --> Router Class Initialized
INFO - 2017-12-26 21:01:22 --> Output Class Initialized
INFO - 2017-12-26 21:01:22 --> Security Class Initialized
DEBUG - 2017-12-26 21:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 21:01:22 --> Input Class Initialized
INFO - 2017-12-26 21:01:22 --> Language Class Initialized
INFO - 2017-12-26 21:01:22 --> Loader Class Initialized
INFO - 2017-12-26 21:01:22 --> Helper loaded: url_helper
INFO - 2017-12-26 21:01:22 --> Helper loaded: form_helper
INFO - 2017-12-26 21:01:22 --> Database Driver Class Initialized
DEBUG - 2017-12-26 21:01:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 21:01:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 21:01:22 --> Form Validation Class Initialized
INFO - 2017-12-26 21:01:22 --> Model Class Initialized
INFO - 2017-12-26 21:01:22 --> Controller Class Initialized
INFO - 2017-12-26 21:01:22 --> Model Class Initialized
INFO - 2017-12-26 21:01:22 --> Model Class Initialized
INFO - 2017-12-26 21:01:22 --> Model Class Initialized
DEBUG - 2017-12-26 21:01:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 21:01:22 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-26 21:01:22 --> Final output sent to browser
DEBUG - 2017-12-26 21:01:22 --> Total execution time: 0.1085
INFO - 2017-12-26 21:01:22 --> Config Class Initialized
INFO - 2017-12-26 21:01:22 --> Hooks Class Initialized
DEBUG - 2017-12-26 21:01:22 --> UTF-8 Support Enabled
INFO - 2017-12-26 21:01:22 --> Utf8 Class Initialized
INFO - 2017-12-26 21:01:22 --> URI Class Initialized
INFO - 2017-12-26 21:01:22 --> Router Class Initialized
INFO - 2017-12-26 21:01:22 --> Output Class Initialized
INFO - 2017-12-26 21:01:22 --> Security Class Initialized
DEBUG - 2017-12-26 21:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 21:01:22 --> Input Class Initialized
INFO - 2017-12-26 21:01:22 --> Language Class Initialized
ERROR - 2017-12-26 21:01:22 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-26 21:01:22 --> Config Class Initialized
INFO - 2017-12-26 21:01:22 --> Config Class Initialized
INFO - 2017-12-26 21:01:22 --> Hooks Class Initialized
INFO - 2017-12-26 21:01:22 --> Hooks Class Initialized
DEBUG - 2017-12-26 21:01:22 --> UTF-8 Support Enabled
DEBUG - 2017-12-26 21:01:22 --> UTF-8 Support Enabled
INFO - 2017-12-26 21:01:22 --> Utf8 Class Initialized
INFO - 2017-12-26 21:01:22 --> Utf8 Class Initialized
INFO - 2017-12-26 21:01:22 --> URI Class Initialized
INFO - 2017-12-26 21:01:22 --> URI Class Initialized
INFO - 2017-12-26 21:01:22 --> Router Class Initialized
INFO - 2017-12-26 21:01:22 --> Router Class Initialized
INFO - 2017-12-26 21:01:22 --> Output Class Initialized
INFO - 2017-12-26 21:01:22 --> Output Class Initialized
INFO - 2017-12-26 21:01:22 --> Security Class Initialized
INFO - 2017-12-26 21:01:22 --> Security Class Initialized
DEBUG - 2017-12-26 21:01:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-26 21:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 21:01:22 --> Input Class Initialized
INFO - 2017-12-26 21:01:22 --> Input Class Initialized
INFO - 2017-12-26 21:01:22 --> Language Class Initialized
INFO - 2017-12-26 21:01:22 --> Language Class Initialized
ERROR - 2017-12-26 21:01:22 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-26 21:01:22 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-26 21:01:22 --> Config Class Initialized
INFO - 2017-12-26 21:01:22 --> Hooks Class Initialized
DEBUG - 2017-12-26 21:01:22 --> UTF-8 Support Enabled
INFO - 2017-12-26 21:01:22 --> Utf8 Class Initialized
INFO - 2017-12-26 21:01:22 --> URI Class Initialized
INFO - 2017-12-26 21:01:22 --> Router Class Initialized
INFO - 2017-12-26 21:01:22 --> Output Class Initialized
INFO - 2017-12-26 21:01:22 --> Security Class Initialized
DEBUG - 2017-12-26 21:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 21:01:22 --> Input Class Initialized
INFO - 2017-12-26 21:01:22 --> Language Class Initialized
INFO - 2017-12-26 21:01:22 --> Loader Class Initialized
INFO - 2017-12-26 21:01:22 --> Helper loaded: url_helper
INFO - 2017-12-26 21:01:22 --> Helper loaded: form_helper
INFO - 2017-12-26 21:01:22 --> Database Driver Class Initialized
DEBUG - 2017-12-26 21:01:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 21:01:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 21:01:22 --> Form Validation Class Initialized
INFO - 2017-12-26 21:01:22 --> Model Class Initialized
INFO - 2017-12-26 21:01:22 --> Controller Class Initialized
INFO - 2017-12-26 21:01:22 --> Model Class Initialized
INFO - 2017-12-26 21:01:22 --> Model Class Initialized
INFO - 2017-12-26 21:01:22 --> Model Class Initialized
DEBUG - 2017-12-26 21:01:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 21:01:24 --> Config Class Initialized
INFO - 2017-12-26 21:01:24 --> Hooks Class Initialized
DEBUG - 2017-12-26 21:01:24 --> UTF-8 Support Enabled
INFO - 2017-12-26 21:01:24 --> Utf8 Class Initialized
INFO - 2017-12-26 21:01:24 --> URI Class Initialized
INFO - 2017-12-26 21:01:24 --> Router Class Initialized
INFO - 2017-12-26 21:01:24 --> Output Class Initialized
INFO - 2017-12-26 21:01:24 --> Security Class Initialized
DEBUG - 2017-12-26 21:01:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 21:01:24 --> Input Class Initialized
INFO - 2017-12-26 21:01:24 --> Language Class Initialized
INFO - 2017-12-26 21:01:24 --> Loader Class Initialized
INFO - 2017-12-26 21:01:24 --> Helper loaded: url_helper
INFO - 2017-12-26 21:01:24 --> Helper loaded: form_helper
INFO - 2017-12-26 21:01:24 --> Database Driver Class Initialized
DEBUG - 2017-12-26 21:01:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 21:01:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 21:01:24 --> Form Validation Class Initialized
INFO - 2017-12-26 21:01:24 --> Model Class Initialized
INFO - 2017-12-26 21:01:24 --> Controller Class Initialized
INFO - 2017-12-26 21:01:24 --> Model Class Initialized
INFO - 2017-12-26 21:01:24 --> Model Class Initialized
INFO - 2017-12-26 21:01:24 --> Model Class Initialized
DEBUG - 2017-12-26 21:01:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 21:01:24 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-26 21:01:24 --> Final output sent to browser
DEBUG - 2017-12-26 21:01:24 --> Total execution time: 0.0613
INFO - 2017-12-26 21:01:26 --> Config Class Initialized
INFO - 2017-12-26 21:01:26 --> Hooks Class Initialized
DEBUG - 2017-12-26 21:01:26 --> UTF-8 Support Enabled
INFO - 2017-12-26 21:01:26 --> Utf8 Class Initialized
INFO - 2017-12-26 21:01:26 --> URI Class Initialized
INFO - 2017-12-26 21:01:26 --> Router Class Initialized
INFO - 2017-12-26 21:01:26 --> Output Class Initialized
INFO - 2017-12-26 21:01:26 --> Security Class Initialized
DEBUG - 2017-12-26 21:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 21:01:26 --> Input Class Initialized
INFO - 2017-12-26 21:01:26 --> Language Class Initialized
ERROR - 2017-12-26 21:01:26 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-26 21:01:26 --> Config Class Initialized
INFO - 2017-12-26 21:01:26 --> Hooks Class Initialized
INFO - 2017-12-26 21:01:26 --> Config Class Initialized
INFO - 2017-12-26 21:01:26 --> Hooks Class Initialized
DEBUG - 2017-12-26 21:01:26 --> UTF-8 Support Enabled
INFO - 2017-12-26 21:01:26 --> Utf8 Class Initialized
DEBUG - 2017-12-26 21:01:26 --> UTF-8 Support Enabled
INFO - 2017-12-26 21:01:26 --> Utf8 Class Initialized
INFO - 2017-12-26 21:01:26 --> URI Class Initialized
INFO - 2017-12-26 21:01:26 --> URI Class Initialized
INFO - 2017-12-26 21:01:26 --> Router Class Initialized
INFO - 2017-12-26 21:01:26 --> Router Class Initialized
INFO - 2017-12-26 21:01:26 --> Output Class Initialized
INFO - 2017-12-26 21:01:26 --> Output Class Initialized
INFO - 2017-12-26 21:01:26 --> Security Class Initialized
INFO - 2017-12-26 21:01:26 --> Security Class Initialized
DEBUG - 2017-12-26 21:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 21:01:26 --> Input Class Initialized
DEBUG - 2017-12-26 21:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 21:01:26 --> Input Class Initialized
INFO - 2017-12-26 21:01:26 --> Language Class Initialized
INFO - 2017-12-26 21:01:26 --> Language Class Initialized
ERROR - 2017-12-26 21:01:26 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-26 21:01:26 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-26 21:01:26 --> Config Class Initialized
INFO - 2017-12-26 21:01:26 --> Hooks Class Initialized
DEBUG - 2017-12-26 21:01:26 --> UTF-8 Support Enabled
INFO - 2017-12-26 21:01:26 --> Utf8 Class Initialized
INFO - 2017-12-26 21:01:26 --> URI Class Initialized
INFO - 2017-12-26 21:01:26 --> Router Class Initialized
INFO - 2017-12-26 21:01:26 --> Output Class Initialized
INFO - 2017-12-26 21:01:26 --> Security Class Initialized
DEBUG - 2017-12-26 21:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 21:01:26 --> Input Class Initialized
INFO - 2017-12-26 21:01:26 --> Language Class Initialized
INFO - 2017-12-26 21:01:26 --> Loader Class Initialized
INFO - 2017-12-26 21:01:26 --> Helper loaded: url_helper
INFO - 2017-12-26 21:01:26 --> Helper loaded: form_helper
INFO - 2017-12-26 21:01:26 --> Database Driver Class Initialized
DEBUG - 2017-12-26 21:01:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 21:01:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 21:01:26 --> Form Validation Class Initialized
INFO - 2017-12-26 21:01:26 --> Model Class Initialized
INFO - 2017-12-26 21:01:26 --> Controller Class Initialized
INFO - 2017-12-26 21:01:26 --> Model Class Initialized
INFO - 2017-12-26 21:01:26 --> Model Class Initialized
INFO - 2017-12-26 21:01:26 --> Model Class Initialized
DEBUG - 2017-12-26 21:01:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 21:01:46 --> Config Class Initialized
INFO - 2017-12-26 21:01:46 --> Hooks Class Initialized
DEBUG - 2017-12-26 21:01:46 --> UTF-8 Support Enabled
INFO - 2017-12-26 21:01:46 --> Utf8 Class Initialized
INFO - 2017-12-26 21:01:46 --> URI Class Initialized
INFO - 2017-12-26 21:01:46 --> Router Class Initialized
INFO - 2017-12-26 21:01:46 --> Output Class Initialized
INFO - 2017-12-26 21:01:46 --> Security Class Initialized
DEBUG - 2017-12-26 21:01:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 21:01:46 --> Input Class Initialized
INFO - 2017-12-26 21:01:46 --> Language Class Initialized
ERROR - 2017-12-26 21:01:46 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-26 21:01:46 --> Config Class Initialized
INFO - 2017-12-26 21:01:46 --> Hooks Class Initialized
INFO - 2017-12-26 21:01:46 --> Config Class Initialized
INFO - 2017-12-26 21:01:46 --> Hooks Class Initialized
DEBUG - 2017-12-26 21:01:46 --> UTF-8 Support Enabled
INFO - 2017-12-26 21:01:46 --> Utf8 Class Initialized
DEBUG - 2017-12-26 21:01:46 --> UTF-8 Support Enabled
INFO - 2017-12-26 21:01:46 --> Utf8 Class Initialized
INFO - 2017-12-26 21:01:46 --> URI Class Initialized
INFO - 2017-12-26 21:01:46 --> URI Class Initialized
INFO - 2017-12-26 21:01:46 --> Router Class Initialized
INFO - 2017-12-26 21:01:46 --> Router Class Initialized
INFO - 2017-12-26 21:01:46 --> Output Class Initialized
INFO - 2017-12-26 21:01:46 --> Output Class Initialized
INFO - 2017-12-26 21:01:46 --> Security Class Initialized
INFO - 2017-12-26 21:01:46 --> Security Class Initialized
DEBUG - 2017-12-26 21:01:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-26 21:01:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 21:01:46 --> Input Class Initialized
INFO - 2017-12-26 21:01:46 --> Input Class Initialized
INFO - 2017-12-26 21:01:46 --> Language Class Initialized
INFO - 2017-12-26 21:01:46 --> Language Class Initialized
ERROR - 2017-12-26 21:01:46 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-26 21:01:46 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-26 21:01:59 --> Config Class Initialized
INFO - 2017-12-26 21:01:59 --> Hooks Class Initialized
INFO - 2017-12-26 21:01:59 --> Config Class Initialized
INFO - 2017-12-26 21:01:59 --> Hooks Class Initialized
DEBUG - 2017-12-26 21:01:59 --> UTF-8 Support Enabled
INFO - 2017-12-26 21:01:59 --> Utf8 Class Initialized
INFO - 2017-12-26 21:01:59 --> URI Class Initialized
DEBUG - 2017-12-26 21:01:59 --> UTF-8 Support Enabled
INFO - 2017-12-26 21:01:59 --> Utf8 Class Initialized
INFO - 2017-12-26 21:01:59 --> Router Class Initialized
INFO - 2017-12-26 21:01:59 --> Config Class Initialized
INFO - 2017-12-26 21:01:59 --> URI Class Initialized
INFO - 2017-12-26 21:01:59 --> Hooks Class Initialized
INFO - 2017-12-26 21:01:59 --> Output Class Initialized
INFO - 2017-12-26 21:01:59 --> Router Class Initialized
INFO - 2017-12-26 21:01:59 --> Security Class Initialized
INFO - 2017-12-26 21:01:59 --> Output Class Initialized
DEBUG - 2017-12-26 21:01:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 21:01:59 --> Input Class Initialized
DEBUG - 2017-12-26 21:01:59 --> UTF-8 Support Enabled
INFO - 2017-12-26 21:01:59 --> Utf8 Class Initialized
INFO - 2017-12-26 21:01:59 --> Language Class Initialized
INFO - 2017-12-26 21:01:59 --> Security Class Initialized
INFO - 2017-12-26 21:01:59 --> URI Class Initialized
ERROR - 2017-12-26 21:01:59 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2017-12-26 21:01:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 21:01:59 --> Input Class Initialized
INFO - 2017-12-26 21:01:59 --> Router Class Initialized
INFO - 2017-12-26 21:01:59 --> Language Class Initialized
ERROR - 2017-12-26 21:01:59 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-26 21:01:59 --> Output Class Initialized
INFO - 2017-12-26 21:01:59 --> Security Class Initialized
DEBUG - 2017-12-26 21:01:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 21:01:59 --> Input Class Initialized
INFO - 2017-12-26 21:01:59 --> Language Class Initialized
ERROR - 2017-12-26 21:01:59 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-26 21:02:25 --> Config Class Initialized
INFO - 2017-12-26 21:02:25 --> Hooks Class Initialized
DEBUG - 2017-12-26 21:02:25 --> UTF-8 Support Enabled
INFO - 2017-12-26 21:02:25 --> Utf8 Class Initialized
INFO - 2017-12-26 21:02:25 --> URI Class Initialized
INFO - 2017-12-26 21:02:25 --> Router Class Initialized
INFO - 2017-12-26 21:02:25 --> Output Class Initialized
INFO - 2017-12-26 21:02:25 --> Security Class Initialized
DEBUG - 2017-12-26 21:02:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 21:02:25 --> Input Class Initialized
INFO - 2017-12-26 21:02:25 --> Language Class Initialized
INFO - 2017-12-26 21:02:25 --> Loader Class Initialized
INFO - 2017-12-26 21:02:25 --> Helper loaded: url_helper
INFO - 2017-12-26 21:02:25 --> Helper loaded: form_helper
INFO - 2017-12-26 21:02:25 --> Database Driver Class Initialized
DEBUG - 2017-12-26 21:02:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 21:02:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 21:02:25 --> Form Validation Class Initialized
INFO - 2017-12-26 21:02:25 --> Model Class Initialized
INFO - 2017-12-26 21:02:25 --> Controller Class Initialized
INFO - 2017-12-26 21:02:25 --> Model Class Initialized
INFO - 2017-12-26 21:02:25 --> Model Class Initialized
INFO - 2017-12-26 21:02:25 --> Model Class Initialized
DEBUG - 2017-12-26 21:02:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 21:02:25 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-26 21:02:25 --> Final output sent to browser
DEBUG - 2017-12-26 21:02:25 --> Total execution time: 0.0585
INFO - 2017-12-26 21:02:25 --> Config Class Initialized
INFO - 2017-12-26 21:02:25 --> Hooks Class Initialized
DEBUG - 2017-12-26 21:02:25 --> UTF-8 Support Enabled
INFO - 2017-12-26 21:02:25 --> Utf8 Class Initialized
INFO - 2017-12-26 21:02:25 --> URI Class Initialized
INFO - 2017-12-26 21:02:25 --> Router Class Initialized
INFO - 2017-12-26 21:02:25 --> Output Class Initialized
INFO - 2017-12-26 21:02:25 --> Security Class Initialized
DEBUG - 2017-12-26 21:02:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 21:02:25 --> Input Class Initialized
INFO - 2017-12-26 21:02:25 --> Language Class Initialized
ERROR - 2017-12-26 21:02:25 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-26 21:02:25 --> Config Class Initialized
INFO - 2017-12-26 21:02:25 --> Hooks Class Initialized
INFO - 2017-12-26 21:02:25 --> Config Class Initialized
INFO - 2017-12-26 21:02:25 --> Hooks Class Initialized
DEBUG - 2017-12-26 21:02:25 --> UTF-8 Support Enabled
INFO - 2017-12-26 21:02:25 --> Utf8 Class Initialized
DEBUG - 2017-12-26 21:02:25 --> UTF-8 Support Enabled
INFO - 2017-12-26 21:02:25 --> Utf8 Class Initialized
INFO - 2017-12-26 21:02:25 --> URI Class Initialized
INFO - 2017-12-26 21:02:25 --> URI Class Initialized
INFO - 2017-12-26 21:02:25 --> Router Class Initialized
INFO - 2017-12-26 21:02:25 --> Router Class Initialized
INFO - 2017-12-26 21:02:25 --> Output Class Initialized
INFO - 2017-12-26 21:02:25 --> Output Class Initialized
INFO - 2017-12-26 21:02:25 --> Security Class Initialized
INFO - 2017-12-26 21:02:25 --> Security Class Initialized
DEBUG - 2017-12-26 21:02:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 21:02:25 --> Input Class Initialized
DEBUG - 2017-12-26 21:02:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 21:02:25 --> Input Class Initialized
INFO - 2017-12-26 21:02:25 --> Language Class Initialized
INFO - 2017-12-26 21:02:25 --> Language Class Initialized
ERROR - 2017-12-26 21:02:25 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-26 21:02:25 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-26 21:02:26 --> Config Class Initialized
INFO - 2017-12-26 21:02:26 --> Hooks Class Initialized
DEBUG - 2017-12-26 21:02:26 --> UTF-8 Support Enabled
INFO - 2017-12-26 21:02:26 --> Utf8 Class Initialized
INFO - 2017-12-26 21:02:26 --> URI Class Initialized
INFO - 2017-12-26 21:02:26 --> Router Class Initialized
INFO - 2017-12-26 21:02:26 --> Output Class Initialized
INFO - 2017-12-26 21:02:26 --> Security Class Initialized
DEBUG - 2017-12-26 21:02:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 21:02:26 --> Input Class Initialized
INFO - 2017-12-26 21:02:26 --> Language Class Initialized
INFO - 2017-12-26 21:02:26 --> Loader Class Initialized
INFO - 2017-12-26 21:02:26 --> Helper loaded: url_helper
INFO - 2017-12-26 21:02:26 --> Helper loaded: form_helper
INFO - 2017-12-26 21:02:26 --> Database Driver Class Initialized
DEBUG - 2017-12-26 21:02:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 21:02:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 21:02:26 --> Form Validation Class Initialized
INFO - 2017-12-26 21:02:26 --> Model Class Initialized
INFO - 2017-12-26 21:02:26 --> Controller Class Initialized
INFO - 2017-12-26 21:02:26 --> Model Class Initialized
INFO - 2017-12-26 21:02:26 --> Model Class Initialized
INFO - 2017-12-26 21:02:26 --> Model Class Initialized
DEBUG - 2017-12-26 21:02:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 21:02:31 --> Config Class Initialized
INFO - 2017-12-26 21:02:31 --> Hooks Class Initialized
DEBUG - 2017-12-26 21:02:31 --> UTF-8 Support Enabled
INFO - 2017-12-26 21:02:31 --> Utf8 Class Initialized
INFO - 2017-12-26 21:02:31 --> URI Class Initialized
INFO - 2017-12-26 21:02:31 --> Router Class Initialized
INFO - 2017-12-26 21:02:31 --> Output Class Initialized
INFO - 2017-12-26 21:02:31 --> Security Class Initialized
DEBUG - 2017-12-26 21:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 21:02:31 --> Input Class Initialized
INFO - 2017-12-26 21:02:31 --> Language Class Initialized
INFO - 2017-12-26 21:02:31 --> Loader Class Initialized
INFO - 2017-12-26 21:02:31 --> Helper loaded: url_helper
INFO - 2017-12-26 21:02:31 --> Helper loaded: form_helper
INFO - 2017-12-26 21:02:31 --> Database Driver Class Initialized
DEBUG - 2017-12-26 21:02:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 21:02:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 21:02:31 --> Form Validation Class Initialized
INFO - 2017-12-26 21:02:31 --> Model Class Initialized
INFO - 2017-12-26 21:02:31 --> Controller Class Initialized
INFO - 2017-12-26 21:02:31 --> Model Class Initialized
INFO - 2017-12-26 21:02:31 --> Model Class Initialized
INFO - 2017-12-26 21:02:31 --> Model Class Initialized
DEBUG - 2017-12-26 21:02:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 21:02:31 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-26 21:02:31 --> Final output sent to browser
DEBUG - 2017-12-26 21:02:31 --> Total execution time: 0.1029
INFO - 2017-12-26 21:02:33 --> Config Class Initialized
INFO - 2017-12-26 21:02:33 --> Hooks Class Initialized
DEBUG - 2017-12-26 21:02:33 --> UTF-8 Support Enabled
INFO - 2017-12-26 21:02:33 --> Utf8 Class Initialized
INFO - 2017-12-26 21:02:33 --> URI Class Initialized
INFO - 2017-12-26 21:02:33 --> Router Class Initialized
INFO - 2017-12-26 21:02:33 --> Output Class Initialized
INFO - 2017-12-26 21:02:33 --> Security Class Initialized
DEBUG - 2017-12-26 21:02:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 21:02:33 --> Input Class Initialized
INFO - 2017-12-26 21:02:33 --> Language Class Initialized
ERROR - 2017-12-26 21:02:33 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-26 21:02:33 --> Config Class Initialized
INFO - 2017-12-26 21:02:33 --> Hooks Class Initialized
INFO - 2017-12-26 21:02:33 --> Config Class Initialized
INFO - 2017-12-26 21:02:33 --> Hooks Class Initialized
DEBUG - 2017-12-26 21:02:33 --> UTF-8 Support Enabled
DEBUG - 2017-12-26 21:02:33 --> UTF-8 Support Enabled
INFO - 2017-12-26 21:02:33 --> Utf8 Class Initialized
INFO - 2017-12-26 21:02:33 --> Utf8 Class Initialized
INFO - 2017-12-26 21:02:33 --> URI Class Initialized
INFO - 2017-12-26 21:02:33 --> URI Class Initialized
INFO - 2017-12-26 21:02:33 --> Router Class Initialized
INFO - 2017-12-26 21:02:33 --> Router Class Initialized
INFO - 2017-12-26 21:02:33 --> Output Class Initialized
INFO - 2017-12-26 21:02:33 --> Output Class Initialized
INFO - 2017-12-26 21:02:33 --> Security Class Initialized
INFO - 2017-12-26 21:02:33 --> Security Class Initialized
DEBUG - 2017-12-26 21:02:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-26 21:02:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 21:02:33 --> Input Class Initialized
INFO - 2017-12-26 21:02:33 --> Input Class Initialized
INFO - 2017-12-26 21:02:33 --> Language Class Initialized
INFO - 2017-12-26 21:02:33 --> Language Class Initialized
ERROR - 2017-12-26 21:02:33 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-26 21:02:33 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-26 21:02:33 --> Config Class Initialized
INFO - 2017-12-26 21:02:33 --> Hooks Class Initialized
DEBUG - 2017-12-26 21:02:33 --> UTF-8 Support Enabled
INFO - 2017-12-26 21:02:33 --> Utf8 Class Initialized
INFO - 2017-12-26 21:02:33 --> URI Class Initialized
INFO - 2017-12-26 21:02:33 --> Router Class Initialized
INFO - 2017-12-26 21:02:33 --> Output Class Initialized
INFO - 2017-12-26 21:02:33 --> Security Class Initialized
DEBUG - 2017-12-26 21:02:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 21:02:33 --> Input Class Initialized
INFO - 2017-12-26 21:02:33 --> Language Class Initialized
INFO - 2017-12-26 21:02:33 --> Loader Class Initialized
INFO - 2017-12-26 21:02:33 --> Helper loaded: url_helper
INFO - 2017-12-26 21:02:33 --> Helper loaded: form_helper
INFO - 2017-12-26 21:02:33 --> Database Driver Class Initialized
DEBUG - 2017-12-26 21:02:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 21:02:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 21:02:33 --> Form Validation Class Initialized
INFO - 2017-12-26 21:02:33 --> Model Class Initialized
INFO - 2017-12-26 21:02:33 --> Controller Class Initialized
INFO - 2017-12-26 21:02:33 --> Model Class Initialized
INFO - 2017-12-26 21:02:33 --> Model Class Initialized
INFO - 2017-12-26 21:02:33 --> Model Class Initialized
DEBUG - 2017-12-26 21:02:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 21:02:41 --> Config Class Initialized
INFO - 2017-12-26 21:02:41 --> Hooks Class Initialized
DEBUG - 2017-12-26 21:02:41 --> UTF-8 Support Enabled
INFO - 2017-12-26 21:02:41 --> Utf8 Class Initialized
INFO - 2017-12-26 21:02:41 --> URI Class Initialized
INFO - 2017-12-26 21:02:41 --> Router Class Initialized
INFO - 2017-12-26 21:02:41 --> Output Class Initialized
INFO - 2017-12-26 21:02:41 --> Security Class Initialized
DEBUG - 2017-12-26 21:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 21:02:41 --> Input Class Initialized
INFO - 2017-12-26 21:02:41 --> Language Class Initialized
INFO - 2017-12-26 21:02:41 --> Loader Class Initialized
INFO - 2017-12-26 21:02:41 --> Helper loaded: url_helper
INFO - 2017-12-26 21:02:41 --> Helper loaded: form_helper
INFO - 2017-12-26 21:02:41 --> Database Driver Class Initialized
DEBUG - 2017-12-26 21:02:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 21:02:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 21:02:41 --> Form Validation Class Initialized
INFO - 2017-12-26 21:02:41 --> Model Class Initialized
INFO - 2017-12-26 21:02:41 --> Controller Class Initialized
INFO - 2017-12-26 21:02:41 --> Model Class Initialized
INFO - 2017-12-26 21:02:41 --> Model Class Initialized
INFO - 2017-12-26 21:02:41 --> Model Class Initialized
DEBUG - 2017-12-26 21:02:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 21:02:41 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-26 21:02:41 --> Final output sent to browser
DEBUG - 2017-12-26 21:02:41 --> Total execution time: 0.1479
INFO - 2017-12-26 21:02:41 --> Config Class Initialized
INFO - 2017-12-26 21:02:41 --> Hooks Class Initialized
DEBUG - 2017-12-26 21:02:41 --> UTF-8 Support Enabled
INFO - 2017-12-26 21:02:41 --> Utf8 Class Initialized
INFO - 2017-12-26 21:02:41 --> URI Class Initialized
INFO - 2017-12-26 21:02:41 --> Router Class Initialized
INFO - 2017-12-26 21:02:41 --> Output Class Initialized
INFO - 2017-12-26 21:02:41 --> Security Class Initialized
DEBUG - 2017-12-26 21:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 21:02:41 --> Input Class Initialized
INFO - 2017-12-26 21:02:41 --> Language Class Initialized
ERROR - 2017-12-26 21:02:41 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-26 21:02:41 --> Config Class Initialized
INFO - 2017-12-26 21:02:41 --> Hooks Class Initialized
INFO - 2017-12-26 21:02:41 --> Config Class Initialized
INFO - 2017-12-26 21:02:41 --> Hooks Class Initialized
DEBUG - 2017-12-26 21:02:41 --> UTF-8 Support Enabled
INFO - 2017-12-26 21:02:41 --> Utf8 Class Initialized
DEBUG - 2017-12-26 21:02:41 --> UTF-8 Support Enabled
INFO - 2017-12-26 21:02:41 --> URI Class Initialized
INFO - 2017-12-26 21:02:41 --> Utf8 Class Initialized
INFO - 2017-12-26 21:02:41 --> URI Class Initialized
INFO - 2017-12-26 21:02:41 --> Router Class Initialized
INFO - 2017-12-26 21:02:41 --> Router Class Initialized
INFO - 2017-12-26 21:02:41 --> Output Class Initialized
INFO - 2017-12-26 21:02:41 --> Output Class Initialized
INFO - 2017-12-26 21:02:41 --> Security Class Initialized
INFO - 2017-12-26 21:02:41 --> Security Class Initialized
DEBUG - 2017-12-26 21:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 21:02:41 --> Input Class Initialized
DEBUG - 2017-12-26 21:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 21:02:41 --> Input Class Initialized
INFO - 2017-12-26 21:02:41 --> Language Class Initialized
INFO - 2017-12-26 21:02:41 --> Language Class Initialized
ERROR - 2017-12-26 21:02:41 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-26 21:02:41 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-26 21:02:41 --> Config Class Initialized
INFO - 2017-12-26 21:02:41 --> Hooks Class Initialized
DEBUG - 2017-12-26 21:02:41 --> UTF-8 Support Enabled
INFO - 2017-12-26 21:02:41 --> Utf8 Class Initialized
INFO - 2017-12-26 21:02:41 --> URI Class Initialized
INFO - 2017-12-26 21:02:41 --> Router Class Initialized
INFO - 2017-12-26 21:02:41 --> Output Class Initialized
INFO - 2017-12-26 21:02:41 --> Security Class Initialized
DEBUG - 2017-12-26 21:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 21:02:41 --> Input Class Initialized
INFO - 2017-12-26 21:02:41 --> Language Class Initialized
INFO - 2017-12-26 21:02:41 --> Loader Class Initialized
INFO - 2017-12-26 21:02:41 --> Helper loaded: url_helper
INFO - 2017-12-26 21:02:41 --> Helper loaded: form_helper
INFO - 2017-12-26 21:02:41 --> Database Driver Class Initialized
DEBUG - 2017-12-26 21:02:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 21:02:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 21:02:41 --> Form Validation Class Initialized
INFO - 2017-12-26 21:02:41 --> Model Class Initialized
INFO - 2017-12-26 21:02:41 --> Controller Class Initialized
INFO - 2017-12-26 21:02:41 --> Model Class Initialized
INFO - 2017-12-26 21:02:41 --> Model Class Initialized
INFO - 2017-12-26 21:02:41 --> Model Class Initialized
DEBUG - 2017-12-26 21:02:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 21:02:44 --> Config Class Initialized
INFO - 2017-12-26 21:02:44 --> Hooks Class Initialized
DEBUG - 2017-12-26 21:02:44 --> UTF-8 Support Enabled
INFO - 2017-12-26 21:02:44 --> Utf8 Class Initialized
INFO - 2017-12-26 21:02:44 --> URI Class Initialized
INFO - 2017-12-26 21:02:44 --> Router Class Initialized
INFO - 2017-12-26 21:02:44 --> Output Class Initialized
INFO - 2017-12-26 21:02:44 --> Security Class Initialized
DEBUG - 2017-12-26 21:02:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 21:02:44 --> Input Class Initialized
INFO - 2017-12-26 21:02:44 --> Language Class Initialized
INFO - 2017-12-26 21:02:44 --> Loader Class Initialized
INFO - 2017-12-26 21:02:44 --> Helper loaded: url_helper
INFO - 2017-12-26 21:02:44 --> Helper loaded: form_helper
INFO - 2017-12-26 21:02:44 --> Database Driver Class Initialized
DEBUG - 2017-12-26 21:02:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 21:02:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 21:02:44 --> Form Validation Class Initialized
INFO - 2017-12-26 21:02:44 --> Model Class Initialized
INFO - 2017-12-26 21:02:44 --> Controller Class Initialized
INFO - 2017-12-26 21:02:44 --> Model Class Initialized
INFO - 2017-12-26 21:02:44 --> Model Class Initialized
INFO - 2017-12-26 21:02:44 --> Model Class Initialized
DEBUG - 2017-12-26 21:02:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 21:02:44 --> Config Class Initialized
INFO - 2017-12-26 21:02:44 --> Hooks Class Initialized
DEBUG - 2017-12-26 21:02:44 --> UTF-8 Support Enabled
INFO - 2017-12-26 21:02:44 --> Utf8 Class Initialized
INFO - 2017-12-26 21:02:44 --> URI Class Initialized
INFO - 2017-12-26 21:02:44 --> Router Class Initialized
INFO - 2017-12-26 21:02:44 --> Output Class Initialized
INFO - 2017-12-26 21:02:44 --> Security Class Initialized
DEBUG - 2017-12-26 21:02:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 21:02:44 --> Input Class Initialized
INFO - 2017-12-26 21:02:44 --> Language Class Initialized
INFO - 2017-12-26 21:02:44 --> Loader Class Initialized
INFO - 2017-12-26 21:02:44 --> Helper loaded: url_helper
INFO - 2017-12-26 21:02:44 --> Helper loaded: form_helper
INFO - 2017-12-26 21:02:44 --> Database Driver Class Initialized
DEBUG - 2017-12-26 21:02:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 21:02:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 21:02:44 --> Form Validation Class Initialized
INFO - 2017-12-26 21:02:44 --> Model Class Initialized
INFO - 2017-12-26 21:02:44 --> Controller Class Initialized
INFO - 2017-12-26 21:02:44 --> Model Class Initialized
INFO - 2017-12-26 21:02:44 --> Model Class Initialized
INFO - 2017-12-26 21:02:44 --> Model Class Initialized
DEBUG - 2017-12-26 21:02:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 21:02:51 --> Config Class Initialized
INFO - 2017-12-26 21:02:51 --> Hooks Class Initialized
DEBUG - 2017-12-26 21:02:51 --> UTF-8 Support Enabled
INFO - 2017-12-26 21:02:51 --> Utf8 Class Initialized
INFO - 2017-12-26 21:02:51 --> URI Class Initialized
INFO - 2017-12-26 21:02:51 --> Router Class Initialized
INFO - 2017-12-26 21:02:51 --> Output Class Initialized
INFO - 2017-12-26 21:02:51 --> Security Class Initialized
DEBUG - 2017-12-26 21:02:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 21:02:51 --> Input Class Initialized
INFO - 2017-12-26 21:02:51 --> Language Class Initialized
INFO - 2017-12-26 21:02:51 --> Loader Class Initialized
INFO - 2017-12-26 21:02:51 --> Helper loaded: url_helper
INFO - 2017-12-26 21:02:51 --> Helper loaded: form_helper
INFO - 2017-12-26 21:02:51 --> Database Driver Class Initialized
DEBUG - 2017-12-26 21:02:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 21:02:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 21:02:51 --> Form Validation Class Initialized
INFO - 2017-12-26 21:02:51 --> Model Class Initialized
INFO - 2017-12-26 21:02:51 --> Controller Class Initialized
INFO - 2017-12-26 21:02:51 --> Model Class Initialized
INFO - 2017-12-26 21:02:51 --> Model Class Initialized
INFO - 2017-12-26 21:02:51 --> Model Class Initialized
DEBUG - 2017-12-26 21:02:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 21:02:51 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-26 21:02:51 --> Final output sent to browser
DEBUG - 2017-12-26 21:02:51 --> Total execution time: 0.1028
INFO - 2017-12-26 21:02:51 --> Config Class Initialized
INFO - 2017-12-26 21:02:51 --> Hooks Class Initialized
DEBUG - 2017-12-26 21:02:51 --> UTF-8 Support Enabled
INFO - 2017-12-26 21:02:51 --> Utf8 Class Initialized
INFO - 2017-12-26 21:02:51 --> URI Class Initialized
INFO - 2017-12-26 21:02:51 --> Router Class Initialized
INFO - 2017-12-26 21:02:51 --> Output Class Initialized
INFO - 2017-12-26 21:02:51 --> Security Class Initialized
DEBUG - 2017-12-26 21:02:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 21:02:51 --> Input Class Initialized
INFO - 2017-12-26 21:02:51 --> Language Class Initialized
INFO - 2017-12-26 21:02:51 --> Loader Class Initialized
INFO - 2017-12-26 21:02:51 --> Helper loaded: url_helper
INFO - 2017-12-26 21:02:51 --> Helper loaded: form_helper
INFO - 2017-12-26 21:02:51 --> Database Driver Class Initialized
DEBUG - 2017-12-26 21:02:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 21:02:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 21:02:51 --> Form Validation Class Initialized
INFO - 2017-12-26 21:02:51 --> Model Class Initialized
INFO - 2017-12-26 21:02:51 --> Controller Class Initialized
INFO - 2017-12-26 21:02:51 --> Model Class Initialized
INFO - 2017-12-26 21:02:51 --> Model Class Initialized
INFO - 2017-12-26 21:02:51 --> Model Class Initialized
DEBUG - 2017-12-26 21:02:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 21:02:52 --> Config Class Initialized
INFO - 2017-12-26 21:02:52 --> Hooks Class Initialized
DEBUG - 2017-12-26 21:02:52 --> UTF-8 Support Enabled
INFO - 2017-12-26 21:02:52 --> Utf8 Class Initialized
INFO - 2017-12-26 21:02:52 --> URI Class Initialized
INFO - 2017-12-26 21:02:52 --> Router Class Initialized
INFO - 2017-12-26 21:02:52 --> Output Class Initialized
INFO - 2017-12-26 21:02:52 --> Security Class Initialized
DEBUG - 2017-12-26 21:02:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 21:02:52 --> Input Class Initialized
INFO - 2017-12-26 21:02:52 --> Language Class Initialized
INFO - 2017-12-26 21:02:52 --> Loader Class Initialized
INFO - 2017-12-26 21:02:52 --> Helper loaded: url_helper
INFO - 2017-12-26 21:02:52 --> Helper loaded: form_helper
INFO - 2017-12-26 21:02:52 --> Database Driver Class Initialized
DEBUG - 2017-12-26 21:02:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 21:02:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 21:02:52 --> Form Validation Class Initialized
INFO - 2017-12-26 21:02:52 --> Model Class Initialized
INFO - 2017-12-26 21:02:52 --> Controller Class Initialized
INFO - 2017-12-26 21:02:52 --> Model Class Initialized
INFO - 2017-12-26 21:02:52 --> Model Class Initialized
INFO - 2017-12-26 21:02:52 --> Model Class Initialized
DEBUG - 2017-12-26 21:02:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 21:02:52 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-26 21:02:52 --> Final output sent to browser
DEBUG - 2017-12-26 21:02:52 --> Total execution time: 0.1344
INFO - 2017-12-26 21:02:52 --> Config Class Initialized
INFO - 2017-12-26 21:02:52 --> Hooks Class Initialized
DEBUG - 2017-12-26 21:02:52 --> UTF-8 Support Enabled
INFO - 2017-12-26 21:02:52 --> Utf8 Class Initialized
INFO - 2017-12-26 21:02:52 --> URI Class Initialized
INFO - 2017-12-26 21:02:52 --> Router Class Initialized
INFO - 2017-12-26 21:02:52 --> Output Class Initialized
INFO - 2017-12-26 21:02:52 --> Security Class Initialized
DEBUG - 2017-12-26 21:02:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 21:02:52 --> Input Class Initialized
INFO - 2017-12-26 21:02:52 --> Language Class Initialized
INFO - 2017-12-26 21:02:52 --> Loader Class Initialized
INFO - 2017-12-26 21:02:52 --> Helper loaded: url_helper
INFO - 2017-12-26 21:02:52 --> Helper loaded: form_helper
INFO - 2017-12-26 21:02:52 --> Database Driver Class Initialized
DEBUG - 2017-12-26 21:02:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 21:02:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 21:02:52 --> Form Validation Class Initialized
INFO - 2017-12-26 21:02:52 --> Model Class Initialized
INFO - 2017-12-26 21:02:52 --> Controller Class Initialized
INFO - 2017-12-26 21:02:52 --> Model Class Initialized
INFO - 2017-12-26 21:02:52 --> Model Class Initialized
INFO - 2017-12-26 21:02:52 --> Model Class Initialized
DEBUG - 2017-12-26 21:02:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 21:03:04 --> Config Class Initialized
INFO - 2017-12-26 21:03:04 --> Hooks Class Initialized
DEBUG - 2017-12-26 21:03:04 --> UTF-8 Support Enabled
INFO - 2017-12-26 21:03:04 --> Utf8 Class Initialized
INFO - 2017-12-26 21:03:04 --> URI Class Initialized
INFO - 2017-12-26 21:03:04 --> Router Class Initialized
INFO - 2017-12-26 21:03:04 --> Output Class Initialized
INFO - 2017-12-26 21:03:04 --> Security Class Initialized
DEBUG - 2017-12-26 21:03:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 21:03:04 --> Input Class Initialized
INFO - 2017-12-26 21:03:04 --> Language Class Initialized
INFO - 2017-12-26 21:03:04 --> Loader Class Initialized
INFO - 2017-12-26 21:03:04 --> Helper loaded: url_helper
INFO - 2017-12-26 21:03:04 --> Helper loaded: form_helper
INFO - 2017-12-26 21:03:04 --> Database Driver Class Initialized
DEBUG - 2017-12-26 21:03:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 21:03:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 21:03:04 --> Form Validation Class Initialized
INFO - 2017-12-26 21:03:04 --> Model Class Initialized
INFO - 2017-12-26 21:03:04 --> Controller Class Initialized
INFO - 2017-12-26 21:03:04 --> Model Class Initialized
INFO - 2017-12-26 21:03:04 --> Model Class Initialized
INFO - 2017-12-26 21:03:04 --> Model Class Initialized
DEBUG - 2017-12-26 21:03:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 21:03:04 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-26 21:03:04 --> Final output sent to browser
DEBUG - 2017-12-26 21:03:04 --> Total execution time: 0.1116
INFO - 2017-12-26 21:03:12 --> Config Class Initialized
INFO - 2017-12-26 21:03:12 --> Hooks Class Initialized
DEBUG - 2017-12-26 21:03:12 --> UTF-8 Support Enabled
INFO - 2017-12-26 21:03:12 --> Utf8 Class Initialized
INFO - 2017-12-26 21:03:12 --> URI Class Initialized
INFO - 2017-12-26 21:03:12 --> Router Class Initialized
INFO - 2017-12-26 21:03:12 --> Output Class Initialized
INFO - 2017-12-26 21:03:12 --> Security Class Initialized
DEBUG - 2017-12-26 21:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 21:03:12 --> Input Class Initialized
INFO - 2017-12-26 21:03:12 --> Language Class Initialized
INFO - 2017-12-26 21:03:12 --> Loader Class Initialized
INFO - 2017-12-26 21:03:12 --> Helper loaded: url_helper
INFO - 2017-12-26 21:03:12 --> Helper loaded: form_helper
INFO - 2017-12-26 21:03:12 --> Database Driver Class Initialized
DEBUG - 2017-12-26 21:03:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 21:03:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 21:03:12 --> Form Validation Class Initialized
INFO - 2017-12-26 21:03:12 --> Model Class Initialized
INFO - 2017-12-26 21:03:12 --> Controller Class Initialized
INFO - 2017-12-26 21:03:12 --> Model Class Initialized
INFO - 2017-12-26 21:03:12 --> Model Class Initialized
INFO - 2017-12-26 21:03:12 --> Model Class Initialized
DEBUG - 2017-12-26 21:03:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 21:03:12 --> Config Class Initialized
INFO - 2017-12-26 21:03:12 --> Hooks Class Initialized
DEBUG - 2017-12-26 21:03:12 --> UTF-8 Support Enabled
INFO - 2017-12-26 21:03:12 --> Utf8 Class Initialized
INFO - 2017-12-26 21:03:12 --> URI Class Initialized
INFO - 2017-12-26 21:03:12 --> Router Class Initialized
INFO - 2017-12-26 21:03:12 --> Output Class Initialized
INFO - 2017-12-26 21:03:12 --> Security Class Initialized
DEBUG - 2017-12-26 21:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 21:03:12 --> Input Class Initialized
INFO - 2017-12-26 21:03:12 --> Language Class Initialized
INFO - 2017-12-26 21:03:12 --> Loader Class Initialized
INFO - 2017-12-26 21:03:12 --> Helper loaded: url_helper
INFO - 2017-12-26 21:03:12 --> Helper loaded: form_helper
INFO - 2017-12-26 21:03:12 --> Database Driver Class Initialized
DEBUG - 2017-12-26 21:03:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 21:03:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 21:03:12 --> Form Validation Class Initialized
INFO - 2017-12-26 21:03:12 --> Model Class Initialized
INFO - 2017-12-26 21:03:12 --> Controller Class Initialized
INFO - 2017-12-26 21:03:12 --> Model Class Initialized
INFO - 2017-12-26 21:03:12 --> Model Class Initialized
INFO - 2017-12-26 21:03:12 --> Model Class Initialized
DEBUG - 2017-12-26 21:03:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 21:03:12 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-26 21:03:12 --> Final output sent to browser
DEBUG - 2017-12-26 21:03:12 --> Total execution time: 0.1126
INFO - 2017-12-26 21:03:12 --> Config Class Initialized
INFO - 2017-12-26 21:03:12 --> Hooks Class Initialized
DEBUG - 2017-12-26 21:03:12 --> UTF-8 Support Enabled
INFO - 2017-12-26 21:03:12 --> Utf8 Class Initialized
INFO - 2017-12-26 21:03:12 --> URI Class Initialized
INFO - 2017-12-26 21:03:12 --> Router Class Initialized
INFO - 2017-12-26 21:03:12 --> Output Class Initialized
INFO - 2017-12-26 21:03:12 --> Security Class Initialized
DEBUG - 2017-12-26 21:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 21:03:12 --> Input Class Initialized
INFO - 2017-12-26 21:03:12 --> Language Class Initialized
INFO - 2017-12-26 21:03:12 --> Loader Class Initialized
INFO - 2017-12-26 21:03:12 --> Helper loaded: url_helper
INFO - 2017-12-26 21:03:12 --> Helper loaded: form_helper
INFO - 2017-12-26 21:03:12 --> Database Driver Class Initialized
DEBUG - 2017-12-26 21:03:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 21:03:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 21:03:12 --> Form Validation Class Initialized
INFO - 2017-12-26 21:03:12 --> Model Class Initialized
INFO - 2017-12-26 21:03:12 --> Controller Class Initialized
INFO - 2017-12-26 21:03:12 --> Model Class Initialized
INFO - 2017-12-26 21:03:12 --> Model Class Initialized
INFO - 2017-12-26 21:03:12 --> Model Class Initialized
DEBUG - 2017-12-26 21:03:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 21:03:15 --> Config Class Initialized
INFO - 2017-12-26 21:03:15 --> Hooks Class Initialized
DEBUG - 2017-12-26 21:03:15 --> UTF-8 Support Enabled
INFO - 2017-12-26 21:03:15 --> Utf8 Class Initialized
INFO - 2017-12-26 21:03:15 --> URI Class Initialized
INFO - 2017-12-26 21:03:15 --> Router Class Initialized
INFO - 2017-12-26 21:03:15 --> Output Class Initialized
INFO - 2017-12-26 21:03:15 --> Security Class Initialized
DEBUG - 2017-12-26 21:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 21:03:15 --> Input Class Initialized
INFO - 2017-12-26 21:03:15 --> Language Class Initialized
INFO - 2017-12-26 21:03:15 --> Loader Class Initialized
INFO - 2017-12-26 21:03:15 --> Helper loaded: url_helper
INFO - 2017-12-26 21:03:15 --> Helper loaded: form_helper
INFO - 2017-12-26 21:03:15 --> Database Driver Class Initialized
DEBUG - 2017-12-26 21:03:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 21:03:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 21:03:15 --> Form Validation Class Initialized
INFO - 2017-12-26 21:03:15 --> Model Class Initialized
INFO - 2017-12-26 21:03:15 --> Controller Class Initialized
INFO - 2017-12-26 21:03:15 --> Model Class Initialized
INFO - 2017-12-26 21:03:15 --> Model Class Initialized
INFO - 2017-12-26 21:03:15 --> Model Class Initialized
DEBUG - 2017-12-26 21:03:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 21:03:15 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-26 21:03:15 --> Final output sent to browser
DEBUG - 2017-12-26 21:03:15 --> Total execution time: 0.0612
INFO - 2017-12-26 21:03:15 --> Config Class Initialized
INFO - 2017-12-26 21:03:15 --> Hooks Class Initialized
DEBUG - 2017-12-26 21:03:15 --> UTF-8 Support Enabled
INFO - 2017-12-26 21:03:15 --> Utf8 Class Initialized
INFO - 2017-12-26 21:03:15 --> URI Class Initialized
INFO - 2017-12-26 21:03:15 --> Router Class Initialized
INFO - 2017-12-26 21:03:15 --> Output Class Initialized
INFO - 2017-12-26 21:03:15 --> Security Class Initialized
DEBUG - 2017-12-26 21:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 21:03:15 --> Input Class Initialized
INFO - 2017-12-26 21:03:15 --> Language Class Initialized
INFO - 2017-12-26 21:03:15 --> Loader Class Initialized
INFO - 2017-12-26 21:03:15 --> Helper loaded: url_helper
INFO - 2017-12-26 21:03:15 --> Helper loaded: form_helper
INFO - 2017-12-26 21:03:15 --> Database Driver Class Initialized
DEBUG - 2017-12-26 21:03:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 21:03:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 21:03:15 --> Form Validation Class Initialized
INFO - 2017-12-26 21:03:15 --> Model Class Initialized
INFO - 2017-12-26 21:03:15 --> Controller Class Initialized
INFO - 2017-12-26 21:03:15 --> Model Class Initialized
INFO - 2017-12-26 21:03:15 --> Model Class Initialized
INFO - 2017-12-26 21:03:15 --> Model Class Initialized
DEBUG - 2017-12-26 21:03:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 21:03:39 --> Config Class Initialized
INFO - 2017-12-26 21:03:39 --> Hooks Class Initialized
DEBUG - 2017-12-26 21:03:39 --> UTF-8 Support Enabled
INFO - 2017-12-26 21:03:39 --> Utf8 Class Initialized
INFO - 2017-12-26 21:03:39 --> URI Class Initialized
INFO - 2017-12-26 21:03:39 --> Router Class Initialized
INFO - 2017-12-26 21:03:39 --> Output Class Initialized
INFO - 2017-12-26 21:03:39 --> Security Class Initialized
DEBUG - 2017-12-26 21:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 21:03:39 --> Input Class Initialized
INFO - 2017-12-26 21:03:39 --> Language Class Initialized
INFO - 2017-12-26 21:03:39 --> Loader Class Initialized
INFO - 2017-12-26 21:03:39 --> Helper loaded: url_helper
INFO - 2017-12-26 21:03:39 --> Helper loaded: form_helper
INFO - 2017-12-26 21:03:39 --> Database Driver Class Initialized
DEBUG - 2017-12-26 21:03:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 21:03:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 21:03:39 --> Form Validation Class Initialized
INFO - 2017-12-26 21:03:39 --> Model Class Initialized
INFO - 2017-12-26 21:03:39 --> Controller Class Initialized
INFO - 2017-12-26 21:03:39 --> Model Class Initialized
INFO - 2017-12-26 21:03:39 --> Model Class Initialized
INFO - 2017-12-26 21:03:39 --> Model Class Initialized
DEBUG - 2017-12-26 21:03:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-26 21:03:39 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-26 21:03:39 --> Final output sent to browser
DEBUG - 2017-12-26 21:03:39 --> Total execution time: 0.0653
INFO - 2017-12-26 21:03:40 --> Config Class Initialized
INFO - 2017-12-26 21:03:40 --> Hooks Class Initialized
DEBUG - 2017-12-26 21:03:40 --> UTF-8 Support Enabled
INFO - 2017-12-26 21:03:40 --> Utf8 Class Initialized
INFO - 2017-12-26 21:03:40 --> URI Class Initialized
INFO - 2017-12-26 21:03:40 --> Router Class Initialized
INFO - 2017-12-26 21:03:40 --> Output Class Initialized
INFO - 2017-12-26 21:03:40 --> Security Class Initialized
DEBUG - 2017-12-26 21:03:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-26 21:03:40 --> Input Class Initialized
INFO - 2017-12-26 21:03:40 --> Language Class Initialized
INFO - 2017-12-26 21:03:40 --> Loader Class Initialized
INFO - 2017-12-26 21:03:40 --> Helper loaded: url_helper
INFO - 2017-12-26 21:03:40 --> Helper loaded: form_helper
INFO - 2017-12-26 21:03:40 --> Database Driver Class Initialized
DEBUG - 2017-12-26 21:03:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-26 21:03:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-26 21:03:40 --> Form Validation Class Initialized
INFO - 2017-12-26 21:03:40 --> Model Class Initialized
INFO - 2017-12-26 21:03:40 --> Controller Class Initialized
INFO - 2017-12-26 21:03:40 --> Model Class Initialized
INFO - 2017-12-26 21:03:40 --> Model Class Initialized
INFO - 2017-12-26 21:03:40 --> Model Class Initialized
DEBUG - 2017-12-26 21:03:40 --> Form_validation class already loaded. Second attempt ignored.
