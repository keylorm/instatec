<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-01-12 03:27:24 --> Config Class Initialized
INFO - 2018-01-12 03:27:24 --> Hooks Class Initialized
DEBUG - 2018-01-12 03:27:24 --> UTF-8 Support Enabled
INFO - 2018-01-12 03:27:24 --> Utf8 Class Initialized
INFO - 2018-01-12 03:27:24 --> URI Class Initialized
DEBUG - 2018-01-12 03:27:24 --> No URI present. Default controller set.
INFO - 2018-01-12 03:27:24 --> Router Class Initialized
INFO - 2018-01-12 03:27:24 --> Output Class Initialized
INFO - 2018-01-12 03:27:24 --> Security Class Initialized
DEBUG - 2018-01-12 03:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 03:27:24 --> Input Class Initialized
INFO - 2018-01-12 03:27:24 --> Language Class Initialized
INFO - 2018-01-12 03:27:24 --> Loader Class Initialized
INFO - 2018-01-12 03:27:24 --> Helper loaded: url_helper
INFO - 2018-01-12 03:27:24 --> Helper loaded: form_helper
INFO - 2018-01-12 03:27:24 --> Database Driver Class Initialized
DEBUG - 2018-01-12 03:27:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 03:27:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 03:27:24 --> Form Validation Class Initialized
INFO - 2018-01-12 03:27:24 --> Model Class Initialized
INFO - 2018-01-12 03:27:24 --> Controller Class Initialized
INFO - 2018-01-12 03:27:24 --> Config Class Initialized
INFO - 2018-01-12 03:27:24 --> Hooks Class Initialized
DEBUG - 2018-01-12 03:27:24 --> UTF-8 Support Enabled
INFO - 2018-01-12 03:27:24 --> Utf8 Class Initialized
INFO - 2018-01-12 03:27:24 --> URI Class Initialized
INFO - 2018-01-12 03:27:24 --> Router Class Initialized
INFO - 2018-01-12 03:27:24 --> Output Class Initialized
INFO - 2018-01-12 03:27:24 --> Security Class Initialized
DEBUG - 2018-01-12 03:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 03:27:24 --> Input Class Initialized
INFO - 2018-01-12 03:27:24 --> Language Class Initialized
INFO - 2018-01-12 03:27:24 --> Loader Class Initialized
INFO - 2018-01-12 03:27:24 --> Helper loaded: url_helper
INFO - 2018-01-12 03:27:24 --> Helper loaded: form_helper
INFO - 2018-01-12 03:27:24 --> Database Driver Class Initialized
DEBUG - 2018-01-12 03:27:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 03:27:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 03:27:24 --> Form Validation Class Initialized
INFO - 2018-01-12 03:27:24 --> Model Class Initialized
INFO - 2018-01-12 03:27:24 --> Controller Class Initialized
INFO - 2018-01-12 03:27:24 --> Model Class Initialized
DEBUG - 2018-01-12 03:27:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 03:27:24 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-12 03:27:24 --> Final output sent to browser
DEBUG - 2018-01-12 03:27:24 --> Total execution time: 0.1136
INFO - 2018-01-12 03:27:27 --> Config Class Initialized
INFO - 2018-01-12 03:27:27 --> Hooks Class Initialized
DEBUG - 2018-01-12 03:27:27 --> UTF-8 Support Enabled
INFO - 2018-01-12 03:27:27 --> Utf8 Class Initialized
INFO - 2018-01-12 03:27:27 --> URI Class Initialized
INFO - 2018-01-12 03:27:27 --> Router Class Initialized
INFO - 2018-01-12 03:27:27 --> Output Class Initialized
INFO - 2018-01-12 03:27:27 --> Security Class Initialized
DEBUG - 2018-01-12 03:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 03:27:27 --> Input Class Initialized
INFO - 2018-01-12 03:27:27 --> Language Class Initialized
INFO - 2018-01-12 03:27:27 --> Loader Class Initialized
INFO - 2018-01-12 03:27:27 --> Helper loaded: url_helper
INFO - 2018-01-12 03:27:27 --> Helper loaded: form_helper
INFO - 2018-01-12 03:27:27 --> Database Driver Class Initialized
DEBUG - 2018-01-12 03:27:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 03:27:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 03:27:27 --> Form Validation Class Initialized
INFO - 2018-01-12 03:27:27 --> Model Class Initialized
INFO - 2018-01-12 03:27:27 --> Controller Class Initialized
INFO - 2018-01-12 03:27:27 --> Model Class Initialized
DEBUG - 2018-01-12 03:27:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 03:27:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-01-12 03:27:28 --> Config Class Initialized
INFO - 2018-01-12 03:27:28 --> Hooks Class Initialized
DEBUG - 2018-01-12 03:27:28 --> UTF-8 Support Enabled
INFO - 2018-01-12 03:27:28 --> Utf8 Class Initialized
INFO - 2018-01-12 03:27:28 --> URI Class Initialized
DEBUG - 2018-01-12 03:27:28 --> No URI present. Default controller set.
INFO - 2018-01-12 03:27:28 --> Router Class Initialized
INFO - 2018-01-12 03:27:28 --> Output Class Initialized
INFO - 2018-01-12 03:27:28 --> Security Class Initialized
DEBUG - 2018-01-12 03:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 03:27:28 --> Input Class Initialized
INFO - 2018-01-12 03:27:28 --> Language Class Initialized
INFO - 2018-01-12 03:27:28 --> Loader Class Initialized
INFO - 2018-01-12 03:27:28 --> Helper loaded: url_helper
INFO - 2018-01-12 03:27:28 --> Helper loaded: form_helper
INFO - 2018-01-12 03:27:28 --> Database Driver Class Initialized
DEBUG - 2018-01-12 03:27:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 03:27:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 03:27:28 --> Form Validation Class Initialized
INFO - 2018-01-12 03:27:28 --> Model Class Initialized
INFO - 2018-01-12 03:27:28 --> Controller Class Initialized
INFO - 2018-01-12 03:27:28 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-12 03:27:28 --> Final output sent to browser
DEBUG - 2018-01-12 03:27:28 --> Total execution time: 0.0523
INFO - 2018-01-12 03:27:28 --> Config Class Initialized
INFO - 2018-01-12 03:27:28 --> Hooks Class Initialized
DEBUG - 2018-01-12 03:27:28 --> UTF-8 Support Enabled
INFO - 2018-01-12 03:27:28 --> Utf8 Class Initialized
INFO - 2018-01-12 03:27:28 --> URI Class Initialized
INFO - 2018-01-12 03:27:28 --> Router Class Initialized
INFO - 2018-01-12 03:27:28 --> Output Class Initialized
INFO - 2018-01-12 03:27:28 --> Security Class Initialized
DEBUG - 2018-01-12 03:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 03:27:28 --> Input Class Initialized
INFO - 2018-01-12 03:27:28 --> Language Class Initialized
INFO - 2018-01-12 03:27:28 --> Loader Class Initialized
INFO - 2018-01-12 03:27:28 --> Helper loaded: url_helper
INFO - 2018-01-12 03:27:28 --> Helper loaded: form_helper
INFO - 2018-01-12 03:27:28 --> Database Driver Class Initialized
DEBUG - 2018-01-12 03:27:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 03:27:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 03:27:28 --> Form Validation Class Initialized
INFO - 2018-01-12 03:27:28 --> Model Class Initialized
INFO - 2018-01-12 03:27:28 --> Controller Class Initialized
INFO - 2018-01-12 03:27:28 --> Model Class Initialized
INFO - 2018-01-12 03:27:28 --> Model Class Initialized
INFO - 2018-01-12 03:27:28 --> Model Class Initialized
INFO - 2018-01-12 03:27:28 --> Model Class Initialized
DEBUG - 2018-01-12 03:27:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 03:27:45 --> Config Class Initialized
INFO - 2018-01-12 03:27:45 --> Hooks Class Initialized
DEBUG - 2018-01-12 03:27:45 --> UTF-8 Support Enabled
INFO - 2018-01-12 03:27:45 --> Utf8 Class Initialized
INFO - 2018-01-12 03:27:45 --> URI Class Initialized
INFO - 2018-01-12 03:27:45 --> Router Class Initialized
INFO - 2018-01-12 03:27:45 --> Output Class Initialized
INFO - 2018-01-12 03:27:45 --> Security Class Initialized
DEBUG - 2018-01-12 03:27:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 03:27:45 --> Input Class Initialized
INFO - 2018-01-12 03:27:45 --> Language Class Initialized
INFO - 2018-01-12 03:27:45 --> Loader Class Initialized
INFO - 2018-01-12 03:27:45 --> Helper loaded: url_helper
INFO - 2018-01-12 03:27:45 --> Helper loaded: form_helper
INFO - 2018-01-12 03:27:45 --> Database Driver Class Initialized
DEBUG - 2018-01-12 03:27:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 03:27:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 03:27:45 --> Form Validation Class Initialized
INFO - 2018-01-12 03:27:45 --> Model Class Initialized
INFO - 2018-01-12 03:27:45 --> Controller Class Initialized
INFO - 2018-01-12 03:27:45 --> Model Class Initialized
INFO - 2018-01-12 03:27:45 --> Model Class Initialized
DEBUG - 2018-01-12 03:27:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 03:27:45 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-12 03:27:45 --> Final output sent to browser
DEBUG - 2018-01-12 03:27:45 --> Total execution time: 0.1259
INFO - 2018-01-12 03:27:45 --> Config Class Initialized
INFO - 2018-01-12 03:27:45 --> Hooks Class Initialized
DEBUG - 2018-01-12 03:27:45 --> UTF-8 Support Enabled
INFO - 2018-01-12 03:27:45 --> Utf8 Class Initialized
INFO - 2018-01-12 03:27:45 --> URI Class Initialized
INFO - 2018-01-12 03:27:45 --> Router Class Initialized
INFO - 2018-01-12 03:27:45 --> Output Class Initialized
INFO - 2018-01-12 03:27:45 --> Security Class Initialized
DEBUG - 2018-01-12 03:27:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 03:27:45 --> Input Class Initialized
INFO - 2018-01-12 03:27:45 --> Language Class Initialized
INFO - 2018-01-12 03:27:45 --> Loader Class Initialized
INFO - 2018-01-12 03:27:45 --> Helper loaded: url_helper
INFO - 2018-01-12 03:27:45 --> Helper loaded: form_helper
INFO - 2018-01-12 03:27:45 --> Database Driver Class Initialized
DEBUG - 2018-01-12 03:27:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 03:27:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 03:27:45 --> Form Validation Class Initialized
INFO - 2018-01-12 03:27:45 --> Model Class Initialized
INFO - 2018-01-12 03:27:45 --> Controller Class Initialized
INFO - 2018-01-12 03:27:45 --> Model Class Initialized
INFO - 2018-01-12 03:27:45 --> Model Class Initialized
DEBUG - 2018-01-12 03:27:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 03:27:56 --> Config Class Initialized
INFO - 2018-01-12 03:27:56 --> Hooks Class Initialized
DEBUG - 2018-01-12 03:27:56 --> UTF-8 Support Enabled
INFO - 2018-01-12 03:27:56 --> Utf8 Class Initialized
INFO - 2018-01-12 03:27:56 --> URI Class Initialized
INFO - 2018-01-12 03:27:56 --> Router Class Initialized
INFO - 2018-01-12 03:27:56 --> Output Class Initialized
INFO - 2018-01-12 03:27:56 --> Security Class Initialized
DEBUG - 2018-01-12 03:27:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 03:27:56 --> Input Class Initialized
INFO - 2018-01-12 03:27:56 --> Language Class Initialized
INFO - 2018-01-12 03:27:56 --> Loader Class Initialized
INFO - 2018-01-12 03:27:56 --> Helper loaded: url_helper
INFO - 2018-01-12 03:27:56 --> Helper loaded: form_helper
INFO - 2018-01-12 03:27:56 --> Database Driver Class Initialized
DEBUG - 2018-01-12 03:27:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 03:27:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 03:27:56 --> Form Validation Class Initialized
INFO - 2018-01-12 03:27:56 --> Model Class Initialized
INFO - 2018-01-12 03:27:56 --> Controller Class Initialized
INFO - 2018-01-12 03:27:56 --> Model Class Initialized
INFO - 2018-01-12 03:27:56 --> Model Class Initialized
DEBUG - 2018-01-12 03:27:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 03:29:29 --> Config Class Initialized
INFO - 2018-01-12 03:29:29 --> Hooks Class Initialized
DEBUG - 2018-01-12 03:29:29 --> UTF-8 Support Enabled
INFO - 2018-01-12 03:29:29 --> Utf8 Class Initialized
INFO - 2018-01-12 03:29:29 --> URI Class Initialized
INFO - 2018-01-12 03:29:29 --> Router Class Initialized
INFO - 2018-01-12 03:29:29 --> Output Class Initialized
INFO - 2018-01-12 03:29:29 --> Security Class Initialized
DEBUG - 2018-01-12 03:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 03:29:29 --> Input Class Initialized
INFO - 2018-01-12 03:29:29 --> Language Class Initialized
INFO - 2018-01-12 03:29:29 --> Loader Class Initialized
INFO - 2018-01-12 03:29:29 --> Helper loaded: url_helper
INFO - 2018-01-12 03:29:29 --> Helper loaded: form_helper
INFO - 2018-01-12 03:29:29 --> Database Driver Class Initialized
DEBUG - 2018-01-12 03:29:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 03:29:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 03:29:29 --> Form Validation Class Initialized
INFO - 2018-01-12 03:29:29 --> Model Class Initialized
INFO - 2018-01-12 03:29:29 --> Controller Class Initialized
INFO - 2018-01-12 03:29:29 --> Model Class Initialized
INFO - 2018-01-12 03:29:29 --> Model Class Initialized
DEBUG - 2018-01-12 03:29:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 03:29:29 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-12 03:29:29 --> Final output sent to browser
DEBUG - 2018-01-12 03:29:29 --> Total execution time: 0.3687
INFO - 2018-01-12 03:30:09 --> Config Class Initialized
INFO - 2018-01-12 03:30:09 --> Hooks Class Initialized
DEBUG - 2018-01-12 03:30:09 --> UTF-8 Support Enabled
INFO - 2018-01-12 03:30:09 --> Utf8 Class Initialized
INFO - 2018-01-12 03:30:09 --> URI Class Initialized
INFO - 2018-01-12 03:30:09 --> Router Class Initialized
INFO - 2018-01-12 03:30:09 --> Output Class Initialized
INFO - 2018-01-12 03:30:09 --> Security Class Initialized
DEBUG - 2018-01-12 03:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 03:30:09 --> Input Class Initialized
INFO - 2018-01-12 03:30:09 --> Language Class Initialized
INFO - 2018-01-12 03:30:09 --> Loader Class Initialized
INFO - 2018-01-12 03:30:09 --> Helper loaded: url_helper
INFO - 2018-01-12 03:30:09 --> Helper loaded: form_helper
INFO - 2018-01-12 03:30:09 --> Database Driver Class Initialized
DEBUG - 2018-01-12 03:30:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 03:30:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 03:30:09 --> Form Validation Class Initialized
INFO - 2018-01-12 03:30:09 --> Model Class Initialized
INFO - 2018-01-12 03:30:09 --> Controller Class Initialized
INFO - 2018-01-12 03:30:09 --> Model Class Initialized
INFO - 2018-01-12 03:30:09 --> Model Class Initialized
DEBUG - 2018-01-12 03:30:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 03:30:10 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-12 03:30:10 --> Final output sent to browser
DEBUG - 2018-01-12 03:30:10 --> Total execution time: 0.3993
INFO - 2018-01-12 03:30:12 --> Config Class Initialized
INFO - 2018-01-12 03:30:12 --> Hooks Class Initialized
DEBUG - 2018-01-12 03:30:12 --> UTF-8 Support Enabled
INFO - 2018-01-12 03:30:12 --> Utf8 Class Initialized
INFO - 2018-01-12 03:30:12 --> URI Class Initialized
INFO - 2018-01-12 03:30:12 --> Router Class Initialized
INFO - 2018-01-12 03:30:12 --> Output Class Initialized
INFO - 2018-01-12 03:30:12 --> Security Class Initialized
DEBUG - 2018-01-12 03:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 03:30:12 --> Input Class Initialized
INFO - 2018-01-12 03:30:12 --> Language Class Initialized
INFO - 2018-01-12 03:30:12 --> Loader Class Initialized
INFO - 2018-01-12 03:30:12 --> Helper loaded: url_helper
INFO - 2018-01-12 03:30:12 --> Helper loaded: form_helper
INFO - 2018-01-12 03:30:12 --> Database Driver Class Initialized
DEBUG - 2018-01-12 03:30:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 03:30:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 03:30:12 --> Form Validation Class Initialized
INFO - 2018-01-12 03:30:12 --> Model Class Initialized
INFO - 2018-01-12 03:30:12 --> Controller Class Initialized
INFO - 2018-01-12 03:30:12 --> Model Class Initialized
INFO - 2018-01-12 03:30:12 --> Model Class Initialized
DEBUG - 2018-01-12 03:30:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 03:30:12 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-12 03:30:12 --> Final output sent to browser
DEBUG - 2018-01-12 03:30:12 --> Total execution time: 0.0693
INFO - 2018-01-12 03:30:12 --> Config Class Initialized
INFO - 2018-01-12 03:30:12 --> Hooks Class Initialized
DEBUG - 2018-01-12 03:30:12 --> UTF-8 Support Enabled
INFO - 2018-01-12 03:30:12 --> Utf8 Class Initialized
INFO - 2018-01-12 03:30:12 --> URI Class Initialized
INFO - 2018-01-12 03:30:12 --> Router Class Initialized
INFO - 2018-01-12 03:30:12 --> Output Class Initialized
INFO - 2018-01-12 03:30:12 --> Security Class Initialized
DEBUG - 2018-01-12 03:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 03:30:12 --> Input Class Initialized
INFO - 2018-01-12 03:30:12 --> Language Class Initialized
INFO - 2018-01-12 03:30:12 --> Loader Class Initialized
INFO - 2018-01-12 03:30:12 --> Helper loaded: url_helper
INFO - 2018-01-12 03:30:12 --> Helper loaded: form_helper
INFO - 2018-01-12 03:30:12 --> Database Driver Class Initialized
DEBUG - 2018-01-12 03:30:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 03:30:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 03:30:12 --> Form Validation Class Initialized
INFO - 2018-01-12 03:30:12 --> Model Class Initialized
INFO - 2018-01-12 03:30:12 --> Controller Class Initialized
INFO - 2018-01-12 03:30:12 --> Model Class Initialized
INFO - 2018-01-12 03:30:12 --> Model Class Initialized
DEBUG - 2018-01-12 03:30:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 03:30:18 --> Config Class Initialized
INFO - 2018-01-12 03:30:18 --> Hooks Class Initialized
DEBUG - 2018-01-12 03:30:18 --> UTF-8 Support Enabled
INFO - 2018-01-12 03:30:18 --> Utf8 Class Initialized
INFO - 2018-01-12 03:30:18 --> URI Class Initialized
INFO - 2018-01-12 03:30:18 --> Router Class Initialized
INFO - 2018-01-12 03:30:18 --> Output Class Initialized
INFO - 2018-01-12 03:30:18 --> Security Class Initialized
DEBUG - 2018-01-12 03:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 03:30:18 --> Input Class Initialized
INFO - 2018-01-12 03:30:18 --> Language Class Initialized
INFO - 2018-01-12 03:30:18 --> Loader Class Initialized
INFO - 2018-01-12 03:30:18 --> Helper loaded: url_helper
INFO - 2018-01-12 03:30:18 --> Helper loaded: form_helper
INFO - 2018-01-12 03:30:18 --> Database Driver Class Initialized
DEBUG - 2018-01-12 03:30:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 03:30:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 03:30:18 --> Form Validation Class Initialized
INFO - 2018-01-12 03:30:18 --> Model Class Initialized
INFO - 2018-01-12 03:30:18 --> Controller Class Initialized
INFO - 2018-01-12 03:30:18 --> Model Class Initialized
INFO - 2018-01-12 03:30:18 --> Model Class Initialized
DEBUG - 2018-01-12 03:30:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 03:30:18 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-12 03:30:18 --> Final output sent to browser
DEBUG - 2018-01-12 03:30:18 --> Total execution time: 0.1024
INFO - 2018-01-12 03:30:30 --> Config Class Initialized
INFO - 2018-01-12 03:30:30 --> Hooks Class Initialized
DEBUG - 2018-01-12 03:30:30 --> UTF-8 Support Enabled
INFO - 2018-01-12 03:30:30 --> Utf8 Class Initialized
INFO - 2018-01-12 03:30:30 --> URI Class Initialized
INFO - 2018-01-12 03:30:30 --> Router Class Initialized
INFO - 2018-01-12 03:30:30 --> Output Class Initialized
INFO - 2018-01-12 03:30:30 --> Security Class Initialized
DEBUG - 2018-01-12 03:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 03:30:30 --> Input Class Initialized
INFO - 2018-01-12 03:30:30 --> Language Class Initialized
INFO - 2018-01-12 03:30:30 --> Loader Class Initialized
INFO - 2018-01-12 03:30:30 --> Helper loaded: url_helper
INFO - 2018-01-12 03:30:30 --> Helper loaded: form_helper
INFO - 2018-01-12 03:30:30 --> Database Driver Class Initialized
DEBUG - 2018-01-12 03:30:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 03:30:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 03:30:30 --> Form Validation Class Initialized
INFO - 2018-01-12 03:30:30 --> Model Class Initialized
INFO - 2018-01-12 03:30:30 --> Controller Class Initialized
INFO - 2018-01-12 03:30:30 --> Model Class Initialized
INFO - 2018-01-12 03:30:30 --> Model Class Initialized
DEBUG - 2018-01-12 03:30:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 03:30:30 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-12 03:30:30 --> Final output sent to browser
DEBUG - 2018-01-12 03:30:30 --> Total execution time: 0.0972
INFO - 2018-01-12 03:30:30 --> Config Class Initialized
INFO - 2018-01-12 03:30:30 --> Hooks Class Initialized
DEBUG - 2018-01-12 03:30:30 --> UTF-8 Support Enabled
INFO - 2018-01-12 03:30:30 --> Utf8 Class Initialized
INFO - 2018-01-12 03:30:30 --> URI Class Initialized
INFO - 2018-01-12 03:30:30 --> Router Class Initialized
INFO - 2018-01-12 03:30:30 --> Output Class Initialized
INFO - 2018-01-12 03:30:30 --> Security Class Initialized
DEBUG - 2018-01-12 03:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 03:30:30 --> Input Class Initialized
INFO - 2018-01-12 03:30:30 --> Language Class Initialized
INFO - 2018-01-12 03:30:30 --> Loader Class Initialized
INFO - 2018-01-12 03:30:30 --> Helper loaded: url_helper
INFO - 2018-01-12 03:30:30 --> Helper loaded: form_helper
INFO - 2018-01-12 03:30:30 --> Database Driver Class Initialized
DEBUG - 2018-01-12 03:30:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 03:30:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 03:30:30 --> Form Validation Class Initialized
INFO - 2018-01-12 03:30:30 --> Model Class Initialized
INFO - 2018-01-12 03:30:30 --> Controller Class Initialized
INFO - 2018-01-12 03:30:30 --> Model Class Initialized
INFO - 2018-01-12 03:30:30 --> Model Class Initialized
DEBUG - 2018-01-12 03:30:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 03:30:35 --> Config Class Initialized
INFO - 2018-01-12 03:30:35 --> Hooks Class Initialized
DEBUG - 2018-01-12 03:30:35 --> UTF-8 Support Enabled
INFO - 2018-01-12 03:30:35 --> Utf8 Class Initialized
INFO - 2018-01-12 03:30:35 --> URI Class Initialized
INFO - 2018-01-12 03:30:35 --> Router Class Initialized
INFO - 2018-01-12 03:30:35 --> Output Class Initialized
INFO - 2018-01-12 03:30:35 --> Security Class Initialized
DEBUG - 2018-01-12 03:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 03:30:35 --> Input Class Initialized
INFO - 2018-01-12 03:30:35 --> Language Class Initialized
INFO - 2018-01-12 03:30:35 --> Loader Class Initialized
INFO - 2018-01-12 03:30:35 --> Helper loaded: url_helper
INFO - 2018-01-12 03:30:35 --> Helper loaded: form_helper
INFO - 2018-01-12 03:30:35 --> Database Driver Class Initialized
DEBUG - 2018-01-12 03:30:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 03:30:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 03:30:35 --> Form Validation Class Initialized
INFO - 2018-01-12 03:30:35 --> Model Class Initialized
INFO - 2018-01-12 03:30:35 --> Controller Class Initialized
INFO - 2018-01-12 03:30:35 --> Model Class Initialized
INFO - 2018-01-12 03:30:35 --> Model Class Initialized
DEBUG - 2018-01-12 03:30:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 03:30:36 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-12 03:30:36 --> Final output sent to browser
DEBUG - 2018-01-12 03:30:36 --> Total execution time: 0.1564
INFO - 2018-01-12 03:30:44 --> Config Class Initialized
INFO - 2018-01-12 03:30:44 --> Hooks Class Initialized
DEBUG - 2018-01-12 03:30:44 --> UTF-8 Support Enabled
INFO - 2018-01-12 03:30:44 --> Utf8 Class Initialized
INFO - 2018-01-12 03:30:44 --> URI Class Initialized
INFO - 2018-01-12 03:30:44 --> Router Class Initialized
INFO - 2018-01-12 03:30:44 --> Output Class Initialized
INFO - 2018-01-12 03:30:44 --> Security Class Initialized
DEBUG - 2018-01-12 03:30:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 03:30:44 --> Input Class Initialized
INFO - 2018-01-12 03:30:44 --> Language Class Initialized
INFO - 2018-01-12 03:30:44 --> Loader Class Initialized
INFO - 2018-01-12 03:30:44 --> Helper loaded: url_helper
INFO - 2018-01-12 03:30:44 --> Helper loaded: form_helper
INFO - 2018-01-12 03:30:44 --> Database Driver Class Initialized
DEBUG - 2018-01-12 03:30:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 03:30:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 03:30:44 --> Form Validation Class Initialized
INFO - 2018-01-12 03:30:44 --> Model Class Initialized
INFO - 2018-01-12 03:30:44 --> Controller Class Initialized
INFO - 2018-01-12 03:30:44 --> Model Class Initialized
INFO - 2018-01-12 03:30:44 --> Model Class Initialized
DEBUG - 2018-01-12 03:30:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 03:30:44 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-12 03:30:44 --> Final output sent to browser
DEBUG - 2018-01-12 03:30:44 --> Total execution time: 0.1905
INFO - 2018-01-12 03:30:44 --> Config Class Initialized
INFO - 2018-01-12 03:30:44 --> Hooks Class Initialized
DEBUG - 2018-01-12 03:30:44 --> UTF-8 Support Enabled
INFO - 2018-01-12 03:30:44 --> Utf8 Class Initialized
INFO - 2018-01-12 03:30:44 --> URI Class Initialized
INFO - 2018-01-12 03:30:44 --> Router Class Initialized
INFO - 2018-01-12 03:30:44 --> Output Class Initialized
INFO - 2018-01-12 03:30:44 --> Security Class Initialized
DEBUG - 2018-01-12 03:30:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 03:30:44 --> Input Class Initialized
INFO - 2018-01-12 03:30:44 --> Language Class Initialized
INFO - 2018-01-12 03:30:44 --> Loader Class Initialized
INFO - 2018-01-12 03:30:44 --> Helper loaded: url_helper
INFO - 2018-01-12 03:30:44 --> Helper loaded: form_helper
INFO - 2018-01-12 03:30:44 --> Database Driver Class Initialized
DEBUG - 2018-01-12 03:30:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 03:30:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 03:30:44 --> Form Validation Class Initialized
INFO - 2018-01-12 03:30:44 --> Model Class Initialized
INFO - 2018-01-12 03:30:44 --> Controller Class Initialized
INFO - 2018-01-12 03:30:44 --> Model Class Initialized
INFO - 2018-01-12 03:30:44 --> Model Class Initialized
DEBUG - 2018-01-12 03:30:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 03:31:25 --> Config Class Initialized
INFO - 2018-01-12 03:31:25 --> Hooks Class Initialized
DEBUG - 2018-01-12 03:31:25 --> UTF-8 Support Enabled
INFO - 2018-01-12 03:31:25 --> Utf8 Class Initialized
INFO - 2018-01-12 03:31:25 --> URI Class Initialized
INFO - 2018-01-12 03:31:25 --> Router Class Initialized
INFO - 2018-01-12 03:31:25 --> Output Class Initialized
INFO - 2018-01-12 03:31:25 --> Security Class Initialized
DEBUG - 2018-01-12 03:31:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 03:31:25 --> Input Class Initialized
INFO - 2018-01-12 03:31:25 --> Language Class Initialized
INFO - 2018-01-12 03:31:25 --> Loader Class Initialized
INFO - 2018-01-12 03:31:25 --> Helper loaded: url_helper
INFO - 2018-01-12 03:31:25 --> Helper loaded: form_helper
INFO - 2018-01-12 03:31:25 --> Database Driver Class Initialized
DEBUG - 2018-01-12 03:31:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 03:31:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 03:31:25 --> Form Validation Class Initialized
INFO - 2018-01-12 03:31:25 --> Model Class Initialized
INFO - 2018-01-12 03:31:25 --> Controller Class Initialized
INFO - 2018-01-12 03:31:25 --> Model Class Initialized
INFO - 2018-01-12 03:31:25 --> Model Class Initialized
DEBUG - 2018-01-12 03:31:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 03:31:25 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-12 03:31:25 --> Final output sent to browser
DEBUG - 2018-01-12 03:31:25 --> Total execution time: 0.3732
INFO - 2018-01-12 03:31:33 --> Config Class Initialized
INFO - 2018-01-12 03:31:33 --> Hooks Class Initialized
DEBUG - 2018-01-12 03:31:33 --> UTF-8 Support Enabled
INFO - 2018-01-12 03:31:33 --> Utf8 Class Initialized
INFO - 2018-01-12 03:31:33 --> URI Class Initialized
INFO - 2018-01-12 03:31:33 --> Router Class Initialized
INFO - 2018-01-12 03:31:33 --> Output Class Initialized
INFO - 2018-01-12 03:31:33 --> Security Class Initialized
DEBUG - 2018-01-12 03:31:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 03:31:33 --> Input Class Initialized
INFO - 2018-01-12 03:31:33 --> Language Class Initialized
INFO - 2018-01-12 03:31:33 --> Loader Class Initialized
INFO - 2018-01-12 03:31:33 --> Helper loaded: url_helper
INFO - 2018-01-12 03:31:33 --> Helper loaded: form_helper
INFO - 2018-01-12 03:31:33 --> Database Driver Class Initialized
DEBUG - 2018-01-12 03:31:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 03:31:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 03:31:33 --> Form Validation Class Initialized
INFO - 2018-01-12 03:31:33 --> Model Class Initialized
INFO - 2018-01-12 03:31:33 --> Controller Class Initialized
INFO - 2018-01-12 03:31:33 --> Model Class Initialized
INFO - 2018-01-12 03:31:33 --> Model Class Initialized
DEBUG - 2018-01-12 03:31:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 03:31:33 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-12 03:31:33 --> Final output sent to browser
DEBUG - 2018-01-12 03:31:33 --> Total execution time: 0.0957
INFO - 2018-01-12 03:31:33 --> Config Class Initialized
INFO - 2018-01-12 03:31:33 --> Hooks Class Initialized
DEBUG - 2018-01-12 03:31:33 --> UTF-8 Support Enabled
INFO - 2018-01-12 03:31:33 --> Utf8 Class Initialized
INFO - 2018-01-12 03:31:33 --> URI Class Initialized
INFO - 2018-01-12 03:31:33 --> Router Class Initialized
INFO - 2018-01-12 03:31:33 --> Output Class Initialized
INFO - 2018-01-12 03:31:33 --> Security Class Initialized
DEBUG - 2018-01-12 03:31:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 03:31:33 --> Input Class Initialized
INFO - 2018-01-12 03:31:33 --> Language Class Initialized
INFO - 2018-01-12 03:31:33 --> Loader Class Initialized
INFO - 2018-01-12 03:31:33 --> Helper loaded: url_helper
INFO - 2018-01-12 03:31:33 --> Helper loaded: form_helper
INFO - 2018-01-12 03:31:33 --> Database Driver Class Initialized
DEBUG - 2018-01-12 03:31:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 03:31:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 03:31:33 --> Form Validation Class Initialized
INFO - 2018-01-12 03:31:33 --> Model Class Initialized
INFO - 2018-01-12 03:31:33 --> Controller Class Initialized
INFO - 2018-01-12 03:31:33 --> Model Class Initialized
INFO - 2018-01-12 03:31:33 --> Model Class Initialized
DEBUG - 2018-01-12 03:31:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 03:32:40 --> Config Class Initialized
INFO - 2018-01-12 03:32:40 --> Hooks Class Initialized
DEBUG - 2018-01-12 03:32:40 --> UTF-8 Support Enabled
INFO - 2018-01-12 03:32:40 --> Utf8 Class Initialized
INFO - 2018-01-12 03:32:40 --> URI Class Initialized
INFO - 2018-01-12 03:32:40 --> Router Class Initialized
INFO - 2018-01-12 03:32:40 --> Output Class Initialized
INFO - 2018-01-12 03:32:40 --> Security Class Initialized
DEBUG - 2018-01-12 03:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 03:32:40 --> Input Class Initialized
INFO - 2018-01-12 03:32:40 --> Language Class Initialized
INFO - 2018-01-12 03:32:40 --> Loader Class Initialized
INFO - 2018-01-12 03:32:40 --> Helper loaded: url_helper
INFO - 2018-01-12 03:32:40 --> Helper loaded: form_helper
INFO - 2018-01-12 03:32:40 --> Database Driver Class Initialized
DEBUG - 2018-01-12 03:32:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 03:32:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 03:32:40 --> Form Validation Class Initialized
INFO - 2018-01-12 03:32:40 --> Model Class Initialized
INFO - 2018-01-12 03:32:40 --> Controller Class Initialized
INFO - 2018-01-12 03:32:40 --> Model Class Initialized
INFO - 2018-01-12 03:32:40 --> Model Class Initialized
DEBUG - 2018-01-12 03:32:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 03:32:40 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-12 03:32:40 --> Final output sent to browser
DEBUG - 2018-01-12 03:32:40 --> Total execution time: 0.4453
INFO - 2018-01-12 03:32:47 --> Config Class Initialized
INFO - 2018-01-12 03:32:47 --> Hooks Class Initialized
DEBUG - 2018-01-12 03:32:47 --> UTF-8 Support Enabled
INFO - 2018-01-12 03:32:47 --> Utf8 Class Initialized
INFO - 2018-01-12 03:32:47 --> URI Class Initialized
INFO - 2018-01-12 03:32:47 --> Router Class Initialized
INFO - 2018-01-12 03:32:47 --> Output Class Initialized
INFO - 2018-01-12 03:32:47 --> Security Class Initialized
DEBUG - 2018-01-12 03:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 03:32:47 --> Input Class Initialized
INFO - 2018-01-12 03:32:47 --> Language Class Initialized
INFO - 2018-01-12 03:32:47 --> Loader Class Initialized
INFO - 2018-01-12 03:32:47 --> Helper loaded: url_helper
INFO - 2018-01-12 03:32:47 --> Helper loaded: form_helper
INFO - 2018-01-12 03:32:47 --> Database Driver Class Initialized
DEBUG - 2018-01-12 03:32:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 03:32:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 03:32:47 --> Form Validation Class Initialized
INFO - 2018-01-12 03:32:47 --> Model Class Initialized
INFO - 2018-01-12 03:32:47 --> Controller Class Initialized
INFO - 2018-01-12 03:32:47 --> Model Class Initialized
INFO - 2018-01-12 03:32:47 --> Model Class Initialized
DEBUG - 2018-01-12 03:32:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 03:32:47 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-12 03:32:47 --> Final output sent to browser
DEBUG - 2018-01-12 03:32:47 --> Total execution time: 0.0821
INFO - 2018-01-12 03:32:47 --> Config Class Initialized
INFO - 2018-01-12 03:32:47 --> Hooks Class Initialized
DEBUG - 2018-01-12 03:32:47 --> UTF-8 Support Enabled
INFO - 2018-01-12 03:32:47 --> Utf8 Class Initialized
INFO - 2018-01-12 03:32:47 --> URI Class Initialized
INFO - 2018-01-12 03:32:47 --> Router Class Initialized
INFO - 2018-01-12 03:32:47 --> Output Class Initialized
INFO - 2018-01-12 03:32:47 --> Security Class Initialized
DEBUG - 2018-01-12 03:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 03:32:47 --> Input Class Initialized
INFO - 2018-01-12 03:32:47 --> Language Class Initialized
INFO - 2018-01-12 03:32:47 --> Loader Class Initialized
INFO - 2018-01-12 03:32:47 --> Helper loaded: url_helper
INFO - 2018-01-12 03:32:47 --> Helper loaded: form_helper
INFO - 2018-01-12 03:32:47 --> Database Driver Class Initialized
DEBUG - 2018-01-12 03:32:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 03:32:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 03:32:47 --> Form Validation Class Initialized
INFO - 2018-01-12 03:32:47 --> Model Class Initialized
INFO - 2018-01-12 03:32:47 --> Controller Class Initialized
INFO - 2018-01-12 03:32:47 --> Model Class Initialized
INFO - 2018-01-12 03:32:47 --> Model Class Initialized
DEBUG - 2018-01-12 03:32:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 03:32:49 --> Config Class Initialized
INFO - 2018-01-12 03:32:49 --> Hooks Class Initialized
DEBUG - 2018-01-12 03:32:49 --> UTF-8 Support Enabled
INFO - 2018-01-12 03:32:49 --> Utf8 Class Initialized
INFO - 2018-01-12 03:32:49 --> URI Class Initialized
INFO - 2018-01-12 03:32:49 --> Router Class Initialized
INFO - 2018-01-12 03:32:49 --> Output Class Initialized
INFO - 2018-01-12 03:32:49 --> Security Class Initialized
DEBUG - 2018-01-12 03:32:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 03:32:49 --> Input Class Initialized
INFO - 2018-01-12 03:32:49 --> Language Class Initialized
INFO - 2018-01-12 03:32:49 --> Loader Class Initialized
INFO - 2018-01-12 03:32:49 --> Helper loaded: url_helper
INFO - 2018-01-12 03:32:49 --> Helper loaded: form_helper
INFO - 2018-01-12 03:32:49 --> Database Driver Class Initialized
DEBUG - 2018-01-12 03:32:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 03:32:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 03:32:49 --> Form Validation Class Initialized
INFO - 2018-01-12 03:32:49 --> Model Class Initialized
INFO - 2018-01-12 03:32:49 --> Controller Class Initialized
INFO - 2018-01-12 03:32:49 --> Model Class Initialized
INFO - 2018-01-12 03:32:49 --> Model Class Initialized
DEBUG - 2018-01-12 03:32:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 03:32:49 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-12 03:32:49 --> Final output sent to browser
DEBUG - 2018-01-12 03:32:49 --> Total execution time: 0.0800
INFO - 2018-01-12 03:32:52 --> Config Class Initialized
INFO - 2018-01-12 03:32:52 --> Hooks Class Initialized
DEBUG - 2018-01-12 03:32:52 --> UTF-8 Support Enabled
INFO - 2018-01-12 03:32:52 --> Utf8 Class Initialized
INFO - 2018-01-12 03:32:52 --> URI Class Initialized
INFO - 2018-01-12 03:32:52 --> Router Class Initialized
INFO - 2018-01-12 03:32:52 --> Output Class Initialized
INFO - 2018-01-12 03:32:52 --> Security Class Initialized
DEBUG - 2018-01-12 03:32:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 03:32:52 --> Input Class Initialized
INFO - 2018-01-12 03:32:52 --> Language Class Initialized
INFO - 2018-01-12 03:32:52 --> Loader Class Initialized
INFO - 2018-01-12 03:32:52 --> Helper loaded: url_helper
INFO - 2018-01-12 03:32:52 --> Helper loaded: form_helper
INFO - 2018-01-12 03:32:53 --> Database Driver Class Initialized
DEBUG - 2018-01-12 03:32:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 03:32:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 03:32:53 --> Form Validation Class Initialized
INFO - 2018-01-12 03:32:53 --> Model Class Initialized
INFO - 2018-01-12 03:32:53 --> Controller Class Initialized
INFO - 2018-01-12 03:32:53 --> Model Class Initialized
INFO - 2018-01-12 03:32:53 --> Model Class Initialized
DEBUG - 2018-01-12 03:32:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 03:32:53 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-12 03:32:53 --> Final output sent to browser
DEBUG - 2018-01-12 03:32:53 --> Total execution time: 0.1176
INFO - 2018-01-12 03:32:53 --> Config Class Initialized
INFO - 2018-01-12 03:32:53 --> Hooks Class Initialized
DEBUG - 2018-01-12 03:32:53 --> UTF-8 Support Enabled
INFO - 2018-01-12 03:32:53 --> Utf8 Class Initialized
INFO - 2018-01-12 03:32:53 --> URI Class Initialized
INFO - 2018-01-12 03:32:53 --> Router Class Initialized
INFO - 2018-01-12 03:32:53 --> Output Class Initialized
INFO - 2018-01-12 03:32:53 --> Security Class Initialized
DEBUG - 2018-01-12 03:32:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 03:32:53 --> Input Class Initialized
INFO - 2018-01-12 03:32:53 --> Language Class Initialized
INFO - 2018-01-12 03:32:53 --> Loader Class Initialized
INFO - 2018-01-12 03:32:53 --> Helper loaded: url_helper
INFO - 2018-01-12 03:32:53 --> Helper loaded: form_helper
INFO - 2018-01-12 03:32:53 --> Database Driver Class Initialized
DEBUG - 2018-01-12 03:32:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 03:32:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 03:32:53 --> Form Validation Class Initialized
INFO - 2018-01-12 03:32:53 --> Model Class Initialized
INFO - 2018-01-12 03:32:53 --> Controller Class Initialized
INFO - 2018-01-12 03:32:53 --> Model Class Initialized
INFO - 2018-01-12 03:32:53 --> Model Class Initialized
DEBUG - 2018-01-12 03:32:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 03:33:38 --> Config Class Initialized
INFO - 2018-01-12 03:33:38 --> Hooks Class Initialized
DEBUG - 2018-01-12 03:33:38 --> UTF-8 Support Enabled
INFO - 2018-01-12 03:33:38 --> Utf8 Class Initialized
INFO - 2018-01-12 03:33:38 --> URI Class Initialized
INFO - 2018-01-12 03:33:38 --> Router Class Initialized
INFO - 2018-01-12 03:33:38 --> Output Class Initialized
INFO - 2018-01-12 03:33:38 --> Security Class Initialized
DEBUG - 2018-01-12 03:33:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 03:33:38 --> Input Class Initialized
INFO - 2018-01-12 03:33:38 --> Language Class Initialized
INFO - 2018-01-12 03:33:38 --> Loader Class Initialized
INFO - 2018-01-12 03:33:38 --> Helper loaded: url_helper
INFO - 2018-01-12 03:33:38 --> Helper loaded: form_helper
INFO - 2018-01-12 03:33:38 --> Database Driver Class Initialized
DEBUG - 2018-01-12 03:33:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 03:33:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 03:33:38 --> Form Validation Class Initialized
INFO - 2018-01-12 03:33:38 --> Model Class Initialized
INFO - 2018-01-12 03:33:38 --> Controller Class Initialized
INFO - 2018-01-12 03:33:38 --> Model Class Initialized
INFO - 2018-01-12 03:33:38 --> Model Class Initialized
DEBUG - 2018-01-12 03:33:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 03:33:41 --> Config Class Initialized
INFO - 2018-01-12 03:33:41 --> Hooks Class Initialized
DEBUG - 2018-01-12 03:33:41 --> UTF-8 Support Enabled
INFO - 2018-01-12 03:33:41 --> Utf8 Class Initialized
INFO - 2018-01-12 03:33:41 --> URI Class Initialized
INFO - 2018-01-12 03:33:41 --> Router Class Initialized
INFO - 2018-01-12 03:33:41 --> Output Class Initialized
INFO - 2018-01-12 03:33:41 --> Security Class Initialized
DEBUG - 2018-01-12 03:33:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 03:33:41 --> Input Class Initialized
INFO - 2018-01-12 03:33:41 --> Language Class Initialized
INFO - 2018-01-12 03:33:41 --> Loader Class Initialized
INFO - 2018-01-12 03:33:41 --> Helper loaded: url_helper
INFO - 2018-01-12 03:33:41 --> Helper loaded: form_helper
INFO - 2018-01-12 03:33:41 --> Database Driver Class Initialized
DEBUG - 2018-01-12 03:33:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 03:33:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 03:33:41 --> Form Validation Class Initialized
INFO - 2018-01-12 03:33:41 --> Model Class Initialized
INFO - 2018-01-12 03:33:41 --> Controller Class Initialized
INFO - 2018-01-12 03:33:41 --> Model Class Initialized
INFO - 2018-01-12 03:33:41 --> Model Class Initialized
DEBUG - 2018-01-12 03:33:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 03:34:19 --> Config Class Initialized
INFO - 2018-01-12 03:34:19 --> Hooks Class Initialized
DEBUG - 2018-01-12 03:34:19 --> UTF-8 Support Enabled
INFO - 2018-01-12 03:34:19 --> Utf8 Class Initialized
INFO - 2018-01-12 03:34:19 --> URI Class Initialized
INFO - 2018-01-12 03:34:19 --> Router Class Initialized
INFO - 2018-01-12 03:34:19 --> Output Class Initialized
INFO - 2018-01-12 03:34:19 --> Security Class Initialized
DEBUG - 2018-01-12 03:34:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 03:34:19 --> Input Class Initialized
INFO - 2018-01-12 03:34:19 --> Language Class Initialized
INFO - 2018-01-12 03:34:19 --> Loader Class Initialized
INFO - 2018-01-12 03:34:19 --> Helper loaded: url_helper
INFO - 2018-01-12 03:34:19 --> Helper loaded: form_helper
INFO - 2018-01-12 03:34:19 --> Database Driver Class Initialized
DEBUG - 2018-01-12 03:34:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 03:34:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 03:34:19 --> Form Validation Class Initialized
INFO - 2018-01-12 03:34:19 --> Model Class Initialized
INFO - 2018-01-12 03:34:19 --> Controller Class Initialized
INFO - 2018-01-12 03:34:19 --> Model Class Initialized
INFO - 2018-01-12 03:34:19 --> Model Class Initialized
INFO - 2018-01-12 03:34:19 --> Model Class Initialized
INFO - 2018-01-12 03:34:19 --> Model Class Initialized
DEBUG - 2018-01-12 03:34:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 03:34:19 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-12 03:34:19 --> Final output sent to browser
DEBUG - 2018-01-12 03:34:19 --> Total execution time: 0.1430
INFO - 2018-01-12 03:34:20 --> Config Class Initialized
INFO - 2018-01-12 03:34:20 --> Hooks Class Initialized
DEBUG - 2018-01-12 03:34:20 --> UTF-8 Support Enabled
INFO - 2018-01-12 03:34:20 --> Utf8 Class Initialized
INFO - 2018-01-12 03:34:20 --> URI Class Initialized
INFO - 2018-01-12 03:34:20 --> Router Class Initialized
INFO - 2018-01-12 03:34:20 --> Output Class Initialized
INFO - 2018-01-12 03:34:20 --> Security Class Initialized
DEBUG - 2018-01-12 03:34:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 03:34:20 --> Input Class Initialized
INFO - 2018-01-12 03:34:20 --> Language Class Initialized
INFO - 2018-01-12 03:34:20 --> Loader Class Initialized
INFO - 2018-01-12 03:34:20 --> Helper loaded: url_helper
INFO - 2018-01-12 03:34:20 --> Helper loaded: form_helper
INFO - 2018-01-12 03:34:20 --> Database Driver Class Initialized
DEBUG - 2018-01-12 03:34:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 03:34:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 03:34:20 --> Form Validation Class Initialized
INFO - 2018-01-12 03:34:20 --> Model Class Initialized
INFO - 2018-01-12 03:34:20 --> Controller Class Initialized
INFO - 2018-01-12 03:34:20 --> Model Class Initialized
INFO - 2018-01-12 03:34:20 --> Model Class Initialized
INFO - 2018-01-12 03:34:20 --> Model Class Initialized
INFO - 2018-01-12 03:34:20 --> Model Class Initialized
DEBUG - 2018-01-12 03:34:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 03:34:24 --> Config Class Initialized
INFO - 2018-01-12 03:34:24 --> Hooks Class Initialized
DEBUG - 2018-01-12 03:34:24 --> UTF-8 Support Enabled
INFO - 2018-01-12 03:34:24 --> Utf8 Class Initialized
INFO - 2018-01-12 03:34:24 --> URI Class Initialized
DEBUG - 2018-01-12 03:34:24 --> No URI present. Default controller set.
INFO - 2018-01-12 03:34:24 --> Router Class Initialized
INFO - 2018-01-12 03:34:24 --> Output Class Initialized
INFO - 2018-01-12 03:34:24 --> Security Class Initialized
DEBUG - 2018-01-12 03:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 03:34:24 --> Input Class Initialized
INFO - 2018-01-12 03:34:24 --> Language Class Initialized
INFO - 2018-01-12 03:34:24 --> Loader Class Initialized
INFO - 2018-01-12 03:34:24 --> Helper loaded: url_helper
INFO - 2018-01-12 03:34:24 --> Helper loaded: form_helper
INFO - 2018-01-12 03:34:24 --> Database Driver Class Initialized
DEBUG - 2018-01-12 03:34:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 03:34:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 03:34:24 --> Form Validation Class Initialized
INFO - 2018-01-12 03:34:24 --> Model Class Initialized
INFO - 2018-01-12 03:34:24 --> Controller Class Initialized
INFO - 2018-01-12 03:34:24 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-12 03:34:24 --> Final output sent to browser
DEBUG - 2018-01-12 03:34:24 --> Total execution time: 0.0714
INFO - 2018-01-12 03:34:25 --> Config Class Initialized
INFO - 2018-01-12 03:34:25 --> Hooks Class Initialized
DEBUG - 2018-01-12 03:34:25 --> UTF-8 Support Enabled
INFO - 2018-01-12 03:34:25 --> Utf8 Class Initialized
INFO - 2018-01-12 03:34:25 --> URI Class Initialized
INFO - 2018-01-12 03:34:25 --> Router Class Initialized
INFO - 2018-01-12 03:34:25 --> Output Class Initialized
INFO - 2018-01-12 03:34:25 --> Security Class Initialized
DEBUG - 2018-01-12 03:34:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 03:34:25 --> Input Class Initialized
INFO - 2018-01-12 03:34:25 --> Language Class Initialized
INFO - 2018-01-12 03:34:25 --> Loader Class Initialized
INFO - 2018-01-12 03:34:25 --> Helper loaded: url_helper
INFO - 2018-01-12 03:34:25 --> Helper loaded: form_helper
INFO - 2018-01-12 03:34:25 --> Database Driver Class Initialized
DEBUG - 2018-01-12 03:34:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 03:34:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 03:34:25 --> Form Validation Class Initialized
INFO - 2018-01-12 03:34:25 --> Model Class Initialized
INFO - 2018-01-12 03:34:25 --> Controller Class Initialized
INFO - 2018-01-12 03:34:25 --> Model Class Initialized
INFO - 2018-01-12 03:34:25 --> Model Class Initialized
INFO - 2018-01-12 03:34:25 --> Model Class Initialized
INFO - 2018-01-12 03:34:25 --> Model Class Initialized
DEBUG - 2018-01-12 03:34:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 03:34:36 --> Config Class Initialized
INFO - 2018-01-12 03:34:36 --> Hooks Class Initialized
DEBUG - 2018-01-12 03:34:36 --> UTF-8 Support Enabled
INFO - 2018-01-12 03:34:36 --> Utf8 Class Initialized
INFO - 2018-01-12 03:34:36 --> URI Class Initialized
INFO - 2018-01-12 03:34:36 --> Router Class Initialized
INFO - 2018-01-12 03:34:36 --> Output Class Initialized
INFO - 2018-01-12 03:34:36 --> Security Class Initialized
DEBUG - 2018-01-12 03:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 03:34:36 --> Input Class Initialized
INFO - 2018-01-12 03:34:36 --> Language Class Initialized
INFO - 2018-01-12 03:34:36 --> Loader Class Initialized
INFO - 2018-01-12 03:34:36 --> Helper loaded: url_helper
INFO - 2018-01-12 03:34:36 --> Helper loaded: form_helper
INFO - 2018-01-12 03:34:36 --> Database Driver Class Initialized
DEBUG - 2018-01-12 03:34:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 03:34:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 03:34:36 --> Form Validation Class Initialized
INFO - 2018-01-12 03:34:36 --> Model Class Initialized
INFO - 2018-01-12 03:34:36 --> Controller Class Initialized
INFO - 2018-01-12 03:34:36 --> Model Class Initialized
INFO - 2018-01-12 03:34:36 --> Model Class Initialized
INFO - 2018-01-12 03:34:36 --> Model Class Initialized
INFO - 2018-01-12 03:34:36 --> Model Class Initialized
DEBUG - 2018-01-12 03:34:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 03:34:36 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-12 03:34:36 --> Final output sent to browser
DEBUG - 2018-01-12 03:34:36 --> Total execution time: 0.0762
INFO - 2018-01-12 03:34:36 --> Config Class Initialized
INFO - 2018-01-12 03:34:36 --> Hooks Class Initialized
DEBUG - 2018-01-12 03:34:36 --> UTF-8 Support Enabled
INFO - 2018-01-12 03:34:36 --> Utf8 Class Initialized
INFO - 2018-01-12 03:34:36 --> URI Class Initialized
INFO - 2018-01-12 03:34:36 --> Router Class Initialized
INFO - 2018-01-12 03:34:36 --> Output Class Initialized
INFO - 2018-01-12 03:34:36 --> Security Class Initialized
DEBUG - 2018-01-12 03:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 03:34:36 --> Input Class Initialized
INFO - 2018-01-12 03:34:36 --> Language Class Initialized
INFO - 2018-01-12 03:34:36 --> Loader Class Initialized
INFO - 2018-01-12 03:34:36 --> Helper loaded: url_helper
INFO - 2018-01-12 03:34:36 --> Helper loaded: form_helper
INFO - 2018-01-12 03:34:36 --> Database Driver Class Initialized
DEBUG - 2018-01-12 03:34:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 03:34:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 03:34:36 --> Form Validation Class Initialized
INFO - 2018-01-12 03:34:36 --> Model Class Initialized
INFO - 2018-01-12 03:34:36 --> Controller Class Initialized
INFO - 2018-01-12 03:34:36 --> Model Class Initialized
INFO - 2018-01-12 03:34:36 --> Model Class Initialized
INFO - 2018-01-12 03:34:36 --> Model Class Initialized
INFO - 2018-01-12 03:34:36 --> Model Class Initialized
DEBUG - 2018-01-12 03:34:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 03:46:02 --> Config Class Initialized
INFO - 2018-01-12 03:46:02 --> Hooks Class Initialized
DEBUG - 2018-01-12 03:46:02 --> UTF-8 Support Enabled
INFO - 2018-01-12 03:46:02 --> Utf8 Class Initialized
INFO - 2018-01-12 03:46:02 --> URI Class Initialized
INFO - 2018-01-12 03:46:02 --> Router Class Initialized
INFO - 2018-01-12 03:46:02 --> Output Class Initialized
INFO - 2018-01-12 03:46:02 --> Security Class Initialized
DEBUG - 2018-01-12 03:46:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 03:46:02 --> Input Class Initialized
INFO - 2018-01-12 03:46:02 --> Language Class Initialized
INFO - 2018-01-12 03:46:02 --> Loader Class Initialized
INFO - 2018-01-12 03:46:02 --> Helper loaded: url_helper
INFO - 2018-01-12 03:46:02 --> Helper loaded: form_helper
INFO - 2018-01-12 03:46:02 --> Database Driver Class Initialized
DEBUG - 2018-01-12 03:46:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 03:46:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 03:46:02 --> Form Validation Class Initialized
INFO - 2018-01-12 03:46:02 --> Model Class Initialized
INFO - 2018-01-12 03:46:02 --> Controller Class Initialized
INFO - 2018-01-12 03:46:02 --> Model Class Initialized
INFO - 2018-01-12 03:46:02 --> Model Class Initialized
INFO - 2018-01-12 03:46:02 --> Model Class Initialized
INFO - 2018-01-12 03:46:02 --> Model Class Initialized
DEBUG - 2018-01-12 03:46:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 03:46:02 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-12 03:46:02 --> Final output sent to browser
DEBUG - 2018-01-12 03:46:02 --> Total execution time: 0.3020
INFO - 2018-01-12 03:47:45 --> Config Class Initialized
INFO - 2018-01-12 03:47:45 --> Hooks Class Initialized
DEBUG - 2018-01-12 03:47:45 --> UTF-8 Support Enabled
INFO - 2018-01-12 03:47:45 --> Utf8 Class Initialized
INFO - 2018-01-12 03:47:45 --> URI Class Initialized
INFO - 2018-01-12 03:47:45 --> Router Class Initialized
INFO - 2018-01-12 03:47:45 --> Output Class Initialized
INFO - 2018-01-12 03:47:45 --> Security Class Initialized
DEBUG - 2018-01-12 03:47:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 03:47:45 --> Input Class Initialized
INFO - 2018-01-12 03:47:45 --> Language Class Initialized
INFO - 2018-01-12 03:47:45 --> Loader Class Initialized
INFO - 2018-01-12 03:47:45 --> Helper loaded: url_helper
INFO - 2018-01-12 03:47:45 --> Helper loaded: form_helper
INFO - 2018-01-12 03:47:45 --> Database Driver Class Initialized
DEBUG - 2018-01-12 03:47:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 03:47:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 03:47:45 --> Form Validation Class Initialized
INFO - 2018-01-12 03:47:45 --> Model Class Initialized
INFO - 2018-01-12 03:47:45 --> Controller Class Initialized
INFO - 2018-01-12 03:47:45 --> Model Class Initialized
INFO - 2018-01-12 03:47:45 --> Model Class Initialized
INFO - 2018-01-12 03:47:45 --> Model Class Initialized
INFO - 2018-01-12 03:47:45 --> Model Class Initialized
DEBUG - 2018-01-12 03:47:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 03:47:45 --> Final output sent to browser
DEBUG - 2018-01-12 03:47:45 --> Total execution time: 0.0803
INFO - 2018-01-12 03:47:47 --> Config Class Initialized
INFO - 2018-01-12 03:47:47 --> Hooks Class Initialized
DEBUG - 2018-01-12 03:47:47 --> UTF-8 Support Enabled
INFO - 2018-01-12 03:47:47 --> Utf8 Class Initialized
INFO - 2018-01-12 03:47:47 --> URI Class Initialized
INFO - 2018-01-12 03:47:47 --> Router Class Initialized
INFO - 2018-01-12 03:47:47 --> Output Class Initialized
INFO - 2018-01-12 03:47:47 --> Security Class Initialized
DEBUG - 2018-01-12 03:47:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 03:47:47 --> Input Class Initialized
INFO - 2018-01-12 03:47:47 --> Language Class Initialized
INFO - 2018-01-12 03:47:47 --> Loader Class Initialized
INFO - 2018-01-12 03:47:47 --> Helper loaded: url_helper
INFO - 2018-01-12 03:47:47 --> Helper loaded: form_helper
INFO - 2018-01-12 03:47:47 --> Database Driver Class Initialized
DEBUG - 2018-01-12 03:47:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 03:47:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 03:47:47 --> Form Validation Class Initialized
INFO - 2018-01-12 03:47:47 --> Model Class Initialized
INFO - 2018-01-12 03:47:47 --> Controller Class Initialized
INFO - 2018-01-12 03:47:47 --> Model Class Initialized
INFO - 2018-01-12 03:47:47 --> Model Class Initialized
INFO - 2018-01-12 03:47:47 --> Model Class Initialized
INFO - 2018-01-12 03:47:47 --> Model Class Initialized
DEBUG - 2018-01-12 03:47:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 03:47:47 --> Final output sent to browser
DEBUG - 2018-01-12 03:47:47 --> Total execution time: 0.0441
INFO - 2018-01-12 03:47:49 --> Config Class Initialized
INFO - 2018-01-12 03:47:49 --> Hooks Class Initialized
DEBUG - 2018-01-12 03:47:49 --> UTF-8 Support Enabled
INFO - 2018-01-12 03:47:49 --> Utf8 Class Initialized
INFO - 2018-01-12 03:47:49 --> URI Class Initialized
INFO - 2018-01-12 03:47:49 --> Router Class Initialized
INFO - 2018-01-12 03:47:49 --> Output Class Initialized
INFO - 2018-01-12 03:47:49 --> Security Class Initialized
DEBUG - 2018-01-12 03:47:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 03:47:49 --> Input Class Initialized
INFO - 2018-01-12 03:47:49 --> Language Class Initialized
INFO - 2018-01-12 03:47:49 --> Loader Class Initialized
INFO - 2018-01-12 03:47:49 --> Helper loaded: url_helper
INFO - 2018-01-12 03:47:49 --> Helper loaded: form_helper
INFO - 2018-01-12 03:47:49 --> Database Driver Class Initialized
DEBUG - 2018-01-12 03:47:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 03:47:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 03:47:49 --> Form Validation Class Initialized
INFO - 2018-01-12 03:47:49 --> Model Class Initialized
INFO - 2018-01-12 03:47:49 --> Controller Class Initialized
INFO - 2018-01-12 03:47:49 --> Model Class Initialized
INFO - 2018-01-12 03:47:49 --> Model Class Initialized
INFO - 2018-01-12 03:47:49 --> Model Class Initialized
INFO - 2018-01-12 03:47:49 --> Model Class Initialized
DEBUG - 2018-01-12 03:47:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 03:47:51 --> Config Class Initialized
INFO - 2018-01-12 03:47:51 --> Hooks Class Initialized
DEBUG - 2018-01-12 03:47:51 --> UTF-8 Support Enabled
INFO - 2018-01-12 03:47:51 --> Utf8 Class Initialized
INFO - 2018-01-12 03:47:51 --> URI Class Initialized
INFO - 2018-01-12 03:47:51 --> Router Class Initialized
INFO - 2018-01-12 03:47:51 --> Output Class Initialized
INFO - 2018-01-12 03:47:51 --> Security Class Initialized
DEBUG - 2018-01-12 03:47:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 03:47:51 --> Input Class Initialized
INFO - 2018-01-12 03:47:51 --> Language Class Initialized
INFO - 2018-01-12 03:47:51 --> Loader Class Initialized
INFO - 2018-01-12 03:47:51 --> Helper loaded: url_helper
INFO - 2018-01-12 03:47:51 --> Helper loaded: form_helper
INFO - 2018-01-12 03:47:51 --> Database Driver Class Initialized
DEBUG - 2018-01-12 03:47:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 03:47:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 03:47:51 --> Form Validation Class Initialized
INFO - 2018-01-12 03:47:51 --> Model Class Initialized
INFO - 2018-01-12 03:47:51 --> Controller Class Initialized
INFO - 2018-01-12 03:47:51 --> Model Class Initialized
INFO - 2018-01-12 03:47:51 --> Model Class Initialized
INFO - 2018-01-12 03:47:51 --> Model Class Initialized
INFO - 2018-01-12 03:47:51 --> Model Class Initialized
DEBUG - 2018-01-12 03:47:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 03:47:55 --> Config Class Initialized
INFO - 2018-01-12 03:47:55 --> Hooks Class Initialized
DEBUG - 2018-01-12 03:47:55 --> UTF-8 Support Enabled
INFO - 2018-01-12 03:47:55 --> Utf8 Class Initialized
INFO - 2018-01-12 03:47:55 --> URI Class Initialized
INFO - 2018-01-12 03:47:55 --> Router Class Initialized
INFO - 2018-01-12 03:47:55 --> Output Class Initialized
INFO - 2018-01-12 03:47:55 --> Security Class Initialized
DEBUG - 2018-01-12 03:47:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 03:47:55 --> Input Class Initialized
INFO - 2018-01-12 03:47:55 --> Language Class Initialized
INFO - 2018-01-12 03:47:55 --> Loader Class Initialized
INFO - 2018-01-12 03:47:55 --> Helper loaded: url_helper
INFO - 2018-01-12 03:47:55 --> Helper loaded: form_helper
INFO - 2018-01-12 03:47:55 --> Database Driver Class Initialized
DEBUG - 2018-01-12 03:47:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 03:47:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 03:47:55 --> Form Validation Class Initialized
INFO - 2018-01-12 03:47:55 --> Model Class Initialized
INFO - 2018-01-12 03:47:55 --> Controller Class Initialized
INFO - 2018-01-12 03:47:55 --> Model Class Initialized
INFO - 2018-01-12 03:47:55 --> Model Class Initialized
INFO - 2018-01-12 03:47:55 --> Model Class Initialized
INFO - 2018-01-12 03:47:55 --> Model Class Initialized
DEBUG - 2018-01-12 03:47:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 03:47:56 --> Config Class Initialized
INFO - 2018-01-12 03:47:56 --> Hooks Class Initialized
DEBUG - 2018-01-12 03:47:56 --> UTF-8 Support Enabled
INFO - 2018-01-12 03:47:56 --> Utf8 Class Initialized
INFO - 2018-01-12 03:47:56 --> URI Class Initialized
INFO - 2018-01-12 03:47:56 --> Router Class Initialized
INFO - 2018-01-12 03:47:56 --> Output Class Initialized
INFO - 2018-01-12 03:47:56 --> Security Class Initialized
DEBUG - 2018-01-12 03:47:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 03:47:56 --> Input Class Initialized
INFO - 2018-01-12 03:47:56 --> Language Class Initialized
INFO - 2018-01-12 03:47:56 --> Loader Class Initialized
INFO - 2018-01-12 03:47:56 --> Helper loaded: url_helper
INFO - 2018-01-12 03:47:56 --> Helper loaded: form_helper
INFO - 2018-01-12 03:47:56 --> Database Driver Class Initialized
DEBUG - 2018-01-12 03:47:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 03:47:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 03:47:56 --> Form Validation Class Initialized
INFO - 2018-01-12 03:47:56 --> Model Class Initialized
INFO - 2018-01-12 03:47:56 --> Controller Class Initialized
INFO - 2018-01-12 03:47:56 --> Model Class Initialized
INFO - 2018-01-12 03:47:56 --> Model Class Initialized
INFO - 2018-01-12 03:47:56 --> Model Class Initialized
INFO - 2018-01-12 03:47:56 --> Model Class Initialized
DEBUG - 2018-01-12 03:47:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 03:47:57 --> Config Class Initialized
INFO - 2018-01-12 03:47:57 --> Hooks Class Initialized
DEBUG - 2018-01-12 03:47:57 --> UTF-8 Support Enabled
INFO - 2018-01-12 03:47:57 --> Utf8 Class Initialized
INFO - 2018-01-12 03:47:57 --> URI Class Initialized
INFO - 2018-01-12 03:47:57 --> Router Class Initialized
INFO - 2018-01-12 03:47:57 --> Output Class Initialized
INFO - 2018-01-12 03:47:57 --> Security Class Initialized
DEBUG - 2018-01-12 03:47:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 03:47:57 --> Input Class Initialized
INFO - 2018-01-12 03:47:57 --> Language Class Initialized
INFO - 2018-01-12 03:47:57 --> Loader Class Initialized
INFO - 2018-01-12 03:47:57 --> Helper loaded: url_helper
INFO - 2018-01-12 03:47:57 --> Helper loaded: form_helper
INFO - 2018-01-12 03:47:57 --> Database Driver Class Initialized
DEBUG - 2018-01-12 03:47:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 03:47:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 03:47:57 --> Form Validation Class Initialized
INFO - 2018-01-12 03:47:57 --> Model Class Initialized
INFO - 2018-01-12 03:47:57 --> Controller Class Initialized
INFO - 2018-01-12 03:47:57 --> Model Class Initialized
INFO - 2018-01-12 03:47:57 --> Model Class Initialized
INFO - 2018-01-12 03:47:57 --> Model Class Initialized
INFO - 2018-01-12 03:47:57 --> Model Class Initialized
DEBUG - 2018-01-12 03:47:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 03:48:39 --> Config Class Initialized
INFO - 2018-01-12 03:48:39 --> Hooks Class Initialized
DEBUG - 2018-01-12 03:48:39 --> UTF-8 Support Enabled
INFO - 2018-01-12 03:48:39 --> Utf8 Class Initialized
INFO - 2018-01-12 03:48:39 --> URI Class Initialized
INFO - 2018-01-12 03:48:39 --> Router Class Initialized
INFO - 2018-01-12 03:48:39 --> Output Class Initialized
INFO - 2018-01-12 03:48:39 --> Security Class Initialized
DEBUG - 2018-01-12 03:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 03:48:39 --> Input Class Initialized
INFO - 2018-01-12 03:48:39 --> Language Class Initialized
INFO - 2018-01-12 03:48:39 --> Loader Class Initialized
INFO - 2018-01-12 03:48:39 --> Helper loaded: url_helper
INFO - 2018-01-12 03:48:39 --> Helper loaded: form_helper
INFO - 2018-01-12 03:48:39 --> Database Driver Class Initialized
DEBUG - 2018-01-12 03:48:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 03:48:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 03:48:39 --> Form Validation Class Initialized
INFO - 2018-01-12 03:48:39 --> Model Class Initialized
INFO - 2018-01-12 03:48:39 --> Controller Class Initialized
INFO - 2018-01-12 03:48:39 --> Model Class Initialized
INFO - 2018-01-12 03:48:39 --> Model Class Initialized
INFO - 2018-01-12 03:48:39 --> Model Class Initialized
INFO - 2018-01-12 03:48:39 --> Model Class Initialized
DEBUG - 2018-01-12 03:48:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 03:48:44 --> Config Class Initialized
INFO - 2018-01-12 03:48:44 --> Hooks Class Initialized
DEBUG - 2018-01-12 03:48:44 --> UTF-8 Support Enabled
INFO - 2018-01-12 03:48:44 --> Utf8 Class Initialized
INFO - 2018-01-12 03:48:44 --> URI Class Initialized
INFO - 2018-01-12 03:48:44 --> Router Class Initialized
INFO - 2018-01-12 03:48:44 --> Output Class Initialized
INFO - 2018-01-12 03:48:44 --> Security Class Initialized
DEBUG - 2018-01-12 03:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 03:48:44 --> Input Class Initialized
INFO - 2018-01-12 03:48:44 --> Language Class Initialized
INFO - 2018-01-12 03:48:44 --> Loader Class Initialized
INFO - 2018-01-12 03:48:44 --> Helper loaded: url_helper
INFO - 2018-01-12 03:48:44 --> Helper loaded: form_helper
INFO - 2018-01-12 03:48:44 --> Database Driver Class Initialized
DEBUG - 2018-01-12 03:48:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 03:48:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 03:48:44 --> Form Validation Class Initialized
INFO - 2018-01-12 03:48:44 --> Model Class Initialized
INFO - 2018-01-12 03:48:44 --> Controller Class Initialized
INFO - 2018-01-12 03:48:44 --> Model Class Initialized
INFO - 2018-01-12 03:48:44 --> Model Class Initialized
INFO - 2018-01-12 03:48:44 --> Model Class Initialized
INFO - 2018-01-12 03:48:44 --> Model Class Initialized
DEBUG - 2018-01-12 03:48:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 03:49:06 --> Config Class Initialized
INFO - 2018-01-12 03:49:06 --> Hooks Class Initialized
DEBUG - 2018-01-12 03:49:06 --> UTF-8 Support Enabled
INFO - 2018-01-12 03:49:06 --> Utf8 Class Initialized
INFO - 2018-01-12 03:49:06 --> URI Class Initialized
INFO - 2018-01-12 03:49:06 --> Router Class Initialized
INFO - 2018-01-12 03:49:06 --> Output Class Initialized
INFO - 2018-01-12 03:49:06 --> Security Class Initialized
DEBUG - 2018-01-12 03:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 03:49:06 --> Input Class Initialized
INFO - 2018-01-12 03:49:06 --> Language Class Initialized
INFO - 2018-01-12 03:49:06 --> Loader Class Initialized
INFO - 2018-01-12 03:49:06 --> Helper loaded: url_helper
INFO - 2018-01-12 03:49:06 --> Helper loaded: form_helper
INFO - 2018-01-12 03:49:06 --> Database Driver Class Initialized
DEBUG - 2018-01-12 03:49:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 03:49:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 03:49:06 --> Form Validation Class Initialized
INFO - 2018-01-12 03:49:06 --> Model Class Initialized
INFO - 2018-01-12 03:49:06 --> Controller Class Initialized
INFO - 2018-01-12 03:49:06 --> Model Class Initialized
INFO - 2018-01-12 03:49:06 --> Model Class Initialized
INFO - 2018-01-12 03:49:06 --> Model Class Initialized
INFO - 2018-01-12 03:49:06 --> Model Class Initialized
DEBUG - 2018-01-12 03:49:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 03:49:09 --> Config Class Initialized
INFO - 2018-01-12 03:49:09 --> Hooks Class Initialized
DEBUG - 2018-01-12 03:49:09 --> UTF-8 Support Enabled
INFO - 2018-01-12 03:49:09 --> Utf8 Class Initialized
INFO - 2018-01-12 03:49:09 --> URI Class Initialized
INFO - 2018-01-12 03:49:09 --> Router Class Initialized
INFO - 2018-01-12 03:49:09 --> Output Class Initialized
INFO - 2018-01-12 03:49:09 --> Security Class Initialized
DEBUG - 2018-01-12 03:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 03:49:09 --> Input Class Initialized
INFO - 2018-01-12 03:49:09 --> Language Class Initialized
INFO - 2018-01-12 03:49:09 --> Loader Class Initialized
INFO - 2018-01-12 03:49:09 --> Helper loaded: url_helper
INFO - 2018-01-12 03:49:09 --> Helper loaded: form_helper
INFO - 2018-01-12 03:49:10 --> Database Driver Class Initialized
DEBUG - 2018-01-12 03:49:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 03:49:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 03:49:10 --> Form Validation Class Initialized
INFO - 2018-01-12 03:49:10 --> Model Class Initialized
INFO - 2018-01-12 03:49:10 --> Controller Class Initialized
INFO - 2018-01-12 03:49:10 --> Model Class Initialized
INFO - 2018-01-12 03:49:10 --> Model Class Initialized
INFO - 2018-01-12 03:49:10 --> Model Class Initialized
INFO - 2018-01-12 03:49:10 --> Model Class Initialized
DEBUG - 2018-01-12 03:49:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 03:49:10 --> Config Class Initialized
INFO - 2018-01-12 03:49:10 --> Hooks Class Initialized
DEBUG - 2018-01-12 03:49:10 --> UTF-8 Support Enabled
INFO - 2018-01-12 03:49:10 --> Utf8 Class Initialized
INFO - 2018-01-12 03:49:10 --> URI Class Initialized
INFO - 2018-01-12 03:49:10 --> Router Class Initialized
INFO - 2018-01-12 03:49:10 --> Output Class Initialized
INFO - 2018-01-12 03:49:10 --> Security Class Initialized
DEBUG - 2018-01-12 03:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 03:49:10 --> Input Class Initialized
INFO - 2018-01-12 03:49:10 --> Language Class Initialized
INFO - 2018-01-12 03:49:10 --> Loader Class Initialized
INFO - 2018-01-12 03:49:10 --> Helper loaded: url_helper
INFO - 2018-01-12 03:49:10 --> Helper loaded: form_helper
INFO - 2018-01-12 03:49:10 --> Database Driver Class Initialized
DEBUG - 2018-01-12 03:49:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 03:49:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 03:49:10 --> Form Validation Class Initialized
INFO - 2018-01-12 03:49:10 --> Model Class Initialized
INFO - 2018-01-12 03:49:10 --> Controller Class Initialized
INFO - 2018-01-12 03:49:10 --> Model Class Initialized
INFO - 2018-01-12 03:49:10 --> Model Class Initialized
INFO - 2018-01-12 03:49:10 --> Model Class Initialized
INFO - 2018-01-12 03:49:10 --> Model Class Initialized
DEBUG - 2018-01-12 03:49:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 03:54:26 --> Config Class Initialized
INFO - 2018-01-12 03:54:26 --> Hooks Class Initialized
DEBUG - 2018-01-12 03:54:26 --> UTF-8 Support Enabled
INFO - 2018-01-12 03:54:26 --> Utf8 Class Initialized
INFO - 2018-01-12 03:54:26 --> URI Class Initialized
INFO - 2018-01-12 03:54:26 --> Router Class Initialized
INFO - 2018-01-12 03:54:26 --> Output Class Initialized
INFO - 2018-01-12 03:54:26 --> Security Class Initialized
DEBUG - 2018-01-12 03:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 03:54:26 --> Input Class Initialized
INFO - 2018-01-12 03:54:26 --> Language Class Initialized
INFO - 2018-01-12 03:54:26 --> Loader Class Initialized
INFO - 2018-01-12 03:54:26 --> Helper loaded: url_helper
INFO - 2018-01-12 03:54:26 --> Helper loaded: form_helper
INFO - 2018-01-12 03:54:26 --> Database Driver Class Initialized
DEBUG - 2018-01-12 03:54:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 03:54:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 03:54:26 --> Form Validation Class Initialized
INFO - 2018-01-12 03:54:26 --> Model Class Initialized
INFO - 2018-01-12 03:54:26 --> Controller Class Initialized
INFO - 2018-01-12 03:54:26 --> Model Class Initialized
INFO - 2018-01-12 03:54:26 --> Model Class Initialized
INFO - 2018-01-12 03:54:26 --> Model Class Initialized
INFO - 2018-01-12 03:54:26 --> Model Class Initialized
DEBUG - 2018-01-12 03:54:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 03:54:27 --> Config Class Initialized
INFO - 2018-01-12 03:54:27 --> Hooks Class Initialized
DEBUG - 2018-01-12 03:54:27 --> UTF-8 Support Enabled
INFO - 2018-01-12 03:54:27 --> Utf8 Class Initialized
INFO - 2018-01-12 03:54:27 --> URI Class Initialized
INFO - 2018-01-12 03:54:27 --> Router Class Initialized
INFO - 2018-01-12 03:54:27 --> Output Class Initialized
INFO - 2018-01-12 03:54:27 --> Security Class Initialized
DEBUG - 2018-01-12 03:54:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 03:54:27 --> Input Class Initialized
INFO - 2018-01-12 03:54:27 --> Language Class Initialized
INFO - 2018-01-12 03:54:27 --> Loader Class Initialized
INFO - 2018-01-12 03:54:27 --> Helper loaded: url_helper
INFO - 2018-01-12 03:54:27 --> Helper loaded: form_helper
INFO - 2018-01-12 03:54:27 --> Database Driver Class Initialized
DEBUG - 2018-01-12 03:54:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 03:54:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 03:54:27 --> Form Validation Class Initialized
INFO - 2018-01-12 03:54:27 --> Model Class Initialized
INFO - 2018-01-12 03:54:27 --> Controller Class Initialized
INFO - 2018-01-12 03:54:27 --> Model Class Initialized
INFO - 2018-01-12 03:54:27 --> Model Class Initialized
INFO - 2018-01-12 03:54:27 --> Model Class Initialized
INFO - 2018-01-12 03:54:27 --> Model Class Initialized
DEBUG - 2018-01-12 03:54:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 03:54:27 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-12 03:54:27 --> Final output sent to browser
DEBUG - 2018-01-12 03:54:27 --> Total execution time: 0.1180
INFO - 2018-01-12 03:54:27 --> Config Class Initialized
INFO - 2018-01-12 03:54:27 --> Hooks Class Initialized
DEBUG - 2018-01-12 03:54:27 --> UTF-8 Support Enabled
INFO - 2018-01-12 03:54:27 --> Utf8 Class Initialized
INFO - 2018-01-12 03:54:27 --> URI Class Initialized
INFO - 2018-01-12 03:54:27 --> Router Class Initialized
INFO - 2018-01-12 03:54:27 --> Output Class Initialized
INFO - 2018-01-12 03:54:27 --> Security Class Initialized
DEBUG - 2018-01-12 03:54:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 03:54:27 --> Input Class Initialized
INFO - 2018-01-12 03:54:27 --> Language Class Initialized
INFO - 2018-01-12 03:54:27 --> Loader Class Initialized
INFO - 2018-01-12 03:54:27 --> Helper loaded: url_helper
INFO - 2018-01-12 03:54:27 --> Helper loaded: form_helper
INFO - 2018-01-12 03:54:27 --> Database Driver Class Initialized
DEBUG - 2018-01-12 03:54:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 03:54:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 03:54:27 --> Form Validation Class Initialized
INFO - 2018-01-12 03:54:27 --> Model Class Initialized
INFO - 2018-01-12 03:54:27 --> Controller Class Initialized
INFO - 2018-01-12 03:54:27 --> Model Class Initialized
INFO - 2018-01-12 03:54:27 --> Model Class Initialized
INFO - 2018-01-12 03:54:27 --> Model Class Initialized
INFO - 2018-01-12 03:54:27 --> Model Class Initialized
DEBUG - 2018-01-12 03:54:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 03:56:02 --> Config Class Initialized
INFO - 2018-01-12 03:56:02 --> Hooks Class Initialized
DEBUG - 2018-01-12 03:56:02 --> UTF-8 Support Enabled
INFO - 2018-01-12 03:56:02 --> Utf8 Class Initialized
INFO - 2018-01-12 03:56:02 --> URI Class Initialized
INFO - 2018-01-12 03:56:02 --> Router Class Initialized
INFO - 2018-01-12 03:56:02 --> Output Class Initialized
INFO - 2018-01-12 03:56:02 --> Security Class Initialized
DEBUG - 2018-01-12 03:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 03:56:02 --> Input Class Initialized
INFO - 2018-01-12 03:56:02 --> Language Class Initialized
INFO - 2018-01-12 03:56:02 --> Loader Class Initialized
INFO - 2018-01-12 03:56:02 --> Helper loaded: url_helper
INFO - 2018-01-12 03:56:02 --> Helper loaded: form_helper
INFO - 2018-01-12 03:56:02 --> Database Driver Class Initialized
DEBUG - 2018-01-12 03:56:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 03:56:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 03:56:02 --> Form Validation Class Initialized
INFO - 2018-01-12 03:56:02 --> Model Class Initialized
INFO - 2018-01-12 03:56:02 --> Controller Class Initialized
INFO - 2018-01-12 03:56:02 --> Model Class Initialized
INFO - 2018-01-12 03:56:02 --> Model Class Initialized
INFO - 2018-01-12 03:56:02 --> Model Class Initialized
INFO - 2018-01-12 03:56:02 --> Model Class Initialized
DEBUG - 2018-01-12 03:56:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 03:56:02 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-12 03:56:02 --> Final output sent to browser
DEBUG - 2018-01-12 03:56:02 --> Total execution time: 0.3177
INFO - 2018-01-12 03:56:02 --> Config Class Initialized
INFO - 2018-01-12 03:56:02 --> Hooks Class Initialized
DEBUG - 2018-01-12 03:56:02 --> UTF-8 Support Enabled
INFO - 2018-01-12 03:56:02 --> Utf8 Class Initialized
INFO - 2018-01-12 03:56:02 --> URI Class Initialized
INFO - 2018-01-12 03:56:02 --> Router Class Initialized
INFO - 2018-01-12 03:56:02 --> Output Class Initialized
INFO - 2018-01-12 03:56:02 --> Security Class Initialized
DEBUG - 2018-01-12 03:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 03:56:02 --> Input Class Initialized
INFO - 2018-01-12 03:56:02 --> Language Class Initialized
INFO - 2018-01-12 03:56:02 --> Loader Class Initialized
INFO - 2018-01-12 03:56:02 --> Helper loaded: url_helper
INFO - 2018-01-12 03:56:02 --> Helper loaded: form_helper
INFO - 2018-01-12 03:56:02 --> Database Driver Class Initialized
DEBUG - 2018-01-12 03:56:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 03:56:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 03:56:02 --> Form Validation Class Initialized
INFO - 2018-01-12 03:56:02 --> Model Class Initialized
INFO - 2018-01-12 03:56:02 --> Controller Class Initialized
INFO - 2018-01-12 03:56:02 --> Model Class Initialized
INFO - 2018-01-12 03:56:02 --> Model Class Initialized
INFO - 2018-01-12 03:56:02 --> Model Class Initialized
INFO - 2018-01-12 03:56:02 --> Model Class Initialized
DEBUG - 2018-01-12 03:56:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 03:56:09 --> Config Class Initialized
INFO - 2018-01-12 03:56:09 --> Hooks Class Initialized
DEBUG - 2018-01-12 03:56:09 --> UTF-8 Support Enabled
INFO - 2018-01-12 03:56:09 --> Utf8 Class Initialized
INFO - 2018-01-12 03:56:09 --> URI Class Initialized
INFO - 2018-01-12 03:56:09 --> Router Class Initialized
INFO - 2018-01-12 03:56:09 --> Output Class Initialized
INFO - 2018-01-12 03:56:09 --> Security Class Initialized
DEBUG - 2018-01-12 03:56:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 03:56:09 --> Input Class Initialized
INFO - 2018-01-12 03:56:09 --> Language Class Initialized
INFO - 2018-01-12 03:56:09 --> Loader Class Initialized
INFO - 2018-01-12 03:56:09 --> Helper loaded: url_helper
INFO - 2018-01-12 03:56:09 --> Helper loaded: form_helper
INFO - 2018-01-12 03:56:09 --> Database Driver Class Initialized
DEBUG - 2018-01-12 03:56:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 03:56:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 03:56:09 --> Form Validation Class Initialized
INFO - 2018-01-12 03:56:09 --> Model Class Initialized
INFO - 2018-01-12 03:56:09 --> Controller Class Initialized
INFO - 2018-01-12 03:56:09 --> Model Class Initialized
INFO - 2018-01-12 03:56:09 --> Model Class Initialized
INFO - 2018-01-12 03:56:09 --> Model Class Initialized
INFO - 2018-01-12 03:56:09 --> Model Class Initialized
DEBUG - 2018-01-12 03:56:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 03:56:09 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-12 03:56:09 --> Final output sent to browser
DEBUG - 2018-01-12 03:56:09 --> Total execution time: 0.1266
INFO - 2018-01-12 03:56:59 --> Config Class Initialized
INFO - 2018-01-12 03:56:59 --> Hooks Class Initialized
DEBUG - 2018-01-12 03:56:59 --> UTF-8 Support Enabled
INFO - 2018-01-12 03:56:59 --> Utf8 Class Initialized
INFO - 2018-01-12 03:56:59 --> URI Class Initialized
INFO - 2018-01-12 03:56:59 --> Router Class Initialized
INFO - 2018-01-12 03:56:59 --> Output Class Initialized
INFO - 2018-01-12 03:56:59 --> Security Class Initialized
DEBUG - 2018-01-12 03:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 03:56:59 --> Input Class Initialized
INFO - 2018-01-12 03:56:59 --> Language Class Initialized
INFO - 2018-01-12 03:56:59 --> Loader Class Initialized
INFO - 2018-01-12 03:56:59 --> Helper loaded: url_helper
INFO - 2018-01-12 03:56:59 --> Helper loaded: form_helper
INFO - 2018-01-12 03:56:59 --> Database Driver Class Initialized
DEBUG - 2018-01-12 03:56:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 03:56:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 03:56:59 --> Form Validation Class Initialized
INFO - 2018-01-12 03:56:59 --> Model Class Initialized
INFO - 2018-01-12 03:56:59 --> Controller Class Initialized
INFO - 2018-01-12 03:56:59 --> Model Class Initialized
INFO - 2018-01-12 03:56:59 --> Model Class Initialized
INFO - 2018-01-12 03:56:59 --> Model Class Initialized
INFO - 2018-01-12 03:56:59 --> Model Class Initialized
DEBUG - 2018-01-12 03:56:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 03:57:00 --> Config Class Initialized
INFO - 2018-01-12 03:57:00 --> Hooks Class Initialized
DEBUG - 2018-01-12 03:57:00 --> UTF-8 Support Enabled
INFO - 2018-01-12 03:57:00 --> Utf8 Class Initialized
INFO - 2018-01-12 03:57:00 --> URI Class Initialized
INFO - 2018-01-12 03:57:00 --> Router Class Initialized
INFO - 2018-01-12 03:57:00 --> Output Class Initialized
INFO - 2018-01-12 03:57:00 --> Security Class Initialized
DEBUG - 2018-01-12 03:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 03:57:00 --> Input Class Initialized
INFO - 2018-01-12 03:57:00 --> Language Class Initialized
INFO - 2018-01-12 03:57:00 --> Loader Class Initialized
INFO - 2018-01-12 03:57:00 --> Helper loaded: url_helper
INFO - 2018-01-12 03:57:00 --> Helper loaded: form_helper
INFO - 2018-01-12 03:57:00 --> Database Driver Class Initialized
DEBUG - 2018-01-12 03:57:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 03:57:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 03:57:00 --> Form Validation Class Initialized
INFO - 2018-01-12 03:57:00 --> Model Class Initialized
INFO - 2018-01-12 03:57:00 --> Controller Class Initialized
INFO - 2018-01-12 03:57:00 --> Model Class Initialized
INFO - 2018-01-12 03:57:00 --> Model Class Initialized
INFO - 2018-01-12 03:57:00 --> Model Class Initialized
INFO - 2018-01-12 03:57:00 --> Model Class Initialized
DEBUG - 2018-01-12 03:57:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 03:57:00 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-12 03:57:00 --> Final output sent to browser
DEBUG - 2018-01-12 03:57:00 --> Total execution time: 0.0868
INFO - 2018-01-12 03:57:00 --> Config Class Initialized
INFO - 2018-01-12 03:57:00 --> Hooks Class Initialized
DEBUG - 2018-01-12 03:57:00 --> UTF-8 Support Enabled
INFO - 2018-01-12 03:57:00 --> Utf8 Class Initialized
INFO - 2018-01-12 03:57:00 --> URI Class Initialized
INFO - 2018-01-12 03:57:00 --> Router Class Initialized
INFO - 2018-01-12 03:57:00 --> Output Class Initialized
INFO - 2018-01-12 03:57:00 --> Security Class Initialized
DEBUG - 2018-01-12 03:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 03:57:00 --> Input Class Initialized
INFO - 2018-01-12 03:57:00 --> Language Class Initialized
INFO - 2018-01-12 03:57:00 --> Loader Class Initialized
INFO - 2018-01-12 03:57:00 --> Helper loaded: url_helper
INFO - 2018-01-12 03:57:00 --> Helper loaded: form_helper
INFO - 2018-01-12 03:57:00 --> Database Driver Class Initialized
DEBUG - 2018-01-12 03:57:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 03:57:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 03:57:00 --> Form Validation Class Initialized
INFO - 2018-01-12 03:57:00 --> Model Class Initialized
INFO - 2018-01-12 03:57:00 --> Controller Class Initialized
INFO - 2018-01-12 03:57:00 --> Model Class Initialized
INFO - 2018-01-12 03:57:00 --> Model Class Initialized
INFO - 2018-01-12 03:57:00 --> Model Class Initialized
INFO - 2018-01-12 03:57:00 --> Model Class Initialized
DEBUG - 2018-01-12 03:57:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 03:57:08 --> Config Class Initialized
INFO - 2018-01-12 03:57:08 --> Hooks Class Initialized
DEBUG - 2018-01-12 03:57:08 --> UTF-8 Support Enabled
INFO - 2018-01-12 03:57:08 --> Utf8 Class Initialized
INFO - 2018-01-12 03:57:08 --> URI Class Initialized
INFO - 2018-01-12 03:57:08 --> Router Class Initialized
INFO - 2018-01-12 03:57:08 --> Output Class Initialized
INFO - 2018-01-12 03:57:08 --> Security Class Initialized
DEBUG - 2018-01-12 03:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 03:57:08 --> Input Class Initialized
INFO - 2018-01-12 03:57:08 --> Language Class Initialized
INFO - 2018-01-12 03:57:08 --> Loader Class Initialized
INFO - 2018-01-12 03:57:08 --> Helper loaded: url_helper
INFO - 2018-01-12 03:57:08 --> Helper loaded: form_helper
INFO - 2018-01-12 03:57:08 --> Database Driver Class Initialized
DEBUG - 2018-01-12 03:57:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 03:57:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 03:57:08 --> Form Validation Class Initialized
INFO - 2018-01-12 03:57:08 --> Model Class Initialized
INFO - 2018-01-12 03:57:08 --> Controller Class Initialized
INFO - 2018-01-12 03:57:08 --> Model Class Initialized
INFO - 2018-01-12 03:57:08 --> Model Class Initialized
INFO - 2018-01-12 03:57:08 --> Model Class Initialized
INFO - 2018-01-12 03:57:08 --> Model Class Initialized
DEBUG - 2018-01-12 03:57:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 03:57:08 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-12 03:57:08 --> Final output sent to browser
DEBUG - 2018-01-12 03:57:08 --> Total execution time: 0.1693
INFO - 2018-01-12 03:57:10 --> Config Class Initialized
INFO - 2018-01-12 03:57:10 --> Hooks Class Initialized
DEBUG - 2018-01-12 03:57:10 --> UTF-8 Support Enabled
INFO - 2018-01-12 03:57:10 --> Utf8 Class Initialized
INFO - 2018-01-12 03:57:10 --> URI Class Initialized
INFO - 2018-01-12 03:57:10 --> Router Class Initialized
INFO - 2018-01-12 03:57:10 --> Output Class Initialized
INFO - 2018-01-12 03:57:10 --> Security Class Initialized
DEBUG - 2018-01-12 03:57:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 03:57:10 --> Input Class Initialized
INFO - 2018-01-12 03:57:10 --> Language Class Initialized
INFO - 2018-01-12 03:57:10 --> Loader Class Initialized
INFO - 2018-01-12 03:57:10 --> Helper loaded: url_helper
INFO - 2018-01-12 03:57:10 --> Helper loaded: form_helper
INFO - 2018-01-12 03:57:10 --> Database Driver Class Initialized
DEBUG - 2018-01-12 03:57:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 03:57:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 03:57:10 --> Form Validation Class Initialized
INFO - 2018-01-12 03:57:10 --> Model Class Initialized
INFO - 2018-01-12 03:57:10 --> Controller Class Initialized
INFO - 2018-01-12 03:57:10 --> Model Class Initialized
INFO - 2018-01-12 03:57:10 --> Model Class Initialized
INFO - 2018-01-12 03:57:10 --> Model Class Initialized
INFO - 2018-01-12 03:57:10 --> Model Class Initialized
DEBUG - 2018-01-12 03:57:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 03:57:10 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-12 03:57:10 --> Final output sent to browser
DEBUG - 2018-01-12 03:57:10 --> Total execution time: 0.0444
INFO - 2018-01-12 03:57:10 --> Config Class Initialized
INFO - 2018-01-12 03:57:10 --> Hooks Class Initialized
DEBUG - 2018-01-12 03:57:10 --> UTF-8 Support Enabled
INFO - 2018-01-12 03:57:10 --> Utf8 Class Initialized
INFO - 2018-01-12 03:57:10 --> URI Class Initialized
INFO - 2018-01-12 03:57:10 --> Router Class Initialized
INFO - 2018-01-12 03:57:10 --> Output Class Initialized
INFO - 2018-01-12 03:57:10 --> Security Class Initialized
DEBUG - 2018-01-12 03:57:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 03:57:10 --> Input Class Initialized
INFO - 2018-01-12 03:57:10 --> Language Class Initialized
INFO - 2018-01-12 03:57:10 --> Loader Class Initialized
INFO - 2018-01-12 03:57:10 --> Helper loaded: url_helper
INFO - 2018-01-12 03:57:10 --> Helper loaded: form_helper
INFO - 2018-01-12 03:57:10 --> Database Driver Class Initialized
DEBUG - 2018-01-12 03:57:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 03:57:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 03:57:10 --> Form Validation Class Initialized
INFO - 2018-01-12 03:57:10 --> Model Class Initialized
INFO - 2018-01-12 03:57:10 --> Controller Class Initialized
INFO - 2018-01-12 03:57:10 --> Model Class Initialized
INFO - 2018-01-12 03:57:10 --> Model Class Initialized
INFO - 2018-01-12 03:57:10 --> Model Class Initialized
INFO - 2018-01-12 03:57:10 --> Model Class Initialized
DEBUG - 2018-01-12 03:57:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 03:57:30 --> Config Class Initialized
INFO - 2018-01-12 03:57:30 --> Hooks Class Initialized
DEBUG - 2018-01-12 03:57:30 --> UTF-8 Support Enabled
INFO - 2018-01-12 03:57:30 --> Utf8 Class Initialized
INFO - 2018-01-12 03:57:30 --> Config Class Initialized
INFO - 2018-01-12 03:57:30 --> Hooks Class Initialized
INFO - 2018-01-12 03:57:30 --> URI Class Initialized
INFO - 2018-01-12 03:57:30 --> Router Class Initialized
DEBUG - 2018-01-12 03:57:30 --> UTF-8 Support Enabled
INFO - 2018-01-12 03:57:30 --> Utf8 Class Initialized
INFO - 2018-01-12 03:57:30 --> Output Class Initialized
INFO - 2018-01-12 03:57:30 --> URI Class Initialized
INFO - 2018-01-12 03:57:30 --> Security Class Initialized
DEBUG - 2018-01-12 03:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 03:57:30 --> Input Class Initialized
INFO - 2018-01-12 03:57:30 --> Router Class Initialized
INFO - 2018-01-12 03:57:30 --> Language Class Initialized
INFO - 2018-01-12 03:57:30 --> Output Class Initialized
INFO - 2018-01-12 03:57:30 --> Security Class Initialized
DEBUG - 2018-01-12 03:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 03:57:30 --> Input Class Initialized
INFO - 2018-01-12 03:57:30 --> Language Class Initialized
ERROR - 2018-01-12 03:57:30 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-01-12 03:57:30 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-01-12 03:58:16 --> Config Class Initialized
INFO - 2018-01-12 03:58:16 --> Hooks Class Initialized
DEBUG - 2018-01-12 03:58:16 --> UTF-8 Support Enabled
INFO - 2018-01-12 03:58:16 --> Utf8 Class Initialized
INFO - 2018-01-12 03:58:16 --> URI Class Initialized
INFO - 2018-01-12 03:58:16 --> Router Class Initialized
INFO - 2018-01-12 03:58:16 --> Output Class Initialized
INFO - 2018-01-12 03:58:16 --> Security Class Initialized
DEBUG - 2018-01-12 03:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 03:58:16 --> Input Class Initialized
INFO - 2018-01-12 03:58:16 --> Language Class Initialized
INFO - 2018-01-12 03:58:16 --> Loader Class Initialized
INFO - 2018-01-12 03:58:16 --> Helper loaded: url_helper
INFO - 2018-01-12 03:58:16 --> Helper loaded: form_helper
INFO - 2018-01-12 03:58:16 --> Database Driver Class Initialized
DEBUG - 2018-01-12 03:58:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 03:58:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 03:58:16 --> Form Validation Class Initialized
INFO - 2018-01-12 03:58:16 --> Model Class Initialized
INFO - 2018-01-12 03:58:16 --> Controller Class Initialized
INFO - 2018-01-12 03:58:16 --> Model Class Initialized
INFO - 2018-01-12 03:58:16 --> Model Class Initialized
INFO - 2018-01-12 03:58:16 --> Model Class Initialized
INFO - 2018-01-12 03:58:16 --> Model Class Initialized
DEBUG - 2018-01-12 03:58:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 03:58:16 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-12 03:58:16 --> Final output sent to browser
DEBUG - 2018-01-12 03:58:16 --> Total execution time: 0.1130
INFO - 2018-01-12 03:58:16 --> Config Class Initialized
INFO - 2018-01-12 03:58:16 --> Hooks Class Initialized
DEBUG - 2018-01-12 03:58:16 --> UTF-8 Support Enabled
INFO - 2018-01-12 03:58:16 --> Utf8 Class Initialized
INFO - 2018-01-12 03:58:16 --> URI Class Initialized
INFO - 2018-01-12 03:58:16 --> Router Class Initialized
INFO - 2018-01-12 03:58:16 --> Output Class Initialized
INFO - 2018-01-12 03:58:16 --> Security Class Initialized
DEBUG - 2018-01-12 03:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 03:58:16 --> Input Class Initialized
INFO - 2018-01-12 03:58:16 --> Language Class Initialized
INFO - 2018-01-12 03:58:16 --> Loader Class Initialized
INFO - 2018-01-12 03:58:16 --> Helper loaded: url_helper
INFO - 2018-01-12 03:58:16 --> Helper loaded: form_helper
INFO - 2018-01-12 03:58:16 --> Database Driver Class Initialized
DEBUG - 2018-01-12 03:58:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 03:58:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 03:58:16 --> Form Validation Class Initialized
INFO - 2018-01-12 03:58:16 --> Model Class Initialized
INFO - 2018-01-12 03:58:16 --> Controller Class Initialized
INFO - 2018-01-12 03:58:16 --> Model Class Initialized
INFO - 2018-01-12 03:58:16 --> Model Class Initialized
INFO - 2018-01-12 03:58:16 --> Model Class Initialized
INFO - 2018-01-12 03:58:16 --> Model Class Initialized
DEBUG - 2018-01-12 03:58:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 04:00:15 --> Config Class Initialized
INFO - 2018-01-12 04:00:15 --> Hooks Class Initialized
DEBUG - 2018-01-12 04:00:15 --> UTF-8 Support Enabled
INFO - 2018-01-12 04:00:15 --> Utf8 Class Initialized
INFO - 2018-01-12 04:00:15 --> URI Class Initialized
INFO - 2018-01-12 04:00:15 --> Router Class Initialized
INFO - 2018-01-12 04:00:15 --> Output Class Initialized
INFO - 2018-01-12 04:00:15 --> Security Class Initialized
DEBUG - 2018-01-12 04:00:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 04:00:15 --> Input Class Initialized
INFO - 2018-01-12 04:00:15 --> Language Class Initialized
INFO - 2018-01-12 04:00:15 --> Loader Class Initialized
INFO - 2018-01-12 04:00:15 --> Helper loaded: url_helper
INFO - 2018-01-12 04:00:15 --> Helper loaded: form_helper
INFO - 2018-01-12 04:00:15 --> Database Driver Class Initialized
DEBUG - 2018-01-12 04:00:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 04:00:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 04:00:15 --> Form Validation Class Initialized
INFO - 2018-01-12 04:00:15 --> Model Class Initialized
INFO - 2018-01-12 04:00:15 --> Controller Class Initialized
INFO - 2018-01-12 04:00:15 --> Model Class Initialized
INFO - 2018-01-12 04:00:15 --> Model Class Initialized
INFO - 2018-01-12 04:00:15 --> Model Class Initialized
INFO - 2018-01-12 04:00:15 --> Model Class Initialized
DEBUG - 2018-01-12 04:00:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 04:00:15 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-12 04:00:15 --> Final output sent to browser
DEBUG - 2018-01-12 04:00:15 --> Total execution time: 0.1470
INFO - 2018-01-12 04:00:15 --> Config Class Initialized
INFO - 2018-01-12 04:00:15 --> Hooks Class Initialized
DEBUG - 2018-01-12 04:00:15 --> UTF-8 Support Enabled
INFO - 2018-01-12 04:00:15 --> Utf8 Class Initialized
INFO - 2018-01-12 04:00:15 --> URI Class Initialized
INFO - 2018-01-12 04:00:15 --> Router Class Initialized
INFO - 2018-01-12 04:00:15 --> Output Class Initialized
INFO - 2018-01-12 04:00:15 --> Security Class Initialized
DEBUG - 2018-01-12 04:00:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 04:00:15 --> Input Class Initialized
INFO - 2018-01-12 04:00:15 --> Language Class Initialized
INFO - 2018-01-12 04:00:15 --> Loader Class Initialized
INFO - 2018-01-12 04:00:15 --> Helper loaded: url_helper
INFO - 2018-01-12 04:00:15 --> Helper loaded: form_helper
INFO - 2018-01-12 04:00:15 --> Database Driver Class Initialized
DEBUG - 2018-01-12 04:00:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 04:00:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 04:00:15 --> Form Validation Class Initialized
INFO - 2018-01-12 04:00:15 --> Model Class Initialized
INFO - 2018-01-12 04:00:15 --> Controller Class Initialized
INFO - 2018-01-12 04:00:15 --> Model Class Initialized
INFO - 2018-01-12 04:00:15 --> Model Class Initialized
INFO - 2018-01-12 04:00:15 --> Model Class Initialized
INFO - 2018-01-12 04:00:15 --> Model Class Initialized
DEBUG - 2018-01-12 04:00:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 04:00:39 --> Config Class Initialized
INFO - 2018-01-12 04:00:39 --> Hooks Class Initialized
DEBUG - 2018-01-12 04:00:39 --> UTF-8 Support Enabled
INFO - 2018-01-12 04:00:39 --> Utf8 Class Initialized
INFO - 2018-01-12 04:00:39 --> URI Class Initialized
INFO - 2018-01-12 04:00:39 --> Router Class Initialized
INFO - 2018-01-12 04:00:39 --> Output Class Initialized
INFO - 2018-01-12 04:00:39 --> Security Class Initialized
DEBUG - 2018-01-12 04:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 04:00:39 --> Input Class Initialized
INFO - 2018-01-12 04:00:39 --> Language Class Initialized
INFO - 2018-01-12 04:00:39 --> Loader Class Initialized
INFO - 2018-01-12 04:00:39 --> Helper loaded: url_helper
INFO - 2018-01-12 04:00:39 --> Helper loaded: form_helper
INFO - 2018-01-12 04:00:39 --> Database Driver Class Initialized
DEBUG - 2018-01-12 04:00:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 04:00:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 04:00:39 --> Form Validation Class Initialized
INFO - 2018-01-12 04:00:39 --> Model Class Initialized
INFO - 2018-01-12 04:00:39 --> Controller Class Initialized
INFO - 2018-01-12 04:00:39 --> Model Class Initialized
INFO - 2018-01-12 04:00:39 --> Model Class Initialized
INFO - 2018-01-12 04:00:39 --> Model Class Initialized
INFO - 2018-01-12 04:00:39 --> Model Class Initialized
DEBUG - 2018-01-12 04:00:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 04:00:39 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-12 04:00:39 --> Final output sent to browser
DEBUG - 2018-01-12 04:00:39 --> Total execution time: 0.1165
INFO - 2018-01-12 04:00:39 --> Config Class Initialized
INFO - 2018-01-12 04:00:39 --> Hooks Class Initialized
DEBUG - 2018-01-12 04:00:39 --> UTF-8 Support Enabled
INFO - 2018-01-12 04:00:39 --> Utf8 Class Initialized
INFO - 2018-01-12 04:00:39 --> URI Class Initialized
INFO - 2018-01-12 04:00:39 --> Router Class Initialized
INFO - 2018-01-12 04:00:39 --> Output Class Initialized
INFO - 2018-01-12 04:00:39 --> Security Class Initialized
DEBUG - 2018-01-12 04:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 04:00:39 --> Input Class Initialized
INFO - 2018-01-12 04:00:39 --> Language Class Initialized
INFO - 2018-01-12 04:00:39 --> Loader Class Initialized
INFO - 2018-01-12 04:00:39 --> Helper loaded: url_helper
INFO - 2018-01-12 04:00:39 --> Helper loaded: form_helper
INFO - 2018-01-12 04:00:39 --> Database Driver Class Initialized
DEBUG - 2018-01-12 04:00:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 04:00:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 04:00:39 --> Form Validation Class Initialized
INFO - 2018-01-12 04:00:39 --> Model Class Initialized
INFO - 2018-01-12 04:00:39 --> Controller Class Initialized
INFO - 2018-01-12 04:00:39 --> Model Class Initialized
INFO - 2018-01-12 04:00:39 --> Model Class Initialized
INFO - 2018-01-12 04:00:39 --> Model Class Initialized
INFO - 2018-01-12 04:00:39 --> Model Class Initialized
DEBUG - 2018-01-12 04:00:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 04:00:43 --> Config Class Initialized
INFO - 2018-01-12 04:00:43 --> Hooks Class Initialized
DEBUG - 2018-01-12 04:00:43 --> UTF-8 Support Enabled
INFO - 2018-01-12 04:00:43 --> Utf8 Class Initialized
INFO - 2018-01-12 04:00:43 --> URI Class Initialized
INFO - 2018-01-12 04:00:43 --> Router Class Initialized
INFO - 2018-01-12 04:00:43 --> Output Class Initialized
INFO - 2018-01-12 04:00:43 --> Security Class Initialized
DEBUG - 2018-01-12 04:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 04:00:43 --> Input Class Initialized
INFO - 2018-01-12 04:00:43 --> Language Class Initialized
INFO - 2018-01-12 04:00:43 --> Loader Class Initialized
INFO - 2018-01-12 04:00:43 --> Helper loaded: url_helper
INFO - 2018-01-12 04:00:43 --> Helper loaded: form_helper
INFO - 2018-01-12 04:00:43 --> Database Driver Class Initialized
DEBUG - 2018-01-12 04:00:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 04:00:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 04:00:43 --> Form Validation Class Initialized
INFO - 2018-01-12 04:00:43 --> Model Class Initialized
INFO - 2018-01-12 04:00:43 --> Controller Class Initialized
INFO - 2018-01-12 04:00:43 --> Model Class Initialized
INFO - 2018-01-12 04:00:43 --> Model Class Initialized
INFO - 2018-01-12 04:00:43 --> Model Class Initialized
INFO - 2018-01-12 04:00:43 --> Model Class Initialized
DEBUG - 2018-01-12 04:00:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 04:00:43 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-12 04:00:43 --> Final output sent to browser
DEBUG - 2018-01-12 04:00:43 --> Total execution time: 0.1031
INFO - 2018-01-12 04:00:44 --> Config Class Initialized
INFO - 2018-01-12 04:00:44 --> Hooks Class Initialized
DEBUG - 2018-01-12 04:00:44 --> UTF-8 Support Enabled
INFO - 2018-01-12 04:00:44 --> Utf8 Class Initialized
INFO - 2018-01-12 04:00:44 --> URI Class Initialized
INFO - 2018-01-12 04:00:44 --> Router Class Initialized
INFO - 2018-01-12 04:00:44 --> Output Class Initialized
INFO - 2018-01-12 04:00:44 --> Security Class Initialized
DEBUG - 2018-01-12 04:00:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 04:00:44 --> Input Class Initialized
INFO - 2018-01-12 04:00:44 --> Language Class Initialized
INFO - 2018-01-12 04:00:44 --> Loader Class Initialized
INFO - 2018-01-12 04:00:44 --> Helper loaded: url_helper
INFO - 2018-01-12 04:00:44 --> Helper loaded: form_helper
INFO - 2018-01-12 04:00:44 --> Database Driver Class Initialized
DEBUG - 2018-01-12 04:00:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 04:00:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 04:00:44 --> Form Validation Class Initialized
INFO - 2018-01-12 04:00:44 --> Model Class Initialized
INFO - 2018-01-12 04:00:44 --> Controller Class Initialized
INFO - 2018-01-12 04:00:44 --> Model Class Initialized
INFO - 2018-01-12 04:00:44 --> Model Class Initialized
INFO - 2018-01-12 04:00:44 --> Model Class Initialized
INFO - 2018-01-12 04:00:44 --> Model Class Initialized
DEBUG - 2018-01-12 04:00:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 04:00:45 --> Config Class Initialized
INFO - 2018-01-12 04:00:45 --> Hooks Class Initialized
DEBUG - 2018-01-12 04:00:45 --> UTF-8 Support Enabled
INFO - 2018-01-12 04:00:45 --> Utf8 Class Initialized
INFO - 2018-01-12 04:00:45 --> URI Class Initialized
INFO - 2018-01-12 04:00:45 --> Router Class Initialized
INFO - 2018-01-12 04:00:45 --> Output Class Initialized
INFO - 2018-01-12 04:00:45 --> Security Class Initialized
DEBUG - 2018-01-12 04:00:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 04:00:45 --> Input Class Initialized
INFO - 2018-01-12 04:00:45 --> Language Class Initialized
INFO - 2018-01-12 04:00:45 --> Loader Class Initialized
INFO - 2018-01-12 04:00:45 --> Helper loaded: url_helper
INFO - 2018-01-12 04:00:45 --> Helper loaded: form_helper
INFO - 2018-01-12 04:00:45 --> Database Driver Class Initialized
DEBUG - 2018-01-12 04:00:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 04:00:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 04:00:45 --> Form Validation Class Initialized
INFO - 2018-01-12 04:00:45 --> Model Class Initialized
INFO - 2018-01-12 04:00:45 --> Controller Class Initialized
INFO - 2018-01-12 04:00:45 --> Model Class Initialized
INFO - 2018-01-12 04:00:45 --> Model Class Initialized
INFO - 2018-01-12 04:00:45 --> Model Class Initialized
INFO - 2018-01-12 04:00:45 --> Model Class Initialized
DEBUG - 2018-01-12 04:00:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 04:00:45 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-12 04:00:45 --> Final output sent to browser
DEBUG - 2018-01-12 04:00:45 --> Total execution time: 0.0536
INFO - 2018-01-12 04:00:56 --> Config Class Initialized
INFO - 2018-01-12 04:00:56 --> Hooks Class Initialized
DEBUG - 2018-01-12 04:00:56 --> UTF-8 Support Enabled
INFO - 2018-01-12 04:00:56 --> Utf8 Class Initialized
INFO - 2018-01-12 04:00:56 --> URI Class Initialized
INFO - 2018-01-12 04:00:56 --> Router Class Initialized
INFO - 2018-01-12 04:00:56 --> Output Class Initialized
INFO - 2018-01-12 04:00:56 --> Security Class Initialized
DEBUG - 2018-01-12 04:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 04:00:56 --> Input Class Initialized
INFO - 2018-01-12 04:00:56 --> Language Class Initialized
INFO - 2018-01-12 04:00:56 --> Loader Class Initialized
INFO - 2018-01-12 04:00:56 --> Helper loaded: url_helper
INFO - 2018-01-12 04:00:56 --> Helper loaded: form_helper
INFO - 2018-01-12 04:00:56 --> Database Driver Class Initialized
DEBUG - 2018-01-12 04:00:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 04:00:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 04:00:56 --> Form Validation Class Initialized
INFO - 2018-01-12 04:00:56 --> Model Class Initialized
INFO - 2018-01-12 04:00:56 --> Controller Class Initialized
INFO - 2018-01-12 04:00:56 --> Model Class Initialized
INFO - 2018-01-12 04:00:56 --> Model Class Initialized
INFO - 2018-01-12 04:00:56 --> Model Class Initialized
INFO - 2018-01-12 04:00:56 --> Model Class Initialized
DEBUG - 2018-01-12 04:00:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 04:00:56 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-12 04:00:56 --> Final output sent to browser
DEBUG - 2018-01-12 04:00:56 --> Total execution time: 0.0799
INFO - 2018-01-12 04:00:56 --> Config Class Initialized
INFO - 2018-01-12 04:00:56 --> Hooks Class Initialized
DEBUG - 2018-01-12 04:00:56 --> UTF-8 Support Enabled
INFO - 2018-01-12 04:00:56 --> Utf8 Class Initialized
INFO - 2018-01-12 04:00:56 --> URI Class Initialized
INFO - 2018-01-12 04:00:56 --> Router Class Initialized
INFO - 2018-01-12 04:00:56 --> Output Class Initialized
INFO - 2018-01-12 04:00:56 --> Security Class Initialized
DEBUG - 2018-01-12 04:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 04:00:56 --> Input Class Initialized
INFO - 2018-01-12 04:00:56 --> Language Class Initialized
INFO - 2018-01-12 04:00:56 --> Loader Class Initialized
INFO - 2018-01-12 04:00:56 --> Helper loaded: url_helper
INFO - 2018-01-12 04:00:56 --> Helper loaded: form_helper
INFO - 2018-01-12 04:00:56 --> Database Driver Class Initialized
DEBUG - 2018-01-12 04:00:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 04:00:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 04:00:56 --> Form Validation Class Initialized
INFO - 2018-01-12 04:00:56 --> Model Class Initialized
INFO - 2018-01-12 04:00:56 --> Controller Class Initialized
INFO - 2018-01-12 04:00:56 --> Model Class Initialized
INFO - 2018-01-12 04:00:56 --> Model Class Initialized
INFO - 2018-01-12 04:00:56 --> Model Class Initialized
INFO - 2018-01-12 04:00:56 --> Model Class Initialized
DEBUG - 2018-01-12 04:00:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 04:01:34 --> Config Class Initialized
INFO - 2018-01-12 04:01:34 --> Hooks Class Initialized
DEBUG - 2018-01-12 04:01:34 --> UTF-8 Support Enabled
INFO - 2018-01-12 04:01:34 --> Utf8 Class Initialized
INFO - 2018-01-12 04:01:34 --> URI Class Initialized
INFO - 2018-01-12 04:01:34 --> Router Class Initialized
INFO - 2018-01-12 04:01:34 --> Output Class Initialized
INFO - 2018-01-12 04:01:34 --> Security Class Initialized
DEBUG - 2018-01-12 04:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 04:01:34 --> Input Class Initialized
INFO - 2018-01-12 04:01:34 --> Language Class Initialized
INFO - 2018-01-12 04:01:34 --> Loader Class Initialized
INFO - 2018-01-12 04:01:34 --> Helper loaded: url_helper
INFO - 2018-01-12 04:01:34 --> Helper loaded: form_helper
INFO - 2018-01-12 04:01:34 --> Database Driver Class Initialized
DEBUG - 2018-01-12 04:01:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 04:01:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 04:01:34 --> Form Validation Class Initialized
INFO - 2018-01-12 04:01:34 --> Model Class Initialized
INFO - 2018-01-12 04:01:34 --> Controller Class Initialized
INFO - 2018-01-12 04:01:34 --> Model Class Initialized
INFO - 2018-01-12 04:01:34 --> Model Class Initialized
INFO - 2018-01-12 04:01:34 --> Model Class Initialized
INFO - 2018-01-12 04:01:34 --> Model Class Initialized
DEBUG - 2018-01-12 04:01:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 04:01:34 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-12 04:01:34 --> Final output sent to browser
DEBUG - 2018-01-12 04:01:34 --> Total execution time: 0.0939
INFO - 2018-01-12 04:01:34 --> Config Class Initialized
INFO - 2018-01-12 04:01:34 --> Hooks Class Initialized
DEBUG - 2018-01-12 04:01:34 --> UTF-8 Support Enabled
INFO - 2018-01-12 04:01:34 --> Utf8 Class Initialized
INFO - 2018-01-12 04:01:34 --> URI Class Initialized
INFO - 2018-01-12 04:01:34 --> Router Class Initialized
INFO - 2018-01-12 04:01:34 --> Output Class Initialized
INFO - 2018-01-12 04:01:34 --> Security Class Initialized
DEBUG - 2018-01-12 04:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 04:01:34 --> Input Class Initialized
INFO - 2018-01-12 04:01:34 --> Language Class Initialized
INFO - 2018-01-12 04:01:34 --> Loader Class Initialized
INFO - 2018-01-12 04:01:34 --> Helper loaded: url_helper
INFO - 2018-01-12 04:01:34 --> Helper loaded: form_helper
INFO - 2018-01-12 04:01:34 --> Database Driver Class Initialized
DEBUG - 2018-01-12 04:01:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 04:01:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 04:01:34 --> Form Validation Class Initialized
INFO - 2018-01-12 04:01:34 --> Model Class Initialized
INFO - 2018-01-12 04:01:34 --> Controller Class Initialized
INFO - 2018-01-12 04:01:34 --> Model Class Initialized
INFO - 2018-01-12 04:01:34 --> Model Class Initialized
INFO - 2018-01-12 04:01:34 --> Model Class Initialized
INFO - 2018-01-12 04:01:34 --> Model Class Initialized
DEBUG - 2018-01-12 04:01:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 04:01:49 --> Config Class Initialized
INFO - 2018-01-12 04:01:49 --> Hooks Class Initialized
DEBUG - 2018-01-12 04:01:49 --> UTF-8 Support Enabled
INFO - 2018-01-12 04:01:49 --> Utf8 Class Initialized
INFO - 2018-01-12 04:01:49 --> URI Class Initialized
INFO - 2018-01-12 04:01:49 --> Router Class Initialized
INFO - 2018-01-12 04:01:49 --> Output Class Initialized
INFO - 2018-01-12 04:01:49 --> Security Class Initialized
DEBUG - 2018-01-12 04:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 04:01:49 --> Input Class Initialized
INFO - 2018-01-12 04:01:49 --> Language Class Initialized
INFO - 2018-01-12 04:01:49 --> Loader Class Initialized
INFO - 2018-01-12 04:01:49 --> Helper loaded: url_helper
INFO - 2018-01-12 04:01:49 --> Helper loaded: form_helper
INFO - 2018-01-12 04:01:49 --> Database Driver Class Initialized
DEBUG - 2018-01-12 04:01:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 04:01:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 04:01:49 --> Form Validation Class Initialized
INFO - 2018-01-12 04:01:49 --> Model Class Initialized
INFO - 2018-01-12 04:01:49 --> Controller Class Initialized
INFO - 2018-01-12 04:01:49 --> Model Class Initialized
INFO - 2018-01-12 04:01:49 --> Model Class Initialized
INFO - 2018-01-12 04:01:49 --> Model Class Initialized
INFO - 2018-01-12 04:01:49 --> Model Class Initialized
DEBUG - 2018-01-12 04:01:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 04:01:49 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-12 04:01:49 --> Final output sent to browser
DEBUG - 2018-01-12 04:01:49 --> Total execution time: 0.1712
INFO - 2018-01-12 04:01:49 --> Config Class Initialized
INFO - 2018-01-12 04:01:49 --> Hooks Class Initialized
DEBUG - 2018-01-12 04:01:49 --> UTF-8 Support Enabled
INFO - 2018-01-12 04:01:49 --> Utf8 Class Initialized
INFO - 2018-01-12 04:01:49 --> URI Class Initialized
INFO - 2018-01-12 04:01:49 --> Router Class Initialized
INFO - 2018-01-12 04:01:49 --> Output Class Initialized
INFO - 2018-01-12 04:01:49 --> Security Class Initialized
DEBUG - 2018-01-12 04:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 04:01:49 --> Input Class Initialized
INFO - 2018-01-12 04:01:49 --> Language Class Initialized
INFO - 2018-01-12 04:01:49 --> Loader Class Initialized
INFO - 2018-01-12 04:01:49 --> Helper loaded: url_helper
INFO - 2018-01-12 04:01:49 --> Helper loaded: form_helper
INFO - 2018-01-12 04:01:49 --> Database Driver Class Initialized
DEBUG - 2018-01-12 04:01:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 04:01:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 04:01:49 --> Form Validation Class Initialized
INFO - 2018-01-12 04:01:49 --> Model Class Initialized
INFO - 2018-01-12 04:01:49 --> Controller Class Initialized
INFO - 2018-01-12 04:01:49 --> Model Class Initialized
INFO - 2018-01-12 04:01:49 --> Model Class Initialized
INFO - 2018-01-12 04:01:49 --> Model Class Initialized
INFO - 2018-01-12 04:01:49 --> Model Class Initialized
DEBUG - 2018-01-12 04:01:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 04:02:01 --> Config Class Initialized
INFO - 2018-01-12 04:02:01 --> Hooks Class Initialized
DEBUG - 2018-01-12 04:02:01 --> UTF-8 Support Enabled
INFO - 2018-01-12 04:02:01 --> Utf8 Class Initialized
INFO - 2018-01-12 04:02:01 --> URI Class Initialized
INFO - 2018-01-12 04:02:01 --> Router Class Initialized
INFO - 2018-01-12 04:02:01 --> Output Class Initialized
INFO - 2018-01-12 04:02:01 --> Security Class Initialized
DEBUG - 2018-01-12 04:02:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 04:02:01 --> Input Class Initialized
INFO - 2018-01-12 04:02:01 --> Language Class Initialized
INFO - 2018-01-12 04:02:01 --> Loader Class Initialized
INFO - 2018-01-12 04:02:01 --> Helper loaded: url_helper
INFO - 2018-01-12 04:02:01 --> Helper loaded: form_helper
INFO - 2018-01-12 04:02:01 --> Database Driver Class Initialized
DEBUG - 2018-01-12 04:02:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 04:02:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 04:02:01 --> Form Validation Class Initialized
INFO - 2018-01-12 04:02:01 --> Model Class Initialized
INFO - 2018-01-12 04:02:01 --> Controller Class Initialized
INFO - 2018-01-12 04:02:01 --> Model Class Initialized
INFO - 2018-01-12 04:02:01 --> Model Class Initialized
INFO - 2018-01-12 04:02:01 --> Model Class Initialized
INFO - 2018-01-12 04:02:01 --> Model Class Initialized
DEBUG - 2018-01-12 04:02:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 04:02:02 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-12 04:02:02 --> Final output sent to browser
DEBUG - 2018-01-12 04:02:02 --> Total execution time: 0.3956
INFO - 2018-01-12 04:03:49 --> Config Class Initialized
INFO - 2018-01-12 04:03:49 --> Hooks Class Initialized
DEBUG - 2018-01-12 04:03:49 --> UTF-8 Support Enabled
INFO - 2018-01-12 04:03:49 --> Utf8 Class Initialized
INFO - 2018-01-12 04:03:49 --> URI Class Initialized
INFO - 2018-01-12 04:03:49 --> Router Class Initialized
INFO - 2018-01-12 04:03:49 --> Output Class Initialized
INFO - 2018-01-12 04:03:49 --> Security Class Initialized
DEBUG - 2018-01-12 04:03:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 04:03:49 --> Input Class Initialized
INFO - 2018-01-12 04:03:49 --> Language Class Initialized
INFO - 2018-01-12 04:03:49 --> Loader Class Initialized
INFO - 2018-01-12 04:03:49 --> Helper loaded: url_helper
INFO - 2018-01-12 04:03:49 --> Helper loaded: form_helper
INFO - 2018-01-12 04:03:49 --> Database Driver Class Initialized
DEBUG - 2018-01-12 04:03:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 04:03:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 04:03:49 --> Form Validation Class Initialized
INFO - 2018-01-12 04:03:49 --> Model Class Initialized
INFO - 2018-01-12 04:03:49 --> Controller Class Initialized
INFO - 2018-01-12 04:03:49 --> Model Class Initialized
INFO - 2018-01-12 04:03:49 --> Model Class Initialized
INFO - 2018-01-12 04:03:49 --> Model Class Initialized
INFO - 2018-01-12 04:03:49 --> Model Class Initialized
DEBUG - 2018-01-12 04:03:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 04:03:49 --> Config Class Initialized
INFO - 2018-01-12 04:03:49 --> Hooks Class Initialized
DEBUG - 2018-01-12 04:03:49 --> UTF-8 Support Enabled
INFO - 2018-01-12 04:03:49 --> Utf8 Class Initialized
INFO - 2018-01-12 04:03:49 --> URI Class Initialized
INFO - 2018-01-12 04:03:49 --> Router Class Initialized
INFO - 2018-01-12 04:03:49 --> Output Class Initialized
INFO - 2018-01-12 04:03:49 --> Security Class Initialized
DEBUG - 2018-01-12 04:03:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 04:03:49 --> Input Class Initialized
INFO - 2018-01-12 04:03:49 --> Language Class Initialized
INFO - 2018-01-12 04:03:49 --> Loader Class Initialized
INFO - 2018-01-12 04:03:49 --> Helper loaded: url_helper
INFO - 2018-01-12 04:03:49 --> Helper loaded: form_helper
INFO - 2018-01-12 04:03:49 --> Database Driver Class Initialized
DEBUG - 2018-01-12 04:03:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 04:03:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 04:03:49 --> Form Validation Class Initialized
INFO - 2018-01-12 04:03:49 --> Model Class Initialized
INFO - 2018-01-12 04:03:49 --> Controller Class Initialized
INFO - 2018-01-12 04:03:49 --> Model Class Initialized
INFO - 2018-01-12 04:03:49 --> Model Class Initialized
INFO - 2018-01-12 04:03:49 --> Model Class Initialized
INFO - 2018-01-12 04:03:49 --> Model Class Initialized
DEBUG - 2018-01-12 04:03:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 04:03:49 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-12 04:03:49 --> Final output sent to browser
DEBUG - 2018-01-12 04:03:49 --> Total execution time: 0.1206
INFO - 2018-01-12 04:03:49 --> Config Class Initialized
INFO - 2018-01-12 04:03:49 --> Hooks Class Initialized
DEBUG - 2018-01-12 04:03:49 --> UTF-8 Support Enabled
INFO - 2018-01-12 04:03:49 --> Utf8 Class Initialized
INFO - 2018-01-12 04:03:49 --> URI Class Initialized
INFO - 2018-01-12 04:03:49 --> Router Class Initialized
INFO - 2018-01-12 04:03:49 --> Output Class Initialized
INFO - 2018-01-12 04:03:49 --> Security Class Initialized
DEBUG - 2018-01-12 04:03:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 04:03:49 --> Input Class Initialized
INFO - 2018-01-12 04:03:49 --> Language Class Initialized
INFO - 2018-01-12 04:03:49 --> Loader Class Initialized
INFO - 2018-01-12 04:03:49 --> Helper loaded: url_helper
INFO - 2018-01-12 04:03:50 --> Helper loaded: form_helper
INFO - 2018-01-12 04:03:50 --> Database Driver Class Initialized
DEBUG - 2018-01-12 04:03:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 04:03:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 04:03:50 --> Form Validation Class Initialized
INFO - 2018-01-12 04:03:50 --> Model Class Initialized
INFO - 2018-01-12 04:03:50 --> Controller Class Initialized
INFO - 2018-01-12 04:03:50 --> Model Class Initialized
INFO - 2018-01-12 04:03:50 --> Model Class Initialized
INFO - 2018-01-12 04:03:50 --> Model Class Initialized
INFO - 2018-01-12 04:03:50 --> Model Class Initialized
DEBUG - 2018-01-12 04:03:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 04:03:55 --> Config Class Initialized
INFO - 2018-01-12 04:03:55 --> Hooks Class Initialized
DEBUG - 2018-01-12 04:03:55 --> UTF-8 Support Enabled
INFO - 2018-01-12 04:03:55 --> Utf8 Class Initialized
INFO - 2018-01-12 04:03:55 --> URI Class Initialized
INFO - 2018-01-12 04:03:55 --> Router Class Initialized
INFO - 2018-01-12 04:03:55 --> Output Class Initialized
INFO - 2018-01-12 04:03:55 --> Security Class Initialized
DEBUG - 2018-01-12 04:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 04:03:55 --> Input Class Initialized
INFO - 2018-01-12 04:03:55 --> Language Class Initialized
INFO - 2018-01-12 04:03:55 --> Loader Class Initialized
INFO - 2018-01-12 04:03:55 --> Helper loaded: url_helper
INFO - 2018-01-12 04:03:55 --> Helper loaded: form_helper
INFO - 2018-01-12 04:03:56 --> Database Driver Class Initialized
DEBUG - 2018-01-12 04:03:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 04:03:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 04:03:56 --> Form Validation Class Initialized
INFO - 2018-01-12 04:03:56 --> Model Class Initialized
INFO - 2018-01-12 04:03:56 --> Controller Class Initialized
INFO - 2018-01-12 04:03:56 --> Model Class Initialized
INFO - 2018-01-12 04:03:56 --> Model Class Initialized
INFO - 2018-01-12 04:03:56 --> Model Class Initialized
INFO - 2018-01-12 04:03:56 --> Model Class Initialized
DEBUG - 2018-01-12 04:03:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 04:03:56 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-12 04:03:56 --> Final output sent to browser
DEBUG - 2018-01-12 04:03:56 --> Total execution time: 0.1283
INFO - 2018-01-12 04:03:59 --> Config Class Initialized
INFO - 2018-01-12 04:03:59 --> Hooks Class Initialized
DEBUG - 2018-01-12 04:03:59 --> UTF-8 Support Enabled
INFO - 2018-01-12 04:03:59 --> Utf8 Class Initialized
INFO - 2018-01-12 04:03:59 --> URI Class Initialized
INFO - 2018-01-12 04:03:59 --> Router Class Initialized
INFO - 2018-01-12 04:03:59 --> Output Class Initialized
INFO - 2018-01-12 04:03:59 --> Security Class Initialized
DEBUG - 2018-01-12 04:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 04:03:59 --> Input Class Initialized
INFO - 2018-01-12 04:03:59 --> Language Class Initialized
INFO - 2018-01-12 04:03:59 --> Loader Class Initialized
INFO - 2018-01-12 04:03:59 --> Helper loaded: url_helper
INFO - 2018-01-12 04:03:59 --> Helper loaded: form_helper
INFO - 2018-01-12 04:03:59 --> Database Driver Class Initialized
DEBUG - 2018-01-12 04:03:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 04:03:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 04:03:59 --> Form Validation Class Initialized
INFO - 2018-01-12 04:03:59 --> Model Class Initialized
INFO - 2018-01-12 04:03:59 --> Controller Class Initialized
INFO - 2018-01-12 04:03:59 --> Model Class Initialized
INFO - 2018-01-12 04:03:59 --> Model Class Initialized
INFO - 2018-01-12 04:03:59 --> Model Class Initialized
INFO - 2018-01-12 04:03:59 --> Model Class Initialized
DEBUG - 2018-01-12 04:03:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 04:03:59 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-12 04:03:59 --> Final output sent to browser
DEBUG - 2018-01-12 04:03:59 --> Total execution time: 0.1256
INFO - 2018-01-12 04:03:59 --> Config Class Initialized
INFO - 2018-01-12 04:03:59 --> Hooks Class Initialized
DEBUG - 2018-01-12 04:03:59 --> UTF-8 Support Enabled
INFO - 2018-01-12 04:03:59 --> Utf8 Class Initialized
INFO - 2018-01-12 04:03:59 --> URI Class Initialized
INFO - 2018-01-12 04:03:59 --> Router Class Initialized
INFO - 2018-01-12 04:03:59 --> Output Class Initialized
INFO - 2018-01-12 04:03:59 --> Security Class Initialized
DEBUG - 2018-01-12 04:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 04:03:59 --> Input Class Initialized
INFO - 2018-01-12 04:03:59 --> Language Class Initialized
INFO - 2018-01-12 04:03:59 --> Loader Class Initialized
INFO - 2018-01-12 04:03:59 --> Helper loaded: url_helper
INFO - 2018-01-12 04:03:59 --> Helper loaded: form_helper
INFO - 2018-01-12 04:03:59 --> Database Driver Class Initialized
DEBUG - 2018-01-12 04:03:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 04:03:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 04:03:59 --> Form Validation Class Initialized
INFO - 2018-01-12 04:03:59 --> Model Class Initialized
INFO - 2018-01-12 04:03:59 --> Controller Class Initialized
INFO - 2018-01-12 04:03:59 --> Model Class Initialized
INFO - 2018-01-12 04:03:59 --> Model Class Initialized
INFO - 2018-01-12 04:03:59 --> Model Class Initialized
INFO - 2018-01-12 04:03:59 --> Model Class Initialized
DEBUG - 2018-01-12 04:03:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 04:07:16 --> Config Class Initialized
INFO - 2018-01-12 04:07:16 --> Hooks Class Initialized
DEBUG - 2018-01-12 04:07:16 --> UTF-8 Support Enabled
INFO - 2018-01-12 04:07:16 --> Utf8 Class Initialized
INFO - 2018-01-12 04:07:16 --> URI Class Initialized
INFO - 2018-01-12 04:07:16 --> Router Class Initialized
INFO - 2018-01-12 04:07:16 --> Output Class Initialized
INFO - 2018-01-12 04:07:16 --> Security Class Initialized
DEBUG - 2018-01-12 04:07:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 04:07:16 --> Input Class Initialized
INFO - 2018-01-12 04:07:16 --> Language Class Initialized
INFO - 2018-01-12 04:07:16 --> Loader Class Initialized
INFO - 2018-01-12 04:07:16 --> Helper loaded: url_helper
INFO - 2018-01-12 04:07:16 --> Helper loaded: form_helper
INFO - 2018-01-12 04:07:16 --> Database Driver Class Initialized
DEBUG - 2018-01-12 04:07:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 04:07:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 04:07:16 --> Form Validation Class Initialized
INFO - 2018-01-12 04:07:16 --> Model Class Initialized
INFO - 2018-01-12 04:07:16 --> Controller Class Initialized
INFO - 2018-01-12 04:07:16 --> Model Class Initialized
INFO - 2018-01-12 04:07:16 --> Model Class Initialized
INFO - 2018-01-12 04:07:16 --> Model Class Initialized
INFO - 2018-01-12 04:07:16 --> Model Class Initialized
DEBUG - 2018-01-12 04:07:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 04:07:16 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-12 04:07:16 --> Final output sent to browser
DEBUG - 2018-01-12 04:07:16 --> Total execution time: 0.1433
INFO - 2018-01-12 04:07:16 --> Config Class Initialized
INFO - 2018-01-12 04:07:16 --> Hooks Class Initialized
DEBUG - 2018-01-12 04:07:16 --> UTF-8 Support Enabled
INFO - 2018-01-12 04:07:16 --> Utf8 Class Initialized
INFO - 2018-01-12 04:07:16 --> URI Class Initialized
INFO - 2018-01-12 04:07:16 --> Router Class Initialized
INFO - 2018-01-12 04:07:16 --> Output Class Initialized
INFO - 2018-01-12 04:07:16 --> Security Class Initialized
DEBUG - 2018-01-12 04:07:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 04:07:16 --> Input Class Initialized
INFO - 2018-01-12 04:07:16 --> Language Class Initialized
INFO - 2018-01-12 04:07:16 --> Loader Class Initialized
INFO - 2018-01-12 04:07:16 --> Helper loaded: url_helper
INFO - 2018-01-12 04:07:16 --> Helper loaded: form_helper
INFO - 2018-01-12 04:07:16 --> Database Driver Class Initialized
DEBUG - 2018-01-12 04:07:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 04:07:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 04:07:16 --> Form Validation Class Initialized
INFO - 2018-01-12 04:07:16 --> Model Class Initialized
INFO - 2018-01-12 04:07:16 --> Controller Class Initialized
INFO - 2018-01-12 04:07:16 --> Model Class Initialized
INFO - 2018-01-12 04:07:16 --> Model Class Initialized
INFO - 2018-01-12 04:07:16 --> Model Class Initialized
INFO - 2018-01-12 04:07:16 --> Model Class Initialized
DEBUG - 2018-01-12 04:07:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 04:07:59 --> Config Class Initialized
INFO - 2018-01-12 04:07:59 --> Hooks Class Initialized
DEBUG - 2018-01-12 04:07:59 --> UTF-8 Support Enabled
INFO - 2018-01-12 04:07:59 --> Utf8 Class Initialized
INFO - 2018-01-12 04:07:59 --> URI Class Initialized
INFO - 2018-01-12 04:07:59 --> Router Class Initialized
INFO - 2018-01-12 04:07:59 --> Output Class Initialized
INFO - 2018-01-12 04:07:59 --> Security Class Initialized
DEBUG - 2018-01-12 04:07:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 04:07:59 --> Input Class Initialized
INFO - 2018-01-12 04:07:59 --> Language Class Initialized
INFO - 2018-01-12 04:07:59 --> Loader Class Initialized
INFO - 2018-01-12 04:07:59 --> Helper loaded: url_helper
INFO - 2018-01-12 04:07:59 --> Helper loaded: form_helper
INFO - 2018-01-12 04:07:59 --> Database Driver Class Initialized
DEBUG - 2018-01-12 04:07:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 04:07:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 04:07:59 --> Form Validation Class Initialized
INFO - 2018-01-12 04:07:59 --> Model Class Initialized
INFO - 2018-01-12 04:07:59 --> Controller Class Initialized
INFO - 2018-01-12 04:07:59 --> Model Class Initialized
INFO - 2018-01-12 04:07:59 --> Model Class Initialized
INFO - 2018-01-12 04:07:59 --> Model Class Initialized
INFO - 2018-01-12 04:07:59 --> Model Class Initialized
DEBUG - 2018-01-12 04:07:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 04:07:59 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-12 04:07:59 --> Final output sent to browser
DEBUG - 2018-01-12 04:07:59 --> Total execution time: 0.1303
INFO - 2018-01-12 04:07:59 --> Config Class Initialized
INFO - 2018-01-12 04:07:59 --> Hooks Class Initialized
DEBUG - 2018-01-12 04:07:59 --> UTF-8 Support Enabled
INFO - 2018-01-12 04:07:59 --> Utf8 Class Initialized
INFO - 2018-01-12 04:07:59 --> URI Class Initialized
INFO - 2018-01-12 04:07:59 --> Router Class Initialized
INFO - 2018-01-12 04:07:59 --> Output Class Initialized
INFO - 2018-01-12 04:07:59 --> Security Class Initialized
DEBUG - 2018-01-12 04:07:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 04:07:59 --> Input Class Initialized
INFO - 2018-01-12 04:07:59 --> Language Class Initialized
INFO - 2018-01-12 04:07:59 --> Loader Class Initialized
INFO - 2018-01-12 04:07:59 --> Helper loaded: url_helper
INFO - 2018-01-12 04:07:59 --> Helper loaded: form_helper
INFO - 2018-01-12 04:07:59 --> Database Driver Class Initialized
DEBUG - 2018-01-12 04:07:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 04:07:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 04:07:59 --> Form Validation Class Initialized
INFO - 2018-01-12 04:07:59 --> Model Class Initialized
INFO - 2018-01-12 04:07:59 --> Controller Class Initialized
INFO - 2018-01-12 04:07:59 --> Model Class Initialized
INFO - 2018-01-12 04:07:59 --> Model Class Initialized
INFO - 2018-01-12 04:07:59 --> Model Class Initialized
INFO - 2018-01-12 04:07:59 --> Model Class Initialized
DEBUG - 2018-01-12 04:07:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 04:08:01 --> Config Class Initialized
INFO - 2018-01-12 04:08:01 --> Hooks Class Initialized
DEBUG - 2018-01-12 04:08:01 --> UTF-8 Support Enabled
INFO - 2018-01-12 04:08:01 --> Utf8 Class Initialized
INFO - 2018-01-12 04:08:01 --> URI Class Initialized
INFO - 2018-01-12 04:08:01 --> Router Class Initialized
INFO - 2018-01-12 04:08:01 --> Output Class Initialized
INFO - 2018-01-12 04:08:01 --> Security Class Initialized
DEBUG - 2018-01-12 04:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 04:08:01 --> Input Class Initialized
INFO - 2018-01-12 04:08:01 --> Language Class Initialized
INFO - 2018-01-12 04:08:01 --> Loader Class Initialized
INFO - 2018-01-12 04:08:01 --> Helper loaded: url_helper
INFO - 2018-01-12 04:08:01 --> Helper loaded: form_helper
INFO - 2018-01-12 04:08:01 --> Database Driver Class Initialized
DEBUG - 2018-01-12 04:08:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 04:08:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 04:08:01 --> Form Validation Class Initialized
INFO - 2018-01-12 04:08:01 --> Model Class Initialized
INFO - 2018-01-12 04:08:01 --> Controller Class Initialized
INFO - 2018-01-12 04:08:01 --> Model Class Initialized
INFO - 2018-01-12 04:08:01 --> Model Class Initialized
INFO - 2018-01-12 04:08:01 --> Model Class Initialized
INFO - 2018-01-12 04:08:01 --> Model Class Initialized
DEBUG - 2018-01-12 04:08:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 04:08:01 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-12 04:08:01 --> Final output sent to browser
DEBUG - 2018-01-12 04:08:01 --> Total execution time: 0.0984
INFO - 2018-01-12 04:08:39 --> Config Class Initialized
INFO - 2018-01-12 04:08:39 --> Hooks Class Initialized
DEBUG - 2018-01-12 04:08:39 --> UTF-8 Support Enabled
INFO - 2018-01-12 04:08:39 --> Utf8 Class Initialized
INFO - 2018-01-12 04:08:39 --> URI Class Initialized
INFO - 2018-01-12 04:08:39 --> Router Class Initialized
INFO - 2018-01-12 04:08:39 --> Output Class Initialized
INFO - 2018-01-12 04:08:39 --> Security Class Initialized
DEBUG - 2018-01-12 04:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 04:08:39 --> Input Class Initialized
INFO - 2018-01-12 04:08:39 --> Language Class Initialized
INFO - 2018-01-12 04:08:39 --> Loader Class Initialized
INFO - 2018-01-12 04:08:39 --> Helper loaded: url_helper
INFO - 2018-01-12 04:08:39 --> Helper loaded: form_helper
INFO - 2018-01-12 04:08:39 --> Database Driver Class Initialized
DEBUG - 2018-01-12 04:08:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 04:08:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 04:08:39 --> Form Validation Class Initialized
INFO - 2018-01-12 04:08:39 --> Model Class Initialized
INFO - 2018-01-12 04:08:39 --> Controller Class Initialized
INFO - 2018-01-12 04:08:39 --> Model Class Initialized
INFO - 2018-01-12 04:08:39 --> Model Class Initialized
INFO - 2018-01-12 04:08:39 --> Model Class Initialized
INFO - 2018-01-12 04:08:39 --> Model Class Initialized
DEBUG - 2018-01-12 04:08:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 04:08:39 --> Config Class Initialized
INFO - 2018-01-12 04:08:39 --> Hooks Class Initialized
DEBUG - 2018-01-12 04:08:39 --> UTF-8 Support Enabled
INFO - 2018-01-12 04:08:39 --> Utf8 Class Initialized
INFO - 2018-01-12 04:08:39 --> URI Class Initialized
INFO - 2018-01-12 04:08:39 --> Router Class Initialized
INFO - 2018-01-12 04:08:39 --> Output Class Initialized
INFO - 2018-01-12 04:08:39 --> Security Class Initialized
DEBUG - 2018-01-12 04:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 04:08:39 --> Input Class Initialized
INFO - 2018-01-12 04:08:39 --> Language Class Initialized
INFO - 2018-01-12 04:08:39 --> Loader Class Initialized
INFO - 2018-01-12 04:08:39 --> Helper loaded: url_helper
INFO - 2018-01-12 04:08:39 --> Helper loaded: form_helper
INFO - 2018-01-12 04:08:39 --> Database Driver Class Initialized
DEBUG - 2018-01-12 04:08:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 04:08:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 04:08:39 --> Form Validation Class Initialized
INFO - 2018-01-12 04:08:39 --> Model Class Initialized
INFO - 2018-01-12 04:08:39 --> Controller Class Initialized
INFO - 2018-01-12 04:08:39 --> Model Class Initialized
INFO - 2018-01-12 04:08:39 --> Model Class Initialized
INFO - 2018-01-12 04:08:39 --> Model Class Initialized
INFO - 2018-01-12 04:08:39 --> Model Class Initialized
DEBUG - 2018-01-12 04:08:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 04:08:39 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-12 04:08:39 --> Final output sent to browser
DEBUG - 2018-01-12 04:08:39 --> Total execution time: 0.1166
INFO - 2018-01-12 04:08:40 --> Config Class Initialized
INFO - 2018-01-12 04:08:40 --> Hooks Class Initialized
DEBUG - 2018-01-12 04:08:40 --> UTF-8 Support Enabled
INFO - 2018-01-12 04:08:40 --> Utf8 Class Initialized
INFO - 2018-01-12 04:08:40 --> URI Class Initialized
INFO - 2018-01-12 04:08:40 --> Router Class Initialized
INFO - 2018-01-12 04:08:40 --> Output Class Initialized
INFO - 2018-01-12 04:08:40 --> Security Class Initialized
DEBUG - 2018-01-12 04:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 04:08:40 --> Input Class Initialized
INFO - 2018-01-12 04:08:40 --> Language Class Initialized
INFO - 2018-01-12 04:08:40 --> Loader Class Initialized
INFO - 2018-01-12 04:08:40 --> Helper loaded: url_helper
INFO - 2018-01-12 04:08:40 --> Helper loaded: form_helper
INFO - 2018-01-12 04:08:40 --> Database Driver Class Initialized
DEBUG - 2018-01-12 04:08:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 04:08:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 04:08:40 --> Form Validation Class Initialized
INFO - 2018-01-12 04:08:40 --> Model Class Initialized
INFO - 2018-01-12 04:08:40 --> Controller Class Initialized
INFO - 2018-01-12 04:08:40 --> Model Class Initialized
INFO - 2018-01-12 04:08:40 --> Model Class Initialized
INFO - 2018-01-12 04:08:40 --> Model Class Initialized
INFO - 2018-01-12 04:08:40 --> Model Class Initialized
DEBUG - 2018-01-12 04:08:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 04:08:45 --> Config Class Initialized
INFO - 2018-01-12 04:08:45 --> Hooks Class Initialized
DEBUG - 2018-01-12 04:08:45 --> UTF-8 Support Enabled
INFO - 2018-01-12 04:08:45 --> Utf8 Class Initialized
INFO - 2018-01-12 04:08:45 --> URI Class Initialized
INFO - 2018-01-12 04:08:45 --> Router Class Initialized
INFO - 2018-01-12 04:08:45 --> Output Class Initialized
INFO - 2018-01-12 04:08:45 --> Security Class Initialized
DEBUG - 2018-01-12 04:08:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 04:08:45 --> Input Class Initialized
INFO - 2018-01-12 04:08:45 --> Language Class Initialized
INFO - 2018-01-12 04:08:45 --> Loader Class Initialized
INFO - 2018-01-12 04:08:45 --> Helper loaded: url_helper
INFO - 2018-01-12 04:08:45 --> Helper loaded: form_helper
INFO - 2018-01-12 04:08:45 --> Database Driver Class Initialized
DEBUG - 2018-01-12 04:08:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 04:08:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 04:08:45 --> Form Validation Class Initialized
INFO - 2018-01-12 04:08:45 --> Model Class Initialized
INFO - 2018-01-12 04:08:45 --> Controller Class Initialized
INFO - 2018-01-12 04:08:45 --> Model Class Initialized
INFO - 2018-01-12 04:08:45 --> Model Class Initialized
INFO - 2018-01-12 04:08:45 --> Model Class Initialized
INFO - 2018-01-12 04:08:45 --> Model Class Initialized
DEBUG - 2018-01-12 04:08:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 04:08:45 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-12 04:08:45 --> Final output sent to browser
DEBUG - 2018-01-12 04:08:45 --> Total execution time: 0.1478
INFO - 2018-01-12 04:08:46 --> Config Class Initialized
INFO - 2018-01-12 04:08:46 --> Hooks Class Initialized
DEBUG - 2018-01-12 04:08:46 --> UTF-8 Support Enabled
INFO - 2018-01-12 04:08:46 --> Utf8 Class Initialized
INFO - 2018-01-12 04:08:46 --> URI Class Initialized
INFO - 2018-01-12 04:08:46 --> Router Class Initialized
INFO - 2018-01-12 04:08:46 --> Output Class Initialized
INFO - 2018-01-12 04:08:46 --> Security Class Initialized
DEBUG - 2018-01-12 04:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 04:08:46 --> Input Class Initialized
INFO - 2018-01-12 04:08:46 --> Language Class Initialized
INFO - 2018-01-12 04:08:46 --> Loader Class Initialized
INFO - 2018-01-12 04:08:46 --> Helper loaded: url_helper
INFO - 2018-01-12 04:08:46 --> Helper loaded: form_helper
INFO - 2018-01-12 04:08:46 --> Database Driver Class Initialized
DEBUG - 2018-01-12 04:08:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 04:08:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 04:08:46 --> Form Validation Class Initialized
INFO - 2018-01-12 04:08:46 --> Model Class Initialized
INFO - 2018-01-12 04:08:46 --> Controller Class Initialized
INFO - 2018-01-12 04:08:46 --> Model Class Initialized
INFO - 2018-01-12 04:08:46 --> Model Class Initialized
INFO - 2018-01-12 04:08:46 --> Model Class Initialized
INFO - 2018-01-12 04:08:46 --> Model Class Initialized
DEBUG - 2018-01-12 04:08:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 04:14:54 --> Config Class Initialized
INFO - 2018-01-12 04:14:54 --> Hooks Class Initialized
DEBUG - 2018-01-12 04:14:54 --> UTF-8 Support Enabled
INFO - 2018-01-12 04:14:54 --> Utf8 Class Initialized
INFO - 2018-01-12 04:14:54 --> URI Class Initialized
INFO - 2018-01-12 04:14:54 --> Router Class Initialized
INFO - 2018-01-12 04:14:54 --> Output Class Initialized
INFO - 2018-01-12 04:14:54 --> Security Class Initialized
DEBUG - 2018-01-12 04:14:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 04:14:54 --> Input Class Initialized
INFO - 2018-01-12 04:14:54 --> Language Class Initialized
INFO - 2018-01-12 04:14:54 --> Loader Class Initialized
INFO - 2018-01-12 04:14:54 --> Helper loaded: url_helper
INFO - 2018-01-12 04:14:54 --> Helper loaded: form_helper
INFO - 2018-01-12 04:14:54 --> Database Driver Class Initialized
DEBUG - 2018-01-12 04:14:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 04:14:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 04:14:54 --> Form Validation Class Initialized
INFO - 2018-01-12 04:14:54 --> Model Class Initialized
INFO - 2018-01-12 04:14:54 --> Controller Class Initialized
INFO - 2018-01-12 04:14:54 --> Model Class Initialized
INFO - 2018-01-12 04:14:54 --> Model Class Initialized
INFO - 2018-01-12 04:14:54 --> Model Class Initialized
INFO - 2018-01-12 04:14:54 --> Model Class Initialized
DEBUG - 2018-01-12 04:14:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 04:14:54 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-12 04:14:54 --> Final output sent to browser
DEBUG - 2018-01-12 04:14:54 --> Total execution time: 0.0901
INFO - 2018-01-12 04:14:54 --> Config Class Initialized
INFO - 2018-01-12 04:14:54 --> Hooks Class Initialized
DEBUG - 2018-01-12 04:14:54 --> UTF-8 Support Enabled
INFO - 2018-01-12 04:14:54 --> Utf8 Class Initialized
INFO - 2018-01-12 04:14:54 --> URI Class Initialized
INFO - 2018-01-12 04:14:54 --> Router Class Initialized
INFO - 2018-01-12 04:14:54 --> Output Class Initialized
INFO - 2018-01-12 04:14:54 --> Security Class Initialized
DEBUG - 2018-01-12 04:14:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 04:14:54 --> Input Class Initialized
INFO - 2018-01-12 04:14:54 --> Language Class Initialized
INFO - 2018-01-12 04:14:54 --> Loader Class Initialized
INFO - 2018-01-12 04:14:54 --> Helper loaded: url_helper
INFO - 2018-01-12 04:14:54 --> Helper loaded: form_helper
INFO - 2018-01-12 04:14:54 --> Database Driver Class Initialized
DEBUG - 2018-01-12 04:14:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 04:14:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 04:14:54 --> Form Validation Class Initialized
INFO - 2018-01-12 04:14:54 --> Model Class Initialized
INFO - 2018-01-12 04:14:54 --> Controller Class Initialized
INFO - 2018-01-12 04:14:54 --> Model Class Initialized
INFO - 2018-01-12 04:14:54 --> Model Class Initialized
INFO - 2018-01-12 04:14:54 --> Model Class Initialized
INFO - 2018-01-12 04:14:54 --> Model Class Initialized
DEBUG - 2018-01-12 04:14:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 04:14:57 --> Config Class Initialized
INFO - 2018-01-12 04:14:57 --> Hooks Class Initialized
DEBUG - 2018-01-12 04:14:57 --> UTF-8 Support Enabled
INFO - 2018-01-12 04:14:57 --> Utf8 Class Initialized
INFO - 2018-01-12 04:14:57 --> URI Class Initialized
INFO - 2018-01-12 04:14:57 --> Router Class Initialized
INFO - 2018-01-12 04:14:57 --> Output Class Initialized
INFO - 2018-01-12 04:14:57 --> Security Class Initialized
DEBUG - 2018-01-12 04:14:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 04:14:57 --> Input Class Initialized
INFO - 2018-01-12 04:14:57 --> Language Class Initialized
INFO - 2018-01-12 04:14:57 --> Loader Class Initialized
INFO - 2018-01-12 04:14:57 --> Helper loaded: url_helper
INFO - 2018-01-12 04:14:57 --> Helper loaded: form_helper
INFO - 2018-01-12 04:14:57 --> Database Driver Class Initialized
DEBUG - 2018-01-12 04:14:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 04:14:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 04:14:57 --> Form Validation Class Initialized
INFO - 2018-01-12 04:14:57 --> Model Class Initialized
INFO - 2018-01-12 04:14:57 --> Controller Class Initialized
INFO - 2018-01-12 04:14:57 --> Model Class Initialized
INFO - 2018-01-12 04:14:57 --> Model Class Initialized
INFO - 2018-01-12 04:14:57 --> Model Class Initialized
INFO - 2018-01-12 04:14:57 --> Model Class Initialized
DEBUG - 2018-01-12 04:14:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 04:14:57 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-12 04:14:57 --> Final output sent to browser
DEBUG - 2018-01-12 04:14:57 --> Total execution time: 0.1178
INFO - 2018-01-12 04:14:58 --> Config Class Initialized
INFO - 2018-01-12 04:14:58 --> Hooks Class Initialized
DEBUG - 2018-01-12 04:14:58 --> UTF-8 Support Enabled
INFO - 2018-01-12 04:14:58 --> Utf8 Class Initialized
INFO - 2018-01-12 04:14:58 --> URI Class Initialized
INFO - 2018-01-12 04:14:58 --> Router Class Initialized
INFO - 2018-01-12 04:14:58 --> Output Class Initialized
INFO - 2018-01-12 04:14:58 --> Security Class Initialized
DEBUG - 2018-01-12 04:14:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 04:14:58 --> Input Class Initialized
INFO - 2018-01-12 04:14:58 --> Language Class Initialized
INFO - 2018-01-12 04:14:58 --> Loader Class Initialized
INFO - 2018-01-12 04:14:58 --> Helper loaded: url_helper
INFO - 2018-01-12 04:14:58 --> Helper loaded: form_helper
INFO - 2018-01-12 04:14:58 --> Database Driver Class Initialized
DEBUG - 2018-01-12 04:14:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 04:14:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 04:14:58 --> Form Validation Class Initialized
INFO - 2018-01-12 04:14:58 --> Model Class Initialized
INFO - 2018-01-12 04:14:58 --> Controller Class Initialized
INFO - 2018-01-12 04:14:58 --> Model Class Initialized
INFO - 2018-01-12 04:14:58 --> Model Class Initialized
INFO - 2018-01-12 04:14:58 --> Model Class Initialized
INFO - 2018-01-12 04:14:58 --> Model Class Initialized
DEBUG - 2018-01-12 04:14:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 04:16:10 --> Config Class Initialized
INFO - 2018-01-12 04:16:10 --> Hooks Class Initialized
DEBUG - 2018-01-12 04:16:10 --> UTF-8 Support Enabled
INFO - 2018-01-12 04:16:10 --> Utf8 Class Initialized
INFO - 2018-01-12 04:16:10 --> URI Class Initialized
INFO - 2018-01-12 04:16:10 --> Router Class Initialized
INFO - 2018-01-12 04:16:10 --> Output Class Initialized
INFO - 2018-01-12 04:16:10 --> Security Class Initialized
DEBUG - 2018-01-12 04:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 04:16:10 --> Input Class Initialized
INFO - 2018-01-12 04:16:10 --> Language Class Initialized
INFO - 2018-01-12 04:16:10 --> Loader Class Initialized
INFO - 2018-01-12 04:16:10 --> Helper loaded: url_helper
INFO - 2018-01-12 04:16:10 --> Helper loaded: form_helper
INFO - 2018-01-12 04:16:10 --> Database Driver Class Initialized
DEBUG - 2018-01-12 04:16:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 04:16:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 04:16:10 --> Form Validation Class Initialized
INFO - 2018-01-12 04:16:10 --> Model Class Initialized
INFO - 2018-01-12 04:16:10 --> Controller Class Initialized
INFO - 2018-01-12 04:16:10 --> Model Class Initialized
INFO - 2018-01-12 04:16:10 --> Model Class Initialized
INFO - 2018-01-12 04:16:10 --> Model Class Initialized
INFO - 2018-01-12 04:16:10 --> Model Class Initialized
DEBUG - 2018-01-12 04:16:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 04:16:10 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-12 04:16:10 --> Final output sent to browser
DEBUG - 2018-01-12 04:16:10 --> Total execution time: 0.0847
INFO - 2018-01-12 04:16:10 --> Config Class Initialized
INFO - 2018-01-12 04:16:10 --> Hooks Class Initialized
DEBUG - 2018-01-12 04:16:10 --> UTF-8 Support Enabled
INFO - 2018-01-12 04:16:10 --> Utf8 Class Initialized
INFO - 2018-01-12 04:16:10 --> URI Class Initialized
INFO - 2018-01-12 04:16:10 --> Router Class Initialized
INFO - 2018-01-12 04:16:10 --> Output Class Initialized
INFO - 2018-01-12 04:16:10 --> Security Class Initialized
DEBUG - 2018-01-12 04:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 04:16:10 --> Input Class Initialized
INFO - 2018-01-12 04:16:10 --> Language Class Initialized
INFO - 2018-01-12 04:16:10 --> Loader Class Initialized
INFO - 2018-01-12 04:16:10 --> Helper loaded: url_helper
INFO - 2018-01-12 04:16:10 --> Helper loaded: form_helper
INFO - 2018-01-12 04:16:10 --> Database Driver Class Initialized
DEBUG - 2018-01-12 04:16:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 04:16:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 04:16:10 --> Form Validation Class Initialized
INFO - 2018-01-12 04:16:10 --> Model Class Initialized
INFO - 2018-01-12 04:16:10 --> Controller Class Initialized
INFO - 2018-01-12 04:16:10 --> Model Class Initialized
INFO - 2018-01-12 04:16:10 --> Model Class Initialized
INFO - 2018-01-12 04:16:10 --> Model Class Initialized
INFO - 2018-01-12 04:16:10 --> Model Class Initialized
DEBUG - 2018-01-12 04:16:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 04:16:29 --> Config Class Initialized
INFO - 2018-01-12 04:16:29 --> Hooks Class Initialized
DEBUG - 2018-01-12 04:16:29 --> UTF-8 Support Enabled
INFO - 2018-01-12 04:16:29 --> Utf8 Class Initialized
INFO - 2018-01-12 04:16:29 --> URI Class Initialized
INFO - 2018-01-12 04:16:29 --> Router Class Initialized
INFO - 2018-01-12 04:16:29 --> Output Class Initialized
INFO - 2018-01-12 04:16:29 --> Security Class Initialized
DEBUG - 2018-01-12 04:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 04:16:29 --> Input Class Initialized
INFO - 2018-01-12 04:16:29 --> Language Class Initialized
INFO - 2018-01-12 04:16:29 --> Loader Class Initialized
INFO - 2018-01-12 04:16:29 --> Helper loaded: url_helper
INFO - 2018-01-12 04:16:29 --> Helper loaded: form_helper
INFO - 2018-01-12 04:16:29 --> Database Driver Class Initialized
DEBUG - 2018-01-12 04:16:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 04:16:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 04:16:29 --> Form Validation Class Initialized
INFO - 2018-01-12 04:16:29 --> Model Class Initialized
INFO - 2018-01-12 04:16:29 --> Controller Class Initialized
INFO - 2018-01-12 04:16:29 --> Model Class Initialized
INFO - 2018-01-12 04:16:29 --> Model Class Initialized
INFO - 2018-01-12 04:16:29 --> Model Class Initialized
INFO - 2018-01-12 04:16:29 --> Model Class Initialized
DEBUG - 2018-01-12 04:16:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 04:16:29 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-12 04:16:29 --> Final output sent to browser
DEBUG - 2018-01-12 04:16:29 --> Total execution time: 0.1127
INFO - 2018-01-12 04:16:30 --> Config Class Initialized
INFO - 2018-01-12 04:16:30 --> Hooks Class Initialized
DEBUG - 2018-01-12 04:16:30 --> UTF-8 Support Enabled
INFO - 2018-01-12 04:16:30 --> Utf8 Class Initialized
INFO - 2018-01-12 04:16:30 --> URI Class Initialized
INFO - 2018-01-12 04:16:30 --> Router Class Initialized
INFO - 2018-01-12 04:16:30 --> Output Class Initialized
INFO - 2018-01-12 04:16:30 --> Security Class Initialized
DEBUG - 2018-01-12 04:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 04:16:30 --> Input Class Initialized
INFO - 2018-01-12 04:16:30 --> Language Class Initialized
INFO - 2018-01-12 04:16:30 --> Loader Class Initialized
INFO - 2018-01-12 04:16:30 --> Helper loaded: url_helper
INFO - 2018-01-12 04:16:30 --> Helper loaded: form_helper
INFO - 2018-01-12 04:16:30 --> Database Driver Class Initialized
DEBUG - 2018-01-12 04:16:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 04:16:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 04:16:30 --> Form Validation Class Initialized
INFO - 2018-01-12 04:16:30 --> Model Class Initialized
INFO - 2018-01-12 04:16:30 --> Controller Class Initialized
INFO - 2018-01-12 04:16:30 --> Model Class Initialized
INFO - 2018-01-12 04:16:30 --> Model Class Initialized
INFO - 2018-01-12 04:16:30 --> Model Class Initialized
INFO - 2018-01-12 04:16:30 --> Model Class Initialized
DEBUG - 2018-01-12 04:16:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 04:17:16 --> Config Class Initialized
INFO - 2018-01-12 04:17:16 --> Hooks Class Initialized
DEBUG - 2018-01-12 04:17:16 --> UTF-8 Support Enabled
INFO - 2018-01-12 04:17:16 --> Utf8 Class Initialized
INFO - 2018-01-12 04:17:16 --> URI Class Initialized
INFO - 2018-01-12 04:17:16 --> Router Class Initialized
INFO - 2018-01-12 04:17:16 --> Output Class Initialized
INFO - 2018-01-12 04:17:16 --> Security Class Initialized
DEBUG - 2018-01-12 04:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 04:17:16 --> Input Class Initialized
INFO - 2018-01-12 04:17:16 --> Language Class Initialized
INFO - 2018-01-12 04:17:16 --> Loader Class Initialized
INFO - 2018-01-12 04:17:16 --> Helper loaded: url_helper
INFO - 2018-01-12 04:17:16 --> Helper loaded: form_helper
INFO - 2018-01-12 04:17:16 --> Database Driver Class Initialized
DEBUG - 2018-01-12 04:17:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 04:17:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 04:17:16 --> Form Validation Class Initialized
INFO - 2018-01-12 04:17:16 --> Model Class Initialized
INFO - 2018-01-12 04:17:16 --> Controller Class Initialized
INFO - 2018-01-12 04:17:16 --> Model Class Initialized
INFO - 2018-01-12 04:17:16 --> Model Class Initialized
INFO - 2018-01-12 04:17:16 --> Model Class Initialized
INFO - 2018-01-12 04:17:16 --> Model Class Initialized
DEBUG - 2018-01-12 04:17:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 04:17:17 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-12 04:17:17 --> Final output sent to browser
DEBUG - 2018-01-12 04:17:17 --> Total execution time: 0.3715
INFO - 2018-01-12 04:17:17 --> Config Class Initialized
INFO - 2018-01-12 04:17:17 --> Hooks Class Initialized
INFO - 2018-01-12 04:17:17 --> Config Class Initialized
INFO - 2018-01-12 04:17:17 --> Hooks Class Initialized
DEBUG - 2018-01-12 04:17:17 --> UTF-8 Support Enabled
INFO - 2018-01-12 04:17:17 --> Utf8 Class Initialized
DEBUG - 2018-01-12 04:17:17 --> UTF-8 Support Enabled
INFO - 2018-01-12 04:17:17 --> Utf8 Class Initialized
INFO - 2018-01-12 04:17:17 --> URI Class Initialized
INFO - 2018-01-12 04:17:17 --> URI Class Initialized
INFO - 2018-01-12 04:17:17 --> Router Class Initialized
INFO - 2018-01-12 04:17:17 --> Router Class Initialized
INFO - 2018-01-12 04:17:17 --> Output Class Initialized
INFO - 2018-01-12 04:17:17 --> Output Class Initialized
INFO - 2018-01-12 04:17:17 --> Security Class Initialized
INFO - 2018-01-12 04:17:17 --> Security Class Initialized
DEBUG - 2018-01-12 04:17:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-01-12 04:17:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 04:17:17 --> Input Class Initialized
INFO - 2018-01-12 04:17:17 --> Input Class Initialized
INFO - 2018-01-12 04:17:17 --> Language Class Initialized
INFO - 2018-01-12 04:17:17 --> Language Class Initialized
INFO - 2018-01-12 04:17:17 --> Loader Class Initialized
INFO - 2018-01-12 04:17:17 --> Loader Class Initialized
INFO - 2018-01-12 04:17:17 --> Helper loaded: url_helper
INFO - 2018-01-12 04:17:17 --> Helper loaded: url_helper
INFO - 2018-01-12 04:17:17 --> Helper loaded: form_helper
INFO - 2018-01-12 04:17:17 --> Helper loaded: form_helper
INFO - 2018-01-12 04:17:17 --> Database Driver Class Initialized
INFO - 2018-01-12 04:17:17 --> Database Driver Class Initialized
DEBUG - 2018-01-12 04:17:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-01-12 04:17:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 04:17:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 04:17:17 --> Form Validation Class Initialized
INFO - 2018-01-12 04:17:17 --> Model Class Initialized
INFO - 2018-01-12 04:17:17 --> Controller Class Initialized
INFO - 2018-01-12 04:17:17 --> Model Class Initialized
INFO - 2018-01-12 04:17:17 --> Model Class Initialized
INFO - 2018-01-12 04:17:17 --> Model Class Initialized
INFO - 2018-01-12 04:17:17 --> Model Class Initialized
DEBUG - 2018-01-12 04:17:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 04:17:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 04:17:17 --> Form Validation Class Initialized
INFO - 2018-01-12 04:17:17 --> Model Class Initialized
INFO - 2018-01-12 04:17:17 --> Controller Class Initialized
INFO - 2018-01-12 04:17:17 --> Model Class Initialized
INFO - 2018-01-12 04:17:17 --> Model Class Initialized
INFO - 2018-01-12 04:17:17 --> Model Class Initialized
INFO - 2018-01-12 04:17:17 --> Model Class Initialized
DEBUG - 2018-01-12 04:17:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 04:17:24 --> Config Class Initialized
INFO - 2018-01-12 04:17:24 --> Hooks Class Initialized
DEBUG - 2018-01-12 04:17:24 --> UTF-8 Support Enabled
INFO - 2018-01-12 04:17:24 --> Utf8 Class Initialized
INFO - 2018-01-12 04:17:24 --> URI Class Initialized
INFO - 2018-01-12 04:17:24 --> Router Class Initialized
INFO - 2018-01-12 04:17:24 --> Output Class Initialized
INFO - 2018-01-12 04:17:24 --> Security Class Initialized
DEBUG - 2018-01-12 04:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 04:17:24 --> Input Class Initialized
INFO - 2018-01-12 04:17:24 --> Language Class Initialized
INFO - 2018-01-12 04:17:24 --> Loader Class Initialized
INFO - 2018-01-12 04:17:24 --> Helper loaded: url_helper
INFO - 2018-01-12 04:17:24 --> Helper loaded: form_helper
INFO - 2018-01-12 04:17:24 --> Database Driver Class Initialized
DEBUG - 2018-01-12 04:17:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 04:17:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 04:17:24 --> Form Validation Class Initialized
INFO - 2018-01-12 04:17:24 --> Model Class Initialized
INFO - 2018-01-12 04:17:24 --> Controller Class Initialized
INFO - 2018-01-12 04:17:24 --> Model Class Initialized
INFO - 2018-01-12 04:17:24 --> Model Class Initialized
INFO - 2018-01-12 04:17:24 --> Model Class Initialized
INFO - 2018-01-12 04:17:24 --> Model Class Initialized
DEBUG - 2018-01-12 04:17:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 04:17:24 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-12 04:17:24 --> Final output sent to browser
DEBUG - 2018-01-12 04:17:24 --> Total execution time: 0.1218
INFO - 2018-01-12 04:17:24 --> Config Class Initialized
INFO - 2018-01-12 04:17:24 --> Hooks Class Initialized
DEBUG - 2018-01-12 04:17:24 --> UTF-8 Support Enabled
INFO - 2018-01-12 04:17:24 --> Utf8 Class Initialized
INFO - 2018-01-12 04:17:24 --> URI Class Initialized
INFO - 2018-01-12 04:17:24 --> Router Class Initialized
INFO - 2018-01-12 04:17:24 --> Output Class Initialized
INFO - 2018-01-12 04:17:24 --> Security Class Initialized
DEBUG - 2018-01-12 04:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 04:17:24 --> Input Class Initialized
INFO - 2018-01-12 04:17:24 --> Language Class Initialized
INFO - 2018-01-12 04:17:24 --> Loader Class Initialized
INFO - 2018-01-12 04:17:24 --> Helper loaded: url_helper
INFO - 2018-01-12 04:17:24 --> Helper loaded: form_helper
INFO - 2018-01-12 04:17:24 --> Database Driver Class Initialized
DEBUG - 2018-01-12 04:17:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 04:17:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 04:17:24 --> Form Validation Class Initialized
INFO - 2018-01-12 04:17:24 --> Model Class Initialized
INFO - 2018-01-12 04:17:24 --> Controller Class Initialized
INFO - 2018-01-12 04:17:24 --> Model Class Initialized
INFO - 2018-01-12 04:17:24 --> Model Class Initialized
INFO - 2018-01-12 04:17:24 --> Model Class Initialized
INFO - 2018-01-12 04:17:24 --> Model Class Initialized
DEBUG - 2018-01-12 04:17:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 04:17:28 --> Config Class Initialized
INFO - 2018-01-12 04:17:28 --> Hooks Class Initialized
DEBUG - 2018-01-12 04:17:28 --> UTF-8 Support Enabled
INFO - 2018-01-12 04:17:28 --> Utf8 Class Initialized
INFO - 2018-01-12 04:17:28 --> URI Class Initialized
INFO - 2018-01-12 04:17:28 --> Router Class Initialized
INFO - 2018-01-12 04:17:28 --> Output Class Initialized
INFO - 2018-01-12 04:17:28 --> Security Class Initialized
DEBUG - 2018-01-12 04:17:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 04:17:28 --> Input Class Initialized
INFO - 2018-01-12 04:17:28 --> Language Class Initialized
INFO - 2018-01-12 04:17:28 --> Loader Class Initialized
INFO - 2018-01-12 04:17:28 --> Helper loaded: url_helper
INFO - 2018-01-12 04:17:28 --> Helper loaded: form_helper
INFO - 2018-01-12 04:17:28 --> Database Driver Class Initialized
DEBUG - 2018-01-12 04:17:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 04:17:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 04:17:28 --> Form Validation Class Initialized
INFO - 2018-01-12 04:17:28 --> Model Class Initialized
INFO - 2018-01-12 04:17:28 --> Controller Class Initialized
INFO - 2018-01-12 04:17:28 --> Model Class Initialized
INFO - 2018-01-12 04:17:28 --> Model Class Initialized
INFO - 2018-01-12 04:17:28 --> Model Class Initialized
INFO - 2018-01-12 04:17:28 --> Model Class Initialized
DEBUG - 2018-01-12 04:17:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 04:17:28 --> Final output sent to browser
DEBUG - 2018-01-12 04:17:28 --> Total execution time: 0.6313
INFO - 2018-01-12 04:22:46 --> Config Class Initialized
INFO - 2018-01-12 04:22:46 --> Hooks Class Initialized
DEBUG - 2018-01-12 04:22:46 --> UTF-8 Support Enabled
INFO - 2018-01-12 04:22:46 --> Utf8 Class Initialized
INFO - 2018-01-12 04:22:46 --> URI Class Initialized
INFO - 2018-01-12 04:22:46 --> Router Class Initialized
INFO - 2018-01-12 04:22:46 --> Output Class Initialized
INFO - 2018-01-12 04:22:46 --> Security Class Initialized
DEBUG - 2018-01-12 04:22:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 04:22:46 --> Input Class Initialized
INFO - 2018-01-12 04:22:47 --> Language Class Initialized
INFO - 2018-01-12 04:22:47 --> Loader Class Initialized
INFO - 2018-01-12 04:22:47 --> Helper loaded: url_helper
INFO - 2018-01-12 04:22:47 --> Helper loaded: form_helper
INFO - 2018-01-12 04:22:47 --> Database Driver Class Initialized
DEBUG - 2018-01-12 04:22:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 04:22:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 04:22:47 --> Form Validation Class Initialized
INFO - 2018-01-12 04:22:47 --> Model Class Initialized
INFO - 2018-01-12 04:22:47 --> Controller Class Initialized
INFO - 2018-01-12 04:22:47 --> Model Class Initialized
INFO - 2018-01-12 04:22:47 --> Model Class Initialized
INFO - 2018-01-12 04:22:47 --> Model Class Initialized
INFO - 2018-01-12 04:22:47 --> Model Class Initialized
DEBUG - 2018-01-12 04:22:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 04:22:47 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-12 04:22:47 --> Final output sent to browser
DEBUG - 2018-01-12 04:22:47 --> Total execution time: 0.0990
INFO - 2018-01-12 04:22:59 --> Config Class Initialized
INFO - 2018-01-12 04:22:59 --> Hooks Class Initialized
DEBUG - 2018-01-12 04:22:59 --> UTF-8 Support Enabled
INFO - 2018-01-12 04:22:59 --> Utf8 Class Initialized
INFO - 2018-01-12 04:22:59 --> URI Class Initialized
INFO - 2018-01-12 04:22:59 --> Router Class Initialized
INFO - 2018-01-12 04:22:59 --> Output Class Initialized
INFO - 2018-01-12 04:22:59 --> Security Class Initialized
DEBUG - 2018-01-12 04:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 04:22:59 --> Input Class Initialized
INFO - 2018-01-12 04:22:59 --> Language Class Initialized
INFO - 2018-01-12 04:22:59 --> Loader Class Initialized
INFO - 2018-01-12 04:22:59 --> Helper loaded: url_helper
INFO - 2018-01-12 04:22:59 --> Helper loaded: form_helper
INFO - 2018-01-12 04:22:59 --> Database Driver Class Initialized
DEBUG - 2018-01-12 04:22:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 04:22:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 04:22:59 --> Form Validation Class Initialized
INFO - 2018-01-12 04:22:59 --> Model Class Initialized
INFO - 2018-01-12 04:22:59 --> Controller Class Initialized
INFO - 2018-01-12 04:22:59 --> Model Class Initialized
INFO - 2018-01-12 04:22:59 --> Model Class Initialized
INFO - 2018-01-12 04:22:59 --> Model Class Initialized
INFO - 2018-01-12 04:22:59 --> Model Class Initialized
DEBUG - 2018-01-12 04:22:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 04:22:59 --> Final output sent to browser
DEBUG - 2018-01-12 04:22:59 --> Total execution time: 0.2978
INFO - 2018-01-12 04:24:49 --> Config Class Initialized
INFO - 2018-01-12 04:24:49 --> Hooks Class Initialized
DEBUG - 2018-01-12 04:24:49 --> UTF-8 Support Enabled
INFO - 2018-01-12 04:24:49 --> Utf8 Class Initialized
INFO - 2018-01-12 04:24:49 --> URI Class Initialized
INFO - 2018-01-12 04:24:49 --> Router Class Initialized
INFO - 2018-01-12 04:24:49 --> Output Class Initialized
INFO - 2018-01-12 04:24:49 --> Security Class Initialized
DEBUG - 2018-01-12 04:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 04:24:49 --> Input Class Initialized
INFO - 2018-01-12 04:24:49 --> Language Class Initialized
INFO - 2018-01-12 04:24:49 --> Loader Class Initialized
INFO - 2018-01-12 04:24:49 --> Helper loaded: url_helper
INFO - 2018-01-12 04:24:49 --> Helper loaded: form_helper
INFO - 2018-01-12 04:24:49 --> Database Driver Class Initialized
DEBUG - 2018-01-12 04:24:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 04:24:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 04:24:49 --> Form Validation Class Initialized
INFO - 2018-01-12 04:24:49 --> Model Class Initialized
INFO - 2018-01-12 04:24:49 --> Controller Class Initialized
INFO - 2018-01-12 04:24:49 --> Model Class Initialized
INFO - 2018-01-12 04:24:49 --> Model Class Initialized
INFO - 2018-01-12 04:24:49 --> Model Class Initialized
INFO - 2018-01-12 04:24:49 --> Model Class Initialized
DEBUG - 2018-01-12 04:24:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 04:24:49 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-12 04:24:49 --> Final output sent to browser
DEBUG - 2018-01-12 04:24:49 --> Total execution time: 0.1100
INFO - 2018-01-12 04:24:56 --> Config Class Initialized
INFO - 2018-01-12 04:24:56 --> Hooks Class Initialized
DEBUG - 2018-01-12 04:24:56 --> UTF-8 Support Enabled
INFO - 2018-01-12 04:24:56 --> Utf8 Class Initialized
INFO - 2018-01-12 04:24:56 --> URI Class Initialized
INFO - 2018-01-12 04:24:56 --> Router Class Initialized
INFO - 2018-01-12 04:24:56 --> Output Class Initialized
INFO - 2018-01-12 04:24:56 --> Security Class Initialized
DEBUG - 2018-01-12 04:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 04:24:56 --> Input Class Initialized
INFO - 2018-01-12 04:24:56 --> Language Class Initialized
INFO - 2018-01-12 04:24:56 --> Loader Class Initialized
INFO - 2018-01-12 04:24:56 --> Helper loaded: url_helper
INFO - 2018-01-12 04:24:56 --> Helper loaded: form_helper
INFO - 2018-01-12 04:24:56 --> Database Driver Class Initialized
DEBUG - 2018-01-12 04:24:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 04:24:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 04:24:56 --> Form Validation Class Initialized
INFO - 2018-01-12 04:24:56 --> Model Class Initialized
INFO - 2018-01-12 04:24:56 --> Controller Class Initialized
INFO - 2018-01-12 04:24:56 --> Model Class Initialized
INFO - 2018-01-12 04:24:56 --> Model Class Initialized
INFO - 2018-01-12 04:24:56 --> Model Class Initialized
INFO - 2018-01-12 04:24:56 --> Model Class Initialized
DEBUG - 2018-01-12 04:24:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 04:24:56 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-12 04:24:56 --> Final output sent to browser
DEBUG - 2018-01-12 04:24:56 --> Total execution time: 0.1072
INFO - 2018-01-12 04:24:58 --> Config Class Initialized
INFO - 2018-01-12 04:24:58 --> Hooks Class Initialized
DEBUG - 2018-01-12 04:24:58 --> UTF-8 Support Enabled
INFO - 2018-01-12 04:24:58 --> Utf8 Class Initialized
INFO - 2018-01-12 04:24:58 --> URI Class Initialized
INFO - 2018-01-12 04:24:58 --> Router Class Initialized
INFO - 2018-01-12 04:24:58 --> Output Class Initialized
INFO - 2018-01-12 04:24:58 --> Security Class Initialized
DEBUG - 2018-01-12 04:24:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 04:24:58 --> Input Class Initialized
INFO - 2018-01-12 04:24:58 --> Language Class Initialized
INFO - 2018-01-12 04:24:58 --> Loader Class Initialized
INFO - 2018-01-12 04:24:58 --> Helper loaded: url_helper
INFO - 2018-01-12 04:24:58 --> Helper loaded: form_helper
INFO - 2018-01-12 04:24:58 --> Database Driver Class Initialized
DEBUG - 2018-01-12 04:24:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 04:24:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 04:24:58 --> Form Validation Class Initialized
INFO - 2018-01-12 04:24:58 --> Model Class Initialized
INFO - 2018-01-12 04:24:58 --> Controller Class Initialized
INFO - 2018-01-12 04:24:58 --> Model Class Initialized
INFO - 2018-01-12 04:24:58 --> Model Class Initialized
INFO - 2018-01-12 04:24:58 --> Model Class Initialized
INFO - 2018-01-12 04:24:58 --> Model Class Initialized
DEBUG - 2018-01-12 04:24:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 04:24:58 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-12 04:24:58 --> Final output sent to browser
DEBUG - 2018-01-12 04:24:58 --> Total execution time: 0.0881
INFO - 2018-01-12 04:24:58 --> Config Class Initialized
INFO - 2018-01-12 04:24:58 --> Hooks Class Initialized
DEBUG - 2018-01-12 04:24:58 --> UTF-8 Support Enabled
INFO - 2018-01-12 04:24:58 --> Utf8 Class Initialized
INFO - 2018-01-12 04:24:58 --> URI Class Initialized
INFO - 2018-01-12 04:24:58 --> Router Class Initialized
INFO - 2018-01-12 04:24:58 --> Output Class Initialized
INFO - 2018-01-12 04:24:58 --> Security Class Initialized
DEBUG - 2018-01-12 04:24:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 04:24:58 --> Input Class Initialized
INFO - 2018-01-12 04:24:58 --> Language Class Initialized
INFO - 2018-01-12 04:24:58 --> Loader Class Initialized
INFO - 2018-01-12 04:24:58 --> Helper loaded: url_helper
INFO - 2018-01-12 04:24:58 --> Helper loaded: form_helper
INFO - 2018-01-12 04:24:58 --> Database Driver Class Initialized
DEBUG - 2018-01-12 04:24:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 04:24:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 04:24:58 --> Form Validation Class Initialized
INFO - 2018-01-12 04:24:58 --> Model Class Initialized
INFO - 2018-01-12 04:24:58 --> Controller Class Initialized
INFO - 2018-01-12 04:24:58 --> Model Class Initialized
INFO - 2018-01-12 04:24:58 --> Model Class Initialized
INFO - 2018-01-12 04:24:58 --> Model Class Initialized
INFO - 2018-01-12 04:24:58 --> Model Class Initialized
DEBUG - 2018-01-12 04:24:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 04:25:20 --> Config Class Initialized
INFO - 2018-01-12 04:25:20 --> Hooks Class Initialized
DEBUG - 2018-01-12 04:25:20 --> UTF-8 Support Enabled
INFO - 2018-01-12 04:25:20 --> Utf8 Class Initialized
INFO - 2018-01-12 04:25:20 --> URI Class Initialized
INFO - 2018-01-12 04:25:20 --> Router Class Initialized
INFO - 2018-01-12 04:25:20 --> Output Class Initialized
INFO - 2018-01-12 04:25:20 --> Security Class Initialized
DEBUG - 2018-01-12 04:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 04:25:20 --> Input Class Initialized
INFO - 2018-01-12 04:25:20 --> Language Class Initialized
INFO - 2018-01-12 04:25:20 --> Loader Class Initialized
INFO - 2018-01-12 04:25:20 --> Helper loaded: url_helper
INFO - 2018-01-12 04:25:20 --> Helper loaded: form_helper
INFO - 2018-01-12 04:25:20 --> Database Driver Class Initialized
DEBUG - 2018-01-12 04:25:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 04:25:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 04:25:20 --> Form Validation Class Initialized
INFO - 2018-01-12 04:25:20 --> Model Class Initialized
INFO - 2018-01-12 04:25:20 --> Controller Class Initialized
INFO - 2018-01-12 04:25:20 --> Model Class Initialized
INFO - 2018-01-12 04:25:20 --> Model Class Initialized
INFO - 2018-01-12 04:25:20 --> Model Class Initialized
INFO - 2018-01-12 04:25:20 --> Model Class Initialized
DEBUG - 2018-01-12 04:25:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 04:25:27 --> Config Class Initialized
INFO - 2018-01-12 04:25:27 --> Hooks Class Initialized
DEBUG - 2018-01-12 04:25:27 --> UTF-8 Support Enabled
INFO - 2018-01-12 04:25:27 --> Utf8 Class Initialized
INFO - 2018-01-12 04:25:27 --> URI Class Initialized
INFO - 2018-01-12 04:25:27 --> Router Class Initialized
INFO - 2018-01-12 04:25:27 --> Output Class Initialized
INFO - 2018-01-12 04:25:27 --> Security Class Initialized
DEBUG - 2018-01-12 04:25:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 04:25:27 --> Input Class Initialized
INFO - 2018-01-12 04:25:27 --> Language Class Initialized
INFO - 2018-01-12 04:25:27 --> Loader Class Initialized
INFO - 2018-01-12 04:25:27 --> Helper loaded: url_helper
INFO - 2018-01-12 04:25:27 --> Helper loaded: form_helper
INFO - 2018-01-12 04:25:27 --> Database Driver Class Initialized
DEBUG - 2018-01-12 04:25:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 04:25:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 04:25:27 --> Form Validation Class Initialized
INFO - 2018-01-12 04:25:27 --> Model Class Initialized
INFO - 2018-01-12 04:25:27 --> Controller Class Initialized
INFO - 2018-01-12 04:25:27 --> Model Class Initialized
INFO - 2018-01-12 04:25:27 --> Model Class Initialized
INFO - 2018-01-12 04:25:27 --> Model Class Initialized
INFO - 2018-01-12 04:25:27 --> Model Class Initialized
DEBUG - 2018-01-12 04:25:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 04:25:27 --> Config Class Initialized
INFO - 2018-01-12 04:25:27 --> Hooks Class Initialized
DEBUG - 2018-01-12 04:25:27 --> UTF-8 Support Enabled
INFO - 2018-01-12 04:25:27 --> Utf8 Class Initialized
INFO - 2018-01-12 04:25:27 --> URI Class Initialized
INFO - 2018-01-12 04:25:27 --> Router Class Initialized
INFO - 2018-01-12 04:25:27 --> Output Class Initialized
INFO - 2018-01-12 04:25:27 --> Security Class Initialized
DEBUG - 2018-01-12 04:25:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 04:25:27 --> Input Class Initialized
INFO - 2018-01-12 04:25:27 --> Language Class Initialized
INFO - 2018-01-12 04:25:27 --> Loader Class Initialized
INFO - 2018-01-12 04:25:27 --> Helper loaded: url_helper
INFO - 2018-01-12 04:25:27 --> Helper loaded: form_helper
INFO - 2018-01-12 04:25:27 --> Database Driver Class Initialized
DEBUG - 2018-01-12 04:25:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 04:25:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 04:25:27 --> Form Validation Class Initialized
INFO - 2018-01-12 04:25:27 --> Model Class Initialized
INFO - 2018-01-12 04:25:27 --> Controller Class Initialized
INFO - 2018-01-12 04:25:27 --> Model Class Initialized
INFO - 2018-01-12 04:25:27 --> Model Class Initialized
INFO - 2018-01-12 04:25:27 --> Model Class Initialized
INFO - 2018-01-12 04:25:27 --> Model Class Initialized
DEBUG - 2018-01-12 04:25:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 04:25:31 --> Config Class Initialized
INFO - 2018-01-12 04:25:31 --> Hooks Class Initialized
DEBUG - 2018-01-12 04:25:31 --> UTF-8 Support Enabled
INFO - 2018-01-12 04:25:31 --> Utf8 Class Initialized
INFO - 2018-01-12 04:25:31 --> URI Class Initialized
INFO - 2018-01-12 04:25:31 --> Router Class Initialized
INFO - 2018-01-12 04:25:31 --> Output Class Initialized
INFO - 2018-01-12 04:25:31 --> Security Class Initialized
DEBUG - 2018-01-12 04:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 04:25:31 --> Input Class Initialized
INFO - 2018-01-12 04:25:31 --> Language Class Initialized
INFO - 2018-01-12 04:25:31 --> Loader Class Initialized
INFO - 2018-01-12 04:25:31 --> Helper loaded: url_helper
INFO - 2018-01-12 04:25:31 --> Helper loaded: form_helper
INFO - 2018-01-12 04:25:31 --> Database Driver Class Initialized
DEBUG - 2018-01-12 04:25:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 04:25:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 04:25:31 --> Form Validation Class Initialized
INFO - 2018-01-12 04:25:31 --> Model Class Initialized
INFO - 2018-01-12 04:25:31 --> Controller Class Initialized
INFO - 2018-01-12 04:25:31 --> Model Class Initialized
INFO - 2018-01-12 04:25:31 --> Model Class Initialized
INFO - 2018-01-12 04:25:31 --> Model Class Initialized
INFO - 2018-01-12 04:25:31 --> Model Class Initialized
DEBUG - 2018-01-12 04:25:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 04:25:31 --> Final output sent to browser
DEBUG - 2018-01-12 04:25:31 --> Total execution time: 0.1228
INFO - 2018-01-12 04:25:31 --> Config Class Initialized
INFO - 2018-01-12 04:25:31 --> Hooks Class Initialized
DEBUG - 2018-01-12 04:25:31 --> UTF-8 Support Enabled
INFO - 2018-01-12 04:25:31 --> Utf8 Class Initialized
INFO - 2018-01-12 04:25:31 --> URI Class Initialized
INFO - 2018-01-12 04:25:31 --> Router Class Initialized
INFO - 2018-01-12 04:25:31 --> Output Class Initialized
INFO - 2018-01-12 04:25:31 --> Security Class Initialized
DEBUG - 2018-01-12 04:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 04:25:31 --> Input Class Initialized
INFO - 2018-01-12 04:25:31 --> Language Class Initialized
INFO - 2018-01-12 04:25:31 --> Loader Class Initialized
INFO - 2018-01-12 04:25:31 --> Helper loaded: url_helper
INFO - 2018-01-12 04:25:31 --> Helper loaded: form_helper
INFO - 2018-01-12 04:25:31 --> Database Driver Class Initialized
DEBUG - 2018-01-12 04:25:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 04:25:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 04:25:31 --> Form Validation Class Initialized
INFO - 2018-01-12 04:25:31 --> Model Class Initialized
INFO - 2018-01-12 04:25:31 --> Controller Class Initialized
INFO - 2018-01-12 04:25:31 --> Model Class Initialized
INFO - 2018-01-12 04:25:31 --> Model Class Initialized
INFO - 2018-01-12 04:25:31 --> Model Class Initialized
INFO - 2018-01-12 04:25:31 --> Model Class Initialized
DEBUG - 2018-01-12 04:25:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 04:25:33 --> Config Class Initialized
INFO - 2018-01-12 04:25:33 --> Hooks Class Initialized
DEBUG - 2018-01-12 04:25:33 --> UTF-8 Support Enabled
INFO - 2018-01-12 04:25:33 --> Utf8 Class Initialized
INFO - 2018-01-12 04:25:33 --> URI Class Initialized
INFO - 2018-01-12 04:25:33 --> Router Class Initialized
INFO - 2018-01-12 04:25:33 --> Output Class Initialized
INFO - 2018-01-12 04:25:33 --> Security Class Initialized
DEBUG - 2018-01-12 04:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 04:25:33 --> Input Class Initialized
INFO - 2018-01-12 04:25:33 --> Language Class Initialized
INFO - 2018-01-12 04:25:33 --> Loader Class Initialized
INFO - 2018-01-12 04:25:33 --> Helper loaded: url_helper
INFO - 2018-01-12 04:25:33 --> Helper loaded: form_helper
INFO - 2018-01-12 04:25:33 --> Database Driver Class Initialized
DEBUG - 2018-01-12 04:25:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 04:25:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 04:25:33 --> Form Validation Class Initialized
INFO - 2018-01-12 04:25:33 --> Model Class Initialized
INFO - 2018-01-12 04:25:33 --> Controller Class Initialized
INFO - 2018-01-12 04:25:33 --> Model Class Initialized
INFO - 2018-01-12 04:25:33 --> Model Class Initialized
INFO - 2018-01-12 04:25:33 --> Model Class Initialized
INFO - 2018-01-12 04:25:33 --> Model Class Initialized
DEBUG - 2018-01-12 04:25:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 04:25:33 --> Final output sent to browser
DEBUG - 2018-01-12 04:25:33 --> Total execution time: 0.0602
INFO - 2018-01-12 04:25:34 --> Config Class Initialized
INFO - 2018-01-12 04:25:34 --> Hooks Class Initialized
DEBUG - 2018-01-12 04:25:34 --> UTF-8 Support Enabled
INFO - 2018-01-12 04:25:34 --> Utf8 Class Initialized
INFO - 2018-01-12 04:25:34 --> URI Class Initialized
INFO - 2018-01-12 04:25:34 --> Router Class Initialized
INFO - 2018-01-12 04:25:34 --> Output Class Initialized
INFO - 2018-01-12 04:25:34 --> Security Class Initialized
DEBUG - 2018-01-12 04:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 04:25:34 --> Input Class Initialized
INFO - 2018-01-12 04:25:34 --> Language Class Initialized
INFO - 2018-01-12 04:25:34 --> Loader Class Initialized
INFO - 2018-01-12 04:25:34 --> Helper loaded: url_helper
INFO - 2018-01-12 04:25:34 --> Helper loaded: form_helper
INFO - 2018-01-12 04:25:34 --> Database Driver Class Initialized
DEBUG - 2018-01-12 04:25:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 04:25:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 04:25:34 --> Form Validation Class Initialized
INFO - 2018-01-12 04:25:34 --> Model Class Initialized
INFO - 2018-01-12 04:25:34 --> Controller Class Initialized
INFO - 2018-01-12 04:25:34 --> Model Class Initialized
INFO - 2018-01-12 04:25:34 --> Model Class Initialized
INFO - 2018-01-12 04:25:34 --> Model Class Initialized
INFO - 2018-01-12 04:25:34 --> Model Class Initialized
DEBUG - 2018-01-12 04:25:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 04:25:35 --> Config Class Initialized
INFO - 2018-01-12 04:25:35 --> Hooks Class Initialized
DEBUG - 2018-01-12 04:25:35 --> UTF-8 Support Enabled
INFO - 2018-01-12 04:25:35 --> Utf8 Class Initialized
INFO - 2018-01-12 04:25:35 --> URI Class Initialized
INFO - 2018-01-12 04:25:35 --> Router Class Initialized
INFO - 2018-01-12 04:25:35 --> Output Class Initialized
INFO - 2018-01-12 04:25:35 --> Security Class Initialized
DEBUG - 2018-01-12 04:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 04:25:35 --> Input Class Initialized
INFO - 2018-01-12 04:25:35 --> Language Class Initialized
INFO - 2018-01-12 04:25:35 --> Loader Class Initialized
INFO - 2018-01-12 04:25:35 --> Helper loaded: url_helper
INFO - 2018-01-12 04:25:35 --> Helper loaded: form_helper
INFO - 2018-01-12 04:25:35 --> Database Driver Class Initialized
DEBUG - 2018-01-12 04:25:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 04:25:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 04:25:35 --> Form Validation Class Initialized
INFO - 2018-01-12 04:25:35 --> Model Class Initialized
INFO - 2018-01-12 04:25:35 --> Controller Class Initialized
INFO - 2018-01-12 04:25:35 --> Model Class Initialized
INFO - 2018-01-12 04:25:35 --> Model Class Initialized
INFO - 2018-01-12 04:25:35 --> Model Class Initialized
INFO - 2018-01-12 04:25:35 --> Model Class Initialized
DEBUG - 2018-01-12 04:25:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 04:25:36 --> Config Class Initialized
INFO - 2018-01-12 04:25:36 --> Hooks Class Initialized
DEBUG - 2018-01-12 04:25:36 --> UTF-8 Support Enabled
INFO - 2018-01-12 04:25:36 --> Utf8 Class Initialized
INFO - 2018-01-12 04:25:36 --> URI Class Initialized
INFO - 2018-01-12 04:25:36 --> Router Class Initialized
INFO - 2018-01-12 04:25:36 --> Output Class Initialized
INFO - 2018-01-12 04:25:36 --> Security Class Initialized
DEBUG - 2018-01-12 04:25:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 04:25:36 --> Input Class Initialized
INFO - 2018-01-12 04:25:36 --> Language Class Initialized
INFO - 2018-01-12 04:25:36 --> Loader Class Initialized
INFO - 2018-01-12 04:25:36 --> Helper loaded: url_helper
INFO - 2018-01-12 04:25:36 --> Helper loaded: form_helper
INFO - 2018-01-12 04:25:36 --> Database Driver Class Initialized
DEBUG - 2018-01-12 04:25:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 04:25:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 04:25:36 --> Form Validation Class Initialized
INFO - 2018-01-12 04:25:36 --> Model Class Initialized
INFO - 2018-01-12 04:25:36 --> Controller Class Initialized
INFO - 2018-01-12 04:25:36 --> Model Class Initialized
INFO - 2018-01-12 04:25:36 --> Model Class Initialized
INFO - 2018-01-12 04:25:36 --> Model Class Initialized
INFO - 2018-01-12 04:25:36 --> Model Class Initialized
DEBUG - 2018-01-12 04:25:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 04:25:44 --> Config Class Initialized
INFO - 2018-01-12 04:25:44 --> Hooks Class Initialized
DEBUG - 2018-01-12 04:25:44 --> UTF-8 Support Enabled
INFO - 2018-01-12 04:25:44 --> Utf8 Class Initialized
INFO - 2018-01-12 04:25:44 --> URI Class Initialized
INFO - 2018-01-12 04:25:44 --> Router Class Initialized
INFO - 2018-01-12 04:25:44 --> Output Class Initialized
INFO - 2018-01-12 04:25:44 --> Security Class Initialized
DEBUG - 2018-01-12 04:25:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 04:25:44 --> Input Class Initialized
INFO - 2018-01-12 04:25:44 --> Language Class Initialized
INFO - 2018-01-12 04:25:44 --> Loader Class Initialized
INFO - 2018-01-12 04:25:44 --> Helper loaded: url_helper
INFO - 2018-01-12 04:25:44 --> Helper loaded: form_helper
INFO - 2018-01-12 04:25:44 --> Database Driver Class Initialized
DEBUG - 2018-01-12 04:25:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 04:25:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 04:25:44 --> Form Validation Class Initialized
INFO - 2018-01-12 04:25:44 --> Model Class Initialized
INFO - 2018-01-12 04:25:44 --> Controller Class Initialized
INFO - 2018-01-12 04:25:44 --> Model Class Initialized
INFO - 2018-01-12 04:25:44 --> Model Class Initialized
INFO - 2018-01-12 04:25:44 --> Model Class Initialized
INFO - 2018-01-12 04:25:44 --> Model Class Initialized
DEBUG - 2018-01-12 04:25:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 04:25:44 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-12 04:25:44 --> Final output sent to browser
DEBUG - 2018-01-12 04:25:44 --> Total execution time: 0.0747
INFO - 2018-01-12 04:25:44 --> Config Class Initialized
INFO - 2018-01-12 04:25:44 --> Hooks Class Initialized
DEBUG - 2018-01-12 04:25:44 --> UTF-8 Support Enabled
INFO - 2018-01-12 04:25:44 --> Utf8 Class Initialized
INFO - 2018-01-12 04:25:44 --> URI Class Initialized
INFO - 2018-01-12 04:25:44 --> Router Class Initialized
INFO - 2018-01-12 04:25:44 --> Output Class Initialized
INFO - 2018-01-12 04:25:44 --> Security Class Initialized
DEBUG - 2018-01-12 04:25:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 04:25:44 --> Input Class Initialized
INFO - 2018-01-12 04:25:44 --> Language Class Initialized
INFO - 2018-01-12 04:25:44 --> Loader Class Initialized
INFO - 2018-01-12 04:25:44 --> Helper loaded: url_helper
INFO - 2018-01-12 04:25:44 --> Helper loaded: form_helper
INFO - 2018-01-12 04:25:44 --> Database Driver Class Initialized
DEBUG - 2018-01-12 04:25:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 04:25:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 04:25:44 --> Form Validation Class Initialized
INFO - 2018-01-12 04:25:44 --> Model Class Initialized
INFO - 2018-01-12 04:25:44 --> Controller Class Initialized
INFO - 2018-01-12 04:25:44 --> Model Class Initialized
INFO - 2018-01-12 04:25:44 --> Model Class Initialized
INFO - 2018-01-12 04:25:44 --> Model Class Initialized
INFO - 2018-01-12 04:25:44 --> Model Class Initialized
DEBUG - 2018-01-12 04:25:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 04:26:09 --> Config Class Initialized
INFO - 2018-01-12 04:26:09 --> Hooks Class Initialized
DEBUG - 2018-01-12 04:26:09 --> UTF-8 Support Enabled
INFO - 2018-01-12 04:26:09 --> Utf8 Class Initialized
INFO - 2018-01-12 04:26:09 --> URI Class Initialized
INFO - 2018-01-12 04:26:09 --> Router Class Initialized
INFO - 2018-01-12 04:26:09 --> Output Class Initialized
INFO - 2018-01-12 04:26:09 --> Security Class Initialized
DEBUG - 2018-01-12 04:26:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 04:26:09 --> Input Class Initialized
INFO - 2018-01-12 04:26:09 --> Language Class Initialized
INFO - 2018-01-12 04:26:09 --> Loader Class Initialized
INFO - 2018-01-12 04:26:09 --> Helper loaded: url_helper
INFO - 2018-01-12 04:26:09 --> Helper loaded: form_helper
INFO - 2018-01-12 04:26:09 --> Database Driver Class Initialized
DEBUG - 2018-01-12 04:26:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 04:26:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 04:26:09 --> Form Validation Class Initialized
INFO - 2018-01-12 04:26:09 --> Model Class Initialized
INFO - 2018-01-12 04:26:09 --> Controller Class Initialized
INFO - 2018-01-12 04:26:09 --> Model Class Initialized
INFO - 2018-01-12 04:26:09 --> Model Class Initialized
INFO - 2018-01-12 04:26:09 --> Model Class Initialized
INFO - 2018-01-12 04:26:09 --> Model Class Initialized
DEBUG - 2018-01-12 04:26:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 04:26:09 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-12 04:26:09 --> Final output sent to browser
DEBUG - 2018-01-12 04:26:09 --> Total execution time: 0.0909
INFO - 2018-01-12 04:26:09 --> Config Class Initialized
INFO - 2018-01-12 04:26:09 --> Hooks Class Initialized
DEBUG - 2018-01-12 04:26:09 --> UTF-8 Support Enabled
INFO - 2018-01-12 04:26:09 --> Utf8 Class Initialized
INFO - 2018-01-12 04:26:09 --> URI Class Initialized
INFO - 2018-01-12 04:26:09 --> Router Class Initialized
INFO - 2018-01-12 04:26:09 --> Output Class Initialized
INFO - 2018-01-12 04:26:09 --> Security Class Initialized
DEBUG - 2018-01-12 04:26:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 04:26:09 --> Input Class Initialized
INFO - 2018-01-12 04:26:09 --> Language Class Initialized
INFO - 2018-01-12 04:26:09 --> Loader Class Initialized
INFO - 2018-01-12 04:26:09 --> Helper loaded: url_helper
INFO - 2018-01-12 04:26:09 --> Helper loaded: form_helper
INFO - 2018-01-12 04:26:09 --> Database Driver Class Initialized
DEBUG - 2018-01-12 04:26:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 04:26:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 04:26:09 --> Form Validation Class Initialized
INFO - 2018-01-12 04:26:09 --> Model Class Initialized
INFO - 2018-01-12 04:26:09 --> Controller Class Initialized
INFO - 2018-01-12 04:26:09 --> Model Class Initialized
INFO - 2018-01-12 04:26:09 --> Model Class Initialized
INFO - 2018-01-12 04:26:09 --> Model Class Initialized
INFO - 2018-01-12 04:26:09 --> Model Class Initialized
DEBUG - 2018-01-12 04:26:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 04:31:13 --> Config Class Initialized
INFO - 2018-01-12 04:31:13 --> Hooks Class Initialized
DEBUG - 2018-01-12 04:31:13 --> UTF-8 Support Enabled
INFO - 2018-01-12 04:31:13 --> Utf8 Class Initialized
INFO - 2018-01-12 04:31:13 --> URI Class Initialized
INFO - 2018-01-12 04:31:13 --> Router Class Initialized
INFO - 2018-01-12 04:31:13 --> Output Class Initialized
INFO - 2018-01-12 04:31:13 --> Security Class Initialized
DEBUG - 2018-01-12 04:31:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 04:31:13 --> Input Class Initialized
INFO - 2018-01-12 04:31:13 --> Language Class Initialized
INFO - 2018-01-12 04:31:13 --> Loader Class Initialized
INFO - 2018-01-12 04:31:13 --> Helper loaded: url_helper
INFO - 2018-01-12 04:31:13 --> Helper loaded: form_helper
INFO - 2018-01-12 04:31:13 --> Database Driver Class Initialized
DEBUG - 2018-01-12 04:31:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 04:31:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 04:31:13 --> Form Validation Class Initialized
INFO - 2018-01-12 04:31:13 --> Model Class Initialized
INFO - 2018-01-12 04:31:13 --> Controller Class Initialized
INFO - 2018-01-12 04:31:13 --> Model Class Initialized
INFO - 2018-01-12 04:31:13 --> Model Class Initialized
INFO - 2018-01-12 04:31:13 --> Model Class Initialized
INFO - 2018-01-12 04:31:13 --> Model Class Initialized
DEBUG - 2018-01-12 04:31:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 04:31:13 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-12 04:31:13 --> Final output sent to browser
DEBUG - 2018-01-12 04:31:13 --> Total execution time: 0.0812
INFO - 2018-01-12 04:31:13 --> Config Class Initialized
INFO - 2018-01-12 04:31:13 --> Hooks Class Initialized
DEBUG - 2018-01-12 04:31:13 --> UTF-8 Support Enabled
INFO - 2018-01-12 04:31:13 --> Utf8 Class Initialized
INFO - 2018-01-12 04:31:13 --> URI Class Initialized
INFO - 2018-01-12 04:31:13 --> Router Class Initialized
INFO - 2018-01-12 04:31:13 --> Output Class Initialized
INFO - 2018-01-12 04:31:13 --> Security Class Initialized
DEBUG - 2018-01-12 04:31:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 04:31:13 --> Input Class Initialized
INFO - 2018-01-12 04:31:13 --> Language Class Initialized
INFO - 2018-01-12 04:31:13 --> Loader Class Initialized
INFO - 2018-01-12 04:31:13 --> Helper loaded: url_helper
INFO - 2018-01-12 04:31:13 --> Helper loaded: form_helper
INFO - 2018-01-12 04:31:13 --> Database Driver Class Initialized
DEBUG - 2018-01-12 04:31:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 04:31:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 04:31:13 --> Form Validation Class Initialized
INFO - 2018-01-12 04:31:13 --> Model Class Initialized
INFO - 2018-01-12 04:31:13 --> Controller Class Initialized
INFO - 2018-01-12 04:31:13 --> Model Class Initialized
INFO - 2018-01-12 04:31:13 --> Model Class Initialized
INFO - 2018-01-12 04:31:13 --> Model Class Initialized
INFO - 2018-01-12 04:31:13 --> Model Class Initialized
DEBUG - 2018-01-12 04:31:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 04:32:53 --> Config Class Initialized
INFO - 2018-01-12 04:32:53 --> Hooks Class Initialized
DEBUG - 2018-01-12 04:32:53 --> UTF-8 Support Enabled
INFO - 2018-01-12 04:32:53 --> Utf8 Class Initialized
INFO - 2018-01-12 04:32:53 --> URI Class Initialized
INFO - 2018-01-12 04:32:53 --> Router Class Initialized
INFO - 2018-01-12 04:32:53 --> Output Class Initialized
INFO - 2018-01-12 04:32:53 --> Security Class Initialized
DEBUG - 2018-01-12 04:32:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 04:32:53 --> Input Class Initialized
INFO - 2018-01-12 04:32:53 --> Language Class Initialized
INFO - 2018-01-12 04:32:53 --> Loader Class Initialized
INFO - 2018-01-12 04:32:53 --> Helper loaded: url_helper
INFO - 2018-01-12 04:32:53 --> Helper loaded: form_helper
INFO - 2018-01-12 04:32:53 --> Database Driver Class Initialized
DEBUG - 2018-01-12 04:32:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 04:32:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 04:32:53 --> Form Validation Class Initialized
INFO - 2018-01-12 04:32:53 --> Model Class Initialized
INFO - 2018-01-12 04:32:53 --> Controller Class Initialized
INFO - 2018-01-12 04:32:53 --> Model Class Initialized
INFO - 2018-01-12 04:32:53 --> Model Class Initialized
INFO - 2018-01-12 04:32:53 --> Model Class Initialized
INFO - 2018-01-12 04:32:53 --> Model Class Initialized
DEBUG - 2018-01-12 04:32:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 04:32:53 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-12 04:32:53 --> Final output sent to browser
DEBUG - 2018-01-12 04:32:53 --> Total execution time: 0.1264
INFO - 2018-01-12 04:33:12 --> Config Class Initialized
INFO - 2018-01-12 04:33:12 --> Hooks Class Initialized
DEBUG - 2018-01-12 04:33:12 --> UTF-8 Support Enabled
INFO - 2018-01-12 04:33:12 --> Utf8 Class Initialized
INFO - 2018-01-12 04:33:12 --> URI Class Initialized
INFO - 2018-01-12 04:33:12 --> Router Class Initialized
INFO - 2018-01-12 04:33:12 --> Output Class Initialized
INFO - 2018-01-12 04:33:12 --> Security Class Initialized
DEBUG - 2018-01-12 04:33:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 04:33:12 --> Input Class Initialized
INFO - 2018-01-12 04:33:12 --> Language Class Initialized
INFO - 2018-01-12 04:33:12 --> Loader Class Initialized
INFO - 2018-01-12 04:33:12 --> Helper loaded: url_helper
INFO - 2018-01-12 04:33:12 --> Helper loaded: form_helper
INFO - 2018-01-12 04:33:12 --> Database Driver Class Initialized
DEBUG - 2018-01-12 04:33:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 04:33:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 04:33:12 --> Form Validation Class Initialized
INFO - 2018-01-12 04:33:12 --> Model Class Initialized
INFO - 2018-01-12 04:33:12 --> Controller Class Initialized
INFO - 2018-01-12 04:33:12 --> Model Class Initialized
INFO - 2018-01-12 04:33:12 --> Model Class Initialized
INFO - 2018-01-12 04:33:12 --> Model Class Initialized
INFO - 2018-01-12 04:33:12 --> Model Class Initialized
DEBUG - 2018-01-12 04:33:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 04:33:12 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-12 04:33:12 --> Final output sent to browser
DEBUG - 2018-01-12 04:33:12 --> Total execution time: 0.0967
INFO - 2018-01-12 04:33:12 --> Config Class Initialized
INFO - 2018-01-12 04:33:12 --> Hooks Class Initialized
DEBUG - 2018-01-12 04:33:12 --> UTF-8 Support Enabled
INFO - 2018-01-12 04:33:12 --> Utf8 Class Initialized
INFO - 2018-01-12 04:33:12 --> URI Class Initialized
INFO - 2018-01-12 04:33:12 --> Router Class Initialized
INFO - 2018-01-12 04:33:12 --> Output Class Initialized
INFO - 2018-01-12 04:33:12 --> Security Class Initialized
DEBUG - 2018-01-12 04:33:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 04:33:12 --> Input Class Initialized
INFO - 2018-01-12 04:33:12 --> Language Class Initialized
INFO - 2018-01-12 04:33:12 --> Loader Class Initialized
INFO - 2018-01-12 04:33:12 --> Helper loaded: url_helper
INFO - 2018-01-12 04:33:12 --> Helper loaded: form_helper
INFO - 2018-01-12 04:33:12 --> Database Driver Class Initialized
DEBUG - 2018-01-12 04:33:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 04:33:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 04:33:12 --> Form Validation Class Initialized
INFO - 2018-01-12 04:33:12 --> Model Class Initialized
INFO - 2018-01-12 04:33:12 --> Controller Class Initialized
INFO - 2018-01-12 04:33:12 --> Model Class Initialized
INFO - 2018-01-12 04:33:12 --> Model Class Initialized
INFO - 2018-01-12 04:33:12 --> Model Class Initialized
INFO - 2018-01-12 04:33:12 --> Model Class Initialized
DEBUG - 2018-01-12 04:33:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 04:36:32 --> Config Class Initialized
INFO - 2018-01-12 04:36:32 --> Hooks Class Initialized
DEBUG - 2018-01-12 04:36:32 --> UTF-8 Support Enabled
INFO - 2018-01-12 04:36:32 --> Utf8 Class Initialized
INFO - 2018-01-12 04:36:32 --> URI Class Initialized
INFO - 2018-01-12 04:36:32 --> Router Class Initialized
INFO - 2018-01-12 04:36:32 --> Output Class Initialized
INFO - 2018-01-12 04:36:32 --> Security Class Initialized
DEBUG - 2018-01-12 04:36:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 04:36:32 --> Input Class Initialized
INFO - 2018-01-12 04:36:32 --> Language Class Initialized
INFO - 2018-01-12 04:36:32 --> Loader Class Initialized
INFO - 2018-01-12 04:36:32 --> Helper loaded: url_helper
INFO - 2018-01-12 04:36:32 --> Helper loaded: form_helper
INFO - 2018-01-12 04:36:32 --> Database Driver Class Initialized
DEBUG - 2018-01-12 04:36:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 04:36:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 04:36:32 --> Form Validation Class Initialized
INFO - 2018-01-12 04:36:32 --> Model Class Initialized
INFO - 2018-01-12 04:36:32 --> Controller Class Initialized
INFO - 2018-01-12 04:36:32 --> Model Class Initialized
INFO - 2018-01-12 04:36:32 --> Model Class Initialized
INFO - 2018-01-12 04:36:32 --> Model Class Initialized
INFO - 2018-01-12 04:36:32 --> Model Class Initialized
DEBUG - 2018-01-12 04:36:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 04:36:32 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-12 04:36:32 --> Final output sent to browser
DEBUG - 2018-01-12 04:36:32 --> Total execution time: 0.0898
INFO - 2018-01-12 04:39:22 --> Config Class Initialized
INFO - 2018-01-12 04:39:22 --> Hooks Class Initialized
DEBUG - 2018-01-12 04:39:23 --> UTF-8 Support Enabled
INFO - 2018-01-12 04:39:23 --> Utf8 Class Initialized
INFO - 2018-01-12 04:39:23 --> URI Class Initialized
INFO - 2018-01-12 04:39:23 --> Router Class Initialized
INFO - 2018-01-12 04:39:23 --> Output Class Initialized
INFO - 2018-01-12 04:39:23 --> Security Class Initialized
DEBUG - 2018-01-12 04:39:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 04:39:23 --> Input Class Initialized
INFO - 2018-01-12 04:39:23 --> Language Class Initialized
INFO - 2018-01-12 04:39:23 --> Loader Class Initialized
INFO - 2018-01-12 04:39:23 --> Helper loaded: url_helper
INFO - 2018-01-12 04:39:23 --> Helper loaded: form_helper
INFO - 2018-01-12 04:39:23 --> Database Driver Class Initialized
DEBUG - 2018-01-12 04:39:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 04:39:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 04:39:23 --> Form Validation Class Initialized
INFO - 2018-01-12 04:39:23 --> Model Class Initialized
INFO - 2018-01-12 04:39:23 --> Controller Class Initialized
INFO - 2018-01-12 04:39:23 --> Model Class Initialized
INFO - 2018-01-12 04:39:23 --> Model Class Initialized
INFO - 2018-01-12 04:39:23 --> Model Class Initialized
INFO - 2018-01-12 04:39:23 --> Model Class Initialized
DEBUG - 2018-01-12 04:39:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 04:39:23 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-12 04:39:23 --> Final output sent to browser
DEBUG - 2018-01-12 04:39:23 --> Total execution time: 0.1018
INFO - 2018-01-12 04:39:23 --> Config Class Initialized
INFO - 2018-01-12 04:39:23 --> Hooks Class Initialized
DEBUG - 2018-01-12 04:39:23 --> UTF-8 Support Enabled
INFO - 2018-01-12 04:39:23 --> Utf8 Class Initialized
INFO - 2018-01-12 04:39:23 --> URI Class Initialized
INFO - 2018-01-12 04:39:23 --> Router Class Initialized
INFO - 2018-01-12 04:39:23 --> Output Class Initialized
INFO - 2018-01-12 04:39:23 --> Security Class Initialized
DEBUG - 2018-01-12 04:39:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 04:39:23 --> Input Class Initialized
INFO - 2018-01-12 04:39:23 --> Language Class Initialized
INFO - 2018-01-12 04:39:23 --> Loader Class Initialized
INFO - 2018-01-12 04:39:23 --> Helper loaded: url_helper
INFO - 2018-01-12 04:39:23 --> Helper loaded: form_helper
INFO - 2018-01-12 04:39:23 --> Database Driver Class Initialized
DEBUG - 2018-01-12 04:39:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 04:39:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 04:39:23 --> Form Validation Class Initialized
INFO - 2018-01-12 04:39:23 --> Model Class Initialized
INFO - 2018-01-12 04:39:23 --> Controller Class Initialized
INFO - 2018-01-12 04:39:23 --> Model Class Initialized
INFO - 2018-01-12 04:39:23 --> Model Class Initialized
INFO - 2018-01-12 04:39:23 --> Model Class Initialized
INFO - 2018-01-12 04:39:23 --> Model Class Initialized
DEBUG - 2018-01-12 04:39:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 04:40:37 --> Config Class Initialized
INFO - 2018-01-12 04:40:37 --> Hooks Class Initialized
DEBUG - 2018-01-12 04:40:37 --> UTF-8 Support Enabled
INFO - 2018-01-12 04:40:37 --> Utf8 Class Initialized
INFO - 2018-01-12 04:40:37 --> URI Class Initialized
INFO - 2018-01-12 04:40:37 --> Router Class Initialized
INFO - 2018-01-12 04:40:37 --> Output Class Initialized
INFO - 2018-01-12 04:40:37 --> Security Class Initialized
DEBUG - 2018-01-12 04:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 04:40:37 --> Input Class Initialized
INFO - 2018-01-12 04:40:37 --> Language Class Initialized
INFO - 2018-01-12 04:40:37 --> Loader Class Initialized
INFO - 2018-01-12 04:40:37 --> Helper loaded: url_helper
INFO - 2018-01-12 04:40:37 --> Helper loaded: form_helper
INFO - 2018-01-12 04:40:37 --> Database Driver Class Initialized
DEBUG - 2018-01-12 04:40:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 04:40:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 04:40:37 --> Form Validation Class Initialized
INFO - 2018-01-12 04:40:37 --> Model Class Initialized
INFO - 2018-01-12 04:40:37 --> Controller Class Initialized
INFO - 2018-01-12 04:40:37 --> Model Class Initialized
INFO - 2018-01-12 04:40:37 --> Model Class Initialized
INFO - 2018-01-12 04:40:37 --> Model Class Initialized
INFO - 2018-01-12 04:40:37 --> Model Class Initialized
DEBUG - 2018-01-12 04:40:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 04:40:37 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-12 04:40:37 --> Final output sent to browser
DEBUG - 2018-01-12 04:40:37 --> Total execution time: 0.1057
INFO - 2018-01-12 04:40:37 --> Config Class Initialized
INFO - 2018-01-12 04:40:37 --> Hooks Class Initialized
DEBUG - 2018-01-12 04:40:37 --> UTF-8 Support Enabled
INFO - 2018-01-12 04:40:37 --> Utf8 Class Initialized
INFO - 2018-01-12 04:40:37 --> URI Class Initialized
INFO - 2018-01-12 04:40:37 --> Router Class Initialized
INFO - 2018-01-12 04:40:37 --> Output Class Initialized
INFO - 2018-01-12 04:40:37 --> Security Class Initialized
DEBUG - 2018-01-12 04:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 04:40:37 --> Input Class Initialized
INFO - 2018-01-12 04:40:37 --> Language Class Initialized
INFO - 2018-01-12 04:40:37 --> Loader Class Initialized
INFO - 2018-01-12 04:40:37 --> Helper loaded: url_helper
INFO - 2018-01-12 04:40:37 --> Helper loaded: form_helper
INFO - 2018-01-12 04:40:37 --> Database Driver Class Initialized
DEBUG - 2018-01-12 04:40:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 04:40:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 04:40:37 --> Form Validation Class Initialized
INFO - 2018-01-12 04:40:37 --> Model Class Initialized
INFO - 2018-01-12 04:40:37 --> Controller Class Initialized
INFO - 2018-01-12 04:40:37 --> Model Class Initialized
INFO - 2018-01-12 04:40:37 --> Model Class Initialized
INFO - 2018-01-12 04:40:37 --> Model Class Initialized
INFO - 2018-01-12 04:40:37 --> Model Class Initialized
DEBUG - 2018-01-12 04:40:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 05:07:04 --> Config Class Initialized
INFO - 2018-01-12 05:07:04 --> Hooks Class Initialized
DEBUG - 2018-01-12 05:07:04 --> UTF-8 Support Enabled
INFO - 2018-01-12 05:07:04 --> Utf8 Class Initialized
INFO - 2018-01-12 05:07:04 --> URI Class Initialized
INFO - 2018-01-12 05:07:04 --> Router Class Initialized
INFO - 2018-01-12 05:07:04 --> Output Class Initialized
INFO - 2018-01-12 05:07:04 --> Security Class Initialized
DEBUG - 2018-01-12 05:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 05:07:04 --> Input Class Initialized
INFO - 2018-01-12 05:07:04 --> Language Class Initialized
INFO - 2018-01-12 05:07:04 --> Loader Class Initialized
INFO - 2018-01-12 05:07:04 --> Helper loaded: url_helper
INFO - 2018-01-12 05:07:04 --> Helper loaded: form_helper
INFO - 2018-01-12 05:07:04 --> Database Driver Class Initialized
DEBUG - 2018-01-12 05:07:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 05:07:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 05:07:04 --> Form Validation Class Initialized
INFO - 2018-01-12 05:07:04 --> Model Class Initialized
INFO - 2018-01-12 05:07:04 --> Controller Class Initialized
INFO - 2018-01-12 05:07:04 --> Model Class Initialized
DEBUG - 2018-01-12 05:07:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 05:07:04 --> Config Class Initialized
INFO - 2018-01-12 05:07:04 --> Hooks Class Initialized
DEBUG - 2018-01-12 05:07:04 --> UTF-8 Support Enabled
INFO - 2018-01-12 05:07:04 --> Utf8 Class Initialized
INFO - 2018-01-12 05:07:04 --> URI Class Initialized
INFO - 2018-01-12 05:07:04 --> Router Class Initialized
INFO - 2018-01-12 05:07:04 --> Output Class Initialized
INFO - 2018-01-12 05:07:04 --> Security Class Initialized
DEBUG - 2018-01-12 05:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 05:07:04 --> Input Class Initialized
INFO - 2018-01-12 05:07:04 --> Language Class Initialized
INFO - 2018-01-12 05:07:04 --> Loader Class Initialized
INFO - 2018-01-12 05:07:04 --> Helper loaded: url_helper
INFO - 2018-01-12 05:07:04 --> Helper loaded: form_helper
INFO - 2018-01-12 05:07:04 --> Database Driver Class Initialized
DEBUG - 2018-01-12 05:07:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 05:07:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 05:07:04 --> Form Validation Class Initialized
INFO - 2018-01-12 05:07:04 --> Model Class Initialized
INFO - 2018-01-12 05:07:04 --> Controller Class Initialized
INFO - 2018-01-12 05:07:04 --> Model Class Initialized
DEBUG - 2018-01-12 05:07:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 05:07:04 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-12 05:07:04 --> Final output sent to browser
DEBUG - 2018-01-12 05:07:04 --> Total execution time: 0.0435
INFO - 2018-01-12 05:07:07 --> Config Class Initialized
INFO - 2018-01-12 05:07:07 --> Hooks Class Initialized
DEBUG - 2018-01-12 05:07:07 --> UTF-8 Support Enabled
INFO - 2018-01-12 05:07:07 --> Utf8 Class Initialized
INFO - 2018-01-12 05:07:07 --> URI Class Initialized
INFO - 2018-01-12 05:07:07 --> Router Class Initialized
INFO - 2018-01-12 05:07:07 --> Output Class Initialized
INFO - 2018-01-12 05:07:07 --> Security Class Initialized
DEBUG - 2018-01-12 05:07:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 05:07:07 --> Input Class Initialized
INFO - 2018-01-12 05:07:07 --> Language Class Initialized
INFO - 2018-01-12 05:07:07 --> Loader Class Initialized
INFO - 2018-01-12 05:07:07 --> Helper loaded: url_helper
INFO - 2018-01-12 05:07:07 --> Helper loaded: form_helper
INFO - 2018-01-12 05:07:07 --> Database Driver Class Initialized
DEBUG - 2018-01-12 05:07:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 05:07:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 05:07:07 --> Form Validation Class Initialized
INFO - 2018-01-12 05:07:07 --> Model Class Initialized
INFO - 2018-01-12 05:07:07 --> Controller Class Initialized
INFO - 2018-01-12 05:07:07 --> Model Class Initialized
DEBUG - 2018-01-12 05:07:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-12 05:07:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-01-12 05:07:08 --> Config Class Initialized
INFO - 2018-01-12 05:07:08 --> Hooks Class Initialized
DEBUG - 2018-01-12 05:07:08 --> UTF-8 Support Enabled
INFO - 2018-01-12 05:07:08 --> Utf8 Class Initialized
INFO - 2018-01-12 05:07:08 --> URI Class Initialized
DEBUG - 2018-01-12 05:07:08 --> No URI present. Default controller set.
INFO - 2018-01-12 05:07:08 --> Router Class Initialized
INFO - 2018-01-12 05:07:08 --> Output Class Initialized
INFO - 2018-01-12 05:07:08 --> Security Class Initialized
DEBUG - 2018-01-12 05:07:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 05:07:08 --> Input Class Initialized
INFO - 2018-01-12 05:07:08 --> Language Class Initialized
INFO - 2018-01-12 05:07:08 --> Loader Class Initialized
INFO - 2018-01-12 05:07:08 --> Helper loaded: url_helper
INFO - 2018-01-12 05:07:08 --> Helper loaded: form_helper
INFO - 2018-01-12 05:07:08 --> Database Driver Class Initialized
DEBUG - 2018-01-12 05:07:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 05:07:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 05:07:08 --> Form Validation Class Initialized
INFO - 2018-01-12 05:07:08 --> Model Class Initialized
INFO - 2018-01-12 05:07:08 --> Controller Class Initialized
INFO - 2018-01-12 05:07:08 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-12 05:07:08 --> Final output sent to browser
DEBUG - 2018-01-12 05:07:08 --> Total execution time: 0.0776
INFO - 2018-01-12 05:07:08 --> Config Class Initialized
INFO - 2018-01-12 05:07:08 --> Hooks Class Initialized
DEBUG - 2018-01-12 05:07:08 --> UTF-8 Support Enabled
INFO - 2018-01-12 05:07:08 --> Utf8 Class Initialized
INFO - 2018-01-12 05:07:08 --> URI Class Initialized
INFO - 2018-01-12 05:07:08 --> Router Class Initialized
INFO - 2018-01-12 05:07:08 --> Output Class Initialized
INFO - 2018-01-12 05:07:08 --> Security Class Initialized
DEBUG - 2018-01-12 05:07:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-12 05:07:08 --> Input Class Initialized
INFO - 2018-01-12 05:07:08 --> Language Class Initialized
INFO - 2018-01-12 05:07:08 --> Loader Class Initialized
INFO - 2018-01-12 05:07:08 --> Helper loaded: url_helper
INFO - 2018-01-12 05:07:08 --> Helper loaded: form_helper
INFO - 2018-01-12 05:07:08 --> Database Driver Class Initialized
DEBUG - 2018-01-12 05:07:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-12 05:07:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-12 05:07:08 --> Form Validation Class Initialized
INFO - 2018-01-12 05:07:08 --> Model Class Initialized
INFO - 2018-01-12 05:07:08 --> Controller Class Initialized
INFO - 2018-01-12 05:07:08 --> Model Class Initialized
INFO - 2018-01-12 05:07:08 --> Model Class Initialized
INFO - 2018-01-12 05:07:08 --> Model Class Initialized
INFO - 2018-01-12 05:07:08 --> Model Class Initialized
DEBUG - 2018-01-12 05:07:08 --> Form_validation class already loaded. Second attempt ignored.
