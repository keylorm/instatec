<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-12-23 00:31:17 --> Config Class Initialized
INFO - 2017-12-23 00:31:17 --> Hooks Class Initialized
DEBUG - 2017-12-23 00:31:17 --> UTF-8 Support Enabled
INFO - 2017-12-23 00:31:17 --> Utf8 Class Initialized
INFO - 2017-12-23 00:31:17 --> URI Class Initialized
INFO - 2017-12-23 00:31:17 --> Router Class Initialized
INFO - 2017-12-23 00:31:17 --> Output Class Initialized
INFO - 2017-12-23 00:31:17 --> Security Class Initialized
DEBUG - 2017-12-23 00:31:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 00:31:17 --> Input Class Initialized
INFO - 2017-12-23 00:31:17 --> Language Class Initialized
INFO - 2017-12-23 00:31:17 --> Loader Class Initialized
INFO - 2017-12-23 00:31:17 --> Helper loaded: url_helper
INFO - 2017-12-23 00:31:17 --> Helper loaded: form_helper
INFO - 2017-12-23 00:31:17 --> Database Driver Class Initialized
DEBUG - 2017-12-23 00:31:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 00:31:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 00:31:17 --> Form Validation Class Initialized
INFO - 2017-12-23 00:31:17 --> Model Class Initialized
INFO - 2017-12-23 00:31:17 --> Controller Class Initialized
INFO - 2017-12-23 00:31:17 --> Model Class Initialized
INFO - 2017-12-23 00:31:17 --> Model Class Initialized
INFO - 2017-12-23 00:31:17 --> Model Class Initialized
DEBUG - 2017-12-23 00:31:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 00:31:17 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-23 00:31:17 --> Final output sent to browser
DEBUG - 2017-12-23 00:31:17 --> Total execution time: 0.0912
INFO - 2017-12-23 01:20:34 --> Config Class Initialized
INFO - 2017-12-23 01:20:34 --> Hooks Class Initialized
DEBUG - 2017-12-23 01:20:34 --> UTF-8 Support Enabled
INFO - 2017-12-23 01:20:34 --> Utf8 Class Initialized
INFO - 2017-12-23 01:20:34 --> URI Class Initialized
INFO - 2017-12-23 01:20:34 --> Router Class Initialized
INFO - 2017-12-23 01:20:34 --> Output Class Initialized
INFO - 2017-12-23 01:20:34 --> Security Class Initialized
DEBUG - 2017-12-23 01:20:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 01:20:34 --> Input Class Initialized
INFO - 2017-12-23 01:20:34 --> Language Class Initialized
INFO - 2017-12-23 01:20:34 --> Loader Class Initialized
INFO - 2017-12-23 01:20:34 --> Helper loaded: url_helper
INFO - 2017-12-23 01:20:34 --> Helper loaded: form_helper
INFO - 2017-12-23 01:20:34 --> Database Driver Class Initialized
DEBUG - 2017-12-23 01:20:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 01:20:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 01:20:34 --> Form Validation Class Initialized
INFO - 2017-12-23 01:20:34 --> Model Class Initialized
INFO - 2017-12-23 01:20:34 --> Controller Class Initialized
INFO - 2017-12-23 01:20:34 --> Model Class Initialized
INFO - 2017-12-23 01:20:34 --> Model Class Initialized
INFO - 2017-12-23 01:20:34 --> Model Class Initialized
DEBUG - 2017-12-23 01:20:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 01:20:34 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-23 01:20:34 --> Final output sent to browser
DEBUG - 2017-12-23 01:20:34 --> Total execution time: 0.1181
INFO - 2017-12-23 01:23:04 --> Config Class Initialized
INFO - 2017-12-23 01:23:04 --> Hooks Class Initialized
DEBUG - 2017-12-23 01:23:04 --> UTF-8 Support Enabled
INFO - 2017-12-23 01:23:04 --> Utf8 Class Initialized
INFO - 2017-12-23 01:23:04 --> URI Class Initialized
INFO - 2017-12-23 01:23:04 --> Router Class Initialized
INFO - 2017-12-23 01:23:04 --> Output Class Initialized
INFO - 2017-12-23 01:23:04 --> Security Class Initialized
DEBUG - 2017-12-23 01:23:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 01:23:04 --> Input Class Initialized
INFO - 2017-12-23 01:23:04 --> Language Class Initialized
ERROR - 2017-12-23 01:23:04 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-23 01:23:04 --> Config Class Initialized
INFO - 2017-12-23 01:23:04 --> Hooks Class Initialized
INFO - 2017-12-23 01:23:04 --> Config Class Initialized
INFO - 2017-12-23 01:23:04 --> Hooks Class Initialized
DEBUG - 2017-12-23 01:23:04 --> UTF-8 Support Enabled
DEBUG - 2017-12-23 01:23:04 --> UTF-8 Support Enabled
INFO - 2017-12-23 01:23:04 --> Utf8 Class Initialized
INFO - 2017-12-23 01:23:04 --> Utf8 Class Initialized
INFO - 2017-12-23 01:23:04 --> URI Class Initialized
INFO - 2017-12-23 01:23:04 --> URI Class Initialized
INFO - 2017-12-23 01:23:04 --> Router Class Initialized
INFO - 2017-12-23 01:23:04 --> Router Class Initialized
INFO - 2017-12-23 01:23:04 --> Output Class Initialized
INFO - 2017-12-23 01:23:04 --> Output Class Initialized
INFO - 2017-12-23 01:23:04 --> Security Class Initialized
DEBUG - 2017-12-23 01:23:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 01:23:04 --> Security Class Initialized
INFO - 2017-12-23 01:23:04 --> Input Class Initialized
INFO - 2017-12-23 01:23:04 --> Language Class Initialized
DEBUG - 2017-12-23 01:23:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 01:23:04 --> Input Class Initialized
ERROR - 2017-12-23 01:23:04 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-23 01:23:04 --> Language Class Initialized
ERROR - 2017-12-23 01:23:04 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-23 01:27:16 --> Config Class Initialized
INFO - 2017-12-23 01:27:16 --> Hooks Class Initialized
DEBUG - 2017-12-23 01:27:16 --> UTF-8 Support Enabled
INFO - 2017-12-23 01:27:16 --> Utf8 Class Initialized
INFO - 2017-12-23 01:27:16 --> URI Class Initialized
INFO - 2017-12-23 01:27:16 --> Router Class Initialized
INFO - 2017-12-23 01:27:16 --> Output Class Initialized
INFO - 2017-12-23 01:27:16 --> Security Class Initialized
DEBUG - 2017-12-23 01:27:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 01:27:16 --> Input Class Initialized
INFO - 2017-12-23 01:27:16 --> Language Class Initialized
INFO - 2017-12-23 01:27:16 --> Loader Class Initialized
INFO - 2017-12-23 01:27:16 --> Helper loaded: url_helper
INFO - 2017-12-23 01:27:16 --> Helper loaded: form_helper
INFO - 2017-12-23 01:27:16 --> Database Driver Class Initialized
DEBUG - 2017-12-23 01:27:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 01:27:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 01:27:16 --> Form Validation Class Initialized
INFO - 2017-12-23 01:27:16 --> Model Class Initialized
INFO - 2017-12-23 01:27:16 --> Controller Class Initialized
INFO - 2017-12-23 01:27:16 --> Model Class Initialized
INFO - 2017-12-23 01:27:16 --> Model Class Initialized
INFO - 2017-12-23 01:27:16 --> Model Class Initialized
DEBUG - 2017-12-23 01:27:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 01:27:16 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-23 01:27:16 --> Final output sent to browser
DEBUG - 2017-12-23 01:27:16 --> Total execution time: 0.0944
INFO - 2017-12-23 01:27:16 --> Config Class Initialized
INFO - 2017-12-23 01:27:16 --> Hooks Class Initialized
DEBUG - 2017-12-23 01:27:16 --> UTF-8 Support Enabled
INFO - 2017-12-23 01:27:16 --> Utf8 Class Initialized
INFO - 2017-12-23 01:27:16 --> URI Class Initialized
INFO - 2017-12-23 01:27:16 --> Router Class Initialized
INFO - 2017-12-23 01:27:16 --> Output Class Initialized
INFO - 2017-12-23 01:27:16 --> Security Class Initialized
DEBUG - 2017-12-23 01:27:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 01:27:16 --> Input Class Initialized
INFO - 2017-12-23 01:27:16 --> Language Class Initialized
ERROR - 2017-12-23 01:27:16 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-23 01:27:16 --> Config Class Initialized
INFO - 2017-12-23 01:27:16 --> Hooks Class Initialized
INFO - 2017-12-23 01:27:16 --> Config Class Initialized
INFO - 2017-12-23 01:27:16 --> Hooks Class Initialized
DEBUG - 2017-12-23 01:27:16 --> UTF-8 Support Enabled
INFO - 2017-12-23 01:27:16 --> Utf8 Class Initialized
DEBUG - 2017-12-23 01:27:16 --> UTF-8 Support Enabled
INFO - 2017-12-23 01:27:16 --> Utf8 Class Initialized
INFO - 2017-12-23 01:27:16 --> URI Class Initialized
INFO - 2017-12-23 01:27:16 --> URI Class Initialized
INFO - 2017-12-23 01:27:16 --> Router Class Initialized
INFO - 2017-12-23 01:27:16 --> Router Class Initialized
INFO - 2017-12-23 01:27:16 --> Output Class Initialized
INFO - 2017-12-23 01:27:16 --> Output Class Initialized
INFO - 2017-12-23 01:27:16 --> Security Class Initialized
INFO - 2017-12-23 01:27:16 --> Security Class Initialized
DEBUG - 2017-12-23 01:27:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-23 01:27:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 01:27:16 --> Input Class Initialized
INFO - 2017-12-23 01:27:16 --> Input Class Initialized
INFO - 2017-12-23 01:27:16 --> Language Class Initialized
INFO - 2017-12-23 01:27:16 --> Language Class Initialized
ERROR - 2017-12-23 01:27:16 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-23 01:27:16 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-23 01:27:43 --> Config Class Initialized
INFO - 2017-12-23 01:27:43 --> Hooks Class Initialized
DEBUG - 2017-12-23 01:27:43 --> UTF-8 Support Enabled
INFO - 2017-12-23 01:27:43 --> Utf8 Class Initialized
INFO - 2017-12-23 01:27:43 --> URI Class Initialized
INFO - 2017-12-23 01:27:43 --> Router Class Initialized
INFO - 2017-12-23 01:27:43 --> Output Class Initialized
INFO - 2017-12-23 01:27:43 --> Security Class Initialized
DEBUG - 2017-12-23 01:27:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 01:27:43 --> Input Class Initialized
INFO - 2017-12-23 01:27:43 --> Language Class Initialized
INFO - 2017-12-23 01:27:43 --> Loader Class Initialized
INFO - 2017-12-23 01:27:43 --> Helper loaded: url_helper
INFO - 2017-12-23 01:27:43 --> Helper loaded: form_helper
INFO - 2017-12-23 01:27:43 --> Database Driver Class Initialized
DEBUG - 2017-12-23 01:27:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 01:27:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 01:27:43 --> Form Validation Class Initialized
INFO - 2017-12-23 01:27:43 --> Model Class Initialized
INFO - 2017-12-23 01:27:43 --> Controller Class Initialized
INFO - 2017-12-23 01:27:43 --> Model Class Initialized
INFO - 2017-12-23 01:27:43 --> Model Class Initialized
INFO - 2017-12-23 01:27:43 --> Model Class Initialized
DEBUG - 2017-12-23 01:27:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 01:27:43 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-23 01:27:43 --> Final output sent to browser
DEBUG - 2017-12-23 01:27:43 --> Total execution time: 0.0703
INFO - 2017-12-23 01:27:52 --> Config Class Initialized
INFO - 2017-12-23 01:27:52 --> Hooks Class Initialized
DEBUG - 2017-12-23 01:27:52 --> UTF-8 Support Enabled
INFO - 2017-12-23 01:27:52 --> Utf8 Class Initialized
INFO - 2017-12-23 01:27:52 --> URI Class Initialized
INFO - 2017-12-23 01:27:52 --> Router Class Initialized
INFO - 2017-12-23 01:27:52 --> Output Class Initialized
INFO - 2017-12-23 01:27:52 --> Security Class Initialized
DEBUG - 2017-12-23 01:27:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 01:27:52 --> Input Class Initialized
INFO - 2017-12-23 01:27:52 --> Language Class Initialized
INFO - 2017-12-23 01:27:52 --> Loader Class Initialized
INFO - 2017-12-23 01:27:52 --> Helper loaded: url_helper
INFO - 2017-12-23 01:27:52 --> Helper loaded: form_helper
INFO - 2017-12-23 01:27:52 --> Database Driver Class Initialized
DEBUG - 2017-12-23 01:27:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 01:27:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 01:27:52 --> Form Validation Class Initialized
INFO - 2017-12-23 01:27:52 --> Model Class Initialized
INFO - 2017-12-23 01:27:52 --> Controller Class Initialized
INFO - 2017-12-23 01:27:52 --> Model Class Initialized
INFO - 2017-12-23 01:27:52 --> Model Class Initialized
INFO - 2017-12-23 01:27:52 --> Model Class Initialized
DEBUG - 2017-12-23 01:27:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 01:27:52 --> Config Class Initialized
INFO - 2017-12-23 01:27:52 --> Hooks Class Initialized
DEBUG - 2017-12-23 01:27:52 --> UTF-8 Support Enabled
INFO - 2017-12-23 01:27:52 --> Utf8 Class Initialized
INFO - 2017-12-23 01:27:52 --> URI Class Initialized
INFO - 2017-12-23 01:27:52 --> Router Class Initialized
INFO - 2017-12-23 01:27:52 --> Output Class Initialized
INFO - 2017-12-23 01:27:52 --> Security Class Initialized
DEBUG - 2017-12-23 01:27:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 01:27:52 --> Input Class Initialized
INFO - 2017-12-23 01:27:52 --> Language Class Initialized
INFO - 2017-12-23 01:27:52 --> Loader Class Initialized
INFO - 2017-12-23 01:27:52 --> Helper loaded: url_helper
INFO - 2017-12-23 01:27:52 --> Helper loaded: form_helper
INFO - 2017-12-23 01:27:52 --> Database Driver Class Initialized
DEBUG - 2017-12-23 01:27:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 01:27:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 01:27:52 --> Form Validation Class Initialized
INFO - 2017-12-23 01:27:52 --> Model Class Initialized
INFO - 2017-12-23 01:27:52 --> Controller Class Initialized
INFO - 2017-12-23 01:27:52 --> Model Class Initialized
INFO - 2017-12-23 01:27:52 --> Model Class Initialized
INFO - 2017-12-23 01:27:52 --> Model Class Initialized
DEBUG - 2017-12-23 01:27:52 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2017-12-23 01:27:52 --> Severity: Notice --> Undefined property: stdClass::$motivo_extension D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verExtensionesProyecto.php 41
INFO - 2017-12-23 01:27:52 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-23 01:27:52 --> Final output sent to browser
DEBUG - 2017-12-23 01:27:52 --> Total execution time: 0.1019
INFO - 2017-12-23 01:31:12 --> Config Class Initialized
INFO - 2017-12-23 01:31:12 --> Hooks Class Initialized
DEBUG - 2017-12-23 01:31:12 --> UTF-8 Support Enabled
INFO - 2017-12-23 01:31:12 --> Utf8 Class Initialized
INFO - 2017-12-23 01:31:12 --> URI Class Initialized
INFO - 2017-12-23 01:31:12 --> Router Class Initialized
INFO - 2017-12-23 01:31:12 --> Output Class Initialized
INFO - 2017-12-23 01:31:12 --> Security Class Initialized
DEBUG - 2017-12-23 01:31:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 01:31:12 --> Input Class Initialized
INFO - 2017-12-23 01:31:12 --> Language Class Initialized
INFO - 2017-12-23 01:31:12 --> Loader Class Initialized
INFO - 2017-12-23 01:31:12 --> Helper loaded: url_helper
INFO - 2017-12-23 01:31:12 --> Helper loaded: form_helper
INFO - 2017-12-23 01:31:12 --> Database Driver Class Initialized
DEBUG - 2017-12-23 01:31:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 01:31:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 01:31:12 --> Form Validation Class Initialized
INFO - 2017-12-23 01:31:12 --> Model Class Initialized
INFO - 2017-12-23 01:31:12 --> Controller Class Initialized
ERROR - 2017-12-23 01:31:12 --> Severity: Parsing Error --> syntax error, unexpected ')' D:\xampp\htdocs\instateccr\instatec_app\models\M_Proyecto.php 376
INFO - 2017-12-23 01:31:13 --> Config Class Initialized
INFO - 2017-12-23 01:31:13 --> Hooks Class Initialized
DEBUG - 2017-12-23 01:31:13 --> UTF-8 Support Enabled
INFO - 2017-12-23 01:31:13 --> Utf8 Class Initialized
INFO - 2017-12-23 01:31:13 --> URI Class Initialized
INFO - 2017-12-23 01:31:13 --> Router Class Initialized
INFO - 2017-12-23 01:31:13 --> Output Class Initialized
INFO - 2017-12-23 01:31:13 --> Security Class Initialized
DEBUG - 2017-12-23 01:31:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 01:31:13 --> Input Class Initialized
INFO - 2017-12-23 01:31:13 --> Language Class Initialized
INFO - 2017-12-23 01:31:13 --> Loader Class Initialized
INFO - 2017-12-23 01:31:13 --> Helper loaded: url_helper
INFO - 2017-12-23 01:31:13 --> Helper loaded: form_helper
INFO - 2017-12-23 01:31:13 --> Database Driver Class Initialized
DEBUG - 2017-12-23 01:31:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 01:31:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 01:31:13 --> Form Validation Class Initialized
INFO - 2017-12-23 01:31:13 --> Model Class Initialized
INFO - 2017-12-23 01:31:13 --> Controller Class Initialized
ERROR - 2017-12-23 01:31:13 --> Severity: Parsing Error --> syntax error, unexpected ')' D:\xampp\htdocs\instateccr\instatec_app\models\M_Proyecto.php 376
INFO - 2017-12-23 01:31:21 --> Config Class Initialized
INFO - 2017-12-23 01:31:21 --> Hooks Class Initialized
DEBUG - 2017-12-23 01:31:21 --> UTF-8 Support Enabled
INFO - 2017-12-23 01:31:21 --> Utf8 Class Initialized
INFO - 2017-12-23 01:31:21 --> URI Class Initialized
INFO - 2017-12-23 01:31:21 --> Router Class Initialized
INFO - 2017-12-23 01:31:21 --> Output Class Initialized
INFO - 2017-12-23 01:31:21 --> Security Class Initialized
DEBUG - 2017-12-23 01:31:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 01:31:21 --> Input Class Initialized
INFO - 2017-12-23 01:31:21 --> Language Class Initialized
INFO - 2017-12-23 01:31:21 --> Loader Class Initialized
INFO - 2017-12-23 01:31:21 --> Helper loaded: url_helper
INFO - 2017-12-23 01:31:21 --> Helper loaded: form_helper
INFO - 2017-12-23 01:31:21 --> Database Driver Class Initialized
DEBUG - 2017-12-23 01:31:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 01:31:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 01:31:21 --> Form Validation Class Initialized
INFO - 2017-12-23 01:31:21 --> Model Class Initialized
INFO - 2017-12-23 01:31:21 --> Controller Class Initialized
INFO - 2017-12-23 01:31:21 --> Model Class Initialized
INFO - 2017-12-23 01:31:21 --> Model Class Initialized
INFO - 2017-12-23 01:31:21 --> Model Class Initialized
DEBUG - 2017-12-23 01:31:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 01:31:21 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-23 01:31:21 --> Final output sent to browser
DEBUG - 2017-12-23 01:31:21 --> Total execution time: 0.0500
INFO - 2017-12-23 01:31:24 --> Config Class Initialized
INFO - 2017-12-23 01:31:24 --> Hooks Class Initialized
DEBUG - 2017-12-23 01:31:24 --> UTF-8 Support Enabled
INFO - 2017-12-23 01:31:24 --> Utf8 Class Initialized
INFO - 2017-12-23 01:31:24 --> URI Class Initialized
INFO - 2017-12-23 01:31:24 --> Router Class Initialized
INFO - 2017-12-23 01:31:24 --> Output Class Initialized
INFO - 2017-12-23 01:31:24 --> Security Class Initialized
DEBUG - 2017-12-23 01:31:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 01:31:24 --> Input Class Initialized
INFO - 2017-12-23 01:31:24 --> Language Class Initialized
INFO - 2017-12-23 01:31:24 --> Loader Class Initialized
INFO - 2017-12-23 01:31:24 --> Helper loaded: url_helper
INFO - 2017-12-23 01:31:24 --> Helper loaded: form_helper
INFO - 2017-12-23 01:31:24 --> Database Driver Class Initialized
DEBUG - 2017-12-23 01:31:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 01:31:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 01:31:24 --> Form Validation Class Initialized
INFO - 2017-12-23 01:31:24 --> Model Class Initialized
INFO - 2017-12-23 01:31:24 --> Controller Class Initialized
INFO - 2017-12-23 01:31:24 --> Model Class Initialized
INFO - 2017-12-23 01:31:24 --> Model Class Initialized
INFO - 2017-12-23 01:31:24 --> Model Class Initialized
DEBUG - 2017-12-23 01:31:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 01:31:24 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-23 01:31:24 --> Final output sent to browser
DEBUG - 2017-12-23 01:31:24 --> Total execution time: 0.0699
INFO - 2017-12-23 01:48:25 --> Config Class Initialized
INFO - 2017-12-23 01:48:25 --> Hooks Class Initialized
DEBUG - 2017-12-23 01:48:25 --> UTF-8 Support Enabled
INFO - 2017-12-23 01:48:25 --> Utf8 Class Initialized
INFO - 2017-12-23 01:48:25 --> URI Class Initialized
INFO - 2017-12-23 01:48:25 --> Router Class Initialized
INFO - 2017-12-23 01:48:25 --> Output Class Initialized
INFO - 2017-12-23 01:48:25 --> Security Class Initialized
DEBUG - 2017-12-23 01:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 01:48:25 --> Input Class Initialized
INFO - 2017-12-23 01:48:25 --> Language Class Initialized
ERROR - 2017-12-23 01:48:25 --> 404 Page Not Found: Proyecto/editarExtensionProyecto
INFO - 2017-12-23 01:48:55 --> Config Class Initialized
INFO - 2017-12-23 01:48:55 --> Hooks Class Initialized
DEBUG - 2017-12-23 01:48:55 --> UTF-8 Support Enabled
INFO - 2017-12-23 01:48:55 --> Utf8 Class Initialized
INFO - 2017-12-23 01:48:55 --> URI Class Initialized
INFO - 2017-12-23 01:48:55 --> Router Class Initialized
INFO - 2017-12-23 01:48:55 --> Output Class Initialized
INFO - 2017-12-23 01:48:55 --> Security Class Initialized
DEBUG - 2017-12-23 01:48:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 01:48:55 --> Input Class Initialized
INFO - 2017-12-23 01:48:55 --> Language Class Initialized
INFO - 2017-12-23 01:48:55 --> Loader Class Initialized
INFO - 2017-12-23 01:48:55 --> Helper loaded: url_helper
INFO - 2017-12-23 01:48:55 --> Helper loaded: form_helper
INFO - 2017-12-23 01:48:55 --> Database Driver Class Initialized
DEBUG - 2017-12-23 01:48:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 01:48:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 01:48:55 --> Form Validation Class Initialized
INFO - 2017-12-23 01:48:55 --> Model Class Initialized
INFO - 2017-12-23 01:48:55 --> Controller Class Initialized
INFO - 2017-12-23 01:48:55 --> Model Class Initialized
INFO - 2017-12-23 01:48:55 --> Model Class Initialized
INFO - 2017-12-23 01:48:55 --> Model Class Initialized
DEBUG - 2017-12-23 01:48:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 01:48:55 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-23 01:48:55 --> Final output sent to browser
DEBUG - 2017-12-23 01:48:55 --> Total execution time: 0.1099
INFO - 2017-12-23 01:48:56 --> Config Class Initialized
INFO - 2017-12-23 01:48:56 --> Hooks Class Initialized
DEBUG - 2017-12-23 01:48:56 --> UTF-8 Support Enabled
INFO - 2017-12-23 01:48:56 --> Utf8 Class Initialized
INFO - 2017-12-23 01:48:56 --> URI Class Initialized
INFO - 2017-12-23 01:48:56 --> Router Class Initialized
INFO - 2017-12-23 01:48:56 --> Output Class Initialized
INFO - 2017-12-23 01:48:56 --> Security Class Initialized
DEBUG - 2017-12-23 01:48:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 01:48:56 --> Input Class Initialized
INFO - 2017-12-23 01:48:56 --> Language Class Initialized
INFO - 2017-12-23 01:48:56 --> Loader Class Initialized
INFO - 2017-12-23 01:48:56 --> Helper loaded: url_helper
INFO - 2017-12-23 01:48:56 --> Helper loaded: form_helper
INFO - 2017-12-23 01:48:56 --> Database Driver Class Initialized
DEBUG - 2017-12-23 01:48:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 01:48:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 01:48:56 --> Form Validation Class Initialized
INFO - 2017-12-23 01:48:56 --> Model Class Initialized
INFO - 2017-12-23 01:48:56 --> Controller Class Initialized
INFO - 2017-12-23 01:48:56 --> Model Class Initialized
INFO - 2017-12-23 01:48:56 --> Model Class Initialized
INFO - 2017-12-23 01:48:56 --> Model Class Initialized
DEBUG - 2017-12-23 01:48:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 01:49:00 --> Config Class Initialized
INFO - 2017-12-23 01:49:00 --> Hooks Class Initialized
DEBUG - 2017-12-23 01:49:00 --> UTF-8 Support Enabled
INFO - 2017-12-23 01:49:00 --> Utf8 Class Initialized
INFO - 2017-12-23 01:49:00 --> URI Class Initialized
INFO - 2017-12-23 01:49:00 --> Router Class Initialized
INFO - 2017-12-23 01:49:00 --> Output Class Initialized
INFO - 2017-12-23 01:49:00 --> Security Class Initialized
DEBUG - 2017-12-23 01:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 01:49:00 --> Input Class Initialized
INFO - 2017-12-23 01:49:00 --> Language Class Initialized
INFO - 2017-12-23 01:49:00 --> Loader Class Initialized
INFO - 2017-12-23 01:49:00 --> Helper loaded: url_helper
INFO - 2017-12-23 01:49:00 --> Helper loaded: form_helper
INFO - 2017-12-23 01:49:00 --> Database Driver Class Initialized
DEBUG - 2017-12-23 01:49:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 01:49:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 01:49:00 --> Form Validation Class Initialized
INFO - 2017-12-23 01:49:00 --> Model Class Initialized
INFO - 2017-12-23 01:49:00 --> Controller Class Initialized
INFO - 2017-12-23 01:49:00 --> Model Class Initialized
INFO - 2017-12-23 01:49:00 --> Model Class Initialized
INFO - 2017-12-23 01:49:00 --> Model Class Initialized
DEBUG - 2017-12-23 01:49:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 01:49:00 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-23 01:49:00 --> Final output sent to browser
DEBUG - 2017-12-23 01:49:00 --> Total execution time: 0.0670
INFO - 2017-12-23 01:49:00 --> Config Class Initialized
INFO - 2017-12-23 01:49:00 --> Hooks Class Initialized
DEBUG - 2017-12-23 01:49:00 --> UTF-8 Support Enabled
INFO - 2017-12-23 01:49:00 --> Utf8 Class Initialized
INFO - 2017-12-23 01:49:00 --> URI Class Initialized
INFO - 2017-12-23 01:49:00 --> Router Class Initialized
INFO - 2017-12-23 01:49:00 --> Output Class Initialized
INFO - 2017-12-23 01:49:00 --> Security Class Initialized
DEBUG - 2017-12-23 01:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 01:49:00 --> Input Class Initialized
INFO - 2017-12-23 01:49:00 --> Language Class Initialized
INFO - 2017-12-23 01:49:00 --> Loader Class Initialized
INFO - 2017-12-23 01:49:00 --> Helper loaded: url_helper
INFO - 2017-12-23 01:49:00 --> Helper loaded: form_helper
INFO - 2017-12-23 01:49:00 --> Database Driver Class Initialized
DEBUG - 2017-12-23 01:49:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 01:49:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 01:49:00 --> Form Validation Class Initialized
INFO - 2017-12-23 01:49:00 --> Model Class Initialized
INFO - 2017-12-23 01:49:00 --> Controller Class Initialized
INFO - 2017-12-23 01:49:00 --> Model Class Initialized
INFO - 2017-12-23 01:49:00 --> Model Class Initialized
INFO - 2017-12-23 01:49:00 --> Model Class Initialized
DEBUG - 2017-12-23 01:49:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 01:49:03 --> Config Class Initialized
INFO - 2017-12-23 01:49:03 --> Hooks Class Initialized
DEBUG - 2017-12-23 01:49:03 --> UTF-8 Support Enabled
INFO - 2017-12-23 01:49:03 --> Utf8 Class Initialized
INFO - 2017-12-23 01:49:03 --> URI Class Initialized
INFO - 2017-12-23 01:49:03 --> Router Class Initialized
INFO - 2017-12-23 01:49:03 --> Output Class Initialized
INFO - 2017-12-23 01:49:03 --> Security Class Initialized
DEBUG - 2017-12-23 01:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 01:49:03 --> Input Class Initialized
INFO - 2017-12-23 01:49:03 --> Language Class Initialized
INFO - 2017-12-23 01:49:03 --> Loader Class Initialized
INFO - 2017-12-23 01:49:03 --> Helper loaded: url_helper
INFO - 2017-12-23 01:49:03 --> Helper loaded: form_helper
INFO - 2017-12-23 01:49:03 --> Database Driver Class Initialized
DEBUG - 2017-12-23 01:49:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 01:49:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 01:49:03 --> Form Validation Class Initialized
INFO - 2017-12-23 01:49:03 --> Model Class Initialized
INFO - 2017-12-23 01:49:03 --> Controller Class Initialized
INFO - 2017-12-23 01:49:03 --> Model Class Initialized
INFO - 2017-12-23 01:49:03 --> Model Class Initialized
INFO - 2017-12-23 01:49:03 --> Model Class Initialized
DEBUG - 2017-12-23 01:49:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 01:49:04 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-23 01:49:04 --> Final output sent to browser
DEBUG - 2017-12-23 01:49:04 --> Total execution time: 0.0752
INFO - 2017-12-23 01:49:04 --> Config Class Initialized
INFO - 2017-12-23 01:49:04 --> Hooks Class Initialized
DEBUG - 2017-12-23 01:49:04 --> UTF-8 Support Enabled
INFO - 2017-12-23 01:49:04 --> Utf8 Class Initialized
INFO - 2017-12-23 01:49:04 --> URI Class Initialized
INFO - 2017-12-23 01:49:04 --> Router Class Initialized
INFO - 2017-12-23 01:49:04 --> Output Class Initialized
INFO - 2017-12-23 01:49:04 --> Security Class Initialized
DEBUG - 2017-12-23 01:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 01:49:04 --> Input Class Initialized
INFO - 2017-12-23 01:49:04 --> Language Class Initialized
INFO - 2017-12-23 01:49:04 --> Loader Class Initialized
INFO - 2017-12-23 01:49:04 --> Helper loaded: url_helper
INFO - 2017-12-23 01:49:04 --> Helper loaded: form_helper
INFO - 2017-12-23 01:49:04 --> Database Driver Class Initialized
DEBUG - 2017-12-23 01:49:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 01:49:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 01:49:04 --> Form Validation Class Initialized
INFO - 2017-12-23 01:49:04 --> Model Class Initialized
INFO - 2017-12-23 01:49:04 --> Controller Class Initialized
INFO - 2017-12-23 01:49:04 --> Model Class Initialized
INFO - 2017-12-23 01:49:04 --> Model Class Initialized
INFO - 2017-12-23 01:49:04 --> Model Class Initialized
DEBUG - 2017-12-23 01:49:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 01:49:32 --> Config Class Initialized
INFO - 2017-12-23 01:49:32 --> Hooks Class Initialized
DEBUG - 2017-12-23 01:49:32 --> UTF-8 Support Enabled
INFO - 2017-12-23 01:49:32 --> Utf8 Class Initialized
INFO - 2017-12-23 01:49:32 --> URI Class Initialized
INFO - 2017-12-23 01:49:32 --> Router Class Initialized
INFO - 2017-12-23 01:49:32 --> Output Class Initialized
INFO - 2017-12-23 01:49:32 --> Security Class Initialized
DEBUG - 2017-12-23 01:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 01:49:32 --> Input Class Initialized
INFO - 2017-12-23 01:49:32 --> Language Class Initialized
INFO - 2017-12-23 01:49:32 --> Loader Class Initialized
INFO - 2017-12-23 01:49:32 --> Helper loaded: url_helper
INFO - 2017-12-23 01:49:32 --> Helper loaded: form_helper
INFO - 2017-12-23 01:49:32 --> Database Driver Class Initialized
DEBUG - 2017-12-23 01:49:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 01:49:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 01:49:32 --> Form Validation Class Initialized
INFO - 2017-12-23 01:49:32 --> Model Class Initialized
INFO - 2017-12-23 01:49:32 --> Controller Class Initialized
INFO - 2017-12-23 01:49:32 --> Model Class Initialized
INFO - 2017-12-23 01:49:32 --> Model Class Initialized
INFO - 2017-12-23 01:49:32 --> Model Class Initialized
DEBUG - 2017-12-23 01:49:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 01:49:32 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-23 01:49:32 --> Final output sent to browser
DEBUG - 2017-12-23 01:49:32 --> Total execution time: 0.0644
INFO - 2017-12-23 01:49:58 --> Config Class Initialized
INFO - 2017-12-23 01:49:58 --> Hooks Class Initialized
DEBUG - 2017-12-23 01:49:58 --> UTF-8 Support Enabled
INFO - 2017-12-23 01:49:58 --> Utf8 Class Initialized
INFO - 2017-12-23 01:49:58 --> URI Class Initialized
INFO - 2017-12-23 01:49:58 --> Router Class Initialized
INFO - 2017-12-23 01:49:58 --> Output Class Initialized
INFO - 2017-12-23 01:49:58 --> Security Class Initialized
DEBUG - 2017-12-23 01:49:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 01:49:58 --> Input Class Initialized
INFO - 2017-12-23 01:49:58 --> Language Class Initialized
INFO - 2017-12-23 01:49:58 --> Loader Class Initialized
INFO - 2017-12-23 01:49:58 --> Helper loaded: url_helper
INFO - 2017-12-23 01:49:58 --> Helper loaded: form_helper
INFO - 2017-12-23 01:49:58 --> Database Driver Class Initialized
DEBUG - 2017-12-23 01:49:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 01:49:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 01:49:58 --> Form Validation Class Initialized
INFO - 2017-12-23 01:49:58 --> Model Class Initialized
INFO - 2017-12-23 01:49:58 --> Controller Class Initialized
INFO - 2017-12-23 01:49:58 --> Model Class Initialized
INFO - 2017-12-23 01:49:58 --> Model Class Initialized
INFO - 2017-12-23 01:49:58 --> Model Class Initialized
DEBUG - 2017-12-23 01:49:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 01:49:58 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-23 01:49:58 --> Final output sent to browser
DEBUG - 2017-12-23 01:49:58 --> Total execution time: 0.0875
INFO - 2017-12-23 01:50:05 --> Config Class Initialized
INFO - 2017-12-23 01:50:05 --> Hooks Class Initialized
DEBUG - 2017-12-23 01:50:05 --> UTF-8 Support Enabled
INFO - 2017-12-23 01:50:05 --> Utf8 Class Initialized
INFO - 2017-12-23 01:50:05 --> URI Class Initialized
INFO - 2017-12-23 01:50:05 --> Router Class Initialized
INFO - 2017-12-23 01:50:05 --> Output Class Initialized
INFO - 2017-12-23 01:50:05 --> Security Class Initialized
DEBUG - 2017-12-23 01:50:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 01:50:05 --> Input Class Initialized
INFO - 2017-12-23 01:50:05 --> Language Class Initialized
ERROR - 2017-12-23 01:50:05 --> 404 Page Not Found: Proyecto/editarExtensionProyecto
INFO - 2017-12-23 01:50:06 --> Config Class Initialized
INFO - 2017-12-23 01:50:06 --> Hooks Class Initialized
DEBUG - 2017-12-23 01:50:06 --> UTF-8 Support Enabled
INFO - 2017-12-23 01:50:06 --> Utf8 Class Initialized
INFO - 2017-12-23 01:50:06 --> URI Class Initialized
INFO - 2017-12-23 01:50:06 --> Router Class Initialized
INFO - 2017-12-23 01:50:06 --> Output Class Initialized
INFO - 2017-12-23 01:50:06 --> Security Class Initialized
DEBUG - 2017-12-23 01:50:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 01:50:06 --> Input Class Initialized
INFO - 2017-12-23 01:50:06 --> Language Class Initialized
INFO - 2017-12-23 01:50:06 --> Loader Class Initialized
INFO - 2017-12-23 01:50:06 --> Helper loaded: url_helper
INFO - 2017-12-23 01:50:06 --> Helper loaded: form_helper
INFO - 2017-12-23 01:50:06 --> Database Driver Class Initialized
DEBUG - 2017-12-23 01:50:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 01:50:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 01:50:06 --> Form Validation Class Initialized
INFO - 2017-12-23 01:50:06 --> Model Class Initialized
INFO - 2017-12-23 01:50:06 --> Controller Class Initialized
INFO - 2017-12-23 01:50:06 --> Model Class Initialized
INFO - 2017-12-23 01:50:06 --> Model Class Initialized
INFO - 2017-12-23 01:50:06 --> Model Class Initialized
DEBUG - 2017-12-23 01:50:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 01:50:06 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-23 01:50:06 --> Final output sent to browser
DEBUG - 2017-12-23 01:50:06 --> Total execution time: 0.1285
INFO - 2017-12-23 01:50:10 --> Config Class Initialized
INFO - 2017-12-23 01:50:10 --> Hooks Class Initialized
DEBUG - 2017-12-23 01:50:10 --> UTF-8 Support Enabled
INFO - 2017-12-23 01:50:10 --> Utf8 Class Initialized
INFO - 2017-12-23 01:50:10 --> URI Class Initialized
INFO - 2017-12-23 01:50:10 --> Router Class Initialized
INFO - 2017-12-23 01:50:10 --> Output Class Initialized
INFO - 2017-12-23 01:50:10 --> Security Class Initialized
DEBUG - 2017-12-23 01:50:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 01:50:10 --> Input Class Initialized
INFO - 2017-12-23 01:50:10 --> Language Class Initialized
INFO - 2017-12-23 01:50:10 --> Loader Class Initialized
INFO - 2017-12-23 01:50:10 --> Helper loaded: url_helper
INFO - 2017-12-23 01:50:10 --> Helper loaded: form_helper
INFO - 2017-12-23 01:50:10 --> Database Driver Class Initialized
DEBUG - 2017-12-23 01:50:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 01:50:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 01:50:10 --> Form Validation Class Initialized
INFO - 2017-12-23 01:50:10 --> Model Class Initialized
INFO - 2017-12-23 01:50:10 --> Controller Class Initialized
INFO - 2017-12-23 01:50:10 --> Model Class Initialized
INFO - 2017-12-23 01:50:10 --> Model Class Initialized
INFO - 2017-12-23 01:50:10 --> Model Class Initialized
DEBUG - 2017-12-23 01:50:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 01:50:10 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-23 01:50:10 --> Final output sent to browser
DEBUG - 2017-12-23 01:50:10 --> Total execution time: 0.0502
INFO - 2017-12-23 01:50:22 --> Config Class Initialized
INFO - 2017-12-23 01:50:22 --> Hooks Class Initialized
DEBUG - 2017-12-23 01:50:22 --> UTF-8 Support Enabled
INFO - 2017-12-23 01:50:22 --> Utf8 Class Initialized
INFO - 2017-12-23 01:50:22 --> URI Class Initialized
INFO - 2017-12-23 01:50:22 --> Router Class Initialized
INFO - 2017-12-23 01:50:22 --> Output Class Initialized
INFO - 2017-12-23 01:50:22 --> Security Class Initialized
DEBUG - 2017-12-23 01:50:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 01:50:22 --> Input Class Initialized
INFO - 2017-12-23 01:50:22 --> Language Class Initialized
INFO - 2017-12-23 01:50:22 --> Loader Class Initialized
INFO - 2017-12-23 01:50:22 --> Helper loaded: url_helper
INFO - 2017-12-23 01:50:22 --> Helper loaded: form_helper
INFO - 2017-12-23 01:50:22 --> Database Driver Class Initialized
DEBUG - 2017-12-23 01:50:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 01:50:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 01:50:22 --> Form Validation Class Initialized
INFO - 2017-12-23 01:50:22 --> Model Class Initialized
INFO - 2017-12-23 01:50:22 --> Controller Class Initialized
INFO - 2017-12-23 01:50:22 --> Model Class Initialized
INFO - 2017-12-23 01:50:22 --> Model Class Initialized
INFO - 2017-12-23 01:50:22 --> Model Class Initialized
DEBUG - 2017-12-23 01:50:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 01:50:22 --> Config Class Initialized
INFO - 2017-12-23 01:50:22 --> Hooks Class Initialized
DEBUG - 2017-12-23 01:50:22 --> UTF-8 Support Enabled
INFO - 2017-12-23 01:50:22 --> Utf8 Class Initialized
INFO - 2017-12-23 01:50:22 --> URI Class Initialized
INFO - 2017-12-23 01:50:22 --> Router Class Initialized
INFO - 2017-12-23 01:50:22 --> Output Class Initialized
INFO - 2017-12-23 01:50:22 --> Security Class Initialized
DEBUG - 2017-12-23 01:50:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 01:50:22 --> Input Class Initialized
INFO - 2017-12-23 01:50:22 --> Language Class Initialized
INFO - 2017-12-23 01:50:22 --> Loader Class Initialized
INFO - 2017-12-23 01:50:22 --> Helper loaded: url_helper
INFO - 2017-12-23 01:50:22 --> Helper loaded: form_helper
INFO - 2017-12-23 01:50:22 --> Database Driver Class Initialized
DEBUG - 2017-12-23 01:50:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 01:50:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 01:50:22 --> Form Validation Class Initialized
INFO - 2017-12-23 01:50:22 --> Model Class Initialized
INFO - 2017-12-23 01:50:22 --> Controller Class Initialized
INFO - 2017-12-23 01:50:22 --> Model Class Initialized
INFO - 2017-12-23 01:50:22 --> Model Class Initialized
INFO - 2017-12-23 01:50:22 --> Model Class Initialized
DEBUG - 2017-12-23 01:50:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 01:50:22 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-23 01:50:22 --> Final output sent to browser
DEBUG - 2017-12-23 01:50:22 --> Total execution time: 0.1015
INFO - 2017-12-23 01:50:40 --> Config Class Initialized
INFO - 2017-12-23 01:50:40 --> Hooks Class Initialized
DEBUG - 2017-12-23 01:50:40 --> UTF-8 Support Enabled
INFO - 2017-12-23 01:50:40 --> Utf8 Class Initialized
INFO - 2017-12-23 01:50:40 --> URI Class Initialized
INFO - 2017-12-23 01:50:40 --> Router Class Initialized
INFO - 2017-12-23 01:50:40 --> Output Class Initialized
INFO - 2017-12-23 01:50:40 --> Security Class Initialized
DEBUG - 2017-12-23 01:50:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 01:50:40 --> Input Class Initialized
INFO - 2017-12-23 01:50:40 --> Language Class Initialized
INFO - 2017-12-23 01:50:40 --> Loader Class Initialized
INFO - 2017-12-23 01:50:40 --> Helper loaded: url_helper
INFO - 2017-12-23 01:50:40 --> Helper loaded: form_helper
INFO - 2017-12-23 01:50:40 --> Database Driver Class Initialized
DEBUG - 2017-12-23 01:50:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 01:50:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 01:50:40 --> Form Validation Class Initialized
INFO - 2017-12-23 01:50:40 --> Model Class Initialized
INFO - 2017-12-23 01:50:40 --> Controller Class Initialized
INFO - 2017-12-23 01:50:40 --> Model Class Initialized
INFO - 2017-12-23 01:50:40 --> Model Class Initialized
INFO - 2017-12-23 01:50:40 --> Model Class Initialized
DEBUG - 2017-12-23 01:50:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 01:50:40 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-23 01:50:40 --> Final output sent to browser
DEBUG - 2017-12-23 01:50:40 --> Total execution time: 0.0677
INFO - 2017-12-23 01:51:22 --> Config Class Initialized
INFO - 2017-12-23 01:51:22 --> Hooks Class Initialized
DEBUG - 2017-12-23 01:51:22 --> UTF-8 Support Enabled
INFO - 2017-12-23 01:51:22 --> Utf8 Class Initialized
INFO - 2017-12-23 01:51:22 --> URI Class Initialized
INFO - 2017-12-23 01:51:22 --> Router Class Initialized
INFO - 2017-12-23 01:51:22 --> Output Class Initialized
INFO - 2017-12-23 01:51:22 --> Security Class Initialized
DEBUG - 2017-12-23 01:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 01:51:22 --> Input Class Initialized
INFO - 2017-12-23 01:51:22 --> Language Class Initialized
INFO - 2017-12-23 01:51:22 --> Loader Class Initialized
INFO - 2017-12-23 01:51:22 --> Helper loaded: url_helper
INFO - 2017-12-23 01:51:22 --> Helper loaded: form_helper
INFO - 2017-12-23 01:51:22 --> Database Driver Class Initialized
DEBUG - 2017-12-23 01:51:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 01:51:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 01:51:22 --> Form Validation Class Initialized
INFO - 2017-12-23 01:51:22 --> Model Class Initialized
INFO - 2017-12-23 01:51:22 --> Controller Class Initialized
INFO - 2017-12-23 01:51:22 --> Model Class Initialized
INFO - 2017-12-23 01:51:22 --> Model Class Initialized
INFO - 2017-12-23 01:51:22 --> Model Class Initialized
DEBUG - 2017-12-23 01:51:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 01:51:22 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-23 01:51:22 --> Final output sent to browser
DEBUG - 2017-12-23 01:51:22 --> Total execution time: 0.1037
INFO - 2017-12-23 01:51:23 --> Config Class Initialized
INFO - 2017-12-23 01:51:23 --> Hooks Class Initialized
DEBUG - 2017-12-23 01:51:23 --> UTF-8 Support Enabled
INFO - 2017-12-23 01:51:23 --> Utf8 Class Initialized
INFO - 2017-12-23 01:51:23 --> URI Class Initialized
INFO - 2017-12-23 01:51:23 --> Router Class Initialized
INFO - 2017-12-23 01:51:23 --> Output Class Initialized
INFO - 2017-12-23 01:51:23 --> Security Class Initialized
DEBUG - 2017-12-23 01:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 01:51:23 --> Input Class Initialized
INFO - 2017-12-23 01:51:23 --> Language Class Initialized
INFO - 2017-12-23 01:51:23 --> Loader Class Initialized
INFO - 2017-12-23 01:51:23 --> Helper loaded: url_helper
INFO - 2017-12-23 01:51:23 --> Helper loaded: form_helper
INFO - 2017-12-23 01:51:23 --> Database Driver Class Initialized
DEBUG - 2017-12-23 01:51:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 01:51:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 01:51:23 --> Form Validation Class Initialized
INFO - 2017-12-23 01:51:23 --> Model Class Initialized
INFO - 2017-12-23 01:51:23 --> Controller Class Initialized
INFO - 2017-12-23 01:51:23 --> Model Class Initialized
INFO - 2017-12-23 01:51:23 --> Model Class Initialized
INFO - 2017-12-23 01:51:23 --> Model Class Initialized
DEBUG - 2017-12-23 01:51:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 01:51:23 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-23 01:51:23 --> Final output sent to browser
DEBUG - 2017-12-23 01:51:23 --> Total execution time: 0.0529
INFO - 2017-12-23 01:52:07 --> Config Class Initialized
INFO - 2017-12-23 01:52:07 --> Hooks Class Initialized
DEBUG - 2017-12-23 01:52:07 --> UTF-8 Support Enabled
INFO - 2017-12-23 01:52:07 --> Utf8 Class Initialized
INFO - 2017-12-23 01:52:07 --> URI Class Initialized
INFO - 2017-12-23 01:52:07 --> Router Class Initialized
INFO - 2017-12-23 01:52:07 --> Output Class Initialized
INFO - 2017-12-23 01:52:07 --> Security Class Initialized
DEBUG - 2017-12-23 01:52:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 01:52:07 --> Input Class Initialized
INFO - 2017-12-23 01:52:07 --> Language Class Initialized
INFO - 2017-12-23 01:52:07 --> Loader Class Initialized
INFO - 2017-12-23 01:52:07 --> Helper loaded: url_helper
INFO - 2017-12-23 01:52:07 --> Helper loaded: form_helper
INFO - 2017-12-23 01:52:07 --> Database Driver Class Initialized
DEBUG - 2017-12-23 01:52:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 01:52:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 01:52:07 --> Form Validation Class Initialized
INFO - 2017-12-23 01:52:07 --> Model Class Initialized
INFO - 2017-12-23 01:52:07 --> Controller Class Initialized
INFO - 2017-12-23 01:52:07 --> Model Class Initialized
INFO - 2017-12-23 01:52:07 --> Model Class Initialized
INFO - 2017-12-23 01:52:07 --> Model Class Initialized
DEBUG - 2017-12-23 01:52:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 01:52:07 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-23 01:52:07 --> Final output sent to browser
DEBUG - 2017-12-23 01:52:07 --> Total execution time: 0.0809
INFO - 2017-12-23 01:52:11 --> Config Class Initialized
INFO - 2017-12-23 01:52:11 --> Hooks Class Initialized
DEBUG - 2017-12-23 01:52:11 --> UTF-8 Support Enabled
INFO - 2017-12-23 01:52:11 --> Utf8 Class Initialized
INFO - 2017-12-23 01:52:11 --> URI Class Initialized
INFO - 2017-12-23 01:52:11 --> Router Class Initialized
INFO - 2017-12-23 01:52:11 --> Output Class Initialized
INFO - 2017-12-23 01:52:11 --> Security Class Initialized
DEBUG - 2017-12-23 01:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 01:52:11 --> Input Class Initialized
INFO - 2017-12-23 01:52:11 --> Language Class Initialized
INFO - 2017-12-23 01:52:11 --> Loader Class Initialized
INFO - 2017-12-23 01:52:11 --> Helper loaded: url_helper
INFO - 2017-12-23 01:52:11 --> Helper loaded: form_helper
INFO - 2017-12-23 01:52:11 --> Database Driver Class Initialized
DEBUG - 2017-12-23 01:52:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 01:52:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 01:52:11 --> Form Validation Class Initialized
INFO - 2017-12-23 01:52:11 --> Model Class Initialized
INFO - 2017-12-23 01:52:11 --> Controller Class Initialized
INFO - 2017-12-23 01:52:11 --> Model Class Initialized
INFO - 2017-12-23 01:52:11 --> Model Class Initialized
INFO - 2017-12-23 01:52:11 --> Model Class Initialized
DEBUG - 2017-12-23 01:52:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 01:52:11 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-23 01:52:11 --> Final output sent to browser
DEBUG - 2017-12-23 01:52:11 --> Total execution time: 0.0517
INFO - 2017-12-23 01:52:11 --> Config Class Initialized
INFO - 2017-12-23 01:52:11 --> Hooks Class Initialized
DEBUG - 2017-12-23 01:52:11 --> UTF-8 Support Enabled
INFO - 2017-12-23 01:52:11 --> Utf8 Class Initialized
INFO - 2017-12-23 01:52:11 --> URI Class Initialized
INFO - 2017-12-23 01:52:11 --> Router Class Initialized
INFO - 2017-12-23 01:52:11 --> Output Class Initialized
INFO - 2017-12-23 01:52:11 --> Security Class Initialized
DEBUG - 2017-12-23 01:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 01:52:11 --> Input Class Initialized
INFO - 2017-12-23 01:52:11 --> Language Class Initialized
INFO - 2017-12-23 01:52:11 --> Loader Class Initialized
INFO - 2017-12-23 01:52:11 --> Helper loaded: url_helper
INFO - 2017-12-23 01:52:11 --> Helper loaded: form_helper
INFO - 2017-12-23 01:52:11 --> Database Driver Class Initialized
DEBUG - 2017-12-23 01:52:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 01:52:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 01:52:11 --> Form Validation Class Initialized
INFO - 2017-12-23 01:52:11 --> Model Class Initialized
INFO - 2017-12-23 01:52:11 --> Controller Class Initialized
INFO - 2017-12-23 01:52:11 --> Model Class Initialized
INFO - 2017-12-23 01:52:11 --> Model Class Initialized
INFO - 2017-12-23 01:52:11 --> Model Class Initialized
DEBUG - 2017-12-23 01:52:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 01:52:12 --> Config Class Initialized
INFO - 2017-12-23 01:52:12 --> Hooks Class Initialized
DEBUG - 2017-12-23 01:52:12 --> UTF-8 Support Enabled
INFO - 2017-12-23 01:52:12 --> Utf8 Class Initialized
INFO - 2017-12-23 01:52:12 --> URI Class Initialized
INFO - 2017-12-23 01:52:12 --> Router Class Initialized
INFO - 2017-12-23 01:52:12 --> Output Class Initialized
INFO - 2017-12-23 01:52:12 --> Security Class Initialized
DEBUG - 2017-12-23 01:52:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 01:52:12 --> Input Class Initialized
INFO - 2017-12-23 01:52:12 --> Language Class Initialized
INFO - 2017-12-23 01:52:12 --> Loader Class Initialized
INFO - 2017-12-23 01:52:12 --> Helper loaded: url_helper
INFO - 2017-12-23 01:52:12 --> Helper loaded: form_helper
INFO - 2017-12-23 01:52:12 --> Database Driver Class Initialized
DEBUG - 2017-12-23 01:52:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 01:52:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 01:52:12 --> Form Validation Class Initialized
INFO - 2017-12-23 01:52:12 --> Model Class Initialized
INFO - 2017-12-23 01:52:12 --> Controller Class Initialized
INFO - 2017-12-23 01:52:12 --> Model Class Initialized
INFO - 2017-12-23 01:52:12 --> Model Class Initialized
INFO - 2017-12-23 01:52:12 --> Model Class Initialized
DEBUG - 2017-12-23 01:52:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 01:52:12 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-23 01:52:12 --> Final output sent to browser
DEBUG - 2017-12-23 01:52:12 --> Total execution time: 0.0600
INFO - 2017-12-23 01:52:13 --> Config Class Initialized
INFO - 2017-12-23 01:52:13 --> Hooks Class Initialized
DEBUG - 2017-12-23 01:52:13 --> UTF-8 Support Enabled
INFO - 2017-12-23 01:52:13 --> Utf8 Class Initialized
INFO - 2017-12-23 01:52:13 --> URI Class Initialized
INFO - 2017-12-23 01:52:13 --> Router Class Initialized
INFO - 2017-12-23 01:52:13 --> Output Class Initialized
INFO - 2017-12-23 01:52:13 --> Security Class Initialized
DEBUG - 2017-12-23 01:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 01:52:13 --> Input Class Initialized
INFO - 2017-12-23 01:52:13 --> Language Class Initialized
INFO - 2017-12-23 01:52:13 --> Loader Class Initialized
INFO - 2017-12-23 01:52:13 --> Helper loaded: url_helper
INFO - 2017-12-23 01:52:13 --> Helper loaded: form_helper
INFO - 2017-12-23 01:52:13 --> Database Driver Class Initialized
DEBUG - 2017-12-23 01:52:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 01:52:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 01:52:13 --> Form Validation Class Initialized
INFO - 2017-12-23 01:52:13 --> Model Class Initialized
INFO - 2017-12-23 01:52:13 --> Controller Class Initialized
INFO - 2017-12-23 01:52:13 --> Model Class Initialized
INFO - 2017-12-23 01:52:13 --> Model Class Initialized
INFO - 2017-12-23 01:52:13 --> Model Class Initialized
DEBUG - 2017-12-23 01:52:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 01:52:13 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-23 01:52:13 --> Final output sent to browser
DEBUG - 2017-12-23 01:52:13 --> Total execution time: 0.0661
INFO - 2017-12-23 01:52:14 --> Config Class Initialized
INFO - 2017-12-23 01:52:14 --> Hooks Class Initialized
DEBUG - 2017-12-23 01:52:14 --> UTF-8 Support Enabled
INFO - 2017-12-23 01:52:14 --> Utf8 Class Initialized
INFO - 2017-12-23 01:52:14 --> URI Class Initialized
INFO - 2017-12-23 01:52:14 --> Router Class Initialized
INFO - 2017-12-23 01:52:14 --> Output Class Initialized
INFO - 2017-12-23 01:52:14 --> Security Class Initialized
DEBUG - 2017-12-23 01:52:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 01:52:14 --> Input Class Initialized
INFO - 2017-12-23 01:52:14 --> Language Class Initialized
INFO - 2017-12-23 01:52:14 --> Loader Class Initialized
INFO - 2017-12-23 01:52:14 --> Helper loaded: url_helper
INFO - 2017-12-23 01:52:14 --> Helper loaded: form_helper
INFO - 2017-12-23 01:52:14 --> Database Driver Class Initialized
DEBUG - 2017-12-23 01:52:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 01:52:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 01:52:14 --> Form Validation Class Initialized
INFO - 2017-12-23 01:52:14 --> Model Class Initialized
INFO - 2017-12-23 01:52:14 --> Controller Class Initialized
INFO - 2017-12-23 01:52:14 --> Model Class Initialized
INFO - 2017-12-23 01:52:14 --> Model Class Initialized
INFO - 2017-12-23 01:52:14 --> Model Class Initialized
DEBUG - 2017-12-23 01:52:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 01:52:14 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-23 01:52:14 --> Final output sent to browser
DEBUG - 2017-12-23 01:52:14 --> Total execution time: 0.0659
INFO - 2017-12-23 01:52:15 --> Config Class Initialized
INFO - 2017-12-23 01:52:15 --> Hooks Class Initialized
DEBUG - 2017-12-23 01:52:15 --> UTF-8 Support Enabled
INFO - 2017-12-23 01:52:15 --> Utf8 Class Initialized
INFO - 2017-12-23 01:52:15 --> URI Class Initialized
INFO - 2017-12-23 01:52:15 --> Router Class Initialized
INFO - 2017-12-23 01:52:15 --> Output Class Initialized
INFO - 2017-12-23 01:52:15 --> Security Class Initialized
DEBUG - 2017-12-23 01:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 01:52:15 --> Input Class Initialized
INFO - 2017-12-23 01:52:15 --> Language Class Initialized
INFO - 2017-12-23 01:52:15 --> Loader Class Initialized
INFO - 2017-12-23 01:52:15 --> Helper loaded: url_helper
INFO - 2017-12-23 01:52:15 --> Helper loaded: form_helper
INFO - 2017-12-23 01:52:15 --> Database Driver Class Initialized
DEBUG - 2017-12-23 01:52:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 01:52:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 01:52:15 --> Form Validation Class Initialized
INFO - 2017-12-23 01:52:15 --> Model Class Initialized
INFO - 2017-12-23 01:52:15 --> Controller Class Initialized
INFO - 2017-12-23 01:52:15 --> Model Class Initialized
INFO - 2017-12-23 01:52:15 --> Model Class Initialized
INFO - 2017-12-23 01:52:15 --> Model Class Initialized
DEBUG - 2017-12-23 01:52:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 01:52:15 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-23 01:52:15 --> Final output sent to browser
DEBUG - 2017-12-23 01:52:15 --> Total execution time: 0.0607
INFO - 2017-12-23 01:52:15 --> Config Class Initialized
INFO - 2017-12-23 01:52:15 --> Hooks Class Initialized
DEBUG - 2017-12-23 01:52:15 --> UTF-8 Support Enabled
INFO - 2017-12-23 01:52:15 --> Utf8 Class Initialized
INFO - 2017-12-23 01:52:15 --> URI Class Initialized
INFO - 2017-12-23 01:52:15 --> Router Class Initialized
INFO - 2017-12-23 01:52:15 --> Output Class Initialized
INFO - 2017-12-23 01:52:15 --> Security Class Initialized
DEBUG - 2017-12-23 01:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 01:52:15 --> Input Class Initialized
INFO - 2017-12-23 01:52:15 --> Language Class Initialized
INFO - 2017-12-23 01:52:15 --> Loader Class Initialized
INFO - 2017-12-23 01:52:15 --> Helper loaded: url_helper
INFO - 2017-12-23 01:52:15 --> Helper loaded: form_helper
INFO - 2017-12-23 01:52:15 --> Database Driver Class Initialized
DEBUG - 2017-12-23 01:52:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 01:52:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 01:52:15 --> Form Validation Class Initialized
INFO - 2017-12-23 01:52:15 --> Model Class Initialized
INFO - 2017-12-23 01:52:15 --> Controller Class Initialized
INFO - 2017-12-23 01:52:15 --> Model Class Initialized
INFO - 2017-12-23 01:52:15 --> Model Class Initialized
INFO - 2017-12-23 01:52:15 --> Model Class Initialized
DEBUG - 2017-12-23 01:52:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 01:52:39 --> Config Class Initialized
INFO - 2017-12-23 01:52:39 --> Hooks Class Initialized
DEBUG - 2017-12-23 01:52:39 --> UTF-8 Support Enabled
INFO - 2017-12-23 01:52:39 --> Utf8 Class Initialized
INFO - 2017-12-23 01:52:39 --> URI Class Initialized
INFO - 2017-12-23 01:52:39 --> Router Class Initialized
INFO - 2017-12-23 01:52:39 --> Output Class Initialized
INFO - 2017-12-23 01:52:39 --> Security Class Initialized
DEBUG - 2017-12-23 01:52:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 01:52:39 --> Input Class Initialized
INFO - 2017-12-23 01:52:39 --> Language Class Initialized
INFO - 2017-12-23 01:52:39 --> Loader Class Initialized
INFO - 2017-12-23 01:52:39 --> Helper loaded: url_helper
INFO - 2017-12-23 01:52:39 --> Helper loaded: form_helper
INFO - 2017-12-23 01:52:39 --> Database Driver Class Initialized
DEBUG - 2017-12-23 01:52:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 01:52:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 01:52:39 --> Form Validation Class Initialized
INFO - 2017-12-23 01:52:39 --> Model Class Initialized
INFO - 2017-12-23 01:52:39 --> Controller Class Initialized
INFO - 2017-12-23 01:52:39 --> Model Class Initialized
INFO - 2017-12-23 01:52:39 --> Model Class Initialized
INFO - 2017-12-23 01:52:39 --> Model Class Initialized
DEBUG - 2017-12-23 01:52:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 01:52:39 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-23 01:52:39 --> Final output sent to browser
DEBUG - 2017-12-23 01:52:39 --> Total execution time: 0.0719
INFO - 2017-12-23 01:52:40 --> Config Class Initialized
INFO - 2017-12-23 01:52:40 --> Hooks Class Initialized
DEBUG - 2017-12-23 01:52:40 --> UTF-8 Support Enabled
INFO - 2017-12-23 01:52:40 --> Utf8 Class Initialized
INFO - 2017-12-23 01:52:40 --> URI Class Initialized
INFO - 2017-12-23 01:52:40 --> Router Class Initialized
INFO - 2017-12-23 01:52:40 --> Output Class Initialized
INFO - 2017-12-23 01:52:40 --> Security Class Initialized
DEBUG - 2017-12-23 01:52:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 01:52:40 --> Input Class Initialized
INFO - 2017-12-23 01:52:40 --> Language Class Initialized
INFO - 2017-12-23 01:52:40 --> Loader Class Initialized
INFO - 2017-12-23 01:52:40 --> Helper loaded: url_helper
INFO - 2017-12-23 01:52:40 --> Helper loaded: form_helper
INFO - 2017-12-23 01:52:40 --> Database Driver Class Initialized
DEBUG - 2017-12-23 01:52:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 01:52:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 01:52:40 --> Form Validation Class Initialized
INFO - 2017-12-23 01:52:40 --> Model Class Initialized
INFO - 2017-12-23 01:52:40 --> Controller Class Initialized
INFO - 2017-12-23 01:52:40 --> Model Class Initialized
INFO - 2017-12-23 01:52:40 --> Model Class Initialized
INFO - 2017-12-23 01:52:40 --> Model Class Initialized
DEBUG - 2017-12-23 01:52:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 01:52:40 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-23 01:52:40 --> Final output sent to browser
DEBUG - 2017-12-23 01:52:40 --> Total execution time: 0.0808
INFO - 2017-12-23 01:52:40 --> Config Class Initialized
INFO - 2017-12-23 01:52:40 --> Hooks Class Initialized
DEBUG - 2017-12-23 01:52:40 --> UTF-8 Support Enabled
INFO - 2017-12-23 01:52:40 --> Utf8 Class Initialized
INFO - 2017-12-23 01:52:40 --> URI Class Initialized
INFO - 2017-12-23 01:52:40 --> Router Class Initialized
INFO - 2017-12-23 01:52:40 --> Output Class Initialized
INFO - 2017-12-23 01:52:40 --> Security Class Initialized
DEBUG - 2017-12-23 01:52:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 01:52:40 --> Input Class Initialized
INFO - 2017-12-23 01:52:40 --> Language Class Initialized
INFO - 2017-12-23 01:52:40 --> Loader Class Initialized
INFO - 2017-12-23 01:52:40 --> Helper loaded: url_helper
INFO - 2017-12-23 01:52:40 --> Helper loaded: form_helper
INFO - 2017-12-23 01:52:40 --> Database Driver Class Initialized
DEBUG - 2017-12-23 01:52:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 01:52:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 01:52:40 --> Form Validation Class Initialized
INFO - 2017-12-23 01:52:40 --> Model Class Initialized
INFO - 2017-12-23 01:52:40 --> Controller Class Initialized
INFO - 2017-12-23 01:52:40 --> Model Class Initialized
INFO - 2017-12-23 01:52:40 --> Model Class Initialized
INFO - 2017-12-23 01:52:40 --> Model Class Initialized
DEBUG - 2017-12-23 01:52:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 01:53:01 --> Config Class Initialized
INFO - 2017-12-23 01:53:01 --> Hooks Class Initialized
DEBUG - 2017-12-23 01:53:01 --> UTF-8 Support Enabled
INFO - 2017-12-23 01:53:01 --> Utf8 Class Initialized
INFO - 2017-12-23 01:53:01 --> URI Class Initialized
INFO - 2017-12-23 01:53:01 --> Router Class Initialized
INFO - 2017-12-23 01:53:01 --> Output Class Initialized
INFO - 2017-12-23 01:53:01 --> Security Class Initialized
DEBUG - 2017-12-23 01:53:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 01:53:01 --> Input Class Initialized
INFO - 2017-12-23 01:53:01 --> Language Class Initialized
INFO - 2017-12-23 01:53:01 --> Loader Class Initialized
INFO - 2017-12-23 01:53:01 --> Helper loaded: url_helper
INFO - 2017-12-23 01:53:01 --> Helper loaded: form_helper
INFO - 2017-12-23 01:53:01 --> Database Driver Class Initialized
DEBUG - 2017-12-23 01:53:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 01:53:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 01:53:01 --> Form Validation Class Initialized
INFO - 2017-12-23 01:53:01 --> Model Class Initialized
INFO - 2017-12-23 01:53:01 --> Controller Class Initialized
INFO - 2017-12-23 01:53:01 --> Model Class Initialized
INFO - 2017-12-23 01:53:01 --> Model Class Initialized
INFO - 2017-12-23 01:53:01 --> Model Class Initialized
DEBUG - 2017-12-23 01:53:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 01:53:01 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-23 01:53:01 --> Final output sent to browser
DEBUG - 2017-12-23 01:53:01 --> Total execution time: 0.1003
INFO - 2017-12-23 01:53:01 --> Config Class Initialized
INFO - 2017-12-23 01:53:01 --> Hooks Class Initialized
DEBUG - 2017-12-23 01:53:01 --> UTF-8 Support Enabled
INFO - 2017-12-23 01:53:01 --> Utf8 Class Initialized
INFO - 2017-12-23 01:53:01 --> URI Class Initialized
INFO - 2017-12-23 01:53:01 --> Router Class Initialized
INFO - 2017-12-23 01:53:01 --> Output Class Initialized
INFO - 2017-12-23 01:53:01 --> Security Class Initialized
DEBUG - 2017-12-23 01:53:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 01:53:01 --> Input Class Initialized
INFO - 2017-12-23 01:53:01 --> Language Class Initialized
INFO - 2017-12-23 01:53:01 --> Loader Class Initialized
INFO - 2017-12-23 01:53:01 --> Helper loaded: url_helper
INFO - 2017-12-23 01:53:01 --> Helper loaded: form_helper
INFO - 2017-12-23 01:53:01 --> Database Driver Class Initialized
DEBUG - 2017-12-23 01:53:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 01:53:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 01:53:01 --> Form Validation Class Initialized
INFO - 2017-12-23 01:53:01 --> Model Class Initialized
INFO - 2017-12-23 01:53:01 --> Controller Class Initialized
INFO - 2017-12-23 01:53:01 --> Model Class Initialized
INFO - 2017-12-23 01:53:01 --> Model Class Initialized
INFO - 2017-12-23 01:53:01 --> Model Class Initialized
DEBUG - 2017-12-23 01:53:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 01:53:26 --> Config Class Initialized
INFO - 2017-12-23 01:53:26 --> Hooks Class Initialized
DEBUG - 2017-12-23 01:53:26 --> UTF-8 Support Enabled
INFO - 2017-12-23 01:53:26 --> Utf8 Class Initialized
INFO - 2017-12-23 01:53:26 --> URI Class Initialized
INFO - 2017-12-23 01:53:26 --> Router Class Initialized
INFO - 2017-12-23 01:53:26 --> Output Class Initialized
INFO - 2017-12-23 01:53:26 --> Security Class Initialized
DEBUG - 2017-12-23 01:53:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 01:53:26 --> Input Class Initialized
INFO - 2017-12-23 01:53:26 --> Language Class Initialized
INFO - 2017-12-23 01:53:26 --> Loader Class Initialized
INFO - 2017-12-23 01:53:26 --> Helper loaded: url_helper
INFO - 2017-12-23 01:53:26 --> Helper loaded: form_helper
INFO - 2017-12-23 01:53:26 --> Database Driver Class Initialized
DEBUG - 2017-12-23 01:53:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 01:53:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 01:53:26 --> Form Validation Class Initialized
INFO - 2017-12-23 01:53:26 --> Model Class Initialized
INFO - 2017-12-23 01:53:26 --> Controller Class Initialized
INFO - 2017-12-23 01:53:26 --> Model Class Initialized
INFO - 2017-12-23 01:53:26 --> Model Class Initialized
INFO - 2017-12-23 01:53:26 --> Model Class Initialized
DEBUG - 2017-12-23 01:53:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 01:53:26 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-23 01:53:26 --> Final output sent to browser
DEBUG - 2017-12-23 01:53:26 --> Total execution time: 0.0641
INFO - 2017-12-23 01:53:26 --> Config Class Initialized
INFO - 2017-12-23 01:53:26 --> Hooks Class Initialized
INFO - 2017-12-23 01:53:26 --> Config Class Initialized
INFO - 2017-12-23 01:53:26 --> Hooks Class Initialized
DEBUG - 2017-12-23 01:53:26 --> UTF-8 Support Enabled
INFO - 2017-12-23 01:53:26 --> Utf8 Class Initialized
DEBUG - 2017-12-23 01:53:26 --> UTF-8 Support Enabled
INFO - 2017-12-23 01:53:26 --> Utf8 Class Initialized
INFO - 2017-12-23 01:53:26 --> URI Class Initialized
INFO - 2017-12-23 01:53:26 --> URI Class Initialized
INFO - 2017-12-23 01:53:26 --> Router Class Initialized
INFO - 2017-12-23 01:53:26 --> Router Class Initialized
INFO - 2017-12-23 01:53:26 --> Output Class Initialized
INFO - 2017-12-23 01:53:26 --> Output Class Initialized
INFO - 2017-12-23 01:53:26 --> Security Class Initialized
INFO - 2017-12-23 01:53:26 --> Security Class Initialized
DEBUG - 2017-12-23 01:53:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 01:53:26 --> Input Class Initialized
INFO - 2017-12-23 01:53:26 --> Language Class Initialized
DEBUG - 2017-12-23 01:53:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 01:53:26 --> Input Class Initialized
INFO - 2017-12-23 01:53:26 --> Language Class Initialized
INFO - 2017-12-23 01:53:26 --> Loader Class Initialized
INFO - 2017-12-23 01:53:26 --> Helper loaded: url_helper
INFO - 2017-12-23 01:53:26 --> Loader Class Initialized
INFO - 2017-12-23 01:53:26 --> Helper loaded: form_helper
INFO - 2017-12-23 01:53:26 --> Helper loaded: url_helper
INFO - 2017-12-23 01:53:26 --> Helper loaded: form_helper
INFO - 2017-12-23 01:53:26 --> Database Driver Class Initialized
INFO - 2017-12-23 01:53:26 --> Database Driver Class Initialized
DEBUG - 2017-12-23 01:53:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 01:53:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 01:53:26 --> Form Validation Class Initialized
DEBUG - 2017-12-23 01:53:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 01:53:26 --> Model Class Initialized
INFO - 2017-12-23 01:53:26 --> Controller Class Initialized
INFO - 2017-12-23 01:53:26 --> Model Class Initialized
INFO - 2017-12-23 01:53:26 --> Model Class Initialized
INFO - 2017-12-23 01:53:26 --> Model Class Initialized
DEBUG - 2017-12-23 01:53:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 01:53:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 01:53:26 --> Form Validation Class Initialized
INFO - 2017-12-23 01:53:26 --> Model Class Initialized
INFO - 2017-12-23 01:53:26 --> Controller Class Initialized
INFO - 2017-12-23 01:53:26 --> Model Class Initialized
INFO - 2017-12-23 01:53:26 --> Model Class Initialized
INFO - 2017-12-23 01:53:26 --> Model Class Initialized
DEBUG - 2017-12-23 01:53:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 01:54:21 --> Config Class Initialized
INFO - 2017-12-23 01:54:21 --> Hooks Class Initialized
DEBUG - 2017-12-23 01:54:21 --> UTF-8 Support Enabled
INFO - 2017-12-23 01:54:21 --> Utf8 Class Initialized
INFO - 2017-12-23 01:54:21 --> URI Class Initialized
INFO - 2017-12-23 01:54:22 --> Router Class Initialized
INFO - 2017-12-23 01:54:22 --> Output Class Initialized
INFO - 2017-12-23 01:54:22 --> Security Class Initialized
DEBUG - 2017-12-23 01:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 01:54:22 --> Input Class Initialized
INFO - 2017-12-23 01:54:22 --> Language Class Initialized
INFO - 2017-12-23 01:54:22 --> Loader Class Initialized
INFO - 2017-12-23 01:54:22 --> Helper loaded: url_helper
INFO - 2017-12-23 01:54:22 --> Helper loaded: form_helper
INFO - 2017-12-23 01:54:22 --> Database Driver Class Initialized
DEBUG - 2017-12-23 01:54:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 01:54:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 01:54:22 --> Form Validation Class Initialized
INFO - 2017-12-23 01:54:22 --> Model Class Initialized
INFO - 2017-12-23 01:54:22 --> Controller Class Initialized
INFO - 2017-12-23 01:54:22 --> Model Class Initialized
INFO - 2017-12-23 01:54:22 --> Model Class Initialized
INFO - 2017-12-23 01:54:22 --> Model Class Initialized
DEBUG - 2017-12-23 01:54:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 01:54:22 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-23 01:54:22 --> Final output sent to browser
DEBUG - 2017-12-23 01:54:22 --> Total execution time: 0.6624
INFO - 2017-12-23 01:54:22 --> Config Class Initialized
INFO - 2017-12-23 01:54:22 --> Hooks Class Initialized
INFO - 2017-12-23 01:54:22 --> Config Class Initialized
INFO - 2017-12-23 01:54:22 --> Hooks Class Initialized
DEBUG - 2017-12-23 01:54:22 --> UTF-8 Support Enabled
INFO - 2017-12-23 01:54:22 --> Utf8 Class Initialized
DEBUG - 2017-12-23 01:54:22 --> UTF-8 Support Enabled
INFO - 2017-12-23 01:54:22 --> URI Class Initialized
INFO - 2017-12-23 01:54:22 --> Utf8 Class Initialized
INFO - 2017-12-23 01:54:22 --> URI Class Initialized
INFO - 2017-12-23 01:54:22 --> Router Class Initialized
INFO - 2017-12-23 01:54:22 --> Router Class Initialized
INFO - 2017-12-23 01:54:22 --> Output Class Initialized
INFO - 2017-12-23 01:54:22 --> Output Class Initialized
INFO - 2017-12-23 01:54:22 --> Security Class Initialized
INFO - 2017-12-23 01:54:22 --> Security Class Initialized
DEBUG - 2017-12-23 01:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 01:54:22 --> Input Class Initialized
DEBUG - 2017-12-23 01:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 01:54:22 --> Input Class Initialized
INFO - 2017-12-23 01:54:22 --> Language Class Initialized
INFO - 2017-12-23 01:54:22 --> Language Class Initialized
INFO - 2017-12-23 01:54:22 --> Loader Class Initialized
INFO - 2017-12-23 01:54:22 --> Loader Class Initialized
INFO - 2017-12-23 01:54:22 --> Helper loaded: url_helper
INFO - 2017-12-23 01:54:22 --> Helper loaded: url_helper
INFO - 2017-12-23 01:54:22 --> Helper loaded: form_helper
INFO - 2017-12-23 01:54:22 --> Helper loaded: form_helper
INFO - 2017-12-23 01:54:22 --> Database Driver Class Initialized
INFO - 2017-12-23 01:54:22 --> Database Driver Class Initialized
DEBUG - 2017-12-23 01:54:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 01:54:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2017-12-23 01:54:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 01:54:22 --> Form Validation Class Initialized
INFO - 2017-12-23 01:54:22 --> Model Class Initialized
INFO - 2017-12-23 01:54:22 --> Controller Class Initialized
INFO - 2017-12-23 01:54:22 --> Model Class Initialized
INFO - 2017-12-23 01:54:22 --> Model Class Initialized
INFO - 2017-12-23 01:54:22 --> Model Class Initialized
DEBUG - 2017-12-23 01:54:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 01:54:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 01:54:22 --> Form Validation Class Initialized
INFO - 2017-12-23 01:54:22 --> Model Class Initialized
INFO - 2017-12-23 01:54:22 --> Controller Class Initialized
INFO - 2017-12-23 01:54:22 --> Model Class Initialized
INFO - 2017-12-23 01:54:22 --> Model Class Initialized
INFO - 2017-12-23 01:54:22 --> Model Class Initialized
DEBUG - 2017-12-23 01:54:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 01:54:25 --> Config Class Initialized
INFO - 2017-12-23 01:54:25 --> Hooks Class Initialized
DEBUG - 2017-12-23 01:54:25 --> UTF-8 Support Enabled
INFO - 2017-12-23 01:54:25 --> Utf8 Class Initialized
INFO - 2017-12-23 01:54:25 --> URI Class Initialized
INFO - 2017-12-23 01:54:25 --> Router Class Initialized
INFO - 2017-12-23 01:54:25 --> Output Class Initialized
INFO - 2017-12-23 01:54:25 --> Security Class Initialized
DEBUG - 2017-12-23 01:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 01:54:25 --> Input Class Initialized
INFO - 2017-12-23 01:54:25 --> Language Class Initialized
INFO - 2017-12-23 01:54:25 --> Loader Class Initialized
INFO - 2017-12-23 01:54:25 --> Helper loaded: url_helper
INFO - 2017-12-23 01:54:25 --> Helper loaded: form_helper
INFO - 2017-12-23 01:54:25 --> Database Driver Class Initialized
DEBUG - 2017-12-23 01:54:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 01:54:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 01:54:25 --> Form Validation Class Initialized
INFO - 2017-12-23 01:54:25 --> Model Class Initialized
INFO - 2017-12-23 01:54:25 --> Controller Class Initialized
INFO - 2017-12-23 01:54:25 --> Model Class Initialized
INFO - 2017-12-23 01:54:25 --> Model Class Initialized
INFO - 2017-12-23 01:54:25 --> Model Class Initialized
DEBUG - 2017-12-23 01:54:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 01:54:25 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-23 01:54:25 --> Final output sent to browser
DEBUG - 2017-12-23 01:54:25 --> Total execution time: 0.0734
INFO - 2017-12-23 01:54:25 --> Config Class Initialized
INFO - 2017-12-23 01:54:25 --> Hooks Class Initialized
DEBUG - 2017-12-23 01:54:25 --> UTF-8 Support Enabled
INFO - 2017-12-23 01:54:25 --> Utf8 Class Initialized
INFO - 2017-12-23 01:54:25 --> URI Class Initialized
INFO - 2017-12-23 01:54:25 --> Router Class Initialized
INFO - 2017-12-23 01:54:25 --> Output Class Initialized
INFO - 2017-12-23 01:54:25 --> Security Class Initialized
DEBUG - 2017-12-23 01:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 01:54:25 --> Input Class Initialized
INFO - 2017-12-23 01:54:25 --> Language Class Initialized
INFO - 2017-12-23 01:54:25 --> Loader Class Initialized
INFO - 2017-12-23 01:54:25 --> Helper loaded: url_helper
INFO - 2017-12-23 01:54:26 --> Helper loaded: form_helper
INFO - 2017-12-23 01:54:26 --> Database Driver Class Initialized
DEBUG - 2017-12-23 01:54:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 01:54:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 01:54:26 --> Form Validation Class Initialized
INFO - 2017-12-23 01:54:26 --> Model Class Initialized
INFO - 2017-12-23 01:54:26 --> Controller Class Initialized
INFO - 2017-12-23 01:54:26 --> Model Class Initialized
INFO - 2017-12-23 01:54:26 --> Model Class Initialized
INFO - 2017-12-23 01:54:26 --> Model Class Initialized
DEBUG - 2017-12-23 01:54:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 01:55:19 --> Config Class Initialized
INFO - 2017-12-23 01:55:19 --> Hooks Class Initialized
DEBUG - 2017-12-23 01:55:19 --> UTF-8 Support Enabled
INFO - 2017-12-23 01:55:19 --> Utf8 Class Initialized
INFO - 2017-12-23 01:55:19 --> URI Class Initialized
INFO - 2017-12-23 01:55:19 --> Router Class Initialized
INFO - 2017-12-23 01:55:19 --> Output Class Initialized
INFO - 2017-12-23 01:55:19 --> Security Class Initialized
DEBUG - 2017-12-23 01:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 01:55:19 --> Input Class Initialized
INFO - 2017-12-23 01:55:19 --> Language Class Initialized
INFO - 2017-12-23 01:55:19 --> Loader Class Initialized
INFO - 2017-12-23 01:55:19 --> Helper loaded: url_helper
INFO - 2017-12-23 01:55:19 --> Helper loaded: form_helper
INFO - 2017-12-23 01:55:19 --> Database Driver Class Initialized
DEBUG - 2017-12-23 01:55:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 01:55:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 01:55:19 --> Form Validation Class Initialized
INFO - 2017-12-23 01:55:19 --> Model Class Initialized
INFO - 2017-12-23 01:55:19 --> Controller Class Initialized
INFO - 2017-12-23 01:55:19 --> Model Class Initialized
INFO - 2017-12-23 01:55:19 --> Model Class Initialized
INFO - 2017-12-23 01:55:19 --> Model Class Initialized
DEBUG - 2017-12-23 01:55:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 01:55:19 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-23 01:55:19 --> Final output sent to browser
DEBUG - 2017-12-23 01:55:19 --> Total execution time: 0.0704
INFO - 2017-12-23 02:12:17 --> Config Class Initialized
INFO - 2017-12-23 02:12:17 --> Hooks Class Initialized
DEBUG - 2017-12-23 02:12:17 --> UTF-8 Support Enabled
INFO - 2017-12-23 02:12:17 --> Utf8 Class Initialized
INFO - 2017-12-23 02:12:17 --> URI Class Initialized
INFO - 2017-12-23 02:12:17 --> Router Class Initialized
INFO - 2017-12-23 02:12:17 --> Output Class Initialized
INFO - 2017-12-23 02:12:17 --> Security Class Initialized
DEBUG - 2017-12-23 02:12:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 02:12:17 --> Input Class Initialized
INFO - 2017-12-23 02:12:17 --> Language Class Initialized
INFO - 2017-12-23 02:12:17 --> Loader Class Initialized
INFO - 2017-12-23 02:12:17 --> Helper loaded: url_helper
INFO - 2017-12-23 02:12:17 --> Helper loaded: form_helper
INFO - 2017-12-23 02:12:17 --> Database Driver Class Initialized
DEBUG - 2017-12-23 02:12:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 02:12:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 02:12:17 --> Form Validation Class Initialized
INFO - 2017-12-23 02:12:17 --> Model Class Initialized
INFO - 2017-12-23 02:12:17 --> Controller Class Initialized
INFO - 2017-12-23 02:12:17 --> Model Class Initialized
INFO - 2017-12-23 02:12:17 --> Model Class Initialized
INFO - 2017-12-23 02:12:17 --> Model Class Initialized
DEBUG - 2017-12-23 02:12:17 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2017-12-23 02:12:17 --> Severity: Notice --> Undefined variable: datos D:\xampp\htdocs\instateccr\instatec_app\models\M_Proyecto.php 368
ERROR - 2017-12-23 02:12:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\editarExtensionProyecto.php 67
ERROR - 2017-12-23 02:12:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\editarExtensionProyecto.php 77
INFO - 2017-12-23 02:12:17 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-23 02:12:17 --> Final output sent to browser
DEBUG - 2017-12-23 02:12:17 --> Total execution time: 0.0577
INFO - 2017-12-23 02:13:27 --> Config Class Initialized
INFO - 2017-12-23 02:13:27 --> Hooks Class Initialized
DEBUG - 2017-12-23 02:13:27 --> UTF-8 Support Enabled
INFO - 2017-12-23 02:13:27 --> Utf8 Class Initialized
INFO - 2017-12-23 02:13:27 --> URI Class Initialized
INFO - 2017-12-23 02:13:27 --> Router Class Initialized
INFO - 2017-12-23 02:13:27 --> Output Class Initialized
INFO - 2017-12-23 02:13:27 --> Security Class Initialized
DEBUG - 2017-12-23 02:13:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 02:13:27 --> Input Class Initialized
INFO - 2017-12-23 02:13:27 --> Language Class Initialized
INFO - 2017-12-23 02:13:27 --> Loader Class Initialized
INFO - 2017-12-23 02:13:27 --> Helper loaded: url_helper
INFO - 2017-12-23 02:13:27 --> Helper loaded: form_helper
INFO - 2017-12-23 02:13:27 --> Database Driver Class Initialized
DEBUG - 2017-12-23 02:13:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 02:13:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 02:13:27 --> Form Validation Class Initialized
INFO - 2017-12-23 02:13:27 --> Model Class Initialized
INFO - 2017-12-23 02:13:27 --> Controller Class Initialized
INFO - 2017-12-23 02:13:27 --> Model Class Initialized
INFO - 2017-12-23 02:13:27 --> Model Class Initialized
INFO - 2017-12-23 02:13:27 --> Model Class Initialized
DEBUG - 2017-12-23 02:13:27 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2017-12-23 02:13:27 --> Severity: Notice --> Undefined variable: datos D:\xampp\htdocs\instateccr\instatec_app\models\M_Proyecto.php 368
INFO - 2017-12-23 02:13:53 --> Config Class Initialized
INFO - 2017-12-23 02:13:53 --> Hooks Class Initialized
DEBUG - 2017-12-23 02:13:53 --> UTF-8 Support Enabled
INFO - 2017-12-23 02:13:53 --> Utf8 Class Initialized
INFO - 2017-12-23 02:13:53 --> URI Class Initialized
INFO - 2017-12-23 02:13:53 --> Router Class Initialized
INFO - 2017-12-23 02:13:53 --> Output Class Initialized
INFO - 2017-12-23 02:13:53 --> Security Class Initialized
DEBUG - 2017-12-23 02:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 02:13:53 --> Input Class Initialized
INFO - 2017-12-23 02:13:53 --> Language Class Initialized
INFO - 2017-12-23 02:13:53 --> Loader Class Initialized
INFO - 2017-12-23 02:13:53 --> Helper loaded: url_helper
INFO - 2017-12-23 02:13:53 --> Helper loaded: form_helper
INFO - 2017-12-23 02:13:53 --> Database Driver Class Initialized
DEBUG - 2017-12-23 02:13:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 02:13:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 02:13:53 --> Form Validation Class Initialized
INFO - 2017-12-23 02:13:53 --> Model Class Initialized
INFO - 2017-12-23 02:13:53 --> Controller Class Initialized
INFO - 2017-12-23 02:13:53 --> Model Class Initialized
INFO - 2017-12-23 02:13:54 --> Model Class Initialized
INFO - 2017-12-23 02:13:54 --> Model Class Initialized
DEBUG - 2017-12-23 02:13:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 02:14:10 --> Config Class Initialized
INFO - 2017-12-23 02:14:10 --> Hooks Class Initialized
DEBUG - 2017-12-23 02:14:10 --> UTF-8 Support Enabled
INFO - 2017-12-23 02:14:10 --> Utf8 Class Initialized
INFO - 2017-12-23 02:14:10 --> URI Class Initialized
INFO - 2017-12-23 02:14:10 --> Router Class Initialized
INFO - 2017-12-23 02:14:10 --> Output Class Initialized
INFO - 2017-12-23 02:14:10 --> Security Class Initialized
DEBUG - 2017-12-23 02:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 02:14:10 --> Input Class Initialized
INFO - 2017-12-23 02:14:10 --> Language Class Initialized
INFO - 2017-12-23 02:14:10 --> Loader Class Initialized
INFO - 2017-12-23 02:14:10 --> Helper loaded: url_helper
INFO - 2017-12-23 02:14:10 --> Helper loaded: form_helper
INFO - 2017-12-23 02:14:10 --> Database Driver Class Initialized
DEBUG - 2017-12-23 02:14:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 02:14:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 02:14:10 --> Form Validation Class Initialized
INFO - 2017-12-23 02:14:10 --> Model Class Initialized
INFO - 2017-12-23 02:14:10 --> Controller Class Initialized
INFO - 2017-12-23 02:14:10 --> Model Class Initialized
INFO - 2017-12-23 02:14:10 --> Model Class Initialized
INFO - 2017-12-23 02:14:10 --> Model Class Initialized
DEBUG - 2017-12-23 02:14:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 02:14:20 --> Config Class Initialized
INFO - 2017-12-23 02:14:20 --> Hooks Class Initialized
DEBUG - 2017-12-23 02:14:20 --> UTF-8 Support Enabled
INFO - 2017-12-23 02:14:20 --> Utf8 Class Initialized
INFO - 2017-12-23 02:14:20 --> URI Class Initialized
INFO - 2017-12-23 02:14:20 --> Router Class Initialized
INFO - 2017-12-23 02:14:20 --> Output Class Initialized
INFO - 2017-12-23 02:14:20 --> Security Class Initialized
DEBUG - 2017-12-23 02:14:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 02:14:20 --> Input Class Initialized
INFO - 2017-12-23 02:14:20 --> Language Class Initialized
INFO - 2017-12-23 02:14:20 --> Loader Class Initialized
INFO - 2017-12-23 02:14:20 --> Helper loaded: url_helper
INFO - 2017-12-23 02:14:20 --> Helper loaded: form_helper
INFO - 2017-12-23 02:14:20 --> Database Driver Class Initialized
DEBUG - 2017-12-23 02:14:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 02:14:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 02:14:20 --> Form Validation Class Initialized
INFO - 2017-12-23 02:14:20 --> Model Class Initialized
INFO - 2017-12-23 02:14:20 --> Controller Class Initialized
INFO - 2017-12-23 02:14:20 --> Model Class Initialized
INFO - 2017-12-23 02:14:20 --> Model Class Initialized
INFO - 2017-12-23 02:14:20 --> Model Class Initialized
DEBUG - 2017-12-23 02:14:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 02:14:20 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-23 02:14:20 --> Final output sent to browser
DEBUG - 2017-12-23 02:14:20 --> Total execution time: 0.1152
INFO - 2017-12-23 02:14:33 --> Config Class Initialized
INFO - 2017-12-23 02:14:33 --> Hooks Class Initialized
DEBUG - 2017-12-23 02:14:33 --> UTF-8 Support Enabled
INFO - 2017-12-23 02:14:33 --> Utf8 Class Initialized
INFO - 2017-12-23 02:14:33 --> URI Class Initialized
INFO - 2017-12-23 02:14:33 --> Router Class Initialized
INFO - 2017-12-23 02:14:33 --> Output Class Initialized
INFO - 2017-12-23 02:14:33 --> Security Class Initialized
DEBUG - 2017-12-23 02:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 02:14:33 --> Input Class Initialized
INFO - 2017-12-23 02:14:33 --> Language Class Initialized
INFO - 2017-12-23 02:14:33 --> Loader Class Initialized
INFO - 2017-12-23 02:14:33 --> Helper loaded: url_helper
INFO - 2017-12-23 02:14:33 --> Helper loaded: form_helper
INFO - 2017-12-23 02:14:33 --> Database Driver Class Initialized
DEBUG - 2017-12-23 02:14:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 02:14:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 02:14:33 --> Form Validation Class Initialized
INFO - 2017-12-23 02:14:33 --> Model Class Initialized
INFO - 2017-12-23 02:14:33 --> Controller Class Initialized
INFO - 2017-12-23 02:14:33 --> Model Class Initialized
INFO - 2017-12-23 02:14:33 --> Model Class Initialized
INFO - 2017-12-23 02:14:33 --> Model Class Initialized
DEBUG - 2017-12-23 02:14:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 02:14:33 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-23 02:14:33 --> Final output sent to browser
DEBUG - 2017-12-23 02:14:33 --> Total execution time: 0.1122
INFO - 2017-12-23 02:17:23 --> Config Class Initialized
INFO - 2017-12-23 02:17:23 --> Hooks Class Initialized
DEBUG - 2017-12-23 02:17:23 --> UTF-8 Support Enabled
INFO - 2017-12-23 02:17:23 --> Utf8 Class Initialized
INFO - 2017-12-23 02:17:23 --> URI Class Initialized
INFO - 2017-12-23 02:17:23 --> Router Class Initialized
INFO - 2017-12-23 02:17:23 --> Output Class Initialized
INFO - 2017-12-23 02:17:23 --> Security Class Initialized
DEBUG - 2017-12-23 02:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 02:17:23 --> Input Class Initialized
INFO - 2017-12-23 02:17:23 --> Language Class Initialized
INFO - 2017-12-23 02:17:23 --> Loader Class Initialized
INFO - 2017-12-23 02:17:23 --> Helper loaded: url_helper
INFO - 2017-12-23 02:17:23 --> Helper loaded: form_helper
INFO - 2017-12-23 02:17:23 --> Database Driver Class Initialized
DEBUG - 2017-12-23 02:17:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 02:17:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 02:17:23 --> Form Validation Class Initialized
INFO - 2017-12-23 02:17:23 --> Model Class Initialized
INFO - 2017-12-23 02:17:23 --> Controller Class Initialized
INFO - 2017-12-23 02:17:23 --> Model Class Initialized
INFO - 2017-12-23 02:17:23 --> Model Class Initialized
INFO - 2017-12-23 02:17:23 --> Model Class Initialized
DEBUG - 2017-12-23 02:17:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 02:17:23 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-23 02:17:23 --> Final output sent to browser
DEBUG - 2017-12-23 02:17:23 --> Total execution time: 0.0504
INFO - 2017-12-23 02:17:23 --> Config Class Initialized
INFO - 2017-12-23 02:17:23 --> Hooks Class Initialized
DEBUG - 2017-12-23 02:17:23 --> UTF-8 Support Enabled
INFO - 2017-12-23 02:17:23 --> Utf8 Class Initialized
INFO - 2017-12-23 02:17:23 --> URI Class Initialized
INFO - 2017-12-23 02:17:23 --> Router Class Initialized
INFO - 2017-12-23 02:17:23 --> Output Class Initialized
INFO - 2017-12-23 02:17:23 --> Security Class Initialized
DEBUG - 2017-12-23 02:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 02:17:23 --> Input Class Initialized
INFO - 2017-12-23 02:17:23 --> Language Class Initialized
INFO - 2017-12-23 02:17:23 --> Loader Class Initialized
INFO - 2017-12-23 02:17:23 --> Helper loaded: url_helper
INFO - 2017-12-23 02:17:23 --> Helper loaded: form_helper
INFO - 2017-12-23 02:17:23 --> Database Driver Class Initialized
DEBUG - 2017-12-23 02:17:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 02:17:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 02:17:23 --> Form Validation Class Initialized
INFO - 2017-12-23 02:17:23 --> Model Class Initialized
INFO - 2017-12-23 02:17:23 --> Controller Class Initialized
INFO - 2017-12-23 02:17:23 --> Model Class Initialized
INFO - 2017-12-23 02:17:23 --> Model Class Initialized
INFO - 2017-12-23 02:17:23 --> Model Class Initialized
DEBUG - 2017-12-23 02:17:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 02:17:23 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-23 02:17:23 --> Final output sent to browser
DEBUG - 2017-12-23 02:17:23 --> Total execution time: 0.1415
INFO - 2017-12-23 02:17:25 --> Config Class Initialized
INFO - 2017-12-23 02:17:25 --> Hooks Class Initialized
DEBUG - 2017-12-23 02:17:25 --> UTF-8 Support Enabled
INFO - 2017-12-23 02:17:25 --> Utf8 Class Initialized
INFO - 2017-12-23 02:17:25 --> URI Class Initialized
INFO - 2017-12-23 02:17:25 --> Router Class Initialized
INFO - 2017-12-23 02:17:25 --> Output Class Initialized
INFO - 2017-12-23 02:17:25 --> Security Class Initialized
DEBUG - 2017-12-23 02:17:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 02:17:25 --> Input Class Initialized
INFO - 2017-12-23 02:17:25 --> Language Class Initialized
INFO - 2017-12-23 02:17:25 --> Loader Class Initialized
INFO - 2017-12-23 02:17:25 --> Helper loaded: url_helper
INFO - 2017-12-23 02:17:25 --> Helper loaded: form_helper
INFO - 2017-12-23 02:17:25 --> Database Driver Class Initialized
DEBUG - 2017-12-23 02:17:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 02:17:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 02:17:25 --> Form Validation Class Initialized
INFO - 2017-12-23 02:17:25 --> Model Class Initialized
INFO - 2017-12-23 02:17:25 --> Controller Class Initialized
INFO - 2017-12-23 02:17:25 --> Model Class Initialized
INFO - 2017-12-23 02:17:25 --> Model Class Initialized
INFO - 2017-12-23 02:17:25 --> Model Class Initialized
DEBUG - 2017-12-23 02:17:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 02:17:25 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-23 02:17:25 --> Final output sent to browser
DEBUG - 2017-12-23 02:17:25 --> Total execution time: 0.0555
INFO - 2017-12-23 02:17:27 --> Config Class Initialized
INFO - 2017-12-23 02:17:27 --> Hooks Class Initialized
DEBUG - 2017-12-23 02:17:27 --> UTF-8 Support Enabled
INFO - 2017-12-23 02:17:27 --> Utf8 Class Initialized
INFO - 2017-12-23 02:17:27 --> URI Class Initialized
INFO - 2017-12-23 02:17:27 --> Router Class Initialized
INFO - 2017-12-23 02:17:27 --> Output Class Initialized
INFO - 2017-12-23 02:17:27 --> Security Class Initialized
DEBUG - 2017-12-23 02:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 02:17:27 --> Input Class Initialized
INFO - 2017-12-23 02:17:27 --> Language Class Initialized
INFO - 2017-12-23 02:17:27 --> Loader Class Initialized
INFO - 2017-12-23 02:17:27 --> Helper loaded: url_helper
INFO - 2017-12-23 02:17:27 --> Helper loaded: form_helper
INFO - 2017-12-23 02:17:27 --> Database Driver Class Initialized
DEBUG - 2017-12-23 02:17:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 02:17:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 02:17:27 --> Form Validation Class Initialized
INFO - 2017-12-23 02:17:27 --> Model Class Initialized
INFO - 2017-12-23 02:17:27 --> Controller Class Initialized
INFO - 2017-12-23 02:17:27 --> Model Class Initialized
INFO - 2017-12-23 02:17:27 --> Model Class Initialized
INFO - 2017-12-23 02:17:27 --> Model Class Initialized
DEBUG - 2017-12-23 02:17:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 02:17:27 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-23 02:17:27 --> Final output sent to browser
DEBUG - 2017-12-23 02:17:27 --> Total execution time: 0.0510
INFO - 2017-12-23 02:17:28 --> Config Class Initialized
INFO - 2017-12-23 02:17:28 --> Hooks Class Initialized
DEBUG - 2017-12-23 02:17:28 --> UTF-8 Support Enabled
INFO - 2017-12-23 02:17:28 --> Utf8 Class Initialized
INFO - 2017-12-23 02:17:28 --> URI Class Initialized
INFO - 2017-12-23 02:17:28 --> Router Class Initialized
INFO - 2017-12-23 02:17:28 --> Output Class Initialized
INFO - 2017-12-23 02:17:28 --> Security Class Initialized
DEBUG - 2017-12-23 02:17:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 02:17:28 --> Input Class Initialized
INFO - 2017-12-23 02:17:28 --> Language Class Initialized
INFO - 2017-12-23 02:17:28 --> Loader Class Initialized
INFO - 2017-12-23 02:17:28 --> Helper loaded: url_helper
INFO - 2017-12-23 02:17:28 --> Helper loaded: form_helper
INFO - 2017-12-23 02:17:28 --> Database Driver Class Initialized
DEBUG - 2017-12-23 02:17:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 02:17:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 02:17:28 --> Form Validation Class Initialized
INFO - 2017-12-23 02:17:28 --> Model Class Initialized
INFO - 2017-12-23 02:17:28 --> Controller Class Initialized
INFO - 2017-12-23 02:17:28 --> Model Class Initialized
INFO - 2017-12-23 02:17:28 --> Model Class Initialized
INFO - 2017-12-23 02:17:28 --> Model Class Initialized
DEBUG - 2017-12-23 02:17:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 02:17:28 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-23 02:17:28 --> Final output sent to browser
DEBUG - 2017-12-23 02:17:28 --> Total execution time: 0.1282
INFO - 2017-12-23 02:17:28 --> Config Class Initialized
INFO - 2017-12-23 02:17:28 --> Hooks Class Initialized
DEBUG - 2017-12-23 02:17:28 --> UTF-8 Support Enabled
INFO - 2017-12-23 02:17:28 --> Utf8 Class Initialized
INFO - 2017-12-23 02:17:28 --> URI Class Initialized
INFO - 2017-12-23 02:17:28 --> Router Class Initialized
INFO - 2017-12-23 02:17:28 --> Output Class Initialized
INFO - 2017-12-23 02:17:28 --> Security Class Initialized
DEBUG - 2017-12-23 02:17:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 02:17:28 --> Input Class Initialized
INFO - 2017-12-23 02:17:28 --> Language Class Initialized
INFO - 2017-12-23 02:17:28 --> Loader Class Initialized
INFO - 2017-12-23 02:17:28 --> Helper loaded: url_helper
INFO - 2017-12-23 02:17:28 --> Helper loaded: form_helper
INFO - 2017-12-23 02:17:28 --> Database Driver Class Initialized
DEBUG - 2017-12-23 02:17:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 02:17:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 02:17:28 --> Form Validation Class Initialized
INFO - 2017-12-23 02:17:28 --> Model Class Initialized
INFO - 2017-12-23 02:17:28 --> Controller Class Initialized
INFO - 2017-12-23 02:17:28 --> Model Class Initialized
INFO - 2017-12-23 02:17:28 --> Model Class Initialized
INFO - 2017-12-23 02:17:28 --> Model Class Initialized
DEBUG - 2017-12-23 02:17:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 02:17:28 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-23 02:17:28 --> Final output sent to browser
DEBUG - 2017-12-23 02:17:28 --> Total execution time: 0.1208
INFO - 2017-12-23 02:17:28 --> Config Class Initialized
INFO - 2017-12-23 02:17:28 --> Hooks Class Initialized
DEBUG - 2017-12-23 02:17:29 --> UTF-8 Support Enabled
INFO - 2017-12-23 02:17:29 --> Utf8 Class Initialized
INFO - 2017-12-23 02:17:29 --> URI Class Initialized
INFO - 2017-12-23 02:17:29 --> Router Class Initialized
INFO - 2017-12-23 02:17:29 --> Output Class Initialized
INFO - 2017-12-23 02:17:29 --> Security Class Initialized
DEBUG - 2017-12-23 02:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 02:17:29 --> Input Class Initialized
INFO - 2017-12-23 02:17:29 --> Language Class Initialized
INFO - 2017-12-23 02:17:29 --> Loader Class Initialized
INFO - 2017-12-23 02:17:29 --> Helper loaded: url_helper
INFO - 2017-12-23 02:17:29 --> Helper loaded: form_helper
INFO - 2017-12-23 02:17:29 --> Database Driver Class Initialized
DEBUG - 2017-12-23 02:17:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 02:17:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 02:17:29 --> Form Validation Class Initialized
INFO - 2017-12-23 02:17:29 --> Model Class Initialized
INFO - 2017-12-23 02:17:29 --> Controller Class Initialized
INFO - 2017-12-23 02:17:29 --> Model Class Initialized
INFO - 2017-12-23 02:17:29 --> Model Class Initialized
INFO - 2017-12-23 02:17:29 --> Model Class Initialized
DEBUG - 2017-12-23 02:17:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 02:17:29 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-23 02:17:29 --> Final output sent to browser
DEBUG - 2017-12-23 02:17:29 --> Total execution time: 0.1225
INFO - 2017-12-23 02:17:29 --> Config Class Initialized
INFO - 2017-12-23 02:17:29 --> Hooks Class Initialized
DEBUG - 2017-12-23 02:17:29 --> UTF-8 Support Enabled
INFO - 2017-12-23 02:17:29 --> Utf8 Class Initialized
INFO - 2017-12-23 02:17:29 --> URI Class Initialized
INFO - 2017-12-23 02:17:29 --> Router Class Initialized
INFO - 2017-12-23 02:17:29 --> Output Class Initialized
INFO - 2017-12-23 02:17:29 --> Security Class Initialized
DEBUG - 2017-12-23 02:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 02:17:29 --> Input Class Initialized
INFO - 2017-12-23 02:17:29 --> Language Class Initialized
INFO - 2017-12-23 02:17:29 --> Loader Class Initialized
INFO - 2017-12-23 02:17:29 --> Helper loaded: url_helper
INFO - 2017-12-23 02:17:29 --> Helper loaded: form_helper
INFO - 2017-12-23 02:17:29 --> Database Driver Class Initialized
DEBUG - 2017-12-23 02:17:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 02:17:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 02:17:29 --> Form Validation Class Initialized
INFO - 2017-12-23 02:17:29 --> Model Class Initialized
INFO - 2017-12-23 02:17:29 --> Controller Class Initialized
INFO - 2017-12-23 02:17:29 --> Model Class Initialized
INFO - 2017-12-23 02:17:29 --> Model Class Initialized
INFO - 2017-12-23 02:17:29 --> Model Class Initialized
DEBUG - 2017-12-23 02:17:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 02:17:29 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-23 02:17:29 --> Final output sent to browser
DEBUG - 2017-12-23 02:17:29 --> Total execution time: 0.0640
INFO - 2017-12-23 02:17:29 --> Config Class Initialized
INFO - 2017-12-23 02:17:29 --> Hooks Class Initialized
DEBUG - 2017-12-23 02:17:29 --> UTF-8 Support Enabled
INFO - 2017-12-23 02:17:29 --> Utf8 Class Initialized
INFO - 2017-12-23 02:17:29 --> URI Class Initialized
INFO - 2017-12-23 02:17:29 --> Router Class Initialized
INFO - 2017-12-23 02:17:29 --> Output Class Initialized
INFO - 2017-12-23 02:17:29 --> Security Class Initialized
DEBUG - 2017-12-23 02:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 02:17:29 --> Input Class Initialized
INFO - 2017-12-23 02:17:29 --> Language Class Initialized
INFO - 2017-12-23 02:17:29 --> Loader Class Initialized
INFO - 2017-12-23 02:17:29 --> Helper loaded: url_helper
INFO - 2017-12-23 02:17:29 --> Helper loaded: form_helper
INFO - 2017-12-23 02:17:29 --> Database Driver Class Initialized
DEBUG - 2017-12-23 02:17:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 02:17:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 02:17:29 --> Form Validation Class Initialized
INFO - 2017-12-23 02:17:29 --> Model Class Initialized
INFO - 2017-12-23 02:17:29 --> Controller Class Initialized
INFO - 2017-12-23 02:17:29 --> Model Class Initialized
INFO - 2017-12-23 02:17:29 --> Model Class Initialized
INFO - 2017-12-23 02:17:29 --> Model Class Initialized
DEBUG - 2017-12-23 02:17:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 02:17:29 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-23 02:17:29 --> Final output sent to browser
DEBUG - 2017-12-23 02:17:29 --> Total execution time: 0.1016
INFO - 2017-12-23 02:17:29 --> Config Class Initialized
INFO - 2017-12-23 02:17:29 --> Hooks Class Initialized
DEBUG - 2017-12-23 02:17:29 --> UTF-8 Support Enabled
INFO - 2017-12-23 02:17:29 --> Utf8 Class Initialized
INFO - 2017-12-23 02:17:29 --> URI Class Initialized
INFO - 2017-12-23 02:17:29 --> Router Class Initialized
INFO - 2017-12-23 02:17:29 --> Output Class Initialized
INFO - 2017-12-23 02:17:29 --> Security Class Initialized
DEBUG - 2017-12-23 02:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 02:17:29 --> Input Class Initialized
INFO - 2017-12-23 02:17:29 --> Language Class Initialized
INFO - 2017-12-23 02:17:29 --> Loader Class Initialized
INFO - 2017-12-23 02:17:29 --> Helper loaded: url_helper
INFO - 2017-12-23 02:17:29 --> Helper loaded: form_helper
INFO - 2017-12-23 02:17:29 --> Database Driver Class Initialized
DEBUG - 2017-12-23 02:17:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 02:17:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 02:17:30 --> Form Validation Class Initialized
INFO - 2017-12-23 02:17:30 --> Model Class Initialized
INFO - 2017-12-23 02:17:30 --> Controller Class Initialized
INFO - 2017-12-23 02:17:30 --> Model Class Initialized
INFO - 2017-12-23 02:17:30 --> Model Class Initialized
INFO - 2017-12-23 02:17:30 --> Model Class Initialized
DEBUG - 2017-12-23 02:17:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 02:17:30 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-23 02:17:30 --> Final output sent to browser
DEBUG - 2017-12-23 02:17:30 --> Total execution time: 0.0846
INFO - 2017-12-23 02:17:32 --> Config Class Initialized
INFO - 2017-12-23 02:17:32 --> Hooks Class Initialized
DEBUG - 2017-12-23 02:17:32 --> UTF-8 Support Enabled
INFO - 2017-12-23 02:17:32 --> Utf8 Class Initialized
INFO - 2017-12-23 02:17:32 --> URI Class Initialized
INFO - 2017-12-23 02:17:32 --> Router Class Initialized
INFO - 2017-12-23 02:17:32 --> Output Class Initialized
INFO - 2017-12-23 02:17:32 --> Security Class Initialized
DEBUG - 2017-12-23 02:17:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 02:17:32 --> Input Class Initialized
INFO - 2017-12-23 02:17:32 --> Language Class Initialized
INFO - 2017-12-23 02:17:32 --> Loader Class Initialized
INFO - 2017-12-23 02:17:32 --> Helper loaded: url_helper
INFO - 2017-12-23 02:17:32 --> Helper loaded: form_helper
INFO - 2017-12-23 02:17:32 --> Database Driver Class Initialized
DEBUG - 2017-12-23 02:17:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 02:17:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 02:17:32 --> Form Validation Class Initialized
INFO - 2017-12-23 02:17:32 --> Model Class Initialized
INFO - 2017-12-23 02:17:32 --> Controller Class Initialized
INFO - 2017-12-23 02:17:32 --> Model Class Initialized
INFO - 2017-12-23 02:17:32 --> Model Class Initialized
INFO - 2017-12-23 02:17:32 --> Model Class Initialized
DEBUG - 2017-12-23 02:17:32 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2017-12-23 02:17:32 --> Severity: Error --> Cannot unset string offsets D:\xampp\htdocs\instateccr\instatec_app\models\M_Proyecto.php 387
INFO - 2017-12-23 02:17:58 --> Config Class Initialized
INFO - 2017-12-23 02:17:58 --> Hooks Class Initialized
DEBUG - 2017-12-23 02:17:58 --> UTF-8 Support Enabled
INFO - 2017-12-23 02:17:58 --> Utf8 Class Initialized
INFO - 2017-12-23 02:17:58 --> URI Class Initialized
INFO - 2017-12-23 02:17:58 --> Router Class Initialized
INFO - 2017-12-23 02:17:58 --> Output Class Initialized
INFO - 2017-12-23 02:17:58 --> Security Class Initialized
DEBUG - 2017-12-23 02:17:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 02:17:58 --> Input Class Initialized
INFO - 2017-12-23 02:17:58 --> Language Class Initialized
INFO - 2017-12-23 02:17:58 --> Loader Class Initialized
INFO - 2017-12-23 02:17:58 --> Helper loaded: url_helper
INFO - 2017-12-23 02:17:58 --> Helper loaded: form_helper
INFO - 2017-12-23 02:17:58 --> Database Driver Class Initialized
DEBUG - 2017-12-23 02:17:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 02:17:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 02:17:58 --> Form Validation Class Initialized
INFO - 2017-12-23 02:17:58 --> Model Class Initialized
INFO - 2017-12-23 02:17:58 --> Controller Class Initialized
INFO - 2017-12-23 02:17:58 --> Model Class Initialized
INFO - 2017-12-23 02:17:58 --> Model Class Initialized
INFO - 2017-12-23 02:17:58 --> Model Class Initialized
DEBUG - 2017-12-23 02:17:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 02:17:58 --> Config Class Initialized
INFO - 2017-12-23 02:17:58 --> Hooks Class Initialized
DEBUG - 2017-12-23 02:17:58 --> UTF-8 Support Enabled
INFO - 2017-12-23 02:17:58 --> Utf8 Class Initialized
INFO - 2017-12-23 02:17:58 --> URI Class Initialized
INFO - 2017-12-23 02:17:58 --> Router Class Initialized
INFO - 2017-12-23 02:17:58 --> Output Class Initialized
INFO - 2017-12-23 02:17:58 --> Security Class Initialized
DEBUG - 2017-12-23 02:17:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 02:17:58 --> Input Class Initialized
INFO - 2017-12-23 02:17:58 --> Language Class Initialized
INFO - 2017-12-23 02:17:58 --> Loader Class Initialized
INFO - 2017-12-23 02:17:58 --> Helper loaded: url_helper
INFO - 2017-12-23 02:17:58 --> Helper loaded: form_helper
INFO - 2017-12-23 02:17:58 --> Database Driver Class Initialized
DEBUG - 2017-12-23 02:17:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 02:17:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 02:17:58 --> Form Validation Class Initialized
INFO - 2017-12-23 02:17:58 --> Model Class Initialized
INFO - 2017-12-23 02:17:58 --> Controller Class Initialized
INFO - 2017-12-23 02:17:58 --> Model Class Initialized
INFO - 2017-12-23 02:17:58 --> Model Class Initialized
INFO - 2017-12-23 02:17:58 --> Model Class Initialized
DEBUG - 2017-12-23 02:17:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 02:17:58 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-23 02:17:58 --> Final output sent to browser
DEBUG - 2017-12-23 02:17:58 --> Total execution time: 0.1433
INFO - 2017-12-23 02:18:00 --> Config Class Initialized
INFO - 2017-12-23 02:18:00 --> Hooks Class Initialized
DEBUG - 2017-12-23 02:18:00 --> UTF-8 Support Enabled
INFO - 2017-12-23 02:18:00 --> Utf8 Class Initialized
INFO - 2017-12-23 02:18:00 --> URI Class Initialized
INFO - 2017-12-23 02:18:00 --> Router Class Initialized
INFO - 2017-12-23 02:18:00 --> Output Class Initialized
INFO - 2017-12-23 02:18:00 --> Security Class Initialized
DEBUG - 2017-12-23 02:18:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 02:18:00 --> Input Class Initialized
INFO - 2017-12-23 02:18:00 --> Language Class Initialized
INFO - 2017-12-23 02:18:00 --> Loader Class Initialized
INFO - 2017-12-23 02:18:00 --> Helper loaded: url_helper
INFO - 2017-12-23 02:18:00 --> Helper loaded: form_helper
INFO - 2017-12-23 02:18:00 --> Database Driver Class Initialized
DEBUG - 2017-12-23 02:18:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 02:18:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 02:18:00 --> Form Validation Class Initialized
INFO - 2017-12-23 02:18:00 --> Model Class Initialized
INFO - 2017-12-23 02:18:00 --> Controller Class Initialized
INFO - 2017-12-23 02:18:00 --> Model Class Initialized
INFO - 2017-12-23 02:18:00 --> Model Class Initialized
INFO - 2017-12-23 02:18:00 --> Model Class Initialized
DEBUG - 2017-12-23 02:18:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 02:18:00 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-23 02:18:00 --> Final output sent to browser
DEBUG - 2017-12-23 02:18:00 --> Total execution time: 0.0926
INFO - 2017-12-23 02:18:01 --> Config Class Initialized
INFO - 2017-12-23 02:18:01 --> Hooks Class Initialized
DEBUG - 2017-12-23 02:18:01 --> UTF-8 Support Enabled
INFO - 2017-12-23 02:18:01 --> Utf8 Class Initialized
INFO - 2017-12-23 02:18:01 --> URI Class Initialized
INFO - 2017-12-23 02:18:01 --> Router Class Initialized
INFO - 2017-12-23 02:18:01 --> Output Class Initialized
INFO - 2017-12-23 02:18:01 --> Security Class Initialized
DEBUG - 2017-12-23 02:18:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 02:18:01 --> Input Class Initialized
INFO - 2017-12-23 02:18:01 --> Language Class Initialized
INFO - 2017-12-23 02:18:01 --> Loader Class Initialized
INFO - 2017-12-23 02:18:01 --> Helper loaded: url_helper
INFO - 2017-12-23 02:18:01 --> Helper loaded: form_helper
INFO - 2017-12-23 02:18:01 --> Database Driver Class Initialized
DEBUG - 2017-12-23 02:18:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 02:18:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 02:18:01 --> Form Validation Class Initialized
INFO - 2017-12-23 02:18:01 --> Model Class Initialized
INFO - 2017-12-23 02:18:01 --> Controller Class Initialized
INFO - 2017-12-23 02:18:01 --> Model Class Initialized
INFO - 2017-12-23 02:18:01 --> Model Class Initialized
INFO - 2017-12-23 02:18:01 --> Model Class Initialized
DEBUG - 2017-12-23 02:18:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 02:18:01 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-23 02:18:01 --> Final output sent to browser
DEBUG - 2017-12-23 02:18:01 --> Total execution time: 0.0639
INFO - 2017-12-23 02:18:04 --> Config Class Initialized
INFO - 2017-12-23 02:18:04 --> Hooks Class Initialized
DEBUG - 2017-12-23 02:18:04 --> UTF-8 Support Enabled
INFO - 2017-12-23 02:18:04 --> Utf8 Class Initialized
INFO - 2017-12-23 02:18:04 --> URI Class Initialized
INFO - 2017-12-23 02:18:04 --> Router Class Initialized
INFO - 2017-12-23 02:18:04 --> Output Class Initialized
INFO - 2017-12-23 02:18:04 --> Security Class Initialized
DEBUG - 2017-12-23 02:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 02:18:04 --> Input Class Initialized
INFO - 2017-12-23 02:18:04 --> Language Class Initialized
INFO - 2017-12-23 02:18:04 --> Loader Class Initialized
INFO - 2017-12-23 02:18:04 --> Helper loaded: url_helper
INFO - 2017-12-23 02:18:04 --> Helper loaded: form_helper
INFO - 2017-12-23 02:18:04 --> Database Driver Class Initialized
DEBUG - 2017-12-23 02:18:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 02:18:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 02:18:04 --> Form Validation Class Initialized
INFO - 2017-12-23 02:18:04 --> Model Class Initialized
INFO - 2017-12-23 02:18:04 --> Controller Class Initialized
INFO - 2017-12-23 02:18:04 --> Model Class Initialized
INFO - 2017-12-23 02:18:04 --> Model Class Initialized
INFO - 2017-12-23 02:18:04 --> Model Class Initialized
DEBUG - 2017-12-23 02:18:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 02:18:05 --> Config Class Initialized
INFO - 2017-12-23 02:18:05 --> Hooks Class Initialized
DEBUG - 2017-12-23 02:18:05 --> UTF-8 Support Enabled
INFO - 2017-12-23 02:18:05 --> Utf8 Class Initialized
INFO - 2017-12-23 02:18:05 --> URI Class Initialized
INFO - 2017-12-23 02:18:05 --> Router Class Initialized
INFO - 2017-12-23 02:18:05 --> Output Class Initialized
INFO - 2017-12-23 02:18:05 --> Security Class Initialized
DEBUG - 2017-12-23 02:18:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 02:18:05 --> Input Class Initialized
INFO - 2017-12-23 02:18:05 --> Language Class Initialized
INFO - 2017-12-23 02:18:05 --> Loader Class Initialized
INFO - 2017-12-23 02:18:05 --> Helper loaded: url_helper
INFO - 2017-12-23 02:18:05 --> Helper loaded: form_helper
INFO - 2017-12-23 02:18:05 --> Database Driver Class Initialized
DEBUG - 2017-12-23 02:18:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 02:18:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 02:18:05 --> Form Validation Class Initialized
INFO - 2017-12-23 02:18:05 --> Model Class Initialized
INFO - 2017-12-23 02:18:05 --> Controller Class Initialized
INFO - 2017-12-23 02:18:05 --> Model Class Initialized
INFO - 2017-12-23 02:18:05 --> Model Class Initialized
INFO - 2017-12-23 02:18:05 --> Model Class Initialized
DEBUG - 2017-12-23 02:18:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 02:18:05 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-23 02:18:05 --> Final output sent to browser
DEBUG - 2017-12-23 02:18:05 --> Total execution time: 0.0948
INFO - 2017-12-23 02:18:06 --> Config Class Initialized
INFO - 2017-12-23 02:18:06 --> Hooks Class Initialized
DEBUG - 2017-12-23 02:18:06 --> UTF-8 Support Enabled
INFO - 2017-12-23 02:18:06 --> Utf8 Class Initialized
INFO - 2017-12-23 02:18:06 --> URI Class Initialized
INFO - 2017-12-23 02:18:06 --> Router Class Initialized
INFO - 2017-12-23 02:18:06 --> Output Class Initialized
INFO - 2017-12-23 02:18:06 --> Security Class Initialized
DEBUG - 2017-12-23 02:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 02:18:06 --> Input Class Initialized
INFO - 2017-12-23 02:18:06 --> Language Class Initialized
INFO - 2017-12-23 02:18:07 --> Loader Class Initialized
INFO - 2017-12-23 02:18:07 --> Helper loaded: url_helper
INFO - 2017-12-23 02:18:07 --> Helper loaded: form_helper
INFO - 2017-12-23 02:18:07 --> Database Driver Class Initialized
DEBUG - 2017-12-23 02:18:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 02:18:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 02:18:07 --> Form Validation Class Initialized
INFO - 2017-12-23 02:18:07 --> Model Class Initialized
INFO - 2017-12-23 02:18:07 --> Controller Class Initialized
INFO - 2017-12-23 02:18:07 --> Model Class Initialized
INFO - 2017-12-23 02:18:07 --> Model Class Initialized
INFO - 2017-12-23 02:18:07 --> Model Class Initialized
DEBUG - 2017-12-23 02:18:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 02:18:07 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-23 02:18:07 --> Final output sent to browser
DEBUG - 2017-12-23 02:18:07 --> Total execution time: 0.0541
INFO - 2017-12-23 02:18:09 --> Config Class Initialized
INFO - 2017-12-23 02:18:09 --> Hooks Class Initialized
DEBUG - 2017-12-23 02:18:09 --> UTF-8 Support Enabled
INFO - 2017-12-23 02:18:09 --> Utf8 Class Initialized
INFO - 2017-12-23 02:18:09 --> URI Class Initialized
INFO - 2017-12-23 02:18:09 --> Router Class Initialized
INFO - 2017-12-23 02:18:09 --> Output Class Initialized
INFO - 2017-12-23 02:18:09 --> Security Class Initialized
DEBUG - 2017-12-23 02:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 02:18:09 --> Input Class Initialized
INFO - 2017-12-23 02:18:09 --> Language Class Initialized
INFO - 2017-12-23 02:18:09 --> Loader Class Initialized
INFO - 2017-12-23 02:18:09 --> Helper loaded: url_helper
INFO - 2017-12-23 02:18:09 --> Helper loaded: form_helper
INFO - 2017-12-23 02:18:09 --> Database Driver Class Initialized
DEBUG - 2017-12-23 02:18:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 02:18:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 02:18:09 --> Form Validation Class Initialized
INFO - 2017-12-23 02:18:09 --> Model Class Initialized
INFO - 2017-12-23 02:18:09 --> Controller Class Initialized
INFO - 2017-12-23 02:18:09 --> Model Class Initialized
INFO - 2017-12-23 02:18:09 --> Model Class Initialized
INFO - 2017-12-23 02:18:09 --> Model Class Initialized
DEBUG - 2017-12-23 02:18:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 02:18:09 --> Config Class Initialized
INFO - 2017-12-23 02:18:09 --> Hooks Class Initialized
DEBUG - 2017-12-23 02:18:09 --> UTF-8 Support Enabled
INFO - 2017-12-23 02:18:09 --> Utf8 Class Initialized
INFO - 2017-12-23 02:18:09 --> URI Class Initialized
INFO - 2017-12-23 02:18:09 --> Router Class Initialized
INFO - 2017-12-23 02:18:09 --> Output Class Initialized
INFO - 2017-12-23 02:18:09 --> Security Class Initialized
DEBUG - 2017-12-23 02:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 02:18:09 --> Input Class Initialized
INFO - 2017-12-23 02:18:09 --> Language Class Initialized
INFO - 2017-12-23 02:18:09 --> Loader Class Initialized
INFO - 2017-12-23 02:18:09 --> Helper loaded: url_helper
INFO - 2017-12-23 02:18:09 --> Helper loaded: form_helper
INFO - 2017-12-23 02:18:09 --> Database Driver Class Initialized
DEBUG - 2017-12-23 02:18:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 02:18:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 02:18:09 --> Form Validation Class Initialized
INFO - 2017-12-23 02:18:09 --> Model Class Initialized
INFO - 2017-12-23 02:18:09 --> Controller Class Initialized
INFO - 2017-12-23 02:18:09 --> Model Class Initialized
INFO - 2017-12-23 02:18:09 --> Model Class Initialized
INFO - 2017-12-23 02:18:09 --> Model Class Initialized
DEBUG - 2017-12-23 02:18:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 02:18:09 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-23 02:18:09 --> Final output sent to browser
DEBUG - 2017-12-23 02:18:09 --> Total execution time: 0.0866
INFO - 2017-12-23 02:18:11 --> Config Class Initialized
INFO - 2017-12-23 02:18:11 --> Hooks Class Initialized
DEBUG - 2017-12-23 02:18:11 --> UTF-8 Support Enabled
INFO - 2017-12-23 02:18:11 --> Utf8 Class Initialized
INFO - 2017-12-23 02:18:11 --> URI Class Initialized
INFO - 2017-12-23 02:18:11 --> Router Class Initialized
INFO - 2017-12-23 02:18:11 --> Output Class Initialized
INFO - 2017-12-23 02:18:11 --> Security Class Initialized
DEBUG - 2017-12-23 02:18:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 02:18:11 --> Input Class Initialized
INFO - 2017-12-23 02:18:11 --> Language Class Initialized
INFO - 2017-12-23 02:18:11 --> Loader Class Initialized
INFO - 2017-12-23 02:18:11 --> Helper loaded: url_helper
INFO - 2017-12-23 02:18:11 --> Helper loaded: form_helper
INFO - 2017-12-23 02:18:11 --> Database Driver Class Initialized
DEBUG - 2017-12-23 02:18:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 02:18:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 02:18:11 --> Form Validation Class Initialized
INFO - 2017-12-23 02:18:11 --> Model Class Initialized
INFO - 2017-12-23 02:18:11 --> Controller Class Initialized
INFO - 2017-12-23 02:18:11 --> Model Class Initialized
INFO - 2017-12-23 02:18:11 --> Model Class Initialized
INFO - 2017-12-23 02:18:11 --> Model Class Initialized
DEBUG - 2017-12-23 02:18:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 02:18:11 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-23 02:18:11 --> Final output sent to browser
DEBUG - 2017-12-23 02:18:11 --> Total execution time: 0.0740
INFO - 2017-12-23 02:18:14 --> Config Class Initialized
INFO - 2017-12-23 02:18:14 --> Hooks Class Initialized
DEBUG - 2017-12-23 02:18:14 --> UTF-8 Support Enabled
INFO - 2017-12-23 02:18:14 --> Utf8 Class Initialized
INFO - 2017-12-23 02:18:14 --> URI Class Initialized
INFO - 2017-12-23 02:18:14 --> Router Class Initialized
INFO - 2017-12-23 02:18:14 --> Output Class Initialized
INFO - 2017-12-23 02:18:14 --> Security Class Initialized
DEBUG - 2017-12-23 02:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 02:18:14 --> Input Class Initialized
INFO - 2017-12-23 02:18:14 --> Language Class Initialized
INFO - 2017-12-23 02:18:14 --> Loader Class Initialized
INFO - 2017-12-23 02:18:14 --> Helper loaded: url_helper
INFO - 2017-12-23 02:18:14 --> Helper loaded: form_helper
INFO - 2017-12-23 02:18:14 --> Database Driver Class Initialized
DEBUG - 2017-12-23 02:18:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 02:18:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 02:18:14 --> Form Validation Class Initialized
INFO - 2017-12-23 02:18:14 --> Model Class Initialized
INFO - 2017-12-23 02:18:14 --> Controller Class Initialized
INFO - 2017-12-23 02:18:14 --> Model Class Initialized
INFO - 2017-12-23 02:18:14 --> Model Class Initialized
INFO - 2017-12-23 02:18:14 --> Model Class Initialized
DEBUG - 2017-12-23 02:18:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 02:18:14 --> Config Class Initialized
INFO - 2017-12-23 02:18:14 --> Hooks Class Initialized
DEBUG - 2017-12-23 02:18:14 --> UTF-8 Support Enabled
INFO - 2017-12-23 02:18:14 --> Utf8 Class Initialized
INFO - 2017-12-23 02:18:14 --> URI Class Initialized
INFO - 2017-12-23 02:18:14 --> Router Class Initialized
INFO - 2017-12-23 02:18:14 --> Output Class Initialized
INFO - 2017-12-23 02:18:14 --> Security Class Initialized
DEBUG - 2017-12-23 02:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 02:18:14 --> Input Class Initialized
INFO - 2017-12-23 02:18:14 --> Language Class Initialized
INFO - 2017-12-23 02:18:14 --> Loader Class Initialized
INFO - 2017-12-23 02:18:14 --> Helper loaded: url_helper
INFO - 2017-12-23 02:18:14 --> Helper loaded: form_helper
INFO - 2017-12-23 02:18:14 --> Database Driver Class Initialized
DEBUG - 2017-12-23 02:18:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 02:18:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 02:18:14 --> Form Validation Class Initialized
INFO - 2017-12-23 02:18:14 --> Model Class Initialized
INFO - 2017-12-23 02:18:14 --> Controller Class Initialized
INFO - 2017-12-23 02:18:14 --> Model Class Initialized
INFO - 2017-12-23 02:18:14 --> Model Class Initialized
INFO - 2017-12-23 02:18:14 --> Model Class Initialized
DEBUG - 2017-12-23 02:18:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 02:18:14 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-23 02:18:14 --> Final output sent to browser
DEBUG - 2017-12-23 02:18:14 --> Total execution time: 0.0535
INFO - 2017-12-23 02:18:15 --> Config Class Initialized
INFO - 2017-12-23 02:18:15 --> Hooks Class Initialized
DEBUG - 2017-12-23 02:18:15 --> UTF-8 Support Enabled
INFO - 2017-12-23 02:18:15 --> Utf8 Class Initialized
INFO - 2017-12-23 02:18:15 --> URI Class Initialized
INFO - 2017-12-23 02:18:15 --> Router Class Initialized
INFO - 2017-12-23 02:18:15 --> Output Class Initialized
INFO - 2017-12-23 02:18:15 --> Security Class Initialized
DEBUG - 2017-12-23 02:18:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 02:18:15 --> Input Class Initialized
INFO - 2017-12-23 02:18:15 --> Language Class Initialized
INFO - 2017-12-23 02:18:15 --> Loader Class Initialized
INFO - 2017-12-23 02:18:15 --> Helper loaded: url_helper
INFO - 2017-12-23 02:18:15 --> Helper loaded: form_helper
INFO - 2017-12-23 02:18:15 --> Database Driver Class Initialized
DEBUG - 2017-12-23 02:18:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 02:18:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 02:18:15 --> Form Validation Class Initialized
INFO - 2017-12-23 02:18:15 --> Model Class Initialized
INFO - 2017-12-23 02:18:15 --> Controller Class Initialized
INFO - 2017-12-23 02:18:15 --> Model Class Initialized
INFO - 2017-12-23 02:18:15 --> Model Class Initialized
INFO - 2017-12-23 02:18:15 --> Model Class Initialized
DEBUG - 2017-12-23 02:18:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 02:18:15 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-23 02:18:15 --> Final output sent to browser
DEBUG - 2017-12-23 02:18:15 --> Total execution time: 0.0650
INFO - 2017-12-23 02:18:20 --> Config Class Initialized
INFO - 2017-12-23 02:18:20 --> Hooks Class Initialized
DEBUG - 2017-12-23 02:18:20 --> UTF-8 Support Enabled
INFO - 2017-12-23 02:18:20 --> Utf8 Class Initialized
INFO - 2017-12-23 02:18:20 --> URI Class Initialized
INFO - 2017-12-23 02:18:20 --> Router Class Initialized
INFO - 2017-12-23 02:18:20 --> Output Class Initialized
INFO - 2017-12-23 02:18:20 --> Security Class Initialized
DEBUG - 2017-12-23 02:18:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 02:18:20 --> Input Class Initialized
INFO - 2017-12-23 02:18:20 --> Language Class Initialized
INFO - 2017-12-23 02:18:20 --> Loader Class Initialized
INFO - 2017-12-23 02:18:20 --> Helper loaded: url_helper
INFO - 2017-12-23 02:18:20 --> Helper loaded: form_helper
INFO - 2017-12-23 02:18:20 --> Database Driver Class Initialized
DEBUG - 2017-12-23 02:18:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 02:18:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 02:18:20 --> Form Validation Class Initialized
INFO - 2017-12-23 02:18:20 --> Model Class Initialized
INFO - 2017-12-23 02:18:20 --> Controller Class Initialized
INFO - 2017-12-23 02:18:20 --> Model Class Initialized
INFO - 2017-12-23 02:18:20 --> Model Class Initialized
INFO - 2017-12-23 02:18:20 --> Model Class Initialized
DEBUG - 2017-12-23 02:18:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 02:18:20 --> Config Class Initialized
INFO - 2017-12-23 02:18:20 --> Hooks Class Initialized
DEBUG - 2017-12-23 02:18:20 --> UTF-8 Support Enabled
INFO - 2017-12-23 02:18:20 --> Utf8 Class Initialized
INFO - 2017-12-23 02:18:20 --> URI Class Initialized
INFO - 2017-12-23 02:18:20 --> Router Class Initialized
INFO - 2017-12-23 02:18:20 --> Output Class Initialized
INFO - 2017-12-23 02:18:20 --> Security Class Initialized
DEBUG - 2017-12-23 02:18:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 02:18:20 --> Input Class Initialized
INFO - 2017-12-23 02:18:20 --> Language Class Initialized
INFO - 2017-12-23 02:18:20 --> Loader Class Initialized
INFO - 2017-12-23 02:18:20 --> Helper loaded: url_helper
INFO - 2017-12-23 02:18:20 --> Helper loaded: form_helper
INFO - 2017-12-23 02:18:20 --> Database Driver Class Initialized
DEBUG - 2017-12-23 02:18:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 02:18:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 02:18:20 --> Form Validation Class Initialized
INFO - 2017-12-23 02:18:20 --> Model Class Initialized
INFO - 2017-12-23 02:18:20 --> Controller Class Initialized
INFO - 2017-12-23 02:18:20 --> Model Class Initialized
INFO - 2017-12-23 02:18:20 --> Model Class Initialized
INFO - 2017-12-23 02:18:20 --> Model Class Initialized
DEBUG - 2017-12-23 02:18:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 02:18:20 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-23 02:18:20 --> Final output sent to browser
DEBUG - 2017-12-23 02:18:20 --> Total execution time: 0.1069
INFO - 2017-12-23 02:18:21 --> Config Class Initialized
INFO - 2017-12-23 02:18:21 --> Hooks Class Initialized
DEBUG - 2017-12-23 02:18:21 --> UTF-8 Support Enabled
INFO - 2017-12-23 02:18:21 --> Utf8 Class Initialized
INFO - 2017-12-23 02:18:21 --> URI Class Initialized
INFO - 2017-12-23 02:18:21 --> Router Class Initialized
INFO - 2017-12-23 02:18:21 --> Output Class Initialized
INFO - 2017-12-23 02:18:21 --> Security Class Initialized
DEBUG - 2017-12-23 02:18:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 02:18:21 --> Input Class Initialized
INFO - 2017-12-23 02:18:21 --> Language Class Initialized
INFO - 2017-12-23 02:18:21 --> Loader Class Initialized
INFO - 2017-12-23 02:18:21 --> Helper loaded: url_helper
INFO - 2017-12-23 02:18:21 --> Helper loaded: form_helper
INFO - 2017-12-23 02:18:21 --> Database Driver Class Initialized
DEBUG - 2017-12-23 02:18:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 02:18:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 02:18:21 --> Form Validation Class Initialized
INFO - 2017-12-23 02:18:21 --> Model Class Initialized
INFO - 2017-12-23 02:18:21 --> Controller Class Initialized
INFO - 2017-12-23 02:18:21 --> Model Class Initialized
INFO - 2017-12-23 02:18:21 --> Model Class Initialized
INFO - 2017-12-23 02:18:21 --> Model Class Initialized
DEBUG - 2017-12-23 02:18:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 02:18:21 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-23 02:18:21 --> Final output sent to browser
DEBUG - 2017-12-23 02:18:21 --> Total execution time: 0.0538
INFO - 2017-12-23 02:18:24 --> Config Class Initialized
INFO - 2017-12-23 02:18:24 --> Hooks Class Initialized
DEBUG - 2017-12-23 02:18:24 --> UTF-8 Support Enabled
INFO - 2017-12-23 02:18:24 --> Utf8 Class Initialized
INFO - 2017-12-23 02:18:24 --> URI Class Initialized
INFO - 2017-12-23 02:18:24 --> Router Class Initialized
INFO - 2017-12-23 02:18:24 --> Output Class Initialized
INFO - 2017-12-23 02:18:24 --> Security Class Initialized
DEBUG - 2017-12-23 02:18:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 02:18:24 --> Input Class Initialized
INFO - 2017-12-23 02:18:24 --> Language Class Initialized
INFO - 2017-12-23 02:18:24 --> Loader Class Initialized
INFO - 2017-12-23 02:18:24 --> Helper loaded: url_helper
INFO - 2017-12-23 02:18:24 --> Helper loaded: form_helper
INFO - 2017-12-23 02:18:24 --> Database Driver Class Initialized
DEBUG - 2017-12-23 02:18:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 02:18:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 02:18:24 --> Form Validation Class Initialized
INFO - 2017-12-23 02:18:24 --> Model Class Initialized
INFO - 2017-12-23 02:18:24 --> Controller Class Initialized
INFO - 2017-12-23 02:18:24 --> Model Class Initialized
INFO - 2017-12-23 02:18:24 --> Model Class Initialized
INFO - 2017-12-23 02:18:24 --> Model Class Initialized
DEBUG - 2017-12-23 02:18:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 02:18:24 --> Config Class Initialized
INFO - 2017-12-23 02:18:24 --> Hooks Class Initialized
DEBUG - 2017-12-23 02:18:24 --> UTF-8 Support Enabled
INFO - 2017-12-23 02:18:24 --> Utf8 Class Initialized
INFO - 2017-12-23 02:18:24 --> URI Class Initialized
INFO - 2017-12-23 02:18:24 --> Router Class Initialized
INFO - 2017-12-23 02:18:24 --> Output Class Initialized
INFO - 2017-12-23 02:18:24 --> Security Class Initialized
DEBUG - 2017-12-23 02:18:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 02:18:24 --> Input Class Initialized
INFO - 2017-12-23 02:18:24 --> Language Class Initialized
INFO - 2017-12-23 02:18:24 --> Loader Class Initialized
INFO - 2017-12-23 02:18:24 --> Helper loaded: url_helper
INFO - 2017-12-23 02:18:24 --> Helper loaded: form_helper
INFO - 2017-12-23 02:18:24 --> Database Driver Class Initialized
DEBUG - 2017-12-23 02:18:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 02:18:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 02:18:24 --> Form Validation Class Initialized
INFO - 2017-12-23 02:18:24 --> Model Class Initialized
INFO - 2017-12-23 02:18:24 --> Controller Class Initialized
INFO - 2017-12-23 02:18:24 --> Model Class Initialized
INFO - 2017-12-23 02:18:24 --> Model Class Initialized
INFO - 2017-12-23 02:18:24 --> Model Class Initialized
DEBUG - 2017-12-23 02:18:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 02:18:24 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-23 02:18:24 --> Final output sent to browser
DEBUG - 2017-12-23 02:18:24 --> Total execution time: 0.0975
INFO - 2017-12-23 02:18:34 --> Config Class Initialized
INFO - 2017-12-23 02:18:34 --> Hooks Class Initialized
DEBUG - 2017-12-23 02:18:34 --> UTF-8 Support Enabled
INFO - 2017-12-23 02:18:34 --> Utf8 Class Initialized
INFO - 2017-12-23 02:18:34 --> URI Class Initialized
INFO - 2017-12-23 02:18:34 --> Router Class Initialized
INFO - 2017-12-23 02:18:34 --> Output Class Initialized
INFO - 2017-12-23 02:18:34 --> Security Class Initialized
DEBUG - 2017-12-23 02:18:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 02:18:34 --> Input Class Initialized
INFO - 2017-12-23 02:18:34 --> Language Class Initialized
INFO - 2017-12-23 02:18:34 --> Loader Class Initialized
INFO - 2017-12-23 02:18:34 --> Helper loaded: url_helper
INFO - 2017-12-23 02:18:34 --> Helper loaded: form_helper
INFO - 2017-12-23 02:18:34 --> Database Driver Class Initialized
DEBUG - 2017-12-23 02:18:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 02:18:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 02:18:34 --> Form Validation Class Initialized
INFO - 2017-12-23 02:18:34 --> Model Class Initialized
INFO - 2017-12-23 02:18:34 --> Controller Class Initialized
INFO - 2017-12-23 02:18:34 --> Model Class Initialized
INFO - 2017-12-23 02:18:34 --> Model Class Initialized
INFO - 2017-12-23 02:18:34 --> Model Class Initialized
DEBUG - 2017-12-23 02:18:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 02:18:34 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-23 02:18:34 --> Final output sent to browser
DEBUG - 2017-12-23 02:18:34 --> Total execution time: 0.0561
INFO - 2017-12-23 02:18:34 --> Config Class Initialized
INFO - 2017-12-23 02:18:34 --> Hooks Class Initialized
DEBUG - 2017-12-23 02:18:34 --> UTF-8 Support Enabled
INFO - 2017-12-23 02:18:34 --> Utf8 Class Initialized
INFO - 2017-12-23 02:18:34 --> URI Class Initialized
INFO - 2017-12-23 02:18:34 --> Router Class Initialized
INFO - 2017-12-23 02:18:34 --> Output Class Initialized
INFO - 2017-12-23 02:18:34 --> Security Class Initialized
DEBUG - 2017-12-23 02:18:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 02:18:34 --> Input Class Initialized
INFO - 2017-12-23 02:18:34 --> Language Class Initialized
INFO - 2017-12-23 02:18:34 --> Loader Class Initialized
INFO - 2017-12-23 02:18:34 --> Helper loaded: url_helper
INFO - 2017-12-23 02:18:34 --> Helper loaded: form_helper
INFO - 2017-12-23 02:18:34 --> Database Driver Class Initialized
DEBUG - 2017-12-23 02:18:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 02:18:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 02:18:34 --> Form Validation Class Initialized
INFO - 2017-12-23 02:18:34 --> Model Class Initialized
INFO - 2017-12-23 02:18:34 --> Controller Class Initialized
INFO - 2017-12-23 02:18:34 --> Model Class Initialized
INFO - 2017-12-23 02:18:34 --> Model Class Initialized
INFO - 2017-12-23 02:18:34 --> Model Class Initialized
DEBUG - 2017-12-23 02:18:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 02:20:02 --> Config Class Initialized
INFO - 2017-12-23 02:20:02 --> Hooks Class Initialized
DEBUG - 2017-12-23 02:20:02 --> UTF-8 Support Enabled
INFO - 2017-12-23 02:20:02 --> Utf8 Class Initialized
INFO - 2017-12-23 02:20:02 --> URI Class Initialized
INFO - 2017-12-23 02:20:02 --> Router Class Initialized
INFO - 2017-12-23 02:20:02 --> Output Class Initialized
INFO - 2017-12-23 02:20:02 --> Security Class Initialized
DEBUG - 2017-12-23 02:20:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 02:20:02 --> Input Class Initialized
INFO - 2017-12-23 02:20:02 --> Language Class Initialized
INFO - 2017-12-23 02:20:02 --> Loader Class Initialized
INFO - 2017-12-23 02:20:02 --> Helper loaded: url_helper
INFO - 2017-12-23 02:20:02 --> Helper loaded: form_helper
INFO - 2017-12-23 02:20:02 --> Database Driver Class Initialized
DEBUG - 2017-12-23 02:20:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 02:20:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 02:20:02 --> Form Validation Class Initialized
INFO - 2017-12-23 02:20:02 --> Model Class Initialized
INFO - 2017-12-23 02:20:02 --> Controller Class Initialized
INFO - 2017-12-23 02:20:02 --> Model Class Initialized
INFO - 2017-12-23 02:20:02 --> Model Class Initialized
INFO - 2017-12-23 02:20:02 --> Model Class Initialized
DEBUG - 2017-12-23 02:20:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 02:20:02 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-23 02:20:02 --> Final output sent to browser
DEBUG - 2017-12-23 02:20:02 --> Total execution time: 0.0796
INFO - 2017-12-23 02:20:02 --> Config Class Initialized
INFO - 2017-12-23 02:20:02 --> Hooks Class Initialized
INFO - 2017-12-23 02:20:02 --> Config Class Initialized
INFO - 2017-12-23 02:20:02 --> Hooks Class Initialized
DEBUG - 2017-12-23 02:20:02 --> UTF-8 Support Enabled
DEBUG - 2017-12-23 02:20:02 --> UTF-8 Support Enabled
INFO - 2017-12-23 02:20:02 --> Utf8 Class Initialized
INFO - 2017-12-23 02:20:02 --> Utf8 Class Initialized
INFO - 2017-12-23 02:20:02 --> URI Class Initialized
INFO - 2017-12-23 02:20:02 --> URI Class Initialized
INFO - 2017-12-23 02:20:02 --> Router Class Initialized
INFO - 2017-12-23 02:20:02 --> Router Class Initialized
INFO - 2017-12-23 02:20:02 --> Output Class Initialized
INFO - 2017-12-23 02:20:02 --> Output Class Initialized
INFO - 2017-12-23 02:20:02 --> Security Class Initialized
DEBUG - 2017-12-23 02:20:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 02:20:02 --> Security Class Initialized
INFO - 2017-12-23 02:20:02 --> Input Class Initialized
INFO - 2017-12-23 02:20:02 --> Language Class Initialized
DEBUG - 2017-12-23 02:20:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 02:20:02 --> Input Class Initialized
INFO - 2017-12-23 02:20:02 --> Language Class Initialized
INFO - 2017-12-23 02:20:02 --> Loader Class Initialized
INFO - 2017-12-23 02:20:02 --> Loader Class Initialized
INFO - 2017-12-23 02:20:02 --> Helper loaded: url_helper
INFO - 2017-12-23 02:20:02 --> Helper loaded: url_helper
INFO - 2017-12-23 02:20:02 --> Helper loaded: form_helper
INFO - 2017-12-23 02:20:02 --> Helper loaded: form_helper
INFO - 2017-12-23 02:20:02 --> Database Driver Class Initialized
INFO - 2017-12-23 02:20:02 --> Database Driver Class Initialized
DEBUG - 2017-12-23 02:20:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 02:20:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2017-12-23 02:20:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 02:20:02 --> Form Validation Class Initialized
INFO - 2017-12-23 02:20:02 --> Model Class Initialized
INFO - 2017-12-23 02:20:02 --> Controller Class Initialized
INFO - 2017-12-23 02:20:02 --> Model Class Initialized
INFO - 2017-12-23 02:20:02 --> Model Class Initialized
INFO - 2017-12-23 02:20:02 --> Model Class Initialized
DEBUG - 2017-12-23 02:20:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 02:20:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 02:20:02 --> Form Validation Class Initialized
INFO - 2017-12-23 02:20:02 --> Model Class Initialized
INFO - 2017-12-23 02:20:02 --> Controller Class Initialized
INFO - 2017-12-23 02:20:02 --> Model Class Initialized
INFO - 2017-12-23 02:20:02 --> Model Class Initialized
INFO - 2017-12-23 02:20:02 --> Model Class Initialized
DEBUG - 2017-12-23 02:20:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 02:20:05 --> Config Class Initialized
INFO - 2017-12-23 02:20:05 --> Hooks Class Initialized
DEBUG - 2017-12-23 02:20:05 --> UTF-8 Support Enabled
INFO - 2017-12-23 02:20:05 --> Utf8 Class Initialized
INFO - 2017-12-23 02:20:05 --> URI Class Initialized
INFO - 2017-12-23 02:20:05 --> Router Class Initialized
INFO - 2017-12-23 02:20:05 --> Output Class Initialized
INFO - 2017-12-23 02:20:05 --> Security Class Initialized
DEBUG - 2017-12-23 02:20:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 02:20:05 --> Input Class Initialized
INFO - 2017-12-23 02:20:05 --> Language Class Initialized
INFO - 2017-12-23 02:20:05 --> Loader Class Initialized
INFO - 2017-12-23 02:20:05 --> Helper loaded: url_helper
INFO - 2017-12-23 02:20:05 --> Helper loaded: form_helper
INFO - 2017-12-23 02:20:05 --> Database Driver Class Initialized
DEBUG - 2017-12-23 02:20:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 02:20:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 02:20:05 --> Form Validation Class Initialized
INFO - 2017-12-23 02:20:05 --> Model Class Initialized
INFO - 2017-12-23 02:20:05 --> Controller Class Initialized
INFO - 2017-12-23 02:20:05 --> Model Class Initialized
INFO - 2017-12-23 02:20:05 --> Model Class Initialized
INFO - 2017-12-23 02:20:05 --> Model Class Initialized
DEBUG - 2017-12-23 02:20:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 02:20:05 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-23 02:20:05 --> Final output sent to browser
DEBUG - 2017-12-23 02:20:05 --> Total execution time: 0.0648
INFO - 2017-12-23 02:20:05 --> Config Class Initialized
INFO - 2017-12-23 02:20:05 --> Hooks Class Initialized
DEBUG - 2017-12-23 02:20:05 --> UTF-8 Support Enabled
INFO - 2017-12-23 02:20:05 --> Utf8 Class Initialized
INFO - 2017-12-23 02:20:05 --> URI Class Initialized
INFO - 2017-12-23 02:20:05 --> Router Class Initialized
INFO - 2017-12-23 02:20:05 --> Output Class Initialized
INFO - 2017-12-23 02:20:05 --> Security Class Initialized
DEBUG - 2017-12-23 02:20:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 02:20:05 --> Input Class Initialized
INFO - 2017-12-23 02:20:05 --> Language Class Initialized
INFO - 2017-12-23 02:20:05 --> Loader Class Initialized
INFO - 2017-12-23 02:20:05 --> Helper loaded: url_helper
INFO - 2017-12-23 02:20:05 --> Helper loaded: form_helper
INFO - 2017-12-23 02:20:05 --> Database Driver Class Initialized
DEBUG - 2017-12-23 02:20:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 02:20:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 02:20:05 --> Form Validation Class Initialized
INFO - 2017-12-23 02:20:05 --> Model Class Initialized
INFO - 2017-12-23 02:20:05 --> Controller Class Initialized
INFO - 2017-12-23 02:20:05 --> Model Class Initialized
INFO - 2017-12-23 02:20:05 --> Model Class Initialized
INFO - 2017-12-23 02:20:05 --> Model Class Initialized
DEBUG - 2017-12-23 02:20:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 02:20:25 --> Config Class Initialized
INFO - 2017-12-23 02:20:25 --> Hooks Class Initialized
DEBUG - 2017-12-23 02:20:25 --> UTF-8 Support Enabled
INFO - 2017-12-23 02:20:25 --> Utf8 Class Initialized
INFO - 2017-12-23 02:20:25 --> URI Class Initialized
INFO - 2017-12-23 02:20:25 --> Router Class Initialized
INFO - 2017-12-23 02:20:25 --> Output Class Initialized
INFO - 2017-12-23 02:20:25 --> Security Class Initialized
DEBUG - 2017-12-23 02:20:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 02:20:25 --> Input Class Initialized
INFO - 2017-12-23 02:20:25 --> Language Class Initialized
INFO - 2017-12-23 02:20:25 --> Loader Class Initialized
INFO - 2017-12-23 02:20:25 --> Helper loaded: url_helper
INFO - 2017-12-23 02:20:25 --> Helper loaded: form_helper
INFO - 2017-12-23 02:20:25 --> Database Driver Class Initialized
DEBUG - 2017-12-23 02:20:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 02:20:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 02:20:25 --> Form Validation Class Initialized
INFO - 2017-12-23 02:20:25 --> Model Class Initialized
INFO - 2017-12-23 02:20:25 --> Controller Class Initialized
INFO - 2017-12-23 02:20:25 --> Model Class Initialized
INFO - 2017-12-23 02:20:25 --> Model Class Initialized
INFO - 2017-12-23 02:20:25 --> Model Class Initialized
DEBUG - 2017-12-23 02:20:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 02:20:25 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-23 02:20:25 --> Final output sent to browser
DEBUG - 2017-12-23 02:20:25 --> Total execution time: 0.0962
INFO - 2017-12-23 02:20:25 --> Config Class Initialized
INFO - 2017-12-23 02:20:25 --> Hooks Class Initialized
DEBUG - 2017-12-23 02:20:25 --> UTF-8 Support Enabled
INFO - 2017-12-23 02:20:25 --> Utf8 Class Initialized
INFO - 2017-12-23 02:20:25 --> URI Class Initialized
INFO - 2017-12-23 02:20:25 --> Router Class Initialized
INFO - 2017-12-23 02:20:25 --> Output Class Initialized
INFO - 2017-12-23 02:20:25 --> Security Class Initialized
DEBUG - 2017-12-23 02:20:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 02:20:25 --> Input Class Initialized
INFO - 2017-12-23 02:20:25 --> Language Class Initialized
INFO - 2017-12-23 02:20:25 --> Loader Class Initialized
INFO - 2017-12-23 02:20:25 --> Helper loaded: url_helper
INFO - 2017-12-23 02:20:25 --> Helper loaded: form_helper
INFO - 2017-12-23 02:20:25 --> Database Driver Class Initialized
DEBUG - 2017-12-23 02:20:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 02:20:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 02:20:25 --> Form Validation Class Initialized
INFO - 2017-12-23 02:20:25 --> Model Class Initialized
INFO - 2017-12-23 02:20:25 --> Controller Class Initialized
INFO - 2017-12-23 02:20:25 --> Model Class Initialized
INFO - 2017-12-23 02:20:25 --> Model Class Initialized
INFO - 2017-12-23 02:20:25 --> Model Class Initialized
DEBUG - 2017-12-23 02:20:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 02:20:26 --> Config Class Initialized
INFO - 2017-12-23 02:20:26 --> Hooks Class Initialized
DEBUG - 2017-12-23 02:20:26 --> UTF-8 Support Enabled
INFO - 2017-12-23 02:20:26 --> Utf8 Class Initialized
INFO - 2017-12-23 02:20:26 --> URI Class Initialized
INFO - 2017-12-23 02:20:26 --> Router Class Initialized
INFO - 2017-12-23 02:20:26 --> Output Class Initialized
INFO - 2017-12-23 02:20:26 --> Security Class Initialized
DEBUG - 2017-12-23 02:20:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 02:20:26 --> Input Class Initialized
INFO - 2017-12-23 02:20:26 --> Language Class Initialized
INFO - 2017-12-23 02:20:26 --> Loader Class Initialized
INFO - 2017-12-23 02:20:26 --> Helper loaded: url_helper
INFO - 2017-12-23 02:20:26 --> Helper loaded: form_helper
INFO - 2017-12-23 02:20:26 --> Database Driver Class Initialized
DEBUG - 2017-12-23 02:20:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 02:20:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 02:20:26 --> Form Validation Class Initialized
INFO - 2017-12-23 02:20:26 --> Model Class Initialized
INFO - 2017-12-23 02:20:26 --> Controller Class Initialized
INFO - 2017-12-23 02:20:26 --> Model Class Initialized
INFO - 2017-12-23 02:20:26 --> Model Class Initialized
INFO - 2017-12-23 02:20:26 --> Model Class Initialized
DEBUG - 2017-12-23 02:20:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 02:20:26 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-23 02:20:26 --> Final output sent to browser
DEBUG - 2017-12-23 02:20:26 --> Total execution time: 0.0722
INFO - 2017-12-23 02:20:26 --> Config Class Initialized
INFO - 2017-12-23 02:20:26 --> Hooks Class Initialized
INFO - 2017-12-23 02:20:26 --> Config Class Initialized
INFO - 2017-12-23 02:20:26 --> Hooks Class Initialized
DEBUG - 2017-12-23 02:20:26 --> UTF-8 Support Enabled
DEBUG - 2017-12-23 02:20:26 --> UTF-8 Support Enabled
INFO - 2017-12-23 02:20:26 --> Utf8 Class Initialized
INFO - 2017-12-23 02:20:26 --> Utf8 Class Initialized
INFO - 2017-12-23 02:20:26 --> URI Class Initialized
INFO - 2017-12-23 02:20:26 --> URI Class Initialized
INFO - 2017-12-23 02:20:26 --> Router Class Initialized
INFO - 2017-12-23 02:20:26 --> Router Class Initialized
INFO - 2017-12-23 02:20:26 --> Output Class Initialized
INFO - 2017-12-23 02:20:26 --> Output Class Initialized
INFO - 2017-12-23 02:20:26 --> Security Class Initialized
INFO - 2017-12-23 02:20:26 --> Security Class Initialized
DEBUG - 2017-12-23 02:20:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-23 02:20:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 02:20:26 --> Input Class Initialized
INFO - 2017-12-23 02:20:26 --> Input Class Initialized
INFO - 2017-12-23 02:20:26 --> Language Class Initialized
INFO - 2017-12-23 02:20:26 --> Language Class Initialized
INFO - 2017-12-23 02:20:26 --> Loader Class Initialized
INFO - 2017-12-23 02:20:26 --> Loader Class Initialized
INFO - 2017-12-23 02:20:26 --> Helper loaded: url_helper
INFO - 2017-12-23 02:20:26 --> Helper loaded: url_helper
INFO - 2017-12-23 02:20:26 --> Helper loaded: form_helper
INFO - 2017-12-23 02:20:26 --> Helper loaded: form_helper
INFO - 2017-12-23 02:20:26 --> Database Driver Class Initialized
INFO - 2017-12-23 02:20:26 --> Database Driver Class Initialized
DEBUG - 2017-12-23 02:20:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2017-12-23 02:20:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 02:20:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 02:20:26 --> Form Validation Class Initialized
INFO - 2017-12-23 02:20:26 --> Model Class Initialized
INFO - 2017-12-23 02:20:26 --> Controller Class Initialized
INFO - 2017-12-23 02:20:26 --> Model Class Initialized
INFO - 2017-12-23 02:20:26 --> Model Class Initialized
INFO - 2017-12-23 02:20:26 --> Model Class Initialized
DEBUG - 2017-12-23 02:20:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 02:20:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 02:20:26 --> Form Validation Class Initialized
INFO - 2017-12-23 02:20:26 --> Model Class Initialized
INFO - 2017-12-23 02:20:26 --> Controller Class Initialized
INFO - 2017-12-23 02:20:26 --> Model Class Initialized
INFO - 2017-12-23 02:20:26 --> Model Class Initialized
INFO - 2017-12-23 02:20:26 --> Model Class Initialized
DEBUG - 2017-12-23 02:20:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 02:20:29 --> Config Class Initialized
INFO - 2017-12-23 02:20:29 --> Hooks Class Initialized
DEBUG - 2017-12-23 02:20:29 --> UTF-8 Support Enabled
INFO - 2017-12-23 02:20:29 --> Utf8 Class Initialized
INFO - 2017-12-23 02:20:29 --> URI Class Initialized
INFO - 2017-12-23 02:20:29 --> Router Class Initialized
INFO - 2017-12-23 02:20:29 --> Output Class Initialized
INFO - 2017-12-23 02:20:29 --> Security Class Initialized
DEBUG - 2017-12-23 02:20:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 02:20:29 --> Input Class Initialized
INFO - 2017-12-23 02:20:29 --> Language Class Initialized
INFO - 2017-12-23 02:20:29 --> Loader Class Initialized
INFO - 2017-12-23 02:20:29 --> Helper loaded: url_helper
INFO - 2017-12-23 02:20:29 --> Helper loaded: form_helper
INFO - 2017-12-23 02:20:29 --> Database Driver Class Initialized
DEBUG - 2017-12-23 02:20:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 02:20:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 02:20:29 --> Form Validation Class Initialized
INFO - 2017-12-23 02:20:29 --> Model Class Initialized
INFO - 2017-12-23 02:20:29 --> Controller Class Initialized
INFO - 2017-12-23 02:20:29 --> Model Class Initialized
INFO - 2017-12-23 02:20:29 --> Model Class Initialized
INFO - 2017-12-23 02:20:29 --> Model Class Initialized
DEBUG - 2017-12-23 02:20:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 02:20:29 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-23 02:20:29 --> Final output sent to browser
DEBUG - 2017-12-23 02:20:29 --> Total execution time: 0.1265
INFO - 2017-12-23 02:20:29 --> Config Class Initialized
INFO - 2017-12-23 02:20:29 --> Hooks Class Initialized
DEBUG - 2017-12-23 02:20:29 --> UTF-8 Support Enabled
INFO - 2017-12-23 02:20:29 --> Utf8 Class Initialized
INFO - 2017-12-23 02:20:29 --> URI Class Initialized
INFO - 2017-12-23 02:20:29 --> Router Class Initialized
INFO - 2017-12-23 02:20:29 --> Output Class Initialized
INFO - 2017-12-23 02:20:29 --> Security Class Initialized
DEBUG - 2017-12-23 02:20:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 02:20:29 --> Input Class Initialized
INFO - 2017-12-23 02:20:29 --> Language Class Initialized
INFO - 2017-12-23 02:20:29 --> Loader Class Initialized
INFO - 2017-12-23 02:20:29 --> Helper loaded: url_helper
INFO - 2017-12-23 02:20:29 --> Helper loaded: form_helper
INFO - 2017-12-23 02:20:29 --> Database Driver Class Initialized
DEBUG - 2017-12-23 02:20:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 02:20:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 02:20:29 --> Form Validation Class Initialized
INFO - 2017-12-23 02:20:29 --> Model Class Initialized
INFO - 2017-12-23 02:20:29 --> Controller Class Initialized
INFO - 2017-12-23 02:20:29 --> Model Class Initialized
INFO - 2017-12-23 02:20:29 --> Model Class Initialized
INFO - 2017-12-23 02:20:29 --> Model Class Initialized
DEBUG - 2017-12-23 02:20:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 02:20:35 --> Config Class Initialized
INFO - 2017-12-23 02:20:35 --> Hooks Class Initialized
DEBUG - 2017-12-23 02:20:35 --> UTF-8 Support Enabled
INFO - 2017-12-23 02:20:35 --> Utf8 Class Initialized
INFO - 2017-12-23 02:20:35 --> URI Class Initialized
INFO - 2017-12-23 02:20:35 --> Router Class Initialized
INFO - 2017-12-23 02:20:35 --> Output Class Initialized
INFO - 2017-12-23 02:20:35 --> Security Class Initialized
DEBUG - 2017-12-23 02:20:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 02:20:35 --> Input Class Initialized
INFO - 2017-12-23 02:20:35 --> Language Class Initialized
INFO - 2017-12-23 02:20:35 --> Loader Class Initialized
INFO - 2017-12-23 02:20:35 --> Helper loaded: url_helper
INFO - 2017-12-23 02:20:35 --> Helper loaded: form_helper
INFO - 2017-12-23 02:20:35 --> Database Driver Class Initialized
DEBUG - 2017-12-23 02:20:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 02:20:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 02:20:35 --> Form Validation Class Initialized
INFO - 2017-12-23 02:20:35 --> Model Class Initialized
INFO - 2017-12-23 02:20:35 --> Controller Class Initialized
INFO - 2017-12-23 02:20:35 --> Model Class Initialized
INFO - 2017-12-23 02:20:35 --> Model Class Initialized
INFO - 2017-12-23 02:20:35 --> Model Class Initialized
DEBUG - 2017-12-23 02:20:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 02:20:35 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-23 02:20:35 --> Final output sent to browser
DEBUG - 2017-12-23 02:20:35 --> Total execution time: 0.0641
INFO - 2017-12-23 02:20:36 --> Config Class Initialized
INFO - 2017-12-23 02:20:36 --> Hooks Class Initialized
DEBUG - 2017-12-23 02:20:36 --> UTF-8 Support Enabled
INFO - 2017-12-23 02:20:36 --> Utf8 Class Initialized
INFO - 2017-12-23 02:20:36 --> URI Class Initialized
INFO - 2017-12-23 02:20:36 --> Router Class Initialized
INFO - 2017-12-23 02:20:36 --> Output Class Initialized
INFO - 2017-12-23 02:20:36 --> Security Class Initialized
DEBUG - 2017-12-23 02:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 02:20:36 --> Input Class Initialized
INFO - 2017-12-23 02:20:36 --> Language Class Initialized
INFO - 2017-12-23 02:20:36 --> Loader Class Initialized
INFO - 2017-12-23 02:20:36 --> Helper loaded: url_helper
INFO - 2017-12-23 02:20:36 --> Helper loaded: form_helper
INFO - 2017-12-23 02:20:36 --> Database Driver Class Initialized
DEBUG - 2017-12-23 02:20:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 02:20:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 02:20:36 --> Form Validation Class Initialized
INFO - 2017-12-23 02:20:36 --> Model Class Initialized
INFO - 2017-12-23 02:20:36 --> Controller Class Initialized
INFO - 2017-12-23 02:20:36 --> Model Class Initialized
INFO - 2017-12-23 02:20:36 --> Model Class Initialized
INFO - 2017-12-23 02:20:36 --> Model Class Initialized
DEBUG - 2017-12-23 02:20:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 02:20:36 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-23 02:20:36 --> Final output sent to browser
DEBUG - 2017-12-23 02:20:36 --> Total execution time: 0.1456
INFO - 2017-12-23 02:20:36 --> Config Class Initialized
INFO - 2017-12-23 02:20:36 --> Hooks Class Initialized
DEBUG - 2017-12-23 02:20:36 --> UTF-8 Support Enabled
INFO - 2017-12-23 02:20:36 --> Utf8 Class Initialized
INFO - 2017-12-23 02:20:36 --> URI Class Initialized
INFO - 2017-12-23 02:20:36 --> Router Class Initialized
INFO - 2017-12-23 02:20:36 --> Output Class Initialized
INFO - 2017-12-23 02:20:36 --> Security Class Initialized
DEBUG - 2017-12-23 02:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 02:20:36 --> Input Class Initialized
INFO - 2017-12-23 02:20:36 --> Language Class Initialized
INFO - 2017-12-23 02:20:36 --> Loader Class Initialized
INFO - 2017-12-23 02:20:36 --> Helper loaded: url_helper
INFO - 2017-12-23 02:20:36 --> Helper loaded: form_helper
INFO - 2017-12-23 02:20:36 --> Database Driver Class Initialized
DEBUG - 2017-12-23 02:20:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 02:20:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 02:20:36 --> Form Validation Class Initialized
INFO - 2017-12-23 02:20:36 --> Model Class Initialized
INFO - 2017-12-23 02:20:36 --> Controller Class Initialized
INFO - 2017-12-23 02:20:36 --> Model Class Initialized
INFO - 2017-12-23 02:20:36 --> Model Class Initialized
INFO - 2017-12-23 02:20:36 --> Model Class Initialized
DEBUG - 2017-12-23 02:20:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 02:20:37 --> Config Class Initialized
INFO - 2017-12-23 02:20:37 --> Hooks Class Initialized
DEBUG - 2017-12-23 02:20:37 --> UTF-8 Support Enabled
INFO - 2017-12-23 02:20:37 --> Utf8 Class Initialized
INFO - 2017-12-23 02:20:37 --> URI Class Initialized
INFO - 2017-12-23 02:20:37 --> Router Class Initialized
INFO - 2017-12-23 02:20:37 --> Output Class Initialized
INFO - 2017-12-23 02:20:37 --> Security Class Initialized
DEBUG - 2017-12-23 02:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 02:20:37 --> Input Class Initialized
INFO - 2017-12-23 02:20:37 --> Language Class Initialized
INFO - 2017-12-23 02:20:37 --> Loader Class Initialized
INFO - 2017-12-23 02:20:37 --> Helper loaded: url_helper
INFO - 2017-12-23 02:20:37 --> Helper loaded: form_helper
INFO - 2017-12-23 02:20:37 --> Database Driver Class Initialized
DEBUG - 2017-12-23 02:20:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 02:20:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 02:20:37 --> Form Validation Class Initialized
INFO - 2017-12-23 02:20:37 --> Model Class Initialized
INFO - 2017-12-23 02:20:37 --> Controller Class Initialized
INFO - 2017-12-23 02:20:37 --> Model Class Initialized
INFO - 2017-12-23 02:20:37 --> Model Class Initialized
INFO - 2017-12-23 02:20:37 --> Model Class Initialized
DEBUG - 2017-12-23 02:20:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 02:20:37 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-23 02:20:37 --> Final output sent to browser
DEBUG - 2017-12-23 02:20:37 --> Total execution time: 0.0765
INFO - 2017-12-23 02:20:39 --> Config Class Initialized
INFO - 2017-12-23 02:20:39 --> Hooks Class Initialized
DEBUG - 2017-12-23 02:20:39 --> UTF-8 Support Enabled
INFO - 2017-12-23 02:20:39 --> Utf8 Class Initialized
INFO - 2017-12-23 02:20:39 --> URI Class Initialized
INFO - 2017-12-23 02:20:39 --> Router Class Initialized
INFO - 2017-12-23 02:20:39 --> Output Class Initialized
INFO - 2017-12-23 02:20:39 --> Security Class Initialized
DEBUG - 2017-12-23 02:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 02:20:39 --> Input Class Initialized
INFO - 2017-12-23 02:20:39 --> Language Class Initialized
INFO - 2017-12-23 02:20:39 --> Loader Class Initialized
INFO - 2017-12-23 02:20:39 --> Helper loaded: url_helper
INFO - 2017-12-23 02:20:39 --> Helper loaded: form_helper
INFO - 2017-12-23 02:20:39 --> Database Driver Class Initialized
DEBUG - 2017-12-23 02:20:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 02:20:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 02:20:39 --> Form Validation Class Initialized
INFO - 2017-12-23 02:20:39 --> Model Class Initialized
INFO - 2017-12-23 02:20:39 --> Controller Class Initialized
INFO - 2017-12-23 02:20:39 --> Model Class Initialized
INFO - 2017-12-23 02:20:39 --> Model Class Initialized
INFO - 2017-12-23 02:20:39 --> Model Class Initialized
DEBUG - 2017-12-23 02:20:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 02:20:39 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-23 02:20:39 --> Final output sent to browser
DEBUG - 2017-12-23 02:20:39 --> Total execution time: 0.0520
INFO - 2017-12-23 02:20:44 --> Config Class Initialized
INFO - 2017-12-23 02:20:44 --> Hooks Class Initialized
DEBUG - 2017-12-23 02:20:44 --> UTF-8 Support Enabled
INFO - 2017-12-23 02:20:44 --> Utf8 Class Initialized
INFO - 2017-12-23 02:20:44 --> URI Class Initialized
INFO - 2017-12-23 02:20:44 --> Router Class Initialized
INFO - 2017-12-23 02:20:44 --> Output Class Initialized
INFO - 2017-12-23 02:20:44 --> Security Class Initialized
DEBUG - 2017-12-23 02:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 02:20:44 --> Input Class Initialized
INFO - 2017-12-23 02:20:44 --> Language Class Initialized
INFO - 2017-12-23 02:20:44 --> Loader Class Initialized
INFO - 2017-12-23 02:20:44 --> Helper loaded: url_helper
INFO - 2017-12-23 02:20:44 --> Helper loaded: form_helper
INFO - 2017-12-23 02:20:44 --> Database Driver Class Initialized
DEBUG - 2017-12-23 02:20:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 02:20:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 02:20:44 --> Form Validation Class Initialized
INFO - 2017-12-23 02:20:44 --> Model Class Initialized
INFO - 2017-12-23 02:20:44 --> Controller Class Initialized
INFO - 2017-12-23 02:20:44 --> Model Class Initialized
INFO - 2017-12-23 02:20:44 --> Model Class Initialized
INFO - 2017-12-23 02:20:44 --> Model Class Initialized
DEBUG - 2017-12-23 02:20:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 02:20:44 --> Config Class Initialized
INFO - 2017-12-23 02:20:44 --> Hooks Class Initialized
DEBUG - 2017-12-23 02:20:44 --> UTF-8 Support Enabled
INFO - 2017-12-23 02:20:44 --> Utf8 Class Initialized
INFO - 2017-12-23 02:20:44 --> URI Class Initialized
INFO - 2017-12-23 02:20:44 --> Router Class Initialized
INFO - 2017-12-23 02:20:44 --> Output Class Initialized
INFO - 2017-12-23 02:20:44 --> Security Class Initialized
DEBUG - 2017-12-23 02:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 02:20:44 --> Input Class Initialized
INFO - 2017-12-23 02:20:44 --> Language Class Initialized
INFO - 2017-12-23 02:20:44 --> Loader Class Initialized
INFO - 2017-12-23 02:20:44 --> Helper loaded: url_helper
INFO - 2017-12-23 02:20:44 --> Helper loaded: form_helper
INFO - 2017-12-23 02:20:44 --> Database Driver Class Initialized
DEBUG - 2017-12-23 02:20:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 02:20:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 02:20:44 --> Form Validation Class Initialized
INFO - 2017-12-23 02:20:44 --> Model Class Initialized
INFO - 2017-12-23 02:20:44 --> Controller Class Initialized
INFO - 2017-12-23 02:20:44 --> Model Class Initialized
INFO - 2017-12-23 02:20:44 --> Model Class Initialized
INFO - 2017-12-23 02:20:44 --> Model Class Initialized
DEBUG - 2017-12-23 02:20:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 02:20:44 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-23 02:20:44 --> Final output sent to browser
DEBUG - 2017-12-23 02:20:44 --> Total execution time: 0.0832
INFO - 2017-12-23 02:20:46 --> Config Class Initialized
INFO - 2017-12-23 02:20:46 --> Hooks Class Initialized
DEBUG - 2017-12-23 02:20:46 --> UTF-8 Support Enabled
INFO - 2017-12-23 02:20:46 --> Utf8 Class Initialized
INFO - 2017-12-23 02:20:46 --> URI Class Initialized
INFO - 2017-12-23 02:20:46 --> Router Class Initialized
INFO - 2017-12-23 02:20:46 --> Output Class Initialized
INFO - 2017-12-23 02:20:46 --> Security Class Initialized
DEBUG - 2017-12-23 02:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 02:20:46 --> Input Class Initialized
INFO - 2017-12-23 02:20:46 --> Language Class Initialized
INFO - 2017-12-23 02:20:46 --> Loader Class Initialized
INFO - 2017-12-23 02:20:46 --> Helper loaded: url_helper
INFO - 2017-12-23 02:20:46 --> Helper loaded: form_helper
INFO - 2017-12-23 02:20:46 --> Database Driver Class Initialized
DEBUG - 2017-12-23 02:20:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 02:20:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 02:20:46 --> Form Validation Class Initialized
INFO - 2017-12-23 02:20:46 --> Model Class Initialized
INFO - 2017-12-23 02:20:46 --> Controller Class Initialized
INFO - 2017-12-23 02:20:46 --> Model Class Initialized
INFO - 2017-12-23 02:20:46 --> Model Class Initialized
INFO - 2017-12-23 02:20:46 --> Model Class Initialized
DEBUG - 2017-12-23 02:20:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 02:20:46 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-23 02:20:46 --> Final output sent to browser
DEBUG - 2017-12-23 02:20:46 --> Total execution time: 0.0627
INFO - 2017-12-23 02:20:46 --> Config Class Initialized
INFO - 2017-12-23 02:20:46 --> Hooks Class Initialized
DEBUG - 2017-12-23 02:20:46 --> UTF-8 Support Enabled
INFO - 2017-12-23 02:20:46 --> Utf8 Class Initialized
INFO - 2017-12-23 02:20:46 --> URI Class Initialized
INFO - 2017-12-23 02:20:46 --> Router Class Initialized
INFO - 2017-12-23 02:20:46 --> Output Class Initialized
INFO - 2017-12-23 02:20:46 --> Security Class Initialized
DEBUG - 2017-12-23 02:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 02:20:46 --> Input Class Initialized
INFO - 2017-12-23 02:20:46 --> Language Class Initialized
INFO - 2017-12-23 02:20:46 --> Loader Class Initialized
INFO - 2017-12-23 02:20:46 --> Helper loaded: url_helper
INFO - 2017-12-23 02:20:46 --> Helper loaded: form_helper
INFO - 2017-12-23 02:20:46 --> Database Driver Class Initialized
DEBUG - 2017-12-23 02:20:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 02:20:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 02:20:46 --> Form Validation Class Initialized
INFO - 2017-12-23 02:20:46 --> Model Class Initialized
INFO - 2017-12-23 02:20:46 --> Controller Class Initialized
INFO - 2017-12-23 02:20:46 --> Model Class Initialized
INFO - 2017-12-23 02:20:46 --> Model Class Initialized
INFO - 2017-12-23 02:20:46 --> Model Class Initialized
DEBUG - 2017-12-23 02:20:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 02:22:08 --> Config Class Initialized
INFO - 2017-12-23 02:22:08 --> Hooks Class Initialized
DEBUG - 2017-12-23 02:22:08 --> UTF-8 Support Enabled
INFO - 2017-12-23 02:22:08 --> Utf8 Class Initialized
INFO - 2017-12-23 02:22:08 --> URI Class Initialized
INFO - 2017-12-23 02:22:08 --> Router Class Initialized
INFO - 2017-12-23 02:22:08 --> Output Class Initialized
INFO - 2017-12-23 02:22:08 --> Security Class Initialized
DEBUG - 2017-12-23 02:22:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 02:22:08 --> Input Class Initialized
INFO - 2017-12-23 02:22:08 --> Language Class Initialized
INFO - 2017-12-23 02:22:09 --> Loader Class Initialized
INFO - 2017-12-23 02:22:09 --> Helper loaded: url_helper
INFO - 2017-12-23 02:22:09 --> Helper loaded: form_helper
INFO - 2017-12-23 02:22:09 --> Database Driver Class Initialized
DEBUG - 2017-12-23 02:22:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 02:22:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 02:22:09 --> Form Validation Class Initialized
INFO - 2017-12-23 02:22:09 --> Model Class Initialized
INFO - 2017-12-23 02:22:09 --> Controller Class Initialized
INFO - 2017-12-23 02:22:09 --> Model Class Initialized
INFO - 2017-12-23 02:22:09 --> Model Class Initialized
DEBUG - 2017-12-23 02:22:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 02:22:09 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-23 02:22:09 --> Final output sent to browser
DEBUG - 2017-12-23 02:22:09 --> Total execution time: 0.3913
INFO - 2017-12-23 02:22:09 --> Config Class Initialized
INFO - 2017-12-23 02:22:09 --> Hooks Class Initialized
DEBUG - 2017-12-23 02:22:09 --> UTF-8 Support Enabled
INFO - 2017-12-23 02:22:09 --> Utf8 Class Initialized
INFO - 2017-12-23 02:22:09 --> URI Class Initialized
INFO - 2017-12-23 02:22:09 --> Router Class Initialized
INFO - 2017-12-23 02:22:09 --> Output Class Initialized
INFO - 2017-12-23 02:22:09 --> Security Class Initialized
DEBUG - 2017-12-23 02:22:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 02:22:09 --> Input Class Initialized
INFO - 2017-12-23 02:22:09 --> Language Class Initialized
INFO - 2017-12-23 02:22:09 --> Loader Class Initialized
INFO - 2017-12-23 02:22:09 --> Helper loaded: url_helper
INFO - 2017-12-23 02:22:09 --> Helper loaded: form_helper
INFO - 2017-12-23 02:22:09 --> Database Driver Class Initialized
DEBUG - 2017-12-23 02:22:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 02:22:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 02:22:09 --> Form Validation Class Initialized
INFO - 2017-12-23 02:22:09 --> Model Class Initialized
INFO - 2017-12-23 02:22:09 --> Controller Class Initialized
INFO - 2017-12-23 02:22:09 --> Model Class Initialized
INFO - 2017-12-23 02:22:09 --> Model Class Initialized
DEBUG - 2017-12-23 02:22:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 02:22:10 --> Config Class Initialized
INFO - 2017-12-23 02:22:10 --> Hooks Class Initialized
DEBUG - 2017-12-23 02:22:10 --> UTF-8 Support Enabled
INFO - 2017-12-23 02:22:10 --> Utf8 Class Initialized
INFO - 2017-12-23 02:22:10 --> URI Class Initialized
INFO - 2017-12-23 02:22:10 --> Router Class Initialized
INFO - 2017-12-23 02:22:10 --> Output Class Initialized
INFO - 2017-12-23 02:22:10 --> Security Class Initialized
DEBUG - 2017-12-23 02:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 02:22:10 --> Input Class Initialized
INFO - 2017-12-23 02:22:10 --> Language Class Initialized
INFO - 2017-12-23 02:22:10 --> Loader Class Initialized
INFO - 2017-12-23 02:22:10 --> Helper loaded: url_helper
INFO - 2017-12-23 02:22:10 --> Helper loaded: form_helper
INFO - 2017-12-23 02:22:10 --> Database Driver Class Initialized
DEBUG - 2017-12-23 02:22:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 02:22:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 02:22:10 --> Form Validation Class Initialized
INFO - 2017-12-23 02:22:10 --> Model Class Initialized
INFO - 2017-12-23 02:22:10 --> Controller Class Initialized
INFO - 2017-12-23 02:22:10 --> Model Class Initialized
INFO - 2017-12-23 02:22:10 --> Model Class Initialized
DEBUG - 2017-12-23 02:22:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 02:22:10 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-23 02:22:10 --> Final output sent to browser
DEBUG - 2017-12-23 02:22:10 --> Total execution time: 0.1309
INFO - 2017-12-23 02:22:10 --> Config Class Initialized
INFO - 2017-12-23 02:22:10 --> Hooks Class Initialized
DEBUG - 2017-12-23 02:22:10 --> UTF-8 Support Enabled
INFO - 2017-12-23 02:22:10 --> Utf8 Class Initialized
INFO - 2017-12-23 02:22:10 --> URI Class Initialized
INFO - 2017-12-23 02:22:10 --> Router Class Initialized
INFO - 2017-12-23 02:22:10 --> Output Class Initialized
INFO - 2017-12-23 02:22:10 --> Security Class Initialized
DEBUG - 2017-12-23 02:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 02:22:10 --> Input Class Initialized
INFO - 2017-12-23 02:22:10 --> Language Class Initialized
INFO - 2017-12-23 02:22:10 --> Loader Class Initialized
INFO - 2017-12-23 02:22:10 --> Helper loaded: url_helper
INFO - 2017-12-23 02:22:10 --> Helper loaded: form_helper
INFO - 2017-12-23 02:22:10 --> Database Driver Class Initialized
DEBUG - 2017-12-23 02:22:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 02:22:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 02:22:10 --> Form Validation Class Initialized
INFO - 2017-12-23 02:22:10 --> Model Class Initialized
INFO - 2017-12-23 02:22:10 --> Controller Class Initialized
INFO - 2017-12-23 02:22:10 --> Model Class Initialized
INFO - 2017-12-23 02:22:10 --> Model Class Initialized
DEBUG - 2017-12-23 02:22:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 02:22:11 --> Config Class Initialized
INFO - 2017-12-23 02:22:11 --> Hooks Class Initialized
DEBUG - 2017-12-23 02:22:11 --> UTF-8 Support Enabled
INFO - 2017-12-23 02:22:11 --> Utf8 Class Initialized
INFO - 2017-12-23 02:22:11 --> URI Class Initialized
INFO - 2017-12-23 02:22:11 --> Router Class Initialized
INFO - 2017-12-23 02:22:11 --> Output Class Initialized
INFO - 2017-12-23 02:22:11 --> Security Class Initialized
DEBUG - 2017-12-23 02:22:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 02:22:11 --> Input Class Initialized
INFO - 2017-12-23 02:22:11 --> Language Class Initialized
INFO - 2017-12-23 02:22:11 --> Loader Class Initialized
INFO - 2017-12-23 02:22:11 --> Helper loaded: url_helper
INFO - 2017-12-23 02:22:11 --> Helper loaded: form_helper
INFO - 2017-12-23 02:22:11 --> Database Driver Class Initialized
DEBUG - 2017-12-23 02:22:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 02:22:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 02:22:11 --> Form Validation Class Initialized
INFO - 2017-12-23 02:22:11 --> Model Class Initialized
INFO - 2017-12-23 02:22:11 --> Controller Class Initialized
INFO - 2017-12-23 02:22:11 --> Model Class Initialized
INFO - 2017-12-23 02:22:11 --> Model Class Initialized
DEBUG - 2017-12-23 02:22:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 02:22:11 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-23 02:22:11 --> Final output sent to browser
DEBUG - 2017-12-23 02:22:11 --> Total execution time: 0.0561
INFO - 2017-12-23 02:22:11 --> Config Class Initialized
INFO - 2017-12-23 02:22:11 --> Hooks Class Initialized
DEBUG - 2017-12-23 02:22:11 --> UTF-8 Support Enabled
INFO - 2017-12-23 02:22:11 --> Utf8 Class Initialized
INFO - 2017-12-23 02:22:11 --> URI Class Initialized
INFO - 2017-12-23 02:22:11 --> Router Class Initialized
INFO - 2017-12-23 02:22:11 --> Output Class Initialized
INFO - 2017-12-23 02:22:11 --> Security Class Initialized
DEBUG - 2017-12-23 02:22:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 02:22:11 --> Input Class Initialized
INFO - 2017-12-23 02:22:11 --> Language Class Initialized
INFO - 2017-12-23 02:22:11 --> Loader Class Initialized
INFO - 2017-12-23 02:22:11 --> Helper loaded: url_helper
INFO - 2017-12-23 02:22:11 --> Helper loaded: form_helper
INFO - 2017-12-23 02:22:11 --> Database Driver Class Initialized
DEBUG - 2017-12-23 02:22:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 02:22:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 02:22:11 --> Form Validation Class Initialized
INFO - 2017-12-23 02:22:11 --> Model Class Initialized
INFO - 2017-12-23 02:22:11 --> Controller Class Initialized
INFO - 2017-12-23 02:22:11 --> Model Class Initialized
INFO - 2017-12-23 02:22:11 --> Model Class Initialized
DEBUG - 2017-12-23 02:22:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 02:22:12 --> Config Class Initialized
INFO - 2017-12-23 02:22:12 --> Hooks Class Initialized
DEBUG - 2017-12-23 02:22:12 --> UTF-8 Support Enabled
INFO - 2017-12-23 02:22:12 --> Utf8 Class Initialized
INFO - 2017-12-23 02:22:12 --> URI Class Initialized
INFO - 2017-12-23 02:22:12 --> Router Class Initialized
INFO - 2017-12-23 02:22:12 --> Output Class Initialized
INFO - 2017-12-23 02:22:12 --> Security Class Initialized
DEBUG - 2017-12-23 02:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 02:22:12 --> Input Class Initialized
INFO - 2017-12-23 02:22:12 --> Language Class Initialized
INFO - 2017-12-23 02:22:12 --> Loader Class Initialized
INFO - 2017-12-23 02:22:12 --> Helper loaded: url_helper
INFO - 2017-12-23 02:22:12 --> Helper loaded: form_helper
INFO - 2017-12-23 02:22:12 --> Database Driver Class Initialized
DEBUG - 2017-12-23 02:22:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 02:22:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 02:22:12 --> Form Validation Class Initialized
INFO - 2017-12-23 02:22:12 --> Model Class Initialized
INFO - 2017-12-23 02:22:12 --> Controller Class Initialized
INFO - 2017-12-23 02:22:12 --> Model Class Initialized
INFO - 2017-12-23 02:22:12 --> Model Class Initialized
INFO - 2017-12-23 02:22:12 --> Model Class Initialized
DEBUG - 2017-12-23 02:22:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 02:22:12 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-23 02:22:12 --> Final output sent to browser
DEBUG - 2017-12-23 02:22:12 --> Total execution time: 0.0696
INFO - 2017-12-23 02:22:12 --> Config Class Initialized
INFO - 2017-12-23 02:22:12 --> Hooks Class Initialized
DEBUG - 2017-12-23 02:22:12 --> UTF-8 Support Enabled
INFO - 2017-12-23 02:22:12 --> Utf8 Class Initialized
INFO - 2017-12-23 02:22:12 --> URI Class Initialized
INFO - 2017-12-23 02:22:12 --> Router Class Initialized
INFO - 2017-12-23 02:22:12 --> Output Class Initialized
INFO - 2017-12-23 02:22:12 --> Security Class Initialized
DEBUG - 2017-12-23 02:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 02:22:12 --> Input Class Initialized
INFO - 2017-12-23 02:22:12 --> Language Class Initialized
INFO - 2017-12-23 02:22:12 --> Loader Class Initialized
INFO - 2017-12-23 02:22:12 --> Helper loaded: url_helper
INFO - 2017-12-23 02:22:12 --> Helper loaded: form_helper
INFO - 2017-12-23 02:22:12 --> Database Driver Class Initialized
DEBUG - 2017-12-23 02:22:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 02:22:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 02:22:12 --> Form Validation Class Initialized
INFO - 2017-12-23 02:22:12 --> Model Class Initialized
INFO - 2017-12-23 02:22:12 --> Controller Class Initialized
INFO - 2017-12-23 02:22:12 --> Model Class Initialized
INFO - 2017-12-23 02:22:12 --> Model Class Initialized
INFO - 2017-12-23 02:22:12 --> Model Class Initialized
DEBUG - 2017-12-23 02:22:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 02:22:15 --> Config Class Initialized
INFO - 2017-12-23 02:22:15 --> Hooks Class Initialized
DEBUG - 2017-12-23 02:22:15 --> UTF-8 Support Enabled
INFO - 2017-12-23 02:22:15 --> Utf8 Class Initialized
INFO - 2017-12-23 02:22:15 --> URI Class Initialized
INFO - 2017-12-23 02:22:15 --> Router Class Initialized
INFO - 2017-12-23 02:22:15 --> Output Class Initialized
INFO - 2017-12-23 02:22:15 --> Security Class Initialized
DEBUG - 2017-12-23 02:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 02:22:15 --> Input Class Initialized
INFO - 2017-12-23 02:22:15 --> Language Class Initialized
INFO - 2017-12-23 02:22:15 --> Loader Class Initialized
INFO - 2017-12-23 02:22:15 --> Helper loaded: url_helper
INFO - 2017-12-23 02:22:15 --> Helper loaded: form_helper
INFO - 2017-12-23 02:22:15 --> Database Driver Class Initialized
DEBUG - 2017-12-23 02:22:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 02:22:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 02:22:15 --> Form Validation Class Initialized
INFO - 2017-12-23 02:22:15 --> Model Class Initialized
INFO - 2017-12-23 02:22:15 --> Controller Class Initialized
INFO - 2017-12-23 02:22:15 --> Model Class Initialized
INFO - 2017-12-23 02:22:15 --> Model Class Initialized
INFO - 2017-12-23 02:22:15 --> Model Class Initialized
DEBUG - 2017-12-23 02:22:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 02:22:15 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-23 02:22:15 --> Final output sent to browser
DEBUG - 2017-12-23 02:22:15 --> Total execution time: 0.0738
INFO - 2017-12-23 02:22:15 --> Config Class Initialized
INFO - 2017-12-23 02:22:15 --> Hooks Class Initialized
DEBUG - 2017-12-23 02:22:15 --> UTF-8 Support Enabled
INFO - 2017-12-23 02:22:15 --> Utf8 Class Initialized
INFO - 2017-12-23 02:22:15 --> URI Class Initialized
INFO - 2017-12-23 02:22:15 --> Router Class Initialized
INFO - 2017-12-23 02:22:15 --> Output Class Initialized
INFO - 2017-12-23 02:22:15 --> Security Class Initialized
DEBUG - 2017-12-23 02:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 02:22:15 --> Input Class Initialized
INFO - 2017-12-23 02:22:15 --> Language Class Initialized
INFO - 2017-12-23 02:22:15 --> Loader Class Initialized
INFO - 2017-12-23 02:22:15 --> Helper loaded: url_helper
INFO - 2017-12-23 02:22:15 --> Helper loaded: form_helper
INFO - 2017-12-23 02:22:15 --> Database Driver Class Initialized
DEBUG - 2017-12-23 02:22:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 02:22:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 02:22:15 --> Form Validation Class Initialized
INFO - 2017-12-23 02:22:15 --> Model Class Initialized
INFO - 2017-12-23 02:22:15 --> Controller Class Initialized
INFO - 2017-12-23 02:22:15 --> Model Class Initialized
INFO - 2017-12-23 02:22:15 --> Model Class Initialized
INFO - 2017-12-23 02:22:15 --> Model Class Initialized
DEBUG - 2017-12-23 02:22:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 02:22:18 --> Config Class Initialized
INFO - 2017-12-23 02:22:18 --> Hooks Class Initialized
DEBUG - 2017-12-23 02:22:18 --> UTF-8 Support Enabled
INFO - 2017-12-23 02:22:18 --> Utf8 Class Initialized
INFO - 2017-12-23 02:22:18 --> URI Class Initialized
INFO - 2017-12-23 02:22:18 --> Router Class Initialized
INFO - 2017-12-23 02:22:18 --> Output Class Initialized
INFO - 2017-12-23 02:22:18 --> Security Class Initialized
DEBUG - 2017-12-23 02:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 02:22:18 --> Input Class Initialized
INFO - 2017-12-23 02:22:18 --> Language Class Initialized
INFO - 2017-12-23 02:22:18 --> Loader Class Initialized
INFO - 2017-12-23 02:22:18 --> Helper loaded: url_helper
INFO - 2017-12-23 02:22:19 --> Helper loaded: form_helper
INFO - 2017-12-23 02:22:19 --> Database Driver Class Initialized
DEBUG - 2017-12-23 02:22:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 02:22:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 02:22:19 --> Form Validation Class Initialized
INFO - 2017-12-23 02:22:19 --> Model Class Initialized
INFO - 2017-12-23 02:22:19 --> Controller Class Initialized
INFO - 2017-12-23 02:22:19 --> Model Class Initialized
INFO - 2017-12-23 02:22:19 --> Model Class Initialized
INFO - 2017-12-23 02:22:19 --> Model Class Initialized
DEBUG - 2017-12-23 02:22:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 02:22:19 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-23 02:22:19 --> Final output sent to browser
DEBUG - 2017-12-23 02:22:19 --> Total execution time: 0.0536
INFO - 2017-12-23 02:22:19 --> Config Class Initialized
INFO - 2017-12-23 02:22:19 --> Hooks Class Initialized
INFO - 2017-12-23 02:22:19 --> Config Class Initialized
INFO - 2017-12-23 02:22:19 --> Hooks Class Initialized
DEBUG - 2017-12-23 02:22:19 --> UTF-8 Support Enabled
INFO - 2017-12-23 02:22:19 --> Utf8 Class Initialized
DEBUG - 2017-12-23 02:22:19 --> UTF-8 Support Enabled
INFO - 2017-12-23 02:22:19 --> Utf8 Class Initialized
INFO - 2017-12-23 02:22:19 --> URI Class Initialized
INFO - 2017-12-23 02:22:19 --> URI Class Initialized
INFO - 2017-12-23 02:22:19 --> Router Class Initialized
INFO - 2017-12-23 02:22:19 --> Router Class Initialized
INFO - 2017-12-23 02:22:19 --> Output Class Initialized
INFO - 2017-12-23 02:22:19 --> Output Class Initialized
INFO - 2017-12-23 02:22:19 --> Security Class Initialized
INFO - 2017-12-23 02:22:19 --> Security Class Initialized
DEBUG - 2017-12-23 02:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 02:22:19 --> Input Class Initialized
DEBUG - 2017-12-23 02:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 02:22:19 --> Input Class Initialized
INFO - 2017-12-23 02:22:19 --> Language Class Initialized
INFO - 2017-12-23 02:22:19 --> Language Class Initialized
INFO - 2017-12-23 02:22:19 --> Loader Class Initialized
INFO - 2017-12-23 02:22:19 --> Loader Class Initialized
INFO - 2017-12-23 02:22:19 --> Helper loaded: url_helper
INFO - 2017-12-23 02:22:19 --> Helper loaded: url_helper
INFO - 2017-12-23 02:22:19 --> Helper loaded: form_helper
INFO - 2017-12-23 02:22:19 --> Helper loaded: form_helper
INFO - 2017-12-23 02:22:19 --> Database Driver Class Initialized
INFO - 2017-12-23 02:22:19 --> Database Driver Class Initialized
DEBUG - 2017-12-23 02:22:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 02:22:19 --> Session: Class initialized using 'files' driver.
DEBUG - 2017-12-23 02:22:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 02:22:19 --> Form Validation Class Initialized
INFO - 2017-12-23 02:22:19 --> Model Class Initialized
INFO - 2017-12-23 02:22:19 --> Controller Class Initialized
INFO - 2017-12-23 02:22:19 --> Model Class Initialized
INFO - 2017-12-23 02:22:19 --> Model Class Initialized
INFO - 2017-12-23 02:22:19 --> Model Class Initialized
DEBUG - 2017-12-23 02:22:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 02:22:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 02:22:19 --> Form Validation Class Initialized
INFO - 2017-12-23 02:22:19 --> Model Class Initialized
INFO - 2017-12-23 02:22:19 --> Controller Class Initialized
INFO - 2017-12-23 02:22:19 --> Model Class Initialized
INFO - 2017-12-23 02:22:19 --> Model Class Initialized
INFO - 2017-12-23 02:22:19 --> Model Class Initialized
DEBUG - 2017-12-23 02:22:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 02:22:20 --> Config Class Initialized
INFO - 2017-12-23 02:22:20 --> Hooks Class Initialized
DEBUG - 2017-12-23 02:22:20 --> UTF-8 Support Enabled
INFO - 2017-12-23 02:22:20 --> Utf8 Class Initialized
INFO - 2017-12-23 02:22:20 --> URI Class Initialized
INFO - 2017-12-23 02:22:20 --> Router Class Initialized
INFO - 2017-12-23 02:22:20 --> Output Class Initialized
INFO - 2017-12-23 02:22:20 --> Security Class Initialized
DEBUG - 2017-12-23 02:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 02:22:20 --> Input Class Initialized
INFO - 2017-12-23 02:22:20 --> Language Class Initialized
INFO - 2017-12-23 02:22:20 --> Loader Class Initialized
INFO - 2017-12-23 02:22:20 --> Helper loaded: url_helper
INFO - 2017-12-23 02:22:20 --> Helper loaded: form_helper
INFO - 2017-12-23 02:22:20 --> Database Driver Class Initialized
DEBUG - 2017-12-23 02:22:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 02:22:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 02:22:20 --> Form Validation Class Initialized
INFO - 2017-12-23 02:22:20 --> Model Class Initialized
INFO - 2017-12-23 02:22:20 --> Controller Class Initialized
INFO - 2017-12-23 02:22:20 --> Model Class Initialized
INFO - 2017-12-23 02:22:20 --> Model Class Initialized
INFO - 2017-12-23 02:22:20 --> Model Class Initialized
DEBUG - 2017-12-23 02:22:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 02:22:20 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-23 02:22:20 --> Final output sent to browser
DEBUG - 2017-12-23 02:22:20 --> Total execution time: 0.0707
INFO - 2017-12-23 02:22:20 --> Config Class Initialized
INFO - 2017-12-23 02:22:20 --> Hooks Class Initialized
DEBUG - 2017-12-23 02:22:20 --> UTF-8 Support Enabled
INFO - 2017-12-23 02:22:20 --> Utf8 Class Initialized
INFO - 2017-12-23 02:22:20 --> URI Class Initialized
INFO - 2017-12-23 02:22:20 --> Router Class Initialized
INFO - 2017-12-23 02:22:20 --> Output Class Initialized
INFO - 2017-12-23 02:22:20 --> Security Class Initialized
DEBUG - 2017-12-23 02:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 02:22:20 --> Input Class Initialized
INFO - 2017-12-23 02:22:20 --> Language Class Initialized
INFO - 2017-12-23 02:22:20 --> Loader Class Initialized
INFO - 2017-12-23 02:22:20 --> Helper loaded: url_helper
INFO - 2017-12-23 02:22:20 --> Helper loaded: form_helper
INFO - 2017-12-23 02:22:20 --> Database Driver Class Initialized
DEBUG - 2017-12-23 02:22:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 02:22:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 02:22:20 --> Form Validation Class Initialized
INFO - 2017-12-23 02:22:20 --> Model Class Initialized
INFO - 2017-12-23 02:22:20 --> Controller Class Initialized
INFO - 2017-12-23 02:22:20 --> Model Class Initialized
INFO - 2017-12-23 02:22:20 --> Model Class Initialized
INFO - 2017-12-23 02:22:20 --> Model Class Initialized
DEBUG - 2017-12-23 02:22:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 02:22:21 --> Config Class Initialized
INFO - 2017-12-23 02:22:21 --> Hooks Class Initialized
DEBUG - 2017-12-23 02:22:21 --> UTF-8 Support Enabled
INFO - 2017-12-23 02:22:21 --> Utf8 Class Initialized
INFO - 2017-12-23 02:22:21 --> URI Class Initialized
INFO - 2017-12-23 02:22:21 --> Router Class Initialized
INFO - 2017-12-23 02:22:21 --> Output Class Initialized
INFO - 2017-12-23 02:22:21 --> Security Class Initialized
DEBUG - 2017-12-23 02:22:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 02:22:21 --> Input Class Initialized
INFO - 2017-12-23 02:22:21 --> Language Class Initialized
INFO - 2017-12-23 02:22:21 --> Loader Class Initialized
INFO - 2017-12-23 02:22:21 --> Helper loaded: url_helper
INFO - 2017-12-23 02:22:21 --> Helper loaded: form_helper
INFO - 2017-12-23 02:22:21 --> Database Driver Class Initialized
DEBUG - 2017-12-23 02:22:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 02:22:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 02:22:21 --> Form Validation Class Initialized
INFO - 2017-12-23 02:22:21 --> Model Class Initialized
INFO - 2017-12-23 02:22:21 --> Controller Class Initialized
INFO - 2017-12-23 02:22:21 --> Model Class Initialized
INFO - 2017-12-23 02:22:21 --> Model Class Initialized
INFO - 2017-12-23 02:22:21 --> Model Class Initialized
DEBUG - 2017-12-23 02:22:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 02:22:21 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-23 02:22:21 --> Final output sent to browser
DEBUG - 2017-12-23 02:22:21 --> Total execution time: 0.0716
INFO - 2017-12-23 02:22:23 --> Config Class Initialized
INFO - 2017-12-23 02:22:23 --> Hooks Class Initialized
DEBUG - 2017-12-23 02:22:23 --> UTF-8 Support Enabled
INFO - 2017-12-23 02:22:23 --> Utf8 Class Initialized
INFO - 2017-12-23 02:22:23 --> URI Class Initialized
INFO - 2017-12-23 02:22:23 --> Router Class Initialized
INFO - 2017-12-23 02:22:23 --> Output Class Initialized
INFO - 2017-12-23 02:22:23 --> Security Class Initialized
DEBUG - 2017-12-23 02:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 02:22:23 --> Input Class Initialized
INFO - 2017-12-23 02:22:23 --> Language Class Initialized
INFO - 2017-12-23 02:22:23 --> Loader Class Initialized
INFO - 2017-12-23 02:22:23 --> Helper loaded: url_helper
INFO - 2017-12-23 02:22:23 --> Helper loaded: form_helper
INFO - 2017-12-23 02:22:23 --> Database Driver Class Initialized
DEBUG - 2017-12-23 02:22:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 02:22:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 02:22:23 --> Form Validation Class Initialized
INFO - 2017-12-23 02:22:23 --> Model Class Initialized
INFO - 2017-12-23 02:22:23 --> Controller Class Initialized
INFO - 2017-12-23 02:22:23 --> Model Class Initialized
INFO - 2017-12-23 02:22:23 --> Model Class Initialized
INFO - 2017-12-23 02:22:23 --> Model Class Initialized
DEBUG - 2017-12-23 02:22:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 02:22:23 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-23 02:22:23 --> Final output sent to browser
DEBUG - 2017-12-23 02:22:23 --> Total execution time: 0.0601
INFO - 2017-12-23 02:22:23 --> Config Class Initialized
INFO - 2017-12-23 02:22:23 --> Hooks Class Initialized
DEBUG - 2017-12-23 02:22:23 --> UTF-8 Support Enabled
INFO - 2017-12-23 02:22:23 --> Utf8 Class Initialized
INFO - 2017-12-23 02:22:23 --> URI Class Initialized
INFO - 2017-12-23 02:22:23 --> Router Class Initialized
INFO - 2017-12-23 02:22:23 --> Output Class Initialized
INFO - 2017-12-23 02:22:23 --> Security Class Initialized
DEBUG - 2017-12-23 02:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 02:22:23 --> Input Class Initialized
INFO - 2017-12-23 02:22:23 --> Language Class Initialized
INFO - 2017-12-23 02:22:23 --> Loader Class Initialized
INFO - 2017-12-23 02:22:23 --> Helper loaded: url_helper
INFO - 2017-12-23 02:22:23 --> Helper loaded: form_helper
INFO - 2017-12-23 02:22:23 --> Database Driver Class Initialized
DEBUG - 2017-12-23 02:22:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 02:22:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 02:22:23 --> Form Validation Class Initialized
INFO - 2017-12-23 02:22:23 --> Model Class Initialized
INFO - 2017-12-23 02:22:23 --> Controller Class Initialized
INFO - 2017-12-23 02:22:23 --> Model Class Initialized
INFO - 2017-12-23 02:22:23 --> Model Class Initialized
INFO - 2017-12-23 02:22:23 --> Model Class Initialized
DEBUG - 2017-12-23 02:22:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 02:22:24 --> Config Class Initialized
INFO - 2017-12-23 02:22:24 --> Hooks Class Initialized
DEBUG - 2017-12-23 02:22:24 --> UTF-8 Support Enabled
INFO - 2017-12-23 02:22:24 --> Utf8 Class Initialized
INFO - 2017-12-23 02:22:24 --> URI Class Initialized
INFO - 2017-12-23 02:22:24 --> Router Class Initialized
INFO - 2017-12-23 02:22:24 --> Output Class Initialized
INFO - 2017-12-23 02:22:24 --> Security Class Initialized
DEBUG - 2017-12-23 02:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 02:22:24 --> Input Class Initialized
INFO - 2017-12-23 02:22:24 --> Language Class Initialized
INFO - 2017-12-23 02:22:24 --> Loader Class Initialized
INFO - 2017-12-23 02:22:24 --> Helper loaded: url_helper
INFO - 2017-12-23 02:22:24 --> Helper loaded: form_helper
INFO - 2017-12-23 02:22:24 --> Database Driver Class Initialized
DEBUG - 2017-12-23 02:22:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 02:22:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 02:22:24 --> Form Validation Class Initialized
INFO - 2017-12-23 02:22:24 --> Model Class Initialized
INFO - 2017-12-23 02:22:24 --> Controller Class Initialized
INFO - 2017-12-23 02:22:24 --> Model Class Initialized
INFO - 2017-12-23 02:22:24 --> Model Class Initialized
INFO - 2017-12-23 02:22:24 --> Model Class Initialized
DEBUG - 2017-12-23 02:22:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 02:22:24 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-23 02:22:24 --> Final output sent to browser
DEBUG - 2017-12-23 02:22:24 --> Total execution time: 0.1082
INFO - 2017-12-23 02:22:24 --> Config Class Initialized
INFO - 2017-12-23 02:22:24 --> Hooks Class Initialized
DEBUG - 2017-12-23 02:22:24 --> UTF-8 Support Enabled
INFO - 2017-12-23 02:22:24 --> Utf8 Class Initialized
INFO - 2017-12-23 02:22:24 --> URI Class Initialized
INFO - 2017-12-23 02:22:24 --> Router Class Initialized
INFO - 2017-12-23 02:22:24 --> Output Class Initialized
INFO - 2017-12-23 02:22:24 --> Security Class Initialized
DEBUG - 2017-12-23 02:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 02:22:24 --> Input Class Initialized
INFO - 2017-12-23 02:22:24 --> Language Class Initialized
INFO - 2017-12-23 02:22:24 --> Loader Class Initialized
INFO - 2017-12-23 02:22:24 --> Helper loaded: url_helper
INFO - 2017-12-23 02:22:24 --> Helper loaded: form_helper
INFO - 2017-12-23 02:22:24 --> Database Driver Class Initialized
DEBUG - 2017-12-23 02:22:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 02:22:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 02:22:24 --> Form Validation Class Initialized
INFO - 2017-12-23 02:22:24 --> Model Class Initialized
INFO - 2017-12-23 02:22:24 --> Controller Class Initialized
INFO - 2017-12-23 02:22:24 --> Model Class Initialized
INFO - 2017-12-23 02:22:24 --> Model Class Initialized
INFO - 2017-12-23 02:22:24 --> Model Class Initialized
DEBUG - 2017-12-23 02:22:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 02:22:26 --> Config Class Initialized
INFO - 2017-12-23 02:22:26 --> Hooks Class Initialized
DEBUG - 2017-12-23 02:22:26 --> UTF-8 Support Enabled
INFO - 2017-12-23 02:22:26 --> Utf8 Class Initialized
INFO - 2017-12-23 02:22:26 --> URI Class Initialized
INFO - 2017-12-23 02:22:26 --> Router Class Initialized
INFO - 2017-12-23 02:22:26 --> Output Class Initialized
INFO - 2017-12-23 02:22:26 --> Security Class Initialized
DEBUG - 2017-12-23 02:22:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 02:22:26 --> Input Class Initialized
INFO - 2017-12-23 02:22:26 --> Language Class Initialized
INFO - 2017-12-23 02:22:26 --> Loader Class Initialized
INFO - 2017-12-23 02:22:26 --> Helper loaded: url_helper
INFO - 2017-12-23 02:22:26 --> Helper loaded: form_helper
INFO - 2017-12-23 02:22:26 --> Database Driver Class Initialized
DEBUG - 2017-12-23 02:22:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 02:22:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 02:22:26 --> Form Validation Class Initialized
INFO - 2017-12-23 02:22:26 --> Model Class Initialized
INFO - 2017-12-23 02:22:26 --> Controller Class Initialized
INFO - 2017-12-23 02:22:26 --> Model Class Initialized
INFO - 2017-12-23 02:22:26 --> Model Class Initialized
INFO - 2017-12-23 02:22:26 --> Model Class Initialized
DEBUG - 2017-12-23 02:22:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 02:22:26 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-23 02:22:26 --> Final output sent to browser
DEBUG - 2017-12-23 02:22:26 --> Total execution time: 0.0560
INFO - 2017-12-23 02:22:26 --> Config Class Initialized
INFO - 2017-12-23 02:22:26 --> Hooks Class Initialized
DEBUG - 2017-12-23 02:22:26 --> UTF-8 Support Enabled
INFO - 2017-12-23 02:22:26 --> Utf8 Class Initialized
INFO - 2017-12-23 02:22:26 --> URI Class Initialized
INFO - 2017-12-23 02:22:26 --> Router Class Initialized
INFO - 2017-12-23 02:22:26 --> Output Class Initialized
INFO - 2017-12-23 02:22:26 --> Security Class Initialized
DEBUG - 2017-12-23 02:22:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 02:22:26 --> Input Class Initialized
INFO - 2017-12-23 02:22:26 --> Language Class Initialized
INFO - 2017-12-23 02:22:26 --> Loader Class Initialized
INFO - 2017-12-23 02:22:26 --> Helper loaded: url_helper
INFO - 2017-12-23 02:22:26 --> Helper loaded: form_helper
INFO - 2017-12-23 02:22:26 --> Database Driver Class Initialized
DEBUG - 2017-12-23 02:22:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 02:22:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 02:22:26 --> Form Validation Class Initialized
INFO - 2017-12-23 02:22:26 --> Model Class Initialized
INFO - 2017-12-23 02:22:26 --> Controller Class Initialized
INFO - 2017-12-23 02:22:26 --> Model Class Initialized
INFO - 2017-12-23 02:22:26 --> Model Class Initialized
INFO - 2017-12-23 02:22:26 --> Model Class Initialized
DEBUG - 2017-12-23 02:22:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 02:22:28 --> Config Class Initialized
INFO - 2017-12-23 02:22:28 --> Hooks Class Initialized
DEBUG - 2017-12-23 02:22:28 --> UTF-8 Support Enabled
INFO - 2017-12-23 02:22:28 --> Utf8 Class Initialized
INFO - 2017-12-23 02:22:28 --> URI Class Initialized
INFO - 2017-12-23 02:22:28 --> Router Class Initialized
INFO - 2017-12-23 02:22:28 --> Output Class Initialized
INFO - 2017-12-23 02:22:28 --> Security Class Initialized
DEBUG - 2017-12-23 02:22:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-23 02:22:28 --> Input Class Initialized
INFO - 2017-12-23 02:22:28 --> Language Class Initialized
INFO - 2017-12-23 02:22:28 --> Loader Class Initialized
INFO - 2017-12-23 02:22:28 --> Helper loaded: url_helper
INFO - 2017-12-23 02:22:28 --> Helper loaded: form_helper
INFO - 2017-12-23 02:22:28 --> Database Driver Class Initialized
DEBUG - 2017-12-23 02:22:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-23 02:22:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-23 02:22:28 --> Form Validation Class Initialized
INFO - 2017-12-23 02:22:28 --> Model Class Initialized
INFO - 2017-12-23 02:22:28 --> Controller Class Initialized
INFO - 2017-12-23 02:22:28 --> Model Class Initialized
INFO - 2017-12-23 02:22:28 --> Model Class Initialized
INFO - 2017-12-23 02:22:28 --> Model Class Initialized
DEBUG - 2017-12-23 02:22:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-23 02:22:28 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-23 02:22:28 --> Final output sent to browser
DEBUG - 2017-12-23 02:22:28 --> Total execution time: 0.0631
