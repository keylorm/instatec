<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-12-28 01:23:10 --> Config Class Initialized
INFO - 2017-12-28 01:23:10 --> Hooks Class Initialized
DEBUG - 2017-12-28 01:23:10 --> UTF-8 Support Enabled
INFO - 2017-12-28 01:23:10 --> Utf8 Class Initialized
INFO - 2017-12-28 01:23:10 --> URI Class Initialized
INFO - 2017-12-28 01:23:10 --> Router Class Initialized
INFO - 2017-12-28 01:23:10 --> Output Class Initialized
INFO - 2017-12-28 01:23:10 --> Security Class Initialized
DEBUG - 2017-12-28 01:23:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 01:23:10 --> Input Class Initialized
INFO - 2017-12-28 01:23:10 --> Language Class Initialized
INFO - 2017-12-28 01:23:10 --> Loader Class Initialized
INFO - 2017-12-28 01:23:10 --> Helper loaded: url_helper
INFO - 2017-12-28 01:23:10 --> Helper loaded: form_helper
INFO - 2017-12-28 01:23:10 --> Database Driver Class Initialized
DEBUG - 2017-12-28 01:23:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 01:23:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 01:23:11 --> Form Validation Class Initialized
INFO - 2017-12-28 01:23:11 --> Model Class Initialized
INFO - 2017-12-28 01:23:11 --> Controller Class Initialized
INFO - 2017-12-28 01:23:11 --> Model Class Initialized
INFO - 2017-12-28 01:23:11 --> Model Class Initialized
INFO - 2017-12-28 01:23:11 --> Model Class Initialized
DEBUG - 2017-12-28 01:23:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 01:23:11 --> Config Class Initialized
INFO - 2017-12-28 01:23:11 --> Hooks Class Initialized
DEBUG - 2017-12-28 01:23:11 --> UTF-8 Support Enabled
INFO - 2017-12-28 01:23:11 --> Utf8 Class Initialized
INFO - 2017-12-28 01:23:11 --> URI Class Initialized
INFO - 2017-12-28 01:23:11 --> Router Class Initialized
INFO - 2017-12-28 01:23:11 --> Output Class Initialized
INFO - 2017-12-28 01:23:11 --> Security Class Initialized
DEBUG - 2017-12-28 01:23:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 01:23:11 --> Input Class Initialized
INFO - 2017-12-28 01:23:11 --> Language Class Initialized
INFO - 2017-12-28 01:23:11 --> Loader Class Initialized
INFO - 2017-12-28 01:23:11 --> Helper loaded: url_helper
INFO - 2017-12-28 01:23:11 --> Helper loaded: form_helper
INFO - 2017-12-28 01:23:11 --> Database Driver Class Initialized
DEBUG - 2017-12-28 01:23:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 01:23:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 01:23:11 --> Form Validation Class Initialized
INFO - 2017-12-28 01:23:11 --> Model Class Initialized
INFO - 2017-12-28 01:23:11 --> Controller Class Initialized
INFO - 2017-12-28 01:23:11 --> Model Class Initialized
DEBUG - 2017-12-28 01:23:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 01:23:11 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 01:23:11 --> Final output sent to browser
DEBUG - 2017-12-28 01:23:11 --> Total execution time: 0.1256
INFO - 2017-12-28 01:23:12 --> Config Class Initialized
INFO - 2017-12-28 01:23:12 --> Hooks Class Initialized
DEBUG - 2017-12-28 01:23:12 --> UTF-8 Support Enabled
INFO - 2017-12-28 01:23:12 --> Utf8 Class Initialized
INFO - 2017-12-28 01:23:12 --> URI Class Initialized
INFO - 2017-12-28 01:23:12 --> Router Class Initialized
INFO - 2017-12-28 01:23:12 --> Output Class Initialized
INFO - 2017-12-28 01:23:12 --> Security Class Initialized
DEBUG - 2017-12-28 01:23:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 01:23:12 --> Input Class Initialized
INFO - 2017-12-28 01:23:12 --> Language Class Initialized
INFO - 2017-12-28 01:23:12 --> Loader Class Initialized
INFO - 2017-12-28 01:23:12 --> Helper loaded: url_helper
INFO - 2017-12-28 01:23:12 --> Helper loaded: form_helper
INFO - 2017-12-28 01:23:12 --> Database Driver Class Initialized
DEBUG - 2017-12-28 01:23:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 01:23:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 01:23:12 --> Form Validation Class Initialized
INFO - 2017-12-28 01:23:12 --> Model Class Initialized
INFO - 2017-12-28 01:23:12 --> Controller Class Initialized
INFO - 2017-12-28 01:23:12 --> Model Class Initialized
DEBUG - 2017-12-28 01:23:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 01:23:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-12-28 01:23:12 --> Config Class Initialized
INFO - 2017-12-28 01:23:12 --> Hooks Class Initialized
DEBUG - 2017-12-28 01:23:12 --> UTF-8 Support Enabled
INFO - 2017-12-28 01:23:12 --> Utf8 Class Initialized
INFO - 2017-12-28 01:23:12 --> URI Class Initialized
DEBUG - 2017-12-28 01:23:12 --> No URI present. Default controller set.
INFO - 2017-12-28 01:23:12 --> Router Class Initialized
INFO - 2017-12-28 01:23:12 --> Output Class Initialized
INFO - 2017-12-28 01:23:12 --> Security Class Initialized
DEBUG - 2017-12-28 01:23:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 01:23:12 --> Input Class Initialized
INFO - 2017-12-28 01:23:12 --> Language Class Initialized
INFO - 2017-12-28 01:23:12 --> Loader Class Initialized
INFO - 2017-12-28 01:23:12 --> Helper loaded: url_helper
INFO - 2017-12-28 01:23:12 --> Helper loaded: form_helper
INFO - 2017-12-28 01:23:12 --> Database Driver Class Initialized
DEBUG - 2017-12-28 01:23:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 01:23:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 01:23:12 --> Form Validation Class Initialized
INFO - 2017-12-28 01:23:12 --> Model Class Initialized
INFO - 2017-12-28 01:23:12 --> Controller Class Initialized
INFO - 2017-12-28 01:23:12 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 01:23:12 --> Final output sent to browser
DEBUG - 2017-12-28 01:23:12 --> Total execution time: 0.1236
INFO - 2017-12-28 01:23:14 --> Config Class Initialized
INFO - 2017-12-28 01:23:14 --> Hooks Class Initialized
DEBUG - 2017-12-28 01:23:14 --> UTF-8 Support Enabled
INFO - 2017-12-28 01:23:14 --> Utf8 Class Initialized
INFO - 2017-12-28 01:23:14 --> URI Class Initialized
INFO - 2017-12-28 01:23:14 --> Router Class Initialized
INFO - 2017-12-28 01:23:14 --> Output Class Initialized
INFO - 2017-12-28 01:23:14 --> Security Class Initialized
DEBUG - 2017-12-28 01:23:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 01:23:14 --> Input Class Initialized
INFO - 2017-12-28 01:23:14 --> Language Class Initialized
INFO - 2017-12-28 01:23:14 --> Loader Class Initialized
INFO - 2017-12-28 01:23:14 --> Helper loaded: url_helper
INFO - 2017-12-28 01:23:14 --> Helper loaded: form_helper
INFO - 2017-12-28 01:23:14 --> Database Driver Class Initialized
DEBUG - 2017-12-28 01:23:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 01:23:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 01:23:14 --> Form Validation Class Initialized
INFO - 2017-12-28 01:23:14 --> Model Class Initialized
INFO - 2017-12-28 01:23:14 --> Controller Class Initialized
INFO - 2017-12-28 01:23:14 --> Model Class Initialized
INFO - 2017-12-28 01:23:14 --> Model Class Initialized
DEBUG - 2017-12-28 01:23:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 01:23:14 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 01:23:14 --> Final output sent to browser
DEBUG - 2017-12-28 01:23:14 --> Total execution time: 0.1149
INFO - 2017-12-28 01:23:14 --> Config Class Initialized
INFO - 2017-12-28 01:23:14 --> Hooks Class Initialized
DEBUG - 2017-12-28 01:23:14 --> UTF-8 Support Enabled
INFO - 2017-12-28 01:23:14 --> Utf8 Class Initialized
INFO - 2017-12-28 01:23:14 --> URI Class Initialized
INFO - 2017-12-28 01:23:14 --> Router Class Initialized
INFO - 2017-12-28 01:23:14 --> Output Class Initialized
INFO - 2017-12-28 01:23:14 --> Security Class Initialized
DEBUG - 2017-12-28 01:23:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 01:23:14 --> Input Class Initialized
INFO - 2017-12-28 01:23:14 --> Language Class Initialized
INFO - 2017-12-28 01:23:14 --> Loader Class Initialized
INFO - 2017-12-28 01:23:14 --> Helper loaded: url_helper
INFO - 2017-12-28 01:23:14 --> Helper loaded: form_helper
INFO - 2017-12-28 01:23:14 --> Database Driver Class Initialized
DEBUG - 2017-12-28 01:23:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 01:23:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 01:23:14 --> Form Validation Class Initialized
INFO - 2017-12-28 01:23:14 --> Model Class Initialized
INFO - 2017-12-28 01:23:14 --> Controller Class Initialized
INFO - 2017-12-28 01:23:14 --> Model Class Initialized
INFO - 2017-12-28 01:23:14 --> Model Class Initialized
DEBUG - 2017-12-28 01:23:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 01:23:15 --> Config Class Initialized
INFO - 2017-12-28 01:23:15 --> Hooks Class Initialized
DEBUG - 2017-12-28 01:23:15 --> UTF-8 Support Enabled
INFO - 2017-12-28 01:23:15 --> Utf8 Class Initialized
INFO - 2017-12-28 01:23:15 --> URI Class Initialized
INFO - 2017-12-28 01:23:15 --> Router Class Initialized
INFO - 2017-12-28 01:23:15 --> Output Class Initialized
INFO - 2017-12-28 01:23:15 --> Security Class Initialized
DEBUG - 2017-12-28 01:23:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 01:23:15 --> Input Class Initialized
INFO - 2017-12-28 01:23:15 --> Language Class Initialized
INFO - 2017-12-28 01:23:15 --> Loader Class Initialized
INFO - 2017-12-28 01:23:15 --> Helper loaded: url_helper
INFO - 2017-12-28 01:23:15 --> Helper loaded: form_helper
INFO - 2017-12-28 01:23:15 --> Database Driver Class Initialized
DEBUG - 2017-12-28 01:23:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 01:23:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 01:23:15 --> Form Validation Class Initialized
INFO - 2017-12-28 01:23:15 --> Model Class Initialized
INFO - 2017-12-28 01:23:15 --> Controller Class Initialized
INFO - 2017-12-28 01:23:15 --> Model Class Initialized
INFO - 2017-12-28 01:23:15 --> Model Class Initialized
DEBUG - 2017-12-28 01:23:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 01:23:15 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 01:23:15 --> Final output sent to browser
DEBUG - 2017-12-28 01:23:15 --> Total execution time: 0.1343
INFO - 2017-12-28 01:23:15 --> Config Class Initialized
INFO - 2017-12-28 01:23:15 --> Hooks Class Initialized
DEBUG - 2017-12-28 01:23:15 --> UTF-8 Support Enabled
INFO - 2017-12-28 01:23:15 --> Utf8 Class Initialized
INFO - 2017-12-28 01:23:15 --> URI Class Initialized
INFO - 2017-12-28 01:23:15 --> Router Class Initialized
INFO - 2017-12-28 01:23:15 --> Output Class Initialized
INFO - 2017-12-28 01:23:15 --> Security Class Initialized
DEBUG - 2017-12-28 01:23:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 01:23:15 --> Input Class Initialized
INFO - 2017-12-28 01:23:15 --> Language Class Initialized
INFO - 2017-12-28 01:23:15 --> Loader Class Initialized
INFO - 2017-12-28 01:23:15 --> Helper loaded: url_helper
INFO - 2017-12-28 01:23:15 --> Helper loaded: form_helper
INFO - 2017-12-28 01:23:15 --> Database Driver Class Initialized
DEBUG - 2017-12-28 01:23:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 01:23:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 01:23:15 --> Form Validation Class Initialized
INFO - 2017-12-28 01:23:15 --> Model Class Initialized
INFO - 2017-12-28 01:23:15 --> Controller Class Initialized
INFO - 2017-12-28 01:23:15 --> Model Class Initialized
INFO - 2017-12-28 01:23:15 --> Model Class Initialized
DEBUG - 2017-12-28 01:23:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 01:23:16 --> Config Class Initialized
INFO - 2017-12-28 01:23:16 --> Hooks Class Initialized
DEBUG - 2017-12-28 01:23:16 --> UTF-8 Support Enabled
INFO - 2017-12-28 01:23:16 --> Utf8 Class Initialized
INFO - 2017-12-28 01:23:16 --> URI Class Initialized
INFO - 2017-12-28 01:23:16 --> Router Class Initialized
INFO - 2017-12-28 01:23:16 --> Output Class Initialized
INFO - 2017-12-28 01:23:16 --> Security Class Initialized
DEBUG - 2017-12-28 01:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 01:23:16 --> Input Class Initialized
INFO - 2017-12-28 01:23:16 --> Language Class Initialized
INFO - 2017-12-28 01:23:16 --> Loader Class Initialized
INFO - 2017-12-28 01:23:16 --> Helper loaded: url_helper
INFO - 2017-12-28 01:23:16 --> Helper loaded: form_helper
INFO - 2017-12-28 01:23:16 --> Database Driver Class Initialized
DEBUG - 2017-12-28 01:23:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 01:23:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 01:23:16 --> Form Validation Class Initialized
INFO - 2017-12-28 01:23:16 --> Model Class Initialized
INFO - 2017-12-28 01:23:16 --> Controller Class Initialized
INFO - 2017-12-28 01:23:16 --> Model Class Initialized
INFO - 2017-12-28 01:23:16 --> Model Class Initialized
INFO - 2017-12-28 01:23:16 --> Model Class Initialized
DEBUG - 2017-12-28 01:23:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 01:23:16 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 01:23:16 --> Final output sent to browser
DEBUG - 2017-12-28 01:23:16 --> Total execution time: 0.1234
INFO - 2017-12-28 01:23:16 --> Config Class Initialized
INFO - 2017-12-28 01:23:16 --> Hooks Class Initialized
DEBUG - 2017-12-28 01:23:16 --> UTF-8 Support Enabled
INFO - 2017-12-28 01:23:16 --> Utf8 Class Initialized
INFO - 2017-12-28 01:23:16 --> URI Class Initialized
INFO - 2017-12-28 01:23:16 --> Router Class Initialized
INFO - 2017-12-28 01:23:16 --> Output Class Initialized
INFO - 2017-12-28 01:23:16 --> Security Class Initialized
DEBUG - 2017-12-28 01:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 01:23:16 --> Input Class Initialized
INFO - 2017-12-28 01:23:16 --> Language Class Initialized
INFO - 2017-12-28 01:23:16 --> Loader Class Initialized
INFO - 2017-12-28 01:23:16 --> Helper loaded: url_helper
INFO - 2017-12-28 01:23:16 --> Helper loaded: form_helper
INFO - 2017-12-28 01:23:16 --> Database Driver Class Initialized
DEBUG - 2017-12-28 01:23:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 01:23:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 01:23:16 --> Form Validation Class Initialized
INFO - 2017-12-28 01:23:16 --> Model Class Initialized
INFO - 2017-12-28 01:23:16 --> Controller Class Initialized
INFO - 2017-12-28 01:23:16 --> Model Class Initialized
INFO - 2017-12-28 01:23:16 --> Model Class Initialized
INFO - 2017-12-28 01:23:16 --> Model Class Initialized
DEBUG - 2017-12-28 01:23:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 01:23:19 --> Config Class Initialized
INFO - 2017-12-28 01:23:19 --> Hooks Class Initialized
DEBUG - 2017-12-28 01:23:19 --> UTF-8 Support Enabled
INFO - 2017-12-28 01:23:19 --> Utf8 Class Initialized
INFO - 2017-12-28 01:23:19 --> URI Class Initialized
INFO - 2017-12-28 01:23:19 --> Router Class Initialized
INFO - 2017-12-28 01:23:19 --> Output Class Initialized
INFO - 2017-12-28 01:23:19 --> Security Class Initialized
DEBUG - 2017-12-28 01:23:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 01:23:19 --> Input Class Initialized
INFO - 2017-12-28 01:23:19 --> Language Class Initialized
INFO - 2017-12-28 01:23:19 --> Loader Class Initialized
INFO - 2017-12-28 01:23:19 --> Helper loaded: url_helper
INFO - 2017-12-28 01:23:19 --> Helper loaded: form_helper
INFO - 2017-12-28 01:23:19 --> Database Driver Class Initialized
DEBUG - 2017-12-28 01:23:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 01:23:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 01:23:19 --> Form Validation Class Initialized
INFO - 2017-12-28 01:23:19 --> Model Class Initialized
INFO - 2017-12-28 01:23:19 --> Controller Class Initialized
INFO - 2017-12-28 01:23:19 --> Model Class Initialized
INFO - 2017-12-28 01:23:19 --> Model Class Initialized
INFO - 2017-12-28 01:23:19 --> Model Class Initialized
DEBUG - 2017-12-28 01:23:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 01:23:19 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 01:23:19 --> Final output sent to browser
DEBUG - 2017-12-28 01:23:19 --> Total execution time: 0.1410
INFO - 2017-12-28 01:23:19 --> Config Class Initialized
INFO - 2017-12-28 01:23:19 --> Hooks Class Initialized
DEBUG - 2017-12-28 01:23:19 --> UTF-8 Support Enabled
INFO - 2017-12-28 01:23:19 --> Utf8 Class Initialized
INFO - 2017-12-28 01:23:20 --> URI Class Initialized
INFO - 2017-12-28 01:23:20 --> Router Class Initialized
INFO - 2017-12-28 01:23:20 --> Output Class Initialized
INFO - 2017-12-28 01:23:20 --> Security Class Initialized
DEBUG - 2017-12-28 01:23:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 01:23:20 --> Input Class Initialized
INFO - 2017-12-28 01:23:20 --> Language Class Initialized
INFO - 2017-12-28 01:23:20 --> Loader Class Initialized
INFO - 2017-12-28 01:23:20 --> Helper loaded: url_helper
INFO - 2017-12-28 01:23:20 --> Helper loaded: form_helper
INFO - 2017-12-28 01:23:20 --> Database Driver Class Initialized
DEBUG - 2017-12-28 01:23:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 01:23:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 01:23:20 --> Form Validation Class Initialized
INFO - 2017-12-28 01:23:20 --> Model Class Initialized
INFO - 2017-12-28 01:23:20 --> Controller Class Initialized
INFO - 2017-12-28 01:23:20 --> Model Class Initialized
INFO - 2017-12-28 01:23:20 --> Model Class Initialized
INFO - 2017-12-28 01:23:20 --> Model Class Initialized
DEBUG - 2017-12-28 01:23:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 01:23:23 --> Config Class Initialized
INFO - 2017-12-28 01:23:23 --> Hooks Class Initialized
DEBUG - 2017-12-28 01:23:23 --> UTF-8 Support Enabled
INFO - 2017-12-28 01:23:23 --> Utf8 Class Initialized
INFO - 2017-12-28 01:23:23 --> URI Class Initialized
INFO - 2017-12-28 01:23:23 --> Router Class Initialized
INFO - 2017-12-28 01:23:23 --> Output Class Initialized
INFO - 2017-12-28 01:23:23 --> Security Class Initialized
DEBUG - 2017-12-28 01:23:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 01:23:23 --> Input Class Initialized
INFO - 2017-12-28 01:23:23 --> Language Class Initialized
INFO - 2017-12-28 01:23:23 --> Loader Class Initialized
INFO - 2017-12-28 01:23:23 --> Helper loaded: url_helper
INFO - 2017-12-28 01:23:23 --> Helper loaded: form_helper
INFO - 2017-12-28 01:23:23 --> Database Driver Class Initialized
DEBUG - 2017-12-28 01:23:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 01:23:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 01:23:23 --> Form Validation Class Initialized
INFO - 2017-12-28 01:23:23 --> Model Class Initialized
INFO - 2017-12-28 01:23:23 --> Controller Class Initialized
INFO - 2017-12-28 01:23:23 --> Model Class Initialized
INFO - 2017-12-28 01:23:23 --> Model Class Initialized
INFO - 2017-12-28 01:23:23 --> Model Class Initialized
DEBUG - 2017-12-28 01:23:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 01:23:23 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 01:23:23 --> Final output sent to browser
DEBUG - 2017-12-28 01:23:23 --> Total execution time: 0.1113
INFO - 2017-12-28 01:23:23 --> Config Class Initialized
INFO - 2017-12-28 01:23:23 --> Hooks Class Initialized
DEBUG - 2017-12-28 01:23:23 --> UTF-8 Support Enabled
INFO - 2017-12-28 01:23:23 --> Utf8 Class Initialized
INFO - 2017-12-28 01:23:23 --> URI Class Initialized
INFO - 2017-12-28 01:23:23 --> Router Class Initialized
INFO - 2017-12-28 01:23:23 --> Output Class Initialized
INFO - 2017-12-28 01:23:23 --> Security Class Initialized
DEBUG - 2017-12-28 01:23:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 01:23:23 --> Input Class Initialized
INFO - 2017-12-28 01:23:23 --> Language Class Initialized
INFO - 2017-12-28 01:23:23 --> Loader Class Initialized
INFO - 2017-12-28 01:23:23 --> Helper loaded: url_helper
INFO - 2017-12-28 01:23:23 --> Helper loaded: form_helper
INFO - 2017-12-28 01:23:23 --> Database Driver Class Initialized
DEBUG - 2017-12-28 01:23:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 01:23:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 01:23:23 --> Form Validation Class Initialized
INFO - 2017-12-28 01:23:23 --> Model Class Initialized
INFO - 2017-12-28 01:23:23 --> Controller Class Initialized
INFO - 2017-12-28 01:23:23 --> Model Class Initialized
INFO - 2017-12-28 01:23:23 --> Model Class Initialized
INFO - 2017-12-28 01:23:23 --> Model Class Initialized
DEBUG - 2017-12-28 01:23:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 04:22:07 --> Config Class Initialized
INFO - 2017-12-28 04:22:07 --> Hooks Class Initialized
DEBUG - 2017-12-28 04:22:07 --> UTF-8 Support Enabled
INFO - 2017-12-28 04:22:07 --> Utf8 Class Initialized
INFO - 2017-12-28 04:22:07 --> URI Class Initialized
INFO - 2017-12-28 04:22:07 --> Router Class Initialized
INFO - 2017-12-28 04:22:07 --> Output Class Initialized
INFO - 2017-12-28 04:22:07 --> Security Class Initialized
DEBUG - 2017-12-28 04:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 04:22:07 --> Input Class Initialized
INFO - 2017-12-28 04:22:07 --> Language Class Initialized
INFO - 2017-12-28 04:22:07 --> Loader Class Initialized
INFO - 2017-12-28 04:22:07 --> Helper loaded: url_helper
INFO - 2017-12-28 04:22:07 --> Helper loaded: form_helper
INFO - 2017-12-28 04:22:07 --> Database Driver Class Initialized
DEBUG - 2017-12-28 04:22:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 04:22:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 04:22:07 --> Form Validation Class Initialized
INFO - 2017-12-28 04:22:07 --> Model Class Initialized
INFO - 2017-12-28 04:22:07 --> Controller Class Initialized
INFO - 2017-12-28 04:22:07 --> Model Class Initialized
INFO - 2017-12-28 04:22:07 --> Model Class Initialized
INFO - 2017-12-28 04:22:07 --> Model Class Initialized
DEBUG - 2017-12-28 04:22:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 04:22:07 --> Config Class Initialized
INFO - 2017-12-28 04:22:07 --> Hooks Class Initialized
DEBUG - 2017-12-28 04:22:07 --> UTF-8 Support Enabled
INFO - 2017-12-28 04:22:07 --> Utf8 Class Initialized
INFO - 2017-12-28 04:22:07 --> URI Class Initialized
INFO - 2017-12-28 04:22:07 --> Router Class Initialized
INFO - 2017-12-28 04:22:07 --> Output Class Initialized
INFO - 2017-12-28 04:22:07 --> Security Class Initialized
DEBUG - 2017-12-28 04:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 04:22:07 --> Input Class Initialized
INFO - 2017-12-28 04:22:07 --> Language Class Initialized
INFO - 2017-12-28 04:22:07 --> Loader Class Initialized
INFO - 2017-12-28 04:22:07 --> Helper loaded: url_helper
INFO - 2017-12-28 04:22:07 --> Helper loaded: form_helper
INFO - 2017-12-28 04:22:07 --> Database Driver Class Initialized
DEBUG - 2017-12-28 04:22:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 04:22:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 04:22:07 --> Form Validation Class Initialized
INFO - 2017-12-28 04:22:07 --> Model Class Initialized
INFO - 2017-12-28 04:22:07 --> Controller Class Initialized
INFO - 2017-12-28 04:22:07 --> Model Class Initialized
DEBUG - 2017-12-28 04:22:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 04:22:07 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 04:22:07 --> Final output sent to browser
DEBUG - 2017-12-28 04:22:07 --> Total execution time: 0.0952
INFO - 2017-12-28 04:22:09 --> Config Class Initialized
INFO - 2017-12-28 04:22:09 --> Hooks Class Initialized
DEBUG - 2017-12-28 04:22:09 --> UTF-8 Support Enabled
INFO - 2017-12-28 04:22:09 --> Utf8 Class Initialized
INFO - 2017-12-28 04:22:09 --> URI Class Initialized
INFO - 2017-12-28 04:22:09 --> Router Class Initialized
INFO - 2017-12-28 04:22:09 --> Output Class Initialized
INFO - 2017-12-28 04:22:09 --> Security Class Initialized
DEBUG - 2017-12-28 04:22:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 04:22:09 --> Input Class Initialized
INFO - 2017-12-28 04:22:09 --> Language Class Initialized
INFO - 2017-12-28 04:22:09 --> Loader Class Initialized
INFO - 2017-12-28 04:22:09 --> Helper loaded: url_helper
INFO - 2017-12-28 04:22:09 --> Helper loaded: form_helper
INFO - 2017-12-28 04:22:09 --> Database Driver Class Initialized
DEBUG - 2017-12-28 04:22:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 04:22:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 04:22:09 --> Form Validation Class Initialized
INFO - 2017-12-28 04:22:09 --> Model Class Initialized
INFO - 2017-12-28 04:22:09 --> Controller Class Initialized
INFO - 2017-12-28 04:22:09 --> Model Class Initialized
DEBUG - 2017-12-28 04:22:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 04:22:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-12-28 04:22:09 --> Config Class Initialized
INFO - 2017-12-28 04:22:09 --> Hooks Class Initialized
DEBUG - 2017-12-28 04:22:09 --> UTF-8 Support Enabled
INFO - 2017-12-28 04:22:09 --> Utf8 Class Initialized
INFO - 2017-12-28 04:22:09 --> URI Class Initialized
DEBUG - 2017-12-28 04:22:09 --> No URI present. Default controller set.
INFO - 2017-12-28 04:22:09 --> Router Class Initialized
INFO - 2017-12-28 04:22:09 --> Output Class Initialized
INFO - 2017-12-28 04:22:09 --> Security Class Initialized
DEBUG - 2017-12-28 04:22:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 04:22:09 --> Input Class Initialized
INFO - 2017-12-28 04:22:09 --> Language Class Initialized
INFO - 2017-12-28 04:22:09 --> Loader Class Initialized
INFO - 2017-12-28 04:22:09 --> Helper loaded: url_helper
INFO - 2017-12-28 04:22:09 --> Helper loaded: form_helper
INFO - 2017-12-28 04:22:09 --> Database Driver Class Initialized
DEBUG - 2017-12-28 04:22:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 04:22:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 04:22:09 --> Form Validation Class Initialized
INFO - 2017-12-28 04:22:09 --> Model Class Initialized
INFO - 2017-12-28 04:22:09 --> Controller Class Initialized
INFO - 2017-12-28 04:22:09 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 04:22:09 --> Final output sent to browser
DEBUG - 2017-12-28 04:22:09 --> Total execution time: 0.0855
INFO - 2017-12-28 04:22:17 --> Config Class Initialized
INFO - 2017-12-28 04:22:17 --> Hooks Class Initialized
DEBUG - 2017-12-28 04:22:17 --> UTF-8 Support Enabled
INFO - 2017-12-28 04:22:17 --> Utf8 Class Initialized
INFO - 2017-12-28 04:22:17 --> URI Class Initialized
INFO - 2017-12-28 04:22:17 --> Router Class Initialized
INFO - 2017-12-28 04:22:17 --> Output Class Initialized
INFO - 2017-12-28 04:22:17 --> Security Class Initialized
DEBUG - 2017-12-28 04:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 04:22:17 --> Input Class Initialized
INFO - 2017-12-28 04:22:17 --> Language Class Initialized
INFO - 2017-12-28 04:22:17 --> Loader Class Initialized
INFO - 2017-12-28 04:22:17 --> Helper loaded: url_helper
INFO - 2017-12-28 04:22:17 --> Helper loaded: form_helper
INFO - 2017-12-28 04:22:17 --> Database Driver Class Initialized
DEBUG - 2017-12-28 04:22:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 04:22:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 04:22:17 --> Form Validation Class Initialized
INFO - 2017-12-28 04:22:17 --> Model Class Initialized
INFO - 2017-12-28 04:22:17 --> Controller Class Initialized
INFO - 2017-12-28 04:22:17 --> Model Class Initialized
INFO - 2017-12-28 04:22:17 --> Model Class Initialized
INFO - 2017-12-28 04:22:17 --> Model Class Initialized
DEBUG - 2017-12-28 04:22:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 04:22:17 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 04:22:17 --> Final output sent to browser
DEBUG - 2017-12-28 04:22:17 --> Total execution time: 0.0644
INFO - 2017-12-28 04:22:17 --> Config Class Initialized
INFO - 2017-12-28 04:22:17 --> Hooks Class Initialized
DEBUG - 2017-12-28 04:22:17 --> UTF-8 Support Enabled
INFO - 2017-12-28 04:22:17 --> Utf8 Class Initialized
INFO - 2017-12-28 04:22:17 --> URI Class Initialized
INFO - 2017-12-28 04:22:17 --> Router Class Initialized
INFO - 2017-12-28 04:22:17 --> Output Class Initialized
INFO - 2017-12-28 04:22:17 --> Security Class Initialized
DEBUG - 2017-12-28 04:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 04:22:17 --> Input Class Initialized
INFO - 2017-12-28 04:22:17 --> Language Class Initialized
INFO - 2017-12-28 04:22:17 --> Loader Class Initialized
INFO - 2017-12-28 04:22:17 --> Helper loaded: url_helper
INFO - 2017-12-28 04:22:17 --> Helper loaded: form_helper
INFO - 2017-12-28 04:22:17 --> Database Driver Class Initialized
DEBUG - 2017-12-28 04:22:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 04:22:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 04:22:17 --> Form Validation Class Initialized
INFO - 2017-12-28 04:22:17 --> Model Class Initialized
INFO - 2017-12-28 04:22:17 --> Controller Class Initialized
INFO - 2017-12-28 04:22:17 --> Model Class Initialized
INFO - 2017-12-28 04:22:17 --> Model Class Initialized
INFO - 2017-12-28 04:22:17 --> Model Class Initialized
DEBUG - 2017-12-28 04:22:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 04:22:21 --> Config Class Initialized
INFO - 2017-12-28 04:22:21 --> Hooks Class Initialized
DEBUG - 2017-12-28 04:22:21 --> UTF-8 Support Enabled
INFO - 2017-12-28 04:22:21 --> Utf8 Class Initialized
INFO - 2017-12-28 04:22:21 --> URI Class Initialized
INFO - 2017-12-28 04:22:21 --> Router Class Initialized
INFO - 2017-12-28 04:22:21 --> Output Class Initialized
INFO - 2017-12-28 04:22:21 --> Security Class Initialized
DEBUG - 2017-12-28 04:22:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 04:22:21 --> Input Class Initialized
INFO - 2017-12-28 04:22:21 --> Language Class Initialized
INFO - 2017-12-28 04:22:21 --> Loader Class Initialized
INFO - 2017-12-28 04:22:21 --> Helper loaded: url_helper
INFO - 2017-12-28 04:22:21 --> Helper loaded: form_helper
INFO - 2017-12-28 04:22:21 --> Database Driver Class Initialized
DEBUG - 2017-12-28 04:22:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 04:22:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 04:22:21 --> Form Validation Class Initialized
INFO - 2017-12-28 04:22:21 --> Model Class Initialized
INFO - 2017-12-28 04:22:21 --> Controller Class Initialized
INFO - 2017-12-28 04:22:21 --> Model Class Initialized
INFO - 2017-12-28 04:22:21 --> Model Class Initialized
INFO - 2017-12-28 04:22:21 --> Model Class Initialized
DEBUG - 2017-12-28 04:22:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 04:22:21 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 04:22:21 --> Final output sent to browser
DEBUG - 2017-12-28 04:22:21 --> Total execution time: 0.0720
INFO - 2017-12-28 04:22:21 --> Config Class Initialized
INFO - 2017-12-28 04:22:21 --> Hooks Class Initialized
DEBUG - 2017-12-28 04:22:21 --> UTF-8 Support Enabled
INFO - 2017-12-28 04:22:21 --> Utf8 Class Initialized
INFO - 2017-12-28 04:22:21 --> URI Class Initialized
INFO - 2017-12-28 04:22:21 --> Router Class Initialized
INFO - 2017-12-28 04:22:21 --> Output Class Initialized
INFO - 2017-12-28 04:22:21 --> Security Class Initialized
DEBUG - 2017-12-28 04:22:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 04:22:21 --> Input Class Initialized
INFO - 2017-12-28 04:22:21 --> Language Class Initialized
INFO - 2017-12-28 04:22:21 --> Loader Class Initialized
INFO - 2017-12-28 04:22:21 --> Helper loaded: url_helper
INFO - 2017-12-28 04:22:21 --> Helper loaded: form_helper
INFO - 2017-12-28 04:22:21 --> Database Driver Class Initialized
DEBUG - 2017-12-28 04:22:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 04:22:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 04:22:21 --> Form Validation Class Initialized
INFO - 2017-12-28 04:22:21 --> Model Class Initialized
INFO - 2017-12-28 04:22:21 --> Controller Class Initialized
INFO - 2017-12-28 04:22:22 --> Model Class Initialized
INFO - 2017-12-28 04:22:22 --> Model Class Initialized
INFO - 2017-12-28 04:22:22 --> Model Class Initialized
DEBUG - 2017-12-28 04:22:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 04:22:22 --> Config Class Initialized
INFO - 2017-12-28 04:22:22 --> Hooks Class Initialized
DEBUG - 2017-12-28 04:22:22 --> UTF-8 Support Enabled
INFO - 2017-12-28 04:22:22 --> Utf8 Class Initialized
INFO - 2017-12-28 04:22:22 --> URI Class Initialized
INFO - 2017-12-28 04:22:22 --> Router Class Initialized
INFO - 2017-12-28 04:22:22 --> Output Class Initialized
INFO - 2017-12-28 04:22:22 --> Security Class Initialized
DEBUG - 2017-12-28 04:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 04:22:22 --> Input Class Initialized
INFO - 2017-12-28 04:22:22 --> Language Class Initialized
INFO - 2017-12-28 04:22:22 --> Loader Class Initialized
INFO - 2017-12-28 04:22:22 --> Helper loaded: url_helper
INFO - 2017-12-28 04:22:22 --> Helper loaded: form_helper
INFO - 2017-12-28 04:22:22 --> Database Driver Class Initialized
DEBUG - 2017-12-28 04:22:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 04:22:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 04:22:22 --> Form Validation Class Initialized
INFO - 2017-12-28 04:22:22 --> Model Class Initialized
INFO - 2017-12-28 04:22:22 --> Controller Class Initialized
INFO - 2017-12-28 04:22:22 --> Model Class Initialized
INFO - 2017-12-28 04:22:22 --> Model Class Initialized
INFO - 2017-12-28 04:22:22 --> Model Class Initialized
DEBUG - 2017-12-28 04:22:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 04:22:22 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 04:22:22 --> Final output sent to browser
DEBUG - 2017-12-28 04:22:22 --> Total execution time: 0.0674
INFO - 2017-12-28 04:22:22 --> Config Class Initialized
INFO - 2017-12-28 04:22:22 --> Hooks Class Initialized
DEBUG - 2017-12-28 04:22:22 --> UTF-8 Support Enabled
INFO - 2017-12-28 04:22:22 --> Utf8 Class Initialized
INFO - 2017-12-28 04:22:22 --> URI Class Initialized
INFO - 2017-12-28 04:22:22 --> Router Class Initialized
INFO - 2017-12-28 04:22:22 --> Output Class Initialized
INFO - 2017-12-28 04:22:22 --> Security Class Initialized
DEBUG - 2017-12-28 04:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 04:22:22 --> Input Class Initialized
INFO - 2017-12-28 04:22:22 --> Language Class Initialized
INFO - 2017-12-28 04:22:22 --> Loader Class Initialized
INFO - 2017-12-28 04:22:22 --> Helper loaded: url_helper
INFO - 2017-12-28 04:22:22 --> Helper loaded: form_helper
INFO - 2017-12-28 04:22:22 --> Database Driver Class Initialized
DEBUG - 2017-12-28 04:22:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 04:22:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 04:22:22 --> Form Validation Class Initialized
INFO - 2017-12-28 04:22:22 --> Model Class Initialized
INFO - 2017-12-28 04:22:22 --> Controller Class Initialized
INFO - 2017-12-28 04:22:22 --> Model Class Initialized
INFO - 2017-12-28 04:22:22 --> Model Class Initialized
INFO - 2017-12-28 04:22:22 --> Model Class Initialized
DEBUG - 2017-12-28 04:22:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 04:22:25 --> Config Class Initialized
INFO - 2017-12-28 04:22:25 --> Hooks Class Initialized
DEBUG - 2017-12-28 04:22:25 --> UTF-8 Support Enabled
INFO - 2017-12-28 04:22:25 --> Utf8 Class Initialized
INFO - 2017-12-28 04:22:25 --> URI Class Initialized
INFO - 2017-12-28 04:22:25 --> Router Class Initialized
INFO - 2017-12-28 04:22:25 --> Output Class Initialized
INFO - 2017-12-28 04:22:25 --> Security Class Initialized
DEBUG - 2017-12-28 04:22:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 04:22:25 --> Input Class Initialized
INFO - 2017-12-28 04:22:25 --> Language Class Initialized
INFO - 2017-12-28 04:22:25 --> Loader Class Initialized
INFO - 2017-12-28 04:22:25 --> Helper loaded: url_helper
INFO - 2017-12-28 04:22:25 --> Helper loaded: form_helper
INFO - 2017-12-28 04:22:25 --> Database Driver Class Initialized
DEBUG - 2017-12-28 04:22:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 04:22:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 04:22:25 --> Form Validation Class Initialized
INFO - 2017-12-28 04:22:25 --> Model Class Initialized
INFO - 2017-12-28 04:22:25 --> Controller Class Initialized
INFO - 2017-12-28 04:22:25 --> Model Class Initialized
INFO - 2017-12-28 04:22:25 --> Model Class Initialized
INFO - 2017-12-28 04:22:25 --> Model Class Initialized
DEBUG - 2017-12-28 04:22:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 04:22:25 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 04:22:25 --> Final output sent to browser
DEBUG - 2017-12-28 04:22:25 --> Total execution time: 0.0968
INFO - 2017-12-28 04:22:36 --> Config Class Initialized
INFO - 2017-12-28 04:22:36 --> Hooks Class Initialized
INFO - 2017-12-28 04:22:36 --> Config Class Initialized
INFO - 2017-12-28 04:22:36 --> Hooks Class Initialized
DEBUG - 2017-12-28 04:22:36 --> UTF-8 Support Enabled
INFO - 2017-12-28 04:22:36 --> Utf8 Class Initialized
DEBUG - 2017-12-28 04:22:36 --> UTF-8 Support Enabled
INFO - 2017-12-28 04:22:36 --> Utf8 Class Initialized
INFO - 2017-12-28 04:22:36 --> URI Class Initialized
INFO - 2017-12-28 04:22:36 --> URI Class Initialized
INFO - 2017-12-28 04:22:36 --> Router Class Initialized
INFO - 2017-12-28 04:22:36 --> Router Class Initialized
INFO - 2017-12-28 04:22:36 --> Output Class Initialized
INFO - 2017-12-28 04:22:36 --> Output Class Initialized
INFO - 2017-12-28 04:22:36 --> Security Class Initialized
INFO - 2017-12-28 04:22:36 --> Security Class Initialized
DEBUG - 2017-12-28 04:22:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 04:22:36 --> Input Class Initialized
DEBUG - 2017-12-28 04:22:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 04:22:36 --> Input Class Initialized
INFO - 2017-12-28 04:22:36 --> Language Class Initialized
INFO - 2017-12-28 04:22:36 --> Language Class Initialized
ERROR - 2017-12-28 04:22:36 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-28 04:22:36 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-28 04:27:50 --> Config Class Initialized
INFO - 2017-12-28 04:27:50 --> Hooks Class Initialized
DEBUG - 2017-12-28 04:27:50 --> UTF-8 Support Enabled
INFO - 2017-12-28 04:27:50 --> Utf8 Class Initialized
INFO - 2017-12-28 04:27:50 --> URI Class Initialized
INFO - 2017-12-28 04:27:50 --> Router Class Initialized
INFO - 2017-12-28 04:27:50 --> Output Class Initialized
INFO - 2017-12-28 04:27:50 --> Security Class Initialized
DEBUG - 2017-12-28 04:27:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 04:27:50 --> Input Class Initialized
INFO - 2017-12-28 04:27:50 --> Language Class Initialized
INFO - 2017-12-28 04:27:50 --> Loader Class Initialized
INFO - 2017-12-28 04:27:50 --> Helper loaded: url_helper
INFO - 2017-12-28 04:27:50 --> Helper loaded: form_helper
INFO - 2017-12-28 04:27:50 --> Database Driver Class Initialized
DEBUG - 2017-12-28 04:27:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 04:27:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 04:27:50 --> Form Validation Class Initialized
INFO - 2017-12-28 04:27:50 --> Model Class Initialized
INFO - 2017-12-28 04:27:50 --> Controller Class Initialized
INFO - 2017-12-28 04:27:50 --> Model Class Initialized
INFO - 2017-12-28 04:27:50 --> Model Class Initialized
INFO - 2017-12-28 04:27:50 --> Model Class Initialized
DEBUG - 2017-12-28 04:27:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 04:27:50 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 04:27:50 --> Final output sent to browser
DEBUG - 2017-12-28 04:27:50 --> Total execution time: 0.0502
INFO - 2017-12-28 04:27:50 --> Config Class Initialized
INFO - 2017-12-28 04:27:50 --> Hooks Class Initialized
DEBUG - 2017-12-28 04:27:50 --> UTF-8 Support Enabled
INFO - 2017-12-28 04:27:50 --> Utf8 Class Initialized
INFO - 2017-12-28 04:27:50 --> Config Class Initialized
INFO - 2017-12-28 04:27:50 --> Hooks Class Initialized
INFO - 2017-12-28 04:27:50 --> Config Class Initialized
INFO - 2017-12-28 04:27:50 --> Hooks Class Initialized
INFO - 2017-12-28 04:27:50 --> URI Class Initialized
INFO - 2017-12-28 04:27:50 --> Router Class Initialized
DEBUG - 2017-12-28 04:27:50 --> UTF-8 Support Enabled
INFO - 2017-12-28 04:27:50 --> Utf8 Class Initialized
DEBUG - 2017-12-28 04:27:50 --> UTF-8 Support Enabled
INFO - 2017-12-28 04:27:50 --> Utf8 Class Initialized
INFO - 2017-12-28 04:27:50 --> URI Class Initialized
INFO - 2017-12-28 04:27:50 --> Output Class Initialized
INFO - 2017-12-28 04:27:50 --> URI Class Initialized
INFO - 2017-12-28 04:27:50 --> Router Class Initialized
INFO - 2017-12-28 04:27:50 --> Security Class Initialized
INFO - 2017-12-28 04:27:50 --> Router Class Initialized
DEBUG - 2017-12-28 04:27:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 04:27:50 --> Input Class Initialized
INFO - 2017-12-28 04:27:50 --> Output Class Initialized
INFO - 2017-12-28 04:27:50 --> Output Class Initialized
INFO - 2017-12-28 04:27:50 --> Language Class Initialized
INFO - 2017-12-28 04:27:50 --> Security Class Initialized
INFO - 2017-12-28 04:27:50 --> Security Class Initialized
ERROR - 2017-12-28 04:27:50 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2017-12-28 04:27:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 04:27:50 --> Input Class Initialized
DEBUG - 2017-12-28 04:27:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 04:27:50 --> Input Class Initialized
INFO - 2017-12-28 04:27:50 --> Language Class Initialized
INFO - 2017-12-28 04:27:50 --> Language Class Initialized
ERROR - 2017-12-28 04:27:50 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-28 04:27:50 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-28 04:37:29 --> Config Class Initialized
INFO - 2017-12-28 04:37:29 --> Hooks Class Initialized
DEBUG - 2017-12-28 04:37:29 --> UTF-8 Support Enabled
INFO - 2017-12-28 04:37:29 --> Utf8 Class Initialized
INFO - 2017-12-28 04:37:29 --> URI Class Initialized
INFO - 2017-12-28 04:37:29 --> Router Class Initialized
INFO - 2017-12-28 04:37:29 --> Output Class Initialized
INFO - 2017-12-28 04:37:29 --> Security Class Initialized
DEBUG - 2017-12-28 04:37:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 04:37:29 --> Input Class Initialized
INFO - 2017-12-28 04:37:29 --> Language Class Initialized
INFO - 2017-12-28 04:37:29 --> Loader Class Initialized
INFO - 2017-12-28 04:37:29 --> Helper loaded: url_helper
INFO - 2017-12-28 04:37:29 --> Helper loaded: form_helper
INFO - 2017-12-28 04:37:29 --> Database Driver Class Initialized
DEBUG - 2017-12-28 04:37:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 04:37:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 04:37:29 --> Form Validation Class Initialized
INFO - 2017-12-28 04:37:29 --> Model Class Initialized
INFO - 2017-12-28 04:37:29 --> Controller Class Initialized
INFO - 2017-12-28 04:37:29 --> Model Class Initialized
INFO - 2017-12-28 04:37:29 --> Model Class Initialized
INFO - 2017-12-28 04:37:29 --> Model Class Initialized
DEBUG - 2017-12-28 04:37:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 04:37:29 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 04:37:29 --> Final output sent to browser
DEBUG - 2017-12-28 04:37:29 --> Total execution time: 0.0597
INFO - 2017-12-28 04:37:53 --> Config Class Initialized
INFO - 2017-12-28 04:37:53 --> Hooks Class Initialized
DEBUG - 2017-12-28 04:37:53 --> UTF-8 Support Enabled
INFO - 2017-12-28 04:37:53 --> Utf8 Class Initialized
INFO - 2017-12-28 04:37:53 --> URI Class Initialized
INFO - 2017-12-28 04:37:53 --> Router Class Initialized
INFO - 2017-12-28 04:37:53 --> Output Class Initialized
INFO - 2017-12-28 04:37:53 --> Security Class Initialized
DEBUG - 2017-12-28 04:37:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 04:37:53 --> Input Class Initialized
INFO - 2017-12-28 04:37:53 --> Language Class Initialized
ERROR - 2017-12-28 04:37:53 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-28 04:37:53 --> Config Class Initialized
INFO - 2017-12-28 04:37:53 --> Hooks Class Initialized
INFO - 2017-12-28 04:37:53 --> Config Class Initialized
INFO - 2017-12-28 04:37:53 --> Hooks Class Initialized
DEBUG - 2017-12-28 04:37:53 --> UTF-8 Support Enabled
INFO - 2017-12-28 04:37:53 --> Utf8 Class Initialized
DEBUG - 2017-12-28 04:37:53 --> UTF-8 Support Enabled
INFO - 2017-12-28 04:37:53 --> Utf8 Class Initialized
INFO - 2017-12-28 04:37:53 --> URI Class Initialized
INFO - 2017-12-28 04:37:53 --> URI Class Initialized
INFO - 2017-12-28 04:37:53 --> Router Class Initialized
INFO - 2017-12-28 04:37:53 --> Router Class Initialized
INFO - 2017-12-28 04:37:53 --> Output Class Initialized
INFO - 2017-12-28 04:37:53 --> Output Class Initialized
INFO - 2017-12-28 04:37:53 --> Security Class Initialized
INFO - 2017-12-28 04:37:53 --> Security Class Initialized
DEBUG - 2017-12-28 04:37:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 04:37:53 --> Input Class Initialized
DEBUG - 2017-12-28 04:37:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 04:37:53 --> Language Class Initialized
INFO - 2017-12-28 04:37:53 --> Input Class Initialized
INFO - 2017-12-28 04:37:53 --> Language Class Initialized
ERROR - 2017-12-28 04:37:53 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-28 04:37:53 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-28 04:38:24 --> Config Class Initialized
INFO - 2017-12-28 04:38:24 --> Hooks Class Initialized
DEBUG - 2017-12-28 04:38:24 --> UTF-8 Support Enabled
INFO - 2017-12-28 04:38:24 --> Utf8 Class Initialized
INFO - 2017-12-28 04:38:24 --> URI Class Initialized
INFO - 2017-12-28 04:38:24 --> Router Class Initialized
INFO - 2017-12-28 04:38:24 --> Output Class Initialized
INFO - 2017-12-28 04:38:24 --> Security Class Initialized
DEBUG - 2017-12-28 04:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 04:38:24 --> Input Class Initialized
INFO - 2017-12-28 04:38:24 --> Language Class Initialized
INFO - 2017-12-28 04:38:24 --> Loader Class Initialized
INFO - 2017-12-28 04:38:24 --> Helper loaded: url_helper
INFO - 2017-12-28 04:38:24 --> Helper loaded: form_helper
INFO - 2017-12-28 04:38:24 --> Database Driver Class Initialized
DEBUG - 2017-12-28 04:38:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 04:38:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 04:38:24 --> Form Validation Class Initialized
INFO - 2017-12-28 04:38:24 --> Model Class Initialized
INFO - 2017-12-28 04:38:24 --> Controller Class Initialized
INFO - 2017-12-28 04:38:24 --> Model Class Initialized
INFO - 2017-12-28 04:38:24 --> Model Class Initialized
INFO - 2017-12-28 04:38:24 --> Model Class Initialized
DEBUG - 2017-12-28 04:38:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 04:38:24 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 04:38:24 --> Final output sent to browser
DEBUG - 2017-12-28 04:38:24 --> Total execution time: 0.1245
INFO - 2017-12-28 04:38:25 --> Config Class Initialized
INFO - 2017-12-28 04:38:25 --> Hooks Class Initialized
DEBUG - 2017-12-28 04:38:25 --> UTF-8 Support Enabled
INFO - 2017-12-28 04:38:25 --> Utf8 Class Initialized
INFO - 2017-12-28 04:38:25 --> URI Class Initialized
INFO - 2017-12-28 04:38:25 --> Router Class Initialized
INFO - 2017-12-28 04:38:25 --> Output Class Initialized
INFO - 2017-12-28 04:38:25 --> Security Class Initialized
DEBUG - 2017-12-28 04:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 04:38:25 --> Input Class Initialized
INFO - 2017-12-28 04:38:25 --> Language Class Initialized
ERROR - 2017-12-28 04:38:25 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-28 04:38:25 --> Config Class Initialized
INFO - 2017-12-28 04:38:25 --> Hooks Class Initialized
INFO - 2017-12-28 04:38:25 --> Config Class Initialized
INFO - 2017-12-28 04:38:25 --> Hooks Class Initialized
DEBUG - 2017-12-28 04:38:25 --> UTF-8 Support Enabled
INFO - 2017-12-28 04:38:25 --> Utf8 Class Initialized
DEBUG - 2017-12-28 04:38:25 --> UTF-8 Support Enabled
INFO - 2017-12-28 04:38:25 --> Utf8 Class Initialized
INFO - 2017-12-28 04:38:25 --> URI Class Initialized
INFO - 2017-12-28 04:38:25 --> URI Class Initialized
INFO - 2017-12-28 04:38:25 --> Router Class Initialized
INFO - 2017-12-28 04:38:25 --> Router Class Initialized
INFO - 2017-12-28 04:38:25 --> Output Class Initialized
INFO - 2017-12-28 04:38:25 --> Output Class Initialized
INFO - 2017-12-28 04:38:25 --> Security Class Initialized
INFO - 2017-12-28 04:38:25 --> Security Class Initialized
DEBUG - 2017-12-28 04:38:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-28 04:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 04:38:25 --> Input Class Initialized
INFO - 2017-12-28 04:38:25 --> Input Class Initialized
INFO - 2017-12-28 04:38:25 --> Language Class Initialized
INFO - 2017-12-28 04:38:25 --> Language Class Initialized
ERROR - 2017-12-28 04:38:25 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-28 04:38:25 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-28 04:38:38 --> Config Class Initialized
INFO - 2017-12-28 04:38:38 --> Hooks Class Initialized
DEBUG - 2017-12-28 04:38:38 --> UTF-8 Support Enabled
INFO - 2017-12-28 04:38:38 --> Utf8 Class Initialized
INFO - 2017-12-28 04:38:38 --> URI Class Initialized
INFO - 2017-12-28 04:38:38 --> Router Class Initialized
INFO - 2017-12-28 04:38:38 --> Output Class Initialized
INFO - 2017-12-28 04:38:38 --> Security Class Initialized
DEBUG - 2017-12-28 04:38:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 04:38:38 --> Input Class Initialized
INFO - 2017-12-28 04:38:38 --> Language Class Initialized
INFO - 2017-12-28 04:38:38 --> Loader Class Initialized
INFO - 2017-12-28 04:38:38 --> Helper loaded: url_helper
INFO - 2017-12-28 04:38:38 --> Helper loaded: form_helper
INFO - 2017-12-28 04:38:38 --> Database Driver Class Initialized
DEBUG - 2017-12-28 04:38:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 04:38:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 04:38:38 --> Form Validation Class Initialized
INFO - 2017-12-28 04:38:38 --> Model Class Initialized
INFO - 2017-12-28 04:38:38 --> Controller Class Initialized
INFO - 2017-12-28 04:38:38 --> Model Class Initialized
INFO - 2017-12-28 04:38:38 --> Model Class Initialized
INFO - 2017-12-28 04:38:38 --> Model Class Initialized
DEBUG - 2017-12-28 04:38:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 04:38:38 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 04:38:38 --> Final output sent to browser
DEBUG - 2017-12-28 04:38:38 --> Total execution time: 0.0809
INFO - 2017-12-28 04:38:38 --> Config Class Initialized
INFO - 2017-12-28 04:38:38 --> Hooks Class Initialized
DEBUG - 2017-12-28 04:38:38 --> UTF-8 Support Enabled
INFO - 2017-12-28 04:38:38 --> Utf8 Class Initialized
INFO - 2017-12-28 04:38:38 --> URI Class Initialized
INFO - 2017-12-28 04:38:38 --> Router Class Initialized
INFO - 2017-12-28 04:38:38 --> Output Class Initialized
INFO - 2017-12-28 04:38:38 --> Security Class Initialized
DEBUG - 2017-12-28 04:38:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 04:38:38 --> Input Class Initialized
INFO - 2017-12-28 04:38:38 --> Language Class Initialized
ERROR - 2017-12-28 04:38:38 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-28 04:38:38 --> Config Class Initialized
INFO - 2017-12-28 04:38:38 --> Hooks Class Initialized
INFO - 2017-12-28 04:38:38 --> Config Class Initialized
INFO - 2017-12-28 04:38:38 --> Hooks Class Initialized
DEBUG - 2017-12-28 04:38:38 --> UTF-8 Support Enabled
INFO - 2017-12-28 04:38:38 --> Utf8 Class Initialized
DEBUG - 2017-12-28 04:38:38 --> UTF-8 Support Enabled
INFO - 2017-12-28 04:38:38 --> Utf8 Class Initialized
INFO - 2017-12-28 04:38:38 --> URI Class Initialized
INFO - 2017-12-28 04:38:38 --> URI Class Initialized
INFO - 2017-12-28 04:38:38 --> Router Class Initialized
INFO - 2017-12-28 04:38:38 --> Router Class Initialized
INFO - 2017-12-28 04:38:38 --> Output Class Initialized
INFO - 2017-12-28 04:38:38 --> Output Class Initialized
INFO - 2017-12-28 04:38:38 --> Security Class Initialized
INFO - 2017-12-28 04:38:38 --> Security Class Initialized
DEBUG - 2017-12-28 04:38:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-28 04:38:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 04:38:38 --> Input Class Initialized
INFO - 2017-12-28 04:38:38 --> Input Class Initialized
INFO - 2017-12-28 04:38:38 --> Language Class Initialized
INFO - 2017-12-28 04:38:38 --> Language Class Initialized
ERROR - 2017-12-28 04:38:38 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-28 04:38:38 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-28 04:49:20 --> Config Class Initialized
INFO - 2017-12-28 04:49:20 --> Hooks Class Initialized
DEBUG - 2017-12-28 04:49:20 --> UTF-8 Support Enabled
INFO - 2017-12-28 04:49:20 --> Utf8 Class Initialized
INFO - 2017-12-28 04:49:20 --> URI Class Initialized
INFO - 2017-12-28 04:49:20 --> Router Class Initialized
INFO - 2017-12-28 04:49:20 --> Output Class Initialized
INFO - 2017-12-28 04:49:20 --> Security Class Initialized
DEBUG - 2017-12-28 04:49:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 04:49:20 --> Input Class Initialized
INFO - 2017-12-28 04:49:20 --> Language Class Initialized
INFO - 2017-12-28 04:49:20 --> Loader Class Initialized
INFO - 2017-12-28 04:49:20 --> Helper loaded: url_helper
INFO - 2017-12-28 04:49:20 --> Helper loaded: form_helper
INFO - 2017-12-28 04:49:20 --> Database Driver Class Initialized
DEBUG - 2017-12-28 04:49:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 04:49:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 04:49:20 --> Form Validation Class Initialized
INFO - 2017-12-28 04:49:20 --> Model Class Initialized
INFO - 2017-12-28 04:49:20 --> Controller Class Initialized
INFO - 2017-12-28 04:49:20 --> Model Class Initialized
INFO - 2017-12-28 04:49:20 --> Model Class Initialized
DEBUG - 2017-12-28 04:49:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 04:49:20 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 04:49:20 --> Final output sent to browser
DEBUG - 2017-12-28 04:49:20 --> Total execution time: 0.0578
INFO - 2017-12-28 04:49:20 --> Config Class Initialized
INFO - 2017-12-28 04:49:20 --> Hooks Class Initialized
DEBUG - 2017-12-28 04:49:20 --> UTF-8 Support Enabled
INFO - 2017-12-28 04:49:20 --> Utf8 Class Initialized
INFO - 2017-12-28 04:49:20 --> URI Class Initialized
INFO - 2017-12-28 04:49:20 --> Router Class Initialized
INFO - 2017-12-28 04:49:20 --> Output Class Initialized
INFO - 2017-12-28 04:49:20 --> Security Class Initialized
DEBUG - 2017-12-28 04:49:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 04:49:20 --> Input Class Initialized
INFO - 2017-12-28 04:49:20 --> Language Class Initialized
INFO - 2017-12-28 04:49:20 --> Loader Class Initialized
INFO - 2017-12-28 04:49:20 --> Helper loaded: url_helper
INFO - 2017-12-28 04:49:20 --> Helper loaded: form_helper
INFO - 2017-12-28 04:49:20 --> Database Driver Class Initialized
DEBUG - 2017-12-28 04:49:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 04:49:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 04:49:20 --> Form Validation Class Initialized
INFO - 2017-12-28 04:49:20 --> Model Class Initialized
INFO - 2017-12-28 04:49:20 --> Controller Class Initialized
INFO - 2017-12-28 04:49:20 --> Model Class Initialized
INFO - 2017-12-28 04:49:20 --> Model Class Initialized
DEBUG - 2017-12-28 04:49:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 04:53:37 --> Config Class Initialized
INFO - 2017-12-28 04:53:37 --> Hooks Class Initialized
DEBUG - 2017-12-28 04:53:37 --> UTF-8 Support Enabled
INFO - 2017-12-28 04:53:37 --> Utf8 Class Initialized
INFO - 2017-12-28 04:53:37 --> URI Class Initialized
INFO - 2017-12-28 04:53:37 --> Router Class Initialized
INFO - 2017-12-28 04:53:37 --> Output Class Initialized
INFO - 2017-12-28 04:53:37 --> Security Class Initialized
DEBUG - 2017-12-28 04:53:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 04:53:37 --> Input Class Initialized
INFO - 2017-12-28 04:53:37 --> Language Class Initialized
INFO - 2017-12-28 04:53:37 --> Loader Class Initialized
INFO - 2017-12-28 04:53:37 --> Helper loaded: url_helper
INFO - 2017-12-28 04:53:37 --> Helper loaded: form_helper
INFO - 2017-12-28 04:53:37 --> Database Driver Class Initialized
DEBUG - 2017-12-28 04:53:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 04:53:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 04:53:37 --> Form Validation Class Initialized
INFO - 2017-12-28 04:53:37 --> Model Class Initialized
INFO - 2017-12-28 04:53:37 --> Controller Class Initialized
INFO - 2017-12-28 04:53:37 --> Model Class Initialized
INFO - 2017-12-28 04:53:37 --> Model Class Initialized
INFO - 2017-12-28 04:53:37 --> Model Class Initialized
INFO - 2017-12-28 04:53:37 --> Model Class Initialized
DEBUG - 2017-12-28 04:53:37 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2017-12-28 04:53:37 --> Query error: Table 'instateccr.t_moneda' doesn't exist - Invalid query: SELECT *
FROM `t_moneda`
INFO - 2017-12-28 04:53:37 --> Language file loaded: language/english/db_lang.php
INFO - 2017-12-28 04:53:58 --> Config Class Initialized
INFO - 2017-12-28 04:53:58 --> Hooks Class Initialized
DEBUG - 2017-12-28 04:53:58 --> UTF-8 Support Enabled
INFO - 2017-12-28 04:53:58 --> Utf8 Class Initialized
INFO - 2017-12-28 04:53:58 --> URI Class Initialized
INFO - 2017-12-28 04:53:58 --> Router Class Initialized
INFO - 2017-12-28 04:53:58 --> Output Class Initialized
INFO - 2017-12-28 04:53:58 --> Security Class Initialized
DEBUG - 2017-12-28 04:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 04:53:58 --> Input Class Initialized
INFO - 2017-12-28 04:53:58 --> Language Class Initialized
INFO - 2017-12-28 04:53:58 --> Loader Class Initialized
INFO - 2017-12-28 04:53:58 --> Helper loaded: url_helper
INFO - 2017-12-28 04:53:58 --> Helper loaded: form_helper
INFO - 2017-12-28 04:53:58 --> Database Driver Class Initialized
DEBUG - 2017-12-28 04:53:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 04:53:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 04:53:58 --> Form Validation Class Initialized
INFO - 2017-12-28 04:53:58 --> Model Class Initialized
INFO - 2017-12-28 04:53:58 --> Controller Class Initialized
INFO - 2017-12-28 04:53:58 --> Model Class Initialized
INFO - 2017-12-28 04:53:58 --> Model Class Initialized
INFO - 2017-12-28 04:53:58 --> Model Class Initialized
INFO - 2017-12-28 04:53:58 --> Model Class Initialized
DEBUG - 2017-12-28 04:53:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 04:53:58 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 04:53:58 --> Final output sent to browser
DEBUG - 2017-12-28 04:53:58 --> Total execution time: 0.1207
INFO - 2017-12-28 04:53:58 --> Config Class Initialized
INFO - 2017-12-28 04:53:58 --> Hooks Class Initialized
DEBUG - 2017-12-28 04:53:58 --> UTF-8 Support Enabled
INFO - 2017-12-28 04:53:58 --> Utf8 Class Initialized
INFO - 2017-12-28 04:53:58 --> URI Class Initialized
INFO - 2017-12-28 04:53:58 --> Router Class Initialized
INFO - 2017-12-28 04:53:58 --> Output Class Initialized
INFO - 2017-12-28 04:53:58 --> Security Class Initialized
DEBUG - 2017-12-28 04:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 04:53:58 --> Input Class Initialized
INFO - 2017-12-28 04:53:58 --> Language Class Initialized
ERROR - 2017-12-28 04:53:58 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-28 04:53:58 --> Config Class Initialized
INFO - 2017-12-28 04:53:58 --> Hooks Class Initialized
INFO - 2017-12-28 04:53:58 --> Config Class Initialized
INFO - 2017-12-28 04:53:58 --> Hooks Class Initialized
DEBUG - 2017-12-28 04:53:58 --> UTF-8 Support Enabled
INFO - 2017-12-28 04:53:58 --> Utf8 Class Initialized
INFO - 2017-12-28 04:53:58 --> URI Class Initialized
DEBUG - 2017-12-28 04:53:58 --> UTF-8 Support Enabled
INFO - 2017-12-28 04:53:58 --> Utf8 Class Initialized
INFO - 2017-12-28 04:53:58 --> Router Class Initialized
INFO - 2017-12-28 04:53:58 --> URI Class Initialized
INFO - 2017-12-28 04:53:58 --> Output Class Initialized
INFO - 2017-12-28 04:53:58 --> Router Class Initialized
INFO - 2017-12-28 04:53:58 --> Security Class Initialized
INFO - 2017-12-28 04:53:58 --> Output Class Initialized
DEBUG - 2017-12-28 04:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 04:53:58 --> Input Class Initialized
INFO - 2017-12-28 04:53:58 --> Security Class Initialized
INFO - 2017-12-28 04:53:58 --> Language Class Initialized
DEBUG - 2017-12-28 04:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 04:53:58 --> Input Class Initialized
ERROR - 2017-12-28 04:53:58 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-28 04:53:58 --> Language Class Initialized
ERROR - 2017-12-28 04:53:58 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-28 04:54:59 --> Config Class Initialized
INFO - 2017-12-28 04:54:59 --> Hooks Class Initialized
DEBUG - 2017-12-28 04:54:59 --> UTF-8 Support Enabled
INFO - 2017-12-28 04:54:59 --> Utf8 Class Initialized
INFO - 2017-12-28 04:54:59 --> URI Class Initialized
INFO - 2017-12-28 04:54:59 --> Router Class Initialized
INFO - 2017-12-28 04:54:59 --> Output Class Initialized
INFO - 2017-12-28 04:54:59 --> Security Class Initialized
DEBUG - 2017-12-28 04:54:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 04:54:59 --> Input Class Initialized
INFO - 2017-12-28 04:54:59 --> Language Class Initialized
INFO - 2017-12-28 04:54:59 --> Loader Class Initialized
INFO - 2017-12-28 04:54:59 --> Helper loaded: url_helper
INFO - 2017-12-28 04:54:59 --> Helper loaded: form_helper
INFO - 2017-12-28 04:54:59 --> Database Driver Class Initialized
DEBUG - 2017-12-28 04:54:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 04:54:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 04:54:59 --> Form Validation Class Initialized
INFO - 2017-12-28 04:54:59 --> Model Class Initialized
INFO - 2017-12-28 04:54:59 --> Controller Class Initialized
INFO - 2017-12-28 04:54:59 --> Model Class Initialized
INFO - 2017-12-28 04:54:59 --> Model Class Initialized
INFO - 2017-12-28 04:54:59 --> Model Class Initialized
INFO - 2017-12-28 04:54:59 --> Model Class Initialized
DEBUG - 2017-12-28 04:54:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 04:54:59 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 04:54:59 --> Final output sent to browser
DEBUG - 2017-12-28 04:54:59 --> Total execution time: 0.1332
INFO - 2017-12-28 04:54:59 --> Config Class Initialized
INFO - 2017-12-28 04:54:59 --> Hooks Class Initialized
DEBUG - 2017-12-28 04:54:59 --> UTF-8 Support Enabled
INFO - 2017-12-28 04:54:59 --> Utf8 Class Initialized
INFO - 2017-12-28 04:54:59 --> URI Class Initialized
INFO - 2017-12-28 04:54:59 --> Router Class Initialized
INFO - 2017-12-28 04:54:59 --> Output Class Initialized
INFO - 2017-12-28 04:54:59 --> Security Class Initialized
DEBUG - 2017-12-28 04:54:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 04:54:59 --> Input Class Initialized
INFO - 2017-12-28 04:54:59 --> Language Class Initialized
ERROR - 2017-12-28 04:54:59 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-28 04:54:59 --> Config Class Initialized
INFO - 2017-12-28 04:54:59 --> Hooks Class Initialized
INFO - 2017-12-28 04:54:59 --> Config Class Initialized
INFO - 2017-12-28 04:54:59 --> Hooks Class Initialized
DEBUG - 2017-12-28 04:54:59 --> UTF-8 Support Enabled
INFO - 2017-12-28 04:54:59 --> Utf8 Class Initialized
DEBUG - 2017-12-28 04:54:59 --> UTF-8 Support Enabled
INFO - 2017-12-28 04:54:59 --> Utf8 Class Initialized
INFO - 2017-12-28 04:54:59 --> URI Class Initialized
INFO - 2017-12-28 04:54:59 --> URI Class Initialized
INFO - 2017-12-28 04:54:59 --> Router Class Initialized
INFO - 2017-12-28 04:54:59 --> Router Class Initialized
INFO - 2017-12-28 04:54:59 --> Output Class Initialized
INFO - 2017-12-28 04:54:59 --> Output Class Initialized
INFO - 2017-12-28 04:54:59 --> Security Class Initialized
INFO - 2017-12-28 04:54:59 --> Security Class Initialized
DEBUG - 2017-12-28 04:54:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 04:54:59 --> Input Class Initialized
DEBUG - 2017-12-28 04:54:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 04:54:59 --> Input Class Initialized
INFO - 2017-12-28 04:54:59 --> Language Class Initialized
INFO - 2017-12-28 04:54:59 --> Language Class Initialized
ERROR - 2017-12-28 04:54:59 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-28 04:54:59 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-28 04:56:00 --> Config Class Initialized
INFO - 2017-12-28 04:56:00 --> Hooks Class Initialized
DEBUG - 2017-12-28 04:56:00 --> UTF-8 Support Enabled
INFO - 2017-12-28 04:56:00 --> Utf8 Class Initialized
INFO - 2017-12-28 04:56:00 --> URI Class Initialized
INFO - 2017-12-28 04:56:00 --> Router Class Initialized
INFO - 2017-12-28 04:56:00 --> Output Class Initialized
INFO - 2017-12-28 04:56:00 --> Security Class Initialized
DEBUG - 2017-12-28 04:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 04:56:00 --> Input Class Initialized
INFO - 2017-12-28 04:56:00 --> Language Class Initialized
INFO - 2017-12-28 04:56:00 --> Loader Class Initialized
INFO - 2017-12-28 04:56:00 --> Helper loaded: url_helper
INFO - 2017-12-28 04:56:00 --> Helper loaded: form_helper
INFO - 2017-12-28 04:56:00 --> Database Driver Class Initialized
DEBUG - 2017-12-28 04:56:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 04:56:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 04:56:00 --> Form Validation Class Initialized
INFO - 2017-12-28 04:56:00 --> Model Class Initialized
INFO - 2017-12-28 04:56:00 --> Controller Class Initialized
INFO - 2017-12-28 04:56:00 --> Model Class Initialized
INFO - 2017-12-28 04:56:00 --> Model Class Initialized
INFO - 2017-12-28 04:56:00 --> Model Class Initialized
INFO - 2017-12-28 04:56:00 --> Model Class Initialized
DEBUG - 2017-12-28 04:56:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 04:56:00 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 04:56:00 --> Final output sent to browser
DEBUG - 2017-12-28 04:56:00 --> Total execution time: 0.1013
INFO - 2017-12-28 04:56:00 --> Config Class Initialized
INFO - 2017-12-28 04:56:00 --> Hooks Class Initialized
DEBUG - 2017-12-28 04:56:00 --> UTF-8 Support Enabled
INFO - 2017-12-28 04:56:00 --> Utf8 Class Initialized
INFO - 2017-12-28 04:56:00 --> URI Class Initialized
INFO - 2017-12-28 04:56:00 --> Router Class Initialized
INFO - 2017-12-28 04:56:00 --> Output Class Initialized
INFO - 2017-12-28 04:56:00 --> Security Class Initialized
DEBUG - 2017-12-28 04:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 04:56:00 --> Input Class Initialized
INFO - 2017-12-28 04:56:00 --> Language Class Initialized
ERROR - 2017-12-28 04:56:00 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-28 04:56:00 --> Config Class Initialized
INFO - 2017-12-28 04:56:00 --> Hooks Class Initialized
INFO - 2017-12-28 04:56:00 --> Config Class Initialized
INFO - 2017-12-28 04:56:00 --> Hooks Class Initialized
DEBUG - 2017-12-28 04:56:00 --> UTF-8 Support Enabled
INFO - 2017-12-28 04:56:00 --> Utf8 Class Initialized
DEBUG - 2017-12-28 04:56:00 --> UTF-8 Support Enabled
INFO - 2017-12-28 04:56:00 --> Utf8 Class Initialized
INFO - 2017-12-28 04:56:00 --> URI Class Initialized
INFO - 2017-12-28 04:56:00 --> URI Class Initialized
INFO - 2017-12-28 04:56:00 --> Router Class Initialized
INFO - 2017-12-28 04:56:00 --> Router Class Initialized
INFO - 2017-12-28 04:56:00 --> Output Class Initialized
INFO - 2017-12-28 04:56:00 --> Output Class Initialized
INFO - 2017-12-28 04:56:00 --> Security Class Initialized
INFO - 2017-12-28 04:56:00 --> Security Class Initialized
DEBUG - 2017-12-28 04:56:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-28 04:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 04:56:00 --> Input Class Initialized
INFO - 2017-12-28 04:56:00 --> Input Class Initialized
INFO - 2017-12-28 04:56:00 --> Language Class Initialized
INFO - 2017-12-28 04:56:00 --> Language Class Initialized
ERROR - 2017-12-28 04:56:00 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-28 04:56:00 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-28 04:56:19 --> Config Class Initialized
INFO - 2017-12-28 04:56:19 --> Hooks Class Initialized
DEBUG - 2017-12-28 04:56:19 --> UTF-8 Support Enabled
INFO - 2017-12-28 04:56:19 --> Utf8 Class Initialized
INFO - 2017-12-28 04:56:19 --> URI Class Initialized
INFO - 2017-12-28 04:56:19 --> Router Class Initialized
INFO - 2017-12-28 04:56:19 --> Output Class Initialized
INFO - 2017-12-28 04:56:19 --> Security Class Initialized
DEBUG - 2017-12-28 04:56:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 04:56:19 --> Input Class Initialized
INFO - 2017-12-28 04:56:19 --> Language Class Initialized
INFO - 2017-12-28 04:56:19 --> Loader Class Initialized
INFO - 2017-12-28 04:56:19 --> Helper loaded: url_helper
INFO - 2017-12-28 04:56:19 --> Helper loaded: form_helper
INFO - 2017-12-28 04:56:19 --> Database Driver Class Initialized
DEBUG - 2017-12-28 04:56:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 04:56:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 04:56:19 --> Form Validation Class Initialized
INFO - 2017-12-28 04:56:19 --> Model Class Initialized
INFO - 2017-12-28 04:56:19 --> Controller Class Initialized
INFO - 2017-12-28 04:56:19 --> Model Class Initialized
INFO - 2017-12-28 04:56:19 --> Model Class Initialized
INFO - 2017-12-28 04:56:19 --> Model Class Initialized
INFO - 2017-12-28 04:56:19 --> Model Class Initialized
DEBUG - 2017-12-28 04:56:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 04:56:19 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 04:56:19 --> Final output sent to browser
DEBUG - 2017-12-28 04:56:19 --> Total execution time: 0.0936
INFO - 2017-12-28 04:56:19 --> Config Class Initialized
INFO - 2017-12-28 04:56:19 --> Hooks Class Initialized
DEBUG - 2017-12-28 04:56:19 --> UTF-8 Support Enabled
INFO - 2017-12-28 04:56:19 --> Utf8 Class Initialized
INFO - 2017-12-28 04:56:19 --> URI Class Initialized
INFO - 2017-12-28 04:56:19 --> Router Class Initialized
INFO - 2017-12-28 04:56:19 --> Output Class Initialized
INFO - 2017-12-28 04:56:19 --> Security Class Initialized
DEBUG - 2017-12-28 04:56:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 04:56:19 --> Input Class Initialized
INFO - 2017-12-28 04:56:19 --> Language Class Initialized
ERROR - 2017-12-28 04:56:19 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-28 04:56:19 --> Config Class Initialized
INFO - 2017-12-28 04:56:19 --> Hooks Class Initialized
INFO - 2017-12-28 04:56:19 --> Config Class Initialized
INFO - 2017-12-28 04:56:19 --> Hooks Class Initialized
DEBUG - 2017-12-28 04:56:19 --> UTF-8 Support Enabled
INFO - 2017-12-28 04:56:19 --> Utf8 Class Initialized
DEBUG - 2017-12-28 04:56:19 --> UTF-8 Support Enabled
INFO - 2017-12-28 04:56:19 --> Utf8 Class Initialized
INFO - 2017-12-28 04:56:19 --> URI Class Initialized
INFO - 2017-12-28 04:56:19 --> URI Class Initialized
INFO - 2017-12-28 04:56:19 --> Router Class Initialized
INFO - 2017-12-28 04:56:19 --> Router Class Initialized
INFO - 2017-12-28 04:56:19 --> Output Class Initialized
INFO - 2017-12-28 04:56:19 --> Output Class Initialized
INFO - 2017-12-28 04:56:19 --> Security Class Initialized
INFO - 2017-12-28 04:56:19 --> Security Class Initialized
DEBUG - 2017-12-28 04:56:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 04:56:19 --> Input Class Initialized
INFO - 2017-12-28 04:56:19 --> Language Class Initialized
DEBUG - 2017-12-28 04:56:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 04:56:19 --> Input Class Initialized
ERROR - 2017-12-28 04:56:19 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-28 04:56:19 --> Language Class Initialized
ERROR - 2017-12-28 04:56:19 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-28 05:37:01 --> Config Class Initialized
INFO - 2017-12-28 05:37:01 --> Hooks Class Initialized
DEBUG - 2017-12-28 05:37:01 --> UTF-8 Support Enabled
INFO - 2017-12-28 05:37:01 --> Utf8 Class Initialized
INFO - 2017-12-28 05:37:01 --> URI Class Initialized
INFO - 2017-12-28 05:37:01 --> Router Class Initialized
INFO - 2017-12-28 05:37:01 --> Output Class Initialized
INFO - 2017-12-28 05:37:01 --> Security Class Initialized
DEBUG - 2017-12-28 05:37:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 05:37:01 --> Input Class Initialized
INFO - 2017-12-28 05:37:01 --> Language Class Initialized
INFO - 2017-12-28 05:37:01 --> Loader Class Initialized
INFO - 2017-12-28 05:37:01 --> Helper loaded: url_helper
INFO - 2017-12-28 05:37:01 --> Helper loaded: form_helper
INFO - 2017-12-28 05:37:01 --> Database Driver Class Initialized
DEBUG - 2017-12-28 05:37:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 05:37:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 05:37:01 --> Form Validation Class Initialized
INFO - 2017-12-28 05:37:01 --> Model Class Initialized
INFO - 2017-12-28 05:37:01 --> Controller Class Initialized
INFO - 2017-12-28 05:37:01 --> Model Class Initialized
INFO - 2017-12-28 05:37:01 --> Model Class Initialized
INFO - 2017-12-28 05:37:01 --> Model Class Initialized
INFO - 2017-12-28 05:37:01 --> Model Class Initialized
DEBUG - 2017-12-28 05:37:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 05:37:01 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 05:37:01 --> Final output sent to browser
DEBUG - 2017-12-28 05:37:01 --> Total execution time: 0.0673
INFO - 2017-12-28 05:37:01 --> Config Class Initialized
INFO - 2017-12-28 05:37:01 --> Hooks Class Initialized
DEBUG - 2017-12-28 05:37:01 --> UTF-8 Support Enabled
INFO - 2017-12-28 05:37:01 --> Utf8 Class Initialized
INFO - 2017-12-28 05:37:01 --> URI Class Initialized
INFO - 2017-12-28 05:37:01 --> Router Class Initialized
INFO - 2017-12-28 05:37:01 --> Output Class Initialized
INFO - 2017-12-28 05:37:01 --> Security Class Initialized
DEBUG - 2017-12-28 05:37:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 05:37:01 --> Input Class Initialized
INFO - 2017-12-28 05:37:01 --> Language Class Initialized
ERROR - 2017-12-28 05:37:01 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-28 05:37:01 --> Config Class Initialized
INFO - 2017-12-28 05:37:01 --> Hooks Class Initialized
INFO - 2017-12-28 05:37:01 --> Config Class Initialized
INFO - 2017-12-28 05:37:01 --> Hooks Class Initialized
DEBUG - 2017-12-28 05:37:01 --> UTF-8 Support Enabled
INFO - 2017-12-28 05:37:01 --> Utf8 Class Initialized
INFO - 2017-12-28 05:37:01 --> URI Class Initialized
INFO - 2017-12-28 05:37:01 --> Router Class Initialized
DEBUG - 2017-12-28 05:37:01 --> UTF-8 Support Enabled
INFO - 2017-12-28 05:37:01 --> Utf8 Class Initialized
INFO - 2017-12-28 05:37:01 --> Output Class Initialized
INFO - 2017-12-28 05:37:01 --> URI Class Initialized
INFO - 2017-12-28 05:37:01 --> Security Class Initialized
INFO - 2017-12-28 05:37:01 --> Router Class Initialized
DEBUG - 2017-12-28 05:37:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 05:37:01 --> Input Class Initialized
INFO - 2017-12-28 05:37:01 --> Language Class Initialized
INFO - 2017-12-28 05:37:01 --> Output Class Initialized
ERROR - 2017-12-28 05:37:01 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-28 05:37:01 --> Security Class Initialized
DEBUG - 2017-12-28 05:37:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 05:37:01 --> Input Class Initialized
INFO - 2017-12-28 05:37:01 --> Language Class Initialized
ERROR - 2017-12-28 05:37:01 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-28 05:37:02 --> Config Class Initialized
INFO - 2017-12-28 05:37:02 --> Hooks Class Initialized
DEBUG - 2017-12-28 05:37:02 --> UTF-8 Support Enabled
INFO - 2017-12-28 05:37:02 --> Utf8 Class Initialized
INFO - 2017-12-28 05:37:02 --> URI Class Initialized
INFO - 2017-12-28 05:37:02 --> Router Class Initialized
INFO - 2017-12-28 05:37:02 --> Output Class Initialized
INFO - 2017-12-28 05:37:02 --> Security Class Initialized
DEBUG - 2017-12-28 05:37:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 05:37:02 --> Input Class Initialized
INFO - 2017-12-28 05:37:02 --> Language Class Initialized
INFO - 2017-12-28 05:37:02 --> Loader Class Initialized
INFO - 2017-12-28 05:37:02 --> Helper loaded: url_helper
INFO - 2017-12-28 05:37:02 --> Helper loaded: form_helper
INFO - 2017-12-28 05:37:02 --> Database Driver Class Initialized
DEBUG - 2017-12-28 05:37:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 05:37:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 05:37:02 --> Form Validation Class Initialized
INFO - 2017-12-28 05:37:02 --> Model Class Initialized
INFO - 2017-12-28 05:37:02 --> Controller Class Initialized
INFO - 2017-12-28 05:37:02 --> Model Class Initialized
INFO - 2017-12-28 05:37:02 --> Model Class Initialized
INFO - 2017-12-28 05:37:02 --> Model Class Initialized
INFO - 2017-12-28 05:37:02 --> Model Class Initialized
DEBUG - 2017-12-28 05:37:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 05:37:02 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 05:37:02 --> Final output sent to browser
DEBUG - 2017-12-28 05:37:02 --> Total execution time: 0.0768
INFO - 2017-12-28 05:37:02 --> Config Class Initialized
INFO - 2017-12-28 05:37:02 --> Hooks Class Initialized
DEBUG - 2017-12-28 05:37:02 --> UTF-8 Support Enabled
INFO - 2017-12-28 05:37:02 --> Utf8 Class Initialized
INFO - 2017-12-28 05:37:02 --> URI Class Initialized
INFO - 2017-12-28 05:37:02 --> Router Class Initialized
INFO - 2017-12-28 05:37:02 --> Output Class Initialized
INFO - 2017-12-28 05:37:02 --> Security Class Initialized
DEBUG - 2017-12-28 05:37:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 05:37:02 --> Input Class Initialized
INFO - 2017-12-28 05:37:02 --> Language Class Initialized
ERROR - 2017-12-28 05:37:02 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-28 05:37:02 --> Config Class Initialized
INFO - 2017-12-28 05:37:02 --> Config Class Initialized
INFO - 2017-12-28 05:37:02 --> Hooks Class Initialized
INFO - 2017-12-28 05:37:02 --> Hooks Class Initialized
DEBUG - 2017-12-28 05:37:02 --> UTF-8 Support Enabled
DEBUG - 2017-12-28 05:37:02 --> UTF-8 Support Enabled
INFO - 2017-12-28 05:37:02 --> Utf8 Class Initialized
INFO - 2017-12-28 05:37:02 --> Utf8 Class Initialized
INFO - 2017-12-28 05:37:02 --> URI Class Initialized
INFO - 2017-12-28 05:37:02 --> URI Class Initialized
INFO - 2017-12-28 05:37:02 --> Router Class Initialized
INFO - 2017-12-28 05:37:02 --> Router Class Initialized
INFO - 2017-12-28 05:37:02 --> Output Class Initialized
INFO - 2017-12-28 05:37:02 --> Output Class Initialized
INFO - 2017-12-28 05:37:02 --> Security Class Initialized
INFO - 2017-12-28 05:37:02 --> Security Class Initialized
DEBUG - 2017-12-28 05:37:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-28 05:37:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 05:37:02 --> Input Class Initialized
INFO - 2017-12-28 05:37:02 --> Input Class Initialized
INFO - 2017-12-28 05:37:02 --> Language Class Initialized
INFO - 2017-12-28 05:37:02 --> Language Class Initialized
ERROR - 2017-12-28 05:37:02 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-28 05:37:02 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-28 05:37:24 --> Config Class Initialized
INFO - 2017-12-28 05:37:24 --> Hooks Class Initialized
DEBUG - 2017-12-28 05:37:24 --> UTF-8 Support Enabled
INFO - 2017-12-28 05:37:24 --> Utf8 Class Initialized
INFO - 2017-12-28 05:37:24 --> URI Class Initialized
INFO - 2017-12-28 05:37:24 --> Router Class Initialized
INFO - 2017-12-28 05:37:24 --> Output Class Initialized
INFO - 2017-12-28 05:37:24 --> Security Class Initialized
DEBUG - 2017-12-28 05:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 05:37:24 --> Input Class Initialized
INFO - 2017-12-28 05:37:24 --> Language Class Initialized
INFO - 2017-12-28 05:37:24 --> Loader Class Initialized
INFO - 2017-12-28 05:37:24 --> Helper loaded: url_helper
INFO - 2017-12-28 05:37:24 --> Helper loaded: form_helper
INFO - 2017-12-28 05:37:24 --> Database Driver Class Initialized
DEBUG - 2017-12-28 05:37:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 05:37:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 05:37:24 --> Form Validation Class Initialized
INFO - 2017-12-28 05:37:24 --> Model Class Initialized
INFO - 2017-12-28 05:37:24 --> Controller Class Initialized
INFO - 2017-12-28 05:37:24 --> Model Class Initialized
INFO - 2017-12-28 05:37:24 --> Model Class Initialized
INFO - 2017-12-28 05:37:24 --> Model Class Initialized
INFO - 2017-12-28 05:37:24 --> Model Class Initialized
DEBUG - 2017-12-28 05:37:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 05:37:24 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 05:37:24 --> Final output sent to browser
DEBUG - 2017-12-28 05:37:24 --> Total execution time: 0.0575
INFO - 2017-12-28 05:37:24 --> Config Class Initialized
INFO - 2017-12-28 05:37:24 --> Hooks Class Initialized
DEBUG - 2017-12-28 05:37:24 --> UTF-8 Support Enabled
INFO - 2017-12-28 05:37:24 --> Utf8 Class Initialized
INFO - 2017-12-28 05:37:24 --> URI Class Initialized
INFO - 2017-12-28 05:37:24 --> Router Class Initialized
INFO - 2017-12-28 05:37:24 --> Output Class Initialized
INFO - 2017-12-28 05:37:24 --> Security Class Initialized
DEBUG - 2017-12-28 05:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 05:37:24 --> Input Class Initialized
INFO - 2017-12-28 05:37:24 --> Language Class Initialized
ERROR - 2017-12-28 05:37:24 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-28 05:37:24 --> Config Class Initialized
INFO - 2017-12-28 05:37:24 --> Hooks Class Initialized
INFO - 2017-12-28 05:37:24 --> Config Class Initialized
INFO - 2017-12-28 05:37:24 --> Hooks Class Initialized
DEBUG - 2017-12-28 05:37:24 --> UTF-8 Support Enabled
INFO - 2017-12-28 05:37:24 --> Utf8 Class Initialized
DEBUG - 2017-12-28 05:37:24 --> UTF-8 Support Enabled
INFO - 2017-12-28 05:37:24 --> URI Class Initialized
INFO - 2017-12-28 05:37:24 --> Utf8 Class Initialized
INFO - 2017-12-28 05:37:24 --> URI Class Initialized
INFO - 2017-12-28 05:37:24 --> Router Class Initialized
INFO - 2017-12-28 05:37:24 --> Router Class Initialized
INFO - 2017-12-28 05:37:24 --> Output Class Initialized
INFO - 2017-12-28 05:37:24 --> Output Class Initialized
INFO - 2017-12-28 05:37:24 --> Security Class Initialized
INFO - 2017-12-28 05:37:24 --> Security Class Initialized
DEBUG - 2017-12-28 05:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 05:37:24 --> Input Class Initialized
DEBUG - 2017-12-28 05:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 05:37:24 --> Input Class Initialized
INFO - 2017-12-28 05:37:24 --> Language Class Initialized
INFO - 2017-12-28 05:37:24 --> Language Class Initialized
ERROR - 2017-12-28 05:37:24 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-28 05:37:24 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-28 05:37:29 --> Config Class Initialized
INFO - 2017-12-28 05:37:29 --> Hooks Class Initialized
DEBUG - 2017-12-28 05:37:29 --> UTF-8 Support Enabled
INFO - 2017-12-28 05:37:29 --> Utf8 Class Initialized
INFO - 2017-12-28 05:37:29 --> URI Class Initialized
INFO - 2017-12-28 05:37:30 --> Router Class Initialized
INFO - 2017-12-28 05:37:30 --> Output Class Initialized
INFO - 2017-12-28 05:37:30 --> Security Class Initialized
DEBUG - 2017-12-28 05:37:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 05:37:30 --> Input Class Initialized
INFO - 2017-12-28 05:37:30 --> Language Class Initialized
INFO - 2017-12-28 05:37:30 --> Loader Class Initialized
INFO - 2017-12-28 05:37:30 --> Helper loaded: url_helper
INFO - 2017-12-28 05:37:30 --> Helper loaded: form_helper
INFO - 2017-12-28 05:37:30 --> Database Driver Class Initialized
DEBUG - 2017-12-28 05:37:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 05:37:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 05:37:30 --> Form Validation Class Initialized
INFO - 2017-12-28 05:37:30 --> Model Class Initialized
INFO - 2017-12-28 05:37:30 --> Controller Class Initialized
INFO - 2017-12-28 05:37:30 --> Model Class Initialized
INFO - 2017-12-28 05:37:30 --> Model Class Initialized
INFO - 2017-12-28 05:37:30 --> Model Class Initialized
INFO - 2017-12-28 05:37:30 --> Model Class Initialized
DEBUG - 2017-12-28 05:37:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 05:37:30 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 05:37:30 --> Final output sent to browser
DEBUG - 2017-12-28 05:37:30 --> Total execution time: 0.0784
INFO - 2017-12-28 05:37:30 --> Config Class Initialized
INFO - 2017-12-28 05:37:30 --> Hooks Class Initialized
INFO - 2017-12-28 05:37:30 --> Config Class Initialized
INFO - 2017-12-28 05:37:30 --> Hooks Class Initialized
DEBUG - 2017-12-28 05:37:30 --> UTF-8 Support Enabled
INFO - 2017-12-28 05:37:30 --> Utf8 Class Initialized
INFO - 2017-12-28 05:37:30 --> URI Class Initialized
DEBUG - 2017-12-28 05:37:30 --> UTF-8 Support Enabled
INFO - 2017-12-28 05:37:30 --> Utf8 Class Initialized
INFO - 2017-12-28 05:37:30 --> URI Class Initialized
INFO - 2017-12-28 05:37:30 --> Router Class Initialized
INFO - 2017-12-28 05:37:30 --> Router Class Initialized
INFO - 2017-12-28 05:37:30 --> Output Class Initialized
INFO - 2017-12-28 05:37:30 --> Security Class Initialized
INFO - 2017-12-28 05:37:30 --> Output Class Initialized
DEBUG - 2017-12-28 05:37:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 05:37:30 --> Input Class Initialized
INFO - 2017-12-28 05:37:30 --> Security Class Initialized
INFO - 2017-12-28 05:37:30 --> Language Class Initialized
DEBUG - 2017-12-28 05:37:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 05:37:30 --> Input Class Initialized
ERROR - 2017-12-28 05:37:30 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-28 05:37:30 --> Language Class Initialized
ERROR - 2017-12-28 05:37:30 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-28 05:37:35 --> Config Class Initialized
INFO - 2017-12-28 05:37:35 --> Hooks Class Initialized
DEBUG - 2017-12-28 05:37:35 --> UTF-8 Support Enabled
INFO - 2017-12-28 05:37:35 --> Utf8 Class Initialized
INFO - 2017-12-28 05:37:35 --> URI Class Initialized
INFO - 2017-12-28 05:37:35 --> Router Class Initialized
INFO - 2017-12-28 05:37:35 --> Output Class Initialized
INFO - 2017-12-28 05:37:35 --> Security Class Initialized
DEBUG - 2017-12-28 05:37:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 05:37:35 --> Input Class Initialized
INFO - 2017-12-28 05:37:35 --> Language Class Initialized
ERROR - 2017-12-28 05:37:35 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-28 05:38:07 --> Config Class Initialized
INFO - 2017-12-28 05:38:07 --> Hooks Class Initialized
DEBUG - 2017-12-28 05:38:07 --> UTF-8 Support Enabled
INFO - 2017-12-28 05:38:07 --> Utf8 Class Initialized
INFO - 2017-12-28 05:38:07 --> URI Class Initialized
INFO - 2017-12-28 05:38:07 --> Router Class Initialized
INFO - 2017-12-28 05:38:07 --> Output Class Initialized
INFO - 2017-12-28 05:38:07 --> Security Class Initialized
DEBUG - 2017-12-28 05:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 05:38:07 --> Input Class Initialized
INFO - 2017-12-28 05:38:07 --> Language Class Initialized
INFO - 2017-12-28 05:38:07 --> Loader Class Initialized
INFO - 2017-12-28 05:38:07 --> Helper loaded: url_helper
INFO - 2017-12-28 05:38:07 --> Helper loaded: form_helper
INFO - 2017-12-28 05:38:07 --> Database Driver Class Initialized
DEBUG - 2017-12-28 05:38:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 05:38:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 05:38:07 --> Form Validation Class Initialized
INFO - 2017-12-28 05:38:07 --> Model Class Initialized
INFO - 2017-12-28 05:38:07 --> Controller Class Initialized
INFO - 2017-12-28 05:38:07 --> Model Class Initialized
INFO - 2017-12-28 05:38:07 --> Model Class Initialized
INFO - 2017-12-28 05:38:07 --> Model Class Initialized
INFO - 2017-12-28 05:38:07 --> Model Class Initialized
DEBUG - 2017-12-28 05:38:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 05:38:07 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 05:38:07 --> Final output sent to browser
DEBUG - 2017-12-28 05:38:07 --> Total execution time: 0.0541
INFO - 2017-12-28 05:38:07 --> Config Class Initialized
INFO - 2017-12-28 05:38:07 --> Hooks Class Initialized
DEBUG - 2017-12-28 05:38:07 --> UTF-8 Support Enabled
INFO - 2017-12-28 05:38:07 --> Utf8 Class Initialized
INFO - 2017-12-28 05:38:07 --> URI Class Initialized
INFO - 2017-12-28 05:38:07 --> Router Class Initialized
INFO - 2017-12-28 05:38:07 --> Output Class Initialized
INFO - 2017-12-28 05:38:07 --> Security Class Initialized
DEBUG - 2017-12-28 05:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 05:38:07 --> Input Class Initialized
INFO - 2017-12-28 05:38:07 --> Language Class Initialized
ERROR - 2017-12-28 05:38:07 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-28 05:38:07 --> Config Class Initialized
INFO - 2017-12-28 05:38:07 --> Hooks Class Initialized
INFO - 2017-12-28 05:38:07 --> Config Class Initialized
INFO - 2017-12-28 05:38:07 --> Hooks Class Initialized
DEBUG - 2017-12-28 05:38:07 --> UTF-8 Support Enabled
INFO - 2017-12-28 05:38:07 --> Utf8 Class Initialized
DEBUG - 2017-12-28 05:38:07 --> UTF-8 Support Enabled
INFO - 2017-12-28 05:38:07 --> Utf8 Class Initialized
INFO - 2017-12-28 05:38:07 --> URI Class Initialized
INFO - 2017-12-28 05:38:07 --> URI Class Initialized
INFO - 2017-12-28 05:38:07 --> Router Class Initialized
INFO - 2017-12-28 05:38:07 --> Router Class Initialized
INFO - 2017-12-28 05:38:07 --> Output Class Initialized
INFO - 2017-12-28 05:38:07 --> Output Class Initialized
INFO - 2017-12-28 05:38:07 --> Security Class Initialized
INFO - 2017-12-28 05:38:07 --> Security Class Initialized
DEBUG - 2017-12-28 05:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 05:38:07 --> Input Class Initialized
DEBUG - 2017-12-28 05:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 05:38:07 --> Input Class Initialized
INFO - 2017-12-28 05:38:07 --> Language Class Initialized
INFO - 2017-12-28 05:38:07 --> Language Class Initialized
ERROR - 2017-12-28 05:38:07 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-28 05:38:07 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-28 05:39:17 --> Config Class Initialized
INFO - 2017-12-28 05:39:17 --> Hooks Class Initialized
DEBUG - 2017-12-28 05:39:17 --> UTF-8 Support Enabled
INFO - 2017-12-28 05:39:17 --> Utf8 Class Initialized
INFO - 2017-12-28 05:39:17 --> URI Class Initialized
INFO - 2017-12-28 05:39:17 --> Router Class Initialized
INFO - 2017-12-28 05:39:17 --> Output Class Initialized
INFO - 2017-12-28 05:39:17 --> Security Class Initialized
DEBUG - 2017-12-28 05:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 05:39:17 --> Input Class Initialized
INFO - 2017-12-28 05:39:17 --> Language Class Initialized
INFO - 2017-12-28 05:39:17 --> Loader Class Initialized
INFO - 2017-12-28 05:39:17 --> Helper loaded: url_helper
INFO - 2017-12-28 05:39:17 --> Helper loaded: form_helper
INFO - 2017-12-28 05:39:17 --> Database Driver Class Initialized
DEBUG - 2017-12-28 05:39:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 05:39:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 05:39:17 --> Form Validation Class Initialized
INFO - 2017-12-28 05:39:17 --> Model Class Initialized
INFO - 2017-12-28 05:39:17 --> Controller Class Initialized
INFO - 2017-12-28 05:39:17 --> Model Class Initialized
INFO - 2017-12-28 05:39:17 --> Model Class Initialized
INFO - 2017-12-28 05:39:17 --> Model Class Initialized
INFO - 2017-12-28 05:39:17 --> Model Class Initialized
DEBUG - 2017-12-28 05:39:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 05:39:17 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 05:39:17 --> Final output sent to browser
DEBUG - 2017-12-28 05:39:17 --> Total execution time: 0.0699
INFO - 2017-12-28 05:39:17 --> Config Class Initialized
INFO - 2017-12-28 05:39:17 --> Hooks Class Initialized
DEBUG - 2017-12-28 05:39:17 --> UTF-8 Support Enabled
INFO - 2017-12-28 05:39:17 --> Utf8 Class Initialized
INFO - 2017-12-28 05:39:17 --> URI Class Initialized
INFO - 2017-12-28 05:39:18 --> Router Class Initialized
INFO - 2017-12-28 05:39:18 --> Output Class Initialized
INFO - 2017-12-28 05:39:18 --> Security Class Initialized
DEBUG - 2017-12-28 05:39:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 05:39:18 --> Input Class Initialized
INFO - 2017-12-28 05:39:18 --> Language Class Initialized
ERROR - 2017-12-28 05:39:18 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-28 05:39:18 --> Config Class Initialized
INFO - 2017-12-28 05:39:18 --> Hooks Class Initialized
INFO - 2017-12-28 05:39:18 --> Config Class Initialized
INFO - 2017-12-28 05:39:18 --> Hooks Class Initialized
DEBUG - 2017-12-28 05:39:18 --> UTF-8 Support Enabled
INFO - 2017-12-28 05:39:18 --> Utf8 Class Initialized
INFO - 2017-12-28 05:39:18 --> URI Class Initialized
DEBUG - 2017-12-28 05:39:18 --> UTF-8 Support Enabled
INFO - 2017-12-28 05:39:18 --> Utf8 Class Initialized
INFO - 2017-12-28 05:39:18 --> URI Class Initialized
INFO - 2017-12-28 05:39:18 --> Router Class Initialized
INFO - 2017-12-28 05:39:18 --> Router Class Initialized
INFO - 2017-12-28 05:39:18 --> Output Class Initialized
INFO - 2017-12-28 05:39:18 --> Security Class Initialized
INFO - 2017-12-28 05:39:18 --> Output Class Initialized
DEBUG - 2017-12-28 05:39:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 05:39:18 --> Input Class Initialized
INFO - 2017-12-28 05:39:18 --> Security Class Initialized
INFO - 2017-12-28 05:39:18 --> Language Class Initialized
DEBUG - 2017-12-28 05:39:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 05:39:18 --> Input Class Initialized
INFO - 2017-12-28 05:39:18 --> Language Class Initialized
ERROR - 2017-12-28 05:39:18 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-28 05:39:18 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-28 05:39:35 --> Config Class Initialized
INFO - 2017-12-28 05:39:35 --> Hooks Class Initialized
DEBUG - 2017-12-28 05:39:35 --> UTF-8 Support Enabled
INFO - 2017-12-28 05:39:35 --> Utf8 Class Initialized
INFO - 2017-12-28 05:39:35 --> URI Class Initialized
INFO - 2017-12-28 05:39:35 --> Router Class Initialized
INFO - 2017-12-28 05:39:35 --> Output Class Initialized
INFO - 2017-12-28 05:39:35 --> Security Class Initialized
DEBUG - 2017-12-28 05:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 05:39:35 --> Input Class Initialized
INFO - 2017-12-28 05:39:35 --> Language Class Initialized
INFO - 2017-12-28 05:39:35 --> Loader Class Initialized
INFO - 2017-12-28 05:39:35 --> Helper loaded: url_helper
INFO - 2017-12-28 05:39:35 --> Helper loaded: form_helper
INFO - 2017-12-28 05:39:35 --> Database Driver Class Initialized
DEBUG - 2017-12-28 05:39:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 05:39:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 05:39:35 --> Form Validation Class Initialized
INFO - 2017-12-28 05:39:35 --> Model Class Initialized
INFO - 2017-12-28 05:39:35 --> Controller Class Initialized
INFO - 2017-12-28 05:39:35 --> Model Class Initialized
INFO - 2017-12-28 05:39:35 --> Model Class Initialized
INFO - 2017-12-28 05:39:35 --> Model Class Initialized
INFO - 2017-12-28 05:39:35 --> Model Class Initialized
DEBUG - 2017-12-28 05:39:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 05:39:35 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 05:39:35 --> Final output sent to browser
DEBUG - 2017-12-28 05:39:35 --> Total execution time: 0.0620
INFO - 2017-12-28 05:39:35 --> Config Class Initialized
INFO - 2017-12-28 05:39:35 --> Hooks Class Initialized
DEBUG - 2017-12-28 05:39:35 --> UTF-8 Support Enabled
INFO - 2017-12-28 05:39:35 --> Utf8 Class Initialized
INFO - 2017-12-28 05:39:35 --> URI Class Initialized
INFO - 2017-12-28 05:39:35 --> Router Class Initialized
INFO - 2017-12-28 05:39:35 --> Output Class Initialized
INFO - 2017-12-28 05:39:35 --> Security Class Initialized
DEBUG - 2017-12-28 05:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 05:39:35 --> Input Class Initialized
INFO - 2017-12-28 05:39:35 --> Language Class Initialized
ERROR - 2017-12-28 05:39:35 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-28 05:39:35 --> Config Class Initialized
INFO - 2017-12-28 05:39:35 --> Config Class Initialized
INFO - 2017-12-28 05:39:35 --> Hooks Class Initialized
INFO - 2017-12-28 05:39:35 --> Hooks Class Initialized
DEBUG - 2017-12-28 05:39:35 --> UTF-8 Support Enabled
INFO - 2017-12-28 05:39:35 --> Utf8 Class Initialized
DEBUG - 2017-12-28 05:39:35 --> UTF-8 Support Enabled
INFO - 2017-12-28 05:39:35 --> Utf8 Class Initialized
INFO - 2017-12-28 05:39:35 --> URI Class Initialized
INFO - 2017-12-28 05:39:35 --> URI Class Initialized
INFO - 2017-12-28 05:39:35 --> Router Class Initialized
INFO - 2017-12-28 05:39:35 --> Output Class Initialized
INFO - 2017-12-28 05:39:35 --> Router Class Initialized
INFO - 2017-12-28 05:39:35 --> Security Class Initialized
INFO - 2017-12-28 05:39:35 --> Output Class Initialized
DEBUG - 2017-12-28 05:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 05:39:35 --> Input Class Initialized
INFO - 2017-12-28 05:39:35 --> Language Class Initialized
INFO - 2017-12-28 05:39:35 --> Security Class Initialized
ERROR - 2017-12-28 05:39:35 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2017-12-28 05:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 05:39:35 --> Input Class Initialized
INFO - 2017-12-28 05:39:35 --> Language Class Initialized
ERROR - 2017-12-28 05:39:35 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-28 05:52:18 --> Config Class Initialized
INFO - 2017-12-28 05:52:18 --> Hooks Class Initialized
DEBUG - 2017-12-28 05:52:18 --> UTF-8 Support Enabled
INFO - 2017-12-28 05:52:18 --> Utf8 Class Initialized
INFO - 2017-12-28 05:52:18 --> URI Class Initialized
INFO - 2017-12-28 05:52:18 --> Router Class Initialized
INFO - 2017-12-28 05:52:18 --> Output Class Initialized
INFO - 2017-12-28 05:52:18 --> Security Class Initialized
DEBUG - 2017-12-28 05:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 05:52:18 --> Input Class Initialized
INFO - 2017-12-28 05:52:18 --> Language Class Initialized
INFO - 2017-12-28 05:52:18 --> Loader Class Initialized
INFO - 2017-12-28 05:52:18 --> Helper loaded: url_helper
INFO - 2017-12-28 05:52:18 --> Helper loaded: form_helper
INFO - 2017-12-28 05:52:18 --> Database Driver Class Initialized
DEBUG - 2017-12-28 05:52:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 05:52:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 05:52:18 --> Form Validation Class Initialized
INFO - 2017-12-28 05:52:18 --> Model Class Initialized
INFO - 2017-12-28 05:52:18 --> Controller Class Initialized
INFO - 2017-12-28 05:52:18 --> Model Class Initialized
INFO - 2017-12-28 05:52:18 --> Model Class Initialized
INFO - 2017-12-28 05:52:18 --> Model Class Initialized
INFO - 2017-12-28 05:52:18 --> Model Class Initialized
DEBUG - 2017-12-28 05:52:18 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2017-12-28 05:52:18 --> Severity: Error --> Call to undefined method M_Proveedor::consultarEstadosGastos() D:\xampp\htdocs\instateccr\instatec_app\controllers\Proyecto.php 298
INFO - 2017-12-28 05:52:47 --> Config Class Initialized
INFO - 2017-12-28 05:52:47 --> Hooks Class Initialized
DEBUG - 2017-12-28 05:52:47 --> UTF-8 Support Enabled
INFO - 2017-12-28 05:52:47 --> Utf8 Class Initialized
INFO - 2017-12-28 05:52:47 --> URI Class Initialized
INFO - 2017-12-28 05:52:47 --> Router Class Initialized
INFO - 2017-12-28 05:52:47 --> Output Class Initialized
INFO - 2017-12-28 05:52:47 --> Security Class Initialized
DEBUG - 2017-12-28 05:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 05:52:47 --> Input Class Initialized
INFO - 2017-12-28 05:52:47 --> Language Class Initialized
INFO - 2017-12-28 05:52:47 --> Loader Class Initialized
INFO - 2017-12-28 05:52:47 --> Helper loaded: url_helper
INFO - 2017-12-28 05:52:47 --> Helper loaded: form_helper
INFO - 2017-12-28 05:52:47 --> Database Driver Class Initialized
DEBUG - 2017-12-28 05:52:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 05:52:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 05:52:47 --> Form Validation Class Initialized
INFO - 2017-12-28 05:52:47 --> Model Class Initialized
INFO - 2017-12-28 05:52:47 --> Controller Class Initialized
INFO - 2017-12-28 05:52:47 --> Model Class Initialized
INFO - 2017-12-28 05:52:47 --> Model Class Initialized
INFO - 2017-12-28 05:52:47 --> Model Class Initialized
INFO - 2017-12-28 05:52:47 --> Model Class Initialized
DEBUG - 2017-12-28 05:52:47 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2017-12-28 05:52:47 --> Query error: Table 'instateccr.prooyecto_gasto_estado' doesn't exist - Invalid query: SELECT *
FROM `prooyecto_gasto_estado`
INFO - 2017-12-28 05:52:47 --> Language file loaded: language/english/db_lang.php
INFO - 2017-12-28 05:55:43 --> Config Class Initialized
INFO - 2017-12-28 05:55:43 --> Hooks Class Initialized
DEBUG - 2017-12-28 05:55:43 --> UTF-8 Support Enabled
INFO - 2017-12-28 05:55:43 --> Utf8 Class Initialized
INFO - 2017-12-28 05:55:43 --> URI Class Initialized
INFO - 2017-12-28 05:55:43 --> Router Class Initialized
INFO - 2017-12-28 05:55:43 --> Output Class Initialized
INFO - 2017-12-28 05:55:43 --> Security Class Initialized
DEBUG - 2017-12-28 05:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 05:55:43 --> Input Class Initialized
INFO - 2017-12-28 05:55:43 --> Language Class Initialized
INFO - 2017-12-28 05:55:43 --> Loader Class Initialized
INFO - 2017-12-28 05:55:43 --> Helper loaded: url_helper
INFO - 2017-12-28 05:55:43 --> Helper loaded: form_helper
INFO - 2017-12-28 05:55:43 --> Database Driver Class Initialized
DEBUG - 2017-12-28 05:55:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 05:55:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 05:55:43 --> Form Validation Class Initialized
INFO - 2017-12-28 05:55:43 --> Model Class Initialized
INFO - 2017-12-28 05:55:43 --> Controller Class Initialized
INFO - 2017-12-28 05:55:43 --> Model Class Initialized
INFO - 2017-12-28 05:55:43 --> Model Class Initialized
INFO - 2017-12-28 05:55:43 --> Model Class Initialized
INFO - 2017-12-28 05:55:43 --> Model Class Initialized
DEBUG - 2017-12-28 05:55:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 05:55:43 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 05:55:43 --> Final output sent to browser
DEBUG - 2017-12-28 05:55:43 --> Total execution time: 0.0759
INFO - 2017-12-28 05:55:43 --> Config Class Initialized
INFO - 2017-12-28 05:55:43 --> Hooks Class Initialized
DEBUG - 2017-12-28 05:55:43 --> UTF-8 Support Enabled
INFO - 2017-12-28 05:55:43 --> Utf8 Class Initialized
INFO - 2017-12-28 05:55:43 --> URI Class Initialized
INFO - 2017-12-28 05:55:43 --> Router Class Initialized
INFO - 2017-12-28 05:55:43 --> Output Class Initialized
INFO - 2017-12-28 05:55:43 --> Security Class Initialized
DEBUG - 2017-12-28 05:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 05:55:43 --> Input Class Initialized
INFO - 2017-12-28 05:55:43 --> Language Class Initialized
ERROR - 2017-12-28 05:55:43 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-28 05:55:43 --> Config Class Initialized
INFO - 2017-12-28 05:55:43 --> Hooks Class Initialized
INFO - 2017-12-28 05:55:43 --> Config Class Initialized
INFO - 2017-12-28 05:55:43 --> Hooks Class Initialized
DEBUG - 2017-12-28 05:55:43 --> UTF-8 Support Enabled
INFO - 2017-12-28 05:55:43 --> Utf8 Class Initialized
INFO - 2017-12-28 05:55:43 --> URI Class Initialized
INFO - 2017-12-28 05:55:43 --> Router Class Initialized
DEBUG - 2017-12-28 05:55:43 --> UTF-8 Support Enabled
INFO - 2017-12-28 05:55:43 --> Utf8 Class Initialized
INFO - 2017-12-28 05:55:43 --> Output Class Initialized
INFO - 2017-12-28 05:55:43 --> URI Class Initialized
INFO - 2017-12-28 05:55:43 --> Security Class Initialized
INFO - 2017-12-28 05:55:43 --> Router Class Initialized
DEBUG - 2017-12-28 05:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 05:55:43 --> Input Class Initialized
INFO - 2017-12-28 05:55:43 --> Output Class Initialized
INFO - 2017-12-28 05:55:43 --> Language Class Initialized
INFO - 2017-12-28 05:55:43 --> Security Class Initialized
ERROR - 2017-12-28 05:55:43 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2017-12-28 05:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 05:55:43 --> Input Class Initialized
INFO - 2017-12-28 05:55:43 --> Language Class Initialized
ERROR - 2017-12-28 05:55:43 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-28 05:56:38 --> Config Class Initialized
INFO - 2017-12-28 05:56:38 --> Hooks Class Initialized
DEBUG - 2017-12-28 05:56:38 --> UTF-8 Support Enabled
INFO - 2017-12-28 05:56:38 --> Utf8 Class Initialized
INFO - 2017-12-28 05:56:38 --> URI Class Initialized
INFO - 2017-12-28 05:56:38 --> Router Class Initialized
INFO - 2017-12-28 05:56:38 --> Output Class Initialized
INFO - 2017-12-28 05:56:38 --> Security Class Initialized
DEBUG - 2017-12-28 05:56:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 05:56:38 --> Input Class Initialized
INFO - 2017-12-28 05:56:38 --> Language Class Initialized
INFO - 2017-12-28 05:56:38 --> Loader Class Initialized
INFO - 2017-12-28 05:56:38 --> Helper loaded: url_helper
INFO - 2017-12-28 05:56:38 --> Helper loaded: form_helper
INFO - 2017-12-28 05:56:38 --> Database Driver Class Initialized
DEBUG - 2017-12-28 05:56:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 05:56:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 05:56:38 --> Form Validation Class Initialized
INFO - 2017-12-28 05:56:38 --> Model Class Initialized
INFO - 2017-12-28 05:56:38 --> Controller Class Initialized
INFO - 2017-12-28 05:56:38 --> Model Class Initialized
INFO - 2017-12-28 05:56:38 --> Model Class Initialized
INFO - 2017-12-28 05:56:38 --> Model Class Initialized
INFO - 2017-12-28 05:56:38 --> Model Class Initialized
DEBUG - 2017-12-28 05:56:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 05:56:38 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 05:56:39 --> Final output sent to browser
DEBUG - 2017-12-28 05:56:39 --> Total execution time: 0.0652
INFO - 2017-12-28 05:56:56 --> Config Class Initialized
INFO - 2017-12-28 05:56:56 --> Hooks Class Initialized
DEBUG - 2017-12-28 05:56:56 --> UTF-8 Support Enabled
INFO - 2017-12-28 05:56:56 --> Utf8 Class Initialized
INFO - 2017-12-28 05:56:56 --> URI Class Initialized
INFO - 2017-12-28 05:56:56 --> Router Class Initialized
INFO - 2017-12-28 05:56:56 --> Output Class Initialized
INFO - 2017-12-28 05:56:56 --> Security Class Initialized
DEBUG - 2017-12-28 05:56:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 05:56:56 --> Input Class Initialized
INFO - 2017-12-28 05:56:56 --> Language Class Initialized
INFO - 2017-12-28 05:56:56 --> Loader Class Initialized
INFO - 2017-12-28 05:56:56 --> Helper loaded: url_helper
INFO - 2017-12-28 05:56:56 --> Helper loaded: form_helper
INFO - 2017-12-28 05:56:56 --> Database Driver Class Initialized
DEBUG - 2017-12-28 05:56:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 05:56:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 05:56:56 --> Form Validation Class Initialized
INFO - 2017-12-28 05:56:56 --> Model Class Initialized
INFO - 2017-12-28 05:56:56 --> Controller Class Initialized
INFO - 2017-12-28 05:56:56 --> Model Class Initialized
INFO - 2017-12-28 05:56:56 --> Model Class Initialized
INFO - 2017-12-28 05:56:56 --> Model Class Initialized
INFO - 2017-12-28 05:56:56 --> Model Class Initialized
DEBUG - 2017-12-28 05:56:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 05:56:56 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 05:56:56 --> Final output sent to browser
DEBUG - 2017-12-28 05:56:56 --> Total execution time: 0.0530
INFO - 2017-12-28 06:00:11 --> Config Class Initialized
INFO - 2017-12-28 06:00:11 --> Hooks Class Initialized
DEBUG - 2017-12-28 06:00:11 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:00:11 --> Utf8 Class Initialized
INFO - 2017-12-28 06:00:11 --> URI Class Initialized
INFO - 2017-12-28 06:00:11 --> Router Class Initialized
INFO - 2017-12-28 06:00:11 --> Output Class Initialized
INFO - 2017-12-28 06:00:11 --> Security Class Initialized
DEBUG - 2017-12-28 06:00:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:00:11 --> Input Class Initialized
INFO - 2017-12-28 06:00:11 --> Language Class Initialized
INFO - 2017-12-28 06:00:11 --> Loader Class Initialized
INFO - 2017-12-28 06:00:11 --> Helper loaded: url_helper
INFO - 2017-12-28 06:00:11 --> Helper loaded: form_helper
INFO - 2017-12-28 06:00:11 --> Database Driver Class Initialized
DEBUG - 2017-12-28 06:00:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 06:00:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 06:00:11 --> Form Validation Class Initialized
INFO - 2017-12-28 06:00:11 --> Model Class Initialized
INFO - 2017-12-28 06:00:11 --> Controller Class Initialized
INFO - 2017-12-28 06:00:11 --> Model Class Initialized
INFO - 2017-12-28 06:00:11 --> Model Class Initialized
INFO - 2017-12-28 06:00:11 --> Model Class Initialized
INFO - 2017-12-28 06:00:11 --> Model Class Initialized
DEBUG - 2017-12-28 06:00:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 06:00:11 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 06:00:11 --> Final output sent to browser
DEBUG - 2017-12-28 06:00:11 --> Total execution time: 0.0581
INFO - 2017-12-28 06:00:14 --> Config Class Initialized
INFO - 2017-12-28 06:00:14 --> Hooks Class Initialized
DEBUG - 2017-12-28 06:00:14 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:00:14 --> Utf8 Class Initialized
INFO - 2017-12-28 06:00:14 --> URI Class Initialized
INFO - 2017-12-28 06:00:14 --> Router Class Initialized
INFO - 2017-12-28 06:00:14 --> Output Class Initialized
INFO - 2017-12-28 06:00:14 --> Security Class Initialized
DEBUG - 2017-12-28 06:00:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:00:14 --> Input Class Initialized
INFO - 2017-12-28 06:00:14 --> Language Class Initialized
ERROR - 2017-12-28 06:00:14 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-28 06:00:14 --> Config Class Initialized
INFO - 2017-12-28 06:00:14 --> Config Class Initialized
INFO - 2017-12-28 06:00:14 --> Hooks Class Initialized
INFO - 2017-12-28 06:00:14 --> Hooks Class Initialized
DEBUG - 2017-12-28 06:00:14 --> UTF-8 Support Enabled
DEBUG - 2017-12-28 06:00:14 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:00:14 --> Utf8 Class Initialized
INFO - 2017-12-28 06:00:14 --> Utf8 Class Initialized
INFO - 2017-12-28 06:00:14 --> URI Class Initialized
INFO - 2017-12-28 06:00:14 --> URI Class Initialized
INFO - 2017-12-28 06:00:14 --> Router Class Initialized
INFO - 2017-12-28 06:00:14 --> Router Class Initialized
INFO - 2017-12-28 06:00:14 --> Output Class Initialized
INFO - 2017-12-28 06:00:14 --> Output Class Initialized
INFO - 2017-12-28 06:00:14 --> Security Class Initialized
INFO - 2017-12-28 06:00:14 --> Security Class Initialized
DEBUG - 2017-12-28 06:00:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:00:14 --> Input Class Initialized
DEBUG - 2017-12-28 06:00:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:00:14 --> Language Class Initialized
INFO - 2017-12-28 06:00:14 --> Input Class Initialized
ERROR - 2017-12-28 06:00:14 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-28 06:00:14 --> Language Class Initialized
ERROR - 2017-12-28 06:00:14 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-28 06:06:58 --> Config Class Initialized
INFO - 2017-12-28 06:06:58 --> Hooks Class Initialized
DEBUG - 2017-12-28 06:06:58 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:06:58 --> Utf8 Class Initialized
INFO - 2017-12-28 06:06:58 --> URI Class Initialized
INFO - 2017-12-28 06:06:58 --> Router Class Initialized
INFO - 2017-12-28 06:06:58 --> Output Class Initialized
INFO - 2017-12-28 06:06:58 --> Security Class Initialized
DEBUG - 2017-12-28 06:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:06:58 --> Input Class Initialized
INFO - 2017-12-28 06:06:58 --> Language Class Initialized
INFO - 2017-12-28 06:06:58 --> Loader Class Initialized
INFO - 2017-12-28 06:06:58 --> Helper loaded: url_helper
INFO - 2017-12-28 06:06:58 --> Helper loaded: form_helper
INFO - 2017-12-28 06:06:58 --> Database Driver Class Initialized
DEBUG - 2017-12-28 06:06:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 06:06:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 06:06:58 --> Form Validation Class Initialized
INFO - 2017-12-28 06:06:58 --> Model Class Initialized
INFO - 2017-12-28 06:06:58 --> Controller Class Initialized
INFO - 2017-12-28 06:06:58 --> Model Class Initialized
INFO - 2017-12-28 06:06:58 --> Model Class Initialized
INFO - 2017-12-28 06:06:58 --> Model Class Initialized
INFO - 2017-12-28 06:06:58 --> Model Class Initialized
DEBUG - 2017-12-28 06:06:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 06:06:58 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 06:06:58 --> Final output sent to browser
DEBUG - 2017-12-28 06:06:58 --> Total execution time: 0.0746
INFO - 2017-12-28 06:06:58 --> Config Class Initialized
INFO - 2017-12-28 06:06:58 --> Hooks Class Initialized
INFO - 2017-12-28 06:06:58 --> Config Class Initialized
INFO - 2017-12-28 06:06:58 --> Hooks Class Initialized
DEBUG - 2017-12-28 06:06:58 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:06:58 --> Utf8 Class Initialized
DEBUG - 2017-12-28 06:06:58 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:06:58 --> Utf8 Class Initialized
INFO - 2017-12-28 06:06:58 --> URI Class Initialized
INFO - 2017-12-28 06:06:58 --> URI Class Initialized
INFO - 2017-12-28 06:06:58 --> Router Class Initialized
INFO - 2017-12-28 06:06:58 --> Router Class Initialized
INFO - 2017-12-28 06:06:58 --> Output Class Initialized
INFO - 2017-12-28 06:06:58 --> Output Class Initialized
INFO - 2017-12-28 06:06:58 --> Security Class Initialized
INFO - 2017-12-28 06:06:58 --> Security Class Initialized
DEBUG - 2017-12-28 06:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:06:58 --> Input Class Initialized
DEBUG - 2017-12-28 06:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:06:58 --> Language Class Initialized
INFO - 2017-12-28 06:06:58 --> Input Class Initialized
ERROR - 2017-12-28 06:06:58 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-28 06:06:58 --> Language Class Initialized
ERROR - 2017-12-28 06:06:58 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-28 06:07:00 --> Config Class Initialized
INFO - 2017-12-28 06:07:00 --> Hooks Class Initialized
DEBUG - 2017-12-28 06:07:00 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:07:00 --> Utf8 Class Initialized
INFO - 2017-12-28 06:07:00 --> URI Class Initialized
INFO - 2017-12-28 06:07:00 --> Router Class Initialized
INFO - 2017-12-28 06:07:00 --> Output Class Initialized
INFO - 2017-12-28 06:07:00 --> Security Class Initialized
DEBUG - 2017-12-28 06:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:07:00 --> Input Class Initialized
INFO - 2017-12-28 06:07:00 --> Language Class Initialized
ERROR - 2017-12-28 06:07:00 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-28 06:07:12 --> Config Class Initialized
INFO - 2017-12-28 06:07:12 --> Hooks Class Initialized
DEBUG - 2017-12-28 06:07:12 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:07:12 --> Utf8 Class Initialized
INFO - 2017-12-28 06:07:12 --> URI Class Initialized
INFO - 2017-12-28 06:07:12 --> Router Class Initialized
INFO - 2017-12-28 06:07:12 --> Output Class Initialized
INFO - 2017-12-28 06:07:12 --> Security Class Initialized
DEBUG - 2017-12-28 06:07:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:07:12 --> Input Class Initialized
INFO - 2017-12-28 06:07:12 --> Language Class Initialized
INFO - 2017-12-28 06:07:12 --> Loader Class Initialized
INFO - 2017-12-28 06:07:12 --> Helper loaded: url_helper
INFO - 2017-12-28 06:07:12 --> Helper loaded: form_helper
INFO - 2017-12-28 06:07:12 --> Database Driver Class Initialized
DEBUG - 2017-12-28 06:07:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 06:07:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 06:07:12 --> Form Validation Class Initialized
INFO - 2017-12-28 06:07:12 --> Model Class Initialized
INFO - 2017-12-28 06:07:12 --> Controller Class Initialized
INFO - 2017-12-28 06:07:12 --> Model Class Initialized
INFO - 2017-12-28 06:07:12 --> Model Class Initialized
INFO - 2017-12-28 06:07:12 --> Model Class Initialized
INFO - 2017-12-28 06:07:12 --> Model Class Initialized
DEBUG - 2017-12-28 06:07:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 06:07:12 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 06:07:12 --> Final output sent to browser
DEBUG - 2017-12-28 06:07:12 --> Total execution time: 0.1022
INFO - 2017-12-28 06:07:14 --> Config Class Initialized
INFO - 2017-12-28 06:07:14 --> Hooks Class Initialized
DEBUG - 2017-12-28 06:07:14 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:07:14 --> Utf8 Class Initialized
INFO - 2017-12-28 06:07:14 --> URI Class Initialized
INFO - 2017-12-28 06:07:14 --> Router Class Initialized
INFO - 2017-12-28 06:07:14 --> Output Class Initialized
INFO - 2017-12-28 06:07:14 --> Security Class Initialized
DEBUG - 2017-12-28 06:07:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:07:14 --> Input Class Initialized
INFO - 2017-12-28 06:07:14 --> Language Class Initialized
ERROR - 2017-12-28 06:07:14 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-28 06:07:14 --> Config Class Initialized
INFO - 2017-12-28 06:07:14 --> Hooks Class Initialized
INFO - 2017-12-28 06:07:14 --> Config Class Initialized
INFO - 2017-12-28 06:07:14 --> Hooks Class Initialized
DEBUG - 2017-12-28 06:07:14 --> UTF-8 Support Enabled
DEBUG - 2017-12-28 06:07:14 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:07:14 --> Utf8 Class Initialized
INFO - 2017-12-28 06:07:14 --> Utf8 Class Initialized
INFO - 2017-12-28 06:07:14 --> URI Class Initialized
INFO - 2017-12-28 06:07:14 --> URI Class Initialized
INFO - 2017-12-28 06:07:14 --> Router Class Initialized
INFO - 2017-12-28 06:07:14 --> Router Class Initialized
INFO - 2017-12-28 06:07:14 --> Output Class Initialized
INFO - 2017-12-28 06:07:14 --> Output Class Initialized
INFO - 2017-12-28 06:07:14 --> Security Class Initialized
INFO - 2017-12-28 06:07:14 --> Security Class Initialized
DEBUG - 2017-12-28 06:07:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-28 06:07:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:07:14 --> Input Class Initialized
INFO - 2017-12-28 06:07:14 --> Input Class Initialized
INFO - 2017-12-28 06:07:14 --> Language Class Initialized
INFO - 2017-12-28 06:07:14 --> Language Class Initialized
ERROR - 2017-12-28 06:07:14 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-28 06:07:14 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-28 06:07:57 --> Config Class Initialized
INFO - 2017-12-28 06:07:57 --> Hooks Class Initialized
DEBUG - 2017-12-28 06:07:57 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:07:57 --> Utf8 Class Initialized
INFO - 2017-12-28 06:07:57 --> URI Class Initialized
INFO - 2017-12-28 06:07:57 --> Router Class Initialized
INFO - 2017-12-28 06:07:57 --> Output Class Initialized
INFO - 2017-12-28 06:07:57 --> Security Class Initialized
DEBUG - 2017-12-28 06:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:07:57 --> Input Class Initialized
INFO - 2017-12-28 06:07:57 --> Language Class Initialized
INFO - 2017-12-28 06:07:57 --> Loader Class Initialized
INFO - 2017-12-28 06:07:57 --> Helper loaded: url_helper
INFO - 2017-12-28 06:07:57 --> Helper loaded: form_helper
INFO - 2017-12-28 06:07:57 --> Database Driver Class Initialized
DEBUG - 2017-12-28 06:07:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 06:07:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 06:07:57 --> Form Validation Class Initialized
INFO - 2017-12-28 06:07:57 --> Model Class Initialized
INFO - 2017-12-28 06:07:57 --> Controller Class Initialized
INFO - 2017-12-28 06:07:57 --> Model Class Initialized
INFO - 2017-12-28 06:07:57 --> Model Class Initialized
INFO - 2017-12-28 06:07:57 --> Model Class Initialized
INFO - 2017-12-28 06:07:57 --> Model Class Initialized
DEBUG - 2017-12-28 06:07:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 06:07:57 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 06:07:57 --> Final output sent to browser
DEBUG - 2017-12-28 06:07:57 --> Total execution time: 0.0518
INFO - 2017-12-28 06:07:59 --> Config Class Initialized
INFO - 2017-12-28 06:07:59 --> Hooks Class Initialized
DEBUG - 2017-12-28 06:07:59 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:07:59 --> Utf8 Class Initialized
INFO - 2017-12-28 06:07:59 --> URI Class Initialized
INFO - 2017-12-28 06:07:59 --> Router Class Initialized
INFO - 2017-12-28 06:07:59 --> Output Class Initialized
INFO - 2017-12-28 06:07:59 --> Security Class Initialized
DEBUG - 2017-12-28 06:07:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:07:59 --> Input Class Initialized
INFO - 2017-12-28 06:07:59 --> Language Class Initialized
ERROR - 2017-12-28 06:07:59 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-28 06:07:59 --> Config Class Initialized
INFO - 2017-12-28 06:07:59 --> Hooks Class Initialized
INFO - 2017-12-28 06:07:59 --> Config Class Initialized
INFO - 2017-12-28 06:07:59 --> Hooks Class Initialized
DEBUG - 2017-12-28 06:07:59 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:07:59 --> Utf8 Class Initialized
DEBUG - 2017-12-28 06:07:59 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:07:59 --> Utf8 Class Initialized
INFO - 2017-12-28 06:07:59 --> URI Class Initialized
INFO - 2017-12-28 06:07:59 --> URI Class Initialized
INFO - 2017-12-28 06:07:59 --> Router Class Initialized
INFO - 2017-12-28 06:07:59 --> Router Class Initialized
INFO - 2017-12-28 06:07:59 --> Output Class Initialized
INFO - 2017-12-28 06:07:59 --> Output Class Initialized
INFO - 2017-12-28 06:07:59 --> Security Class Initialized
INFO - 2017-12-28 06:07:59 --> Security Class Initialized
DEBUG - 2017-12-28 06:07:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:07:59 --> Input Class Initialized
INFO - 2017-12-28 06:07:59 --> Language Class Initialized
DEBUG - 2017-12-28 06:07:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:07:59 --> Input Class Initialized
INFO - 2017-12-28 06:07:59 --> Language Class Initialized
ERROR - 2017-12-28 06:07:59 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-28 06:07:59 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-28 06:07:59 --> Config Class Initialized
INFO - 2017-12-28 06:07:59 --> Hooks Class Initialized
DEBUG - 2017-12-28 06:07:59 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:07:59 --> Utf8 Class Initialized
INFO - 2017-12-28 06:07:59 --> URI Class Initialized
INFO - 2017-12-28 06:07:59 --> Router Class Initialized
INFO - 2017-12-28 06:07:59 --> Output Class Initialized
INFO - 2017-12-28 06:07:59 --> Security Class Initialized
DEBUG - 2017-12-28 06:07:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:07:59 --> Input Class Initialized
INFO - 2017-12-28 06:07:59 --> Language Class Initialized
ERROR - 2017-12-28 06:07:59 --> 404 Page Not Found: Faviconico/index
INFO - 2017-12-28 06:08:10 --> Config Class Initialized
INFO - 2017-12-28 06:08:10 --> Hooks Class Initialized
DEBUG - 2017-12-28 06:08:10 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:08:10 --> Utf8 Class Initialized
INFO - 2017-12-28 06:08:10 --> URI Class Initialized
INFO - 2017-12-28 06:08:10 --> Router Class Initialized
INFO - 2017-12-28 06:08:10 --> Output Class Initialized
INFO - 2017-12-28 06:08:10 --> Security Class Initialized
DEBUG - 2017-12-28 06:08:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:08:10 --> Input Class Initialized
INFO - 2017-12-28 06:08:10 --> Language Class Initialized
INFO - 2017-12-28 06:08:10 --> Loader Class Initialized
INFO - 2017-12-28 06:08:10 --> Helper loaded: url_helper
INFO - 2017-12-28 06:08:10 --> Helper loaded: form_helper
INFO - 2017-12-28 06:08:10 --> Database Driver Class Initialized
DEBUG - 2017-12-28 06:08:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 06:08:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 06:08:10 --> Form Validation Class Initialized
INFO - 2017-12-28 06:08:10 --> Model Class Initialized
INFO - 2017-12-28 06:08:10 --> Controller Class Initialized
INFO - 2017-12-28 06:08:10 --> Model Class Initialized
INFO - 2017-12-28 06:08:10 --> Model Class Initialized
INFO - 2017-12-28 06:08:10 --> Model Class Initialized
INFO - 2017-12-28 06:08:10 --> Model Class Initialized
DEBUG - 2017-12-28 06:08:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 06:08:10 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 06:08:10 --> Final output sent to browser
DEBUG - 2017-12-28 06:08:10 --> Total execution time: 0.0679
INFO - 2017-12-28 06:08:10 --> Config Class Initialized
INFO - 2017-12-28 06:08:10 --> Hooks Class Initialized
DEBUG - 2017-12-28 06:08:10 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:08:10 --> Utf8 Class Initialized
INFO - 2017-12-28 06:08:10 --> URI Class Initialized
INFO - 2017-12-28 06:08:10 --> Router Class Initialized
INFO - 2017-12-28 06:08:10 --> Output Class Initialized
INFO - 2017-12-28 06:08:10 --> Security Class Initialized
DEBUG - 2017-12-28 06:08:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:08:10 --> Input Class Initialized
INFO - 2017-12-28 06:08:10 --> Language Class Initialized
ERROR - 2017-12-28 06:08:10 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-28 06:08:10 --> Config Class Initialized
INFO - 2017-12-28 06:08:10 --> Hooks Class Initialized
INFO - 2017-12-28 06:08:10 --> Config Class Initialized
INFO - 2017-12-28 06:08:10 --> Hooks Class Initialized
DEBUG - 2017-12-28 06:08:10 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:08:10 --> Utf8 Class Initialized
INFO - 2017-12-28 06:08:10 --> URI Class Initialized
DEBUG - 2017-12-28 06:08:10 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:08:10 --> Utf8 Class Initialized
INFO - 2017-12-28 06:08:10 --> Router Class Initialized
INFO - 2017-12-28 06:08:10 --> URI Class Initialized
INFO - 2017-12-28 06:08:10 --> Output Class Initialized
INFO - 2017-12-28 06:08:10 --> Router Class Initialized
INFO - 2017-12-28 06:08:10 --> Security Class Initialized
DEBUG - 2017-12-28 06:08:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:08:10 --> Output Class Initialized
INFO - 2017-12-28 06:08:10 --> Input Class Initialized
INFO - 2017-12-28 06:08:10 --> Language Class Initialized
INFO - 2017-12-28 06:08:10 --> Security Class Initialized
ERROR - 2017-12-28 06:08:10 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2017-12-28 06:08:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:08:10 --> Input Class Initialized
INFO - 2017-12-28 06:08:10 --> Language Class Initialized
ERROR - 2017-12-28 06:08:10 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-28 06:08:43 --> Config Class Initialized
INFO - 2017-12-28 06:08:43 --> Hooks Class Initialized
DEBUG - 2017-12-28 06:08:43 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:08:43 --> Utf8 Class Initialized
INFO - 2017-12-28 06:08:43 --> URI Class Initialized
INFO - 2017-12-28 06:08:43 --> Router Class Initialized
INFO - 2017-12-28 06:08:43 --> Output Class Initialized
INFO - 2017-12-28 06:08:43 --> Security Class Initialized
DEBUG - 2017-12-28 06:08:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:08:43 --> Input Class Initialized
INFO - 2017-12-28 06:08:43 --> Language Class Initialized
INFO - 2017-12-28 06:08:43 --> Loader Class Initialized
INFO - 2017-12-28 06:08:43 --> Helper loaded: url_helper
INFO - 2017-12-28 06:08:43 --> Helper loaded: form_helper
INFO - 2017-12-28 06:08:43 --> Database Driver Class Initialized
DEBUG - 2017-12-28 06:08:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 06:08:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 06:08:43 --> Form Validation Class Initialized
INFO - 2017-12-28 06:08:43 --> Model Class Initialized
INFO - 2017-12-28 06:08:43 --> Controller Class Initialized
INFO - 2017-12-28 06:08:43 --> Model Class Initialized
INFO - 2017-12-28 06:08:43 --> Model Class Initialized
INFO - 2017-12-28 06:08:43 --> Model Class Initialized
INFO - 2017-12-28 06:08:43 --> Model Class Initialized
DEBUG - 2017-12-28 06:08:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 06:08:43 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 06:08:43 --> Final output sent to browser
DEBUG - 2017-12-28 06:08:43 --> Total execution time: 0.0511
INFO - 2017-12-28 06:08:44 --> Config Class Initialized
INFO - 2017-12-28 06:08:44 --> Hooks Class Initialized
DEBUG - 2017-12-28 06:08:44 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:08:44 --> Utf8 Class Initialized
INFO - 2017-12-28 06:08:44 --> URI Class Initialized
INFO - 2017-12-28 06:08:44 --> Router Class Initialized
INFO - 2017-12-28 06:08:44 --> Output Class Initialized
INFO - 2017-12-28 06:08:44 --> Security Class Initialized
DEBUG - 2017-12-28 06:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:08:44 --> Input Class Initialized
INFO - 2017-12-28 06:08:44 --> Language Class Initialized
ERROR - 2017-12-28 06:08:44 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-28 06:08:44 --> Config Class Initialized
INFO - 2017-12-28 06:08:44 --> Hooks Class Initialized
INFO - 2017-12-28 06:08:44 --> Config Class Initialized
INFO - 2017-12-28 06:08:44 --> Hooks Class Initialized
DEBUG - 2017-12-28 06:08:44 --> UTF-8 Support Enabled
DEBUG - 2017-12-28 06:08:44 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:08:44 --> Utf8 Class Initialized
INFO - 2017-12-28 06:08:44 --> Utf8 Class Initialized
INFO - 2017-12-28 06:08:44 --> URI Class Initialized
INFO - 2017-12-28 06:08:44 --> URI Class Initialized
INFO - 2017-12-28 06:08:44 --> Router Class Initialized
INFO - 2017-12-28 06:08:44 --> Router Class Initialized
INFO - 2017-12-28 06:08:44 --> Output Class Initialized
INFO - 2017-12-28 06:08:44 --> Output Class Initialized
INFO - 2017-12-28 06:08:44 --> Security Class Initialized
INFO - 2017-12-28 06:08:44 --> Security Class Initialized
DEBUG - 2017-12-28 06:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:08:44 --> Input Class Initialized
DEBUG - 2017-12-28 06:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:08:44 --> Input Class Initialized
INFO - 2017-12-28 06:08:44 --> Language Class Initialized
INFO - 2017-12-28 06:08:44 --> Language Class Initialized
ERROR - 2017-12-28 06:08:44 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-28 06:08:44 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-28 06:10:01 --> Config Class Initialized
INFO - 2017-12-28 06:10:01 --> Hooks Class Initialized
DEBUG - 2017-12-28 06:10:01 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:10:01 --> Utf8 Class Initialized
INFO - 2017-12-28 06:10:01 --> URI Class Initialized
INFO - 2017-12-28 06:10:01 --> Router Class Initialized
INFO - 2017-12-28 06:10:01 --> Output Class Initialized
INFO - 2017-12-28 06:10:01 --> Security Class Initialized
DEBUG - 2017-12-28 06:10:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:10:01 --> Input Class Initialized
INFO - 2017-12-28 06:10:01 --> Language Class Initialized
INFO - 2017-12-28 06:10:01 --> Loader Class Initialized
INFO - 2017-12-28 06:10:01 --> Helper loaded: url_helper
INFO - 2017-12-28 06:10:01 --> Helper loaded: form_helper
INFO - 2017-12-28 06:10:01 --> Database Driver Class Initialized
DEBUG - 2017-12-28 06:10:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 06:10:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 06:10:01 --> Form Validation Class Initialized
INFO - 2017-12-28 06:10:01 --> Model Class Initialized
INFO - 2017-12-28 06:10:01 --> Controller Class Initialized
INFO - 2017-12-28 06:10:01 --> Model Class Initialized
INFO - 2017-12-28 06:10:01 --> Model Class Initialized
INFO - 2017-12-28 06:10:01 --> Model Class Initialized
INFO - 2017-12-28 06:10:01 --> Model Class Initialized
DEBUG - 2017-12-28 06:10:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 06:10:01 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 06:10:01 --> Final output sent to browser
DEBUG - 2017-12-28 06:10:01 --> Total execution time: 0.0689
INFO - 2017-12-28 06:10:02 --> Config Class Initialized
INFO - 2017-12-28 06:10:02 --> Hooks Class Initialized
DEBUG - 2017-12-28 06:10:02 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:10:02 --> Utf8 Class Initialized
INFO - 2017-12-28 06:10:02 --> URI Class Initialized
INFO - 2017-12-28 06:10:02 --> Router Class Initialized
INFO - 2017-12-28 06:10:02 --> Output Class Initialized
INFO - 2017-12-28 06:10:02 --> Security Class Initialized
DEBUG - 2017-12-28 06:10:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:10:02 --> Input Class Initialized
INFO - 2017-12-28 06:10:02 --> Language Class Initialized
ERROR - 2017-12-28 06:10:02 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-28 06:10:02 --> Config Class Initialized
INFO - 2017-12-28 06:10:02 --> Hooks Class Initialized
INFO - 2017-12-28 06:10:02 --> Config Class Initialized
INFO - 2017-12-28 06:10:02 --> Hooks Class Initialized
DEBUG - 2017-12-28 06:10:02 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:10:02 --> Utf8 Class Initialized
DEBUG - 2017-12-28 06:10:02 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:10:02 --> Utf8 Class Initialized
INFO - 2017-12-28 06:10:02 --> URI Class Initialized
INFO - 2017-12-28 06:10:02 --> URI Class Initialized
INFO - 2017-12-28 06:10:02 --> Router Class Initialized
INFO - 2017-12-28 06:10:02 --> Router Class Initialized
INFO - 2017-12-28 06:10:02 --> Output Class Initialized
INFO - 2017-12-28 06:10:02 --> Output Class Initialized
INFO - 2017-12-28 06:10:02 --> Security Class Initialized
INFO - 2017-12-28 06:10:02 --> Security Class Initialized
DEBUG - 2017-12-28 06:10:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:10:02 --> Input Class Initialized
INFO - 2017-12-28 06:10:02 --> Language Class Initialized
DEBUG - 2017-12-28 06:10:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:10:02 --> Input Class Initialized
ERROR - 2017-12-28 06:10:02 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-28 06:10:02 --> Language Class Initialized
ERROR - 2017-12-28 06:10:02 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-28 06:11:20 --> Config Class Initialized
INFO - 2017-12-28 06:11:20 --> Hooks Class Initialized
DEBUG - 2017-12-28 06:11:20 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:11:20 --> Utf8 Class Initialized
INFO - 2017-12-28 06:11:20 --> URI Class Initialized
INFO - 2017-12-28 06:11:20 --> Router Class Initialized
INFO - 2017-12-28 06:11:20 --> Output Class Initialized
INFO - 2017-12-28 06:11:20 --> Security Class Initialized
DEBUG - 2017-12-28 06:11:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:11:20 --> Input Class Initialized
INFO - 2017-12-28 06:11:20 --> Language Class Initialized
INFO - 2017-12-28 06:11:20 --> Loader Class Initialized
INFO - 2017-12-28 06:11:20 --> Helper loaded: url_helper
INFO - 2017-12-28 06:11:20 --> Helper loaded: form_helper
INFO - 2017-12-28 06:11:20 --> Database Driver Class Initialized
DEBUG - 2017-12-28 06:11:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 06:11:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 06:11:20 --> Form Validation Class Initialized
INFO - 2017-12-28 06:11:20 --> Model Class Initialized
INFO - 2017-12-28 06:11:20 --> Controller Class Initialized
INFO - 2017-12-28 06:11:20 --> Model Class Initialized
INFO - 2017-12-28 06:11:20 --> Model Class Initialized
INFO - 2017-12-28 06:11:20 --> Model Class Initialized
INFO - 2017-12-28 06:11:20 --> Model Class Initialized
DEBUG - 2017-12-28 06:11:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 06:11:20 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 06:11:20 --> Final output sent to browser
DEBUG - 2017-12-28 06:11:20 --> Total execution time: 0.0773
INFO - 2017-12-28 06:11:20 --> Config Class Initialized
INFO - 2017-12-28 06:11:20 --> Hooks Class Initialized
DEBUG - 2017-12-28 06:11:20 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:11:20 --> Utf8 Class Initialized
INFO - 2017-12-28 06:11:20 --> URI Class Initialized
INFO - 2017-12-28 06:11:20 --> Router Class Initialized
INFO - 2017-12-28 06:11:20 --> Output Class Initialized
INFO - 2017-12-28 06:11:20 --> Security Class Initialized
DEBUG - 2017-12-28 06:11:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:11:20 --> Input Class Initialized
INFO - 2017-12-28 06:11:20 --> Language Class Initialized
ERROR - 2017-12-28 06:11:20 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-28 06:11:20 --> Config Class Initialized
INFO - 2017-12-28 06:11:20 --> Hooks Class Initialized
INFO - 2017-12-28 06:11:20 --> Config Class Initialized
DEBUG - 2017-12-28 06:11:20 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:11:20 --> Hooks Class Initialized
INFO - 2017-12-28 06:11:20 --> Utf8 Class Initialized
INFO - 2017-12-28 06:11:20 --> URI Class Initialized
INFO - 2017-12-28 06:11:20 --> Router Class Initialized
DEBUG - 2017-12-28 06:11:20 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:11:20 --> Utf8 Class Initialized
INFO - 2017-12-28 06:11:20 --> Output Class Initialized
INFO - 2017-12-28 06:11:20 --> URI Class Initialized
INFO - 2017-12-28 06:11:20 --> Security Class Initialized
DEBUG - 2017-12-28 06:11:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:11:20 --> Input Class Initialized
INFO - 2017-12-28 06:11:20 --> Router Class Initialized
INFO - 2017-12-28 06:11:20 --> Language Class Initialized
ERROR - 2017-12-28 06:11:20 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-28 06:11:20 --> Output Class Initialized
INFO - 2017-12-28 06:11:20 --> Security Class Initialized
DEBUG - 2017-12-28 06:11:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:11:20 --> Input Class Initialized
INFO - 2017-12-28 06:11:20 --> Language Class Initialized
ERROR - 2017-12-28 06:11:20 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-28 06:11:49 --> Config Class Initialized
INFO - 2017-12-28 06:11:49 --> Hooks Class Initialized
DEBUG - 2017-12-28 06:11:49 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:11:49 --> Utf8 Class Initialized
INFO - 2017-12-28 06:11:49 --> URI Class Initialized
INFO - 2017-12-28 06:11:49 --> Router Class Initialized
INFO - 2017-12-28 06:11:49 --> Output Class Initialized
INFO - 2017-12-28 06:11:49 --> Security Class Initialized
DEBUG - 2017-12-28 06:11:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:11:49 --> Input Class Initialized
INFO - 2017-12-28 06:11:49 --> Language Class Initialized
INFO - 2017-12-28 06:11:49 --> Loader Class Initialized
INFO - 2017-12-28 06:11:49 --> Helper loaded: url_helper
INFO - 2017-12-28 06:11:49 --> Helper loaded: form_helper
INFO - 2017-12-28 06:11:49 --> Database Driver Class Initialized
DEBUG - 2017-12-28 06:11:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 06:11:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 06:11:49 --> Form Validation Class Initialized
INFO - 2017-12-28 06:11:49 --> Model Class Initialized
INFO - 2017-12-28 06:11:49 --> Controller Class Initialized
INFO - 2017-12-28 06:11:49 --> Model Class Initialized
INFO - 2017-12-28 06:11:49 --> Model Class Initialized
INFO - 2017-12-28 06:11:49 --> Model Class Initialized
INFO - 2017-12-28 06:11:49 --> Model Class Initialized
DEBUG - 2017-12-28 06:11:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 06:11:49 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 06:11:49 --> Final output sent to browser
DEBUG - 2017-12-28 06:11:49 --> Total execution time: 0.0740
INFO - 2017-12-28 06:11:49 --> Config Class Initialized
INFO - 2017-12-28 06:11:49 --> Hooks Class Initialized
INFO - 2017-12-28 06:11:49 --> Config Class Initialized
INFO - 2017-12-28 06:11:49 --> Hooks Class Initialized
DEBUG - 2017-12-28 06:11:49 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:11:49 --> Utf8 Class Initialized
INFO - 2017-12-28 06:11:49 --> URI Class Initialized
DEBUG - 2017-12-28 06:11:49 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:11:49 --> Utf8 Class Initialized
INFO - 2017-12-28 06:11:49 --> Router Class Initialized
INFO - 2017-12-28 06:11:49 --> URI Class Initialized
INFO - 2017-12-28 06:11:49 --> Output Class Initialized
INFO - 2017-12-28 06:11:49 --> Router Class Initialized
INFO - 2017-12-28 06:11:49 --> Security Class Initialized
INFO - 2017-12-28 06:11:49 --> Output Class Initialized
DEBUG - 2017-12-28 06:11:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:11:49 --> Input Class Initialized
INFO - 2017-12-28 06:11:49 --> Security Class Initialized
INFO - 2017-12-28 06:11:49 --> Language Class Initialized
DEBUG - 2017-12-28 06:11:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2017-12-28 06:11:49 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-28 06:11:49 --> Input Class Initialized
INFO - 2017-12-28 06:11:49 --> Language Class Initialized
ERROR - 2017-12-28 06:11:49 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-28 06:11:50 --> Config Class Initialized
INFO - 2017-12-28 06:11:50 --> Hooks Class Initialized
DEBUG - 2017-12-28 06:11:50 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:11:50 --> Utf8 Class Initialized
INFO - 2017-12-28 06:11:50 --> URI Class Initialized
INFO - 2017-12-28 06:11:50 --> Router Class Initialized
INFO - 2017-12-28 06:11:50 --> Output Class Initialized
INFO - 2017-12-28 06:11:50 --> Security Class Initialized
DEBUG - 2017-12-28 06:11:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:11:50 --> Input Class Initialized
INFO - 2017-12-28 06:11:50 --> Language Class Initialized
ERROR - 2017-12-28 06:11:50 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-28 06:15:05 --> Config Class Initialized
INFO - 2017-12-28 06:15:05 --> Hooks Class Initialized
DEBUG - 2017-12-28 06:15:05 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:15:05 --> Utf8 Class Initialized
INFO - 2017-12-28 06:15:05 --> URI Class Initialized
INFO - 2017-12-28 06:15:05 --> Router Class Initialized
INFO - 2017-12-28 06:15:05 --> Output Class Initialized
INFO - 2017-12-28 06:15:05 --> Security Class Initialized
DEBUG - 2017-12-28 06:15:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:15:05 --> Input Class Initialized
INFO - 2017-12-28 06:15:05 --> Language Class Initialized
INFO - 2017-12-28 06:15:05 --> Loader Class Initialized
INFO - 2017-12-28 06:15:05 --> Helper loaded: url_helper
INFO - 2017-12-28 06:15:05 --> Helper loaded: form_helper
INFO - 2017-12-28 06:15:05 --> Database Driver Class Initialized
DEBUG - 2017-12-28 06:15:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 06:15:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 06:15:05 --> Form Validation Class Initialized
INFO - 2017-12-28 06:15:05 --> Model Class Initialized
INFO - 2017-12-28 06:15:05 --> Controller Class Initialized
INFO - 2017-12-28 06:15:05 --> Model Class Initialized
INFO - 2017-12-28 06:15:05 --> Model Class Initialized
INFO - 2017-12-28 06:15:05 --> Model Class Initialized
INFO - 2017-12-28 06:15:05 --> Model Class Initialized
DEBUG - 2017-12-28 06:15:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 06:15:05 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 06:15:05 --> Final output sent to browser
DEBUG - 2017-12-28 06:15:05 --> Total execution time: 0.0747
INFO - 2017-12-28 06:15:06 --> Config Class Initialized
INFO - 2017-12-28 06:15:06 --> Hooks Class Initialized
DEBUG - 2017-12-28 06:15:06 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:15:06 --> Utf8 Class Initialized
INFO - 2017-12-28 06:15:06 --> URI Class Initialized
INFO - 2017-12-28 06:15:06 --> Router Class Initialized
INFO - 2017-12-28 06:15:06 --> Output Class Initialized
INFO - 2017-12-28 06:15:06 --> Security Class Initialized
DEBUG - 2017-12-28 06:15:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:15:06 --> Input Class Initialized
INFO - 2017-12-28 06:15:06 --> Language Class Initialized
ERROR - 2017-12-28 06:15:06 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-28 06:15:06 --> Config Class Initialized
INFO - 2017-12-28 06:15:06 --> Hooks Class Initialized
INFO - 2017-12-28 06:15:06 --> Config Class Initialized
INFO - 2017-12-28 06:15:06 --> Hooks Class Initialized
DEBUG - 2017-12-28 06:15:06 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:15:06 --> Utf8 Class Initialized
DEBUG - 2017-12-28 06:15:06 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:15:06 --> Utf8 Class Initialized
INFO - 2017-12-28 06:15:06 --> URI Class Initialized
INFO - 2017-12-28 06:15:06 --> URI Class Initialized
INFO - 2017-12-28 06:15:06 --> Router Class Initialized
INFO - 2017-12-28 06:15:06 --> Router Class Initialized
INFO - 2017-12-28 06:15:06 --> Output Class Initialized
INFO - 2017-12-28 06:15:06 --> Security Class Initialized
INFO - 2017-12-28 06:15:06 --> Output Class Initialized
DEBUG - 2017-12-28 06:15:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:15:06 --> Input Class Initialized
INFO - 2017-12-28 06:15:06 --> Security Class Initialized
INFO - 2017-12-28 06:15:06 --> Language Class Initialized
DEBUG - 2017-12-28 06:15:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2017-12-28 06:15:06 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-28 06:15:06 --> Input Class Initialized
INFO - 2017-12-28 06:15:06 --> Language Class Initialized
ERROR - 2017-12-28 06:15:06 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-28 06:16:08 --> Config Class Initialized
INFO - 2017-12-28 06:16:08 --> Hooks Class Initialized
DEBUG - 2017-12-28 06:16:08 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:16:08 --> Utf8 Class Initialized
INFO - 2017-12-28 06:16:08 --> URI Class Initialized
INFO - 2017-12-28 06:16:08 --> Router Class Initialized
INFO - 2017-12-28 06:16:08 --> Output Class Initialized
INFO - 2017-12-28 06:16:08 --> Security Class Initialized
DEBUG - 2017-12-28 06:16:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:16:08 --> Input Class Initialized
INFO - 2017-12-28 06:16:08 --> Language Class Initialized
INFO - 2017-12-28 06:16:08 --> Loader Class Initialized
INFO - 2017-12-28 06:16:08 --> Helper loaded: url_helper
INFO - 2017-12-28 06:16:08 --> Helper loaded: form_helper
INFO - 2017-12-28 06:16:08 --> Database Driver Class Initialized
DEBUG - 2017-12-28 06:16:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 06:16:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 06:16:08 --> Form Validation Class Initialized
INFO - 2017-12-28 06:16:08 --> Model Class Initialized
INFO - 2017-12-28 06:16:08 --> Controller Class Initialized
INFO - 2017-12-28 06:16:08 --> Model Class Initialized
INFO - 2017-12-28 06:16:08 --> Model Class Initialized
INFO - 2017-12-28 06:16:09 --> Model Class Initialized
INFO - 2017-12-28 06:16:09 --> Model Class Initialized
DEBUG - 2017-12-28 06:16:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 06:16:09 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 06:16:09 --> Final output sent to browser
DEBUG - 2017-12-28 06:16:09 --> Total execution time: 0.0773
INFO - 2017-12-28 06:16:09 --> Config Class Initialized
INFO - 2017-12-28 06:16:09 --> Hooks Class Initialized
DEBUG - 2017-12-28 06:16:09 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:16:09 --> Utf8 Class Initialized
INFO - 2017-12-28 06:16:09 --> URI Class Initialized
INFO - 2017-12-28 06:16:09 --> Router Class Initialized
INFO - 2017-12-28 06:16:09 --> Output Class Initialized
INFO - 2017-12-28 06:16:09 --> Security Class Initialized
DEBUG - 2017-12-28 06:16:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:16:09 --> Input Class Initialized
INFO - 2017-12-28 06:16:09 --> Language Class Initialized
ERROR - 2017-12-28 06:16:09 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-28 06:16:09 --> Config Class Initialized
INFO - 2017-12-28 06:16:09 --> Hooks Class Initialized
INFO - 2017-12-28 06:16:09 --> Config Class Initialized
INFO - 2017-12-28 06:16:09 --> Hooks Class Initialized
DEBUG - 2017-12-28 06:16:09 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:16:09 --> Utf8 Class Initialized
DEBUG - 2017-12-28 06:16:09 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:16:09 --> Utf8 Class Initialized
INFO - 2017-12-28 06:16:09 --> URI Class Initialized
INFO - 2017-12-28 06:16:09 --> URI Class Initialized
INFO - 2017-12-28 06:16:09 --> Router Class Initialized
INFO - 2017-12-28 06:16:09 --> Router Class Initialized
INFO - 2017-12-28 06:16:09 --> Output Class Initialized
INFO - 2017-12-28 06:16:09 --> Output Class Initialized
INFO - 2017-12-28 06:16:09 --> Security Class Initialized
DEBUG - 2017-12-28 06:16:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:16:09 --> Input Class Initialized
INFO - 2017-12-28 06:16:09 --> Security Class Initialized
INFO - 2017-12-28 06:16:09 --> Language Class Initialized
DEBUG - 2017-12-28 06:16:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:16:09 --> Input Class Initialized
ERROR - 2017-12-28 06:16:09 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-28 06:16:09 --> Language Class Initialized
ERROR - 2017-12-28 06:16:09 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-28 06:16:09 --> Config Class Initialized
INFO - 2017-12-28 06:16:09 --> Hooks Class Initialized
DEBUG - 2017-12-28 06:16:09 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:16:09 --> Utf8 Class Initialized
INFO - 2017-12-28 06:16:09 --> URI Class Initialized
INFO - 2017-12-28 06:16:09 --> Router Class Initialized
INFO - 2017-12-28 06:16:09 --> Output Class Initialized
INFO - 2017-12-28 06:16:09 --> Security Class Initialized
DEBUG - 2017-12-28 06:16:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:16:09 --> Input Class Initialized
INFO - 2017-12-28 06:16:09 --> Language Class Initialized
INFO - 2017-12-28 06:16:09 --> Loader Class Initialized
INFO - 2017-12-28 06:16:09 --> Helper loaded: url_helper
INFO - 2017-12-28 06:16:09 --> Helper loaded: form_helper
INFO - 2017-12-28 06:16:09 --> Database Driver Class Initialized
DEBUG - 2017-12-28 06:16:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 06:16:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 06:16:09 --> Form Validation Class Initialized
INFO - 2017-12-28 06:16:09 --> Model Class Initialized
INFO - 2017-12-28 06:16:09 --> Controller Class Initialized
INFO - 2017-12-28 06:16:09 --> Model Class Initialized
INFO - 2017-12-28 06:16:09 --> Model Class Initialized
INFO - 2017-12-28 06:16:09 --> Model Class Initialized
INFO - 2017-12-28 06:16:09 --> Model Class Initialized
DEBUG - 2017-12-28 06:16:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 06:16:09 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 06:16:09 --> Final output sent to browser
DEBUG - 2017-12-28 06:16:09 --> Total execution time: 0.0766
INFO - 2017-12-28 06:16:09 --> Config Class Initialized
INFO - 2017-12-28 06:16:09 --> Hooks Class Initialized
DEBUG - 2017-12-28 06:16:09 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:16:09 --> Utf8 Class Initialized
INFO - 2017-12-28 06:16:09 --> URI Class Initialized
INFO - 2017-12-28 06:16:09 --> Router Class Initialized
INFO - 2017-12-28 06:16:10 --> Output Class Initialized
INFO - 2017-12-28 06:16:10 --> Security Class Initialized
DEBUG - 2017-12-28 06:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:16:10 --> Input Class Initialized
INFO - 2017-12-28 06:16:10 --> Language Class Initialized
ERROR - 2017-12-28 06:16:10 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-28 06:16:10 --> Config Class Initialized
INFO - 2017-12-28 06:16:10 --> Hooks Class Initialized
INFO - 2017-12-28 06:16:10 --> Config Class Initialized
INFO - 2017-12-28 06:16:10 --> Hooks Class Initialized
DEBUG - 2017-12-28 06:16:10 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:16:10 --> Utf8 Class Initialized
DEBUG - 2017-12-28 06:16:10 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:16:10 --> Utf8 Class Initialized
INFO - 2017-12-28 06:16:10 --> URI Class Initialized
INFO - 2017-12-28 06:16:10 --> URI Class Initialized
INFO - 2017-12-28 06:16:10 --> Router Class Initialized
INFO - 2017-12-28 06:16:10 --> Router Class Initialized
INFO - 2017-12-28 06:16:10 --> Output Class Initialized
INFO - 2017-12-28 06:16:10 --> Output Class Initialized
INFO - 2017-12-28 06:16:10 --> Security Class Initialized
INFO - 2017-12-28 06:16:10 --> Security Class Initialized
DEBUG - 2017-12-28 06:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:16:10 --> Input Class Initialized
DEBUG - 2017-12-28 06:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:16:10 --> Input Class Initialized
INFO - 2017-12-28 06:16:10 --> Language Class Initialized
INFO - 2017-12-28 06:16:10 --> Language Class Initialized
ERROR - 2017-12-28 06:16:10 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-28 06:16:10 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-28 06:19:46 --> Config Class Initialized
INFO - 2017-12-28 06:19:46 --> Hooks Class Initialized
DEBUG - 2017-12-28 06:19:46 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:19:46 --> Utf8 Class Initialized
INFO - 2017-12-28 06:19:46 --> URI Class Initialized
INFO - 2017-12-28 06:19:46 --> Router Class Initialized
INFO - 2017-12-28 06:19:46 --> Output Class Initialized
INFO - 2017-12-28 06:19:46 --> Security Class Initialized
DEBUG - 2017-12-28 06:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:19:46 --> Input Class Initialized
INFO - 2017-12-28 06:19:46 --> Language Class Initialized
INFO - 2017-12-28 06:19:46 --> Loader Class Initialized
INFO - 2017-12-28 06:19:46 --> Helper loaded: url_helper
INFO - 2017-12-28 06:19:46 --> Helper loaded: form_helper
INFO - 2017-12-28 06:19:46 --> Database Driver Class Initialized
DEBUG - 2017-12-28 06:19:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 06:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 06:19:46 --> Form Validation Class Initialized
INFO - 2017-12-28 06:19:46 --> Model Class Initialized
INFO - 2017-12-28 06:19:46 --> Controller Class Initialized
INFO - 2017-12-28 06:19:46 --> Model Class Initialized
INFO - 2017-12-28 06:19:46 --> Model Class Initialized
INFO - 2017-12-28 06:19:46 --> Model Class Initialized
INFO - 2017-12-28 06:19:46 --> Model Class Initialized
DEBUG - 2017-12-28 06:19:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 06:19:46 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 06:19:46 --> Final output sent to browser
DEBUG - 2017-12-28 06:19:46 --> Total execution time: 0.0721
INFO - 2017-12-28 06:19:46 --> Config Class Initialized
INFO - 2017-12-28 06:19:46 --> Hooks Class Initialized
DEBUG - 2017-12-28 06:19:46 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:19:46 --> Utf8 Class Initialized
INFO - 2017-12-28 06:19:46 --> URI Class Initialized
INFO - 2017-12-28 06:19:46 --> Router Class Initialized
INFO - 2017-12-28 06:19:46 --> Output Class Initialized
INFO - 2017-12-28 06:19:46 --> Security Class Initialized
DEBUG - 2017-12-28 06:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:19:46 --> Input Class Initialized
INFO - 2017-12-28 06:19:46 --> Language Class Initialized
ERROR - 2017-12-28 06:19:46 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-28 06:19:46 --> Config Class Initialized
INFO - 2017-12-28 06:19:46 --> Config Class Initialized
INFO - 2017-12-28 06:19:46 --> Hooks Class Initialized
INFO - 2017-12-28 06:19:46 --> Hooks Class Initialized
DEBUG - 2017-12-28 06:19:46 --> UTF-8 Support Enabled
DEBUG - 2017-12-28 06:19:46 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:19:46 --> Utf8 Class Initialized
INFO - 2017-12-28 06:19:46 --> Utf8 Class Initialized
INFO - 2017-12-28 06:19:46 --> URI Class Initialized
INFO - 2017-12-28 06:19:46 --> URI Class Initialized
INFO - 2017-12-28 06:19:46 --> Router Class Initialized
INFO - 2017-12-28 06:19:46 --> Router Class Initialized
INFO - 2017-12-28 06:19:46 --> Output Class Initialized
INFO - 2017-12-28 06:19:46 --> Output Class Initialized
INFO - 2017-12-28 06:19:46 --> Security Class Initialized
INFO - 2017-12-28 06:19:46 --> Security Class Initialized
DEBUG - 2017-12-28 06:19:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-28 06:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:19:46 --> Input Class Initialized
INFO - 2017-12-28 06:19:46 --> Input Class Initialized
INFO - 2017-12-28 06:19:46 --> Language Class Initialized
INFO - 2017-12-28 06:19:46 --> Language Class Initialized
ERROR - 2017-12-28 06:19:46 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-28 06:19:46 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-28 06:28:07 --> Config Class Initialized
INFO - 2017-12-28 06:28:07 --> Hooks Class Initialized
DEBUG - 2017-12-28 06:28:07 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:28:07 --> Utf8 Class Initialized
INFO - 2017-12-28 06:28:07 --> URI Class Initialized
INFO - 2017-12-28 06:28:07 --> Router Class Initialized
INFO - 2017-12-28 06:28:07 --> Output Class Initialized
INFO - 2017-12-28 06:28:07 --> Security Class Initialized
DEBUG - 2017-12-28 06:28:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:28:07 --> Input Class Initialized
INFO - 2017-12-28 06:28:07 --> Language Class Initialized
INFO - 2017-12-28 06:28:07 --> Loader Class Initialized
INFO - 2017-12-28 06:28:07 --> Helper loaded: url_helper
INFO - 2017-12-28 06:28:07 --> Helper loaded: form_helper
INFO - 2017-12-28 06:28:07 --> Database Driver Class Initialized
DEBUG - 2017-12-28 06:28:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 06:28:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 06:28:07 --> Form Validation Class Initialized
INFO - 2017-12-28 06:28:07 --> Model Class Initialized
INFO - 2017-12-28 06:28:07 --> Controller Class Initialized
INFO - 2017-12-28 06:28:07 --> Model Class Initialized
INFO - 2017-12-28 06:28:07 --> Model Class Initialized
INFO - 2017-12-28 06:28:07 --> Model Class Initialized
INFO - 2017-12-28 06:28:07 --> Model Class Initialized
DEBUG - 2017-12-28 06:28:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 06:28:07 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 06:28:07 --> Final output sent to browser
DEBUG - 2017-12-28 06:28:07 --> Total execution time: 0.0615
INFO - 2017-12-28 06:28:08 --> Config Class Initialized
INFO - 2017-12-28 06:28:08 --> Config Class Initialized
INFO - 2017-12-28 06:28:08 --> Config Class Initialized
INFO - 2017-12-28 06:28:08 --> Hooks Class Initialized
INFO - 2017-12-28 06:28:08 --> Hooks Class Initialized
INFO - 2017-12-28 06:28:08 --> Hooks Class Initialized
DEBUG - 2017-12-28 06:28:08 --> UTF-8 Support Enabled
DEBUG - 2017-12-28 06:28:08 --> UTF-8 Support Enabled
DEBUG - 2017-12-28 06:28:08 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:28:08 --> Utf8 Class Initialized
INFO - 2017-12-28 06:28:08 --> Utf8 Class Initialized
INFO - 2017-12-28 06:28:08 --> Utf8 Class Initialized
INFO - 2017-12-28 06:28:08 --> URI Class Initialized
INFO - 2017-12-28 06:28:08 --> URI Class Initialized
INFO - 2017-12-28 06:28:08 --> URI Class Initialized
INFO - 2017-12-28 06:28:08 --> Router Class Initialized
INFO - 2017-12-28 06:28:08 --> Router Class Initialized
INFO - 2017-12-28 06:28:08 --> Router Class Initialized
INFO - 2017-12-28 06:28:08 --> Output Class Initialized
INFO - 2017-12-28 06:28:08 --> Output Class Initialized
INFO - 2017-12-28 06:28:08 --> Output Class Initialized
INFO - 2017-12-28 06:28:08 --> Security Class Initialized
INFO - 2017-12-28 06:28:08 --> Security Class Initialized
INFO - 2017-12-28 06:28:08 --> Security Class Initialized
DEBUG - 2017-12-28 06:28:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-28 06:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:28:08 --> Input Class Initialized
DEBUG - 2017-12-28 06:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:28:08 --> Input Class Initialized
INFO - 2017-12-28 06:28:08 --> Input Class Initialized
INFO - 2017-12-28 06:28:08 --> Language Class Initialized
INFO - 2017-12-28 06:28:08 --> Language Class Initialized
INFO - 2017-12-28 06:28:08 --> Language Class Initialized
ERROR - 2017-12-28 06:28:08 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-28 06:28:08 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2017-12-28 06:28:08 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-28 06:28:53 --> Config Class Initialized
INFO - 2017-12-28 06:28:53 --> Hooks Class Initialized
DEBUG - 2017-12-28 06:28:53 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:28:53 --> Utf8 Class Initialized
INFO - 2017-12-28 06:28:53 --> URI Class Initialized
INFO - 2017-12-28 06:28:53 --> Router Class Initialized
INFO - 2017-12-28 06:28:53 --> Output Class Initialized
INFO - 2017-12-28 06:28:53 --> Security Class Initialized
DEBUG - 2017-12-28 06:28:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:28:53 --> Input Class Initialized
INFO - 2017-12-28 06:28:53 --> Language Class Initialized
INFO - 2017-12-28 06:28:53 --> Loader Class Initialized
INFO - 2017-12-28 06:28:53 --> Helper loaded: url_helper
INFO - 2017-12-28 06:28:53 --> Helper loaded: form_helper
INFO - 2017-12-28 06:28:53 --> Database Driver Class Initialized
DEBUG - 2017-12-28 06:28:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 06:28:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 06:28:53 --> Form Validation Class Initialized
INFO - 2017-12-28 06:28:53 --> Model Class Initialized
INFO - 2017-12-28 06:28:53 --> Controller Class Initialized
INFO - 2017-12-28 06:28:53 --> Model Class Initialized
INFO - 2017-12-28 06:28:53 --> Model Class Initialized
INFO - 2017-12-28 06:28:53 --> Model Class Initialized
INFO - 2017-12-28 06:28:53 --> Model Class Initialized
DEBUG - 2017-12-28 06:28:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 06:28:53 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 06:28:53 --> Final output sent to browser
DEBUG - 2017-12-28 06:28:53 --> Total execution time: 0.0671
INFO - 2017-12-28 06:28:53 --> Config Class Initialized
INFO - 2017-12-28 06:28:53 --> Hooks Class Initialized
DEBUG - 2017-12-28 06:28:53 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:28:53 --> Utf8 Class Initialized
INFO - 2017-12-28 06:28:53 --> URI Class Initialized
INFO - 2017-12-28 06:28:53 --> Router Class Initialized
INFO - 2017-12-28 06:28:53 --> Output Class Initialized
INFO - 2017-12-28 06:28:53 --> Security Class Initialized
DEBUG - 2017-12-28 06:28:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:28:53 --> Input Class Initialized
INFO - 2017-12-28 06:28:53 --> Language Class Initialized
ERROR - 2017-12-28 06:28:53 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-28 06:28:53 --> Config Class Initialized
INFO - 2017-12-28 06:28:53 --> Hooks Class Initialized
INFO - 2017-12-28 06:28:53 --> Config Class Initialized
INFO - 2017-12-28 06:28:53 --> Hooks Class Initialized
DEBUG - 2017-12-28 06:28:53 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:28:53 --> Utf8 Class Initialized
DEBUG - 2017-12-28 06:28:53 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:28:53 --> Utf8 Class Initialized
INFO - 2017-12-28 06:28:53 --> URI Class Initialized
INFO - 2017-12-28 06:28:53 --> URI Class Initialized
INFO - 2017-12-28 06:28:53 --> Router Class Initialized
INFO - 2017-12-28 06:28:53 --> Router Class Initialized
INFO - 2017-12-28 06:28:53 --> Output Class Initialized
INFO - 2017-12-28 06:28:53 --> Output Class Initialized
INFO - 2017-12-28 06:28:53 --> Security Class Initialized
INFO - 2017-12-28 06:28:53 --> Security Class Initialized
DEBUG - 2017-12-28 06:28:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:28:53 --> Input Class Initialized
DEBUG - 2017-12-28 06:28:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:28:53 --> Input Class Initialized
INFO - 2017-12-28 06:28:53 --> Language Class Initialized
INFO - 2017-12-28 06:28:53 --> Language Class Initialized
ERROR - 2017-12-28 06:28:53 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-28 06:28:53 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-28 06:28:57 --> Config Class Initialized
INFO - 2017-12-28 06:28:57 --> Hooks Class Initialized
DEBUG - 2017-12-28 06:28:58 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:28:58 --> Utf8 Class Initialized
INFO - 2017-12-28 06:28:58 --> URI Class Initialized
INFO - 2017-12-28 06:28:58 --> Router Class Initialized
INFO - 2017-12-28 06:28:58 --> Output Class Initialized
INFO - 2017-12-28 06:28:58 --> Security Class Initialized
DEBUG - 2017-12-28 06:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:28:58 --> Input Class Initialized
INFO - 2017-12-28 06:28:58 --> Language Class Initialized
INFO - 2017-12-28 06:28:58 --> Loader Class Initialized
INFO - 2017-12-28 06:28:58 --> Helper loaded: url_helper
INFO - 2017-12-28 06:28:58 --> Helper loaded: form_helper
INFO - 2017-12-28 06:28:58 --> Database Driver Class Initialized
DEBUG - 2017-12-28 06:28:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 06:28:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 06:28:58 --> Form Validation Class Initialized
INFO - 2017-12-28 06:28:58 --> Model Class Initialized
INFO - 2017-12-28 06:28:58 --> Controller Class Initialized
INFO - 2017-12-28 06:28:58 --> Model Class Initialized
INFO - 2017-12-28 06:28:58 --> Model Class Initialized
INFO - 2017-12-28 06:28:58 --> Model Class Initialized
INFO - 2017-12-28 06:28:58 --> Model Class Initialized
DEBUG - 2017-12-28 06:28:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 06:28:58 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 06:28:58 --> Final output sent to browser
DEBUG - 2017-12-28 06:28:58 --> Total execution time: 0.0659
INFO - 2017-12-28 06:28:58 --> Config Class Initialized
INFO - 2017-12-28 06:28:58 --> Config Class Initialized
INFO - 2017-12-28 06:28:58 --> Hooks Class Initialized
INFO - 2017-12-28 06:28:58 --> Hooks Class Initialized
DEBUG - 2017-12-28 06:28:58 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:28:58 --> Utf8 Class Initialized
DEBUG - 2017-12-28 06:28:58 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:28:58 --> Utf8 Class Initialized
INFO - 2017-12-28 06:28:58 --> URI Class Initialized
INFO - 2017-12-28 06:28:58 --> URI Class Initialized
INFO - 2017-12-28 06:28:58 --> Router Class Initialized
INFO - 2017-12-28 06:28:58 --> Router Class Initialized
INFO - 2017-12-28 06:28:58 --> Output Class Initialized
INFO - 2017-12-28 06:28:58 --> Output Class Initialized
INFO - 2017-12-28 06:28:58 --> Security Class Initialized
INFO - 2017-12-28 06:28:58 --> Security Class Initialized
DEBUG - 2017-12-28 06:28:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-28 06:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:28:58 --> Input Class Initialized
INFO - 2017-12-28 06:28:58 --> Input Class Initialized
INFO - 2017-12-28 06:28:58 --> Language Class Initialized
INFO - 2017-12-28 06:28:58 --> Language Class Initialized
ERROR - 2017-12-28 06:28:58 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-28 06:28:58 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-28 06:29:03 --> Config Class Initialized
INFO - 2017-12-28 06:29:03 --> Hooks Class Initialized
DEBUG - 2017-12-28 06:29:03 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:29:03 --> Utf8 Class Initialized
INFO - 2017-12-28 06:29:03 --> URI Class Initialized
INFO - 2017-12-28 06:29:03 --> Router Class Initialized
INFO - 2017-12-28 06:29:03 --> Output Class Initialized
INFO - 2017-12-28 06:29:03 --> Security Class Initialized
DEBUG - 2017-12-28 06:29:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:29:03 --> Input Class Initialized
INFO - 2017-12-28 06:29:03 --> Language Class Initialized
ERROR - 2017-12-28 06:29:03 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-28 06:32:34 --> Config Class Initialized
INFO - 2017-12-28 06:32:34 --> Hooks Class Initialized
DEBUG - 2017-12-28 06:32:34 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:32:34 --> Utf8 Class Initialized
INFO - 2017-12-28 06:32:34 --> URI Class Initialized
INFO - 2017-12-28 06:32:34 --> Router Class Initialized
INFO - 2017-12-28 06:32:34 --> Output Class Initialized
INFO - 2017-12-28 06:32:34 --> Security Class Initialized
DEBUG - 2017-12-28 06:32:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:32:34 --> Input Class Initialized
INFO - 2017-12-28 06:32:34 --> Language Class Initialized
INFO - 2017-12-28 06:32:34 --> Loader Class Initialized
INFO - 2017-12-28 06:32:34 --> Helper loaded: url_helper
INFO - 2017-12-28 06:32:34 --> Helper loaded: form_helper
INFO - 2017-12-28 06:32:34 --> Database Driver Class Initialized
DEBUG - 2017-12-28 06:32:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 06:32:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 06:32:34 --> Form Validation Class Initialized
INFO - 2017-12-28 06:32:34 --> Model Class Initialized
INFO - 2017-12-28 06:32:34 --> Controller Class Initialized
INFO - 2017-12-28 06:32:34 --> Model Class Initialized
INFO - 2017-12-28 06:32:34 --> Model Class Initialized
INFO - 2017-12-28 06:32:34 --> Model Class Initialized
INFO - 2017-12-28 06:32:34 --> Model Class Initialized
DEBUG - 2017-12-28 06:32:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 06:32:34 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 06:32:34 --> Final output sent to browser
DEBUG - 2017-12-28 06:32:34 --> Total execution time: 0.0772
INFO - 2017-12-28 06:32:34 --> Config Class Initialized
INFO - 2017-12-28 06:32:34 --> Hooks Class Initialized
DEBUG - 2017-12-28 06:32:34 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:32:34 --> Utf8 Class Initialized
INFO - 2017-12-28 06:32:34 --> URI Class Initialized
INFO - 2017-12-28 06:32:34 --> Router Class Initialized
INFO - 2017-12-28 06:32:34 --> Output Class Initialized
INFO - 2017-12-28 06:32:34 --> Security Class Initialized
DEBUG - 2017-12-28 06:32:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:32:34 --> Input Class Initialized
INFO - 2017-12-28 06:32:34 --> Language Class Initialized
ERROR - 2017-12-28 06:32:34 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-28 06:32:34 --> Config Class Initialized
INFO - 2017-12-28 06:32:34 --> Config Class Initialized
INFO - 2017-12-28 06:32:34 --> Hooks Class Initialized
INFO - 2017-12-28 06:32:34 --> Hooks Class Initialized
DEBUG - 2017-12-28 06:32:34 --> UTF-8 Support Enabled
DEBUG - 2017-12-28 06:32:34 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:32:34 --> Utf8 Class Initialized
INFO - 2017-12-28 06:32:34 --> Utf8 Class Initialized
INFO - 2017-12-28 06:32:34 --> URI Class Initialized
INFO - 2017-12-28 06:32:34 --> URI Class Initialized
INFO - 2017-12-28 06:32:34 --> Router Class Initialized
INFO - 2017-12-28 06:32:34 --> Router Class Initialized
INFO - 2017-12-28 06:32:34 --> Output Class Initialized
INFO - 2017-12-28 06:32:34 --> Output Class Initialized
INFO - 2017-12-28 06:32:34 --> Security Class Initialized
INFO - 2017-12-28 06:32:34 --> Security Class Initialized
DEBUG - 2017-12-28 06:32:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:32:34 --> Input Class Initialized
DEBUG - 2017-12-28 06:32:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:32:34 --> Input Class Initialized
INFO - 2017-12-28 06:32:34 --> Language Class Initialized
INFO - 2017-12-28 06:32:34 --> Language Class Initialized
ERROR - 2017-12-28 06:32:34 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-28 06:32:34 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-28 06:32:43 --> Config Class Initialized
INFO - 2017-12-28 06:32:43 --> Hooks Class Initialized
DEBUG - 2017-12-28 06:32:43 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:32:43 --> Utf8 Class Initialized
INFO - 2017-12-28 06:32:43 --> URI Class Initialized
INFO - 2017-12-28 06:32:43 --> Router Class Initialized
INFO - 2017-12-28 06:32:43 --> Output Class Initialized
INFO - 2017-12-28 06:32:43 --> Security Class Initialized
DEBUG - 2017-12-28 06:32:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:32:43 --> Input Class Initialized
INFO - 2017-12-28 06:32:43 --> Language Class Initialized
INFO - 2017-12-28 06:32:43 --> Loader Class Initialized
INFO - 2017-12-28 06:32:43 --> Helper loaded: url_helper
INFO - 2017-12-28 06:32:43 --> Helper loaded: form_helper
INFO - 2017-12-28 06:32:43 --> Database Driver Class Initialized
DEBUG - 2017-12-28 06:32:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 06:32:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 06:32:43 --> Form Validation Class Initialized
INFO - 2017-12-28 06:32:43 --> Model Class Initialized
INFO - 2017-12-28 06:32:43 --> Controller Class Initialized
INFO - 2017-12-28 06:32:43 --> Model Class Initialized
INFO - 2017-12-28 06:32:43 --> Model Class Initialized
INFO - 2017-12-28 06:32:43 --> Model Class Initialized
INFO - 2017-12-28 06:32:43 --> Model Class Initialized
DEBUG - 2017-12-28 06:32:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 06:32:43 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 06:32:43 --> Final output sent to browser
DEBUG - 2017-12-28 06:32:43 --> Total execution time: 0.0786
INFO - 2017-12-28 06:32:43 --> Config Class Initialized
INFO - 2017-12-28 06:32:43 --> Hooks Class Initialized
DEBUG - 2017-12-28 06:32:43 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:32:43 --> Utf8 Class Initialized
INFO - 2017-12-28 06:32:43 --> URI Class Initialized
INFO - 2017-12-28 06:32:43 --> Router Class Initialized
INFO - 2017-12-28 06:32:43 --> Output Class Initialized
INFO - 2017-12-28 06:32:43 --> Security Class Initialized
DEBUG - 2017-12-28 06:32:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:32:43 --> Input Class Initialized
INFO - 2017-12-28 06:32:43 --> Language Class Initialized
ERROR - 2017-12-28 06:32:43 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-28 06:32:43 --> Config Class Initialized
INFO - 2017-12-28 06:32:43 --> Hooks Class Initialized
INFO - 2017-12-28 06:32:43 --> Config Class Initialized
INFO - 2017-12-28 06:32:43 --> Hooks Class Initialized
DEBUG - 2017-12-28 06:32:43 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:32:43 --> Utf8 Class Initialized
INFO - 2017-12-28 06:32:43 --> URI Class Initialized
DEBUG - 2017-12-28 06:32:43 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:32:43 --> Utf8 Class Initialized
INFO - 2017-12-28 06:32:43 --> Router Class Initialized
INFO - 2017-12-28 06:32:43 --> URI Class Initialized
INFO - 2017-12-28 06:32:43 --> Output Class Initialized
INFO - 2017-12-28 06:32:43 --> Router Class Initialized
INFO - 2017-12-28 06:32:43 --> Security Class Initialized
DEBUG - 2017-12-28 06:32:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:32:43 --> Output Class Initialized
INFO - 2017-12-28 06:32:43 --> Input Class Initialized
INFO - 2017-12-28 06:32:43 --> Language Class Initialized
INFO - 2017-12-28 06:32:43 --> Security Class Initialized
ERROR - 2017-12-28 06:32:43 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2017-12-28 06:32:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:32:43 --> Input Class Initialized
INFO - 2017-12-28 06:32:43 --> Language Class Initialized
ERROR - 2017-12-28 06:32:43 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-28 06:35:46 --> Config Class Initialized
INFO - 2017-12-28 06:35:46 --> Hooks Class Initialized
DEBUG - 2017-12-28 06:35:46 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:35:46 --> Utf8 Class Initialized
INFO - 2017-12-28 06:35:46 --> URI Class Initialized
INFO - 2017-12-28 06:35:46 --> Router Class Initialized
INFO - 2017-12-28 06:35:46 --> Output Class Initialized
INFO - 2017-12-28 06:35:46 --> Security Class Initialized
DEBUG - 2017-12-28 06:35:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:35:46 --> Input Class Initialized
INFO - 2017-12-28 06:35:46 --> Language Class Initialized
INFO - 2017-12-28 06:35:46 --> Loader Class Initialized
INFO - 2017-12-28 06:35:46 --> Helper loaded: url_helper
INFO - 2017-12-28 06:35:46 --> Helper loaded: form_helper
INFO - 2017-12-28 06:35:46 --> Database Driver Class Initialized
DEBUG - 2017-12-28 06:35:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 06:35:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 06:35:46 --> Form Validation Class Initialized
INFO - 2017-12-28 06:35:46 --> Model Class Initialized
INFO - 2017-12-28 06:35:46 --> Controller Class Initialized
INFO - 2017-12-28 06:35:46 --> Model Class Initialized
INFO - 2017-12-28 06:35:46 --> Model Class Initialized
INFO - 2017-12-28 06:35:46 --> Model Class Initialized
INFO - 2017-12-28 06:35:46 --> Model Class Initialized
DEBUG - 2017-12-28 06:35:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 06:35:46 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 06:35:46 --> Final output sent to browser
DEBUG - 2017-12-28 06:35:46 --> Total execution time: 0.0560
INFO - 2017-12-28 06:35:46 --> Config Class Initialized
INFO - 2017-12-28 06:35:46 --> Hooks Class Initialized
DEBUG - 2017-12-28 06:35:46 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:35:46 --> Utf8 Class Initialized
INFO - 2017-12-28 06:35:46 --> URI Class Initialized
INFO - 2017-12-28 06:35:46 --> Router Class Initialized
INFO - 2017-12-28 06:35:46 --> Output Class Initialized
INFO - 2017-12-28 06:35:46 --> Security Class Initialized
DEBUG - 2017-12-28 06:35:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:35:46 --> Input Class Initialized
INFO - 2017-12-28 06:35:46 --> Language Class Initialized
ERROR - 2017-12-28 06:35:46 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-28 06:35:46 --> Config Class Initialized
INFO - 2017-12-28 06:35:46 --> Hooks Class Initialized
INFO - 2017-12-28 06:35:46 --> Config Class Initialized
INFO - 2017-12-28 06:35:46 --> Hooks Class Initialized
DEBUG - 2017-12-28 06:35:46 --> UTF-8 Support Enabled
DEBUG - 2017-12-28 06:35:46 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:35:46 --> Utf8 Class Initialized
INFO - 2017-12-28 06:35:46 --> Utf8 Class Initialized
INFO - 2017-12-28 06:35:46 --> URI Class Initialized
INFO - 2017-12-28 06:35:46 --> URI Class Initialized
INFO - 2017-12-28 06:35:46 --> Router Class Initialized
INFO - 2017-12-28 06:35:46 --> Router Class Initialized
INFO - 2017-12-28 06:35:46 --> Output Class Initialized
INFO - 2017-12-28 06:35:46 --> Output Class Initialized
INFO - 2017-12-28 06:35:46 --> Security Class Initialized
INFO - 2017-12-28 06:35:46 --> Security Class Initialized
DEBUG - 2017-12-28 06:35:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-28 06:35:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:35:46 --> Input Class Initialized
INFO - 2017-12-28 06:35:46 --> Input Class Initialized
INFO - 2017-12-28 06:35:46 --> Language Class Initialized
INFO - 2017-12-28 06:35:46 --> Language Class Initialized
ERROR - 2017-12-28 06:35:46 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-28 06:35:46 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-28 06:42:35 --> Config Class Initialized
INFO - 2017-12-28 06:42:35 --> Hooks Class Initialized
DEBUG - 2017-12-28 06:42:35 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:42:35 --> Utf8 Class Initialized
INFO - 2017-12-28 06:42:35 --> URI Class Initialized
INFO - 2017-12-28 06:42:35 --> Router Class Initialized
INFO - 2017-12-28 06:42:35 --> Output Class Initialized
INFO - 2017-12-28 06:42:35 --> Security Class Initialized
DEBUG - 2017-12-28 06:42:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:42:35 --> Input Class Initialized
INFO - 2017-12-28 06:42:35 --> Language Class Initialized
INFO - 2017-12-28 06:42:35 --> Loader Class Initialized
INFO - 2017-12-28 06:42:35 --> Helper loaded: url_helper
INFO - 2017-12-28 06:42:35 --> Helper loaded: form_helper
INFO - 2017-12-28 06:42:35 --> Database Driver Class Initialized
DEBUG - 2017-12-28 06:42:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 06:42:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 06:42:35 --> Form Validation Class Initialized
INFO - 2017-12-28 06:42:35 --> Model Class Initialized
INFO - 2017-12-28 06:42:35 --> Controller Class Initialized
INFO - 2017-12-28 06:42:35 --> Model Class Initialized
INFO - 2017-12-28 06:42:35 --> Model Class Initialized
INFO - 2017-12-28 06:42:35 --> Model Class Initialized
INFO - 2017-12-28 06:42:35 --> Model Class Initialized
DEBUG - 2017-12-28 06:42:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 06:42:35 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 06:42:35 --> Final output sent to browser
DEBUG - 2017-12-28 06:42:35 --> Total execution time: 0.0647
INFO - 2017-12-28 06:43:06 --> Config Class Initialized
INFO - 2017-12-28 06:43:06 --> Hooks Class Initialized
DEBUG - 2017-12-28 06:43:06 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:43:06 --> Utf8 Class Initialized
INFO - 2017-12-28 06:43:06 --> URI Class Initialized
INFO - 2017-12-28 06:43:06 --> Router Class Initialized
INFO - 2017-12-28 06:43:06 --> Output Class Initialized
INFO - 2017-12-28 06:43:06 --> Security Class Initialized
DEBUG - 2017-12-28 06:43:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:43:06 --> Input Class Initialized
INFO - 2017-12-28 06:43:06 --> Language Class Initialized
INFO - 2017-12-28 06:43:06 --> Loader Class Initialized
INFO - 2017-12-28 06:43:06 --> Helper loaded: url_helper
INFO - 2017-12-28 06:43:06 --> Helper loaded: form_helper
INFO - 2017-12-28 06:43:06 --> Database Driver Class Initialized
DEBUG - 2017-12-28 06:43:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 06:43:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 06:43:06 --> Form Validation Class Initialized
INFO - 2017-12-28 06:43:06 --> Model Class Initialized
INFO - 2017-12-28 06:43:06 --> Controller Class Initialized
INFO - 2017-12-28 06:43:06 --> Model Class Initialized
INFO - 2017-12-28 06:43:06 --> Model Class Initialized
INFO - 2017-12-28 06:43:06 --> Model Class Initialized
INFO - 2017-12-28 06:43:06 --> Model Class Initialized
DEBUG - 2017-12-28 06:43:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 06:43:06 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 06:43:06 --> Final output sent to browser
DEBUG - 2017-12-28 06:43:06 --> Total execution time: 0.0665
INFO - 2017-12-28 06:43:24 --> Config Class Initialized
INFO - 2017-12-28 06:43:24 --> Hooks Class Initialized
DEBUG - 2017-12-28 06:43:24 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:43:24 --> Utf8 Class Initialized
INFO - 2017-12-28 06:43:24 --> URI Class Initialized
INFO - 2017-12-28 06:43:24 --> Router Class Initialized
INFO - 2017-12-28 06:43:24 --> Output Class Initialized
INFO - 2017-12-28 06:43:24 --> Security Class Initialized
DEBUG - 2017-12-28 06:43:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:43:24 --> Input Class Initialized
INFO - 2017-12-28 06:43:24 --> Language Class Initialized
INFO - 2017-12-28 06:43:24 --> Loader Class Initialized
INFO - 2017-12-28 06:43:24 --> Helper loaded: url_helper
INFO - 2017-12-28 06:43:24 --> Helper loaded: form_helper
INFO - 2017-12-28 06:43:24 --> Database Driver Class Initialized
DEBUG - 2017-12-28 06:43:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 06:43:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 06:43:24 --> Form Validation Class Initialized
INFO - 2017-12-28 06:43:24 --> Model Class Initialized
INFO - 2017-12-28 06:43:24 --> Controller Class Initialized
INFO - 2017-12-28 06:43:24 --> Model Class Initialized
INFO - 2017-12-28 06:43:24 --> Model Class Initialized
INFO - 2017-12-28 06:43:24 --> Model Class Initialized
INFO - 2017-12-28 06:43:24 --> Model Class Initialized
DEBUG - 2017-12-28 06:43:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 06:43:24 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 06:43:24 --> Final output sent to browser
DEBUG - 2017-12-28 06:43:24 --> Total execution time: 0.0706
INFO - 2017-12-28 06:45:41 --> Config Class Initialized
INFO - 2017-12-28 06:45:41 --> Hooks Class Initialized
DEBUG - 2017-12-28 06:45:41 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:45:41 --> Utf8 Class Initialized
INFO - 2017-12-28 06:45:41 --> URI Class Initialized
INFO - 2017-12-28 06:45:41 --> Router Class Initialized
INFO - 2017-12-28 06:45:41 --> Output Class Initialized
INFO - 2017-12-28 06:45:41 --> Security Class Initialized
DEBUG - 2017-12-28 06:45:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:45:41 --> Input Class Initialized
INFO - 2017-12-28 06:45:41 --> Language Class Initialized
INFO - 2017-12-28 06:45:41 --> Loader Class Initialized
INFO - 2017-12-28 06:45:41 --> Helper loaded: url_helper
INFO - 2017-12-28 06:45:41 --> Helper loaded: form_helper
INFO - 2017-12-28 06:45:41 --> Database Driver Class Initialized
DEBUG - 2017-12-28 06:45:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 06:45:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 06:45:41 --> Form Validation Class Initialized
INFO - 2017-12-28 06:45:41 --> Model Class Initialized
INFO - 2017-12-28 06:45:41 --> Controller Class Initialized
INFO - 2017-12-28 06:45:41 --> Model Class Initialized
INFO - 2017-12-28 06:45:41 --> Model Class Initialized
INFO - 2017-12-28 06:45:41 --> Model Class Initialized
INFO - 2017-12-28 06:45:41 --> Model Class Initialized
DEBUG - 2017-12-28 06:45:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 06:45:41 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 06:45:41 --> Final output sent to browser
DEBUG - 2017-12-28 06:45:41 --> Total execution time: 0.0521
INFO - 2017-12-28 06:45:42 --> Config Class Initialized
INFO - 2017-12-28 06:45:42 --> Hooks Class Initialized
DEBUG - 2017-12-28 06:45:42 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:45:42 --> Utf8 Class Initialized
INFO - 2017-12-28 06:45:42 --> URI Class Initialized
INFO - 2017-12-28 06:45:42 --> Router Class Initialized
INFO - 2017-12-28 06:45:42 --> Output Class Initialized
INFO - 2017-12-28 06:45:42 --> Security Class Initialized
DEBUG - 2017-12-28 06:45:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:45:42 --> Input Class Initialized
INFO - 2017-12-28 06:45:42 --> Language Class Initialized
INFO - 2017-12-28 06:45:42 --> Loader Class Initialized
INFO - 2017-12-28 06:45:42 --> Helper loaded: url_helper
INFO - 2017-12-28 06:45:42 --> Helper loaded: form_helper
INFO - 2017-12-28 06:45:42 --> Database Driver Class Initialized
DEBUG - 2017-12-28 06:45:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 06:45:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 06:45:42 --> Form Validation Class Initialized
INFO - 2017-12-28 06:45:42 --> Model Class Initialized
INFO - 2017-12-28 06:45:42 --> Controller Class Initialized
INFO - 2017-12-28 06:45:42 --> Model Class Initialized
INFO - 2017-12-28 06:45:42 --> Model Class Initialized
INFO - 2017-12-28 06:45:42 --> Model Class Initialized
INFO - 2017-12-28 06:45:42 --> Model Class Initialized
DEBUG - 2017-12-28 06:45:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 06:45:42 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 06:45:42 --> Final output sent to browser
DEBUG - 2017-12-28 06:45:42 --> Total execution time: 0.0509
INFO - 2017-12-28 06:45:44 --> Config Class Initialized
INFO - 2017-12-28 06:45:44 --> Hooks Class Initialized
DEBUG - 2017-12-28 06:45:44 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:45:44 --> Utf8 Class Initialized
INFO - 2017-12-28 06:45:44 --> URI Class Initialized
INFO - 2017-12-28 06:45:44 --> Router Class Initialized
INFO - 2017-12-28 06:45:44 --> Output Class Initialized
INFO - 2017-12-28 06:45:44 --> Security Class Initialized
DEBUG - 2017-12-28 06:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:45:44 --> Input Class Initialized
INFO - 2017-12-28 06:45:44 --> Language Class Initialized
ERROR - 2017-12-28 06:45:44 --> 404 Page Not Found: Faviconico/index
INFO - 2017-12-28 06:47:10 --> Config Class Initialized
INFO - 2017-12-28 06:47:10 --> Hooks Class Initialized
DEBUG - 2017-12-28 06:47:10 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:47:10 --> Utf8 Class Initialized
INFO - 2017-12-28 06:47:10 --> URI Class Initialized
INFO - 2017-12-28 06:47:10 --> Router Class Initialized
INFO - 2017-12-28 06:47:10 --> Output Class Initialized
INFO - 2017-12-28 06:47:10 --> Security Class Initialized
DEBUG - 2017-12-28 06:47:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:47:10 --> Input Class Initialized
INFO - 2017-12-28 06:47:10 --> Language Class Initialized
INFO - 2017-12-28 06:47:10 --> Loader Class Initialized
INFO - 2017-12-28 06:47:10 --> Helper loaded: url_helper
INFO - 2017-12-28 06:47:10 --> Helper loaded: form_helper
INFO - 2017-12-28 06:47:10 --> Database Driver Class Initialized
DEBUG - 2017-12-28 06:47:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 06:47:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 06:47:10 --> Form Validation Class Initialized
INFO - 2017-12-28 06:47:10 --> Model Class Initialized
INFO - 2017-12-28 06:47:10 --> Controller Class Initialized
INFO - 2017-12-28 06:47:10 --> Model Class Initialized
INFO - 2017-12-28 06:47:10 --> Model Class Initialized
INFO - 2017-12-28 06:47:10 --> Model Class Initialized
INFO - 2017-12-28 06:47:10 --> Model Class Initialized
DEBUG - 2017-12-28 06:47:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 06:47:10 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 06:47:10 --> Final output sent to browser
DEBUG - 2017-12-28 06:47:10 --> Total execution time: 0.0497
INFO - 2017-12-28 06:47:16 --> Config Class Initialized
INFO - 2017-12-28 06:47:16 --> Hooks Class Initialized
DEBUG - 2017-12-28 06:47:16 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:47:16 --> Utf8 Class Initialized
INFO - 2017-12-28 06:47:16 --> URI Class Initialized
INFO - 2017-12-28 06:47:16 --> Router Class Initialized
INFO - 2017-12-28 06:47:16 --> Output Class Initialized
INFO - 2017-12-28 06:47:16 --> Security Class Initialized
DEBUG - 2017-12-28 06:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:47:16 --> Input Class Initialized
INFO - 2017-12-28 06:47:16 --> Language Class Initialized
INFO - 2017-12-28 06:47:16 --> Loader Class Initialized
INFO - 2017-12-28 06:47:16 --> Helper loaded: url_helper
INFO - 2017-12-28 06:47:16 --> Helper loaded: form_helper
INFO - 2017-12-28 06:47:16 --> Database Driver Class Initialized
DEBUG - 2017-12-28 06:47:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 06:47:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 06:47:16 --> Form Validation Class Initialized
INFO - 2017-12-28 06:47:16 --> Model Class Initialized
INFO - 2017-12-28 06:47:16 --> Controller Class Initialized
INFO - 2017-12-28 06:47:16 --> Model Class Initialized
INFO - 2017-12-28 06:47:16 --> Model Class Initialized
INFO - 2017-12-28 06:47:16 --> Model Class Initialized
INFO - 2017-12-28 06:47:16 --> Model Class Initialized
DEBUG - 2017-12-28 06:47:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 06:47:16 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 06:47:16 --> Final output sent to browser
DEBUG - 2017-12-28 06:47:16 --> Total execution time: 0.0597
INFO - 2017-12-28 06:47:18 --> Config Class Initialized
INFO - 2017-12-28 06:47:18 --> Hooks Class Initialized
DEBUG - 2017-12-28 06:47:18 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:47:18 --> Utf8 Class Initialized
INFO - 2017-12-28 06:47:18 --> URI Class Initialized
INFO - 2017-12-28 06:47:18 --> Router Class Initialized
INFO - 2017-12-28 06:47:18 --> Output Class Initialized
INFO - 2017-12-28 06:47:18 --> Security Class Initialized
DEBUG - 2017-12-28 06:47:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:47:18 --> Input Class Initialized
INFO - 2017-12-28 06:47:18 --> Language Class Initialized
ERROR - 2017-12-28 06:47:18 --> 404 Page Not Found: Faviconico/index
INFO - 2017-12-28 06:48:17 --> Config Class Initialized
INFO - 2017-12-28 06:48:17 --> Hooks Class Initialized
DEBUG - 2017-12-28 06:48:17 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:48:17 --> Utf8 Class Initialized
INFO - 2017-12-28 06:48:17 --> URI Class Initialized
INFO - 2017-12-28 06:48:17 --> Router Class Initialized
INFO - 2017-12-28 06:48:17 --> Output Class Initialized
INFO - 2017-12-28 06:48:17 --> Security Class Initialized
DEBUG - 2017-12-28 06:48:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:48:17 --> Input Class Initialized
INFO - 2017-12-28 06:48:17 --> Language Class Initialized
INFO - 2017-12-28 06:48:17 --> Loader Class Initialized
INFO - 2017-12-28 06:48:17 --> Helper loaded: url_helper
INFO - 2017-12-28 06:48:17 --> Helper loaded: form_helper
INFO - 2017-12-28 06:48:17 --> Database Driver Class Initialized
DEBUG - 2017-12-28 06:48:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 06:48:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 06:48:17 --> Form Validation Class Initialized
INFO - 2017-12-28 06:48:17 --> Model Class Initialized
INFO - 2017-12-28 06:48:17 --> Controller Class Initialized
INFO - 2017-12-28 06:48:17 --> Model Class Initialized
INFO - 2017-12-28 06:48:17 --> Model Class Initialized
INFO - 2017-12-28 06:48:17 --> Model Class Initialized
INFO - 2017-12-28 06:48:17 --> Model Class Initialized
DEBUG - 2017-12-28 06:48:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 06:48:17 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 06:48:17 --> Final output sent to browser
DEBUG - 2017-12-28 06:48:17 --> Total execution time: 0.0848
INFO - 2017-12-28 06:48:25 --> Config Class Initialized
INFO - 2017-12-28 06:48:25 --> Hooks Class Initialized
DEBUG - 2017-12-28 06:48:25 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:48:25 --> Utf8 Class Initialized
INFO - 2017-12-28 06:48:25 --> URI Class Initialized
INFO - 2017-12-28 06:48:25 --> Config Class Initialized
INFO - 2017-12-28 06:48:25 --> Hooks Class Initialized
INFO - 2017-12-28 06:48:25 --> Config Class Initialized
INFO - 2017-12-28 06:48:25 --> Hooks Class Initialized
INFO - 2017-12-28 06:48:25 --> Router Class Initialized
INFO - 2017-12-28 06:48:25 --> Output Class Initialized
DEBUG - 2017-12-28 06:48:25 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:48:25 --> Utf8 Class Initialized
DEBUG - 2017-12-28 06:48:25 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:48:25 --> Security Class Initialized
INFO - 2017-12-28 06:48:25 --> Utf8 Class Initialized
INFO - 2017-12-28 06:48:25 --> URI Class Initialized
DEBUG - 2017-12-28 06:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:48:25 --> URI Class Initialized
INFO - 2017-12-28 06:48:25 --> Input Class Initialized
INFO - 2017-12-28 06:48:25 --> Language Class Initialized
INFO - 2017-12-28 06:48:25 --> Router Class Initialized
INFO - 2017-12-28 06:48:25 --> Router Class Initialized
ERROR - 2017-12-28 06:48:25 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-28 06:48:25 --> Output Class Initialized
INFO - 2017-12-28 06:48:25 --> Output Class Initialized
INFO - 2017-12-28 06:48:25 --> Security Class Initialized
INFO - 2017-12-28 06:48:25 --> Security Class Initialized
DEBUG - 2017-12-28 06:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:48:25 --> Input Class Initialized
INFO - 2017-12-28 06:48:25 --> Language Class Initialized
DEBUG - 2017-12-28 06:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:48:25 --> Input Class Initialized
INFO - 2017-12-28 06:48:25 --> Language Class Initialized
ERROR - 2017-12-28 06:48:25 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-28 06:48:25 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-28 06:51:10 --> Config Class Initialized
INFO - 2017-12-28 06:51:10 --> Hooks Class Initialized
DEBUG - 2017-12-28 06:51:10 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:51:10 --> Utf8 Class Initialized
INFO - 2017-12-28 06:51:10 --> URI Class Initialized
INFO - 2017-12-28 06:51:10 --> Router Class Initialized
INFO - 2017-12-28 06:51:10 --> Output Class Initialized
INFO - 2017-12-28 06:51:10 --> Security Class Initialized
DEBUG - 2017-12-28 06:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:51:10 --> Input Class Initialized
INFO - 2017-12-28 06:51:10 --> Language Class Initialized
INFO - 2017-12-28 06:51:10 --> Loader Class Initialized
INFO - 2017-12-28 06:51:10 --> Helper loaded: url_helper
INFO - 2017-12-28 06:51:10 --> Helper loaded: form_helper
INFO - 2017-12-28 06:51:10 --> Database Driver Class Initialized
DEBUG - 2017-12-28 06:51:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 06:51:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 06:51:10 --> Form Validation Class Initialized
INFO - 2017-12-28 06:51:10 --> Model Class Initialized
INFO - 2017-12-28 06:51:10 --> Controller Class Initialized
INFO - 2017-12-28 06:51:10 --> Model Class Initialized
INFO - 2017-12-28 06:51:10 --> Model Class Initialized
INFO - 2017-12-28 06:51:10 --> Model Class Initialized
INFO - 2017-12-28 06:51:10 --> Model Class Initialized
DEBUG - 2017-12-28 06:51:10 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2017-12-28 06:51:10 --> Severity: Notice --> Undefined variable: vgast D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\agregarGastoProyecto.php 55
ERROR - 2017-12-28 06:51:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\agregarGastoProyecto.php 55
ERROR - 2017-12-28 06:51:10 --> Severity: Notice --> Undefined variable: vgast D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\agregarGastoProyecto.php 55
ERROR - 2017-12-28 06:51:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\agregarGastoProyecto.php 55
ERROR - 2017-12-28 06:51:10 --> Severity: Notice --> Undefined variable: vgast D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\agregarGastoProyecto.php 55
ERROR - 2017-12-28 06:51:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\agregarGastoProyecto.php 55
ERROR - 2017-12-28 06:51:10 --> Severity: Notice --> Undefined variable: vgast D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\agregarGastoProyecto.php 55
ERROR - 2017-12-28 06:51:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\agregarGastoProyecto.php 55
INFO - 2017-12-28 06:51:10 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 06:51:10 --> Final output sent to browser
DEBUG - 2017-12-28 06:51:10 --> Total execution time: 0.0843
INFO - 2017-12-28 06:51:10 --> Config Class Initialized
INFO - 2017-12-28 06:51:10 --> Hooks Class Initialized
DEBUG - 2017-12-28 06:51:10 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:51:10 --> Utf8 Class Initialized
INFO - 2017-12-28 06:51:10 --> URI Class Initialized
INFO - 2017-12-28 06:51:10 --> Router Class Initialized
INFO - 2017-12-28 06:51:10 --> Output Class Initialized
INFO - 2017-12-28 06:51:10 --> Security Class Initialized
DEBUG - 2017-12-28 06:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:51:10 --> Input Class Initialized
INFO - 2017-12-28 06:51:10 --> Language Class Initialized
ERROR - 2017-12-28 06:51:10 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-28 06:51:10 --> Config Class Initialized
INFO - 2017-12-28 06:51:10 --> Hooks Class Initialized
INFO - 2017-12-28 06:51:10 --> Config Class Initialized
INFO - 2017-12-28 06:51:10 --> Hooks Class Initialized
DEBUG - 2017-12-28 06:51:10 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:51:10 --> Utf8 Class Initialized
DEBUG - 2017-12-28 06:51:10 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:51:10 --> URI Class Initialized
INFO - 2017-12-28 06:51:10 --> Utf8 Class Initialized
INFO - 2017-12-28 06:51:10 --> URI Class Initialized
INFO - 2017-12-28 06:51:10 --> Router Class Initialized
INFO - 2017-12-28 06:51:10 --> Router Class Initialized
INFO - 2017-12-28 06:51:10 --> Output Class Initialized
INFO - 2017-12-28 06:51:10 --> Security Class Initialized
INFO - 2017-12-28 06:51:10 --> Output Class Initialized
DEBUG - 2017-12-28 06:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:51:10 --> Input Class Initialized
INFO - 2017-12-28 06:51:10 --> Security Class Initialized
INFO - 2017-12-28 06:51:10 --> Language Class Initialized
DEBUG - 2017-12-28 06:51:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2017-12-28 06:51:10 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-28 06:51:10 --> Input Class Initialized
INFO - 2017-12-28 06:51:10 --> Language Class Initialized
ERROR - 2017-12-28 06:51:10 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-28 06:51:33 --> Config Class Initialized
INFO - 2017-12-28 06:51:33 --> Hooks Class Initialized
DEBUG - 2017-12-28 06:51:33 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:51:33 --> Utf8 Class Initialized
INFO - 2017-12-28 06:51:33 --> URI Class Initialized
INFO - 2017-12-28 06:51:33 --> Router Class Initialized
INFO - 2017-12-28 06:51:33 --> Output Class Initialized
INFO - 2017-12-28 06:51:33 --> Security Class Initialized
DEBUG - 2017-12-28 06:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:51:33 --> Input Class Initialized
INFO - 2017-12-28 06:51:33 --> Language Class Initialized
INFO - 2017-12-28 06:51:33 --> Loader Class Initialized
INFO - 2017-12-28 06:51:33 --> Helper loaded: url_helper
INFO - 2017-12-28 06:51:33 --> Helper loaded: form_helper
INFO - 2017-12-28 06:51:33 --> Database Driver Class Initialized
DEBUG - 2017-12-28 06:51:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 06:51:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 06:51:33 --> Form Validation Class Initialized
INFO - 2017-12-28 06:51:33 --> Model Class Initialized
INFO - 2017-12-28 06:51:33 --> Controller Class Initialized
INFO - 2017-12-28 06:51:33 --> Model Class Initialized
INFO - 2017-12-28 06:51:33 --> Model Class Initialized
INFO - 2017-12-28 06:51:33 --> Model Class Initialized
INFO - 2017-12-28 06:51:33 --> Model Class Initialized
DEBUG - 2017-12-28 06:51:33 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2017-12-28 06:51:33 --> Severity: Notice --> Undefined variable: vgast D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\agregarGastoProyecto.php 55
ERROR - 2017-12-28 06:51:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\agregarGastoProyecto.php 55
ERROR - 2017-12-28 06:51:33 --> Severity: Notice --> Undefined variable: vgast D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\agregarGastoProyecto.php 55
ERROR - 2017-12-28 06:51:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\agregarGastoProyecto.php 55
ERROR - 2017-12-28 06:51:33 --> Severity: Notice --> Undefined variable: vgast D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\agregarGastoProyecto.php 55
ERROR - 2017-12-28 06:51:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\agregarGastoProyecto.php 55
ERROR - 2017-12-28 06:51:33 --> Severity: Notice --> Undefined variable: vgast D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\agregarGastoProyecto.php 55
ERROR - 2017-12-28 06:51:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\agregarGastoProyecto.php 55
INFO - 2017-12-28 06:51:33 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 06:51:33 --> Final output sent to browser
DEBUG - 2017-12-28 06:51:33 --> Total execution time: 0.0642
INFO - 2017-12-28 06:51:33 --> Config Class Initialized
INFO - 2017-12-28 06:51:33 --> Hooks Class Initialized
DEBUG - 2017-12-28 06:51:33 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:51:33 --> Utf8 Class Initialized
INFO - 2017-12-28 06:51:33 --> URI Class Initialized
INFO - 2017-12-28 06:51:33 --> Router Class Initialized
INFO - 2017-12-28 06:51:33 --> Output Class Initialized
INFO - 2017-12-28 06:51:33 --> Security Class Initialized
DEBUG - 2017-12-28 06:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:51:33 --> Input Class Initialized
INFO - 2017-12-28 06:51:33 --> Language Class Initialized
ERROR - 2017-12-28 06:51:33 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-28 06:51:33 --> Config Class Initialized
INFO - 2017-12-28 06:51:33 --> Hooks Class Initialized
INFO - 2017-12-28 06:51:33 --> Config Class Initialized
INFO - 2017-12-28 06:51:33 --> Hooks Class Initialized
DEBUG - 2017-12-28 06:51:33 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:51:33 --> Utf8 Class Initialized
INFO - 2017-12-28 06:51:33 --> URI Class Initialized
DEBUG - 2017-12-28 06:51:33 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:51:33 --> Router Class Initialized
INFO - 2017-12-28 06:51:33 --> Utf8 Class Initialized
INFO - 2017-12-28 06:51:33 --> URI Class Initialized
INFO - 2017-12-28 06:51:33 --> Output Class Initialized
INFO - 2017-12-28 06:51:33 --> Security Class Initialized
INFO - 2017-12-28 06:51:33 --> Router Class Initialized
DEBUG - 2017-12-28 06:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:51:33 --> Input Class Initialized
INFO - 2017-12-28 06:51:33 --> Output Class Initialized
INFO - 2017-12-28 06:51:33 --> Language Class Initialized
INFO - 2017-12-28 06:51:33 --> Security Class Initialized
DEBUG - 2017-12-28 06:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:51:33 --> Input Class Initialized
ERROR - 2017-12-28 06:51:33 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-28 06:51:33 --> Language Class Initialized
ERROR - 2017-12-28 06:51:33 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-28 06:51:59 --> Config Class Initialized
INFO - 2017-12-28 06:51:59 --> Hooks Class Initialized
DEBUG - 2017-12-28 06:51:59 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:51:59 --> Utf8 Class Initialized
INFO - 2017-12-28 06:51:59 --> URI Class Initialized
INFO - 2017-12-28 06:51:59 --> Router Class Initialized
INFO - 2017-12-28 06:51:59 --> Output Class Initialized
INFO - 2017-12-28 06:51:59 --> Security Class Initialized
DEBUG - 2017-12-28 06:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:51:59 --> Input Class Initialized
INFO - 2017-12-28 06:51:59 --> Language Class Initialized
INFO - 2017-12-28 06:51:59 --> Loader Class Initialized
INFO - 2017-12-28 06:51:59 --> Helper loaded: url_helper
INFO - 2017-12-28 06:51:59 --> Helper loaded: form_helper
INFO - 2017-12-28 06:51:59 --> Database Driver Class Initialized
DEBUG - 2017-12-28 06:51:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 06:51:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 06:51:59 --> Form Validation Class Initialized
INFO - 2017-12-28 06:51:59 --> Model Class Initialized
INFO - 2017-12-28 06:51:59 --> Controller Class Initialized
INFO - 2017-12-28 06:51:59 --> Model Class Initialized
INFO - 2017-12-28 06:51:59 --> Model Class Initialized
INFO - 2017-12-28 06:51:59 --> Model Class Initialized
INFO - 2017-12-28 06:51:59 --> Model Class Initialized
DEBUG - 2017-12-28 06:51:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 06:51:59 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 06:51:59 --> Final output sent to browser
DEBUG - 2017-12-28 06:51:59 --> Total execution time: 0.0558
INFO - 2017-12-28 06:51:59 --> Config Class Initialized
INFO - 2017-12-28 06:51:59 --> Hooks Class Initialized
DEBUG - 2017-12-28 06:51:59 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:51:59 --> Utf8 Class Initialized
INFO - 2017-12-28 06:51:59 --> URI Class Initialized
INFO - 2017-12-28 06:51:59 --> Router Class Initialized
INFO - 2017-12-28 06:51:59 --> Output Class Initialized
INFO - 2017-12-28 06:51:59 --> Security Class Initialized
DEBUG - 2017-12-28 06:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:51:59 --> Input Class Initialized
INFO - 2017-12-28 06:51:59 --> Language Class Initialized
ERROR - 2017-12-28 06:51:59 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-28 06:51:59 --> Config Class Initialized
INFO - 2017-12-28 06:51:59 --> Hooks Class Initialized
INFO - 2017-12-28 06:51:59 --> Config Class Initialized
INFO - 2017-12-28 06:51:59 --> Hooks Class Initialized
DEBUG - 2017-12-28 06:51:59 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:51:59 --> Utf8 Class Initialized
DEBUG - 2017-12-28 06:51:59 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:51:59 --> URI Class Initialized
INFO - 2017-12-28 06:51:59 --> Utf8 Class Initialized
INFO - 2017-12-28 06:51:59 --> URI Class Initialized
INFO - 2017-12-28 06:51:59 --> Router Class Initialized
INFO - 2017-12-28 06:51:59 --> Router Class Initialized
INFO - 2017-12-28 06:51:59 --> Output Class Initialized
INFO - 2017-12-28 06:51:59 --> Output Class Initialized
INFO - 2017-12-28 06:51:59 --> Security Class Initialized
DEBUG - 2017-12-28 06:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:51:59 --> Security Class Initialized
INFO - 2017-12-28 06:51:59 --> Input Class Initialized
INFO - 2017-12-28 06:51:59 --> Language Class Initialized
DEBUG - 2017-12-28 06:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:51:59 --> Input Class Initialized
ERROR - 2017-12-28 06:51:59 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-28 06:51:59 --> Language Class Initialized
ERROR - 2017-12-28 06:51:59 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-28 06:52:46 --> Config Class Initialized
INFO - 2017-12-28 06:52:46 --> Hooks Class Initialized
DEBUG - 2017-12-28 06:52:46 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:52:46 --> Utf8 Class Initialized
INFO - 2017-12-28 06:52:46 --> URI Class Initialized
INFO - 2017-12-28 06:52:46 --> Router Class Initialized
INFO - 2017-12-28 06:52:46 --> Output Class Initialized
INFO - 2017-12-28 06:52:46 --> Security Class Initialized
DEBUG - 2017-12-28 06:52:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:52:46 --> Input Class Initialized
INFO - 2017-12-28 06:52:46 --> Language Class Initialized
INFO - 2017-12-28 06:52:46 --> Loader Class Initialized
INFO - 2017-12-28 06:52:46 --> Helper loaded: url_helper
INFO - 2017-12-28 06:52:46 --> Helper loaded: form_helper
INFO - 2017-12-28 06:52:46 --> Database Driver Class Initialized
DEBUG - 2017-12-28 06:52:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 06:52:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 06:52:46 --> Form Validation Class Initialized
INFO - 2017-12-28 06:52:46 --> Model Class Initialized
INFO - 2017-12-28 06:52:46 --> Controller Class Initialized
INFO - 2017-12-28 06:52:46 --> Model Class Initialized
INFO - 2017-12-28 06:52:46 --> Model Class Initialized
INFO - 2017-12-28 06:52:46 --> Model Class Initialized
INFO - 2017-12-28 06:52:46 --> Model Class Initialized
DEBUG - 2017-12-28 06:52:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 06:52:46 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 06:52:46 --> Final output sent to browser
DEBUG - 2017-12-28 06:52:46 --> Total execution time: 0.0543
INFO - 2017-12-28 06:52:46 --> Config Class Initialized
INFO - 2017-12-28 06:52:46 --> Hooks Class Initialized
DEBUG - 2017-12-28 06:52:46 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:52:46 --> Utf8 Class Initialized
INFO - 2017-12-28 06:52:46 --> URI Class Initialized
INFO - 2017-12-28 06:52:46 --> Router Class Initialized
INFO - 2017-12-28 06:52:46 --> Output Class Initialized
INFO - 2017-12-28 06:52:46 --> Security Class Initialized
DEBUG - 2017-12-28 06:52:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:52:46 --> Input Class Initialized
INFO - 2017-12-28 06:52:46 --> Language Class Initialized
ERROR - 2017-12-28 06:52:46 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-28 06:52:47 --> Config Class Initialized
INFO - 2017-12-28 06:52:47 --> Hooks Class Initialized
INFO - 2017-12-28 06:52:47 --> Config Class Initialized
INFO - 2017-12-28 06:52:47 --> Hooks Class Initialized
DEBUG - 2017-12-28 06:52:47 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:52:47 --> Utf8 Class Initialized
DEBUG - 2017-12-28 06:52:47 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:52:47 --> Utf8 Class Initialized
INFO - 2017-12-28 06:52:47 --> URI Class Initialized
INFO - 2017-12-28 06:52:47 --> URI Class Initialized
INFO - 2017-12-28 06:52:47 --> Router Class Initialized
INFO - 2017-12-28 06:52:47 --> Router Class Initialized
INFO - 2017-12-28 06:52:47 --> Output Class Initialized
INFO - 2017-12-28 06:52:47 --> Output Class Initialized
INFO - 2017-12-28 06:52:47 --> Security Class Initialized
DEBUG - 2017-12-28 06:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:52:47 --> Input Class Initialized
INFO - 2017-12-28 06:52:47 --> Security Class Initialized
INFO - 2017-12-28 06:52:47 --> Language Class Initialized
DEBUG - 2017-12-28 06:52:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2017-12-28 06:52:47 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-28 06:52:47 --> Input Class Initialized
INFO - 2017-12-28 06:52:47 --> Language Class Initialized
ERROR - 2017-12-28 06:52:47 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-28 06:53:16 --> Config Class Initialized
INFO - 2017-12-28 06:53:16 --> Hooks Class Initialized
DEBUG - 2017-12-28 06:53:16 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:53:16 --> Utf8 Class Initialized
INFO - 2017-12-28 06:53:16 --> URI Class Initialized
INFO - 2017-12-28 06:53:16 --> Router Class Initialized
INFO - 2017-12-28 06:53:16 --> Output Class Initialized
INFO - 2017-12-28 06:53:16 --> Security Class Initialized
DEBUG - 2017-12-28 06:53:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:53:16 --> Input Class Initialized
INFO - 2017-12-28 06:53:16 --> Language Class Initialized
INFO - 2017-12-28 06:53:16 --> Loader Class Initialized
INFO - 2017-12-28 06:53:16 --> Helper loaded: url_helper
INFO - 2017-12-28 06:53:16 --> Helper loaded: form_helper
INFO - 2017-12-28 06:53:16 --> Database Driver Class Initialized
DEBUG - 2017-12-28 06:53:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 06:53:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 06:53:16 --> Form Validation Class Initialized
INFO - 2017-12-28 06:53:16 --> Model Class Initialized
INFO - 2017-12-28 06:53:16 --> Controller Class Initialized
INFO - 2017-12-28 06:53:16 --> Model Class Initialized
INFO - 2017-12-28 06:53:16 --> Model Class Initialized
INFO - 2017-12-28 06:53:16 --> Model Class Initialized
INFO - 2017-12-28 06:53:16 --> Model Class Initialized
DEBUG - 2017-12-28 06:53:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 06:53:21 --> Config Class Initialized
INFO - 2017-12-28 06:53:21 --> Hooks Class Initialized
DEBUG - 2017-12-28 06:53:21 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:53:21 --> Utf8 Class Initialized
INFO - 2017-12-28 06:53:21 --> URI Class Initialized
INFO - 2017-12-28 06:53:21 --> Router Class Initialized
INFO - 2017-12-28 06:53:21 --> Output Class Initialized
INFO - 2017-12-28 06:53:21 --> Security Class Initialized
DEBUG - 2017-12-28 06:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:53:21 --> Input Class Initialized
INFO - 2017-12-28 06:53:21 --> Language Class Initialized
INFO - 2017-12-28 06:53:21 --> Loader Class Initialized
INFO - 2017-12-28 06:53:21 --> Helper loaded: url_helper
INFO - 2017-12-28 06:53:21 --> Helper loaded: form_helper
INFO - 2017-12-28 06:53:21 --> Database Driver Class Initialized
DEBUG - 2017-12-28 06:53:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 06:53:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 06:53:21 --> Form Validation Class Initialized
INFO - 2017-12-28 06:53:21 --> Model Class Initialized
INFO - 2017-12-28 06:53:21 --> Controller Class Initialized
INFO - 2017-12-28 06:53:21 --> Model Class Initialized
INFO - 2017-12-28 06:53:21 --> Model Class Initialized
INFO - 2017-12-28 06:53:21 --> Model Class Initialized
INFO - 2017-12-28 06:53:21 --> Model Class Initialized
DEBUG - 2017-12-28 06:53:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 06:53:21 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 06:53:21 --> Final output sent to browser
DEBUG - 2017-12-28 06:53:21 --> Total execution time: 0.0748
INFO - 2017-12-28 06:53:21 --> Config Class Initialized
INFO - 2017-12-28 06:53:21 --> Hooks Class Initialized
DEBUG - 2017-12-28 06:53:21 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:53:21 --> Utf8 Class Initialized
INFO - 2017-12-28 06:53:21 --> URI Class Initialized
INFO - 2017-12-28 06:53:21 --> Router Class Initialized
INFO - 2017-12-28 06:53:21 --> Output Class Initialized
INFO - 2017-12-28 06:53:21 --> Security Class Initialized
DEBUG - 2017-12-28 06:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:53:21 --> Input Class Initialized
INFO - 2017-12-28 06:53:21 --> Language Class Initialized
ERROR - 2017-12-28 06:53:21 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-28 06:53:21 --> Config Class Initialized
INFO - 2017-12-28 06:53:21 --> Hooks Class Initialized
INFO - 2017-12-28 06:53:21 --> Config Class Initialized
INFO - 2017-12-28 06:53:21 --> Hooks Class Initialized
DEBUG - 2017-12-28 06:53:21 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:53:21 --> Utf8 Class Initialized
DEBUG - 2017-12-28 06:53:21 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:53:21 --> Utf8 Class Initialized
INFO - 2017-12-28 06:53:21 --> URI Class Initialized
INFO - 2017-12-28 06:53:21 --> URI Class Initialized
INFO - 2017-12-28 06:53:21 --> Router Class Initialized
INFO - 2017-12-28 06:53:21 --> Router Class Initialized
INFO - 2017-12-28 06:53:21 --> Output Class Initialized
INFO - 2017-12-28 06:53:21 --> Output Class Initialized
INFO - 2017-12-28 06:53:21 --> Security Class Initialized
INFO - 2017-12-28 06:53:21 --> Security Class Initialized
DEBUG - 2017-12-28 06:53:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-28 06:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:53:21 --> Input Class Initialized
INFO - 2017-12-28 06:53:21 --> Input Class Initialized
INFO - 2017-12-28 06:53:21 --> Language Class Initialized
INFO - 2017-12-28 06:53:21 --> Language Class Initialized
ERROR - 2017-12-28 06:53:21 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-28 06:53:21 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-28 06:53:22 --> Config Class Initialized
INFO - 2017-12-28 06:53:22 --> Hooks Class Initialized
DEBUG - 2017-12-28 06:53:22 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:53:22 --> Utf8 Class Initialized
INFO - 2017-12-28 06:53:22 --> URI Class Initialized
INFO - 2017-12-28 06:53:22 --> Router Class Initialized
INFO - 2017-12-28 06:53:22 --> Output Class Initialized
INFO - 2017-12-28 06:53:22 --> Security Class Initialized
DEBUG - 2017-12-28 06:53:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:53:22 --> Input Class Initialized
INFO - 2017-12-28 06:53:22 --> Language Class Initialized
INFO - 2017-12-28 06:53:22 --> Loader Class Initialized
INFO - 2017-12-28 06:53:22 --> Helper loaded: url_helper
INFO - 2017-12-28 06:53:22 --> Helper loaded: form_helper
INFO - 2017-12-28 06:53:22 --> Database Driver Class Initialized
DEBUG - 2017-12-28 06:53:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 06:53:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 06:53:22 --> Form Validation Class Initialized
INFO - 2017-12-28 06:53:22 --> Model Class Initialized
INFO - 2017-12-28 06:53:22 --> Controller Class Initialized
INFO - 2017-12-28 06:53:22 --> Model Class Initialized
INFO - 2017-12-28 06:53:22 --> Model Class Initialized
INFO - 2017-12-28 06:53:22 --> Model Class Initialized
INFO - 2017-12-28 06:53:22 --> Model Class Initialized
DEBUG - 2017-12-28 06:53:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 06:53:22 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 06:53:22 --> Final output sent to browser
DEBUG - 2017-12-28 06:53:22 --> Total execution time: 0.0767
INFO - 2017-12-28 06:53:22 --> Config Class Initialized
INFO - 2017-12-28 06:53:22 --> Hooks Class Initialized
DEBUG - 2017-12-28 06:53:22 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:53:22 --> Utf8 Class Initialized
INFO - 2017-12-28 06:53:22 --> URI Class Initialized
INFO - 2017-12-28 06:53:22 --> Router Class Initialized
INFO - 2017-12-28 06:53:22 --> Output Class Initialized
INFO - 2017-12-28 06:53:22 --> Security Class Initialized
DEBUG - 2017-12-28 06:53:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:53:22 --> Input Class Initialized
INFO - 2017-12-28 06:53:22 --> Language Class Initialized
ERROR - 2017-12-28 06:53:22 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-28 06:53:22 --> Config Class Initialized
INFO - 2017-12-28 06:53:22 --> Hooks Class Initialized
INFO - 2017-12-28 06:53:22 --> Config Class Initialized
INFO - 2017-12-28 06:53:22 --> Hooks Class Initialized
DEBUG - 2017-12-28 06:53:22 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:53:22 --> Utf8 Class Initialized
DEBUG - 2017-12-28 06:53:22 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:53:22 --> Utf8 Class Initialized
INFO - 2017-12-28 06:53:22 --> URI Class Initialized
INFO - 2017-12-28 06:53:22 --> URI Class Initialized
INFO - 2017-12-28 06:53:22 --> Router Class Initialized
INFO - 2017-12-28 06:53:22 --> Router Class Initialized
INFO - 2017-12-28 06:53:22 --> Output Class Initialized
INFO - 2017-12-28 06:53:22 --> Output Class Initialized
INFO - 2017-12-28 06:53:22 --> Security Class Initialized
INFO - 2017-12-28 06:53:22 --> Security Class Initialized
DEBUG - 2017-12-28 06:53:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:53:22 --> Input Class Initialized
INFO - 2017-12-28 06:53:22 --> Language Class Initialized
DEBUG - 2017-12-28 06:53:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:53:22 --> Input Class Initialized
INFO - 2017-12-28 06:53:22 --> Language Class Initialized
ERROR - 2017-12-28 06:53:22 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-28 06:53:22 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-28 06:53:49 --> Config Class Initialized
INFO - 2017-12-28 06:53:49 --> Hooks Class Initialized
DEBUG - 2017-12-28 06:53:49 --> UTF-8 Support Enabled
INFO - 2017-12-28 06:53:49 --> Utf8 Class Initialized
INFO - 2017-12-28 06:53:49 --> URI Class Initialized
INFO - 2017-12-28 06:53:49 --> Router Class Initialized
INFO - 2017-12-28 06:53:49 --> Output Class Initialized
INFO - 2017-12-28 06:53:49 --> Security Class Initialized
DEBUG - 2017-12-28 06:53:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 06:53:49 --> Input Class Initialized
INFO - 2017-12-28 06:53:49 --> Language Class Initialized
INFO - 2017-12-28 06:53:49 --> Loader Class Initialized
INFO - 2017-12-28 06:53:49 --> Helper loaded: url_helper
INFO - 2017-12-28 06:53:49 --> Helper loaded: form_helper
INFO - 2017-12-28 06:53:49 --> Database Driver Class Initialized
DEBUG - 2017-12-28 06:53:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 06:53:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 06:53:49 --> Form Validation Class Initialized
INFO - 2017-12-28 06:53:49 --> Model Class Initialized
INFO - 2017-12-28 06:53:49 --> Controller Class Initialized
INFO - 2017-12-28 06:53:49 --> Model Class Initialized
INFO - 2017-12-28 06:53:49 --> Model Class Initialized
INFO - 2017-12-28 06:53:49 --> Model Class Initialized
INFO - 2017-12-28 06:53:49 --> Model Class Initialized
DEBUG - 2017-12-28 06:53:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 07:07:56 --> Config Class Initialized
INFO - 2017-12-28 07:07:56 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:07:56 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:07:56 --> Utf8 Class Initialized
INFO - 2017-12-28 07:07:56 --> URI Class Initialized
INFO - 2017-12-28 07:07:56 --> Router Class Initialized
INFO - 2017-12-28 07:07:56 --> Output Class Initialized
INFO - 2017-12-28 07:07:56 --> Security Class Initialized
DEBUG - 2017-12-28 07:07:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:07:56 --> Input Class Initialized
INFO - 2017-12-28 07:07:56 --> Language Class Initialized
INFO - 2017-12-28 07:07:56 --> Loader Class Initialized
INFO - 2017-12-28 07:07:56 --> Helper loaded: url_helper
INFO - 2017-12-28 07:07:56 --> Helper loaded: form_helper
INFO - 2017-12-28 07:07:56 --> Database Driver Class Initialized
DEBUG - 2017-12-28 07:07:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 07:07:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 07:07:56 --> Form Validation Class Initialized
INFO - 2017-12-28 07:07:56 --> Model Class Initialized
INFO - 2017-12-28 07:07:56 --> Controller Class Initialized
INFO - 2017-12-28 07:07:56 --> Model Class Initialized
INFO - 2017-12-28 07:07:56 --> Model Class Initialized
INFO - 2017-12-28 07:07:56 --> Model Class Initialized
INFO - 2017-12-28 07:07:56 --> Model Class Initialized
DEBUG - 2017-12-28 07:07:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 07:07:56 --> Config Class Initialized
INFO - 2017-12-28 07:07:56 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:07:56 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:07:56 --> Utf8 Class Initialized
INFO - 2017-12-28 07:07:56 --> URI Class Initialized
INFO - 2017-12-28 07:07:56 --> Router Class Initialized
INFO - 2017-12-28 07:07:56 --> Output Class Initialized
INFO - 2017-12-28 07:07:56 --> Security Class Initialized
DEBUG - 2017-12-28 07:07:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:07:56 --> Input Class Initialized
INFO - 2017-12-28 07:07:56 --> Language Class Initialized
INFO - 2017-12-28 07:07:56 --> Loader Class Initialized
INFO - 2017-12-28 07:07:56 --> Helper loaded: url_helper
INFO - 2017-12-28 07:07:56 --> Helper loaded: form_helper
INFO - 2017-12-28 07:07:56 --> Database Driver Class Initialized
DEBUG - 2017-12-28 07:07:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 07:07:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 07:07:56 --> Form Validation Class Initialized
INFO - 2017-12-28 07:07:56 --> Model Class Initialized
INFO - 2017-12-28 07:07:56 --> Controller Class Initialized
INFO - 2017-12-28 07:07:56 --> Model Class Initialized
INFO - 2017-12-28 07:07:56 --> Model Class Initialized
INFO - 2017-12-28 07:07:56 --> Model Class Initialized
INFO - 2017-12-28 07:07:56 --> Model Class Initialized
DEBUG - 2017-12-28 07:07:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 07:07:56 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 07:07:56 --> Final output sent to browser
DEBUG - 2017-12-28 07:07:56 --> Total execution time: 0.0658
INFO - 2017-12-28 07:07:56 --> Config Class Initialized
INFO - 2017-12-28 07:07:56 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:07:56 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:07:56 --> Utf8 Class Initialized
INFO - 2017-12-28 07:07:56 --> URI Class Initialized
INFO - 2017-12-28 07:07:56 --> Router Class Initialized
INFO - 2017-12-28 07:07:56 --> Output Class Initialized
INFO - 2017-12-28 07:07:56 --> Security Class Initialized
DEBUG - 2017-12-28 07:07:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:07:56 --> Input Class Initialized
INFO - 2017-12-28 07:07:56 --> Language Class Initialized
ERROR - 2017-12-28 07:07:56 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-28 07:07:56 --> Config Class Initialized
INFO - 2017-12-28 07:07:56 --> Hooks Class Initialized
INFO - 2017-12-28 07:07:56 --> Config Class Initialized
INFO - 2017-12-28 07:07:56 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:07:56 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:07:56 --> Utf8 Class Initialized
DEBUG - 2017-12-28 07:07:56 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:07:56 --> Utf8 Class Initialized
INFO - 2017-12-28 07:07:56 --> Config Class Initialized
INFO - 2017-12-28 07:07:56 --> URI Class Initialized
INFO - 2017-12-28 07:07:56 --> URI Class Initialized
INFO - 2017-12-28 07:07:56 --> Hooks Class Initialized
INFO - 2017-12-28 07:07:56 --> Router Class Initialized
INFO - 2017-12-28 07:07:56 --> Router Class Initialized
DEBUG - 2017-12-28 07:07:56 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:07:56 --> Utf8 Class Initialized
INFO - 2017-12-28 07:07:56 --> Output Class Initialized
INFO - 2017-12-28 07:07:56 --> Output Class Initialized
INFO - 2017-12-28 07:07:56 --> URI Class Initialized
INFO - 2017-12-28 07:07:56 --> Security Class Initialized
INFO - 2017-12-28 07:07:56 --> Security Class Initialized
INFO - 2017-12-28 07:07:56 --> Router Class Initialized
DEBUG - 2017-12-28 07:07:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:07:56 --> Input Class Initialized
DEBUG - 2017-12-28 07:07:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:07:56 --> Input Class Initialized
INFO - 2017-12-28 07:07:56 --> Language Class Initialized
INFO - 2017-12-28 07:07:56 --> Language Class Initialized
INFO - 2017-12-28 07:07:56 --> Output Class Initialized
ERROR - 2017-12-28 07:07:56 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-28 07:07:56 --> Security Class Initialized
ERROR - 2017-12-28 07:07:56 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2017-12-28 07:07:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:07:56 --> Input Class Initialized
INFO - 2017-12-28 07:07:56 --> Language Class Initialized
INFO - 2017-12-28 07:07:56 --> Loader Class Initialized
INFO - 2017-12-28 07:07:56 --> Helper loaded: url_helper
INFO - 2017-12-28 07:07:56 --> Helper loaded: form_helper
INFO - 2017-12-28 07:07:56 --> Database Driver Class Initialized
DEBUG - 2017-12-28 07:07:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 07:07:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 07:07:56 --> Form Validation Class Initialized
INFO - 2017-12-28 07:07:56 --> Model Class Initialized
INFO - 2017-12-28 07:07:56 --> Controller Class Initialized
INFO - 2017-12-28 07:07:56 --> Model Class Initialized
INFO - 2017-12-28 07:07:56 --> Model Class Initialized
INFO - 2017-12-28 07:07:56 --> Model Class Initialized
INFO - 2017-12-28 07:07:56 --> Model Class Initialized
DEBUG - 2017-12-28 07:07:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 07:08:19 --> Config Class Initialized
INFO - 2017-12-28 07:08:19 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:08:19 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:08:19 --> Utf8 Class Initialized
INFO - 2017-12-28 07:08:19 --> URI Class Initialized
INFO - 2017-12-28 07:08:19 --> Router Class Initialized
INFO - 2017-12-28 07:08:19 --> Output Class Initialized
INFO - 2017-12-28 07:08:19 --> Security Class Initialized
DEBUG - 2017-12-28 07:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:08:19 --> Input Class Initialized
INFO - 2017-12-28 07:08:19 --> Language Class Initialized
INFO - 2017-12-28 07:08:19 --> Loader Class Initialized
INFO - 2017-12-28 07:08:19 --> Helper loaded: url_helper
INFO - 2017-12-28 07:08:19 --> Helper loaded: form_helper
INFO - 2017-12-28 07:08:19 --> Database Driver Class Initialized
DEBUG - 2017-12-28 07:08:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 07:08:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 07:08:19 --> Form Validation Class Initialized
INFO - 2017-12-28 07:08:19 --> Model Class Initialized
INFO - 2017-12-28 07:08:19 --> Controller Class Initialized
INFO - 2017-12-28 07:08:19 --> Model Class Initialized
INFO - 2017-12-28 07:08:19 --> Model Class Initialized
INFO - 2017-12-28 07:08:19 --> Model Class Initialized
INFO - 2017-12-28 07:08:19 --> Model Class Initialized
DEBUG - 2017-12-28 07:08:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 07:08:19 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 07:08:19 --> Final output sent to browser
DEBUG - 2017-12-28 07:08:19 --> Total execution time: 0.0652
INFO - 2017-12-28 07:08:19 --> Config Class Initialized
INFO - 2017-12-28 07:08:19 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:08:19 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:08:19 --> Utf8 Class Initialized
INFO - 2017-12-28 07:08:19 --> URI Class Initialized
INFO - 2017-12-28 07:08:19 --> Router Class Initialized
INFO - 2017-12-28 07:08:19 --> Output Class Initialized
INFO - 2017-12-28 07:08:19 --> Security Class Initialized
DEBUG - 2017-12-28 07:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:08:19 --> Input Class Initialized
INFO - 2017-12-28 07:08:19 --> Language Class Initialized
ERROR - 2017-12-28 07:08:19 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-28 07:08:19 --> Config Class Initialized
INFO - 2017-12-28 07:08:19 --> Hooks Class Initialized
INFO - 2017-12-28 07:08:19 --> Config Class Initialized
INFO - 2017-12-28 07:08:19 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:08:19 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:08:19 --> Utf8 Class Initialized
DEBUG - 2017-12-28 07:08:19 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:08:19 --> URI Class Initialized
INFO - 2017-12-28 07:08:19 --> Utf8 Class Initialized
INFO - 2017-12-28 07:08:19 --> URI Class Initialized
INFO - 2017-12-28 07:08:19 --> Router Class Initialized
INFO - 2017-12-28 07:08:19 --> Router Class Initialized
INFO - 2017-12-28 07:08:19 --> Output Class Initialized
INFO - 2017-12-28 07:08:19 --> Output Class Initialized
INFO - 2017-12-28 07:08:19 --> Security Class Initialized
INFO - 2017-12-28 07:08:19 --> Security Class Initialized
DEBUG - 2017-12-28 07:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:08:19 --> Input Class Initialized
DEBUG - 2017-12-28 07:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:08:19 --> Input Class Initialized
INFO - 2017-12-28 07:08:19 --> Language Class Initialized
INFO - 2017-12-28 07:08:19 --> Language Class Initialized
ERROR - 2017-12-28 07:08:19 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-28 07:08:19 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-28 07:08:19 --> Config Class Initialized
INFO - 2017-12-28 07:08:19 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:08:19 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:08:19 --> Utf8 Class Initialized
INFO - 2017-12-28 07:08:19 --> URI Class Initialized
INFO - 2017-12-28 07:08:19 --> Router Class Initialized
INFO - 2017-12-28 07:08:19 --> Output Class Initialized
INFO - 2017-12-28 07:08:19 --> Security Class Initialized
DEBUG - 2017-12-28 07:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:08:19 --> Input Class Initialized
INFO - 2017-12-28 07:08:19 --> Language Class Initialized
INFO - 2017-12-28 07:08:19 --> Loader Class Initialized
INFO - 2017-12-28 07:08:19 --> Helper loaded: url_helper
INFO - 2017-12-28 07:08:19 --> Helper loaded: form_helper
INFO - 2017-12-28 07:08:19 --> Database Driver Class Initialized
DEBUG - 2017-12-28 07:08:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 07:08:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 07:08:19 --> Form Validation Class Initialized
INFO - 2017-12-28 07:08:19 --> Model Class Initialized
INFO - 2017-12-28 07:08:19 --> Controller Class Initialized
INFO - 2017-12-28 07:08:19 --> Model Class Initialized
INFO - 2017-12-28 07:08:19 --> Model Class Initialized
INFO - 2017-12-28 07:08:19 --> Model Class Initialized
INFO - 2017-12-28 07:08:19 --> Model Class Initialized
DEBUG - 2017-12-28 07:08:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 07:08:34 --> Config Class Initialized
INFO - 2017-12-28 07:08:34 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:08:34 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:08:34 --> Utf8 Class Initialized
INFO - 2017-12-28 07:08:34 --> URI Class Initialized
INFO - 2017-12-28 07:08:34 --> Router Class Initialized
INFO - 2017-12-28 07:08:34 --> Output Class Initialized
INFO - 2017-12-28 07:08:34 --> Security Class Initialized
DEBUG - 2017-12-28 07:08:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:08:34 --> Input Class Initialized
INFO - 2017-12-28 07:08:34 --> Language Class Initialized
INFO - 2017-12-28 07:08:34 --> Loader Class Initialized
INFO - 2017-12-28 07:08:34 --> Helper loaded: url_helper
INFO - 2017-12-28 07:08:34 --> Helper loaded: form_helper
INFO - 2017-12-28 07:08:34 --> Database Driver Class Initialized
DEBUG - 2017-12-28 07:08:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 07:08:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 07:08:34 --> Form Validation Class Initialized
INFO - 2017-12-28 07:08:34 --> Model Class Initialized
INFO - 2017-12-28 07:08:34 --> Controller Class Initialized
INFO - 2017-12-28 07:08:34 --> Model Class Initialized
INFO - 2017-12-28 07:08:34 --> Model Class Initialized
INFO - 2017-12-28 07:08:34 --> Model Class Initialized
INFO - 2017-12-28 07:08:34 --> Model Class Initialized
DEBUG - 2017-12-28 07:08:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 07:08:34 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 07:08:34 --> Final output sent to browser
DEBUG - 2017-12-28 07:08:34 --> Total execution time: 0.0615
INFO - 2017-12-28 07:08:34 --> Config Class Initialized
INFO - 2017-12-28 07:08:34 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:08:34 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:08:34 --> Utf8 Class Initialized
INFO - 2017-12-28 07:08:34 --> URI Class Initialized
INFO - 2017-12-28 07:08:34 --> Router Class Initialized
INFO - 2017-12-28 07:08:34 --> Output Class Initialized
INFO - 2017-12-28 07:08:34 --> Security Class Initialized
DEBUG - 2017-12-28 07:08:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:08:34 --> Input Class Initialized
INFO - 2017-12-28 07:08:34 --> Language Class Initialized
ERROR - 2017-12-28 07:08:34 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-28 07:08:34 --> Config Class Initialized
INFO - 2017-12-28 07:08:34 --> Config Class Initialized
INFO - 2017-12-28 07:08:34 --> Hooks Class Initialized
INFO - 2017-12-28 07:08:34 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:08:34 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:08:34 --> Utf8 Class Initialized
DEBUG - 2017-12-28 07:08:34 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:08:34 --> URI Class Initialized
INFO - 2017-12-28 07:08:34 --> Utf8 Class Initialized
INFO - 2017-12-28 07:08:34 --> URI Class Initialized
INFO - 2017-12-28 07:08:34 --> Router Class Initialized
INFO - 2017-12-28 07:08:34 --> Output Class Initialized
INFO - 2017-12-28 07:08:34 --> Router Class Initialized
INFO - 2017-12-28 07:08:34 --> Security Class Initialized
INFO - 2017-12-28 07:08:34 --> Output Class Initialized
DEBUG - 2017-12-28 07:08:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:08:34 --> Input Class Initialized
INFO - 2017-12-28 07:08:34 --> Security Class Initialized
INFO - 2017-12-28 07:08:34 --> Language Class Initialized
DEBUG - 2017-12-28 07:08:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:08:34 --> Input Class Initialized
ERROR - 2017-12-28 07:08:34 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-28 07:08:34 --> Language Class Initialized
ERROR - 2017-12-28 07:08:34 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-28 07:08:34 --> Config Class Initialized
INFO - 2017-12-28 07:08:34 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:08:34 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:08:34 --> Utf8 Class Initialized
INFO - 2017-12-28 07:08:34 --> URI Class Initialized
INFO - 2017-12-28 07:08:34 --> Router Class Initialized
INFO - 2017-12-28 07:08:34 --> Output Class Initialized
INFO - 2017-12-28 07:08:34 --> Security Class Initialized
DEBUG - 2017-12-28 07:08:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:08:34 --> Input Class Initialized
INFO - 2017-12-28 07:08:34 --> Language Class Initialized
INFO - 2017-12-28 07:08:34 --> Loader Class Initialized
INFO - 2017-12-28 07:08:34 --> Helper loaded: url_helper
INFO - 2017-12-28 07:08:35 --> Helper loaded: form_helper
INFO - 2017-12-28 07:08:35 --> Database Driver Class Initialized
DEBUG - 2017-12-28 07:08:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 07:08:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 07:08:35 --> Form Validation Class Initialized
INFO - 2017-12-28 07:08:35 --> Model Class Initialized
INFO - 2017-12-28 07:08:35 --> Controller Class Initialized
INFO - 2017-12-28 07:08:35 --> Model Class Initialized
INFO - 2017-12-28 07:08:35 --> Model Class Initialized
INFO - 2017-12-28 07:08:35 --> Model Class Initialized
INFO - 2017-12-28 07:08:35 --> Model Class Initialized
DEBUG - 2017-12-28 07:08:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 07:08:36 --> Config Class Initialized
INFO - 2017-12-28 07:08:36 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:08:36 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:08:36 --> Utf8 Class Initialized
INFO - 2017-12-28 07:08:36 --> URI Class Initialized
INFO - 2017-12-28 07:08:36 --> Router Class Initialized
INFO - 2017-12-28 07:08:36 --> Output Class Initialized
INFO - 2017-12-28 07:08:36 --> Security Class Initialized
DEBUG - 2017-12-28 07:08:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:08:36 --> Input Class Initialized
INFO - 2017-12-28 07:08:36 --> Language Class Initialized
INFO - 2017-12-28 07:08:36 --> Loader Class Initialized
INFO - 2017-12-28 07:08:36 --> Helper loaded: url_helper
INFO - 2017-12-28 07:08:36 --> Helper loaded: form_helper
INFO - 2017-12-28 07:08:36 --> Database Driver Class Initialized
DEBUG - 2017-12-28 07:08:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 07:08:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 07:08:36 --> Form Validation Class Initialized
INFO - 2017-12-28 07:08:36 --> Model Class Initialized
INFO - 2017-12-28 07:08:36 --> Controller Class Initialized
INFO - 2017-12-28 07:08:36 --> Model Class Initialized
INFO - 2017-12-28 07:08:36 --> Model Class Initialized
INFO - 2017-12-28 07:08:36 --> Model Class Initialized
INFO - 2017-12-28 07:08:36 --> Model Class Initialized
DEBUG - 2017-12-28 07:08:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 07:08:36 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 07:08:36 --> Final output sent to browser
DEBUG - 2017-12-28 07:08:36 --> Total execution time: 0.0550
INFO - 2017-12-28 07:08:36 --> Config Class Initialized
INFO - 2017-12-28 07:08:36 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:08:36 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:08:36 --> Utf8 Class Initialized
INFO - 2017-12-28 07:08:36 --> URI Class Initialized
INFO - 2017-12-28 07:08:36 --> Router Class Initialized
INFO - 2017-12-28 07:08:36 --> Output Class Initialized
INFO - 2017-12-28 07:08:36 --> Security Class Initialized
DEBUG - 2017-12-28 07:08:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:08:36 --> Input Class Initialized
INFO - 2017-12-28 07:08:36 --> Language Class Initialized
ERROR - 2017-12-28 07:08:36 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-28 07:08:36 --> Config Class Initialized
INFO - 2017-12-28 07:08:36 --> Config Class Initialized
INFO - 2017-12-28 07:08:36 --> Hooks Class Initialized
INFO - 2017-12-28 07:08:36 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:08:36 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:08:36 --> Utf8 Class Initialized
DEBUG - 2017-12-28 07:08:36 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:08:36 --> Utf8 Class Initialized
INFO - 2017-12-28 07:08:36 --> URI Class Initialized
INFO - 2017-12-28 07:08:36 --> URI Class Initialized
INFO - 2017-12-28 07:08:36 --> Router Class Initialized
INFO - 2017-12-28 07:08:36 --> Output Class Initialized
INFO - 2017-12-28 07:08:36 --> Router Class Initialized
INFO - 2017-12-28 07:08:36 --> Security Class Initialized
DEBUG - 2017-12-28 07:08:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:08:36 --> Output Class Initialized
INFO - 2017-12-28 07:08:36 --> Input Class Initialized
INFO - 2017-12-28 07:08:36 --> Language Class Initialized
INFO - 2017-12-28 07:08:36 --> Security Class Initialized
ERROR - 2017-12-28 07:08:36 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2017-12-28 07:08:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:08:36 --> Input Class Initialized
INFO - 2017-12-28 07:08:36 --> Language Class Initialized
ERROR - 2017-12-28 07:08:36 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-28 07:08:36 --> Config Class Initialized
INFO - 2017-12-28 07:08:36 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:08:36 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:08:36 --> Utf8 Class Initialized
INFO - 2017-12-28 07:08:36 --> URI Class Initialized
INFO - 2017-12-28 07:08:36 --> Router Class Initialized
INFO - 2017-12-28 07:08:36 --> Output Class Initialized
INFO - 2017-12-28 07:08:36 --> Security Class Initialized
DEBUG - 2017-12-28 07:08:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:08:36 --> Input Class Initialized
INFO - 2017-12-28 07:08:36 --> Language Class Initialized
INFO - 2017-12-28 07:08:36 --> Loader Class Initialized
INFO - 2017-12-28 07:08:36 --> Helper loaded: url_helper
INFO - 2017-12-28 07:08:36 --> Helper loaded: form_helper
INFO - 2017-12-28 07:08:36 --> Database Driver Class Initialized
DEBUG - 2017-12-28 07:08:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 07:08:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 07:08:36 --> Form Validation Class Initialized
INFO - 2017-12-28 07:08:36 --> Model Class Initialized
INFO - 2017-12-28 07:08:36 --> Controller Class Initialized
INFO - 2017-12-28 07:08:36 --> Model Class Initialized
INFO - 2017-12-28 07:08:36 --> Model Class Initialized
INFO - 2017-12-28 07:08:36 --> Model Class Initialized
INFO - 2017-12-28 07:08:36 --> Model Class Initialized
DEBUG - 2017-12-28 07:08:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 07:10:32 --> Config Class Initialized
INFO - 2017-12-28 07:10:32 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:10:32 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:10:32 --> Utf8 Class Initialized
INFO - 2017-12-28 07:10:32 --> URI Class Initialized
INFO - 2017-12-28 07:10:32 --> Router Class Initialized
INFO - 2017-12-28 07:10:32 --> Output Class Initialized
INFO - 2017-12-28 07:10:32 --> Security Class Initialized
DEBUG - 2017-12-28 07:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:10:32 --> Input Class Initialized
INFO - 2017-12-28 07:10:32 --> Language Class Initialized
INFO - 2017-12-28 07:10:32 --> Loader Class Initialized
INFO - 2017-12-28 07:10:32 --> Helper loaded: url_helper
INFO - 2017-12-28 07:10:32 --> Helper loaded: form_helper
INFO - 2017-12-28 07:10:32 --> Database Driver Class Initialized
DEBUG - 2017-12-28 07:10:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 07:10:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 07:10:32 --> Form Validation Class Initialized
INFO - 2017-12-28 07:10:32 --> Model Class Initialized
INFO - 2017-12-28 07:10:32 --> Controller Class Initialized
INFO - 2017-12-28 07:10:32 --> Model Class Initialized
INFO - 2017-12-28 07:10:32 --> Model Class Initialized
INFO - 2017-12-28 07:10:32 --> Model Class Initialized
INFO - 2017-12-28 07:10:32 --> Model Class Initialized
DEBUG - 2017-12-28 07:10:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 07:10:32 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 07:10:32 --> Final output sent to browser
DEBUG - 2017-12-28 07:10:32 --> Total execution time: 0.0658
INFO - 2017-12-28 07:10:32 --> Config Class Initialized
INFO - 2017-12-28 07:10:32 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:10:32 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:10:32 --> Utf8 Class Initialized
INFO - 2017-12-28 07:10:32 --> URI Class Initialized
INFO - 2017-12-28 07:10:32 --> Router Class Initialized
INFO - 2017-12-28 07:10:32 --> Output Class Initialized
INFO - 2017-12-28 07:10:32 --> Security Class Initialized
DEBUG - 2017-12-28 07:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:10:32 --> Input Class Initialized
INFO - 2017-12-28 07:10:32 --> Language Class Initialized
ERROR - 2017-12-28 07:10:32 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-28 07:10:32 --> Config Class Initialized
INFO - 2017-12-28 07:10:32 --> Hooks Class Initialized
INFO - 2017-12-28 07:10:32 --> Config Class Initialized
INFO - 2017-12-28 07:10:32 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:10:32 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:10:32 --> Utf8 Class Initialized
DEBUG - 2017-12-28 07:10:32 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:10:32 --> URI Class Initialized
INFO - 2017-12-28 07:10:32 --> Utf8 Class Initialized
INFO - 2017-12-28 07:10:32 --> URI Class Initialized
INFO - 2017-12-28 07:10:32 --> Router Class Initialized
INFO - 2017-12-28 07:10:32 --> Output Class Initialized
INFO - 2017-12-28 07:10:32 --> Router Class Initialized
INFO - 2017-12-28 07:10:32 --> Security Class Initialized
DEBUG - 2017-12-28 07:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:10:32 --> Output Class Initialized
INFO - 2017-12-28 07:10:32 --> Input Class Initialized
INFO - 2017-12-28 07:10:32 --> Security Class Initialized
INFO - 2017-12-28 07:10:32 --> Language Class Initialized
DEBUG - 2017-12-28 07:10:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2017-12-28 07:10:32 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-28 07:10:32 --> Input Class Initialized
INFO - 2017-12-28 07:10:32 --> Language Class Initialized
ERROR - 2017-12-28 07:10:32 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-28 07:11:00 --> Config Class Initialized
INFO - 2017-12-28 07:11:00 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:11:00 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:11:00 --> Utf8 Class Initialized
INFO - 2017-12-28 07:11:00 --> URI Class Initialized
INFO - 2017-12-28 07:11:00 --> Router Class Initialized
INFO - 2017-12-28 07:11:00 --> Output Class Initialized
INFO - 2017-12-28 07:11:00 --> Security Class Initialized
DEBUG - 2017-12-28 07:11:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:11:00 --> Input Class Initialized
INFO - 2017-12-28 07:11:00 --> Language Class Initialized
INFO - 2017-12-28 07:11:00 --> Loader Class Initialized
INFO - 2017-12-28 07:11:00 --> Helper loaded: url_helper
INFO - 2017-12-28 07:11:00 --> Helper loaded: form_helper
INFO - 2017-12-28 07:11:00 --> Database Driver Class Initialized
DEBUG - 2017-12-28 07:11:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 07:11:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 07:11:00 --> Form Validation Class Initialized
INFO - 2017-12-28 07:11:00 --> Model Class Initialized
INFO - 2017-12-28 07:11:00 --> Controller Class Initialized
INFO - 2017-12-28 07:11:00 --> Model Class Initialized
INFO - 2017-12-28 07:11:00 --> Model Class Initialized
INFO - 2017-12-28 07:11:00 --> Model Class Initialized
INFO - 2017-12-28 07:11:00 --> Model Class Initialized
DEBUG - 2017-12-28 07:11:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 07:11:00 --> Config Class Initialized
INFO - 2017-12-28 07:11:00 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:11:00 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:11:00 --> Utf8 Class Initialized
INFO - 2017-12-28 07:11:00 --> URI Class Initialized
INFO - 2017-12-28 07:11:00 --> Router Class Initialized
INFO - 2017-12-28 07:11:00 --> Output Class Initialized
INFO - 2017-12-28 07:11:00 --> Security Class Initialized
DEBUG - 2017-12-28 07:11:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:11:00 --> Input Class Initialized
INFO - 2017-12-28 07:11:00 --> Language Class Initialized
INFO - 2017-12-28 07:11:00 --> Loader Class Initialized
INFO - 2017-12-28 07:11:00 --> Helper loaded: url_helper
INFO - 2017-12-28 07:11:00 --> Helper loaded: form_helper
INFO - 2017-12-28 07:11:00 --> Database Driver Class Initialized
DEBUG - 2017-12-28 07:11:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 07:11:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 07:11:00 --> Form Validation Class Initialized
INFO - 2017-12-28 07:11:00 --> Model Class Initialized
INFO - 2017-12-28 07:11:00 --> Controller Class Initialized
INFO - 2017-12-28 07:11:00 --> Model Class Initialized
INFO - 2017-12-28 07:11:00 --> Model Class Initialized
INFO - 2017-12-28 07:11:00 --> Model Class Initialized
INFO - 2017-12-28 07:11:00 --> Model Class Initialized
DEBUG - 2017-12-28 07:11:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 07:11:00 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 07:11:00 --> Final output sent to browser
DEBUG - 2017-12-28 07:11:00 --> Total execution time: 0.0638
INFO - 2017-12-28 07:11:00 --> Config Class Initialized
INFO - 2017-12-28 07:11:00 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:11:00 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:11:00 --> Utf8 Class Initialized
INFO - 2017-12-28 07:11:00 --> URI Class Initialized
INFO - 2017-12-28 07:11:00 --> Router Class Initialized
INFO - 2017-12-28 07:11:00 --> Output Class Initialized
INFO - 2017-12-28 07:11:00 --> Security Class Initialized
DEBUG - 2017-12-28 07:11:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:11:00 --> Input Class Initialized
INFO - 2017-12-28 07:11:00 --> Language Class Initialized
INFO - 2017-12-28 07:11:00 --> Loader Class Initialized
INFO - 2017-12-28 07:11:00 --> Helper loaded: url_helper
INFO - 2017-12-28 07:11:00 --> Helper loaded: form_helper
INFO - 2017-12-28 07:11:00 --> Database Driver Class Initialized
DEBUG - 2017-12-28 07:11:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 07:11:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 07:11:00 --> Form Validation Class Initialized
INFO - 2017-12-28 07:11:00 --> Model Class Initialized
INFO - 2017-12-28 07:11:00 --> Controller Class Initialized
INFO - 2017-12-28 07:11:00 --> Model Class Initialized
INFO - 2017-12-28 07:11:00 --> Model Class Initialized
INFO - 2017-12-28 07:11:00 --> Model Class Initialized
INFO - 2017-12-28 07:11:00 --> Model Class Initialized
DEBUG - 2017-12-28 07:11:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 07:11:37 --> Config Class Initialized
INFO - 2017-12-28 07:11:37 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:11:37 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:11:37 --> Utf8 Class Initialized
INFO - 2017-12-28 07:11:37 --> URI Class Initialized
INFO - 2017-12-28 07:11:37 --> Router Class Initialized
INFO - 2017-12-28 07:11:37 --> Output Class Initialized
INFO - 2017-12-28 07:11:37 --> Security Class Initialized
DEBUG - 2017-12-28 07:11:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:11:37 --> Input Class Initialized
INFO - 2017-12-28 07:11:37 --> Language Class Initialized
INFO - 2017-12-28 07:11:37 --> Loader Class Initialized
INFO - 2017-12-28 07:11:37 --> Helper loaded: url_helper
INFO - 2017-12-28 07:11:37 --> Helper loaded: form_helper
INFO - 2017-12-28 07:11:37 --> Database Driver Class Initialized
DEBUG - 2017-12-28 07:11:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 07:11:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 07:11:37 --> Form Validation Class Initialized
INFO - 2017-12-28 07:11:37 --> Model Class Initialized
INFO - 2017-12-28 07:11:37 --> Controller Class Initialized
INFO - 2017-12-28 07:11:37 --> Model Class Initialized
INFO - 2017-12-28 07:11:37 --> Model Class Initialized
INFO - 2017-12-28 07:11:37 --> Model Class Initialized
INFO - 2017-12-28 07:11:37 --> Model Class Initialized
DEBUG - 2017-12-28 07:11:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 07:11:37 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 07:11:37 --> Final output sent to browser
DEBUG - 2017-12-28 07:11:37 --> Total execution time: 0.0703
INFO - 2017-12-28 07:11:52 --> Config Class Initialized
INFO - 2017-12-28 07:11:52 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:11:52 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:11:52 --> Utf8 Class Initialized
INFO - 2017-12-28 07:11:52 --> URI Class Initialized
INFO - 2017-12-28 07:11:52 --> Router Class Initialized
INFO - 2017-12-28 07:11:52 --> Output Class Initialized
INFO - 2017-12-28 07:11:52 --> Security Class Initialized
DEBUG - 2017-12-28 07:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:11:52 --> Input Class Initialized
INFO - 2017-12-28 07:11:52 --> Language Class Initialized
INFO - 2017-12-28 07:11:52 --> Loader Class Initialized
INFO - 2017-12-28 07:11:52 --> Helper loaded: url_helper
INFO - 2017-12-28 07:11:52 --> Helper loaded: form_helper
INFO - 2017-12-28 07:11:52 --> Database Driver Class Initialized
DEBUG - 2017-12-28 07:11:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 07:11:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 07:11:52 --> Form Validation Class Initialized
INFO - 2017-12-28 07:11:52 --> Model Class Initialized
INFO - 2017-12-28 07:11:52 --> Controller Class Initialized
INFO - 2017-12-28 07:11:52 --> Model Class Initialized
INFO - 2017-12-28 07:11:52 --> Model Class Initialized
INFO - 2017-12-28 07:11:52 --> Model Class Initialized
INFO - 2017-12-28 07:11:52 --> Model Class Initialized
DEBUG - 2017-12-28 07:11:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 07:11:52 --> Config Class Initialized
INFO - 2017-12-28 07:11:52 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:11:52 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:11:52 --> Utf8 Class Initialized
INFO - 2017-12-28 07:11:52 --> URI Class Initialized
INFO - 2017-12-28 07:11:52 --> Router Class Initialized
INFO - 2017-12-28 07:11:52 --> Output Class Initialized
INFO - 2017-12-28 07:11:52 --> Security Class Initialized
DEBUG - 2017-12-28 07:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:11:52 --> Input Class Initialized
INFO - 2017-12-28 07:11:52 --> Language Class Initialized
INFO - 2017-12-28 07:11:52 --> Loader Class Initialized
INFO - 2017-12-28 07:11:52 --> Helper loaded: url_helper
INFO - 2017-12-28 07:11:52 --> Helper loaded: form_helper
INFO - 2017-12-28 07:11:52 --> Database Driver Class Initialized
DEBUG - 2017-12-28 07:11:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 07:11:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 07:11:52 --> Form Validation Class Initialized
INFO - 2017-12-28 07:11:52 --> Model Class Initialized
INFO - 2017-12-28 07:11:52 --> Controller Class Initialized
INFO - 2017-12-28 07:11:52 --> Model Class Initialized
INFO - 2017-12-28 07:11:52 --> Model Class Initialized
INFO - 2017-12-28 07:11:52 --> Model Class Initialized
INFO - 2017-12-28 07:11:52 --> Model Class Initialized
DEBUG - 2017-12-28 07:11:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 07:11:52 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 07:11:52 --> Final output sent to browser
DEBUG - 2017-12-28 07:11:52 --> Total execution time: 0.0602
INFO - 2017-12-28 07:11:52 --> Config Class Initialized
INFO - 2017-12-28 07:11:52 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:11:52 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:11:52 --> Utf8 Class Initialized
INFO - 2017-12-28 07:11:52 --> URI Class Initialized
INFO - 2017-12-28 07:11:52 --> Router Class Initialized
INFO - 2017-12-28 07:11:52 --> Output Class Initialized
INFO - 2017-12-28 07:11:52 --> Security Class Initialized
DEBUG - 2017-12-28 07:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:11:52 --> Input Class Initialized
INFO - 2017-12-28 07:11:52 --> Language Class Initialized
INFO - 2017-12-28 07:11:52 --> Loader Class Initialized
INFO - 2017-12-28 07:11:52 --> Helper loaded: url_helper
INFO - 2017-12-28 07:11:52 --> Helper loaded: form_helper
INFO - 2017-12-28 07:11:52 --> Database Driver Class Initialized
DEBUG - 2017-12-28 07:11:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 07:11:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 07:11:52 --> Form Validation Class Initialized
INFO - 2017-12-28 07:11:52 --> Model Class Initialized
INFO - 2017-12-28 07:11:52 --> Controller Class Initialized
INFO - 2017-12-28 07:11:52 --> Model Class Initialized
INFO - 2017-12-28 07:11:52 --> Model Class Initialized
INFO - 2017-12-28 07:11:52 --> Model Class Initialized
INFO - 2017-12-28 07:11:52 --> Model Class Initialized
DEBUG - 2017-12-28 07:11:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 07:16:00 --> Config Class Initialized
INFO - 2017-12-28 07:16:00 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:16:00 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:16:00 --> Utf8 Class Initialized
INFO - 2017-12-28 07:16:00 --> URI Class Initialized
INFO - 2017-12-28 07:16:00 --> Router Class Initialized
INFO - 2017-12-28 07:16:00 --> Output Class Initialized
INFO - 2017-12-28 07:16:00 --> Security Class Initialized
DEBUG - 2017-12-28 07:16:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:16:00 --> Input Class Initialized
INFO - 2017-12-28 07:16:00 --> Language Class Initialized
INFO - 2017-12-28 07:16:00 --> Loader Class Initialized
INFO - 2017-12-28 07:16:00 --> Helper loaded: url_helper
INFO - 2017-12-28 07:16:00 --> Helper loaded: form_helper
INFO - 2017-12-28 07:16:00 --> Database Driver Class Initialized
DEBUG - 2017-12-28 07:16:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 07:16:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 07:16:00 --> Form Validation Class Initialized
INFO - 2017-12-28 07:16:00 --> Model Class Initialized
INFO - 2017-12-28 07:16:00 --> Controller Class Initialized
INFO - 2017-12-28 07:16:00 --> Model Class Initialized
INFO - 2017-12-28 07:16:00 --> Model Class Initialized
INFO - 2017-12-28 07:16:00 --> Model Class Initialized
INFO - 2017-12-28 07:16:00 --> Model Class Initialized
DEBUG - 2017-12-28 07:16:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 07:16:00 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 07:16:00 --> Final output sent to browser
DEBUG - 2017-12-28 07:16:00 --> Total execution time: 0.0598
INFO - 2017-12-28 07:16:00 --> Config Class Initialized
INFO - 2017-12-28 07:16:00 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:16:00 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:16:00 --> Utf8 Class Initialized
INFO - 2017-12-28 07:16:00 --> URI Class Initialized
INFO - 2017-12-28 07:16:00 --> Router Class Initialized
INFO - 2017-12-28 07:16:00 --> Output Class Initialized
INFO - 2017-12-28 07:16:00 --> Security Class Initialized
DEBUG - 2017-12-28 07:16:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:16:00 --> Input Class Initialized
INFO - 2017-12-28 07:16:00 --> Language Class Initialized
INFO - 2017-12-28 07:16:00 --> Loader Class Initialized
INFO - 2017-12-28 07:16:00 --> Helper loaded: url_helper
INFO - 2017-12-28 07:16:00 --> Helper loaded: form_helper
INFO - 2017-12-28 07:16:00 --> Database Driver Class Initialized
DEBUG - 2017-12-28 07:16:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 07:16:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 07:16:00 --> Form Validation Class Initialized
INFO - 2017-12-28 07:16:00 --> Model Class Initialized
INFO - 2017-12-28 07:16:00 --> Controller Class Initialized
INFO - 2017-12-28 07:16:00 --> Model Class Initialized
INFO - 2017-12-28 07:16:00 --> Model Class Initialized
INFO - 2017-12-28 07:16:00 --> Model Class Initialized
INFO - 2017-12-28 07:16:00 --> Model Class Initialized
DEBUG - 2017-12-28 07:16:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 07:16:01 --> Config Class Initialized
INFO - 2017-12-28 07:16:01 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:16:01 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:16:01 --> Utf8 Class Initialized
INFO - 2017-12-28 07:16:01 --> URI Class Initialized
INFO - 2017-12-28 07:16:01 --> Router Class Initialized
INFO - 2017-12-28 07:16:01 --> Output Class Initialized
INFO - 2017-12-28 07:16:01 --> Security Class Initialized
DEBUG - 2017-12-28 07:16:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:16:01 --> Input Class Initialized
INFO - 2017-12-28 07:16:01 --> Language Class Initialized
INFO - 2017-12-28 07:16:01 --> Loader Class Initialized
INFO - 2017-12-28 07:16:01 --> Helper loaded: url_helper
INFO - 2017-12-28 07:16:01 --> Helper loaded: form_helper
INFO - 2017-12-28 07:16:01 --> Database Driver Class Initialized
DEBUG - 2017-12-28 07:16:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 07:16:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 07:16:01 --> Form Validation Class Initialized
INFO - 2017-12-28 07:16:01 --> Model Class Initialized
INFO - 2017-12-28 07:16:01 --> Controller Class Initialized
INFO - 2017-12-28 07:16:01 --> Model Class Initialized
INFO - 2017-12-28 07:16:01 --> Model Class Initialized
INFO - 2017-12-28 07:16:01 --> Model Class Initialized
INFO - 2017-12-28 07:16:01 --> Model Class Initialized
DEBUG - 2017-12-28 07:16:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 07:16:01 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 07:16:01 --> Final output sent to browser
DEBUG - 2017-12-28 07:16:01 --> Total execution time: 0.0533
INFO - 2017-12-28 07:16:01 --> Config Class Initialized
INFO - 2017-12-28 07:16:01 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:16:01 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:16:01 --> Utf8 Class Initialized
INFO - 2017-12-28 07:16:01 --> URI Class Initialized
INFO - 2017-12-28 07:16:01 --> Router Class Initialized
INFO - 2017-12-28 07:16:01 --> Output Class Initialized
INFO - 2017-12-28 07:16:01 --> Security Class Initialized
DEBUG - 2017-12-28 07:16:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:16:01 --> Input Class Initialized
INFO - 2017-12-28 07:16:01 --> Language Class Initialized
INFO - 2017-12-28 07:16:01 --> Loader Class Initialized
INFO - 2017-12-28 07:16:01 --> Helper loaded: url_helper
INFO - 2017-12-28 07:16:01 --> Helper loaded: form_helper
INFO - 2017-12-28 07:16:01 --> Database Driver Class Initialized
DEBUG - 2017-12-28 07:16:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 07:16:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 07:16:01 --> Form Validation Class Initialized
INFO - 2017-12-28 07:16:01 --> Model Class Initialized
INFO - 2017-12-28 07:16:01 --> Controller Class Initialized
INFO - 2017-12-28 07:16:01 --> Model Class Initialized
INFO - 2017-12-28 07:16:01 --> Model Class Initialized
INFO - 2017-12-28 07:16:01 --> Model Class Initialized
INFO - 2017-12-28 07:16:01 --> Model Class Initialized
DEBUG - 2017-12-28 07:16:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 07:17:11 --> Config Class Initialized
INFO - 2017-12-28 07:17:11 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:17:11 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:17:11 --> Utf8 Class Initialized
INFO - 2017-12-28 07:17:11 --> URI Class Initialized
INFO - 2017-12-28 07:17:11 --> Router Class Initialized
INFO - 2017-12-28 07:17:11 --> Output Class Initialized
INFO - 2017-12-28 07:17:11 --> Security Class Initialized
DEBUG - 2017-12-28 07:17:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:17:11 --> Input Class Initialized
INFO - 2017-12-28 07:17:11 --> Language Class Initialized
INFO - 2017-12-28 07:17:11 --> Loader Class Initialized
INFO - 2017-12-28 07:17:11 --> Helper loaded: url_helper
INFO - 2017-12-28 07:17:11 --> Helper loaded: form_helper
INFO - 2017-12-28 07:17:11 --> Database Driver Class Initialized
DEBUG - 2017-12-28 07:17:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 07:17:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 07:17:11 --> Form Validation Class Initialized
INFO - 2017-12-28 07:17:11 --> Model Class Initialized
INFO - 2017-12-28 07:17:11 --> Controller Class Initialized
INFO - 2017-12-28 07:17:11 --> Model Class Initialized
INFO - 2017-12-28 07:17:11 --> Model Class Initialized
INFO - 2017-12-28 07:17:11 --> Model Class Initialized
INFO - 2017-12-28 07:17:11 --> Model Class Initialized
DEBUG - 2017-12-28 07:17:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 07:17:11 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 07:17:11 --> Final output sent to browser
DEBUG - 2017-12-28 07:17:11 --> Total execution time: 0.0618
INFO - 2017-12-28 07:17:11 --> Config Class Initialized
INFO - 2017-12-28 07:17:11 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:17:11 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:17:11 --> Utf8 Class Initialized
INFO - 2017-12-28 07:17:11 --> URI Class Initialized
INFO - 2017-12-28 07:17:11 --> Router Class Initialized
INFO - 2017-12-28 07:17:11 --> Output Class Initialized
INFO - 2017-12-28 07:17:11 --> Security Class Initialized
DEBUG - 2017-12-28 07:17:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:17:11 --> Input Class Initialized
INFO - 2017-12-28 07:17:11 --> Language Class Initialized
INFO - 2017-12-28 07:17:11 --> Loader Class Initialized
INFO - 2017-12-28 07:17:11 --> Helper loaded: url_helper
INFO - 2017-12-28 07:17:11 --> Helper loaded: form_helper
INFO - 2017-12-28 07:17:11 --> Database Driver Class Initialized
DEBUG - 2017-12-28 07:17:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 07:17:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 07:17:11 --> Form Validation Class Initialized
INFO - 2017-12-28 07:17:11 --> Model Class Initialized
INFO - 2017-12-28 07:17:11 --> Controller Class Initialized
INFO - 2017-12-28 07:17:11 --> Model Class Initialized
INFO - 2017-12-28 07:17:11 --> Model Class Initialized
INFO - 2017-12-28 07:17:11 --> Model Class Initialized
INFO - 2017-12-28 07:17:11 --> Model Class Initialized
DEBUG - 2017-12-28 07:17:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 07:18:09 --> Config Class Initialized
INFO - 2017-12-28 07:18:09 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:18:09 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:18:09 --> Utf8 Class Initialized
INFO - 2017-12-28 07:18:09 --> URI Class Initialized
INFO - 2017-12-28 07:18:09 --> Router Class Initialized
INFO - 2017-12-28 07:18:09 --> Output Class Initialized
INFO - 2017-12-28 07:18:09 --> Security Class Initialized
DEBUG - 2017-12-28 07:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:18:09 --> Input Class Initialized
INFO - 2017-12-28 07:18:09 --> Language Class Initialized
INFO - 2017-12-28 07:18:09 --> Loader Class Initialized
INFO - 2017-12-28 07:18:09 --> Helper loaded: url_helper
INFO - 2017-12-28 07:18:09 --> Helper loaded: form_helper
INFO - 2017-12-28 07:18:09 --> Database Driver Class Initialized
DEBUG - 2017-12-28 07:18:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 07:18:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 07:18:09 --> Form Validation Class Initialized
INFO - 2017-12-28 07:18:09 --> Model Class Initialized
INFO - 2017-12-28 07:18:09 --> Controller Class Initialized
INFO - 2017-12-28 07:18:09 --> Model Class Initialized
INFO - 2017-12-28 07:18:09 --> Model Class Initialized
INFO - 2017-12-28 07:18:09 --> Model Class Initialized
INFO - 2017-12-28 07:18:09 --> Model Class Initialized
DEBUG - 2017-12-28 07:18:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 07:18:09 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 07:18:09 --> Final output sent to browser
DEBUG - 2017-12-28 07:18:09 --> Total execution time: 0.0846
INFO - 2017-12-28 07:18:09 --> Config Class Initialized
INFO - 2017-12-28 07:18:09 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:18:09 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:18:09 --> Utf8 Class Initialized
INFO - 2017-12-28 07:18:09 --> URI Class Initialized
INFO - 2017-12-28 07:18:09 --> Router Class Initialized
INFO - 2017-12-28 07:18:09 --> Output Class Initialized
INFO - 2017-12-28 07:18:09 --> Security Class Initialized
DEBUG - 2017-12-28 07:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:18:09 --> Input Class Initialized
INFO - 2017-12-28 07:18:09 --> Language Class Initialized
INFO - 2017-12-28 07:18:09 --> Loader Class Initialized
INFO - 2017-12-28 07:18:09 --> Helper loaded: url_helper
INFO - 2017-12-28 07:18:09 --> Helper loaded: form_helper
INFO - 2017-12-28 07:18:09 --> Database Driver Class Initialized
DEBUG - 2017-12-28 07:18:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 07:18:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 07:18:09 --> Form Validation Class Initialized
INFO - 2017-12-28 07:18:09 --> Model Class Initialized
INFO - 2017-12-28 07:18:09 --> Controller Class Initialized
INFO - 2017-12-28 07:18:09 --> Model Class Initialized
INFO - 2017-12-28 07:18:09 --> Model Class Initialized
INFO - 2017-12-28 07:18:09 --> Model Class Initialized
INFO - 2017-12-28 07:18:09 --> Model Class Initialized
DEBUG - 2017-12-28 07:18:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 07:20:04 --> Config Class Initialized
INFO - 2017-12-28 07:20:04 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:20:04 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:20:04 --> Utf8 Class Initialized
INFO - 2017-12-28 07:20:04 --> URI Class Initialized
INFO - 2017-12-28 07:20:04 --> Router Class Initialized
INFO - 2017-12-28 07:20:04 --> Output Class Initialized
INFO - 2017-12-28 07:20:04 --> Security Class Initialized
DEBUG - 2017-12-28 07:20:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:20:04 --> Input Class Initialized
INFO - 2017-12-28 07:20:04 --> Language Class Initialized
INFO - 2017-12-28 07:20:04 --> Loader Class Initialized
INFO - 2017-12-28 07:20:04 --> Helper loaded: url_helper
INFO - 2017-12-28 07:20:04 --> Helper loaded: form_helper
INFO - 2017-12-28 07:20:04 --> Database Driver Class Initialized
DEBUG - 2017-12-28 07:20:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 07:20:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 07:20:04 --> Form Validation Class Initialized
INFO - 2017-12-28 07:20:04 --> Model Class Initialized
INFO - 2017-12-28 07:20:04 --> Controller Class Initialized
INFO - 2017-12-28 07:20:04 --> Model Class Initialized
INFO - 2017-12-28 07:20:04 --> Model Class Initialized
INFO - 2017-12-28 07:20:04 --> Model Class Initialized
INFO - 2017-12-28 07:20:04 --> Model Class Initialized
DEBUG - 2017-12-28 07:20:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 07:20:04 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 07:20:04 --> Final output sent to browser
DEBUG - 2017-12-28 07:20:04 --> Total execution time: 0.0492
INFO - 2017-12-28 07:20:04 --> Config Class Initialized
INFO - 2017-12-28 07:20:04 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:20:04 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:20:04 --> Utf8 Class Initialized
INFO - 2017-12-28 07:20:04 --> URI Class Initialized
INFO - 2017-12-28 07:20:04 --> Router Class Initialized
INFO - 2017-12-28 07:20:04 --> Output Class Initialized
INFO - 2017-12-28 07:20:04 --> Security Class Initialized
DEBUG - 2017-12-28 07:20:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:20:04 --> Input Class Initialized
INFO - 2017-12-28 07:20:04 --> Language Class Initialized
INFO - 2017-12-28 07:20:04 --> Loader Class Initialized
INFO - 2017-12-28 07:20:04 --> Helper loaded: url_helper
INFO - 2017-12-28 07:20:04 --> Helper loaded: form_helper
INFO - 2017-12-28 07:20:04 --> Database Driver Class Initialized
DEBUG - 2017-12-28 07:20:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 07:20:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 07:20:04 --> Form Validation Class Initialized
INFO - 2017-12-28 07:20:04 --> Model Class Initialized
INFO - 2017-12-28 07:20:04 --> Controller Class Initialized
INFO - 2017-12-28 07:20:04 --> Model Class Initialized
INFO - 2017-12-28 07:20:04 --> Model Class Initialized
INFO - 2017-12-28 07:20:04 --> Model Class Initialized
INFO - 2017-12-28 07:20:04 --> Model Class Initialized
DEBUG - 2017-12-28 07:20:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 07:20:16 --> Config Class Initialized
INFO - 2017-12-28 07:20:16 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:20:16 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:20:16 --> Utf8 Class Initialized
INFO - 2017-12-28 07:20:16 --> URI Class Initialized
INFO - 2017-12-28 07:20:16 --> Router Class Initialized
INFO - 2017-12-28 07:20:16 --> Output Class Initialized
INFO - 2017-12-28 07:20:16 --> Security Class Initialized
DEBUG - 2017-12-28 07:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:20:16 --> Input Class Initialized
INFO - 2017-12-28 07:20:16 --> Language Class Initialized
INFO - 2017-12-28 07:20:16 --> Loader Class Initialized
INFO - 2017-12-28 07:20:16 --> Helper loaded: url_helper
INFO - 2017-12-28 07:20:16 --> Helper loaded: form_helper
INFO - 2017-12-28 07:20:16 --> Database Driver Class Initialized
DEBUG - 2017-12-28 07:20:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 07:20:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 07:20:16 --> Form Validation Class Initialized
INFO - 2017-12-28 07:20:16 --> Model Class Initialized
INFO - 2017-12-28 07:20:16 --> Controller Class Initialized
INFO - 2017-12-28 07:20:16 --> Model Class Initialized
INFO - 2017-12-28 07:20:16 --> Model Class Initialized
INFO - 2017-12-28 07:20:16 --> Model Class Initialized
INFO - 2017-12-28 07:20:16 --> Model Class Initialized
DEBUG - 2017-12-28 07:20:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 07:20:16 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 07:20:16 --> Final output sent to browser
DEBUG - 2017-12-28 07:20:16 --> Total execution time: 0.0942
INFO - 2017-12-28 07:20:16 --> Config Class Initialized
INFO - 2017-12-28 07:20:16 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:20:16 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:20:16 --> Utf8 Class Initialized
INFO - 2017-12-28 07:20:16 --> URI Class Initialized
INFO - 2017-12-28 07:20:16 --> Router Class Initialized
INFO - 2017-12-28 07:20:16 --> Output Class Initialized
INFO - 2017-12-28 07:20:16 --> Security Class Initialized
DEBUG - 2017-12-28 07:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:20:16 --> Input Class Initialized
INFO - 2017-12-28 07:20:16 --> Language Class Initialized
INFO - 2017-12-28 07:20:16 --> Loader Class Initialized
INFO - 2017-12-28 07:20:16 --> Helper loaded: url_helper
INFO - 2017-12-28 07:20:16 --> Helper loaded: form_helper
INFO - 2017-12-28 07:20:16 --> Database Driver Class Initialized
DEBUG - 2017-12-28 07:20:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 07:20:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 07:20:16 --> Form Validation Class Initialized
INFO - 2017-12-28 07:20:16 --> Model Class Initialized
INFO - 2017-12-28 07:20:16 --> Controller Class Initialized
INFO - 2017-12-28 07:20:16 --> Model Class Initialized
INFO - 2017-12-28 07:20:16 --> Model Class Initialized
INFO - 2017-12-28 07:20:16 --> Model Class Initialized
INFO - 2017-12-28 07:20:16 --> Model Class Initialized
DEBUG - 2017-12-28 07:20:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 07:20:26 --> Config Class Initialized
INFO - 2017-12-28 07:20:26 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:20:26 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:20:26 --> Utf8 Class Initialized
INFO - 2017-12-28 07:20:26 --> URI Class Initialized
INFO - 2017-12-28 07:20:26 --> Router Class Initialized
INFO - 2017-12-28 07:20:26 --> Output Class Initialized
INFO - 2017-12-28 07:20:26 --> Security Class Initialized
DEBUG - 2017-12-28 07:20:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:20:26 --> Input Class Initialized
INFO - 2017-12-28 07:20:26 --> Language Class Initialized
INFO - 2017-12-28 07:20:26 --> Loader Class Initialized
INFO - 2017-12-28 07:20:26 --> Helper loaded: url_helper
INFO - 2017-12-28 07:20:26 --> Helper loaded: form_helper
INFO - 2017-12-28 07:20:26 --> Database Driver Class Initialized
DEBUG - 2017-12-28 07:20:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 07:20:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 07:20:26 --> Form Validation Class Initialized
INFO - 2017-12-28 07:20:26 --> Model Class Initialized
INFO - 2017-12-28 07:20:26 --> Controller Class Initialized
INFO - 2017-12-28 07:20:26 --> Model Class Initialized
INFO - 2017-12-28 07:20:26 --> Model Class Initialized
INFO - 2017-12-28 07:20:26 --> Model Class Initialized
INFO - 2017-12-28 07:20:26 --> Model Class Initialized
DEBUG - 2017-12-28 07:20:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 07:20:26 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 07:20:26 --> Final output sent to browser
DEBUG - 2017-12-28 07:20:26 --> Total execution time: 0.0735
INFO - 2017-12-28 07:20:26 --> Config Class Initialized
INFO - 2017-12-28 07:20:26 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:20:26 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:20:26 --> Utf8 Class Initialized
INFO - 2017-12-28 07:20:26 --> URI Class Initialized
INFO - 2017-12-28 07:20:26 --> Router Class Initialized
INFO - 2017-12-28 07:20:26 --> Output Class Initialized
INFO - 2017-12-28 07:20:26 --> Security Class Initialized
DEBUG - 2017-12-28 07:20:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:20:26 --> Input Class Initialized
INFO - 2017-12-28 07:20:26 --> Language Class Initialized
INFO - 2017-12-28 07:20:26 --> Loader Class Initialized
INFO - 2017-12-28 07:20:26 --> Helper loaded: url_helper
INFO - 2017-12-28 07:20:26 --> Helper loaded: form_helper
INFO - 2017-12-28 07:20:26 --> Database Driver Class Initialized
DEBUG - 2017-12-28 07:20:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 07:20:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 07:20:26 --> Form Validation Class Initialized
INFO - 2017-12-28 07:20:26 --> Model Class Initialized
INFO - 2017-12-28 07:20:26 --> Controller Class Initialized
INFO - 2017-12-28 07:20:26 --> Model Class Initialized
INFO - 2017-12-28 07:20:26 --> Model Class Initialized
INFO - 2017-12-28 07:20:26 --> Model Class Initialized
INFO - 2017-12-28 07:20:26 --> Model Class Initialized
DEBUG - 2017-12-28 07:20:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 07:20:48 --> Config Class Initialized
INFO - 2017-12-28 07:20:48 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:20:48 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:20:48 --> Utf8 Class Initialized
INFO - 2017-12-28 07:20:48 --> URI Class Initialized
INFO - 2017-12-28 07:20:48 --> Router Class Initialized
INFO - 2017-12-28 07:20:48 --> Output Class Initialized
INFO - 2017-12-28 07:20:48 --> Security Class Initialized
DEBUG - 2017-12-28 07:20:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:20:48 --> Input Class Initialized
INFO - 2017-12-28 07:20:48 --> Language Class Initialized
INFO - 2017-12-28 07:20:48 --> Loader Class Initialized
INFO - 2017-12-28 07:20:48 --> Helper loaded: url_helper
INFO - 2017-12-28 07:20:48 --> Helper loaded: form_helper
INFO - 2017-12-28 07:20:48 --> Database Driver Class Initialized
DEBUG - 2017-12-28 07:20:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 07:20:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 07:20:48 --> Form Validation Class Initialized
INFO - 2017-12-28 07:20:48 --> Model Class Initialized
INFO - 2017-12-28 07:20:48 --> Controller Class Initialized
INFO - 2017-12-28 07:20:48 --> Model Class Initialized
INFO - 2017-12-28 07:20:48 --> Model Class Initialized
INFO - 2017-12-28 07:20:48 --> Model Class Initialized
INFO - 2017-12-28 07:20:48 --> Model Class Initialized
DEBUG - 2017-12-28 07:20:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 07:20:48 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 07:20:48 --> Final output sent to browser
DEBUG - 2017-12-28 07:20:48 --> Total execution time: 0.0733
INFO - 2017-12-28 07:20:48 --> Config Class Initialized
INFO - 2017-12-28 07:20:48 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:20:48 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:20:48 --> Utf8 Class Initialized
INFO - 2017-12-28 07:20:48 --> URI Class Initialized
INFO - 2017-12-28 07:20:48 --> Router Class Initialized
INFO - 2017-12-28 07:20:48 --> Output Class Initialized
INFO - 2017-12-28 07:20:48 --> Security Class Initialized
DEBUG - 2017-12-28 07:20:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:20:48 --> Input Class Initialized
INFO - 2017-12-28 07:20:48 --> Language Class Initialized
INFO - 2017-12-28 07:20:48 --> Loader Class Initialized
INFO - 2017-12-28 07:20:48 --> Helper loaded: url_helper
INFO - 2017-12-28 07:20:48 --> Helper loaded: form_helper
INFO - 2017-12-28 07:20:48 --> Database Driver Class Initialized
DEBUG - 2017-12-28 07:20:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 07:20:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 07:20:48 --> Form Validation Class Initialized
INFO - 2017-12-28 07:20:48 --> Model Class Initialized
INFO - 2017-12-28 07:20:48 --> Controller Class Initialized
INFO - 2017-12-28 07:20:48 --> Model Class Initialized
INFO - 2017-12-28 07:20:48 --> Model Class Initialized
INFO - 2017-12-28 07:20:48 --> Model Class Initialized
INFO - 2017-12-28 07:20:48 --> Model Class Initialized
DEBUG - 2017-12-28 07:20:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 07:20:50 --> Config Class Initialized
INFO - 2017-12-28 07:20:50 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:20:50 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:20:50 --> Utf8 Class Initialized
INFO - 2017-12-28 07:20:50 --> URI Class Initialized
INFO - 2017-12-28 07:20:50 --> Router Class Initialized
INFO - 2017-12-28 07:20:50 --> Output Class Initialized
INFO - 2017-12-28 07:20:50 --> Security Class Initialized
DEBUG - 2017-12-28 07:20:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:20:50 --> Input Class Initialized
INFO - 2017-12-28 07:20:50 --> Language Class Initialized
INFO - 2017-12-28 07:20:50 --> Loader Class Initialized
INFO - 2017-12-28 07:20:50 --> Helper loaded: url_helper
INFO - 2017-12-28 07:20:50 --> Helper loaded: form_helper
INFO - 2017-12-28 07:20:50 --> Database Driver Class Initialized
DEBUG - 2017-12-28 07:20:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 07:20:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 07:20:50 --> Form Validation Class Initialized
INFO - 2017-12-28 07:20:50 --> Model Class Initialized
INFO - 2017-12-28 07:20:50 --> Controller Class Initialized
INFO - 2017-12-28 07:20:50 --> Model Class Initialized
INFO - 2017-12-28 07:20:50 --> Model Class Initialized
INFO - 2017-12-28 07:20:50 --> Model Class Initialized
INFO - 2017-12-28 07:20:50 --> Model Class Initialized
DEBUG - 2017-12-28 07:20:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 07:20:50 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 07:20:50 --> Final output sent to browser
DEBUG - 2017-12-28 07:20:50 --> Total execution time: 0.0565
INFO - 2017-12-28 07:20:52 --> Config Class Initialized
INFO - 2017-12-28 07:20:52 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:20:52 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:20:52 --> Utf8 Class Initialized
INFO - 2017-12-28 07:20:52 --> URI Class Initialized
INFO - 2017-12-28 07:20:52 --> Router Class Initialized
INFO - 2017-12-28 07:20:52 --> Output Class Initialized
INFO - 2017-12-28 07:20:52 --> Security Class Initialized
DEBUG - 2017-12-28 07:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:20:52 --> Input Class Initialized
INFO - 2017-12-28 07:20:52 --> Language Class Initialized
INFO - 2017-12-28 07:20:52 --> Loader Class Initialized
INFO - 2017-12-28 07:20:52 --> Helper loaded: url_helper
INFO - 2017-12-28 07:20:52 --> Helper loaded: form_helper
INFO - 2017-12-28 07:20:52 --> Config Class Initialized
INFO - 2017-12-28 07:20:52 --> Hooks Class Initialized
INFO - 2017-12-28 07:20:52 --> Database Driver Class Initialized
DEBUG - 2017-12-28 07:20:52 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:20:52 --> Utf8 Class Initialized
INFO - 2017-12-28 07:20:52 --> URI Class Initialized
DEBUG - 2017-12-28 07:20:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 07:20:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 07:20:52 --> Router Class Initialized
INFO - 2017-12-28 07:20:52 --> Form Validation Class Initialized
INFO - 2017-12-28 07:20:52 --> Model Class Initialized
INFO - 2017-12-28 07:20:52 --> Output Class Initialized
INFO - 2017-12-28 07:20:52 --> Controller Class Initialized
INFO - 2017-12-28 07:20:52 --> Security Class Initialized
INFO - 2017-12-28 07:20:52 --> Model Class Initialized
INFO - 2017-12-28 07:20:52 --> Model Class Initialized
DEBUG - 2017-12-28 07:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:20:52 --> Model Class Initialized
INFO - 2017-12-28 07:20:52 --> Input Class Initialized
INFO - 2017-12-28 07:20:52 --> Model Class Initialized
INFO - 2017-12-28 07:20:52 --> Language Class Initialized
DEBUG - 2017-12-28 07:20:52 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2017-12-28 07:20:52 --> 404 Page Not Found: Faviconico/index
INFO - 2017-12-28 07:21:03 --> Config Class Initialized
INFO - 2017-12-28 07:21:03 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:21:03 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:21:03 --> Utf8 Class Initialized
INFO - 2017-12-28 07:21:03 --> URI Class Initialized
INFO - 2017-12-28 07:21:03 --> Router Class Initialized
INFO - 2017-12-28 07:21:03 --> Output Class Initialized
INFO - 2017-12-28 07:21:03 --> Security Class Initialized
DEBUG - 2017-12-28 07:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:21:03 --> Input Class Initialized
INFO - 2017-12-28 07:21:03 --> Language Class Initialized
INFO - 2017-12-28 07:21:03 --> Loader Class Initialized
INFO - 2017-12-28 07:21:03 --> Helper loaded: url_helper
INFO - 2017-12-28 07:21:03 --> Helper loaded: form_helper
INFO - 2017-12-28 07:21:03 --> Database Driver Class Initialized
DEBUG - 2017-12-28 07:21:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 07:21:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 07:21:03 --> Form Validation Class Initialized
INFO - 2017-12-28 07:21:03 --> Model Class Initialized
INFO - 2017-12-28 07:21:03 --> Controller Class Initialized
INFO - 2017-12-28 07:21:03 --> Model Class Initialized
INFO - 2017-12-28 07:21:03 --> Model Class Initialized
INFO - 2017-12-28 07:21:03 --> Model Class Initialized
INFO - 2017-12-28 07:21:03 --> Model Class Initialized
DEBUG - 2017-12-28 07:21:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 07:21:03 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 07:21:03 --> Final output sent to browser
DEBUG - 2017-12-28 07:21:03 --> Total execution time: 0.0722
INFO - 2017-12-28 07:21:03 --> Config Class Initialized
INFO - 2017-12-28 07:21:03 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:21:03 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:21:03 --> Utf8 Class Initialized
INFO - 2017-12-28 07:21:03 --> URI Class Initialized
INFO - 2017-12-28 07:21:03 --> Router Class Initialized
INFO - 2017-12-28 07:21:03 --> Output Class Initialized
INFO - 2017-12-28 07:21:03 --> Security Class Initialized
DEBUG - 2017-12-28 07:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:21:03 --> Input Class Initialized
INFO - 2017-12-28 07:21:03 --> Language Class Initialized
INFO - 2017-12-28 07:21:03 --> Loader Class Initialized
INFO - 2017-12-28 07:21:03 --> Helper loaded: url_helper
INFO - 2017-12-28 07:21:03 --> Helper loaded: form_helper
INFO - 2017-12-28 07:21:03 --> Database Driver Class Initialized
DEBUG - 2017-12-28 07:21:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 07:21:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 07:21:03 --> Form Validation Class Initialized
INFO - 2017-12-28 07:21:03 --> Model Class Initialized
INFO - 2017-12-28 07:21:03 --> Controller Class Initialized
INFO - 2017-12-28 07:21:03 --> Model Class Initialized
INFO - 2017-12-28 07:21:03 --> Model Class Initialized
INFO - 2017-12-28 07:21:03 --> Model Class Initialized
INFO - 2017-12-28 07:21:03 --> Model Class Initialized
DEBUG - 2017-12-28 07:21:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 07:21:14 --> Config Class Initialized
INFO - 2017-12-28 07:21:14 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:21:14 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:21:14 --> Utf8 Class Initialized
INFO - 2017-12-28 07:21:14 --> URI Class Initialized
INFO - 2017-12-28 07:21:14 --> Router Class Initialized
INFO - 2017-12-28 07:21:14 --> Output Class Initialized
INFO - 2017-12-28 07:21:14 --> Security Class Initialized
DEBUG - 2017-12-28 07:21:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:21:14 --> Input Class Initialized
INFO - 2017-12-28 07:21:14 --> Language Class Initialized
INFO - 2017-12-28 07:21:14 --> Loader Class Initialized
INFO - 2017-12-28 07:21:14 --> Helper loaded: url_helper
INFO - 2017-12-28 07:21:14 --> Helper loaded: form_helper
INFO - 2017-12-28 07:21:14 --> Database Driver Class Initialized
DEBUG - 2017-12-28 07:21:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 07:21:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 07:21:14 --> Form Validation Class Initialized
INFO - 2017-12-28 07:21:14 --> Model Class Initialized
INFO - 2017-12-28 07:21:14 --> Controller Class Initialized
INFO - 2017-12-28 07:21:14 --> Model Class Initialized
INFO - 2017-12-28 07:21:14 --> Model Class Initialized
INFO - 2017-12-28 07:21:14 --> Model Class Initialized
INFO - 2017-12-28 07:21:14 --> Model Class Initialized
DEBUG - 2017-12-28 07:21:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 07:21:14 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 07:21:14 --> Final output sent to browser
DEBUG - 2017-12-28 07:21:14 --> Total execution time: 0.0745
INFO - 2017-12-28 07:21:14 --> Config Class Initialized
INFO - 2017-12-28 07:21:14 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:21:14 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:21:14 --> Utf8 Class Initialized
INFO - 2017-12-28 07:21:14 --> URI Class Initialized
INFO - 2017-12-28 07:21:14 --> Router Class Initialized
INFO - 2017-12-28 07:21:14 --> Output Class Initialized
INFO - 2017-12-28 07:21:14 --> Security Class Initialized
DEBUG - 2017-12-28 07:21:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:21:14 --> Input Class Initialized
INFO - 2017-12-28 07:21:14 --> Language Class Initialized
INFO - 2017-12-28 07:21:14 --> Loader Class Initialized
INFO - 2017-12-28 07:21:14 --> Helper loaded: url_helper
INFO - 2017-12-28 07:21:14 --> Helper loaded: form_helper
INFO - 2017-12-28 07:21:14 --> Database Driver Class Initialized
DEBUG - 2017-12-28 07:21:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 07:21:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 07:21:14 --> Form Validation Class Initialized
INFO - 2017-12-28 07:21:14 --> Model Class Initialized
INFO - 2017-12-28 07:21:14 --> Controller Class Initialized
INFO - 2017-12-28 07:21:14 --> Model Class Initialized
INFO - 2017-12-28 07:21:14 --> Model Class Initialized
INFO - 2017-12-28 07:21:14 --> Model Class Initialized
INFO - 2017-12-28 07:21:14 --> Model Class Initialized
DEBUG - 2017-12-28 07:21:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 07:22:05 --> Config Class Initialized
INFO - 2017-12-28 07:22:05 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:22:05 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:22:05 --> Utf8 Class Initialized
INFO - 2017-12-28 07:22:05 --> URI Class Initialized
INFO - 2017-12-28 07:22:05 --> Router Class Initialized
INFO - 2017-12-28 07:22:05 --> Output Class Initialized
INFO - 2017-12-28 07:22:05 --> Security Class Initialized
DEBUG - 2017-12-28 07:22:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:22:05 --> Input Class Initialized
INFO - 2017-12-28 07:22:05 --> Language Class Initialized
INFO - 2017-12-28 07:22:05 --> Loader Class Initialized
INFO - 2017-12-28 07:22:05 --> Helper loaded: url_helper
INFO - 2017-12-28 07:22:05 --> Helper loaded: form_helper
INFO - 2017-12-28 07:22:05 --> Database Driver Class Initialized
DEBUG - 2017-12-28 07:22:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 07:22:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 07:22:05 --> Form Validation Class Initialized
INFO - 2017-12-28 07:22:05 --> Model Class Initialized
INFO - 2017-12-28 07:22:05 --> Controller Class Initialized
INFO - 2017-12-28 07:22:05 --> Model Class Initialized
INFO - 2017-12-28 07:22:05 --> Model Class Initialized
INFO - 2017-12-28 07:22:05 --> Model Class Initialized
INFO - 2017-12-28 07:22:05 --> Model Class Initialized
DEBUG - 2017-12-28 07:22:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 07:22:05 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 07:22:05 --> Final output sent to browser
DEBUG - 2017-12-28 07:22:05 --> Total execution time: 0.0636
INFO - 2017-12-28 07:22:05 --> Config Class Initialized
INFO - 2017-12-28 07:22:05 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:22:05 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:22:05 --> Utf8 Class Initialized
INFO - 2017-12-28 07:22:05 --> URI Class Initialized
INFO - 2017-12-28 07:22:05 --> Router Class Initialized
INFO - 2017-12-28 07:22:05 --> Output Class Initialized
INFO - 2017-12-28 07:22:05 --> Security Class Initialized
DEBUG - 2017-12-28 07:22:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:22:05 --> Input Class Initialized
INFO - 2017-12-28 07:22:05 --> Language Class Initialized
INFO - 2017-12-28 07:22:05 --> Loader Class Initialized
INFO - 2017-12-28 07:22:05 --> Helper loaded: url_helper
INFO - 2017-12-28 07:22:05 --> Helper loaded: form_helper
INFO - 2017-12-28 07:22:05 --> Database Driver Class Initialized
DEBUG - 2017-12-28 07:22:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 07:22:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 07:22:05 --> Form Validation Class Initialized
INFO - 2017-12-28 07:22:05 --> Model Class Initialized
INFO - 2017-12-28 07:22:05 --> Controller Class Initialized
INFO - 2017-12-28 07:22:05 --> Model Class Initialized
INFO - 2017-12-28 07:22:05 --> Model Class Initialized
INFO - 2017-12-28 07:22:05 --> Model Class Initialized
INFO - 2017-12-28 07:22:05 --> Model Class Initialized
DEBUG - 2017-12-28 07:22:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 07:22:20 --> Config Class Initialized
INFO - 2017-12-28 07:22:20 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:22:20 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:22:20 --> Utf8 Class Initialized
INFO - 2017-12-28 07:22:20 --> URI Class Initialized
INFO - 2017-12-28 07:22:20 --> Router Class Initialized
INFO - 2017-12-28 07:22:20 --> Output Class Initialized
INFO - 2017-12-28 07:22:20 --> Security Class Initialized
DEBUG - 2017-12-28 07:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:22:20 --> Input Class Initialized
INFO - 2017-12-28 07:22:20 --> Language Class Initialized
INFO - 2017-12-28 07:22:20 --> Loader Class Initialized
INFO - 2017-12-28 07:22:20 --> Helper loaded: url_helper
INFO - 2017-12-28 07:22:20 --> Helper loaded: form_helper
INFO - 2017-12-28 07:22:20 --> Database Driver Class Initialized
DEBUG - 2017-12-28 07:22:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 07:22:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 07:22:20 --> Form Validation Class Initialized
INFO - 2017-12-28 07:22:20 --> Model Class Initialized
INFO - 2017-12-28 07:22:20 --> Controller Class Initialized
INFO - 2017-12-28 07:22:20 --> Model Class Initialized
INFO - 2017-12-28 07:22:20 --> Model Class Initialized
INFO - 2017-12-28 07:22:20 --> Model Class Initialized
INFO - 2017-12-28 07:22:20 --> Model Class Initialized
DEBUG - 2017-12-28 07:22:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 07:22:20 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 07:22:20 --> Final output sent to browser
DEBUG - 2017-12-28 07:22:20 --> Total execution time: 0.0607
INFO - 2017-12-28 07:22:20 --> Config Class Initialized
INFO - 2017-12-28 07:22:20 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:22:20 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:22:20 --> Utf8 Class Initialized
INFO - 2017-12-28 07:22:20 --> URI Class Initialized
INFO - 2017-12-28 07:22:20 --> Router Class Initialized
INFO - 2017-12-28 07:22:20 --> Output Class Initialized
INFO - 2017-12-28 07:22:20 --> Security Class Initialized
DEBUG - 2017-12-28 07:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:22:20 --> Input Class Initialized
INFO - 2017-12-28 07:22:20 --> Language Class Initialized
INFO - 2017-12-28 07:22:20 --> Loader Class Initialized
INFO - 2017-12-28 07:22:20 --> Helper loaded: url_helper
INFO - 2017-12-28 07:22:20 --> Helper loaded: form_helper
INFO - 2017-12-28 07:22:20 --> Database Driver Class Initialized
DEBUG - 2017-12-28 07:22:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 07:22:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 07:22:20 --> Form Validation Class Initialized
INFO - 2017-12-28 07:22:20 --> Model Class Initialized
INFO - 2017-12-28 07:22:20 --> Controller Class Initialized
INFO - 2017-12-28 07:22:20 --> Model Class Initialized
INFO - 2017-12-28 07:22:20 --> Model Class Initialized
INFO - 2017-12-28 07:22:20 --> Model Class Initialized
INFO - 2017-12-28 07:22:20 --> Model Class Initialized
DEBUG - 2017-12-28 07:22:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 07:22:21 --> Config Class Initialized
INFO - 2017-12-28 07:22:21 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:22:21 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:22:21 --> Utf8 Class Initialized
INFO - 2017-12-28 07:22:21 --> URI Class Initialized
INFO - 2017-12-28 07:22:21 --> Router Class Initialized
INFO - 2017-12-28 07:22:21 --> Output Class Initialized
INFO - 2017-12-28 07:22:21 --> Security Class Initialized
DEBUG - 2017-12-28 07:22:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:22:21 --> Input Class Initialized
INFO - 2017-12-28 07:22:21 --> Language Class Initialized
INFO - 2017-12-28 07:22:21 --> Loader Class Initialized
INFO - 2017-12-28 07:22:21 --> Helper loaded: url_helper
INFO - 2017-12-28 07:22:21 --> Helper loaded: form_helper
INFO - 2017-12-28 07:22:21 --> Database Driver Class Initialized
DEBUG - 2017-12-28 07:22:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 07:22:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 07:22:21 --> Form Validation Class Initialized
INFO - 2017-12-28 07:22:21 --> Model Class Initialized
INFO - 2017-12-28 07:22:21 --> Controller Class Initialized
INFO - 2017-12-28 07:22:21 --> Model Class Initialized
INFO - 2017-12-28 07:22:21 --> Model Class Initialized
INFO - 2017-12-28 07:22:21 --> Model Class Initialized
INFO - 2017-12-28 07:22:21 --> Model Class Initialized
DEBUG - 2017-12-28 07:22:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 07:22:21 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 07:22:21 --> Final output sent to browser
DEBUG - 2017-12-28 07:22:21 --> Total execution time: 0.0537
INFO - 2017-12-28 07:22:51 --> Config Class Initialized
INFO - 2017-12-28 07:22:51 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:22:51 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:22:51 --> Utf8 Class Initialized
INFO - 2017-12-28 07:22:51 --> URI Class Initialized
INFO - 2017-12-28 07:22:51 --> Router Class Initialized
INFO - 2017-12-28 07:22:51 --> Output Class Initialized
INFO - 2017-12-28 07:22:51 --> Security Class Initialized
DEBUG - 2017-12-28 07:22:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:22:51 --> Input Class Initialized
INFO - 2017-12-28 07:22:51 --> Language Class Initialized
INFO - 2017-12-28 07:22:51 --> Loader Class Initialized
INFO - 2017-12-28 07:22:51 --> Helper loaded: url_helper
INFO - 2017-12-28 07:22:51 --> Helper loaded: form_helper
INFO - 2017-12-28 07:22:51 --> Database Driver Class Initialized
DEBUG - 2017-12-28 07:22:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 07:22:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 07:22:51 --> Form Validation Class Initialized
INFO - 2017-12-28 07:22:51 --> Model Class Initialized
INFO - 2017-12-28 07:22:51 --> Controller Class Initialized
INFO - 2017-12-28 07:22:51 --> Model Class Initialized
INFO - 2017-12-28 07:22:51 --> Model Class Initialized
INFO - 2017-12-28 07:22:51 --> Model Class Initialized
INFO - 2017-12-28 07:22:51 --> Model Class Initialized
DEBUG - 2017-12-28 07:22:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 07:22:51 --> Config Class Initialized
INFO - 2017-12-28 07:22:51 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:22:51 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:22:51 --> Utf8 Class Initialized
INFO - 2017-12-28 07:22:51 --> URI Class Initialized
INFO - 2017-12-28 07:22:51 --> Router Class Initialized
INFO - 2017-12-28 07:22:51 --> Output Class Initialized
INFO - 2017-12-28 07:22:51 --> Security Class Initialized
DEBUG - 2017-12-28 07:22:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:22:51 --> Input Class Initialized
INFO - 2017-12-28 07:22:51 --> Language Class Initialized
INFO - 2017-12-28 07:22:51 --> Loader Class Initialized
INFO - 2017-12-28 07:22:51 --> Helper loaded: url_helper
INFO - 2017-12-28 07:22:51 --> Helper loaded: form_helper
INFO - 2017-12-28 07:22:51 --> Database Driver Class Initialized
DEBUG - 2017-12-28 07:22:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 07:22:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 07:22:51 --> Form Validation Class Initialized
INFO - 2017-12-28 07:22:51 --> Model Class Initialized
INFO - 2017-12-28 07:22:51 --> Controller Class Initialized
INFO - 2017-12-28 07:22:51 --> Model Class Initialized
INFO - 2017-12-28 07:22:51 --> Model Class Initialized
INFO - 2017-12-28 07:22:51 --> Model Class Initialized
INFO - 2017-12-28 07:22:51 --> Model Class Initialized
DEBUG - 2017-12-28 07:22:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 07:22:51 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 07:22:51 --> Final output sent to browser
DEBUG - 2017-12-28 07:22:51 --> Total execution time: 0.0616
INFO - 2017-12-28 07:22:52 --> Config Class Initialized
INFO - 2017-12-28 07:22:52 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:22:52 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:22:52 --> Utf8 Class Initialized
INFO - 2017-12-28 07:22:52 --> URI Class Initialized
INFO - 2017-12-28 07:22:52 --> Router Class Initialized
INFO - 2017-12-28 07:22:52 --> Output Class Initialized
INFO - 2017-12-28 07:22:52 --> Security Class Initialized
DEBUG - 2017-12-28 07:22:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:22:52 --> Input Class Initialized
INFO - 2017-12-28 07:22:52 --> Language Class Initialized
INFO - 2017-12-28 07:22:52 --> Loader Class Initialized
INFO - 2017-12-28 07:22:52 --> Helper loaded: url_helper
INFO - 2017-12-28 07:22:52 --> Helper loaded: form_helper
INFO - 2017-12-28 07:22:52 --> Database Driver Class Initialized
DEBUG - 2017-12-28 07:22:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 07:22:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 07:22:52 --> Form Validation Class Initialized
INFO - 2017-12-28 07:22:52 --> Model Class Initialized
INFO - 2017-12-28 07:22:52 --> Controller Class Initialized
INFO - 2017-12-28 07:22:52 --> Model Class Initialized
INFO - 2017-12-28 07:22:52 --> Model Class Initialized
INFO - 2017-12-28 07:22:52 --> Model Class Initialized
INFO - 2017-12-28 07:22:52 --> Model Class Initialized
DEBUG - 2017-12-28 07:22:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 07:23:45 --> Config Class Initialized
INFO - 2017-12-28 07:23:45 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:23:45 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:23:45 --> Utf8 Class Initialized
INFO - 2017-12-28 07:23:45 --> URI Class Initialized
INFO - 2017-12-28 07:23:45 --> Router Class Initialized
INFO - 2017-12-28 07:23:45 --> Output Class Initialized
INFO - 2017-12-28 07:23:45 --> Security Class Initialized
DEBUG - 2017-12-28 07:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:23:45 --> Input Class Initialized
INFO - 2017-12-28 07:23:45 --> Language Class Initialized
INFO - 2017-12-28 07:23:45 --> Loader Class Initialized
INFO - 2017-12-28 07:23:45 --> Helper loaded: url_helper
INFO - 2017-12-28 07:23:45 --> Helper loaded: form_helper
INFO - 2017-12-28 07:23:45 --> Database Driver Class Initialized
DEBUG - 2017-12-28 07:23:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 07:23:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 07:23:45 --> Form Validation Class Initialized
INFO - 2017-12-28 07:23:45 --> Model Class Initialized
INFO - 2017-12-28 07:23:45 --> Controller Class Initialized
INFO - 2017-12-28 07:23:45 --> Model Class Initialized
INFO - 2017-12-28 07:23:45 --> Model Class Initialized
INFO - 2017-12-28 07:23:45 --> Model Class Initialized
INFO - 2017-12-28 07:23:45 --> Model Class Initialized
DEBUG - 2017-12-28 07:23:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 07:23:45 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 07:23:45 --> Final output sent to browser
DEBUG - 2017-12-28 07:23:45 --> Total execution time: 0.0505
INFO - 2017-12-28 07:23:45 --> Config Class Initialized
INFO - 2017-12-28 07:23:45 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:23:45 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:23:45 --> Utf8 Class Initialized
INFO - 2017-12-28 07:23:45 --> URI Class Initialized
INFO - 2017-12-28 07:23:45 --> Router Class Initialized
INFO - 2017-12-28 07:23:45 --> Output Class Initialized
INFO - 2017-12-28 07:23:45 --> Security Class Initialized
DEBUG - 2017-12-28 07:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:23:45 --> Input Class Initialized
INFO - 2017-12-28 07:23:45 --> Language Class Initialized
INFO - 2017-12-28 07:23:45 --> Loader Class Initialized
INFO - 2017-12-28 07:23:45 --> Helper loaded: url_helper
INFO - 2017-12-28 07:23:45 --> Helper loaded: form_helper
INFO - 2017-12-28 07:23:45 --> Database Driver Class Initialized
DEBUG - 2017-12-28 07:23:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 07:23:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 07:23:45 --> Form Validation Class Initialized
INFO - 2017-12-28 07:23:45 --> Model Class Initialized
INFO - 2017-12-28 07:23:45 --> Controller Class Initialized
INFO - 2017-12-28 07:23:45 --> Model Class Initialized
INFO - 2017-12-28 07:23:45 --> Model Class Initialized
INFO - 2017-12-28 07:23:45 --> Model Class Initialized
INFO - 2017-12-28 07:23:45 --> Model Class Initialized
DEBUG - 2017-12-28 07:23:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 07:24:00 --> Config Class Initialized
INFO - 2017-12-28 07:24:00 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:24:00 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:24:00 --> Utf8 Class Initialized
INFO - 2017-12-28 07:24:00 --> URI Class Initialized
INFO - 2017-12-28 07:24:00 --> Router Class Initialized
INFO - 2017-12-28 07:24:00 --> Output Class Initialized
INFO - 2017-12-28 07:24:00 --> Security Class Initialized
DEBUG - 2017-12-28 07:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:24:00 --> Input Class Initialized
INFO - 2017-12-28 07:24:00 --> Language Class Initialized
INFO - 2017-12-28 07:24:00 --> Loader Class Initialized
INFO - 2017-12-28 07:24:00 --> Helper loaded: url_helper
INFO - 2017-12-28 07:24:00 --> Helper loaded: form_helper
INFO - 2017-12-28 07:24:00 --> Database Driver Class Initialized
DEBUG - 2017-12-28 07:24:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 07:24:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 07:24:00 --> Form Validation Class Initialized
INFO - 2017-12-28 07:24:00 --> Model Class Initialized
INFO - 2017-12-28 07:24:00 --> Controller Class Initialized
INFO - 2017-12-28 07:24:00 --> Model Class Initialized
INFO - 2017-12-28 07:24:00 --> Model Class Initialized
INFO - 2017-12-28 07:24:00 --> Model Class Initialized
INFO - 2017-12-28 07:24:00 --> Model Class Initialized
DEBUG - 2017-12-28 07:24:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 07:24:00 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 07:24:00 --> Final output sent to browser
DEBUG - 2017-12-28 07:24:00 --> Total execution time: 0.0640
INFO - 2017-12-28 07:24:00 --> Config Class Initialized
INFO - 2017-12-28 07:24:00 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:24:00 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:24:00 --> Utf8 Class Initialized
INFO - 2017-12-28 07:24:00 --> URI Class Initialized
INFO - 2017-12-28 07:24:00 --> Router Class Initialized
INFO - 2017-12-28 07:24:00 --> Output Class Initialized
INFO - 2017-12-28 07:24:00 --> Security Class Initialized
DEBUG - 2017-12-28 07:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:24:00 --> Input Class Initialized
INFO - 2017-12-28 07:24:00 --> Language Class Initialized
INFO - 2017-12-28 07:24:00 --> Loader Class Initialized
INFO - 2017-12-28 07:24:00 --> Helper loaded: url_helper
INFO - 2017-12-28 07:24:00 --> Helper loaded: form_helper
INFO - 2017-12-28 07:24:00 --> Database Driver Class Initialized
DEBUG - 2017-12-28 07:24:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 07:24:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 07:24:00 --> Form Validation Class Initialized
INFO - 2017-12-28 07:24:00 --> Model Class Initialized
INFO - 2017-12-28 07:24:00 --> Controller Class Initialized
INFO - 2017-12-28 07:24:00 --> Model Class Initialized
INFO - 2017-12-28 07:24:00 --> Model Class Initialized
INFO - 2017-12-28 07:24:00 --> Model Class Initialized
INFO - 2017-12-28 07:24:00 --> Model Class Initialized
DEBUG - 2017-12-28 07:24:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 07:24:02 --> Config Class Initialized
INFO - 2017-12-28 07:24:02 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:24:02 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:24:02 --> Utf8 Class Initialized
INFO - 2017-12-28 07:24:02 --> URI Class Initialized
INFO - 2017-12-28 07:24:02 --> Router Class Initialized
INFO - 2017-12-28 07:24:02 --> Output Class Initialized
INFO - 2017-12-28 07:24:02 --> Security Class Initialized
DEBUG - 2017-12-28 07:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:24:02 --> Input Class Initialized
INFO - 2017-12-28 07:24:02 --> Language Class Initialized
INFO - 2017-12-28 07:24:02 --> Loader Class Initialized
INFO - 2017-12-28 07:24:02 --> Helper loaded: url_helper
INFO - 2017-12-28 07:24:02 --> Helper loaded: form_helper
INFO - 2017-12-28 07:24:02 --> Database Driver Class Initialized
DEBUG - 2017-12-28 07:24:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 07:24:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 07:24:02 --> Form Validation Class Initialized
INFO - 2017-12-28 07:24:02 --> Model Class Initialized
INFO - 2017-12-28 07:24:02 --> Controller Class Initialized
INFO - 2017-12-28 07:24:02 --> Model Class Initialized
INFO - 2017-12-28 07:24:02 --> Model Class Initialized
INFO - 2017-12-28 07:24:02 --> Model Class Initialized
INFO - 2017-12-28 07:24:02 --> Model Class Initialized
DEBUG - 2017-12-28 07:24:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 07:24:02 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 07:24:02 --> Final output sent to browser
DEBUG - 2017-12-28 07:24:02 --> Total execution time: 0.0994
INFO - 2017-12-28 07:24:03 --> Config Class Initialized
INFO - 2017-12-28 07:24:03 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:24:03 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:24:03 --> Utf8 Class Initialized
INFO - 2017-12-28 07:24:03 --> URI Class Initialized
INFO - 2017-12-28 07:24:03 --> Router Class Initialized
INFO - 2017-12-28 07:24:03 --> Output Class Initialized
INFO - 2017-12-28 07:24:03 --> Security Class Initialized
DEBUG - 2017-12-28 07:24:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:24:03 --> Input Class Initialized
INFO - 2017-12-28 07:24:03 --> Language Class Initialized
INFO - 2017-12-28 07:24:03 --> Loader Class Initialized
INFO - 2017-12-28 07:24:03 --> Helper loaded: url_helper
INFO - 2017-12-28 07:24:03 --> Helper loaded: form_helper
INFO - 2017-12-28 07:24:03 --> Database Driver Class Initialized
DEBUG - 2017-12-28 07:24:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 07:24:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 07:24:03 --> Form Validation Class Initialized
INFO - 2017-12-28 07:24:03 --> Model Class Initialized
INFO - 2017-12-28 07:24:03 --> Controller Class Initialized
INFO - 2017-12-28 07:24:03 --> Model Class Initialized
INFO - 2017-12-28 07:24:03 --> Model Class Initialized
INFO - 2017-12-28 07:24:03 --> Model Class Initialized
INFO - 2017-12-28 07:24:03 --> Model Class Initialized
DEBUG - 2017-12-28 07:24:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 07:24:05 --> Config Class Initialized
INFO - 2017-12-28 07:24:05 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:24:05 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:24:05 --> Utf8 Class Initialized
INFO - 2017-12-28 07:24:05 --> URI Class Initialized
INFO - 2017-12-28 07:24:05 --> Router Class Initialized
INFO - 2017-12-28 07:24:05 --> Output Class Initialized
INFO - 2017-12-28 07:24:05 --> Security Class Initialized
DEBUG - 2017-12-28 07:24:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:24:05 --> Input Class Initialized
INFO - 2017-12-28 07:24:05 --> Language Class Initialized
INFO - 2017-12-28 07:24:05 --> Loader Class Initialized
INFO - 2017-12-28 07:24:05 --> Helper loaded: url_helper
INFO - 2017-12-28 07:24:05 --> Helper loaded: form_helper
INFO - 2017-12-28 07:24:05 --> Database Driver Class Initialized
DEBUG - 2017-12-28 07:24:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 07:24:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 07:24:05 --> Form Validation Class Initialized
INFO - 2017-12-28 07:24:05 --> Model Class Initialized
INFO - 2017-12-28 07:24:05 --> Controller Class Initialized
INFO - 2017-12-28 07:24:05 --> Model Class Initialized
INFO - 2017-12-28 07:24:05 --> Model Class Initialized
INFO - 2017-12-28 07:24:05 --> Model Class Initialized
INFO - 2017-12-28 07:24:05 --> Model Class Initialized
DEBUG - 2017-12-28 07:24:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 07:24:05 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 07:24:05 --> Final output sent to browser
DEBUG - 2017-12-28 07:24:05 --> Total execution time: 0.0598
INFO - 2017-12-28 07:24:05 --> Config Class Initialized
INFO - 2017-12-28 07:24:05 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:24:05 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:24:05 --> Utf8 Class Initialized
INFO - 2017-12-28 07:24:05 --> URI Class Initialized
INFO - 2017-12-28 07:24:05 --> Router Class Initialized
INFO - 2017-12-28 07:24:05 --> Output Class Initialized
INFO - 2017-12-28 07:24:05 --> Security Class Initialized
DEBUG - 2017-12-28 07:24:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:24:05 --> Input Class Initialized
INFO - 2017-12-28 07:24:05 --> Language Class Initialized
INFO - 2017-12-28 07:24:05 --> Loader Class Initialized
INFO - 2017-12-28 07:24:05 --> Helper loaded: url_helper
INFO - 2017-12-28 07:24:05 --> Helper loaded: form_helper
INFO - 2017-12-28 07:24:05 --> Database Driver Class Initialized
DEBUG - 2017-12-28 07:24:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 07:24:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 07:24:05 --> Form Validation Class Initialized
INFO - 2017-12-28 07:24:05 --> Model Class Initialized
INFO - 2017-12-28 07:24:05 --> Controller Class Initialized
INFO - 2017-12-28 07:24:05 --> Model Class Initialized
INFO - 2017-12-28 07:24:05 --> Model Class Initialized
INFO - 2017-12-28 07:24:05 --> Model Class Initialized
INFO - 2017-12-28 07:24:05 --> Model Class Initialized
DEBUG - 2017-12-28 07:24:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 07:24:12 --> Config Class Initialized
INFO - 2017-12-28 07:24:12 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:24:12 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:24:12 --> Utf8 Class Initialized
INFO - 2017-12-28 07:24:12 --> URI Class Initialized
INFO - 2017-12-28 07:24:12 --> Router Class Initialized
INFO - 2017-12-28 07:24:12 --> Output Class Initialized
INFO - 2017-12-28 07:24:12 --> Security Class Initialized
DEBUG - 2017-12-28 07:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:24:12 --> Input Class Initialized
INFO - 2017-12-28 07:24:12 --> Language Class Initialized
INFO - 2017-12-28 07:24:12 --> Loader Class Initialized
INFO - 2017-12-28 07:24:12 --> Helper loaded: url_helper
INFO - 2017-12-28 07:24:12 --> Helper loaded: form_helper
INFO - 2017-12-28 07:24:12 --> Database Driver Class Initialized
DEBUG - 2017-12-28 07:24:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 07:24:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 07:24:12 --> Form Validation Class Initialized
INFO - 2017-12-28 07:24:12 --> Model Class Initialized
INFO - 2017-12-28 07:24:12 --> Controller Class Initialized
INFO - 2017-12-28 07:24:12 --> Model Class Initialized
INFO - 2017-12-28 07:24:12 --> Model Class Initialized
INFO - 2017-12-28 07:24:12 --> Model Class Initialized
INFO - 2017-12-28 07:24:12 --> Model Class Initialized
DEBUG - 2017-12-28 07:24:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 07:24:12 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 07:24:12 --> Final output sent to browser
DEBUG - 2017-12-28 07:24:12 --> Total execution time: 0.0499
INFO - 2017-12-28 07:24:13 --> Config Class Initialized
INFO - 2017-12-28 07:24:13 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:24:13 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:24:13 --> Utf8 Class Initialized
INFO - 2017-12-28 07:24:13 --> URI Class Initialized
INFO - 2017-12-28 07:24:13 --> Router Class Initialized
INFO - 2017-12-28 07:24:13 --> Output Class Initialized
INFO - 2017-12-28 07:24:13 --> Security Class Initialized
DEBUG - 2017-12-28 07:24:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:24:13 --> Input Class Initialized
INFO - 2017-12-28 07:24:13 --> Language Class Initialized
INFO - 2017-12-28 07:24:13 --> Loader Class Initialized
INFO - 2017-12-28 07:24:13 --> Helper loaded: url_helper
INFO - 2017-12-28 07:24:13 --> Helper loaded: form_helper
INFO - 2017-12-28 07:24:13 --> Database Driver Class Initialized
DEBUG - 2017-12-28 07:24:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 07:24:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 07:24:13 --> Form Validation Class Initialized
INFO - 2017-12-28 07:24:13 --> Model Class Initialized
INFO - 2017-12-28 07:24:13 --> Controller Class Initialized
INFO - 2017-12-28 07:24:13 --> Model Class Initialized
INFO - 2017-12-28 07:24:13 --> Model Class Initialized
INFO - 2017-12-28 07:24:13 --> Model Class Initialized
INFO - 2017-12-28 07:24:13 --> Model Class Initialized
DEBUG - 2017-12-28 07:24:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 07:24:16 --> Config Class Initialized
INFO - 2017-12-28 07:24:16 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:24:16 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:24:16 --> Utf8 Class Initialized
INFO - 2017-12-28 07:24:16 --> URI Class Initialized
INFO - 2017-12-28 07:24:16 --> Router Class Initialized
INFO - 2017-12-28 07:24:16 --> Output Class Initialized
INFO - 2017-12-28 07:24:16 --> Security Class Initialized
DEBUG - 2017-12-28 07:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:24:16 --> Input Class Initialized
INFO - 2017-12-28 07:24:16 --> Language Class Initialized
INFO - 2017-12-28 07:24:16 --> Loader Class Initialized
INFO - 2017-12-28 07:24:16 --> Helper loaded: url_helper
INFO - 2017-12-28 07:24:16 --> Helper loaded: form_helper
INFO - 2017-12-28 07:24:16 --> Database Driver Class Initialized
DEBUG - 2017-12-28 07:24:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 07:24:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 07:24:16 --> Form Validation Class Initialized
INFO - 2017-12-28 07:24:16 --> Model Class Initialized
INFO - 2017-12-28 07:24:16 --> Controller Class Initialized
INFO - 2017-12-28 07:24:16 --> Model Class Initialized
INFO - 2017-12-28 07:24:16 --> Model Class Initialized
INFO - 2017-12-28 07:24:16 --> Model Class Initialized
INFO - 2017-12-28 07:24:16 --> Model Class Initialized
DEBUG - 2017-12-28 07:24:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 07:24:16 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 07:24:16 --> Final output sent to browser
DEBUG - 2017-12-28 07:24:16 --> Total execution time: 0.0611
INFO - 2017-12-28 07:24:16 --> Config Class Initialized
INFO - 2017-12-28 07:24:16 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:24:16 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:24:16 --> Utf8 Class Initialized
INFO - 2017-12-28 07:24:16 --> URI Class Initialized
INFO - 2017-12-28 07:24:16 --> Router Class Initialized
INFO - 2017-12-28 07:24:16 --> Output Class Initialized
INFO - 2017-12-28 07:24:16 --> Security Class Initialized
DEBUG - 2017-12-28 07:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:24:16 --> Input Class Initialized
INFO - 2017-12-28 07:24:16 --> Language Class Initialized
INFO - 2017-12-28 07:24:16 --> Loader Class Initialized
INFO - 2017-12-28 07:24:16 --> Helper loaded: url_helper
INFO - 2017-12-28 07:24:16 --> Helper loaded: form_helper
INFO - 2017-12-28 07:24:16 --> Database Driver Class Initialized
DEBUG - 2017-12-28 07:24:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 07:24:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 07:24:16 --> Form Validation Class Initialized
INFO - 2017-12-28 07:24:16 --> Model Class Initialized
INFO - 2017-12-28 07:24:16 --> Controller Class Initialized
INFO - 2017-12-28 07:24:16 --> Model Class Initialized
INFO - 2017-12-28 07:24:16 --> Model Class Initialized
INFO - 2017-12-28 07:24:16 --> Model Class Initialized
INFO - 2017-12-28 07:24:16 --> Model Class Initialized
DEBUG - 2017-12-28 07:24:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 07:25:05 --> Config Class Initialized
INFO - 2017-12-28 07:25:05 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:25:05 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:25:05 --> Utf8 Class Initialized
INFO - 2017-12-28 07:25:05 --> URI Class Initialized
INFO - 2017-12-28 07:25:05 --> Router Class Initialized
INFO - 2017-12-28 07:25:05 --> Output Class Initialized
INFO - 2017-12-28 07:25:05 --> Security Class Initialized
DEBUG - 2017-12-28 07:25:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:25:05 --> Input Class Initialized
INFO - 2017-12-28 07:25:05 --> Language Class Initialized
INFO - 2017-12-28 07:25:05 --> Loader Class Initialized
INFO - 2017-12-28 07:25:05 --> Helper loaded: url_helper
INFO - 2017-12-28 07:25:05 --> Helper loaded: form_helper
INFO - 2017-12-28 07:25:05 --> Database Driver Class Initialized
DEBUG - 2017-12-28 07:25:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 07:25:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 07:25:05 --> Form Validation Class Initialized
INFO - 2017-12-28 07:25:05 --> Model Class Initialized
INFO - 2017-12-28 07:25:05 --> Controller Class Initialized
INFO - 2017-12-28 07:25:05 --> Model Class Initialized
INFO - 2017-12-28 07:25:05 --> Model Class Initialized
INFO - 2017-12-28 07:25:05 --> Model Class Initialized
INFO - 2017-12-28 07:25:05 --> Model Class Initialized
DEBUG - 2017-12-28 07:25:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 07:25:05 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 07:25:05 --> Final output sent to browser
DEBUG - 2017-12-28 07:25:05 --> Total execution time: 0.0521
INFO - 2017-12-28 07:25:06 --> Config Class Initialized
INFO - 2017-12-28 07:25:06 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:25:06 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:25:06 --> Utf8 Class Initialized
INFO - 2017-12-28 07:25:06 --> URI Class Initialized
INFO - 2017-12-28 07:25:06 --> Router Class Initialized
INFO - 2017-12-28 07:25:06 --> Output Class Initialized
INFO - 2017-12-28 07:25:06 --> Security Class Initialized
DEBUG - 2017-12-28 07:25:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:25:06 --> Input Class Initialized
INFO - 2017-12-28 07:25:06 --> Language Class Initialized
INFO - 2017-12-28 07:25:06 --> Loader Class Initialized
INFO - 2017-12-28 07:25:06 --> Helper loaded: url_helper
INFO - 2017-12-28 07:25:06 --> Helper loaded: form_helper
INFO - 2017-12-28 07:25:06 --> Database Driver Class Initialized
DEBUG - 2017-12-28 07:25:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 07:25:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 07:25:06 --> Form Validation Class Initialized
INFO - 2017-12-28 07:25:06 --> Model Class Initialized
INFO - 2017-12-28 07:25:06 --> Controller Class Initialized
INFO - 2017-12-28 07:25:06 --> Model Class Initialized
INFO - 2017-12-28 07:25:06 --> Model Class Initialized
INFO - 2017-12-28 07:25:06 --> Model Class Initialized
INFO - 2017-12-28 07:25:06 --> Model Class Initialized
DEBUG - 2017-12-28 07:25:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 07:25:51 --> Config Class Initialized
INFO - 2017-12-28 07:25:51 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:25:51 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:25:51 --> Utf8 Class Initialized
INFO - 2017-12-28 07:25:51 --> URI Class Initialized
INFO - 2017-12-28 07:25:51 --> Router Class Initialized
INFO - 2017-12-28 07:25:51 --> Output Class Initialized
INFO - 2017-12-28 07:25:51 --> Security Class Initialized
DEBUG - 2017-12-28 07:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:25:51 --> Input Class Initialized
INFO - 2017-12-28 07:25:51 --> Language Class Initialized
INFO - 2017-12-28 07:25:52 --> Loader Class Initialized
INFO - 2017-12-28 07:25:52 --> Helper loaded: url_helper
INFO - 2017-12-28 07:25:52 --> Helper loaded: form_helper
INFO - 2017-12-28 07:25:52 --> Database Driver Class Initialized
DEBUG - 2017-12-28 07:25:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 07:25:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 07:25:52 --> Form Validation Class Initialized
INFO - 2017-12-28 07:25:52 --> Model Class Initialized
INFO - 2017-12-28 07:25:52 --> Controller Class Initialized
INFO - 2017-12-28 07:25:52 --> Model Class Initialized
INFO - 2017-12-28 07:25:52 --> Model Class Initialized
INFO - 2017-12-28 07:25:52 --> Model Class Initialized
INFO - 2017-12-28 07:25:52 --> Model Class Initialized
DEBUG - 2017-12-28 07:25:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 07:25:52 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 07:25:52 --> Final output sent to browser
DEBUG - 2017-12-28 07:25:52 --> Total execution time: 0.3366
INFO - 2017-12-28 07:25:53 --> Config Class Initialized
INFO - 2017-12-28 07:25:53 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:25:53 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:25:53 --> Utf8 Class Initialized
INFO - 2017-12-28 07:25:53 --> URI Class Initialized
INFO - 2017-12-28 07:25:53 --> Router Class Initialized
INFO - 2017-12-28 07:25:53 --> Output Class Initialized
INFO - 2017-12-28 07:25:53 --> Security Class Initialized
DEBUG - 2017-12-28 07:25:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:25:53 --> Input Class Initialized
INFO - 2017-12-28 07:25:53 --> Language Class Initialized
INFO - 2017-12-28 07:25:53 --> Loader Class Initialized
INFO - 2017-12-28 07:25:53 --> Helper loaded: url_helper
INFO - 2017-12-28 07:25:53 --> Helper loaded: form_helper
INFO - 2017-12-28 07:25:53 --> Database Driver Class Initialized
DEBUG - 2017-12-28 07:25:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 07:25:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 07:25:53 --> Form Validation Class Initialized
INFO - 2017-12-28 07:25:53 --> Model Class Initialized
INFO - 2017-12-28 07:25:53 --> Controller Class Initialized
INFO - 2017-12-28 07:25:53 --> Model Class Initialized
INFO - 2017-12-28 07:25:53 --> Model Class Initialized
INFO - 2017-12-28 07:25:53 --> Model Class Initialized
INFO - 2017-12-28 07:25:53 --> Model Class Initialized
DEBUG - 2017-12-28 07:25:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 07:25:53 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 07:25:53 --> Final output sent to browser
DEBUG - 2017-12-28 07:25:53 --> Total execution time: 0.0747
INFO - 2017-12-28 07:25:53 --> Config Class Initialized
INFO - 2017-12-28 07:25:53 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:25:53 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:25:53 --> Utf8 Class Initialized
INFO - 2017-12-28 07:25:53 --> URI Class Initialized
INFO - 2017-12-28 07:25:53 --> Router Class Initialized
INFO - 2017-12-28 07:25:53 --> Output Class Initialized
INFO - 2017-12-28 07:25:53 --> Security Class Initialized
DEBUG - 2017-12-28 07:25:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:25:53 --> Input Class Initialized
INFO - 2017-12-28 07:25:53 --> Language Class Initialized
INFO - 2017-12-28 07:25:53 --> Loader Class Initialized
INFO - 2017-12-28 07:25:53 --> Helper loaded: url_helper
INFO - 2017-12-28 07:25:53 --> Helper loaded: form_helper
INFO - 2017-12-28 07:25:53 --> Database Driver Class Initialized
DEBUG - 2017-12-28 07:25:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 07:25:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 07:25:53 --> Form Validation Class Initialized
INFO - 2017-12-28 07:25:53 --> Model Class Initialized
INFO - 2017-12-28 07:25:53 --> Controller Class Initialized
INFO - 2017-12-28 07:25:53 --> Model Class Initialized
INFO - 2017-12-28 07:25:53 --> Model Class Initialized
INFO - 2017-12-28 07:25:53 --> Model Class Initialized
INFO - 2017-12-28 07:25:53 --> Model Class Initialized
DEBUG - 2017-12-28 07:25:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 07:30:20 --> Config Class Initialized
INFO - 2017-12-28 07:30:20 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:30:20 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:30:20 --> Utf8 Class Initialized
INFO - 2017-12-28 07:30:20 --> URI Class Initialized
INFO - 2017-12-28 07:30:20 --> Router Class Initialized
INFO - 2017-12-28 07:30:20 --> Output Class Initialized
INFO - 2017-12-28 07:30:20 --> Security Class Initialized
DEBUG - 2017-12-28 07:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:30:20 --> Input Class Initialized
INFO - 2017-12-28 07:30:20 --> Language Class Initialized
INFO - 2017-12-28 07:30:20 --> Loader Class Initialized
INFO - 2017-12-28 07:30:20 --> Helper loaded: url_helper
INFO - 2017-12-28 07:30:20 --> Helper loaded: form_helper
INFO - 2017-12-28 07:30:20 --> Database Driver Class Initialized
DEBUG - 2017-12-28 07:30:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 07:30:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 07:30:20 --> Form Validation Class Initialized
INFO - 2017-12-28 07:30:20 --> Model Class Initialized
INFO - 2017-12-28 07:30:20 --> Controller Class Initialized
INFO - 2017-12-28 07:30:20 --> Model Class Initialized
INFO - 2017-12-28 07:30:20 --> Model Class Initialized
INFO - 2017-12-28 07:30:20 --> Model Class Initialized
INFO - 2017-12-28 07:30:20 --> Model Class Initialized
DEBUG - 2017-12-28 07:30:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 07:30:20 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 07:30:20 --> Final output sent to browser
DEBUG - 2017-12-28 07:30:20 --> Total execution time: 0.0759
INFO - 2017-12-28 07:30:20 --> Config Class Initialized
INFO - 2017-12-28 07:30:20 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:30:20 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:30:20 --> Utf8 Class Initialized
INFO - 2017-12-28 07:30:20 --> URI Class Initialized
INFO - 2017-12-28 07:30:20 --> Router Class Initialized
INFO - 2017-12-28 07:30:20 --> Output Class Initialized
INFO - 2017-12-28 07:30:20 --> Security Class Initialized
DEBUG - 2017-12-28 07:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:30:20 --> Input Class Initialized
INFO - 2017-12-28 07:30:20 --> Language Class Initialized
INFO - 2017-12-28 07:30:20 --> Loader Class Initialized
INFO - 2017-12-28 07:30:20 --> Helper loaded: url_helper
INFO - 2017-12-28 07:30:20 --> Helper loaded: form_helper
INFO - 2017-12-28 07:30:20 --> Database Driver Class Initialized
DEBUG - 2017-12-28 07:30:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 07:30:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 07:30:20 --> Form Validation Class Initialized
INFO - 2017-12-28 07:30:20 --> Model Class Initialized
INFO - 2017-12-28 07:30:20 --> Controller Class Initialized
INFO - 2017-12-28 07:30:20 --> Model Class Initialized
INFO - 2017-12-28 07:30:20 --> Model Class Initialized
INFO - 2017-12-28 07:30:20 --> Model Class Initialized
INFO - 2017-12-28 07:30:20 --> Model Class Initialized
DEBUG - 2017-12-28 07:30:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 07:33:22 --> Config Class Initialized
INFO - 2017-12-28 07:33:22 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:33:22 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:33:22 --> Utf8 Class Initialized
INFO - 2017-12-28 07:33:22 --> URI Class Initialized
INFO - 2017-12-28 07:33:22 --> Router Class Initialized
INFO - 2017-12-28 07:33:22 --> Output Class Initialized
INFO - 2017-12-28 07:33:22 --> Security Class Initialized
DEBUG - 2017-12-28 07:33:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:33:22 --> Input Class Initialized
INFO - 2017-12-28 07:33:22 --> Language Class Initialized
INFO - 2017-12-28 07:33:22 --> Loader Class Initialized
INFO - 2017-12-28 07:33:22 --> Helper loaded: url_helper
INFO - 2017-12-28 07:33:22 --> Helper loaded: form_helper
INFO - 2017-12-28 07:33:22 --> Database Driver Class Initialized
DEBUG - 2017-12-28 07:33:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 07:33:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 07:33:22 --> Form Validation Class Initialized
INFO - 2017-12-28 07:33:22 --> Model Class Initialized
INFO - 2017-12-28 07:33:22 --> Controller Class Initialized
INFO - 2017-12-28 07:33:22 --> Model Class Initialized
INFO - 2017-12-28 07:33:22 --> Model Class Initialized
INFO - 2017-12-28 07:33:22 --> Model Class Initialized
INFO - 2017-12-28 07:33:22 --> Model Class Initialized
DEBUG - 2017-12-28 07:33:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 07:33:22 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 07:33:22 --> Final output sent to browser
DEBUG - 2017-12-28 07:33:22 --> Total execution time: 0.0528
INFO - 2017-12-28 07:33:23 --> Config Class Initialized
INFO - 2017-12-28 07:33:23 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:33:23 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:33:23 --> Utf8 Class Initialized
INFO - 2017-12-28 07:33:23 --> URI Class Initialized
INFO - 2017-12-28 07:33:23 --> Router Class Initialized
INFO - 2017-12-28 07:33:23 --> Output Class Initialized
INFO - 2017-12-28 07:33:23 --> Security Class Initialized
DEBUG - 2017-12-28 07:33:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:33:23 --> Input Class Initialized
INFO - 2017-12-28 07:33:23 --> Language Class Initialized
INFO - 2017-12-28 07:33:23 --> Loader Class Initialized
INFO - 2017-12-28 07:33:23 --> Helper loaded: url_helper
INFO - 2017-12-28 07:33:23 --> Helper loaded: form_helper
INFO - 2017-12-28 07:33:23 --> Database Driver Class Initialized
DEBUG - 2017-12-28 07:33:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 07:33:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 07:33:23 --> Form Validation Class Initialized
INFO - 2017-12-28 07:33:23 --> Model Class Initialized
INFO - 2017-12-28 07:33:23 --> Controller Class Initialized
INFO - 2017-12-28 07:33:23 --> Model Class Initialized
INFO - 2017-12-28 07:33:23 --> Model Class Initialized
INFO - 2017-12-28 07:33:23 --> Model Class Initialized
INFO - 2017-12-28 07:33:23 --> Model Class Initialized
DEBUG - 2017-12-28 07:33:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 07:33:30 --> Config Class Initialized
INFO - 2017-12-28 07:33:30 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:33:30 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:33:30 --> Utf8 Class Initialized
INFO - 2017-12-28 07:33:30 --> URI Class Initialized
INFO - 2017-12-28 07:33:30 --> Router Class Initialized
INFO - 2017-12-28 07:33:30 --> Output Class Initialized
INFO - 2017-12-28 07:33:30 --> Security Class Initialized
INFO - 2017-12-28 07:33:30 --> Config Class Initialized
INFO - 2017-12-28 07:33:30 --> Config Class Initialized
INFO - 2017-12-28 07:33:30 --> Hooks Class Initialized
INFO - 2017-12-28 07:33:30 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:33:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:33:30 --> Input Class Initialized
INFO - 2017-12-28 07:33:30 --> Language Class Initialized
ERROR - 2017-12-28 07:33:30 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2017-12-28 07:33:30 --> UTF-8 Support Enabled
DEBUG - 2017-12-28 07:33:30 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:33:30 --> Utf8 Class Initialized
INFO - 2017-12-28 07:33:30 --> Utf8 Class Initialized
INFO - 2017-12-28 07:33:30 --> URI Class Initialized
INFO - 2017-12-28 07:33:30 --> URI Class Initialized
INFO - 2017-12-28 07:33:30 --> Router Class Initialized
INFO - 2017-12-28 07:33:30 --> Router Class Initialized
INFO - 2017-12-28 07:33:30 --> Output Class Initialized
INFO - 2017-12-28 07:33:30 --> Output Class Initialized
INFO - 2017-12-28 07:33:30 --> Security Class Initialized
INFO - 2017-12-28 07:33:30 --> Security Class Initialized
DEBUG - 2017-12-28 07:33:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-28 07:33:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:33:30 --> Input Class Initialized
INFO - 2017-12-28 07:33:30 --> Input Class Initialized
INFO - 2017-12-28 07:33:30 --> Language Class Initialized
INFO - 2017-12-28 07:33:30 --> Language Class Initialized
ERROR - 2017-12-28 07:33:30 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-28 07:33:30 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-28 07:34:06 --> Config Class Initialized
INFO - 2017-12-28 07:34:06 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:34:06 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:34:06 --> Utf8 Class Initialized
INFO - 2017-12-28 07:34:06 --> URI Class Initialized
INFO - 2017-12-28 07:34:06 --> Router Class Initialized
INFO - 2017-12-28 07:34:06 --> Output Class Initialized
INFO - 2017-12-28 07:34:06 --> Security Class Initialized
DEBUG - 2017-12-28 07:34:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:34:06 --> Input Class Initialized
INFO - 2017-12-28 07:34:06 --> Language Class Initialized
INFO - 2017-12-28 07:34:06 --> Loader Class Initialized
INFO - 2017-12-28 07:34:06 --> Helper loaded: url_helper
INFO - 2017-12-28 07:34:06 --> Helper loaded: form_helper
INFO - 2017-12-28 07:34:06 --> Database Driver Class Initialized
DEBUG - 2017-12-28 07:34:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 07:34:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 07:34:06 --> Form Validation Class Initialized
INFO - 2017-12-28 07:34:06 --> Model Class Initialized
INFO - 2017-12-28 07:34:06 --> Controller Class Initialized
INFO - 2017-12-28 07:34:06 --> Model Class Initialized
INFO - 2017-12-28 07:34:06 --> Model Class Initialized
INFO - 2017-12-28 07:34:06 --> Model Class Initialized
INFO - 2017-12-28 07:34:06 --> Model Class Initialized
DEBUG - 2017-12-28 07:34:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 07:34:06 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 07:34:06 --> Final output sent to browser
DEBUG - 2017-12-28 07:34:06 --> Total execution time: 0.0699
INFO - 2017-12-28 07:34:07 --> Config Class Initialized
INFO - 2017-12-28 07:34:07 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:34:07 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:34:07 --> Utf8 Class Initialized
INFO - 2017-12-28 07:34:07 --> URI Class Initialized
INFO - 2017-12-28 07:34:07 --> Router Class Initialized
INFO - 2017-12-28 07:34:07 --> Output Class Initialized
INFO - 2017-12-28 07:34:07 --> Security Class Initialized
DEBUG - 2017-12-28 07:34:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:34:07 --> Input Class Initialized
INFO - 2017-12-28 07:34:07 --> Language Class Initialized
ERROR - 2017-12-28 07:34:07 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-28 07:34:07 --> Config Class Initialized
INFO - 2017-12-28 07:34:07 --> Hooks Class Initialized
INFO - 2017-12-28 07:34:07 --> Config Class Initialized
INFO - 2017-12-28 07:34:07 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:34:07 --> UTF-8 Support Enabled
DEBUG - 2017-12-28 07:34:07 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:34:07 --> Utf8 Class Initialized
INFO - 2017-12-28 07:34:07 --> Utf8 Class Initialized
INFO - 2017-12-28 07:34:07 --> URI Class Initialized
INFO - 2017-12-28 07:34:07 --> URI Class Initialized
INFO - 2017-12-28 07:34:07 --> Router Class Initialized
INFO - 2017-12-28 07:34:07 --> Router Class Initialized
INFO - 2017-12-28 07:34:07 --> Output Class Initialized
INFO - 2017-12-28 07:34:07 --> Security Class Initialized
INFO - 2017-12-28 07:34:07 --> Output Class Initialized
DEBUG - 2017-12-28 07:34:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:34:07 --> Input Class Initialized
INFO - 2017-12-28 07:34:07 --> Language Class Initialized
INFO - 2017-12-28 07:34:07 --> Security Class Initialized
ERROR - 2017-12-28 07:34:07 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2017-12-28 07:34:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:34:07 --> Input Class Initialized
INFO - 2017-12-28 07:34:07 --> Language Class Initialized
ERROR - 2017-12-28 07:34:07 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-28 07:34:07 --> Config Class Initialized
INFO - 2017-12-28 07:34:07 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:34:07 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:34:07 --> Utf8 Class Initialized
INFO - 2017-12-28 07:34:07 --> URI Class Initialized
INFO - 2017-12-28 07:34:07 --> Router Class Initialized
INFO - 2017-12-28 07:34:07 --> Output Class Initialized
INFO - 2017-12-28 07:34:07 --> Security Class Initialized
DEBUG - 2017-12-28 07:34:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:34:07 --> Input Class Initialized
INFO - 2017-12-28 07:34:07 --> Language Class Initialized
INFO - 2017-12-28 07:34:07 --> Loader Class Initialized
INFO - 2017-12-28 07:34:07 --> Helper loaded: url_helper
INFO - 2017-12-28 07:34:07 --> Helper loaded: form_helper
INFO - 2017-12-28 07:34:07 --> Database Driver Class Initialized
DEBUG - 2017-12-28 07:34:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 07:34:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 07:34:07 --> Form Validation Class Initialized
INFO - 2017-12-28 07:34:07 --> Model Class Initialized
INFO - 2017-12-28 07:34:07 --> Controller Class Initialized
INFO - 2017-12-28 07:34:07 --> Model Class Initialized
INFO - 2017-12-28 07:34:07 --> Model Class Initialized
INFO - 2017-12-28 07:34:07 --> Model Class Initialized
INFO - 2017-12-28 07:34:07 --> Model Class Initialized
DEBUG - 2017-12-28 07:34:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 07:34:12 --> Config Class Initialized
INFO - 2017-12-28 07:34:12 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:34:12 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:34:12 --> Utf8 Class Initialized
INFO - 2017-12-28 07:34:12 --> URI Class Initialized
INFO - 2017-12-28 07:34:12 --> Router Class Initialized
INFO - 2017-12-28 07:34:12 --> Output Class Initialized
INFO - 2017-12-28 07:34:12 --> Security Class Initialized
DEBUG - 2017-12-28 07:34:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:34:12 --> Input Class Initialized
INFO - 2017-12-28 07:34:12 --> Language Class Initialized
INFO - 2017-12-28 07:34:12 --> Loader Class Initialized
INFO - 2017-12-28 07:34:12 --> Helper loaded: url_helper
INFO - 2017-12-28 07:34:12 --> Helper loaded: form_helper
INFO - 2017-12-28 07:34:12 --> Database Driver Class Initialized
DEBUG - 2017-12-28 07:34:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 07:34:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 07:34:12 --> Form Validation Class Initialized
INFO - 2017-12-28 07:34:12 --> Model Class Initialized
INFO - 2017-12-28 07:34:12 --> Controller Class Initialized
INFO - 2017-12-28 07:34:12 --> Model Class Initialized
INFO - 2017-12-28 07:34:12 --> Model Class Initialized
INFO - 2017-12-28 07:34:12 --> Model Class Initialized
INFO - 2017-12-28 07:34:12 --> Model Class Initialized
DEBUG - 2017-12-28 07:34:12 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2017-12-28 07:34:12 --> Query error: Unknown column 'proyecto_valor_oferta.proyecto_valor_oferta_extension_tipo_id' in 'where clause' - Invalid query: SELECT *
FROM `proyecto_valor_oferta`
LEFT JOIN `proyecto_valor_oferta_extension_detalle` ON `proyecto_valor_oferta_extension_detalle`.`proyecto_valor_oferta_id` = `proyecto_valor_oferta`.`proyecto_valor_oferta_id`
LEFT JOIN `proyecto_valor_oferta_extension_tipo` ON `proyecto_valor_oferta_extension_tipo`.`proyecto_valor_oferta_extension_tipo_id` = `proyecto_valor_oferta_extension_detalle`.`proyecto_valor_oferta_extension_tipo_id`
WHERE `proyecto_valor_oferta`.`proyecto_valor_oferta_tipo_id` = 6
AND `proyecto_valor_oferta`.`proyecto_id` = '1'
AND `proyecto_valor_oferta`.`proyecto_valor_oferta_extension_tipo_id` = '1'
INFO - 2017-12-28 07:34:12 --> Language file loaded: language/english/db_lang.php
INFO - 2017-12-28 07:35:44 --> Config Class Initialized
INFO - 2017-12-28 07:35:44 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:35:44 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:35:44 --> Utf8 Class Initialized
INFO - 2017-12-28 07:35:44 --> URI Class Initialized
INFO - 2017-12-28 07:35:44 --> Router Class Initialized
INFO - 2017-12-28 07:35:44 --> Output Class Initialized
INFO - 2017-12-28 07:35:44 --> Security Class Initialized
DEBUG - 2017-12-28 07:35:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:35:44 --> Input Class Initialized
INFO - 2017-12-28 07:35:44 --> Language Class Initialized
INFO - 2017-12-28 07:35:44 --> Loader Class Initialized
INFO - 2017-12-28 07:35:44 --> Helper loaded: url_helper
INFO - 2017-12-28 07:35:44 --> Helper loaded: form_helper
INFO - 2017-12-28 07:35:44 --> Database Driver Class Initialized
DEBUG - 2017-12-28 07:35:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 07:35:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 07:35:44 --> Form Validation Class Initialized
INFO - 2017-12-28 07:35:44 --> Model Class Initialized
INFO - 2017-12-28 07:35:44 --> Controller Class Initialized
INFO - 2017-12-28 07:35:44 --> Model Class Initialized
INFO - 2017-12-28 07:35:44 --> Model Class Initialized
INFO - 2017-12-28 07:35:44 --> Model Class Initialized
INFO - 2017-12-28 07:35:44 --> Model Class Initialized
DEBUG - 2017-12-28 07:35:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 07:35:44 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 07:35:44 --> Final output sent to browser
DEBUG - 2017-12-28 07:35:44 --> Total execution time: 0.0687
INFO - 2017-12-28 07:35:45 --> Config Class Initialized
INFO - 2017-12-28 07:35:45 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:35:45 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:35:45 --> Utf8 Class Initialized
INFO - 2017-12-28 07:35:45 --> URI Class Initialized
INFO - 2017-12-28 07:35:45 --> Router Class Initialized
INFO - 2017-12-28 07:35:45 --> Output Class Initialized
INFO - 2017-12-28 07:35:45 --> Security Class Initialized
DEBUG - 2017-12-28 07:35:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:35:45 --> Input Class Initialized
INFO - 2017-12-28 07:35:45 --> Language Class Initialized
ERROR - 2017-12-28 07:35:45 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-28 07:35:45 --> Config Class Initialized
INFO - 2017-12-28 07:35:45 --> Hooks Class Initialized
INFO - 2017-12-28 07:35:45 --> Config Class Initialized
INFO - 2017-12-28 07:35:45 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:35:45 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:35:45 --> Utf8 Class Initialized
DEBUG - 2017-12-28 07:35:45 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:35:45 --> URI Class Initialized
INFO - 2017-12-28 07:35:45 --> Utf8 Class Initialized
INFO - 2017-12-28 07:35:45 --> Router Class Initialized
INFO - 2017-12-28 07:35:45 --> URI Class Initialized
INFO - 2017-12-28 07:35:45 --> Output Class Initialized
INFO - 2017-12-28 07:35:45 --> Router Class Initialized
INFO - 2017-12-28 07:35:45 --> Security Class Initialized
DEBUG - 2017-12-28 07:35:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:35:45 --> Input Class Initialized
INFO - 2017-12-28 07:35:45 --> Output Class Initialized
INFO - 2017-12-28 07:35:45 --> Language Class Initialized
INFO - 2017-12-28 07:35:45 --> Security Class Initialized
ERROR - 2017-12-28 07:35:45 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2017-12-28 07:35:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:35:45 --> Input Class Initialized
INFO - 2017-12-28 07:35:45 --> Language Class Initialized
ERROR - 2017-12-28 07:35:45 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-28 07:35:45 --> Config Class Initialized
INFO - 2017-12-28 07:35:45 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:35:45 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:35:45 --> Utf8 Class Initialized
INFO - 2017-12-28 07:35:45 --> URI Class Initialized
INFO - 2017-12-28 07:35:45 --> Router Class Initialized
INFO - 2017-12-28 07:35:45 --> Output Class Initialized
INFO - 2017-12-28 07:35:45 --> Security Class Initialized
DEBUG - 2017-12-28 07:35:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:35:45 --> Input Class Initialized
INFO - 2017-12-28 07:35:45 --> Language Class Initialized
INFO - 2017-12-28 07:35:45 --> Loader Class Initialized
INFO - 2017-12-28 07:35:45 --> Helper loaded: url_helper
INFO - 2017-12-28 07:35:45 --> Helper loaded: form_helper
INFO - 2017-12-28 07:35:45 --> Database Driver Class Initialized
DEBUG - 2017-12-28 07:35:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 07:35:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 07:35:45 --> Form Validation Class Initialized
INFO - 2017-12-28 07:35:45 --> Model Class Initialized
INFO - 2017-12-28 07:35:45 --> Controller Class Initialized
INFO - 2017-12-28 07:35:45 --> Model Class Initialized
INFO - 2017-12-28 07:35:45 --> Model Class Initialized
INFO - 2017-12-28 07:35:45 --> Model Class Initialized
INFO - 2017-12-28 07:35:45 --> Model Class Initialized
DEBUG - 2017-12-28 07:35:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 07:35:49 --> Config Class Initialized
INFO - 2017-12-28 07:35:49 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:35:49 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:35:49 --> Utf8 Class Initialized
INFO - 2017-12-28 07:35:49 --> URI Class Initialized
INFO - 2017-12-28 07:35:49 --> Router Class Initialized
INFO - 2017-12-28 07:35:49 --> Output Class Initialized
INFO - 2017-12-28 07:35:49 --> Security Class Initialized
DEBUG - 2017-12-28 07:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:35:49 --> Input Class Initialized
INFO - 2017-12-28 07:35:49 --> Language Class Initialized
INFO - 2017-12-28 07:35:49 --> Loader Class Initialized
INFO - 2017-12-28 07:35:49 --> Helper loaded: url_helper
INFO - 2017-12-28 07:35:49 --> Helper loaded: form_helper
INFO - 2017-12-28 07:35:49 --> Database Driver Class Initialized
DEBUG - 2017-12-28 07:35:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 07:35:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 07:35:49 --> Form Validation Class Initialized
INFO - 2017-12-28 07:35:49 --> Model Class Initialized
INFO - 2017-12-28 07:35:49 --> Controller Class Initialized
INFO - 2017-12-28 07:35:49 --> Model Class Initialized
INFO - 2017-12-28 07:35:49 --> Model Class Initialized
INFO - 2017-12-28 07:35:49 --> Model Class Initialized
INFO - 2017-12-28 07:35:49 --> Model Class Initialized
DEBUG - 2017-12-28 07:35:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 07:35:52 --> Config Class Initialized
INFO - 2017-12-28 07:35:52 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:35:52 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:35:52 --> Utf8 Class Initialized
INFO - 2017-12-28 07:35:52 --> URI Class Initialized
INFO - 2017-12-28 07:35:52 --> Router Class Initialized
INFO - 2017-12-28 07:35:52 --> Output Class Initialized
INFO - 2017-12-28 07:35:52 --> Security Class Initialized
DEBUG - 2017-12-28 07:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:35:52 --> Input Class Initialized
INFO - 2017-12-28 07:35:52 --> Language Class Initialized
INFO - 2017-12-28 07:35:52 --> Loader Class Initialized
INFO - 2017-12-28 07:35:52 --> Helper loaded: url_helper
INFO - 2017-12-28 07:35:52 --> Helper loaded: form_helper
INFO - 2017-12-28 07:35:52 --> Database Driver Class Initialized
DEBUG - 2017-12-28 07:35:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 07:35:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 07:35:52 --> Form Validation Class Initialized
INFO - 2017-12-28 07:35:52 --> Model Class Initialized
INFO - 2017-12-28 07:35:52 --> Controller Class Initialized
INFO - 2017-12-28 07:35:52 --> Model Class Initialized
INFO - 2017-12-28 07:35:52 --> Model Class Initialized
INFO - 2017-12-28 07:35:52 --> Model Class Initialized
INFO - 2017-12-28 07:35:52 --> Model Class Initialized
DEBUG - 2017-12-28 07:35:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 07:35:54 --> Config Class Initialized
INFO - 2017-12-28 07:35:54 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:35:54 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:35:54 --> Utf8 Class Initialized
INFO - 2017-12-28 07:35:54 --> URI Class Initialized
INFO - 2017-12-28 07:35:54 --> Router Class Initialized
INFO - 2017-12-28 07:35:54 --> Output Class Initialized
INFO - 2017-12-28 07:35:54 --> Security Class Initialized
DEBUG - 2017-12-28 07:35:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:35:54 --> Input Class Initialized
INFO - 2017-12-28 07:35:54 --> Language Class Initialized
INFO - 2017-12-28 07:35:54 --> Loader Class Initialized
INFO - 2017-12-28 07:35:54 --> Helper loaded: url_helper
INFO - 2017-12-28 07:35:54 --> Helper loaded: form_helper
INFO - 2017-12-28 07:35:54 --> Database Driver Class Initialized
DEBUG - 2017-12-28 07:35:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 07:35:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 07:35:54 --> Form Validation Class Initialized
INFO - 2017-12-28 07:35:54 --> Model Class Initialized
INFO - 2017-12-28 07:35:54 --> Controller Class Initialized
INFO - 2017-12-28 07:35:54 --> Model Class Initialized
INFO - 2017-12-28 07:35:54 --> Model Class Initialized
INFO - 2017-12-28 07:35:54 --> Model Class Initialized
INFO - 2017-12-28 07:35:54 --> Model Class Initialized
DEBUG - 2017-12-28 07:35:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 07:35:56 --> Config Class Initialized
INFO - 2017-12-28 07:35:56 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:35:56 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:35:56 --> Utf8 Class Initialized
INFO - 2017-12-28 07:35:56 --> URI Class Initialized
INFO - 2017-12-28 07:35:56 --> Router Class Initialized
INFO - 2017-12-28 07:35:56 --> Output Class Initialized
INFO - 2017-12-28 07:35:56 --> Security Class Initialized
DEBUG - 2017-12-28 07:35:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:35:56 --> Input Class Initialized
INFO - 2017-12-28 07:35:56 --> Language Class Initialized
INFO - 2017-12-28 07:35:56 --> Loader Class Initialized
INFO - 2017-12-28 07:35:56 --> Helper loaded: url_helper
INFO - 2017-12-28 07:35:56 --> Helper loaded: form_helper
INFO - 2017-12-28 07:35:56 --> Database Driver Class Initialized
DEBUG - 2017-12-28 07:35:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 07:35:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 07:35:56 --> Form Validation Class Initialized
INFO - 2017-12-28 07:35:56 --> Model Class Initialized
INFO - 2017-12-28 07:35:56 --> Controller Class Initialized
INFO - 2017-12-28 07:35:56 --> Model Class Initialized
INFO - 2017-12-28 07:35:56 --> Model Class Initialized
INFO - 2017-12-28 07:35:56 --> Model Class Initialized
INFO - 2017-12-28 07:35:56 --> Model Class Initialized
DEBUG - 2017-12-28 07:35:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 07:36:34 --> Config Class Initialized
INFO - 2017-12-28 07:36:34 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:36:34 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:36:34 --> Utf8 Class Initialized
INFO - 2017-12-28 07:36:34 --> URI Class Initialized
INFO - 2017-12-28 07:36:34 --> Router Class Initialized
INFO - 2017-12-28 07:36:34 --> Output Class Initialized
INFO - 2017-12-28 07:36:34 --> Security Class Initialized
DEBUG - 2017-12-28 07:36:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:36:34 --> Input Class Initialized
INFO - 2017-12-28 07:36:34 --> Language Class Initialized
INFO - 2017-12-28 07:36:34 --> Loader Class Initialized
INFO - 2017-12-28 07:36:34 --> Helper loaded: url_helper
INFO - 2017-12-28 07:36:34 --> Helper loaded: form_helper
INFO - 2017-12-28 07:36:34 --> Database Driver Class Initialized
DEBUG - 2017-12-28 07:36:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 07:36:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 07:36:34 --> Form Validation Class Initialized
INFO - 2017-12-28 07:36:34 --> Model Class Initialized
INFO - 2017-12-28 07:36:34 --> Controller Class Initialized
INFO - 2017-12-28 07:36:34 --> Model Class Initialized
INFO - 2017-12-28 07:36:34 --> Model Class Initialized
INFO - 2017-12-28 07:36:34 --> Model Class Initialized
INFO - 2017-12-28 07:36:34 --> Model Class Initialized
DEBUG - 2017-12-28 07:36:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 07:36:34 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 07:36:34 --> Final output sent to browser
DEBUG - 2017-12-28 07:36:34 --> Total execution time: 0.0631
INFO - 2017-12-28 07:36:34 --> Config Class Initialized
INFO - 2017-12-28 07:36:34 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:36:34 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:36:34 --> Utf8 Class Initialized
INFO - 2017-12-28 07:36:34 --> URI Class Initialized
INFO - 2017-12-28 07:36:34 --> Router Class Initialized
INFO - 2017-12-28 07:36:34 --> Output Class Initialized
INFO - 2017-12-28 07:36:34 --> Security Class Initialized
DEBUG - 2017-12-28 07:36:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:36:34 --> Input Class Initialized
INFO - 2017-12-28 07:36:34 --> Language Class Initialized
ERROR - 2017-12-28 07:36:34 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-28 07:36:34 --> Config Class Initialized
INFO - 2017-12-28 07:36:34 --> Hooks Class Initialized
INFO - 2017-12-28 07:36:34 --> Config Class Initialized
INFO - 2017-12-28 07:36:34 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:36:34 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:36:34 --> Utf8 Class Initialized
INFO - 2017-12-28 07:36:34 --> URI Class Initialized
DEBUG - 2017-12-28 07:36:34 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:36:34 --> Utf8 Class Initialized
INFO - 2017-12-28 07:36:34 --> Router Class Initialized
INFO - 2017-12-28 07:36:34 --> URI Class Initialized
INFO - 2017-12-28 07:36:34 --> Output Class Initialized
INFO - 2017-12-28 07:36:34 --> Security Class Initialized
INFO - 2017-12-28 07:36:34 --> Router Class Initialized
DEBUG - 2017-12-28 07:36:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:36:34 --> Input Class Initialized
INFO - 2017-12-28 07:36:34 --> Output Class Initialized
INFO - 2017-12-28 07:36:34 --> Language Class Initialized
INFO - 2017-12-28 07:36:34 --> Security Class Initialized
ERROR - 2017-12-28 07:36:34 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2017-12-28 07:36:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:36:34 --> Input Class Initialized
INFO - 2017-12-28 07:36:34 --> Language Class Initialized
ERROR - 2017-12-28 07:36:34 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-28 07:36:34 --> Config Class Initialized
INFO - 2017-12-28 07:36:34 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:36:34 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:36:34 --> Utf8 Class Initialized
INFO - 2017-12-28 07:36:34 --> URI Class Initialized
INFO - 2017-12-28 07:36:34 --> Router Class Initialized
INFO - 2017-12-28 07:36:34 --> Output Class Initialized
INFO - 2017-12-28 07:36:34 --> Security Class Initialized
DEBUG - 2017-12-28 07:36:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:36:34 --> Input Class Initialized
INFO - 2017-12-28 07:36:34 --> Language Class Initialized
INFO - 2017-12-28 07:36:34 --> Loader Class Initialized
INFO - 2017-12-28 07:36:34 --> Helper loaded: url_helper
INFO - 2017-12-28 07:36:34 --> Helper loaded: form_helper
INFO - 2017-12-28 07:36:34 --> Database Driver Class Initialized
DEBUG - 2017-12-28 07:36:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 07:36:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 07:36:34 --> Form Validation Class Initialized
INFO - 2017-12-28 07:36:34 --> Model Class Initialized
INFO - 2017-12-28 07:36:34 --> Controller Class Initialized
INFO - 2017-12-28 07:36:34 --> Model Class Initialized
INFO - 2017-12-28 07:36:34 --> Model Class Initialized
INFO - 2017-12-28 07:36:34 --> Model Class Initialized
INFO - 2017-12-28 07:36:34 --> Model Class Initialized
DEBUG - 2017-12-28 07:36:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 07:36:44 --> Config Class Initialized
INFO - 2017-12-28 07:36:44 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:36:44 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:36:44 --> Utf8 Class Initialized
INFO - 2017-12-28 07:36:44 --> URI Class Initialized
INFO - 2017-12-28 07:36:44 --> Router Class Initialized
INFO - 2017-12-28 07:36:44 --> Output Class Initialized
INFO - 2017-12-28 07:36:44 --> Security Class Initialized
DEBUG - 2017-12-28 07:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:36:44 --> Input Class Initialized
INFO - 2017-12-28 07:36:44 --> Language Class Initialized
INFO - 2017-12-28 07:36:44 --> Loader Class Initialized
INFO - 2017-12-28 07:36:44 --> Helper loaded: url_helper
INFO - 2017-12-28 07:36:44 --> Helper loaded: form_helper
INFO - 2017-12-28 07:36:44 --> Database Driver Class Initialized
DEBUG - 2017-12-28 07:36:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 07:36:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 07:36:44 --> Form Validation Class Initialized
INFO - 2017-12-28 07:36:44 --> Model Class Initialized
INFO - 2017-12-28 07:36:44 --> Controller Class Initialized
INFO - 2017-12-28 07:36:44 --> Model Class Initialized
INFO - 2017-12-28 07:36:44 --> Model Class Initialized
INFO - 2017-12-28 07:36:44 --> Model Class Initialized
INFO - 2017-12-28 07:36:44 --> Model Class Initialized
DEBUG - 2017-12-28 07:36:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 07:36:49 --> Config Class Initialized
INFO - 2017-12-28 07:36:49 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:36:49 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:36:49 --> Utf8 Class Initialized
INFO - 2017-12-28 07:36:49 --> URI Class Initialized
INFO - 2017-12-28 07:36:49 --> Router Class Initialized
INFO - 2017-12-28 07:36:49 --> Output Class Initialized
INFO - 2017-12-28 07:36:49 --> Security Class Initialized
DEBUG - 2017-12-28 07:36:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:36:49 --> Input Class Initialized
INFO - 2017-12-28 07:36:49 --> Language Class Initialized
INFO - 2017-12-28 07:36:49 --> Loader Class Initialized
INFO - 2017-12-28 07:36:49 --> Helper loaded: url_helper
INFO - 2017-12-28 07:36:49 --> Helper loaded: form_helper
INFO - 2017-12-28 07:36:49 --> Database Driver Class Initialized
DEBUG - 2017-12-28 07:36:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 07:36:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 07:36:49 --> Form Validation Class Initialized
INFO - 2017-12-28 07:36:49 --> Model Class Initialized
INFO - 2017-12-28 07:36:49 --> Controller Class Initialized
INFO - 2017-12-28 07:36:49 --> Model Class Initialized
INFO - 2017-12-28 07:36:49 --> Model Class Initialized
INFO - 2017-12-28 07:36:49 --> Model Class Initialized
INFO - 2017-12-28 07:36:49 --> Model Class Initialized
DEBUG - 2017-12-28 07:36:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 07:36:58 --> Config Class Initialized
INFO - 2017-12-28 07:36:58 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:36:58 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:36:58 --> Utf8 Class Initialized
INFO - 2017-12-28 07:36:58 --> URI Class Initialized
INFO - 2017-12-28 07:36:58 --> Router Class Initialized
INFO - 2017-12-28 07:36:58 --> Output Class Initialized
INFO - 2017-12-28 07:36:58 --> Security Class Initialized
DEBUG - 2017-12-28 07:36:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:36:58 --> Input Class Initialized
INFO - 2017-12-28 07:36:58 --> Language Class Initialized
INFO - 2017-12-28 07:36:58 --> Loader Class Initialized
INFO - 2017-12-28 07:36:58 --> Helper loaded: url_helper
INFO - 2017-12-28 07:36:58 --> Helper loaded: form_helper
INFO - 2017-12-28 07:36:58 --> Database Driver Class Initialized
DEBUG - 2017-12-28 07:36:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 07:36:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 07:36:58 --> Form Validation Class Initialized
INFO - 2017-12-28 07:36:58 --> Model Class Initialized
INFO - 2017-12-28 07:36:58 --> Controller Class Initialized
INFO - 2017-12-28 07:36:58 --> Model Class Initialized
INFO - 2017-12-28 07:36:58 --> Model Class Initialized
INFO - 2017-12-28 07:36:58 --> Model Class Initialized
INFO - 2017-12-28 07:36:58 --> Model Class Initialized
DEBUG - 2017-12-28 07:36:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 07:37:41 --> Config Class Initialized
INFO - 2017-12-28 07:37:41 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:37:41 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:37:41 --> Utf8 Class Initialized
INFO - 2017-12-28 07:37:41 --> URI Class Initialized
INFO - 2017-12-28 07:37:41 --> Router Class Initialized
INFO - 2017-12-28 07:37:41 --> Output Class Initialized
INFO - 2017-12-28 07:37:41 --> Security Class Initialized
DEBUG - 2017-12-28 07:37:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:37:41 --> Input Class Initialized
INFO - 2017-12-28 07:37:41 --> Language Class Initialized
INFO - 2017-12-28 07:37:41 --> Loader Class Initialized
INFO - 2017-12-28 07:37:41 --> Helper loaded: url_helper
INFO - 2017-12-28 07:37:41 --> Helper loaded: form_helper
INFO - 2017-12-28 07:37:41 --> Database Driver Class Initialized
DEBUG - 2017-12-28 07:37:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 07:37:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 07:37:41 --> Form Validation Class Initialized
INFO - 2017-12-28 07:37:41 --> Model Class Initialized
INFO - 2017-12-28 07:37:41 --> Controller Class Initialized
INFO - 2017-12-28 07:37:41 --> Model Class Initialized
INFO - 2017-12-28 07:37:41 --> Model Class Initialized
INFO - 2017-12-28 07:37:41 --> Model Class Initialized
INFO - 2017-12-28 07:37:41 --> Model Class Initialized
DEBUG - 2017-12-28 07:37:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 07:37:41 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 07:37:41 --> Final output sent to browser
DEBUG - 2017-12-28 07:37:41 --> Total execution time: 0.0603
INFO - 2017-12-28 07:37:49 --> Config Class Initialized
INFO - 2017-12-28 07:37:49 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:37:49 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:37:49 --> Utf8 Class Initialized
INFO - 2017-12-28 07:37:49 --> URI Class Initialized
INFO - 2017-12-28 07:37:49 --> Router Class Initialized
INFO - 2017-12-28 07:37:49 --> Output Class Initialized
INFO - 2017-12-28 07:37:49 --> Security Class Initialized
DEBUG - 2017-12-28 07:37:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:37:49 --> Input Class Initialized
INFO - 2017-12-28 07:37:49 --> Language Class Initialized
INFO - 2017-12-28 07:37:49 --> Loader Class Initialized
INFO - 2017-12-28 07:37:49 --> Helper loaded: url_helper
INFO - 2017-12-28 07:37:49 --> Helper loaded: form_helper
INFO - 2017-12-28 07:37:49 --> Database Driver Class Initialized
DEBUG - 2017-12-28 07:37:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 07:37:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 07:37:49 --> Form Validation Class Initialized
INFO - 2017-12-28 07:37:49 --> Model Class Initialized
INFO - 2017-12-28 07:37:49 --> Controller Class Initialized
INFO - 2017-12-28 07:37:49 --> Model Class Initialized
INFO - 2017-12-28 07:37:49 --> Model Class Initialized
INFO - 2017-12-28 07:37:49 --> Model Class Initialized
INFO - 2017-12-28 07:37:49 --> Model Class Initialized
DEBUG - 2017-12-28 07:37:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 07:37:49 --> Config Class Initialized
INFO - 2017-12-28 07:37:49 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:37:49 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:37:49 --> Utf8 Class Initialized
INFO - 2017-12-28 07:37:49 --> URI Class Initialized
INFO - 2017-12-28 07:37:49 --> Router Class Initialized
INFO - 2017-12-28 07:37:49 --> Output Class Initialized
INFO - 2017-12-28 07:37:49 --> Security Class Initialized
DEBUG - 2017-12-28 07:37:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:37:49 --> Input Class Initialized
INFO - 2017-12-28 07:37:49 --> Language Class Initialized
INFO - 2017-12-28 07:37:49 --> Loader Class Initialized
INFO - 2017-12-28 07:37:49 --> Helper loaded: url_helper
INFO - 2017-12-28 07:37:49 --> Helper loaded: form_helper
INFO - 2017-12-28 07:37:49 --> Database Driver Class Initialized
DEBUG - 2017-12-28 07:37:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 07:37:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 07:37:49 --> Form Validation Class Initialized
INFO - 2017-12-28 07:37:49 --> Model Class Initialized
INFO - 2017-12-28 07:37:49 --> Controller Class Initialized
INFO - 2017-12-28 07:37:49 --> Model Class Initialized
INFO - 2017-12-28 07:37:49 --> Model Class Initialized
INFO - 2017-12-28 07:37:49 --> Model Class Initialized
INFO - 2017-12-28 07:37:49 --> Model Class Initialized
DEBUG - 2017-12-28 07:37:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 07:37:49 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 07:37:49 --> Final output sent to browser
DEBUG - 2017-12-28 07:37:49 --> Total execution time: 0.0607
INFO - 2017-12-28 07:37:49 --> Config Class Initialized
INFO - 2017-12-28 07:37:49 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:37:49 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:37:49 --> Utf8 Class Initialized
INFO - 2017-12-28 07:37:49 --> URI Class Initialized
INFO - 2017-12-28 07:37:49 --> Router Class Initialized
INFO - 2017-12-28 07:37:49 --> Output Class Initialized
INFO - 2017-12-28 07:37:49 --> Security Class Initialized
DEBUG - 2017-12-28 07:37:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:37:49 --> Input Class Initialized
INFO - 2017-12-28 07:37:49 --> Language Class Initialized
INFO - 2017-12-28 07:37:49 --> Loader Class Initialized
INFO - 2017-12-28 07:37:49 --> Helper loaded: url_helper
INFO - 2017-12-28 07:37:49 --> Helper loaded: form_helper
INFO - 2017-12-28 07:37:49 --> Database Driver Class Initialized
DEBUG - 2017-12-28 07:37:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 07:37:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 07:37:49 --> Form Validation Class Initialized
INFO - 2017-12-28 07:37:49 --> Model Class Initialized
INFO - 2017-12-28 07:37:49 --> Controller Class Initialized
INFO - 2017-12-28 07:37:49 --> Model Class Initialized
INFO - 2017-12-28 07:37:49 --> Model Class Initialized
INFO - 2017-12-28 07:37:49 --> Model Class Initialized
INFO - 2017-12-28 07:37:49 --> Model Class Initialized
DEBUG - 2017-12-28 07:37:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 07:38:01 --> Config Class Initialized
INFO - 2017-12-28 07:38:01 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:38:01 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:38:01 --> Utf8 Class Initialized
INFO - 2017-12-28 07:38:01 --> URI Class Initialized
INFO - 2017-12-28 07:38:01 --> Router Class Initialized
INFO - 2017-12-28 07:38:01 --> Output Class Initialized
INFO - 2017-12-28 07:38:01 --> Security Class Initialized
DEBUG - 2017-12-28 07:38:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:38:01 --> Input Class Initialized
INFO - 2017-12-28 07:38:01 --> Language Class Initialized
INFO - 2017-12-28 07:38:01 --> Loader Class Initialized
INFO - 2017-12-28 07:38:01 --> Helper loaded: url_helper
INFO - 2017-12-28 07:38:01 --> Helper loaded: form_helper
INFO - 2017-12-28 07:38:01 --> Database Driver Class Initialized
DEBUG - 2017-12-28 07:38:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 07:38:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 07:38:01 --> Form Validation Class Initialized
INFO - 2017-12-28 07:38:01 --> Model Class Initialized
INFO - 2017-12-28 07:38:01 --> Controller Class Initialized
INFO - 2017-12-28 07:38:01 --> Model Class Initialized
INFO - 2017-12-28 07:38:01 --> Model Class Initialized
INFO - 2017-12-28 07:38:01 --> Model Class Initialized
INFO - 2017-12-28 07:38:01 --> Model Class Initialized
DEBUG - 2017-12-28 07:38:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 07:38:05 --> Config Class Initialized
INFO - 2017-12-28 07:38:05 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:38:05 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:38:05 --> Utf8 Class Initialized
INFO - 2017-12-28 07:38:05 --> URI Class Initialized
INFO - 2017-12-28 07:38:05 --> Router Class Initialized
INFO - 2017-12-28 07:38:05 --> Output Class Initialized
INFO - 2017-12-28 07:38:05 --> Security Class Initialized
DEBUG - 2017-12-28 07:38:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:38:05 --> Input Class Initialized
INFO - 2017-12-28 07:38:05 --> Language Class Initialized
INFO - 2017-12-28 07:38:05 --> Loader Class Initialized
INFO - 2017-12-28 07:38:05 --> Helper loaded: url_helper
INFO - 2017-12-28 07:38:05 --> Helper loaded: form_helper
INFO - 2017-12-28 07:38:05 --> Database Driver Class Initialized
DEBUG - 2017-12-28 07:38:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 07:38:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 07:38:05 --> Form Validation Class Initialized
INFO - 2017-12-28 07:38:05 --> Model Class Initialized
INFO - 2017-12-28 07:38:05 --> Controller Class Initialized
INFO - 2017-12-28 07:38:05 --> Model Class Initialized
INFO - 2017-12-28 07:38:05 --> Model Class Initialized
INFO - 2017-12-28 07:38:05 --> Model Class Initialized
INFO - 2017-12-28 07:38:05 --> Model Class Initialized
DEBUG - 2017-12-28 07:38:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 07:38:24 --> Config Class Initialized
INFO - 2017-12-28 07:38:24 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:38:24 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:38:24 --> Utf8 Class Initialized
INFO - 2017-12-28 07:38:24 --> URI Class Initialized
INFO - 2017-12-28 07:38:24 --> Router Class Initialized
INFO - 2017-12-28 07:38:24 --> Output Class Initialized
INFO - 2017-12-28 07:38:24 --> Security Class Initialized
DEBUG - 2017-12-28 07:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:38:24 --> Input Class Initialized
INFO - 2017-12-28 07:38:24 --> Language Class Initialized
INFO - 2017-12-28 07:38:24 --> Loader Class Initialized
INFO - 2017-12-28 07:38:24 --> Helper loaded: url_helper
INFO - 2017-12-28 07:38:24 --> Helper loaded: form_helper
INFO - 2017-12-28 07:38:24 --> Database Driver Class Initialized
DEBUG - 2017-12-28 07:38:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 07:38:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 07:38:24 --> Form Validation Class Initialized
INFO - 2017-12-28 07:38:24 --> Model Class Initialized
INFO - 2017-12-28 07:38:24 --> Controller Class Initialized
INFO - 2017-12-28 07:38:24 --> Model Class Initialized
INFO - 2017-12-28 07:38:24 --> Model Class Initialized
INFO - 2017-12-28 07:38:24 --> Model Class Initialized
INFO - 2017-12-28 07:38:24 --> Model Class Initialized
DEBUG - 2017-12-28 07:38:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 07:38:24 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 07:38:24 --> Final output sent to browser
DEBUG - 2017-12-28 07:38:24 --> Total execution time: 0.0613
INFO - 2017-12-28 07:38:24 --> Config Class Initialized
INFO - 2017-12-28 07:38:24 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:38:24 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:38:24 --> Utf8 Class Initialized
INFO - 2017-12-28 07:38:24 --> URI Class Initialized
INFO - 2017-12-28 07:38:24 --> Router Class Initialized
INFO - 2017-12-28 07:38:24 --> Output Class Initialized
INFO - 2017-12-28 07:38:24 --> Security Class Initialized
DEBUG - 2017-12-28 07:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:38:24 --> Input Class Initialized
INFO - 2017-12-28 07:38:24 --> Language Class Initialized
INFO - 2017-12-28 07:38:24 --> Loader Class Initialized
INFO - 2017-12-28 07:38:25 --> Helper loaded: url_helper
INFO - 2017-12-28 07:38:25 --> Helper loaded: form_helper
INFO - 2017-12-28 07:38:25 --> Database Driver Class Initialized
DEBUG - 2017-12-28 07:38:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 07:38:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 07:38:25 --> Form Validation Class Initialized
INFO - 2017-12-28 07:38:25 --> Model Class Initialized
INFO - 2017-12-28 07:38:25 --> Controller Class Initialized
INFO - 2017-12-28 07:38:25 --> Model Class Initialized
INFO - 2017-12-28 07:38:25 --> Model Class Initialized
INFO - 2017-12-28 07:38:25 --> Model Class Initialized
INFO - 2017-12-28 07:38:25 --> Model Class Initialized
DEBUG - 2017-12-28 07:38:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 07:38:28 --> Config Class Initialized
INFO - 2017-12-28 07:38:28 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:38:28 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:38:28 --> Utf8 Class Initialized
INFO - 2017-12-28 07:38:28 --> URI Class Initialized
INFO - 2017-12-28 07:38:28 --> Router Class Initialized
INFO - 2017-12-28 07:38:28 --> Output Class Initialized
INFO - 2017-12-28 07:38:28 --> Security Class Initialized
DEBUG - 2017-12-28 07:38:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:38:28 --> Input Class Initialized
INFO - 2017-12-28 07:38:28 --> Language Class Initialized
INFO - 2017-12-28 07:38:28 --> Loader Class Initialized
INFO - 2017-12-28 07:38:28 --> Helper loaded: url_helper
INFO - 2017-12-28 07:38:28 --> Helper loaded: form_helper
INFO - 2017-12-28 07:38:28 --> Database Driver Class Initialized
DEBUG - 2017-12-28 07:38:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 07:38:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 07:38:28 --> Form Validation Class Initialized
INFO - 2017-12-28 07:38:28 --> Model Class Initialized
INFO - 2017-12-28 07:38:28 --> Controller Class Initialized
INFO - 2017-12-28 07:38:28 --> Model Class Initialized
INFO - 2017-12-28 07:38:28 --> Model Class Initialized
INFO - 2017-12-28 07:38:28 --> Model Class Initialized
INFO - 2017-12-28 07:38:28 --> Model Class Initialized
DEBUG - 2017-12-28 07:38:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 07:38:28 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 07:38:28 --> Final output sent to browser
DEBUG - 2017-12-28 07:38:28 --> Total execution time: 0.0614
INFO - 2017-12-28 07:38:29 --> Config Class Initialized
INFO - 2017-12-28 07:38:29 --> Hooks Class Initialized
DEBUG - 2017-12-28 07:38:29 --> UTF-8 Support Enabled
INFO - 2017-12-28 07:38:29 --> Utf8 Class Initialized
INFO - 2017-12-28 07:38:29 --> URI Class Initialized
INFO - 2017-12-28 07:38:29 --> Router Class Initialized
INFO - 2017-12-28 07:38:29 --> Output Class Initialized
INFO - 2017-12-28 07:38:29 --> Security Class Initialized
DEBUG - 2017-12-28 07:38:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 07:38:29 --> Input Class Initialized
INFO - 2017-12-28 07:38:29 --> Language Class Initialized
INFO - 2017-12-28 07:38:29 --> Loader Class Initialized
INFO - 2017-12-28 07:38:29 --> Helper loaded: url_helper
INFO - 2017-12-28 07:38:29 --> Helper loaded: form_helper
INFO - 2017-12-28 07:38:29 --> Database Driver Class Initialized
DEBUG - 2017-12-28 07:38:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 07:38:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 07:38:29 --> Form Validation Class Initialized
INFO - 2017-12-28 07:38:29 --> Model Class Initialized
INFO - 2017-12-28 07:38:29 --> Controller Class Initialized
INFO - 2017-12-28 07:38:29 --> Model Class Initialized
INFO - 2017-12-28 07:38:29 --> Model Class Initialized
INFO - 2017-12-28 07:38:29 --> Model Class Initialized
INFO - 2017-12-28 07:38:29 --> Model Class Initialized
DEBUG - 2017-12-28 07:38:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:14:00 --> Config Class Initialized
INFO - 2017-12-28 19:14:00 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:14:00 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:14:00 --> Utf8 Class Initialized
INFO - 2017-12-28 19:14:00 --> URI Class Initialized
INFO - 2017-12-28 19:14:00 --> Router Class Initialized
INFO - 2017-12-28 19:14:00 --> Output Class Initialized
INFO - 2017-12-28 19:14:00 --> Security Class Initialized
DEBUG - 2017-12-28 19:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:14:00 --> Input Class Initialized
INFO - 2017-12-28 19:14:00 --> Language Class Initialized
INFO - 2017-12-28 19:14:00 --> Loader Class Initialized
INFO - 2017-12-28 19:14:00 --> Helper loaded: url_helper
INFO - 2017-12-28 19:14:00 --> Helper loaded: form_helper
INFO - 2017-12-28 19:14:00 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:14:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:14:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:14:00 --> Form Validation Class Initialized
INFO - 2017-12-28 19:14:00 --> Model Class Initialized
INFO - 2017-12-28 19:14:00 --> Controller Class Initialized
INFO - 2017-12-28 19:14:00 --> Model Class Initialized
INFO - 2017-12-28 19:14:00 --> Model Class Initialized
INFO - 2017-12-28 19:14:00 --> Model Class Initialized
INFO - 2017-12-28 19:14:00 --> Model Class Initialized
DEBUG - 2017-12-28 19:14:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:14:00 --> Config Class Initialized
INFO - 2017-12-28 19:14:00 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:14:00 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:14:00 --> Utf8 Class Initialized
INFO - 2017-12-28 19:14:00 --> URI Class Initialized
INFO - 2017-12-28 19:14:00 --> Router Class Initialized
INFO - 2017-12-28 19:14:00 --> Output Class Initialized
INFO - 2017-12-28 19:14:00 --> Security Class Initialized
DEBUG - 2017-12-28 19:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:14:00 --> Input Class Initialized
INFO - 2017-12-28 19:14:00 --> Language Class Initialized
INFO - 2017-12-28 19:14:00 --> Loader Class Initialized
INFO - 2017-12-28 19:14:00 --> Helper loaded: url_helper
INFO - 2017-12-28 19:14:00 --> Helper loaded: form_helper
INFO - 2017-12-28 19:14:00 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:14:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:14:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:14:00 --> Form Validation Class Initialized
INFO - 2017-12-28 19:14:00 --> Model Class Initialized
INFO - 2017-12-28 19:14:00 --> Controller Class Initialized
INFO - 2017-12-28 19:14:00 --> Model Class Initialized
DEBUG - 2017-12-28 19:14:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:14:00 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 19:14:00 --> Final output sent to browser
DEBUG - 2017-12-28 19:14:00 --> Total execution time: 0.1268
INFO - 2017-12-28 19:14:01 --> Config Class Initialized
INFO - 2017-12-28 19:14:01 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:14:02 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:14:02 --> Utf8 Class Initialized
INFO - 2017-12-28 19:14:02 --> URI Class Initialized
INFO - 2017-12-28 19:14:02 --> Router Class Initialized
INFO - 2017-12-28 19:14:02 --> Output Class Initialized
INFO - 2017-12-28 19:14:02 --> Security Class Initialized
DEBUG - 2017-12-28 19:14:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:14:02 --> Input Class Initialized
INFO - 2017-12-28 19:14:02 --> Language Class Initialized
INFO - 2017-12-28 19:14:02 --> Loader Class Initialized
INFO - 2017-12-28 19:14:02 --> Helper loaded: url_helper
INFO - 2017-12-28 19:14:02 --> Helper loaded: form_helper
INFO - 2017-12-28 19:14:02 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:14:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:14:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:14:02 --> Form Validation Class Initialized
INFO - 2017-12-28 19:14:02 --> Model Class Initialized
INFO - 2017-12-28 19:14:02 --> Controller Class Initialized
INFO - 2017-12-28 19:14:02 --> Model Class Initialized
DEBUG - 2017-12-28 19:14:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:14:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-12-28 19:14:02 --> Config Class Initialized
INFO - 2017-12-28 19:14:02 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:14:02 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:14:02 --> Utf8 Class Initialized
INFO - 2017-12-28 19:14:02 --> URI Class Initialized
DEBUG - 2017-12-28 19:14:02 --> No URI present. Default controller set.
INFO - 2017-12-28 19:14:02 --> Router Class Initialized
INFO - 2017-12-28 19:14:02 --> Output Class Initialized
INFO - 2017-12-28 19:14:02 --> Security Class Initialized
DEBUG - 2017-12-28 19:14:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:14:02 --> Input Class Initialized
INFO - 2017-12-28 19:14:02 --> Language Class Initialized
INFO - 2017-12-28 19:14:02 --> Loader Class Initialized
INFO - 2017-12-28 19:14:02 --> Helper loaded: url_helper
INFO - 2017-12-28 19:14:02 --> Helper loaded: form_helper
INFO - 2017-12-28 19:14:02 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:14:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:14:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:14:02 --> Form Validation Class Initialized
INFO - 2017-12-28 19:14:02 --> Model Class Initialized
INFO - 2017-12-28 19:14:02 --> Controller Class Initialized
INFO - 2017-12-28 19:14:02 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 19:14:02 --> Final output sent to browser
DEBUG - 2017-12-28 19:14:02 --> Total execution time: 0.0754
INFO - 2017-12-28 19:14:04 --> Config Class Initialized
INFO - 2017-12-28 19:14:04 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:14:04 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:14:04 --> Utf8 Class Initialized
INFO - 2017-12-28 19:14:04 --> URI Class Initialized
INFO - 2017-12-28 19:14:04 --> Router Class Initialized
INFO - 2017-12-28 19:14:04 --> Output Class Initialized
INFO - 2017-12-28 19:14:04 --> Security Class Initialized
DEBUG - 2017-12-28 19:14:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:14:04 --> Input Class Initialized
INFO - 2017-12-28 19:14:04 --> Language Class Initialized
INFO - 2017-12-28 19:14:04 --> Loader Class Initialized
INFO - 2017-12-28 19:14:04 --> Helper loaded: url_helper
INFO - 2017-12-28 19:14:04 --> Helper loaded: form_helper
INFO - 2017-12-28 19:14:04 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:14:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:14:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:14:04 --> Form Validation Class Initialized
INFO - 2017-12-28 19:14:04 --> Model Class Initialized
INFO - 2017-12-28 19:14:04 --> Controller Class Initialized
INFO - 2017-12-28 19:14:04 --> Model Class Initialized
INFO - 2017-12-28 19:14:04 --> Model Class Initialized
INFO - 2017-12-28 19:14:04 --> Model Class Initialized
INFO - 2017-12-28 19:14:04 --> Model Class Initialized
DEBUG - 2017-12-28 19:14:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:14:04 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 19:14:04 --> Final output sent to browser
DEBUG - 2017-12-28 19:14:04 --> Total execution time: 0.0657
INFO - 2017-12-28 19:14:04 --> Config Class Initialized
INFO - 2017-12-28 19:14:04 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:14:04 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:14:04 --> Utf8 Class Initialized
INFO - 2017-12-28 19:14:04 --> URI Class Initialized
INFO - 2017-12-28 19:14:04 --> Router Class Initialized
INFO - 2017-12-28 19:14:04 --> Output Class Initialized
INFO - 2017-12-28 19:14:04 --> Security Class Initialized
DEBUG - 2017-12-28 19:14:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:14:04 --> Input Class Initialized
INFO - 2017-12-28 19:14:04 --> Language Class Initialized
INFO - 2017-12-28 19:14:04 --> Loader Class Initialized
INFO - 2017-12-28 19:14:04 --> Helper loaded: url_helper
INFO - 2017-12-28 19:14:04 --> Helper loaded: form_helper
INFO - 2017-12-28 19:14:04 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:14:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:14:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:14:04 --> Form Validation Class Initialized
INFO - 2017-12-28 19:14:04 --> Model Class Initialized
INFO - 2017-12-28 19:14:04 --> Controller Class Initialized
INFO - 2017-12-28 19:14:04 --> Model Class Initialized
INFO - 2017-12-28 19:14:04 --> Model Class Initialized
INFO - 2017-12-28 19:14:04 --> Model Class Initialized
INFO - 2017-12-28 19:14:04 --> Model Class Initialized
DEBUG - 2017-12-28 19:14:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:14:06 --> Config Class Initialized
INFO - 2017-12-28 19:14:06 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:14:06 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:14:06 --> Utf8 Class Initialized
INFO - 2017-12-28 19:14:06 --> URI Class Initialized
INFO - 2017-12-28 19:14:06 --> Router Class Initialized
INFO - 2017-12-28 19:14:06 --> Output Class Initialized
INFO - 2017-12-28 19:14:06 --> Security Class Initialized
DEBUG - 2017-12-28 19:14:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:14:06 --> Input Class Initialized
INFO - 2017-12-28 19:14:06 --> Language Class Initialized
INFO - 2017-12-28 19:14:06 --> Loader Class Initialized
INFO - 2017-12-28 19:14:06 --> Helper loaded: url_helper
INFO - 2017-12-28 19:14:06 --> Helper loaded: form_helper
INFO - 2017-12-28 19:14:06 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:14:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:14:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:14:06 --> Form Validation Class Initialized
INFO - 2017-12-28 19:14:06 --> Model Class Initialized
INFO - 2017-12-28 19:14:06 --> Controller Class Initialized
INFO - 2017-12-28 19:14:06 --> Model Class Initialized
INFO - 2017-12-28 19:14:06 --> Model Class Initialized
INFO - 2017-12-28 19:14:06 --> Model Class Initialized
INFO - 2017-12-28 19:14:06 --> Model Class Initialized
DEBUG - 2017-12-28 19:14:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:14:06 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 19:14:06 --> Final output sent to browser
DEBUG - 2017-12-28 19:14:06 --> Total execution time: 0.0559
INFO - 2017-12-28 19:14:06 --> Config Class Initialized
INFO - 2017-12-28 19:14:06 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:14:06 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:14:06 --> Utf8 Class Initialized
INFO - 2017-12-28 19:14:06 --> URI Class Initialized
INFO - 2017-12-28 19:14:06 --> Router Class Initialized
INFO - 2017-12-28 19:14:06 --> Output Class Initialized
INFO - 2017-12-28 19:14:06 --> Security Class Initialized
DEBUG - 2017-12-28 19:14:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:14:06 --> Input Class Initialized
INFO - 2017-12-28 19:14:06 --> Language Class Initialized
INFO - 2017-12-28 19:14:06 --> Loader Class Initialized
INFO - 2017-12-28 19:14:06 --> Helper loaded: url_helper
INFO - 2017-12-28 19:14:06 --> Helper loaded: form_helper
INFO - 2017-12-28 19:14:06 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:14:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:14:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:14:06 --> Form Validation Class Initialized
INFO - 2017-12-28 19:14:06 --> Model Class Initialized
INFO - 2017-12-28 19:14:06 --> Controller Class Initialized
INFO - 2017-12-28 19:14:06 --> Model Class Initialized
INFO - 2017-12-28 19:14:06 --> Model Class Initialized
INFO - 2017-12-28 19:14:06 --> Model Class Initialized
INFO - 2017-12-28 19:14:06 --> Model Class Initialized
DEBUG - 2017-12-28 19:14:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:14:07 --> Config Class Initialized
INFO - 2017-12-28 19:14:07 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:14:07 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:14:07 --> Utf8 Class Initialized
INFO - 2017-12-28 19:14:07 --> URI Class Initialized
INFO - 2017-12-28 19:14:07 --> Router Class Initialized
INFO - 2017-12-28 19:14:07 --> Output Class Initialized
INFO - 2017-12-28 19:14:07 --> Security Class Initialized
DEBUG - 2017-12-28 19:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:14:07 --> Input Class Initialized
INFO - 2017-12-28 19:14:07 --> Language Class Initialized
INFO - 2017-12-28 19:14:07 --> Loader Class Initialized
INFO - 2017-12-28 19:14:07 --> Helper loaded: url_helper
INFO - 2017-12-28 19:14:07 --> Helper loaded: form_helper
INFO - 2017-12-28 19:14:07 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:14:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:14:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:14:07 --> Form Validation Class Initialized
INFO - 2017-12-28 19:14:07 --> Model Class Initialized
INFO - 2017-12-28 19:14:07 --> Controller Class Initialized
INFO - 2017-12-28 19:14:07 --> Model Class Initialized
INFO - 2017-12-28 19:14:07 --> Model Class Initialized
INFO - 2017-12-28 19:14:07 --> Model Class Initialized
INFO - 2017-12-28 19:14:07 --> Model Class Initialized
DEBUG - 2017-12-28 19:14:07 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2017-12-28 19:14:07 --> Severity: Notice --> Undefined variable: gasto_tipo D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verGastosProyecto.php 46
ERROR - 2017-12-28 19:14:07 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verGastosProyecto.php 46
ERROR - 2017-12-28 19:14:07 --> Severity: Notice --> Undefined variable: proveedores D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verGastosProyecto.php 78
ERROR - 2017-12-28 19:14:07 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\verGastosProyecto.php 78
INFO - 2017-12-28 19:14:07 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 19:14:07 --> Final output sent to browser
DEBUG - 2017-12-28 19:14:07 --> Total execution time: 0.0839
INFO - 2017-12-28 19:14:07 --> Config Class Initialized
INFO - 2017-12-28 19:14:07 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:14:07 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:14:07 --> Utf8 Class Initialized
INFO - 2017-12-28 19:14:07 --> URI Class Initialized
INFO - 2017-12-28 19:14:07 --> Router Class Initialized
INFO - 2017-12-28 19:14:07 --> Output Class Initialized
INFO - 2017-12-28 19:14:07 --> Security Class Initialized
DEBUG - 2017-12-28 19:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:14:07 --> Input Class Initialized
INFO - 2017-12-28 19:14:07 --> Language Class Initialized
INFO - 2017-12-28 19:14:07 --> Loader Class Initialized
INFO - 2017-12-28 19:14:07 --> Helper loaded: url_helper
INFO - 2017-12-28 19:14:07 --> Helper loaded: form_helper
INFO - 2017-12-28 19:14:07 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:14:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:14:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:14:07 --> Form Validation Class Initialized
INFO - 2017-12-28 19:14:07 --> Model Class Initialized
INFO - 2017-12-28 19:14:07 --> Controller Class Initialized
INFO - 2017-12-28 19:14:07 --> Model Class Initialized
INFO - 2017-12-28 19:14:07 --> Model Class Initialized
INFO - 2017-12-28 19:14:07 --> Model Class Initialized
INFO - 2017-12-28 19:14:07 --> Model Class Initialized
DEBUG - 2017-12-28 19:14:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:15:02 --> Config Class Initialized
INFO - 2017-12-28 19:15:02 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:15:02 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:15:02 --> Utf8 Class Initialized
INFO - 2017-12-28 19:15:02 --> URI Class Initialized
INFO - 2017-12-28 19:15:02 --> Router Class Initialized
INFO - 2017-12-28 19:15:02 --> Output Class Initialized
INFO - 2017-12-28 19:15:02 --> Security Class Initialized
DEBUG - 2017-12-28 19:15:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:15:02 --> Input Class Initialized
INFO - 2017-12-28 19:15:02 --> Language Class Initialized
INFO - 2017-12-28 19:15:02 --> Loader Class Initialized
INFO - 2017-12-28 19:15:02 --> Helper loaded: url_helper
INFO - 2017-12-28 19:15:02 --> Helper loaded: form_helper
INFO - 2017-12-28 19:15:02 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:15:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:15:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:15:02 --> Form Validation Class Initialized
INFO - 2017-12-28 19:15:02 --> Model Class Initialized
INFO - 2017-12-28 19:15:02 --> Controller Class Initialized
INFO - 2017-12-28 19:15:02 --> Model Class Initialized
INFO - 2017-12-28 19:15:02 --> Model Class Initialized
INFO - 2017-12-28 19:15:02 --> Model Class Initialized
INFO - 2017-12-28 19:15:02 --> Model Class Initialized
DEBUG - 2017-12-28 19:15:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:15:02 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 19:15:02 --> Final output sent to browser
DEBUG - 2017-12-28 19:15:02 --> Total execution time: 0.0417
INFO - 2017-12-28 19:15:02 --> Config Class Initialized
INFO - 2017-12-28 19:15:02 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:15:02 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:15:02 --> Utf8 Class Initialized
INFO - 2017-12-28 19:15:02 --> URI Class Initialized
INFO - 2017-12-28 19:15:02 --> Router Class Initialized
INFO - 2017-12-28 19:15:02 --> Output Class Initialized
INFO - 2017-12-28 19:15:02 --> Security Class Initialized
DEBUG - 2017-12-28 19:15:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:15:02 --> Input Class Initialized
INFO - 2017-12-28 19:15:02 --> Language Class Initialized
INFO - 2017-12-28 19:15:02 --> Loader Class Initialized
INFO - 2017-12-28 19:15:02 --> Helper loaded: url_helper
INFO - 2017-12-28 19:15:02 --> Helper loaded: form_helper
INFO - 2017-12-28 19:15:02 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:15:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:15:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:15:02 --> Form Validation Class Initialized
INFO - 2017-12-28 19:15:02 --> Model Class Initialized
INFO - 2017-12-28 19:15:02 --> Controller Class Initialized
INFO - 2017-12-28 19:15:02 --> Model Class Initialized
INFO - 2017-12-28 19:15:02 --> Model Class Initialized
INFO - 2017-12-28 19:15:02 --> Model Class Initialized
INFO - 2017-12-28 19:15:02 --> Model Class Initialized
DEBUG - 2017-12-28 19:15:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:22:20 --> Config Class Initialized
INFO - 2017-12-28 19:22:20 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:22:20 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:22:20 --> Utf8 Class Initialized
INFO - 2017-12-28 19:22:20 --> URI Class Initialized
INFO - 2017-12-28 19:22:20 --> Router Class Initialized
INFO - 2017-12-28 19:22:20 --> Output Class Initialized
INFO - 2017-12-28 19:22:20 --> Security Class Initialized
DEBUG - 2017-12-28 19:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:22:20 --> Input Class Initialized
INFO - 2017-12-28 19:22:20 --> Language Class Initialized
INFO - 2017-12-28 19:22:20 --> Loader Class Initialized
INFO - 2017-12-28 19:22:20 --> Helper loaded: url_helper
INFO - 2017-12-28 19:22:20 --> Helper loaded: form_helper
INFO - 2017-12-28 19:22:20 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:22:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:22:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:22:20 --> Form Validation Class Initialized
INFO - 2017-12-28 19:22:20 --> Model Class Initialized
INFO - 2017-12-28 19:22:20 --> Controller Class Initialized
INFO - 2017-12-28 19:22:20 --> Model Class Initialized
INFO - 2017-12-28 19:22:20 --> Model Class Initialized
INFO - 2017-12-28 19:22:20 --> Model Class Initialized
INFO - 2017-12-28 19:22:20 --> Model Class Initialized
DEBUG - 2017-12-28 19:22:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:22:20 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 19:22:20 --> Final output sent to browser
DEBUG - 2017-12-28 19:22:20 --> Total execution time: 0.0469
INFO - 2017-12-28 19:22:20 --> Config Class Initialized
INFO - 2017-12-28 19:22:20 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:22:20 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:22:20 --> Utf8 Class Initialized
INFO - 2017-12-28 19:22:20 --> URI Class Initialized
INFO - 2017-12-28 19:22:20 --> Router Class Initialized
INFO - 2017-12-28 19:22:20 --> Output Class Initialized
INFO - 2017-12-28 19:22:20 --> Security Class Initialized
DEBUG - 2017-12-28 19:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:22:20 --> Input Class Initialized
INFO - 2017-12-28 19:22:20 --> Language Class Initialized
INFO - 2017-12-28 19:22:20 --> Loader Class Initialized
INFO - 2017-12-28 19:22:20 --> Helper loaded: url_helper
INFO - 2017-12-28 19:22:20 --> Helper loaded: form_helper
INFO - 2017-12-28 19:22:20 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:22:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:22:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:22:20 --> Form Validation Class Initialized
INFO - 2017-12-28 19:22:20 --> Model Class Initialized
INFO - 2017-12-28 19:22:20 --> Controller Class Initialized
INFO - 2017-12-28 19:22:20 --> Model Class Initialized
INFO - 2017-12-28 19:22:20 --> Model Class Initialized
INFO - 2017-12-28 19:22:20 --> Model Class Initialized
INFO - 2017-12-28 19:22:20 --> Model Class Initialized
DEBUG - 2017-12-28 19:22:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:22:58 --> Config Class Initialized
INFO - 2017-12-28 19:22:58 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:22:58 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:22:58 --> Utf8 Class Initialized
INFO - 2017-12-28 19:22:58 --> URI Class Initialized
INFO - 2017-12-28 19:22:58 --> Router Class Initialized
INFO - 2017-12-28 19:22:58 --> Output Class Initialized
INFO - 2017-12-28 19:22:58 --> Security Class Initialized
DEBUG - 2017-12-28 19:22:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:22:58 --> Input Class Initialized
INFO - 2017-12-28 19:22:58 --> Language Class Initialized
INFO - 2017-12-28 19:22:58 --> Loader Class Initialized
INFO - 2017-12-28 19:22:58 --> Helper loaded: url_helper
INFO - 2017-12-28 19:22:58 --> Helper loaded: form_helper
INFO - 2017-12-28 19:22:58 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:22:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:22:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:22:58 --> Form Validation Class Initialized
INFO - 2017-12-28 19:22:58 --> Model Class Initialized
INFO - 2017-12-28 19:22:58 --> Controller Class Initialized
INFO - 2017-12-28 19:22:58 --> Model Class Initialized
INFO - 2017-12-28 19:22:58 --> Model Class Initialized
INFO - 2017-12-28 19:22:58 --> Model Class Initialized
INFO - 2017-12-28 19:22:58 --> Model Class Initialized
DEBUG - 2017-12-28 19:22:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:22:58 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 19:22:58 --> Final output sent to browser
DEBUG - 2017-12-28 19:22:58 --> Total execution time: 0.0882
INFO - 2017-12-28 19:22:58 --> Config Class Initialized
INFO - 2017-12-28 19:22:58 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:22:58 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:22:58 --> Utf8 Class Initialized
INFO - 2017-12-28 19:22:58 --> URI Class Initialized
INFO - 2017-12-28 19:22:58 --> Router Class Initialized
INFO - 2017-12-28 19:22:58 --> Output Class Initialized
INFO - 2017-12-28 19:22:58 --> Security Class Initialized
DEBUG - 2017-12-28 19:22:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:22:58 --> Input Class Initialized
INFO - 2017-12-28 19:22:58 --> Language Class Initialized
INFO - 2017-12-28 19:22:58 --> Loader Class Initialized
INFO - 2017-12-28 19:22:58 --> Helper loaded: url_helper
INFO - 2017-12-28 19:22:58 --> Helper loaded: form_helper
INFO - 2017-12-28 19:22:58 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:22:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:22:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:22:58 --> Form Validation Class Initialized
INFO - 2017-12-28 19:22:58 --> Model Class Initialized
INFO - 2017-12-28 19:22:58 --> Controller Class Initialized
INFO - 2017-12-28 19:22:58 --> Model Class Initialized
INFO - 2017-12-28 19:22:58 --> Model Class Initialized
INFO - 2017-12-28 19:22:58 --> Model Class Initialized
INFO - 2017-12-28 19:22:58 --> Model Class Initialized
DEBUG - 2017-12-28 19:22:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:24:35 --> Config Class Initialized
INFO - 2017-12-28 19:24:35 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:24:35 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:24:35 --> Utf8 Class Initialized
INFO - 2017-12-28 19:24:35 --> URI Class Initialized
INFO - 2017-12-28 19:24:35 --> Router Class Initialized
INFO - 2017-12-28 19:24:35 --> Output Class Initialized
INFO - 2017-12-28 19:24:35 --> Security Class Initialized
DEBUG - 2017-12-28 19:24:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:24:35 --> Input Class Initialized
INFO - 2017-12-28 19:24:35 --> Language Class Initialized
INFO - 2017-12-28 19:24:35 --> Loader Class Initialized
INFO - 2017-12-28 19:24:35 --> Helper loaded: url_helper
INFO - 2017-12-28 19:24:35 --> Helper loaded: form_helper
INFO - 2017-12-28 19:24:35 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:24:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:24:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:24:35 --> Form Validation Class Initialized
INFO - 2017-12-28 19:24:35 --> Model Class Initialized
INFO - 2017-12-28 19:24:35 --> Controller Class Initialized
INFO - 2017-12-28 19:24:35 --> Model Class Initialized
INFO - 2017-12-28 19:24:35 --> Model Class Initialized
INFO - 2017-12-28 19:24:35 --> Model Class Initialized
INFO - 2017-12-28 19:24:35 --> Model Class Initialized
DEBUG - 2017-12-28 19:24:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:24:35 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 19:24:35 --> Final output sent to browser
DEBUG - 2017-12-28 19:24:35 --> Total execution time: 0.0656
INFO - 2017-12-28 19:24:35 --> Config Class Initialized
INFO - 2017-12-28 19:24:35 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:24:35 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:24:35 --> Utf8 Class Initialized
INFO - 2017-12-28 19:24:35 --> URI Class Initialized
INFO - 2017-12-28 19:24:35 --> Router Class Initialized
INFO - 2017-12-28 19:24:35 --> Output Class Initialized
INFO - 2017-12-28 19:24:35 --> Security Class Initialized
DEBUG - 2017-12-28 19:24:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:24:35 --> Input Class Initialized
INFO - 2017-12-28 19:24:35 --> Language Class Initialized
INFO - 2017-12-28 19:24:35 --> Loader Class Initialized
INFO - 2017-12-28 19:24:35 --> Helper loaded: url_helper
INFO - 2017-12-28 19:24:35 --> Helper loaded: form_helper
INFO - 2017-12-28 19:24:35 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:24:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:24:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:24:35 --> Form Validation Class Initialized
INFO - 2017-12-28 19:24:35 --> Model Class Initialized
INFO - 2017-12-28 19:24:35 --> Controller Class Initialized
INFO - 2017-12-28 19:24:35 --> Model Class Initialized
INFO - 2017-12-28 19:24:35 --> Model Class Initialized
INFO - 2017-12-28 19:24:35 --> Model Class Initialized
INFO - 2017-12-28 19:24:35 --> Model Class Initialized
DEBUG - 2017-12-28 19:24:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:24:48 --> Config Class Initialized
INFO - 2017-12-28 19:24:48 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:24:48 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:24:48 --> Utf8 Class Initialized
INFO - 2017-12-28 19:24:48 --> URI Class Initialized
INFO - 2017-12-28 19:24:48 --> Router Class Initialized
INFO - 2017-12-28 19:24:48 --> Output Class Initialized
INFO - 2017-12-28 19:24:48 --> Security Class Initialized
DEBUG - 2017-12-28 19:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:24:48 --> Input Class Initialized
INFO - 2017-12-28 19:24:48 --> Language Class Initialized
INFO - 2017-12-28 19:24:48 --> Loader Class Initialized
INFO - 2017-12-28 19:24:48 --> Helper loaded: url_helper
INFO - 2017-12-28 19:24:48 --> Helper loaded: form_helper
INFO - 2017-12-28 19:24:48 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:24:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:24:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:24:48 --> Form Validation Class Initialized
INFO - 2017-12-28 19:24:48 --> Model Class Initialized
INFO - 2017-12-28 19:24:48 --> Controller Class Initialized
INFO - 2017-12-28 19:24:48 --> Model Class Initialized
INFO - 2017-12-28 19:24:48 --> Model Class Initialized
INFO - 2017-12-28 19:24:48 --> Model Class Initialized
INFO - 2017-12-28 19:24:48 --> Model Class Initialized
DEBUG - 2017-12-28 19:24:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:24:48 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 19:24:48 --> Final output sent to browser
DEBUG - 2017-12-28 19:24:48 --> Total execution time: 0.0996
INFO - 2017-12-28 19:24:50 --> Config Class Initialized
INFO - 2017-12-28 19:24:50 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:24:50 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:24:50 --> Utf8 Class Initialized
INFO - 2017-12-28 19:24:50 --> URI Class Initialized
INFO - 2017-12-28 19:24:50 --> Router Class Initialized
INFO - 2017-12-28 19:24:50 --> Output Class Initialized
INFO - 2017-12-28 19:24:50 --> Security Class Initialized
DEBUG - 2017-12-28 19:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:24:50 --> Input Class Initialized
INFO - 2017-12-28 19:24:50 --> Language Class Initialized
INFO - 2017-12-28 19:24:50 --> Loader Class Initialized
INFO - 2017-12-28 19:24:50 --> Helper loaded: url_helper
INFO - 2017-12-28 19:24:50 --> Helper loaded: form_helper
INFO - 2017-12-28 19:24:50 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:24:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:24:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:24:50 --> Form Validation Class Initialized
INFO - 2017-12-28 19:24:50 --> Model Class Initialized
INFO - 2017-12-28 19:24:50 --> Controller Class Initialized
INFO - 2017-12-28 19:24:50 --> Model Class Initialized
INFO - 2017-12-28 19:24:50 --> Model Class Initialized
INFO - 2017-12-28 19:24:50 --> Model Class Initialized
INFO - 2017-12-28 19:24:50 --> Model Class Initialized
DEBUG - 2017-12-28 19:24:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:24:50 --> Config Class Initialized
INFO - 2017-12-28 19:24:50 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:24:50 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:24:50 --> Utf8 Class Initialized
INFO - 2017-12-28 19:24:50 --> URI Class Initialized
INFO - 2017-12-28 19:24:50 --> Router Class Initialized
INFO - 2017-12-28 19:24:50 --> Output Class Initialized
INFO - 2017-12-28 19:24:50 --> Security Class Initialized
DEBUG - 2017-12-28 19:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:24:50 --> Input Class Initialized
INFO - 2017-12-28 19:24:50 --> Language Class Initialized
ERROR - 2017-12-28 19:24:50 --> 404 Page Not Found: Faviconico/index
INFO - 2017-12-28 19:25:35 --> Config Class Initialized
INFO - 2017-12-28 19:25:35 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:25:35 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:25:35 --> Utf8 Class Initialized
INFO - 2017-12-28 19:25:35 --> URI Class Initialized
INFO - 2017-12-28 19:25:35 --> Router Class Initialized
INFO - 2017-12-28 19:25:35 --> Output Class Initialized
INFO - 2017-12-28 19:25:35 --> Security Class Initialized
DEBUG - 2017-12-28 19:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:25:35 --> Input Class Initialized
INFO - 2017-12-28 19:25:35 --> Language Class Initialized
INFO - 2017-12-28 19:25:35 --> Loader Class Initialized
INFO - 2017-12-28 19:25:35 --> Helper loaded: url_helper
INFO - 2017-12-28 19:25:35 --> Helper loaded: form_helper
INFO - 2017-12-28 19:25:35 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:25:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:25:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:25:35 --> Form Validation Class Initialized
INFO - 2017-12-28 19:25:35 --> Model Class Initialized
INFO - 2017-12-28 19:25:35 --> Controller Class Initialized
INFO - 2017-12-28 19:25:35 --> Model Class Initialized
INFO - 2017-12-28 19:25:35 --> Model Class Initialized
INFO - 2017-12-28 19:25:35 --> Model Class Initialized
INFO - 2017-12-28 19:25:35 --> Model Class Initialized
DEBUG - 2017-12-28 19:25:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:25:35 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 19:25:35 --> Final output sent to browser
DEBUG - 2017-12-28 19:25:35 --> Total execution time: 0.0820
INFO - 2017-12-28 19:25:37 --> Config Class Initialized
INFO - 2017-12-28 19:25:37 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:25:37 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:25:37 --> Utf8 Class Initialized
INFO - 2017-12-28 19:25:37 --> URI Class Initialized
INFO - 2017-12-28 19:25:37 --> Router Class Initialized
INFO - 2017-12-28 19:25:37 --> Output Class Initialized
INFO - 2017-12-28 19:25:37 --> Security Class Initialized
DEBUG - 2017-12-28 19:25:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:25:37 --> Input Class Initialized
INFO - 2017-12-28 19:25:37 --> Language Class Initialized
INFO - 2017-12-28 19:25:37 --> Loader Class Initialized
INFO - 2017-12-28 19:25:37 --> Helper loaded: url_helper
INFO - 2017-12-28 19:25:37 --> Helper loaded: form_helper
INFO - 2017-12-28 19:25:37 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:25:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:25:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:25:37 --> Form Validation Class Initialized
INFO - 2017-12-28 19:25:37 --> Model Class Initialized
INFO - 2017-12-28 19:25:37 --> Controller Class Initialized
INFO - 2017-12-28 19:25:37 --> Model Class Initialized
INFO - 2017-12-28 19:25:37 --> Model Class Initialized
INFO - 2017-12-28 19:25:37 --> Model Class Initialized
INFO - 2017-12-28 19:25:37 --> Model Class Initialized
DEBUG - 2017-12-28 19:25:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:25:37 --> Config Class Initialized
INFO - 2017-12-28 19:25:37 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:25:37 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:25:37 --> Utf8 Class Initialized
INFO - 2017-12-28 19:25:37 --> URI Class Initialized
INFO - 2017-12-28 19:25:37 --> Router Class Initialized
INFO - 2017-12-28 19:25:37 --> Output Class Initialized
INFO - 2017-12-28 19:25:37 --> Security Class Initialized
DEBUG - 2017-12-28 19:25:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:25:37 --> Input Class Initialized
INFO - 2017-12-28 19:25:37 --> Language Class Initialized
ERROR - 2017-12-28 19:25:37 --> 404 Page Not Found: Faviconico/index
INFO - 2017-12-28 19:35:08 --> Config Class Initialized
INFO - 2017-12-28 19:35:08 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:35:08 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:35:08 --> Utf8 Class Initialized
INFO - 2017-12-28 19:35:08 --> URI Class Initialized
INFO - 2017-12-28 19:35:08 --> Router Class Initialized
INFO - 2017-12-28 19:35:08 --> Output Class Initialized
INFO - 2017-12-28 19:35:08 --> Security Class Initialized
DEBUG - 2017-12-28 19:35:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:35:08 --> Input Class Initialized
INFO - 2017-12-28 19:35:08 --> Language Class Initialized
INFO - 2017-12-28 19:35:08 --> Loader Class Initialized
INFO - 2017-12-28 19:35:08 --> Helper loaded: url_helper
INFO - 2017-12-28 19:35:08 --> Helper loaded: form_helper
INFO - 2017-12-28 19:35:08 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:35:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:35:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:35:08 --> Form Validation Class Initialized
INFO - 2017-12-28 19:35:08 --> Model Class Initialized
INFO - 2017-12-28 19:35:08 --> Controller Class Initialized
INFO - 2017-12-28 19:35:08 --> Model Class Initialized
INFO - 2017-12-28 19:35:08 --> Model Class Initialized
INFO - 2017-12-28 19:35:08 --> Model Class Initialized
INFO - 2017-12-28 19:35:08 --> Model Class Initialized
DEBUG - 2017-12-28 19:35:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:35:08 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 19:35:08 --> Final output sent to browser
DEBUG - 2017-12-28 19:35:08 --> Total execution time: 0.0627
INFO - 2017-12-28 19:35:08 --> Config Class Initialized
INFO - 2017-12-28 19:35:08 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:35:08 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:35:08 --> Utf8 Class Initialized
INFO - 2017-12-28 19:35:08 --> URI Class Initialized
INFO - 2017-12-28 19:35:08 --> Router Class Initialized
INFO - 2017-12-28 19:35:08 --> Output Class Initialized
INFO - 2017-12-28 19:35:08 --> Security Class Initialized
DEBUG - 2017-12-28 19:35:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:35:08 --> Input Class Initialized
INFO - 2017-12-28 19:35:08 --> Language Class Initialized
INFO - 2017-12-28 19:35:08 --> Loader Class Initialized
INFO - 2017-12-28 19:35:08 --> Helper loaded: url_helper
INFO - 2017-12-28 19:35:08 --> Helper loaded: form_helper
INFO - 2017-12-28 19:35:08 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:35:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:35:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:35:08 --> Form Validation Class Initialized
INFO - 2017-12-28 19:35:08 --> Model Class Initialized
INFO - 2017-12-28 19:35:08 --> Controller Class Initialized
INFO - 2017-12-28 19:35:08 --> Model Class Initialized
INFO - 2017-12-28 19:35:08 --> Model Class Initialized
INFO - 2017-12-28 19:35:08 --> Model Class Initialized
INFO - 2017-12-28 19:35:08 --> Model Class Initialized
DEBUG - 2017-12-28 19:35:08 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2017-12-28 19:35:08 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\instateccr\instatec_sys\database\DB_query_builder.php 683
ERROR - 2017-12-28 19:35:08 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT *
FROM `proyecto_gasto`
LEFT JOIN `proyecto_gasto_tipo` ON `proyecto_gasto_tipo`.`proyecto_gasto_tipo_id` = `proyecto_gasto`.`proyecto_gasto_tipo_id`
LEFT JOIN `proyecto_gasto_monto` ON `proyecto_gasto_monto`.`proyecto_gasto_id` = `proyecto_gasto`.`proyecto_gasto_id` AND `proyecto_gasto_monto`.`estado_registro` = 1
LEFT JOIN `proyecto_gasto_detalle` ON `proyecto_gasto_detalle`.`proyecto_gasto_id` = `proyecto_gasto`.`proyecto_gasto_id`
LEFT JOIN `proveedor` ON `proveedor`.`proveedor_id` = `proyecto_gasto_detalle`.`proveedor_id`
WHERE `proyecto_gasto`.`proyecto_id` = '1'
AND `proyecto_gasto`.`fecha_gasto` = `Array`
ORDER BY `proyecto_gasto`.`fecha_registro` ASC
INFO - 2017-12-28 19:35:08 --> Language file loaded: language/english/db_lang.php
INFO - 2017-12-28 19:35:13 --> Config Class Initialized
INFO - 2017-12-28 19:35:13 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:35:13 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:35:13 --> Utf8 Class Initialized
INFO - 2017-12-28 19:35:13 --> URI Class Initialized
INFO - 2017-12-28 19:35:13 --> Router Class Initialized
INFO - 2017-12-28 19:35:13 --> Output Class Initialized
INFO - 2017-12-28 19:35:13 --> Security Class Initialized
DEBUG - 2017-12-28 19:35:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:35:13 --> Input Class Initialized
INFO - 2017-12-28 19:35:13 --> Language Class Initialized
INFO - 2017-12-28 19:35:13 --> Loader Class Initialized
INFO - 2017-12-28 19:35:13 --> Helper loaded: url_helper
INFO - 2017-12-28 19:35:13 --> Helper loaded: form_helper
INFO - 2017-12-28 19:35:13 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:35:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:35:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:35:13 --> Form Validation Class Initialized
INFO - 2017-12-28 19:35:13 --> Model Class Initialized
INFO - 2017-12-28 19:35:13 --> Controller Class Initialized
INFO - 2017-12-28 19:35:13 --> Model Class Initialized
INFO - 2017-12-28 19:35:13 --> Model Class Initialized
INFO - 2017-12-28 19:35:13 --> Model Class Initialized
INFO - 2017-12-28 19:35:13 --> Model Class Initialized
DEBUG - 2017-12-28 19:35:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:35:13 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 19:35:13 --> Final output sent to browser
DEBUG - 2017-12-28 19:35:13 --> Total execution time: 0.0606
INFO - 2017-12-28 19:35:17 --> Config Class Initialized
INFO - 2017-12-28 19:35:17 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:35:17 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:35:17 --> Utf8 Class Initialized
INFO - 2017-12-28 19:35:17 --> URI Class Initialized
INFO - 2017-12-28 19:35:17 --> Router Class Initialized
INFO - 2017-12-28 19:35:17 --> Output Class Initialized
INFO - 2017-12-28 19:35:17 --> Security Class Initialized
DEBUG - 2017-12-28 19:35:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:35:17 --> Input Class Initialized
INFO - 2017-12-28 19:35:17 --> Language Class Initialized
INFO - 2017-12-28 19:35:17 --> Loader Class Initialized
INFO - 2017-12-28 19:35:17 --> Helper loaded: url_helper
INFO - 2017-12-28 19:35:17 --> Helper loaded: form_helper
INFO - 2017-12-28 19:35:17 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:35:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:35:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:35:17 --> Form Validation Class Initialized
INFO - 2017-12-28 19:35:17 --> Model Class Initialized
INFO - 2017-12-28 19:35:17 --> Controller Class Initialized
INFO - 2017-12-28 19:35:17 --> Model Class Initialized
INFO - 2017-12-28 19:35:17 --> Model Class Initialized
INFO - 2017-12-28 19:35:17 --> Model Class Initialized
INFO - 2017-12-28 19:35:17 --> Model Class Initialized
DEBUG - 2017-12-28 19:35:17 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2017-12-28 19:35:17 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\instateccr\instatec_sys\database\DB_query_builder.php 683
ERROR - 2017-12-28 19:35:17 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT *
FROM `proyecto_gasto`
LEFT JOIN `proyecto_gasto_tipo` ON `proyecto_gasto_tipo`.`proyecto_gasto_tipo_id` = `proyecto_gasto`.`proyecto_gasto_tipo_id`
LEFT JOIN `proyecto_gasto_monto` ON `proyecto_gasto_monto`.`proyecto_gasto_id` = `proyecto_gasto`.`proyecto_gasto_id` AND `proyecto_gasto_monto`.`estado_registro` = 1
LEFT JOIN `proyecto_gasto_detalle` ON `proyecto_gasto_detalle`.`proyecto_gasto_id` = `proyecto_gasto`.`proyecto_gasto_id`
LEFT JOIN `proveedor` ON `proveedor`.`proveedor_id` = `proyecto_gasto_detalle`.`proveedor_id`
WHERE `proyecto_gasto`.`proyecto_id` = '1'
AND `proyecto_gasto`.`fecha_gasto` = `Array`
ORDER BY `proyecto_gasto`.`fecha_registro` ASC
INFO - 2017-12-28 19:35:17 --> Language file loaded: language/english/db_lang.php
INFO - 2017-12-28 19:35:17 --> Config Class Initialized
INFO - 2017-12-28 19:35:17 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:35:17 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:35:17 --> Utf8 Class Initialized
INFO - 2017-12-28 19:35:17 --> URI Class Initialized
INFO - 2017-12-28 19:35:17 --> Router Class Initialized
INFO - 2017-12-28 19:35:17 --> Output Class Initialized
INFO - 2017-12-28 19:35:17 --> Security Class Initialized
DEBUG - 2017-12-28 19:35:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:35:17 --> Input Class Initialized
INFO - 2017-12-28 19:35:17 --> Language Class Initialized
ERROR - 2017-12-28 19:35:17 --> 404 Page Not Found: Faviconico/index
INFO - 2017-12-28 19:35:42 --> Config Class Initialized
INFO - 2017-12-28 19:35:42 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:35:42 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:35:42 --> Utf8 Class Initialized
INFO - 2017-12-28 19:35:42 --> URI Class Initialized
INFO - 2017-12-28 19:35:42 --> Router Class Initialized
INFO - 2017-12-28 19:35:42 --> Output Class Initialized
INFO - 2017-12-28 19:35:42 --> Security Class Initialized
DEBUG - 2017-12-28 19:35:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:35:42 --> Input Class Initialized
INFO - 2017-12-28 19:35:42 --> Language Class Initialized
INFO - 2017-12-28 19:35:42 --> Loader Class Initialized
INFO - 2017-12-28 19:35:42 --> Helper loaded: url_helper
INFO - 2017-12-28 19:35:42 --> Helper loaded: form_helper
INFO - 2017-12-28 19:35:42 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:35:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:35:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:35:42 --> Form Validation Class Initialized
INFO - 2017-12-28 19:35:42 --> Model Class Initialized
INFO - 2017-12-28 19:35:42 --> Controller Class Initialized
INFO - 2017-12-28 19:35:42 --> Model Class Initialized
INFO - 2017-12-28 19:35:42 --> Model Class Initialized
INFO - 2017-12-28 19:35:42 --> Model Class Initialized
INFO - 2017-12-28 19:35:42 --> Model Class Initialized
DEBUG - 2017-12-28 19:35:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:35:42 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 19:35:42 --> Final output sent to browser
DEBUG - 2017-12-28 19:35:42 --> Total execution time: 0.0716
INFO - 2017-12-28 19:35:42 --> Config Class Initialized
INFO - 2017-12-28 19:35:42 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:35:42 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:35:42 --> Utf8 Class Initialized
INFO - 2017-12-28 19:35:42 --> URI Class Initialized
INFO - 2017-12-28 19:35:42 --> Router Class Initialized
INFO - 2017-12-28 19:35:42 --> Output Class Initialized
INFO - 2017-12-28 19:35:42 --> Security Class Initialized
DEBUG - 2017-12-28 19:35:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:35:42 --> Input Class Initialized
INFO - 2017-12-28 19:35:42 --> Language Class Initialized
INFO - 2017-12-28 19:35:42 --> Loader Class Initialized
INFO - 2017-12-28 19:35:42 --> Helper loaded: url_helper
INFO - 2017-12-28 19:35:42 --> Helper loaded: form_helper
INFO - 2017-12-28 19:35:42 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:35:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:35:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:35:42 --> Form Validation Class Initialized
INFO - 2017-12-28 19:35:42 --> Model Class Initialized
INFO - 2017-12-28 19:35:42 --> Controller Class Initialized
INFO - 2017-12-28 19:35:42 --> Model Class Initialized
INFO - 2017-12-28 19:35:42 --> Model Class Initialized
INFO - 2017-12-28 19:35:42 --> Model Class Initialized
INFO - 2017-12-28 19:35:42 --> Model Class Initialized
DEBUG - 2017-12-28 19:35:42 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2017-12-28 19:35:42 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\instateccr\instatec_sys\database\DB_query_builder.php 683
ERROR - 2017-12-28 19:35:42 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT *
FROM `proyecto_gasto`
LEFT JOIN `proyecto_gasto_tipo` ON `proyecto_gasto_tipo`.`proyecto_gasto_tipo_id` = `proyecto_gasto`.`proyecto_gasto_tipo_id`
LEFT JOIN `proyecto_gasto_monto` ON `proyecto_gasto_monto`.`proyecto_gasto_id` = `proyecto_gasto`.`proyecto_gasto_id` AND `proyecto_gasto_monto`.`estado_registro` = 1
LEFT JOIN `proyecto_gasto_detalle` ON `proyecto_gasto_detalle`.`proyecto_gasto_id` = `proyecto_gasto`.`proyecto_gasto_id`
LEFT JOIN `proveedor` ON `proveedor`.`proveedor_id` = `proyecto_gasto_detalle`.`proveedor_id`
WHERE `proyecto_gasto`.`proyecto_id` = '1'
AND `proyecto_gasto`.`fecha_gasto` = `Array`
ORDER BY `proyecto_gasto`.`fecha_registro` ASC
INFO - 2017-12-28 19:35:42 --> Language file loaded: language/english/db_lang.php
INFO - 2017-12-28 19:35:43 --> Config Class Initialized
INFO - 2017-12-28 19:35:43 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:35:43 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:35:43 --> Utf8 Class Initialized
INFO - 2017-12-28 19:35:43 --> URI Class Initialized
INFO - 2017-12-28 19:35:43 --> Router Class Initialized
INFO - 2017-12-28 19:35:43 --> Output Class Initialized
INFO - 2017-12-28 19:35:43 --> Security Class Initialized
DEBUG - 2017-12-28 19:35:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:35:43 --> Input Class Initialized
INFO - 2017-12-28 19:35:43 --> Language Class Initialized
INFO - 2017-12-28 19:35:43 --> Loader Class Initialized
INFO - 2017-12-28 19:35:43 --> Helper loaded: url_helper
INFO - 2017-12-28 19:35:43 --> Helper loaded: form_helper
INFO - 2017-12-28 19:35:43 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:35:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:35:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:35:43 --> Form Validation Class Initialized
INFO - 2017-12-28 19:35:43 --> Model Class Initialized
INFO - 2017-12-28 19:35:43 --> Controller Class Initialized
INFO - 2017-12-28 19:35:43 --> Model Class Initialized
INFO - 2017-12-28 19:35:43 --> Model Class Initialized
INFO - 2017-12-28 19:35:43 --> Model Class Initialized
INFO - 2017-12-28 19:35:43 --> Model Class Initialized
DEBUG - 2017-12-28 19:35:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:35:43 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 19:35:43 --> Final output sent to browser
DEBUG - 2017-12-28 19:35:43 --> Total execution time: 0.0916
INFO - 2017-12-28 19:35:43 --> Config Class Initialized
INFO - 2017-12-28 19:35:43 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:35:43 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:35:43 --> Utf8 Class Initialized
INFO - 2017-12-28 19:35:43 --> URI Class Initialized
INFO - 2017-12-28 19:35:43 --> Router Class Initialized
INFO - 2017-12-28 19:35:43 --> Output Class Initialized
INFO - 2017-12-28 19:35:43 --> Security Class Initialized
DEBUG - 2017-12-28 19:35:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:35:43 --> Input Class Initialized
INFO - 2017-12-28 19:35:43 --> Language Class Initialized
INFO - 2017-12-28 19:35:43 --> Loader Class Initialized
INFO - 2017-12-28 19:35:43 --> Helper loaded: url_helper
INFO - 2017-12-28 19:35:43 --> Helper loaded: form_helper
INFO - 2017-12-28 19:35:43 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:35:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:35:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:35:43 --> Form Validation Class Initialized
INFO - 2017-12-28 19:35:43 --> Model Class Initialized
INFO - 2017-12-28 19:35:43 --> Controller Class Initialized
INFO - 2017-12-28 19:35:43 --> Model Class Initialized
INFO - 2017-12-28 19:35:43 --> Model Class Initialized
INFO - 2017-12-28 19:35:43 --> Model Class Initialized
INFO - 2017-12-28 19:35:43 --> Model Class Initialized
DEBUG - 2017-12-28 19:35:43 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2017-12-28 19:35:43 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\instateccr\instatec_sys\database\DB_query_builder.php 683
ERROR - 2017-12-28 19:35:43 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT *
FROM `proyecto_gasto`
LEFT JOIN `proyecto_gasto_tipo` ON `proyecto_gasto_tipo`.`proyecto_gasto_tipo_id` = `proyecto_gasto`.`proyecto_gasto_tipo_id`
LEFT JOIN `proyecto_gasto_monto` ON `proyecto_gasto_monto`.`proyecto_gasto_id` = `proyecto_gasto`.`proyecto_gasto_id` AND `proyecto_gasto_monto`.`estado_registro` = 1
LEFT JOIN `proyecto_gasto_detalle` ON `proyecto_gasto_detalle`.`proyecto_gasto_id` = `proyecto_gasto`.`proyecto_gasto_id`
LEFT JOIN `proveedor` ON `proveedor`.`proveedor_id` = `proyecto_gasto_detalle`.`proveedor_id`
WHERE `proyecto_gasto`.`proyecto_id` = '1'
AND `proyecto_gasto`.`fecha_gasto` = `Array`
ORDER BY `proyecto_gasto`.`fecha_registro` ASC
INFO - 2017-12-28 19:35:43 --> Language file loaded: language/english/db_lang.php
INFO - 2017-12-28 19:35:44 --> Config Class Initialized
INFO - 2017-12-28 19:35:44 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:35:44 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:35:44 --> Utf8 Class Initialized
INFO - 2017-12-28 19:35:44 --> URI Class Initialized
INFO - 2017-12-28 19:35:44 --> Router Class Initialized
INFO - 2017-12-28 19:35:44 --> Output Class Initialized
INFO - 2017-12-28 19:35:44 --> Security Class Initialized
DEBUG - 2017-12-28 19:35:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:35:44 --> Input Class Initialized
INFO - 2017-12-28 19:35:44 --> Language Class Initialized
INFO - 2017-12-28 19:35:44 --> Loader Class Initialized
INFO - 2017-12-28 19:35:44 --> Helper loaded: url_helper
INFO - 2017-12-28 19:35:44 --> Helper loaded: form_helper
INFO - 2017-12-28 19:35:44 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:35:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:35:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:35:44 --> Form Validation Class Initialized
INFO - 2017-12-28 19:35:44 --> Model Class Initialized
INFO - 2017-12-28 19:35:44 --> Controller Class Initialized
INFO - 2017-12-28 19:35:44 --> Model Class Initialized
INFO - 2017-12-28 19:35:44 --> Model Class Initialized
INFO - 2017-12-28 19:35:44 --> Model Class Initialized
INFO - 2017-12-28 19:35:44 --> Model Class Initialized
DEBUG - 2017-12-28 19:35:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:35:44 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 19:35:44 --> Final output sent to browser
DEBUG - 2017-12-28 19:35:44 --> Total execution time: 0.1096
INFO - 2017-12-28 19:35:48 --> Config Class Initialized
INFO - 2017-12-28 19:35:48 --> Hooks Class Initialized
INFO - 2017-12-28 19:35:48 --> Config Class Initialized
INFO - 2017-12-28 19:35:48 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:35:48 --> UTF-8 Support Enabled
DEBUG - 2017-12-28 19:35:48 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:35:48 --> Utf8 Class Initialized
INFO - 2017-12-28 19:35:48 --> Utf8 Class Initialized
INFO - 2017-12-28 19:35:48 --> URI Class Initialized
INFO - 2017-12-28 19:35:48 --> URI Class Initialized
INFO - 2017-12-28 19:35:48 --> Router Class Initialized
INFO - 2017-12-28 19:35:48 --> Router Class Initialized
INFO - 2017-12-28 19:35:48 --> Output Class Initialized
INFO - 2017-12-28 19:35:48 --> Output Class Initialized
INFO - 2017-12-28 19:35:48 --> Security Class Initialized
INFO - 2017-12-28 19:35:48 --> Security Class Initialized
DEBUG - 2017-12-28 19:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:35:48 --> Input Class Initialized
DEBUG - 2017-12-28 19:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:35:48 --> Input Class Initialized
INFO - 2017-12-28 19:35:48 --> Language Class Initialized
INFO - 2017-12-28 19:35:48 --> Language Class Initialized
ERROR - 2017-12-28 19:35:48 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-28 19:35:48 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-28 19:35:51 --> Config Class Initialized
INFO - 2017-12-28 19:35:51 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:35:51 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:35:51 --> Utf8 Class Initialized
INFO - 2017-12-28 19:35:51 --> URI Class Initialized
INFO - 2017-12-28 19:35:51 --> Router Class Initialized
INFO - 2017-12-28 19:35:51 --> Output Class Initialized
INFO - 2017-12-28 19:35:51 --> Security Class Initialized
DEBUG - 2017-12-28 19:35:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:35:51 --> Input Class Initialized
INFO - 2017-12-28 19:35:51 --> Language Class Initialized
ERROR - 2017-12-28 19:35:51 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-28 19:35:51 --> Config Class Initialized
INFO - 2017-12-28 19:35:51 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:35:51 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:35:51 --> Utf8 Class Initialized
INFO - 2017-12-28 19:35:51 --> URI Class Initialized
INFO - 2017-12-28 19:35:51 --> Router Class Initialized
INFO - 2017-12-28 19:35:51 --> Output Class Initialized
INFO - 2017-12-28 19:35:51 --> Security Class Initialized
DEBUG - 2017-12-28 19:35:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:35:51 --> Input Class Initialized
INFO - 2017-12-28 19:35:51 --> Language Class Initialized
INFO - 2017-12-28 19:35:51 --> Loader Class Initialized
INFO - 2017-12-28 19:35:51 --> Helper loaded: url_helper
INFO - 2017-12-28 19:35:51 --> Helper loaded: form_helper
INFO - 2017-12-28 19:35:51 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:35:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:35:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:35:52 --> Form Validation Class Initialized
INFO - 2017-12-28 19:35:52 --> Model Class Initialized
INFO - 2017-12-28 19:35:52 --> Controller Class Initialized
INFO - 2017-12-28 19:35:52 --> Model Class Initialized
INFO - 2017-12-28 19:35:52 --> Model Class Initialized
INFO - 2017-12-28 19:35:52 --> Model Class Initialized
INFO - 2017-12-28 19:35:52 --> Model Class Initialized
DEBUG - 2017-12-28 19:35:52 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2017-12-28 19:35:52 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\instateccr\instatec_sys\database\DB_query_builder.php 683
ERROR - 2017-12-28 19:35:52 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT *
FROM `proyecto_gasto`
LEFT JOIN `proyecto_gasto_tipo` ON `proyecto_gasto_tipo`.`proyecto_gasto_tipo_id` = `proyecto_gasto`.`proyecto_gasto_tipo_id`
LEFT JOIN `proyecto_gasto_monto` ON `proyecto_gasto_monto`.`proyecto_gasto_id` = `proyecto_gasto`.`proyecto_gasto_id` AND `proyecto_gasto_monto`.`estado_registro` = 1
LEFT JOIN `proyecto_gasto_detalle` ON `proyecto_gasto_detalle`.`proyecto_gasto_id` = `proyecto_gasto`.`proyecto_gasto_id`
LEFT JOIN `proveedor` ON `proveedor`.`proveedor_id` = `proyecto_gasto_detalle`.`proveedor_id`
WHERE `proyecto_gasto`.`proyecto_id` = '1'
AND `proyecto_gasto`.`fecha_gasto` = `Array`
ORDER BY `proyecto_gasto`.`fecha_registro` ASC
INFO - 2017-12-28 19:35:52 --> Language file loaded: language/english/db_lang.php
INFO - 2017-12-28 19:35:52 --> Config Class Initialized
INFO - 2017-12-28 19:35:52 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:35:52 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:35:52 --> Utf8 Class Initialized
INFO - 2017-12-28 19:35:52 --> URI Class Initialized
INFO - 2017-12-28 19:35:52 --> Router Class Initialized
INFO - 2017-12-28 19:35:52 --> Output Class Initialized
INFO - 2017-12-28 19:35:52 --> Security Class Initialized
DEBUG - 2017-12-28 19:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:35:52 --> Input Class Initialized
INFO - 2017-12-28 19:35:52 --> Language Class Initialized
ERROR - 2017-12-28 19:35:52 --> 404 Page Not Found: Faviconico/index
INFO - 2017-12-28 19:41:46 --> Config Class Initialized
INFO - 2017-12-28 19:41:46 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:41:46 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:41:46 --> Utf8 Class Initialized
INFO - 2017-12-28 19:41:46 --> URI Class Initialized
INFO - 2017-12-28 19:41:46 --> Router Class Initialized
INFO - 2017-12-28 19:41:46 --> Output Class Initialized
INFO - 2017-12-28 19:41:46 --> Security Class Initialized
DEBUG - 2017-12-28 19:41:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:41:46 --> Input Class Initialized
INFO - 2017-12-28 19:41:46 --> Language Class Initialized
INFO - 2017-12-28 19:41:46 --> Loader Class Initialized
INFO - 2017-12-28 19:41:46 --> Helper loaded: url_helper
INFO - 2017-12-28 19:41:46 --> Helper loaded: form_helper
INFO - 2017-12-28 19:41:46 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:41:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:41:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:41:46 --> Form Validation Class Initialized
INFO - 2017-12-28 19:41:46 --> Model Class Initialized
INFO - 2017-12-28 19:41:46 --> Controller Class Initialized
INFO - 2017-12-28 19:41:46 --> Model Class Initialized
INFO - 2017-12-28 19:41:46 --> Model Class Initialized
INFO - 2017-12-28 19:41:46 --> Model Class Initialized
INFO - 2017-12-28 19:41:46 --> Model Class Initialized
DEBUG - 2017-12-28 19:41:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:41:46 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 19:41:46 --> Final output sent to browser
DEBUG - 2017-12-28 19:41:46 --> Total execution time: 0.1117
INFO - 2017-12-28 19:41:46 --> Config Class Initialized
INFO - 2017-12-28 19:41:46 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:41:46 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:41:46 --> Utf8 Class Initialized
INFO - 2017-12-28 19:41:46 --> URI Class Initialized
INFO - 2017-12-28 19:41:46 --> Router Class Initialized
INFO - 2017-12-28 19:41:46 --> Output Class Initialized
INFO - 2017-12-28 19:41:46 --> Security Class Initialized
DEBUG - 2017-12-28 19:41:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:41:46 --> Input Class Initialized
INFO - 2017-12-28 19:41:46 --> Language Class Initialized
ERROR - 2017-12-28 19:41:46 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-28 19:41:46 --> Config Class Initialized
INFO - 2017-12-28 19:41:46 --> Hooks Class Initialized
INFO - 2017-12-28 19:41:46 --> Config Class Initialized
INFO - 2017-12-28 19:41:46 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:41:46 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:41:46 --> Utf8 Class Initialized
DEBUG - 2017-12-28 19:41:46 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:41:46 --> URI Class Initialized
INFO - 2017-12-28 19:41:46 --> Utf8 Class Initialized
INFO - 2017-12-28 19:41:46 --> URI Class Initialized
INFO - 2017-12-28 19:41:46 --> Router Class Initialized
INFO - 2017-12-28 19:41:46 --> Router Class Initialized
INFO - 2017-12-28 19:41:46 --> Output Class Initialized
INFO - 2017-12-28 19:41:46 --> Output Class Initialized
INFO - 2017-12-28 19:41:46 --> Security Class Initialized
INFO - 2017-12-28 19:41:46 --> Security Class Initialized
DEBUG - 2017-12-28 19:41:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:41:46 --> Input Class Initialized
DEBUG - 2017-12-28 19:41:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:41:46 --> Language Class Initialized
INFO - 2017-12-28 19:41:46 --> Input Class Initialized
INFO - 2017-12-28 19:41:46 --> Language Class Initialized
ERROR - 2017-12-28 19:41:46 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-28 19:41:46 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-28 19:41:46 --> Config Class Initialized
INFO - 2017-12-28 19:41:46 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:41:46 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:41:46 --> Utf8 Class Initialized
INFO - 2017-12-28 19:41:46 --> URI Class Initialized
INFO - 2017-12-28 19:41:46 --> Router Class Initialized
INFO - 2017-12-28 19:41:46 --> Output Class Initialized
INFO - 2017-12-28 19:41:46 --> Security Class Initialized
DEBUG - 2017-12-28 19:41:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:41:46 --> Input Class Initialized
INFO - 2017-12-28 19:41:46 --> Language Class Initialized
INFO - 2017-12-28 19:41:46 --> Loader Class Initialized
INFO - 2017-12-28 19:41:46 --> Helper loaded: url_helper
INFO - 2017-12-28 19:41:46 --> Helper loaded: form_helper
INFO - 2017-12-28 19:41:46 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:41:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:41:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:41:46 --> Form Validation Class Initialized
INFO - 2017-12-28 19:41:46 --> Model Class Initialized
INFO - 2017-12-28 19:41:46 --> Controller Class Initialized
INFO - 2017-12-28 19:41:46 --> Model Class Initialized
INFO - 2017-12-28 19:41:46 --> Model Class Initialized
INFO - 2017-12-28 19:41:46 --> Model Class Initialized
INFO - 2017-12-28 19:41:46 --> Model Class Initialized
DEBUG - 2017-12-28 19:41:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:42:09 --> Config Class Initialized
INFO - 2017-12-28 19:42:09 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:42:09 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:42:09 --> Utf8 Class Initialized
INFO - 2017-12-28 19:42:09 --> URI Class Initialized
INFO - 2017-12-28 19:42:09 --> Router Class Initialized
INFO - 2017-12-28 19:42:09 --> Output Class Initialized
INFO - 2017-12-28 19:42:09 --> Security Class Initialized
DEBUG - 2017-12-28 19:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:42:09 --> Input Class Initialized
INFO - 2017-12-28 19:42:09 --> Language Class Initialized
INFO - 2017-12-28 19:42:09 --> Loader Class Initialized
INFO - 2017-12-28 19:42:09 --> Helper loaded: url_helper
INFO - 2017-12-28 19:42:09 --> Helper loaded: form_helper
INFO - 2017-12-28 19:42:09 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:42:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:42:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:42:09 --> Form Validation Class Initialized
INFO - 2017-12-28 19:42:09 --> Model Class Initialized
INFO - 2017-12-28 19:42:09 --> Controller Class Initialized
INFO - 2017-12-28 19:42:09 --> Model Class Initialized
INFO - 2017-12-28 19:42:09 --> Model Class Initialized
INFO - 2017-12-28 19:42:09 --> Model Class Initialized
INFO - 2017-12-28 19:42:09 --> Model Class Initialized
DEBUG - 2017-12-28 19:42:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:42:09 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 19:42:09 --> Final output sent to browser
DEBUG - 2017-12-28 19:42:09 --> Total execution time: 0.0458
INFO - 2017-12-28 19:42:20 --> Config Class Initialized
INFO - 2017-12-28 19:42:20 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:42:20 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:42:20 --> Utf8 Class Initialized
INFO - 2017-12-28 19:42:20 --> URI Class Initialized
INFO - 2017-12-28 19:42:20 --> Router Class Initialized
INFO - 2017-12-28 19:42:20 --> Output Class Initialized
INFO - 2017-12-28 19:42:20 --> Security Class Initialized
DEBUG - 2017-12-28 19:42:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:42:20 --> Input Class Initialized
INFO - 2017-12-28 19:42:20 --> Language Class Initialized
INFO - 2017-12-28 19:42:20 --> Loader Class Initialized
INFO - 2017-12-28 19:42:20 --> Helper loaded: url_helper
INFO - 2017-12-28 19:42:20 --> Helper loaded: form_helper
INFO - 2017-12-28 19:42:20 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:42:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:42:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:42:20 --> Form Validation Class Initialized
INFO - 2017-12-28 19:42:20 --> Model Class Initialized
INFO - 2017-12-28 19:42:20 --> Controller Class Initialized
INFO - 2017-12-28 19:42:20 --> Model Class Initialized
INFO - 2017-12-28 19:42:20 --> Model Class Initialized
INFO - 2017-12-28 19:42:20 --> Model Class Initialized
INFO - 2017-12-28 19:42:20 --> Model Class Initialized
DEBUG - 2017-12-28 19:42:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:42:20 --> Config Class Initialized
INFO - 2017-12-28 19:42:20 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:42:20 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:42:20 --> Utf8 Class Initialized
INFO - 2017-12-28 19:42:20 --> URI Class Initialized
INFO - 2017-12-28 19:42:20 --> Router Class Initialized
INFO - 2017-12-28 19:42:20 --> Output Class Initialized
INFO - 2017-12-28 19:42:20 --> Security Class Initialized
DEBUG - 2017-12-28 19:42:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:42:20 --> Input Class Initialized
INFO - 2017-12-28 19:42:20 --> Language Class Initialized
ERROR - 2017-12-28 19:42:20 --> 404 Page Not Found: Faviconico/index
INFO - 2017-12-28 19:42:29 --> Config Class Initialized
INFO - 2017-12-28 19:42:29 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:42:29 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:42:29 --> Utf8 Class Initialized
INFO - 2017-12-28 19:42:29 --> URI Class Initialized
INFO - 2017-12-28 19:42:29 --> Router Class Initialized
INFO - 2017-12-28 19:42:29 --> Output Class Initialized
INFO - 2017-12-28 19:42:29 --> Security Class Initialized
DEBUG - 2017-12-28 19:42:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:42:29 --> Input Class Initialized
INFO - 2017-12-28 19:42:29 --> Language Class Initialized
INFO - 2017-12-28 19:42:29 --> Loader Class Initialized
INFO - 2017-12-28 19:42:29 --> Helper loaded: url_helper
INFO - 2017-12-28 19:42:29 --> Helper loaded: form_helper
INFO - 2017-12-28 19:42:29 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:42:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:42:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:42:29 --> Form Validation Class Initialized
INFO - 2017-12-28 19:42:29 --> Model Class Initialized
INFO - 2017-12-28 19:42:29 --> Controller Class Initialized
INFO - 2017-12-28 19:42:29 --> Model Class Initialized
INFO - 2017-12-28 19:42:29 --> Model Class Initialized
INFO - 2017-12-28 19:42:29 --> Model Class Initialized
INFO - 2017-12-28 19:42:29 --> Model Class Initialized
DEBUG - 2017-12-28 19:42:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:42:32 --> Config Class Initialized
INFO - 2017-12-28 19:42:32 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:42:33 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:42:33 --> Utf8 Class Initialized
INFO - 2017-12-28 19:42:33 --> URI Class Initialized
INFO - 2017-12-28 19:42:33 --> Router Class Initialized
INFO - 2017-12-28 19:42:33 --> Output Class Initialized
INFO - 2017-12-28 19:42:33 --> Security Class Initialized
DEBUG - 2017-12-28 19:42:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:42:33 --> Input Class Initialized
INFO - 2017-12-28 19:42:33 --> Language Class Initialized
INFO - 2017-12-28 19:42:33 --> Loader Class Initialized
INFO - 2017-12-28 19:42:33 --> Helper loaded: url_helper
INFO - 2017-12-28 19:42:33 --> Helper loaded: form_helper
INFO - 2017-12-28 19:42:33 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:42:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:42:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:42:33 --> Form Validation Class Initialized
INFO - 2017-12-28 19:42:33 --> Model Class Initialized
INFO - 2017-12-28 19:42:33 --> Controller Class Initialized
INFO - 2017-12-28 19:42:33 --> Model Class Initialized
INFO - 2017-12-28 19:42:33 --> Model Class Initialized
INFO - 2017-12-28 19:42:33 --> Model Class Initialized
INFO - 2017-12-28 19:42:33 --> Model Class Initialized
DEBUG - 2017-12-28 19:42:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:42:36 --> Config Class Initialized
INFO - 2017-12-28 19:42:36 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:42:36 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:42:36 --> Utf8 Class Initialized
INFO - 2017-12-28 19:42:36 --> URI Class Initialized
INFO - 2017-12-28 19:42:36 --> Router Class Initialized
INFO - 2017-12-28 19:42:36 --> Output Class Initialized
INFO - 2017-12-28 19:42:36 --> Security Class Initialized
DEBUG - 2017-12-28 19:42:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:42:36 --> Input Class Initialized
INFO - 2017-12-28 19:42:36 --> Language Class Initialized
INFO - 2017-12-28 19:42:36 --> Loader Class Initialized
INFO - 2017-12-28 19:42:36 --> Helper loaded: url_helper
INFO - 2017-12-28 19:42:36 --> Helper loaded: form_helper
INFO - 2017-12-28 19:42:36 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:42:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:42:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:42:36 --> Form Validation Class Initialized
INFO - 2017-12-28 19:42:36 --> Model Class Initialized
INFO - 2017-12-28 19:42:36 --> Controller Class Initialized
INFO - 2017-12-28 19:42:36 --> Model Class Initialized
INFO - 2017-12-28 19:42:36 --> Model Class Initialized
INFO - 2017-12-28 19:42:36 --> Model Class Initialized
INFO - 2017-12-28 19:42:36 --> Model Class Initialized
DEBUG - 2017-12-28 19:42:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:42:40 --> Config Class Initialized
INFO - 2017-12-28 19:42:40 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:42:40 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:42:40 --> Utf8 Class Initialized
INFO - 2017-12-28 19:42:40 --> URI Class Initialized
INFO - 2017-12-28 19:42:40 --> Router Class Initialized
INFO - 2017-12-28 19:42:40 --> Output Class Initialized
INFO - 2017-12-28 19:42:40 --> Security Class Initialized
DEBUG - 2017-12-28 19:42:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:42:40 --> Input Class Initialized
INFO - 2017-12-28 19:42:40 --> Language Class Initialized
INFO - 2017-12-28 19:42:40 --> Loader Class Initialized
INFO - 2017-12-28 19:42:40 --> Helper loaded: url_helper
INFO - 2017-12-28 19:42:40 --> Helper loaded: form_helper
INFO - 2017-12-28 19:42:40 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:42:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:42:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:42:40 --> Form Validation Class Initialized
INFO - 2017-12-28 19:42:40 --> Model Class Initialized
INFO - 2017-12-28 19:42:40 --> Controller Class Initialized
INFO - 2017-12-28 19:42:40 --> Model Class Initialized
INFO - 2017-12-28 19:42:41 --> Model Class Initialized
INFO - 2017-12-28 19:42:41 --> Model Class Initialized
INFO - 2017-12-28 19:42:41 --> Model Class Initialized
DEBUG - 2017-12-28 19:42:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:42:53 --> Config Class Initialized
INFO - 2017-12-28 19:42:53 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:42:53 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:42:53 --> Utf8 Class Initialized
INFO - 2017-12-28 19:42:53 --> URI Class Initialized
INFO - 2017-12-28 19:42:53 --> Router Class Initialized
INFO - 2017-12-28 19:42:53 --> Output Class Initialized
INFO - 2017-12-28 19:42:53 --> Security Class Initialized
DEBUG - 2017-12-28 19:42:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:42:53 --> Input Class Initialized
INFO - 2017-12-28 19:42:53 --> Language Class Initialized
INFO - 2017-12-28 19:42:53 --> Loader Class Initialized
INFO - 2017-12-28 19:42:53 --> Helper loaded: url_helper
INFO - 2017-12-28 19:42:53 --> Helper loaded: form_helper
INFO - 2017-12-28 19:42:53 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:42:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:42:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:42:53 --> Form Validation Class Initialized
INFO - 2017-12-28 19:42:53 --> Model Class Initialized
INFO - 2017-12-28 19:42:53 --> Controller Class Initialized
INFO - 2017-12-28 19:42:53 --> Model Class Initialized
INFO - 2017-12-28 19:42:53 --> Model Class Initialized
INFO - 2017-12-28 19:42:53 --> Model Class Initialized
INFO - 2017-12-28 19:42:53 --> Model Class Initialized
DEBUG - 2017-12-28 19:42:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:43:08 --> Config Class Initialized
INFO - 2017-12-28 19:43:08 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:43:08 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:43:08 --> Utf8 Class Initialized
INFO - 2017-12-28 19:43:08 --> URI Class Initialized
INFO - 2017-12-28 19:43:08 --> Router Class Initialized
INFO - 2017-12-28 19:43:08 --> Output Class Initialized
INFO - 2017-12-28 19:43:08 --> Security Class Initialized
DEBUG - 2017-12-28 19:43:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:43:08 --> Input Class Initialized
INFO - 2017-12-28 19:43:08 --> Language Class Initialized
INFO - 2017-12-28 19:43:08 --> Loader Class Initialized
INFO - 2017-12-28 19:43:08 --> Helper loaded: url_helper
INFO - 2017-12-28 19:43:08 --> Helper loaded: form_helper
INFO - 2017-12-28 19:43:08 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:43:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:43:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:43:08 --> Form Validation Class Initialized
INFO - 2017-12-28 19:43:08 --> Model Class Initialized
INFO - 2017-12-28 19:43:08 --> Controller Class Initialized
INFO - 2017-12-28 19:43:08 --> Model Class Initialized
INFO - 2017-12-28 19:43:08 --> Model Class Initialized
INFO - 2017-12-28 19:43:08 --> Model Class Initialized
INFO - 2017-12-28 19:43:08 --> Model Class Initialized
DEBUG - 2017-12-28 19:43:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:43:08 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 19:43:08 --> Final output sent to browser
DEBUG - 2017-12-28 19:43:08 --> Total execution time: 0.0591
INFO - 2017-12-28 19:43:09 --> Config Class Initialized
INFO - 2017-12-28 19:43:09 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:43:09 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:43:09 --> Utf8 Class Initialized
INFO - 2017-12-28 19:43:09 --> URI Class Initialized
INFO - 2017-12-28 19:43:09 --> Router Class Initialized
INFO - 2017-12-28 19:43:09 --> Output Class Initialized
INFO - 2017-12-28 19:43:09 --> Security Class Initialized
DEBUG - 2017-12-28 19:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:43:09 --> Input Class Initialized
INFO - 2017-12-28 19:43:09 --> Language Class Initialized
INFO - 2017-12-28 19:43:09 --> Loader Class Initialized
INFO - 2017-12-28 19:43:09 --> Helper loaded: url_helper
INFO - 2017-12-28 19:43:09 --> Helper loaded: form_helper
INFO - 2017-12-28 19:43:09 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:43:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:43:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:43:09 --> Form Validation Class Initialized
INFO - 2017-12-28 19:43:09 --> Model Class Initialized
INFO - 2017-12-28 19:43:09 --> Controller Class Initialized
INFO - 2017-12-28 19:43:09 --> Model Class Initialized
INFO - 2017-12-28 19:43:09 --> Model Class Initialized
INFO - 2017-12-28 19:43:09 --> Model Class Initialized
INFO - 2017-12-28 19:43:09 --> Model Class Initialized
DEBUG - 2017-12-28 19:43:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:43:16 --> Config Class Initialized
INFO - 2017-12-28 19:43:16 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:43:16 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:43:16 --> Utf8 Class Initialized
INFO - 2017-12-28 19:43:16 --> URI Class Initialized
INFO - 2017-12-28 19:43:16 --> Router Class Initialized
INFO - 2017-12-28 19:43:16 --> Output Class Initialized
INFO - 2017-12-28 19:43:16 --> Security Class Initialized
DEBUG - 2017-12-28 19:43:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:43:16 --> Input Class Initialized
INFO - 2017-12-28 19:43:16 --> Language Class Initialized
INFO - 2017-12-28 19:43:16 --> Loader Class Initialized
INFO - 2017-12-28 19:43:16 --> Helper loaded: url_helper
INFO - 2017-12-28 19:43:16 --> Helper loaded: form_helper
INFO - 2017-12-28 19:43:16 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:43:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:43:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:43:16 --> Form Validation Class Initialized
INFO - 2017-12-28 19:43:16 --> Model Class Initialized
INFO - 2017-12-28 19:43:16 --> Controller Class Initialized
INFO - 2017-12-28 19:43:16 --> Model Class Initialized
INFO - 2017-12-28 19:43:16 --> Model Class Initialized
INFO - 2017-12-28 19:43:16 --> Model Class Initialized
INFO - 2017-12-28 19:43:16 --> Model Class Initialized
DEBUG - 2017-12-28 19:43:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:43:17 --> Config Class Initialized
INFO - 2017-12-28 19:43:17 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:43:17 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:43:17 --> Utf8 Class Initialized
INFO - 2017-12-28 19:43:17 --> URI Class Initialized
INFO - 2017-12-28 19:43:17 --> Router Class Initialized
INFO - 2017-12-28 19:43:17 --> Output Class Initialized
INFO - 2017-12-28 19:43:17 --> Security Class Initialized
DEBUG - 2017-12-28 19:43:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:43:17 --> Input Class Initialized
INFO - 2017-12-28 19:43:17 --> Language Class Initialized
INFO - 2017-12-28 19:43:17 --> Loader Class Initialized
INFO - 2017-12-28 19:43:17 --> Helper loaded: url_helper
INFO - 2017-12-28 19:43:17 --> Helper loaded: form_helper
INFO - 2017-12-28 19:43:18 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:43:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:43:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:43:18 --> Form Validation Class Initialized
INFO - 2017-12-28 19:43:18 --> Model Class Initialized
INFO - 2017-12-28 19:43:18 --> Controller Class Initialized
INFO - 2017-12-28 19:43:18 --> Model Class Initialized
INFO - 2017-12-28 19:43:18 --> Model Class Initialized
INFO - 2017-12-28 19:43:18 --> Model Class Initialized
INFO - 2017-12-28 19:43:18 --> Model Class Initialized
DEBUG - 2017-12-28 19:43:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:43:23 --> Config Class Initialized
INFO - 2017-12-28 19:43:23 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:43:23 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:43:23 --> Utf8 Class Initialized
INFO - 2017-12-28 19:43:23 --> URI Class Initialized
INFO - 2017-12-28 19:43:23 --> Router Class Initialized
INFO - 2017-12-28 19:43:23 --> Output Class Initialized
INFO - 2017-12-28 19:43:23 --> Security Class Initialized
DEBUG - 2017-12-28 19:43:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:43:23 --> Input Class Initialized
INFO - 2017-12-28 19:43:23 --> Language Class Initialized
INFO - 2017-12-28 19:43:23 --> Loader Class Initialized
INFO - 2017-12-28 19:43:23 --> Helper loaded: url_helper
INFO - 2017-12-28 19:43:23 --> Helper loaded: form_helper
INFO - 2017-12-28 19:43:23 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:43:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:43:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:43:23 --> Form Validation Class Initialized
INFO - 2017-12-28 19:43:23 --> Model Class Initialized
INFO - 2017-12-28 19:43:23 --> Controller Class Initialized
INFO - 2017-12-28 19:43:23 --> Model Class Initialized
INFO - 2017-12-28 19:43:23 --> Model Class Initialized
INFO - 2017-12-28 19:43:23 --> Model Class Initialized
INFO - 2017-12-28 19:43:23 --> Model Class Initialized
DEBUG - 2017-12-28 19:43:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:43:27 --> Config Class Initialized
INFO - 2017-12-28 19:43:27 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:43:27 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:43:27 --> Utf8 Class Initialized
INFO - 2017-12-28 19:43:27 --> URI Class Initialized
INFO - 2017-12-28 19:43:27 --> Router Class Initialized
INFO - 2017-12-28 19:43:27 --> Output Class Initialized
INFO - 2017-12-28 19:43:27 --> Security Class Initialized
DEBUG - 2017-12-28 19:43:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:43:27 --> Input Class Initialized
INFO - 2017-12-28 19:43:27 --> Language Class Initialized
INFO - 2017-12-28 19:43:27 --> Loader Class Initialized
INFO - 2017-12-28 19:43:27 --> Helper loaded: url_helper
INFO - 2017-12-28 19:43:27 --> Helper loaded: form_helper
INFO - 2017-12-28 19:43:27 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:43:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:43:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:43:27 --> Form Validation Class Initialized
INFO - 2017-12-28 19:43:27 --> Model Class Initialized
INFO - 2017-12-28 19:43:27 --> Controller Class Initialized
INFO - 2017-12-28 19:43:27 --> Model Class Initialized
INFO - 2017-12-28 19:43:27 --> Model Class Initialized
INFO - 2017-12-28 19:43:27 --> Model Class Initialized
INFO - 2017-12-28 19:43:27 --> Model Class Initialized
DEBUG - 2017-12-28 19:43:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:43:28 --> Config Class Initialized
INFO - 2017-12-28 19:43:28 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:43:28 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:43:28 --> Utf8 Class Initialized
INFO - 2017-12-28 19:43:28 --> URI Class Initialized
INFO - 2017-12-28 19:43:28 --> Router Class Initialized
INFO - 2017-12-28 19:43:28 --> Output Class Initialized
INFO - 2017-12-28 19:43:28 --> Security Class Initialized
DEBUG - 2017-12-28 19:43:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:43:28 --> Input Class Initialized
INFO - 2017-12-28 19:43:28 --> Language Class Initialized
INFO - 2017-12-28 19:43:28 --> Loader Class Initialized
INFO - 2017-12-28 19:43:28 --> Helper loaded: url_helper
INFO - 2017-12-28 19:43:28 --> Helper loaded: form_helper
INFO - 2017-12-28 19:43:28 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:43:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:43:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:43:28 --> Form Validation Class Initialized
INFO - 2017-12-28 19:43:28 --> Model Class Initialized
INFO - 2017-12-28 19:43:28 --> Controller Class Initialized
INFO - 2017-12-28 19:43:28 --> Model Class Initialized
INFO - 2017-12-28 19:43:28 --> Model Class Initialized
INFO - 2017-12-28 19:43:28 --> Model Class Initialized
INFO - 2017-12-28 19:43:28 --> Model Class Initialized
DEBUG - 2017-12-28 19:43:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:43:30 --> Config Class Initialized
INFO - 2017-12-28 19:43:30 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:43:30 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:43:30 --> Utf8 Class Initialized
INFO - 2017-12-28 19:43:30 --> URI Class Initialized
INFO - 2017-12-28 19:43:30 --> Router Class Initialized
INFO - 2017-12-28 19:43:30 --> Output Class Initialized
INFO - 2017-12-28 19:43:30 --> Security Class Initialized
DEBUG - 2017-12-28 19:43:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:43:30 --> Input Class Initialized
INFO - 2017-12-28 19:43:30 --> Language Class Initialized
INFO - 2017-12-28 19:43:30 --> Loader Class Initialized
INFO - 2017-12-28 19:43:30 --> Helper loaded: url_helper
INFO - 2017-12-28 19:43:30 --> Helper loaded: form_helper
INFO - 2017-12-28 19:43:30 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:43:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:43:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:43:30 --> Form Validation Class Initialized
INFO - 2017-12-28 19:43:30 --> Model Class Initialized
INFO - 2017-12-28 19:43:30 --> Controller Class Initialized
INFO - 2017-12-28 19:43:30 --> Model Class Initialized
INFO - 2017-12-28 19:43:30 --> Model Class Initialized
INFO - 2017-12-28 19:43:30 --> Model Class Initialized
INFO - 2017-12-28 19:43:30 --> Model Class Initialized
DEBUG - 2017-12-28 19:43:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:43:30 --> Config Class Initialized
INFO - 2017-12-28 19:43:30 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:43:30 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:43:30 --> Utf8 Class Initialized
INFO - 2017-12-28 19:43:30 --> URI Class Initialized
INFO - 2017-12-28 19:43:30 --> Router Class Initialized
INFO - 2017-12-28 19:43:30 --> Output Class Initialized
INFO - 2017-12-28 19:43:30 --> Security Class Initialized
DEBUG - 2017-12-28 19:43:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:43:30 --> Input Class Initialized
INFO - 2017-12-28 19:43:30 --> Language Class Initialized
INFO - 2017-12-28 19:43:30 --> Loader Class Initialized
INFO - 2017-12-28 19:43:30 --> Helper loaded: url_helper
INFO - 2017-12-28 19:43:30 --> Helper loaded: form_helper
INFO - 2017-12-28 19:43:30 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:43:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:43:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:43:30 --> Form Validation Class Initialized
INFO - 2017-12-28 19:43:30 --> Model Class Initialized
INFO - 2017-12-28 19:43:30 --> Controller Class Initialized
INFO - 2017-12-28 19:43:30 --> Model Class Initialized
INFO - 2017-12-28 19:43:30 --> Model Class Initialized
INFO - 2017-12-28 19:43:30 --> Model Class Initialized
INFO - 2017-12-28 19:43:30 --> Model Class Initialized
DEBUG - 2017-12-28 19:43:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:43:30 --> Config Class Initialized
INFO - 2017-12-28 19:43:30 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:43:30 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:43:30 --> Utf8 Class Initialized
INFO - 2017-12-28 19:43:30 --> URI Class Initialized
INFO - 2017-12-28 19:43:30 --> Router Class Initialized
INFO - 2017-12-28 19:43:30 --> Output Class Initialized
INFO - 2017-12-28 19:43:30 --> Security Class Initialized
DEBUG - 2017-12-28 19:43:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:43:30 --> Input Class Initialized
INFO - 2017-12-28 19:43:30 --> Language Class Initialized
INFO - 2017-12-28 19:43:30 --> Loader Class Initialized
INFO - 2017-12-28 19:43:30 --> Helper loaded: url_helper
INFO - 2017-12-28 19:43:30 --> Helper loaded: form_helper
INFO - 2017-12-28 19:43:30 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:43:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:43:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:43:31 --> Form Validation Class Initialized
INFO - 2017-12-28 19:43:31 --> Model Class Initialized
INFO - 2017-12-28 19:43:31 --> Controller Class Initialized
INFO - 2017-12-28 19:43:31 --> Model Class Initialized
INFO - 2017-12-28 19:43:31 --> Model Class Initialized
INFO - 2017-12-28 19:43:31 --> Model Class Initialized
INFO - 2017-12-28 19:43:31 --> Model Class Initialized
DEBUG - 2017-12-28 19:43:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:43:31 --> Config Class Initialized
INFO - 2017-12-28 19:43:31 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:43:31 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:43:31 --> Utf8 Class Initialized
INFO - 2017-12-28 19:43:31 --> URI Class Initialized
INFO - 2017-12-28 19:43:31 --> Router Class Initialized
INFO - 2017-12-28 19:43:31 --> Output Class Initialized
INFO - 2017-12-28 19:43:31 --> Security Class Initialized
DEBUG - 2017-12-28 19:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:43:31 --> Input Class Initialized
INFO - 2017-12-28 19:43:31 --> Language Class Initialized
INFO - 2017-12-28 19:43:31 --> Loader Class Initialized
INFO - 2017-12-28 19:43:31 --> Helper loaded: url_helper
INFO - 2017-12-28 19:43:31 --> Helper loaded: form_helper
INFO - 2017-12-28 19:43:31 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:43:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:43:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:43:31 --> Form Validation Class Initialized
INFO - 2017-12-28 19:43:31 --> Model Class Initialized
INFO - 2017-12-28 19:43:31 --> Controller Class Initialized
INFO - 2017-12-28 19:43:31 --> Model Class Initialized
INFO - 2017-12-28 19:43:31 --> Model Class Initialized
INFO - 2017-12-28 19:43:31 --> Model Class Initialized
INFO - 2017-12-28 19:43:31 --> Model Class Initialized
DEBUG - 2017-12-28 19:43:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:43:31 --> Config Class Initialized
INFO - 2017-12-28 19:43:31 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:43:31 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:43:31 --> Utf8 Class Initialized
INFO - 2017-12-28 19:43:31 --> URI Class Initialized
INFO - 2017-12-28 19:43:31 --> Router Class Initialized
INFO - 2017-12-28 19:43:31 --> Output Class Initialized
INFO - 2017-12-28 19:43:31 --> Security Class Initialized
DEBUG - 2017-12-28 19:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:43:31 --> Input Class Initialized
INFO - 2017-12-28 19:43:31 --> Language Class Initialized
INFO - 2017-12-28 19:43:31 --> Loader Class Initialized
INFO - 2017-12-28 19:43:31 --> Helper loaded: url_helper
INFO - 2017-12-28 19:43:31 --> Helper loaded: form_helper
INFO - 2017-12-28 19:43:31 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:43:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:43:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:43:31 --> Form Validation Class Initialized
INFO - 2017-12-28 19:43:31 --> Model Class Initialized
INFO - 2017-12-28 19:43:31 --> Controller Class Initialized
INFO - 2017-12-28 19:43:31 --> Model Class Initialized
INFO - 2017-12-28 19:43:31 --> Model Class Initialized
INFO - 2017-12-28 19:43:31 --> Model Class Initialized
INFO - 2017-12-28 19:43:31 --> Model Class Initialized
DEBUG - 2017-12-28 19:43:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:43:31 --> Config Class Initialized
INFO - 2017-12-28 19:43:31 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:43:31 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:43:31 --> Utf8 Class Initialized
INFO - 2017-12-28 19:43:31 --> URI Class Initialized
INFO - 2017-12-28 19:43:31 --> Router Class Initialized
INFO - 2017-12-28 19:43:31 --> Output Class Initialized
INFO - 2017-12-28 19:43:31 --> Security Class Initialized
DEBUG - 2017-12-28 19:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:43:31 --> Input Class Initialized
INFO - 2017-12-28 19:43:31 --> Language Class Initialized
INFO - 2017-12-28 19:43:31 --> Loader Class Initialized
INFO - 2017-12-28 19:43:31 --> Helper loaded: url_helper
INFO - 2017-12-28 19:43:31 --> Helper loaded: form_helper
INFO - 2017-12-28 19:43:31 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:43:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:43:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:43:31 --> Form Validation Class Initialized
INFO - 2017-12-28 19:43:31 --> Model Class Initialized
INFO - 2017-12-28 19:43:31 --> Controller Class Initialized
INFO - 2017-12-28 19:43:31 --> Model Class Initialized
INFO - 2017-12-28 19:43:31 --> Model Class Initialized
INFO - 2017-12-28 19:43:31 --> Model Class Initialized
INFO - 2017-12-28 19:43:31 --> Model Class Initialized
DEBUG - 2017-12-28 19:43:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:43:36 --> Config Class Initialized
INFO - 2017-12-28 19:43:36 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:43:36 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:43:36 --> Utf8 Class Initialized
INFO - 2017-12-28 19:43:36 --> URI Class Initialized
INFO - 2017-12-28 19:43:36 --> Router Class Initialized
INFO - 2017-12-28 19:43:36 --> Output Class Initialized
INFO - 2017-12-28 19:43:36 --> Security Class Initialized
DEBUG - 2017-12-28 19:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:43:36 --> Input Class Initialized
INFO - 2017-12-28 19:43:36 --> Language Class Initialized
INFO - 2017-12-28 19:43:36 --> Loader Class Initialized
INFO - 2017-12-28 19:43:36 --> Helper loaded: url_helper
INFO - 2017-12-28 19:43:36 --> Helper loaded: form_helper
INFO - 2017-12-28 19:43:36 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:43:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:43:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:43:36 --> Form Validation Class Initialized
INFO - 2017-12-28 19:43:36 --> Model Class Initialized
INFO - 2017-12-28 19:43:36 --> Controller Class Initialized
INFO - 2017-12-28 19:43:36 --> Model Class Initialized
INFO - 2017-12-28 19:43:36 --> Model Class Initialized
INFO - 2017-12-28 19:43:36 --> Model Class Initialized
INFO - 2017-12-28 19:43:36 --> Model Class Initialized
DEBUG - 2017-12-28 19:43:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:44:24 --> Config Class Initialized
INFO - 2017-12-28 19:44:24 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:44:24 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:44:24 --> Utf8 Class Initialized
INFO - 2017-12-28 19:44:24 --> URI Class Initialized
INFO - 2017-12-28 19:44:24 --> Router Class Initialized
INFO - 2017-12-28 19:44:24 --> Output Class Initialized
INFO - 2017-12-28 19:44:24 --> Security Class Initialized
DEBUG - 2017-12-28 19:44:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:44:24 --> Input Class Initialized
INFO - 2017-12-28 19:44:24 --> Language Class Initialized
INFO - 2017-12-28 19:44:24 --> Loader Class Initialized
INFO - 2017-12-28 19:44:24 --> Helper loaded: url_helper
INFO - 2017-12-28 19:44:24 --> Helper loaded: form_helper
INFO - 2017-12-28 19:44:24 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:44:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:44:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:44:24 --> Form Validation Class Initialized
INFO - 2017-12-28 19:44:24 --> Model Class Initialized
INFO - 2017-12-28 19:44:24 --> Controller Class Initialized
INFO - 2017-12-28 19:44:24 --> Model Class Initialized
INFO - 2017-12-28 19:44:24 --> Model Class Initialized
INFO - 2017-12-28 19:44:24 --> Model Class Initialized
INFO - 2017-12-28 19:44:24 --> Model Class Initialized
DEBUG - 2017-12-28 19:44:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:44:24 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 19:44:24 --> Final output sent to browser
DEBUG - 2017-12-28 19:44:24 --> Total execution time: 0.0839
INFO - 2017-12-28 19:44:26 --> Config Class Initialized
INFO - 2017-12-28 19:44:26 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:44:26 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:44:26 --> Utf8 Class Initialized
INFO - 2017-12-28 19:44:26 --> URI Class Initialized
INFO - 2017-12-28 19:44:26 --> Router Class Initialized
INFO - 2017-12-28 19:44:26 --> Output Class Initialized
INFO - 2017-12-28 19:44:26 --> Security Class Initialized
DEBUG - 2017-12-28 19:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:44:26 --> Input Class Initialized
INFO - 2017-12-28 19:44:26 --> Language Class Initialized
INFO - 2017-12-28 19:44:26 --> Loader Class Initialized
INFO - 2017-12-28 19:44:26 --> Helper loaded: url_helper
INFO - 2017-12-28 19:44:26 --> Helper loaded: form_helper
INFO - 2017-12-28 19:44:26 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:44:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:44:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:44:26 --> Form Validation Class Initialized
INFO - 2017-12-28 19:44:26 --> Model Class Initialized
INFO - 2017-12-28 19:44:26 --> Controller Class Initialized
INFO - 2017-12-28 19:44:26 --> Model Class Initialized
INFO - 2017-12-28 19:44:26 --> Model Class Initialized
INFO - 2017-12-28 19:44:26 --> Model Class Initialized
INFO - 2017-12-28 19:44:26 --> Model Class Initialized
DEBUG - 2017-12-28 19:44:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:44:26 --> Config Class Initialized
INFO - 2017-12-28 19:44:26 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:44:26 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:44:26 --> Utf8 Class Initialized
INFO - 2017-12-28 19:44:26 --> URI Class Initialized
INFO - 2017-12-28 19:44:26 --> Router Class Initialized
INFO - 2017-12-28 19:44:26 --> Output Class Initialized
INFO - 2017-12-28 19:44:26 --> Security Class Initialized
DEBUG - 2017-12-28 19:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:44:26 --> Input Class Initialized
INFO - 2017-12-28 19:44:26 --> Language Class Initialized
ERROR - 2017-12-28 19:44:26 --> 404 Page Not Found: Faviconico/index
INFO - 2017-12-28 19:44:32 --> Config Class Initialized
INFO - 2017-12-28 19:44:32 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:44:32 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:44:32 --> Utf8 Class Initialized
INFO - 2017-12-28 19:44:32 --> URI Class Initialized
INFO - 2017-12-28 19:44:32 --> Router Class Initialized
INFO - 2017-12-28 19:44:32 --> Output Class Initialized
INFO - 2017-12-28 19:44:32 --> Security Class Initialized
DEBUG - 2017-12-28 19:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:44:32 --> Input Class Initialized
INFO - 2017-12-28 19:44:32 --> Language Class Initialized
INFO - 2017-12-28 19:44:32 --> Loader Class Initialized
INFO - 2017-12-28 19:44:32 --> Helper loaded: url_helper
INFO - 2017-12-28 19:44:32 --> Helper loaded: form_helper
INFO - 2017-12-28 19:44:32 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:44:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:44:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:44:32 --> Form Validation Class Initialized
INFO - 2017-12-28 19:44:32 --> Model Class Initialized
INFO - 2017-12-28 19:44:32 --> Controller Class Initialized
INFO - 2017-12-28 19:44:32 --> Model Class Initialized
INFO - 2017-12-28 19:44:32 --> Model Class Initialized
INFO - 2017-12-28 19:44:32 --> Model Class Initialized
INFO - 2017-12-28 19:44:32 --> Model Class Initialized
DEBUG - 2017-12-28 19:44:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:44:36 --> Config Class Initialized
INFO - 2017-12-28 19:44:36 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:44:36 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:44:36 --> Utf8 Class Initialized
INFO - 2017-12-28 19:44:36 --> URI Class Initialized
INFO - 2017-12-28 19:44:36 --> Router Class Initialized
INFO - 2017-12-28 19:44:36 --> Output Class Initialized
INFO - 2017-12-28 19:44:36 --> Security Class Initialized
DEBUG - 2017-12-28 19:44:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:44:36 --> Input Class Initialized
INFO - 2017-12-28 19:44:36 --> Language Class Initialized
INFO - 2017-12-28 19:44:36 --> Loader Class Initialized
INFO - 2017-12-28 19:44:36 --> Helper loaded: url_helper
INFO - 2017-12-28 19:44:36 --> Helper loaded: form_helper
INFO - 2017-12-28 19:44:36 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:44:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:44:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:44:37 --> Form Validation Class Initialized
INFO - 2017-12-28 19:44:37 --> Model Class Initialized
INFO - 2017-12-28 19:44:37 --> Controller Class Initialized
INFO - 2017-12-28 19:44:37 --> Model Class Initialized
INFO - 2017-12-28 19:44:37 --> Model Class Initialized
INFO - 2017-12-28 19:44:37 --> Model Class Initialized
INFO - 2017-12-28 19:44:37 --> Model Class Initialized
DEBUG - 2017-12-28 19:44:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:44:38 --> Config Class Initialized
INFO - 2017-12-28 19:44:38 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:44:38 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:44:38 --> Utf8 Class Initialized
INFO - 2017-12-28 19:44:38 --> URI Class Initialized
INFO - 2017-12-28 19:44:38 --> Router Class Initialized
INFO - 2017-12-28 19:44:38 --> Output Class Initialized
INFO - 2017-12-28 19:44:38 --> Security Class Initialized
DEBUG - 2017-12-28 19:44:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:44:38 --> Input Class Initialized
INFO - 2017-12-28 19:44:38 --> Language Class Initialized
ERROR - 2017-12-28 19:44:38 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-28 19:44:38 --> Config Class Initialized
INFO - 2017-12-28 19:44:38 --> Hooks Class Initialized
INFO - 2017-12-28 19:44:38 --> Config Class Initialized
INFO - 2017-12-28 19:44:38 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:44:38 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:44:38 --> Utf8 Class Initialized
DEBUG - 2017-12-28 19:44:38 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:44:38 --> Utf8 Class Initialized
INFO - 2017-12-28 19:44:38 --> URI Class Initialized
INFO - 2017-12-28 19:44:38 --> URI Class Initialized
INFO - 2017-12-28 19:44:38 --> Router Class Initialized
INFO - 2017-12-28 19:44:38 --> Router Class Initialized
INFO - 2017-12-28 19:44:38 --> Output Class Initialized
INFO - 2017-12-28 19:44:38 --> Output Class Initialized
INFO - 2017-12-28 19:44:38 --> Security Class Initialized
INFO - 2017-12-28 19:44:38 --> Security Class Initialized
DEBUG - 2017-12-28 19:44:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:44:38 --> Input Class Initialized
DEBUG - 2017-12-28 19:44:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:44:38 --> Language Class Initialized
INFO - 2017-12-28 19:44:38 --> Input Class Initialized
INFO - 2017-12-28 19:44:38 --> Language Class Initialized
ERROR - 2017-12-28 19:44:38 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-28 19:44:38 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-28 19:44:45 --> Config Class Initialized
INFO - 2017-12-28 19:44:45 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:44:45 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:44:45 --> Utf8 Class Initialized
INFO - 2017-12-28 19:44:45 --> URI Class Initialized
INFO - 2017-12-28 19:44:45 --> Router Class Initialized
INFO - 2017-12-28 19:44:45 --> Output Class Initialized
INFO - 2017-12-28 19:44:45 --> Security Class Initialized
DEBUG - 2017-12-28 19:44:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:44:45 --> Input Class Initialized
INFO - 2017-12-28 19:44:45 --> Language Class Initialized
INFO - 2017-12-28 19:44:46 --> Loader Class Initialized
INFO - 2017-12-28 19:44:46 --> Helper loaded: url_helper
INFO - 2017-12-28 19:44:46 --> Helper loaded: form_helper
INFO - 2017-12-28 19:44:46 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:44:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:44:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:44:46 --> Form Validation Class Initialized
INFO - 2017-12-28 19:44:46 --> Model Class Initialized
INFO - 2017-12-28 19:44:46 --> Controller Class Initialized
INFO - 2017-12-28 19:44:46 --> Model Class Initialized
INFO - 2017-12-28 19:44:46 --> Model Class Initialized
INFO - 2017-12-28 19:44:46 --> Model Class Initialized
INFO - 2017-12-28 19:44:46 --> Model Class Initialized
DEBUG - 2017-12-28 19:44:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:45:06 --> Config Class Initialized
INFO - 2017-12-28 19:45:06 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:45:06 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:45:06 --> Utf8 Class Initialized
INFO - 2017-12-28 19:45:06 --> URI Class Initialized
INFO - 2017-12-28 19:45:06 --> Router Class Initialized
INFO - 2017-12-28 19:45:06 --> Output Class Initialized
INFO - 2017-12-28 19:45:06 --> Security Class Initialized
DEBUG - 2017-12-28 19:45:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:45:06 --> Input Class Initialized
INFO - 2017-12-28 19:45:06 --> Language Class Initialized
INFO - 2017-12-28 19:45:06 --> Loader Class Initialized
INFO - 2017-12-28 19:45:06 --> Helper loaded: url_helper
INFO - 2017-12-28 19:45:06 --> Helper loaded: form_helper
INFO - 2017-12-28 19:45:06 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:45:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:45:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:45:06 --> Form Validation Class Initialized
INFO - 2017-12-28 19:45:06 --> Model Class Initialized
INFO - 2017-12-28 19:45:06 --> Controller Class Initialized
INFO - 2017-12-28 19:45:06 --> Model Class Initialized
INFO - 2017-12-28 19:45:06 --> Model Class Initialized
INFO - 2017-12-28 19:45:06 --> Model Class Initialized
INFO - 2017-12-28 19:45:06 --> Model Class Initialized
DEBUG - 2017-12-28 19:45:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:45:06 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 19:45:06 --> Final output sent to browser
DEBUG - 2017-12-28 19:45:06 --> Total execution time: 0.0981
INFO - 2017-12-28 19:45:07 --> Config Class Initialized
INFO - 2017-12-28 19:45:07 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:45:07 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:45:07 --> Utf8 Class Initialized
INFO - 2017-12-28 19:45:07 --> URI Class Initialized
INFO - 2017-12-28 19:45:07 --> Router Class Initialized
INFO - 2017-12-28 19:45:07 --> Output Class Initialized
INFO - 2017-12-28 19:45:07 --> Security Class Initialized
DEBUG - 2017-12-28 19:45:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:45:07 --> Input Class Initialized
INFO - 2017-12-28 19:45:07 --> Language Class Initialized
ERROR - 2017-12-28 19:45:07 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-28 19:45:07 --> Config Class Initialized
INFO - 2017-12-28 19:45:07 --> Hooks Class Initialized
INFO - 2017-12-28 19:45:07 --> Config Class Initialized
INFO - 2017-12-28 19:45:07 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:45:07 --> UTF-8 Support Enabled
DEBUG - 2017-12-28 19:45:07 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:45:07 --> Utf8 Class Initialized
INFO - 2017-12-28 19:45:07 --> Utf8 Class Initialized
INFO - 2017-12-28 19:45:07 --> URI Class Initialized
INFO - 2017-12-28 19:45:07 --> URI Class Initialized
INFO - 2017-12-28 19:45:07 --> Router Class Initialized
INFO - 2017-12-28 19:45:07 --> Router Class Initialized
INFO - 2017-12-28 19:45:07 --> Output Class Initialized
INFO - 2017-12-28 19:45:07 --> Output Class Initialized
INFO - 2017-12-28 19:45:07 --> Security Class Initialized
INFO - 2017-12-28 19:45:07 --> Security Class Initialized
DEBUG - 2017-12-28 19:45:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-28 19:45:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:45:07 --> Input Class Initialized
INFO - 2017-12-28 19:45:07 --> Input Class Initialized
INFO - 2017-12-28 19:45:07 --> Language Class Initialized
INFO - 2017-12-28 19:45:07 --> Language Class Initialized
ERROR - 2017-12-28 19:45:07 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-28 19:45:07 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-28 19:45:07 --> Config Class Initialized
INFO - 2017-12-28 19:45:07 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:45:07 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:45:07 --> Utf8 Class Initialized
INFO - 2017-12-28 19:45:07 --> URI Class Initialized
INFO - 2017-12-28 19:45:07 --> Router Class Initialized
INFO - 2017-12-28 19:45:07 --> Output Class Initialized
INFO - 2017-12-28 19:45:07 --> Security Class Initialized
DEBUG - 2017-12-28 19:45:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:45:08 --> Input Class Initialized
INFO - 2017-12-28 19:45:08 --> Language Class Initialized
INFO - 2017-12-28 19:45:08 --> Loader Class Initialized
INFO - 2017-12-28 19:45:08 --> Helper loaded: url_helper
INFO - 2017-12-28 19:45:08 --> Helper loaded: form_helper
INFO - 2017-12-28 19:45:08 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:45:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:45:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:45:08 --> Form Validation Class Initialized
INFO - 2017-12-28 19:45:08 --> Model Class Initialized
INFO - 2017-12-28 19:45:08 --> Controller Class Initialized
INFO - 2017-12-28 19:45:08 --> Model Class Initialized
INFO - 2017-12-28 19:45:08 --> Model Class Initialized
INFO - 2017-12-28 19:45:08 --> Model Class Initialized
INFO - 2017-12-28 19:45:08 --> Model Class Initialized
DEBUG - 2017-12-28 19:45:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:45:14 --> Config Class Initialized
INFO - 2017-12-28 19:45:14 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:45:14 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:45:14 --> Utf8 Class Initialized
INFO - 2017-12-28 19:45:14 --> URI Class Initialized
INFO - 2017-12-28 19:45:14 --> Router Class Initialized
INFO - 2017-12-28 19:45:14 --> Output Class Initialized
INFO - 2017-12-28 19:45:14 --> Security Class Initialized
DEBUG - 2017-12-28 19:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:45:14 --> Input Class Initialized
INFO - 2017-12-28 19:45:14 --> Language Class Initialized
INFO - 2017-12-28 19:45:14 --> Loader Class Initialized
INFO - 2017-12-28 19:45:14 --> Helper loaded: url_helper
INFO - 2017-12-28 19:45:14 --> Helper loaded: form_helper
INFO - 2017-12-28 19:45:14 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:45:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:45:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:45:14 --> Form Validation Class Initialized
INFO - 2017-12-28 19:45:14 --> Model Class Initialized
INFO - 2017-12-28 19:45:14 --> Controller Class Initialized
INFO - 2017-12-28 19:45:14 --> Model Class Initialized
INFO - 2017-12-28 19:45:14 --> Model Class Initialized
INFO - 2017-12-28 19:45:14 --> Model Class Initialized
INFO - 2017-12-28 19:45:14 --> Model Class Initialized
DEBUG - 2017-12-28 19:45:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:45:20 --> Config Class Initialized
INFO - 2017-12-28 19:45:20 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:45:20 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:45:20 --> Utf8 Class Initialized
INFO - 2017-12-28 19:45:20 --> URI Class Initialized
INFO - 2017-12-28 19:45:20 --> Router Class Initialized
INFO - 2017-12-28 19:45:20 --> Output Class Initialized
INFO - 2017-12-28 19:45:20 --> Security Class Initialized
DEBUG - 2017-12-28 19:45:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:45:20 --> Input Class Initialized
INFO - 2017-12-28 19:45:20 --> Language Class Initialized
INFO - 2017-12-28 19:45:20 --> Loader Class Initialized
INFO - 2017-12-28 19:45:20 --> Helper loaded: url_helper
INFO - 2017-12-28 19:45:20 --> Helper loaded: form_helper
INFO - 2017-12-28 19:45:20 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:45:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:45:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:45:20 --> Form Validation Class Initialized
INFO - 2017-12-28 19:45:20 --> Model Class Initialized
INFO - 2017-12-28 19:45:20 --> Controller Class Initialized
INFO - 2017-12-28 19:45:20 --> Model Class Initialized
INFO - 2017-12-28 19:45:20 --> Model Class Initialized
INFO - 2017-12-28 19:45:20 --> Model Class Initialized
INFO - 2017-12-28 19:45:20 --> Model Class Initialized
DEBUG - 2017-12-28 19:45:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:45:24 --> Config Class Initialized
INFO - 2017-12-28 19:45:24 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:45:24 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:45:24 --> Utf8 Class Initialized
INFO - 2017-12-28 19:45:24 --> URI Class Initialized
INFO - 2017-12-28 19:45:24 --> Router Class Initialized
INFO - 2017-12-28 19:45:24 --> Output Class Initialized
INFO - 2017-12-28 19:45:24 --> Security Class Initialized
DEBUG - 2017-12-28 19:45:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:45:24 --> Input Class Initialized
INFO - 2017-12-28 19:45:24 --> Language Class Initialized
INFO - 2017-12-28 19:45:24 --> Loader Class Initialized
INFO - 2017-12-28 19:45:24 --> Helper loaded: url_helper
INFO - 2017-12-28 19:45:24 --> Helper loaded: form_helper
INFO - 2017-12-28 19:45:24 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:45:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:45:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:45:24 --> Form Validation Class Initialized
INFO - 2017-12-28 19:45:24 --> Model Class Initialized
INFO - 2017-12-28 19:45:24 --> Controller Class Initialized
INFO - 2017-12-28 19:45:24 --> Model Class Initialized
INFO - 2017-12-28 19:45:24 --> Model Class Initialized
INFO - 2017-12-28 19:45:24 --> Model Class Initialized
INFO - 2017-12-28 19:45:24 --> Model Class Initialized
DEBUG - 2017-12-28 19:45:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:45:24 --> Config Class Initialized
INFO - 2017-12-28 19:45:24 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:45:24 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:45:24 --> Utf8 Class Initialized
INFO - 2017-12-28 19:45:24 --> URI Class Initialized
INFO - 2017-12-28 19:45:24 --> Router Class Initialized
INFO - 2017-12-28 19:45:24 --> Output Class Initialized
INFO - 2017-12-28 19:45:24 --> Security Class Initialized
DEBUG - 2017-12-28 19:45:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:45:24 --> Input Class Initialized
INFO - 2017-12-28 19:45:24 --> Language Class Initialized
INFO - 2017-12-28 19:45:24 --> Loader Class Initialized
INFO - 2017-12-28 19:45:24 --> Helper loaded: url_helper
INFO - 2017-12-28 19:45:24 --> Helper loaded: form_helper
INFO - 2017-12-28 19:45:24 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:45:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:45:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:45:24 --> Form Validation Class Initialized
INFO - 2017-12-28 19:45:24 --> Model Class Initialized
INFO - 2017-12-28 19:45:24 --> Controller Class Initialized
INFO - 2017-12-28 19:45:24 --> Model Class Initialized
INFO - 2017-12-28 19:45:24 --> Model Class Initialized
INFO - 2017-12-28 19:45:24 --> Model Class Initialized
INFO - 2017-12-28 19:45:24 --> Model Class Initialized
DEBUG - 2017-12-28 19:45:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:45:28 --> Config Class Initialized
INFO - 2017-12-28 19:45:28 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:45:28 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:45:28 --> Utf8 Class Initialized
INFO - 2017-12-28 19:45:28 --> URI Class Initialized
INFO - 2017-12-28 19:45:28 --> Router Class Initialized
INFO - 2017-12-28 19:45:28 --> Output Class Initialized
INFO - 2017-12-28 19:45:28 --> Security Class Initialized
DEBUG - 2017-12-28 19:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:45:28 --> Input Class Initialized
INFO - 2017-12-28 19:45:28 --> Language Class Initialized
INFO - 2017-12-28 19:45:28 --> Loader Class Initialized
INFO - 2017-12-28 19:45:28 --> Helper loaded: url_helper
INFO - 2017-12-28 19:45:28 --> Helper loaded: form_helper
INFO - 2017-12-28 19:45:28 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:45:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:45:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:45:28 --> Form Validation Class Initialized
INFO - 2017-12-28 19:45:28 --> Model Class Initialized
INFO - 2017-12-28 19:45:28 --> Controller Class Initialized
INFO - 2017-12-28 19:45:28 --> Model Class Initialized
INFO - 2017-12-28 19:45:28 --> Model Class Initialized
INFO - 2017-12-28 19:45:28 --> Model Class Initialized
INFO - 2017-12-28 19:45:28 --> Model Class Initialized
DEBUG - 2017-12-28 19:45:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:45:51 --> Config Class Initialized
INFO - 2017-12-28 19:45:51 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:45:51 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:45:51 --> Utf8 Class Initialized
INFO - 2017-12-28 19:45:51 --> URI Class Initialized
INFO - 2017-12-28 19:45:51 --> Router Class Initialized
INFO - 2017-12-28 19:45:51 --> Output Class Initialized
INFO - 2017-12-28 19:45:51 --> Security Class Initialized
DEBUG - 2017-12-28 19:45:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:45:51 --> Input Class Initialized
INFO - 2017-12-28 19:45:51 --> Language Class Initialized
INFO - 2017-12-28 19:45:51 --> Loader Class Initialized
INFO - 2017-12-28 19:45:51 --> Helper loaded: url_helper
INFO - 2017-12-28 19:45:51 --> Helper loaded: form_helper
INFO - 2017-12-28 19:45:51 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:45:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:45:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:45:51 --> Form Validation Class Initialized
INFO - 2017-12-28 19:45:51 --> Model Class Initialized
INFO - 2017-12-28 19:45:51 --> Controller Class Initialized
INFO - 2017-12-28 19:45:51 --> Model Class Initialized
INFO - 2017-12-28 19:45:51 --> Model Class Initialized
INFO - 2017-12-28 19:45:51 --> Model Class Initialized
INFO - 2017-12-28 19:45:51 --> Model Class Initialized
DEBUG - 2017-12-28 19:45:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:45:51 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 19:45:51 --> Final output sent to browser
DEBUG - 2017-12-28 19:45:51 --> Total execution time: 0.1187
INFO - 2017-12-28 19:45:53 --> Config Class Initialized
INFO - 2017-12-28 19:45:53 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:45:53 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:45:53 --> Utf8 Class Initialized
INFO - 2017-12-28 19:45:53 --> URI Class Initialized
INFO - 2017-12-28 19:45:53 --> Router Class Initialized
INFO - 2017-12-28 19:45:53 --> Output Class Initialized
INFO - 2017-12-28 19:45:53 --> Security Class Initialized
DEBUG - 2017-12-28 19:45:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:45:53 --> Input Class Initialized
INFO - 2017-12-28 19:45:53 --> Language Class Initialized
ERROR - 2017-12-28 19:45:53 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-28 19:45:53 --> Config Class Initialized
INFO - 2017-12-28 19:45:53 --> Hooks Class Initialized
INFO - 2017-12-28 19:45:53 --> Config Class Initialized
INFO - 2017-12-28 19:45:53 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:45:53 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:45:53 --> Utf8 Class Initialized
INFO - 2017-12-28 19:45:53 --> URI Class Initialized
DEBUG - 2017-12-28 19:45:53 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:45:53 --> Utf8 Class Initialized
INFO - 2017-12-28 19:45:53 --> Router Class Initialized
INFO - 2017-12-28 19:45:53 --> URI Class Initialized
INFO - 2017-12-28 19:45:53 --> Output Class Initialized
INFO - 2017-12-28 19:45:53 --> Router Class Initialized
INFO - 2017-12-28 19:45:53 --> Security Class Initialized
INFO - 2017-12-28 19:45:53 --> Output Class Initialized
DEBUG - 2017-12-28 19:45:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:45:53 --> Input Class Initialized
INFO - 2017-12-28 19:45:53 --> Security Class Initialized
INFO - 2017-12-28 19:45:53 --> Language Class Initialized
DEBUG - 2017-12-28 19:45:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:45:53 --> Input Class Initialized
ERROR - 2017-12-28 19:45:53 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-28 19:45:53 --> Language Class Initialized
ERROR - 2017-12-28 19:45:53 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-28 19:45:53 --> Config Class Initialized
INFO - 2017-12-28 19:45:53 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:45:53 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:45:53 --> Utf8 Class Initialized
INFO - 2017-12-28 19:45:53 --> URI Class Initialized
INFO - 2017-12-28 19:45:53 --> Router Class Initialized
INFO - 2017-12-28 19:45:53 --> Output Class Initialized
INFO - 2017-12-28 19:45:53 --> Security Class Initialized
DEBUG - 2017-12-28 19:45:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:45:53 --> Input Class Initialized
INFO - 2017-12-28 19:45:53 --> Language Class Initialized
INFO - 2017-12-28 19:45:53 --> Loader Class Initialized
INFO - 2017-12-28 19:45:53 --> Helper loaded: url_helper
INFO - 2017-12-28 19:45:53 --> Helper loaded: form_helper
INFO - 2017-12-28 19:45:53 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:45:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:45:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:45:53 --> Form Validation Class Initialized
INFO - 2017-12-28 19:45:53 --> Model Class Initialized
INFO - 2017-12-28 19:45:53 --> Controller Class Initialized
INFO - 2017-12-28 19:45:53 --> Model Class Initialized
INFO - 2017-12-28 19:45:53 --> Model Class Initialized
INFO - 2017-12-28 19:45:53 --> Model Class Initialized
INFO - 2017-12-28 19:45:53 --> Model Class Initialized
DEBUG - 2017-12-28 19:45:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:46:00 --> Config Class Initialized
INFO - 2017-12-28 19:46:00 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:46:00 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:46:00 --> Utf8 Class Initialized
INFO - 2017-12-28 19:46:00 --> URI Class Initialized
INFO - 2017-12-28 19:46:00 --> Router Class Initialized
INFO - 2017-12-28 19:46:00 --> Output Class Initialized
INFO - 2017-12-28 19:46:00 --> Security Class Initialized
DEBUG - 2017-12-28 19:46:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:46:00 --> Input Class Initialized
INFO - 2017-12-28 19:46:00 --> Language Class Initialized
INFO - 2017-12-28 19:46:00 --> Loader Class Initialized
INFO - 2017-12-28 19:46:00 --> Helper loaded: url_helper
INFO - 2017-12-28 19:46:00 --> Helper loaded: form_helper
INFO - 2017-12-28 19:46:00 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:46:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:46:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:46:00 --> Form Validation Class Initialized
INFO - 2017-12-28 19:46:00 --> Model Class Initialized
INFO - 2017-12-28 19:46:00 --> Controller Class Initialized
INFO - 2017-12-28 19:46:00 --> Model Class Initialized
INFO - 2017-12-28 19:46:00 --> Model Class Initialized
INFO - 2017-12-28 19:46:00 --> Model Class Initialized
INFO - 2017-12-28 19:46:00 --> Model Class Initialized
DEBUG - 2017-12-28 19:46:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:46:05 --> Config Class Initialized
INFO - 2017-12-28 19:46:05 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:46:05 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:46:05 --> Utf8 Class Initialized
INFO - 2017-12-28 19:46:05 --> URI Class Initialized
INFO - 2017-12-28 19:46:05 --> Router Class Initialized
INFO - 2017-12-28 19:46:05 --> Output Class Initialized
INFO - 2017-12-28 19:46:05 --> Security Class Initialized
DEBUG - 2017-12-28 19:46:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:46:05 --> Input Class Initialized
INFO - 2017-12-28 19:46:05 --> Language Class Initialized
INFO - 2017-12-28 19:46:05 --> Loader Class Initialized
INFO - 2017-12-28 19:46:05 --> Helper loaded: url_helper
INFO - 2017-12-28 19:46:05 --> Helper loaded: form_helper
INFO - 2017-12-28 19:46:05 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:46:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:46:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:46:05 --> Form Validation Class Initialized
INFO - 2017-12-28 19:46:05 --> Model Class Initialized
INFO - 2017-12-28 19:46:05 --> Controller Class Initialized
INFO - 2017-12-28 19:46:05 --> Model Class Initialized
INFO - 2017-12-28 19:46:05 --> Model Class Initialized
INFO - 2017-12-28 19:46:05 --> Model Class Initialized
INFO - 2017-12-28 19:46:05 --> Model Class Initialized
DEBUG - 2017-12-28 19:46:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:46:09 --> Config Class Initialized
INFO - 2017-12-28 19:46:09 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:46:09 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:46:09 --> Utf8 Class Initialized
INFO - 2017-12-28 19:46:09 --> URI Class Initialized
INFO - 2017-12-28 19:46:09 --> Router Class Initialized
INFO - 2017-12-28 19:46:09 --> Output Class Initialized
INFO - 2017-12-28 19:46:09 --> Security Class Initialized
DEBUG - 2017-12-28 19:46:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:46:09 --> Input Class Initialized
INFO - 2017-12-28 19:46:09 --> Language Class Initialized
INFO - 2017-12-28 19:46:09 --> Loader Class Initialized
INFO - 2017-12-28 19:46:09 --> Helper loaded: url_helper
INFO - 2017-12-28 19:46:09 --> Helper loaded: form_helper
INFO - 2017-12-28 19:46:09 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:46:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:46:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:46:09 --> Form Validation Class Initialized
INFO - 2017-12-28 19:46:09 --> Model Class Initialized
INFO - 2017-12-28 19:46:09 --> Controller Class Initialized
INFO - 2017-12-28 19:46:09 --> Model Class Initialized
INFO - 2017-12-28 19:46:09 --> Model Class Initialized
INFO - 2017-12-28 19:46:09 --> Model Class Initialized
INFO - 2017-12-28 19:46:09 --> Model Class Initialized
DEBUG - 2017-12-28 19:46:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:46:40 --> Config Class Initialized
INFO - 2017-12-28 19:46:40 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:46:40 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:46:40 --> Utf8 Class Initialized
INFO - 2017-12-28 19:46:40 --> URI Class Initialized
INFO - 2017-12-28 19:46:40 --> Router Class Initialized
INFO - 2017-12-28 19:46:40 --> Output Class Initialized
INFO - 2017-12-28 19:46:40 --> Security Class Initialized
DEBUG - 2017-12-28 19:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:46:40 --> Input Class Initialized
INFO - 2017-12-28 19:46:40 --> Language Class Initialized
INFO - 2017-12-28 19:46:40 --> Loader Class Initialized
INFO - 2017-12-28 19:46:40 --> Helper loaded: url_helper
INFO - 2017-12-28 19:46:40 --> Helper loaded: form_helper
INFO - 2017-12-28 19:46:40 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:46:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:46:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:46:40 --> Form Validation Class Initialized
INFO - 2017-12-28 19:46:40 --> Model Class Initialized
INFO - 2017-12-28 19:46:40 --> Controller Class Initialized
INFO - 2017-12-28 19:46:40 --> Model Class Initialized
INFO - 2017-12-28 19:46:40 --> Model Class Initialized
INFO - 2017-12-28 19:46:40 --> Model Class Initialized
INFO - 2017-12-28 19:46:40 --> Model Class Initialized
DEBUG - 2017-12-28 19:46:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:46:44 --> Config Class Initialized
INFO - 2017-12-28 19:46:44 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:46:44 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:46:44 --> Utf8 Class Initialized
INFO - 2017-12-28 19:46:44 --> URI Class Initialized
INFO - 2017-12-28 19:46:44 --> Router Class Initialized
INFO - 2017-12-28 19:46:44 --> Output Class Initialized
INFO - 2017-12-28 19:46:44 --> Security Class Initialized
DEBUG - 2017-12-28 19:46:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:46:44 --> Input Class Initialized
INFO - 2017-12-28 19:46:44 --> Language Class Initialized
INFO - 2017-12-28 19:46:44 --> Loader Class Initialized
INFO - 2017-12-28 19:46:44 --> Helper loaded: url_helper
INFO - 2017-12-28 19:46:44 --> Helper loaded: form_helper
INFO - 2017-12-28 19:46:44 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:46:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:46:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:46:44 --> Form Validation Class Initialized
INFO - 2017-12-28 19:46:44 --> Model Class Initialized
INFO - 2017-12-28 19:46:44 --> Controller Class Initialized
INFO - 2017-12-28 19:46:44 --> Model Class Initialized
INFO - 2017-12-28 19:46:44 --> Model Class Initialized
INFO - 2017-12-28 19:46:44 --> Model Class Initialized
INFO - 2017-12-28 19:46:44 --> Model Class Initialized
DEBUG - 2017-12-28 19:46:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:46:44 --> Config Class Initialized
INFO - 2017-12-28 19:46:44 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:46:44 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:46:44 --> Utf8 Class Initialized
INFO - 2017-12-28 19:46:44 --> URI Class Initialized
INFO - 2017-12-28 19:46:44 --> Router Class Initialized
INFO - 2017-12-28 19:46:44 --> Output Class Initialized
INFO - 2017-12-28 19:46:44 --> Security Class Initialized
DEBUG - 2017-12-28 19:46:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:46:44 --> Input Class Initialized
INFO - 2017-12-28 19:46:44 --> Language Class Initialized
INFO - 2017-12-28 19:46:44 --> Loader Class Initialized
INFO - 2017-12-28 19:46:44 --> Helper loaded: url_helper
INFO - 2017-12-28 19:46:44 --> Helper loaded: form_helper
INFO - 2017-12-28 19:46:44 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:46:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:46:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:46:45 --> Form Validation Class Initialized
INFO - 2017-12-28 19:46:45 --> Model Class Initialized
INFO - 2017-12-28 19:46:45 --> Controller Class Initialized
INFO - 2017-12-28 19:46:45 --> Model Class Initialized
INFO - 2017-12-28 19:46:45 --> Model Class Initialized
INFO - 2017-12-28 19:46:45 --> Model Class Initialized
INFO - 2017-12-28 19:46:45 --> Model Class Initialized
DEBUG - 2017-12-28 19:46:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:48:54 --> Config Class Initialized
INFO - 2017-12-28 19:48:54 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:48:54 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:48:54 --> Utf8 Class Initialized
INFO - 2017-12-28 19:48:54 --> URI Class Initialized
INFO - 2017-12-28 19:48:54 --> Router Class Initialized
INFO - 2017-12-28 19:48:54 --> Output Class Initialized
INFO - 2017-12-28 19:48:54 --> Security Class Initialized
DEBUG - 2017-12-28 19:48:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:48:54 --> Input Class Initialized
INFO - 2017-12-28 19:48:54 --> Language Class Initialized
INFO - 2017-12-28 19:48:54 --> Loader Class Initialized
INFO - 2017-12-28 19:48:54 --> Helper loaded: url_helper
INFO - 2017-12-28 19:48:54 --> Helper loaded: form_helper
INFO - 2017-12-28 19:48:55 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:48:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:48:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:48:55 --> Form Validation Class Initialized
INFO - 2017-12-28 19:48:55 --> Model Class Initialized
INFO - 2017-12-28 19:48:55 --> Controller Class Initialized
INFO - 2017-12-28 19:48:55 --> Model Class Initialized
INFO - 2017-12-28 19:48:55 --> Model Class Initialized
INFO - 2017-12-28 19:48:55 --> Model Class Initialized
INFO - 2017-12-28 19:48:55 --> Model Class Initialized
DEBUG - 2017-12-28 19:48:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:48:55 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 19:48:55 --> Final output sent to browser
DEBUG - 2017-12-28 19:48:55 --> Total execution time: 0.0922
INFO - 2017-12-28 19:48:57 --> Config Class Initialized
INFO - 2017-12-28 19:48:57 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:48:57 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:48:57 --> Utf8 Class Initialized
INFO - 2017-12-28 19:48:57 --> URI Class Initialized
INFO - 2017-12-28 19:48:57 --> Router Class Initialized
INFO - 2017-12-28 19:48:57 --> Output Class Initialized
INFO - 2017-12-28 19:48:57 --> Security Class Initialized
DEBUG - 2017-12-28 19:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:48:57 --> Input Class Initialized
INFO - 2017-12-28 19:48:57 --> Language Class Initialized
ERROR - 2017-12-28 19:48:57 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-28 19:48:57 --> Config Class Initialized
INFO - 2017-12-28 19:48:57 --> Hooks Class Initialized
INFO - 2017-12-28 19:48:57 --> Config Class Initialized
INFO - 2017-12-28 19:48:57 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:48:57 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:48:57 --> Utf8 Class Initialized
DEBUG - 2017-12-28 19:48:57 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:48:57 --> Utf8 Class Initialized
INFO - 2017-12-28 19:48:57 --> URI Class Initialized
INFO - 2017-12-28 19:48:57 --> URI Class Initialized
INFO - 2017-12-28 19:48:57 --> Router Class Initialized
INFO - 2017-12-28 19:48:57 --> Router Class Initialized
INFO - 2017-12-28 19:48:57 --> Output Class Initialized
INFO - 2017-12-28 19:48:57 --> Security Class Initialized
INFO - 2017-12-28 19:48:57 --> Output Class Initialized
DEBUG - 2017-12-28 19:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:48:57 --> Input Class Initialized
INFO - 2017-12-28 19:48:57 --> Security Class Initialized
INFO - 2017-12-28 19:48:57 --> Language Class Initialized
DEBUG - 2017-12-28 19:48:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2017-12-28 19:48:57 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-28 19:48:57 --> Input Class Initialized
INFO - 2017-12-28 19:48:57 --> Language Class Initialized
ERROR - 2017-12-28 19:48:57 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-28 19:48:57 --> Config Class Initialized
INFO - 2017-12-28 19:48:57 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:48:57 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:48:57 --> Utf8 Class Initialized
INFO - 2017-12-28 19:48:57 --> URI Class Initialized
INFO - 2017-12-28 19:48:57 --> Router Class Initialized
INFO - 2017-12-28 19:48:57 --> Output Class Initialized
INFO - 2017-12-28 19:48:57 --> Security Class Initialized
DEBUG - 2017-12-28 19:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:48:57 --> Input Class Initialized
INFO - 2017-12-28 19:48:57 --> Language Class Initialized
INFO - 2017-12-28 19:48:57 --> Loader Class Initialized
INFO - 2017-12-28 19:48:57 --> Helper loaded: url_helper
INFO - 2017-12-28 19:48:57 --> Helper loaded: form_helper
INFO - 2017-12-28 19:48:57 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:48:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:48:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:48:57 --> Form Validation Class Initialized
INFO - 2017-12-28 19:48:57 --> Model Class Initialized
INFO - 2017-12-28 19:48:57 --> Controller Class Initialized
INFO - 2017-12-28 19:48:57 --> Model Class Initialized
INFO - 2017-12-28 19:48:57 --> Model Class Initialized
INFO - 2017-12-28 19:48:57 --> Model Class Initialized
INFO - 2017-12-28 19:48:57 --> Model Class Initialized
DEBUG - 2017-12-28 19:48:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:49:05 --> Config Class Initialized
INFO - 2017-12-28 19:49:05 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:49:05 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:49:05 --> Utf8 Class Initialized
INFO - 2017-12-28 19:49:05 --> URI Class Initialized
INFO - 2017-12-28 19:49:05 --> Router Class Initialized
INFO - 2017-12-28 19:49:05 --> Output Class Initialized
INFO - 2017-12-28 19:49:05 --> Security Class Initialized
DEBUG - 2017-12-28 19:49:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:49:05 --> Input Class Initialized
INFO - 2017-12-28 19:49:05 --> Language Class Initialized
INFO - 2017-12-28 19:49:05 --> Loader Class Initialized
INFO - 2017-12-28 19:49:05 --> Helper loaded: url_helper
INFO - 2017-12-28 19:49:05 --> Helper loaded: form_helper
INFO - 2017-12-28 19:49:05 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:49:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:49:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:49:05 --> Form Validation Class Initialized
INFO - 2017-12-28 19:49:05 --> Model Class Initialized
INFO - 2017-12-28 19:49:05 --> Controller Class Initialized
INFO - 2017-12-28 19:49:05 --> Model Class Initialized
INFO - 2017-12-28 19:49:05 --> Model Class Initialized
INFO - 2017-12-28 19:49:05 --> Model Class Initialized
INFO - 2017-12-28 19:49:05 --> Model Class Initialized
DEBUG - 2017-12-28 19:49:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:49:11 --> Config Class Initialized
INFO - 2017-12-28 19:49:11 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:49:11 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:49:11 --> Utf8 Class Initialized
INFO - 2017-12-28 19:49:11 --> URI Class Initialized
INFO - 2017-12-28 19:49:11 --> Router Class Initialized
INFO - 2017-12-28 19:49:11 --> Output Class Initialized
INFO - 2017-12-28 19:49:11 --> Security Class Initialized
DEBUG - 2017-12-28 19:49:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:49:11 --> Input Class Initialized
INFO - 2017-12-28 19:49:11 --> Language Class Initialized
INFO - 2017-12-28 19:49:11 --> Loader Class Initialized
INFO - 2017-12-28 19:49:11 --> Helper loaded: url_helper
INFO - 2017-12-28 19:49:11 --> Helper loaded: form_helper
INFO - 2017-12-28 19:49:11 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:49:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:49:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:49:11 --> Form Validation Class Initialized
INFO - 2017-12-28 19:49:11 --> Model Class Initialized
INFO - 2017-12-28 19:49:11 --> Controller Class Initialized
INFO - 2017-12-28 19:49:11 --> Model Class Initialized
INFO - 2017-12-28 19:49:11 --> Model Class Initialized
INFO - 2017-12-28 19:49:11 --> Model Class Initialized
INFO - 2017-12-28 19:49:11 --> Model Class Initialized
DEBUG - 2017-12-28 19:49:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:49:15 --> Config Class Initialized
INFO - 2017-12-28 19:49:15 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:49:15 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:49:15 --> Utf8 Class Initialized
INFO - 2017-12-28 19:49:15 --> URI Class Initialized
INFO - 2017-12-28 19:49:15 --> Router Class Initialized
INFO - 2017-12-28 19:49:15 --> Output Class Initialized
INFO - 2017-12-28 19:49:15 --> Security Class Initialized
DEBUG - 2017-12-28 19:49:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:49:15 --> Input Class Initialized
INFO - 2017-12-28 19:49:15 --> Language Class Initialized
INFO - 2017-12-28 19:49:15 --> Loader Class Initialized
INFO - 2017-12-28 19:49:15 --> Helper loaded: url_helper
INFO - 2017-12-28 19:49:15 --> Helper loaded: form_helper
INFO - 2017-12-28 19:49:15 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:49:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:49:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:49:15 --> Form Validation Class Initialized
INFO - 2017-12-28 19:49:15 --> Model Class Initialized
INFO - 2017-12-28 19:49:15 --> Controller Class Initialized
INFO - 2017-12-28 19:49:15 --> Model Class Initialized
INFO - 2017-12-28 19:49:15 --> Model Class Initialized
INFO - 2017-12-28 19:49:15 --> Model Class Initialized
INFO - 2017-12-28 19:49:15 --> Model Class Initialized
DEBUG - 2017-12-28 19:49:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:49:18 --> Config Class Initialized
INFO - 2017-12-28 19:49:18 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:49:18 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:49:18 --> Utf8 Class Initialized
INFO - 2017-12-28 19:49:18 --> URI Class Initialized
INFO - 2017-12-28 19:49:18 --> Router Class Initialized
INFO - 2017-12-28 19:49:18 --> Output Class Initialized
INFO - 2017-12-28 19:49:18 --> Security Class Initialized
DEBUG - 2017-12-28 19:49:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:49:18 --> Input Class Initialized
INFO - 2017-12-28 19:49:18 --> Language Class Initialized
INFO - 2017-12-28 19:49:18 --> Loader Class Initialized
INFO - 2017-12-28 19:49:18 --> Helper loaded: url_helper
INFO - 2017-12-28 19:49:18 --> Helper loaded: form_helper
INFO - 2017-12-28 19:49:18 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:49:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:49:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:49:18 --> Form Validation Class Initialized
INFO - 2017-12-28 19:49:18 --> Model Class Initialized
INFO - 2017-12-28 19:49:18 --> Controller Class Initialized
INFO - 2017-12-28 19:49:18 --> Model Class Initialized
INFO - 2017-12-28 19:49:18 --> Model Class Initialized
INFO - 2017-12-28 19:49:18 --> Model Class Initialized
INFO - 2017-12-28 19:49:18 --> Model Class Initialized
DEBUG - 2017-12-28 19:49:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:49:19 --> Config Class Initialized
INFO - 2017-12-28 19:49:19 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:49:19 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:49:19 --> Utf8 Class Initialized
INFO - 2017-12-28 19:49:19 --> URI Class Initialized
INFO - 2017-12-28 19:49:19 --> Router Class Initialized
INFO - 2017-12-28 19:49:19 --> Output Class Initialized
INFO - 2017-12-28 19:49:19 --> Security Class Initialized
DEBUG - 2017-12-28 19:49:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:49:19 --> Input Class Initialized
INFO - 2017-12-28 19:49:19 --> Language Class Initialized
INFO - 2017-12-28 19:49:19 --> Loader Class Initialized
INFO - 2017-12-28 19:49:19 --> Helper loaded: url_helper
INFO - 2017-12-28 19:49:19 --> Helper loaded: form_helper
INFO - 2017-12-28 19:49:19 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:49:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:49:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:49:19 --> Form Validation Class Initialized
INFO - 2017-12-28 19:49:19 --> Model Class Initialized
INFO - 2017-12-28 19:49:19 --> Controller Class Initialized
INFO - 2017-12-28 19:49:19 --> Model Class Initialized
INFO - 2017-12-28 19:49:19 --> Model Class Initialized
INFO - 2017-12-28 19:49:19 --> Model Class Initialized
INFO - 2017-12-28 19:49:19 --> Model Class Initialized
DEBUG - 2017-12-28 19:49:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:49:19 --> Config Class Initialized
INFO - 2017-12-28 19:49:19 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:49:19 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:49:19 --> Utf8 Class Initialized
INFO - 2017-12-28 19:49:19 --> URI Class Initialized
INFO - 2017-12-28 19:49:19 --> Router Class Initialized
INFO - 2017-12-28 19:49:19 --> Output Class Initialized
INFO - 2017-12-28 19:49:19 --> Security Class Initialized
DEBUG - 2017-12-28 19:49:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:49:19 --> Input Class Initialized
INFO - 2017-12-28 19:49:19 --> Language Class Initialized
INFO - 2017-12-28 19:49:19 --> Loader Class Initialized
INFO - 2017-12-28 19:49:19 --> Helper loaded: url_helper
INFO - 2017-12-28 19:49:19 --> Helper loaded: form_helper
INFO - 2017-12-28 19:49:19 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:49:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:49:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:49:19 --> Form Validation Class Initialized
INFO - 2017-12-28 19:49:19 --> Model Class Initialized
INFO - 2017-12-28 19:49:19 --> Controller Class Initialized
INFO - 2017-12-28 19:49:19 --> Model Class Initialized
INFO - 2017-12-28 19:49:19 --> Model Class Initialized
INFO - 2017-12-28 19:49:19 --> Model Class Initialized
INFO - 2017-12-28 19:49:19 --> Model Class Initialized
DEBUG - 2017-12-28 19:49:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:49:19 --> Config Class Initialized
INFO - 2017-12-28 19:49:19 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:49:19 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:49:19 --> Utf8 Class Initialized
INFO - 2017-12-28 19:49:19 --> URI Class Initialized
INFO - 2017-12-28 19:49:19 --> Router Class Initialized
INFO - 2017-12-28 19:49:19 --> Output Class Initialized
INFO - 2017-12-28 19:49:19 --> Security Class Initialized
DEBUG - 2017-12-28 19:49:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:49:19 --> Input Class Initialized
INFO - 2017-12-28 19:49:19 --> Language Class Initialized
INFO - 2017-12-28 19:49:19 --> Loader Class Initialized
INFO - 2017-12-28 19:49:19 --> Helper loaded: url_helper
INFO - 2017-12-28 19:49:19 --> Helper loaded: form_helper
INFO - 2017-12-28 19:49:20 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:49:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:49:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:49:20 --> Form Validation Class Initialized
INFO - 2017-12-28 19:49:20 --> Model Class Initialized
INFO - 2017-12-28 19:49:20 --> Controller Class Initialized
INFO - 2017-12-28 19:49:20 --> Model Class Initialized
INFO - 2017-12-28 19:49:20 --> Model Class Initialized
INFO - 2017-12-28 19:49:20 --> Model Class Initialized
INFO - 2017-12-28 19:49:20 --> Model Class Initialized
DEBUG - 2017-12-28 19:49:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:49:20 --> Config Class Initialized
INFO - 2017-12-28 19:49:20 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:49:20 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:49:20 --> Utf8 Class Initialized
INFO - 2017-12-28 19:49:20 --> URI Class Initialized
INFO - 2017-12-28 19:49:20 --> Router Class Initialized
INFO - 2017-12-28 19:49:20 --> Output Class Initialized
INFO - 2017-12-28 19:49:20 --> Security Class Initialized
DEBUG - 2017-12-28 19:49:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:49:20 --> Input Class Initialized
INFO - 2017-12-28 19:49:20 --> Language Class Initialized
INFO - 2017-12-28 19:49:20 --> Loader Class Initialized
INFO - 2017-12-28 19:49:20 --> Helper loaded: url_helper
INFO - 2017-12-28 19:49:20 --> Helper loaded: form_helper
INFO - 2017-12-28 19:49:20 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:49:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:49:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:49:20 --> Form Validation Class Initialized
INFO - 2017-12-28 19:49:20 --> Model Class Initialized
INFO - 2017-12-28 19:49:20 --> Controller Class Initialized
INFO - 2017-12-28 19:49:20 --> Model Class Initialized
INFO - 2017-12-28 19:49:20 --> Model Class Initialized
INFO - 2017-12-28 19:49:20 --> Model Class Initialized
INFO - 2017-12-28 19:49:20 --> Model Class Initialized
DEBUG - 2017-12-28 19:49:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:49:20 --> Config Class Initialized
INFO - 2017-12-28 19:49:20 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:49:20 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:49:20 --> Utf8 Class Initialized
INFO - 2017-12-28 19:49:20 --> URI Class Initialized
INFO - 2017-12-28 19:49:20 --> Router Class Initialized
INFO - 2017-12-28 19:49:20 --> Output Class Initialized
INFO - 2017-12-28 19:49:20 --> Security Class Initialized
DEBUG - 2017-12-28 19:49:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:49:20 --> Input Class Initialized
INFO - 2017-12-28 19:49:20 --> Language Class Initialized
INFO - 2017-12-28 19:49:20 --> Loader Class Initialized
INFO - 2017-12-28 19:49:20 --> Helper loaded: url_helper
INFO - 2017-12-28 19:49:20 --> Helper loaded: form_helper
INFO - 2017-12-28 19:49:20 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:49:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:49:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:49:20 --> Form Validation Class Initialized
INFO - 2017-12-28 19:49:20 --> Model Class Initialized
INFO - 2017-12-28 19:49:20 --> Controller Class Initialized
INFO - 2017-12-28 19:49:20 --> Model Class Initialized
INFO - 2017-12-28 19:49:20 --> Model Class Initialized
INFO - 2017-12-28 19:49:20 --> Model Class Initialized
INFO - 2017-12-28 19:49:20 --> Model Class Initialized
DEBUG - 2017-12-28 19:49:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:49:20 --> Config Class Initialized
INFO - 2017-12-28 19:49:20 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:49:20 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:49:20 --> Utf8 Class Initialized
INFO - 2017-12-28 19:49:20 --> URI Class Initialized
INFO - 2017-12-28 19:49:20 --> Router Class Initialized
INFO - 2017-12-28 19:49:20 --> Output Class Initialized
INFO - 2017-12-28 19:49:20 --> Security Class Initialized
DEBUG - 2017-12-28 19:49:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:49:20 --> Input Class Initialized
INFO - 2017-12-28 19:49:20 --> Language Class Initialized
INFO - 2017-12-28 19:49:20 --> Loader Class Initialized
INFO - 2017-12-28 19:49:20 --> Helper loaded: url_helper
INFO - 2017-12-28 19:49:20 --> Helper loaded: form_helper
INFO - 2017-12-28 19:49:20 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:49:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:49:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:49:20 --> Form Validation Class Initialized
INFO - 2017-12-28 19:49:20 --> Model Class Initialized
INFO - 2017-12-28 19:49:20 --> Controller Class Initialized
INFO - 2017-12-28 19:49:20 --> Model Class Initialized
INFO - 2017-12-28 19:49:20 --> Model Class Initialized
INFO - 2017-12-28 19:49:20 --> Model Class Initialized
INFO - 2017-12-28 19:49:20 --> Model Class Initialized
DEBUG - 2017-12-28 19:49:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:49:26 --> Config Class Initialized
INFO - 2017-12-28 19:49:26 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:49:26 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:49:26 --> Utf8 Class Initialized
INFO - 2017-12-28 19:49:26 --> URI Class Initialized
INFO - 2017-12-28 19:49:26 --> Router Class Initialized
INFO - 2017-12-28 19:49:26 --> Output Class Initialized
INFO - 2017-12-28 19:49:26 --> Security Class Initialized
DEBUG - 2017-12-28 19:49:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:49:26 --> Input Class Initialized
INFO - 2017-12-28 19:49:26 --> Language Class Initialized
INFO - 2017-12-28 19:49:26 --> Loader Class Initialized
INFO - 2017-12-28 19:49:26 --> Helper loaded: url_helper
INFO - 2017-12-28 19:49:26 --> Helper loaded: form_helper
INFO - 2017-12-28 19:49:26 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:49:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:49:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:49:26 --> Form Validation Class Initialized
INFO - 2017-12-28 19:49:26 --> Model Class Initialized
INFO - 2017-12-28 19:49:26 --> Controller Class Initialized
INFO - 2017-12-28 19:49:26 --> Model Class Initialized
INFO - 2017-12-28 19:49:26 --> Model Class Initialized
INFO - 2017-12-28 19:49:26 --> Model Class Initialized
INFO - 2017-12-28 19:49:26 --> Model Class Initialized
DEBUG - 2017-12-28 19:49:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:49:30 --> Config Class Initialized
INFO - 2017-12-28 19:49:30 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:49:30 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:49:30 --> Utf8 Class Initialized
INFO - 2017-12-28 19:49:30 --> URI Class Initialized
INFO - 2017-12-28 19:49:30 --> Router Class Initialized
INFO - 2017-12-28 19:49:30 --> Output Class Initialized
INFO - 2017-12-28 19:49:30 --> Security Class Initialized
DEBUG - 2017-12-28 19:49:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:49:30 --> Input Class Initialized
INFO - 2017-12-28 19:49:30 --> Language Class Initialized
INFO - 2017-12-28 19:49:30 --> Loader Class Initialized
INFO - 2017-12-28 19:49:30 --> Helper loaded: url_helper
INFO - 2017-12-28 19:49:30 --> Helper loaded: form_helper
INFO - 2017-12-28 19:49:30 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:49:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:49:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:49:30 --> Form Validation Class Initialized
INFO - 2017-12-28 19:49:30 --> Model Class Initialized
INFO - 2017-12-28 19:49:30 --> Controller Class Initialized
INFO - 2017-12-28 19:49:30 --> Model Class Initialized
INFO - 2017-12-28 19:49:30 --> Model Class Initialized
INFO - 2017-12-28 19:49:30 --> Model Class Initialized
INFO - 2017-12-28 19:49:30 --> Model Class Initialized
DEBUG - 2017-12-28 19:49:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:49:34 --> Config Class Initialized
INFO - 2017-12-28 19:49:34 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:49:34 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:49:34 --> Utf8 Class Initialized
INFO - 2017-12-28 19:49:34 --> URI Class Initialized
INFO - 2017-12-28 19:49:34 --> Router Class Initialized
INFO - 2017-12-28 19:49:34 --> Output Class Initialized
INFO - 2017-12-28 19:49:34 --> Security Class Initialized
DEBUG - 2017-12-28 19:49:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:49:34 --> Input Class Initialized
INFO - 2017-12-28 19:49:34 --> Language Class Initialized
INFO - 2017-12-28 19:49:34 --> Loader Class Initialized
INFO - 2017-12-28 19:49:34 --> Helper loaded: url_helper
INFO - 2017-12-28 19:49:34 --> Helper loaded: form_helper
INFO - 2017-12-28 19:49:34 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:49:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:49:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:49:34 --> Form Validation Class Initialized
INFO - 2017-12-28 19:49:34 --> Model Class Initialized
INFO - 2017-12-28 19:49:34 --> Controller Class Initialized
INFO - 2017-12-28 19:49:34 --> Model Class Initialized
INFO - 2017-12-28 19:49:34 --> Model Class Initialized
INFO - 2017-12-28 19:49:34 --> Model Class Initialized
INFO - 2017-12-28 19:49:34 --> Model Class Initialized
DEBUG - 2017-12-28 19:49:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:50:15 --> Config Class Initialized
INFO - 2017-12-28 19:50:15 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:50:15 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:50:15 --> Utf8 Class Initialized
INFO - 2017-12-28 19:50:15 --> URI Class Initialized
INFO - 2017-12-28 19:50:15 --> Router Class Initialized
INFO - 2017-12-28 19:50:15 --> Output Class Initialized
INFO - 2017-12-28 19:50:15 --> Security Class Initialized
DEBUG - 2017-12-28 19:50:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:50:15 --> Input Class Initialized
INFO - 2017-12-28 19:50:15 --> Language Class Initialized
INFO - 2017-12-28 19:50:15 --> Loader Class Initialized
INFO - 2017-12-28 19:50:15 --> Helper loaded: url_helper
INFO - 2017-12-28 19:50:15 --> Helper loaded: form_helper
INFO - 2017-12-28 19:50:15 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:50:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:50:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:50:15 --> Form Validation Class Initialized
INFO - 2017-12-28 19:50:15 --> Model Class Initialized
INFO - 2017-12-28 19:50:15 --> Controller Class Initialized
INFO - 2017-12-28 19:50:15 --> Model Class Initialized
INFO - 2017-12-28 19:50:15 --> Model Class Initialized
INFO - 2017-12-28 19:50:15 --> Model Class Initialized
INFO - 2017-12-28 19:50:15 --> Model Class Initialized
DEBUG - 2017-12-28 19:50:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:50:15 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 19:50:15 --> Final output sent to browser
DEBUG - 2017-12-28 19:50:15 --> Total execution time: 0.0992
INFO - 2017-12-28 19:50:17 --> Config Class Initialized
INFO - 2017-12-28 19:50:17 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:50:17 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:50:17 --> Utf8 Class Initialized
INFO - 2017-12-28 19:50:17 --> URI Class Initialized
INFO - 2017-12-28 19:50:17 --> Router Class Initialized
INFO - 2017-12-28 19:50:17 --> Output Class Initialized
INFO - 2017-12-28 19:50:17 --> Security Class Initialized
DEBUG - 2017-12-28 19:50:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:50:17 --> Input Class Initialized
INFO - 2017-12-28 19:50:17 --> Language Class Initialized
ERROR - 2017-12-28 19:50:17 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-28 19:50:17 --> Config Class Initialized
INFO - 2017-12-28 19:50:17 --> Hooks Class Initialized
INFO - 2017-12-28 19:50:17 --> Config Class Initialized
INFO - 2017-12-28 19:50:17 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:50:17 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:50:17 --> Utf8 Class Initialized
INFO - 2017-12-28 19:50:17 --> URI Class Initialized
DEBUG - 2017-12-28 19:50:17 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:50:17 --> Utf8 Class Initialized
INFO - 2017-12-28 19:50:17 --> Router Class Initialized
INFO - 2017-12-28 19:50:17 --> URI Class Initialized
INFO - 2017-12-28 19:50:17 --> Output Class Initialized
INFO - 2017-12-28 19:50:17 --> Router Class Initialized
INFO - 2017-12-28 19:50:17 --> Security Class Initialized
DEBUG - 2017-12-28 19:50:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:50:17 --> Input Class Initialized
INFO - 2017-12-28 19:50:17 --> Output Class Initialized
INFO - 2017-12-28 19:50:17 --> Language Class Initialized
INFO - 2017-12-28 19:50:17 --> Security Class Initialized
ERROR - 2017-12-28 19:50:17 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2017-12-28 19:50:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:50:17 --> Input Class Initialized
INFO - 2017-12-28 19:50:17 --> Language Class Initialized
ERROR - 2017-12-28 19:50:17 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-28 19:50:17 --> Config Class Initialized
INFO - 2017-12-28 19:50:17 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:50:17 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:50:17 --> Utf8 Class Initialized
INFO - 2017-12-28 19:50:17 --> URI Class Initialized
INFO - 2017-12-28 19:50:17 --> Router Class Initialized
INFO - 2017-12-28 19:50:17 --> Output Class Initialized
INFO - 2017-12-28 19:50:17 --> Security Class Initialized
DEBUG - 2017-12-28 19:50:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:50:17 --> Input Class Initialized
INFO - 2017-12-28 19:50:17 --> Language Class Initialized
INFO - 2017-12-28 19:50:17 --> Loader Class Initialized
INFO - 2017-12-28 19:50:17 --> Helper loaded: url_helper
INFO - 2017-12-28 19:50:17 --> Helper loaded: form_helper
INFO - 2017-12-28 19:50:17 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:50:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:50:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:50:17 --> Form Validation Class Initialized
INFO - 2017-12-28 19:50:17 --> Model Class Initialized
INFO - 2017-12-28 19:50:17 --> Controller Class Initialized
INFO - 2017-12-28 19:50:17 --> Model Class Initialized
INFO - 2017-12-28 19:50:17 --> Model Class Initialized
INFO - 2017-12-28 19:50:17 --> Model Class Initialized
INFO - 2017-12-28 19:50:17 --> Model Class Initialized
DEBUG - 2017-12-28 19:50:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:50:30 --> Config Class Initialized
INFO - 2017-12-28 19:50:30 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:50:30 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:50:30 --> Utf8 Class Initialized
INFO - 2017-12-28 19:50:30 --> URI Class Initialized
INFO - 2017-12-28 19:50:30 --> Router Class Initialized
INFO - 2017-12-28 19:50:30 --> Output Class Initialized
INFO - 2017-12-28 19:50:30 --> Security Class Initialized
DEBUG - 2017-12-28 19:50:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:50:30 --> Input Class Initialized
INFO - 2017-12-28 19:50:30 --> Language Class Initialized
INFO - 2017-12-28 19:50:30 --> Loader Class Initialized
INFO - 2017-12-28 19:50:30 --> Helper loaded: url_helper
INFO - 2017-12-28 19:50:30 --> Helper loaded: form_helper
INFO - 2017-12-28 19:50:30 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:50:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:50:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:50:31 --> Form Validation Class Initialized
INFO - 2017-12-28 19:50:31 --> Model Class Initialized
INFO - 2017-12-28 19:50:31 --> Controller Class Initialized
INFO - 2017-12-28 19:50:31 --> Model Class Initialized
INFO - 2017-12-28 19:50:31 --> Model Class Initialized
INFO - 2017-12-28 19:50:31 --> Model Class Initialized
INFO - 2017-12-28 19:50:31 --> Model Class Initialized
DEBUG - 2017-12-28 19:50:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:50:34 --> Config Class Initialized
INFO - 2017-12-28 19:50:34 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:50:34 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:50:34 --> Utf8 Class Initialized
INFO - 2017-12-28 19:50:34 --> URI Class Initialized
INFO - 2017-12-28 19:50:34 --> Router Class Initialized
INFO - 2017-12-28 19:50:34 --> Output Class Initialized
INFO - 2017-12-28 19:50:34 --> Security Class Initialized
DEBUG - 2017-12-28 19:50:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:50:34 --> Input Class Initialized
INFO - 2017-12-28 19:50:34 --> Language Class Initialized
INFO - 2017-12-28 19:50:34 --> Loader Class Initialized
INFO - 2017-12-28 19:50:34 --> Helper loaded: url_helper
INFO - 2017-12-28 19:50:34 --> Helper loaded: form_helper
INFO - 2017-12-28 19:50:34 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:50:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:50:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:50:34 --> Form Validation Class Initialized
INFO - 2017-12-28 19:50:34 --> Model Class Initialized
INFO - 2017-12-28 19:50:34 --> Controller Class Initialized
INFO - 2017-12-28 19:50:34 --> Model Class Initialized
INFO - 2017-12-28 19:50:34 --> Model Class Initialized
INFO - 2017-12-28 19:50:34 --> Model Class Initialized
INFO - 2017-12-28 19:50:34 --> Model Class Initialized
DEBUG - 2017-12-28 19:50:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:50:40 --> Config Class Initialized
INFO - 2017-12-28 19:50:40 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:50:40 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:50:40 --> Utf8 Class Initialized
INFO - 2017-12-28 19:50:40 --> URI Class Initialized
INFO - 2017-12-28 19:50:40 --> Router Class Initialized
INFO - 2017-12-28 19:50:40 --> Output Class Initialized
INFO - 2017-12-28 19:50:40 --> Security Class Initialized
DEBUG - 2017-12-28 19:50:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:50:40 --> Input Class Initialized
INFO - 2017-12-28 19:50:40 --> Language Class Initialized
INFO - 2017-12-28 19:50:40 --> Loader Class Initialized
INFO - 2017-12-28 19:50:40 --> Helper loaded: url_helper
INFO - 2017-12-28 19:50:40 --> Helper loaded: form_helper
INFO - 2017-12-28 19:50:40 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:50:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:50:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:50:40 --> Form Validation Class Initialized
INFO - 2017-12-28 19:50:40 --> Model Class Initialized
INFO - 2017-12-28 19:50:40 --> Controller Class Initialized
INFO - 2017-12-28 19:50:40 --> Model Class Initialized
INFO - 2017-12-28 19:50:40 --> Model Class Initialized
INFO - 2017-12-28 19:50:40 --> Model Class Initialized
INFO - 2017-12-28 19:50:40 --> Model Class Initialized
DEBUG - 2017-12-28 19:50:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:50:44 --> Config Class Initialized
INFO - 2017-12-28 19:50:44 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:50:44 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:50:44 --> Utf8 Class Initialized
INFO - 2017-12-28 19:50:44 --> URI Class Initialized
INFO - 2017-12-28 19:50:44 --> Router Class Initialized
INFO - 2017-12-28 19:50:44 --> Output Class Initialized
INFO - 2017-12-28 19:50:44 --> Security Class Initialized
DEBUG - 2017-12-28 19:50:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:50:44 --> Input Class Initialized
INFO - 2017-12-28 19:50:44 --> Language Class Initialized
INFO - 2017-12-28 19:50:44 --> Loader Class Initialized
INFO - 2017-12-28 19:50:44 --> Helper loaded: url_helper
INFO - 2017-12-28 19:50:44 --> Helper loaded: form_helper
INFO - 2017-12-28 19:50:44 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:50:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:50:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:50:44 --> Form Validation Class Initialized
INFO - 2017-12-28 19:50:44 --> Model Class Initialized
INFO - 2017-12-28 19:50:44 --> Controller Class Initialized
INFO - 2017-12-28 19:50:44 --> Model Class Initialized
INFO - 2017-12-28 19:50:44 --> Model Class Initialized
INFO - 2017-12-28 19:50:44 --> Model Class Initialized
INFO - 2017-12-28 19:50:44 --> Model Class Initialized
DEBUG - 2017-12-28 19:50:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:50:44 --> Config Class Initialized
INFO - 2017-12-28 19:50:44 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:50:44 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:50:44 --> Utf8 Class Initialized
INFO - 2017-12-28 19:50:44 --> URI Class Initialized
INFO - 2017-12-28 19:50:44 --> Router Class Initialized
INFO - 2017-12-28 19:50:44 --> Output Class Initialized
INFO - 2017-12-28 19:50:44 --> Security Class Initialized
DEBUG - 2017-12-28 19:50:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:50:44 --> Input Class Initialized
INFO - 2017-12-28 19:50:44 --> Language Class Initialized
INFO - 2017-12-28 19:50:44 --> Loader Class Initialized
INFO - 2017-12-28 19:50:44 --> Helper loaded: url_helper
INFO - 2017-12-28 19:50:44 --> Helper loaded: form_helper
INFO - 2017-12-28 19:50:44 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:50:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:50:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:50:45 --> Form Validation Class Initialized
INFO - 2017-12-28 19:50:45 --> Model Class Initialized
INFO - 2017-12-28 19:50:45 --> Controller Class Initialized
INFO - 2017-12-28 19:50:45 --> Model Class Initialized
INFO - 2017-12-28 19:50:45 --> Model Class Initialized
INFO - 2017-12-28 19:50:45 --> Model Class Initialized
INFO - 2017-12-28 19:50:45 --> Model Class Initialized
DEBUG - 2017-12-28 19:50:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:50:47 --> Config Class Initialized
INFO - 2017-12-28 19:50:47 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:50:47 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:50:47 --> Utf8 Class Initialized
INFO - 2017-12-28 19:50:47 --> URI Class Initialized
INFO - 2017-12-28 19:50:47 --> Router Class Initialized
INFO - 2017-12-28 19:50:47 --> Output Class Initialized
INFO - 2017-12-28 19:50:47 --> Security Class Initialized
DEBUG - 2017-12-28 19:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:50:47 --> Input Class Initialized
INFO - 2017-12-28 19:50:47 --> Language Class Initialized
ERROR - 2017-12-28 19:50:47 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-28 19:50:47 --> Config Class Initialized
INFO - 2017-12-28 19:50:47 --> Config Class Initialized
INFO - 2017-12-28 19:50:47 --> Hooks Class Initialized
INFO - 2017-12-28 19:50:47 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:50:47 --> UTF-8 Support Enabled
DEBUG - 2017-12-28 19:50:47 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:50:47 --> Utf8 Class Initialized
INFO - 2017-12-28 19:50:47 --> Utf8 Class Initialized
INFO - 2017-12-28 19:50:47 --> URI Class Initialized
INFO - 2017-12-28 19:50:47 --> URI Class Initialized
INFO - 2017-12-28 19:50:47 --> Router Class Initialized
INFO - 2017-12-28 19:50:47 --> Router Class Initialized
INFO - 2017-12-28 19:50:47 --> Output Class Initialized
INFO - 2017-12-28 19:50:47 --> Output Class Initialized
INFO - 2017-12-28 19:50:47 --> Security Class Initialized
INFO - 2017-12-28 19:50:47 --> Security Class Initialized
DEBUG - 2017-12-28 19:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:50:47 --> Input Class Initialized
DEBUG - 2017-12-28 19:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:50:47 --> Input Class Initialized
INFO - 2017-12-28 19:50:47 --> Language Class Initialized
INFO - 2017-12-28 19:50:47 --> Language Class Initialized
ERROR - 2017-12-28 19:50:47 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-28 19:50:47 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-28 19:50:55 --> Config Class Initialized
INFO - 2017-12-28 19:50:55 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:50:55 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:50:55 --> Utf8 Class Initialized
INFO - 2017-12-28 19:50:55 --> URI Class Initialized
INFO - 2017-12-28 19:50:55 --> Router Class Initialized
INFO - 2017-12-28 19:50:55 --> Output Class Initialized
INFO - 2017-12-28 19:50:55 --> Security Class Initialized
DEBUG - 2017-12-28 19:50:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:50:55 --> Input Class Initialized
INFO - 2017-12-28 19:50:55 --> Language Class Initialized
INFO - 2017-12-28 19:50:55 --> Loader Class Initialized
INFO - 2017-12-28 19:50:55 --> Helper loaded: url_helper
INFO - 2017-12-28 19:50:55 --> Helper loaded: form_helper
INFO - 2017-12-28 19:50:55 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:50:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:50:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:50:55 --> Form Validation Class Initialized
INFO - 2017-12-28 19:50:55 --> Model Class Initialized
INFO - 2017-12-28 19:50:55 --> Controller Class Initialized
INFO - 2017-12-28 19:50:55 --> Model Class Initialized
INFO - 2017-12-28 19:50:55 --> Model Class Initialized
INFO - 2017-12-28 19:50:55 --> Model Class Initialized
INFO - 2017-12-28 19:50:55 --> Model Class Initialized
DEBUG - 2017-12-28 19:50:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:51:19 --> Config Class Initialized
INFO - 2017-12-28 19:51:19 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:51:19 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:51:19 --> Utf8 Class Initialized
INFO - 2017-12-28 19:51:19 --> URI Class Initialized
INFO - 2017-12-28 19:51:19 --> Router Class Initialized
INFO - 2017-12-28 19:51:19 --> Output Class Initialized
INFO - 2017-12-28 19:51:19 --> Security Class Initialized
DEBUG - 2017-12-28 19:51:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:51:19 --> Input Class Initialized
INFO - 2017-12-28 19:51:19 --> Language Class Initialized
INFO - 2017-12-28 19:51:19 --> Loader Class Initialized
INFO - 2017-12-28 19:51:19 --> Helper loaded: url_helper
INFO - 2017-12-28 19:51:19 --> Helper loaded: form_helper
INFO - 2017-12-28 19:51:19 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:51:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:51:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:51:19 --> Form Validation Class Initialized
INFO - 2017-12-28 19:51:19 --> Model Class Initialized
INFO - 2017-12-28 19:51:19 --> Controller Class Initialized
INFO - 2017-12-28 19:51:19 --> Model Class Initialized
INFO - 2017-12-28 19:51:19 --> Model Class Initialized
INFO - 2017-12-28 19:51:19 --> Model Class Initialized
INFO - 2017-12-28 19:51:19 --> Model Class Initialized
DEBUG - 2017-12-28 19:51:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:51:19 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 19:51:19 --> Final output sent to browser
DEBUG - 2017-12-28 19:51:19 --> Total execution time: 0.0505
INFO - 2017-12-28 19:51:21 --> Config Class Initialized
INFO - 2017-12-28 19:51:21 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:51:21 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:51:21 --> Utf8 Class Initialized
INFO - 2017-12-28 19:51:21 --> URI Class Initialized
INFO - 2017-12-28 19:51:21 --> Router Class Initialized
INFO - 2017-12-28 19:51:21 --> Output Class Initialized
INFO - 2017-12-28 19:51:21 --> Security Class Initialized
DEBUG - 2017-12-28 19:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:51:21 --> Input Class Initialized
INFO - 2017-12-28 19:51:21 --> Language Class Initialized
ERROR - 2017-12-28 19:51:21 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-28 19:51:21 --> Config Class Initialized
INFO - 2017-12-28 19:51:21 --> Config Class Initialized
INFO - 2017-12-28 19:51:21 --> Hooks Class Initialized
INFO - 2017-12-28 19:51:21 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:51:21 --> UTF-8 Support Enabled
DEBUG - 2017-12-28 19:51:21 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:51:21 --> Utf8 Class Initialized
INFO - 2017-12-28 19:51:21 --> Utf8 Class Initialized
INFO - 2017-12-28 19:51:21 --> URI Class Initialized
INFO - 2017-12-28 19:51:21 --> URI Class Initialized
INFO - 2017-12-28 19:51:21 --> Router Class Initialized
INFO - 2017-12-28 19:51:21 --> Router Class Initialized
INFO - 2017-12-28 19:51:21 --> Output Class Initialized
INFO - 2017-12-28 19:51:21 --> Output Class Initialized
INFO - 2017-12-28 19:51:21 --> Security Class Initialized
INFO - 2017-12-28 19:51:21 --> Security Class Initialized
DEBUG - 2017-12-28 19:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:51:21 --> Input Class Initialized
DEBUG - 2017-12-28 19:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:51:21 --> Language Class Initialized
INFO - 2017-12-28 19:51:21 --> Input Class Initialized
INFO - 2017-12-28 19:51:21 --> Language Class Initialized
ERROR - 2017-12-28 19:51:21 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-28 19:51:21 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-28 19:51:21 --> Config Class Initialized
INFO - 2017-12-28 19:51:21 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:51:21 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:51:21 --> Utf8 Class Initialized
INFO - 2017-12-28 19:51:21 --> URI Class Initialized
INFO - 2017-12-28 19:51:21 --> Router Class Initialized
INFO - 2017-12-28 19:51:21 --> Output Class Initialized
INFO - 2017-12-28 19:51:21 --> Security Class Initialized
DEBUG - 2017-12-28 19:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:51:21 --> Input Class Initialized
INFO - 2017-12-28 19:51:21 --> Language Class Initialized
INFO - 2017-12-28 19:51:21 --> Loader Class Initialized
INFO - 2017-12-28 19:51:21 --> Helper loaded: url_helper
INFO - 2017-12-28 19:51:21 --> Helper loaded: form_helper
INFO - 2017-12-28 19:51:21 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:51:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:51:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:51:21 --> Form Validation Class Initialized
INFO - 2017-12-28 19:51:21 --> Model Class Initialized
INFO - 2017-12-28 19:51:21 --> Controller Class Initialized
INFO - 2017-12-28 19:51:21 --> Model Class Initialized
INFO - 2017-12-28 19:51:21 --> Model Class Initialized
INFO - 2017-12-28 19:51:21 --> Model Class Initialized
INFO - 2017-12-28 19:51:21 --> Model Class Initialized
DEBUG - 2017-12-28 19:51:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:51:26 --> Config Class Initialized
INFO - 2017-12-28 19:51:26 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:51:26 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:51:26 --> Utf8 Class Initialized
INFO - 2017-12-28 19:51:26 --> URI Class Initialized
INFO - 2017-12-28 19:51:26 --> Router Class Initialized
INFO - 2017-12-28 19:51:26 --> Output Class Initialized
INFO - 2017-12-28 19:51:26 --> Security Class Initialized
DEBUG - 2017-12-28 19:51:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:51:26 --> Input Class Initialized
INFO - 2017-12-28 19:51:26 --> Language Class Initialized
INFO - 2017-12-28 19:51:26 --> Loader Class Initialized
INFO - 2017-12-28 19:51:26 --> Helper loaded: url_helper
INFO - 2017-12-28 19:51:26 --> Helper loaded: form_helper
INFO - 2017-12-28 19:51:26 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:51:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:51:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:51:26 --> Form Validation Class Initialized
INFO - 2017-12-28 19:51:26 --> Model Class Initialized
INFO - 2017-12-28 19:51:26 --> Controller Class Initialized
INFO - 2017-12-28 19:51:26 --> Model Class Initialized
INFO - 2017-12-28 19:51:26 --> Model Class Initialized
INFO - 2017-12-28 19:51:26 --> Model Class Initialized
INFO - 2017-12-28 19:51:26 --> Model Class Initialized
DEBUG - 2017-12-28 19:51:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:51:31 --> Config Class Initialized
INFO - 2017-12-28 19:51:31 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:51:31 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:51:31 --> Utf8 Class Initialized
INFO - 2017-12-28 19:51:31 --> URI Class Initialized
INFO - 2017-12-28 19:51:31 --> Router Class Initialized
INFO - 2017-12-28 19:51:31 --> Output Class Initialized
INFO - 2017-12-28 19:51:31 --> Security Class Initialized
DEBUG - 2017-12-28 19:51:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:51:31 --> Input Class Initialized
INFO - 2017-12-28 19:51:31 --> Language Class Initialized
INFO - 2017-12-28 19:51:31 --> Loader Class Initialized
INFO - 2017-12-28 19:51:31 --> Helper loaded: url_helper
INFO - 2017-12-28 19:51:31 --> Helper loaded: form_helper
INFO - 2017-12-28 19:51:31 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:51:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:51:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:51:31 --> Form Validation Class Initialized
INFO - 2017-12-28 19:51:31 --> Model Class Initialized
INFO - 2017-12-28 19:51:31 --> Controller Class Initialized
INFO - 2017-12-28 19:51:31 --> Model Class Initialized
INFO - 2017-12-28 19:51:31 --> Model Class Initialized
INFO - 2017-12-28 19:51:31 --> Model Class Initialized
INFO - 2017-12-28 19:51:31 --> Model Class Initialized
DEBUG - 2017-12-28 19:51:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:52:13 --> Config Class Initialized
INFO - 2017-12-28 19:52:13 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:52:13 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:52:13 --> Utf8 Class Initialized
INFO - 2017-12-28 19:52:13 --> URI Class Initialized
INFO - 2017-12-28 19:52:13 --> Router Class Initialized
INFO - 2017-12-28 19:52:13 --> Output Class Initialized
INFO - 2017-12-28 19:52:13 --> Security Class Initialized
DEBUG - 2017-12-28 19:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:52:13 --> Input Class Initialized
INFO - 2017-12-28 19:52:13 --> Language Class Initialized
INFO - 2017-12-28 19:52:13 --> Loader Class Initialized
INFO - 2017-12-28 19:52:13 --> Helper loaded: url_helper
INFO - 2017-12-28 19:52:13 --> Helper loaded: form_helper
INFO - 2017-12-28 19:52:13 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:52:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:52:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:52:13 --> Form Validation Class Initialized
INFO - 2017-12-28 19:52:13 --> Model Class Initialized
INFO - 2017-12-28 19:52:13 --> Controller Class Initialized
INFO - 2017-12-28 19:52:13 --> Model Class Initialized
INFO - 2017-12-28 19:52:13 --> Model Class Initialized
INFO - 2017-12-28 19:52:13 --> Model Class Initialized
INFO - 2017-12-28 19:52:13 --> Model Class Initialized
DEBUG - 2017-12-28 19:52:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:52:13 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 19:52:13 --> Final output sent to browser
DEBUG - 2017-12-28 19:52:13 --> Total execution time: 0.1179
INFO - 2017-12-28 19:52:15 --> Config Class Initialized
INFO - 2017-12-28 19:52:15 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:52:15 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:52:15 --> Utf8 Class Initialized
INFO - 2017-12-28 19:52:15 --> URI Class Initialized
INFO - 2017-12-28 19:52:15 --> Router Class Initialized
INFO - 2017-12-28 19:52:15 --> Output Class Initialized
INFO - 2017-12-28 19:52:15 --> Security Class Initialized
DEBUG - 2017-12-28 19:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:52:15 --> Input Class Initialized
INFO - 2017-12-28 19:52:15 --> Language Class Initialized
ERROR - 2017-12-28 19:52:15 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-28 19:52:15 --> Config Class Initialized
INFO - 2017-12-28 19:52:15 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:52:15 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:52:15 --> Utf8 Class Initialized
INFO - 2017-12-28 19:52:15 --> Config Class Initialized
INFO - 2017-12-28 19:52:15 --> URI Class Initialized
INFO - 2017-12-28 19:52:15 --> Hooks Class Initialized
INFO - 2017-12-28 19:52:15 --> Router Class Initialized
DEBUG - 2017-12-28 19:52:15 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:52:15 --> Utf8 Class Initialized
INFO - 2017-12-28 19:52:15 --> Output Class Initialized
INFO - 2017-12-28 19:52:15 --> URI Class Initialized
INFO - 2017-12-28 19:52:15 --> Security Class Initialized
DEBUG - 2017-12-28 19:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:52:15 --> Input Class Initialized
INFO - 2017-12-28 19:52:15 --> Router Class Initialized
INFO - 2017-12-28 19:52:15 --> Language Class Initialized
INFO - 2017-12-28 19:52:15 --> Output Class Initialized
ERROR - 2017-12-28 19:52:15 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-28 19:52:15 --> Security Class Initialized
DEBUG - 2017-12-28 19:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:52:15 --> Input Class Initialized
INFO - 2017-12-28 19:52:15 --> Language Class Initialized
ERROR - 2017-12-28 19:52:15 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-28 19:52:15 --> Config Class Initialized
INFO - 2017-12-28 19:52:15 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:52:15 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:52:15 --> Utf8 Class Initialized
INFO - 2017-12-28 19:52:15 --> URI Class Initialized
INFO - 2017-12-28 19:52:15 --> Router Class Initialized
INFO - 2017-12-28 19:52:15 --> Output Class Initialized
INFO - 2017-12-28 19:52:15 --> Security Class Initialized
DEBUG - 2017-12-28 19:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:52:15 --> Input Class Initialized
INFO - 2017-12-28 19:52:15 --> Language Class Initialized
INFO - 2017-12-28 19:52:15 --> Loader Class Initialized
INFO - 2017-12-28 19:52:15 --> Helper loaded: url_helper
INFO - 2017-12-28 19:52:15 --> Helper loaded: form_helper
INFO - 2017-12-28 19:52:15 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:52:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:52:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:52:15 --> Form Validation Class Initialized
INFO - 2017-12-28 19:52:15 --> Model Class Initialized
INFO - 2017-12-28 19:52:15 --> Controller Class Initialized
INFO - 2017-12-28 19:52:15 --> Model Class Initialized
INFO - 2017-12-28 19:52:15 --> Model Class Initialized
INFO - 2017-12-28 19:52:15 --> Model Class Initialized
INFO - 2017-12-28 19:52:15 --> Model Class Initialized
DEBUG - 2017-12-28 19:52:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:52:24 --> Config Class Initialized
INFO - 2017-12-28 19:52:24 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:52:24 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:52:24 --> Utf8 Class Initialized
INFO - 2017-12-28 19:52:24 --> URI Class Initialized
INFO - 2017-12-28 19:52:24 --> Router Class Initialized
INFO - 2017-12-28 19:52:24 --> Output Class Initialized
INFO - 2017-12-28 19:52:24 --> Security Class Initialized
DEBUG - 2017-12-28 19:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:52:24 --> Input Class Initialized
INFO - 2017-12-28 19:52:24 --> Language Class Initialized
INFO - 2017-12-28 19:52:24 --> Loader Class Initialized
INFO - 2017-12-28 19:52:24 --> Helper loaded: url_helper
INFO - 2017-12-28 19:52:24 --> Helper loaded: form_helper
INFO - 2017-12-28 19:52:24 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:52:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:52:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:52:24 --> Form Validation Class Initialized
INFO - 2017-12-28 19:52:24 --> Model Class Initialized
INFO - 2017-12-28 19:52:24 --> Controller Class Initialized
INFO - 2017-12-28 19:52:24 --> Model Class Initialized
INFO - 2017-12-28 19:52:24 --> Model Class Initialized
INFO - 2017-12-28 19:52:24 --> Model Class Initialized
INFO - 2017-12-28 19:52:24 --> Model Class Initialized
DEBUG - 2017-12-28 19:52:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:52:28 --> Config Class Initialized
INFO - 2017-12-28 19:52:28 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:52:28 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:52:28 --> Utf8 Class Initialized
INFO - 2017-12-28 19:52:28 --> URI Class Initialized
INFO - 2017-12-28 19:52:28 --> Router Class Initialized
INFO - 2017-12-28 19:52:28 --> Output Class Initialized
INFO - 2017-12-28 19:52:28 --> Security Class Initialized
DEBUG - 2017-12-28 19:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:52:28 --> Input Class Initialized
INFO - 2017-12-28 19:52:28 --> Language Class Initialized
INFO - 2017-12-28 19:52:28 --> Loader Class Initialized
INFO - 2017-12-28 19:52:28 --> Helper loaded: url_helper
INFO - 2017-12-28 19:52:28 --> Helper loaded: form_helper
INFO - 2017-12-28 19:52:28 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:52:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:52:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:52:28 --> Form Validation Class Initialized
INFO - 2017-12-28 19:52:28 --> Model Class Initialized
INFO - 2017-12-28 19:52:28 --> Controller Class Initialized
INFO - 2017-12-28 19:52:28 --> Model Class Initialized
INFO - 2017-12-28 19:52:28 --> Model Class Initialized
INFO - 2017-12-28 19:52:28 --> Model Class Initialized
INFO - 2017-12-28 19:52:28 --> Model Class Initialized
DEBUG - 2017-12-28 19:52:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:52:51 --> Config Class Initialized
INFO - 2017-12-28 19:52:51 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:52:51 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:52:51 --> Utf8 Class Initialized
INFO - 2017-12-28 19:52:51 --> URI Class Initialized
INFO - 2017-12-28 19:52:51 --> Router Class Initialized
INFO - 2017-12-28 19:52:51 --> Output Class Initialized
INFO - 2017-12-28 19:52:51 --> Security Class Initialized
DEBUG - 2017-12-28 19:52:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:52:51 --> Input Class Initialized
INFO - 2017-12-28 19:52:51 --> Language Class Initialized
INFO - 2017-12-28 19:52:51 --> Loader Class Initialized
INFO - 2017-12-28 19:52:51 --> Helper loaded: url_helper
INFO - 2017-12-28 19:52:51 --> Helper loaded: form_helper
INFO - 2017-12-28 19:52:51 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:52:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:52:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:52:51 --> Form Validation Class Initialized
INFO - 2017-12-28 19:52:51 --> Model Class Initialized
INFO - 2017-12-28 19:52:51 --> Controller Class Initialized
INFO - 2017-12-28 19:52:51 --> Model Class Initialized
INFO - 2017-12-28 19:52:51 --> Model Class Initialized
INFO - 2017-12-28 19:52:51 --> Model Class Initialized
INFO - 2017-12-28 19:52:51 --> Model Class Initialized
DEBUG - 2017-12-28 19:52:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:52:51 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 19:52:51 --> Final output sent to browser
DEBUG - 2017-12-28 19:52:51 --> Total execution time: 0.0693
INFO - 2017-12-28 19:52:53 --> Config Class Initialized
INFO - 2017-12-28 19:52:53 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:52:53 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:52:53 --> Utf8 Class Initialized
INFO - 2017-12-28 19:52:53 --> URI Class Initialized
INFO - 2017-12-28 19:52:53 --> Router Class Initialized
INFO - 2017-12-28 19:52:53 --> Output Class Initialized
INFO - 2017-12-28 19:52:53 --> Security Class Initialized
DEBUG - 2017-12-28 19:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:52:53 --> Input Class Initialized
INFO - 2017-12-28 19:52:53 --> Language Class Initialized
ERROR - 2017-12-28 19:52:53 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-28 19:52:53 --> Config Class Initialized
INFO - 2017-12-28 19:52:53 --> Hooks Class Initialized
INFO - 2017-12-28 19:52:53 --> Config Class Initialized
INFO - 2017-12-28 19:52:53 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:52:53 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:52:53 --> Utf8 Class Initialized
DEBUG - 2017-12-28 19:52:53 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:52:53 --> Utf8 Class Initialized
INFO - 2017-12-28 19:52:53 --> URI Class Initialized
INFO - 2017-12-28 19:52:53 --> URI Class Initialized
INFO - 2017-12-28 19:52:53 --> Router Class Initialized
INFO - 2017-12-28 19:52:53 --> Router Class Initialized
INFO - 2017-12-28 19:52:53 --> Output Class Initialized
INFO - 2017-12-28 19:52:53 --> Output Class Initialized
INFO - 2017-12-28 19:52:53 --> Security Class Initialized
INFO - 2017-12-28 19:52:53 --> Security Class Initialized
DEBUG - 2017-12-28 19:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:52:53 --> Input Class Initialized
INFO - 2017-12-28 19:52:53 --> Language Class Initialized
DEBUG - 2017-12-28 19:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:52:53 --> Input Class Initialized
ERROR - 2017-12-28 19:52:53 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-28 19:52:53 --> Language Class Initialized
ERROR - 2017-12-28 19:52:53 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-28 19:52:53 --> Config Class Initialized
INFO - 2017-12-28 19:52:53 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:52:53 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:52:53 --> Utf8 Class Initialized
INFO - 2017-12-28 19:52:53 --> URI Class Initialized
INFO - 2017-12-28 19:52:53 --> Router Class Initialized
INFO - 2017-12-28 19:52:53 --> Output Class Initialized
INFO - 2017-12-28 19:52:53 --> Security Class Initialized
DEBUG - 2017-12-28 19:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:52:53 --> Input Class Initialized
INFO - 2017-12-28 19:52:53 --> Language Class Initialized
INFO - 2017-12-28 19:52:53 --> Loader Class Initialized
INFO - 2017-12-28 19:52:53 --> Helper loaded: url_helper
INFO - 2017-12-28 19:52:53 --> Helper loaded: form_helper
INFO - 2017-12-28 19:52:53 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:52:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:52:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:52:53 --> Form Validation Class Initialized
INFO - 2017-12-28 19:52:53 --> Model Class Initialized
INFO - 2017-12-28 19:52:53 --> Controller Class Initialized
INFO - 2017-12-28 19:52:53 --> Model Class Initialized
INFO - 2017-12-28 19:52:53 --> Model Class Initialized
INFO - 2017-12-28 19:52:53 --> Model Class Initialized
INFO - 2017-12-28 19:52:53 --> Model Class Initialized
DEBUG - 2017-12-28 19:52:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:52:59 --> Config Class Initialized
INFO - 2017-12-28 19:52:59 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:52:59 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:52:59 --> Utf8 Class Initialized
INFO - 2017-12-28 19:52:59 --> URI Class Initialized
INFO - 2017-12-28 19:52:59 --> Router Class Initialized
INFO - 2017-12-28 19:52:59 --> Output Class Initialized
INFO - 2017-12-28 19:52:59 --> Security Class Initialized
DEBUG - 2017-12-28 19:52:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:52:59 --> Input Class Initialized
INFO - 2017-12-28 19:52:59 --> Language Class Initialized
INFO - 2017-12-28 19:52:59 --> Loader Class Initialized
INFO - 2017-12-28 19:52:59 --> Helper loaded: url_helper
INFO - 2017-12-28 19:52:59 --> Helper loaded: form_helper
INFO - 2017-12-28 19:52:59 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:53:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:53:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:53:00 --> Form Validation Class Initialized
INFO - 2017-12-28 19:53:00 --> Model Class Initialized
INFO - 2017-12-28 19:53:00 --> Controller Class Initialized
INFO - 2017-12-28 19:53:00 --> Model Class Initialized
INFO - 2017-12-28 19:53:00 --> Model Class Initialized
INFO - 2017-12-28 19:53:00 --> Model Class Initialized
INFO - 2017-12-28 19:53:00 --> Model Class Initialized
DEBUG - 2017-12-28 19:53:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:53:05 --> Config Class Initialized
INFO - 2017-12-28 19:53:05 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:53:05 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:53:05 --> Utf8 Class Initialized
INFO - 2017-12-28 19:53:05 --> URI Class Initialized
INFO - 2017-12-28 19:53:05 --> Router Class Initialized
INFO - 2017-12-28 19:53:05 --> Output Class Initialized
INFO - 2017-12-28 19:53:05 --> Security Class Initialized
DEBUG - 2017-12-28 19:53:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:53:05 --> Input Class Initialized
INFO - 2017-12-28 19:53:05 --> Language Class Initialized
INFO - 2017-12-28 19:53:05 --> Loader Class Initialized
INFO - 2017-12-28 19:53:05 --> Helper loaded: url_helper
INFO - 2017-12-28 19:53:05 --> Helper loaded: form_helper
INFO - 2017-12-28 19:53:05 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:53:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:53:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:53:05 --> Form Validation Class Initialized
INFO - 2017-12-28 19:53:05 --> Model Class Initialized
INFO - 2017-12-28 19:53:05 --> Controller Class Initialized
INFO - 2017-12-28 19:53:05 --> Model Class Initialized
INFO - 2017-12-28 19:53:05 --> Model Class Initialized
INFO - 2017-12-28 19:53:05 --> Model Class Initialized
INFO - 2017-12-28 19:53:05 --> Model Class Initialized
DEBUG - 2017-12-28 19:53:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:53:05 --> Config Class Initialized
INFO - 2017-12-28 19:53:05 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:53:05 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:53:05 --> Utf8 Class Initialized
INFO - 2017-12-28 19:53:05 --> URI Class Initialized
INFO - 2017-12-28 19:53:05 --> Router Class Initialized
INFO - 2017-12-28 19:53:05 --> Output Class Initialized
INFO - 2017-12-28 19:53:05 --> Security Class Initialized
DEBUG - 2017-12-28 19:53:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:53:05 --> Input Class Initialized
INFO - 2017-12-28 19:53:05 --> Language Class Initialized
INFO - 2017-12-28 19:53:05 --> Loader Class Initialized
INFO - 2017-12-28 19:53:05 --> Helper loaded: url_helper
INFO - 2017-12-28 19:53:05 --> Helper loaded: form_helper
INFO - 2017-12-28 19:53:05 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:53:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:53:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:53:05 --> Form Validation Class Initialized
INFO - 2017-12-28 19:53:05 --> Model Class Initialized
INFO - 2017-12-28 19:53:05 --> Controller Class Initialized
INFO - 2017-12-28 19:53:05 --> Model Class Initialized
INFO - 2017-12-28 19:53:05 --> Model Class Initialized
INFO - 2017-12-28 19:53:05 --> Model Class Initialized
INFO - 2017-12-28 19:53:05 --> Model Class Initialized
DEBUG - 2017-12-28 19:53:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:53:09 --> Config Class Initialized
INFO - 2017-12-28 19:53:09 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:53:09 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:53:09 --> Utf8 Class Initialized
INFO - 2017-12-28 19:53:09 --> URI Class Initialized
INFO - 2017-12-28 19:53:09 --> Router Class Initialized
INFO - 2017-12-28 19:53:09 --> Output Class Initialized
INFO - 2017-12-28 19:53:09 --> Security Class Initialized
DEBUG - 2017-12-28 19:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:53:09 --> Input Class Initialized
INFO - 2017-12-28 19:53:09 --> Language Class Initialized
INFO - 2017-12-28 19:53:09 --> Loader Class Initialized
INFO - 2017-12-28 19:53:09 --> Helper loaded: url_helper
INFO - 2017-12-28 19:53:09 --> Helper loaded: form_helper
INFO - 2017-12-28 19:53:09 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:53:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:53:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:53:09 --> Form Validation Class Initialized
INFO - 2017-12-28 19:53:09 --> Model Class Initialized
INFO - 2017-12-28 19:53:09 --> Controller Class Initialized
INFO - 2017-12-28 19:53:09 --> Model Class Initialized
INFO - 2017-12-28 19:53:09 --> Model Class Initialized
INFO - 2017-12-28 19:53:09 --> Model Class Initialized
INFO - 2017-12-28 19:53:09 --> Model Class Initialized
DEBUG - 2017-12-28 19:53:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:54:00 --> Config Class Initialized
INFO - 2017-12-28 19:54:00 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:54:00 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:54:00 --> Utf8 Class Initialized
INFO - 2017-12-28 19:54:00 --> URI Class Initialized
INFO - 2017-12-28 19:54:00 --> Router Class Initialized
INFO - 2017-12-28 19:54:00 --> Output Class Initialized
INFO - 2017-12-28 19:54:00 --> Security Class Initialized
DEBUG - 2017-12-28 19:54:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:54:00 --> Input Class Initialized
INFO - 2017-12-28 19:54:00 --> Language Class Initialized
INFO - 2017-12-28 19:54:00 --> Loader Class Initialized
INFO - 2017-12-28 19:54:00 --> Helper loaded: url_helper
INFO - 2017-12-28 19:54:00 --> Helper loaded: form_helper
INFO - 2017-12-28 19:54:00 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:54:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:54:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:54:00 --> Form Validation Class Initialized
INFO - 2017-12-28 19:54:00 --> Model Class Initialized
INFO - 2017-12-28 19:54:00 --> Controller Class Initialized
INFO - 2017-12-28 19:54:00 --> Model Class Initialized
INFO - 2017-12-28 19:54:00 --> Model Class Initialized
INFO - 2017-12-28 19:54:00 --> Model Class Initialized
INFO - 2017-12-28 19:54:00 --> Model Class Initialized
DEBUG - 2017-12-28 19:54:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:54:00 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 19:54:00 --> Final output sent to browser
DEBUG - 2017-12-28 19:54:00 --> Total execution time: 0.0873
INFO - 2017-12-28 19:54:00 --> Config Class Initialized
INFO - 2017-12-28 19:54:00 --> Hooks Class Initialized
INFO - 2017-12-28 19:54:00 --> Config Class Initialized
INFO - 2017-12-28 19:54:00 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:54:00 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:54:00 --> Utf8 Class Initialized
DEBUG - 2017-12-28 19:54:00 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:54:00 --> Utf8 Class Initialized
INFO - 2017-12-28 19:54:00 --> URI Class Initialized
INFO - 2017-12-28 19:54:00 --> URI Class Initialized
INFO - 2017-12-28 19:54:00 --> Router Class Initialized
INFO - 2017-12-28 19:54:00 --> Router Class Initialized
INFO - 2017-12-28 19:54:00 --> Output Class Initialized
INFO - 2017-12-28 19:54:00 --> Output Class Initialized
INFO - 2017-12-28 19:54:00 --> Security Class Initialized
INFO - 2017-12-28 19:54:00 --> Security Class Initialized
DEBUG - 2017-12-28 19:54:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:54:00 --> Input Class Initialized
DEBUG - 2017-12-28 19:54:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:54:00 --> Input Class Initialized
INFO - 2017-12-28 19:54:00 --> Language Class Initialized
INFO - 2017-12-28 19:54:00 --> Language Class Initialized
ERROR - 2017-12-28 19:54:00 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-28 19:54:00 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-28 19:54:02 --> Config Class Initialized
INFO - 2017-12-28 19:54:02 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:54:02 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:54:02 --> Utf8 Class Initialized
INFO - 2017-12-28 19:54:02 --> URI Class Initialized
INFO - 2017-12-28 19:54:02 --> Router Class Initialized
INFO - 2017-12-28 19:54:02 --> Output Class Initialized
INFO - 2017-12-28 19:54:02 --> Security Class Initialized
DEBUG - 2017-12-28 19:54:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:54:02 --> Input Class Initialized
INFO - 2017-12-28 19:54:02 --> Language Class Initialized
ERROR - 2017-12-28 19:54:02 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-28 19:54:02 --> Config Class Initialized
INFO - 2017-12-28 19:54:02 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:54:02 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:54:02 --> Utf8 Class Initialized
INFO - 2017-12-28 19:54:02 --> URI Class Initialized
INFO - 2017-12-28 19:54:02 --> Router Class Initialized
INFO - 2017-12-28 19:54:02 --> Output Class Initialized
INFO - 2017-12-28 19:54:02 --> Security Class Initialized
DEBUG - 2017-12-28 19:54:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:54:02 --> Input Class Initialized
INFO - 2017-12-28 19:54:02 --> Language Class Initialized
INFO - 2017-12-28 19:54:02 --> Loader Class Initialized
INFO - 2017-12-28 19:54:02 --> Helper loaded: url_helper
INFO - 2017-12-28 19:54:02 --> Helper loaded: form_helper
INFO - 2017-12-28 19:54:02 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:54:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:54:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:54:02 --> Form Validation Class Initialized
INFO - 2017-12-28 19:54:02 --> Model Class Initialized
INFO - 2017-12-28 19:54:02 --> Controller Class Initialized
INFO - 2017-12-28 19:54:02 --> Model Class Initialized
INFO - 2017-12-28 19:54:02 --> Model Class Initialized
INFO - 2017-12-28 19:54:02 --> Model Class Initialized
INFO - 2017-12-28 19:54:02 --> Model Class Initialized
DEBUG - 2017-12-28 19:54:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:54:08 --> Config Class Initialized
INFO - 2017-12-28 19:54:08 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:54:08 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:54:08 --> Utf8 Class Initialized
INFO - 2017-12-28 19:54:08 --> URI Class Initialized
INFO - 2017-12-28 19:54:08 --> Router Class Initialized
INFO - 2017-12-28 19:54:08 --> Output Class Initialized
INFO - 2017-12-28 19:54:08 --> Security Class Initialized
DEBUG - 2017-12-28 19:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:54:08 --> Input Class Initialized
INFO - 2017-12-28 19:54:08 --> Language Class Initialized
INFO - 2017-12-28 19:54:08 --> Loader Class Initialized
INFO - 2017-12-28 19:54:08 --> Helper loaded: url_helper
INFO - 2017-12-28 19:54:08 --> Helper loaded: form_helper
INFO - 2017-12-28 19:54:08 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:54:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:54:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:54:08 --> Form Validation Class Initialized
INFO - 2017-12-28 19:54:08 --> Model Class Initialized
INFO - 2017-12-28 19:54:08 --> Controller Class Initialized
INFO - 2017-12-28 19:54:08 --> Model Class Initialized
INFO - 2017-12-28 19:54:08 --> Model Class Initialized
INFO - 2017-12-28 19:54:08 --> Model Class Initialized
INFO - 2017-12-28 19:54:08 --> Model Class Initialized
DEBUG - 2017-12-28 19:54:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:54:11 --> Config Class Initialized
INFO - 2017-12-28 19:54:11 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:54:11 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:54:11 --> Utf8 Class Initialized
INFO - 2017-12-28 19:54:11 --> URI Class Initialized
INFO - 2017-12-28 19:54:11 --> Router Class Initialized
INFO - 2017-12-28 19:54:11 --> Output Class Initialized
INFO - 2017-12-28 19:54:11 --> Security Class Initialized
DEBUG - 2017-12-28 19:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:54:11 --> Input Class Initialized
INFO - 2017-12-28 19:54:11 --> Language Class Initialized
INFO - 2017-12-28 19:54:11 --> Loader Class Initialized
INFO - 2017-12-28 19:54:11 --> Helper loaded: url_helper
INFO - 2017-12-28 19:54:11 --> Helper loaded: form_helper
INFO - 2017-12-28 19:54:11 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:54:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:54:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:54:11 --> Form Validation Class Initialized
INFO - 2017-12-28 19:54:11 --> Model Class Initialized
INFO - 2017-12-28 19:54:11 --> Controller Class Initialized
INFO - 2017-12-28 19:54:11 --> Model Class Initialized
INFO - 2017-12-28 19:54:11 --> Model Class Initialized
INFO - 2017-12-28 19:54:11 --> Model Class Initialized
INFO - 2017-12-28 19:54:11 --> Model Class Initialized
DEBUG - 2017-12-28 19:54:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:54:34 --> Config Class Initialized
INFO - 2017-12-28 19:54:34 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:54:34 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:54:34 --> Utf8 Class Initialized
INFO - 2017-12-28 19:54:34 --> URI Class Initialized
INFO - 2017-12-28 19:54:34 --> Router Class Initialized
INFO - 2017-12-28 19:54:34 --> Output Class Initialized
INFO - 2017-12-28 19:54:34 --> Security Class Initialized
DEBUG - 2017-12-28 19:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:54:34 --> Input Class Initialized
INFO - 2017-12-28 19:54:34 --> Language Class Initialized
INFO - 2017-12-28 19:54:34 --> Loader Class Initialized
INFO - 2017-12-28 19:54:34 --> Helper loaded: url_helper
INFO - 2017-12-28 19:54:34 --> Helper loaded: form_helper
INFO - 2017-12-28 19:54:34 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:54:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:54:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:54:34 --> Form Validation Class Initialized
INFO - 2017-12-28 19:54:34 --> Model Class Initialized
INFO - 2017-12-28 19:54:34 --> Controller Class Initialized
INFO - 2017-12-28 19:54:34 --> Model Class Initialized
INFO - 2017-12-28 19:54:34 --> Model Class Initialized
INFO - 2017-12-28 19:54:34 --> Model Class Initialized
INFO - 2017-12-28 19:54:34 --> Model Class Initialized
DEBUG - 2017-12-28 19:54:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:54:34 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 19:54:34 --> Final output sent to browser
DEBUG - 2017-12-28 19:54:34 --> Total execution time: 0.0461
INFO - 2017-12-28 19:54:36 --> Config Class Initialized
INFO - 2017-12-28 19:54:36 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:54:36 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:54:36 --> Utf8 Class Initialized
INFO - 2017-12-28 19:54:36 --> URI Class Initialized
INFO - 2017-12-28 19:54:36 --> Router Class Initialized
INFO - 2017-12-28 19:54:36 --> Output Class Initialized
INFO - 2017-12-28 19:54:36 --> Security Class Initialized
DEBUG - 2017-12-28 19:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:54:36 --> Input Class Initialized
INFO - 2017-12-28 19:54:36 --> Language Class Initialized
INFO - 2017-12-28 19:54:36 --> Loader Class Initialized
INFO - 2017-12-28 19:54:36 --> Helper loaded: url_helper
INFO - 2017-12-28 19:54:36 --> Helper loaded: form_helper
INFO - 2017-12-28 19:54:36 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:54:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:54:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:54:36 --> Form Validation Class Initialized
INFO - 2017-12-28 19:54:36 --> Model Class Initialized
INFO - 2017-12-28 19:54:36 --> Controller Class Initialized
INFO - 2017-12-28 19:54:36 --> Model Class Initialized
INFO - 2017-12-28 19:54:36 --> Model Class Initialized
INFO - 2017-12-28 19:54:36 --> Model Class Initialized
INFO - 2017-12-28 19:54:36 --> Model Class Initialized
DEBUG - 2017-12-28 19:54:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:54:36 --> Config Class Initialized
INFO - 2017-12-28 19:54:36 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:54:36 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:54:36 --> Utf8 Class Initialized
INFO - 2017-12-28 19:54:36 --> URI Class Initialized
INFO - 2017-12-28 19:54:36 --> Router Class Initialized
INFO - 2017-12-28 19:54:36 --> Output Class Initialized
INFO - 2017-12-28 19:54:36 --> Security Class Initialized
DEBUG - 2017-12-28 19:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:54:36 --> Input Class Initialized
INFO - 2017-12-28 19:54:36 --> Language Class Initialized
ERROR - 2017-12-28 19:54:36 --> 404 Page Not Found: Faviconico/index
INFO - 2017-12-28 19:54:42 --> Config Class Initialized
INFO - 2017-12-28 19:54:42 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:54:42 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:54:42 --> Utf8 Class Initialized
INFO - 2017-12-28 19:54:42 --> URI Class Initialized
INFO - 2017-12-28 19:54:42 --> Router Class Initialized
INFO - 2017-12-28 19:54:42 --> Output Class Initialized
INFO - 2017-12-28 19:54:42 --> Security Class Initialized
DEBUG - 2017-12-28 19:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:54:42 --> Input Class Initialized
INFO - 2017-12-28 19:54:42 --> Language Class Initialized
INFO - 2017-12-28 19:54:42 --> Loader Class Initialized
INFO - 2017-12-28 19:54:42 --> Helper loaded: url_helper
INFO - 2017-12-28 19:54:42 --> Helper loaded: form_helper
INFO - 2017-12-28 19:54:42 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:54:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:54:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:54:42 --> Form Validation Class Initialized
INFO - 2017-12-28 19:54:42 --> Model Class Initialized
INFO - 2017-12-28 19:54:42 --> Controller Class Initialized
INFO - 2017-12-28 19:54:42 --> Model Class Initialized
INFO - 2017-12-28 19:54:42 --> Model Class Initialized
INFO - 2017-12-28 19:54:42 --> Model Class Initialized
INFO - 2017-12-28 19:54:42 --> Model Class Initialized
DEBUG - 2017-12-28 19:54:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:54:51 --> Config Class Initialized
INFO - 2017-12-28 19:54:51 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:54:51 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:54:51 --> Utf8 Class Initialized
INFO - 2017-12-28 19:54:51 --> URI Class Initialized
INFO - 2017-12-28 19:54:51 --> Router Class Initialized
INFO - 2017-12-28 19:54:51 --> Output Class Initialized
INFO - 2017-12-28 19:54:51 --> Security Class Initialized
DEBUG - 2017-12-28 19:54:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:54:51 --> Input Class Initialized
INFO - 2017-12-28 19:54:51 --> Language Class Initialized
INFO - 2017-12-28 19:54:51 --> Loader Class Initialized
INFO - 2017-12-28 19:54:51 --> Helper loaded: url_helper
INFO - 2017-12-28 19:54:51 --> Helper loaded: form_helper
INFO - 2017-12-28 19:54:51 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:54:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:54:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:54:51 --> Form Validation Class Initialized
INFO - 2017-12-28 19:54:51 --> Model Class Initialized
INFO - 2017-12-28 19:54:51 --> Controller Class Initialized
INFO - 2017-12-28 19:54:51 --> Model Class Initialized
INFO - 2017-12-28 19:54:51 --> Model Class Initialized
INFO - 2017-12-28 19:54:51 --> Model Class Initialized
INFO - 2017-12-28 19:54:51 --> Model Class Initialized
DEBUG - 2017-12-28 19:54:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:54:56 --> Config Class Initialized
INFO - 2017-12-28 19:54:56 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:54:56 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:54:56 --> Utf8 Class Initialized
INFO - 2017-12-28 19:54:56 --> URI Class Initialized
INFO - 2017-12-28 19:54:56 --> Router Class Initialized
INFO - 2017-12-28 19:54:56 --> Output Class Initialized
INFO - 2017-12-28 19:54:56 --> Security Class Initialized
DEBUG - 2017-12-28 19:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:54:56 --> Input Class Initialized
INFO - 2017-12-28 19:54:56 --> Language Class Initialized
INFO - 2017-12-28 19:54:56 --> Loader Class Initialized
INFO - 2017-12-28 19:54:56 --> Helper loaded: url_helper
INFO - 2017-12-28 19:54:56 --> Helper loaded: form_helper
INFO - 2017-12-28 19:54:56 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:54:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:54:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:54:56 --> Form Validation Class Initialized
INFO - 2017-12-28 19:54:56 --> Model Class Initialized
INFO - 2017-12-28 19:54:56 --> Controller Class Initialized
INFO - 2017-12-28 19:54:56 --> Model Class Initialized
INFO - 2017-12-28 19:54:56 --> Model Class Initialized
INFO - 2017-12-28 19:54:56 --> Model Class Initialized
INFO - 2017-12-28 19:54:56 --> Model Class Initialized
DEBUG - 2017-12-28 19:54:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:55:00 --> Config Class Initialized
INFO - 2017-12-28 19:55:00 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:55:00 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:55:00 --> Utf8 Class Initialized
INFO - 2017-12-28 19:55:00 --> URI Class Initialized
INFO - 2017-12-28 19:55:00 --> Router Class Initialized
INFO - 2017-12-28 19:55:00 --> Output Class Initialized
INFO - 2017-12-28 19:55:00 --> Security Class Initialized
DEBUG - 2017-12-28 19:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:55:00 --> Input Class Initialized
INFO - 2017-12-28 19:55:00 --> Language Class Initialized
INFO - 2017-12-28 19:55:00 --> Loader Class Initialized
INFO - 2017-12-28 19:55:00 --> Helper loaded: url_helper
INFO - 2017-12-28 19:55:00 --> Helper loaded: form_helper
INFO - 2017-12-28 19:55:00 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:55:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:55:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:55:00 --> Form Validation Class Initialized
INFO - 2017-12-28 19:55:00 --> Model Class Initialized
INFO - 2017-12-28 19:55:00 --> Controller Class Initialized
INFO - 2017-12-28 19:55:00 --> Model Class Initialized
INFO - 2017-12-28 19:55:00 --> Model Class Initialized
INFO - 2017-12-28 19:55:00 --> Model Class Initialized
INFO - 2017-12-28 19:55:00 --> Model Class Initialized
DEBUG - 2017-12-28 19:55:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:55:04 --> Config Class Initialized
INFO - 2017-12-28 19:55:04 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:55:04 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:55:04 --> Utf8 Class Initialized
INFO - 2017-12-28 19:55:04 --> URI Class Initialized
INFO - 2017-12-28 19:55:04 --> Router Class Initialized
INFO - 2017-12-28 19:55:04 --> Output Class Initialized
INFO - 2017-12-28 19:55:04 --> Security Class Initialized
DEBUG - 2017-12-28 19:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:55:04 --> Input Class Initialized
INFO - 2017-12-28 19:55:04 --> Language Class Initialized
INFO - 2017-12-28 19:55:04 --> Loader Class Initialized
INFO - 2017-12-28 19:55:04 --> Helper loaded: url_helper
INFO - 2017-12-28 19:55:04 --> Helper loaded: form_helper
INFO - 2017-12-28 19:55:04 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:55:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:55:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:55:04 --> Form Validation Class Initialized
INFO - 2017-12-28 19:55:04 --> Model Class Initialized
INFO - 2017-12-28 19:55:04 --> Controller Class Initialized
INFO - 2017-12-28 19:55:04 --> Model Class Initialized
INFO - 2017-12-28 19:55:04 --> Model Class Initialized
INFO - 2017-12-28 19:55:04 --> Model Class Initialized
INFO - 2017-12-28 19:55:04 --> Model Class Initialized
DEBUG - 2017-12-28 19:55:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:55:19 --> Config Class Initialized
INFO - 2017-12-28 19:55:19 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:55:19 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:55:19 --> Utf8 Class Initialized
INFO - 2017-12-28 19:55:19 --> URI Class Initialized
INFO - 2017-12-28 19:55:19 --> Router Class Initialized
INFO - 2017-12-28 19:55:19 --> Output Class Initialized
INFO - 2017-12-28 19:55:19 --> Security Class Initialized
DEBUG - 2017-12-28 19:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:55:19 --> Input Class Initialized
INFO - 2017-12-28 19:55:19 --> Language Class Initialized
INFO - 2017-12-28 19:55:19 --> Loader Class Initialized
INFO - 2017-12-28 19:55:19 --> Helper loaded: url_helper
INFO - 2017-12-28 19:55:19 --> Helper loaded: form_helper
INFO - 2017-12-28 19:55:19 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:55:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:55:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:55:19 --> Form Validation Class Initialized
INFO - 2017-12-28 19:55:19 --> Model Class Initialized
INFO - 2017-12-28 19:55:19 --> Controller Class Initialized
INFO - 2017-12-28 19:55:19 --> Model Class Initialized
INFO - 2017-12-28 19:55:19 --> Model Class Initialized
INFO - 2017-12-28 19:55:19 --> Model Class Initialized
INFO - 2017-12-28 19:55:19 --> Model Class Initialized
DEBUG - 2017-12-28 19:55:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:55:24 --> Config Class Initialized
INFO - 2017-12-28 19:55:24 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:55:24 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:55:24 --> Utf8 Class Initialized
INFO - 2017-12-28 19:55:24 --> URI Class Initialized
INFO - 2017-12-28 19:55:24 --> Router Class Initialized
INFO - 2017-12-28 19:55:24 --> Output Class Initialized
INFO - 2017-12-28 19:55:24 --> Security Class Initialized
DEBUG - 2017-12-28 19:55:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:55:24 --> Input Class Initialized
INFO - 2017-12-28 19:55:24 --> Language Class Initialized
INFO - 2017-12-28 19:55:24 --> Loader Class Initialized
INFO - 2017-12-28 19:55:24 --> Helper loaded: url_helper
INFO - 2017-12-28 19:55:24 --> Helper loaded: form_helper
INFO - 2017-12-28 19:55:24 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:55:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:55:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:55:24 --> Form Validation Class Initialized
INFO - 2017-12-28 19:55:24 --> Model Class Initialized
INFO - 2017-12-28 19:55:24 --> Controller Class Initialized
INFO - 2017-12-28 19:55:24 --> Model Class Initialized
INFO - 2017-12-28 19:55:24 --> Model Class Initialized
INFO - 2017-12-28 19:55:24 --> Model Class Initialized
INFO - 2017-12-28 19:55:24 --> Model Class Initialized
DEBUG - 2017-12-28 19:55:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:55:35 --> Config Class Initialized
INFO - 2017-12-28 19:55:35 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:55:35 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:55:35 --> Utf8 Class Initialized
INFO - 2017-12-28 19:55:35 --> URI Class Initialized
INFO - 2017-12-28 19:55:35 --> Router Class Initialized
INFO - 2017-12-28 19:55:35 --> Output Class Initialized
INFO - 2017-12-28 19:55:35 --> Security Class Initialized
DEBUG - 2017-12-28 19:55:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:55:35 --> Input Class Initialized
INFO - 2017-12-28 19:55:35 --> Language Class Initialized
INFO - 2017-12-28 19:55:35 --> Loader Class Initialized
INFO - 2017-12-28 19:55:35 --> Helper loaded: url_helper
INFO - 2017-12-28 19:55:35 --> Helper loaded: form_helper
INFO - 2017-12-28 19:55:35 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:55:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:55:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:55:35 --> Form Validation Class Initialized
INFO - 2017-12-28 19:55:35 --> Model Class Initialized
INFO - 2017-12-28 19:55:35 --> Controller Class Initialized
INFO - 2017-12-28 19:55:35 --> Model Class Initialized
INFO - 2017-12-28 19:55:35 --> Model Class Initialized
INFO - 2017-12-28 19:55:35 --> Model Class Initialized
INFO - 2017-12-28 19:55:35 --> Model Class Initialized
DEBUG - 2017-12-28 19:55:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:55:44 --> Config Class Initialized
INFO - 2017-12-28 19:55:44 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:55:44 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:55:44 --> Utf8 Class Initialized
INFO - 2017-12-28 19:55:44 --> URI Class Initialized
INFO - 2017-12-28 19:55:44 --> Router Class Initialized
INFO - 2017-12-28 19:55:44 --> Output Class Initialized
INFO - 2017-12-28 19:55:44 --> Security Class Initialized
DEBUG - 2017-12-28 19:55:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:55:44 --> Input Class Initialized
INFO - 2017-12-28 19:55:44 --> Language Class Initialized
INFO - 2017-12-28 19:55:44 --> Loader Class Initialized
INFO - 2017-12-28 19:55:44 --> Helper loaded: url_helper
INFO - 2017-12-28 19:55:44 --> Helper loaded: form_helper
INFO - 2017-12-28 19:55:44 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:55:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:55:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:55:44 --> Form Validation Class Initialized
INFO - 2017-12-28 19:55:44 --> Model Class Initialized
INFO - 2017-12-28 19:55:44 --> Controller Class Initialized
INFO - 2017-12-28 19:55:44 --> Model Class Initialized
INFO - 2017-12-28 19:55:44 --> Model Class Initialized
INFO - 2017-12-28 19:55:44 --> Model Class Initialized
INFO - 2017-12-28 19:55:44 --> Model Class Initialized
DEBUG - 2017-12-28 19:55:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:56:17 --> Config Class Initialized
INFO - 2017-12-28 19:56:17 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:56:17 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:56:17 --> Utf8 Class Initialized
INFO - 2017-12-28 19:56:17 --> URI Class Initialized
INFO - 2017-12-28 19:56:17 --> Router Class Initialized
INFO - 2017-12-28 19:56:17 --> Output Class Initialized
INFO - 2017-12-28 19:56:17 --> Security Class Initialized
DEBUG - 2017-12-28 19:56:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:56:17 --> Input Class Initialized
INFO - 2017-12-28 19:56:17 --> Language Class Initialized
INFO - 2017-12-28 19:56:17 --> Loader Class Initialized
INFO - 2017-12-28 19:56:17 --> Helper loaded: url_helper
INFO - 2017-12-28 19:56:17 --> Helper loaded: form_helper
INFO - 2017-12-28 19:56:17 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:56:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:56:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:56:17 --> Form Validation Class Initialized
INFO - 2017-12-28 19:56:17 --> Model Class Initialized
INFO - 2017-12-28 19:56:17 --> Controller Class Initialized
INFO - 2017-12-28 19:56:17 --> Model Class Initialized
INFO - 2017-12-28 19:56:17 --> Model Class Initialized
INFO - 2017-12-28 19:56:17 --> Model Class Initialized
INFO - 2017-12-28 19:56:17 --> Model Class Initialized
DEBUG - 2017-12-28 19:56:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:56:17 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 19:56:17 --> Final output sent to browser
DEBUG - 2017-12-28 19:56:17 --> Total execution time: 0.0861
INFO - 2017-12-28 19:56:19 --> Config Class Initialized
INFO - 2017-12-28 19:56:19 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:56:19 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:56:19 --> Utf8 Class Initialized
INFO - 2017-12-28 19:56:19 --> URI Class Initialized
INFO - 2017-12-28 19:56:19 --> Router Class Initialized
INFO - 2017-12-28 19:56:19 --> Output Class Initialized
INFO - 2017-12-28 19:56:19 --> Security Class Initialized
DEBUG - 2017-12-28 19:56:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:56:19 --> Input Class Initialized
INFO - 2017-12-28 19:56:19 --> Language Class Initialized
INFO - 2017-12-28 19:56:19 --> Loader Class Initialized
INFO - 2017-12-28 19:56:19 --> Helper loaded: url_helper
INFO - 2017-12-28 19:56:19 --> Helper loaded: form_helper
INFO - 2017-12-28 19:56:19 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:56:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:56:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:56:19 --> Form Validation Class Initialized
INFO - 2017-12-28 19:56:19 --> Model Class Initialized
INFO - 2017-12-28 19:56:19 --> Controller Class Initialized
INFO - 2017-12-28 19:56:19 --> Model Class Initialized
INFO - 2017-12-28 19:56:19 --> Model Class Initialized
INFO - 2017-12-28 19:56:19 --> Model Class Initialized
INFO - 2017-12-28 19:56:19 --> Model Class Initialized
DEBUG - 2017-12-28 19:56:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:56:19 --> Config Class Initialized
INFO - 2017-12-28 19:56:19 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:56:19 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:56:19 --> Utf8 Class Initialized
INFO - 2017-12-28 19:56:19 --> URI Class Initialized
INFO - 2017-12-28 19:56:19 --> Router Class Initialized
INFO - 2017-12-28 19:56:19 --> Output Class Initialized
INFO - 2017-12-28 19:56:19 --> Security Class Initialized
DEBUG - 2017-12-28 19:56:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:56:19 --> Input Class Initialized
INFO - 2017-12-28 19:56:19 --> Language Class Initialized
ERROR - 2017-12-28 19:56:19 --> 404 Page Not Found: Faviconico/index
INFO - 2017-12-28 19:57:20 --> Config Class Initialized
INFO - 2017-12-28 19:57:20 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:57:20 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:57:20 --> Utf8 Class Initialized
INFO - 2017-12-28 19:57:20 --> URI Class Initialized
INFO - 2017-12-28 19:57:20 --> Router Class Initialized
INFO - 2017-12-28 19:57:20 --> Output Class Initialized
INFO - 2017-12-28 19:57:20 --> Security Class Initialized
DEBUG - 2017-12-28 19:57:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:57:20 --> Input Class Initialized
INFO - 2017-12-28 19:57:20 --> Language Class Initialized
INFO - 2017-12-28 19:57:20 --> Loader Class Initialized
INFO - 2017-12-28 19:57:20 --> Helper loaded: url_helper
INFO - 2017-12-28 19:57:20 --> Helper loaded: form_helper
INFO - 2017-12-28 19:57:20 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:57:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:57:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:57:20 --> Form Validation Class Initialized
INFO - 2017-12-28 19:57:20 --> Model Class Initialized
INFO - 2017-12-28 19:57:20 --> Controller Class Initialized
INFO - 2017-12-28 19:57:20 --> Model Class Initialized
INFO - 2017-12-28 19:57:20 --> Model Class Initialized
INFO - 2017-12-28 19:57:20 --> Model Class Initialized
INFO - 2017-12-28 19:57:20 --> Model Class Initialized
DEBUG - 2017-12-28 19:57:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:57:20 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 19:57:20 --> Final output sent to browser
DEBUG - 2017-12-28 19:57:20 --> Total execution time: 0.0474
INFO - 2017-12-28 19:57:21 --> Config Class Initialized
INFO - 2017-12-28 19:57:21 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:57:21 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:57:21 --> Utf8 Class Initialized
INFO - 2017-12-28 19:57:21 --> URI Class Initialized
INFO - 2017-12-28 19:57:21 --> Router Class Initialized
INFO - 2017-12-28 19:57:21 --> Output Class Initialized
INFO - 2017-12-28 19:57:21 --> Security Class Initialized
DEBUG - 2017-12-28 19:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:57:21 --> Input Class Initialized
INFO - 2017-12-28 19:57:21 --> Language Class Initialized
INFO - 2017-12-28 19:57:21 --> Loader Class Initialized
INFO - 2017-12-28 19:57:21 --> Helper loaded: url_helper
INFO - 2017-12-28 19:57:21 --> Helper loaded: form_helper
INFO - 2017-12-28 19:57:21 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:57:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:57:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:57:21 --> Form Validation Class Initialized
INFO - 2017-12-28 19:57:21 --> Model Class Initialized
INFO - 2017-12-28 19:57:21 --> Controller Class Initialized
INFO - 2017-12-28 19:57:21 --> Model Class Initialized
INFO - 2017-12-28 19:57:21 --> Model Class Initialized
INFO - 2017-12-28 19:57:21 --> Model Class Initialized
INFO - 2017-12-28 19:57:21 --> Model Class Initialized
DEBUG - 2017-12-28 19:57:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:58:41 --> Config Class Initialized
INFO - 2017-12-28 19:58:41 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:58:41 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:58:41 --> Utf8 Class Initialized
INFO - 2017-12-28 19:58:41 --> URI Class Initialized
INFO - 2017-12-28 19:58:41 --> Router Class Initialized
INFO - 2017-12-28 19:58:41 --> Output Class Initialized
INFO - 2017-12-28 19:58:41 --> Security Class Initialized
DEBUG - 2017-12-28 19:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:58:41 --> Input Class Initialized
INFO - 2017-12-28 19:58:41 --> Language Class Initialized
INFO - 2017-12-28 19:58:41 --> Loader Class Initialized
INFO - 2017-12-28 19:58:41 --> Helper loaded: url_helper
INFO - 2017-12-28 19:58:41 --> Helper loaded: form_helper
INFO - 2017-12-28 19:58:41 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:58:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:58:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:58:41 --> Form Validation Class Initialized
INFO - 2017-12-28 19:58:41 --> Model Class Initialized
INFO - 2017-12-28 19:58:41 --> Controller Class Initialized
INFO - 2017-12-28 19:58:41 --> Model Class Initialized
INFO - 2017-12-28 19:58:41 --> Model Class Initialized
INFO - 2017-12-28 19:58:41 --> Model Class Initialized
INFO - 2017-12-28 19:58:41 --> Model Class Initialized
DEBUG - 2017-12-28 19:58:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:58:41 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 19:58:41 --> Final output sent to browser
DEBUG - 2017-12-28 19:58:41 --> Total execution time: 0.1073
INFO - 2017-12-28 19:58:43 --> Config Class Initialized
INFO - 2017-12-28 19:58:43 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:58:43 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:58:43 --> Utf8 Class Initialized
INFO - 2017-12-28 19:58:43 --> URI Class Initialized
INFO - 2017-12-28 19:58:43 --> Router Class Initialized
INFO - 2017-12-28 19:58:43 --> Output Class Initialized
INFO - 2017-12-28 19:58:43 --> Security Class Initialized
DEBUG - 2017-12-28 19:58:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:58:43 --> Input Class Initialized
INFO - 2017-12-28 19:58:43 --> Language Class Initialized
INFO - 2017-12-28 19:58:43 --> Loader Class Initialized
INFO - 2017-12-28 19:58:43 --> Helper loaded: url_helper
INFO - 2017-12-28 19:58:43 --> Helper loaded: form_helper
INFO - 2017-12-28 19:58:43 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:58:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:58:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:58:43 --> Form Validation Class Initialized
INFO - 2017-12-28 19:58:43 --> Model Class Initialized
INFO - 2017-12-28 19:58:43 --> Controller Class Initialized
INFO - 2017-12-28 19:58:43 --> Model Class Initialized
INFO - 2017-12-28 19:58:43 --> Model Class Initialized
INFO - 2017-12-28 19:58:43 --> Model Class Initialized
INFO - 2017-12-28 19:58:43 --> Model Class Initialized
DEBUG - 2017-12-28 19:58:43 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2017-12-28 19:58:43 --> Query error: Not unique table/alias: 'proyecto_gasto_detalle' - Invalid query: SELECT *
FROM `proyecto_gasto`
LEFT JOIN `proyecto_gasto_tipo` ON `proyecto_gasto_tipo`.`proyecto_gasto_tipo_id` = `proyecto_gasto`.`proyecto_gasto_tipo_id`
LEFT JOIN `proyecto_gasto_monto` ON `proyecto_gasto_monto`.`proyecto_gasto_id` = `proyecto_gasto`.`proyecto_gasto_id` AND `proyecto_gasto_monto`.`estado_registro` = 1
LEFT JOIN `proyecto_gasto_detalle` ON `proyecto_gasto_detalle`.`proyecto_gasto_id` = `proyecto_gasto`.`proyecto_gasto_id`
LEFT JOIN `proyecto_gasto_detalle` ON `proyecto_gasto_detalle`.`proyecto_gasto_estado_id` = `proyecto_gasto_estado`.`proyecto_gasto_estado_id`
LEFT JOIN `proveedor` ON `proveedor`.`proveedor_id` = `proyecto_gasto_detalle`.`proveedor_id`
WHERE `proyecto_gasto`.`proyecto_id` = '1'
ORDER BY `proyecto_gasto`.`fecha_registro` ASC
INFO - 2017-12-28 19:58:43 --> Language file loaded: language/english/db_lang.php
INFO - 2017-12-28 19:58:43 --> Config Class Initialized
INFO - 2017-12-28 19:58:43 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:58:43 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:58:43 --> Utf8 Class Initialized
INFO - 2017-12-28 19:58:43 --> URI Class Initialized
INFO - 2017-12-28 19:58:43 --> Router Class Initialized
INFO - 2017-12-28 19:58:43 --> Output Class Initialized
INFO - 2017-12-28 19:58:43 --> Security Class Initialized
DEBUG - 2017-12-28 19:58:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:58:43 --> Input Class Initialized
INFO - 2017-12-28 19:58:43 --> Language Class Initialized
ERROR - 2017-12-28 19:58:43 --> 404 Page Not Found: Faviconico/index
INFO - 2017-12-28 19:58:47 --> Config Class Initialized
INFO - 2017-12-28 19:58:47 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:58:47 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:58:47 --> Utf8 Class Initialized
INFO - 2017-12-28 19:58:47 --> URI Class Initialized
INFO - 2017-12-28 19:58:47 --> Router Class Initialized
INFO - 2017-12-28 19:58:47 --> Output Class Initialized
INFO - 2017-12-28 19:58:47 --> Security Class Initialized
DEBUG - 2017-12-28 19:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:58:47 --> Input Class Initialized
INFO - 2017-12-28 19:58:47 --> Language Class Initialized
ERROR - 2017-12-28 19:58:47 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-28 19:58:48 --> Config Class Initialized
INFO - 2017-12-28 19:58:48 --> Hooks Class Initialized
INFO - 2017-12-28 19:58:48 --> Config Class Initialized
INFO - 2017-12-28 19:58:48 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:58:48 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:58:48 --> Utf8 Class Initialized
DEBUG - 2017-12-28 19:58:48 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:58:48 --> Utf8 Class Initialized
INFO - 2017-12-28 19:58:48 --> URI Class Initialized
INFO - 2017-12-28 19:58:48 --> URI Class Initialized
INFO - 2017-12-28 19:58:48 --> Router Class Initialized
INFO - 2017-12-28 19:58:48 --> Router Class Initialized
INFO - 2017-12-28 19:58:48 --> Output Class Initialized
INFO - 2017-12-28 19:58:48 --> Output Class Initialized
INFO - 2017-12-28 19:58:48 --> Security Class Initialized
INFO - 2017-12-28 19:58:48 --> Security Class Initialized
DEBUG - 2017-12-28 19:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:58:48 --> Input Class Initialized
DEBUG - 2017-12-28 19:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:58:48 --> Input Class Initialized
INFO - 2017-12-28 19:58:48 --> Language Class Initialized
INFO - 2017-12-28 19:58:48 --> Language Class Initialized
ERROR - 2017-12-28 19:58:48 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-28 19:58:48 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-28 19:58:49 --> Config Class Initialized
INFO - 2017-12-28 19:58:49 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:58:49 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:58:49 --> Utf8 Class Initialized
INFO - 2017-12-28 19:58:49 --> URI Class Initialized
INFO - 2017-12-28 19:58:49 --> Router Class Initialized
INFO - 2017-12-28 19:58:49 --> Output Class Initialized
INFO - 2017-12-28 19:58:49 --> Security Class Initialized
DEBUG - 2017-12-28 19:58:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:58:49 --> Input Class Initialized
INFO - 2017-12-28 19:58:49 --> Language Class Initialized
INFO - 2017-12-28 19:58:49 --> Loader Class Initialized
INFO - 2017-12-28 19:58:49 --> Helper loaded: url_helper
INFO - 2017-12-28 19:58:49 --> Helper loaded: form_helper
INFO - 2017-12-28 19:58:49 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:58:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:58:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:58:49 --> Form Validation Class Initialized
INFO - 2017-12-28 19:58:49 --> Model Class Initialized
INFO - 2017-12-28 19:58:49 --> Controller Class Initialized
INFO - 2017-12-28 19:58:49 --> Model Class Initialized
INFO - 2017-12-28 19:58:49 --> Model Class Initialized
INFO - 2017-12-28 19:58:49 --> Model Class Initialized
INFO - 2017-12-28 19:58:49 --> Model Class Initialized
DEBUG - 2017-12-28 19:58:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:58:49 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 19:58:49 --> Final output sent to browser
DEBUG - 2017-12-28 19:58:49 --> Total execution time: 0.0483
INFO - 2017-12-28 19:58:50 --> Config Class Initialized
INFO - 2017-12-28 19:58:50 --> Hooks Class Initialized
INFO - 2017-12-28 19:58:50 --> Config Class Initialized
INFO - 2017-12-28 19:58:50 --> Config Class Initialized
INFO - 2017-12-28 19:58:50 --> Hooks Class Initialized
INFO - 2017-12-28 19:58:50 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:58:50 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:58:50 --> Utf8 Class Initialized
DEBUG - 2017-12-28 19:58:50 --> UTF-8 Support Enabled
DEBUG - 2017-12-28 19:58:50 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:58:50 --> Utf8 Class Initialized
INFO - 2017-12-28 19:58:50 --> Utf8 Class Initialized
INFO - 2017-12-28 19:58:50 --> URI Class Initialized
INFO - 2017-12-28 19:58:50 --> URI Class Initialized
INFO - 2017-12-28 19:58:50 --> URI Class Initialized
INFO - 2017-12-28 19:58:50 --> Router Class Initialized
INFO - 2017-12-28 19:58:50 --> Router Class Initialized
INFO - 2017-12-28 19:58:50 --> Router Class Initialized
INFO - 2017-12-28 19:58:50 --> Output Class Initialized
INFO - 2017-12-28 19:58:50 --> Output Class Initialized
INFO - 2017-12-28 19:58:50 --> Security Class Initialized
INFO - 2017-12-28 19:58:50 --> Output Class Initialized
INFO - 2017-12-28 19:58:50 --> Security Class Initialized
DEBUG - 2017-12-28 19:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:58:50 --> Input Class Initialized
DEBUG - 2017-12-28 19:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:58:50 --> Input Class Initialized
INFO - 2017-12-28 19:58:50 --> Security Class Initialized
INFO - 2017-12-28 19:58:50 --> Language Class Initialized
INFO - 2017-12-28 19:58:50 --> Language Class Initialized
DEBUG - 2017-12-28 19:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:58:50 --> Input Class Initialized
ERROR - 2017-12-28 19:58:50 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2017-12-28 19:58:50 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-28 19:58:50 --> Language Class Initialized
ERROR - 2017-12-28 19:58:50 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-28 19:58:50 --> Config Class Initialized
INFO - 2017-12-28 19:58:50 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:58:50 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:58:50 --> Utf8 Class Initialized
INFO - 2017-12-28 19:58:50 --> URI Class Initialized
INFO - 2017-12-28 19:58:50 --> Router Class Initialized
INFO - 2017-12-28 19:58:50 --> Output Class Initialized
INFO - 2017-12-28 19:58:50 --> Security Class Initialized
DEBUG - 2017-12-28 19:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:58:50 --> Input Class Initialized
INFO - 2017-12-28 19:58:50 --> Language Class Initialized
INFO - 2017-12-28 19:58:50 --> Loader Class Initialized
INFO - 2017-12-28 19:58:50 --> Helper loaded: url_helper
INFO - 2017-12-28 19:58:50 --> Helper loaded: form_helper
INFO - 2017-12-28 19:58:50 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:58:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:58:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:58:50 --> Form Validation Class Initialized
INFO - 2017-12-28 19:58:50 --> Model Class Initialized
INFO - 2017-12-28 19:58:50 --> Controller Class Initialized
INFO - 2017-12-28 19:58:50 --> Model Class Initialized
INFO - 2017-12-28 19:58:50 --> Model Class Initialized
INFO - 2017-12-28 19:58:50 --> Model Class Initialized
INFO - 2017-12-28 19:58:50 --> Model Class Initialized
DEBUG - 2017-12-28 19:58:50 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2017-12-28 19:58:50 --> Query error: Not unique table/alias: 'proyecto_gasto_detalle' - Invalid query: SELECT *
FROM `proyecto_gasto`
LEFT JOIN `proyecto_gasto_tipo` ON `proyecto_gasto_tipo`.`proyecto_gasto_tipo_id` = `proyecto_gasto`.`proyecto_gasto_tipo_id`
LEFT JOIN `proyecto_gasto_monto` ON `proyecto_gasto_monto`.`proyecto_gasto_id` = `proyecto_gasto`.`proyecto_gasto_id` AND `proyecto_gasto_monto`.`estado_registro` = 1
LEFT JOIN `proyecto_gasto_detalle` ON `proyecto_gasto_detalle`.`proyecto_gasto_id` = `proyecto_gasto`.`proyecto_gasto_id`
LEFT JOIN `proyecto_gasto_detalle` ON `proyecto_gasto_detalle`.`proyecto_gasto_estado_id` = `proyecto_gasto_estado`.`proyecto_gasto_estado_id`
LEFT JOIN `proveedor` ON `proveedor`.`proveedor_id` = `proyecto_gasto_detalle`.`proveedor_id`
WHERE `proyecto_gasto`.`proyecto_id` = '1'
ORDER BY `proyecto_gasto`.`fecha_registro` ASC
INFO - 2017-12-28 19:58:50 --> Language file loaded: language/english/db_lang.php
INFO - 2017-12-28 19:59:25 --> Config Class Initialized
INFO - 2017-12-28 19:59:25 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:59:25 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:59:25 --> Utf8 Class Initialized
INFO - 2017-12-28 19:59:25 --> URI Class Initialized
INFO - 2017-12-28 19:59:25 --> Router Class Initialized
INFO - 2017-12-28 19:59:25 --> Output Class Initialized
INFO - 2017-12-28 19:59:25 --> Security Class Initialized
DEBUG - 2017-12-28 19:59:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:59:25 --> Input Class Initialized
INFO - 2017-12-28 19:59:25 --> Language Class Initialized
INFO - 2017-12-28 19:59:25 --> Loader Class Initialized
INFO - 2017-12-28 19:59:25 --> Helper loaded: url_helper
INFO - 2017-12-28 19:59:25 --> Helper loaded: form_helper
INFO - 2017-12-28 19:59:25 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:59:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:59:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:59:25 --> Form Validation Class Initialized
INFO - 2017-12-28 19:59:25 --> Model Class Initialized
INFO - 2017-12-28 19:59:25 --> Controller Class Initialized
INFO - 2017-12-28 19:59:25 --> Model Class Initialized
INFO - 2017-12-28 19:59:25 --> Model Class Initialized
INFO - 2017-12-28 19:59:25 --> Model Class Initialized
INFO - 2017-12-28 19:59:25 --> Model Class Initialized
DEBUG - 2017-12-28 19:59:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 19:59:25 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 19:59:25 --> Final output sent to browser
DEBUG - 2017-12-28 19:59:25 --> Total execution time: 0.0825
INFO - 2017-12-28 19:59:25 --> Config Class Initialized
INFO - 2017-12-28 19:59:25 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:59:25 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:59:25 --> Utf8 Class Initialized
INFO - 2017-12-28 19:59:25 --> URI Class Initialized
INFO - 2017-12-28 19:59:25 --> Router Class Initialized
INFO - 2017-12-28 19:59:25 --> Output Class Initialized
INFO - 2017-12-28 19:59:25 --> Security Class Initialized
DEBUG - 2017-12-28 19:59:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:59:25 --> Input Class Initialized
INFO - 2017-12-28 19:59:25 --> Language Class Initialized
ERROR - 2017-12-28 19:59:25 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-28 19:59:25 --> Config Class Initialized
INFO - 2017-12-28 19:59:25 --> Hooks Class Initialized
INFO - 2017-12-28 19:59:25 --> Config Class Initialized
INFO - 2017-12-28 19:59:25 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:59:25 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:59:25 --> Utf8 Class Initialized
DEBUG - 2017-12-28 19:59:25 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:59:25 --> Utf8 Class Initialized
INFO - 2017-12-28 19:59:25 --> URI Class Initialized
INFO - 2017-12-28 19:59:25 --> URI Class Initialized
INFO - 2017-12-28 19:59:25 --> Router Class Initialized
INFO - 2017-12-28 19:59:25 --> Router Class Initialized
INFO - 2017-12-28 19:59:25 --> Output Class Initialized
INFO - 2017-12-28 19:59:25 --> Output Class Initialized
INFO - 2017-12-28 19:59:25 --> Security Class Initialized
INFO - 2017-12-28 19:59:25 --> Security Class Initialized
DEBUG - 2017-12-28 19:59:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-28 19:59:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:59:25 --> Input Class Initialized
INFO - 2017-12-28 19:59:25 --> Input Class Initialized
INFO - 2017-12-28 19:59:25 --> Language Class Initialized
INFO - 2017-12-28 19:59:25 --> Language Class Initialized
ERROR - 2017-12-28 19:59:25 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-28 19:59:25 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-28 19:59:25 --> Config Class Initialized
INFO - 2017-12-28 19:59:25 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:59:25 --> UTF-8 Support Enabled
INFO - 2017-12-28 19:59:25 --> Utf8 Class Initialized
INFO - 2017-12-28 19:59:25 --> URI Class Initialized
INFO - 2017-12-28 19:59:25 --> Router Class Initialized
INFO - 2017-12-28 19:59:25 --> Output Class Initialized
INFO - 2017-12-28 19:59:25 --> Security Class Initialized
DEBUG - 2017-12-28 19:59:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 19:59:25 --> Input Class Initialized
INFO - 2017-12-28 19:59:25 --> Language Class Initialized
INFO - 2017-12-28 19:59:25 --> Loader Class Initialized
INFO - 2017-12-28 19:59:25 --> Helper loaded: url_helper
INFO - 2017-12-28 19:59:25 --> Helper loaded: form_helper
INFO - 2017-12-28 19:59:25 --> Database Driver Class Initialized
DEBUG - 2017-12-28 19:59:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 19:59:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 19:59:25 --> Form Validation Class Initialized
INFO - 2017-12-28 19:59:25 --> Model Class Initialized
INFO - 2017-12-28 19:59:25 --> Controller Class Initialized
INFO - 2017-12-28 19:59:25 --> Model Class Initialized
INFO - 2017-12-28 19:59:25 --> Model Class Initialized
INFO - 2017-12-28 19:59:25 --> Model Class Initialized
INFO - 2017-12-28 19:59:25 --> Model Class Initialized
DEBUG - 2017-12-28 19:59:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 20:03:31 --> Config Class Initialized
INFO - 2017-12-28 20:03:31 --> Hooks Class Initialized
DEBUG - 2017-12-28 20:03:31 --> UTF-8 Support Enabled
INFO - 2017-12-28 20:03:31 --> Utf8 Class Initialized
INFO - 2017-12-28 20:03:31 --> URI Class Initialized
INFO - 2017-12-28 20:03:31 --> Router Class Initialized
INFO - 2017-12-28 20:03:31 --> Output Class Initialized
INFO - 2017-12-28 20:03:31 --> Security Class Initialized
DEBUG - 2017-12-28 20:03:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 20:03:31 --> Input Class Initialized
INFO - 2017-12-28 20:03:31 --> Language Class Initialized
INFO - 2017-12-28 20:03:31 --> Loader Class Initialized
INFO - 2017-12-28 20:03:31 --> Helper loaded: url_helper
INFO - 2017-12-28 20:03:31 --> Helper loaded: form_helper
INFO - 2017-12-28 20:03:31 --> Database Driver Class Initialized
DEBUG - 2017-12-28 20:03:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 20:03:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 20:03:31 --> Form Validation Class Initialized
INFO - 2017-12-28 20:03:31 --> Model Class Initialized
INFO - 2017-12-28 20:03:31 --> Controller Class Initialized
INFO - 2017-12-28 20:03:31 --> Model Class Initialized
INFO - 2017-12-28 20:03:31 --> Model Class Initialized
INFO - 2017-12-28 20:03:31 --> Model Class Initialized
INFO - 2017-12-28 20:03:31 --> Model Class Initialized
DEBUG - 2017-12-28 20:03:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 20:03:31 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 20:03:31 --> Final output sent to browser
DEBUG - 2017-12-28 20:03:31 --> Total execution time: 0.0933
INFO - 2017-12-28 20:03:31 --> Config Class Initialized
INFO - 2017-12-28 20:03:31 --> Hooks Class Initialized
DEBUG - 2017-12-28 20:03:31 --> UTF-8 Support Enabled
INFO - 2017-12-28 20:03:31 --> Utf8 Class Initialized
INFO - 2017-12-28 20:03:31 --> URI Class Initialized
INFO - 2017-12-28 20:03:31 --> Router Class Initialized
INFO - 2017-12-28 20:03:31 --> Output Class Initialized
INFO - 2017-12-28 20:03:31 --> Security Class Initialized
DEBUG - 2017-12-28 20:03:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 20:03:31 --> Input Class Initialized
INFO - 2017-12-28 20:03:31 --> Language Class Initialized
INFO - 2017-12-28 20:03:31 --> Loader Class Initialized
INFO - 2017-12-28 20:03:31 --> Helper loaded: url_helper
INFO - 2017-12-28 20:03:31 --> Helper loaded: form_helper
INFO - 2017-12-28 20:03:31 --> Database Driver Class Initialized
DEBUG - 2017-12-28 20:03:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 20:03:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 20:03:31 --> Form Validation Class Initialized
INFO - 2017-12-28 20:03:31 --> Model Class Initialized
INFO - 2017-12-28 20:03:31 --> Controller Class Initialized
INFO - 2017-12-28 20:03:31 --> Model Class Initialized
INFO - 2017-12-28 20:03:31 --> Model Class Initialized
INFO - 2017-12-28 20:03:31 --> Model Class Initialized
INFO - 2017-12-28 20:03:31 --> Model Class Initialized
DEBUG - 2017-12-28 20:03:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 20:03:33 --> Config Class Initialized
INFO - 2017-12-28 20:03:33 --> Hooks Class Initialized
DEBUG - 2017-12-28 20:03:33 --> UTF-8 Support Enabled
INFO - 2017-12-28 20:03:33 --> Utf8 Class Initialized
INFO - 2017-12-28 20:03:33 --> URI Class Initialized
INFO - 2017-12-28 20:03:33 --> Router Class Initialized
INFO - 2017-12-28 20:03:33 --> Output Class Initialized
INFO - 2017-12-28 20:03:33 --> Security Class Initialized
DEBUG - 2017-12-28 20:03:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 20:03:33 --> Input Class Initialized
INFO - 2017-12-28 20:03:33 --> Language Class Initialized
ERROR - 2017-12-28 20:03:33 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-28 20:03:33 --> Config Class Initialized
INFO - 2017-12-28 20:03:33 --> Hooks Class Initialized
INFO - 2017-12-28 20:03:33 --> Config Class Initialized
INFO - 2017-12-28 20:03:33 --> Hooks Class Initialized
DEBUG - 2017-12-28 20:03:33 --> UTF-8 Support Enabled
INFO - 2017-12-28 20:03:33 --> Utf8 Class Initialized
DEBUG - 2017-12-28 20:03:33 --> UTF-8 Support Enabled
INFO - 2017-12-28 20:03:33 --> Utf8 Class Initialized
INFO - 2017-12-28 20:03:33 --> URI Class Initialized
INFO - 2017-12-28 20:03:33 --> URI Class Initialized
INFO - 2017-12-28 20:03:33 --> Router Class Initialized
INFO - 2017-12-28 20:03:33 --> Router Class Initialized
INFO - 2017-12-28 20:03:33 --> Output Class Initialized
INFO - 2017-12-28 20:03:33 --> Output Class Initialized
INFO - 2017-12-28 20:03:33 --> Security Class Initialized
INFO - 2017-12-28 20:03:33 --> Security Class Initialized
DEBUG - 2017-12-28 20:03:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 20:03:34 --> Input Class Initialized
DEBUG - 2017-12-28 20:03:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 20:03:34 --> Input Class Initialized
INFO - 2017-12-28 20:03:34 --> Language Class Initialized
INFO - 2017-12-28 20:03:34 --> Language Class Initialized
ERROR - 2017-12-28 20:03:34 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-28 20:03:34 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-28 20:27:00 --> Config Class Initialized
INFO - 2017-12-28 20:27:00 --> Hooks Class Initialized
DEBUG - 2017-12-28 20:27:00 --> UTF-8 Support Enabled
INFO - 2017-12-28 20:27:00 --> Utf8 Class Initialized
INFO - 2017-12-28 20:27:00 --> URI Class Initialized
INFO - 2017-12-28 20:27:00 --> Router Class Initialized
INFO - 2017-12-28 20:27:00 --> Output Class Initialized
INFO - 2017-12-28 20:27:00 --> Security Class Initialized
DEBUG - 2017-12-28 20:27:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 20:27:00 --> Input Class Initialized
INFO - 2017-12-28 20:27:00 --> Language Class Initialized
INFO - 2017-12-28 20:27:00 --> Loader Class Initialized
INFO - 2017-12-28 20:27:00 --> Helper loaded: url_helper
INFO - 2017-12-28 20:27:00 --> Helper loaded: form_helper
INFO - 2017-12-28 20:27:00 --> Database Driver Class Initialized
DEBUG - 2017-12-28 20:27:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 20:27:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 20:27:00 --> Form Validation Class Initialized
INFO - 2017-12-28 20:27:00 --> Model Class Initialized
INFO - 2017-12-28 20:27:00 --> Controller Class Initialized
INFO - 2017-12-28 20:27:00 --> Model Class Initialized
INFO - 2017-12-28 20:27:00 --> Model Class Initialized
INFO - 2017-12-28 20:27:00 --> Model Class Initialized
INFO - 2017-12-28 20:27:00 --> Model Class Initialized
DEBUG - 2017-12-28 20:27:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 20:27:00 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 20:27:00 --> Final output sent to browser
DEBUG - 2017-12-28 20:27:00 --> Total execution time: 0.0875
INFO - 2017-12-28 20:27:00 --> Config Class Initialized
INFO - 2017-12-28 20:27:00 --> Hooks Class Initialized
DEBUG - 2017-12-28 20:27:01 --> UTF-8 Support Enabled
INFO - 2017-12-28 20:27:01 --> Utf8 Class Initialized
INFO - 2017-12-28 20:27:01 --> URI Class Initialized
INFO - 2017-12-28 20:27:01 --> Router Class Initialized
INFO - 2017-12-28 20:27:01 --> Output Class Initialized
INFO - 2017-12-28 20:27:01 --> Security Class Initialized
DEBUG - 2017-12-28 20:27:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 20:27:01 --> Input Class Initialized
INFO - 2017-12-28 20:27:01 --> Language Class Initialized
ERROR - 2017-12-28 20:27:01 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-28 20:27:01 --> Config Class Initialized
INFO - 2017-12-28 20:27:01 --> Hooks Class Initialized
INFO - 2017-12-28 20:27:01 --> Config Class Initialized
INFO - 2017-12-28 20:27:01 --> Hooks Class Initialized
DEBUG - 2017-12-28 20:27:01 --> UTF-8 Support Enabled
INFO - 2017-12-28 20:27:01 --> Utf8 Class Initialized
DEBUG - 2017-12-28 20:27:01 --> UTF-8 Support Enabled
INFO - 2017-12-28 20:27:01 --> Utf8 Class Initialized
INFO - 2017-12-28 20:27:01 --> URI Class Initialized
INFO - 2017-12-28 20:27:01 --> URI Class Initialized
INFO - 2017-12-28 20:27:01 --> Router Class Initialized
INFO - 2017-12-28 20:27:01 --> Router Class Initialized
INFO - 2017-12-28 20:27:01 --> Output Class Initialized
INFO - 2017-12-28 20:27:01 --> Output Class Initialized
INFO - 2017-12-28 20:27:01 --> Security Class Initialized
INFO - 2017-12-28 20:27:01 --> Security Class Initialized
DEBUG - 2017-12-28 20:27:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-28 20:27:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 20:27:01 --> Input Class Initialized
INFO - 2017-12-28 20:27:01 --> Input Class Initialized
INFO - 2017-12-28 20:27:01 --> Language Class Initialized
INFO - 2017-12-28 20:27:01 --> Language Class Initialized
ERROR - 2017-12-28 20:27:01 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-28 20:27:01 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-28 20:27:01 --> Config Class Initialized
INFO - 2017-12-28 20:27:01 --> Hooks Class Initialized
DEBUG - 2017-12-28 20:27:01 --> UTF-8 Support Enabled
INFO - 2017-12-28 20:27:01 --> Utf8 Class Initialized
INFO - 2017-12-28 20:27:01 --> URI Class Initialized
INFO - 2017-12-28 20:27:01 --> Router Class Initialized
INFO - 2017-12-28 20:27:01 --> Output Class Initialized
INFO - 2017-12-28 20:27:01 --> Security Class Initialized
DEBUG - 2017-12-28 20:27:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 20:27:01 --> Input Class Initialized
INFO - 2017-12-28 20:27:01 --> Language Class Initialized
INFO - 2017-12-28 20:27:01 --> Loader Class Initialized
INFO - 2017-12-28 20:27:01 --> Helper loaded: url_helper
INFO - 2017-12-28 20:27:01 --> Helper loaded: form_helper
INFO - 2017-12-28 20:27:01 --> Database Driver Class Initialized
DEBUG - 2017-12-28 20:27:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 20:27:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 20:27:01 --> Form Validation Class Initialized
INFO - 2017-12-28 20:27:01 --> Model Class Initialized
INFO - 2017-12-28 20:27:01 --> Controller Class Initialized
INFO - 2017-12-28 20:27:01 --> Model Class Initialized
INFO - 2017-12-28 20:27:01 --> Model Class Initialized
INFO - 2017-12-28 20:27:01 --> Model Class Initialized
INFO - 2017-12-28 20:27:01 --> Model Class Initialized
DEBUG - 2017-12-28 20:27:01 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2017-12-28 20:27:01 --> Severity: Notice --> Undefined property: Proyecto::$t_proyecto_detalle D:\xampp\htdocs\instateccr\instatec_sys\core\Model.php 77
ERROR - 2017-12-28 20:27:01 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ' `proyecto_gasto_detalle`.`numero_factura`, `proyecto_gasto_estado`.`proyecto_ga' at line 1 - Invalid query: SELECT `proyecto_gasto`.*, `proyecto_gasto_monto`.`proyecto_gasto_monto`, `proyecto_gasto_monto`.`moneda_id`, .`proveedor_id`, `proyecto_gasto_detalle`.`numero_factura`, `proyecto_gasto_estado`.`proyecto_gasto_estado`, `proveedor`.`nombre_proveedor`
FROM `proyecto_gasto`
LEFT JOIN `proyecto_gasto_tipo` ON `proyecto_gasto_tipo`.`proyecto_gasto_tipo_id` = `proyecto_gasto`.`proyecto_gasto_tipo_id`
LEFT JOIN `proyecto_gasto_monto` ON `proyecto_gasto_monto`.`proyecto_gasto_id` = `proyecto_gasto`.`proyecto_gasto_id` AND `proyecto_gasto_monto`.`estado_registro` = 1
LEFT JOIN `proyecto_gasto_detalle` ON `proyecto_gasto_detalle`.`proyecto_gasto_id` = `proyecto_gasto`.`proyecto_gasto_id`
LEFT JOIN `proyecto_gasto_estado` ON `proyecto_gasto_estado`.`proyecto_gasto_estado_id` = `proyecto_gasto_detalle`.`proyecto_gasto_estado_id`
LEFT JOIN `proveedor` ON `proveedor`.`proveedor_id` = `proyecto_gasto_detalle`.`proveedor_id`
WHERE `proyecto_gasto`.`proyecto_id` = '1'
ORDER BY `proyecto_gasto`.`fecha_registro` ASC
INFO - 2017-12-28 20:27:01 --> Language file loaded: language/english/db_lang.php
INFO - 2017-12-28 20:27:26 --> Config Class Initialized
INFO - 2017-12-28 20:27:26 --> Hooks Class Initialized
DEBUG - 2017-12-28 20:27:26 --> UTF-8 Support Enabled
INFO - 2017-12-28 20:27:26 --> Utf8 Class Initialized
INFO - 2017-12-28 20:27:26 --> URI Class Initialized
INFO - 2017-12-28 20:27:26 --> Router Class Initialized
INFO - 2017-12-28 20:27:26 --> Output Class Initialized
INFO - 2017-12-28 20:27:26 --> Security Class Initialized
DEBUG - 2017-12-28 20:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 20:27:26 --> Input Class Initialized
INFO - 2017-12-28 20:27:26 --> Language Class Initialized
INFO - 2017-12-28 20:27:26 --> Loader Class Initialized
INFO - 2017-12-28 20:27:26 --> Helper loaded: url_helper
INFO - 2017-12-28 20:27:26 --> Helper loaded: form_helper
INFO - 2017-12-28 20:27:26 --> Database Driver Class Initialized
DEBUG - 2017-12-28 20:27:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 20:27:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 20:27:26 --> Form Validation Class Initialized
INFO - 2017-12-28 20:27:26 --> Model Class Initialized
INFO - 2017-12-28 20:27:26 --> Controller Class Initialized
INFO - 2017-12-28 20:27:26 --> Model Class Initialized
INFO - 2017-12-28 20:27:26 --> Model Class Initialized
INFO - 2017-12-28 20:27:26 --> Model Class Initialized
INFO - 2017-12-28 20:27:26 --> Model Class Initialized
DEBUG - 2017-12-28 20:27:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 20:27:26 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 20:27:26 --> Final output sent to browser
DEBUG - 2017-12-28 20:27:26 --> Total execution time: 0.0771
INFO - 2017-12-28 20:27:26 --> Config Class Initialized
INFO - 2017-12-28 20:27:26 --> Hooks Class Initialized
DEBUG - 2017-12-28 20:27:26 --> UTF-8 Support Enabled
INFO - 2017-12-28 20:27:26 --> Utf8 Class Initialized
INFO - 2017-12-28 20:27:26 --> URI Class Initialized
INFO - 2017-12-28 20:27:26 --> Router Class Initialized
INFO - 2017-12-28 20:27:26 --> Output Class Initialized
INFO - 2017-12-28 20:27:26 --> Security Class Initialized
DEBUG - 2017-12-28 20:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 20:27:26 --> Input Class Initialized
INFO - 2017-12-28 20:27:26 --> Language Class Initialized
ERROR - 2017-12-28 20:27:26 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-28 20:27:26 --> Config Class Initialized
INFO - 2017-12-28 20:27:26 --> Hooks Class Initialized
INFO - 2017-12-28 20:27:26 --> Config Class Initialized
INFO - 2017-12-28 20:27:26 --> Hooks Class Initialized
DEBUG - 2017-12-28 20:27:26 --> UTF-8 Support Enabled
INFO - 2017-12-28 20:27:26 --> Utf8 Class Initialized
DEBUG - 2017-12-28 20:27:26 --> UTF-8 Support Enabled
INFO - 2017-12-28 20:27:26 --> Utf8 Class Initialized
INFO - 2017-12-28 20:27:26 --> URI Class Initialized
INFO - 2017-12-28 20:27:26 --> URI Class Initialized
INFO - 2017-12-28 20:27:26 --> Router Class Initialized
INFO - 2017-12-28 20:27:26 --> Router Class Initialized
INFO - 2017-12-28 20:27:26 --> Output Class Initialized
INFO - 2017-12-28 20:27:26 --> Output Class Initialized
INFO - 2017-12-28 20:27:26 --> Security Class Initialized
INFO - 2017-12-28 20:27:26 --> Security Class Initialized
DEBUG - 2017-12-28 20:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 20:27:26 --> Input Class Initialized
INFO - 2017-12-28 20:27:26 --> Language Class Initialized
DEBUG - 2017-12-28 20:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 20:27:26 --> Input Class Initialized
INFO - 2017-12-28 20:27:26 --> Language Class Initialized
ERROR - 2017-12-28 20:27:26 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-28 20:27:26 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-28 20:27:26 --> Config Class Initialized
INFO - 2017-12-28 20:27:26 --> Hooks Class Initialized
DEBUG - 2017-12-28 20:27:26 --> UTF-8 Support Enabled
INFO - 2017-12-28 20:27:26 --> Utf8 Class Initialized
INFO - 2017-12-28 20:27:26 --> URI Class Initialized
INFO - 2017-12-28 20:27:26 --> Router Class Initialized
INFO - 2017-12-28 20:27:26 --> Output Class Initialized
INFO - 2017-12-28 20:27:26 --> Security Class Initialized
DEBUG - 2017-12-28 20:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 20:27:26 --> Input Class Initialized
INFO - 2017-12-28 20:27:26 --> Language Class Initialized
INFO - 2017-12-28 20:27:26 --> Loader Class Initialized
INFO - 2017-12-28 20:27:26 --> Helper loaded: url_helper
INFO - 2017-12-28 20:27:26 --> Helper loaded: form_helper
INFO - 2017-12-28 20:27:26 --> Database Driver Class Initialized
DEBUG - 2017-12-28 20:27:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 20:27:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 20:27:26 --> Form Validation Class Initialized
INFO - 2017-12-28 20:27:26 --> Model Class Initialized
INFO - 2017-12-28 20:27:26 --> Controller Class Initialized
INFO - 2017-12-28 20:27:26 --> Model Class Initialized
INFO - 2017-12-28 20:27:26 --> Model Class Initialized
INFO - 2017-12-28 20:27:26 --> Model Class Initialized
INFO - 2017-12-28 20:27:26 --> Model Class Initialized
DEBUG - 2017-12-28 20:27:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 20:28:13 --> Config Class Initialized
INFO - 2017-12-28 20:28:13 --> Hooks Class Initialized
DEBUG - 2017-12-28 20:28:13 --> UTF-8 Support Enabled
INFO - 2017-12-28 20:28:13 --> Utf8 Class Initialized
INFO - 2017-12-28 20:28:13 --> URI Class Initialized
INFO - 2017-12-28 20:28:13 --> Router Class Initialized
INFO - 2017-12-28 20:28:13 --> Output Class Initialized
INFO - 2017-12-28 20:28:13 --> Security Class Initialized
DEBUG - 2017-12-28 20:28:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 20:28:13 --> Input Class Initialized
INFO - 2017-12-28 20:28:13 --> Language Class Initialized
INFO - 2017-12-28 20:28:13 --> Loader Class Initialized
INFO - 2017-12-28 20:28:13 --> Helper loaded: url_helper
INFO - 2017-12-28 20:28:13 --> Helper loaded: form_helper
INFO - 2017-12-28 20:28:13 --> Database Driver Class Initialized
DEBUG - 2017-12-28 20:28:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 20:28:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 20:28:13 --> Form Validation Class Initialized
INFO - 2017-12-28 20:28:13 --> Model Class Initialized
INFO - 2017-12-28 20:28:13 --> Controller Class Initialized
INFO - 2017-12-28 20:28:13 --> Model Class Initialized
INFO - 2017-12-28 20:28:13 --> Model Class Initialized
INFO - 2017-12-28 20:28:13 --> Model Class Initialized
INFO - 2017-12-28 20:28:13 --> Model Class Initialized
DEBUG - 2017-12-28 20:28:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 20:28:13 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 20:28:13 --> Final output sent to browser
DEBUG - 2017-12-28 20:28:13 --> Total execution time: 0.1039
INFO - 2017-12-28 20:28:14 --> Config Class Initialized
INFO - 2017-12-28 20:28:14 --> Hooks Class Initialized
DEBUG - 2017-12-28 20:28:14 --> UTF-8 Support Enabled
INFO - 2017-12-28 20:28:14 --> Utf8 Class Initialized
INFO - 2017-12-28 20:28:14 --> URI Class Initialized
INFO - 2017-12-28 20:28:14 --> Router Class Initialized
INFO - 2017-12-28 20:28:14 --> Output Class Initialized
INFO - 2017-12-28 20:28:14 --> Security Class Initialized
DEBUG - 2017-12-28 20:28:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 20:28:14 --> Input Class Initialized
INFO - 2017-12-28 20:28:14 --> Language Class Initialized
ERROR - 2017-12-28 20:28:14 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-28 20:28:14 --> Config Class Initialized
INFO - 2017-12-28 20:28:14 --> Config Class Initialized
INFO - 2017-12-28 20:28:14 --> Hooks Class Initialized
INFO - 2017-12-28 20:28:14 --> Hooks Class Initialized
DEBUG - 2017-12-28 20:28:14 --> UTF-8 Support Enabled
DEBUG - 2017-12-28 20:28:14 --> UTF-8 Support Enabled
INFO - 2017-12-28 20:28:14 --> Utf8 Class Initialized
INFO - 2017-12-28 20:28:14 --> Utf8 Class Initialized
INFO - 2017-12-28 20:28:14 --> URI Class Initialized
INFO - 2017-12-28 20:28:14 --> URI Class Initialized
INFO - 2017-12-28 20:28:14 --> Router Class Initialized
INFO - 2017-12-28 20:28:14 --> Router Class Initialized
INFO - 2017-12-28 20:28:14 --> Output Class Initialized
INFO - 2017-12-28 20:28:14 --> Output Class Initialized
INFO - 2017-12-28 20:28:14 --> Security Class Initialized
INFO - 2017-12-28 20:28:14 --> Security Class Initialized
DEBUG - 2017-12-28 20:28:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 20:28:14 --> Input Class Initialized
DEBUG - 2017-12-28 20:28:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 20:28:14 --> Language Class Initialized
INFO - 2017-12-28 20:28:14 --> Input Class Initialized
INFO - 2017-12-28 20:28:14 --> Language Class Initialized
ERROR - 2017-12-28 20:28:14 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-28 20:28:14 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-28 20:28:14 --> Config Class Initialized
INFO - 2017-12-28 20:28:14 --> Hooks Class Initialized
DEBUG - 2017-12-28 20:28:14 --> UTF-8 Support Enabled
INFO - 2017-12-28 20:28:14 --> Utf8 Class Initialized
INFO - 2017-12-28 20:28:14 --> URI Class Initialized
INFO - 2017-12-28 20:28:14 --> Router Class Initialized
INFO - 2017-12-28 20:28:14 --> Output Class Initialized
INFO - 2017-12-28 20:28:14 --> Security Class Initialized
DEBUG - 2017-12-28 20:28:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 20:28:14 --> Input Class Initialized
INFO - 2017-12-28 20:28:14 --> Language Class Initialized
INFO - 2017-12-28 20:28:14 --> Loader Class Initialized
INFO - 2017-12-28 20:28:14 --> Helper loaded: url_helper
INFO - 2017-12-28 20:28:14 --> Helper loaded: form_helper
INFO - 2017-12-28 20:28:14 --> Database Driver Class Initialized
DEBUG - 2017-12-28 20:28:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 20:28:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 20:28:14 --> Form Validation Class Initialized
INFO - 2017-12-28 20:28:14 --> Model Class Initialized
INFO - 2017-12-28 20:28:14 --> Controller Class Initialized
INFO - 2017-12-28 20:28:14 --> Model Class Initialized
INFO - 2017-12-28 20:28:14 --> Model Class Initialized
INFO - 2017-12-28 20:28:14 --> Model Class Initialized
INFO - 2017-12-28 20:28:14 --> Model Class Initialized
DEBUG - 2017-12-28 20:28:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 20:28:41 --> Config Class Initialized
INFO - 2017-12-28 20:28:41 --> Hooks Class Initialized
DEBUG - 2017-12-28 20:28:41 --> UTF-8 Support Enabled
INFO - 2017-12-28 20:28:41 --> Utf8 Class Initialized
INFO - 2017-12-28 20:28:41 --> URI Class Initialized
INFO - 2017-12-28 20:28:41 --> Router Class Initialized
INFO - 2017-12-28 20:28:41 --> Output Class Initialized
INFO - 2017-12-28 20:28:41 --> Security Class Initialized
DEBUG - 2017-12-28 20:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 20:28:41 --> Input Class Initialized
INFO - 2017-12-28 20:28:41 --> Language Class Initialized
INFO - 2017-12-28 20:28:41 --> Loader Class Initialized
INFO - 2017-12-28 20:28:41 --> Helper loaded: url_helper
INFO - 2017-12-28 20:28:41 --> Helper loaded: form_helper
INFO - 2017-12-28 20:28:41 --> Database Driver Class Initialized
DEBUG - 2017-12-28 20:28:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 20:28:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 20:28:41 --> Form Validation Class Initialized
INFO - 2017-12-28 20:28:41 --> Model Class Initialized
INFO - 2017-12-28 20:28:41 --> Controller Class Initialized
INFO - 2017-12-28 20:28:41 --> Model Class Initialized
INFO - 2017-12-28 20:28:41 --> Model Class Initialized
INFO - 2017-12-28 20:28:41 --> Model Class Initialized
INFO - 2017-12-28 20:28:41 --> Model Class Initialized
DEBUG - 2017-12-28 20:28:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-28 20:28:41 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-28 20:28:41 --> Final output sent to browser
DEBUG - 2017-12-28 20:28:41 --> Total execution time: 0.0917
INFO - 2017-12-28 20:28:41 --> Config Class Initialized
INFO - 2017-12-28 20:28:41 --> Hooks Class Initialized
DEBUG - 2017-12-28 20:28:41 --> UTF-8 Support Enabled
INFO - 2017-12-28 20:28:41 --> Utf8 Class Initialized
INFO - 2017-12-28 20:28:41 --> URI Class Initialized
INFO - 2017-12-28 20:28:41 --> Router Class Initialized
INFO - 2017-12-28 20:28:41 --> Output Class Initialized
INFO - 2017-12-28 20:28:41 --> Security Class Initialized
DEBUG - 2017-12-28 20:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-28 20:28:41 --> Input Class Initialized
INFO - 2017-12-28 20:28:41 --> Language Class Initialized
INFO - 2017-12-28 20:28:41 --> Loader Class Initialized
INFO - 2017-12-28 20:28:41 --> Helper loaded: url_helper
INFO - 2017-12-28 20:28:41 --> Helper loaded: form_helper
INFO - 2017-12-28 20:28:41 --> Database Driver Class Initialized
DEBUG - 2017-12-28 20:28:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-28 20:28:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-28 20:28:41 --> Form Validation Class Initialized
INFO - 2017-12-28 20:28:41 --> Model Class Initialized
INFO - 2017-12-28 20:28:41 --> Controller Class Initialized
INFO - 2017-12-28 20:28:41 --> Model Class Initialized
INFO - 2017-12-28 20:28:41 --> Model Class Initialized
INFO - 2017-12-28 20:28:41 --> Model Class Initialized
INFO - 2017-12-28 20:28:41 --> Model Class Initialized
DEBUG - 2017-12-28 20:28:41 --> Form_validation class already loaded. Second attempt ignored.
