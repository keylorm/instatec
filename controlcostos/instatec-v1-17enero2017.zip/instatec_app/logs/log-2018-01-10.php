<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-01-10 00:08:05 --> Config Class Initialized
INFO - 2018-01-10 00:08:05 --> Hooks Class Initialized
DEBUG - 2018-01-10 00:08:05 --> UTF-8 Support Enabled
INFO - 2018-01-10 00:08:05 --> Utf8 Class Initialized
INFO - 2018-01-10 00:08:05 --> URI Class Initialized
INFO - 2018-01-10 00:08:05 --> Router Class Initialized
INFO - 2018-01-10 00:08:05 --> Output Class Initialized
INFO - 2018-01-10 00:08:05 --> Security Class Initialized
DEBUG - 2018-01-10 00:08:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-10 00:08:05 --> Input Class Initialized
INFO - 2018-01-10 00:08:05 --> Language Class Initialized
INFO - 2018-01-10 00:08:05 --> Loader Class Initialized
INFO - 2018-01-10 00:08:05 --> Helper loaded: url_helper
INFO - 2018-01-10 00:08:05 --> Helper loaded: form_helper
INFO - 2018-01-10 00:08:05 --> Database Driver Class Initialized
DEBUG - 2018-01-10 00:08:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-10 00:08:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-10 00:08:05 --> Form Validation Class Initialized
INFO - 2018-01-10 00:08:05 --> Model Class Initialized
INFO - 2018-01-10 00:08:05 --> Controller Class Initialized
INFO - 2018-01-10 00:08:05 --> Model Class Initialized
DEBUG - 2018-01-10 00:08:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-10 00:08:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-01-10 00:08:05 --> Config Class Initialized
INFO - 2018-01-10 00:08:05 --> Hooks Class Initialized
DEBUG - 2018-01-10 00:08:05 --> UTF-8 Support Enabled
INFO - 2018-01-10 00:08:05 --> Utf8 Class Initialized
INFO - 2018-01-10 00:08:05 --> URI Class Initialized
DEBUG - 2018-01-10 00:08:05 --> No URI present. Default controller set.
INFO - 2018-01-10 00:08:05 --> Router Class Initialized
INFO - 2018-01-10 00:08:05 --> Output Class Initialized
INFO - 2018-01-10 00:08:05 --> Security Class Initialized
DEBUG - 2018-01-10 00:08:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-10 00:08:05 --> Input Class Initialized
INFO - 2018-01-10 00:08:05 --> Language Class Initialized
INFO - 2018-01-10 00:08:05 --> Loader Class Initialized
INFO - 2018-01-10 00:08:05 --> Helper loaded: url_helper
INFO - 2018-01-10 00:08:05 --> Helper loaded: form_helper
INFO - 2018-01-10 00:08:05 --> Database Driver Class Initialized
DEBUG - 2018-01-10 00:08:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-10 00:08:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-10 00:08:05 --> Form Validation Class Initialized
INFO - 2018-01-10 00:08:05 --> Model Class Initialized
INFO - 2018-01-10 00:08:05 --> Controller Class Initialized
INFO - 2018-01-10 00:08:06 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-10 00:08:06 --> Final output sent to browser
DEBUG - 2018-01-10 00:08:06 --> Total execution time: 0.1227
INFO - 2018-01-10 00:08:06 --> Config Class Initialized
INFO - 2018-01-10 00:08:06 --> Hooks Class Initialized
DEBUG - 2018-01-10 00:08:06 --> UTF-8 Support Enabled
INFO - 2018-01-10 00:08:06 --> Utf8 Class Initialized
INFO - 2018-01-10 00:08:06 --> URI Class Initialized
INFO - 2018-01-10 00:08:06 --> Router Class Initialized
INFO - 2018-01-10 00:08:06 --> Output Class Initialized
INFO - 2018-01-10 00:08:06 --> Security Class Initialized
DEBUG - 2018-01-10 00:08:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-10 00:08:06 --> Input Class Initialized
INFO - 2018-01-10 00:08:06 --> Language Class Initialized
INFO - 2018-01-10 00:08:06 --> Loader Class Initialized
INFO - 2018-01-10 00:08:06 --> Helper loaded: url_helper
INFO - 2018-01-10 00:08:06 --> Helper loaded: form_helper
INFO - 2018-01-10 00:08:06 --> Database Driver Class Initialized
DEBUG - 2018-01-10 00:08:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-10 00:08:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-10 00:08:06 --> Form Validation Class Initialized
INFO - 2018-01-10 00:08:06 --> Model Class Initialized
INFO - 2018-01-10 00:08:06 --> Controller Class Initialized
INFO - 2018-01-10 00:08:06 --> Model Class Initialized
INFO - 2018-01-10 00:08:06 --> Model Class Initialized
INFO - 2018-01-10 00:08:06 --> Model Class Initialized
INFO - 2018-01-10 00:08:06 --> Model Class Initialized
DEBUG - 2018-01-10 00:08:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-10 00:08:14 --> Config Class Initialized
INFO - 2018-01-10 00:08:14 --> Hooks Class Initialized
DEBUG - 2018-01-10 00:08:14 --> UTF-8 Support Enabled
INFO - 2018-01-10 00:08:14 --> Utf8 Class Initialized
INFO - 2018-01-10 00:08:14 --> URI Class Initialized
INFO - 2018-01-10 00:08:14 --> Router Class Initialized
INFO - 2018-01-10 00:08:14 --> Output Class Initialized
INFO - 2018-01-10 00:08:14 --> Security Class Initialized
DEBUG - 2018-01-10 00:08:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-10 00:08:14 --> Input Class Initialized
INFO - 2018-01-10 00:08:14 --> Language Class Initialized
INFO - 2018-01-10 00:08:14 --> Loader Class Initialized
INFO - 2018-01-10 00:08:14 --> Helper loaded: url_helper
INFO - 2018-01-10 00:08:14 --> Helper loaded: form_helper
INFO - 2018-01-10 00:08:14 --> Database Driver Class Initialized
DEBUG - 2018-01-10 00:08:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-10 00:08:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-10 00:08:14 --> Form Validation Class Initialized
INFO - 2018-01-10 00:08:14 --> Model Class Initialized
INFO - 2018-01-10 00:08:14 --> Controller Class Initialized
INFO - 2018-01-10 00:08:14 --> Model Class Initialized
INFO - 2018-01-10 00:08:14 --> Model Class Initialized
DEBUG - 2018-01-10 00:08:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-10 00:08:14 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-10 00:08:14 --> Final output sent to browser
DEBUG - 2018-01-10 00:08:14 --> Total execution time: 0.1470
INFO - 2018-01-10 00:08:15 --> Config Class Initialized
INFO - 2018-01-10 00:08:15 --> Hooks Class Initialized
DEBUG - 2018-01-10 00:08:15 --> UTF-8 Support Enabled
INFO - 2018-01-10 00:08:15 --> Utf8 Class Initialized
INFO - 2018-01-10 00:08:15 --> URI Class Initialized
INFO - 2018-01-10 00:08:15 --> Router Class Initialized
INFO - 2018-01-10 00:08:15 --> Output Class Initialized
INFO - 2018-01-10 00:08:15 --> Security Class Initialized
DEBUG - 2018-01-10 00:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-10 00:08:15 --> Input Class Initialized
INFO - 2018-01-10 00:08:15 --> Language Class Initialized
INFO - 2018-01-10 00:08:15 --> Loader Class Initialized
INFO - 2018-01-10 00:08:15 --> Helper loaded: url_helper
INFO - 2018-01-10 00:08:15 --> Helper loaded: form_helper
INFO - 2018-01-10 00:08:15 --> Database Driver Class Initialized
DEBUG - 2018-01-10 00:08:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-10 00:08:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-10 00:08:15 --> Form Validation Class Initialized
INFO - 2018-01-10 00:08:15 --> Model Class Initialized
INFO - 2018-01-10 00:08:15 --> Controller Class Initialized
INFO - 2018-01-10 00:08:15 --> Model Class Initialized
INFO - 2018-01-10 00:08:15 --> Model Class Initialized
DEBUG - 2018-01-10 00:08:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-10 00:08:24 --> Config Class Initialized
INFO - 2018-01-10 00:08:24 --> Hooks Class Initialized
DEBUG - 2018-01-10 00:08:24 --> UTF-8 Support Enabled
INFO - 2018-01-10 00:08:24 --> Utf8 Class Initialized
INFO - 2018-01-10 00:08:24 --> URI Class Initialized
INFO - 2018-01-10 00:08:24 --> Router Class Initialized
INFO - 2018-01-10 00:08:24 --> Output Class Initialized
INFO - 2018-01-10 00:08:24 --> Security Class Initialized
DEBUG - 2018-01-10 00:08:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-10 00:08:24 --> Input Class Initialized
INFO - 2018-01-10 00:08:24 --> Language Class Initialized
INFO - 2018-01-10 00:08:24 --> Loader Class Initialized
INFO - 2018-01-10 00:08:24 --> Helper loaded: url_helper
INFO - 2018-01-10 00:08:24 --> Helper loaded: form_helper
INFO - 2018-01-10 00:08:24 --> Database Driver Class Initialized
DEBUG - 2018-01-10 00:08:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-10 00:08:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-10 00:08:24 --> Form Validation Class Initialized
INFO - 2018-01-10 00:08:24 --> Model Class Initialized
INFO - 2018-01-10 00:08:24 --> Controller Class Initialized
INFO - 2018-01-10 00:08:24 --> Model Class Initialized
INFO - 2018-01-10 00:08:24 --> Model Class Initialized
DEBUG - 2018-01-10 00:08:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-10 00:08:24 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-10 00:08:24 --> Final output sent to browser
DEBUG - 2018-01-10 00:08:24 --> Total execution time: 0.1871
INFO - 2018-01-10 00:08:31 --> Config Class Initialized
INFO - 2018-01-10 00:08:31 --> Hooks Class Initialized
DEBUG - 2018-01-10 00:08:31 --> UTF-8 Support Enabled
INFO - 2018-01-10 00:08:31 --> Utf8 Class Initialized
INFO - 2018-01-10 00:08:31 --> URI Class Initialized
INFO - 2018-01-10 00:08:31 --> Router Class Initialized
INFO - 2018-01-10 00:08:31 --> Output Class Initialized
INFO - 2018-01-10 00:08:31 --> Security Class Initialized
DEBUG - 2018-01-10 00:08:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-10 00:08:31 --> Input Class Initialized
INFO - 2018-01-10 00:08:31 --> Language Class Initialized
INFO - 2018-01-10 00:08:31 --> Loader Class Initialized
INFO - 2018-01-10 00:08:31 --> Helper loaded: url_helper
INFO - 2018-01-10 00:08:31 --> Helper loaded: form_helper
INFO - 2018-01-10 00:08:31 --> Database Driver Class Initialized
DEBUG - 2018-01-10 00:08:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-10 00:08:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-10 00:08:31 --> Form Validation Class Initialized
INFO - 2018-01-10 00:08:31 --> Model Class Initialized
INFO - 2018-01-10 00:08:31 --> Controller Class Initialized
INFO - 2018-01-10 00:08:31 --> Model Class Initialized
INFO - 2018-01-10 00:08:31 --> Model Class Initialized
DEBUG - 2018-01-10 00:08:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-10 00:08:31 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-10 00:08:31 --> Final output sent to browser
DEBUG - 2018-01-10 00:08:31 --> Total execution time: 0.1633
INFO - 2018-01-10 00:08:41 --> Config Class Initialized
INFO - 2018-01-10 00:08:41 --> Hooks Class Initialized
DEBUG - 2018-01-10 00:08:41 --> UTF-8 Support Enabled
INFO - 2018-01-10 00:08:41 --> Utf8 Class Initialized
INFO - 2018-01-10 00:08:41 --> URI Class Initialized
INFO - 2018-01-10 00:08:41 --> Router Class Initialized
INFO - 2018-01-10 00:08:41 --> Output Class Initialized
INFO - 2018-01-10 00:08:41 --> Security Class Initialized
DEBUG - 2018-01-10 00:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-10 00:08:41 --> Input Class Initialized
INFO - 2018-01-10 00:08:41 --> Language Class Initialized
INFO - 2018-01-10 00:08:41 --> Loader Class Initialized
INFO - 2018-01-10 00:08:41 --> Helper loaded: url_helper
INFO - 2018-01-10 00:08:41 --> Helper loaded: form_helper
INFO - 2018-01-10 00:08:41 --> Database Driver Class Initialized
DEBUG - 2018-01-10 00:08:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-10 00:08:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-10 00:08:41 --> Form Validation Class Initialized
INFO - 2018-01-10 00:08:41 --> Model Class Initialized
INFO - 2018-01-10 00:08:41 --> Controller Class Initialized
INFO - 2018-01-10 00:08:41 --> Model Class Initialized
INFO - 2018-01-10 00:08:41 --> Model Class Initialized
DEBUG - 2018-01-10 00:08:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-10 00:08:41 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-10 00:08:41 --> Final output sent to browser
DEBUG - 2018-01-10 00:08:41 --> Total execution time: 0.1054
INFO - 2018-01-10 00:08:41 --> Config Class Initialized
INFO - 2018-01-10 00:08:41 --> Hooks Class Initialized
DEBUG - 2018-01-10 00:08:41 --> UTF-8 Support Enabled
INFO - 2018-01-10 00:08:41 --> Utf8 Class Initialized
INFO - 2018-01-10 00:08:41 --> URI Class Initialized
INFO - 2018-01-10 00:08:41 --> Router Class Initialized
INFO - 2018-01-10 00:08:41 --> Output Class Initialized
INFO - 2018-01-10 00:08:41 --> Security Class Initialized
DEBUG - 2018-01-10 00:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-10 00:08:41 --> Input Class Initialized
INFO - 2018-01-10 00:08:41 --> Language Class Initialized
INFO - 2018-01-10 00:08:41 --> Loader Class Initialized
INFO - 2018-01-10 00:08:41 --> Helper loaded: url_helper
INFO - 2018-01-10 00:08:41 --> Helper loaded: form_helper
INFO - 2018-01-10 00:08:41 --> Database Driver Class Initialized
DEBUG - 2018-01-10 00:08:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-10 00:08:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-10 00:08:41 --> Form Validation Class Initialized
INFO - 2018-01-10 00:08:41 --> Model Class Initialized
INFO - 2018-01-10 00:08:41 --> Controller Class Initialized
INFO - 2018-01-10 00:08:41 --> Model Class Initialized
INFO - 2018-01-10 00:08:41 --> Model Class Initialized
DEBUG - 2018-01-10 00:08:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-10 00:08:43 --> Config Class Initialized
INFO - 2018-01-10 00:08:43 --> Hooks Class Initialized
DEBUG - 2018-01-10 00:08:43 --> UTF-8 Support Enabled
INFO - 2018-01-10 00:08:43 --> Utf8 Class Initialized
INFO - 2018-01-10 00:08:43 --> URI Class Initialized
INFO - 2018-01-10 00:08:43 --> Router Class Initialized
INFO - 2018-01-10 00:08:43 --> Output Class Initialized
INFO - 2018-01-10 00:08:43 --> Security Class Initialized
DEBUG - 2018-01-10 00:08:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-10 00:08:43 --> Input Class Initialized
INFO - 2018-01-10 00:08:43 --> Language Class Initialized
INFO - 2018-01-10 00:08:43 --> Loader Class Initialized
INFO - 2018-01-10 00:08:43 --> Helper loaded: url_helper
INFO - 2018-01-10 00:08:43 --> Helper loaded: form_helper
INFO - 2018-01-10 00:08:43 --> Database Driver Class Initialized
DEBUG - 2018-01-10 00:08:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-10 00:08:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-10 00:08:43 --> Form Validation Class Initialized
INFO - 2018-01-10 00:08:43 --> Model Class Initialized
INFO - 2018-01-10 00:08:43 --> Controller Class Initialized
INFO - 2018-01-10 00:08:43 --> Model Class Initialized
INFO - 2018-01-10 00:08:43 --> Model Class Initialized
DEBUG - 2018-01-10 00:08:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-10 00:08:43 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-10 00:08:43 --> Final output sent to browser
DEBUG - 2018-01-10 00:08:43 --> Total execution time: 0.0877
INFO - 2018-01-10 00:08:45 --> Config Class Initialized
INFO - 2018-01-10 00:08:45 --> Hooks Class Initialized
DEBUG - 2018-01-10 00:08:45 --> UTF-8 Support Enabled
INFO - 2018-01-10 00:08:45 --> Utf8 Class Initialized
INFO - 2018-01-10 00:08:45 --> URI Class Initialized
INFO - 2018-01-10 00:08:45 --> Router Class Initialized
INFO - 2018-01-10 00:08:45 --> Output Class Initialized
INFO - 2018-01-10 00:08:45 --> Security Class Initialized
DEBUG - 2018-01-10 00:08:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-10 00:08:45 --> Input Class Initialized
INFO - 2018-01-10 00:08:45 --> Language Class Initialized
INFO - 2018-01-10 00:08:45 --> Loader Class Initialized
INFO - 2018-01-10 00:08:45 --> Helper loaded: url_helper
INFO - 2018-01-10 00:08:45 --> Helper loaded: form_helper
INFO - 2018-01-10 00:08:45 --> Database Driver Class Initialized
DEBUG - 2018-01-10 00:08:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-10 00:08:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-10 00:08:45 --> Form Validation Class Initialized
INFO - 2018-01-10 00:08:45 --> Model Class Initialized
INFO - 2018-01-10 00:08:45 --> Controller Class Initialized
INFO - 2018-01-10 00:08:45 --> Model Class Initialized
INFO - 2018-01-10 00:08:45 --> Model Class Initialized
DEBUG - 2018-01-10 00:08:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-10 00:08:45 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-10 00:08:45 --> Final output sent to browser
DEBUG - 2018-01-10 00:08:45 --> Total execution time: 0.0361
INFO - 2018-01-10 00:08:45 --> Config Class Initialized
INFO - 2018-01-10 00:08:45 --> Hooks Class Initialized
DEBUG - 2018-01-10 00:08:45 --> UTF-8 Support Enabled
INFO - 2018-01-10 00:08:45 --> Utf8 Class Initialized
INFO - 2018-01-10 00:08:45 --> URI Class Initialized
INFO - 2018-01-10 00:08:45 --> Router Class Initialized
INFO - 2018-01-10 00:08:45 --> Output Class Initialized
INFO - 2018-01-10 00:08:45 --> Security Class Initialized
DEBUG - 2018-01-10 00:08:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-10 00:08:45 --> Input Class Initialized
INFO - 2018-01-10 00:08:45 --> Language Class Initialized
INFO - 2018-01-10 00:08:45 --> Loader Class Initialized
INFO - 2018-01-10 00:08:45 --> Helper loaded: url_helper
INFO - 2018-01-10 00:08:45 --> Helper loaded: form_helper
INFO - 2018-01-10 00:08:45 --> Database Driver Class Initialized
DEBUG - 2018-01-10 00:08:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-10 00:08:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-10 00:08:45 --> Form Validation Class Initialized
INFO - 2018-01-10 00:08:45 --> Model Class Initialized
INFO - 2018-01-10 00:08:45 --> Controller Class Initialized
INFO - 2018-01-10 00:08:45 --> Model Class Initialized
INFO - 2018-01-10 00:08:45 --> Model Class Initialized
DEBUG - 2018-01-10 00:08:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-10 00:08:51 --> Config Class Initialized
INFO - 2018-01-10 00:08:51 --> Hooks Class Initialized
DEBUG - 2018-01-10 00:08:51 --> UTF-8 Support Enabled
INFO - 2018-01-10 00:08:51 --> Utf8 Class Initialized
INFO - 2018-01-10 00:08:51 --> URI Class Initialized
INFO - 2018-01-10 00:08:51 --> Router Class Initialized
INFO - 2018-01-10 00:08:51 --> Output Class Initialized
INFO - 2018-01-10 00:08:51 --> Security Class Initialized
DEBUG - 2018-01-10 00:08:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-10 00:08:51 --> Input Class Initialized
INFO - 2018-01-10 00:08:51 --> Language Class Initialized
INFO - 2018-01-10 00:08:51 --> Loader Class Initialized
INFO - 2018-01-10 00:08:51 --> Helper loaded: url_helper
INFO - 2018-01-10 00:08:51 --> Helper loaded: form_helper
INFO - 2018-01-10 00:08:51 --> Database Driver Class Initialized
DEBUG - 2018-01-10 00:08:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-10 00:08:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-10 00:08:51 --> Form Validation Class Initialized
INFO - 2018-01-10 00:08:51 --> Model Class Initialized
INFO - 2018-01-10 00:08:51 --> Controller Class Initialized
INFO - 2018-01-10 00:08:51 --> Model Class Initialized
INFO - 2018-01-10 00:08:51 --> Model Class Initialized
DEBUG - 2018-01-10 00:08:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-10 00:08:54 --> Config Class Initialized
INFO - 2018-01-10 00:08:54 --> Hooks Class Initialized
DEBUG - 2018-01-10 00:08:54 --> UTF-8 Support Enabled
INFO - 2018-01-10 00:08:54 --> Utf8 Class Initialized
INFO - 2018-01-10 00:08:54 --> URI Class Initialized
INFO - 2018-01-10 00:08:54 --> Router Class Initialized
INFO - 2018-01-10 00:08:54 --> Output Class Initialized
INFO - 2018-01-10 00:08:54 --> Security Class Initialized
DEBUG - 2018-01-10 00:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-10 00:08:54 --> Input Class Initialized
INFO - 2018-01-10 00:08:54 --> Language Class Initialized
INFO - 2018-01-10 00:08:54 --> Loader Class Initialized
INFO - 2018-01-10 00:08:54 --> Helper loaded: url_helper
INFO - 2018-01-10 00:08:54 --> Helper loaded: form_helper
INFO - 2018-01-10 00:08:54 --> Database Driver Class Initialized
DEBUG - 2018-01-10 00:08:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-10 00:08:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-10 00:08:54 --> Form Validation Class Initialized
INFO - 2018-01-10 00:08:54 --> Model Class Initialized
INFO - 2018-01-10 00:08:54 --> Controller Class Initialized
INFO - 2018-01-10 00:08:54 --> Model Class Initialized
INFO - 2018-01-10 00:08:54 --> Model Class Initialized
DEBUG - 2018-01-10 00:08:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-10 00:08:54 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-10 00:08:54 --> Final output sent to browser
DEBUG - 2018-01-10 00:08:54 --> Total execution time: 0.1382
INFO - 2018-01-10 00:08:54 --> Config Class Initialized
INFO - 2018-01-10 00:08:54 --> Hooks Class Initialized
DEBUG - 2018-01-10 00:08:54 --> UTF-8 Support Enabled
INFO - 2018-01-10 00:08:54 --> Utf8 Class Initialized
INFO - 2018-01-10 00:08:54 --> URI Class Initialized
INFO - 2018-01-10 00:08:54 --> Router Class Initialized
INFO - 2018-01-10 00:08:54 --> Output Class Initialized
INFO - 2018-01-10 00:08:54 --> Security Class Initialized
DEBUG - 2018-01-10 00:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-10 00:08:54 --> Input Class Initialized
INFO - 2018-01-10 00:08:54 --> Language Class Initialized
INFO - 2018-01-10 00:08:54 --> Loader Class Initialized
INFO - 2018-01-10 00:08:54 --> Helper loaded: url_helper
INFO - 2018-01-10 00:08:54 --> Helper loaded: form_helper
INFO - 2018-01-10 00:08:54 --> Database Driver Class Initialized
DEBUG - 2018-01-10 00:08:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-10 00:08:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-10 00:08:54 --> Form Validation Class Initialized
INFO - 2018-01-10 00:08:54 --> Model Class Initialized
INFO - 2018-01-10 00:08:54 --> Controller Class Initialized
INFO - 2018-01-10 00:08:54 --> Model Class Initialized
INFO - 2018-01-10 00:08:54 --> Model Class Initialized
DEBUG - 2018-01-10 00:08:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-10 00:09:02 --> Config Class Initialized
INFO - 2018-01-10 00:09:02 --> Hooks Class Initialized
DEBUG - 2018-01-10 00:09:02 --> UTF-8 Support Enabled
INFO - 2018-01-10 00:09:02 --> Utf8 Class Initialized
INFO - 2018-01-10 00:09:02 --> URI Class Initialized
INFO - 2018-01-10 00:09:02 --> Router Class Initialized
INFO - 2018-01-10 00:09:02 --> Output Class Initialized
INFO - 2018-01-10 00:09:02 --> Security Class Initialized
DEBUG - 2018-01-10 00:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-10 00:09:02 --> Input Class Initialized
INFO - 2018-01-10 00:09:02 --> Language Class Initialized
INFO - 2018-01-10 00:09:02 --> Loader Class Initialized
INFO - 2018-01-10 00:09:02 --> Helper loaded: url_helper
INFO - 2018-01-10 00:09:02 --> Helper loaded: form_helper
INFO - 2018-01-10 00:09:02 --> Database Driver Class Initialized
DEBUG - 2018-01-10 00:09:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-10 00:09:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-10 00:09:02 --> Form Validation Class Initialized
INFO - 2018-01-10 00:09:02 --> Model Class Initialized
INFO - 2018-01-10 00:09:02 --> Controller Class Initialized
INFO - 2018-01-10 00:09:02 --> Model Class Initialized
INFO - 2018-01-10 00:09:02 --> Model Class Initialized
INFO - 2018-01-10 00:09:02 --> Model Class Initialized
INFO - 2018-01-10 00:09:02 --> Model Class Initialized
DEBUG - 2018-01-10 00:09:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-10 00:09:02 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-10 00:09:02 --> Final output sent to browser
DEBUG - 2018-01-10 00:09:02 --> Total execution time: 0.1529
INFO - 2018-01-10 00:09:02 --> Config Class Initialized
INFO - 2018-01-10 00:09:02 --> Hooks Class Initialized
DEBUG - 2018-01-10 00:09:02 --> UTF-8 Support Enabled
INFO - 2018-01-10 00:09:02 --> Utf8 Class Initialized
INFO - 2018-01-10 00:09:02 --> URI Class Initialized
INFO - 2018-01-10 00:09:02 --> Router Class Initialized
INFO - 2018-01-10 00:09:02 --> Output Class Initialized
INFO - 2018-01-10 00:09:02 --> Security Class Initialized
DEBUG - 2018-01-10 00:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-10 00:09:02 --> Input Class Initialized
INFO - 2018-01-10 00:09:02 --> Language Class Initialized
INFO - 2018-01-10 00:09:02 --> Loader Class Initialized
INFO - 2018-01-10 00:09:02 --> Helper loaded: url_helper
INFO - 2018-01-10 00:09:02 --> Helper loaded: form_helper
INFO - 2018-01-10 00:09:02 --> Database Driver Class Initialized
DEBUG - 2018-01-10 00:09:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-10 00:09:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-10 00:09:02 --> Form Validation Class Initialized
INFO - 2018-01-10 00:09:02 --> Model Class Initialized
INFO - 2018-01-10 00:09:02 --> Controller Class Initialized
INFO - 2018-01-10 00:09:02 --> Model Class Initialized
INFO - 2018-01-10 00:09:02 --> Model Class Initialized
INFO - 2018-01-10 00:09:02 --> Model Class Initialized
INFO - 2018-01-10 00:09:02 --> Model Class Initialized
DEBUG - 2018-01-10 00:09:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-10 00:09:04 --> Config Class Initialized
INFO - 2018-01-10 00:09:04 --> Hooks Class Initialized
DEBUG - 2018-01-10 00:09:04 --> UTF-8 Support Enabled
INFO - 2018-01-10 00:09:04 --> Utf8 Class Initialized
INFO - 2018-01-10 00:09:04 --> URI Class Initialized
INFO - 2018-01-10 00:09:04 --> Router Class Initialized
INFO - 2018-01-10 00:09:04 --> Output Class Initialized
INFO - 2018-01-10 00:09:04 --> Security Class Initialized
DEBUG - 2018-01-10 00:09:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-10 00:09:04 --> Input Class Initialized
INFO - 2018-01-10 00:09:04 --> Language Class Initialized
INFO - 2018-01-10 00:09:04 --> Loader Class Initialized
INFO - 2018-01-10 00:09:04 --> Helper loaded: url_helper
INFO - 2018-01-10 00:09:04 --> Helper loaded: form_helper
INFO - 2018-01-10 00:09:04 --> Database Driver Class Initialized
DEBUG - 2018-01-10 00:09:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-10 00:09:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-10 00:09:04 --> Form Validation Class Initialized
INFO - 2018-01-10 00:09:04 --> Model Class Initialized
INFO - 2018-01-10 00:09:04 --> Controller Class Initialized
INFO - 2018-01-10 00:09:04 --> Model Class Initialized
INFO - 2018-01-10 00:09:04 --> Model Class Initialized
INFO - 2018-01-10 00:09:04 --> Model Class Initialized
INFO - 2018-01-10 00:09:04 --> Model Class Initialized
DEBUG - 2018-01-10 00:09:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-10 00:09:05 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-10 00:09:05 --> Final output sent to browser
DEBUG - 2018-01-10 00:09:05 --> Total execution time: 0.0942
INFO - 2018-01-10 00:09:30 --> Config Class Initialized
INFO - 2018-01-10 00:09:30 --> Hooks Class Initialized
DEBUG - 2018-01-10 00:09:30 --> UTF-8 Support Enabled
INFO - 2018-01-10 00:09:30 --> Utf8 Class Initialized
INFO - 2018-01-10 00:09:30 --> URI Class Initialized
INFO - 2018-01-10 00:09:30 --> Router Class Initialized
INFO - 2018-01-10 00:09:30 --> Output Class Initialized
INFO - 2018-01-10 00:09:30 --> Security Class Initialized
DEBUG - 2018-01-10 00:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-10 00:09:30 --> Input Class Initialized
INFO - 2018-01-10 00:09:30 --> Language Class Initialized
INFO - 2018-01-10 00:09:30 --> Loader Class Initialized
INFO - 2018-01-10 00:09:30 --> Helper loaded: url_helper
INFO - 2018-01-10 00:09:30 --> Helper loaded: form_helper
INFO - 2018-01-10 00:09:30 --> Database Driver Class Initialized
DEBUG - 2018-01-10 00:09:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-10 00:09:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-10 00:09:30 --> Form Validation Class Initialized
INFO - 2018-01-10 00:09:30 --> Model Class Initialized
INFO - 2018-01-10 00:09:30 --> Controller Class Initialized
INFO - 2018-01-10 00:09:30 --> Model Class Initialized
INFO - 2018-01-10 00:09:30 --> Model Class Initialized
INFO - 2018-01-10 00:09:30 --> Model Class Initialized
INFO - 2018-01-10 00:09:30 --> Model Class Initialized
DEBUG - 2018-01-10 00:09:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-10 00:09:30 --> Final output sent to browser
DEBUG - 2018-01-10 00:09:30 --> Total execution time: 0.1142
INFO - 2018-01-10 00:09:31 --> Config Class Initialized
INFO - 2018-01-10 00:09:31 --> Hooks Class Initialized
DEBUG - 2018-01-10 00:09:31 --> UTF-8 Support Enabled
INFO - 2018-01-10 00:09:31 --> Utf8 Class Initialized
INFO - 2018-01-10 00:09:31 --> URI Class Initialized
INFO - 2018-01-10 00:09:31 --> Router Class Initialized
INFO - 2018-01-10 00:09:31 --> Output Class Initialized
INFO - 2018-01-10 00:09:31 --> Security Class Initialized
DEBUG - 2018-01-10 00:09:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-10 00:09:31 --> Input Class Initialized
INFO - 2018-01-10 00:09:31 --> Language Class Initialized
INFO - 2018-01-10 00:09:31 --> Loader Class Initialized
INFO - 2018-01-10 00:09:31 --> Helper loaded: url_helper
INFO - 2018-01-10 00:09:31 --> Helper loaded: form_helper
INFO - 2018-01-10 00:09:31 --> Database Driver Class Initialized
DEBUG - 2018-01-10 00:09:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-10 00:09:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-10 00:09:31 --> Form Validation Class Initialized
INFO - 2018-01-10 00:09:31 --> Model Class Initialized
INFO - 2018-01-10 00:09:31 --> Controller Class Initialized
INFO - 2018-01-10 00:09:31 --> Model Class Initialized
INFO - 2018-01-10 00:09:31 --> Model Class Initialized
INFO - 2018-01-10 00:09:31 --> Model Class Initialized
INFO - 2018-01-10 00:09:31 --> Model Class Initialized
DEBUG - 2018-01-10 00:09:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-10 00:09:32 --> Config Class Initialized
INFO - 2018-01-10 00:09:32 --> Hooks Class Initialized
DEBUG - 2018-01-10 00:09:32 --> UTF-8 Support Enabled
INFO - 2018-01-10 00:09:32 --> Utf8 Class Initialized
INFO - 2018-01-10 00:09:32 --> URI Class Initialized
INFO - 2018-01-10 00:09:32 --> Router Class Initialized
INFO - 2018-01-10 00:09:32 --> Output Class Initialized
INFO - 2018-01-10 00:09:32 --> Security Class Initialized
DEBUG - 2018-01-10 00:09:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-10 00:09:32 --> Input Class Initialized
INFO - 2018-01-10 00:09:32 --> Language Class Initialized
INFO - 2018-01-10 00:09:32 --> Loader Class Initialized
INFO - 2018-01-10 00:09:32 --> Helper loaded: url_helper
INFO - 2018-01-10 00:09:32 --> Helper loaded: form_helper
INFO - 2018-01-10 00:09:32 --> Database Driver Class Initialized
DEBUG - 2018-01-10 00:09:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-10 00:09:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-10 00:09:32 --> Form Validation Class Initialized
INFO - 2018-01-10 00:09:32 --> Model Class Initialized
INFO - 2018-01-10 00:09:32 --> Controller Class Initialized
INFO - 2018-01-10 00:09:32 --> Model Class Initialized
INFO - 2018-01-10 00:09:32 --> Model Class Initialized
INFO - 2018-01-10 00:09:32 --> Model Class Initialized
INFO - 2018-01-10 00:09:32 --> Model Class Initialized
DEBUG - 2018-01-10 00:09:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-10 00:09:32 --> Final output sent to browser
DEBUG - 2018-01-10 00:09:32 --> Total execution time: 0.0971
INFO - 2018-01-10 00:09:33 --> Config Class Initialized
INFO - 2018-01-10 00:09:33 --> Hooks Class Initialized
DEBUG - 2018-01-10 00:09:33 --> UTF-8 Support Enabled
INFO - 2018-01-10 00:09:33 --> Utf8 Class Initialized
INFO - 2018-01-10 00:09:33 --> URI Class Initialized
INFO - 2018-01-10 00:09:33 --> Router Class Initialized
INFO - 2018-01-10 00:09:33 --> Output Class Initialized
INFO - 2018-01-10 00:09:33 --> Security Class Initialized
DEBUG - 2018-01-10 00:09:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-10 00:09:33 --> Input Class Initialized
INFO - 2018-01-10 00:09:33 --> Language Class Initialized
INFO - 2018-01-10 00:09:33 --> Loader Class Initialized
INFO - 2018-01-10 00:09:33 --> Helper loaded: url_helper
INFO - 2018-01-10 00:09:33 --> Helper loaded: form_helper
INFO - 2018-01-10 00:09:33 --> Database Driver Class Initialized
DEBUG - 2018-01-10 00:09:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-10 00:09:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-10 00:09:33 --> Form Validation Class Initialized
INFO - 2018-01-10 00:09:33 --> Model Class Initialized
INFO - 2018-01-10 00:09:33 --> Controller Class Initialized
INFO - 2018-01-10 00:09:33 --> Model Class Initialized
INFO - 2018-01-10 00:09:33 --> Model Class Initialized
INFO - 2018-01-10 00:09:33 --> Model Class Initialized
INFO - 2018-01-10 00:09:33 --> Model Class Initialized
DEBUG - 2018-01-10 00:09:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-10 00:09:34 --> Config Class Initialized
INFO - 2018-01-10 00:09:34 --> Hooks Class Initialized
DEBUG - 2018-01-10 00:09:34 --> UTF-8 Support Enabled
INFO - 2018-01-10 00:09:34 --> Utf8 Class Initialized
INFO - 2018-01-10 00:09:34 --> URI Class Initialized
INFO - 2018-01-10 00:09:34 --> Router Class Initialized
INFO - 2018-01-10 00:09:34 --> Output Class Initialized
INFO - 2018-01-10 00:09:34 --> Security Class Initialized
DEBUG - 2018-01-10 00:09:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-10 00:09:34 --> Input Class Initialized
INFO - 2018-01-10 00:09:34 --> Language Class Initialized
INFO - 2018-01-10 00:09:34 --> Loader Class Initialized
INFO - 2018-01-10 00:09:34 --> Helper loaded: url_helper
INFO - 2018-01-10 00:09:34 --> Helper loaded: form_helper
INFO - 2018-01-10 00:09:34 --> Database Driver Class Initialized
DEBUG - 2018-01-10 00:09:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-10 00:09:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-10 00:09:34 --> Form Validation Class Initialized
INFO - 2018-01-10 00:09:34 --> Model Class Initialized
INFO - 2018-01-10 00:09:34 --> Controller Class Initialized
INFO - 2018-01-10 00:09:34 --> Model Class Initialized
INFO - 2018-01-10 00:09:34 --> Model Class Initialized
INFO - 2018-01-10 00:09:34 --> Model Class Initialized
INFO - 2018-01-10 00:09:34 --> Model Class Initialized
DEBUG - 2018-01-10 00:09:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-10 00:09:36 --> Config Class Initialized
INFO - 2018-01-10 00:09:36 --> Hooks Class Initialized
DEBUG - 2018-01-10 00:09:36 --> UTF-8 Support Enabled
INFO - 2018-01-10 00:09:36 --> Utf8 Class Initialized
INFO - 2018-01-10 00:09:36 --> URI Class Initialized
INFO - 2018-01-10 00:09:36 --> Router Class Initialized
INFO - 2018-01-10 00:09:36 --> Output Class Initialized
INFO - 2018-01-10 00:09:36 --> Security Class Initialized
DEBUG - 2018-01-10 00:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-10 00:09:36 --> Input Class Initialized
INFO - 2018-01-10 00:09:36 --> Language Class Initialized
INFO - 2018-01-10 00:09:36 --> Loader Class Initialized
INFO - 2018-01-10 00:09:36 --> Helper loaded: url_helper
INFO - 2018-01-10 00:09:36 --> Helper loaded: form_helper
INFO - 2018-01-10 00:09:36 --> Database Driver Class Initialized
DEBUG - 2018-01-10 00:09:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-10 00:09:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-10 00:09:36 --> Form Validation Class Initialized
INFO - 2018-01-10 00:09:36 --> Model Class Initialized
INFO - 2018-01-10 00:09:36 --> Controller Class Initialized
INFO - 2018-01-10 00:09:36 --> Model Class Initialized
INFO - 2018-01-10 00:09:36 --> Model Class Initialized
INFO - 2018-01-10 00:09:36 --> Model Class Initialized
INFO - 2018-01-10 00:09:36 --> Model Class Initialized
DEBUG - 2018-01-10 00:09:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-10 00:10:41 --> Config Class Initialized
INFO - 2018-01-10 00:10:41 --> Hooks Class Initialized
DEBUG - 2018-01-10 00:10:41 --> UTF-8 Support Enabled
INFO - 2018-01-10 00:10:41 --> Utf8 Class Initialized
INFO - 2018-01-10 00:10:41 --> URI Class Initialized
INFO - 2018-01-10 00:10:41 --> Router Class Initialized
INFO - 2018-01-10 00:10:41 --> Output Class Initialized
INFO - 2018-01-10 00:10:41 --> Security Class Initialized
DEBUG - 2018-01-10 00:10:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-10 00:10:41 --> Input Class Initialized
INFO - 2018-01-10 00:10:41 --> Language Class Initialized
INFO - 2018-01-10 00:10:41 --> Loader Class Initialized
INFO - 2018-01-10 00:10:41 --> Helper loaded: url_helper
INFO - 2018-01-10 00:10:41 --> Helper loaded: form_helper
INFO - 2018-01-10 00:10:41 --> Database Driver Class Initialized
DEBUG - 2018-01-10 00:10:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-10 00:10:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-10 00:10:41 --> Form Validation Class Initialized
INFO - 2018-01-10 00:10:41 --> Model Class Initialized
INFO - 2018-01-10 00:10:41 --> Controller Class Initialized
INFO - 2018-01-10 00:10:41 --> Model Class Initialized
INFO - 2018-01-10 00:10:41 --> Model Class Initialized
INFO - 2018-01-10 00:10:41 --> Model Class Initialized
INFO - 2018-01-10 00:10:41 --> Model Class Initialized
DEBUG - 2018-01-10 00:10:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-10 00:10:41 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-10 00:10:41 --> Final output sent to browser
DEBUG - 2018-01-10 00:10:41 --> Total execution time: 0.0975
INFO - 2018-01-10 00:10:41 --> Config Class Initialized
INFO - 2018-01-10 00:10:41 --> Hooks Class Initialized
DEBUG - 2018-01-10 00:10:41 --> UTF-8 Support Enabled
INFO - 2018-01-10 00:10:41 --> Utf8 Class Initialized
INFO - 2018-01-10 00:10:41 --> URI Class Initialized
INFO - 2018-01-10 00:10:41 --> Router Class Initialized
INFO - 2018-01-10 00:10:41 --> Output Class Initialized
INFO - 2018-01-10 00:10:41 --> Security Class Initialized
DEBUG - 2018-01-10 00:10:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-10 00:10:41 --> Input Class Initialized
INFO - 2018-01-10 00:10:41 --> Language Class Initialized
INFO - 2018-01-10 00:10:41 --> Loader Class Initialized
INFO - 2018-01-10 00:10:41 --> Helper loaded: url_helper
INFO - 2018-01-10 00:10:41 --> Helper loaded: form_helper
INFO - 2018-01-10 00:10:41 --> Database Driver Class Initialized
DEBUG - 2018-01-10 00:10:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-10 00:10:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-10 00:10:41 --> Form Validation Class Initialized
INFO - 2018-01-10 00:10:41 --> Model Class Initialized
INFO - 2018-01-10 00:10:41 --> Controller Class Initialized
INFO - 2018-01-10 00:10:41 --> Model Class Initialized
INFO - 2018-01-10 00:10:41 --> Model Class Initialized
INFO - 2018-01-10 00:10:41 --> Model Class Initialized
INFO - 2018-01-10 00:10:41 --> Model Class Initialized
DEBUG - 2018-01-10 00:10:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-10 00:10:46 --> Config Class Initialized
INFO - 2018-01-10 00:10:46 --> Hooks Class Initialized
DEBUG - 2018-01-10 00:10:46 --> UTF-8 Support Enabled
INFO - 2018-01-10 00:10:46 --> Utf8 Class Initialized
INFO - 2018-01-10 00:10:46 --> URI Class Initialized
INFO - 2018-01-10 00:10:46 --> Router Class Initialized
INFO - 2018-01-10 00:10:46 --> Output Class Initialized
INFO - 2018-01-10 00:10:46 --> Security Class Initialized
DEBUG - 2018-01-10 00:10:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-10 00:10:46 --> Input Class Initialized
INFO - 2018-01-10 00:10:46 --> Language Class Initialized
INFO - 2018-01-10 00:10:46 --> Loader Class Initialized
INFO - 2018-01-10 00:10:46 --> Helper loaded: url_helper
INFO - 2018-01-10 00:10:46 --> Helper loaded: form_helper
INFO - 2018-01-10 00:10:46 --> Database Driver Class Initialized
DEBUG - 2018-01-10 00:10:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-10 00:10:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-10 00:10:46 --> Form Validation Class Initialized
INFO - 2018-01-10 00:10:46 --> Model Class Initialized
INFO - 2018-01-10 00:10:46 --> Controller Class Initialized
INFO - 2018-01-10 00:10:46 --> Model Class Initialized
INFO - 2018-01-10 00:10:46 --> Model Class Initialized
INFO - 2018-01-10 00:10:46 --> Model Class Initialized
INFO - 2018-01-10 00:10:46 --> Model Class Initialized
DEBUG - 2018-01-10 00:10:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-10 00:10:46 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-10 00:10:46 --> Final output sent to browser
DEBUG - 2018-01-10 00:10:46 --> Total execution time: 0.1580
INFO - 2018-01-10 00:10:46 --> Config Class Initialized
INFO - 2018-01-10 00:10:46 --> Hooks Class Initialized
INFO - 2018-01-10 00:10:46 --> Config Class Initialized
DEBUG - 2018-01-10 00:10:46 --> UTF-8 Support Enabled
INFO - 2018-01-10 00:10:46 --> Hooks Class Initialized
INFO - 2018-01-10 00:10:46 --> Utf8 Class Initialized
INFO - 2018-01-10 00:10:46 --> URI Class Initialized
DEBUG - 2018-01-10 00:10:46 --> UTF-8 Support Enabled
INFO - 2018-01-10 00:10:46 --> Utf8 Class Initialized
INFO - 2018-01-10 00:10:46 --> Router Class Initialized
INFO - 2018-01-10 00:10:46 --> URI Class Initialized
INFO - 2018-01-10 00:10:46 --> Output Class Initialized
INFO - 2018-01-10 00:10:46 --> Router Class Initialized
INFO - 2018-01-10 00:10:46 --> Security Class Initialized
DEBUG - 2018-01-10 00:10:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-10 00:10:46 --> Output Class Initialized
INFO - 2018-01-10 00:10:46 --> Input Class Initialized
INFO - 2018-01-10 00:10:46 --> Language Class Initialized
INFO - 2018-01-10 00:10:46 --> Security Class Initialized
DEBUG - 2018-01-10 00:10:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-10 00:10:46 --> Input Class Initialized
INFO - 2018-01-10 00:10:46 --> Language Class Initialized
INFO - 2018-01-10 00:10:46 --> Loader Class Initialized
INFO - 2018-01-10 00:10:46 --> Helper loaded: url_helper
INFO - 2018-01-10 00:10:46 --> Loader Class Initialized
INFO - 2018-01-10 00:10:46 --> Helper loaded: form_helper
INFO - 2018-01-10 00:10:46 --> Helper loaded: url_helper
INFO - 2018-01-10 00:10:46 --> Helper loaded: form_helper
INFO - 2018-01-10 00:10:46 --> Database Driver Class Initialized
INFO - 2018-01-10 00:10:46 --> Database Driver Class Initialized
DEBUG - 2018-01-10 00:10:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-10 00:10:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-10 00:10:46 --> Form Validation Class Initialized
INFO - 2018-01-10 00:10:46 --> Model Class Initialized
INFO - 2018-01-10 00:10:46 --> Controller Class Initialized
INFO - 2018-01-10 00:10:46 --> Model Class Initialized
INFO - 2018-01-10 00:10:46 --> Model Class Initialized
INFO - 2018-01-10 00:10:46 --> Model Class Initialized
INFO - 2018-01-10 00:10:46 --> Model Class Initialized
DEBUG - 2018-01-10 00:10:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-01-10 00:10:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-10 00:10:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-10 00:10:46 --> Form Validation Class Initialized
INFO - 2018-01-10 00:10:46 --> Model Class Initialized
INFO - 2018-01-10 00:10:46 --> Controller Class Initialized
INFO - 2018-01-10 00:10:46 --> Model Class Initialized
INFO - 2018-01-10 00:10:46 --> Model Class Initialized
INFO - 2018-01-10 00:10:46 --> Model Class Initialized
INFO - 2018-01-10 00:10:46 --> Model Class Initialized
DEBUG - 2018-01-10 00:10:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-10 00:10:51 --> Config Class Initialized
INFO - 2018-01-10 00:10:51 --> Hooks Class Initialized
DEBUG - 2018-01-10 00:10:51 --> UTF-8 Support Enabled
INFO - 2018-01-10 00:10:51 --> Utf8 Class Initialized
INFO - 2018-01-10 00:10:51 --> URI Class Initialized
INFO - 2018-01-10 00:10:51 --> Router Class Initialized
INFO - 2018-01-10 00:10:51 --> Output Class Initialized
INFO - 2018-01-10 00:10:51 --> Security Class Initialized
DEBUG - 2018-01-10 00:10:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-10 00:10:51 --> Input Class Initialized
INFO - 2018-01-10 00:10:51 --> Language Class Initialized
INFO - 2018-01-10 00:10:51 --> Loader Class Initialized
INFO - 2018-01-10 00:10:51 --> Helper loaded: url_helper
INFO - 2018-01-10 00:10:51 --> Helper loaded: form_helper
INFO - 2018-01-10 00:10:51 --> Database Driver Class Initialized
DEBUG - 2018-01-10 00:10:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-10 00:10:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-10 00:10:51 --> Form Validation Class Initialized
INFO - 2018-01-10 00:10:51 --> Model Class Initialized
INFO - 2018-01-10 00:10:51 --> Controller Class Initialized
INFO - 2018-01-10 00:10:51 --> Model Class Initialized
INFO - 2018-01-10 00:10:51 --> Model Class Initialized
INFO - 2018-01-10 00:10:51 --> Model Class Initialized
INFO - 2018-01-10 00:10:51 --> Model Class Initialized
DEBUG - 2018-01-10 00:10:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-10 00:10:51 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-10 00:10:51 --> Final output sent to browser
DEBUG - 2018-01-10 00:10:51 --> Total execution time: 0.0848
INFO - 2018-01-10 00:10:51 --> Config Class Initialized
INFO - 2018-01-10 00:10:51 --> Hooks Class Initialized
DEBUG - 2018-01-10 00:10:51 --> UTF-8 Support Enabled
INFO - 2018-01-10 00:10:51 --> Utf8 Class Initialized
INFO - 2018-01-10 00:10:51 --> URI Class Initialized
INFO - 2018-01-10 00:10:51 --> Router Class Initialized
INFO - 2018-01-10 00:10:51 --> Output Class Initialized
INFO - 2018-01-10 00:10:51 --> Security Class Initialized
DEBUG - 2018-01-10 00:10:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-10 00:10:51 --> Input Class Initialized
INFO - 2018-01-10 00:10:51 --> Language Class Initialized
INFO - 2018-01-10 00:10:51 --> Loader Class Initialized
INFO - 2018-01-10 00:10:51 --> Helper loaded: url_helper
INFO - 2018-01-10 00:10:51 --> Helper loaded: form_helper
INFO - 2018-01-10 00:10:51 --> Database Driver Class Initialized
DEBUG - 2018-01-10 00:10:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-10 00:10:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-10 00:10:51 --> Form Validation Class Initialized
INFO - 2018-01-10 00:10:51 --> Model Class Initialized
INFO - 2018-01-10 00:10:51 --> Controller Class Initialized
INFO - 2018-01-10 00:10:51 --> Model Class Initialized
INFO - 2018-01-10 00:10:51 --> Model Class Initialized
INFO - 2018-01-10 00:10:51 --> Model Class Initialized
INFO - 2018-01-10 00:10:51 --> Model Class Initialized
DEBUG - 2018-01-10 00:10:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-10 00:10:53 --> Config Class Initialized
INFO - 2018-01-10 00:10:53 --> Hooks Class Initialized
DEBUG - 2018-01-10 00:10:53 --> UTF-8 Support Enabled
INFO - 2018-01-10 00:10:53 --> Utf8 Class Initialized
INFO - 2018-01-10 00:10:53 --> URI Class Initialized
INFO - 2018-01-10 00:10:53 --> Router Class Initialized
INFO - 2018-01-10 00:10:53 --> Output Class Initialized
INFO - 2018-01-10 00:10:53 --> Security Class Initialized
DEBUG - 2018-01-10 00:10:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-10 00:10:53 --> Input Class Initialized
INFO - 2018-01-10 00:10:53 --> Language Class Initialized
INFO - 2018-01-10 00:10:53 --> Loader Class Initialized
INFO - 2018-01-10 00:10:53 --> Helper loaded: url_helper
INFO - 2018-01-10 00:10:53 --> Helper loaded: form_helper
INFO - 2018-01-10 00:10:53 --> Database Driver Class Initialized
DEBUG - 2018-01-10 00:10:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-10 00:10:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-10 00:10:53 --> Form Validation Class Initialized
INFO - 2018-01-10 00:10:53 --> Model Class Initialized
INFO - 2018-01-10 00:10:53 --> Controller Class Initialized
INFO - 2018-01-10 00:10:53 --> Model Class Initialized
INFO - 2018-01-10 00:10:53 --> Model Class Initialized
INFO - 2018-01-10 00:10:53 --> Model Class Initialized
INFO - 2018-01-10 00:10:53 --> Model Class Initialized
DEBUG - 2018-01-10 00:10:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-10 00:10:53 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-10 00:10:53 --> Final output sent to browser
DEBUG - 2018-01-10 00:10:53 --> Total execution time: 0.0855
INFO - 2018-01-10 00:10:53 --> Config Class Initialized
INFO - 2018-01-10 00:10:53 --> Hooks Class Initialized
DEBUG - 2018-01-10 00:10:53 --> UTF-8 Support Enabled
INFO - 2018-01-10 00:10:53 --> Utf8 Class Initialized
INFO - 2018-01-10 00:10:53 --> URI Class Initialized
INFO - 2018-01-10 00:10:53 --> Router Class Initialized
INFO - 2018-01-10 00:10:53 --> Output Class Initialized
INFO - 2018-01-10 00:10:53 --> Security Class Initialized
DEBUG - 2018-01-10 00:10:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-10 00:10:53 --> Input Class Initialized
INFO - 2018-01-10 00:10:53 --> Language Class Initialized
INFO - 2018-01-10 00:10:53 --> Loader Class Initialized
INFO - 2018-01-10 00:10:53 --> Helper loaded: url_helper
INFO - 2018-01-10 00:10:53 --> Helper loaded: form_helper
INFO - 2018-01-10 00:10:53 --> Database Driver Class Initialized
DEBUG - 2018-01-10 00:10:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-10 00:10:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-10 00:10:53 --> Form Validation Class Initialized
INFO - 2018-01-10 00:10:53 --> Model Class Initialized
INFO - 2018-01-10 00:10:53 --> Controller Class Initialized
INFO - 2018-01-10 00:10:53 --> Model Class Initialized
INFO - 2018-01-10 00:10:53 --> Model Class Initialized
INFO - 2018-01-10 00:10:53 --> Model Class Initialized
INFO - 2018-01-10 00:10:53 --> Model Class Initialized
DEBUG - 2018-01-10 00:10:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-10 00:12:34 --> Config Class Initialized
INFO - 2018-01-10 00:12:34 --> Hooks Class Initialized
DEBUG - 2018-01-10 00:12:34 --> UTF-8 Support Enabled
INFO - 2018-01-10 00:12:34 --> Utf8 Class Initialized
INFO - 2018-01-10 00:12:34 --> URI Class Initialized
INFO - 2018-01-10 00:12:34 --> Router Class Initialized
INFO - 2018-01-10 00:12:34 --> Output Class Initialized
INFO - 2018-01-10 00:12:34 --> Security Class Initialized
DEBUG - 2018-01-10 00:12:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-10 00:12:34 --> Input Class Initialized
INFO - 2018-01-10 00:12:34 --> Language Class Initialized
INFO - 2018-01-10 00:12:34 --> Loader Class Initialized
INFO - 2018-01-10 00:12:34 --> Helper loaded: url_helper
INFO - 2018-01-10 00:12:34 --> Helper loaded: form_helper
INFO - 2018-01-10 00:12:34 --> Database Driver Class Initialized
DEBUG - 2018-01-10 00:12:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-10 00:12:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-10 00:12:34 --> Form Validation Class Initialized
INFO - 2018-01-10 00:12:34 --> Model Class Initialized
INFO - 2018-01-10 00:12:34 --> Controller Class Initialized
INFO - 2018-01-10 00:12:34 --> Model Class Initialized
INFO - 2018-01-10 00:12:34 --> Model Class Initialized
INFO - 2018-01-10 00:12:34 --> Model Class Initialized
INFO - 2018-01-10 00:12:34 --> Model Class Initialized
DEBUG - 2018-01-10 00:12:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-10 00:12:34 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-10 00:12:34 --> Final output sent to browser
DEBUG - 2018-01-10 00:12:34 --> Total execution time: 0.4527
INFO - 2018-01-10 00:12:35 --> Config Class Initialized
INFO - 2018-01-10 00:12:35 --> Hooks Class Initialized
DEBUG - 2018-01-10 00:12:35 --> UTF-8 Support Enabled
INFO - 2018-01-10 00:12:35 --> Utf8 Class Initialized
INFO - 2018-01-10 00:12:35 --> URI Class Initialized
INFO - 2018-01-10 00:12:35 --> Router Class Initialized
INFO - 2018-01-10 00:12:35 --> Output Class Initialized
INFO - 2018-01-10 00:12:35 --> Security Class Initialized
DEBUG - 2018-01-10 00:12:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-10 00:12:35 --> Input Class Initialized
INFO - 2018-01-10 00:12:35 --> Language Class Initialized
INFO - 2018-01-10 00:12:35 --> Loader Class Initialized
INFO - 2018-01-10 00:12:35 --> Helper loaded: url_helper
INFO - 2018-01-10 00:12:35 --> Helper loaded: form_helper
INFO - 2018-01-10 00:12:35 --> Database Driver Class Initialized
DEBUG - 2018-01-10 00:12:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-10 00:12:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-10 00:12:35 --> Form Validation Class Initialized
INFO - 2018-01-10 00:12:35 --> Model Class Initialized
INFO - 2018-01-10 00:12:35 --> Controller Class Initialized
INFO - 2018-01-10 00:12:35 --> Model Class Initialized
INFO - 2018-01-10 00:12:35 --> Model Class Initialized
INFO - 2018-01-10 00:12:35 --> Model Class Initialized
INFO - 2018-01-10 00:12:35 --> Model Class Initialized
DEBUG - 2018-01-10 00:12:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-10 00:12:42 --> Config Class Initialized
INFO - 2018-01-10 00:12:42 --> Hooks Class Initialized
DEBUG - 2018-01-10 00:12:42 --> UTF-8 Support Enabled
INFO - 2018-01-10 00:12:42 --> Utf8 Class Initialized
INFO - 2018-01-10 00:12:43 --> URI Class Initialized
INFO - 2018-01-10 00:12:43 --> Router Class Initialized
INFO - 2018-01-10 00:12:43 --> Output Class Initialized
INFO - 2018-01-10 00:12:43 --> Security Class Initialized
DEBUG - 2018-01-10 00:12:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-10 00:12:43 --> Input Class Initialized
INFO - 2018-01-10 00:12:43 --> Language Class Initialized
INFO - 2018-01-10 00:12:43 --> Loader Class Initialized
INFO - 2018-01-10 00:12:43 --> Helper loaded: url_helper
INFO - 2018-01-10 00:12:43 --> Helper loaded: form_helper
INFO - 2018-01-10 00:12:43 --> Database Driver Class Initialized
DEBUG - 2018-01-10 00:12:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-10 00:12:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-10 00:12:43 --> Form Validation Class Initialized
INFO - 2018-01-10 00:12:43 --> Model Class Initialized
INFO - 2018-01-10 00:12:43 --> Controller Class Initialized
INFO - 2018-01-10 00:12:43 --> Model Class Initialized
INFO - 2018-01-10 00:12:43 --> Model Class Initialized
INFO - 2018-01-10 00:12:43 --> Model Class Initialized
INFO - 2018-01-10 00:12:43 --> Model Class Initialized
DEBUG - 2018-01-10 00:12:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-10 00:12:43 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-10 00:12:43 --> Final output sent to browser
DEBUG - 2018-01-10 00:12:43 --> Total execution time: 0.1437
INFO - 2018-01-10 00:12:51 --> Config Class Initialized
INFO - 2018-01-10 00:12:51 --> Hooks Class Initialized
DEBUG - 2018-01-10 00:12:51 --> UTF-8 Support Enabled
INFO - 2018-01-10 00:12:51 --> Utf8 Class Initialized
INFO - 2018-01-10 00:12:51 --> URI Class Initialized
INFO - 2018-01-10 00:12:51 --> Router Class Initialized
INFO - 2018-01-10 00:12:51 --> Output Class Initialized
INFO - 2018-01-10 00:12:51 --> Security Class Initialized
DEBUG - 2018-01-10 00:12:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-10 00:12:51 --> Input Class Initialized
INFO - 2018-01-10 00:12:51 --> Language Class Initialized
INFO - 2018-01-10 00:12:51 --> Loader Class Initialized
INFO - 2018-01-10 00:12:51 --> Helper loaded: url_helper
INFO - 2018-01-10 00:12:51 --> Helper loaded: form_helper
INFO - 2018-01-10 00:12:51 --> Database Driver Class Initialized
DEBUG - 2018-01-10 00:12:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-10 00:12:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-10 00:12:51 --> Form Validation Class Initialized
INFO - 2018-01-10 00:12:51 --> Model Class Initialized
INFO - 2018-01-10 00:12:51 --> Controller Class Initialized
INFO - 2018-01-10 00:12:51 --> Model Class Initialized
INFO - 2018-01-10 00:12:51 --> Model Class Initialized
INFO - 2018-01-10 00:12:51 --> Model Class Initialized
INFO - 2018-01-10 00:12:51 --> Model Class Initialized
DEBUG - 2018-01-10 00:12:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-10 00:12:51 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-10 00:12:51 --> Final output sent to browser
DEBUG - 2018-01-10 00:12:51 --> Total execution time: 0.0843
INFO - 2018-01-10 00:12:51 --> Config Class Initialized
INFO - 2018-01-10 00:12:51 --> Hooks Class Initialized
DEBUG - 2018-01-10 00:12:51 --> UTF-8 Support Enabled
INFO - 2018-01-10 00:12:51 --> Utf8 Class Initialized
INFO - 2018-01-10 00:12:51 --> URI Class Initialized
INFO - 2018-01-10 00:12:51 --> Router Class Initialized
INFO - 2018-01-10 00:12:51 --> Output Class Initialized
INFO - 2018-01-10 00:12:51 --> Security Class Initialized
DEBUG - 2018-01-10 00:12:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-10 00:12:51 --> Input Class Initialized
INFO - 2018-01-10 00:12:51 --> Language Class Initialized
INFO - 2018-01-10 00:12:51 --> Loader Class Initialized
INFO - 2018-01-10 00:12:51 --> Helper loaded: url_helper
INFO - 2018-01-10 00:12:51 --> Helper loaded: form_helper
INFO - 2018-01-10 00:12:51 --> Database Driver Class Initialized
DEBUG - 2018-01-10 00:12:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-10 00:12:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-10 00:12:51 --> Form Validation Class Initialized
INFO - 2018-01-10 00:12:51 --> Model Class Initialized
INFO - 2018-01-10 00:12:51 --> Controller Class Initialized
INFO - 2018-01-10 00:12:51 --> Model Class Initialized
INFO - 2018-01-10 00:12:51 --> Model Class Initialized
INFO - 2018-01-10 00:12:51 --> Model Class Initialized
INFO - 2018-01-10 00:12:51 --> Model Class Initialized
DEBUG - 2018-01-10 00:12:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-10 00:12:56 --> Config Class Initialized
INFO - 2018-01-10 00:12:56 --> Hooks Class Initialized
DEBUG - 2018-01-10 00:12:56 --> UTF-8 Support Enabled
INFO - 2018-01-10 00:12:56 --> Utf8 Class Initialized
INFO - 2018-01-10 00:12:56 --> URI Class Initialized
INFO - 2018-01-10 00:12:56 --> Router Class Initialized
INFO - 2018-01-10 00:12:56 --> Output Class Initialized
INFO - 2018-01-10 00:12:56 --> Security Class Initialized
DEBUG - 2018-01-10 00:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-10 00:12:56 --> Input Class Initialized
INFO - 2018-01-10 00:12:56 --> Language Class Initialized
INFO - 2018-01-10 00:12:56 --> Loader Class Initialized
INFO - 2018-01-10 00:12:56 --> Helper loaded: url_helper
INFO - 2018-01-10 00:12:56 --> Helper loaded: form_helper
INFO - 2018-01-10 00:12:56 --> Database Driver Class Initialized
DEBUG - 2018-01-10 00:12:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-10 00:12:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-10 00:12:56 --> Form Validation Class Initialized
INFO - 2018-01-10 00:12:56 --> Model Class Initialized
INFO - 2018-01-10 00:12:56 --> Controller Class Initialized
INFO - 2018-01-10 00:12:56 --> Model Class Initialized
INFO - 2018-01-10 00:12:56 --> Model Class Initialized
INFO - 2018-01-10 00:12:56 --> Model Class Initialized
INFO - 2018-01-10 00:12:56 --> Model Class Initialized
DEBUG - 2018-01-10 00:12:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-10 00:12:56 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-10 00:12:56 --> Final output sent to browser
DEBUG - 2018-01-10 00:12:56 --> Total execution time: 0.1259
INFO - 2018-01-10 00:12:56 --> Config Class Initialized
INFO - 2018-01-10 00:12:56 --> Hooks Class Initialized
DEBUG - 2018-01-10 00:12:56 --> UTF-8 Support Enabled
INFO - 2018-01-10 00:12:56 --> Utf8 Class Initialized
INFO - 2018-01-10 00:12:56 --> URI Class Initialized
INFO - 2018-01-10 00:12:56 --> Router Class Initialized
INFO - 2018-01-10 00:12:56 --> Output Class Initialized
INFO - 2018-01-10 00:12:56 --> Security Class Initialized
DEBUG - 2018-01-10 00:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-10 00:12:56 --> Input Class Initialized
INFO - 2018-01-10 00:12:56 --> Language Class Initialized
INFO - 2018-01-10 00:12:56 --> Loader Class Initialized
INFO - 2018-01-10 00:12:56 --> Helper loaded: url_helper
INFO - 2018-01-10 00:12:56 --> Helper loaded: form_helper
INFO - 2018-01-10 00:12:56 --> Database Driver Class Initialized
DEBUG - 2018-01-10 00:12:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-10 00:12:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-10 00:12:56 --> Form Validation Class Initialized
INFO - 2018-01-10 00:12:56 --> Model Class Initialized
INFO - 2018-01-10 00:12:56 --> Controller Class Initialized
INFO - 2018-01-10 00:12:56 --> Model Class Initialized
INFO - 2018-01-10 00:12:56 --> Model Class Initialized
INFO - 2018-01-10 00:12:56 --> Model Class Initialized
INFO - 2018-01-10 00:12:56 --> Model Class Initialized
DEBUG - 2018-01-10 00:12:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-10 00:13:05 --> Config Class Initialized
INFO - 2018-01-10 00:13:05 --> Hooks Class Initialized
DEBUG - 2018-01-10 00:13:05 --> UTF-8 Support Enabled
INFO - 2018-01-10 00:13:05 --> Utf8 Class Initialized
INFO - 2018-01-10 00:13:05 --> URI Class Initialized
INFO - 2018-01-10 00:13:05 --> Router Class Initialized
INFO - 2018-01-10 00:13:05 --> Output Class Initialized
INFO - 2018-01-10 00:13:05 --> Security Class Initialized
DEBUG - 2018-01-10 00:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-10 00:13:05 --> Input Class Initialized
INFO - 2018-01-10 00:13:05 --> Language Class Initialized
INFO - 2018-01-10 00:13:05 --> Loader Class Initialized
INFO - 2018-01-10 00:13:05 --> Helper loaded: url_helper
INFO - 2018-01-10 00:13:05 --> Helper loaded: form_helper
INFO - 2018-01-10 00:13:05 --> Database Driver Class Initialized
DEBUG - 2018-01-10 00:13:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-10 00:13:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-10 00:13:05 --> Form Validation Class Initialized
INFO - 2018-01-10 00:13:05 --> Model Class Initialized
INFO - 2018-01-10 00:13:05 --> Controller Class Initialized
INFO - 2018-01-10 00:13:05 --> Model Class Initialized
INFO - 2018-01-10 00:13:05 --> Model Class Initialized
INFO - 2018-01-10 00:13:05 --> Model Class Initialized
INFO - 2018-01-10 00:13:05 --> Model Class Initialized
DEBUG - 2018-01-10 00:13:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-10 00:13:05 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-10 00:13:05 --> Final output sent to browser
DEBUG - 2018-01-10 00:13:05 --> Total execution time: 0.1792
INFO - 2018-01-10 00:13:05 --> Config Class Initialized
INFO - 2018-01-10 00:13:05 --> Hooks Class Initialized
DEBUG - 2018-01-10 00:13:05 --> UTF-8 Support Enabled
INFO - 2018-01-10 00:13:05 --> Utf8 Class Initialized
INFO - 2018-01-10 00:13:05 --> URI Class Initialized
INFO - 2018-01-10 00:13:05 --> Router Class Initialized
INFO - 2018-01-10 00:13:05 --> Output Class Initialized
INFO - 2018-01-10 00:13:05 --> Security Class Initialized
DEBUG - 2018-01-10 00:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-10 00:13:05 --> Input Class Initialized
INFO - 2018-01-10 00:13:05 --> Language Class Initialized
INFO - 2018-01-10 00:13:05 --> Loader Class Initialized
INFO - 2018-01-10 00:13:05 --> Helper loaded: url_helper
INFO - 2018-01-10 00:13:05 --> Helper loaded: form_helper
INFO - 2018-01-10 00:13:05 --> Database Driver Class Initialized
DEBUG - 2018-01-10 00:13:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-10 00:13:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-10 00:13:05 --> Form Validation Class Initialized
INFO - 2018-01-10 00:13:05 --> Model Class Initialized
INFO - 2018-01-10 00:13:05 --> Controller Class Initialized
INFO - 2018-01-10 00:13:05 --> Model Class Initialized
INFO - 2018-01-10 00:13:05 --> Model Class Initialized
INFO - 2018-01-10 00:13:05 --> Model Class Initialized
INFO - 2018-01-10 00:13:05 --> Model Class Initialized
DEBUG - 2018-01-10 00:13:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-10 00:13:27 --> Config Class Initialized
INFO - 2018-01-10 00:13:27 --> Hooks Class Initialized
DEBUG - 2018-01-10 00:13:27 --> UTF-8 Support Enabled
INFO - 2018-01-10 00:13:27 --> Utf8 Class Initialized
INFO - 2018-01-10 00:13:27 --> URI Class Initialized
INFO - 2018-01-10 00:13:27 --> Router Class Initialized
INFO - 2018-01-10 00:13:27 --> Output Class Initialized
INFO - 2018-01-10 00:13:27 --> Security Class Initialized
DEBUG - 2018-01-10 00:13:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-10 00:13:27 --> Input Class Initialized
INFO - 2018-01-10 00:13:27 --> Language Class Initialized
INFO - 2018-01-10 00:13:27 --> Loader Class Initialized
INFO - 2018-01-10 00:13:27 --> Helper loaded: url_helper
INFO - 2018-01-10 00:13:27 --> Helper loaded: form_helper
INFO - 2018-01-10 00:13:27 --> Database Driver Class Initialized
DEBUG - 2018-01-10 00:13:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-10 00:13:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-10 00:13:27 --> Form Validation Class Initialized
INFO - 2018-01-10 00:13:27 --> Model Class Initialized
INFO - 2018-01-10 00:13:27 --> Controller Class Initialized
INFO - 2018-01-10 00:13:27 --> Model Class Initialized
INFO - 2018-01-10 00:13:27 --> Model Class Initialized
INFO - 2018-01-10 00:13:27 --> Model Class Initialized
INFO - 2018-01-10 00:13:27 --> Model Class Initialized
DEBUG - 2018-01-10 00:13:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-10 00:13:27 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-10 00:13:27 --> Final output sent to browser
DEBUG - 2018-01-10 00:13:27 --> Total execution time: 0.1616
INFO - 2018-01-10 00:13:46 --> Config Class Initialized
INFO - 2018-01-10 00:13:46 --> Hooks Class Initialized
DEBUG - 2018-01-10 00:13:46 --> UTF-8 Support Enabled
INFO - 2018-01-10 00:13:46 --> Utf8 Class Initialized
INFO - 2018-01-10 00:13:46 --> URI Class Initialized
INFO - 2018-01-10 00:13:46 --> Router Class Initialized
INFO - 2018-01-10 00:13:46 --> Output Class Initialized
INFO - 2018-01-10 00:13:46 --> Security Class Initialized
DEBUG - 2018-01-10 00:13:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-10 00:13:46 --> Input Class Initialized
INFO - 2018-01-10 00:13:46 --> Language Class Initialized
INFO - 2018-01-10 00:13:46 --> Loader Class Initialized
INFO - 2018-01-10 00:13:46 --> Helper loaded: url_helper
INFO - 2018-01-10 00:13:46 --> Helper loaded: form_helper
INFO - 2018-01-10 00:13:46 --> Database Driver Class Initialized
DEBUG - 2018-01-10 00:13:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-10 00:13:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-10 00:13:46 --> Form Validation Class Initialized
INFO - 2018-01-10 00:13:46 --> Model Class Initialized
INFO - 2018-01-10 00:13:46 --> Controller Class Initialized
INFO - 2018-01-10 00:13:46 --> Model Class Initialized
INFO - 2018-01-10 00:13:46 --> Model Class Initialized
INFO - 2018-01-10 00:13:46 --> Model Class Initialized
INFO - 2018-01-10 00:13:46 --> Model Class Initialized
DEBUG - 2018-01-10 00:13:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-10 00:13:46 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-10 00:13:46 --> Final output sent to browser
DEBUG - 2018-01-10 00:13:46 --> Total execution time: 0.1900
INFO - 2018-01-10 00:13:46 --> Config Class Initialized
INFO - 2018-01-10 00:13:46 --> Hooks Class Initialized
DEBUG - 2018-01-10 00:13:46 --> UTF-8 Support Enabled
INFO - 2018-01-10 00:13:46 --> Utf8 Class Initialized
INFO - 2018-01-10 00:13:46 --> URI Class Initialized
INFO - 2018-01-10 00:13:46 --> Router Class Initialized
INFO - 2018-01-10 00:13:46 --> Output Class Initialized
INFO - 2018-01-10 00:13:46 --> Security Class Initialized
DEBUG - 2018-01-10 00:13:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-10 00:13:46 --> Input Class Initialized
INFO - 2018-01-10 00:13:46 --> Language Class Initialized
INFO - 2018-01-10 00:13:46 --> Loader Class Initialized
INFO - 2018-01-10 00:13:46 --> Helper loaded: url_helper
INFO - 2018-01-10 00:13:46 --> Helper loaded: form_helper
INFO - 2018-01-10 00:13:46 --> Database Driver Class Initialized
DEBUG - 2018-01-10 00:13:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-10 00:13:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-10 00:13:46 --> Form Validation Class Initialized
INFO - 2018-01-10 00:13:47 --> Model Class Initialized
INFO - 2018-01-10 00:13:47 --> Controller Class Initialized
INFO - 2018-01-10 00:13:47 --> Model Class Initialized
INFO - 2018-01-10 00:13:47 --> Model Class Initialized
INFO - 2018-01-10 00:13:47 --> Model Class Initialized
INFO - 2018-01-10 00:13:47 --> Model Class Initialized
DEBUG - 2018-01-10 00:13:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-10 00:13:54 --> Config Class Initialized
INFO - 2018-01-10 00:13:54 --> Hooks Class Initialized
DEBUG - 2018-01-10 00:13:54 --> UTF-8 Support Enabled
INFO - 2018-01-10 00:13:54 --> Utf8 Class Initialized
INFO - 2018-01-10 00:13:54 --> URI Class Initialized
INFO - 2018-01-10 00:13:54 --> Router Class Initialized
INFO - 2018-01-10 00:13:54 --> Output Class Initialized
INFO - 2018-01-10 00:13:54 --> Security Class Initialized
DEBUG - 2018-01-10 00:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-10 00:13:54 --> Input Class Initialized
INFO - 2018-01-10 00:13:54 --> Language Class Initialized
INFO - 2018-01-10 00:13:54 --> Loader Class Initialized
INFO - 2018-01-10 00:13:54 --> Helper loaded: url_helper
INFO - 2018-01-10 00:13:54 --> Helper loaded: form_helper
INFO - 2018-01-10 00:13:54 --> Database Driver Class Initialized
DEBUG - 2018-01-10 00:13:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-10 00:13:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-10 00:13:54 --> Form Validation Class Initialized
INFO - 2018-01-10 00:13:54 --> Model Class Initialized
INFO - 2018-01-10 00:13:54 --> Controller Class Initialized
INFO - 2018-01-10 00:13:54 --> Model Class Initialized
INFO - 2018-01-10 00:13:54 --> Model Class Initialized
INFO - 2018-01-10 00:13:54 --> Model Class Initialized
INFO - 2018-01-10 00:13:54 --> Model Class Initialized
DEBUG - 2018-01-10 00:13:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-10 00:13:54 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-10 00:13:54 --> Final output sent to browser
DEBUG - 2018-01-10 00:13:54 --> Total execution time: 0.1131
INFO - 2018-01-10 00:13:54 --> Config Class Initialized
INFO - 2018-01-10 00:13:54 --> Hooks Class Initialized
DEBUG - 2018-01-10 00:13:54 --> UTF-8 Support Enabled
INFO - 2018-01-10 00:13:54 --> Utf8 Class Initialized
INFO - 2018-01-10 00:13:54 --> URI Class Initialized
INFO - 2018-01-10 00:13:54 --> Router Class Initialized
INFO - 2018-01-10 00:13:54 --> Output Class Initialized
INFO - 2018-01-10 00:13:54 --> Security Class Initialized
DEBUG - 2018-01-10 00:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-10 00:13:54 --> Input Class Initialized
INFO - 2018-01-10 00:13:54 --> Language Class Initialized
INFO - 2018-01-10 00:13:54 --> Loader Class Initialized
INFO - 2018-01-10 00:13:54 --> Helper loaded: url_helper
INFO - 2018-01-10 00:13:54 --> Helper loaded: form_helper
INFO - 2018-01-10 00:13:54 --> Database Driver Class Initialized
DEBUG - 2018-01-10 00:13:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-10 00:13:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-10 00:13:54 --> Form Validation Class Initialized
INFO - 2018-01-10 00:13:54 --> Model Class Initialized
INFO - 2018-01-10 00:13:54 --> Controller Class Initialized
INFO - 2018-01-10 00:13:54 --> Model Class Initialized
INFO - 2018-01-10 00:13:54 --> Model Class Initialized
INFO - 2018-01-10 00:13:54 --> Model Class Initialized
INFO - 2018-01-10 00:13:54 --> Model Class Initialized
DEBUG - 2018-01-10 00:13:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-10 00:14:06 --> Config Class Initialized
INFO - 2018-01-10 00:14:06 --> Hooks Class Initialized
DEBUG - 2018-01-10 00:14:06 --> UTF-8 Support Enabled
INFO - 2018-01-10 00:14:06 --> Utf8 Class Initialized
INFO - 2018-01-10 00:14:06 --> URI Class Initialized
INFO - 2018-01-10 00:14:06 --> Router Class Initialized
INFO - 2018-01-10 00:14:06 --> Output Class Initialized
INFO - 2018-01-10 00:14:06 --> Security Class Initialized
DEBUG - 2018-01-10 00:14:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-10 00:14:06 --> Input Class Initialized
INFO - 2018-01-10 00:14:06 --> Language Class Initialized
INFO - 2018-01-10 00:14:06 --> Loader Class Initialized
INFO - 2018-01-10 00:14:06 --> Helper loaded: url_helper
INFO - 2018-01-10 00:14:06 --> Helper loaded: form_helper
INFO - 2018-01-10 00:14:06 --> Database Driver Class Initialized
DEBUG - 2018-01-10 00:14:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-10 00:14:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-10 00:14:06 --> Form Validation Class Initialized
INFO - 2018-01-10 00:14:06 --> Model Class Initialized
INFO - 2018-01-10 00:14:06 --> Controller Class Initialized
INFO - 2018-01-10 00:14:06 --> Model Class Initialized
INFO - 2018-01-10 00:14:06 --> Model Class Initialized
INFO - 2018-01-10 00:14:06 --> Model Class Initialized
INFO - 2018-01-10 00:14:06 --> Model Class Initialized
DEBUG - 2018-01-10 00:14:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-10 00:14:06 --> Final output sent to browser
DEBUG - 2018-01-10 00:14:06 --> Total execution time: 0.6673
INFO - 2018-01-10 00:15:06 --> Config Class Initialized
INFO - 2018-01-10 00:15:06 --> Hooks Class Initialized
DEBUG - 2018-01-10 00:15:06 --> UTF-8 Support Enabled
INFO - 2018-01-10 00:15:06 --> Utf8 Class Initialized
INFO - 2018-01-10 00:15:06 --> URI Class Initialized
INFO - 2018-01-10 00:15:06 --> Router Class Initialized
INFO - 2018-01-10 00:15:06 --> Output Class Initialized
INFO - 2018-01-10 00:15:06 --> Security Class Initialized
DEBUG - 2018-01-10 00:15:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-10 00:15:06 --> Input Class Initialized
INFO - 2018-01-10 00:15:06 --> Language Class Initialized
INFO - 2018-01-10 00:15:06 --> Loader Class Initialized
INFO - 2018-01-10 00:15:06 --> Helper loaded: url_helper
INFO - 2018-01-10 00:15:06 --> Helper loaded: form_helper
INFO - 2018-01-10 00:15:07 --> Database Driver Class Initialized
DEBUG - 2018-01-10 00:15:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-10 00:15:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-10 00:15:07 --> Form Validation Class Initialized
INFO - 2018-01-10 00:15:07 --> Model Class Initialized
INFO - 2018-01-10 00:15:07 --> Controller Class Initialized
INFO - 2018-01-10 00:15:07 --> Model Class Initialized
DEBUG - 2018-01-10 00:15:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-10 00:15:07 --> Config Class Initialized
INFO - 2018-01-10 00:15:07 --> Hooks Class Initialized
DEBUG - 2018-01-10 00:15:07 --> UTF-8 Support Enabled
INFO - 2018-01-10 00:15:07 --> Utf8 Class Initialized
INFO - 2018-01-10 00:15:07 --> URI Class Initialized
INFO - 2018-01-10 00:15:07 --> Router Class Initialized
INFO - 2018-01-10 00:15:07 --> Output Class Initialized
INFO - 2018-01-10 00:15:07 --> Security Class Initialized
DEBUG - 2018-01-10 00:15:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-10 00:15:07 --> Input Class Initialized
INFO - 2018-01-10 00:15:07 --> Language Class Initialized
INFO - 2018-01-10 00:15:07 --> Loader Class Initialized
INFO - 2018-01-10 00:15:07 --> Helper loaded: url_helper
INFO - 2018-01-10 00:15:07 --> Helper loaded: form_helper
INFO - 2018-01-10 00:15:07 --> Database Driver Class Initialized
DEBUG - 2018-01-10 00:15:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-10 00:15:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-10 00:15:07 --> Form Validation Class Initialized
INFO - 2018-01-10 00:15:07 --> Model Class Initialized
INFO - 2018-01-10 00:15:07 --> Controller Class Initialized
INFO - 2018-01-10 00:15:07 --> Model Class Initialized
DEBUG - 2018-01-10 00:15:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-10 00:15:07 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-10 00:15:07 --> Final output sent to browser
DEBUG - 2018-01-10 00:15:07 --> Total execution time: 0.3703
INFO - 2018-01-10 05:44:39 --> Config Class Initialized
INFO - 2018-01-10 05:44:39 --> Hooks Class Initialized
DEBUG - 2018-01-10 05:44:39 --> UTF-8 Support Enabled
INFO - 2018-01-10 05:44:39 --> Utf8 Class Initialized
INFO - 2018-01-10 05:44:39 --> URI Class Initialized
DEBUG - 2018-01-10 05:44:39 --> No URI present. Default controller set.
INFO - 2018-01-10 05:44:39 --> Router Class Initialized
INFO - 2018-01-10 05:44:39 --> Output Class Initialized
INFO - 2018-01-10 05:44:39 --> Security Class Initialized
DEBUG - 2018-01-10 05:44:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-10 05:44:39 --> Input Class Initialized
INFO - 2018-01-10 05:44:39 --> Language Class Initialized
INFO - 2018-01-10 05:44:39 --> Loader Class Initialized
INFO - 2018-01-10 05:44:39 --> Helper loaded: url_helper
INFO - 2018-01-10 05:44:39 --> Helper loaded: form_helper
INFO - 2018-01-10 05:44:39 --> Database Driver Class Initialized
DEBUG - 2018-01-10 05:44:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-10 05:44:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-10 05:44:39 --> Form Validation Class Initialized
INFO - 2018-01-10 05:44:39 --> Model Class Initialized
INFO - 2018-01-10 05:44:39 --> Controller Class Initialized
INFO - 2018-01-10 05:44:39 --> Config Class Initialized
INFO - 2018-01-10 05:44:39 --> Hooks Class Initialized
DEBUG - 2018-01-10 05:44:39 --> UTF-8 Support Enabled
INFO - 2018-01-10 05:44:39 --> Utf8 Class Initialized
INFO - 2018-01-10 05:44:39 --> Config Class Initialized
INFO - 2018-01-10 05:44:39 --> Hooks Class Initialized
INFO - 2018-01-10 05:44:39 --> URI Class Initialized
INFO - 2018-01-10 05:44:39 --> Router Class Initialized
DEBUG - 2018-01-10 05:44:39 --> UTF-8 Support Enabled
INFO - 2018-01-10 05:44:39 --> Utf8 Class Initialized
INFO - 2018-01-10 05:44:39 --> Output Class Initialized
INFO - 2018-01-10 05:44:39 --> URI Class Initialized
INFO - 2018-01-10 05:44:39 --> Security Class Initialized
INFO - 2018-01-10 05:44:39 --> Router Class Initialized
DEBUG - 2018-01-10 05:44:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-10 05:44:39 --> Input Class Initialized
INFO - 2018-01-10 05:44:39 --> Language Class Initialized
INFO - 2018-01-10 05:44:39 --> Output Class Initialized
INFO - 2018-01-10 05:44:39 --> Security Class Initialized
INFO - 2018-01-10 05:44:39 --> Loader Class Initialized
DEBUG - 2018-01-10 05:44:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-10 05:44:39 --> Input Class Initialized
INFO - 2018-01-10 05:44:39 --> Language Class Initialized
INFO - 2018-01-10 05:44:39 --> Helper loaded: url_helper
INFO - 2018-01-10 05:44:39 --> Helper loaded: form_helper
INFO - 2018-01-10 05:44:39 --> Database Driver Class Initialized
DEBUG - 2018-01-10 05:44:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-10 05:44:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-10 05:44:39 --> Form Validation Class Initialized
INFO - 2018-01-10 05:44:39 --> Model Class Initialized
INFO - 2018-01-10 05:44:39 --> Controller Class Initialized
INFO - 2018-01-10 05:44:39 --> Model Class Initialized
DEBUG - 2018-01-10 05:44:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-10 05:44:39 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-10 05:44:39 --> Final output sent to browser
DEBUG - 2018-01-10 05:44:39 --> Total execution time: 0.0376
ERROR - 2018-01-10 05:44:39 --> 404 Page Not Found: Faviconico/index
INFO - 2018-01-10 05:44:40 --> Config Class Initialized
INFO - 2018-01-10 05:44:40 --> Hooks Class Initialized
DEBUG - 2018-01-10 05:44:40 --> UTF-8 Support Enabled
INFO - 2018-01-10 05:44:40 --> Utf8 Class Initialized
INFO - 2018-01-10 05:44:40 --> URI Class Initialized
INFO - 2018-01-10 05:44:40 --> Router Class Initialized
INFO - 2018-01-10 05:44:40 --> Output Class Initialized
INFO - 2018-01-10 05:44:40 --> Security Class Initialized
DEBUG - 2018-01-10 05:44:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-10 05:44:40 --> Input Class Initialized
INFO - 2018-01-10 05:44:40 --> Language Class Initialized
ERROR - 2018-01-10 05:44:40 --> 404 Page Not Found: Faviconico/index
INFO - 2018-01-10 05:44:41 --> Config Class Initialized
INFO - 2018-01-10 05:44:41 --> Hooks Class Initialized
DEBUG - 2018-01-10 05:44:41 --> UTF-8 Support Enabled
INFO - 2018-01-10 05:44:41 --> Utf8 Class Initialized
INFO - 2018-01-10 05:44:41 --> URI Class Initialized
INFO - 2018-01-10 05:44:41 --> Router Class Initialized
INFO - 2018-01-10 05:44:41 --> Output Class Initialized
INFO - 2018-01-10 05:44:41 --> Security Class Initialized
DEBUG - 2018-01-10 05:44:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-10 05:44:41 --> Input Class Initialized
INFO - 2018-01-10 05:44:41 --> Language Class Initialized
INFO - 2018-01-10 05:44:41 --> Loader Class Initialized
INFO - 2018-01-10 05:44:41 --> Helper loaded: url_helper
INFO - 2018-01-10 05:44:41 --> Helper loaded: form_helper
INFO - 2018-01-10 05:44:41 --> Database Driver Class Initialized
DEBUG - 2018-01-10 05:44:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-10 05:44:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-10 05:44:41 --> Form Validation Class Initialized
INFO - 2018-01-10 05:44:41 --> Model Class Initialized
INFO - 2018-01-10 05:44:41 --> Controller Class Initialized
INFO - 2018-01-10 05:44:41 --> Model Class Initialized
DEBUG - 2018-01-10 05:44:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-10 05:44:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-01-10 05:44:41 --> Config Class Initialized
INFO - 2018-01-10 05:44:41 --> Hooks Class Initialized
DEBUG - 2018-01-10 05:44:41 --> UTF-8 Support Enabled
INFO - 2018-01-10 05:44:41 --> Utf8 Class Initialized
INFO - 2018-01-10 05:44:41 --> URI Class Initialized
DEBUG - 2018-01-10 05:44:41 --> No URI present. Default controller set.
INFO - 2018-01-10 05:44:41 --> Router Class Initialized
INFO - 2018-01-10 05:44:41 --> Output Class Initialized
INFO - 2018-01-10 05:44:41 --> Security Class Initialized
DEBUG - 2018-01-10 05:44:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-10 05:44:41 --> Input Class Initialized
INFO - 2018-01-10 05:44:41 --> Language Class Initialized
INFO - 2018-01-10 05:44:41 --> Loader Class Initialized
INFO - 2018-01-10 05:44:41 --> Helper loaded: url_helper
INFO - 2018-01-10 05:44:41 --> Helper loaded: form_helper
INFO - 2018-01-10 05:44:41 --> Database Driver Class Initialized
DEBUG - 2018-01-10 05:44:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-10 05:44:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-10 05:44:41 --> Form Validation Class Initialized
INFO - 2018-01-10 05:44:41 --> Model Class Initialized
INFO - 2018-01-10 05:44:41 --> Controller Class Initialized
INFO - 2018-01-10 05:44:41 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-10 05:44:41 --> Final output sent to browser
DEBUG - 2018-01-10 05:44:41 --> Total execution time: 0.0446
INFO - 2018-01-10 05:44:42 --> Config Class Initialized
INFO - 2018-01-10 05:44:42 --> Hooks Class Initialized
DEBUG - 2018-01-10 05:44:42 --> UTF-8 Support Enabled
INFO - 2018-01-10 05:44:42 --> Utf8 Class Initialized
INFO - 2018-01-10 05:44:42 --> URI Class Initialized
INFO - 2018-01-10 05:44:42 --> Router Class Initialized
INFO - 2018-01-10 05:44:42 --> Output Class Initialized
INFO - 2018-01-10 05:44:42 --> Security Class Initialized
DEBUG - 2018-01-10 05:44:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-10 05:44:42 --> Input Class Initialized
INFO - 2018-01-10 05:44:42 --> Language Class Initialized
INFO - 2018-01-10 05:44:42 --> Loader Class Initialized
INFO - 2018-01-10 05:44:42 --> Helper loaded: url_helper
INFO - 2018-01-10 05:44:42 --> Helper loaded: form_helper
INFO - 2018-01-10 05:44:42 --> Database Driver Class Initialized
DEBUG - 2018-01-10 05:44:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-10 05:44:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-10 05:44:42 --> Form Validation Class Initialized
INFO - 2018-01-10 05:44:42 --> Model Class Initialized
INFO - 2018-01-10 05:44:42 --> Controller Class Initialized
INFO - 2018-01-10 05:44:42 --> Model Class Initialized
INFO - 2018-01-10 05:44:42 --> Model Class Initialized
INFO - 2018-01-10 05:44:42 --> Model Class Initialized
INFO - 2018-01-10 05:44:42 --> Model Class Initialized
DEBUG - 2018-01-10 05:44:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-10 05:44:47 --> Config Class Initialized
INFO - 2018-01-10 05:44:47 --> Hooks Class Initialized
DEBUG - 2018-01-10 05:44:47 --> UTF-8 Support Enabled
INFO - 2018-01-10 05:44:47 --> Utf8 Class Initialized
INFO - 2018-01-10 05:44:47 --> URI Class Initialized
INFO - 2018-01-10 05:44:47 --> Router Class Initialized
INFO - 2018-01-10 05:44:47 --> Output Class Initialized
INFO - 2018-01-10 05:44:47 --> Security Class Initialized
DEBUG - 2018-01-10 05:44:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-10 05:44:47 --> Input Class Initialized
INFO - 2018-01-10 05:44:47 --> Language Class Initialized
INFO - 2018-01-10 05:44:47 --> Loader Class Initialized
INFO - 2018-01-10 05:44:47 --> Helper loaded: url_helper
INFO - 2018-01-10 05:44:47 --> Helper loaded: form_helper
INFO - 2018-01-10 05:44:47 --> Database Driver Class Initialized
DEBUG - 2018-01-10 05:44:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-10 05:44:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-10 05:44:47 --> Form Validation Class Initialized
INFO - 2018-01-10 05:44:47 --> Model Class Initialized
INFO - 2018-01-10 05:44:47 --> Controller Class Initialized
INFO - 2018-01-10 05:44:47 --> Model Class Initialized
INFO - 2018-01-10 05:44:47 --> Model Class Initialized
INFO - 2018-01-10 05:44:47 --> Model Class Initialized
INFO - 2018-01-10 05:44:47 --> Model Class Initialized
DEBUG - 2018-01-10 05:44:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-10 05:44:47 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-10 05:44:47 --> Final output sent to browser
DEBUG - 2018-01-10 05:44:47 --> Total execution time: 0.1098
INFO - 2018-01-10 05:44:47 --> Config Class Initialized
INFO - 2018-01-10 05:44:47 --> Hooks Class Initialized
DEBUG - 2018-01-10 05:44:47 --> UTF-8 Support Enabled
INFO - 2018-01-10 05:44:47 --> Utf8 Class Initialized
INFO - 2018-01-10 05:44:47 --> URI Class Initialized
INFO - 2018-01-10 05:44:47 --> Router Class Initialized
INFO - 2018-01-10 05:44:47 --> Output Class Initialized
INFO - 2018-01-10 05:44:47 --> Security Class Initialized
DEBUG - 2018-01-10 05:44:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-10 05:44:47 --> Input Class Initialized
INFO - 2018-01-10 05:44:47 --> Language Class Initialized
INFO - 2018-01-10 05:44:47 --> Loader Class Initialized
INFO - 2018-01-10 05:44:47 --> Helper loaded: url_helper
INFO - 2018-01-10 05:44:47 --> Helper loaded: form_helper
INFO - 2018-01-10 05:44:47 --> Database Driver Class Initialized
DEBUG - 2018-01-10 05:44:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-10 05:44:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-10 05:44:47 --> Form Validation Class Initialized
INFO - 2018-01-10 05:44:47 --> Model Class Initialized
INFO - 2018-01-10 05:44:47 --> Controller Class Initialized
INFO - 2018-01-10 05:44:47 --> Model Class Initialized
INFO - 2018-01-10 05:44:47 --> Model Class Initialized
INFO - 2018-01-10 05:44:47 --> Model Class Initialized
INFO - 2018-01-10 05:44:47 --> Model Class Initialized
DEBUG - 2018-01-10 05:44:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-10 05:44:53 --> Config Class Initialized
INFO - 2018-01-10 05:44:53 --> Hooks Class Initialized
DEBUG - 2018-01-10 05:44:53 --> UTF-8 Support Enabled
INFO - 2018-01-10 05:44:53 --> Utf8 Class Initialized
INFO - 2018-01-10 05:44:53 --> URI Class Initialized
INFO - 2018-01-10 05:44:53 --> Router Class Initialized
INFO - 2018-01-10 05:44:53 --> Output Class Initialized
INFO - 2018-01-10 05:44:53 --> Security Class Initialized
DEBUG - 2018-01-10 05:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-10 05:44:53 --> Input Class Initialized
INFO - 2018-01-10 05:44:53 --> Language Class Initialized
INFO - 2018-01-10 05:44:53 --> Loader Class Initialized
INFO - 2018-01-10 05:44:53 --> Helper loaded: url_helper
INFO - 2018-01-10 05:44:53 --> Helper loaded: form_helper
INFO - 2018-01-10 05:44:53 --> Database Driver Class Initialized
DEBUG - 2018-01-10 05:44:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-10 05:44:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-10 05:44:53 --> Form Validation Class Initialized
INFO - 2018-01-10 05:44:53 --> Model Class Initialized
INFO - 2018-01-10 05:44:53 --> Controller Class Initialized
INFO - 2018-01-10 05:44:53 --> Model Class Initialized
INFO - 2018-01-10 05:44:53 --> Model Class Initialized
INFO - 2018-01-10 05:44:53 --> Model Class Initialized
INFO - 2018-01-10 05:44:53 --> Model Class Initialized
DEBUG - 2018-01-10 05:44:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-10 05:44:53 --> Final output sent to browser
DEBUG - 2018-01-10 05:44:53 --> Total execution time: 0.2459
INFO - 2018-01-10 05:45:03 --> Config Class Initialized
INFO - 2018-01-10 05:45:03 --> Hooks Class Initialized
DEBUG - 2018-01-10 05:45:03 --> UTF-8 Support Enabled
INFO - 2018-01-10 05:45:03 --> Utf8 Class Initialized
INFO - 2018-01-10 05:45:03 --> URI Class Initialized
INFO - 2018-01-10 05:45:03 --> Router Class Initialized
INFO - 2018-01-10 05:45:03 --> Output Class Initialized
INFO - 2018-01-10 05:45:03 --> Security Class Initialized
DEBUG - 2018-01-10 05:45:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-10 05:45:03 --> Input Class Initialized
INFO - 2018-01-10 05:45:03 --> Language Class Initialized
INFO - 2018-01-10 05:45:03 --> Loader Class Initialized
INFO - 2018-01-10 05:45:03 --> Helper loaded: url_helper
INFO - 2018-01-10 05:45:03 --> Helper loaded: form_helper
INFO - 2018-01-10 05:45:03 --> Database Driver Class Initialized
DEBUG - 2018-01-10 05:45:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-10 05:45:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-10 05:45:03 --> Form Validation Class Initialized
INFO - 2018-01-10 05:45:03 --> Model Class Initialized
INFO - 2018-01-10 05:45:03 --> Controller Class Initialized
INFO - 2018-01-10 05:45:03 --> Model Class Initialized
INFO - 2018-01-10 05:45:03 --> Model Class Initialized
INFO - 2018-01-10 05:45:03 --> Model Class Initialized
INFO - 2018-01-10 05:45:03 --> Model Class Initialized
DEBUG - 2018-01-10 05:45:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-10 05:45:03 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-10 05:45:03 --> Final output sent to browser
DEBUG - 2018-01-10 05:45:03 --> Total execution time: 0.1018
INFO - 2018-01-10 05:45:03 --> Config Class Initialized
INFO - 2018-01-10 05:45:03 --> Hooks Class Initialized
DEBUG - 2018-01-10 05:45:03 --> UTF-8 Support Enabled
INFO - 2018-01-10 05:45:03 --> Utf8 Class Initialized
INFO - 2018-01-10 05:45:03 --> URI Class Initialized
INFO - 2018-01-10 05:45:03 --> Router Class Initialized
INFO - 2018-01-10 05:45:03 --> Output Class Initialized
INFO - 2018-01-10 05:45:03 --> Security Class Initialized
DEBUG - 2018-01-10 05:45:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-10 05:45:03 --> Input Class Initialized
INFO - 2018-01-10 05:45:03 --> Language Class Initialized
INFO - 2018-01-10 05:45:03 --> Loader Class Initialized
INFO - 2018-01-10 05:45:03 --> Helper loaded: url_helper
INFO - 2018-01-10 05:45:03 --> Helper loaded: form_helper
INFO - 2018-01-10 05:45:03 --> Database Driver Class Initialized
DEBUG - 2018-01-10 05:45:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-10 05:45:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-10 05:45:03 --> Form Validation Class Initialized
INFO - 2018-01-10 05:45:03 --> Model Class Initialized
INFO - 2018-01-10 05:45:03 --> Controller Class Initialized
INFO - 2018-01-10 05:45:03 --> Model Class Initialized
INFO - 2018-01-10 05:45:03 --> Model Class Initialized
INFO - 2018-01-10 05:45:03 --> Model Class Initialized
INFO - 2018-01-10 05:45:03 --> Model Class Initialized
DEBUG - 2018-01-10 05:45:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-10 05:45:17 --> Config Class Initialized
INFO - 2018-01-10 05:45:17 --> Hooks Class Initialized
DEBUG - 2018-01-10 05:45:17 --> UTF-8 Support Enabled
INFO - 2018-01-10 05:45:17 --> Utf8 Class Initialized
INFO - 2018-01-10 05:45:17 --> URI Class Initialized
INFO - 2018-01-10 05:45:17 --> Router Class Initialized
INFO - 2018-01-10 05:45:17 --> Output Class Initialized
INFO - 2018-01-10 05:45:17 --> Security Class Initialized
DEBUG - 2018-01-10 05:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-10 05:45:17 --> Input Class Initialized
INFO - 2018-01-10 05:45:17 --> Language Class Initialized
INFO - 2018-01-10 05:45:17 --> Loader Class Initialized
INFO - 2018-01-10 05:45:17 --> Helper loaded: url_helper
INFO - 2018-01-10 05:45:17 --> Helper loaded: form_helper
INFO - 2018-01-10 05:45:17 --> Database Driver Class Initialized
DEBUG - 2018-01-10 05:45:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-10 05:45:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-10 05:45:17 --> Form Validation Class Initialized
INFO - 2018-01-10 05:45:17 --> Model Class Initialized
INFO - 2018-01-10 05:45:17 --> Controller Class Initialized
INFO - 2018-01-10 05:45:17 --> Model Class Initialized
INFO - 2018-01-10 05:45:17 --> Model Class Initialized
INFO - 2018-01-10 05:45:17 --> Model Class Initialized
INFO - 2018-01-10 05:45:17 --> Model Class Initialized
DEBUG - 2018-01-10 05:45:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-10 05:45:17 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-10 05:45:17 --> Final output sent to browser
DEBUG - 2018-01-10 05:45:17 --> Total execution time: 0.1441
INFO - 2018-01-10 05:45:17 --> Config Class Initialized
INFO - 2018-01-10 05:45:17 --> Config Class Initialized
INFO - 2018-01-10 05:45:17 --> Hooks Class Initialized
INFO - 2018-01-10 05:45:17 --> Hooks Class Initialized
DEBUG - 2018-01-10 05:45:17 --> UTF-8 Support Enabled
INFO - 2018-01-10 05:45:17 --> Utf8 Class Initialized
DEBUG - 2018-01-10 05:45:17 --> UTF-8 Support Enabled
INFO - 2018-01-10 05:45:17 --> Utf8 Class Initialized
INFO - 2018-01-10 05:45:17 --> URI Class Initialized
INFO - 2018-01-10 05:45:17 --> URI Class Initialized
INFO - 2018-01-10 05:45:17 --> Router Class Initialized
INFO - 2018-01-10 05:45:17 --> Router Class Initialized
INFO - 2018-01-10 05:45:17 --> Output Class Initialized
INFO - 2018-01-10 05:45:17 --> Security Class Initialized
INFO - 2018-01-10 05:45:17 --> Output Class Initialized
INFO - 2018-01-10 05:45:17 --> Security Class Initialized
DEBUG - 2018-01-10 05:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-10 05:45:17 --> Input Class Initialized
INFO - 2018-01-10 05:45:17 --> Language Class Initialized
DEBUG - 2018-01-10 05:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-10 05:45:17 --> Input Class Initialized
INFO - 2018-01-10 05:45:17 --> Language Class Initialized
INFO - 2018-01-10 05:45:17 --> Loader Class Initialized
INFO - 2018-01-10 05:45:17 --> Loader Class Initialized
INFO - 2018-01-10 05:45:17 --> Helper loaded: url_helper
INFO - 2018-01-10 05:45:17 --> Helper loaded: url_helper
INFO - 2018-01-10 05:45:17 --> Helper loaded: form_helper
INFO - 2018-01-10 05:45:17 --> Helper loaded: form_helper
INFO - 2018-01-10 05:45:18 --> Database Driver Class Initialized
INFO - 2018-01-10 05:45:18 --> Database Driver Class Initialized
DEBUG - 2018-01-10 05:45:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-10 05:45:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-10 05:45:18 --> Form Validation Class Initialized
INFO - 2018-01-10 05:45:18 --> Model Class Initialized
INFO - 2018-01-10 05:45:18 --> Controller Class Initialized
INFO - 2018-01-10 05:45:18 --> Model Class Initialized
INFO - 2018-01-10 05:45:18 --> Model Class Initialized
INFO - 2018-01-10 05:45:18 --> Model Class Initialized
INFO - 2018-01-10 05:45:18 --> Model Class Initialized
DEBUG - 2018-01-10 05:45:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-01-10 05:45:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-10 05:45:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-10 05:45:18 --> Form Validation Class Initialized
INFO - 2018-01-10 05:45:18 --> Model Class Initialized
INFO - 2018-01-10 05:45:18 --> Controller Class Initialized
INFO - 2018-01-10 05:45:18 --> Model Class Initialized
INFO - 2018-01-10 05:45:18 --> Model Class Initialized
INFO - 2018-01-10 05:45:18 --> Model Class Initialized
INFO - 2018-01-10 05:45:18 --> Model Class Initialized
DEBUG - 2018-01-10 05:45:18 --> Form_validation class already loaded. Second attempt ignored.
