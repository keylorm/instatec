<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-12-24 18:51:01 --> Config Class Initialized
INFO - 2017-12-24 18:51:01 --> Hooks Class Initialized
DEBUG - 2017-12-24 18:51:01 --> UTF-8 Support Enabled
INFO - 2017-12-24 18:51:01 --> Utf8 Class Initialized
INFO - 2017-12-24 18:51:01 --> URI Class Initialized
INFO - 2017-12-24 18:51:01 --> Router Class Initialized
INFO - 2017-12-24 18:51:01 --> Output Class Initialized
INFO - 2017-12-24 18:51:01 --> Security Class Initialized
DEBUG - 2017-12-24 18:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-24 18:51:01 --> Input Class Initialized
INFO - 2017-12-24 18:51:01 --> Language Class Initialized
INFO - 2017-12-24 18:51:01 --> Loader Class Initialized
INFO - 2017-12-24 18:51:01 --> Helper loaded: url_helper
INFO - 2017-12-24 18:51:01 --> Helper loaded: form_helper
INFO - 2017-12-24 18:51:01 --> Database Driver Class Initialized
DEBUG - 2017-12-24 18:51:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-24 18:51:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-24 18:51:01 --> Form Validation Class Initialized
INFO - 2017-12-24 18:51:01 --> Model Class Initialized
INFO - 2017-12-24 18:51:01 --> Controller Class Initialized
INFO - 2017-12-24 18:51:01 --> Model Class Initialized
INFO - 2017-12-24 18:51:01 --> Model Class Initialized
INFO - 2017-12-24 18:51:01 --> Model Class Initialized
DEBUG - 2017-12-24 18:51:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-24 18:51:01 --> Config Class Initialized
INFO - 2017-12-24 18:51:01 --> Hooks Class Initialized
DEBUG - 2017-12-24 18:51:01 --> UTF-8 Support Enabled
INFO - 2017-12-24 18:51:01 --> Utf8 Class Initialized
INFO - 2017-12-24 18:51:01 --> URI Class Initialized
INFO - 2017-12-24 18:51:01 --> Router Class Initialized
INFO - 2017-12-24 18:51:01 --> Output Class Initialized
INFO - 2017-12-24 18:51:01 --> Security Class Initialized
DEBUG - 2017-12-24 18:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-24 18:51:01 --> Input Class Initialized
INFO - 2017-12-24 18:51:01 --> Language Class Initialized
INFO - 2017-12-24 18:51:02 --> Loader Class Initialized
INFO - 2017-12-24 18:51:02 --> Helper loaded: url_helper
INFO - 2017-12-24 18:51:02 --> Helper loaded: form_helper
INFO - 2017-12-24 18:51:02 --> Database Driver Class Initialized
DEBUG - 2017-12-24 18:51:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-24 18:51:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-24 18:51:02 --> Form Validation Class Initialized
INFO - 2017-12-24 18:51:02 --> Model Class Initialized
INFO - 2017-12-24 18:51:02 --> Controller Class Initialized
INFO - 2017-12-24 18:51:02 --> Model Class Initialized
DEBUG - 2017-12-24 18:51:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-24 18:51:02 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-24 18:51:02 --> Final output sent to browser
DEBUG - 2017-12-24 18:51:02 --> Total execution time: 0.1565
INFO - 2017-12-24 18:51:03 --> Config Class Initialized
INFO - 2017-12-24 18:51:03 --> Hooks Class Initialized
DEBUG - 2017-12-24 18:51:03 --> UTF-8 Support Enabled
INFO - 2017-12-24 18:51:03 --> Utf8 Class Initialized
INFO - 2017-12-24 18:51:03 --> URI Class Initialized
INFO - 2017-12-24 18:51:03 --> Router Class Initialized
INFO - 2017-12-24 18:51:03 --> Output Class Initialized
INFO - 2017-12-24 18:51:03 --> Security Class Initialized
DEBUG - 2017-12-24 18:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-24 18:51:03 --> Input Class Initialized
INFO - 2017-12-24 18:51:03 --> Language Class Initialized
INFO - 2017-12-24 18:51:03 --> Loader Class Initialized
INFO - 2017-12-24 18:51:03 --> Helper loaded: url_helper
INFO - 2017-12-24 18:51:03 --> Helper loaded: form_helper
INFO - 2017-12-24 18:51:03 --> Database Driver Class Initialized
DEBUG - 2017-12-24 18:51:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-24 18:51:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-24 18:51:03 --> Form Validation Class Initialized
INFO - 2017-12-24 18:51:03 --> Model Class Initialized
INFO - 2017-12-24 18:51:03 --> Controller Class Initialized
INFO - 2017-12-24 18:51:03 --> Model Class Initialized
DEBUG - 2017-12-24 18:51:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-24 18:51:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-12-24 18:51:03 --> Config Class Initialized
INFO - 2017-12-24 18:51:03 --> Hooks Class Initialized
DEBUG - 2017-12-24 18:51:03 --> UTF-8 Support Enabled
INFO - 2017-12-24 18:51:03 --> Utf8 Class Initialized
INFO - 2017-12-24 18:51:03 --> URI Class Initialized
DEBUG - 2017-12-24 18:51:03 --> No URI present. Default controller set.
INFO - 2017-12-24 18:51:03 --> Router Class Initialized
INFO - 2017-12-24 18:51:03 --> Output Class Initialized
INFO - 2017-12-24 18:51:03 --> Security Class Initialized
DEBUG - 2017-12-24 18:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-24 18:51:03 --> Input Class Initialized
INFO - 2017-12-24 18:51:03 --> Language Class Initialized
INFO - 2017-12-24 18:51:03 --> Loader Class Initialized
INFO - 2017-12-24 18:51:03 --> Helper loaded: url_helper
INFO - 2017-12-24 18:51:03 --> Helper loaded: form_helper
INFO - 2017-12-24 18:51:03 --> Database Driver Class Initialized
DEBUG - 2017-12-24 18:51:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-24 18:51:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-24 18:51:03 --> Form Validation Class Initialized
INFO - 2017-12-24 18:51:03 --> Model Class Initialized
INFO - 2017-12-24 18:51:03 --> Controller Class Initialized
INFO - 2017-12-24 18:51:03 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-24 18:51:03 --> Final output sent to browser
DEBUG - 2017-12-24 18:51:03 --> Total execution time: 0.0556
INFO - 2017-12-24 18:51:05 --> Config Class Initialized
INFO - 2017-12-24 18:51:05 --> Hooks Class Initialized
DEBUG - 2017-12-24 18:51:05 --> UTF-8 Support Enabled
INFO - 2017-12-24 18:51:05 --> Utf8 Class Initialized
INFO - 2017-12-24 18:51:05 --> URI Class Initialized
INFO - 2017-12-24 18:51:05 --> Router Class Initialized
INFO - 2017-12-24 18:51:05 --> Output Class Initialized
INFO - 2017-12-24 18:51:05 --> Security Class Initialized
DEBUG - 2017-12-24 18:51:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-24 18:51:05 --> Input Class Initialized
INFO - 2017-12-24 18:51:05 --> Language Class Initialized
INFO - 2017-12-24 18:51:05 --> Loader Class Initialized
INFO - 2017-12-24 18:51:05 --> Helper loaded: url_helper
INFO - 2017-12-24 18:51:05 --> Helper loaded: form_helper
INFO - 2017-12-24 18:51:05 --> Database Driver Class Initialized
DEBUG - 2017-12-24 18:51:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-24 18:51:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-24 18:51:05 --> Form Validation Class Initialized
INFO - 2017-12-24 18:51:05 --> Model Class Initialized
INFO - 2017-12-24 18:51:05 --> Controller Class Initialized
INFO - 2017-12-24 18:51:05 --> Model Class Initialized
INFO - 2017-12-24 18:51:05 --> Model Class Initialized
INFO - 2017-12-24 18:51:05 --> Model Class Initialized
DEBUG - 2017-12-24 18:51:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-24 18:51:05 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-24 18:51:05 --> Final output sent to browser
DEBUG - 2017-12-24 18:51:05 --> Total execution time: 0.0667
INFO - 2017-12-24 18:51:05 --> Config Class Initialized
INFO - 2017-12-24 18:51:05 --> Hooks Class Initialized
DEBUG - 2017-12-24 18:51:05 --> UTF-8 Support Enabled
INFO - 2017-12-24 18:51:05 --> Utf8 Class Initialized
INFO - 2017-12-24 18:51:05 --> URI Class Initialized
INFO - 2017-12-24 18:51:05 --> Router Class Initialized
INFO - 2017-12-24 18:51:05 --> Output Class Initialized
INFO - 2017-12-24 18:51:05 --> Security Class Initialized
DEBUG - 2017-12-24 18:51:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-24 18:51:05 --> Input Class Initialized
INFO - 2017-12-24 18:51:05 --> Language Class Initialized
INFO - 2017-12-24 18:51:05 --> Loader Class Initialized
INFO - 2017-12-24 18:51:05 --> Helper loaded: url_helper
INFO - 2017-12-24 18:51:05 --> Helper loaded: form_helper
INFO - 2017-12-24 18:51:05 --> Database Driver Class Initialized
DEBUG - 2017-12-24 18:51:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-24 18:51:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-24 18:51:05 --> Form Validation Class Initialized
INFO - 2017-12-24 18:51:05 --> Model Class Initialized
INFO - 2017-12-24 18:51:05 --> Controller Class Initialized
INFO - 2017-12-24 18:51:05 --> Model Class Initialized
INFO - 2017-12-24 18:51:05 --> Model Class Initialized
INFO - 2017-12-24 18:51:05 --> Model Class Initialized
DEBUG - 2017-12-24 18:51:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-24 18:51:08 --> Config Class Initialized
INFO - 2017-12-24 18:51:08 --> Hooks Class Initialized
DEBUG - 2017-12-24 18:51:08 --> UTF-8 Support Enabled
INFO - 2017-12-24 18:51:08 --> Utf8 Class Initialized
INFO - 2017-12-24 18:51:08 --> URI Class Initialized
INFO - 2017-12-24 18:51:08 --> Router Class Initialized
INFO - 2017-12-24 18:51:08 --> Output Class Initialized
INFO - 2017-12-24 18:51:08 --> Security Class Initialized
DEBUG - 2017-12-24 18:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-24 18:51:08 --> Input Class Initialized
INFO - 2017-12-24 18:51:08 --> Language Class Initialized
INFO - 2017-12-24 18:51:08 --> Loader Class Initialized
INFO - 2017-12-24 18:51:08 --> Helper loaded: url_helper
INFO - 2017-12-24 18:51:08 --> Helper loaded: form_helper
INFO - 2017-12-24 18:51:08 --> Database Driver Class Initialized
DEBUG - 2017-12-24 18:51:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-24 18:51:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-24 18:51:08 --> Form Validation Class Initialized
INFO - 2017-12-24 18:51:08 --> Model Class Initialized
INFO - 2017-12-24 18:51:08 --> Controller Class Initialized
INFO - 2017-12-24 18:51:08 --> Model Class Initialized
INFO - 2017-12-24 18:51:08 --> Model Class Initialized
INFO - 2017-12-24 18:51:08 --> Model Class Initialized
DEBUG - 2017-12-24 18:51:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-24 18:51:08 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-24 18:51:08 --> Final output sent to browser
DEBUG - 2017-12-24 18:51:08 --> Total execution time: 0.0689
INFO - 2017-12-24 18:51:08 --> Config Class Initialized
INFO - 2017-12-24 18:51:08 --> Hooks Class Initialized
DEBUG - 2017-12-24 18:51:08 --> UTF-8 Support Enabled
INFO - 2017-12-24 18:51:08 --> Utf8 Class Initialized
INFO - 2017-12-24 18:51:08 --> URI Class Initialized
INFO - 2017-12-24 18:51:08 --> Router Class Initialized
INFO - 2017-12-24 18:51:08 --> Output Class Initialized
INFO - 2017-12-24 18:51:08 --> Security Class Initialized
DEBUG - 2017-12-24 18:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-24 18:51:08 --> Input Class Initialized
INFO - 2017-12-24 18:51:08 --> Language Class Initialized
INFO - 2017-12-24 18:51:08 --> Loader Class Initialized
INFO - 2017-12-24 18:51:08 --> Helper loaded: url_helper
INFO - 2017-12-24 18:51:08 --> Helper loaded: form_helper
INFO - 2017-12-24 18:51:08 --> Database Driver Class Initialized
DEBUG - 2017-12-24 18:51:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-24 18:51:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-24 18:51:08 --> Form Validation Class Initialized
INFO - 2017-12-24 18:51:08 --> Model Class Initialized
INFO - 2017-12-24 18:51:08 --> Controller Class Initialized
INFO - 2017-12-24 18:51:08 --> Model Class Initialized
INFO - 2017-12-24 18:51:08 --> Model Class Initialized
INFO - 2017-12-24 18:51:08 --> Model Class Initialized
DEBUG - 2017-12-24 18:51:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-24 18:51:12 --> Config Class Initialized
INFO - 2017-12-24 18:51:12 --> Hooks Class Initialized
DEBUG - 2017-12-24 18:51:12 --> UTF-8 Support Enabled
INFO - 2017-12-24 18:51:12 --> Utf8 Class Initialized
INFO - 2017-12-24 18:51:12 --> URI Class Initialized
INFO - 2017-12-24 18:51:12 --> Router Class Initialized
INFO - 2017-12-24 18:51:12 --> Output Class Initialized
INFO - 2017-12-24 18:51:12 --> Security Class Initialized
DEBUG - 2017-12-24 18:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-24 18:51:12 --> Input Class Initialized
INFO - 2017-12-24 18:51:12 --> Language Class Initialized
INFO - 2017-12-24 18:51:12 --> Loader Class Initialized
INFO - 2017-12-24 18:51:12 --> Helper loaded: url_helper
INFO - 2017-12-24 18:51:12 --> Helper loaded: form_helper
INFO - 2017-12-24 18:51:12 --> Database Driver Class Initialized
DEBUG - 2017-12-24 18:51:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-24 18:51:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-24 18:51:12 --> Form Validation Class Initialized
INFO - 2017-12-24 18:51:12 --> Model Class Initialized
INFO - 2017-12-24 18:51:12 --> Controller Class Initialized
INFO - 2017-12-24 18:51:12 --> Model Class Initialized
INFO - 2017-12-24 18:51:12 --> Model Class Initialized
INFO - 2017-12-24 18:51:12 --> Model Class Initialized
DEBUG - 2017-12-24 18:51:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-24 18:51:12 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-24 18:51:12 --> Final output sent to browser
DEBUG - 2017-12-24 18:51:12 --> Total execution time: 0.1654
INFO - 2017-12-24 19:17:36 --> Config Class Initialized
INFO - 2017-12-24 19:17:36 --> Hooks Class Initialized
DEBUG - 2017-12-24 19:17:36 --> UTF-8 Support Enabled
INFO - 2017-12-24 19:17:36 --> Utf8 Class Initialized
INFO - 2017-12-24 19:17:36 --> URI Class Initialized
INFO - 2017-12-24 19:17:36 --> Router Class Initialized
INFO - 2017-12-24 19:17:36 --> Output Class Initialized
INFO - 2017-12-24 19:17:36 --> Security Class Initialized
DEBUG - 2017-12-24 19:17:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-24 19:17:36 --> Input Class Initialized
INFO - 2017-12-24 19:17:36 --> Language Class Initialized
INFO - 2017-12-24 19:17:36 --> Loader Class Initialized
INFO - 2017-12-24 19:17:36 --> Helper loaded: url_helper
INFO - 2017-12-24 19:17:36 --> Helper loaded: form_helper
INFO - 2017-12-24 19:17:36 --> Database Driver Class Initialized
DEBUG - 2017-12-24 19:17:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-24 19:17:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-24 19:17:36 --> Form Validation Class Initialized
INFO - 2017-12-24 19:17:36 --> Model Class Initialized
INFO - 2017-12-24 19:17:36 --> Controller Class Initialized
INFO - 2017-12-24 19:17:36 --> Model Class Initialized
INFO - 2017-12-24 19:17:36 --> Model Class Initialized
INFO - 2017-12-24 19:17:36 --> Model Class Initialized
DEBUG - 2017-12-24 19:17:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-24 19:17:36 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-24 19:17:36 --> Final output sent to browser
DEBUG - 2017-12-24 19:17:36 --> Total execution time: 0.1225
INFO - 2017-12-24 19:17:43 --> Config Class Initialized
INFO - 2017-12-24 19:17:43 --> Hooks Class Initialized
DEBUG - 2017-12-24 19:17:43 --> UTF-8 Support Enabled
INFO - 2017-12-24 19:17:43 --> Utf8 Class Initialized
INFO - 2017-12-24 19:17:43 --> URI Class Initialized
INFO - 2017-12-24 19:17:43 --> Router Class Initialized
INFO - 2017-12-24 19:17:43 --> Output Class Initialized
INFO - 2017-12-24 19:17:43 --> Security Class Initialized
DEBUG - 2017-12-24 19:17:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-24 19:17:43 --> Input Class Initialized
INFO - 2017-12-24 19:17:43 --> Language Class Initialized
INFO - 2017-12-24 19:17:43 --> Loader Class Initialized
INFO - 2017-12-24 19:17:43 --> Helper loaded: url_helper
INFO - 2017-12-24 19:17:43 --> Helper loaded: form_helper
INFO - 2017-12-24 19:17:43 --> Database Driver Class Initialized
DEBUG - 2017-12-24 19:17:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-24 19:17:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-24 19:17:43 --> Form Validation Class Initialized
INFO - 2017-12-24 19:17:43 --> Model Class Initialized
INFO - 2017-12-24 19:17:43 --> Controller Class Initialized
INFO - 2017-12-24 19:17:43 --> Model Class Initialized
INFO - 2017-12-24 19:17:43 --> Model Class Initialized
INFO - 2017-12-24 19:17:43 --> Model Class Initialized
DEBUG - 2017-12-24 19:17:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-24 19:17:43 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-24 19:17:43 --> Final output sent to browser
DEBUG - 2017-12-24 19:17:43 --> Total execution time: 0.0947
INFO - 2017-12-24 19:17:43 --> Config Class Initialized
INFO - 2017-12-24 19:17:43 --> Hooks Class Initialized
DEBUG - 2017-12-24 19:17:43 --> UTF-8 Support Enabled
INFO - 2017-12-24 19:17:43 --> Utf8 Class Initialized
INFO - 2017-12-24 19:17:43 --> URI Class Initialized
INFO - 2017-12-24 19:17:43 --> Router Class Initialized
INFO - 2017-12-24 19:17:43 --> Output Class Initialized
INFO - 2017-12-24 19:17:43 --> Security Class Initialized
DEBUG - 2017-12-24 19:17:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-24 19:17:43 --> Input Class Initialized
INFO - 2017-12-24 19:17:43 --> Language Class Initialized
INFO - 2017-12-24 19:17:43 --> Loader Class Initialized
INFO - 2017-12-24 19:17:43 --> Helper loaded: url_helper
INFO - 2017-12-24 19:17:43 --> Helper loaded: form_helper
INFO - 2017-12-24 19:17:43 --> Database Driver Class Initialized
DEBUG - 2017-12-24 19:17:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-24 19:17:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-24 19:17:43 --> Form Validation Class Initialized
INFO - 2017-12-24 19:17:43 --> Model Class Initialized
INFO - 2017-12-24 19:17:43 --> Controller Class Initialized
INFO - 2017-12-24 19:17:43 --> Model Class Initialized
INFO - 2017-12-24 19:17:43 --> Model Class Initialized
INFO - 2017-12-24 19:17:43 --> Model Class Initialized
DEBUG - 2017-12-24 19:17:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-24 19:17:46 --> Config Class Initialized
INFO - 2017-12-24 19:17:46 --> Hooks Class Initialized
DEBUG - 2017-12-24 19:17:46 --> UTF-8 Support Enabled
INFO - 2017-12-24 19:17:46 --> Utf8 Class Initialized
INFO - 2017-12-24 19:17:46 --> URI Class Initialized
INFO - 2017-12-24 19:17:46 --> Router Class Initialized
INFO - 2017-12-24 19:17:46 --> Output Class Initialized
INFO - 2017-12-24 19:17:46 --> Security Class Initialized
DEBUG - 2017-12-24 19:17:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-24 19:17:46 --> Input Class Initialized
INFO - 2017-12-24 19:17:46 --> Language Class Initialized
INFO - 2017-12-24 19:17:46 --> Loader Class Initialized
INFO - 2017-12-24 19:17:46 --> Helper loaded: url_helper
INFO - 2017-12-24 19:17:46 --> Helper loaded: form_helper
INFO - 2017-12-24 19:17:46 --> Database Driver Class Initialized
DEBUG - 2017-12-24 19:17:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-24 19:17:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-24 19:17:46 --> Form Validation Class Initialized
INFO - 2017-12-24 19:17:46 --> Model Class Initialized
INFO - 2017-12-24 19:17:46 --> Controller Class Initialized
INFO - 2017-12-24 19:17:46 --> Model Class Initialized
INFO - 2017-12-24 19:17:46 --> Model Class Initialized
INFO - 2017-12-24 19:17:46 --> Model Class Initialized
DEBUG - 2017-12-24 19:17:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-24 19:17:46 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-24 19:17:46 --> Final output sent to browser
DEBUG - 2017-12-24 19:17:46 --> Total execution time: 0.0673
INFO - 2017-12-24 19:17:46 --> Config Class Initialized
INFO - 2017-12-24 19:17:46 --> Hooks Class Initialized
DEBUG - 2017-12-24 19:17:46 --> UTF-8 Support Enabled
INFO - 2017-12-24 19:17:46 --> Utf8 Class Initialized
INFO - 2017-12-24 19:17:46 --> URI Class Initialized
INFO - 2017-12-24 19:17:46 --> Router Class Initialized
INFO - 2017-12-24 19:17:46 --> Output Class Initialized
INFO - 2017-12-24 19:17:46 --> Security Class Initialized
DEBUG - 2017-12-24 19:17:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-24 19:17:46 --> Input Class Initialized
INFO - 2017-12-24 19:17:46 --> Language Class Initialized
INFO - 2017-12-24 19:17:46 --> Loader Class Initialized
INFO - 2017-12-24 19:17:46 --> Helper loaded: url_helper
INFO - 2017-12-24 19:17:46 --> Helper loaded: form_helper
INFO - 2017-12-24 19:17:46 --> Database Driver Class Initialized
DEBUG - 2017-12-24 19:17:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-24 19:17:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-24 19:17:46 --> Form Validation Class Initialized
INFO - 2017-12-24 19:17:46 --> Model Class Initialized
INFO - 2017-12-24 19:17:46 --> Controller Class Initialized
INFO - 2017-12-24 19:17:46 --> Model Class Initialized
INFO - 2017-12-24 19:17:46 --> Model Class Initialized
INFO - 2017-12-24 19:17:46 --> Model Class Initialized
DEBUG - 2017-12-24 19:17:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-24 19:17:49 --> Config Class Initialized
INFO - 2017-12-24 19:17:49 --> Hooks Class Initialized
DEBUG - 2017-12-24 19:17:49 --> UTF-8 Support Enabled
INFO - 2017-12-24 19:17:49 --> Utf8 Class Initialized
INFO - 2017-12-24 19:17:49 --> URI Class Initialized
INFO - 2017-12-24 19:17:49 --> Router Class Initialized
INFO - 2017-12-24 19:17:49 --> Output Class Initialized
INFO - 2017-12-24 19:17:49 --> Security Class Initialized
DEBUG - 2017-12-24 19:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-24 19:17:49 --> Input Class Initialized
INFO - 2017-12-24 19:17:49 --> Language Class Initialized
INFO - 2017-12-24 19:17:49 --> Loader Class Initialized
INFO - 2017-12-24 19:17:49 --> Helper loaded: url_helper
INFO - 2017-12-24 19:17:49 --> Helper loaded: form_helper
INFO - 2017-12-24 19:17:49 --> Database Driver Class Initialized
DEBUG - 2017-12-24 19:17:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-24 19:17:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-24 19:17:49 --> Form Validation Class Initialized
INFO - 2017-12-24 19:17:49 --> Model Class Initialized
INFO - 2017-12-24 19:17:49 --> Controller Class Initialized
INFO - 2017-12-24 19:17:49 --> Model Class Initialized
INFO - 2017-12-24 19:17:49 --> Model Class Initialized
INFO - 2017-12-24 19:17:49 --> Model Class Initialized
DEBUG - 2017-12-24 19:17:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-24 19:17:49 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-24 19:17:49 --> Final output sent to browser
DEBUG - 2017-12-24 19:17:49 --> Total execution time: 0.0902
INFO - 2017-12-24 19:17:53 --> Config Class Initialized
INFO - 2017-12-24 19:17:53 --> Hooks Class Initialized
DEBUG - 2017-12-24 19:17:53 --> UTF-8 Support Enabled
INFO - 2017-12-24 19:17:53 --> Utf8 Class Initialized
INFO - 2017-12-24 19:17:53 --> URI Class Initialized
INFO - 2017-12-24 19:17:53 --> Router Class Initialized
INFO - 2017-12-24 19:17:53 --> Output Class Initialized
INFO - 2017-12-24 19:17:53 --> Security Class Initialized
DEBUG - 2017-12-24 19:17:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-24 19:17:53 --> Input Class Initialized
INFO - 2017-12-24 19:17:53 --> Language Class Initialized
INFO - 2017-12-24 19:17:53 --> Loader Class Initialized
INFO - 2017-12-24 19:17:53 --> Helper loaded: url_helper
INFO - 2017-12-24 19:17:53 --> Helper loaded: form_helper
INFO - 2017-12-24 19:17:53 --> Database Driver Class Initialized
DEBUG - 2017-12-24 19:17:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-24 19:17:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-24 19:17:53 --> Form Validation Class Initialized
INFO - 2017-12-24 19:17:53 --> Model Class Initialized
INFO - 2017-12-24 19:17:53 --> Controller Class Initialized
INFO - 2017-12-24 19:17:53 --> Model Class Initialized
INFO - 2017-12-24 19:17:53 --> Model Class Initialized
INFO - 2017-12-24 19:17:53 --> Model Class Initialized
DEBUG - 2017-12-24 19:17:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-24 19:17:53 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-24 19:17:53 --> Final output sent to browser
DEBUG - 2017-12-24 19:17:53 --> Total execution time: 0.0886
INFO - 2017-12-24 19:17:56 --> Config Class Initialized
INFO - 2017-12-24 19:17:56 --> Hooks Class Initialized
DEBUG - 2017-12-24 19:17:56 --> UTF-8 Support Enabled
INFO - 2017-12-24 19:17:56 --> Utf8 Class Initialized
INFO - 2017-12-24 19:17:56 --> URI Class Initialized
INFO - 2017-12-24 19:17:56 --> Router Class Initialized
INFO - 2017-12-24 19:17:56 --> Output Class Initialized
INFO - 2017-12-24 19:17:56 --> Security Class Initialized
DEBUG - 2017-12-24 19:17:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-24 19:17:56 --> Input Class Initialized
INFO - 2017-12-24 19:17:56 --> Language Class Initialized
INFO - 2017-12-24 19:17:56 --> Loader Class Initialized
INFO - 2017-12-24 19:17:56 --> Helper loaded: url_helper
INFO - 2017-12-24 19:17:56 --> Helper loaded: form_helper
INFO - 2017-12-24 19:17:56 --> Database Driver Class Initialized
DEBUG - 2017-12-24 19:17:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-24 19:17:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-24 19:17:56 --> Form Validation Class Initialized
INFO - 2017-12-24 19:17:56 --> Model Class Initialized
INFO - 2017-12-24 19:17:56 --> Controller Class Initialized
INFO - 2017-12-24 19:17:56 --> Model Class Initialized
INFO - 2017-12-24 19:17:56 --> Model Class Initialized
INFO - 2017-12-24 19:17:56 --> Model Class Initialized
DEBUG - 2017-12-24 19:17:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-24 19:17:56 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-24 19:17:56 --> Final output sent to browser
DEBUG - 2017-12-24 19:17:56 --> Total execution time: 0.1215
INFO - 2017-12-24 19:27:25 --> Config Class Initialized
INFO - 2017-12-24 19:27:25 --> Hooks Class Initialized
DEBUG - 2017-12-24 19:27:25 --> UTF-8 Support Enabled
INFO - 2017-12-24 19:27:25 --> Utf8 Class Initialized
INFO - 2017-12-24 19:27:25 --> URI Class Initialized
INFO - 2017-12-24 19:27:25 --> Router Class Initialized
INFO - 2017-12-24 19:27:25 --> Output Class Initialized
INFO - 2017-12-24 19:27:25 --> Security Class Initialized
DEBUG - 2017-12-24 19:27:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-24 19:27:25 --> Input Class Initialized
INFO - 2017-12-24 19:27:25 --> Language Class Initialized
INFO - 2017-12-24 19:27:25 --> Loader Class Initialized
INFO - 2017-12-24 19:27:25 --> Helper loaded: url_helper
INFO - 2017-12-24 19:27:25 --> Helper loaded: form_helper
INFO - 2017-12-24 19:27:25 --> Database Driver Class Initialized
DEBUG - 2017-12-24 19:27:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-24 19:27:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-24 19:27:25 --> Form Validation Class Initialized
INFO - 2017-12-24 19:27:25 --> Model Class Initialized
INFO - 2017-12-24 19:27:25 --> Controller Class Initialized
INFO - 2017-12-24 19:27:25 --> Model Class Initialized
INFO - 2017-12-24 19:27:25 --> Model Class Initialized
INFO - 2017-12-24 19:27:25 --> Model Class Initialized
DEBUG - 2017-12-24 19:27:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-24 19:27:25 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-24 19:27:25 --> Final output sent to browser
DEBUG - 2017-12-24 19:27:25 --> Total execution time: 0.0637
INFO - 2017-12-24 19:27:34 --> Config Class Initialized
INFO - 2017-12-24 19:27:34 --> Hooks Class Initialized
DEBUG - 2017-12-24 19:27:34 --> UTF-8 Support Enabled
INFO - 2017-12-24 19:27:34 --> Utf8 Class Initialized
INFO - 2017-12-24 19:27:34 --> URI Class Initialized
INFO - 2017-12-24 19:27:34 --> Router Class Initialized
INFO - 2017-12-24 19:27:34 --> Output Class Initialized
INFO - 2017-12-24 19:27:34 --> Security Class Initialized
DEBUG - 2017-12-24 19:27:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-24 19:27:34 --> Input Class Initialized
INFO - 2017-12-24 19:27:34 --> Language Class Initialized
ERROR - 2017-12-24 19:27:34 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-24 19:27:34 --> Config Class Initialized
INFO - 2017-12-24 19:27:34 --> Hooks Class Initialized
DEBUG - 2017-12-24 19:27:34 --> UTF-8 Support Enabled
INFO - 2017-12-24 19:27:34 --> Utf8 Class Initialized
INFO - 2017-12-24 19:27:34 --> URI Class Initialized
INFO - 2017-12-24 19:27:34 --> Router Class Initialized
INFO - 2017-12-24 19:27:34 --> Config Class Initialized
INFO - 2017-12-24 19:27:34 --> Hooks Class Initialized
INFO - 2017-12-24 19:27:34 --> Output Class Initialized
INFO - 2017-12-24 19:27:34 --> Security Class Initialized
DEBUG - 2017-12-24 19:27:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-24 19:27:34 --> Input Class Initialized
INFO - 2017-12-24 19:27:34 --> Language Class Initialized
DEBUG - 2017-12-24 19:27:34 --> UTF-8 Support Enabled
INFO - 2017-12-24 19:27:34 --> Utf8 Class Initialized
ERROR - 2017-12-24 19:27:34 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-24 19:27:34 --> URI Class Initialized
INFO - 2017-12-24 19:27:34 --> Router Class Initialized
INFO - 2017-12-24 19:27:34 --> Output Class Initialized
INFO - 2017-12-24 19:27:34 --> Security Class Initialized
DEBUG - 2017-12-24 19:27:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-24 19:27:34 --> Input Class Initialized
INFO - 2017-12-24 19:27:34 --> Language Class Initialized
ERROR - 2017-12-24 19:27:34 --> 404 Page Not Found: Instatec_pub/css
