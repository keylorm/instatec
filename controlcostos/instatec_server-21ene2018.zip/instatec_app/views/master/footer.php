				</div>
			</div>
			<?php if($loggedin){ ?>
				<footer  class="sticky-footer">
			<?php }else{ ?>
				<footer  class="sticky-footer-full">	
			<?php } ?>
					<div class="container-fluid">
						<p class="text-center">Instalaciones Tecnológicas INSTATEC S.A.</p>
					</div>			
				</footer>
		</div>	

	</body>	
</html>