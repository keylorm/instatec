<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-01-09 20:09:43 --> Config Class Initialized
INFO - 2018-01-09 20:09:43 --> Hooks Class Initialized
DEBUG - 2018-01-09 20:09:43 --> UTF-8 Support Enabled
INFO - 2018-01-09 20:09:43 --> Utf8 Class Initialized
INFO - 2018-01-09 20:09:43 --> URI Class Initialized
DEBUG - 2018-01-09 20:09:43 --> No URI present. Default controller set.
INFO - 2018-01-09 20:09:43 --> Router Class Initialized
INFO - 2018-01-09 20:09:43 --> Output Class Initialized
INFO - 2018-01-09 20:09:43 --> Security Class Initialized
DEBUG - 2018-01-09 20:09:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-09 20:09:43 --> Input Class Initialized
INFO - 2018-01-09 20:09:43 --> Language Class Initialized
INFO - 2018-01-09 20:09:43 --> Loader Class Initialized
INFO - 2018-01-09 20:09:43 --> Helper loaded: url_helper
INFO - 2018-01-09 20:09:43 --> Helper loaded: form_helper
INFO - 2018-01-09 20:09:44 --> Database Driver Class Initialized
DEBUG - 2018-01-09 20:09:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-09 20:09:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-09 20:09:44 --> Form Validation Class Initialized
INFO - 2018-01-09 20:09:44 --> Model Class Initialized
INFO - 2018-01-09 20:09:44 --> Controller Class Initialized
INFO - 2018-01-09 20:09:44 --> Config Class Initialized
INFO - 2018-01-09 20:09:44 --> Hooks Class Initialized
INFO - 2018-01-09 20:09:44 --> Config Class Initialized
INFO - 2018-01-09 20:09:44 --> Hooks Class Initialized
DEBUG - 2018-01-09 20:09:44 --> UTF-8 Support Enabled
INFO - 2018-01-09 20:09:44 --> Utf8 Class Initialized
INFO - 2018-01-09 20:09:44 --> URI Class Initialized
DEBUG - 2018-01-09 20:09:44 --> UTF-8 Support Enabled
INFO - 2018-01-09 20:09:44 --> Utf8 Class Initialized
INFO - 2018-01-09 20:09:44 --> URI Class Initialized
INFO - 2018-01-09 20:09:44 --> Router Class Initialized
INFO - 2018-01-09 20:09:44 --> Router Class Initialized
INFO - 2018-01-09 20:09:44 --> Output Class Initialized
INFO - 2018-01-09 20:09:44 --> Output Class Initialized
INFO - 2018-01-09 20:09:44 --> Security Class Initialized
INFO - 2018-01-09 20:09:44 --> Security Class Initialized
DEBUG - 2018-01-09 20:09:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-09 20:09:44 --> Input Class Initialized
DEBUG - 2018-01-09 20:09:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-09 20:09:44 --> Input Class Initialized
INFO - 2018-01-09 20:09:44 --> Language Class Initialized
INFO - 2018-01-09 20:09:44 --> Language Class Initialized
INFO - 2018-01-09 20:09:44 --> Loader Class Initialized
INFO - 2018-01-09 20:09:44 --> Helper loaded: url_helper
INFO - 2018-01-09 20:09:44 --> Helper loaded: form_helper
INFO - 2018-01-09 20:09:44 --> Database Driver Class Initialized
DEBUG - 2018-01-09 20:09:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-01-09 20:09:44 --> 404 Page Not Found: Faviconico/index
INFO - 2018-01-09 20:09:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-09 20:09:44 --> Form Validation Class Initialized
INFO - 2018-01-09 20:09:44 --> Model Class Initialized
INFO - 2018-01-09 20:09:44 --> Controller Class Initialized
INFO - 2018-01-09 20:09:44 --> Model Class Initialized
DEBUG - 2018-01-09 20:09:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-09 20:09:44 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-09 20:09:44 --> Final output sent to browser
DEBUG - 2018-01-09 20:09:44 --> Total execution time: 0.1580
INFO - 2018-01-09 20:09:50 --> Config Class Initialized
INFO - 2018-01-09 20:09:50 --> Hooks Class Initialized
DEBUG - 2018-01-09 20:09:50 --> UTF-8 Support Enabled
INFO - 2018-01-09 20:09:50 --> Utf8 Class Initialized
INFO - 2018-01-09 20:09:50 --> URI Class Initialized
INFO - 2018-01-09 20:09:50 --> Router Class Initialized
INFO - 2018-01-09 20:09:50 --> Output Class Initialized
INFO - 2018-01-09 20:09:50 --> Security Class Initialized
DEBUG - 2018-01-09 20:09:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-09 20:09:50 --> Input Class Initialized
INFO - 2018-01-09 20:09:50 --> Language Class Initialized
INFO - 2018-01-09 20:09:50 --> Loader Class Initialized
INFO - 2018-01-09 20:09:50 --> Helper loaded: url_helper
INFO - 2018-01-09 20:09:50 --> Helper loaded: form_helper
INFO - 2018-01-09 20:09:50 --> Database Driver Class Initialized
DEBUG - 2018-01-09 20:09:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-09 20:09:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-09 20:09:50 --> Form Validation Class Initialized
INFO - 2018-01-09 20:09:50 --> Model Class Initialized
INFO - 2018-01-09 20:09:50 --> Controller Class Initialized
INFO - 2018-01-09 20:09:50 --> Model Class Initialized
DEBUG - 2018-01-09 20:09:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-09 20:09:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-01-09 20:09:50 --> Config Class Initialized
INFO - 2018-01-09 20:09:50 --> Hooks Class Initialized
DEBUG - 2018-01-09 20:09:50 --> UTF-8 Support Enabled
INFO - 2018-01-09 20:09:50 --> Utf8 Class Initialized
INFO - 2018-01-09 20:09:50 --> URI Class Initialized
DEBUG - 2018-01-09 20:09:50 --> No URI present. Default controller set.
INFO - 2018-01-09 20:09:50 --> Router Class Initialized
INFO - 2018-01-09 20:09:50 --> Output Class Initialized
INFO - 2018-01-09 20:09:50 --> Security Class Initialized
DEBUG - 2018-01-09 20:09:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-09 20:09:50 --> Input Class Initialized
INFO - 2018-01-09 20:09:50 --> Language Class Initialized
INFO - 2018-01-09 20:09:50 --> Loader Class Initialized
INFO - 2018-01-09 20:09:50 --> Helper loaded: url_helper
INFO - 2018-01-09 20:09:50 --> Helper loaded: form_helper
INFO - 2018-01-09 20:09:50 --> Database Driver Class Initialized
DEBUG - 2018-01-09 20:09:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-09 20:09:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-09 20:09:50 --> Form Validation Class Initialized
INFO - 2018-01-09 20:09:50 --> Model Class Initialized
INFO - 2018-01-09 20:09:50 --> Controller Class Initialized
INFO - 2018-01-09 20:09:50 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-09 20:09:50 --> Final output sent to browser
DEBUG - 2018-01-09 20:09:50 --> Total execution time: 0.0639
INFO - 2018-01-09 20:09:50 --> Config Class Initialized
INFO - 2018-01-09 20:09:50 --> Hooks Class Initialized
DEBUG - 2018-01-09 20:09:50 --> UTF-8 Support Enabled
INFO - 2018-01-09 20:09:50 --> Utf8 Class Initialized
INFO - 2018-01-09 20:09:50 --> URI Class Initialized
INFO - 2018-01-09 20:09:50 --> Router Class Initialized
INFO - 2018-01-09 20:09:50 --> Output Class Initialized
INFO - 2018-01-09 20:09:50 --> Security Class Initialized
DEBUG - 2018-01-09 20:09:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-09 20:09:50 --> Input Class Initialized
INFO - 2018-01-09 20:09:50 --> Language Class Initialized
INFO - 2018-01-09 20:09:50 --> Loader Class Initialized
INFO - 2018-01-09 20:09:50 --> Helper loaded: url_helper
INFO - 2018-01-09 20:09:50 --> Helper loaded: form_helper
INFO - 2018-01-09 20:09:50 --> Database Driver Class Initialized
DEBUG - 2018-01-09 20:09:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-09 20:09:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-09 20:09:50 --> Form Validation Class Initialized
INFO - 2018-01-09 20:09:50 --> Model Class Initialized
INFO - 2018-01-09 20:09:50 --> Controller Class Initialized
INFO - 2018-01-09 20:09:50 --> Model Class Initialized
INFO - 2018-01-09 20:09:50 --> Model Class Initialized
INFO - 2018-01-09 20:09:50 --> Model Class Initialized
INFO - 2018-01-09 20:09:50 --> Model Class Initialized
DEBUG - 2018-01-09 20:09:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-09 20:09:58 --> Config Class Initialized
INFO - 2018-01-09 20:09:58 --> Hooks Class Initialized
DEBUG - 2018-01-09 20:09:58 --> UTF-8 Support Enabled
INFO - 2018-01-09 20:09:58 --> Utf8 Class Initialized
INFO - 2018-01-09 20:09:58 --> URI Class Initialized
INFO - 2018-01-09 20:09:58 --> Router Class Initialized
INFO - 2018-01-09 20:09:58 --> Output Class Initialized
INFO - 2018-01-09 20:09:58 --> Security Class Initialized
DEBUG - 2018-01-09 20:09:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-09 20:09:58 --> Input Class Initialized
INFO - 2018-01-09 20:09:58 --> Language Class Initialized
INFO - 2018-01-09 20:09:58 --> Loader Class Initialized
INFO - 2018-01-09 20:09:58 --> Helper loaded: url_helper
INFO - 2018-01-09 20:09:58 --> Helper loaded: form_helper
INFO - 2018-01-09 20:09:58 --> Database Driver Class Initialized
DEBUG - 2018-01-09 20:09:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-09 20:09:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-09 20:09:58 --> Form Validation Class Initialized
INFO - 2018-01-09 20:09:58 --> Model Class Initialized
INFO - 2018-01-09 20:09:58 --> Controller Class Initialized
INFO - 2018-01-09 20:09:58 --> Model Class Initialized
INFO - 2018-01-09 20:09:58 --> Model Class Initialized
INFO - 2018-01-09 20:09:58 --> Model Class Initialized
INFO - 2018-01-09 20:09:58 --> Model Class Initialized
DEBUG - 2018-01-09 20:09:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-09 20:09:58 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-09 20:09:58 --> Final output sent to browser
DEBUG - 2018-01-09 20:09:58 --> Total execution time: 0.1193
INFO - 2018-01-09 20:09:58 --> Config Class Initialized
INFO - 2018-01-09 20:09:58 --> Hooks Class Initialized
DEBUG - 2018-01-09 20:09:58 --> UTF-8 Support Enabled
INFO - 2018-01-09 20:09:58 --> Utf8 Class Initialized
INFO - 2018-01-09 20:09:58 --> URI Class Initialized
INFO - 2018-01-09 20:09:58 --> Router Class Initialized
INFO - 2018-01-09 20:09:58 --> Output Class Initialized
INFO - 2018-01-09 20:09:58 --> Security Class Initialized
DEBUG - 2018-01-09 20:09:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-09 20:09:58 --> Input Class Initialized
INFO - 2018-01-09 20:09:58 --> Language Class Initialized
INFO - 2018-01-09 20:09:58 --> Loader Class Initialized
INFO - 2018-01-09 20:09:58 --> Helper loaded: url_helper
INFO - 2018-01-09 20:09:58 --> Helper loaded: form_helper
INFO - 2018-01-09 20:09:58 --> Database Driver Class Initialized
DEBUG - 2018-01-09 20:09:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-09 20:09:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-09 20:09:58 --> Form Validation Class Initialized
INFO - 2018-01-09 20:09:58 --> Model Class Initialized
INFO - 2018-01-09 20:09:58 --> Controller Class Initialized
INFO - 2018-01-09 20:09:58 --> Model Class Initialized
INFO - 2018-01-09 20:09:58 --> Model Class Initialized
INFO - 2018-01-09 20:09:58 --> Model Class Initialized
INFO - 2018-01-09 20:09:58 --> Model Class Initialized
DEBUG - 2018-01-09 20:09:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-09 20:10:01 --> Config Class Initialized
INFO - 2018-01-09 20:10:01 --> Hooks Class Initialized
DEBUG - 2018-01-09 20:10:01 --> UTF-8 Support Enabled
INFO - 2018-01-09 20:10:01 --> Utf8 Class Initialized
INFO - 2018-01-09 20:10:01 --> URI Class Initialized
INFO - 2018-01-09 20:10:01 --> Router Class Initialized
INFO - 2018-01-09 20:10:01 --> Output Class Initialized
INFO - 2018-01-09 20:10:01 --> Security Class Initialized
DEBUG - 2018-01-09 20:10:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-09 20:10:01 --> Input Class Initialized
INFO - 2018-01-09 20:10:01 --> Language Class Initialized
INFO - 2018-01-09 20:10:01 --> Loader Class Initialized
INFO - 2018-01-09 20:10:01 --> Helper loaded: url_helper
INFO - 2018-01-09 20:10:01 --> Helper loaded: form_helper
INFO - 2018-01-09 20:10:01 --> Database Driver Class Initialized
DEBUG - 2018-01-09 20:10:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-09 20:10:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-09 20:10:01 --> Form Validation Class Initialized
INFO - 2018-01-09 20:10:01 --> Model Class Initialized
INFO - 2018-01-09 20:10:01 --> Controller Class Initialized
INFO - 2018-01-09 20:10:01 --> Model Class Initialized
INFO - 2018-01-09 20:10:01 --> Model Class Initialized
INFO - 2018-01-09 20:10:01 --> Model Class Initialized
INFO - 2018-01-09 20:10:01 --> Model Class Initialized
DEBUG - 2018-01-09 20:10:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-09 20:10:01 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-09 20:10:01 --> Final output sent to browser
DEBUG - 2018-01-09 20:10:01 --> Total execution time: 0.4226
INFO - 2018-01-09 20:10:01 --> Config Class Initialized
INFO - 2018-01-09 20:10:01 --> Hooks Class Initialized
DEBUG - 2018-01-09 20:10:01 --> UTF-8 Support Enabled
INFO - 2018-01-09 20:10:01 --> Utf8 Class Initialized
INFO - 2018-01-09 20:10:01 --> URI Class Initialized
INFO - 2018-01-09 20:10:01 --> Router Class Initialized
INFO - 2018-01-09 20:10:01 --> Output Class Initialized
INFO - 2018-01-09 20:10:01 --> Security Class Initialized
DEBUG - 2018-01-09 20:10:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-09 20:10:01 --> Input Class Initialized
INFO - 2018-01-09 20:10:01 --> Language Class Initialized
INFO - 2018-01-09 20:10:01 --> Loader Class Initialized
INFO - 2018-01-09 20:10:01 --> Helper loaded: url_helper
INFO - 2018-01-09 20:10:01 --> Helper loaded: form_helper
INFO - 2018-01-09 20:10:01 --> Database Driver Class Initialized
DEBUG - 2018-01-09 20:10:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-09 20:10:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-09 20:10:01 --> Form Validation Class Initialized
INFO - 2018-01-09 20:10:01 --> Model Class Initialized
INFO - 2018-01-09 20:10:01 --> Controller Class Initialized
INFO - 2018-01-09 20:10:01 --> Model Class Initialized
INFO - 2018-01-09 20:10:01 --> Model Class Initialized
INFO - 2018-01-09 20:10:01 --> Model Class Initialized
INFO - 2018-01-09 20:10:01 --> Model Class Initialized
DEBUG - 2018-01-09 20:10:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-09 20:10:11 --> Config Class Initialized
INFO - 2018-01-09 20:10:11 --> Hooks Class Initialized
DEBUG - 2018-01-09 20:10:11 --> UTF-8 Support Enabled
INFO - 2018-01-09 20:10:11 --> Utf8 Class Initialized
INFO - 2018-01-09 20:10:11 --> URI Class Initialized
INFO - 2018-01-09 20:10:11 --> Router Class Initialized
INFO - 2018-01-09 20:10:11 --> Output Class Initialized
INFO - 2018-01-09 20:10:11 --> Security Class Initialized
DEBUG - 2018-01-09 20:10:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-09 20:10:11 --> Input Class Initialized
INFO - 2018-01-09 20:10:11 --> Language Class Initialized
INFO - 2018-01-09 20:10:11 --> Loader Class Initialized
INFO - 2018-01-09 20:10:11 --> Helper loaded: url_helper
INFO - 2018-01-09 20:10:11 --> Helper loaded: form_helper
INFO - 2018-01-09 20:10:11 --> Database Driver Class Initialized
DEBUG - 2018-01-09 20:10:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-09 20:10:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-09 20:10:11 --> Form Validation Class Initialized
INFO - 2018-01-09 20:10:11 --> Model Class Initialized
INFO - 2018-01-09 20:10:11 --> Controller Class Initialized
INFO - 2018-01-09 20:10:11 --> Model Class Initialized
INFO - 2018-01-09 20:10:11 --> Model Class Initialized
INFO - 2018-01-09 20:10:11 --> Model Class Initialized
INFO - 2018-01-09 20:10:11 --> Model Class Initialized
DEBUG - 2018-01-09 20:10:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-09 20:10:12 --> Final output sent to browser
DEBUG - 2018-01-09 20:10:12 --> Total execution time: 0.8168
INFO - 2018-01-09 20:10:22 --> Config Class Initialized
INFO - 2018-01-09 20:10:22 --> Hooks Class Initialized
DEBUG - 2018-01-09 20:10:22 --> UTF-8 Support Enabled
INFO - 2018-01-09 20:10:22 --> Utf8 Class Initialized
INFO - 2018-01-09 20:10:22 --> URI Class Initialized
INFO - 2018-01-09 20:10:22 --> Router Class Initialized
INFO - 2018-01-09 20:10:22 --> Output Class Initialized
INFO - 2018-01-09 20:10:22 --> Security Class Initialized
DEBUG - 2018-01-09 20:10:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-09 20:10:22 --> Input Class Initialized
INFO - 2018-01-09 20:10:22 --> Language Class Initialized
INFO - 2018-01-09 20:10:22 --> Loader Class Initialized
INFO - 2018-01-09 20:10:22 --> Helper loaded: url_helper
INFO - 2018-01-09 20:10:22 --> Helper loaded: form_helper
INFO - 2018-01-09 20:10:22 --> Database Driver Class Initialized
DEBUG - 2018-01-09 20:10:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-09 20:10:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-09 20:10:22 --> Form Validation Class Initialized
INFO - 2018-01-09 20:10:22 --> Model Class Initialized
INFO - 2018-01-09 20:10:22 --> Controller Class Initialized
INFO - 2018-01-09 20:10:22 --> Model Class Initialized
INFO - 2018-01-09 20:10:22 --> Model Class Initialized
INFO - 2018-01-09 20:10:22 --> Model Class Initialized
INFO - 2018-01-09 20:10:22 --> Model Class Initialized
DEBUG - 2018-01-09 20:10:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-09 20:10:22 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-09 20:10:22 --> Final output sent to browser
DEBUG - 2018-01-09 20:10:22 --> Total execution time: 0.0965
INFO - 2018-01-09 20:10:22 --> Config Class Initialized
INFO - 2018-01-09 20:10:22 --> Hooks Class Initialized
INFO - 2018-01-09 20:10:22 --> Config Class Initialized
INFO - 2018-01-09 20:10:22 --> Hooks Class Initialized
DEBUG - 2018-01-09 20:10:22 --> UTF-8 Support Enabled
INFO - 2018-01-09 20:10:22 --> Utf8 Class Initialized
INFO - 2018-01-09 20:10:22 --> URI Class Initialized
DEBUG - 2018-01-09 20:10:22 --> UTF-8 Support Enabled
INFO - 2018-01-09 20:10:22 --> Utf8 Class Initialized
INFO - 2018-01-09 20:10:22 --> URI Class Initialized
INFO - 2018-01-09 20:10:22 --> Router Class Initialized
INFO - 2018-01-09 20:10:22 --> Output Class Initialized
INFO - 2018-01-09 20:10:22 --> Router Class Initialized
INFO - 2018-01-09 20:10:22 --> Security Class Initialized
INFO - 2018-01-09 20:10:22 --> Output Class Initialized
DEBUG - 2018-01-09 20:10:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-09 20:10:22 --> Input Class Initialized
INFO - 2018-01-09 20:10:22 --> Security Class Initialized
INFO - 2018-01-09 20:10:22 --> Language Class Initialized
DEBUG - 2018-01-09 20:10:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-09 20:10:22 --> Input Class Initialized
INFO - 2018-01-09 20:10:22 --> Language Class Initialized
INFO - 2018-01-09 20:10:22 --> Loader Class Initialized
INFO - 2018-01-09 20:10:22 --> Helper loaded: url_helper
INFO - 2018-01-09 20:10:22 --> Loader Class Initialized
INFO - 2018-01-09 20:10:22 --> Helper loaded: form_helper
INFO - 2018-01-09 20:10:22 --> Helper loaded: url_helper
INFO - 2018-01-09 20:10:22 --> Helper loaded: form_helper
INFO - 2018-01-09 20:10:22 --> Database Driver Class Initialized
INFO - 2018-01-09 20:10:22 --> Database Driver Class Initialized
DEBUG - 2018-01-09 20:10:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-09 20:10:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-01-09 20:10:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-09 20:10:22 --> Form Validation Class Initialized
INFO - 2018-01-09 20:10:22 --> Model Class Initialized
INFO - 2018-01-09 20:10:22 --> Controller Class Initialized
INFO - 2018-01-09 20:10:22 --> Model Class Initialized
INFO - 2018-01-09 20:10:22 --> Model Class Initialized
INFO - 2018-01-09 20:10:22 --> Model Class Initialized
INFO - 2018-01-09 20:10:22 --> Model Class Initialized
DEBUG - 2018-01-09 20:10:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-09 20:10:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-09 20:10:22 --> Form Validation Class Initialized
INFO - 2018-01-09 20:10:22 --> Model Class Initialized
INFO - 2018-01-09 20:10:22 --> Controller Class Initialized
INFO - 2018-01-09 20:10:22 --> Model Class Initialized
INFO - 2018-01-09 20:10:22 --> Model Class Initialized
INFO - 2018-01-09 20:10:22 --> Model Class Initialized
INFO - 2018-01-09 20:10:22 --> Model Class Initialized
DEBUG - 2018-01-09 20:10:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-09 20:10:42 --> Config Class Initialized
INFO - 2018-01-09 20:10:42 --> Hooks Class Initialized
DEBUG - 2018-01-09 20:10:42 --> UTF-8 Support Enabled
INFO - 2018-01-09 20:10:42 --> Utf8 Class Initialized
INFO - 2018-01-09 20:10:42 --> URI Class Initialized
INFO - 2018-01-09 20:10:42 --> Router Class Initialized
INFO - 2018-01-09 20:10:42 --> Output Class Initialized
INFO - 2018-01-09 20:10:42 --> Security Class Initialized
DEBUG - 2018-01-09 20:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-09 20:10:42 --> Input Class Initialized
INFO - 2018-01-09 20:10:42 --> Language Class Initialized
INFO - 2018-01-09 20:10:42 --> Loader Class Initialized
INFO - 2018-01-09 20:10:42 --> Helper loaded: url_helper
INFO - 2018-01-09 20:10:42 --> Helper loaded: form_helper
INFO - 2018-01-09 20:10:42 --> Database Driver Class Initialized
DEBUG - 2018-01-09 20:10:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-09 20:10:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-09 20:10:42 --> Form Validation Class Initialized
INFO - 2018-01-09 20:10:42 --> Model Class Initialized
INFO - 2018-01-09 20:10:42 --> Controller Class Initialized
INFO - 2018-01-09 20:10:42 --> Model Class Initialized
INFO - 2018-01-09 20:10:42 --> Model Class Initialized
DEBUG - 2018-01-09 20:10:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-09 20:10:42 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-09 20:10:42 --> Final output sent to browser
DEBUG - 2018-01-09 20:10:42 --> Total execution time: 0.1181
INFO - 2018-01-09 20:10:42 --> Config Class Initialized
INFO - 2018-01-09 20:10:42 --> Hooks Class Initialized
DEBUG - 2018-01-09 20:10:42 --> UTF-8 Support Enabled
INFO - 2018-01-09 20:10:42 --> Utf8 Class Initialized
INFO - 2018-01-09 20:10:42 --> URI Class Initialized
INFO - 2018-01-09 20:10:42 --> Router Class Initialized
INFO - 2018-01-09 20:10:42 --> Output Class Initialized
INFO - 2018-01-09 20:10:42 --> Security Class Initialized
DEBUG - 2018-01-09 20:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-09 20:10:42 --> Input Class Initialized
INFO - 2018-01-09 20:10:42 --> Language Class Initialized
INFO - 2018-01-09 20:10:42 --> Loader Class Initialized
INFO - 2018-01-09 20:10:42 --> Helper loaded: url_helper
INFO - 2018-01-09 20:10:42 --> Helper loaded: form_helper
INFO - 2018-01-09 20:10:42 --> Database Driver Class Initialized
DEBUG - 2018-01-09 20:10:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-09 20:10:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-09 20:10:42 --> Form Validation Class Initialized
INFO - 2018-01-09 20:10:42 --> Model Class Initialized
INFO - 2018-01-09 20:10:42 --> Controller Class Initialized
INFO - 2018-01-09 20:10:42 --> Model Class Initialized
INFO - 2018-01-09 20:10:42 --> Model Class Initialized
DEBUG - 2018-01-09 20:10:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-09 20:10:44 --> Config Class Initialized
INFO - 2018-01-09 20:10:44 --> Hooks Class Initialized
DEBUG - 2018-01-09 20:10:44 --> UTF-8 Support Enabled
INFO - 2018-01-09 20:10:44 --> Utf8 Class Initialized
INFO - 2018-01-09 20:10:44 --> URI Class Initialized
INFO - 2018-01-09 20:10:44 --> Router Class Initialized
INFO - 2018-01-09 20:10:44 --> Output Class Initialized
INFO - 2018-01-09 20:10:44 --> Security Class Initialized
DEBUG - 2018-01-09 20:10:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-09 20:10:44 --> Input Class Initialized
INFO - 2018-01-09 20:10:44 --> Language Class Initialized
INFO - 2018-01-09 20:10:44 --> Loader Class Initialized
INFO - 2018-01-09 20:10:44 --> Helper loaded: url_helper
INFO - 2018-01-09 20:10:44 --> Helper loaded: form_helper
INFO - 2018-01-09 20:10:44 --> Database Driver Class Initialized
DEBUG - 2018-01-09 20:10:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-09 20:10:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-09 20:10:44 --> Form Validation Class Initialized
INFO - 2018-01-09 20:10:44 --> Model Class Initialized
INFO - 2018-01-09 20:10:44 --> Controller Class Initialized
INFO - 2018-01-09 20:10:44 --> Model Class Initialized
INFO - 2018-01-09 20:10:44 --> Model Class Initialized
DEBUG - 2018-01-09 20:10:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-09 20:10:44 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-09 20:10:44 --> Final output sent to browser
DEBUG - 2018-01-09 20:10:44 --> Total execution time: 0.1218
INFO - 2018-01-09 20:10:44 --> Config Class Initialized
INFO - 2018-01-09 20:10:44 --> Hooks Class Initialized
DEBUG - 2018-01-09 20:10:44 --> UTF-8 Support Enabled
INFO - 2018-01-09 20:10:44 --> Utf8 Class Initialized
INFO - 2018-01-09 20:10:44 --> URI Class Initialized
INFO - 2018-01-09 20:10:44 --> Router Class Initialized
INFO - 2018-01-09 20:10:44 --> Output Class Initialized
INFO - 2018-01-09 20:10:44 --> Security Class Initialized
DEBUG - 2018-01-09 20:10:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-09 20:10:44 --> Input Class Initialized
INFO - 2018-01-09 20:10:44 --> Language Class Initialized
INFO - 2018-01-09 20:10:44 --> Loader Class Initialized
INFO - 2018-01-09 20:10:44 --> Helper loaded: url_helper
INFO - 2018-01-09 20:10:44 --> Helper loaded: form_helper
INFO - 2018-01-09 20:10:44 --> Database Driver Class Initialized
DEBUG - 2018-01-09 20:10:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-09 20:10:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-09 20:10:44 --> Form Validation Class Initialized
INFO - 2018-01-09 20:10:44 --> Model Class Initialized
INFO - 2018-01-09 20:10:44 --> Controller Class Initialized
INFO - 2018-01-09 20:10:44 --> Model Class Initialized
INFO - 2018-01-09 20:10:44 --> Model Class Initialized
DEBUG - 2018-01-09 20:10:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-09 20:10:52 --> Config Class Initialized
INFO - 2018-01-09 20:10:52 --> Hooks Class Initialized
DEBUG - 2018-01-09 20:10:52 --> UTF-8 Support Enabled
INFO - 2018-01-09 20:10:52 --> Utf8 Class Initialized
INFO - 2018-01-09 20:10:52 --> URI Class Initialized
INFO - 2018-01-09 20:10:52 --> Router Class Initialized
INFO - 2018-01-09 20:10:52 --> Output Class Initialized
INFO - 2018-01-09 20:10:52 --> Security Class Initialized
DEBUG - 2018-01-09 20:10:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-09 20:10:52 --> Input Class Initialized
INFO - 2018-01-09 20:10:52 --> Language Class Initialized
INFO - 2018-01-09 20:10:52 --> Loader Class Initialized
INFO - 2018-01-09 20:10:52 --> Helper loaded: url_helper
INFO - 2018-01-09 20:10:52 --> Helper loaded: form_helper
INFO - 2018-01-09 20:10:52 --> Database Driver Class Initialized
DEBUG - 2018-01-09 20:10:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-09 20:10:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-09 20:10:52 --> Form Validation Class Initialized
INFO - 2018-01-09 20:10:52 --> Model Class Initialized
INFO - 2018-01-09 20:10:52 --> Controller Class Initialized
INFO - 2018-01-09 20:10:52 --> Model Class Initialized
INFO - 2018-01-09 20:10:52 --> Model Class Initialized
DEBUG - 2018-01-09 20:10:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-09 20:10:56 --> Config Class Initialized
INFO - 2018-01-09 20:10:56 --> Hooks Class Initialized
DEBUG - 2018-01-09 20:10:56 --> UTF-8 Support Enabled
INFO - 2018-01-09 20:10:56 --> Utf8 Class Initialized
INFO - 2018-01-09 20:10:56 --> URI Class Initialized
INFO - 2018-01-09 20:10:56 --> Router Class Initialized
INFO - 2018-01-09 20:10:56 --> Output Class Initialized
INFO - 2018-01-09 20:10:56 --> Security Class Initialized
DEBUG - 2018-01-09 20:10:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-09 20:10:56 --> Input Class Initialized
INFO - 2018-01-09 20:10:56 --> Language Class Initialized
INFO - 2018-01-09 20:10:56 --> Loader Class Initialized
INFO - 2018-01-09 20:10:56 --> Helper loaded: url_helper
INFO - 2018-01-09 20:10:56 --> Helper loaded: form_helper
INFO - 2018-01-09 20:10:56 --> Database Driver Class Initialized
DEBUG - 2018-01-09 20:10:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-09 20:10:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-09 20:10:56 --> Form Validation Class Initialized
INFO - 2018-01-09 20:10:56 --> Model Class Initialized
INFO - 2018-01-09 20:10:56 --> Controller Class Initialized
INFO - 2018-01-09 20:10:56 --> Model Class Initialized
INFO - 2018-01-09 20:10:56 --> Model Class Initialized
DEBUG - 2018-01-09 20:10:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-09 20:10:59 --> Config Class Initialized
INFO - 2018-01-09 20:10:59 --> Hooks Class Initialized
DEBUG - 2018-01-09 20:10:59 --> UTF-8 Support Enabled
INFO - 2018-01-09 20:10:59 --> Utf8 Class Initialized
INFO - 2018-01-09 20:10:59 --> URI Class Initialized
INFO - 2018-01-09 20:10:59 --> Router Class Initialized
INFO - 2018-01-09 20:10:59 --> Output Class Initialized
INFO - 2018-01-09 20:10:59 --> Security Class Initialized
DEBUG - 2018-01-09 20:10:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-09 20:10:59 --> Input Class Initialized
INFO - 2018-01-09 20:10:59 --> Language Class Initialized
INFO - 2018-01-09 20:10:59 --> Loader Class Initialized
INFO - 2018-01-09 20:10:59 --> Helper loaded: url_helper
INFO - 2018-01-09 20:10:59 --> Helper loaded: form_helper
INFO - 2018-01-09 20:10:59 --> Database Driver Class Initialized
DEBUG - 2018-01-09 20:10:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-09 20:10:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-09 20:10:59 --> Form Validation Class Initialized
INFO - 2018-01-09 20:10:59 --> Model Class Initialized
INFO - 2018-01-09 20:10:59 --> Controller Class Initialized
INFO - 2018-01-09 20:10:59 --> Model Class Initialized
INFO - 2018-01-09 20:10:59 --> Model Class Initialized
INFO - 2018-01-09 20:10:59 --> Model Class Initialized
INFO - 2018-01-09 20:10:59 --> Model Class Initialized
DEBUG - 2018-01-09 20:10:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-09 20:10:59 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-09 20:10:59 --> Final output sent to browser
DEBUG - 2018-01-09 20:10:59 --> Total execution time: 0.0891
INFO - 2018-01-09 20:10:59 --> Config Class Initialized
INFO - 2018-01-09 20:10:59 --> Hooks Class Initialized
DEBUG - 2018-01-09 20:10:59 --> UTF-8 Support Enabled
INFO - 2018-01-09 20:10:59 --> Utf8 Class Initialized
INFO - 2018-01-09 20:10:59 --> URI Class Initialized
INFO - 2018-01-09 20:10:59 --> Router Class Initialized
INFO - 2018-01-09 20:10:59 --> Output Class Initialized
INFO - 2018-01-09 20:10:59 --> Security Class Initialized
DEBUG - 2018-01-09 20:10:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-09 20:10:59 --> Input Class Initialized
INFO - 2018-01-09 20:10:59 --> Language Class Initialized
INFO - 2018-01-09 20:10:59 --> Loader Class Initialized
INFO - 2018-01-09 20:10:59 --> Helper loaded: url_helper
INFO - 2018-01-09 20:10:59 --> Helper loaded: form_helper
INFO - 2018-01-09 20:10:59 --> Database Driver Class Initialized
DEBUG - 2018-01-09 20:10:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-09 20:10:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-09 20:10:59 --> Form Validation Class Initialized
INFO - 2018-01-09 20:10:59 --> Model Class Initialized
INFO - 2018-01-09 20:10:59 --> Controller Class Initialized
INFO - 2018-01-09 20:10:59 --> Model Class Initialized
INFO - 2018-01-09 20:10:59 --> Model Class Initialized
INFO - 2018-01-09 20:10:59 --> Model Class Initialized
INFO - 2018-01-09 20:10:59 --> Model Class Initialized
DEBUG - 2018-01-09 20:10:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-09 20:11:03 --> Config Class Initialized
INFO - 2018-01-09 20:11:03 --> Hooks Class Initialized
DEBUG - 2018-01-09 20:11:03 --> UTF-8 Support Enabled
INFO - 2018-01-09 20:11:03 --> Utf8 Class Initialized
INFO - 2018-01-09 20:11:03 --> URI Class Initialized
INFO - 2018-01-09 20:11:03 --> Router Class Initialized
INFO - 2018-01-09 20:11:03 --> Output Class Initialized
INFO - 2018-01-09 20:11:03 --> Security Class Initialized
DEBUG - 2018-01-09 20:11:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-09 20:11:03 --> Input Class Initialized
INFO - 2018-01-09 20:11:03 --> Language Class Initialized
INFO - 2018-01-09 20:11:03 --> Loader Class Initialized
INFO - 2018-01-09 20:11:03 --> Helper loaded: url_helper
INFO - 2018-01-09 20:11:03 --> Helper loaded: form_helper
INFO - 2018-01-09 20:11:03 --> Database Driver Class Initialized
DEBUG - 2018-01-09 20:11:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-09 20:11:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-09 20:11:03 --> Form Validation Class Initialized
INFO - 2018-01-09 20:11:03 --> Model Class Initialized
INFO - 2018-01-09 20:11:03 --> Controller Class Initialized
INFO - 2018-01-09 20:11:03 --> Model Class Initialized
INFO - 2018-01-09 20:11:03 --> Model Class Initialized
INFO - 2018-01-09 20:11:03 --> Model Class Initialized
INFO - 2018-01-09 20:11:03 --> Model Class Initialized
DEBUG - 2018-01-09 20:11:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-09 20:11:03 --> Final output sent to browser
DEBUG - 2018-01-09 20:11:03 --> Total execution time: 0.1307
INFO - 2018-01-09 20:11:03 --> Config Class Initialized
INFO - 2018-01-09 20:11:03 --> Hooks Class Initialized
DEBUG - 2018-01-09 20:11:03 --> UTF-8 Support Enabled
INFO - 2018-01-09 20:11:03 --> Utf8 Class Initialized
INFO - 2018-01-09 20:11:03 --> URI Class Initialized
INFO - 2018-01-09 20:11:03 --> Router Class Initialized
INFO - 2018-01-09 20:11:03 --> Output Class Initialized
INFO - 2018-01-09 20:11:03 --> Security Class Initialized
DEBUG - 2018-01-09 20:11:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-09 20:11:03 --> Input Class Initialized
INFO - 2018-01-09 20:11:03 --> Language Class Initialized
INFO - 2018-01-09 20:11:03 --> Loader Class Initialized
INFO - 2018-01-09 20:11:03 --> Helper loaded: url_helper
INFO - 2018-01-09 20:11:03 --> Helper loaded: form_helper
INFO - 2018-01-09 20:11:03 --> Database Driver Class Initialized
DEBUG - 2018-01-09 20:11:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-09 20:11:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-09 20:11:03 --> Form Validation Class Initialized
INFO - 2018-01-09 20:11:03 --> Model Class Initialized
INFO - 2018-01-09 20:11:03 --> Controller Class Initialized
INFO - 2018-01-09 20:11:03 --> Model Class Initialized
INFO - 2018-01-09 20:11:03 --> Model Class Initialized
INFO - 2018-01-09 20:11:03 --> Model Class Initialized
INFO - 2018-01-09 20:11:03 --> Model Class Initialized
DEBUG - 2018-01-09 20:11:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-09 20:11:03 --> Final output sent to browser
DEBUG - 2018-01-09 20:11:03 --> Total execution time: 0.0784
INFO - 2018-01-09 20:11:03 --> Config Class Initialized
INFO - 2018-01-09 20:11:03 --> Hooks Class Initialized
DEBUG - 2018-01-09 20:11:03 --> UTF-8 Support Enabled
INFO - 2018-01-09 20:11:03 --> Utf8 Class Initialized
INFO - 2018-01-09 20:11:03 --> URI Class Initialized
INFO - 2018-01-09 20:11:03 --> Router Class Initialized
INFO - 2018-01-09 20:11:03 --> Output Class Initialized
INFO - 2018-01-09 20:11:03 --> Security Class Initialized
DEBUG - 2018-01-09 20:11:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-09 20:11:03 --> Input Class Initialized
INFO - 2018-01-09 20:11:03 --> Language Class Initialized
INFO - 2018-01-09 20:11:03 --> Loader Class Initialized
INFO - 2018-01-09 20:11:03 --> Helper loaded: url_helper
INFO - 2018-01-09 20:11:03 --> Helper loaded: form_helper
INFO - 2018-01-09 20:11:03 --> Database Driver Class Initialized
DEBUG - 2018-01-09 20:11:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-09 20:11:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-09 20:11:03 --> Form Validation Class Initialized
INFO - 2018-01-09 20:11:03 --> Model Class Initialized
INFO - 2018-01-09 20:11:03 --> Controller Class Initialized
INFO - 2018-01-09 20:11:03 --> Model Class Initialized
INFO - 2018-01-09 20:11:03 --> Model Class Initialized
INFO - 2018-01-09 20:11:03 --> Model Class Initialized
INFO - 2018-01-09 20:11:03 --> Model Class Initialized
DEBUG - 2018-01-09 20:11:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-09 20:11:03 --> Final output sent to browser
DEBUG - 2018-01-09 20:11:03 --> Total execution time: 0.1000
INFO - 2018-01-09 20:11:05 --> Config Class Initialized
INFO - 2018-01-09 20:11:05 --> Hooks Class Initialized
DEBUG - 2018-01-09 20:11:05 --> UTF-8 Support Enabled
INFO - 2018-01-09 20:11:05 --> Utf8 Class Initialized
INFO - 2018-01-09 20:11:05 --> URI Class Initialized
INFO - 2018-01-09 20:11:05 --> Router Class Initialized
INFO - 2018-01-09 20:11:05 --> Output Class Initialized
INFO - 2018-01-09 20:11:05 --> Security Class Initialized
DEBUG - 2018-01-09 20:11:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-09 20:11:05 --> Input Class Initialized
INFO - 2018-01-09 20:11:05 --> Language Class Initialized
INFO - 2018-01-09 20:11:05 --> Loader Class Initialized
INFO - 2018-01-09 20:11:05 --> Helper loaded: url_helper
INFO - 2018-01-09 20:11:05 --> Helper loaded: form_helper
INFO - 2018-01-09 20:11:05 --> Database Driver Class Initialized
DEBUG - 2018-01-09 20:11:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-09 20:11:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-09 20:11:05 --> Form Validation Class Initialized
INFO - 2018-01-09 20:11:05 --> Model Class Initialized
INFO - 2018-01-09 20:11:05 --> Controller Class Initialized
INFO - 2018-01-09 20:11:05 --> Model Class Initialized
INFO - 2018-01-09 20:11:05 --> Model Class Initialized
INFO - 2018-01-09 20:11:05 --> Model Class Initialized
INFO - 2018-01-09 20:11:05 --> Model Class Initialized
DEBUG - 2018-01-09 20:11:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-09 20:11:05 --> Final output sent to browser
DEBUG - 2018-01-09 20:11:05 --> Total execution time: 0.1068
INFO - 2018-01-09 20:11:06 --> Config Class Initialized
INFO - 2018-01-09 20:11:06 --> Hooks Class Initialized
DEBUG - 2018-01-09 20:11:06 --> UTF-8 Support Enabled
INFO - 2018-01-09 20:11:06 --> Utf8 Class Initialized
INFO - 2018-01-09 20:11:06 --> URI Class Initialized
INFO - 2018-01-09 20:11:06 --> Router Class Initialized
INFO - 2018-01-09 20:11:06 --> Output Class Initialized
INFO - 2018-01-09 20:11:06 --> Security Class Initialized
DEBUG - 2018-01-09 20:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-09 20:11:06 --> Input Class Initialized
INFO - 2018-01-09 20:11:06 --> Language Class Initialized
INFO - 2018-01-09 20:11:06 --> Loader Class Initialized
INFO - 2018-01-09 20:11:06 --> Helper loaded: url_helper
INFO - 2018-01-09 20:11:06 --> Helper loaded: form_helper
INFO - 2018-01-09 20:11:06 --> Database Driver Class Initialized
DEBUG - 2018-01-09 20:11:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-09 20:11:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-09 20:11:06 --> Form Validation Class Initialized
INFO - 2018-01-09 20:11:06 --> Model Class Initialized
INFO - 2018-01-09 20:11:06 --> Controller Class Initialized
INFO - 2018-01-09 20:11:06 --> Model Class Initialized
INFO - 2018-01-09 20:11:06 --> Model Class Initialized
INFO - 2018-01-09 20:11:06 --> Model Class Initialized
INFO - 2018-01-09 20:11:06 --> Model Class Initialized
DEBUG - 2018-01-09 20:11:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-09 20:11:07 --> Config Class Initialized
INFO - 2018-01-09 20:11:07 --> Hooks Class Initialized
DEBUG - 2018-01-09 20:11:07 --> UTF-8 Support Enabled
INFO - 2018-01-09 20:11:07 --> Utf8 Class Initialized
INFO - 2018-01-09 20:11:07 --> URI Class Initialized
INFO - 2018-01-09 20:11:07 --> Router Class Initialized
INFO - 2018-01-09 20:11:07 --> Output Class Initialized
INFO - 2018-01-09 20:11:07 --> Security Class Initialized
DEBUG - 2018-01-09 20:11:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-09 20:11:07 --> Input Class Initialized
INFO - 2018-01-09 20:11:07 --> Language Class Initialized
INFO - 2018-01-09 20:11:07 --> Loader Class Initialized
INFO - 2018-01-09 20:11:07 --> Helper loaded: url_helper
INFO - 2018-01-09 20:11:07 --> Helper loaded: form_helper
INFO - 2018-01-09 20:11:07 --> Database Driver Class Initialized
DEBUG - 2018-01-09 20:11:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-09 20:11:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-09 20:11:07 --> Form Validation Class Initialized
INFO - 2018-01-09 20:11:07 --> Model Class Initialized
INFO - 2018-01-09 20:11:07 --> Controller Class Initialized
INFO - 2018-01-09 20:11:07 --> Model Class Initialized
INFO - 2018-01-09 20:11:07 --> Model Class Initialized
INFO - 2018-01-09 20:11:07 --> Model Class Initialized
INFO - 2018-01-09 20:11:07 --> Model Class Initialized
DEBUG - 2018-01-09 20:11:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-09 20:11:09 --> Config Class Initialized
INFO - 2018-01-09 20:11:09 --> Hooks Class Initialized
DEBUG - 2018-01-09 20:11:09 --> UTF-8 Support Enabled
INFO - 2018-01-09 20:11:09 --> Utf8 Class Initialized
INFO - 2018-01-09 20:11:09 --> URI Class Initialized
INFO - 2018-01-09 20:11:09 --> Router Class Initialized
INFO - 2018-01-09 20:11:09 --> Output Class Initialized
INFO - 2018-01-09 20:11:09 --> Security Class Initialized
DEBUG - 2018-01-09 20:11:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-09 20:11:09 --> Input Class Initialized
INFO - 2018-01-09 20:11:09 --> Language Class Initialized
INFO - 2018-01-09 20:11:09 --> Loader Class Initialized
INFO - 2018-01-09 20:11:09 --> Helper loaded: url_helper
INFO - 2018-01-09 20:11:09 --> Helper loaded: form_helper
INFO - 2018-01-09 20:11:09 --> Database Driver Class Initialized
DEBUG - 2018-01-09 20:11:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-09 20:11:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-09 20:11:09 --> Form Validation Class Initialized
INFO - 2018-01-09 20:11:09 --> Model Class Initialized
INFO - 2018-01-09 20:11:09 --> Controller Class Initialized
INFO - 2018-01-09 20:11:09 --> Model Class Initialized
INFO - 2018-01-09 20:11:09 --> Model Class Initialized
INFO - 2018-01-09 20:11:09 --> Model Class Initialized
INFO - 2018-01-09 20:11:09 --> Model Class Initialized
DEBUG - 2018-01-09 20:11:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-09 20:11:18 --> Config Class Initialized
INFO - 2018-01-09 20:11:18 --> Hooks Class Initialized
DEBUG - 2018-01-09 20:11:18 --> UTF-8 Support Enabled
INFO - 2018-01-09 20:11:18 --> Utf8 Class Initialized
INFO - 2018-01-09 20:11:18 --> URI Class Initialized
INFO - 2018-01-09 20:11:18 --> Router Class Initialized
INFO - 2018-01-09 20:11:18 --> Output Class Initialized
INFO - 2018-01-09 20:11:18 --> Security Class Initialized
DEBUG - 2018-01-09 20:11:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-09 20:11:18 --> Input Class Initialized
INFO - 2018-01-09 20:11:18 --> Language Class Initialized
INFO - 2018-01-09 20:11:18 --> Loader Class Initialized
INFO - 2018-01-09 20:11:18 --> Helper loaded: url_helper
INFO - 2018-01-09 20:11:19 --> Helper loaded: form_helper
INFO - 2018-01-09 20:11:19 --> Database Driver Class Initialized
DEBUG - 2018-01-09 20:11:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-09 20:11:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-09 20:11:19 --> Form Validation Class Initialized
INFO - 2018-01-09 20:11:19 --> Model Class Initialized
INFO - 2018-01-09 20:11:19 --> Controller Class Initialized
INFO - 2018-01-09 20:11:19 --> Model Class Initialized
DEBUG - 2018-01-09 20:11:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-09 20:11:19 --> Config Class Initialized
INFO - 2018-01-09 20:11:19 --> Hooks Class Initialized
DEBUG - 2018-01-09 20:11:19 --> UTF-8 Support Enabled
INFO - 2018-01-09 20:11:19 --> Utf8 Class Initialized
INFO - 2018-01-09 20:11:19 --> URI Class Initialized
INFO - 2018-01-09 20:11:19 --> Router Class Initialized
INFO - 2018-01-09 20:11:19 --> Output Class Initialized
INFO - 2018-01-09 20:11:19 --> Security Class Initialized
DEBUG - 2018-01-09 20:11:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-09 20:11:19 --> Input Class Initialized
INFO - 2018-01-09 20:11:19 --> Language Class Initialized
INFO - 2018-01-09 20:11:19 --> Loader Class Initialized
INFO - 2018-01-09 20:11:19 --> Helper loaded: url_helper
INFO - 2018-01-09 20:11:19 --> Helper loaded: form_helper
INFO - 2018-01-09 20:11:19 --> Database Driver Class Initialized
DEBUG - 2018-01-09 20:11:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-09 20:11:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-09 20:11:19 --> Form Validation Class Initialized
INFO - 2018-01-09 20:11:19 --> Model Class Initialized
INFO - 2018-01-09 20:11:19 --> Controller Class Initialized
INFO - 2018-01-09 20:11:19 --> Model Class Initialized
DEBUG - 2018-01-09 20:11:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-09 20:11:19 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-09 20:11:19 --> Final output sent to browser
DEBUG - 2018-01-09 20:11:19 --> Total execution time: 0.3399
