<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-12-31 19:41:42 --> Config Class Initialized
INFO - 2017-12-31 19:41:42 --> Hooks Class Initialized
DEBUG - 2017-12-31 19:41:42 --> UTF-8 Support Enabled
INFO - 2017-12-31 19:41:42 --> Utf8 Class Initialized
INFO - 2017-12-31 19:41:42 --> URI Class Initialized
DEBUG - 2017-12-31 19:41:42 --> No URI present. Default controller set.
INFO - 2017-12-31 19:41:42 --> Router Class Initialized
INFO - 2017-12-31 19:41:42 --> Output Class Initialized
INFO - 2017-12-31 19:41:42 --> Security Class Initialized
DEBUG - 2017-12-31 19:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-31 19:41:42 --> Input Class Initialized
INFO - 2017-12-31 19:41:42 --> Language Class Initialized
INFO - 2017-12-31 19:41:42 --> Loader Class Initialized
INFO - 2017-12-31 19:41:42 --> Helper loaded: url_helper
INFO - 2017-12-31 19:41:42 --> Helper loaded: form_helper
INFO - 2017-12-31 19:41:42 --> Database Driver Class Initialized
DEBUG - 2017-12-31 19:41:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-31 19:41:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-31 19:41:42 --> Form Validation Class Initialized
INFO - 2017-12-31 19:41:42 --> Model Class Initialized
INFO - 2017-12-31 19:41:42 --> Controller Class Initialized
INFO - 2017-12-31 19:41:42 --> Config Class Initialized
INFO - 2017-12-31 19:41:42 --> Hooks Class Initialized
DEBUG - 2017-12-31 19:41:42 --> UTF-8 Support Enabled
INFO - 2017-12-31 19:41:42 --> Utf8 Class Initialized
INFO - 2017-12-31 19:41:42 --> URI Class Initialized
INFO - 2017-12-31 19:41:42 --> Config Class Initialized
INFO - 2017-12-31 19:41:42 --> Hooks Class Initialized
DEBUG - 2017-12-31 19:41:42 --> UTF-8 Support Enabled
INFO - 2017-12-31 19:41:42 --> Utf8 Class Initialized
INFO - 2017-12-31 19:41:42 --> URI Class Initialized
INFO - 2017-12-31 19:41:42 --> Router Class Initialized
INFO - 2017-12-31 19:41:42 --> Router Class Initialized
INFO - 2017-12-31 19:41:42 --> Output Class Initialized
INFO - 2017-12-31 19:41:42 --> Output Class Initialized
INFO - 2017-12-31 19:41:42 --> Security Class Initialized
INFO - 2017-12-31 19:41:42 --> Security Class Initialized
DEBUG - 2017-12-31 19:41:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-31 19:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-31 19:41:42 --> Input Class Initialized
INFO - 2017-12-31 19:41:42 --> Input Class Initialized
INFO - 2017-12-31 19:41:42 --> Language Class Initialized
INFO - 2017-12-31 19:41:42 --> Language Class Initialized
ERROR - 2017-12-31 19:41:42 --> 404 Page Not Found: Faviconico/index
INFO - 2017-12-31 19:41:42 --> Loader Class Initialized
INFO - 2017-12-31 19:41:42 --> Helper loaded: url_helper
INFO - 2017-12-31 19:41:42 --> Helper loaded: form_helper
INFO - 2017-12-31 19:41:42 --> Database Driver Class Initialized
DEBUG - 2017-12-31 19:41:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-31 19:41:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-31 19:41:42 --> Form Validation Class Initialized
INFO - 2017-12-31 19:41:42 --> Model Class Initialized
INFO - 2017-12-31 19:41:42 --> Controller Class Initialized
INFO - 2017-12-31 19:41:42 --> Model Class Initialized
DEBUG - 2017-12-31 19:41:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-31 19:41:42 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-31 19:41:42 --> Final output sent to browser
DEBUG - 2017-12-31 19:41:42 --> Total execution time: 0.1608
INFO - 2017-12-31 19:42:03 --> Config Class Initialized
INFO - 2017-12-31 19:42:03 --> Hooks Class Initialized
DEBUG - 2017-12-31 19:42:03 --> UTF-8 Support Enabled
INFO - 2017-12-31 19:42:03 --> Utf8 Class Initialized
INFO - 2017-12-31 19:42:03 --> URI Class Initialized
INFO - 2017-12-31 19:42:03 --> Router Class Initialized
INFO - 2017-12-31 19:42:03 --> Output Class Initialized
INFO - 2017-12-31 19:42:03 --> Security Class Initialized
DEBUG - 2017-12-31 19:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-31 19:42:03 --> Input Class Initialized
INFO - 2017-12-31 19:42:03 --> Language Class Initialized
INFO - 2017-12-31 19:42:03 --> Loader Class Initialized
INFO - 2017-12-31 19:42:03 --> Helper loaded: url_helper
INFO - 2017-12-31 19:42:03 --> Helper loaded: form_helper
INFO - 2017-12-31 19:42:03 --> Database Driver Class Initialized
DEBUG - 2017-12-31 19:42:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-31 19:42:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-31 19:42:03 --> Form Validation Class Initialized
INFO - 2017-12-31 19:42:03 --> Model Class Initialized
INFO - 2017-12-31 19:42:03 --> Controller Class Initialized
INFO - 2017-12-31 19:42:03 --> Model Class Initialized
DEBUG - 2017-12-31 19:42:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-31 19:42:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-12-31 19:42:03 --> Config Class Initialized
INFO - 2017-12-31 19:42:03 --> Hooks Class Initialized
DEBUG - 2017-12-31 19:42:03 --> UTF-8 Support Enabled
INFO - 2017-12-31 19:42:03 --> Utf8 Class Initialized
INFO - 2017-12-31 19:42:03 --> URI Class Initialized
DEBUG - 2017-12-31 19:42:03 --> No URI present. Default controller set.
INFO - 2017-12-31 19:42:03 --> Router Class Initialized
INFO - 2017-12-31 19:42:03 --> Output Class Initialized
INFO - 2017-12-31 19:42:03 --> Security Class Initialized
DEBUG - 2017-12-31 19:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-31 19:42:03 --> Input Class Initialized
INFO - 2017-12-31 19:42:03 --> Language Class Initialized
INFO - 2017-12-31 19:42:03 --> Loader Class Initialized
INFO - 2017-12-31 19:42:03 --> Helper loaded: url_helper
INFO - 2017-12-31 19:42:03 --> Helper loaded: form_helper
INFO - 2017-12-31 19:42:03 --> Database Driver Class Initialized
DEBUG - 2017-12-31 19:42:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-31 19:42:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-31 19:42:03 --> Form Validation Class Initialized
INFO - 2017-12-31 19:42:03 --> Model Class Initialized
INFO - 2017-12-31 19:42:03 --> Controller Class Initialized
INFO - 2017-12-31 19:42:03 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-31 19:42:03 --> Final output sent to browser
DEBUG - 2017-12-31 19:42:03 --> Total execution time: 0.0503
INFO - 2017-12-31 19:42:03 --> Config Class Initialized
INFO - 2017-12-31 19:42:03 --> Hooks Class Initialized
DEBUG - 2017-12-31 19:42:03 --> UTF-8 Support Enabled
INFO - 2017-12-31 19:42:03 --> Utf8 Class Initialized
INFO - 2017-12-31 19:42:03 --> URI Class Initialized
INFO - 2017-12-31 19:42:03 --> Router Class Initialized
INFO - 2017-12-31 19:42:03 --> Output Class Initialized
INFO - 2017-12-31 19:42:03 --> Security Class Initialized
DEBUG - 2017-12-31 19:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-31 19:42:03 --> Input Class Initialized
INFO - 2017-12-31 19:42:03 --> Language Class Initialized
INFO - 2017-12-31 19:42:03 --> Loader Class Initialized
INFO - 2017-12-31 19:42:03 --> Helper loaded: url_helper
INFO - 2017-12-31 19:42:03 --> Helper loaded: form_helper
INFO - 2017-12-31 19:42:03 --> Database Driver Class Initialized
DEBUG - 2017-12-31 19:42:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-31 19:42:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-31 19:42:03 --> Form Validation Class Initialized
INFO - 2017-12-31 19:42:03 --> Model Class Initialized
INFO - 2017-12-31 19:42:03 --> Controller Class Initialized
INFO - 2017-12-31 19:42:03 --> Model Class Initialized
INFO - 2017-12-31 19:42:03 --> Model Class Initialized
INFO - 2017-12-31 19:42:03 --> Model Class Initialized
INFO - 2017-12-31 19:42:03 --> Model Class Initialized
DEBUG - 2017-12-31 19:42:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-31 19:42:16 --> Config Class Initialized
INFO - 2017-12-31 19:42:16 --> Hooks Class Initialized
DEBUG - 2017-12-31 19:42:16 --> UTF-8 Support Enabled
INFO - 2017-12-31 19:42:16 --> Utf8 Class Initialized
INFO - 2017-12-31 19:42:16 --> URI Class Initialized
INFO - 2017-12-31 19:42:16 --> Router Class Initialized
INFO - 2017-12-31 19:42:16 --> Output Class Initialized
INFO - 2017-12-31 19:42:16 --> Security Class Initialized
DEBUG - 2017-12-31 19:42:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-31 19:42:16 --> Input Class Initialized
INFO - 2017-12-31 19:42:16 --> Language Class Initialized
INFO - 2017-12-31 19:42:16 --> Loader Class Initialized
INFO - 2017-12-31 19:42:16 --> Helper loaded: url_helper
INFO - 2017-12-31 19:42:16 --> Helper loaded: form_helper
INFO - 2017-12-31 19:42:16 --> Database Driver Class Initialized
DEBUG - 2017-12-31 19:42:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-31 19:42:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-31 19:42:16 --> Form Validation Class Initialized
INFO - 2017-12-31 19:42:16 --> Model Class Initialized
INFO - 2017-12-31 19:42:16 --> Controller Class Initialized
INFO - 2017-12-31 19:42:16 --> Model Class Initialized
INFO - 2017-12-31 19:42:16 --> Model Class Initialized
DEBUG - 2017-12-31 19:42:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-31 19:42:16 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-31 19:42:16 --> Final output sent to browser
DEBUG - 2017-12-31 19:42:16 --> Total execution time: 0.1039
INFO - 2017-12-31 19:42:16 --> Config Class Initialized
INFO - 2017-12-31 19:42:16 --> Hooks Class Initialized
DEBUG - 2017-12-31 19:42:16 --> UTF-8 Support Enabled
INFO - 2017-12-31 19:42:16 --> Utf8 Class Initialized
INFO - 2017-12-31 19:42:16 --> URI Class Initialized
INFO - 2017-12-31 19:42:16 --> Router Class Initialized
INFO - 2017-12-31 19:42:16 --> Output Class Initialized
INFO - 2017-12-31 19:42:16 --> Security Class Initialized
DEBUG - 2017-12-31 19:42:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-31 19:42:16 --> Input Class Initialized
INFO - 2017-12-31 19:42:16 --> Language Class Initialized
INFO - 2017-12-31 19:42:16 --> Loader Class Initialized
INFO - 2017-12-31 19:42:16 --> Helper loaded: url_helper
INFO - 2017-12-31 19:42:16 --> Helper loaded: form_helper
INFO - 2017-12-31 19:42:16 --> Database Driver Class Initialized
DEBUG - 2017-12-31 19:42:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-31 19:42:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-31 19:42:16 --> Form Validation Class Initialized
INFO - 2017-12-31 19:42:16 --> Model Class Initialized
INFO - 2017-12-31 19:42:16 --> Controller Class Initialized
INFO - 2017-12-31 19:42:16 --> Model Class Initialized
INFO - 2017-12-31 19:42:16 --> Model Class Initialized
DEBUG - 2017-12-31 19:42:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-31 19:42:20 --> Config Class Initialized
INFO - 2017-12-31 19:42:20 --> Hooks Class Initialized
DEBUG - 2017-12-31 19:42:20 --> UTF-8 Support Enabled
INFO - 2017-12-31 19:42:20 --> Utf8 Class Initialized
INFO - 2017-12-31 19:42:20 --> URI Class Initialized
INFO - 2017-12-31 19:42:20 --> Router Class Initialized
INFO - 2017-12-31 19:42:20 --> Output Class Initialized
INFO - 2017-12-31 19:42:20 --> Security Class Initialized
DEBUG - 2017-12-31 19:42:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-31 19:42:20 --> Input Class Initialized
INFO - 2017-12-31 19:42:20 --> Language Class Initialized
INFO - 2017-12-31 19:42:20 --> Loader Class Initialized
INFO - 2017-12-31 19:42:20 --> Helper loaded: url_helper
INFO - 2017-12-31 19:42:20 --> Helper loaded: form_helper
INFO - 2017-12-31 19:42:20 --> Database Driver Class Initialized
DEBUG - 2017-12-31 19:42:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-31 19:42:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-31 19:42:20 --> Form Validation Class Initialized
INFO - 2017-12-31 19:42:20 --> Model Class Initialized
INFO - 2017-12-31 19:42:20 --> Controller Class Initialized
INFO - 2017-12-31 19:42:20 --> Model Class Initialized
INFO - 2017-12-31 19:42:20 --> Model Class Initialized
DEBUG - 2017-12-31 19:42:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-31 19:42:20 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-31 19:42:20 --> Final output sent to browser
DEBUG - 2017-12-31 19:42:20 --> Total execution time: 0.0763
INFO - 2017-12-31 19:42:22 --> Config Class Initialized
INFO - 2017-12-31 19:42:22 --> Hooks Class Initialized
DEBUG - 2017-12-31 19:42:22 --> UTF-8 Support Enabled
INFO - 2017-12-31 19:42:22 --> Utf8 Class Initialized
INFO - 2017-12-31 19:42:22 --> URI Class Initialized
INFO - 2017-12-31 19:42:22 --> Router Class Initialized
INFO - 2017-12-31 19:42:22 --> Output Class Initialized
INFO - 2017-12-31 19:42:22 --> Security Class Initialized
DEBUG - 2017-12-31 19:42:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-31 19:42:22 --> Input Class Initialized
INFO - 2017-12-31 19:42:22 --> Language Class Initialized
INFO - 2017-12-31 19:42:22 --> Loader Class Initialized
INFO - 2017-12-31 19:42:22 --> Helper loaded: url_helper
INFO - 2017-12-31 19:42:22 --> Helper loaded: form_helper
INFO - 2017-12-31 19:42:22 --> Database Driver Class Initialized
DEBUG - 2017-12-31 19:42:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-31 19:42:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-31 19:42:22 --> Form Validation Class Initialized
INFO - 2017-12-31 19:42:22 --> Model Class Initialized
INFO - 2017-12-31 19:42:22 --> Controller Class Initialized
INFO - 2017-12-31 19:42:22 --> Model Class Initialized
INFO - 2017-12-31 19:42:22 --> Model Class Initialized
DEBUG - 2017-12-31 19:42:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-31 19:42:22 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-31 19:42:22 --> Final output sent to browser
DEBUG - 2017-12-31 19:42:22 --> Total execution time: 0.0423
INFO - 2017-12-31 19:42:22 --> Config Class Initialized
INFO - 2017-12-31 19:42:22 --> Hooks Class Initialized
DEBUG - 2017-12-31 19:42:22 --> UTF-8 Support Enabled
INFO - 2017-12-31 19:42:22 --> Utf8 Class Initialized
INFO - 2017-12-31 19:42:22 --> URI Class Initialized
INFO - 2017-12-31 19:42:22 --> Router Class Initialized
INFO - 2017-12-31 19:42:22 --> Output Class Initialized
INFO - 2017-12-31 19:42:22 --> Security Class Initialized
DEBUG - 2017-12-31 19:42:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-31 19:42:22 --> Input Class Initialized
INFO - 2017-12-31 19:42:22 --> Language Class Initialized
INFO - 2017-12-31 19:42:22 --> Loader Class Initialized
INFO - 2017-12-31 19:42:22 --> Helper loaded: url_helper
INFO - 2017-12-31 19:42:22 --> Helper loaded: form_helper
INFO - 2017-12-31 19:42:22 --> Database Driver Class Initialized
DEBUG - 2017-12-31 19:42:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-31 19:42:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-31 19:42:22 --> Form Validation Class Initialized
INFO - 2017-12-31 19:42:22 --> Model Class Initialized
INFO - 2017-12-31 19:42:22 --> Controller Class Initialized
INFO - 2017-12-31 19:42:22 --> Model Class Initialized
INFO - 2017-12-31 19:42:22 --> Model Class Initialized
DEBUG - 2017-12-31 19:42:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-31 19:42:29 --> Config Class Initialized
INFO - 2017-12-31 19:42:29 --> Hooks Class Initialized
DEBUG - 2017-12-31 19:42:29 --> UTF-8 Support Enabled
INFO - 2017-12-31 19:42:29 --> Utf8 Class Initialized
INFO - 2017-12-31 19:42:29 --> URI Class Initialized
INFO - 2017-12-31 19:42:29 --> Router Class Initialized
INFO - 2017-12-31 19:42:29 --> Output Class Initialized
INFO - 2017-12-31 19:42:29 --> Security Class Initialized
DEBUG - 2017-12-31 19:42:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-31 19:42:29 --> Input Class Initialized
INFO - 2017-12-31 19:42:29 --> Language Class Initialized
INFO - 2017-12-31 19:42:29 --> Loader Class Initialized
INFO - 2017-12-31 19:42:29 --> Helper loaded: url_helper
INFO - 2017-12-31 19:42:29 --> Helper loaded: form_helper
INFO - 2017-12-31 19:42:29 --> Database Driver Class Initialized
DEBUG - 2017-12-31 19:42:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-31 19:42:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-31 19:42:29 --> Form Validation Class Initialized
INFO - 2017-12-31 19:42:29 --> Model Class Initialized
INFO - 2017-12-31 19:42:29 --> Controller Class Initialized
INFO - 2017-12-31 19:42:29 --> Model Class Initialized
INFO - 2017-12-31 19:42:29 --> Model Class Initialized
DEBUG - 2017-12-31 19:42:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-31 19:42:33 --> Config Class Initialized
INFO - 2017-12-31 19:42:33 --> Hooks Class Initialized
DEBUG - 2017-12-31 19:42:33 --> UTF-8 Support Enabled
INFO - 2017-12-31 19:42:33 --> Utf8 Class Initialized
INFO - 2017-12-31 19:42:33 --> URI Class Initialized
INFO - 2017-12-31 19:42:33 --> Router Class Initialized
INFO - 2017-12-31 19:42:33 --> Output Class Initialized
INFO - 2017-12-31 19:42:33 --> Security Class Initialized
DEBUG - 2017-12-31 19:42:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-31 19:42:33 --> Input Class Initialized
INFO - 2017-12-31 19:42:33 --> Language Class Initialized
INFO - 2017-12-31 19:42:33 --> Loader Class Initialized
INFO - 2017-12-31 19:42:33 --> Helper loaded: url_helper
INFO - 2017-12-31 19:42:33 --> Helper loaded: form_helper
INFO - 2017-12-31 19:42:33 --> Database Driver Class Initialized
DEBUG - 2017-12-31 19:42:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-31 19:42:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-31 19:42:33 --> Form Validation Class Initialized
INFO - 2017-12-31 19:42:33 --> Model Class Initialized
INFO - 2017-12-31 19:42:33 --> Controller Class Initialized
INFO - 2017-12-31 19:42:33 --> Model Class Initialized
INFO - 2017-12-31 19:42:33 --> Model Class Initialized
DEBUG - 2017-12-31 19:42:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-31 19:42:39 --> Config Class Initialized
INFO - 2017-12-31 19:42:39 --> Hooks Class Initialized
DEBUG - 2017-12-31 19:42:39 --> UTF-8 Support Enabled
INFO - 2017-12-31 19:42:39 --> Utf8 Class Initialized
INFO - 2017-12-31 19:42:39 --> URI Class Initialized
INFO - 2017-12-31 19:42:39 --> Router Class Initialized
INFO - 2017-12-31 19:42:39 --> Output Class Initialized
INFO - 2017-12-31 19:42:39 --> Security Class Initialized
DEBUG - 2017-12-31 19:42:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-31 19:42:39 --> Input Class Initialized
INFO - 2017-12-31 19:42:39 --> Language Class Initialized
INFO - 2017-12-31 19:42:39 --> Loader Class Initialized
INFO - 2017-12-31 19:42:39 --> Helper loaded: url_helper
INFO - 2017-12-31 19:42:39 --> Helper loaded: form_helper
INFO - 2017-12-31 19:42:39 --> Database Driver Class Initialized
DEBUG - 2017-12-31 19:42:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-31 19:42:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-31 19:42:39 --> Form Validation Class Initialized
INFO - 2017-12-31 19:42:39 --> Model Class Initialized
INFO - 2017-12-31 19:42:39 --> Controller Class Initialized
INFO - 2017-12-31 19:42:39 --> Model Class Initialized
INFO - 2017-12-31 19:42:39 --> Model Class Initialized
DEBUG - 2017-12-31 19:42:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-31 19:42:39 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-31 19:42:39 --> Final output sent to browser
DEBUG - 2017-12-31 19:42:39 --> Total execution time: 0.1000
INFO - 2017-12-31 19:42:39 --> Config Class Initialized
INFO - 2017-12-31 19:42:39 --> Hooks Class Initialized
DEBUG - 2017-12-31 19:42:39 --> UTF-8 Support Enabled
INFO - 2017-12-31 19:42:39 --> Utf8 Class Initialized
INFO - 2017-12-31 19:42:39 --> URI Class Initialized
INFO - 2017-12-31 19:42:39 --> Router Class Initialized
INFO - 2017-12-31 19:42:39 --> Output Class Initialized
INFO - 2017-12-31 19:42:39 --> Security Class Initialized
DEBUG - 2017-12-31 19:42:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-31 19:42:39 --> Input Class Initialized
INFO - 2017-12-31 19:42:39 --> Language Class Initialized
INFO - 2017-12-31 19:42:39 --> Loader Class Initialized
INFO - 2017-12-31 19:42:39 --> Helper loaded: url_helper
INFO - 2017-12-31 19:42:39 --> Helper loaded: form_helper
INFO - 2017-12-31 19:42:39 --> Database Driver Class Initialized
DEBUG - 2017-12-31 19:42:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-31 19:42:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-31 19:42:39 --> Form Validation Class Initialized
INFO - 2017-12-31 19:42:39 --> Model Class Initialized
INFO - 2017-12-31 19:42:39 --> Controller Class Initialized
INFO - 2017-12-31 19:42:39 --> Model Class Initialized
INFO - 2017-12-31 19:42:39 --> Model Class Initialized
DEBUG - 2017-12-31 19:42:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-31 19:43:04 --> Config Class Initialized
INFO - 2017-12-31 19:43:04 --> Hooks Class Initialized
DEBUG - 2017-12-31 19:43:04 --> UTF-8 Support Enabled
INFO - 2017-12-31 19:43:04 --> Utf8 Class Initialized
INFO - 2017-12-31 19:43:04 --> URI Class Initialized
INFO - 2017-12-31 19:43:04 --> Router Class Initialized
INFO - 2017-12-31 19:43:04 --> Output Class Initialized
INFO - 2017-12-31 19:43:04 --> Security Class Initialized
DEBUG - 2017-12-31 19:43:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-31 19:43:04 --> Input Class Initialized
INFO - 2017-12-31 19:43:04 --> Language Class Initialized
INFO - 2017-12-31 19:43:04 --> Loader Class Initialized
INFO - 2017-12-31 19:43:04 --> Helper loaded: url_helper
INFO - 2017-12-31 19:43:04 --> Helper loaded: form_helper
INFO - 2017-12-31 19:43:04 --> Database Driver Class Initialized
DEBUG - 2017-12-31 19:43:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-31 19:43:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-31 19:43:04 --> Form Validation Class Initialized
INFO - 2017-12-31 19:43:04 --> Model Class Initialized
INFO - 2017-12-31 19:43:04 --> Controller Class Initialized
INFO - 2017-12-31 19:43:04 --> Model Class Initialized
INFO - 2017-12-31 19:43:04 --> Model Class Initialized
INFO - 2017-12-31 19:43:04 --> Model Class Initialized
INFO - 2017-12-31 19:43:04 --> Model Class Initialized
DEBUG - 2017-12-31 19:43:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-31 19:43:04 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-31 19:43:04 --> Final output sent to browser
DEBUG - 2017-12-31 19:43:04 --> Total execution time: 0.1062
INFO - 2017-12-31 19:43:04 --> Config Class Initialized
INFO - 2017-12-31 19:43:04 --> Hooks Class Initialized
DEBUG - 2017-12-31 19:43:04 --> UTF-8 Support Enabled
INFO - 2017-12-31 19:43:04 --> Utf8 Class Initialized
INFO - 2017-12-31 19:43:04 --> URI Class Initialized
INFO - 2017-12-31 19:43:04 --> Router Class Initialized
INFO - 2017-12-31 19:43:04 --> Output Class Initialized
INFO - 2017-12-31 19:43:04 --> Security Class Initialized
DEBUG - 2017-12-31 19:43:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-31 19:43:04 --> Input Class Initialized
INFO - 2017-12-31 19:43:04 --> Language Class Initialized
INFO - 2017-12-31 19:43:04 --> Loader Class Initialized
INFO - 2017-12-31 19:43:04 --> Helper loaded: url_helper
INFO - 2017-12-31 19:43:04 --> Helper loaded: form_helper
INFO - 2017-12-31 19:43:04 --> Database Driver Class Initialized
DEBUG - 2017-12-31 19:43:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-31 19:43:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-31 19:43:04 --> Form Validation Class Initialized
INFO - 2017-12-31 19:43:04 --> Model Class Initialized
INFO - 2017-12-31 19:43:04 --> Controller Class Initialized
INFO - 2017-12-31 19:43:04 --> Model Class Initialized
INFO - 2017-12-31 19:43:04 --> Model Class Initialized
INFO - 2017-12-31 19:43:04 --> Model Class Initialized
INFO - 2017-12-31 19:43:04 --> Model Class Initialized
DEBUG - 2017-12-31 19:43:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-31 19:43:07 --> Config Class Initialized
INFO - 2017-12-31 19:43:07 --> Hooks Class Initialized
DEBUG - 2017-12-31 19:43:07 --> UTF-8 Support Enabled
INFO - 2017-12-31 19:43:07 --> Utf8 Class Initialized
INFO - 2017-12-31 19:43:08 --> URI Class Initialized
INFO - 2017-12-31 19:43:08 --> Router Class Initialized
INFO - 2017-12-31 19:43:08 --> Output Class Initialized
INFO - 2017-12-31 19:43:08 --> Security Class Initialized
DEBUG - 2017-12-31 19:43:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-31 19:43:08 --> Input Class Initialized
INFO - 2017-12-31 19:43:08 --> Language Class Initialized
INFO - 2017-12-31 19:43:08 --> Loader Class Initialized
INFO - 2017-12-31 19:43:08 --> Helper loaded: url_helper
INFO - 2017-12-31 19:43:08 --> Helper loaded: form_helper
INFO - 2017-12-31 19:43:08 --> Database Driver Class Initialized
DEBUG - 2017-12-31 19:43:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-31 19:43:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-31 19:43:08 --> Form Validation Class Initialized
INFO - 2017-12-31 19:43:08 --> Model Class Initialized
INFO - 2017-12-31 19:43:08 --> Controller Class Initialized
INFO - 2017-12-31 19:43:08 --> Model Class Initialized
INFO - 2017-12-31 19:43:08 --> Model Class Initialized
INFO - 2017-12-31 19:43:08 --> Model Class Initialized
INFO - 2017-12-31 19:43:08 --> Model Class Initialized
DEBUG - 2017-12-31 19:43:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-31 19:43:08 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-31 19:43:08 --> Final output sent to browser
DEBUG - 2017-12-31 19:43:08 --> Total execution time: 0.1232
INFO - 2017-12-31 19:43:08 --> Config Class Initialized
INFO - 2017-12-31 19:43:08 --> Hooks Class Initialized
DEBUG - 2017-12-31 19:43:08 --> UTF-8 Support Enabled
INFO - 2017-12-31 19:43:08 --> Utf8 Class Initialized
INFO - 2017-12-31 19:43:08 --> URI Class Initialized
INFO - 2017-12-31 19:43:08 --> Router Class Initialized
INFO - 2017-12-31 19:43:08 --> Output Class Initialized
INFO - 2017-12-31 19:43:08 --> Security Class Initialized
DEBUG - 2017-12-31 19:43:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-31 19:43:08 --> Input Class Initialized
INFO - 2017-12-31 19:43:08 --> Language Class Initialized
INFO - 2017-12-31 19:43:08 --> Loader Class Initialized
INFO - 2017-12-31 19:43:08 --> Helper loaded: url_helper
INFO - 2017-12-31 19:43:08 --> Helper loaded: form_helper
INFO - 2017-12-31 19:43:08 --> Database Driver Class Initialized
DEBUG - 2017-12-31 19:43:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-31 19:43:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-31 19:43:08 --> Form Validation Class Initialized
INFO - 2017-12-31 19:43:08 --> Model Class Initialized
INFO - 2017-12-31 19:43:08 --> Controller Class Initialized
INFO - 2017-12-31 19:43:08 --> Model Class Initialized
INFO - 2017-12-31 19:43:08 --> Model Class Initialized
INFO - 2017-12-31 19:43:08 --> Model Class Initialized
INFO - 2017-12-31 19:43:08 --> Model Class Initialized
DEBUG - 2017-12-31 19:43:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-31 19:43:59 --> Config Class Initialized
INFO - 2017-12-31 19:43:59 --> Hooks Class Initialized
DEBUG - 2017-12-31 19:43:59 --> UTF-8 Support Enabled
INFO - 2017-12-31 19:43:59 --> Utf8 Class Initialized
INFO - 2017-12-31 19:43:59 --> URI Class Initialized
INFO - 2017-12-31 19:43:59 --> Router Class Initialized
INFO - 2017-12-31 19:43:59 --> Output Class Initialized
INFO - 2017-12-31 19:43:59 --> Security Class Initialized
DEBUG - 2017-12-31 19:43:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-31 19:43:59 --> Input Class Initialized
INFO - 2017-12-31 19:43:59 --> Language Class Initialized
INFO - 2017-12-31 19:43:59 --> Loader Class Initialized
INFO - 2017-12-31 19:43:59 --> Helper loaded: url_helper
INFO - 2017-12-31 19:43:59 --> Helper loaded: form_helper
INFO - 2017-12-31 19:43:59 --> Database Driver Class Initialized
DEBUG - 2017-12-31 19:43:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-31 19:43:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-31 19:43:59 --> Form Validation Class Initialized
INFO - 2017-12-31 19:43:59 --> Model Class Initialized
INFO - 2017-12-31 19:43:59 --> Controller Class Initialized
INFO - 2017-12-31 19:43:59 --> Model Class Initialized
INFO - 2017-12-31 19:43:59 --> Model Class Initialized
INFO - 2017-12-31 19:43:59 --> Model Class Initialized
INFO - 2017-12-31 19:43:59 --> Model Class Initialized
DEBUG - 2017-12-31 19:43:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-31 19:43:59 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-31 19:43:59 --> Final output sent to browser
DEBUG - 2017-12-31 19:43:59 --> Total execution time: 0.1045
INFO - 2017-12-31 19:43:59 --> Config Class Initialized
INFO - 2017-12-31 19:43:59 --> Hooks Class Initialized
DEBUG - 2017-12-31 19:43:59 --> UTF-8 Support Enabled
INFO - 2017-12-31 19:43:59 --> Utf8 Class Initialized
INFO - 2017-12-31 19:43:59 --> URI Class Initialized
INFO - 2017-12-31 19:43:59 --> Router Class Initialized
INFO - 2017-12-31 19:43:59 --> Output Class Initialized
INFO - 2017-12-31 19:43:59 --> Security Class Initialized
DEBUG - 2017-12-31 19:43:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-31 19:43:59 --> Input Class Initialized
INFO - 2017-12-31 19:43:59 --> Language Class Initialized
INFO - 2017-12-31 19:43:59 --> Loader Class Initialized
INFO - 2017-12-31 19:43:59 --> Helper loaded: url_helper
INFO - 2017-12-31 19:43:59 --> Helper loaded: form_helper
INFO - 2017-12-31 19:43:59 --> Database Driver Class Initialized
DEBUG - 2017-12-31 19:43:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-31 19:43:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-31 19:43:59 --> Form Validation Class Initialized
INFO - 2017-12-31 19:43:59 --> Model Class Initialized
INFO - 2017-12-31 19:43:59 --> Controller Class Initialized
INFO - 2017-12-31 19:43:59 --> Model Class Initialized
INFO - 2017-12-31 19:43:59 --> Model Class Initialized
INFO - 2017-12-31 19:43:59 --> Model Class Initialized
INFO - 2017-12-31 19:43:59 --> Model Class Initialized
DEBUG - 2017-12-31 19:43:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-31 19:44:02 --> Config Class Initialized
INFO - 2017-12-31 19:44:02 --> Hooks Class Initialized
DEBUG - 2017-12-31 19:44:02 --> UTF-8 Support Enabled
INFO - 2017-12-31 19:44:02 --> Utf8 Class Initialized
INFO - 2017-12-31 19:44:02 --> URI Class Initialized
INFO - 2017-12-31 19:44:02 --> Router Class Initialized
INFO - 2017-12-31 19:44:02 --> Output Class Initialized
INFO - 2017-12-31 19:44:02 --> Security Class Initialized
DEBUG - 2017-12-31 19:44:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-31 19:44:02 --> Input Class Initialized
INFO - 2017-12-31 19:44:02 --> Language Class Initialized
INFO - 2017-12-31 19:44:02 --> Loader Class Initialized
INFO - 2017-12-31 19:44:02 --> Helper loaded: url_helper
INFO - 2017-12-31 19:44:02 --> Helper loaded: form_helper
INFO - 2017-12-31 19:44:02 --> Database Driver Class Initialized
DEBUG - 2017-12-31 19:44:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-31 19:44:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-31 19:44:02 --> Form Validation Class Initialized
INFO - 2017-12-31 19:44:02 --> Model Class Initialized
INFO - 2017-12-31 19:44:02 --> Controller Class Initialized
INFO - 2017-12-31 19:44:02 --> Model Class Initialized
INFO - 2017-12-31 19:44:02 --> Model Class Initialized
INFO - 2017-12-31 19:44:02 --> Model Class Initialized
INFO - 2017-12-31 19:44:03 --> Model Class Initialized
DEBUG - 2017-12-31 19:44:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-31 19:44:03 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-31 19:44:03 --> Final output sent to browser
DEBUG - 2017-12-31 19:44:03 --> Total execution time: 0.0925
INFO - 2017-12-31 19:44:09 --> Config Class Initialized
INFO - 2017-12-31 19:44:09 --> Hooks Class Initialized
DEBUG - 2017-12-31 19:44:09 --> UTF-8 Support Enabled
INFO - 2017-12-31 19:44:09 --> Utf8 Class Initialized
INFO - 2017-12-31 19:44:09 --> URI Class Initialized
INFO - 2017-12-31 19:44:09 --> Router Class Initialized
INFO - 2017-12-31 19:44:09 --> Output Class Initialized
INFO - 2017-12-31 19:44:09 --> Security Class Initialized
DEBUG - 2017-12-31 19:44:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-31 19:44:09 --> Input Class Initialized
INFO - 2017-12-31 19:44:09 --> Language Class Initialized
INFO - 2017-12-31 19:44:09 --> Loader Class Initialized
INFO - 2017-12-31 19:44:09 --> Helper loaded: url_helper
INFO - 2017-12-31 19:44:09 --> Helper loaded: form_helper
INFO - 2017-12-31 19:44:09 --> Database Driver Class Initialized
DEBUG - 2017-12-31 19:44:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-31 19:44:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-31 19:44:09 --> Form Validation Class Initialized
INFO - 2017-12-31 19:44:09 --> Model Class Initialized
INFO - 2017-12-31 19:44:09 --> Controller Class Initialized
INFO - 2017-12-31 19:44:09 --> Model Class Initialized
INFO - 2017-12-31 19:44:09 --> Model Class Initialized
DEBUG - 2017-12-31 19:44:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-31 19:44:09 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-31 19:44:09 --> Final output sent to browser
DEBUG - 2017-12-31 19:44:09 --> Total execution time: 0.0419
INFO - 2017-12-31 19:44:09 --> Config Class Initialized
INFO - 2017-12-31 19:44:09 --> Hooks Class Initialized
DEBUG - 2017-12-31 19:44:09 --> UTF-8 Support Enabled
INFO - 2017-12-31 19:44:09 --> Utf8 Class Initialized
INFO - 2017-12-31 19:44:09 --> URI Class Initialized
INFO - 2017-12-31 19:44:09 --> Router Class Initialized
INFO - 2017-12-31 19:44:09 --> Output Class Initialized
INFO - 2017-12-31 19:44:09 --> Security Class Initialized
DEBUG - 2017-12-31 19:44:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-31 19:44:09 --> Input Class Initialized
INFO - 2017-12-31 19:44:09 --> Language Class Initialized
INFO - 2017-12-31 19:44:09 --> Loader Class Initialized
INFO - 2017-12-31 19:44:09 --> Helper loaded: url_helper
INFO - 2017-12-31 19:44:09 --> Helper loaded: form_helper
INFO - 2017-12-31 19:44:09 --> Database Driver Class Initialized
DEBUG - 2017-12-31 19:44:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-31 19:44:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-31 19:44:09 --> Form Validation Class Initialized
INFO - 2017-12-31 19:44:09 --> Model Class Initialized
INFO - 2017-12-31 19:44:09 --> Controller Class Initialized
INFO - 2017-12-31 19:44:09 --> Model Class Initialized
INFO - 2017-12-31 19:44:09 --> Model Class Initialized
DEBUG - 2017-12-31 19:44:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-31 19:44:10 --> Config Class Initialized
INFO - 2017-12-31 19:44:10 --> Hooks Class Initialized
DEBUG - 2017-12-31 19:44:10 --> UTF-8 Support Enabled
INFO - 2017-12-31 19:44:10 --> Utf8 Class Initialized
INFO - 2017-12-31 19:44:10 --> URI Class Initialized
INFO - 2017-12-31 19:44:10 --> Router Class Initialized
INFO - 2017-12-31 19:44:10 --> Output Class Initialized
INFO - 2017-12-31 19:44:10 --> Security Class Initialized
DEBUG - 2017-12-31 19:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-31 19:44:10 --> Input Class Initialized
INFO - 2017-12-31 19:44:10 --> Language Class Initialized
INFO - 2017-12-31 19:44:10 --> Loader Class Initialized
INFO - 2017-12-31 19:44:10 --> Helper loaded: url_helper
INFO - 2017-12-31 19:44:10 --> Helper loaded: form_helper
INFO - 2017-12-31 19:44:10 --> Database Driver Class Initialized
DEBUG - 2017-12-31 19:44:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-31 19:44:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-31 19:44:10 --> Form Validation Class Initialized
INFO - 2017-12-31 19:44:10 --> Model Class Initialized
INFO - 2017-12-31 19:44:10 --> Controller Class Initialized
INFO - 2017-12-31 19:44:10 --> Model Class Initialized
INFO - 2017-12-31 19:44:10 --> Model Class Initialized
INFO - 2017-12-31 19:44:10 --> Model Class Initialized
INFO - 2017-12-31 19:44:10 --> Model Class Initialized
DEBUG - 2017-12-31 19:44:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-31 19:44:10 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-31 19:44:10 --> Final output sent to browser
DEBUG - 2017-12-31 19:44:10 --> Total execution time: 0.0475
INFO - 2017-12-31 19:44:10 --> Config Class Initialized
INFO - 2017-12-31 19:44:10 --> Hooks Class Initialized
DEBUG - 2017-12-31 19:44:10 --> UTF-8 Support Enabled
INFO - 2017-12-31 19:44:10 --> Utf8 Class Initialized
INFO - 2017-12-31 19:44:10 --> URI Class Initialized
INFO - 2017-12-31 19:44:10 --> Router Class Initialized
INFO - 2017-12-31 19:44:10 --> Output Class Initialized
INFO - 2017-12-31 19:44:10 --> Security Class Initialized
DEBUG - 2017-12-31 19:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-31 19:44:10 --> Input Class Initialized
INFO - 2017-12-31 19:44:10 --> Language Class Initialized
INFO - 2017-12-31 19:44:10 --> Loader Class Initialized
INFO - 2017-12-31 19:44:10 --> Helper loaded: url_helper
INFO - 2017-12-31 19:44:10 --> Helper loaded: form_helper
INFO - 2017-12-31 19:44:10 --> Database Driver Class Initialized
DEBUG - 2017-12-31 19:44:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-31 19:44:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-31 19:44:10 --> Form Validation Class Initialized
INFO - 2017-12-31 19:44:10 --> Model Class Initialized
INFO - 2017-12-31 19:44:10 --> Controller Class Initialized
INFO - 2017-12-31 19:44:10 --> Model Class Initialized
INFO - 2017-12-31 19:44:10 --> Model Class Initialized
INFO - 2017-12-31 19:44:10 --> Model Class Initialized
INFO - 2017-12-31 19:44:10 --> Model Class Initialized
DEBUG - 2017-12-31 19:44:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-31 19:44:12 --> Config Class Initialized
INFO - 2017-12-31 19:44:12 --> Hooks Class Initialized
DEBUG - 2017-12-31 19:44:12 --> UTF-8 Support Enabled
INFO - 2017-12-31 19:44:12 --> Utf8 Class Initialized
INFO - 2017-12-31 19:44:12 --> URI Class Initialized
INFO - 2017-12-31 19:44:12 --> Router Class Initialized
INFO - 2017-12-31 19:44:12 --> Output Class Initialized
INFO - 2017-12-31 19:44:12 --> Security Class Initialized
DEBUG - 2017-12-31 19:44:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-31 19:44:12 --> Input Class Initialized
INFO - 2017-12-31 19:44:12 --> Language Class Initialized
INFO - 2017-12-31 19:44:12 --> Loader Class Initialized
INFO - 2017-12-31 19:44:12 --> Helper loaded: url_helper
INFO - 2017-12-31 19:44:12 --> Helper loaded: form_helper
INFO - 2017-12-31 19:44:12 --> Database Driver Class Initialized
DEBUG - 2017-12-31 19:44:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-31 19:44:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-31 19:44:12 --> Form Validation Class Initialized
INFO - 2017-12-31 19:44:12 --> Model Class Initialized
INFO - 2017-12-31 19:44:12 --> Controller Class Initialized
INFO - 2017-12-31 19:44:12 --> Model Class Initialized
INFO - 2017-12-31 19:44:12 --> Model Class Initialized
INFO - 2017-12-31 19:44:12 --> Model Class Initialized
INFO - 2017-12-31 19:44:12 --> Model Class Initialized
DEBUG - 2017-12-31 19:44:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-31 19:44:12 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-31 19:44:12 --> Final output sent to browser
DEBUG - 2017-12-31 19:44:12 --> Total execution time: 0.0610
INFO - 2017-12-31 19:45:32 --> Config Class Initialized
INFO - 2017-12-31 19:45:32 --> Hooks Class Initialized
DEBUG - 2017-12-31 19:45:32 --> UTF-8 Support Enabled
INFO - 2017-12-31 19:45:32 --> Utf8 Class Initialized
INFO - 2017-12-31 19:45:32 --> URI Class Initialized
INFO - 2017-12-31 19:45:32 --> Router Class Initialized
INFO - 2017-12-31 19:45:32 --> Output Class Initialized
INFO - 2017-12-31 19:45:32 --> Security Class Initialized
DEBUG - 2017-12-31 19:45:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-31 19:45:32 --> Input Class Initialized
INFO - 2017-12-31 19:45:32 --> Language Class Initialized
INFO - 2017-12-31 19:45:32 --> Loader Class Initialized
INFO - 2017-12-31 19:45:32 --> Helper loaded: url_helper
INFO - 2017-12-31 19:45:32 --> Helper loaded: form_helper
INFO - 2017-12-31 19:45:32 --> Database Driver Class Initialized
DEBUG - 2017-12-31 19:45:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-31 19:45:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-31 19:45:32 --> Form Validation Class Initialized
INFO - 2017-12-31 19:45:32 --> Model Class Initialized
INFO - 2017-12-31 19:45:32 --> Controller Class Initialized
INFO - 2017-12-31 19:45:32 --> Model Class Initialized
INFO - 2017-12-31 19:45:32 --> Model Class Initialized
INFO - 2017-12-31 19:45:32 --> Model Class Initialized
INFO - 2017-12-31 19:45:32 --> Model Class Initialized
DEBUG - 2017-12-31 19:45:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-31 19:45:32 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-31 19:45:32 --> Final output sent to browser
DEBUG - 2017-12-31 19:45:32 --> Total execution time: 0.0568
INFO - 2017-12-31 19:45:32 --> Config Class Initialized
INFO - 2017-12-31 19:45:32 --> Hooks Class Initialized
DEBUG - 2017-12-31 19:45:32 --> UTF-8 Support Enabled
INFO - 2017-12-31 19:45:32 --> Utf8 Class Initialized
INFO - 2017-12-31 19:45:32 --> URI Class Initialized
INFO - 2017-12-31 19:45:32 --> Router Class Initialized
INFO - 2017-12-31 19:45:32 --> Output Class Initialized
INFO - 2017-12-31 19:45:32 --> Security Class Initialized
DEBUG - 2017-12-31 19:45:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-31 19:45:32 --> Input Class Initialized
INFO - 2017-12-31 19:45:32 --> Language Class Initialized
INFO - 2017-12-31 19:45:32 --> Loader Class Initialized
INFO - 2017-12-31 19:45:32 --> Helper loaded: url_helper
INFO - 2017-12-31 19:45:32 --> Helper loaded: form_helper
INFO - 2017-12-31 19:45:32 --> Database Driver Class Initialized
DEBUG - 2017-12-31 19:45:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-31 19:45:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-31 19:45:32 --> Form Validation Class Initialized
INFO - 2017-12-31 19:45:32 --> Model Class Initialized
INFO - 2017-12-31 19:45:32 --> Controller Class Initialized
INFO - 2017-12-31 19:45:32 --> Model Class Initialized
INFO - 2017-12-31 19:45:32 --> Model Class Initialized
INFO - 2017-12-31 19:45:32 --> Model Class Initialized
INFO - 2017-12-31 19:45:32 --> Model Class Initialized
DEBUG - 2017-12-31 19:45:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-31 19:45:35 --> Config Class Initialized
INFO - 2017-12-31 19:45:35 --> Hooks Class Initialized
DEBUG - 2017-12-31 19:45:35 --> UTF-8 Support Enabled
INFO - 2017-12-31 19:45:35 --> Utf8 Class Initialized
INFO - 2017-12-31 19:45:35 --> URI Class Initialized
INFO - 2017-12-31 19:45:35 --> Router Class Initialized
INFO - 2017-12-31 19:45:35 --> Output Class Initialized
INFO - 2017-12-31 19:45:35 --> Security Class Initialized
DEBUG - 2017-12-31 19:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-31 19:45:35 --> Input Class Initialized
INFO - 2017-12-31 19:45:35 --> Language Class Initialized
INFO - 2017-12-31 19:45:35 --> Loader Class Initialized
INFO - 2017-12-31 19:45:35 --> Helper loaded: url_helper
INFO - 2017-12-31 19:45:35 --> Helper loaded: form_helper
INFO - 2017-12-31 19:45:35 --> Database Driver Class Initialized
DEBUG - 2017-12-31 19:45:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-31 19:45:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-31 19:45:35 --> Form Validation Class Initialized
INFO - 2017-12-31 19:45:35 --> Model Class Initialized
INFO - 2017-12-31 19:45:35 --> Controller Class Initialized
INFO - 2017-12-31 19:45:35 --> Model Class Initialized
INFO - 2017-12-31 19:45:35 --> Model Class Initialized
INFO - 2017-12-31 19:45:35 --> Model Class Initialized
INFO - 2017-12-31 19:45:35 --> Model Class Initialized
DEBUG - 2017-12-31 19:45:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-31 19:45:35 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-31 19:45:35 --> Final output sent to browser
DEBUG - 2017-12-31 19:45:35 --> Total execution time: 0.0670
INFO - 2017-12-31 19:45:35 --> Config Class Initialized
INFO - 2017-12-31 19:45:35 --> Hooks Class Initialized
DEBUG - 2017-12-31 19:45:35 --> UTF-8 Support Enabled
INFO - 2017-12-31 19:45:35 --> Utf8 Class Initialized
INFO - 2017-12-31 19:45:35 --> URI Class Initialized
INFO - 2017-12-31 19:45:35 --> Router Class Initialized
INFO - 2017-12-31 19:45:35 --> Output Class Initialized
INFO - 2017-12-31 19:45:35 --> Security Class Initialized
DEBUG - 2017-12-31 19:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-31 19:45:35 --> Input Class Initialized
INFO - 2017-12-31 19:45:35 --> Language Class Initialized
INFO - 2017-12-31 19:45:35 --> Loader Class Initialized
INFO - 2017-12-31 19:45:35 --> Helper loaded: url_helper
INFO - 2017-12-31 19:45:35 --> Helper loaded: form_helper
INFO - 2017-12-31 19:45:35 --> Database Driver Class Initialized
DEBUG - 2017-12-31 19:45:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-31 19:45:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-31 19:45:35 --> Form Validation Class Initialized
INFO - 2017-12-31 19:45:35 --> Model Class Initialized
INFO - 2017-12-31 19:45:35 --> Controller Class Initialized
INFO - 2017-12-31 19:45:35 --> Model Class Initialized
INFO - 2017-12-31 19:45:35 --> Model Class Initialized
INFO - 2017-12-31 19:45:35 --> Model Class Initialized
INFO - 2017-12-31 19:45:35 --> Model Class Initialized
DEBUG - 2017-12-31 19:45:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-31 19:45:37 --> Config Class Initialized
INFO - 2017-12-31 19:45:37 --> Hooks Class Initialized
DEBUG - 2017-12-31 19:45:37 --> UTF-8 Support Enabled
INFO - 2017-12-31 19:45:37 --> Utf8 Class Initialized
INFO - 2017-12-31 19:45:37 --> URI Class Initialized
INFO - 2017-12-31 19:45:37 --> Router Class Initialized
INFO - 2017-12-31 19:45:37 --> Output Class Initialized
INFO - 2017-12-31 19:45:37 --> Security Class Initialized
DEBUG - 2017-12-31 19:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-31 19:45:37 --> Input Class Initialized
INFO - 2017-12-31 19:45:37 --> Language Class Initialized
INFO - 2017-12-31 19:45:37 --> Loader Class Initialized
INFO - 2017-12-31 19:45:37 --> Helper loaded: url_helper
INFO - 2017-12-31 19:45:37 --> Helper loaded: form_helper
INFO - 2017-12-31 19:45:37 --> Database Driver Class Initialized
DEBUG - 2017-12-31 19:45:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-31 19:45:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-31 19:45:37 --> Form Validation Class Initialized
INFO - 2017-12-31 19:45:37 --> Model Class Initialized
INFO - 2017-12-31 19:45:37 --> Controller Class Initialized
INFO - 2017-12-31 19:45:37 --> Model Class Initialized
INFO - 2017-12-31 19:45:37 --> Model Class Initialized
INFO - 2017-12-31 19:45:37 --> Model Class Initialized
INFO - 2017-12-31 19:45:37 --> Model Class Initialized
DEBUG - 2017-12-31 19:45:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-31 19:45:37 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-31 19:45:37 --> Final output sent to browser
DEBUG - 2017-12-31 19:45:37 --> Total execution time: 0.0594
INFO - 2017-12-31 19:45:37 --> Config Class Initialized
INFO - 2017-12-31 19:45:37 --> Hooks Class Initialized
DEBUG - 2017-12-31 19:45:37 --> UTF-8 Support Enabled
INFO - 2017-12-31 19:45:37 --> Utf8 Class Initialized
INFO - 2017-12-31 19:45:37 --> URI Class Initialized
INFO - 2017-12-31 19:45:37 --> Router Class Initialized
INFO - 2017-12-31 19:45:37 --> Output Class Initialized
INFO - 2017-12-31 19:45:37 --> Security Class Initialized
DEBUG - 2017-12-31 19:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-31 19:45:37 --> Input Class Initialized
INFO - 2017-12-31 19:45:37 --> Language Class Initialized
INFO - 2017-12-31 19:45:37 --> Loader Class Initialized
INFO - 2017-12-31 19:45:37 --> Helper loaded: url_helper
INFO - 2017-12-31 19:45:37 --> Helper loaded: form_helper
INFO - 2017-12-31 19:45:37 --> Database Driver Class Initialized
DEBUG - 2017-12-31 19:45:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-31 19:45:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-31 19:45:37 --> Form Validation Class Initialized
INFO - 2017-12-31 19:45:37 --> Model Class Initialized
INFO - 2017-12-31 19:45:37 --> Controller Class Initialized
INFO - 2017-12-31 19:45:37 --> Model Class Initialized
INFO - 2017-12-31 19:45:37 --> Model Class Initialized
INFO - 2017-12-31 19:45:37 --> Model Class Initialized
INFO - 2017-12-31 19:45:37 --> Model Class Initialized
DEBUG - 2017-12-31 19:45:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-31 19:45:39 --> Config Class Initialized
INFO - 2017-12-31 19:45:39 --> Hooks Class Initialized
DEBUG - 2017-12-31 19:45:39 --> UTF-8 Support Enabled
INFO - 2017-12-31 19:45:39 --> Utf8 Class Initialized
INFO - 2017-12-31 19:45:39 --> URI Class Initialized
INFO - 2017-12-31 19:45:39 --> Router Class Initialized
INFO - 2017-12-31 19:45:39 --> Output Class Initialized
INFO - 2017-12-31 19:45:39 --> Security Class Initialized
DEBUG - 2017-12-31 19:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-31 19:45:39 --> Input Class Initialized
INFO - 2017-12-31 19:45:39 --> Language Class Initialized
INFO - 2017-12-31 19:45:39 --> Loader Class Initialized
INFO - 2017-12-31 19:45:39 --> Helper loaded: url_helper
INFO - 2017-12-31 19:45:39 --> Helper loaded: form_helper
INFO - 2017-12-31 19:45:39 --> Database Driver Class Initialized
DEBUG - 2017-12-31 19:45:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-31 19:45:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-31 19:45:39 --> Form Validation Class Initialized
INFO - 2017-12-31 19:45:39 --> Model Class Initialized
INFO - 2017-12-31 19:45:39 --> Controller Class Initialized
INFO - 2017-12-31 19:45:39 --> Model Class Initialized
INFO - 2017-12-31 19:45:39 --> Model Class Initialized
INFO - 2017-12-31 19:45:39 --> Model Class Initialized
INFO - 2017-12-31 19:45:39 --> Model Class Initialized
DEBUG - 2017-12-31 19:45:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-31 19:45:39 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-31 19:45:39 --> Final output sent to browser
DEBUG - 2017-12-31 19:45:39 --> Total execution time: 0.0749
INFO - 2017-12-31 19:45:49 --> Config Class Initialized
INFO - 2017-12-31 19:45:49 --> Hooks Class Initialized
DEBUG - 2017-12-31 19:45:49 --> UTF-8 Support Enabled
INFO - 2017-12-31 19:45:49 --> Utf8 Class Initialized
INFO - 2017-12-31 19:45:49 --> URI Class Initialized
INFO - 2017-12-31 19:45:49 --> Router Class Initialized
INFO - 2017-12-31 19:45:49 --> Output Class Initialized
INFO - 2017-12-31 19:45:49 --> Security Class Initialized
DEBUG - 2017-12-31 19:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-31 19:45:49 --> Input Class Initialized
INFO - 2017-12-31 19:45:49 --> Language Class Initialized
INFO - 2017-12-31 19:45:49 --> Loader Class Initialized
INFO - 2017-12-31 19:45:49 --> Helper loaded: url_helper
INFO - 2017-12-31 19:45:49 --> Helper loaded: form_helper
INFO - 2017-12-31 19:45:49 --> Database Driver Class Initialized
DEBUG - 2017-12-31 19:45:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-31 19:45:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-31 19:45:49 --> Form Validation Class Initialized
INFO - 2017-12-31 19:45:49 --> Model Class Initialized
INFO - 2017-12-31 19:45:49 --> Controller Class Initialized
INFO - 2017-12-31 19:45:49 --> Model Class Initialized
INFO - 2017-12-31 19:45:49 --> Model Class Initialized
INFO - 2017-12-31 19:45:49 --> Model Class Initialized
INFO - 2017-12-31 19:45:49 --> Model Class Initialized
DEBUG - 2017-12-31 19:45:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-31 19:45:49 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-31 19:45:49 --> Final output sent to browser
DEBUG - 2017-12-31 19:45:49 --> Total execution time: 0.0816
INFO - 2017-12-31 19:45:49 --> Config Class Initialized
INFO - 2017-12-31 19:45:49 --> Hooks Class Initialized
DEBUG - 2017-12-31 19:45:49 --> UTF-8 Support Enabled
INFO - 2017-12-31 19:45:49 --> Utf8 Class Initialized
INFO - 2017-12-31 19:45:49 --> URI Class Initialized
INFO - 2017-12-31 19:45:49 --> Router Class Initialized
INFO - 2017-12-31 19:45:49 --> Output Class Initialized
INFO - 2017-12-31 19:45:49 --> Security Class Initialized
DEBUG - 2017-12-31 19:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-31 19:45:49 --> Input Class Initialized
INFO - 2017-12-31 19:45:49 --> Language Class Initialized
INFO - 2017-12-31 19:45:49 --> Loader Class Initialized
INFO - 2017-12-31 19:45:49 --> Helper loaded: url_helper
INFO - 2017-12-31 19:45:49 --> Helper loaded: form_helper
INFO - 2017-12-31 19:45:49 --> Database Driver Class Initialized
DEBUG - 2017-12-31 19:45:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-31 19:45:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-31 19:45:49 --> Form Validation Class Initialized
INFO - 2017-12-31 19:45:49 --> Model Class Initialized
INFO - 2017-12-31 19:45:49 --> Controller Class Initialized
INFO - 2017-12-31 19:45:49 --> Model Class Initialized
INFO - 2017-12-31 19:45:49 --> Model Class Initialized
INFO - 2017-12-31 19:45:49 --> Model Class Initialized
INFO - 2017-12-31 19:45:49 --> Model Class Initialized
DEBUG - 2017-12-31 19:45:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-31 19:45:50 --> Config Class Initialized
INFO - 2017-12-31 19:45:50 --> Hooks Class Initialized
DEBUG - 2017-12-31 19:45:50 --> UTF-8 Support Enabled
INFO - 2017-12-31 19:45:50 --> Utf8 Class Initialized
INFO - 2017-12-31 19:45:50 --> URI Class Initialized
INFO - 2017-12-31 19:45:50 --> Router Class Initialized
INFO - 2017-12-31 19:45:50 --> Output Class Initialized
INFO - 2017-12-31 19:45:50 --> Security Class Initialized
DEBUG - 2017-12-31 19:45:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-31 19:45:50 --> Input Class Initialized
INFO - 2017-12-31 19:45:50 --> Language Class Initialized
INFO - 2017-12-31 19:45:50 --> Loader Class Initialized
INFO - 2017-12-31 19:45:50 --> Helper loaded: url_helper
INFO - 2017-12-31 19:45:50 --> Helper loaded: form_helper
INFO - 2017-12-31 19:45:50 --> Database Driver Class Initialized
DEBUG - 2017-12-31 19:45:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-31 19:45:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-31 19:45:50 --> Form Validation Class Initialized
INFO - 2017-12-31 19:45:50 --> Model Class Initialized
INFO - 2017-12-31 19:45:50 --> Controller Class Initialized
INFO - 2017-12-31 19:45:50 --> Model Class Initialized
INFO - 2017-12-31 19:45:50 --> Model Class Initialized
INFO - 2017-12-31 19:45:50 --> Model Class Initialized
INFO - 2017-12-31 19:45:50 --> Model Class Initialized
DEBUG - 2017-12-31 19:45:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-31 19:45:50 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-31 19:45:50 --> Final output sent to browser
DEBUG - 2017-12-31 19:45:50 --> Total execution time: 0.0723
INFO - 2017-12-31 19:45:50 --> Config Class Initialized
INFO - 2017-12-31 19:45:50 --> Hooks Class Initialized
DEBUG - 2017-12-31 19:45:50 --> UTF-8 Support Enabled
INFO - 2017-12-31 19:45:50 --> Utf8 Class Initialized
INFO - 2017-12-31 19:45:50 --> URI Class Initialized
INFO - 2017-12-31 19:45:50 --> Router Class Initialized
INFO - 2017-12-31 19:45:50 --> Output Class Initialized
INFO - 2017-12-31 19:45:50 --> Security Class Initialized
DEBUG - 2017-12-31 19:45:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-31 19:45:50 --> Input Class Initialized
INFO - 2017-12-31 19:45:50 --> Language Class Initialized
INFO - 2017-12-31 19:45:50 --> Loader Class Initialized
INFO - 2017-12-31 19:45:50 --> Helper loaded: url_helper
INFO - 2017-12-31 19:45:50 --> Helper loaded: form_helper
INFO - 2017-12-31 19:45:50 --> Database Driver Class Initialized
DEBUG - 2017-12-31 19:45:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-31 19:45:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-31 19:45:50 --> Form Validation Class Initialized
INFO - 2017-12-31 19:45:50 --> Model Class Initialized
INFO - 2017-12-31 19:45:50 --> Controller Class Initialized
INFO - 2017-12-31 19:45:50 --> Model Class Initialized
INFO - 2017-12-31 19:45:50 --> Model Class Initialized
INFO - 2017-12-31 19:45:50 --> Model Class Initialized
INFO - 2017-12-31 19:45:50 --> Model Class Initialized
DEBUG - 2017-12-31 19:45:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-31 19:46:04 --> Config Class Initialized
INFO - 2017-12-31 19:46:04 --> Hooks Class Initialized
DEBUG - 2017-12-31 19:46:04 --> UTF-8 Support Enabled
INFO - 2017-12-31 19:46:04 --> Utf8 Class Initialized
INFO - 2017-12-31 19:46:04 --> URI Class Initialized
INFO - 2017-12-31 19:46:04 --> Router Class Initialized
INFO - 2017-12-31 19:46:04 --> Output Class Initialized
INFO - 2017-12-31 19:46:04 --> Security Class Initialized
DEBUG - 2017-12-31 19:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-31 19:46:04 --> Input Class Initialized
INFO - 2017-12-31 19:46:04 --> Language Class Initialized
INFO - 2017-12-31 19:46:04 --> Loader Class Initialized
INFO - 2017-12-31 19:46:04 --> Helper loaded: url_helper
INFO - 2017-12-31 19:46:04 --> Helper loaded: form_helper
INFO - 2017-12-31 19:46:04 --> Database Driver Class Initialized
DEBUG - 2017-12-31 19:46:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-31 19:46:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-31 19:46:04 --> Form Validation Class Initialized
INFO - 2017-12-31 19:46:04 --> Model Class Initialized
INFO - 2017-12-31 19:46:04 --> Controller Class Initialized
INFO - 2017-12-31 19:46:04 --> Model Class Initialized
INFO - 2017-12-31 19:46:04 --> Model Class Initialized
INFO - 2017-12-31 19:46:04 --> Model Class Initialized
INFO - 2017-12-31 19:46:04 --> Model Class Initialized
DEBUG - 2017-12-31 19:46:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-31 19:46:04 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-31 19:46:04 --> Final output sent to browser
DEBUG - 2017-12-31 19:46:04 --> Total execution time: 0.0793
INFO - 2017-12-31 19:46:04 --> Config Class Initialized
INFO - 2017-12-31 19:46:04 --> Hooks Class Initialized
DEBUG - 2017-12-31 19:46:04 --> UTF-8 Support Enabled
INFO - 2017-12-31 19:46:04 --> Utf8 Class Initialized
INFO - 2017-12-31 19:46:04 --> URI Class Initialized
INFO - 2017-12-31 19:46:04 --> Router Class Initialized
INFO - 2017-12-31 19:46:04 --> Output Class Initialized
INFO - 2017-12-31 19:46:04 --> Security Class Initialized
DEBUG - 2017-12-31 19:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-31 19:46:04 --> Input Class Initialized
INFO - 2017-12-31 19:46:04 --> Language Class Initialized
INFO - 2017-12-31 19:46:04 --> Loader Class Initialized
INFO - 2017-12-31 19:46:04 --> Helper loaded: url_helper
INFO - 2017-12-31 19:46:04 --> Helper loaded: form_helper
INFO - 2017-12-31 19:46:04 --> Database Driver Class Initialized
DEBUG - 2017-12-31 19:46:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-31 19:46:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-31 19:46:04 --> Form Validation Class Initialized
INFO - 2017-12-31 19:46:04 --> Model Class Initialized
INFO - 2017-12-31 19:46:04 --> Controller Class Initialized
INFO - 2017-12-31 19:46:04 --> Model Class Initialized
INFO - 2017-12-31 19:46:04 --> Model Class Initialized
INFO - 2017-12-31 19:46:04 --> Model Class Initialized
INFO - 2017-12-31 19:46:04 --> Model Class Initialized
DEBUG - 2017-12-31 19:46:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-31 19:46:21 --> Config Class Initialized
INFO - 2017-12-31 19:46:21 --> Hooks Class Initialized
DEBUG - 2017-12-31 19:46:21 --> UTF-8 Support Enabled
INFO - 2017-12-31 19:46:21 --> Utf8 Class Initialized
INFO - 2017-12-31 19:46:21 --> URI Class Initialized
INFO - 2017-12-31 19:46:21 --> Router Class Initialized
INFO - 2017-12-31 19:46:21 --> Output Class Initialized
INFO - 2017-12-31 19:46:21 --> Security Class Initialized
DEBUG - 2017-12-31 19:46:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-31 19:46:21 --> Input Class Initialized
INFO - 2017-12-31 19:46:21 --> Language Class Initialized
INFO - 2017-12-31 19:46:21 --> Loader Class Initialized
INFO - 2017-12-31 19:46:21 --> Helper loaded: url_helper
INFO - 2017-12-31 19:46:21 --> Helper loaded: form_helper
INFO - 2017-12-31 19:46:21 --> Database Driver Class Initialized
DEBUG - 2017-12-31 19:46:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-31 19:46:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-31 19:46:21 --> Form Validation Class Initialized
INFO - 2017-12-31 19:46:21 --> Model Class Initialized
INFO - 2017-12-31 19:46:21 --> Controller Class Initialized
INFO - 2017-12-31 19:46:21 --> Model Class Initialized
INFO - 2017-12-31 19:46:21 --> Model Class Initialized
INFO - 2017-12-31 19:46:21 --> Model Class Initialized
INFO - 2017-12-31 19:46:21 --> Model Class Initialized
DEBUG - 2017-12-31 19:46:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-31 19:46:21 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-31 19:46:21 --> Final output sent to browser
DEBUG - 2017-12-31 19:46:21 --> Total execution time: 0.0858
INFO - 2017-12-31 19:46:21 --> Config Class Initialized
INFO - 2017-12-31 19:46:21 --> Hooks Class Initialized
DEBUG - 2017-12-31 19:46:21 --> UTF-8 Support Enabled
INFO - 2017-12-31 19:46:21 --> Utf8 Class Initialized
INFO - 2017-12-31 19:46:21 --> URI Class Initialized
INFO - 2017-12-31 19:46:21 --> Router Class Initialized
INFO - 2017-12-31 19:46:21 --> Output Class Initialized
INFO - 2017-12-31 19:46:21 --> Security Class Initialized
DEBUG - 2017-12-31 19:46:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-31 19:46:22 --> Input Class Initialized
INFO - 2017-12-31 19:46:22 --> Language Class Initialized
INFO - 2017-12-31 19:46:22 --> Loader Class Initialized
INFO - 2017-12-31 19:46:22 --> Helper loaded: url_helper
INFO - 2017-12-31 19:46:22 --> Helper loaded: form_helper
INFO - 2017-12-31 19:46:22 --> Database Driver Class Initialized
DEBUG - 2017-12-31 19:46:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-31 19:46:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-31 19:46:22 --> Form Validation Class Initialized
INFO - 2017-12-31 19:46:22 --> Model Class Initialized
INFO - 2017-12-31 19:46:22 --> Controller Class Initialized
INFO - 2017-12-31 19:46:22 --> Model Class Initialized
INFO - 2017-12-31 19:46:22 --> Model Class Initialized
INFO - 2017-12-31 19:46:22 --> Model Class Initialized
INFO - 2017-12-31 19:46:22 --> Model Class Initialized
DEBUG - 2017-12-31 19:46:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-31 19:48:08 --> Config Class Initialized
INFO - 2017-12-31 19:48:08 --> Hooks Class Initialized
DEBUG - 2017-12-31 19:48:08 --> UTF-8 Support Enabled
INFO - 2017-12-31 19:48:08 --> Utf8 Class Initialized
INFO - 2017-12-31 19:48:08 --> URI Class Initialized
INFO - 2017-12-31 19:48:08 --> Router Class Initialized
INFO - 2017-12-31 19:48:08 --> Output Class Initialized
INFO - 2017-12-31 19:48:08 --> Security Class Initialized
DEBUG - 2017-12-31 19:48:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-31 19:48:08 --> Input Class Initialized
INFO - 2017-12-31 19:48:08 --> Language Class Initialized
INFO - 2017-12-31 19:48:08 --> Loader Class Initialized
INFO - 2017-12-31 19:48:08 --> Helper loaded: url_helper
INFO - 2017-12-31 19:48:08 --> Helper loaded: form_helper
INFO - 2017-12-31 19:48:08 --> Database Driver Class Initialized
DEBUG - 2017-12-31 19:48:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-31 19:48:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-31 19:48:08 --> Form Validation Class Initialized
INFO - 2017-12-31 19:48:08 --> Model Class Initialized
INFO - 2017-12-31 19:48:08 --> Controller Class Initialized
INFO - 2017-12-31 19:48:08 --> Model Class Initialized
INFO - 2017-12-31 19:48:08 --> Model Class Initialized
INFO - 2017-12-31 19:48:08 --> Model Class Initialized
INFO - 2017-12-31 19:48:08 --> Model Class Initialized
DEBUG - 2017-12-31 19:48:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-31 19:48:09 --> Final output sent to browser
DEBUG - 2017-12-31 19:48:09 --> Total execution time: 0.7577
INFO - 2017-12-31 19:48:50 --> Config Class Initialized
INFO - 2017-12-31 19:48:50 --> Hooks Class Initialized
DEBUG - 2017-12-31 19:48:50 --> UTF-8 Support Enabled
INFO - 2017-12-31 19:48:50 --> Utf8 Class Initialized
INFO - 2017-12-31 19:48:50 --> URI Class Initialized
INFO - 2017-12-31 19:48:50 --> Router Class Initialized
INFO - 2017-12-31 19:48:50 --> Output Class Initialized
INFO - 2017-12-31 19:48:50 --> Security Class Initialized
DEBUG - 2017-12-31 19:48:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-31 19:48:50 --> Input Class Initialized
INFO - 2017-12-31 19:48:50 --> Language Class Initialized
INFO - 2017-12-31 19:48:50 --> Loader Class Initialized
INFO - 2017-12-31 19:48:50 --> Helper loaded: url_helper
INFO - 2017-12-31 19:48:50 --> Helper loaded: form_helper
INFO - 2017-12-31 19:48:50 --> Database Driver Class Initialized
DEBUG - 2017-12-31 19:48:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-31 19:48:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-31 19:48:50 --> Form Validation Class Initialized
INFO - 2017-12-31 19:48:50 --> Model Class Initialized
INFO - 2017-12-31 19:48:50 --> Controller Class Initialized
INFO - 2017-12-31 19:48:50 --> Model Class Initialized
INFO - 2017-12-31 19:48:50 --> Model Class Initialized
INFO - 2017-12-31 19:48:50 --> Model Class Initialized
INFO - 2017-12-31 19:48:50 --> Model Class Initialized
DEBUG - 2017-12-31 19:48:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-31 19:48:50 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-31 19:48:50 --> Final output sent to browser
DEBUG - 2017-12-31 19:48:50 --> Total execution time: 0.0844
INFO - 2017-12-31 19:48:51 --> Config Class Initialized
INFO - 2017-12-31 19:48:51 --> Hooks Class Initialized
DEBUG - 2017-12-31 19:48:51 --> UTF-8 Support Enabled
INFO - 2017-12-31 19:48:51 --> Utf8 Class Initialized
INFO - 2017-12-31 19:48:51 --> URI Class Initialized
INFO - 2017-12-31 19:48:51 --> Router Class Initialized
INFO - 2017-12-31 19:48:51 --> Output Class Initialized
INFO - 2017-12-31 19:48:51 --> Security Class Initialized
DEBUG - 2017-12-31 19:48:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-31 19:48:51 --> Input Class Initialized
INFO - 2017-12-31 19:48:51 --> Language Class Initialized
INFO - 2017-12-31 19:48:51 --> Loader Class Initialized
INFO - 2017-12-31 19:48:51 --> Helper loaded: url_helper
INFO - 2017-12-31 19:48:51 --> Helper loaded: form_helper
INFO - 2017-12-31 19:48:51 --> Database Driver Class Initialized
DEBUG - 2017-12-31 19:48:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-31 19:48:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-31 19:48:51 --> Form Validation Class Initialized
INFO - 2017-12-31 19:48:51 --> Model Class Initialized
INFO - 2017-12-31 19:48:51 --> Controller Class Initialized
INFO - 2017-12-31 19:48:51 --> Model Class Initialized
INFO - 2017-12-31 19:48:51 --> Model Class Initialized
DEBUG - 2017-12-31 19:48:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-31 19:48:51 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-31 19:48:51 --> Final output sent to browser
DEBUG - 2017-12-31 19:48:51 --> Total execution time: 0.0446
INFO - 2017-12-31 19:48:51 --> Config Class Initialized
INFO - 2017-12-31 19:48:51 --> Hooks Class Initialized
DEBUG - 2017-12-31 19:48:51 --> UTF-8 Support Enabled
INFO - 2017-12-31 19:48:51 --> Utf8 Class Initialized
INFO - 2017-12-31 19:48:51 --> URI Class Initialized
INFO - 2017-12-31 19:48:51 --> Router Class Initialized
INFO - 2017-12-31 19:48:51 --> Output Class Initialized
INFO - 2017-12-31 19:48:51 --> Security Class Initialized
DEBUG - 2017-12-31 19:48:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-31 19:48:51 --> Input Class Initialized
INFO - 2017-12-31 19:48:51 --> Language Class Initialized
INFO - 2017-12-31 19:48:51 --> Loader Class Initialized
INFO - 2017-12-31 19:48:51 --> Helper loaded: url_helper
INFO - 2017-12-31 19:48:51 --> Helper loaded: form_helper
INFO - 2017-12-31 19:48:51 --> Database Driver Class Initialized
DEBUG - 2017-12-31 19:48:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-31 19:48:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-31 19:48:51 --> Form Validation Class Initialized
INFO - 2017-12-31 19:48:51 --> Model Class Initialized
INFO - 2017-12-31 19:48:51 --> Controller Class Initialized
INFO - 2017-12-31 19:48:51 --> Model Class Initialized
INFO - 2017-12-31 19:48:51 --> Model Class Initialized
DEBUG - 2017-12-31 19:48:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-31 19:48:52 --> Config Class Initialized
INFO - 2017-12-31 19:48:52 --> Hooks Class Initialized
DEBUG - 2017-12-31 19:48:52 --> UTF-8 Support Enabled
INFO - 2017-12-31 19:48:52 --> Utf8 Class Initialized
INFO - 2017-12-31 19:48:52 --> URI Class Initialized
INFO - 2017-12-31 19:48:52 --> Router Class Initialized
INFO - 2017-12-31 19:48:52 --> Output Class Initialized
INFO - 2017-12-31 19:48:52 --> Security Class Initialized
DEBUG - 2017-12-31 19:48:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-31 19:48:52 --> Input Class Initialized
INFO - 2017-12-31 19:48:52 --> Language Class Initialized
INFO - 2017-12-31 19:48:52 --> Loader Class Initialized
INFO - 2017-12-31 19:48:52 --> Helper loaded: url_helper
INFO - 2017-12-31 19:48:52 --> Helper loaded: form_helper
INFO - 2017-12-31 19:48:52 --> Database Driver Class Initialized
DEBUG - 2017-12-31 19:48:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-31 19:48:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-31 19:48:52 --> Form Validation Class Initialized
INFO - 2017-12-31 19:48:52 --> Model Class Initialized
INFO - 2017-12-31 19:48:52 --> Controller Class Initialized
INFO - 2017-12-31 19:48:52 --> Model Class Initialized
INFO - 2017-12-31 19:48:52 --> Model Class Initialized
INFO - 2017-12-31 19:48:52 --> Model Class Initialized
INFO - 2017-12-31 19:48:52 --> Model Class Initialized
DEBUG - 2017-12-31 19:48:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-31 19:48:52 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-31 19:48:52 --> Final output sent to browser
DEBUG - 2017-12-31 19:48:52 --> Total execution time: 0.0465
INFO - 2017-12-31 19:48:52 --> Config Class Initialized
INFO - 2017-12-31 19:48:52 --> Hooks Class Initialized
DEBUG - 2017-12-31 19:48:52 --> UTF-8 Support Enabled
INFO - 2017-12-31 19:48:52 --> Utf8 Class Initialized
INFO - 2017-12-31 19:48:52 --> URI Class Initialized
INFO - 2017-12-31 19:48:52 --> Router Class Initialized
INFO - 2017-12-31 19:48:52 --> Output Class Initialized
INFO - 2017-12-31 19:48:52 --> Security Class Initialized
DEBUG - 2017-12-31 19:48:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-31 19:48:52 --> Input Class Initialized
INFO - 2017-12-31 19:48:52 --> Language Class Initialized
INFO - 2017-12-31 19:48:52 --> Loader Class Initialized
INFO - 2017-12-31 19:48:52 --> Helper loaded: url_helper
INFO - 2017-12-31 19:48:52 --> Helper loaded: form_helper
INFO - 2017-12-31 19:48:52 --> Database Driver Class Initialized
DEBUG - 2017-12-31 19:48:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-31 19:48:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-31 19:48:52 --> Form Validation Class Initialized
INFO - 2017-12-31 19:48:52 --> Model Class Initialized
INFO - 2017-12-31 19:48:52 --> Controller Class Initialized
INFO - 2017-12-31 19:48:52 --> Model Class Initialized
INFO - 2017-12-31 19:48:52 --> Model Class Initialized
INFO - 2017-12-31 19:48:52 --> Model Class Initialized
INFO - 2017-12-31 19:48:52 --> Model Class Initialized
DEBUG - 2017-12-31 19:48:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-31 19:49:27 --> Config Class Initialized
INFO - 2017-12-31 19:49:27 --> Hooks Class Initialized
DEBUG - 2017-12-31 19:49:27 --> UTF-8 Support Enabled
INFO - 2017-12-31 19:49:27 --> Utf8 Class Initialized
INFO - 2017-12-31 19:49:27 --> URI Class Initialized
INFO - 2017-12-31 19:49:27 --> Router Class Initialized
INFO - 2017-12-31 19:49:27 --> Output Class Initialized
INFO - 2017-12-31 19:49:27 --> Security Class Initialized
DEBUG - 2017-12-31 19:49:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-31 19:49:27 --> Input Class Initialized
INFO - 2017-12-31 19:49:27 --> Language Class Initialized
INFO - 2017-12-31 19:49:27 --> Loader Class Initialized
INFO - 2017-12-31 19:49:27 --> Helper loaded: url_helper
INFO - 2017-12-31 19:49:27 --> Helper loaded: form_helper
INFO - 2017-12-31 19:49:27 --> Database Driver Class Initialized
DEBUG - 2017-12-31 19:49:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-31 19:49:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-31 19:49:27 --> Form Validation Class Initialized
INFO - 2017-12-31 19:49:27 --> Model Class Initialized
INFO - 2017-12-31 19:49:27 --> Controller Class Initialized
INFO - 2017-12-31 19:49:27 --> Model Class Initialized
INFO - 2017-12-31 19:49:27 --> Model Class Initialized
INFO - 2017-12-31 19:49:27 --> Model Class Initialized
INFO - 2017-12-31 19:49:27 --> Model Class Initialized
DEBUG - 2017-12-31 19:49:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-31 19:49:27 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-31 19:49:27 --> Final output sent to browser
DEBUG - 2017-12-31 19:49:27 --> Total execution time: 0.0489
INFO - 2017-12-31 19:49:29 --> Config Class Initialized
INFO - 2017-12-31 19:49:29 --> Hooks Class Initialized
DEBUG - 2017-12-31 19:49:29 --> UTF-8 Support Enabled
INFO - 2017-12-31 19:49:29 --> Utf8 Class Initialized
INFO - 2017-12-31 19:49:29 --> URI Class Initialized
INFO - 2017-12-31 19:49:29 --> Router Class Initialized
INFO - 2017-12-31 19:49:29 --> Output Class Initialized
INFO - 2017-12-31 19:49:29 --> Security Class Initialized
DEBUG - 2017-12-31 19:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-31 19:49:29 --> Input Class Initialized
INFO - 2017-12-31 19:49:29 --> Language Class Initialized
INFO - 2017-12-31 19:49:29 --> Loader Class Initialized
INFO - 2017-12-31 19:49:29 --> Helper loaded: url_helper
INFO - 2017-12-31 19:49:29 --> Helper loaded: form_helper
INFO - 2017-12-31 19:49:29 --> Database Driver Class Initialized
DEBUG - 2017-12-31 19:49:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-31 19:49:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-31 19:49:29 --> Form Validation Class Initialized
INFO - 2017-12-31 19:49:29 --> Model Class Initialized
INFO - 2017-12-31 19:49:29 --> Controller Class Initialized
INFO - 2017-12-31 19:49:29 --> Model Class Initialized
INFO - 2017-12-31 19:49:29 --> Model Class Initialized
INFO - 2017-12-31 19:49:29 --> Model Class Initialized
INFO - 2017-12-31 19:49:29 --> Model Class Initialized
DEBUG - 2017-12-31 19:49:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-31 19:49:29 --> Config Class Initialized
INFO - 2017-12-31 19:49:29 --> Hooks Class Initialized
DEBUG - 2017-12-31 19:49:29 --> UTF-8 Support Enabled
INFO - 2017-12-31 19:49:29 --> Utf8 Class Initialized
INFO - 2017-12-31 19:49:29 --> URI Class Initialized
INFO - 2017-12-31 19:49:29 --> Router Class Initialized
INFO - 2017-12-31 19:49:29 --> Output Class Initialized
INFO - 2017-12-31 19:49:29 --> Security Class Initialized
DEBUG - 2017-12-31 19:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-31 19:49:29 --> Input Class Initialized
INFO - 2017-12-31 19:49:29 --> Language Class Initialized
ERROR - 2017-12-31 19:49:29 --> 404 Page Not Found: Faviconico/index
INFO - 2017-12-31 20:00:28 --> Config Class Initialized
INFO - 2017-12-31 20:00:28 --> Hooks Class Initialized
DEBUG - 2017-12-31 20:00:28 --> UTF-8 Support Enabled
INFO - 2017-12-31 20:00:28 --> Utf8 Class Initialized
INFO - 2017-12-31 20:00:28 --> URI Class Initialized
INFO - 2017-12-31 20:00:28 --> Router Class Initialized
INFO - 2017-12-31 20:00:28 --> Output Class Initialized
INFO - 2017-12-31 20:00:28 --> Security Class Initialized
DEBUG - 2017-12-31 20:00:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-31 20:00:28 --> Input Class Initialized
INFO - 2017-12-31 20:00:28 --> Language Class Initialized
INFO - 2017-12-31 20:00:28 --> Loader Class Initialized
INFO - 2017-12-31 20:00:28 --> Helper loaded: url_helper
INFO - 2017-12-31 20:00:28 --> Helper loaded: form_helper
INFO - 2017-12-31 20:00:28 --> Database Driver Class Initialized
DEBUG - 2017-12-31 20:00:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-31 20:00:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-31 20:00:28 --> Form Validation Class Initialized
INFO - 2017-12-31 20:00:28 --> Model Class Initialized
INFO - 2017-12-31 20:00:28 --> Controller Class Initialized
INFO - 2017-12-31 20:00:28 --> Model Class Initialized
INFO - 2017-12-31 20:00:28 --> Model Class Initialized
INFO - 2017-12-31 20:00:28 --> Model Class Initialized
INFO - 2017-12-31 20:00:28 --> Model Class Initialized
DEBUG - 2017-12-31 20:00:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-31 20:00:28 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-31 20:00:28 --> Final output sent to browser
DEBUG - 2017-12-31 20:00:28 --> Total execution time: 0.0799
INFO - 2017-12-31 20:00:29 --> Config Class Initialized
INFO - 2017-12-31 20:00:29 --> Hooks Class Initialized
DEBUG - 2017-12-31 20:00:29 --> UTF-8 Support Enabled
INFO - 2017-12-31 20:00:29 --> Utf8 Class Initialized
INFO - 2017-12-31 20:00:29 --> URI Class Initialized
INFO - 2017-12-31 20:00:29 --> Router Class Initialized
INFO - 2017-12-31 20:00:29 --> Output Class Initialized
INFO - 2017-12-31 20:00:29 --> Security Class Initialized
DEBUG - 2017-12-31 20:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-31 20:00:29 --> Input Class Initialized
INFO - 2017-12-31 20:00:29 --> Language Class Initialized
INFO - 2017-12-31 20:00:29 --> Loader Class Initialized
INFO - 2017-12-31 20:00:29 --> Helper loaded: url_helper
INFO - 2017-12-31 20:00:29 --> Helper loaded: form_helper
INFO - 2017-12-31 20:00:29 --> Database Driver Class Initialized
DEBUG - 2017-12-31 20:00:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-31 20:00:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-31 20:00:29 --> Form Validation Class Initialized
INFO - 2017-12-31 20:00:29 --> Model Class Initialized
INFO - 2017-12-31 20:00:29 --> Controller Class Initialized
INFO - 2017-12-31 20:00:29 --> Model Class Initialized
INFO - 2017-12-31 20:00:29 --> Model Class Initialized
INFO - 2017-12-31 20:00:29 --> Model Class Initialized
INFO - 2017-12-31 20:00:29 --> Model Class Initialized
DEBUG - 2017-12-31 20:00:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-31 20:00:33 --> Config Class Initialized
INFO - 2017-12-31 20:00:33 --> Hooks Class Initialized
DEBUG - 2017-12-31 20:00:33 --> UTF-8 Support Enabled
INFO - 2017-12-31 20:00:33 --> Utf8 Class Initialized
INFO - 2017-12-31 20:00:33 --> URI Class Initialized
INFO - 2017-12-31 20:00:33 --> Router Class Initialized
INFO - 2017-12-31 20:00:33 --> Output Class Initialized
INFO - 2017-12-31 20:00:33 --> Security Class Initialized
DEBUG - 2017-12-31 20:00:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-31 20:00:33 --> Input Class Initialized
INFO - 2017-12-31 20:00:33 --> Language Class Initialized
INFO - 2017-12-31 20:00:33 --> Loader Class Initialized
INFO - 2017-12-31 20:00:33 --> Helper loaded: url_helper
INFO - 2017-12-31 20:00:33 --> Helper loaded: form_helper
INFO - 2017-12-31 20:00:33 --> Database Driver Class Initialized
DEBUG - 2017-12-31 20:00:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-31 20:00:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-31 20:00:33 --> Form Validation Class Initialized
INFO - 2017-12-31 20:00:33 --> Model Class Initialized
INFO - 2017-12-31 20:00:33 --> Controller Class Initialized
INFO - 2017-12-31 20:00:33 --> Model Class Initialized
INFO - 2017-12-31 20:00:33 --> Model Class Initialized
INFO - 2017-12-31 20:00:33 --> Model Class Initialized
INFO - 2017-12-31 20:00:33 --> Model Class Initialized
DEBUG - 2017-12-31 20:00:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-31 20:00:33 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-31 20:00:33 --> Final output sent to browser
DEBUG - 2017-12-31 20:00:33 --> Total execution time: 0.0714
INFO - 2017-12-31 20:00:33 --> Config Class Initialized
INFO - 2017-12-31 20:00:33 --> Hooks Class Initialized
DEBUG - 2017-12-31 20:00:33 --> UTF-8 Support Enabled
INFO - 2017-12-31 20:00:33 --> Utf8 Class Initialized
INFO - 2017-12-31 20:00:33 --> URI Class Initialized
INFO - 2017-12-31 20:00:33 --> Router Class Initialized
INFO - 2017-12-31 20:00:33 --> Output Class Initialized
INFO - 2017-12-31 20:00:33 --> Security Class Initialized
DEBUG - 2017-12-31 20:00:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-31 20:00:33 --> Input Class Initialized
INFO - 2017-12-31 20:00:33 --> Language Class Initialized
INFO - 2017-12-31 20:00:33 --> Loader Class Initialized
INFO - 2017-12-31 20:00:33 --> Helper loaded: url_helper
INFO - 2017-12-31 20:00:33 --> Helper loaded: form_helper
INFO - 2017-12-31 20:00:33 --> Database Driver Class Initialized
DEBUG - 2017-12-31 20:00:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-31 20:00:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-31 20:00:33 --> Form Validation Class Initialized
INFO - 2017-12-31 20:00:33 --> Model Class Initialized
INFO - 2017-12-31 20:00:33 --> Controller Class Initialized
INFO - 2017-12-31 20:00:33 --> Model Class Initialized
INFO - 2017-12-31 20:00:33 --> Model Class Initialized
INFO - 2017-12-31 20:00:33 --> Model Class Initialized
INFO - 2017-12-31 20:00:33 --> Model Class Initialized
DEBUG - 2017-12-31 20:00:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-31 20:00:37 --> Config Class Initialized
INFO - 2017-12-31 20:00:37 --> Hooks Class Initialized
DEBUG - 2017-12-31 20:00:37 --> UTF-8 Support Enabled
INFO - 2017-12-31 20:00:37 --> Utf8 Class Initialized
INFO - 2017-12-31 20:00:37 --> URI Class Initialized
INFO - 2017-12-31 20:00:37 --> Router Class Initialized
INFO - 2017-12-31 20:00:37 --> Output Class Initialized
INFO - 2017-12-31 20:00:37 --> Security Class Initialized
DEBUG - 2017-12-31 20:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-31 20:00:37 --> Input Class Initialized
INFO - 2017-12-31 20:00:37 --> Language Class Initialized
INFO - 2017-12-31 20:00:37 --> Loader Class Initialized
INFO - 2017-12-31 20:00:37 --> Helper loaded: url_helper
INFO - 2017-12-31 20:00:37 --> Helper loaded: form_helper
INFO - 2017-12-31 20:00:37 --> Database Driver Class Initialized
DEBUG - 2017-12-31 20:00:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-31 20:00:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-31 20:00:37 --> Form Validation Class Initialized
INFO - 2017-12-31 20:00:37 --> Model Class Initialized
INFO - 2017-12-31 20:00:37 --> Controller Class Initialized
INFO - 2017-12-31 20:00:37 --> Model Class Initialized
INFO - 2017-12-31 20:00:37 --> Model Class Initialized
INFO - 2017-12-31 20:00:37 --> Model Class Initialized
INFO - 2017-12-31 20:00:37 --> Model Class Initialized
DEBUG - 2017-12-31 20:00:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-31 20:00:37 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-31 20:00:37 --> Final output sent to browser
DEBUG - 2017-12-31 20:00:37 --> Total execution time: 0.0715
INFO - 2017-12-31 20:00:37 --> Config Class Initialized
INFO - 2017-12-31 20:00:37 --> Hooks Class Initialized
DEBUG - 2017-12-31 20:00:37 --> UTF-8 Support Enabled
INFO - 2017-12-31 20:00:37 --> Utf8 Class Initialized
INFO - 2017-12-31 20:00:37 --> URI Class Initialized
INFO - 2017-12-31 20:00:37 --> Router Class Initialized
INFO - 2017-12-31 20:00:37 --> Output Class Initialized
INFO - 2017-12-31 20:00:37 --> Security Class Initialized
DEBUG - 2017-12-31 20:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-31 20:00:37 --> Input Class Initialized
INFO - 2017-12-31 20:00:37 --> Language Class Initialized
INFO - 2017-12-31 20:00:37 --> Loader Class Initialized
INFO - 2017-12-31 20:00:37 --> Helper loaded: url_helper
INFO - 2017-12-31 20:00:37 --> Helper loaded: form_helper
INFO - 2017-12-31 20:00:37 --> Database Driver Class Initialized
DEBUG - 2017-12-31 20:00:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-31 20:00:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-31 20:00:37 --> Form Validation Class Initialized
INFO - 2017-12-31 20:00:37 --> Model Class Initialized
INFO - 2017-12-31 20:00:37 --> Controller Class Initialized
INFO - 2017-12-31 20:00:37 --> Model Class Initialized
INFO - 2017-12-31 20:00:37 --> Model Class Initialized
INFO - 2017-12-31 20:00:37 --> Model Class Initialized
INFO - 2017-12-31 20:00:37 --> Model Class Initialized
DEBUG - 2017-12-31 20:00:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-31 20:00:44 --> Config Class Initialized
INFO - 2017-12-31 20:00:44 --> Hooks Class Initialized
DEBUG - 2017-12-31 20:00:44 --> UTF-8 Support Enabled
INFO - 2017-12-31 20:00:44 --> Utf8 Class Initialized
INFO - 2017-12-31 20:00:44 --> URI Class Initialized
INFO - 2017-12-31 20:00:44 --> Router Class Initialized
INFO - 2017-12-31 20:00:44 --> Output Class Initialized
INFO - 2017-12-31 20:00:44 --> Security Class Initialized
DEBUG - 2017-12-31 20:00:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-31 20:00:44 --> Input Class Initialized
INFO - 2017-12-31 20:00:44 --> Language Class Initialized
INFO - 2017-12-31 20:00:44 --> Loader Class Initialized
INFO - 2017-12-31 20:00:44 --> Helper loaded: url_helper
INFO - 2017-12-31 20:00:44 --> Helper loaded: form_helper
INFO - 2017-12-31 20:00:44 --> Database Driver Class Initialized
DEBUG - 2017-12-31 20:00:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-31 20:00:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-31 20:00:44 --> Form Validation Class Initialized
INFO - 2017-12-31 20:00:44 --> Model Class Initialized
INFO - 2017-12-31 20:00:44 --> Controller Class Initialized
INFO - 2017-12-31 20:00:44 --> Model Class Initialized
INFO - 2017-12-31 20:00:44 --> Model Class Initialized
INFO - 2017-12-31 20:00:44 --> Model Class Initialized
INFO - 2017-12-31 20:00:44 --> Model Class Initialized
DEBUG - 2017-12-31 20:00:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-31 20:00:44 --> Final output sent to browser
DEBUG - 2017-12-31 20:00:44 --> Total execution time: 0.0659
INFO - 2017-12-31 20:00:45 --> Config Class Initialized
INFO - 2017-12-31 20:00:45 --> Hooks Class Initialized
DEBUG - 2017-12-31 20:00:45 --> UTF-8 Support Enabled
INFO - 2017-12-31 20:00:45 --> Utf8 Class Initialized
INFO - 2017-12-31 20:00:45 --> URI Class Initialized
INFO - 2017-12-31 20:00:45 --> Router Class Initialized
INFO - 2017-12-31 20:00:45 --> Output Class Initialized
INFO - 2017-12-31 20:00:45 --> Security Class Initialized
DEBUG - 2017-12-31 20:00:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-31 20:00:45 --> Input Class Initialized
INFO - 2017-12-31 20:00:45 --> Language Class Initialized
INFO - 2017-12-31 20:00:45 --> Loader Class Initialized
INFO - 2017-12-31 20:00:45 --> Helper loaded: url_helper
INFO - 2017-12-31 20:00:45 --> Helper loaded: form_helper
INFO - 2017-12-31 20:00:45 --> Database Driver Class Initialized
DEBUG - 2017-12-31 20:00:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-31 20:00:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-31 20:00:45 --> Form Validation Class Initialized
INFO - 2017-12-31 20:00:45 --> Model Class Initialized
INFO - 2017-12-31 20:00:45 --> Controller Class Initialized
INFO - 2017-12-31 20:00:45 --> Model Class Initialized
INFO - 2017-12-31 20:00:45 --> Model Class Initialized
INFO - 2017-12-31 20:00:45 --> Model Class Initialized
INFO - 2017-12-31 20:00:45 --> Model Class Initialized
DEBUG - 2017-12-31 20:00:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-31 20:00:47 --> Config Class Initialized
INFO - 2017-12-31 20:00:47 --> Hooks Class Initialized
DEBUG - 2017-12-31 20:00:47 --> UTF-8 Support Enabled
INFO - 2017-12-31 20:00:47 --> Utf8 Class Initialized
INFO - 2017-12-31 20:00:47 --> URI Class Initialized
INFO - 2017-12-31 20:00:47 --> Router Class Initialized
INFO - 2017-12-31 20:00:47 --> Output Class Initialized
INFO - 2017-12-31 20:00:47 --> Security Class Initialized
DEBUG - 2017-12-31 20:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-31 20:00:47 --> Input Class Initialized
INFO - 2017-12-31 20:00:47 --> Language Class Initialized
INFO - 2017-12-31 20:00:47 --> Loader Class Initialized
INFO - 2017-12-31 20:00:47 --> Helper loaded: url_helper
INFO - 2017-12-31 20:00:47 --> Helper loaded: form_helper
INFO - 2017-12-31 20:00:47 --> Database Driver Class Initialized
DEBUG - 2017-12-31 20:00:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-31 20:00:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-31 20:00:47 --> Form Validation Class Initialized
INFO - 2017-12-31 20:00:47 --> Model Class Initialized
INFO - 2017-12-31 20:00:47 --> Controller Class Initialized
INFO - 2017-12-31 20:00:47 --> Model Class Initialized
INFO - 2017-12-31 20:00:47 --> Model Class Initialized
INFO - 2017-12-31 20:00:47 --> Model Class Initialized
INFO - 2017-12-31 20:00:47 --> Model Class Initialized
DEBUG - 2017-12-31 20:00:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-31 20:00:53 --> Config Class Initialized
INFO - 2017-12-31 20:00:53 --> Hooks Class Initialized
DEBUG - 2017-12-31 20:00:53 --> UTF-8 Support Enabled
INFO - 2017-12-31 20:00:53 --> Utf8 Class Initialized
INFO - 2017-12-31 20:00:53 --> URI Class Initialized
INFO - 2017-12-31 20:00:53 --> Router Class Initialized
INFO - 2017-12-31 20:00:53 --> Output Class Initialized
INFO - 2017-12-31 20:00:53 --> Security Class Initialized
DEBUG - 2017-12-31 20:00:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-31 20:00:53 --> Input Class Initialized
INFO - 2017-12-31 20:00:53 --> Language Class Initialized
INFO - 2017-12-31 20:00:53 --> Loader Class Initialized
INFO - 2017-12-31 20:00:53 --> Helper loaded: url_helper
INFO - 2017-12-31 20:00:53 --> Helper loaded: form_helper
INFO - 2017-12-31 20:00:53 --> Database Driver Class Initialized
DEBUG - 2017-12-31 20:00:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-31 20:00:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-31 20:00:53 --> Form Validation Class Initialized
INFO - 2017-12-31 20:00:53 --> Model Class Initialized
INFO - 2017-12-31 20:00:53 --> Controller Class Initialized
INFO - 2017-12-31 20:00:53 --> Model Class Initialized
INFO - 2017-12-31 20:00:53 --> Model Class Initialized
INFO - 2017-12-31 20:00:53 --> Model Class Initialized
INFO - 2017-12-31 20:00:53 --> Model Class Initialized
DEBUG - 2017-12-31 20:00:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-31 20:00:54 --> Config Class Initialized
INFO - 2017-12-31 20:00:54 --> Hooks Class Initialized
DEBUG - 2017-12-31 20:00:54 --> UTF-8 Support Enabled
INFO - 2017-12-31 20:00:54 --> Utf8 Class Initialized
INFO - 2017-12-31 20:00:54 --> URI Class Initialized
INFO - 2017-12-31 20:00:54 --> Router Class Initialized
INFO - 2017-12-31 20:00:54 --> Output Class Initialized
INFO - 2017-12-31 20:00:54 --> Security Class Initialized
DEBUG - 2017-12-31 20:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-31 20:00:54 --> Input Class Initialized
INFO - 2017-12-31 20:00:54 --> Language Class Initialized
INFO - 2017-12-31 20:00:54 --> Loader Class Initialized
INFO - 2017-12-31 20:00:54 --> Helper loaded: url_helper
INFO - 2017-12-31 20:00:54 --> Helper loaded: form_helper
INFO - 2017-12-31 20:00:54 --> Database Driver Class Initialized
DEBUG - 2017-12-31 20:00:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-31 20:00:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-31 20:00:54 --> Form Validation Class Initialized
INFO - 2017-12-31 20:00:54 --> Model Class Initialized
INFO - 2017-12-31 20:00:54 --> Controller Class Initialized
INFO - 2017-12-31 20:00:54 --> Model Class Initialized
INFO - 2017-12-31 20:00:54 --> Model Class Initialized
INFO - 2017-12-31 20:00:54 --> Model Class Initialized
INFO - 2017-12-31 20:00:54 --> Model Class Initialized
DEBUG - 2017-12-31 20:00:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-31 20:00:56 --> Config Class Initialized
INFO - 2017-12-31 20:00:56 --> Hooks Class Initialized
DEBUG - 2017-12-31 20:00:56 --> UTF-8 Support Enabled
INFO - 2017-12-31 20:00:56 --> Utf8 Class Initialized
INFO - 2017-12-31 20:00:56 --> URI Class Initialized
INFO - 2017-12-31 20:00:56 --> Router Class Initialized
INFO - 2017-12-31 20:00:56 --> Output Class Initialized
INFO - 2017-12-31 20:00:56 --> Security Class Initialized
DEBUG - 2017-12-31 20:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-31 20:00:56 --> Input Class Initialized
INFO - 2017-12-31 20:00:56 --> Language Class Initialized
INFO - 2017-12-31 20:00:56 --> Loader Class Initialized
INFO - 2017-12-31 20:00:56 --> Helper loaded: url_helper
INFO - 2017-12-31 20:00:56 --> Helper loaded: form_helper
INFO - 2017-12-31 20:00:56 --> Database Driver Class Initialized
DEBUG - 2017-12-31 20:00:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-31 20:00:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-31 20:00:56 --> Form Validation Class Initialized
INFO - 2017-12-31 20:00:56 --> Model Class Initialized
INFO - 2017-12-31 20:00:56 --> Controller Class Initialized
INFO - 2017-12-31 20:00:56 --> Model Class Initialized
INFO - 2017-12-31 20:00:56 --> Model Class Initialized
INFO - 2017-12-31 20:00:56 --> Model Class Initialized
INFO - 2017-12-31 20:00:56 --> Model Class Initialized
DEBUG - 2017-12-31 20:00:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-31 20:01:02 --> Config Class Initialized
INFO - 2017-12-31 20:01:02 --> Hooks Class Initialized
DEBUG - 2017-12-31 20:01:02 --> UTF-8 Support Enabled
INFO - 2017-12-31 20:01:02 --> Utf8 Class Initialized
INFO - 2017-12-31 20:01:02 --> URI Class Initialized
INFO - 2017-12-31 20:01:02 --> Router Class Initialized
INFO - 2017-12-31 20:01:02 --> Output Class Initialized
INFO - 2017-12-31 20:01:02 --> Security Class Initialized
DEBUG - 2017-12-31 20:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-31 20:01:02 --> Input Class Initialized
INFO - 2017-12-31 20:01:02 --> Language Class Initialized
INFO - 2017-12-31 20:01:02 --> Loader Class Initialized
INFO - 2017-12-31 20:01:02 --> Helper loaded: url_helper
INFO - 2017-12-31 20:01:02 --> Helper loaded: form_helper
INFO - 2017-12-31 20:01:02 --> Database Driver Class Initialized
DEBUG - 2017-12-31 20:01:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-31 20:01:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-31 20:01:02 --> Form Validation Class Initialized
INFO - 2017-12-31 20:01:02 --> Model Class Initialized
INFO - 2017-12-31 20:01:02 --> Controller Class Initialized
INFO - 2017-12-31 20:01:02 --> Model Class Initialized
INFO - 2017-12-31 20:01:02 --> Model Class Initialized
INFO - 2017-12-31 20:01:02 --> Model Class Initialized
INFO - 2017-12-31 20:01:02 --> Model Class Initialized
DEBUG - 2017-12-31 20:01:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-31 20:01:03 --> Config Class Initialized
INFO - 2017-12-31 20:01:03 --> Hooks Class Initialized
DEBUG - 2017-12-31 20:01:03 --> UTF-8 Support Enabled
INFO - 2017-12-31 20:01:03 --> Utf8 Class Initialized
INFO - 2017-12-31 20:01:03 --> URI Class Initialized
INFO - 2017-12-31 20:01:03 --> Router Class Initialized
INFO - 2017-12-31 20:01:03 --> Output Class Initialized
INFO - 2017-12-31 20:01:03 --> Security Class Initialized
DEBUG - 2017-12-31 20:01:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-31 20:01:03 --> Input Class Initialized
INFO - 2017-12-31 20:01:03 --> Language Class Initialized
INFO - 2017-12-31 20:01:03 --> Loader Class Initialized
INFO - 2017-12-31 20:01:03 --> Helper loaded: url_helper
INFO - 2017-12-31 20:01:03 --> Helper loaded: form_helper
INFO - 2017-12-31 20:01:03 --> Database Driver Class Initialized
DEBUG - 2017-12-31 20:01:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-31 20:01:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-31 20:01:03 --> Form Validation Class Initialized
INFO - 2017-12-31 20:01:03 --> Model Class Initialized
INFO - 2017-12-31 20:01:03 --> Controller Class Initialized
INFO - 2017-12-31 20:01:03 --> Model Class Initialized
INFO - 2017-12-31 20:01:03 --> Model Class Initialized
INFO - 2017-12-31 20:01:03 --> Model Class Initialized
INFO - 2017-12-31 20:01:03 --> Model Class Initialized
DEBUG - 2017-12-31 20:01:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-31 20:01:07 --> Config Class Initialized
INFO - 2017-12-31 20:01:07 --> Hooks Class Initialized
DEBUG - 2017-12-31 20:01:08 --> UTF-8 Support Enabled
INFO - 2017-12-31 20:01:08 --> Utf8 Class Initialized
INFO - 2017-12-31 20:01:08 --> URI Class Initialized
INFO - 2017-12-31 20:01:08 --> Router Class Initialized
INFO - 2017-12-31 20:01:08 --> Output Class Initialized
INFO - 2017-12-31 20:01:08 --> Security Class Initialized
DEBUG - 2017-12-31 20:01:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-31 20:01:08 --> Input Class Initialized
INFO - 2017-12-31 20:01:08 --> Language Class Initialized
INFO - 2017-12-31 20:01:08 --> Loader Class Initialized
INFO - 2017-12-31 20:01:08 --> Helper loaded: url_helper
INFO - 2017-12-31 20:01:08 --> Helper loaded: form_helper
INFO - 2017-12-31 20:01:08 --> Database Driver Class Initialized
DEBUG - 2017-12-31 20:01:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-31 20:01:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-31 20:01:08 --> Form Validation Class Initialized
INFO - 2017-12-31 20:01:08 --> Model Class Initialized
INFO - 2017-12-31 20:01:08 --> Controller Class Initialized
INFO - 2017-12-31 20:01:08 --> Model Class Initialized
INFO - 2017-12-31 20:01:08 --> Model Class Initialized
INFO - 2017-12-31 20:01:08 --> Model Class Initialized
INFO - 2017-12-31 20:01:08 --> Model Class Initialized
DEBUG - 2017-12-31 20:01:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-31 20:01:09 --> Config Class Initialized
INFO - 2017-12-31 20:01:09 --> Hooks Class Initialized
DEBUG - 2017-12-31 20:01:09 --> UTF-8 Support Enabled
INFO - 2017-12-31 20:01:09 --> Utf8 Class Initialized
INFO - 2017-12-31 20:01:09 --> URI Class Initialized
INFO - 2017-12-31 20:01:09 --> Router Class Initialized
INFO - 2017-12-31 20:01:09 --> Output Class Initialized
INFO - 2017-12-31 20:01:09 --> Security Class Initialized
DEBUG - 2017-12-31 20:01:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-31 20:01:09 --> Input Class Initialized
INFO - 2017-12-31 20:01:09 --> Language Class Initialized
INFO - 2017-12-31 20:01:09 --> Loader Class Initialized
INFO - 2017-12-31 20:01:09 --> Helper loaded: url_helper
INFO - 2017-12-31 20:01:09 --> Helper loaded: form_helper
INFO - 2017-12-31 20:01:09 --> Database Driver Class Initialized
DEBUG - 2017-12-31 20:01:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-31 20:01:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-31 20:01:09 --> Form Validation Class Initialized
INFO - 2017-12-31 20:01:09 --> Model Class Initialized
INFO - 2017-12-31 20:01:09 --> Controller Class Initialized
INFO - 2017-12-31 20:01:09 --> Model Class Initialized
INFO - 2017-12-31 20:01:09 --> Model Class Initialized
INFO - 2017-12-31 20:01:09 --> Model Class Initialized
INFO - 2017-12-31 20:01:09 --> Model Class Initialized
DEBUG - 2017-12-31 20:01:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-31 20:01:10 --> Config Class Initialized
INFO - 2017-12-31 20:01:10 --> Hooks Class Initialized
DEBUG - 2017-12-31 20:01:10 --> UTF-8 Support Enabled
INFO - 2017-12-31 20:01:10 --> Utf8 Class Initialized
INFO - 2017-12-31 20:01:10 --> URI Class Initialized
INFO - 2017-12-31 20:01:10 --> Router Class Initialized
INFO - 2017-12-31 20:01:10 --> Output Class Initialized
INFO - 2017-12-31 20:01:10 --> Security Class Initialized
DEBUG - 2017-12-31 20:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-31 20:01:11 --> Input Class Initialized
INFO - 2017-12-31 20:01:11 --> Language Class Initialized
INFO - 2017-12-31 20:01:11 --> Loader Class Initialized
INFO - 2017-12-31 20:01:11 --> Helper loaded: url_helper
INFO - 2017-12-31 20:01:11 --> Helper loaded: form_helper
INFO - 2017-12-31 20:01:11 --> Database Driver Class Initialized
DEBUG - 2017-12-31 20:01:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-31 20:01:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-31 20:01:11 --> Form Validation Class Initialized
INFO - 2017-12-31 20:01:11 --> Model Class Initialized
INFO - 2017-12-31 20:01:11 --> Controller Class Initialized
INFO - 2017-12-31 20:01:11 --> Model Class Initialized
INFO - 2017-12-31 20:01:11 --> Model Class Initialized
INFO - 2017-12-31 20:01:11 --> Model Class Initialized
INFO - 2017-12-31 20:01:11 --> Model Class Initialized
DEBUG - 2017-12-31 20:01:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-31 20:01:12 --> Config Class Initialized
INFO - 2017-12-31 20:01:12 --> Hooks Class Initialized
DEBUG - 2017-12-31 20:01:12 --> UTF-8 Support Enabled
INFO - 2017-12-31 20:01:12 --> Utf8 Class Initialized
INFO - 2017-12-31 20:01:12 --> URI Class Initialized
INFO - 2017-12-31 20:01:12 --> Router Class Initialized
INFO - 2017-12-31 20:01:12 --> Output Class Initialized
INFO - 2017-12-31 20:01:12 --> Security Class Initialized
DEBUG - 2017-12-31 20:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-31 20:01:12 --> Input Class Initialized
INFO - 2017-12-31 20:01:12 --> Language Class Initialized
INFO - 2017-12-31 20:01:12 --> Loader Class Initialized
INFO - 2017-12-31 20:01:12 --> Helper loaded: url_helper
INFO - 2017-12-31 20:01:12 --> Helper loaded: form_helper
INFO - 2017-12-31 20:01:12 --> Database Driver Class Initialized
DEBUG - 2017-12-31 20:01:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-31 20:01:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-31 20:01:12 --> Form Validation Class Initialized
INFO - 2017-12-31 20:01:12 --> Model Class Initialized
INFO - 2017-12-31 20:01:12 --> Controller Class Initialized
INFO - 2017-12-31 20:01:12 --> Model Class Initialized
INFO - 2017-12-31 20:01:12 --> Model Class Initialized
INFO - 2017-12-31 20:01:12 --> Model Class Initialized
INFO - 2017-12-31 20:01:12 --> Model Class Initialized
DEBUG - 2017-12-31 20:01:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-31 20:01:15 --> Config Class Initialized
INFO - 2017-12-31 20:01:15 --> Hooks Class Initialized
DEBUG - 2017-12-31 20:01:15 --> UTF-8 Support Enabled
INFO - 2017-12-31 20:01:15 --> Utf8 Class Initialized
INFO - 2017-12-31 20:01:15 --> URI Class Initialized
INFO - 2017-12-31 20:01:15 --> Router Class Initialized
INFO - 2017-12-31 20:01:15 --> Output Class Initialized
INFO - 2017-12-31 20:01:15 --> Security Class Initialized
DEBUG - 2017-12-31 20:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-31 20:01:15 --> Input Class Initialized
INFO - 2017-12-31 20:01:15 --> Language Class Initialized
INFO - 2017-12-31 20:01:15 --> Loader Class Initialized
INFO - 2017-12-31 20:01:15 --> Helper loaded: url_helper
INFO - 2017-12-31 20:01:15 --> Helper loaded: form_helper
INFO - 2017-12-31 20:01:15 --> Database Driver Class Initialized
DEBUG - 2017-12-31 20:01:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-31 20:01:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-31 20:01:15 --> Form Validation Class Initialized
INFO - 2017-12-31 20:01:15 --> Model Class Initialized
INFO - 2017-12-31 20:01:15 --> Controller Class Initialized
INFO - 2017-12-31 20:01:15 --> Model Class Initialized
INFO - 2017-12-31 20:01:15 --> Model Class Initialized
INFO - 2017-12-31 20:01:15 --> Model Class Initialized
INFO - 2017-12-31 20:01:15 --> Model Class Initialized
DEBUG - 2017-12-31 20:01:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-31 20:01:15 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-31 20:01:15 --> Final output sent to browser
DEBUG - 2017-12-31 20:01:15 --> Total execution time: 0.0735
INFO - 2017-12-31 20:01:15 --> Config Class Initialized
INFO - 2017-12-31 20:01:15 --> Hooks Class Initialized
DEBUG - 2017-12-31 20:01:15 --> UTF-8 Support Enabled
INFO - 2017-12-31 20:01:15 --> Utf8 Class Initialized
INFO - 2017-12-31 20:01:15 --> URI Class Initialized
INFO - 2017-12-31 20:01:15 --> Router Class Initialized
INFO - 2017-12-31 20:01:15 --> Output Class Initialized
INFO - 2017-12-31 20:01:15 --> Security Class Initialized
DEBUG - 2017-12-31 20:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-31 20:01:15 --> Input Class Initialized
INFO - 2017-12-31 20:01:15 --> Language Class Initialized
INFO - 2017-12-31 20:01:15 --> Loader Class Initialized
INFO - 2017-12-31 20:01:15 --> Helper loaded: url_helper
INFO - 2017-12-31 20:01:15 --> Helper loaded: form_helper
INFO - 2017-12-31 20:01:15 --> Database Driver Class Initialized
DEBUG - 2017-12-31 20:01:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-31 20:01:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-31 20:01:15 --> Form Validation Class Initialized
INFO - 2017-12-31 20:01:15 --> Model Class Initialized
INFO - 2017-12-31 20:01:15 --> Controller Class Initialized
INFO - 2017-12-31 20:01:15 --> Model Class Initialized
INFO - 2017-12-31 20:01:15 --> Model Class Initialized
INFO - 2017-12-31 20:01:15 --> Model Class Initialized
INFO - 2017-12-31 20:01:15 --> Model Class Initialized
DEBUG - 2017-12-31 20:01:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-31 20:01:26 --> Config Class Initialized
INFO - 2017-12-31 20:01:26 --> Hooks Class Initialized
DEBUG - 2017-12-31 20:01:26 --> UTF-8 Support Enabled
INFO - 2017-12-31 20:01:26 --> Utf8 Class Initialized
INFO - 2017-12-31 20:01:26 --> URI Class Initialized
INFO - 2017-12-31 20:01:26 --> Router Class Initialized
INFO - 2017-12-31 20:01:26 --> Output Class Initialized
INFO - 2017-12-31 20:01:26 --> Security Class Initialized
DEBUG - 2017-12-31 20:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-31 20:01:26 --> Input Class Initialized
INFO - 2017-12-31 20:01:26 --> Language Class Initialized
INFO - 2017-12-31 20:01:26 --> Loader Class Initialized
INFO - 2017-12-31 20:01:26 --> Helper loaded: url_helper
INFO - 2017-12-31 20:01:26 --> Helper loaded: form_helper
INFO - 2017-12-31 20:01:26 --> Database Driver Class Initialized
DEBUG - 2017-12-31 20:01:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-31 20:01:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-31 20:01:26 --> Form Validation Class Initialized
INFO - 2017-12-31 20:01:26 --> Model Class Initialized
INFO - 2017-12-31 20:01:26 --> Controller Class Initialized
INFO - 2017-12-31 20:01:26 --> Model Class Initialized
INFO - 2017-12-31 20:01:26 --> Model Class Initialized
INFO - 2017-12-31 20:01:26 --> Model Class Initialized
INFO - 2017-12-31 20:01:26 --> Model Class Initialized
DEBUG - 2017-12-31 20:01:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-31 20:01:26 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-31 20:01:26 --> Final output sent to browser
DEBUG - 2017-12-31 20:01:26 --> Total execution time: 0.1193
INFO - 2017-12-31 20:01:26 --> Config Class Initialized
INFO - 2017-12-31 20:01:26 --> Hooks Class Initialized
INFO - 2017-12-31 20:01:26 --> Config Class Initialized
INFO - 2017-12-31 20:01:26 --> Hooks Class Initialized
DEBUG - 2017-12-31 20:01:26 --> UTF-8 Support Enabled
INFO - 2017-12-31 20:01:26 --> Utf8 Class Initialized
DEBUG - 2017-12-31 20:01:26 --> UTF-8 Support Enabled
INFO - 2017-12-31 20:01:26 --> URI Class Initialized
INFO - 2017-12-31 20:01:26 --> Utf8 Class Initialized
INFO - 2017-12-31 20:01:26 --> URI Class Initialized
INFO - 2017-12-31 20:01:26 --> Router Class Initialized
INFO - 2017-12-31 20:01:26 --> Router Class Initialized
INFO - 2017-12-31 20:01:26 --> Output Class Initialized
INFO - 2017-12-31 20:01:26 --> Output Class Initialized
INFO - 2017-12-31 20:01:26 --> Security Class Initialized
INFO - 2017-12-31 20:01:26 --> Security Class Initialized
DEBUG - 2017-12-31 20:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-31 20:01:26 --> Input Class Initialized
INFO - 2017-12-31 20:01:26 --> Language Class Initialized
DEBUG - 2017-12-31 20:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-31 20:01:26 --> Input Class Initialized
INFO - 2017-12-31 20:01:26 --> Language Class Initialized
INFO - 2017-12-31 20:01:26 --> Loader Class Initialized
INFO - 2017-12-31 20:01:26 --> Loader Class Initialized
INFO - 2017-12-31 20:01:26 --> Helper loaded: url_helper
INFO - 2017-12-31 20:01:26 --> Helper loaded: url_helper
INFO - 2017-12-31 20:01:26 --> Helper loaded: form_helper
INFO - 2017-12-31 20:01:26 --> Helper loaded: form_helper
INFO - 2017-12-31 20:01:26 --> Database Driver Class Initialized
INFO - 2017-12-31 20:01:26 --> Database Driver Class Initialized
DEBUG - 2017-12-31 20:01:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-31 20:01:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-31 20:01:26 --> Form Validation Class Initialized
INFO - 2017-12-31 20:01:26 --> Model Class Initialized
INFO - 2017-12-31 20:01:26 --> Controller Class Initialized
INFO - 2017-12-31 20:01:26 --> Model Class Initialized
INFO - 2017-12-31 20:01:26 --> Model Class Initialized
INFO - 2017-12-31 20:01:26 --> Model Class Initialized
DEBUG - 2017-12-31 20:01:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-31 20:01:26 --> Model Class Initialized
DEBUG - 2017-12-31 20:01:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-31 20:01:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-31 20:01:26 --> Form Validation Class Initialized
INFO - 2017-12-31 20:01:26 --> Model Class Initialized
INFO - 2017-12-31 20:01:26 --> Controller Class Initialized
INFO - 2017-12-31 20:01:26 --> Model Class Initialized
INFO - 2017-12-31 20:01:26 --> Model Class Initialized
INFO - 2017-12-31 20:01:26 --> Model Class Initialized
INFO - 2017-12-31 20:01:26 --> Model Class Initialized
DEBUG - 2017-12-31 20:01:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-31 20:01:53 --> Config Class Initialized
INFO - 2017-12-31 20:01:53 --> Hooks Class Initialized
DEBUG - 2017-12-31 20:01:53 --> UTF-8 Support Enabled
INFO - 2017-12-31 20:01:53 --> Utf8 Class Initialized
INFO - 2017-12-31 20:01:53 --> URI Class Initialized
INFO - 2017-12-31 20:01:53 --> Router Class Initialized
INFO - 2017-12-31 20:01:53 --> Output Class Initialized
INFO - 2017-12-31 20:01:53 --> Security Class Initialized
DEBUG - 2017-12-31 20:01:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-31 20:01:53 --> Input Class Initialized
INFO - 2017-12-31 20:01:53 --> Language Class Initialized
INFO - 2017-12-31 20:01:53 --> Loader Class Initialized
INFO - 2017-12-31 20:01:53 --> Helper loaded: url_helper
INFO - 2017-12-31 20:01:53 --> Helper loaded: form_helper
INFO - 2017-12-31 20:01:53 --> Database Driver Class Initialized
DEBUG - 2017-12-31 20:01:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-31 20:01:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-31 20:01:53 --> Form Validation Class Initialized
INFO - 2017-12-31 20:01:53 --> Model Class Initialized
INFO - 2017-12-31 20:01:53 --> Controller Class Initialized
INFO - 2017-12-31 20:01:53 --> Model Class Initialized
INFO - 2017-12-31 20:01:53 --> Model Class Initialized
INFO - 2017-12-31 20:01:53 --> Model Class Initialized
INFO - 2017-12-31 20:01:53 --> Model Class Initialized
DEBUG - 2017-12-31 20:01:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-31 20:01:53 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-31 20:01:53 --> Final output sent to browser
DEBUG - 2017-12-31 20:01:53 --> Total execution time: 0.5944
INFO - 2017-12-31 20:01:53 --> Config Class Initialized
INFO - 2017-12-31 20:01:53 --> Hooks Class Initialized
INFO - 2017-12-31 20:01:53 --> Config Class Initialized
INFO - 2017-12-31 20:01:53 --> Hooks Class Initialized
DEBUG - 2017-12-31 20:01:53 --> UTF-8 Support Enabled
INFO - 2017-12-31 20:01:53 --> Utf8 Class Initialized
DEBUG - 2017-12-31 20:01:53 --> UTF-8 Support Enabled
INFO - 2017-12-31 20:01:53 --> Utf8 Class Initialized
INFO - 2017-12-31 20:01:53 --> URI Class Initialized
INFO - 2017-12-31 20:01:53 --> URI Class Initialized
INFO - 2017-12-31 20:01:53 --> Router Class Initialized
INFO - 2017-12-31 20:01:53 --> Router Class Initialized
INFO - 2017-12-31 20:01:53 --> Output Class Initialized
INFO - 2017-12-31 20:01:53 --> Output Class Initialized
INFO - 2017-12-31 20:01:53 --> Security Class Initialized
INFO - 2017-12-31 20:01:53 --> Security Class Initialized
DEBUG - 2017-12-31 20:01:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-31 20:01:53 --> Input Class Initialized
DEBUG - 2017-12-31 20:01:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-31 20:01:53 --> Input Class Initialized
INFO - 2017-12-31 20:01:53 --> Language Class Initialized
INFO - 2017-12-31 20:01:53 --> Language Class Initialized
INFO - 2017-12-31 20:01:53 --> Loader Class Initialized
INFO - 2017-12-31 20:01:53 --> Loader Class Initialized
INFO - 2017-12-31 20:01:53 --> Helper loaded: url_helper
INFO - 2017-12-31 20:01:53 --> Helper loaded: url_helper
INFO - 2017-12-31 20:01:53 --> Helper loaded: form_helper
INFO - 2017-12-31 20:01:53 --> Helper loaded: form_helper
INFO - 2017-12-31 20:01:53 --> Database Driver Class Initialized
INFO - 2017-12-31 20:01:53 --> Database Driver Class Initialized
DEBUG - 2017-12-31 20:01:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-31 20:01:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-31 20:01:53 --> Form Validation Class Initialized
DEBUG - 2017-12-31 20:01:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-31 20:01:53 --> Model Class Initialized
INFO - 2017-12-31 20:01:53 --> Controller Class Initialized
INFO - 2017-12-31 20:01:53 --> Model Class Initialized
INFO - 2017-12-31 20:01:53 --> Model Class Initialized
INFO - 2017-12-31 20:01:53 --> Model Class Initialized
INFO - 2017-12-31 20:01:53 --> Model Class Initialized
DEBUG - 2017-12-31 20:01:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-31 20:01:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-31 20:01:53 --> Form Validation Class Initialized
INFO - 2017-12-31 20:01:53 --> Model Class Initialized
INFO - 2017-12-31 20:01:53 --> Controller Class Initialized
INFO - 2017-12-31 20:01:53 --> Model Class Initialized
INFO - 2017-12-31 20:01:53 --> Model Class Initialized
INFO - 2017-12-31 20:01:53 --> Model Class Initialized
INFO - 2017-12-31 20:01:53 --> Model Class Initialized
DEBUG - 2017-12-31 20:01:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-31 20:01:59 --> Config Class Initialized
INFO - 2017-12-31 20:01:59 --> Hooks Class Initialized
DEBUG - 2017-12-31 20:01:59 --> UTF-8 Support Enabled
INFO - 2017-12-31 20:01:59 --> Utf8 Class Initialized
INFO - 2017-12-31 20:01:59 --> URI Class Initialized
INFO - 2017-12-31 20:01:59 --> Router Class Initialized
INFO - 2017-12-31 20:01:59 --> Output Class Initialized
INFO - 2017-12-31 20:01:59 --> Security Class Initialized
DEBUG - 2017-12-31 20:01:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-31 20:01:59 --> Input Class Initialized
INFO - 2017-12-31 20:01:59 --> Language Class Initialized
INFO - 2017-12-31 20:01:59 --> Loader Class Initialized
INFO - 2017-12-31 20:01:59 --> Helper loaded: url_helper
INFO - 2017-12-31 20:01:59 --> Helper loaded: form_helper
INFO - 2017-12-31 20:01:59 --> Database Driver Class Initialized
DEBUG - 2017-12-31 20:01:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-31 20:01:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-31 20:01:59 --> Form Validation Class Initialized
INFO - 2017-12-31 20:01:59 --> Model Class Initialized
INFO - 2017-12-31 20:01:59 --> Controller Class Initialized
INFO - 2017-12-31 20:01:59 --> Model Class Initialized
INFO - 2017-12-31 20:01:59 --> Model Class Initialized
INFO - 2017-12-31 20:01:59 --> Model Class Initialized
INFO - 2017-12-31 20:01:59 --> Model Class Initialized
DEBUG - 2017-12-31 20:01:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-31 20:01:59 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-31 20:01:59 --> Final output sent to browser
DEBUG - 2017-12-31 20:01:59 --> Total execution time: 0.0660
INFO - 2017-12-31 20:02:00 --> Config Class Initialized
INFO - 2017-12-31 20:02:00 --> Hooks Class Initialized
DEBUG - 2017-12-31 20:02:00 --> UTF-8 Support Enabled
INFO - 2017-12-31 20:02:00 --> Utf8 Class Initialized
INFO - 2017-12-31 20:02:00 --> URI Class Initialized
INFO - 2017-12-31 20:02:00 --> Router Class Initialized
INFO - 2017-12-31 20:02:00 --> Output Class Initialized
INFO - 2017-12-31 20:02:00 --> Security Class Initialized
DEBUG - 2017-12-31 20:02:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-31 20:02:00 --> Input Class Initialized
INFO - 2017-12-31 20:02:00 --> Language Class Initialized
INFO - 2017-12-31 20:02:00 --> Loader Class Initialized
INFO - 2017-12-31 20:02:00 --> Helper loaded: url_helper
INFO - 2017-12-31 20:02:00 --> Helper loaded: form_helper
INFO - 2017-12-31 20:02:00 --> Database Driver Class Initialized
DEBUG - 2017-12-31 20:02:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-31 20:02:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-31 20:02:00 --> Form Validation Class Initialized
INFO - 2017-12-31 20:02:00 --> Model Class Initialized
INFO - 2017-12-31 20:02:00 --> Controller Class Initialized
INFO - 2017-12-31 20:02:00 --> Model Class Initialized
INFO - 2017-12-31 20:02:00 --> Model Class Initialized
INFO - 2017-12-31 20:02:00 --> Model Class Initialized
INFO - 2017-12-31 20:02:00 --> Model Class Initialized
DEBUG - 2017-12-31 20:02:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-31 20:02:19 --> Config Class Initialized
INFO - 2017-12-31 20:02:19 --> Hooks Class Initialized
DEBUG - 2017-12-31 20:02:19 --> UTF-8 Support Enabled
INFO - 2017-12-31 20:02:19 --> Utf8 Class Initialized
INFO - 2017-12-31 20:02:19 --> URI Class Initialized
INFO - 2017-12-31 20:02:19 --> Router Class Initialized
INFO - 2017-12-31 20:02:19 --> Output Class Initialized
INFO - 2017-12-31 20:02:19 --> Security Class Initialized
DEBUG - 2017-12-31 20:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-31 20:02:19 --> Input Class Initialized
INFO - 2017-12-31 20:02:19 --> Language Class Initialized
INFO - 2017-12-31 20:02:19 --> Loader Class Initialized
INFO - 2017-12-31 20:02:19 --> Helper loaded: url_helper
INFO - 2017-12-31 20:02:19 --> Helper loaded: form_helper
INFO - 2017-12-31 20:02:19 --> Database Driver Class Initialized
DEBUG - 2017-12-31 20:02:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-31 20:02:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-31 20:02:19 --> Form Validation Class Initialized
INFO - 2017-12-31 20:02:19 --> Model Class Initialized
INFO - 2017-12-31 20:02:19 --> Controller Class Initialized
INFO - 2017-12-31 20:02:19 --> Model Class Initialized
INFO - 2017-12-31 20:02:19 --> Model Class Initialized
INFO - 2017-12-31 20:02:19 --> Model Class Initialized
INFO - 2017-12-31 20:02:19 --> Model Class Initialized
DEBUG - 2017-12-31 20:02:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-31 20:02:19 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-31 20:02:19 --> Final output sent to browser
DEBUG - 2017-12-31 20:02:19 --> Total execution time: 0.0800
INFO - 2017-12-31 20:02:19 --> Config Class Initialized
INFO - 2017-12-31 20:02:19 --> Hooks Class Initialized
DEBUG - 2017-12-31 20:02:19 --> UTF-8 Support Enabled
INFO - 2017-12-31 20:02:19 --> Utf8 Class Initialized
INFO - 2017-12-31 20:02:19 --> URI Class Initialized
INFO - 2017-12-31 20:02:19 --> Router Class Initialized
INFO - 2017-12-31 20:02:19 --> Output Class Initialized
INFO - 2017-12-31 20:02:19 --> Security Class Initialized
DEBUG - 2017-12-31 20:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-31 20:02:19 --> Input Class Initialized
INFO - 2017-12-31 20:02:19 --> Language Class Initialized
INFO - 2017-12-31 20:02:19 --> Loader Class Initialized
INFO - 2017-12-31 20:02:19 --> Helper loaded: url_helper
INFO - 2017-12-31 20:02:19 --> Helper loaded: form_helper
INFO - 2017-12-31 20:02:19 --> Database Driver Class Initialized
DEBUG - 2017-12-31 20:02:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-31 20:02:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-31 20:02:19 --> Form Validation Class Initialized
INFO - 2017-12-31 20:02:19 --> Model Class Initialized
INFO - 2017-12-31 20:02:19 --> Controller Class Initialized
INFO - 2017-12-31 20:02:19 --> Model Class Initialized
INFO - 2017-12-31 20:02:19 --> Model Class Initialized
INFO - 2017-12-31 20:02:19 --> Model Class Initialized
INFO - 2017-12-31 20:02:19 --> Model Class Initialized
DEBUG - 2017-12-31 20:02:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-31 23:58:35 --> Config Class Initialized
INFO - 2017-12-31 23:58:35 --> Hooks Class Initialized
DEBUG - 2017-12-31 23:58:35 --> UTF-8 Support Enabled
INFO - 2017-12-31 23:58:35 --> Utf8 Class Initialized
INFO - 2017-12-31 23:58:35 --> URI Class Initialized
INFO - 2017-12-31 23:58:35 --> Router Class Initialized
INFO - 2017-12-31 23:58:35 --> Output Class Initialized
INFO - 2017-12-31 23:58:35 --> Security Class Initialized
DEBUG - 2017-12-31 23:58:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-31 23:58:35 --> Input Class Initialized
INFO - 2017-12-31 23:58:35 --> Language Class Initialized
INFO - 2017-12-31 23:58:35 --> Loader Class Initialized
INFO - 2017-12-31 23:58:35 --> Helper loaded: url_helper
INFO - 2017-12-31 23:58:35 --> Helper loaded: form_helper
INFO - 2017-12-31 23:58:35 --> Database Driver Class Initialized
DEBUG - 2017-12-31 23:58:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-31 23:58:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-31 23:58:35 --> Form Validation Class Initialized
INFO - 2017-12-31 23:58:35 --> Model Class Initialized
INFO - 2017-12-31 23:58:35 --> Controller Class Initialized
INFO - 2017-12-31 23:58:35 --> Model Class Initialized
DEBUG - 2017-12-31 23:58:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-31 23:58:35 --> Config Class Initialized
INFO - 2017-12-31 23:58:35 --> Hooks Class Initialized
DEBUG - 2017-12-31 23:58:35 --> UTF-8 Support Enabled
INFO - 2017-12-31 23:58:35 --> Utf8 Class Initialized
INFO - 2017-12-31 23:58:35 --> URI Class Initialized
INFO - 2017-12-31 23:58:35 --> Router Class Initialized
INFO - 2017-12-31 23:58:35 --> Output Class Initialized
INFO - 2017-12-31 23:58:35 --> Security Class Initialized
DEBUG - 2017-12-31 23:58:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-31 23:58:35 --> Input Class Initialized
INFO - 2017-12-31 23:58:35 --> Language Class Initialized
INFO - 2017-12-31 23:58:35 --> Loader Class Initialized
INFO - 2017-12-31 23:58:35 --> Helper loaded: url_helper
INFO - 2017-12-31 23:58:35 --> Helper loaded: form_helper
INFO - 2017-12-31 23:58:35 --> Database Driver Class Initialized
DEBUG - 2017-12-31 23:58:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-31 23:58:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-31 23:58:35 --> Form Validation Class Initialized
INFO - 2017-12-31 23:58:35 --> Model Class Initialized
INFO - 2017-12-31 23:58:35 --> Controller Class Initialized
INFO - 2017-12-31 23:58:35 --> Model Class Initialized
DEBUG - 2017-12-31 23:58:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-31 23:58:35 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-31 23:58:35 --> Final output sent to browser
DEBUG - 2017-12-31 23:58:35 --> Total execution time: 0.0739
