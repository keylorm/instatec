<div class="row row-bienvenida">
	<div class="col-12">
		<h1 class="fgris text-center">Bienvenido</h1>
	</div>
</div>
