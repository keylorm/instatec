<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-12-30 00:03:11 --> Config Class Initialized
INFO - 2017-12-30 00:03:11 --> Hooks Class Initialized
DEBUG - 2017-12-30 00:03:11 --> UTF-8 Support Enabled
INFO - 2017-12-30 00:03:11 --> Utf8 Class Initialized
INFO - 2017-12-30 00:03:11 --> URI Class Initialized
DEBUG - 2017-12-30 00:03:11 --> No URI present. Default controller set.
INFO - 2017-12-30 00:03:11 --> Router Class Initialized
INFO - 2017-12-30 00:03:11 --> Output Class Initialized
INFO - 2017-12-30 00:03:11 --> Security Class Initialized
DEBUG - 2017-12-30 00:03:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-30 00:03:11 --> Input Class Initialized
INFO - 2017-12-30 00:03:11 --> Language Class Initialized
INFO - 2017-12-30 00:03:11 --> Loader Class Initialized
INFO - 2017-12-30 00:03:11 --> Helper loaded: url_helper
INFO - 2017-12-30 00:03:11 --> Helper loaded: form_helper
INFO - 2017-12-30 00:03:11 --> Database Driver Class Initialized
DEBUG - 2017-12-30 00:03:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-30 00:03:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-30 00:03:11 --> Form Validation Class Initialized
INFO - 2017-12-30 00:03:11 --> Model Class Initialized
INFO - 2017-12-30 00:03:11 --> Controller Class Initialized
INFO - 2017-12-30 00:03:11 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-30 00:03:11 --> Final output sent to browser
DEBUG - 2017-12-30 00:03:11 --> Total execution time: 0.0783
