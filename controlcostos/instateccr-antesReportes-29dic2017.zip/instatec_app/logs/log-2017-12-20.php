<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-12-20 03:16:02 --> Config Class Initialized
INFO - 2017-12-20 03:16:02 --> Hooks Class Initialized
DEBUG - 2017-12-20 03:16:02 --> UTF-8 Support Enabled
INFO - 2017-12-20 03:16:02 --> Utf8 Class Initialized
INFO - 2017-12-20 03:16:02 --> URI Class Initialized
INFO - 2017-12-20 03:16:02 --> Router Class Initialized
INFO - 2017-12-20 03:16:02 --> Output Class Initialized
INFO - 2017-12-20 03:16:02 --> Security Class Initialized
DEBUG - 2017-12-20 03:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-20 03:16:02 --> Input Class Initialized
INFO - 2017-12-20 03:16:02 --> Language Class Initialized
INFO - 2017-12-20 03:16:02 --> Loader Class Initialized
INFO - 2017-12-20 03:16:02 --> Helper loaded: url_helper
INFO - 2017-12-20 03:16:02 --> Helper loaded: form_helper
INFO - 2017-12-20 03:16:02 --> Database Driver Class Initialized
DEBUG - 2017-12-20 03:16:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-20 03:16:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-20 03:16:02 --> Form Validation Class Initialized
INFO - 2017-12-20 03:16:02 --> Model Class Initialized
INFO - 2017-12-20 03:16:02 --> Controller Class Initialized
INFO - 2017-12-20 03:16:02 --> Model Class Initialized
INFO - 2017-12-20 03:16:02 --> Model Class Initialized
INFO - 2017-12-20 03:16:02 --> Model Class Initialized
DEBUG - 2017-12-20 03:16:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-20 03:16:02 --> Config Class Initialized
INFO - 2017-12-20 03:16:02 --> Hooks Class Initialized
DEBUG - 2017-12-20 03:16:02 --> UTF-8 Support Enabled
INFO - 2017-12-20 03:16:02 --> Utf8 Class Initialized
INFO - 2017-12-20 03:16:02 --> URI Class Initialized
INFO - 2017-12-20 03:16:02 --> Router Class Initialized
INFO - 2017-12-20 03:16:02 --> Output Class Initialized
INFO - 2017-12-20 03:16:02 --> Security Class Initialized
DEBUG - 2017-12-20 03:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-20 03:16:02 --> Input Class Initialized
INFO - 2017-12-20 03:16:02 --> Language Class Initialized
INFO - 2017-12-20 03:16:02 --> Loader Class Initialized
INFO - 2017-12-20 03:16:02 --> Helper loaded: url_helper
INFO - 2017-12-20 03:16:02 --> Helper loaded: form_helper
INFO - 2017-12-20 03:16:02 --> Database Driver Class Initialized
DEBUG - 2017-12-20 03:16:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-20 03:16:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-20 03:16:02 --> Form Validation Class Initialized
INFO - 2017-12-20 03:16:02 --> Model Class Initialized
INFO - 2017-12-20 03:16:02 --> Controller Class Initialized
INFO - 2017-12-20 03:16:02 --> Model Class Initialized
DEBUG - 2017-12-20 03:16:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-20 03:16:03 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-20 03:16:03 --> Final output sent to browser
DEBUG - 2017-12-20 03:16:03 --> Total execution time: 0.1464
INFO - 2017-12-20 03:16:03 --> Config Class Initialized
INFO - 2017-12-20 03:16:03 --> Hooks Class Initialized
INFO - 2017-12-20 03:16:03 --> Config Class Initialized
DEBUG - 2017-12-20 03:16:03 --> UTF-8 Support Enabled
INFO - 2017-12-20 03:16:03 --> Hooks Class Initialized
INFO - 2017-12-20 03:16:03 --> Utf8 Class Initialized
INFO - 2017-12-20 03:16:03 --> Config Class Initialized
INFO - 2017-12-20 03:16:03 --> Hooks Class Initialized
INFO - 2017-12-20 03:16:03 --> URI Class Initialized
DEBUG - 2017-12-20 03:16:03 --> UTF-8 Support Enabled
INFO - 2017-12-20 03:16:03 --> Utf8 Class Initialized
INFO - 2017-12-20 03:16:03 --> Router Class Initialized
DEBUG - 2017-12-20 03:16:03 --> UTF-8 Support Enabled
INFO - 2017-12-20 03:16:03 --> Utf8 Class Initialized
INFO - 2017-12-20 03:16:03 --> URI Class Initialized
INFO - 2017-12-20 03:16:03 --> Output Class Initialized
INFO - 2017-12-20 03:16:03 --> URI Class Initialized
INFO - 2017-12-20 03:16:03 --> Router Class Initialized
INFO - 2017-12-20 03:16:03 --> Security Class Initialized
INFO - 2017-12-20 03:16:03 --> Router Class Initialized
DEBUG - 2017-12-20 03:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-20 03:16:03 --> Output Class Initialized
INFO - 2017-12-20 03:16:03 --> Input Class Initialized
INFO - 2017-12-20 03:16:03 --> Output Class Initialized
INFO - 2017-12-20 03:16:03 --> Language Class Initialized
INFO - 2017-12-20 03:16:03 --> Security Class Initialized
INFO - 2017-12-20 03:16:03 --> Security Class Initialized
DEBUG - 2017-12-20 03:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-20 03:16:03 --> Input Class Initialized
DEBUG - 2017-12-20 03:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-20 03:16:03 --> Language Class Initialized
INFO - 2017-12-20 03:16:03 --> Input Class Initialized
INFO - 2017-12-20 03:16:03 --> Language Class Initialized
ERROR - 2017-12-20 03:16:03 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2017-12-20 03:16:03 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-20 03:16:03 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-20 03:16:04 --> Config Class Initialized
INFO - 2017-12-20 03:16:04 --> Hooks Class Initialized
DEBUG - 2017-12-20 03:16:04 --> UTF-8 Support Enabled
INFO - 2017-12-20 03:16:04 --> Utf8 Class Initialized
INFO - 2017-12-20 03:16:04 --> URI Class Initialized
INFO - 2017-12-20 03:16:04 --> Router Class Initialized
INFO - 2017-12-20 03:16:04 --> Output Class Initialized
INFO - 2017-12-20 03:16:04 --> Security Class Initialized
DEBUG - 2017-12-20 03:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-20 03:16:04 --> Input Class Initialized
INFO - 2017-12-20 03:16:04 --> Language Class Initialized
INFO - 2017-12-20 03:16:04 --> Loader Class Initialized
INFO - 2017-12-20 03:16:04 --> Helper loaded: url_helper
INFO - 2017-12-20 03:16:04 --> Helper loaded: form_helper
INFO - 2017-12-20 03:16:04 --> Database Driver Class Initialized
DEBUG - 2017-12-20 03:16:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-20 03:16:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-20 03:16:04 --> Form Validation Class Initialized
INFO - 2017-12-20 03:16:04 --> Model Class Initialized
INFO - 2017-12-20 03:16:04 --> Controller Class Initialized
INFO - 2017-12-20 03:16:04 --> Model Class Initialized
DEBUG - 2017-12-20 03:16:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-20 03:16:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-12-20 03:16:04 --> Config Class Initialized
INFO - 2017-12-20 03:16:04 --> Hooks Class Initialized
DEBUG - 2017-12-20 03:16:04 --> UTF-8 Support Enabled
INFO - 2017-12-20 03:16:04 --> Utf8 Class Initialized
INFO - 2017-12-20 03:16:04 --> URI Class Initialized
DEBUG - 2017-12-20 03:16:04 --> No URI present. Default controller set.
INFO - 2017-12-20 03:16:04 --> Router Class Initialized
INFO - 2017-12-20 03:16:04 --> Output Class Initialized
INFO - 2017-12-20 03:16:04 --> Security Class Initialized
DEBUG - 2017-12-20 03:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-20 03:16:04 --> Input Class Initialized
INFO - 2017-12-20 03:16:04 --> Language Class Initialized
INFO - 2017-12-20 03:16:04 --> Loader Class Initialized
INFO - 2017-12-20 03:16:04 --> Helper loaded: url_helper
INFO - 2017-12-20 03:16:04 --> Helper loaded: form_helper
INFO - 2017-12-20 03:16:04 --> Database Driver Class Initialized
DEBUG - 2017-12-20 03:16:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-20 03:16:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-20 03:16:04 --> Form Validation Class Initialized
INFO - 2017-12-20 03:16:04 --> Model Class Initialized
INFO - 2017-12-20 03:16:04 --> Controller Class Initialized
INFO - 2017-12-20 03:16:04 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-20 03:16:04 --> Final output sent to browser
DEBUG - 2017-12-20 03:16:04 --> Total execution time: 0.0763
INFO - 2017-12-20 03:16:04 --> Config Class Initialized
INFO - 2017-12-20 03:16:04 --> Hooks Class Initialized
DEBUG - 2017-12-20 03:16:04 --> UTF-8 Support Enabled
INFO - 2017-12-20 03:16:04 --> Utf8 Class Initialized
INFO - 2017-12-20 03:16:04 --> Config Class Initialized
INFO - 2017-12-20 03:16:04 --> Config Class Initialized
INFO - 2017-12-20 03:16:04 --> Hooks Class Initialized
INFO - 2017-12-20 03:16:04 --> Hooks Class Initialized
INFO - 2017-12-20 03:16:04 --> URI Class Initialized
INFO - 2017-12-20 03:16:04 --> Router Class Initialized
DEBUG - 2017-12-20 03:16:04 --> UTF-8 Support Enabled
INFO - 2017-12-20 03:16:04 --> Utf8 Class Initialized
DEBUG - 2017-12-20 03:16:04 --> UTF-8 Support Enabled
INFO - 2017-12-20 03:16:04 --> Utf8 Class Initialized
INFO - 2017-12-20 03:16:04 --> Output Class Initialized
INFO - 2017-12-20 03:16:04 --> URI Class Initialized
INFO - 2017-12-20 03:16:04 --> URI Class Initialized
INFO - 2017-12-20 03:16:04 --> Security Class Initialized
INFO - 2017-12-20 03:16:04 --> Router Class Initialized
DEBUG - 2017-12-20 03:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-20 03:16:04 --> Router Class Initialized
INFO - 2017-12-20 03:16:04 --> Input Class Initialized
INFO - 2017-12-20 03:16:04 --> Output Class Initialized
INFO - 2017-12-20 03:16:04 --> Language Class Initialized
INFO - 2017-12-20 03:16:04 --> Output Class Initialized
INFO - 2017-12-20 03:16:04 --> Security Class Initialized
ERROR - 2017-12-20 03:16:04 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-20 03:16:04 --> Security Class Initialized
DEBUG - 2017-12-20 03:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-20 03:16:04 --> Input Class Initialized
DEBUG - 2017-12-20 03:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-20 03:16:04 --> Input Class Initialized
INFO - 2017-12-20 03:16:04 --> Language Class Initialized
INFO - 2017-12-20 03:16:04 --> Language Class Initialized
ERROR - 2017-12-20 03:16:04 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-20 03:16:04 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-20 03:16:16 --> Config Class Initialized
INFO - 2017-12-20 03:16:16 --> Hooks Class Initialized
DEBUG - 2017-12-20 03:16:16 --> UTF-8 Support Enabled
INFO - 2017-12-20 03:16:16 --> Utf8 Class Initialized
INFO - 2017-12-20 03:16:16 --> URI Class Initialized
DEBUG - 2017-12-20 03:16:16 --> No URI present. Default controller set.
INFO - 2017-12-20 03:16:16 --> Router Class Initialized
INFO - 2017-12-20 03:16:16 --> Output Class Initialized
INFO - 2017-12-20 03:16:16 --> Security Class Initialized
DEBUG - 2017-12-20 03:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-20 03:16:16 --> Input Class Initialized
INFO - 2017-12-20 03:16:16 --> Language Class Initialized
INFO - 2017-12-20 03:16:16 --> Loader Class Initialized
INFO - 2017-12-20 03:16:16 --> Helper loaded: url_helper
INFO - 2017-12-20 03:16:16 --> Helper loaded: form_helper
INFO - 2017-12-20 03:16:16 --> Database Driver Class Initialized
DEBUG - 2017-12-20 03:16:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-20 03:16:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-20 03:16:16 --> Form Validation Class Initialized
INFO - 2017-12-20 03:16:16 --> Model Class Initialized
INFO - 2017-12-20 03:16:16 --> Controller Class Initialized
INFO - 2017-12-20 03:16:16 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-20 03:16:16 --> Final output sent to browser
DEBUG - 2017-12-20 03:16:16 --> Total execution time: 0.0860
INFO - 2017-12-20 03:16:16 --> Config Class Initialized
INFO - 2017-12-20 03:16:16 --> Config Class Initialized
INFO - 2017-12-20 03:16:16 --> Hooks Class Initialized
INFO - 2017-12-20 03:16:16 --> Hooks Class Initialized
INFO - 2017-12-20 03:16:16 --> Config Class Initialized
INFO - 2017-12-20 03:16:16 --> Hooks Class Initialized
DEBUG - 2017-12-20 03:16:16 --> UTF-8 Support Enabled
INFO - 2017-12-20 03:16:16 --> Utf8 Class Initialized
DEBUG - 2017-12-20 03:16:16 --> UTF-8 Support Enabled
INFO - 2017-12-20 03:16:16 --> Utf8 Class Initialized
INFO - 2017-12-20 03:16:16 --> URI Class Initialized
DEBUG - 2017-12-20 03:16:16 --> UTF-8 Support Enabled
INFO - 2017-12-20 03:16:16 --> Utf8 Class Initialized
INFO - 2017-12-20 03:16:16 --> URI Class Initialized
INFO - 2017-12-20 03:16:16 --> URI Class Initialized
INFO - 2017-12-20 03:16:16 --> Router Class Initialized
INFO - 2017-12-20 03:16:16 --> Router Class Initialized
INFO - 2017-12-20 03:16:16 --> Output Class Initialized
INFO - 2017-12-20 03:16:16 --> Router Class Initialized
INFO - 2017-12-20 03:16:16 --> Output Class Initialized
INFO - 2017-12-20 03:16:16 --> Security Class Initialized
INFO - 2017-12-20 03:16:16 --> Output Class Initialized
INFO - 2017-12-20 03:16:16 --> Security Class Initialized
DEBUG - 2017-12-20 03:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-20 03:16:16 --> Input Class Initialized
INFO - 2017-12-20 03:16:16 --> Security Class Initialized
DEBUG - 2017-12-20 03:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-20 03:16:16 --> Language Class Initialized
INFO - 2017-12-20 03:16:16 --> Input Class Initialized
DEBUG - 2017-12-20 03:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-20 03:16:16 --> Input Class Initialized
INFO - 2017-12-20 03:16:16 --> Language Class Initialized
ERROR - 2017-12-20 03:16:16 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-20 03:16:16 --> Language Class Initialized
ERROR - 2017-12-20 03:16:16 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-20 03:16:16 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-20 03:16:19 --> Config Class Initialized
INFO - 2017-12-20 03:16:19 --> Hooks Class Initialized
DEBUG - 2017-12-20 03:16:19 --> UTF-8 Support Enabled
INFO - 2017-12-20 03:16:19 --> Utf8 Class Initialized
INFO - 2017-12-20 03:16:19 --> URI Class Initialized
DEBUG - 2017-12-20 03:16:19 --> No URI present. Default controller set.
INFO - 2017-12-20 03:16:19 --> Router Class Initialized
INFO - 2017-12-20 03:16:19 --> Output Class Initialized
INFO - 2017-12-20 03:16:19 --> Security Class Initialized
DEBUG - 2017-12-20 03:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-20 03:16:19 --> Input Class Initialized
INFO - 2017-12-20 03:16:19 --> Language Class Initialized
INFO - 2017-12-20 03:16:19 --> Loader Class Initialized
INFO - 2017-12-20 03:16:19 --> Helper loaded: url_helper
INFO - 2017-12-20 03:16:19 --> Helper loaded: form_helper
INFO - 2017-12-20 03:16:19 --> Database Driver Class Initialized
DEBUG - 2017-12-20 03:16:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-20 03:16:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-20 03:16:19 --> Form Validation Class Initialized
INFO - 2017-12-20 03:16:19 --> Model Class Initialized
INFO - 2017-12-20 03:16:19 --> Controller Class Initialized
INFO - 2017-12-20 03:16:19 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-20 03:16:19 --> Final output sent to browser
DEBUG - 2017-12-20 03:16:19 --> Total execution time: 0.0470
INFO - 2017-12-20 03:16:21 --> Config Class Initialized
INFO - 2017-12-20 03:16:21 --> Hooks Class Initialized
INFO - 2017-12-20 03:16:21 --> Config Class Initialized
INFO - 2017-12-20 03:16:21 --> Config Class Initialized
INFO - 2017-12-20 03:16:21 --> Hooks Class Initialized
INFO - 2017-12-20 03:16:21 --> Hooks Class Initialized
DEBUG - 2017-12-20 03:16:21 --> UTF-8 Support Enabled
INFO - 2017-12-20 03:16:21 --> Utf8 Class Initialized
DEBUG - 2017-12-20 03:16:21 --> UTF-8 Support Enabled
DEBUG - 2017-12-20 03:16:21 --> UTF-8 Support Enabled
INFO - 2017-12-20 03:16:21 --> Utf8 Class Initialized
INFO - 2017-12-20 03:16:21 --> Utf8 Class Initialized
INFO - 2017-12-20 03:16:21 --> URI Class Initialized
INFO - 2017-12-20 03:16:21 --> URI Class Initialized
INFO - 2017-12-20 03:16:21 --> URI Class Initialized
INFO - 2017-12-20 03:16:21 --> Router Class Initialized
INFO - 2017-12-20 03:16:21 --> Router Class Initialized
INFO - 2017-12-20 03:16:21 --> Router Class Initialized
INFO - 2017-12-20 03:16:21 --> Output Class Initialized
INFO - 2017-12-20 03:16:21 --> Output Class Initialized
INFO - 2017-12-20 03:16:21 --> Output Class Initialized
INFO - 2017-12-20 03:16:21 --> Security Class Initialized
INFO - 2017-12-20 03:16:21 --> Security Class Initialized
INFO - 2017-12-20 03:16:21 --> Security Class Initialized
DEBUG - 2017-12-20 03:16:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-20 03:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-20 03:16:21 --> Input Class Initialized
INFO - 2017-12-20 03:16:21 --> Input Class Initialized
INFO - 2017-12-20 03:16:21 --> Language Class Initialized
DEBUG - 2017-12-20 03:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-20 03:16:21 --> Language Class Initialized
INFO - 2017-12-20 03:16:21 --> Input Class Initialized
INFO - 2017-12-20 03:16:21 --> Language Class Initialized
ERROR - 2017-12-20 03:16:21 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-20 03:16:21 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-20 03:16:21 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-20 03:16:42 --> Config Class Initialized
INFO - 2017-12-20 03:16:42 --> Hooks Class Initialized
DEBUG - 2017-12-20 03:16:42 --> UTF-8 Support Enabled
INFO - 2017-12-20 03:16:42 --> Utf8 Class Initialized
INFO - 2017-12-20 03:16:42 --> URI Class Initialized
DEBUG - 2017-12-20 03:16:42 --> No URI present. Default controller set.
INFO - 2017-12-20 03:16:42 --> Router Class Initialized
INFO - 2017-12-20 03:16:42 --> Output Class Initialized
INFO - 2017-12-20 03:16:42 --> Security Class Initialized
DEBUG - 2017-12-20 03:16:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-20 03:16:42 --> Input Class Initialized
INFO - 2017-12-20 03:16:42 --> Language Class Initialized
INFO - 2017-12-20 03:16:42 --> Loader Class Initialized
INFO - 2017-12-20 03:16:42 --> Helper loaded: url_helper
INFO - 2017-12-20 03:16:42 --> Helper loaded: form_helper
INFO - 2017-12-20 03:16:42 --> Database Driver Class Initialized
DEBUG - 2017-12-20 03:16:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-20 03:16:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-20 03:16:42 --> Form Validation Class Initialized
INFO - 2017-12-20 03:16:42 --> Model Class Initialized
INFO - 2017-12-20 03:16:42 --> Controller Class Initialized
INFO - 2017-12-20 03:16:42 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-20 03:16:42 --> Final output sent to browser
DEBUG - 2017-12-20 03:16:42 --> Total execution time: 0.0472
INFO - 2017-12-20 03:16:42 --> Config Class Initialized
INFO - 2017-12-20 03:16:42 --> Hooks Class Initialized
INFO - 2017-12-20 03:16:42 --> Config Class Initialized
INFO - 2017-12-20 03:16:42 --> Hooks Class Initialized
INFO - 2017-12-20 03:16:42 --> Config Class Initialized
INFO - 2017-12-20 03:16:42 --> Hooks Class Initialized
DEBUG - 2017-12-20 03:16:42 --> UTF-8 Support Enabled
DEBUG - 2017-12-20 03:16:42 --> UTF-8 Support Enabled
INFO - 2017-12-20 03:16:42 --> Utf8 Class Initialized
INFO - 2017-12-20 03:16:42 --> Utf8 Class Initialized
INFO - 2017-12-20 03:16:42 --> URI Class Initialized
INFO - 2017-12-20 03:16:42 --> URI Class Initialized
DEBUG - 2017-12-20 03:16:42 --> UTF-8 Support Enabled
INFO - 2017-12-20 03:16:42 --> Utf8 Class Initialized
INFO - 2017-12-20 03:16:42 --> Router Class Initialized
INFO - 2017-12-20 03:16:42 --> URI Class Initialized
INFO - 2017-12-20 03:16:42 --> Router Class Initialized
INFO - 2017-12-20 03:16:42 --> Output Class Initialized
INFO - 2017-12-20 03:16:42 --> Output Class Initialized
INFO - 2017-12-20 03:16:42 --> Router Class Initialized
INFO - 2017-12-20 03:16:42 --> Security Class Initialized
INFO - 2017-12-20 03:16:42 --> Security Class Initialized
INFO - 2017-12-20 03:16:42 --> Output Class Initialized
DEBUG - 2017-12-20 03:16:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-20 03:16:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-20 03:16:42 --> Input Class Initialized
INFO - 2017-12-20 03:16:42 --> Input Class Initialized
INFO - 2017-12-20 03:16:42 --> Security Class Initialized
INFO - 2017-12-20 03:16:42 --> Language Class Initialized
INFO - 2017-12-20 03:16:42 --> Language Class Initialized
DEBUG - 2017-12-20 03:16:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2017-12-20 03:16:42 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-20 03:16:42 --> Input Class Initialized
ERROR - 2017-12-20 03:16:42 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-20 03:16:42 --> Language Class Initialized
ERROR - 2017-12-20 03:16:42 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-20 03:16:44 --> Config Class Initialized
INFO - 2017-12-20 03:16:44 --> Hooks Class Initialized
DEBUG - 2017-12-20 03:16:44 --> UTF-8 Support Enabled
INFO - 2017-12-20 03:16:44 --> Utf8 Class Initialized
INFO - 2017-12-20 03:16:44 --> URI Class Initialized
DEBUG - 2017-12-20 03:16:44 --> No URI present. Default controller set.
INFO - 2017-12-20 03:16:44 --> Router Class Initialized
INFO - 2017-12-20 03:16:44 --> Output Class Initialized
INFO - 2017-12-20 03:16:44 --> Security Class Initialized
DEBUG - 2017-12-20 03:16:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-20 03:16:44 --> Input Class Initialized
INFO - 2017-12-20 03:16:44 --> Language Class Initialized
INFO - 2017-12-20 03:16:44 --> Loader Class Initialized
INFO - 2017-12-20 03:16:44 --> Helper loaded: url_helper
INFO - 2017-12-20 03:16:44 --> Helper loaded: form_helper
INFO - 2017-12-20 03:16:44 --> Database Driver Class Initialized
DEBUG - 2017-12-20 03:16:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-20 03:16:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-20 03:16:44 --> Form Validation Class Initialized
INFO - 2017-12-20 03:16:44 --> Model Class Initialized
INFO - 2017-12-20 03:16:44 --> Controller Class Initialized
INFO - 2017-12-20 03:16:44 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-20 03:16:44 --> Final output sent to browser
DEBUG - 2017-12-20 03:16:44 --> Total execution time: 0.0480
INFO - 2017-12-20 03:16:45 --> Config Class Initialized
INFO - 2017-12-20 03:16:45 --> Hooks Class Initialized
INFO - 2017-12-20 03:16:45 --> Config Class Initialized
INFO - 2017-12-20 03:16:45 --> Hooks Class Initialized
INFO - 2017-12-20 03:16:45 --> Config Class Initialized
INFO - 2017-12-20 03:16:45 --> Hooks Class Initialized
DEBUG - 2017-12-20 03:16:45 --> UTF-8 Support Enabled
INFO - 2017-12-20 03:16:45 --> Utf8 Class Initialized
DEBUG - 2017-12-20 03:16:45 --> UTF-8 Support Enabled
INFO - 2017-12-20 03:16:45 --> Utf8 Class Initialized
DEBUG - 2017-12-20 03:16:45 --> UTF-8 Support Enabled
INFO - 2017-12-20 03:16:45 --> URI Class Initialized
INFO - 2017-12-20 03:16:45 --> Utf8 Class Initialized
INFO - 2017-12-20 03:16:45 --> URI Class Initialized
INFO - 2017-12-20 03:16:45 --> URI Class Initialized
INFO - 2017-12-20 03:16:45 --> Router Class Initialized
INFO - 2017-12-20 03:16:45 --> Router Class Initialized
INFO - 2017-12-20 03:16:45 --> Router Class Initialized
INFO - 2017-12-20 03:16:45 --> Output Class Initialized
INFO - 2017-12-20 03:16:45 --> Output Class Initialized
INFO - 2017-12-20 03:16:45 --> Security Class Initialized
INFO - 2017-12-20 03:16:45 --> Output Class Initialized
INFO - 2017-12-20 03:16:45 --> Security Class Initialized
DEBUG - 2017-12-20 03:16:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-20 03:16:45 --> Input Class Initialized
INFO - 2017-12-20 03:16:45 --> Security Class Initialized
DEBUG - 2017-12-20 03:16:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-20 03:16:45 --> Input Class Initialized
INFO - 2017-12-20 03:16:45 --> Language Class Initialized
DEBUG - 2017-12-20 03:16:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-20 03:16:45 --> Input Class Initialized
INFO - 2017-12-20 03:16:45 --> Language Class Initialized
INFO - 2017-12-20 03:16:45 --> Language Class Initialized
ERROR - 2017-12-20 03:16:45 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2017-12-20 03:16:45 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-20 03:16:45 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-20 03:17:23 --> Config Class Initialized
INFO - 2017-12-20 03:17:23 --> Hooks Class Initialized
DEBUG - 2017-12-20 03:17:23 --> UTF-8 Support Enabled
INFO - 2017-12-20 03:17:23 --> Utf8 Class Initialized
INFO - 2017-12-20 03:17:23 --> URI Class Initialized
DEBUG - 2017-12-20 03:17:23 --> No URI present. Default controller set.
INFO - 2017-12-20 03:17:23 --> Router Class Initialized
INFO - 2017-12-20 03:17:23 --> Output Class Initialized
INFO - 2017-12-20 03:17:23 --> Security Class Initialized
DEBUG - 2017-12-20 03:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-20 03:17:23 --> Input Class Initialized
INFO - 2017-12-20 03:17:23 --> Language Class Initialized
INFO - 2017-12-20 03:17:23 --> Loader Class Initialized
INFO - 2017-12-20 03:17:23 --> Helper loaded: url_helper
INFO - 2017-12-20 03:17:23 --> Helper loaded: form_helper
INFO - 2017-12-20 03:17:23 --> Database Driver Class Initialized
DEBUG - 2017-12-20 03:17:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-20 03:17:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-20 03:17:23 --> Form Validation Class Initialized
INFO - 2017-12-20 03:17:23 --> Model Class Initialized
INFO - 2017-12-20 03:17:23 --> Controller Class Initialized
INFO - 2017-12-20 03:17:23 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-20 03:17:23 --> Final output sent to browser
DEBUG - 2017-12-20 03:17:23 --> Total execution time: 0.1023
INFO - 2017-12-20 03:17:23 --> Config Class Initialized
INFO - 2017-12-20 03:17:23 --> Config Class Initialized
INFO - 2017-12-20 03:17:23 --> Hooks Class Initialized
INFO - 2017-12-20 03:17:23 --> Hooks Class Initialized
INFO - 2017-12-20 03:17:23 --> Config Class Initialized
INFO - 2017-12-20 03:17:23 --> Hooks Class Initialized
DEBUG - 2017-12-20 03:17:23 --> UTF-8 Support Enabled
INFO - 2017-12-20 03:17:23 --> Utf8 Class Initialized
DEBUG - 2017-12-20 03:17:23 --> UTF-8 Support Enabled
INFO - 2017-12-20 03:17:23 --> Utf8 Class Initialized
INFO - 2017-12-20 03:17:23 --> URI Class Initialized
DEBUG - 2017-12-20 03:17:23 --> UTF-8 Support Enabled
INFO - 2017-12-20 03:17:23 --> Utf8 Class Initialized
INFO - 2017-12-20 03:17:23 --> URI Class Initialized
INFO - 2017-12-20 03:17:23 --> URI Class Initialized
INFO - 2017-12-20 03:17:23 --> Router Class Initialized
INFO - 2017-12-20 03:17:23 --> Router Class Initialized
INFO - 2017-12-20 03:17:23 --> Router Class Initialized
INFO - 2017-12-20 03:17:23 --> Output Class Initialized
INFO - 2017-12-20 03:17:23 --> Output Class Initialized
INFO - 2017-12-20 03:17:23 --> Output Class Initialized
INFO - 2017-12-20 03:17:23 --> Security Class Initialized
INFO - 2017-12-20 03:17:23 --> Security Class Initialized
INFO - 2017-12-20 03:17:23 --> Security Class Initialized
DEBUG - 2017-12-20 03:17:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-12-20 03:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-20 03:17:23 --> Input Class Initialized
INFO - 2017-12-20 03:17:23 --> Input Class Initialized
DEBUG - 2017-12-20 03:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-20 03:17:23 --> Input Class Initialized
INFO - 2017-12-20 03:17:23 --> Language Class Initialized
INFO - 2017-12-20 03:17:23 --> Language Class Initialized
INFO - 2017-12-20 03:17:23 --> Language Class Initialized
ERROR - 2017-12-20 03:17:23 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-20 03:17:23 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2017-12-20 03:17:23 --> 404 Page Not Found: Instatec_pub/js
INFO - 2017-12-20 03:17:26 --> Config Class Initialized
INFO - 2017-12-20 03:17:26 --> Hooks Class Initialized
DEBUG - 2017-12-20 03:17:26 --> UTF-8 Support Enabled
INFO - 2017-12-20 03:17:26 --> Utf8 Class Initialized
INFO - 2017-12-20 03:17:26 --> URI Class Initialized
DEBUG - 2017-12-20 03:17:26 --> No URI present. Default controller set.
INFO - 2017-12-20 03:17:26 --> Router Class Initialized
INFO - 2017-12-20 03:17:26 --> Output Class Initialized
INFO - 2017-12-20 03:17:26 --> Security Class Initialized
DEBUG - 2017-12-20 03:17:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-20 03:17:26 --> Input Class Initialized
INFO - 2017-12-20 03:17:26 --> Language Class Initialized
INFO - 2017-12-20 03:17:26 --> Loader Class Initialized
INFO - 2017-12-20 03:17:26 --> Helper loaded: url_helper
INFO - 2017-12-20 03:17:26 --> Helper loaded: form_helper
INFO - 2017-12-20 03:17:26 --> Database Driver Class Initialized
DEBUG - 2017-12-20 03:17:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-20 03:17:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-20 03:17:26 --> Form Validation Class Initialized
INFO - 2017-12-20 03:17:26 --> Model Class Initialized
INFO - 2017-12-20 03:17:26 --> Controller Class Initialized
INFO - 2017-12-20 03:17:26 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-20 03:17:26 --> Final output sent to browser
DEBUG - 2017-12-20 03:17:26 --> Total execution time: 0.0533
INFO - 2017-12-20 03:17:26 --> Config Class Initialized
INFO - 2017-12-20 03:17:26 --> Hooks Class Initialized
INFO - 2017-12-20 03:17:26 --> Config Class Initialized
INFO - 2017-12-20 03:17:26 --> Config Class Initialized
INFO - 2017-12-20 03:17:26 --> Hooks Class Initialized
INFO - 2017-12-20 03:17:26 --> Hooks Class Initialized
DEBUG - 2017-12-20 03:17:26 --> UTF-8 Support Enabled
INFO - 2017-12-20 03:17:26 --> Utf8 Class Initialized
INFO - 2017-12-20 03:17:26 --> URI Class Initialized
DEBUG - 2017-12-20 03:17:26 --> UTF-8 Support Enabled
INFO - 2017-12-20 03:17:26 --> Utf8 Class Initialized
DEBUG - 2017-12-20 03:17:26 --> UTF-8 Support Enabled
INFO - 2017-12-20 03:17:26 --> Utf8 Class Initialized
INFO - 2017-12-20 03:17:26 --> Router Class Initialized
INFO - 2017-12-20 03:17:26 --> URI Class Initialized
INFO - 2017-12-20 03:17:26 --> URI Class Initialized
INFO - 2017-12-20 03:17:26 --> Router Class Initialized
INFO - 2017-12-20 03:17:26 --> Output Class Initialized
INFO - 2017-12-20 03:17:26 --> Router Class Initialized
INFO - 2017-12-20 03:17:26 --> Output Class Initialized
INFO - 2017-12-20 03:17:26 --> Security Class Initialized
INFO - 2017-12-20 03:17:26 --> Security Class Initialized
INFO - 2017-12-20 03:17:26 --> Output Class Initialized
DEBUG - 2017-12-20 03:17:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-20 03:17:26 --> Input Class Initialized
DEBUG - 2017-12-20 03:17:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-20 03:17:26 --> Input Class Initialized
INFO - 2017-12-20 03:17:26 --> Security Class Initialized
INFO - 2017-12-20 03:17:26 --> Language Class Initialized
INFO - 2017-12-20 03:17:26 --> Language Class Initialized
DEBUG - 2017-12-20 03:17:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-20 03:17:26 --> Input Class Initialized
ERROR - 2017-12-20 03:17:26 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2017-12-20 03:17:26 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-20 03:17:26 --> Language Class Initialized
ERROR - 2017-12-20 03:17:26 --> 404 Page Not Found: Instatec_pub/css
