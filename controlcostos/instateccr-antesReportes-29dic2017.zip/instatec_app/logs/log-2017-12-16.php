<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-12-16 05:41:16 --> Config Class Initialized
INFO - 2017-12-16 05:41:16 --> Hooks Class Initialized
DEBUG - 2017-12-16 05:41:16 --> UTF-8 Support Enabled
INFO - 2017-12-16 05:41:16 --> Utf8 Class Initialized
INFO - 2017-12-16 05:41:16 --> URI Class Initialized
INFO - 2017-12-16 05:41:16 --> Router Class Initialized
INFO - 2017-12-16 05:41:16 --> Output Class Initialized
INFO - 2017-12-16 05:41:16 --> Security Class Initialized
DEBUG - 2017-12-16 05:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 05:41:16 --> Input Class Initialized
INFO - 2017-12-16 05:41:16 --> Language Class Initialized
INFO - 2017-12-16 05:41:16 --> Loader Class Initialized
INFO - 2017-12-16 05:41:16 --> Helper loaded: url_helper
INFO - 2017-12-16 05:41:16 --> Helper loaded: form_helper
INFO - 2017-12-16 05:41:16 --> Database Driver Class Initialized
DEBUG - 2017-12-16 05:41:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 05:41:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 05:41:16 --> Form Validation Class Initialized
INFO - 2017-12-16 05:41:16 --> Model Class Initialized
INFO - 2017-12-16 05:41:16 --> Controller Class Initialized
INFO - 2017-12-16 05:41:16 --> Model Class Initialized
INFO - 2017-12-16 05:41:16 --> Model Class Initialized
INFO - 2017-12-16 05:41:16 --> Model Class Initialized
DEBUG - 2017-12-16 05:41:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 05:41:16 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-16 05:41:16 --> Final output sent to browser
DEBUG - 2017-12-16 05:41:16 --> Total execution time: 0.0502
INFO - 2017-12-16 05:47:17 --> Config Class Initialized
INFO - 2017-12-16 05:47:17 --> Hooks Class Initialized
DEBUG - 2017-12-16 05:47:17 --> UTF-8 Support Enabled
INFO - 2017-12-16 05:47:17 --> Utf8 Class Initialized
INFO - 2017-12-16 05:47:17 --> URI Class Initialized
INFO - 2017-12-16 05:47:17 --> Router Class Initialized
INFO - 2017-12-16 05:47:17 --> Output Class Initialized
INFO - 2017-12-16 05:47:17 --> Security Class Initialized
DEBUG - 2017-12-16 05:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 05:47:17 --> Input Class Initialized
INFO - 2017-12-16 05:47:17 --> Language Class Initialized
INFO - 2017-12-16 05:47:17 --> Loader Class Initialized
INFO - 2017-12-16 05:47:17 --> Helper loaded: url_helper
INFO - 2017-12-16 05:47:17 --> Helper loaded: form_helper
INFO - 2017-12-16 05:47:17 --> Database Driver Class Initialized
DEBUG - 2017-12-16 05:47:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 05:47:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 05:47:17 --> Form Validation Class Initialized
INFO - 2017-12-16 05:47:17 --> Model Class Initialized
INFO - 2017-12-16 05:47:17 --> Controller Class Initialized
INFO - 2017-12-16 05:47:17 --> Model Class Initialized
INFO - 2017-12-16 05:47:17 --> Model Class Initialized
INFO - 2017-12-16 05:47:17 --> Model Class Initialized
DEBUG - 2017-12-16 05:47:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 05:47:17 --> Final output sent to browser
DEBUG - 2017-12-16 05:47:17 --> Total execution time: 0.0436
INFO - 2017-12-16 05:47:18 --> Config Class Initialized
INFO - 2017-12-16 05:47:18 --> Hooks Class Initialized
DEBUG - 2017-12-16 05:47:18 --> UTF-8 Support Enabled
INFO - 2017-12-16 05:47:18 --> Utf8 Class Initialized
INFO - 2017-12-16 05:47:18 --> URI Class Initialized
INFO - 2017-12-16 05:47:18 --> Router Class Initialized
INFO - 2017-12-16 05:47:18 --> Output Class Initialized
INFO - 2017-12-16 05:47:18 --> Security Class Initialized
DEBUG - 2017-12-16 05:47:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 05:47:18 --> Input Class Initialized
INFO - 2017-12-16 05:47:18 --> Language Class Initialized
INFO - 2017-12-16 05:47:18 --> Loader Class Initialized
INFO - 2017-12-16 05:47:18 --> Helper loaded: url_helper
INFO - 2017-12-16 05:47:18 --> Helper loaded: form_helper
INFO - 2017-12-16 05:47:18 --> Database Driver Class Initialized
DEBUG - 2017-12-16 05:47:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 05:47:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 05:47:18 --> Form Validation Class Initialized
INFO - 2017-12-16 05:47:18 --> Model Class Initialized
INFO - 2017-12-16 05:47:18 --> Controller Class Initialized
INFO - 2017-12-16 05:47:18 --> Model Class Initialized
INFO - 2017-12-16 05:47:18 --> Model Class Initialized
INFO - 2017-12-16 05:47:18 --> Model Class Initialized
DEBUG - 2017-12-16 05:47:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 05:47:19 --> Config Class Initialized
INFO - 2017-12-16 05:47:19 --> Hooks Class Initialized
DEBUG - 2017-12-16 05:47:19 --> UTF-8 Support Enabled
INFO - 2017-12-16 05:47:19 --> Utf8 Class Initialized
INFO - 2017-12-16 05:47:19 --> URI Class Initialized
INFO - 2017-12-16 05:47:19 --> Router Class Initialized
INFO - 2017-12-16 05:47:19 --> Output Class Initialized
INFO - 2017-12-16 05:47:19 --> Security Class Initialized
DEBUG - 2017-12-16 05:47:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 05:47:19 --> Input Class Initialized
INFO - 2017-12-16 05:47:19 --> Language Class Initialized
INFO - 2017-12-16 05:47:19 --> Loader Class Initialized
INFO - 2017-12-16 05:47:19 --> Helper loaded: url_helper
INFO - 2017-12-16 05:47:19 --> Helper loaded: form_helper
INFO - 2017-12-16 05:47:19 --> Database Driver Class Initialized
DEBUG - 2017-12-16 05:47:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 05:47:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 05:47:19 --> Form Validation Class Initialized
INFO - 2017-12-16 05:47:19 --> Model Class Initialized
INFO - 2017-12-16 05:47:19 --> Controller Class Initialized
INFO - 2017-12-16 05:47:19 --> Model Class Initialized
INFO - 2017-12-16 05:47:19 --> Model Class Initialized
INFO - 2017-12-16 05:47:19 --> Model Class Initialized
DEBUG - 2017-12-16 05:47:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 05:47:19 --> Final output sent to browser
DEBUG - 2017-12-16 05:47:19 --> Total execution time: 0.0441
INFO - 2017-12-16 05:47:19 --> Config Class Initialized
INFO - 2017-12-16 05:47:19 --> Hooks Class Initialized
DEBUG - 2017-12-16 05:47:19 --> UTF-8 Support Enabled
INFO - 2017-12-16 05:47:19 --> Utf8 Class Initialized
INFO - 2017-12-16 05:47:19 --> URI Class Initialized
INFO - 2017-12-16 05:47:19 --> Router Class Initialized
INFO - 2017-12-16 05:47:19 --> Output Class Initialized
INFO - 2017-12-16 05:47:19 --> Security Class Initialized
DEBUG - 2017-12-16 05:47:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 05:47:19 --> Input Class Initialized
INFO - 2017-12-16 05:47:19 --> Language Class Initialized
INFO - 2017-12-16 05:47:19 --> Loader Class Initialized
INFO - 2017-12-16 05:47:19 --> Helper loaded: url_helper
INFO - 2017-12-16 05:47:19 --> Helper loaded: form_helper
INFO - 2017-12-16 05:47:19 --> Database Driver Class Initialized
DEBUG - 2017-12-16 05:47:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 05:47:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 05:47:19 --> Form Validation Class Initialized
INFO - 2017-12-16 05:47:19 --> Model Class Initialized
INFO - 2017-12-16 05:47:19 --> Controller Class Initialized
INFO - 2017-12-16 05:47:19 --> Model Class Initialized
INFO - 2017-12-16 05:47:19 --> Model Class Initialized
INFO - 2017-12-16 05:47:19 --> Model Class Initialized
DEBUG - 2017-12-16 05:47:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 05:47:20 --> Config Class Initialized
INFO - 2017-12-16 05:47:20 --> Hooks Class Initialized
DEBUG - 2017-12-16 05:47:20 --> UTF-8 Support Enabled
INFO - 2017-12-16 05:47:20 --> Utf8 Class Initialized
INFO - 2017-12-16 05:47:20 --> URI Class Initialized
INFO - 2017-12-16 05:47:20 --> Router Class Initialized
INFO - 2017-12-16 05:47:20 --> Output Class Initialized
INFO - 2017-12-16 05:47:20 --> Security Class Initialized
DEBUG - 2017-12-16 05:47:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 05:47:20 --> Input Class Initialized
INFO - 2017-12-16 05:47:20 --> Language Class Initialized
INFO - 2017-12-16 05:47:20 --> Loader Class Initialized
INFO - 2017-12-16 05:47:20 --> Helper loaded: url_helper
INFO - 2017-12-16 05:47:20 --> Helper loaded: form_helper
INFO - 2017-12-16 05:47:20 --> Database Driver Class Initialized
DEBUG - 2017-12-16 05:47:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 05:47:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 05:47:20 --> Form Validation Class Initialized
INFO - 2017-12-16 05:47:20 --> Model Class Initialized
INFO - 2017-12-16 05:47:20 --> Controller Class Initialized
INFO - 2017-12-16 05:47:20 --> Model Class Initialized
INFO - 2017-12-16 05:47:20 --> Model Class Initialized
INFO - 2017-12-16 05:47:20 --> Model Class Initialized
DEBUG - 2017-12-16 05:47:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 05:47:21 --> Config Class Initialized
INFO - 2017-12-16 05:47:21 --> Hooks Class Initialized
DEBUG - 2017-12-16 05:47:21 --> UTF-8 Support Enabled
INFO - 2017-12-16 05:47:21 --> Utf8 Class Initialized
INFO - 2017-12-16 05:47:21 --> URI Class Initialized
INFO - 2017-12-16 05:47:21 --> Router Class Initialized
INFO - 2017-12-16 05:47:21 --> Output Class Initialized
INFO - 2017-12-16 05:47:21 --> Security Class Initialized
DEBUG - 2017-12-16 05:47:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 05:47:21 --> Input Class Initialized
INFO - 2017-12-16 05:47:21 --> Language Class Initialized
INFO - 2017-12-16 05:47:21 --> Loader Class Initialized
INFO - 2017-12-16 05:47:21 --> Helper loaded: url_helper
INFO - 2017-12-16 05:47:21 --> Helper loaded: form_helper
INFO - 2017-12-16 05:47:21 --> Database Driver Class Initialized
DEBUG - 2017-12-16 05:47:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 05:47:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 05:47:21 --> Form Validation Class Initialized
INFO - 2017-12-16 05:47:21 --> Model Class Initialized
INFO - 2017-12-16 05:47:21 --> Controller Class Initialized
INFO - 2017-12-16 05:47:21 --> Model Class Initialized
INFO - 2017-12-16 05:47:21 --> Model Class Initialized
INFO - 2017-12-16 05:47:21 --> Model Class Initialized
DEBUG - 2017-12-16 05:47:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 05:47:57 --> Config Class Initialized
INFO - 2017-12-16 05:47:57 --> Hooks Class Initialized
DEBUG - 2017-12-16 05:47:57 --> UTF-8 Support Enabled
INFO - 2017-12-16 05:47:57 --> Utf8 Class Initialized
INFO - 2017-12-16 05:47:57 --> URI Class Initialized
INFO - 2017-12-16 05:47:57 --> Router Class Initialized
INFO - 2017-12-16 05:47:57 --> Output Class Initialized
INFO - 2017-12-16 05:47:57 --> Security Class Initialized
DEBUG - 2017-12-16 05:47:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 05:47:57 --> Input Class Initialized
INFO - 2017-12-16 05:47:57 --> Language Class Initialized
INFO - 2017-12-16 05:47:57 --> Loader Class Initialized
INFO - 2017-12-16 05:47:57 --> Helper loaded: url_helper
INFO - 2017-12-16 05:47:57 --> Helper loaded: form_helper
INFO - 2017-12-16 05:47:57 --> Database Driver Class Initialized
DEBUG - 2017-12-16 05:47:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 05:47:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 05:47:57 --> Form Validation Class Initialized
INFO - 2017-12-16 05:47:57 --> Model Class Initialized
INFO - 2017-12-16 05:47:57 --> Controller Class Initialized
INFO - 2017-12-16 05:47:57 --> Model Class Initialized
INFO - 2017-12-16 05:47:57 --> Model Class Initialized
INFO - 2017-12-16 05:47:57 --> Model Class Initialized
DEBUG - 2017-12-16 05:47:57 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2017-12-16 05:47:57 --> Severity: Notice --> Undefined index: inserted_id D:\xampp\htdocs\instateccr\instatec_app\controllers\Proyecto.php 61
INFO - 2017-12-16 05:47:57 --> Config Class Initialized
INFO - 2017-12-16 05:47:57 --> Hooks Class Initialized
DEBUG - 2017-12-16 05:47:57 --> UTF-8 Support Enabled
INFO - 2017-12-16 05:47:57 --> Utf8 Class Initialized
INFO - 2017-12-16 05:47:57 --> URI Class Initialized
INFO - 2017-12-16 05:47:57 --> Router Class Initialized
INFO - 2017-12-16 05:47:57 --> Output Class Initialized
INFO - 2017-12-16 05:47:57 --> Security Class Initialized
DEBUG - 2017-12-16 05:47:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 05:47:57 --> Input Class Initialized
INFO - 2017-12-16 05:47:57 --> Language Class Initialized
ERROR - 2017-12-16 05:47:57 --> 404 Page Not Found: Proyectos/editar-proyecto
INFO - 2017-12-16 05:48:55 --> Config Class Initialized
INFO - 2017-12-16 05:48:55 --> Hooks Class Initialized
DEBUG - 2017-12-16 05:48:55 --> UTF-8 Support Enabled
INFO - 2017-12-16 05:48:55 --> Utf8 Class Initialized
INFO - 2017-12-16 05:48:55 --> URI Class Initialized
INFO - 2017-12-16 05:48:55 --> Router Class Initialized
INFO - 2017-12-16 05:48:55 --> Output Class Initialized
INFO - 2017-12-16 05:48:55 --> Security Class Initialized
DEBUG - 2017-12-16 05:48:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 05:48:55 --> Input Class Initialized
INFO - 2017-12-16 05:48:55 --> Language Class Initialized
INFO - 2017-12-16 05:48:55 --> Loader Class Initialized
INFO - 2017-12-16 05:48:55 --> Helper loaded: url_helper
INFO - 2017-12-16 05:48:55 --> Helper loaded: form_helper
INFO - 2017-12-16 05:48:55 --> Database Driver Class Initialized
DEBUG - 2017-12-16 05:48:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 05:48:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 05:48:55 --> Form Validation Class Initialized
INFO - 2017-12-16 05:48:55 --> Model Class Initialized
INFO - 2017-12-16 05:48:55 --> Controller Class Initialized
INFO - 2017-12-16 05:48:55 --> Model Class Initialized
INFO - 2017-12-16 05:48:55 --> Model Class Initialized
INFO - 2017-12-16 05:48:55 --> Model Class Initialized
DEBUG - 2017-12-16 05:48:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 05:48:55 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-16 05:48:55 --> Final output sent to browser
DEBUG - 2017-12-16 05:48:55 --> Total execution time: 0.0474
INFO - 2017-12-16 05:49:01 --> Config Class Initialized
INFO - 2017-12-16 05:49:01 --> Hooks Class Initialized
DEBUG - 2017-12-16 05:49:01 --> UTF-8 Support Enabled
INFO - 2017-12-16 05:49:01 --> Utf8 Class Initialized
INFO - 2017-12-16 05:49:01 --> URI Class Initialized
INFO - 2017-12-16 05:49:01 --> Router Class Initialized
INFO - 2017-12-16 05:49:01 --> Output Class Initialized
INFO - 2017-12-16 05:49:01 --> Security Class Initialized
DEBUG - 2017-12-16 05:49:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 05:49:01 --> Input Class Initialized
INFO - 2017-12-16 05:49:01 --> Language Class Initialized
ERROR - 2017-12-16 05:49:01 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-16 05:49:11 --> Config Class Initialized
INFO - 2017-12-16 05:49:11 --> Hooks Class Initialized
DEBUG - 2017-12-16 05:49:11 --> UTF-8 Support Enabled
INFO - 2017-12-16 05:49:11 --> Utf8 Class Initialized
INFO - 2017-12-16 05:49:11 --> URI Class Initialized
INFO - 2017-12-16 05:49:11 --> Router Class Initialized
INFO - 2017-12-16 05:49:11 --> Output Class Initialized
INFO - 2017-12-16 05:49:11 --> Security Class Initialized
DEBUG - 2017-12-16 05:49:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 05:49:11 --> Input Class Initialized
INFO - 2017-12-16 05:49:11 --> Language Class Initialized
INFO - 2017-12-16 05:49:11 --> Loader Class Initialized
INFO - 2017-12-16 05:49:11 --> Helper loaded: url_helper
INFO - 2017-12-16 05:49:11 --> Helper loaded: form_helper
INFO - 2017-12-16 05:49:11 --> Database Driver Class Initialized
DEBUG - 2017-12-16 05:49:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 05:49:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 05:49:11 --> Form Validation Class Initialized
INFO - 2017-12-16 05:49:11 --> Model Class Initialized
INFO - 2017-12-16 05:49:11 --> Controller Class Initialized
INFO - 2017-12-16 05:49:11 --> Model Class Initialized
INFO - 2017-12-16 05:49:11 --> Model Class Initialized
INFO - 2017-12-16 05:49:11 --> Model Class Initialized
DEBUG - 2017-12-16 05:49:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 05:49:11 --> Final output sent to browser
DEBUG - 2017-12-16 05:49:11 --> Total execution time: 0.0382
INFO - 2017-12-16 05:49:11 --> Config Class Initialized
INFO - 2017-12-16 05:49:11 --> Hooks Class Initialized
DEBUG - 2017-12-16 05:49:11 --> UTF-8 Support Enabled
INFO - 2017-12-16 05:49:11 --> Utf8 Class Initialized
INFO - 2017-12-16 05:49:11 --> URI Class Initialized
INFO - 2017-12-16 05:49:11 --> Router Class Initialized
INFO - 2017-12-16 05:49:11 --> Output Class Initialized
INFO - 2017-12-16 05:49:11 --> Security Class Initialized
DEBUG - 2017-12-16 05:49:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 05:49:11 --> Input Class Initialized
INFO - 2017-12-16 05:49:11 --> Language Class Initialized
INFO - 2017-12-16 05:49:11 --> Loader Class Initialized
INFO - 2017-12-16 05:49:11 --> Helper loaded: url_helper
INFO - 2017-12-16 05:49:11 --> Helper loaded: form_helper
INFO - 2017-12-16 05:49:11 --> Database Driver Class Initialized
DEBUG - 2017-12-16 05:49:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 05:49:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 05:49:11 --> Form Validation Class Initialized
INFO - 2017-12-16 05:49:11 --> Model Class Initialized
INFO - 2017-12-16 05:49:11 --> Controller Class Initialized
INFO - 2017-12-16 05:49:11 --> Model Class Initialized
INFO - 2017-12-16 05:49:11 --> Model Class Initialized
INFO - 2017-12-16 05:49:11 --> Model Class Initialized
DEBUG - 2017-12-16 05:49:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 05:49:13 --> Config Class Initialized
INFO - 2017-12-16 05:49:13 --> Hooks Class Initialized
DEBUG - 2017-12-16 05:49:13 --> UTF-8 Support Enabled
INFO - 2017-12-16 05:49:13 --> Utf8 Class Initialized
INFO - 2017-12-16 05:49:13 --> URI Class Initialized
INFO - 2017-12-16 05:49:13 --> Router Class Initialized
INFO - 2017-12-16 05:49:13 --> Output Class Initialized
INFO - 2017-12-16 05:49:13 --> Security Class Initialized
DEBUG - 2017-12-16 05:49:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 05:49:13 --> Input Class Initialized
INFO - 2017-12-16 05:49:13 --> Language Class Initialized
INFO - 2017-12-16 05:49:13 --> Loader Class Initialized
INFO - 2017-12-16 05:49:13 --> Helper loaded: url_helper
INFO - 2017-12-16 05:49:13 --> Helper loaded: form_helper
INFO - 2017-12-16 05:49:13 --> Database Driver Class Initialized
DEBUG - 2017-12-16 05:49:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 05:49:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 05:49:13 --> Form Validation Class Initialized
INFO - 2017-12-16 05:49:13 --> Model Class Initialized
INFO - 2017-12-16 05:49:13 --> Controller Class Initialized
INFO - 2017-12-16 05:49:13 --> Model Class Initialized
INFO - 2017-12-16 05:49:13 --> Model Class Initialized
INFO - 2017-12-16 05:49:13 --> Model Class Initialized
DEBUG - 2017-12-16 05:49:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 05:49:13 --> Final output sent to browser
DEBUG - 2017-12-16 05:49:13 --> Total execution time: 0.0444
INFO - 2017-12-16 05:49:13 --> Config Class Initialized
INFO - 2017-12-16 05:49:13 --> Hooks Class Initialized
DEBUG - 2017-12-16 05:49:13 --> UTF-8 Support Enabled
INFO - 2017-12-16 05:49:13 --> Utf8 Class Initialized
INFO - 2017-12-16 05:49:13 --> URI Class Initialized
INFO - 2017-12-16 05:49:13 --> Router Class Initialized
INFO - 2017-12-16 05:49:13 --> Output Class Initialized
INFO - 2017-12-16 05:49:13 --> Security Class Initialized
DEBUG - 2017-12-16 05:49:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 05:49:13 --> Input Class Initialized
INFO - 2017-12-16 05:49:13 --> Language Class Initialized
INFO - 2017-12-16 05:49:13 --> Loader Class Initialized
INFO - 2017-12-16 05:49:13 --> Helper loaded: url_helper
INFO - 2017-12-16 05:49:13 --> Helper loaded: form_helper
INFO - 2017-12-16 05:49:13 --> Database Driver Class Initialized
DEBUG - 2017-12-16 05:49:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 05:49:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 05:49:13 --> Form Validation Class Initialized
INFO - 2017-12-16 05:49:13 --> Model Class Initialized
INFO - 2017-12-16 05:49:13 --> Controller Class Initialized
INFO - 2017-12-16 05:49:13 --> Model Class Initialized
INFO - 2017-12-16 05:49:13 --> Model Class Initialized
INFO - 2017-12-16 05:49:13 --> Model Class Initialized
DEBUG - 2017-12-16 05:49:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 05:50:10 --> Config Class Initialized
INFO - 2017-12-16 05:50:10 --> Hooks Class Initialized
DEBUG - 2017-12-16 05:50:10 --> UTF-8 Support Enabled
INFO - 2017-12-16 05:50:10 --> Utf8 Class Initialized
INFO - 2017-12-16 05:50:10 --> URI Class Initialized
INFO - 2017-12-16 05:50:10 --> Router Class Initialized
INFO - 2017-12-16 05:50:10 --> Output Class Initialized
INFO - 2017-12-16 05:50:10 --> Security Class Initialized
DEBUG - 2017-12-16 05:50:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 05:50:10 --> Input Class Initialized
INFO - 2017-12-16 05:50:10 --> Language Class Initialized
INFO - 2017-12-16 05:50:10 --> Loader Class Initialized
INFO - 2017-12-16 05:50:10 --> Helper loaded: url_helper
INFO - 2017-12-16 05:50:10 --> Helper loaded: form_helper
INFO - 2017-12-16 05:50:10 --> Database Driver Class Initialized
DEBUG - 2017-12-16 05:50:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 05:50:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 05:50:10 --> Form Validation Class Initialized
INFO - 2017-12-16 05:50:10 --> Model Class Initialized
INFO - 2017-12-16 05:50:10 --> Controller Class Initialized
INFO - 2017-12-16 05:50:10 --> Model Class Initialized
INFO - 2017-12-16 05:50:10 --> Model Class Initialized
INFO - 2017-12-16 05:50:10 --> Model Class Initialized
DEBUG - 2017-12-16 05:50:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 05:50:11 --> Config Class Initialized
INFO - 2017-12-16 05:50:11 --> Hooks Class Initialized
DEBUG - 2017-12-16 05:50:11 --> UTF-8 Support Enabled
INFO - 2017-12-16 05:50:11 --> Utf8 Class Initialized
INFO - 2017-12-16 05:50:11 --> URI Class Initialized
INFO - 2017-12-16 05:50:11 --> Router Class Initialized
INFO - 2017-12-16 05:50:11 --> Output Class Initialized
INFO - 2017-12-16 05:50:11 --> Security Class Initialized
DEBUG - 2017-12-16 05:50:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 05:50:11 --> Input Class Initialized
INFO - 2017-12-16 05:50:11 --> Language Class Initialized
ERROR - 2017-12-16 05:50:11 --> 404 Page Not Found: Proyecto/editarProyecto
INFO - 2017-12-16 05:50:59 --> Config Class Initialized
INFO - 2017-12-16 05:50:59 --> Hooks Class Initialized
DEBUG - 2017-12-16 05:50:59 --> UTF-8 Support Enabled
INFO - 2017-12-16 05:50:59 --> Utf8 Class Initialized
INFO - 2017-12-16 05:50:59 --> URI Class Initialized
INFO - 2017-12-16 05:50:59 --> Router Class Initialized
INFO - 2017-12-16 05:50:59 --> Output Class Initialized
INFO - 2017-12-16 05:50:59 --> Security Class Initialized
DEBUG - 2017-12-16 05:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 05:50:59 --> Input Class Initialized
INFO - 2017-12-16 05:50:59 --> Language Class Initialized
INFO - 2017-12-16 05:50:59 --> Loader Class Initialized
INFO - 2017-12-16 05:50:59 --> Helper loaded: url_helper
INFO - 2017-12-16 05:50:59 --> Helper loaded: form_helper
INFO - 2017-12-16 05:50:59 --> Database Driver Class Initialized
DEBUG - 2017-12-16 05:50:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 05:50:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 05:50:59 --> Form Validation Class Initialized
INFO - 2017-12-16 05:50:59 --> Model Class Initialized
INFO - 2017-12-16 05:50:59 --> Controller Class Initialized
INFO - 2017-12-16 05:50:59 --> Model Class Initialized
INFO - 2017-12-16 05:50:59 --> Model Class Initialized
INFO - 2017-12-16 05:50:59 --> Model Class Initialized
DEBUG - 2017-12-16 05:50:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 05:50:59 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-16 05:50:59 --> Final output sent to browser
DEBUG - 2017-12-16 05:50:59 --> Total execution time: 0.0386
INFO - 2017-12-16 06:33:17 --> Config Class Initialized
INFO - 2017-12-16 06:33:17 --> Hooks Class Initialized
DEBUG - 2017-12-16 06:33:17 --> UTF-8 Support Enabled
INFO - 2017-12-16 06:33:17 --> Utf8 Class Initialized
INFO - 2017-12-16 06:33:17 --> URI Class Initialized
INFO - 2017-12-16 06:33:17 --> Router Class Initialized
INFO - 2017-12-16 06:33:17 --> Output Class Initialized
INFO - 2017-12-16 06:33:17 --> Security Class Initialized
DEBUG - 2017-12-16 06:33:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 06:33:17 --> Input Class Initialized
INFO - 2017-12-16 06:33:17 --> Language Class Initialized
INFO - 2017-12-16 06:33:17 --> Loader Class Initialized
INFO - 2017-12-16 06:33:17 --> Helper loaded: url_helper
INFO - 2017-12-16 06:33:17 --> Helper loaded: form_helper
INFO - 2017-12-16 06:33:17 --> Database Driver Class Initialized
DEBUG - 2017-12-16 06:33:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 06:33:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 06:33:17 --> Form Validation Class Initialized
INFO - 2017-12-16 06:33:17 --> Model Class Initialized
INFO - 2017-12-16 06:33:17 --> Controller Class Initialized
INFO - 2017-12-16 06:33:17 --> Model Class Initialized
INFO - 2017-12-16 06:33:17 --> Model Class Initialized
INFO - 2017-12-16 06:33:17 --> Model Class Initialized
DEBUG - 2017-12-16 06:33:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 06:33:17 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-16 06:33:17 --> Final output sent to browser
DEBUG - 2017-12-16 06:33:17 --> Total execution time: 0.0399
INFO - 2017-12-16 06:46:32 --> Config Class Initialized
INFO - 2017-12-16 06:46:32 --> Hooks Class Initialized
DEBUG - 2017-12-16 06:46:32 --> UTF-8 Support Enabled
INFO - 2017-12-16 06:46:32 --> Utf8 Class Initialized
INFO - 2017-12-16 06:46:32 --> URI Class Initialized
INFO - 2017-12-16 06:46:32 --> Router Class Initialized
INFO - 2017-12-16 06:46:32 --> Output Class Initialized
INFO - 2017-12-16 06:46:32 --> Security Class Initialized
DEBUG - 2017-12-16 06:46:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 06:46:32 --> Input Class Initialized
INFO - 2017-12-16 06:46:32 --> Language Class Initialized
INFO - 2017-12-16 06:46:32 --> Loader Class Initialized
INFO - 2017-12-16 06:46:32 --> Helper loaded: url_helper
INFO - 2017-12-16 06:46:32 --> Helper loaded: form_helper
INFO - 2017-12-16 06:46:32 --> Database Driver Class Initialized
DEBUG - 2017-12-16 06:46:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 06:46:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 06:46:32 --> Form Validation Class Initialized
INFO - 2017-12-16 06:46:32 --> Model Class Initialized
INFO - 2017-12-16 06:46:32 --> Controller Class Initialized
INFO - 2017-12-16 06:46:32 --> Model Class Initialized
INFO - 2017-12-16 06:46:32 --> Model Class Initialized
INFO - 2017-12-16 06:46:32 --> Model Class Initialized
DEBUG - 2017-12-16 06:46:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 06:46:32 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-16 06:46:32 --> Final output sent to browser
DEBUG - 2017-12-16 06:46:32 --> Total execution time: 0.0569
INFO - 2017-12-16 06:50:06 --> Config Class Initialized
INFO - 2017-12-16 06:50:06 --> Hooks Class Initialized
DEBUG - 2017-12-16 06:50:06 --> UTF-8 Support Enabled
INFO - 2017-12-16 06:50:06 --> Utf8 Class Initialized
INFO - 2017-12-16 06:50:06 --> URI Class Initialized
INFO - 2017-12-16 06:50:06 --> Router Class Initialized
INFO - 2017-12-16 06:50:06 --> Output Class Initialized
INFO - 2017-12-16 06:50:06 --> Security Class Initialized
DEBUG - 2017-12-16 06:50:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 06:50:06 --> Input Class Initialized
INFO - 2017-12-16 06:50:06 --> Language Class Initialized
INFO - 2017-12-16 06:50:06 --> Loader Class Initialized
INFO - 2017-12-16 06:50:06 --> Helper loaded: url_helper
INFO - 2017-12-16 06:50:06 --> Helper loaded: form_helper
INFO - 2017-12-16 06:50:06 --> Database Driver Class Initialized
DEBUG - 2017-12-16 06:50:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 06:50:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 06:50:06 --> Form Validation Class Initialized
INFO - 2017-12-16 06:50:06 --> Model Class Initialized
INFO - 2017-12-16 06:50:06 --> Controller Class Initialized
INFO - 2017-12-16 06:50:06 --> Model Class Initialized
INFO - 2017-12-16 06:50:06 --> Model Class Initialized
INFO - 2017-12-16 06:50:06 --> Model Class Initialized
DEBUG - 2017-12-16 06:50:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 06:50:06 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-16 06:50:06 --> Final output sent to browser
DEBUG - 2017-12-16 06:50:06 --> Total execution time: 0.0591
INFO - 2017-12-16 06:50:08 --> Config Class Initialized
INFO - 2017-12-16 06:50:08 --> Hooks Class Initialized
DEBUG - 2017-12-16 06:50:08 --> UTF-8 Support Enabled
INFO - 2017-12-16 06:50:08 --> Utf8 Class Initialized
INFO - 2017-12-16 06:50:08 --> URI Class Initialized
INFO - 2017-12-16 06:50:08 --> Router Class Initialized
INFO - 2017-12-16 06:50:08 --> Output Class Initialized
INFO - 2017-12-16 06:50:08 --> Security Class Initialized
DEBUG - 2017-12-16 06:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 06:50:08 --> Input Class Initialized
INFO - 2017-12-16 06:50:08 --> Language Class Initialized
ERROR - 2017-12-16 06:50:08 --> 404 Page Not Found: Faviconico/index
INFO - 2017-12-16 06:51:50 --> Config Class Initialized
INFO - 2017-12-16 06:51:50 --> Hooks Class Initialized
DEBUG - 2017-12-16 06:51:50 --> UTF-8 Support Enabled
INFO - 2017-12-16 06:51:50 --> Utf8 Class Initialized
INFO - 2017-12-16 06:51:50 --> URI Class Initialized
INFO - 2017-12-16 06:51:50 --> Router Class Initialized
INFO - 2017-12-16 06:51:50 --> Output Class Initialized
INFO - 2017-12-16 06:51:50 --> Security Class Initialized
DEBUG - 2017-12-16 06:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 06:51:50 --> Input Class Initialized
INFO - 2017-12-16 06:51:50 --> Language Class Initialized
INFO - 2017-12-16 06:51:50 --> Loader Class Initialized
INFO - 2017-12-16 06:51:50 --> Helper loaded: url_helper
INFO - 2017-12-16 06:51:50 --> Helper loaded: form_helper
INFO - 2017-12-16 06:51:50 --> Database Driver Class Initialized
DEBUG - 2017-12-16 06:51:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 06:51:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 06:51:50 --> Form Validation Class Initialized
INFO - 2017-12-16 06:51:50 --> Model Class Initialized
INFO - 2017-12-16 06:51:50 --> Controller Class Initialized
INFO - 2017-12-16 06:51:50 --> Model Class Initialized
INFO - 2017-12-16 06:51:50 --> Model Class Initialized
INFO - 2017-12-16 06:51:50 --> Model Class Initialized
DEBUG - 2017-12-16 06:51:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 06:51:50 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-16 06:51:50 --> Final output sent to browser
DEBUG - 2017-12-16 06:51:50 --> Total execution time: 0.0648
INFO - 2017-12-16 06:51:52 --> Config Class Initialized
INFO - 2017-12-16 06:51:52 --> Hooks Class Initialized
DEBUG - 2017-12-16 06:51:52 --> UTF-8 Support Enabled
INFO - 2017-12-16 06:51:52 --> Utf8 Class Initialized
INFO - 2017-12-16 06:51:52 --> URI Class Initialized
INFO - 2017-12-16 06:51:52 --> Router Class Initialized
INFO - 2017-12-16 06:51:52 --> Output Class Initialized
INFO - 2017-12-16 06:51:52 --> Security Class Initialized
DEBUG - 2017-12-16 06:51:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 06:51:52 --> Input Class Initialized
INFO - 2017-12-16 06:51:52 --> Language Class Initialized
ERROR - 2017-12-16 06:51:52 --> 404 Page Not Found: Faviconico/index
INFO - 2017-12-16 07:08:32 --> Config Class Initialized
INFO - 2017-12-16 07:08:32 --> Hooks Class Initialized
DEBUG - 2017-12-16 07:08:32 --> UTF-8 Support Enabled
INFO - 2017-12-16 07:08:32 --> Utf8 Class Initialized
INFO - 2017-12-16 07:08:32 --> URI Class Initialized
INFO - 2017-12-16 07:08:32 --> Router Class Initialized
INFO - 2017-12-16 07:08:32 --> Output Class Initialized
INFO - 2017-12-16 07:08:32 --> Security Class Initialized
DEBUG - 2017-12-16 07:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 07:08:32 --> Input Class Initialized
INFO - 2017-12-16 07:08:32 --> Language Class Initialized
INFO - 2017-12-16 07:08:32 --> Loader Class Initialized
INFO - 2017-12-16 07:08:32 --> Helper loaded: url_helper
INFO - 2017-12-16 07:08:32 --> Helper loaded: form_helper
INFO - 2017-12-16 07:08:32 --> Database Driver Class Initialized
DEBUG - 2017-12-16 07:08:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 07:08:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 07:08:32 --> Form Validation Class Initialized
INFO - 2017-12-16 07:08:32 --> Model Class Initialized
INFO - 2017-12-16 07:08:32 --> Controller Class Initialized
INFO - 2017-12-16 07:08:32 --> Model Class Initialized
INFO - 2017-12-16 07:08:32 --> Model Class Initialized
INFO - 2017-12-16 07:08:32 --> Model Class Initialized
DEBUG - 2017-12-16 07:08:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 07:08:32 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-16 07:08:32 --> Final output sent to browser
DEBUG - 2017-12-16 07:08:32 --> Total execution time: 0.0722
INFO - 2017-12-16 07:08:33 --> Config Class Initialized
INFO - 2017-12-16 07:08:33 --> Hooks Class Initialized
DEBUG - 2017-12-16 07:08:33 --> UTF-8 Support Enabled
INFO - 2017-12-16 07:08:33 --> Utf8 Class Initialized
INFO - 2017-12-16 07:08:33 --> URI Class Initialized
INFO - 2017-12-16 07:08:33 --> Router Class Initialized
INFO - 2017-12-16 07:08:33 --> Output Class Initialized
INFO - 2017-12-16 07:08:33 --> Security Class Initialized
DEBUG - 2017-12-16 07:08:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 07:08:33 --> Input Class Initialized
INFO - 2017-12-16 07:08:33 --> Language Class Initialized
ERROR - 2017-12-16 07:08:33 --> 404 Page Not Found: Faviconico/index
INFO - 2017-12-16 07:08:59 --> Config Class Initialized
INFO - 2017-12-16 07:08:59 --> Hooks Class Initialized
DEBUG - 2017-12-16 07:08:59 --> UTF-8 Support Enabled
INFO - 2017-12-16 07:08:59 --> Utf8 Class Initialized
INFO - 2017-12-16 07:08:59 --> URI Class Initialized
INFO - 2017-12-16 07:08:59 --> Router Class Initialized
INFO - 2017-12-16 07:08:59 --> Output Class Initialized
INFO - 2017-12-16 07:08:59 --> Security Class Initialized
DEBUG - 2017-12-16 07:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 07:08:59 --> Input Class Initialized
INFO - 2017-12-16 07:08:59 --> Language Class Initialized
INFO - 2017-12-16 07:08:59 --> Loader Class Initialized
INFO - 2017-12-16 07:08:59 --> Helper loaded: url_helper
INFO - 2017-12-16 07:08:59 --> Helper loaded: form_helper
INFO - 2017-12-16 07:08:59 --> Database Driver Class Initialized
DEBUG - 2017-12-16 07:08:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 07:08:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 07:08:59 --> Form Validation Class Initialized
INFO - 2017-12-16 07:08:59 --> Model Class Initialized
INFO - 2017-12-16 07:08:59 --> Controller Class Initialized
INFO - 2017-12-16 07:08:59 --> Model Class Initialized
INFO - 2017-12-16 07:08:59 --> Model Class Initialized
INFO - 2017-12-16 07:08:59 --> Model Class Initialized
DEBUG - 2017-12-16 07:08:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 07:08:59 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-16 07:08:59 --> Final output sent to browser
DEBUG - 2017-12-16 07:08:59 --> Total execution time: 0.0689
INFO - 2017-12-16 07:09:00 --> Config Class Initialized
INFO - 2017-12-16 07:09:00 --> Hooks Class Initialized
DEBUG - 2017-12-16 07:09:00 --> UTF-8 Support Enabled
INFO - 2017-12-16 07:09:00 --> Utf8 Class Initialized
INFO - 2017-12-16 07:09:00 --> URI Class Initialized
INFO - 2017-12-16 07:09:00 --> Router Class Initialized
INFO - 2017-12-16 07:09:00 --> Output Class Initialized
INFO - 2017-12-16 07:09:00 --> Security Class Initialized
DEBUG - 2017-12-16 07:09:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 07:09:00 --> Input Class Initialized
INFO - 2017-12-16 07:09:00 --> Language Class Initialized
ERROR - 2017-12-16 07:09:00 --> 404 Page Not Found: Faviconico/index
INFO - 2017-12-16 07:09:45 --> Config Class Initialized
INFO - 2017-12-16 07:09:45 --> Hooks Class Initialized
DEBUG - 2017-12-16 07:09:45 --> UTF-8 Support Enabled
INFO - 2017-12-16 07:09:45 --> Utf8 Class Initialized
INFO - 2017-12-16 07:09:45 --> URI Class Initialized
INFO - 2017-12-16 07:09:45 --> Router Class Initialized
INFO - 2017-12-16 07:09:45 --> Output Class Initialized
INFO - 2017-12-16 07:09:45 --> Security Class Initialized
DEBUG - 2017-12-16 07:09:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 07:09:45 --> Input Class Initialized
INFO - 2017-12-16 07:09:45 --> Language Class Initialized
INFO - 2017-12-16 07:09:45 --> Loader Class Initialized
INFO - 2017-12-16 07:09:45 --> Helper loaded: url_helper
INFO - 2017-12-16 07:09:45 --> Helper loaded: form_helper
INFO - 2017-12-16 07:09:45 --> Database Driver Class Initialized
DEBUG - 2017-12-16 07:09:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 07:09:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 07:09:45 --> Form Validation Class Initialized
INFO - 2017-12-16 07:09:45 --> Model Class Initialized
INFO - 2017-12-16 07:09:45 --> Controller Class Initialized
INFO - 2017-12-16 07:09:45 --> Model Class Initialized
INFO - 2017-12-16 07:09:45 --> Model Class Initialized
INFO - 2017-12-16 07:09:45 --> Model Class Initialized
DEBUG - 2017-12-16 07:09:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 07:09:45 --> Final output sent to browser
DEBUG - 2017-12-16 07:09:45 --> Total execution time: 0.0497
INFO - 2017-12-16 07:09:46 --> Config Class Initialized
INFO - 2017-12-16 07:09:46 --> Hooks Class Initialized
DEBUG - 2017-12-16 07:09:46 --> UTF-8 Support Enabled
INFO - 2017-12-16 07:09:46 --> Utf8 Class Initialized
INFO - 2017-12-16 07:09:46 --> URI Class Initialized
INFO - 2017-12-16 07:09:46 --> Router Class Initialized
INFO - 2017-12-16 07:09:46 --> Output Class Initialized
INFO - 2017-12-16 07:09:46 --> Security Class Initialized
DEBUG - 2017-12-16 07:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 07:09:46 --> Input Class Initialized
INFO - 2017-12-16 07:09:46 --> Language Class Initialized
INFO - 2017-12-16 07:09:46 --> Loader Class Initialized
INFO - 2017-12-16 07:09:46 --> Helper loaded: url_helper
INFO - 2017-12-16 07:09:46 --> Helper loaded: form_helper
INFO - 2017-12-16 07:09:46 --> Database Driver Class Initialized
DEBUG - 2017-12-16 07:09:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 07:09:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 07:09:46 --> Form Validation Class Initialized
INFO - 2017-12-16 07:09:46 --> Model Class Initialized
INFO - 2017-12-16 07:09:46 --> Controller Class Initialized
INFO - 2017-12-16 07:09:46 --> Model Class Initialized
INFO - 2017-12-16 07:09:46 --> Model Class Initialized
INFO - 2017-12-16 07:09:46 --> Model Class Initialized
DEBUG - 2017-12-16 07:09:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 07:09:46 --> Final output sent to browser
DEBUG - 2017-12-16 07:09:46 --> Total execution time: 0.0537
INFO - 2017-12-16 07:10:13 --> Config Class Initialized
INFO - 2017-12-16 07:10:13 --> Hooks Class Initialized
DEBUG - 2017-12-16 07:10:13 --> UTF-8 Support Enabled
INFO - 2017-12-16 07:10:13 --> Utf8 Class Initialized
INFO - 2017-12-16 07:10:13 --> URI Class Initialized
INFO - 2017-12-16 07:10:13 --> Router Class Initialized
INFO - 2017-12-16 07:10:13 --> Output Class Initialized
INFO - 2017-12-16 07:10:13 --> Security Class Initialized
DEBUG - 2017-12-16 07:10:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 07:10:13 --> Input Class Initialized
INFO - 2017-12-16 07:10:13 --> Language Class Initialized
INFO - 2017-12-16 07:10:13 --> Loader Class Initialized
INFO - 2017-12-16 07:10:13 --> Helper loaded: url_helper
INFO - 2017-12-16 07:10:13 --> Helper loaded: form_helper
INFO - 2017-12-16 07:10:13 --> Database Driver Class Initialized
DEBUG - 2017-12-16 07:10:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 07:10:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 07:10:13 --> Form Validation Class Initialized
INFO - 2017-12-16 07:10:13 --> Model Class Initialized
INFO - 2017-12-16 07:10:13 --> Controller Class Initialized
INFO - 2017-12-16 07:10:13 --> Model Class Initialized
INFO - 2017-12-16 07:10:13 --> Model Class Initialized
INFO - 2017-12-16 07:10:13 --> Model Class Initialized
DEBUG - 2017-12-16 07:10:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 07:10:13 --> Final output sent to browser
DEBUG - 2017-12-16 07:10:13 --> Total execution time: 0.0397
INFO - 2017-12-16 07:10:15 --> Config Class Initialized
INFO - 2017-12-16 07:10:15 --> Hooks Class Initialized
DEBUG - 2017-12-16 07:10:15 --> UTF-8 Support Enabled
INFO - 2017-12-16 07:10:15 --> Utf8 Class Initialized
INFO - 2017-12-16 07:10:15 --> URI Class Initialized
INFO - 2017-12-16 07:10:15 --> Router Class Initialized
INFO - 2017-12-16 07:10:15 --> Output Class Initialized
INFO - 2017-12-16 07:10:15 --> Security Class Initialized
DEBUG - 2017-12-16 07:10:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 07:10:15 --> Input Class Initialized
INFO - 2017-12-16 07:10:15 --> Language Class Initialized
INFO - 2017-12-16 07:10:15 --> Loader Class Initialized
INFO - 2017-12-16 07:10:15 --> Helper loaded: url_helper
INFO - 2017-12-16 07:10:15 --> Helper loaded: form_helper
INFO - 2017-12-16 07:10:15 --> Database Driver Class Initialized
DEBUG - 2017-12-16 07:10:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 07:10:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 07:10:15 --> Form Validation Class Initialized
INFO - 2017-12-16 07:10:15 --> Model Class Initialized
INFO - 2017-12-16 07:10:15 --> Controller Class Initialized
INFO - 2017-12-16 07:10:15 --> Model Class Initialized
INFO - 2017-12-16 07:10:15 --> Model Class Initialized
INFO - 2017-12-16 07:10:15 --> Model Class Initialized
DEBUG - 2017-12-16 07:10:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 07:10:15 --> Final output sent to browser
DEBUG - 2017-12-16 07:10:15 --> Total execution time: 0.0527
INFO - 2017-12-16 07:15:04 --> Config Class Initialized
INFO - 2017-12-16 07:15:04 --> Hooks Class Initialized
DEBUG - 2017-12-16 07:15:04 --> UTF-8 Support Enabled
INFO - 2017-12-16 07:15:04 --> Utf8 Class Initialized
INFO - 2017-12-16 07:15:04 --> URI Class Initialized
INFO - 2017-12-16 07:15:04 --> Router Class Initialized
INFO - 2017-12-16 07:15:04 --> Output Class Initialized
INFO - 2017-12-16 07:15:04 --> Security Class Initialized
DEBUG - 2017-12-16 07:15:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 07:15:04 --> Input Class Initialized
INFO - 2017-12-16 07:15:04 --> Language Class Initialized
INFO - 2017-12-16 07:15:04 --> Loader Class Initialized
INFO - 2017-12-16 07:15:04 --> Helper loaded: url_helper
INFO - 2017-12-16 07:15:04 --> Helper loaded: form_helper
INFO - 2017-12-16 07:15:04 --> Database Driver Class Initialized
DEBUG - 2017-12-16 07:15:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 07:15:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 07:15:04 --> Form Validation Class Initialized
INFO - 2017-12-16 07:15:04 --> Model Class Initialized
INFO - 2017-12-16 07:15:04 --> Controller Class Initialized
INFO - 2017-12-16 07:15:04 --> Model Class Initialized
INFO - 2017-12-16 07:15:04 --> Model Class Initialized
INFO - 2017-12-16 07:15:04 --> Model Class Initialized
DEBUG - 2017-12-16 07:15:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 07:15:04 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-16 07:15:04 --> Final output sent to browser
DEBUG - 2017-12-16 07:15:04 --> Total execution time: 0.0805
INFO - 2017-12-16 07:15:05 --> Config Class Initialized
INFO - 2017-12-16 07:15:05 --> Hooks Class Initialized
DEBUG - 2017-12-16 07:15:05 --> UTF-8 Support Enabled
INFO - 2017-12-16 07:15:05 --> Utf8 Class Initialized
INFO - 2017-12-16 07:15:05 --> URI Class Initialized
INFO - 2017-12-16 07:15:05 --> Router Class Initialized
INFO - 2017-12-16 07:15:05 --> Output Class Initialized
INFO - 2017-12-16 07:15:05 --> Security Class Initialized
DEBUG - 2017-12-16 07:15:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 07:15:05 --> Input Class Initialized
INFO - 2017-12-16 07:15:05 --> Language Class Initialized
ERROR - 2017-12-16 07:15:05 --> 404 Page Not Found: Faviconico/index
INFO - 2017-12-16 07:15:10 --> Config Class Initialized
INFO - 2017-12-16 07:15:10 --> Hooks Class Initialized
DEBUG - 2017-12-16 07:15:10 --> UTF-8 Support Enabled
INFO - 2017-12-16 07:15:10 --> Utf8 Class Initialized
INFO - 2017-12-16 07:15:10 --> URI Class Initialized
INFO - 2017-12-16 07:15:10 --> Router Class Initialized
INFO - 2017-12-16 07:15:10 --> Output Class Initialized
INFO - 2017-12-16 07:15:10 --> Security Class Initialized
DEBUG - 2017-12-16 07:15:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 07:15:10 --> Input Class Initialized
INFO - 2017-12-16 07:15:10 --> Language Class Initialized
INFO - 2017-12-16 07:15:10 --> Loader Class Initialized
INFO - 2017-12-16 07:15:10 --> Helper loaded: url_helper
INFO - 2017-12-16 07:15:10 --> Helper loaded: form_helper
INFO - 2017-12-16 07:15:10 --> Database Driver Class Initialized
DEBUG - 2017-12-16 07:15:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 07:15:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 07:15:10 --> Form Validation Class Initialized
INFO - 2017-12-16 07:15:10 --> Model Class Initialized
INFO - 2017-12-16 07:15:10 --> Controller Class Initialized
INFO - 2017-12-16 07:15:10 --> Model Class Initialized
INFO - 2017-12-16 07:15:10 --> Model Class Initialized
INFO - 2017-12-16 07:15:10 --> Model Class Initialized
DEBUG - 2017-12-16 07:15:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 07:15:10 --> Final output sent to browser
DEBUG - 2017-12-16 07:15:10 --> Total execution time: 0.0530
INFO - 2017-12-16 07:15:10 --> Config Class Initialized
INFO - 2017-12-16 07:15:10 --> Hooks Class Initialized
DEBUG - 2017-12-16 07:15:10 --> UTF-8 Support Enabled
INFO - 2017-12-16 07:15:10 --> Utf8 Class Initialized
INFO - 2017-12-16 07:15:10 --> URI Class Initialized
INFO - 2017-12-16 07:15:10 --> Router Class Initialized
INFO - 2017-12-16 07:15:10 --> Output Class Initialized
INFO - 2017-12-16 07:15:10 --> Security Class Initialized
DEBUG - 2017-12-16 07:15:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 07:15:10 --> Input Class Initialized
INFO - 2017-12-16 07:15:10 --> Language Class Initialized
INFO - 2017-12-16 07:15:10 --> Loader Class Initialized
INFO - 2017-12-16 07:15:10 --> Helper loaded: url_helper
INFO - 2017-12-16 07:15:10 --> Helper loaded: form_helper
INFO - 2017-12-16 07:15:10 --> Database Driver Class Initialized
DEBUG - 2017-12-16 07:15:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 07:15:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 07:15:10 --> Form Validation Class Initialized
INFO - 2017-12-16 07:15:10 --> Model Class Initialized
INFO - 2017-12-16 07:15:10 --> Controller Class Initialized
INFO - 2017-12-16 07:15:10 --> Model Class Initialized
INFO - 2017-12-16 07:15:10 --> Model Class Initialized
INFO - 2017-12-16 07:15:10 --> Model Class Initialized
DEBUG - 2017-12-16 07:15:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 07:15:10 --> Final output sent to browser
DEBUG - 2017-12-16 07:15:10 --> Total execution time: 0.0551
INFO - 2017-12-16 07:17:13 --> Config Class Initialized
INFO - 2017-12-16 07:17:13 --> Hooks Class Initialized
DEBUG - 2017-12-16 07:17:13 --> UTF-8 Support Enabled
INFO - 2017-12-16 07:17:13 --> Utf8 Class Initialized
INFO - 2017-12-16 07:17:13 --> URI Class Initialized
INFO - 2017-12-16 07:17:13 --> Router Class Initialized
INFO - 2017-12-16 07:17:13 --> Output Class Initialized
INFO - 2017-12-16 07:17:13 --> Security Class Initialized
DEBUG - 2017-12-16 07:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 07:17:13 --> Input Class Initialized
INFO - 2017-12-16 07:17:13 --> Language Class Initialized
INFO - 2017-12-16 07:17:13 --> Loader Class Initialized
INFO - 2017-12-16 07:17:13 --> Helper loaded: url_helper
INFO - 2017-12-16 07:17:13 --> Helper loaded: form_helper
INFO - 2017-12-16 07:17:13 --> Database Driver Class Initialized
DEBUG - 2017-12-16 07:17:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 07:17:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 07:17:13 --> Form Validation Class Initialized
INFO - 2017-12-16 07:17:13 --> Model Class Initialized
INFO - 2017-12-16 07:17:13 --> Controller Class Initialized
INFO - 2017-12-16 07:17:13 --> Model Class Initialized
INFO - 2017-12-16 07:17:13 --> Model Class Initialized
INFO - 2017-12-16 07:17:13 --> Model Class Initialized
DEBUG - 2017-12-16 07:17:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 07:17:13 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-16 07:17:13 --> Final output sent to browser
DEBUG - 2017-12-16 07:17:13 --> Total execution time: 0.0536
INFO - 2017-12-16 07:19:11 --> Config Class Initialized
INFO - 2017-12-16 07:19:11 --> Hooks Class Initialized
DEBUG - 2017-12-16 07:19:11 --> UTF-8 Support Enabled
INFO - 2017-12-16 07:19:11 --> Utf8 Class Initialized
INFO - 2017-12-16 07:19:11 --> URI Class Initialized
INFO - 2017-12-16 07:19:11 --> Router Class Initialized
INFO - 2017-12-16 07:19:11 --> Output Class Initialized
INFO - 2017-12-16 07:19:11 --> Security Class Initialized
DEBUG - 2017-12-16 07:19:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 07:19:11 --> Input Class Initialized
INFO - 2017-12-16 07:19:11 --> Language Class Initialized
INFO - 2017-12-16 07:19:11 --> Loader Class Initialized
INFO - 2017-12-16 07:19:11 --> Helper loaded: url_helper
INFO - 2017-12-16 07:19:11 --> Helper loaded: form_helper
INFO - 2017-12-16 07:19:11 --> Database Driver Class Initialized
DEBUG - 2017-12-16 07:19:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 07:19:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 07:19:11 --> Form Validation Class Initialized
INFO - 2017-12-16 07:19:11 --> Model Class Initialized
INFO - 2017-12-16 07:19:11 --> Controller Class Initialized
INFO - 2017-12-16 07:19:11 --> Model Class Initialized
INFO - 2017-12-16 07:19:11 --> Model Class Initialized
INFO - 2017-12-16 07:19:11 --> Model Class Initialized
DEBUG - 2017-12-16 07:19:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 07:19:11 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-16 07:19:11 --> Final output sent to browser
DEBUG - 2017-12-16 07:19:11 --> Total execution time: 0.1117
INFO - 2017-12-16 07:19:12 --> Config Class Initialized
INFO - 2017-12-16 07:19:12 --> Hooks Class Initialized
DEBUG - 2017-12-16 07:19:13 --> UTF-8 Support Enabled
INFO - 2017-12-16 07:19:13 --> Utf8 Class Initialized
INFO - 2017-12-16 07:19:13 --> URI Class Initialized
INFO - 2017-12-16 07:19:13 --> Router Class Initialized
INFO - 2017-12-16 07:19:13 --> Output Class Initialized
INFO - 2017-12-16 07:19:13 --> Security Class Initialized
DEBUG - 2017-12-16 07:19:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 07:19:13 --> Input Class Initialized
INFO - 2017-12-16 07:19:13 --> Language Class Initialized
ERROR - 2017-12-16 07:19:13 --> 404 Page Not Found: Faviconico/index
INFO - 2017-12-16 07:19:45 --> Config Class Initialized
INFO - 2017-12-16 07:19:45 --> Hooks Class Initialized
DEBUG - 2017-12-16 07:19:45 --> UTF-8 Support Enabled
INFO - 2017-12-16 07:19:45 --> Utf8 Class Initialized
INFO - 2017-12-16 07:19:45 --> URI Class Initialized
INFO - 2017-12-16 07:19:45 --> Router Class Initialized
INFO - 2017-12-16 07:19:45 --> Output Class Initialized
INFO - 2017-12-16 07:19:45 --> Security Class Initialized
DEBUG - 2017-12-16 07:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 07:19:45 --> Input Class Initialized
INFO - 2017-12-16 07:19:45 --> Language Class Initialized
INFO - 2017-12-16 07:19:45 --> Loader Class Initialized
INFO - 2017-12-16 07:19:45 --> Helper loaded: url_helper
INFO - 2017-12-16 07:19:45 --> Helper loaded: form_helper
INFO - 2017-12-16 07:19:45 --> Database Driver Class Initialized
DEBUG - 2017-12-16 07:19:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 07:19:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 07:19:45 --> Form Validation Class Initialized
INFO - 2017-12-16 07:19:45 --> Model Class Initialized
INFO - 2017-12-16 07:19:45 --> Controller Class Initialized
INFO - 2017-12-16 07:19:45 --> Model Class Initialized
INFO - 2017-12-16 07:19:45 --> Model Class Initialized
INFO - 2017-12-16 07:19:45 --> Model Class Initialized
DEBUG - 2017-12-16 07:19:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 07:19:45 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-16 07:19:45 --> Final output sent to browser
DEBUG - 2017-12-16 07:19:45 --> Total execution time: 0.0788
INFO - 2017-12-16 07:22:50 --> Config Class Initialized
INFO - 2017-12-16 07:22:50 --> Hooks Class Initialized
DEBUG - 2017-12-16 07:22:50 --> UTF-8 Support Enabled
INFO - 2017-12-16 07:22:50 --> Utf8 Class Initialized
INFO - 2017-12-16 07:22:50 --> URI Class Initialized
INFO - 2017-12-16 07:22:50 --> Router Class Initialized
INFO - 2017-12-16 07:22:50 --> Output Class Initialized
INFO - 2017-12-16 07:22:50 --> Security Class Initialized
DEBUG - 2017-12-16 07:22:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 07:22:50 --> Input Class Initialized
INFO - 2017-12-16 07:22:50 --> Language Class Initialized
INFO - 2017-12-16 07:22:50 --> Loader Class Initialized
INFO - 2017-12-16 07:22:50 --> Helper loaded: url_helper
INFO - 2017-12-16 07:22:50 --> Helper loaded: form_helper
INFO - 2017-12-16 07:22:50 --> Database Driver Class Initialized
DEBUG - 2017-12-16 07:22:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 07:22:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 07:22:50 --> Form Validation Class Initialized
INFO - 2017-12-16 07:22:50 --> Model Class Initialized
INFO - 2017-12-16 07:22:50 --> Controller Class Initialized
INFO - 2017-12-16 07:22:50 --> Model Class Initialized
INFO - 2017-12-16 07:22:50 --> Model Class Initialized
INFO - 2017-12-16 07:22:50 --> Model Class Initialized
DEBUG - 2017-12-16 07:22:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 07:22:50 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-16 07:22:50 --> Final output sent to browser
DEBUG - 2017-12-16 07:22:50 --> Total execution time: 0.0739
INFO - 2017-12-16 07:23:14 --> Config Class Initialized
INFO - 2017-12-16 07:23:14 --> Hooks Class Initialized
DEBUG - 2017-12-16 07:23:14 --> UTF-8 Support Enabled
INFO - 2017-12-16 07:23:14 --> Utf8 Class Initialized
INFO - 2017-12-16 07:23:14 --> URI Class Initialized
INFO - 2017-12-16 07:23:14 --> Router Class Initialized
INFO - 2017-12-16 07:23:14 --> Output Class Initialized
INFO - 2017-12-16 07:23:14 --> Security Class Initialized
DEBUG - 2017-12-16 07:23:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 07:23:14 --> Input Class Initialized
INFO - 2017-12-16 07:23:14 --> Language Class Initialized
INFO - 2017-12-16 07:23:14 --> Loader Class Initialized
INFO - 2017-12-16 07:23:14 --> Helper loaded: url_helper
INFO - 2017-12-16 07:23:14 --> Helper loaded: form_helper
INFO - 2017-12-16 07:23:14 --> Database Driver Class Initialized
DEBUG - 2017-12-16 07:23:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 07:23:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 07:23:14 --> Form Validation Class Initialized
INFO - 2017-12-16 07:23:14 --> Model Class Initialized
INFO - 2017-12-16 07:23:14 --> Controller Class Initialized
INFO - 2017-12-16 07:23:14 --> Model Class Initialized
INFO - 2017-12-16 07:23:14 --> Model Class Initialized
INFO - 2017-12-16 07:23:14 --> Model Class Initialized
DEBUG - 2017-12-16 07:23:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 07:23:14 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-16 07:23:14 --> Final output sent to browser
DEBUG - 2017-12-16 07:23:14 --> Total execution time: 0.0580
INFO - 2017-12-16 07:23:41 --> Config Class Initialized
INFO - 2017-12-16 07:23:41 --> Hooks Class Initialized
DEBUG - 2017-12-16 07:23:41 --> UTF-8 Support Enabled
INFO - 2017-12-16 07:23:41 --> Utf8 Class Initialized
INFO - 2017-12-16 07:23:41 --> URI Class Initialized
INFO - 2017-12-16 07:23:41 --> Router Class Initialized
INFO - 2017-12-16 07:23:41 --> Output Class Initialized
INFO - 2017-12-16 07:23:41 --> Security Class Initialized
DEBUG - 2017-12-16 07:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 07:23:41 --> Input Class Initialized
INFO - 2017-12-16 07:23:41 --> Language Class Initialized
INFO - 2017-12-16 07:23:41 --> Loader Class Initialized
INFO - 2017-12-16 07:23:41 --> Helper loaded: url_helper
INFO - 2017-12-16 07:23:41 --> Helper loaded: form_helper
INFO - 2017-12-16 07:23:41 --> Database Driver Class Initialized
DEBUG - 2017-12-16 07:23:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 07:23:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 07:23:41 --> Form Validation Class Initialized
INFO - 2017-12-16 07:23:41 --> Model Class Initialized
INFO - 2017-12-16 07:23:41 --> Controller Class Initialized
INFO - 2017-12-16 07:23:41 --> Model Class Initialized
INFO - 2017-12-16 07:23:41 --> Model Class Initialized
INFO - 2017-12-16 07:23:41 --> Model Class Initialized
DEBUG - 2017-12-16 07:23:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 07:23:41 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-16 07:23:41 --> Final output sent to browser
DEBUG - 2017-12-16 07:23:41 --> Total execution time: 0.0762
INFO - 2017-12-16 07:23:50 --> Config Class Initialized
INFO - 2017-12-16 07:23:50 --> Hooks Class Initialized
DEBUG - 2017-12-16 07:23:50 --> UTF-8 Support Enabled
INFO - 2017-12-16 07:23:50 --> Utf8 Class Initialized
INFO - 2017-12-16 07:23:50 --> URI Class Initialized
INFO - 2017-12-16 07:23:50 --> Router Class Initialized
INFO - 2017-12-16 07:23:50 --> Output Class Initialized
INFO - 2017-12-16 07:23:50 --> Security Class Initialized
DEBUG - 2017-12-16 07:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 07:23:50 --> Input Class Initialized
INFO - 2017-12-16 07:23:50 --> Language Class Initialized
INFO - 2017-12-16 07:23:50 --> Loader Class Initialized
INFO - 2017-12-16 07:23:50 --> Helper loaded: url_helper
INFO - 2017-12-16 07:23:50 --> Helper loaded: form_helper
INFO - 2017-12-16 07:23:50 --> Database Driver Class Initialized
DEBUG - 2017-12-16 07:23:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 07:23:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 07:23:50 --> Form Validation Class Initialized
INFO - 2017-12-16 07:23:50 --> Model Class Initialized
INFO - 2017-12-16 07:23:50 --> Controller Class Initialized
INFO - 2017-12-16 07:23:50 --> Model Class Initialized
INFO - 2017-12-16 07:23:50 --> Model Class Initialized
INFO - 2017-12-16 07:23:50 --> Model Class Initialized
DEBUG - 2017-12-16 07:23:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 07:23:50 --> Final output sent to browser
DEBUG - 2017-12-16 07:23:50 --> Total execution time: 0.0546
INFO - 2017-12-16 07:23:51 --> Config Class Initialized
INFO - 2017-12-16 07:23:51 --> Hooks Class Initialized
DEBUG - 2017-12-16 07:23:51 --> UTF-8 Support Enabled
INFO - 2017-12-16 07:23:51 --> Utf8 Class Initialized
INFO - 2017-12-16 07:23:51 --> URI Class Initialized
INFO - 2017-12-16 07:23:51 --> Router Class Initialized
INFO - 2017-12-16 07:23:51 --> Output Class Initialized
INFO - 2017-12-16 07:23:51 --> Security Class Initialized
DEBUG - 2017-12-16 07:23:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 07:23:51 --> Input Class Initialized
INFO - 2017-12-16 07:23:51 --> Language Class Initialized
INFO - 2017-12-16 07:23:51 --> Loader Class Initialized
INFO - 2017-12-16 07:23:51 --> Helper loaded: url_helper
INFO - 2017-12-16 07:23:51 --> Helper loaded: form_helper
INFO - 2017-12-16 07:23:51 --> Database Driver Class Initialized
DEBUG - 2017-12-16 07:23:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 07:23:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 07:23:51 --> Form Validation Class Initialized
INFO - 2017-12-16 07:23:51 --> Model Class Initialized
INFO - 2017-12-16 07:23:51 --> Controller Class Initialized
INFO - 2017-12-16 07:23:51 --> Model Class Initialized
INFO - 2017-12-16 07:23:51 --> Model Class Initialized
INFO - 2017-12-16 07:23:51 --> Model Class Initialized
DEBUG - 2017-12-16 07:23:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 07:23:56 --> Config Class Initialized
INFO - 2017-12-16 07:23:56 --> Hooks Class Initialized
DEBUG - 2017-12-16 07:23:56 --> UTF-8 Support Enabled
INFO - 2017-12-16 07:23:56 --> Utf8 Class Initialized
INFO - 2017-12-16 07:23:56 --> URI Class Initialized
INFO - 2017-12-16 07:23:56 --> Router Class Initialized
INFO - 2017-12-16 07:23:56 --> Output Class Initialized
INFO - 2017-12-16 07:23:56 --> Security Class Initialized
DEBUG - 2017-12-16 07:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 07:23:56 --> Input Class Initialized
INFO - 2017-12-16 07:23:56 --> Language Class Initialized
INFO - 2017-12-16 07:23:56 --> Loader Class Initialized
INFO - 2017-12-16 07:23:56 --> Helper loaded: url_helper
INFO - 2017-12-16 07:23:56 --> Helper loaded: form_helper
INFO - 2017-12-16 07:23:56 --> Database Driver Class Initialized
DEBUG - 2017-12-16 07:23:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 07:23:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 07:23:56 --> Form Validation Class Initialized
INFO - 2017-12-16 07:23:56 --> Model Class Initialized
INFO - 2017-12-16 07:23:56 --> Controller Class Initialized
INFO - 2017-12-16 07:23:56 --> Model Class Initialized
INFO - 2017-12-16 07:23:56 --> Model Class Initialized
INFO - 2017-12-16 07:23:56 --> Model Class Initialized
DEBUG - 2017-12-16 07:23:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 07:23:56 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-16 07:23:56 --> Final output sent to browser
DEBUG - 2017-12-16 07:23:56 --> Total execution time: 0.0574
INFO - 2017-12-16 07:24:02 --> Config Class Initialized
INFO - 2017-12-16 07:24:02 --> Hooks Class Initialized
DEBUG - 2017-12-16 07:24:02 --> UTF-8 Support Enabled
INFO - 2017-12-16 07:24:02 --> Utf8 Class Initialized
INFO - 2017-12-16 07:24:02 --> URI Class Initialized
INFO - 2017-12-16 07:24:02 --> Router Class Initialized
INFO - 2017-12-16 07:24:02 --> Output Class Initialized
INFO - 2017-12-16 07:24:02 --> Security Class Initialized
DEBUG - 2017-12-16 07:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 07:24:02 --> Input Class Initialized
INFO - 2017-12-16 07:24:02 --> Language Class Initialized
INFO - 2017-12-16 07:24:02 --> Loader Class Initialized
INFO - 2017-12-16 07:24:02 --> Helper loaded: url_helper
INFO - 2017-12-16 07:24:02 --> Helper loaded: form_helper
INFO - 2017-12-16 07:24:02 --> Database Driver Class Initialized
DEBUG - 2017-12-16 07:24:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 07:24:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 07:24:02 --> Form Validation Class Initialized
INFO - 2017-12-16 07:24:02 --> Model Class Initialized
INFO - 2017-12-16 07:24:02 --> Controller Class Initialized
INFO - 2017-12-16 07:24:02 --> Model Class Initialized
INFO - 2017-12-16 07:24:02 --> Model Class Initialized
INFO - 2017-12-16 07:24:02 --> Model Class Initialized
DEBUG - 2017-12-16 07:24:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 07:24:02 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-16 07:24:02 --> Final output sent to browser
DEBUG - 2017-12-16 07:24:02 --> Total execution time: 0.0536
INFO - 2017-12-16 07:26:48 --> Config Class Initialized
INFO - 2017-12-16 07:26:48 --> Hooks Class Initialized
DEBUG - 2017-12-16 07:26:48 --> UTF-8 Support Enabled
INFO - 2017-12-16 07:26:48 --> Utf8 Class Initialized
INFO - 2017-12-16 07:26:48 --> URI Class Initialized
INFO - 2017-12-16 07:26:48 --> Router Class Initialized
INFO - 2017-12-16 07:26:48 --> Output Class Initialized
INFO - 2017-12-16 07:26:48 --> Security Class Initialized
DEBUG - 2017-12-16 07:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 07:26:48 --> Input Class Initialized
INFO - 2017-12-16 07:26:48 --> Language Class Initialized
INFO - 2017-12-16 07:26:48 --> Loader Class Initialized
INFO - 2017-12-16 07:26:48 --> Helper loaded: url_helper
INFO - 2017-12-16 07:26:48 --> Helper loaded: form_helper
INFO - 2017-12-16 07:26:48 --> Database Driver Class Initialized
DEBUG - 2017-12-16 07:26:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 07:26:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 07:26:48 --> Form Validation Class Initialized
INFO - 2017-12-16 07:26:48 --> Model Class Initialized
INFO - 2017-12-16 07:26:48 --> Controller Class Initialized
INFO - 2017-12-16 07:26:48 --> Model Class Initialized
INFO - 2017-12-16 07:26:48 --> Model Class Initialized
INFO - 2017-12-16 07:26:48 --> Model Class Initialized
DEBUG - 2017-12-16 07:26:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 07:26:48 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-16 07:26:48 --> Final output sent to browser
DEBUG - 2017-12-16 07:26:48 --> Total execution time: 0.0800
INFO - 2017-12-16 07:27:14 --> Config Class Initialized
INFO - 2017-12-16 07:27:14 --> Hooks Class Initialized
DEBUG - 2017-12-16 07:27:14 --> UTF-8 Support Enabled
INFO - 2017-12-16 07:27:14 --> Utf8 Class Initialized
INFO - 2017-12-16 07:27:14 --> URI Class Initialized
INFO - 2017-12-16 07:27:14 --> Router Class Initialized
INFO - 2017-12-16 07:27:14 --> Output Class Initialized
INFO - 2017-12-16 07:27:14 --> Security Class Initialized
DEBUG - 2017-12-16 07:27:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 07:27:14 --> Input Class Initialized
INFO - 2017-12-16 07:27:14 --> Language Class Initialized
INFO - 2017-12-16 07:27:14 --> Loader Class Initialized
INFO - 2017-12-16 07:27:14 --> Helper loaded: url_helper
INFO - 2017-12-16 07:27:14 --> Helper loaded: form_helper
INFO - 2017-12-16 07:27:14 --> Database Driver Class Initialized
DEBUG - 2017-12-16 07:27:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 07:27:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 07:27:14 --> Form Validation Class Initialized
INFO - 2017-12-16 07:27:14 --> Model Class Initialized
INFO - 2017-12-16 07:27:14 --> Controller Class Initialized
INFO - 2017-12-16 07:27:14 --> Model Class Initialized
INFO - 2017-12-16 07:27:14 --> Model Class Initialized
INFO - 2017-12-16 07:27:14 --> Model Class Initialized
DEBUG - 2017-12-16 07:27:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 07:27:14 --> Final output sent to browser
DEBUG - 2017-12-16 07:27:14 --> Total execution time: 0.0575
INFO - 2017-12-16 07:27:15 --> Config Class Initialized
INFO - 2017-12-16 07:27:15 --> Hooks Class Initialized
DEBUG - 2017-12-16 07:27:15 --> UTF-8 Support Enabled
INFO - 2017-12-16 07:27:15 --> Utf8 Class Initialized
INFO - 2017-12-16 07:27:15 --> URI Class Initialized
INFO - 2017-12-16 07:27:15 --> Router Class Initialized
INFO - 2017-12-16 07:27:15 --> Output Class Initialized
INFO - 2017-12-16 07:27:15 --> Security Class Initialized
DEBUG - 2017-12-16 07:27:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 07:27:15 --> Input Class Initialized
INFO - 2017-12-16 07:27:15 --> Language Class Initialized
INFO - 2017-12-16 07:27:15 --> Loader Class Initialized
INFO - 2017-12-16 07:27:15 --> Helper loaded: url_helper
INFO - 2017-12-16 07:27:15 --> Helper loaded: form_helper
INFO - 2017-12-16 07:27:15 --> Database Driver Class Initialized
DEBUG - 2017-12-16 07:27:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 07:27:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 07:27:15 --> Form Validation Class Initialized
INFO - 2017-12-16 07:27:15 --> Model Class Initialized
INFO - 2017-12-16 07:27:15 --> Controller Class Initialized
INFO - 2017-12-16 07:27:15 --> Model Class Initialized
INFO - 2017-12-16 07:27:15 --> Model Class Initialized
INFO - 2017-12-16 07:27:15 --> Model Class Initialized
DEBUG - 2017-12-16 07:27:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 07:27:21 --> Config Class Initialized
INFO - 2017-12-16 07:27:21 --> Hooks Class Initialized
DEBUG - 2017-12-16 07:27:22 --> UTF-8 Support Enabled
INFO - 2017-12-16 07:27:22 --> Utf8 Class Initialized
INFO - 2017-12-16 07:27:22 --> URI Class Initialized
INFO - 2017-12-16 07:27:22 --> Router Class Initialized
INFO - 2017-12-16 07:27:22 --> Output Class Initialized
INFO - 2017-12-16 07:27:22 --> Security Class Initialized
DEBUG - 2017-12-16 07:27:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 07:27:22 --> Input Class Initialized
INFO - 2017-12-16 07:27:22 --> Language Class Initialized
INFO - 2017-12-16 07:27:22 --> Loader Class Initialized
INFO - 2017-12-16 07:27:22 --> Helper loaded: url_helper
INFO - 2017-12-16 07:27:22 --> Helper loaded: form_helper
INFO - 2017-12-16 07:27:22 --> Database Driver Class Initialized
DEBUG - 2017-12-16 07:27:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 07:27:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 07:27:22 --> Form Validation Class Initialized
INFO - 2017-12-16 07:27:22 --> Model Class Initialized
INFO - 2017-12-16 07:27:22 --> Controller Class Initialized
INFO - 2017-12-16 07:27:22 --> Model Class Initialized
INFO - 2017-12-16 07:27:22 --> Model Class Initialized
INFO - 2017-12-16 07:27:22 --> Model Class Initialized
DEBUG - 2017-12-16 07:27:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 07:27:22 --> Final output sent to browser
DEBUG - 2017-12-16 07:27:22 --> Total execution time: 0.0446
INFO - 2017-12-16 07:27:23 --> Config Class Initialized
INFO - 2017-12-16 07:27:23 --> Hooks Class Initialized
DEBUG - 2017-12-16 07:27:23 --> UTF-8 Support Enabled
INFO - 2017-12-16 07:27:23 --> Utf8 Class Initialized
INFO - 2017-12-16 07:27:23 --> URI Class Initialized
INFO - 2017-12-16 07:27:23 --> Router Class Initialized
INFO - 2017-12-16 07:27:23 --> Output Class Initialized
INFO - 2017-12-16 07:27:23 --> Security Class Initialized
DEBUG - 2017-12-16 07:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 07:27:23 --> Input Class Initialized
INFO - 2017-12-16 07:27:23 --> Language Class Initialized
INFO - 2017-12-16 07:27:23 --> Loader Class Initialized
INFO - 2017-12-16 07:27:23 --> Helper loaded: url_helper
INFO - 2017-12-16 07:27:23 --> Helper loaded: form_helper
INFO - 2017-12-16 07:27:23 --> Database Driver Class Initialized
DEBUG - 2017-12-16 07:27:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 07:27:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 07:27:23 --> Form Validation Class Initialized
INFO - 2017-12-16 07:27:23 --> Model Class Initialized
INFO - 2017-12-16 07:27:23 --> Controller Class Initialized
INFO - 2017-12-16 07:27:23 --> Model Class Initialized
INFO - 2017-12-16 07:27:23 --> Model Class Initialized
INFO - 2017-12-16 07:27:23 --> Model Class Initialized
DEBUG - 2017-12-16 07:27:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 07:32:27 --> Config Class Initialized
INFO - 2017-12-16 07:32:27 --> Hooks Class Initialized
DEBUG - 2017-12-16 07:32:27 --> UTF-8 Support Enabled
INFO - 2017-12-16 07:32:27 --> Utf8 Class Initialized
INFO - 2017-12-16 07:32:27 --> URI Class Initialized
INFO - 2017-12-16 07:32:27 --> Router Class Initialized
INFO - 2017-12-16 07:32:27 --> Output Class Initialized
INFO - 2017-12-16 07:32:27 --> Security Class Initialized
DEBUG - 2017-12-16 07:32:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 07:32:27 --> Input Class Initialized
INFO - 2017-12-16 07:32:27 --> Language Class Initialized
INFO - 2017-12-16 07:32:27 --> Loader Class Initialized
INFO - 2017-12-16 07:32:27 --> Helper loaded: url_helper
INFO - 2017-12-16 07:32:27 --> Helper loaded: form_helper
INFO - 2017-12-16 07:32:27 --> Database Driver Class Initialized
DEBUG - 2017-12-16 07:32:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 07:32:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 07:32:27 --> Form Validation Class Initialized
INFO - 2017-12-16 07:32:27 --> Model Class Initialized
INFO - 2017-12-16 07:32:27 --> Controller Class Initialized
INFO - 2017-12-16 07:32:27 --> Model Class Initialized
INFO - 2017-12-16 07:32:27 --> Model Class Initialized
INFO - 2017-12-16 07:32:27 --> Model Class Initialized
DEBUG - 2017-12-16 07:32:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 07:32:28 --> Config Class Initialized
INFO - 2017-12-16 07:32:28 --> Hooks Class Initialized
DEBUG - 2017-12-16 07:32:28 --> UTF-8 Support Enabled
INFO - 2017-12-16 07:32:28 --> Utf8 Class Initialized
INFO - 2017-12-16 07:32:28 --> URI Class Initialized
INFO - 2017-12-16 07:32:28 --> Router Class Initialized
INFO - 2017-12-16 07:32:28 --> Output Class Initialized
INFO - 2017-12-16 07:32:28 --> Security Class Initialized
DEBUG - 2017-12-16 07:32:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 07:32:28 --> Input Class Initialized
INFO - 2017-12-16 07:32:28 --> Language Class Initialized
ERROR - 2017-12-16 07:32:28 --> 404 Page Not Found: Proyecto/editarProyecto
INFO - 2017-12-16 19:09:46 --> Config Class Initialized
INFO - 2017-12-16 19:09:46 --> Hooks Class Initialized
DEBUG - 2017-12-16 19:09:46 --> UTF-8 Support Enabled
INFO - 2017-12-16 19:09:46 --> Utf8 Class Initialized
INFO - 2017-12-16 19:09:46 --> URI Class Initialized
INFO - 2017-12-16 19:09:46 --> Router Class Initialized
INFO - 2017-12-16 19:09:46 --> Output Class Initialized
INFO - 2017-12-16 19:09:46 --> Security Class Initialized
DEBUG - 2017-12-16 19:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 19:09:46 --> Input Class Initialized
INFO - 2017-12-16 19:09:46 --> Language Class Initialized
INFO - 2017-12-16 19:09:46 --> Loader Class Initialized
INFO - 2017-12-16 19:09:46 --> Helper loaded: url_helper
INFO - 2017-12-16 19:09:46 --> Helper loaded: form_helper
INFO - 2017-12-16 19:09:46 --> Database Driver Class Initialized
DEBUG - 2017-12-16 19:09:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 19:09:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 19:09:46 --> Form Validation Class Initialized
INFO - 2017-12-16 19:09:46 --> Model Class Initialized
INFO - 2017-12-16 19:09:46 --> Controller Class Initialized
INFO - 2017-12-16 19:09:46 --> Model Class Initialized
INFO - 2017-12-16 19:09:46 --> Config Class Initialized
INFO - 2017-12-16 19:09:46 --> Hooks Class Initialized
DEBUG - 2017-12-16 19:09:46 --> UTF-8 Support Enabled
INFO - 2017-12-16 19:09:46 --> Utf8 Class Initialized
INFO - 2017-12-16 19:09:46 --> URI Class Initialized
INFO - 2017-12-16 19:09:46 --> Router Class Initialized
INFO - 2017-12-16 19:09:46 --> Output Class Initialized
INFO - 2017-12-16 19:09:46 --> Security Class Initialized
DEBUG - 2017-12-16 19:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 19:09:46 --> Input Class Initialized
INFO - 2017-12-16 19:09:46 --> Language Class Initialized
INFO - 2017-12-16 19:09:46 --> Loader Class Initialized
INFO - 2017-12-16 19:09:46 --> Helper loaded: url_helper
INFO - 2017-12-16 19:09:46 --> Helper loaded: form_helper
INFO - 2017-12-16 19:09:46 --> Database Driver Class Initialized
DEBUG - 2017-12-16 19:09:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 19:09:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 19:09:46 --> Form Validation Class Initialized
INFO - 2017-12-16 19:09:46 --> Model Class Initialized
INFO - 2017-12-16 19:09:46 --> Controller Class Initialized
INFO - 2017-12-16 19:09:46 --> Model Class Initialized
DEBUG - 2017-12-16 19:09:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 19:09:46 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-16 19:09:46 --> Final output sent to browser
DEBUG - 2017-12-16 19:09:46 --> Total execution time: 0.1279
INFO - 2017-12-16 19:09:48 --> Config Class Initialized
INFO - 2017-12-16 19:09:48 --> Hooks Class Initialized
DEBUG - 2017-12-16 19:09:48 --> UTF-8 Support Enabled
INFO - 2017-12-16 19:09:48 --> Utf8 Class Initialized
INFO - 2017-12-16 19:09:48 --> URI Class Initialized
INFO - 2017-12-16 19:09:48 --> Router Class Initialized
INFO - 2017-12-16 19:09:48 --> Output Class Initialized
INFO - 2017-12-16 19:09:48 --> Security Class Initialized
DEBUG - 2017-12-16 19:09:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 19:09:48 --> Input Class Initialized
INFO - 2017-12-16 19:09:48 --> Language Class Initialized
INFO - 2017-12-16 19:09:48 --> Loader Class Initialized
INFO - 2017-12-16 19:09:48 --> Helper loaded: url_helper
INFO - 2017-12-16 19:09:48 --> Helper loaded: form_helper
INFO - 2017-12-16 19:09:48 --> Database Driver Class Initialized
DEBUG - 2017-12-16 19:09:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 19:09:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 19:09:48 --> Form Validation Class Initialized
INFO - 2017-12-16 19:09:48 --> Model Class Initialized
INFO - 2017-12-16 19:09:48 --> Controller Class Initialized
INFO - 2017-12-16 19:09:48 --> Model Class Initialized
DEBUG - 2017-12-16 19:09:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 19:09:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-12-16 19:09:48 --> Config Class Initialized
INFO - 2017-12-16 19:09:48 --> Hooks Class Initialized
DEBUG - 2017-12-16 19:09:48 --> UTF-8 Support Enabled
INFO - 2017-12-16 19:09:48 --> Utf8 Class Initialized
INFO - 2017-12-16 19:09:48 --> URI Class Initialized
DEBUG - 2017-12-16 19:09:48 --> No URI present. Default controller set.
INFO - 2017-12-16 19:09:48 --> Router Class Initialized
INFO - 2017-12-16 19:09:48 --> Output Class Initialized
INFO - 2017-12-16 19:09:48 --> Security Class Initialized
DEBUG - 2017-12-16 19:09:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 19:09:48 --> Input Class Initialized
INFO - 2017-12-16 19:09:48 --> Language Class Initialized
INFO - 2017-12-16 19:09:48 --> Loader Class Initialized
INFO - 2017-12-16 19:09:48 --> Helper loaded: url_helper
INFO - 2017-12-16 19:09:48 --> Helper loaded: form_helper
INFO - 2017-12-16 19:09:48 --> Database Driver Class Initialized
DEBUG - 2017-12-16 19:09:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 19:09:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 19:09:48 --> Form Validation Class Initialized
INFO - 2017-12-16 19:09:48 --> Model Class Initialized
INFO - 2017-12-16 19:09:48 --> Controller Class Initialized
INFO - 2017-12-16 19:09:48 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-16 19:09:48 --> Final output sent to browser
DEBUG - 2017-12-16 19:09:48 --> Total execution time: 0.0952
INFO - 2017-12-16 19:09:53 --> Config Class Initialized
INFO - 2017-12-16 19:09:53 --> Hooks Class Initialized
DEBUG - 2017-12-16 19:09:53 --> UTF-8 Support Enabled
INFO - 2017-12-16 19:09:53 --> Utf8 Class Initialized
INFO - 2017-12-16 19:09:53 --> URI Class Initialized
INFO - 2017-12-16 19:09:53 --> Router Class Initialized
INFO - 2017-12-16 19:09:53 --> Output Class Initialized
INFO - 2017-12-16 19:09:53 --> Security Class Initialized
DEBUG - 2017-12-16 19:09:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 19:09:53 --> Input Class Initialized
INFO - 2017-12-16 19:09:53 --> Language Class Initialized
INFO - 2017-12-16 19:09:53 --> Loader Class Initialized
INFO - 2017-12-16 19:09:53 --> Helper loaded: url_helper
INFO - 2017-12-16 19:09:53 --> Helper loaded: form_helper
INFO - 2017-12-16 19:09:53 --> Database Driver Class Initialized
DEBUG - 2017-12-16 19:09:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 19:09:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 19:09:53 --> Form Validation Class Initialized
INFO - 2017-12-16 19:09:53 --> Model Class Initialized
INFO - 2017-12-16 19:09:53 --> Controller Class Initialized
INFO - 2017-12-16 19:09:53 --> Model Class Initialized
INFO - 2017-12-16 19:09:53 --> Model Class Initialized
INFO - 2017-12-16 19:09:53 --> Model Class Initialized
DEBUG - 2017-12-16 19:09:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 19:09:53 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-16 19:09:53 --> Final output sent to browser
DEBUG - 2017-12-16 19:09:53 --> Total execution time: 0.1111
INFO - 2017-12-16 19:16:36 --> Config Class Initialized
INFO - 2017-12-16 19:16:36 --> Hooks Class Initialized
DEBUG - 2017-12-16 19:16:36 --> UTF-8 Support Enabled
INFO - 2017-12-16 19:16:36 --> Utf8 Class Initialized
INFO - 2017-12-16 19:16:36 --> URI Class Initialized
INFO - 2017-12-16 19:16:36 --> Router Class Initialized
INFO - 2017-12-16 19:16:36 --> Output Class Initialized
INFO - 2017-12-16 19:16:36 --> Security Class Initialized
DEBUG - 2017-12-16 19:16:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 19:16:36 --> Input Class Initialized
INFO - 2017-12-16 19:16:36 --> Language Class Initialized
INFO - 2017-12-16 19:16:36 --> Loader Class Initialized
INFO - 2017-12-16 19:16:36 --> Helper loaded: url_helper
INFO - 2017-12-16 19:16:36 --> Helper loaded: form_helper
INFO - 2017-12-16 19:16:36 --> Database Driver Class Initialized
DEBUG - 2017-12-16 19:16:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 19:16:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 19:16:36 --> Form Validation Class Initialized
INFO - 2017-12-16 19:16:36 --> Model Class Initialized
INFO - 2017-12-16 19:16:36 --> Controller Class Initialized
INFO - 2017-12-16 19:16:36 --> Model Class Initialized
INFO - 2017-12-16 19:16:36 --> Model Class Initialized
INFO - 2017-12-16 19:16:36 --> Model Class Initialized
DEBUG - 2017-12-16 19:16:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 19:16:36 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-16 19:16:36 --> Final output sent to browser
DEBUG - 2017-12-16 19:16:36 --> Total execution time: 0.0576
INFO - 2017-12-16 20:00:18 --> Config Class Initialized
INFO - 2017-12-16 20:00:18 --> Hooks Class Initialized
DEBUG - 2017-12-16 20:00:18 --> UTF-8 Support Enabled
INFO - 2017-12-16 20:00:18 --> Utf8 Class Initialized
INFO - 2017-12-16 20:00:18 --> URI Class Initialized
INFO - 2017-12-16 20:00:18 --> Router Class Initialized
INFO - 2017-12-16 20:00:18 --> Output Class Initialized
INFO - 2017-12-16 20:00:18 --> Security Class Initialized
DEBUG - 2017-12-16 20:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 20:00:18 --> Input Class Initialized
INFO - 2017-12-16 20:00:18 --> Language Class Initialized
INFO - 2017-12-16 20:00:18 --> Loader Class Initialized
INFO - 2017-12-16 20:00:18 --> Helper loaded: url_helper
INFO - 2017-12-16 20:00:18 --> Helper loaded: form_helper
INFO - 2017-12-16 20:00:18 --> Database Driver Class Initialized
DEBUG - 2017-12-16 20:00:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 20:00:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 20:00:18 --> Form Validation Class Initialized
INFO - 2017-12-16 20:00:18 --> Model Class Initialized
INFO - 2017-12-16 20:00:18 --> Controller Class Initialized
INFO - 2017-12-16 20:00:18 --> Model Class Initialized
INFO - 2017-12-16 20:00:18 --> Model Class Initialized
INFO - 2017-12-16 20:00:18 --> Model Class Initialized
DEBUG - 2017-12-16 20:00:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 20:00:18 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-16 20:00:18 --> Final output sent to browser
DEBUG - 2017-12-16 20:00:18 --> Total execution time: 0.0837
INFO - 2017-12-16 20:01:59 --> Config Class Initialized
INFO - 2017-12-16 20:01:59 --> Hooks Class Initialized
DEBUG - 2017-12-16 20:01:59 --> UTF-8 Support Enabled
INFO - 2017-12-16 20:01:59 --> Utf8 Class Initialized
INFO - 2017-12-16 20:01:59 --> URI Class Initialized
INFO - 2017-12-16 20:01:59 --> Router Class Initialized
INFO - 2017-12-16 20:01:59 --> Output Class Initialized
INFO - 2017-12-16 20:01:59 --> Security Class Initialized
DEBUG - 2017-12-16 20:01:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 20:01:59 --> Input Class Initialized
INFO - 2017-12-16 20:01:59 --> Language Class Initialized
INFO - 2017-12-16 20:01:59 --> Loader Class Initialized
INFO - 2017-12-16 20:01:59 --> Helper loaded: url_helper
INFO - 2017-12-16 20:01:59 --> Helper loaded: form_helper
INFO - 2017-12-16 20:01:59 --> Database Driver Class Initialized
DEBUG - 2017-12-16 20:01:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 20:01:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 20:01:59 --> Form Validation Class Initialized
INFO - 2017-12-16 20:01:59 --> Model Class Initialized
INFO - 2017-12-16 20:01:59 --> Controller Class Initialized
INFO - 2017-12-16 20:01:59 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-16 20:01:59 --> Final output sent to browser
DEBUG - 2017-12-16 20:01:59 --> Total execution time: 0.0502
INFO - 2017-12-16 20:02:38 --> Config Class Initialized
INFO - 2017-12-16 20:02:38 --> Hooks Class Initialized
DEBUG - 2017-12-16 20:02:38 --> UTF-8 Support Enabled
INFO - 2017-12-16 20:02:38 --> Utf8 Class Initialized
INFO - 2017-12-16 20:02:38 --> URI Class Initialized
INFO - 2017-12-16 20:02:38 --> Router Class Initialized
INFO - 2017-12-16 20:02:38 --> Output Class Initialized
INFO - 2017-12-16 20:02:38 --> Security Class Initialized
DEBUG - 2017-12-16 20:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 20:02:38 --> Input Class Initialized
INFO - 2017-12-16 20:02:38 --> Language Class Initialized
INFO - 2017-12-16 20:02:38 --> Loader Class Initialized
INFO - 2017-12-16 20:02:38 --> Helper loaded: url_helper
INFO - 2017-12-16 20:02:38 --> Helper loaded: form_helper
INFO - 2017-12-16 20:02:38 --> Database Driver Class Initialized
DEBUG - 2017-12-16 20:02:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 20:02:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 20:02:38 --> Form Validation Class Initialized
INFO - 2017-12-16 20:02:38 --> Model Class Initialized
INFO - 2017-12-16 20:02:38 --> Controller Class Initialized
INFO - 2017-12-16 20:02:38 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-16 20:02:38 --> Final output sent to browser
DEBUG - 2017-12-16 20:02:38 --> Total execution time: 0.0438
INFO - 2017-12-16 20:02:40 --> Config Class Initialized
INFO - 2017-12-16 20:02:40 --> Hooks Class Initialized
DEBUG - 2017-12-16 20:02:40 --> UTF-8 Support Enabled
INFO - 2017-12-16 20:02:40 --> Utf8 Class Initialized
INFO - 2017-12-16 20:02:40 --> URI Class Initialized
DEBUG - 2017-12-16 20:02:40 --> No URI present. Default controller set.
INFO - 2017-12-16 20:02:40 --> Router Class Initialized
INFO - 2017-12-16 20:02:40 --> Output Class Initialized
INFO - 2017-12-16 20:02:40 --> Security Class Initialized
DEBUG - 2017-12-16 20:02:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 20:02:40 --> Input Class Initialized
INFO - 2017-12-16 20:02:40 --> Language Class Initialized
INFO - 2017-12-16 20:02:40 --> Loader Class Initialized
INFO - 2017-12-16 20:02:40 --> Helper loaded: url_helper
INFO - 2017-12-16 20:02:40 --> Helper loaded: form_helper
INFO - 2017-12-16 20:02:40 --> Database Driver Class Initialized
DEBUG - 2017-12-16 20:02:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 20:02:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 20:02:40 --> Form Validation Class Initialized
INFO - 2017-12-16 20:02:40 --> Model Class Initialized
INFO - 2017-12-16 20:02:40 --> Controller Class Initialized
INFO - 2017-12-16 20:02:40 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-16 20:02:40 --> Final output sent to browser
DEBUG - 2017-12-16 20:02:40 --> Total execution time: 0.0360
INFO - 2017-12-16 20:02:43 --> Config Class Initialized
INFO - 2017-12-16 20:02:43 --> Hooks Class Initialized
DEBUG - 2017-12-16 20:02:43 --> UTF-8 Support Enabled
INFO - 2017-12-16 20:02:43 --> Utf8 Class Initialized
INFO - 2017-12-16 20:02:43 --> URI Class Initialized
INFO - 2017-12-16 20:02:43 --> Router Class Initialized
INFO - 2017-12-16 20:02:43 --> Output Class Initialized
INFO - 2017-12-16 20:02:43 --> Security Class Initialized
DEBUG - 2017-12-16 20:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 20:02:43 --> Input Class Initialized
INFO - 2017-12-16 20:02:43 --> Language Class Initialized
INFO - 2017-12-16 20:02:43 --> Loader Class Initialized
INFO - 2017-12-16 20:02:43 --> Helper loaded: url_helper
INFO - 2017-12-16 20:02:43 --> Helper loaded: form_helper
INFO - 2017-12-16 20:02:43 --> Database Driver Class Initialized
DEBUG - 2017-12-16 20:02:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 20:02:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 20:02:43 --> Form Validation Class Initialized
INFO - 2017-12-16 20:02:43 --> Model Class Initialized
INFO - 2017-12-16 20:02:43 --> Controller Class Initialized
INFO - 2017-12-16 20:02:43 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-16 20:02:43 --> Final output sent to browser
DEBUG - 2017-12-16 20:02:43 --> Total execution time: 0.0372
INFO - 2017-12-16 20:07:50 --> Config Class Initialized
INFO - 2017-12-16 20:07:50 --> Hooks Class Initialized
DEBUG - 2017-12-16 20:07:50 --> UTF-8 Support Enabled
INFO - 2017-12-16 20:07:50 --> Utf8 Class Initialized
INFO - 2017-12-16 20:07:50 --> URI Class Initialized
DEBUG - 2017-12-16 20:07:50 --> No URI present. Default controller set.
INFO - 2017-12-16 20:07:50 --> Router Class Initialized
INFO - 2017-12-16 20:07:50 --> Output Class Initialized
INFO - 2017-12-16 20:07:50 --> Security Class Initialized
DEBUG - 2017-12-16 20:07:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 20:07:50 --> Input Class Initialized
INFO - 2017-12-16 20:07:50 --> Language Class Initialized
INFO - 2017-12-16 20:07:50 --> Loader Class Initialized
INFO - 2017-12-16 20:07:50 --> Helper loaded: url_helper
INFO - 2017-12-16 20:07:50 --> Helper loaded: form_helper
INFO - 2017-12-16 20:07:50 --> Database Driver Class Initialized
DEBUG - 2017-12-16 20:07:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 20:07:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 20:07:50 --> Form Validation Class Initialized
INFO - 2017-12-16 20:07:50 --> Model Class Initialized
INFO - 2017-12-16 20:07:50 --> Controller Class Initialized
INFO - 2017-12-16 20:07:50 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-16 20:07:50 --> Final output sent to browser
DEBUG - 2017-12-16 20:07:50 --> Total execution time: 0.0477
INFO - 2017-12-16 20:07:54 --> Config Class Initialized
INFO - 2017-12-16 20:07:54 --> Hooks Class Initialized
DEBUG - 2017-12-16 20:07:54 --> UTF-8 Support Enabled
INFO - 2017-12-16 20:07:54 --> Utf8 Class Initialized
INFO - 2017-12-16 20:07:54 --> URI Class Initialized
INFO - 2017-12-16 20:07:54 --> Router Class Initialized
INFO - 2017-12-16 20:07:54 --> Output Class Initialized
INFO - 2017-12-16 20:07:54 --> Security Class Initialized
DEBUG - 2017-12-16 20:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 20:07:54 --> Input Class Initialized
INFO - 2017-12-16 20:07:54 --> Language Class Initialized
INFO - 2017-12-16 20:07:54 --> Loader Class Initialized
INFO - 2017-12-16 20:07:54 --> Helper loaded: url_helper
INFO - 2017-12-16 20:07:54 --> Helper loaded: form_helper
INFO - 2017-12-16 20:07:54 --> Database Driver Class Initialized
DEBUG - 2017-12-16 20:07:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 20:07:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 20:07:54 --> Form Validation Class Initialized
INFO - 2017-12-16 20:07:54 --> Model Class Initialized
INFO - 2017-12-16 20:07:54 --> Controller Class Initialized
INFO - 2017-12-16 20:07:54 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-16 20:07:54 --> Final output sent to browser
DEBUG - 2017-12-16 20:07:54 --> Total execution time: 0.0353
INFO - 2017-12-16 20:09:04 --> Config Class Initialized
INFO - 2017-12-16 20:09:04 --> Hooks Class Initialized
DEBUG - 2017-12-16 20:09:04 --> UTF-8 Support Enabled
INFO - 2017-12-16 20:09:04 --> Utf8 Class Initialized
INFO - 2017-12-16 20:09:04 --> URI Class Initialized
INFO - 2017-12-16 20:09:04 --> Router Class Initialized
INFO - 2017-12-16 20:09:04 --> Output Class Initialized
INFO - 2017-12-16 20:09:04 --> Security Class Initialized
DEBUG - 2017-12-16 20:09:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 20:09:04 --> Input Class Initialized
INFO - 2017-12-16 20:09:04 --> Language Class Initialized
INFO - 2017-12-16 20:09:04 --> Loader Class Initialized
INFO - 2017-12-16 20:09:04 --> Helper loaded: url_helper
INFO - 2017-12-16 20:09:04 --> Helper loaded: form_helper
INFO - 2017-12-16 20:09:04 --> Database Driver Class Initialized
DEBUG - 2017-12-16 20:09:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 20:09:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 20:09:04 --> Form Validation Class Initialized
INFO - 2017-12-16 20:09:04 --> Model Class Initialized
INFO - 2017-12-16 20:09:04 --> Controller Class Initialized
INFO - 2017-12-16 20:09:04 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-16 20:09:04 --> Final output sent to browser
DEBUG - 2017-12-16 20:09:04 --> Total execution time: 0.1085
INFO - 2017-12-16 20:09:11 --> Config Class Initialized
INFO - 2017-12-16 20:09:11 --> Hooks Class Initialized
DEBUG - 2017-12-16 20:09:11 --> UTF-8 Support Enabled
INFO - 2017-12-16 20:09:11 --> Utf8 Class Initialized
INFO - 2017-12-16 20:09:11 --> URI Class Initialized
DEBUG - 2017-12-16 20:09:11 --> No URI present. Default controller set.
INFO - 2017-12-16 20:09:11 --> Router Class Initialized
INFO - 2017-12-16 20:09:11 --> Output Class Initialized
INFO - 2017-12-16 20:09:11 --> Security Class Initialized
DEBUG - 2017-12-16 20:09:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 20:09:11 --> Input Class Initialized
INFO - 2017-12-16 20:09:11 --> Language Class Initialized
INFO - 2017-12-16 20:09:11 --> Loader Class Initialized
INFO - 2017-12-16 20:09:11 --> Helper loaded: url_helper
INFO - 2017-12-16 20:09:11 --> Helper loaded: form_helper
INFO - 2017-12-16 20:09:11 --> Database Driver Class Initialized
DEBUG - 2017-12-16 20:09:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 20:09:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 20:09:11 --> Form Validation Class Initialized
INFO - 2017-12-16 20:09:11 --> Model Class Initialized
INFO - 2017-12-16 20:09:11 --> Controller Class Initialized
INFO - 2017-12-16 20:09:11 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-16 20:09:11 --> Final output sent to browser
DEBUG - 2017-12-16 20:09:11 --> Total execution time: 0.0492
INFO - 2017-12-16 20:09:16 --> Config Class Initialized
INFO - 2017-12-16 20:09:16 --> Hooks Class Initialized
DEBUG - 2017-12-16 20:09:16 --> UTF-8 Support Enabled
INFO - 2017-12-16 20:09:16 --> Utf8 Class Initialized
INFO - 2017-12-16 20:09:16 --> URI Class Initialized
INFO - 2017-12-16 20:09:16 --> Router Class Initialized
INFO - 2017-12-16 20:09:16 --> Output Class Initialized
INFO - 2017-12-16 20:09:16 --> Security Class Initialized
DEBUG - 2017-12-16 20:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 20:09:16 --> Input Class Initialized
INFO - 2017-12-16 20:09:16 --> Language Class Initialized
INFO - 2017-12-16 20:09:16 --> Loader Class Initialized
INFO - 2017-12-16 20:09:16 --> Helper loaded: url_helper
INFO - 2017-12-16 20:09:16 --> Helper loaded: form_helper
INFO - 2017-12-16 20:09:16 --> Database Driver Class Initialized
DEBUG - 2017-12-16 20:09:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 20:09:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 20:09:16 --> Form Validation Class Initialized
INFO - 2017-12-16 20:09:16 --> Model Class Initialized
INFO - 2017-12-16 20:09:16 --> Controller Class Initialized
INFO - 2017-12-16 20:09:16 --> Model Class Initialized
INFO - 2017-12-16 20:09:16 --> Model Class Initialized
INFO - 2017-12-16 20:09:16 --> Model Class Initialized
DEBUG - 2017-12-16 20:09:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 20:09:16 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-16 20:09:16 --> Final output sent to browser
DEBUG - 2017-12-16 20:09:16 --> Total execution time: 0.0475
INFO - 2017-12-16 20:09:18 --> Config Class Initialized
INFO - 2017-12-16 20:09:18 --> Hooks Class Initialized
DEBUG - 2017-12-16 20:09:18 --> UTF-8 Support Enabled
INFO - 2017-12-16 20:09:18 --> Utf8 Class Initialized
INFO - 2017-12-16 20:09:18 --> URI Class Initialized
INFO - 2017-12-16 20:09:18 --> Router Class Initialized
INFO - 2017-12-16 20:09:18 --> Output Class Initialized
INFO - 2017-12-16 20:09:18 --> Security Class Initialized
DEBUG - 2017-12-16 20:09:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 20:09:18 --> Input Class Initialized
INFO - 2017-12-16 20:09:18 --> Language Class Initialized
INFO - 2017-12-16 20:09:18 --> Loader Class Initialized
INFO - 2017-12-16 20:09:18 --> Helper loaded: url_helper
INFO - 2017-12-16 20:09:18 --> Helper loaded: form_helper
INFO - 2017-12-16 20:09:18 --> Database Driver Class Initialized
DEBUG - 2017-12-16 20:09:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 20:09:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 20:09:18 --> Form Validation Class Initialized
INFO - 2017-12-16 20:09:18 --> Model Class Initialized
INFO - 2017-12-16 20:09:18 --> Controller Class Initialized
INFO - 2017-12-16 20:09:18 --> Model Class Initialized
INFO - 2017-12-16 20:09:18 --> Model Class Initialized
INFO - 2017-12-16 20:09:18 --> Model Class Initialized
DEBUG - 2017-12-16 20:09:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 20:09:18 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-16 20:09:18 --> Final output sent to browser
DEBUG - 2017-12-16 20:09:18 --> Total execution time: 0.0551
INFO - 2017-12-16 20:09:19 --> Config Class Initialized
INFO - 2017-12-16 20:09:19 --> Hooks Class Initialized
DEBUG - 2017-12-16 20:09:19 --> UTF-8 Support Enabled
INFO - 2017-12-16 20:09:19 --> Utf8 Class Initialized
INFO - 2017-12-16 20:09:19 --> URI Class Initialized
INFO - 2017-12-16 20:09:19 --> Router Class Initialized
INFO - 2017-12-16 20:09:19 --> Output Class Initialized
INFO - 2017-12-16 20:09:19 --> Security Class Initialized
DEBUG - 2017-12-16 20:09:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 20:09:19 --> Input Class Initialized
INFO - 2017-12-16 20:09:19 --> Language Class Initialized
INFO - 2017-12-16 20:09:19 --> Loader Class Initialized
INFO - 2017-12-16 20:09:19 --> Helper loaded: url_helper
INFO - 2017-12-16 20:09:19 --> Helper loaded: form_helper
INFO - 2017-12-16 20:09:19 --> Database Driver Class Initialized
DEBUG - 2017-12-16 20:09:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 20:09:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 20:09:19 --> Form Validation Class Initialized
INFO - 2017-12-16 20:09:19 --> Model Class Initialized
INFO - 2017-12-16 20:09:19 --> Controller Class Initialized
INFO - 2017-12-16 20:09:19 --> Model Class Initialized
INFO - 2017-12-16 20:09:19 --> Model Class Initialized
INFO - 2017-12-16 20:09:19 --> Model Class Initialized
DEBUG - 2017-12-16 20:09:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 20:09:19 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-16 20:09:19 --> Final output sent to browser
DEBUG - 2017-12-16 20:09:19 --> Total execution time: 0.0568
INFO - 2017-12-16 20:09:20 --> Config Class Initialized
INFO - 2017-12-16 20:09:20 --> Hooks Class Initialized
DEBUG - 2017-12-16 20:09:20 --> UTF-8 Support Enabled
INFO - 2017-12-16 20:09:20 --> Utf8 Class Initialized
INFO - 2017-12-16 20:09:20 --> URI Class Initialized
INFO - 2017-12-16 20:09:20 --> Router Class Initialized
INFO - 2017-12-16 20:09:20 --> Output Class Initialized
INFO - 2017-12-16 20:09:20 --> Security Class Initialized
DEBUG - 2017-12-16 20:09:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 20:09:20 --> Input Class Initialized
INFO - 2017-12-16 20:09:20 --> Language Class Initialized
INFO - 2017-12-16 20:09:20 --> Loader Class Initialized
INFO - 2017-12-16 20:09:20 --> Helper loaded: url_helper
INFO - 2017-12-16 20:09:20 --> Helper loaded: form_helper
INFO - 2017-12-16 20:09:20 --> Database Driver Class Initialized
DEBUG - 2017-12-16 20:09:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 20:09:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 20:09:20 --> Form Validation Class Initialized
INFO - 2017-12-16 20:09:20 --> Model Class Initialized
INFO - 2017-12-16 20:09:20 --> Controller Class Initialized
INFO - 2017-12-16 20:09:20 --> Model Class Initialized
INFO - 2017-12-16 20:09:20 --> Model Class Initialized
INFO - 2017-12-16 20:09:20 --> Model Class Initialized
DEBUG - 2017-12-16 20:09:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 20:09:20 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-16 20:09:20 --> Final output sent to browser
DEBUG - 2017-12-16 20:09:20 --> Total execution time: 0.0562
INFO - 2017-12-16 20:09:21 --> Config Class Initialized
INFO - 2017-12-16 20:09:21 --> Hooks Class Initialized
DEBUG - 2017-12-16 20:09:21 --> UTF-8 Support Enabled
INFO - 2017-12-16 20:09:21 --> Utf8 Class Initialized
INFO - 2017-12-16 20:09:21 --> URI Class Initialized
INFO - 2017-12-16 20:09:21 --> Router Class Initialized
INFO - 2017-12-16 20:09:21 --> Output Class Initialized
INFO - 2017-12-16 20:09:21 --> Security Class Initialized
DEBUG - 2017-12-16 20:09:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 20:09:21 --> Input Class Initialized
INFO - 2017-12-16 20:09:21 --> Language Class Initialized
INFO - 2017-12-16 20:09:21 --> Loader Class Initialized
INFO - 2017-12-16 20:09:21 --> Helper loaded: url_helper
INFO - 2017-12-16 20:09:21 --> Helper loaded: form_helper
INFO - 2017-12-16 20:09:21 --> Database Driver Class Initialized
DEBUG - 2017-12-16 20:09:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 20:09:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 20:09:21 --> Form Validation Class Initialized
INFO - 2017-12-16 20:09:21 --> Model Class Initialized
INFO - 2017-12-16 20:09:21 --> Controller Class Initialized
INFO - 2017-12-16 20:09:21 --> Model Class Initialized
INFO - 2017-12-16 20:09:21 --> Model Class Initialized
INFO - 2017-12-16 20:09:21 --> Model Class Initialized
DEBUG - 2017-12-16 20:09:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 20:09:21 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-16 20:09:21 --> Final output sent to browser
DEBUG - 2017-12-16 20:09:21 --> Total execution time: 0.0601
INFO - 2017-12-16 20:09:38 --> Config Class Initialized
INFO - 2017-12-16 20:09:38 --> Hooks Class Initialized
DEBUG - 2017-12-16 20:09:38 --> UTF-8 Support Enabled
INFO - 2017-12-16 20:09:38 --> Utf8 Class Initialized
INFO - 2017-12-16 20:09:38 --> URI Class Initialized
INFO - 2017-12-16 20:09:38 --> Router Class Initialized
INFO - 2017-12-16 20:09:38 --> Output Class Initialized
INFO - 2017-12-16 20:09:38 --> Security Class Initialized
DEBUG - 2017-12-16 20:09:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 20:09:38 --> Input Class Initialized
INFO - 2017-12-16 20:09:38 --> Language Class Initialized
INFO - 2017-12-16 20:09:38 --> Loader Class Initialized
INFO - 2017-12-16 20:09:38 --> Helper loaded: url_helper
INFO - 2017-12-16 20:09:38 --> Helper loaded: form_helper
INFO - 2017-12-16 20:09:38 --> Database Driver Class Initialized
DEBUG - 2017-12-16 20:09:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 20:09:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 20:09:38 --> Form Validation Class Initialized
INFO - 2017-12-16 20:09:38 --> Model Class Initialized
INFO - 2017-12-16 20:09:38 --> Controller Class Initialized
INFO - 2017-12-16 20:09:38 --> Model Class Initialized
INFO - 2017-12-16 20:09:38 --> Model Class Initialized
INFO - 2017-12-16 20:09:38 --> Model Class Initialized
DEBUG - 2017-12-16 20:09:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 20:09:38 --> Config Class Initialized
INFO - 2017-12-16 20:09:38 --> Hooks Class Initialized
DEBUG - 2017-12-16 20:09:38 --> UTF-8 Support Enabled
INFO - 2017-12-16 20:09:38 --> Utf8 Class Initialized
INFO - 2017-12-16 20:09:38 --> URI Class Initialized
INFO - 2017-12-16 20:09:38 --> Router Class Initialized
INFO - 2017-12-16 20:09:38 --> Output Class Initialized
INFO - 2017-12-16 20:09:38 --> Security Class Initialized
DEBUG - 2017-12-16 20:09:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 20:09:38 --> Input Class Initialized
INFO - 2017-12-16 20:09:38 --> Language Class Initialized
INFO - 2017-12-16 20:09:38 --> Loader Class Initialized
INFO - 2017-12-16 20:09:38 --> Helper loaded: url_helper
INFO - 2017-12-16 20:09:38 --> Helper loaded: form_helper
INFO - 2017-12-16 20:09:38 --> Database Driver Class Initialized
DEBUG - 2017-12-16 20:09:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 20:09:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 20:09:38 --> Form Validation Class Initialized
INFO - 2017-12-16 20:09:38 --> Model Class Initialized
INFO - 2017-12-16 20:09:38 --> Controller Class Initialized
INFO - 2017-12-16 20:09:38 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-16 20:09:38 --> Final output sent to browser
DEBUG - 2017-12-16 20:09:38 --> Total execution time: 0.0456
INFO - 2017-12-16 20:09:39 --> Config Class Initialized
INFO - 2017-12-16 20:09:39 --> Hooks Class Initialized
DEBUG - 2017-12-16 20:09:39 --> UTF-8 Support Enabled
INFO - 2017-12-16 20:09:39 --> Utf8 Class Initialized
INFO - 2017-12-16 20:09:39 --> URI Class Initialized
INFO - 2017-12-16 20:09:39 --> Router Class Initialized
INFO - 2017-12-16 20:09:39 --> Output Class Initialized
INFO - 2017-12-16 20:09:39 --> Security Class Initialized
DEBUG - 2017-12-16 20:09:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 20:09:39 --> Input Class Initialized
INFO - 2017-12-16 20:09:39 --> Language Class Initialized
INFO - 2017-12-16 20:09:39 --> Loader Class Initialized
INFO - 2017-12-16 20:09:39 --> Helper loaded: url_helper
INFO - 2017-12-16 20:09:39 --> Helper loaded: form_helper
INFO - 2017-12-16 20:09:39 --> Database Driver Class Initialized
DEBUG - 2017-12-16 20:09:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 20:09:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 20:09:39 --> Form Validation Class Initialized
INFO - 2017-12-16 20:09:39 --> Model Class Initialized
INFO - 2017-12-16 20:09:39 --> Controller Class Initialized
INFO - 2017-12-16 20:09:39 --> Model Class Initialized
INFO - 2017-12-16 20:09:39 --> Model Class Initialized
INFO - 2017-12-16 20:09:39 --> Model Class Initialized
DEBUG - 2017-12-16 20:09:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 20:09:39 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-16 20:09:39 --> Final output sent to browser
DEBUG - 2017-12-16 20:09:39 --> Total execution time: 0.0593
INFO - 2017-12-16 20:09:40 --> Config Class Initialized
INFO - 2017-12-16 20:09:40 --> Hooks Class Initialized
DEBUG - 2017-12-16 20:09:40 --> UTF-8 Support Enabled
INFO - 2017-12-16 20:09:40 --> Utf8 Class Initialized
INFO - 2017-12-16 20:09:40 --> URI Class Initialized
INFO - 2017-12-16 20:09:40 --> Router Class Initialized
INFO - 2017-12-16 20:09:40 --> Output Class Initialized
INFO - 2017-12-16 20:09:40 --> Security Class Initialized
DEBUG - 2017-12-16 20:09:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 20:09:40 --> Input Class Initialized
INFO - 2017-12-16 20:09:40 --> Language Class Initialized
INFO - 2017-12-16 20:09:40 --> Loader Class Initialized
INFO - 2017-12-16 20:09:40 --> Helper loaded: url_helper
INFO - 2017-12-16 20:09:40 --> Helper loaded: form_helper
INFO - 2017-12-16 20:09:40 --> Database Driver Class Initialized
DEBUG - 2017-12-16 20:09:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 20:09:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 20:09:40 --> Form Validation Class Initialized
INFO - 2017-12-16 20:09:40 --> Model Class Initialized
INFO - 2017-12-16 20:09:40 --> Controller Class Initialized
INFO - 2017-12-16 20:09:40 --> Model Class Initialized
INFO - 2017-12-16 20:09:40 --> Model Class Initialized
INFO - 2017-12-16 20:09:40 --> Model Class Initialized
DEBUG - 2017-12-16 20:09:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 20:09:40 --> Config Class Initialized
INFO - 2017-12-16 20:09:40 --> Hooks Class Initialized
DEBUG - 2017-12-16 20:09:40 --> UTF-8 Support Enabled
INFO - 2017-12-16 20:09:40 --> Utf8 Class Initialized
INFO - 2017-12-16 20:09:40 --> URI Class Initialized
INFO - 2017-12-16 20:09:40 --> Router Class Initialized
INFO - 2017-12-16 20:09:40 --> Output Class Initialized
INFO - 2017-12-16 20:09:40 --> Security Class Initialized
DEBUG - 2017-12-16 20:09:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 20:09:40 --> Input Class Initialized
INFO - 2017-12-16 20:09:40 --> Language Class Initialized
INFO - 2017-12-16 20:09:40 --> Loader Class Initialized
INFO - 2017-12-16 20:09:40 --> Helper loaded: url_helper
INFO - 2017-12-16 20:09:40 --> Helper loaded: form_helper
INFO - 2017-12-16 20:09:40 --> Database Driver Class Initialized
DEBUG - 2017-12-16 20:09:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 20:09:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 20:09:40 --> Form Validation Class Initialized
INFO - 2017-12-16 20:09:40 --> Model Class Initialized
INFO - 2017-12-16 20:09:40 --> Controller Class Initialized
INFO - 2017-12-16 20:09:40 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-16 20:09:40 --> Final output sent to browser
DEBUG - 2017-12-16 20:09:40 --> Total execution time: 0.0455
INFO - 2017-12-16 20:09:41 --> Config Class Initialized
INFO - 2017-12-16 20:09:41 --> Hooks Class Initialized
DEBUG - 2017-12-16 20:09:41 --> UTF-8 Support Enabled
INFO - 2017-12-16 20:09:41 --> Utf8 Class Initialized
INFO - 2017-12-16 20:09:41 --> URI Class Initialized
INFO - 2017-12-16 20:09:41 --> Router Class Initialized
INFO - 2017-12-16 20:09:41 --> Output Class Initialized
INFO - 2017-12-16 20:09:41 --> Security Class Initialized
DEBUG - 2017-12-16 20:09:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 20:09:41 --> Input Class Initialized
INFO - 2017-12-16 20:09:41 --> Language Class Initialized
INFO - 2017-12-16 20:09:41 --> Loader Class Initialized
INFO - 2017-12-16 20:09:41 --> Helper loaded: url_helper
INFO - 2017-12-16 20:09:41 --> Helper loaded: form_helper
INFO - 2017-12-16 20:09:41 --> Database Driver Class Initialized
DEBUG - 2017-12-16 20:09:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 20:09:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 20:09:41 --> Form Validation Class Initialized
INFO - 2017-12-16 20:09:41 --> Model Class Initialized
INFO - 2017-12-16 20:09:41 --> Controller Class Initialized
INFO - 2017-12-16 20:09:41 --> Model Class Initialized
INFO - 2017-12-16 20:09:41 --> Model Class Initialized
INFO - 2017-12-16 20:09:41 --> Model Class Initialized
DEBUG - 2017-12-16 20:09:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 20:09:41 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-16 20:09:41 --> Final output sent to browser
DEBUG - 2017-12-16 20:09:41 --> Total execution time: 0.0571
INFO - 2017-12-16 20:09:42 --> Config Class Initialized
INFO - 2017-12-16 20:09:42 --> Hooks Class Initialized
DEBUG - 2017-12-16 20:09:42 --> UTF-8 Support Enabled
INFO - 2017-12-16 20:09:42 --> Utf8 Class Initialized
INFO - 2017-12-16 20:09:42 --> URI Class Initialized
INFO - 2017-12-16 20:09:42 --> Router Class Initialized
INFO - 2017-12-16 20:09:42 --> Output Class Initialized
INFO - 2017-12-16 20:09:42 --> Security Class Initialized
DEBUG - 2017-12-16 20:09:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 20:09:42 --> Input Class Initialized
INFO - 2017-12-16 20:09:42 --> Language Class Initialized
INFO - 2017-12-16 20:09:42 --> Loader Class Initialized
INFO - 2017-12-16 20:09:42 --> Helper loaded: url_helper
INFO - 2017-12-16 20:09:42 --> Helper loaded: form_helper
INFO - 2017-12-16 20:09:42 --> Database Driver Class Initialized
DEBUG - 2017-12-16 20:09:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 20:09:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 20:09:42 --> Form Validation Class Initialized
INFO - 2017-12-16 20:09:42 --> Model Class Initialized
INFO - 2017-12-16 20:09:42 --> Controller Class Initialized
INFO - 2017-12-16 20:09:42 --> Model Class Initialized
INFO - 2017-12-16 20:09:42 --> Model Class Initialized
INFO - 2017-12-16 20:09:42 --> Model Class Initialized
DEBUG - 2017-12-16 20:09:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 20:09:42 --> Config Class Initialized
INFO - 2017-12-16 20:09:42 --> Hooks Class Initialized
DEBUG - 2017-12-16 20:09:42 --> UTF-8 Support Enabled
INFO - 2017-12-16 20:09:42 --> Utf8 Class Initialized
INFO - 2017-12-16 20:09:42 --> URI Class Initialized
INFO - 2017-12-16 20:09:42 --> Router Class Initialized
INFO - 2017-12-16 20:09:42 --> Output Class Initialized
INFO - 2017-12-16 20:09:42 --> Security Class Initialized
DEBUG - 2017-12-16 20:09:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 20:09:42 --> Input Class Initialized
INFO - 2017-12-16 20:09:42 --> Language Class Initialized
INFO - 2017-12-16 20:09:42 --> Loader Class Initialized
INFO - 2017-12-16 20:09:42 --> Helper loaded: url_helper
INFO - 2017-12-16 20:09:42 --> Helper loaded: form_helper
INFO - 2017-12-16 20:09:42 --> Database Driver Class Initialized
DEBUG - 2017-12-16 20:09:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 20:09:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 20:09:42 --> Form Validation Class Initialized
INFO - 2017-12-16 20:09:42 --> Model Class Initialized
INFO - 2017-12-16 20:09:42 --> Controller Class Initialized
INFO - 2017-12-16 20:09:42 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-16 20:09:42 --> Final output sent to browser
DEBUG - 2017-12-16 20:09:42 --> Total execution time: 0.0601
INFO - 2017-12-16 20:09:43 --> Config Class Initialized
INFO - 2017-12-16 20:09:43 --> Hooks Class Initialized
DEBUG - 2017-12-16 20:09:43 --> UTF-8 Support Enabled
INFO - 2017-12-16 20:09:43 --> Utf8 Class Initialized
INFO - 2017-12-16 20:09:43 --> URI Class Initialized
INFO - 2017-12-16 20:09:43 --> Router Class Initialized
INFO - 2017-12-16 20:09:43 --> Output Class Initialized
INFO - 2017-12-16 20:09:43 --> Security Class Initialized
DEBUG - 2017-12-16 20:09:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 20:09:43 --> Input Class Initialized
INFO - 2017-12-16 20:09:43 --> Language Class Initialized
INFO - 2017-12-16 20:09:43 --> Loader Class Initialized
INFO - 2017-12-16 20:09:43 --> Helper loaded: url_helper
INFO - 2017-12-16 20:09:43 --> Helper loaded: form_helper
INFO - 2017-12-16 20:09:43 --> Database Driver Class Initialized
DEBUG - 2017-12-16 20:09:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 20:09:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 20:09:43 --> Form Validation Class Initialized
INFO - 2017-12-16 20:09:43 --> Model Class Initialized
INFO - 2017-12-16 20:09:43 --> Controller Class Initialized
INFO - 2017-12-16 20:09:43 --> Model Class Initialized
INFO - 2017-12-16 20:09:43 --> Model Class Initialized
INFO - 2017-12-16 20:09:43 --> Model Class Initialized
DEBUG - 2017-12-16 20:09:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 20:09:43 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-16 20:09:43 --> Final output sent to browser
DEBUG - 2017-12-16 20:09:43 --> Total execution time: 0.0579
INFO - 2017-12-16 20:43:02 --> Config Class Initialized
INFO - 2017-12-16 20:43:02 --> Hooks Class Initialized
DEBUG - 2017-12-16 20:43:02 --> UTF-8 Support Enabled
INFO - 2017-12-16 20:43:02 --> Utf8 Class Initialized
INFO - 2017-12-16 20:43:02 --> URI Class Initialized
INFO - 2017-12-16 20:43:02 --> Router Class Initialized
INFO - 2017-12-16 20:43:02 --> Output Class Initialized
INFO - 2017-12-16 20:43:02 --> Security Class Initialized
DEBUG - 2017-12-16 20:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 20:43:02 --> Input Class Initialized
INFO - 2017-12-16 20:43:02 --> Language Class Initialized
INFO - 2017-12-16 20:43:02 --> Loader Class Initialized
INFO - 2017-12-16 20:43:02 --> Helper loaded: url_helper
INFO - 2017-12-16 20:43:02 --> Helper loaded: form_helper
INFO - 2017-12-16 20:43:02 --> Database Driver Class Initialized
DEBUG - 2017-12-16 20:43:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 20:43:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 20:43:03 --> Form Validation Class Initialized
INFO - 2017-12-16 20:43:03 --> Model Class Initialized
INFO - 2017-12-16 20:43:03 --> Controller Class Initialized
INFO - 2017-12-16 20:43:03 --> Model Class Initialized
INFO - 2017-12-16 20:43:03 --> Model Class Initialized
DEBUG - 2017-12-16 20:43:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 20:43:03 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-16 20:43:03 --> Final output sent to browser
DEBUG - 2017-12-16 20:43:03 --> Total execution time: 0.6410
INFO - 2017-12-16 20:43:03 --> Config Class Initialized
INFO - 2017-12-16 20:43:03 --> Hooks Class Initialized
DEBUG - 2017-12-16 20:43:03 --> UTF-8 Support Enabled
INFO - 2017-12-16 20:43:03 --> Utf8 Class Initialized
INFO - 2017-12-16 20:43:03 --> URI Class Initialized
INFO - 2017-12-16 20:43:03 --> Router Class Initialized
INFO - 2017-12-16 20:43:03 --> Output Class Initialized
INFO - 2017-12-16 20:43:03 --> Security Class Initialized
DEBUG - 2017-12-16 20:43:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 20:43:03 --> Input Class Initialized
INFO - 2017-12-16 20:43:03 --> Language Class Initialized
INFO - 2017-12-16 20:43:03 --> Loader Class Initialized
INFO - 2017-12-16 20:43:03 --> Helper loaded: url_helper
INFO - 2017-12-16 20:43:03 --> Helper loaded: form_helper
INFO - 2017-12-16 20:43:03 --> Database Driver Class Initialized
DEBUG - 2017-12-16 20:43:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 20:43:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 20:43:03 --> Form Validation Class Initialized
INFO - 2017-12-16 20:43:03 --> Model Class Initialized
INFO - 2017-12-16 20:43:03 --> Controller Class Initialized
INFO - 2017-12-16 20:43:03 --> Model Class Initialized
INFO - 2017-12-16 20:43:03 --> Model Class Initialized
DEBUG - 2017-12-16 20:43:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 20:43:06 --> Config Class Initialized
INFO - 2017-12-16 20:43:06 --> Hooks Class Initialized
DEBUG - 2017-12-16 20:43:06 --> UTF-8 Support Enabled
INFO - 2017-12-16 20:43:06 --> Utf8 Class Initialized
INFO - 2017-12-16 20:43:06 --> URI Class Initialized
INFO - 2017-12-16 20:43:06 --> Router Class Initialized
INFO - 2017-12-16 20:43:06 --> Output Class Initialized
INFO - 2017-12-16 20:43:06 --> Security Class Initialized
DEBUG - 2017-12-16 20:43:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 20:43:06 --> Input Class Initialized
INFO - 2017-12-16 20:43:06 --> Language Class Initialized
ERROR - 2017-12-16 20:43:06 --> 404 Page Not Found: Reportes/index
INFO - 2017-12-16 20:43:07 --> Config Class Initialized
INFO - 2017-12-16 20:43:07 --> Hooks Class Initialized
DEBUG - 2017-12-16 20:43:07 --> UTF-8 Support Enabled
INFO - 2017-12-16 20:43:07 --> Utf8 Class Initialized
INFO - 2017-12-16 20:43:07 --> URI Class Initialized
INFO - 2017-12-16 20:43:07 --> Router Class Initialized
INFO - 2017-12-16 20:43:07 --> Output Class Initialized
INFO - 2017-12-16 20:43:07 --> Security Class Initialized
DEBUG - 2017-12-16 20:43:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 20:43:07 --> Input Class Initialized
INFO - 2017-12-16 20:43:07 --> Language Class Initialized
INFO - 2017-12-16 20:43:07 --> Loader Class Initialized
INFO - 2017-12-16 20:43:07 --> Helper loaded: url_helper
INFO - 2017-12-16 20:43:07 --> Helper loaded: form_helper
INFO - 2017-12-16 20:43:07 --> Database Driver Class Initialized
DEBUG - 2017-12-16 20:43:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 20:43:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 20:43:07 --> Form Validation Class Initialized
INFO - 2017-12-16 20:43:07 --> Model Class Initialized
INFO - 2017-12-16 20:43:07 --> Controller Class Initialized
INFO - 2017-12-16 20:43:07 --> Model Class Initialized
INFO - 2017-12-16 20:43:07 --> Model Class Initialized
DEBUG - 2017-12-16 20:43:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 20:43:07 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-16 20:43:07 --> Final output sent to browser
DEBUG - 2017-12-16 20:43:07 --> Total execution time: 0.0469
INFO - 2017-12-16 20:43:07 --> Config Class Initialized
INFO - 2017-12-16 20:43:07 --> Hooks Class Initialized
DEBUG - 2017-12-16 20:43:07 --> UTF-8 Support Enabled
INFO - 2017-12-16 20:43:07 --> Utf8 Class Initialized
INFO - 2017-12-16 20:43:07 --> URI Class Initialized
INFO - 2017-12-16 20:43:07 --> Router Class Initialized
INFO - 2017-12-16 20:43:07 --> Output Class Initialized
INFO - 2017-12-16 20:43:07 --> Security Class Initialized
DEBUG - 2017-12-16 20:43:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 20:43:07 --> Input Class Initialized
INFO - 2017-12-16 20:43:07 --> Language Class Initialized
INFO - 2017-12-16 20:43:07 --> Loader Class Initialized
INFO - 2017-12-16 20:43:07 --> Helper loaded: url_helper
INFO - 2017-12-16 20:43:07 --> Helper loaded: form_helper
INFO - 2017-12-16 20:43:07 --> Database Driver Class Initialized
DEBUG - 2017-12-16 20:43:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 20:43:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 20:43:07 --> Form Validation Class Initialized
INFO - 2017-12-16 20:43:07 --> Model Class Initialized
INFO - 2017-12-16 20:43:07 --> Controller Class Initialized
INFO - 2017-12-16 20:43:07 --> Model Class Initialized
INFO - 2017-12-16 20:43:07 --> Model Class Initialized
DEBUG - 2017-12-16 20:43:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 20:43:07 --> Config Class Initialized
INFO - 2017-12-16 20:43:07 --> Hooks Class Initialized
DEBUG - 2017-12-16 20:43:07 --> UTF-8 Support Enabled
INFO - 2017-12-16 20:43:07 --> Utf8 Class Initialized
INFO - 2017-12-16 20:43:07 --> URI Class Initialized
INFO - 2017-12-16 20:43:07 --> Router Class Initialized
INFO - 2017-12-16 20:43:07 --> Output Class Initialized
INFO - 2017-12-16 20:43:07 --> Security Class Initialized
DEBUG - 2017-12-16 20:43:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 20:43:07 --> Input Class Initialized
INFO - 2017-12-16 20:43:07 --> Language Class Initialized
INFO - 2017-12-16 20:43:08 --> Loader Class Initialized
INFO - 2017-12-16 20:43:08 --> Helper loaded: url_helper
INFO - 2017-12-16 20:43:08 --> Helper loaded: form_helper
INFO - 2017-12-16 20:43:08 --> Database Driver Class Initialized
DEBUG - 2017-12-16 20:43:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 20:43:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 20:43:08 --> Form Validation Class Initialized
INFO - 2017-12-16 20:43:08 --> Model Class Initialized
INFO - 2017-12-16 20:43:08 --> Controller Class Initialized
INFO - 2017-12-16 20:43:08 --> Model Class Initialized
INFO - 2017-12-16 20:43:08 --> Model Class Initialized
DEBUG - 2017-12-16 20:43:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 20:43:08 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-16 20:43:08 --> Final output sent to browser
DEBUG - 2017-12-16 20:43:08 --> Total execution time: 0.1639
INFO - 2017-12-16 20:43:08 --> Config Class Initialized
INFO - 2017-12-16 20:43:08 --> Hooks Class Initialized
DEBUG - 2017-12-16 20:43:08 --> UTF-8 Support Enabled
INFO - 2017-12-16 20:43:08 --> Utf8 Class Initialized
INFO - 2017-12-16 20:43:08 --> URI Class Initialized
INFO - 2017-12-16 20:43:08 --> Router Class Initialized
INFO - 2017-12-16 20:43:08 --> Output Class Initialized
INFO - 2017-12-16 20:43:08 --> Security Class Initialized
DEBUG - 2017-12-16 20:43:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 20:43:08 --> Input Class Initialized
INFO - 2017-12-16 20:43:08 --> Language Class Initialized
INFO - 2017-12-16 20:43:08 --> Loader Class Initialized
INFO - 2017-12-16 20:43:08 --> Helper loaded: url_helper
INFO - 2017-12-16 20:43:08 --> Helper loaded: form_helper
INFO - 2017-12-16 20:43:08 --> Database Driver Class Initialized
DEBUG - 2017-12-16 20:43:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 20:43:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 20:43:08 --> Form Validation Class Initialized
INFO - 2017-12-16 20:43:08 --> Model Class Initialized
INFO - 2017-12-16 20:43:08 --> Controller Class Initialized
INFO - 2017-12-16 20:43:08 --> Model Class Initialized
INFO - 2017-12-16 20:43:08 --> Model Class Initialized
DEBUG - 2017-12-16 20:43:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 20:43:08 --> Config Class Initialized
INFO - 2017-12-16 20:43:08 --> Hooks Class Initialized
DEBUG - 2017-12-16 20:43:08 --> UTF-8 Support Enabled
INFO - 2017-12-16 20:43:08 --> Utf8 Class Initialized
INFO - 2017-12-16 20:43:08 --> URI Class Initialized
INFO - 2017-12-16 20:43:08 --> Router Class Initialized
INFO - 2017-12-16 20:43:08 --> Output Class Initialized
INFO - 2017-12-16 20:43:08 --> Security Class Initialized
DEBUG - 2017-12-16 20:43:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 20:43:08 --> Input Class Initialized
INFO - 2017-12-16 20:43:08 --> Language Class Initialized
INFO - 2017-12-16 20:43:08 --> Loader Class Initialized
INFO - 2017-12-16 20:43:08 --> Helper loaded: url_helper
INFO - 2017-12-16 20:43:08 --> Helper loaded: form_helper
INFO - 2017-12-16 20:43:08 --> Database Driver Class Initialized
DEBUG - 2017-12-16 20:43:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 20:43:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 20:43:08 --> Form Validation Class Initialized
INFO - 2017-12-16 20:43:08 --> Model Class Initialized
INFO - 2017-12-16 20:43:08 --> Controller Class Initialized
INFO - 2017-12-16 20:43:08 --> Model Class Initialized
INFO - 2017-12-16 20:43:08 --> Model Class Initialized
DEBUG - 2017-12-16 20:43:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 20:43:08 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-16 20:43:08 --> Final output sent to browser
DEBUG - 2017-12-16 20:43:08 --> Total execution time: 0.0486
INFO - 2017-12-16 20:43:08 --> Config Class Initialized
INFO - 2017-12-16 20:43:08 --> Hooks Class Initialized
DEBUG - 2017-12-16 20:43:08 --> UTF-8 Support Enabled
INFO - 2017-12-16 20:43:08 --> Utf8 Class Initialized
INFO - 2017-12-16 20:43:08 --> URI Class Initialized
INFO - 2017-12-16 20:43:08 --> Router Class Initialized
INFO - 2017-12-16 20:43:08 --> Output Class Initialized
INFO - 2017-12-16 20:43:08 --> Security Class Initialized
DEBUG - 2017-12-16 20:43:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 20:43:08 --> Input Class Initialized
INFO - 2017-12-16 20:43:08 --> Language Class Initialized
INFO - 2017-12-16 20:43:08 --> Loader Class Initialized
INFO - 2017-12-16 20:43:08 --> Helper loaded: url_helper
INFO - 2017-12-16 20:43:08 --> Helper loaded: form_helper
INFO - 2017-12-16 20:43:08 --> Database Driver Class Initialized
DEBUG - 2017-12-16 20:43:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 20:43:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 20:43:08 --> Form Validation Class Initialized
INFO - 2017-12-16 20:43:08 --> Model Class Initialized
INFO - 2017-12-16 20:43:08 --> Controller Class Initialized
INFO - 2017-12-16 20:43:08 --> Model Class Initialized
INFO - 2017-12-16 20:43:08 --> Model Class Initialized
DEBUG - 2017-12-16 20:43:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 20:43:14 --> Config Class Initialized
INFO - 2017-12-16 20:43:14 --> Hooks Class Initialized
DEBUG - 2017-12-16 20:43:14 --> UTF-8 Support Enabled
INFO - 2017-12-16 20:43:14 --> Utf8 Class Initialized
INFO - 2017-12-16 20:43:14 --> URI Class Initialized
INFO - 2017-12-16 20:43:14 --> Router Class Initialized
INFO - 2017-12-16 20:43:14 --> Output Class Initialized
INFO - 2017-12-16 20:43:14 --> Security Class Initialized
DEBUG - 2017-12-16 20:43:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 20:43:14 --> Input Class Initialized
INFO - 2017-12-16 20:43:14 --> Language Class Initialized
INFO - 2017-12-16 20:43:14 --> Loader Class Initialized
INFO - 2017-12-16 20:43:14 --> Helper loaded: url_helper
INFO - 2017-12-16 20:43:14 --> Helper loaded: form_helper
INFO - 2017-12-16 20:43:14 --> Database Driver Class Initialized
DEBUG - 2017-12-16 20:43:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 20:43:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 20:43:14 --> Form Validation Class Initialized
INFO - 2017-12-16 20:43:14 --> Model Class Initialized
INFO - 2017-12-16 20:43:14 --> Controller Class Initialized
INFO - 2017-12-16 20:43:14 --> Model Class Initialized
INFO - 2017-12-16 20:43:14 --> Model Class Initialized
DEBUG - 2017-12-16 20:43:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 20:43:14 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-16 20:43:14 --> Final output sent to browser
DEBUG - 2017-12-16 20:43:14 --> Total execution time: 0.0473
INFO - 2017-12-16 20:43:14 --> Config Class Initialized
INFO - 2017-12-16 20:43:14 --> Hooks Class Initialized
DEBUG - 2017-12-16 20:43:14 --> UTF-8 Support Enabled
INFO - 2017-12-16 20:43:14 --> Utf8 Class Initialized
INFO - 2017-12-16 20:43:14 --> URI Class Initialized
INFO - 2017-12-16 20:43:14 --> Router Class Initialized
INFO - 2017-12-16 20:43:14 --> Output Class Initialized
INFO - 2017-12-16 20:43:14 --> Security Class Initialized
DEBUG - 2017-12-16 20:43:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 20:43:14 --> Input Class Initialized
INFO - 2017-12-16 20:43:14 --> Language Class Initialized
INFO - 2017-12-16 20:43:14 --> Loader Class Initialized
INFO - 2017-12-16 20:43:14 --> Helper loaded: url_helper
INFO - 2017-12-16 20:43:14 --> Helper loaded: form_helper
INFO - 2017-12-16 20:43:14 --> Database Driver Class Initialized
DEBUG - 2017-12-16 20:43:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 20:43:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 20:43:14 --> Form Validation Class Initialized
INFO - 2017-12-16 20:43:14 --> Model Class Initialized
INFO - 2017-12-16 20:43:14 --> Controller Class Initialized
INFO - 2017-12-16 20:43:14 --> Model Class Initialized
INFO - 2017-12-16 20:43:14 --> Model Class Initialized
DEBUG - 2017-12-16 20:43:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 20:43:16 --> Config Class Initialized
INFO - 2017-12-16 20:43:16 --> Hooks Class Initialized
DEBUG - 2017-12-16 20:43:16 --> UTF-8 Support Enabled
INFO - 2017-12-16 20:43:16 --> Utf8 Class Initialized
INFO - 2017-12-16 20:43:16 --> URI Class Initialized
INFO - 2017-12-16 20:43:16 --> Router Class Initialized
INFO - 2017-12-16 20:43:16 --> Output Class Initialized
INFO - 2017-12-16 20:43:16 --> Security Class Initialized
DEBUG - 2017-12-16 20:43:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 20:43:16 --> Input Class Initialized
INFO - 2017-12-16 20:43:16 --> Language Class Initialized
INFO - 2017-12-16 20:43:16 --> Loader Class Initialized
INFO - 2017-12-16 20:43:16 --> Helper loaded: url_helper
INFO - 2017-12-16 20:43:16 --> Helper loaded: form_helper
INFO - 2017-12-16 20:43:16 --> Database Driver Class Initialized
DEBUG - 2017-12-16 20:43:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 20:43:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 20:43:16 --> Form Validation Class Initialized
INFO - 2017-12-16 20:43:16 --> Model Class Initialized
INFO - 2017-12-16 20:43:16 --> Controller Class Initialized
INFO - 2017-12-16 20:43:16 --> Model Class Initialized
INFO - 2017-12-16 20:43:16 --> Model Class Initialized
DEBUG - 2017-12-16 20:43:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 20:43:16 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-16 20:43:16 --> Final output sent to browser
DEBUG - 2017-12-16 20:43:16 --> Total execution time: 0.0942
INFO - 2017-12-16 20:43:17 --> Config Class Initialized
INFO - 2017-12-16 20:43:17 --> Hooks Class Initialized
DEBUG - 2017-12-16 20:43:17 --> UTF-8 Support Enabled
INFO - 2017-12-16 20:43:17 --> Utf8 Class Initialized
INFO - 2017-12-16 20:43:17 --> URI Class Initialized
INFO - 2017-12-16 20:43:17 --> Router Class Initialized
INFO - 2017-12-16 20:43:17 --> Output Class Initialized
INFO - 2017-12-16 20:43:17 --> Security Class Initialized
DEBUG - 2017-12-16 20:43:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 20:43:17 --> Input Class Initialized
INFO - 2017-12-16 20:43:17 --> Language Class Initialized
INFO - 2017-12-16 20:43:17 --> Loader Class Initialized
INFO - 2017-12-16 20:43:17 --> Helper loaded: url_helper
INFO - 2017-12-16 20:43:17 --> Helper loaded: form_helper
INFO - 2017-12-16 20:43:17 --> Database Driver Class Initialized
DEBUG - 2017-12-16 20:43:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 20:43:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 20:43:17 --> Form Validation Class Initialized
INFO - 2017-12-16 20:43:17 --> Model Class Initialized
INFO - 2017-12-16 20:43:17 --> Controller Class Initialized
INFO - 2017-12-16 20:43:17 --> Model Class Initialized
INFO - 2017-12-16 20:43:17 --> Model Class Initialized
DEBUG - 2017-12-16 20:43:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 20:43:17 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-16 20:43:17 --> Final output sent to browser
DEBUG - 2017-12-16 20:43:17 --> Total execution time: 0.0467
INFO - 2017-12-16 20:43:17 --> Config Class Initialized
INFO - 2017-12-16 20:43:17 --> Hooks Class Initialized
DEBUG - 2017-12-16 20:43:17 --> UTF-8 Support Enabled
INFO - 2017-12-16 20:43:17 --> Utf8 Class Initialized
INFO - 2017-12-16 20:43:17 --> URI Class Initialized
INFO - 2017-12-16 20:43:17 --> Router Class Initialized
INFO - 2017-12-16 20:43:17 --> Output Class Initialized
INFO - 2017-12-16 20:43:17 --> Security Class Initialized
DEBUG - 2017-12-16 20:43:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 20:43:17 --> Input Class Initialized
INFO - 2017-12-16 20:43:17 --> Language Class Initialized
INFO - 2017-12-16 20:43:17 --> Loader Class Initialized
INFO - 2017-12-16 20:43:17 --> Helper loaded: url_helper
INFO - 2017-12-16 20:43:17 --> Helper loaded: form_helper
INFO - 2017-12-16 20:43:17 --> Database Driver Class Initialized
DEBUG - 2017-12-16 20:43:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 20:43:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 20:43:17 --> Form Validation Class Initialized
INFO - 2017-12-16 20:43:17 --> Model Class Initialized
INFO - 2017-12-16 20:43:17 --> Controller Class Initialized
INFO - 2017-12-16 20:43:17 --> Model Class Initialized
INFO - 2017-12-16 20:43:17 --> Model Class Initialized
DEBUG - 2017-12-16 20:43:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 20:43:18 --> Config Class Initialized
INFO - 2017-12-16 20:43:18 --> Hooks Class Initialized
DEBUG - 2017-12-16 20:43:18 --> UTF-8 Support Enabled
INFO - 2017-12-16 20:43:18 --> Utf8 Class Initialized
INFO - 2017-12-16 20:43:18 --> URI Class Initialized
INFO - 2017-12-16 20:43:18 --> Router Class Initialized
INFO - 2017-12-16 20:43:18 --> Output Class Initialized
INFO - 2017-12-16 20:43:18 --> Security Class Initialized
DEBUG - 2017-12-16 20:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 20:43:18 --> Input Class Initialized
INFO - 2017-12-16 20:43:18 --> Language Class Initialized
INFO - 2017-12-16 20:43:18 --> Loader Class Initialized
INFO - 2017-12-16 20:43:18 --> Helper loaded: url_helper
INFO - 2017-12-16 20:43:18 --> Helper loaded: form_helper
INFO - 2017-12-16 20:43:18 --> Database Driver Class Initialized
DEBUG - 2017-12-16 20:43:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 20:43:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 20:43:18 --> Form Validation Class Initialized
INFO - 2017-12-16 20:43:18 --> Model Class Initialized
INFO - 2017-12-16 20:43:18 --> Controller Class Initialized
INFO - 2017-12-16 20:43:18 --> Model Class Initialized
INFO - 2017-12-16 20:43:18 --> Model Class Initialized
DEBUG - 2017-12-16 20:43:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 20:43:18 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-16 20:43:18 --> Final output sent to browser
DEBUG - 2017-12-16 20:43:18 --> Total execution time: 0.0670
INFO - 2017-12-16 20:43:20 --> Config Class Initialized
INFO - 2017-12-16 20:43:20 --> Hooks Class Initialized
DEBUG - 2017-12-16 20:43:20 --> UTF-8 Support Enabled
INFO - 2017-12-16 20:43:20 --> Utf8 Class Initialized
INFO - 2017-12-16 20:43:20 --> URI Class Initialized
INFO - 2017-12-16 20:43:20 --> Router Class Initialized
INFO - 2017-12-16 20:43:20 --> Output Class Initialized
INFO - 2017-12-16 20:43:20 --> Security Class Initialized
DEBUG - 2017-12-16 20:43:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 20:43:20 --> Input Class Initialized
INFO - 2017-12-16 20:43:20 --> Language Class Initialized
INFO - 2017-12-16 20:43:20 --> Loader Class Initialized
INFO - 2017-12-16 20:43:20 --> Helper loaded: url_helper
INFO - 2017-12-16 20:43:20 --> Helper loaded: form_helper
INFO - 2017-12-16 20:43:20 --> Database Driver Class Initialized
DEBUG - 2017-12-16 20:43:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 20:43:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 20:43:20 --> Form Validation Class Initialized
INFO - 2017-12-16 20:43:20 --> Model Class Initialized
INFO - 2017-12-16 20:43:20 --> Controller Class Initialized
INFO - 2017-12-16 20:43:20 --> Model Class Initialized
INFO - 2017-12-16 20:43:20 --> Model Class Initialized
DEBUG - 2017-12-16 20:43:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 20:43:20 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-16 20:43:20 --> Final output sent to browser
DEBUG - 2017-12-16 20:43:20 --> Total execution time: 0.0491
INFO - 2017-12-16 20:43:23 --> Config Class Initialized
INFO - 2017-12-16 20:43:23 --> Hooks Class Initialized
DEBUG - 2017-12-16 20:43:23 --> UTF-8 Support Enabled
INFO - 2017-12-16 20:43:23 --> Utf8 Class Initialized
INFO - 2017-12-16 20:43:23 --> URI Class Initialized
INFO - 2017-12-16 20:43:23 --> Router Class Initialized
INFO - 2017-12-16 20:43:23 --> Output Class Initialized
INFO - 2017-12-16 20:43:23 --> Security Class Initialized
DEBUG - 2017-12-16 20:43:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 20:43:23 --> Input Class Initialized
INFO - 2017-12-16 20:43:23 --> Language Class Initialized
INFO - 2017-12-16 20:43:23 --> Loader Class Initialized
INFO - 2017-12-16 20:43:23 --> Helper loaded: url_helper
INFO - 2017-12-16 20:43:23 --> Helper loaded: form_helper
INFO - 2017-12-16 20:43:23 --> Database Driver Class Initialized
DEBUG - 2017-12-16 20:43:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 20:43:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 20:43:23 --> Form Validation Class Initialized
INFO - 2017-12-16 20:43:23 --> Model Class Initialized
INFO - 2017-12-16 20:43:23 --> Controller Class Initialized
INFO - 2017-12-16 20:43:23 --> Model Class Initialized
INFO - 2017-12-16 20:43:23 --> Model Class Initialized
DEBUG - 2017-12-16 20:43:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 20:43:23 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-16 20:43:23 --> Final output sent to browser
DEBUG - 2017-12-16 20:43:23 --> Total execution time: 0.0371
INFO - 2017-12-16 20:43:23 --> Config Class Initialized
INFO - 2017-12-16 20:43:23 --> Hooks Class Initialized
DEBUG - 2017-12-16 20:43:23 --> UTF-8 Support Enabled
INFO - 2017-12-16 20:43:23 --> Utf8 Class Initialized
INFO - 2017-12-16 20:43:23 --> URI Class Initialized
INFO - 2017-12-16 20:43:23 --> Router Class Initialized
INFO - 2017-12-16 20:43:23 --> Output Class Initialized
INFO - 2017-12-16 20:43:23 --> Security Class Initialized
DEBUG - 2017-12-16 20:43:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 20:43:23 --> Input Class Initialized
INFO - 2017-12-16 20:43:23 --> Language Class Initialized
INFO - 2017-12-16 20:43:23 --> Loader Class Initialized
INFO - 2017-12-16 20:43:23 --> Helper loaded: url_helper
INFO - 2017-12-16 20:43:23 --> Helper loaded: form_helper
INFO - 2017-12-16 20:43:23 --> Database Driver Class Initialized
DEBUG - 2017-12-16 20:43:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 20:43:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 20:43:23 --> Form Validation Class Initialized
INFO - 2017-12-16 20:43:23 --> Model Class Initialized
INFO - 2017-12-16 20:43:23 --> Controller Class Initialized
INFO - 2017-12-16 20:43:23 --> Model Class Initialized
INFO - 2017-12-16 20:43:23 --> Model Class Initialized
DEBUG - 2017-12-16 20:43:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 20:43:25 --> Config Class Initialized
INFO - 2017-12-16 20:43:25 --> Hooks Class Initialized
DEBUG - 2017-12-16 20:43:25 --> UTF-8 Support Enabled
INFO - 2017-12-16 20:43:25 --> Utf8 Class Initialized
INFO - 2017-12-16 20:43:25 --> URI Class Initialized
INFO - 2017-12-16 20:43:25 --> Router Class Initialized
INFO - 2017-12-16 20:43:25 --> Output Class Initialized
INFO - 2017-12-16 20:43:25 --> Security Class Initialized
DEBUG - 2017-12-16 20:43:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 20:43:25 --> Input Class Initialized
INFO - 2017-12-16 20:43:25 --> Language Class Initialized
INFO - 2017-12-16 20:43:25 --> Loader Class Initialized
INFO - 2017-12-16 20:43:25 --> Helper loaded: url_helper
INFO - 2017-12-16 20:43:25 --> Helper loaded: form_helper
INFO - 2017-12-16 20:43:25 --> Database Driver Class Initialized
DEBUG - 2017-12-16 20:43:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 20:43:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 20:43:25 --> Form Validation Class Initialized
INFO - 2017-12-16 20:43:25 --> Model Class Initialized
INFO - 2017-12-16 20:43:25 --> Controller Class Initialized
INFO - 2017-12-16 20:43:25 --> Model Class Initialized
INFO - 2017-12-16 20:43:25 --> Model Class Initialized
DEBUG - 2017-12-16 20:43:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 20:43:25 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-16 20:43:25 --> Final output sent to browser
DEBUG - 2017-12-16 20:43:25 --> Total execution time: 0.0748
INFO - 2017-12-16 20:43:28 --> Config Class Initialized
INFO - 2017-12-16 20:43:28 --> Hooks Class Initialized
DEBUG - 2017-12-16 20:43:28 --> UTF-8 Support Enabled
INFO - 2017-12-16 20:43:28 --> Utf8 Class Initialized
INFO - 2017-12-16 20:43:28 --> URI Class Initialized
INFO - 2017-12-16 20:43:28 --> Router Class Initialized
INFO - 2017-12-16 20:43:28 --> Output Class Initialized
INFO - 2017-12-16 20:43:28 --> Security Class Initialized
DEBUG - 2017-12-16 20:43:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 20:43:28 --> Input Class Initialized
INFO - 2017-12-16 20:43:28 --> Language Class Initialized
INFO - 2017-12-16 20:43:28 --> Loader Class Initialized
INFO - 2017-12-16 20:43:28 --> Helper loaded: url_helper
INFO - 2017-12-16 20:43:28 --> Helper loaded: form_helper
INFO - 2017-12-16 20:43:28 --> Database Driver Class Initialized
DEBUG - 2017-12-16 20:43:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 20:43:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 20:43:28 --> Form Validation Class Initialized
INFO - 2017-12-16 20:43:28 --> Model Class Initialized
INFO - 2017-12-16 20:43:28 --> Controller Class Initialized
INFO - 2017-12-16 20:43:28 --> Model Class Initialized
INFO - 2017-12-16 20:43:28 --> Model Class Initialized
DEBUG - 2017-12-16 20:43:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 20:43:28 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-16 20:43:28 --> Final output sent to browser
DEBUG - 2017-12-16 20:43:28 --> Total execution time: 0.0460
INFO - 2017-12-16 20:43:28 --> Config Class Initialized
INFO - 2017-12-16 20:43:28 --> Hooks Class Initialized
DEBUG - 2017-12-16 20:43:28 --> UTF-8 Support Enabled
INFO - 2017-12-16 20:43:28 --> Utf8 Class Initialized
INFO - 2017-12-16 20:43:28 --> URI Class Initialized
INFO - 2017-12-16 20:43:28 --> Router Class Initialized
INFO - 2017-12-16 20:43:28 --> Output Class Initialized
INFO - 2017-12-16 20:43:28 --> Security Class Initialized
DEBUG - 2017-12-16 20:43:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 20:43:28 --> Input Class Initialized
INFO - 2017-12-16 20:43:28 --> Language Class Initialized
INFO - 2017-12-16 20:43:28 --> Loader Class Initialized
INFO - 2017-12-16 20:43:28 --> Helper loaded: url_helper
INFO - 2017-12-16 20:43:28 --> Helper loaded: form_helper
INFO - 2017-12-16 20:43:28 --> Database Driver Class Initialized
DEBUG - 2017-12-16 20:43:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 20:43:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 20:43:28 --> Form Validation Class Initialized
INFO - 2017-12-16 20:43:28 --> Model Class Initialized
INFO - 2017-12-16 20:43:28 --> Controller Class Initialized
INFO - 2017-12-16 20:43:28 --> Model Class Initialized
INFO - 2017-12-16 20:43:28 --> Model Class Initialized
DEBUG - 2017-12-16 20:43:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 20:43:33 --> Config Class Initialized
INFO - 2017-12-16 20:43:33 --> Hooks Class Initialized
DEBUG - 2017-12-16 20:43:33 --> UTF-8 Support Enabled
INFO - 2017-12-16 20:43:33 --> Utf8 Class Initialized
INFO - 2017-12-16 20:43:33 --> URI Class Initialized
INFO - 2017-12-16 20:43:33 --> Router Class Initialized
INFO - 2017-12-16 20:43:33 --> Output Class Initialized
INFO - 2017-12-16 20:43:33 --> Security Class Initialized
DEBUG - 2017-12-16 20:43:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 20:43:33 --> Input Class Initialized
INFO - 2017-12-16 20:43:33 --> Language Class Initialized
INFO - 2017-12-16 20:43:33 --> Loader Class Initialized
INFO - 2017-12-16 20:43:33 --> Helper loaded: url_helper
INFO - 2017-12-16 20:43:33 --> Helper loaded: form_helper
INFO - 2017-12-16 20:43:33 --> Database Driver Class Initialized
DEBUG - 2017-12-16 20:43:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 20:43:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 20:43:33 --> Form Validation Class Initialized
INFO - 2017-12-16 20:43:33 --> Model Class Initialized
INFO - 2017-12-16 20:43:33 --> Controller Class Initialized
INFO - 2017-12-16 20:43:33 --> Model Class Initialized
INFO - 2017-12-16 20:43:33 --> Model Class Initialized
INFO - 2017-12-16 20:43:33 --> Model Class Initialized
DEBUG - 2017-12-16 20:43:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 20:43:33 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-16 20:43:33 --> Final output sent to browser
DEBUG - 2017-12-16 20:43:33 --> Total execution time: 0.1221
INFO - 2017-12-16 20:43:36 --> Config Class Initialized
INFO - 2017-12-16 20:43:36 --> Hooks Class Initialized
DEBUG - 2017-12-16 20:43:36 --> UTF-8 Support Enabled
INFO - 2017-12-16 20:43:36 --> Utf8 Class Initialized
INFO - 2017-12-16 20:43:36 --> URI Class Initialized
INFO - 2017-12-16 20:43:36 --> Router Class Initialized
INFO - 2017-12-16 20:43:36 --> Output Class Initialized
INFO - 2017-12-16 20:43:36 --> Security Class Initialized
DEBUG - 2017-12-16 20:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 20:43:36 --> Input Class Initialized
INFO - 2017-12-16 20:43:36 --> Language Class Initialized
INFO - 2017-12-16 20:43:36 --> Loader Class Initialized
INFO - 2017-12-16 20:43:36 --> Helper loaded: url_helper
INFO - 2017-12-16 20:43:36 --> Helper loaded: form_helper
INFO - 2017-12-16 20:43:36 --> Database Driver Class Initialized
DEBUG - 2017-12-16 20:43:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 20:43:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 20:43:36 --> Form Validation Class Initialized
INFO - 2017-12-16 20:43:36 --> Model Class Initialized
INFO - 2017-12-16 20:43:36 --> Controller Class Initialized
INFO - 2017-12-16 20:43:36 --> Model Class Initialized
INFO - 2017-12-16 20:43:36 --> Model Class Initialized
INFO - 2017-12-16 20:43:36 --> Model Class Initialized
DEBUG - 2017-12-16 20:43:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 20:43:36 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-16 20:43:36 --> Final output sent to browser
DEBUG - 2017-12-16 20:43:36 --> Total execution time: 0.1106
INFO - 2017-12-16 20:43:44 --> Config Class Initialized
INFO - 2017-12-16 20:43:44 --> Hooks Class Initialized
DEBUG - 2017-12-16 20:43:44 --> UTF-8 Support Enabled
INFO - 2017-12-16 20:43:44 --> Utf8 Class Initialized
INFO - 2017-12-16 20:43:44 --> URI Class Initialized
INFO - 2017-12-16 20:43:44 --> Router Class Initialized
INFO - 2017-12-16 20:43:44 --> Output Class Initialized
INFO - 2017-12-16 20:43:44 --> Security Class Initialized
DEBUG - 2017-12-16 20:43:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 20:43:44 --> Input Class Initialized
INFO - 2017-12-16 20:43:44 --> Language Class Initialized
ERROR - 2017-12-16 20:43:44 --> 404 Page Not Found: Instatec_pub/css
INFO - 2017-12-16 20:43:49 --> Config Class Initialized
INFO - 2017-12-16 20:43:49 --> Hooks Class Initialized
DEBUG - 2017-12-16 20:43:49 --> UTF-8 Support Enabled
INFO - 2017-12-16 20:43:49 --> Utf8 Class Initialized
INFO - 2017-12-16 20:43:49 --> URI Class Initialized
INFO - 2017-12-16 20:43:49 --> Router Class Initialized
INFO - 2017-12-16 20:43:49 --> Output Class Initialized
INFO - 2017-12-16 20:43:49 --> Security Class Initialized
DEBUG - 2017-12-16 20:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 20:43:49 --> Input Class Initialized
INFO - 2017-12-16 20:43:49 --> Language Class Initialized
INFO - 2017-12-16 20:43:49 --> Loader Class Initialized
INFO - 2017-12-16 20:43:49 --> Helper loaded: url_helper
INFO - 2017-12-16 20:43:49 --> Helper loaded: form_helper
INFO - 2017-12-16 20:43:49 --> Database Driver Class Initialized
DEBUG - 2017-12-16 20:43:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 20:43:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 20:43:49 --> Form Validation Class Initialized
INFO - 2017-12-16 20:43:49 --> Model Class Initialized
INFO - 2017-12-16 20:43:49 --> Controller Class Initialized
INFO - 2017-12-16 20:43:49 --> Model Class Initialized
INFO - 2017-12-16 20:43:49 --> Model Class Initialized
INFO - 2017-12-16 20:43:49 --> Model Class Initialized
DEBUG - 2017-12-16 20:43:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 20:43:49 --> Final output sent to browser
DEBUG - 2017-12-16 20:43:49 --> Total execution time: 0.0479
INFO - 2017-12-16 20:43:50 --> Config Class Initialized
INFO - 2017-12-16 20:43:50 --> Hooks Class Initialized
DEBUG - 2017-12-16 20:43:50 --> UTF-8 Support Enabled
INFO - 2017-12-16 20:43:50 --> Utf8 Class Initialized
INFO - 2017-12-16 20:43:50 --> URI Class Initialized
INFO - 2017-12-16 20:43:50 --> Router Class Initialized
INFO - 2017-12-16 20:43:50 --> Output Class Initialized
INFO - 2017-12-16 20:43:50 --> Security Class Initialized
DEBUG - 2017-12-16 20:43:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 20:43:50 --> Input Class Initialized
INFO - 2017-12-16 20:43:50 --> Language Class Initialized
INFO - 2017-12-16 20:43:50 --> Loader Class Initialized
INFO - 2017-12-16 20:43:50 --> Helper loaded: url_helper
INFO - 2017-12-16 20:43:50 --> Helper loaded: form_helper
INFO - 2017-12-16 20:43:50 --> Database Driver Class Initialized
DEBUG - 2017-12-16 20:43:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 20:43:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 20:43:50 --> Form Validation Class Initialized
INFO - 2017-12-16 20:43:50 --> Model Class Initialized
INFO - 2017-12-16 20:43:50 --> Controller Class Initialized
INFO - 2017-12-16 20:43:50 --> Model Class Initialized
INFO - 2017-12-16 20:43:50 --> Model Class Initialized
INFO - 2017-12-16 20:43:50 --> Model Class Initialized
DEBUG - 2017-12-16 20:43:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 20:43:50 --> Config Class Initialized
INFO - 2017-12-16 20:43:50 --> Hooks Class Initialized
DEBUG - 2017-12-16 20:43:50 --> UTF-8 Support Enabled
INFO - 2017-12-16 20:43:50 --> Utf8 Class Initialized
INFO - 2017-12-16 20:43:50 --> URI Class Initialized
INFO - 2017-12-16 20:43:50 --> Router Class Initialized
INFO - 2017-12-16 20:43:50 --> Output Class Initialized
INFO - 2017-12-16 20:43:51 --> Security Class Initialized
DEBUG - 2017-12-16 20:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 20:43:51 --> Input Class Initialized
INFO - 2017-12-16 20:43:51 --> Language Class Initialized
INFO - 2017-12-16 20:43:51 --> Loader Class Initialized
INFO - 2017-12-16 20:43:51 --> Helper loaded: url_helper
INFO - 2017-12-16 20:43:51 --> Helper loaded: form_helper
INFO - 2017-12-16 20:43:51 --> Database Driver Class Initialized
DEBUG - 2017-12-16 20:43:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 20:43:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 20:43:51 --> Form Validation Class Initialized
INFO - 2017-12-16 20:43:51 --> Model Class Initialized
INFO - 2017-12-16 20:43:51 --> Controller Class Initialized
INFO - 2017-12-16 20:43:51 --> Model Class Initialized
INFO - 2017-12-16 20:43:51 --> Model Class Initialized
INFO - 2017-12-16 20:43:51 --> Model Class Initialized
DEBUG - 2017-12-16 20:43:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 20:43:51 --> Final output sent to browser
DEBUG - 2017-12-16 20:43:51 --> Total execution time: 0.0440
INFO - 2017-12-16 20:43:52 --> Config Class Initialized
INFO - 2017-12-16 20:43:52 --> Hooks Class Initialized
DEBUG - 2017-12-16 20:43:52 --> UTF-8 Support Enabled
INFO - 2017-12-16 20:43:52 --> Utf8 Class Initialized
INFO - 2017-12-16 20:43:52 --> URI Class Initialized
INFO - 2017-12-16 20:43:52 --> Router Class Initialized
INFO - 2017-12-16 20:43:52 --> Output Class Initialized
INFO - 2017-12-16 20:43:52 --> Security Class Initialized
DEBUG - 2017-12-16 20:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 20:43:52 --> Input Class Initialized
INFO - 2017-12-16 20:43:52 --> Language Class Initialized
INFO - 2017-12-16 20:43:52 --> Loader Class Initialized
INFO - 2017-12-16 20:43:52 --> Helper loaded: url_helper
INFO - 2017-12-16 20:43:52 --> Helper loaded: form_helper
INFO - 2017-12-16 20:43:52 --> Database Driver Class Initialized
DEBUG - 2017-12-16 20:43:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 20:43:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 20:43:52 --> Form Validation Class Initialized
INFO - 2017-12-16 20:43:52 --> Model Class Initialized
INFO - 2017-12-16 20:43:52 --> Controller Class Initialized
INFO - 2017-12-16 20:43:52 --> Model Class Initialized
INFO - 2017-12-16 20:43:52 --> Model Class Initialized
INFO - 2017-12-16 20:43:52 --> Model Class Initialized
DEBUG - 2017-12-16 20:43:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 20:44:48 --> Config Class Initialized
INFO - 2017-12-16 20:44:48 --> Hooks Class Initialized
DEBUG - 2017-12-16 20:44:48 --> UTF-8 Support Enabled
INFO - 2017-12-16 20:44:48 --> Utf8 Class Initialized
INFO - 2017-12-16 20:44:48 --> URI Class Initialized
INFO - 2017-12-16 20:44:48 --> Router Class Initialized
INFO - 2017-12-16 20:44:48 --> Output Class Initialized
INFO - 2017-12-16 20:44:48 --> Security Class Initialized
DEBUG - 2017-12-16 20:44:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 20:44:48 --> Input Class Initialized
INFO - 2017-12-16 20:44:48 --> Language Class Initialized
INFO - 2017-12-16 20:44:48 --> Loader Class Initialized
INFO - 2017-12-16 20:44:48 --> Helper loaded: url_helper
INFO - 2017-12-16 20:44:48 --> Helper loaded: form_helper
INFO - 2017-12-16 20:44:48 --> Database Driver Class Initialized
DEBUG - 2017-12-16 20:44:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 20:44:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 20:44:48 --> Form Validation Class Initialized
INFO - 2017-12-16 20:44:48 --> Model Class Initialized
INFO - 2017-12-16 20:44:48 --> Controller Class Initialized
INFO - 2017-12-16 20:44:48 --> Model Class Initialized
INFO - 2017-12-16 20:44:48 --> Model Class Initialized
INFO - 2017-12-16 20:44:48 --> Model Class Initialized
DEBUG - 2017-12-16 20:44:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 20:44:49 --> Config Class Initialized
INFO - 2017-12-16 20:44:49 --> Hooks Class Initialized
DEBUG - 2017-12-16 20:44:49 --> UTF-8 Support Enabled
INFO - 2017-12-16 20:44:49 --> Utf8 Class Initialized
INFO - 2017-12-16 20:44:49 --> URI Class Initialized
INFO - 2017-12-16 20:44:49 --> Router Class Initialized
INFO - 2017-12-16 20:44:49 --> Output Class Initialized
INFO - 2017-12-16 20:44:49 --> Security Class Initialized
DEBUG - 2017-12-16 20:44:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 20:44:49 --> Input Class Initialized
INFO - 2017-12-16 20:44:49 --> Language Class Initialized
INFO - 2017-12-16 20:44:49 --> Loader Class Initialized
INFO - 2017-12-16 20:44:49 --> Helper loaded: url_helper
INFO - 2017-12-16 20:44:49 --> Helper loaded: form_helper
INFO - 2017-12-16 20:44:49 --> Database Driver Class Initialized
DEBUG - 2017-12-16 20:44:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 20:44:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 20:44:49 --> Form Validation Class Initialized
INFO - 2017-12-16 20:44:49 --> Model Class Initialized
INFO - 2017-12-16 20:44:49 --> Controller Class Initialized
INFO - 2017-12-16 20:44:49 --> Model Class Initialized
INFO - 2017-12-16 20:44:49 --> Model Class Initialized
INFO - 2017-12-16 20:44:49 --> Model Class Initialized
DEBUG - 2017-12-16 20:44:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 20:44:50 --> Config Class Initialized
INFO - 2017-12-16 20:44:50 --> Hooks Class Initialized
DEBUG - 2017-12-16 20:44:50 --> UTF-8 Support Enabled
INFO - 2017-12-16 20:44:50 --> Utf8 Class Initialized
INFO - 2017-12-16 20:44:50 --> URI Class Initialized
INFO - 2017-12-16 20:44:50 --> Router Class Initialized
INFO - 2017-12-16 20:44:50 --> Output Class Initialized
INFO - 2017-12-16 20:44:50 --> Security Class Initialized
DEBUG - 2017-12-16 20:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 20:44:50 --> Input Class Initialized
INFO - 2017-12-16 20:44:50 --> Language Class Initialized
INFO - 2017-12-16 20:44:50 --> Loader Class Initialized
INFO - 2017-12-16 20:44:50 --> Helper loaded: url_helper
INFO - 2017-12-16 20:44:50 --> Helper loaded: form_helper
INFO - 2017-12-16 20:44:50 --> Database Driver Class Initialized
DEBUG - 2017-12-16 20:44:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 20:44:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 20:44:50 --> Form Validation Class Initialized
INFO - 2017-12-16 20:44:50 --> Model Class Initialized
INFO - 2017-12-16 20:44:50 --> Controller Class Initialized
INFO - 2017-12-16 20:44:50 --> Model Class Initialized
INFO - 2017-12-16 20:44:50 --> Model Class Initialized
INFO - 2017-12-16 20:44:50 --> Model Class Initialized
DEBUG - 2017-12-16 20:44:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 20:44:51 --> Config Class Initialized
INFO - 2017-12-16 20:44:51 --> Hooks Class Initialized
DEBUG - 2017-12-16 20:44:51 --> UTF-8 Support Enabled
INFO - 2017-12-16 20:44:51 --> Utf8 Class Initialized
INFO - 2017-12-16 20:44:51 --> URI Class Initialized
INFO - 2017-12-16 20:44:51 --> Router Class Initialized
INFO - 2017-12-16 20:44:51 --> Output Class Initialized
INFO - 2017-12-16 20:44:51 --> Security Class Initialized
DEBUG - 2017-12-16 20:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 20:44:51 --> Input Class Initialized
INFO - 2017-12-16 20:44:51 --> Language Class Initialized
INFO - 2017-12-16 20:44:51 --> Loader Class Initialized
INFO - 2017-12-16 20:44:51 --> Helper loaded: url_helper
INFO - 2017-12-16 20:44:51 --> Helper loaded: form_helper
INFO - 2017-12-16 20:44:51 --> Database Driver Class Initialized
DEBUG - 2017-12-16 20:44:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 20:44:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 20:44:51 --> Form Validation Class Initialized
INFO - 2017-12-16 20:44:51 --> Model Class Initialized
INFO - 2017-12-16 20:44:51 --> Controller Class Initialized
INFO - 2017-12-16 20:44:51 --> Model Class Initialized
INFO - 2017-12-16 20:44:51 --> Model Class Initialized
INFO - 2017-12-16 20:44:51 --> Model Class Initialized
DEBUG - 2017-12-16 20:44:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 20:44:53 --> Config Class Initialized
INFO - 2017-12-16 20:44:53 --> Hooks Class Initialized
DEBUG - 2017-12-16 20:44:53 --> UTF-8 Support Enabled
INFO - 2017-12-16 20:44:53 --> Utf8 Class Initialized
INFO - 2017-12-16 20:44:53 --> URI Class Initialized
INFO - 2017-12-16 20:44:53 --> Router Class Initialized
INFO - 2017-12-16 20:44:53 --> Output Class Initialized
INFO - 2017-12-16 20:44:53 --> Security Class Initialized
DEBUG - 2017-12-16 20:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 20:44:53 --> Input Class Initialized
INFO - 2017-12-16 20:44:53 --> Language Class Initialized
INFO - 2017-12-16 20:44:53 --> Loader Class Initialized
INFO - 2017-12-16 20:44:53 --> Helper loaded: url_helper
INFO - 2017-12-16 20:44:53 --> Helper loaded: form_helper
INFO - 2017-12-16 20:44:53 --> Database Driver Class Initialized
DEBUG - 2017-12-16 20:44:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 20:44:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 20:44:53 --> Form Validation Class Initialized
INFO - 2017-12-16 20:44:53 --> Model Class Initialized
INFO - 2017-12-16 20:44:53 --> Controller Class Initialized
INFO - 2017-12-16 20:44:53 --> Model Class Initialized
INFO - 2017-12-16 20:44:53 --> Model Class Initialized
INFO - 2017-12-16 20:44:53 --> Model Class Initialized
DEBUG - 2017-12-16 20:44:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 20:44:56 --> Config Class Initialized
INFO - 2017-12-16 20:44:56 --> Hooks Class Initialized
DEBUG - 2017-12-16 20:44:56 --> UTF-8 Support Enabled
INFO - 2017-12-16 20:44:56 --> Utf8 Class Initialized
INFO - 2017-12-16 20:44:56 --> URI Class Initialized
INFO - 2017-12-16 20:44:56 --> Router Class Initialized
INFO - 2017-12-16 20:44:56 --> Output Class Initialized
INFO - 2017-12-16 20:44:56 --> Security Class Initialized
DEBUG - 2017-12-16 20:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 20:44:56 --> Input Class Initialized
INFO - 2017-12-16 20:44:56 --> Language Class Initialized
INFO - 2017-12-16 20:44:56 --> Loader Class Initialized
INFO - 2017-12-16 20:44:56 --> Helper loaded: url_helper
INFO - 2017-12-16 20:44:56 --> Helper loaded: form_helper
INFO - 2017-12-16 20:44:56 --> Database Driver Class Initialized
DEBUG - 2017-12-16 20:44:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 20:44:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 20:44:56 --> Form Validation Class Initialized
INFO - 2017-12-16 20:44:56 --> Model Class Initialized
INFO - 2017-12-16 20:44:56 --> Controller Class Initialized
INFO - 2017-12-16 20:44:56 --> Model Class Initialized
INFO - 2017-12-16 20:44:56 --> Model Class Initialized
INFO - 2017-12-16 20:44:56 --> Model Class Initialized
DEBUG - 2017-12-16 20:44:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 20:44:57 --> Config Class Initialized
INFO - 2017-12-16 20:44:57 --> Hooks Class Initialized
DEBUG - 2017-12-16 20:44:57 --> UTF-8 Support Enabled
INFO - 2017-12-16 20:44:57 --> Utf8 Class Initialized
INFO - 2017-12-16 20:44:57 --> URI Class Initialized
INFO - 2017-12-16 20:44:57 --> Router Class Initialized
INFO - 2017-12-16 20:44:57 --> Output Class Initialized
INFO - 2017-12-16 20:44:57 --> Security Class Initialized
DEBUG - 2017-12-16 20:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 20:44:57 --> Input Class Initialized
INFO - 2017-12-16 20:44:57 --> Language Class Initialized
INFO - 2017-12-16 20:44:57 --> Loader Class Initialized
INFO - 2017-12-16 20:44:57 --> Helper loaded: url_helper
INFO - 2017-12-16 20:44:57 --> Helper loaded: form_helper
INFO - 2017-12-16 20:44:57 --> Database Driver Class Initialized
DEBUG - 2017-12-16 20:44:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 20:44:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 20:44:57 --> Form Validation Class Initialized
INFO - 2017-12-16 20:44:57 --> Model Class Initialized
INFO - 2017-12-16 20:44:57 --> Controller Class Initialized
INFO - 2017-12-16 20:44:57 --> Model Class Initialized
INFO - 2017-12-16 20:44:57 --> Model Class Initialized
INFO - 2017-12-16 20:44:57 --> Model Class Initialized
DEBUG - 2017-12-16 20:44:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 20:44:57 --> Config Class Initialized
INFO - 2017-12-16 20:44:57 --> Hooks Class Initialized
DEBUG - 2017-12-16 20:44:57 --> UTF-8 Support Enabled
INFO - 2017-12-16 20:44:57 --> Utf8 Class Initialized
INFO - 2017-12-16 20:44:57 --> URI Class Initialized
INFO - 2017-12-16 20:44:57 --> Router Class Initialized
INFO - 2017-12-16 20:44:57 --> Output Class Initialized
INFO - 2017-12-16 20:44:57 --> Security Class Initialized
DEBUG - 2017-12-16 20:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 20:44:57 --> Input Class Initialized
INFO - 2017-12-16 20:44:57 --> Language Class Initialized
INFO - 2017-12-16 20:44:57 --> Loader Class Initialized
INFO - 2017-12-16 20:44:57 --> Helper loaded: url_helper
INFO - 2017-12-16 20:44:57 --> Helper loaded: form_helper
INFO - 2017-12-16 20:44:57 --> Database Driver Class Initialized
DEBUG - 2017-12-16 20:44:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 20:44:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 20:44:57 --> Form Validation Class Initialized
INFO - 2017-12-16 20:44:57 --> Model Class Initialized
INFO - 2017-12-16 20:44:57 --> Controller Class Initialized
INFO - 2017-12-16 20:44:57 --> Model Class Initialized
INFO - 2017-12-16 20:44:57 --> Model Class Initialized
INFO - 2017-12-16 20:44:57 --> Model Class Initialized
DEBUG - 2017-12-16 20:44:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 20:44:58 --> Config Class Initialized
INFO - 2017-12-16 20:44:58 --> Hooks Class Initialized
DEBUG - 2017-12-16 20:44:58 --> UTF-8 Support Enabled
INFO - 2017-12-16 20:44:58 --> Utf8 Class Initialized
INFO - 2017-12-16 20:44:58 --> URI Class Initialized
INFO - 2017-12-16 20:44:58 --> Router Class Initialized
INFO - 2017-12-16 20:44:58 --> Output Class Initialized
INFO - 2017-12-16 20:44:58 --> Security Class Initialized
DEBUG - 2017-12-16 20:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 20:44:58 --> Input Class Initialized
INFO - 2017-12-16 20:44:58 --> Language Class Initialized
INFO - 2017-12-16 20:44:58 --> Loader Class Initialized
INFO - 2017-12-16 20:44:58 --> Helper loaded: url_helper
INFO - 2017-12-16 20:44:58 --> Helper loaded: form_helper
INFO - 2017-12-16 20:44:58 --> Database Driver Class Initialized
DEBUG - 2017-12-16 20:44:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 20:44:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 20:44:58 --> Form Validation Class Initialized
INFO - 2017-12-16 20:44:58 --> Model Class Initialized
INFO - 2017-12-16 20:44:58 --> Controller Class Initialized
INFO - 2017-12-16 20:44:58 --> Model Class Initialized
INFO - 2017-12-16 20:44:58 --> Model Class Initialized
INFO - 2017-12-16 20:44:58 --> Model Class Initialized
DEBUG - 2017-12-16 20:44:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 20:45:00 --> Config Class Initialized
INFO - 2017-12-16 20:45:00 --> Hooks Class Initialized
DEBUG - 2017-12-16 20:45:00 --> UTF-8 Support Enabled
INFO - 2017-12-16 20:45:00 --> Utf8 Class Initialized
INFO - 2017-12-16 20:45:00 --> URI Class Initialized
INFO - 2017-12-16 20:45:00 --> Router Class Initialized
INFO - 2017-12-16 20:45:00 --> Output Class Initialized
INFO - 2017-12-16 20:45:00 --> Security Class Initialized
DEBUG - 2017-12-16 20:45:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 20:45:00 --> Input Class Initialized
INFO - 2017-12-16 20:45:00 --> Language Class Initialized
INFO - 2017-12-16 20:45:00 --> Loader Class Initialized
INFO - 2017-12-16 20:45:00 --> Helper loaded: url_helper
INFO - 2017-12-16 20:45:00 --> Helper loaded: form_helper
INFO - 2017-12-16 20:45:00 --> Database Driver Class Initialized
DEBUG - 2017-12-16 20:45:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 20:45:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 20:45:00 --> Form Validation Class Initialized
INFO - 2017-12-16 20:45:00 --> Model Class Initialized
INFO - 2017-12-16 20:45:00 --> Controller Class Initialized
INFO - 2017-12-16 20:45:00 --> Model Class Initialized
INFO - 2017-12-16 20:45:00 --> Model Class Initialized
INFO - 2017-12-16 20:45:00 --> Model Class Initialized
DEBUG - 2017-12-16 20:45:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 20:45:02 --> Config Class Initialized
INFO - 2017-12-16 20:45:02 --> Hooks Class Initialized
DEBUG - 2017-12-16 20:45:02 --> UTF-8 Support Enabled
INFO - 2017-12-16 20:45:02 --> Utf8 Class Initialized
INFO - 2017-12-16 20:45:02 --> URI Class Initialized
INFO - 2017-12-16 20:45:02 --> Router Class Initialized
INFO - 2017-12-16 20:45:02 --> Output Class Initialized
INFO - 2017-12-16 20:45:02 --> Security Class Initialized
DEBUG - 2017-12-16 20:45:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 20:45:02 --> Input Class Initialized
INFO - 2017-12-16 20:45:02 --> Language Class Initialized
INFO - 2017-12-16 20:45:02 --> Loader Class Initialized
INFO - 2017-12-16 20:45:02 --> Helper loaded: url_helper
INFO - 2017-12-16 20:45:02 --> Helper loaded: form_helper
INFO - 2017-12-16 20:45:02 --> Database Driver Class Initialized
DEBUG - 2017-12-16 20:45:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 20:45:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 20:45:02 --> Form Validation Class Initialized
INFO - 2017-12-16 20:45:02 --> Model Class Initialized
INFO - 2017-12-16 20:45:02 --> Controller Class Initialized
INFO - 2017-12-16 20:45:02 --> Model Class Initialized
INFO - 2017-12-16 20:45:02 --> Model Class Initialized
INFO - 2017-12-16 20:45:02 --> Model Class Initialized
DEBUG - 2017-12-16 20:45:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 20:45:05 --> Config Class Initialized
INFO - 2017-12-16 20:45:05 --> Hooks Class Initialized
DEBUG - 2017-12-16 20:45:05 --> UTF-8 Support Enabled
INFO - 2017-12-16 20:45:05 --> Utf8 Class Initialized
INFO - 2017-12-16 20:45:05 --> URI Class Initialized
INFO - 2017-12-16 20:45:05 --> Router Class Initialized
INFO - 2017-12-16 20:45:05 --> Output Class Initialized
INFO - 2017-12-16 20:45:05 --> Security Class Initialized
DEBUG - 2017-12-16 20:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 20:45:05 --> Input Class Initialized
INFO - 2017-12-16 20:45:05 --> Language Class Initialized
INFO - 2017-12-16 20:45:05 --> Loader Class Initialized
INFO - 2017-12-16 20:45:05 --> Helper loaded: url_helper
INFO - 2017-12-16 20:45:05 --> Helper loaded: form_helper
INFO - 2017-12-16 20:45:05 --> Database Driver Class Initialized
DEBUG - 2017-12-16 20:45:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 20:45:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 20:45:05 --> Form Validation Class Initialized
INFO - 2017-12-16 20:45:05 --> Model Class Initialized
INFO - 2017-12-16 20:45:05 --> Controller Class Initialized
INFO - 2017-12-16 20:45:05 --> Model Class Initialized
INFO - 2017-12-16 20:45:05 --> Model Class Initialized
INFO - 2017-12-16 20:45:05 --> Model Class Initialized
DEBUG - 2017-12-16 20:45:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 20:45:09 --> Config Class Initialized
INFO - 2017-12-16 20:45:09 --> Hooks Class Initialized
DEBUG - 2017-12-16 20:45:09 --> UTF-8 Support Enabled
INFO - 2017-12-16 20:45:09 --> Utf8 Class Initialized
INFO - 2017-12-16 20:45:09 --> URI Class Initialized
INFO - 2017-12-16 20:45:09 --> Router Class Initialized
INFO - 2017-12-16 20:45:09 --> Output Class Initialized
INFO - 2017-12-16 20:45:09 --> Security Class Initialized
DEBUG - 2017-12-16 20:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 20:45:09 --> Input Class Initialized
INFO - 2017-12-16 20:45:09 --> Language Class Initialized
INFO - 2017-12-16 20:45:09 --> Loader Class Initialized
INFO - 2017-12-16 20:45:09 --> Helper loaded: url_helper
INFO - 2017-12-16 20:45:09 --> Helper loaded: form_helper
INFO - 2017-12-16 20:45:09 --> Database Driver Class Initialized
DEBUG - 2017-12-16 20:45:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 20:45:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 20:45:09 --> Form Validation Class Initialized
INFO - 2017-12-16 20:45:09 --> Model Class Initialized
INFO - 2017-12-16 20:45:09 --> Controller Class Initialized
INFO - 2017-12-16 20:45:09 --> Model Class Initialized
INFO - 2017-12-16 20:45:09 --> Model Class Initialized
INFO - 2017-12-16 20:45:09 --> Model Class Initialized
DEBUG - 2017-12-16 20:45:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 20:45:11 --> Config Class Initialized
INFO - 2017-12-16 20:45:11 --> Hooks Class Initialized
DEBUG - 2017-12-16 20:45:11 --> UTF-8 Support Enabled
INFO - 2017-12-16 20:45:11 --> Utf8 Class Initialized
INFO - 2017-12-16 20:45:11 --> URI Class Initialized
INFO - 2017-12-16 20:45:11 --> Router Class Initialized
INFO - 2017-12-16 20:45:11 --> Output Class Initialized
INFO - 2017-12-16 20:45:11 --> Security Class Initialized
DEBUG - 2017-12-16 20:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 20:45:11 --> Input Class Initialized
INFO - 2017-12-16 20:45:11 --> Language Class Initialized
INFO - 2017-12-16 20:45:11 --> Loader Class Initialized
INFO - 2017-12-16 20:45:11 --> Helper loaded: url_helper
INFO - 2017-12-16 20:45:11 --> Helper loaded: form_helper
INFO - 2017-12-16 20:45:11 --> Database Driver Class Initialized
DEBUG - 2017-12-16 20:45:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 20:45:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 20:45:11 --> Form Validation Class Initialized
INFO - 2017-12-16 20:45:11 --> Model Class Initialized
INFO - 2017-12-16 20:45:11 --> Controller Class Initialized
INFO - 2017-12-16 20:45:11 --> Model Class Initialized
INFO - 2017-12-16 20:45:11 --> Model Class Initialized
INFO - 2017-12-16 20:45:11 --> Model Class Initialized
DEBUG - 2017-12-16 20:45:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 20:45:14 --> Config Class Initialized
INFO - 2017-12-16 20:45:14 --> Hooks Class Initialized
DEBUG - 2017-12-16 20:45:14 --> UTF-8 Support Enabled
INFO - 2017-12-16 20:45:14 --> Utf8 Class Initialized
INFO - 2017-12-16 20:45:14 --> URI Class Initialized
INFO - 2017-12-16 20:45:14 --> Router Class Initialized
INFO - 2017-12-16 20:45:14 --> Output Class Initialized
INFO - 2017-12-16 20:45:14 --> Security Class Initialized
DEBUG - 2017-12-16 20:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 20:45:14 --> Input Class Initialized
INFO - 2017-12-16 20:45:14 --> Language Class Initialized
INFO - 2017-12-16 20:45:14 --> Loader Class Initialized
INFO - 2017-12-16 20:45:14 --> Helper loaded: url_helper
INFO - 2017-12-16 20:45:14 --> Helper loaded: form_helper
INFO - 2017-12-16 20:45:14 --> Database Driver Class Initialized
DEBUG - 2017-12-16 20:45:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 20:45:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 20:45:14 --> Form Validation Class Initialized
INFO - 2017-12-16 20:45:14 --> Model Class Initialized
INFO - 2017-12-16 20:45:14 --> Controller Class Initialized
INFO - 2017-12-16 20:45:14 --> Model Class Initialized
INFO - 2017-12-16 20:45:14 --> Model Class Initialized
INFO - 2017-12-16 20:45:14 --> Model Class Initialized
DEBUG - 2017-12-16 20:45:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 20:45:15 --> Config Class Initialized
INFO - 2017-12-16 20:45:15 --> Hooks Class Initialized
DEBUG - 2017-12-16 20:45:15 --> UTF-8 Support Enabled
INFO - 2017-12-16 20:45:15 --> Utf8 Class Initialized
INFO - 2017-12-16 20:45:15 --> URI Class Initialized
INFO - 2017-12-16 20:45:15 --> Router Class Initialized
INFO - 2017-12-16 20:45:15 --> Output Class Initialized
INFO - 2017-12-16 20:45:15 --> Security Class Initialized
DEBUG - 2017-12-16 20:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 20:45:15 --> Input Class Initialized
INFO - 2017-12-16 20:45:15 --> Language Class Initialized
INFO - 2017-12-16 20:45:15 --> Loader Class Initialized
INFO - 2017-12-16 20:45:15 --> Helper loaded: url_helper
INFO - 2017-12-16 20:45:15 --> Helper loaded: form_helper
INFO - 2017-12-16 20:45:15 --> Database Driver Class Initialized
DEBUG - 2017-12-16 20:45:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 20:45:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 20:45:15 --> Form Validation Class Initialized
INFO - 2017-12-16 20:45:15 --> Model Class Initialized
INFO - 2017-12-16 20:45:15 --> Controller Class Initialized
INFO - 2017-12-16 20:45:15 --> Model Class Initialized
INFO - 2017-12-16 20:45:15 --> Model Class Initialized
INFO - 2017-12-16 20:45:15 --> Model Class Initialized
DEBUG - 2017-12-16 20:45:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 20:54:22 --> Config Class Initialized
INFO - 2017-12-16 20:54:22 --> Hooks Class Initialized
DEBUG - 2017-12-16 20:54:22 --> UTF-8 Support Enabled
INFO - 2017-12-16 20:54:22 --> Utf8 Class Initialized
INFO - 2017-12-16 20:54:22 --> URI Class Initialized
INFO - 2017-12-16 20:54:22 --> Router Class Initialized
INFO - 2017-12-16 20:54:22 --> Output Class Initialized
INFO - 2017-12-16 20:54:22 --> Security Class Initialized
DEBUG - 2017-12-16 20:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 20:54:22 --> Input Class Initialized
INFO - 2017-12-16 20:54:22 --> Language Class Initialized
INFO - 2017-12-16 20:54:22 --> Loader Class Initialized
INFO - 2017-12-16 20:54:22 --> Helper loaded: url_helper
INFO - 2017-12-16 20:54:22 --> Helper loaded: form_helper
INFO - 2017-12-16 20:54:22 --> Database Driver Class Initialized
DEBUG - 2017-12-16 20:54:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 20:54:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 20:54:22 --> Form Validation Class Initialized
INFO - 2017-12-16 20:54:22 --> Model Class Initialized
INFO - 2017-12-16 20:54:22 --> Controller Class Initialized
INFO - 2017-12-16 20:54:22 --> Model Class Initialized
INFO - 2017-12-16 20:54:22 --> Model Class Initialized
INFO - 2017-12-16 20:54:22 --> Model Class Initialized
DEBUG - 2017-12-16 20:54:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 20:54:22 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-16 20:54:22 --> Final output sent to browser
DEBUG - 2017-12-16 20:54:22 --> Total execution time: 0.0374
INFO - 2017-12-16 20:54:57 --> Config Class Initialized
INFO - 2017-12-16 20:54:57 --> Hooks Class Initialized
DEBUG - 2017-12-16 20:54:57 --> UTF-8 Support Enabled
INFO - 2017-12-16 20:54:57 --> Utf8 Class Initialized
INFO - 2017-12-16 20:54:57 --> URI Class Initialized
INFO - 2017-12-16 20:54:57 --> Router Class Initialized
INFO - 2017-12-16 20:54:57 --> Output Class Initialized
INFO - 2017-12-16 20:54:57 --> Security Class Initialized
DEBUG - 2017-12-16 20:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 20:54:57 --> Input Class Initialized
INFO - 2017-12-16 20:54:57 --> Language Class Initialized
INFO - 2017-12-16 20:54:57 --> Loader Class Initialized
INFO - 2017-12-16 20:54:57 --> Helper loaded: url_helper
INFO - 2017-12-16 20:54:57 --> Helper loaded: form_helper
INFO - 2017-12-16 20:54:57 --> Database Driver Class Initialized
DEBUG - 2017-12-16 20:54:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 20:54:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 20:54:57 --> Form Validation Class Initialized
INFO - 2017-12-16 20:54:57 --> Model Class Initialized
INFO - 2017-12-16 20:54:57 --> Controller Class Initialized
INFO - 2017-12-16 20:54:57 --> Model Class Initialized
INFO - 2017-12-16 20:54:57 --> Model Class Initialized
INFO - 2017-12-16 20:54:57 --> Model Class Initialized
DEBUG - 2017-12-16 20:54:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 20:54:57 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-16 20:54:57 --> Final output sent to browser
DEBUG - 2017-12-16 20:54:57 --> Total execution time: 0.0368
INFO - 2017-12-16 20:54:58 --> Config Class Initialized
INFO - 2017-12-16 20:54:58 --> Hooks Class Initialized
DEBUG - 2017-12-16 20:54:58 --> UTF-8 Support Enabled
INFO - 2017-12-16 20:54:58 --> Utf8 Class Initialized
INFO - 2017-12-16 20:54:58 --> URI Class Initialized
INFO - 2017-12-16 20:54:58 --> Router Class Initialized
INFO - 2017-12-16 20:54:58 --> Output Class Initialized
INFO - 2017-12-16 20:54:58 --> Security Class Initialized
DEBUG - 2017-12-16 20:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 20:54:58 --> Input Class Initialized
INFO - 2017-12-16 20:54:58 --> Language Class Initialized
INFO - 2017-12-16 20:54:58 --> Loader Class Initialized
INFO - 2017-12-16 20:54:58 --> Helper loaded: url_helper
INFO - 2017-12-16 20:54:58 --> Helper loaded: form_helper
INFO - 2017-12-16 20:54:58 --> Database Driver Class Initialized
DEBUG - 2017-12-16 20:54:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 20:54:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 20:54:58 --> Form Validation Class Initialized
INFO - 2017-12-16 20:54:58 --> Model Class Initialized
INFO - 2017-12-16 20:54:58 --> Controller Class Initialized
INFO - 2017-12-16 20:54:58 --> Model Class Initialized
INFO - 2017-12-16 20:54:58 --> Model Class Initialized
INFO - 2017-12-16 20:54:58 --> Model Class Initialized
DEBUG - 2017-12-16 20:54:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 20:54:58 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-16 20:54:58 --> Final output sent to browser
DEBUG - 2017-12-16 20:54:58 --> Total execution time: 0.0423
INFO - 2017-12-16 20:55:11 --> Config Class Initialized
INFO - 2017-12-16 20:55:11 --> Hooks Class Initialized
DEBUG - 2017-12-16 20:55:11 --> UTF-8 Support Enabled
INFO - 2017-12-16 20:55:11 --> Utf8 Class Initialized
INFO - 2017-12-16 20:55:11 --> URI Class Initialized
INFO - 2017-12-16 20:55:11 --> Router Class Initialized
INFO - 2017-12-16 20:55:11 --> Output Class Initialized
INFO - 2017-12-16 20:55:11 --> Security Class Initialized
DEBUG - 2017-12-16 20:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 20:55:11 --> Input Class Initialized
INFO - 2017-12-16 20:55:11 --> Language Class Initialized
INFO - 2017-12-16 20:55:11 --> Loader Class Initialized
INFO - 2017-12-16 20:55:11 --> Helper loaded: url_helper
INFO - 2017-12-16 20:55:11 --> Helper loaded: form_helper
INFO - 2017-12-16 20:55:11 --> Database Driver Class Initialized
DEBUG - 2017-12-16 20:55:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 20:55:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 20:55:11 --> Form Validation Class Initialized
INFO - 2017-12-16 20:55:11 --> Model Class Initialized
INFO - 2017-12-16 20:55:11 --> Controller Class Initialized
INFO - 2017-12-16 20:55:11 --> Model Class Initialized
INFO - 2017-12-16 20:55:11 --> Model Class Initialized
DEBUG - 2017-12-16 20:55:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 20:55:11 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-16 20:55:11 --> Final output sent to browser
DEBUG - 2017-12-16 20:55:11 --> Total execution time: 0.0447
INFO - 2017-12-16 20:55:11 --> Config Class Initialized
INFO - 2017-12-16 20:55:11 --> Hooks Class Initialized
DEBUG - 2017-12-16 20:55:11 --> UTF-8 Support Enabled
INFO - 2017-12-16 20:55:11 --> Utf8 Class Initialized
INFO - 2017-12-16 20:55:11 --> URI Class Initialized
INFO - 2017-12-16 20:55:11 --> Router Class Initialized
INFO - 2017-12-16 20:55:11 --> Output Class Initialized
INFO - 2017-12-16 20:55:11 --> Security Class Initialized
DEBUG - 2017-12-16 20:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 20:55:11 --> Input Class Initialized
INFO - 2017-12-16 20:55:11 --> Language Class Initialized
INFO - 2017-12-16 20:55:11 --> Loader Class Initialized
INFO - 2017-12-16 20:55:11 --> Helper loaded: url_helper
INFO - 2017-12-16 20:55:11 --> Helper loaded: form_helper
INFO - 2017-12-16 20:55:11 --> Database Driver Class Initialized
DEBUG - 2017-12-16 20:55:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 20:55:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 20:55:12 --> Form Validation Class Initialized
INFO - 2017-12-16 20:55:12 --> Model Class Initialized
INFO - 2017-12-16 20:55:12 --> Controller Class Initialized
INFO - 2017-12-16 20:55:12 --> Model Class Initialized
INFO - 2017-12-16 20:55:12 --> Model Class Initialized
DEBUG - 2017-12-16 20:55:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 20:55:15 --> Config Class Initialized
INFO - 2017-12-16 20:55:15 --> Hooks Class Initialized
DEBUG - 2017-12-16 20:55:15 --> UTF-8 Support Enabled
INFO - 2017-12-16 20:55:15 --> Utf8 Class Initialized
INFO - 2017-12-16 20:55:16 --> URI Class Initialized
INFO - 2017-12-16 20:55:16 --> Router Class Initialized
INFO - 2017-12-16 20:55:16 --> Output Class Initialized
INFO - 2017-12-16 20:55:16 --> Security Class Initialized
DEBUG - 2017-12-16 20:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 20:55:16 --> Input Class Initialized
INFO - 2017-12-16 20:55:16 --> Language Class Initialized
INFO - 2017-12-16 20:55:16 --> Loader Class Initialized
INFO - 2017-12-16 20:55:16 --> Helper loaded: url_helper
INFO - 2017-12-16 20:55:16 --> Helper loaded: form_helper
INFO - 2017-12-16 20:55:16 --> Database Driver Class Initialized
DEBUG - 2017-12-16 20:55:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 20:55:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 20:55:16 --> Form Validation Class Initialized
INFO - 2017-12-16 20:55:16 --> Model Class Initialized
INFO - 2017-12-16 20:55:16 --> Controller Class Initialized
INFO - 2017-12-16 20:55:16 --> Model Class Initialized
INFO - 2017-12-16 20:55:16 --> Model Class Initialized
DEBUG - 2017-12-16 20:55:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 20:55:16 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-16 20:55:16 --> Final output sent to browser
DEBUG - 2017-12-16 20:55:16 --> Total execution time: 0.0428
INFO - 2017-12-16 20:55:23 --> Config Class Initialized
INFO - 2017-12-16 20:55:23 --> Hooks Class Initialized
DEBUG - 2017-12-16 20:55:23 --> UTF-8 Support Enabled
INFO - 2017-12-16 20:55:23 --> Utf8 Class Initialized
INFO - 2017-12-16 20:55:23 --> URI Class Initialized
INFO - 2017-12-16 20:55:23 --> Router Class Initialized
INFO - 2017-12-16 20:55:23 --> Output Class Initialized
INFO - 2017-12-16 20:55:23 --> Security Class Initialized
DEBUG - 2017-12-16 20:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 20:55:23 --> Input Class Initialized
INFO - 2017-12-16 20:55:23 --> Language Class Initialized
INFO - 2017-12-16 20:55:23 --> Loader Class Initialized
INFO - 2017-12-16 20:55:23 --> Helper loaded: url_helper
INFO - 2017-12-16 20:55:23 --> Helper loaded: form_helper
INFO - 2017-12-16 20:55:23 --> Database Driver Class Initialized
DEBUG - 2017-12-16 20:55:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 20:55:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 20:55:23 --> Form Validation Class Initialized
INFO - 2017-12-16 20:55:23 --> Model Class Initialized
INFO - 2017-12-16 20:55:23 --> Controller Class Initialized
INFO - 2017-12-16 20:55:23 --> Model Class Initialized
INFO - 2017-12-16 20:55:23 --> Model Class Initialized
DEBUG - 2017-12-16 20:55:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 20:55:23 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-16 20:55:23 --> Final output sent to browser
DEBUG - 2017-12-16 20:55:23 --> Total execution time: 0.0463
INFO - 2017-12-16 20:55:23 --> Config Class Initialized
INFO - 2017-12-16 20:55:23 --> Hooks Class Initialized
DEBUG - 2017-12-16 20:55:23 --> UTF-8 Support Enabled
INFO - 2017-12-16 20:55:23 --> Utf8 Class Initialized
INFO - 2017-12-16 20:55:23 --> URI Class Initialized
INFO - 2017-12-16 20:55:23 --> Router Class Initialized
INFO - 2017-12-16 20:55:23 --> Output Class Initialized
INFO - 2017-12-16 20:55:23 --> Security Class Initialized
DEBUG - 2017-12-16 20:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 20:55:23 --> Input Class Initialized
INFO - 2017-12-16 20:55:23 --> Language Class Initialized
INFO - 2017-12-16 20:55:23 --> Loader Class Initialized
INFO - 2017-12-16 20:55:23 --> Helper loaded: url_helper
INFO - 2017-12-16 20:55:23 --> Helper loaded: form_helper
INFO - 2017-12-16 20:55:23 --> Database Driver Class Initialized
DEBUG - 2017-12-16 20:55:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 20:55:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 20:55:23 --> Form Validation Class Initialized
INFO - 2017-12-16 20:55:23 --> Model Class Initialized
INFO - 2017-12-16 20:55:23 --> Controller Class Initialized
INFO - 2017-12-16 20:55:23 --> Model Class Initialized
INFO - 2017-12-16 20:55:23 --> Model Class Initialized
DEBUG - 2017-12-16 20:55:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 20:55:26 --> Config Class Initialized
INFO - 2017-12-16 20:55:26 --> Hooks Class Initialized
DEBUG - 2017-12-16 20:55:26 --> UTF-8 Support Enabled
INFO - 2017-12-16 20:55:26 --> Utf8 Class Initialized
INFO - 2017-12-16 20:55:26 --> URI Class Initialized
INFO - 2017-12-16 20:55:26 --> Router Class Initialized
INFO - 2017-12-16 20:55:26 --> Output Class Initialized
INFO - 2017-12-16 20:55:26 --> Security Class Initialized
DEBUG - 2017-12-16 20:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 20:55:26 --> Input Class Initialized
INFO - 2017-12-16 20:55:26 --> Language Class Initialized
INFO - 2017-12-16 20:55:26 --> Loader Class Initialized
INFO - 2017-12-16 20:55:26 --> Helper loaded: url_helper
INFO - 2017-12-16 20:55:26 --> Helper loaded: form_helper
INFO - 2017-12-16 20:55:26 --> Database Driver Class Initialized
DEBUG - 2017-12-16 20:55:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 20:55:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 20:55:26 --> Form Validation Class Initialized
INFO - 2017-12-16 20:55:26 --> Model Class Initialized
INFO - 2017-12-16 20:55:26 --> Controller Class Initialized
INFO - 2017-12-16 20:55:26 --> Model Class Initialized
INFO - 2017-12-16 20:55:26 --> Model Class Initialized
INFO - 2017-12-16 20:55:26 --> Model Class Initialized
DEBUG - 2017-12-16 20:55:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 20:55:26 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-16 20:55:26 --> Final output sent to browser
DEBUG - 2017-12-16 20:55:26 --> Total execution time: 0.0459
INFO - 2017-12-16 20:55:26 --> Config Class Initialized
INFO - 2017-12-16 20:55:26 --> Hooks Class Initialized
DEBUG - 2017-12-16 20:55:26 --> UTF-8 Support Enabled
INFO - 2017-12-16 20:55:26 --> Utf8 Class Initialized
INFO - 2017-12-16 20:55:26 --> URI Class Initialized
INFO - 2017-12-16 20:55:26 --> Router Class Initialized
INFO - 2017-12-16 20:55:26 --> Output Class Initialized
INFO - 2017-12-16 20:55:26 --> Security Class Initialized
DEBUG - 2017-12-16 20:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 20:55:26 --> Input Class Initialized
INFO - 2017-12-16 20:55:26 --> Language Class Initialized
INFO - 2017-12-16 20:55:26 --> Loader Class Initialized
INFO - 2017-12-16 20:55:26 --> Helper loaded: url_helper
INFO - 2017-12-16 20:55:26 --> Helper loaded: form_helper
INFO - 2017-12-16 20:55:26 --> Database Driver Class Initialized
DEBUG - 2017-12-16 20:55:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 20:55:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 20:55:26 --> Form Validation Class Initialized
INFO - 2017-12-16 20:55:26 --> Model Class Initialized
INFO - 2017-12-16 20:55:26 --> Controller Class Initialized
INFO - 2017-12-16 20:55:27 --> Model Class Initialized
INFO - 2017-12-16 20:55:27 --> Model Class Initialized
INFO - 2017-12-16 20:55:27 --> Model Class Initialized
DEBUG - 2017-12-16 20:55:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 20:55:27 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-16 20:55:27 --> Final output sent to browser
DEBUG - 2017-12-16 20:55:27 --> Total execution time: 0.0500
INFO - 2017-12-16 22:52:29 --> Config Class Initialized
INFO - 2017-12-16 22:52:29 --> Hooks Class Initialized
DEBUG - 2017-12-16 22:52:29 --> UTF-8 Support Enabled
INFO - 2017-12-16 22:52:29 --> Utf8 Class Initialized
INFO - 2017-12-16 22:52:29 --> URI Class Initialized
INFO - 2017-12-16 22:52:29 --> Router Class Initialized
INFO - 2017-12-16 22:52:29 --> Output Class Initialized
INFO - 2017-12-16 22:52:29 --> Security Class Initialized
DEBUG - 2017-12-16 22:52:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 22:52:29 --> Input Class Initialized
INFO - 2017-12-16 22:52:29 --> Language Class Initialized
INFO - 2017-12-16 22:52:30 --> Loader Class Initialized
INFO - 2017-12-16 22:52:30 --> Helper loaded: url_helper
INFO - 2017-12-16 22:52:30 --> Helper loaded: form_helper
INFO - 2017-12-16 22:52:30 --> Database Driver Class Initialized
DEBUG - 2017-12-16 22:52:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 22:52:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 22:52:30 --> Form Validation Class Initialized
INFO - 2017-12-16 22:52:30 --> Model Class Initialized
INFO - 2017-12-16 22:52:30 --> Controller Class Initialized
INFO - 2017-12-16 22:52:30 --> Model Class Initialized
INFO - 2017-12-16 22:52:30 --> Model Class Initialized
INFO - 2017-12-16 22:52:30 --> Model Class Initialized
DEBUG - 2017-12-16 22:52:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 22:52:30 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-16 22:52:30 --> Final output sent to browser
DEBUG - 2017-12-16 22:52:30 --> Total execution time: 0.0384
INFO - 2017-12-16 23:35:52 --> Config Class Initialized
INFO - 2017-12-16 23:35:52 --> Hooks Class Initialized
DEBUG - 2017-12-16 23:35:52 --> UTF-8 Support Enabled
INFO - 2017-12-16 23:35:52 --> Utf8 Class Initialized
INFO - 2017-12-16 23:35:52 --> URI Class Initialized
INFO - 2017-12-16 23:35:52 --> Router Class Initialized
INFO - 2017-12-16 23:35:52 --> Output Class Initialized
INFO - 2017-12-16 23:35:52 --> Security Class Initialized
DEBUG - 2017-12-16 23:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 23:35:52 --> Input Class Initialized
INFO - 2017-12-16 23:35:52 --> Language Class Initialized
INFO - 2017-12-16 23:35:52 --> Loader Class Initialized
INFO - 2017-12-16 23:35:52 --> Helper loaded: url_helper
INFO - 2017-12-16 23:35:52 --> Helper loaded: form_helper
INFO - 2017-12-16 23:35:52 --> Database Driver Class Initialized
DEBUG - 2017-12-16 23:35:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 23:35:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 23:35:52 --> Form Validation Class Initialized
INFO - 2017-12-16 23:35:52 --> Model Class Initialized
INFO - 2017-12-16 23:35:52 --> Controller Class Initialized
INFO - 2017-12-16 23:35:52 --> Model Class Initialized
INFO - 2017-12-16 23:35:52 --> Model Class Initialized
INFO - 2017-12-16 23:35:52 --> Model Class Initialized
DEBUG - 2017-12-16 23:35:52 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2017-12-16 23:35:52 --> Severity: Notice --> Undefined variable: clientes D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\index.php 45
ERROR - 2017-12-16 23:35:52 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\index.php 45
ERROR - 2017-12-16 23:35:52 --> Severity: Notice --> Undefined variable: proyecto_estados D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\index.php 55
ERROR - 2017-12-16 23:35:52 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\index.php 55
INFO - 2017-12-16 23:35:52 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-16 23:35:52 --> Final output sent to browser
DEBUG - 2017-12-16 23:35:52 --> Total execution time: 0.0902
INFO - 2017-12-16 23:36:05 --> Config Class Initialized
INFO - 2017-12-16 23:36:05 --> Hooks Class Initialized
DEBUG - 2017-12-16 23:36:05 --> UTF-8 Support Enabled
INFO - 2017-12-16 23:36:05 --> Utf8 Class Initialized
INFO - 2017-12-16 23:36:05 --> URI Class Initialized
INFO - 2017-12-16 23:36:05 --> Router Class Initialized
INFO - 2017-12-16 23:36:05 --> Output Class Initialized
INFO - 2017-12-16 23:36:05 --> Security Class Initialized
DEBUG - 2017-12-16 23:36:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 23:36:05 --> Input Class Initialized
INFO - 2017-12-16 23:36:05 --> Language Class Initialized
INFO - 2017-12-16 23:36:05 --> Loader Class Initialized
INFO - 2017-12-16 23:36:05 --> Helper loaded: url_helper
INFO - 2017-12-16 23:36:05 --> Helper loaded: form_helper
INFO - 2017-12-16 23:36:05 --> Database Driver Class Initialized
DEBUG - 2017-12-16 23:36:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 23:36:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 23:36:05 --> Form Validation Class Initialized
INFO - 2017-12-16 23:36:05 --> Model Class Initialized
INFO - 2017-12-16 23:36:05 --> Controller Class Initialized
INFO - 2017-12-16 23:36:05 --> Model Class Initialized
INFO - 2017-12-16 23:36:05 --> Model Class Initialized
INFO - 2017-12-16 23:36:05 --> Model Class Initialized
DEBUG - 2017-12-16 23:36:05 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2017-12-16 23:36:05 --> Severity: Notice --> Undefined variable: clientes D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\index.php 45
ERROR - 2017-12-16 23:36:05 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\index.php 45
ERROR - 2017-12-16 23:36:05 --> Severity: Notice --> Undefined variable: proyecto_estados D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\index.php 55
ERROR - 2017-12-16 23:36:05 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\instateccr\instatec_app\views\proyecto\index.php 55
INFO - 2017-12-16 23:36:05 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-16 23:36:05 --> Final output sent to browser
DEBUG - 2017-12-16 23:36:05 --> Total execution time: 0.0615
INFO - 2017-12-16 23:38:16 --> Config Class Initialized
INFO - 2017-12-16 23:38:16 --> Hooks Class Initialized
DEBUG - 2017-12-16 23:38:16 --> UTF-8 Support Enabled
INFO - 2017-12-16 23:38:16 --> Utf8 Class Initialized
INFO - 2017-12-16 23:38:16 --> URI Class Initialized
INFO - 2017-12-16 23:38:16 --> Router Class Initialized
INFO - 2017-12-16 23:38:16 --> Output Class Initialized
INFO - 2017-12-16 23:38:16 --> Security Class Initialized
DEBUG - 2017-12-16 23:38:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 23:38:16 --> Input Class Initialized
INFO - 2017-12-16 23:38:16 --> Language Class Initialized
INFO - 2017-12-16 23:38:16 --> Loader Class Initialized
INFO - 2017-12-16 23:38:16 --> Helper loaded: url_helper
INFO - 2017-12-16 23:38:16 --> Helper loaded: form_helper
INFO - 2017-12-16 23:38:16 --> Database Driver Class Initialized
DEBUG - 2017-12-16 23:38:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 23:38:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 23:38:16 --> Form Validation Class Initialized
INFO - 2017-12-16 23:38:16 --> Model Class Initialized
INFO - 2017-12-16 23:38:16 --> Controller Class Initialized
INFO - 2017-12-16 23:38:16 --> Model Class Initialized
INFO - 2017-12-16 23:38:16 --> Model Class Initialized
INFO - 2017-12-16 23:38:16 --> Model Class Initialized
DEBUG - 2017-12-16 23:38:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 23:38:16 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-16 23:38:16 --> Final output sent to browser
DEBUG - 2017-12-16 23:38:16 --> Total execution time: 0.0548
INFO - 2017-12-16 23:45:02 --> Config Class Initialized
INFO - 2017-12-16 23:45:02 --> Hooks Class Initialized
DEBUG - 2017-12-16 23:45:02 --> UTF-8 Support Enabled
INFO - 2017-12-16 23:45:02 --> Utf8 Class Initialized
INFO - 2017-12-16 23:45:02 --> URI Class Initialized
INFO - 2017-12-16 23:45:02 --> Router Class Initialized
INFO - 2017-12-16 23:45:02 --> Output Class Initialized
INFO - 2017-12-16 23:45:02 --> Security Class Initialized
DEBUG - 2017-12-16 23:45:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 23:45:02 --> Input Class Initialized
INFO - 2017-12-16 23:45:02 --> Language Class Initialized
INFO - 2017-12-16 23:45:02 --> Loader Class Initialized
INFO - 2017-12-16 23:45:02 --> Helper loaded: url_helper
INFO - 2017-12-16 23:45:02 --> Helper loaded: form_helper
INFO - 2017-12-16 23:45:02 --> Database Driver Class Initialized
DEBUG - 2017-12-16 23:45:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 23:45:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 23:45:02 --> Form Validation Class Initialized
INFO - 2017-12-16 23:45:02 --> Model Class Initialized
INFO - 2017-12-16 23:45:02 --> Controller Class Initialized
INFO - 2017-12-16 23:45:02 --> Model Class Initialized
INFO - 2017-12-16 23:45:02 --> Model Class Initialized
INFO - 2017-12-16 23:45:02 --> Model Class Initialized
DEBUG - 2017-12-16 23:45:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 23:45:02 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-16 23:45:02 --> Final output sent to browser
DEBUG - 2017-12-16 23:45:02 --> Total execution time: 0.0787
INFO - 2017-12-16 23:46:19 --> Config Class Initialized
INFO - 2017-12-16 23:46:19 --> Hooks Class Initialized
DEBUG - 2017-12-16 23:46:19 --> UTF-8 Support Enabled
INFO - 2017-12-16 23:46:19 --> Utf8 Class Initialized
INFO - 2017-12-16 23:46:19 --> URI Class Initialized
INFO - 2017-12-16 23:46:19 --> Router Class Initialized
INFO - 2017-12-16 23:46:19 --> Output Class Initialized
INFO - 2017-12-16 23:46:19 --> Security Class Initialized
DEBUG - 2017-12-16 23:46:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 23:46:19 --> Input Class Initialized
INFO - 2017-12-16 23:46:19 --> Language Class Initialized
INFO - 2017-12-16 23:46:19 --> Loader Class Initialized
INFO - 2017-12-16 23:46:19 --> Helper loaded: url_helper
INFO - 2017-12-16 23:46:19 --> Helper loaded: form_helper
INFO - 2017-12-16 23:46:19 --> Database Driver Class Initialized
DEBUG - 2017-12-16 23:46:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 23:46:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 23:46:19 --> Form Validation Class Initialized
INFO - 2017-12-16 23:46:19 --> Model Class Initialized
INFO - 2017-12-16 23:46:19 --> Controller Class Initialized
INFO - 2017-12-16 23:46:19 --> Model Class Initialized
INFO - 2017-12-16 23:46:19 --> Model Class Initialized
INFO - 2017-12-16 23:46:19 --> Model Class Initialized
DEBUG - 2017-12-16 23:46:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 23:46:19 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-16 23:46:19 --> Final output sent to browser
DEBUG - 2017-12-16 23:46:19 --> Total execution time: 0.0762
INFO - 2017-12-16 23:51:18 --> Config Class Initialized
INFO - 2017-12-16 23:51:18 --> Hooks Class Initialized
DEBUG - 2017-12-16 23:51:18 --> UTF-8 Support Enabled
INFO - 2017-12-16 23:51:18 --> Utf8 Class Initialized
INFO - 2017-12-16 23:51:18 --> URI Class Initialized
INFO - 2017-12-16 23:51:18 --> Router Class Initialized
INFO - 2017-12-16 23:51:18 --> Output Class Initialized
INFO - 2017-12-16 23:51:18 --> Security Class Initialized
DEBUG - 2017-12-16 23:51:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 23:51:18 --> Input Class Initialized
INFO - 2017-12-16 23:51:18 --> Language Class Initialized
INFO - 2017-12-16 23:51:18 --> Loader Class Initialized
INFO - 2017-12-16 23:51:18 --> Helper loaded: url_helper
INFO - 2017-12-16 23:51:18 --> Helper loaded: form_helper
INFO - 2017-12-16 23:51:18 --> Database Driver Class Initialized
DEBUG - 2017-12-16 23:51:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 23:51:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 23:51:18 --> Form Validation Class Initialized
INFO - 2017-12-16 23:51:18 --> Model Class Initialized
INFO - 2017-12-16 23:51:18 --> Controller Class Initialized
INFO - 2017-12-16 23:51:18 --> Model Class Initialized
INFO - 2017-12-16 23:51:18 --> Model Class Initialized
INFO - 2017-12-16 23:51:18 --> Model Class Initialized
DEBUG - 2017-12-16 23:51:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 23:51:18 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-16 23:51:18 --> Final output sent to browser
DEBUG - 2017-12-16 23:51:18 --> Total execution time: 0.0652
INFO - 2017-12-16 23:53:23 --> Config Class Initialized
INFO - 2017-12-16 23:53:23 --> Hooks Class Initialized
DEBUG - 2017-12-16 23:53:23 --> UTF-8 Support Enabled
INFO - 2017-12-16 23:53:23 --> Utf8 Class Initialized
INFO - 2017-12-16 23:53:23 --> URI Class Initialized
INFO - 2017-12-16 23:53:23 --> Router Class Initialized
INFO - 2017-12-16 23:53:23 --> Output Class Initialized
INFO - 2017-12-16 23:53:23 --> Security Class Initialized
DEBUG - 2017-12-16 23:53:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 23:53:23 --> Input Class Initialized
INFO - 2017-12-16 23:53:23 --> Language Class Initialized
INFO - 2017-12-16 23:53:23 --> Loader Class Initialized
INFO - 2017-12-16 23:53:23 --> Helper loaded: url_helper
INFO - 2017-12-16 23:53:23 --> Helper loaded: form_helper
INFO - 2017-12-16 23:53:23 --> Database Driver Class Initialized
DEBUG - 2017-12-16 23:53:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 23:53:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 23:53:23 --> Form Validation Class Initialized
INFO - 2017-12-16 23:53:23 --> Model Class Initialized
INFO - 2017-12-16 23:53:23 --> Controller Class Initialized
INFO - 2017-12-16 23:53:23 --> Model Class Initialized
INFO - 2017-12-16 23:53:23 --> Model Class Initialized
INFO - 2017-12-16 23:53:23 --> Model Class Initialized
DEBUG - 2017-12-16 23:53:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 23:53:23 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-16 23:53:23 --> Final output sent to browser
DEBUG - 2017-12-16 23:53:23 --> Total execution time: 0.1622
INFO - 2017-12-16 23:53:32 --> Config Class Initialized
INFO - 2017-12-16 23:53:32 --> Hooks Class Initialized
DEBUG - 2017-12-16 23:53:32 --> UTF-8 Support Enabled
INFO - 2017-12-16 23:53:32 --> Utf8 Class Initialized
INFO - 2017-12-16 23:53:32 --> URI Class Initialized
INFO - 2017-12-16 23:53:32 --> Router Class Initialized
INFO - 2017-12-16 23:53:32 --> Output Class Initialized
INFO - 2017-12-16 23:53:32 --> Security Class Initialized
DEBUG - 2017-12-16 23:53:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 23:53:32 --> Input Class Initialized
INFO - 2017-12-16 23:53:32 --> Language Class Initialized
INFO - 2017-12-16 23:53:32 --> Loader Class Initialized
INFO - 2017-12-16 23:53:32 --> Helper loaded: url_helper
INFO - 2017-12-16 23:53:32 --> Helper loaded: form_helper
INFO - 2017-12-16 23:53:32 --> Database Driver Class Initialized
DEBUG - 2017-12-16 23:53:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 23:53:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 23:53:32 --> Form Validation Class Initialized
INFO - 2017-12-16 23:53:32 --> Model Class Initialized
INFO - 2017-12-16 23:53:32 --> Controller Class Initialized
INFO - 2017-12-16 23:53:32 --> Model Class Initialized
INFO - 2017-12-16 23:53:32 --> Model Class Initialized
INFO - 2017-12-16 23:53:32 --> Model Class Initialized
DEBUG - 2017-12-16 23:53:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 23:53:32 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-16 23:53:32 --> Final output sent to browser
DEBUG - 2017-12-16 23:53:32 --> Total execution time: 0.0856
INFO - 2017-12-16 23:53:33 --> Config Class Initialized
INFO - 2017-12-16 23:53:33 --> Hooks Class Initialized
DEBUG - 2017-12-16 23:53:33 --> UTF-8 Support Enabled
INFO - 2017-12-16 23:53:33 --> Utf8 Class Initialized
INFO - 2017-12-16 23:53:33 --> URI Class Initialized
INFO - 2017-12-16 23:53:33 --> Router Class Initialized
INFO - 2017-12-16 23:53:33 --> Output Class Initialized
INFO - 2017-12-16 23:53:33 --> Security Class Initialized
DEBUG - 2017-12-16 23:53:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 23:53:33 --> Input Class Initialized
INFO - 2017-12-16 23:53:33 --> Language Class Initialized
ERROR - 2017-12-16 23:53:33 --> 404 Page Not Found: Faviconico/index
INFO - 2017-12-16 23:53:36 --> Config Class Initialized
INFO - 2017-12-16 23:53:36 --> Hooks Class Initialized
DEBUG - 2017-12-16 23:53:36 --> UTF-8 Support Enabled
INFO - 2017-12-16 23:53:36 --> Utf8 Class Initialized
INFO - 2017-12-16 23:53:36 --> URI Class Initialized
INFO - 2017-12-16 23:53:36 --> Router Class Initialized
INFO - 2017-12-16 23:53:36 --> Output Class Initialized
INFO - 2017-12-16 23:53:36 --> Security Class Initialized
DEBUG - 2017-12-16 23:53:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 23:53:36 --> Input Class Initialized
INFO - 2017-12-16 23:53:36 --> Language Class Initialized
INFO - 2017-12-16 23:53:36 --> Loader Class Initialized
INFO - 2017-12-16 23:53:36 --> Helper loaded: url_helper
INFO - 2017-12-16 23:53:36 --> Helper loaded: form_helper
INFO - 2017-12-16 23:53:36 --> Database Driver Class Initialized
DEBUG - 2017-12-16 23:53:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 23:53:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 23:53:36 --> Form Validation Class Initialized
INFO - 2017-12-16 23:53:36 --> Model Class Initialized
INFO - 2017-12-16 23:53:36 --> Controller Class Initialized
INFO - 2017-12-16 23:53:36 --> Model Class Initialized
INFO - 2017-12-16 23:53:36 --> Model Class Initialized
INFO - 2017-12-16 23:53:36 --> Model Class Initialized
DEBUG - 2017-12-16 23:53:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 23:53:36 --> Final output sent to browser
DEBUG - 2017-12-16 23:53:36 --> Total execution time: 0.0439
INFO - 2017-12-16 23:53:37 --> Config Class Initialized
INFO - 2017-12-16 23:53:37 --> Hooks Class Initialized
DEBUG - 2017-12-16 23:53:37 --> UTF-8 Support Enabled
INFO - 2017-12-16 23:53:37 --> Utf8 Class Initialized
INFO - 2017-12-16 23:53:37 --> URI Class Initialized
INFO - 2017-12-16 23:53:37 --> Router Class Initialized
INFO - 2017-12-16 23:53:37 --> Output Class Initialized
INFO - 2017-12-16 23:53:37 --> Security Class Initialized
DEBUG - 2017-12-16 23:53:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 23:53:37 --> Input Class Initialized
INFO - 2017-12-16 23:53:37 --> Language Class Initialized
INFO - 2017-12-16 23:53:37 --> Loader Class Initialized
INFO - 2017-12-16 23:53:37 --> Helper loaded: url_helper
INFO - 2017-12-16 23:53:37 --> Helper loaded: form_helper
INFO - 2017-12-16 23:53:37 --> Database Driver Class Initialized
DEBUG - 2017-12-16 23:53:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 23:53:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 23:53:37 --> Form Validation Class Initialized
INFO - 2017-12-16 23:53:37 --> Model Class Initialized
INFO - 2017-12-16 23:53:37 --> Controller Class Initialized
INFO - 2017-12-16 23:53:37 --> Model Class Initialized
INFO - 2017-12-16 23:53:37 --> Model Class Initialized
INFO - 2017-12-16 23:53:37 --> Model Class Initialized
DEBUG - 2017-12-16 23:53:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 23:53:37 --> Config Class Initialized
INFO - 2017-12-16 23:53:37 --> Hooks Class Initialized
DEBUG - 2017-12-16 23:53:37 --> UTF-8 Support Enabled
INFO - 2017-12-16 23:53:37 --> Utf8 Class Initialized
INFO - 2017-12-16 23:53:37 --> URI Class Initialized
INFO - 2017-12-16 23:53:37 --> Router Class Initialized
INFO - 2017-12-16 23:53:37 --> Output Class Initialized
INFO - 2017-12-16 23:53:37 --> Security Class Initialized
DEBUG - 2017-12-16 23:53:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 23:53:37 --> Input Class Initialized
INFO - 2017-12-16 23:53:37 --> Language Class Initialized
INFO - 2017-12-16 23:53:37 --> Loader Class Initialized
INFO - 2017-12-16 23:53:37 --> Helper loaded: url_helper
INFO - 2017-12-16 23:53:37 --> Helper loaded: form_helper
INFO - 2017-12-16 23:53:37 --> Database Driver Class Initialized
DEBUG - 2017-12-16 23:53:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 23:53:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 23:53:37 --> Form Validation Class Initialized
INFO - 2017-12-16 23:53:37 --> Model Class Initialized
INFO - 2017-12-16 23:53:37 --> Controller Class Initialized
INFO - 2017-12-16 23:53:37 --> Model Class Initialized
INFO - 2017-12-16 23:53:37 --> Model Class Initialized
INFO - 2017-12-16 23:53:37 --> Model Class Initialized
DEBUG - 2017-12-16 23:53:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 23:53:37 --> Final output sent to browser
DEBUG - 2017-12-16 23:53:37 --> Total execution time: 0.0541
INFO - 2017-12-16 23:53:38 --> Config Class Initialized
INFO - 2017-12-16 23:53:38 --> Hooks Class Initialized
DEBUG - 2017-12-16 23:53:38 --> UTF-8 Support Enabled
INFO - 2017-12-16 23:53:38 --> Utf8 Class Initialized
INFO - 2017-12-16 23:53:38 --> URI Class Initialized
INFO - 2017-12-16 23:53:38 --> Router Class Initialized
INFO - 2017-12-16 23:53:38 --> Output Class Initialized
INFO - 2017-12-16 23:53:38 --> Security Class Initialized
DEBUG - 2017-12-16 23:53:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 23:53:38 --> Input Class Initialized
INFO - 2017-12-16 23:53:38 --> Language Class Initialized
INFO - 2017-12-16 23:53:38 --> Loader Class Initialized
INFO - 2017-12-16 23:53:38 --> Helper loaded: url_helper
INFO - 2017-12-16 23:53:38 --> Helper loaded: form_helper
INFO - 2017-12-16 23:53:38 --> Database Driver Class Initialized
DEBUG - 2017-12-16 23:53:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 23:53:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 23:53:38 --> Form Validation Class Initialized
INFO - 2017-12-16 23:53:38 --> Model Class Initialized
INFO - 2017-12-16 23:53:38 --> Controller Class Initialized
INFO - 2017-12-16 23:53:38 --> Model Class Initialized
INFO - 2017-12-16 23:53:38 --> Model Class Initialized
INFO - 2017-12-16 23:53:38 --> Model Class Initialized
DEBUG - 2017-12-16 23:53:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 23:53:41 --> Config Class Initialized
INFO - 2017-12-16 23:53:41 --> Hooks Class Initialized
DEBUG - 2017-12-16 23:53:41 --> UTF-8 Support Enabled
INFO - 2017-12-16 23:53:41 --> Utf8 Class Initialized
INFO - 2017-12-16 23:53:41 --> URI Class Initialized
INFO - 2017-12-16 23:53:41 --> Router Class Initialized
INFO - 2017-12-16 23:53:41 --> Output Class Initialized
INFO - 2017-12-16 23:53:41 --> Security Class Initialized
DEBUG - 2017-12-16 23:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 23:53:41 --> Input Class Initialized
INFO - 2017-12-16 23:53:41 --> Language Class Initialized
INFO - 2017-12-16 23:53:41 --> Loader Class Initialized
INFO - 2017-12-16 23:53:41 --> Helper loaded: url_helper
INFO - 2017-12-16 23:53:41 --> Helper loaded: form_helper
INFO - 2017-12-16 23:53:41 --> Database Driver Class Initialized
DEBUG - 2017-12-16 23:53:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 23:53:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 23:53:41 --> Form Validation Class Initialized
INFO - 2017-12-16 23:53:41 --> Model Class Initialized
INFO - 2017-12-16 23:53:41 --> Controller Class Initialized
INFO - 2017-12-16 23:53:41 --> Model Class Initialized
INFO - 2017-12-16 23:53:41 --> Model Class Initialized
INFO - 2017-12-16 23:53:41 --> Model Class Initialized
DEBUG - 2017-12-16 23:53:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 23:53:41 --> Config Class Initialized
INFO - 2017-12-16 23:53:41 --> Hooks Class Initialized
DEBUG - 2017-12-16 23:53:41 --> UTF-8 Support Enabled
INFO - 2017-12-16 23:53:41 --> Utf8 Class Initialized
INFO - 2017-12-16 23:53:41 --> URI Class Initialized
INFO - 2017-12-16 23:53:41 --> Router Class Initialized
INFO - 2017-12-16 23:53:41 --> Output Class Initialized
INFO - 2017-12-16 23:53:41 --> Security Class Initialized
DEBUG - 2017-12-16 23:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 23:53:41 --> Input Class Initialized
INFO - 2017-12-16 23:53:41 --> Language Class Initialized
INFO - 2017-12-16 23:53:41 --> Loader Class Initialized
INFO - 2017-12-16 23:53:41 --> Helper loaded: url_helper
INFO - 2017-12-16 23:53:41 --> Helper loaded: form_helper
INFO - 2017-12-16 23:53:41 --> Database Driver Class Initialized
DEBUG - 2017-12-16 23:53:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 23:53:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 23:53:41 --> Form Validation Class Initialized
INFO - 2017-12-16 23:53:41 --> Model Class Initialized
INFO - 2017-12-16 23:53:41 --> Controller Class Initialized
INFO - 2017-12-16 23:53:41 --> Model Class Initialized
INFO - 2017-12-16 23:53:41 --> Model Class Initialized
INFO - 2017-12-16 23:53:41 --> Model Class Initialized
DEBUG - 2017-12-16 23:53:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 23:58:14 --> Config Class Initialized
INFO - 2017-12-16 23:58:14 --> Hooks Class Initialized
DEBUG - 2017-12-16 23:58:14 --> UTF-8 Support Enabled
INFO - 2017-12-16 23:58:14 --> Utf8 Class Initialized
INFO - 2017-12-16 23:58:14 --> URI Class Initialized
INFO - 2017-12-16 23:58:14 --> Router Class Initialized
INFO - 2017-12-16 23:58:14 --> Output Class Initialized
INFO - 2017-12-16 23:58:14 --> Security Class Initialized
DEBUG - 2017-12-16 23:58:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 23:58:14 --> Input Class Initialized
INFO - 2017-12-16 23:58:14 --> Language Class Initialized
INFO - 2017-12-16 23:58:14 --> Loader Class Initialized
INFO - 2017-12-16 23:58:14 --> Helper loaded: url_helper
INFO - 2017-12-16 23:58:14 --> Helper loaded: form_helper
INFO - 2017-12-16 23:58:14 --> Database Driver Class Initialized
DEBUG - 2017-12-16 23:58:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 23:58:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 23:58:14 --> Form Validation Class Initialized
INFO - 2017-12-16 23:58:14 --> Model Class Initialized
INFO - 2017-12-16 23:58:14 --> Controller Class Initialized
INFO - 2017-12-16 23:58:14 --> Model Class Initialized
INFO - 2017-12-16 23:58:14 --> Model Class Initialized
INFO - 2017-12-16 23:58:14 --> Model Class Initialized
DEBUG - 2017-12-16 23:58:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-12-16 23:58:14 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2017-12-16 23:58:14 --> Final output sent to browser
DEBUG - 2017-12-16 23:58:14 --> Total execution time: 0.0656
INFO - 2017-12-16 23:58:15 --> Config Class Initialized
INFO - 2017-12-16 23:58:15 --> Hooks Class Initialized
DEBUG - 2017-12-16 23:58:15 --> UTF-8 Support Enabled
INFO - 2017-12-16 23:58:15 --> Utf8 Class Initialized
INFO - 2017-12-16 23:58:15 --> URI Class Initialized
INFO - 2017-12-16 23:58:15 --> Router Class Initialized
INFO - 2017-12-16 23:58:15 --> Output Class Initialized
INFO - 2017-12-16 23:58:15 --> Security Class Initialized
DEBUG - 2017-12-16 23:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 23:58:15 --> Input Class Initialized
INFO - 2017-12-16 23:58:15 --> Language Class Initialized
INFO - 2017-12-16 23:58:15 --> Loader Class Initialized
INFO - 2017-12-16 23:58:15 --> Helper loaded: url_helper
INFO - 2017-12-16 23:58:15 --> Helper loaded: form_helper
INFO - 2017-12-16 23:58:15 --> Database Driver Class Initialized
DEBUG - 2017-12-16 23:58:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 23:58:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 23:58:15 --> Form Validation Class Initialized
INFO - 2017-12-16 23:58:15 --> Model Class Initialized
INFO - 2017-12-16 23:58:15 --> Controller Class Initialized
INFO - 2017-12-16 23:58:15 --> Model Class Initialized
INFO - 2017-12-16 23:58:15 --> Model Class Initialized
DEBUG - 2017-12-16 23:58:15 --> Form_validation class already loaded. Second attempt ignored.
