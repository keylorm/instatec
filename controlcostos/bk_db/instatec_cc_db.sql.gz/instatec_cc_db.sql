-- MySQL dump 10.13  Distrib 5.6.38, for Linux (x86_64)
--
-- Host: localhost    Database: instatec_cc_db
-- ------------------------------------------------------
-- Server version	5.6.38

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `canton`
--

DROP TABLE IF EXISTS `canton`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `canton` (
  `canton_id` int(11) NOT NULL AUTO_INCREMENT,
  `provincia_id` int(11) NOT NULL,
  `canton_id_provincia` int(11) NOT NULL,
  `canton` varchar(40) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`canton_id`)
) ENGINE=InnoDB AUTO_INCREMENT=83 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `canton`
--

LOCK TABLES `canton` WRITE;
/*!40000 ALTER TABLE `canton` DISABLE KEYS */;
INSERT INTO `canton` (`canton_id`, `provincia_id`, `canton_id_provincia`, `canton`) VALUES (1,1,1,'San José'),(2,1,2,'Escazú'),(3,1,3,'Desamparados'),(4,1,4,'Puriscal'),(5,1,5,'Tarrazú'),(6,1,6,'Aserrí'),(7,1,7,'Mora'),(8,1,8,'Goicoechea'),(9,1,9,'Santa Ana'),(10,1,10,'Alajuelita'),(11,1,11,'Vásquez de Coronado'),(12,1,12,'Acosta'),(13,1,13,'Tibás'),(14,1,14,'Moravia'),(15,1,15,'Montes de Oca'),(16,1,16,'Turrubares'),(17,1,17,'Dota'),(18,1,18,'Curridabat'),(19,1,19,'Pérez Zeledón'),(20,1,20,'León Cortés'),(21,2,1,'Alajuela'),(22,2,2,'San Ramón'),(23,2,3,'Grecia'),(24,2,4,'San Mateo'),(25,2,5,'Atenas'),(26,2,6,'Naranjo'),(27,2,7,'Palmares'),(28,2,8,'Poás'),(29,2,9,'Orotina'),(30,2,10,'San Carlos'),(31,2,11,'Zarcero'),(32,2,12,'Valverde Vega'),(33,2,13,'Upala'),(34,2,14,'Los Chiles'),(35,2,15,'Guatuso'),(36,2,16,'Río Cuarto'),(37,3,1,'Cartago'),(38,3,2,'Paraíso'),(39,3,3,'La Unión'),(40,3,4,'Jiménez'),(41,3,5,'Turrialba'),(42,3,6,'Alvarado'),(43,3,7,'Oreamuno'),(44,3,8,'El Guarco'),(45,4,1,'Heredia'),(46,4,2,'Barva'),(47,4,3,'Santo Domingo'),(48,4,4,'Santa Bárbara'),(49,4,5,'San Rafael'),(50,4,6,'San Isidro'),(51,4,7,'Belén'),(52,4,8,'Flores'),(53,4,9,'San Pablo'),(54,4,10,'Sarapiquí'),(55,5,1,'Liberia'),(56,5,2,'Nicoya'),(57,5,3,'Santa Cruz'),(58,5,4,'Bagaces'),(59,5,5,'Carrillo'),(60,5,6,'Cañas'),(61,5,7,'Abangares'),(62,5,8,'Tilarán'),(63,5,9,'Nandayure'),(64,5,10,'La Cruz'),(65,5,11,'Hojancha'),(66,6,1,'Puntarenas'),(67,6,2,'Esparza'),(68,6,3,'Buenos Aires'),(69,6,4,'Montes de Oro'),(70,6,5,'Osa'),(71,6,6,'Quepos'),(72,6,7,'Golfito'),(73,6,8,'Coto Brus'),(74,6,9,'Parrita'),(75,6,10,'Corredores'),(76,6,11,'Garabito'),(77,7,1,'Limón'),(78,7,2,'Pococí'),(79,7,3,'Siquirres'),(80,7,4,'Talamanca'),(81,7,5,'Matina'),(82,7,6,'Guácimo');
/*!40000 ALTER TABLE `canton` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cliente`
--

DROP TABLE IF EXISTS `cliente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cliente` (
  `cliente_id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario_id` int(11) NOT NULL,
  `fecha_registro` datetime NOT NULL,
  `nombre_cliente` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `cedula_cliente` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `estado_cliente` int(11) NOT NULL COMMENT '0 para inactivo, 1 para activo',
  PRIMARY KEY (`cliente_id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cliente`
--

LOCK TABLES `cliente` WRITE;
/*!40000 ALTER TABLE `cliente` DISABLE KEYS */;
INSERT INTO `cliente` (`cliente_id`, `usuario_id`, `fecha_registro`, `nombre_cliente`, `cedula_cliente`, `estado_cliente`) VALUES (16,1,'2018-01-18 07:34:24','CONSTRUCTORA PROYCON','3101094864',1),(17,1,'2018-01-18 07:36:45','BILCO COSTA RICA ','3101595426',1),(18,1,'2018-01-18 07:38:38','EDICA LIMITADA','3101005810',1),(19,1,'2018-01-18 12:19:39','ALUMIMUNDO','3101086859',1),(20,1,'2018-01-18 12:20:56','VAN DER LAAT Y JIMENEZ SA','3101012553',1),(21,1,'2018-01-18 12:20:57','VAN DER LAAT Y JIMENEZ SA','3101012553',1),(22,1,'2018-01-19 15:30:26','Van Oord – BAM Limitada','3-102-658980',1),(23,1,'2018-01-20 07:27:55','VOLIO Y TREJOS ASOCIADOS, S.A','3-101- 058988-25',1);
/*!40000 ALTER TABLE `cliente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cliente_correo`
--

DROP TABLE IF EXISTS `cliente_correo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cliente_correo` (
  `cliente_correo_id` int(11) NOT NULL AUTO_INCREMENT,
  `cliente_id` int(11) NOT NULL,
  `correo_cliente` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`cliente_correo_id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cliente_correo`
--

LOCK TABLES `cliente_correo` WRITE;
/*!40000 ALTER TABLE `cliente_correo` DISABLE KEYS */;
INSERT INTO `cliente_correo` (`cliente_correo_id`, `cliente_id`, `correo_cliente`) VALUES (20,16,'info@proycon.com'),(21,17,'info@bilcocr.com'),(22,18,'contactus@edica.co.cr'),(23,19,'cmontero@alumimundo.com'),(24,22,'juan.rivera@vobamcb.com'),(25,23,'alejandro_araya@volioytrejos.com ');
/*!40000 ALTER TABLE `cliente_correo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cliente_telefono`
--

DROP TABLE IF EXISTS `cliente_telefono`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cliente_telefono` (
  `cliente_telefono_id` int(11) NOT NULL AUTO_INCREMENT,
  `cliente_id` int(11) NOT NULL,
  `telefono_cliente` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`cliente_telefono_id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cliente_telefono`
--

LOCK TABLES `cliente_telefono` WRITE;
/*!40000 ALTER TABLE `cliente_telefono` DISABLE KEYS */;
INSERT INTO `cliente_telefono` (`cliente_telefono_id`, `cliente_id`, `telefono_cliente`) VALUES (19,16,'22967090'),(20,17,'22885051'),(21,18,'22224511'),(22,19,'41018600'),(23,22,'+506 6046-3027'),(24,23,'88248703');
/*!40000 ALTER TABLE `cliente_telefono` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `colaborador`
--

DROP TABLE IF EXISTS `colaborador`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `colaborador` (
  `colaborador_id` int(11) NOT NULL AUTO_INCREMENT,
  `colaborador_puesto_id` int(11) NOT NULL,
  `nombre` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `apellidos` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `correo_electronico` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `cedula` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `seguro_social` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `identificador_interno` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `telefono` varchar(20) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`colaborador_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `colaborador`
--

LOCK TABLES `colaborador` WRITE;
/*!40000 ALTER TABLE `colaborador` DISABLE KEYS */;
/*!40000 ALTER TABLE `colaborador` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `colaborador_costo_hora`
--

DROP TABLE IF EXISTS `colaborador_costo_hora`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `colaborador_costo_hora` (
  `colaborador_costo_hora_id` int(11) NOT NULL AUTO_INCREMENT,
  `colaborador_id` int(11) NOT NULL,
  `moneda_id` int(11) NOT NULL,
  `fecha_registro` datetime NOT NULL,
  `costo_hora` float(10,2) NOT NULL,
  `estado_costo` int(11) NOT NULL COMMENT '0 es inactivo, 1 es activo',
  PRIMARY KEY (`colaborador_costo_hora_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `colaborador_costo_hora`
--

LOCK TABLES `colaborador_costo_hora` WRITE;
/*!40000 ALTER TABLE `colaborador_costo_hora` DISABLE KEYS */;
/*!40000 ALTER TABLE `colaborador_costo_hora` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `colaborador_puesto`
--

DROP TABLE IF EXISTS `colaborador_puesto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `colaborador_puesto` (
  `colaborador_puesto_id` int(11) NOT NULL AUTO_INCREMENT,
  `puesto` varchar(60) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`colaborador_puesto_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `colaborador_puesto`
--

LOCK TABLES `colaborador_puesto` WRITE;
/*!40000 ALTER TABLE `colaborador_puesto` DISABLE KEYS */;
/*!40000 ALTER TABLE `colaborador_puesto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `distrito`
--

DROP TABLE IF EXISTS `distrito`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `distrito` (
  `distrito_id` int(11) NOT NULL AUTO_INCREMENT,
  `canton_id` int(11) NOT NULL,
  `distrito_id_provincia` int(11) NOT NULL,
  `distrito` varchar(60) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`distrito_id`)
) ENGINE=InnoDB AUTO_INCREMENT=486 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `distrito`
--

LOCK TABLES `distrito` WRITE;
/*!40000 ALTER TABLE `distrito` DISABLE KEYS */;
INSERT INTO `distrito` (`distrito_id`, `canton_id`, `distrito_id_provincia`, `distrito`) VALUES (1,1,1,'Carmen'),(2,1,2,'Merced'),(3,1,3,'Hospital'),(4,1,4,'Catedral'),(5,1,5,'Zapote'),(6,1,6,'San Francisco de Dos Ríos'),(7,1,7,'Uruca'),(8,1,8,'Mata Redonda'),(9,1,9,'Pavas'),(10,1,10,'Hatillo'),(11,1,11,'San Sebastián'),(12,2,12,'Escazu'),(13,2,13,'San Antonio'),(14,2,14,'San Rafael'),(15,3,15,'Desamparados'),(16,3,16,'San Miguel'),(17,3,17,'San Juan de Dios'),(18,3,18,'San Rafael Arriba'),(19,3,19,'San Antonio'),(20,3,20,'Frailes'),(21,3,21,'Patarrá'),(22,3,22,'San Cristóbal'),(23,3,23,'Rosario'),(24,3,24,'Damas'),(25,3,25,'San Rafael Abajo'),(26,3,26,'Gravillas'),(27,3,27,'Los Guido'),(28,4,28,'Santiago'),(29,4,29,'Mercedes Sur'),(30,4,30,'Barbacoas'),(31,4,31,'Grito Alto'),(32,4,32,'San Rafael'),(33,4,33,'Candelarita'),(34,4,34,'Desamparaditos'),(35,4,35,'San Antonio'),(36,4,36,'Chires'),(37,4,37,'La Cangreja'),(38,5,38,'San Marcos'),(39,5,39,'San Lorenzo'),(40,5,40,'San Carlos'),(41,6,41,'Aserrí'),(42,6,42,'Tarbaca'),(43,6,43,'Vuelta de Jorco'),(44,6,44,'San Gabriel'),(45,6,45,'Legua'),(46,6,46,'Monterrey'),(47,6,47,'Salitrillos'),(48,7,48,'Ciudad Colón'),(49,7,49,'Guayabo'),(50,7,50,'Tabarcia'),(51,7,51,'Piedras Negras'),(52,7,52,'Picagres'),(53,7,53,'Jaris'),(54,7,54,'Quitirrisí'),(55,8,55,'Guadalupe'),(56,8,56,'San Francisco'),(57,8,57,'Calle Blancos'),(58,8,58,'Mata de Plátano'),(59,8,59,'Ipís'),(60,8,60,'Rancho Redondo'),(61,8,61,'Purral'),(62,9,62,'Santa Ana'),(63,9,63,'Salitral'),(64,9,64,'Pozos'),(65,9,65,'Uruca'),(66,9,66,'Piedades'),(67,9,67,'Brasil'),(68,10,68,'Alajuelita'),(69,10,69,'San Josecito'),(70,10,70,'San Antonio'),(71,10,71,'Concepción'),(72,10,72,'San Felipe'),(73,11,73,'San Isidro'),(74,11,74,'San Rafael'),(75,11,78,'Dulce Nombre de Jesús'),(76,11,76,'Patalillo'),(77,11,77,'Cascajal'),(78,12,78,'San Ignacio'),(79,12,79,'Guaitil'),(80,12,80,'Palmichal'),(81,12,81,'Cangrejal'),(82,12,82,'Sabanillas'),(83,13,83,'San Juan'),(84,13,84,'Cinco Esquinas'),(85,13,85,'Anselmo Llorente'),(86,13,86,'León XIII'),(87,13,87,'Colima'),(88,14,88,'San Vicente'),(89,14,89,'San Jerónimo'),(90,14,90,'Trinidad'),(91,15,91,'San Pedro'),(92,15,92,'Sabanilla'),(93,15,93,'Mercedes'),(94,15,94,'San Rafael'),(95,16,95,'San Pablo'),(96,16,96,'San Pedro'),(97,16,97,'San Juan de Mata'),(98,16,98,'San Luis'),(99,16,99,'Carara'),(100,17,100,'Santa María'),(101,17,101,'Jardín'),(102,17,102,'Copey'),(103,18,103,'Curridabat'),(104,18,104,'Granadilla'),(105,18,105,'Sánchez'),(106,18,106,'Tirrases'),(107,19,107,'San Isidro de El General'),(108,19,108,'El General'),(109,19,109,'Daniel Flores'),(110,19,110,'Rivas'),(111,19,111,'San Pedro'),(112,19,112,'Platanares'),(113,19,113,'Pejibaye'),(114,19,114,'Cajón'),(115,19,115,'Barú'),(116,19,116,'Río Nuevo'),(117,19,117,'Páramo'),(118,19,118,'La Amistad'),(119,20,119,'San Pablo'),(120,20,120,'San Andrés'),(121,20,121,'Llano Bonito'),(122,20,122,'San Isidro'),(123,20,123,'Santa Cruz'),(124,20,124,'San Antonio'),(125,21,1,'Alajuela'),(126,21,2,'San José'),(127,21,3,'Carrizal'),(128,21,4,'San Antonio'),(129,21,5,'Guácima'),(130,21,6,'San Isidro'),(131,21,7,'Sabanilla'),(132,21,8,'San Rafael'),(133,21,9,'Río Segundo'),(134,21,10,'Desamparados'),(135,21,11,'Turrícares'),(136,21,12,'Tambor'),(137,21,13,'Garita'),(138,21,14,'Sarapiquí'),(139,22,15,'San Ramón'),(140,22,16,'Santiago'),(141,22,17,'San Juan'),(142,22,18,'Piedades Norte'),(143,22,19,'Piedades Sur'),(144,22,20,'San Rafael'),(145,22,21,'San Isidro'),(146,22,22,'Ángeles'),(147,22,23,'Alfaro'),(148,22,24,'Volio'),(149,22,25,'Concepción'),(150,22,26,'Zapotal'),(151,22,27,'Peñas Blancas'),(152,22,28,'San Lorenzo'),(153,23,29,'Grecia'),(154,23,30,'San Isidro'),(155,23,31,'San José'),(156,23,32,'San Roque'),(157,23,33,'Tacares'),(158,23,34,'Puente de Piedra'),(159,23,35,'Bolívar'),(160,24,36,'San Mateo'),(161,24,37,'Desmonte'),(162,24,38,'Jesús María'),(163,24,39,'Labrador'),(164,25,40,'Atenas'),(165,25,41,'Jesús'),(166,25,42,'Mercedes'),(167,25,43,'San Isidro'),(168,25,44,'Concepción'),(169,25,45,'San José'),(170,25,46,'Santa Eulalia'),(171,25,47,'Escobal'),(172,26,48,'Naranjo'),(173,26,49,'San Miguel'),(174,26,50,'San José'),(175,26,51,'Cirrí'),(176,26,52,'San Jerónimo'),(177,26,53,'San Juan'),(178,26,54,'El Rosario'),(179,26,55,'Palmitos'),(180,27,56,'Palmares'),(181,27,57,'Zaragoza'),(182,27,58,'Buenos Aires'),(183,27,59,'Santiago'),(184,27,60,'Candelaria'),(185,27,61,'Esquipulas'),(186,27,62,'La Granja'),(187,28,63,'San Pedro'),(188,28,64,'San Juan'),(189,28,65,'San Rafael'),(190,28,66,'Carrillos'),(191,28,67,'Sabana Redonda'),(192,29,68,'Orotina'),(193,29,69,'Mastate'),(194,29,70,'Hacienda Vieja'),(195,29,71,'Coyolar'),(196,29,72,'La Ceiba'),(197,30,73,'Quesada'),(198,30,74,'Florencia'),(199,30,75,'Buenavista'),(200,30,76,'Aguas Zarcas'),(201,30,77,'Venecia'),(202,30,78,'Pital'),(203,30,79,'La Fortuna'),(204,30,80,'La Tigra'),(205,30,81,'La Palmera'),(206,30,82,'Venado'),(207,30,83,'Cutris'),(208,30,84,'Monterrey'),(209,30,85,'Pocosol'),(210,31,86,'Zarcero'),(211,31,87,'Laguna'),(212,31,88,'Tapezco'),(213,31,89,'Guadalupe'),(214,31,90,'Palmira'),(215,31,91,'Zapote'),(216,31,92,'Brisas'),(217,32,93,'Sarchí Norte'),(218,32,94,'Sarchí Sur'),(219,32,95,'Toro Amarillo'),(220,32,96,'San Pedro'),(221,32,97,'Rodríguez'),(222,33,98,'Upala'),(223,33,99,'Aguas Claras'),(224,33,100,'San José'),(225,33,101,'Bijagua'),(226,33,102,'Delicias'),(227,33,103,'Dos Ríos'),(228,33,104,'Yolillal'),(229,33,105,'Canalete'),(230,34,106,'Los Chiles'),(231,34,107,'Caño Negro'),(232,34,108,'El Amparo'),(233,34,109,'San Jorge'),(234,35,110,'San Rafael'),(235,35,111,'Buena Vista'),(236,35,112,'Cote'),(237,35,113,'Katira'),(238,36,114,'Río Cuarto'),(239,37,1,'Oriental'),(240,37,2,'Occidental'),(241,37,3,'Carmen'),(242,37,4,'San Nicolás'),(243,37,5,'Aguacaliente (San Francisco)'),(244,37,6,'Guadalupe (Arenilla)'),(245,37,7,'Corralillo'),(246,37,8,'Tierra Blanca'),(247,37,9,'Dulce Nombre'),(248,37,10,'Llano Grande'),(249,37,11,'Quebradilla'),(250,38,12,'Paraíso'),(251,38,13,'Santiago de Paraíso'),(252,38,14,'Orosi'),(253,38,15,'Cachí'),(254,38,16,'Llanos de Santa Lucía'),(255,39,17,'Tres Ríos'),(256,39,18,'San Diego'),(257,39,19,'San Juan'),(258,39,20,'San Rafael'),(259,39,21,'Concepción'),(260,39,22,'Dulce Nombre'),(261,39,23,'San Ramón'),(262,39,24,'Río Azul'),(263,40,25,'Juan Viñas'),(264,40,26,'Tucurrique'),(265,40,27,'Pejibaye'),(266,41,28,'Turrialba'),(267,41,29,'La Suiza'),(268,41,30,'Peralta'),(269,41,31,'Santa cruz'),(270,41,32,'Santa Teresita'),(271,41,33,'Pavones'),(272,41,34,'Tuis'),(273,41,35,'Tayutic'),(274,41,36,'Santa Rosa'),(275,41,37,'Tres Equis'),(276,41,38,'La Isabel'),(277,41,39,'Chirripó'),(278,42,40,'Pacayas'),(279,42,41,'Cervantes'),(280,42,42,'Capellades'),(281,43,43,'San Rafael'),(282,43,44,'Cot'),(283,43,45,'Potrero Cerrado'),(284,43,46,'Cipreses'),(285,43,47,'Santa Rosa'),(286,44,48,'Tejar'),(287,44,49,'San Isidro'),(288,44,50,'Tobosi'),(289,44,51,'Patio de Agua'),(290,45,1,'Heredia'),(291,45,2,'Mercedes'),(292,45,3,'San Francisco'),(293,45,4,'Ulloa'),(294,45,5,'Vara Blanca'),(295,46,6,'Barva'),(296,46,7,'San Pedro'),(297,46,8,'San Pablo'),(298,46,9,'San Roque'),(299,46,10,'Santa Lucía'),(300,46,11,'San José de la Montaña'),(301,47,12,'Santo Domingo'),(302,47,13,'San Vicente'),(303,47,14,'San Miguel'),(304,47,15,'Paracito'),(305,47,16,'Santo Tomás'),(306,47,17,'Santa Rosa'),(307,47,18,'Tures'),(308,47,19,'Pará'),(309,48,20,'Santa Bárbara'),(310,48,21,'San Pedro'),(311,48,22,'San Juan'),(312,48,23,'Jesús'),(313,48,24,'Santo Domingo'),(314,48,25,'Purabá'),(315,49,26,'San Rafael'),(316,49,27,'San Josecito'),(317,49,28,'Santiago'),(318,49,29,'Ángeles'),(319,49,30,'Concepción'),(320,50,31,'San Isidro'),(321,50,32,'San José'),(322,50,33,'Concepción'),(323,50,34,'San Francisco'),(324,51,35,'San Antonio'),(325,51,36,'La Ribera'),(326,51,37,'La Asunción'),(327,52,38,'San Joaquín'),(328,52,39,'Barrantes'),(329,52,40,'Llorente'),(330,53,41,'San Pablo'),(331,53,42,'Rincón de Sabanilla'),(332,54,43,'Puerto Viejo'),(333,54,44,'La Virgen'),(334,54,45,'Horquetas'),(335,54,46,'Llanuras del Gaspar'),(336,54,47,'Cureña'),(337,55,1,'Liberia'),(338,55,2,'Cañas Dulces'),(339,55,3,'Mayorga'),(340,55,4,'Nacascolo'),(341,55,5,'Curubandé'),(342,56,6,'Nicoya'),(343,56,7,'Mansión'),(344,56,8,'San Antonio'),(345,56,9,'Quebrada Honda'),(346,56,10,'Sámara'),(347,56,11,'Nosara'),(348,56,12,'Belén de Nosarita'),(349,57,13,'Santa Cruz'),(350,57,14,'Bolsón'),(351,57,15,'Veintisiete de Abril'),(352,57,16,'Tempate'),(353,57,17,'Cartagena'),(354,57,18,'Cuajiniquil'),(355,57,19,'Diriá'),(356,57,20,'Cabo Velas'),(357,57,21,'Tamarindo'),(358,58,22,'Bagaces'),(359,58,23,'La Fortuna'),(360,58,24,'Mogote'),(361,58,25,'Río Naranjo'),(362,59,26,'Filadelfia'),(363,59,27,'Palmira'),(364,59,28,'Sardinal'),(365,59,29,'Belén'),(366,60,30,'Cañas'),(367,60,31,'Palmira'),(368,60,32,'San Miguel'),(369,60,33,'Bebedero'),(370,60,34,'Porozal'),(371,61,35,'Las Juntas'),(372,61,36,'Sierra'),(373,61,37,'San Juan'),(374,61,38,'Colorado'),(375,62,39,'Tilarán'),(376,62,40,'Quebrada Grande'),(377,62,41,'Tronadora'),(378,62,42,'Santa Rosa'),(379,62,43,'Líbano'),(380,62,44,'Tierras Morenas'),(381,62,45,'Arenal'),(382,63,46,'Carmona'),(383,63,47,'Santa Rita'),(384,63,48,'Zapotal'),(385,63,49,'San Pablo'),(386,63,50,'Porvenir'),(387,63,51,'Bejuco'),(388,64,52,'La Cruz'),(389,64,53,'Santa Cecilia'),(390,64,54,'La Garita'),(391,64,55,'Santa Elena'),(392,65,56,'Hojancha'),(393,65,57,'Monte Romo'),(394,65,58,'Puerto Carrillo'),(395,65,59,'Huacas'),(396,65,60,'Matambú'),(397,66,1,'Puntarenas'),(398,66,2,'Pitahaya'),(399,66,3,'Chomes'),(400,66,4,'Lepanto'),(401,66,5,'Paquera'),(402,66,6,'Manzanillo'),(403,66,7,'Guacimal'),(404,66,8,'Barranca'),(405,66,9,'Monte Verde'),(406,66,10,'Isla del Coco'),(407,66,11,'Cóbano'),(408,66,12,'Chacarita'),(409,66,13,'Chira'),(410,66,14,'Acapulco'),(411,66,15,'El Roble'),(412,66,16,'Arancibia'),(413,67,17,'Espíritu Santo'),(414,67,18,'San Juan Grande'),(415,67,19,'Macacona'),(416,67,20,'San Rafael'),(417,67,21,'San Jerónimo'),(418,67,22,'Caldera'),(419,68,23,'Buenos Aires'),(420,68,24,'Volcán'),(421,68,25,'Potrero Grande'),(422,68,26,'Boruca'),(423,68,27,'Pilas'),(424,68,28,'Colinas'),(425,68,29,'Chánguena'),(426,68,30,'Biolley'),(427,68,31,'Brunka'),(428,69,32,'Miramar'),(429,69,33,'La Unión'),(430,69,34,'San Isidro'),(431,70,35,'Cortés'),(432,70,36,'Palmar'),(433,70,37,'Sierpe'),(434,70,38,'Bahía Ballena'),(435,70,39,'Piedras Blancas'),(436,70,40,'Bahía Drake'),(437,71,41,'Quepos'),(438,71,42,'Savegre'),(439,71,43,'Naranjito'),(440,72,44,'Golfito'),(441,72,45,'Puerto Jiménez'),(442,72,46,'Guaycará'),(443,72,47,'Pavón'),(444,73,48,'San Vito'),(445,73,49,'Sabalito'),(446,73,50,'Aguabuena'),(447,73,51,'Limoncito'),(448,73,52,'Pittier'),(449,73,53,'Gutiérrez Brown'),(450,74,54,'Parrita'),(451,75,55,'Corredor'),(452,75,56,'La Cuesta'),(453,75,57,'Paso Canoas'),(454,75,58,'Laurel'),(455,76,59,'Jacó'),(456,76,60,'Tárcoles'),(457,77,1,'Limón'),(458,77,2,'Valle la Estrella'),(459,77,3,'Río Blanco'),(460,77,4,'Matama'),(461,78,5,'Guápiles'),(462,78,6,'Jiménez'),(463,78,7,'La Rita'),(464,78,8,'Roxana'),(465,78,9,'Cariari'),(466,78,10,'Colorado'),(467,78,11,'La Colonia'),(468,79,12,'Siquirres'),(469,79,13,'Pacuarito'),(470,79,14,'Florida'),(471,79,15,'Germania'),(472,79,16,'Cairo'),(473,79,17,'Alegría'),(474,80,18,'Bratsi'),(475,80,19,'Sixaola'),(476,80,20,'Cahuita'),(477,80,21,'Telire'),(478,81,22,'Matina'),(479,81,23,'Batan'),(480,81,24,'Carrandi'),(481,82,25,'Guácimo'),(482,82,26,'Mercedes'),(483,82,27,'Pocora'),(484,82,28,'Río Jiménez'),(485,82,29,'Duacarí');
/*!40000 ALTER TABLE `distrito` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `moneda`
--

DROP TABLE IF EXISTS `moneda`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `moneda` (
  `moneda_id` int(11) NOT NULL AUTO_INCREMENT,
  `moneda` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `simbolo` varchar(6) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`moneda_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `moneda`
--

LOCK TABLES `moneda` WRITE;
/*!40000 ALTER TABLE `moneda` DISABLE KEYS */;
INSERT INTO `moneda` (`moneda_id`, `moneda`, `simbolo`) VALUES (1,'Dolar (USD)','$'),(2,'Colón (CRC)','₡');
/*!40000 ALTER TABLE `moneda` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proveedor`
--

DROP TABLE IF EXISTS `proveedor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `proveedor` (
  `proveedor_id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario_id` int(11) NOT NULL,
  `fecha_registro` datetime NOT NULL,
  `nombre_proveedor` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `cedula_proveedor` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `estado_proveedor` int(11) NOT NULL COMMENT '0 para inactivo, 1 para activo',
  PRIMARY KEY (`proveedor_id`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proveedor`
--

LOCK TABLES `proveedor` WRITE;
/*!40000 ALTER TABLE `proveedor` DISABLE KEYS */;
INSERT INTO `proveedor` (`proveedor_id`, `usuario_id`, `fecha_registro`, `nombre_proveedor`, `cedula_proveedor`, `estado_proveedor`) VALUES (5,1,'2018-01-19 06:23:46','Instalaciones y Servicios Macopa','',1),(6,1,'2018-01-19 15:42:34','TERESITA','',1),(7,1,'2018-01-19 15:44:29','SODA MEGAPUERTO(MARIA ELENA HIDALGO ACOSTA)','203260109',1),(8,1,'2018-01-19 15:45:58','TRANSPORTES MARCO ANTONIO RODRIGUEZ','155800854936',1),(9,1,'2018-01-19 15:45:59','TRANSPORTES MARCO ANTONIO RODRIGUEZ','155800854936',1),(10,1,'2018-01-19 17:42:16','Instatec diesel Arlen','3-349034',1),(11,1,'2018-01-19 17:43:39','Instatec S.A','3-101-32747300',1),(12,1,'2018-02-07 11:01:43','PLYCEN CONSTRUSISTEMAS COSTA RICA S.A.','',1),(13,1,'2018-02-07 11:47:10','ICE','',1),(14,1,'2018-02-07 11:49:57','ACUEDUCTO RIO BLANCO','',1),(15,1,'2018-02-07 12:08:22','MOVILSACR.COM','2-528-920',1),(16,1,'2018-02-07 12:12:51','ALMACENES EL COLONO S.A.','3-101-082969',1),(17,1,'2018-02-07 12:17:47','FERRETERIA SAM KI SAN','3-101-262664',1),(18,1,'2018-02-07 12:21:53','GRUPO EMPRESARIAL EL ALMENDRO','3-101-0901394',1),(19,1,'2018-02-07 12:23:39','ANDRES GUSTAVO RIVERA MORA','03-0355-0337',1),(20,1,'2018-02-07 12:26:16','PETROLEOS DELTA COSTA RICA S.A.','3-101-028782',1),(21,1,'2018-02-07 12:30:50','HOTEL MAR AZUL','134000020026',1),(22,1,'2018-02-07 12:32:02','GRUPO HAYLING S.A.','3-101-188880',1),(23,1,'2018-02-07 12:37:40','SUPERMERCADO MAYOREO SAM #2','115600319514',1),(24,1,'2018-02-07 12:40:06','HOTEL LA UVITA','3229615',1),(25,1,'2018-02-07 12:42:08','SERVICENTRO JSM LA SUIZA','3-101-632533',1),(26,1,'2018-02-07 12:45:32','SUPER OFERTAS TURRIALBA','3263071',1),(27,1,'2018-02-07 12:50:20','ALMACEN EL REY SAN JOSE LTDA.','3-102-615387',1),(28,1,'2018-02-07 12:56:14','MARCO ANTONIO RODRIGUEZ PEREZ','155800854936',1),(29,1,'2018-02-08 12:14:53','BAZAR Y MUEBLERIA MAYRA','1-483-953-12',1),(30,1,'2018-02-12 08:59:37','TRANSPORTES CUSUCO S.A.','3-101-238495',1),(31,1,'2018-02-12 09:05:51','COOPERATIVA ELECTRIFICACIÓN RURAL GUANACASTE COBRO DE RECIBOS ELECTRONICOS','',1),(32,1,'2018-02-12 09:27:24','ALPEMUSA S.A. PEQUEÑO MUNDO','3-101289929',1),(33,1,'2018-02-12 09:32:03','SHADE TREE S.R.L.','3-1052-683019',1),(34,1,'2018-02-12 09:34:24','TRANSPORTES Y MUDANZAS AZOFEIFA','1-505-822',1),(35,1,'2018-02-12 09:37:06','MUNICIPALIDAD DE SANTA CRUZ','3-014-042109',1),(36,1,'2018-02-12 11:28:05','AFALPI S.A.','',1),(37,1,'2018-02-12 11:36:38','TRANSPORTES SARA MARIA MORA SERRANO','3-0250-0039',1),(38,1,'2018-02-12 11:51:52','DEPOSITO DE MADERAS EL POCHOTE','3-101-058492-17',1);
/*!40000 ALTER TABLE `proveedor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proveedor_correo`
--

DROP TABLE IF EXISTS `proveedor_correo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `proveedor_correo` (
  `proveedor_correo_id` int(11) NOT NULL AUTO_INCREMENT,
  `proveedor_id` int(11) NOT NULL,
  `correo_proveedor` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`proveedor_correo_id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proveedor_correo`
--

LOCK TABLES `proveedor_correo` WRITE;
/*!40000 ALTER TABLE `proveedor_correo` DISABLE KEYS */;
INSERT INTO `proveedor_correo` (`proveedor_correo_id`, `proveedor_id`, `correo_proveedor`) VALUES (18,10,'arlen@instateccr.com'),(19,11,'instateccr@gmail.com'),(20,15,'jfallas@movilsacr.com'),(21,18,'INFO@ALMENDROCR.COM'),(22,20,'costarica@petrodelta.com'),(23,24,'cabinauvita@outlook.com'),(24,28,'marcosrp2486@gmail.com'),(25,38,'info@el pochote.com');
/*!40000 ALTER TABLE `proveedor_correo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proveedor_telefono`
--

DROP TABLE IF EXISTS `proveedor_telefono`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `proveedor_telefono` (
  `proveedor_telefono_id` int(11) NOT NULL AUTO_INCREMENT,
  `proveedor_id` int(11) NOT NULL,
  `telefono_proveedor` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`proveedor_telefono_id`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proveedor_telefono`
--

LOCK TABLES `proveedor_telefono` WRITE;
/*!40000 ALTER TABLE `proveedor_telefono` DISABLE KEYS */;
INSERT INTO `proveedor_telefono` (`proveedor_telefono_id`, `proveedor_id`, `telefono_proveedor`) VALUES (18,7,'89271489'),(19,8,'62933671'),(20,9,'62933671'),(21,10,'8889-6060'),(22,11,'25526616'),(23,15,'84296629'),(25,16,'27992900'),(26,17,'27582164'),(27,18,'25737474'),(28,20,'22428300'),(29,21,'27951294'),(30,22,'27580460'),(31,23,'27580234'),(32,24,'27952583'),(33,25,'25560434'),(34,26,'25565551'),(35,27,'22218384'),(36,28,'62933671'),(37,29,'22573052'),(38,30,'26870116'),(39,32,'28882111'),(40,33,'86299429'),(41,34,'83516166'),(42,37,'89611199'),(43,38,'25918920');
/*!40000 ALTER TABLE `proveedor_telefono` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `provincia`
--

DROP TABLE IF EXISTS `provincia`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `provincia` (
  `provincia_id` int(11) NOT NULL AUTO_INCREMENT,
  `provincia` varchar(20) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`provincia_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `provincia`
--

LOCK TABLES `provincia` WRITE;
/*!40000 ALTER TABLE `provincia` DISABLE KEYS */;
INSERT INTO `provincia` (`provincia_id`, `provincia`) VALUES (1,'San José'),(2,'Alajuela'),(3,'Cartago'),(4,'Heredia'),(5,'Guanacaste'),(6,'Puntarenas'),(7,'Limón');
/*!40000 ALTER TABLE `provincia` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proyecto`
--

DROP TABLE IF EXISTS `proyecto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `proyecto` (
  `proyecto_id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario_id` int(11) NOT NULL,
  `cliente_id` int(11) NOT NULL,
  `jefe_proyecto_id` int(11) NOT NULL COMMENT 'Jefe de Proyecto',
  `proyecto_estado_id` int(11) NOT NULL,
  `distrito_id` int(11) NOT NULL,
  `moneda_id` int(11) NOT NULL,
  `nombre_proyecto` varchar(400) COLLATE utf8_spanish_ci NOT NULL,
  `fecha_registro` datetime NOT NULL,
  `fecha_firma_contrato` date DEFAULT NULL,
  `fecha_inicio` date DEFAULT NULL,
  `fecha_entrega_estimada` date DEFAULT NULL,
  `numero_contrato` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `orden_compra` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `direccion_exacta` text COLLATE utf8_spanish_ci NOT NULL,
  `observaciones` text COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`proyecto_id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proyecto`
--

LOCK TABLES `proyecto` WRITE;
/*!40000 ALTER TABLE `proyecto` DISABLE KEYS */;
INSERT INTO `proyecto` (`proyecto_id`, `usuario_id`, `cliente_id`, `jefe_proyecto_id`, `proyecto_estado_id`, `distrito_id`, `moneda_id`, `nombre_proyecto`, `fecha_registro`, `fecha_firma_contrato`, `fecha_inicio`, `fecha_entrega_estimada`, `numero_contrato`, `orden_compra`, `direccion_exacta`, `observaciones`) VALUES (17,1,18,0,1,125,1,'AEROPUERTO TERMINAL DOMESTICA','2018-01-18 12:00:38','2018-01-18','2020-01-18','2020-05-18','','','AEROPUERTO INTERNACIONAL JUAN SANTAMARÍA','No incluye oferta'),(18,1,16,0,6,293,1,'ALIGN','2018-01-18 12:06:55','2010-01-18','2013-01-18','2013-04-18','0010','123','FRENTE CENTRO CORPORATIVO EL CAFETAL','PRUBA '),(19,1,17,0,6,129,1,'STERIGENICS','2018-01-18 12:18:22','2010-11-17','2011-11-17','2010-01-18','123','123','COYOL','123'),(21,1,22,0,2,457,1,'APM TERMINALS','2018-01-19 15:36:46','2025-05-17','2015-11-17','2005-06-18','','','TERMINAL PORTUARIA MOIN','EN EJECUCIÓN'),(22,1,16,0,2,0,1,'203 Guachipelin','2018-01-26 17:03:12','2017-11-20','2017-11-20','2018-03-30','','','','Validar monto total'),(23,1,23,0,2,356,1,'TREE HOUSE W CONCHAL','2018-02-08 09:45:45','2017-09-28','2017-10-03','2018-03-07','','','Ruta 180, 800 norte del adobe renta car, reserva conchal 1.5 km hasta el campamento.',''),(24,1,23,0,2,356,1,'SPECIALTY RESTAURANT W CONCHAL','2018-02-08 12:08:10','2017-09-28','2017-11-15','2018-01-15','','','Ruta 180, 800 norte del adobe renta car, reserva conchal 1.5 km hasta el campamento.',''),(25,1,16,0,2,0,1,'CAFETAL','2018-02-09 08:26:45','0000-00-00','0000-00-00','0000-00-00','','','',''),(26,1,18,0,2,0,1,'DHL CUSTOMER SUPPORT ( COSTA RICA) S.A.','2018-02-12 10:08:17','0000-00-00','0000-00-00','0000-00-00','','','ZONA FRANCA CAFETAL, COSTADO OESTE HOTEL MARRIOT','');
/*!40000 ALTER TABLE `proyecto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proyecto_colaborador`
--

DROP TABLE IF EXISTS `proyecto_colaborador`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `proyecto_colaborador` (
  `proyecto_colaborador_id` int(11) NOT NULL AUTO_INCREMENT,
  `proyecto_id` int(11) NOT NULL,
  `colaborador_id` int(11) NOT NULL,
  `tipo_relacion` int(2) NOT NULL COMMENT '1 = Jefe de proyecto, 2 = colaborador',
  `fecha_registro` datetime NOT NULL,
  `estado_registro` int(2) NOT NULL COMMENT '0 = inactivo, 1 = activo',
  PRIMARY KEY (`proyecto_colaborador_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proyecto_colaborador`
--

LOCK TABLES `proyecto_colaborador` WRITE;
/*!40000 ALTER TABLE `proyecto_colaborador` DISABLE KEYS */;
/*!40000 ALTER TABLE `proyecto_colaborador` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proyecto_estado`
--

DROP TABLE IF EXISTS `proyecto_estado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `proyecto_estado` (
  `proyecto_estado_id` int(11) NOT NULL AUTO_INCREMENT,
  `proyecto_estado` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`proyecto_estado_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proyecto_estado`
--

LOCK TABLES `proyecto_estado` WRITE;
/*!40000 ALTER TABLE `proyecto_estado` DISABLE KEYS */;
INSERT INTO `proyecto_estado` (`proyecto_estado_id`, `proyecto_estado`) VALUES (1,'En presupuesto'),(2,'En ejecución'),(3,'Entregado'),(4,'Archivado');
/*!40000 ALTER TABLE `proyecto_estado` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proyecto_gasto`
--

DROP TABLE IF EXISTS `proyecto_gasto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `proyecto_gasto` (
  `proyecto_gasto_id` int(11) NOT NULL AUTO_INCREMENT,
  `proyecto_id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `proyecto_gasto_tipo_id` int(11) NOT NULL,
  `fecha_registro` datetime NOT NULL,
  `fecha_gasto` date NOT NULL,
  PRIMARY KEY (`proyecto_gasto_id`)
) ENGINE=InnoDB AUTO_INCREMENT=301 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proyecto_gasto`
--

LOCK TABLES `proyecto_gasto` WRITE;
/*!40000 ALTER TABLE `proyecto_gasto` DISABLE KEYS */;
INSERT INTO `proyecto_gasto` (`proyecto_gasto_id`, `proyecto_id`, `usuario_id`, `proyecto_gasto_tipo_id`, `fecha_registro`, `fecha_gasto`) VALUES (26,18,1,4,'2018-01-18 12:06:55','2018-01-18'),(27,19,1,4,'2018-01-18 12:18:22','2018-01-18'),(39,21,1,4,'2018-01-20 07:20:02','2018-01-20'),(40,22,1,4,'2018-01-26 17:03:12','2018-01-26'),(44,17,1,4,'2018-02-03 22:20:43','2018-02-03'),(46,22,1,1,'2018-02-05 10:58:50','2017-09-25'),(47,22,1,1,'2018-02-05 11:00:56','2017-09-28'),(48,22,1,1,'2018-02-05 11:14:23','2017-09-28'),(49,22,1,1,'2018-02-05 11:17:28','2017-09-28'),(50,22,1,1,'2018-02-05 11:18:49','2017-09-29'),(51,22,1,1,'2018-02-05 11:21:19','2017-10-02'),(52,22,1,1,'2018-02-05 11:23:43','2017-10-02'),(53,22,1,1,'2018-02-05 11:26:10','2017-10-03'),(54,22,1,1,'2018-02-05 11:27:10','2017-10-04'),(55,22,1,1,'2018-02-05 11:28:02','2017-10-09'),(56,22,1,1,'2018-02-05 11:29:00','2017-10-10'),(57,22,1,1,'2018-02-05 11:29:45','2017-10-24'),(58,22,1,1,'2018-02-05 11:30:38','2017-10-27'),(59,22,1,1,'2018-02-05 11:31:38','2017-10-27'),(60,22,1,1,'2018-02-05 11:32:27','2017-10-30'),(61,22,1,1,'2018-02-05 11:35:07','2017-10-31'),(62,22,1,1,'2018-02-05 11:39:09','2017-11-01'),(63,22,1,1,'2018-02-05 11:40:06','2017-11-02'),(64,22,1,1,'2018-02-05 11:41:07','2017-11-03'),(65,22,1,1,'2018-02-05 11:42:07','2017-11-04'),(66,22,1,1,'2018-02-05 11:43:16','2007-11-06'),(67,22,1,1,'2018-02-05 11:44:15','2017-11-10'),(68,22,1,1,'2018-02-05 11:46:20','2017-11-13'),(69,22,1,1,'2018-02-05 11:48:36','2017-11-16'),(70,22,1,1,'2018-02-05 11:50:00','2017-11-17'),(71,22,1,1,'2018-02-05 11:51:07','2017-11-21'),(72,22,1,1,'2018-02-05 11:53:46','2017-11-21'),(73,22,1,1,'2018-02-05 11:58:36','2017-11-23'),(74,22,1,1,'2018-02-05 11:59:55','2017-11-24'),(75,22,1,1,'2018-02-05 12:00:58','2017-11-24'),(76,22,1,1,'2018-02-05 12:02:01','2017-11-27'),(77,22,1,1,'2018-02-05 12:03:01','2017-11-27'),(78,22,1,1,'2018-02-05 12:04:14','2017-11-29'),(79,22,1,1,'2018-02-05 12:05:06','2017-11-30'),(80,22,1,1,'2018-02-05 12:07:14','2017-12-08'),(81,22,1,1,'2018-02-05 12:08:10','2017-12-01'),(82,22,1,1,'2018-02-05 12:09:36','2017-12-04'),(83,22,1,1,'2018-02-05 12:12:18','2017-12-04'),(84,22,1,1,'2018-02-05 12:13:01','2017-12-06'),(85,22,1,1,'2018-02-05 12:14:06','2017-12-06'),(86,22,1,1,'2018-02-05 12:16:04','2017-12-08'),(87,22,1,1,'2018-02-05 12:16:39','2017-12-11'),(88,22,1,1,'2018-02-05 12:17:38','2017-12-11'),(89,22,1,1,'2018-02-05 12:18:40','2017-12-12'),(90,22,1,1,'2018-02-05 12:19:31','2017-12-13'),(91,22,1,1,'2018-02-05 12:20:20','2017-12-15'),(92,22,1,1,'2018-02-05 12:22:06','2017-12-18'),(93,22,1,1,'2018-02-05 12:23:44','2017-12-20'),(94,22,1,1,'2018-02-05 12:25:10','2017-12-21'),(95,22,1,1,'2018-02-05 12:25:55','2017-12-21'),(96,22,1,1,'2018-02-05 12:27:42','2018-01-02'),(97,22,1,1,'2018-02-05 12:28:43','2018-01-08'),(98,22,1,1,'2018-02-05 12:29:32','2018-01-08'),(99,22,1,1,'2018-02-05 12:30:22','2018-01-09'),(100,22,1,1,'2018-02-05 12:31:34','2018-01-11'),(101,22,1,1,'2018-02-05 12:32:20','2018-01-13'),(102,22,1,1,'2018-02-05 12:33:10','2018-01-16'),(103,22,1,1,'2018-02-05 12:38:32','2017-01-18'),(104,22,1,1,'2018-02-05 12:39:27','2018-01-19'),(105,22,1,1,'2018-02-05 12:40:27','2018-01-19'),(106,22,1,1,'2018-02-05 12:41:14','2018-01-23'),(107,22,1,1,'2018-02-05 12:42:02','2018-01-26'),(108,22,1,1,'2018-02-06 09:04:03','2018-01-31'),(109,22,1,1,'2018-02-06 09:08:34','2018-02-05'),(110,21,1,1,'2018-02-06 11:05:31','2017-11-27'),(111,21,1,1,'2018-02-06 11:06:31','2017-11-27'),(112,21,1,1,'2018-02-06 11:07:59','2017-12-01'),(113,21,1,1,'2018-02-06 11:08:43','2017-12-04'),(114,21,1,1,'2018-02-06 11:09:33','2017-11-14'),(115,21,1,1,'2018-02-06 11:10:13','2017-12-08'),(116,21,1,1,'2018-02-06 11:11:11','2017-12-05'),(117,21,1,1,'2018-02-06 11:11:58','2017-12-14'),(118,21,1,1,'2018-02-06 11:12:51','2017-12-14'),(119,21,1,1,'2018-02-06 11:13:57','2017-12-19'),(120,21,1,1,'2018-02-06 11:16:00','2017-12-20'),(121,21,1,1,'2018-02-06 11:16:47','2017-12-20'),(122,21,1,1,'2018-02-06 11:17:48','2017-12-21'),(123,21,1,1,'2018-02-06 11:18:40','2017-12-18'),(124,21,1,1,'2018-02-06 11:23:18','2018-01-04'),(125,21,1,1,'2018-02-06 11:30:03','2018-01-11'),(126,21,1,1,'2018-02-06 11:52:03','2018-01-15'),(127,21,1,1,'2018-02-06 11:54:28','2018-01-18'),(128,21,1,1,'2018-02-06 12:01:43','2018-01-17'),(129,21,1,1,'2018-02-06 12:04:02','2018-01-23'),(130,21,1,1,'2018-02-06 12:04:56','2018-01-26'),(131,21,1,1,'2018-02-06 12:05:45','2018-01-29'),(132,21,1,1,'2018-02-06 12:07:17','2018-01-08'),(133,17,1,1,'2018-02-06 12:32:48','2017-12-15'),(134,17,1,1,'2018-02-06 12:34:19','2017-12-18'),(135,17,1,1,'2018-02-06 12:35:17','2017-12-18'),(136,17,1,1,'2018-02-06 12:36:14','2017-12-20'),(137,17,1,1,'2018-02-06 12:37:12','2017-12-21'),(138,17,1,1,'2018-02-06 12:44:25','2018-01-04'),(139,17,1,1,'2018-02-06 12:45:25','2018-01-08'),(140,17,1,1,'2018-02-06 12:46:14','2018-01-09'),(141,17,1,1,'2018-02-06 12:47:30','2018-01-11'),(142,17,1,1,'2018-02-06 12:48:29','2018-01-11'),(143,17,1,1,'2018-02-06 12:49:14','2018-01-16'),(144,17,1,1,'2018-02-06 12:49:50','2018-01-17'),(145,17,1,1,'2018-02-06 12:53:03','2018-01-17'),(146,17,1,1,'2018-02-06 12:53:58','2018-01-26'),(147,17,1,1,'2018-02-06 12:55:02','2018-01-30'),(148,17,1,1,'2018-02-06 12:55:50','2018-01-23'),(149,21,1,1,'2018-02-07 09:03:37','2018-02-05'),(150,17,1,1,'2018-02-07 09:21:29','2018-01-31'),(151,18,1,1,'2018-02-07 09:53:05','2018-01-02'),(152,18,1,1,'2018-02-07 09:55:04','2018-01-02'),(153,18,1,1,'2018-02-07 09:56:54','2018-01-04'),(154,18,1,1,'2018-02-07 09:58:03','2018-01-05'),(155,18,1,1,'2018-02-07 09:59:16','2018-01-05'),(156,18,1,1,'2018-02-07 10:01:31','2018-01-08'),(157,18,1,1,'2018-02-07 10:02:43','2018-01-08'),(158,18,1,1,'2018-02-07 10:04:06','2018-01-10'),(159,18,1,1,'2018-02-07 10:05:00','2018-01-11'),(160,18,1,1,'2018-02-07 10:05:43','2018-01-11'),(161,18,1,1,'2018-02-07 10:07:09','2018-01-12'),(162,18,1,1,'2018-02-07 10:08:43','2018-01-12'),(163,18,1,1,'2018-02-07 10:09:54','2018-01-15'),(164,18,1,1,'2018-02-07 10:12:41','2018-01-15'),(165,18,1,1,'2018-02-07 10:14:31','2018-01-16'),(166,18,1,1,'2018-02-07 10:15:33','2018-01-23'),(167,18,1,1,'2018-02-07 10:16:31','2018-01-26'),(168,18,1,1,'2018-02-07 10:18:31','2018-01-18'),(169,18,1,1,'2018-02-07 10:19:23','2018-01-18'),(170,18,1,1,'2018-02-07 10:20:20','2018-01-30'),(171,18,1,1,'2018-02-07 10:21:00','2018-01-26'),(172,18,1,1,'2018-02-07 10:22:12','2018-02-02'),(173,18,1,1,'2018-02-07 10:22:57','2018-02-02'),(174,19,1,1,'2018-02-07 10:34:01','2017-12-11'),(175,19,1,1,'2018-02-07 10:34:45','2017-12-11'),(176,19,1,1,'2018-02-07 10:35:37','2017-12-13'),(177,19,1,1,'2018-02-07 10:38:15','2017-12-13'),(178,19,1,1,'2018-02-07 10:40:17','2017-12-20'),(179,19,1,1,'2018-02-07 10:42:14','2017-12-20'),(180,19,1,1,'2018-02-07 10:43:08','2017-12-24'),(181,19,1,1,'2018-02-07 10:43:57','2017-12-21'),(182,19,1,1,'2018-02-07 10:44:38','2017-12-21'),(183,22,1,2,'2018-02-07 10:47:18','2018-02-07'),(184,22,1,1,'2018-02-07 11:06:28','2017-11-14'),(185,19,1,1,'2018-02-07 11:26:53','2018-01-04'),(186,19,1,1,'2018-02-07 11:27:36','2018-01-04'),(187,19,1,1,'2018-02-07 11:29:40','2018-01-02'),(188,19,1,1,'2018-02-07 11:31:04','2018-01-09'),(189,19,1,1,'2018-02-07 11:31:48','2018-01-02'),(190,19,1,1,'2018-02-07 11:32:38','2018-01-05'),(191,19,1,1,'2018-02-07 11:34:12','2018-01-05'),(192,19,1,1,'2018-02-07 11:40:31','2018-01-08'),(193,21,1,3,'2018-02-07 11:49:26','2018-01-17'),(194,17,1,1,'2018-02-07 12:03:07','2018-02-05'),(195,21,1,3,'2018-02-07 12:05:49','2018-01-11'),(196,21,1,3,'2018-02-07 12:09:15','2018-01-10'),(197,21,1,3,'2018-02-07 12:15:07','2017-12-20'),(198,21,1,3,'2018-02-07 12:19:52','2017-12-20'),(199,21,1,3,'2018-02-07 12:22:38','2017-12-14'),(200,21,1,3,'2018-02-07 12:24:11','2017-12-15'),(201,21,1,3,'2018-02-07 12:26:54','2017-12-11'),(202,21,1,3,'2018-02-07 12:31:23','2017-12-15'),(203,21,1,3,'2018-02-07 12:35:03','2017-12-22'),(204,21,1,3,'2018-02-07 12:35:49','2017-12-18'),(205,21,1,3,'2018-02-07 12:36:43','2017-12-18'),(206,21,1,3,'2018-02-07 12:39:15','2017-12-19'),(207,21,1,3,'2018-02-07 12:40:41','2017-12-19'),(208,21,1,3,'2018-02-07 12:41:10','2017-12-20'),(209,21,1,3,'2018-02-07 12:45:00','2017-12-16'),(210,21,1,3,'2018-02-07 12:46:11','2017-12-11'),(211,21,1,3,'2018-02-07 12:51:40','2017-11-06'),(212,21,1,3,'2018-02-07 12:52:26','2017-11-13'),(213,21,1,3,'2018-02-07 12:54:10','2017-12-14'),(214,21,1,3,'2018-02-07 12:56:59','2017-12-08'),(215,21,1,3,'2018-02-07 12:58:14','2017-12-14'),(216,21,1,3,'2018-02-07 12:59:04','2017-12-21'),(217,21,1,3,'2018-02-07 12:59:38','2017-12-22'),(218,21,1,3,'2018-02-07 13:00:15','2017-12-15'),(219,21,1,3,'2018-02-07 13:00:59','2017-12-22'),(220,17,1,1,'2018-02-08 08:34:44','2018-02-07'),(221,17,1,1,'2018-02-08 08:36:13','2018-02-07'),(222,18,1,2,'2018-02-08 09:11:44','2018-02-08'),(223,21,1,2,'2018-02-08 09:20:21','2018-02-08'),(224,23,1,4,'2018-02-08 09:45:45','2018-02-08'),(225,23,1,1,'2018-02-08 11:30:13','2017-11-28'),(226,23,1,1,'2018-02-08 11:37:28','2017-12-04'),(227,23,1,1,'2018-02-08 11:38:34','2017-12-04'),(228,23,1,1,'2018-02-08 11:39:29','2017-12-01'),(229,23,1,1,'2018-02-08 11:40:22','2017-12-11'),(230,23,1,1,'2018-02-08 11:43:59','2017-12-14'),(231,23,1,1,'2018-02-08 11:44:58','2017-12-14'),(232,23,1,1,'2018-02-08 11:45:59','2017-12-15'),(233,23,1,1,'2018-02-08 11:50:15','2018-01-05'),(234,23,1,1,'2018-02-08 11:50:54','2018-01-09'),(235,23,1,1,'2018-02-08 11:52:42','2018-01-10'),(236,23,1,1,'2018-02-08 11:53:34','2018-01-10'),(237,23,1,1,'2018-02-08 11:54:23','2018-01-15'),(238,23,1,1,'2018-02-08 11:55:17','2018-01-22'),(239,23,1,1,'2018-02-08 11:56:03','2018-01-24'),(240,23,1,1,'2018-02-08 11:59:55','2018-02-02'),(241,24,1,4,'2018-02-08 12:08:10','2018-02-08'),(242,24,1,1,'2018-02-08 12:10:39','2017-12-04'),(243,24,1,1,'2018-02-08 12:11:20','2017-12-11'),(244,24,1,1,'2018-02-08 12:11:56','2018-02-02'),(245,24,1,1,'2018-02-08 12:12:32','2017-12-14'),(246,23,1,3,'2018-02-08 12:15:39','2017-11-14'),(247,23,1,3,'2018-02-08 12:16:21','2017-11-28'),(248,17,1,1,'2018-02-08 12:42:10','2018-02-08'),(249,25,1,4,'2018-02-09 08:26:45','2018-02-09'),(250,25,1,1,'2018-02-09 08:28:37','2017-12-07'),(251,25,1,1,'2018-02-09 08:29:24','2017-12-07'),(252,25,1,1,'2018-02-09 08:31:45','2017-12-15'),(253,25,1,1,'2018-02-09 08:32:32','2017-12-19'),(254,25,1,1,'2018-02-09 08:33:31','2017-12-19'),(255,25,1,1,'2018-02-09 08:41:31','2018-01-02'),(256,25,1,1,'2018-02-09 08:42:39','2018-01-05'),(257,25,1,1,'2018-02-09 08:44:38','2018-01-08'),(258,25,1,1,'2018-02-09 08:46:54','2018-01-10'),(259,25,1,1,'2018-02-09 08:48:10','2018-01-12'),(260,25,1,1,'2018-02-09 08:49:20','2018-01-15'),(261,25,1,1,'2018-02-09 08:50:24','2018-01-17'),(262,25,1,1,'2018-02-09 08:51:34','2018-01-23'),(263,25,1,1,'2018-02-09 08:52:35','2018-01-18'),(264,25,1,1,'2018-02-09 08:54:21','2018-01-26'),(265,25,1,1,'2018-02-09 08:55:55','2018-01-30'),(266,25,1,1,'2018-02-09 08:56:40','2018-01-08'),(267,25,1,1,'2018-02-09 08:58:39','2018-02-01'),(268,25,1,1,'2018-02-09 08:59:29','2018-02-08'),(269,25,1,2,'2018-02-09 09:09:07','2018-02-09'),(270,22,1,1,'2018-02-09 12:07:12','2018-01-26'),(271,25,1,1,'2018-02-09 12:11:22','2018-01-26'),(272,17,1,1,'2018-02-09 12:12:51','2018-01-19'),(273,25,1,1,'2018-02-09 12:14:29','2018-02-05'),(274,18,1,1,'2018-02-09 12:16:30','2018-02-08'),(275,18,1,1,'2018-02-09 12:17:08','2018-02-02'),(276,21,1,1,'2018-02-09 12:22:22','2018-02-07'),(277,23,1,3,'2018-02-12 08:54:10','2018-01-09'),(278,23,1,3,'2018-02-12 08:55:32','2018-01-29'),(279,23,1,3,'2018-02-12 09:00:58','2018-01-29'),(280,23,1,3,'2018-02-12 09:02:06','2018-01-30'),(281,23,1,3,'2018-02-12 09:06:33','2018-02-02'),(282,23,1,3,'2018-02-12 09:28:42','2018-01-26'),(283,23,1,3,'2018-02-12 09:33:36','2018-01-26'),(284,23,1,3,'2018-02-12 09:35:30','2018-01-16'),(285,23,1,3,'2018-02-12 09:38:01','2018-01-15'),(286,17,1,3,'2018-02-12 09:53:34','2018-02-09'),(287,22,1,1,'2018-02-12 09:55:09','2018-02-08'),(288,18,1,1,'2018-02-12 09:57:10','2018-02-10'),(289,26,1,4,'2018-02-12 10:08:18','2018-02-12'),(290,26,1,1,'2018-02-12 10:10:01','2018-02-02'),(291,26,1,1,'2018-02-12 10:11:57','2018-02-07'),(292,26,1,1,'2018-02-12 10:12:59','2018-02-07'),(293,26,1,1,'2018-02-12 10:13:50','2018-02-09'),(294,26,1,1,'2018-02-12 10:14:32','2018-02-09'),(295,23,1,3,'2018-02-12 10:31:13','2018-02-07'),(296,26,1,1,'2018-02-12 10:39:02','2018-02-12'),(297,26,1,1,'2018-02-12 10:39:35','2018-02-12'),(298,21,1,3,'2018-02-12 11:28:45','2017-11-27'),(299,21,1,3,'2018-02-12 11:37:50','2018-02-06'),(300,23,1,1,'2018-02-12 11:53:04','2018-01-29');
/*!40000 ALTER TABLE `proyecto_gasto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proyecto_gasto_detalle`
--

DROP TABLE IF EXISTS `proyecto_gasto_detalle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `proyecto_gasto_detalle` (
  `proyecto_gasto_detalle_id` int(11) NOT NULL AUTO_INCREMENT,
  `proyecto_gasto_id` int(11) NOT NULL,
  `proveedor_id` int(11) NOT NULL,
  `proyecto_gasto_estado_id` int(11) NOT NULL,
  `numero_factura` int(11) NOT NULL,
  PRIMARY KEY (`proyecto_gasto_detalle_id`)
) ENGINE=InnoDB AUTO_INCREMENT=270 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proyecto_gasto_detalle`
--

LOCK TABLES `proyecto_gasto_detalle` WRITE;
/*!40000 ALTER TABLE `proyecto_gasto_detalle` DISABLE KEYS */;
INSERT INTO `proyecto_gasto_detalle` (`proyecto_gasto_detalle_id`, `proyecto_gasto_id`, `proveedor_id`, `proyecto_gasto_estado_id`, `numero_factura`) VALUES (23,46,5,1,866406),(24,47,5,1,868101),(25,48,5,1,868066),(26,49,5,1,868174),(27,50,5,1,868352),(28,51,5,1,868466),(29,52,5,1,868470),(30,53,5,1,868769),(31,54,5,1,869118),(32,55,5,1,869594),(33,56,5,1,869773),(34,57,5,1,883104),(35,58,5,1,883716),(36,59,5,1,883793),(37,60,5,1,883957),(38,61,5,1,884278),(39,62,5,1,884472),(40,63,5,1,884566),(41,64,5,1,884784),(42,65,5,1,884955),(43,66,5,1,885208),(44,67,5,1,886071),(45,68,5,1,886373),(46,69,5,1,886872),(47,70,5,1,887098),(48,71,5,1,887586),(49,72,5,1,887744),(50,73,5,1,888210),(51,74,5,1,888233),(52,75,5,1,888389),(53,76,5,1,888680),(54,77,5,1,888681),(55,78,5,1,889185),(56,79,5,1,889296),(57,80,5,1,890699),(58,81,5,1,889513),(59,82,5,1,889746),(60,83,5,1,889795),(61,84,5,1,890096),(62,85,5,1,890223),(63,86,5,1,890810),(64,87,5,1,890955),(65,88,5,1,890957),(66,89,5,1,891135),(67,90,5,1,891478),(68,91,5,1,891896),(69,92,5,1,892134),(70,93,5,1,892674),(71,94,5,1,892757),(72,95,5,1,892925),(73,96,5,1,893283),(74,97,5,1,894160),(75,98,5,1,894293),(76,99,5,1,894331),(77,100,5,1,894755),(78,101,5,1,895136),(79,102,5,1,16),(80,103,5,1,895812),(81,104,5,1,896057),(82,105,5,1,896056),(83,106,5,1,896457),(84,107,5,1,26),(85,108,5,1,897948),(86,109,5,1,898649),(87,110,5,1,888629),(88,111,5,1,888674),(89,112,5,1,889603),(90,113,5,1,889657),(91,114,5,1,886600),(92,115,5,1,890652),(93,116,5,1,890065),(94,117,5,1,891526),(95,118,5,1,891530),(96,119,5,1,892440),(97,120,5,1,892676),(98,121,5,1,892675),(99,122,5,1,892874),(100,123,5,1,892178),(101,124,5,1,893783),(102,125,5,1,894911),(103,126,5,1,895373),(104,127,5,1,895863),(105,128,5,1,895766),(106,129,5,1,896641),(107,130,5,1,897210),(108,131,5,1,897498),(109,132,5,1,894185),(110,133,5,1,891907),(111,134,5,1,892022),(112,135,5,1,892115),(113,136,5,1,892673),(114,137,5,1,892894),(115,138,5,1,893757),(116,139,5,1,894161),(117,140,5,1,894447),(118,141,5,1,894847),(119,142,5,1,894789),(120,143,5,1,895412),(121,144,5,1,895691),(122,145,5,1,895581),(123,146,5,1,897240),(124,147,5,1,897737),(125,148,5,1,896458),(126,149,5,1,898583),(127,150,5,1,897790),(128,151,5,1,893182),(129,152,5,1,893183),(130,153,5,1,893694),(131,154,5,1,893870),(132,155,5,1,893982),(133,156,5,1,894279),(134,157,5,1,894167),(135,158,5,1,894506),(136,159,5,1,894738),(137,160,5,1,894739),(138,161,5,1,895090),(139,162,5,1,895087),(140,163,5,1,895372),(141,164,5,1,895383),(142,165,5,1,895422),(143,166,5,1,896615),(144,167,5,1,897259),(145,168,5,1,895928),(146,169,5,1,895933),(147,170,5,1,897738),(148,171,5,1,897260),(149,172,5,1,898309),(150,173,5,1,898308),(151,174,5,1,890882),(152,175,5,1,890956),(153,176,5,1,891461),(154,177,5,1,891463),(155,178,5,1,892542),(156,179,5,1,892543),(157,180,5,1,892702),(158,181,5,1,892703),(159,182,5,1,892704),(160,184,12,1,96469),(161,185,5,1,893755),(162,186,5,1,893756),(163,187,5,1,893170),(164,188,5,1,894363),(165,189,5,1,893169),(166,190,5,1,893953),(167,191,5,1,893933),(168,192,5,1,894173),(169,193,13,2,1712907915),(170,194,5,1,898656),(171,195,14,2,98624),(172,196,15,2,2506),(173,197,16,2,2704),(174,198,17,2,262011),(175,199,18,2,69917),(176,200,19,2,352),(177,201,20,2,19652901),(178,202,21,2,9747),(179,203,22,2,766045),(180,204,21,2,9757),(181,205,20,2,19649606),(182,206,23,2,2),(183,207,24,2,6054),(184,208,24,2,6055),(185,209,25,2,315755),(186,210,26,2,24669),(187,211,27,2,377434),(188,212,27,2,430735),(189,213,14,2,97247),(190,214,8,2,42),(191,215,7,2,2807),(192,216,13,2,1711830646),(193,217,7,2,2843),(194,218,7,2,2818),(195,219,8,2,43),(196,220,5,1,899112),(197,221,5,1,899106),(198,225,5,1,888947),(199,226,5,1,889763),(200,227,5,1,889768),(201,228,5,1,889537),(202,229,5,1,890977),(203,230,5,1,891607),(204,231,5,1,891608),(205,232,5,1,891732),(206,233,5,1,893990),(207,234,5,1,894443),(208,235,5,1,894569),(209,236,5,1,894653),(210,237,5,1,895247),(211,238,5,1,896399),(212,239,5,1,896875),(213,240,5,1,898323),(214,242,5,1,889763),(215,243,5,1,890977),(216,244,5,1,898323),(217,245,5,1,891608),(218,246,29,2,8847),(219,247,29,2,8919),(220,248,5,1,899203),(221,250,5,1,890404),(222,251,5,1,890524),(223,252,5,1,891906),(224,253,5,1,892279),(225,254,5,1,892269),(226,255,5,1,893232),(227,256,5,1,893901),(228,257,5,1,894223),(229,258,5,1,894676),(230,259,5,1,895092),(231,260,5,1,895276),(232,261,5,1,895582),(233,262,5,1,896588),(234,263,5,1,895964),(235,264,5,1,897282),(236,265,5,1,897570),(237,266,5,1,894220),(238,267,5,1,898181),(239,268,5,1,899367),(240,270,5,1,897208),(241,271,5,1,897135),(242,272,5,1,896163),(243,273,5,1,898644),(244,274,5,1,899301),(245,275,5,1,898212),(246,276,5,1,899140),(247,277,29,2,9146),(248,278,29,2,9254),(249,279,30,2,32520),(250,280,30,2,2018),(251,281,31,2,18962127),(252,282,32,2,511127935),(253,283,33,2,4),(254,284,34,2,181),(255,285,35,2,8101),(256,286,5,1,899479),(257,287,5,1,899273),(258,288,5,1,899645),(259,290,5,1,898415),(260,291,5,1,899022),(261,292,5,1,899137),(262,293,5,1,899477),(263,294,5,1,899478),(264,295,33,2,6),(265,296,5,1,899675),(266,297,5,1,899687),(267,298,36,1,239502),(268,299,37,2,16),(269,300,38,1,2308355);
/*!40000 ALTER TABLE `proyecto_gasto_detalle` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proyecto_gasto_estado`
--

DROP TABLE IF EXISTS `proyecto_gasto_estado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `proyecto_gasto_estado` (
  `proyecto_gasto_estado_id` int(11) NOT NULL AUTO_INCREMENT,
  `proyecto_gasto_estado` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`proyecto_gasto_estado_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proyecto_gasto_estado`
--

LOCK TABLES `proyecto_gasto_estado` WRITE;
/*!40000 ALTER TABLE `proyecto_gasto_estado` DISABLE KEYS */;
INSERT INTO `proyecto_gasto_estado` (`proyecto_gasto_estado_id`, `proyecto_gasto_estado`) VALUES (1,'Pendiente'),(2,'Cancelado');
/*!40000 ALTER TABLE `proyecto_gasto_estado` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proyecto_gasto_mano_obra`
--

DROP TABLE IF EXISTS `proyecto_gasto_mano_obra`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `proyecto_gasto_mano_obra` (
  `proyecto_gasto_mano_obra_id` int(11) NOT NULL AUTO_INCREMENT,
  `proyecto_gasto_id` int(11) NOT NULL,
  `proyecto_colaborador_id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `fecha_registro` datetime NOT NULL,
  `cantidad_horas` float(6,2) NOT NULL,
  `costo_hora_mano_obra` float(10,2) NOT NULL,
  `estado_registro` int(2) NOT NULL COMMENT '0 = inactivo, 1 = activo',
  PRIMARY KEY (`proyecto_gasto_mano_obra_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proyecto_gasto_mano_obra`
--

LOCK TABLES `proyecto_gasto_mano_obra` WRITE;
/*!40000 ALTER TABLE `proyecto_gasto_mano_obra` DISABLE KEYS */;
/*!40000 ALTER TABLE `proyecto_gasto_mano_obra` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proyecto_gasto_monto`
--

DROP TABLE IF EXISTS `proyecto_gasto_monto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `proyecto_gasto_monto` (
  `proyecto_gasto_monto_id` int(11) NOT NULL AUTO_INCREMENT,
  `proyecto_gasto_id` int(11) NOT NULL,
  `moneda_id` int(11) NOT NULL,
  `proyecto_gasto_monto` float(20,2) NOT NULL,
  `estado_registro` int(11) NOT NULL COMMENT '0 = inactivo, 1 = activo',
  `fecha_registro` datetime NOT NULL,
  PRIMARY KEY (`proyecto_gasto_monto_id`)
) ENGINE=InnoDB AUTO_INCREMENT=354 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proyecto_gasto_monto`
--

LOCK TABLES `proyecto_gasto_monto` WRITE;
/*!40000 ALTER TABLE `proyecto_gasto_monto` DISABLE KEYS */;
INSERT INTO `proyecto_gasto_monto` (`proyecto_gasto_monto_id`, `proyecto_gasto_id`, `moneda_id`, `proyecto_gasto_monto`, `estado_registro`, `fecha_registro`) VALUES (44,26,1,33000.00,1,'2018-01-18 12:06:55'),(45,27,1,2000.00,1,'2018-01-18 12:18:22'),(71,39,1,19724.00,1,'2018-01-20 07:20:02'),(73,40,1,4000.00,1,'2018-01-26 17:03:12'),(77,44,1,1500.00,0,'2018-02-03 22:20:43'),(79,46,1,9716.00,1,'2018-02-05 10:58:50'),(80,47,1,846.00,0,'2018-02-05 11:00:56'),(81,48,1,4803.00,1,'2018-02-05 11:14:23'),(82,49,1,7388.00,1,'2018-02-05 11:17:28'),(83,50,1,4005.00,1,'2018-02-05 11:18:49'),(84,51,1,507.00,1,'2018-02-05 11:21:19'),(85,52,1,76.14,1,'2018-02-05 11:23:43'),(86,53,1,1533.41,1,'2018-02-05 11:26:10'),(87,54,1,4786.16,1,'2018-02-05 11:27:10'),(88,55,1,912.48,1,'2018-02-05 11:28:02'),(89,56,1,3922.13,1,'2018-02-05 11:29:00'),(90,57,1,4391.20,1,'2018-02-05 11:29:45'),(91,58,1,1885.36,1,'2018-02-05 11:30:38'),(92,59,1,2209.15,1,'2018-02-05 11:31:38'),(93,60,1,2026.98,1,'2018-02-05 11:32:27'),(94,61,1,4391.42,1,'2018-02-05 11:35:07'),(95,62,1,622.92,1,'2018-02-05 11:39:09'),(96,63,1,1159.38,1,'2018-02-05 11:40:06'),(97,64,1,1385.99,1,'2018-02-05 11:41:07'),(98,65,1,1251.52,1,'2018-02-05 11:42:07'),(99,66,1,1543.85,0,'2018-02-05 11:43:16'),(100,67,1,3555.24,0,'2018-02-05 11:44:15'),(101,68,1,6689.97,0,'2018-02-05 11:46:20'),(102,69,1,6480.64,0,'2018-02-05 11:48:36'),(103,70,1,1196.70,0,'2018-02-05 11:50:00'),(104,71,1,2331.84,0,'2018-02-05 11:51:07'),(105,72,1,6032.63,0,'2018-02-05 11:53:46'),(106,73,1,2149.51,0,'2018-02-05 11:58:36'),(107,74,1,508.39,0,'2018-02-05 11:59:55'),(108,75,1,12654.49,0,'2018-02-05 12:00:58'),(109,76,1,848.84,0,'2018-02-05 12:02:01'),(110,77,1,866.15,0,'2018-02-05 12:03:01'),(111,78,1,2569.96,0,'2018-02-05 12:04:14'),(112,79,1,2362.49,0,'2018-02-05 12:05:06'),(113,80,1,1023.22,1,'2018-02-05 12:07:14'),(114,81,1,2835.15,1,'2018-02-05 12:08:10'),(115,82,1,1179.69,1,'2018-02-05 12:09:36'),(116,83,1,6498.62,1,'2018-02-05 12:12:18'),(117,84,1,1223.23,1,'2018-02-05 12:13:02'),(118,85,1,2727.68,1,'2018-02-05 12:14:06'),(119,86,1,8296.06,1,'2018-02-05 12:16:04'),(120,87,1,728.85,1,'2018-02-05 12:16:39'),(121,88,1,1753.47,1,'2018-02-05 12:17:38'),(122,89,1,786.56,1,'2018-02-05 12:18:40'),(123,90,1,6819.87,1,'2018-02-05 12:19:31'),(124,91,1,4339.35,1,'2018-02-05 12:20:20'),(125,92,1,6625.04,1,'2018-02-05 12:22:06'),(126,93,1,1244.63,1,'2018-02-05 12:23:44'),(127,94,1,423.61,1,'2018-02-05 12:25:10'),(128,95,1,1480.46,1,'2018-02-05 12:25:55'),(129,96,1,12052.34,1,'2018-02-05 12:27:42'),(130,97,1,1368.09,1,'2018-02-05 12:28:43'),(131,98,1,1217.58,1,'2018-02-05 12:29:32'),(132,99,1,6184.02,1,'2018-02-05 12:30:22'),(133,100,1,571.19,1,'2018-02-05 12:31:34'),(134,101,1,2126.76,1,'2018-02-05 12:32:20'),(135,102,1,10895.89,1,'2018-02-05 12:33:10'),(136,103,1,10717.27,1,'2018-02-05 12:38:32'),(137,104,1,2682.80,1,'2018-02-05 12:39:27'),(138,105,1,2682.80,1,'2018-02-05 12:40:27'),(139,106,1,7195.72,1,'2018-02-05 12:41:14'),(140,107,1,700.80,1,'2018-02-05 12:42:02'),(141,108,1,17087.52,0,'2018-02-06 09:04:03'),(142,109,1,9792.98,1,'2018-02-06 09:08:34'),(143,110,1,10936.53,1,'2018-02-06 11:05:31'),(144,111,1,45.77,1,'2018-02-06 11:06:31'),(145,112,1,3630.57,1,'2018-02-06 11:07:59'),(146,113,1,648.94,1,'2018-02-06 11:08:43'),(147,114,1,14405.47,1,'2018-02-06 11:09:33'),(148,115,1,308.49,1,'2018-02-06 11:10:13'),(149,116,1,7954.45,1,'2018-02-06 11:11:11'),(150,117,1,1428.08,1,'2018-02-06 11:11:59'),(151,118,1,235.86,1,'2018-02-06 11:12:51'),(152,119,1,6821.79,1,'2018-02-06 11:13:57'),(153,120,1,2401.20,1,'2018-02-06 11:16:00'),(154,121,1,2401.20,1,'2018-02-06 11:16:47'),(155,122,1,1881.91,1,'2018-02-06 11:17:48'),(156,123,1,4000.11,1,'2018-02-06 11:18:40'),(157,124,1,7537.81,1,'2018-02-06 11:23:18'),(158,125,1,3094.87,1,'2018-02-06 11:30:03'),(159,126,1,4417.55,1,'2018-02-06 11:52:03'),(160,127,1,1936.93,1,'2018-02-06 11:54:28'),(161,128,1,1525.14,1,'2018-02-06 12:01:43'),(162,129,1,5329.23,1,'2018-02-06 12:04:02'),(163,130,1,3035.00,1,'2018-02-06 12:04:56'),(164,131,1,807.53,1,'2018-02-06 12:05:45'),(165,132,1,2646.41,1,'2018-02-06 12:07:17'),(166,133,1,36.94,1,'2018-02-06 12:32:48'),(167,134,1,3267.75,1,'2018-02-06 12:34:19'),(168,135,1,1845.03,1,'2018-02-06 12:35:17'),(169,136,1,198.19,1,'2018-02-06 12:36:14'),(170,137,1,871.08,1,'2018-02-06 12:37:12'),(171,138,1,1969.36,1,'2018-02-06 12:44:25'),(172,139,1,941.64,1,'2018-02-06 12:45:25'),(173,140,1,3851.65,1,'2018-02-06 12:46:14'),(174,141,1,598.09,1,'2018-02-06 12:47:30'),(175,142,1,6224.55,1,'2018-02-06 12:48:29'),(176,143,1,2386.55,1,'2018-02-06 12:49:14'),(177,144,1,1623.19,1,'2018-02-06 12:49:50'),(178,145,1,1716.99,1,'2018-02-06 12:53:03'),(179,146,1,4403.44,1,'2018-02-06 12:53:58'),(180,147,1,2548.45,1,'2018-02-06 12:55:02'),(181,148,1,12424.82,1,'2018-02-06 12:55:50'),(182,108,1,15564.84,1,'2018-02-07 08:43:11'),(183,149,1,4911.69,1,'2018-02-07 09:03:37'),(184,150,1,88.52,1,'2018-02-07 09:21:29'),(185,151,1,2149.64,1,'2018-02-07 09:53:05'),(186,152,1,1954.63,1,'2018-02-07 09:55:04'),(187,153,1,4976.43,1,'2018-02-07 09:56:54'),(188,154,1,5953.61,1,'2018-02-07 09:58:03'),(189,155,1,2696.08,1,'2018-02-07 09:59:16'),(190,156,1,4701.56,1,'2018-02-07 10:01:31'),(191,157,1,3457.78,1,'2018-02-07 10:02:43'),(192,158,1,4397.81,1,'2018-02-07 10:04:06'),(193,159,1,2939.62,1,'2018-02-07 10:05:00'),(194,160,1,759.30,1,'2018-02-07 10:05:43'),(195,161,1,11329.32,1,'2018-02-07 10:07:09'),(196,162,1,331.42,1,'2018-02-07 10:08:43'),(197,163,1,4454.68,1,'2018-02-07 10:09:54'),(198,164,1,3555.32,1,'2018-02-07 10:12:41'),(199,165,1,392.84,1,'2018-02-07 10:14:31'),(200,166,1,12172.32,1,'2018-02-07 10:15:33'),(201,167,1,10789.74,1,'2018-02-07 10:16:31'),(202,168,1,649.43,1,'2018-02-07 10:18:31'),(203,169,1,14234.54,1,'2018-02-07 10:19:23'),(204,170,1,8096.51,1,'2018-02-07 10:20:20'),(205,171,1,411.31,1,'2018-02-07 10:21:00'),(206,172,1,549.84,1,'2018-02-07 10:22:12'),(207,173,1,5553.74,1,'2018-02-07 10:22:57'),(208,174,1,2144.88,1,'2018-02-07 10:34:01'),(209,175,1,31.08,1,'2018-02-07 10:34:45'),(210,176,1,272.88,1,'2018-02-07 10:35:37'),(211,177,1,3896.70,1,'2018-02-07 10:38:15'),(212,178,1,131.79,1,'2018-02-07 10:40:17'),(213,179,1,481.00,1,'2018-02-07 10:42:14'),(214,180,1,192.80,1,'2018-02-07 10:43:08'),(215,181,1,42.47,1,'2018-02-07 10:43:57'),(216,182,1,384.80,1,'2018-02-07 10:44:38'),(217,183,2,61362500.00,1,'2018-02-07 10:47:18'),(218,184,2,4043109.50,1,'2018-02-07 11:06:28'),(219,185,1,686.63,1,'2018-02-07 11:26:53'),(220,186,1,94.60,1,'2018-02-07 11:27:36'),(221,187,1,4986.60,1,'2018-02-07 11:29:40'),(222,188,1,90.68,1,'2018-02-07 11:31:04'),(223,189,1,50.66,1,'2018-02-07 11:31:48'),(224,190,1,132.70,1,'2018-02-07 11:32:38'),(225,191,1,1326.90,1,'2018-02-07 11:34:12'),(226,192,1,437.64,1,'2018-02-07 11:40:31'),(227,193,2,10475.00,1,'2018-02-07 11:49:26'),(228,194,1,2404.62,1,'2018-02-07 12:03:07'),(229,195,2,8329.16,1,'2018-02-07 12:05:49'),(230,196,1,470.00,1,'2018-02-07 12:09:15'),(231,197,2,134900.00,1,'2018-02-07 12:15:07'),(232,198,2,81750.00,1,'2018-02-07 12:19:52'),(233,199,2,165197.34,1,'2018-02-07 12:22:38'),(234,200,2,180000.00,1,'2018-02-07 12:24:11'),(235,201,2,17613.00,1,'2018-02-07 12:26:54'),(236,202,2,17000.00,1,'2018-02-07 12:31:23'),(237,203,2,15000.00,1,'2018-02-07 12:35:03'),(238,204,2,17000.00,1,'2018-02-07 12:35:49'),(239,205,2,15000.00,1,'2018-02-07 12:36:43'),(240,206,2,4335.00,1,'2018-02-07 12:39:15'),(241,207,2,152.55,1,'2018-02-07 12:40:41'),(242,208,2,15255.00,1,'2018-02-07 12:41:10'),(243,209,2,5000.00,1,'2018-02-07 12:45:00'),(244,210,2,575.00,1,'2018-02-07 12:46:11'),(245,211,2,6750.00,1,'2018-02-07 12:51:40'),(246,212,2,49000.00,1,'2018-02-07 12:52:26'),(247,213,2,4051.70,1,'2018-02-07 12:54:10'),(248,214,2,170000.00,1,'2018-02-07 12:56:59'),(249,215,2,200000.00,1,'2018-02-07 12:58:14'),(250,216,2,9020.00,1,'2018-02-07 12:59:04'),(251,217,2,341000.00,1,'2018-02-07 12:59:38'),(252,218,2,359000.00,1,'2018-02-07 13:00:15'),(253,219,2,200000.00,1,'2018-02-07 13:00:59'),(254,220,1,24.05,1,'2018-02-08 08:34:44'),(255,221,1,1039.11,1,'2018-02-08 08:36:13'),(256,222,2,9550663.00,0,'2018-02-08 09:11:44'),(257,222,2,9550663.00,1,'2018-02-08 09:17:01'),(258,223,2,12831532.00,1,'2018-02-08 09:20:21'),(259,224,1,0.00,1,'2018-02-08 09:45:45'),(260,44,1,0.00,1,'2018-02-08 09:47:00'),(261,225,1,16961.34,1,'2018-02-08 11:30:13'),(262,226,1,13549.23,1,'2018-02-08 11:37:28'),(263,227,1,1833.54,1,'2018-02-08 11:38:34'),(264,228,1,22.88,1,'2018-02-08 11:39:29'),(265,229,1,918.31,1,'2018-02-08 11:40:22'),(266,230,1,228.71,1,'2018-02-08 11:43:59'),(267,231,1,1700.09,1,'2018-02-08 11:44:58'),(268,232,1,1094.47,1,'2018-02-08 11:45:59'),(269,233,1,18378.81,1,'2018-02-08 11:50:15'),(270,234,1,76.29,1,'2018-02-08 11:50:54'),(271,235,1,101.02,1,'2018-02-08 11:52:42'),(272,236,1,5206.51,1,'2018-02-08 11:53:34'),(273,237,1,3204.75,1,'2018-02-08 11:54:23'),(274,238,1,12481.49,1,'2018-02-08 11:55:17'),(275,239,1,7930.00,1,'2018-02-08 11:56:03'),(276,240,1,13339.70,1,'2018-02-08 11:59:55'),(277,241,1,0.00,1,'2018-02-08 12:08:10'),(278,242,1,6975.77,1,'2018-02-08 12:10:39'),(279,243,1,84.94,1,'2018-02-08 12:11:20'),(280,244,1,2425.34,1,'2018-02-08 12:11:56'),(281,245,1,167.04,1,'2018-02-08 12:12:32'),(282,246,2,640000.00,1,'2018-02-08 12:15:39'),(283,247,2,1016000.00,1,'2018-02-08 12:16:21'),(284,248,1,1157.75,1,'2018-02-08 12:42:10'),(285,249,1,0.00,1,'2018-02-09 08:26:45'),(286,250,1,3792.45,1,'2018-02-09 08:28:37'),(287,251,1,3732.63,1,'2018-02-09 08:29:24'),(288,252,1,2314.14,1,'2018-02-09 08:31:45'),(289,253,1,134.87,1,'2018-02-09 08:32:32'),(290,254,1,8342.13,1,'2018-02-09 08:33:31'),(291,255,1,3883.86,1,'2018-02-09 08:41:32'),(292,256,1,2740.94,1,'2018-02-09 08:42:39'),(293,257,1,76.14,1,'2018-02-09 08:44:38'),(294,258,1,3923.59,1,'2018-02-09 08:46:54'),(295,259,1,3268.85,1,'2018-02-09 08:48:10'),(296,260,1,329.15,1,'2018-02-09 08:49:20'),(297,261,1,2919.40,1,'2018-02-09 08:50:24'),(298,262,1,3966.52,1,'2018-02-09 08:51:34'),(299,263,1,5043.21,1,'2018-02-09 08:52:35'),(300,264,1,6805.32,1,'2018-02-09 08:54:21'),(301,265,1,6538.96,1,'2018-02-09 08:55:55'),(302,266,1,2303.71,1,'2018-02-09 08:56:40'),(303,267,1,1849.66,1,'2018-02-09 08:58:39'),(304,268,1,4008.72,1,'2018-02-09 08:59:29'),(305,269,1,9400000.00,1,'2018-02-09 09:09:07'),(306,270,1,7468.76,1,'2018-02-09 12:07:12'),(307,271,1,2754.91,1,'2018-02-09 12:11:22'),(308,272,1,1434.15,1,'2018-02-09 12:12:51'),(309,273,1,109.10,1,'2018-02-09 12:14:29'),(310,274,1,7382.32,1,'2018-02-09 12:16:30'),(311,275,1,163.06,1,'2018-02-09 12:17:08'),(312,276,1,4942.28,1,'2018-02-09 12:22:22'),(313,277,2,535000.00,1,'2018-02-12 08:54:10'),(314,278,2,1463000.00,1,'2018-02-12 08:55:32'),(315,279,2,15000.00,1,'2018-02-12 09:00:58'),(316,280,2,15000.00,1,'2018-02-12 09:02:06'),(317,281,2,28941.50,1,'2018-02-12 09:06:33'),(318,282,2,122500.00,1,'2018-02-12 09:28:42'),(319,283,2,184976.16,1,'2018-02-12 09:33:36'),(320,284,2,110000.00,1,'2018-02-12 09:35:30'),(321,285,2,45296.70,1,'2018-02-12 09:38:01'),(322,286,2,713.70,0,'2018-02-12 09:53:34'),(323,287,1,1905.77,1,'2018-02-12 09:55:09'),(324,286,1,713.70,1,'2018-02-12 09:55:55'),(325,288,1,388.69,1,'2018-02-12 09:57:10'),(326,289,1,0.00,1,'2018-02-12 10:08:18'),(327,290,1,5291.09,1,'2018-02-12 10:10:02'),(328,291,1,2235.00,1,'2018-02-12 10:11:57'),(329,292,1,5845.56,1,'2018-02-12 10:12:59'),(330,293,1,130.56,1,'2018-02-12 10:13:50'),(331,294,1,120.14,1,'2018-02-12 10:14:32'),(332,295,2,205673.50,1,'2018-02-12 10:31:13'),(333,296,1,267.50,1,'2018-02-12 10:39:02'),(334,297,1,45.99,1,'2018-02-12 10:39:35'),(335,298,2,44578.50,1,'2018-02-12 11:28:45'),(336,299,2,320000.00,1,'2018-02-12 11:37:50'),(337,300,2,5390.03,1,'2018-02-12 11:53:04'),(338,68,1,12654.49,1,'2018-02-19 14:57:03'),(339,47,1,0.00,0,'2018-02-19 15:08:22'),(340,47,1,485.90,1,'2018-02-19 15:08:44'),(341,66,1,6032.63,1,'2018-02-19 15:12:11'),(342,67,1,508.39,1,'2018-02-19 15:16:07'),(343,69,1,848.84,1,'2018-02-19 15:16:30'),(344,70,1,866.15,1,'2018-02-19 15:23:31'),(345,71,1,1543.85,1,'2018-02-19 15:33:40'),(346,72,1,3355.24,1,'2018-02-19 15:59:50'),(347,73,1,822.70,1,'2018-02-19 16:00:29'),(348,74,1,2362.49,1,'2018-02-19 16:28:45'),(349,75,1,1196.70,1,'2018-02-19 16:30:01'),(350,76,1,6480.64,1,'2018-02-19 16:31:00'),(351,77,1,6689.97,1,'2018-02-19 16:45:32'),(352,78,1,2149.50,1,'2018-02-19 16:52:17'),(353,79,1,2569.96,1,'2018-02-19 16:52:47');
/*!40000 ALTER TABLE `proyecto_gasto_monto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proyecto_gasto_tipo`
--

DROP TABLE IF EXISTS `proyecto_gasto_tipo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `proyecto_gasto_tipo` (
  `proyecto_gasto_tipo_id` int(11) NOT NULL AUTO_INCREMENT,
  `proyecto_gasto_tipo` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`proyecto_gasto_tipo_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proyecto_gasto_tipo`
--

LOCK TABLES `proyecto_gasto_tipo` WRITE;
/*!40000 ALTER TABLE `proyecto_gasto_tipo` DISABLE KEYS */;
INSERT INTO `proyecto_gasto_tipo` (`proyecto_gasto_tipo_id`, `proyecto_gasto_tipo`) VALUES (1,'Gasto en Materiales'),(2,'Gasto en Mano de Obra'),(3,'Gasto de Operación'),(4,'Gasto Administrativo');
/*!40000 ALTER TABLE `proyecto_gasto_tipo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proyecto_tipo_cambio`
--

DROP TABLE IF EXISTS `proyecto_tipo_cambio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `proyecto_tipo_cambio` (
  `proyecto_tipo_cambio_id` int(11) NOT NULL AUTO_INCREMENT,
  `proyecto_id` int(11) NOT NULL,
  `moneda_base_id` int(11) NOT NULL,
  `moneda_destino_id` int(11) NOT NULL,
  `valor_compra` float(10,2) NOT NULL,
  `valor_venta` float(10,2) NOT NULL,
  `fecha_registro` datetime NOT NULL,
  PRIMARY KEY (`proyecto_tipo_cambio_id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proyecto_tipo_cambio`
--

LOCK TABLES `proyecto_tipo_cambio` WRITE;
/*!40000 ALTER TABLE `proyecto_tipo_cambio` DISABLE KEYS */;
INSERT INTO `proyecto_tipo_cambio` (`proyecto_tipo_cambio_id`, `proyecto_id`, `moneda_base_id`, `moneda_destino_id`, `valor_compra`, `valor_venta`, `fecha_registro`) VALUES (17,17,1,2,562.00,565.00,'2018-01-18 12:00:38'),(18,18,1,2,562.00,566.00,'2018-01-18 12:06:55'),(19,19,1,2,562.00,566.00,'2018-01-18 12:18:22'),(21,21,1,2,562.00,568.00,'2018-01-19 15:36:46'),(22,22,1,2,562.00,578.00,'2018-01-26 17:03:13'),(23,23,1,2,570.52,575.13,'2018-02-08 09:45:45'),(24,24,1,2,570.52,575.13,'2018-02-08 12:08:10'),(25,25,1,2,0.00,0.00,'2018-02-09 08:26:45'),(26,26,1,2,0.00,0.00,'2018-02-12 10:08:18');
/*!40000 ALTER TABLE `proyecto_tipo_cambio` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proyecto_valor_oferta`
--

DROP TABLE IF EXISTS `proyecto_valor_oferta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `proyecto_valor_oferta` (
  `proyecto_valor_oferta_id` int(11) NOT NULL AUTO_INCREMENT,
  `proyecto_valor_oferta_tipo_id` int(11) NOT NULL,
  `proyecto_id` int(11) NOT NULL,
  `moneda_id` int(11) NOT NULL,
  `valor_oferta` float(20,2) NOT NULL,
  `fecha_registro` datetime NOT NULL,
  `estado_registro` int(1) NOT NULL COMMENT '0 = inactivo, 1 = activo',
  PRIMARY KEY (`proyecto_valor_oferta_id`)
) ENGINE=InnoDB AUTO_INCREMENT=156 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proyecto_valor_oferta`
--

LOCK TABLES `proyecto_valor_oferta` WRITE;
/*!40000 ALTER TABLE `proyecto_valor_oferta` DISABLE KEYS */;
INSERT INTO `proyecto_valor_oferta` (`proyecto_valor_oferta_id`, `proyecto_valor_oferta_tipo_id`, `proyecto_id`, `moneda_id`, `valor_oferta`, `fecha_registro`, `estado_registro`) VALUES (106,1,17,1,39996.47,'2018-01-18 12:00:38',1),(107,2,17,1,34663.59,'2018-01-18 12:00:38',1),(108,3,17,1,1000.00,'2018-01-18 12:00:38',1),(109,4,17,1,0.00,'2018-01-18 12:00:38',1),(110,5,17,1,11720.99,'2018-01-18 12:00:38',1),(111,1,18,1,200000.00,'2018-01-18 12:06:55',1),(112,2,18,1,200000.00,'2018-01-18 12:06:55',1),(113,3,18,1,33000.00,'2018-01-18 12:06:55',1),(114,4,18,1,33000.00,'2018-01-18 12:06:55',1),(115,5,18,1,34000.00,'2018-01-18 12:06:55',1),(116,1,19,1,10000.00,'2018-01-18 12:18:22',1),(117,2,19,1,5000.00,'2018-01-18 12:18:22',1),(118,3,19,1,3000.00,'2018-01-18 12:18:22',1),(119,4,19,1,2000.00,'2018-01-18 12:18:22',1),(120,5,19,1,3000.00,'2018-01-18 12:18:22',1),(126,1,21,1,197246.00,'2018-01-19 15:36:46',1),(127,2,21,1,118348.00,'2018-01-19 15:36:46',1),(128,3,21,1,19724.00,'2018-01-19 15:36:46',1),(129,4,21,1,19724.00,'2018-01-19 15:36:46',1),(130,5,21,1,39449.00,'2018-01-19 15:36:46',1),(131,1,22,1,260000.00,'2018-01-26 17:03:12',1),(132,2,22,1,140000.00,'2018-01-26 17:03:12',1),(133,3,22,1,6000.00,'2018-01-26 17:03:12',1),(134,4,22,1,4000.00,'2018-01-26 17:03:12',1),(135,5,22,1,90000.00,'2018-01-26 17:03:12',1),(136,1,23,1,0.00,'2018-02-08 09:45:45',1),(137,2,23,1,0.00,'2018-02-08 09:45:45',1),(138,3,23,1,0.00,'2018-02-08 09:45:45',1),(139,4,23,1,0.00,'2018-02-08 09:45:45',1),(140,5,23,1,0.00,'2018-02-08 09:45:45',1),(141,1,24,1,0.00,'2018-02-08 12:08:10',1),(142,2,24,1,0.00,'2018-02-08 12:08:10',1),(143,3,24,1,0.00,'2018-02-08 12:08:10',1),(144,4,24,1,0.00,'2018-02-08 12:08:10',1),(145,5,24,1,0.00,'2018-02-08 12:08:10',1),(146,1,25,1,0.00,'2018-02-09 08:26:45',1),(147,2,25,1,0.00,'2018-02-09 08:26:45',1),(148,3,25,1,0.00,'2018-02-09 08:26:45',1),(149,4,25,1,0.00,'2018-02-09 08:26:45',1),(150,5,25,1,0.00,'2018-02-09 08:26:45',1),(151,1,26,1,0.00,'2018-02-12 10:08:18',1),(152,2,26,1,0.00,'2018-02-12 10:08:18',1),(153,3,26,1,0.00,'2018-02-12 10:08:18',1),(154,4,26,1,0.00,'2018-02-12 10:08:18',1),(155,5,26,1,0.00,'2018-02-12 10:08:18',1);
/*!40000 ALTER TABLE `proyecto_valor_oferta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proyecto_valor_oferta_extension_detalle`
--

DROP TABLE IF EXISTS `proyecto_valor_oferta_extension_detalle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `proyecto_valor_oferta_extension_detalle` (
  `proyecto_valor_oferta_extension_detalle_id` int(11) NOT NULL AUTO_INCREMENT,
  `proyecto_valor_oferta_id` int(11) NOT NULL,
  `proyecto_valor_oferta_extension_tipo_id` int(11) NOT NULL,
  `proyecto_valor_oferta_extension_descripcion` text COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`proyecto_valor_oferta_extension_detalle_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proyecto_valor_oferta_extension_detalle`
--

LOCK TABLES `proyecto_valor_oferta_extension_detalle` WRITE;
/*!40000 ALTER TABLE `proyecto_valor_oferta_extension_detalle` DISABLE KEYS */;
/*!40000 ALTER TABLE `proyecto_valor_oferta_extension_detalle` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proyecto_valor_oferta_extension_tipo`
--

DROP TABLE IF EXISTS `proyecto_valor_oferta_extension_tipo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `proyecto_valor_oferta_extension_tipo` (
  `proyecto_valor_oferta_extension_tipo_id` int(11) NOT NULL AUTO_INCREMENT,
  `proyecto_valor_oferta_extension_tipo` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `estado_registro` int(11) NOT NULL COMMENT '0 = Inactivo, 1 = activo',
  PRIMARY KEY (`proyecto_valor_oferta_extension_tipo_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proyecto_valor_oferta_extension_tipo`
--

LOCK TABLES `proyecto_valor_oferta_extension_tipo` WRITE;
/*!40000 ALTER TABLE `proyecto_valor_oferta_extension_tipo` DISABLE KEYS */;
INSERT INTO `proyecto_valor_oferta_extension_tipo` (`proyecto_valor_oferta_extension_tipo_id`, `proyecto_valor_oferta_extension_tipo`, `estado_registro`) VALUES (1,'Paredes',1),(2,'Cielo',1),(3,'Pisos',1);
/*!40000 ALTER TABLE `proyecto_valor_oferta_extension_tipo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proyecto_valor_oferta_tipo`
--

DROP TABLE IF EXISTS `proyecto_valor_oferta_tipo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `proyecto_valor_oferta_tipo` (
  `proyecto_valor_oferta_tipo_id` int(11) NOT NULL AUTO_INCREMENT,
  `proyecto_valor_oferta_tipo` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`proyecto_valor_oferta_tipo_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proyecto_valor_oferta_tipo`
--

LOCK TABLES `proyecto_valor_oferta_tipo` WRITE;
/*!40000 ALTER TABLE `proyecto_valor_oferta_tipo` DISABLE KEYS */;
INSERT INTO `proyecto_valor_oferta_tipo` (`proyecto_valor_oferta_tipo_id`, `proyecto_valor_oferta_tipo`) VALUES (1,'Valor de Materiales'),(2,'Valor de Mano de Obra'),(3,'Valor de Gastos de Operación'),(4,'Valor de Gastos Administrativos'),(5,'Valor de Utilidad'),(6,'Valor de Extensiones');
/*!40000 ALTER TABLE `proyecto_valor_oferta_tipo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuario`
--

DROP TABLE IF EXISTS `usuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usuario` (
  `usuario_id` int(11) NOT NULL AUTO_INCREMENT,
  `fecha_registro` datetime NOT NULL,
  `rol_id` int(11) NOT NULL,
  `estado_id` int(11) NOT NULL,
  `usuario` text COLLATE utf8_spanish_ci NOT NULL,
  `password` char(255) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`usuario_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuario`
--

LOCK TABLES `usuario` WRITE;
/*!40000 ALTER TABLE `usuario` DISABLE KEYS */;
INSERT INTO `usuario` (`usuario_id`, `fecha_registro`, `rol_id`, `estado_id`, `usuario`, `password`) VALUES (1,'2017-12-01 06:19:38',1,1,'instatec_admin','$2y$10$UDJh9W7b0YR5.yNPEmNyLO6j8ZSN.f/7WXt136JrAEumTXbVfbdQC'),(2,'2017-12-01 06:21:48',1,1,'keylormg','$2y$10$H/zVeP80TCO1oY1Qo6ZzbOMUUphGPyCdVDD43IZFaQ24dISqo5s9y');
/*!40000 ALTER TABLE `usuario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuario_bitacora_cambios`
--

DROP TABLE IF EXISTS `usuario_bitacora_cambios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usuario_bitacora_cambios` (
  `usuario_bitacora_cambio_id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario_id` int(11) NOT NULL,
  `fecha_cambio` datetime NOT NULL,
  `tipo` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  `tabla` varchar(60) COLLATE utf8_spanish_ci NOT NULL,
  `id_fila` int(11) NOT NULL,
  PRIMARY KEY (`usuario_bitacora_cambio_id`)
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuario_bitacora_cambios`
--

LOCK TABLES `usuario_bitacora_cambios` WRITE;
/*!40000 ALTER TABLE `usuario_bitacora_cambios` DISABLE KEYS */;
INSERT INTO `usuario_bitacora_cambios` (`usuario_bitacora_cambio_id`, `usuario_id`, `fecha_cambio`, `tipo`, `tabla`, `id_fila`) VALUES (32,1,'2018-01-18 12:01:44','edicion','',17),(33,1,'2018-01-18 13:38:48','edicion','',20),(34,1,'2018-01-18 15:53:49','edicion','',20),(35,1,'2018-01-18 16:30:11','edicion','',20),(36,1,'2018-01-18 19:20:45','edicion','',20),(37,1,'2018-01-18 20:46:56','edicion','',17),(38,1,'2018-01-19 06:19:16','edicion','',20),(39,1,'2018-01-19 15:38:15','edicion','',21),(40,1,'2018-01-19 15:39:16','edicion','',21),(41,1,'2018-01-19 15:39:45','edicion','',21),(42,1,'2018-01-19 15:39:49','edicion','',17),(43,1,'2018-01-19 15:49:18','edicion','',17),(44,1,'2018-01-19 15:49:46','edicion','',17),(45,1,'2018-01-19 15:55:28','edicion','',21),(46,1,'2018-01-20 07:20:02','edicion','',21),(47,1,'2018-02-03 22:20:43','edicion','',17),(48,1,'2018-02-07 12:14:16','edicion','proveedor',16),(49,1,'2018-02-08 09:47:00','edicion','',17),(50,1,'2018-02-08 11:07:47','edicion','',23),(51,1,'2018-02-08 11:07:57','edicion','',23),(52,1,'2018-02-08 11:25:20','edicion','',23),(53,1,'2018-02-08 11:25:26','edicion','',23),(54,1,'2018-02-08 12:03:10','edicion','',23),(55,1,'2018-02-08 12:08:03','edicion','',23);
/*!40000 ALTER TABLE `usuario_bitacora_cambios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuario_bitacora_ingreso`
--

DROP TABLE IF EXISTS `usuario_bitacora_ingreso`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usuario_bitacora_ingreso` (
  `usuario_bitacora_id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario_id` int(11) NOT NULL,
  `fecha_ingreso` datetime NOT NULL,
  `ip` varchar(60) COLLATE utf8_spanish_ci NOT NULL,
  `agente_usuario` varchar(300) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`usuario_bitacora_id`)
) ENGINE=InnoDB AUTO_INCREMENT=92 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuario_bitacora_ingreso`
--

LOCK TABLES `usuario_bitacora_ingreso` WRITE;
/*!40000 ALTER TABLE `usuario_bitacora_ingreso` DISABLE KEYS */;
INSERT INTO `usuario_bitacora_ingreso` (`usuario_bitacora_id`, `usuario_id`, `fecha_ingreso`, `ip`, `agente_usuario`) VALUES (46,1,'2018-01-17 21:01:50','186.177.172.237','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36'),(47,1,'2018-01-18 07:23:40','138.94.57.137','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36 Edge/16.16299'),(48,1,'2018-01-18 09:43:37','138.94.57.137','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36 Edge/16.16299'),(49,1,'2018-01-18 10:20:27','138.94.57.137','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36'),(50,1,'2018-01-18 11:23:16','167.250.193.173','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36'),(51,1,'2018-01-18 11:55:42','138.94.57.137','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36'),(52,1,'2018-01-18 12:10:07','181.194.195.246','Mozilla/5.0 (iPad; CPU OS 11_2_2 like Mac OS X) AppleWebKit/604.4.7 (KHTML, like Gecko) Version/11.0 Mobile/15C202 Safari/604.1'),(53,1,'2018-01-18 12:13:21','138.94.57.137','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36'),(54,1,'2018-01-18 12:17:25','138.94.57.137','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36'),(55,1,'2018-01-18 12:34:40','138.94.57.137','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36'),(56,1,'2018-01-18 15:51:47','201.191.198.41','Mozilla/5.0 (iPad; CPU OS 11_2_2 like Mac OS X) AppleWebKit/604.4.7 (KHTML, like Gecko) Version/11.0 Mobile/15C202 Safari/604.1'),(57,1,'2018-01-18 19:19:57','186.177.155.150','Mozilla/5.0 (iPad; CPU OS 11_2_2 like Mac OS X) AppleWebKit/604.4.7 (KHTML, like Gecko) Version/11.0 Mobile/15C202 Safari/604.1'),(58,1,'2018-01-18 19:19:58','186.177.155.150','Mozilla/5.0 (iPad; CPU OS 11_2_2 like Mac OS X) AppleWebKit/604.4.7 (KHTML, like Gecko) Version/11.0 Mobile/15C202 Safari/604.1'),(59,1,'2018-01-18 20:29:03','186.177.172.237','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36'),(60,1,'2018-01-19 06:09:11','201.191.199.168','Mozilla/5.0 (iPad; CPU OS 11_2_2 like Mac OS X) AppleWebKit/604.4.7 (KHTML, like Gecko) Version/11.0 Mobile/15C202 Safari/604.1'),(61,1,'2018-01-19 06:29:22','138.94.57.137','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36'),(62,1,'2018-01-19 12:12:59','138.94.57.137','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36'),(63,1,'2018-01-19 14:49:44','138.94.57.137','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36'),(64,1,'2018-01-19 15:01:07','186.177.155.150','Mozilla/5.0 (iPad; CPU OS 11_2_2 like Mac OS X) AppleWebKit/604.4.7 (KHTML, like Gecko) Version/11.0 Mobile/15C202 Safari/604.1'),(65,1,'2018-01-19 20:10:33','201.191.199.144','Mozilla/5.0 (Linux; Android 7.0; SAMSUNG SM-G950F Build/NRD90M) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/6.2 Chrome/56.0.2924.87 Mobile Safari/537.36'),(66,1,'2018-01-20 06:36:39','201.191.199.158','Mozilla/5.0 (Linux; Android 7.0; SAMSUNG SM-G950F Build/NRD90M) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/6.2 Chrome/56.0.2924.87 Mobile Safari/537.36'),(67,1,'2018-01-20 06:55:34','181.194.195.246','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36'),(68,1,'2018-01-20 13:05:31','181.194.195.246','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36'),(69,1,'2018-01-20 13:35:22','181.194.195.246','Mozilla/5.0 (iPad; CPU OS 11_2_2 like Mac OS X) AppleWebKit/604.4.7 (KHTML, like Gecko) Version/11.0 Mobile/15C202 Safari/604.1'),(70,1,'2018-01-22 12:53:25','138.94.57.137','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36'),(71,1,'2018-01-24 07:48:07','167.250.193.173','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36'),(72,1,'2018-01-25 12:32:00','167.250.193.173','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36'),(73,1,'2018-01-26 16:51:12','138.94.57.137','Mozilla/5.0 (iPad; CPU OS 11_2_2 like Mac OS X) AppleWebKit/604.4.7 (KHTML, like Gecko) Version/11.0 Mobile/15C202 Safari/604.1'),(74,1,'2018-01-26 19:11:47','201.205.51.11','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36'),(75,1,'2018-01-29 12:10:23','138.94.57.137','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36'),(76,1,'2018-01-29 12:13:42','138.94.57.137','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36'),(77,1,'2018-02-01 20:33:40','186.177.172.237','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36'),(78,1,'2018-02-01 20:37:59','186.177.155.150','Mozilla/5.0 (iPad; CPU OS 11_2_2 like Mac OS X) AppleWebKit/604.4.7 (KHTML, like Gecko) Version/11.0 Mobile/15C202 Safari/604.1'),(79,1,'2018-02-03 22:18:15','186.177.155.150','Mozilla/5.0 (iPad; CPU OS 11_2_2 like Mac OS X) AppleWebKit/604.4.7 (KHTML, like Gecko) Version/11.0 Mobile/15C202 Safari/604.1'),(80,1,'2018-02-05 09:56:33','138.94.57.137','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36'),(81,1,'2018-02-05 10:03:35','138.94.57.137','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36'),(82,1,'2018-02-05 10:49:50','138.94.57.137','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36'),(83,1,'2018-02-06 08:26:51','138.94.57.137','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36'),(84,1,'2018-02-07 08:27:17','138.94.57.137','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.140 Safari/537.36'),(85,1,'2018-02-08 08:31:43','138.94.57.137','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.140 Safari/537.36'),(86,1,'2018-02-08 12:50:51','138.94.57.137','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.140 Safari/537.36'),(87,1,'2018-02-09 08:24:09','138.94.57.137','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.140 Safari/537.36'),(88,1,'2018-02-09 10:47:52','138.94.57.137','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.140 Safari/537.36'),(89,1,'2018-02-12 08:51:37','138.94.57.137','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.140 Safari/537.36'),(90,1,'2018-02-19 14:56:17','138.94.57.137','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.167 Safari/537.36'),(91,1,'2018-02-19 15:07:56','138.94.57.137','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.167 Safari/537.36');
/*!40000 ALTER TABLE `usuario_bitacora_ingreso` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuario_colaborador`
--

DROP TABLE IF EXISTS `usuario_colaborador`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usuario_colaborador` (
  `usuario_colaborador_id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario_id` int(11) NOT NULL,
  `colaborador_id` int(11) NOT NULL,
  PRIMARY KEY (`usuario_colaborador_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuario_colaborador`
--

LOCK TABLES `usuario_colaborador` WRITE;
/*!40000 ALTER TABLE `usuario_colaborador` DISABLE KEYS */;
/*!40000 ALTER TABLE `usuario_colaborador` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuario_detalle`
--

DROP TABLE IF EXISTS `usuario_detalle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usuario_detalle` (
  `usuario_detalle_id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario_id` int(11) NOT NULL,
  `nombre` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `apellidos` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `correo` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`usuario_detalle_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuario_detalle`
--

LOCK TABLES `usuario_detalle` WRITE;
/*!40000 ALTER TABLE `usuario_detalle` DISABLE KEYS */;
INSERT INTO `usuario_detalle` (`usuario_detalle_id`, `usuario_id`, `nombre`, `apellidos`, `correo`) VALUES (1,1,'Arlen','Loaiza','info@instateccr.com'),(2,2,'Keylor','Mora','khmg13@gmail.com');
/*!40000 ALTER TABLE `usuario_detalle` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuario_estado`
--

DROP TABLE IF EXISTS `usuario_estado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usuario_estado` (
  `estado_id` int(11) NOT NULL AUTO_INCREMENT,
  `estado` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`estado_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuario_estado`
--

LOCK TABLES `usuario_estado` WRITE;
/*!40000 ALTER TABLE `usuario_estado` DISABLE KEYS */;
INSERT INTO `usuario_estado` (`estado_id`, `estado`) VALUES (1,'activo'),(2,'inactivo');
/*!40000 ALTER TABLE `usuario_estado` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuario_rol`
--

DROP TABLE IF EXISTS `usuario_rol`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usuario_rol` (
  `rol_id` int(11) NOT NULL AUTO_INCREMENT,
  `rol` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`rol_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuario_rol`
--

LOCK TABLES `usuario_rol` WRITE;
/*!40000 ALTER TABLE `usuario_rol` DISABLE KEYS */;
INSERT INTO `usuario_rol` (`rol_id`, `rol`) VALUES (1,'administrador'),(2,'asistente'),(3,'jefe_proyecto'),(4,'colaborador');
/*!40000 ALTER TABLE `usuario_rol` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuario_rol_permiso`
--

DROP TABLE IF EXISTS `usuario_rol_permiso`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usuario_rol_permiso` (
  `usuario_rol_permiso_id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario_rol_id` int(11) NOT NULL,
  `modulo` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `funcion` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `estado_permiso` int(1) NOT NULL,
  PRIMARY KEY (`usuario_rol_permiso_id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuario_rol_permiso`
--

LOCK TABLES `usuario_rol_permiso` WRITE;
/*!40000 ALTER TABLE `usuario_rol_permiso` DISABLE KEYS */;
INSERT INTO `usuario_rol_permiso` (`usuario_rol_permiso_id`, `usuario_rol_id`, `modulo`, `funcion`, `estado_permiso`) VALUES (1,1,'proyecto','create',1),(2,1,'proyecto','view',1),(3,1,'proyecto','edit',1),(4,1,'proyecto','delete',1),(5,1,'proyecto','list',1),(6,1,'cliente','create',1),(7,1,'cliente','view',1),(8,1,'cliente','edit',1),(9,1,'cliente','delete',1),(10,1,'cliente','list',1),(11,1,'proveedor','create',1),(12,1,'proveedor','view',1),(13,1,'proveedor','edit',1),(14,1,'proveedor','delete',1),(15,1,'proveedor','list',1),(16,1,'proyecto_extensiones','create',1),(17,1,'proyecto_extensiones','view',1),(18,1,'proyecto_extensiones','edit',1),(19,1,'proyecto_extensiones','list',1),(20,1,'proyecto_extensiones','delete',1),(21,1,'proyecto_gastos','create',1),(22,1,'proyecto_gastos','view',1),(23,1,'proyecto_gastos','edit',1),(24,1,'proyecto_gastos','delete',1),(25,1,'proyecto_gastos','list',1),(26,1,'reporte','list',1),(27,1,'reporte_proyecto_especifico','view',1);
/*!40000 ALTER TABLE `usuario_rol_permiso` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'instatec_cc_db'
--

--
-- Dumping routines for database 'instatec_cc_db'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-02-20 22:17:37
