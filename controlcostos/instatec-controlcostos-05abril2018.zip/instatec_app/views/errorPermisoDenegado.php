<script src="/instatec_pub/js/cliente.js"></script>
<!-- Breadcrumbs-->
<ol class="breadcrumb">
	<li class="breadcrumb-item">
	  <a href="/">Inicio</a>
	</li>
	<li class="breadcrumb-item active">Acceso denegado</li>
</ol>

<h1 class="text-center"><i class="fa fa-fw fa-exclamation-circle"></i> Acceso no permitido</h1>
<hr>

<p>No posee permisos para ingresar a esta página.</p>

<a href='/' class='btn btn-primary'>Volver al inicio</a>