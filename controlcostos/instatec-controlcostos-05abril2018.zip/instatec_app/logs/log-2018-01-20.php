<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-01-20 06:36:33 --> Config Class Initialized
INFO - 2018-01-20 06:36:33 --> Hooks Class Initialized
DEBUG - 2018-01-20 06:36:33 --> UTF-8 Support Enabled
INFO - 2018-01-20 06:36:33 --> Utf8 Class Initialized
INFO - 2018-01-20 06:36:33 --> URI Class Initialized
DEBUG - 2018-01-20 06:36:33 --> No URI present. Default controller set.
INFO - 2018-01-20 06:36:33 --> Router Class Initialized
INFO - 2018-01-20 06:36:33 --> Output Class Initialized
INFO - 2018-01-20 06:36:33 --> Security Class Initialized
DEBUG - 2018-01-20 06:36:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-20 06:36:33 --> Input Class Initialized
INFO - 2018-01-20 06:36:33 --> Language Class Initialized
INFO - 2018-01-20 06:36:33 --> Loader Class Initialized
INFO - 2018-01-20 06:36:33 --> Helper loaded: url_helper
INFO - 2018-01-20 06:36:33 --> Helper loaded: form_helper
INFO - 2018-01-20 06:36:33 --> Database Driver Class Initialized
DEBUG - 2018-01-20 06:36:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-20 06:36:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-20 06:36:33 --> Form Validation Class Initialized
INFO - 2018-01-20 06:36:34 --> Model Class Initialized
INFO - 2018-01-20 06:36:34 --> Controller Class Initialized
INFO - 2018-01-20 06:36:34 --> Config Class Initialized
INFO - 2018-01-20 06:36:34 --> Hooks Class Initialized
DEBUG - 2018-01-20 06:36:34 --> UTF-8 Support Enabled
INFO - 2018-01-20 06:36:34 --> Utf8 Class Initialized
INFO - 2018-01-20 06:36:34 --> URI Class Initialized
INFO - 2018-01-20 06:36:34 --> Router Class Initialized
INFO - 2018-01-20 06:36:34 --> Output Class Initialized
INFO - 2018-01-20 06:36:34 --> Security Class Initialized
DEBUG - 2018-01-20 06:36:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-20 06:36:34 --> Input Class Initialized
INFO - 2018-01-20 06:36:34 --> Language Class Initialized
INFO - 2018-01-20 06:36:34 --> Loader Class Initialized
INFO - 2018-01-20 06:36:34 --> Helper loaded: url_helper
INFO - 2018-01-20 06:36:34 --> Helper loaded: form_helper
INFO - 2018-01-20 06:36:34 --> Database Driver Class Initialized
DEBUG - 2018-01-20 06:36:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-20 06:36:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-20 06:36:34 --> Form Validation Class Initialized
INFO - 2018-01-20 06:36:34 --> Model Class Initialized
INFO - 2018-01-20 06:36:34 --> Controller Class Initialized
INFO - 2018-01-20 06:36:34 --> Model Class Initialized
DEBUG - 2018-01-20 06:36:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-20 06:36:34 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-20 06:36:34 --> Final output sent to browser
DEBUG - 2018-01-20 06:36:34 --> Total execution time: 0.2024
INFO - 2018-01-20 06:36:39 --> Config Class Initialized
INFO - 2018-01-20 06:36:39 --> Hooks Class Initialized
DEBUG - 2018-01-20 06:36:39 --> UTF-8 Support Enabled
INFO - 2018-01-20 06:36:39 --> Utf8 Class Initialized
INFO - 2018-01-20 06:36:39 --> URI Class Initialized
INFO - 2018-01-20 06:36:39 --> Router Class Initialized
INFO - 2018-01-20 06:36:39 --> Output Class Initialized
INFO - 2018-01-20 06:36:39 --> Security Class Initialized
DEBUG - 2018-01-20 06:36:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-20 06:36:39 --> Input Class Initialized
INFO - 2018-01-20 06:36:39 --> Language Class Initialized
INFO - 2018-01-20 06:36:39 --> Loader Class Initialized
INFO - 2018-01-20 06:36:39 --> Helper loaded: url_helper
INFO - 2018-01-20 06:36:39 --> Helper loaded: form_helper
INFO - 2018-01-20 06:36:39 --> Database Driver Class Initialized
DEBUG - 2018-01-20 06:36:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-20 06:36:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-20 06:36:39 --> Form Validation Class Initialized
INFO - 2018-01-20 06:36:39 --> Model Class Initialized
INFO - 2018-01-20 06:36:39 --> Controller Class Initialized
INFO - 2018-01-20 06:36:39 --> Model Class Initialized
DEBUG - 2018-01-20 06:36:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-20 06:36:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-01-20 06:36:42 --> Config Class Initialized
INFO - 2018-01-20 06:36:42 --> Hooks Class Initialized
DEBUG - 2018-01-20 06:36:42 --> UTF-8 Support Enabled
INFO - 2018-01-20 06:36:42 --> Utf8 Class Initialized
INFO - 2018-01-20 06:36:42 --> URI Class Initialized
DEBUG - 2018-01-20 06:36:42 --> No URI present. Default controller set.
INFO - 2018-01-20 06:36:42 --> Router Class Initialized
INFO - 2018-01-20 06:36:42 --> Output Class Initialized
INFO - 2018-01-20 06:36:42 --> Security Class Initialized
DEBUG - 2018-01-20 06:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-20 06:36:42 --> Input Class Initialized
INFO - 2018-01-20 06:36:42 --> Language Class Initialized
INFO - 2018-01-20 06:36:42 --> Loader Class Initialized
INFO - 2018-01-20 06:36:42 --> Helper loaded: url_helper
INFO - 2018-01-20 06:36:42 --> Helper loaded: form_helper
INFO - 2018-01-20 06:36:42 --> Database Driver Class Initialized
DEBUG - 2018-01-20 06:36:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-20 06:36:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-20 06:36:42 --> Form Validation Class Initialized
INFO - 2018-01-20 06:36:42 --> Model Class Initialized
INFO - 2018-01-20 06:36:42 --> Controller Class Initialized
INFO - 2018-01-20 06:36:42 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-20 06:36:42 --> Final output sent to browser
DEBUG - 2018-01-20 06:36:42 --> Total execution time: 0.0524
INFO - 2018-01-20 06:36:46 --> Config Class Initialized
INFO - 2018-01-20 06:36:46 --> Hooks Class Initialized
DEBUG - 2018-01-20 06:36:46 --> UTF-8 Support Enabled
INFO - 2018-01-20 06:36:46 --> Utf8 Class Initialized
INFO - 2018-01-20 06:36:46 --> URI Class Initialized
INFO - 2018-01-20 06:36:46 --> Router Class Initialized
INFO - 2018-01-20 06:36:46 --> Output Class Initialized
INFO - 2018-01-20 06:36:46 --> Security Class Initialized
DEBUG - 2018-01-20 06:36:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-20 06:36:46 --> Input Class Initialized
INFO - 2018-01-20 06:36:46 --> Language Class Initialized
INFO - 2018-01-20 06:36:46 --> Loader Class Initialized
INFO - 2018-01-20 06:36:46 --> Helper loaded: url_helper
INFO - 2018-01-20 06:36:46 --> Helper loaded: form_helper
INFO - 2018-01-20 06:36:46 --> Database Driver Class Initialized
DEBUG - 2018-01-20 06:36:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-20 06:36:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-20 06:36:46 --> Form Validation Class Initialized
INFO - 2018-01-20 06:36:46 --> Model Class Initialized
INFO - 2018-01-20 06:36:46 --> Controller Class Initialized
INFO - 2018-01-20 06:36:46 --> Model Class Initialized
INFO - 2018-01-20 06:36:46 --> Model Class Initialized
INFO - 2018-01-20 06:36:46 --> Model Class Initialized
INFO - 2018-01-20 06:36:46 --> Model Class Initialized
DEBUG - 2018-01-20 06:36:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-20 06:36:46 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-20 06:36:46 --> Final output sent to browser
DEBUG - 2018-01-20 06:36:46 --> Total execution time: 0.2287
INFO - 2018-01-20 06:36:46 --> Config Class Initialized
INFO - 2018-01-20 06:36:46 --> Hooks Class Initialized
DEBUG - 2018-01-20 06:36:46 --> UTF-8 Support Enabled
INFO - 2018-01-20 06:36:46 --> Utf8 Class Initialized
INFO - 2018-01-20 06:36:46 --> URI Class Initialized
INFO - 2018-01-20 06:36:46 --> Router Class Initialized
INFO - 2018-01-20 06:36:46 --> Output Class Initialized
INFO - 2018-01-20 06:36:46 --> Security Class Initialized
DEBUG - 2018-01-20 06:36:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-20 06:36:46 --> Input Class Initialized
INFO - 2018-01-20 06:36:46 --> Language Class Initialized
INFO - 2018-01-20 06:36:46 --> Loader Class Initialized
INFO - 2018-01-20 06:36:46 --> Helper loaded: url_helper
INFO - 2018-01-20 06:36:46 --> Helper loaded: form_helper
INFO - 2018-01-20 06:36:46 --> Database Driver Class Initialized
DEBUG - 2018-01-20 06:36:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-20 06:36:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-20 06:36:46 --> Form Validation Class Initialized
INFO - 2018-01-20 06:36:46 --> Model Class Initialized
INFO - 2018-01-20 06:36:46 --> Controller Class Initialized
INFO - 2018-01-20 06:36:46 --> Model Class Initialized
INFO - 2018-01-20 06:36:46 --> Model Class Initialized
INFO - 2018-01-20 06:36:46 --> Model Class Initialized
INFO - 2018-01-20 06:36:46 --> Model Class Initialized
DEBUG - 2018-01-20 06:36:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-20 06:37:31 --> Config Class Initialized
INFO - 2018-01-20 06:37:31 --> Hooks Class Initialized
DEBUG - 2018-01-20 06:37:31 --> UTF-8 Support Enabled
INFO - 2018-01-20 06:37:31 --> Utf8 Class Initialized
INFO - 2018-01-20 06:37:31 --> URI Class Initialized
INFO - 2018-01-20 06:37:31 --> Router Class Initialized
INFO - 2018-01-20 06:37:31 --> Output Class Initialized
INFO - 2018-01-20 06:37:31 --> Security Class Initialized
DEBUG - 2018-01-20 06:37:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-20 06:37:31 --> Input Class Initialized
INFO - 2018-01-20 06:37:31 --> Language Class Initialized
INFO - 2018-01-20 06:37:31 --> Loader Class Initialized
INFO - 2018-01-20 06:37:31 --> Helper loaded: url_helper
INFO - 2018-01-20 06:37:31 --> Helper loaded: form_helper
INFO - 2018-01-20 06:37:31 --> Database Driver Class Initialized
DEBUG - 2018-01-20 06:37:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-20 06:37:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-20 06:37:33 --> Form Validation Class Initialized
INFO - 2018-01-20 06:37:33 --> Model Class Initialized
INFO - 2018-01-20 06:37:33 --> Controller Class Initialized
INFO - 2018-01-20 06:37:33 --> Model Class Initialized
INFO - 2018-01-20 06:37:33 --> Model Class Initialized
INFO - 2018-01-20 06:37:33 --> Model Class Initialized
INFO - 2018-01-20 06:37:33 --> Model Class Initialized
DEBUG - 2018-01-20 06:37:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-20 06:37:33 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-20 06:37:33 --> Final output sent to browser
DEBUG - 2018-01-20 06:37:33 --> Total execution time: 2.0953
INFO - 2018-01-20 06:37:34 --> Config Class Initialized
INFO - 2018-01-20 06:37:34 --> Hooks Class Initialized
DEBUG - 2018-01-20 06:37:34 --> UTF-8 Support Enabled
INFO - 2018-01-20 06:37:34 --> Utf8 Class Initialized
INFO - 2018-01-20 06:37:34 --> URI Class Initialized
INFO - 2018-01-20 06:37:34 --> Router Class Initialized
INFO - 2018-01-20 06:37:34 --> Output Class Initialized
INFO - 2018-01-20 06:37:34 --> Security Class Initialized
DEBUG - 2018-01-20 06:37:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-20 06:37:34 --> Input Class Initialized
INFO - 2018-01-20 06:37:34 --> Language Class Initialized
INFO - 2018-01-20 06:37:34 --> Loader Class Initialized
INFO - 2018-01-20 06:37:34 --> Helper loaded: url_helper
INFO - 2018-01-20 06:37:34 --> Helper loaded: form_helper
INFO - 2018-01-20 06:37:34 --> Database Driver Class Initialized
DEBUG - 2018-01-20 06:37:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-20 06:37:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-20 06:37:34 --> Form Validation Class Initialized
INFO - 2018-01-20 06:37:34 --> Model Class Initialized
INFO - 2018-01-20 06:37:34 --> Controller Class Initialized
INFO - 2018-01-20 06:37:34 --> Model Class Initialized
INFO - 2018-01-20 06:37:34 --> Model Class Initialized
INFO - 2018-01-20 06:37:34 --> Model Class Initialized
INFO - 2018-01-20 06:37:34 --> Model Class Initialized
DEBUG - 2018-01-20 06:37:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-20 06:37:37 --> Config Class Initialized
INFO - 2018-01-20 06:37:37 --> Hooks Class Initialized
DEBUG - 2018-01-20 06:37:37 --> UTF-8 Support Enabled
INFO - 2018-01-20 06:37:37 --> Utf8 Class Initialized
INFO - 2018-01-20 06:37:37 --> URI Class Initialized
INFO - 2018-01-20 06:37:37 --> Router Class Initialized
INFO - 2018-01-20 06:37:37 --> Output Class Initialized
INFO - 2018-01-20 06:37:37 --> Security Class Initialized
DEBUG - 2018-01-20 06:37:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-20 06:37:37 --> Input Class Initialized
INFO - 2018-01-20 06:37:37 --> Language Class Initialized
INFO - 2018-01-20 06:37:37 --> Loader Class Initialized
INFO - 2018-01-20 06:37:37 --> Helper loaded: url_helper
INFO - 2018-01-20 06:37:37 --> Helper loaded: form_helper
INFO - 2018-01-20 06:37:37 --> Database Driver Class Initialized
DEBUG - 2018-01-20 06:37:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-20 06:37:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-20 06:37:37 --> Form Validation Class Initialized
INFO - 2018-01-20 06:37:37 --> Model Class Initialized
INFO - 2018-01-20 06:37:37 --> Controller Class Initialized
INFO - 2018-01-20 06:37:37 --> Model Class Initialized
INFO - 2018-01-20 06:37:37 --> Model Class Initialized
INFO - 2018-01-20 06:37:37 --> Model Class Initialized
INFO - 2018-01-20 06:37:37 --> Model Class Initialized
DEBUG - 2018-01-20 06:37:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-20 06:37:37 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-20 06:37:37 --> Final output sent to browser
DEBUG - 2018-01-20 06:37:37 --> Total execution time: 0.0571
INFO - 2018-01-20 06:37:38 --> Config Class Initialized
INFO - 2018-01-20 06:37:38 --> Hooks Class Initialized
DEBUG - 2018-01-20 06:37:38 --> UTF-8 Support Enabled
INFO - 2018-01-20 06:37:38 --> Utf8 Class Initialized
INFO - 2018-01-20 06:37:38 --> URI Class Initialized
INFO - 2018-01-20 06:37:38 --> Router Class Initialized
INFO - 2018-01-20 06:37:38 --> Output Class Initialized
INFO - 2018-01-20 06:37:38 --> Security Class Initialized
DEBUG - 2018-01-20 06:37:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-20 06:37:38 --> Input Class Initialized
INFO - 2018-01-20 06:37:38 --> Language Class Initialized
INFO - 2018-01-20 06:37:38 --> Loader Class Initialized
INFO - 2018-01-20 06:37:38 --> Helper loaded: url_helper
INFO - 2018-01-20 06:37:38 --> Helper loaded: form_helper
INFO - 2018-01-20 06:37:38 --> Database Driver Class Initialized
DEBUG - 2018-01-20 06:37:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-20 06:37:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-20 06:37:38 --> Form Validation Class Initialized
INFO - 2018-01-20 06:37:38 --> Model Class Initialized
INFO - 2018-01-20 06:37:38 --> Controller Class Initialized
INFO - 2018-01-20 06:37:38 --> Model Class Initialized
INFO - 2018-01-20 06:37:38 --> Model Class Initialized
INFO - 2018-01-20 06:37:38 --> Model Class Initialized
INFO - 2018-01-20 06:37:38 --> Model Class Initialized
DEBUG - 2018-01-20 06:37:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-20 06:37:49 --> Config Class Initialized
INFO - 2018-01-20 06:37:49 --> Hooks Class Initialized
DEBUG - 2018-01-20 06:37:49 --> UTF-8 Support Enabled
INFO - 2018-01-20 06:37:49 --> Utf8 Class Initialized
INFO - 2018-01-20 06:37:49 --> URI Class Initialized
INFO - 2018-01-20 06:37:49 --> Config Class Initialized
INFO - 2018-01-20 06:37:49 --> Hooks Class Initialized
DEBUG - 2018-01-20 06:37:49 --> No URI present. Default controller set.
INFO - 2018-01-20 06:37:49 --> Router Class Initialized
DEBUG - 2018-01-20 06:37:49 --> UTF-8 Support Enabled
INFO - 2018-01-20 06:37:49 --> Utf8 Class Initialized
INFO - 2018-01-20 06:37:49 --> Output Class Initialized
INFO - 2018-01-20 06:37:49 --> URI Class Initialized
INFO - 2018-01-20 06:37:49 --> Security Class Initialized
INFO - 2018-01-20 06:37:49 --> Router Class Initialized
DEBUG - 2018-01-20 06:37:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-20 06:37:49 --> Input Class Initialized
INFO - 2018-01-20 06:37:49 --> Language Class Initialized
INFO - 2018-01-20 06:37:49 --> Output Class Initialized
INFO - 2018-01-20 06:37:49 --> Security Class Initialized
INFO - 2018-01-20 06:37:49 --> Loader Class Initialized
DEBUG - 2018-01-20 06:37:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-20 06:37:49 --> Helper loaded: url_helper
INFO - 2018-01-20 06:37:49 --> Input Class Initialized
INFO - 2018-01-20 06:37:49 --> Language Class Initialized
INFO - 2018-01-20 06:37:49 --> Helper loaded: form_helper
INFO - 2018-01-20 06:37:49 --> Loader Class Initialized
INFO - 2018-01-20 06:37:49 --> Helper loaded: url_helper
INFO - 2018-01-20 06:37:49 --> Helper loaded: form_helper
INFO - 2018-01-20 06:37:49 --> Database Driver Class Initialized
DEBUG - 2018-01-20 06:37:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-20 06:37:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-20 06:37:49 --> Database Driver Class Initialized
INFO - 2018-01-20 06:37:49 --> Form Validation Class Initialized
INFO - 2018-01-20 06:37:49 --> Model Class Initialized
INFO - 2018-01-20 06:37:49 --> Controller Class Initialized
INFO - 2018-01-20 06:37:49 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-20 06:37:49 --> Final output sent to browser
DEBUG - 2018-01-20 06:37:49 --> Total execution time: 0.0338
DEBUG - 2018-01-20 06:37:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-20 06:37:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-20 06:37:49 --> Form Validation Class Initialized
INFO - 2018-01-20 06:37:50 --> Model Class Initialized
INFO - 2018-01-20 06:37:50 --> Controller Class Initialized
INFO - 2018-01-20 06:37:50 --> Model Class Initialized
INFO - 2018-01-20 06:37:50 --> Model Class Initialized
INFO - 2018-01-20 06:37:50 --> Model Class Initialized
INFO - 2018-01-20 06:37:50 --> Model Class Initialized
DEBUG - 2018-01-20 06:37:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-20 06:37:50 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-20 06:37:50 --> Final output sent to browser
DEBUG - 2018-01-20 06:37:50 --> Total execution time: 0.0651
INFO - 2018-01-20 06:37:52 --> Config Class Initialized
INFO - 2018-01-20 06:37:52 --> Hooks Class Initialized
DEBUG - 2018-01-20 06:37:52 --> UTF-8 Support Enabled
INFO - 2018-01-20 06:37:52 --> Utf8 Class Initialized
INFO - 2018-01-20 06:37:52 --> URI Class Initialized
INFO - 2018-01-20 06:37:52 --> Router Class Initialized
INFO - 2018-01-20 06:37:52 --> Output Class Initialized
INFO - 2018-01-20 06:37:52 --> Security Class Initialized
DEBUG - 2018-01-20 06:37:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-20 06:37:52 --> Input Class Initialized
INFO - 2018-01-20 06:37:52 --> Language Class Initialized
INFO - 2018-01-20 06:37:52 --> Loader Class Initialized
INFO - 2018-01-20 06:37:52 --> Helper loaded: url_helper
INFO - 2018-01-20 06:37:52 --> Helper loaded: form_helper
INFO - 2018-01-20 06:37:52 --> Database Driver Class Initialized
DEBUG - 2018-01-20 06:37:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-20 06:37:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-20 06:37:52 --> Form Validation Class Initialized
INFO - 2018-01-20 06:37:52 --> Model Class Initialized
INFO - 2018-01-20 06:37:52 --> Controller Class Initialized
INFO - 2018-01-20 06:37:52 --> Model Class Initialized
DEBUG - 2018-01-20 06:37:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-20 06:37:52 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-20 06:37:52 --> Final output sent to browser
DEBUG - 2018-01-20 06:37:52 --> Total execution time: 0.0353
INFO - 2018-01-20 06:53:54 --> Config Class Initialized
INFO - 2018-01-20 06:53:54 --> Hooks Class Initialized
DEBUG - 2018-01-20 06:53:54 --> UTF-8 Support Enabled
INFO - 2018-01-20 06:53:54 --> Utf8 Class Initialized
INFO - 2018-01-20 06:53:54 --> URI Class Initialized
INFO - 2018-01-20 06:53:54 --> Router Class Initialized
INFO - 2018-01-20 06:53:54 --> Output Class Initialized
INFO - 2018-01-20 06:53:54 --> Security Class Initialized
DEBUG - 2018-01-20 06:53:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-20 06:53:54 --> Input Class Initialized
INFO - 2018-01-20 06:53:54 --> Language Class Initialized
INFO - 2018-01-20 06:53:54 --> Loader Class Initialized
INFO - 2018-01-20 06:53:54 --> Helper loaded: url_helper
INFO - 2018-01-20 06:53:54 --> Helper loaded: form_helper
INFO - 2018-01-20 06:53:54 --> Database Driver Class Initialized
DEBUG - 2018-01-20 06:53:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-20 06:53:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-20 06:53:54 --> Form Validation Class Initialized
INFO - 2018-01-20 06:53:54 --> Model Class Initialized
INFO - 2018-01-20 06:53:54 --> Controller Class Initialized
INFO - 2018-01-20 06:53:54 --> Model Class Initialized
INFO - 2018-01-20 06:53:54 --> Model Class Initialized
INFO - 2018-01-20 06:53:54 --> Model Class Initialized
INFO - 2018-01-20 06:53:54 --> Model Class Initialized
DEBUG - 2018-01-20 06:53:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-20 06:53:55 --> Config Class Initialized
INFO - 2018-01-20 06:53:55 --> Hooks Class Initialized
DEBUG - 2018-01-20 06:53:55 --> UTF-8 Support Enabled
INFO - 2018-01-20 06:53:55 --> Utf8 Class Initialized
INFO - 2018-01-20 06:53:55 --> URI Class Initialized
INFO - 2018-01-20 06:53:55 --> Router Class Initialized
INFO - 2018-01-20 06:53:55 --> Output Class Initialized
INFO - 2018-01-20 06:53:55 --> Security Class Initialized
DEBUG - 2018-01-20 06:53:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-20 06:53:55 --> Input Class Initialized
INFO - 2018-01-20 06:53:55 --> Language Class Initialized
INFO - 2018-01-20 06:53:55 --> Loader Class Initialized
INFO - 2018-01-20 06:53:55 --> Helper loaded: url_helper
INFO - 2018-01-20 06:53:55 --> Helper loaded: form_helper
INFO - 2018-01-20 06:53:55 --> Database Driver Class Initialized
DEBUG - 2018-01-20 06:53:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-20 06:53:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-20 06:53:55 --> Form Validation Class Initialized
INFO - 2018-01-20 06:53:55 --> Model Class Initialized
INFO - 2018-01-20 06:53:55 --> Controller Class Initialized
INFO - 2018-01-20 06:53:55 --> Model Class Initialized
DEBUG - 2018-01-20 06:53:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-20 06:53:55 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-20 06:53:55 --> Final output sent to browser
DEBUG - 2018-01-20 06:53:55 --> Total execution time: 0.0352
INFO - 2018-01-20 06:55:05 --> Config Class Initialized
INFO - 2018-01-20 06:55:05 --> Hooks Class Initialized
DEBUG - 2018-01-20 06:55:05 --> UTF-8 Support Enabled
INFO - 2018-01-20 06:55:05 --> Utf8 Class Initialized
INFO - 2018-01-20 06:55:05 --> URI Class Initialized
DEBUG - 2018-01-20 06:55:05 --> No URI present. Default controller set.
INFO - 2018-01-20 06:55:05 --> Router Class Initialized
INFO - 2018-01-20 06:55:05 --> Output Class Initialized
INFO - 2018-01-20 06:55:05 --> Security Class Initialized
DEBUG - 2018-01-20 06:55:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-20 06:55:05 --> Input Class Initialized
INFO - 2018-01-20 06:55:05 --> Language Class Initialized
INFO - 2018-01-20 06:55:05 --> Loader Class Initialized
INFO - 2018-01-20 06:55:05 --> Helper loaded: url_helper
INFO - 2018-01-20 06:55:05 --> Helper loaded: form_helper
INFO - 2018-01-20 06:55:05 --> Database Driver Class Initialized
DEBUG - 2018-01-20 06:55:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-20 06:55:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-20 06:55:05 --> Form Validation Class Initialized
INFO - 2018-01-20 06:55:05 --> Model Class Initialized
INFO - 2018-01-20 06:55:05 --> Controller Class Initialized
INFO - 2018-01-20 06:55:06 --> Config Class Initialized
INFO - 2018-01-20 06:55:06 --> Hooks Class Initialized
DEBUG - 2018-01-20 06:55:06 --> UTF-8 Support Enabled
INFO - 2018-01-20 06:55:06 --> Utf8 Class Initialized
INFO - 2018-01-20 06:55:06 --> URI Class Initialized
INFO - 2018-01-20 06:55:06 --> Router Class Initialized
INFO - 2018-01-20 06:55:06 --> Output Class Initialized
INFO - 2018-01-20 06:55:06 --> Security Class Initialized
DEBUG - 2018-01-20 06:55:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-20 06:55:06 --> Input Class Initialized
INFO - 2018-01-20 06:55:06 --> Language Class Initialized
INFO - 2018-01-20 06:55:06 --> Loader Class Initialized
INFO - 2018-01-20 06:55:06 --> Helper loaded: url_helper
INFO - 2018-01-20 06:55:06 --> Helper loaded: form_helper
INFO - 2018-01-20 06:55:06 --> Database Driver Class Initialized
DEBUG - 2018-01-20 06:55:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-20 06:55:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-20 06:55:06 --> Form Validation Class Initialized
INFO - 2018-01-20 06:55:06 --> Model Class Initialized
INFO - 2018-01-20 06:55:06 --> Controller Class Initialized
INFO - 2018-01-20 06:55:06 --> Model Class Initialized
DEBUG - 2018-01-20 06:55:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-20 06:55:06 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-20 06:55:06 --> Final output sent to browser
DEBUG - 2018-01-20 06:55:06 --> Total execution time: 0.0361
INFO - 2018-01-20 06:55:34 --> Config Class Initialized
INFO - 2018-01-20 06:55:34 --> Hooks Class Initialized
DEBUG - 2018-01-20 06:55:34 --> UTF-8 Support Enabled
INFO - 2018-01-20 06:55:34 --> Utf8 Class Initialized
INFO - 2018-01-20 06:55:34 --> URI Class Initialized
INFO - 2018-01-20 06:55:34 --> Router Class Initialized
INFO - 2018-01-20 06:55:34 --> Output Class Initialized
INFO - 2018-01-20 06:55:34 --> Security Class Initialized
DEBUG - 2018-01-20 06:55:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-20 06:55:34 --> Input Class Initialized
INFO - 2018-01-20 06:55:34 --> Language Class Initialized
INFO - 2018-01-20 06:55:34 --> Loader Class Initialized
INFO - 2018-01-20 06:55:34 --> Helper loaded: url_helper
INFO - 2018-01-20 06:55:34 --> Helper loaded: form_helper
INFO - 2018-01-20 06:55:34 --> Database Driver Class Initialized
DEBUG - 2018-01-20 06:55:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-20 06:55:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-20 06:55:34 --> Form Validation Class Initialized
INFO - 2018-01-20 06:55:34 --> Model Class Initialized
INFO - 2018-01-20 06:55:34 --> Controller Class Initialized
INFO - 2018-01-20 06:55:34 --> Model Class Initialized
DEBUG - 2018-01-20 06:55:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-20 06:55:34 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-01-20 06:55:36 --> Config Class Initialized
INFO - 2018-01-20 06:55:36 --> Hooks Class Initialized
DEBUG - 2018-01-20 06:55:36 --> UTF-8 Support Enabled
INFO - 2018-01-20 06:55:36 --> Utf8 Class Initialized
INFO - 2018-01-20 06:55:36 --> URI Class Initialized
DEBUG - 2018-01-20 06:55:36 --> No URI present. Default controller set.
INFO - 2018-01-20 06:55:36 --> Router Class Initialized
INFO - 2018-01-20 06:55:36 --> Output Class Initialized
INFO - 2018-01-20 06:55:36 --> Security Class Initialized
DEBUG - 2018-01-20 06:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-20 06:55:36 --> Input Class Initialized
INFO - 2018-01-20 06:55:36 --> Language Class Initialized
INFO - 2018-01-20 06:55:36 --> Loader Class Initialized
INFO - 2018-01-20 06:55:36 --> Helper loaded: url_helper
INFO - 2018-01-20 06:55:36 --> Helper loaded: form_helper
INFO - 2018-01-20 06:55:36 --> Database Driver Class Initialized
DEBUG - 2018-01-20 06:55:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-20 06:55:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-20 06:55:36 --> Form Validation Class Initialized
INFO - 2018-01-20 06:55:36 --> Model Class Initialized
INFO - 2018-01-20 06:55:36 --> Controller Class Initialized
INFO - 2018-01-20 06:55:36 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-20 06:55:36 --> Final output sent to browser
DEBUG - 2018-01-20 06:55:36 --> Total execution time: 0.0347
INFO - 2018-01-20 07:14:58 --> Config Class Initialized
INFO - 2018-01-20 07:14:58 --> Hooks Class Initialized
DEBUG - 2018-01-20 07:14:58 --> UTF-8 Support Enabled
INFO - 2018-01-20 07:14:58 --> Utf8 Class Initialized
INFO - 2018-01-20 07:14:58 --> URI Class Initialized
INFO - 2018-01-20 07:14:58 --> Router Class Initialized
INFO - 2018-01-20 07:14:58 --> Output Class Initialized
INFO - 2018-01-20 07:14:58 --> Security Class Initialized
DEBUG - 2018-01-20 07:14:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-20 07:14:58 --> Input Class Initialized
INFO - 2018-01-20 07:14:58 --> Language Class Initialized
INFO - 2018-01-20 07:14:58 --> Loader Class Initialized
INFO - 2018-01-20 07:14:58 --> Helper loaded: url_helper
INFO - 2018-01-20 07:14:58 --> Helper loaded: form_helper
INFO - 2018-01-20 07:14:58 --> Database Driver Class Initialized
DEBUG - 2018-01-20 07:14:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-20 07:14:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-20 07:14:58 --> Form Validation Class Initialized
INFO - 2018-01-20 07:14:58 --> Model Class Initialized
INFO - 2018-01-20 07:14:58 --> Controller Class Initialized
INFO - 2018-01-20 07:14:59 --> Model Class Initialized
INFO - 2018-01-20 07:14:59 --> Model Class Initialized
INFO - 2018-01-20 07:14:59 --> Model Class Initialized
INFO - 2018-01-20 07:14:59 --> Model Class Initialized
DEBUG - 2018-01-20 07:14:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-20 07:14:59 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-20 07:14:59 --> Final output sent to browser
DEBUG - 2018-01-20 07:14:59 --> Total execution time: 0.0957
INFO - 2018-01-20 07:15:00 --> Config Class Initialized
INFO - 2018-01-20 07:15:00 --> Hooks Class Initialized
DEBUG - 2018-01-20 07:15:00 --> UTF-8 Support Enabled
INFO - 2018-01-20 07:15:00 --> Utf8 Class Initialized
INFO - 2018-01-20 07:15:00 --> URI Class Initialized
INFO - 2018-01-20 07:15:00 --> Router Class Initialized
INFO - 2018-01-20 07:15:00 --> Output Class Initialized
INFO - 2018-01-20 07:15:00 --> Security Class Initialized
DEBUG - 2018-01-20 07:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-20 07:15:00 --> Input Class Initialized
INFO - 2018-01-20 07:15:00 --> Language Class Initialized
INFO - 2018-01-20 07:15:00 --> Loader Class Initialized
INFO - 2018-01-20 07:15:00 --> Helper loaded: url_helper
INFO - 2018-01-20 07:15:00 --> Helper loaded: form_helper
INFO - 2018-01-20 07:15:00 --> Database Driver Class Initialized
DEBUG - 2018-01-20 07:15:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-20 07:15:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-20 07:15:00 --> Form Validation Class Initialized
INFO - 2018-01-20 07:15:00 --> Model Class Initialized
INFO - 2018-01-20 07:15:00 --> Controller Class Initialized
INFO - 2018-01-20 07:15:00 --> Model Class Initialized
INFO - 2018-01-20 07:15:00 --> Model Class Initialized
INFO - 2018-01-20 07:15:00 --> Model Class Initialized
INFO - 2018-01-20 07:15:00 --> Model Class Initialized
DEBUG - 2018-01-20 07:15:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-20 07:15:02 --> Config Class Initialized
INFO - 2018-01-20 07:15:02 --> Hooks Class Initialized
DEBUG - 2018-01-20 07:15:02 --> UTF-8 Support Enabled
INFO - 2018-01-20 07:15:02 --> Utf8 Class Initialized
INFO - 2018-01-20 07:15:02 --> URI Class Initialized
INFO - 2018-01-20 07:15:02 --> Router Class Initialized
INFO - 2018-01-20 07:15:02 --> Output Class Initialized
INFO - 2018-01-20 07:15:02 --> Security Class Initialized
DEBUG - 2018-01-20 07:15:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-20 07:15:02 --> Input Class Initialized
INFO - 2018-01-20 07:15:02 --> Language Class Initialized
INFO - 2018-01-20 07:15:02 --> Loader Class Initialized
INFO - 2018-01-20 07:15:02 --> Helper loaded: url_helper
INFO - 2018-01-20 07:15:02 --> Helper loaded: form_helper
INFO - 2018-01-20 07:15:02 --> Database Driver Class Initialized
DEBUG - 2018-01-20 07:15:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-20 07:15:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-20 07:15:02 --> Form Validation Class Initialized
INFO - 2018-01-20 07:15:02 --> Model Class Initialized
INFO - 2018-01-20 07:15:02 --> Controller Class Initialized
INFO - 2018-01-20 07:15:02 --> Model Class Initialized
INFO - 2018-01-20 07:15:02 --> Model Class Initialized
INFO - 2018-01-20 07:15:02 --> Model Class Initialized
INFO - 2018-01-20 07:15:02 --> Model Class Initialized
DEBUG - 2018-01-20 07:15:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-20 07:15:04 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-20 07:15:04 --> Final output sent to browser
DEBUG - 2018-01-20 07:15:04 --> Total execution time: 1.9201
INFO - 2018-01-20 07:15:05 --> Config Class Initialized
INFO - 2018-01-20 07:15:05 --> Hooks Class Initialized
DEBUG - 2018-01-20 07:15:05 --> UTF-8 Support Enabled
INFO - 2018-01-20 07:15:05 --> Utf8 Class Initialized
INFO - 2018-01-20 07:15:05 --> URI Class Initialized
INFO - 2018-01-20 07:15:05 --> Router Class Initialized
INFO - 2018-01-20 07:15:05 --> Output Class Initialized
INFO - 2018-01-20 07:15:05 --> Security Class Initialized
DEBUG - 2018-01-20 07:15:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-20 07:15:05 --> Input Class Initialized
INFO - 2018-01-20 07:15:05 --> Language Class Initialized
INFO - 2018-01-20 07:15:05 --> Loader Class Initialized
INFO - 2018-01-20 07:15:05 --> Helper loaded: url_helper
INFO - 2018-01-20 07:15:05 --> Helper loaded: form_helper
INFO - 2018-01-20 07:15:05 --> Database Driver Class Initialized
DEBUG - 2018-01-20 07:15:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-20 07:15:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-20 07:15:05 --> Form Validation Class Initialized
INFO - 2018-01-20 07:15:05 --> Model Class Initialized
INFO - 2018-01-20 07:15:05 --> Controller Class Initialized
INFO - 2018-01-20 07:15:05 --> Model Class Initialized
INFO - 2018-01-20 07:15:05 --> Model Class Initialized
INFO - 2018-01-20 07:15:05 --> Model Class Initialized
INFO - 2018-01-20 07:15:05 --> Model Class Initialized
DEBUG - 2018-01-20 07:15:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-20 07:15:07 --> Config Class Initialized
INFO - 2018-01-20 07:15:07 --> Hooks Class Initialized
DEBUG - 2018-01-20 07:15:07 --> UTF-8 Support Enabled
INFO - 2018-01-20 07:15:07 --> Utf8 Class Initialized
INFO - 2018-01-20 07:15:07 --> URI Class Initialized
INFO - 2018-01-20 07:15:07 --> Router Class Initialized
INFO - 2018-01-20 07:15:07 --> Output Class Initialized
INFO - 2018-01-20 07:15:07 --> Security Class Initialized
DEBUG - 2018-01-20 07:15:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-20 07:15:07 --> Input Class Initialized
INFO - 2018-01-20 07:15:07 --> Language Class Initialized
INFO - 2018-01-20 07:15:07 --> Loader Class Initialized
INFO - 2018-01-20 07:15:07 --> Helper loaded: url_helper
INFO - 2018-01-20 07:15:07 --> Helper loaded: form_helper
INFO - 2018-01-20 07:15:07 --> Database Driver Class Initialized
DEBUG - 2018-01-20 07:15:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-20 07:15:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-20 07:15:07 --> Form Validation Class Initialized
INFO - 2018-01-20 07:15:07 --> Model Class Initialized
INFO - 2018-01-20 07:15:07 --> Controller Class Initialized
INFO - 2018-01-20 07:15:07 --> Model Class Initialized
INFO - 2018-01-20 07:15:07 --> Model Class Initialized
INFO - 2018-01-20 07:15:07 --> Model Class Initialized
INFO - 2018-01-20 07:15:07 --> Model Class Initialized
DEBUG - 2018-01-20 07:15:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-20 07:15:07 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-20 07:15:07 --> Final output sent to browser
DEBUG - 2018-01-20 07:15:07 --> Total execution time: 0.0794
INFO - 2018-01-20 07:15:08 --> Config Class Initialized
INFO - 2018-01-20 07:15:08 --> Hooks Class Initialized
DEBUG - 2018-01-20 07:15:08 --> UTF-8 Support Enabled
INFO - 2018-01-20 07:15:08 --> Utf8 Class Initialized
INFO - 2018-01-20 07:15:08 --> URI Class Initialized
INFO - 2018-01-20 07:15:08 --> Router Class Initialized
INFO - 2018-01-20 07:15:08 --> Output Class Initialized
INFO - 2018-01-20 07:15:08 --> Security Class Initialized
DEBUG - 2018-01-20 07:15:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-20 07:15:08 --> Input Class Initialized
INFO - 2018-01-20 07:15:08 --> Language Class Initialized
INFO - 2018-01-20 07:15:08 --> Loader Class Initialized
INFO - 2018-01-20 07:15:08 --> Helper loaded: url_helper
INFO - 2018-01-20 07:15:08 --> Helper loaded: form_helper
INFO - 2018-01-20 07:15:08 --> Database Driver Class Initialized
DEBUG - 2018-01-20 07:15:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-20 07:15:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-20 07:15:08 --> Form Validation Class Initialized
INFO - 2018-01-20 07:15:08 --> Model Class Initialized
INFO - 2018-01-20 07:15:08 --> Controller Class Initialized
INFO - 2018-01-20 07:15:08 --> Model Class Initialized
INFO - 2018-01-20 07:15:08 --> Model Class Initialized
INFO - 2018-01-20 07:15:08 --> Model Class Initialized
INFO - 2018-01-20 07:15:08 --> Model Class Initialized
DEBUG - 2018-01-20 07:15:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-20 07:15:23 --> Config Class Initialized
INFO - 2018-01-20 07:15:23 --> Hooks Class Initialized
DEBUG - 2018-01-20 07:15:23 --> UTF-8 Support Enabled
INFO - 2018-01-20 07:15:23 --> Utf8 Class Initialized
INFO - 2018-01-20 07:15:23 --> URI Class Initialized
INFO - 2018-01-20 07:15:23 --> Router Class Initialized
INFO - 2018-01-20 07:15:23 --> Output Class Initialized
INFO - 2018-01-20 07:15:23 --> Security Class Initialized
DEBUG - 2018-01-20 07:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-20 07:15:23 --> Input Class Initialized
INFO - 2018-01-20 07:15:23 --> Language Class Initialized
INFO - 2018-01-20 07:15:23 --> Loader Class Initialized
INFO - 2018-01-20 07:15:23 --> Helper loaded: url_helper
INFO - 2018-01-20 07:15:23 --> Helper loaded: form_helper
INFO - 2018-01-20 07:15:23 --> Database Driver Class Initialized
DEBUG - 2018-01-20 07:15:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-20 07:15:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-20 07:15:23 --> Form Validation Class Initialized
INFO - 2018-01-20 07:15:23 --> Model Class Initialized
INFO - 2018-01-20 07:15:23 --> Controller Class Initialized
INFO - 2018-01-20 07:15:23 --> Model Class Initialized
INFO - 2018-01-20 07:15:23 --> Model Class Initialized
INFO - 2018-01-20 07:15:23 --> Model Class Initialized
INFO - 2018-01-20 07:15:23 --> Model Class Initialized
DEBUG - 2018-01-20 07:15:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-20 07:15:23 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-20 07:15:23 --> Final output sent to browser
DEBUG - 2018-01-20 07:15:23 --> Total execution time: 0.0642
INFO - 2018-01-20 07:15:30 --> Config Class Initialized
INFO - 2018-01-20 07:15:30 --> Hooks Class Initialized
DEBUG - 2018-01-20 07:15:30 --> UTF-8 Support Enabled
INFO - 2018-01-20 07:15:30 --> Utf8 Class Initialized
INFO - 2018-01-20 07:15:30 --> URI Class Initialized
INFO - 2018-01-20 07:15:30 --> Router Class Initialized
INFO - 2018-01-20 07:15:30 --> Output Class Initialized
INFO - 2018-01-20 07:15:30 --> Security Class Initialized
DEBUG - 2018-01-20 07:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-20 07:15:30 --> Input Class Initialized
INFO - 2018-01-20 07:15:30 --> Language Class Initialized
INFO - 2018-01-20 07:15:30 --> Loader Class Initialized
INFO - 2018-01-20 07:15:30 --> Helper loaded: url_helper
INFO - 2018-01-20 07:15:30 --> Helper loaded: form_helper
INFO - 2018-01-20 07:15:30 --> Database Driver Class Initialized
DEBUG - 2018-01-20 07:15:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-20 07:15:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-20 07:15:30 --> Form Validation Class Initialized
INFO - 2018-01-20 07:15:30 --> Model Class Initialized
INFO - 2018-01-20 07:15:30 --> Controller Class Initialized
INFO - 2018-01-20 07:15:30 --> Model Class Initialized
INFO - 2018-01-20 07:15:30 --> Model Class Initialized
INFO - 2018-01-20 07:15:30 --> Model Class Initialized
INFO - 2018-01-20 07:15:30 --> Model Class Initialized
DEBUG - 2018-01-20 07:15:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-20 07:15:31 --> Config Class Initialized
INFO - 2018-01-20 07:15:31 --> Hooks Class Initialized
DEBUG - 2018-01-20 07:15:31 --> UTF-8 Support Enabled
INFO - 2018-01-20 07:15:31 --> Utf8 Class Initialized
INFO - 2018-01-20 07:15:31 --> URI Class Initialized
INFO - 2018-01-20 07:15:31 --> Router Class Initialized
INFO - 2018-01-20 07:15:31 --> Output Class Initialized
INFO - 2018-01-20 07:15:31 --> Security Class Initialized
DEBUG - 2018-01-20 07:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-20 07:15:31 --> Input Class Initialized
INFO - 2018-01-20 07:15:31 --> Language Class Initialized
INFO - 2018-01-20 07:15:31 --> Loader Class Initialized
INFO - 2018-01-20 07:15:31 --> Helper loaded: url_helper
INFO - 2018-01-20 07:15:31 --> Helper loaded: form_helper
INFO - 2018-01-20 07:15:31 --> Database Driver Class Initialized
DEBUG - 2018-01-20 07:15:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-20 07:15:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-20 07:15:31 --> Form Validation Class Initialized
INFO - 2018-01-20 07:15:31 --> Model Class Initialized
INFO - 2018-01-20 07:15:31 --> Controller Class Initialized
INFO - 2018-01-20 07:15:31 --> Model Class Initialized
INFO - 2018-01-20 07:15:31 --> Model Class Initialized
INFO - 2018-01-20 07:15:31 --> Model Class Initialized
INFO - 2018-01-20 07:15:31 --> Model Class Initialized
DEBUG - 2018-01-20 07:15:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-20 07:15:31 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-20 07:15:31 --> Final output sent to browser
DEBUG - 2018-01-20 07:15:31 --> Total execution time: 0.0519
INFO - 2018-01-20 07:15:31 --> Config Class Initialized
INFO - 2018-01-20 07:15:31 --> Hooks Class Initialized
DEBUG - 2018-01-20 07:15:31 --> UTF-8 Support Enabled
INFO - 2018-01-20 07:15:31 --> Utf8 Class Initialized
INFO - 2018-01-20 07:15:31 --> URI Class Initialized
INFO - 2018-01-20 07:15:31 --> Router Class Initialized
INFO - 2018-01-20 07:15:31 --> Output Class Initialized
INFO - 2018-01-20 07:15:31 --> Security Class Initialized
DEBUG - 2018-01-20 07:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-20 07:15:31 --> Input Class Initialized
INFO - 2018-01-20 07:15:31 --> Language Class Initialized
INFO - 2018-01-20 07:15:31 --> Loader Class Initialized
INFO - 2018-01-20 07:15:31 --> Helper loaded: url_helper
INFO - 2018-01-20 07:15:31 --> Helper loaded: form_helper
INFO - 2018-01-20 07:15:31 --> Database Driver Class Initialized
DEBUG - 2018-01-20 07:15:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-20 07:15:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-20 07:15:31 --> Form Validation Class Initialized
INFO - 2018-01-20 07:15:31 --> Model Class Initialized
INFO - 2018-01-20 07:15:31 --> Controller Class Initialized
INFO - 2018-01-20 07:15:31 --> Model Class Initialized
INFO - 2018-01-20 07:15:31 --> Model Class Initialized
INFO - 2018-01-20 07:15:31 --> Model Class Initialized
INFO - 2018-01-20 07:15:31 --> Model Class Initialized
DEBUG - 2018-01-20 07:15:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-20 07:15:48 --> Config Class Initialized
INFO - 2018-01-20 07:15:48 --> Hooks Class Initialized
DEBUG - 2018-01-20 07:15:48 --> UTF-8 Support Enabled
INFO - 2018-01-20 07:15:48 --> Utf8 Class Initialized
INFO - 2018-01-20 07:15:48 --> URI Class Initialized
INFO - 2018-01-20 07:15:48 --> Router Class Initialized
INFO - 2018-01-20 07:15:48 --> Output Class Initialized
INFO - 2018-01-20 07:15:48 --> Security Class Initialized
DEBUG - 2018-01-20 07:15:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-20 07:15:48 --> Input Class Initialized
INFO - 2018-01-20 07:15:48 --> Language Class Initialized
INFO - 2018-01-20 07:15:48 --> Loader Class Initialized
INFO - 2018-01-20 07:15:48 --> Helper loaded: url_helper
INFO - 2018-01-20 07:15:48 --> Helper loaded: form_helper
INFO - 2018-01-20 07:15:48 --> Database Driver Class Initialized
DEBUG - 2018-01-20 07:15:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-20 07:15:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-20 07:15:48 --> Form Validation Class Initialized
INFO - 2018-01-20 07:15:48 --> Model Class Initialized
INFO - 2018-01-20 07:15:48 --> Controller Class Initialized
INFO - 2018-01-20 07:15:48 --> Model Class Initialized
INFO - 2018-01-20 07:15:48 --> Model Class Initialized
INFO - 2018-01-20 07:15:48 --> Model Class Initialized
INFO - 2018-01-20 07:15:48 --> Model Class Initialized
DEBUG - 2018-01-20 07:15:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-20 07:15:48 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-20 07:15:48 --> Final output sent to browser
DEBUG - 2018-01-20 07:15:48 --> Total execution time: 0.0513
INFO - 2018-01-20 07:16:00 --> Config Class Initialized
INFO - 2018-01-20 07:16:00 --> Hooks Class Initialized
DEBUG - 2018-01-20 07:16:00 --> UTF-8 Support Enabled
INFO - 2018-01-20 07:16:00 --> Utf8 Class Initialized
INFO - 2018-01-20 07:16:00 --> URI Class Initialized
INFO - 2018-01-20 07:16:00 --> Router Class Initialized
INFO - 2018-01-20 07:16:00 --> Output Class Initialized
INFO - 2018-01-20 07:16:00 --> Security Class Initialized
DEBUG - 2018-01-20 07:16:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-20 07:16:00 --> Input Class Initialized
INFO - 2018-01-20 07:16:00 --> Language Class Initialized
INFO - 2018-01-20 07:16:00 --> Loader Class Initialized
INFO - 2018-01-20 07:16:00 --> Helper loaded: url_helper
INFO - 2018-01-20 07:16:00 --> Helper loaded: form_helper
INFO - 2018-01-20 07:16:00 --> Database Driver Class Initialized
DEBUG - 2018-01-20 07:16:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-20 07:16:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-20 07:16:00 --> Form Validation Class Initialized
INFO - 2018-01-20 07:16:00 --> Model Class Initialized
INFO - 2018-01-20 07:16:00 --> Controller Class Initialized
INFO - 2018-01-20 07:16:00 --> Model Class Initialized
INFO - 2018-01-20 07:16:00 --> Model Class Initialized
INFO - 2018-01-20 07:16:00 --> Model Class Initialized
INFO - 2018-01-20 07:16:00 --> Model Class Initialized
DEBUG - 2018-01-20 07:16:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-20 07:16:01 --> Config Class Initialized
INFO - 2018-01-20 07:16:01 --> Hooks Class Initialized
DEBUG - 2018-01-20 07:16:01 --> UTF-8 Support Enabled
INFO - 2018-01-20 07:16:01 --> Utf8 Class Initialized
INFO - 2018-01-20 07:16:01 --> URI Class Initialized
INFO - 2018-01-20 07:16:01 --> Router Class Initialized
INFO - 2018-01-20 07:16:01 --> Output Class Initialized
INFO - 2018-01-20 07:16:01 --> Security Class Initialized
DEBUG - 2018-01-20 07:16:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-20 07:16:01 --> Input Class Initialized
INFO - 2018-01-20 07:16:01 --> Language Class Initialized
INFO - 2018-01-20 07:16:01 --> Loader Class Initialized
INFO - 2018-01-20 07:16:01 --> Helper loaded: url_helper
INFO - 2018-01-20 07:16:01 --> Helper loaded: form_helper
INFO - 2018-01-20 07:16:01 --> Database Driver Class Initialized
DEBUG - 2018-01-20 07:16:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-20 07:16:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-20 07:16:01 --> Form Validation Class Initialized
INFO - 2018-01-20 07:16:01 --> Model Class Initialized
INFO - 2018-01-20 07:16:01 --> Controller Class Initialized
INFO - 2018-01-20 07:16:01 --> Model Class Initialized
INFO - 2018-01-20 07:16:01 --> Model Class Initialized
INFO - 2018-01-20 07:16:01 --> Model Class Initialized
INFO - 2018-01-20 07:16:01 --> Model Class Initialized
DEBUG - 2018-01-20 07:16:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-20 07:16:01 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-20 07:16:01 --> Final output sent to browser
DEBUG - 2018-01-20 07:16:01 --> Total execution time: 0.0563
INFO - 2018-01-20 07:16:01 --> Config Class Initialized
INFO - 2018-01-20 07:16:01 --> Hooks Class Initialized
DEBUG - 2018-01-20 07:16:01 --> UTF-8 Support Enabled
INFO - 2018-01-20 07:16:01 --> Utf8 Class Initialized
INFO - 2018-01-20 07:16:01 --> URI Class Initialized
INFO - 2018-01-20 07:16:01 --> Router Class Initialized
INFO - 2018-01-20 07:16:01 --> Output Class Initialized
INFO - 2018-01-20 07:16:01 --> Security Class Initialized
DEBUG - 2018-01-20 07:16:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-20 07:16:01 --> Input Class Initialized
INFO - 2018-01-20 07:16:01 --> Language Class Initialized
INFO - 2018-01-20 07:16:01 --> Loader Class Initialized
INFO - 2018-01-20 07:16:01 --> Helper loaded: url_helper
INFO - 2018-01-20 07:16:01 --> Helper loaded: form_helper
INFO - 2018-01-20 07:16:01 --> Database Driver Class Initialized
DEBUG - 2018-01-20 07:16:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-20 07:16:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-20 07:16:01 --> Form Validation Class Initialized
INFO - 2018-01-20 07:16:01 --> Model Class Initialized
INFO - 2018-01-20 07:16:01 --> Controller Class Initialized
INFO - 2018-01-20 07:16:01 --> Model Class Initialized
INFO - 2018-01-20 07:16:01 --> Model Class Initialized
INFO - 2018-01-20 07:16:01 --> Model Class Initialized
INFO - 2018-01-20 07:16:01 --> Model Class Initialized
DEBUG - 2018-01-20 07:16:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-20 07:16:28 --> Config Class Initialized
INFO - 2018-01-20 07:16:28 --> Hooks Class Initialized
DEBUG - 2018-01-20 07:16:28 --> UTF-8 Support Enabled
INFO - 2018-01-20 07:16:28 --> Utf8 Class Initialized
INFO - 2018-01-20 07:16:28 --> URI Class Initialized
INFO - 2018-01-20 07:16:28 --> Router Class Initialized
INFO - 2018-01-20 07:16:28 --> Output Class Initialized
INFO - 2018-01-20 07:16:28 --> Security Class Initialized
DEBUG - 2018-01-20 07:16:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-20 07:16:28 --> Input Class Initialized
INFO - 2018-01-20 07:16:28 --> Language Class Initialized
INFO - 2018-01-20 07:16:28 --> Loader Class Initialized
INFO - 2018-01-20 07:16:28 --> Helper loaded: url_helper
INFO - 2018-01-20 07:16:28 --> Helper loaded: form_helper
INFO - 2018-01-20 07:16:28 --> Database Driver Class Initialized
DEBUG - 2018-01-20 07:16:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-20 07:16:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-20 07:16:28 --> Form Validation Class Initialized
INFO - 2018-01-20 07:16:28 --> Model Class Initialized
INFO - 2018-01-20 07:16:28 --> Controller Class Initialized
INFO - 2018-01-20 07:16:28 --> Model Class Initialized
INFO - 2018-01-20 07:16:28 --> Model Class Initialized
INFO - 2018-01-20 07:16:28 --> Model Class Initialized
INFO - 2018-01-20 07:16:28 --> Model Class Initialized
DEBUG - 2018-01-20 07:16:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-20 07:16:28 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-20 07:16:28 --> Final output sent to browser
DEBUG - 2018-01-20 07:16:28 --> Total execution time: 0.0556
INFO - 2018-01-20 07:16:47 --> Config Class Initialized
INFO - 2018-01-20 07:16:47 --> Hooks Class Initialized
DEBUG - 2018-01-20 07:16:47 --> UTF-8 Support Enabled
INFO - 2018-01-20 07:16:47 --> Utf8 Class Initialized
INFO - 2018-01-20 07:16:47 --> URI Class Initialized
INFO - 2018-01-20 07:16:47 --> Router Class Initialized
INFO - 2018-01-20 07:16:47 --> Output Class Initialized
INFO - 2018-01-20 07:16:47 --> Security Class Initialized
DEBUG - 2018-01-20 07:16:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-20 07:16:47 --> Input Class Initialized
INFO - 2018-01-20 07:16:47 --> Language Class Initialized
INFO - 2018-01-20 07:16:47 --> Loader Class Initialized
INFO - 2018-01-20 07:16:47 --> Helper loaded: url_helper
INFO - 2018-01-20 07:16:47 --> Helper loaded: form_helper
INFO - 2018-01-20 07:16:47 --> Database Driver Class Initialized
DEBUG - 2018-01-20 07:16:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-20 07:16:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-20 07:16:47 --> Form Validation Class Initialized
INFO - 2018-01-20 07:16:47 --> Model Class Initialized
INFO - 2018-01-20 07:16:47 --> Controller Class Initialized
INFO - 2018-01-20 07:16:47 --> Model Class Initialized
INFO - 2018-01-20 07:16:47 --> Model Class Initialized
INFO - 2018-01-20 07:16:47 --> Model Class Initialized
INFO - 2018-01-20 07:16:47 --> Model Class Initialized
DEBUG - 2018-01-20 07:16:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-20 07:16:47 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-20 07:16:47 --> Final output sent to browser
DEBUG - 2018-01-20 07:16:47 --> Total execution time: 0.0520
INFO - 2018-01-20 07:16:47 --> Config Class Initialized
INFO - 2018-01-20 07:16:47 --> Hooks Class Initialized
DEBUG - 2018-01-20 07:16:47 --> UTF-8 Support Enabled
INFO - 2018-01-20 07:16:47 --> Utf8 Class Initialized
INFO - 2018-01-20 07:16:47 --> URI Class Initialized
INFO - 2018-01-20 07:16:47 --> Router Class Initialized
INFO - 2018-01-20 07:16:47 --> Output Class Initialized
INFO - 2018-01-20 07:16:47 --> Security Class Initialized
DEBUG - 2018-01-20 07:16:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-20 07:16:47 --> Input Class Initialized
INFO - 2018-01-20 07:16:47 --> Language Class Initialized
INFO - 2018-01-20 07:16:47 --> Loader Class Initialized
INFO - 2018-01-20 07:16:47 --> Helper loaded: url_helper
INFO - 2018-01-20 07:16:47 --> Helper loaded: form_helper
INFO - 2018-01-20 07:16:47 --> Database Driver Class Initialized
DEBUG - 2018-01-20 07:16:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-20 07:16:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-20 07:16:47 --> Form Validation Class Initialized
INFO - 2018-01-20 07:16:47 --> Model Class Initialized
INFO - 2018-01-20 07:16:47 --> Controller Class Initialized
INFO - 2018-01-20 07:16:47 --> Model Class Initialized
INFO - 2018-01-20 07:16:47 --> Model Class Initialized
INFO - 2018-01-20 07:16:47 --> Model Class Initialized
INFO - 2018-01-20 07:16:47 --> Model Class Initialized
DEBUG - 2018-01-20 07:16:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-20 07:17:01 --> Config Class Initialized
INFO - 2018-01-20 07:17:01 --> Hooks Class Initialized
DEBUG - 2018-01-20 07:17:01 --> UTF-8 Support Enabled
INFO - 2018-01-20 07:17:01 --> Utf8 Class Initialized
INFO - 2018-01-20 07:17:01 --> URI Class Initialized
INFO - 2018-01-20 07:17:01 --> Router Class Initialized
INFO - 2018-01-20 07:17:01 --> Output Class Initialized
INFO - 2018-01-20 07:17:01 --> Security Class Initialized
DEBUG - 2018-01-20 07:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-20 07:17:01 --> Input Class Initialized
INFO - 2018-01-20 07:17:01 --> Language Class Initialized
INFO - 2018-01-20 07:17:01 --> Loader Class Initialized
INFO - 2018-01-20 07:17:01 --> Helper loaded: url_helper
INFO - 2018-01-20 07:17:01 --> Helper loaded: form_helper
INFO - 2018-01-20 07:17:01 --> Database Driver Class Initialized
DEBUG - 2018-01-20 07:17:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-20 07:17:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-20 07:17:01 --> Form Validation Class Initialized
INFO - 2018-01-20 07:17:01 --> Model Class Initialized
INFO - 2018-01-20 07:17:01 --> Controller Class Initialized
INFO - 2018-01-20 07:17:01 --> Model Class Initialized
INFO - 2018-01-20 07:17:01 --> Model Class Initialized
INFO - 2018-01-20 07:17:01 --> Model Class Initialized
INFO - 2018-01-20 07:17:01 --> Model Class Initialized
DEBUG - 2018-01-20 07:17:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-20 07:17:01 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-20 07:17:01 --> Final output sent to browser
DEBUG - 2018-01-20 07:17:01 --> Total execution time: 0.0573
INFO - 2018-01-20 07:17:21 --> Config Class Initialized
INFO - 2018-01-20 07:17:21 --> Hooks Class Initialized
DEBUG - 2018-01-20 07:17:21 --> UTF-8 Support Enabled
INFO - 2018-01-20 07:17:21 --> Utf8 Class Initialized
INFO - 2018-01-20 07:17:21 --> URI Class Initialized
INFO - 2018-01-20 07:17:21 --> Router Class Initialized
INFO - 2018-01-20 07:17:21 --> Output Class Initialized
INFO - 2018-01-20 07:17:21 --> Security Class Initialized
DEBUG - 2018-01-20 07:17:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-20 07:17:21 --> Input Class Initialized
INFO - 2018-01-20 07:17:21 --> Language Class Initialized
INFO - 2018-01-20 07:17:21 --> Loader Class Initialized
INFO - 2018-01-20 07:17:21 --> Helper loaded: url_helper
INFO - 2018-01-20 07:17:21 --> Helper loaded: form_helper
INFO - 2018-01-20 07:17:21 --> Database Driver Class Initialized
DEBUG - 2018-01-20 07:17:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-20 07:17:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-20 07:17:21 --> Form Validation Class Initialized
INFO - 2018-01-20 07:17:21 --> Model Class Initialized
INFO - 2018-01-20 07:17:21 --> Controller Class Initialized
INFO - 2018-01-20 07:17:21 --> Model Class Initialized
INFO - 2018-01-20 07:17:21 --> Model Class Initialized
INFO - 2018-01-20 07:17:21 --> Model Class Initialized
INFO - 2018-01-20 07:17:21 --> Model Class Initialized
DEBUG - 2018-01-20 07:17:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-20 07:17:22 --> Config Class Initialized
INFO - 2018-01-20 07:17:22 --> Hooks Class Initialized
DEBUG - 2018-01-20 07:17:22 --> UTF-8 Support Enabled
INFO - 2018-01-20 07:17:22 --> Utf8 Class Initialized
INFO - 2018-01-20 07:17:22 --> URI Class Initialized
INFO - 2018-01-20 07:17:22 --> Router Class Initialized
INFO - 2018-01-20 07:17:22 --> Output Class Initialized
INFO - 2018-01-20 07:17:22 --> Security Class Initialized
DEBUG - 2018-01-20 07:17:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-20 07:17:22 --> Input Class Initialized
INFO - 2018-01-20 07:17:22 --> Language Class Initialized
INFO - 2018-01-20 07:17:22 --> Loader Class Initialized
INFO - 2018-01-20 07:17:22 --> Helper loaded: url_helper
INFO - 2018-01-20 07:17:22 --> Helper loaded: form_helper
INFO - 2018-01-20 07:17:22 --> Database Driver Class Initialized
DEBUG - 2018-01-20 07:17:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-20 07:17:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-20 07:17:22 --> Form Validation Class Initialized
INFO - 2018-01-20 07:17:22 --> Model Class Initialized
INFO - 2018-01-20 07:17:22 --> Controller Class Initialized
INFO - 2018-01-20 07:17:22 --> Model Class Initialized
INFO - 2018-01-20 07:17:22 --> Model Class Initialized
INFO - 2018-01-20 07:17:22 --> Model Class Initialized
INFO - 2018-01-20 07:17:22 --> Model Class Initialized
DEBUG - 2018-01-20 07:17:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-20 07:17:22 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-20 07:17:22 --> Final output sent to browser
DEBUG - 2018-01-20 07:17:22 --> Total execution time: 0.0548
INFO - 2018-01-20 07:17:22 --> Config Class Initialized
INFO - 2018-01-20 07:17:22 --> Hooks Class Initialized
DEBUG - 2018-01-20 07:17:22 --> UTF-8 Support Enabled
INFO - 2018-01-20 07:17:22 --> Utf8 Class Initialized
INFO - 2018-01-20 07:17:22 --> URI Class Initialized
INFO - 2018-01-20 07:17:22 --> Router Class Initialized
INFO - 2018-01-20 07:17:22 --> Output Class Initialized
INFO - 2018-01-20 07:17:22 --> Security Class Initialized
DEBUG - 2018-01-20 07:17:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-20 07:17:22 --> Input Class Initialized
INFO - 2018-01-20 07:17:22 --> Language Class Initialized
INFO - 2018-01-20 07:17:22 --> Loader Class Initialized
INFO - 2018-01-20 07:17:23 --> Helper loaded: url_helper
INFO - 2018-01-20 07:17:23 --> Helper loaded: form_helper
INFO - 2018-01-20 07:17:23 --> Database Driver Class Initialized
DEBUG - 2018-01-20 07:17:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-20 07:17:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-20 07:17:23 --> Form Validation Class Initialized
INFO - 2018-01-20 07:17:23 --> Model Class Initialized
INFO - 2018-01-20 07:17:23 --> Controller Class Initialized
INFO - 2018-01-20 07:17:23 --> Model Class Initialized
INFO - 2018-01-20 07:17:23 --> Model Class Initialized
INFO - 2018-01-20 07:17:23 --> Model Class Initialized
INFO - 2018-01-20 07:17:23 --> Model Class Initialized
DEBUG - 2018-01-20 07:17:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-20 07:17:30 --> Config Class Initialized
INFO - 2018-01-20 07:17:30 --> Hooks Class Initialized
DEBUG - 2018-01-20 07:17:30 --> UTF-8 Support Enabled
INFO - 2018-01-20 07:17:30 --> Utf8 Class Initialized
INFO - 2018-01-20 07:17:30 --> URI Class Initialized
INFO - 2018-01-20 07:17:30 --> Router Class Initialized
INFO - 2018-01-20 07:17:30 --> Output Class Initialized
INFO - 2018-01-20 07:17:30 --> Security Class Initialized
DEBUG - 2018-01-20 07:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-20 07:17:30 --> Input Class Initialized
INFO - 2018-01-20 07:17:30 --> Language Class Initialized
INFO - 2018-01-20 07:17:30 --> Loader Class Initialized
INFO - 2018-01-20 07:17:30 --> Helper loaded: url_helper
INFO - 2018-01-20 07:17:30 --> Helper loaded: form_helper
INFO - 2018-01-20 07:17:30 --> Database Driver Class Initialized
DEBUG - 2018-01-20 07:17:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-20 07:17:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-20 07:17:30 --> Form Validation Class Initialized
INFO - 2018-01-20 07:17:30 --> Model Class Initialized
INFO - 2018-01-20 07:17:30 --> Controller Class Initialized
INFO - 2018-01-20 07:17:30 --> Model Class Initialized
INFO - 2018-01-20 07:17:30 --> Model Class Initialized
INFO - 2018-01-20 07:17:30 --> Model Class Initialized
INFO - 2018-01-20 07:17:30 --> Model Class Initialized
DEBUG - 2018-01-20 07:17:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-20 07:17:30 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-20 07:17:30 --> Final output sent to browser
DEBUG - 2018-01-20 07:17:30 --> Total execution time: 0.0525
INFO - 2018-01-20 07:17:30 --> Config Class Initialized
INFO - 2018-01-20 07:17:30 --> Hooks Class Initialized
DEBUG - 2018-01-20 07:17:30 --> UTF-8 Support Enabled
INFO - 2018-01-20 07:17:30 --> Utf8 Class Initialized
INFO - 2018-01-20 07:17:30 --> URI Class Initialized
INFO - 2018-01-20 07:17:30 --> Router Class Initialized
INFO - 2018-01-20 07:17:30 --> Output Class Initialized
INFO - 2018-01-20 07:17:30 --> Security Class Initialized
DEBUG - 2018-01-20 07:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-20 07:17:30 --> Input Class Initialized
INFO - 2018-01-20 07:17:30 --> Language Class Initialized
INFO - 2018-01-20 07:17:30 --> Loader Class Initialized
INFO - 2018-01-20 07:17:30 --> Helper loaded: url_helper
INFO - 2018-01-20 07:17:30 --> Helper loaded: form_helper
INFO - 2018-01-20 07:17:30 --> Database Driver Class Initialized
DEBUG - 2018-01-20 07:17:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-20 07:17:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-20 07:17:30 --> Form Validation Class Initialized
INFO - 2018-01-20 07:17:30 --> Model Class Initialized
INFO - 2018-01-20 07:17:30 --> Controller Class Initialized
INFO - 2018-01-20 07:17:30 --> Model Class Initialized
INFO - 2018-01-20 07:17:30 --> Model Class Initialized
INFO - 2018-01-20 07:17:30 --> Model Class Initialized
INFO - 2018-01-20 07:17:30 --> Model Class Initialized
DEBUG - 2018-01-20 07:17:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-20 07:17:32 --> Config Class Initialized
INFO - 2018-01-20 07:17:32 --> Hooks Class Initialized
DEBUG - 2018-01-20 07:17:32 --> UTF-8 Support Enabled
INFO - 2018-01-20 07:17:32 --> Utf8 Class Initialized
INFO - 2018-01-20 07:17:32 --> URI Class Initialized
INFO - 2018-01-20 07:17:32 --> Router Class Initialized
INFO - 2018-01-20 07:17:32 --> Output Class Initialized
INFO - 2018-01-20 07:17:32 --> Security Class Initialized
DEBUG - 2018-01-20 07:17:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-20 07:17:32 --> Input Class Initialized
INFO - 2018-01-20 07:17:32 --> Language Class Initialized
INFO - 2018-01-20 07:17:32 --> Loader Class Initialized
INFO - 2018-01-20 07:17:32 --> Helper loaded: url_helper
INFO - 2018-01-20 07:17:32 --> Helper loaded: form_helper
INFO - 2018-01-20 07:17:32 --> Database Driver Class Initialized
DEBUG - 2018-01-20 07:17:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-20 07:17:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-20 07:17:32 --> Form Validation Class Initialized
INFO - 2018-01-20 07:17:32 --> Model Class Initialized
INFO - 2018-01-20 07:17:32 --> Controller Class Initialized
INFO - 2018-01-20 07:17:32 --> Model Class Initialized
INFO - 2018-01-20 07:17:32 --> Model Class Initialized
INFO - 2018-01-20 07:17:32 --> Model Class Initialized
INFO - 2018-01-20 07:17:32 --> Model Class Initialized
DEBUG - 2018-01-20 07:17:32 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-01-20 07:17:35 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/instateccr/public_html/controlcostos/vendor/phpoffice/phpspreadsheet/src/PhpSpreadsheet/Calculation/Calculation.php:3030) /home/instateccr/public_html/controlcostos/instatec_sys/core/Common.php 564
ERROR - 2018-01-20 07:17:35 --> Severity: Parsing Error --> syntax error, unexpected '.', expecting '&' or variable (T_VARIABLE) /home/instateccr/public_html/controlcostos/vendor/phpoffice/phpspreadsheet/src/PhpSpreadsheet/Calculation/Calculation.php 3030
INFO - 2018-01-20 07:17:42 --> Config Class Initialized
INFO - 2018-01-20 07:17:42 --> Hooks Class Initialized
DEBUG - 2018-01-20 07:17:42 --> UTF-8 Support Enabled
INFO - 2018-01-20 07:17:42 --> Utf8 Class Initialized
INFO - 2018-01-20 07:17:42 --> URI Class Initialized
INFO - 2018-01-20 07:17:42 --> Router Class Initialized
INFO - 2018-01-20 07:17:42 --> Output Class Initialized
INFO - 2018-01-20 07:17:42 --> Security Class Initialized
DEBUG - 2018-01-20 07:17:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-20 07:17:42 --> Input Class Initialized
INFO - 2018-01-20 07:17:42 --> Language Class Initialized
INFO - 2018-01-20 07:17:42 --> Loader Class Initialized
INFO - 2018-01-20 07:17:42 --> Helper loaded: url_helper
INFO - 2018-01-20 07:17:42 --> Helper loaded: form_helper
INFO - 2018-01-20 07:17:42 --> Database Driver Class Initialized
DEBUG - 2018-01-20 07:17:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-20 07:17:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-20 07:17:42 --> Form Validation Class Initialized
INFO - 2018-01-20 07:17:42 --> Model Class Initialized
INFO - 2018-01-20 07:17:42 --> Controller Class Initialized
INFO - 2018-01-20 07:17:42 --> Model Class Initialized
INFO - 2018-01-20 07:17:42 --> Model Class Initialized
INFO - 2018-01-20 07:17:42 --> Model Class Initialized
INFO - 2018-01-20 07:17:42 --> Model Class Initialized
DEBUG - 2018-01-20 07:17:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-20 07:17:42 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-20 07:17:42 --> Final output sent to browser
DEBUG - 2018-01-20 07:17:42 --> Total execution time: 0.0552
INFO - 2018-01-20 07:17:43 --> Config Class Initialized
INFO - 2018-01-20 07:17:43 --> Hooks Class Initialized
DEBUG - 2018-01-20 07:17:43 --> UTF-8 Support Enabled
INFO - 2018-01-20 07:17:43 --> Utf8 Class Initialized
INFO - 2018-01-20 07:17:43 --> URI Class Initialized
INFO - 2018-01-20 07:17:43 --> Router Class Initialized
INFO - 2018-01-20 07:17:43 --> Output Class Initialized
INFO - 2018-01-20 07:17:43 --> Security Class Initialized
DEBUG - 2018-01-20 07:17:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-20 07:17:43 --> Input Class Initialized
INFO - 2018-01-20 07:17:43 --> Language Class Initialized
INFO - 2018-01-20 07:17:43 --> Loader Class Initialized
INFO - 2018-01-20 07:17:43 --> Helper loaded: url_helper
INFO - 2018-01-20 07:17:43 --> Helper loaded: form_helper
INFO - 2018-01-20 07:17:43 --> Database Driver Class Initialized
DEBUG - 2018-01-20 07:17:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-20 07:17:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-20 07:17:43 --> Form Validation Class Initialized
INFO - 2018-01-20 07:17:43 --> Model Class Initialized
INFO - 2018-01-20 07:17:43 --> Controller Class Initialized
INFO - 2018-01-20 07:17:43 --> Model Class Initialized
INFO - 2018-01-20 07:17:43 --> Model Class Initialized
INFO - 2018-01-20 07:17:43 --> Model Class Initialized
INFO - 2018-01-20 07:17:43 --> Model Class Initialized
DEBUG - 2018-01-20 07:17:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-20 07:17:43 --> Config Class Initialized
INFO - 2018-01-20 07:17:43 --> Hooks Class Initialized
DEBUG - 2018-01-20 07:17:43 --> UTF-8 Support Enabled
INFO - 2018-01-20 07:17:43 --> Utf8 Class Initialized
INFO - 2018-01-20 07:17:43 --> URI Class Initialized
INFO - 2018-01-20 07:17:43 --> Router Class Initialized
INFO - 2018-01-20 07:17:43 --> Output Class Initialized
INFO - 2018-01-20 07:17:43 --> Security Class Initialized
DEBUG - 2018-01-20 07:17:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-20 07:17:43 --> Input Class Initialized
INFO - 2018-01-20 07:17:43 --> Language Class Initialized
INFO - 2018-01-20 07:17:43 --> Loader Class Initialized
INFO - 2018-01-20 07:17:43 --> Helper loaded: url_helper
INFO - 2018-01-20 07:17:43 --> Helper loaded: form_helper
INFO - 2018-01-20 07:17:43 --> Database Driver Class Initialized
DEBUG - 2018-01-20 07:17:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-20 07:17:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-20 07:17:43 --> Form Validation Class Initialized
INFO - 2018-01-20 07:17:43 --> Model Class Initialized
INFO - 2018-01-20 07:17:43 --> Controller Class Initialized
INFO - 2018-01-20 07:17:43 --> Model Class Initialized
INFO - 2018-01-20 07:17:43 --> Model Class Initialized
INFO - 2018-01-20 07:17:43 --> Model Class Initialized
INFO - 2018-01-20 07:17:43 --> Model Class Initialized
DEBUG - 2018-01-20 07:17:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-20 07:20:02 --> Config Class Initialized
INFO - 2018-01-20 07:20:02 --> Hooks Class Initialized
DEBUG - 2018-01-20 07:20:02 --> UTF-8 Support Enabled
INFO - 2018-01-20 07:20:02 --> Utf8 Class Initialized
INFO - 2018-01-20 07:20:02 --> URI Class Initialized
INFO - 2018-01-20 07:20:02 --> Router Class Initialized
INFO - 2018-01-20 07:20:02 --> Output Class Initialized
INFO - 2018-01-20 07:20:02 --> Security Class Initialized
DEBUG - 2018-01-20 07:20:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-20 07:20:02 --> Input Class Initialized
INFO - 2018-01-20 07:20:02 --> Language Class Initialized
INFO - 2018-01-20 07:20:02 --> Loader Class Initialized
INFO - 2018-01-20 07:20:02 --> Helper loaded: url_helper
INFO - 2018-01-20 07:20:02 --> Helper loaded: form_helper
INFO - 2018-01-20 07:20:02 --> Database Driver Class Initialized
DEBUG - 2018-01-20 07:20:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-20 07:20:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-20 07:20:02 --> Form Validation Class Initialized
INFO - 2018-01-20 07:20:02 --> Model Class Initialized
INFO - 2018-01-20 07:20:02 --> Controller Class Initialized
INFO - 2018-01-20 07:20:02 --> Model Class Initialized
INFO - 2018-01-20 07:20:02 --> Model Class Initialized
INFO - 2018-01-20 07:20:02 --> Model Class Initialized
INFO - 2018-01-20 07:20:02 --> Model Class Initialized
DEBUG - 2018-01-20 07:20:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-20 07:20:02 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-20 07:20:02 --> Final output sent to browser
DEBUG - 2018-01-20 07:20:02 --> Total execution time: 0.7905
INFO - 2018-01-20 07:20:03 --> Config Class Initialized
INFO - 2018-01-20 07:20:03 --> Hooks Class Initialized
DEBUG - 2018-01-20 07:20:03 --> UTF-8 Support Enabled
INFO - 2018-01-20 07:20:03 --> Utf8 Class Initialized
INFO - 2018-01-20 07:20:03 --> URI Class Initialized
INFO - 2018-01-20 07:20:03 --> Router Class Initialized
INFO - 2018-01-20 07:20:03 --> Output Class Initialized
INFO - 2018-01-20 07:20:03 --> Security Class Initialized
DEBUG - 2018-01-20 07:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-20 07:20:03 --> Input Class Initialized
INFO - 2018-01-20 07:20:03 --> Language Class Initialized
INFO - 2018-01-20 07:20:03 --> Loader Class Initialized
INFO - 2018-01-20 07:20:03 --> Helper loaded: url_helper
INFO - 2018-01-20 07:20:03 --> Helper loaded: form_helper
INFO - 2018-01-20 07:20:03 --> Database Driver Class Initialized
DEBUG - 2018-01-20 07:20:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-20 07:20:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-20 07:20:03 --> Form Validation Class Initialized
INFO - 2018-01-20 07:20:03 --> Model Class Initialized
INFO - 2018-01-20 07:20:03 --> Controller Class Initialized
INFO - 2018-01-20 07:20:03 --> Model Class Initialized
INFO - 2018-01-20 07:20:03 --> Model Class Initialized
INFO - 2018-01-20 07:20:03 --> Model Class Initialized
INFO - 2018-01-20 07:20:03 --> Model Class Initialized
DEBUG - 2018-01-20 07:20:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-20 07:20:03 --> Config Class Initialized
INFO - 2018-01-20 07:20:03 --> Hooks Class Initialized
DEBUG - 2018-01-20 07:20:03 --> UTF-8 Support Enabled
INFO - 2018-01-20 07:20:03 --> Utf8 Class Initialized
INFO - 2018-01-20 07:20:03 --> URI Class Initialized
INFO - 2018-01-20 07:20:03 --> Router Class Initialized
INFO - 2018-01-20 07:20:03 --> Output Class Initialized
INFO - 2018-01-20 07:20:03 --> Security Class Initialized
DEBUG - 2018-01-20 07:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-20 07:20:03 --> Input Class Initialized
INFO - 2018-01-20 07:20:03 --> Language Class Initialized
INFO - 2018-01-20 07:20:03 --> Loader Class Initialized
INFO - 2018-01-20 07:20:03 --> Helper loaded: url_helper
INFO - 2018-01-20 07:20:03 --> Helper loaded: form_helper
INFO - 2018-01-20 07:20:03 --> Database Driver Class Initialized
DEBUG - 2018-01-20 07:20:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-20 07:20:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-20 07:20:03 --> Form Validation Class Initialized
INFO - 2018-01-20 07:20:03 --> Model Class Initialized
INFO - 2018-01-20 07:20:03 --> Controller Class Initialized
INFO - 2018-01-20 07:20:03 --> Model Class Initialized
INFO - 2018-01-20 07:20:03 --> Model Class Initialized
INFO - 2018-01-20 07:20:03 --> Model Class Initialized
INFO - 2018-01-20 07:20:03 --> Model Class Initialized
DEBUG - 2018-01-20 07:20:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-20 07:20:09 --> Config Class Initialized
INFO - 2018-01-20 07:20:09 --> Hooks Class Initialized
DEBUG - 2018-01-20 07:20:09 --> UTF-8 Support Enabled
INFO - 2018-01-20 07:20:09 --> Utf8 Class Initialized
INFO - 2018-01-20 07:20:09 --> URI Class Initialized
INFO - 2018-01-20 07:20:09 --> Router Class Initialized
INFO - 2018-01-20 07:20:09 --> Output Class Initialized
INFO - 2018-01-20 07:20:09 --> Security Class Initialized
DEBUG - 2018-01-20 07:20:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-20 07:20:09 --> Input Class Initialized
INFO - 2018-01-20 07:20:09 --> Language Class Initialized
INFO - 2018-01-20 07:20:09 --> Loader Class Initialized
INFO - 2018-01-20 07:20:09 --> Helper loaded: url_helper
INFO - 2018-01-20 07:20:09 --> Helper loaded: form_helper
INFO - 2018-01-20 07:20:09 --> Database Driver Class Initialized
DEBUG - 2018-01-20 07:20:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-20 07:20:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-20 07:20:09 --> Form Validation Class Initialized
INFO - 2018-01-20 07:20:09 --> Model Class Initialized
INFO - 2018-01-20 07:20:09 --> Controller Class Initialized
INFO - 2018-01-20 07:20:09 --> Model Class Initialized
INFO - 2018-01-20 07:20:09 --> Model Class Initialized
INFO - 2018-01-20 07:20:09 --> Model Class Initialized
INFO - 2018-01-20 07:20:09 --> Model Class Initialized
DEBUG - 2018-01-20 07:20:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-20 07:20:09 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-20 07:20:09 --> Final output sent to browser
DEBUG - 2018-01-20 07:20:09 --> Total execution time: 0.0579
INFO - 2018-01-20 07:20:09 --> Config Class Initialized
INFO - 2018-01-20 07:20:09 --> Hooks Class Initialized
DEBUG - 2018-01-20 07:20:09 --> UTF-8 Support Enabled
INFO - 2018-01-20 07:20:09 --> Utf8 Class Initialized
INFO - 2018-01-20 07:20:09 --> URI Class Initialized
INFO - 2018-01-20 07:20:09 --> Router Class Initialized
INFO - 2018-01-20 07:20:09 --> Output Class Initialized
INFO - 2018-01-20 07:20:09 --> Security Class Initialized
DEBUG - 2018-01-20 07:20:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-20 07:20:09 --> Input Class Initialized
INFO - 2018-01-20 07:20:09 --> Language Class Initialized
INFO - 2018-01-20 07:20:09 --> Loader Class Initialized
INFO - 2018-01-20 07:20:09 --> Helper loaded: url_helper
INFO - 2018-01-20 07:20:09 --> Helper loaded: form_helper
INFO - 2018-01-20 07:20:09 --> Database Driver Class Initialized
DEBUG - 2018-01-20 07:20:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-20 07:20:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-20 07:20:09 --> Form Validation Class Initialized
INFO - 2018-01-20 07:20:09 --> Model Class Initialized
INFO - 2018-01-20 07:20:09 --> Controller Class Initialized
INFO - 2018-01-20 07:20:09 --> Model Class Initialized
INFO - 2018-01-20 07:20:09 --> Model Class Initialized
INFO - 2018-01-20 07:20:09 --> Model Class Initialized
INFO - 2018-01-20 07:20:09 --> Model Class Initialized
DEBUG - 2018-01-20 07:20:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-20 07:20:13 --> Config Class Initialized
INFO - 2018-01-20 07:20:13 --> Hooks Class Initialized
DEBUG - 2018-01-20 07:20:13 --> UTF-8 Support Enabled
INFO - 2018-01-20 07:20:13 --> Utf8 Class Initialized
INFO - 2018-01-20 07:20:13 --> URI Class Initialized
INFO - 2018-01-20 07:20:13 --> Router Class Initialized
INFO - 2018-01-20 07:20:13 --> Output Class Initialized
INFO - 2018-01-20 07:20:13 --> Security Class Initialized
DEBUG - 2018-01-20 07:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-20 07:20:13 --> Input Class Initialized
INFO - 2018-01-20 07:20:13 --> Language Class Initialized
INFO - 2018-01-20 07:20:13 --> Loader Class Initialized
INFO - 2018-01-20 07:20:13 --> Helper loaded: url_helper
INFO - 2018-01-20 07:20:13 --> Helper loaded: form_helper
INFO - 2018-01-20 07:20:13 --> Database Driver Class Initialized
DEBUG - 2018-01-20 07:20:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-20 07:20:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-20 07:20:13 --> Form Validation Class Initialized
INFO - 2018-01-20 07:20:13 --> Model Class Initialized
INFO - 2018-01-20 07:20:13 --> Controller Class Initialized
INFO - 2018-01-20 07:20:13 --> Model Class Initialized
INFO - 2018-01-20 07:20:13 --> Model Class Initialized
INFO - 2018-01-20 07:20:13 --> Model Class Initialized
INFO - 2018-01-20 07:20:13 --> Model Class Initialized
DEBUG - 2018-01-20 07:20:13 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-01-20 07:20:13 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/instateccr/public_html/controlcostos/vendor/phpoffice/phpspreadsheet/src/PhpSpreadsheet/Calculation/Calculation.php:3030) /home/instateccr/public_html/controlcostos/instatec_sys/core/Common.php 564
ERROR - 2018-01-20 07:20:13 --> Severity: Parsing Error --> syntax error, unexpected '.', expecting '&' or variable (T_VARIABLE) /home/instateccr/public_html/controlcostos/vendor/phpoffice/phpspreadsheet/src/PhpSpreadsheet/Calculation/Calculation.php 3030
INFO - 2018-01-20 07:24:10 --> Config Class Initialized
INFO - 2018-01-20 07:24:10 --> Hooks Class Initialized
DEBUG - 2018-01-20 07:24:10 --> UTF-8 Support Enabled
INFO - 2018-01-20 07:24:10 --> Utf8 Class Initialized
INFO - 2018-01-20 07:24:10 --> URI Class Initialized
INFO - 2018-01-20 07:24:10 --> Router Class Initialized
INFO - 2018-01-20 07:24:10 --> Output Class Initialized
INFO - 2018-01-20 07:24:10 --> Security Class Initialized
DEBUG - 2018-01-20 07:24:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-20 07:24:10 --> Input Class Initialized
INFO - 2018-01-20 07:24:10 --> Language Class Initialized
INFO - 2018-01-20 07:24:10 --> Loader Class Initialized
INFO - 2018-01-20 07:24:10 --> Helper loaded: url_helper
INFO - 2018-01-20 07:24:10 --> Helper loaded: form_helper
INFO - 2018-01-20 07:24:10 --> Database Driver Class Initialized
DEBUG - 2018-01-20 07:24:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-20 07:24:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-20 07:24:10 --> Form Validation Class Initialized
INFO - 2018-01-20 07:24:10 --> Model Class Initialized
INFO - 2018-01-20 07:24:10 --> Controller Class Initialized
INFO - 2018-01-20 07:24:10 --> Model Class Initialized
INFO - 2018-01-20 07:24:10 --> Model Class Initialized
INFO - 2018-01-20 07:24:10 --> Model Class Initialized
INFO - 2018-01-20 07:24:10 --> Model Class Initialized
DEBUG - 2018-01-20 07:24:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-20 07:24:10 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-20 07:24:10 --> Final output sent to browser
DEBUG - 2018-01-20 07:24:10 --> Total execution time: 0.0450
INFO - 2018-01-20 07:24:10 --> Config Class Initialized
INFO - 2018-01-20 07:24:10 --> Hooks Class Initialized
DEBUG - 2018-01-20 07:24:10 --> UTF-8 Support Enabled
INFO - 2018-01-20 07:24:10 --> Utf8 Class Initialized
INFO - 2018-01-20 07:24:10 --> URI Class Initialized
INFO - 2018-01-20 07:24:10 --> Router Class Initialized
INFO - 2018-01-20 07:24:10 --> Output Class Initialized
INFO - 2018-01-20 07:24:10 --> Security Class Initialized
DEBUG - 2018-01-20 07:24:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-20 07:24:10 --> Input Class Initialized
INFO - 2018-01-20 07:24:10 --> Language Class Initialized
INFO - 2018-01-20 07:24:10 --> Loader Class Initialized
INFO - 2018-01-20 07:24:10 --> Helper loaded: url_helper
INFO - 2018-01-20 07:24:10 --> Helper loaded: form_helper
INFO - 2018-01-20 07:24:10 --> Database Driver Class Initialized
DEBUG - 2018-01-20 07:24:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-20 07:24:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-20 07:24:10 --> Form Validation Class Initialized
INFO - 2018-01-20 07:24:10 --> Model Class Initialized
INFO - 2018-01-20 07:24:10 --> Controller Class Initialized
INFO - 2018-01-20 07:24:10 --> Model Class Initialized
INFO - 2018-01-20 07:24:10 --> Model Class Initialized
INFO - 2018-01-20 07:24:10 --> Model Class Initialized
INFO - 2018-01-20 07:24:10 --> Model Class Initialized
DEBUG - 2018-01-20 07:24:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-20 07:24:17 --> Config Class Initialized
INFO - 2018-01-20 07:24:17 --> Hooks Class Initialized
DEBUG - 2018-01-20 07:24:17 --> UTF-8 Support Enabled
INFO - 2018-01-20 07:24:17 --> Utf8 Class Initialized
INFO - 2018-01-20 07:24:17 --> URI Class Initialized
INFO - 2018-01-20 07:24:17 --> Router Class Initialized
INFO - 2018-01-20 07:24:17 --> Output Class Initialized
INFO - 2018-01-20 07:24:17 --> Security Class Initialized
DEBUG - 2018-01-20 07:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-20 07:24:17 --> Input Class Initialized
INFO - 2018-01-20 07:24:17 --> Language Class Initialized
INFO - 2018-01-20 07:24:17 --> Loader Class Initialized
INFO - 2018-01-20 07:24:17 --> Helper loaded: url_helper
INFO - 2018-01-20 07:24:17 --> Helper loaded: form_helper
INFO - 2018-01-20 07:24:17 --> Database Driver Class Initialized
DEBUG - 2018-01-20 07:24:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-20 07:24:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-20 07:24:17 --> Form Validation Class Initialized
INFO - 2018-01-20 07:24:17 --> Model Class Initialized
INFO - 2018-01-20 07:24:17 --> Controller Class Initialized
INFO - 2018-01-20 07:24:17 --> Model Class Initialized
INFO - 2018-01-20 07:24:17 --> Model Class Initialized
INFO - 2018-01-20 07:24:17 --> Model Class Initialized
INFO - 2018-01-20 07:24:17 --> Model Class Initialized
DEBUG - 2018-01-20 07:24:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-20 07:24:20 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-20 07:24:20 --> Final output sent to browser
DEBUG - 2018-01-20 07:24:20 --> Total execution time: 2.8415
INFO - 2018-01-20 07:24:38 --> Config Class Initialized
INFO - 2018-01-20 07:24:38 --> Hooks Class Initialized
DEBUG - 2018-01-20 07:24:38 --> UTF-8 Support Enabled
INFO - 2018-01-20 07:24:38 --> Utf8 Class Initialized
INFO - 2018-01-20 07:24:38 --> URI Class Initialized
INFO - 2018-01-20 07:24:38 --> Router Class Initialized
INFO - 2018-01-20 07:24:38 --> Output Class Initialized
INFO - 2018-01-20 07:24:38 --> Security Class Initialized
DEBUG - 2018-01-20 07:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-20 07:24:38 --> Input Class Initialized
INFO - 2018-01-20 07:24:38 --> Language Class Initialized
INFO - 2018-01-20 07:24:38 --> Loader Class Initialized
INFO - 2018-01-20 07:24:38 --> Helper loaded: url_helper
INFO - 2018-01-20 07:24:38 --> Helper loaded: form_helper
INFO - 2018-01-20 07:24:38 --> Database Driver Class Initialized
DEBUG - 2018-01-20 07:24:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-20 07:24:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-20 07:24:38 --> Form Validation Class Initialized
INFO - 2018-01-20 07:24:38 --> Model Class Initialized
INFO - 2018-01-20 07:24:38 --> Controller Class Initialized
INFO - 2018-01-20 07:24:38 --> Model Class Initialized
INFO - 2018-01-20 07:24:38 --> Model Class Initialized
DEBUG - 2018-01-20 07:24:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-20 07:24:38 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-20 07:24:38 --> Final output sent to browser
DEBUG - 2018-01-20 07:24:38 --> Total execution time: 0.0436
INFO - 2018-01-20 07:24:38 --> Config Class Initialized
INFO - 2018-01-20 07:24:38 --> Hooks Class Initialized
DEBUG - 2018-01-20 07:24:38 --> UTF-8 Support Enabled
INFO - 2018-01-20 07:24:38 --> Utf8 Class Initialized
INFO - 2018-01-20 07:24:38 --> URI Class Initialized
INFO - 2018-01-20 07:24:38 --> Router Class Initialized
INFO - 2018-01-20 07:24:38 --> Output Class Initialized
INFO - 2018-01-20 07:24:38 --> Security Class Initialized
DEBUG - 2018-01-20 07:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-20 07:24:38 --> Input Class Initialized
INFO - 2018-01-20 07:24:38 --> Language Class Initialized
INFO - 2018-01-20 07:24:38 --> Loader Class Initialized
INFO - 2018-01-20 07:24:38 --> Helper loaded: url_helper
INFO - 2018-01-20 07:24:38 --> Helper loaded: form_helper
INFO - 2018-01-20 07:24:39 --> Database Driver Class Initialized
DEBUG - 2018-01-20 07:24:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-20 07:24:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-20 07:24:39 --> Form Validation Class Initialized
INFO - 2018-01-20 07:24:39 --> Model Class Initialized
INFO - 2018-01-20 07:24:39 --> Controller Class Initialized
INFO - 2018-01-20 07:24:39 --> Model Class Initialized
INFO - 2018-01-20 07:24:39 --> Model Class Initialized
DEBUG - 2018-01-20 07:24:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-20 07:24:43 --> Config Class Initialized
INFO - 2018-01-20 07:24:43 --> Hooks Class Initialized
DEBUG - 2018-01-20 07:24:43 --> UTF-8 Support Enabled
INFO - 2018-01-20 07:24:43 --> Utf8 Class Initialized
INFO - 2018-01-20 07:24:43 --> URI Class Initialized
INFO - 2018-01-20 07:24:43 --> Router Class Initialized
INFO - 2018-01-20 07:24:43 --> Output Class Initialized
INFO - 2018-01-20 07:24:43 --> Security Class Initialized
DEBUG - 2018-01-20 07:24:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-20 07:24:43 --> Input Class Initialized
INFO - 2018-01-20 07:24:43 --> Language Class Initialized
INFO - 2018-01-20 07:24:43 --> Loader Class Initialized
INFO - 2018-01-20 07:24:43 --> Helper loaded: url_helper
INFO - 2018-01-20 07:24:43 --> Helper loaded: form_helper
INFO - 2018-01-20 07:24:43 --> Database Driver Class Initialized
DEBUG - 2018-01-20 07:24:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-20 07:24:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-20 07:24:43 --> Form Validation Class Initialized
INFO - 2018-01-20 07:24:43 --> Model Class Initialized
INFO - 2018-01-20 07:24:43 --> Controller Class Initialized
INFO - 2018-01-20 07:24:43 --> Model Class Initialized
INFO - 2018-01-20 07:24:43 --> Model Class Initialized
DEBUG - 2018-01-20 07:24:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-20 07:24:43 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-20 07:24:43 --> Final output sent to browser
DEBUG - 2018-01-20 07:24:43 --> Total execution time: 0.0400
INFO - 2018-01-20 07:27:55 --> Config Class Initialized
INFO - 2018-01-20 07:27:55 --> Hooks Class Initialized
DEBUG - 2018-01-20 07:27:55 --> UTF-8 Support Enabled
INFO - 2018-01-20 07:27:55 --> Utf8 Class Initialized
INFO - 2018-01-20 07:27:55 --> URI Class Initialized
INFO - 2018-01-20 07:27:55 --> Router Class Initialized
INFO - 2018-01-20 07:27:55 --> Output Class Initialized
INFO - 2018-01-20 07:27:55 --> Security Class Initialized
DEBUG - 2018-01-20 07:27:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-20 07:27:55 --> Input Class Initialized
INFO - 2018-01-20 07:27:55 --> Language Class Initialized
INFO - 2018-01-20 07:27:55 --> Loader Class Initialized
INFO - 2018-01-20 07:27:55 --> Helper loaded: url_helper
INFO - 2018-01-20 07:27:55 --> Helper loaded: form_helper
INFO - 2018-01-20 07:27:55 --> Database Driver Class Initialized
DEBUG - 2018-01-20 07:27:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-20 07:27:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-20 07:27:55 --> Form Validation Class Initialized
INFO - 2018-01-20 07:27:55 --> Model Class Initialized
INFO - 2018-01-20 07:27:55 --> Controller Class Initialized
INFO - 2018-01-20 07:27:55 --> Model Class Initialized
INFO - 2018-01-20 07:27:55 --> Model Class Initialized
DEBUG - 2018-01-20 07:27:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-20 07:27:56 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-20 07:27:56 --> Final output sent to browser
DEBUG - 2018-01-20 07:27:56 --> Total execution time: 0.7358
INFO - 2018-01-20 07:28:00 --> Config Class Initialized
INFO - 2018-01-20 07:28:00 --> Hooks Class Initialized
DEBUG - 2018-01-20 07:28:00 --> UTF-8 Support Enabled
INFO - 2018-01-20 07:28:00 --> Utf8 Class Initialized
INFO - 2018-01-20 07:28:00 --> URI Class Initialized
INFO - 2018-01-20 07:28:00 --> Router Class Initialized
INFO - 2018-01-20 07:28:00 --> Output Class Initialized
INFO - 2018-01-20 07:28:00 --> Security Class Initialized
DEBUG - 2018-01-20 07:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-20 07:28:00 --> Input Class Initialized
INFO - 2018-01-20 07:28:00 --> Language Class Initialized
INFO - 2018-01-20 07:28:00 --> Loader Class Initialized
INFO - 2018-01-20 07:28:00 --> Helper loaded: url_helper
INFO - 2018-01-20 07:28:00 --> Helper loaded: form_helper
INFO - 2018-01-20 07:28:00 --> Database Driver Class Initialized
DEBUG - 2018-01-20 07:28:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-20 07:28:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-20 07:28:00 --> Form Validation Class Initialized
INFO - 2018-01-20 07:28:00 --> Model Class Initialized
INFO - 2018-01-20 07:28:00 --> Controller Class Initialized
INFO - 2018-01-20 07:28:00 --> Model Class Initialized
INFO - 2018-01-20 07:28:00 --> Model Class Initialized
INFO - 2018-01-20 07:28:00 --> Model Class Initialized
INFO - 2018-01-20 07:28:00 --> Model Class Initialized
DEBUG - 2018-01-20 07:28:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-20 07:28:00 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-20 07:28:00 --> Final output sent to browser
DEBUG - 2018-01-20 07:28:00 --> Total execution time: 0.0464
INFO - 2018-01-20 07:28:01 --> Config Class Initialized
INFO - 2018-01-20 07:28:01 --> Hooks Class Initialized
DEBUG - 2018-01-20 07:28:01 --> UTF-8 Support Enabled
INFO - 2018-01-20 07:28:01 --> Utf8 Class Initialized
INFO - 2018-01-20 07:28:01 --> URI Class Initialized
INFO - 2018-01-20 07:28:01 --> Router Class Initialized
INFO - 2018-01-20 07:28:01 --> Output Class Initialized
INFO - 2018-01-20 07:28:01 --> Security Class Initialized
DEBUG - 2018-01-20 07:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-20 07:28:01 --> Input Class Initialized
INFO - 2018-01-20 07:28:01 --> Language Class Initialized
INFO - 2018-01-20 07:28:01 --> Loader Class Initialized
INFO - 2018-01-20 07:28:01 --> Helper loaded: url_helper
INFO - 2018-01-20 07:28:01 --> Helper loaded: form_helper
INFO - 2018-01-20 07:28:01 --> Database Driver Class Initialized
DEBUG - 2018-01-20 07:28:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-20 07:28:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-20 07:28:01 --> Form Validation Class Initialized
INFO - 2018-01-20 07:28:01 --> Model Class Initialized
INFO - 2018-01-20 07:28:01 --> Controller Class Initialized
INFO - 2018-01-20 07:28:01 --> Model Class Initialized
INFO - 2018-01-20 07:28:01 --> Model Class Initialized
INFO - 2018-01-20 07:28:01 --> Model Class Initialized
INFO - 2018-01-20 07:28:01 --> Model Class Initialized
DEBUG - 2018-01-20 07:28:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-20 07:28:02 --> Config Class Initialized
INFO - 2018-01-20 07:28:02 --> Hooks Class Initialized
DEBUG - 2018-01-20 07:28:02 --> UTF-8 Support Enabled
INFO - 2018-01-20 07:28:02 --> Utf8 Class Initialized
INFO - 2018-01-20 07:28:02 --> URI Class Initialized
INFO - 2018-01-20 07:28:02 --> Router Class Initialized
INFO - 2018-01-20 07:28:02 --> Output Class Initialized
INFO - 2018-01-20 07:28:02 --> Security Class Initialized
DEBUG - 2018-01-20 07:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-20 07:28:02 --> Input Class Initialized
INFO - 2018-01-20 07:28:02 --> Language Class Initialized
INFO - 2018-01-20 07:28:02 --> Loader Class Initialized
INFO - 2018-01-20 07:28:02 --> Helper loaded: url_helper
INFO - 2018-01-20 07:28:02 --> Helper loaded: form_helper
INFO - 2018-01-20 07:28:02 --> Database Driver Class Initialized
DEBUG - 2018-01-20 07:28:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-20 07:28:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-20 07:28:02 --> Form Validation Class Initialized
INFO - 2018-01-20 07:28:02 --> Model Class Initialized
INFO - 2018-01-20 07:28:02 --> Controller Class Initialized
INFO - 2018-01-20 07:28:02 --> Model Class Initialized
INFO - 2018-01-20 07:28:02 --> Model Class Initialized
INFO - 2018-01-20 07:28:02 --> Model Class Initialized
INFO - 2018-01-20 07:28:02 --> Model Class Initialized
DEBUG - 2018-01-20 07:28:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-20 07:28:02 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-20 07:28:02 --> Final output sent to browser
DEBUG - 2018-01-20 07:28:02 --> Total execution time: 0.0897
INFO - 2018-01-20 13:03:54 --> Config Class Initialized
INFO - 2018-01-20 13:03:54 --> Hooks Class Initialized
DEBUG - 2018-01-20 13:03:54 --> UTF-8 Support Enabled
INFO - 2018-01-20 13:03:54 --> Utf8 Class Initialized
INFO - 2018-01-20 13:03:54 --> URI Class Initialized
DEBUG - 2018-01-20 13:03:54 --> No URI present. Default controller set.
INFO - 2018-01-20 13:03:54 --> Router Class Initialized
INFO - 2018-01-20 13:03:54 --> Output Class Initialized
INFO - 2018-01-20 13:03:54 --> Security Class Initialized
DEBUG - 2018-01-20 13:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-20 13:03:54 --> Input Class Initialized
INFO - 2018-01-20 13:03:54 --> Language Class Initialized
INFO - 2018-01-20 13:03:54 --> Loader Class Initialized
INFO - 2018-01-20 13:03:54 --> Helper loaded: url_helper
INFO - 2018-01-20 13:03:54 --> Helper loaded: form_helper
INFO - 2018-01-20 13:03:54 --> Database Driver Class Initialized
DEBUG - 2018-01-20 13:03:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-20 13:03:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-20 13:03:54 --> Form Validation Class Initialized
INFO - 2018-01-20 13:03:54 --> Model Class Initialized
INFO - 2018-01-20 13:03:54 --> Controller Class Initialized
INFO - 2018-01-20 13:03:55 --> Config Class Initialized
INFO - 2018-01-20 13:03:55 --> Hooks Class Initialized
DEBUG - 2018-01-20 13:03:55 --> UTF-8 Support Enabled
INFO - 2018-01-20 13:03:55 --> Utf8 Class Initialized
INFO - 2018-01-20 13:03:55 --> URI Class Initialized
INFO - 2018-01-20 13:03:55 --> Router Class Initialized
INFO - 2018-01-20 13:03:55 --> Output Class Initialized
INFO - 2018-01-20 13:03:55 --> Security Class Initialized
DEBUG - 2018-01-20 13:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-20 13:03:55 --> Input Class Initialized
INFO - 2018-01-20 13:03:55 --> Language Class Initialized
INFO - 2018-01-20 13:03:55 --> Loader Class Initialized
INFO - 2018-01-20 13:03:55 --> Helper loaded: url_helper
INFO - 2018-01-20 13:03:55 --> Helper loaded: form_helper
INFO - 2018-01-20 13:03:55 --> Database Driver Class Initialized
DEBUG - 2018-01-20 13:03:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-20 13:03:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-20 13:03:55 --> Form Validation Class Initialized
INFO - 2018-01-20 13:03:55 --> Model Class Initialized
INFO - 2018-01-20 13:03:55 --> Controller Class Initialized
INFO - 2018-01-20 13:03:55 --> Model Class Initialized
DEBUG - 2018-01-20 13:03:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-20 13:03:55 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-20 13:03:55 --> Final output sent to browser
DEBUG - 2018-01-20 13:03:55 --> Total execution time: 0.3433
INFO - 2018-01-20 13:04:38 --> Config Class Initialized
INFO - 2018-01-20 13:04:38 --> Hooks Class Initialized
DEBUG - 2018-01-20 13:04:38 --> UTF-8 Support Enabled
INFO - 2018-01-20 13:04:38 --> Utf8 Class Initialized
INFO - 2018-01-20 13:04:38 --> URI Class Initialized
DEBUG - 2018-01-20 13:04:38 --> No URI present. Default controller set.
INFO - 2018-01-20 13:04:38 --> Router Class Initialized
INFO - 2018-01-20 13:04:38 --> Output Class Initialized
INFO - 2018-01-20 13:04:38 --> Security Class Initialized
DEBUG - 2018-01-20 13:04:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-20 13:04:38 --> Input Class Initialized
INFO - 2018-01-20 13:04:38 --> Language Class Initialized
INFO - 2018-01-20 13:04:38 --> Loader Class Initialized
INFO - 2018-01-20 13:04:38 --> Helper loaded: url_helper
INFO - 2018-01-20 13:04:38 --> Helper loaded: form_helper
INFO - 2018-01-20 13:04:38 --> Database Driver Class Initialized
DEBUG - 2018-01-20 13:04:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-20 13:04:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-20 13:04:38 --> Form Validation Class Initialized
INFO - 2018-01-20 13:04:38 --> Model Class Initialized
INFO - 2018-01-20 13:04:38 --> Controller Class Initialized
INFO - 2018-01-20 13:04:39 --> Config Class Initialized
INFO - 2018-01-20 13:04:39 --> Hooks Class Initialized
DEBUG - 2018-01-20 13:04:39 --> UTF-8 Support Enabled
INFO - 2018-01-20 13:04:39 --> Utf8 Class Initialized
INFO - 2018-01-20 13:04:39 --> URI Class Initialized
INFO - 2018-01-20 13:04:39 --> Router Class Initialized
INFO - 2018-01-20 13:04:39 --> Output Class Initialized
INFO - 2018-01-20 13:04:39 --> Security Class Initialized
DEBUG - 2018-01-20 13:04:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-20 13:04:39 --> Input Class Initialized
INFO - 2018-01-20 13:04:39 --> Language Class Initialized
INFO - 2018-01-20 13:04:39 --> Loader Class Initialized
INFO - 2018-01-20 13:04:39 --> Helper loaded: url_helper
INFO - 2018-01-20 13:04:39 --> Helper loaded: form_helper
INFO - 2018-01-20 13:04:39 --> Database Driver Class Initialized
DEBUG - 2018-01-20 13:04:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-20 13:04:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-20 13:04:39 --> Form Validation Class Initialized
INFO - 2018-01-20 13:04:39 --> Model Class Initialized
INFO - 2018-01-20 13:04:39 --> Controller Class Initialized
INFO - 2018-01-20 13:04:39 --> Model Class Initialized
DEBUG - 2018-01-20 13:04:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-20 13:04:39 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-20 13:04:39 --> Final output sent to browser
DEBUG - 2018-01-20 13:04:40 --> Total execution time: 0.0350
INFO - 2018-01-20 13:05:27 --> Config Class Initialized
INFO - 2018-01-20 13:05:27 --> Hooks Class Initialized
DEBUG - 2018-01-20 13:05:27 --> UTF-8 Support Enabled
INFO - 2018-01-20 13:05:27 --> Utf8 Class Initialized
INFO - 2018-01-20 13:05:27 --> URI Class Initialized
INFO - 2018-01-20 13:05:27 --> Router Class Initialized
INFO - 2018-01-20 13:05:27 --> Output Class Initialized
INFO - 2018-01-20 13:05:27 --> Security Class Initialized
DEBUG - 2018-01-20 13:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-20 13:05:27 --> Input Class Initialized
INFO - 2018-01-20 13:05:27 --> Language Class Initialized
INFO - 2018-01-20 13:05:27 --> Loader Class Initialized
INFO - 2018-01-20 13:05:27 --> Helper loaded: url_helper
INFO - 2018-01-20 13:05:27 --> Helper loaded: form_helper
INFO - 2018-01-20 13:05:27 --> Database Driver Class Initialized
DEBUG - 2018-01-20 13:05:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-20 13:05:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-20 13:05:27 --> Form Validation Class Initialized
INFO - 2018-01-20 13:05:27 --> Model Class Initialized
INFO - 2018-01-20 13:05:27 --> Controller Class Initialized
INFO - 2018-01-20 13:05:27 --> Model Class Initialized
DEBUG - 2018-01-20 13:05:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-20 13:05:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-01-20 13:05:32 --> Config Class Initialized
INFO - 2018-01-20 13:05:32 --> Hooks Class Initialized
DEBUG - 2018-01-20 13:05:32 --> UTF-8 Support Enabled
INFO - 2018-01-20 13:05:32 --> Utf8 Class Initialized
INFO - 2018-01-20 13:05:32 --> URI Class Initialized
DEBUG - 2018-01-20 13:05:32 --> No URI present. Default controller set.
INFO - 2018-01-20 13:05:32 --> Router Class Initialized
INFO - 2018-01-20 13:05:32 --> Output Class Initialized
INFO - 2018-01-20 13:05:32 --> Security Class Initialized
DEBUG - 2018-01-20 13:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-20 13:05:32 --> Input Class Initialized
INFO - 2018-01-20 13:05:32 --> Language Class Initialized
INFO - 2018-01-20 13:05:32 --> Loader Class Initialized
INFO - 2018-01-20 13:05:32 --> Helper loaded: url_helper
INFO - 2018-01-20 13:05:32 --> Helper loaded: form_helper
INFO - 2018-01-20 13:05:32 --> Database Driver Class Initialized
DEBUG - 2018-01-20 13:05:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-20 13:05:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-20 13:05:32 --> Form Validation Class Initialized
INFO - 2018-01-20 13:05:32 --> Model Class Initialized
INFO - 2018-01-20 13:05:32 --> Controller Class Initialized
INFO - 2018-01-20 13:05:32 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-20 13:05:32 --> Final output sent to browser
DEBUG - 2018-01-20 13:05:32 --> Total execution time: 0.0350
INFO - 2018-01-20 13:06:07 --> Config Class Initialized
INFO - 2018-01-20 13:06:07 --> Hooks Class Initialized
DEBUG - 2018-01-20 13:06:07 --> UTF-8 Support Enabled
INFO - 2018-01-20 13:06:07 --> Utf8 Class Initialized
INFO - 2018-01-20 13:06:07 --> URI Class Initialized
INFO - 2018-01-20 13:06:07 --> Router Class Initialized
INFO - 2018-01-20 13:06:07 --> Output Class Initialized
INFO - 2018-01-20 13:06:07 --> Security Class Initialized
DEBUG - 2018-01-20 13:06:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-20 13:06:07 --> Input Class Initialized
INFO - 2018-01-20 13:06:07 --> Language Class Initialized
INFO - 2018-01-20 13:06:07 --> Loader Class Initialized
INFO - 2018-01-20 13:06:07 --> Helper loaded: url_helper
INFO - 2018-01-20 13:06:07 --> Helper loaded: form_helper
INFO - 2018-01-20 13:06:07 --> Database Driver Class Initialized
DEBUG - 2018-01-20 13:06:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-20 13:06:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-20 13:06:07 --> Form Validation Class Initialized
INFO - 2018-01-20 13:06:07 --> Model Class Initialized
INFO - 2018-01-20 13:06:07 --> Controller Class Initialized
INFO - 2018-01-20 13:06:07 --> Model Class Initialized
INFO - 2018-01-20 13:06:07 --> Model Class Initialized
INFO - 2018-01-20 13:06:07 --> Model Class Initialized
INFO - 2018-01-20 13:06:07 --> Model Class Initialized
DEBUG - 2018-01-20 13:06:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-20 13:06:08 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-20 13:06:08 --> Final output sent to browser
DEBUG - 2018-01-20 13:06:08 --> Total execution time: 0.8095
INFO - 2018-01-20 13:06:09 --> Config Class Initialized
INFO - 2018-01-20 13:06:09 --> Hooks Class Initialized
DEBUG - 2018-01-20 13:06:09 --> UTF-8 Support Enabled
INFO - 2018-01-20 13:06:09 --> Utf8 Class Initialized
INFO - 2018-01-20 13:06:09 --> URI Class Initialized
INFO - 2018-01-20 13:06:09 --> Router Class Initialized
INFO - 2018-01-20 13:06:09 --> Output Class Initialized
INFO - 2018-01-20 13:06:09 --> Security Class Initialized
DEBUG - 2018-01-20 13:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-20 13:06:09 --> Input Class Initialized
INFO - 2018-01-20 13:06:09 --> Language Class Initialized
INFO - 2018-01-20 13:06:09 --> Loader Class Initialized
INFO - 2018-01-20 13:06:09 --> Helper loaded: url_helper
INFO - 2018-01-20 13:06:09 --> Helper loaded: form_helper
INFO - 2018-01-20 13:06:09 --> Database Driver Class Initialized
DEBUG - 2018-01-20 13:06:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-20 13:06:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-20 13:06:09 --> Form Validation Class Initialized
INFO - 2018-01-20 13:06:09 --> Model Class Initialized
INFO - 2018-01-20 13:06:09 --> Controller Class Initialized
INFO - 2018-01-20 13:06:09 --> Model Class Initialized
INFO - 2018-01-20 13:06:09 --> Model Class Initialized
INFO - 2018-01-20 13:06:09 --> Model Class Initialized
INFO - 2018-01-20 13:06:09 --> Model Class Initialized
DEBUG - 2018-01-20 13:06:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-20 13:06:16 --> Config Class Initialized
INFO - 2018-01-20 13:06:16 --> Hooks Class Initialized
DEBUG - 2018-01-20 13:06:16 --> UTF-8 Support Enabled
INFO - 2018-01-20 13:06:16 --> Utf8 Class Initialized
INFO - 2018-01-20 13:06:16 --> URI Class Initialized
INFO - 2018-01-20 13:06:16 --> Router Class Initialized
INFO - 2018-01-20 13:06:16 --> Output Class Initialized
INFO - 2018-01-20 13:06:16 --> Security Class Initialized
DEBUG - 2018-01-20 13:06:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-20 13:06:16 --> Input Class Initialized
INFO - 2018-01-20 13:06:16 --> Language Class Initialized
INFO - 2018-01-20 13:06:16 --> Loader Class Initialized
INFO - 2018-01-20 13:06:16 --> Helper loaded: url_helper
INFO - 2018-01-20 13:06:16 --> Helper loaded: form_helper
INFO - 2018-01-20 13:06:16 --> Database Driver Class Initialized
DEBUG - 2018-01-20 13:06:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-20 13:06:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-20 13:06:16 --> Form Validation Class Initialized
INFO - 2018-01-20 13:06:16 --> Model Class Initialized
INFO - 2018-01-20 13:06:16 --> Controller Class Initialized
INFO - 2018-01-20 13:06:16 --> Model Class Initialized
INFO - 2018-01-20 13:06:16 --> Model Class Initialized
INFO - 2018-01-20 13:06:16 --> Model Class Initialized
INFO - 2018-01-20 13:06:16 --> Model Class Initialized
DEBUG - 2018-01-20 13:06:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-20 13:06:16 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-20 13:06:16 --> Final output sent to browser
DEBUG - 2018-01-20 13:06:16 --> Total execution time: 0.0813
INFO - 2018-01-20 13:06:17 --> Config Class Initialized
INFO - 2018-01-20 13:06:17 --> Hooks Class Initialized
DEBUG - 2018-01-20 13:06:17 --> UTF-8 Support Enabled
INFO - 2018-01-20 13:06:17 --> Utf8 Class Initialized
INFO - 2018-01-20 13:06:17 --> URI Class Initialized
INFO - 2018-01-20 13:06:17 --> Router Class Initialized
INFO - 2018-01-20 13:06:17 --> Output Class Initialized
INFO - 2018-01-20 13:06:17 --> Security Class Initialized
DEBUG - 2018-01-20 13:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-20 13:06:17 --> Input Class Initialized
INFO - 2018-01-20 13:06:17 --> Language Class Initialized
INFO - 2018-01-20 13:06:17 --> Loader Class Initialized
INFO - 2018-01-20 13:06:17 --> Helper loaded: url_helper
INFO - 2018-01-20 13:06:17 --> Helper loaded: form_helper
INFO - 2018-01-20 13:06:17 --> Database Driver Class Initialized
DEBUG - 2018-01-20 13:06:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-20 13:06:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-20 13:06:17 --> Form Validation Class Initialized
INFO - 2018-01-20 13:06:17 --> Model Class Initialized
INFO - 2018-01-20 13:06:17 --> Controller Class Initialized
INFO - 2018-01-20 13:06:17 --> Model Class Initialized
INFO - 2018-01-20 13:06:17 --> Model Class Initialized
INFO - 2018-01-20 13:06:17 --> Model Class Initialized
INFO - 2018-01-20 13:06:17 --> Model Class Initialized
DEBUG - 2018-01-20 13:06:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-20 13:29:45 --> Config Class Initialized
INFO - 2018-01-20 13:29:45 --> Hooks Class Initialized
DEBUG - 2018-01-20 13:29:45 --> UTF-8 Support Enabled
INFO - 2018-01-20 13:29:45 --> Utf8 Class Initialized
INFO - 2018-01-20 13:29:45 --> URI Class Initialized
INFO - 2018-01-20 13:29:45 --> Router Class Initialized
INFO - 2018-01-20 13:29:45 --> Output Class Initialized
INFO - 2018-01-20 13:29:45 --> Security Class Initialized
DEBUG - 2018-01-20 13:29:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-20 13:29:45 --> Input Class Initialized
INFO - 2018-01-20 13:29:45 --> Language Class Initialized
INFO - 2018-01-20 13:29:45 --> Loader Class Initialized
INFO - 2018-01-20 13:29:45 --> Helper loaded: url_helper
INFO - 2018-01-20 13:29:45 --> Helper loaded: form_helper
INFO - 2018-01-20 13:29:45 --> Database Driver Class Initialized
DEBUG - 2018-01-20 13:29:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-20 13:29:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-20 13:29:45 --> Form Validation Class Initialized
INFO - 2018-01-20 13:29:45 --> Model Class Initialized
INFO - 2018-01-20 13:29:45 --> Controller Class Initialized
INFO - 2018-01-20 13:29:45 --> Model Class Initialized
INFO - 2018-01-20 13:29:45 --> Model Class Initialized
INFO - 2018-01-20 13:29:45 --> Model Class Initialized
INFO - 2018-01-20 13:29:45 --> Model Class Initialized
DEBUG - 2018-01-20 13:29:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-20 13:29:45 --> Config Class Initialized
INFO - 2018-01-20 13:29:45 --> Hooks Class Initialized
DEBUG - 2018-01-20 13:29:45 --> UTF-8 Support Enabled
INFO - 2018-01-20 13:29:45 --> Utf8 Class Initialized
INFO - 2018-01-20 13:29:45 --> URI Class Initialized
INFO - 2018-01-20 13:29:45 --> Router Class Initialized
INFO - 2018-01-20 13:29:45 --> Output Class Initialized
INFO - 2018-01-20 13:29:45 --> Security Class Initialized
DEBUG - 2018-01-20 13:29:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-20 13:29:45 --> Input Class Initialized
INFO - 2018-01-20 13:29:45 --> Language Class Initialized
INFO - 2018-01-20 13:29:45 --> Loader Class Initialized
INFO - 2018-01-20 13:29:45 --> Helper loaded: url_helper
INFO - 2018-01-20 13:29:45 --> Helper loaded: form_helper
INFO - 2018-01-20 13:29:45 --> Database Driver Class Initialized
DEBUG - 2018-01-20 13:29:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-20 13:29:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-20 13:29:45 --> Form Validation Class Initialized
INFO - 2018-01-20 13:29:45 --> Model Class Initialized
INFO - 2018-01-20 13:29:45 --> Controller Class Initialized
INFO - 2018-01-20 13:29:45 --> Model Class Initialized
DEBUG - 2018-01-20 13:29:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-20 13:29:45 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-20 13:29:45 --> Final output sent to browser
DEBUG - 2018-01-20 13:29:45 --> Total execution time: 0.0373
INFO - 2018-01-20 13:33:30 --> Config Class Initialized
INFO - 2018-01-20 13:33:30 --> Hooks Class Initialized
DEBUG - 2018-01-20 13:33:30 --> UTF-8 Support Enabled
INFO - 2018-01-20 13:33:30 --> Utf8 Class Initialized
INFO - 2018-01-20 13:33:30 --> URI Class Initialized
INFO - 2018-01-20 13:33:30 --> Router Class Initialized
INFO - 2018-01-20 13:33:30 --> Output Class Initialized
INFO - 2018-01-20 13:33:30 --> Security Class Initialized
DEBUG - 2018-01-20 13:33:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-20 13:33:30 --> Input Class Initialized
INFO - 2018-01-20 13:33:30 --> Language Class Initialized
INFO - 2018-01-20 13:33:30 --> Loader Class Initialized
INFO - 2018-01-20 13:33:30 --> Helper loaded: url_helper
INFO - 2018-01-20 13:33:30 --> Helper loaded: form_helper
INFO - 2018-01-20 13:33:30 --> Database Driver Class Initialized
DEBUG - 2018-01-20 13:33:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-20 13:33:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-20 13:33:30 --> Form Validation Class Initialized
INFO - 2018-01-20 13:33:30 --> Model Class Initialized
INFO - 2018-01-20 13:33:30 --> Controller Class Initialized
INFO - 2018-01-20 13:33:30 --> Model Class Initialized
DEBUG - 2018-01-20 13:33:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-20 13:33:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-01-20 13:33:30 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-20 13:33:30 --> Final output sent to browser
DEBUG - 2018-01-20 13:33:30 --> Total execution time: 0.3895
INFO - 2018-01-20 13:35:22 --> Config Class Initialized
INFO - 2018-01-20 13:35:22 --> Hooks Class Initialized
DEBUG - 2018-01-20 13:35:22 --> UTF-8 Support Enabled
INFO - 2018-01-20 13:35:22 --> Utf8 Class Initialized
INFO - 2018-01-20 13:35:22 --> URI Class Initialized
INFO - 2018-01-20 13:35:22 --> Router Class Initialized
INFO - 2018-01-20 13:35:22 --> Output Class Initialized
INFO - 2018-01-20 13:35:22 --> Security Class Initialized
DEBUG - 2018-01-20 13:35:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-20 13:35:22 --> Input Class Initialized
INFO - 2018-01-20 13:35:22 --> Language Class Initialized
INFO - 2018-01-20 13:35:22 --> Loader Class Initialized
INFO - 2018-01-20 13:35:22 --> Helper loaded: url_helper
INFO - 2018-01-20 13:35:22 --> Helper loaded: form_helper
INFO - 2018-01-20 13:35:22 --> Database Driver Class Initialized
DEBUG - 2018-01-20 13:35:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-20 13:35:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-20 13:35:22 --> Form Validation Class Initialized
INFO - 2018-01-20 13:35:22 --> Model Class Initialized
INFO - 2018-01-20 13:35:22 --> Controller Class Initialized
INFO - 2018-01-20 13:35:22 --> Model Class Initialized
DEBUG - 2018-01-20 13:35:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-20 13:35:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-01-20 13:35:22 --> Config Class Initialized
INFO - 2018-01-20 13:35:22 --> Hooks Class Initialized
DEBUG - 2018-01-20 13:35:22 --> UTF-8 Support Enabled
INFO - 2018-01-20 13:35:22 --> Utf8 Class Initialized
INFO - 2018-01-20 13:35:22 --> URI Class Initialized
DEBUG - 2018-01-20 13:35:22 --> No URI present. Default controller set.
INFO - 2018-01-20 13:35:22 --> Router Class Initialized
INFO - 2018-01-20 13:35:22 --> Output Class Initialized
INFO - 2018-01-20 13:35:22 --> Security Class Initialized
DEBUG - 2018-01-20 13:35:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-20 13:35:22 --> Input Class Initialized
INFO - 2018-01-20 13:35:22 --> Language Class Initialized
INFO - 2018-01-20 13:35:22 --> Loader Class Initialized
INFO - 2018-01-20 13:35:22 --> Helper loaded: url_helper
INFO - 2018-01-20 13:35:22 --> Helper loaded: form_helper
INFO - 2018-01-20 13:35:22 --> Database Driver Class Initialized
DEBUG - 2018-01-20 13:35:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-20 13:35:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-20 13:35:22 --> Form Validation Class Initialized
INFO - 2018-01-20 13:35:22 --> Model Class Initialized
INFO - 2018-01-20 13:35:22 --> Controller Class Initialized
INFO - 2018-01-20 13:35:22 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-20 13:35:22 --> Final output sent to browser
DEBUG - 2018-01-20 13:35:22 --> Total execution time: 0.0343
INFO - 2018-01-20 13:35:31 --> Config Class Initialized
INFO - 2018-01-20 13:35:31 --> Hooks Class Initialized
DEBUG - 2018-01-20 13:35:31 --> UTF-8 Support Enabled
INFO - 2018-01-20 13:35:31 --> Utf8 Class Initialized
INFO - 2018-01-20 13:35:31 --> URI Class Initialized
INFO - 2018-01-20 13:35:31 --> Router Class Initialized
INFO - 2018-01-20 13:35:31 --> Output Class Initialized
INFO - 2018-01-20 13:35:31 --> Security Class Initialized
DEBUG - 2018-01-20 13:35:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-20 13:35:31 --> Input Class Initialized
INFO - 2018-01-20 13:35:31 --> Language Class Initialized
INFO - 2018-01-20 13:35:31 --> Loader Class Initialized
INFO - 2018-01-20 13:35:31 --> Helper loaded: url_helper
INFO - 2018-01-20 13:35:31 --> Helper loaded: form_helper
INFO - 2018-01-20 13:35:31 --> Database Driver Class Initialized
DEBUG - 2018-01-20 13:35:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-20 13:35:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-20 13:35:31 --> Form Validation Class Initialized
INFO - 2018-01-20 13:35:31 --> Model Class Initialized
INFO - 2018-01-20 13:35:31 --> Controller Class Initialized
INFO - 2018-01-20 13:35:31 --> Model Class Initialized
INFO - 2018-01-20 13:35:31 --> Model Class Initialized
INFO - 2018-01-20 13:35:31 --> Model Class Initialized
INFO - 2018-01-20 13:35:31 --> Model Class Initialized
DEBUG - 2018-01-20 13:35:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-20 13:35:31 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-20 13:35:31 --> Final output sent to browser
DEBUG - 2018-01-20 13:35:31 --> Total execution time: 0.0503
INFO - 2018-01-20 13:35:33 --> Config Class Initialized
INFO - 2018-01-20 13:35:33 --> Hooks Class Initialized
DEBUG - 2018-01-20 13:35:33 --> UTF-8 Support Enabled
INFO - 2018-01-20 13:35:33 --> Utf8 Class Initialized
INFO - 2018-01-20 13:35:33 --> URI Class Initialized
INFO - 2018-01-20 13:35:33 --> Router Class Initialized
INFO - 2018-01-20 13:35:33 --> Output Class Initialized
INFO - 2018-01-20 13:35:33 --> Security Class Initialized
DEBUG - 2018-01-20 13:35:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-20 13:35:33 --> Input Class Initialized
INFO - 2018-01-20 13:35:33 --> Language Class Initialized
INFO - 2018-01-20 13:35:33 --> Loader Class Initialized
INFO - 2018-01-20 13:35:33 --> Helper loaded: url_helper
INFO - 2018-01-20 13:35:33 --> Helper loaded: form_helper
INFO - 2018-01-20 13:35:33 --> Database Driver Class Initialized
DEBUG - 2018-01-20 13:35:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-20 13:35:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-20 13:35:33 --> Form Validation Class Initialized
INFO - 2018-01-20 13:35:33 --> Model Class Initialized
INFO - 2018-01-20 13:35:33 --> Controller Class Initialized
INFO - 2018-01-20 13:35:33 --> Model Class Initialized
INFO - 2018-01-20 13:35:33 --> Model Class Initialized
INFO - 2018-01-20 13:35:33 --> Model Class Initialized
INFO - 2018-01-20 13:35:33 --> Model Class Initialized
DEBUG - 2018-01-20 13:35:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-20 13:35:35 --> Config Class Initialized
INFO - 2018-01-20 13:35:35 --> Hooks Class Initialized
DEBUG - 2018-01-20 13:35:35 --> UTF-8 Support Enabled
INFO - 2018-01-20 13:35:35 --> Utf8 Class Initialized
INFO - 2018-01-20 13:35:35 --> URI Class Initialized
INFO - 2018-01-20 13:35:35 --> Router Class Initialized
INFO - 2018-01-20 13:35:35 --> Output Class Initialized
INFO - 2018-01-20 13:35:35 --> Security Class Initialized
DEBUG - 2018-01-20 13:35:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-20 13:35:35 --> Input Class Initialized
INFO - 2018-01-20 13:35:35 --> Language Class Initialized
INFO - 2018-01-20 13:35:35 --> Loader Class Initialized
INFO - 2018-01-20 13:35:35 --> Helper loaded: url_helper
INFO - 2018-01-20 13:35:35 --> Helper loaded: form_helper
INFO - 2018-01-20 13:35:35 --> Database Driver Class Initialized
DEBUG - 2018-01-20 13:35:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-20 13:35:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-20 13:35:35 --> Form Validation Class Initialized
INFO - 2018-01-20 13:35:35 --> Model Class Initialized
INFO - 2018-01-20 13:35:35 --> Controller Class Initialized
INFO - 2018-01-20 13:35:35 --> Model Class Initialized
INFO - 2018-01-20 13:35:35 --> Model Class Initialized
INFO - 2018-01-20 13:35:35 --> Model Class Initialized
INFO - 2018-01-20 13:35:35 --> Model Class Initialized
DEBUG - 2018-01-20 13:35:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-20 13:35:35 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-20 13:35:35 --> Final output sent to browser
DEBUG - 2018-01-20 13:35:35 --> Total execution time: 0.0863
INFO - 2018-01-20 13:35:36 --> Config Class Initialized
INFO - 2018-01-20 13:35:36 --> Hooks Class Initialized
DEBUG - 2018-01-20 13:35:36 --> UTF-8 Support Enabled
INFO - 2018-01-20 13:35:36 --> Utf8 Class Initialized
INFO - 2018-01-20 13:35:36 --> URI Class Initialized
INFO - 2018-01-20 13:35:36 --> Router Class Initialized
INFO - 2018-01-20 13:35:36 --> Output Class Initialized
INFO - 2018-01-20 13:35:36 --> Security Class Initialized
DEBUG - 2018-01-20 13:35:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-20 13:35:36 --> Input Class Initialized
INFO - 2018-01-20 13:35:36 --> Language Class Initialized
INFO - 2018-01-20 13:35:36 --> Loader Class Initialized
INFO - 2018-01-20 13:35:36 --> Helper loaded: url_helper
INFO - 2018-01-20 13:35:36 --> Helper loaded: form_helper
INFO - 2018-01-20 13:35:36 --> Database Driver Class Initialized
DEBUG - 2018-01-20 13:35:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-20 13:35:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-20 13:35:36 --> Form Validation Class Initialized
INFO - 2018-01-20 13:35:36 --> Model Class Initialized
INFO - 2018-01-20 13:35:36 --> Controller Class Initialized
INFO - 2018-01-20 13:35:36 --> Model Class Initialized
INFO - 2018-01-20 13:35:36 --> Model Class Initialized
INFO - 2018-01-20 13:35:36 --> Model Class Initialized
INFO - 2018-01-20 13:35:36 --> Model Class Initialized
DEBUG - 2018-01-20 13:35:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-20 13:36:07 --> Config Class Initialized
INFO - 2018-01-20 13:36:07 --> Hooks Class Initialized
DEBUG - 2018-01-20 13:36:07 --> UTF-8 Support Enabled
INFO - 2018-01-20 13:36:07 --> Utf8 Class Initialized
INFO - 2018-01-20 13:36:07 --> URI Class Initialized
INFO - 2018-01-20 13:36:07 --> Router Class Initialized
INFO - 2018-01-20 13:36:07 --> Output Class Initialized
INFO - 2018-01-20 13:36:07 --> Security Class Initialized
DEBUG - 2018-01-20 13:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-20 13:36:07 --> Input Class Initialized
INFO - 2018-01-20 13:36:07 --> Language Class Initialized
INFO - 2018-01-20 13:36:07 --> Loader Class Initialized
INFO - 2018-01-20 13:36:07 --> Helper loaded: url_helper
INFO - 2018-01-20 13:36:07 --> Helper loaded: form_helper
INFO - 2018-01-20 13:36:07 --> Database Driver Class Initialized
DEBUG - 2018-01-20 13:36:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-20 13:36:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-20 13:36:07 --> Form Validation Class Initialized
INFO - 2018-01-20 13:36:07 --> Model Class Initialized
INFO - 2018-01-20 13:36:07 --> Controller Class Initialized
INFO - 2018-01-20 13:36:07 --> Model Class Initialized
INFO - 2018-01-20 13:36:07 --> Model Class Initialized
INFO - 2018-01-20 13:36:07 --> Model Class Initialized
INFO - 2018-01-20 13:36:07 --> Model Class Initialized
DEBUG - 2018-01-20 13:36:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-20 13:36:07 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-20 13:36:07 --> Final output sent to browser
DEBUG - 2018-01-20 13:36:07 --> Total execution time: 0.0567
INFO - 2018-01-20 13:36:08 --> Config Class Initialized
INFO - 2018-01-20 13:36:08 --> Hooks Class Initialized
DEBUG - 2018-01-20 13:36:08 --> UTF-8 Support Enabled
INFO - 2018-01-20 13:36:08 --> Utf8 Class Initialized
INFO - 2018-01-20 13:36:08 --> URI Class Initialized
INFO - 2018-01-20 13:36:08 --> Router Class Initialized
INFO - 2018-01-20 13:36:08 --> Output Class Initialized
INFO - 2018-01-20 13:36:08 --> Security Class Initialized
DEBUG - 2018-01-20 13:36:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-20 13:36:08 --> Input Class Initialized
INFO - 2018-01-20 13:36:08 --> Language Class Initialized
INFO - 2018-01-20 13:36:08 --> Loader Class Initialized
INFO - 2018-01-20 13:36:08 --> Helper loaded: url_helper
INFO - 2018-01-20 13:36:08 --> Helper loaded: form_helper
INFO - 2018-01-20 13:36:08 --> Database Driver Class Initialized
DEBUG - 2018-01-20 13:36:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-20 13:36:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-20 13:36:08 --> Form Validation Class Initialized
INFO - 2018-01-20 13:36:08 --> Model Class Initialized
INFO - 2018-01-20 13:36:08 --> Controller Class Initialized
INFO - 2018-01-20 13:36:08 --> Model Class Initialized
INFO - 2018-01-20 13:36:08 --> Model Class Initialized
INFO - 2018-01-20 13:36:08 --> Model Class Initialized
INFO - 2018-01-20 13:36:08 --> Model Class Initialized
DEBUG - 2018-01-20 13:36:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-20 13:36:25 --> Config Class Initialized
INFO - 2018-01-20 13:36:25 --> Hooks Class Initialized
DEBUG - 2018-01-20 13:36:25 --> UTF-8 Support Enabled
INFO - 2018-01-20 13:36:25 --> Utf8 Class Initialized
INFO - 2018-01-20 13:36:25 --> URI Class Initialized
INFO - 2018-01-20 13:36:25 --> Router Class Initialized
INFO - 2018-01-20 13:36:25 --> Output Class Initialized
INFO - 2018-01-20 13:36:25 --> Security Class Initialized
DEBUG - 2018-01-20 13:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-20 13:36:25 --> Input Class Initialized
INFO - 2018-01-20 13:36:25 --> Language Class Initialized
INFO - 2018-01-20 13:36:25 --> Loader Class Initialized
INFO - 2018-01-20 13:36:25 --> Helper loaded: url_helper
INFO - 2018-01-20 13:36:25 --> Helper loaded: form_helper
INFO - 2018-01-20 13:36:25 --> Database Driver Class Initialized
DEBUG - 2018-01-20 13:36:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-20 13:36:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-20 13:36:25 --> Form Validation Class Initialized
INFO - 2018-01-20 13:36:25 --> Model Class Initialized
INFO - 2018-01-20 13:36:25 --> Controller Class Initialized
INFO - 2018-01-20 13:36:25 --> Model Class Initialized
INFO - 2018-01-20 13:36:25 --> Model Class Initialized
INFO - 2018-01-20 13:36:25 --> Model Class Initialized
INFO - 2018-01-20 13:36:25 --> Model Class Initialized
DEBUG - 2018-01-20 13:36:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-20 13:36:25 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-20 13:36:25 --> Final output sent to browser
DEBUG - 2018-01-20 13:36:25 --> Total execution time: 0.0566
INFO - 2018-01-20 13:37:15 --> Config Class Initialized
INFO - 2018-01-20 13:37:15 --> Hooks Class Initialized
DEBUG - 2018-01-20 13:37:15 --> UTF-8 Support Enabled
INFO - 2018-01-20 13:37:15 --> Utf8 Class Initialized
INFO - 2018-01-20 13:37:15 --> URI Class Initialized
INFO - 2018-01-20 13:37:15 --> Router Class Initialized
INFO - 2018-01-20 13:37:15 --> Output Class Initialized
INFO - 2018-01-20 13:37:15 --> Security Class Initialized
DEBUG - 2018-01-20 13:37:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-20 13:37:15 --> Input Class Initialized
INFO - 2018-01-20 13:37:15 --> Language Class Initialized
INFO - 2018-01-20 13:37:15 --> Loader Class Initialized
INFO - 2018-01-20 13:37:15 --> Helper loaded: url_helper
INFO - 2018-01-20 13:37:15 --> Helper loaded: form_helper
INFO - 2018-01-20 13:37:15 --> Database Driver Class Initialized
DEBUG - 2018-01-20 13:37:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-20 13:37:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-20 13:37:15 --> Form Validation Class Initialized
INFO - 2018-01-20 13:37:15 --> Model Class Initialized
INFO - 2018-01-20 13:37:15 --> Controller Class Initialized
INFO - 2018-01-20 13:37:15 --> Model Class Initialized
INFO - 2018-01-20 13:37:15 --> Model Class Initialized
INFO - 2018-01-20 13:37:15 --> Model Class Initialized
INFO - 2018-01-20 13:37:15 --> Model Class Initialized
DEBUG - 2018-01-20 13:37:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-20 13:37:16 --> Config Class Initialized
INFO - 2018-01-20 13:37:16 --> Hooks Class Initialized
DEBUG - 2018-01-20 13:37:16 --> UTF-8 Support Enabled
INFO - 2018-01-20 13:37:16 --> Utf8 Class Initialized
INFO - 2018-01-20 13:37:16 --> URI Class Initialized
INFO - 2018-01-20 13:37:16 --> Router Class Initialized
INFO - 2018-01-20 13:37:16 --> Output Class Initialized
INFO - 2018-01-20 13:37:16 --> Security Class Initialized
DEBUG - 2018-01-20 13:37:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-20 13:37:16 --> Input Class Initialized
INFO - 2018-01-20 13:37:16 --> Language Class Initialized
INFO - 2018-01-20 13:37:16 --> Loader Class Initialized
INFO - 2018-01-20 13:37:16 --> Helper loaded: url_helper
INFO - 2018-01-20 13:37:16 --> Helper loaded: form_helper
INFO - 2018-01-20 13:37:16 --> Database Driver Class Initialized
DEBUG - 2018-01-20 13:37:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-20 13:37:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-20 13:37:16 --> Form Validation Class Initialized
INFO - 2018-01-20 13:37:16 --> Model Class Initialized
INFO - 2018-01-20 13:37:16 --> Controller Class Initialized
INFO - 2018-01-20 13:37:16 --> Model Class Initialized
INFO - 2018-01-20 13:37:16 --> Model Class Initialized
INFO - 2018-01-20 13:37:16 --> Model Class Initialized
INFO - 2018-01-20 13:37:16 --> Model Class Initialized
DEBUG - 2018-01-20 13:37:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-20 13:37:16 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-20 13:37:16 --> Final output sent to browser
DEBUG - 2018-01-20 13:37:16 --> Total execution time: 0.0549
INFO - 2018-01-20 13:37:17 --> Config Class Initialized
INFO - 2018-01-20 13:37:17 --> Hooks Class Initialized
DEBUG - 2018-01-20 13:37:17 --> UTF-8 Support Enabled
INFO - 2018-01-20 13:37:17 --> Utf8 Class Initialized
INFO - 2018-01-20 13:37:17 --> URI Class Initialized
INFO - 2018-01-20 13:37:17 --> Router Class Initialized
INFO - 2018-01-20 13:37:17 --> Output Class Initialized
INFO - 2018-01-20 13:37:17 --> Security Class Initialized
DEBUG - 2018-01-20 13:37:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-20 13:37:17 --> Input Class Initialized
INFO - 2018-01-20 13:37:17 --> Language Class Initialized
INFO - 2018-01-20 13:37:17 --> Loader Class Initialized
INFO - 2018-01-20 13:37:17 --> Helper loaded: url_helper
INFO - 2018-01-20 13:37:17 --> Helper loaded: form_helper
INFO - 2018-01-20 13:37:17 --> Database Driver Class Initialized
DEBUG - 2018-01-20 13:37:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-20 13:37:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-20 13:37:17 --> Form Validation Class Initialized
INFO - 2018-01-20 13:37:17 --> Model Class Initialized
INFO - 2018-01-20 13:37:17 --> Controller Class Initialized
INFO - 2018-01-20 13:37:17 --> Model Class Initialized
INFO - 2018-01-20 13:37:17 --> Model Class Initialized
INFO - 2018-01-20 13:37:17 --> Model Class Initialized
INFO - 2018-01-20 13:37:17 --> Model Class Initialized
DEBUG - 2018-01-20 13:37:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-20 13:37:37 --> Config Class Initialized
INFO - 2018-01-20 13:37:37 --> Hooks Class Initialized
DEBUG - 2018-01-20 13:37:37 --> UTF-8 Support Enabled
INFO - 2018-01-20 13:37:37 --> Utf8 Class Initialized
INFO - 2018-01-20 13:37:37 --> URI Class Initialized
INFO - 2018-01-20 13:37:37 --> Router Class Initialized
INFO - 2018-01-20 13:37:37 --> Output Class Initialized
INFO - 2018-01-20 13:37:37 --> Security Class Initialized
DEBUG - 2018-01-20 13:37:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-20 13:37:37 --> Input Class Initialized
INFO - 2018-01-20 13:37:37 --> Language Class Initialized
INFO - 2018-01-20 13:37:37 --> Loader Class Initialized
INFO - 2018-01-20 13:37:37 --> Helper loaded: url_helper
INFO - 2018-01-20 13:37:37 --> Helper loaded: form_helper
INFO - 2018-01-20 13:37:37 --> Database Driver Class Initialized
DEBUG - 2018-01-20 13:37:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-20 13:37:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-20 13:37:37 --> Form Validation Class Initialized
INFO - 2018-01-20 13:37:37 --> Model Class Initialized
INFO - 2018-01-20 13:37:37 --> Controller Class Initialized
INFO - 2018-01-20 13:37:37 --> Model Class Initialized
INFO - 2018-01-20 13:37:37 --> Model Class Initialized
INFO - 2018-01-20 13:37:37 --> Model Class Initialized
INFO - 2018-01-20 13:37:37 --> Model Class Initialized
DEBUG - 2018-01-20 13:37:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-20 13:37:37 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-20 13:37:37 --> Final output sent to browser
DEBUG - 2018-01-20 13:37:37 --> Total execution time: 0.0541
INFO - 2018-01-20 13:37:37 --> Config Class Initialized
INFO - 2018-01-20 13:37:37 --> Hooks Class Initialized
DEBUG - 2018-01-20 13:37:37 --> UTF-8 Support Enabled
INFO - 2018-01-20 13:37:37 --> Utf8 Class Initialized
INFO - 2018-01-20 13:37:37 --> URI Class Initialized
INFO - 2018-01-20 13:37:37 --> Router Class Initialized
INFO - 2018-01-20 13:37:37 --> Output Class Initialized
INFO - 2018-01-20 13:37:37 --> Security Class Initialized
DEBUG - 2018-01-20 13:37:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-20 13:37:37 --> Input Class Initialized
INFO - 2018-01-20 13:37:37 --> Language Class Initialized
INFO - 2018-01-20 13:37:37 --> Loader Class Initialized
INFO - 2018-01-20 13:37:37 --> Helper loaded: url_helper
INFO - 2018-01-20 13:37:37 --> Helper loaded: form_helper
INFO - 2018-01-20 13:37:37 --> Database Driver Class Initialized
DEBUG - 2018-01-20 13:37:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-20 13:37:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-20 13:37:37 --> Form Validation Class Initialized
INFO - 2018-01-20 13:37:37 --> Model Class Initialized
INFO - 2018-01-20 13:37:37 --> Controller Class Initialized
INFO - 2018-01-20 13:37:37 --> Model Class Initialized
INFO - 2018-01-20 13:37:37 --> Model Class Initialized
INFO - 2018-01-20 13:37:37 --> Model Class Initialized
INFO - 2018-01-20 13:37:37 --> Model Class Initialized
DEBUG - 2018-01-20 13:37:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-20 13:39:02 --> Config Class Initialized
INFO - 2018-01-20 13:39:02 --> Hooks Class Initialized
DEBUG - 2018-01-20 13:39:02 --> UTF-8 Support Enabled
INFO - 2018-01-20 13:39:02 --> Utf8 Class Initialized
INFO - 2018-01-20 13:39:02 --> URI Class Initialized
INFO - 2018-01-20 13:39:02 --> Router Class Initialized
INFO - 2018-01-20 13:39:02 --> Output Class Initialized
INFO - 2018-01-20 13:39:02 --> Security Class Initialized
DEBUG - 2018-01-20 13:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-20 13:39:02 --> Input Class Initialized
INFO - 2018-01-20 13:39:02 --> Language Class Initialized
INFO - 2018-01-20 13:39:02 --> Loader Class Initialized
INFO - 2018-01-20 13:39:02 --> Helper loaded: url_helper
INFO - 2018-01-20 13:39:02 --> Helper loaded: form_helper
INFO - 2018-01-20 13:39:02 --> Database Driver Class Initialized
DEBUG - 2018-01-20 13:39:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-20 13:39:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-20 13:39:02 --> Form Validation Class Initialized
INFO - 2018-01-20 13:39:02 --> Model Class Initialized
INFO - 2018-01-20 13:39:02 --> Controller Class Initialized
INFO - 2018-01-20 13:39:02 --> Model Class Initialized
INFO - 2018-01-20 13:39:02 --> Model Class Initialized
INFO - 2018-01-20 13:39:02 --> Model Class Initialized
INFO - 2018-01-20 13:39:02 --> Model Class Initialized
DEBUG - 2018-01-20 13:39:02 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-01-20 13:39:02 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/instateccr/public_html/controlcostos/vendor/phpoffice/phpspreadsheet/src/PhpSpreadsheet/Calculation/Calculation.php:3030) /home/instateccr/public_html/controlcostos/instatec_sys/core/Common.php 564
ERROR - 2018-01-20 13:39:02 --> Severity: Parsing Error --> syntax error, unexpected '.', expecting '&' or variable (T_VARIABLE) /home/instateccr/public_html/controlcostos/vendor/phpoffice/phpspreadsheet/src/PhpSpreadsheet/Calculation/Calculation.php 3030
INFO - 2018-01-20 13:40:01 --> Config Class Initialized
INFO - 2018-01-20 13:40:01 --> Hooks Class Initialized
DEBUG - 2018-01-20 13:40:01 --> UTF-8 Support Enabled
INFO - 2018-01-20 13:40:01 --> Utf8 Class Initialized
INFO - 2018-01-20 13:40:01 --> URI Class Initialized
INFO - 2018-01-20 13:40:01 --> Router Class Initialized
INFO - 2018-01-20 13:40:01 --> Output Class Initialized
INFO - 2018-01-20 13:40:01 --> Security Class Initialized
DEBUG - 2018-01-20 13:40:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-20 13:40:01 --> Input Class Initialized
INFO - 2018-01-20 13:40:01 --> Language Class Initialized
INFO - 2018-01-20 13:40:01 --> Loader Class Initialized
INFO - 2018-01-20 13:40:01 --> Helper loaded: url_helper
INFO - 2018-01-20 13:40:01 --> Helper loaded: form_helper
INFO - 2018-01-20 13:40:01 --> Database Driver Class Initialized
DEBUG - 2018-01-20 13:40:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-20 13:40:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-20 13:40:01 --> Form Validation Class Initialized
INFO - 2018-01-20 13:40:01 --> Model Class Initialized
INFO - 2018-01-20 13:40:01 --> Controller Class Initialized
INFO - 2018-01-20 13:40:01 --> Model Class Initialized
INFO - 2018-01-20 13:40:01 --> Model Class Initialized
INFO - 2018-01-20 13:40:01 --> Model Class Initialized
INFO - 2018-01-20 13:40:01 --> Model Class Initialized
DEBUG - 2018-01-20 13:40:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-20 13:40:01 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-20 13:40:01 --> Final output sent to browser
DEBUG - 2018-01-20 13:40:01 --> Total execution time: 0.0675
INFO - 2018-01-20 13:40:01 --> Config Class Initialized
INFO - 2018-01-20 13:40:01 --> Hooks Class Initialized
DEBUG - 2018-01-20 13:40:01 --> UTF-8 Support Enabled
INFO - 2018-01-20 13:40:01 --> Utf8 Class Initialized
INFO - 2018-01-20 13:40:01 --> URI Class Initialized
INFO - 2018-01-20 13:40:01 --> Router Class Initialized
INFO - 2018-01-20 13:40:01 --> Output Class Initialized
INFO - 2018-01-20 13:40:01 --> Security Class Initialized
DEBUG - 2018-01-20 13:40:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-20 13:40:01 --> Input Class Initialized
INFO - 2018-01-20 13:40:01 --> Language Class Initialized
INFO - 2018-01-20 13:40:01 --> Loader Class Initialized
INFO - 2018-01-20 13:40:01 --> Helper loaded: url_helper
INFO - 2018-01-20 13:40:01 --> Helper loaded: form_helper
INFO - 2018-01-20 13:40:02 --> Database Driver Class Initialized
DEBUG - 2018-01-20 13:40:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-20 13:40:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-20 13:40:02 --> Form Validation Class Initialized
INFO - 2018-01-20 13:40:02 --> Model Class Initialized
INFO - 2018-01-20 13:40:02 --> Controller Class Initialized
INFO - 2018-01-20 13:40:02 --> Model Class Initialized
INFO - 2018-01-20 13:40:02 --> Model Class Initialized
INFO - 2018-01-20 13:40:02 --> Model Class Initialized
INFO - 2018-01-20 13:40:02 --> Model Class Initialized
DEBUG - 2018-01-20 13:40:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-20 20:52:10 --> Config Class Initialized
INFO - 2018-01-20 20:52:10 --> Hooks Class Initialized
DEBUG - 2018-01-20 20:52:10 --> UTF-8 Support Enabled
INFO - 2018-01-20 20:52:10 --> Utf8 Class Initialized
INFO - 2018-01-20 20:52:10 --> URI Class Initialized
INFO - 2018-01-20 20:52:10 --> Router Class Initialized
INFO - 2018-01-20 20:52:10 --> Output Class Initialized
INFO - 2018-01-20 20:52:10 --> Security Class Initialized
DEBUG - 2018-01-20 20:52:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-20 20:52:10 --> Input Class Initialized
INFO - 2018-01-20 20:52:10 --> Language Class Initialized
INFO - 2018-01-20 20:52:10 --> Loader Class Initialized
INFO - 2018-01-20 20:52:10 --> Helper loaded: url_helper
INFO - 2018-01-20 20:52:10 --> Helper loaded: form_helper
INFO - 2018-01-20 20:52:11 --> Database Driver Class Initialized
DEBUG - 2018-01-20 20:52:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-20 20:52:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-20 20:52:11 --> Form Validation Class Initialized
INFO - 2018-01-20 20:52:11 --> Model Class Initialized
INFO - 2018-01-20 20:52:11 --> Controller Class Initialized
INFO - 2018-01-20 20:52:11 --> Model Class Initialized
INFO - 2018-01-20 20:52:11 --> Model Class Initialized
INFO - 2018-01-20 20:52:11 --> Model Class Initialized
INFO - 2018-01-20 20:52:11 --> Model Class Initialized
DEBUG - 2018-01-20 20:52:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-20 20:52:12 --> Config Class Initialized
INFO - 2018-01-20 20:52:12 --> Hooks Class Initialized
DEBUG - 2018-01-20 20:52:12 --> UTF-8 Support Enabled
INFO - 2018-01-20 20:52:12 --> Utf8 Class Initialized
INFO - 2018-01-20 20:52:12 --> URI Class Initialized
INFO - 2018-01-20 20:52:12 --> Router Class Initialized
INFO - 2018-01-20 20:52:12 --> Output Class Initialized
INFO - 2018-01-20 20:52:12 --> Security Class Initialized
DEBUG - 2018-01-20 20:52:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-20 20:52:12 --> Input Class Initialized
INFO - 2018-01-20 20:52:12 --> Language Class Initialized
INFO - 2018-01-20 20:52:12 --> Loader Class Initialized
INFO - 2018-01-20 20:52:12 --> Helper loaded: url_helper
INFO - 2018-01-20 20:52:12 --> Helper loaded: form_helper
INFO - 2018-01-20 20:52:12 --> Database Driver Class Initialized
DEBUG - 2018-01-20 20:52:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-20 20:52:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-20 20:52:12 --> Form Validation Class Initialized
INFO - 2018-01-20 20:52:12 --> Model Class Initialized
INFO - 2018-01-20 20:52:12 --> Controller Class Initialized
INFO - 2018-01-20 20:52:12 --> Model Class Initialized
DEBUG - 2018-01-20 20:52:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-20 20:52:12 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-20 20:52:12 --> Final output sent to browser
DEBUG - 2018-01-20 20:52:12 --> Total execution time: 0.0390
INFO - 2018-01-20 20:52:20 --> Config Class Initialized
INFO - 2018-01-20 20:52:20 --> Hooks Class Initialized
DEBUG - 2018-01-20 20:52:20 --> UTF-8 Support Enabled
INFO - 2018-01-20 20:52:20 --> Utf8 Class Initialized
INFO - 2018-01-20 20:52:20 --> URI Class Initialized
INFO - 2018-01-20 20:52:20 --> Router Class Initialized
INFO - 2018-01-20 20:52:20 --> Output Class Initialized
INFO - 2018-01-20 20:52:20 --> Security Class Initialized
DEBUG - 2018-01-20 20:52:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-20 20:52:20 --> Input Class Initialized
INFO - 2018-01-20 20:52:20 --> Language Class Initialized
INFO - 2018-01-20 20:52:20 --> Loader Class Initialized
INFO - 2018-01-20 20:52:20 --> Helper loaded: url_helper
INFO - 2018-01-20 20:52:20 --> Helper loaded: form_helper
INFO - 2018-01-20 20:52:20 --> Database Driver Class Initialized
DEBUG - 2018-01-20 20:52:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-20 20:52:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-20 20:52:20 --> Form Validation Class Initialized
INFO - 2018-01-20 20:52:20 --> Model Class Initialized
INFO - 2018-01-20 20:52:20 --> Controller Class Initialized
INFO - 2018-01-20 20:52:20 --> Model Class Initialized
INFO - 2018-01-20 20:52:20 --> Model Class Initialized
INFO - 2018-01-20 20:52:20 --> Model Class Initialized
INFO - 2018-01-20 20:52:20 --> Model Class Initialized
DEBUG - 2018-01-20 20:52:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-20 20:52:21 --> Config Class Initialized
INFO - 2018-01-20 20:52:21 --> Hooks Class Initialized
DEBUG - 2018-01-20 20:52:21 --> UTF-8 Support Enabled
INFO - 2018-01-20 20:52:21 --> Utf8 Class Initialized
INFO - 2018-01-20 20:52:21 --> URI Class Initialized
INFO - 2018-01-20 20:52:21 --> Router Class Initialized
INFO - 2018-01-20 20:52:21 --> Output Class Initialized
INFO - 2018-01-20 20:52:21 --> Security Class Initialized
DEBUG - 2018-01-20 20:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-20 20:52:21 --> Input Class Initialized
INFO - 2018-01-20 20:52:21 --> Language Class Initialized
INFO - 2018-01-20 20:52:21 --> Loader Class Initialized
INFO - 2018-01-20 20:52:21 --> Helper loaded: url_helper
INFO - 2018-01-20 20:52:21 --> Helper loaded: form_helper
INFO - 2018-01-20 20:52:21 --> Database Driver Class Initialized
DEBUG - 2018-01-20 20:52:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-20 20:52:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-20 20:52:21 --> Form Validation Class Initialized
INFO - 2018-01-20 20:52:21 --> Model Class Initialized
INFO - 2018-01-20 20:52:21 --> Controller Class Initialized
INFO - 2018-01-20 20:52:21 --> Model Class Initialized
DEBUG - 2018-01-20 20:52:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-20 20:52:21 --> File loaded: /home/instateccr/public_html/controlcostos/instatec_app/views/index.php
INFO - 2018-01-20 20:52:21 --> Final output sent to browser
DEBUG - 2018-01-20 20:52:21 --> Total execution time: 0.0353
