<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-03-09 00:19:23 --> Config Class Initialized
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-03-09 00:19:23 --> Config Class Initialized
INFO - 2018-03-09 00:19:23 --> Hooks Class Initialized
INFO - 2018-03-09 00:19:23 --> Config Class Initialized
INFO - 2018-03-09 00:19:23 --> Hooks Class Initialized
INFO - 2018-03-09 00:19:23 --> Hooks Class Initialized
INFO - 2018-03-09 00:19:23 --> Config Class Initialized
INFO - 2018-03-09 00:19:23 --> Hooks Class Initialized
DEBUG - 2018-03-09 00:19:23 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 00:19:23 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 00:19:23 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 00:19:23 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:19:23 --> Utf8 Class Initialized
INFO - 2018-03-09 00:19:23 --> Utf8 Class Initialized
INFO - 2018-03-09 00:19:23 --> Utf8 Class Initialized
INFO - 2018-03-09 00:19:23 --> Utf8 Class Initialized
INFO - 2018-03-09 00:19:23 --> URI Class Initialized
INFO - 2018-03-09 00:19:23 --> URI Class Initialized
INFO - 2018-03-09 00:19:23 --> URI Class Initialized
INFO - 2018-03-09 00:19:23 --> URI Class Initialized
INFO - 2018-03-09 00:19:23 --> Router Class Initialized
INFO - 2018-03-09 00:19:23 --> Router Class Initialized
INFO - 2018-03-09 00:19:23 --> Router Class Initialized
INFO - 2018-03-09 00:19:23 --> Output Class Initialized
INFO - 2018-03-09 00:19:23 --> Output Class Initialized
INFO - 2018-03-09 00:19:23 --> Output Class Initialized
INFO - 2018-03-09 00:19:23 --> Security Class Initialized
INFO - 2018-03-09 00:19:23 --> Security Class Initialized
INFO - 2018-03-09 00:19:23 --> Security Class Initialized
INFO - 2018-03-09 00:19:23 --> Router Class Initialized
DEBUG - 2018-03-09 00:19:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 00:19:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:19:23 --> Input Class Initialized
DEBUG - 2018-03-09 00:19:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:19:23 --> Input Class Initialized
INFO - 2018-03-09 00:19:23 --> Input Class Initialized
INFO - 2018-03-09 00:19:23 --> Language Class Initialized
INFO - 2018-03-09 00:19:23 --> Output Class Initialized
INFO - 2018-03-09 00:19:23 --> Language Class Initialized
INFO - 2018-03-09 00:19:23 --> Language Class Initialized
ERROR - 2018-03-09 00:19:23 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-09 00:19:23 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-09 00:19:23 --> Security Class Initialized
ERROR - 2018-03-09 00:19:23 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-09 00:19:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:19:23 --> Input Class Initialized
INFO - 2018-03-09 00:19:23 --> Language Class Initialized
ERROR - 2018-03-09 00:19:23 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-09 00:19:23 --> Config Class Initialized
INFO - 2018-03-09 00:19:23 --> Hooks Class Initialized
INFO - 2018-03-09 00:19:23 --> Config Class Initialized
INFO - 2018-03-09 00:19:23 --> Config Class Initialized
INFO - 2018-03-09 00:19:23 --> Hooks Class Initialized
DEBUG - 2018-03-09 00:19:23 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:19:23 --> Hooks Class Initialized
INFO - 2018-03-09 00:19:23 --> Utf8 Class Initialized
INFO - 2018-03-09 00:19:23 --> URI Class Initialized
DEBUG - 2018-03-09 00:19:23 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 00:19:23 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:19:23 --> Utf8 Class Initialized
INFO - 2018-03-09 00:19:23 --> Router Class Initialized
INFO - 2018-03-09 00:19:23 --> Utf8 Class Initialized
INFO - 2018-03-09 00:19:23 --> URI Class Initialized
INFO - 2018-03-09 00:19:23 --> Output Class Initialized
INFO - 2018-03-09 00:19:23 --> Router Class Initialized
INFO - 2018-03-09 00:19:23 --> URI Class Initialized
INFO - 2018-03-09 00:19:23 --> Output Class Initialized
INFO - 2018-03-09 00:19:23 --> Security Class Initialized
INFO - 2018-03-09 00:19:23 --> Router Class Initialized
INFO - 2018-03-09 00:19:23 --> Security Class Initialized
DEBUG - 2018-03-09 00:19:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:19:23 --> Input Class Initialized
INFO - 2018-03-09 00:19:23 --> Output Class Initialized
DEBUG - 2018-03-09 00:19:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:19:23 --> Input Class Initialized
INFO - 2018-03-09 00:19:23 --> Language Class Initialized
INFO - 2018-03-09 00:19:23 --> Security Class Initialized
INFO - 2018-03-09 00:19:23 --> Language Class Initialized
ERROR - 2018-03-09 00:19:23 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-03-09 00:19:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-03-09 00:19:23 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-09 00:19:23 --> Input Class Initialized
INFO - 2018-03-09 00:19:23 --> Language Class Initialized
ERROR - 2018-03-09 00:19:23 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-09 00:19:26 --> Config Class Initialized
INFO - 2018-03-09 00:19:26 --> Hooks Class Initialized
DEBUG - 2018-03-09 00:19:26 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:19:26 --> Utf8 Class Initialized
INFO - 2018-03-09 00:19:26 --> URI Class Initialized
INFO - 2018-03-09 00:19:26 --> Router Class Initialized
INFO - 2018-03-09 00:19:26 --> Output Class Initialized
INFO - 2018-03-09 00:19:26 --> Security Class Initialized
DEBUG - 2018-03-09 00:19:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:19:26 --> Input Class Initialized
INFO - 2018-03-09 00:19:26 --> Language Class Initialized
INFO - 2018-03-09 00:19:26 --> Loader Class Initialized
INFO - 2018-03-09 00:19:26 --> Helper loaded: url_helper
INFO - 2018-03-09 00:19:26 --> Helper loaded: form_helper
INFO - 2018-03-09 00:19:26 --> Database Driver Class Initialized
DEBUG - 2018-03-09 00:19:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-09 00:19:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 00:19:26 --> Form Validation Class Initialized
INFO - 2018-03-09 00:19:26 --> Model Class Initialized
INFO - 2018-03-09 00:19:26 --> Controller Class Initialized
INFO - 2018-03-09 00:19:26 --> Model Class Initialized
INFO - 2018-03-09 00:19:26 --> Model Class Initialized
INFO - 2018-03-09 00:19:26 --> Model Class Initialized
INFO - 2018-03-09 00:19:26 --> Model Class Initialized
INFO - 2018-03-09 00:19:26 --> Model Class Initialized
DEBUG - 2018-03-09 00:19:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-09 00:19:26 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-09 00:19:26 --> Final output sent to browser
DEBUG - 2018-03-09 00:19:26 --> Total execution time: 0.0587
INFO - 2018-03-09 00:19:26 --> Config Class Initialized
INFO - 2018-03-09 00:19:26 --> Hooks Class Initialized
INFO - 2018-03-09 00:19:26 --> Config Class Initialized
INFO - 2018-03-09 00:19:26 --> Config Class Initialized
INFO - 2018-03-09 00:19:26 --> Hooks Class Initialized
INFO - 2018-03-09 00:19:26 --> Hooks Class Initialized
DEBUG - 2018-03-09 00:19:26 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:19:26 --> Utf8 Class Initialized
DEBUG - 2018-03-09 00:19:26 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:19:26 --> Config Class Initialized
INFO - 2018-03-09 00:19:26 --> Utf8 Class Initialized
DEBUG - 2018-03-09 00:19:26 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:19:26 --> Hooks Class Initialized
INFO - 2018-03-09 00:19:26 --> Utf8 Class Initialized
INFO - 2018-03-09 00:19:26 --> URI Class Initialized
INFO - 2018-03-09 00:19:26 --> URI Class Initialized
INFO - 2018-03-09 00:19:26 --> URI Class Initialized
INFO - 2018-03-09 00:19:26 --> Router Class Initialized
INFO - 2018-03-09 00:19:26 --> Router Class Initialized
DEBUG - 2018-03-09 00:19:26 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:19:26 --> Utf8 Class Initialized
INFO - 2018-03-09 00:19:26 --> Router Class Initialized
INFO - 2018-03-09 00:19:26 --> URI Class Initialized
INFO - 2018-03-09 00:19:26 --> Output Class Initialized
INFO - 2018-03-09 00:19:26 --> Output Class Initialized
INFO - 2018-03-09 00:19:26 --> Output Class Initialized
INFO - 2018-03-09 00:19:26 --> Router Class Initialized
INFO - 2018-03-09 00:19:26 --> Security Class Initialized
INFO - 2018-03-09 00:19:26 --> Security Class Initialized
INFO - 2018-03-09 00:19:26 --> Security Class Initialized
DEBUG - 2018-03-09 00:19:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:19:26 --> Input Class Initialized
INFO - 2018-03-09 00:19:26 --> Output Class Initialized
DEBUG - 2018-03-09 00:19:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:19:26 --> Language Class Initialized
DEBUG - 2018-03-09 00:19:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:19:26 --> Input Class Initialized
INFO - 2018-03-09 00:19:26 --> Input Class Initialized
INFO - 2018-03-09 00:19:26 --> Security Class Initialized
INFO - 2018-03-09 00:19:26 --> Language Class Initialized
ERROR - 2018-03-09 00:19:26 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-09 00:19:26 --> Language Class Initialized
ERROR - 2018-03-09 00:19:26 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-09 00:19:26 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-09 00:19:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:19:26 --> Input Class Initialized
INFO - 2018-03-09 00:19:26 --> Language Class Initialized
ERROR - 2018-03-09 00:19:26 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-09 00:19:26 --> Config Class Initialized
INFO - 2018-03-09 00:19:26 --> Hooks Class Initialized
INFO - 2018-03-09 00:19:26 --> Config Class Initialized
INFO - 2018-03-09 00:19:26 --> Hooks Class Initialized
INFO - 2018-03-09 00:19:26 --> Config Class Initialized
INFO - 2018-03-09 00:19:26 --> Hooks Class Initialized
DEBUG - 2018-03-09 00:19:26 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:19:26 --> Utf8 Class Initialized
DEBUG - 2018-03-09 00:19:26 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:19:26 --> Utf8 Class Initialized
INFO - 2018-03-09 00:19:26 --> URI Class Initialized
INFO - 2018-03-09 00:19:26 --> URI Class Initialized
DEBUG - 2018-03-09 00:19:26 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:19:26 --> Utf8 Class Initialized
INFO - 2018-03-09 00:19:26 --> Router Class Initialized
INFO - 2018-03-09 00:19:26 --> URI Class Initialized
INFO - 2018-03-09 00:19:26 --> Router Class Initialized
INFO - 2018-03-09 00:19:26 --> Output Class Initialized
INFO - 2018-03-09 00:19:26 --> Router Class Initialized
INFO - 2018-03-09 00:19:26 --> Output Class Initialized
INFO - 2018-03-09 00:19:26 --> Security Class Initialized
INFO - 2018-03-09 00:19:26 --> Output Class Initialized
INFO - 2018-03-09 00:19:26 --> Security Class Initialized
DEBUG - 2018-03-09 00:19:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:19:26 --> Input Class Initialized
INFO - 2018-03-09 00:19:26 --> Security Class Initialized
INFO - 2018-03-09 00:19:26 --> Language Class Initialized
DEBUG - 2018-03-09 00:19:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:19:26 --> Input Class Initialized
DEBUG - 2018-03-09 00:19:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:19:26 --> Language Class Initialized
INFO - 2018-03-09 00:19:26 --> Input Class Initialized
ERROR - 2018-03-09 00:19:26 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-09 00:19:26 --> Language Class Initialized
ERROR - 2018-03-09 00:19:26 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-09 00:19:26 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-09 00:19:26 --> Config Class Initialized
INFO - 2018-03-09 00:19:26 --> Hooks Class Initialized
DEBUG - 2018-03-09 00:19:26 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:19:26 --> Utf8 Class Initialized
INFO - 2018-03-09 00:19:26 --> URI Class Initialized
INFO - 2018-03-09 00:19:26 --> Router Class Initialized
INFO - 2018-03-09 00:19:26 --> Output Class Initialized
INFO - 2018-03-09 00:19:26 --> Security Class Initialized
DEBUG - 2018-03-09 00:19:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:19:26 --> Input Class Initialized
INFO - 2018-03-09 00:19:26 --> Language Class Initialized
INFO - 2018-03-09 00:19:26 --> Loader Class Initialized
INFO - 2018-03-09 00:19:26 --> Helper loaded: url_helper
INFO - 2018-03-09 00:19:26 --> Helper loaded: form_helper
INFO - 2018-03-09 00:19:26 --> Database Driver Class Initialized
DEBUG - 2018-03-09 00:19:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-09 00:19:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 00:19:27 --> Form Validation Class Initialized
INFO - 2018-03-09 00:19:27 --> Model Class Initialized
INFO - 2018-03-09 00:19:27 --> Controller Class Initialized
INFO - 2018-03-09 00:19:27 --> Model Class Initialized
INFO - 2018-03-09 00:19:27 --> Model Class Initialized
INFO - 2018-03-09 00:19:27 --> Model Class Initialized
INFO - 2018-03-09 00:19:27 --> Model Class Initialized
INFO - 2018-03-09 00:19:27 --> Model Class Initialized
DEBUG - 2018-03-09 00:19:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-09 00:23:52 --> Config Class Initialized
INFO - 2018-03-09 00:23:52 --> Hooks Class Initialized
DEBUG - 2018-03-09 00:23:52 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:23:52 --> Utf8 Class Initialized
INFO - 2018-03-09 00:23:52 --> URI Class Initialized
INFO - 2018-03-09 00:23:52 --> Router Class Initialized
INFO - 2018-03-09 00:23:52 --> Output Class Initialized
INFO - 2018-03-09 00:23:52 --> Security Class Initialized
DEBUG - 2018-03-09 00:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:23:52 --> Input Class Initialized
INFO - 2018-03-09 00:23:52 --> Language Class Initialized
INFO - 2018-03-09 00:23:52 --> Loader Class Initialized
INFO - 2018-03-09 00:23:52 --> Helper loaded: url_helper
INFO - 2018-03-09 00:23:52 --> Helper loaded: form_helper
INFO - 2018-03-09 00:23:52 --> Database Driver Class Initialized
DEBUG - 2018-03-09 00:23:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-09 00:23:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 00:23:52 --> Form Validation Class Initialized
INFO - 2018-03-09 00:23:52 --> Model Class Initialized
INFO - 2018-03-09 00:23:52 --> Controller Class Initialized
INFO - 2018-03-09 00:23:52 --> Model Class Initialized
INFO - 2018-03-09 00:23:52 --> Model Class Initialized
INFO - 2018-03-09 00:23:52 --> Model Class Initialized
INFO - 2018-03-09 00:23:52 --> Model Class Initialized
INFO - 2018-03-09 00:23:52 --> Model Class Initialized
DEBUG - 2018-03-09 00:23:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-09 00:23:52 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-09 00:23:52 --> Final output sent to browser
DEBUG - 2018-03-09 00:23:52 --> Total execution time: 0.0680
INFO - 2018-03-09 00:23:53 --> Config Class Initialized
INFO - 2018-03-09 00:23:53 --> Hooks Class Initialized
DEBUG - 2018-03-09 00:23:53 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:23:53 --> Utf8 Class Initialized
INFO - 2018-03-09 00:23:53 --> URI Class Initialized
INFO - 2018-03-09 00:23:53 --> Router Class Initialized
INFO - 2018-03-09 00:23:53 --> Output Class Initialized
INFO - 2018-03-09 00:23:53 --> Security Class Initialized
DEBUG - 2018-03-09 00:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:23:53 --> Input Class Initialized
INFO - 2018-03-09 00:23:53 --> Language Class Initialized
INFO - 2018-03-09 00:23:53 --> Loader Class Initialized
INFO - 2018-03-09 00:23:53 --> Helper loaded: url_helper
INFO - 2018-03-09 00:23:53 --> Helper loaded: form_helper
INFO - 2018-03-09 00:23:53 --> Database Driver Class Initialized
DEBUG - 2018-03-09 00:23:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-09 00:23:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 00:23:53 --> Form Validation Class Initialized
INFO - 2018-03-09 00:23:53 --> Model Class Initialized
INFO - 2018-03-09 00:23:53 --> Controller Class Initialized
INFO - 2018-03-09 00:23:53 --> Model Class Initialized
INFO - 2018-03-09 00:23:53 --> Model Class Initialized
INFO - 2018-03-09 00:23:53 --> Model Class Initialized
INFO - 2018-03-09 00:23:53 --> Model Class Initialized
INFO - 2018-03-09 00:23:53 --> Model Class Initialized
DEBUG - 2018-03-09 00:23:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-09 00:23:55 --> Config Class Initialized
INFO - 2018-03-09 00:23:55 --> Hooks Class Initialized
DEBUG - 2018-03-09 00:23:55 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:23:55 --> Utf8 Class Initialized
INFO - 2018-03-09 00:23:55 --> URI Class Initialized
INFO - 2018-03-09 00:23:55 --> Router Class Initialized
INFO - 2018-03-09 00:23:55 --> Output Class Initialized
INFO - 2018-03-09 00:23:55 --> Security Class Initialized
DEBUG - 2018-03-09 00:23:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:23:55 --> Input Class Initialized
INFO - 2018-03-09 00:23:55 --> Language Class Initialized
INFO - 2018-03-09 00:23:55 --> Loader Class Initialized
INFO - 2018-03-09 00:23:55 --> Helper loaded: url_helper
INFO - 2018-03-09 00:23:55 --> Helper loaded: form_helper
INFO - 2018-03-09 00:23:55 --> Database Driver Class Initialized
DEBUG - 2018-03-09 00:23:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-09 00:23:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 00:23:55 --> Form Validation Class Initialized
INFO - 2018-03-09 00:23:55 --> Model Class Initialized
INFO - 2018-03-09 00:23:55 --> Controller Class Initialized
INFO - 2018-03-09 00:23:55 --> Model Class Initialized
INFO - 2018-03-09 00:23:55 --> Model Class Initialized
INFO - 2018-03-09 00:23:55 --> Model Class Initialized
INFO - 2018-03-09 00:23:55 --> Model Class Initialized
INFO - 2018-03-09 00:23:55 --> Model Class Initialized
DEBUG - 2018-03-09 00:23:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-09 00:23:55 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-09 00:23:55 --> Final output sent to browser
DEBUG - 2018-03-09 00:23:55 --> Total execution time: 0.0554
INFO - 2018-03-09 00:23:55 --> Config Class Initialized
INFO - 2018-03-09 00:23:55 --> Hooks Class Initialized
DEBUG - 2018-03-09 00:23:55 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:23:55 --> Utf8 Class Initialized
INFO - 2018-03-09 00:23:55 --> URI Class Initialized
INFO - 2018-03-09 00:23:55 --> Router Class Initialized
INFO - 2018-03-09 00:23:55 --> Output Class Initialized
INFO - 2018-03-09 00:23:55 --> Security Class Initialized
DEBUG - 2018-03-09 00:23:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:23:55 --> Input Class Initialized
INFO - 2018-03-09 00:23:55 --> Language Class Initialized
INFO - 2018-03-09 00:23:55 --> Loader Class Initialized
INFO - 2018-03-09 00:23:55 --> Helper loaded: url_helper
INFO - 2018-03-09 00:23:55 --> Helper loaded: form_helper
INFO - 2018-03-09 00:23:55 --> Database Driver Class Initialized
DEBUG - 2018-03-09 00:23:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-09 00:23:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 00:23:55 --> Form Validation Class Initialized
INFO - 2018-03-09 00:23:55 --> Model Class Initialized
INFO - 2018-03-09 00:23:55 --> Controller Class Initialized
INFO - 2018-03-09 00:23:55 --> Model Class Initialized
INFO - 2018-03-09 00:23:55 --> Model Class Initialized
INFO - 2018-03-09 00:23:55 --> Model Class Initialized
INFO - 2018-03-09 00:23:55 --> Model Class Initialized
INFO - 2018-03-09 00:23:55 --> Model Class Initialized
DEBUG - 2018-03-09 00:23:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-09 00:24:02 --> Config Class Initialized
INFO - 2018-03-09 00:24:02 --> Hooks Class Initialized
DEBUG - 2018-03-09 00:24:02 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:24:02 --> Utf8 Class Initialized
INFO - 2018-03-09 00:24:02 --> URI Class Initialized
INFO - 2018-03-09 00:24:02 --> Router Class Initialized
INFO - 2018-03-09 00:24:02 --> Output Class Initialized
INFO - 2018-03-09 00:24:02 --> Security Class Initialized
DEBUG - 2018-03-09 00:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:24:02 --> Input Class Initialized
INFO - 2018-03-09 00:24:02 --> Language Class Initialized
INFO - 2018-03-09 00:24:02 --> Loader Class Initialized
INFO - 2018-03-09 00:24:02 --> Helper loaded: url_helper
INFO - 2018-03-09 00:24:02 --> Helper loaded: form_helper
INFO - 2018-03-09 00:24:02 --> Database Driver Class Initialized
DEBUG - 2018-03-09 00:24:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-09 00:24:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 00:24:02 --> Form Validation Class Initialized
INFO - 2018-03-09 00:24:02 --> Model Class Initialized
INFO - 2018-03-09 00:24:02 --> Controller Class Initialized
INFO - 2018-03-09 00:24:02 --> Model Class Initialized
INFO - 2018-03-09 00:24:02 --> Model Class Initialized
INFO - 2018-03-09 00:24:02 --> Model Class Initialized
INFO - 2018-03-09 00:24:02 --> Model Class Initialized
INFO - 2018-03-09 00:24:02 --> Model Class Initialized
DEBUG - 2018-03-09 00:24:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-09 00:24:12 --> Config Class Initialized
INFO - 2018-03-09 00:24:12 --> Hooks Class Initialized
DEBUG - 2018-03-09 00:24:12 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:24:12 --> Utf8 Class Initialized
INFO - 2018-03-09 00:24:12 --> URI Class Initialized
INFO - 2018-03-09 00:24:12 --> Router Class Initialized
INFO - 2018-03-09 00:24:12 --> Output Class Initialized
INFO - 2018-03-09 00:24:12 --> Security Class Initialized
DEBUG - 2018-03-09 00:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:24:12 --> Input Class Initialized
INFO - 2018-03-09 00:24:12 --> Language Class Initialized
INFO - 2018-03-09 00:24:12 --> Loader Class Initialized
INFO - 2018-03-09 00:24:12 --> Helper loaded: url_helper
INFO - 2018-03-09 00:24:12 --> Helper loaded: form_helper
INFO - 2018-03-09 00:24:12 --> Database Driver Class Initialized
DEBUG - 2018-03-09 00:24:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-09 00:24:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 00:24:12 --> Form Validation Class Initialized
INFO - 2018-03-09 00:24:12 --> Model Class Initialized
INFO - 2018-03-09 00:24:12 --> Controller Class Initialized
INFO - 2018-03-09 00:24:12 --> Model Class Initialized
INFO - 2018-03-09 00:24:12 --> Model Class Initialized
INFO - 2018-03-09 00:24:12 --> Model Class Initialized
INFO - 2018-03-09 00:24:12 --> Model Class Initialized
INFO - 2018-03-09 00:24:12 --> Model Class Initialized
DEBUG - 2018-03-09 00:24:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-09 00:24:21 --> Config Class Initialized
INFO - 2018-03-09 00:24:21 --> Hooks Class Initialized
DEBUG - 2018-03-09 00:24:21 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:24:21 --> Utf8 Class Initialized
INFO - 2018-03-09 00:24:21 --> URI Class Initialized
INFO - 2018-03-09 00:24:21 --> Router Class Initialized
INFO - 2018-03-09 00:24:21 --> Output Class Initialized
INFO - 2018-03-09 00:24:21 --> Security Class Initialized
DEBUG - 2018-03-09 00:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:24:21 --> Input Class Initialized
INFO - 2018-03-09 00:24:21 --> Language Class Initialized
INFO - 2018-03-09 00:24:21 --> Loader Class Initialized
INFO - 2018-03-09 00:24:21 --> Helper loaded: url_helper
INFO - 2018-03-09 00:24:21 --> Helper loaded: form_helper
INFO - 2018-03-09 00:24:21 --> Database Driver Class Initialized
DEBUG - 2018-03-09 00:24:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-09 00:24:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 00:24:21 --> Form Validation Class Initialized
INFO - 2018-03-09 00:24:21 --> Model Class Initialized
INFO - 2018-03-09 00:24:21 --> Controller Class Initialized
INFO - 2018-03-09 00:24:21 --> Model Class Initialized
INFO - 2018-03-09 00:24:21 --> Model Class Initialized
INFO - 2018-03-09 00:24:21 --> Model Class Initialized
INFO - 2018-03-09 00:24:21 --> Model Class Initialized
INFO - 2018-03-09 00:24:21 --> Model Class Initialized
DEBUG - 2018-03-09 00:24:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-09 00:24:26 --> Config Class Initialized
INFO - 2018-03-09 00:24:26 --> Hooks Class Initialized
DEBUG - 2018-03-09 00:24:26 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:24:26 --> Utf8 Class Initialized
INFO - 2018-03-09 00:24:26 --> URI Class Initialized
INFO - 2018-03-09 00:24:26 --> Router Class Initialized
INFO - 2018-03-09 00:24:26 --> Output Class Initialized
INFO - 2018-03-09 00:24:26 --> Security Class Initialized
DEBUG - 2018-03-09 00:24:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:24:26 --> Input Class Initialized
INFO - 2018-03-09 00:24:26 --> Language Class Initialized
INFO - 2018-03-09 00:24:26 --> Loader Class Initialized
INFO - 2018-03-09 00:24:26 --> Helper loaded: url_helper
INFO - 2018-03-09 00:24:26 --> Helper loaded: form_helper
INFO - 2018-03-09 00:24:26 --> Database Driver Class Initialized
DEBUG - 2018-03-09 00:24:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-09 00:24:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 00:24:26 --> Form Validation Class Initialized
INFO - 2018-03-09 00:24:26 --> Model Class Initialized
INFO - 2018-03-09 00:24:26 --> Controller Class Initialized
INFO - 2018-03-09 00:24:26 --> Model Class Initialized
INFO - 2018-03-09 00:24:26 --> Model Class Initialized
INFO - 2018-03-09 00:24:26 --> Model Class Initialized
INFO - 2018-03-09 00:24:26 --> Model Class Initialized
INFO - 2018-03-09 00:24:26 --> Model Class Initialized
DEBUG - 2018-03-09 00:24:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-09 00:24:29 --> Config Class Initialized
INFO - 2018-03-09 00:24:29 --> Hooks Class Initialized
DEBUG - 2018-03-09 00:24:29 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:24:29 --> Utf8 Class Initialized
INFO - 2018-03-09 00:24:29 --> URI Class Initialized
INFO - 2018-03-09 00:24:29 --> Router Class Initialized
INFO - 2018-03-09 00:24:29 --> Output Class Initialized
INFO - 2018-03-09 00:24:29 --> Security Class Initialized
DEBUG - 2018-03-09 00:24:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:24:29 --> Input Class Initialized
INFO - 2018-03-09 00:24:29 --> Language Class Initialized
INFO - 2018-03-09 00:24:29 --> Loader Class Initialized
INFO - 2018-03-09 00:24:29 --> Helper loaded: url_helper
INFO - 2018-03-09 00:24:29 --> Helper loaded: form_helper
INFO - 2018-03-09 00:24:29 --> Database Driver Class Initialized
DEBUG - 2018-03-09 00:24:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-09 00:24:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 00:24:29 --> Form Validation Class Initialized
INFO - 2018-03-09 00:24:29 --> Model Class Initialized
INFO - 2018-03-09 00:24:29 --> Controller Class Initialized
INFO - 2018-03-09 00:24:29 --> Model Class Initialized
INFO - 2018-03-09 00:24:29 --> Model Class Initialized
INFO - 2018-03-09 00:24:29 --> Model Class Initialized
INFO - 2018-03-09 00:24:29 --> Model Class Initialized
INFO - 2018-03-09 00:24:29 --> Model Class Initialized
DEBUG - 2018-03-09 00:24:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-09 00:24:33 --> Config Class Initialized
INFO - 2018-03-09 00:24:33 --> Hooks Class Initialized
DEBUG - 2018-03-09 00:24:33 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:24:33 --> Utf8 Class Initialized
INFO - 2018-03-09 00:24:33 --> URI Class Initialized
INFO - 2018-03-09 00:24:33 --> Router Class Initialized
INFO - 2018-03-09 00:24:33 --> Output Class Initialized
INFO - 2018-03-09 00:24:33 --> Security Class Initialized
DEBUG - 2018-03-09 00:24:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:24:33 --> Input Class Initialized
INFO - 2018-03-09 00:24:33 --> Language Class Initialized
INFO - 2018-03-09 00:24:33 --> Loader Class Initialized
INFO - 2018-03-09 00:24:33 --> Helper loaded: url_helper
INFO - 2018-03-09 00:24:33 --> Helper loaded: form_helper
INFO - 2018-03-09 00:24:33 --> Database Driver Class Initialized
DEBUG - 2018-03-09 00:24:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-09 00:24:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 00:24:33 --> Form Validation Class Initialized
INFO - 2018-03-09 00:24:33 --> Model Class Initialized
INFO - 2018-03-09 00:24:33 --> Controller Class Initialized
INFO - 2018-03-09 00:24:33 --> Model Class Initialized
INFO - 2018-03-09 00:24:33 --> Model Class Initialized
INFO - 2018-03-09 00:24:33 --> Model Class Initialized
INFO - 2018-03-09 00:24:33 --> Model Class Initialized
INFO - 2018-03-09 00:24:33 --> Model Class Initialized
DEBUG - 2018-03-09 00:24:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-09 00:25:33 --> Config Class Initialized
INFO - 2018-03-09 00:25:33 --> Hooks Class Initialized
DEBUG - 2018-03-09 00:25:33 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:25:33 --> Utf8 Class Initialized
INFO - 2018-03-09 00:25:33 --> URI Class Initialized
INFO - 2018-03-09 00:25:33 --> Router Class Initialized
INFO - 2018-03-09 00:25:33 --> Output Class Initialized
INFO - 2018-03-09 00:25:33 --> Security Class Initialized
DEBUG - 2018-03-09 00:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:25:33 --> Input Class Initialized
INFO - 2018-03-09 00:25:33 --> Language Class Initialized
INFO - 2018-03-09 00:25:33 --> Loader Class Initialized
INFO - 2018-03-09 00:25:33 --> Helper loaded: url_helper
INFO - 2018-03-09 00:25:33 --> Helper loaded: form_helper
INFO - 2018-03-09 00:25:33 --> Database Driver Class Initialized
DEBUG - 2018-03-09 00:25:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-09 00:25:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 00:25:33 --> Form Validation Class Initialized
INFO - 2018-03-09 00:25:33 --> Model Class Initialized
INFO - 2018-03-09 00:25:33 --> Controller Class Initialized
INFO - 2018-03-09 00:25:33 --> Model Class Initialized
INFO - 2018-03-09 00:25:33 --> Model Class Initialized
INFO - 2018-03-09 00:25:33 --> Model Class Initialized
INFO - 2018-03-09 00:25:33 --> Model Class Initialized
INFO - 2018-03-09 00:25:33 --> Model Class Initialized
DEBUG - 2018-03-09 00:25:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-09 00:25:33 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-09 00:25:33 --> Final output sent to browser
DEBUG - 2018-03-09 00:25:33 --> Total execution time: 0.1325
INFO - 2018-03-09 00:25:33 --> Config Class Initialized
INFO - 2018-03-09 00:25:33 --> Hooks Class Initialized
DEBUG - 2018-03-09 00:25:33 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:25:33 --> Utf8 Class Initialized
INFO - 2018-03-09 00:25:33 --> URI Class Initialized
INFO - 2018-03-09 00:25:33 --> Router Class Initialized
INFO - 2018-03-09 00:25:33 --> Output Class Initialized
INFO - 2018-03-09 00:25:33 --> Security Class Initialized
DEBUG - 2018-03-09 00:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:25:33 --> Input Class Initialized
INFO - 2018-03-09 00:25:33 --> Language Class Initialized
INFO - 2018-03-09 00:25:33 --> Loader Class Initialized
INFO - 2018-03-09 00:25:33 --> Helper loaded: url_helper
INFO - 2018-03-09 00:25:33 --> Helper loaded: form_helper
INFO - 2018-03-09 00:25:33 --> Database Driver Class Initialized
DEBUG - 2018-03-09 00:25:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-09 00:25:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 00:25:33 --> Form Validation Class Initialized
INFO - 2018-03-09 00:25:33 --> Model Class Initialized
INFO - 2018-03-09 00:25:33 --> Controller Class Initialized
INFO - 2018-03-09 00:25:33 --> Model Class Initialized
INFO - 2018-03-09 00:25:33 --> Model Class Initialized
INFO - 2018-03-09 00:25:33 --> Model Class Initialized
INFO - 2018-03-09 00:25:33 --> Model Class Initialized
INFO - 2018-03-09 00:25:33 --> Model Class Initialized
DEBUG - 2018-03-09 00:25:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-09 00:25:34 --> Config Class Initialized
INFO - 2018-03-09 00:25:34 --> Hooks Class Initialized
DEBUG - 2018-03-09 00:25:34 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:25:34 --> Utf8 Class Initialized
INFO - 2018-03-09 00:25:34 --> URI Class Initialized
INFO - 2018-03-09 00:25:34 --> Router Class Initialized
INFO - 2018-03-09 00:25:34 --> Output Class Initialized
INFO - 2018-03-09 00:25:34 --> Security Class Initialized
DEBUG - 2018-03-09 00:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:25:34 --> Input Class Initialized
INFO - 2018-03-09 00:25:34 --> Language Class Initialized
INFO - 2018-03-09 00:25:34 --> Loader Class Initialized
INFO - 2018-03-09 00:25:34 --> Helper loaded: url_helper
INFO - 2018-03-09 00:25:34 --> Helper loaded: form_helper
INFO - 2018-03-09 00:25:34 --> Database Driver Class Initialized
DEBUG - 2018-03-09 00:25:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-09 00:25:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 00:25:34 --> Form Validation Class Initialized
INFO - 2018-03-09 00:25:34 --> Model Class Initialized
INFO - 2018-03-09 00:25:34 --> Controller Class Initialized
INFO - 2018-03-09 00:25:34 --> Model Class Initialized
INFO - 2018-03-09 00:25:34 --> Model Class Initialized
INFO - 2018-03-09 00:25:34 --> Model Class Initialized
INFO - 2018-03-09 00:25:34 --> Model Class Initialized
INFO - 2018-03-09 00:25:34 --> Model Class Initialized
DEBUG - 2018-03-09 00:25:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-09 00:25:34 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-09 00:25:34 --> Final output sent to browser
DEBUG - 2018-03-09 00:25:34 --> Total execution time: 0.0578
INFO - 2018-03-09 00:25:34 --> Config Class Initialized
INFO - 2018-03-09 00:25:34 --> Config Class Initialized
INFO - 2018-03-09 00:25:34 --> Config Class Initialized
INFO - 2018-03-09 00:25:34 --> Hooks Class Initialized
INFO - 2018-03-09 00:25:34 --> Hooks Class Initialized
INFO - 2018-03-09 00:25:34 --> Hooks Class Initialized
INFO - 2018-03-09 00:25:34 --> Config Class Initialized
INFO - 2018-03-09 00:25:34 --> Hooks Class Initialized
DEBUG - 2018-03-09 00:25:34 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 00:25:34 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:25:34 --> Utf8 Class Initialized
DEBUG - 2018-03-09 00:25:34 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:25:34 --> Utf8 Class Initialized
INFO - 2018-03-09 00:25:34 --> Utf8 Class Initialized
INFO - 2018-03-09 00:25:34 --> URI Class Initialized
DEBUG - 2018-03-09 00:25:34 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:25:34 --> URI Class Initialized
INFO - 2018-03-09 00:25:34 --> URI Class Initialized
INFO - 2018-03-09 00:25:34 --> Utf8 Class Initialized
INFO - 2018-03-09 00:25:34 --> Router Class Initialized
INFO - 2018-03-09 00:25:34 --> URI Class Initialized
INFO - 2018-03-09 00:25:34 --> Router Class Initialized
INFO - 2018-03-09 00:25:34 --> Router Class Initialized
INFO - 2018-03-09 00:25:34 --> Router Class Initialized
INFO - 2018-03-09 00:25:34 --> Output Class Initialized
INFO - 2018-03-09 00:25:34 --> Output Class Initialized
INFO - 2018-03-09 00:25:34 --> Output Class Initialized
INFO - 2018-03-09 00:25:34 --> Security Class Initialized
INFO - 2018-03-09 00:25:34 --> Output Class Initialized
INFO - 2018-03-09 00:25:34 --> Security Class Initialized
DEBUG - 2018-03-09 00:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:25:34 --> Input Class Initialized
DEBUG - 2018-03-09 00:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:25:34 --> Security Class Initialized
INFO - 2018-03-09 00:25:34 --> Security Class Initialized
INFO - 2018-03-09 00:25:34 --> Input Class Initialized
INFO - 2018-03-09 00:25:34 --> Language Class Initialized
INFO - 2018-03-09 00:25:34 --> Language Class Initialized
DEBUG - 2018-03-09 00:25:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 00:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:25:34 --> Input Class Initialized
INFO - 2018-03-09 00:25:34 --> Input Class Initialized
ERROR - 2018-03-09 00:25:34 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-09 00:25:34 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-09 00:25:34 --> Language Class Initialized
INFO - 2018-03-09 00:25:34 --> Language Class Initialized
ERROR - 2018-03-09 00:25:34 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-09 00:25:34 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-09 00:25:34 --> Config Class Initialized
INFO - 2018-03-09 00:25:34 --> Config Class Initialized
INFO - 2018-03-09 00:25:34 --> Hooks Class Initialized
INFO - 2018-03-09 00:25:34 --> Hooks Class Initialized
INFO - 2018-03-09 00:25:34 --> Config Class Initialized
INFO - 2018-03-09 00:25:34 --> Hooks Class Initialized
DEBUG - 2018-03-09 00:25:34 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:25:34 --> Utf8 Class Initialized
DEBUG - 2018-03-09 00:25:34 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:25:34 --> Utf8 Class Initialized
INFO - 2018-03-09 00:25:34 --> URI Class Initialized
INFO - 2018-03-09 00:25:34 --> URI Class Initialized
DEBUG - 2018-03-09 00:25:34 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:25:34 --> Utf8 Class Initialized
INFO - 2018-03-09 00:25:34 --> Router Class Initialized
INFO - 2018-03-09 00:25:34 --> Router Class Initialized
INFO - 2018-03-09 00:25:34 --> URI Class Initialized
INFO - 2018-03-09 00:25:34 --> Output Class Initialized
INFO - 2018-03-09 00:25:34 --> Output Class Initialized
INFO - 2018-03-09 00:25:34 --> Router Class Initialized
INFO - 2018-03-09 00:25:34 --> Security Class Initialized
DEBUG - 2018-03-09 00:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:25:34 --> Security Class Initialized
INFO - 2018-03-09 00:25:34 --> Input Class Initialized
INFO - 2018-03-09 00:25:34 --> Output Class Initialized
INFO - 2018-03-09 00:25:34 --> Language Class Initialized
DEBUG - 2018-03-09 00:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:25:34 --> Input Class Initialized
INFO - 2018-03-09 00:25:34 --> Security Class Initialized
INFO - 2018-03-09 00:25:34 --> Language Class Initialized
ERROR - 2018-03-09 00:25:34 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-03-09 00:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:25:34 --> Input Class Initialized
ERROR - 2018-03-09 00:25:34 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-09 00:25:34 --> Language Class Initialized
ERROR - 2018-03-09 00:25:34 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-09 00:25:34 --> Config Class Initialized
INFO - 2018-03-09 00:25:34 --> Hooks Class Initialized
DEBUG - 2018-03-09 00:25:34 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:25:34 --> Utf8 Class Initialized
INFO - 2018-03-09 00:25:34 --> URI Class Initialized
INFO - 2018-03-09 00:25:34 --> Router Class Initialized
INFO - 2018-03-09 00:25:34 --> Output Class Initialized
INFO - 2018-03-09 00:25:34 --> Security Class Initialized
DEBUG - 2018-03-09 00:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:25:34 --> Input Class Initialized
INFO - 2018-03-09 00:25:34 --> Language Class Initialized
INFO - 2018-03-09 00:25:34 --> Loader Class Initialized
INFO - 2018-03-09 00:25:34 --> Helper loaded: url_helper
INFO - 2018-03-09 00:25:34 --> Helper loaded: form_helper
INFO - 2018-03-09 00:25:35 --> Database Driver Class Initialized
DEBUG - 2018-03-09 00:25:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-09 00:25:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 00:25:35 --> Form Validation Class Initialized
INFO - 2018-03-09 00:25:35 --> Model Class Initialized
INFO - 2018-03-09 00:25:35 --> Controller Class Initialized
INFO - 2018-03-09 00:25:35 --> Model Class Initialized
INFO - 2018-03-09 00:25:35 --> Model Class Initialized
INFO - 2018-03-09 00:25:35 --> Model Class Initialized
INFO - 2018-03-09 00:25:35 --> Model Class Initialized
INFO - 2018-03-09 00:25:35 --> Model Class Initialized
DEBUG - 2018-03-09 00:25:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-09 00:34:49 --> Config Class Initialized
INFO - 2018-03-09 00:34:49 --> Hooks Class Initialized
DEBUG - 2018-03-09 00:34:49 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:34:49 --> Utf8 Class Initialized
INFO - 2018-03-09 00:34:49 --> URI Class Initialized
INFO - 2018-03-09 00:34:49 --> Router Class Initialized
INFO - 2018-03-09 00:34:49 --> Output Class Initialized
INFO - 2018-03-09 00:34:49 --> Security Class Initialized
DEBUG - 2018-03-09 00:34:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:34:49 --> Input Class Initialized
INFO - 2018-03-09 00:34:49 --> Language Class Initialized
INFO - 2018-03-09 00:34:49 --> Loader Class Initialized
INFO - 2018-03-09 00:34:49 --> Helper loaded: url_helper
INFO - 2018-03-09 00:34:49 --> Helper loaded: form_helper
INFO - 2018-03-09 00:34:49 --> Database Driver Class Initialized
DEBUG - 2018-03-09 00:34:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-09 00:34:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 00:34:49 --> Form Validation Class Initialized
INFO - 2018-03-09 00:34:49 --> Model Class Initialized
INFO - 2018-03-09 00:34:49 --> Controller Class Initialized
INFO - 2018-03-09 00:34:49 --> Model Class Initialized
INFO - 2018-03-09 00:34:49 --> Model Class Initialized
INFO - 2018-03-09 00:34:49 --> Model Class Initialized
INFO - 2018-03-09 00:34:49 --> Model Class Initialized
INFO - 2018-03-09 00:34:49 --> Model Class Initialized
DEBUG - 2018-03-09 00:34:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-09 00:34:49 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-09 00:34:49 --> Final output sent to browser
DEBUG - 2018-03-09 00:34:49 --> Total execution time: 0.0598
INFO - 2018-03-09 00:34:49 --> Config Class Initialized
INFO - 2018-03-09 00:34:49 --> Hooks Class Initialized
INFO - 2018-03-09 00:34:49 --> Config Class Initialized
INFO - 2018-03-09 00:34:49 --> Hooks Class Initialized
DEBUG - 2018-03-09 00:34:49 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:34:49 --> Utf8 Class Initialized
DEBUG - 2018-03-09 00:34:49 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:34:49 --> URI Class Initialized
INFO - 2018-03-09 00:34:49 --> Utf8 Class Initialized
INFO - 2018-03-09 00:34:49 --> Config Class Initialized
INFO - 2018-03-09 00:34:49 --> Hooks Class Initialized
INFO - 2018-03-09 00:34:49 --> URI Class Initialized
INFO - 2018-03-09 00:34:49 --> Config Class Initialized
INFO - 2018-03-09 00:34:49 --> Router Class Initialized
INFO - 2018-03-09 00:34:49 --> Hooks Class Initialized
INFO - 2018-03-09 00:34:49 --> Router Class Initialized
DEBUG - 2018-03-09 00:34:49 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:34:49 --> Utf8 Class Initialized
INFO - 2018-03-09 00:34:49 --> Output Class Initialized
INFO - 2018-03-09 00:34:49 --> Output Class Initialized
INFO - 2018-03-09 00:34:49 --> URI Class Initialized
DEBUG - 2018-03-09 00:34:49 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:34:49 --> Security Class Initialized
INFO - 2018-03-09 00:34:49 --> Utf8 Class Initialized
INFO - 2018-03-09 00:34:49 --> Security Class Initialized
INFO - 2018-03-09 00:34:49 --> Router Class Initialized
DEBUG - 2018-03-09 00:34:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:34:49 --> URI Class Initialized
INFO - 2018-03-09 00:34:49 --> Input Class Initialized
DEBUG - 2018-03-09 00:34:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:34:49 --> Input Class Initialized
INFO - 2018-03-09 00:34:49 --> Language Class Initialized
INFO - 2018-03-09 00:34:49 --> Output Class Initialized
INFO - 2018-03-09 00:34:49 --> Router Class Initialized
INFO - 2018-03-09 00:34:49 --> Language Class Initialized
ERROR - 2018-03-09 00:34:49 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-09 00:34:49 --> Security Class Initialized
ERROR - 2018-03-09 00:34:49 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-09 00:34:49 --> Output Class Initialized
DEBUG - 2018-03-09 00:34:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:34:49 --> Input Class Initialized
INFO - 2018-03-09 00:34:49 --> Security Class Initialized
INFO - 2018-03-09 00:34:49 --> Language Class Initialized
DEBUG - 2018-03-09 00:34:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:34:49 --> Input Class Initialized
ERROR - 2018-03-09 00:34:49 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-09 00:34:49 --> Language Class Initialized
ERROR - 2018-03-09 00:34:49 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-09 00:34:49 --> Config Class Initialized
INFO - 2018-03-09 00:34:49 --> Hooks Class Initialized
INFO - 2018-03-09 00:34:49 --> Config Class Initialized
INFO - 2018-03-09 00:34:49 --> Hooks Class Initialized
INFO - 2018-03-09 00:34:49 --> Config Class Initialized
INFO - 2018-03-09 00:34:49 --> Hooks Class Initialized
DEBUG - 2018-03-09 00:34:49 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:34:49 --> Utf8 Class Initialized
DEBUG - 2018-03-09 00:34:49 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:34:49 --> Utf8 Class Initialized
INFO - 2018-03-09 00:34:49 --> URI Class Initialized
DEBUG - 2018-03-09 00:34:49 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:34:49 --> Utf8 Class Initialized
INFO - 2018-03-09 00:34:49 --> URI Class Initialized
INFO - 2018-03-09 00:34:49 --> Router Class Initialized
INFO - 2018-03-09 00:34:49 --> URI Class Initialized
INFO - 2018-03-09 00:34:49 --> Router Class Initialized
INFO - 2018-03-09 00:34:49 --> Router Class Initialized
INFO - 2018-03-09 00:34:49 --> Output Class Initialized
INFO - 2018-03-09 00:34:49 --> Output Class Initialized
INFO - 2018-03-09 00:34:49 --> Security Class Initialized
INFO - 2018-03-09 00:34:49 --> Security Class Initialized
INFO - 2018-03-09 00:34:49 --> Output Class Initialized
DEBUG - 2018-03-09 00:34:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:34:49 --> Input Class Initialized
DEBUG - 2018-03-09 00:34:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:34:49 --> Input Class Initialized
INFO - 2018-03-09 00:34:49 --> Security Class Initialized
INFO - 2018-03-09 00:34:49 --> Language Class Initialized
INFO - 2018-03-09 00:34:49 --> Language Class Initialized
ERROR - 2018-03-09 00:34:49 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-03-09 00:34:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-03-09 00:34:49 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-09 00:34:49 --> Input Class Initialized
INFO - 2018-03-09 00:34:49 --> Language Class Initialized
ERROR - 2018-03-09 00:34:49 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-09 00:34:49 --> Config Class Initialized
INFO - 2018-03-09 00:34:49 --> Hooks Class Initialized
DEBUG - 2018-03-09 00:34:49 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:34:49 --> Utf8 Class Initialized
INFO - 2018-03-09 00:34:49 --> URI Class Initialized
INFO - 2018-03-09 00:34:49 --> Router Class Initialized
INFO - 2018-03-09 00:34:49 --> Output Class Initialized
INFO - 2018-03-09 00:34:49 --> Security Class Initialized
DEBUG - 2018-03-09 00:34:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:34:49 --> Input Class Initialized
INFO - 2018-03-09 00:34:49 --> Language Class Initialized
INFO - 2018-03-09 00:34:49 --> Loader Class Initialized
INFO - 2018-03-09 00:34:49 --> Helper loaded: url_helper
INFO - 2018-03-09 00:34:49 --> Helper loaded: form_helper
INFO - 2018-03-09 00:34:49 --> Database Driver Class Initialized
DEBUG - 2018-03-09 00:34:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-09 00:34:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 00:34:49 --> Form Validation Class Initialized
INFO - 2018-03-09 00:34:49 --> Model Class Initialized
INFO - 2018-03-09 00:34:49 --> Controller Class Initialized
INFO - 2018-03-09 00:34:49 --> Model Class Initialized
INFO - 2018-03-09 00:34:49 --> Model Class Initialized
INFO - 2018-03-09 00:34:49 --> Model Class Initialized
INFO - 2018-03-09 00:34:49 --> Model Class Initialized
INFO - 2018-03-09 00:34:49 --> Model Class Initialized
DEBUG - 2018-03-09 00:34:49 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-03-09 00:34:49 --> Severity: Notice --> Undefined variable: tiempo_mensual D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 613
ERROR - 2018-03-09 00:34:49 --> Severity: Notice --> Undefined variable: tiempo_semanal D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 617
ERROR - 2018-03-09 00:34:49 --> Severity: Notice --> Undefined variable: tiempo_total D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 620
INFO - 2018-03-09 00:35:00 --> Config Class Initialized
INFO - 2018-03-09 00:35:00 --> Hooks Class Initialized
DEBUG - 2018-03-09 00:35:00 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:35:00 --> Utf8 Class Initialized
INFO - 2018-03-09 00:35:00 --> URI Class Initialized
INFO - 2018-03-09 00:35:00 --> Router Class Initialized
INFO - 2018-03-09 00:35:00 --> Output Class Initialized
INFO - 2018-03-09 00:35:00 --> Security Class Initialized
DEBUG - 2018-03-09 00:35:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:35:00 --> Input Class Initialized
INFO - 2018-03-09 00:35:00 --> Language Class Initialized
INFO - 2018-03-09 00:35:00 --> Loader Class Initialized
INFO - 2018-03-09 00:35:00 --> Helper loaded: url_helper
INFO - 2018-03-09 00:35:00 --> Helper loaded: form_helper
INFO - 2018-03-09 00:35:00 --> Database Driver Class Initialized
DEBUG - 2018-03-09 00:35:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-09 00:35:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 00:35:00 --> Form Validation Class Initialized
INFO - 2018-03-09 00:35:00 --> Model Class Initialized
INFO - 2018-03-09 00:35:00 --> Controller Class Initialized
INFO - 2018-03-09 00:35:00 --> Model Class Initialized
INFO - 2018-03-09 00:35:00 --> Model Class Initialized
INFO - 2018-03-09 00:35:00 --> Model Class Initialized
INFO - 2018-03-09 00:35:00 --> Model Class Initialized
INFO - 2018-03-09 00:35:00 --> Model Class Initialized
DEBUG - 2018-03-09 00:35:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-09 00:35:00 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-09 00:35:00 --> Final output sent to browser
DEBUG - 2018-03-09 00:35:00 --> Total execution time: 0.1738
INFO - 2018-03-09 00:35:00 --> Config Class Initialized
INFO - 2018-03-09 00:35:00 --> Config Class Initialized
INFO - 2018-03-09 00:35:00 --> Hooks Class Initialized
INFO - 2018-03-09 00:35:00 --> Config Class Initialized
INFO - 2018-03-09 00:35:00 --> Hooks Class Initialized
INFO - 2018-03-09 00:35:00 --> Hooks Class Initialized
DEBUG - 2018-03-09 00:35:00 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 00:35:00 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:35:00 --> Utf8 Class Initialized
INFO - 2018-03-09 00:35:00 --> Utf8 Class Initialized
DEBUG - 2018-03-09 00:35:00 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:35:00 --> Utf8 Class Initialized
INFO - 2018-03-09 00:35:00 --> URI Class Initialized
INFO - 2018-03-09 00:35:00 --> URI Class Initialized
INFO - 2018-03-09 00:35:00 --> URI Class Initialized
INFO - 2018-03-09 00:35:00 --> Router Class Initialized
INFO - 2018-03-09 00:35:00 --> Router Class Initialized
INFO - 2018-03-09 00:35:00 --> Router Class Initialized
INFO - 2018-03-09 00:35:00 --> Output Class Initialized
INFO - 2018-03-09 00:35:00 --> Output Class Initialized
INFO - 2018-03-09 00:35:00 --> Output Class Initialized
INFO - 2018-03-09 00:35:00 --> Security Class Initialized
INFO - 2018-03-09 00:35:00 --> Security Class Initialized
INFO - 2018-03-09 00:35:00 --> Security Class Initialized
DEBUG - 2018-03-09 00:35:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:35:00 --> Input Class Initialized
DEBUG - 2018-03-09 00:35:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 00:35:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:35:00 --> Language Class Initialized
INFO - 2018-03-09 00:35:00 --> Input Class Initialized
INFO - 2018-03-09 00:35:00 --> Input Class Initialized
INFO - 2018-03-09 00:35:00 --> Language Class Initialized
INFO - 2018-03-09 00:35:00 --> Language Class Initialized
ERROR - 2018-03-09 00:35:00 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-09 00:35:00 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-09 00:35:00 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-09 00:35:00 --> Config Class Initialized
INFO - 2018-03-09 00:35:00 --> Hooks Class Initialized
DEBUG - 2018-03-09 00:35:00 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:35:00 --> Utf8 Class Initialized
INFO - 2018-03-09 00:35:00 --> URI Class Initialized
INFO - 2018-03-09 00:35:00 --> Router Class Initialized
INFO - 2018-03-09 00:35:00 --> Output Class Initialized
INFO - 2018-03-09 00:35:00 --> Security Class Initialized
DEBUG - 2018-03-09 00:35:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:35:00 --> Input Class Initialized
INFO - 2018-03-09 00:35:00 --> Language Class Initialized
ERROR - 2018-03-09 00:35:00 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-09 00:35:00 --> Config Class Initialized
INFO - 2018-03-09 00:35:00 --> Hooks Class Initialized
INFO - 2018-03-09 00:35:00 --> Config Class Initialized
INFO - 2018-03-09 00:35:00 --> Hooks Class Initialized
INFO - 2018-03-09 00:35:00 --> Config Class Initialized
INFO - 2018-03-09 00:35:00 --> Hooks Class Initialized
DEBUG - 2018-03-09 00:35:00 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:35:00 --> Utf8 Class Initialized
DEBUG - 2018-03-09 00:35:00 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:35:00 --> Utf8 Class Initialized
DEBUG - 2018-03-09 00:35:00 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:35:00 --> Utf8 Class Initialized
INFO - 2018-03-09 00:35:00 --> URI Class Initialized
INFO - 2018-03-09 00:35:00 --> URI Class Initialized
INFO - 2018-03-09 00:35:00 --> URI Class Initialized
INFO - 2018-03-09 00:35:00 --> Router Class Initialized
INFO - 2018-03-09 00:35:00 --> Router Class Initialized
INFO - 2018-03-09 00:35:00 --> Router Class Initialized
INFO - 2018-03-09 00:35:00 --> Output Class Initialized
INFO - 2018-03-09 00:35:00 --> Security Class Initialized
INFO - 2018-03-09 00:35:00 --> Output Class Initialized
INFO - 2018-03-09 00:35:00 --> Output Class Initialized
DEBUG - 2018-03-09 00:35:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:35:00 --> Input Class Initialized
INFO - 2018-03-09 00:35:00 --> Security Class Initialized
INFO - 2018-03-09 00:35:00 --> Security Class Initialized
INFO - 2018-03-09 00:35:00 --> Language Class Initialized
DEBUG - 2018-03-09 00:35:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 00:35:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:35:00 --> Input Class Initialized
INFO - 2018-03-09 00:35:00 --> Input Class Initialized
ERROR - 2018-03-09 00:35:00 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-09 00:35:00 --> Language Class Initialized
INFO - 2018-03-09 00:35:00 --> Language Class Initialized
ERROR - 2018-03-09 00:35:00 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-09 00:35:00 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-09 00:35:01 --> Config Class Initialized
INFO - 2018-03-09 00:35:01 --> Hooks Class Initialized
DEBUG - 2018-03-09 00:35:01 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:35:01 --> Utf8 Class Initialized
INFO - 2018-03-09 00:35:01 --> URI Class Initialized
INFO - 2018-03-09 00:35:01 --> Router Class Initialized
INFO - 2018-03-09 00:35:01 --> Output Class Initialized
INFO - 2018-03-09 00:35:01 --> Security Class Initialized
DEBUG - 2018-03-09 00:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:35:01 --> Input Class Initialized
INFO - 2018-03-09 00:35:01 --> Language Class Initialized
INFO - 2018-03-09 00:35:01 --> Loader Class Initialized
INFO - 2018-03-09 00:35:01 --> Helper loaded: url_helper
INFO - 2018-03-09 00:35:01 --> Helper loaded: form_helper
INFO - 2018-03-09 00:35:01 --> Database Driver Class Initialized
DEBUG - 2018-03-09 00:35:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-09 00:35:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 00:35:01 --> Form Validation Class Initialized
INFO - 2018-03-09 00:35:01 --> Model Class Initialized
INFO - 2018-03-09 00:35:01 --> Controller Class Initialized
INFO - 2018-03-09 00:35:01 --> Model Class Initialized
INFO - 2018-03-09 00:35:01 --> Model Class Initialized
INFO - 2018-03-09 00:35:01 --> Model Class Initialized
INFO - 2018-03-09 00:35:01 --> Model Class Initialized
INFO - 2018-03-09 00:35:01 --> Model Class Initialized
DEBUG - 2018-03-09 00:35:01 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-03-09 00:35:01 --> Severity: Notice --> Undefined variable: tiempo_mensual D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 613
ERROR - 2018-03-09 00:35:01 --> Severity: Notice --> Undefined variable: tiempo_semanal D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 617
ERROR - 2018-03-09 00:35:01 --> Severity: Notice --> Undefined variable: tiempo_total D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 620
INFO - 2018-03-09 00:36:01 --> Config Class Initialized
INFO - 2018-03-09 00:36:01 --> Hooks Class Initialized
DEBUG - 2018-03-09 00:36:01 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:36:01 --> Utf8 Class Initialized
INFO - 2018-03-09 00:36:01 --> URI Class Initialized
INFO - 2018-03-09 00:36:01 --> Router Class Initialized
INFO - 2018-03-09 00:36:01 --> Output Class Initialized
INFO - 2018-03-09 00:36:01 --> Security Class Initialized
DEBUG - 2018-03-09 00:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:36:01 --> Input Class Initialized
INFO - 2018-03-09 00:36:01 --> Language Class Initialized
INFO - 2018-03-09 00:36:01 --> Loader Class Initialized
INFO - 2018-03-09 00:36:01 --> Helper loaded: url_helper
INFO - 2018-03-09 00:36:01 --> Helper loaded: form_helper
INFO - 2018-03-09 00:36:01 --> Database Driver Class Initialized
DEBUG - 2018-03-09 00:36:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-09 00:36:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 00:36:01 --> Form Validation Class Initialized
INFO - 2018-03-09 00:36:01 --> Model Class Initialized
INFO - 2018-03-09 00:36:01 --> Controller Class Initialized
INFO - 2018-03-09 00:36:01 --> Model Class Initialized
INFO - 2018-03-09 00:36:01 --> Model Class Initialized
INFO - 2018-03-09 00:36:01 --> Model Class Initialized
INFO - 2018-03-09 00:36:01 --> Model Class Initialized
INFO - 2018-03-09 00:36:01 --> Model Class Initialized
DEBUG - 2018-03-09 00:36:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-09 00:36:01 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-09 00:36:01 --> Final output sent to browser
DEBUG - 2018-03-09 00:36:01 --> Total execution time: 0.0672
INFO - 2018-03-09 00:36:01 --> Config Class Initialized
INFO - 2018-03-09 00:36:01 --> Config Class Initialized
INFO - 2018-03-09 00:36:01 --> Hooks Class Initialized
INFO - 2018-03-09 00:36:01 --> Hooks Class Initialized
INFO - 2018-03-09 00:36:01 --> Config Class Initialized
INFO - 2018-03-09 00:36:01 --> Hooks Class Initialized
DEBUG - 2018-03-09 00:36:01 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:36:01 --> Utf8 Class Initialized
DEBUG - 2018-03-09 00:36:01 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:36:01 --> Utf8 Class Initialized
INFO - 2018-03-09 00:36:01 --> URI Class Initialized
INFO - 2018-03-09 00:36:01 --> URI Class Initialized
DEBUG - 2018-03-09 00:36:01 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:36:01 --> Config Class Initialized
INFO - 2018-03-09 00:36:01 --> Utf8 Class Initialized
INFO - 2018-03-09 00:36:01 --> Hooks Class Initialized
INFO - 2018-03-09 00:36:01 --> Router Class Initialized
INFO - 2018-03-09 00:36:01 --> URI Class Initialized
INFO - 2018-03-09 00:36:01 --> Router Class Initialized
INFO - 2018-03-09 00:36:01 --> Router Class Initialized
INFO - 2018-03-09 00:36:01 --> Output Class Initialized
INFO - 2018-03-09 00:36:01 --> Output Class Initialized
DEBUG - 2018-03-09 00:36:01 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:36:01 --> Utf8 Class Initialized
INFO - 2018-03-09 00:36:01 --> Security Class Initialized
INFO - 2018-03-09 00:36:01 --> Output Class Initialized
INFO - 2018-03-09 00:36:01 --> URI Class Initialized
INFO - 2018-03-09 00:36:01 --> Security Class Initialized
DEBUG - 2018-03-09 00:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:36:01 --> Security Class Initialized
INFO - 2018-03-09 00:36:01 --> Input Class Initialized
DEBUG - 2018-03-09 00:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:36:01 --> Input Class Initialized
INFO - 2018-03-09 00:36:01 --> Router Class Initialized
INFO - 2018-03-09 00:36:01 --> Language Class Initialized
INFO - 2018-03-09 00:36:01 --> Language Class Initialized
DEBUG - 2018-03-09 00:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:36:01 --> Input Class Initialized
INFO - 2018-03-09 00:36:01 --> Language Class Initialized
ERROR - 2018-03-09 00:36:01 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-09 00:36:01 --> Output Class Initialized
ERROR - 2018-03-09 00:36:01 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-09 00:36:01 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-09 00:36:01 --> Security Class Initialized
DEBUG - 2018-03-09 00:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:36:01 --> Input Class Initialized
INFO - 2018-03-09 00:36:01 --> Language Class Initialized
ERROR - 2018-03-09 00:36:01 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-09 00:36:01 --> Config Class Initialized
INFO - 2018-03-09 00:36:01 --> Hooks Class Initialized
INFO - 2018-03-09 00:36:01 --> Config Class Initialized
INFO - 2018-03-09 00:36:01 --> Config Class Initialized
DEBUG - 2018-03-09 00:36:01 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:36:01 --> Hooks Class Initialized
INFO - 2018-03-09 00:36:01 --> Utf8 Class Initialized
INFO - 2018-03-09 00:36:01 --> Hooks Class Initialized
INFO - 2018-03-09 00:36:01 --> URI Class Initialized
DEBUG - 2018-03-09 00:36:01 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 00:36:01 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:36:01 --> Utf8 Class Initialized
INFO - 2018-03-09 00:36:01 --> Router Class Initialized
INFO - 2018-03-09 00:36:01 --> Utf8 Class Initialized
INFO - 2018-03-09 00:36:01 --> URI Class Initialized
INFO - 2018-03-09 00:36:01 --> URI Class Initialized
INFO - 2018-03-09 00:36:01 --> Output Class Initialized
INFO - 2018-03-09 00:36:01 --> Router Class Initialized
INFO - 2018-03-09 00:36:01 --> Router Class Initialized
INFO - 2018-03-09 00:36:01 --> Security Class Initialized
INFO - 2018-03-09 00:36:01 --> Output Class Initialized
DEBUG - 2018-03-09 00:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:36:01 --> Input Class Initialized
INFO - 2018-03-09 00:36:01 --> Output Class Initialized
INFO - 2018-03-09 00:36:01 --> Language Class Initialized
INFO - 2018-03-09 00:36:01 --> Security Class Initialized
INFO - 2018-03-09 00:36:01 --> Security Class Initialized
ERROR - 2018-03-09 00:36:01 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-03-09 00:36:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 00:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:36:01 --> Input Class Initialized
INFO - 2018-03-09 00:36:01 --> Input Class Initialized
INFO - 2018-03-09 00:36:01 --> Language Class Initialized
INFO - 2018-03-09 00:36:01 --> Language Class Initialized
ERROR - 2018-03-09 00:36:01 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-09 00:36:01 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-09 00:36:01 --> Config Class Initialized
INFO - 2018-03-09 00:36:01 --> Hooks Class Initialized
DEBUG - 2018-03-09 00:36:01 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:36:01 --> Utf8 Class Initialized
INFO - 2018-03-09 00:36:01 --> URI Class Initialized
INFO - 2018-03-09 00:36:01 --> Router Class Initialized
INFO - 2018-03-09 00:36:01 --> Output Class Initialized
INFO - 2018-03-09 00:36:01 --> Security Class Initialized
DEBUG - 2018-03-09 00:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:36:01 --> Input Class Initialized
INFO - 2018-03-09 00:36:01 --> Language Class Initialized
INFO - 2018-03-09 00:36:01 --> Loader Class Initialized
INFO - 2018-03-09 00:36:01 --> Helper loaded: url_helper
INFO - 2018-03-09 00:36:01 --> Helper loaded: form_helper
INFO - 2018-03-09 00:36:01 --> Database Driver Class Initialized
DEBUG - 2018-03-09 00:36:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-09 00:36:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 00:36:02 --> Form Validation Class Initialized
INFO - 2018-03-09 00:36:02 --> Model Class Initialized
INFO - 2018-03-09 00:36:02 --> Controller Class Initialized
INFO - 2018-03-09 00:36:02 --> Model Class Initialized
INFO - 2018-03-09 00:36:02 --> Model Class Initialized
INFO - 2018-03-09 00:36:02 --> Model Class Initialized
INFO - 2018-03-09 00:36:02 --> Model Class Initialized
INFO - 2018-03-09 00:36:02 --> Model Class Initialized
DEBUG - 2018-03-09 00:36:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-09 00:36:31 --> Config Class Initialized
INFO - 2018-03-09 00:36:31 --> Hooks Class Initialized
DEBUG - 2018-03-09 00:36:31 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:36:31 --> Utf8 Class Initialized
INFO - 2018-03-09 00:36:31 --> URI Class Initialized
INFO - 2018-03-09 00:36:31 --> Router Class Initialized
INFO - 2018-03-09 00:36:31 --> Output Class Initialized
INFO - 2018-03-09 00:36:31 --> Security Class Initialized
DEBUG - 2018-03-09 00:36:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:36:31 --> Input Class Initialized
INFO - 2018-03-09 00:36:31 --> Language Class Initialized
INFO - 2018-03-09 00:36:31 --> Loader Class Initialized
INFO - 2018-03-09 00:36:31 --> Helper loaded: url_helper
INFO - 2018-03-09 00:36:31 --> Helper loaded: form_helper
INFO - 2018-03-09 00:36:31 --> Database Driver Class Initialized
DEBUG - 2018-03-09 00:36:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-09 00:36:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 00:36:31 --> Form Validation Class Initialized
INFO - 2018-03-09 00:36:31 --> Model Class Initialized
INFO - 2018-03-09 00:36:31 --> Controller Class Initialized
INFO - 2018-03-09 00:36:31 --> Model Class Initialized
INFO - 2018-03-09 00:36:31 --> Model Class Initialized
INFO - 2018-03-09 00:36:31 --> Model Class Initialized
INFO - 2018-03-09 00:36:31 --> Model Class Initialized
INFO - 2018-03-09 00:36:31 --> Model Class Initialized
DEBUG - 2018-03-09 00:36:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-09 00:36:31 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-09 00:36:31 --> Final output sent to browser
DEBUG - 2018-03-09 00:36:31 --> Total execution time: 0.0614
INFO - 2018-03-09 00:36:31 --> Config Class Initialized
INFO - 2018-03-09 00:36:31 --> Config Class Initialized
INFO - 2018-03-09 00:36:31 --> Hooks Class Initialized
INFO - 2018-03-09 00:36:31 --> Config Class Initialized
INFO - 2018-03-09 00:36:31 --> Hooks Class Initialized
INFO - 2018-03-09 00:36:31 --> Hooks Class Initialized
DEBUG - 2018-03-09 00:36:31 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 00:36:31 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 00:36:31 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:36:31 --> Config Class Initialized
INFO - 2018-03-09 00:36:31 --> Utf8 Class Initialized
INFO - 2018-03-09 00:36:31 --> Utf8 Class Initialized
INFO - 2018-03-09 00:36:31 --> Utf8 Class Initialized
INFO - 2018-03-09 00:36:31 --> Hooks Class Initialized
INFO - 2018-03-09 00:36:31 --> URI Class Initialized
INFO - 2018-03-09 00:36:31 --> URI Class Initialized
INFO - 2018-03-09 00:36:31 --> URI Class Initialized
INFO - 2018-03-09 00:36:31 --> Router Class Initialized
DEBUG - 2018-03-09 00:36:31 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:36:31 --> Router Class Initialized
INFO - 2018-03-09 00:36:31 --> Utf8 Class Initialized
INFO - 2018-03-09 00:36:31 --> Router Class Initialized
INFO - 2018-03-09 00:36:31 --> URI Class Initialized
INFO - 2018-03-09 00:36:31 --> Output Class Initialized
INFO - 2018-03-09 00:36:31 --> Output Class Initialized
INFO - 2018-03-09 00:36:31 --> Output Class Initialized
INFO - 2018-03-09 00:36:31 --> Security Class Initialized
INFO - 2018-03-09 00:36:31 --> Security Class Initialized
INFO - 2018-03-09 00:36:31 --> Router Class Initialized
INFO - 2018-03-09 00:36:31 --> Security Class Initialized
DEBUG - 2018-03-09 00:36:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:36:31 --> Input Class Initialized
DEBUG - 2018-03-09 00:36:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:36:31 --> Input Class Initialized
DEBUG - 2018-03-09 00:36:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:36:31 --> Language Class Initialized
INFO - 2018-03-09 00:36:31 --> Output Class Initialized
INFO - 2018-03-09 00:36:31 --> Input Class Initialized
INFO - 2018-03-09 00:36:31 --> Language Class Initialized
INFO - 2018-03-09 00:36:31 --> Language Class Initialized
ERROR - 2018-03-09 00:36:31 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-09 00:36:31 --> Security Class Initialized
ERROR - 2018-03-09 00:36:31 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-09 00:36:31 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-09 00:36:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:36:31 --> Input Class Initialized
INFO - 2018-03-09 00:36:31 --> Language Class Initialized
ERROR - 2018-03-09 00:36:31 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-09 00:36:31 --> Config Class Initialized
INFO - 2018-03-09 00:36:31 --> Hooks Class Initialized
INFO - 2018-03-09 00:36:31 --> Config Class Initialized
INFO - 2018-03-09 00:36:31 --> Hooks Class Initialized
INFO - 2018-03-09 00:36:31 --> Config Class Initialized
INFO - 2018-03-09 00:36:31 --> Hooks Class Initialized
DEBUG - 2018-03-09 00:36:31 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:36:31 --> Utf8 Class Initialized
DEBUG - 2018-03-09 00:36:31 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 00:36:31 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:36:31 --> URI Class Initialized
INFO - 2018-03-09 00:36:31 --> Utf8 Class Initialized
INFO - 2018-03-09 00:36:31 --> Utf8 Class Initialized
INFO - 2018-03-09 00:36:31 --> URI Class Initialized
INFO - 2018-03-09 00:36:31 --> URI Class Initialized
INFO - 2018-03-09 00:36:31 --> Router Class Initialized
INFO - 2018-03-09 00:36:31 --> Router Class Initialized
INFO - 2018-03-09 00:36:31 --> Router Class Initialized
INFO - 2018-03-09 00:36:31 --> Output Class Initialized
INFO - 2018-03-09 00:36:31 --> Output Class Initialized
INFO - 2018-03-09 00:36:31 --> Security Class Initialized
INFO - 2018-03-09 00:36:31 --> Output Class Initialized
INFO - 2018-03-09 00:36:31 --> Security Class Initialized
DEBUG - 2018-03-09 00:36:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:36:31 --> Security Class Initialized
INFO - 2018-03-09 00:36:31 --> Input Class Initialized
DEBUG - 2018-03-09 00:36:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:36:31 --> Input Class Initialized
INFO - 2018-03-09 00:36:31 --> Language Class Initialized
DEBUG - 2018-03-09 00:36:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:36:31 --> Language Class Initialized
INFO - 2018-03-09 00:36:31 --> Input Class Initialized
ERROR - 2018-03-09 00:36:31 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-09 00:36:31 --> Language Class Initialized
ERROR - 2018-03-09 00:36:31 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-09 00:36:31 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-09 00:36:31 --> Config Class Initialized
INFO - 2018-03-09 00:36:31 --> Hooks Class Initialized
DEBUG - 2018-03-09 00:36:31 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:36:31 --> Utf8 Class Initialized
INFO - 2018-03-09 00:36:31 --> URI Class Initialized
INFO - 2018-03-09 00:36:31 --> Router Class Initialized
INFO - 2018-03-09 00:36:31 --> Output Class Initialized
INFO - 2018-03-09 00:36:31 --> Security Class Initialized
DEBUG - 2018-03-09 00:36:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:36:31 --> Input Class Initialized
INFO - 2018-03-09 00:36:31 --> Language Class Initialized
INFO - 2018-03-09 00:36:31 --> Loader Class Initialized
INFO - 2018-03-09 00:36:31 --> Helper loaded: url_helper
INFO - 2018-03-09 00:36:31 --> Helper loaded: form_helper
INFO - 2018-03-09 00:36:31 --> Database Driver Class Initialized
DEBUG - 2018-03-09 00:36:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-09 00:36:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 00:36:31 --> Form Validation Class Initialized
INFO - 2018-03-09 00:36:31 --> Model Class Initialized
INFO - 2018-03-09 00:36:31 --> Controller Class Initialized
INFO - 2018-03-09 00:36:31 --> Model Class Initialized
INFO - 2018-03-09 00:36:31 --> Model Class Initialized
INFO - 2018-03-09 00:36:31 --> Model Class Initialized
INFO - 2018-03-09 00:36:31 --> Model Class Initialized
INFO - 2018-03-09 00:36:31 --> Model Class Initialized
DEBUG - 2018-03-09 00:36:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-09 00:39:31 --> Config Class Initialized
INFO - 2018-03-09 00:39:31 --> Hooks Class Initialized
DEBUG - 2018-03-09 00:39:31 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:39:31 --> Utf8 Class Initialized
INFO - 2018-03-09 00:39:31 --> URI Class Initialized
INFO - 2018-03-09 00:39:31 --> Router Class Initialized
INFO - 2018-03-09 00:39:31 --> Output Class Initialized
INFO - 2018-03-09 00:39:31 --> Security Class Initialized
DEBUG - 2018-03-09 00:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:39:31 --> Input Class Initialized
INFO - 2018-03-09 00:39:31 --> Language Class Initialized
INFO - 2018-03-09 00:39:31 --> Loader Class Initialized
INFO - 2018-03-09 00:39:31 --> Helper loaded: url_helper
INFO - 2018-03-09 00:39:31 --> Helper loaded: form_helper
INFO - 2018-03-09 00:39:31 --> Database Driver Class Initialized
DEBUG - 2018-03-09 00:39:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-09 00:39:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 00:39:31 --> Form Validation Class Initialized
INFO - 2018-03-09 00:39:31 --> Model Class Initialized
INFO - 2018-03-09 00:39:31 --> Controller Class Initialized
INFO - 2018-03-09 00:39:31 --> Model Class Initialized
INFO - 2018-03-09 00:39:31 --> Model Class Initialized
INFO - 2018-03-09 00:39:31 --> Model Class Initialized
INFO - 2018-03-09 00:39:31 --> Model Class Initialized
INFO - 2018-03-09 00:39:31 --> Model Class Initialized
DEBUG - 2018-03-09 00:39:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-09 00:39:31 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-09 00:39:31 --> Final output sent to browser
DEBUG - 2018-03-09 00:39:31 --> Total execution time: 0.0541
INFO - 2018-03-09 00:39:31 --> Config Class Initialized
INFO - 2018-03-09 00:39:31 --> Config Class Initialized
INFO - 2018-03-09 00:39:31 --> Hooks Class Initialized
INFO - 2018-03-09 00:39:31 --> Hooks Class Initialized
INFO - 2018-03-09 00:39:31 --> Config Class Initialized
INFO - 2018-03-09 00:39:31 --> Hooks Class Initialized
DEBUG - 2018-03-09 00:39:31 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 00:39:31 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:39:31 --> Utf8 Class Initialized
INFO - 2018-03-09 00:39:31 --> Utf8 Class Initialized
INFO - 2018-03-09 00:39:31 --> URI Class Initialized
INFO - 2018-03-09 00:39:31 --> URI Class Initialized
DEBUG - 2018-03-09 00:39:31 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:39:31 --> Utf8 Class Initialized
INFO - 2018-03-09 00:39:31 --> Router Class Initialized
INFO - 2018-03-09 00:39:31 --> Config Class Initialized
INFO - 2018-03-09 00:39:31 --> URI Class Initialized
INFO - 2018-03-09 00:39:31 --> Router Class Initialized
INFO - 2018-03-09 00:39:31 --> Hooks Class Initialized
INFO - 2018-03-09 00:39:31 --> Output Class Initialized
INFO - 2018-03-09 00:39:31 --> Router Class Initialized
INFO - 2018-03-09 00:39:31 --> Output Class Initialized
INFO - 2018-03-09 00:39:31 --> Security Class Initialized
DEBUG - 2018-03-09 00:39:31 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:39:31 --> Utf8 Class Initialized
INFO - 2018-03-09 00:39:31 --> Security Class Initialized
DEBUG - 2018-03-09 00:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:39:31 --> Output Class Initialized
INFO - 2018-03-09 00:39:31 --> Input Class Initialized
INFO - 2018-03-09 00:39:31 --> URI Class Initialized
DEBUG - 2018-03-09 00:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:39:31 --> Language Class Initialized
INFO - 2018-03-09 00:39:31 --> Input Class Initialized
INFO - 2018-03-09 00:39:31 --> Security Class Initialized
INFO - 2018-03-09 00:39:31 --> Router Class Initialized
INFO - 2018-03-09 00:39:31 --> Language Class Initialized
ERROR - 2018-03-09 00:39:31 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-09 00:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:39:31 --> Input Class Initialized
ERROR - 2018-03-09 00:39:31 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-09 00:39:31 --> Language Class Initialized
INFO - 2018-03-09 00:39:31 --> Output Class Initialized
INFO - 2018-03-09 00:39:31 --> Security Class Initialized
ERROR - 2018-03-09 00:39:31 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-09 00:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:39:31 --> Input Class Initialized
INFO - 2018-03-09 00:39:31 --> Language Class Initialized
ERROR - 2018-03-09 00:39:31 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-09 00:39:31 --> Config Class Initialized
INFO - 2018-03-09 00:39:31 --> Config Class Initialized
INFO - 2018-03-09 00:39:31 --> Hooks Class Initialized
INFO - 2018-03-09 00:39:31 --> Hooks Class Initialized
INFO - 2018-03-09 00:39:31 --> Config Class Initialized
INFO - 2018-03-09 00:39:31 --> Hooks Class Initialized
DEBUG - 2018-03-09 00:39:31 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 00:39:31 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:39:31 --> Utf8 Class Initialized
INFO - 2018-03-09 00:39:31 --> Utf8 Class Initialized
DEBUG - 2018-03-09 00:39:31 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:39:31 --> Utf8 Class Initialized
INFO - 2018-03-09 00:39:31 --> URI Class Initialized
INFO - 2018-03-09 00:39:31 --> URI Class Initialized
INFO - 2018-03-09 00:39:31 --> URI Class Initialized
INFO - 2018-03-09 00:39:31 --> Router Class Initialized
INFO - 2018-03-09 00:39:31 --> Router Class Initialized
INFO - 2018-03-09 00:39:31 --> Router Class Initialized
INFO - 2018-03-09 00:39:31 --> Output Class Initialized
INFO - 2018-03-09 00:39:31 --> Output Class Initialized
INFO - 2018-03-09 00:39:31 --> Output Class Initialized
INFO - 2018-03-09 00:39:31 --> Security Class Initialized
INFO - 2018-03-09 00:39:31 --> Security Class Initialized
INFO - 2018-03-09 00:39:31 --> Security Class Initialized
DEBUG - 2018-03-09 00:39:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 00:39:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 00:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:39:31 --> Input Class Initialized
INFO - 2018-03-09 00:39:31 --> Input Class Initialized
INFO - 2018-03-09 00:39:31 --> Input Class Initialized
INFO - 2018-03-09 00:39:31 --> Language Class Initialized
INFO - 2018-03-09 00:39:31 --> Language Class Initialized
INFO - 2018-03-09 00:39:31 --> Language Class Initialized
ERROR - 2018-03-09 00:39:31 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-09 00:39:31 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-09 00:39:31 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-09 00:39:32 --> Config Class Initialized
INFO - 2018-03-09 00:39:32 --> Hooks Class Initialized
DEBUG - 2018-03-09 00:39:32 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:39:32 --> Utf8 Class Initialized
INFO - 2018-03-09 00:39:32 --> URI Class Initialized
INFO - 2018-03-09 00:39:32 --> Router Class Initialized
INFO - 2018-03-09 00:39:32 --> Output Class Initialized
INFO - 2018-03-09 00:39:32 --> Security Class Initialized
DEBUG - 2018-03-09 00:39:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:39:32 --> Input Class Initialized
INFO - 2018-03-09 00:39:32 --> Language Class Initialized
INFO - 2018-03-09 00:39:32 --> Loader Class Initialized
INFO - 2018-03-09 00:39:32 --> Helper loaded: url_helper
INFO - 2018-03-09 00:39:32 --> Helper loaded: form_helper
INFO - 2018-03-09 00:39:32 --> Database Driver Class Initialized
DEBUG - 2018-03-09 00:39:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-09 00:39:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 00:39:32 --> Form Validation Class Initialized
INFO - 2018-03-09 00:39:32 --> Model Class Initialized
INFO - 2018-03-09 00:39:32 --> Controller Class Initialized
INFO - 2018-03-09 00:39:32 --> Model Class Initialized
INFO - 2018-03-09 00:39:32 --> Model Class Initialized
INFO - 2018-03-09 00:39:32 --> Model Class Initialized
INFO - 2018-03-09 00:39:32 --> Model Class Initialized
INFO - 2018-03-09 00:39:32 --> Model Class Initialized
DEBUG - 2018-03-09 00:39:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-09 00:40:27 --> Config Class Initialized
INFO - 2018-03-09 00:40:27 --> Hooks Class Initialized
DEBUG - 2018-03-09 00:40:27 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:40:27 --> Utf8 Class Initialized
INFO - 2018-03-09 00:40:27 --> URI Class Initialized
INFO - 2018-03-09 00:40:27 --> Router Class Initialized
INFO - 2018-03-09 00:40:27 --> Output Class Initialized
INFO - 2018-03-09 00:40:27 --> Security Class Initialized
DEBUG - 2018-03-09 00:40:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:40:27 --> Input Class Initialized
INFO - 2018-03-09 00:40:27 --> Language Class Initialized
INFO - 2018-03-09 00:40:27 --> Loader Class Initialized
INFO - 2018-03-09 00:40:27 --> Helper loaded: url_helper
INFO - 2018-03-09 00:40:27 --> Helper loaded: form_helper
INFO - 2018-03-09 00:40:27 --> Database Driver Class Initialized
DEBUG - 2018-03-09 00:40:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-09 00:40:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 00:40:27 --> Form Validation Class Initialized
INFO - 2018-03-09 00:40:27 --> Model Class Initialized
INFO - 2018-03-09 00:40:27 --> Controller Class Initialized
INFO - 2018-03-09 00:40:27 --> Model Class Initialized
INFO - 2018-03-09 00:40:27 --> Model Class Initialized
INFO - 2018-03-09 00:40:27 --> Model Class Initialized
INFO - 2018-03-09 00:40:27 --> Model Class Initialized
INFO - 2018-03-09 00:40:27 --> Model Class Initialized
DEBUG - 2018-03-09 00:40:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-09 00:40:27 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-09 00:40:27 --> Final output sent to browser
DEBUG - 2018-03-09 00:40:27 --> Total execution time: 0.0551
INFO - 2018-03-09 00:40:27 --> Config Class Initialized
INFO - 2018-03-09 00:40:27 --> Hooks Class Initialized
INFO - 2018-03-09 00:40:27 --> Config Class Initialized
INFO - 2018-03-09 00:40:27 --> Hooks Class Initialized
INFO - 2018-03-09 00:40:27 --> Config Class Initialized
INFO - 2018-03-09 00:40:27 --> Hooks Class Initialized
DEBUG - 2018-03-09 00:40:27 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:40:27 --> Utf8 Class Initialized
INFO - 2018-03-09 00:40:27 --> URI Class Initialized
DEBUG - 2018-03-09 00:40:27 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:40:27 --> Config Class Initialized
DEBUG - 2018-03-09 00:40:27 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:40:27 --> Utf8 Class Initialized
INFO - 2018-03-09 00:40:27 --> Hooks Class Initialized
INFO - 2018-03-09 00:40:27 --> Utf8 Class Initialized
INFO - 2018-03-09 00:40:27 --> Router Class Initialized
INFO - 2018-03-09 00:40:27 --> URI Class Initialized
INFO - 2018-03-09 00:40:27 --> URI Class Initialized
DEBUG - 2018-03-09 00:40:27 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:40:27 --> Output Class Initialized
INFO - 2018-03-09 00:40:27 --> Utf8 Class Initialized
INFO - 2018-03-09 00:40:27 --> Router Class Initialized
INFO - 2018-03-09 00:40:27 --> Router Class Initialized
INFO - 2018-03-09 00:40:27 --> URI Class Initialized
INFO - 2018-03-09 00:40:27 --> Security Class Initialized
INFO - 2018-03-09 00:40:27 --> Output Class Initialized
INFO - 2018-03-09 00:40:27 --> Output Class Initialized
DEBUG - 2018-03-09 00:40:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:40:27 --> Router Class Initialized
INFO - 2018-03-09 00:40:27 --> Security Class Initialized
INFO - 2018-03-09 00:40:27 --> Input Class Initialized
INFO - 2018-03-09 00:40:27 --> Security Class Initialized
INFO - 2018-03-09 00:40:27 --> Language Class Initialized
DEBUG - 2018-03-09 00:40:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:40:27 --> Output Class Initialized
INFO - 2018-03-09 00:40:27 --> Input Class Initialized
DEBUG - 2018-03-09 00:40:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:40:27 --> Language Class Initialized
ERROR - 2018-03-09 00:40:27 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-09 00:40:27 --> Security Class Initialized
INFO - 2018-03-09 00:40:27 --> Input Class Initialized
ERROR - 2018-03-09 00:40:27 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-09 00:40:27 --> Language Class Initialized
DEBUG - 2018-03-09 00:40:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:40:27 --> Input Class Initialized
ERROR - 2018-03-09 00:40:27 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-09 00:40:27 --> Language Class Initialized
ERROR - 2018-03-09 00:40:27 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-09 00:40:27 --> Config Class Initialized
INFO - 2018-03-09 00:40:27 --> Hooks Class Initialized
INFO - 2018-03-09 00:40:27 --> Config Class Initialized
INFO - 2018-03-09 00:40:27 --> Config Class Initialized
INFO - 2018-03-09 00:40:27 --> Hooks Class Initialized
INFO - 2018-03-09 00:40:27 --> Hooks Class Initialized
DEBUG - 2018-03-09 00:40:27 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:40:27 --> Utf8 Class Initialized
INFO - 2018-03-09 00:40:27 --> URI Class Initialized
DEBUG - 2018-03-09 00:40:27 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 00:40:27 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:40:27 --> Utf8 Class Initialized
INFO - 2018-03-09 00:40:27 --> Utf8 Class Initialized
INFO - 2018-03-09 00:40:27 --> Router Class Initialized
INFO - 2018-03-09 00:40:27 --> URI Class Initialized
INFO - 2018-03-09 00:40:27 --> URI Class Initialized
INFO - 2018-03-09 00:40:27 --> Output Class Initialized
INFO - 2018-03-09 00:40:27 --> Router Class Initialized
INFO - 2018-03-09 00:40:27 --> Router Class Initialized
INFO - 2018-03-09 00:40:27 --> Security Class Initialized
INFO - 2018-03-09 00:40:27 --> Output Class Initialized
DEBUG - 2018-03-09 00:40:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:40:27 --> Output Class Initialized
INFO - 2018-03-09 00:40:27 --> Input Class Initialized
INFO - 2018-03-09 00:40:27 --> Security Class Initialized
INFO - 2018-03-09 00:40:27 --> Language Class Initialized
INFO - 2018-03-09 00:40:27 --> Security Class Initialized
DEBUG - 2018-03-09 00:40:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:40:27 --> Input Class Initialized
ERROR - 2018-03-09 00:40:27 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-03-09 00:40:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:40:27 --> Language Class Initialized
INFO - 2018-03-09 00:40:27 --> Input Class Initialized
INFO - 2018-03-09 00:40:27 --> Language Class Initialized
ERROR - 2018-03-09 00:40:27 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-09 00:40:27 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-09 00:40:27 --> Config Class Initialized
INFO - 2018-03-09 00:40:27 --> Hooks Class Initialized
DEBUG - 2018-03-09 00:40:27 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:40:27 --> Utf8 Class Initialized
INFO - 2018-03-09 00:40:27 --> URI Class Initialized
INFO - 2018-03-09 00:40:27 --> Router Class Initialized
INFO - 2018-03-09 00:40:27 --> Output Class Initialized
INFO - 2018-03-09 00:40:27 --> Security Class Initialized
DEBUG - 2018-03-09 00:40:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:40:27 --> Input Class Initialized
INFO - 2018-03-09 00:40:27 --> Language Class Initialized
INFO - 2018-03-09 00:40:27 --> Loader Class Initialized
INFO - 2018-03-09 00:40:27 --> Helper loaded: url_helper
INFO - 2018-03-09 00:40:27 --> Helper loaded: form_helper
INFO - 2018-03-09 00:40:27 --> Database Driver Class Initialized
DEBUG - 2018-03-09 00:40:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-09 00:40:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 00:40:27 --> Form Validation Class Initialized
INFO - 2018-03-09 00:40:27 --> Model Class Initialized
INFO - 2018-03-09 00:40:27 --> Controller Class Initialized
INFO - 2018-03-09 00:40:27 --> Model Class Initialized
INFO - 2018-03-09 00:40:27 --> Model Class Initialized
INFO - 2018-03-09 00:40:27 --> Model Class Initialized
INFO - 2018-03-09 00:40:27 --> Model Class Initialized
INFO - 2018-03-09 00:40:27 --> Model Class Initialized
DEBUG - 2018-03-09 00:40:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-09 00:40:45 --> Config Class Initialized
INFO - 2018-03-09 00:40:45 --> Hooks Class Initialized
DEBUG - 2018-03-09 00:40:45 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:40:45 --> Utf8 Class Initialized
INFO - 2018-03-09 00:40:45 --> URI Class Initialized
INFO - 2018-03-09 00:40:45 --> Router Class Initialized
INFO - 2018-03-09 00:40:45 --> Output Class Initialized
INFO - 2018-03-09 00:40:45 --> Security Class Initialized
DEBUG - 2018-03-09 00:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:40:45 --> Input Class Initialized
INFO - 2018-03-09 00:40:45 --> Language Class Initialized
INFO - 2018-03-09 00:40:45 --> Loader Class Initialized
INFO - 2018-03-09 00:40:45 --> Helper loaded: url_helper
INFO - 2018-03-09 00:40:45 --> Helper loaded: form_helper
INFO - 2018-03-09 00:40:45 --> Database Driver Class Initialized
DEBUG - 2018-03-09 00:40:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-09 00:40:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 00:40:45 --> Form Validation Class Initialized
INFO - 2018-03-09 00:40:45 --> Model Class Initialized
INFO - 2018-03-09 00:40:45 --> Controller Class Initialized
INFO - 2018-03-09 00:40:45 --> Model Class Initialized
INFO - 2018-03-09 00:40:45 --> Model Class Initialized
INFO - 2018-03-09 00:40:45 --> Model Class Initialized
INFO - 2018-03-09 00:40:45 --> Model Class Initialized
INFO - 2018-03-09 00:40:45 --> Model Class Initialized
DEBUG - 2018-03-09 00:40:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-09 00:40:45 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-09 00:40:45 --> Final output sent to browser
DEBUG - 2018-03-09 00:40:45 --> Total execution time: 0.0591
INFO - 2018-03-09 00:40:45 --> Config Class Initialized
INFO - 2018-03-09 00:40:45 --> Hooks Class Initialized
INFO - 2018-03-09 00:40:45 --> Config Class Initialized
INFO - 2018-03-09 00:40:45 --> Config Class Initialized
DEBUG - 2018-03-09 00:40:45 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:40:45 --> Hooks Class Initialized
INFO - 2018-03-09 00:40:45 --> Hooks Class Initialized
INFO - 2018-03-09 00:40:45 --> Utf8 Class Initialized
INFO - 2018-03-09 00:40:45 --> Config Class Initialized
INFO - 2018-03-09 00:40:45 --> Hooks Class Initialized
INFO - 2018-03-09 00:40:45 --> URI Class Initialized
DEBUG - 2018-03-09 00:40:45 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 00:40:45 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:40:45 --> Utf8 Class Initialized
INFO - 2018-03-09 00:40:45 --> Router Class Initialized
INFO - 2018-03-09 00:40:45 --> Utf8 Class Initialized
DEBUG - 2018-03-09 00:40:45 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:40:45 --> URI Class Initialized
INFO - 2018-03-09 00:40:45 --> Utf8 Class Initialized
INFO - 2018-03-09 00:40:45 --> Output Class Initialized
INFO - 2018-03-09 00:40:45 --> URI Class Initialized
INFO - 2018-03-09 00:40:45 --> Router Class Initialized
INFO - 2018-03-09 00:40:45 --> URI Class Initialized
INFO - 2018-03-09 00:40:45 --> Security Class Initialized
INFO - 2018-03-09 00:40:45 --> Router Class Initialized
INFO - 2018-03-09 00:40:45 --> Output Class Initialized
DEBUG - 2018-03-09 00:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:40:45 --> Router Class Initialized
INFO - 2018-03-09 00:40:45 --> Input Class Initialized
INFO - 2018-03-09 00:40:45 --> Security Class Initialized
INFO - 2018-03-09 00:40:45 --> Language Class Initialized
INFO - 2018-03-09 00:40:45 --> Output Class Initialized
INFO - 2018-03-09 00:40:45 --> Output Class Initialized
DEBUG - 2018-03-09 00:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:40:45 --> Input Class Initialized
ERROR - 2018-03-09 00:40:45 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-09 00:40:45 --> Security Class Initialized
INFO - 2018-03-09 00:40:45 --> Security Class Initialized
INFO - 2018-03-09 00:40:45 --> Language Class Initialized
DEBUG - 2018-03-09 00:40:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-03-09 00:40:45 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-09 00:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:40:45 --> Input Class Initialized
INFO - 2018-03-09 00:40:45 --> Input Class Initialized
INFO - 2018-03-09 00:40:45 --> Language Class Initialized
INFO - 2018-03-09 00:40:45 --> Language Class Initialized
ERROR - 2018-03-09 00:40:45 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-09 00:40:45 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-09 00:40:45 --> Config Class Initialized
INFO - 2018-03-09 00:40:45 --> Hooks Class Initialized
INFO - 2018-03-09 00:40:45 --> Config Class Initialized
INFO - 2018-03-09 00:40:45 --> Config Class Initialized
INFO - 2018-03-09 00:40:45 --> Hooks Class Initialized
DEBUG - 2018-03-09 00:40:45 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:40:45 --> Hooks Class Initialized
INFO - 2018-03-09 00:40:45 --> Utf8 Class Initialized
INFO - 2018-03-09 00:40:45 --> URI Class Initialized
DEBUG - 2018-03-09 00:40:45 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 00:40:45 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:40:45 --> Router Class Initialized
INFO - 2018-03-09 00:40:45 --> Utf8 Class Initialized
INFO - 2018-03-09 00:40:45 --> Utf8 Class Initialized
INFO - 2018-03-09 00:40:45 --> URI Class Initialized
INFO - 2018-03-09 00:40:45 --> URI Class Initialized
INFO - 2018-03-09 00:40:45 --> Output Class Initialized
INFO - 2018-03-09 00:40:45 --> Router Class Initialized
INFO - 2018-03-09 00:40:45 --> Router Class Initialized
INFO - 2018-03-09 00:40:45 --> Security Class Initialized
INFO - 2018-03-09 00:40:45 --> Output Class Initialized
DEBUG - 2018-03-09 00:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:40:45 --> Input Class Initialized
INFO - 2018-03-09 00:40:45 --> Output Class Initialized
INFO - 2018-03-09 00:40:45 --> Language Class Initialized
INFO - 2018-03-09 00:40:45 --> Security Class Initialized
INFO - 2018-03-09 00:40:45 --> Security Class Initialized
ERROR - 2018-03-09 00:40:45 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-03-09 00:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:40:45 --> Input Class Initialized
DEBUG - 2018-03-09 00:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:40:45 --> Input Class Initialized
INFO - 2018-03-09 00:40:45 --> Language Class Initialized
INFO - 2018-03-09 00:40:45 --> Language Class Initialized
ERROR - 2018-03-09 00:40:45 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-09 00:40:45 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-09 00:40:45 --> Config Class Initialized
INFO - 2018-03-09 00:40:45 --> Hooks Class Initialized
DEBUG - 2018-03-09 00:40:45 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:40:45 --> Utf8 Class Initialized
INFO - 2018-03-09 00:40:45 --> URI Class Initialized
INFO - 2018-03-09 00:40:45 --> Router Class Initialized
INFO - 2018-03-09 00:40:45 --> Output Class Initialized
INFO - 2018-03-09 00:40:45 --> Security Class Initialized
DEBUG - 2018-03-09 00:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:40:45 --> Input Class Initialized
INFO - 2018-03-09 00:40:45 --> Language Class Initialized
INFO - 2018-03-09 00:40:45 --> Loader Class Initialized
INFO - 2018-03-09 00:40:45 --> Helper loaded: url_helper
INFO - 2018-03-09 00:40:45 --> Helper loaded: form_helper
INFO - 2018-03-09 00:40:45 --> Database Driver Class Initialized
DEBUG - 2018-03-09 00:40:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-09 00:40:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 00:40:45 --> Form Validation Class Initialized
INFO - 2018-03-09 00:40:45 --> Model Class Initialized
INFO - 2018-03-09 00:40:45 --> Controller Class Initialized
INFO - 2018-03-09 00:40:45 --> Model Class Initialized
INFO - 2018-03-09 00:40:45 --> Model Class Initialized
INFO - 2018-03-09 00:40:45 --> Model Class Initialized
INFO - 2018-03-09 00:40:45 --> Model Class Initialized
INFO - 2018-03-09 00:40:45 --> Model Class Initialized
DEBUG - 2018-03-09 00:40:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-09 00:40:46 --> Config Class Initialized
INFO - 2018-03-09 00:40:46 --> Hooks Class Initialized
DEBUG - 2018-03-09 00:40:46 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:40:46 --> Utf8 Class Initialized
INFO - 2018-03-09 00:40:46 --> URI Class Initialized
INFO - 2018-03-09 00:40:46 --> Router Class Initialized
INFO - 2018-03-09 00:40:46 --> Output Class Initialized
INFO - 2018-03-09 00:40:46 --> Security Class Initialized
DEBUG - 2018-03-09 00:40:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:40:46 --> Input Class Initialized
INFO - 2018-03-09 00:40:46 --> Language Class Initialized
INFO - 2018-03-09 00:40:46 --> Loader Class Initialized
INFO - 2018-03-09 00:40:46 --> Helper loaded: url_helper
INFO - 2018-03-09 00:40:46 --> Helper loaded: form_helper
INFO - 2018-03-09 00:40:46 --> Database Driver Class Initialized
DEBUG - 2018-03-09 00:40:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-09 00:40:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 00:40:46 --> Form Validation Class Initialized
INFO - 2018-03-09 00:40:46 --> Model Class Initialized
INFO - 2018-03-09 00:40:46 --> Controller Class Initialized
INFO - 2018-03-09 00:40:46 --> Model Class Initialized
INFO - 2018-03-09 00:40:46 --> Model Class Initialized
INFO - 2018-03-09 00:40:46 --> Model Class Initialized
INFO - 2018-03-09 00:40:46 --> Model Class Initialized
INFO - 2018-03-09 00:40:46 --> Model Class Initialized
DEBUG - 2018-03-09 00:40:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-09 00:40:46 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-09 00:40:46 --> Final output sent to browser
DEBUG - 2018-03-09 00:40:46 --> Total execution time: 0.0541
INFO - 2018-03-09 00:40:46 --> Config Class Initialized
INFO - 2018-03-09 00:40:46 --> Hooks Class Initialized
INFO - 2018-03-09 00:40:46 --> Config Class Initialized
INFO - 2018-03-09 00:40:46 --> Hooks Class Initialized
INFO - 2018-03-09 00:40:46 --> Config Class Initialized
INFO - 2018-03-09 00:40:46 --> Hooks Class Initialized
DEBUG - 2018-03-09 00:40:46 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:40:46 --> Utf8 Class Initialized
DEBUG - 2018-03-09 00:40:46 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:40:46 --> Utf8 Class Initialized
INFO - 2018-03-09 00:40:46 --> URI Class Initialized
DEBUG - 2018-03-09 00:40:46 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:40:46 --> URI Class Initialized
INFO - 2018-03-09 00:40:46 --> Utf8 Class Initialized
INFO - 2018-03-09 00:40:46 --> Router Class Initialized
INFO - 2018-03-09 00:40:46 --> Config Class Initialized
INFO - 2018-03-09 00:40:46 --> URI Class Initialized
INFO - 2018-03-09 00:40:46 --> Hooks Class Initialized
INFO - 2018-03-09 00:40:46 --> Router Class Initialized
INFO - 2018-03-09 00:40:46 --> Output Class Initialized
INFO - 2018-03-09 00:40:46 --> Router Class Initialized
INFO - 2018-03-09 00:40:46 --> Output Class Initialized
INFO - 2018-03-09 00:40:46 --> Security Class Initialized
INFO - 2018-03-09 00:40:46 --> Output Class Initialized
DEBUG - 2018-03-09 00:40:46 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:40:46 --> Security Class Initialized
INFO - 2018-03-09 00:40:46 --> Utf8 Class Initialized
DEBUG - 2018-03-09 00:40:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:40:46 --> Input Class Initialized
INFO - 2018-03-09 00:40:46 --> Security Class Initialized
INFO - 2018-03-09 00:40:46 --> URI Class Initialized
DEBUG - 2018-03-09 00:40:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:40:46 --> Language Class Initialized
INFO - 2018-03-09 00:40:46 --> Input Class Initialized
DEBUG - 2018-03-09 00:40:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:40:46 --> Language Class Initialized
INFO - 2018-03-09 00:40:46 --> Input Class Initialized
INFO - 2018-03-09 00:40:46 --> Router Class Initialized
ERROR - 2018-03-09 00:40:46 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-09 00:40:46 --> Language Class Initialized
ERROR - 2018-03-09 00:40:46 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-09 00:40:46 --> Output Class Initialized
ERROR - 2018-03-09 00:40:46 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-09 00:40:46 --> Security Class Initialized
DEBUG - 2018-03-09 00:40:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:40:46 --> Input Class Initialized
INFO - 2018-03-09 00:40:46 --> Language Class Initialized
ERROR - 2018-03-09 00:40:46 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-09 00:40:46 --> Config Class Initialized
INFO - 2018-03-09 00:40:46 --> Hooks Class Initialized
INFO - 2018-03-09 00:40:46 --> Config Class Initialized
INFO - 2018-03-09 00:40:46 --> Hooks Class Initialized
INFO - 2018-03-09 00:40:46 --> Config Class Initialized
INFO - 2018-03-09 00:40:46 --> Hooks Class Initialized
DEBUG - 2018-03-09 00:40:46 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:40:46 --> Utf8 Class Initialized
INFO - 2018-03-09 00:40:46 --> URI Class Initialized
DEBUG - 2018-03-09 00:40:46 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:40:46 --> Utf8 Class Initialized
INFO - 2018-03-09 00:40:46 --> Router Class Initialized
INFO - 2018-03-09 00:40:46 --> URI Class Initialized
DEBUG - 2018-03-09 00:40:46 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:40:46 --> Utf8 Class Initialized
INFO - 2018-03-09 00:40:46 --> Output Class Initialized
INFO - 2018-03-09 00:40:46 --> Router Class Initialized
INFO - 2018-03-09 00:40:46 --> URI Class Initialized
INFO - 2018-03-09 00:40:46 --> Security Class Initialized
INFO - 2018-03-09 00:40:46 --> Output Class Initialized
INFO - 2018-03-09 00:40:46 --> Router Class Initialized
DEBUG - 2018-03-09 00:40:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:40:46 --> Input Class Initialized
INFO - 2018-03-09 00:40:46 --> Language Class Initialized
INFO - 2018-03-09 00:40:46 --> Security Class Initialized
INFO - 2018-03-09 00:40:46 --> Output Class Initialized
ERROR - 2018-03-09 00:40:46 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-03-09 00:40:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:40:46 --> Input Class Initialized
INFO - 2018-03-09 00:40:46 --> Security Class Initialized
INFO - 2018-03-09 00:40:46 --> Language Class Initialized
DEBUG - 2018-03-09 00:40:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:40:46 --> Input Class Initialized
ERROR - 2018-03-09 00:40:46 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-09 00:40:46 --> Language Class Initialized
ERROR - 2018-03-09 00:40:46 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-09 00:40:46 --> Config Class Initialized
INFO - 2018-03-09 00:40:46 --> Hooks Class Initialized
DEBUG - 2018-03-09 00:40:46 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:40:46 --> Utf8 Class Initialized
INFO - 2018-03-09 00:40:46 --> URI Class Initialized
INFO - 2018-03-09 00:40:46 --> Router Class Initialized
INFO - 2018-03-09 00:40:46 --> Output Class Initialized
INFO - 2018-03-09 00:40:46 --> Security Class Initialized
DEBUG - 2018-03-09 00:40:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:40:46 --> Input Class Initialized
INFO - 2018-03-09 00:40:46 --> Language Class Initialized
INFO - 2018-03-09 00:40:46 --> Loader Class Initialized
INFO - 2018-03-09 00:40:46 --> Helper loaded: url_helper
INFO - 2018-03-09 00:40:46 --> Helper loaded: form_helper
INFO - 2018-03-09 00:40:46 --> Database Driver Class Initialized
DEBUG - 2018-03-09 00:40:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-09 00:40:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 00:40:46 --> Form Validation Class Initialized
INFO - 2018-03-09 00:40:46 --> Model Class Initialized
INFO - 2018-03-09 00:40:46 --> Controller Class Initialized
INFO - 2018-03-09 00:40:46 --> Model Class Initialized
INFO - 2018-03-09 00:40:46 --> Model Class Initialized
INFO - 2018-03-09 00:40:46 --> Model Class Initialized
INFO - 2018-03-09 00:40:46 --> Model Class Initialized
INFO - 2018-03-09 00:40:46 --> Model Class Initialized
DEBUG - 2018-03-09 00:40:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-09 00:41:05 --> Config Class Initialized
INFO - 2018-03-09 00:41:05 --> Hooks Class Initialized
DEBUG - 2018-03-09 00:41:05 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:41:05 --> Utf8 Class Initialized
INFO - 2018-03-09 00:41:05 --> URI Class Initialized
INFO - 2018-03-09 00:41:05 --> Router Class Initialized
INFO - 2018-03-09 00:41:05 --> Output Class Initialized
INFO - 2018-03-09 00:41:05 --> Security Class Initialized
DEBUG - 2018-03-09 00:41:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:41:05 --> Input Class Initialized
INFO - 2018-03-09 00:41:05 --> Language Class Initialized
INFO - 2018-03-09 00:41:05 --> Loader Class Initialized
INFO - 2018-03-09 00:41:05 --> Helper loaded: url_helper
INFO - 2018-03-09 00:41:05 --> Helper loaded: form_helper
INFO - 2018-03-09 00:41:05 --> Database Driver Class Initialized
DEBUG - 2018-03-09 00:41:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-09 00:41:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 00:41:05 --> Form Validation Class Initialized
INFO - 2018-03-09 00:41:05 --> Model Class Initialized
INFO - 2018-03-09 00:41:05 --> Controller Class Initialized
INFO - 2018-03-09 00:41:05 --> Model Class Initialized
INFO - 2018-03-09 00:41:05 --> Model Class Initialized
INFO - 2018-03-09 00:41:05 --> Model Class Initialized
INFO - 2018-03-09 00:41:05 --> Model Class Initialized
INFO - 2018-03-09 00:41:05 --> Model Class Initialized
DEBUG - 2018-03-09 00:41:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-09 00:41:06 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-09 00:41:06 --> Final output sent to browser
DEBUG - 2018-03-09 00:41:06 --> Total execution time: 0.2599
INFO - 2018-03-09 00:41:06 --> Config Class Initialized
INFO - 2018-03-09 00:41:06 --> Hooks Class Initialized
INFO - 2018-03-09 00:41:06 --> Config Class Initialized
INFO - 2018-03-09 00:41:06 --> Hooks Class Initialized
INFO - 2018-03-09 00:41:06 --> Config Class Initialized
INFO - 2018-03-09 00:41:06 --> Hooks Class Initialized
DEBUG - 2018-03-09 00:41:06 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:41:06 --> Utf8 Class Initialized
DEBUG - 2018-03-09 00:41:06 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:41:06 --> Utf8 Class Initialized
INFO - 2018-03-09 00:41:06 --> URI Class Initialized
INFO - 2018-03-09 00:41:06 --> Config Class Initialized
INFO - 2018-03-09 00:41:06 --> Hooks Class Initialized
DEBUG - 2018-03-09 00:41:06 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:41:06 --> Utf8 Class Initialized
INFO - 2018-03-09 00:41:06 --> URI Class Initialized
INFO - 2018-03-09 00:41:06 --> Router Class Initialized
INFO - 2018-03-09 00:41:06 --> URI Class Initialized
INFO - 2018-03-09 00:41:06 --> Router Class Initialized
DEBUG - 2018-03-09 00:41:06 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:41:06 --> Utf8 Class Initialized
INFO - 2018-03-09 00:41:06 --> Output Class Initialized
INFO - 2018-03-09 00:41:06 --> Router Class Initialized
INFO - 2018-03-09 00:41:06 --> URI Class Initialized
INFO - 2018-03-09 00:41:06 --> Output Class Initialized
INFO - 2018-03-09 00:41:06 --> Security Class Initialized
INFO - 2018-03-09 00:41:06 --> Output Class Initialized
INFO - 2018-03-09 00:41:06 --> Router Class Initialized
INFO - 2018-03-09 00:41:06 --> Security Class Initialized
DEBUG - 2018-03-09 00:41:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:41:06 --> Input Class Initialized
INFO - 2018-03-09 00:41:06 --> Security Class Initialized
DEBUG - 2018-03-09 00:41:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:41:06 --> Input Class Initialized
INFO - 2018-03-09 00:41:06 --> Output Class Initialized
INFO - 2018-03-09 00:41:06 --> Language Class Initialized
INFO - 2018-03-09 00:41:06 --> Language Class Initialized
DEBUG - 2018-03-09 00:41:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:41:06 --> Input Class Initialized
INFO - 2018-03-09 00:41:06 --> Security Class Initialized
ERROR - 2018-03-09 00:41:06 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-09 00:41:06 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-09 00:41:06 --> Language Class Initialized
DEBUG - 2018-03-09 00:41:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:41:06 --> Input Class Initialized
ERROR - 2018-03-09 00:41:06 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-09 00:41:06 --> Language Class Initialized
ERROR - 2018-03-09 00:41:06 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-09 00:41:06 --> Config Class Initialized
INFO - 2018-03-09 00:41:06 --> Hooks Class Initialized
INFO - 2018-03-09 00:41:06 --> Config Class Initialized
INFO - 2018-03-09 00:41:06 --> Hooks Class Initialized
INFO - 2018-03-09 00:41:06 --> Config Class Initialized
INFO - 2018-03-09 00:41:06 --> Hooks Class Initialized
DEBUG - 2018-03-09 00:41:06 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:41:06 --> Utf8 Class Initialized
DEBUG - 2018-03-09 00:41:06 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:41:06 --> URI Class Initialized
INFO - 2018-03-09 00:41:06 --> Utf8 Class Initialized
DEBUG - 2018-03-09 00:41:06 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:41:06 --> URI Class Initialized
INFO - 2018-03-09 00:41:06 --> Router Class Initialized
INFO - 2018-03-09 00:41:06 --> Utf8 Class Initialized
INFO - 2018-03-09 00:41:06 --> URI Class Initialized
INFO - 2018-03-09 00:41:06 --> Router Class Initialized
INFO - 2018-03-09 00:41:06 --> Output Class Initialized
INFO - 2018-03-09 00:41:06 --> Router Class Initialized
INFO - 2018-03-09 00:41:06 --> Security Class Initialized
INFO - 2018-03-09 00:41:06 --> Output Class Initialized
DEBUG - 2018-03-09 00:41:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:41:06 --> Output Class Initialized
INFO - 2018-03-09 00:41:06 --> Input Class Initialized
INFO - 2018-03-09 00:41:06 --> Security Class Initialized
INFO - 2018-03-09 00:41:06 --> Language Class Initialized
INFO - 2018-03-09 00:41:06 --> Security Class Initialized
DEBUG - 2018-03-09 00:41:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:41:06 --> Input Class Initialized
ERROR - 2018-03-09 00:41:06 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-03-09 00:41:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:41:06 --> Input Class Initialized
INFO - 2018-03-09 00:41:06 --> Language Class Initialized
INFO - 2018-03-09 00:41:06 --> Language Class Initialized
ERROR - 2018-03-09 00:41:06 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-09 00:41:06 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-09 00:41:06 --> Config Class Initialized
INFO - 2018-03-09 00:41:06 --> Hooks Class Initialized
DEBUG - 2018-03-09 00:41:06 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:41:06 --> Utf8 Class Initialized
INFO - 2018-03-09 00:41:06 --> URI Class Initialized
INFO - 2018-03-09 00:41:06 --> Router Class Initialized
INFO - 2018-03-09 00:41:06 --> Output Class Initialized
INFO - 2018-03-09 00:41:06 --> Security Class Initialized
DEBUG - 2018-03-09 00:41:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:41:06 --> Input Class Initialized
INFO - 2018-03-09 00:41:06 --> Language Class Initialized
INFO - 2018-03-09 00:41:06 --> Loader Class Initialized
INFO - 2018-03-09 00:41:06 --> Helper loaded: url_helper
INFO - 2018-03-09 00:41:06 --> Helper loaded: form_helper
INFO - 2018-03-09 00:41:06 --> Database Driver Class Initialized
DEBUG - 2018-03-09 00:41:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-09 00:41:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 00:41:06 --> Form Validation Class Initialized
INFO - 2018-03-09 00:41:06 --> Model Class Initialized
INFO - 2018-03-09 00:41:06 --> Controller Class Initialized
INFO - 2018-03-09 00:41:06 --> Model Class Initialized
INFO - 2018-03-09 00:41:06 --> Model Class Initialized
INFO - 2018-03-09 00:41:06 --> Model Class Initialized
INFO - 2018-03-09 00:41:06 --> Model Class Initialized
INFO - 2018-03-09 00:41:06 --> Model Class Initialized
DEBUG - 2018-03-09 00:41:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-09 00:41:15 --> Config Class Initialized
INFO - 2018-03-09 00:41:15 --> Hooks Class Initialized
DEBUG - 2018-03-09 00:41:15 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:41:15 --> Utf8 Class Initialized
INFO - 2018-03-09 00:41:15 --> URI Class Initialized
INFO - 2018-03-09 00:41:15 --> Router Class Initialized
INFO - 2018-03-09 00:41:15 --> Output Class Initialized
INFO - 2018-03-09 00:41:15 --> Security Class Initialized
DEBUG - 2018-03-09 00:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:41:15 --> Input Class Initialized
INFO - 2018-03-09 00:41:15 --> Language Class Initialized
INFO - 2018-03-09 00:41:15 --> Loader Class Initialized
INFO - 2018-03-09 00:41:15 --> Helper loaded: url_helper
INFO - 2018-03-09 00:41:15 --> Helper loaded: form_helper
INFO - 2018-03-09 00:41:15 --> Database Driver Class Initialized
DEBUG - 2018-03-09 00:41:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-09 00:41:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 00:41:15 --> Form Validation Class Initialized
INFO - 2018-03-09 00:41:15 --> Model Class Initialized
INFO - 2018-03-09 00:41:15 --> Controller Class Initialized
INFO - 2018-03-09 00:41:15 --> Model Class Initialized
INFO - 2018-03-09 00:41:15 --> Model Class Initialized
INFO - 2018-03-09 00:41:15 --> Model Class Initialized
INFO - 2018-03-09 00:41:15 --> Model Class Initialized
INFO - 2018-03-09 00:41:15 --> Model Class Initialized
DEBUG - 2018-03-09 00:41:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-09 00:41:27 --> Config Class Initialized
INFO - 2018-03-09 00:41:27 --> Hooks Class Initialized
DEBUG - 2018-03-09 00:41:27 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:41:27 --> Utf8 Class Initialized
INFO - 2018-03-09 00:41:27 --> URI Class Initialized
INFO - 2018-03-09 00:41:27 --> Router Class Initialized
INFO - 2018-03-09 00:41:27 --> Output Class Initialized
INFO - 2018-03-09 00:41:27 --> Security Class Initialized
DEBUG - 2018-03-09 00:41:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:41:27 --> Input Class Initialized
INFO - 2018-03-09 00:41:27 --> Language Class Initialized
INFO - 2018-03-09 00:41:27 --> Loader Class Initialized
INFO - 2018-03-09 00:41:27 --> Helper loaded: url_helper
INFO - 2018-03-09 00:41:27 --> Helper loaded: form_helper
INFO - 2018-03-09 00:41:27 --> Database Driver Class Initialized
DEBUG - 2018-03-09 00:41:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-09 00:41:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 00:41:27 --> Form Validation Class Initialized
INFO - 2018-03-09 00:41:27 --> Model Class Initialized
INFO - 2018-03-09 00:41:27 --> Controller Class Initialized
INFO - 2018-03-09 00:41:27 --> Model Class Initialized
INFO - 2018-03-09 00:41:27 --> Model Class Initialized
INFO - 2018-03-09 00:41:27 --> Model Class Initialized
INFO - 2018-03-09 00:41:27 --> Model Class Initialized
INFO - 2018-03-09 00:41:27 --> Model Class Initialized
DEBUG - 2018-03-09 00:41:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-09 00:41:27 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-09 00:41:27 --> Final output sent to browser
DEBUG - 2018-03-09 00:41:27 --> Total execution time: 0.2701
INFO - 2018-03-09 00:41:27 --> Config Class Initialized
INFO - 2018-03-09 00:41:27 --> Hooks Class Initialized
DEBUG - 2018-03-09 00:41:27 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:41:27 --> Utf8 Class Initialized
INFO - 2018-03-09 00:41:27 --> URI Class Initialized
INFO - 2018-03-09 00:41:27 --> Router Class Initialized
INFO - 2018-03-09 00:41:27 --> Output Class Initialized
INFO - 2018-03-09 00:41:27 --> Security Class Initialized
DEBUG - 2018-03-09 00:41:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:41:27 --> Input Class Initialized
INFO - 2018-03-09 00:41:27 --> Language Class Initialized
INFO - 2018-03-09 00:41:27 --> Loader Class Initialized
INFO - 2018-03-09 00:41:27 --> Helper loaded: url_helper
INFO - 2018-03-09 00:41:27 --> Helper loaded: form_helper
INFO - 2018-03-09 00:41:27 --> Database Driver Class Initialized
DEBUG - 2018-03-09 00:41:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-09 00:41:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 00:41:27 --> Form Validation Class Initialized
INFO - 2018-03-09 00:41:27 --> Model Class Initialized
INFO - 2018-03-09 00:41:27 --> Controller Class Initialized
INFO - 2018-03-09 00:41:27 --> Model Class Initialized
INFO - 2018-03-09 00:41:27 --> Model Class Initialized
INFO - 2018-03-09 00:41:27 --> Model Class Initialized
INFO - 2018-03-09 00:41:27 --> Model Class Initialized
INFO - 2018-03-09 00:41:27 --> Model Class Initialized
DEBUG - 2018-03-09 00:41:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-09 00:41:32 --> Config Class Initialized
INFO - 2018-03-09 00:41:32 --> Hooks Class Initialized
DEBUG - 2018-03-09 00:41:32 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:41:32 --> Utf8 Class Initialized
INFO - 2018-03-09 00:41:32 --> URI Class Initialized
INFO - 2018-03-09 00:41:32 --> Router Class Initialized
INFO - 2018-03-09 00:41:32 --> Output Class Initialized
INFO - 2018-03-09 00:41:32 --> Security Class Initialized
DEBUG - 2018-03-09 00:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:41:32 --> Input Class Initialized
INFO - 2018-03-09 00:41:32 --> Language Class Initialized
INFO - 2018-03-09 00:41:32 --> Loader Class Initialized
INFO - 2018-03-09 00:41:32 --> Helper loaded: url_helper
INFO - 2018-03-09 00:41:32 --> Helper loaded: form_helper
INFO - 2018-03-09 00:41:32 --> Database Driver Class Initialized
DEBUG - 2018-03-09 00:41:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-09 00:41:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 00:41:32 --> Form Validation Class Initialized
INFO - 2018-03-09 00:41:32 --> Model Class Initialized
INFO - 2018-03-09 00:41:32 --> Controller Class Initialized
INFO - 2018-03-09 00:41:32 --> Model Class Initialized
INFO - 2018-03-09 00:41:32 --> Model Class Initialized
INFO - 2018-03-09 00:41:32 --> Model Class Initialized
INFO - 2018-03-09 00:41:32 --> Model Class Initialized
INFO - 2018-03-09 00:41:32 --> Model Class Initialized
DEBUG - 2018-03-09 00:41:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-09 00:41:36 --> Config Class Initialized
INFO - 2018-03-09 00:41:36 --> Hooks Class Initialized
DEBUG - 2018-03-09 00:41:36 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:41:36 --> Utf8 Class Initialized
INFO - 2018-03-09 00:41:36 --> URI Class Initialized
INFO - 2018-03-09 00:41:36 --> Router Class Initialized
INFO - 2018-03-09 00:41:36 --> Output Class Initialized
INFO - 2018-03-09 00:41:36 --> Security Class Initialized
DEBUG - 2018-03-09 00:41:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:41:36 --> Input Class Initialized
INFO - 2018-03-09 00:41:36 --> Language Class Initialized
INFO - 2018-03-09 00:41:36 --> Loader Class Initialized
INFO - 2018-03-09 00:41:36 --> Helper loaded: url_helper
INFO - 2018-03-09 00:41:36 --> Helper loaded: form_helper
INFO - 2018-03-09 00:41:36 --> Database Driver Class Initialized
DEBUG - 2018-03-09 00:41:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-09 00:41:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 00:41:36 --> Form Validation Class Initialized
INFO - 2018-03-09 00:41:36 --> Model Class Initialized
INFO - 2018-03-09 00:41:36 --> Controller Class Initialized
INFO - 2018-03-09 00:41:36 --> Model Class Initialized
INFO - 2018-03-09 00:41:36 --> Model Class Initialized
INFO - 2018-03-09 00:41:36 --> Model Class Initialized
INFO - 2018-03-09 00:41:36 --> Model Class Initialized
INFO - 2018-03-09 00:41:36 --> Model Class Initialized
DEBUG - 2018-03-09 00:41:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-09 00:41:36 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-09 00:41:36 --> Final output sent to browser
DEBUG - 2018-03-09 00:41:36 --> Total execution time: 0.0757
INFO - 2018-03-09 00:41:36 --> Config Class Initialized
INFO - 2018-03-09 00:41:36 --> Hooks Class Initialized
DEBUG - 2018-03-09 00:41:36 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:41:36 --> Utf8 Class Initialized
INFO - 2018-03-09 00:41:36 --> URI Class Initialized
INFO - 2018-03-09 00:41:36 --> Router Class Initialized
INFO - 2018-03-09 00:41:36 --> Output Class Initialized
INFO - 2018-03-09 00:41:36 --> Security Class Initialized
DEBUG - 2018-03-09 00:41:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:41:36 --> Input Class Initialized
INFO - 2018-03-09 00:41:36 --> Language Class Initialized
INFO - 2018-03-09 00:41:36 --> Loader Class Initialized
INFO - 2018-03-09 00:41:36 --> Helper loaded: url_helper
INFO - 2018-03-09 00:41:36 --> Helper loaded: form_helper
INFO - 2018-03-09 00:41:36 --> Database Driver Class Initialized
DEBUG - 2018-03-09 00:41:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-09 00:41:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 00:41:36 --> Form Validation Class Initialized
INFO - 2018-03-09 00:41:36 --> Model Class Initialized
INFO - 2018-03-09 00:41:36 --> Controller Class Initialized
INFO - 2018-03-09 00:41:36 --> Model Class Initialized
INFO - 2018-03-09 00:41:36 --> Model Class Initialized
INFO - 2018-03-09 00:41:36 --> Model Class Initialized
INFO - 2018-03-09 00:41:36 --> Model Class Initialized
INFO - 2018-03-09 00:41:36 --> Model Class Initialized
DEBUG - 2018-03-09 00:41:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-09 00:41:37 --> Config Class Initialized
INFO - 2018-03-09 00:41:37 --> Hooks Class Initialized
DEBUG - 2018-03-09 00:41:37 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:41:37 --> Utf8 Class Initialized
INFO - 2018-03-09 00:41:37 --> URI Class Initialized
INFO - 2018-03-09 00:41:37 --> Router Class Initialized
INFO - 2018-03-09 00:41:37 --> Output Class Initialized
INFO - 2018-03-09 00:41:37 --> Security Class Initialized
DEBUG - 2018-03-09 00:41:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:41:37 --> Input Class Initialized
INFO - 2018-03-09 00:41:37 --> Language Class Initialized
INFO - 2018-03-09 00:41:37 --> Loader Class Initialized
INFO - 2018-03-09 00:41:37 --> Helper loaded: url_helper
INFO - 2018-03-09 00:41:37 --> Helper loaded: form_helper
INFO - 2018-03-09 00:41:37 --> Database Driver Class Initialized
DEBUG - 2018-03-09 00:41:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-09 00:41:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 00:41:37 --> Form Validation Class Initialized
INFO - 2018-03-09 00:41:37 --> Model Class Initialized
INFO - 2018-03-09 00:41:37 --> Controller Class Initialized
INFO - 2018-03-09 00:41:37 --> Model Class Initialized
INFO - 2018-03-09 00:41:37 --> Model Class Initialized
INFO - 2018-03-09 00:41:37 --> Model Class Initialized
INFO - 2018-03-09 00:41:37 --> Model Class Initialized
INFO - 2018-03-09 00:41:37 --> Model Class Initialized
DEBUG - 2018-03-09 00:41:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-09 00:41:37 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-09 00:41:37 --> Final output sent to browser
DEBUG - 2018-03-09 00:41:37 --> Total execution time: 0.0593
INFO - 2018-03-09 00:41:37 --> Config Class Initialized
INFO - 2018-03-09 00:41:37 --> Hooks Class Initialized
DEBUG - 2018-03-09 00:41:37 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:41:37 --> Utf8 Class Initialized
INFO - 2018-03-09 00:41:37 --> URI Class Initialized
INFO - 2018-03-09 00:41:37 --> Router Class Initialized
INFO - 2018-03-09 00:41:37 --> Output Class Initialized
INFO - 2018-03-09 00:41:37 --> Security Class Initialized
DEBUG - 2018-03-09 00:41:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:41:37 --> Input Class Initialized
INFO - 2018-03-09 00:41:37 --> Language Class Initialized
INFO - 2018-03-09 00:41:37 --> Loader Class Initialized
INFO - 2018-03-09 00:41:37 --> Helper loaded: url_helper
INFO - 2018-03-09 00:41:37 --> Helper loaded: form_helper
INFO - 2018-03-09 00:41:37 --> Database Driver Class Initialized
DEBUG - 2018-03-09 00:41:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-09 00:41:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 00:41:37 --> Form Validation Class Initialized
INFO - 2018-03-09 00:41:37 --> Model Class Initialized
INFO - 2018-03-09 00:41:37 --> Controller Class Initialized
INFO - 2018-03-09 00:41:37 --> Model Class Initialized
INFO - 2018-03-09 00:41:37 --> Model Class Initialized
INFO - 2018-03-09 00:41:37 --> Model Class Initialized
INFO - 2018-03-09 00:41:37 --> Model Class Initialized
INFO - 2018-03-09 00:41:37 --> Model Class Initialized
DEBUG - 2018-03-09 00:41:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-09 00:41:43 --> Config Class Initialized
INFO - 2018-03-09 00:41:43 --> Hooks Class Initialized
INFO - 2018-03-09 00:41:43 --> Config Class Initialized
INFO - 2018-03-09 00:41:43 --> Config Class Initialized
INFO - 2018-03-09 00:41:43 --> Hooks Class Initialized
INFO - 2018-03-09 00:41:43 --> Hooks Class Initialized
DEBUG - 2018-03-09 00:41:43 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:41:43 --> Utf8 Class Initialized
INFO - 2018-03-09 00:41:43 --> URI Class Initialized
DEBUG - 2018-03-09 00:41:43 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:41:43 --> Utf8 Class Initialized
DEBUG - 2018-03-09 00:41:43 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:41:43 --> Router Class Initialized
INFO - 2018-03-09 00:41:43 --> Utf8 Class Initialized
INFO - 2018-03-09 00:41:43 --> URI Class Initialized
INFO - 2018-03-09 00:41:43 --> Output Class Initialized
INFO - 2018-03-09 00:41:43 --> URI Class Initialized
INFO - 2018-03-09 00:41:43 --> Security Class Initialized
INFO - 2018-03-09 00:41:43 --> Router Class Initialized
INFO - 2018-03-09 00:41:43 --> Router Class Initialized
DEBUG - 2018-03-09 00:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:41:43 --> Input Class Initialized
INFO - 2018-03-09 00:41:43 --> Language Class Initialized
INFO - 2018-03-09 00:41:43 --> Output Class Initialized
INFO - 2018-03-09 00:41:43 --> Output Class Initialized
ERROR - 2018-03-09 00:41:43 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-09 00:41:43 --> Security Class Initialized
INFO - 2018-03-09 00:41:43 --> Security Class Initialized
DEBUG - 2018-03-09 00:41:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 00:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:41:43 --> Input Class Initialized
INFO - 2018-03-09 00:41:43 --> Input Class Initialized
INFO - 2018-03-09 00:41:43 --> Language Class Initialized
INFO - 2018-03-09 00:41:43 --> Language Class Initialized
ERROR - 2018-03-09 00:41:43 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-09 00:41:43 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-09 00:41:52 --> Config Class Initialized
INFO - 2018-03-09 00:41:52 --> Hooks Class Initialized
DEBUG - 2018-03-09 00:41:52 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:41:52 --> Utf8 Class Initialized
INFO - 2018-03-09 00:41:52 --> URI Class Initialized
INFO - 2018-03-09 00:41:52 --> Router Class Initialized
INFO - 2018-03-09 00:41:52 --> Output Class Initialized
INFO - 2018-03-09 00:41:52 --> Security Class Initialized
DEBUG - 2018-03-09 00:41:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:41:52 --> Input Class Initialized
INFO - 2018-03-09 00:41:52 --> Language Class Initialized
INFO - 2018-03-09 00:41:52 --> Loader Class Initialized
INFO - 2018-03-09 00:41:52 --> Helper loaded: url_helper
INFO - 2018-03-09 00:41:52 --> Helper loaded: form_helper
INFO - 2018-03-09 00:41:52 --> Database Driver Class Initialized
DEBUG - 2018-03-09 00:41:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-09 00:41:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 00:41:53 --> Form Validation Class Initialized
INFO - 2018-03-09 00:41:53 --> Model Class Initialized
INFO - 2018-03-09 00:41:53 --> Controller Class Initialized
INFO - 2018-03-09 00:41:53 --> Model Class Initialized
INFO - 2018-03-09 00:41:53 --> Model Class Initialized
INFO - 2018-03-09 00:41:53 --> Model Class Initialized
INFO - 2018-03-09 00:41:53 --> Model Class Initialized
INFO - 2018-03-09 00:41:53 --> Model Class Initialized
DEBUG - 2018-03-09 00:41:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-09 00:41:53 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-09 00:41:53 --> Final output sent to browser
DEBUG - 2018-03-09 00:41:53 --> Total execution time: 0.0947
INFO - 2018-03-09 00:41:54 --> Config Class Initialized
INFO - 2018-03-09 00:41:54 --> Hooks Class Initialized
DEBUG - 2018-03-09 00:41:54 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:41:54 --> Utf8 Class Initialized
INFO - 2018-03-09 00:41:54 --> URI Class Initialized
INFO - 2018-03-09 00:41:54 --> Router Class Initialized
INFO - 2018-03-09 00:41:54 --> Output Class Initialized
INFO - 2018-03-09 00:41:54 --> Security Class Initialized
DEBUG - 2018-03-09 00:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:41:54 --> Input Class Initialized
INFO - 2018-03-09 00:41:54 --> Language Class Initialized
INFO - 2018-03-09 00:41:54 --> Loader Class Initialized
INFO - 2018-03-09 00:41:54 --> Helper loaded: url_helper
INFO - 2018-03-09 00:41:54 --> Helper loaded: form_helper
INFO - 2018-03-09 00:41:54 --> Database Driver Class Initialized
DEBUG - 2018-03-09 00:41:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-09 00:41:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 00:41:54 --> Form Validation Class Initialized
INFO - 2018-03-09 00:41:54 --> Model Class Initialized
INFO - 2018-03-09 00:41:54 --> Controller Class Initialized
INFO - 2018-03-09 00:41:54 --> Model Class Initialized
INFO - 2018-03-09 00:41:54 --> Model Class Initialized
INFO - 2018-03-09 00:41:54 --> Model Class Initialized
INFO - 2018-03-09 00:41:54 --> Model Class Initialized
INFO - 2018-03-09 00:41:54 --> Model Class Initialized
DEBUG - 2018-03-09 00:41:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-09 00:41:56 --> Config Class Initialized
INFO - 2018-03-09 00:41:56 --> Hooks Class Initialized
DEBUG - 2018-03-09 00:41:56 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:41:56 --> Utf8 Class Initialized
INFO - 2018-03-09 00:41:56 --> URI Class Initialized
INFO - 2018-03-09 00:41:56 --> Router Class Initialized
INFO - 2018-03-09 00:41:56 --> Output Class Initialized
INFO - 2018-03-09 00:41:56 --> Security Class Initialized
DEBUG - 2018-03-09 00:41:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:41:56 --> Input Class Initialized
INFO - 2018-03-09 00:41:56 --> Language Class Initialized
INFO - 2018-03-09 00:41:56 --> Loader Class Initialized
INFO - 2018-03-09 00:41:56 --> Helper loaded: url_helper
INFO - 2018-03-09 00:41:56 --> Helper loaded: form_helper
INFO - 2018-03-09 00:41:56 --> Database Driver Class Initialized
DEBUG - 2018-03-09 00:41:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-09 00:41:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 00:41:56 --> Form Validation Class Initialized
INFO - 2018-03-09 00:41:56 --> Model Class Initialized
INFO - 2018-03-09 00:41:56 --> Controller Class Initialized
INFO - 2018-03-09 00:41:56 --> Model Class Initialized
INFO - 2018-03-09 00:41:56 --> Model Class Initialized
INFO - 2018-03-09 00:41:56 --> Model Class Initialized
INFO - 2018-03-09 00:41:56 --> Model Class Initialized
INFO - 2018-03-09 00:41:56 --> Model Class Initialized
DEBUG - 2018-03-09 00:41:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-09 00:41:56 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-09 00:41:56 --> Final output sent to browser
DEBUG - 2018-03-09 00:41:56 --> Total execution time: 0.0546
INFO - 2018-03-09 00:41:56 --> Config Class Initialized
INFO - 2018-03-09 00:41:56 --> Hooks Class Initialized
DEBUG - 2018-03-09 00:41:56 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:41:56 --> Utf8 Class Initialized
INFO - 2018-03-09 00:41:56 --> URI Class Initialized
INFO - 2018-03-09 00:41:56 --> Router Class Initialized
INFO - 2018-03-09 00:41:56 --> Output Class Initialized
INFO - 2018-03-09 00:41:56 --> Security Class Initialized
DEBUG - 2018-03-09 00:41:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:41:56 --> Input Class Initialized
INFO - 2018-03-09 00:41:56 --> Language Class Initialized
INFO - 2018-03-09 00:41:56 --> Loader Class Initialized
INFO - 2018-03-09 00:41:56 --> Helper loaded: url_helper
INFO - 2018-03-09 00:41:56 --> Helper loaded: form_helper
INFO - 2018-03-09 00:41:56 --> Database Driver Class Initialized
DEBUG - 2018-03-09 00:41:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-09 00:41:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 00:41:56 --> Form Validation Class Initialized
INFO - 2018-03-09 00:41:56 --> Model Class Initialized
INFO - 2018-03-09 00:41:56 --> Controller Class Initialized
INFO - 2018-03-09 00:41:56 --> Model Class Initialized
INFO - 2018-03-09 00:41:56 --> Model Class Initialized
INFO - 2018-03-09 00:41:56 --> Model Class Initialized
INFO - 2018-03-09 00:41:56 --> Model Class Initialized
INFO - 2018-03-09 00:41:56 --> Model Class Initialized
DEBUG - 2018-03-09 00:41:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-09 00:45:35 --> Config Class Initialized
INFO - 2018-03-09 00:45:35 --> Hooks Class Initialized
DEBUG - 2018-03-09 00:45:35 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:45:35 --> Utf8 Class Initialized
INFO - 2018-03-09 00:45:35 --> URI Class Initialized
INFO - 2018-03-09 00:45:35 --> Router Class Initialized
INFO - 2018-03-09 00:45:35 --> Output Class Initialized
INFO - 2018-03-09 00:45:35 --> Security Class Initialized
DEBUG - 2018-03-09 00:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:45:35 --> Input Class Initialized
INFO - 2018-03-09 00:45:35 --> Language Class Initialized
INFO - 2018-03-09 00:45:35 --> Loader Class Initialized
INFO - 2018-03-09 00:45:35 --> Helper loaded: url_helper
INFO - 2018-03-09 00:45:35 --> Helper loaded: form_helper
INFO - 2018-03-09 00:45:35 --> Database Driver Class Initialized
DEBUG - 2018-03-09 00:45:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-09 00:45:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 00:45:35 --> Form Validation Class Initialized
INFO - 2018-03-09 00:45:35 --> Model Class Initialized
INFO - 2018-03-09 00:45:35 --> Controller Class Initialized
INFO - 2018-03-09 00:45:35 --> Model Class Initialized
INFO - 2018-03-09 00:45:35 --> Model Class Initialized
INFO - 2018-03-09 00:45:35 --> Model Class Initialized
INFO - 2018-03-09 00:45:35 --> Model Class Initialized
INFO - 2018-03-09 00:45:35 --> Model Class Initialized
DEBUG - 2018-03-09 00:45:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-09 00:45:35 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-09 00:45:35 --> Final output sent to browser
DEBUG - 2018-03-09 00:45:35 --> Total execution time: 0.0725
INFO - 2018-03-09 00:45:35 --> Config Class Initialized
INFO - 2018-03-09 00:45:35 --> Hooks Class Initialized
INFO - 2018-03-09 00:45:35 --> Config Class Initialized
INFO - 2018-03-09 00:45:35 --> Hooks Class Initialized
DEBUG - 2018-03-09 00:45:35 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:45:35 --> Utf8 Class Initialized
INFO - 2018-03-09 00:45:35 --> Config Class Initialized
DEBUG - 2018-03-09 00:45:35 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:45:35 --> Hooks Class Initialized
INFO - 2018-03-09 00:45:35 --> Utf8 Class Initialized
INFO - 2018-03-09 00:45:35 --> URI Class Initialized
INFO - 2018-03-09 00:45:35 --> Config Class Initialized
INFO - 2018-03-09 00:45:35 --> Hooks Class Initialized
INFO - 2018-03-09 00:45:35 --> URI Class Initialized
INFO - 2018-03-09 00:45:35 --> Router Class Initialized
DEBUG - 2018-03-09 00:45:35 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:45:35 --> Utf8 Class Initialized
INFO - 2018-03-09 00:45:35 --> Router Class Initialized
DEBUG - 2018-03-09 00:45:35 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:45:35 --> Output Class Initialized
INFO - 2018-03-09 00:45:35 --> Utf8 Class Initialized
INFO - 2018-03-09 00:45:35 --> URI Class Initialized
INFO - 2018-03-09 00:45:35 --> Output Class Initialized
INFO - 2018-03-09 00:45:35 --> Security Class Initialized
INFO - 2018-03-09 00:45:35 --> URI Class Initialized
INFO - 2018-03-09 00:45:35 --> Security Class Initialized
INFO - 2018-03-09 00:45:35 --> Router Class Initialized
DEBUG - 2018-03-09 00:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:45:35 --> Input Class Initialized
INFO - 2018-03-09 00:45:35 --> Router Class Initialized
DEBUG - 2018-03-09 00:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:45:35 --> Input Class Initialized
INFO - 2018-03-09 00:45:35 --> Output Class Initialized
INFO - 2018-03-09 00:45:35 --> Language Class Initialized
INFO - 2018-03-09 00:45:35 --> Language Class Initialized
INFO - 2018-03-09 00:45:35 --> Output Class Initialized
INFO - 2018-03-09 00:45:35 --> Security Class Initialized
ERROR - 2018-03-09 00:45:35 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-09 00:45:35 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-09 00:45:35 --> Security Class Initialized
DEBUG - 2018-03-09 00:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:45:35 --> Input Class Initialized
INFO - 2018-03-09 00:45:35 --> Language Class Initialized
DEBUG - 2018-03-09 00:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:45:35 --> Input Class Initialized
INFO - 2018-03-09 00:45:35 --> Language Class Initialized
ERROR - 2018-03-09 00:45:35 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-09 00:45:35 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-09 00:45:35 --> Config Class Initialized
INFO - 2018-03-09 00:45:35 --> Hooks Class Initialized
INFO - 2018-03-09 00:45:35 --> Config Class Initialized
INFO - 2018-03-09 00:45:35 --> Config Class Initialized
INFO - 2018-03-09 00:45:35 --> Hooks Class Initialized
INFO - 2018-03-09 00:45:35 --> Hooks Class Initialized
DEBUG - 2018-03-09 00:45:35 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:45:35 --> Utf8 Class Initialized
DEBUG - 2018-03-09 00:45:35 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 00:45:35 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:45:35 --> Utf8 Class Initialized
INFO - 2018-03-09 00:45:35 --> Utf8 Class Initialized
INFO - 2018-03-09 00:45:35 --> URI Class Initialized
INFO - 2018-03-09 00:45:35 --> URI Class Initialized
INFO - 2018-03-09 00:45:35 --> URI Class Initialized
INFO - 2018-03-09 00:45:35 --> Router Class Initialized
INFO - 2018-03-09 00:45:35 --> Router Class Initialized
INFO - 2018-03-09 00:45:35 --> Router Class Initialized
INFO - 2018-03-09 00:45:35 --> Output Class Initialized
INFO - 2018-03-09 00:45:35 --> Output Class Initialized
INFO - 2018-03-09 00:45:35 --> Output Class Initialized
INFO - 2018-03-09 00:45:35 --> Security Class Initialized
INFO - 2018-03-09 00:45:35 --> Security Class Initialized
INFO - 2018-03-09 00:45:35 --> Security Class Initialized
DEBUG - 2018-03-09 00:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:45:35 --> Input Class Initialized
DEBUG - 2018-03-09 00:45:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 00:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:45:35 --> Input Class Initialized
INFO - 2018-03-09 00:45:35 --> Input Class Initialized
INFO - 2018-03-09 00:45:35 --> Language Class Initialized
INFO - 2018-03-09 00:45:35 --> Language Class Initialized
INFO - 2018-03-09 00:45:35 --> Language Class Initialized
ERROR - 2018-03-09 00:45:35 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-09 00:45:35 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-09 00:45:35 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-09 00:45:35 --> Config Class Initialized
INFO - 2018-03-09 00:45:35 --> Hooks Class Initialized
DEBUG - 2018-03-09 00:45:35 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:45:35 --> Utf8 Class Initialized
INFO - 2018-03-09 00:45:35 --> URI Class Initialized
INFO - 2018-03-09 00:45:35 --> Router Class Initialized
INFO - 2018-03-09 00:45:35 --> Output Class Initialized
INFO - 2018-03-09 00:45:35 --> Security Class Initialized
DEBUG - 2018-03-09 00:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:45:35 --> Input Class Initialized
INFO - 2018-03-09 00:45:35 --> Language Class Initialized
INFO - 2018-03-09 00:45:35 --> Loader Class Initialized
INFO - 2018-03-09 00:45:35 --> Helper loaded: url_helper
INFO - 2018-03-09 00:45:35 --> Helper loaded: form_helper
INFO - 2018-03-09 00:45:35 --> Database Driver Class Initialized
DEBUG - 2018-03-09 00:45:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-09 00:45:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 00:45:35 --> Form Validation Class Initialized
INFO - 2018-03-09 00:45:35 --> Model Class Initialized
INFO - 2018-03-09 00:45:35 --> Controller Class Initialized
INFO - 2018-03-09 00:45:35 --> Model Class Initialized
INFO - 2018-03-09 00:45:35 --> Model Class Initialized
INFO - 2018-03-09 00:45:35 --> Model Class Initialized
INFO - 2018-03-09 00:45:35 --> Model Class Initialized
INFO - 2018-03-09 00:45:35 --> Model Class Initialized
DEBUG - 2018-03-09 00:45:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-09 00:49:37 --> Config Class Initialized
INFO - 2018-03-09 00:49:37 --> Hooks Class Initialized
DEBUG - 2018-03-09 00:49:37 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:49:37 --> Utf8 Class Initialized
INFO - 2018-03-09 00:49:37 --> URI Class Initialized
INFO - 2018-03-09 00:49:37 --> Router Class Initialized
INFO - 2018-03-09 00:49:37 --> Output Class Initialized
INFO - 2018-03-09 00:49:37 --> Security Class Initialized
DEBUG - 2018-03-09 00:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:49:37 --> Input Class Initialized
INFO - 2018-03-09 00:49:37 --> Language Class Initialized
INFO - 2018-03-09 00:49:37 --> Loader Class Initialized
INFO - 2018-03-09 00:49:37 --> Helper loaded: url_helper
INFO - 2018-03-09 00:49:37 --> Helper loaded: form_helper
INFO - 2018-03-09 00:49:37 --> Database Driver Class Initialized
DEBUG - 2018-03-09 00:49:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-09 00:49:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 00:49:37 --> Form Validation Class Initialized
INFO - 2018-03-09 00:49:37 --> Model Class Initialized
INFO - 2018-03-09 00:49:37 --> Controller Class Initialized
INFO - 2018-03-09 00:49:37 --> Model Class Initialized
INFO - 2018-03-09 00:49:37 --> Model Class Initialized
INFO - 2018-03-09 00:49:37 --> Model Class Initialized
INFO - 2018-03-09 00:49:37 --> Model Class Initialized
INFO - 2018-03-09 00:49:37 --> Model Class Initialized
DEBUG - 2018-03-09 00:49:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-09 00:49:37 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-09 00:49:37 --> Final output sent to browser
DEBUG - 2018-03-09 00:49:37 --> Total execution time: 0.1564
INFO - 2018-03-09 00:49:37 --> Config Class Initialized
INFO - 2018-03-09 00:49:37 --> Hooks Class Initialized
INFO - 2018-03-09 00:49:37 --> Config Class Initialized
INFO - 2018-03-09 00:49:37 --> Hooks Class Initialized
DEBUG - 2018-03-09 00:49:37 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:49:37 --> Utf8 Class Initialized
DEBUG - 2018-03-09 00:49:37 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:49:37 --> Utf8 Class Initialized
INFO - 2018-03-09 00:49:37 --> Config Class Initialized
INFO - 2018-03-09 00:49:37 --> URI Class Initialized
INFO - 2018-03-09 00:49:37 --> Hooks Class Initialized
INFO - 2018-03-09 00:49:37 --> URI Class Initialized
INFO - 2018-03-09 00:49:37 --> Router Class Initialized
INFO - 2018-03-09 00:49:37 --> Router Class Initialized
DEBUG - 2018-03-09 00:49:37 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:49:37 --> Utf8 Class Initialized
INFO - 2018-03-09 00:49:37 --> Output Class Initialized
INFO - 2018-03-09 00:49:37 --> Output Class Initialized
INFO - 2018-03-09 00:49:37 --> URI Class Initialized
INFO - 2018-03-09 00:49:37 --> Config Class Initialized
INFO - 2018-03-09 00:49:37 --> Hooks Class Initialized
INFO - 2018-03-09 00:49:37 --> Security Class Initialized
INFO - 2018-03-09 00:49:37 --> Security Class Initialized
INFO - 2018-03-09 00:49:37 --> Router Class Initialized
DEBUG - 2018-03-09 00:49:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 00:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:49:37 --> Input Class Initialized
INFO - 2018-03-09 00:49:37 --> Input Class Initialized
INFO - 2018-03-09 00:49:37 --> Language Class Initialized
DEBUG - 2018-03-09 00:49:37 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:49:37 --> Output Class Initialized
INFO - 2018-03-09 00:49:37 --> Language Class Initialized
INFO - 2018-03-09 00:49:37 --> Utf8 Class Initialized
INFO - 2018-03-09 00:49:37 --> URI Class Initialized
ERROR - 2018-03-09 00:49:37 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-09 00:49:37 --> Security Class Initialized
ERROR - 2018-03-09 00:49:37 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-09 00:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:49:37 --> Router Class Initialized
INFO - 2018-03-09 00:49:37 --> Input Class Initialized
INFO - 2018-03-09 00:49:37 --> Language Class Initialized
INFO - 2018-03-09 00:49:37 --> Output Class Initialized
ERROR - 2018-03-09 00:49:37 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-09 00:49:37 --> Security Class Initialized
DEBUG - 2018-03-09 00:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:49:37 --> Input Class Initialized
INFO - 2018-03-09 00:49:37 --> Language Class Initialized
ERROR - 2018-03-09 00:49:37 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-09 00:49:37 --> Config Class Initialized
INFO - 2018-03-09 00:49:37 --> Hooks Class Initialized
INFO - 2018-03-09 00:49:37 --> Config Class Initialized
INFO - 2018-03-09 00:49:37 --> Hooks Class Initialized
INFO - 2018-03-09 00:49:37 --> Config Class Initialized
INFO - 2018-03-09 00:49:37 --> Hooks Class Initialized
DEBUG - 2018-03-09 00:49:37 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:49:37 --> Utf8 Class Initialized
DEBUG - 2018-03-09 00:49:37 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:49:37 --> URI Class Initialized
INFO - 2018-03-09 00:49:37 --> Utf8 Class Initialized
DEBUG - 2018-03-09 00:49:37 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:49:37 --> Utf8 Class Initialized
INFO - 2018-03-09 00:49:37 --> URI Class Initialized
INFO - 2018-03-09 00:49:37 --> Router Class Initialized
INFO - 2018-03-09 00:49:37 --> URI Class Initialized
INFO - 2018-03-09 00:49:37 --> Router Class Initialized
INFO - 2018-03-09 00:49:37 --> Output Class Initialized
INFO - 2018-03-09 00:49:37 --> Router Class Initialized
INFO - 2018-03-09 00:49:37 --> Security Class Initialized
INFO - 2018-03-09 00:49:37 --> Output Class Initialized
INFO - 2018-03-09 00:49:37 --> Output Class Initialized
DEBUG - 2018-03-09 00:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:49:37 --> Security Class Initialized
INFO - 2018-03-09 00:49:37 --> Input Class Initialized
INFO - 2018-03-09 00:49:37 --> Security Class Initialized
INFO - 2018-03-09 00:49:37 --> Language Class Initialized
DEBUG - 2018-03-09 00:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:49:37 --> Input Class Initialized
DEBUG - 2018-03-09 00:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:49:37 --> Language Class Initialized
INFO - 2018-03-09 00:49:37 --> Input Class Initialized
ERROR - 2018-03-09 00:49:37 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-09 00:49:37 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-09 00:49:37 --> Language Class Initialized
ERROR - 2018-03-09 00:49:37 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-09 00:49:37 --> Config Class Initialized
INFO - 2018-03-09 00:49:37 --> Hooks Class Initialized
DEBUG - 2018-03-09 00:49:37 --> UTF-8 Support Enabled
INFO - 2018-03-09 00:49:37 --> Utf8 Class Initialized
INFO - 2018-03-09 00:49:37 --> URI Class Initialized
INFO - 2018-03-09 00:49:37 --> Router Class Initialized
INFO - 2018-03-09 00:49:37 --> Output Class Initialized
INFO - 2018-03-09 00:49:37 --> Security Class Initialized
DEBUG - 2018-03-09 00:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 00:49:37 --> Input Class Initialized
INFO - 2018-03-09 00:49:37 --> Language Class Initialized
INFO - 2018-03-09 00:49:37 --> Loader Class Initialized
INFO - 2018-03-09 00:49:37 --> Helper loaded: url_helper
INFO - 2018-03-09 00:49:37 --> Helper loaded: form_helper
INFO - 2018-03-09 00:49:37 --> Database Driver Class Initialized
DEBUG - 2018-03-09 00:49:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-09 00:49:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 00:49:37 --> Form Validation Class Initialized
INFO - 2018-03-09 00:49:37 --> Model Class Initialized
INFO - 2018-03-09 00:49:37 --> Controller Class Initialized
INFO - 2018-03-09 00:49:37 --> Model Class Initialized
INFO - 2018-03-09 00:49:37 --> Model Class Initialized
INFO - 2018-03-09 00:49:37 --> Model Class Initialized
INFO - 2018-03-09 00:49:37 --> Model Class Initialized
INFO - 2018-03-09 00:49:37 --> Model Class Initialized
DEBUG - 2018-03-09 00:49:37 --> Form_validation class already loaded. Second attempt ignored.
