<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-03-21 00:03:21 --> Config Class Initialized
INFO - 2018-03-21 00:03:21 --> Hooks Class Initialized
DEBUG - 2018-03-21 00:03:21 --> UTF-8 Support Enabled
INFO - 2018-03-21 00:03:21 --> Utf8 Class Initialized
INFO - 2018-03-21 00:03:21 --> URI Class Initialized
INFO - 2018-03-21 00:03:21 --> Router Class Initialized
INFO - 2018-03-21 00:03:21 --> Output Class Initialized
INFO - 2018-03-21 00:03:21 --> Security Class Initialized
DEBUG - 2018-03-21 00:03:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 00:03:21 --> Input Class Initialized
INFO - 2018-03-21 00:03:21 --> Language Class Initialized
INFO - 2018-03-21 00:03:21 --> Loader Class Initialized
INFO - 2018-03-21 00:03:21 --> Helper loaded: url_helper
INFO - 2018-03-21 00:03:21 --> Helper loaded: form_helper
INFO - 2018-03-21 00:03:21 --> Database Driver Class Initialized
DEBUG - 2018-03-21 00:03:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 00:03:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 00:03:21 --> Form Validation Class Initialized
INFO - 2018-03-21 00:03:21 --> Model Class Initialized
INFO - 2018-03-21 00:03:21 --> Controller Class Initialized
INFO - 2018-03-21 00:03:21 --> Model Class Initialized
INFO - 2018-03-21 00:03:21 --> Model Class Initialized
INFO - 2018-03-21 00:03:21 --> Model Class Initialized
INFO - 2018-03-21 00:03:21 --> Model Class Initialized
DEBUG - 2018-03-21 00:03:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 00:03:21 --> Final output sent to browser
DEBUG - 2018-03-21 00:03:21 --> Total execution time: 0.1644
INFO - 2018-03-21 00:04:00 --> Config Class Initialized
INFO - 2018-03-21 00:04:00 --> Hooks Class Initialized
DEBUG - 2018-03-21 00:04:00 --> UTF-8 Support Enabled
INFO - 2018-03-21 00:04:00 --> Utf8 Class Initialized
INFO - 2018-03-21 00:04:00 --> URI Class Initialized
INFO - 2018-03-21 00:04:00 --> Router Class Initialized
INFO - 2018-03-21 00:04:00 --> Output Class Initialized
INFO - 2018-03-21 00:04:00 --> Security Class Initialized
DEBUG - 2018-03-21 00:04:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 00:04:00 --> Input Class Initialized
INFO - 2018-03-21 00:04:00 --> Language Class Initialized
INFO - 2018-03-21 00:04:00 --> Loader Class Initialized
INFO - 2018-03-21 00:04:00 --> Helper loaded: url_helper
INFO - 2018-03-21 00:04:00 --> Helper loaded: form_helper
INFO - 2018-03-21 00:04:00 --> Database Driver Class Initialized
DEBUG - 2018-03-21 00:04:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 00:04:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 00:04:00 --> Form Validation Class Initialized
INFO - 2018-03-21 00:04:00 --> Model Class Initialized
INFO - 2018-03-21 00:04:00 --> Controller Class Initialized
INFO - 2018-03-21 00:04:00 --> Model Class Initialized
INFO - 2018-03-21 00:04:00 --> Model Class Initialized
INFO - 2018-03-21 00:04:00 --> Model Class Initialized
INFO - 2018-03-21 00:04:00 --> Model Class Initialized
DEBUG - 2018-03-21 00:04:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 00:04:00 --> Final output sent to browser
DEBUG - 2018-03-21 00:04:00 --> Total execution time: 0.1520
INFO - 2018-03-21 00:05:24 --> Config Class Initialized
INFO - 2018-03-21 00:05:24 --> Hooks Class Initialized
DEBUG - 2018-03-21 00:05:24 --> UTF-8 Support Enabled
INFO - 2018-03-21 00:05:24 --> Utf8 Class Initialized
INFO - 2018-03-21 00:05:24 --> URI Class Initialized
INFO - 2018-03-21 00:05:24 --> Router Class Initialized
INFO - 2018-03-21 00:05:24 --> Output Class Initialized
INFO - 2018-03-21 00:05:24 --> Security Class Initialized
DEBUG - 2018-03-21 00:05:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 00:05:24 --> Input Class Initialized
INFO - 2018-03-21 00:05:24 --> Language Class Initialized
INFO - 2018-03-21 00:05:24 --> Loader Class Initialized
INFO - 2018-03-21 00:05:24 --> Helper loaded: url_helper
INFO - 2018-03-21 00:05:24 --> Helper loaded: form_helper
INFO - 2018-03-21 00:05:24 --> Database Driver Class Initialized
DEBUG - 2018-03-21 00:05:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 00:05:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 00:05:24 --> Form Validation Class Initialized
INFO - 2018-03-21 00:05:24 --> Model Class Initialized
INFO - 2018-03-21 00:05:24 --> Controller Class Initialized
INFO - 2018-03-21 00:05:24 --> Model Class Initialized
INFO - 2018-03-21 00:05:24 --> Model Class Initialized
INFO - 2018-03-21 00:05:24 --> Model Class Initialized
INFO - 2018-03-21 00:05:24 --> Model Class Initialized
DEBUG - 2018-03-21 00:05:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 00:05:24 --> Final output sent to browser
DEBUG - 2018-03-21 00:05:24 --> Total execution time: 0.1603
INFO - 2018-03-21 00:11:19 --> Config Class Initialized
INFO - 2018-03-21 00:11:19 --> Hooks Class Initialized
DEBUG - 2018-03-21 00:11:19 --> UTF-8 Support Enabled
INFO - 2018-03-21 00:11:19 --> Utf8 Class Initialized
INFO - 2018-03-21 00:11:19 --> URI Class Initialized
INFO - 2018-03-21 00:11:19 --> Router Class Initialized
INFO - 2018-03-21 00:11:19 --> Output Class Initialized
INFO - 2018-03-21 00:11:19 --> Security Class Initialized
DEBUG - 2018-03-21 00:11:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 00:11:19 --> Input Class Initialized
INFO - 2018-03-21 00:11:19 --> Language Class Initialized
INFO - 2018-03-21 00:11:19 --> Loader Class Initialized
INFO - 2018-03-21 00:11:19 --> Helper loaded: url_helper
INFO - 2018-03-21 00:11:19 --> Helper loaded: form_helper
INFO - 2018-03-21 00:11:19 --> Database Driver Class Initialized
DEBUG - 2018-03-21 00:11:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 00:11:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 00:11:19 --> Form Validation Class Initialized
INFO - 2018-03-21 00:11:19 --> Model Class Initialized
INFO - 2018-03-21 00:11:19 --> Controller Class Initialized
INFO - 2018-03-21 00:11:19 --> Model Class Initialized
INFO - 2018-03-21 00:11:19 --> Model Class Initialized
INFO - 2018-03-21 00:11:19 --> Model Class Initialized
INFO - 2018-03-21 00:11:19 --> Model Class Initialized
DEBUG - 2018-03-21 00:11:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 00:11:19 --> Final output sent to browser
DEBUG - 2018-03-21 00:11:19 --> Total execution time: 0.1633
INFO - 2018-03-21 00:11:37 --> Config Class Initialized
INFO - 2018-03-21 00:11:37 --> Hooks Class Initialized
DEBUG - 2018-03-21 00:11:37 --> UTF-8 Support Enabled
INFO - 2018-03-21 00:11:37 --> Utf8 Class Initialized
INFO - 2018-03-21 00:11:37 --> URI Class Initialized
INFO - 2018-03-21 00:11:37 --> Router Class Initialized
INFO - 2018-03-21 00:11:37 --> Output Class Initialized
INFO - 2018-03-21 00:11:37 --> Security Class Initialized
DEBUG - 2018-03-21 00:11:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 00:11:37 --> Input Class Initialized
INFO - 2018-03-21 00:11:37 --> Language Class Initialized
INFO - 2018-03-21 00:11:37 --> Loader Class Initialized
INFO - 2018-03-21 00:11:37 --> Helper loaded: url_helper
INFO - 2018-03-21 00:11:37 --> Helper loaded: form_helper
INFO - 2018-03-21 00:11:37 --> Database Driver Class Initialized
DEBUG - 2018-03-21 00:11:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 00:11:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 00:11:37 --> Form Validation Class Initialized
INFO - 2018-03-21 00:11:37 --> Model Class Initialized
INFO - 2018-03-21 00:11:37 --> Controller Class Initialized
INFO - 2018-03-21 00:11:37 --> Model Class Initialized
INFO - 2018-03-21 00:11:37 --> Model Class Initialized
INFO - 2018-03-21 00:11:37 --> Model Class Initialized
INFO - 2018-03-21 00:11:37 --> Model Class Initialized
DEBUG - 2018-03-21 00:11:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 00:11:37 --> Final output sent to browser
DEBUG - 2018-03-21 00:11:37 --> Total execution time: 0.1797
INFO - 2018-03-21 00:12:29 --> Config Class Initialized
INFO - 2018-03-21 00:12:29 --> Hooks Class Initialized
DEBUG - 2018-03-21 00:12:29 --> UTF-8 Support Enabled
INFO - 2018-03-21 00:12:29 --> Utf8 Class Initialized
INFO - 2018-03-21 00:12:29 --> URI Class Initialized
INFO - 2018-03-21 00:12:29 --> Router Class Initialized
INFO - 2018-03-21 00:12:29 --> Output Class Initialized
INFO - 2018-03-21 00:12:29 --> Security Class Initialized
DEBUG - 2018-03-21 00:12:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 00:12:29 --> Input Class Initialized
INFO - 2018-03-21 00:12:29 --> Language Class Initialized
INFO - 2018-03-21 00:12:29 --> Loader Class Initialized
INFO - 2018-03-21 00:12:29 --> Helper loaded: url_helper
INFO - 2018-03-21 00:12:29 --> Helper loaded: form_helper
INFO - 2018-03-21 00:12:29 --> Database Driver Class Initialized
DEBUG - 2018-03-21 00:12:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 00:12:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 00:12:29 --> Form Validation Class Initialized
INFO - 2018-03-21 00:12:29 --> Model Class Initialized
INFO - 2018-03-21 00:12:29 --> Controller Class Initialized
INFO - 2018-03-21 00:12:29 --> Model Class Initialized
INFO - 2018-03-21 00:12:29 --> Model Class Initialized
INFO - 2018-03-21 00:12:29 --> Model Class Initialized
INFO - 2018-03-21 00:12:29 --> Model Class Initialized
DEBUG - 2018-03-21 00:12:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 00:12:29 --> Final output sent to browser
DEBUG - 2018-03-21 00:12:29 --> Total execution time: 0.1576
INFO - 2018-03-21 00:12:53 --> Config Class Initialized
INFO - 2018-03-21 00:12:53 --> Hooks Class Initialized
DEBUG - 2018-03-21 00:12:53 --> UTF-8 Support Enabled
INFO - 2018-03-21 00:12:53 --> Utf8 Class Initialized
INFO - 2018-03-21 00:12:53 --> URI Class Initialized
INFO - 2018-03-21 00:12:53 --> Router Class Initialized
INFO - 2018-03-21 00:12:53 --> Output Class Initialized
INFO - 2018-03-21 00:12:53 --> Security Class Initialized
DEBUG - 2018-03-21 00:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 00:12:53 --> Input Class Initialized
INFO - 2018-03-21 00:12:53 --> Language Class Initialized
INFO - 2018-03-21 00:12:53 --> Loader Class Initialized
INFO - 2018-03-21 00:12:53 --> Helper loaded: url_helper
INFO - 2018-03-21 00:12:53 --> Helper loaded: form_helper
INFO - 2018-03-21 00:12:53 --> Database Driver Class Initialized
DEBUG - 2018-03-21 00:12:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 00:12:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 00:12:53 --> Form Validation Class Initialized
INFO - 2018-03-21 00:12:53 --> Model Class Initialized
INFO - 2018-03-21 00:12:53 --> Controller Class Initialized
INFO - 2018-03-21 00:12:53 --> Model Class Initialized
INFO - 2018-03-21 00:12:53 --> Model Class Initialized
INFO - 2018-03-21 00:12:53 --> Model Class Initialized
INFO - 2018-03-21 00:12:53 --> Model Class Initialized
DEBUG - 2018-03-21 00:12:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 00:12:53 --> Final output sent to browser
DEBUG - 2018-03-21 00:12:53 --> Total execution time: 0.1574
INFO - 2018-03-21 00:17:34 --> Config Class Initialized
INFO - 2018-03-21 00:17:34 --> Hooks Class Initialized
DEBUG - 2018-03-21 00:17:34 --> UTF-8 Support Enabled
INFO - 2018-03-21 00:17:34 --> Utf8 Class Initialized
INFO - 2018-03-21 00:17:34 --> URI Class Initialized
INFO - 2018-03-21 00:17:34 --> Router Class Initialized
INFO - 2018-03-21 00:17:34 --> Output Class Initialized
INFO - 2018-03-21 00:17:34 --> Security Class Initialized
DEBUG - 2018-03-21 00:17:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 00:17:34 --> Input Class Initialized
INFO - 2018-03-21 00:17:34 --> Language Class Initialized
INFO - 2018-03-21 00:17:34 --> Loader Class Initialized
INFO - 2018-03-21 00:17:34 --> Helper loaded: url_helper
INFO - 2018-03-21 00:17:34 --> Helper loaded: form_helper
INFO - 2018-03-21 00:17:34 --> Database Driver Class Initialized
DEBUG - 2018-03-21 00:17:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 00:17:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 00:17:34 --> Form Validation Class Initialized
INFO - 2018-03-21 00:17:34 --> Model Class Initialized
INFO - 2018-03-21 00:17:34 --> Controller Class Initialized
INFO - 2018-03-21 00:17:35 --> Model Class Initialized
INFO - 2018-03-21 00:17:35 --> Model Class Initialized
INFO - 2018-03-21 00:17:35 --> Model Class Initialized
INFO - 2018-03-21 00:17:35 --> Model Class Initialized
DEBUG - 2018-03-21 00:17:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 00:17:35 --> Final output sent to browser
DEBUG - 2018-03-21 00:17:35 --> Total execution time: 0.1765
INFO - 2018-03-21 00:26:43 --> Config Class Initialized
INFO - 2018-03-21 00:26:43 --> Hooks Class Initialized
DEBUG - 2018-03-21 00:26:43 --> UTF-8 Support Enabled
INFO - 2018-03-21 00:26:43 --> Utf8 Class Initialized
INFO - 2018-03-21 00:26:43 --> URI Class Initialized
INFO - 2018-03-21 00:26:43 --> Router Class Initialized
INFO - 2018-03-21 00:26:43 --> Output Class Initialized
INFO - 2018-03-21 00:26:43 --> Security Class Initialized
DEBUG - 2018-03-21 00:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 00:26:43 --> Input Class Initialized
INFO - 2018-03-21 00:26:43 --> Language Class Initialized
INFO - 2018-03-21 00:26:43 --> Loader Class Initialized
INFO - 2018-03-21 00:26:43 --> Helper loaded: url_helper
INFO - 2018-03-21 00:26:43 --> Helper loaded: form_helper
INFO - 2018-03-21 00:26:43 --> Database Driver Class Initialized
DEBUG - 2018-03-21 00:26:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 00:26:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 00:26:43 --> Form Validation Class Initialized
INFO - 2018-03-21 00:26:43 --> Model Class Initialized
INFO - 2018-03-21 00:26:43 --> Controller Class Initialized
INFO - 2018-03-21 00:26:43 --> Model Class Initialized
INFO - 2018-03-21 00:26:43 --> Model Class Initialized
INFO - 2018-03-21 00:26:43 --> Model Class Initialized
INFO - 2018-03-21 00:26:43 --> Model Class Initialized
DEBUG - 2018-03-21 00:26:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 00:26:43 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-21 00:26:43 --> Final output sent to browser
DEBUG - 2018-03-21 00:26:43 --> Total execution time: 0.0584
INFO - 2018-03-21 00:26:44 --> Config Class Initialized
INFO - 2018-03-21 00:26:44 --> Hooks Class Initialized
DEBUG - 2018-03-21 00:26:44 --> UTF-8 Support Enabled
INFO - 2018-03-21 00:26:44 --> Utf8 Class Initialized
INFO - 2018-03-21 00:26:44 --> URI Class Initialized
INFO - 2018-03-21 00:26:44 --> Router Class Initialized
INFO - 2018-03-21 00:26:44 --> Output Class Initialized
INFO - 2018-03-21 00:26:44 --> Security Class Initialized
DEBUG - 2018-03-21 00:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 00:26:44 --> Input Class Initialized
INFO - 2018-03-21 00:26:44 --> Language Class Initialized
INFO - 2018-03-21 00:26:44 --> Loader Class Initialized
INFO - 2018-03-21 00:26:44 --> Helper loaded: url_helper
INFO - 2018-03-21 00:26:44 --> Helper loaded: form_helper
INFO - 2018-03-21 00:26:44 --> Database Driver Class Initialized
DEBUG - 2018-03-21 00:26:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 00:26:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 00:26:44 --> Form Validation Class Initialized
INFO - 2018-03-21 00:26:44 --> Model Class Initialized
INFO - 2018-03-21 00:26:44 --> Controller Class Initialized
INFO - 2018-03-21 00:26:44 --> Model Class Initialized
INFO - 2018-03-21 00:26:44 --> Model Class Initialized
INFO - 2018-03-21 00:26:44 --> Model Class Initialized
INFO - 2018-03-21 00:26:44 --> Model Class Initialized
DEBUG - 2018-03-21 00:26:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 00:26:44 --> Model Class Initialized
INFO - 2018-03-21 00:26:44 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-21 00:26:44 --> Final output sent to browser
DEBUG - 2018-03-21 00:26:44 --> Total execution time: 0.0603
INFO - 2018-03-21 00:26:44 --> Config Class Initialized
INFO - 2018-03-21 00:26:44 --> Hooks Class Initialized
DEBUG - 2018-03-21 00:26:44 --> UTF-8 Support Enabled
INFO - 2018-03-21 00:26:44 --> Utf8 Class Initialized
INFO - 2018-03-21 00:26:44 --> URI Class Initialized
INFO - 2018-03-21 00:26:44 --> Router Class Initialized
INFO - 2018-03-21 00:26:44 --> Output Class Initialized
INFO - 2018-03-21 00:26:44 --> Security Class Initialized
DEBUG - 2018-03-21 00:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 00:26:44 --> Input Class Initialized
INFO - 2018-03-21 00:26:44 --> Language Class Initialized
INFO - 2018-03-21 00:26:44 --> Loader Class Initialized
INFO - 2018-03-21 00:26:44 --> Helper loaded: url_helper
INFO - 2018-03-21 00:26:44 --> Helper loaded: form_helper
INFO - 2018-03-21 00:26:44 --> Database Driver Class Initialized
DEBUG - 2018-03-21 00:26:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 00:26:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 00:26:44 --> Form Validation Class Initialized
INFO - 2018-03-21 00:26:44 --> Model Class Initialized
INFO - 2018-03-21 00:26:44 --> Controller Class Initialized
INFO - 2018-03-21 00:26:44 --> Model Class Initialized
INFO - 2018-03-21 00:26:44 --> Model Class Initialized
DEBUG - 2018-03-21 00:26:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 00:26:49 --> Config Class Initialized
INFO - 2018-03-21 00:26:49 --> Hooks Class Initialized
DEBUG - 2018-03-21 00:26:49 --> UTF-8 Support Enabled
INFO - 2018-03-21 00:26:49 --> Utf8 Class Initialized
INFO - 2018-03-21 00:26:49 --> URI Class Initialized
INFO - 2018-03-21 00:26:49 --> Router Class Initialized
INFO - 2018-03-21 00:26:49 --> Output Class Initialized
INFO - 2018-03-21 00:26:49 --> Security Class Initialized
DEBUG - 2018-03-21 00:26:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 00:26:49 --> Input Class Initialized
INFO - 2018-03-21 00:26:49 --> Language Class Initialized
INFO - 2018-03-21 00:26:49 --> Loader Class Initialized
INFO - 2018-03-21 00:26:49 --> Helper loaded: url_helper
INFO - 2018-03-21 00:26:49 --> Helper loaded: form_helper
INFO - 2018-03-21 00:26:49 --> Database Driver Class Initialized
DEBUG - 2018-03-21 00:26:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 00:26:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 00:26:49 --> Form Validation Class Initialized
INFO - 2018-03-21 00:26:49 --> Model Class Initialized
INFO - 2018-03-21 00:26:49 --> Controller Class Initialized
INFO - 2018-03-21 00:26:49 --> Model Class Initialized
INFO - 2018-03-21 00:26:49 --> Model Class Initialized
INFO - 2018-03-21 00:26:49 --> Model Class Initialized
INFO - 2018-03-21 00:26:49 --> Model Class Initialized
DEBUG - 2018-03-21 00:26:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 00:26:49 --> Model Class Initialized
INFO - 2018-03-21 00:26:49 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-21 00:26:49 --> Final output sent to browser
DEBUG - 2018-03-21 00:26:49 --> Total execution time: 0.0659
INFO - 2018-03-21 00:26:49 --> Config Class Initialized
INFO - 2018-03-21 00:26:49 --> Hooks Class Initialized
DEBUG - 2018-03-21 00:26:49 --> UTF-8 Support Enabled
INFO - 2018-03-21 00:26:49 --> Utf8 Class Initialized
INFO - 2018-03-21 00:26:49 --> URI Class Initialized
INFO - 2018-03-21 00:26:49 --> Router Class Initialized
INFO - 2018-03-21 00:26:49 --> Output Class Initialized
INFO - 2018-03-21 00:26:49 --> Security Class Initialized
DEBUG - 2018-03-21 00:26:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 00:26:49 --> Input Class Initialized
INFO - 2018-03-21 00:26:49 --> Language Class Initialized
INFO - 2018-03-21 00:26:49 --> Loader Class Initialized
INFO - 2018-03-21 00:26:49 --> Helper loaded: url_helper
INFO - 2018-03-21 00:26:49 --> Helper loaded: form_helper
INFO - 2018-03-21 00:26:49 --> Database Driver Class Initialized
DEBUG - 2018-03-21 00:26:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 00:26:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 00:26:49 --> Form Validation Class Initialized
INFO - 2018-03-21 00:26:49 --> Model Class Initialized
INFO - 2018-03-21 00:26:49 --> Controller Class Initialized
INFO - 2018-03-21 00:26:49 --> Model Class Initialized
INFO - 2018-03-21 00:26:49 --> Model Class Initialized
INFO - 2018-03-21 00:26:49 --> Model Class Initialized
INFO - 2018-03-21 00:26:49 --> Model Class Initialized
DEBUG - 2018-03-21 00:26:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 00:27:09 --> Config Class Initialized
INFO - 2018-03-21 00:27:09 --> Hooks Class Initialized
DEBUG - 2018-03-21 00:27:09 --> UTF-8 Support Enabled
INFO - 2018-03-21 00:27:09 --> Utf8 Class Initialized
INFO - 2018-03-21 00:27:09 --> URI Class Initialized
INFO - 2018-03-21 00:27:09 --> Router Class Initialized
INFO - 2018-03-21 00:27:09 --> Output Class Initialized
INFO - 2018-03-21 00:27:09 --> Security Class Initialized
DEBUG - 2018-03-21 00:27:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 00:27:09 --> Input Class Initialized
INFO - 2018-03-21 00:27:09 --> Language Class Initialized
INFO - 2018-03-21 00:27:09 --> Loader Class Initialized
INFO - 2018-03-21 00:27:09 --> Helper loaded: url_helper
INFO - 2018-03-21 00:27:09 --> Helper loaded: form_helper
INFO - 2018-03-21 00:27:09 --> Database Driver Class Initialized
DEBUG - 2018-03-21 00:27:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 00:27:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 00:27:09 --> Form Validation Class Initialized
INFO - 2018-03-21 00:27:09 --> Model Class Initialized
INFO - 2018-03-21 00:27:09 --> Controller Class Initialized
INFO - 2018-03-21 00:27:09 --> Model Class Initialized
INFO - 2018-03-21 00:27:09 --> Model Class Initialized
INFO - 2018-03-21 00:27:09 --> Model Class Initialized
INFO - 2018-03-21 00:27:09 --> Model Class Initialized
DEBUG - 2018-03-21 00:27:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 00:27:09 --> Model Class Initialized
INFO - 2018-03-21 00:27:09 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-21 00:27:09 --> Final output sent to browser
DEBUG - 2018-03-21 00:27:09 --> Total execution time: 0.1162
INFO - 2018-03-21 00:27:10 --> Config Class Initialized
INFO - 2018-03-21 00:27:10 --> Hooks Class Initialized
DEBUG - 2018-03-21 00:27:10 --> UTF-8 Support Enabled
INFO - 2018-03-21 00:27:10 --> Utf8 Class Initialized
INFO - 2018-03-21 00:27:10 --> URI Class Initialized
INFO - 2018-03-21 00:27:10 --> Router Class Initialized
INFO - 2018-03-21 00:27:10 --> Output Class Initialized
INFO - 2018-03-21 00:27:10 --> Security Class Initialized
DEBUG - 2018-03-21 00:27:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 00:27:10 --> Input Class Initialized
INFO - 2018-03-21 00:27:10 --> Language Class Initialized
INFO - 2018-03-21 00:27:10 --> Loader Class Initialized
INFO - 2018-03-21 00:27:10 --> Helper loaded: url_helper
INFO - 2018-03-21 00:27:10 --> Helper loaded: form_helper
INFO - 2018-03-21 00:27:10 --> Database Driver Class Initialized
DEBUG - 2018-03-21 00:27:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 00:27:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 00:27:10 --> Form Validation Class Initialized
INFO - 2018-03-21 00:27:10 --> Model Class Initialized
INFO - 2018-03-21 00:27:10 --> Controller Class Initialized
INFO - 2018-03-21 00:27:10 --> Model Class Initialized
INFO - 2018-03-21 00:27:10 --> Model Class Initialized
INFO - 2018-03-21 00:27:10 --> Model Class Initialized
INFO - 2018-03-21 00:27:10 --> Model Class Initialized
DEBUG - 2018-03-21 00:27:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 00:27:17 --> Config Class Initialized
INFO - 2018-03-21 00:27:17 --> Hooks Class Initialized
DEBUG - 2018-03-21 00:27:17 --> UTF-8 Support Enabled
INFO - 2018-03-21 00:27:17 --> Utf8 Class Initialized
INFO - 2018-03-21 00:27:17 --> URI Class Initialized
INFO - 2018-03-21 00:27:17 --> Router Class Initialized
INFO - 2018-03-21 00:27:17 --> Output Class Initialized
INFO - 2018-03-21 00:27:17 --> Security Class Initialized
DEBUG - 2018-03-21 00:27:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 00:27:17 --> Input Class Initialized
INFO - 2018-03-21 00:27:17 --> Language Class Initialized
INFO - 2018-03-21 00:27:17 --> Loader Class Initialized
INFO - 2018-03-21 00:27:17 --> Helper loaded: url_helper
INFO - 2018-03-21 00:27:17 --> Helper loaded: form_helper
INFO - 2018-03-21 00:27:17 --> Database Driver Class Initialized
DEBUG - 2018-03-21 00:27:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 00:27:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 00:27:17 --> Form Validation Class Initialized
INFO - 2018-03-21 00:27:17 --> Model Class Initialized
INFO - 2018-03-21 00:27:17 --> Controller Class Initialized
INFO - 2018-03-21 00:27:17 --> Model Class Initialized
INFO - 2018-03-21 00:27:17 --> Model Class Initialized
INFO - 2018-03-21 00:27:17 --> Model Class Initialized
INFO - 2018-03-21 00:27:17 --> Model Class Initialized
DEBUG - 2018-03-21 00:27:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 00:27:17 --> Model Class Initialized
INFO - 2018-03-21 00:27:17 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-21 00:27:17 --> Final output sent to browser
DEBUG - 2018-03-21 00:27:17 --> Total execution time: 0.0979
INFO - 2018-03-21 00:27:17 --> Config Class Initialized
INFO - 2018-03-21 00:27:17 --> Hooks Class Initialized
DEBUG - 2018-03-21 00:27:17 --> UTF-8 Support Enabled
INFO - 2018-03-21 00:27:17 --> Utf8 Class Initialized
INFO - 2018-03-21 00:27:17 --> URI Class Initialized
INFO - 2018-03-21 00:27:17 --> Router Class Initialized
INFO - 2018-03-21 00:27:17 --> Output Class Initialized
INFO - 2018-03-21 00:27:17 --> Security Class Initialized
DEBUG - 2018-03-21 00:27:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 00:27:17 --> Input Class Initialized
INFO - 2018-03-21 00:27:17 --> Language Class Initialized
INFO - 2018-03-21 00:27:17 --> Loader Class Initialized
INFO - 2018-03-21 00:27:17 --> Helper loaded: url_helper
INFO - 2018-03-21 00:27:17 --> Helper loaded: form_helper
INFO - 2018-03-21 00:27:17 --> Database Driver Class Initialized
DEBUG - 2018-03-21 00:27:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 00:27:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 00:27:17 --> Form Validation Class Initialized
INFO - 2018-03-21 00:27:17 --> Model Class Initialized
INFO - 2018-03-21 00:27:17 --> Controller Class Initialized
INFO - 2018-03-21 00:27:17 --> Model Class Initialized
INFO - 2018-03-21 00:27:17 --> Model Class Initialized
INFO - 2018-03-21 00:27:17 --> Model Class Initialized
INFO - 2018-03-21 00:27:17 --> Model Class Initialized
DEBUG - 2018-03-21 00:27:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 00:27:31 --> Config Class Initialized
INFO - 2018-03-21 00:27:31 --> Hooks Class Initialized
DEBUG - 2018-03-21 00:27:31 --> UTF-8 Support Enabled
INFO - 2018-03-21 00:27:31 --> Utf8 Class Initialized
INFO - 2018-03-21 00:27:31 --> URI Class Initialized
INFO - 2018-03-21 00:27:31 --> Router Class Initialized
INFO - 2018-03-21 00:27:31 --> Output Class Initialized
INFO - 2018-03-21 00:27:31 --> Security Class Initialized
DEBUG - 2018-03-21 00:27:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 00:27:31 --> Input Class Initialized
INFO - 2018-03-21 00:27:31 --> Language Class Initialized
INFO - 2018-03-21 00:27:31 --> Loader Class Initialized
INFO - 2018-03-21 00:27:31 --> Helper loaded: url_helper
INFO - 2018-03-21 00:27:31 --> Helper loaded: form_helper
INFO - 2018-03-21 00:27:31 --> Database Driver Class Initialized
DEBUG - 2018-03-21 00:27:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 00:27:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 00:27:31 --> Form Validation Class Initialized
INFO - 2018-03-21 00:27:31 --> Model Class Initialized
INFO - 2018-03-21 00:27:31 --> Controller Class Initialized
INFO - 2018-03-21 00:27:31 --> Model Class Initialized
INFO - 2018-03-21 00:27:31 --> Model Class Initialized
INFO - 2018-03-21 00:27:31 --> Model Class Initialized
INFO - 2018-03-21 00:27:31 --> Model Class Initialized
DEBUG - 2018-03-21 00:27:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 00:27:31 --> Model Class Initialized
INFO - 2018-03-21 00:27:31 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-21 00:27:31 --> Final output sent to browser
DEBUG - 2018-03-21 00:27:31 --> Total execution time: 0.0842
INFO - 2018-03-21 00:27:32 --> Config Class Initialized
INFO - 2018-03-21 00:27:32 --> Hooks Class Initialized
DEBUG - 2018-03-21 00:27:32 --> UTF-8 Support Enabled
INFO - 2018-03-21 00:27:32 --> Utf8 Class Initialized
INFO - 2018-03-21 00:27:32 --> URI Class Initialized
INFO - 2018-03-21 00:27:32 --> Router Class Initialized
INFO - 2018-03-21 00:27:32 --> Output Class Initialized
INFO - 2018-03-21 00:27:32 --> Security Class Initialized
DEBUG - 2018-03-21 00:27:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 00:27:32 --> Input Class Initialized
INFO - 2018-03-21 00:27:32 --> Language Class Initialized
INFO - 2018-03-21 00:27:32 --> Loader Class Initialized
INFO - 2018-03-21 00:27:32 --> Helper loaded: url_helper
INFO - 2018-03-21 00:27:32 --> Helper loaded: form_helper
INFO - 2018-03-21 00:27:32 --> Database Driver Class Initialized
DEBUG - 2018-03-21 00:27:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 00:27:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 00:27:32 --> Form Validation Class Initialized
INFO - 2018-03-21 00:27:32 --> Model Class Initialized
INFO - 2018-03-21 00:27:32 --> Controller Class Initialized
INFO - 2018-03-21 00:27:32 --> Model Class Initialized
INFO - 2018-03-21 00:27:32 --> Model Class Initialized
INFO - 2018-03-21 00:27:32 --> Model Class Initialized
INFO - 2018-03-21 00:27:32 --> Model Class Initialized
DEBUG - 2018-03-21 00:27:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 00:27:45 --> Config Class Initialized
INFO - 2018-03-21 00:27:45 --> Hooks Class Initialized
DEBUG - 2018-03-21 00:27:45 --> UTF-8 Support Enabled
INFO - 2018-03-21 00:27:45 --> Utf8 Class Initialized
INFO - 2018-03-21 00:27:45 --> URI Class Initialized
INFO - 2018-03-21 00:27:45 --> Router Class Initialized
INFO - 2018-03-21 00:27:45 --> Output Class Initialized
INFO - 2018-03-21 00:27:45 --> Security Class Initialized
DEBUG - 2018-03-21 00:27:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 00:27:45 --> Input Class Initialized
INFO - 2018-03-21 00:27:45 --> Language Class Initialized
INFO - 2018-03-21 00:27:45 --> Loader Class Initialized
INFO - 2018-03-21 00:27:45 --> Helper loaded: url_helper
INFO - 2018-03-21 00:27:45 --> Helper loaded: form_helper
INFO - 2018-03-21 00:27:45 --> Database Driver Class Initialized
DEBUG - 2018-03-21 00:27:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 00:27:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 00:27:46 --> Form Validation Class Initialized
INFO - 2018-03-21 00:27:46 --> Model Class Initialized
INFO - 2018-03-21 00:27:46 --> Controller Class Initialized
INFO - 2018-03-21 00:27:46 --> Model Class Initialized
INFO - 2018-03-21 00:27:46 --> Model Class Initialized
INFO - 2018-03-21 00:27:46 --> Model Class Initialized
INFO - 2018-03-21 00:27:46 --> Model Class Initialized
DEBUG - 2018-03-21 00:27:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 00:27:46 --> Model Class Initialized
INFO - 2018-03-21 00:27:46 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-21 00:27:46 --> Final output sent to browser
DEBUG - 2018-03-21 00:27:46 --> Total execution time: 0.1734
INFO - 2018-03-21 00:27:46 --> Config Class Initialized
INFO - 2018-03-21 00:27:46 --> Hooks Class Initialized
DEBUG - 2018-03-21 00:27:46 --> UTF-8 Support Enabled
INFO - 2018-03-21 00:27:46 --> Utf8 Class Initialized
INFO - 2018-03-21 00:27:46 --> URI Class Initialized
INFO - 2018-03-21 00:27:46 --> Router Class Initialized
INFO - 2018-03-21 00:27:46 --> Output Class Initialized
INFO - 2018-03-21 00:27:46 --> Security Class Initialized
DEBUG - 2018-03-21 00:27:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 00:27:46 --> Input Class Initialized
INFO - 2018-03-21 00:27:46 --> Language Class Initialized
INFO - 2018-03-21 00:27:46 --> Loader Class Initialized
INFO - 2018-03-21 00:27:46 --> Helper loaded: url_helper
INFO - 2018-03-21 00:27:46 --> Helper loaded: form_helper
INFO - 2018-03-21 00:27:46 --> Database Driver Class Initialized
DEBUG - 2018-03-21 00:27:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 00:27:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 00:27:46 --> Form Validation Class Initialized
INFO - 2018-03-21 00:27:46 --> Model Class Initialized
INFO - 2018-03-21 00:27:46 --> Controller Class Initialized
INFO - 2018-03-21 00:27:46 --> Model Class Initialized
INFO - 2018-03-21 00:27:46 --> Model Class Initialized
INFO - 2018-03-21 00:27:46 --> Model Class Initialized
INFO - 2018-03-21 00:27:46 --> Model Class Initialized
DEBUG - 2018-03-21 00:27:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 00:29:33 --> Config Class Initialized
INFO - 2018-03-21 00:29:33 --> Hooks Class Initialized
DEBUG - 2018-03-21 00:29:33 --> UTF-8 Support Enabled
INFO - 2018-03-21 00:29:33 --> Utf8 Class Initialized
INFO - 2018-03-21 00:29:33 --> URI Class Initialized
INFO - 2018-03-21 00:29:33 --> Router Class Initialized
INFO - 2018-03-21 00:29:33 --> Output Class Initialized
INFO - 2018-03-21 00:29:33 --> Security Class Initialized
DEBUG - 2018-03-21 00:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 00:29:33 --> Input Class Initialized
INFO - 2018-03-21 00:29:33 --> Language Class Initialized
INFO - 2018-03-21 00:29:33 --> Loader Class Initialized
INFO - 2018-03-21 00:29:33 --> Helper loaded: url_helper
INFO - 2018-03-21 00:29:33 --> Helper loaded: form_helper
INFO - 2018-03-21 00:29:33 --> Database Driver Class Initialized
DEBUG - 2018-03-21 00:29:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 00:29:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 00:29:33 --> Form Validation Class Initialized
INFO - 2018-03-21 00:29:33 --> Model Class Initialized
INFO - 2018-03-21 00:29:33 --> Controller Class Initialized
INFO - 2018-03-21 00:29:33 --> Model Class Initialized
INFO - 2018-03-21 00:29:33 --> Model Class Initialized
INFO - 2018-03-21 00:29:33 --> Model Class Initialized
INFO - 2018-03-21 00:29:33 --> Model Class Initialized
DEBUG - 2018-03-21 00:29:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 00:29:33 --> Model Class Initialized
INFO - 2018-03-21 00:29:33 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-21 00:29:33 --> Final output sent to browser
DEBUG - 2018-03-21 00:29:33 --> Total execution time: 0.0872
INFO - 2018-03-21 00:29:33 --> Config Class Initialized
INFO - 2018-03-21 00:29:33 --> Hooks Class Initialized
DEBUG - 2018-03-21 00:29:33 --> UTF-8 Support Enabled
INFO - 2018-03-21 00:29:33 --> Utf8 Class Initialized
INFO - 2018-03-21 00:29:33 --> URI Class Initialized
INFO - 2018-03-21 00:29:33 --> Router Class Initialized
INFO - 2018-03-21 00:29:33 --> Output Class Initialized
INFO - 2018-03-21 00:29:33 --> Security Class Initialized
DEBUG - 2018-03-21 00:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 00:29:33 --> Input Class Initialized
INFO - 2018-03-21 00:29:33 --> Language Class Initialized
INFO - 2018-03-21 00:29:33 --> Loader Class Initialized
INFO - 2018-03-21 00:29:33 --> Helper loaded: url_helper
INFO - 2018-03-21 00:29:33 --> Helper loaded: form_helper
INFO - 2018-03-21 00:29:33 --> Database Driver Class Initialized
DEBUG - 2018-03-21 00:29:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 00:29:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 00:29:33 --> Form Validation Class Initialized
INFO - 2018-03-21 00:29:33 --> Model Class Initialized
INFO - 2018-03-21 00:29:33 --> Controller Class Initialized
INFO - 2018-03-21 00:29:33 --> Model Class Initialized
INFO - 2018-03-21 00:29:33 --> Model Class Initialized
INFO - 2018-03-21 00:29:33 --> Model Class Initialized
INFO - 2018-03-21 00:29:33 --> Model Class Initialized
DEBUG - 2018-03-21 00:29:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 00:29:34 --> Config Class Initialized
INFO - 2018-03-21 00:29:34 --> Hooks Class Initialized
DEBUG - 2018-03-21 00:29:34 --> UTF-8 Support Enabled
INFO - 2018-03-21 00:29:34 --> Utf8 Class Initialized
INFO - 2018-03-21 00:29:34 --> URI Class Initialized
INFO - 2018-03-21 00:29:34 --> Router Class Initialized
INFO - 2018-03-21 00:29:34 --> Output Class Initialized
INFO - 2018-03-21 00:29:34 --> Security Class Initialized
DEBUG - 2018-03-21 00:29:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 00:29:34 --> Input Class Initialized
INFO - 2018-03-21 00:29:34 --> Language Class Initialized
INFO - 2018-03-21 00:29:34 --> Loader Class Initialized
INFO - 2018-03-21 00:29:34 --> Helper loaded: url_helper
INFO - 2018-03-21 00:29:34 --> Helper loaded: form_helper
INFO - 2018-03-21 00:29:34 --> Database Driver Class Initialized
DEBUG - 2018-03-21 00:29:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 00:29:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 00:29:34 --> Form Validation Class Initialized
INFO - 2018-03-21 00:29:34 --> Model Class Initialized
INFO - 2018-03-21 00:29:34 --> Controller Class Initialized
INFO - 2018-03-21 00:29:34 --> Model Class Initialized
INFO - 2018-03-21 00:29:34 --> Model Class Initialized
INFO - 2018-03-21 00:29:34 --> Model Class Initialized
INFO - 2018-03-21 00:29:34 --> Model Class Initialized
DEBUG - 2018-03-21 00:29:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 00:29:34 --> Model Class Initialized
INFO - 2018-03-21 00:29:34 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-21 00:29:34 --> Final output sent to browser
DEBUG - 2018-03-21 00:29:34 --> Total execution time: 0.0915
INFO - 2018-03-21 00:29:34 --> Config Class Initialized
INFO - 2018-03-21 00:29:34 --> Hooks Class Initialized
DEBUG - 2018-03-21 00:29:34 --> UTF-8 Support Enabled
INFO - 2018-03-21 00:29:34 --> Utf8 Class Initialized
INFO - 2018-03-21 00:29:34 --> URI Class Initialized
INFO - 2018-03-21 00:29:34 --> Router Class Initialized
INFO - 2018-03-21 00:29:34 --> Output Class Initialized
INFO - 2018-03-21 00:29:34 --> Security Class Initialized
DEBUG - 2018-03-21 00:29:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 00:29:34 --> Input Class Initialized
INFO - 2018-03-21 00:29:34 --> Language Class Initialized
INFO - 2018-03-21 00:29:34 --> Loader Class Initialized
INFO - 2018-03-21 00:29:34 --> Helper loaded: url_helper
INFO - 2018-03-21 00:29:34 --> Helper loaded: form_helper
INFO - 2018-03-21 00:29:34 --> Database Driver Class Initialized
DEBUG - 2018-03-21 00:29:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 00:29:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 00:29:34 --> Form Validation Class Initialized
INFO - 2018-03-21 00:29:34 --> Model Class Initialized
INFO - 2018-03-21 00:29:34 --> Controller Class Initialized
INFO - 2018-03-21 00:29:34 --> Model Class Initialized
INFO - 2018-03-21 00:29:34 --> Model Class Initialized
INFO - 2018-03-21 00:29:34 --> Model Class Initialized
INFO - 2018-03-21 00:29:34 --> Model Class Initialized
DEBUG - 2018-03-21 00:29:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 00:29:36 --> Config Class Initialized
INFO - 2018-03-21 00:29:36 --> Hooks Class Initialized
DEBUG - 2018-03-21 00:29:36 --> UTF-8 Support Enabled
INFO - 2018-03-21 00:29:36 --> Utf8 Class Initialized
INFO - 2018-03-21 00:29:36 --> URI Class Initialized
INFO - 2018-03-21 00:29:36 --> Router Class Initialized
INFO - 2018-03-21 00:29:36 --> Output Class Initialized
INFO - 2018-03-21 00:29:36 --> Security Class Initialized
DEBUG - 2018-03-21 00:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 00:29:36 --> Input Class Initialized
INFO - 2018-03-21 00:29:36 --> Language Class Initialized
INFO - 2018-03-21 00:29:36 --> Loader Class Initialized
INFO - 2018-03-21 00:29:36 --> Helper loaded: url_helper
INFO - 2018-03-21 00:29:36 --> Helper loaded: form_helper
INFO - 2018-03-21 00:29:36 --> Database Driver Class Initialized
DEBUG - 2018-03-21 00:29:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 00:29:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 00:29:36 --> Form Validation Class Initialized
INFO - 2018-03-21 00:29:36 --> Model Class Initialized
INFO - 2018-03-21 00:29:36 --> Controller Class Initialized
INFO - 2018-03-21 00:29:36 --> Model Class Initialized
INFO - 2018-03-21 00:29:36 --> Model Class Initialized
INFO - 2018-03-21 00:29:36 --> Model Class Initialized
INFO - 2018-03-21 00:29:36 --> Model Class Initialized
DEBUG - 2018-03-21 00:29:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 00:29:36 --> Model Class Initialized
INFO - 2018-03-21 00:29:36 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-21 00:29:36 --> Final output sent to browser
DEBUG - 2018-03-21 00:29:36 --> Total execution time: 0.0932
INFO - 2018-03-21 00:29:36 --> Config Class Initialized
INFO - 2018-03-21 00:29:36 --> Hooks Class Initialized
DEBUG - 2018-03-21 00:29:36 --> UTF-8 Support Enabled
INFO - 2018-03-21 00:29:36 --> Utf8 Class Initialized
INFO - 2018-03-21 00:29:36 --> URI Class Initialized
INFO - 2018-03-21 00:29:36 --> Router Class Initialized
INFO - 2018-03-21 00:29:36 --> Output Class Initialized
INFO - 2018-03-21 00:29:36 --> Security Class Initialized
DEBUG - 2018-03-21 00:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 00:29:36 --> Input Class Initialized
INFO - 2018-03-21 00:29:36 --> Language Class Initialized
INFO - 2018-03-21 00:29:36 --> Loader Class Initialized
INFO - 2018-03-21 00:29:36 --> Helper loaded: url_helper
INFO - 2018-03-21 00:29:36 --> Helper loaded: form_helper
INFO - 2018-03-21 00:29:36 --> Database Driver Class Initialized
DEBUG - 2018-03-21 00:29:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 00:29:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 00:29:36 --> Form Validation Class Initialized
INFO - 2018-03-21 00:29:36 --> Model Class Initialized
INFO - 2018-03-21 00:29:36 --> Controller Class Initialized
INFO - 2018-03-21 00:29:36 --> Model Class Initialized
INFO - 2018-03-21 00:29:36 --> Model Class Initialized
INFO - 2018-03-21 00:29:36 --> Model Class Initialized
INFO - 2018-03-21 00:29:36 --> Model Class Initialized
DEBUG - 2018-03-21 00:29:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 00:29:37 --> Config Class Initialized
INFO - 2018-03-21 00:29:37 --> Hooks Class Initialized
DEBUG - 2018-03-21 00:29:37 --> UTF-8 Support Enabled
INFO - 2018-03-21 00:29:37 --> Utf8 Class Initialized
INFO - 2018-03-21 00:29:37 --> URI Class Initialized
INFO - 2018-03-21 00:29:37 --> Router Class Initialized
INFO - 2018-03-21 00:29:37 --> Output Class Initialized
INFO - 2018-03-21 00:29:37 --> Security Class Initialized
DEBUG - 2018-03-21 00:29:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 00:29:37 --> Input Class Initialized
INFO - 2018-03-21 00:29:37 --> Language Class Initialized
INFO - 2018-03-21 00:29:37 --> Loader Class Initialized
INFO - 2018-03-21 00:29:37 --> Helper loaded: url_helper
INFO - 2018-03-21 00:29:37 --> Helper loaded: form_helper
INFO - 2018-03-21 00:29:37 --> Database Driver Class Initialized
DEBUG - 2018-03-21 00:29:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 00:29:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 00:29:37 --> Form Validation Class Initialized
INFO - 2018-03-21 00:29:37 --> Model Class Initialized
INFO - 2018-03-21 00:29:37 --> Controller Class Initialized
INFO - 2018-03-21 00:29:37 --> Model Class Initialized
INFO - 2018-03-21 00:29:37 --> Model Class Initialized
INFO - 2018-03-21 00:29:37 --> Model Class Initialized
INFO - 2018-03-21 00:29:37 --> Model Class Initialized
DEBUG - 2018-03-21 00:29:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 00:29:38 --> Model Class Initialized
INFO - 2018-03-21 00:29:38 --> Final output sent to browser
DEBUG - 2018-03-21 00:29:38 --> Total execution time: 0.1370
INFO - 2018-03-21 00:29:41 --> Config Class Initialized
INFO - 2018-03-21 00:29:41 --> Hooks Class Initialized
DEBUG - 2018-03-21 00:29:41 --> UTF-8 Support Enabled
INFO - 2018-03-21 00:29:41 --> Utf8 Class Initialized
INFO - 2018-03-21 00:29:41 --> URI Class Initialized
INFO - 2018-03-21 00:29:41 --> Router Class Initialized
INFO - 2018-03-21 00:29:41 --> Output Class Initialized
INFO - 2018-03-21 00:29:41 --> Security Class Initialized
DEBUG - 2018-03-21 00:29:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 00:29:41 --> Input Class Initialized
INFO - 2018-03-21 00:29:41 --> Language Class Initialized
INFO - 2018-03-21 00:29:41 --> Config Class Initialized
INFO - 2018-03-21 00:29:41 --> Hooks Class Initialized
INFO - 2018-03-21 00:29:41 --> Config Class Initialized
INFO - 2018-03-21 00:29:41 --> Hooks Class Initialized
DEBUG - 2018-03-21 00:29:41 --> UTF-8 Support Enabled
INFO - 2018-03-21 00:29:41 --> Utf8 Class Initialized
INFO - 2018-03-21 00:29:41 --> Config Class Initialized
INFO - 2018-03-21 00:29:41 --> Hooks Class Initialized
INFO - 2018-03-21 00:29:41 --> URI Class Initialized
DEBUG - 2018-03-21 00:29:41 --> UTF-8 Support Enabled
INFO - 2018-03-21 00:29:41 --> Utf8 Class Initialized
INFO - 2018-03-21 00:29:41 --> Router Class Initialized
INFO - 2018-03-21 00:29:41 --> URI Class Initialized
DEBUG - 2018-03-21 00:29:41 --> UTF-8 Support Enabled
INFO - 2018-03-21 00:29:41 --> Utf8 Class Initialized
INFO - 2018-03-21 00:29:41 --> Output Class Initialized
INFO - 2018-03-21 00:29:41 --> Router Class Initialized
INFO - 2018-03-21 00:29:41 --> URI Class Initialized
INFO - 2018-03-21 00:29:41 --> Security Class Initialized
INFO - 2018-03-21 00:29:41 --> Output Class Initialized
DEBUG - 2018-03-21 00:29:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 00:29:41 --> Input Class Initialized
INFO - 2018-03-21 00:29:41 --> Security Class Initialized
INFO - 2018-03-21 00:29:41 --> Language Class Initialized
DEBUG - 2018-03-21 00:29:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 00:29:41 --> Input Class Initialized
INFO - 2018-03-21 00:29:41 --> Language Class Initialized
INFO - 2018-03-21 00:29:41 --> Router Class Initialized
INFO - 2018-03-21 00:29:41 --> Output Class Initialized
INFO - 2018-03-21 00:29:41 --> Security Class Initialized
DEBUG - 2018-03-21 00:29:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 00:29:41 --> Input Class Initialized
INFO - 2018-03-21 00:29:41 --> Language Class Initialized
ERROR - 2018-03-21 00:29:41 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-21 00:29:41 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-21 00:29:41 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-21 00:29:41 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-21 00:29:46 --> Config Class Initialized
INFO - 2018-03-21 00:29:46 --> Hooks Class Initialized
DEBUG - 2018-03-21 00:29:46 --> UTF-8 Support Enabled
INFO - 2018-03-21 00:29:46 --> Utf8 Class Initialized
INFO - 2018-03-21 00:29:46 --> URI Class Initialized
INFO - 2018-03-21 00:29:46 --> Router Class Initialized
INFO - 2018-03-21 00:29:46 --> Output Class Initialized
INFO - 2018-03-21 00:29:46 --> Security Class Initialized
DEBUG - 2018-03-21 00:29:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 00:29:46 --> Input Class Initialized
INFO - 2018-03-21 00:29:46 --> Language Class Initialized
INFO - 2018-03-21 00:29:46 --> Loader Class Initialized
INFO - 2018-03-21 00:29:46 --> Helper loaded: url_helper
INFO - 2018-03-21 00:29:46 --> Helper loaded: form_helper
INFO - 2018-03-21 00:29:46 --> Database Driver Class Initialized
DEBUG - 2018-03-21 00:29:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 00:29:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 00:29:46 --> Form Validation Class Initialized
INFO - 2018-03-21 00:29:46 --> Model Class Initialized
INFO - 2018-03-21 00:29:46 --> Controller Class Initialized
INFO - 2018-03-21 00:29:46 --> Model Class Initialized
INFO - 2018-03-21 00:29:46 --> Model Class Initialized
INFO - 2018-03-21 00:29:46 --> Model Class Initialized
INFO - 2018-03-21 00:29:46 --> Model Class Initialized
DEBUG - 2018-03-21 00:29:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 00:29:46 --> Model Class Initialized
INFO - 2018-03-21 00:29:46 --> Final output sent to browser
DEBUG - 2018-03-21 00:29:46 --> Total execution time: 0.1315
INFO - 2018-03-21 08:02:05 --> Config Class Initialized
INFO - 2018-03-21 08:02:05 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:02:05 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:02:05 --> Utf8 Class Initialized
INFO - 2018-03-21 08:02:05 --> URI Class Initialized
INFO - 2018-03-21 08:02:05 --> Router Class Initialized
INFO - 2018-03-21 08:02:05 --> Output Class Initialized
INFO - 2018-03-21 08:02:05 --> Security Class Initialized
DEBUG - 2018-03-21 08:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:02:05 --> Input Class Initialized
INFO - 2018-03-21 08:02:05 --> Language Class Initialized
INFO - 2018-03-21 08:02:05 --> Loader Class Initialized
INFO - 2018-03-21 08:02:05 --> Helper loaded: url_helper
INFO - 2018-03-21 08:02:05 --> Helper loaded: form_helper
INFO - 2018-03-21 08:02:05 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:02:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:02:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:02:05 --> Form Validation Class Initialized
INFO - 2018-03-21 08:02:05 --> Model Class Initialized
INFO - 2018-03-21 08:02:05 --> Controller Class Initialized
INFO - 2018-03-21 08:02:05 --> Model Class Initialized
INFO - 2018-03-21 08:02:05 --> Model Class Initialized
INFO - 2018-03-21 08:02:05 --> Model Class Initialized
INFO - 2018-03-21 08:02:05 --> Model Class Initialized
DEBUG - 2018-03-21 08:02:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:02:05 --> Config Class Initialized
INFO - 2018-03-21 08:02:05 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:02:05 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:02:05 --> Utf8 Class Initialized
INFO - 2018-03-21 08:02:05 --> URI Class Initialized
INFO - 2018-03-21 08:02:05 --> Router Class Initialized
INFO - 2018-03-21 08:02:05 --> Output Class Initialized
INFO - 2018-03-21 08:02:05 --> Security Class Initialized
DEBUG - 2018-03-21 08:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:02:05 --> Input Class Initialized
INFO - 2018-03-21 08:02:05 --> Language Class Initialized
INFO - 2018-03-21 08:02:05 --> Loader Class Initialized
INFO - 2018-03-21 08:02:05 --> Helper loaded: url_helper
INFO - 2018-03-21 08:02:05 --> Helper loaded: form_helper
INFO - 2018-03-21 08:02:05 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:02:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:02:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:02:05 --> Form Validation Class Initialized
INFO - 2018-03-21 08:02:05 --> Model Class Initialized
INFO - 2018-03-21 08:02:05 --> Controller Class Initialized
INFO - 2018-03-21 08:02:05 --> Model Class Initialized
DEBUG - 2018-03-21 08:02:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:02:05 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-21 08:02:05 --> Final output sent to browser
DEBUG - 2018-03-21 08:02:05 --> Total execution time: 0.0478
INFO - 2018-03-21 08:02:05 --> Config Class Initialized
INFO - 2018-03-21 08:02:05 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:02:05 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:02:05 --> Utf8 Class Initialized
INFO - 2018-03-21 08:02:05 --> URI Class Initialized
INFO - 2018-03-21 08:02:05 --> Config Class Initialized
INFO - 2018-03-21 08:02:05 --> Hooks Class Initialized
INFO - 2018-03-21 08:02:05 --> Router Class Initialized
INFO - 2018-03-21 08:02:05 --> Output Class Initialized
DEBUG - 2018-03-21 08:02:05 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:02:05 --> Utf8 Class Initialized
INFO - 2018-03-21 08:02:05 --> Security Class Initialized
INFO - 2018-03-21 08:02:05 --> URI Class Initialized
DEBUG - 2018-03-21 08:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:02:05 --> Config Class Initialized
INFO - 2018-03-21 08:02:05 --> Config Class Initialized
INFO - 2018-03-21 08:02:05 --> Input Class Initialized
INFO - 2018-03-21 08:02:05 --> Hooks Class Initialized
INFO - 2018-03-21 08:02:05 --> Hooks Class Initialized
INFO - 2018-03-21 08:02:05 --> Language Class Initialized
INFO - 2018-03-21 08:02:05 --> Router Class Initialized
ERROR - 2018-03-21 08:02:05 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-21 08:02:05 --> Config Class Initialized
INFO - 2018-03-21 08:02:05 --> Hooks Class Initialized
INFO - 2018-03-21 08:02:05 --> Config Class Initialized
DEBUG - 2018-03-21 08:02:05 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:02:05 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:02:05 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:02:05 --> Utf8 Class Initialized
INFO - 2018-03-21 08:02:05 --> Utf8 Class Initialized
INFO - 2018-03-21 08:02:05 --> Output Class Initialized
INFO - 2018-03-21 08:02:05 --> URI Class Initialized
INFO - 2018-03-21 08:02:05 --> URI Class Initialized
INFO - 2018-03-21 08:02:05 --> Security Class Initialized
DEBUG - 2018-03-21 08:02:05 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:02:05 --> Utf8 Class Initialized
DEBUG - 2018-03-21 08:02:05 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:02:05 --> Router Class Initialized
INFO - 2018-03-21 08:02:05 --> Utf8 Class Initialized
DEBUG - 2018-03-21 08:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:02:05 --> Router Class Initialized
INFO - 2018-03-21 08:02:05 --> Input Class Initialized
INFO - 2018-03-21 08:02:05 --> Language Class Initialized
INFO - 2018-03-21 08:02:05 --> URI Class Initialized
INFO - 2018-03-21 08:02:05 --> URI Class Initialized
INFO - 2018-03-21 08:02:05 --> Output Class Initialized
INFO - 2018-03-21 08:02:05 --> Output Class Initialized
ERROR - 2018-03-21 08:02:05 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-21 08:02:05 --> Security Class Initialized
INFO - 2018-03-21 08:02:05 --> Security Class Initialized
DEBUG - 2018-03-21 08:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:02:05 --> Input Class Initialized
INFO - 2018-03-21 08:02:05 --> Config Class Initialized
DEBUG - 2018-03-21 08:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:02:05 --> Hooks Class Initialized
INFO - 2018-03-21 08:02:05 --> Input Class Initialized
INFO - 2018-03-21 08:02:05 --> Language Class Initialized
INFO - 2018-03-21 08:02:05 --> Language Class Initialized
ERROR - 2018-03-21 08:02:05 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-21 08:02:05 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-21 08:02:05 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:02:05 --> Utf8 Class Initialized
INFO - 2018-03-21 08:02:05 --> Router Class Initialized
INFO - 2018-03-21 08:02:05 --> URI Class Initialized
INFO - 2018-03-21 08:02:05 --> Router Class Initialized
INFO - 2018-03-21 08:02:05 --> Output Class Initialized
INFO - 2018-03-21 08:02:05 --> Router Class Initialized
INFO - 2018-03-21 08:02:05 --> Output Class Initialized
INFO - 2018-03-21 08:02:05 --> Security Class Initialized
INFO - 2018-03-21 08:02:05 --> Output Class Initialized
INFO - 2018-03-21 08:02:05 --> Security Class Initialized
DEBUG - 2018-03-21 08:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:02:05 --> Input Class Initialized
INFO - 2018-03-21 08:02:05 --> Security Class Initialized
INFO - 2018-03-21 08:02:05 --> Language Class Initialized
DEBUG - 2018-03-21 08:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:02:05 --> Input Class Initialized
DEBUG - 2018-03-21 08:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:02:05 --> Language Class Initialized
ERROR - 2018-03-21 08:02:05 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-21 08:02:05 --> Input Class Initialized
INFO - 2018-03-21 08:02:05 --> Language Class Initialized
ERROR - 2018-03-21 08:02:05 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-21 08:02:05 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-21 08:02:06 --> Config Class Initialized
INFO - 2018-03-21 08:02:06 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:02:06 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:02:06 --> Utf8 Class Initialized
INFO - 2018-03-21 08:02:06 --> URI Class Initialized
INFO - 2018-03-21 08:02:06 --> Router Class Initialized
INFO - 2018-03-21 08:02:06 --> Output Class Initialized
INFO - 2018-03-21 08:02:06 --> Security Class Initialized
DEBUG - 2018-03-21 08:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:02:06 --> Input Class Initialized
INFO - 2018-03-21 08:02:06 --> Language Class Initialized
INFO - 2018-03-21 08:02:06 --> Loader Class Initialized
INFO - 2018-03-21 08:02:06 --> Helper loaded: url_helper
INFO - 2018-03-21 08:02:06 --> Helper loaded: form_helper
INFO - 2018-03-21 08:02:06 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:02:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:02:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:02:06 --> Form Validation Class Initialized
INFO - 2018-03-21 08:02:07 --> Model Class Initialized
INFO - 2018-03-21 08:02:07 --> Controller Class Initialized
INFO - 2018-03-21 08:02:07 --> Model Class Initialized
DEBUG - 2018-03-21 08:02:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:02:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-21 08:02:07 --> Config Class Initialized
INFO - 2018-03-21 08:02:07 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:02:07 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:02:07 --> Utf8 Class Initialized
INFO - 2018-03-21 08:02:07 --> URI Class Initialized
DEBUG - 2018-03-21 08:02:07 --> No URI present. Default controller set.
INFO - 2018-03-21 08:02:07 --> Router Class Initialized
INFO - 2018-03-21 08:02:07 --> Output Class Initialized
INFO - 2018-03-21 08:02:07 --> Security Class Initialized
DEBUG - 2018-03-21 08:02:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:02:07 --> Input Class Initialized
INFO - 2018-03-21 08:02:07 --> Language Class Initialized
INFO - 2018-03-21 08:02:07 --> Loader Class Initialized
INFO - 2018-03-21 08:02:07 --> Helper loaded: url_helper
INFO - 2018-03-21 08:02:07 --> Helper loaded: form_helper
INFO - 2018-03-21 08:02:07 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:02:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:02:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:02:07 --> Form Validation Class Initialized
INFO - 2018-03-21 08:02:07 --> Model Class Initialized
INFO - 2018-03-21 08:02:07 --> Controller Class Initialized
INFO - 2018-03-21 08:02:07 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-21 08:02:07 --> Final output sent to browser
DEBUG - 2018-03-21 08:02:07 --> Total execution time: 0.0916
INFO - 2018-03-21 08:02:07 --> Config Class Initialized
INFO - 2018-03-21 08:02:07 --> Config Class Initialized
INFO - 2018-03-21 08:02:07 --> Hooks Class Initialized
INFO - 2018-03-21 08:02:07 --> Hooks Class Initialized
INFO - 2018-03-21 08:02:07 --> Config Class Initialized
INFO - 2018-03-21 08:02:07 --> Hooks Class Initialized
INFO - 2018-03-21 08:02:07 --> Config Class Initialized
DEBUG - 2018-03-21 08:02:07 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:02:07 --> Hooks Class Initialized
INFO - 2018-03-21 08:02:07 --> Utf8 Class Initialized
DEBUG - 2018-03-21 08:02:07 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:02:07 --> Utf8 Class Initialized
INFO - 2018-03-21 08:02:07 --> URI Class Initialized
INFO - 2018-03-21 08:02:07 --> URI Class Initialized
DEBUG - 2018-03-21 08:02:07 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:02:07 --> Utf8 Class Initialized
DEBUG - 2018-03-21 08:02:07 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:02:07 --> Utf8 Class Initialized
INFO - 2018-03-21 08:02:07 --> Router Class Initialized
INFO - 2018-03-21 08:02:07 --> URI Class Initialized
INFO - 2018-03-21 08:02:07 --> Router Class Initialized
INFO - 2018-03-21 08:02:07 --> URI Class Initialized
INFO - 2018-03-21 08:02:07 --> Router Class Initialized
INFO - 2018-03-21 08:02:07 --> Output Class Initialized
INFO - 2018-03-21 08:02:07 --> Output Class Initialized
INFO - 2018-03-21 08:02:07 --> Router Class Initialized
INFO - 2018-03-21 08:02:07 --> Output Class Initialized
INFO - 2018-03-21 08:02:07 --> Security Class Initialized
INFO - 2018-03-21 08:02:07 --> Security Class Initialized
DEBUG - 2018-03-21 08:02:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:02:07 --> Security Class Initialized
INFO - 2018-03-21 08:02:07 --> Input Class Initialized
INFO - 2018-03-21 08:02:07 --> Output Class Initialized
DEBUG - 2018-03-21 08:02:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:02:07 --> Language Class Initialized
INFO - 2018-03-21 08:02:07 --> Input Class Initialized
DEBUG - 2018-03-21 08:02:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:02:07 --> Input Class Initialized
INFO - 2018-03-21 08:02:07 --> Security Class Initialized
INFO - 2018-03-21 08:02:07 --> Language Class Initialized
ERROR - 2018-03-21 08:02:07 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-21 08:02:07 --> Language Class Initialized
DEBUG - 2018-03-21 08:02:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-03-21 08:02:07 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-21 08:02:07 --> Input Class Initialized
ERROR - 2018-03-21 08:02:07 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-21 08:02:07 --> Language Class Initialized
ERROR - 2018-03-21 08:02:07 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-21 08:02:07 --> Config Class Initialized
INFO - 2018-03-21 08:02:07 --> Hooks Class Initialized
INFO - 2018-03-21 08:02:07 --> Config Class Initialized
INFO - 2018-03-21 08:02:07 --> Hooks Class Initialized
INFO - 2018-03-21 08:02:07 --> Config Class Initialized
INFO - 2018-03-21 08:02:07 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:02:07 --> UTF-8 Support Enabled
DEBUG - 2018-03-21 08:02:07 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:02:07 --> Utf8 Class Initialized
INFO - 2018-03-21 08:02:07 --> Utf8 Class Initialized
DEBUG - 2018-03-21 08:02:07 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:02:07 --> Utf8 Class Initialized
INFO - 2018-03-21 08:02:07 --> URI Class Initialized
INFO - 2018-03-21 08:02:07 --> URI Class Initialized
INFO - 2018-03-21 08:02:07 --> URI Class Initialized
INFO - 2018-03-21 08:02:07 --> Router Class Initialized
INFO - 2018-03-21 08:02:07 --> Router Class Initialized
INFO - 2018-03-21 08:02:07 --> Router Class Initialized
INFO - 2018-03-21 08:02:07 --> Output Class Initialized
INFO - 2018-03-21 08:02:07 --> Output Class Initialized
INFO - 2018-03-21 08:02:07 --> Output Class Initialized
INFO - 2018-03-21 08:02:07 --> Security Class Initialized
INFO - 2018-03-21 08:02:07 --> Security Class Initialized
INFO - 2018-03-21 08:02:07 --> Security Class Initialized
DEBUG - 2018-03-21 08:02:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:02:07 --> Input Class Initialized
DEBUG - 2018-03-21 08:02:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:02:07 --> Input Class Initialized
INFO - 2018-03-21 08:02:07 --> Language Class Initialized
DEBUG - 2018-03-21 08:02:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:02:07 --> Language Class Initialized
INFO - 2018-03-21 08:02:07 --> Input Class Initialized
ERROR - 2018-03-21 08:02:07 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-21 08:02:07 --> Language Class Initialized
ERROR - 2018-03-21 08:02:07 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-21 08:02:07 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-21 08:02:07 --> Config Class Initialized
INFO - 2018-03-21 08:02:07 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:02:07 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:02:07 --> Utf8 Class Initialized
INFO - 2018-03-21 08:02:07 --> URI Class Initialized
INFO - 2018-03-21 08:02:07 --> Router Class Initialized
INFO - 2018-03-21 08:02:07 --> Output Class Initialized
INFO - 2018-03-21 08:02:07 --> Security Class Initialized
DEBUG - 2018-03-21 08:02:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:02:07 --> Input Class Initialized
INFO - 2018-03-21 08:02:07 --> Language Class Initialized
INFO - 2018-03-21 08:02:07 --> Loader Class Initialized
INFO - 2018-03-21 08:02:07 --> Helper loaded: url_helper
INFO - 2018-03-21 08:02:07 --> Helper loaded: form_helper
INFO - 2018-03-21 08:02:07 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:02:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:02:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:02:07 --> Form Validation Class Initialized
INFO - 2018-03-21 08:02:07 --> Model Class Initialized
INFO - 2018-03-21 08:02:07 --> Controller Class Initialized
INFO - 2018-03-21 08:02:07 --> Model Class Initialized
INFO - 2018-03-21 08:02:07 --> Model Class Initialized
INFO - 2018-03-21 08:02:07 --> Model Class Initialized
INFO - 2018-03-21 08:02:07 --> Model Class Initialized
INFO - 2018-03-21 08:02:07 --> Model Class Initialized
DEBUG - 2018-03-21 08:02:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:02:11 --> Config Class Initialized
INFO - 2018-03-21 08:02:11 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:02:11 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:02:11 --> Utf8 Class Initialized
INFO - 2018-03-21 08:02:11 --> URI Class Initialized
INFO - 2018-03-21 08:02:11 --> Router Class Initialized
INFO - 2018-03-21 08:02:11 --> Output Class Initialized
INFO - 2018-03-21 08:02:11 --> Security Class Initialized
DEBUG - 2018-03-21 08:02:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:02:11 --> Input Class Initialized
INFO - 2018-03-21 08:02:11 --> Language Class Initialized
INFO - 2018-03-21 08:02:11 --> Loader Class Initialized
INFO - 2018-03-21 08:02:11 --> Helper loaded: url_helper
INFO - 2018-03-21 08:02:11 --> Helper loaded: form_helper
INFO - 2018-03-21 08:02:11 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:02:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:02:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:02:11 --> Form Validation Class Initialized
INFO - 2018-03-21 08:02:11 --> Model Class Initialized
INFO - 2018-03-21 08:02:11 --> Controller Class Initialized
INFO - 2018-03-21 08:02:11 --> Model Class Initialized
INFO - 2018-03-21 08:02:11 --> Model Class Initialized
INFO - 2018-03-21 08:02:11 --> Model Class Initialized
INFO - 2018-03-21 08:02:11 --> Model Class Initialized
DEBUG - 2018-03-21 08:02:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:02:11 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-21 08:02:11 --> Final output sent to browser
DEBUG - 2018-03-21 08:02:11 --> Total execution time: 0.0607
INFO - 2018-03-21 08:02:13 --> Config Class Initialized
INFO - 2018-03-21 08:02:13 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:02:13 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:02:13 --> Utf8 Class Initialized
INFO - 2018-03-21 08:02:13 --> URI Class Initialized
INFO - 2018-03-21 08:02:13 --> Router Class Initialized
INFO - 2018-03-21 08:02:13 --> Output Class Initialized
INFO - 2018-03-21 08:02:13 --> Security Class Initialized
DEBUG - 2018-03-21 08:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:02:13 --> Input Class Initialized
INFO - 2018-03-21 08:02:13 --> Language Class Initialized
INFO - 2018-03-21 08:02:13 --> Loader Class Initialized
INFO - 2018-03-21 08:02:13 --> Helper loaded: url_helper
INFO - 2018-03-21 08:02:13 --> Helper loaded: form_helper
INFO - 2018-03-21 08:02:13 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:02:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:02:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:02:13 --> Form Validation Class Initialized
INFO - 2018-03-21 08:02:13 --> Model Class Initialized
INFO - 2018-03-21 08:02:13 --> Controller Class Initialized
INFO - 2018-03-21 08:02:13 --> Model Class Initialized
INFO - 2018-03-21 08:02:13 --> Model Class Initialized
INFO - 2018-03-21 08:02:13 --> Model Class Initialized
INFO - 2018-03-21 08:02:13 --> Model Class Initialized
DEBUG - 2018-03-21 08:02:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:02:13 --> Model Class Initialized
INFO - 2018-03-21 08:02:13 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-21 08:02:13 --> Final output sent to browser
DEBUG - 2018-03-21 08:02:13 --> Total execution time: 0.0638
INFO - 2018-03-21 08:02:13 --> Config Class Initialized
INFO - 2018-03-21 08:02:13 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:02:13 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:02:13 --> Utf8 Class Initialized
INFO - 2018-03-21 08:02:13 --> URI Class Initialized
INFO - 2018-03-21 08:02:13 --> Router Class Initialized
INFO - 2018-03-21 08:02:13 --> Output Class Initialized
INFO - 2018-03-21 08:02:13 --> Security Class Initialized
DEBUG - 2018-03-21 08:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:02:13 --> Input Class Initialized
INFO - 2018-03-21 08:02:13 --> Language Class Initialized
INFO - 2018-03-21 08:02:13 --> Loader Class Initialized
INFO - 2018-03-21 08:02:13 --> Helper loaded: url_helper
INFO - 2018-03-21 08:02:13 --> Helper loaded: form_helper
INFO - 2018-03-21 08:02:13 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:02:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:02:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:02:13 --> Form Validation Class Initialized
INFO - 2018-03-21 08:02:13 --> Model Class Initialized
INFO - 2018-03-21 08:02:13 --> Controller Class Initialized
INFO - 2018-03-21 08:02:13 --> Model Class Initialized
INFO - 2018-03-21 08:02:13 --> Model Class Initialized
DEBUG - 2018-03-21 08:02:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:02:15 --> Config Class Initialized
INFO - 2018-03-21 08:02:15 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:02:15 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:02:15 --> Utf8 Class Initialized
INFO - 2018-03-21 08:02:15 --> URI Class Initialized
INFO - 2018-03-21 08:02:15 --> Router Class Initialized
INFO - 2018-03-21 08:02:15 --> Output Class Initialized
INFO - 2018-03-21 08:02:15 --> Security Class Initialized
DEBUG - 2018-03-21 08:02:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:02:15 --> Input Class Initialized
INFO - 2018-03-21 08:02:15 --> Language Class Initialized
INFO - 2018-03-21 08:02:15 --> Loader Class Initialized
INFO - 2018-03-21 08:02:15 --> Helper loaded: url_helper
INFO - 2018-03-21 08:02:15 --> Helper loaded: form_helper
INFO - 2018-03-21 08:02:15 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:02:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:02:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:02:15 --> Form Validation Class Initialized
INFO - 2018-03-21 08:02:15 --> Model Class Initialized
INFO - 2018-03-21 08:02:15 --> Controller Class Initialized
INFO - 2018-03-21 08:02:15 --> Model Class Initialized
INFO - 2018-03-21 08:02:15 --> Model Class Initialized
INFO - 2018-03-21 08:02:15 --> Model Class Initialized
INFO - 2018-03-21 08:02:15 --> Model Class Initialized
DEBUG - 2018-03-21 08:02:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:02:15 --> Model Class Initialized
INFO - 2018-03-21 08:02:15 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-21 08:02:15 --> Final output sent to browser
DEBUG - 2018-03-21 08:02:15 --> Total execution time: 0.0669
INFO - 2018-03-21 08:02:15 --> Config Class Initialized
INFO - 2018-03-21 08:02:15 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:02:15 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:02:15 --> Utf8 Class Initialized
INFO - 2018-03-21 08:02:15 --> URI Class Initialized
INFO - 2018-03-21 08:02:15 --> Router Class Initialized
INFO - 2018-03-21 08:02:15 --> Output Class Initialized
INFO - 2018-03-21 08:02:15 --> Security Class Initialized
DEBUG - 2018-03-21 08:02:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:02:15 --> Input Class Initialized
INFO - 2018-03-21 08:02:15 --> Language Class Initialized
INFO - 2018-03-21 08:02:15 --> Loader Class Initialized
INFO - 2018-03-21 08:02:15 --> Helper loaded: url_helper
INFO - 2018-03-21 08:02:15 --> Helper loaded: form_helper
INFO - 2018-03-21 08:02:15 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:02:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:02:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:02:15 --> Form Validation Class Initialized
INFO - 2018-03-21 08:02:15 --> Model Class Initialized
INFO - 2018-03-21 08:02:15 --> Controller Class Initialized
INFO - 2018-03-21 08:02:15 --> Model Class Initialized
INFO - 2018-03-21 08:02:15 --> Model Class Initialized
INFO - 2018-03-21 08:02:15 --> Model Class Initialized
INFO - 2018-03-21 08:02:15 --> Model Class Initialized
DEBUG - 2018-03-21 08:02:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:02:21 --> Config Class Initialized
INFO - 2018-03-21 08:02:21 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:02:21 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:02:21 --> Utf8 Class Initialized
INFO - 2018-03-21 08:02:21 --> URI Class Initialized
INFO - 2018-03-21 08:02:21 --> Router Class Initialized
INFO - 2018-03-21 08:02:21 --> Output Class Initialized
INFO - 2018-03-21 08:02:21 --> Security Class Initialized
DEBUG - 2018-03-21 08:02:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:02:21 --> Input Class Initialized
INFO - 2018-03-21 08:02:21 --> Language Class Initialized
ERROR - 2018-03-21 08:02:21 --> 404 Page Not Found: Reporte/generarReporteHorasPorTrabajadorAjax
INFO - 2018-03-21 08:02:23 --> Config Class Initialized
INFO - 2018-03-21 08:02:23 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:02:23 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:02:23 --> Utf8 Class Initialized
INFO - 2018-03-21 08:02:23 --> URI Class Initialized
INFO - 2018-03-21 08:02:23 --> Router Class Initialized
INFO - 2018-03-21 08:02:23 --> Output Class Initialized
INFO - 2018-03-21 08:02:23 --> Security Class Initialized
DEBUG - 2018-03-21 08:02:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:02:23 --> Input Class Initialized
INFO - 2018-03-21 08:02:23 --> Language Class Initialized
ERROR - 2018-03-21 08:02:23 --> 404 Page Not Found: Reporte/generarReporteHorasPorTrabajadorAjax
INFO - 2018-03-21 08:02:24 --> Config Class Initialized
INFO - 2018-03-21 08:02:24 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:02:24 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:02:24 --> Utf8 Class Initialized
INFO - 2018-03-21 08:02:24 --> URI Class Initialized
INFO - 2018-03-21 08:02:24 --> Router Class Initialized
INFO - 2018-03-21 08:02:24 --> Output Class Initialized
INFO - 2018-03-21 08:02:24 --> Security Class Initialized
DEBUG - 2018-03-21 08:02:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:02:24 --> Input Class Initialized
INFO - 2018-03-21 08:02:24 --> Language Class Initialized
ERROR - 2018-03-21 08:02:24 --> 404 Page Not Found: Reporte/generarReporteHorasPorTrabajadorAjax
INFO - 2018-03-21 08:02:49 --> Config Class Initialized
INFO - 2018-03-21 08:02:49 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:02:49 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:02:49 --> Utf8 Class Initialized
INFO - 2018-03-21 08:02:49 --> URI Class Initialized
INFO - 2018-03-21 08:02:49 --> Router Class Initialized
INFO - 2018-03-21 08:02:49 --> Output Class Initialized
INFO - 2018-03-21 08:02:49 --> Security Class Initialized
DEBUG - 2018-03-21 08:02:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:02:49 --> Input Class Initialized
INFO - 2018-03-21 08:02:49 --> Language Class Initialized
INFO - 2018-03-21 08:02:49 --> Loader Class Initialized
INFO - 2018-03-21 08:02:49 --> Helper loaded: url_helper
INFO - 2018-03-21 08:02:49 --> Helper loaded: form_helper
INFO - 2018-03-21 08:02:49 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:02:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:02:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:02:49 --> Form Validation Class Initialized
INFO - 2018-03-21 08:02:49 --> Model Class Initialized
INFO - 2018-03-21 08:02:49 --> Controller Class Initialized
INFO - 2018-03-21 08:02:49 --> Model Class Initialized
INFO - 2018-03-21 08:02:49 --> Model Class Initialized
INFO - 2018-03-21 08:02:49 --> Model Class Initialized
INFO - 2018-03-21 08:02:49 --> Model Class Initialized
DEBUG - 2018-03-21 08:02:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:02:49 --> Model Class Initialized
INFO - 2018-03-21 08:02:49 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-21 08:02:49 --> Final output sent to browser
DEBUG - 2018-03-21 08:02:49 --> Total execution time: 0.0540
INFO - 2018-03-21 08:02:49 --> Config Class Initialized
INFO - 2018-03-21 08:02:49 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:02:49 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:02:49 --> Utf8 Class Initialized
INFO - 2018-03-21 08:02:49 --> URI Class Initialized
INFO - 2018-03-21 08:02:49 --> Router Class Initialized
INFO - 2018-03-21 08:02:49 --> Output Class Initialized
INFO - 2018-03-21 08:02:49 --> Security Class Initialized
DEBUG - 2018-03-21 08:02:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:02:49 --> Input Class Initialized
INFO - 2018-03-21 08:02:49 --> Language Class Initialized
INFO - 2018-03-21 08:02:49 --> Loader Class Initialized
INFO - 2018-03-21 08:02:49 --> Helper loaded: url_helper
INFO - 2018-03-21 08:02:49 --> Helper loaded: form_helper
INFO - 2018-03-21 08:02:49 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:02:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:02:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:02:49 --> Form Validation Class Initialized
INFO - 2018-03-21 08:02:49 --> Model Class Initialized
INFO - 2018-03-21 08:02:49 --> Controller Class Initialized
INFO - 2018-03-21 08:02:49 --> Model Class Initialized
INFO - 2018-03-21 08:02:49 --> Model Class Initialized
INFO - 2018-03-21 08:02:49 --> Model Class Initialized
INFO - 2018-03-21 08:02:49 --> Model Class Initialized
DEBUG - 2018-03-21 08:02:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:02:59 --> Config Class Initialized
INFO - 2018-03-21 08:02:59 --> Hooks Class Initialized
INFO - 2018-03-21 08:02:59 --> Config Class Initialized
INFO - 2018-03-21 08:02:59 --> Hooks Class Initialized
INFO - 2018-03-21 08:02:59 --> Config Class Initialized
INFO - 2018-03-21 08:02:59 --> Hooks Class Initialized
INFO - 2018-03-21 08:02:59 --> Config Class Initialized
DEBUG - 2018-03-21 08:02:59 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:02:59 --> Hooks Class Initialized
INFO - 2018-03-21 08:02:59 --> Utf8 Class Initialized
DEBUG - 2018-03-21 08:02:59 --> UTF-8 Support Enabled
DEBUG - 2018-03-21 08:02:59 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:02:59 --> Utf8 Class Initialized
INFO - 2018-03-21 08:02:59 --> Utf8 Class Initialized
INFO - 2018-03-21 08:02:59 --> URI Class Initialized
INFO - 2018-03-21 08:02:59 --> URI Class Initialized
INFO - 2018-03-21 08:02:59 --> URI Class Initialized
DEBUG - 2018-03-21 08:02:59 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:02:59 --> Router Class Initialized
INFO - 2018-03-21 08:02:59 --> Utf8 Class Initialized
INFO - 2018-03-21 08:02:59 --> Router Class Initialized
INFO - 2018-03-21 08:02:59 --> Router Class Initialized
INFO - 2018-03-21 08:02:59 --> URI Class Initialized
INFO - 2018-03-21 08:02:59 --> Output Class Initialized
INFO - 2018-03-21 08:02:59 --> Output Class Initialized
INFO - 2018-03-21 08:02:59 --> Security Class Initialized
INFO - 2018-03-21 08:02:59 --> Output Class Initialized
INFO - 2018-03-21 08:02:59 --> Router Class Initialized
INFO - 2018-03-21 08:02:59 --> Security Class Initialized
INFO - 2018-03-21 08:02:59 --> Security Class Initialized
DEBUG - 2018-03-21 08:02:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:02:59 --> Input Class Initialized
INFO - 2018-03-21 08:02:59 --> Output Class Initialized
DEBUG - 2018-03-21 08:02:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:02:59 --> Language Class Initialized
DEBUG - 2018-03-21 08:02:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:02:59 --> Input Class Initialized
INFO - 2018-03-21 08:02:59 --> Input Class Initialized
INFO - 2018-03-21 08:02:59 --> Security Class Initialized
INFO - 2018-03-21 08:02:59 --> Language Class Initialized
INFO - 2018-03-21 08:02:59 --> Language Class Initialized
ERROR - 2018-03-21 08:02:59 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-21 08:02:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:02:59 --> Input Class Initialized
ERROR - 2018-03-21 08:02:59 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-21 08:02:59 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-21 08:02:59 --> Language Class Initialized
ERROR - 2018-03-21 08:02:59 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-21 08:02:59 --> Config Class Initialized
INFO - 2018-03-21 08:02:59 --> Config Class Initialized
INFO - 2018-03-21 08:02:59 --> Hooks Class Initialized
INFO - 2018-03-21 08:02:59 --> Config Class Initialized
INFO - 2018-03-21 08:02:59 --> Hooks Class Initialized
INFO - 2018-03-21 08:02:59 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:02:59 --> UTF-8 Support Enabled
DEBUG - 2018-03-21 08:02:59 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:02:59 --> Utf8 Class Initialized
INFO - 2018-03-21 08:02:59 --> Utf8 Class Initialized
DEBUG - 2018-03-21 08:02:59 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:02:59 --> Utf8 Class Initialized
INFO - 2018-03-21 08:02:59 --> URI Class Initialized
INFO - 2018-03-21 08:02:59 --> URI Class Initialized
INFO - 2018-03-21 08:02:59 --> URI Class Initialized
INFO - 2018-03-21 08:02:59 --> Router Class Initialized
INFO - 2018-03-21 08:02:59 --> Router Class Initialized
INFO - 2018-03-21 08:02:59 --> Router Class Initialized
INFO - 2018-03-21 08:02:59 --> Output Class Initialized
INFO - 2018-03-21 08:02:59 --> Output Class Initialized
INFO - 2018-03-21 08:02:59 --> Output Class Initialized
INFO - 2018-03-21 08:02:59 --> Security Class Initialized
INFO - 2018-03-21 08:02:59 --> Security Class Initialized
INFO - 2018-03-21 08:02:59 --> Security Class Initialized
DEBUG - 2018-03-21 08:02:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-21 08:02:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:02:59 --> Input Class Initialized
INFO - 2018-03-21 08:02:59 --> Input Class Initialized
DEBUG - 2018-03-21 08:02:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:02:59 --> Input Class Initialized
INFO - 2018-03-21 08:02:59 --> Language Class Initialized
INFO - 2018-03-21 08:02:59 --> Language Class Initialized
INFO - 2018-03-21 08:02:59 --> Language Class Initialized
ERROR - 2018-03-21 08:02:59 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-21 08:02:59 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-21 08:02:59 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-21 08:03:15 --> Config Class Initialized
INFO - 2018-03-21 08:03:15 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:03:15 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:03:15 --> Utf8 Class Initialized
INFO - 2018-03-21 08:03:15 --> URI Class Initialized
INFO - 2018-03-21 08:03:15 --> Router Class Initialized
INFO - 2018-03-21 08:03:15 --> Output Class Initialized
INFO - 2018-03-21 08:03:15 --> Security Class Initialized
DEBUG - 2018-03-21 08:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:03:15 --> Input Class Initialized
INFO - 2018-03-21 08:03:15 --> Language Class Initialized
INFO - 2018-03-21 08:03:15 --> Loader Class Initialized
INFO - 2018-03-21 08:03:15 --> Helper loaded: url_helper
INFO - 2018-03-21 08:03:15 --> Helper loaded: form_helper
INFO - 2018-03-21 08:03:15 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:03:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:03:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:03:15 --> Form Validation Class Initialized
INFO - 2018-03-21 08:03:15 --> Model Class Initialized
INFO - 2018-03-21 08:03:15 --> Controller Class Initialized
INFO - 2018-03-21 08:03:15 --> Model Class Initialized
INFO - 2018-03-21 08:03:15 --> Model Class Initialized
INFO - 2018-03-21 08:03:15 --> Model Class Initialized
INFO - 2018-03-21 08:03:15 --> Model Class Initialized
DEBUG - 2018-03-21 08:03:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:03:15 --> Model Class Initialized
INFO - 2018-03-21 08:03:15 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-21 08:03:15 --> Final output sent to browser
DEBUG - 2018-03-21 08:03:15 --> Total execution time: 0.1453
INFO - 2018-03-21 08:03:15 --> Config Class Initialized
INFO - 2018-03-21 08:03:15 --> Hooks Class Initialized
INFO - 2018-03-21 08:03:15 --> Config Class Initialized
INFO - 2018-03-21 08:03:15 --> Config Class Initialized
INFO - 2018-03-21 08:03:15 --> Hooks Class Initialized
INFO - 2018-03-21 08:03:15 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:03:15 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:03:15 --> Utf8 Class Initialized
INFO - 2018-03-21 08:03:15 --> Config Class Initialized
INFO - 2018-03-21 08:03:15 --> URI Class Initialized
INFO - 2018-03-21 08:03:15 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:03:15 --> UTF-8 Support Enabled
DEBUG - 2018-03-21 08:03:15 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:03:15 --> Utf8 Class Initialized
INFO - 2018-03-21 08:03:15 --> Utf8 Class Initialized
INFO - 2018-03-21 08:03:15 --> Router Class Initialized
INFO - 2018-03-21 08:03:15 --> URI Class Initialized
INFO - 2018-03-21 08:03:15 --> URI Class Initialized
DEBUG - 2018-03-21 08:03:15 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:03:15 --> Utf8 Class Initialized
INFO - 2018-03-21 08:03:15 --> Output Class Initialized
INFO - 2018-03-21 08:03:15 --> Router Class Initialized
INFO - 2018-03-21 08:03:15 --> URI Class Initialized
INFO - 2018-03-21 08:03:15 --> Router Class Initialized
INFO - 2018-03-21 08:03:15 --> Security Class Initialized
INFO - 2018-03-21 08:03:15 --> Output Class Initialized
INFO - 2018-03-21 08:03:15 --> Output Class Initialized
INFO - 2018-03-21 08:03:15 --> Router Class Initialized
DEBUG - 2018-03-21 08:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:03:15 --> Input Class Initialized
INFO - 2018-03-21 08:03:15 --> Security Class Initialized
INFO - 2018-03-21 08:03:15 --> Security Class Initialized
INFO - 2018-03-21 08:03:15 --> Language Class Initialized
INFO - 2018-03-21 08:03:15 --> Output Class Initialized
DEBUG - 2018-03-21 08:03:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-21 08:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:03:15 --> Input Class Initialized
INFO - 2018-03-21 08:03:15 --> Input Class Initialized
INFO - 2018-03-21 08:03:15 --> Security Class Initialized
ERROR - 2018-03-21 08:03:15 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-21 08:03:15 --> Language Class Initialized
INFO - 2018-03-21 08:03:15 --> Language Class Initialized
DEBUG - 2018-03-21 08:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:03:15 --> Input Class Initialized
ERROR - 2018-03-21 08:03:15 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-21 08:03:15 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-21 08:03:15 --> Language Class Initialized
ERROR - 2018-03-21 08:03:15 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-21 08:03:15 --> Config Class Initialized
INFO - 2018-03-21 08:03:15 --> Hooks Class Initialized
INFO - 2018-03-21 08:03:15 --> Config Class Initialized
INFO - 2018-03-21 08:03:15 --> Config Class Initialized
INFO - 2018-03-21 08:03:15 --> Hooks Class Initialized
INFO - 2018-03-21 08:03:15 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:03:15 --> UTF-8 Support Enabled
DEBUG - 2018-03-21 08:03:15 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:03:15 --> Utf8 Class Initialized
INFO - 2018-03-21 08:03:15 --> Utf8 Class Initialized
DEBUG - 2018-03-21 08:03:15 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:03:15 --> Utf8 Class Initialized
INFO - 2018-03-21 08:03:15 --> URI Class Initialized
INFO - 2018-03-21 08:03:15 --> URI Class Initialized
INFO - 2018-03-21 08:03:15 --> URI Class Initialized
INFO - 2018-03-21 08:03:15 --> Router Class Initialized
INFO - 2018-03-21 08:03:15 --> Router Class Initialized
INFO - 2018-03-21 08:03:15 --> Router Class Initialized
INFO - 2018-03-21 08:03:15 --> Output Class Initialized
INFO - 2018-03-21 08:03:15 --> Output Class Initialized
INFO - 2018-03-21 08:03:15 --> Security Class Initialized
INFO - 2018-03-21 08:03:15 --> Output Class Initialized
INFO - 2018-03-21 08:03:15 --> Security Class Initialized
DEBUG - 2018-03-21 08:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:03:15 --> Input Class Initialized
INFO - 2018-03-21 08:03:15 --> Security Class Initialized
DEBUG - 2018-03-21 08:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:03:15 --> Input Class Initialized
INFO - 2018-03-21 08:03:15 --> Language Class Initialized
INFO - 2018-03-21 08:03:15 --> Language Class Initialized
DEBUG - 2018-03-21 08:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:03:15 --> Input Class Initialized
ERROR - 2018-03-21 08:03:15 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-21 08:03:15 --> Language Class Initialized
ERROR - 2018-03-21 08:03:15 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-21 08:03:15 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-21 08:03:15 --> Config Class Initialized
INFO - 2018-03-21 08:03:15 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:03:15 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:03:15 --> Utf8 Class Initialized
INFO - 2018-03-21 08:03:15 --> URI Class Initialized
INFO - 2018-03-21 08:03:15 --> Router Class Initialized
INFO - 2018-03-21 08:03:15 --> Output Class Initialized
INFO - 2018-03-21 08:03:15 --> Security Class Initialized
DEBUG - 2018-03-21 08:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:03:15 --> Input Class Initialized
INFO - 2018-03-21 08:03:15 --> Language Class Initialized
INFO - 2018-03-21 08:03:15 --> Loader Class Initialized
INFO - 2018-03-21 08:03:15 --> Helper loaded: url_helper
INFO - 2018-03-21 08:03:15 --> Helper loaded: form_helper
INFO - 2018-03-21 08:03:15 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:03:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:03:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:03:15 --> Form Validation Class Initialized
INFO - 2018-03-21 08:03:15 --> Model Class Initialized
INFO - 2018-03-21 08:03:15 --> Controller Class Initialized
INFO - 2018-03-21 08:03:15 --> Model Class Initialized
INFO - 2018-03-21 08:03:15 --> Model Class Initialized
INFO - 2018-03-21 08:03:15 --> Model Class Initialized
INFO - 2018-03-21 08:03:15 --> Model Class Initialized
DEBUG - 2018-03-21 08:03:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:03:17 --> Config Class Initialized
INFO - 2018-03-21 08:03:17 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:03:17 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:03:17 --> Utf8 Class Initialized
INFO - 2018-03-21 08:03:17 --> URI Class Initialized
INFO - 2018-03-21 08:03:17 --> Router Class Initialized
INFO - 2018-03-21 08:03:17 --> Output Class Initialized
INFO - 2018-03-21 08:03:17 --> Security Class Initialized
DEBUG - 2018-03-21 08:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:03:17 --> Input Class Initialized
INFO - 2018-03-21 08:03:17 --> Language Class Initialized
INFO - 2018-03-21 08:03:17 --> Loader Class Initialized
INFO - 2018-03-21 08:03:17 --> Helper loaded: url_helper
INFO - 2018-03-21 08:03:17 --> Helper loaded: form_helper
INFO - 2018-03-21 08:03:17 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:03:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:03:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:03:17 --> Form Validation Class Initialized
INFO - 2018-03-21 08:03:17 --> Model Class Initialized
INFO - 2018-03-21 08:03:17 --> Controller Class Initialized
INFO - 2018-03-21 08:03:17 --> Model Class Initialized
INFO - 2018-03-21 08:03:17 --> Model Class Initialized
INFO - 2018-03-21 08:03:17 --> Model Class Initialized
INFO - 2018-03-21 08:03:17 --> Model Class Initialized
DEBUG - 2018-03-21 08:03:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:03:20 --> Config Class Initialized
INFO - 2018-03-21 08:03:20 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:03:20 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:03:20 --> Utf8 Class Initialized
INFO - 2018-03-21 08:03:20 --> URI Class Initialized
INFO - 2018-03-21 08:03:20 --> Router Class Initialized
INFO - 2018-03-21 08:03:20 --> Output Class Initialized
INFO - 2018-03-21 08:03:20 --> Security Class Initialized
DEBUG - 2018-03-21 08:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:03:20 --> Input Class Initialized
INFO - 2018-03-21 08:03:20 --> Language Class Initialized
INFO - 2018-03-21 08:03:20 --> Loader Class Initialized
INFO - 2018-03-21 08:03:20 --> Helper loaded: url_helper
INFO - 2018-03-21 08:03:20 --> Helper loaded: form_helper
INFO - 2018-03-21 08:03:20 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:03:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:03:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:03:20 --> Form Validation Class Initialized
INFO - 2018-03-21 08:03:20 --> Model Class Initialized
INFO - 2018-03-21 08:03:20 --> Controller Class Initialized
INFO - 2018-03-21 08:03:20 --> Model Class Initialized
INFO - 2018-03-21 08:03:20 --> Model Class Initialized
INFO - 2018-03-21 08:03:20 --> Model Class Initialized
INFO - 2018-03-21 08:03:20 --> Model Class Initialized
DEBUG - 2018-03-21 08:03:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:03:20 --> Model Class Initialized
INFO - 2018-03-21 08:03:20 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-21 08:03:20 --> Final output sent to browser
DEBUG - 2018-03-21 08:03:20 --> Total execution time: 0.0581
INFO - 2018-03-21 08:03:20 --> Config Class Initialized
INFO - 2018-03-21 08:03:20 --> Config Class Initialized
INFO - 2018-03-21 08:03:20 --> Config Class Initialized
INFO - 2018-03-21 08:03:20 --> Hooks Class Initialized
INFO - 2018-03-21 08:03:20 --> Hooks Class Initialized
INFO - 2018-03-21 08:03:20 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:03:20 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:03:20 --> Utf8 Class Initialized
DEBUG - 2018-03-21 08:03:20 --> UTF-8 Support Enabled
DEBUG - 2018-03-21 08:03:20 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:03:20 --> Utf8 Class Initialized
INFO - 2018-03-21 08:03:20 --> Utf8 Class Initialized
INFO - 2018-03-21 08:03:20 --> URI Class Initialized
INFO - 2018-03-21 08:03:20 --> URI Class Initialized
INFO - 2018-03-21 08:03:20 --> URI Class Initialized
INFO - 2018-03-21 08:03:20 --> Config Class Initialized
INFO - 2018-03-21 08:03:20 --> Hooks Class Initialized
INFO - 2018-03-21 08:03:20 --> Router Class Initialized
INFO - 2018-03-21 08:03:20 --> Router Class Initialized
INFO - 2018-03-21 08:03:20 --> Router Class Initialized
INFO - 2018-03-21 08:03:20 --> Output Class Initialized
INFO - 2018-03-21 08:03:20 --> Output Class Initialized
INFO - 2018-03-21 08:03:20 --> Output Class Initialized
DEBUG - 2018-03-21 08:03:20 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:03:20 --> Security Class Initialized
INFO - 2018-03-21 08:03:20 --> Utf8 Class Initialized
INFO - 2018-03-21 08:03:20 --> Security Class Initialized
INFO - 2018-03-21 08:03:20 --> Security Class Initialized
INFO - 2018-03-21 08:03:20 --> URI Class Initialized
DEBUG - 2018-03-21 08:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:03:20 --> Input Class Initialized
DEBUG - 2018-03-21 08:03:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-21 08:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:03:20 --> Input Class Initialized
INFO - 2018-03-21 08:03:20 --> Input Class Initialized
INFO - 2018-03-21 08:03:20 --> Language Class Initialized
INFO - 2018-03-21 08:03:20 --> Router Class Initialized
INFO - 2018-03-21 08:03:20 --> Language Class Initialized
INFO - 2018-03-21 08:03:20 --> Language Class Initialized
ERROR - 2018-03-21 08:03:20 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-21 08:03:20 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-21 08:03:20 --> Output Class Initialized
ERROR - 2018-03-21 08:03:20 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-21 08:03:20 --> Security Class Initialized
DEBUG - 2018-03-21 08:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:03:20 --> Input Class Initialized
INFO - 2018-03-21 08:03:20 --> Language Class Initialized
ERROR - 2018-03-21 08:03:20 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-21 08:03:20 --> Config Class Initialized
INFO - 2018-03-21 08:03:20 --> Hooks Class Initialized
INFO - 2018-03-21 08:03:20 --> Config Class Initialized
INFO - 2018-03-21 08:03:20 --> Hooks Class Initialized
INFO - 2018-03-21 08:03:20 --> Config Class Initialized
INFO - 2018-03-21 08:03:20 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:03:20 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:03:20 --> Utf8 Class Initialized
DEBUG - 2018-03-21 08:03:20 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:03:20 --> URI Class Initialized
INFO - 2018-03-21 08:03:20 --> Utf8 Class Initialized
DEBUG - 2018-03-21 08:03:20 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:03:20 --> Utf8 Class Initialized
INFO - 2018-03-21 08:03:20 --> URI Class Initialized
INFO - 2018-03-21 08:03:20 --> Router Class Initialized
INFO - 2018-03-21 08:03:20 --> URI Class Initialized
INFO - 2018-03-21 08:03:20 --> Router Class Initialized
INFO - 2018-03-21 08:03:20 --> Output Class Initialized
INFO - 2018-03-21 08:03:20 --> Router Class Initialized
INFO - 2018-03-21 08:03:20 --> Output Class Initialized
INFO - 2018-03-21 08:03:20 --> Security Class Initialized
INFO - 2018-03-21 08:03:20 --> Security Class Initialized
DEBUG - 2018-03-21 08:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:03:20 --> Output Class Initialized
INFO - 2018-03-21 08:03:20 --> Input Class Initialized
DEBUG - 2018-03-21 08:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:03:20 --> Language Class Initialized
INFO - 2018-03-21 08:03:20 --> Input Class Initialized
INFO - 2018-03-21 08:03:20 --> Security Class Initialized
INFO - 2018-03-21 08:03:20 --> Language Class Initialized
ERROR - 2018-03-21 08:03:20 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-03-21 08:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:03:20 --> Input Class Initialized
ERROR - 2018-03-21 08:03:20 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-21 08:03:20 --> Language Class Initialized
ERROR - 2018-03-21 08:03:20 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-21 08:03:20 --> Config Class Initialized
INFO - 2018-03-21 08:03:20 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:03:20 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:03:20 --> Utf8 Class Initialized
INFO - 2018-03-21 08:03:20 --> URI Class Initialized
INFO - 2018-03-21 08:03:20 --> Router Class Initialized
INFO - 2018-03-21 08:03:20 --> Output Class Initialized
INFO - 2018-03-21 08:03:20 --> Security Class Initialized
DEBUG - 2018-03-21 08:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:03:20 --> Input Class Initialized
INFO - 2018-03-21 08:03:20 --> Language Class Initialized
INFO - 2018-03-21 08:03:20 --> Loader Class Initialized
INFO - 2018-03-21 08:03:20 --> Helper loaded: url_helper
INFO - 2018-03-21 08:03:20 --> Helper loaded: form_helper
INFO - 2018-03-21 08:03:20 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:03:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:03:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:03:20 --> Form Validation Class Initialized
INFO - 2018-03-21 08:03:20 --> Model Class Initialized
INFO - 2018-03-21 08:03:20 --> Controller Class Initialized
INFO - 2018-03-21 08:03:20 --> Model Class Initialized
INFO - 2018-03-21 08:03:20 --> Model Class Initialized
INFO - 2018-03-21 08:03:20 --> Model Class Initialized
INFO - 2018-03-21 08:03:20 --> Model Class Initialized
DEBUG - 2018-03-21 08:03:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:03:29 --> Config Class Initialized
INFO - 2018-03-21 08:03:29 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:03:29 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:03:29 --> Utf8 Class Initialized
INFO - 2018-03-21 08:03:29 --> URI Class Initialized
INFO - 2018-03-21 08:03:29 --> Router Class Initialized
INFO - 2018-03-21 08:03:29 --> Output Class Initialized
INFO - 2018-03-21 08:03:29 --> Security Class Initialized
DEBUG - 2018-03-21 08:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:03:29 --> Input Class Initialized
INFO - 2018-03-21 08:03:29 --> Language Class Initialized
INFO - 2018-03-21 08:03:29 --> Loader Class Initialized
INFO - 2018-03-21 08:03:29 --> Helper loaded: url_helper
INFO - 2018-03-21 08:03:29 --> Helper loaded: form_helper
INFO - 2018-03-21 08:03:29 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:03:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:03:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:03:29 --> Form Validation Class Initialized
INFO - 2018-03-21 08:03:29 --> Model Class Initialized
INFO - 2018-03-21 08:03:29 --> Controller Class Initialized
INFO - 2018-03-21 08:03:29 --> Model Class Initialized
INFO - 2018-03-21 08:03:29 --> Model Class Initialized
INFO - 2018-03-21 08:03:29 --> Model Class Initialized
INFO - 2018-03-21 08:03:29 --> Model Class Initialized
DEBUG - 2018-03-21 08:03:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:03:30 --> Config Class Initialized
INFO - 2018-03-21 08:03:30 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:03:30 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:03:30 --> Utf8 Class Initialized
INFO - 2018-03-21 08:03:30 --> URI Class Initialized
INFO - 2018-03-21 08:03:30 --> Router Class Initialized
INFO - 2018-03-21 08:03:30 --> Output Class Initialized
INFO - 2018-03-21 08:03:30 --> Security Class Initialized
DEBUG - 2018-03-21 08:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:03:30 --> Input Class Initialized
INFO - 2018-03-21 08:03:30 --> Language Class Initialized
INFO - 2018-03-21 08:03:30 --> Loader Class Initialized
INFO - 2018-03-21 08:03:30 --> Helper loaded: url_helper
INFO - 2018-03-21 08:03:30 --> Helper loaded: form_helper
INFO - 2018-03-21 08:03:30 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:03:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:03:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:03:30 --> Form Validation Class Initialized
INFO - 2018-03-21 08:03:30 --> Model Class Initialized
INFO - 2018-03-21 08:03:30 --> Controller Class Initialized
INFO - 2018-03-21 08:03:30 --> Model Class Initialized
INFO - 2018-03-21 08:03:30 --> Model Class Initialized
INFO - 2018-03-21 08:03:30 --> Model Class Initialized
INFO - 2018-03-21 08:03:30 --> Model Class Initialized
DEBUG - 2018-03-21 08:03:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:03:30 --> Model Class Initialized
INFO - 2018-03-21 08:03:30 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-21 08:03:30 --> Final output sent to browser
DEBUG - 2018-03-21 08:03:30 --> Total execution time: 0.0721
INFO - 2018-03-21 08:03:30 --> Config Class Initialized
INFO - 2018-03-21 08:03:30 --> Hooks Class Initialized
INFO - 2018-03-21 08:03:30 --> Config Class Initialized
INFO - 2018-03-21 08:03:30 --> Hooks Class Initialized
INFO - 2018-03-21 08:03:30 --> Config Class Initialized
INFO - 2018-03-21 08:03:30 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:03:30 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:03:30 --> Utf8 Class Initialized
INFO - 2018-03-21 08:03:30 --> URI Class Initialized
DEBUG - 2018-03-21 08:03:30 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:03:30 --> Utf8 Class Initialized
INFO - 2018-03-21 08:03:30 --> URI Class Initialized
INFO - 2018-03-21 08:03:30 --> Router Class Initialized
DEBUG - 2018-03-21 08:03:30 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:03:30 --> Utf8 Class Initialized
INFO - 2018-03-21 08:03:30 --> Config Class Initialized
INFO - 2018-03-21 08:03:30 --> Hooks Class Initialized
INFO - 2018-03-21 08:03:30 --> Router Class Initialized
INFO - 2018-03-21 08:03:30 --> URI Class Initialized
INFO - 2018-03-21 08:03:30 --> Output Class Initialized
INFO - 2018-03-21 08:03:30 --> Output Class Initialized
DEBUG - 2018-03-21 08:03:30 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:03:30 --> Router Class Initialized
INFO - 2018-03-21 08:03:30 --> Security Class Initialized
INFO - 2018-03-21 08:03:30 --> Utf8 Class Initialized
INFO - 2018-03-21 08:03:30 --> Security Class Initialized
DEBUG - 2018-03-21 08:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:03:30 --> URI Class Initialized
INFO - 2018-03-21 08:03:30 --> Input Class Initialized
INFO - 2018-03-21 08:03:30 --> Output Class Initialized
INFO - 2018-03-21 08:03:30 --> Language Class Initialized
DEBUG - 2018-03-21 08:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:03:30 --> Input Class Initialized
INFO - 2018-03-21 08:03:30 --> Router Class Initialized
INFO - 2018-03-21 08:03:30 --> Security Class Initialized
INFO - 2018-03-21 08:03:30 --> Language Class Initialized
ERROR - 2018-03-21 08:03:30 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-21 08:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:03:30 --> Output Class Initialized
INFO - 2018-03-21 08:03:30 --> Input Class Initialized
ERROR - 2018-03-21 08:03:30 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-21 08:03:30 --> Language Class Initialized
INFO - 2018-03-21 08:03:30 --> Security Class Initialized
ERROR - 2018-03-21 08:03:30 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-21 08:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:03:30 --> Input Class Initialized
INFO - 2018-03-21 08:03:30 --> Language Class Initialized
ERROR - 2018-03-21 08:03:30 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-21 08:03:30 --> Config Class Initialized
INFO - 2018-03-21 08:03:30 --> Config Class Initialized
INFO - 2018-03-21 08:03:30 --> Hooks Class Initialized
INFO - 2018-03-21 08:03:30 --> Hooks Class Initialized
INFO - 2018-03-21 08:03:30 --> Config Class Initialized
INFO - 2018-03-21 08:03:30 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:03:30 --> UTF-8 Support Enabled
DEBUG - 2018-03-21 08:03:30 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:03:30 --> Utf8 Class Initialized
INFO - 2018-03-21 08:03:30 --> Utf8 Class Initialized
DEBUG - 2018-03-21 08:03:30 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:03:30 --> URI Class Initialized
INFO - 2018-03-21 08:03:30 --> Utf8 Class Initialized
INFO - 2018-03-21 08:03:30 --> URI Class Initialized
INFO - 2018-03-21 08:03:30 --> URI Class Initialized
INFO - 2018-03-21 08:03:30 --> Router Class Initialized
INFO - 2018-03-21 08:03:30 --> Router Class Initialized
INFO - 2018-03-21 08:03:30 --> Router Class Initialized
INFO - 2018-03-21 08:03:30 --> Output Class Initialized
INFO - 2018-03-21 08:03:30 --> Output Class Initialized
INFO - 2018-03-21 08:03:30 --> Security Class Initialized
INFO - 2018-03-21 08:03:30 --> Output Class Initialized
INFO - 2018-03-21 08:03:30 --> Security Class Initialized
DEBUG - 2018-03-21 08:03:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-21 08:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:03:30 --> Security Class Initialized
INFO - 2018-03-21 08:03:30 --> Input Class Initialized
INFO - 2018-03-21 08:03:30 --> Input Class Initialized
INFO - 2018-03-21 08:03:30 --> Language Class Initialized
INFO - 2018-03-21 08:03:30 --> Language Class Initialized
DEBUG - 2018-03-21 08:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:03:30 --> Input Class Initialized
ERROR - 2018-03-21 08:03:30 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-21 08:03:30 --> Language Class Initialized
ERROR - 2018-03-21 08:03:30 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-21 08:03:30 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-21 08:03:30 --> Config Class Initialized
INFO - 2018-03-21 08:03:30 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:03:30 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:03:30 --> Utf8 Class Initialized
INFO - 2018-03-21 08:03:30 --> URI Class Initialized
INFO - 2018-03-21 08:03:30 --> Router Class Initialized
INFO - 2018-03-21 08:03:30 --> Output Class Initialized
INFO - 2018-03-21 08:03:30 --> Security Class Initialized
DEBUG - 2018-03-21 08:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:03:30 --> Input Class Initialized
INFO - 2018-03-21 08:03:30 --> Language Class Initialized
INFO - 2018-03-21 08:03:30 --> Loader Class Initialized
INFO - 2018-03-21 08:03:30 --> Helper loaded: url_helper
INFO - 2018-03-21 08:03:30 --> Helper loaded: form_helper
INFO - 2018-03-21 08:03:30 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:03:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:03:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:03:30 --> Form Validation Class Initialized
INFO - 2018-03-21 08:03:30 --> Model Class Initialized
INFO - 2018-03-21 08:03:30 --> Controller Class Initialized
INFO - 2018-03-21 08:03:30 --> Model Class Initialized
INFO - 2018-03-21 08:03:30 --> Model Class Initialized
INFO - 2018-03-21 08:03:30 --> Model Class Initialized
INFO - 2018-03-21 08:03:30 --> Model Class Initialized
DEBUG - 2018-03-21 08:03:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:03:42 --> Config Class Initialized
INFO - 2018-03-21 08:03:42 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:03:42 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:03:42 --> Utf8 Class Initialized
INFO - 2018-03-21 08:03:42 --> URI Class Initialized
INFO - 2018-03-21 08:03:42 --> Router Class Initialized
INFO - 2018-03-21 08:03:42 --> Output Class Initialized
INFO - 2018-03-21 08:03:42 --> Security Class Initialized
DEBUG - 2018-03-21 08:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:03:42 --> Input Class Initialized
INFO - 2018-03-21 08:03:42 --> Language Class Initialized
INFO - 2018-03-21 08:03:42 --> Loader Class Initialized
INFO - 2018-03-21 08:03:42 --> Helper loaded: url_helper
INFO - 2018-03-21 08:03:42 --> Helper loaded: form_helper
INFO - 2018-03-21 08:03:42 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:03:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:03:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:03:42 --> Form Validation Class Initialized
INFO - 2018-03-21 08:03:42 --> Model Class Initialized
INFO - 2018-03-21 08:03:42 --> Controller Class Initialized
INFO - 2018-03-21 08:03:42 --> Model Class Initialized
INFO - 2018-03-21 08:03:42 --> Model Class Initialized
INFO - 2018-03-21 08:03:42 --> Model Class Initialized
INFO - 2018-03-21 08:03:42 --> Model Class Initialized
DEBUG - 2018-03-21 08:03:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:03:43 --> Config Class Initialized
INFO - 2018-03-21 08:03:43 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:03:43 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:03:43 --> Utf8 Class Initialized
INFO - 2018-03-21 08:03:43 --> URI Class Initialized
INFO - 2018-03-21 08:03:43 --> Router Class Initialized
INFO - 2018-03-21 08:03:43 --> Output Class Initialized
INFO - 2018-03-21 08:03:43 --> Security Class Initialized
DEBUG - 2018-03-21 08:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:03:43 --> Input Class Initialized
INFO - 2018-03-21 08:03:43 --> Language Class Initialized
INFO - 2018-03-21 08:03:43 --> Loader Class Initialized
INFO - 2018-03-21 08:03:43 --> Helper loaded: url_helper
INFO - 2018-03-21 08:03:43 --> Helper loaded: form_helper
INFO - 2018-03-21 08:03:43 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:03:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:03:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:03:43 --> Form Validation Class Initialized
INFO - 2018-03-21 08:03:43 --> Model Class Initialized
INFO - 2018-03-21 08:03:43 --> Controller Class Initialized
INFO - 2018-03-21 08:03:43 --> Model Class Initialized
INFO - 2018-03-21 08:03:43 --> Model Class Initialized
INFO - 2018-03-21 08:03:43 --> Model Class Initialized
INFO - 2018-03-21 08:03:43 --> Model Class Initialized
DEBUG - 2018-03-21 08:03:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:03:43 --> Model Class Initialized
INFO - 2018-03-21 08:03:43 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-21 08:03:43 --> Final output sent to browser
DEBUG - 2018-03-21 08:03:43 --> Total execution time: 0.0639
INFO - 2018-03-21 08:03:44 --> Config Class Initialized
INFO - 2018-03-21 08:03:44 --> Hooks Class Initialized
INFO - 2018-03-21 08:03:44 --> Config Class Initialized
INFO - 2018-03-21 08:03:44 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:03:44 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:03:44 --> Utf8 Class Initialized
INFO - 2018-03-21 08:03:44 --> Config Class Initialized
INFO - 2018-03-21 08:03:44 --> Hooks Class Initialized
INFO - 2018-03-21 08:03:44 --> URI Class Initialized
DEBUG - 2018-03-21 08:03:44 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:03:44 --> Utf8 Class Initialized
DEBUG - 2018-03-21 08:03:44 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:03:44 --> Router Class Initialized
INFO - 2018-03-21 08:03:44 --> URI Class Initialized
INFO - 2018-03-21 08:03:44 --> Utf8 Class Initialized
INFO - 2018-03-21 08:03:44 --> URI Class Initialized
INFO - 2018-03-21 08:03:44 --> Output Class Initialized
INFO - 2018-03-21 08:03:44 --> Router Class Initialized
INFO - 2018-03-21 08:03:44 --> Security Class Initialized
INFO - 2018-03-21 08:03:44 --> Router Class Initialized
INFO - 2018-03-21 08:03:44 --> Output Class Initialized
DEBUG - 2018-03-21 08:03:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:03:44 --> Input Class Initialized
INFO - 2018-03-21 08:03:44 --> Output Class Initialized
INFO - 2018-03-21 08:03:44 --> Security Class Initialized
INFO - 2018-03-21 08:03:44 --> Language Class Initialized
INFO - 2018-03-21 08:03:44 --> Config Class Initialized
INFO - 2018-03-21 08:03:44 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:03:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:03:44 --> Input Class Initialized
INFO - 2018-03-21 08:03:44 --> Security Class Initialized
ERROR - 2018-03-21 08:03:44 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-21 08:03:44 --> Language Class Initialized
DEBUG - 2018-03-21 08:03:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:03:44 --> Input Class Initialized
ERROR - 2018-03-21 08:03:44 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-21 08:03:44 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:03:44 --> Utf8 Class Initialized
INFO - 2018-03-21 08:03:44 --> Language Class Initialized
INFO - 2018-03-21 08:03:44 --> URI Class Initialized
ERROR - 2018-03-21 08:03:44 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-21 08:03:44 --> Router Class Initialized
INFO - 2018-03-21 08:03:44 --> Output Class Initialized
INFO - 2018-03-21 08:03:44 --> Security Class Initialized
DEBUG - 2018-03-21 08:03:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:03:44 --> Input Class Initialized
INFO - 2018-03-21 08:03:44 --> Language Class Initialized
ERROR - 2018-03-21 08:03:44 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-21 08:03:44 --> Config Class Initialized
INFO - 2018-03-21 08:03:44 --> Hooks Class Initialized
INFO - 2018-03-21 08:03:44 --> Config Class Initialized
INFO - 2018-03-21 08:03:44 --> Hooks Class Initialized
INFO - 2018-03-21 08:03:44 --> Config Class Initialized
INFO - 2018-03-21 08:03:44 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:03:44 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:03:44 --> Utf8 Class Initialized
INFO - 2018-03-21 08:03:44 --> URI Class Initialized
DEBUG - 2018-03-21 08:03:44 --> UTF-8 Support Enabled
DEBUG - 2018-03-21 08:03:44 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:03:44 --> Utf8 Class Initialized
INFO - 2018-03-21 08:03:44 --> Utf8 Class Initialized
INFO - 2018-03-21 08:03:44 --> Router Class Initialized
INFO - 2018-03-21 08:03:44 --> URI Class Initialized
INFO - 2018-03-21 08:03:44 --> URI Class Initialized
INFO - 2018-03-21 08:03:44 --> Output Class Initialized
INFO - 2018-03-21 08:03:44 --> Router Class Initialized
INFO - 2018-03-21 08:03:44 --> Router Class Initialized
INFO - 2018-03-21 08:03:44 --> Security Class Initialized
DEBUG - 2018-03-21 08:03:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:03:44 --> Output Class Initialized
INFO - 2018-03-21 08:03:44 --> Output Class Initialized
INFO - 2018-03-21 08:03:44 --> Input Class Initialized
INFO - 2018-03-21 08:03:44 --> Language Class Initialized
INFO - 2018-03-21 08:03:44 --> Security Class Initialized
INFO - 2018-03-21 08:03:44 --> Security Class Initialized
ERROR - 2018-03-21 08:03:44 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-03-21 08:03:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-21 08:03:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:03:44 --> Input Class Initialized
INFO - 2018-03-21 08:03:44 --> Input Class Initialized
INFO - 2018-03-21 08:03:44 --> Language Class Initialized
INFO - 2018-03-21 08:03:44 --> Language Class Initialized
ERROR - 2018-03-21 08:03:44 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-21 08:03:44 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-21 08:03:44 --> Config Class Initialized
INFO - 2018-03-21 08:03:44 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:03:44 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:03:44 --> Utf8 Class Initialized
INFO - 2018-03-21 08:03:44 --> URI Class Initialized
INFO - 2018-03-21 08:03:44 --> Router Class Initialized
INFO - 2018-03-21 08:03:44 --> Output Class Initialized
INFO - 2018-03-21 08:03:44 --> Security Class Initialized
DEBUG - 2018-03-21 08:03:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:03:44 --> Input Class Initialized
INFO - 2018-03-21 08:03:44 --> Language Class Initialized
INFO - 2018-03-21 08:03:44 --> Loader Class Initialized
INFO - 2018-03-21 08:03:44 --> Helper loaded: url_helper
INFO - 2018-03-21 08:03:44 --> Helper loaded: form_helper
INFO - 2018-03-21 08:03:44 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:03:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:03:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:03:44 --> Form Validation Class Initialized
INFO - 2018-03-21 08:03:44 --> Model Class Initialized
INFO - 2018-03-21 08:03:44 --> Controller Class Initialized
INFO - 2018-03-21 08:03:44 --> Model Class Initialized
INFO - 2018-03-21 08:03:44 --> Model Class Initialized
INFO - 2018-03-21 08:03:44 --> Model Class Initialized
INFO - 2018-03-21 08:03:44 --> Model Class Initialized
DEBUG - 2018-03-21 08:03:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:05:01 --> Config Class Initialized
INFO - 2018-03-21 08:05:01 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:05:01 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:05:01 --> Utf8 Class Initialized
INFO - 2018-03-21 08:05:01 --> URI Class Initialized
INFO - 2018-03-21 08:05:01 --> Router Class Initialized
INFO - 2018-03-21 08:05:01 --> Output Class Initialized
INFO - 2018-03-21 08:05:01 --> Security Class Initialized
DEBUG - 2018-03-21 08:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:05:01 --> Input Class Initialized
INFO - 2018-03-21 08:05:01 --> Language Class Initialized
INFO - 2018-03-21 08:05:02 --> Loader Class Initialized
INFO - 2018-03-21 08:05:02 --> Helper loaded: url_helper
INFO - 2018-03-21 08:05:02 --> Helper loaded: form_helper
INFO - 2018-03-21 08:05:02 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:05:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:05:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:05:02 --> Form Validation Class Initialized
INFO - 2018-03-21 08:05:02 --> Model Class Initialized
INFO - 2018-03-21 08:05:02 --> Controller Class Initialized
INFO - 2018-03-21 08:05:02 --> Model Class Initialized
INFO - 2018-03-21 08:05:02 --> Model Class Initialized
INFO - 2018-03-21 08:05:02 --> Model Class Initialized
INFO - 2018-03-21 08:05:02 --> Model Class Initialized
DEBUG - 2018-03-21 08:05:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:05:02 --> Model Class Initialized
INFO - 2018-03-21 08:05:02 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-21 08:05:02 --> Final output sent to browser
DEBUG - 2018-03-21 08:05:02 --> Total execution time: 0.0560
INFO - 2018-03-21 08:05:02 --> Config Class Initialized
INFO - 2018-03-21 08:05:02 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:05:02 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:05:02 --> Utf8 Class Initialized
INFO - 2018-03-21 08:05:02 --> Config Class Initialized
INFO - 2018-03-21 08:05:02 --> Hooks Class Initialized
INFO - 2018-03-21 08:05:02 --> URI Class Initialized
DEBUG - 2018-03-21 08:05:02 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:05:02 --> Router Class Initialized
INFO - 2018-03-21 08:05:02 --> Utf8 Class Initialized
INFO - 2018-03-21 08:05:02 --> Config Class Initialized
INFO - 2018-03-21 08:05:02 --> Hooks Class Initialized
INFO - 2018-03-21 08:05:02 --> URI Class Initialized
INFO - 2018-03-21 08:05:02 --> Output Class Initialized
INFO - 2018-03-21 08:05:02 --> Security Class Initialized
INFO - 2018-03-21 08:05:02 --> Router Class Initialized
DEBUG - 2018-03-21 08:05:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-21 08:05:02 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:05:02 --> Input Class Initialized
INFO - 2018-03-21 08:05:02 --> Utf8 Class Initialized
INFO - 2018-03-21 08:05:02 --> Output Class Initialized
INFO - 2018-03-21 08:05:02 --> Language Class Initialized
INFO - 2018-03-21 08:05:02 --> URI Class Initialized
INFO - 2018-03-21 08:05:02 --> Security Class Initialized
ERROR - 2018-03-21 08:05:02 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-21 08:05:02 --> Router Class Initialized
DEBUG - 2018-03-21 08:05:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:05:02 --> Input Class Initialized
INFO - 2018-03-21 08:05:02 --> Output Class Initialized
INFO - 2018-03-21 08:05:02 --> Language Class Initialized
INFO - 2018-03-21 08:05:02 --> Config Class Initialized
INFO - 2018-03-21 08:05:02 --> Hooks Class Initialized
INFO - 2018-03-21 08:05:02 --> Security Class Initialized
ERROR - 2018-03-21 08:05:02 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-21 08:05:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:05:02 --> Input Class Initialized
DEBUG - 2018-03-21 08:05:02 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:05:02 --> Utf8 Class Initialized
INFO - 2018-03-21 08:05:02 --> Language Class Initialized
INFO - 2018-03-21 08:05:02 --> URI Class Initialized
ERROR - 2018-03-21 08:05:02 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-21 08:05:02 --> Router Class Initialized
INFO - 2018-03-21 08:05:02 --> Output Class Initialized
INFO - 2018-03-21 08:05:02 --> Security Class Initialized
DEBUG - 2018-03-21 08:05:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:05:02 --> Input Class Initialized
INFO - 2018-03-21 08:05:02 --> Language Class Initialized
ERROR - 2018-03-21 08:05:02 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-21 08:05:02 --> Config Class Initialized
INFO - 2018-03-21 08:05:02 --> Hooks Class Initialized
INFO - 2018-03-21 08:05:02 --> Config Class Initialized
INFO - 2018-03-21 08:05:02 --> Config Class Initialized
INFO - 2018-03-21 08:05:02 --> Hooks Class Initialized
INFO - 2018-03-21 08:05:02 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:05:02 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:05:02 --> Utf8 Class Initialized
INFO - 2018-03-21 08:05:02 --> URI Class Initialized
DEBUG - 2018-03-21 08:05:02 --> UTF-8 Support Enabled
DEBUG - 2018-03-21 08:05:02 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:05:02 --> Utf8 Class Initialized
INFO - 2018-03-21 08:05:02 --> Utf8 Class Initialized
INFO - 2018-03-21 08:05:02 --> Router Class Initialized
INFO - 2018-03-21 08:05:02 --> URI Class Initialized
INFO - 2018-03-21 08:05:02 --> URI Class Initialized
INFO - 2018-03-21 08:05:02 --> Output Class Initialized
INFO - 2018-03-21 08:05:02 --> Router Class Initialized
INFO - 2018-03-21 08:05:02 --> Router Class Initialized
INFO - 2018-03-21 08:05:02 --> Security Class Initialized
DEBUG - 2018-03-21 08:05:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:05:02 --> Output Class Initialized
INFO - 2018-03-21 08:05:02 --> Input Class Initialized
INFO - 2018-03-21 08:05:02 --> Output Class Initialized
INFO - 2018-03-21 08:05:02 --> Language Class Initialized
INFO - 2018-03-21 08:05:02 --> Security Class Initialized
INFO - 2018-03-21 08:05:02 --> Security Class Initialized
ERROR - 2018-03-21 08:05:02 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-03-21 08:05:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-21 08:05:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:05:02 --> Input Class Initialized
INFO - 2018-03-21 08:05:02 --> Input Class Initialized
INFO - 2018-03-21 08:05:02 --> Language Class Initialized
INFO - 2018-03-21 08:05:02 --> Language Class Initialized
ERROR - 2018-03-21 08:05:02 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-21 08:05:02 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-21 08:05:02 --> Config Class Initialized
INFO - 2018-03-21 08:05:02 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:05:02 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:05:02 --> Utf8 Class Initialized
INFO - 2018-03-21 08:05:02 --> URI Class Initialized
INFO - 2018-03-21 08:05:02 --> Router Class Initialized
INFO - 2018-03-21 08:05:02 --> Output Class Initialized
INFO - 2018-03-21 08:05:02 --> Security Class Initialized
DEBUG - 2018-03-21 08:05:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:05:02 --> Input Class Initialized
INFO - 2018-03-21 08:05:02 --> Language Class Initialized
INFO - 2018-03-21 08:05:02 --> Loader Class Initialized
INFO - 2018-03-21 08:05:02 --> Helper loaded: url_helper
INFO - 2018-03-21 08:05:02 --> Helper loaded: form_helper
INFO - 2018-03-21 08:05:02 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:05:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:05:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:05:02 --> Form Validation Class Initialized
INFO - 2018-03-21 08:05:02 --> Model Class Initialized
INFO - 2018-03-21 08:05:02 --> Controller Class Initialized
INFO - 2018-03-21 08:05:02 --> Model Class Initialized
INFO - 2018-03-21 08:05:02 --> Model Class Initialized
INFO - 2018-03-21 08:05:02 --> Model Class Initialized
INFO - 2018-03-21 08:05:02 --> Model Class Initialized
DEBUG - 2018-03-21 08:05:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:05:29 --> Config Class Initialized
INFO - 2018-03-21 08:05:29 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:05:29 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:05:29 --> Utf8 Class Initialized
INFO - 2018-03-21 08:05:29 --> URI Class Initialized
INFO - 2018-03-21 08:05:29 --> Router Class Initialized
INFO - 2018-03-21 08:05:29 --> Output Class Initialized
INFO - 2018-03-21 08:05:29 --> Security Class Initialized
DEBUG - 2018-03-21 08:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:05:29 --> Input Class Initialized
INFO - 2018-03-21 08:05:29 --> Language Class Initialized
INFO - 2018-03-21 08:05:29 --> Loader Class Initialized
INFO - 2018-03-21 08:05:29 --> Helper loaded: url_helper
INFO - 2018-03-21 08:05:29 --> Helper loaded: form_helper
INFO - 2018-03-21 08:05:29 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:05:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:05:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:05:29 --> Form Validation Class Initialized
INFO - 2018-03-21 08:05:29 --> Model Class Initialized
INFO - 2018-03-21 08:05:29 --> Controller Class Initialized
INFO - 2018-03-21 08:05:30 --> Model Class Initialized
INFO - 2018-03-21 08:05:30 --> Model Class Initialized
INFO - 2018-03-21 08:05:30 --> Model Class Initialized
INFO - 2018-03-21 08:05:30 --> Model Class Initialized
DEBUG - 2018-03-21 08:05:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:05:30 --> Model Class Initialized
INFO - 2018-03-21 08:05:30 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-21 08:05:30 --> Final output sent to browser
DEBUG - 2018-03-21 08:05:30 --> Total execution time: 0.1000
INFO - 2018-03-21 08:05:30 --> Config Class Initialized
INFO - 2018-03-21 08:05:30 --> Hooks Class Initialized
INFO - 2018-03-21 08:05:30 --> Config Class Initialized
INFO - 2018-03-21 08:05:30 --> Hooks Class Initialized
INFO - 2018-03-21 08:05:30 --> Config Class Initialized
INFO - 2018-03-21 08:05:30 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:05:30 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:05:30 --> Utf8 Class Initialized
DEBUG - 2018-03-21 08:05:30 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:05:30 --> Utf8 Class Initialized
INFO - 2018-03-21 08:05:30 --> URI Class Initialized
DEBUG - 2018-03-21 08:05:30 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:05:30 --> Utf8 Class Initialized
INFO - 2018-03-21 08:05:30 --> URI Class Initialized
INFO - 2018-03-21 08:05:30 --> Router Class Initialized
INFO - 2018-03-21 08:05:30 --> URI Class Initialized
INFO - 2018-03-21 08:05:30 --> Router Class Initialized
INFO - 2018-03-21 08:05:30 --> Output Class Initialized
INFO - 2018-03-21 08:05:30 --> Router Class Initialized
INFO - 2018-03-21 08:05:30 --> Output Class Initialized
INFO - 2018-03-21 08:05:30 --> Security Class Initialized
INFO - 2018-03-21 08:05:30 --> Config Class Initialized
INFO - 2018-03-21 08:05:30 --> Hooks Class Initialized
INFO - 2018-03-21 08:05:30 --> Output Class Initialized
INFO - 2018-03-21 08:05:30 --> Security Class Initialized
DEBUG - 2018-03-21 08:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:05:30 --> Input Class Initialized
INFO - 2018-03-21 08:05:30 --> Security Class Initialized
DEBUG - 2018-03-21 08:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:05:30 --> Language Class Initialized
INFO - 2018-03-21 08:05:30 --> Input Class Initialized
DEBUG - 2018-03-21 08:05:30 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:05:30 --> Language Class Initialized
ERROR - 2018-03-21 08:05:30 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-21 08:05:30 --> Utf8 Class Initialized
DEBUG - 2018-03-21 08:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:05:30 --> Input Class Initialized
ERROR - 2018-03-21 08:05:30 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-21 08:05:30 --> Language Class Initialized
INFO - 2018-03-21 08:05:30 --> URI Class Initialized
ERROR - 2018-03-21 08:05:30 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-21 08:05:30 --> Router Class Initialized
INFO - 2018-03-21 08:05:30 --> Output Class Initialized
INFO - 2018-03-21 08:05:30 --> Security Class Initialized
DEBUG - 2018-03-21 08:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:05:30 --> Input Class Initialized
INFO - 2018-03-21 08:05:30 --> Language Class Initialized
ERROR - 2018-03-21 08:05:30 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-21 08:05:30 --> Config Class Initialized
INFO - 2018-03-21 08:05:30 --> Hooks Class Initialized
INFO - 2018-03-21 08:05:30 --> Config Class Initialized
INFO - 2018-03-21 08:05:30 --> Hooks Class Initialized
INFO - 2018-03-21 08:05:30 --> Config Class Initialized
INFO - 2018-03-21 08:05:30 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:05:30 --> UTF-8 Support Enabled
DEBUG - 2018-03-21 08:05:30 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:05:30 --> Utf8 Class Initialized
INFO - 2018-03-21 08:05:30 --> Utf8 Class Initialized
DEBUG - 2018-03-21 08:05:30 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:05:30 --> URI Class Initialized
INFO - 2018-03-21 08:05:30 --> URI Class Initialized
INFO - 2018-03-21 08:05:30 --> Utf8 Class Initialized
INFO - 2018-03-21 08:05:30 --> URI Class Initialized
INFO - 2018-03-21 08:05:30 --> Router Class Initialized
INFO - 2018-03-21 08:05:30 --> Router Class Initialized
INFO - 2018-03-21 08:05:30 --> Router Class Initialized
INFO - 2018-03-21 08:05:30 --> Output Class Initialized
INFO - 2018-03-21 08:05:30 --> Output Class Initialized
INFO - 2018-03-21 08:05:30 --> Security Class Initialized
INFO - 2018-03-21 08:05:30 --> Output Class Initialized
INFO - 2018-03-21 08:05:30 --> Security Class Initialized
DEBUG - 2018-03-21 08:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:05:30 --> Input Class Initialized
INFO - 2018-03-21 08:05:30 --> Security Class Initialized
DEBUG - 2018-03-21 08:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:05:30 --> Language Class Initialized
INFO - 2018-03-21 08:05:30 --> Input Class Initialized
DEBUG - 2018-03-21 08:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:05:30 --> Language Class Initialized
INFO - 2018-03-21 08:05:30 --> Input Class Initialized
ERROR - 2018-03-21 08:05:30 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-21 08:05:30 --> Language Class Initialized
ERROR - 2018-03-21 08:05:30 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-21 08:05:30 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-21 08:05:30 --> Config Class Initialized
INFO - 2018-03-21 08:05:30 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:05:30 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:05:30 --> Utf8 Class Initialized
INFO - 2018-03-21 08:05:30 --> URI Class Initialized
INFO - 2018-03-21 08:05:30 --> Router Class Initialized
INFO - 2018-03-21 08:05:30 --> Output Class Initialized
INFO - 2018-03-21 08:05:30 --> Security Class Initialized
DEBUG - 2018-03-21 08:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:05:30 --> Input Class Initialized
INFO - 2018-03-21 08:05:30 --> Language Class Initialized
INFO - 2018-03-21 08:05:30 --> Loader Class Initialized
INFO - 2018-03-21 08:05:30 --> Helper loaded: url_helper
INFO - 2018-03-21 08:05:30 --> Helper loaded: form_helper
INFO - 2018-03-21 08:05:30 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:05:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:05:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:05:30 --> Form Validation Class Initialized
INFO - 2018-03-21 08:05:30 --> Model Class Initialized
INFO - 2018-03-21 08:05:30 --> Controller Class Initialized
INFO - 2018-03-21 08:05:30 --> Model Class Initialized
INFO - 2018-03-21 08:05:30 --> Model Class Initialized
INFO - 2018-03-21 08:05:30 --> Model Class Initialized
INFO - 2018-03-21 08:05:30 --> Model Class Initialized
DEBUG - 2018-03-21 08:05:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:05:31 --> Config Class Initialized
INFO - 2018-03-21 08:05:31 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:05:31 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:05:31 --> Utf8 Class Initialized
INFO - 2018-03-21 08:05:31 --> URI Class Initialized
INFO - 2018-03-21 08:05:31 --> Router Class Initialized
INFO - 2018-03-21 08:05:31 --> Output Class Initialized
INFO - 2018-03-21 08:05:31 --> Security Class Initialized
DEBUG - 2018-03-21 08:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:05:31 --> Input Class Initialized
INFO - 2018-03-21 08:05:31 --> Language Class Initialized
INFO - 2018-03-21 08:05:31 --> Loader Class Initialized
INFO - 2018-03-21 08:05:31 --> Helper loaded: url_helper
INFO - 2018-03-21 08:05:31 --> Helper loaded: form_helper
INFO - 2018-03-21 08:05:31 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:05:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:05:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:05:31 --> Form Validation Class Initialized
INFO - 2018-03-21 08:05:31 --> Model Class Initialized
INFO - 2018-03-21 08:05:31 --> Controller Class Initialized
INFO - 2018-03-21 08:05:31 --> Model Class Initialized
INFO - 2018-03-21 08:05:31 --> Model Class Initialized
INFO - 2018-03-21 08:05:31 --> Model Class Initialized
INFO - 2018-03-21 08:05:31 --> Model Class Initialized
DEBUG - 2018-03-21 08:05:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:05:31 --> Model Class Initialized
INFO - 2018-03-21 08:05:31 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-21 08:05:31 --> Final output sent to browser
DEBUG - 2018-03-21 08:05:31 --> Total execution time: 0.1215
INFO - 2018-03-21 08:05:32 --> Config Class Initialized
INFO - 2018-03-21 08:05:32 --> Config Class Initialized
INFO - 2018-03-21 08:05:32 --> Hooks Class Initialized
INFO - 2018-03-21 08:05:32 --> Hooks Class Initialized
INFO - 2018-03-21 08:05:32 --> Config Class Initialized
INFO - 2018-03-21 08:05:32 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:05:32 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:05:32 --> Utf8 Class Initialized
DEBUG - 2018-03-21 08:05:32 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:05:32 --> Utf8 Class Initialized
INFO - 2018-03-21 08:05:32 --> URI Class Initialized
INFO - 2018-03-21 08:05:32 --> URI Class Initialized
INFO - 2018-03-21 08:05:32 --> Router Class Initialized
DEBUG - 2018-03-21 08:05:32 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:05:32 --> Config Class Initialized
INFO - 2018-03-21 08:05:32 --> Router Class Initialized
INFO - 2018-03-21 08:05:32 --> Utf8 Class Initialized
INFO - 2018-03-21 08:05:32 --> Hooks Class Initialized
INFO - 2018-03-21 08:05:32 --> Output Class Initialized
INFO - 2018-03-21 08:05:32 --> URI Class Initialized
INFO - 2018-03-21 08:05:32 --> Output Class Initialized
INFO - 2018-03-21 08:05:32 --> Security Class Initialized
DEBUG - 2018-03-21 08:05:32 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:05:32 --> Utf8 Class Initialized
INFO - 2018-03-21 08:05:32 --> Router Class Initialized
DEBUG - 2018-03-21 08:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:05:32 --> Security Class Initialized
INFO - 2018-03-21 08:05:32 --> Input Class Initialized
INFO - 2018-03-21 08:05:32 --> URI Class Initialized
INFO - 2018-03-21 08:05:32 --> Output Class Initialized
INFO - 2018-03-21 08:05:32 --> Language Class Initialized
DEBUG - 2018-03-21 08:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:05:32 --> Router Class Initialized
INFO - 2018-03-21 08:05:32 --> Input Class Initialized
ERROR - 2018-03-21 08:05:32 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-21 08:05:32 --> Security Class Initialized
DEBUG - 2018-03-21 08:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:05:32 --> Language Class Initialized
INFO - 2018-03-21 08:05:32 --> Output Class Initialized
INFO - 2018-03-21 08:05:32 --> Input Class Initialized
INFO - 2018-03-21 08:05:32 --> Language Class Initialized
INFO - 2018-03-21 08:05:32 --> Security Class Initialized
ERROR - 2018-03-21 08:05:32 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-21 08:05:32 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-21 08:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:05:32 --> Input Class Initialized
INFO - 2018-03-21 08:05:32 --> Language Class Initialized
ERROR - 2018-03-21 08:05:32 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-21 08:05:32 --> Config Class Initialized
INFO - 2018-03-21 08:05:32 --> Hooks Class Initialized
INFO - 2018-03-21 08:05:32 --> Config Class Initialized
INFO - 2018-03-21 08:05:32 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:05:32 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:05:32 --> Utf8 Class Initialized
DEBUG - 2018-03-21 08:05:32 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:05:32 --> Utf8 Class Initialized
INFO - 2018-03-21 08:05:32 --> URI Class Initialized
INFO - 2018-03-21 08:05:32 --> Config Class Initialized
INFO - 2018-03-21 08:05:32 --> Hooks Class Initialized
INFO - 2018-03-21 08:05:32 --> URI Class Initialized
INFO - 2018-03-21 08:05:32 --> Router Class Initialized
INFO - 2018-03-21 08:05:32 --> Router Class Initialized
DEBUG - 2018-03-21 08:05:32 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:05:32 --> Utf8 Class Initialized
INFO - 2018-03-21 08:05:32 --> Output Class Initialized
INFO - 2018-03-21 08:05:32 --> Output Class Initialized
INFO - 2018-03-21 08:05:32 --> URI Class Initialized
INFO - 2018-03-21 08:05:32 --> Security Class Initialized
INFO - 2018-03-21 08:05:32 --> Security Class Initialized
DEBUG - 2018-03-21 08:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:05:32 --> Router Class Initialized
INFO - 2018-03-21 08:05:32 --> Input Class Initialized
DEBUG - 2018-03-21 08:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:05:32 --> Language Class Initialized
INFO - 2018-03-21 08:05:32 --> Input Class Initialized
INFO - 2018-03-21 08:05:32 --> Output Class Initialized
INFO - 2018-03-21 08:05:32 --> Language Class Initialized
ERROR - 2018-03-21 08:05:32 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-21 08:05:32 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-21 08:05:32 --> Security Class Initialized
DEBUG - 2018-03-21 08:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:05:32 --> Input Class Initialized
INFO - 2018-03-21 08:05:32 --> Language Class Initialized
ERROR - 2018-03-21 08:05:32 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-21 08:05:32 --> Config Class Initialized
INFO - 2018-03-21 08:05:32 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:05:32 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:05:32 --> Utf8 Class Initialized
INFO - 2018-03-21 08:05:32 --> URI Class Initialized
INFO - 2018-03-21 08:05:32 --> Router Class Initialized
INFO - 2018-03-21 08:05:32 --> Output Class Initialized
INFO - 2018-03-21 08:05:32 --> Security Class Initialized
DEBUG - 2018-03-21 08:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:05:32 --> Input Class Initialized
INFO - 2018-03-21 08:05:32 --> Language Class Initialized
INFO - 2018-03-21 08:05:32 --> Loader Class Initialized
INFO - 2018-03-21 08:05:32 --> Helper loaded: url_helper
INFO - 2018-03-21 08:05:32 --> Helper loaded: form_helper
INFO - 2018-03-21 08:05:32 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:05:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:05:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:05:32 --> Form Validation Class Initialized
INFO - 2018-03-21 08:05:32 --> Model Class Initialized
INFO - 2018-03-21 08:05:32 --> Controller Class Initialized
INFO - 2018-03-21 08:05:32 --> Model Class Initialized
INFO - 2018-03-21 08:05:32 --> Model Class Initialized
INFO - 2018-03-21 08:05:32 --> Model Class Initialized
INFO - 2018-03-21 08:05:32 --> Model Class Initialized
DEBUG - 2018-03-21 08:05:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:05:42 --> Config Class Initialized
INFO - 2018-03-21 08:05:42 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:05:42 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:05:42 --> Utf8 Class Initialized
INFO - 2018-03-21 08:05:42 --> URI Class Initialized
INFO - 2018-03-21 08:05:42 --> Router Class Initialized
INFO - 2018-03-21 08:05:42 --> Output Class Initialized
INFO - 2018-03-21 08:05:42 --> Security Class Initialized
DEBUG - 2018-03-21 08:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:05:42 --> Input Class Initialized
INFO - 2018-03-21 08:05:42 --> Language Class Initialized
INFO - 2018-03-21 08:05:42 --> Loader Class Initialized
INFO - 2018-03-21 08:05:42 --> Helper loaded: url_helper
INFO - 2018-03-21 08:05:42 --> Helper loaded: form_helper
INFO - 2018-03-21 08:05:42 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:05:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:05:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:05:42 --> Form Validation Class Initialized
INFO - 2018-03-21 08:05:42 --> Model Class Initialized
INFO - 2018-03-21 08:05:42 --> Controller Class Initialized
INFO - 2018-03-21 08:05:42 --> Model Class Initialized
INFO - 2018-03-21 08:05:42 --> Model Class Initialized
INFO - 2018-03-21 08:05:42 --> Model Class Initialized
INFO - 2018-03-21 08:05:42 --> Model Class Initialized
DEBUG - 2018-03-21 08:05:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:05:43 --> Config Class Initialized
INFO - 2018-03-21 08:05:43 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:05:43 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:05:43 --> Utf8 Class Initialized
INFO - 2018-03-21 08:05:43 --> URI Class Initialized
INFO - 2018-03-21 08:05:43 --> Router Class Initialized
INFO - 2018-03-21 08:05:43 --> Output Class Initialized
INFO - 2018-03-21 08:05:43 --> Security Class Initialized
DEBUG - 2018-03-21 08:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:05:43 --> Input Class Initialized
INFO - 2018-03-21 08:05:43 --> Language Class Initialized
INFO - 2018-03-21 08:05:43 --> Loader Class Initialized
INFO - 2018-03-21 08:05:43 --> Helper loaded: url_helper
INFO - 2018-03-21 08:05:43 --> Helper loaded: form_helper
INFO - 2018-03-21 08:05:43 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:05:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:05:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:05:43 --> Form Validation Class Initialized
INFO - 2018-03-21 08:05:43 --> Model Class Initialized
INFO - 2018-03-21 08:05:43 --> Controller Class Initialized
INFO - 2018-03-21 08:05:43 --> Model Class Initialized
INFO - 2018-03-21 08:05:43 --> Model Class Initialized
INFO - 2018-03-21 08:05:43 --> Model Class Initialized
INFO - 2018-03-21 08:05:43 --> Model Class Initialized
DEBUG - 2018-03-21 08:05:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:05:43 --> Model Class Initialized
INFO - 2018-03-21 08:05:43 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-21 08:05:43 --> Final output sent to browser
DEBUG - 2018-03-21 08:05:43 --> Total execution time: 0.0706
INFO - 2018-03-21 08:05:43 --> Config Class Initialized
INFO - 2018-03-21 08:05:43 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:05:43 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:05:43 --> Utf8 Class Initialized
INFO - 2018-03-21 08:05:43 --> URI Class Initialized
INFO - 2018-03-21 08:05:43 --> Router Class Initialized
INFO - 2018-03-21 08:05:43 --> Output Class Initialized
INFO - 2018-03-21 08:05:43 --> Security Class Initialized
DEBUG - 2018-03-21 08:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:05:43 --> Input Class Initialized
INFO - 2018-03-21 08:05:43 --> Language Class Initialized
INFO - 2018-03-21 08:05:43 --> Loader Class Initialized
INFO - 2018-03-21 08:05:43 --> Helper loaded: url_helper
INFO - 2018-03-21 08:05:43 --> Helper loaded: form_helper
INFO - 2018-03-21 08:05:43 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:05:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:05:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:05:43 --> Form Validation Class Initialized
INFO - 2018-03-21 08:05:43 --> Model Class Initialized
INFO - 2018-03-21 08:05:43 --> Controller Class Initialized
INFO - 2018-03-21 08:05:43 --> Model Class Initialized
INFO - 2018-03-21 08:05:43 --> Model Class Initialized
INFO - 2018-03-21 08:05:43 --> Model Class Initialized
INFO - 2018-03-21 08:05:43 --> Model Class Initialized
DEBUG - 2018-03-21 08:05:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:06:33 --> Config Class Initialized
INFO - 2018-03-21 08:06:33 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:06:33 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:06:33 --> Utf8 Class Initialized
INFO - 2018-03-21 08:06:33 --> URI Class Initialized
INFO - 2018-03-21 08:06:33 --> Router Class Initialized
INFO - 2018-03-21 08:06:33 --> Output Class Initialized
INFO - 2018-03-21 08:06:33 --> Security Class Initialized
DEBUG - 2018-03-21 08:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:06:33 --> Input Class Initialized
INFO - 2018-03-21 08:06:33 --> Language Class Initialized
INFO - 2018-03-21 08:06:33 --> Loader Class Initialized
INFO - 2018-03-21 08:06:33 --> Helper loaded: url_helper
INFO - 2018-03-21 08:06:33 --> Helper loaded: form_helper
INFO - 2018-03-21 08:06:33 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:06:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:06:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:06:33 --> Form Validation Class Initialized
INFO - 2018-03-21 08:06:33 --> Model Class Initialized
INFO - 2018-03-21 08:06:33 --> Controller Class Initialized
INFO - 2018-03-21 08:06:33 --> Model Class Initialized
INFO - 2018-03-21 08:06:33 --> Model Class Initialized
INFO - 2018-03-21 08:06:33 --> Model Class Initialized
INFO - 2018-03-21 08:06:33 --> Model Class Initialized
DEBUG - 2018-03-21 08:06:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:06:33 --> Model Class Initialized
INFO - 2018-03-21 08:06:33 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-21 08:06:33 --> Final output sent to browser
DEBUG - 2018-03-21 08:06:33 --> Total execution time: 0.0594
INFO - 2018-03-21 08:06:33 --> Config Class Initialized
INFO - 2018-03-21 08:06:33 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:06:33 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:06:33 --> Utf8 Class Initialized
INFO - 2018-03-21 08:06:33 --> URI Class Initialized
INFO - 2018-03-21 08:06:33 --> Router Class Initialized
INFO - 2018-03-21 08:06:33 --> Output Class Initialized
INFO - 2018-03-21 08:06:33 --> Security Class Initialized
DEBUG - 2018-03-21 08:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:06:33 --> Input Class Initialized
INFO - 2018-03-21 08:06:33 --> Language Class Initialized
INFO - 2018-03-21 08:06:33 --> Loader Class Initialized
INFO - 2018-03-21 08:06:33 --> Helper loaded: url_helper
INFO - 2018-03-21 08:06:33 --> Helper loaded: form_helper
INFO - 2018-03-21 08:06:33 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:06:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:06:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:06:33 --> Form Validation Class Initialized
INFO - 2018-03-21 08:06:33 --> Model Class Initialized
INFO - 2018-03-21 08:06:33 --> Controller Class Initialized
INFO - 2018-03-21 08:06:33 --> Model Class Initialized
INFO - 2018-03-21 08:06:33 --> Model Class Initialized
INFO - 2018-03-21 08:06:33 --> Model Class Initialized
INFO - 2018-03-21 08:06:33 --> Model Class Initialized
DEBUG - 2018-03-21 08:06:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:06:36 --> Config Class Initialized
INFO - 2018-03-21 08:06:36 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:06:36 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:06:36 --> Utf8 Class Initialized
INFO - 2018-03-21 08:06:36 --> URI Class Initialized
INFO - 2018-03-21 08:06:36 --> Router Class Initialized
INFO - 2018-03-21 08:06:36 --> Output Class Initialized
INFO - 2018-03-21 08:06:36 --> Security Class Initialized
DEBUG - 2018-03-21 08:06:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:06:36 --> Input Class Initialized
INFO - 2018-03-21 08:06:36 --> Language Class Initialized
INFO - 2018-03-21 08:06:36 --> Loader Class Initialized
INFO - 2018-03-21 08:06:36 --> Helper loaded: url_helper
INFO - 2018-03-21 08:06:36 --> Helper loaded: form_helper
INFO - 2018-03-21 08:06:36 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:06:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:06:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:06:36 --> Form Validation Class Initialized
INFO - 2018-03-21 08:06:36 --> Model Class Initialized
INFO - 2018-03-21 08:06:36 --> Controller Class Initialized
INFO - 2018-03-21 08:06:36 --> Model Class Initialized
INFO - 2018-03-21 08:06:36 --> Model Class Initialized
INFO - 2018-03-21 08:06:36 --> Model Class Initialized
INFO - 2018-03-21 08:06:36 --> Model Class Initialized
DEBUG - 2018-03-21 08:06:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:06:38 --> Config Class Initialized
INFO - 2018-03-21 08:06:38 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:06:38 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:06:38 --> Utf8 Class Initialized
INFO - 2018-03-21 08:06:38 --> URI Class Initialized
INFO - 2018-03-21 08:06:38 --> Router Class Initialized
INFO - 2018-03-21 08:06:38 --> Output Class Initialized
INFO - 2018-03-21 08:06:38 --> Security Class Initialized
DEBUG - 2018-03-21 08:06:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:06:38 --> Input Class Initialized
INFO - 2018-03-21 08:06:38 --> Language Class Initialized
INFO - 2018-03-21 08:06:38 --> Loader Class Initialized
INFO - 2018-03-21 08:06:38 --> Helper loaded: url_helper
INFO - 2018-03-21 08:06:38 --> Helper loaded: form_helper
INFO - 2018-03-21 08:06:38 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:06:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:06:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:06:38 --> Form Validation Class Initialized
INFO - 2018-03-21 08:06:38 --> Model Class Initialized
INFO - 2018-03-21 08:06:38 --> Controller Class Initialized
INFO - 2018-03-21 08:06:38 --> Model Class Initialized
INFO - 2018-03-21 08:06:38 --> Model Class Initialized
INFO - 2018-03-21 08:06:38 --> Model Class Initialized
INFO - 2018-03-21 08:06:38 --> Model Class Initialized
DEBUG - 2018-03-21 08:06:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:06:38 --> Model Class Initialized
INFO - 2018-03-21 08:06:38 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-21 08:06:38 --> Final output sent to browser
DEBUG - 2018-03-21 08:06:38 --> Total execution time: 0.0622
INFO - 2018-03-21 08:06:38 --> Config Class Initialized
INFO - 2018-03-21 08:06:38 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:06:38 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:06:38 --> Utf8 Class Initialized
INFO - 2018-03-21 08:06:38 --> URI Class Initialized
INFO - 2018-03-21 08:06:38 --> Router Class Initialized
INFO - 2018-03-21 08:06:38 --> Output Class Initialized
INFO - 2018-03-21 08:06:38 --> Security Class Initialized
DEBUG - 2018-03-21 08:06:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:06:38 --> Input Class Initialized
INFO - 2018-03-21 08:06:38 --> Language Class Initialized
INFO - 2018-03-21 08:06:38 --> Loader Class Initialized
INFO - 2018-03-21 08:06:38 --> Helper loaded: url_helper
INFO - 2018-03-21 08:06:38 --> Helper loaded: form_helper
INFO - 2018-03-21 08:06:38 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:06:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:06:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:06:38 --> Form Validation Class Initialized
INFO - 2018-03-21 08:06:38 --> Model Class Initialized
INFO - 2018-03-21 08:06:38 --> Controller Class Initialized
INFO - 2018-03-21 08:06:38 --> Model Class Initialized
INFO - 2018-03-21 08:06:38 --> Model Class Initialized
INFO - 2018-03-21 08:06:38 --> Model Class Initialized
INFO - 2018-03-21 08:06:38 --> Model Class Initialized
DEBUG - 2018-03-21 08:06:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:06:42 --> Config Class Initialized
INFO - 2018-03-21 08:06:42 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:06:42 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:06:42 --> Utf8 Class Initialized
INFO - 2018-03-21 08:06:42 --> URI Class Initialized
INFO - 2018-03-21 08:06:42 --> Router Class Initialized
INFO - 2018-03-21 08:06:42 --> Output Class Initialized
INFO - 2018-03-21 08:06:42 --> Security Class Initialized
DEBUG - 2018-03-21 08:06:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:06:42 --> Input Class Initialized
INFO - 2018-03-21 08:06:42 --> Language Class Initialized
INFO - 2018-03-21 08:06:42 --> Loader Class Initialized
INFO - 2018-03-21 08:06:42 --> Helper loaded: url_helper
INFO - 2018-03-21 08:06:42 --> Helper loaded: form_helper
INFO - 2018-03-21 08:06:42 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:06:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:06:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:06:42 --> Form Validation Class Initialized
INFO - 2018-03-21 08:06:42 --> Model Class Initialized
INFO - 2018-03-21 08:06:42 --> Controller Class Initialized
INFO - 2018-03-21 08:06:42 --> Model Class Initialized
INFO - 2018-03-21 08:06:42 --> Model Class Initialized
INFO - 2018-03-21 08:06:42 --> Model Class Initialized
INFO - 2018-03-21 08:06:42 --> Model Class Initialized
DEBUG - 2018-03-21 08:06:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:06:45 --> Config Class Initialized
INFO - 2018-03-21 08:06:45 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:06:45 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:06:45 --> Utf8 Class Initialized
INFO - 2018-03-21 08:06:45 --> URI Class Initialized
INFO - 2018-03-21 08:06:45 --> Router Class Initialized
INFO - 2018-03-21 08:06:45 --> Output Class Initialized
INFO - 2018-03-21 08:06:45 --> Security Class Initialized
DEBUG - 2018-03-21 08:06:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:06:45 --> Input Class Initialized
INFO - 2018-03-21 08:06:45 --> Language Class Initialized
INFO - 2018-03-21 08:06:45 --> Loader Class Initialized
INFO - 2018-03-21 08:06:45 --> Helper loaded: url_helper
INFO - 2018-03-21 08:06:45 --> Helper loaded: form_helper
INFO - 2018-03-21 08:06:45 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:06:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:06:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:06:46 --> Form Validation Class Initialized
INFO - 2018-03-21 08:06:46 --> Model Class Initialized
INFO - 2018-03-21 08:06:46 --> Controller Class Initialized
INFO - 2018-03-21 08:06:46 --> Model Class Initialized
INFO - 2018-03-21 08:06:46 --> Model Class Initialized
INFO - 2018-03-21 08:06:46 --> Model Class Initialized
INFO - 2018-03-21 08:06:46 --> Model Class Initialized
DEBUG - 2018-03-21 08:06:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:06:46 --> Model Class Initialized
INFO - 2018-03-21 08:06:46 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-21 08:06:46 --> Final output sent to browser
DEBUG - 2018-03-21 08:06:46 --> Total execution time: 0.0703
INFO - 2018-03-21 08:06:46 --> Config Class Initialized
INFO - 2018-03-21 08:06:46 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:06:46 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:06:46 --> Utf8 Class Initialized
INFO - 2018-03-21 08:06:46 --> URI Class Initialized
INFO - 2018-03-21 08:06:46 --> Router Class Initialized
INFO - 2018-03-21 08:06:46 --> Output Class Initialized
INFO - 2018-03-21 08:06:46 --> Security Class Initialized
DEBUG - 2018-03-21 08:06:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:06:46 --> Input Class Initialized
INFO - 2018-03-21 08:06:46 --> Language Class Initialized
INFO - 2018-03-21 08:06:46 --> Loader Class Initialized
INFO - 2018-03-21 08:06:46 --> Helper loaded: url_helper
INFO - 2018-03-21 08:06:46 --> Helper loaded: form_helper
INFO - 2018-03-21 08:06:46 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:06:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:06:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:06:46 --> Form Validation Class Initialized
INFO - 2018-03-21 08:06:46 --> Model Class Initialized
INFO - 2018-03-21 08:06:46 --> Controller Class Initialized
INFO - 2018-03-21 08:06:46 --> Model Class Initialized
INFO - 2018-03-21 08:06:46 --> Model Class Initialized
INFO - 2018-03-21 08:06:46 --> Model Class Initialized
INFO - 2018-03-21 08:06:46 --> Model Class Initialized
DEBUG - 2018-03-21 08:06:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:07:02 --> Config Class Initialized
INFO - 2018-03-21 08:07:02 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:07:02 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:07:02 --> Utf8 Class Initialized
INFO - 2018-03-21 08:07:02 --> URI Class Initialized
INFO - 2018-03-21 08:07:02 --> Router Class Initialized
INFO - 2018-03-21 08:07:02 --> Output Class Initialized
INFO - 2018-03-21 08:07:02 --> Security Class Initialized
DEBUG - 2018-03-21 08:07:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:07:02 --> Input Class Initialized
INFO - 2018-03-21 08:07:02 --> Language Class Initialized
INFO - 2018-03-21 08:07:02 --> Loader Class Initialized
INFO - 2018-03-21 08:07:02 --> Helper loaded: url_helper
INFO - 2018-03-21 08:07:02 --> Helper loaded: form_helper
INFO - 2018-03-21 08:07:02 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:07:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:07:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:07:02 --> Form Validation Class Initialized
INFO - 2018-03-21 08:07:02 --> Model Class Initialized
INFO - 2018-03-21 08:07:02 --> Controller Class Initialized
INFO - 2018-03-21 08:07:02 --> Model Class Initialized
INFO - 2018-03-21 08:07:02 --> Model Class Initialized
INFO - 2018-03-21 08:07:02 --> Model Class Initialized
INFO - 2018-03-21 08:07:02 --> Model Class Initialized
DEBUG - 2018-03-21 08:07:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:07:02 --> Model Class Initialized
INFO - 2018-03-21 08:07:02 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-21 08:07:02 --> Final output sent to browser
DEBUG - 2018-03-21 08:07:02 --> Total execution time: 0.0570
INFO - 2018-03-21 08:07:02 --> Config Class Initialized
INFO - 2018-03-21 08:07:02 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:07:02 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:07:02 --> Utf8 Class Initialized
INFO - 2018-03-21 08:07:02 --> URI Class Initialized
INFO - 2018-03-21 08:07:02 --> Router Class Initialized
INFO - 2018-03-21 08:07:02 --> Output Class Initialized
INFO - 2018-03-21 08:07:02 --> Security Class Initialized
DEBUG - 2018-03-21 08:07:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:07:02 --> Input Class Initialized
INFO - 2018-03-21 08:07:02 --> Language Class Initialized
INFO - 2018-03-21 08:07:02 --> Loader Class Initialized
INFO - 2018-03-21 08:07:02 --> Helper loaded: url_helper
INFO - 2018-03-21 08:07:02 --> Helper loaded: form_helper
INFO - 2018-03-21 08:07:02 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:07:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:07:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:07:02 --> Form Validation Class Initialized
INFO - 2018-03-21 08:07:02 --> Model Class Initialized
INFO - 2018-03-21 08:07:02 --> Controller Class Initialized
INFO - 2018-03-21 08:07:02 --> Model Class Initialized
INFO - 2018-03-21 08:07:02 --> Model Class Initialized
INFO - 2018-03-21 08:07:02 --> Model Class Initialized
INFO - 2018-03-21 08:07:02 --> Model Class Initialized
DEBUG - 2018-03-21 08:07:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:07:06 --> Config Class Initialized
INFO - 2018-03-21 08:07:06 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:07:06 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:07:06 --> Utf8 Class Initialized
INFO - 2018-03-21 08:07:06 --> URI Class Initialized
INFO - 2018-03-21 08:07:06 --> Router Class Initialized
INFO - 2018-03-21 08:07:06 --> Output Class Initialized
INFO - 2018-03-21 08:07:06 --> Security Class Initialized
DEBUG - 2018-03-21 08:07:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:07:06 --> Input Class Initialized
INFO - 2018-03-21 08:07:06 --> Language Class Initialized
INFO - 2018-03-21 08:07:06 --> Loader Class Initialized
INFO - 2018-03-21 08:07:06 --> Helper loaded: url_helper
INFO - 2018-03-21 08:07:06 --> Helper loaded: form_helper
INFO - 2018-03-21 08:07:06 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:07:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:07:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:07:06 --> Form Validation Class Initialized
INFO - 2018-03-21 08:07:06 --> Model Class Initialized
INFO - 2018-03-21 08:07:06 --> Controller Class Initialized
INFO - 2018-03-21 08:07:06 --> Model Class Initialized
INFO - 2018-03-21 08:07:06 --> Model Class Initialized
INFO - 2018-03-21 08:07:06 --> Model Class Initialized
INFO - 2018-03-21 08:07:06 --> Model Class Initialized
DEBUG - 2018-03-21 08:07:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:07:08 --> Config Class Initialized
INFO - 2018-03-21 08:07:08 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:07:08 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:07:08 --> Utf8 Class Initialized
INFO - 2018-03-21 08:07:08 --> URI Class Initialized
INFO - 2018-03-21 08:07:08 --> Router Class Initialized
INFO - 2018-03-21 08:07:08 --> Output Class Initialized
INFO - 2018-03-21 08:07:08 --> Security Class Initialized
DEBUG - 2018-03-21 08:07:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:07:08 --> Input Class Initialized
INFO - 2018-03-21 08:07:08 --> Language Class Initialized
INFO - 2018-03-21 08:07:08 --> Loader Class Initialized
INFO - 2018-03-21 08:07:08 --> Helper loaded: url_helper
INFO - 2018-03-21 08:07:08 --> Helper loaded: form_helper
INFO - 2018-03-21 08:07:08 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:07:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:07:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:07:08 --> Form Validation Class Initialized
INFO - 2018-03-21 08:07:08 --> Model Class Initialized
INFO - 2018-03-21 08:07:08 --> Controller Class Initialized
INFO - 2018-03-21 08:07:08 --> Model Class Initialized
INFO - 2018-03-21 08:07:08 --> Model Class Initialized
INFO - 2018-03-21 08:07:08 --> Model Class Initialized
INFO - 2018-03-21 08:07:08 --> Model Class Initialized
DEBUG - 2018-03-21 08:07:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:07:08 --> Model Class Initialized
INFO - 2018-03-21 08:07:08 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-21 08:07:08 --> Final output sent to browser
DEBUG - 2018-03-21 08:07:08 --> Total execution time: 0.0575
INFO - 2018-03-21 08:07:09 --> Config Class Initialized
INFO - 2018-03-21 08:07:09 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:07:09 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:07:09 --> Utf8 Class Initialized
INFO - 2018-03-21 08:07:09 --> URI Class Initialized
INFO - 2018-03-21 08:07:09 --> Router Class Initialized
INFO - 2018-03-21 08:07:09 --> Output Class Initialized
INFO - 2018-03-21 08:07:09 --> Security Class Initialized
DEBUG - 2018-03-21 08:07:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:07:09 --> Input Class Initialized
INFO - 2018-03-21 08:07:09 --> Language Class Initialized
INFO - 2018-03-21 08:07:09 --> Loader Class Initialized
INFO - 2018-03-21 08:07:09 --> Helper loaded: url_helper
INFO - 2018-03-21 08:07:09 --> Helper loaded: form_helper
INFO - 2018-03-21 08:07:09 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:07:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:07:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:07:09 --> Form Validation Class Initialized
INFO - 2018-03-21 08:07:09 --> Model Class Initialized
INFO - 2018-03-21 08:07:09 --> Controller Class Initialized
INFO - 2018-03-21 08:07:09 --> Model Class Initialized
INFO - 2018-03-21 08:07:09 --> Model Class Initialized
INFO - 2018-03-21 08:07:09 --> Model Class Initialized
INFO - 2018-03-21 08:07:09 --> Model Class Initialized
DEBUG - 2018-03-21 08:07:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:07:16 --> Config Class Initialized
INFO - 2018-03-21 08:07:16 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:07:16 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:07:16 --> Utf8 Class Initialized
INFO - 2018-03-21 08:07:16 --> URI Class Initialized
INFO - 2018-03-21 08:07:16 --> Router Class Initialized
INFO - 2018-03-21 08:07:16 --> Output Class Initialized
INFO - 2018-03-21 08:07:16 --> Security Class Initialized
DEBUG - 2018-03-21 08:07:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:07:16 --> Input Class Initialized
INFO - 2018-03-21 08:07:16 --> Language Class Initialized
INFO - 2018-03-21 08:07:17 --> Loader Class Initialized
INFO - 2018-03-21 08:07:17 --> Helper loaded: url_helper
INFO - 2018-03-21 08:07:17 --> Helper loaded: form_helper
INFO - 2018-03-21 08:07:17 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:07:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:07:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:07:17 --> Form Validation Class Initialized
INFO - 2018-03-21 08:07:17 --> Model Class Initialized
INFO - 2018-03-21 08:07:17 --> Controller Class Initialized
INFO - 2018-03-21 08:07:17 --> Model Class Initialized
INFO - 2018-03-21 08:07:17 --> Model Class Initialized
INFO - 2018-03-21 08:07:17 --> Model Class Initialized
INFO - 2018-03-21 08:07:17 --> Model Class Initialized
DEBUG - 2018-03-21 08:07:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:07:25 --> Config Class Initialized
INFO - 2018-03-21 08:07:25 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:07:25 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:07:25 --> Utf8 Class Initialized
INFO - 2018-03-21 08:07:25 --> URI Class Initialized
INFO - 2018-03-21 08:07:25 --> Router Class Initialized
INFO - 2018-03-21 08:07:25 --> Output Class Initialized
INFO - 2018-03-21 08:07:25 --> Security Class Initialized
DEBUG - 2018-03-21 08:07:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:07:25 --> Input Class Initialized
INFO - 2018-03-21 08:07:25 --> Language Class Initialized
INFO - 2018-03-21 08:07:25 --> Loader Class Initialized
INFO - 2018-03-21 08:07:25 --> Helper loaded: url_helper
INFO - 2018-03-21 08:07:25 --> Helper loaded: form_helper
INFO - 2018-03-21 08:07:25 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:07:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:07:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:07:25 --> Form Validation Class Initialized
INFO - 2018-03-21 08:07:25 --> Model Class Initialized
INFO - 2018-03-21 08:07:25 --> Controller Class Initialized
INFO - 2018-03-21 08:07:25 --> Model Class Initialized
INFO - 2018-03-21 08:07:25 --> Model Class Initialized
INFO - 2018-03-21 08:07:25 --> Model Class Initialized
INFO - 2018-03-21 08:07:25 --> Model Class Initialized
DEBUG - 2018-03-21 08:07:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:07:25 --> Model Class Initialized
INFO - 2018-03-21 08:07:25 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-21 08:07:25 --> Final output sent to browser
DEBUG - 2018-03-21 08:07:25 --> Total execution time: 0.0582
INFO - 2018-03-21 08:07:25 --> Config Class Initialized
INFO - 2018-03-21 08:07:25 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:07:25 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:07:25 --> Utf8 Class Initialized
INFO - 2018-03-21 08:07:25 --> URI Class Initialized
INFO - 2018-03-21 08:07:25 --> Router Class Initialized
INFO - 2018-03-21 08:07:25 --> Output Class Initialized
INFO - 2018-03-21 08:07:25 --> Security Class Initialized
DEBUG - 2018-03-21 08:07:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:07:25 --> Input Class Initialized
INFO - 2018-03-21 08:07:25 --> Language Class Initialized
INFO - 2018-03-21 08:07:25 --> Loader Class Initialized
INFO - 2018-03-21 08:07:25 --> Helper loaded: url_helper
INFO - 2018-03-21 08:07:25 --> Helper loaded: form_helper
INFO - 2018-03-21 08:07:25 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:07:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:07:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:07:25 --> Form Validation Class Initialized
INFO - 2018-03-21 08:07:25 --> Model Class Initialized
INFO - 2018-03-21 08:07:25 --> Controller Class Initialized
INFO - 2018-03-21 08:07:25 --> Model Class Initialized
INFO - 2018-03-21 08:07:25 --> Model Class Initialized
INFO - 2018-03-21 08:07:25 --> Model Class Initialized
INFO - 2018-03-21 08:07:25 --> Model Class Initialized
DEBUG - 2018-03-21 08:07:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:07:50 --> Config Class Initialized
INFO - 2018-03-21 08:07:50 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:07:50 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:07:50 --> Utf8 Class Initialized
INFO - 2018-03-21 08:07:50 --> URI Class Initialized
INFO - 2018-03-21 08:07:50 --> Router Class Initialized
INFO - 2018-03-21 08:07:50 --> Output Class Initialized
INFO - 2018-03-21 08:07:50 --> Security Class Initialized
DEBUG - 2018-03-21 08:07:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:07:50 --> Input Class Initialized
INFO - 2018-03-21 08:07:50 --> Language Class Initialized
INFO - 2018-03-21 08:07:50 --> Loader Class Initialized
INFO - 2018-03-21 08:07:50 --> Helper loaded: url_helper
INFO - 2018-03-21 08:07:50 --> Helper loaded: form_helper
INFO - 2018-03-21 08:07:50 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:07:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:07:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:07:50 --> Form Validation Class Initialized
INFO - 2018-03-21 08:07:50 --> Model Class Initialized
INFO - 2018-03-21 08:07:50 --> Controller Class Initialized
INFO - 2018-03-21 08:07:50 --> Model Class Initialized
INFO - 2018-03-21 08:07:50 --> Model Class Initialized
INFO - 2018-03-21 08:07:50 --> Model Class Initialized
INFO - 2018-03-21 08:07:50 --> Model Class Initialized
DEBUG - 2018-03-21 08:07:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:07:50 --> Model Class Initialized
INFO - 2018-03-21 08:07:50 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-21 08:07:50 --> Final output sent to browser
DEBUG - 2018-03-21 08:07:50 --> Total execution time: 0.0554
INFO - 2018-03-21 08:07:50 --> Config Class Initialized
INFO - 2018-03-21 08:07:50 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:07:50 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:07:50 --> Utf8 Class Initialized
INFO - 2018-03-21 08:07:50 --> URI Class Initialized
INFO - 2018-03-21 08:07:50 --> Router Class Initialized
INFO - 2018-03-21 08:07:50 --> Output Class Initialized
INFO - 2018-03-21 08:07:50 --> Security Class Initialized
DEBUG - 2018-03-21 08:07:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:07:50 --> Input Class Initialized
INFO - 2018-03-21 08:07:50 --> Language Class Initialized
INFO - 2018-03-21 08:07:50 --> Loader Class Initialized
INFO - 2018-03-21 08:07:50 --> Helper loaded: url_helper
INFO - 2018-03-21 08:07:50 --> Helper loaded: form_helper
INFO - 2018-03-21 08:07:50 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:07:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:07:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:07:50 --> Form Validation Class Initialized
INFO - 2018-03-21 08:07:50 --> Model Class Initialized
INFO - 2018-03-21 08:07:50 --> Controller Class Initialized
INFO - 2018-03-21 08:07:50 --> Model Class Initialized
INFO - 2018-03-21 08:07:51 --> Model Class Initialized
INFO - 2018-03-21 08:07:51 --> Model Class Initialized
INFO - 2018-03-21 08:07:51 --> Model Class Initialized
DEBUG - 2018-03-21 08:07:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:07:54 --> Config Class Initialized
INFO - 2018-03-21 08:07:54 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:07:54 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:07:54 --> Utf8 Class Initialized
INFO - 2018-03-21 08:07:54 --> URI Class Initialized
INFO - 2018-03-21 08:07:54 --> Router Class Initialized
INFO - 2018-03-21 08:07:54 --> Output Class Initialized
INFO - 2018-03-21 08:07:55 --> Security Class Initialized
DEBUG - 2018-03-21 08:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:07:55 --> Input Class Initialized
INFO - 2018-03-21 08:07:55 --> Language Class Initialized
INFO - 2018-03-21 08:07:55 --> Loader Class Initialized
INFO - 2018-03-21 08:07:55 --> Helper loaded: url_helper
INFO - 2018-03-21 08:07:55 --> Helper loaded: form_helper
INFO - 2018-03-21 08:07:55 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:07:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:07:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:07:55 --> Form Validation Class Initialized
INFO - 2018-03-21 08:07:55 --> Model Class Initialized
INFO - 2018-03-21 08:07:55 --> Controller Class Initialized
INFO - 2018-03-21 08:07:55 --> Model Class Initialized
INFO - 2018-03-21 08:07:55 --> Model Class Initialized
INFO - 2018-03-21 08:07:55 --> Model Class Initialized
INFO - 2018-03-21 08:07:55 --> Model Class Initialized
DEBUG - 2018-03-21 08:07:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:07:58 --> Config Class Initialized
INFO - 2018-03-21 08:07:58 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:07:58 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:07:58 --> Utf8 Class Initialized
INFO - 2018-03-21 08:07:58 --> URI Class Initialized
INFO - 2018-03-21 08:07:58 --> Router Class Initialized
INFO - 2018-03-21 08:07:58 --> Output Class Initialized
INFO - 2018-03-21 08:07:58 --> Security Class Initialized
DEBUG - 2018-03-21 08:07:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:07:58 --> Input Class Initialized
INFO - 2018-03-21 08:07:58 --> Language Class Initialized
INFO - 2018-03-21 08:07:58 --> Loader Class Initialized
INFO - 2018-03-21 08:07:58 --> Helper loaded: url_helper
INFO - 2018-03-21 08:07:58 --> Helper loaded: form_helper
INFO - 2018-03-21 08:07:58 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:07:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:07:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:07:58 --> Form Validation Class Initialized
INFO - 2018-03-21 08:07:58 --> Model Class Initialized
INFO - 2018-03-21 08:07:58 --> Controller Class Initialized
INFO - 2018-03-21 08:07:58 --> Model Class Initialized
INFO - 2018-03-21 08:07:58 --> Model Class Initialized
INFO - 2018-03-21 08:07:58 --> Model Class Initialized
INFO - 2018-03-21 08:07:58 --> Model Class Initialized
DEBUG - 2018-03-21 08:07:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:07:58 --> Model Class Initialized
INFO - 2018-03-21 08:07:58 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-21 08:07:58 --> Final output sent to browser
DEBUG - 2018-03-21 08:07:58 --> Total execution time: 0.0577
INFO - 2018-03-21 08:07:58 --> Config Class Initialized
INFO - 2018-03-21 08:07:58 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:07:58 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:07:58 --> Utf8 Class Initialized
INFO - 2018-03-21 08:07:58 --> URI Class Initialized
INFO - 2018-03-21 08:07:58 --> Router Class Initialized
INFO - 2018-03-21 08:07:58 --> Output Class Initialized
INFO - 2018-03-21 08:07:58 --> Security Class Initialized
DEBUG - 2018-03-21 08:07:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:07:58 --> Input Class Initialized
INFO - 2018-03-21 08:07:58 --> Language Class Initialized
INFO - 2018-03-21 08:07:58 --> Loader Class Initialized
INFO - 2018-03-21 08:07:58 --> Helper loaded: url_helper
INFO - 2018-03-21 08:07:58 --> Helper loaded: form_helper
INFO - 2018-03-21 08:07:58 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:07:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:07:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:07:58 --> Form Validation Class Initialized
INFO - 2018-03-21 08:07:58 --> Model Class Initialized
INFO - 2018-03-21 08:07:58 --> Controller Class Initialized
INFO - 2018-03-21 08:07:58 --> Model Class Initialized
INFO - 2018-03-21 08:07:58 --> Model Class Initialized
INFO - 2018-03-21 08:07:58 --> Model Class Initialized
INFO - 2018-03-21 08:07:58 --> Model Class Initialized
DEBUG - 2018-03-21 08:07:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:08:19 --> Config Class Initialized
INFO - 2018-03-21 08:08:19 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:08:19 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:08:19 --> Utf8 Class Initialized
INFO - 2018-03-21 08:08:19 --> URI Class Initialized
INFO - 2018-03-21 08:08:19 --> Router Class Initialized
INFO - 2018-03-21 08:08:19 --> Output Class Initialized
INFO - 2018-03-21 08:08:19 --> Security Class Initialized
DEBUG - 2018-03-21 08:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:08:19 --> Input Class Initialized
INFO - 2018-03-21 08:08:19 --> Language Class Initialized
INFO - 2018-03-21 08:08:19 --> Loader Class Initialized
INFO - 2018-03-21 08:08:19 --> Helper loaded: url_helper
INFO - 2018-03-21 08:08:19 --> Helper loaded: form_helper
INFO - 2018-03-21 08:08:19 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:08:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:08:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:08:19 --> Form Validation Class Initialized
INFO - 2018-03-21 08:08:19 --> Model Class Initialized
INFO - 2018-03-21 08:08:19 --> Controller Class Initialized
INFO - 2018-03-21 08:08:19 --> Model Class Initialized
INFO - 2018-03-21 08:08:19 --> Model Class Initialized
INFO - 2018-03-21 08:08:19 --> Model Class Initialized
INFO - 2018-03-21 08:08:19 --> Model Class Initialized
DEBUG - 2018-03-21 08:08:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:08:19 --> Model Class Initialized
INFO - 2018-03-21 08:08:19 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-21 08:08:19 --> Final output sent to browser
DEBUG - 2018-03-21 08:08:19 --> Total execution time: 0.0595
INFO - 2018-03-21 08:08:19 --> Config Class Initialized
INFO - 2018-03-21 08:08:19 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:08:19 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:08:19 --> Utf8 Class Initialized
INFO - 2018-03-21 08:08:19 --> URI Class Initialized
INFO - 2018-03-21 08:08:19 --> Router Class Initialized
INFO - 2018-03-21 08:08:19 --> Output Class Initialized
INFO - 2018-03-21 08:08:19 --> Security Class Initialized
DEBUG - 2018-03-21 08:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:08:19 --> Input Class Initialized
INFO - 2018-03-21 08:08:19 --> Language Class Initialized
INFO - 2018-03-21 08:08:19 --> Loader Class Initialized
INFO - 2018-03-21 08:08:19 --> Helper loaded: url_helper
INFO - 2018-03-21 08:08:19 --> Helper loaded: form_helper
INFO - 2018-03-21 08:08:19 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:08:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:08:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:08:19 --> Form Validation Class Initialized
INFO - 2018-03-21 08:08:19 --> Model Class Initialized
INFO - 2018-03-21 08:08:19 --> Controller Class Initialized
INFO - 2018-03-21 08:08:19 --> Model Class Initialized
INFO - 2018-03-21 08:08:19 --> Model Class Initialized
INFO - 2018-03-21 08:08:19 --> Model Class Initialized
INFO - 2018-03-21 08:08:19 --> Model Class Initialized
DEBUG - 2018-03-21 08:08:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:08:20 --> Config Class Initialized
INFO - 2018-03-21 08:08:20 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:08:20 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:08:20 --> Utf8 Class Initialized
INFO - 2018-03-21 08:08:20 --> URI Class Initialized
INFO - 2018-03-21 08:08:20 --> Router Class Initialized
INFO - 2018-03-21 08:08:20 --> Output Class Initialized
INFO - 2018-03-21 08:08:20 --> Security Class Initialized
DEBUG - 2018-03-21 08:08:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:08:20 --> Input Class Initialized
INFO - 2018-03-21 08:08:20 --> Language Class Initialized
INFO - 2018-03-21 08:08:20 --> Loader Class Initialized
INFO - 2018-03-21 08:08:20 --> Helper loaded: url_helper
INFO - 2018-03-21 08:08:20 --> Helper loaded: form_helper
INFO - 2018-03-21 08:08:20 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:08:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:08:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:08:20 --> Form Validation Class Initialized
INFO - 2018-03-21 08:08:20 --> Model Class Initialized
INFO - 2018-03-21 08:08:20 --> Controller Class Initialized
INFO - 2018-03-21 08:08:20 --> Model Class Initialized
INFO - 2018-03-21 08:08:20 --> Model Class Initialized
INFO - 2018-03-21 08:08:20 --> Model Class Initialized
INFO - 2018-03-21 08:08:20 --> Model Class Initialized
DEBUG - 2018-03-21 08:08:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:08:20 --> Model Class Initialized
INFO - 2018-03-21 08:08:20 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-21 08:08:20 --> Final output sent to browser
DEBUG - 2018-03-21 08:08:20 --> Total execution time: 0.0555
INFO - 2018-03-21 08:08:20 --> Config Class Initialized
INFO - 2018-03-21 08:08:20 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:08:20 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:08:20 --> Utf8 Class Initialized
INFO - 2018-03-21 08:08:20 --> URI Class Initialized
INFO - 2018-03-21 08:08:20 --> Router Class Initialized
INFO - 2018-03-21 08:08:20 --> Output Class Initialized
INFO - 2018-03-21 08:08:20 --> Security Class Initialized
DEBUG - 2018-03-21 08:08:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:08:20 --> Input Class Initialized
INFO - 2018-03-21 08:08:20 --> Language Class Initialized
INFO - 2018-03-21 08:08:20 --> Loader Class Initialized
INFO - 2018-03-21 08:08:20 --> Helper loaded: url_helper
INFO - 2018-03-21 08:08:20 --> Helper loaded: form_helper
INFO - 2018-03-21 08:08:20 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:08:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:08:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:08:20 --> Form Validation Class Initialized
INFO - 2018-03-21 08:08:20 --> Model Class Initialized
INFO - 2018-03-21 08:08:20 --> Controller Class Initialized
INFO - 2018-03-21 08:08:20 --> Model Class Initialized
INFO - 2018-03-21 08:08:20 --> Model Class Initialized
INFO - 2018-03-21 08:08:20 --> Model Class Initialized
INFO - 2018-03-21 08:08:20 --> Model Class Initialized
DEBUG - 2018-03-21 08:08:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:08:23 --> Config Class Initialized
INFO - 2018-03-21 08:08:23 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:08:23 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:08:23 --> Utf8 Class Initialized
INFO - 2018-03-21 08:08:23 --> URI Class Initialized
INFO - 2018-03-21 08:08:23 --> Router Class Initialized
INFO - 2018-03-21 08:08:23 --> Output Class Initialized
INFO - 2018-03-21 08:08:23 --> Security Class Initialized
DEBUG - 2018-03-21 08:08:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:08:23 --> Input Class Initialized
INFO - 2018-03-21 08:08:23 --> Language Class Initialized
INFO - 2018-03-21 08:08:23 --> Loader Class Initialized
INFO - 2018-03-21 08:08:23 --> Helper loaded: url_helper
INFO - 2018-03-21 08:08:23 --> Helper loaded: form_helper
INFO - 2018-03-21 08:08:23 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:08:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:08:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:08:23 --> Form Validation Class Initialized
INFO - 2018-03-21 08:08:23 --> Model Class Initialized
INFO - 2018-03-21 08:08:23 --> Controller Class Initialized
INFO - 2018-03-21 08:08:23 --> Model Class Initialized
INFO - 2018-03-21 08:08:23 --> Model Class Initialized
INFO - 2018-03-21 08:08:23 --> Model Class Initialized
INFO - 2018-03-21 08:08:23 --> Model Class Initialized
DEBUG - 2018-03-21 08:08:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:08:24 --> Config Class Initialized
INFO - 2018-03-21 08:08:24 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:08:24 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:08:24 --> Utf8 Class Initialized
INFO - 2018-03-21 08:08:24 --> URI Class Initialized
INFO - 2018-03-21 08:08:24 --> Router Class Initialized
INFO - 2018-03-21 08:08:24 --> Output Class Initialized
INFO - 2018-03-21 08:08:24 --> Security Class Initialized
DEBUG - 2018-03-21 08:08:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:08:24 --> Input Class Initialized
INFO - 2018-03-21 08:08:24 --> Language Class Initialized
INFO - 2018-03-21 08:08:24 --> Loader Class Initialized
INFO - 2018-03-21 08:08:24 --> Helper loaded: url_helper
INFO - 2018-03-21 08:08:24 --> Helper loaded: form_helper
INFO - 2018-03-21 08:08:24 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:08:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:08:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:08:24 --> Form Validation Class Initialized
INFO - 2018-03-21 08:08:24 --> Model Class Initialized
INFO - 2018-03-21 08:08:24 --> Controller Class Initialized
INFO - 2018-03-21 08:08:24 --> Model Class Initialized
INFO - 2018-03-21 08:08:24 --> Model Class Initialized
INFO - 2018-03-21 08:08:24 --> Model Class Initialized
INFO - 2018-03-21 08:08:24 --> Model Class Initialized
DEBUG - 2018-03-21 08:08:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:08:24 --> Model Class Initialized
INFO - 2018-03-21 08:08:24 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-21 08:08:24 --> Final output sent to browser
DEBUG - 2018-03-21 08:08:24 --> Total execution time: 0.0608
INFO - 2018-03-21 08:08:24 --> Config Class Initialized
INFO - 2018-03-21 08:08:24 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:08:24 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:08:24 --> Utf8 Class Initialized
INFO - 2018-03-21 08:08:24 --> URI Class Initialized
INFO - 2018-03-21 08:08:24 --> Router Class Initialized
INFO - 2018-03-21 08:08:24 --> Output Class Initialized
INFO - 2018-03-21 08:08:24 --> Security Class Initialized
DEBUG - 2018-03-21 08:08:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:08:24 --> Input Class Initialized
INFO - 2018-03-21 08:08:24 --> Language Class Initialized
INFO - 2018-03-21 08:08:24 --> Loader Class Initialized
INFO - 2018-03-21 08:08:24 --> Helper loaded: url_helper
INFO - 2018-03-21 08:08:24 --> Helper loaded: form_helper
INFO - 2018-03-21 08:08:24 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:08:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:08:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:08:24 --> Form Validation Class Initialized
INFO - 2018-03-21 08:08:24 --> Model Class Initialized
INFO - 2018-03-21 08:08:24 --> Controller Class Initialized
INFO - 2018-03-21 08:08:24 --> Model Class Initialized
INFO - 2018-03-21 08:08:24 --> Model Class Initialized
INFO - 2018-03-21 08:08:24 --> Model Class Initialized
INFO - 2018-03-21 08:08:24 --> Model Class Initialized
DEBUG - 2018-03-21 08:08:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:09:37 --> Config Class Initialized
INFO - 2018-03-21 08:09:37 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:09:37 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:09:37 --> Utf8 Class Initialized
INFO - 2018-03-21 08:09:37 --> URI Class Initialized
INFO - 2018-03-21 08:09:37 --> Router Class Initialized
INFO - 2018-03-21 08:09:37 --> Output Class Initialized
INFO - 2018-03-21 08:09:37 --> Security Class Initialized
DEBUG - 2018-03-21 08:09:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:09:37 --> Input Class Initialized
INFO - 2018-03-21 08:09:37 --> Language Class Initialized
INFO - 2018-03-21 08:09:37 --> Loader Class Initialized
INFO - 2018-03-21 08:09:37 --> Helper loaded: url_helper
INFO - 2018-03-21 08:09:37 --> Helper loaded: form_helper
INFO - 2018-03-21 08:09:37 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:09:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:09:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:09:37 --> Form Validation Class Initialized
INFO - 2018-03-21 08:09:37 --> Model Class Initialized
INFO - 2018-03-21 08:09:37 --> Controller Class Initialized
INFO - 2018-03-21 08:09:37 --> Model Class Initialized
INFO - 2018-03-21 08:09:37 --> Model Class Initialized
INFO - 2018-03-21 08:09:37 --> Model Class Initialized
INFO - 2018-03-21 08:09:37 --> Model Class Initialized
DEBUG - 2018-03-21 08:09:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:09:37 --> Model Class Initialized
ERROR - 2018-03-21 08:09:37 --> Severity: Notice --> Undefined index: colaborador_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 202
ERROR - 2018-03-21 08:09:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 215
ERROR - 2018-03-21 08:09:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 215
ERROR - 2018-03-21 08:09:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 234
ERROR - 2018-03-21 08:09:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 234
INFO - 2018-03-21 08:09:37 --> Final output sent to browser
DEBUG - 2018-03-21 08:09:37 --> Total execution time: 0.1784
INFO - 2018-03-21 08:11:04 --> Config Class Initialized
INFO - 2018-03-21 08:11:04 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:11:04 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:11:04 --> Utf8 Class Initialized
INFO - 2018-03-21 08:11:04 --> URI Class Initialized
INFO - 2018-03-21 08:11:04 --> Router Class Initialized
INFO - 2018-03-21 08:11:04 --> Output Class Initialized
INFO - 2018-03-21 08:11:04 --> Security Class Initialized
DEBUG - 2018-03-21 08:11:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:11:04 --> Input Class Initialized
INFO - 2018-03-21 08:11:04 --> Language Class Initialized
INFO - 2018-03-21 08:11:04 --> Loader Class Initialized
INFO - 2018-03-21 08:11:04 --> Helper loaded: url_helper
INFO - 2018-03-21 08:11:04 --> Helper loaded: form_helper
INFO - 2018-03-21 08:11:04 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:11:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:11:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:11:04 --> Form Validation Class Initialized
INFO - 2018-03-21 08:11:04 --> Model Class Initialized
INFO - 2018-03-21 08:11:04 --> Controller Class Initialized
INFO - 2018-03-21 08:11:04 --> Model Class Initialized
INFO - 2018-03-21 08:11:04 --> Model Class Initialized
INFO - 2018-03-21 08:11:04 --> Model Class Initialized
INFO - 2018-03-21 08:11:04 --> Model Class Initialized
DEBUG - 2018-03-21 08:11:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:11:04 --> Model Class Initialized
INFO - 2018-03-21 08:11:04 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-21 08:11:04 --> Final output sent to browser
DEBUG - 2018-03-21 08:11:04 --> Total execution time: 0.1305
INFO - 2018-03-21 08:11:05 --> Config Class Initialized
INFO - 2018-03-21 08:11:05 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:11:05 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:11:05 --> Utf8 Class Initialized
INFO - 2018-03-21 08:11:05 --> URI Class Initialized
INFO - 2018-03-21 08:11:05 --> Router Class Initialized
INFO - 2018-03-21 08:11:05 --> Output Class Initialized
INFO - 2018-03-21 08:11:05 --> Security Class Initialized
DEBUG - 2018-03-21 08:11:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:11:05 --> Input Class Initialized
INFO - 2018-03-21 08:11:05 --> Language Class Initialized
INFO - 2018-03-21 08:11:05 --> Loader Class Initialized
INFO - 2018-03-21 08:11:05 --> Helper loaded: url_helper
INFO - 2018-03-21 08:11:05 --> Helper loaded: form_helper
INFO - 2018-03-21 08:11:05 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:11:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:11:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:11:05 --> Form Validation Class Initialized
INFO - 2018-03-21 08:11:05 --> Model Class Initialized
INFO - 2018-03-21 08:11:05 --> Controller Class Initialized
INFO - 2018-03-21 08:11:05 --> Model Class Initialized
INFO - 2018-03-21 08:11:05 --> Model Class Initialized
INFO - 2018-03-21 08:11:05 --> Model Class Initialized
INFO - 2018-03-21 08:11:05 --> Model Class Initialized
DEBUG - 2018-03-21 08:11:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:11:07 --> Config Class Initialized
INFO - 2018-03-21 08:11:07 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:11:07 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:11:07 --> Utf8 Class Initialized
INFO - 2018-03-21 08:11:07 --> URI Class Initialized
INFO - 2018-03-21 08:11:07 --> Router Class Initialized
INFO - 2018-03-21 08:11:07 --> Output Class Initialized
INFO - 2018-03-21 08:11:07 --> Security Class Initialized
DEBUG - 2018-03-21 08:11:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:11:07 --> Input Class Initialized
INFO - 2018-03-21 08:11:07 --> Language Class Initialized
INFO - 2018-03-21 08:11:07 --> Loader Class Initialized
INFO - 2018-03-21 08:11:07 --> Helper loaded: url_helper
INFO - 2018-03-21 08:11:07 --> Helper loaded: form_helper
INFO - 2018-03-21 08:11:07 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:11:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:11:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:11:07 --> Form Validation Class Initialized
INFO - 2018-03-21 08:11:07 --> Model Class Initialized
INFO - 2018-03-21 08:11:07 --> Controller Class Initialized
INFO - 2018-03-21 08:11:07 --> Model Class Initialized
INFO - 2018-03-21 08:11:07 --> Model Class Initialized
INFO - 2018-03-21 08:11:07 --> Model Class Initialized
INFO - 2018-03-21 08:11:07 --> Model Class Initialized
DEBUG - 2018-03-21 08:11:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:11:07 --> Model Class Initialized
INFO - 2018-03-21 08:11:07 --> Final output sent to browser
DEBUG - 2018-03-21 08:11:07 --> Total execution time: 0.1246
INFO - 2018-03-21 08:15:17 --> Config Class Initialized
INFO - 2018-03-21 08:15:17 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:15:17 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:15:17 --> Utf8 Class Initialized
INFO - 2018-03-21 08:15:17 --> URI Class Initialized
INFO - 2018-03-21 08:15:17 --> Router Class Initialized
INFO - 2018-03-21 08:15:17 --> Output Class Initialized
INFO - 2018-03-21 08:15:17 --> Security Class Initialized
DEBUG - 2018-03-21 08:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:15:17 --> Input Class Initialized
INFO - 2018-03-21 08:15:17 --> Language Class Initialized
INFO - 2018-03-21 08:15:17 --> Loader Class Initialized
INFO - 2018-03-21 08:15:17 --> Helper loaded: url_helper
INFO - 2018-03-21 08:15:17 --> Helper loaded: form_helper
INFO - 2018-03-21 08:15:17 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:15:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:15:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:15:17 --> Form Validation Class Initialized
INFO - 2018-03-21 08:15:17 --> Model Class Initialized
INFO - 2018-03-21 08:15:17 --> Controller Class Initialized
INFO - 2018-03-21 08:15:17 --> Model Class Initialized
INFO - 2018-03-21 08:15:17 --> Model Class Initialized
INFO - 2018-03-21 08:15:17 --> Model Class Initialized
INFO - 2018-03-21 08:15:17 --> Model Class Initialized
DEBUG - 2018-03-21 08:15:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:15:17 --> Model Class Initialized
INFO - 2018-03-21 08:15:17 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-21 08:15:17 --> Final output sent to browser
DEBUG - 2018-03-21 08:15:17 --> Total execution time: 0.0624
INFO - 2018-03-21 08:15:17 --> Config Class Initialized
INFO - 2018-03-21 08:15:17 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:15:17 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:15:17 --> Utf8 Class Initialized
INFO - 2018-03-21 08:15:17 --> URI Class Initialized
INFO - 2018-03-21 08:15:17 --> Router Class Initialized
INFO - 2018-03-21 08:15:17 --> Output Class Initialized
INFO - 2018-03-21 08:15:17 --> Security Class Initialized
DEBUG - 2018-03-21 08:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:15:17 --> Input Class Initialized
INFO - 2018-03-21 08:15:17 --> Language Class Initialized
INFO - 2018-03-21 08:15:17 --> Loader Class Initialized
INFO - 2018-03-21 08:15:17 --> Helper loaded: url_helper
INFO - 2018-03-21 08:15:17 --> Helper loaded: form_helper
INFO - 2018-03-21 08:15:17 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:15:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:15:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:15:17 --> Form Validation Class Initialized
INFO - 2018-03-21 08:15:17 --> Model Class Initialized
INFO - 2018-03-21 08:15:17 --> Controller Class Initialized
INFO - 2018-03-21 08:15:17 --> Model Class Initialized
INFO - 2018-03-21 08:15:17 --> Model Class Initialized
INFO - 2018-03-21 08:15:17 --> Model Class Initialized
INFO - 2018-03-21 08:15:17 --> Model Class Initialized
DEBUG - 2018-03-21 08:15:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:15:24 --> Config Class Initialized
INFO - 2018-03-21 08:15:24 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:15:24 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:15:24 --> Utf8 Class Initialized
INFO - 2018-03-21 08:15:24 --> URI Class Initialized
INFO - 2018-03-21 08:15:24 --> Router Class Initialized
INFO - 2018-03-21 08:15:24 --> Output Class Initialized
INFO - 2018-03-21 08:15:24 --> Security Class Initialized
DEBUG - 2018-03-21 08:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:15:24 --> Input Class Initialized
INFO - 2018-03-21 08:15:24 --> Language Class Initialized
INFO - 2018-03-21 08:15:24 --> Loader Class Initialized
INFO - 2018-03-21 08:15:24 --> Helper loaded: url_helper
INFO - 2018-03-21 08:15:24 --> Helper loaded: form_helper
INFO - 2018-03-21 08:15:24 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:15:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:15:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:15:24 --> Form Validation Class Initialized
INFO - 2018-03-21 08:15:24 --> Model Class Initialized
INFO - 2018-03-21 08:15:24 --> Controller Class Initialized
INFO - 2018-03-21 08:15:24 --> Model Class Initialized
INFO - 2018-03-21 08:15:24 --> Model Class Initialized
INFO - 2018-03-21 08:15:24 --> Model Class Initialized
INFO - 2018-03-21 08:15:24 --> Model Class Initialized
DEBUG - 2018-03-21 08:15:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:15:24 --> Model Class Initialized
INFO - 2018-03-21 08:15:24 --> Final output sent to browser
DEBUG - 2018-03-21 08:15:24 --> Total execution time: 0.1796
INFO - 2018-03-21 08:15:40 --> Config Class Initialized
INFO - 2018-03-21 08:15:40 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:15:40 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:15:40 --> Utf8 Class Initialized
INFO - 2018-03-21 08:15:40 --> URI Class Initialized
INFO - 2018-03-21 08:15:40 --> Router Class Initialized
INFO - 2018-03-21 08:15:40 --> Output Class Initialized
INFO - 2018-03-21 08:15:40 --> Security Class Initialized
DEBUG - 2018-03-21 08:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:15:40 --> Input Class Initialized
INFO - 2018-03-21 08:15:40 --> Language Class Initialized
INFO - 2018-03-21 08:15:40 --> Loader Class Initialized
INFO - 2018-03-21 08:15:40 --> Helper loaded: url_helper
INFO - 2018-03-21 08:15:40 --> Helper loaded: form_helper
INFO - 2018-03-21 08:15:40 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:15:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:15:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:15:40 --> Form Validation Class Initialized
INFO - 2018-03-21 08:15:40 --> Model Class Initialized
INFO - 2018-03-21 08:15:40 --> Controller Class Initialized
INFO - 2018-03-21 08:15:40 --> Model Class Initialized
INFO - 2018-03-21 08:15:40 --> Model Class Initialized
INFO - 2018-03-21 08:15:40 --> Model Class Initialized
INFO - 2018-03-21 08:15:40 --> Model Class Initialized
DEBUG - 2018-03-21 08:15:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:15:42 --> Config Class Initialized
INFO - 2018-03-21 08:15:42 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:15:42 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:15:42 --> Utf8 Class Initialized
INFO - 2018-03-21 08:15:42 --> URI Class Initialized
INFO - 2018-03-21 08:15:42 --> Router Class Initialized
INFO - 2018-03-21 08:15:42 --> Output Class Initialized
INFO - 2018-03-21 08:15:42 --> Security Class Initialized
DEBUG - 2018-03-21 08:15:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:15:42 --> Input Class Initialized
INFO - 2018-03-21 08:15:42 --> Language Class Initialized
INFO - 2018-03-21 08:15:42 --> Loader Class Initialized
INFO - 2018-03-21 08:15:42 --> Helper loaded: url_helper
INFO - 2018-03-21 08:15:42 --> Helper loaded: form_helper
INFO - 2018-03-21 08:15:42 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:15:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:15:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:15:42 --> Form Validation Class Initialized
INFO - 2018-03-21 08:15:42 --> Model Class Initialized
INFO - 2018-03-21 08:15:42 --> Controller Class Initialized
INFO - 2018-03-21 08:15:42 --> Model Class Initialized
INFO - 2018-03-21 08:15:42 --> Model Class Initialized
INFO - 2018-03-21 08:15:42 --> Model Class Initialized
INFO - 2018-03-21 08:15:42 --> Model Class Initialized
DEBUG - 2018-03-21 08:15:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:15:42 --> Model Class Initialized
INFO - 2018-03-21 08:15:42 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-21 08:15:42 --> Final output sent to browser
DEBUG - 2018-03-21 08:15:42 --> Total execution time: 0.0565
INFO - 2018-03-21 08:15:42 --> Config Class Initialized
INFO - 2018-03-21 08:15:42 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:15:42 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:15:42 --> Utf8 Class Initialized
INFO - 2018-03-21 08:15:42 --> URI Class Initialized
INFO - 2018-03-21 08:15:42 --> Router Class Initialized
INFO - 2018-03-21 08:15:42 --> Output Class Initialized
INFO - 2018-03-21 08:15:42 --> Security Class Initialized
DEBUG - 2018-03-21 08:15:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:15:42 --> Input Class Initialized
INFO - 2018-03-21 08:15:42 --> Language Class Initialized
INFO - 2018-03-21 08:15:42 --> Loader Class Initialized
INFO - 2018-03-21 08:15:42 --> Helper loaded: url_helper
INFO - 2018-03-21 08:15:42 --> Helper loaded: form_helper
INFO - 2018-03-21 08:15:42 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:15:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:15:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:15:42 --> Form Validation Class Initialized
INFO - 2018-03-21 08:15:42 --> Model Class Initialized
INFO - 2018-03-21 08:15:42 --> Controller Class Initialized
INFO - 2018-03-21 08:15:42 --> Model Class Initialized
INFO - 2018-03-21 08:15:42 --> Model Class Initialized
DEBUG - 2018-03-21 08:15:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:15:49 --> Config Class Initialized
INFO - 2018-03-21 08:15:49 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:15:49 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:15:49 --> Utf8 Class Initialized
INFO - 2018-03-21 08:15:49 --> URI Class Initialized
INFO - 2018-03-21 08:15:49 --> Router Class Initialized
INFO - 2018-03-21 08:15:49 --> Output Class Initialized
INFO - 2018-03-21 08:15:49 --> Security Class Initialized
DEBUG - 2018-03-21 08:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:15:49 --> Input Class Initialized
INFO - 2018-03-21 08:15:49 --> Language Class Initialized
INFO - 2018-03-21 08:15:49 --> Loader Class Initialized
INFO - 2018-03-21 08:15:49 --> Helper loaded: url_helper
INFO - 2018-03-21 08:15:49 --> Helper loaded: form_helper
INFO - 2018-03-21 08:15:49 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:15:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:15:49 --> Form Validation Class Initialized
INFO - 2018-03-21 08:15:49 --> Model Class Initialized
INFO - 2018-03-21 08:15:49 --> Controller Class Initialized
INFO - 2018-03-21 08:15:49 --> Model Class Initialized
INFO - 2018-03-21 08:15:49 --> Model Class Initialized
INFO - 2018-03-21 08:15:49 --> Model Class Initialized
INFO - 2018-03-21 08:15:49 --> Model Class Initialized
DEBUG - 2018-03-21 08:15:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:15:49 --> Model Class Initialized
INFO - 2018-03-21 08:15:49 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-21 08:15:49 --> Final output sent to browser
DEBUG - 2018-03-21 08:15:49 --> Total execution time: 0.0607
INFO - 2018-03-21 08:15:49 --> Config Class Initialized
INFO - 2018-03-21 08:15:49 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:15:49 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:15:49 --> Utf8 Class Initialized
INFO - 2018-03-21 08:15:49 --> URI Class Initialized
INFO - 2018-03-21 08:15:49 --> Router Class Initialized
INFO - 2018-03-21 08:15:49 --> Output Class Initialized
INFO - 2018-03-21 08:15:49 --> Security Class Initialized
DEBUG - 2018-03-21 08:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:15:49 --> Input Class Initialized
INFO - 2018-03-21 08:15:49 --> Language Class Initialized
INFO - 2018-03-21 08:15:49 --> Loader Class Initialized
INFO - 2018-03-21 08:15:49 --> Helper loaded: url_helper
INFO - 2018-03-21 08:15:49 --> Helper loaded: form_helper
INFO - 2018-03-21 08:15:49 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:15:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:15:49 --> Form Validation Class Initialized
INFO - 2018-03-21 08:15:49 --> Model Class Initialized
INFO - 2018-03-21 08:15:49 --> Controller Class Initialized
INFO - 2018-03-21 08:15:49 --> Model Class Initialized
INFO - 2018-03-21 08:15:49 --> Model Class Initialized
INFO - 2018-03-21 08:15:49 --> Model Class Initialized
INFO - 2018-03-21 08:15:49 --> Model Class Initialized
DEBUG - 2018-03-21 08:15:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:15:52 --> Config Class Initialized
INFO - 2018-03-21 08:15:52 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:15:52 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:15:52 --> Utf8 Class Initialized
INFO - 2018-03-21 08:15:52 --> URI Class Initialized
INFO - 2018-03-21 08:15:52 --> Router Class Initialized
INFO - 2018-03-21 08:15:52 --> Output Class Initialized
INFO - 2018-03-21 08:15:52 --> Security Class Initialized
DEBUG - 2018-03-21 08:15:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:15:52 --> Input Class Initialized
INFO - 2018-03-21 08:15:52 --> Language Class Initialized
INFO - 2018-03-21 08:15:52 --> Loader Class Initialized
INFO - 2018-03-21 08:15:52 --> Helper loaded: url_helper
INFO - 2018-03-21 08:15:52 --> Helper loaded: form_helper
INFO - 2018-03-21 08:15:52 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:15:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:15:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:15:52 --> Form Validation Class Initialized
INFO - 2018-03-21 08:15:52 --> Model Class Initialized
INFO - 2018-03-21 08:15:52 --> Controller Class Initialized
INFO - 2018-03-21 08:15:52 --> Model Class Initialized
INFO - 2018-03-21 08:15:52 --> Model Class Initialized
INFO - 2018-03-21 08:15:52 --> Model Class Initialized
INFO - 2018-03-21 08:15:52 --> Model Class Initialized
DEBUG - 2018-03-21 08:15:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:16:10 --> Config Class Initialized
INFO - 2018-03-21 08:16:10 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:16:10 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:16:10 --> Utf8 Class Initialized
INFO - 2018-03-21 08:16:10 --> URI Class Initialized
INFO - 2018-03-21 08:16:10 --> Router Class Initialized
INFO - 2018-03-21 08:16:10 --> Output Class Initialized
INFO - 2018-03-21 08:16:10 --> Security Class Initialized
DEBUG - 2018-03-21 08:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:16:10 --> Input Class Initialized
INFO - 2018-03-21 08:16:10 --> Language Class Initialized
INFO - 2018-03-21 08:16:10 --> Loader Class Initialized
INFO - 2018-03-21 08:16:10 --> Helper loaded: url_helper
INFO - 2018-03-21 08:16:10 --> Helper loaded: form_helper
INFO - 2018-03-21 08:16:10 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:16:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:16:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:16:10 --> Form Validation Class Initialized
INFO - 2018-03-21 08:16:10 --> Model Class Initialized
INFO - 2018-03-21 08:16:10 --> Controller Class Initialized
INFO - 2018-03-21 08:16:10 --> Model Class Initialized
INFO - 2018-03-21 08:16:10 --> Model Class Initialized
INFO - 2018-03-21 08:16:10 --> Model Class Initialized
INFO - 2018-03-21 08:16:10 --> Model Class Initialized
DEBUG - 2018-03-21 08:16:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:16:10 --> Model Class Initialized
INFO - 2018-03-21 08:16:10 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-21 08:16:10 --> Final output sent to browser
DEBUG - 2018-03-21 08:16:10 --> Total execution time: 0.0872
INFO - 2018-03-21 08:16:10 --> Config Class Initialized
INFO - 2018-03-21 08:16:10 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:16:10 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:16:10 --> Utf8 Class Initialized
INFO - 2018-03-21 08:16:10 --> URI Class Initialized
INFO - 2018-03-21 08:16:10 --> Router Class Initialized
INFO - 2018-03-21 08:16:10 --> Output Class Initialized
INFO - 2018-03-21 08:16:10 --> Security Class Initialized
DEBUG - 2018-03-21 08:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:16:10 --> Input Class Initialized
INFO - 2018-03-21 08:16:10 --> Language Class Initialized
INFO - 2018-03-21 08:16:10 --> Loader Class Initialized
INFO - 2018-03-21 08:16:10 --> Helper loaded: url_helper
INFO - 2018-03-21 08:16:10 --> Helper loaded: form_helper
INFO - 2018-03-21 08:16:10 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:16:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:16:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:16:10 --> Form Validation Class Initialized
INFO - 2018-03-21 08:16:10 --> Model Class Initialized
INFO - 2018-03-21 08:16:10 --> Controller Class Initialized
INFO - 2018-03-21 08:16:10 --> Model Class Initialized
INFO - 2018-03-21 08:16:10 --> Model Class Initialized
INFO - 2018-03-21 08:16:10 --> Model Class Initialized
INFO - 2018-03-21 08:16:10 --> Model Class Initialized
DEBUG - 2018-03-21 08:16:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:16:13 --> Config Class Initialized
INFO - 2018-03-21 08:16:13 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:16:13 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:16:13 --> Utf8 Class Initialized
INFO - 2018-03-21 08:16:13 --> URI Class Initialized
INFO - 2018-03-21 08:16:13 --> Router Class Initialized
INFO - 2018-03-21 08:16:13 --> Output Class Initialized
INFO - 2018-03-21 08:16:13 --> Security Class Initialized
DEBUG - 2018-03-21 08:16:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:16:13 --> Input Class Initialized
INFO - 2018-03-21 08:16:13 --> Language Class Initialized
INFO - 2018-03-21 08:16:13 --> Loader Class Initialized
INFO - 2018-03-21 08:16:13 --> Helper loaded: url_helper
INFO - 2018-03-21 08:16:13 --> Helper loaded: form_helper
INFO - 2018-03-21 08:16:13 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:16:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:16:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:16:13 --> Form Validation Class Initialized
INFO - 2018-03-21 08:16:13 --> Model Class Initialized
INFO - 2018-03-21 08:16:13 --> Controller Class Initialized
INFO - 2018-03-21 08:16:13 --> Model Class Initialized
INFO - 2018-03-21 08:16:13 --> Model Class Initialized
INFO - 2018-03-21 08:16:13 --> Model Class Initialized
INFO - 2018-03-21 08:16:13 --> Model Class Initialized
DEBUG - 2018-03-21 08:16:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:16:16 --> Config Class Initialized
INFO - 2018-03-21 08:16:16 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:16:16 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:16:16 --> Utf8 Class Initialized
INFO - 2018-03-21 08:16:16 --> URI Class Initialized
INFO - 2018-03-21 08:16:16 --> Router Class Initialized
INFO - 2018-03-21 08:16:16 --> Output Class Initialized
INFO - 2018-03-21 08:16:16 --> Security Class Initialized
DEBUG - 2018-03-21 08:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:16:16 --> Input Class Initialized
INFO - 2018-03-21 08:16:16 --> Language Class Initialized
INFO - 2018-03-21 08:16:16 --> Loader Class Initialized
INFO - 2018-03-21 08:16:16 --> Helper loaded: url_helper
INFO - 2018-03-21 08:16:16 --> Helper loaded: form_helper
INFO - 2018-03-21 08:16:16 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:16:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:16:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:16:17 --> Form Validation Class Initialized
INFO - 2018-03-21 08:16:17 --> Model Class Initialized
INFO - 2018-03-21 08:16:17 --> Controller Class Initialized
INFO - 2018-03-21 08:16:17 --> Model Class Initialized
INFO - 2018-03-21 08:16:17 --> Model Class Initialized
INFO - 2018-03-21 08:16:17 --> Model Class Initialized
INFO - 2018-03-21 08:16:17 --> Model Class Initialized
DEBUG - 2018-03-21 08:16:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:16:31 --> Config Class Initialized
INFO - 2018-03-21 08:16:31 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:16:31 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:16:31 --> Utf8 Class Initialized
INFO - 2018-03-21 08:16:31 --> URI Class Initialized
INFO - 2018-03-21 08:16:31 --> Router Class Initialized
INFO - 2018-03-21 08:16:31 --> Output Class Initialized
INFO - 2018-03-21 08:16:31 --> Security Class Initialized
DEBUG - 2018-03-21 08:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:16:31 --> Input Class Initialized
INFO - 2018-03-21 08:16:31 --> Language Class Initialized
INFO - 2018-03-21 08:16:31 --> Loader Class Initialized
INFO - 2018-03-21 08:16:31 --> Helper loaded: url_helper
INFO - 2018-03-21 08:16:31 --> Helper loaded: form_helper
INFO - 2018-03-21 08:16:31 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:16:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:16:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:16:31 --> Form Validation Class Initialized
INFO - 2018-03-21 08:16:31 --> Model Class Initialized
INFO - 2018-03-21 08:16:31 --> Controller Class Initialized
INFO - 2018-03-21 08:16:31 --> Model Class Initialized
INFO - 2018-03-21 08:16:31 --> Model Class Initialized
INFO - 2018-03-21 08:16:31 --> Model Class Initialized
INFO - 2018-03-21 08:16:31 --> Model Class Initialized
DEBUG - 2018-03-21 08:16:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:16:31 --> Model Class Initialized
INFO - 2018-03-21 08:16:31 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-21 08:16:31 --> Final output sent to browser
DEBUG - 2018-03-21 08:16:31 --> Total execution time: 0.0888
INFO - 2018-03-21 08:16:31 --> Config Class Initialized
INFO - 2018-03-21 08:16:31 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:16:31 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:16:31 --> Utf8 Class Initialized
INFO - 2018-03-21 08:16:31 --> URI Class Initialized
INFO - 2018-03-21 08:16:31 --> Router Class Initialized
INFO - 2018-03-21 08:16:31 --> Output Class Initialized
INFO - 2018-03-21 08:16:31 --> Security Class Initialized
DEBUG - 2018-03-21 08:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:16:31 --> Input Class Initialized
INFO - 2018-03-21 08:16:31 --> Language Class Initialized
INFO - 2018-03-21 08:16:31 --> Loader Class Initialized
INFO - 2018-03-21 08:16:31 --> Helper loaded: url_helper
INFO - 2018-03-21 08:16:31 --> Helper loaded: form_helper
INFO - 2018-03-21 08:16:31 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:16:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:16:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:16:31 --> Form Validation Class Initialized
INFO - 2018-03-21 08:16:31 --> Model Class Initialized
INFO - 2018-03-21 08:16:31 --> Controller Class Initialized
INFO - 2018-03-21 08:16:31 --> Model Class Initialized
INFO - 2018-03-21 08:16:31 --> Model Class Initialized
INFO - 2018-03-21 08:16:31 --> Model Class Initialized
INFO - 2018-03-21 08:16:31 --> Model Class Initialized
DEBUG - 2018-03-21 08:16:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:16:36 --> Config Class Initialized
INFO - 2018-03-21 08:16:36 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:16:36 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:16:36 --> Utf8 Class Initialized
INFO - 2018-03-21 08:16:36 --> URI Class Initialized
INFO - 2018-03-21 08:16:36 --> Router Class Initialized
INFO - 2018-03-21 08:16:36 --> Output Class Initialized
INFO - 2018-03-21 08:16:36 --> Security Class Initialized
DEBUG - 2018-03-21 08:16:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:16:36 --> Input Class Initialized
INFO - 2018-03-21 08:16:36 --> Language Class Initialized
INFO - 2018-03-21 08:16:36 --> Loader Class Initialized
INFO - 2018-03-21 08:16:36 --> Helper loaded: url_helper
INFO - 2018-03-21 08:16:36 --> Helper loaded: form_helper
INFO - 2018-03-21 08:16:36 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:16:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:16:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:16:36 --> Form Validation Class Initialized
INFO - 2018-03-21 08:16:36 --> Model Class Initialized
INFO - 2018-03-21 08:16:36 --> Controller Class Initialized
INFO - 2018-03-21 08:16:36 --> Model Class Initialized
INFO - 2018-03-21 08:16:36 --> Model Class Initialized
INFO - 2018-03-21 08:16:36 --> Model Class Initialized
INFO - 2018-03-21 08:16:36 --> Model Class Initialized
DEBUG - 2018-03-21 08:16:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:16:48 --> Config Class Initialized
INFO - 2018-03-21 08:16:48 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:16:48 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:16:48 --> Utf8 Class Initialized
INFO - 2018-03-21 08:16:48 --> URI Class Initialized
INFO - 2018-03-21 08:16:48 --> Router Class Initialized
INFO - 2018-03-21 08:16:48 --> Output Class Initialized
INFO - 2018-03-21 08:16:48 --> Security Class Initialized
DEBUG - 2018-03-21 08:16:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:16:48 --> Input Class Initialized
INFO - 2018-03-21 08:16:48 --> Language Class Initialized
INFO - 2018-03-21 08:16:48 --> Loader Class Initialized
INFO - 2018-03-21 08:16:48 --> Helper loaded: url_helper
INFO - 2018-03-21 08:16:48 --> Helper loaded: form_helper
INFO - 2018-03-21 08:16:48 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:16:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:16:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:16:48 --> Form Validation Class Initialized
INFO - 2018-03-21 08:16:48 --> Model Class Initialized
INFO - 2018-03-21 08:16:48 --> Controller Class Initialized
INFO - 2018-03-21 08:16:48 --> Model Class Initialized
INFO - 2018-03-21 08:16:48 --> Model Class Initialized
INFO - 2018-03-21 08:16:48 --> Model Class Initialized
INFO - 2018-03-21 08:16:48 --> Model Class Initialized
DEBUG - 2018-03-21 08:16:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:16:49 --> Config Class Initialized
INFO - 2018-03-21 08:16:49 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:16:49 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:16:49 --> Utf8 Class Initialized
INFO - 2018-03-21 08:16:49 --> URI Class Initialized
INFO - 2018-03-21 08:16:49 --> Router Class Initialized
INFO - 2018-03-21 08:16:49 --> Output Class Initialized
INFO - 2018-03-21 08:16:49 --> Security Class Initialized
DEBUG - 2018-03-21 08:16:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:16:49 --> Input Class Initialized
INFO - 2018-03-21 08:16:49 --> Language Class Initialized
INFO - 2018-03-21 08:16:49 --> Loader Class Initialized
INFO - 2018-03-21 08:16:49 --> Helper loaded: url_helper
INFO - 2018-03-21 08:16:49 --> Helper loaded: form_helper
INFO - 2018-03-21 08:16:50 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:16:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:16:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:16:50 --> Form Validation Class Initialized
INFO - 2018-03-21 08:16:50 --> Model Class Initialized
INFO - 2018-03-21 08:16:50 --> Controller Class Initialized
INFO - 2018-03-21 08:16:50 --> Model Class Initialized
INFO - 2018-03-21 08:16:50 --> Model Class Initialized
INFO - 2018-03-21 08:16:50 --> Model Class Initialized
INFO - 2018-03-21 08:16:50 --> Model Class Initialized
DEBUG - 2018-03-21 08:16:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:16:50 --> Config Class Initialized
INFO - 2018-03-21 08:16:50 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:16:50 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:16:50 --> Utf8 Class Initialized
INFO - 2018-03-21 08:16:50 --> URI Class Initialized
INFO - 2018-03-21 08:16:50 --> Router Class Initialized
INFO - 2018-03-21 08:16:50 --> Output Class Initialized
INFO - 2018-03-21 08:16:50 --> Security Class Initialized
DEBUG - 2018-03-21 08:16:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:16:50 --> Input Class Initialized
INFO - 2018-03-21 08:16:50 --> Language Class Initialized
INFO - 2018-03-21 08:16:50 --> Loader Class Initialized
INFO - 2018-03-21 08:16:50 --> Helper loaded: url_helper
INFO - 2018-03-21 08:16:50 --> Helper loaded: form_helper
INFO - 2018-03-21 08:16:50 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:16:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:16:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:16:50 --> Form Validation Class Initialized
INFO - 2018-03-21 08:16:50 --> Model Class Initialized
INFO - 2018-03-21 08:16:50 --> Controller Class Initialized
INFO - 2018-03-21 08:16:50 --> Model Class Initialized
INFO - 2018-03-21 08:16:50 --> Model Class Initialized
INFO - 2018-03-21 08:16:50 --> Model Class Initialized
INFO - 2018-03-21 08:16:50 --> Model Class Initialized
DEBUG - 2018-03-21 08:16:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:16:52 --> Config Class Initialized
INFO - 2018-03-21 08:16:52 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:16:52 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:16:52 --> Utf8 Class Initialized
INFO - 2018-03-21 08:16:52 --> URI Class Initialized
INFO - 2018-03-21 08:16:52 --> Router Class Initialized
INFO - 2018-03-21 08:16:52 --> Output Class Initialized
INFO - 2018-03-21 08:16:52 --> Security Class Initialized
DEBUG - 2018-03-21 08:16:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:16:52 --> Input Class Initialized
INFO - 2018-03-21 08:16:52 --> Language Class Initialized
INFO - 2018-03-21 08:16:52 --> Loader Class Initialized
INFO - 2018-03-21 08:16:52 --> Helper loaded: url_helper
INFO - 2018-03-21 08:16:52 --> Helper loaded: form_helper
INFO - 2018-03-21 08:16:52 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:16:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:16:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:16:52 --> Form Validation Class Initialized
INFO - 2018-03-21 08:16:52 --> Model Class Initialized
INFO - 2018-03-21 08:16:52 --> Controller Class Initialized
INFO - 2018-03-21 08:16:52 --> Model Class Initialized
INFO - 2018-03-21 08:16:52 --> Model Class Initialized
INFO - 2018-03-21 08:16:52 --> Model Class Initialized
INFO - 2018-03-21 08:16:52 --> Model Class Initialized
DEBUG - 2018-03-21 08:16:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:17:22 --> Config Class Initialized
INFO - 2018-03-21 08:17:22 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:17:22 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:17:22 --> Utf8 Class Initialized
INFO - 2018-03-21 08:17:22 --> URI Class Initialized
INFO - 2018-03-21 08:17:22 --> Router Class Initialized
INFO - 2018-03-21 08:17:22 --> Output Class Initialized
INFO - 2018-03-21 08:17:22 --> Security Class Initialized
DEBUG - 2018-03-21 08:17:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:17:22 --> Input Class Initialized
INFO - 2018-03-21 08:17:22 --> Language Class Initialized
INFO - 2018-03-21 08:17:22 --> Loader Class Initialized
INFO - 2018-03-21 08:17:22 --> Helper loaded: url_helper
INFO - 2018-03-21 08:17:22 --> Helper loaded: form_helper
INFO - 2018-03-21 08:17:22 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:17:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:17:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:17:22 --> Form Validation Class Initialized
INFO - 2018-03-21 08:17:22 --> Model Class Initialized
INFO - 2018-03-21 08:17:22 --> Controller Class Initialized
INFO - 2018-03-21 08:17:22 --> Model Class Initialized
INFO - 2018-03-21 08:17:22 --> Model Class Initialized
INFO - 2018-03-21 08:17:22 --> Model Class Initialized
INFO - 2018-03-21 08:17:22 --> Model Class Initialized
DEBUG - 2018-03-21 08:17:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:17:22 --> Model Class Initialized
INFO - 2018-03-21 08:17:22 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-21 08:17:22 --> Final output sent to browser
DEBUG - 2018-03-21 08:17:22 --> Total execution time: 0.0894
INFO - 2018-03-21 08:17:22 --> Config Class Initialized
INFO - 2018-03-21 08:17:22 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:17:22 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:17:22 --> Utf8 Class Initialized
INFO - 2018-03-21 08:17:22 --> URI Class Initialized
INFO - 2018-03-21 08:17:22 --> Router Class Initialized
INFO - 2018-03-21 08:17:22 --> Output Class Initialized
INFO - 2018-03-21 08:17:22 --> Security Class Initialized
DEBUG - 2018-03-21 08:17:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:17:22 --> Input Class Initialized
INFO - 2018-03-21 08:17:22 --> Language Class Initialized
INFO - 2018-03-21 08:17:22 --> Loader Class Initialized
INFO - 2018-03-21 08:17:22 --> Helper loaded: url_helper
INFO - 2018-03-21 08:17:22 --> Helper loaded: form_helper
INFO - 2018-03-21 08:17:22 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:17:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:17:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:17:22 --> Form Validation Class Initialized
INFO - 2018-03-21 08:17:22 --> Model Class Initialized
INFO - 2018-03-21 08:17:22 --> Controller Class Initialized
INFO - 2018-03-21 08:17:22 --> Model Class Initialized
INFO - 2018-03-21 08:17:22 --> Model Class Initialized
INFO - 2018-03-21 08:17:22 --> Model Class Initialized
INFO - 2018-03-21 08:17:22 --> Model Class Initialized
DEBUG - 2018-03-21 08:17:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:17:32 --> Config Class Initialized
INFO - 2018-03-21 08:17:32 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:17:32 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:17:32 --> Utf8 Class Initialized
INFO - 2018-03-21 08:17:32 --> URI Class Initialized
INFO - 2018-03-21 08:17:32 --> Router Class Initialized
INFO - 2018-03-21 08:17:32 --> Output Class Initialized
INFO - 2018-03-21 08:17:32 --> Security Class Initialized
DEBUG - 2018-03-21 08:17:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:17:32 --> Input Class Initialized
INFO - 2018-03-21 08:17:32 --> Language Class Initialized
INFO - 2018-03-21 08:17:32 --> Loader Class Initialized
INFO - 2018-03-21 08:17:32 --> Helper loaded: url_helper
INFO - 2018-03-21 08:17:32 --> Helper loaded: form_helper
INFO - 2018-03-21 08:17:32 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:17:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:17:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:17:32 --> Form Validation Class Initialized
INFO - 2018-03-21 08:17:32 --> Model Class Initialized
INFO - 2018-03-21 08:17:32 --> Controller Class Initialized
INFO - 2018-03-21 08:17:32 --> Model Class Initialized
INFO - 2018-03-21 08:17:32 --> Model Class Initialized
INFO - 2018-03-21 08:17:32 --> Model Class Initialized
INFO - 2018-03-21 08:17:32 --> Model Class Initialized
DEBUG - 2018-03-21 08:17:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:17:32 --> Model Class Initialized
INFO - 2018-03-21 08:17:32 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-21 08:17:32 --> Final output sent to browser
DEBUG - 2018-03-21 08:17:32 --> Total execution time: 0.1403
INFO - 2018-03-21 08:17:32 --> Config Class Initialized
INFO - 2018-03-21 08:17:32 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:17:32 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:17:32 --> Utf8 Class Initialized
INFO - 2018-03-21 08:17:32 --> URI Class Initialized
INFO - 2018-03-21 08:17:32 --> Router Class Initialized
INFO - 2018-03-21 08:17:32 --> Output Class Initialized
INFO - 2018-03-21 08:17:32 --> Security Class Initialized
DEBUG - 2018-03-21 08:17:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:17:32 --> Input Class Initialized
INFO - 2018-03-21 08:17:32 --> Language Class Initialized
INFO - 2018-03-21 08:17:32 --> Loader Class Initialized
INFO - 2018-03-21 08:17:32 --> Helper loaded: url_helper
INFO - 2018-03-21 08:17:32 --> Helper loaded: form_helper
INFO - 2018-03-21 08:17:32 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:17:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:17:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:17:32 --> Form Validation Class Initialized
INFO - 2018-03-21 08:17:32 --> Model Class Initialized
INFO - 2018-03-21 08:17:32 --> Controller Class Initialized
INFO - 2018-03-21 08:17:32 --> Model Class Initialized
INFO - 2018-03-21 08:17:32 --> Model Class Initialized
INFO - 2018-03-21 08:17:32 --> Model Class Initialized
INFO - 2018-03-21 08:17:32 --> Model Class Initialized
DEBUG - 2018-03-21 08:17:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:17:35 --> Config Class Initialized
INFO - 2018-03-21 08:17:35 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:17:35 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:17:35 --> Utf8 Class Initialized
INFO - 2018-03-21 08:17:35 --> URI Class Initialized
INFO - 2018-03-21 08:17:35 --> Router Class Initialized
INFO - 2018-03-21 08:17:35 --> Output Class Initialized
INFO - 2018-03-21 08:17:35 --> Security Class Initialized
DEBUG - 2018-03-21 08:17:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:17:35 --> Input Class Initialized
INFO - 2018-03-21 08:17:35 --> Language Class Initialized
INFO - 2018-03-21 08:17:35 --> Loader Class Initialized
INFO - 2018-03-21 08:17:35 --> Helper loaded: url_helper
INFO - 2018-03-21 08:17:35 --> Helper loaded: form_helper
INFO - 2018-03-21 08:17:35 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:17:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:17:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:17:35 --> Form Validation Class Initialized
INFO - 2018-03-21 08:17:35 --> Model Class Initialized
INFO - 2018-03-21 08:17:35 --> Controller Class Initialized
INFO - 2018-03-21 08:17:35 --> Model Class Initialized
INFO - 2018-03-21 08:17:35 --> Model Class Initialized
INFO - 2018-03-21 08:17:35 --> Model Class Initialized
INFO - 2018-03-21 08:17:35 --> Model Class Initialized
DEBUG - 2018-03-21 08:17:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:17:38 --> Config Class Initialized
INFO - 2018-03-21 08:17:38 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:17:38 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:17:38 --> Utf8 Class Initialized
INFO - 2018-03-21 08:17:38 --> URI Class Initialized
INFO - 2018-03-21 08:17:38 --> Router Class Initialized
INFO - 2018-03-21 08:17:38 --> Output Class Initialized
INFO - 2018-03-21 08:17:38 --> Security Class Initialized
DEBUG - 2018-03-21 08:17:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:17:38 --> Input Class Initialized
INFO - 2018-03-21 08:17:38 --> Language Class Initialized
INFO - 2018-03-21 08:17:38 --> Loader Class Initialized
INFO - 2018-03-21 08:17:38 --> Helper loaded: url_helper
INFO - 2018-03-21 08:17:38 --> Helper loaded: form_helper
INFO - 2018-03-21 08:17:38 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:17:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:17:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:17:38 --> Form Validation Class Initialized
INFO - 2018-03-21 08:17:38 --> Model Class Initialized
INFO - 2018-03-21 08:17:38 --> Controller Class Initialized
INFO - 2018-03-21 08:17:38 --> Model Class Initialized
INFO - 2018-03-21 08:17:38 --> Model Class Initialized
INFO - 2018-03-21 08:17:38 --> Model Class Initialized
INFO - 2018-03-21 08:17:38 --> Model Class Initialized
DEBUG - 2018-03-21 08:17:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:17:40 --> Config Class Initialized
INFO - 2018-03-21 08:17:40 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:17:40 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:17:40 --> Utf8 Class Initialized
INFO - 2018-03-21 08:17:40 --> URI Class Initialized
INFO - 2018-03-21 08:17:40 --> Router Class Initialized
INFO - 2018-03-21 08:17:40 --> Output Class Initialized
INFO - 2018-03-21 08:17:40 --> Security Class Initialized
DEBUG - 2018-03-21 08:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:17:40 --> Input Class Initialized
INFO - 2018-03-21 08:17:40 --> Language Class Initialized
INFO - 2018-03-21 08:17:40 --> Loader Class Initialized
INFO - 2018-03-21 08:17:40 --> Helper loaded: url_helper
INFO - 2018-03-21 08:17:40 --> Helper loaded: form_helper
INFO - 2018-03-21 08:17:40 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:17:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:17:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:17:40 --> Form Validation Class Initialized
INFO - 2018-03-21 08:17:40 --> Model Class Initialized
INFO - 2018-03-21 08:17:40 --> Controller Class Initialized
INFO - 2018-03-21 08:17:40 --> Model Class Initialized
INFO - 2018-03-21 08:17:40 --> Model Class Initialized
INFO - 2018-03-21 08:17:40 --> Model Class Initialized
INFO - 2018-03-21 08:17:40 --> Model Class Initialized
DEBUG - 2018-03-21 08:17:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:17:41 --> Config Class Initialized
INFO - 2018-03-21 08:17:41 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:17:41 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:17:41 --> Utf8 Class Initialized
INFO - 2018-03-21 08:17:41 --> URI Class Initialized
INFO - 2018-03-21 08:17:41 --> Router Class Initialized
INFO - 2018-03-21 08:17:41 --> Output Class Initialized
INFO - 2018-03-21 08:17:41 --> Security Class Initialized
DEBUG - 2018-03-21 08:17:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:17:41 --> Input Class Initialized
INFO - 2018-03-21 08:17:41 --> Language Class Initialized
INFO - 2018-03-21 08:17:41 --> Loader Class Initialized
INFO - 2018-03-21 08:17:41 --> Helper loaded: url_helper
INFO - 2018-03-21 08:17:41 --> Helper loaded: form_helper
INFO - 2018-03-21 08:17:41 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:17:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:17:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:17:41 --> Form Validation Class Initialized
INFO - 2018-03-21 08:17:41 --> Model Class Initialized
INFO - 2018-03-21 08:17:41 --> Controller Class Initialized
INFO - 2018-03-21 08:17:41 --> Model Class Initialized
INFO - 2018-03-21 08:17:41 --> Model Class Initialized
INFO - 2018-03-21 08:17:41 --> Model Class Initialized
INFO - 2018-03-21 08:17:41 --> Model Class Initialized
DEBUG - 2018-03-21 08:17:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:17:41 --> Config Class Initialized
INFO - 2018-03-21 08:17:41 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:17:41 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:17:41 --> Utf8 Class Initialized
INFO - 2018-03-21 08:17:41 --> URI Class Initialized
INFO - 2018-03-21 08:17:41 --> Router Class Initialized
INFO - 2018-03-21 08:17:41 --> Output Class Initialized
INFO - 2018-03-21 08:17:41 --> Security Class Initialized
DEBUG - 2018-03-21 08:17:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:17:41 --> Input Class Initialized
INFO - 2018-03-21 08:17:41 --> Language Class Initialized
INFO - 2018-03-21 08:17:41 --> Loader Class Initialized
INFO - 2018-03-21 08:17:41 --> Helper loaded: url_helper
INFO - 2018-03-21 08:17:41 --> Helper loaded: form_helper
INFO - 2018-03-21 08:17:41 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:17:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:17:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:17:41 --> Form Validation Class Initialized
INFO - 2018-03-21 08:17:41 --> Model Class Initialized
INFO - 2018-03-21 08:17:41 --> Controller Class Initialized
INFO - 2018-03-21 08:17:41 --> Model Class Initialized
INFO - 2018-03-21 08:17:41 --> Model Class Initialized
INFO - 2018-03-21 08:17:41 --> Model Class Initialized
INFO - 2018-03-21 08:17:41 --> Model Class Initialized
DEBUG - 2018-03-21 08:17:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:17:42 --> Config Class Initialized
INFO - 2018-03-21 08:17:42 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:17:42 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:17:42 --> Utf8 Class Initialized
INFO - 2018-03-21 08:17:42 --> URI Class Initialized
INFO - 2018-03-21 08:17:42 --> Router Class Initialized
INFO - 2018-03-21 08:17:42 --> Output Class Initialized
INFO - 2018-03-21 08:17:42 --> Security Class Initialized
DEBUG - 2018-03-21 08:17:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:17:42 --> Input Class Initialized
INFO - 2018-03-21 08:17:42 --> Language Class Initialized
INFO - 2018-03-21 08:17:42 --> Loader Class Initialized
INFO - 2018-03-21 08:17:42 --> Helper loaded: url_helper
INFO - 2018-03-21 08:17:42 --> Helper loaded: form_helper
INFO - 2018-03-21 08:17:42 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:17:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:17:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:17:42 --> Form Validation Class Initialized
INFO - 2018-03-21 08:17:42 --> Model Class Initialized
INFO - 2018-03-21 08:17:42 --> Controller Class Initialized
INFO - 2018-03-21 08:17:42 --> Model Class Initialized
INFO - 2018-03-21 08:17:42 --> Model Class Initialized
INFO - 2018-03-21 08:17:42 --> Model Class Initialized
INFO - 2018-03-21 08:17:42 --> Model Class Initialized
DEBUG - 2018-03-21 08:17:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:17:43 --> Config Class Initialized
INFO - 2018-03-21 08:17:43 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:17:43 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:17:43 --> Utf8 Class Initialized
INFO - 2018-03-21 08:17:43 --> URI Class Initialized
INFO - 2018-03-21 08:17:43 --> Router Class Initialized
INFO - 2018-03-21 08:17:43 --> Output Class Initialized
INFO - 2018-03-21 08:17:43 --> Security Class Initialized
DEBUG - 2018-03-21 08:17:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:17:43 --> Input Class Initialized
INFO - 2018-03-21 08:17:43 --> Language Class Initialized
INFO - 2018-03-21 08:17:43 --> Loader Class Initialized
INFO - 2018-03-21 08:17:43 --> Helper loaded: url_helper
INFO - 2018-03-21 08:17:43 --> Helper loaded: form_helper
INFO - 2018-03-21 08:17:43 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:17:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:17:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:17:43 --> Form Validation Class Initialized
INFO - 2018-03-21 08:17:43 --> Model Class Initialized
INFO - 2018-03-21 08:17:43 --> Controller Class Initialized
INFO - 2018-03-21 08:17:43 --> Model Class Initialized
INFO - 2018-03-21 08:17:43 --> Model Class Initialized
INFO - 2018-03-21 08:17:43 --> Model Class Initialized
INFO - 2018-03-21 08:17:43 --> Model Class Initialized
DEBUG - 2018-03-21 08:17:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:17:44 --> Config Class Initialized
INFO - 2018-03-21 08:17:44 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:17:44 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:17:44 --> Utf8 Class Initialized
INFO - 2018-03-21 08:17:44 --> URI Class Initialized
INFO - 2018-03-21 08:17:44 --> Router Class Initialized
INFO - 2018-03-21 08:17:44 --> Output Class Initialized
INFO - 2018-03-21 08:17:44 --> Security Class Initialized
DEBUG - 2018-03-21 08:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:17:44 --> Input Class Initialized
INFO - 2018-03-21 08:17:44 --> Language Class Initialized
INFO - 2018-03-21 08:17:44 --> Loader Class Initialized
INFO - 2018-03-21 08:17:44 --> Helper loaded: url_helper
INFO - 2018-03-21 08:17:44 --> Helper loaded: form_helper
INFO - 2018-03-21 08:17:44 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:17:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:17:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:17:44 --> Form Validation Class Initialized
INFO - 2018-03-21 08:17:44 --> Model Class Initialized
INFO - 2018-03-21 08:17:44 --> Controller Class Initialized
INFO - 2018-03-21 08:17:44 --> Model Class Initialized
INFO - 2018-03-21 08:17:44 --> Model Class Initialized
INFO - 2018-03-21 08:17:44 --> Model Class Initialized
INFO - 2018-03-21 08:17:44 --> Model Class Initialized
DEBUG - 2018-03-21 08:17:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:18:09 --> Config Class Initialized
INFO - 2018-03-21 08:18:09 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:18:09 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:18:09 --> Utf8 Class Initialized
INFO - 2018-03-21 08:18:09 --> URI Class Initialized
INFO - 2018-03-21 08:18:09 --> Router Class Initialized
INFO - 2018-03-21 08:18:09 --> Output Class Initialized
INFO - 2018-03-21 08:18:09 --> Security Class Initialized
DEBUG - 2018-03-21 08:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:18:09 --> Input Class Initialized
INFO - 2018-03-21 08:18:09 --> Language Class Initialized
INFO - 2018-03-21 08:18:09 --> Loader Class Initialized
INFO - 2018-03-21 08:18:09 --> Helper loaded: url_helper
INFO - 2018-03-21 08:18:09 --> Helper loaded: form_helper
INFO - 2018-03-21 08:18:09 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:18:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:18:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:18:09 --> Form Validation Class Initialized
INFO - 2018-03-21 08:18:09 --> Model Class Initialized
INFO - 2018-03-21 08:18:09 --> Controller Class Initialized
INFO - 2018-03-21 08:18:09 --> Model Class Initialized
INFO - 2018-03-21 08:18:09 --> Model Class Initialized
INFO - 2018-03-21 08:18:09 --> Model Class Initialized
INFO - 2018-03-21 08:18:09 --> Model Class Initialized
DEBUG - 2018-03-21 08:18:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:18:09 --> Model Class Initialized
INFO - 2018-03-21 08:18:09 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-21 08:18:09 --> Final output sent to browser
DEBUG - 2018-03-21 08:18:09 --> Total execution time: 0.0939
INFO - 2018-03-21 08:18:09 --> Config Class Initialized
INFO - 2018-03-21 08:18:09 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:18:09 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:18:09 --> Utf8 Class Initialized
INFO - 2018-03-21 08:18:09 --> URI Class Initialized
INFO - 2018-03-21 08:18:09 --> Router Class Initialized
INFO - 2018-03-21 08:18:09 --> Output Class Initialized
INFO - 2018-03-21 08:18:09 --> Security Class Initialized
DEBUG - 2018-03-21 08:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:18:09 --> Input Class Initialized
INFO - 2018-03-21 08:18:09 --> Language Class Initialized
INFO - 2018-03-21 08:18:09 --> Loader Class Initialized
INFO - 2018-03-21 08:18:09 --> Helper loaded: url_helper
INFO - 2018-03-21 08:18:09 --> Helper loaded: form_helper
INFO - 2018-03-21 08:18:09 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:18:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:18:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:18:09 --> Form Validation Class Initialized
INFO - 2018-03-21 08:18:09 --> Model Class Initialized
INFO - 2018-03-21 08:18:09 --> Controller Class Initialized
INFO - 2018-03-21 08:18:09 --> Model Class Initialized
INFO - 2018-03-21 08:18:09 --> Model Class Initialized
INFO - 2018-03-21 08:18:09 --> Model Class Initialized
INFO - 2018-03-21 08:18:09 --> Model Class Initialized
DEBUG - 2018-03-21 08:18:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:18:12 --> Config Class Initialized
INFO - 2018-03-21 08:18:12 --> Hooks Class Initialized
INFO - 2018-03-21 08:18:12 --> Config Class Initialized
INFO - 2018-03-21 08:18:12 --> Hooks Class Initialized
INFO - 2018-03-21 08:18:12 --> Config Class Initialized
INFO - 2018-03-21 08:18:12 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:18:12 --> UTF-8 Support Enabled
DEBUG - 2018-03-21 08:18:12 --> UTF-8 Support Enabled
DEBUG - 2018-03-21 08:18:12 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:18:12 --> Utf8 Class Initialized
INFO - 2018-03-21 08:18:12 --> Utf8 Class Initialized
INFO - 2018-03-21 08:18:12 --> Utf8 Class Initialized
INFO - 2018-03-21 08:18:12 --> URI Class Initialized
INFO - 2018-03-21 08:18:12 --> URI Class Initialized
INFO - 2018-03-21 08:18:12 --> URI Class Initialized
INFO - 2018-03-21 08:18:12 --> Router Class Initialized
INFO - 2018-03-21 08:18:12 --> Router Class Initialized
INFO - 2018-03-21 08:18:12 --> Router Class Initialized
INFO - 2018-03-21 08:18:12 --> Config Class Initialized
INFO - 2018-03-21 08:18:12 --> Hooks Class Initialized
INFO - 2018-03-21 08:18:12 --> Output Class Initialized
INFO - 2018-03-21 08:18:12 --> Output Class Initialized
INFO - 2018-03-21 08:18:12 --> Output Class Initialized
INFO - 2018-03-21 08:18:12 --> Security Class Initialized
DEBUG - 2018-03-21 08:18:12 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:18:12 --> Utf8 Class Initialized
INFO - 2018-03-21 08:18:12 --> Security Class Initialized
INFO - 2018-03-21 08:18:12 --> Security Class Initialized
DEBUG - 2018-03-21 08:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:18:12 --> Input Class Initialized
INFO - 2018-03-21 08:18:12 --> URI Class Initialized
DEBUG - 2018-03-21 08:18:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-21 08:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:18:12 --> Language Class Initialized
INFO - 2018-03-21 08:18:12 --> Input Class Initialized
INFO - 2018-03-21 08:18:12 --> Input Class Initialized
INFO - 2018-03-21 08:18:12 --> Router Class Initialized
INFO - 2018-03-21 08:18:12 --> Language Class Initialized
INFO - 2018-03-21 08:18:12 --> Language Class Initialized
ERROR - 2018-03-21 08:18:12 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-21 08:18:12 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-21 08:18:12 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-21 08:18:12 --> Output Class Initialized
INFO - 2018-03-21 08:18:12 --> Security Class Initialized
DEBUG - 2018-03-21 08:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:18:12 --> Input Class Initialized
INFO - 2018-03-21 08:18:12 --> Language Class Initialized
INFO - 2018-03-21 08:18:12 --> Config Class Initialized
INFO - 2018-03-21 08:18:12 --> Hooks Class Initialized
ERROR - 2018-03-21 08:18:12 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-21 08:18:12 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:18:12 --> Utf8 Class Initialized
INFO - 2018-03-21 08:18:12 --> Config Class Initialized
INFO - 2018-03-21 08:18:12 --> Hooks Class Initialized
INFO - 2018-03-21 08:18:12 --> Config Class Initialized
INFO - 2018-03-21 08:18:12 --> URI Class Initialized
INFO - 2018-03-21 08:18:12 --> Hooks Class Initialized
INFO - 2018-03-21 08:18:12 --> Router Class Initialized
DEBUG - 2018-03-21 08:18:12 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:18:12 --> Utf8 Class Initialized
DEBUG - 2018-03-21 08:18:12 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:18:12 --> Utf8 Class Initialized
INFO - 2018-03-21 08:18:12 --> Output Class Initialized
INFO - 2018-03-21 08:18:12 --> URI Class Initialized
INFO - 2018-03-21 08:18:12 --> URI Class Initialized
INFO - 2018-03-21 08:18:12 --> Security Class Initialized
INFO - 2018-03-21 08:18:12 --> Router Class Initialized
INFO - 2018-03-21 08:18:12 --> Router Class Initialized
DEBUG - 2018-03-21 08:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:18:12 --> Input Class Initialized
INFO - 2018-03-21 08:18:12 --> Language Class Initialized
INFO - 2018-03-21 08:18:12 --> Output Class Initialized
INFO - 2018-03-21 08:18:12 --> Output Class Initialized
ERROR - 2018-03-21 08:18:12 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-21 08:18:12 --> Security Class Initialized
INFO - 2018-03-21 08:18:12 --> Security Class Initialized
DEBUG - 2018-03-21 08:18:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-21 08:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:18:12 --> Input Class Initialized
INFO - 2018-03-21 08:18:12 --> Input Class Initialized
INFO - 2018-03-21 08:18:12 --> Language Class Initialized
INFO - 2018-03-21 08:18:12 --> Language Class Initialized
ERROR - 2018-03-21 08:18:12 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-21 08:18:12 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-21 08:18:18 --> Config Class Initialized
INFO - 2018-03-21 08:18:18 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:18:18 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:18:18 --> Utf8 Class Initialized
INFO - 2018-03-21 08:18:18 --> URI Class Initialized
INFO - 2018-03-21 08:18:18 --> Router Class Initialized
INFO - 2018-03-21 08:18:18 --> Output Class Initialized
INFO - 2018-03-21 08:18:18 --> Security Class Initialized
DEBUG - 2018-03-21 08:18:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:18:18 --> Input Class Initialized
INFO - 2018-03-21 08:18:18 --> Language Class Initialized
INFO - 2018-03-21 08:18:18 --> Loader Class Initialized
INFO - 2018-03-21 08:18:18 --> Helper loaded: url_helper
INFO - 2018-03-21 08:18:18 --> Helper loaded: form_helper
INFO - 2018-03-21 08:18:18 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:18:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:18:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:18:18 --> Form Validation Class Initialized
INFO - 2018-03-21 08:18:18 --> Model Class Initialized
INFO - 2018-03-21 08:18:18 --> Controller Class Initialized
INFO - 2018-03-21 08:18:18 --> Model Class Initialized
INFO - 2018-03-21 08:18:18 --> Model Class Initialized
INFO - 2018-03-21 08:18:18 --> Model Class Initialized
INFO - 2018-03-21 08:18:18 --> Model Class Initialized
DEBUG - 2018-03-21 08:18:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:18:23 --> Config Class Initialized
INFO - 2018-03-21 08:18:23 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:18:23 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:18:23 --> Utf8 Class Initialized
INFO - 2018-03-21 08:18:23 --> URI Class Initialized
INFO - 2018-03-21 08:18:23 --> Router Class Initialized
INFO - 2018-03-21 08:18:23 --> Output Class Initialized
INFO - 2018-03-21 08:18:23 --> Security Class Initialized
DEBUG - 2018-03-21 08:18:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:18:23 --> Input Class Initialized
INFO - 2018-03-21 08:18:23 --> Language Class Initialized
INFO - 2018-03-21 08:18:23 --> Loader Class Initialized
INFO - 2018-03-21 08:18:23 --> Helper loaded: url_helper
INFO - 2018-03-21 08:18:23 --> Helper loaded: form_helper
INFO - 2018-03-21 08:18:23 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:18:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:18:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:18:23 --> Form Validation Class Initialized
INFO - 2018-03-21 08:18:23 --> Model Class Initialized
INFO - 2018-03-21 08:18:23 --> Controller Class Initialized
INFO - 2018-03-21 08:18:23 --> Model Class Initialized
INFO - 2018-03-21 08:18:23 --> Model Class Initialized
INFO - 2018-03-21 08:18:23 --> Model Class Initialized
INFO - 2018-03-21 08:18:23 --> Model Class Initialized
DEBUG - 2018-03-21 08:18:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:18:25 --> Config Class Initialized
INFO - 2018-03-21 08:18:25 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:18:25 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:18:25 --> Utf8 Class Initialized
INFO - 2018-03-21 08:18:25 --> URI Class Initialized
INFO - 2018-03-21 08:18:25 --> Router Class Initialized
INFO - 2018-03-21 08:18:25 --> Output Class Initialized
INFO - 2018-03-21 08:18:25 --> Security Class Initialized
DEBUG - 2018-03-21 08:18:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:18:25 --> Input Class Initialized
INFO - 2018-03-21 08:18:25 --> Language Class Initialized
INFO - 2018-03-21 08:18:25 --> Loader Class Initialized
INFO - 2018-03-21 08:18:25 --> Helper loaded: url_helper
INFO - 2018-03-21 08:18:25 --> Helper loaded: form_helper
INFO - 2018-03-21 08:18:25 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:18:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:18:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:18:25 --> Form Validation Class Initialized
INFO - 2018-03-21 08:18:25 --> Model Class Initialized
INFO - 2018-03-21 08:18:25 --> Controller Class Initialized
INFO - 2018-03-21 08:18:25 --> Model Class Initialized
INFO - 2018-03-21 08:18:25 --> Model Class Initialized
INFO - 2018-03-21 08:18:25 --> Model Class Initialized
INFO - 2018-03-21 08:18:25 --> Model Class Initialized
DEBUG - 2018-03-21 08:18:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:18:25 --> Model Class Initialized
INFO - 2018-03-21 08:18:26 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-21 08:18:26 --> Final output sent to browser
DEBUG - 2018-03-21 08:18:26 --> Total execution time: 0.1065
INFO - 2018-03-21 08:18:26 --> Config Class Initialized
INFO - 2018-03-21 08:18:26 --> Hooks Class Initialized
INFO - 2018-03-21 08:18:26 --> Config Class Initialized
INFO - 2018-03-21 08:18:26 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:18:26 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:18:26 --> Utf8 Class Initialized
DEBUG - 2018-03-21 08:18:26 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:18:26 --> Utf8 Class Initialized
INFO - 2018-03-21 08:18:26 --> URI Class Initialized
INFO - 2018-03-21 08:18:26 --> URI Class Initialized
INFO - 2018-03-21 08:18:26 --> Router Class Initialized
INFO - 2018-03-21 08:18:26 --> Router Class Initialized
INFO - 2018-03-21 08:18:26 --> Output Class Initialized
INFO - 2018-03-21 08:18:26 --> Output Class Initialized
INFO - 2018-03-21 08:18:26 --> Security Class Initialized
INFO - 2018-03-21 08:18:26 --> Security Class Initialized
DEBUG - 2018-03-21 08:18:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:18:26 --> Input Class Initialized
INFO - 2018-03-21 08:18:26 --> Language Class Initialized
DEBUG - 2018-03-21 08:18:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:18:26 --> Input Class Initialized
ERROR - 2018-03-21 08:18:26 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-21 08:18:26 --> Language Class Initialized
ERROR - 2018-03-21 08:18:26 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-21 08:18:26 --> Config Class Initialized
INFO - 2018-03-21 08:18:26 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:18:26 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:18:26 --> Config Class Initialized
INFO - 2018-03-21 08:18:26 --> Utf8 Class Initialized
INFO - 2018-03-21 08:18:26 --> Hooks Class Initialized
INFO - 2018-03-21 08:18:26 --> URI Class Initialized
INFO - 2018-03-21 08:18:26 --> Router Class Initialized
DEBUG - 2018-03-21 08:18:26 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:18:26 --> Utf8 Class Initialized
INFO - 2018-03-21 08:18:26 --> URI Class Initialized
INFO - 2018-03-21 08:18:26 --> Output Class Initialized
INFO - 2018-03-21 08:18:26 --> Router Class Initialized
INFO - 2018-03-21 08:18:26 --> Security Class Initialized
DEBUG - 2018-03-21 08:18:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:18:26 --> Input Class Initialized
INFO - 2018-03-21 08:18:26 --> Output Class Initialized
INFO - 2018-03-21 08:18:26 --> Language Class Initialized
INFO - 2018-03-21 08:18:26 --> Security Class Initialized
ERROR - 2018-03-21 08:18:26 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-21 08:18:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:18:26 --> Input Class Initialized
INFO - 2018-03-21 08:18:26 --> Language Class Initialized
ERROR - 2018-03-21 08:18:26 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-21 08:18:26 --> Config Class Initialized
INFO - 2018-03-21 08:18:26 --> Hooks Class Initialized
INFO - 2018-03-21 08:18:26 --> Config Class Initialized
INFO - 2018-03-21 08:18:26 --> Hooks Class Initialized
INFO - 2018-03-21 08:18:26 --> Config Class Initialized
DEBUG - 2018-03-21 08:18:26 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:18:26 --> Hooks Class Initialized
INFO - 2018-03-21 08:18:26 --> Utf8 Class Initialized
INFO - 2018-03-21 08:18:26 --> URI Class Initialized
DEBUG - 2018-03-21 08:18:26 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:18:26 --> Utf8 Class Initialized
DEBUG - 2018-03-21 08:18:26 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:18:26 --> Router Class Initialized
INFO - 2018-03-21 08:18:26 --> Utf8 Class Initialized
INFO - 2018-03-21 08:18:26 --> URI Class Initialized
INFO - 2018-03-21 08:18:26 --> URI Class Initialized
INFO - 2018-03-21 08:18:26 --> Output Class Initialized
INFO - 2018-03-21 08:18:26 --> Router Class Initialized
INFO - 2018-03-21 08:18:26 --> Router Class Initialized
INFO - 2018-03-21 08:18:26 --> Security Class Initialized
INFO - 2018-03-21 08:18:26 --> Output Class Initialized
INFO - 2018-03-21 08:18:26 --> Output Class Initialized
DEBUG - 2018-03-21 08:18:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:18:26 --> Input Class Initialized
INFO - 2018-03-21 08:18:26 --> Security Class Initialized
INFO - 2018-03-21 08:18:26 --> Security Class Initialized
INFO - 2018-03-21 08:18:26 --> Language Class Initialized
DEBUG - 2018-03-21 08:18:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-21 08:18:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:18:26 --> Input Class Initialized
ERROR - 2018-03-21 08:18:26 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-21 08:18:26 --> Input Class Initialized
INFO - 2018-03-21 08:18:26 --> Language Class Initialized
INFO - 2018-03-21 08:18:26 --> Language Class Initialized
ERROR - 2018-03-21 08:18:26 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-21 08:18:26 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-21 08:18:26 --> Config Class Initialized
INFO - 2018-03-21 08:18:26 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:18:26 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:18:26 --> Utf8 Class Initialized
INFO - 2018-03-21 08:18:26 --> URI Class Initialized
INFO - 2018-03-21 08:18:26 --> Router Class Initialized
INFO - 2018-03-21 08:18:26 --> Output Class Initialized
INFO - 2018-03-21 08:18:26 --> Security Class Initialized
DEBUG - 2018-03-21 08:18:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:18:26 --> Input Class Initialized
INFO - 2018-03-21 08:18:26 --> Language Class Initialized
INFO - 2018-03-21 08:18:26 --> Loader Class Initialized
INFO - 2018-03-21 08:18:26 --> Helper loaded: url_helper
INFO - 2018-03-21 08:18:26 --> Helper loaded: form_helper
INFO - 2018-03-21 08:18:26 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:18:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:18:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:18:26 --> Form Validation Class Initialized
INFO - 2018-03-21 08:18:26 --> Model Class Initialized
INFO - 2018-03-21 08:18:26 --> Controller Class Initialized
INFO - 2018-03-21 08:18:26 --> Model Class Initialized
INFO - 2018-03-21 08:18:26 --> Model Class Initialized
INFO - 2018-03-21 08:18:26 --> Model Class Initialized
INFO - 2018-03-21 08:18:26 --> Model Class Initialized
DEBUG - 2018-03-21 08:18:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:18:32 --> Config Class Initialized
INFO - 2018-03-21 08:18:32 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:18:32 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:18:32 --> Utf8 Class Initialized
INFO - 2018-03-21 08:18:32 --> URI Class Initialized
INFO - 2018-03-21 08:18:32 --> Router Class Initialized
INFO - 2018-03-21 08:18:32 --> Output Class Initialized
INFO - 2018-03-21 08:18:32 --> Security Class Initialized
DEBUG - 2018-03-21 08:18:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:18:32 --> Input Class Initialized
INFO - 2018-03-21 08:18:32 --> Language Class Initialized
INFO - 2018-03-21 08:18:32 --> Loader Class Initialized
INFO - 2018-03-21 08:18:32 --> Helper loaded: url_helper
INFO - 2018-03-21 08:18:32 --> Helper loaded: form_helper
INFO - 2018-03-21 08:18:32 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:18:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:18:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:18:32 --> Form Validation Class Initialized
INFO - 2018-03-21 08:18:32 --> Model Class Initialized
INFO - 2018-03-21 08:18:32 --> Controller Class Initialized
INFO - 2018-03-21 08:18:32 --> Model Class Initialized
INFO - 2018-03-21 08:18:32 --> Model Class Initialized
INFO - 2018-03-21 08:18:32 --> Model Class Initialized
INFO - 2018-03-21 08:18:32 --> Model Class Initialized
DEBUG - 2018-03-21 08:18:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:18:34 --> Config Class Initialized
INFO - 2018-03-21 08:18:34 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:18:34 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:18:34 --> Utf8 Class Initialized
INFO - 2018-03-21 08:18:34 --> URI Class Initialized
INFO - 2018-03-21 08:18:34 --> Router Class Initialized
INFO - 2018-03-21 08:18:34 --> Output Class Initialized
INFO - 2018-03-21 08:18:34 --> Security Class Initialized
DEBUG - 2018-03-21 08:18:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:18:34 --> Input Class Initialized
INFO - 2018-03-21 08:18:34 --> Language Class Initialized
INFO - 2018-03-21 08:18:34 --> Loader Class Initialized
INFO - 2018-03-21 08:18:34 --> Helper loaded: url_helper
INFO - 2018-03-21 08:18:34 --> Helper loaded: form_helper
INFO - 2018-03-21 08:18:34 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:18:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:18:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:18:34 --> Form Validation Class Initialized
INFO - 2018-03-21 08:18:34 --> Model Class Initialized
INFO - 2018-03-21 08:18:34 --> Controller Class Initialized
INFO - 2018-03-21 08:18:34 --> Model Class Initialized
INFO - 2018-03-21 08:18:34 --> Model Class Initialized
INFO - 2018-03-21 08:18:34 --> Model Class Initialized
INFO - 2018-03-21 08:18:34 --> Model Class Initialized
DEBUG - 2018-03-21 08:18:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:18:34 --> Config Class Initialized
INFO - 2018-03-21 08:18:34 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:18:34 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:18:34 --> Utf8 Class Initialized
INFO - 2018-03-21 08:18:34 --> URI Class Initialized
INFO - 2018-03-21 08:18:34 --> Router Class Initialized
INFO - 2018-03-21 08:18:34 --> Output Class Initialized
INFO - 2018-03-21 08:18:34 --> Security Class Initialized
DEBUG - 2018-03-21 08:18:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:18:34 --> Input Class Initialized
INFO - 2018-03-21 08:18:34 --> Language Class Initialized
INFO - 2018-03-21 08:18:34 --> Loader Class Initialized
INFO - 2018-03-21 08:18:34 --> Helper loaded: url_helper
INFO - 2018-03-21 08:18:34 --> Helper loaded: form_helper
INFO - 2018-03-21 08:18:35 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:18:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:18:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:18:35 --> Form Validation Class Initialized
INFO - 2018-03-21 08:18:35 --> Model Class Initialized
INFO - 2018-03-21 08:18:35 --> Controller Class Initialized
INFO - 2018-03-21 08:18:35 --> Model Class Initialized
INFO - 2018-03-21 08:18:35 --> Model Class Initialized
INFO - 2018-03-21 08:18:35 --> Model Class Initialized
INFO - 2018-03-21 08:18:35 --> Model Class Initialized
DEBUG - 2018-03-21 08:18:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:18:35 --> Config Class Initialized
INFO - 2018-03-21 08:18:35 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:18:35 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:18:35 --> Utf8 Class Initialized
INFO - 2018-03-21 08:18:35 --> URI Class Initialized
INFO - 2018-03-21 08:18:35 --> Router Class Initialized
INFO - 2018-03-21 08:18:35 --> Output Class Initialized
INFO - 2018-03-21 08:18:35 --> Security Class Initialized
DEBUG - 2018-03-21 08:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:18:35 --> Input Class Initialized
INFO - 2018-03-21 08:18:35 --> Language Class Initialized
INFO - 2018-03-21 08:18:35 --> Loader Class Initialized
INFO - 2018-03-21 08:18:35 --> Helper loaded: url_helper
INFO - 2018-03-21 08:18:35 --> Helper loaded: form_helper
INFO - 2018-03-21 08:18:35 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:18:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:18:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:18:35 --> Form Validation Class Initialized
INFO - 2018-03-21 08:18:35 --> Model Class Initialized
INFO - 2018-03-21 08:18:35 --> Controller Class Initialized
INFO - 2018-03-21 08:18:35 --> Model Class Initialized
INFO - 2018-03-21 08:18:35 --> Model Class Initialized
INFO - 2018-03-21 08:18:35 --> Model Class Initialized
INFO - 2018-03-21 08:18:35 --> Model Class Initialized
DEBUG - 2018-03-21 08:18:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:18:41 --> Config Class Initialized
INFO - 2018-03-21 08:18:41 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:18:41 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:18:41 --> Utf8 Class Initialized
INFO - 2018-03-21 08:18:41 --> URI Class Initialized
INFO - 2018-03-21 08:18:41 --> Router Class Initialized
INFO - 2018-03-21 08:18:41 --> Output Class Initialized
INFO - 2018-03-21 08:18:41 --> Security Class Initialized
DEBUG - 2018-03-21 08:18:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:18:41 --> Input Class Initialized
INFO - 2018-03-21 08:18:41 --> Language Class Initialized
INFO - 2018-03-21 08:18:41 --> Loader Class Initialized
INFO - 2018-03-21 08:18:41 --> Helper loaded: url_helper
INFO - 2018-03-21 08:18:41 --> Helper loaded: form_helper
INFO - 2018-03-21 08:18:41 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:18:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:18:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:18:41 --> Form Validation Class Initialized
INFO - 2018-03-21 08:18:41 --> Model Class Initialized
INFO - 2018-03-21 08:18:41 --> Controller Class Initialized
INFO - 2018-03-21 08:18:41 --> Model Class Initialized
INFO - 2018-03-21 08:18:41 --> Model Class Initialized
INFO - 2018-03-21 08:18:41 --> Model Class Initialized
INFO - 2018-03-21 08:18:41 --> Model Class Initialized
DEBUG - 2018-03-21 08:18:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:18:52 --> Config Class Initialized
INFO - 2018-03-21 08:18:52 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:18:52 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:18:52 --> Utf8 Class Initialized
INFO - 2018-03-21 08:18:52 --> URI Class Initialized
INFO - 2018-03-21 08:18:52 --> Router Class Initialized
INFO - 2018-03-21 08:18:52 --> Output Class Initialized
INFO - 2018-03-21 08:18:52 --> Security Class Initialized
DEBUG - 2018-03-21 08:18:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:18:52 --> Input Class Initialized
INFO - 2018-03-21 08:18:52 --> Language Class Initialized
INFO - 2018-03-21 08:18:52 --> Loader Class Initialized
INFO - 2018-03-21 08:18:52 --> Helper loaded: url_helper
INFO - 2018-03-21 08:18:52 --> Helper loaded: form_helper
INFO - 2018-03-21 08:18:52 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:18:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:18:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:18:52 --> Form Validation Class Initialized
INFO - 2018-03-21 08:18:52 --> Model Class Initialized
INFO - 2018-03-21 08:18:52 --> Controller Class Initialized
INFO - 2018-03-21 08:18:52 --> Model Class Initialized
INFO - 2018-03-21 08:18:52 --> Model Class Initialized
INFO - 2018-03-21 08:18:52 --> Model Class Initialized
INFO - 2018-03-21 08:18:52 --> Model Class Initialized
DEBUG - 2018-03-21 08:18:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:19:02 --> Config Class Initialized
INFO - 2018-03-21 08:19:02 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:19:02 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:19:02 --> Utf8 Class Initialized
INFO - 2018-03-21 08:19:02 --> URI Class Initialized
INFO - 2018-03-21 08:19:02 --> Router Class Initialized
INFO - 2018-03-21 08:19:02 --> Output Class Initialized
INFO - 2018-03-21 08:19:02 --> Security Class Initialized
DEBUG - 2018-03-21 08:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:19:02 --> Input Class Initialized
INFO - 2018-03-21 08:19:02 --> Language Class Initialized
INFO - 2018-03-21 08:19:02 --> Loader Class Initialized
INFO - 2018-03-21 08:19:02 --> Helper loaded: url_helper
INFO - 2018-03-21 08:19:02 --> Helper loaded: form_helper
INFO - 2018-03-21 08:19:02 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:19:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:19:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:19:02 --> Form Validation Class Initialized
INFO - 2018-03-21 08:19:02 --> Model Class Initialized
INFO - 2018-03-21 08:19:02 --> Controller Class Initialized
INFO - 2018-03-21 08:19:02 --> Model Class Initialized
INFO - 2018-03-21 08:19:02 --> Model Class Initialized
INFO - 2018-03-21 08:19:02 --> Model Class Initialized
INFO - 2018-03-21 08:19:02 --> Model Class Initialized
DEBUG - 2018-03-21 08:19:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 08:19:02 --> Model Class Initialized
INFO - 2018-03-21 08:19:02 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-21 08:19:02 --> Final output sent to browser
DEBUG - 2018-03-21 08:19:02 --> Total execution time: 0.0869
INFO - 2018-03-21 08:19:02 --> Config Class Initialized
INFO - 2018-03-21 08:19:02 --> Hooks Class Initialized
INFO - 2018-03-21 08:19:02 --> Config Class Initialized
INFO - 2018-03-21 08:19:02 --> Hooks Class Initialized
INFO - 2018-03-21 08:19:02 --> Config Class Initialized
INFO - 2018-03-21 08:19:02 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:19:02 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:19:02 --> Utf8 Class Initialized
DEBUG - 2018-03-21 08:19:02 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:19:02 --> Utf8 Class Initialized
DEBUG - 2018-03-21 08:19:02 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:19:02 --> Utf8 Class Initialized
INFO - 2018-03-21 08:19:02 --> URI Class Initialized
INFO - 2018-03-21 08:19:02 --> URI Class Initialized
INFO - 2018-03-21 08:19:02 --> Config Class Initialized
INFO - 2018-03-21 08:19:02 --> URI Class Initialized
INFO - 2018-03-21 08:19:02 --> Hooks Class Initialized
INFO - 2018-03-21 08:19:02 --> Router Class Initialized
INFO - 2018-03-21 08:19:02 --> Router Class Initialized
INFO - 2018-03-21 08:19:02 --> Router Class Initialized
INFO - 2018-03-21 08:19:02 --> Output Class Initialized
DEBUG - 2018-03-21 08:19:02 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:19:02 --> Utf8 Class Initialized
INFO - 2018-03-21 08:19:02 --> Output Class Initialized
INFO - 2018-03-21 08:19:02 --> Output Class Initialized
INFO - 2018-03-21 08:19:02 --> Security Class Initialized
INFO - 2018-03-21 08:19:02 --> URI Class Initialized
INFO - 2018-03-21 08:19:02 --> Security Class Initialized
INFO - 2018-03-21 08:19:02 --> Security Class Initialized
DEBUG - 2018-03-21 08:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:19:02 --> Router Class Initialized
INFO - 2018-03-21 08:19:02 --> Input Class Initialized
DEBUG - 2018-03-21 08:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:19:02 --> Input Class Initialized
DEBUG - 2018-03-21 08:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:19:02 --> Input Class Initialized
INFO - 2018-03-21 08:19:02 --> Language Class Initialized
INFO - 2018-03-21 08:19:02 --> Language Class Initialized
INFO - 2018-03-21 08:19:02 --> Output Class Initialized
INFO - 2018-03-21 08:19:02 --> Language Class Initialized
ERROR - 2018-03-21 08:19:02 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-21 08:19:02 --> Security Class Initialized
DEBUG - 2018-03-21 08:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:19:02 --> Input Class Initialized
INFO - 2018-03-21 08:19:02 --> Language Class Initialized
ERROR - 2018-03-21 08:19:02 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-21 08:19:02 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-21 08:19:02 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-21 08:19:03 --> Config Class Initialized
INFO - 2018-03-21 08:19:03 --> Hooks Class Initialized
INFO - 2018-03-21 08:19:03 --> Config Class Initialized
INFO - 2018-03-21 08:19:03 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:19:03 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:19:03 --> Utf8 Class Initialized
DEBUG - 2018-03-21 08:19:03 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:19:03 --> URI Class Initialized
INFO - 2018-03-21 08:19:03 --> Utf8 Class Initialized
INFO - 2018-03-21 08:19:03 --> Config Class Initialized
INFO - 2018-03-21 08:19:03 --> Hooks Class Initialized
INFO - 2018-03-21 08:19:03 --> URI Class Initialized
INFO - 2018-03-21 08:19:03 --> Router Class Initialized
DEBUG - 2018-03-21 08:19:03 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:19:03 --> Utf8 Class Initialized
INFO - 2018-03-21 08:19:03 --> Router Class Initialized
INFO - 2018-03-21 08:19:03 --> Output Class Initialized
INFO - 2018-03-21 08:19:03 --> URI Class Initialized
INFO - 2018-03-21 08:19:03 --> Security Class Initialized
INFO - 2018-03-21 08:19:03 --> Output Class Initialized
INFO - 2018-03-21 08:19:03 --> Router Class Initialized
DEBUG - 2018-03-21 08:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:19:03 --> Input Class Initialized
INFO - 2018-03-21 08:19:03 --> Security Class Initialized
INFO - 2018-03-21 08:19:03 --> Output Class Initialized
INFO - 2018-03-21 08:19:03 --> Language Class Initialized
DEBUG - 2018-03-21 08:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:19:03 --> Input Class Initialized
ERROR - 2018-03-21 08:19:03 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-21 08:19:03 --> Security Class Initialized
INFO - 2018-03-21 08:19:03 --> Language Class Initialized
ERROR - 2018-03-21 08:19:03 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-03-21 08:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:19:03 --> Input Class Initialized
INFO - 2018-03-21 08:19:03 --> Language Class Initialized
ERROR - 2018-03-21 08:19:03 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-21 08:19:03 --> Config Class Initialized
INFO - 2018-03-21 08:19:03 --> Hooks Class Initialized
DEBUG - 2018-03-21 08:19:03 --> UTF-8 Support Enabled
INFO - 2018-03-21 08:19:03 --> Utf8 Class Initialized
INFO - 2018-03-21 08:19:03 --> URI Class Initialized
INFO - 2018-03-21 08:19:03 --> Router Class Initialized
INFO - 2018-03-21 08:19:03 --> Output Class Initialized
INFO - 2018-03-21 08:19:03 --> Security Class Initialized
DEBUG - 2018-03-21 08:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 08:19:03 --> Input Class Initialized
INFO - 2018-03-21 08:19:03 --> Language Class Initialized
INFO - 2018-03-21 08:19:03 --> Loader Class Initialized
INFO - 2018-03-21 08:19:03 --> Helper loaded: url_helper
INFO - 2018-03-21 08:19:03 --> Helper loaded: form_helper
INFO - 2018-03-21 08:19:03 --> Database Driver Class Initialized
DEBUG - 2018-03-21 08:19:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 08:19:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 08:19:03 --> Form Validation Class Initialized
INFO - 2018-03-21 08:19:03 --> Model Class Initialized
INFO - 2018-03-21 08:19:03 --> Controller Class Initialized
INFO - 2018-03-21 08:19:03 --> Model Class Initialized
INFO - 2018-03-21 08:19:03 --> Model Class Initialized
INFO - 2018-03-21 08:19:03 --> Model Class Initialized
INFO - 2018-03-21 08:19:03 --> Model Class Initialized
DEBUG - 2018-03-21 08:19:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 22:09:31 --> Config Class Initialized
INFO - 2018-03-21 22:09:31 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:09:31 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:09:31 --> Utf8 Class Initialized
INFO - 2018-03-21 22:09:31 --> URI Class Initialized
INFO - 2018-03-21 22:09:31 --> Router Class Initialized
INFO - 2018-03-21 22:09:31 --> Output Class Initialized
INFO - 2018-03-21 22:09:31 --> Security Class Initialized
DEBUG - 2018-03-21 22:09:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:09:31 --> Input Class Initialized
INFO - 2018-03-21 22:09:31 --> Language Class Initialized
INFO - 2018-03-21 22:09:31 --> Loader Class Initialized
INFO - 2018-03-21 22:09:31 --> Helper loaded: url_helper
INFO - 2018-03-21 22:09:31 --> Helper loaded: form_helper
INFO - 2018-03-21 22:09:31 --> Database Driver Class Initialized
DEBUG - 2018-03-21 22:09:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 22:09:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 22:09:31 --> Form Validation Class Initialized
INFO - 2018-03-21 22:09:31 --> Model Class Initialized
INFO - 2018-03-21 22:09:31 --> Controller Class Initialized
INFO - 2018-03-21 22:09:31 --> Model Class Initialized
INFO - 2018-03-21 22:09:31 --> Model Class Initialized
INFO - 2018-03-21 22:09:31 --> Model Class Initialized
INFO - 2018-03-21 22:09:31 --> Model Class Initialized
DEBUG - 2018-03-21 22:09:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 22:09:31 --> Config Class Initialized
INFO - 2018-03-21 22:09:31 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:09:31 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:09:31 --> Utf8 Class Initialized
INFO - 2018-03-21 22:09:31 --> URI Class Initialized
INFO - 2018-03-21 22:09:31 --> Router Class Initialized
INFO - 2018-03-21 22:09:31 --> Output Class Initialized
INFO - 2018-03-21 22:09:31 --> Security Class Initialized
DEBUG - 2018-03-21 22:09:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:09:31 --> Input Class Initialized
INFO - 2018-03-21 22:09:31 --> Language Class Initialized
INFO - 2018-03-21 22:09:31 --> Loader Class Initialized
INFO - 2018-03-21 22:09:31 --> Helper loaded: url_helper
INFO - 2018-03-21 22:09:31 --> Helper loaded: form_helper
INFO - 2018-03-21 22:09:31 --> Database Driver Class Initialized
DEBUG - 2018-03-21 22:09:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 22:09:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 22:09:31 --> Form Validation Class Initialized
INFO - 2018-03-21 22:09:31 --> Model Class Initialized
INFO - 2018-03-21 22:09:31 --> Controller Class Initialized
INFO - 2018-03-21 22:09:31 --> Model Class Initialized
DEBUG - 2018-03-21 22:09:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 22:09:31 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-21 22:09:31 --> Final output sent to browser
DEBUG - 2018-03-21 22:09:31 --> Total execution time: 0.0416
INFO - 2018-03-21 22:09:32 --> Config Class Initialized
INFO - 2018-03-21 22:09:32 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:09:32 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:09:32 --> Utf8 Class Initialized
INFO - 2018-03-21 22:09:32 --> URI Class Initialized
INFO - 2018-03-21 22:09:32 --> Router Class Initialized
INFO - 2018-03-21 22:09:32 --> Output Class Initialized
INFO - 2018-03-21 22:09:32 --> Security Class Initialized
DEBUG - 2018-03-21 22:09:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:09:32 --> Input Class Initialized
INFO - 2018-03-21 22:09:32 --> Language Class Initialized
INFO - 2018-03-21 22:09:32 --> Loader Class Initialized
INFO - 2018-03-21 22:09:32 --> Helper loaded: url_helper
INFO - 2018-03-21 22:09:32 --> Helper loaded: form_helper
INFO - 2018-03-21 22:09:32 --> Database Driver Class Initialized
DEBUG - 2018-03-21 22:09:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 22:09:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 22:09:32 --> Form Validation Class Initialized
INFO - 2018-03-21 22:09:32 --> Model Class Initialized
INFO - 2018-03-21 22:09:32 --> Controller Class Initialized
INFO - 2018-03-21 22:09:32 --> Model Class Initialized
DEBUG - 2018-03-21 22:09:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 22:09:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-21 22:09:33 --> Config Class Initialized
INFO - 2018-03-21 22:09:33 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:09:33 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:09:33 --> Utf8 Class Initialized
INFO - 2018-03-21 22:09:33 --> URI Class Initialized
DEBUG - 2018-03-21 22:09:33 --> No URI present. Default controller set.
INFO - 2018-03-21 22:09:33 --> Router Class Initialized
INFO - 2018-03-21 22:09:33 --> Output Class Initialized
INFO - 2018-03-21 22:09:33 --> Security Class Initialized
DEBUG - 2018-03-21 22:09:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:09:33 --> Input Class Initialized
INFO - 2018-03-21 22:09:33 --> Language Class Initialized
INFO - 2018-03-21 22:09:33 --> Loader Class Initialized
INFO - 2018-03-21 22:09:33 --> Helper loaded: url_helper
INFO - 2018-03-21 22:09:33 --> Helper loaded: form_helper
INFO - 2018-03-21 22:09:33 --> Database Driver Class Initialized
DEBUG - 2018-03-21 22:09:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 22:09:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 22:09:33 --> Form Validation Class Initialized
INFO - 2018-03-21 22:09:33 --> Model Class Initialized
INFO - 2018-03-21 22:09:33 --> Controller Class Initialized
INFO - 2018-03-21 22:09:33 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-21 22:09:33 --> Final output sent to browser
DEBUG - 2018-03-21 22:09:33 --> Total execution time: 0.0971
INFO - 2018-03-21 22:09:33 --> Config Class Initialized
INFO - 2018-03-21 22:09:33 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:09:33 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:09:33 --> Utf8 Class Initialized
INFO - 2018-03-21 22:09:33 --> URI Class Initialized
INFO - 2018-03-21 22:09:33 --> Router Class Initialized
INFO - 2018-03-21 22:09:33 --> Output Class Initialized
INFO - 2018-03-21 22:09:33 --> Security Class Initialized
DEBUG - 2018-03-21 22:09:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:09:33 --> Input Class Initialized
INFO - 2018-03-21 22:09:33 --> Language Class Initialized
INFO - 2018-03-21 22:09:33 --> Loader Class Initialized
INFO - 2018-03-21 22:09:33 --> Helper loaded: url_helper
INFO - 2018-03-21 22:09:33 --> Helper loaded: form_helper
INFO - 2018-03-21 22:09:33 --> Database Driver Class Initialized
DEBUG - 2018-03-21 22:09:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 22:09:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 22:09:33 --> Form Validation Class Initialized
INFO - 2018-03-21 22:09:33 --> Model Class Initialized
INFO - 2018-03-21 22:09:33 --> Controller Class Initialized
INFO - 2018-03-21 22:09:33 --> Model Class Initialized
INFO - 2018-03-21 22:09:33 --> Model Class Initialized
INFO - 2018-03-21 22:09:33 --> Model Class Initialized
INFO - 2018-03-21 22:09:33 --> Model Class Initialized
INFO - 2018-03-21 22:09:33 --> Model Class Initialized
DEBUG - 2018-03-21 22:09:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 22:09:35 --> Config Class Initialized
INFO - 2018-03-21 22:09:35 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:09:35 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:09:35 --> Utf8 Class Initialized
INFO - 2018-03-21 22:09:35 --> URI Class Initialized
INFO - 2018-03-21 22:09:35 --> Router Class Initialized
INFO - 2018-03-21 22:09:35 --> Output Class Initialized
INFO - 2018-03-21 22:09:35 --> Security Class Initialized
DEBUG - 2018-03-21 22:09:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:09:35 --> Input Class Initialized
INFO - 2018-03-21 22:09:35 --> Language Class Initialized
INFO - 2018-03-21 22:09:35 --> Loader Class Initialized
INFO - 2018-03-21 22:09:35 --> Helper loaded: url_helper
INFO - 2018-03-21 22:09:35 --> Helper loaded: form_helper
INFO - 2018-03-21 22:09:35 --> Database Driver Class Initialized
DEBUG - 2018-03-21 22:09:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 22:09:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 22:09:35 --> Form Validation Class Initialized
INFO - 2018-03-21 22:09:35 --> Model Class Initialized
INFO - 2018-03-21 22:09:35 --> Controller Class Initialized
INFO - 2018-03-21 22:09:35 --> Model Class Initialized
INFO - 2018-03-21 22:09:35 --> Model Class Initialized
INFO - 2018-03-21 22:09:35 --> Model Class Initialized
INFO - 2018-03-21 22:09:35 --> Model Class Initialized
DEBUG - 2018-03-21 22:09:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 22:09:35 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-21 22:09:35 --> Final output sent to browser
DEBUG - 2018-03-21 22:09:35 --> Total execution time: 0.0691
INFO - 2018-03-21 22:09:36 --> Config Class Initialized
INFO - 2018-03-21 22:09:36 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:09:36 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:09:36 --> Utf8 Class Initialized
INFO - 2018-03-21 22:09:36 --> URI Class Initialized
INFO - 2018-03-21 22:09:36 --> Router Class Initialized
INFO - 2018-03-21 22:09:36 --> Output Class Initialized
INFO - 2018-03-21 22:09:36 --> Security Class Initialized
DEBUG - 2018-03-21 22:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:09:36 --> Input Class Initialized
INFO - 2018-03-21 22:09:36 --> Language Class Initialized
INFO - 2018-03-21 22:09:36 --> Loader Class Initialized
INFO - 2018-03-21 22:09:36 --> Helper loaded: url_helper
INFO - 2018-03-21 22:09:36 --> Helper loaded: form_helper
INFO - 2018-03-21 22:09:36 --> Database Driver Class Initialized
DEBUG - 2018-03-21 22:09:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 22:09:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 22:09:36 --> Form Validation Class Initialized
INFO - 2018-03-21 22:09:36 --> Model Class Initialized
INFO - 2018-03-21 22:09:36 --> Controller Class Initialized
INFO - 2018-03-21 22:09:36 --> Model Class Initialized
INFO - 2018-03-21 22:09:36 --> Model Class Initialized
INFO - 2018-03-21 22:09:36 --> Model Class Initialized
INFO - 2018-03-21 22:09:36 --> Model Class Initialized
DEBUG - 2018-03-21 22:09:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 22:09:36 --> Model Class Initialized
INFO - 2018-03-21 22:09:36 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-21 22:09:36 --> Final output sent to browser
DEBUG - 2018-03-21 22:09:36 --> Total execution time: 0.0653
INFO - 2018-03-21 22:09:36 --> Config Class Initialized
INFO - 2018-03-21 22:09:36 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:09:36 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:09:36 --> Utf8 Class Initialized
INFO - 2018-03-21 22:09:36 --> URI Class Initialized
INFO - 2018-03-21 22:09:36 --> Router Class Initialized
INFO - 2018-03-21 22:09:36 --> Output Class Initialized
INFO - 2018-03-21 22:09:36 --> Security Class Initialized
DEBUG - 2018-03-21 22:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:09:36 --> Input Class Initialized
INFO - 2018-03-21 22:09:36 --> Language Class Initialized
INFO - 2018-03-21 22:09:36 --> Loader Class Initialized
INFO - 2018-03-21 22:09:36 --> Helper loaded: url_helper
INFO - 2018-03-21 22:09:36 --> Helper loaded: form_helper
INFO - 2018-03-21 22:09:36 --> Database Driver Class Initialized
DEBUG - 2018-03-21 22:09:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 22:09:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 22:09:36 --> Form Validation Class Initialized
INFO - 2018-03-21 22:09:36 --> Model Class Initialized
INFO - 2018-03-21 22:09:36 --> Controller Class Initialized
INFO - 2018-03-21 22:09:36 --> Model Class Initialized
INFO - 2018-03-21 22:09:36 --> Model Class Initialized
DEBUG - 2018-03-21 22:09:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 22:09:38 --> Config Class Initialized
INFO - 2018-03-21 22:09:38 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:09:38 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:09:38 --> Utf8 Class Initialized
INFO - 2018-03-21 22:09:38 --> URI Class Initialized
INFO - 2018-03-21 22:09:38 --> Router Class Initialized
INFO - 2018-03-21 22:09:38 --> Output Class Initialized
INFO - 2018-03-21 22:09:38 --> Security Class Initialized
DEBUG - 2018-03-21 22:09:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:09:38 --> Input Class Initialized
INFO - 2018-03-21 22:09:38 --> Language Class Initialized
INFO - 2018-03-21 22:09:38 --> Loader Class Initialized
INFO - 2018-03-21 22:09:38 --> Helper loaded: url_helper
INFO - 2018-03-21 22:09:38 --> Helper loaded: form_helper
INFO - 2018-03-21 22:09:38 --> Database Driver Class Initialized
DEBUG - 2018-03-21 22:09:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 22:09:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 22:09:38 --> Form Validation Class Initialized
INFO - 2018-03-21 22:09:38 --> Model Class Initialized
INFO - 2018-03-21 22:09:38 --> Controller Class Initialized
INFO - 2018-03-21 22:09:38 --> Model Class Initialized
INFO - 2018-03-21 22:09:38 --> Model Class Initialized
INFO - 2018-03-21 22:09:38 --> Model Class Initialized
INFO - 2018-03-21 22:09:38 --> Model Class Initialized
DEBUG - 2018-03-21 22:09:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 22:09:38 --> Model Class Initialized
INFO - 2018-03-21 22:09:38 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-21 22:09:38 --> Final output sent to browser
DEBUG - 2018-03-21 22:09:38 --> Total execution time: 0.0602
INFO - 2018-03-21 22:09:38 --> Config Class Initialized
INFO - 2018-03-21 22:09:38 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:09:38 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:09:38 --> Utf8 Class Initialized
INFO - 2018-03-21 22:09:38 --> URI Class Initialized
INFO - 2018-03-21 22:09:38 --> Router Class Initialized
INFO - 2018-03-21 22:09:38 --> Output Class Initialized
INFO - 2018-03-21 22:09:38 --> Security Class Initialized
DEBUG - 2018-03-21 22:09:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:09:38 --> Input Class Initialized
INFO - 2018-03-21 22:09:38 --> Language Class Initialized
INFO - 2018-03-21 22:09:38 --> Loader Class Initialized
INFO - 2018-03-21 22:09:38 --> Helper loaded: url_helper
INFO - 2018-03-21 22:09:38 --> Helper loaded: form_helper
INFO - 2018-03-21 22:09:38 --> Database Driver Class Initialized
DEBUG - 2018-03-21 22:09:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 22:09:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 22:09:38 --> Form Validation Class Initialized
INFO - 2018-03-21 22:09:38 --> Model Class Initialized
INFO - 2018-03-21 22:09:38 --> Controller Class Initialized
INFO - 2018-03-21 22:09:38 --> Model Class Initialized
INFO - 2018-03-21 22:09:38 --> Model Class Initialized
INFO - 2018-03-21 22:09:38 --> Model Class Initialized
INFO - 2018-03-21 22:09:38 --> Model Class Initialized
DEBUG - 2018-03-21 22:09:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 22:09:57 --> Config Class Initialized
INFO - 2018-03-21 22:09:57 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:09:57 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:09:57 --> Utf8 Class Initialized
INFO - 2018-03-21 22:09:57 --> URI Class Initialized
INFO - 2018-03-21 22:09:57 --> Router Class Initialized
INFO - 2018-03-21 22:09:57 --> Output Class Initialized
INFO - 2018-03-21 22:09:57 --> Security Class Initialized
DEBUG - 2018-03-21 22:09:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:09:57 --> Input Class Initialized
INFO - 2018-03-21 22:09:57 --> Language Class Initialized
INFO - 2018-03-21 22:09:57 --> Loader Class Initialized
INFO - 2018-03-21 22:09:57 --> Helper loaded: url_helper
INFO - 2018-03-21 22:09:57 --> Helper loaded: form_helper
INFO - 2018-03-21 22:09:57 --> Database Driver Class Initialized
DEBUG - 2018-03-21 22:09:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 22:09:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 22:09:57 --> Form Validation Class Initialized
INFO - 2018-03-21 22:09:57 --> Model Class Initialized
INFO - 2018-03-21 22:09:57 --> Controller Class Initialized
INFO - 2018-03-21 22:09:57 --> Model Class Initialized
INFO - 2018-03-21 22:09:57 --> Model Class Initialized
INFO - 2018-03-21 22:09:57 --> Model Class Initialized
INFO - 2018-03-21 22:09:57 --> Model Class Initialized
DEBUG - 2018-03-21 22:09:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 22:09:59 --> Config Class Initialized
INFO - 2018-03-21 22:09:59 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:09:59 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:09:59 --> Utf8 Class Initialized
INFO - 2018-03-21 22:09:59 --> URI Class Initialized
INFO - 2018-03-21 22:09:59 --> Router Class Initialized
INFO - 2018-03-21 22:09:59 --> Output Class Initialized
INFO - 2018-03-21 22:09:59 --> Security Class Initialized
DEBUG - 2018-03-21 22:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:09:59 --> Input Class Initialized
INFO - 2018-03-21 22:09:59 --> Language Class Initialized
INFO - 2018-03-21 22:09:59 --> Loader Class Initialized
INFO - 2018-03-21 22:09:59 --> Helper loaded: url_helper
INFO - 2018-03-21 22:09:59 --> Helper loaded: form_helper
INFO - 2018-03-21 22:09:59 --> Database Driver Class Initialized
DEBUG - 2018-03-21 22:09:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 22:09:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 22:09:59 --> Form Validation Class Initialized
INFO - 2018-03-21 22:09:59 --> Model Class Initialized
INFO - 2018-03-21 22:09:59 --> Controller Class Initialized
INFO - 2018-03-21 22:09:59 --> Model Class Initialized
INFO - 2018-03-21 22:09:59 --> Model Class Initialized
INFO - 2018-03-21 22:09:59 --> Model Class Initialized
INFO - 2018-03-21 22:09:59 --> Model Class Initialized
DEBUG - 2018-03-21 22:09:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 22:09:59 --> Model Class Initialized
INFO - 2018-03-21 22:09:59 --> Final output sent to browser
DEBUG - 2018-03-21 22:09:59 --> Total execution time: 0.1746
INFO - 2018-03-21 22:10:33 --> Config Class Initialized
INFO - 2018-03-21 22:10:33 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:10:33 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:10:33 --> Utf8 Class Initialized
INFO - 2018-03-21 22:10:33 --> URI Class Initialized
INFO - 2018-03-21 22:10:33 --> Router Class Initialized
INFO - 2018-03-21 22:10:33 --> Output Class Initialized
INFO - 2018-03-21 22:10:33 --> Security Class Initialized
DEBUG - 2018-03-21 22:10:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:10:33 --> Input Class Initialized
INFO - 2018-03-21 22:10:33 --> Language Class Initialized
INFO - 2018-03-21 22:10:33 --> Loader Class Initialized
INFO - 2018-03-21 22:10:33 --> Helper loaded: url_helper
INFO - 2018-03-21 22:10:33 --> Helper loaded: form_helper
INFO - 2018-03-21 22:10:33 --> Database Driver Class Initialized
DEBUG - 2018-03-21 22:10:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 22:10:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 22:10:33 --> Form Validation Class Initialized
INFO - 2018-03-21 22:10:33 --> Model Class Initialized
INFO - 2018-03-21 22:10:33 --> Controller Class Initialized
INFO - 2018-03-21 22:10:33 --> Model Class Initialized
INFO - 2018-03-21 22:10:33 --> Model Class Initialized
INFO - 2018-03-21 22:10:33 --> Model Class Initialized
INFO - 2018-03-21 22:10:33 --> Model Class Initialized
DEBUG - 2018-03-21 22:10:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 22:10:33 --> Model Class Initialized
INFO - 2018-03-21 22:10:34 --> Final output sent to browser
DEBUG - 2018-03-21 22:10:34 --> Total execution time: 0.1169
INFO - 2018-03-21 22:11:34 --> Config Class Initialized
INFO - 2018-03-21 22:11:34 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:11:34 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:11:34 --> Utf8 Class Initialized
INFO - 2018-03-21 22:11:34 --> URI Class Initialized
INFO - 2018-03-21 22:11:34 --> Router Class Initialized
INFO - 2018-03-21 22:11:34 --> Output Class Initialized
INFO - 2018-03-21 22:11:34 --> Security Class Initialized
DEBUG - 2018-03-21 22:11:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:11:34 --> Input Class Initialized
INFO - 2018-03-21 22:11:34 --> Language Class Initialized
INFO - 2018-03-21 22:11:34 --> Loader Class Initialized
INFO - 2018-03-21 22:11:34 --> Helper loaded: url_helper
INFO - 2018-03-21 22:11:34 --> Helper loaded: form_helper
INFO - 2018-03-21 22:11:34 --> Database Driver Class Initialized
DEBUG - 2018-03-21 22:11:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 22:11:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 22:11:34 --> Form Validation Class Initialized
INFO - 2018-03-21 22:11:34 --> Model Class Initialized
INFO - 2018-03-21 22:11:34 --> Controller Class Initialized
INFO - 2018-03-21 22:11:34 --> Model Class Initialized
INFO - 2018-03-21 22:11:34 --> Model Class Initialized
INFO - 2018-03-21 22:11:34 --> Model Class Initialized
INFO - 2018-03-21 22:11:34 --> Model Class Initialized
DEBUG - 2018-03-21 22:11:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 22:11:34 --> Model Class Initialized
INFO - 2018-03-21 22:11:34 --> Final output sent to browser
DEBUG - 2018-03-21 22:11:34 --> Total execution time: 0.1603
INFO - 2018-03-21 22:12:08 --> Config Class Initialized
INFO - 2018-03-21 22:12:08 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:12:08 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:12:08 --> Utf8 Class Initialized
INFO - 2018-03-21 22:12:08 --> URI Class Initialized
INFO - 2018-03-21 22:12:08 --> Router Class Initialized
INFO - 2018-03-21 22:12:08 --> Output Class Initialized
INFO - 2018-03-21 22:12:08 --> Security Class Initialized
DEBUG - 2018-03-21 22:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:12:08 --> Input Class Initialized
INFO - 2018-03-21 22:12:08 --> Language Class Initialized
INFO - 2018-03-21 22:12:08 --> Loader Class Initialized
INFO - 2018-03-21 22:12:08 --> Helper loaded: url_helper
INFO - 2018-03-21 22:12:08 --> Helper loaded: form_helper
INFO - 2018-03-21 22:12:08 --> Database Driver Class Initialized
DEBUG - 2018-03-21 22:12:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 22:12:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 22:12:08 --> Form Validation Class Initialized
INFO - 2018-03-21 22:12:08 --> Model Class Initialized
INFO - 2018-03-21 22:12:08 --> Controller Class Initialized
INFO - 2018-03-21 22:12:08 --> Model Class Initialized
INFO - 2018-03-21 22:12:08 --> Model Class Initialized
INFO - 2018-03-21 22:12:08 --> Model Class Initialized
INFO - 2018-03-21 22:12:08 --> Model Class Initialized
DEBUG - 2018-03-21 22:12:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 22:12:08 --> Model Class Initialized
INFO - 2018-03-21 22:12:08 --> Final output sent to browser
DEBUG - 2018-03-21 22:12:08 --> Total execution time: 0.1118
INFO - 2018-03-21 22:13:58 --> Config Class Initialized
INFO - 2018-03-21 22:13:58 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:13:58 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:13:58 --> Utf8 Class Initialized
INFO - 2018-03-21 22:13:58 --> URI Class Initialized
INFO - 2018-03-21 22:13:58 --> Router Class Initialized
INFO - 2018-03-21 22:13:58 --> Output Class Initialized
INFO - 2018-03-21 22:13:58 --> Security Class Initialized
DEBUG - 2018-03-21 22:13:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:13:58 --> Input Class Initialized
INFO - 2018-03-21 22:13:58 --> Language Class Initialized
INFO - 2018-03-21 22:13:58 --> Loader Class Initialized
INFO - 2018-03-21 22:13:58 --> Helper loaded: url_helper
INFO - 2018-03-21 22:13:58 --> Helper loaded: form_helper
INFO - 2018-03-21 22:13:58 --> Database Driver Class Initialized
DEBUG - 2018-03-21 22:13:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 22:13:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 22:13:58 --> Form Validation Class Initialized
INFO - 2018-03-21 22:13:58 --> Model Class Initialized
INFO - 2018-03-21 22:13:58 --> Controller Class Initialized
INFO - 2018-03-21 22:13:58 --> Model Class Initialized
INFO - 2018-03-21 22:13:58 --> Model Class Initialized
INFO - 2018-03-21 22:13:58 --> Model Class Initialized
INFO - 2018-03-21 22:13:58 --> Model Class Initialized
DEBUG - 2018-03-21 22:13:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 22:13:58 --> Model Class Initialized
INFO - 2018-03-21 22:13:58 --> Final output sent to browser
DEBUG - 2018-03-21 22:13:58 --> Total execution time: 0.1075
INFO - 2018-03-21 22:14:27 --> Config Class Initialized
INFO - 2018-03-21 22:14:27 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:14:27 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:14:27 --> Utf8 Class Initialized
INFO - 2018-03-21 22:14:27 --> URI Class Initialized
INFO - 2018-03-21 22:14:27 --> Router Class Initialized
INFO - 2018-03-21 22:14:27 --> Output Class Initialized
INFO - 2018-03-21 22:14:27 --> Security Class Initialized
DEBUG - 2018-03-21 22:14:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:14:27 --> Input Class Initialized
INFO - 2018-03-21 22:14:27 --> Language Class Initialized
INFO - 2018-03-21 22:14:27 --> Loader Class Initialized
INFO - 2018-03-21 22:14:27 --> Helper loaded: url_helper
INFO - 2018-03-21 22:14:27 --> Helper loaded: form_helper
INFO - 2018-03-21 22:14:27 --> Database Driver Class Initialized
DEBUG - 2018-03-21 22:14:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 22:14:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 22:14:27 --> Form Validation Class Initialized
INFO - 2018-03-21 22:14:27 --> Model Class Initialized
INFO - 2018-03-21 22:14:27 --> Controller Class Initialized
INFO - 2018-03-21 22:14:27 --> Model Class Initialized
INFO - 2018-03-21 22:14:27 --> Model Class Initialized
INFO - 2018-03-21 22:14:27 --> Model Class Initialized
INFO - 2018-03-21 22:14:27 --> Model Class Initialized
DEBUG - 2018-03-21 22:14:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 22:14:27 --> Model Class Initialized
INFO - 2018-03-21 22:14:27 --> Final output sent to browser
DEBUG - 2018-03-21 22:14:27 --> Total execution time: 0.1229
INFO - 2018-03-21 22:19:02 --> Config Class Initialized
INFO - 2018-03-21 22:19:02 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:19:02 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:19:02 --> Utf8 Class Initialized
INFO - 2018-03-21 22:19:02 --> URI Class Initialized
INFO - 2018-03-21 22:19:02 --> Router Class Initialized
INFO - 2018-03-21 22:19:02 --> Output Class Initialized
INFO - 2018-03-21 22:19:02 --> Security Class Initialized
DEBUG - 2018-03-21 22:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:19:02 --> Input Class Initialized
INFO - 2018-03-21 22:19:02 --> Language Class Initialized
INFO - 2018-03-21 22:19:02 --> Loader Class Initialized
INFO - 2018-03-21 22:19:02 --> Helper loaded: url_helper
INFO - 2018-03-21 22:19:02 --> Helper loaded: form_helper
INFO - 2018-03-21 22:19:02 --> Database Driver Class Initialized
DEBUG - 2018-03-21 22:19:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 22:19:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 22:19:02 --> Form Validation Class Initialized
INFO - 2018-03-21 22:19:02 --> Model Class Initialized
INFO - 2018-03-21 22:19:02 --> Controller Class Initialized
INFO - 2018-03-21 22:19:02 --> Model Class Initialized
INFO - 2018-03-21 22:19:02 --> Model Class Initialized
INFO - 2018-03-21 22:19:02 --> Model Class Initialized
INFO - 2018-03-21 22:19:02 --> Model Class Initialized
DEBUG - 2018-03-21 22:19:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 22:19:02 --> Model Class Initialized
INFO - 2018-03-21 22:19:02 --> Final output sent to browser
DEBUG - 2018-03-21 22:19:02 --> Total execution time: 0.1119
INFO - 2018-03-21 22:20:43 --> Config Class Initialized
INFO - 2018-03-21 22:20:43 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:20:43 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:20:43 --> Utf8 Class Initialized
INFO - 2018-03-21 22:20:43 --> URI Class Initialized
INFO - 2018-03-21 22:20:43 --> Router Class Initialized
INFO - 2018-03-21 22:20:43 --> Output Class Initialized
INFO - 2018-03-21 22:20:43 --> Security Class Initialized
DEBUG - 2018-03-21 22:20:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:20:43 --> Input Class Initialized
INFO - 2018-03-21 22:20:43 --> Language Class Initialized
INFO - 2018-03-21 22:20:43 --> Loader Class Initialized
INFO - 2018-03-21 22:20:43 --> Helper loaded: url_helper
INFO - 2018-03-21 22:20:43 --> Helper loaded: form_helper
INFO - 2018-03-21 22:20:43 --> Database Driver Class Initialized
DEBUG - 2018-03-21 22:20:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 22:20:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 22:20:43 --> Form Validation Class Initialized
INFO - 2018-03-21 22:20:43 --> Model Class Initialized
INFO - 2018-03-21 22:20:43 --> Controller Class Initialized
INFO - 2018-03-21 22:20:43 --> Model Class Initialized
INFO - 2018-03-21 22:20:43 --> Model Class Initialized
INFO - 2018-03-21 22:20:43 --> Model Class Initialized
INFO - 2018-03-21 22:20:43 --> Model Class Initialized
DEBUG - 2018-03-21 22:20:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 22:20:43 --> Model Class Initialized
INFO - 2018-03-21 22:20:43 --> Final output sent to browser
DEBUG - 2018-03-21 22:20:43 --> Total execution time: 0.1305
INFO - 2018-03-21 22:21:33 --> Config Class Initialized
INFO - 2018-03-21 22:21:33 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:21:33 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:21:33 --> Utf8 Class Initialized
INFO - 2018-03-21 22:21:33 --> URI Class Initialized
INFO - 2018-03-21 22:21:33 --> Router Class Initialized
INFO - 2018-03-21 22:21:33 --> Output Class Initialized
INFO - 2018-03-21 22:21:33 --> Security Class Initialized
DEBUG - 2018-03-21 22:21:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:21:33 --> Input Class Initialized
INFO - 2018-03-21 22:21:33 --> Language Class Initialized
INFO - 2018-03-21 22:21:33 --> Loader Class Initialized
INFO - 2018-03-21 22:21:33 --> Helper loaded: url_helper
INFO - 2018-03-21 22:21:33 --> Helper loaded: form_helper
INFO - 2018-03-21 22:21:33 --> Database Driver Class Initialized
DEBUG - 2018-03-21 22:21:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 22:21:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 22:21:33 --> Form Validation Class Initialized
INFO - 2018-03-21 22:21:33 --> Model Class Initialized
INFO - 2018-03-21 22:21:33 --> Controller Class Initialized
INFO - 2018-03-21 22:21:33 --> Model Class Initialized
INFO - 2018-03-21 22:21:33 --> Model Class Initialized
INFO - 2018-03-21 22:21:33 --> Model Class Initialized
INFO - 2018-03-21 22:21:33 --> Model Class Initialized
DEBUG - 2018-03-21 22:21:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 22:21:33 --> Model Class Initialized
INFO - 2018-03-21 22:21:33 --> Final output sent to browser
DEBUG - 2018-03-21 22:21:33 --> Total execution time: 0.1258
INFO - 2018-03-21 22:31:53 --> Config Class Initialized
INFO - 2018-03-21 22:31:53 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:31:53 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:31:53 --> Utf8 Class Initialized
INFO - 2018-03-21 22:31:53 --> URI Class Initialized
INFO - 2018-03-21 22:31:53 --> Router Class Initialized
INFO - 2018-03-21 22:31:53 --> Output Class Initialized
INFO - 2018-03-21 22:31:53 --> Security Class Initialized
DEBUG - 2018-03-21 22:31:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:31:53 --> Input Class Initialized
INFO - 2018-03-21 22:31:53 --> Language Class Initialized
INFO - 2018-03-21 22:31:53 --> Loader Class Initialized
INFO - 2018-03-21 22:31:53 --> Helper loaded: url_helper
INFO - 2018-03-21 22:31:53 --> Helper loaded: form_helper
INFO - 2018-03-21 22:31:53 --> Database Driver Class Initialized
DEBUG - 2018-03-21 22:31:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 22:31:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 22:31:53 --> Form Validation Class Initialized
INFO - 2018-03-21 22:31:53 --> Model Class Initialized
INFO - 2018-03-21 22:31:53 --> Controller Class Initialized
INFO - 2018-03-21 22:31:53 --> Model Class Initialized
INFO - 2018-03-21 22:31:53 --> Model Class Initialized
INFO - 2018-03-21 22:31:53 --> Model Class Initialized
INFO - 2018-03-21 22:31:53 --> Model Class Initialized
DEBUG - 2018-03-21 22:31:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 22:31:53 --> Model Class Initialized
INFO - 2018-03-21 22:31:53 --> Final output sent to browser
DEBUG - 2018-03-21 22:31:53 --> Total execution time: 0.1771
INFO - 2018-03-21 22:35:36 --> Config Class Initialized
INFO - 2018-03-21 22:35:36 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:35:36 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:35:36 --> Utf8 Class Initialized
INFO - 2018-03-21 22:35:36 --> URI Class Initialized
INFO - 2018-03-21 22:35:36 --> Router Class Initialized
INFO - 2018-03-21 22:35:36 --> Output Class Initialized
INFO - 2018-03-21 22:35:36 --> Security Class Initialized
DEBUG - 2018-03-21 22:35:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:35:36 --> Input Class Initialized
INFO - 2018-03-21 22:35:36 --> Language Class Initialized
INFO - 2018-03-21 22:35:36 --> Loader Class Initialized
INFO - 2018-03-21 22:35:36 --> Helper loaded: url_helper
INFO - 2018-03-21 22:35:36 --> Helper loaded: form_helper
INFO - 2018-03-21 22:35:36 --> Database Driver Class Initialized
DEBUG - 2018-03-21 22:35:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 22:35:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 22:35:36 --> Form Validation Class Initialized
INFO - 2018-03-21 22:35:36 --> Model Class Initialized
INFO - 2018-03-21 22:35:36 --> Controller Class Initialized
INFO - 2018-03-21 22:35:36 --> Model Class Initialized
INFO - 2018-03-21 22:35:36 --> Model Class Initialized
INFO - 2018-03-21 22:35:36 --> Model Class Initialized
INFO - 2018-03-21 22:35:36 --> Model Class Initialized
DEBUG - 2018-03-21 22:35:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 22:35:36 --> Model Class Initialized
INFO - 2018-03-21 22:35:36 --> Final output sent to browser
DEBUG - 2018-03-21 22:35:36 --> Total execution time: 0.1549
INFO - 2018-03-21 22:39:29 --> Config Class Initialized
INFO - 2018-03-21 22:39:29 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:39:29 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:39:29 --> Utf8 Class Initialized
INFO - 2018-03-21 22:39:29 --> URI Class Initialized
INFO - 2018-03-21 22:39:29 --> Router Class Initialized
INFO - 2018-03-21 22:39:29 --> Output Class Initialized
INFO - 2018-03-21 22:39:29 --> Security Class Initialized
DEBUG - 2018-03-21 22:39:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:39:29 --> Input Class Initialized
INFO - 2018-03-21 22:39:29 --> Language Class Initialized
INFO - 2018-03-21 22:39:29 --> Loader Class Initialized
INFO - 2018-03-21 22:39:29 --> Helper loaded: url_helper
INFO - 2018-03-21 22:39:29 --> Helper loaded: form_helper
INFO - 2018-03-21 22:39:29 --> Database Driver Class Initialized
DEBUG - 2018-03-21 22:39:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 22:39:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 22:39:29 --> Form Validation Class Initialized
INFO - 2018-03-21 22:39:29 --> Model Class Initialized
INFO - 2018-03-21 22:39:29 --> Controller Class Initialized
INFO - 2018-03-21 22:39:29 --> Model Class Initialized
INFO - 2018-03-21 22:39:29 --> Model Class Initialized
INFO - 2018-03-21 22:39:29 --> Model Class Initialized
INFO - 2018-03-21 22:39:29 --> Model Class Initialized
DEBUG - 2018-03-21 22:39:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 22:39:29 --> Model Class Initialized
INFO - 2018-03-21 22:39:29 --> Final output sent to browser
DEBUG - 2018-03-21 22:39:29 --> Total execution time: 0.1640
INFO - 2018-03-21 22:39:50 --> Config Class Initialized
INFO - 2018-03-21 22:39:50 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:39:50 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:39:50 --> Utf8 Class Initialized
INFO - 2018-03-21 22:39:50 --> URI Class Initialized
INFO - 2018-03-21 22:39:50 --> Router Class Initialized
INFO - 2018-03-21 22:39:50 --> Output Class Initialized
INFO - 2018-03-21 22:39:50 --> Security Class Initialized
DEBUG - 2018-03-21 22:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:39:50 --> Input Class Initialized
INFO - 2018-03-21 22:39:50 --> Language Class Initialized
INFO - 2018-03-21 22:39:50 --> Loader Class Initialized
INFO - 2018-03-21 22:39:50 --> Helper loaded: url_helper
INFO - 2018-03-21 22:39:50 --> Helper loaded: form_helper
INFO - 2018-03-21 22:39:50 --> Database Driver Class Initialized
DEBUG - 2018-03-21 22:39:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 22:39:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 22:39:50 --> Form Validation Class Initialized
INFO - 2018-03-21 22:39:50 --> Model Class Initialized
INFO - 2018-03-21 22:39:50 --> Controller Class Initialized
INFO - 2018-03-21 22:39:50 --> Model Class Initialized
INFO - 2018-03-21 22:39:50 --> Model Class Initialized
INFO - 2018-03-21 22:39:50 --> Model Class Initialized
INFO - 2018-03-21 22:39:50 --> Model Class Initialized
DEBUG - 2018-03-21 22:39:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 22:39:50 --> Model Class Initialized
INFO - 2018-03-21 22:39:50 --> Final output sent to browser
DEBUG - 2018-03-21 22:39:50 --> Total execution time: 0.1528
INFO - 2018-03-21 22:40:14 --> Config Class Initialized
INFO - 2018-03-21 22:40:14 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:40:14 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:40:14 --> Utf8 Class Initialized
INFO - 2018-03-21 22:40:14 --> URI Class Initialized
INFO - 2018-03-21 22:40:14 --> Router Class Initialized
INFO - 2018-03-21 22:40:14 --> Output Class Initialized
INFO - 2018-03-21 22:40:14 --> Security Class Initialized
DEBUG - 2018-03-21 22:40:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:40:14 --> Input Class Initialized
INFO - 2018-03-21 22:40:14 --> Language Class Initialized
INFO - 2018-03-21 22:40:14 --> Loader Class Initialized
INFO - 2018-03-21 22:40:14 --> Helper loaded: url_helper
INFO - 2018-03-21 22:40:14 --> Helper loaded: form_helper
INFO - 2018-03-21 22:40:14 --> Database Driver Class Initialized
DEBUG - 2018-03-21 22:40:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 22:40:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 22:40:14 --> Form Validation Class Initialized
INFO - 2018-03-21 22:40:14 --> Model Class Initialized
INFO - 2018-03-21 22:40:14 --> Controller Class Initialized
INFO - 2018-03-21 22:40:14 --> Model Class Initialized
INFO - 2018-03-21 22:40:14 --> Model Class Initialized
INFO - 2018-03-21 22:40:14 --> Model Class Initialized
INFO - 2018-03-21 22:40:14 --> Model Class Initialized
DEBUG - 2018-03-21 22:40:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 22:40:14 --> Model Class Initialized
INFO - 2018-03-21 22:40:14 --> Final output sent to browser
DEBUG - 2018-03-21 22:40:14 --> Total execution time: 0.1574
INFO - 2018-03-21 22:45:51 --> Config Class Initialized
INFO - 2018-03-21 22:45:51 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:45:51 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:45:51 --> Utf8 Class Initialized
INFO - 2018-03-21 22:45:51 --> URI Class Initialized
INFO - 2018-03-21 22:45:51 --> Router Class Initialized
INFO - 2018-03-21 22:45:51 --> Output Class Initialized
INFO - 2018-03-21 22:45:51 --> Security Class Initialized
DEBUG - 2018-03-21 22:45:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:45:51 --> Input Class Initialized
INFO - 2018-03-21 22:45:51 --> Language Class Initialized
INFO - 2018-03-21 22:45:51 --> Loader Class Initialized
INFO - 2018-03-21 22:45:51 --> Helper loaded: url_helper
INFO - 2018-03-21 22:45:51 --> Helper loaded: form_helper
INFO - 2018-03-21 22:45:51 --> Database Driver Class Initialized
DEBUG - 2018-03-21 22:45:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 22:45:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 22:45:51 --> Form Validation Class Initialized
INFO - 2018-03-21 22:45:51 --> Model Class Initialized
INFO - 2018-03-21 22:45:51 --> Controller Class Initialized
INFO - 2018-03-21 22:45:51 --> Model Class Initialized
INFO - 2018-03-21 22:45:51 --> Model Class Initialized
INFO - 2018-03-21 22:45:51 --> Model Class Initialized
INFO - 2018-03-21 22:45:51 --> Model Class Initialized
DEBUG - 2018-03-21 22:45:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 22:45:51 --> Model Class Initialized
INFO - 2018-03-21 22:45:51 --> Final output sent to browser
DEBUG - 2018-03-21 22:45:51 --> Total execution time: 0.1966
INFO - 2018-03-21 22:47:14 --> Config Class Initialized
INFO - 2018-03-21 22:47:14 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:47:14 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:47:14 --> Utf8 Class Initialized
INFO - 2018-03-21 22:47:14 --> URI Class Initialized
INFO - 2018-03-21 22:47:14 --> Router Class Initialized
INFO - 2018-03-21 22:47:14 --> Output Class Initialized
INFO - 2018-03-21 22:47:14 --> Security Class Initialized
DEBUG - 2018-03-21 22:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:47:14 --> Input Class Initialized
INFO - 2018-03-21 22:47:14 --> Language Class Initialized
INFO - 2018-03-21 22:47:14 --> Loader Class Initialized
INFO - 2018-03-21 22:47:14 --> Helper loaded: url_helper
INFO - 2018-03-21 22:47:14 --> Helper loaded: form_helper
INFO - 2018-03-21 22:47:14 --> Database Driver Class Initialized
DEBUG - 2018-03-21 22:47:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 22:47:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 22:47:14 --> Form Validation Class Initialized
INFO - 2018-03-21 22:47:14 --> Model Class Initialized
INFO - 2018-03-21 22:47:14 --> Controller Class Initialized
INFO - 2018-03-21 22:47:14 --> Model Class Initialized
INFO - 2018-03-21 22:47:14 --> Model Class Initialized
INFO - 2018-03-21 22:47:14 --> Model Class Initialized
INFO - 2018-03-21 22:47:14 --> Model Class Initialized
DEBUG - 2018-03-21 22:47:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 22:47:14 --> Model Class Initialized
INFO - 2018-03-21 22:47:14 --> Final output sent to browser
DEBUG - 2018-03-21 22:47:14 --> Total execution time: 0.1915
INFO - 2018-03-21 22:47:46 --> Config Class Initialized
INFO - 2018-03-21 22:47:46 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:47:46 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:47:46 --> Utf8 Class Initialized
INFO - 2018-03-21 22:47:46 --> URI Class Initialized
INFO - 2018-03-21 22:47:46 --> Router Class Initialized
INFO - 2018-03-21 22:47:46 --> Output Class Initialized
INFO - 2018-03-21 22:47:46 --> Security Class Initialized
DEBUG - 2018-03-21 22:47:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:47:46 --> Input Class Initialized
INFO - 2018-03-21 22:47:46 --> Language Class Initialized
INFO - 2018-03-21 22:47:46 --> Loader Class Initialized
INFO - 2018-03-21 22:47:46 --> Helper loaded: url_helper
INFO - 2018-03-21 22:47:46 --> Helper loaded: form_helper
INFO - 2018-03-21 22:47:46 --> Database Driver Class Initialized
DEBUG - 2018-03-21 22:47:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 22:47:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 22:47:46 --> Form Validation Class Initialized
INFO - 2018-03-21 22:47:46 --> Model Class Initialized
INFO - 2018-03-21 22:47:46 --> Controller Class Initialized
INFO - 2018-03-21 22:47:46 --> Model Class Initialized
INFO - 2018-03-21 22:47:46 --> Model Class Initialized
INFO - 2018-03-21 22:47:46 --> Model Class Initialized
INFO - 2018-03-21 22:47:46 --> Model Class Initialized
DEBUG - 2018-03-21 22:47:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 22:47:46 --> Model Class Initialized
INFO - 2018-03-21 22:47:46 --> Final output sent to browser
DEBUG - 2018-03-21 22:47:46 --> Total execution time: 0.1918
INFO - 2018-03-21 22:48:15 --> Config Class Initialized
INFO - 2018-03-21 22:48:15 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:48:15 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:48:15 --> Utf8 Class Initialized
INFO - 2018-03-21 22:48:15 --> URI Class Initialized
INFO - 2018-03-21 22:48:15 --> Router Class Initialized
INFO - 2018-03-21 22:48:15 --> Output Class Initialized
INFO - 2018-03-21 22:48:15 --> Security Class Initialized
DEBUG - 2018-03-21 22:48:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:48:15 --> Input Class Initialized
INFO - 2018-03-21 22:48:15 --> Language Class Initialized
INFO - 2018-03-21 22:48:15 --> Loader Class Initialized
INFO - 2018-03-21 22:48:15 --> Helper loaded: url_helper
INFO - 2018-03-21 22:48:15 --> Helper loaded: form_helper
INFO - 2018-03-21 22:48:15 --> Database Driver Class Initialized
DEBUG - 2018-03-21 22:48:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 22:48:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 22:48:15 --> Form Validation Class Initialized
INFO - 2018-03-21 22:48:15 --> Model Class Initialized
INFO - 2018-03-21 22:48:15 --> Controller Class Initialized
INFO - 2018-03-21 22:48:15 --> Model Class Initialized
INFO - 2018-03-21 22:48:15 --> Model Class Initialized
INFO - 2018-03-21 22:48:15 --> Model Class Initialized
INFO - 2018-03-21 22:48:15 --> Model Class Initialized
DEBUG - 2018-03-21 22:48:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 22:48:15 --> Model Class Initialized
INFO - 2018-03-21 22:48:15 --> Final output sent to browser
DEBUG - 2018-03-21 22:48:15 --> Total execution time: 0.1625
INFO - 2018-03-21 22:53:05 --> Config Class Initialized
INFO - 2018-03-21 22:53:05 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:53:05 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:53:05 --> Utf8 Class Initialized
INFO - 2018-03-21 22:53:05 --> URI Class Initialized
INFO - 2018-03-21 22:53:05 --> Router Class Initialized
INFO - 2018-03-21 22:53:05 --> Output Class Initialized
INFO - 2018-03-21 22:53:05 --> Security Class Initialized
DEBUG - 2018-03-21 22:53:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:53:05 --> Input Class Initialized
INFO - 2018-03-21 22:53:05 --> Language Class Initialized
INFO - 2018-03-21 22:53:05 --> Loader Class Initialized
INFO - 2018-03-21 22:53:05 --> Helper loaded: url_helper
INFO - 2018-03-21 22:53:05 --> Helper loaded: form_helper
INFO - 2018-03-21 22:53:05 --> Database Driver Class Initialized
DEBUG - 2018-03-21 22:53:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 22:53:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 22:53:05 --> Form Validation Class Initialized
INFO - 2018-03-21 22:53:05 --> Model Class Initialized
INFO - 2018-03-21 22:53:05 --> Controller Class Initialized
INFO - 2018-03-21 22:53:05 --> Model Class Initialized
INFO - 2018-03-21 22:53:05 --> Model Class Initialized
INFO - 2018-03-21 22:53:05 --> Model Class Initialized
INFO - 2018-03-21 22:53:05 --> Model Class Initialized
DEBUG - 2018-03-21 22:53:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 22:53:07 --> Config Class Initialized
INFO - 2018-03-21 22:53:07 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:53:07 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:53:07 --> Utf8 Class Initialized
INFO - 2018-03-21 22:53:07 --> URI Class Initialized
INFO - 2018-03-21 22:53:07 --> Router Class Initialized
INFO - 2018-03-21 22:53:07 --> Output Class Initialized
INFO - 2018-03-21 22:53:07 --> Security Class Initialized
DEBUG - 2018-03-21 22:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:53:07 --> Input Class Initialized
INFO - 2018-03-21 22:53:07 --> Language Class Initialized
INFO - 2018-03-21 22:53:07 --> Loader Class Initialized
INFO - 2018-03-21 22:53:07 --> Helper loaded: url_helper
INFO - 2018-03-21 22:53:07 --> Helper loaded: form_helper
INFO - 2018-03-21 22:53:07 --> Database Driver Class Initialized
DEBUG - 2018-03-21 22:53:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 22:53:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 22:53:07 --> Form Validation Class Initialized
INFO - 2018-03-21 22:53:07 --> Model Class Initialized
INFO - 2018-03-21 22:53:07 --> Controller Class Initialized
INFO - 2018-03-21 22:53:07 --> Model Class Initialized
INFO - 2018-03-21 22:53:07 --> Model Class Initialized
INFO - 2018-03-21 22:53:07 --> Model Class Initialized
INFO - 2018-03-21 22:53:07 --> Model Class Initialized
DEBUG - 2018-03-21 22:53:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 22:53:07 --> Model Class Initialized
INFO - 2018-03-21 22:53:08 --> Final output sent to browser
DEBUG - 2018-03-21 22:53:08 --> Total execution time: 0.2451
INFO - 2018-03-21 22:53:50 --> Config Class Initialized
INFO - 2018-03-21 22:53:50 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:53:50 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:53:50 --> Utf8 Class Initialized
INFO - 2018-03-21 22:53:50 --> URI Class Initialized
INFO - 2018-03-21 22:53:50 --> Router Class Initialized
INFO - 2018-03-21 22:53:50 --> Output Class Initialized
INFO - 2018-03-21 22:53:50 --> Security Class Initialized
DEBUG - 2018-03-21 22:53:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:53:50 --> Input Class Initialized
INFO - 2018-03-21 22:53:50 --> Language Class Initialized
INFO - 2018-03-21 22:53:50 --> Loader Class Initialized
INFO - 2018-03-21 22:53:50 --> Helper loaded: url_helper
INFO - 2018-03-21 22:53:50 --> Helper loaded: form_helper
INFO - 2018-03-21 22:53:50 --> Database Driver Class Initialized
DEBUG - 2018-03-21 22:53:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 22:53:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 22:53:50 --> Form Validation Class Initialized
INFO - 2018-03-21 22:53:50 --> Model Class Initialized
INFO - 2018-03-21 22:53:50 --> Controller Class Initialized
INFO - 2018-03-21 22:53:50 --> Model Class Initialized
INFO - 2018-03-21 22:53:50 --> Model Class Initialized
INFO - 2018-03-21 22:53:50 --> Model Class Initialized
INFO - 2018-03-21 22:53:50 --> Model Class Initialized
DEBUG - 2018-03-21 22:53:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 22:53:50 --> Model Class Initialized
INFO - 2018-03-21 22:53:50 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-21 22:53:50 --> Final output sent to browser
DEBUG - 2018-03-21 22:53:50 --> Total execution time: 0.0813
INFO - 2018-03-21 22:53:50 --> Config Class Initialized
INFO - 2018-03-21 22:53:50 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:53:50 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:53:50 --> Utf8 Class Initialized
INFO - 2018-03-21 22:53:50 --> URI Class Initialized
INFO - 2018-03-21 22:53:50 --> Router Class Initialized
INFO - 2018-03-21 22:53:50 --> Output Class Initialized
INFO - 2018-03-21 22:53:50 --> Security Class Initialized
DEBUG - 2018-03-21 22:53:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:53:50 --> Input Class Initialized
INFO - 2018-03-21 22:53:50 --> Language Class Initialized
INFO - 2018-03-21 22:53:50 --> Loader Class Initialized
INFO - 2018-03-21 22:53:50 --> Helper loaded: url_helper
INFO - 2018-03-21 22:53:50 --> Helper loaded: form_helper
INFO - 2018-03-21 22:53:50 --> Database Driver Class Initialized
DEBUG - 2018-03-21 22:53:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 22:53:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 22:53:50 --> Form Validation Class Initialized
INFO - 2018-03-21 22:53:50 --> Model Class Initialized
INFO - 2018-03-21 22:53:50 --> Controller Class Initialized
INFO - 2018-03-21 22:53:50 --> Model Class Initialized
INFO - 2018-03-21 22:53:50 --> Model Class Initialized
DEBUG - 2018-03-21 22:53:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 22:53:52 --> Config Class Initialized
INFO - 2018-03-21 22:53:52 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:53:52 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:53:52 --> Utf8 Class Initialized
INFO - 2018-03-21 22:53:52 --> URI Class Initialized
INFO - 2018-03-21 22:53:52 --> Router Class Initialized
INFO - 2018-03-21 22:53:52 --> Output Class Initialized
INFO - 2018-03-21 22:53:52 --> Security Class Initialized
DEBUG - 2018-03-21 22:53:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:53:52 --> Input Class Initialized
INFO - 2018-03-21 22:53:52 --> Language Class Initialized
INFO - 2018-03-21 22:53:52 --> Loader Class Initialized
INFO - 2018-03-21 22:53:52 --> Helper loaded: url_helper
INFO - 2018-03-21 22:53:52 --> Helper loaded: form_helper
INFO - 2018-03-21 22:53:52 --> Database Driver Class Initialized
DEBUG - 2018-03-21 22:53:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 22:53:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 22:53:52 --> Form Validation Class Initialized
INFO - 2018-03-21 22:53:52 --> Model Class Initialized
INFO - 2018-03-21 22:53:52 --> Controller Class Initialized
INFO - 2018-03-21 22:53:52 --> Model Class Initialized
INFO - 2018-03-21 22:53:52 --> Model Class Initialized
INFO - 2018-03-21 22:53:52 --> Model Class Initialized
INFO - 2018-03-21 22:53:52 --> Model Class Initialized
DEBUG - 2018-03-21 22:53:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 22:53:52 --> Model Class Initialized
INFO - 2018-03-21 22:53:52 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-21 22:53:52 --> Final output sent to browser
DEBUG - 2018-03-21 22:53:52 --> Total execution time: 0.0658
INFO - 2018-03-21 22:53:53 --> Config Class Initialized
INFO - 2018-03-21 22:53:53 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:53:53 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:53:53 --> Utf8 Class Initialized
INFO - 2018-03-21 22:53:53 --> URI Class Initialized
INFO - 2018-03-21 22:53:53 --> Router Class Initialized
INFO - 2018-03-21 22:53:53 --> Output Class Initialized
INFO - 2018-03-21 22:53:53 --> Security Class Initialized
DEBUG - 2018-03-21 22:53:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:53:53 --> Input Class Initialized
INFO - 2018-03-21 22:53:53 --> Language Class Initialized
INFO - 2018-03-21 22:53:53 --> Loader Class Initialized
INFO - 2018-03-21 22:53:53 --> Helper loaded: url_helper
INFO - 2018-03-21 22:53:53 --> Helper loaded: form_helper
INFO - 2018-03-21 22:53:53 --> Database Driver Class Initialized
DEBUG - 2018-03-21 22:53:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 22:53:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 22:53:53 --> Form Validation Class Initialized
INFO - 2018-03-21 22:53:53 --> Model Class Initialized
INFO - 2018-03-21 22:53:53 --> Controller Class Initialized
INFO - 2018-03-21 22:53:53 --> Model Class Initialized
INFO - 2018-03-21 22:53:53 --> Model Class Initialized
INFO - 2018-03-21 22:53:53 --> Model Class Initialized
INFO - 2018-03-21 22:53:53 --> Model Class Initialized
DEBUG - 2018-03-21 22:53:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 22:53:54 --> Config Class Initialized
INFO - 2018-03-21 22:53:54 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:53:54 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:53:54 --> Utf8 Class Initialized
INFO - 2018-03-21 22:53:54 --> URI Class Initialized
INFO - 2018-03-21 22:53:54 --> Router Class Initialized
INFO - 2018-03-21 22:53:54 --> Output Class Initialized
INFO - 2018-03-21 22:53:54 --> Security Class Initialized
DEBUG - 2018-03-21 22:53:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:53:54 --> Input Class Initialized
INFO - 2018-03-21 22:53:54 --> Language Class Initialized
INFO - 2018-03-21 22:53:54 --> Loader Class Initialized
INFO - 2018-03-21 22:53:54 --> Helper loaded: url_helper
INFO - 2018-03-21 22:53:54 --> Helper loaded: form_helper
INFO - 2018-03-21 22:53:54 --> Database Driver Class Initialized
DEBUG - 2018-03-21 22:53:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 22:53:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 22:53:54 --> Form Validation Class Initialized
INFO - 2018-03-21 22:53:54 --> Model Class Initialized
INFO - 2018-03-21 22:53:54 --> Controller Class Initialized
INFO - 2018-03-21 22:53:54 --> Model Class Initialized
INFO - 2018-03-21 22:53:54 --> Model Class Initialized
INFO - 2018-03-21 22:53:54 --> Model Class Initialized
INFO - 2018-03-21 22:53:54 --> Model Class Initialized
DEBUG - 2018-03-21 22:53:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 22:53:54 --> Model Class Initialized
INFO - 2018-03-21 22:53:54 --> Final output sent to browser
DEBUG - 2018-03-21 22:53:54 --> Total execution time: 0.1670
INFO - 2018-03-21 22:55:22 --> Config Class Initialized
INFO - 2018-03-21 22:55:22 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:55:22 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:55:22 --> Utf8 Class Initialized
INFO - 2018-03-21 22:55:22 --> URI Class Initialized
INFO - 2018-03-21 22:55:22 --> Router Class Initialized
INFO - 2018-03-21 22:55:22 --> Output Class Initialized
INFO - 2018-03-21 22:55:22 --> Security Class Initialized
DEBUG - 2018-03-21 22:55:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:55:22 --> Input Class Initialized
INFO - 2018-03-21 22:55:22 --> Language Class Initialized
INFO - 2018-03-21 22:55:22 --> Loader Class Initialized
INFO - 2018-03-21 22:55:22 --> Helper loaded: url_helper
INFO - 2018-03-21 22:55:22 --> Helper loaded: form_helper
INFO - 2018-03-21 22:55:22 --> Database Driver Class Initialized
DEBUG - 2018-03-21 22:55:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 22:55:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 22:55:22 --> Form Validation Class Initialized
INFO - 2018-03-21 22:55:22 --> Model Class Initialized
INFO - 2018-03-21 22:55:22 --> Controller Class Initialized
INFO - 2018-03-21 22:55:22 --> Model Class Initialized
INFO - 2018-03-21 22:55:22 --> Model Class Initialized
INFO - 2018-03-21 22:55:22 --> Model Class Initialized
INFO - 2018-03-21 22:55:22 --> Model Class Initialized
DEBUG - 2018-03-21 22:55:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 22:55:22 --> Model Class Initialized
INFO - 2018-03-21 22:55:22 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-21 22:55:22 --> Final output sent to browser
DEBUG - 2018-03-21 22:55:22 --> Total execution time: 0.0561
INFO - 2018-03-21 22:55:23 --> Config Class Initialized
INFO - 2018-03-21 22:55:23 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:55:23 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:55:23 --> Utf8 Class Initialized
INFO - 2018-03-21 22:55:23 --> URI Class Initialized
INFO - 2018-03-21 22:55:23 --> Router Class Initialized
INFO - 2018-03-21 22:55:23 --> Output Class Initialized
INFO - 2018-03-21 22:55:23 --> Security Class Initialized
DEBUG - 2018-03-21 22:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:55:23 --> Input Class Initialized
INFO - 2018-03-21 22:55:23 --> Language Class Initialized
INFO - 2018-03-21 22:55:23 --> Loader Class Initialized
INFO - 2018-03-21 22:55:23 --> Helper loaded: url_helper
INFO - 2018-03-21 22:55:23 --> Helper loaded: form_helper
INFO - 2018-03-21 22:55:23 --> Database Driver Class Initialized
DEBUG - 2018-03-21 22:55:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 22:55:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 22:55:23 --> Form Validation Class Initialized
INFO - 2018-03-21 22:55:23 --> Model Class Initialized
INFO - 2018-03-21 22:55:23 --> Controller Class Initialized
INFO - 2018-03-21 22:55:23 --> Model Class Initialized
INFO - 2018-03-21 22:55:23 --> Model Class Initialized
INFO - 2018-03-21 22:55:23 --> Model Class Initialized
INFO - 2018-03-21 22:55:23 --> Model Class Initialized
DEBUG - 2018-03-21 22:55:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 22:55:29 --> Config Class Initialized
INFO - 2018-03-21 22:55:29 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:55:29 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:55:29 --> Utf8 Class Initialized
INFO - 2018-03-21 22:55:29 --> URI Class Initialized
INFO - 2018-03-21 22:55:29 --> Router Class Initialized
INFO - 2018-03-21 22:55:29 --> Output Class Initialized
INFO - 2018-03-21 22:55:29 --> Security Class Initialized
DEBUG - 2018-03-21 22:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:55:29 --> Input Class Initialized
INFO - 2018-03-21 22:55:29 --> Language Class Initialized
INFO - 2018-03-21 22:55:29 --> Loader Class Initialized
INFO - 2018-03-21 22:55:29 --> Helper loaded: url_helper
INFO - 2018-03-21 22:55:29 --> Helper loaded: form_helper
INFO - 2018-03-21 22:55:29 --> Database Driver Class Initialized
DEBUG - 2018-03-21 22:55:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 22:55:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 22:55:29 --> Form Validation Class Initialized
INFO - 2018-03-21 22:55:29 --> Model Class Initialized
INFO - 2018-03-21 22:55:29 --> Controller Class Initialized
INFO - 2018-03-21 22:55:29 --> Model Class Initialized
INFO - 2018-03-21 22:55:29 --> Model Class Initialized
INFO - 2018-03-21 22:55:29 --> Model Class Initialized
INFO - 2018-03-21 22:55:29 --> Model Class Initialized
DEBUG - 2018-03-21 22:55:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 22:55:29 --> Model Class Initialized
INFO - 2018-03-21 22:55:29 --> Final output sent to browser
DEBUG - 2018-03-21 22:55:29 --> Total execution time: 0.2331
INFO - 2018-03-21 22:57:01 --> Config Class Initialized
INFO - 2018-03-21 22:57:01 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:57:01 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:57:01 --> Utf8 Class Initialized
INFO - 2018-03-21 22:57:01 --> URI Class Initialized
INFO - 2018-03-21 22:57:01 --> Router Class Initialized
INFO - 2018-03-21 22:57:01 --> Output Class Initialized
INFO - 2018-03-21 22:57:01 --> Security Class Initialized
DEBUG - 2018-03-21 22:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:57:01 --> Input Class Initialized
INFO - 2018-03-21 22:57:01 --> Language Class Initialized
INFO - 2018-03-21 22:57:01 --> Loader Class Initialized
INFO - 2018-03-21 22:57:01 --> Helper loaded: url_helper
INFO - 2018-03-21 22:57:01 --> Helper loaded: form_helper
INFO - 2018-03-21 22:57:01 --> Database Driver Class Initialized
DEBUG - 2018-03-21 22:57:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 22:57:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 22:57:01 --> Form Validation Class Initialized
INFO - 2018-03-21 22:57:01 --> Model Class Initialized
INFO - 2018-03-21 22:57:01 --> Controller Class Initialized
INFO - 2018-03-21 22:57:01 --> Model Class Initialized
INFO - 2018-03-21 22:57:01 --> Model Class Initialized
INFO - 2018-03-21 22:57:01 --> Model Class Initialized
INFO - 2018-03-21 22:57:01 --> Model Class Initialized
DEBUG - 2018-03-21 22:57:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 22:57:01 --> Model Class Initialized
INFO - 2018-03-21 22:57:01 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-21 22:57:01 --> Final output sent to browser
DEBUG - 2018-03-21 22:57:01 --> Total execution time: 0.0574
INFO - 2018-03-21 22:57:01 --> Config Class Initialized
INFO - 2018-03-21 22:57:01 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:57:01 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:57:01 --> Utf8 Class Initialized
INFO - 2018-03-21 22:57:01 --> URI Class Initialized
INFO - 2018-03-21 22:57:01 --> Router Class Initialized
INFO - 2018-03-21 22:57:01 --> Output Class Initialized
INFO - 2018-03-21 22:57:01 --> Security Class Initialized
DEBUG - 2018-03-21 22:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:57:01 --> Input Class Initialized
INFO - 2018-03-21 22:57:01 --> Language Class Initialized
INFO - 2018-03-21 22:57:01 --> Loader Class Initialized
INFO - 2018-03-21 22:57:01 --> Helper loaded: url_helper
INFO - 2018-03-21 22:57:01 --> Helper loaded: form_helper
INFO - 2018-03-21 22:57:01 --> Database Driver Class Initialized
DEBUG - 2018-03-21 22:57:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 22:57:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 22:57:01 --> Form Validation Class Initialized
INFO - 2018-03-21 22:57:01 --> Model Class Initialized
INFO - 2018-03-21 22:57:01 --> Controller Class Initialized
INFO - 2018-03-21 22:57:01 --> Model Class Initialized
INFO - 2018-03-21 22:57:01 --> Model Class Initialized
DEBUG - 2018-03-21 22:57:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 22:57:03 --> Config Class Initialized
INFO - 2018-03-21 22:57:03 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:57:03 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:57:03 --> Utf8 Class Initialized
INFO - 2018-03-21 22:57:03 --> URI Class Initialized
INFO - 2018-03-21 22:57:03 --> Router Class Initialized
INFO - 2018-03-21 22:57:03 --> Output Class Initialized
INFO - 2018-03-21 22:57:03 --> Security Class Initialized
DEBUG - 2018-03-21 22:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:57:03 --> Input Class Initialized
INFO - 2018-03-21 22:57:03 --> Language Class Initialized
INFO - 2018-03-21 22:57:03 --> Loader Class Initialized
INFO - 2018-03-21 22:57:03 --> Helper loaded: url_helper
INFO - 2018-03-21 22:57:03 --> Helper loaded: form_helper
INFO - 2018-03-21 22:57:03 --> Database Driver Class Initialized
DEBUG - 2018-03-21 22:57:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 22:57:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 22:57:03 --> Form Validation Class Initialized
INFO - 2018-03-21 22:57:03 --> Model Class Initialized
INFO - 2018-03-21 22:57:03 --> Controller Class Initialized
INFO - 2018-03-21 22:57:03 --> Model Class Initialized
INFO - 2018-03-21 22:57:03 --> Model Class Initialized
INFO - 2018-03-21 22:57:03 --> Model Class Initialized
INFO - 2018-03-21 22:57:03 --> Model Class Initialized
DEBUG - 2018-03-21 22:57:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 22:57:03 --> Model Class Initialized
INFO - 2018-03-21 22:57:03 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-21 22:57:03 --> Final output sent to browser
DEBUG - 2018-03-21 22:57:03 --> Total execution time: 0.0584
INFO - 2018-03-21 22:57:03 --> Config Class Initialized
INFO - 2018-03-21 22:57:03 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:57:03 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:57:03 --> Utf8 Class Initialized
INFO - 2018-03-21 22:57:03 --> URI Class Initialized
INFO - 2018-03-21 22:57:03 --> Router Class Initialized
INFO - 2018-03-21 22:57:03 --> Output Class Initialized
INFO - 2018-03-21 22:57:03 --> Security Class Initialized
DEBUG - 2018-03-21 22:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:57:03 --> Input Class Initialized
INFO - 2018-03-21 22:57:03 --> Language Class Initialized
INFO - 2018-03-21 22:57:03 --> Loader Class Initialized
INFO - 2018-03-21 22:57:03 --> Helper loaded: url_helper
INFO - 2018-03-21 22:57:03 --> Helper loaded: form_helper
INFO - 2018-03-21 22:57:03 --> Database Driver Class Initialized
DEBUG - 2018-03-21 22:57:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 22:57:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 22:57:03 --> Form Validation Class Initialized
INFO - 2018-03-21 22:57:03 --> Model Class Initialized
INFO - 2018-03-21 22:57:03 --> Controller Class Initialized
INFO - 2018-03-21 22:57:03 --> Model Class Initialized
INFO - 2018-03-21 22:57:03 --> Model Class Initialized
INFO - 2018-03-21 22:57:03 --> Model Class Initialized
INFO - 2018-03-21 22:57:03 --> Model Class Initialized
DEBUG - 2018-03-21 22:57:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 22:57:06 --> Config Class Initialized
INFO - 2018-03-21 22:57:06 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:57:06 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:57:06 --> Utf8 Class Initialized
INFO - 2018-03-21 22:57:06 --> URI Class Initialized
INFO - 2018-03-21 22:57:06 --> Router Class Initialized
INFO - 2018-03-21 22:57:06 --> Output Class Initialized
INFO - 2018-03-21 22:57:06 --> Security Class Initialized
DEBUG - 2018-03-21 22:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:57:06 --> Input Class Initialized
INFO - 2018-03-21 22:57:06 --> Language Class Initialized
INFO - 2018-03-21 22:57:06 --> Loader Class Initialized
INFO - 2018-03-21 22:57:06 --> Helper loaded: url_helper
INFO - 2018-03-21 22:57:06 --> Helper loaded: form_helper
INFO - 2018-03-21 22:57:06 --> Database Driver Class Initialized
DEBUG - 2018-03-21 22:57:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 22:57:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 22:57:06 --> Form Validation Class Initialized
INFO - 2018-03-21 22:57:06 --> Model Class Initialized
INFO - 2018-03-21 22:57:06 --> Controller Class Initialized
INFO - 2018-03-21 22:57:06 --> Model Class Initialized
INFO - 2018-03-21 22:57:06 --> Model Class Initialized
INFO - 2018-03-21 22:57:06 --> Model Class Initialized
INFO - 2018-03-21 22:57:06 --> Model Class Initialized
DEBUG - 2018-03-21 22:57:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 22:57:06 --> Model Class Initialized
INFO - 2018-03-21 22:57:06 --> Final output sent to browser
DEBUG - 2018-03-21 22:57:06 --> Total execution time: 0.1730
INFO - 2018-03-21 22:57:23 --> Config Class Initialized
INFO - 2018-03-21 22:57:23 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:57:23 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:57:23 --> Utf8 Class Initialized
INFO - 2018-03-21 22:57:23 --> URI Class Initialized
INFO - 2018-03-21 22:57:23 --> Router Class Initialized
INFO - 2018-03-21 22:57:23 --> Output Class Initialized
INFO - 2018-03-21 22:57:23 --> Security Class Initialized
DEBUG - 2018-03-21 22:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:57:23 --> Input Class Initialized
INFO - 2018-03-21 22:57:23 --> Language Class Initialized
INFO - 2018-03-21 22:57:23 --> Loader Class Initialized
INFO - 2018-03-21 22:57:23 --> Helper loaded: url_helper
INFO - 2018-03-21 22:57:23 --> Helper loaded: form_helper
INFO - 2018-03-21 22:57:23 --> Database Driver Class Initialized
DEBUG - 2018-03-21 22:57:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 22:57:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 22:57:23 --> Form Validation Class Initialized
INFO - 2018-03-21 22:57:23 --> Model Class Initialized
INFO - 2018-03-21 22:57:23 --> Controller Class Initialized
INFO - 2018-03-21 22:57:23 --> Model Class Initialized
INFO - 2018-03-21 22:57:23 --> Model Class Initialized
INFO - 2018-03-21 22:57:23 --> Model Class Initialized
INFO - 2018-03-21 22:57:23 --> Model Class Initialized
DEBUG - 2018-03-21 22:57:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 22:57:23 --> Model Class Initialized
INFO - 2018-03-21 22:57:23 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-21 22:57:23 --> Final output sent to browser
DEBUG - 2018-03-21 22:57:23 --> Total execution time: 0.0618
INFO - 2018-03-21 22:57:24 --> Config Class Initialized
INFO - 2018-03-21 22:57:24 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:57:24 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:57:24 --> Utf8 Class Initialized
INFO - 2018-03-21 22:57:24 --> URI Class Initialized
INFO - 2018-03-21 22:57:24 --> Router Class Initialized
INFO - 2018-03-21 22:57:24 --> Output Class Initialized
INFO - 2018-03-21 22:57:24 --> Security Class Initialized
DEBUG - 2018-03-21 22:57:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:57:24 --> Input Class Initialized
INFO - 2018-03-21 22:57:24 --> Language Class Initialized
INFO - 2018-03-21 22:57:24 --> Loader Class Initialized
INFO - 2018-03-21 22:57:24 --> Helper loaded: url_helper
INFO - 2018-03-21 22:57:24 --> Helper loaded: form_helper
INFO - 2018-03-21 22:57:24 --> Database Driver Class Initialized
DEBUG - 2018-03-21 22:57:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 22:57:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 22:57:24 --> Form Validation Class Initialized
INFO - 2018-03-21 22:57:24 --> Model Class Initialized
INFO - 2018-03-21 22:57:24 --> Controller Class Initialized
INFO - 2018-03-21 22:57:24 --> Model Class Initialized
INFO - 2018-03-21 22:57:24 --> Model Class Initialized
DEBUG - 2018-03-21 22:57:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 22:57:26 --> Config Class Initialized
INFO - 2018-03-21 22:57:26 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:57:26 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:57:26 --> Utf8 Class Initialized
INFO - 2018-03-21 22:57:26 --> URI Class Initialized
INFO - 2018-03-21 22:57:26 --> Router Class Initialized
INFO - 2018-03-21 22:57:26 --> Output Class Initialized
INFO - 2018-03-21 22:57:26 --> Security Class Initialized
DEBUG - 2018-03-21 22:57:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:57:26 --> Input Class Initialized
INFO - 2018-03-21 22:57:26 --> Language Class Initialized
INFO - 2018-03-21 22:57:26 --> Loader Class Initialized
INFO - 2018-03-21 22:57:26 --> Helper loaded: url_helper
INFO - 2018-03-21 22:57:26 --> Helper loaded: form_helper
INFO - 2018-03-21 22:57:26 --> Database Driver Class Initialized
DEBUG - 2018-03-21 22:57:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 22:57:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 22:57:26 --> Form Validation Class Initialized
INFO - 2018-03-21 22:57:26 --> Model Class Initialized
INFO - 2018-03-21 22:57:26 --> Controller Class Initialized
INFO - 2018-03-21 22:57:26 --> Model Class Initialized
INFO - 2018-03-21 22:57:26 --> Model Class Initialized
INFO - 2018-03-21 22:57:26 --> Model Class Initialized
INFO - 2018-03-21 22:57:26 --> Model Class Initialized
DEBUG - 2018-03-21 22:57:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 22:57:26 --> Model Class Initialized
INFO - 2018-03-21 22:57:26 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-21 22:57:26 --> Final output sent to browser
DEBUG - 2018-03-21 22:57:26 --> Total execution time: 0.0606
INFO - 2018-03-21 22:57:26 --> Config Class Initialized
INFO - 2018-03-21 22:57:26 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:57:26 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:57:26 --> Utf8 Class Initialized
INFO - 2018-03-21 22:57:26 --> URI Class Initialized
INFO - 2018-03-21 22:57:26 --> Router Class Initialized
INFO - 2018-03-21 22:57:26 --> Output Class Initialized
INFO - 2018-03-21 22:57:26 --> Security Class Initialized
DEBUG - 2018-03-21 22:57:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:57:26 --> Input Class Initialized
INFO - 2018-03-21 22:57:26 --> Language Class Initialized
INFO - 2018-03-21 22:57:26 --> Loader Class Initialized
INFO - 2018-03-21 22:57:26 --> Helper loaded: url_helper
INFO - 2018-03-21 22:57:26 --> Helper loaded: form_helper
INFO - 2018-03-21 22:57:26 --> Database Driver Class Initialized
DEBUG - 2018-03-21 22:57:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 22:57:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 22:57:26 --> Form Validation Class Initialized
INFO - 2018-03-21 22:57:26 --> Model Class Initialized
INFO - 2018-03-21 22:57:26 --> Controller Class Initialized
INFO - 2018-03-21 22:57:26 --> Model Class Initialized
INFO - 2018-03-21 22:57:26 --> Model Class Initialized
INFO - 2018-03-21 22:57:26 --> Model Class Initialized
INFO - 2018-03-21 22:57:26 --> Model Class Initialized
DEBUG - 2018-03-21 22:57:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 22:57:29 --> Config Class Initialized
INFO - 2018-03-21 22:57:29 --> Hooks Class Initialized
DEBUG - 2018-03-21 22:57:29 --> UTF-8 Support Enabled
INFO - 2018-03-21 22:57:29 --> Utf8 Class Initialized
INFO - 2018-03-21 22:57:29 --> URI Class Initialized
INFO - 2018-03-21 22:57:29 --> Router Class Initialized
INFO - 2018-03-21 22:57:29 --> Output Class Initialized
INFO - 2018-03-21 22:57:29 --> Security Class Initialized
DEBUG - 2018-03-21 22:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 22:57:29 --> Input Class Initialized
INFO - 2018-03-21 22:57:29 --> Language Class Initialized
INFO - 2018-03-21 22:57:29 --> Loader Class Initialized
INFO - 2018-03-21 22:57:29 --> Helper loaded: url_helper
INFO - 2018-03-21 22:57:29 --> Helper loaded: form_helper
INFO - 2018-03-21 22:57:29 --> Database Driver Class Initialized
DEBUG - 2018-03-21 22:57:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 22:57:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 22:57:29 --> Form Validation Class Initialized
INFO - 2018-03-21 22:57:29 --> Model Class Initialized
INFO - 2018-03-21 22:57:29 --> Controller Class Initialized
INFO - 2018-03-21 22:57:29 --> Model Class Initialized
INFO - 2018-03-21 22:57:29 --> Model Class Initialized
INFO - 2018-03-21 22:57:29 --> Model Class Initialized
INFO - 2018-03-21 22:57:29 --> Model Class Initialized
DEBUG - 2018-03-21 22:57:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-21 22:57:29 --> Model Class Initialized
INFO - 2018-03-21 22:57:29 --> Final output sent to browser
DEBUG - 2018-03-21 22:57:29 --> Total execution time: 0.2490
