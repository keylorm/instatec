<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-03-12 00:01:00 --> Config Class Initialized
INFO - 2018-03-12 00:01:00 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:01:00 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:01:00 --> Utf8 Class Initialized
INFO - 2018-03-12 00:01:00 --> URI Class Initialized
INFO - 2018-03-12 00:01:00 --> Router Class Initialized
INFO - 2018-03-12 00:01:00 --> Output Class Initialized
INFO - 2018-03-12 00:01:00 --> Security Class Initialized
DEBUG - 2018-03-12 00:01:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:01:00 --> Input Class Initialized
INFO - 2018-03-12 00:01:00 --> Language Class Initialized
INFO - 2018-03-12 00:01:00 --> Loader Class Initialized
INFO - 2018-03-12 00:01:00 --> Helper loaded: url_helper
INFO - 2018-03-12 00:01:00 --> Helper loaded: form_helper
INFO - 2018-03-12 00:01:00 --> Database Driver Class Initialized
DEBUG - 2018-03-12 00:01:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 00:01:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 00:01:00 --> Form Validation Class Initialized
INFO - 2018-03-12 00:01:00 --> Model Class Initialized
INFO - 2018-03-12 00:01:00 --> Controller Class Initialized
INFO - 2018-03-12 00:01:00 --> Model Class Initialized
INFO - 2018-03-12 00:01:00 --> Model Class Initialized
INFO - 2018-03-12 00:01:00 --> Model Class Initialized
INFO - 2018-03-12 00:01:00 --> Model Class Initialized
INFO - 2018-03-12 00:01:00 --> Model Class Initialized
DEBUG - 2018-03-12 00:01:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-12 00:01:00 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-12 00:01:00 --> Final output sent to browser
DEBUG - 2018-03-12 00:01:00 --> Total execution time: 0.0774
INFO - 2018-03-12 00:01:00 --> Config Class Initialized
INFO - 2018-03-12 00:01:00 --> Config Class Initialized
INFO - 2018-03-12 00:01:00 --> Hooks Class Initialized
INFO - 2018-03-12 00:01:00 --> Hooks Class Initialized
INFO - 2018-03-12 00:01:00 --> Config Class Initialized
INFO - 2018-03-12 00:01:00 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:01:00 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 00:01:00 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:01:00 --> Utf8 Class Initialized
INFO - 2018-03-12 00:01:00 --> Utf8 Class Initialized
INFO - 2018-03-12 00:01:00 --> URI Class Initialized
DEBUG - 2018-03-12 00:01:00 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:01:00 --> URI Class Initialized
INFO - 2018-03-12 00:01:00 --> Config Class Initialized
INFO - 2018-03-12 00:01:00 --> Utf8 Class Initialized
INFO - 2018-03-12 00:01:00 --> Hooks Class Initialized
INFO - 2018-03-12 00:01:00 --> Router Class Initialized
INFO - 2018-03-12 00:01:00 --> URI Class Initialized
INFO - 2018-03-12 00:01:00 --> Router Class Initialized
INFO - 2018-03-12 00:01:00 --> Output Class Initialized
INFO - 2018-03-12 00:01:00 --> Router Class Initialized
DEBUG - 2018-03-12 00:01:00 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:01:00 --> Utf8 Class Initialized
INFO - 2018-03-12 00:01:00 --> Output Class Initialized
INFO - 2018-03-12 00:01:00 --> Security Class Initialized
INFO - 2018-03-12 00:01:00 --> URI Class Initialized
INFO - 2018-03-12 00:01:00 --> Output Class Initialized
INFO - 2018-03-12 00:01:00 --> Security Class Initialized
DEBUG - 2018-03-12 00:01:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:01:00 --> Input Class Initialized
INFO - 2018-03-12 00:01:00 --> Router Class Initialized
INFO - 2018-03-12 00:01:00 --> Security Class Initialized
INFO - 2018-03-12 00:01:00 --> Language Class Initialized
DEBUG - 2018-03-12 00:01:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:01:00 --> Input Class Initialized
DEBUG - 2018-03-12 00:01:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:01:00 --> Language Class Initialized
ERROR - 2018-03-12 00:01:00 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-12 00:01:00 --> Output Class Initialized
INFO - 2018-03-12 00:01:00 --> Input Class Initialized
ERROR - 2018-03-12 00:01:00 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-12 00:01:00 --> Language Class Initialized
INFO - 2018-03-12 00:01:00 --> Security Class Initialized
ERROR - 2018-03-12 00:01:00 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-12 00:01:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:01:00 --> Input Class Initialized
INFO - 2018-03-12 00:01:00 --> Language Class Initialized
ERROR - 2018-03-12 00:01:00 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-12 00:01:00 --> Config Class Initialized
INFO - 2018-03-12 00:01:00 --> Hooks Class Initialized
INFO - 2018-03-12 00:01:00 --> Config Class Initialized
INFO - 2018-03-12 00:01:00 --> Hooks Class Initialized
INFO - 2018-03-12 00:01:00 --> Config Class Initialized
INFO - 2018-03-12 00:01:00 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:01:00 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:01:00 --> Utf8 Class Initialized
INFO - 2018-03-12 00:01:00 --> URI Class Initialized
DEBUG - 2018-03-12 00:01:00 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:01:00 --> Utf8 Class Initialized
DEBUG - 2018-03-12 00:01:00 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:01:00 --> Utf8 Class Initialized
INFO - 2018-03-12 00:01:00 --> Router Class Initialized
INFO - 2018-03-12 00:01:00 --> URI Class Initialized
INFO - 2018-03-12 00:01:00 --> URI Class Initialized
INFO - 2018-03-12 00:01:00 --> Output Class Initialized
INFO - 2018-03-12 00:01:00 --> Router Class Initialized
INFO - 2018-03-12 00:01:00 --> Router Class Initialized
INFO - 2018-03-12 00:01:00 --> Security Class Initialized
INFO - 2018-03-12 00:01:00 --> Output Class Initialized
INFO - 2018-03-12 00:01:00 --> Output Class Initialized
DEBUG - 2018-03-12 00:01:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:01:00 --> Security Class Initialized
INFO - 2018-03-12 00:01:00 --> Input Class Initialized
INFO - 2018-03-12 00:01:00 --> Security Class Initialized
DEBUG - 2018-03-12 00:01:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:01:00 --> Language Class Initialized
INFO - 2018-03-12 00:01:00 --> Input Class Initialized
DEBUG - 2018-03-12 00:01:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:01:00 --> Input Class Initialized
INFO - 2018-03-12 00:01:00 --> Language Class Initialized
INFO - 2018-03-12 00:01:00 --> Language Class Initialized
ERROR - 2018-03-12 00:01:00 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-12 00:01:00 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-12 00:01:00 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-12 00:01:00 --> Config Class Initialized
INFO - 2018-03-12 00:01:00 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:01:00 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:01:00 --> Utf8 Class Initialized
INFO - 2018-03-12 00:01:00 --> URI Class Initialized
INFO - 2018-03-12 00:01:00 --> Router Class Initialized
INFO - 2018-03-12 00:01:00 --> Output Class Initialized
INFO - 2018-03-12 00:01:00 --> Security Class Initialized
DEBUG - 2018-03-12 00:01:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:01:00 --> Input Class Initialized
INFO - 2018-03-12 00:01:00 --> Language Class Initialized
INFO - 2018-03-12 00:01:00 --> Loader Class Initialized
INFO - 2018-03-12 00:01:00 --> Helper loaded: url_helper
INFO - 2018-03-12 00:01:00 --> Helper loaded: form_helper
INFO - 2018-03-12 00:01:00 --> Database Driver Class Initialized
DEBUG - 2018-03-12 00:01:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 00:01:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 00:01:00 --> Form Validation Class Initialized
INFO - 2018-03-12 00:01:00 --> Model Class Initialized
INFO - 2018-03-12 00:01:00 --> Controller Class Initialized
INFO - 2018-03-12 00:01:00 --> Model Class Initialized
INFO - 2018-03-12 00:01:00 --> Model Class Initialized
INFO - 2018-03-12 00:01:00 --> Model Class Initialized
INFO - 2018-03-12 00:01:00 --> Model Class Initialized
INFO - 2018-03-12 00:01:00 --> Model Class Initialized
DEBUG - 2018-03-12 00:01:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-12 00:01:17 --> Config Class Initialized
INFO - 2018-03-12 00:01:17 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:01:17 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:01:17 --> Utf8 Class Initialized
INFO - 2018-03-12 00:01:17 --> URI Class Initialized
INFO - 2018-03-12 00:01:17 --> Router Class Initialized
INFO - 2018-03-12 00:01:17 --> Output Class Initialized
INFO - 2018-03-12 00:01:17 --> Security Class Initialized
DEBUG - 2018-03-12 00:01:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:01:17 --> Input Class Initialized
INFO - 2018-03-12 00:01:17 --> Language Class Initialized
INFO - 2018-03-12 00:01:18 --> Loader Class Initialized
INFO - 2018-03-12 00:01:18 --> Helper loaded: url_helper
INFO - 2018-03-12 00:01:18 --> Helper loaded: form_helper
INFO - 2018-03-12 00:01:18 --> Database Driver Class Initialized
DEBUG - 2018-03-12 00:01:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 00:01:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 00:01:18 --> Form Validation Class Initialized
INFO - 2018-03-12 00:01:18 --> Model Class Initialized
INFO - 2018-03-12 00:01:18 --> Controller Class Initialized
INFO - 2018-03-12 00:01:18 --> Model Class Initialized
INFO - 2018-03-12 00:01:18 --> Model Class Initialized
INFO - 2018-03-12 00:01:18 --> Model Class Initialized
INFO - 2018-03-12 00:01:18 --> Model Class Initialized
INFO - 2018-03-12 00:01:18 --> Model Class Initialized
DEBUG - 2018-03-12 00:01:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-12 00:01:18 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-12 00:01:18 --> Final output sent to browser
DEBUG - 2018-03-12 00:01:18 --> Total execution time: 0.0481
INFO - 2018-03-12 00:01:18 --> Config Class Initialized
INFO - 2018-03-12 00:01:18 --> Config Class Initialized
INFO - 2018-03-12 00:01:18 --> Hooks Class Initialized
INFO - 2018-03-12 00:01:18 --> Hooks Class Initialized
INFO - 2018-03-12 00:01:18 --> Config Class Initialized
INFO - 2018-03-12 00:01:18 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:01:18 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 00:01:18 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:01:18 --> Utf8 Class Initialized
INFO - 2018-03-12 00:01:18 --> Utf8 Class Initialized
INFO - 2018-03-12 00:01:18 --> URI Class Initialized
INFO - 2018-03-12 00:01:18 --> URI Class Initialized
DEBUG - 2018-03-12 00:01:18 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:01:18 --> Router Class Initialized
INFO - 2018-03-12 00:01:18 --> Utf8 Class Initialized
INFO - 2018-03-12 00:01:18 --> Router Class Initialized
INFO - 2018-03-12 00:01:18 --> Config Class Initialized
INFO - 2018-03-12 00:01:18 --> Hooks Class Initialized
INFO - 2018-03-12 00:01:18 --> URI Class Initialized
INFO - 2018-03-12 00:01:18 --> Output Class Initialized
INFO - 2018-03-12 00:01:18 --> Output Class Initialized
INFO - 2018-03-12 00:01:18 --> Security Class Initialized
INFO - 2018-03-12 00:01:18 --> Router Class Initialized
INFO - 2018-03-12 00:01:18 --> Security Class Initialized
DEBUG - 2018-03-12 00:01:18 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:01:18 --> Utf8 Class Initialized
DEBUG - 2018-03-12 00:01:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:01:18 --> Input Class Initialized
INFO - 2018-03-12 00:01:18 --> Output Class Initialized
DEBUG - 2018-03-12 00:01:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:01:18 --> URI Class Initialized
INFO - 2018-03-12 00:01:18 --> Input Class Initialized
INFO - 2018-03-12 00:01:18 --> Language Class Initialized
INFO - 2018-03-12 00:01:18 --> Language Class Initialized
INFO - 2018-03-12 00:01:18 --> Security Class Initialized
ERROR - 2018-03-12 00:01:18 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-12 00:01:18 --> Router Class Initialized
ERROR - 2018-03-12 00:01:18 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-12 00:01:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:01:18 --> Input Class Initialized
INFO - 2018-03-12 00:01:18 --> Output Class Initialized
INFO - 2018-03-12 00:01:18 --> Language Class Initialized
ERROR - 2018-03-12 00:01:18 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-12 00:01:18 --> Security Class Initialized
DEBUG - 2018-03-12 00:01:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:01:18 --> Input Class Initialized
INFO - 2018-03-12 00:01:18 --> Language Class Initialized
ERROR - 2018-03-12 00:01:18 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-12 00:01:18 --> Config Class Initialized
INFO - 2018-03-12 00:01:18 --> Config Class Initialized
INFO - 2018-03-12 00:01:18 --> Hooks Class Initialized
INFO - 2018-03-12 00:01:18 --> Hooks Class Initialized
INFO - 2018-03-12 00:01:18 --> Config Class Initialized
INFO - 2018-03-12 00:01:18 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:01:18 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:01:18 --> Utf8 Class Initialized
DEBUG - 2018-03-12 00:01:18 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 00:01:18 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:01:18 --> Utf8 Class Initialized
INFO - 2018-03-12 00:01:18 --> Utf8 Class Initialized
INFO - 2018-03-12 00:01:18 --> URI Class Initialized
INFO - 2018-03-12 00:01:18 --> URI Class Initialized
INFO - 2018-03-12 00:01:18 --> URI Class Initialized
INFO - 2018-03-12 00:01:18 --> Router Class Initialized
INFO - 2018-03-12 00:01:18 --> Router Class Initialized
INFO - 2018-03-12 00:01:18 --> Router Class Initialized
INFO - 2018-03-12 00:01:18 --> Output Class Initialized
INFO - 2018-03-12 00:01:18 --> Output Class Initialized
INFO - 2018-03-12 00:01:18 --> Output Class Initialized
INFO - 2018-03-12 00:01:18 --> Security Class Initialized
INFO - 2018-03-12 00:01:18 --> Security Class Initialized
INFO - 2018-03-12 00:01:18 --> Security Class Initialized
DEBUG - 2018-03-12 00:01:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:01:18 --> Input Class Initialized
DEBUG - 2018-03-12 00:01:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:01:18 --> Input Class Initialized
DEBUG - 2018-03-12 00:01:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:01:18 --> Language Class Initialized
INFO - 2018-03-12 00:01:18 --> Input Class Initialized
INFO - 2018-03-12 00:01:18 --> Language Class Initialized
INFO - 2018-03-12 00:01:18 --> Language Class Initialized
ERROR - 2018-03-12 00:01:18 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-12 00:01:18 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-12 00:01:18 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-12 00:01:18 --> Config Class Initialized
INFO - 2018-03-12 00:01:18 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:01:18 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:01:18 --> Utf8 Class Initialized
INFO - 2018-03-12 00:01:18 --> URI Class Initialized
INFO - 2018-03-12 00:01:18 --> Router Class Initialized
INFO - 2018-03-12 00:01:18 --> Output Class Initialized
INFO - 2018-03-12 00:01:18 --> Security Class Initialized
DEBUG - 2018-03-12 00:01:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:01:18 --> Input Class Initialized
INFO - 2018-03-12 00:01:18 --> Language Class Initialized
INFO - 2018-03-12 00:01:18 --> Loader Class Initialized
INFO - 2018-03-12 00:01:18 --> Helper loaded: url_helper
INFO - 2018-03-12 00:01:18 --> Helper loaded: form_helper
INFO - 2018-03-12 00:01:18 --> Database Driver Class Initialized
DEBUG - 2018-03-12 00:01:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 00:01:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 00:01:18 --> Form Validation Class Initialized
INFO - 2018-03-12 00:01:18 --> Model Class Initialized
INFO - 2018-03-12 00:01:18 --> Controller Class Initialized
INFO - 2018-03-12 00:01:18 --> Model Class Initialized
INFO - 2018-03-12 00:01:18 --> Model Class Initialized
INFO - 2018-03-12 00:01:18 --> Model Class Initialized
INFO - 2018-03-12 00:01:18 --> Model Class Initialized
INFO - 2018-03-12 00:01:18 --> Model Class Initialized
DEBUG - 2018-03-12 00:01:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-12 00:01:30 --> Config Class Initialized
INFO - 2018-03-12 00:01:30 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:01:30 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:01:30 --> Utf8 Class Initialized
INFO - 2018-03-12 00:01:30 --> URI Class Initialized
INFO - 2018-03-12 00:01:30 --> Router Class Initialized
INFO - 2018-03-12 00:01:30 --> Output Class Initialized
INFO - 2018-03-12 00:01:30 --> Security Class Initialized
DEBUG - 2018-03-12 00:01:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:01:30 --> Input Class Initialized
INFO - 2018-03-12 00:01:30 --> Language Class Initialized
INFO - 2018-03-12 00:01:30 --> Loader Class Initialized
INFO - 2018-03-12 00:01:30 --> Helper loaded: url_helper
INFO - 2018-03-12 00:01:30 --> Helper loaded: form_helper
INFO - 2018-03-12 00:01:30 --> Database Driver Class Initialized
DEBUG - 2018-03-12 00:01:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 00:01:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 00:01:30 --> Form Validation Class Initialized
INFO - 2018-03-12 00:01:30 --> Model Class Initialized
INFO - 2018-03-12 00:01:30 --> Controller Class Initialized
INFO - 2018-03-12 00:01:30 --> Model Class Initialized
INFO - 2018-03-12 00:01:30 --> Model Class Initialized
INFO - 2018-03-12 00:01:30 --> Model Class Initialized
INFO - 2018-03-12 00:01:30 --> Model Class Initialized
INFO - 2018-03-12 00:01:30 --> Model Class Initialized
DEBUG - 2018-03-12 00:01:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-12 00:01:30 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-12 00:01:30 --> Final output sent to browser
DEBUG - 2018-03-12 00:01:30 --> Total execution time: 0.0525
INFO - 2018-03-12 00:01:30 --> Config Class Initialized
INFO - 2018-03-12 00:01:30 --> Hooks Class Initialized
INFO - 2018-03-12 00:01:30 --> Config Class Initialized
INFO - 2018-03-12 00:01:30 --> Hooks Class Initialized
INFO - 2018-03-12 00:01:30 --> Config Class Initialized
INFO - 2018-03-12 00:01:30 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:01:30 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:01:30 --> Utf8 Class Initialized
DEBUG - 2018-03-12 00:01:30 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:01:30 --> Utf8 Class Initialized
DEBUG - 2018-03-12 00:01:30 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:01:30 --> Utf8 Class Initialized
INFO - 2018-03-12 00:01:30 --> URI Class Initialized
INFO - 2018-03-12 00:01:30 --> URI Class Initialized
INFO - 2018-03-12 00:01:30 --> URI Class Initialized
INFO - 2018-03-12 00:01:30 --> Config Class Initialized
INFO - 2018-03-12 00:01:30 --> Router Class Initialized
INFO - 2018-03-12 00:01:30 --> Router Class Initialized
INFO - 2018-03-12 00:01:30 --> Hooks Class Initialized
INFO - 2018-03-12 00:01:30 --> Router Class Initialized
INFO - 2018-03-12 00:01:30 --> Output Class Initialized
INFO - 2018-03-12 00:01:30 --> Output Class Initialized
INFO - 2018-03-12 00:01:30 --> Output Class Initialized
DEBUG - 2018-03-12 00:01:30 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:01:30 --> Utf8 Class Initialized
INFO - 2018-03-12 00:01:30 --> Security Class Initialized
INFO - 2018-03-12 00:01:30 --> Security Class Initialized
INFO - 2018-03-12 00:01:30 --> URI Class Initialized
INFO - 2018-03-12 00:01:30 --> Security Class Initialized
DEBUG - 2018-03-12 00:01:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 00:01:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:01:30 --> Input Class Initialized
INFO - 2018-03-12 00:01:30 --> Input Class Initialized
DEBUG - 2018-03-12 00:01:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:01:30 --> Input Class Initialized
INFO - 2018-03-12 00:01:30 --> Language Class Initialized
INFO - 2018-03-12 00:01:30 --> Language Class Initialized
INFO - 2018-03-12 00:01:30 --> Router Class Initialized
INFO - 2018-03-12 00:01:30 --> Language Class Initialized
ERROR - 2018-03-12 00:01:30 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-12 00:01:30 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-12 00:01:30 --> Output Class Initialized
ERROR - 2018-03-12 00:01:30 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-12 00:01:30 --> Security Class Initialized
DEBUG - 2018-03-12 00:01:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:01:30 --> Input Class Initialized
INFO - 2018-03-12 00:01:30 --> Language Class Initialized
ERROR - 2018-03-12 00:01:30 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-12 00:01:30 --> Config Class Initialized
INFO - 2018-03-12 00:01:30 --> Hooks Class Initialized
INFO - 2018-03-12 00:01:30 --> Config Class Initialized
INFO - 2018-03-12 00:01:30 --> Hooks Class Initialized
INFO - 2018-03-12 00:01:30 --> Config Class Initialized
INFO - 2018-03-12 00:01:30 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:01:30 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:01:30 --> Utf8 Class Initialized
INFO - 2018-03-12 00:01:30 --> URI Class Initialized
DEBUG - 2018-03-12 00:01:30 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:01:30 --> Utf8 Class Initialized
DEBUG - 2018-03-12 00:01:30 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:01:30 --> Utf8 Class Initialized
INFO - 2018-03-12 00:01:30 --> URI Class Initialized
INFO - 2018-03-12 00:01:30 --> Router Class Initialized
INFO - 2018-03-12 00:01:30 --> URI Class Initialized
INFO - 2018-03-12 00:01:30 --> Router Class Initialized
INFO - 2018-03-12 00:01:30 --> Output Class Initialized
INFO - 2018-03-12 00:01:30 --> Router Class Initialized
INFO - 2018-03-12 00:01:30 --> Output Class Initialized
INFO - 2018-03-12 00:01:30 --> Security Class Initialized
DEBUG - 2018-03-12 00:01:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:01:30 --> Security Class Initialized
INFO - 2018-03-12 00:01:30 --> Input Class Initialized
INFO - 2018-03-12 00:01:30 --> Output Class Initialized
INFO - 2018-03-12 00:01:30 --> Language Class Initialized
DEBUG - 2018-03-12 00:01:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:01:30 --> Input Class Initialized
INFO - 2018-03-12 00:01:30 --> Security Class Initialized
ERROR - 2018-03-12 00:01:30 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-12 00:01:30 --> Language Class Initialized
DEBUG - 2018-03-12 00:01:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-03-12 00:01:30 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-12 00:01:30 --> Input Class Initialized
INFO - 2018-03-12 00:01:30 --> Language Class Initialized
ERROR - 2018-03-12 00:01:30 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-12 00:01:30 --> Config Class Initialized
INFO - 2018-03-12 00:01:30 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:01:30 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:01:30 --> Utf8 Class Initialized
INFO - 2018-03-12 00:01:30 --> URI Class Initialized
INFO - 2018-03-12 00:01:30 --> Router Class Initialized
INFO - 2018-03-12 00:01:30 --> Output Class Initialized
INFO - 2018-03-12 00:01:30 --> Security Class Initialized
DEBUG - 2018-03-12 00:01:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:01:30 --> Input Class Initialized
INFO - 2018-03-12 00:01:30 --> Language Class Initialized
INFO - 2018-03-12 00:01:30 --> Loader Class Initialized
INFO - 2018-03-12 00:01:30 --> Helper loaded: url_helper
INFO - 2018-03-12 00:01:30 --> Helper loaded: form_helper
INFO - 2018-03-12 00:01:30 --> Database Driver Class Initialized
DEBUG - 2018-03-12 00:01:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 00:01:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 00:01:30 --> Form Validation Class Initialized
INFO - 2018-03-12 00:01:30 --> Model Class Initialized
INFO - 2018-03-12 00:01:30 --> Controller Class Initialized
INFO - 2018-03-12 00:01:30 --> Model Class Initialized
INFO - 2018-03-12 00:01:30 --> Model Class Initialized
INFO - 2018-03-12 00:01:30 --> Model Class Initialized
INFO - 2018-03-12 00:01:30 --> Model Class Initialized
INFO - 2018-03-12 00:01:30 --> Model Class Initialized
DEBUG - 2018-03-12 00:01:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-12 00:01:35 --> Config Class Initialized
INFO - 2018-03-12 00:01:35 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:01:35 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:01:35 --> Utf8 Class Initialized
INFO - 2018-03-12 00:01:35 --> URI Class Initialized
INFO - 2018-03-12 00:01:35 --> Router Class Initialized
INFO - 2018-03-12 00:01:35 --> Output Class Initialized
INFO - 2018-03-12 00:01:35 --> Security Class Initialized
DEBUG - 2018-03-12 00:01:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:01:35 --> Input Class Initialized
INFO - 2018-03-12 00:01:35 --> Language Class Initialized
INFO - 2018-03-12 00:01:35 --> Loader Class Initialized
INFO - 2018-03-12 00:01:35 --> Helper loaded: url_helper
INFO - 2018-03-12 00:01:35 --> Helper loaded: form_helper
INFO - 2018-03-12 00:01:35 --> Database Driver Class Initialized
DEBUG - 2018-03-12 00:01:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 00:01:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 00:01:35 --> Form Validation Class Initialized
INFO - 2018-03-12 00:01:35 --> Model Class Initialized
INFO - 2018-03-12 00:01:35 --> Controller Class Initialized
INFO - 2018-03-12 00:01:35 --> Model Class Initialized
INFO - 2018-03-12 00:01:35 --> Model Class Initialized
INFO - 2018-03-12 00:01:35 --> Model Class Initialized
INFO - 2018-03-12 00:01:35 --> Model Class Initialized
INFO - 2018-03-12 00:01:35 --> Model Class Initialized
DEBUG - 2018-03-12 00:01:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-12 00:01:35 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-12 00:01:35 --> Final output sent to browser
DEBUG - 2018-03-12 00:01:35 --> Total execution time: 0.0495
INFO - 2018-03-12 00:01:35 --> Config Class Initialized
INFO - 2018-03-12 00:01:35 --> Hooks Class Initialized
INFO - 2018-03-12 00:01:35 --> Config Class Initialized
INFO - 2018-03-12 00:01:35 --> Hooks Class Initialized
INFO - 2018-03-12 00:01:35 --> Config Class Initialized
INFO - 2018-03-12 00:01:35 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:01:35 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:01:35 --> Utf8 Class Initialized
INFO - 2018-03-12 00:01:35 --> URI Class Initialized
DEBUG - 2018-03-12 00:01:35 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 00:01:35 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:01:35 --> Utf8 Class Initialized
INFO - 2018-03-12 00:01:35 --> Utf8 Class Initialized
INFO - 2018-03-12 00:01:35 --> URI Class Initialized
INFO - 2018-03-12 00:01:35 --> URI Class Initialized
INFO - 2018-03-12 00:01:35 --> Router Class Initialized
INFO - 2018-03-12 00:01:35 --> Config Class Initialized
INFO - 2018-03-12 00:01:35 --> Hooks Class Initialized
INFO - 2018-03-12 00:01:35 --> Output Class Initialized
INFO - 2018-03-12 00:01:35 --> Router Class Initialized
INFO - 2018-03-12 00:01:35 --> Router Class Initialized
DEBUG - 2018-03-12 00:01:35 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:01:35 --> Security Class Initialized
INFO - 2018-03-12 00:01:35 --> Utf8 Class Initialized
INFO - 2018-03-12 00:01:35 --> Output Class Initialized
INFO - 2018-03-12 00:01:35 --> Output Class Initialized
INFO - 2018-03-12 00:01:35 --> URI Class Initialized
DEBUG - 2018-03-12 00:01:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:01:35 --> Security Class Initialized
INFO - 2018-03-12 00:01:35 --> Input Class Initialized
INFO - 2018-03-12 00:01:35 --> Language Class Initialized
INFO - 2018-03-12 00:01:35 --> Security Class Initialized
DEBUG - 2018-03-12 00:01:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:01:35 --> Router Class Initialized
INFO - 2018-03-12 00:01:35 --> Input Class Initialized
ERROR - 2018-03-12 00:01:35 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-12 00:01:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:01:35 --> Language Class Initialized
INFO - 2018-03-12 00:01:35 --> Input Class Initialized
INFO - 2018-03-12 00:01:35 --> Output Class Initialized
INFO - 2018-03-12 00:01:35 --> Language Class Initialized
ERROR - 2018-03-12 00:01:35 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-12 00:01:35 --> Security Class Initialized
ERROR - 2018-03-12 00:01:35 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-12 00:01:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:01:35 --> Input Class Initialized
INFO - 2018-03-12 00:01:35 --> Language Class Initialized
ERROR - 2018-03-12 00:01:35 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-12 00:01:36 --> Config Class Initialized
INFO - 2018-03-12 00:01:36 --> Hooks Class Initialized
INFO - 2018-03-12 00:01:36 --> Config Class Initialized
INFO - 2018-03-12 00:01:36 --> Hooks Class Initialized
INFO - 2018-03-12 00:01:36 --> Config Class Initialized
INFO - 2018-03-12 00:01:36 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:01:36 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:01:36 --> Utf8 Class Initialized
DEBUG - 2018-03-12 00:01:36 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:01:36 --> URI Class Initialized
DEBUG - 2018-03-12 00:01:36 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:01:36 --> Utf8 Class Initialized
INFO - 2018-03-12 00:01:36 --> Utf8 Class Initialized
INFO - 2018-03-12 00:01:36 --> URI Class Initialized
INFO - 2018-03-12 00:01:36 --> URI Class Initialized
INFO - 2018-03-12 00:01:36 --> Router Class Initialized
INFO - 2018-03-12 00:01:36 --> Router Class Initialized
INFO - 2018-03-12 00:01:36 --> Output Class Initialized
INFO - 2018-03-12 00:01:36 --> Router Class Initialized
INFO - 2018-03-12 00:01:36 --> Output Class Initialized
INFO - 2018-03-12 00:01:36 --> Security Class Initialized
INFO - 2018-03-12 00:01:36 --> Output Class Initialized
INFO - 2018-03-12 00:01:36 --> Security Class Initialized
DEBUG - 2018-03-12 00:01:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:01:36 --> Input Class Initialized
INFO - 2018-03-12 00:01:36 --> Security Class Initialized
DEBUG - 2018-03-12 00:01:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:01:36 --> Language Class Initialized
INFO - 2018-03-12 00:01:36 --> Input Class Initialized
INFO - 2018-03-12 00:01:36 --> Language Class Initialized
DEBUG - 2018-03-12 00:01:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-03-12 00:01:36 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-12 00:01:36 --> Input Class Initialized
ERROR - 2018-03-12 00:01:36 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-12 00:01:36 --> Language Class Initialized
ERROR - 2018-03-12 00:01:36 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-12 00:01:36 --> Config Class Initialized
INFO - 2018-03-12 00:01:36 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:01:36 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:01:36 --> Utf8 Class Initialized
INFO - 2018-03-12 00:01:36 --> URI Class Initialized
INFO - 2018-03-12 00:01:36 --> Router Class Initialized
INFO - 2018-03-12 00:01:36 --> Output Class Initialized
INFO - 2018-03-12 00:01:36 --> Security Class Initialized
DEBUG - 2018-03-12 00:01:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:01:36 --> Input Class Initialized
INFO - 2018-03-12 00:01:36 --> Language Class Initialized
INFO - 2018-03-12 00:01:36 --> Loader Class Initialized
INFO - 2018-03-12 00:01:36 --> Helper loaded: url_helper
INFO - 2018-03-12 00:01:36 --> Helper loaded: form_helper
INFO - 2018-03-12 00:01:36 --> Database Driver Class Initialized
DEBUG - 2018-03-12 00:01:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 00:01:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 00:01:36 --> Form Validation Class Initialized
INFO - 2018-03-12 00:01:36 --> Model Class Initialized
INFO - 2018-03-12 00:01:36 --> Controller Class Initialized
INFO - 2018-03-12 00:01:36 --> Model Class Initialized
INFO - 2018-03-12 00:01:36 --> Model Class Initialized
INFO - 2018-03-12 00:01:36 --> Model Class Initialized
INFO - 2018-03-12 00:01:36 --> Model Class Initialized
INFO - 2018-03-12 00:01:36 --> Model Class Initialized
DEBUG - 2018-03-12 00:01:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-12 00:03:18 --> Config Class Initialized
INFO - 2018-03-12 00:03:18 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:03:18 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:03:18 --> Utf8 Class Initialized
INFO - 2018-03-12 00:03:18 --> URI Class Initialized
INFO - 2018-03-12 00:03:18 --> Router Class Initialized
INFO - 2018-03-12 00:03:18 --> Output Class Initialized
INFO - 2018-03-12 00:03:18 --> Security Class Initialized
DEBUG - 2018-03-12 00:03:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:03:18 --> Input Class Initialized
INFO - 2018-03-12 00:03:18 --> Language Class Initialized
INFO - 2018-03-12 00:03:18 --> Loader Class Initialized
INFO - 2018-03-12 00:03:18 --> Helper loaded: url_helper
INFO - 2018-03-12 00:03:18 --> Helper loaded: form_helper
INFO - 2018-03-12 00:03:18 --> Database Driver Class Initialized
DEBUG - 2018-03-12 00:03:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 00:03:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 00:03:18 --> Form Validation Class Initialized
INFO - 2018-03-12 00:03:18 --> Model Class Initialized
INFO - 2018-03-12 00:03:18 --> Controller Class Initialized
INFO - 2018-03-12 00:03:18 --> Model Class Initialized
INFO - 2018-03-12 00:03:18 --> Model Class Initialized
INFO - 2018-03-12 00:03:18 --> Model Class Initialized
INFO - 2018-03-12 00:03:18 --> Model Class Initialized
INFO - 2018-03-12 00:03:18 --> Model Class Initialized
DEBUG - 2018-03-12 00:03:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-12 00:03:18 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-12 00:03:18 --> Final output sent to browser
DEBUG - 2018-03-12 00:03:18 --> Total execution time: 0.0781
INFO - 2018-03-12 00:03:18 --> Config Class Initialized
INFO - 2018-03-12 00:03:18 --> Hooks Class Initialized
INFO - 2018-03-12 00:03:18 --> Config Class Initialized
INFO - 2018-03-12 00:03:18 --> Config Class Initialized
INFO - 2018-03-12 00:03:18 --> Hooks Class Initialized
INFO - 2018-03-12 00:03:18 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:03:18 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:03:18 --> Utf8 Class Initialized
DEBUG - 2018-03-12 00:03:18 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:03:18 --> Utf8 Class Initialized
DEBUG - 2018-03-12 00:03:18 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:03:18 --> Utf8 Class Initialized
INFO - 2018-03-12 00:03:18 --> URI Class Initialized
INFO - 2018-03-12 00:03:18 --> URI Class Initialized
INFO - 2018-03-12 00:03:18 --> URI Class Initialized
INFO - 2018-03-12 00:03:18 --> Router Class Initialized
INFO - 2018-03-12 00:03:18 --> Router Class Initialized
INFO - 2018-03-12 00:03:18 --> Router Class Initialized
INFO - 2018-03-12 00:03:18 --> Config Class Initialized
INFO - 2018-03-12 00:03:18 --> Hooks Class Initialized
INFO - 2018-03-12 00:03:18 --> Output Class Initialized
INFO - 2018-03-12 00:03:18 --> Output Class Initialized
INFO - 2018-03-12 00:03:18 --> Output Class Initialized
INFO - 2018-03-12 00:03:18 --> Security Class Initialized
DEBUG - 2018-03-12 00:03:18 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:03:18 --> Security Class Initialized
INFO - 2018-03-12 00:03:18 --> Utf8 Class Initialized
DEBUG - 2018-03-12 00:03:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:03:18 --> Security Class Initialized
INFO - 2018-03-12 00:03:18 --> Input Class Initialized
DEBUG - 2018-03-12 00:03:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:03:18 --> URI Class Initialized
INFO - 2018-03-12 00:03:18 --> Language Class Initialized
INFO - 2018-03-12 00:03:18 --> Input Class Initialized
DEBUG - 2018-03-12 00:03:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:03:18 --> Input Class Initialized
INFO - 2018-03-12 00:03:18 --> Language Class Initialized
INFO - 2018-03-12 00:03:18 --> Language Class Initialized
ERROR - 2018-03-12 00:03:18 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-12 00:03:18 --> Router Class Initialized
ERROR - 2018-03-12 00:03:18 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-12 00:03:18 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-12 00:03:18 --> Output Class Initialized
INFO - 2018-03-12 00:03:18 --> Security Class Initialized
DEBUG - 2018-03-12 00:03:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:03:18 --> Input Class Initialized
INFO - 2018-03-12 00:03:18 --> Language Class Initialized
ERROR - 2018-03-12 00:03:18 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-12 00:03:18 --> Config Class Initialized
INFO - 2018-03-12 00:03:18 --> Hooks Class Initialized
INFO - 2018-03-12 00:03:18 --> Config Class Initialized
INFO - 2018-03-12 00:03:18 --> Hooks Class Initialized
INFO - 2018-03-12 00:03:18 --> Config Class Initialized
INFO - 2018-03-12 00:03:18 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:03:18 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:03:18 --> Utf8 Class Initialized
INFO - 2018-03-12 00:03:18 --> URI Class Initialized
DEBUG - 2018-03-12 00:03:18 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:03:18 --> Utf8 Class Initialized
DEBUG - 2018-03-12 00:03:18 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:03:18 --> Utf8 Class Initialized
INFO - 2018-03-12 00:03:18 --> URI Class Initialized
INFO - 2018-03-12 00:03:18 --> Router Class Initialized
INFO - 2018-03-12 00:03:18 --> URI Class Initialized
INFO - 2018-03-12 00:03:18 --> Output Class Initialized
INFO - 2018-03-12 00:03:18 --> Router Class Initialized
INFO - 2018-03-12 00:03:18 --> Router Class Initialized
INFO - 2018-03-12 00:03:18 --> Security Class Initialized
INFO - 2018-03-12 00:03:18 --> Output Class Initialized
DEBUG - 2018-03-12 00:03:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:03:18 --> Output Class Initialized
INFO - 2018-03-12 00:03:18 --> Input Class Initialized
INFO - 2018-03-12 00:03:18 --> Security Class Initialized
INFO - 2018-03-12 00:03:18 --> Language Class Initialized
INFO - 2018-03-12 00:03:18 --> Security Class Initialized
DEBUG - 2018-03-12 00:03:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:03:18 --> Input Class Initialized
ERROR - 2018-03-12 00:03:18 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-12 00:03:18 --> Language Class Initialized
DEBUG - 2018-03-12 00:03:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:03:18 --> Input Class Initialized
INFO - 2018-03-12 00:03:18 --> Language Class Initialized
ERROR - 2018-03-12 00:03:18 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-12 00:03:18 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-12 00:03:18 --> Config Class Initialized
INFO - 2018-03-12 00:03:18 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:03:18 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:03:18 --> Utf8 Class Initialized
INFO - 2018-03-12 00:03:18 --> URI Class Initialized
INFO - 2018-03-12 00:03:18 --> Router Class Initialized
INFO - 2018-03-12 00:03:18 --> Output Class Initialized
INFO - 2018-03-12 00:03:18 --> Security Class Initialized
DEBUG - 2018-03-12 00:03:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:03:18 --> Input Class Initialized
INFO - 2018-03-12 00:03:18 --> Language Class Initialized
INFO - 2018-03-12 00:03:18 --> Loader Class Initialized
INFO - 2018-03-12 00:03:18 --> Helper loaded: url_helper
INFO - 2018-03-12 00:03:18 --> Helper loaded: form_helper
INFO - 2018-03-12 00:03:18 --> Database Driver Class Initialized
DEBUG - 2018-03-12 00:03:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 00:03:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 00:03:18 --> Form Validation Class Initialized
INFO - 2018-03-12 00:03:18 --> Model Class Initialized
INFO - 2018-03-12 00:03:18 --> Controller Class Initialized
INFO - 2018-03-12 00:03:18 --> Model Class Initialized
INFO - 2018-03-12 00:03:18 --> Model Class Initialized
INFO - 2018-03-12 00:03:18 --> Model Class Initialized
INFO - 2018-03-12 00:03:18 --> Model Class Initialized
INFO - 2018-03-12 00:03:18 --> Model Class Initialized
DEBUG - 2018-03-12 00:03:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-12 00:04:11 --> Config Class Initialized
INFO - 2018-03-12 00:04:11 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:04:11 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:04:11 --> Utf8 Class Initialized
INFO - 2018-03-12 00:04:11 --> URI Class Initialized
INFO - 2018-03-12 00:04:11 --> Router Class Initialized
INFO - 2018-03-12 00:04:11 --> Output Class Initialized
INFO - 2018-03-12 00:04:11 --> Security Class Initialized
DEBUG - 2018-03-12 00:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:04:11 --> Input Class Initialized
INFO - 2018-03-12 00:04:11 --> Language Class Initialized
INFO - 2018-03-12 00:04:11 --> Loader Class Initialized
INFO - 2018-03-12 00:04:11 --> Helper loaded: url_helper
INFO - 2018-03-12 00:04:12 --> Helper loaded: form_helper
INFO - 2018-03-12 00:04:12 --> Database Driver Class Initialized
DEBUG - 2018-03-12 00:04:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 00:04:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 00:04:12 --> Form Validation Class Initialized
INFO - 2018-03-12 00:04:12 --> Model Class Initialized
INFO - 2018-03-12 00:04:12 --> Controller Class Initialized
INFO - 2018-03-12 00:04:12 --> Model Class Initialized
INFO - 2018-03-12 00:04:12 --> Model Class Initialized
INFO - 2018-03-12 00:04:12 --> Model Class Initialized
INFO - 2018-03-12 00:04:12 --> Model Class Initialized
INFO - 2018-03-12 00:04:12 --> Model Class Initialized
DEBUG - 2018-03-12 00:04:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-12 00:04:12 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-12 00:04:12 --> Final output sent to browser
DEBUG - 2018-03-12 00:04:12 --> Total execution time: 0.0679
INFO - 2018-03-12 00:04:12 --> Config Class Initialized
INFO - 2018-03-12 00:04:12 --> Hooks Class Initialized
INFO - 2018-03-12 00:04:12 --> Config Class Initialized
INFO - 2018-03-12 00:04:12 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:04:12 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:04:12 --> Utf8 Class Initialized
INFO - 2018-03-12 00:04:12 --> Config Class Initialized
DEBUG - 2018-03-12 00:04:12 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:04:12 --> Hooks Class Initialized
INFO - 2018-03-12 00:04:12 --> Utf8 Class Initialized
INFO - 2018-03-12 00:04:12 --> URI Class Initialized
INFO - 2018-03-12 00:04:12 --> URI Class Initialized
INFO - 2018-03-12 00:04:12 --> Router Class Initialized
DEBUG - 2018-03-12 00:04:12 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:04:12 --> Utf8 Class Initialized
INFO - 2018-03-12 00:04:12 --> Router Class Initialized
INFO - 2018-03-12 00:04:12 --> URI Class Initialized
INFO - 2018-03-12 00:04:12 --> Output Class Initialized
INFO - 2018-03-12 00:04:12 --> Output Class Initialized
INFO - 2018-03-12 00:04:12 --> Security Class Initialized
INFO - 2018-03-12 00:04:12 --> Router Class Initialized
INFO - 2018-03-12 00:04:12 --> Config Class Initialized
INFO - 2018-03-12 00:04:12 --> Security Class Initialized
INFO - 2018-03-12 00:04:12 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:04:12 --> Input Class Initialized
DEBUG - 2018-03-12 00:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:04:12 --> Input Class Initialized
INFO - 2018-03-12 00:04:12 --> Output Class Initialized
INFO - 2018-03-12 00:04:12 --> Language Class Initialized
INFO - 2018-03-12 00:04:12 --> Language Class Initialized
ERROR - 2018-03-12 00:04:12 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-12 00:04:12 --> Security Class Initialized
DEBUG - 2018-03-12 00:04:12 --> UTF-8 Support Enabled
ERROR - 2018-03-12 00:04:12 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-12 00:04:12 --> Utf8 Class Initialized
DEBUG - 2018-03-12 00:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:04:12 --> Input Class Initialized
INFO - 2018-03-12 00:04:12 --> URI Class Initialized
INFO - 2018-03-12 00:04:12 --> Language Class Initialized
INFO - 2018-03-12 00:04:12 --> Router Class Initialized
ERROR - 2018-03-12 00:04:12 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-12 00:04:12 --> Output Class Initialized
INFO - 2018-03-12 00:04:12 --> Security Class Initialized
DEBUG - 2018-03-12 00:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:04:12 --> Input Class Initialized
INFO - 2018-03-12 00:04:12 --> Language Class Initialized
ERROR - 2018-03-12 00:04:12 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-12 00:04:12 --> Config Class Initialized
INFO - 2018-03-12 00:04:12 --> Hooks Class Initialized
INFO - 2018-03-12 00:04:12 --> Config Class Initialized
INFO - 2018-03-12 00:04:12 --> Hooks Class Initialized
INFO - 2018-03-12 00:04:12 --> Config Class Initialized
INFO - 2018-03-12 00:04:12 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:04:12 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:04:12 --> Utf8 Class Initialized
INFO - 2018-03-12 00:04:12 --> URI Class Initialized
DEBUG - 2018-03-12 00:04:12 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:04:12 --> Utf8 Class Initialized
DEBUG - 2018-03-12 00:04:12 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:04:12 --> Utf8 Class Initialized
INFO - 2018-03-12 00:04:12 --> URI Class Initialized
INFO - 2018-03-12 00:04:12 --> Router Class Initialized
INFO - 2018-03-12 00:04:12 --> URI Class Initialized
INFO - 2018-03-12 00:04:12 --> Router Class Initialized
INFO - 2018-03-12 00:04:12 --> Router Class Initialized
INFO - 2018-03-12 00:04:12 --> Output Class Initialized
INFO - 2018-03-12 00:04:12 --> Output Class Initialized
INFO - 2018-03-12 00:04:12 --> Output Class Initialized
INFO - 2018-03-12 00:04:12 --> Security Class Initialized
INFO - 2018-03-12 00:04:12 --> Security Class Initialized
DEBUG - 2018-03-12 00:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:04:12 --> Security Class Initialized
INFO - 2018-03-12 00:04:12 --> Input Class Initialized
DEBUG - 2018-03-12 00:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:04:12 --> Input Class Initialized
INFO - 2018-03-12 00:04:12 --> Language Class Initialized
DEBUG - 2018-03-12 00:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:04:12 --> Input Class Initialized
INFO - 2018-03-12 00:04:12 --> Language Class Initialized
ERROR - 2018-03-12 00:04:12 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-12 00:04:12 --> Language Class Initialized
ERROR - 2018-03-12 00:04:12 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-12 00:04:12 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-12 00:04:12 --> Config Class Initialized
INFO - 2018-03-12 00:04:12 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:04:12 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:04:12 --> Utf8 Class Initialized
INFO - 2018-03-12 00:04:12 --> URI Class Initialized
INFO - 2018-03-12 00:04:12 --> Router Class Initialized
INFO - 2018-03-12 00:04:12 --> Output Class Initialized
INFO - 2018-03-12 00:04:12 --> Security Class Initialized
DEBUG - 2018-03-12 00:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:04:12 --> Input Class Initialized
INFO - 2018-03-12 00:04:12 --> Language Class Initialized
INFO - 2018-03-12 00:04:12 --> Loader Class Initialized
INFO - 2018-03-12 00:04:12 --> Helper loaded: url_helper
INFO - 2018-03-12 00:04:12 --> Helper loaded: form_helper
INFO - 2018-03-12 00:04:12 --> Database Driver Class Initialized
DEBUG - 2018-03-12 00:04:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 00:04:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 00:04:12 --> Form Validation Class Initialized
INFO - 2018-03-12 00:04:12 --> Model Class Initialized
INFO - 2018-03-12 00:04:12 --> Controller Class Initialized
INFO - 2018-03-12 00:04:12 --> Model Class Initialized
INFO - 2018-03-12 00:04:12 --> Model Class Initialized
INFO - 2018-03-12 00:04:12 --> Model Class Initialized
INFO - 2018-03-12 00:04:12 --> Model Class Initialized
INFO - 2018-03-12 00:04:12 --> Model Class Initialized
DEBUG - 2018-03-12 00:04:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-12 00:04:43 --> Config Class Initialized
INFO - 2018-03-12 00:04:43 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:04:43 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:04:43 --> Utf8 Class Initialized
INFO - 2018-03-12 00:04:43 --> URI Class Initialized
INFO - 2018-03-12 00:04:43 --> Router Class Initialized
INFO - 2018-03-12 00:04:43 --> Output Class Initialized
INFO - 2018-03-12 00:04:43 --> Security Class Initialized
DEBUG - 2018-03-12 00:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:04:43 --> Input Class Initialized
INFO - 2018-03-12 00:04:43 --> Language Class Initialized
INFO - 2018-03-12 00:04:43 --> Loader Class Initialized
INFO - 2018-03-12 00:04:43 --> Helper loaded: url_helper
INFO - 2018-03-12 00:04:43 --> Helper loaded: form_helper
INFO - 2018-03-12 00:04:43 --> Database Driver Class Initialized
DEBUG - 2018-03-12 00:04:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 00:04:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 00:04:43 --> Form Validation Class Initialized
INFO - 2018-03-12 00:04:43 --> Model Class Initialized
INFO - 2018-03-12 00:04:43 --> Controller Class Initialized
INFO - 2018-03-12 00:04:43 --> Model Class Initialized
INFO - 2018-03-12 00:04:43 --> Model Class Initialized
INFO - 2018-03-12 00:04:43 --> Model Class Initialized
INFO - 2018-03-12 00:04:43 --> Model Class Initialized
INFO - 2018-03-12 00:04:43 --> Model Class Initialized
DEBUG - 2018-03-12 00:04:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-12 00:04:43 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-12 00:04:43 --> Final output sent to browser
DEBUG - 2018-03-12 00:04:43 --> Total execution time: 0.0609
INFO - 2018-03-12 00:04:43 --> Config Class Initialized
INFO - 2018-03-12 00:04:43 --> Hooks Class Initialized
INFO - 2018-03-12 00:04:43 --> Config Class Initialized
INFO - 2018-03-12 00:04:43 --> Hooks Class Initialized
INFO - 2018-03-12 00:04:43 --> Config Class Initialized
INFO - 2018-03-12 00:04:43 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:04:43 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:04:43 --> Utf8 Class Initialized
DEBUG - 2018-03-12 00:04:43 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:04:43 --> Utf8 Class Initialized
INFO - 2018-03-12 00:04:43 --> URI Class Initialized
DEBUG - 2018-03-12 00:04:43 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:04:43 --> Utf8 Class Initialized
INFO - 2018-03-12 00:04:43 --> URI Class Initialized
INFO - 2018-03-12 00:04:43 --> Router Class Initialized
INFO - 2018-03-12 00:04:43 --> URI Class Initialized
INFO - 2018-03-12 00:04:43 --> Router Class Initialized
INFO - 2018-03-12 00:04:43 --> Output Class Initialized
INFO - 2018-03-12 00:04:43 --> Config Class Initialized
INFO - 2018-03-12 00:04:43 --> Router Class Initialized
INFO - 2018-03-12 00:04:43 --> Hooks Class Initialized
INFO - 2018-03-12 00:04:43 --> Output Class Initialized
INFO - 2018-03-12 00:04:43 --> Security Class Initialized
INFO - 2018-03-12 00:04:43 --> Output Class Initialized
INFO - 2018-03-12 00:04:43 --> Security Class Initialized
DEBUG - 2018-03-12 00:04:43 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:04:43 --> Utf8 Class Initialized
DEBUG - 2018-03-12 00:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:04:43 --> Input Class Initialized
INFO - 2018-03-12 00:04:43 --> Security Class Initialized
DEBUG - 2018-03-12 00:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:04:43 --> Input Class Initialized
INFO - 2018-03-12 00:04:43 --> URI Class Initialized
INFO - 2018-03-12 00:04:43 --> Language Class Initialized
INFO - 2018-03-12 00:04:43 --> Language Class Initialized
DEBUG - 2018-03-12 00:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:04:43 --> Input Class Initialized
INFO - 2018-03-12 00:04:43 --> Router Class Initialized
ERROR - 2018-03-12 00:04:43 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-12 00:04:43 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-12 00:04:43 --> Language Class Initialized
ERROR - 2018-03-12 00:04:43 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-12 00:04:43 --> Output Class Initialized
INFO - 2018-03-12 00:04:43 --> Security Class Initialized
DEBUG - 2018-03-12 00:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:04:43 --> Input Class Initialized
INFO - 2018-03-12 00:04:43 --> Language Class Initialized
ERROR - 2018-03-12 00:04:43 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-12 00:04:43 --> Config Class Initialized
INFO - 2018-03-12 00:04:43 --> Hooks Class Initialized
INFO - 2018-03-12 00:04:43 --> Config Class Initialized
INFO - 2018-03-12 00:04:43 --> Config Class Initialized
INFO - 2018-03-12 00:04:43 --> Hooks Class Initialized
INFO - 2018-03-12 00:04:43 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:04:43 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:04:43 --> Utf8 Class Initialized
INFO - 2018-03-12 00:04:43 --> URI Class Initialized
DEBUG - 2018-03-12 00:04:43 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:04:43 --> Utf8 Class Initialized
DEBUG - 2018-03-12 00:04:43 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:04:43 --> Router Class Initialized
INFO - 2018-03-12 00:04:43 --> Utf8 Class Initialized
INFO - 2018-03-12 00:04:43 --> URI Class Initialized
INFO - 2018-03-12 00:04:43 --> URI Class Initialized
INFO - 2018-03-12 00:04:43 --> Output Class Initialized
INFO - 2018-03-12 00:04:43 --> Router Class Initialized
INFO - 2018-03-12 00:04:43 --> Router Class Initialized
INFO - 2018-03-12 00:04:43 --> Security Class Initialized
DEBUG - 2018-03-12 00:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:04:43 --> Output Class Initialized
INFO - 2018-03-12 00:04:43 --> Output Class Initialized
INFO - 2018-03-12 00:04:43 --> Input Class Initialized
INFO - 2018-03-12 00:04:43 --> Language Class Initialized
INFO - 2018-03-12 00:04:43 --> Security Class Initialized
INFO - 2018-03-12 00:04:43 --> Security Class Initialized
ERROR - 2018-03-12 00:04:43 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-03-12 00:04:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 00:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:04:43 --> Input Class Initialized
INFO - 2018-03-12 00:04:43 --> Input Class Initialized
INFO - 2018-03-12 00:04:43 --> Language Class Initialized
INFO - 2018-03-12 00:04:43 --> Language Class Initialized
ERROR - 2018-03-12 00:04:43 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-12 00:04:43 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-12 00:04:43 --> Config Class Initialized
INFO - 2018-03-12 00:04:43 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:04:43 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:04:43 --> Utf8 Class Initialized
INFO - 2018-03-12 00:04:43 --> URI Class Initialized
INFO - 2018-03-12 00:04:43 --> Router Class Initialized
INFO - 2018-03-12 00:04:43 --> Output Class Initialized
INFO - 2018-03-12 00:04:43 --> Security Class Initialized
DEBUG - 2018-03-12 00:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:04:43 --> Input Class Initialized
INFO - 2018-03-12 00:04:43 --> Language Class Initialized
INFO - 2018-03-12 00:04:43 --> Loader Class Initialized
INFO - 2018-03-12 00:04:43 --> Helper loaded: url_helper
INFO - 2018-03-12 00:04:43 --> Helper loaded: form_helper
INFO - 2018-03-12 00:04:43 --> Database Driver Class Initialized
DEBUG - 2018-03-12 00:04:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 00:04:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 00:04:43 --> Form Validation Class Initialized
INFO - 2018-03-12 00:04:43 --> Model Class Initialized
INFO - 2018-03-12 00:04:43 --> Controller Class Initialized
INFO - 2018-03-12 00:04:43 --> Model Class Initialized
INFO - 2018-03-12 00:04:43 --> Model Class Initialized
INFO - 2018-03-12 00:04:43 --> Model Class Initialized
INFO - 2018-03-12 00:04:43 --> Model Class Initialized
INFO - 2018-03-12 00:04:43 --> Model Class Initialized
DEBUG - 2018-03-12 00:04:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-12 00:07:51 --> Config Class Initialized
INFO - 2018-03-12 00:07:51 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:07:51 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:07:51 --> Utf8 Class Initialized
INFO - 2018-03-12 00:07:51 --> URI Class Initialized
INFO - 2018-03-12 00:07:51 --> Router Class Initialized
INFO - 2018-03-12 00:07:51 --> Output Class Initialized
INFO - 2018-03-12 00:07:51 --> Security Class Initialized
DEBUG - 2018-03-12 00:07:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:07:51 --> Input Class Initialized
INFO - 2018-03-12 00:07:51 --> Language Class Initialized
INFO - 2018-03-12 00:07:51 --> Loader Class Initialized
INFO - 2018-03-12 00:07:51 --> Helper loaded: url_helper
INFO - 2018-03-12 00:07:51 --> Helper loaded: form_helper
INFO - 2018-03-12 00:07:51 --> Database Driver Class Initialized
DEBUG - 2018-03-12 00:07:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 00:07:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 00:07:51 --> Form Validation Class Initialized
INFO - 2018-03-12 00:07:51 --> Model Class Initialized
INFO - 2018-03-12 00:07:51 --> Controller Class Initialized
INFO - 2018-03-12 00:07:51 --> Model Class Initialized
INFO - 2018-03-12 00:07:51 --> Model Class Initialized
INFO - 2018-03-12 00:07:51 --> Model Class Initialized
INFO - 2018-03-12 00:07:51 --> Model Class Initialized
INFO - 2018-03-12 00:07:51 --> Model Class Initialized
DEBUG - 2018-03-12 00:07:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-12 00:07:51 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-12 00:07:51 --> Final output sent to browser
DEBUG - 2018-03-12 00:07:51 --> Total execution time: 0.0558
INFO - 2018-03-12 00:07:51 --> Config Class Initialized
INFO - 2018-03-12 00:07:51 --> Hooks Class Initialized
INFO - 2018-03-12 00:07:51 --> Config Class Initialized
INFO - 2018-03-12 00:07:51 --> Config Class Initialized
INFO - 2018-03-12 00:07:51 --> Hooks Class Initialized
INFO - 2018-03-12 00:07:51 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:07:51 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:07:51 --> Utf8 Class Initialized
INFO - 2018-03-12 00:07:51 --> URI Class Initialized
DEBUG - 2018-03-12 00:07:51 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 00:07:51 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:07:51 --> Utf8 Class Initialized
INFO - 2018-03-12 00:07:51 --> Utf8 Class Initialized
INFO - 2018-03-12 00:07:51 --> Router Class Initialized
INFO - 2018-03-12 00:07:51 --> Config Class Initialized
INFO - 2018-03-12 00:07:51 --> URI Class Initialized
INFO - 2018-03-12 00:07:51 --> URI Class Initialized
INFO - 2018-03-12 00:07:51 --> Hooks Class Initialized
INFO - 2018-03-12 00:07:51 --> Output Class Initialized
INFO - 2018-03-12 00:07:51 --> Router Class Initialized
INFO - 2018-03-12 00:07:51 --> Router Class Initialized
INFO - 2018-03-12 00:07:51 --> Security Class Initialized
DEBUG - 2018-03-12 00:07:51 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:07:51 --> Output Class Initialized
INFO - 2018-03-12 00:07:51 --> Output Class Initialized
INFO - 2018-03-12 00:07:51 --> Utf8 Class Initialized
DEBUG - 2018-03-12 00:07:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:07:51 --> Input Class Initialized
INFO - 2018-03-12 00:07:51 --> URI Class Initialized
INFO - 2018-03-12 00:07:51 --> Security Class Initialized
INFO - 2018-03-12 00:07:51 --> Security Class Initialized
INFO - 2018-03-12 00:07:51 --> Language Class Initialized
INFO - 2018-03-12 00:07:51 --> Router Class Initialized
DEBUG - 2018-03-12 00:07:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 00:07:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:07:51 --> Input Class Initialized
ERROR - 2018-03-12 00:07:51 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-12 00:07:51 --> Input Class Initialized
INFO - 2018-03-12 00:07:51 --> Language Class Initialized
INFO - 2018-03-12 00:07:51 --> Language Class Initialized
INFO - 2018-03-12 00:07:51 --> Output Class Initialized
ERROR - 2018-03-12 00:07:51 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-12 00:07:51 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-12 00:07:51 --> Security Class Initialized
DEBUG - 2018-03-12 00:07:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:07:51 --> Input Class Initialized
INFO - 2018-03-12 00:07:51 --> Language Class Initialized
ERROR - 2018-03-12 00:07:51 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-12 00:07:51 --> Config Class Initialized
INFO - 2018-03-12 00:07:51 --> Hooks Class Initialized
INFO - 2018-03-12 00:07:51 --> Config Class Initialized
INFO - 2018-03-12 00:07:51 --> Hooks Class Initialized
INFO - 2018-03-12 00:07:51 --> Config Class Initialized
INFO - 2018-03-12 00:07:51 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:07:51 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:07:51 --> Utf8 Class Initialized
DEBUG - 2018-03-12 00:07:51 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:07:51 --> Utf8 Class Initialized
DEBUG - 2018-03-12 00:07:51 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:07:51 --> URI Class Initialized
INFO - 2018-03-12 00:07:51 --> Utf8 Class Initialized
INFO - 2018-03-12 00:07:51 --> URI Class Initialized
INFO - 2018-03-12 00:07:51 --> URI Class Initialized
INFO - 2018-03-12 00:07:51 --> Router Class Initialized
INFO - 2018-03-12 00:07:51 --> Router Class Initialized
INFO - 2018-03-12 00:07:51 --> Router Class Initialized
INFO - 2018-03-12 00:07:51 --> Output Class Initialized
INFO - 2018-03-12 00:07:51 --> Output Class Initialized
INFO - 2018-03-12 00:07:51 --> Security Class Initialized
INFO - 2018-03-12 00:07:51 --> Output Class Initialized
INFO - 2018-03-12 00:07:51 --> Security Class Initialized
DEBUG - 2018-03-12 00:07:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:07:51 --> Input Class Initialized
DEBUG - 2018-03-12 00:07:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:07:51 --> Security Class Initialized
INFO - 2018-03-12 00:07:51 --> Input Class Initialized
INFO - 2018-03-12 00:07:51 --> Language Class Initialized
INFO - 2018-03-12 00:07:51 --> Language Class Initialized
DEBUG - 2018-03-12 00:07:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:07:51 --> Input Class Initialized
ERROR - 2018-03-12 00:07:51 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-12 00:07:51 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-12 00:07:51 --> Language Class Initialized
ERROR - 2018-03-12 00:07:51 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-12 00:07:51 --> Config Class Initialized
INFO - 2018-03-12 00:07:51 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:07:51 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:07:51 --> Utf8 Class Initialized
INFO - 2018-03-12 00:07:51 --> URI Class Initialized
INFO - 2018-03-12 00:07:51 --> Router Class Initialized
INFO - 2018-03-12 00:07:51 --> Output Class Initialized
INFO - 2018-03-12 00:07:51 --> Security Class Initialized
DEBUG - 2018-03-12 00:07:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:07:51 --> Input Class Initialized
INFO - 2018-03-12 00:07:51 --> Language Class Initialized
INFO - 2018-03-12 00:07:51 --> Loader Class Initialized
INFO - 2018-03-12 00:07:51 --> Helper loaded: url_helper
INFO - 2018-03-12 00:07:51 --> Helper loaded: form_helper
INFO - 2018-03-12 00:07:51 --> Database Driver Class Initialized
DEBUG - 2018-03-12 00:07:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 00:07:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 00:07:51 --> Form Validation Class Initialized
INFO - 2018-03-12 00:07:51 --> Model Class Initialized
INFO - 2018-03-12 00:07:51 --> Controller Class Initialized
INFO - 2018-03-12 00:07:51 --> Model Class Initialized
INFO - 2018-03-12 00:07:51 --> Model Class Initialized
INFO - 2018-03-12 00:07:51 --> Model Class Initialized
INFO - 2018-03-12 00:07:51 --> Model Class Initialized
INFO - 2018-03-12 00:07:51 --> Model Class Initialized
DEBUG - 2018-03-12 00:07:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-12 00:17:10 --> Config Class Initialized
INFO - 2018-03-12 00:17:10 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:17:10 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:17:10 --> Utf8 Class Initialized
INFO - 2018-03-12 00:17:10 --> URI Class Initialized
INFO - 2018-03-12 00:17:10 --> Router Class Initialized
INFO - 2018-03-12 00:17:10 --> Output Class Initialized
INFO - 2018-03-12 00:17:10 --> Security Class Initialized
DEBUG - 2018-03-12 00:17:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:17:10 --> Input Class Initialized
INFO - 2018-03-12 00:17:10 --> Language Class Initialized
INFO - 2018-03-12 00:17:10 --> Loader Class Initialized
INFO - 2018-03-12 00:17:10 --> Helper loaded: url_helper
INFO - 2018-03-12 00:17:10 --> Helper loaded: form_helper
INFO - 2018-03-12 00:17:10 --> Database Driver Class Initialized
DEBUG - 2018-03-12 00:17:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 00:17:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 00:17:10 --> Form Validation Class Initialized
INFO - 2018-03-12 00:17:10 --> Model Class Initialized
INFO - 2018-03-12 00:17:10 --> Controller Class Initialized
INFO - 2018-03-12 00:17:10 --> Model Class Initialized
INFO - 2018-03-12 00:17:10 --> Model Class Initialized
INFO - 2018-03-12 00:17:10 --> Model Class Initialized
INFO - 2018-03-12 00:17:10 --> Model Class Initialized
INFO - 2018-03-12 00:17:10 --> Model Class Initialized
DEBUG - 2018-03-12 00:17:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-12 00:17:10 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-12 00:17:10 --> Final output sent to browser
DEBUG - 2018-03-12 00:17:10 --> Total execution time: 0.0886
INFO - 2018-03-12 00:17:10 --> Config Class Initialized
INFO - 2018-03-12 00:17:10 --> Hooks Class Initialized
INFO - 2018-03-12 00:17:10 --> Config Class Initialized
INFO - 2018-03-12 00:17:10 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:17:10 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:17:10 --> Utf8 Class Initialized
DEBUG - 2018-03-12 00:17:10 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:17:10 --> Utf8 Class Initialized
INFO - 2018-03-12 00:17:10 --> URI Class Initialized
INFO - 2018-03-12 00:17:10 --> URI Class Initialized
INFO - 2018-03-12 00:17:10 --> Router Class Initialized
INFO - 2018-03-12 00:17:10 --> Router Class Initialized
INFO - 2018-03-12 00:17:10 --> Output Class Initialized
INFO - 2018-03-12 00:17:10 --> Config Class Initialized
INFO - 2018-03-12 00:17:10 --> Output Class Initialized
INFO - 2018-03-12 00:17:10 --> Hooks Class Initialized
INFO - 2018-03-12 00:17:10 --> Security Class Initialized
INFO - 2018-03-12 00:17:10 --> Security Class Initialized
INFO - 2018-03-12 00:17:10 --> Config Class Initialized
INFO - 2018-03-12 00:17:10 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:17:10 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 00:17:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 00:17:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:17:10 --> Utf8 Class Initialized
INFO - 2018-03-12 00:17:10 --> Input Class Initialized
INFO - 2018-03-12 00:17:10 --> Input Class Initialized
INFO - 2018-03-12 00:17:10 --> Language Class Initialized
INFO - 2018-03-12 00:17:10 --> Language Class Initialized
INFO - 2018-03-12 00:17:10 --> URI Class Initialized
DEBUG - 2018-03-12 00:17:10 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:17:10 --> Utf8 Class Initialized
ERROR - 2018-03-12 00:17:10 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-12 00:17:10 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-12 00:17:10 --> URI Class Initialized
INFO - 2018-03-12 00:17:10 --> Router Class Initialized
INFO - 2018-03-12 00:17:10 --> Output Class Initialized
INFO - 2018-03-12 00:17:10 --> Router Class Initialized
INFO - 2018-03-12 00:17:10 --> Security Class Initialized
INFO - 2018-03-12 00:17:10 --> Output Class Initialized
DEBUG - 2018-03-12 00:17:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:17:10 --> Input Class Initialized
INFO - 2018-03-12 00:17:10 --> Language Class Initialized
INFO - 2018-03-12 00:17:10 --> Security Class Initialized
DEBUG - 2018-03-12 00:17:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-03-12 00:17:10 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-12 00:17:10 --> Input Class Initialized
INFO - 2018-03-12 00:17:10 --> Language Class Initialized
ERROR - 2018-03-12 00:17:10 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-12 00:17:10 --> Config Class Initialized
INFO - 2018-03-12 00:17:10 --> Hooks Class Initialized
INFO - 2018-03-12 00:17:10 --> Config Class Initialized
INFO - 2018-03-12 00:17:10 --> Config Class Initialized
INFO - 2018-03-12 00:17:10 --> Hooks Class Initialized
INFO - 2018-03-12 00:17:10 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:17:10 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:17:10 --> Utf8 Class Initialized
DEBUG - 2018-03-12 00:17:10 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 00:17:10 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:17:10 --> Utf8 Class Initialized
INFO - 2018-03-12 00:17:10 --> Utf8 Class Initialized
INFO - 2018-03-12 00:17:10 --> URI Class Initialized
INFO - 2018-03-12 00:17:10 --> URI Class Initialized
INFO - 2018-03-12 00:17:10 --> URI Class Initialized
INFO - 2018-03-12 00:17:10 --> Router Class Initialized
INFO - 2018-03-12 00:17:10 --> Router Class Initialized
INFO - 2018-03-12 00:17:10 --> Router Class Initialized
INFO - 2018-03-12 00:17:10 --> Output Class Initialized
INFO - 2018-03-12 00:17:10 --> Output Class Initialized
INFO - 2018-03-12 00:17:10 --> Output Class Initialized
INFO - 2018-03-12 00:17:10 --> Security Class Initialized
INFO - 2018-03-12 00:17:10 --> Security Class Initialized
INFO - 2018-03-12 00:17:10 --> Security Class Initialized
DEBUG - 2018-03-12 00:17:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 00:17:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:17:10 --> Input Class Initialized
INFO - 2018-03-12 00:17:10 --> Input Class Initialized
DEBUG - 2018-03-12 00:17:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:17:10 --> Input Class Initialized
INFO - 2018-03-12 00:17:10 --> Language Class Initialized
INFO - 2018-03-12 00:17:10 --> Language Class Initialized
INFO - 2018-03-12 00:17:10 --> Language Class Initialized
ERROR - 2018-03-12 00:17:10 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-12 00:17:10 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-12 00:17:10 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-12 00:17:10 --> Config Class Initialized
INFO - 2018-03-12 00:17:10 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:17:10 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:17:10 --> Utf8 Class Initialized
INFO - 2018-03-12 00:17:10 --> URI Class Initialized
INFO - 2018-03-12 00:17:10 --> Router Class Initialized
INFO - 2018-03-12 00:17:10 --> Output Class Initialized
INFO - 2018-03-12 00:17:10 --> Security Class Initialized
DEBUG - 2018-03-12 00:17:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:17:10 --> Input Class Initialized
INFO - 2018-03-12 00:17:10 --> Language Class Initialized
INFO - 2018-03-12 00:17:10 --> Loader Class Initialized
INFO - 2018-03-12 00:17:10 --> Helper loaded: url_helper
INFO - 2018-03-12 00:17:10 --> Helper loaded: form_helper
INFO - 2018-03-12 00:17:10 --> Database Driver Class Initialized
DEBUG - 2018-03-12 00:17:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 00:17:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 00:17:10 --> Form Validation Class Initialized
INFO - 2018-03-12 00:17:10 --> Model Class Initialized
INFO - 2018-03-12 00:17:10 --> Controller Class Initialized
INFO - 2018-03-12 00:17:10 --> Model Class Initialized
INFO - 2018-03-12 00:17:10 --> Model Class Initialized
INFO - 2018-03-12 00:17:10 --> Model Class Initialized
INFO - 2018-03-12 00:17:10 --> Model Class Initialized
INFO - 2018-03-12 00:17:10 --> Model Class Initialized
DEBUG - 2018-03-12 00:17:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-12 00:17:23 --> Config Class Initialized
INFO - 2018-03-12 00:17:23 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:17:23 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:17:23 --> Utf8 Class Initialized
INFO - 2018-03-12 00:17:23 --> URI Class Initialized
INFO - 2018-03-12 00:17:23 --> Router Class Initialized
INFO - 2018-03-12 00:17:23 --> Output Class Initialized
INFO - 2018-03-12 00:17:23 --> Security Class Initialized
DEBUG - 2018-03-12 00:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:17:23 --> Input Class Initialized
INFO - 2018-03-12 00:17:23 --> Language Class Initialized
INFO - 2018-03-12 00:17:23 --> Loader Class Initialized
INFO - 2018-03-12 00:17:23 --> Helper loaded: url_helper
INFO - 2018-03-12 00:17:23 --> Helper loaded: form_helper
INFO - 2018-03-12 00:17:23 --> Database Driver Class Initialized
DEBUG - 2018-03-12 00:17:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 00:17:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 00:17:23 --> Form Validation Class Initialized
INFO - 2018-03-12 00:17:23 --> Model Class Initialized
INFO - 2018-03-12 00:17:23 --> Controller Class Initialized
INFO - 2018-03-12 00:17:23 --> Model Class Initialized
INFO - 2018-03-12 00:17:23 --> Model Class Initialized
INFO - 2018-03-12 00:17:23 --> Model Class Initialized
INFO - 2018-03-12 00:17:23 --> Model Class Initialized
INFO - 2018-03-12 00:17:23 --> Model Class Initialized
DEBUG - 2018-03-12 00:17:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-12 00:17:23 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-12 00:17:23 --> Final output sent to browser
DEBUG - 2018-03-12 00:17:23 --> Total execution time: 0.0768
INFO - 2018-03-12 00:17:23 --> Config Class Initialized
INFO - 2018-03-12 00:17:23 --> Hooks Class Initialized
INFO - 2018-03-12 00:17:23 --> Config Class Initialized
INFO - 2018-03-12 00:17:23 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:17:23 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:17:23 --> Utf8 Class Initialized
INFO - 2018-03-12 00:17:23 --> Config Class Initialized
DEBUG - 2018-03-12 00:17:23 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:17:23 --> Hooks Class Initialized
INFO - 2018-03-12 00:17:23 --> Utf8 Class Initialized
INFO - 2018-03-12 00:17:23 --> Config Class Initialized
INFO - 2018-03-12 00:17:23 --> URI Class Initialized
INFO - 2018-03-12 00:17:23 --> Hooks Class Initialized
INFO - 2018-03-12 00:17:23 --> URI Class Initialized
INFO - 2018-03-12 00:17:23 --> Router Class Initialized
INFO - 2018-03-12 00:17:23 --> Router Class Initialized
DEBUG - 2018-03-12 00:17:23 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 00:17:23 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:17:23 --> Utf8 Class Initialized
INFO - 2018-03-12 00:17:23 --> Output Class Initialized
INFO - 2018-03-12 00:17:23 --> Utf8 Class Initialized
INFO - 2018-03-12 00:17:23 --> URI Class Initialized
INFO - 2018-03-12 00:17:23 --> Output Class Initialized
INFO - 2018-03-12 00:17:23 --> URI Class Initialized
INFO - 2018-03-12 00:17:23 --> Security Class Initialized
INFO - 2018-03-12 00:17:23 --> Security Class Initialized
INFO - 2018-03-12 00:17:23 --> Router Class Initialized
INFO - 2018-03-12 00:17:23 --> Router Class Initialized
DEBUG - 2018-03-12 00:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:17:23 --> Input Class Initialized
DEBUG - 2018-03-12 00:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:17:23 --> Input Class Initialized
INFO - 2018-03-12 00:17:23 --> Language Class Initialized
INFO - 2018-03-12 00:17:23 --> Output Class Initialized
INFO - 2018-03-12 00:17:23 --> Language Class Initialized
INFO - 2018-03-12 00:17:23 --> Output Class Initialized
ERROR - 2018-03-12 00:17:23 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-12 00:17:23 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-12 00:17:23 --> Security Class Initialized
INFO - 2018-03-12 00:17:23 --> Security Class Initialized
DEBUG - 2018-03-12 00:17:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 00:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:17:23 --> Input Class Initialized
INFO - 2018-03-12 00:17:23 --> Input Class Initialized
INFO - 2018-03-12 00:17:23 --> Language Class Initialized
INFO - 2018-03-12 00:17:23 --> Language Class Initialized
ERROR - 2018-03-12 00:17:23 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-12 00:17:23 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-12 00:17:23 --> Config Class Initialized
INFO - 2018-03-12 00:17:23 --> Hooks Class Initialized
INFO - 2018-03-12 00:17:23 --> Config Class Initialized
INFO - 2018-03-12 00:17:23 --> Config Class Initialized
INFO - 2018-03-12 00:17:23 --> Hooks Class Initialized
INFO - 2018-03-12 00:17:23 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:17:23 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:17:23 --> Utf8 Class Initialized
DEBUG - 2018-03-12 00:17:23 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:17:23 --> Utf8 Class Initialized
DEBUG - 2018-03-12 00:17:23 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:17:23 --> Utf8 Class Initialized
INFO - 2018-03-12 00:17:23 --> URI Class Initialized
INFO - 2018-03-12 00:17:23 --> URI Class Initialized
INFO - 2018-03-12 00:17:23 --> URI Class Initialized
INFO - 2018-03-12 00:17:23 --> Router Class Initialized
INFO - 2018-03-12 00:17:23 --> Router Class Initialized
INFO - 2018-03-12 00:17:23 --> Router Class Initialized
INFO - 2018-03-12 00:17:23 --> Output Class Initialized
INFO - 2018-03-12 00:17:23 --> Output Class Initialized
INFO - 2018-03-12 00:17:23 --> Output Class Initialized
INFO - 2018-03-12 00:17:23 --> Security Class Initialized
INFO - 2018-03-12 00:17:23 --> Security Class Initialized
INFO - 2018-03-12 00:17:23 --> Security Class Initialized
DEBUG - 2018-03-12 00:17:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 00:17:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 00:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:17:23 --> Input Class Initialized
INFO - 2018-03-12 00:17:23 --> Input Class Initialized
INFO - 2018-03-12 00:17:23 --> Input Class Initialized
INFO - 2018-03-12 00:17:23 --> Language Class Initialized
INFO - 2018-03-12 00:17:23 --> Language Class Initialized
INFO - 2018-03-12 00:17:23 --> Language Class Initialized
ERROR - 2018-03-12 00:17:23 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-12 00:17:23 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-12 00:17:23 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-12 00:17:23 --> Config Class Initialized
INFO - 2018-03-12 00:17:23 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:17:23 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:17:23 --> Utf8 Class Initialized
INFO - 2018-03-12 00:17:23 --> URI Class Initialized
INFO - 2018-03-12 00:17:23 --> Router Class Initialized
INFO - 2018-03-12 00:17:23 --> Output Class Initialized
INFO - 2018-03-12 00:17:23 --> Security Class Initialized
DEBUG - 2018-03-12 00:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:17:23 --> Input Class Initialized
INFO - 2018-03-12 00:17:23 --> Language Class Initialized
INFO - 2018-03-12 00:17:23 --> Loader Class Initialized
INFO - 2018-03-12 00:17:23 --> Helper loaded: url_helper
INFO - 2018-03-12 00:17:23 --> Helper loaded: form_helper
INFO - 2018-03-12 00:17:23 --> Database Driver Class Initialized
DEBUG - 2018-03-12 00:17:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 00:17:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 00:17:23 --> Form Validation Class Initialized
INFO - 2018-03-12 00:17:23 --> Model Class Initialized
INFO - 2018-03-12 00:17:23 --> Controller Class Initialized
INFO - 2018-03-12 00:17:23 --> Model Class Initialized
INFO - 2018-03-12 00:17:23 --> Model Class Initialized
INFO - 2018-03-12 00:17:23 --> Model Class Initialized
INFO - 2018-03-12 00:17:23 --> Model Class Initialized
INFO - 2018-03-12 00:17:23 --> Model Class Initialized
DEBUG - 2018-03-12 00:17:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-12 00:18:05 --> Config Class Initialized
INFO - 2018-03-12 00:18:05 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:18:05 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:18:05 --> Utf8 Class Initialized
INFO - 2018-03-12 00:18:05 --> URI Class Initialized
INFO - 2018-03-12 00:18:05 --> Router Class Initialized
INFO - 2018-03-12 00:18:06 --> Output Class Initialized
INFO - 2018-03-12 00:18:06 --> Security Class Initialized
DEBUG - 2018-03-12 00:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:18:06 --> Input Class Initialized
INFO - 2018-03-12 00:18:06 --> Language Class Initialized
INFO - 2018-03-12 00:18:06 --> Loader Class Initialized
INFO - 2018-03-12 00:18:06 --> Helper loaded: url_helper
INFO - 2018-03-12 00:18:06 --> Helper loaded: form_helper
INFO - 2018-03-12 00:18:06 --> Database Driver Class Initialized
DEBUG - 2018-03-12 00:18:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 00:18:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 00:18:06 --> Form Validation Class Initialized
INFO - 2018-03-12 00:18:06 --> Model Class Initialized
INFO - 2018-03-12 00:18:06 --> Controller Class Initialized
INFO - 2018-03-12 00:18:06 --> Model Class Initialized
INFO - 2018-03-12 00:18:06 --> Model Class Initialized
INFO - 2018-03-12 00:18:06 --> Model Class Initialized
INFO - 2018-03-12 00:18:06 --> Model Class Initialized
INFO - 2018-03-12 00:18:06 --> Model Class Initialized
DEBUG - 2018-03-12 00:18:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-12 00:18:06 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-12 00:18:06 --> Final output sent to browser
DEBUG - 2018-03-12 00:18:06 --> Total execution time: 0.0737
INFO - 2018-03-12 00:18:06 --> Config Class Initialized
INFO - 2018-03-12 00:18:06 --> Hooks Class Initialized
INFO - 2018-03-12 00:18:06 --> Config Class Initialized
INFO - 2018-03-12 00:18:06 --> Hooks Class Initialized
INFO - 2018-03-12 00:18:06 --> Config Class Initialized
INFO - 2018-03-12 00:18:06 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:18:06 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:18:06 --> Utf8 Class Initialized
DEBUG - 2018-03-12 00:18:06 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 00:18:06 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:18:06 --> Utf8 Class Initialized
INFO - 2018-03-12 00:18:06 --> Utf8 Class Initialized
INFO - 2018-03-12 00:18:06 --> Config Class Initialized
INFO - 2018-03-12 00:18:06 --> Hooks Class Initialized
INFO - 2018-03-12 00:18:06 --> URI Class Initialized
INFO - 2018-03-12 00:18:06 --> URI Class Initialized
INFO - 2018-03-12 00:18:06 --> URI Class Initialized
INFO - 2018-03-12 00:18:06 --> Router Class Initialized
INFO - 2018-03-12 00:18:06 --> Router Class Initialized
INFO - 2018-03-12 00:18:06 --> Router Class Initialized
DEBUG - 2018-03-12 00:18:06 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:18:06 --> Utf8 Class Initialized
INFO - 2018-03-12 00:18:06 --> Output Class Initialized
INFO - 2018-03-12 00:18:06 --> URI Class Initialized
INFO - 2018-03-12 00:18:06 --> Output Class Initialized
INFO - 2018-03-12 00:18:06 --> Output Class Initialized
INFO - 2018-03-12 00:18:06 --> Security Class Initialized
INFO - 2018-03-12 00:18:06 --> Security Class Initialized
INFO - 2018-03-12 00:18:06 --> Security Class Initialized
INFO - 2018-03-12 00:18:06 --> Router Class Initialized
DEBUG - 2018-03-12 00:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:18:06 --> Input Class Initialized
DEBUG - 2018-03-12 00:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:18:06 --> Language Class Initialized
DEBUG - 2018-03-12 00:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:18:06 --> Input Class Initialized
INFO - 2018-03-12 00:18:06 --> Input Class Initialized
INFO - 2018-03-12 00:18:06 --> Output Class Initialized
INFO - 2018-03-12 00:18:06 --> Language Class Initialized
INFO - 2018-03-12 00:18:06 --> Language Class Initialized
ERROR - 2018-03-12 00:18:06 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-12 00:18:06 --> Security Class Initialized
ERROR - 2018-03-12 00:18:06 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-12 00:18:06 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-12 00:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:18:06 --> Input Class Initialized
INFO - 2018-03-12 00:18:06 --> Language Class Initialized
ERROR - 2018-03-12 00:18:06 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-12 00:18:06 --> Config Class Initialized
INFO - 2018-03-12 00:18:06 --> Hooks Class Initialized
INFO - 2018-03-12 00:18:06 --> Config Class Initialized
INFO - 2018-03-12 00:18:06 --> Config Class Initialized
INFO - 2018-03-12 00:18:06 --> Hooks Class Initialized
INFO - 2018-03-12 00:18:06 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:18:06 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:18:06 --> Utf8 Class Initialized
DEBUG - 2018-03-12 00:18:06 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:18:06 --> Utf8 Class Initialized
INFO - 2018-03-12 00:18:06 --> URI Class Initialized
DEBUG - 2018-03-12 00:18:06 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:18:06 --> Utf8 Class Initialized
INFO - 2018-03-12 00:18:06 --> URI Class Initialized
INFO - 2018-03-12 00:18:06 --> Router Class Initialized
INFO - 2018-03-12 00:18:06 --> URI Class Initialized
INFO - 2018-03-12 00:18:06 --> Router Class Initialized
INFO - 2018-03-12 00:18:06 --> Output Class Initialized
INFO - 2018-03-12 00:18:06 --> Router Class Initialized
INFO - 2018-03-12 00:18:06 --> Output Class Initialized
INFO - 2018-03-12 00:18:06 --> Security Class Initialized
INFO - 2018-03-12 00:18:06 --> Output Class Initialized
DEBUG - 2018-03-12 00:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:18:06 --> Security Class Initialized
INFO - 2018-03-12 00:18:06 --> Input Class Initialized
INFO - 2018-03-12 00:18:06 --> Language Class Initialized
INFO - 2018-03-12 00:18:06 --> Security Class Initialized
DEBUG - 2018-03-12 00:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:18:06 --> Input Class Initialized
ERROR - 2018-03-12 00:18:06 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-12 00:18:06 --> Language Class Initialized
DEBUG - 2018-03-12 00:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:18:06 --> Input Class Initialized
INFO - 2018-03-12 00:18:06 --> Language Class Initialized
ERROR - 2018-03-12 00:18:06 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-12 00:18:06 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-12 00:18:06 --> Config Class Initialized
INFO - 2018-03-12 00:18:06 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:18:06 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:18:06 --> Utf8 Class Initialized
INFO - 2018-03-12 00:18:06 --> URI Class Initialized
INFO - 2018-03-12 00:18:06 --> Router Class Initialized
INFO - 2018-03-12 00:18:06 --> Output Class Initialized
INFO - 2018-03-12 00:18:06 --> Security Class Initialized
DEBUG - 2018-03-12 00:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:18:06 --> Input Class Initialized
INFO - 2018-03-12 00:18:06 --> Language Class Initialized
INFO - 2018-03-12 00:18:06 --> Loader Class Initialized
INFO - 2018-03-12 00:18:06 --> Helper loaded: url_helper
INFO - 2018-03-12 00:18:06 --> Helper loaded: form_helper
INFO - 2018-03-12 00:18:06 --> Database Driver Class Initialized
DEBUG - 2018-03-12 00:18:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 00:18:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 00:18:06 --> Form Validation Class Initialized
INFO - 2018-03-12 00:18:06 --> Model Class Initialized
INFO - 2018-03-12 00:18:06 --> Controller Class Initialized
INFO - 2018-03-12 00:18:06 --> Model Class Initialized
INFO - 2018-03-12 00:18:06 --> Model Class Initialized
INFO - 2018-03-12 00:18:06 --> Model Class Initialized
INFO - 2018-03-12 00:18:06 --> Model Class Initialized
INFO - 2018-03-12 00:18:06 --> Model Class Initialized
DEBUG - 2018-03-12 00:18:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-12 00:18:37 --> Config Class Initialized
INFO - 2018-03-12 00:18:37 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:18:37 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:18:37 --> Utf8 Class Initialized
INFO - 2018-03-12 00:18:37 --> URI Class Initialized
INFO - 2018-03-12 00:18:37 --> Router Class Initialized
INFO - 2018-03-12 00:18:37 --> Output Class Initialized
INFO - 2018-03-12 00:18:37 --> Security Class Initialized
DEBUG - 2018-03-12 00:18:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:18:37 --> Input Class Initialized
INFO - 2018-03-12 00:18:37 --> Language Class Initialized
INFO - 2018-03-12 00:18:37 --> Loader Class Initialized
INFO - 2018-03-12 00:18:37 --> Helper loaded: url_helper
INFO - 2018-03-12 00:18:37 --> Helper loaded: form_helper
INFO - 2018-03-12 00:18:37 --> Database Driver Class Initialized
DEBUG - 2018-03-12 00:18:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 00:18:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 00:18:37 --> Form Validation Class Initialized
INFO - 2018-03-12 00:18:37 --> Model Class Initialized
INFO - 2018-03-12 00:18:37 --> Controller Class Initialized
INFO - 2018-03-12 00:18:37 --> Model Class Initialized
INFO - 2018-03-12 00:18:37 --> Model Class Initialized
INFO - 2018-03-12 00:18:37 --> Model Class Initialized
INFO - 2018-03-12 00:18:37 --> Model Class Initialized
INFO - 2018-03-12 00:18:37 --> Model Class Initialized
DEBUG - 2018-03-12 00:18:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-12 00:18:37 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-12 00:18:37 --> Final output sent to browser
DEBUG - 2018-03-12 00:18:37 --> Total execution time: 0.0740
INFO - 2018-03-12 00:18:37 --> Config Class Initialized
INFO - 2018-03-12 00:18:37 --> Hooks Class Initialized
INFO - 2018-03-12 00:18:37 --> Config Class Initialized
INFO - 2018-03-12 00:18:37 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:18:37 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:18:37 --> Config Class Initialized
INFO - 2018-03-12 00:18:37 --> Utf8 Class Initialized
INFO - 2018-03-12 00:18:37 --> Hooks Class Initialized
INFO - 2018-03-12 00:18:37 --> URI Class Initialized
INFO - 2018-03-12 00:18:37 --> Config Class Initialized
INFO - 2018-03-12 00:18:37 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:18:37 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 00:18:37 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:18:37 --> Utf8 Class Initialized
INFO - 2018-03-12 00:18:37 --> Router Class Initialized
INFO - 2018-03-12 00:18:37 --> Utf8 Class Initialized
INFO - 2018-03-12 00:18:37 --> URI Class Initialized
INFO - 2018-03-12 00:18:37 --> URI Class Initialized
DEBUG - 2018-03-12 00:18:37 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:18:37 --> Utf8 Class Initialized
INFO - 2018-03-12 00:18:37 --> Output Class Initialized
INFO - 2018-03-12 00:18:37 --> Router Class Initialized
INFO - 2018-03-12 00:18:37 --> URI Class Initialized
INFO - 2018-03-12 00:18:37 --> Router Class Initialized
INFO - 2018-03-12 00:18:37 --> Security Class Initialized
INFO - 2018-03-12 00:18:37 --> Output Class Initialized
INFO - 2018-03-12 00:18:37 --> Router Class Initialized
INFO - 2018-03-12 00:18:37 --> Output Class Initialized
DEBUG - 2018-03-12 00:18:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:18:37 --> Input Class Initialized
INFO - 2018-03-12 00:18:37 --> Security Class Initialized
INFO - 2018-03-12 00:18:37 --> Output Class Initialized
INFO - 2018-03-12 00:18:37 --> Language Class Initialized
INFO - 2018-03-12 00:18:37 --> Security Class Initialized
DEBUG - 2018-03-12 00:18:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:18:37 --> Input Class Initialized
INFO - 2018-03-12 00:18:37 --> Security Class Initialized
ERROR - 2018-03-12 00:18:37 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-12 00:18:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:18:37 --> Language Class Initialized
INFO - 2018-03-12 00:18:37 --> Input Class Initialized
DEBUG - 2018-03-12 00:18:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:18:37 --> Language Class Initialized
INFO - 2018-03-12 00:18:37 --> Input Class Initialized
ERROR - 2018-03-12 00:18:37 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-12 00:18:37 --> Language Class Initialized
ERROR - 2018-03-12 00:18:37 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-12 00:18:37 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-12 00:18:37 --> Config Class Initialized
INFO - 2018-03-12 00:18:37 --> Hooks Class Initialized
INFO - 2018-03-12 00:18:37 --> Config Class Initialized
INFO - 2018-03-12 00:18:37 --> Hooks Class Initialized
INFO - 2018-03-12 00:18:37 --> Config Class Initialized
INFO - 2018-03-12 00:18:37 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:18:37 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:18:37 --> Utf8 Class Initialized
DEBUG - 2018-03-12 00:18:37 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:18:37 --> Utf8 Class Initialized
DEBUG - 2018-03-12 00:18:37 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:18:37 --> URI Class Initialized
INFO - 2018-03-12 00:18:37 --> Utf8 Class Initialized
INFO - 2018-03-12 00:18:37 --> URI Class Initialized
INFO - 2018-03-12 00:18:37 --> URI Class Initialized
INFO - 2018-03-12 00:18:37 --> Router Class Initialized
INFO - 2018-03-12 00:18:37 --> Router Class Initialized
INFO - 2018-03-12 00:18:37 --> Output Class Initialized
INFO - 2018-03-12 00:18:37 --> Router Class Initialized
INFO - 2018-03-12 00:18:37 --> Output Class Initialized
INFO - 2018-03-12 00:18:37 --> Security Class Initialized
INFO - 2018-03-12 00:18:37 --> Output Class Initialized
INFO - 2018-03-12 00:18:37 --> Security Class Initialized
DEBUG - 2018-03-12 00:18:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:18:37 --> Input Class Initialized
INFO - 2018-03-12 00:18:37 --> Security Class Initialized
DEBUG - 2018-03-12 00:18:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:18:37 --> Input Class Initialized
INFO - 2018-03-12 00:18:37 --> Language Class Initialized
INFO - 2018-03-12 00:18:37 --> Language Class Initialized
DEBUG - 2018-03-12 00:18:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:18:37 --> Input Class Initialized
ERROR - 2018-03-12 00:18:37 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-12 00:18:37 --> Language Class Initialized
ERROR - 2018-03-12 00:18:37 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-12 00:18:37 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-12 00:18:37 --> Config Class Initialized
INFO - 2018-03-12 00:18:37 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:18:37 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:18:37 --> Utf8 Class Initialized
INFO - 2018-03-12 00:18:37 --> URI Class Initialized
INFO - 2018-03-12 00:18:37 --> Router Class Initialized
INFO - 2018-03-12 00:18:37 --> Output Class Initialized
INFO - 2018-03-12 00:18:37 --> Security Class Initialized
DEBUG - 2018-03-12 00:18:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:18:37 --> Input Class Initialized
INFO - 2018-03-12 00:18:37 --> Language Class Initialized
INFO - 2018-03-12 00:18:37 --> Loader Class Initialized
INFO - 2018-03-12 00:18:37 --> Helper loaded: url_helper
INFO - 2018-03-12 00:18:37 --> Helper loaded: form_helper
INFO - 2018-03-12 00:18:37 --> Database Driver Class Initialized
DEBUG - 2018-03-12 00:18:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 00:18:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 00:18:37 --> Form Validation Class Initialized
INFO - 2018-03-12 00:18:37 --> Model Class Initialized
INFO - 2018-03-12 00:18:37 --> Controller Class Initialized
INFO - 2018-03-12 00:18:37 --> Model Class Initialized
INFO - 2018-03-12 00:18:37 --> Model Class Initialized
INFO - 2018-03-12 00:18:37 --> Model Class Initialized
INFO - 2018-03-12 00:18:37 --> Model Class Initialized
INFO - 2018-03-12 00:18:37 --> Model Class Initialized
DEBUG - 2018-03-12 00:18:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-12 00:19:46 --> Config Class Initialized
INFO - 2018-03-12 00:19:46 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:19:46 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:19:46 --> Utf8 Class Initialized
INFO - 2018-03-12 00:19:46 --> URI Class Initialized
INFO - 2018-03-12 00:19:46 --> Router Class Initialized
INFO - 2018-03-12 00:19:46 --> Output Class Initialized
INFO - 2018-03-12 00:19:46 --> Security Class Initialized
DEBUG - 2018-03-12 00:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:19:46 --> Input Class Initialized
INFO - 2018-03-12 00:19:46 --> Language Class Initialized
INFO - 2018-03-12 00:19:46 --> Loader Class Initialized
INFO - 2018-03-12 00:19:46 --> Helper loaded: url_helper
INFO - 2018-03-12 00:19:46 --> Helper loaded: form_helper
INFO - 2018-03-12 00:19:46 --> Database Driver Class Initialized
DEBUG - 2018-03-12 00:19:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 00:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 00:19:46 --> Form Validation Class Initialized
INFO - 2018-03-12 00:19:46 --> Model Class Initialized
INFO - 2018-03-12 00:19:46 --> Controller Class Initialized
INFO - 2018-03-12 00:19:46 --> Model Class Initialized
INFO - 2018-03-12 00:19:46 --> Model Class Initialized
INFO - 2018-03-12 00:19:46 --> Model Class Initialized
INFO - 2018-03-12 00:19:46 --> Model Class Initialized
INFO - 2018-03-12 00:19:46 --> Model Class Initialized
DEBUG - 2018-03-12 00:19:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-12 00:19:46 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-12 00:19:46 --> Final output sent to browser
DEBUG - 2018-03-12 00:19:46 --> Total execution time: 0.0590
INFO - 2018-03-12 00:19:46 --> Config Class Initialized
INFO - 2018-03-12 00:19:46 --> Hooks Class Initialized
INFO - 2018-03-12 00:19:46 --> Config Class Initialized
INFO - 2018-03-12 00:19:46 --> Hooks Class Initialized
INFO - 2018-03-12 00:19:46 --> Config Class Initialized
INFO - 2018-03-12 00:19:46 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:19:46 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:19:46 --> Utf8 Class Initialized
DEBUG - 2018-03-12 00:19:46 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:19:46 --> Utf8 Class Initialized
DEBUG - 2018-03-12 00:19:46 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:19:46 --> Utf8 Class Initialized
INFO - 2018-03-12 00:19:46 --> URI Class Initialized
INFO - 2018-03-12 00:19:46 --> URI Class Initialized
INFO - 2018-03-12 00:19:46 --> URI Class Initialized
INFO - 2018-03-12 00:19:46 --> Config Class Initialized
INFO - 2018-03-12 00:19:46 --> Hooks Class Initialized
INFO - 2018-03-12 00:19:46 --> Router Class Initialized
INFO - 2018-03-12 00:19:46 --> Router Class Initialized
INFO - 2018-03-12 00:19:46 --> Router Class Initialized
INFO - 2018-03-12 00:19:46 --> Output Class Initialized
INFO - 2018-03-12 00:19:46 --> Output Class Initialized
DEBUG - 2018-03-12 00:19:46 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:19:46 --> Output Class Initialized
INFO - 2018-03-12 00:19:46 --> Utf8 Class Initialized
INFO - 2018-03-12 00:19:46 --> Security Class Initialized
INFO - 2018-03-12 00:19:46 --> Security Class Initialized
INFO - 2018-03-12 00:19:46 --> Security Class Initialized
INFO - 2018-03-12 00:19:46 --> URI Class Initialized
DEBUG - 2018-03-12 00:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:19:46 --> Input Class Initialized
DEBUG - 2018-03-12 00:19:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 00:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:19:46 --> Language Class Initialized
INFO - 2018-03-12 00:19:46 --> Input Class Initialized
INFO - 2018-03-12 00:19:46 --> Input Class Initialized
INFO - 2018-03-12 00:19:46 --> Router Class Initialized
INFO - 2018-03-12 00:19:46 --> Language Class Initialized
INFO - 2018-03-12 00:19:46 --> Language Class Initialized
ERROR - 2018-03-12 00:19:46 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-12 00:19:46 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-12 00:19:46 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-12 00:19:46 --> Output Class Initialized
INFO - 2018-03-12 00:19:46 --> Security Class Initialized
DEBUG - 2018-03-12 00:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:19:46 --> Input Class Initialized
INFO - 2018-03-12 00:19:46 --> Language Class Initialized
ERROR - 2018-03-12 00:19:46 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-12 00:19:46 --> Config Class Initialized
INFO - 2018-03-12 00:19:46 --> Hooks Class Initialized
INFO - 2018-03-12 00:19:46 --> Config Class Initialized
INFO - 2018-03-12 00:19:46 --> Hooks Class Initialized
INFO - 2018-03-12 00:19:46 --> Config Class Initialized
INFO - 2018-03-12 00:19:46 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:19:46 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:19:46 --> Utf8 Class Initialized
DEBUG - 2018-03-12 00:19:46 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:19:46 --> Utf8 Class Initialized
DEBUG - 2018-03-12 00:19:46 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:19:46 --> Utf8 Class Initialized
INFO - 2018-03-12 00:19:46 --> URI Class Initialized
INFO - 2018-03-12 00:19:46 --> URI Class Initialized
INFO - 2018-03-12 00:19:46 --> URI Class Initialized
INFO - 2018-03-12 00:19:46 --> Router Class Initialized
INFO - 2018-03-12 00:19:46 --> Router Class Initialized
INFO - 2018-03-12 00:19:46 --> Router Class Initialized
INFO - 2018-03-12 00:19:46 --> Output Class Initialized
INFO - 2018-03-12 00:19:46 --> Output Class Initialized
INFO - 2018-03-12 00:19:46 --> Output Class Initialized
INFO - 2018-03-12 00:19:46 --> Security Class Initialized
INFO - 2018-03-12 00:19:46 --> Security Class Initialized
INFO - 2018-03-12 00:19:46 --> Security Class Initialized
DEBUG - 2018-03-12 00:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:19:46 --> Input Class Initialized
DEBUG - 2018-03-12 00:19:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 00:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:19:46 --> Input Class Initialized
INFO - 2018-03-12 00:19:46 --> Language Class Initialized
INFO - 2018-03-12 00:19:46 --> Input Class Initialized
INFO - 2018-03-12 00:19:46 --> Language Class Initialized
INFO - 2018-03-12 00:19:46 --> Language Class Initialized
ERROR - 2018-03-12 00:19:46 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-12 00:19:46 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-12 00:19:46 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-12 00:19:46 --> Config Class Initialized
INFO - 2018-03-12 00:19:46 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:19:46 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:19:46 --> Utf8 Class Initialized
INFO - 2018-03-12 00:19:46 --> URI Class Initialized
INFO - 2018-03-12 00:19:46 --> Router Class Initialized
INFO - 2018-03-12 00:19:46 --> Output Class Initialized
INFO - 2018-03-12 00:19:46 --> Security Class Initialized
DEBUG - 2018-03-12 00:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:19:46 --> Input Class Initialized
INFO - 2018-03-12 00:19:46 --> Language Class Initialized
INFO - 2018-03-12 00:19:46 --> Loader Class Initialized
INFO - 2018-03-12 00:19:46 --> Helper loaded: url_helper
INFO - 2018-03-12 00:19:46 --> Helper loaded: form_helper
INFO - 2018-03-12 00:19:46 --> Database Driver Class Initialized
DEBUG - 2018-03-12 00:19:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 00:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 00:19:46 --> Form Validation Class Initialized
INFO - 2018-03-12 00:19:46 --> Model Class Initialized
INFO - 2018-03-12 00:19:46 --> Controller Class Initialized
INFO - 2018-03-12 00:19:46 --> Model Class Initialized
INFO - 2018-03-12 00:19:46 --> Model Class Initialized
INFO - 2018-03-12 00:19:46 --> Model Class Initialized
INFO - 2018-03-12 00:19:46 --> Model Class Initialized
INFO - 2018-03-12 00:19:46 --> Model Class Initialized
DEBUG - 2018-03-12 00:19:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-12 00:20:05 --> Config Class Initialized
INFO - 2018-03-12 00:20:05 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:20:05 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:20:05 --> Utf8 Class Initialized
INFO - 2018-03-12 00:20:05 --> URI Class Initialized
INFO - 2018-03-12 00:20:05 --> Router Class Initialized
INFO - 2018-03-12 00:20:05 --> Output Class Initialized
INFO - 2018-03-12 00:20:05 --> Security Class Initialized
DEBUG - 2018-03-12 00:20:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:20:05 --> Input Class Initialized
INFO - 2018-03-12 00:20:05 --> Language Class Initialized
INFO - 2018-03-12 00:20:05 --> Loader Class Initialized
INFO - 2018-03-12 00:20:05 --> Helper loaded: url_helper
INFO - 2018-03-12 00:20:05 --> Helper loaded: form_helper
INFO - 2018-03-12 00:20:05 --> Database Driver Class Initialized
DEBUG - 2018-03-12 00:20:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 00:20:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 00:20:05 --> Form Validation Class Initialized
INFO - 2018-03-12 00:20:05 --> Model Class Initialized
INFO - 2018-03-12 00:20:05 --> Controller Class Initialized
INFO - 2018-03-12 00:20:05 --> Model Class Initialized
INFO - 2018-03-12 00:20:05 --> Model Class Initialized
INFO - 2018-03-12 00:20:05 --> Model Class Initialized
INFO - 2018-03-12 00:20:05 --> Model Class Initialized
INFO - 2018-03-12 00:20:05 --> Model Class Initialized
DEBUG - 2018-03-12 00:20:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-12 00:20:05 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-12 00:20:05 --> Final output sent to browser
DEBUG - 2018-03-12 00:20:05 --> Total execution time: 0.0609
INFO - 2018-03-12 00:20:06 --> Config Class Initialized
INFO - 2018-03-12 00:20:06 --> Hooks Class Initialized
INFO - 2018-03-12 00:20:06 --> Config Class Initialized
INFO - 2018-03-12 00:20:06 --> Config Class Initialized
INFO - 2018-03-12 00:20:06 --> Hooks Class Initialized
INFO - 2018-03-12 00:20:06 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:20:06 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:20:06 --> Utf8 Class Initialized
DEBUG - 2018-03-12 00:20:06 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:20:06 --> Utf8 Class Initialized
DEBUG - 2018-03-12 00:20:06 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:20:06 --> URI Class Initialized
INFO - 2018-03-12 00:20:06 --> Utf8 Class Initialized
INFO - 2018-03-12 00:20:06 --> Config Class Initialized
INFO - 2018-03-12 00:20:06 --> Hooks Class Initialized
INFO - 2018-03-12 00:20:06 --> URI Class Initialized
INFO - 2018-03-12 00:20:06 --> URI Class Initialized
INFO - 2018-03-12 00:20:06 --> Router Class Initialized
INFO - 2018-03-12 00:20:06 --> Router Class Initialized
DEBUG - 2018-03-12 00:20:06 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:20:06 --> Utf8 Class Initialized
INFO - 2018-03-12 00:20:06 --> Router Class Initialized
INFO - 2018-03-12 00:20:06 --> Output Class Initialized
INFO - 2018-03-12 00:20:06 --> URI Class Initialized
INFO - 2018-03-12 00:20:06 --> Output Class Initialized
INFO - 2018-03-12 00:20:06 --> Security Class Initialized
INFO - 2018-03-12 00:20:06 --> Output Class Initialized
INFO - 2018-03-12 00:20:06 --> Security Class Initialized
INFO - 2018-03-12 00:20:06 --> Router Class Initialized
DEBUG - 2018-03-12 00:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:20:06 --> Security Class Initialized
INFO - 2018-03-12 00:20:06 --> Input Class Initialized
DEBUG - 2018-03-12 00:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:20:06 --> Input Class Initialized
INFO - 2018-03-12 00:20:06 --> Language Class Initialized
DEBUG - 2018-03-12 00:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:20:06 --> Output Class Initialized
INFO - 2018-03-12 00:20:06 --> Input Class Initialized
INFO - 2018-03-12 00:20:06 --> Language Class Initialized
ERROR - 2018-03-12 00:20:06 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-12 00:20:06 --> Language Class Initialized
INFO - 2018-03-12 00:20:06 --> Security Class Initialized
ERROR - 2018-03-12 00:20:06 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-12 00:20:06 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-12 00:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:20:06 --> Input Class Initialized
INFO - 2018-03-12 00:20:06 --> Language Class Initialized
ERROR - 2018-03-12 00:20:06 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-12 00:20:06 --> Config Class Initialized
INFO - 2018-03-12 00:20:06 --> Config Class Initialized
INFO - 2018-03-12 00:20:06 --> Config Class Initialized
INFO - 2018-03-12 00:20:06 --> Hooks Class Initialized
INFO - 2018-03-12 00:20:06 --> Hooks Class Initialized
INFO - 2018-03-12 00:20:06 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:20:06 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 00:20:06 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:20:06 --> Utf8 Class Initialized
INFO - 2018-03-12 00:20:06 --> Utf8 Class Initialized
DEBUG - 2018-03-12 00:20:06 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:20:06 --> Utf8 Class Initialized
INFO - 2018-03-12 00:20:06 --> URI Class Initialized
INFO - 2018-03-12 00:20:06 --> URI Class Initialized
INFO - 2018-03-12 00:20:06 --> URI Class Initialized
INFO - 2018-03-12 00:20:06 --> Router Class Initialized
INFO - 2018-03-12 00:20:06 --> Router Class Initialized
INFO - 2018-03-12 00:20:06 --> Router Class Initialized
INFO - 2018-03-12 00:20:06 --> Output Class Initialized
INFO - 2018-03-12 00:20:06 --> Output Class Initialized
INFO - 2018-03-12 00:20:06 --> Output Class Initialized
INFO - 2018-03-12 00:20:06 --> Security Class Initialized
INFO - 2018-03-12 00:20:06 --> Security Class Initialized
INFO - 2018-03-12 00:20:06 --> Security Class Initialized
DEBUG - 2018-03-12 00:20:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 00:20:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 00:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:20:06 --> Input Class Initialized
INFO - 2018-03-12 00:20:06 --> Input Class Initialized
INFO - 2018-03-12 00:20:06 --> Input Class Initialized
INFO - 2018-03-12 00:20:06 --> Language Class Initialized
INFO - 2018-03-12 00:20:06 --> Language Class Initialized
INFO - 2018-03-12 00:20:06 --> Language Class Initialized
ERROR - 2018-03-12 00:20:06 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-12 00:20:06 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-12 00:20:06 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-12 00:20:06 --> Config Class Initialized
INFO - 2018-03-12 00:20:06 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:20:06 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:20:06 --> Utf8 Class Initialized
INFO - 2018-03-12 00:20:06 --> URI Class Initialized
INFO - 2018-03-12 00:20:06 --> Router Class Initialized
INFO - 2018-03-12 00:20:06 --> Output Class Initialized
INFO - 2018-03-12 00:20:06 --> Security Class Initialized
DEBUG - 2018-03-12 00:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:20:06 --> Input Class Initialized
INFO - 2018-03-12 00:20:06 --> Language Class Initialized
INFO - 2018-03-12 00:20:06 --> Loader Class Initialized
INFO - 2018-03-12 00:20:06 --> Helper loaded: url_helper
INFO - 2018-03-12 00:20:06 --> Helper loaded: form_helper
INFO - 2018-03-12 00:20:06 --> Database Driver Class Initialized
DEBUG - 2018-03-12 00:20:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 00:20:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 00:20:06 --> Form Validation Class Initialized
INFO - 2018-03-12 00:20:06 --> Model Class Initialized
INFO - 2018-03-12 00:20:06 --> Controller Class Initialized
INFO - 2018-03-12 00:20:06 --> Model Class Initialized
INFO - 2018-03-12 00:20:06 --> Model Class Initialized
INFO - 2018-03-12 00:20:06 --> Model Class Initialized
INFO - 2018-03-12 00:20:06 --> Model Class Initialized
INFO - 2018-03-12 00:20:06 --> Model Class Initialized
DEBUG - 2018-03-12 00:20:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-12 00:20:16 --> Config Class Initialized
INFO - 2018-03-12 00:20:16 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:20:16 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:20:16 --> Utf8 Class Initialized
INFO - 2018-03-12 00:20:16 --> URI Class Initialized
INFO - 2018-03-12 00:20:16 --> Router Class Initialized
INFO - 2018-03-12 00:20:16 --> Output Class Initialized
INFO - 2018-03-12 00:20:16 --> Security Class Initialized
DEBUG - 2018-03-12 00:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:20:16 --> Input Class Initialized
INFO - 2018-03-12 00:20:16 --> Language Class Initialized
INFO - 2018-03-12 00:20:16 --> Loader Class Initialized
INFO - 2018-03-12 00:20:16 --> Helper loaded: url_helper
INFO - 2018-03-12 00:20:16 --> Helper loaded: form_helper
INFO - 2018-03-12 00:20:16 --> Database Driver Class Initialized
DEBUG - 2018-03-12 00:20:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 00:20:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 00:20:16 --> Form Validation Class Initialized
INFO - 2018-03-12 00:20:16 --> Model Class Initialized
INFO - 2018-03-12 00:20:16 --> Controller Class Initialized
INFO - 2018-03-12 00:20:16 --> Model Class Initialized
INFO - 2018-03-12 00:20:16 --> Model Class Initialized
INFO - 2018-03-12 00:20:16 --> Model Class Initialized
INFO - 2018-03-12 00:20:16 --> Model Class Initialized
INFO - 2018-03-12 00:20:16 --> Model Class Initialized
DEBUG - 2018-03-12 00:20:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-12 00:20:16 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-12 00:20:16 --> Final output sent to browser
DEBUG - 2018-03-12 00:20:16 --> Total execution time: 0.0813
INFO - 2018-03-12 00:20:17 --> Config Class Initialized
INFO - 2018-03-12 00:20:17 --> Config Class Initialized
INFO - 2018-03-12 00:20:17 --> Hooks Class Initialized
INFO - 2018-03-12 00:20:17 --> Hooks Class Initialized
INFO - 2018-03-12 00:20:17 --> Config Class Initialized
INFO - 2018-03-12 00:20:17 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:20:17 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 00:20:17 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:20:17 --> Utf8 Class Initialized
INFO - 2018-03-12 00:20:17 --> Config Class Initialized
INFO - 2018-03-12 00:20:17 --> Utf8 Class Initialized
INFO - 2018-03-12 00:20:17 --> Hooks Class Initialized
INFO - 2018-03-12 00:20:17 --> URI Class Initialized
DEBUG - 2018-03-12 00:20:17 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:20:17 --> URI Class Initialized
INFO - 2018-03-12 00:20:17 --> Utf8 Class Initialized
DEBUG - 2018-03-12 00:20:17 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:20:17 --> URI Class Initialized
INFO - 2018-03-12 00:20:17 --> Utf8 Class Initialized
INFO - 2018-03-12 00:20:17 --> Router Class Initialized
INFO - 2018-03-12 00:20:17 --> Router Class Initialized
INFO - 2018-03-12 00:20:17 --> URI Class Initialized
INFO - 2018-03-12 00:20:17 --> Output Class Initialized
INFO - 2018-03-12 00:20:17 --> Router Class Initialized
INFO - 2018-03-12 00:20:17 --> Output Class Initialized
INFO - 2018-03-12 00:20:17 --> Router Class Initialized
INFO - 2018-03-12 00:20:17 --> Security Class Initialized
INFO - 2018-03-12 00:20:17 --> Security Class Initialized
INFO - 2018-03-12 00:20:17 --> Output Class Initialized
INFO - 2018-03-12 00:20:17 --> Output Class Initialized
DEBUG - 2018-03-12 00:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:20:17 --> Input Class Initialized
DEBUG - 2018-03-12 00:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:20:17 --> Security Class Initialized
INFO - 2018-03-12 00:20:17 --> Security Class Initialized
INFO - 2018-03-12 00:20:17 --> Input Class Initialized
INFO - 2018-03-12 00:20:17 --> Language Class Initialized
INFO - 2018-03-12 00:20:17 --> Language Class Initialized
DEBUG - 2018-03-12 00:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:20:17 --> Input Class Initialized
DEBUG - 2018-03-12 00:20:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-03-12 00:20:17 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-12 00:20:17 --> Input Class Initialized
ERROR - 2018-03-12 00:20:17 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-12 00:20:17 --> Language Class Initialized
INFO - 2018-03-12 00:20:17 --> Language Class Initialized
ERROR - 2018-03-12 00:20:17 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-12 00:20:17 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-12 00:20:17 --> Config Class Initialized
INFO - 2018-03-12 00:20:17 --> Hooks Class Initialized
INFO - 2018-03-12 00:20:17 --> Config Class Initialized
INFO - 2018-03-12 00:20:17 --> Hooks Class Initialized
INFO - 2018-03-12 00:20:17 --> Config Class Initialized
INFO - 2018-03-12 00:20:17 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:20:17 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:20:17 --> Utf8 Class Initialized
DEBUG - 2018-03-12 00:20:17 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:20:17 --> Utf8 Class Initialized
INFO - 2018-03-12 00:20:17 --> URI Class Initialized
INFO - 2018-03-12 00:20:17 --> URI Class Initialized
DEBUG - 2018-03-12 00:20:17 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:20:17 --> Utf8 Class Initialized
INFO - 2018-03-12 00:20:17 --> Router Class Initialized
INFO - 2018-03-12 00:20:17 --> Router Class Initialized
INFO - 2018-03-12 00:20:17 --> URI Class Initialized
INFO - 2018-03-12 00:20:17 --> Output Class Initialized
INFO - 2018-03-12 00:20:17 --> Output Class Initialized
INFO - 2018-03-12 00:20:17 --> Security Class Initialized
INFO - 2018-03-12 00:20:17 --> Router Class Initialized
INFO - 2018-03-12 00:20:17 --> Security Class Initialized
DEBUG - 2018-03-12 00:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:20:17 --> Input Class Initialized
DEBUG - 2018-03-12 00:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:20:17 --> Input Class Initialized
INFO - 2018-03-12 00:20:17 --> Output Class Initialized
INFO - 2018-03-12 00:20:17 --> Language Class Initialized
INFO - 2018-03-12 00:20:17 --> Language Class Initialized
ERROR - 2018-03-12 00:20:17 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-12 00:20:17 --> Security Class Initialized
ERROR - 2018-03-12 00:20:17 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-03-12 00:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:20:17 --> Input Class Initialized
INFO - 2018-03-12 00:20:17 --> Language Class Initialized
ERROR - 2018-03-12 00:20:17 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-12 00:20:17 --> Config Class Initialized
INFO - 2018-03-12 00:20:17 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:20:17 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:20:17 --> Utf8 Class Initialized
INFO - 2018-03-12 00:20:17 --> URI Class Initialized
INFO - 2018-03-12 00:20:17 --> Router Class Initialized
INFO - 2018-03-12 00:20:17 --> Output Class Initialized
INFO - 2018-03-12 00:20:17 --> Security Class Initialized
DEBUG - 2018-03-12 00:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:20:17 --> Input Class Initialized
INFO - 2018-03-12 00:20:17 --> Language Class Initialized
INFO - 2018-03-12 00:20:17 --> Loader Class Initialized
INFO - 2018-03-12 00:20:17 --> Helper loaded: url_helper
INFO - 2018-03-12 00:20:17 --> Helper loaded: form_helper
INFO - 2018-03-12 00:20:17 --> Database Driver Class Initialized
DEBUG - 2018-03-12 00:20:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 00:20:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 00:20:17 --> Form Validation Class Initialized
INFO - 2018-03-12 00:20:17 --> Model Class Initialized
INFO - 2018-03-12 00:20:17 --> Controller Class Initialized
INFO - 2018-03-12 00:20:17 --> Model Class Initialized
INFO - 2018-03-12 00:20:17 --> Model Class Initialized
INFO - 2018-03-12 00:20:17 --> Model Class Initialized
INFO - 2018-03-12 00:20:17 --> Model Class Initialized
INFO - 2018-03-12 00:20:17 --> Model Class Initialized
DEBUG - 2018-03-12 00:20:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-12 00:20:24 --> Config Class Initialized
INFO - 2018-03-12 00:20:24 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:20:24 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:20:24 --> Utf8 Class Initialized
INFO - 2018-03-12 00:20:24 --> URI Class Initialized
INFO - 2018-03-12 00:20:24 --> Router Class Initialized
INFO - 2018-03-12 00:20:24 --> Output Class Initialized
INFO - 2018-03-12 00:20:24 --> Security Class Initialized
DEBUG - 2018-03-12 00:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:20:24 --> Input Class Initialized
INFO - 2018-03-12 00:20:24 --> Language Class Initialized
INFO - 2018-03-12 00:20:24 --> Loader Class Initialized
INFO - 2018-03-12 00:20:24 --> Helper loaded: url_helper
INFO - 2018-03-12 00:20:24 --> Helper loaded: form_helper
INFO - 2018-03-12 00:20:24 --> Database Driver Class Initialized
DEBUG - 2018-03-12 00:20:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 00:20:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 00:20:24 --> Form Validation Class Initialized
INFO - 2018-03-12 00:20:24 --> Model Class Initialized
INFO - 2018-03-12 00:20:24 --> Controller Class Initialized
INFO - 2018-03-12 00:20:24 --> Model Class Initialized
INFO - 2018-03-12 00:20:24 --> Model Class Initialized
INFO - 2018-03-12 00:20:24 --> Model Class Initialized
INFO - 2018-03-12 00:20:24 --> Model Class Initialized
INFO - 2018-03-12 00:20:24 --> Model Class Initialized
DEBUG - 2018-03-12 00:20:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-12 00:20:24 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-12 00:20:24 --> Final output sent to browser
DEBUG - 2018-03-12 00:20:24 --> Total execution time: 0.0724
INFO - 2018-03-12 00:20:24 --> Config Class Initialized
INFO - 2018-03-12 00:20:24 --> Hooks Class Initialized
INFO - 2018-03-12 00:20:24 --> Config Class Initialized
INFO - 2018-03-12 00:20:24 --> Hooks Class Initialized
INFO - 2018-03-12 00:20:24 --> Config Class Initialized
DEBUG - 2018-03-12 00:20:24 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:20:24 --> Hooks Class Initialized
INFO - 2018-03-12 00:20:24 --> Utf8 Class Initialized
DEBUG - 2018-03-12 00:20:24 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:20:24 --> Utf8 Class Initialized
INFO - 2018-03-12 00:20:24 --> URI Class Initialized
INFO - 2018-03-12 00:20:24 --> URI Class Initialized
INFO - 2018-03-12 00:20:24 --> Config Class Initialized
INFO - 2018-03-12 00:20:24 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:20:24 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:20:24 --> Utf8 Class Initialized
INFO - 2018-03-12 00:20:24 --> Router Class Initialized
INFO - 2018-03-12 00:20:24 --> Router Class Initialized
INFO - 2018-03-12 00:20:24 --> URI Class Initialized
DEBUG - 2018-03-12 00:20:24 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:20:24 --> Output Class Initialized
INFO - 2018-03-12 00:20:24 --> Output Class Initialized
INFO - 2018-03-12 00:20:24 --> Utf8 Class Initialized
INFO - 2018-03-12 00:20:24 --> Router Class Initialized
INFO - 2018-03-12 00:20:24 --> Security Class Initialized
INFO - 2018-03-12 00:20:24 --> URI Class Initialized
INFO - 2018-03-12 00:20:24 --> Security Class Initialized
DEBUG - 2018-03-12 00:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:20:24 --> Input Class Initialized
DEBUG - 2018-03-12 00:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:20:24 --> Output Class Initialized
INFO - 2018-03-12 00:20:24 --> Input Class Initialized
INFO - 2018-03-12 00:20:24 --> Router Class Initialized
INFO - 2018-03-12 00:20:24 --> Language Class Initialized
INFO - 2018-03-12 00:20:24 --> Language Class Initialized
INFO - 2018-03-12 00:20:24 --> Security Class Initialized
ERROR - 2018-03-12 00:20:24 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-12 00:20:24 --> Output Class Initialized
ERROR - 2018-03-12 00:20:24 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-12 00:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:20:24 --> Security Class Initialized
INFO - 2018-03-12 00:20:24 --> Input Class Initialized
INFO - 2018-03-12 00:20:24 --> Language Class Initialized
DEBUG - 2018-03-12 00:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:20:24 --> Input Class Initialized
ERROR - 2018-03-12 00:20:24 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-12 00:20:24 --> Language Class Initialized
ERROR - 2018-03-12 00:20:24 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-12 00:20:24 --> Config Class Initialized
INFO - 2018-03-12 00:20:24 --> Hooks Class Initialized
INFO - 2018-03-12 00:20:24 --> Config Class Initialized
INFO - 2018-03-12 00:20:24 --> Hooks Class Initialized
INFO - 2018-03-12 00:20:24 --> Config Class Initialized
INFO - 2018-03-12 00:20:24 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:20:24 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:20:24 --> Utf8 Class Initialized
DEBUG - 2018-03-12 00:20:24 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:20:24 --> Utf8 Class Initialized
INFO - 2018-03-12 00:20:24 --> URI Class Initialized
DEBUG - 2018-03-12 00:20:24 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:20:24 --> Utf8 Class Initialized
INFO - 2018-03-12 00:20:24 --> URI Class Initialized
INFO - 2018-03-12 00:20:24 --> Router Class Initialized
INFO - 2018-03-12 00:20:24 --> URI Class Initialized
INFO - 2018-03-12 00:20:24 --> Router Class Initialized
INFO - 2018-03-12 00:20:24 --> Output Class Initialized
INFO - 2018-03-12 00:20:24 --> Router Class Initialized
INFO - 2018-03-12 00:20:24 --> Security Class Initialized
INFO - 2018-03-12 00:20:24 --> Output Class Initialized
INFO - 2018-03-12 00:20:24 --> Output Class Initialized
DEBUG - 2018-03-12 00:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:20:24 --> Security Class Initialized
INFO - 2018-03-12 00:20:24 --> Input Class Initialized
INFO - 2018-03-12 00:20:24 --> Security Class Initialized
INFO - 2018-03-12 00:20:24 --> Language Class Initialized
DEBUG - 2018-03-12 00:20:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 00:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:20:24 --> Input Class Initialized
INFO - 2018-03-12 00:20:24 --> Input Class Initialized
INFO - 2018-03-12 00:20:24 --> Language Class Initialized
INFO - 2018-03-12 00:20:24 --> Language Class Initialized
ERROR - 2018-03-12 00:20:24 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-12 00:20:24 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-12 00:20:24 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-12 00:20:24 --> Config Class Initialized
INFO - 2018-03-12 00:20:24 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:20:24 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:20:24 --> Utf8 Class Initialized
INFO - 2018-03-12 00:20:24 --> URI Class Initialized
INFO - 2018-03-12 00:20:24 --> Router Class Initialized
INFO - 2018-03-12 00:20:24 --> Output Class Initialized
INFO - 2018-03-12 00:20:24 --> Security Class Initialized
DEBUG - 2018-03-12 00:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:20:24 --> Input Class Initialized
INFO - 2018-03-12 00:20:24 --> Language Class Initialized
INFO - 2018-03-12 00:20:24 --> Loader Class Initialized
INFO - 2018-03-12 00:20:24 --> Helper loaded: url_helper
INFO - 2018-03-12 00:20:24 --> Helper loaded: form_helper
INFO - 2018-03-12 00:20:24 --> Database Driver Class Initialized
DEBUG - 2018-03-12 00:20:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 00:20:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 00:20:24 --> Form Validation Class Initialized
INFO - 2018-03-12 00:20:24 --> Model Class Initialized
INFO - 2018-03-12 00:20:24 --> Controller Class Initialized
INFO - 2018-03-12 00:20:24 --> Model Class Initialized
INFO - 2018-03-12 00:20:24 --> Model Class Initialized
INFO - 2018-03-12 00:20:24 --> Model Class Initialized
INFO - 2018-03-12 00:20:24 --> Model Class Initialized
INFO - 2018-03-12 00:20:24 --> Model Class Initialized
DEBUG - 2018-03-12 00:20:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-12 00:21:03 --> Config Class Initialized
INFO - 2018-03-12 00:21:03 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:21:03 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:21:03 --> Utf8 Class Initialized
INFO - 2018-03-12 00:21:03 --> URI Class Initialized
INFO - 2018-03-12 00:21:03 --> Router Class Initialized
INFO - 2018-03-12 00:21:03 --> Output Class Initialized
INFO - 2018-03-12 00:21:03 --> Security Class Initialized
DEBUG - 2018-03-12 00:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:21:03 --> Input Class Initialized
INFO - 2018-03-12 00:21:03 --> Language Class Initialized
INFO - 2018-03-12 00:21:03 --> Loader Class Initialized
INFO - 2018-03-12 00:21:03 --> Helper loaded: url_helper
INFO - 2018-03-12 00:21:03 --> Helper loaded: form_helper
INFO - 2018-03-12 00:21:03 --> Database Driver Class Initialized
DEBUG - 2018-03-12 00:21:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 00:21:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 00:21:03 --> Form Validation Class Initialized
INFO - 2018-03-12 00:21:03 --> Model Class Initialized
INFO - 2018-03-12 00:21:03 --> Controller Class Initialized
INFO - 2018-03-12 00:21:03 --> Model Class Initialized
INFO - 2018-03-12 00:21:03 --> Model Class Initialized
INFO - 2018-03-12 00:21:03 --> Model Class Initialized
INFO - 2018-03-12 00:21:03 --> Model Class Initialized
INFO - 2018-03-12 00:21:03 --> Model Class Initialized
DEBUG - 2018-03-12 00:21:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-12 00:21:03 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-12 00:21:03 --> Final output sent to browser
DEBUG - 2018-03-12 00:21:03 --> Total execution time: 0.3538
INFO - 2018-03-12 00:21:03 --> Config Class Initialized
INFO - 2018-03-12 00:21:03 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:21:03 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:21:03 --> Utf8 Class Initialized
INFO - 2018-03-12 00:21:03 --> URI Class Initialized
INFO - 2018-03-12 00:21:03 --> Router Class Initialized
INFO - 2018-03-12 00:21:03 --> Output Class Initialized
INFO - 2018-03-12 00:21:03 --> Security Class Initialized
DEBUG - 2018-03-12 00:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:21:03 --> Input Class Initialized
INFO - 2018-03-12 00:21:03 --> Language Class Initialized
INFO - 2018-03-12 00:21:03 --> Loader Class Initialized
INFO - 2018-03-12 00:21:03 --> Helper loaded: url_helper
INFO - 2018-03-12 00:21:03 --> Helper loaded: form_helper
INFO - 2018-03-12 00:21:03 --> Database Driver Class Initialized
DEBUG - 2018-03-12 00:21:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 00:21:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 00:21:03 --> Form Validation Class Initialized
INFO - 2018-03-12 00:21:03 --> Model Class Initialized
INFO - 2018-03-12 00:21:03 --> Controller Class Initialized
INFO - 2018-03-12 00:21:03 --> Model Class Initialized
INFO - 2018-03-12 00:21:03 --> Model Class Initialized
INFO - 2018-03-12 00:21:03 --> Model Class Initialized
INFO - 2018-03-12 00:21:03 --> Model Class Initialized
INFO - 2018-03-12 00:21:03 --> Model Class Initialized
DEBUG - 2018-03-12 00:21:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-12 00:21:05 --> Config Class Initialized
INFO - 2018-03-12 00:21:05 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:21:05 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:21:05 --> Utf8 Class Initialized
INFO - 2018-03-12 00:21:05 --> URI Class Initialized
INFO - 2018-03-12 00:21:05 --> Router Class Initialized
INFO - 2018-03-12 00:21:05 --> Output Class Initialized
INFO - 2018-03-12 00:21:05 --> Security Class Initialized
DEBUG - 2018-03-12 00:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:21:05 --> Input Class Initialized
INFO - 2018-03-12 00:21:05 --> Language Class Initialized
INFO - 2018-03-12 00:21:05 --> Loader Class Initialized
INFO - 2018-03-12 00:21:05 --> Helper loaded: url_helper
INFO - 2018-03-12 00:21:05 --> Helper loaded: form_helper
INFO - 2018-03-12 00:21:05 --> Database Driver Class Initialized
DEBUG - 2018-03-12 00:21:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 00:21:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 00:21:05 --> Form Validation Class Initialized
INFO - 2018-03-12 00:21:05 --> Model Class Initialized
INFO - 2018-03-12 00:21:05 --> Controller Class Initialized
INFO - 2018-03-12 00:21:05 --> Model Class Initialized
INFO - 2018-03-12 00:21:05 --> Model Class Initialized
INFO - 2018-03-12 00:21:05 --> Model Class Initialized
INFO - 2018-03-12 00:21:05 --> Model Class Initialized
INFO - 2018-03-12 00:21:05 --> Model Class Initialized
DEBUG - 2018-03-12 00:21:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-12 00:21:05 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-12 00:21:05 --> Final output sent to browser
DEBUG - 2018-03-12 00:21:05 --> Total execution time: 0.0653
INFO - 2018-03-12 00:21:05 --> Config Class Initialized
INFO - 2018-03-12 00:21:05 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:21:05 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:21:05 --> Utf8 Class Initialized
INFO - 2018-03-12 00:21:05 --> URI Class Initialized
INFO - 2018-03-12 00:21:05 --> Router Class Initialized
INFO - 2018-03-12 00:21:05 --> Output Class Initialized
INFO - 2018-03-12 00:21:05 --> Security Class Initialized
DEBUG - 2018-03-12 00:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:21:05 --> Input Class Initialized
INFO - 2018-03-12 00:21:05 --> Language Class Initialized
INFO - 2018-03-12 00:21:05 --> Loader Class Initialized
INFO - 2018-03-12 00:21:05 --> Helper loaded: url_helper
INFO - 2018-03-12 00:21:05 --> Helper loaded: form_helper
INFO - 2018-03-12 00:21:05 --> Database Driver Class Initialized
DEBUG - 2018-03-12 00:21:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 00:21:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 00:21:05 --> Form Validation Class Initialized
INFO - 2018-03-12 00:21:05 --> Model Class Initialized
INFO - 2018-03-12 00:21:05 --> Controller Class Initialized
INFO - 2018-03-12 00:21:05 --> Model Class Initialized
INFO - 2018-03-12 00:21:05 --> Model Class Initialized
INFO - 2018-03-12 00:21:05 --> Model Class Initialized
INFO - 2018-03-12 00:21:05 --> Model Class Initialized
INFO - 2018-03-12 00:21:05 --> Model Class Initialized
DEBUG - 2018-03-12 00:21:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-12 00:21:11 --> Config Class Initialized
INFO - 2018-03-12 00:21:11 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:21:11 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:21:11 --> Utf8 Class Initialized
INFO - 2018-03-12 00:21:11 --> URI Class Initialized
INFO - 2018-03-12 00:21:11 --> Router Class Initialized
INFO - 2018-03-12 00:21:11 --> Output Class Initialized
INFO - 2018-03-12 00:21:11 --> Security Class Initialized
DEBUG - 2018-03-12 00:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:21:11 --> Input Class Initialized
INFO - 2018-03-12 00:21:11 --> Language Class Initialized
INFO - 2018-03-12 00:21:11 --> Loader Class Initialized
INFO - 2018-03-12 00:21:11 --> Helper loaded: url_helper
INFO - 2018-03-12 00:21:11 --> Helper loaded: form_helper
INFO - 2018-03-12 00:21:11 --> Database Driver Class Initialized
DEBUG - 2018-03-12 00:21:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 00:21:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 00:21:11 --> Form Validation Class Initialized
INFO - 2018-03-12 00:21:11 --> Model Class Initialized
INFO - 2018-03-12 00:21:11 --> Controller Class Initialized
INFO - 2018-03-12 00:21:11 --> Model Class Initialized
INFO - 2018-03-12 00:21:11 --> Model Class Initialized
INFO - 2018-03-12 00:21:11 --> Model Class Initialized
INFO - 2018-03-12 00:21:11 --> Model Class Initialized
INFO - 2018-03-12 00:21:11 --> Model Class Initialized
DEBUG - 2018-03-12 00:21:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-12 00:21:11 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-12 00:21:11 --> Final output sent to browser
DEBUG - 2018-03-12 00:21:11 --> Total execution time: 0.0618
INFO - 2018-03-12 00:21:11 --> Config Class Initialized
INFO - 2018-03-12 00:21:11 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:21:11 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:21:11 --> Utf8 Class Initialized
INFO - 2018-03-12 00:21:11 --> URI Class Initialized
INFO - 2018-03-12 00:21:11 --> Router Class Initialized
INFO - 2018-03-12 00:21:11 --> Output Class Initialized
INFO - 2018-03-12 00:21:11 --> Security Class Initialized
DEBUG - 2018-03-12 00:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:21:11 --> Input Class Initialized
INFO - 2018-03-12 00:21:11 --> Language Class Initialized
INFO - 2018-03-12 00:21:11 --> Loader Class Initialized
INFO - 2018-03-12 00:21:11 --> Helper loaded: url_helper
INFO - 2018-03-12 00:21:11 --> Helper loaded: form_helper
INFO - 2018-03-12 00:21:11 --> Database Driver Class Initialized
DEBUG - 2018-03-12 00:21:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 00:21:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 00:21:11 --> Form Validation Class Initialized
INFO - 2018-03-12 00:21:11 --> Model Class Initialized
INFO - 2018-03-12 00:21:11 --> Controller Class Initialized
INFO - 2018-03-12 00:21:11 --> Model Class Initialized
INFO - 2018-03-12 00:21:11 --> Model Class Initialized
INFO - 2018-03-12 00:21:11 --> Model Class Initialized
INFO - 2018-03-12 00:21:11 --> Model Class Initialized
INFO - 2018-03-12 00:21:11 --> Model Class Initialized
DEBUG - 2018-03-12 00:21:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-12 00:21:13 --> Config Class Initialized
INFO - 2018-03-12 00:21:13 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:21:13 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:21:13 --> Utf8 Class Initialized
INFO - 2018-03-12 00:21:13 --> URI Class Initialized
INFO - 2018-03-12 00:21:13 --> Router Class Initialized
INFO - 2018-03-12 00:21:13 --> Output Class Initialized
INFO - 2018-03-12 00:21:13 --> Security Class Initialized
DEBUG - 2018-03-12 00:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:21:13 --> Input Class Initialized
INFO - 2018-03-12 00:21:13 --> Language Class Initialized
INFO - 2018-03-12 00:21:13 --> Loader Class Initialized
INFO - 2018-03-12 00:21:13 --> Helper loaded: url_helper
INFO - 2018-03-12 00:21:13 --> Helper loaded: form_helper
INFO - 2018-03-12 00:21:13 --> Database Driver Class Initialized
DEBUG - 2018-03-12 00:21:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 00:21:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 00:21:13 --> Form Validation Class Initialized
INFO - 2018-03-12 00:21:13 --> Model Class Initialized
INFO - 2018-03-12 00:21:13 --> Controller Class Initialized
INFO - 2018-03-12 00:21:13 --> Model Class Initialized
INFO - 2018-03-12 00:21:13 --> Model Class Initialized
INFO - 2018-03-12 00:21:13 --> Model Class Initialized
INFO - 2018-03-12 00:21:13 --> Model Class Initialized
INFO - 2018-03-12 00:21:13 --> Model Class Initialized
DEBUG - 2018-03-12 00:21:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-12 00:21:13 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-12 00:21:13 --> Final output sent to browser
DEBUG - 2018-03-12 00:21:13 --> Total execution time: 0.0486
INFO - 2018-03-12 00:21:13 --> Config Class Initialized
INFO - 2018-03-12 00:21:13 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:21:13 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:21:13 --> Utf8 Class Initialized
INFO - 2018-03-12 00:21:13 --> URI Class Initialized
INFO - 2018-03-12 00:21:13 --> Router Class Initialized
INFO - 2018-03-12 00:21:13 --> Output Class Initialized
INFO - 2018-03-12 00:21:13 --> Security Class Initialized
DEBUG - 2018-03-12 00:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:21:13 --> Input Class Initialized
INFO - 2018-03-12 00:21:13 --> Language Class Initialized
INFO - 2018-03-12 00:21:13 --> Loader Class Initialized
INFO - 2018-03-12 00:21:13 --> Helper loaded: url_helper
INFO - 2018-03-12 00:21:13 --> Helper loaded: form_helper
INFO - 2018-03-12 00:21:13 --> Database Driver Class Initialized
DEBUG - 2018-03-12 00:21:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 00:21:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 00:21:13 --> Form Validation Class Initialized
INFO - 2018-03-12 00:21:13 --> Model Class Initialized
INFO - 2018-03-12 00:21:13 --> Controller Class Initialized
INFO - 2018-03-12 00:21:13 --> Model Class Initialized
INFO - 2018-03-12 00:21:13 --> Model Class Initialized
INFO - 2018-03-12 00:21:13 --> Model Class Initialized
INFO - 2018-03-12 00:21:13 --> Model Class Initialized
INFO - 2018-03-12 00:21:13 --> Model Class Initialized
DEBUG - 2018-03-12 00:21:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-12 00:21:25 --> Config Class Initialized
INFO - 2018-03-12 00:21:25 --> Hooks Class Initialized
INFO - 2018-03-12 00:21:25 --> Config Class Initialized
INFO - 2018-03-12 00:21:25 --> Hooks Class Initialized
INFO - 2018-03-12 00:21:25 --> Config Class Initialized
INFO - 2018-03-12 00:21:25 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:21:25 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 00:21:25 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:21:25 --> Utf8 Class Initialized
INFO - 2018-03-12 00:21:25 --> Utf8 Class Initialized
INFO - 2018-03-12 00:21:25 --> URI Class Initialized
DEBUG - 2018-03-12 00:21:25 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:21:25 --> URI Class Initialized
INFO - 2018-03-12 00:21:25 --> Utf8 Class Initialized
INFO - 2018-03-12 00:21:25 --> Router Class Initialized
INFO - 2018-03-12 00:21:25 --> URI Class Initialized
INFO - 2018-03-12 00:21:25 --> Router Class Initialized
INFO - 2018-03-12 00:21:25 --> Output Class Initialized
INFO - 2018-03-12 00:21:25 --> Router Class Initialized
INFO - 2018-03-12 00:21:25 --> Output Class Initialized
INFO - 2018-03-12 00:21:25 --> Security Class Initialized
INFO - 2018-03-12 00:21:25 --> Output Class Initialized
DEBUG - 2018-03-12 00:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:21:25 --> Input Class Initialized
INFO - 2018-03-12 00:21:25 --> Security Class Initialized
INFO - 2018-03-12 00:21:25 --> Language Class Initialized
INFO - 2018-03-12 00:21:25 --> Security Class Initialized
DEBUG - 2018-03-12 00:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:21:25 --> Input Class Initialized
ERROR - 2018-03-12 00:21:25 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-12 00:21:25 --> Language Class Initialized
DEBUG - 2018-03-12 00:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:21:25 --> Input Class Initialized
INFO - 2018-03-12 00:21:25 --> Language Class Initialized
ERROR - 2018-03-12 00:21:25 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-12 00:21:25 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-12 00:21:29 --> Config Class Initialized
INFO - 2018-03-12 00:21:29 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:21:29 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:21:29 --> Utf8 Class Initialized
INFO - 2018-03-12 00:21:29 --> URI Class Initialized
INFO - 2018-03-12 00:21:29 --> Router Class Initialized
INFO - 2018-03-12 00:21:29 --> Output Class Initialized
INFO - 2018-03-12 00:21:29 --> Security Class Initialized
DEBUG - 2018-03-12 00:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:21:29 --> Input Class Initialized
INFO - 2018-03-12 00:21:29 --> Language Class Initialized
INFO - 2018-03-12 00:21:29 --> Loader Class Initialized
INFO - 2018-03-12 00:21:29 --> Helper loaded: url_helper
INFO - 2018-03-12 00:21:29 --> Helper loaded: form_helper
INFO - 2018-03-12 00:21:29 --> Database Driver Class Initialized
DEBUG - 2018-03-12 00:21:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 00:21:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 00:21:29 --> Form Validation Class Initialized
INFO - 2018-03-12 00:21:29 --> Model Class Initialized
INFO - 2018-03-12 00:21:29 --> Controller Class Initialized
INFO - 2018-03-12 00:21:29 --> Model Class Initialized
INFO - 2018-03-12 00:21:29 --> Model Class Initialized
INFO - 2018-03-12 00:21:29 --> Model Class Initialized
INFO - 2018-03-12 00:21:29 --> Model Class Initialized
INFO - 2018-03-12 00:21:29 --> Model Class Initialized
DEBUG - 2018-03-12 00:21:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-12 00:21:29 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-12 00:21:29 --> Final output sent to browser
DEBUG - 2018-03-12 00:21:29 --> Total execution time: 0.0806
INFO - 2018-03-12 00:21:29 --> Config Class Initialized
INFO - 2018-03-12 00:21:29 --> Hooks Class Initialized
INFO - 2018-03-12 00:21:29 --> Config Class Initialized
INFO - 2018-03-12 00:21:29 --> Hooks Class Initialized
INFO - 2018-03-12 00:21:29 --> Config Class Initialized
INFO - 2018-03-12 00:21:29 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:21:29 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:21:29 --> Utf8 Class Initialized
DEBUG - 2018-03-12 00:21:29 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:21:29 --> Utf8 Class Initialized
INFO - 2018-03-12 00:21:29 --> URI Class Initialized
INFO - 2018-03-12 00:21:29 --> URI Class Initialized
DEBUG - 2018-03-12 00:21:29 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:21:29 --> Utf8 Class Initialized
INFO - 2018-03-12 00:21:29 --> Router Class Initialized
INFO - 2018-03-12 00:21:29 --> URI Class Initialized
INFO - 2018-03-12 00:21:29 --> Router Class Initialized
INFO - 2018-03-12 00:21:29 --> Config Class Initialized
INFO - 2018-03-12 00:21:29 --> Hooks Class Initialized
INFO - 2018-03-12 00:21:29 --> Router Class Initialized
INFO - 2018-03-12 00:21:29 --> Output Class Initialized
INFO - 2018-03-12 00:21:29 --> Output Class Initialized
INFO - 2018-03-12 00:21:29 --> Security Class Initialized
INFO - 2018-03-12 00:21:29 --> Output Class Initialized
INFO - 2018-03-12 00:21:29 --> Security Class Initialized
DEBUG - 2018-03-12 00:21:29 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:21:29 --> Utf8 Class Initialized
DEBUG - 2018-03-12 00:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:21:29 --> Input Class Initialized
INFO - 2018-03-12 00:21:29 --> Security Class Initialized
DEBUG - 2018-03-12 00:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:21:29 --> URI Class Initialized
INFO - 2018-03-12 00:21:29 --> Input Class Initialized
INFO - 2018-03-12 00:21:29 --> Language Class Initialized
INFO - 2018-03-12 00:21:29 --> Language Class Initialized
DEBUG - 2018-03-12 00:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:21:29 --> Input Class Initialized
INFO - 2018-03-12 00:21:29 --> Router Class Initialized
ERROR - 2018-03-12 00:21:29 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-12 00:21:29 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-12 00:21:29 --> Language Class Initialized
INFO - 2018-03-12 00:21:29 --> Output Class Initialized
ERROR - 2018-03-12 00:21:29 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-12 00:21:29 --> Security Class Initialized
DEBUG - 2018-03-12 00:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:21:29 --> Input Class Initialized
INFO - 2018-03-12 00:21:29 --> Language Class Initialized
ERROR - 2018-03-12 00:21:29 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-12 00:21:29 --> Config Class Initialized
INFO - 2018-03-12 00:21:29 --> Hooks Class Initialized
INFO - 2018-03-12 00:21:29 --> Config Class Initialized
INFO - 2018-03-12 00:21:29 --> Hooks Class Initialized
INFO - 2018-03-12 00:21:29 --> Config Class Initialized
INFO - 2018-03-12 00:21:29 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:21:29 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:21:29 --> Utf8 Class Initialized
DEBUG - 2018-03-12 00:21:29 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:21:29 --> Utf8 Class Initialized
INFO - 2018-03-12 00:21:29 --> URI Class Initialized
DEBUG - 2018-03-12 00:21:29 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:21:29 --> Utf8 Class Initialized
INFO - 2018-03-12 00:21:29 --> URI Class Initialized
INFO - 2018-03-12 00:21:29 --> URI Class Initialized
INFO - 2018-03-12 00:21:29 --> Router Class Initialized
INFO - 2018-03-12 00:21:29 --> Router Class Initialized
INFO - 2018-03-12 00:21:29 --> Router Class Initialized
INFO - 2018-03-12 00:21:29 --> Output Class Initialized
INFO - 2018-03-12 00:21:29 --> Output Class Initialized
INFO - 2018-03-12 00:21:29 --> Output Class Initialized
INFO - 2018-03-12 00:21:29 --> Security Class Initialized
INFO - 2018-03-12 00:21:29 --> Security Class Initialized
INFO - 2018-03-12 00:21:29 --> Security Class Initialized
DEBUG - 2018-03-12 00:21:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 00:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:21:29 --> Input Class Initialized
INFO - 2018-03-12 00:21:29 --> Input Class Initialized
DEBUG - 2018-03-12 00:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:21:29 --> Input Class Initialized
INFO - 2018-03-12 00:21:29 --> Language Class Initialized
INFO - 2018-03-12 00:21:29 --> Language Class Initialized
INFO - 2018-03-12 00:21:29 --> Language Class Initialized
ERROR - 2018-03-12 00:21:29 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-12 00:21:29 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-12 00:21:29 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-12 00:21:29 --> Config Class Initialized
INFO - 2018-03-12 00:21:29 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:21:29 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:21:29 --> Utf8 Class Initialized
INFO - 2018-03-12 00:21:29 --> URI Class Initialized
INFO - 2018-03-12 00:21:29 --> Router Class Initialized
INFO - 2018-03-12 00:21:29 --> Output Class Initialized
INFO - 2018-03-12 00:21:29 --> Security Class Initialized
DEBUG - 2018-03-12 00:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:21:29 --> Input Class Initialized
INFO - 2018-03-12 00:21:29 --> Language Class Initialized
INFO - 2018-03-12 00:21:29 --> Loader Class Initialized
INFO - 2018-03-12 00:21:29 --> Helper loaded: url_helper
INFO - 2018-03-12 00:21:29 --> Helper loaded: form_helper
INFO - 2018-03-12 00:21:29 --> Database Driver Class Initialized
DEBUG - 2018-03-12 00:21:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 00:21:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 00:21:29 --> Form Validation Class Initialized
INFO - 2018-03-12 00:21:29 --> Model Class Initialized
INFO - 2018-03-12 00:21:29 --> Controller Class Initialized
INFO - 2018-03-12 00:21:29 --> Model Class Initialized
INFO - 2018-03-12 00:21:29 --> Model Class Initialized
INFO - 2018-03-12 00:21:29 --> Model Class Initialized
INFO - 2018-03-12 00:21:29 --> Model Class Initialized
INFO - 2018-03-12 00:21:29 --> Model Class Initialized
DEBUG - 2018-03-12 00:21:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-12 00:24:18 --> Config Class Initialized
INFO - 2018-03-12 00:24:18 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:24:18 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:24:18 --> Utf8 Class Initialized
INFO - 2018-03-12 00:24:18 --> URI Class Initialized
INFO - 2018-03-12 00:24:18 --> Router Class Initialized
INFO - 2018-03-12 00:24:18 --> Output Class Initialized
INFO - 2018-03-12 00:24:18 --> Security Class Initialized
DEBUG - 2018-03-12 00:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:24:18 --> Input Class Initialized
INFO - 2018-03-12 00:24:18 --> Language Class Initialized
INFO - 2018-03-12 00:24:18 --> Loader Class Initialized
INFO - 2018-03-12 00:24:18 --> Helper loaded: url_helper
INFO - 2018-03-12 00:24:18 --> Helper loaded: form_helper
INFO - 2018-03-12 00:24:18 --> Database Driver Class Initialized
DEBUG - 2018-03-12 00:24:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 00:24:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 00:24:18 --> Form Validation Class Initialized
INFO - 2018-03-12 00:24:18 --> Model Class Initialized
INFO - 2018-03-12 00:24:18 --> Controller Class Initialized
INFO - 2018-03-12 00:24:18 --> Model Class Initialized
INFO - 2018-03-12 00:24:18 --> Model Class Initialized
INFO - 2018-03-12 00:24:18 --> Model Class Initialized
INFO - 2018-03-12 00:24:18 --> Model Class Initialized
INFO - 2018-03-12 00:24:18 --> Model Class Initialized
DEBUG - 2018-03-12 00:24:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-12 00:24:18 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-12 00:24:18 --> Final output sent to browser
DEBUG - 2018-03-12 00:24:18 --> Total execution time: 0.0918
INFO - 2018-03-12 00:24:19 --> Config Class Initialized
INFO - 2018-03-12 00:24:19 --> Hooks Class Initialized
INFO - 2018-03-12 00:24:19 --> Config Class Initialized
INFO - 2018-03-12 00:24:19 --> Hooks Class Initialized
INFO - 2018-03-12 00:24:19 --> Config Class Initialized
INFO - 2018-03-12 00:24:19 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:24:19 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 00:24:19 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:24:19 --> Config Class Initialized
INFO - 2018-03-12 00:24:19 --> Utf8 Class Initialized
INFO - 2018-03-12 00:24:19 --> Utf8 Class Initialized
INFO - 2018-03-12 00:24:19 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:24:19 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:24:19 --> Utf8 Class Initialized
INFO - 2018-03-12 00:24:19 --> URI Class Initialized
INFO - 2018-03-12 00:24:19 --> URI Class Initialized
INFO - 2018-03-12 00:24:19 --> URI Class Initialized
INFO - 2018-03-12 00:24:19 --> Router Class Initialized
DEBUG - 2018-03-12 00:24:19 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:24:19 --> Utf8 Class Initialized
INFO - 2018-03-12 00:24:19 --> Router Class Initialized
INFO - 2018-03-12 00:24:19 --> Router Class Initialized
INFO - 2018-03-12 00:24:19 --> URI Class Initialized
INFO - 2018-03-12 00:24:19 --> Output Class Initialized
INFO - 2018-03-12 00:24:19 --> Output Class Initialized
INFO - 2018-03-12 00:24:19 --> Output Class Initialized
INFO - 2018-03-12 00:24:19 --> Security Class Initialized
INFO - 2018-03-12 00:24:19 --> Router Class Initialized
INFO - 2018-03-12 00:24:19 --> Security Class Initialized
INFO - 2018-03-12 00:24:19 --> Security Class Initialized
DEBUG - 2018-03-12 00:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:24:19 --> Input Class Initialized
INFO - 2018-03-12 00:24:19 --> Output Class Initialized
DEBUG - 2018-03-12 00:24:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 00:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:24:19 --> Input Class Initialized
INFO - 2018-03-12 00:24:19 --> Language Class Initialized
INFO - 2018-03-12 00:24:19 --> Input Class Initialized
INFO - 2018-03-12 00:24:19 --> Security Class Initialized
INFO - 2018-03-12 00:24:19 --> Language Class Initialized
INFO - 2018-03-12 00:24:19 --> Language Class Initialized
ERROR - 2018-03-12 00:24:19 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-12 00:24:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-03-12 00:24:19 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-12 00:24:19 --> Input Class Initialized
ERROR - 2018-03-12 00:24:19 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-12 00:24:19 --> Language Class Initialized
ERROR - 2018-03-12 00:24:19 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-12 00:24:19 --> Config Class Initialized
INFO - 2018-03-12 00:24:19 --> Hooks Class Initialized
INFO - 2018-03-12 00:24:19 --> Config Class Initialized
INFO - 2018-03-12 00:24:19 --> Hooks Class Initialized
INFO - 2018-03-12 00:24:19 --> Config Class Initialized
INFO - 2018-03-12 00:24:19 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:24:19 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:24:19 --> Utf8 Class Initialized
DEBUG - 2018-03-12 00:24:19 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:24:19 --> Utf8 Class Initialized
INFO - 2018-03-12 00:24:19 --> URI Class Initialized
INFO - 2018-03-12 00:24:19 --> URI Class Initialized
DEBUG - 2018-03-12 00:24:19 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:24:19 --> Utf8 Class Initialized
INFO - 2018-03-12 00:24:19 --> Router Class Initialized
INFO - 2018-03-12 00:24:19 --> URI Class Initialized
INFO - 2018-03-12 00:24:19 --> Router Class Initialized
INFO - 2018-03-12 00:24:19 --> Output Class Initialized
INFO - 2018-03-12 00:24:19 --> Router Class Initialized
INFO - 2018-03-12 00:24:19 --> Output Class Initialized
INFO - 2018-03-12 00:24:19 --> Security Class Initialized
INFO - 2018-03-12 00:24:19 --> Security Class Initialized
INFO - 2018-03-12 00:24:19 --> Output Class Initialized
DEBUG - 2018-03-12 00:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:24:19 --> Input Class Initialized
INFO - 2018-03-12 00:24:19 --> Language Class Initialized
DEBUG - 2018-03-12 00:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:24:19 --> Security Class Initialized
INFO - 2018-03-12 00:24:19 --> Input Class Initialized
INFO - 2018-03-12 00:24:19 --> Language Class Initialized
ERROR - 2018-03-12 00:24:19 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-03-12 00:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:24:19 --> Input Class Initialized
ERROR - 2018-03-12 00:24:19 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-12 00:24:19 --> Language Class Initialized
ERROR - 2018-03-12 00:24:19 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-12 00:24:19 --> Config Class Initialized
INFO - 2018-03-12 00:24:19 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:24:19 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:24:19 --> Utf8 Class Initialized
INFO - 2018-03-12 00:24:19 --> URI Class Initialized
INFO - 2018-03-12 00:24:19 --> Router Class Initialized
INFO - 2018-03-12 00:24:19 --> Output Class Initialized
INFO - 2018-03-12 00:24:19 --> Security Class Initialized
DEBUG - 2018-03-12 00:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:24:19 --> Input Class Initialized
INFO - 2018-03-12 00:24:19 --> Language Class Initialized
INFO - 2018-03-12 00:24:19 --> Loader Class Initialized
INFO - 2018-03-12 00:24:19 --> Helper loaded: url_helper
INFO - 2018-03-12 00:24:19 --> Helper loaded: form_helper
INFO - 2018-03-12 00:24:19 --> Database Driver Class Initialized
DEBUG - 2018-03-12 00:24:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 00:24:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 00:24:19 --> Form Validation Class Initialized
INFO - 2018-03-12 00:24:19 --> Model Class Initialized
INFO - 2018-03-12 00:24:19 --> Controller Class Initialized
INFO - 2018-03-12 00:24:19 --> Model Class Initialized
INFO - 2018-03-12 00:24:19 --> Model Class Initialized
INFO - 2018-03-12 00:24:19 --> Model Class Initialized
INFO - 2018-03-12 00:24:19 --> Model Class Initialized
INFO - 2018-03-12 00:24:19 --> Model Class Initialized
DEBUG - 2018-03-12 00:24:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-12 00:25:39 --> Config Class Initialized
INFO - 2018-03-12 00:25:39 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:25:39 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:25:39 --> Utf8 Class Initialized
INFO - 2018-03-12 00:25:39 --> URI Class Initialized
INFO - 2018-03-12 00:25:39 --> Router Class Initialized
INFO - 2018-03-12 00:25:39 --> Output Class Initialized
INFO - 2018-03-12 00:25:39 --> Security Class Initialized
DEBUG - 2018-03-12 00:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:25:39 --> Input Class Initialized
INFO - 2018-03-12 00:25:39 --> Language Class Initialized
INFO - 2018-03-12 00:25:39 --> Loader Class Initialized
INFO - 2018-03-12 00:25:39 --> Helper loaded: url_helper
INFO - 2018-03-12 00:25:39 --> Helper loaded: form_helper
INFO - 2018-03-12 00:25:39 --> Database Driver Class Initialized
DEBUG - 2018-03-12 00:25:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 00:25:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 00:25:39 --> Form Validation Class Initialized
INFO - 2018-03-12 00:25:39 --> Model Class Initialized
INFO - 2018-03-12 00:25:39 --> Controller Class Initialized
INFO - 2018-03-12 00:25:39 --> Model Class Initialized
INFO - 2018-03-12 00:25:39 --> Model Class Initialized
INFO - 2018-03-12 00:25:39 --> Model Class Initialized
INFO - 2018-03-12 00:25:39 --> Model Class Initialized
INFO - 2018-03-12 00:25:39 --> Model Class Initialized
DEBUG - 2018-03-12 00:25:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-12 00:25:39 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-12 00:25:39 --> Final output sent to browser
DEBUG - 2018-03-12 00:25:39 --> Total execution time: 0.0757
INFO - 2018-03-12 00:25:39 --> Config Class Initialized
INFO - 2018-03-12 00:25:39 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:25:39 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:25:39 --> Utf8 Class Initialized
INFO - 2018-03-12 00:25:39 --> Config Class Initialized
INFO - 2018-03-12 00:25:39 --> Hooks Class Initialized
INFO - 2018-03-12 00:25:39 --> URI Class Initialized
INFO - 2018-03-12 00:25:39 --> Config Class Initialized
INFO - 2018-03-12 00:25:39 --> Hooks Class Initialized
INFO - 2018-03-12 00:25:39 --> Router Class Initialized
DEBUG - 2018-03-12 00:25:39 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:25:39 --> Utf8 Class Initialized
DEBUG - 2018-03-12 00:25:39 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:25:39 --> Utf8 Class Initialized
INFO - 2018-03-12 00:25:39 --> Output Class Initialized
INFO - 2018-03-12 00:25:39 --> URI Class Initialized
INFO - 2018-03-12 00:25:39 --> URI Class Initialized
INFO - 2018-03-12 00:25:39 --> Security Class Initialized
INFO - 2018-03-12 00:25:39 --> Config Class Initialized
INFO - 2018-03-12 00:25:39 --> Hooks Class Initialized
INFO - 2018-03-12 00:25:39 --> Router Class Initialized
INFO - 2018-03-12 00:25:39 --> Router Class Initialized
DEBUG - 2018-03-12 00:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:25:39 --> Input Class Initialized
INFO - 2018-03-12 00:25:39 --> Output Class Initialized
DEBUG - 2018-03-12 00:25:39 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:25:39 --> Language Class Initialized
INFO - 2018-03-12 00:25:39 --> Output Class Initialized
INFO - 2018-03-12 00:25:39 --> Utf8 Class Initialized
INFO - 2018-03-12 00:25:39 --> Security Class Initialized
INFO - 2018-03-12 00:25:39 --> URI Class Initialized
INFO - 2018-03-12 00:25:39 --> Security Class Initialized
ERROR - 2018-03-12 00:25:39 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-12 00:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:25:39 --> Input Class Initialized
DEBUG - 2018-03-12 00:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:25:39 --> Router Class Initialized
INFO - 2018-03-12 00:25:39 --> Input Class Initialized
INFO - 2018-03-12 00:25:39 --> Language Class Initialized
INFO - 2018-03-12 00:25:39 --> Language Class Initialized
ERROR - 2018-03-12 00:25:39 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-12 00:25:39 --> Output Class Initialized
ERROR - 2018-03-12 00:25:39 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-12 00:25:39 --> Security Class Initialized
DEBUG - 2018-03-12 00:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:25:39 --> Input Class Initialized
INFO - 2018-03-12 00:25:39 --> Language Class Initialized
ERROR - 2018-03-12 00:25:39 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-12 00:25:39 --> Config Class Initialized
INFO - 2018-03-12 00:25:39 --> Config Class Initialized
INFO - 2018-03-12 00:25:39 --> Config Class Initialized
INFO - 2018-03-12 00:25:39 --> Hooks Class Initialized
INFO - 2018-03-12 00:25:39 --> Hooks Class Initialized
INFO - 2018-03-12 00:25:39 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:25:39 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 00:25:39 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 00:25:39 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:25:39 --> Utf8 Class Initialized
INFO - 2018-03-12 00:25:39 --> Utf8 Class Initialized
INFO - 2018-03-12 00:25:39 --> Utf8 Class Initialized
INFO - 2018-03-12 00:25:39 --> URI Class Initialized
INFO - 2018-03-12 00:25:39 --> URI Class Initialized
INFO - 2018-03-12 00:25:39 --> URI Class Initialized
INFO - 2018-03-12 00:25:39 --> Router Class Initialized
INFO - 2018-03-12 00:25:39 --> Router Class Initialized
INFO - 2018-03-12 00:25:39 --> Router Class Initialized
INFO - 2018-03-12 00:25:39 --> Output Class Initialized
INFO - 2018-03-12 00:25:39 --> Output Class Initialized
INFO - 2018-03-12 00:25:39 --> Output Class Initialized
INFO - 2018-03-12 00:25:39 --> Security Class Initialized
INFO - 2018-03-12 00:25:39 --> Security Class Initialized
INFO - 2018-03-12 00:25:39 --> Security Class Initialized
DEBUG - 2018-03-12 00:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:25:39 --> Input Class Initialized
DEBUG - 2018-03-12 00:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:25:39 --> Input Class Initialized
INFO - 2018-03-12 00:25:39 --> Language Class Initialized
DEBUG - 2018-03-12 00:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:25:39 --> Input Class Initialized
INFO - 2018-03-12 00:25:39 --> Language Class Initialized
INFO - 2018-03-12 00:25:39 --> Language Class Initialized
ERROR - 2018-03-12 00:25:39 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-12 00:25:39 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-12 00:25:39 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-12 00:25:39 --> Config Class Initialized
INFO - 2018-03-12 00:25:39 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:25:39 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:25:39 --> Utf8 Class Initialized
INFO - 2018-03-12 00:25:39 --> URI Class Initialized
INFO - 2018-03-12 00:25:39 --> Router Class Initialized
INFO - 2018-03-12 00:25:39 --> Output Class Initialized
INFO - 2018-03-12 00:25:39 --> Security Class Initialized
DEBUG - 2018-03-12 00:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:25:39 --> Input Class Initialized
INFO - 2018-03-12 00:25:39 --> Language Class Initialized
INFO - 2018-03-12 00:25:39 --> Loader Class Initialized
INFO - 2018-03-12 00:25:39 --> Helper loaded: url_helper
INFO - 2018-03-12 00:25:39 --> Helper loaded: form_helper
INFO - 2018-03-12 00:25:39 --> Database Driver Class Initialized
DEBUG - 2018-03-12 00:25:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 00:25:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 00:25:39 --> Form Validation Class Initialized
INFO - 2018-03-12 00:25:39 --> Model Class Initialized
INFO - 2018-03-12 00:25:39 --> Controller Class Initialized
INFO - 2018-03-12 00:25:39 --> Model Class Initialized
INFO - 2018-03-12 00:25:39 --> Model Class Initialized
INFO - 2018-03-12 00:25:39 --> Model Class Initialized
INFO - 2018-03-12 00:25:39 --> Model Class Initialized
INFO - 2018-03-12 00:25:39 --> Model Class Initialized
DEBUG - 2018-03-12 00:25:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-12 00:25:45 --> Config Class Initialized
INFO - 2018-03-12 00:25:45 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:25:45 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:25:45 --> Utf8 Class Initialized
INFO - 2018-03-12 00:25:45 --> URI Class Initialized
INFO - 2018-03-12 00:25:45 --> Router Class Initialized
INFO - 2018-03-12 00:25:45 --> Output Class Initialized
INFO - 2018-03-12 00:25:45 --> Security Class Initialized
DEBUG - 2018-03-12 00:25:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:25:45 --> Input Class Initialized
INFO - 2018-03-12 00:25:45 --> Language Class Initialized
INFO - 2018-03-12 00:25:45 --> Loader Class Initialized
INFO - 2018-03-12 00:25:45 --> Helper loaded: url_helper
INFO - 2018-03-12 00:25:45 --> Helper loaded: form_helper
INFO - 2018-03-12 00:25:45 --> Database Driver Class Initialized
DEBUG - 2018-03-12 00:25:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 00:25:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 00:25:45 --> Form Validation Class Initialized
INFO - 2018-03-12 00:25:45 --> Model Class Initialized
INFO - 2018-03-12 00:25:45 --> Controller Class Initialized
INFO - 2018-03-12 00:25:45 --> Model Class Initialized
INFO - 2018-03-12 00:25:45 --> Model Class Initialized
INFO - 2018-03-12 00:25:45 --> Model Class Initialized
INFO - 2018-03-12 00:25:45 --> Model Class Initialized
INFO - 2018-03-12 00:25:45 --> Model Class Initialized
DEBUG - 2018-03-12 00:25:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-12 00:25:45 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-12 00:25:45 --> Final output sent to browser
DEBUG - 2018-03-12 00:25:45 --> Total execution time: 0.0722
INFO - 2018-03-12 00:25:45 --> Config Class Initialized
INFO - 2018-03-12 00:25:45 --> Hooks Class Initialized
INFO - 2018-03-12 00:25:45 --> Config Class Initialized
INFO - 2018-03-12 00:25:45 --> Config Class Initialized
INFO - 2018-03-12 00:25:45 --> Hooks Class Initialized
INFO - 2018-03-12 00:25:45 --> Hooks Class Initialized
INFO - 2018-03-12 00:25:45 --> Config Class Initialized
DEBUG - 2018-03-12 00:25:45 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:25:45 --> Hooks Class Initialized
INFO - 2018-03-12 00:25:45 --> Utf8 Class Initialized
DEBUG - 2018-03-12 00:25:45 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 00:25:45 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:25:45 --> Utf8 Class Initialized
INFO - 2018-03-12 00:25:45 --> Utf8 Class Initialized
INFO - 2018-03-12 00:25:45 --> URI Class Initialized
INFO - 2018-03-12 00:25:45 --> URI Class Initialized
INFO - 2018-03-12 00:25:45 --> URI Class Initialized
INFO - 2018-03-12 00:25:45 --> Router Class Initialized
DEBUG - 2018-03-12 00:25:45 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:25:45 --> Utf8 Class Initialized
INFO - 2018-03-12 00:25:45 --> Router Class Initialized
INFO - 2018-03-12 00:25:45 --> Router Class Initialized
INFO - 2018-03-12 00:25:45 --> URI Class Initialized
INFO - 2018-03-12 00:25:45 --> Output Class Initialized
INFO - 2018-03-12 00:25:45 --> Output Class Initialized
INFO - 2018-03-12 00:25:45 --> Router Class Initialized
INFO - 2018-03-12 00:25:45 --> Output Class Initialized
INFO - 2018-03-12 00:25:45 --> Security Class Initialized
INFO - 2018-03-12 00:25:45 --> Security Class Initialized
DEBUG - 2018-03-12 00:25:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:25:45 --> Output Class Initialized
INFO - 2018-03-12 00:25:45 --> Security Class Initialized
INFO - 2018-03-12 00:25:45 --> Input Class Initialized
DEBUG - 2018-03-12 00:25:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:25:45 --> Input Class Initialized
INFO - 2018-03-12 00:25:45 --> Language Class Initialized
DEBUG - 2018-03-12 00:25:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:25:45 --> Security Class Initialized
INFO - 2018-03-12 00:25:45 --> Language Class Initialized
INFO - 2018-03-12 00:25:45 --> Input Class Initialized
INFO - 2018-03-12 00:25:45 --> Language Class Initialized
ERROR - 2018-03-12 00:25:45 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-12 00:25:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-03-12 00:25:45 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-12 00:25:45 --> Input Class Initialized
ERROR - 2018-03-12 00:25:45 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-12 00:25:45 --> Language Class Initialized
ERROR - 2018-03-12 00:25:45 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-12 00:25:45 --> Config Class Initialized
INFO - 2018-03-12 00:25:45 --> Hooks Class Initialized
INFO - 2018-03-12 00:25:45 --> Config Class Initialized
INFO - 2018-03-12 00:25:45 --> Hooks Class Initialized
INFO - 2018-03-12 00:25:45 --> Config Class Initialized
INFO - 2018-03-12 00:25:45 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:25:45 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:25:45 --> Utf8 Class Initialized
DEBUG - 2018-03-12 00:25:45 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:25:45 --> Utf8 Class Initialized
INFO - 2018-03-12 00:25:45 --> URI Class Initialized
DEBUG - 2018-03-12 00:25:45 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:25:45 --> URI Class Initialized
INFO - 2018-03-12 00:25:45 --> Utf8 Class Initialized
INFO - 2018-03-12 00:25:45 --> URI Class Initialized
INFO - 2018-03-12 00:25:45 --> Router Class Initialized
INFO - 2018-03-12 00:25:45 --> Router Class Initialized
INFO - 2018-03-12 00:25:45 --> Router Class Initialized
INFO - 2018-03-12 00:25:45 --> Output Class Initialized
INFO - 2018-03-12 00:25:45 --> Output Class Initialized
INFO - 2018-03-12 00:25:45 --> Output Class Initialized
INFO - 2018-03-12 00:25:45 --> Security Class Initialized
INFO - 2018-03-12 00:25:45 --> Security Class Initialized
INFO - 2018-03-12 00:25:45 --> Security Class Initialized
DEBUG - 2018-03-12 00:25:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 00:25:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:25:45 --> Input Class Initialized
INFO - 2018-03-12 00:25:45 --> Input Class Initialized
INFO - 2018-03-12 00:25:45 --> Language Class Initialized
INFO - 2018-03-12 00:25:45 --> Language Class Initialized
DEBUG - 2018-03-12 00:25:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:25:45 --> Input Class Initialized
INFO - 2018-03-12 00:25:45 --> Language Class Initialized
ERROR - 2018-03-12 00:25:45 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-12 00:25:45 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-12 00:25:45 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-12 00:25:45 --> Config Class Initialized
INFO - 2018-03-12 00:25:45 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:25:45 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:25:45 --> Utf8 Class Initialized
INFO - 2018-03-12 00:25:45 --> URI Class Initialized
INFO - 2018-03-12 00:25:45 --> Router Class Initialized
INFO - 2018-03-12 00:25:45 --> Output Class Initialized
INFO - 2018-03-12 00:25:45 --> Security Class Initialized
DEBUG - 2018-03-12 00:25:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:25:45 --> Input Class Initialized
INFO - 2018-03-12 00:25:45 --> Language Class Initialized
INFO - 2018-03-12 00:25:45 --> Loader Class Initialized
INFO - 2018-03-12 00:25:45 --> Helper loaded: url_helper
INFO - 2018-03-12 00:25:45 --> Helper loaded: form_helper
INFO - 2018-03-12 00:25:45 --> Database Driver Class Initialized
DEBUG - 2018-03-12 00:25:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 00:25:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 00:25:45 --> Form Validation Class Initialized
INFO - 2018-03-12 00:25:45 --> Model Class Initialized
INFO - 2018-03-12 00:25:45 --> Controller Class Initialized
INFO - 2018-03-12 00:25:45 --> Model Class Initialized
INFO - 2018-03-12 00:25:45 --> Model Class Initialized
INFO - 2018-03-12 00:25:45 --> Model Class Initialized
INFO - 2018-03-12 00:25:45 --> Model Class Initialized
INFO - 2018-03-12 00:25:45 --> Model Class Initialized
DEBUG - 2018-03-12 00:25:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-12 00:25:47 --> Config Class Initialized
INFO - 2018-03-12 00:25:47 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:25:47 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:25:47 --> Utf8 Class Initialized
INFO - 2018-03-12 00:25:47 --> URI Class Initialized
INFO - 2018-03-12 00:25:47 --> Router Class Initialized
INFO - 2018-03-12 00:25:47 --> Output Class Initialized
INFO - 2018-03-12 00:25:47 --> Security Class Initialized
DEBUG - 2018-03-12 00:25:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:25:47 --> Input Class Initialized
INFO - 2018-03-12 00:25:47 --> Language Class Initialized
INFO - 2018-03-12 00:25:47 --> Loader Class Initialized
INFO - 2018-03-12 00:25:47 --> Helper loaded: url_helper
INFO - 2018-03-12 00:25:47 --> Helper loaded: form_helper
INFO - 2018-03-12 00:25:47 --> Database Driver Class Initialized
DEBUG - 2018-03-12 00:25:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 00:25:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 00:25:47 --> Form Validation Class Initialized
INFO - 2018-03-12 00:25:47 --> Model Class Initialized
INFO - 2018-03-12 00:25:47 --> Controller Class Initialized
INFO - 2018-03-12 00:25:47 --> Model Class Initialized
INFO - 2018-03-12 00:25:47 --> Model Class Initialized
INFO - 2018-03-12 00:25:47 --> Model Class Initialized
INFO - 2018-03-12 00:25:47 --> Model Class Initialized
INFO - 2018-03-12 00:25:47 --> Model Class Initialized
DEBUG - 2018-03-12 00:25:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-12 00:25:47 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-12 00:25:47 --> Final output sent to browser
DEBUG - 2018-03-12 00:25:47 --> Total execution time: 0.0664
INFO - 2018-03-12 00:25:47 --> Config Class Initialized
INFO - 2018-03-12 00:25:47 --> Config Class Initialized
INFO - 2018-03-12 00:25:47 --> Hooks Class Initialized
INFO - 2018-03-12 00:25:47 --> Hooks Class Initialized
INFO - 2018-03-12 00:25:47 --> Config Class Initialized
INFO - 2018-03-12 00:25:47 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:25:47 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 00:25:47 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:25:47 --> Utf8 Class Initialized
INFO - 2018-03-12 00:25:47 --> Utf8 Class Initialized
DEBUG - 2018-03-12 00:25:47 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:25:47 --> Config Class Initialized
INFO - 2018-03-12 00:25:47 --> Utf8 Class Initialized
INFO - 2018-03-12 00:25:47 --> Hooks Class Initialized
INFO - 2018-03-12 00:25:47 --> URI Class Initialized
INFO - 2018-03-12 00:25:47 --> URI Class Initialized
INFO - 2018-03-12 00:25:47 --> URI Class Initialized
INFO - 2018-03-12 00:25:47 --> Router Class Initialized
INFO - 2018-03-12 00:25:47 --> Router Class Initialized
INFO - 2018-03-12 00:25:47 --> Router Class Initialized
DEBUG - 2018-03-12 00:25:47 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:25:47 --> Utf8 Class Initialized
INFO - 2018-03-12 00:25:47 --> Output Class Initialized
INFO - 2018-03-12 00:25:47 --> Output Class Initialized
INFO - 2018-03-12 00:25:47 --> Output Class Initialized
INFO - 2018-03-12 00:25:47 --> URI Class Initialized
INFO - 2018-03-12 00:25:48 --> Security Class Initialized
INFO - 2018-03-12 00:25:48 --> Security Class Initialized
INFO - 2018-03-12 00:25:48 --> Security Class Initialized
INFO - 2018-03-12 00:25:48 --> Router Class Initialized
DEBUG - 2018-03-12 00:25:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:25:48 --> Input Class Initialized
DEBUG - 2018-03-12 00:25:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:25:48 --> Input Class Initialized
INFO - 2018-03-12 00:25:48 --> Language Class Initialized
DEBUG - 2018-03-12 00:25:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:25:48 --> Input Class Initialized
INFO - 2018-03-12 00:25:48 --> Language Class Initialized
INFO - 2018-03-12 00:25:48 --> Output Class Initialized
INFO - 2018-03-12 00:25:48 --> Language Class Initialized
ERROR - 2018-03-12 00:25:48 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-12 00:25:48 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-12 00:25:48 --> Security Class Initialized
ERROR - 2018-03-12 00:25:48 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-12 00:25:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:25:48 --> Input Class Initialized
INFO - 2018-03-12 00:25:48 --> Language Class Initialized
ERROR - 2018-03-12 00:25:48 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-12 00:25:48 --> Config Class Initialized
INFO - 2018-03-12 00:25:48 --> Hooks Class Initialized
INFO - 2018-03-12 00:25:48 --> Config Class Initialized
INFO - 2018-03-12 00:25:48 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:25:48 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:25:48 --> Utf8 Class Initialized
INFO - 2018-03-12 00:25:48 --> Config Class Initialized
INFO - 2018-03-12 00:25:48 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:25:48 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:25:48 --> Utf8 Class Initialized
INFO - 2018-03-12 00:25:48 --> URI Class Initialized
INFO - 2018-03-12 00:25:48 --> URI Class Initialized
DEBUG - 2018-03-12 00:25:48 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:25:48 --> Utf8 Class Initialized
INFO - 2018-03-12 00:25:48 --> Router Class Initialized
INFO - 2018-03-12 00:25:48 --> Router Class Initialized
INFO - 2018-03-12 00:25:48 --> URI Class Initialized
INFO - 2018-03-12 00:25:48 --> Output Class Initialized
INFO - 2018-03-12 00:25:48 --> Output Class Initialized
INFO - 2018-03-12 00:25:48 --> Router Class Initialized
INFO - 2018-03-12 00:25:48 --> Security Class Initialized
INFO - 2018-03-12 00:25:48 --> Security Class Initialized
DEBUG - 2018-03-12 00:25:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 00:25:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:25:48 --> Input Class Initialized
INFO - 2018-03-12 00:25:48 --> Input Class Initialized
INFO - 2018-03-12 00:25:48 --> Output Class Initialized
INFO - 2018-03-12 00:25:48 --> Language Class Initialized
INFO - 2018-03-12 00:25:48 --> Language Class Initialized
INFO - 2018-03-12 00:25:48 --> Security Class Initialized
ERROR - 2018-03-12 00:25:48 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-12 00:25:48 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-03-12 00:25:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:25:48 --> Input Class Initialized
INFO - 2018-03-12 00:25:48 --> Language Class Initialized
ERROR - 2018-03-12 00:25:48 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-12 00:25:48 --> Config Class Initialized
INFO - 2018-03-12 00:25:48 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:25:48 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:25:48 --> Utf8 Class Initialized
INFO - 2018-03-12 00:25:48 --> URI Class Initialized
INFO - 2018-03-12 00:25:48 --> Router Class Initialized
INFO - 2018-03-12 00:25:48 --> Output Class Initialized
INFO - 2018-03-12 00:25:48 --> Security Class Initialized
DEBUG - 2018-03-12 00:25:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:25:48 --> Input Class Initialized
INFO - 2018-03-12 00:25:48 --> Language Class Initialized
INFO - 2018-03-12 00:25:48 --> Loader Class Initialized
INFO - 2018-03-12 00:25:48 --> Helper loaded: url_helper
INFO - 2018-03-12 00:25:48 --> Helper loaded: form_helper
INFO - 2018-03-12 00:25:48 --> Database Driver Class Initialized
DEBUG - 2018-03-12 00:25:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 00:25:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 00:25:48 --> Form Validation Class Initialized
INFO - 2018-03-12 00:25:48 --> Model Class Initialized
INFO - 2018-03-12 00:25:48 --> Controller Class Initialized
INFO - 2018-03-12 00:25:48 --> Model Class Initialized
INFO - 2018-03-12 00:25:48 --> Model Class Initialized
INFO - 2018-03-12 00:25:48 --> Model Class Initialized
INFO - 2018-03-12 00:25:48 --> Model Class Initialized
INFO - 2018-03-12 00:25:48 --> Model Class Initialized
DEBUG - 2018-03-12 00:25:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-12 00:26:07 --> Config Class Initialized
INFO - 2018-03-12 00:26:07 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:26:07 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:26:07 --> Utf8 Class Initialized
INFO - 2018-03-12 00:26:07 --> URI Class Initialized
INFO - 2018-03-12 00:26:07 --> Router Class Initialized
INFO - 2018-03-12 00:26:07 --> Output Class Initialized
INFO - 2018-03-12 00:26:07 --> Security Class Initialized
DEBUG - 2018-03-12 00:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:26:07 --> Input Class Initialized
INFO - 2018-03-12 00:26:07 --> Language Class Initialized
INFO - 2018-03-12 00:26:07 --> Loader Class Initialized
INFO - 2018-03-12 00:26:07 --> Helper loaded: url_helper
INFO - 2018-03-12 00:26:07 --> Helper loaded: form_helper
INFO - 2018-03-12 00:26:07 --> Database Driver Class Initialized
DEBUG - 2018-03-12 00:26:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 00:26:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 00:26:07 --> Form Validation Class Initialized
INFO - 2018-03-12 00:26:07 --> Model Class Initialized
INFO - 2018-03-12 00:26:07 --> Controller Class Initialized
INFO - 2018-03-12 00:26:07 --> Model Class Initialized
INFO - 2018-03-12 00:26:07 --> Model Class Initialized
INFO - 2018-03-12 00:26:07 --> Model Class Initialized
INFO - 2018-03-12 00:26:07 --> Model Class Initialized
INFO - 2018-03-12 00:26:07 --> Model Class Initialized
DEBUG - 2018-03-12 00:26:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-12 00:26:07 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-12 00:26:07 --> Final output sent to browser
DEBUG - 2018-03-12 00:26:07 --> Total execution time: 0.0733
INFO - 2018-03-12 00:26:07 --> Config Class Initialized
INFO - 2018-03-12 00:26:07 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:26:07 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:26:07 --> Utf8 Class Initialized
INFO - 2018-03-12 00:26:07 --> URI Class Initialized
INFO - 2018-03-12 00:26:07 --> Router Class Initialized
INFO - 2018-03-12 00:26:07 --> Output Class Initialized
INFO - 2018-03-12 00:26:07 --> Security Class Initialized
DEBUG - 2018-03-12 00:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:26:07 --> Input Class Initialized
INFO - 2018-03-12 00:26:07 --> Language Class Initialized
INFO - 2018-03-12 00:26:07 --> Loader Class Initialized
INFO - 2018-03-12 00:26:07 --> Helper loaded: url_helper
INFO - 2018-03-12 00:26:07 --> Helper loaded: form_helper
INFO - 2018-03-12 00:26:07 --> Database Driver Class Initialized
DEBUG - 2018-03-12 00:26:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 00:26:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 00:26:07 --> Form Validation Class Initialized
INFO - 2018-03-12 00:26:07 --> Model Class Initialized
INFO - 2018-03-12 00:26:07 --> Controller Class Initialized
INFO - 2018-03-12 00:26:07 --> Model Class Initialized
INFO - 2018-03-12 00:26:07 --> Model Class Initialized
INFO - 2018-03-12 00:26:07 --> Model Class Initialized
INFO - 2018-03-12 00:26:07 --> Model Class Initialized
INFO - 2018-03-12 00:26:07 --> Model Class Initialized
DEBUG - 2018-03-12 00:26:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-12 00:26:09 --> Config Class Initialized
INFO - 2018-03-12 00:26:09 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:26:09 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:26:09 --> Utf8 Class Initialized
INFO - 2018-03-12 00:26:09 --> URI Class Initialized
INFO - 2018-03-12 00:26:09 --> Router Class Initialized
INFO - 2018-03-12 00:26:09 --> Output Class Initialized
INFO - 2018-03-12 00:26:09 --> Security Class Initialized
DEBUG - 2018-03-12 00:26:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:26:09 --> Input Class Initialized
INFO - 2018-03-12 00:26:09 --> Language Class Initialized
INFO - 2018-03-12 00:26:09 --> Loader Class Initialized
INFO - 2018-03-12 00:26:09 --> Helper loaded: url_helper
INFO - 2018-03-12 00:26:09 --> Helper loaded: form_helper
INFO - 2018-03-12 00:26:09 --> Database Driver Class Initialized
DEBUG - 2018-03-12 00:26:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 00:26:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 00:26:09 --> Form Validation Class Initialized
INFO - 2018-03-12 00:26:09 --> Model Class Initialized
INFO - 2018-03-12 00:26:09 --> Controller Class Initialized
INFO - 2018-03-12 00:26:09 --> Model Class Initialized
INFO - 2018-03-12 00:26:09 --> Model Class Initialized
INFO - 2018-03-12 00:26:09 --> Model Class Initialized
INFO - 2018-03-12 00:26:09 --> Model Class Initialized
INFO - 2018-03-12 00:26:09 --> Model Class Initialized
DEBUG - 2018-03-12 00:26:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-12 00:26:09 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-12 00:26:09 --> Final output sent to browser
DEBUG - 2018-03-12 00:26:09 --> Total execution time: 0.0727
INFO - 2018-03-12 00:26:09 --> Config Class Initialized
INFO - 2018-03-12 00:26:09 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:26:09 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:26:09 --> Utf8 Class Initialized
INFO - 2018-03-12 00:26:09 --> URI Class Initialized
INFO - 2018-03-12 00:26:09 --> Router Class Initialized
INFO - 2018-03-12 00:26:09 --> Output Class Initialized
INFO - 2018-03-12 00:26:09 --> Security Class Initialized
DEBUG - 2018-03-12 00:26:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:26:09 --> Input Class Initialized
INFO - 2018-03-12 00:26:09 --> Language Class Initialized
INFO - 2018-03-12 00:26:09 --> Loader Class Initialized
INFO - 2018-03-12 00:26:09 --> Helper loaded: url_helper
INFO - 2018-03-12 00:26:09 --> Helper loaded: form_helper
INFO - 2018-03-12 00:26:09 --> Database Driver Class Initialized
DEBUG - 2018-03-12 00:26:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 00:26:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 00:26:09 --> Form Validation Class Initialized
INFO - 2018-03-12 00:26:09 --> Model Class Initialized
INFO - 2018-03-12 00:26:09 --> Controller Class Initialized
INFO - 2018-03-12 00:26:09 --> Model Class Initialized
INFO - 2018-03-12 00:26:09 --> Model Class Initialized
INFO - 2018-03-12 00:26:09 --> Model Class Initialized
INFO - 2018-03-12 00:26:09 --> Model Class Initialized
INFO - 2018-03-12 00:26:09 --> Model Class Initialized
DEBUG - 2018-03-12 00:26:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-12 00:27:29 --> Config Class Initialized
INFO - 2018-03-12 00:27:29 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:27:29 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:27:29 --> Utf8 Class Initialized
INFO - 2018-03-12 00:27:29 --> URI Class Initialized
INFO - 2018-03-12 00:27:29 --> Router Class Initialized
INFO - 2018-03-12 00:27:29 --> Output Class Initialized
INFO - 2018-03-12 00:27:29 --> Security Class Initialized
DEBUG - 2018-03-12 00:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:27:29 --> Input Class Initialized
INFO - 2018-03-12 00:27:29 --> Language Class Initialized
INFO - 2018-03-12 00:27:30 --> Loader Class Initialized
INFO - 2018-03-12 00:27:30 --> Helper loaded: url_helper
INFO - 2018-03-12 00:27:30 --> Helper loaded: form_helper
INFO - 2018-03-12 00:27:30 --> Database Driver Class Initialized
DEBUG - 2018-03-12 00:27:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 00:27:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 00:27:30 --> Form Validation Class Initialized
INFO - 2018-03-12 00:27:30 --> Model Class Initialized
INFO - 2018-03-12 00:27:30 --> Controller Class Initialized
INFO - 2018-03-12 00:27:30 --> Model Class Initialized
INFO - 2018-03-12 00:27:30 --> Model Class Initialized
INFO - 2018-03-12 00:27:30 --> Model Class Initialized
INFO - 2018-03-12 00:27:30 --> Model Class Initialized
INFO - 2018-03-12 00:27:30 --> Model Class Initialized
DEBUG - 2018-03-12 00:27:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-12 00:27:30 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-12 00:27:30 --> Final output sent to browser
DEBUG - 2018-03-12 00:27:30 --> Total execution time: 0.0766
INFO - 2018-03-12 00:27:30 --> Config Class Initialized
INFO - 2018-03-12 00:27:30 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:27:30 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:27:30 --> Utf8 Class Initialized
INFO - 2018-03-12 00:27:30 --> URI Class Initialized
INFO - 2018-03-12 00:27:30 --> Router Class Initialized
INFO - 2018-03-12 00:27:30 --> Output Class Initialized
INFO - 2018-03-12 00:27:30 --> Security Class Initialized
DEBUG - 2018-03-12 00:27:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:27:30 --> Input Class Initialized
INFO - 2018-03-12 00:27:30 --> Language Class Initialized
INFO - 2018-03-12 00:27:30 --> Loader Class Initialized
INFO - 2018-03-12 00:27:30 --> Helper loaded: url_helper
INFO - 2018-03-12 00:27:30 --> Helper loaded: form_helper
INFO - 2018-03-12 00:27:30 --> Database Driver Class Initialized
DEBUG - 2018-03-12 00:27:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 00:27:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 00:27:30 --> Form Validation Class Initialized
INFO - 2018-03-12 00:27:30 --> Model Class Initialized
INFO - 2018-03-12 00:27:30 --> Controller Class Initialized
INFO - 2018-03-12 00:27:30 --> Model Class Initialized
INFO - 2018-03-12 00:27:30 --> Model Class Initialized
INFO - 2018-03-12 00:27:30 --> Model Class Initialized
INFO - 2018-03-12 00:27:30 --> Model Class Initialized
INFO - 2018-03-12 00:27:30 --> Model Class Initialized
DEBUG - 2018-03-12 00:27:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-12 00:27:31 --> Config Class Initialized
INFO - 2018-03-12 00:27:31 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:27:31 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:27:31 --> Utf8 Class Initialized
INFO - 2018-03-12 00:27:31 --> URI Class Initialized
INFO - 2018-03-12 00:27:31 --> Router Class Initialized
INFO - 2018-03-12 00:27:31 --> Output Class Initialized
INFO - 2018-03-12 00:27:31 --> Security Class Initialized
DEBUG - 2018-03-12 00:27:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:27:31 --> Input Class Initialized
INFO - 2018-03-12 00:27:31 --> Language Class Initialized
INFO - 2018-03-12 00:27:31 --> Loader Class Initialized
INFO - 2018-03-12 00:27:31 --> Helper loaded: url_helper
INFO - 2018-03-12 00:27:31 --> Helper loaded: form_helper
INFO - 2018-03-12 00:27:31 --> Database Driver Class Initialized
DEBUG - 2018-03-12 00:27:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 00:27:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 00:27:31 --> Form Validation Class Initialized
INFO - 2018-03-12 00:27:31 --> Model Class Initialized
INFO - 2018-03-12 00:27:31 --> Controller Class Initialized
INFO - 2018-03-12 00:27:31 --> Model Class Initialized
INFO - 2018-03-12 00:27:31 --> Model Class Initialized
INFO - 2018-03-12 00:27:31 --> Model Class Initialized
INFO - 2018-03-12 00:27:31 --> Model Class Initialized
INFO - 2018-03-12 00:27:31 --> Model Class Initialized
DEBUG - 2018-03-12 00:27:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-12 00:27:31 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-12 00:27:31 --> Final output sent to browser
DEBUG - 2018-03-12 00:27:31 --> Total execution time: 0.0852
INFO - 2018-03-12 00:27:31 --> Config Class Initialized
INFO - 2018-03-12 00:27:31 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:27:31 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:27:31 --> Utf8 Class Initialized
INFO - 2018-03-12 00:27:31 --> URI Class Initialized
INFO - 2018-03-12 00:27:31 --> Router Class Initialized
INFO - 2018-03-12 00:27:31 --> Output Class Initialized
INFO - 2018-03-12 00:27:31 --> Security Class Initialized
DEBUG - 2018-03-12 00:27:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:27:31 --> Input Class Initialized
INFO - 2018-03-12 00:27:31 --> Language Class Initialized
INFO - 2018-03-12 00:27:31 --> Loader Class Initialized
INFO - 2018-03-12 00:27:31 --> Helper loaded: url_helper
INFO - 2018-03-12 00:27:31 --> Helper loaded: form_helper
INFO - 2018-03-12 00:27:31 --> Database Driver Class Initialized
DEBUG - 2018-03-12 00:27:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 00:27:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 00:27:31 --> Form Validation Class Initialized
INFO - 2018-03-12 00:27:31 --> Model Class Initialized
INFO - 2018-03-12 00:27:31 --> Controller Class Initialized
INFO - 2018-03-12 00:27:31 --> Model Class Initialized
INFO - 2018-03-12 00:27:31 --> Model Class Initialized
INFO - 2018-03-12 00:27:31 --> Model Class Initialized
INFO - 2018-03-12 00:27:31 --> Model Class Initialized
INFO - 2018-03-12 00:27:31 --> Model Class Initialized
DEBUG - 2018-03-12 00:27:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-12 00:27:42 --> Config Class Initialized
INFO - 2018-03-12 00:27:42 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:27:42 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:27:42 --> Utf8 Class Initialized
INFO - 2018-03-12 00:27:42 --> URI Class Initialized
INFO - 2018-03-12 00:27:42 --> Router Class Initialized
INFO - 2018-03-12 00:27:42 --> Output Class Initialized
INFO - 2018-03-12 00:27:42 --> Security Class Initialized
DEBUG - 2018-03-12 00:27:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:27:42 --> Input Class Initialized
INFO - 2018-03-12 00:27:42 --> Language Class Initialized
INFO - 2018-03-12 00:27:42 --> Loader Class Initialized
INFO - 2018-03-12 00:27:42 --> Helper loaded: url_helper
INFO - 2018-03-12 00:27:42 --> Helper loaded: form_helper
INFO - 2018-03-12 00:27:42 --> Database Driver Class Initialized
DEBUG - 2018-03-12 00:27:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 00:27:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 00:27:42 --> Form Validation Class Initialized
INFO - 2018-03-12 00:27:42 --> Model Class Initialized
INFO - 2018-03-12 00:27:42 --> Controller Class Initialized
INFO - 2018-03-12 00:27:42 --> Model Class Initialized
INFO - 2018-03-12 00:27:42 --> Model Class Initialized
INFO - 2018-03-12 00:27:42 --> Model Class Initialized
INFO - 2018-03-12 00:27:42 --> Model Class Initialized
INFO - 2018-03-12 00:27:42 --> Model Class Initialized
DEBUG - 2018-03-12 00:27:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-12 00:27:42 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-12 00:27:42 --> Final output sent to browser
DEBUG - 2018-03-12 00:27:42 --> Total execution time: 0.0769
INFO - 2018-03-12 00:27:42 --> Config Class Initialized
INFO - 2018-03-12 00:27:42 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:27:42 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:27:42 --> Utf8 Class Initialized
INFO - 2018-03-12 00:27:42 --> URI Class Initialized
INFO - 2018-03-12 00:27:42 --> Router Class Initialized
INFO - 2018-03-12 00:27:42 --> Output Class Initialized
INFO - 2018-03-12 00:27:42 --> Security Class Initialized
DEBUG - 2018-03-12 00:27:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:27:42 --> Input Class Initialized
INFO - 2018-03-12 00:27:42 --> Language Class Initialized
INFO - 2018-03-12 00:27:42 --> Loader Class Initialized
INFO - 2018-03-12 00:27:42 --> Helper loaded: url_helper
INFO - 2018-03-12 00:27:42 --> Helper loaded: form_helper
INFO - 2018-03-12 00:27:42 --> Database Driver Class Initialized
DEBUG - 2018-03-12 00:27:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 00:27:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 00:27:42 --> Form Validation Class Initialized
INFO - 2018-03-12 00:27:42 --> Model Class Initialized
INFO - 2018-03-12 00:27:42 --> Controller Class Initialized
INFO - 2018-03-12 00:27:42 --> Model Class Initialized
INFO - 2018-03-12 00:27:42 --> Model Class Initialized
INFO - 2018-03-12 00:27:42 --> Model Class Initialized
INFO - 2018-03-12 00:27:42 --> Model Class Initialized
INFO - 2018-03-12 00:27:42 --> Model Class Initialized
DEBUG - 2018-03-12 00:27:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-12 00:27:46 --> Config Class Initialized
INFO - 2018-03-12 00:27:46 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:27:46 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:27:46 --> Utf8 Class Initialized
INFO - 2018-03-12 00:27:46 --> URI Class Initialized
INFO - 2018-03-12 00:27:46 --> Router Class Initialized
INFO - 2018-03-12 00:27:46 --> Output Class Initialized
INFO - 2018-03-12 00:27:46 --> Security Class Initialized
DEBUG - 2018-03-12 00:27:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:27:46 --> Input Class Initialized
INFO - 2018-03-12 00:27:46 --> Language Class Initialized
INFO - 2018-03-12 00:27:46 --> Loader Class Initialized
INFO - 2018-03-12 00:27:46 --> Helper loaded: url_helper
INFO - 2018-03-12 00:27:46 --> Helper loaded: form_helper
INFO - 2018-03-12 00:27:46 --> Database Driver Class Initialized
DEBUG - 2018-03-12 00:27:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 00:27:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 00:27:46 --> Form Validation Class Initialized
INFO - 2018-03-12 00:27:46 --> Model Class Initialized
INFO - 2018-03-12 00:27:46 --> Controller Class Initialized
INFO - 2018-03-12 00:27:46 --> Model Class Initialized
INFO - 2018-03-12 00:27:46 --> Model Class Initialized
INFO - 2018-03-12 00:27:46 --> Model Class Initialized
INFO - 2018-03-12 00:27:46 --> Model Class Initialized
INFO - 2018-03-12 00:27:46 --> Model Class Initialized
DEBUG - 2018-03-12 00:27:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-12 00:27:46 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-12 00:27:46 --> Final output sent to browser
DEBUG - 2018-03-12 00:27:46 --> Total execution time: 0.0516
INFO - 2018-03-12 00:27:46 --> Config Class Initialized
INFO - 2018-03-12 00:27:46 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:27:46 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:27:46 --> Utf8 Class Initialized
INFO - 2018-03-12 00:27:46 --> URI Class Initialized
INFO - 2018-03-12 00:27:46 --> Router Class Initialized
INFO - 2018-03-12 00:27:46 --> Output Class Initialized
INFO - 2018-03-12 00:27:46 --> Security Class Initialized
DEBUG - 2018-03-12 00:27:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:27:46 --> Input Class Initialized
INFO - 2018-03-12 00:27:46 --> Language Class Initialized
INFO - 2018-03-12 00:27:46 --> Loader Class Initialized
INFO - 2018-03-12 00:27:46 --> Helper loaded: url_helper
INFO - 2018-03-12 00:27:46 --> Helper loaded: form_helper
INFO - 2018-03-12 00:27:46 --> Database Driver Class Initialized
DEBUG - 2018-03-12 00:27:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 00:27:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 00:27:46 --> Form Validation Class Initialized
INFO - 2018-03-12 00:27:46 --> Model Class Initialized
INFO - 2018-03-12 00:27:46 --> Controller Class Initialized
INFO - 2018-03-12 00:27:46 --> Model Class Initialized
INFO - 2018-03-12 00:27:46 --> Model Class Initialized
INFO - 2018-03-12 00:27:46 --> Model Class Initialized
INFO - 2018-03-12 00:27:46 --> Model Class Initialized
INFO - 2018-03-12 00:27:46 --> Model Class Initialized
DEBUG - 2018-03-12 00:27:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-12 00:27:49 --> Config Class Initialized
INFO - 2018-03-12 00:27:49 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:27:49 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:27:49 --> Utf8 Class Initialized
INFO - 2018-03-12 00:27:49 --> URI Class Initialized
INFO - 2018-03-12 00:27:49 --> Router Class Initialized
INFO - 2018-03-12 00:27:49 --> Output Class Initialized
INFO - 2018-03-12 00:27:49 --> Security Class Initialized
DEBUG - 2018-03-12 00:27:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:27:49 --> Input Class Initialized
INFO - 2018-03-12 00:27:49 --> Language Class Initialized
INFO - 2018-03-12 00:27:49 --> Loader Class Initialized
INFO - 2018-03-12 00:27:49 --> Helper loaded: url_helper
INFO - 2018-03-12 00:27:49 --> Helper loaded: form_helper
INFO - 2018-03-12 00:27:49 --> Database Driver Class Initialized
DEBUG - 2018-03-12 00:27:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 00:27:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 00:27:49 --> Form Validation Class Initialized
INFO - 2018-03-12 00:27:49 --> Model Class Initialized
INFO - 2018-03-12 00:27:49 --> Controller Class Initialized
INFO - 2018-03-12 00:27:49 --> Model Class Initialized
INFO - 2018-03-12 00:27:49 --> Model Class Initialized
INFO - 2018-03-12 00:27:49 --> Model Class Initialized
INFO - 2018-03-12 00:27:49 --> Model Class Initialized
INFO - 2018-03-12 00:27:49 --> Model Class Initialized
DEBUG - 2018-03-12 00:27:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-12 00:27:49 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-12 00:27:49 --> Final output sent to browser
DEBUG - 2018-03-12 00:27:49 --> Total execution time: 0.0636
INFO - 2018-03-12 00:27:50 --> Config Class Initialized
INFO - 2018-03-12 00:27:50 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:27:50 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:27:50 --> Utf8 Class Initialized
INFO - 2018-03-12 00:27:50 --> URI Class Initialized
INFO - 2018-03-12 00:27:50 --> Router Class Initialized
INFO - 2018-03-12 00:27:50 --> Output Class Initialized
INFO - 2018-03-12 00:27:50 --> Security Class Initialized
DEBUG - 2018-03-12 00:27:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:27:50 --> Input Class Initialized
INFO - 2018-03-12 00:27:50 --> Language Class Initialized
INFO - 2018-03-12 00:27:50 --> Loader Class Initialized
INFO - 2018-03-12 00:27:50 --> Helper loaded: url_helper
INFO - 2018-03-12 00:27:50 --> Helper loaded: form_helper
INFO - 2018-03-12 00:27:50 --> Database Driver Class Initialized
DEBUG - 2018-03-12 00:27:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 00:27:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 00:27:50 --> Form Validation Class Initialized
INFO - 2018-03-12 00:27:50 --> Model Class Initialized
INFO - 2018-03-12 00:27:50 --> Controller Class Initialized
INFO - 2018-03-12 00:27:50 --> Model Class Initialized
INFO - 2018-03-12 00:27:50 --> Model Class Initialized
INFO - 2018-03-12 00:27:50 --> Model Class Initialized
INFO - 2018-03-12 00:27:50 --> Model Class Initialized
INFO - 2018-03-12 00:27:50 --> Model Class Initialized
DEBUG - 2018-03-12 00:27:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-12 00:31:46 --> Config Class Initialized
INFO - 2018-03-12 00:31:46 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:31:46 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:31:46 --> Utf8 Class Initialized
INFO - 2018-03-12 00:31:46 --> URI Class Initialized
INFO - 2018-03-12 00:31:46 --> Router Class Initialized
INFO - 2018-03-12 00:31:46 --> Output Class Initialized
INFO - 2018-03-12 00:31:46 --> Security Class Initialized
DEBUG - 2018-03-12 00:31:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:31:46 --> Input Class Initialized
INFO - 2018-03-12 00:31:46 --> Language Class Initialized
INFO - 2018-03-12 00:31:46 --> Loader Class Initialized
INFO - 2018-03-12 00:31:46 --> Helper loaded: url_helper
INFO - 2018-03-12 00:31:46 --> Helper loaded: form_helper
INFO - 2018-03-12 00:31:46 --> Database Driver Class Initialized
DEBUG - 2018-03-12 00:31:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 00:31:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 00:31:46 --> Form Validation Class Initialized
INFO - 2018-03-12 00:31:46 --> Model Class Initialized
INFO - 2018-03-12 00:31:46 --> Controller Class Initialized
INFO - 2018-03-12 00:31:46 --> Model Class Initialized
INFO - 2018-03-12 00:31:46 --> Model Class Initialized
INFO - 2018-03-12 00:31:46 --> Model Class Initialized
INFO - 2018-03-12 00:31:46 --> Model Class Initialized
INFO - 2018-03-12 00:31:46 --> Model Class Initialized
DEBUG - 2018-03-12 00:31:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-12 00:31:46 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-12 00:31:46 --> Final output sent to browser
DEBUG - 2018-03-12 00:31:46 --> Total execution time: 0.0606
INFO - 2018-03-12 00:31:46 --> Config Class Initialized
INFO - 2018-03-12 00:31:46 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:31:46 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:31:46 --> Utf8 Class Initialized
INFO - 2018-03-12 00:31:46 --> URI Class Initialized
INFO - 2018-03-12 00:31:46 --> Router Class Initialized
INFO - 2018-03-12 00:31:46 --> Output Class Initialized
INFO - 2018-03-12 00:31:46 --> Security Class Initialized
DEBUG - 2018-03-12 00:31:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:31:46 --> Input Class Initialized
INFO - 2018-03-12 00:31:46 --> Language Class Initialized
INFO - 2018-03-12 00:31:46 --> Loader Class Initialized
INFO - 2018-03-12 00:31:46 --> Helper loaded: url_helper
INFO - 2018-03-12 00:31:46 --> Helper loaded: form_helper
INFO - 2018-03-12 00:31:46 --> Database Driver Class Initialized
DEBUG - 2018-03-12 00:31:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 00:31:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 00:31:46 --> Form Validation Class Initialized
INFO - 2018-03-12 00:31:46 --> Model Class Initialized
INFO - 2018-03-12 00:31:46 --> Controller Class Initialized
INFO - 2018-03-12 00:31:46 --> Model Class Initialized
INFO - 2018-03-12 00:31:46 --> Model Class Initialized
INFO - 2018-03-12 00:31:46 --> Model Class Initialized
INFO - 2018-03-12 00:31:46 --> Model Class Initialized
INFO - 2018-03-12 00:31:46 --> Model Class Initialized
DEBUG - 2018-03-12 00:31:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-12 00:34:50 --> Config Class Initialized
INFO - 2018-03-12 00:34:50 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:34:50 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:34:50 --> Utf8 Class Initialized
INFO - 2018-03-12 00:34:50 --> URI Class Initialized
INFO - 2018-03-12 00:34:50 --> Router Class Initialized
INFO - 2018-03-12 00:34:50 --> Output Class Initialized
INFO - 2018-03-12 00:34:50 --> Security Class Initialized
DEBUG - 2018-03-12 00:34:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:34:50 --> Input Class Initialized
INFO - 2018-03-12 00:34:50 --> Language Class Initialized
INFO - 2018-03-12 00:34:50 --> Loader Class Initialized
INFO - 2018-03-12 00:34:50 --> Helper loaded: url_helper
INFO - 2018-03-12 00:34:50 --> Helper loaded: form_helper
INFO - 2018-03-12 00:34:50 --> Database Driver Class Initialized
DEBUG - 2018-03-12 00:34:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 00:34:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 00:34:50 --> Form Validation Class Initialized
INFO - 2018-03-12 00:34:50 --> Model Class Initialized
INFO - 2018-03-12 00:34:50 --> Controller Class Initialized
INFO - 2018-03-12 00:34:50 --> Model Class Initialized
INFO - 2018-03-12 00:34:50 --> Model Class Initialized
INFO - 2018-03-12 00:34:50 --> Model Class Initialized
INFO - 2018-03-12 00:34:50 --> Model Class Initialized
INFO - 2018-03-12 00:34:50 --> Model Class Initialized
DEBUG - 2018-03-12 00:34:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-12 00:34:50 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-12 00:34:50 --> Final output sent to browser
DEBUG - 2018-03-12 00:34:50 --> Total execution time: 0.0718
INFO - 2018-03-12 00:34:50 --> Config Class Initialized
INFO - 2018-03-12 00:34:50 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:34:50 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:34:50 --> Utf8 Class Initialized
INFO - 2018-03-12 00:34:50 --> URI Class Initialized
INFO - 2018-03-12 00:34:50 --> Router Class Initialized
INFO - 2018-03-12 00:34:50 --> Output Class Initialized
INFO - 2018-03-12 00:34:50 --> Security Class Initialized
DEBUG - 2018-03-12 00:34:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:34:50 --> Input Class Initialized
INFO - 2018-03-12 00:34:50 --> Language Class Initialized
INFO - 2018-03-12 00:34:50 --> Loader Class Initialized
INFO - 2018-03-12 00:34:50 --> Helper loaded: url_helper
INFO - 2018-03-12 00:34:50 --> Helper loaded: form_helper
INFO - 2018-03-12 00:34:50 --> Database Driver Class Initialized
DEBUG - 2018-03-12 00:34:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 00:34:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 00:34:50 --> Form Validation Class Initialized
INFO - 2018-03-12 00:34:50 --> Model Class Initialized
INFO - 2018-03-12 00:34:50 --> Controller Class Initialized
INFO - 2018-03-12 00:34:50 --> Model Class Initialized
INFO - 2018-03-12 00:34:50 --> Model Class Initialized
INFO - 2018-03-12 00:34:50 --> Model Class Initialized
INFO - 2018-03-12 00:34:50 --> Model Class Initialized
INFO - 2018-03-12 00:34:50 --> Model Class Initialized
DEBUG - 2018-03-12 00:34:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-12 00:34:56 --> Config Class Initialized
INFO - 2018-03-12 00:34:56 --> Hooks Class Initialized
INFO - 2018-03-12 00:34:56 --> Config Class Initialized
INFO - 2018-03-12 00:34:56 --> Hooks Class Initialized
INFO - 2018-03-12 00:34:56 --> Config Class Initialized
INFO - 2018-03-12 00:34:56 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:34:56 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:34:56 --> Utf8 Class Initialized
INFO - 2018-03-12 00:34:56 --> Config Class Initialized
DEBUG - 2018-03-12 00:34:56 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:34:56 --> Hooks Class Initialized
INFO - 2018-03-12 00:34:56 --> Utf8 Class Initialized
INFO - 2018-03-12 00:34:56 --> URI Class Initialized
DEBUG - 2018-03-12 00:34:56 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:34:56 --> Utf8 Class Initialized
INFO - 2018-03-12 00:34:56 --> URI Class Initialized
INFO - 2018-03-12 00:34:56 --> URI Class Initialized
INFO - 2018-03-12 00:34:56 --> Router Class Initialized
DEBUG - 2018-03-12 00:34:56 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:34:56 --> Utf8 Class Initialized
INFO - 2018-03-12 00:34:56 --> Router Class Initialized
INFO - 2018-03-12 00:34:56 --> URI Class Initialized
INFO - 2018-03-12 00:34:56 --> Router Class Initialized
INFO - 2018-03-12 00:34:56 --> Output Class Initialized
INFO - 2018-03-12 00:34:56 --> Output Class Initialized
INFO - 2018-03-12 00:34:56 --> Output Class Initialized
INFO - 2018-03-12 00:34:56 --> Router Class Initialized
INFO - 2018-03-12 00:34:56 --> Security Class Initialized
INFO - 2018-03-12 00:34:56 --> Security Class Initialized
INFO - 2018-03-12 00:34:56 --> Security Class Initialized
DEBUG - 2018-03-12 00:34:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:34:56 --> Input Class Initialized
DEBUG - 2018-03-12 00:34:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:34:56 --> Output Class Initialized
INFO - 2018-03-12 00:34:56 --> Input Class Initialized
INFO - 2018-03-12 00:34:56 --> Language Class Initialized
DEBUG - 2018-03-12 00:34:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:34:56 --> Language Class Initialized
INFO - 2018-03-12 00:34:56 --> Input Class Initialized
INFO - 2018-03-12 00:34:56 --> Security Class Initialized
ERROR - 2018-03-12 00:34:56 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-12 00:34:56 --> Language Class Initialized
ERROR - 2018-03-12 00:34:56 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-12 00:34:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:34:56 --> Input Class Initialized
ERROR - 2018-03-12 00:34:56 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-12 00:34:56 --> Language Class Initialized
ERROR - 2018-03-12 00:34:56 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-12 00:34:56 --> Config Class Initialized
INFO - 2018-03-12 00:34:56 --> Hooks Class Initialized
INFO - 2018-03-12 00:34:56 --> Config Class Initialized
INFO - 2018-03-12 00:34:56 --> Hooks Class Initialized
INFO - 2018-03-12 00:34:56 --> Config Class Initialized
INFO - 2018-03-12 00:34:56 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:34:56 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 00:34:56 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:34:56 --> Utf8 Class Initialized
INFO - 2018-03-12 00:34:56 --> Utf8 Class Initialized
DEBUG - 2018-03-12 00:34:56 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:34:56 --> Utf8 Class Initialized
INFO - 2018-03-12 00:34:56 --> URI Class Initialized
INFO - 2018-03-12 00:34:56 --> URI Class Initialized
INFO - 2018-03-12 00:34:56 --> URI Class Initialized
INFO - 2018-03-12 00:34:56 --> Router Class Initialized
INFO - 2018-03-12 00:34:56 --> Router Class Initialized
INFO - 2018-03-12 00:34:56 --> Router Class Initialized
INFO - 2018-03-12 00:34:56 --> Output Class Initialized
INFO - 2018-03-12 00:34:56 --> Output Class Initialized
INFO - 2018-03-12 00:34:56 --> Output Class Initialized
INFO - 2018-03-12 00:34:56 --> Security Class Initialized
INFO - 2018-03-12 00:34:56 --> Security Class Initialized
INFO - 2018-03-12 00:34:56 --> Security Class Initialized
DEBUG - 2018-03-12 00:34:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:34:56 --> Input Class Initialized
DEBUG - 2018-03-12 00:34:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 00:34:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:34:56 --> Language Class Initialized
INFO - 2018-03-12 00:34:56 --> Input Class Initialized
INFO - 2018-03-12 00:34:56 --> Input Class Initialized
INFO - 2018-03-12 00:34:56 --> Language Class Initialized
INFO - 2018-03-12 00:34:56 --> Language Class Initialized
ERROR - 2018-03-12 00:34:56 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-12 00:34:56 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-12 00:34:56 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-12 00:35:11 --> Config Class Initialized
INFO - 2018-03-12 00:35:11 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:35:11 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:35:11 --> Utf8 Class Initialized
INFO - 2018-03-12 00:35:11 --> URI Class Initialized
INFO - 2018-03-12 00:35:11 --> Router Class Initialized
INFO - 2018-03-12 00:35:11 --> Output Class Initialized
INFO - 2018-03-12 00:35:11 --> Security Class Initialized
DEBUG - 2018-03-12 00:35:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:35:11 --> Input Class Initialized
INFO - 2018-03-12 00:35:11 --> Language Class Initialized
INFO - 2018-03-12 00:35:11 --> Loader Class Initialized
INFO - 2018-03-12 00:35:11 --> Helper loaded: url_helper
INFO - 2018-03-12 00:35:11 --> Helper loaded: form_helper
INFO - 2018-03-12 00:35:11 --> Database Driver Class Initialized
DEBUG - 2018-03-12 00:35:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 00:35:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 00:35:11 --> Form Validation Class Initialized
INFO - 2018-03-12 00:35:11 --> Model Class Initialized
INFO - 2018-03-12 00:35:11 --> Controller Class Initialized
INFO - 2018-03-12 00:35:11 --> Model Class Initialized
INFO - 2018-03-12 00:35:11 --> Model Class Initialized
INFO - 2018-03-12 00:35:11 --> Model Class Initialized
INFO - 2018-03-12 00:35:11 --> Model Class Initialized
INFO - 2018-03-12 00:35:11 --> Model Class Initialized
DEBUG - 2018-03-12 00:35:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-12 00:35:11 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-12 00:35:11 --> Final output sent to browser
DEBUG - 2018-03-12 00:35:11 --> Total execution time: 0.0625
INFO - 2018-03-12 00:35:11 --> Config Class Initialized
INFO - 2018-03-12 00:35:11 --> Hooks Class Initialized
INFO - 2018-03-12 00:35:11 --> Config Class Initialized
INFO - 2018-03-12 00:35:11 --> Hooks Class Initialized
INFO - 2018-03-12 00:35:11 --> Config Class Initialized
INFO - 2018-03-12 00:35:11 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:35:11 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:35:11 --> Utf8 Class Initialized
DEBUG - 2018-03-12 00:35:11 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 00:35:11 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:35:11 --> Utf8 Class Initialized
INFO - 2018-03-12 00:35:11 --> URI Class Initialized
INFO - 2018-03-12 00:35:11 --> Utf8 Class Initialized
INFO - 2018-03-12 00:35:11 --> URI Class Initialized
INFO - 2018-03-12 00:35:11 --> URI Class Initialized
INFO - 2018-03-12 00:35:11 --> Router Class Initialized
INFO - 2018-03-12 00:35:11 --> Config Class Initialized
INFO - 2018-03-12 00:35:11 --> Hooks Class Initialized
INFO - 2018-03-12 00:35:11 --> Router Class Initialized
INFO - 2018-03-12 00:35:11 --> Router Class Initialized
INFO - 2018-03-12 00:35:11 --> Output Class Initialized
INFO - 2018-03-12 00:35:11 --> Output Class Initialized
INFO - 2018-03-12 00:35:11 --> Output Class Initialized
DEBUG - 2018-03-12 00:35:11 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:35:11 --> Utf8 Class Initialized
INFO - 2018-03-12 00:35:11 --> Security Class Initialized
INFO - 2018-03-12 00:35:11 --> Security Class Initialized
INFO - 2018-03-12 00:35:11 --> Security Class Initialized
INFO - 2018-03-12 00:35:11 --> URI Class Initialized
DEBUG - 2018-03-12 00:35:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:35:11 --> Input Class Initialized
DEBUG - 2018-03-12 00:35:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 00:35:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:35:11 --> Input Class Initialized
INFO - 2018-03-12 00:35:11 --> Language Class Initialized
INFO - 2018-03-12 00:35:11 --> Input Class Initialized
INFO - 2018-03-12 00:35:11 --> Language Class Initialized
INFO - 2018-03-12 00:35:11 --> Language Class Initialized
INFO - 2018-03-12 00:35:11 --> Router Class Initialized
ERROR - 2018-03-12 00:35:11 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-12 00:35:11 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-12 00:35:11 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-12 00:35:11 --> Output Class Initialized
INFO - 2018-03-12 00:35:11 --> Security Class Initialized
DEBUG - 2018-03-12 00:35:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:35:11 --> Input Class Initialized
INFO - 2018-03-12 00:35:11 --> Language Class Initialized
ERROR - 2018-03-12 00:35:11 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-12 00:35:11 --> Config Class Initialized
INFO - 2018-03-12 00:35:11 --> Hooks Class Initialized
INFO - 2018-03-12 00:35:11 --> Config Class Initialized
INFO - 2018-03-12 00:35:11 --> Hooks Class Initialized
INFO - 2018-03-12 00:35:11 --> Config Class Initialized
INFO - 2018-03-12 00:35:11 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:35:11 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:35:11 --> Utf8 Class Initialized
DEBUG - 2018-03-12 00:35:11 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 00:35:11 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:35:11 --> Utf8 Class Initialized
INFO - 2018-03-12 00:35:11 --> Utf8 Class Initialized
INFO - 2018-03-12 00:35:11 --> URI Class Initialized
INFO - 2018-03-12 00:35:11 --> URI Class Initialized
INFO - 2018-03-12 00:35:11 --> URI Class Initialized
INFO - 2018-03-12 00:35:11 --> Router Class Initialized
INFO - 2018-03-12 00:35:11 --> Router Class Initialized
INFO - 2018-03-12 00:35:11 --> Router Class Initialized
INFO - 2018-03-12 00:35:11 --> Output Class Initialized
INFO - 2018-03-12 00:35:11 --> Output Class Initialized
INFO - 2018-03-12 00:35:11 --> Output Class Initialized
INFO - 2018-03-12 00:35:11 --> Security Class Initialized
INFO - 2018-03-12 00:35:11 --> Security Class Initialized
INFO - 2018-03-12 00:35:11 --> Security Class Initialized
DEBUG - 2018-03-12 00:35:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 00:35:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:35:11 --> Input Class Initialized
INFO - 2018-03-12 00:35:11 --> Input Class Initialized
INFO - 2018-03-12 00:35:11 --> Language Class Initialized
DEBUG - 2018-03-12 00:35:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:35:11 --> Language Class Initialized
INFO - 2018-03-12 00:35:11 --> Input Class Initialized
INFO - 2018-03-12 00:35:11 --> Language Class Initialized
ERROR - 2018-03-12 00:35:11 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-12 00:35:11 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-12 00:35:11 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-12 00:35:11 --> Config Class Initialized
INFO - 2018-03-12 00:35:11 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:35:11 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:35:11 --> Utf8 Class Initialized
INFO - 2018-03-12 00:35:11 --> URI Class Initialized
INFO - 2018-03-12 00:35:11 --> Router Class Initialized
INFO - 2018-03-12 00:35:11 --> Output Class Initialized
INFO - 2018-03-12 00:35:11 --> Security Class Initialized
DEBUG - 2018-03-12 00:35:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:35:11 --> Input Class Initialized
INFO - 2018-03-12 00:35:11 --> Language Class Initialized
INFO - 2018-03-12 00:35:11 --> Loader Class Initialized
INFO - 2018-03-12 00:35:11 --> Helper loaded: url_helper
INFO - 2018-03-12 00:35:11 --> Helper loaded: form_helper
INFO - 2018-03-12 00:35:11 --> Database Driver Class Initialized
DEBUG - 2018-03-12 00:35:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 00:35:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 00:35:11 --> Form Validation Class Initialized
INFO - 2018-03-12 00:35:11 --> Model Class Initialized
INFO - 2018-03-12 00:35:11 --> Controller Class Initialized
INFO - 2018-03-12 00:35:11 --> Model Class Initialized
INFO - 2018-03-12 00:35:11 --> Model Class Initialized
INFO - 2018-03-12 00:35:11 --> Model Class Initialized
INFO - 2018-03-12 00:35:11 --> Model Class Initialized
INFO - 2018-03-12 00:35:11 --> Model Class Initialized
DEBUG - 2018-03-12 00:35:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-12 00:35:24 --> Config Class Initialized
INFO - 2018-03-12 00:35:24 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:35:24 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:35:24 --> Utf8 Class Initialized
INFO - 2018-03-12 00:35:24 --> URI Class Initialized
INFO - 2018-03-12 00:35:24 --> Router Class Initialized
INFO - 2018-03-12 00:35:24 --> Output Class Initialized
INFO - 2018-03-12 00:35:24 --> Security Class Initialized
DEBUG - 2018-03-12 00:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:35:24 --> Input Class Initialized
INFO - 2018-03-12 00:35:24 --> Language Class Initialized
INFO - 2018-03-12 00:35:24 --> Loader Class Initialized
INFO - 2018-03-12 00:35:24 --> Helper loaded: url_helper
INFO - 2018-03-12 00:35:24 --> Helper loaded: form_helper
INFO - 2018-03-12 00:35:24 --> Database Driver Class Initialized
DEBUG - 2018-03-12 00:35:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 00:35:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 00:35:24 --> Form Validation Class Initialized
INFO - 2018-03-12 00:35:24 --> Model Class Initialized
INFO - 2018-03-12 00:35:24 --> Controller Class Initialized
INFO - 2018-03-12 00:35:24 --> Model Class Initialized
INFO - 2018-03-12 00:35:24 --> Model Class Initialized
INFO - 2018-03-12 00:35:24 --> Model Class Initialized
INFO - 2018-03-12 00:35:24 --> Model Class Initialized
INFO - 2018-03-12 00:35:24 --> Model Class Initialized
DEBUG - 2018-03-12 00:35:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-12 00:35:24 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-12 00:35:24 --> Final output sent to browser
DEBUG - 2018-03-12 00:35:24 --> Total execution time: 0.0535
INFO - 2018-03-12 00:35:24 --> Config Class Initialized
INFO - 2018-03-12 00:35:24 --> Config Class Initialized
INFO - 2018-03-12 00:35:24 --> Hooks Class Initialized
INFO - 2018-03-12 00:35:24 --> Hooks Class Initialized
INFO - 2018-03-12 00:35:24 --> Config Class Initialized
INFO - 2018-03-12 00:35:24 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:35:24 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 00:35:24 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:35:24 --> Utf8 Class Initialized
INFO - 2018-03-12 00:35:24 --> Utf8 Class Initialized
DEBUG - 2018-03-12 00:35:24 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:35:24 --> Utf8 Class Initialized
INFO - 2018-03-12 00:35:24 --> Config Class Initialized
INFO - 2018-03-12 00:35:24 --> URI Class Initialized
INFO - 2018-03-12 00:35:24 --> URI Class Initialized
INFO - 2018-03-12 00:35:24 --> Hooks Class Initialized
INFO - 2018-03-12 00:35:24 --> URI Class Initialized
INFO - 2018-03-12 00:35:24 --> Router Class Initialized
INFO - 2018-03-12 00:35:24 --> Router Class Initialized
INFO - 2018-03-12 00:35:24 --> Router Class Initialized
DEBUG - 2018-03-12 00:35:24 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:35:24 --> Utf8 Class Initialized
INFO - 2018-03-12 00:35:24 --> Output Class Initialized
INFO - 2018-03-12 00:35:24 --> Output Class Initialized
INFO - 2018-03-12 00:35:24 --> URI Class Initialized
INFO - 2018-03-12 00:35:24 --> Output Class Initialized
INFO - 2018-03-12 00:35:24 --> Security Class Initialized
INFO - 2018-03-12 00:35:24 --> Security Class Initialized
INFO - 2018-03-12 00:35:24 --> Router Class Initialized
INFO - 2018-03-12 00:35:24 --> Security Class Initialized
DEBUG - 2018-03-12 00:35:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 00:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:35:24 --> Input Class Initialized
DEBUG - 2018-03-12 00:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:35:24 --> Input Class Initialized
INFO - 2018-03-12 00:35:24 --> Output Class Initialized
INFO - 2018-03-12 00:35:24 --> Input Class Initialized
INFO - 2018-03-12 00:35:24 --> Language Class Initialized
INFO - 2018-03-12 00:35:24 --> Language Class Initialized
INFO - 2018-03-12 00:35:24 --> Language Class Initialized
INFO - 2018-03-12 00:35:24 --> Security Class Initialized
ERROR - 2018-03-12 00:35:24 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-12 00:35:24 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-12 00:35:24 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-12 00:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:35:24 --> Input Class Initialized
INFO - 2018-03-12 00:35:24 --> Language Class Initialized
ERROR - 2018-03-12 00:35:24 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-12 00:35:24 --> Config Class Initialized
INFO - 2018-03-12 00:35:24 --> Hooks Class Initialized
INFO - 2018-03-12 00:35:24 --> Config Class Initialized
INFO - 2018-03-12 00:35:24 --> Hooks Class Initialized
INFO - 2018-03-12 00:35:24 --> Config Class Initialized
INFO - 2018-03-12 00:35:24 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:35:24 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 00:35:24 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:35:24 --> Utf8 Class Initialized
INFO - 2018-03-12 00:35:24 --> Utf8 Class Initialized
DEBUG - 2018-03-12 00:35:24 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:35:24 --> Utf8 Class Initialized
INFO - 2018-03-12 00:35:24 --> URI Class Initialized
INFO - 2018-03-12 00:35:24 --> URI Class Initialized
INFO - 2018-03-12 00:35:24 --> URI Class Initialized
INFO - 2018-03-12 00:35:24 --> Router Class Initialized
INFO - 2018-03-12 00:35:24 --> Router Class Initialized
INFO - 2018-03-12 00:35:24 --> Router Class Initialized
INFO - 2018-03-12 00:35:24 --> Output Class Initialized
INFO - 2018-03-12 00:35:24 --> Output Class Initialized
INFO - 2018-03-12 00:35:24 --> Output Class Initialized
INFO - 2018-03-12 00:35:24 --> Security Class Initialized
INFO - 2018-03-12 00:35:24 --> Security Class Initialized
INFO - 2018-03-12 00:35:24 --> Security Class Initialized
DEBUG - 2018-03-12 00:35:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 00:35:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 00:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:35:24 --> Input Class Initialized
INFO - 2018-03-12 00:35:24 --> Input Class Initialized
INFO - 2018-03-12 00:35:24 --> Input Class Initialized
INFO - 2018-03-12 00:35:24 --> Language Class Initialized
INFO - 2018-03-12 00:35:24 --> Language Class Initialized
INFO - 2018-03-12 00:35:24 --> Language Class Initialized
ERROR - 2018-03-12 00:35:24 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-12 00:35:24 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-12 00:35:24 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-12 00:35:25 --> Config Class Initialized
INFO - 2018-03-12 00:35:25 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:35:25 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:35:25 --> Utf8 Class Initialized
INFO - 2018-03-12 00:35:25 --> URI Class Initialized
INFO - 2018-03-12 00:35:25 --> Router Class Initialized
INFO - 2018-03-12 00:35:25 --> Output Class Initialized
INFO - 2018-03-12 00:35:25 --> Security Class Initialized
DEBUG - 2018-03-12 00:35:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:35:25 --> Input Class Initialized
INFO - 2018-03-12 00:35:25 --> Language Class Initialized
INFO - 2018-03-12 00:35:25 --> Loader Class Initialized
INFO - 2018-03-12 00:35:25 --> Helper loaded: url_helper
INFO - 2018-03-12 00:35:25 --> Helper loaded: form_helper
INFO - 2018-03-12 00:35:25 --> Database Driver Class Initialized
DEBUG - 2018-03-12 00:35:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 00:35:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 00:35:25 --> Form Validation Class Initialized
INFO - 2018-03-12 00:35:25 --> Model Class Initialized
INFO - 2018-03-12 00:35:25 --> Controller Class Initialized
INFO - 2018-03-12 00:35:25 --> Model Class Initialized
INFO - 2018-03-12 00:35:25 --> Model Class Initialized
INFO - 2018-03-12 00:35:25 --> Model Class Initialized
INFO - 2018-03-12 00:35:25 --> Model Class Initialized
INFO - 2018-03-12 00:35:25 --> Model Class Initialized
DEBUG - 2018-03-12 00:35:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-12 00:38:02 --> Config Class Initialized
INFO - 2018-03-12 00:38:02 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:38:02 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:38:02 --> Utf8 Class Initialized
INFO - 2018-03-12 00:38:02 --> URI Class Initialized
INFO - 2018-03-12 00:38:02 --> Router Class Initialized
INFO - 2018-03-12 00:38:02 --> Output Class Initialized
INFO - 2018-03-12 00:38:02 --> Security Class Initialized
DEBUG - 2018-03-12 00:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:38:02 --> Input Class Initialized
INFO - 2018-03-12 00:38:02 --> Language Class Initialized
INFO - 2018-03-12 00:38:02 --> Loader Class Initialized
INFO - 2018-03-12 00:38:02 --> Helper loaded: url_helper
INFO - 2018-03-12 00:38:02 --> Helper loaded: form_helper
INFO - 2018-03-12 00:38:02 --> Database Driver Class Initialized
DEBUG - 2018-03-12 00:38:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 00:38:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 00:38:02 --> Form Validation Class Initialized
INFO - 2018-03-12 00:38:02 --> Model Class Initialized
INFO - 2018-03-12 00:38:02 --> Controller Class Initialized
INFO - 2018-03-12 00:38:02 --> Model Class Initialized
INFO - 2018-03-12 00:38:02 --> Model Class Initialized
INFO - 2018-03-12 00:38:02 --> Model Class Initialized
INFO - 2018-03-12 00:38:02 --> Model Class Initialized
INFO - 2018-03-12 00:38:02 --> Model Class Initialized
DEBUG - 2018-03-12 00:38:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-12 00:38:02 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-12 00:38:02 --> Final output sent to browser
DEBUG - 2018-03-12 00:38:02 --> Total execution time: 0.0655
INFO - 2018-03-12 00:38:02 --> Config Class Initialized
INFO - 2018-03-12 00:38:02 --> Hooks Class Initialized
INFO - 2018-03-12 00:38:02 --> Config Class Initialized
INFO - 2018-03-12 00:38:02 --> Hooks Class Initialized
INFO - 2018-03-12 00:38:02 --> Config Class Initialized
INFO - 2018-03-12 00:38:02 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:38:02 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:38:02 --> Utf8 Class Initialized
INFO - 2018-03-12 00:38:02 --> Config Class Initialized
DEBUG - 2018-03-12 00:38:02 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:38:02 --> URI Class Initialized
INFO - 2018-03-12 00:38:02 --> Hooks Class Initialized
INFO - 2018-03-12 00:38:02 --> Utf8 Class Initialized
DEBUG - 2018-03-12 00:38:02 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:38:02 --> Utf8 Class Initialized
INFO - 2018-03-12 00:38:02 --> URI Class Initialized
INFO - 2018-03-12 00:38:02 --> Router Class Initialized
INFO - 2018-03-12 00:38:02 --> URI Class Initialized
DEBUG - 2018-03-12 00:38:02 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:38:02 --> Utf8 Class Initialized
INFO - 2018-03-12 00:38:02 --> Router Class Initialized
INFO - 2018-03-12 00:38:02 --> Output Class Initialized
INFO - 2018-03-12 00:38:02 --> URI Class Initialized
INFO - 2018-03-12 00:38:02 --> Router Class Initialized
INFO - 2018-03-12 00:38:02 --> Output Class Initialized
INFO - 2018-03-12 00:38:02 --> Security Class Initialized
INFO - 2018-03-12 00:38:02 --> Router Class Initialized
INFO - 2018-03-12 00:38:02 --> Security Class Initialized
INFO - 2018-03-12 00:38:02 --> Output Class Initialized
DEBUG - 2018-03-12 00:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:38:02 --> Input Class Initialized
INFO - 2018-03-12 00:38:02 --> Output Class Initialized
DEBUG - 2018-03-12 00:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:38:02 --> Language Class Initialized
INFO - 2018-03-12 00:38:02 --> Input Class Initialized
INFO - 2018-03-12 00:38:02 --> Security Class Initialized
INFO - 2018-03-12 00:38:02 --> Language Class Initialized
INFO - 2018-03-12 00:38:02 --> Security Class Initialized
ERROR - 2018-03-12 00:38:02 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-12 00:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:38:02 --> Input Class Initialized
ERROR - 2018-03-12 00:38:02 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-12 00:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:38:02 --> Language Class Initialized
INFO - 2018-03-12 00:38:02 --> Input Class Initialized
INFO - 2018-03-12 00:38:02 --> Language Class Initialized
ERROR - 2018-03-12 00:38:02 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-12 00:38:02 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-12 00:38:02 --> Config Class Initialized
INFO - 2018-03-12 00:38:02 --> Hooks Class Initialized
INFO - 2018-03-12 00:38:02 --> Config Class Initialized
INFO - 2018-03-12 00:38:02 --> Config Class Initialized
INFO - 2018-03-12 00:38:02 --> Hooks Class Initialized
INFO - 2018-03-12 00:38:02 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:38:02 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:38:02 --> Utf8 Class Initialized
DEBUG - 2018-03-12 00:38:02 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:38:02 --> Utf8 Class Initialized
DEBUG - 2018-03-12 00:38:02 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:38:02 --> Utf8 Class Initialized
INFO - 2018-03-12 00:38:02 --> URI Class Initialized
INFO - 2018-03-12 00:38:02 --> URI Class Initialized
INFO - 2018-03-12 00:38:02 --> URI Class Initialized
INFO - 2018-03-12 00:38:02 --> Router Class Initialized
INFO - 2018-03-12 00:38:02 --> Router Class Initialized
INFO - 2018-03-12 00:38:02 --> Router Class Initialized
INFO - 2018-03-12 00:38:02 --> Output Class Initialized
INFO - 2018-03-12 00:38:02 --> Output Class Initialized
INFO - 2018-03-12 00:38:02 --> Security Class Initialized
INFO - 2018-03-12 00:38:02 --> Output Class Initialized
DEBUG - 2018-03-12 00:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:38:02 --> Security Class Initialized
INFO - 2018-03-12 00:38:02 --> Input Class Initialized
INFO - 2018-03-12 00:38:02 --> Security Class Initialized
INFO - 2018-03-12 00:38:02 --> Language Class Initialized
DEBUG - 2018-03-12 00:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:38:02 --> Input Class Initialized
DEBUG - 2018-03-12 00:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:38:02 --> Input Class Initialized
INFO - 2018-03-12 00:38:02 --> Language Class Initialized
ERROR - 2018-03-12 00:38:02 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-12 00:38:02 --> Language Class Initialized
ERROR - 2018-03-12 00:38:02 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-12 00:38:02 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-12 00:38:02 --> Config Class Initialized
INFO - 2018-03-12 00:38:02 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:38:02 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:38:02 --> Utf8 Class Initialized
INFO - 2018-03-12 00:38:02 --> URI Class Initialized
INFO - 2018-03-12 00:38:02 --> Router Class Initialized
INFO - 2018-03-12 00:38:02 --> Output Class Initialized
INFO - 2018-03-12 00:38:02 --> Security Class Initialized
DEBUG - 2018-03-12 00:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:38:02 --> Input Class Initialized
INFO - 2018-03-12 00:38:02 --> Language Class Initialized
INFO - 2018-03-12 00:38:02 --> Loader Class Initialized
INFO - 2018-03-12 00:38:02 --> Helper loaded: url_helper
INFO - 2018-03-12 00:38:02 --> Helper loaded: form_helper
INFO - 2018-03-12 00:38:02 --> Database Driver Class Initialized
DEBUG - 2018-03-12 00:38:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 00:38:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 00:38:02 --> Form Validation Class Initialized
INFO - 2018-03-12 00:38:02 --> Model Class Initialized
INFO - 2018-03-12 00:38:02 --> Controller Class Initialized
INFO - 2018-03-12 00:38:02 --> Model Class Initialized
INFO - 2018-03-12 00:38:02 --> Model Class Initialized
INFO - 2018-03-12 00:38:02 --> Model Class Initialized
INFO - 2018-03-12 00:38:02 --> Model Class Initialized
INFO - 2018-03-12 00:38:02 --> Model Class Initialized
DEBUG - 2018-03-12 00:38:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-12 00:38:21 --> Config Class Initialized
INFO - 2018-03-12 00:38:21 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:38:21 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:38:21 --> Utf8 Class Initialized
INFO - 2018-03-12 00:38:21 --> URI Class Initialized
INFO - 2018-03-12 00:38:21 --> Router Class Initialized
INFO - 2018-03-12 00:38:21 --> Output Class Initialized
INFO - 2018-03-12 00:38:21 --> Security Class Initialized
DEBUG - 2018-03-12 00:38:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:38:21 --> Input Class Initialized
INFO - 2018-03-12 00:38:21 --> Language Class Initialized
INFO - 2018-03-12 00:38:21 --> Loader Class Initialized
INFO - 2018-03-12 00:38:21 --> Helper loaded: url_helper
INFO - 2018-03-12 00:38:21 --> Helper loaded: form_helper
INFO - 2018-03-12 00:38:21 --> Database Driver Class Initialized
DEBUG - 2018-03-12 00:38:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 00:38:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 00:38:21 --> Form Validation Class Initialized
INFO - 2018-03-12 00:38:21 --> Model Class Initialized
INFO - 2018-03-12 00:38:21 --> Controller Class Initialized
INFO - 2018-03-12 00:38:21 --> Model Class Initialized
INFO - 2018-03-12 00:38:21 --> Model Class Initialized
INFO - 2018-03-12 00:38:21 --> Model Class Initialized
INFO - 2018-03-12 00:38:21 --> Model Class Initialized
INFO - 2018-03-12 00:38:21 --> Model Class Initialized
DEBUG - 2018-03-12 00:38:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-12 00:38:21 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-12 00:38:21 --> Final output sent to browser
DEBUG - 2018-03-12 00:38:21 --> Total execution time: 0.0874
INFO - 2018-03-12 00:38:21 --> Config Class Initialized
INFO - 2018-03-12 00:38:21 --> Config Class Initialized
INFO - 2018-03-12 00:38:21 --> Hooks Class Initialized
INFO - 2018-03-12 00:38:21 --> Hooks Class Initialized
INFO - 2018-03-12 00:38:21 --> Config Class Initialized
INFO - 2018-03-12 00:38:21 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:38:21 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:38:21 --> Utf8 Class Initialized
DEBUG - 2018-03-12 00:38:21 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:38:21 --> Utf8 Class Initialized
INFO - 2018-03-12 00:38:21 --> Config Class Initialized
INFO - 2018-03-12 00:38:21 --> URI Class Initialized
INFO - 2018-03-12 00:38:21 --> Hooks Class Initialized
INFO - 2018-03-12 00:38:21 --> URI Class Initialized
DEBUG - 2018-03-12 00:38:21 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:38:21 --> Utf8 Class Initialized
INFO - 2018-03-12 00:38:21 --> Router Class Initialized
DEBUG - 2018-03-12 00:38:21 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:38:21 --> URI Class Initialized
INFO - 2018-03-12 00:38:21 --> Router Class Initialized
INFO - 2018-03-12 00:38:21 --> Utf8 Class Initialized
INFO - 2018-03-12 00:38:21 --> Output Class Initialized
INFO - 2018-03-12 00:38:21 --> URI Class Initialized
INFO - 2018-03-12 00:38:21 --> Router Class Initialized
INFO - 2018-03-12 00:38:21 --> Output Class Initialized
INFO - 2018-03-12 00:38:21 --> Security Class Initialized
INFO - 2018-03-12 00:38:21 --> Router Class Initialized
INFO - 2018-03-12 00:38:21 --> Output Class Initialized
DEBUG - 2018-03-12 00:38:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:38:21 --> Security Class Initialized
INFO - 2018-03-12 00:38:21 --> Input Class Initialized
INFO - 2018-03-12 00:38:21 --> Output Class Initialized
INFO - 2018-03-12 00:38:21 --> Language Class Initialized
DEBUG - 2018-03-12 00:38:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:38:21 --> Security Class Initialized
INFO - 2018-03-12 00:38:21 --> Input Class Initialized
INFO - 2018-03-12 00:38:21 --> Security Class Initialized
INFO - 2018-03-12 00:38:21 --> Language Class Initialized
ERROR - 2018-03-12 00:38:21 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-12 00:38:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:38:21 --> Input Class Initialized
DEBUG - 2018-03-12 00:38:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:38:21 --> Input Class Initialized
ERROR - 2018-03-12 00:38:21 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-12 00:38:21 --> Language Class Initialized
INFO - 2018-03-12 00:38:21 --> Language Class Initialized
ERROR - 2018-03-12 00:38:21 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-12 00:38:21 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-12 00:38:21 --> Config Class Initialized
INFO - 2018-03-12 00:38:21 --> Hooks Class Initialized
INFO - 2018-03-12 00:38:21 --> Config Class Initialized
INFO - 2018-03-12 00:38:21 --> Hooks Class Initialized
INFO - 2018-03-12 00:38:21 --> Config Class Initialized
INFO - 2018-03-12 00:38:21 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:38:21 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:38:21 --> Utf8 Class Initialized
DEBUG - 2018-03-12 00:38:21 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 00:38:21 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:38:21 --> Utf8 Class Initialized
INFO - 2018-03-12 00:38:21 --> Utf8 Class Initialized
INFO - 2018-03-12 00:38:21 --> URI Class Initialized
INFO - 2018-03-12 00:38:21 --> URI Class Initialized
INFO - 2018-03-12 00:38:21 --> URI Class Initialized
INFO - 2018-03-12 00:38:21 --> Router Class Initialized
INFO - 2018-03-12 00:38:21 --> Router Class Initialized
INFO - 2018-03-12 00:38:21 --> Router Class Initialized
INFO - 2018-03-12 00:38:21 --> Output Class Initialized
INFO - 2018-03-12 00:38:21 --> Output Class Initialized
INFO - 2018-03-12 00:38:21 --> Output Class Initialized
INFO - 2018-03-12 00:38:21 --> Security Class Initialized
INFO - 2018-03-12 00:38:21 --> Security Class Initialized
INFO - 2018-03-12 00:38:21 --> Security Class Initialized
DEBUG - 2018-03-12 00:38:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:38:21 --> Input Class Initialized
DEBUG - 2018-03-12 00:38:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 00:38:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:38:21 --> Input Class Initialized
INFO - 2018-03-12 00:38:21 --> Input Class Initialized
INFO - 2018-03-12 00:38:21 --> Language Class Initialized
INFO - 2018-03-12 00:38:21 --> Language Class Initialized
INFO - 2018-03-12 00:38:21 --> Language Class Initialized
ERROR - 2018-03-12 00:38:21 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-12 00:38:21 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-12 00:38:21 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-12 00:38:21 --> Config Class Initialized
INFO - 2018-03-12 00:38:21 --> Hooks Class Initialized
DEBUG - 2018-03-12 00:38:21 --> UTF-8 Support Enabled
INFO - 2018-03-12 00:38:21 --> Utf8 Class Initialized
INFO - 2018-03-12 00:38:21 --> URI Class Initialized
INFO - 2018-03-12 00:38:21 --> Router Class Initialized
INFO - 2018-03-12 00:38:21 --> Output Class Initialized
INFO - 2018-03-12 00:38:21 --> Security Class Initialized
DEBUG - 2018-03-12 00:38:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-12 00:38:21 --> Input Class Initialized
INFO - 2018-03-12 00:38:21 --> Language Class Initialized
INFO - 2018-03-12 00:38:21 --> Loader Class Initialized
INFO - 2018-03-12 00:38:21 --> Helper loaded: url_helper
INFO - 2018-03-12 00:38:21 --> Helper loaded: form_helper
INFO - 2018-03-12 00:38:21 --> Database Driver Class Initialized
DEBUG - 2018-03-12 00:38:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-12 00:38:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-12 00:38:21 --> Form Validation Class Initialized
INFO - 2018-03-12 00:38:21 --> Model Class Initialized
INFO - 2018-03-12 00:38:21 --> Controller Class Initialized
INFO - 2018-03-12 00:38:21 --> Model Class Initialized
INFO - 2018-03-12 00:38:21 --> Model Class Initialized
INFO - 2018-03-12 00:38:21 --> Model Class Initialized
INFO - 2018-03-12 00:38:21 --> Model Class Initialized
INFO - 2018-03-12 00:38:21 --> Model Class Initialized
DEBUG - 2018-03-12 00:38:21 --> Form_validation class already loaded. Second attempt ignored.
