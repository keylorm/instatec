<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-01-02 06:05:46 --> Config Class Initialized
INFO - 2018-01-02 06:05:46 --> Hooks Class Initialized
DEBUG - 2018-01-02 06:05:46 --> UTF-8 Support Enabled
INFO - 2018-01-02 06:05:46 --> Utf8 Class Initialized
INFO - 2018-01-02 06:05:46 --> URI Class Initialized
DEBUG - 2018-01-02 06:05:46 --> No URI present. Default controller set.
INFO - 2018-01-02 06:05:46 --> Router Class Initialized
INFO - 2018-01-02 06:05:46 --> Output Class Initialized
INFO - 2018-01-02 06:05:46 --> Security Class Initialized
DEBUG - 2018-01-02 06:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-02 06:05:46 --> Input Class Initialized
INFO - 2018-01-02 06:05:46 --> Language Class Initialized
INFO - 2018-01-02 06:05:46 --> Loader Class Initialized
INFO - 2018-01-02 06:05:46 --> Helper loaded: url_helper
INFO - 2018-01-02 06:05:46 --> Helper loaded: form_helper
INFO - 2018-01-02 06:05:46 --> Database Driver Class Initialized
DEBUG - 2018-01-02 06:05:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-02 06:05:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-02 06:05:46 --> Form Validation Class Initialized
INFO - 2018-01-02 06:05:46 --> Model Class Initialized
INFO - 2018-01-02 06:05:46 --> Controller Class Initialized
INFO - 2018-01-02 06:05:46 --> Config Class Initialized
INFO - 2018-01-02 06:05:46 --> Config Class Initialized
INFO - 2018-01-02 06:05:46 --> Hooks Class Initialized
INFO - 2018-01-02 06:05:46 --> Hooks Class Initialized
DEBUG - 2018-01-02 06:05:46 --> UTF-8 Support Enabled
DEBUG - 2018-01-02 06:05:46 --> UTF-8 Support Enabled
INFO - 2018-01-02 06:05:46 --> Utf8 Class Initialized
INFO - 2018-01-02 06:05:46 --> Utf8 Class Initialized
INFO - 2018-01-02 06:05:46 --> URI Class Initialized
INFO - 2018-01-02 06:05:46 --> URI Class Initialized
INFO - 2018-01-02 06:05:46 --> Router Class Initialized
INFO - 2018-01-02 06:05:46 --> Router Class Initialized
INFO - 2018-01-02 06:05:46 --> Output Class Initialized
INFO - 2018-01-02 06:05:46 --> Output Class Initialized
INFO - 2018-01-02 06:05:46 --> Security Class Initialized
INFO - 2018-01-02 06:05:46 --> Security Class Initialized
DEBUG - 2018-01-02 06:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-02 06:05:46 --> Input Class Initialized
DEBUG - 2018-01-02 06:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-02 06:05:46 --> Input Class Initialized
INFO - 2018-01-02 06:05:46 --> Language Class Initialized
INFO - 2018-01-02 06:05:46 --> Language Class Initialized
INFO - 2018-01-02 06:05:46 --> Loader Class Initialized
INFO - 2018-01-02 06:05:46 --> Helper loaded: url_helper
INFO - 2018-01-02 06:05:46 --> Helper loaded: form_helper
INFO - 2018-01-02 06:05:46 --> Database Driver Class Initialized
ERROR - 2018-01-02 06:05:46 --> 404 Page Not Found: Faviconico/index
DEBUG - 2018-01-02 06:05:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-02 06:05:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-02 06:05:46 --> Form Validation Class Initialized
INFO - 2018-01-02 06:05:46 --> Model Class Initialized
INFO - 2018-01-02 06:05:46 --> Controller Class Initialized
INFO - 2018-01-02 06:05:46 --> Model Class Initialized
DEBUG - 2018-01-02 06:05:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-02 06:05:46 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-02 06:05:46 --> Final output sent to browser
DEBUG - 2018-01-02 06:05:46 --> Total execution time: 0.1471
INFO - 2018-01-02 06:05:48 --> Config Class Initialized
INFO - 2018-01-02 06:05:48 --> Hooks Class Initialized
DEBUG - 2018-01-02 06:05:48 --> UTF-8 Support Enabled
INFO - 2018-01-02 06:05:48 --> Utf8 Class Initialized
INFO - 2018-01-02 06:05:48 --> URI Class Initialized
INFO - 2018-01-02 06:05:48 --> Router Class Initialized
INFO - 2018-01-02 06:05:48 --> Output Class Initialized
INFO - 2018-01-02 06:05:48 --> Security Class Initialized
DEBUG - 2018-01-02 06:05:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-02 06:05:48 --> Input Class Initialized
INFO - 2018-01-02 06:05:48 --> Language Class Initialized
INFO - 2018-01-02 06:05:48 --> Loader Class Initialized
INFO - 2018-01-02 06:05:48 --> Helper loaded: url_helper
INFO - 2018-01-02 06:05:48 --> Helper loaded: form_helper
INFO - 2018-01-02 06:05:48 --> Database Driver Class Initialized
DEBUG - 2018-01-02 06:05:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-02 06:05:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-02 06:05:48 --> Form Validation Class Initialized
INFO - 2018-01-02 06:05:48 --> Model Class Initialized
INFO - 2018-01-02 06:05:48 --> Controller Class Initialized
INFO - 2018-01-02 06:05:48 --> Model Class Initialized
DEBUG - 2018-01-02 06:05:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-02 06:05:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-01-02 06:05:48 --> Config Class Initialized
INFO - 2018-01-02 06:05:48 --> Hooks Class Initialized
DEBUG - 2018-01-02 06:05:48 --> UTF-8 Support Enabled
INFO - 2018-01-02 06:05:48 --> Utf8 Class Initialized
INFO - 2018-01-02 06:05:48 --> URI Class Initialized
DEBUG - 2018-01-02 06:05:48 --> No URI present. Default controller set.
INFO - 2018-01-02 06:05:48 --> Router Class Initialized
INFO - 2018-01-02 06:05:48 --> Output Class Initialized
INFO - 2018-01-02 06:05:48 --> Security Class Initialized
DEBUG - 2018-01-02 06:05:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-02 06:05:48 --> Input Class Initialized
INFO - 2018-01-02 06:05:48 --> Language Class Initialized
INFO - 2018-01-02 06:05:48 --> Loader Class Initialized
INFO - 2018-01-02 06:05:48 --> Helper loaded: url_helper
INFO - 2018-01-02 06:05:48 --> Helper loaded: form_helper
INFO - 2018-01-02 06:05:48 --> Database Driver Class Initialized
DEBUG - 2018-01-02 06:05:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-02 06:05:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-02 06:05:48 --> Form Validation Class Initialized
INFO - 2018-01-02 06:05:48 --> Model Class Initialized
INFO - 2018-01-02 06:05:48 --> Controller Class Initialized
INFO - 2018-01-02 06:05:48 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-02 06:05:48 --> Final output sent to browser
DEBUG - 2018-01-02 06:05:48 --> Total execution time: 0.0532
INFO - 2018-01-02 06:05:48 --> Config Class Initialized
INFO - 2018-01-02 06:05:48 --> Hooks Class Initialized
DEBUG - 2018-01-02 06:05:48 --> UTF-8 Support Enabled
INFO - 2018-01-02 06:05:48 --> Utf8 Class Initialized
INFO - 2018-01-02 06:05:48 --> URI Class Initialized
INFO - 2018-01-02 06:05:48 --> Router Class Initialized
INFO - 2018-01-02 06:05:48 --> Output Class Initialized
INFO - 2018-01-02 06:05:48 --> Security Class Initialized
DEBUG - 2018-01-02 06:05:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-02 06:05:48 --> Input Class Initialized
INFO - 2018-01-02 06:05:48 --> Language Class Initialized
INFO - 2018-01-02 06:05:48 --> Loader Class Initialized
INFO - 2018-01-02 06:05:48 --> Helper loaded: url_helper
INFO - 2018-01-02 06:05:48 --> Helper loaded: form_helper
INFO - 2018-01-02 06:05:48 --> Database Driver Class Initialized
DEBUG - 2018-01-02 06:05:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-02 06:05:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-02 06:05:48 --> Form Validation Class Initialized
INFO - 2018-01-02 06:05:48 --> Model Class Initialized
INFO - 2018-01-02 06:05:48 --> Controller Class Initialized
INFO - 2018-01-02 06:05:48 --> Model Class Initialized
INFO - 2018-01-02 06:05:48 --> Model Class Initialized
INFO - 2018-01-02 06:05:48 --> Model Class Initialized
INFO - 2018-01-02 06:05:48 --> Model Class Initialized
DEBUG - 2018-01-02 06:05:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-02 06:05:50 --> Config Class Initialized
INFO - 2018-01-02 06:05:50 --> Hooks Class Initialized
DEBUG - 2018-01-02 06:05:50 --> UTF-8 Support Enabled
INFO - 2018-01-02 06:05:50 --> Utf8 Class Initialized
INFO - 2018-01-02 06:05:50 --> URI Class Initialized
INFO - 2018-01-02 06:05:50 --> Router Class Initialized
INFO - 2018-01-02 06:05:50 --> Output Class Initialized
INFO - 2018-01-02 06:05:50 --> Security Class Initialized
DEBUG - 2018-01-02 06:05:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-02 06:05:50 --> Input Class Initialized
INFO - 2018-01-02 06:05:50 --> Language Class Initialized
INFO - 2018-01-02 06:05:50 --> Loader Class Initialized
INFO - 2018-01-02 06:05:50 --> Helper loaded: url_helper
INFO - 2018-01-02 06:05:50 --> Helper loaded: form_helper
INFO - 2018-01-02 06:05:50 --> Database Driver Class Initialized
DEBUG - 2018-01-02 06:05:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-02 06:05:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-02 06:05:50 --> Form Validation Class Initialized
INFO - 2018-01-02 06:05:50 --> Model Class Initialized
INFO - 2018-01-02 06:05:50 --> Controller Class Initialized
INFO - 2018-01-02 06:05:50 --> Model Class Initialized
INFO - 2018-01-02 06:05:50 --> Model Class Initialized
DEBUG - 2018-01-02 06:05:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-02 06:05:50 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-02 06:05:50 --> Final output sent to browser
DEBUG - 2018-01-02 06:05:50 --> Total execution time: 0.0832
INFO - 2018-01-02 06:05:50 --> Config Class Initialized
INFO - 2018-01-02 06:05:50 --> Hooks Class Initialized
DEBUG - 2018-01-02 06:05:50 --> UTF-8 Support Enabled
INFO - 2018-01-02 06:05:50 --> Utf8 Class Initialized
INFO - 2018-01-02 06:05:50 --> URI Class Initialized
INFO - 2018-01-02 06:05:50 --> Router Class Initialized
INFO - 2018-01-02 06:05:50 --> Output Class Initialized
INFO - 2018-01-02 06:05:50 --> Security Class Initialized
DEBUG - 2018-01-02 06:05:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-02 06:05:50 --> Input Class Initialized
INFO - 2018-01-02 06:05:50 --> Language Class Initialized
INFO - 2018-01-02 06:05:50 --> Loader Class Initialized
INFO - 2018-01-02 06:05:50 --> Helper loaded: url_helper
INFO - 2018-01-02 06:05:50 --> Helper loaded: form_helper
INFO - 2018-01-02 06:05:50 --> Database Driver Class Initialized
DEBUG - 2018-01-02 06:05:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-02 06:05:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-02 06:05:50 --> Form Validation Class Initialized
INFO - 2018-01-02 06:05:50 --> Model Class Initialized
INFO - 2018-01-02 06:05:50 --> Controller Class Initialized
INFO - 2018-01-02 06:05:50 --> Model Class Initialized
INFO - 2018-01-02 06:05:50 --> Model Class Initialized
DEBUG - 2018-01-02 06:05:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-02 06:05:54 --> Config Class Initialized
INFO - 2018-01-02 06:05:54 --> Hooks Class Initialized
DEBUG - 2018-01-02 06:05:54 --> UTF-8 Support Enabled
INFO - 2018-01-02 06:05:54 --> Utf8 Class Initialized
INFO - 2018-01-02 06:05:54 --> URI Class Initialized
INFO - 2018-01-02 06:05:54 --> Router Class Initialized
INFO - 2018-01-02 06:05:54 --> Output Class Initialized
INFO - 2018-01-02 06:05:54 --> Security Class Initialized
DEBUG - 2018-01-02 06:05:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-02 06:05:54 --> Input Class Initialized
INFO - 2018-01-02 06:05:54 --> Language Class Initialized
INFO - 2018-01-02 06:05:54 --> Loader Class Initialized
INFO - 2018-01-02 06:05:54 --> Helper loaded: url_helper
INFO - 2018-01-02 06:05:54 --> Helper loaded: form_helper
INFO - 2018-01-02 06:05:54 --> Database Driver Class Initialized
DEBUG - 2018-01-02 06:05:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-02 06:05:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-02 06:05:54 --> Form Validation Class Initialized
INFO - 2018-01-02 06:05:54 --> Model Class Initialized
INFO - 2018-01-02 06:05:54 --> Controller Class Initialized
INFO - 2018-01-02 06:05:54 --> Model Class Initialized
INFO - 2018-01-02 06:05:54 --> Model Class Initialized
DEBUG - 2018-01-02 06:05:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-02 06:05:54 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-02 06:05:54 --> Final output sent to browser
DEBUG - 2018-01-02 06:05:54 --> Total execution time: 0.0686
INFO - 2018-01-02 06:06:14 --> Config Class Initialized
INFO - 2018-01-02 06:06:14 --> Hooks Class Initialized
DEBUG - 2018-01-02 06:06:14 --> UTF-8 Support Enabled
INFO - 2018-01-02 06:06:14 --> Utf8 Class Initialized
INFO - 2018-01-02 06:06:14 --> URI Class Initialized
INFO - 2018-01-02 06:06:14 --> Router Class Initialized
INFO - 2018-01-02 06:06:14 --> Output Class Initialized
INFO - 2018-01-02 06:06:14 --> Security Class Initialized
DEBUG - 2018-01-02 06:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-02 06:06:14 --> Input Class Initialized
INFO - 2018-01-02 06:06:14 --> Language Class Initialized
INFO - 2018-01-02 06:06:14 --> Loader Class Initialized
INFO - 2018-01-02 06:06:14 --> Helper loaded: url_helper
INFO - 2018-01-02 06:06:14 --> Helper loaded: form_helper
INFO - 2018-01-02 06:06:14 --> Database Driver Class Initialized
DEBUG - 2018-01-02 06:06:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-02 06:06:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-02 06:06:14 --> Form Validation Class Initialized
INFO - 2018-01-02 06:06:14 --> Model Class Initialized
INFO - 2018-01-02 06:06:14 --> Controller Class Initialized
INFO - 2018-01-02 06:06:14 --> Model Class Initialized
INFO - 2018-01-02 06:06:14 --> Model Class Initialized
DEBUG - 2018-01-02 06:06:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-02 06:06:14 --> File loaded: D:\xampp\htdocs\instateccr\instatec_app\views\index.php
INFO - 2018-01-02 06:06:14 --> Final output sent to browser
DEBUG - 2018-01-02 06:06:14 --> Total execution time: 0.0597
INFO - 2018-01-02 06:06:18 --> Config Class Initialized
INFO - 2018-01-02 06:06:18 --> Hooks Class Initialized
DEBUG - 2018-01-02 06:06:18 --> UTF-8 Support Enabled
INFO - 2018-01-02 06:06:18 --> Utf8 Class Initialized
INFO - 2018-01-02 06:06:18 --> URI Class Initialized
INFO - 2018-01-02 06:06:18 --> Router Class Initialized
INFO - 2018-01-02 06:06:18 --> Output Class Initialized
INFO - 2018-01-02 06:06:18 --> Security Class Initialized
DEBUG - 2018-01-02 06:06:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-02 06:06:18 --> Input Class Initialized
INFO - 2018-01-02 06:06:18 --> Language Class Initialized
ERROR - 2018-01-02 06:06:18 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-01-02 06:06:18 --> Config Class Initialized
INFO - 2018-01-02 06:06:18 --> Hooks Class Initialized
INFO - 2018-01-02 06:06:18 --> Config Class Initialized
INFO - 2018-01-02 06:06:18 --> Hooks Class Initialized
DEBUG - 2018-01-02 06:06:18 --> UTF-8 Support Enabled
INFO - 2018-01-02 06:06:18 --> Utf8 Class Initialized
DEBUG - 2018-01-02 06:06:18 --> UTF-8 Support Enabled
INFO - 2018-01-02 06:06:18 --> URI Class Initialized
INFO - 2018-01-02 06:06:18 --> Utf8 Class Initialized
INFO - 2018-01-02 06:06:18 --> URI Class Initialized
INFO - 2018-01-02 06:06:18 --> Router Class Initialized
INFO - 2018-01-02 06:06:18 --> Router Class Initialized
INFO - 2018-01-02 06:06:18 --> Output Class Initialized
INFO - 2018-01-02 06:06:18 --> Security Class Initialized
INFO - 2018-01-02 06:06:18 --> Output Class Initialized
DEBUG - 2018-01-02 06:06:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-02 06:06:18 --> Input Class Initialized
INFO - 2018-01-02 06:06:18 --> Security Class Initialized
INFO - 2018-01-02 06:06:18 --> Language Class Initialized
DEBUG - 2018-01-02 06:06:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-02 06:06:18 --> Input Class Initialized
INFO - 2018-01-02 06:06:18 --> Language Class Initialized
ERROR - 2018-01-02 06:06:18 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-01-02 06:06:18 --> 404 Page Not Found: Instatec_pub/css
