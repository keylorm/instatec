<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-03-17 12:45:11 --> Config Class Initialized
INFO - 2018-03-17 12:45:11 --> Hooks Class Initialized
DEBUG - 2018-03-17 12:45:11 --> UTF-8 Support Enabled
INFO - 2018-03-17 12:45:11 --> Utf8 Class Initialized
INFO - 2018-03-17 12:45:11 --> URI Class Initialized
INFO - 2018-03-17 12:45:11 --> Router Class Initialized
INFO - 2018-03-17 12:45:11 --> Output Class Initialized
INFO - 2018-03-17 12:45:11 --> Security Class Initialized
DEBUG - 2018-03-17 12:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-17 12:45:11 --> Input Class Initialized
INFO - 2018-03-17 12:45:11 --> Language Class Initialized
INFO - 2018-03-17 12:45:12 --> Loader Class Initialized
INFO - 2018-03-17 12:45:12 --> Helper loaded: url_helper
INFO - 2018-03-17 12:45:12 --> Helper loaded: form_helper
INFO - 2018-03-17 12:45:12 --> Database Driver Class Initialized
ERROR - 2018-03-17 12:45:14 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No se puede establecer una conexi�n ya que el equipo de destino deneg� expresamente dicha conexi�n.
 D:\xampp\htdocs\instateccr\controlcostos\instatec_sys\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2018-03-17 12:45:14 --> Unable to connect to the database
INFO - 2018-03-17 12:45:14 --> Language file loaded: language/english/db_lang.php
INFO - 2018-03-17 12:45:25 --> Config Class Initialized
INFO - 2018-03-17 12:45:25 --> Hooks Class Initialized
DEBUG - 2018-03-17 12:45:25 --> UTF-8 Support Enabled
INFO - 2018-03-17 12:45:25 --> Utf8 Class Initialized
INFO - 2018-03-17 12:45:25 --> URI Class Initialized
INFO - 2018-03-17 12:45:25 --> Router Class Initialized
INFO - 2018-03-17 12:45:25 --> Output Class Initialized
INFO - 2018-03-17 12:45:25 --> Security Class Initialized
DEBUG - 2018-03-17 12:45:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-17 12:45:25 --> Input Class Initialized
INFO - 2018-03-17 12:45:25 --> Language Class Initialized
INFO - 2018-03-17 12:45:25 --> Loader Class Initialized
INFO - 2018-03-17 12:45:25 --> Helper loaded: url_helper
INFO - 2018-03-17 12:45:25 --> Helper loaded: form_helper
INFO - 2018-03-17 12:45:25 --> Database Driver Class Initialized
DEBUG - 2018-03-17 12:45:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-17 12:45:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-17 12:45:25 --> Form Validation Class Initialized
INFO - 2018-03-17 12:45:25 --> Model Class Initialized
INFO - 2018-03-17 12:45:25 --> Controller Class Initialized
INFO - 2018-03-17 12:45:25 --> Model Class Initialized
INFO - 2018-03-17 12:45:25 --> Model Class Initialized
INFO - 2018-03-17 12:45:25 --> Model Class Initialized
INFO - 2018-03-17 12:45:25 --> Model Class Initialized
DEBUG - 2018-03-17 12:45:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-17 12:45:25 --> Config Class Initialized
INFO - 2018-03-17 12:45:25 --> Hooks Class Initialized
DEBUG - 2018-03-17 12:45:25 --> UTF-8 Support Enabled
INFO - 2018-03-17 12:45:25 --> Utf8 Class Initialized
INFO - 2018-03-17 12:45:25 --> URI Class Initialized
INFO - 2018-03-17 12:45:25 --> Router Class Initialized
INFO - 2018-03-17 12:45:25 --> Output Class Initialized
INFO - 2018-03-17 12:45:25 --> Security Class Initialized
DEBUG - 2018-03-17 12:45:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-17 12:45:25 --> Input Class Initialized
INFO - 2018-03-17 12:45:25 --> Language Class Initialized
INFO - 2018-03-17 12:45:25 --> Loader Class Initialized
INFO - 2018-03-17 12:45:25 --> Helper loaded: url_helper
INFO - 2018-03-17 12:45:25 --> Helper loaded: form_helper
INFO - 2018-03-17 12:45:25 --> Database Driver Class Initialized
DEBUG - 2018-03-17 12:45:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-17 12:45:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-17 12:45:25 --> Form Validation Class Initialized
INFO - 2018-03-17 12:45:25 --> Model Class Initialized
INFO - 2018-03-17 12:45:25 --> Controller Class Initialized
INFO - 2018-03-17 12:45:25 --> Model Class Initialized
DEBUG - 2018-03-17 12:45:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-17 12:45:25 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-17 12:45:25 --> Final output sent to browser
DEBUG - 2018-03-17 12:45:25 --> Total execution time: 0.1052
INFO - 2018-03-17 12:45:27 --> Config Class Initialized
INFO - 2018-03-17 12:45:27 --> Hooks Class Initialized
DEBUG - 2018-03-17 12:45:27 --> UTF-8 Support Enabled
INFO - 2018-03-17 12:45:27 --> Utf8 Class Initialized
INFO - 2018-03-17 12:45:27 --> URI Class Initialized
INFO - 2018-03-17 12:45:27 --> Router Class Initialized
INFO - 2018-03-17 12:45:27 --> Output Class Initialized
INFO - 2018-03-17 12:45:27 --> Security Class Initialized
DEBUG - 2018-03-17 12:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-17 12:45:27 --> Input Class Initialized
INFO - 2018-03-17 12:45:27 --> Language Class Initialized
INFO - 2018-03-17 12:45:27 --> Loader Class Initialized
INFO - 2018-03-17 12:45:27 --> Helper loaded: url_helper
INFO - 2018-03-17 12:45:27 --> Helper loaded: form_helper
INFO - 2018-03-17 12:45:27 --> Database Driver Class Initialized
DEBUG - 2018-03-17 12:45:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-17 12:45:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-17 12:45:27 --> Form Validation Class Initialized
INFO - 2018-03-17 12:45:27 --> Model Class Initialized
INFO - 2018-03-17 12:45:27 --> Controller Class Initialized
INFO - 2018-03-17 12:45:27 --> Model Class Initialized
DEBUG - 2018-03-17 12:45:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-17 12:45:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-17 12:45:28 --> Config Class Initialized
INFO - 2018-03-17 12:45:28 --> Hooks Class Initialized
DEBUG - 2018-03-17 12:45:28 --> UTF-8 Support Enabled
INFO - 2018-03-17 12:45:28 --> Utf8 Class Initialized
INFO - 2018-03-17 12:45:28 --> URI Class Initialized
DEBUG - 2018-03-17 12:45:28 --> No URI present. Default controller set.
INFO - 2018-03-17 12:45:28 --> Router Class Initialized
INFO - 2018-03-17 12:45:28 --> Output Class Initialized
INFO - 2018-03-17 12:45:28 --> Security Class Initialized
DEBUG - 2018-03-17 12:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-17 12:45:28 --> Input Class Initialized
INFO - 2018-03-17 12:45:28 --> Language Class Initialized
INFO - 2018-03-17 12:45:28 --> Loader Class Initialized
INFO - 2018-03-17 12:45:28 --> Helper loaded: url_helper
INFO - 2018-03-17 12:45:28 --> Helper loaded: form_helper
INFO - 2018-03-17 12:45:28 --> Database Driver Class Initialized
DEBUG - 2018-03-17 12:45:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-17 12:45:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-17 12:45:28 --> Form Validation Class Initialized
INFO - 2018-03-17 12:45:28 --> Model Class Initialized
INFO - 2018-03-17 12:45:28 --> Controller Class Initialized
INFO - 2018-03-17 12:45:28 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-17 12:45:28 --> Final output sent to browser
DEBUG - 2018-03-17 12:45:28 --> Total execution time: 0.1062
INFO - 2018-03-17 12:45:28 --> Config Class Initialized
INFO - 2018-03-17 12:45:28 --> Hooks Class Initialized
DEBUG - 2018-03-17 12:45:28 --> UTF-8 Support Enabled
INFO - 2018-03-17 12:45:28 --> Utf8 Class Initialized
INFO - 2018-03-17 12:45:28 --> URI Class Initialized
INFO - 2018-03-17 12:45:28 --> Router Class Initialized
INFO - 2018-03-17 12:45:28 --> Output Class Initialized
INFO - 2018-03-17 12:45:28 --> Security Class Initialized
DEBUG - 2018-03-17 12:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-17 12:45:28 --> Input Class Initialized
INFO - 2018-03-17 12:45:28 --> Language Class Initialized
INFO - 2018-03-17 12:45:28 --> Loader Class Initialized
INFO - 2018-03-17 12:45:28 --> Helper loaded: url_helper
INFO - 2018-03-17 12:45:28 --> Helper loaded: form_helper
INFO - 2018-03-17 12:45:28 --> Database Driver Class Initialized
DEBUG - 2018-03-17 12:45:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-17 12:45:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-17 12:45:28 --> Form Validation Class Initialized
INFO - 2018-03-17 12:45:28 --> Model Class Initialized
INFO - 2018-03-17 12:45:28 --> Controller Class Initialized
INFO - 2018-03-17 12:45:28 --> Model Class Initialized
INFO - 2018-03-17 12:45:28 --> Model Class Initialized
INFO - 2018-03-17 12:45:28 --> Model Class Initialized
INFO - 2018-03-17 12:45:28 --> Model Class Initialized
INFO - 2018-03-17 12:45:28 --> Model Class Initialized
DEBUG - 2018-03-17 12:45:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-17 12:45:36 --> Config Class Initialized
INFO - 2018-03-17 12:45:36 --> Hooks Class Initialized
DEBUG - 2018-03-17 12:45:36 --> UTF-8 Support Enabled
INFO - 2018-03-17 12:45:36 --> Utf8 Class Initialized
INFO - 2018-03-17 12:45:36 --> URI Class Initialized
INFO - 2018-03-17 12:45:36 --> Router Class Initialized
INFO - 2018-03-17 12:45:36 --> Output Class Initialized
INFO - 2018-03-17 12:45:36 --> Security Class Initialized
DEBUG - 2018-03-17 12:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-17 12:45:36 --> Input Class Initialized
INFO - 2018-03-17 12:45:36 --> Language Class Initialized
INFO - 2018-03-17 12:45:36 --> Loader Class Initialized
INFO - 2018-03-17 12:45:36 --> Helper loaded: url_helper
INFO - 2018-03-17 12:45:36 --> Helper loaded: form_helper
INFO - 2018-03-17 12:45:36 --> Database Driver Class Initialized
DEBUG - 2018-03-17 12:45:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-17 12:45:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-17 12:45:36 --> Form Validation Class Initialized
INFO - 2018-03-17 12:45:36 --> Model Class Initialized
INFO - 2018-03-17 12:45:36 --> Controller Class Initialized
INFO - 2018-03-17 12:45:36 --> Model Class Initialized
INFO - 2018-03-17 12:45:36 --> Model Class Initialized
INFO - 2018-03-17 12:45:36 --> Model Class Initialized
INFO - 2018-03-17 12:45:36 --> Model Class Initialized
DEBUG - 2018-03-17 12:45:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-17 12:45:36 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-17 12:45:36 --> Final output sent to browser
DEBUG - 2018-03-17 12:45:36 --> Total execution time: 0.0938
INFO - 2018-03-17 12:45:37 --> Config Class Initialized
INFO - 2018-03-17 12:45:37 --> Hooks Class Initialized
DEBUG - 2018-03-17 12:45:37 --> UTF-8 Support Enabled
INFO - 2018-03-17 12:45:37 --> Utf8 Class Initialized
INFO - 2018-03-17 12:45:37 --> URI Class Initialized
INFO - 2018-03-17 12:45:37 --> Router Class Initialized
INFO - 2018-03-17 12:45:37 --> Output Class Initialized
INFO - 2018-03-17 12:45:37 --> Security Class Initialized
DEBUG - 2018-03-17 12:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-17 12:45:37 --> Input Class Initialized
INFO - 2018-03-17 12:45:37 --> Language Class Initialized
INFO - 2018-03-17 12:45:37 --> Loader Class Initialized
INFO - 2018-03-17 12:45:37 --> Helper loaded: url_helper
INFO - 2018-03-17 12:45:37 --> Helper loaded: form_helper
INFO - 2018-03-17 12:45:37 --> Database Driver Class Initialized
DEBUG - 2018-03-17 12:45:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-17 12:45:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-17 12:45:37 --> Form Validation Class Initialized
INFO - 2018-03-17 12:45:37 --> Model Class Initialized
INFO - 2018-03-17 12:45:37 --> Controller Class Initialized
INFO - 2018-03-17 12:45:37 --> Model Class Initialized
INFO - 2018-03-17 12:45:37 --> Model Class Initialized
INFO - 2018-03-17 12:45:37 --> Model Class Initialized
INFO - 2018-03-17 12:45:37 --> Model Class Initialized
DEBUG - 2018-03-17 12:45:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-17 12:45:38 --> Model Class Initialized
INFO - 2018-03-17 12:45:38 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-17 12:45:38 --> Final output sent to browser
DEBUG - 2018-03-17 12:45:38 --> Total execution time: 0.1219
INFO - 2018-03-17 12:45:38 --> Config Class Initialized
INFO - 2018-03-17 12:45:38 --> Hooks Class Initialized
DEBUG - 2018-03-17 12:45:38 --> UTF-8 Support Enabled
INFO - 2018-03-17 12:45:38 --> Utf8 Class Initialized
INFO - 2018-03-17 12:45:38 --> URI Class Initialized
INFO - 2018-03-17 12:45:38 --> Router Class Initialized
INFO - 2018-03-17 12:45:38 --> Output Class Initialized
INFO - 2018-03-17 12:45:38 --> Security Class Initialized
DEBUG - 2018-03-17 12:45:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-17 12:45:38 --> Input Class Initialized
INFO - 2018-03-17 12:45:38 --> Language Class Initialized
INFO - 2018-03-17 12:45:38 --> Loader Class Initialized
INFO - 2018-03-17 12:45:38 --> Helper loaded: url_helper
INFO - 2018-03-17 12:45:38 --> Helper loaded: form_helper
INFO - 2018-03-17 12:45:38 --> Database Driver Class Initialized
DEBUG - 2018-03-17 12:45:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-17 12:45:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-17 12:45:38 --> Form Validation Class Initialized
INFO - 2018-03-17 12:45:38 --> Model Class Initialized
INFO - 2018-03-17 12:45:38 --> Controller Class Initialized
INFO - 2018-03-17 12:45:38 --> Model Class Initialized
INFO - 2018-03-17 12:45:38 --> Model Class Initialized
DEBUG - 2018-03-17 12:45:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-17 12:45:44 --> Config Class Initialized
INFO - 2018-03-17 12:45:44 --> Hooks Class Initialized
DEBUG - 2018-03-17 12:45:44 --> UTF-8 Support Enabled
INFO - 2018-03-17 12:45:44 --> Utf8 Class Initialized
INFO - 2018-03-17 12:45:44 --> URI Class Initialized
INFO - 2018-03-17 12:45:44 --> Router Class Initialized
INFO - 2018-03-17 12:45:44 --> Output Class Initialized
INFO - 2018-03-17 12:45:44 --> Security Class Initialized
DEBUG - 2018-03-17 12:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-17 12:45:44 --> Input Class Initialized
INFO - 2018-03-17 12:45:44 --> Language Class Initialized
INFO - 2018-03-17 12:45:44 --> Loader Class Initialized
INFO - 2018-03-17 12:45:44 --> Helper loaded: url_helper
INFO - 2018-03-17 12:45:44 --> Helper loaded: form_helper
INFO - 2018-03-17 12:45:44 --> Database Driver Class Initialized
DEBUG - 2018-03-17 12:45:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-17 12:45:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-17 12:45:44 --> Form Validation Class Initialized
INFO - 2018-03-17 12:45:44 --> Model Class Initialized
INFO - 2018-03-17 12:45:44 --> Controller Class Initialized
INFO - 2018-03-17 12:45:44 --> Model Class Initialized
INFO - 2018-03-17 12:45:44 --> Model Class Initialized
DEBUG - 2018-03-17 12:45:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-17 12:45:48 --> Config Class Initialized
INFO - 2018-03-17 12:45:48 --> Hooks Class Initialized
DEBUG - 2018-03-17 12:45:48 --> UTF-8 Support Enabled
INFO - 2018-03-17 12:45:48 --> Utf8 Class Initialized
INFO - 2018-03-17 12:45:48 --> URI Class Initialized
INFO - 2018-03-17 12:45:48 --> Router Class Initialized
INFO - 2018-03-17 12:45:48 --> Output Class Initialized
INFO - 2018-03-17 12:45:48 --> Security Class Initialized
DEBUG - 2018-03-17 12:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-17 12:45:48 --> Input Class Initialized
INFO - 2018-03-17 12:45:48 --> Language Class Initialized
INFO - 2018-03-17 12:45:48 --> Loader Class Initialized
INFO - 2018-03-17 12:45:48 --> Helper loaded: url_helper
INFO - 2018-03-17 12:45:48 --> Helper loaded: form_helper
INFO - 2018-03-17 12:45:48 --> Database Driver Class Initialized
DEBUG - 2018-03-17 12:45:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-17 12:45:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-17 12:45:48 --> Form Validation Class Initialized
INFO - 2018-03-17 12:45:48 --> Model Class Initialized
INFO - 2018-03-17 12:45:48 --> Controller Class Initialized
INFO - 2018-03-17 12:45:48 --> Model Class Initialized
INFO - 2018-03-17 12:45:48 --> Model Class Initialized
DEBUG - 2018-03-17 12:45:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-17 12:45:51 --> Config Class Initialized
INFO - 2018-03-17 12:45:51 --> Hooks Class Initialized
DEBUG - 2018-03-17 12:45:51 --> UTF-8 Support Enabled
INFO - 2018-03-17 12:45:51 --> Utf8 Class Initialized
INFO - 2018-03-17 12:45:51 --> URI Class Initialized
INFO - 2018-03-17 12:45:51 --> Router Class Initialized
INFO - 2018-03-17 12:45:51 --> Output Class Initialized
INFO - 2018-03-17 12:45:51 --> Security Class Initialized
DEBUG - 2018-03-17 12:45:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-17 12:45:51 --> Input Class Initialized
INFO - 2018-03-17 12:45:51 --> Language Class Initialized
INFO - 2018-03-17 12:45:51 --> Loader Class Initialized
INFO - 2018-03-17 12:45:51 --> Helper loaded: url_helper
INFO - 2018-03-17 12:45:51 --> Helper loaded: form_helper
INFO - 2018-03-17 12:45:51 --> Database Driver Class Initialized
DEBUG - 2018-03-17 12:45:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-17 12:45:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-17 12:45:51 --> Form Validation Class Initialized
INFO - 2018-03-17 12:45:51 --> Model Class Initialized
INFO - 2018-03-17 12:45:51 --> Controller Class Initialized
INFO - 2018-03-17 12:45:51 --> Model Class Initialized
INFO - 2018-03-17 12:45:51 --> Model Class Initialized
DEBUG - 2018-03-17 12:45:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-17 12:45:54 --> Config Class Initialized
INFO - 2018-03-17 12:45:54 --> Hooks Class Initialized
DEBUG - 2018-03-17 12:45:54 --> UTF-8 Support Enabled
INFO - 2018-03-17 12:45:54 --> Utf8 Class Initialized
INFO - 2018-03-17 12:45:54 --> URI Class Initialized
INFO - 2018-03-17 12:45:54 --> Router Class Initialized
INFO - 2018-03-17 12:45:54 --> Output Class Initialized
INFO - 2018-03-17 12:45:54 --> Security Class Initialized
DEBUG - 2018-03-17 12:45:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-17 12:45:54 --> Input Class Initialized
INFO - 2018-03-17 12:45:54 --> Language Class Initialized
INFO - 2018-03-17 12:45:54 --> Loader Class Initialized
INFO - 2018-03-17 12:45:54 --> Helper loaded: url_helper
INFO - 2018-03-17 12:45:54 --> Helper loaded: form_helper
INFO - 2018-03-17 12:45:54 --> Database Driver Class Initialized
DEBUG - 2018-03-17 12:45:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-17 12:45:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-17 12:45:54 --> Form Validation Class Initialized
INFO - 2018-03-17 12:45:54 --> Model Class Initialized
INFO - 2018-03-17 12:45:54 --> Controller Class Initialized
INFO - 2018-03-17 12:45:54 --> Model Class Initialized
INFO - 2018-03-17 12:45:54 --> Model Class Initialized
DEBUG - 2018-03-17 12:45:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-17 12:46:00 --> Config Class Initialized
INFO - 2018-03-17 12:46:00 --> Hooks Class Initialized
DEBUG - 2018-03-17 12:46:00 --> UTF-8 Support Enabled
INFO - 2018-03-17 12:46:00 --> Utf8 Class Initialized
INFO - 2018-03-17 12:46:00 --> URI Class Initialized
INFO - 2018-03-17 12:46:00 --> Router Class Initialized
INFO - 2018-03-17 12:46:00 --> Output Class Initialized
INFO - 2018-03-17 12:46:00 --> Security Class Initialized
DEBUG - 2018-03-17 12:46:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-17 12:46:00 --> Input Class Initialized
INFO - 2018-03-17 12:46:00 --> Language Class Initialized
INFO - 2018-03-17 12:46:00 --> Loader Class Initialized
INFO - 2018-03-17 12:46:00 --> Helper loaded: url_helper
INFO - 2018-03-17 12:46:00 --> Helper loaded: form_helper
INFO - 2018-03-17 12:46:00 --> Database Driver Class Initialized
DEBUG - 2018-03-17 12:46:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-17 12:46:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-17 12:46:00 --> Form Validation Class Initialized
INFO - 2018-03-17 12:46:00 --> Model Class Initialized
INFO - 2018-03-17 12:46:00 --> Controller Class Initialized
INFO - 2018-03-17 12:46:00 --> Model Class Initialized
INFO - 2018-03-17 12:46:00 --> Model Class Initialized
INFO - 2018-03-17 12:46:00 --> Model Class Initialized
INFO - 2018-03-17 12:46:00 --> Model Class Initialized
DEBUG - 2018-03-17 12:46:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-17 12:46:00 --> Model Class Initialized
INFO - 2018-03-17 12:46:00 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-17 12:46:00 --> Final output sent to browser
DEBUG - 2018-03-17 12:46:00 --> Total execution time: 0.1303
INFO - 2018-03-17 12:46:04 --> Config Class Initialized
INFO - 2018-03-17 12:46:04 --> Hooks Class Initialized
DEBUG - 2018-03-17 12:46:04 --> UTF-8 Support Enabled
INFO - 2018-03-17 12:46:04 --> Utf8 Class Initialized
INFO - 2018-03-17 12:46:04 --> URI Class Initialized
INFO - 2018-03-17 12:46:04 --> Router Class Initialized
INFO - 2018-03-17 12:46:04 --> Output Class Initialized
INFO - 2018-03-17 12:46:04 --> Security Class Initialized
DEBUG - 2018-03-17 12:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-17 12:46:04 --> Input Class Initialized
INFO - 2018-03-17 12:46:04 --> Language Class Initialized
INFO - 2018-03-17 12:46:04 --> Loader Class Initialized
INFO - 2018-03-17 12:46:04 --> Helper loaded: url_helper
INFO - 2018-03-17 12:46:04 --> Helper loaded: form_helper
INFO - 2018-03-17 12:46:04 --> Database Driver Class Initialized
DEBUG - 2018-03-17 12:46:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-17 12:46:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-17 12:46:04 --> Form Validation Class Initialized
INFO - 2018-03-17 12:46:04 --> Model Class Initialized
INFO - 2018-03-17 12:46:04 --> Controller Class Initialized
INFO - 2018-03-17 12:46:04 --> Model Class Initialized
INFO - 2018-03-17 12:46:04 --> Model Class Initialized
INFO - 2018-03-17 12:46:04 --> Model Class Initialized
INFO - 2018-03-17 12:46:04 --> Model Class Initialized
DEBUG - 2018-03-17 12:46:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-17 12:46:04 --> Model Class Initialized
INFO - 2018-03-17 12:46:04 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-17 12:46:04 --> Final output sent to browser
DEBUG - 2018-03-17 12:46:04 --> Total execution time: 0.0465
INFO - 2018-03-17 12:46:04 --> Config Class Initialized
INFO - 2018-03-17 12:46:04 --> Hooks Class Initialized
DEBUG - 2018-03-17 12:46:04 --> UTF-8 Support Enabled
INFO - 2018-03-17 12:46:04 --> Utf8 Class Initialized
INFO - 2018-03-17 12:46:04 --> URI Class Initialized
INFO - 2018-03-17 12:46:04 --> Router Class Initialized
INFO - 2018-03-17 12:46:04 --> Output Class Initialized
INFO - 2018-03-17 12:46:04 --> Security Class Initialized
DEBUG - 2018-03-17 12:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-17 12:46:04 --> Input Class Initialized
INFO - 2018-03-17 12:46:04 --> Language Class Initialized
INFO - 2018-03-17 12:46:04 --> Loader Class Initialized
INFO - 2018-03-17 12:46:04 --> Helper loaded: url_helper
INFO - 2018-03-17 12:46:04 --> Helper loaded: form_helper
INFO - 2018-03-17 12:46:04 --> Database Driver Class Initialized
DEBUG - 2018-03-17 12:46:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-17 12:46:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-17 12:46:04 --> Form Validation Class Initialized
INFO - 2018-03-17 12:46:04 --> Model Class Initialized
INFO - 2018-03-17 12:46:04 --> Controller Class Initialized
INFO - 2018-03-17 12:46:04 --> Model Class Initialized
INFO - 2018-03-17 12:46:04 --> Model Class Initialized
DEBUG - 2018-03-17 12:46:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-17 12:46:06 --> Config Class Initialized
INFO - 2018-03-17 12:46:06 --> Hooks Class Initialized
DEBUG - 2018-03-17 12:46:06 --> UTF-8 Support Enabled
INFO - 2018-03-17 12:46:06 --> Utf8 Class Initialized
INFO - 2018-03-17 12:46:06 --> URI Class Initialized
INFO - 2018-03-17 12:46:06 --> Router Class Initialized
INFO - 2018-03-17 12:46:06 --> Output Class Initialized
INFO - 2018-03-17 12:46:06 --> Security Class Initialized
DEBUG - 2018-03-17 12:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-17 12:46:06 --> Input Class Initialized
INFO - 2018-03-17 12:46:06 --> Language Class Initialized
INFO - 2018-03-17 12:46:06 --> Loader Class Initialized
INFO - 2018-03-17 12:46:06 --> Helper loaded: url_helper
INFO - 2018-03-17 12:46:06 --> Helper loaded: form_helper
INFO - 2018-03-17 12:46:06 --> Database Driver Class Initialized
DEBUG - 2018-03-17 12:46:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-17 12:46:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-17 12:46:06 --> Form Validation Class Initialized
INFO - 2018-03-17 12:46:06 --> Model Class Initialized
INFO - 2018-03-17 12:46:06 --> Controller Class Initialized
INFO - 2018-03-17 12:46:06 --> Model Class Initialized
INFO - 2018-03-17 12:46:06 --> Model Class Initialized
INFO - 2018-03-17 12:46:06 --> Model Class Initialized
INFO - 2018-03-17 12:46:06 --> Model Class Initialized
DEBUG - 2018-03-17 12:46:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-17 12:46:06 --> Model Class Initialized
INFO - 2018-03-17 12:46:06 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-17 12:46:06 --> Final output sent to browser
DEBUG - 2018-03-17 12:46:06 --> Total execution time: 0.0577
INFO - 2018-03-17 12:46:07 --> Config Class Initialized
INFO - 2018-03-17 12:46:07 --> Hooks Class Initialized
DEBUG - 2018-03-17 12:46:07 --> UTF-8 Support Enabled
INFO - 2018-03-17 12:46:07 --> Utf8 Class Initialized
INFO - 2018-03-17 12:46:07 --> URI Class Initialized
INFO - 2018-03-17 12:46:07 --> Router Class Initialized
INFO - 2018-03-17 12:46:07 --> Output Class Initialized
INFO - 2018-03-17 12:46:07 --> Security Class Initialized
DEBUG - 2018-03-17 12:46:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-17 12:46:07 --> Input Class Initialized
INFO - 2018-03-17 12:46:07 --> Language Class Initialized
INFO - 2018-03-17 12:46:07 --> Loader Class Initialized
INFO - 2018-03-17 12:46:07 --> Helper loaded: url_helper
INFO - 2018-03-17 12:46:07 --> Helper loaded: form_helper
INFO - 2018-03-17 12:46:07 --> Database Driver Class Initialized
DEBUG - 2018-03-17 12:46:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-17 12:46:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-17 12:46:07 --> Form Validation Class Initialized
INFO - 2018-03-17 12:46:07 --> Model Class Initialized
INFO - 2018-03-17 12:46:07 --> Controller Class Initialized
INFO - 2018-03-17 12:46:07 --> Model Class Initialized
INFO - 2018-03-17 12:46:07 --> Model Class Initialized
INFO - 2018-03-17 12:46:07 --> Model Class Initialized
INFO - 2018-03-17 12:46:07 --> Model Class Initialized
INFO - 2018-03-17 12:46:07 --> Model Class Initialized
DEBUG - 2018-03-17 12:46:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-17 12:46:07 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-17 12:46:07 --> Final output sent to browser
DEBUG - 2018-03-17 12:46:07 --> Total execution time: 0.2067
INFO - 2018-03-17 12:46:08 --> Config Class Initialized
INFO - 2018-03-17 12:46:08 --> Hooks Class Initialized
DEBUG - 2018-03-17 12:46:08 --> UTF-8 Support Enabled
INFO - 2018-03-17 12:46:08 --> Utf8 Class Initialized
INFO - 2018-03-17 12:46:08 --> URI Class Initialized
INFO - 2018-03-17 12:46:08 --> Router Class Initialized
INFO - 2018-03-17 12:46:08 --> Output Class Initialized
INFO - 2018-03-17 12:46:08 --> Security Class Initialized
DEBUG - 2018-03-17 12:46:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-17 12:46:08 --> Input Class Initialized
INFO - 2018-03-17 12:46:08 --> Language Class Initialized
INFO - 2018-03-17 12:46:08 --> Loader Class Initialized
INFO - 2018-03-17 12:46:08 --> Helper loaded: url_helper
INFO - 2018-03-17 12:46:08 --> Helper loaded: form_helper
INFO - 2018-03-17 12:46:08 --> Database Driver Class Initialized
DEBUG - 2018-03-17 12:46:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-17 12:46:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-17 12:46:08 --> Form Validation Class Initialized
INFO - 2018-03-17 12:46:08 --> Model Class Initialized
INFO - 2018-03-17 12:46:08 --> Controller Class Initialized
INFO - 2018-03-17 12:46:08 --> Model Class Initialized
INFO - 2018-03-17 12:46:08 --> Model Class Initialized
INFO - 2018-03-17 12:46:08 --> Model Class Initialized
INFO - 2018-03-17 12:46:08 --> Model Class Initialized
INFO - 2018-03-17 12:46:08 --> Model Class Initialized
DEBUG - 2018-03-17 12:46:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-17 13:23:42 --> Config Class Initialized
INFO - 2018-03-17 13:23:42 --> Hooks Class Initialized
INFO - 2018-03-17 13:23:42 --> Config Class Initialized
INFO - 2018-03-17 13:23:42 --> Hooks Class Initialized
INFO - 2018-03-17 13:23:42 --> Config Class Initialized
INFO - 2018-03-17 13:23:42 --> Hooks Class Initialized
DEBUG - 2018-03-17 13:23:42 --> UTF-8 Support Enabled
DEBUG - 2018-03-17 13:23:42 --> UTF-8 Support Enabled
DEBUG - 2018-03-17 13:23:42 --> UTF-8 Support Enabled
INFO - 2018-03-17 13:23:42 --> Utf8 Class Initialized
INFO - 2018-03-17 13:23:42 --> Utf8 Class Initialized
INFO - 2018-03-17 13:23:42 --> Utf8 Class Initialized
INFO - 2018-03-17 13:23:42 --> URI Class Initialized
INFO - 2018-03-17 13:23:42 --> URI Class Initialized
INFO - 2018-03-17 13:23:42 --> URI Class Initialized
INFO - 2018-03-17 13:23:42 --> Router Class Initialized
INFO - 2018-03-17 13:23:42 --> Router Class Initialized
INFO - 2018-03-17 13:23:42 --> Output Class Initialized
INFO - 2018-03-17 13:23:42 --> Output Class Initialized
INFO - 2018-03-17 13:23:42 --> Security Class Initialized
INFO - 2018-03-17 13:23:42 --> Security Class Initialized
INFO - 2018-03-17 13:23:42 --> Router Class Initialized
DEBUG - 2018-03-17 13:23:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-17 13:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-17 13:23:42 --> Input Class Initialized
INFO - 2018-03-17 13:23:42 --> Input Class Initialized
INFO - 2018-03-17 13:23:42 --> Output Class Initialized
INFO - 2018-03-17 13:23:42 --> Language Class Initialized
INFO - 2018-03-17 13:23:42 --> Language Class Initialized
ERROR - 2018-03-17 13:23:42 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-17 13:23:42 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-17 13:23:42 --> Security Class Initialized
DEBUG - 2018-03-17 13:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-17 13:23:42 --> Input Class Initialized
INFO - 2018-03-17 13:23:42 --> Language Class Initialized
ERROR - 2018-03-17 13:23:42 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-17 13:23:44 --> Config Class Initialized
INFO - 2018-03-17 13:23:44 --> Hooks Class Initialized
DEBUG - 2018-03-17 13:23:44 --> UTF-8 Support Enabled
INFO - 2018-03-17 13:23:44 --> Utf8 Class Initialized
INFO - 2018-03-17 13:23:44 --> URI Class Initialized
INFO - 2018-03-17 13:23:44 --> Router Class Initialized
INFO - 2018-03-17 13:23:44 --> Output Class Initialized
INFO - 2018-03-17 13:23:44 --> Security Class Initialized
DEBUG - 2018-03-17 13:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-17 13:23:44 --> Input Class Initialized
INFO - 2018-03-17 13:23:44 --> Language Class Initialized
INFO - 2018-03-17 13:23:44 --> Loader Class Initialized
INFO - 2018-03-17 13:23:44 --> Helper loaded: url_helper
INFO - 2018-03-17 13:23:44 --> Helper loaded: form_helper
INFO - 2018-03-17 13:23:44 --> Database Driver Class Initialized
DEBUG - 2018-03-17 13:23:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-17 13:23:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-17 13:23:44 --> Form Validation Class Initialized
INFO - 2018-03-17 13:23:44 --> Model Class Initialized
INFO - 2018-03-17 13:23:44 --> Controller Class Initialized
INFO - 2018-03-17 13:23:44 --> Model Class Initialized
INFO - 2018-03-17 13:23:44 --> Model Class Initialized
INFO - 2018-03-17 13:23:44 --> Model Class Initialized
INFO - 2018-03-17 13:23:44 --> Model Class Initialized
DEBUG - 2018-03-17 13:23:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-17 13:23:44 --> Model Class Initialized
INFO - 2018-03-17 13:23:44 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-17 13:23:44 --> Final output sent to browser
DEBUG - 2018-03-17 13:23:44 --> Total execution time: 0.0518
INFO - 2018-03-17 13:23:45 --> Config Class Initialized
INFO - 2018-03-17 13:23:45 --> Hooks Class Initialized
INFO - 2018-03-17 13:23:45 --> Config Class Initialized
INFO - 2018-03-17 13:23:45 --> Hooks Class Initialized
INFO - 2018-03-17 13:23:45 --> Config Class Initialized
INFO - 2018-03-17 13:23:45 --> Hooks Class Initialized
DEBUG - 2018-03-17 13:23:45 --> UTF-8 Support Enabled
INFO - 2018-03-17 13:23:45 --> Utf8 Class Initialized
DEBUG - 2018-03-17 13:23:45 --> UTF-8 Support Enabled
INFO - 2018-03-17 13:23:45 --> URI Class Initialized
INFO - 2018-03-17 13:23:45 --> Utf8 Class Initialized
DEBUG - 2018-03-17 13:23:45 --> UTF-8 Support Enabled
INFO - 2018-03-17 13:23:45 --> Utf8 Class Initialized
INFO - 2018-03-17 13:23:45 --> URI Class Initialized
INFO - 2018-03-17 13:23:45 --> URI Class Initialized
INFO - 2018-03-17 13:23:45 --> Router Class Initialized
INFO - 2018-03-17 13:23:45 --> Router Class Initialized
INFO - 2018-03-17 13:23:45 --> Config Class Initialized
INFO - 2018-03-17 13:23:45 --> Hooks Class Initialized
INFO - 2018-03-17 13:23:45 --> Router Class Initialized
INFO - 2018-03-17 13:23:45 --> Output Class Initialized
INFO - 2018-03-17 13:23:45 --> Output Class Initialized
INFO - 2018-03-17 13:23:45 --> Output Class Initialized
DEBUG - 2018-03-17 13:23:45 --> UTF-8 Support Enabled
INFO - 2018-03-17 13:23:45 --> Security Class Initialized
INFO - 2018-03-17 13:23:45 --> Utf8 Class Initialized
INFO - 2018-03-17 13:23:45 --> Security Class Initialized
INFO - 2018-03-17 13:23:45 --> Security Class Initialized
INFO - 2018-03-17 13:23:45 --> URI Class Initialized
DEBUG - 2018-03-17 13:23:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-17 13:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-17 13:23:45 --> Input Class Initialized
DEBUG - 2018-03-17 13:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-17 13:23:45 --> Input Class Initialized
INFO - 2018-03-17 13:23:45 --> Input Class Initialized
INFO - 2018-03-17 13:23:45 --> Language Class Initialized
INFO - 2018-03-17 13:23:45 --> Router Class Initialized
INFO - 2018-03-17 13:23:45 --> Language Class Initialized
INFO - 2018-03-17 13:23:45 --> Language Class Initialized
ERROR - 2018-03-17 13:23:45 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-17 13:23:45 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-17 13:23:45 --> Output Class Initialized
ERROR - 2018-03-17 13:23:45 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-17 13:23:45 --> Security Class Initialized
DEBUG - 2018-03-17 13:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-17 13:23:45 --> Input Class Initialized
INFO - 2018-03-17 13:23:45 --> Language Class Initialized
ERROR - 2018-03-17 13:23:45 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-17 13:23:45 --> Config Class Initialized
INFO - 2018-03-17 13:23:45 --> Hooks Class Initialized
INFO - 2018-03-17 13:23:45 --> Config Class Initialized
INFO - 2018-03-17 13:23:45 --> Config Class Initialized
INFO - 2018-03-17 13:23:45 --> Hooks Class Initialized
INFO - 2018-03-17 13:23:45 --> Hooks Class Initialized
DEBUG - 2018-03-17 13:23:45 --> UTF-8 Support Enabled
INFO - 2018-03-17 13:23:45 --> Utf8 Class Initialized
DEBUG - 2018-03-17 13:23:45 --> UTF-8 Support Enabled
DEBUG - 2018-03-17 13:23:45 --> UTF-8 Support Enabled
INFO - 2018-03-17 13:23:45 --> Utf8 Class Initialized
INFO - 2018-03-17 13:23:45 --> Utf8 Class Initialized
INFO - 2018-03-17 13:23:45 --> URI Class Initialized
INFO - 2018-03-17 13:23:45 --> URI Class Initialized
INFO - 2018-03-17 13:23:45 --> URI Class Initialized
INFO - 2018-03-17 13:23:45 --> Router Class Initialized
INFO - 2018-03-17 13:23:45 --> Output Class Initialized
INFO - 2018-03-17 13:23:45 --> Security Class Initialized
INFO - 2018-03-17 13:23:45 --> Router Class Initialized
DEBUG - 2018-03-17 13:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-17 13:23:45 --> Input Class Initialized
INFO - 2018-03-17 13:23:45 --> Router Class Initialized
INFO - 2018-03-17 13:23:45 --> Language Class Initialized
INFO - 2018-03-17 13:23:45 --> Output Class Initialized
INFO - 2018-03-17 13:23:45 --> Output Class Initialized
ERROR - 2018-03-17 13:23:45 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-17 13:23:45 --> Security Class Initialized
INFO - 2018-03-17 13:23:45 --> Security Class Initialized
DEBUG - 2018-03-17 13:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-17 13:23:45 --> Input Class Initialized
DEBUG - 2018-03-17 13:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-17 13:23:45 --> Input Class Initialized
INFO - 2018-03-17 13:23:45 --> Language Class Initialized
INFO - 2018-03-17 13:23:45 --> Language Class Initialized
ERROR - 2018-03-17 13:23:45 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-17 13:23:45 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-17 13:23:45 --> Config Class Initialized
INFO - 2018-03-17 13:23:45 --> Hooks Class Initialized
DEBUG - 2018-03-17 13:23:45 --> UTF-8 Support Enabled
INFO - 2018-03-17 13:23:45 --> Utf8 Class Initialized
INFO - 2018-03-17 13:23:45 --> URI Class Initialized
INFO - 2018-03-17 13:23:45 --> Router Class Initialized
INFO - 2018-03-17 13:23:45 --> Output Class Initialized
INFO - 2018-03-17 13:23:45 --> Security Class Initialized
DEBUG - 2018-03-17 13:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-17 13:23:45 --> Input Class Initialized
INFO - 2018-03-17 13:23:45 --> Language Class Initialized
INFO - 2018-03-17 13:23:45 --> Loader Class Initialized
INFO - 2018-03-17 13:23:45 --> Helper loaded: url_helper
INFO - 2018-03-17 13:23:45 --> Helper loaded: form_helper
INFO - 2018-03-17 13:23:45 --> Database Driver Class Initialized
DEBUG - 2018-03-17 13:23:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-17 13:23:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-17 13:23:45 --> Form Validation Class Initialized
INFO - 2018-03-17 13:23:45 --> Model Class Initialized
INFO - 2018-03-17 13:23:45 --> Controller Class Initialized
INFO - 2018-03-17 13:23:45 --> Model Class Initialized
INFO - 2018-03-17 13:23:45 --> Model Class Initialized
INFO - 2018-03-17 13:23:45 --> Model Class Initialized
INFO - 2018-03-17 13:23:45 --> Model Class Initialized
DEBUG - 2018-03-17 13:23:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-17 13:23:45 --> Model Class Initialized
INFO - 2018-03-17 13:23:45 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-17 13:23:45 --> Final output sent to browser
DEBUG - 2018-03-17 13:23:45 --> Total execution time: 0.0616
INFO - 2018-03-17 13:23:45 --> Config Class Initialized
INFO - 2018-03-17 13:23:45 --> Hooks Class Initialized
INFO - 2018-03-17 13:23:45 --> Config Class Initialized
INFO - 2018-03-17 13:23:45 --> Hooks Class Initialized
INFO - 2018-03-17 13:23:45 --> Config Class Initialized
INFO - 2018-03-17 13:23:45 --> Hooks Class Initialized
DEBUG - 2018-03-17 13:23:45 --> UTF-8 Support Enabled
INFO - 2018-03-17 13:23:45 --> Utf8 Class Initialized
INFO - 2018-03-17 13:23:45 --> Config Class Initialized
INFO - 2018-03-17 13:23:45 --> Hooks Class Initialized
DEBUG - 2018-03-17 13:23:45 --> UTF-8 Support Enabled
DEBUG - 2018-03-17 13:23:45 --> UTF-8 Support Enabled
INFO - 2018-03-17 13:23:45 --> Utf8 Class Initialized
INFO - 2018-03-17 13:23:45 --> URI Class Initialized
INFO - 2018-03-17 13:23:45 --> Utf8 Class Initialized
INFO - 2018-03-17 13:23:45 --> URI Class Initialized
INFO - 2018-03-17 13:23:45 --> URI Class Initialized
INFO - 2018-03-17 13:23:45 --> Router Class Initialized
DEBUG - 2018-03-17 13:23:45 --> UTF-8 Support Enabled
INFO - 2018-03-17 13:23:45 --> Utf8 Class Initialized
INFO - 2018-03-17 13:23:45 --> Router Class Initialized
INFO - 2018-03-17 13:23:45 --> Router Class Initialized
INFO - 2018-03-17 13:23:45 --> URI Class Initialized
INFO - 2018-03-17 13:23:45 --> Output Class Initialized
INFO - 2018-03-17 13:23:45 --> Output Class Initialized
INFO - 2018-03-17 13:23:45 --> Router Class Initialized
INFO - 2018-03-17 13:23:45 --> Security Class Initialized
INFO - 2018-03-17 13:23:45 --> Output Class Initialized
DEBUG - 2018-03-17 13:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-17 13:23:45 --> Security Class Initialized
INFO - 2018-03-17 13:23:45 --> Input Class Initialized
INFO - 2018-03-17 13:23:45 --> Security Class Initialized
INFO - 2018-03-17 13:23:45 --> Output Class Initialized
INFO - 2018-03-17 13:23:45 --> Language Class Initialized
DEBUG - 2018-03-17 13:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-17 13:23:45 --> Input Class Initialized
DEBUG - 2018-03-17 13:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-17 13:23:45 --> Input Class Initialized
ERROR - 2018-03-17 13:23:45 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-17 13:23:45 --> Security Class Initialized
INFO - 2018-03-17 13:23:45 --> Language Class Initialized
INFO - 2018-03-17 13:23:45 --> Language Class Initialized
DEBUG - 2018-03-17 13:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-17 13:23:45 --> Input Class Initialized
ERROR - 2018-03-17 13:23:45 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-17 13:23:45 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-17 13:23:45 --> Language Class Initialized
ERROR - 2018-03-17 13:23:45 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-17 13:23:45 --> Config Class Initialized
INFO - 2018-03-17 13:23:45 --> Hooks Class Initialized
INFO - 2018-03-17 13:23:45 --> Config Class Initialized
INFO - 2018-03-17 13:23:45 --> Hooks Class Initialized
INFO - 2018-03-17 13:23:45 --> Config Class Initialized
INFO - 2018-03-17 13:23:45 --> Hooks Class Initialized
DEBUG - 2018-03-17 13:23:45 --> UTF-8 Support Enabled
INFO - 2018-03-17 13:23:45 --> Utf8 Class Initialized
INFO - 2018-03-17 13:23:45 --> URI Class Initialized
DEBUG - 2018-03-17 13:23:45 --> UTF-8 Support Enabled
INFO - 2018-03-17 13:23:45 --> Utf8 Class Initialized
DEBUG - 2018-03-17 13:23:45 --> UTF-8 Support Enabled
INFO - 2018-03-17 13:23:45 --> Utf8 Class Initialized
INFO - 2018-03-17 13:23:45 --> Router Class Initialized
INFO - 2018-03-17 13:23:45 --> URI Class Initialized
INFO - 2018-03-17 13:23:45 --> URI Class Initialized
INFO - 2018-03-17 13:23:45 --> Output Class Initialized
INFO - 2018-03-17 13:23:45 --> Router Class Initialized
INFO - 2018-03-17 13:23:45 --> Router Class Initialized
INFO - 2018-03-17 13:23:45 --> Security Class Initialized
INFO - 2018-03-17 13:23:45 --> Output Class Initialized
DEBUG - 2018-03-17 13:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-17 13:23:45 --> Output Class Initialized
INFO - 2018-03-17 13:23:45 --> Input Class Initialized
INFO - 2018-03-17 13:23:45 --> Security Class Initialized
INFO - 2018-03-17 13:23:45 --> Language Class Initialized
INFO - 2018-03-17 13:23:45 --> Security Class Initialized
DEBUG - 2018-03-17 13:23:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-03-17 13:23:45 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-17 13:23:45 --> Input Class Initialized
DEBUG - 2018-03-17 13:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-17 13:23:45 --> Input Class Initialized
INFO - 2018-03-17 13:23:45 --> Language Class Initialized
INFO - 2018-03-17 13:23:45 --> Language Class Initialized
ERROR - 2018-03-17 13:23:45 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-17 13:23:45 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-17 13:23:49 --> Config Class Initialized
INFO - 2018-03-17 13:23:49 --> Hooks Class Initialized
DEBUG - 2018-03-17 13:23:49 --> UTF-8 Support Enabled
INFO - 2018-03-17 13:23:49 --> Utf8 Class Initialized
INFO - 2018-03-17 13:23:49 --> URI Class Initialized
INFO - 2018-03-17 13:23:49 --> Router Class Initialized
INFO - 2018-03-17 13:23:49 --> Output Class Initialized
INFO - 2018-03-17 13:23:49 --> Security Class Initialized
DEBUG - 2018-03-17 13:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-17 13:23:49 --> Input Class Initialized
INFO - 2018-03-17 13:23:49 --> Language Class Initialized
INFO - 2018-03-17 13:23:49 --> Loader Class Initialized
INFO - 2018-03-17 13:23:49 --> Helper loaded: url_helper
INFO - 2018-03-17 13:23:49 --> Helper loaded: form_helper
INFO - 2018-03-17 13:23:49 --> Database Driver Class Initialized
DEBUG - 2018-03-17 13:23:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-17 13:23:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-17 13:23:49 --> Form Validation Class Initialized
INFO - 2018-03-17 13:23:49 --> Model Class Initialized
INFO - 2018-03-17 13:23:49 --> Controller Class Initialized
INFO - 2018-03-17 13:23:49 --> Model Class Initialized
INFO - 2018-03-17 13:23:49 --> Model Class Initialized
INFO - 2018-03-17 13:23:49 --> Model Class Initialized
INFO - 2018-03-17 13:23:49 --> Model Class Initialized
DEBUG - 2018-03-17 13:23:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-17 13:23:49 --> Model Class Initialized
INFO - 2018-03-17 13:23:49 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-17 13:23:49 --> Final output sent to browser
DEBUG - 2018-03-17 13:23:49 --> Total execution time: 0.0660
INFO - 2018-03-17 13:23:49 --> Config Class Initialized
INFO - 2018-03-17 13:23:49 --> Config Class Initialized
INFO - 2018-03-17 13:23:49 --> Hooks Class Initialized
INFO - 2018-03-17 13:23:49 --> Hooks Class Initialized
DEBUG - 2018-03-17 13:23:49 --> UTF-8 Support Enabled
DEBUG - 2018-03-17 13:23:49 --> UTF-8 Support Enabled
INFO - 2018-03-17 13:23:49 --> Utf8 Class Initialized
INFO - 2018-03-17 13:23:49 --> Utf8 Class Initialized
INFO - 2018-03-17 13:23:49 --> URI Class Initialized
INFO - 2018-03-17 13:23:49 --> URI Class Initialized
INFO - 2018-03-17 13:23:49 --> Router Class Initialized
INFO - 2018-03-17 13:23:49 --> Router Class Initialized
INFO - 2018-03-17 13:23:49 --> Output Class Initialized
INFO - 2018-03-17 13:23:49 --> Output Class Initialized
INFO - 2018-03-17 13:23:49 --> Security Class Initialized
INFO - 2018-03-17 13:23:49 --> Security Class Initialized
DEBUG - 2018-03-17 13:23:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-17 13:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-17 13:23:49 --> Input Class Initialized
INFO - 2018-03-17 13:23:49 --> Input Class Initialized
INFO - 2018-03-17 13:23:49 --> Language Class Initialized
INFO - 2018-03-17 13:23:49 --> Language Class Initialized
ERROR - 2018-03-17 13:23:49 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-17 13:23:49 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-17 13:23:49 --> Config Class Initialized
INFO - 2018-03-17 13:23:49 --> Hooks Class Initialized
DEBUG - 2018-03-17 13:23:49 --> UTF-8 Support Enabled
INFO - 2018-03-17 13:23:49 --> Config Class Initialized
INFO - 2018-03-17 13:23:49 --> Utf8 Class Initialized
INFO - 2018-03-17 13:23:49 --> Hooks Class Initialized
INFO - 2018-03-17 13:23:49 --> URI Class Initialized
INFO - 2018-03-17 13:23:49 --> Router Class Initialized
DEBUG - 2018-03-17 13:23:49 --> UTF-8 Support Enabled
INFO - 2018-03-17 13:23:49 --> Utf8 Class Initialized
INFO - 2018-03-17 13:23:49 --> URI Class Initialized
INFO - 2018-03-17 13:23:49 --> Output Class Initialized
INFO - 2018-03-17 13:23:49 --> Router Class Initialized
INFO - 2018-03-17 13:23:49 --> Security Class Initialized
INFO - 2018-03-17 13:23:49 --> Output Class Initialized
DEBUG - 2018-03-17 13:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-17 13:23:49 --> Input Class Initialized
INFO - 2018-03-17 13:23:49 --> Language Class Initialized
INFO - 2018-03-17 13:23:49 --> Security Class Initialized
ERROR - 2018-03-17 13:23:49 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-17 13:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-17 13:23:49 --> Input Class Initialized
INFO - 2018-03-17 13:23:49 --> Language Class Initialized
ERROR - 2018-03-17 13:23:49 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-17 13:23:49 --> Config Class Initialized
INFO - 2018-03-17 13:23:49 --> Hooks Class Initialized
INFO - 2018-03-17 13:23:49 --> Config Class Initialized
INFO - 2018-03-17 13:23:49 --> Hooks Class Initialized
INFO - 2018-03-17 13:23:49 --> Config Class Initialized
INFO - 2018-03-17 13:23:49 --> Hooks Class Initialized
DEBUG - 2018-03-17 13:23:49 --> UTF-8 Support Enabled
INFO - 2018-03-17 13:23:49 --> Utf8 Class Initialized
INFO - 2018-03-17 13:23:49 --> URI Class Initialized
DEBUG - 2018-03-17 13:23:49 --> UTF-8 Support Enabled
INFO - 2018-03-17 13:23:49 --> Utf8 Class Initialized
DEBUG - 2018-03-17 13:23:49 --> UTF-8 Support Enabled
INFO - 2018-03-17 13:23:49 --> Utf8 Class Initialized
INFO - 2018-03-17 13:23:49 --> URI Class Initialized
INFO - 2018-03-17 13:23:49 --> Router Class Initialized
INFO - 2018-03-17 13:23:49 --> URI Class Initialized
INFO - 2018-03-17 13:23:49 --> Router Class Initialized
INFO - 2018-03-17 13:23:49 --> Router Class Initialized
INFO - 2018-03-17 13:23:49 --> Output Class Initialized
INFO - 2018-03-17 13:23:49 --> Security Class Initialized
INFO - 2018-03-17 13:23:49 --> Output Class Initialized
INFO - 2018-03-17 13:23:49 --> Output Class Initialized
INFO - 2018-03-17 13:23:49 --> Security Class Initialized
INFO - 2018-03-17 13:23:49 --> Security Class Initialized
DEBUG - 2018-03-17 13:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-17 13:23:49 --> Input Class Initialized
DEBUG - 2018-03-17 13:23:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-17 13:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-17 13:23:49 --> Input Class Initialized
INFO - 2018-03-17 13:23:49 --> Language Class Initialized
INFO - 2018-03-17 13:23:49 --> Input Class Initialized
INFO - 2018-03-17 13:23:49 --> Language Class Initialized
INFO - 2018-03-17 13:23:49 --> Language Class Initialized
ERROR - 2018-03-17 13:23:49 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-17 13:23:49 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-17 13:23:49 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-17 13:24:00 --> Config Class Initialized
INFO - 2018-03-17 13:24:00 --> Hooks Class Initialized
DEBUG - 2018-03-17 13:24:00 --> UTF-8 Support Enabled
INFO - 2018-03-17 13:24:00 --> Utf8 Class Initialized
INFO - 2018-03-17 13:24:00 --> URI Class Initialized
INFO - 2018-03-17 13:24:00 --> Router Class Initialized
INFO - 2018-03-17 13:24:00 --> Output Class Initialized
INFO - 2018-03-17 13:24:00 --> Security Class Initialized
DEBUG - 2018-03-17 13:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-17 13:24:00 --> Input Class Initialized
INFO - 2018-03-17 13:24:00 --> Language Class Initialized
INFO - 2018-03-17 13:24:00 --> Loader Class Initialized
INFO - 2018-03-17 13:24:00 --> Helper loaded: url_helper
INFO - 2018-03-17 13:24:00 --> Helper loaded: form_helper
INFO - 2018-03-17 13:24:00 --> Database Driver Class Initialized
DEBUG - 2018-03-17 13:24:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-17 13:24:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-17 13:24:00 --> Form Validation Class Initialized
INFO - 2018-03-17 13:24:00 --> Model Class Initialized
INFO - 2018-03-17 13:24:00 --> Controller Class Initialized
INFO - 2018-03-17 13:24:00 --> Model Class Initialized
INFO - 2018-03-17 13:24:00 --> Model Class Initialized
INFO - 2018-03-17 13:24:00 --> Model Class Initialized
INFO - 2018-03-17 13:24:00 --> Model Class Initialized
DEBUG - 2018-03-17 13:24:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-17 13:24:00 --> Model Class Initialized
INFO - 2018-03-17 13:24:00 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-17 13:24:00 --> Final output sent to browser
DEBUG - 2018-03-17 13:24:00 --> Total execution time: 0.0740
INFO - 2018-03-17 13:24:00 --> Config Class Initialized
INFO - 2018-03-17 13:24:00 --> Config Class Initialized
INFO - 2018-03-17 13:24:00 --> Hooks Class Initialized
INFO - 2018-03-17 13:24:00 --> Hooks Class Initialized
DEBUG - 2018-03-17 13:24:00 --> UTF-8 Support Enabled
DEBUG - 2018-03-17 13:24:00 --> UTF-8 Support Enabled
INFO - 2018-03-17 13:24:00 --> Utf8 Class Initialized
INFO - 2018-03-17 13:24:00 --> Utf8 Class Initialized
INFO - 2018-03-17 13:24:00 --> URI Class Initialized
INFO - 2018-03-17 13:24:00 --> URI Class Initialized
INFO - 2018-03-17 13:24:00 --> Router Class Initialized
INFO - 2018-03-17 13:24:00 --> Router Class Initialized
INFO - 2018-03-17 13:24:00 --> Output Class Initialized
INFO - 2018-03-17 13:24:00 --> Output Class Initialized
INFO - 2018-03-17 13:24:00 --> Security Class Initialized
INFO - 2018-03-17 13:24:00 --> Security Class Initialized
DEBUG - 2018-03-17 13:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-17 13:24:00 --> Input Class Initialized
DEBUG - 2018-03-17 13:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-17 13:24:00 --> Language Class Initialized
INFO - 2018-03-17 13:24:00 --> Input Class Initialized
INFO - 2018-03-17 13:24:00 --> Language Class Initialized
ERROR - 2018-03-17 13:24:00 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-17 13:24:00 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-17 13:24:00 --> Config Class Initialized
INFO - 2018-03-17 13:24:00 --> Hooks Class Initialized
INFO - 2018-03-17 13:24:00 --> Config Class Initialized
INFO - 2018-03-17 13:24:00 --> Hooks Class Initialized
DEBUG - 2018-03-17 13:24:00 --> UTF-8 Support Enabled
INFO - 2018-03-17 13:24:00 --> Utf8 Class Initialized
INFO - 2018-03-17 13:24:00 --> URI Class Initialized
DEBUG - 2018-03-17 13:24:00 --> UTF-8 Support Enabled
INFO - 2018-03-17 13:24:00 --> Utf8 Class Initialized
INFO - 2018-03-17 13:24:00 --> Router Class Initialized
INFO - 2018-03-17 13:24:00 --> URI Class Initialized
INFO - 2018-03-17 13:24:00 --> Output Class Initialized
INFO - 2018-03-17 13:24:00 --> Router Class Initialized
INFO - 2018-03-17 13:24:00 --> Security Class Initialized
INFO - 2018-03-17 13:24:00 --> Output Class Initialized
DEBUG - 2018-03-17 13:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-17 13:24:00 --> Input Class Initialized
INFO - 2018-03-17 13:24:00 --> Language Class Initialized
INFO - 2018-03-17 13:24:00 --> Security Class Initialized
ERROR - 2018-03-17 13:24:00 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-17 13:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-17 13:24:00 --> Input Class Initialized
INFO - 2018-03-17 13:24:00 --> Language Class Initialized
ERROR - 2018-03-17 13:24:00 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-17 13:24:00 --> Config Class Initialized
INFO - 2018-03-17 13:24:00 --> Hooks Class Initialized
INFO - 2018-03-17 13:24:00 --> Config Class Initialized
INFO - 2018-03-17 13:24:00 --> Hooks Class Initialized
INFO - 2018-03-17 13:24:00 --> Config Class Initialized
DEBUG - 2018-03-17 13:24:00 --> UTF-8 Support Enabled
INFO - 2018-03-17 13:24:00 --> Hooks Class Initialized
INFO - 2018-03-17 13:24:00 --> Utf8 Class Initialized
DEBUG - 2018-03-17 13:24:00 --> UTF-8 Support Enabled
INFO - 2018-03-17 13:24:00 --> URI Class Initialized
INFO - 2018-03-17 13:24:00 --> Utf8 Class Initialized
DEBUG - 2018-03-17 13:24:00 --> UTF-8 Support Enabled
INFO - 2018-03-17 13:24:00 --> Utf8 Class Initialized
INFO - 2018-03-17 13:24:00 --> URI Class Initialized
INFO - 2018-03-17 13:24:00 --> Router Class Initialized
INFO - 2018-03-17 13:24:00 --> URI Class Initialized
INFO - 2018-03-17 13:24:00 --> Router Class Initialized
INFO - 2018-03-17 13:24:00 --> Output Class Initialized
INFO - 2018-03-17 13:24:00 --> Router Class Initialized
INFO - 2018-03-17 13:24:00 --> Output Class Initialized
INFO - 2018-03-17 13:24:00 --> Security Class Initialized
INFO - 2018-03-17 13:24:00 --> Output Class Initialized
INFO - 2018-03-17 13:24:00 --> Security Class Initialized
DEBUG - 2018-03-17 13:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-17 13:24:00 --> Input Class Initialized
INFO - 2018-03-17 13:24:00 --> Security Class Initialized
DEBUG - 2018-03-17 13:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-17 13:24:00 --> Input Class Initialized
INFO - 2018-03-17 13:24:00 --> Language Class Initialized
DEBUG - 2018-03-17 13:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-17 13:24:00 --> Input Class Initialized
INFO - 2018-03-17 13:24:00 --> Language Class Initialized
INFO - 2018-03-17 13:24:00 --> Language Class Initialized
ERROR - 2018-03-17 13:24:00 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-17 13:24:00 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-17 13:24:00 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-17 13:27:25 --> Config Class Initialized
INFO - 2018-03-17 13:27:25 --> Hooks Class Initialized
DEBUG - 2018-03-17 13:27:25 --> UTF-8 Support Enabled
INFO - 2018-03-17 13:27:25 --> Utf8 Class Initialized
INFO - 2018-03-17 13:27:25 --> URI Class Initialized
INFO - 2018-03-17 13:27:25 --> Router Class Initialized
INFO - 2018-03-17 13:27:25 --> Output Class Initialized
INFO - 2018-03-17 13:27:25 --> Security Class Initialized
DEBUG - 2018-03-17 13:27:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-17 13:27:25 --> Input Class Initialized
INFO - 2018-03-17 13:27:25 --> Language Class Initialized
INFO - 2018-03-17 13:27:25 --> Loader Class Initialized
INFO - 2018-03-17 13:27:25 --> Helper loaded: url_helper
INFO - 2018-03-17 13:27:25 --> Helper loaded: form_helper
INFO - 2018-03-17 13:27:25 --> Database Driver Class Initialized
DEBUG - 2018-03-17 13:27:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-17 13:27:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-17 13:27:25 --> Form Validation Class Initialized
INFO - 2018-03-17 13:27:25 --> Model Class Initialized
INFO - 2018-03-17 13:27:25 --> Controller Class Initialized
INFO - 2018-03-17 13:27:25 --> Model Class Initialized
INFO - 2018-03-17 13:27:25 --> Model Class Initialized
INFO - 2018-03-17 13:27:25 --> Model Class Initialized
INFO - 2018-03-17 13:27:25 --> Model Class Initialized
DEBUG - 2018-03-17 13:27:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-17 13:27:25 --> Model Class Initialized
INFO - 2018-03-17 13:27:25 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-17 13:27:25 --> Final output sent to browser
DEBUG - 2018-03-17 13:27:25 --> Total execution time: 0.0505
INFO - 2018-03-17 13:27:25 --> Config Class Initialized
INFO - 2018-03-17 13:27:25 --> Hooks Class Initialized
INFO - 2018-03-17 13:27:25 --> Config Class Initialized
INFO - 2018-03-17 13:27:25 --> Config Class Initialized
INFO - 2018-03-17 13:27:25 --> Hooks Class Initialized
INFO - 2018-03-17 13:27:25 --> Hooks Class Initialized
DEBUG - 2018-03-17 13:27:25 --> UTF-8 Support Enabled
INFO - 2018-03-17 13:27:25 --> Utf8 Class Initialized
INFO - 2018-03-17 13:27:25 --> Config Class Initialized
DEBUG - 2018-03-17 13:27:25 --> UTF-8 Support Enabled
INFO - 2018-03-17 13:27:25 --> Hooks Class Initialized
INFO - 2018-03-17 13:27:25 --> Utf8 Class Initialized
INFO - 2018-03-17 13:27:25 --> URI Class Initialized
DEBUG - 2018-03-17 13:27:25 --> UTF-8 Support Enabled
INFO - 2018-03-17 13:27:25 --> Utf8 Class Initialized
INFO - 2018-03-17 13:27:25 --> URI Class Initialized
INFO - 2018-03-17 13:27:25 --> URI Class Initialized
INFO - 2018-03-17 13:27:25 --> Router Class Initialized
DEBUG - 2018-03-17 13:27:25 --> UTF-8 Support Enabled
INFO - 2018-03-17 13:27:25 --> Utf8 Class Initialized
INFO - 2018-03-17 13:27:25 --> Router Class Initialized
INFO - 2018-03-17 13:27:25 --> Output Class Initialized
INFO - 2018-03-17 13:27:25 --> Router Class Initialized
INFO - 2018-03-17 13:27:25 --> URI Class Initialized
INFO - 2018-03-17 13:27:25 --> Security Class Initialized
INFO - 2018-03-17 13:27:25 --> Output Class Initialized
INFO - 2018-03-17 13:27:25 --> Output Class Initialized
INFO - 2018-03-17 13:27:25 --> Router Class Initialized
DEBUG - 2018-03-17 13:27:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-17 13:27:25 --> Input Class Initialized
INFO - 2018-03-17 13:27:25 --> Security Class Initialized
INFO - 2018-03-17 13:27:25 --> Language Class Initialized
INFO - 2018-03-17 13:27:25 --> Security Class Initialized
INFO - 2018-03-17 13:27:25 --> Output Class Initialized
DEBUG - 2018-03-17 13:27:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-03-17 13:27:25 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-17 13:27:25 --> Input Class Initialized
DEBUG - 2018-03-17 13:27:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-17 13:27:25 --> Input Class Initialized
INFO - 2018-03-17 13:27:25 --> Security Class Initialized
INFO - 2018-03-17 13:27:25 --> Language Class Initialized
INFO - 2018-03-17 13:27:25 --> Language Class Initialized
DEBUG - 2018-03-17 13:27:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-03-17 13:27:25 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-17 13:27:25 --> Input Class Initialized
ERROR - 2018-03-17 13:27:25 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-17 13:27:25 --> Language Class Initialized
ERROR - 2018-03-17 13:27:25 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-17 13:27:25 --> Config Class Initialized
INFO - 2018-03-17 13:27:25 --> Hooks Class Initialized
INFO - 2018-03-17 13:27:25 --> Config Class Initialized
INFO - 2018-03-17 13:27:25 --> Config Class Initialized
INFO - 2018-03-17 13:27:25 --> Hooks Class Initialized
INFO - 2018-03-17 13:27:25 --> Hooks Class Initialized
DEBUG - 2018-03-17 13:27:25 --> UTF-8 Support Enabled
INFO - 2018-03-17 13:27:25 --> Utf8 Class Initialized
INFO - 2018-03-17 13:27:25 --> URI Class Initialized
DEBUG - 2018-03-17 13:27:25 --> UTF-8 Support Enabled
DEBUG - 2018-03-17 13:27:25 --> UTF-8 Support Enabled
INFO - 2018-03-17 13:27:25 --> Utf8 Class Initialized
INFO - 2018-03-17 13:27:25 --> Utf8 Class Initialized
INFO - 2018-03-17 13:27:25 --> Router Class Initialized
INFO - 2018-03-17 13:27:25 --> URI Class Initialized
INFO - 2018-03-17 13:27:25 --> URI Class Initialized
INFO - 2018-03-17 13:27:25 --> Output Class Initialized
INFO - 2018-03-17 13:27:25 --> Router Class Initialized
INFO - 2018-03-17 13:27:25 --> Router Class Initialized
INFO - 2018-03-17 13:27:25 --> Security Class Initialized
INFO - 2018-03-17 13:27:25 --> Output Class Initialized
INFO - 2018-03-17 13:27:25 --> Output Class Initialized
DEBUG - 2018-03-17 13:27:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-17 13:27:25 --> Input Class Initialized
INFO - 2018-03-17 13:27:25 --> Security Class Initialized
INFO - 2018-03-17 13:27:25 --> Security Class Initialized
INFO - 2018-03-17 13:27:25 --> Language Class Initialized
DEBUG - 2018-03-17 13:27:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-17 13:27:25 --> Input Class Initialized
ERROR - 2018-03-17 13:27:25 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-03-17 13:27:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-17 13:27:25 --> Input Class Initialized
INFO - 2018-03-17 13:27:25 --> Language Class Initialized
INFO - 2018-03-17 13:27:25 --> Language Class Initialized
ERROR - 2018-03-17 13:27:25 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-17 13:27:25 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-17 13:27:25 --> Config Class Initialized
INFO - 2018-03-17 13:27:25 --> Hooks Class Initialized
DEBUG - 2018-03-17 13:27:25 --> UTF-8 Support Enabled
INFO - 2018-03-17 13:27:25 --> Utf8 Class Initialized
INFO - 2018-03-17 13:27:25 --> URI Class Initialized
INFO - 2018-03-17 13:27:25 --> Router Class Initialized
INFO - 2018-03-17 13:27:25 --> Output Class Initialized
INFO - 2018-03-17 13:27:25 --> Security Class Initialized
DEBUG - 2018-03-17 13:27:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-17 13:27:25 --> Input Class Initialized
INFO - 2018-03-17 13:27:25 --> Language Class Initialized
INFO - 2018-03-17 13:27:25 --> Loader Class Initialized
INFO - 2018-03-17 13:27:25 --> Helper loaded: url_helper
INFO - 2018-03-17 13:27:25 --> Helper loaded: form_helper
INFO - 2018-03-17 13:27:25 --> Database Driver Class Initialized
DEBUG - 2018-03-17 13:27:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-17 13:27:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-17 13:27:25 --> Form Validation Class Initialized
INFO - 2018-03-17 13:27:25 --> Model Class Initialized
INFO - 2018-03-17 13:27:25 --> Controller Class Initialized
INFO - 2018-03-17 13:27:25 --> Model Class Initialized
INFO - 2018-03-17 13:27:25 --> Model Class Initialized
INFO - 2018-03-17 13:27:25 --> Model Class Initialized
INFO - 2018-03-17 13:27:25 --> Model Class Initialized
DEBUG - 2018-03-17 13:27:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-17 13:27:25 --> Model Class Initialized
INFO - 2018-03-17 13:27:25 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-17 13:27:25 --> Final output sent to browser
DEBUG - 2018-03-17 13:27:25 --> Total execution time: 0.0613
INFO - 2018-03-17 13:27:26 --> Config Class Initialized
INFO - 2018-03-17 13:27:26 --> Hooks Class Initialized
INFO - 2018-03-17 13:27:26 --> Config Class Initialized
INFO - 2018-03-17 13:27:26 --> Hooks Class Initialized
INFO - 2018-03-17 13:27:26 --> Config Class Initialized
INFO - 2018-03-17 13:27:26 --> Hooks Class Initialized
DEBUG - 2018-03-17 13:27:26 --> UTF-8 Support Enabled
INFO - 2018-03-17 13:27:26 --> Utf8 Class Initialized
DEBUG - 2018-03-17 13:27:26 --> UTF-8 Support Enabled
INFO - 2018-03-17 13:27:26 --> Config Class Initialized
INFO - 2018-03-17 13:27:26 --> Hooks Class Initialized
INFO - 2018-03-17 13:27:26 --> Utf8 Class Initialized
DEBUG - 2018-03-17 13:27:26 --> UTF-8 Support Enabled
INFO - 2018-03-17 13:27:26 --> Utf8 Class Initialized
INFO - 2018-03-17 13:27:26 --> URI Class Initialized
INFO - 2018-03-17 13:27:26 --> URI Class Initialized
INFO - 2018-03-17 13:27:26 --> URI Class Initialized
INFO - 2018-03-17 13:27:26 --> Router Class Initialized
DEBUG - 2018-03-17 13:27:26 --> UTF-8 Support Enabled
INFO - 2018-03-17 13:27:26 --> Utf8 Class Initialized
INFO - 2018-03-17 13:27:26 --> Router Class Initialized
INFO - 2018-03-17 13:27:26 --> Router Class Initialized
INFO - 2018-03-17 13:27:26 --> URI Class Initialized
INFO - 2018-03-17 13:27:26 --> Output Class Initialized
INFO - 2018-03-17 13:27:26 --> Output Class Initialized
INFO - 2018-03-17 13:27:26 --> Security Class Initialized
INFO - 2018-03-17 13:27:26 --> Router Class Initialized
INFO - 2018-03-17 13:27:26 --> Output Class Initialized
INFO - 2018-03-17 13:27:26 --> Security Class Initialized
DEBUG - 2018-03-17 13:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-17 13:27:26 --> Input Class Initialized
INFO - 2018-03-17 13:27:26 --> Output Class Initialized
INFO - 2018-03-17 13:27:26 --> Security Class Initialized
DEBUG - 2018-03-17 13:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-17 13:27:26 --> Language Class Initialized
INFO - 2018-03-17 13:27:26 --> Input Class Initialized
INFO - 2018-03-17 13:27:26 --> Security Class Initialized
DEBUG - 2018-03-17 13:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-17 13:27:26 --> Language Class Initialized
INFO - 2018-03-17 13:27:26 --> Input Class Initialized
ERROR - 2018-03-17 13:27:26 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-17 13:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-17 13:27:26 --> Language Class Initialized
INFO - 2018-03-17 13:27:26 --> Input Class Initialized
ERROR - 2018-03-17 13:27:26 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-17 13:27:26 --> Language Class Initialized
ERROR - 2018-03-17 13:27:26 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-17 13:27:26 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-17 13:27:26 --> Config Class Initialized
INFO - 2018-03-17 13:27:26 --> Hooks Class Initialized
INFO - 2018-03-17 13:27:26 --> Config Class Initialized
INFO - 2018-03-17 13:27:26 --> Hooks Class Initialized
INFO - 2018-03-17 13:27:26 --> Config Class Initialized
INFO - 2018-03-17 13:27:26 --> Hooks Class Initialized
DEBUG - 2018-03-17 13:27:26 --> UTF-8 Support Enabled
INFO - 2018-03-17 13:27:26 --> Utf8 Class Initialized
DEBUG - 2018-03-17 13:27:26 --> UTF-8 Support Enabled
INFO - 2018-03-17 13:27:26 --> Utf8 Class Initialized
INFO - 2018-03-17 13:27:26 --> URI Class Initialized
DEBUG - 2018-03-17 13:27:26 --> UTF-8 Support Enabled
INFO - 2018-03-17 13:27:26 --> Utf8 Class Initialized
INFO - 2018-03-17 13:27:26 --> URI Class Initialized
INFO - 2018-03-17 13:27:26 --> URI Class Initialized
INFO - 2018-03-17 13:27:26 --> Router Class Initialized
INFO - 2018-03-17 13:27:26 --> Router Class Initialized
INFO - 2018-03-17 13:27:26 --> Router Class Initialized
INFO - 2018-03-17 13:27:26 --> Output Class Initialized
INFO - 2018-03-17 13:27:26 --> Output Class Initialized
INFO - 2018-03-17 13:27:26 --> Security Class Initialized
INFO - 2018-03-17 13:27:26 --> Output Class Initialized
INFO - 2018-03-17 13:27:26 --> Security Class Initialized
DEBUG - 2018-03-17 13:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-17 13:27:26 --> Input Class Initialized
INFO - 2018-03-17 13:27:26 --> Security Class Initialized
DEBUG - 2018-03-17 13:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-17 13:27:26 --> Language Class Initialized
INFO - 2018-03-17 13:27:26 --> Input Class Initialized
INFO - 2018-03-17 13:27:26 --> Language Class Initialized
DEBUG - 2018-03-17 13:27:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-03-17 13:27:26 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-17 13:27:26 --> Input Class Initialized
INFO - 2018-03-17 13:27:26 --> Language Class Initialized
ERROR - 2018-03-17 13:27:26 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-17 13:27:26 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-17 13:27:26 --> Config Class Initialized
INFO - 2018-03-17 13:27:26 --> Hooks Class Initialized
DEBUG - 2018-03-17 13:27:26 --> UTF-8 Support Enabled
INFO - 2018-03-17 13:27:26 --> Utf8 Class Initialized
INFO - 2018-03-17 13:27:26 --> URI Class Initialized
INFO - 2018-03-17 13:27:26 --> Router Class Initialized
INFO - 2018-03-17 13:27:26 --> Output Class Initialized
INFO - 2018-03-17 13:27:26 --> Security Class Initialized
DEBUG - 2018-03-17 13:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-17 13:27:26 --> Input Class Initialized
INFO - 2018-03-17 13:27:26 --> Language Class Initialized
INFO - 2018-03-17 13:27:26 --> Loader Class Initialized
INFO - 2018-03-17 13:27:26 --> Helper loaded: url_helper
INFO - 2018-03-17 13:27:26 --> Helper loaded: form_helper
INFO - 2018-03-17 13:27:26 --> Database Driver Class Initialized
DEBUG - 2018-03-17 13:27:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-17 13:27:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-17 13:27:26 --> Form Validation Class Initialized
INFO - 2018-03-17 13:27:26 --> Model Class Initialized
INFO - 2018-03-17 13:27:26 --> Controller Class Initialized
INFO - 2018-03-17 13:27:26 --> Model Class Initialized
INFO - 2018-03-17 13:27:26 --> Model Class Initialized
INFO - 2018-03-17 13:27:26 --> Model Class Initialized
INFO - 2018-03-17 13:27:26 --> Model Class Initialized
DEBUG - 2018-03-17 13:27:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-17 13:27:26 --> Model Class Initialized
INFO - 2018-03-17 13:27:26 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-17 13:27:26 --> Final output sent to browser
DEBUG - 2018-03-17 13:27:26 --> Total execution time: 0.0477
INFO - 2018-03-17 13:27:27 --> Config Class Initialized
INFO - 2018-03-17 13:27:27 --> Hooks Class Initialized
INFO - 2018-03-17 13:27:27 --> Config Class Initialized
INFO - 2018-03-17 13:27:27 --> Config Class Initialized
INFO - 2018-03-17 13:27:27 --> Hooks Class Initialized
INFO - 2018-03-17 13:27:27 --> Hooks Class Initialized
DEBUG - 2018-03-17 13:27:27 --> UTF-8 Support Enabled
INFO - 2018-03-17 13:27:27 --> Utf8 Class Initialized
INFO - 2018-03-17 13:27:27 --> Config Class Initialized
DEBUG - 2018-03-17 13:27:27 --> UTF-8 Support Enabled
DEBUG - 2018-03-17 13:27:27 --> UTF-8 Support Enabled
INFO - 2018-03-17 13:27:27 --> Hooks Class Initialized
INFO - 2018-03-17 13:27:27 --> Utf8 Class Initialized
INFO - 2018-03-17 13:27:27 --> Utf8 Class Initialized
INFO - 2018-03-17 13:27:27 --> URI Class Initialized
INFO - 2018-03-17 13:27:27 --> URI Class Initialized
INFO - 2018-03-17 13:27:27 --> URI Class Initialized
INFO - 2018-03-17 13:27:27 --> Router Class Initialized
DEBUG - 2018-03-17 13:27:27 --> UTF-8 Support Enabled
INFO - 2018-03-17 13:27:27 --> Utf8 Class Initialized
INFO - 2018-03-17 13:27:27 --> Router Class Initialized
INFO - 2018-03-17 13:27:27 --> Router Class Initialized
INFO - 2018-03-17 13:27:27 --> URI Class Initialized
INFO - 2018-03-17 13:27:27 --> Output Class Initialized
INFO - 2018-03-17 13:27:27 --> Output Class Initialized
INFO - 2018-03-17 13:27:27 --> Output Class Initialized
INFO - 2018-03-17 13:27:27 --> Router Class Initialized
INFO - 2018-03-17 13:27:27 --> Security Class Initialized
INFO - 2018-03-17 13:27:27 --> Security Class Initialized
DEBUG - 2018-03-17 13:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-17 13:27:27 --> Security Class Initialized
INFO - 2018-03-17 13:27:27 --> Input Class Initialized
INFO - 2018-03-17 13:27:27 --> Output Class Initialized
DEBUG - 2018-03-17 13:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-17 13:27:27 --> Input Class Initialized
INFO - 2018-03-17 13:27:27 --> Language Class Initialized
INFO - 2018-03-17 13:27:27 --> Security Class Initialized
DEBUG - 2018-03-17 13:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-17 13:27:27 --> Language Class Initialized
INFO - 2018-03-17 13:27:27 --> Input Class Initialized
ERROR - 2018-03-17 13:27:27 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-17 13:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-17 13:27:27 --> Input Class Initialized
INFO - 2018-03-17 13:27:27 --> Language Class Initialized
ERROR - 2018-03-17 13:27:27 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-17 13:27:27 --> Language Class Initialized
ERROR - 2018-03-17 13:27:27 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-17 13:27:27 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-17 13:27:27 --> Config Class Initialized
INFO - 2018-03-17 13:27:27 --> Hooks Class Initialized
INFO - 2018-03-17 13:27:27 --> Config Class Initialized
INFO - 2018-03-17 13:27:27 --> Hooks Class Initialized
INFO - 2018-03-17 13:27:27 --> Config Class Initialized
INFO - 2018-03-17 13:27:27 --> Hooks Class Initialized
DEBUG - 2018-03-17 13:27:27 --> UTF-8 Support Enabled
DEBUG - 2018-03-17 13:27:27 --> UTF-8 Support Enabled
INFO - 2018-03-17 13:27:27 --> Utf8 Class Initialized
INFO - 2018-03-17 13:27:27 --> Utf8 Class Initialized
DEBUG - 2018-03-17 13:27:27 --> UTF-8 Support Enabled
INFO - 2018-03-17 13:27:27 --> Utf8 Class Initialized
INFO - 2018-03-17 13:27:27 --> URI Class Initialized
INFO - 2018-03-17 13:27:27 --> URI Class Initialized
INFO - 2018-03-17 13:27:27 --> URI Class Initialized
INFO - 2018-03-17 13:27:27 --> Router Class Initialized
INFO - 2018-03-17 13:27:27 --> Router Class Initialized
INFO - 2018-03-17 13:27:27 --> Router Class Initialized
INFO - 2018-03-17 13:27:27 --> Output Class Initialized
INFO - 2018-03-17 13:27:27 --> Output Class Initialized
INFO - 2018-03-17 13:27:27 --> Output Class Initialized
INFO - 2018-03-17 13:27:27 --> Security Class Initialized
INFO - 2018-03-17 13:27:27 --> Security Class Initialized
INFO - 2018-03-17 13:27:27 --> Security Class Initialized
DEBUG - 2018-03-17 13:27:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-17 13:27:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-17 13:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-17 13:27:27 --> Input Class Initialized
INFO - 2018-03-17 13:27:27 --> Input Class Initialized
INFO - 2018-03-17 13:27:27 --> Input Class Initialized
INFO - 2018-03-17 13:27:27 --> Language Class Initialized
INFO - 2018-03-17 13:27:27 --> Language Class Initialized
INFO - 2018-03-17 13:27:27 --> Language Class Initialized
ERROR - 2018-03-17 13:27:27 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-17 13:27:27 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-17 13:27:27 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-17 13:27:28 --> Config Class Initialized
INFO - 2018-03-17 13:27:28 --> Hooks Class Initialized
DEBUG - 2018-03-17 13:27:28 --> UTF-8 Support Enabled
INFO - 2018-03-17 13:27:28 --> Utf8 Class Initialized
INFO - 2018-03-17 13:27:28 --> URI Class Initialized
INFO - 2018-03-17 13:27:28 --> Router Class Initialized
INFO - 2018-03-17 13:27:28 --> Output Class Initialized
INFO - 2018-03-17 13:27:28 --> Security Class Initialized
DEBUG - 2018-03-17 13:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-17 13:27:28 --> Input Class Initialized
INFO - 2018-03-17 13:27:28 --> Language Class Initialized
INFO - 2018-03-17 13:27:28 --> Loader Class Initialized
INFO - 2018-03-17 13:27:28 --> Helper loaded: url_helper
INFO - 2018-03-17 13:27:28 --> Helper loaded: form_helper
INFO - 2018-03-17 13:27:28 --> Database Driver Class Initialized
DEBUG - 2018-03-17 13:27:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-17 13:27:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-17 13:27:28 --> Form Validation Class Initialized
INFO - 2018-03-17 13:27:28 --> Model Class Initialized
INFO - 2018-03-17 13:27:28 --> Controller Class Initialized
INFO - 2018-03-17 13:27:28 --> Model Class Initialized
INFO - 2018-03-17 13:27:28 --> Model Class Initialized
INFO - 2018-03-17 13:27:28 --> Model Class Initialized
INFO - 2018-03-17 13:27:28 --> Model Class Initialized
DEBUG - 2018-03-17 13:27:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-17 13:27:28 --> Model Class Initialized
INFO - 2018-03-17 13:27:28 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-17 13:27:28 --> Final output sent to browser
DEBUG - 2018-03-17 13:27:28 --> Total execution time: 0.0512
INFO - 2018-03-17 13:27:28 --> Config Class Initialized
INFO - 2018-03-17 13:27:28 --> Config Class Initialized
INFO - 2018-03-17 13:27:28 --> Config Class Initialized
INFO - 2018-03-17 13:27:28 --> Hooks Class Initialized
INFO - 2018-03-17 13:27:28 --> Hooks Class Initialized
INFO - 2018-03-17 13:27:28 --> Hooks Class Initialized
INFO - 2018-03-17 13:27:28 --> Config Class Initialized
DEBUG - 2018-03-17 13:27:28 --> UTF-8 Support Enabled
INFO - 2018-03-17 13:27:28 --> Hooks Class Initialized
INFO - 2018-03-17 13:27:28 --> Utf8 Class Initialized
DEBUG - 2018-03-17 13:27:28 --> UTF-8 Support Enabled
DEBUG - 2018-03-17 13:27:28 --> UTF-8 Support Enabled
INFO - 2018-03-17 13:27:28 --> Utf8 Class Initialized
INFO - 2018-03-17 13:27:28 --> Utf8 Class Initialized
INFO - 2018-03-17 13:27:28 --> URI Class Initialized
INFO - 2018-03-17 13:27:28 --> URI Class Initialized
INFO - 2018-03-17 13:27:28 --> URI Class Initialized
DEBUG - 2018-03-17 13:27:28 --> UTF-8 Support Enabled
INFO - 2018-03-17 13:27:28 --> Utf8 Class Initialized
INFO - 2018-03-17 13:27:28 --> Router Class Initialized
INFO - 2018-03-17 13:27:28 --> Router Class Initialized
INFO - 2018-03-17 13:27:28 --> Router Class Initialized
INFO - 2018-03-17 13:27:28 --> URI Class Initialized
INFO - 2018-03-17 13:27:28 --> Output Class Initialized
INFO - 2018-03-17 13:27:28 --> Output Class Initialized
INFO - 2018-03-17 13:27:28 --> Router Class Initialized
INFO - 2018-03-17 13:27:28 --> Output Class Initialized
INFO - 2018-03-17 13:27:28 --> Security Class Initialized
INFO - 2018-03-17 13:27:28 --> Security Class Initialized
INFO - 2018-03-17 13:27:28 --> Security Class Initialized
INFO - 2018-03-17 13:27:28 --> Output Class Initialized
DEBUG - 2018-03-17 13:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-17 13:27:28 --> Input Class Initialized
DEBUG - 2018-03-17 13:27:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-17 13:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-17 13:27:28 --> Input Class Initialized
INFO - 2018-03-17 13:27:28 --> Input Class Initialized
INFO - 2018-03-17 13:27:28 --> Security Class Initialized
INFO - 2018-03-17 13:27:28 --> Language Class Initialized
INFO - 2018-03-17 13:27:28 --> Language Class Initialized
INFO - 2018-03-17 13:27:28 --> Language Class Initialized
DEBUG - 2018-03-17 13:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-17 13:27:28 --> Input Class Initialized
ERROR - 2018-03-17 13:27:28 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-17 13:27:28 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-17 13:27:28 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-17 13:27:28 --> Language Class Initialized
ERROR - 2018-03-17 13:27:28 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-17 13:27:28 --> Config Class Initialized
INFO - 2018-03-17 13:27:28 --> Hooks Class Initialized
INFO - 2018-03-17 13:27:28 --> Config Class Initialized
INFO - 2018-03-17 13:27:28 --> Hooks Class Initialized
INFO - 2018-03-17 13:27:28 --> Config Class Initialized
INFO - 2018-03-17 13:27:28 --> Hooks Class Initialized
DEBUG - 2018-03-17 13:27:28 --> UTF-8 Support Enabled
INFO - 2018-03-17 13:27:28 --> Utf8 Class Initialized
DEBUG - 2018-03-17 13:27:28 --> UTF-8 Support Enabled
INFO - 2018-03-17 13:27:28 --> URI Class Initialized
DEBUG - 2018-03-17 13:27:28 --> UTF-8 Support Enabled
INFO - 2018-03-17 13:27:28 --> Utf8 Class Initialized
INFO - 2018-03-17 13:27:28 --> Utf8 Class Initialized
INFO - 2018-03-17 13:27:28 --> URI Class Initialized
INFO - 2018-03-17 13:27:28 --> Router Class Initialized
INFO - 2018-03-17 13:27:28 --> URI Class Initialized
INFO - 2018-03-17 13:27:28 --> Router Class Initialized
INFO - 2018-03-17 13:27:28 --> Output Class Initialized
INFO - 2018-03-17 13:27:28 --> Router Class Initialized
INFO - 2018-03-17 13:27:28 --> Security Class Initialized
INFO - 2018-03-17 13:27:28 --> Output Class Initialized
DEBUG - 2018-03-17 13:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-17 13:27:28 --> Input Class Initialized
INFO - 2018-03-17 13:27:28 --> Output Class Initialized
INFO - 2018-03-17 13:27:28 --> Security Class Initialized
INFO - 2018-03-17 13:27:28 --> Language Class Initialized
INFO - 2018-03-17 13:27:28 --> Security Class Initialized
DEBUG - 2018-03-17 13:27:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-03-17 13:27:28 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-17 13:27:28 --> Input Class Initialized
DEBUG - 2018-03-17 13:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-17 13:27:28 --> Language Class Initialized
INFO - 2018-03-17 13:27:28 --> Input Class Initialized
INFO - 2018-03-17 13:27:28 --> Language Class Initialized
ERROR - 2018-03-17 13:27:28 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-17 13:27:28 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-17 13:27:28 --> Config Class Initialized
INFO - 2018-03-17 13:27:28 --> Hooks Class Initialized
DEBUG - 2018-03-17 13:27:28 --> UTF-8 Support Enabled
INFO - 2018-03-17 13:27:28 --> Utf8 Class Initialized
INFO - 2018-03-17 13:27:28 --> URI Class Initialized
INFO - 2018-03-17 13:27:28 --> Router Class Initialized
INFO - 2018-03-17 13:27:28 --> Output Class Initialized
INFO - 2018-03-17 13:27:28 --> Security Class Initialized
DEBUG - 2018-03-17 13:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-17 13:27:28 --> Input Class Initialized
INFO - 2018-03-17 13:27:28 --> Language Class Initialized
INFO - 2018-03-17 13:27:28 --> Loader Class Initialized
INFO - 2018-03-17 13:27:28 --> Helper loaded: url_helper
INFO - 2018-03-17 13:27:28 --> Helper loaded: form_helper
INFO - 2018-03-17 13:27:28 --> Database Driver Class Initialized
DEBUG - 2018-03-17 13:27:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-17 13:27:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-17 13:27:28 --> Form Validation Class Initialized
INFO - 2018-03-17 13:27:28 --> Model Class Initialized
INFO - 2018-03-17 13:27:28 --> Controller Class Initialized
INFO - 2018-03-17 13:27:28 --> Model Class Initialized
INFO - 2018-03-17 13:27:28 --> Model Class Initialized
INFO - 2018-03-17 13:27:28 --> Model Class Initialized
INFO - 2018-03-17 13:27:28 --> Model Class Initialized
DEBUG - 2018-03-17 13:27:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-17 13:27:28 --> Model Class Initialized
INFO - 2018-03-17 13:27:28 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-17 13:27:28 --> Final output sent to browser
DEBUG - 2018-03-17 13:27:28 --> Total execution time: 0.0491
INFO - 2018-03-17 13:27:29 --> Config Class Initialized
INFO - 2018-03-17 13:27:29 --> Hooks Class Initialized
INFO - 2018-03-17 13:27:29 --> Config Class Initialized
INFO - 2018-03-17 13:27:29 --> Hooks Class Initialized
INFO - 2018-03-17 13:27:29 --> Config Class Initialized
INFO - 2018-03-17 13:27:29 --> Hooks Class Initialized
DEBUG - 2018-03-17 13:27:29 --> UTF-8 Support Enabled
INFO - 2018-03-17 13:27:29 --> Utf8 Class Initialized
DEBUG - 2018-03-17 13:27:29 --> UTF-8 Support Enabled
INFO - 2018-03-17 13:27:29 --> Utf8 Class Initialized
INFO - 2018-03-17 13:27:29 --> Config Class Initialized
INFO - 2018-03-17 13:27:29 --> URI Class Initialized
INFO - 2018-03-17 13:27:29 --> Hooks Class Initialized
INFO - 2018-03-17 13:27:29 --> URI Class Initialized
DEBUG - 2018-03-17 13:27:29 --> UTF-8 Support Enabled
INFO - 2018-03-17 13:27:29 --> Utf8 Class Initialized
INFO - 2018-03-17 13:27:29 --> Router Class Initialized
INFO - 2018-03-17 13:27:29 --> Router Class Initialized
INFO - 2018-03-17 13:27:29 --> URI Class Initialized
DEBUG - 2018-03-17 13:27:29 --> UTF-8 Support Enabled
INFO - 2018-03-17 13:27:29 --> Utf8 Class Initialized
INFO - 2018-03-17 13:27:29 --> Output Class Initialized
INFO - 2018-03-17 13:27:29 --> Router Class Initialized
INFO - 2018-03-17 13:27:29 --> URI Class Initialized
INFO - 2018-03-17 13:27:29 --> Output Class Initialized
INFO - 2018-03-17 13:27:29 --> Security Class Initialized
INFO - 2018-03-17 13:27:29 --> Security Class Initialized
INFO - 2018-03-17 13:27:29 --> Output Class Initialized
INFO - 2018-03-17 13:27:29 --> Router Class Initialized
DEBUG - 2018-03-17 13:27:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-17 13:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-17 13:27:29 --> Input Class Initialized
INFO - 2018-03-17 13:27:29 --> Input Class Initialized
INFO - 2018-03-17 13:27:29 --> Security Class Initialized
INFO - 2018-03-17 13:27:29 --> Language Class Initialized
INFO - 2018-03-17 13:27:29 --> Output Class Initialized
INFO - 2018-03-17 13:27:29 --> Language Class Initialized
DEBUG - 2018-03-17 13:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-17 13:27:29 --> Security Class Initialized
INFO - 2018-03-17 13:27:29 --> Input Class Initialized
ERROR - 2018-03-17 13:27:29 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-17 13:27:29 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-17 13:27:29 --> Language Class Initialized
DEBUG - 2018-03-17 13:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-17 13:27:29 --> Input Class Initialized
ERROR - 2018-03-17 13:27:29 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-17 13:27:29 --> Language Class Initialized
ERROR - 2018-03-17 13:27:29 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-17 13:27:29 --> Config Class Initialized
INFO - 2018-03-17 13:27:29 --> Hooks Class Initialized
INFO - 2018-03-17 13:27:29 --> Config Class Initialized
INFO - 2018-03-17 13:27:29 --> Config Class Initialized
INFO - 2018-03-17 13:27:29 --> Hooks Class Initialized
INFO - 2018-03-17 13:27:29 --> Hooks Class Initialized
DEBUG - 2018-03-17 13:27:29 --> UTF-8 Support Enabled
INFO - 2018-03-17 13:27:29 --> Utf8 Class Initialized
DEBUG - 2018-03-17 13:27:29 --> UTF-8 Support Enabled
DEBUG - 2018-03-17 13:27:29 --> UTF-8 Support Enabled
INFO - 2018-03-17 13:27:29 --> Utf8 Class Initialized
INFO - 2018-03-17 13:27:29 --> URI Class Initialized
INFO - 2018-03-17 13:27:29 --> Utf8 Class Initialized
INFO - 2018-03-17 13:27:29 --> URI Class Initialized
INFO - 2018-03-17 13:27:29 --> URI Class Initialized
INFO - 2018-03-17 13:27:29 --> Router Class Initialized
INFO - 2018-03-17 13:27:29 --> Router Class Initialized
INFO - 2018-03-17 13:27:29 --> Router Class Initialized
INFO - 2018-03-17 13:27:29 --> Output Class Initialized
INFO - 2018-03-17 13:27:29 --> Output Class Initialized
INFO - 2018-03-17 13:27:29 --> Output Class Initialized
INFO - 2018-03-17 13:27:29 --> Security Class Initialized
INFO - 2018-03-17 13:27:29 --> Security Class Initialized
INFO - 2018-03-17 13:27:29 --> Security Class Initialized
DEBUG - 2018-03-17 13:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-17 13:27:29 --> Input Class Initialized
DEBUG - 2018-03-17 13:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-17 13:27:29 --> Input Class Initialized
INFO - 2018-03-17 13:27:29 --> Language Class Initialized
DEBUG - 2018-03-17 13:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-17 13:27:29 --> Input Class Initialized
INFO - 2018-03-17 13:27:29 --> Language Class Initialized
INFO - 2018-03-17 13:27:29 --> Language Class Initialized
ERROR - 2018-03-17 13:27:29 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-17 13:27:29 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-17 13:27:29 --> 404 Page Not Found: Instatec_pub/css
