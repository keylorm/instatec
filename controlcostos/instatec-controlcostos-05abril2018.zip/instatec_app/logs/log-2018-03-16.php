<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-03-16 00:06:52 --> Config Class Initialized
INFO - 2018-03-16 00:06:52 --> Hooks Class Initialized
DEBUG - 2018-03-16 00:06:52 --> UTF-8 Support Enabled
INFO - 2018-03-16 00:06:52 --> Utf8 Class Initialized
INFO - 2018-03-16 00:06:52 --> URI Class Initialized
INFO - 2018-03-16 00:06:52 --> Router Class Initialized
INFO - 2018-03-16 00:06:52 --> Output Class Initialized
INFO - 2018-03-16 00:06:52 --> Security Class Initialized
DEBUG - 2018-03-16 00:06:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 00:06:52 --> Input Class Initialized
INFO - 2018-03-16 00:06:52 --> Language Class Initialized
INFO - 2018-03-16 00:06:52 --> Loader Class Initialized
INFO - 2018-03-16 00:06:52 --> Helper loaded: url_helper
INFO - 2018-03-16 00:06:52 --> Helper loaded: form_helper
INFO - 2018-03-16 00:06:52 --> Database Driver Class Initialized
DEBUG - 2018-03-16 00:06:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-16 00:06:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-16 00:06:52 --> Form Validation Class Initialized
INFO - 2018-03-16 00:06:52 --> Model Class Initialized
INFO - 2018-03-16 00:06:52 --> Controller Class Initialized
INFO - 2018-03-16 00:06:52 --> Model Class Initialized
INFO - 2018-03-16 00:06:52 --> Model Class Initialized
INFO - 2018-03-16 00:06:52 --> Model Class Initialized
INFO - 2018-03-16 00:06:52 --> Model Class Initialized
DEBUG - 2018-03-16 00:06:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-16 00:06:52 --> Config Class Initialized
INFO - 2018-03-16 00:06:52 --> Hooks Class Initialized
DEBUG - 2018-03-16 00:06:52 --> UTF-8 Support Enabled
INFO - 2018-03-16 00:06:52 --> Utf8 Class Initialized
INFO - 2018-03-16 00:06:52 --> URI Class Initialized
INFO - 2018-03-16 00:06:52 --> Router Class Initialized
INFO - 2018-03-16 00:06:52 --> Output Class Initialized
INFO - 2018-03-16 00:06:52 --> Security Class Initialized
DEBUG - 2018-03-16 00:06:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 00:06:52 --> Input Class Initialized
INFO - 2018-03-16 00:06:52 --> Language Class Initialized
INFO - 2018-03-16 00:06:52 --> Loader Class Initialized
INFO - 2018-03-16 00:06:52 --> Helper loaded: url_helper
INFO - 2018-03-16 00:06:52 --> Helper loaded: form_helper
INFO - 2018-03-16 00:06:52 --> Database Driver Class Initialized
DEBUG - 2018-03-16 00:06:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-16 00:06:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-16 00:06:52 --> Form Validation Class Initialized
INFO - 2018-03-16 00:06:52 --> Model Class Initialized
INFO - 2018-03-16 00:06:52 --> Controller Class Initialized
INFO - 2018-03-16 00:06:52 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-16 00:06:52 --> Final output sent to browser
DEBUG - 2018-03-16 00:06:52 --> Total execution time: 0.0823
INFO - 2018-03-16 00:08:10 --> Config Class Initialized
INFO - 2018-03-16 00:08:10 --> Hooks Class Initialized
DEBUG - 2018-03-16 00:08:10 --> UTF-8 Support Enabled
INFO - 2018-03-16 00:08:10 --> Utf8 Class Initialized
INFO - 2018-03-16 00:08:10 --> URI Class Initialized
INFO - 2018-03-16 00:08:10 --> Router Class Initialized
INFO - 2018-03-16 00:08:10 --> Output Class Initialized
INFO - 2018-03-16 00:08:10 --> Security Class Initialized
DEBUG - 2018-03-16 00:08:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 00:08:10 --> Input Class Initialized
INFO - 2018-03-16 00:08:10 --> Language Class Initialized
INFO - 2018-03-16 00:08:10 --> Loader Class Initialized
INFO - 2018-03-16 00:08:10 --> Helper loaded: url_helper
INFO - 2018-03-16 00:08:10 --> Helper loaded: form_helper
INFO - 2018-03-16 00:08:10 --> Database Driver Class Initialized
DEBUG - 2018-03-16 00:08:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-16 00:08:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-16 00:08:10 --> Form Validation Class Initialized
INFO - 2018-03-16 00:08:10 --> Model Class Initialized
INFO - 2018-03-16 00:08:10 --> Controller Class Initialized
INFO - 2018-03-16 00:08:10 --> Model Class Initialized
INFO - 2018-03-16 00:08:10 --> Model Class Initialized
DEBUG - 2018-03-16 00:08:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-16 00:08:10 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-16 00:08:10 --> Final output sent to browser
DEBUG - 2018-03-16 00:08:10 --> Total execution time: 0.1176
INFO - 2018-03-16 00:08:11 --> Config Class Initialized
INFO - 2018-03-16 00:08:11 --> Hooks Class Initialized
DEBUG - 2018-03-16 00:08:11 --> UTF-8 Support Enabled
INFO - 2018-03-16 00:08:11 --> Utf8 Class Initialized
INFO - 2018-03-16 00:08:11 --> URI Class Initialized
INFO - 2018-03-16 00:08:11 --> Router Class Initialized
INFO - 2018-03-16 00:08:11 --> Output Class Initialized
INFO - 2018-03-16 00:08:11 --> Security Class Initialized
DEBUG - 2018-03-16 00:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 00:08:11 --> Input Class Initialized
INFO - 2018-03-16 00:08:11 --> Language Class Initialized
INFO - 2018-03-16 00:08:11 --> Loader Class Initialized
INFO - 2018-03-16 00:08:11 --> Helper loaded: url_helper
INFO - 2018-03-16 00:08:11 --> Helper loaded: form_helper
INFO - 2018-03-16 00:08:11 --> Database Driver Class Initialized
DEBUG - 2018-03-16 00:08:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-16 00:08:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-16 00:08:11 --> Form Validation Class Initialized
INFO - 2018-03-16 00:08:11 --> Model Class Initialized
INFO - 2018-03-16 00:08:11 --> Controller Class Initialized
INFO - 2018-03-16 00:08:11 --> Model Class Initialized
INFO - 2018-03-16 00:08:11 --> Model Class Initialized
DEBUG - 2018-03-16 00:08:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-16 00:08:11 --> Config Class Initialized
INFO - 2018-03-16 00:08:11 --> Hooks Class Initialized
DEBUG - 2018-03-16 00:08:11 --> UTF-8 Support Enabled
INFO - 2018-03-16 00:08:11 --> Utf8 Class Initialized
INFO - 2018-03-16 00:08:11 --> URI Class Initialized
INFO - 2018-03-16 00:08:11 --> Router Class Initialized
INFO - 2018-03-16 00:08:11 --> Output Class Initialized
INFO - 2018-03-16 00:08:11 --> Security Class Initialized
DEBUG - 2018-03-16 00:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 00:08:11 --> Input Class Initialized
INFO - 2018-03-16 00:08:11 --> Language Class Initialized
INFO - 2018-03-16 00:08:11 --> Loader Class Initialized
INFO - 2018-03-16 00:08:11 --> Helper loaded: url_helper
INFO - 2018-03-16 00:08:11 --> Helper loaded: form_helper
INFO - 2018-03-16 00:08:11 --> Database Driver Class Initialized
DEBUG - 2018-03-16 00:08:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-16 00:08:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-16 00:08:11 --> Form Validation Class Initialized
INFO - 2018-03-16 00:08:11 --> Model Class Initialized
INFO - 2018-03-16 00:08:11 --> Controller Class Initialized
INFO - 2018-03-16 00:08:11 --> Model Class Initialized
INFO - 2018-03-16 00:08:11 --> Model Class Initialized
INFO - 2018-03-16 00:08:11 --> Model Class Initialized
INFO - 2018-03-16 00:08:11 --> Model Class Initialized
DEBUG - 2018-03-16 00:08:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-16 00:08:11 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-16 00:08:11 --> Final output sent to browser
DEBUG - 2018-03-16 00:08:11 --> Total execution time: 0.0584
INFO - 2018-03-16 00:08:12 --> Config Class Initialized
INFO - 2018-03-16 00:08:12 --> Hooks Class Initialized
DEBUG - 2018-03-16 00:08:12 --> UTF-8 Support Enabled
INFO - 2018-03-16 00:08:12 --> Utf8 Class Initialized
INFO - 2018-03-16 00:08:12 --> URI Class Initialized
INFO - 2018-03-16 00:08:12 --> Router Class Initialized
INFO - 2018-03-16 00:08:12 --> Output Class Initialized
INFO - 2018-03-16 00:08:12 --> Security Class Initialized
DEBUG - 2018-03-16 00:08:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 00:08:12 --> Input Class Initialized
INFO - 2018-03-16 00:08:12 --> Language Class Initialized
INFO - 2018-03-16 00:08:12 --> Loader Class Initialized
INFO - 2018-03-16 00:08:12 --> Helper loaded: url_helper
INFO - 2018-03-16 00:08:12 --> Helper loaded: form_helper
INFO - 2018-03-16 00:08:12 --> Database Driver Class Initialized
DEBUG - 2018-03-16 00:08:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-16 00:08:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-16 00:08:12 --> Form Validation Class Initialized
INFO - 2018-03-16 00:08:12 --> Model Class Initialized
INFO - 2018-03-16 00:08:12 --> Controller Class Initialized
INFO - 2018-03-16 00:08:12 --> Model Class Initialized
INFO - 2018-03-16 00:08:12 --> Model Class Initialized
INFO - 2018-03-16 00:08:12 --> Model Class Initialized
INFO - 2018-03-16 00:08:12 --> Model Class Initialized
DEBUG - 2018-03-16 00:08:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-16 00:08:12 --> Model Class Initialized
INFO - 2018-03-16 00:08:12 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-16 00:08:12 --> Final output sent to browser
DEBUG - 2018-03-16 00:08:12 --> Total execution time: 0.0588
INFO - 2018-03-16 00:08:12 --> Config Class Initialized
INFO - 2018-03-16 00:08:12 --> Hooks Class Initialized
DEBUG - 2018-03-16 00:08:12 --> UTF-8 Support Enabled
INFO - 2018-03-16 00:08:12 --> Utf8 Class Initialized
INFO - 2018-03-16 00:08:12 --> URI Class Initialized
INFO - 2018-03-16 00:08:12 --> Router Class Initialized
INFO - 2018-03-16 00:08:12 --> Output Class Initialized
INFO - 2018-03-16 00:08:12 --> Security Class Initialized
DEBUG - 2018-03-16 00:08:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 00:08:12 --> Input Class Initialized
INFO - 2018-03-16 00:08:12 --> Language Class Initialized
INFO - 2018-03-16 00:08:12 --> Loader Class Initialized
INFO - 2018-03-16 00:08:12 --> Helper loaded: url_helper
INFO - 2018-03-16 00:08:12 --> Helper loaded: form_helper
INFO - 2018-03-16 00:08:12 --> Database Driver Class Initialized
DEBUG - 2018-03-16 00:08:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-16 00:08:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-16 00:08:12 --> Form Validation Class Initialized
INFO - 2018-03-16 00:08:12 --> Model Class Initialized
INFO - 2018-03-16 00:08:12 --> Controller Class Initialized
INFO - 2018-03-16 00:08:12 --> Model Class Initialized
INFO - 2018-03-16 00:08:12 --> Model Class Initialized
DEBUG - 2018-03-16 00:08:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-16 00:08:17 --> Config Class Initialized
INFO - 2018-03-16 00:08:17 --> Hooks Class Initialized
DEBUG - 2018-03-16 00:08:17 --> UTF-8 Support Enabled
INFO - 2018-03-16 00:08:17 --> Utf8 Class Initialized
INFO - 2018-03-16 00:08:17 --> URI Class Initialized
INFO - 2018-03-16 00:08:17 --> Router Class Initialized
INFO - 2018-03-16 00:08:17 --> Output Class Initialized
INFO - 2018-03-16 00:08:17 --> Security Class Initialized
DEBUG - 2018-03-16 00:08:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 00:08:17 --> Input Class Initialized
INFO - 2018-03-16 00:08:17 --> Language Class Initialized
INFO - 2018-03-16 00:08:17 --> Loader Class Initialized
INFO - 2018-03-16 00:08:17 --> Helper loaded: url_helper
INFO - 2018-03-16 00:08:17 --> Helper loaded: form_helper
INFO - 2018-03-16 00:08:17 --> Database Driver Class Initialized
DEBUG - 2018-03-16 00:08:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-16 00:08:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-16 00:08:17 --> Form Validation Class Initialized
INFO - 2018-03-16 00:08:17 --> Model Class Initialized
INFO - 2018-03-16 00:08:17 --> Controller Class Initialized
INFO - 2018-03-16 00:08:17 --> Model Class Initialized
INFO - 2018-03-16 00:08:17 --> Model Class Initialized
INFO - 2018-03-16 00:08:17 --> Model Class Initialized
INFO - 2018-03-16 00:08:17 --> Model Class Initialized
DEBUG - 2018-03-16 00:08:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-16 00:08:17 --> Model Class Initialized
INFO - 2018-03-16 00:08:17 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-16 00:08:17 --> Final output sent to browser
DEBUG - 2018-03-16 00:08:17 --> Total execution time: 0.0553
INFO - 2018-03-16 00:09:15 --> Config Class Initialized
INFO - 2018-03-16 00:09:15 --> Hooks Class Initialized
DEBUG - 2018-03-16 00:09:15 --> UTF-8 Support Enabled
INFO - 2018-03-16 00:09:15 --> Utf8 Class Initialized
INFO - 2018-03-16 00:09:15 --> URI Class Initialized
INFO - 2018-03-16 00:09:15 --> Router Class Initialized
INFO - 2018-03-16 00:09:15 --> Output Class Initialized
INFO - 2018-03-16 00:09:15 --> Security Class Initialized
DEBUG - 2018-03-16 00:09:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 00:09:15 --> Input Class Initialized
INFO - 2018-03-16 00:09:15 --> Language Class Initialized
INFO - 2018-03-16 00:09:15 --> Loader Class Initialized
INFO - 2018-03-16 00:09:15 --> Helper loaded: url_helper
INFO - 2018-03-16 00:09:15 --> Helper loaded: form_helper
INFO - 2018-03-16 00:09:15 --> Database Driver Class Initialized
DEBUG - 2018-03-16 00:09:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-16 00:09:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-16 00:09:15 --> Form Validation Class Initialized
INFO - 2018-03-16 00:09:15 --> Model Class Initialized
INFO - 2018-03-16 00:09:15 --> Controller Class Initialized
INFO - 2018-03-16 00:09:15 --> Model Class Initialized
INFO - 2018-03-16 00:09:15 --> Model Class Initialized
INFO - 2018-03-16 00:09:15 --> Model Class Initialized
INFO - 2018-03-16 00:09:15 --> Model Class Initialized
DEBUG - 2018-03-16 00:09:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-16 00:09:15 --> Model Class Initialized
INFO - 2018-03-16 00:09:15 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-16 00:09:15 --> Final output sent to browser
DEBUG - 2018-03-16 00:09:15 --> Total execution time: 0.0821
