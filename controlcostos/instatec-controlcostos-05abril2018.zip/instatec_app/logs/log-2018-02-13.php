<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-02-13 06:41:07 --> Config Class Initialized
INFO - 2018-02-13 06:41:07 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:41:08 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:41:08 --> Utf8 Class Initialized
INFO - 2018-02-13 06:41:08 --> URI Class Initialized
INFO - 2018-02-13 06:41:08 --> Router Class Initialized
INFO - 2018-02-13 06:41:08 --> Output Class Initialized
INFO - 2018-02-13 06:41:08 --> Security Class Initialized
DEBUG - 2018-02-13 06:41:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:41:08 --> Input Class Initialized
INFO - 2018-02-13 06:41:09 --> Language Class Initialized
INFO - 2018-02-13 06:41:09 --> Loader Class Initialized
INFO - 2018-02-13 06:41:09 --> Helper loaded: url_helper
INFO - 2018-02-13 06:41:09 --> Helper loaded: form_helper
INFO - 2018-02-13 06:41:09 --> Database Driver Class Initialized
DEBUG - 2018-02-13 06:41:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 06:41:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:41:09 --> Form Validation Class Initialized
INFO - 2018-02-13 06:41:09 --> Model Class Initialized
INFO - 2018-02-13 06:41:09 --> Controller Class Initialized
INFO - 2018-02-13 06:41:09 --> Model Class Initialized
INFO - 2018-02-13 06:41:09 --> Model Class Initialized
DEBUG - 2018-02-13 06:41:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 06:41:09 --> Config Class Initialized
INFO - 2018-02-13 06:41:09 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:41:09 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:41:09 --> Utf8 Class Initialized
INFO - 2018-02-13 06:41:09 --> URI Class Initialized
INFO - 2018-02-13 06:41:09 --> Router Class Initialized
INFO - 2018-02-13 06:41:09 --> Output Class Initialized
INFO - 2018-02-13 06:41:09 --> Security Class Initialized
DEBUG - 2018-02-13 06:41:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:41:09 --> Input Class Initialized
INFO - 2018-02-13 06:41:09 --> Language Class Initialized
INFO - 2018-02-13 06:41:09 --> Loader Class Initialized
INFO - 2018-02-13 06:41:09 --> Helper loaded: url_helper
INFO - 2018-02-13 06:41:09 --> Helper loaded: form_helper
INFO - 2018-02-13 06:41:09 --> Database Driver Class Initialized
DEBUG - 2018-02-13 06:41:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 06:41:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:41:09 --> Form Validation Class Initialized
INFO - 2018-02-13 06:41:09 --> Model Class Initialized
INFO - 2018-02-13 06:41:09 --> Controller Class Initialized
INFO - 2018-02-13 06:41:09 --> Model Class Initialized
DEBUG - 2018-02-13 06:41:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 06:41:09 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 06:41:09 --> Final output sent to browser
DEBUG - 2018-02-13 06:41:09 --> Total execution time: 0.0590
INFO - 2018-02-13 06:41:09 --> Config Class Initialized
INFO - 2018-02-13 06:41:09 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:41:09 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:41:09 --> Utf8 Class Initialized
INFO - 2018-02-13 06:41:09 --> URI Class Initialized
INFO - 2018-02-13 06:41:09 --> Config Class Initialized
INFO - 2018-02-13 06:41:09 --> Hooks Class Initialized
INFO - 2018-02-13 06:41:09 --> Router Class Initialized
INFO - 2018-02-13 06:41:09 --> Config Class Initialized
INFO - 2018-02-13 06:41:09 --> Output Class Initialized
INFO - 2018-02-13 06:41:09 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:41:09 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:41:09 --> Utf8 Class Initialized
INFO - 2018-02-13 06:41:09 --> Security Class Initialized
INFO - 2018-02-13 06:41:09 --> URI Class Initialized
INFO - 2018-02-13 06:41:09 --> Config Class Initialized
INFO - 2018-02-13 06:41:09 --> Config Class Initialized
DEBUG - 2018-02-13 06:41:09 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:41:09 --> Hooks Class Initialized
INFO - 2018-02-13 06:41:09 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:41:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:41:09 --> Utf8 Class Initialized
INFO - 2018-02-13 06:41:09 --> Input Class Initialized
INFO - 2018-02-13 06:41:09 --> URI Class Initialized
INFO - 2018-02-13 06:41:09 --> Router Class Initialized
INFO - 2018-02-13 06:41:09 --> Language Class Initialized
INFO - 2018-02-13 06:41:09 --> Config Class Initialized
INFO - 2018-02-13 06:41:09 --> Hooks Class Initialized
INFO - 2018-02-13 06:41:09 --> Router Class Initialized
DEBUG - 2018-02-13 06:41:09 --> UTF-8 Support Enabled
ERROR - 2018-02-13 06:41:09 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-13 06:41:09 --> Utf8 Class Initialized
INFO - 2018-02-13 06:41:09 --> Output Class Initialized
INFO - 2018-02-13 06:41:09 --> Output Class Initialized
INFO - 2018-02-13 06:41:09 --> URI Class Initialized
INFO - 2018-02-13 06:41:09 --> Security Class Initialized
DEBUG - 2018-02-13 06:41:09 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:41:09 --> Utf8 Class Initialized
INFO - 2018-02-13 06:41:09 --> Router Class Initialized
INFO - 2018-02-13 06:41:09 --> Security Class Initialized
INFO - 2018-02-13 06:41:09 --> URI Class Initialized
INFO - 2018-02-13 06:41:09 --> Output Class Initialized
DEBUG - 2018-02-13 06:41:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:41:09 --> Input Class Initialized
INFO - 2018-02-13 06:41:09 --> Security Class Initialized
INFO - 2018-02-13 06:41:09 --> Language Class Initialized
INFO - 2018-02-13 06:41:09 --> Router Class Initialized
DEBUG - 2018-02-13 06:41:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:41:09 --> Input Class Initialized
ERROR - 2018-02-13 06:41:09 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-13 06:41:09 --> Output Class Initialized
INFO - 2018-02-13 06:41:09 --> Language Class Initialized
ERROR - 2018-02-13 06:41:09 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-13 06:41:09 --> Config Class Initialized
INFO - 2018-02-13 06:41:09 --> Security Class Initialized
INFO - 2018-02-13 06:41:09 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:41:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 06:41:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:41:09 --> Input Class Initialized
INFO - 2018-02-13 06:41:09 --> Input Class Initialized
INFO - 2018-02-13 06:41:09 --> Language Class Initialized
INFO - 2018-02-13 06:41:09 --> Language Class Initialized
DEBUG - 2018-02-13 06:41:09 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:41:09 --> Utf8 Class Initialized
DEBUG - 2018-02-13 06:41:09 --> UTF-8 Support Enabled
ERROR - 2018-02-13 06:41:09 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-13 06:41:09 --> Utf8 Class Initialized
ERROR - 2018-02-13 06:41:09 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-13 06:41:09 --> URI Class Initialized
INFO - 2018-02-13 06:41:09 --> URI Class Initialized
INFO - 2018-02-13 06:41:09 --> Router Class Initialized
INFO - 2018-02-13 06:41:09 --> Router Class Initialized
INFO - 2018-02-13 06:41:09 --> Output Class Initialized
INFO - 2018-02-13 06:41:09 --> Output Class Initialized
INFO - 2018-02-13 06:41:09 --> Security Class Initialized
INFO - 2018-02-13 06:41:09 --> Security Class Initialized
DEBUG - 2018-02-13 06:41:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:41:09 --> Input Class Initialized
INFO - 2018-02-13 06:41:09 --> Language Class Initialized
DEBUG - 2018-02-13 06:41:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:41:09 --> Input Class Initialized
INFO - 2018-02-13 06:41:09 --> Language Class Initialized
ERROR - 2018-02-13 06:41:09 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-13 06:41:09 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-13 06:41:11 --> Config Class Initialized
INFO - 2018-02-13 06:41:11 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:41:11 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:41:11 --> Utf8 Class Initialized
INFO - 2018-02-13 06:41:11 --> URI Class Initialized
INFO - 2018-02-13 06:41:11 --> Router Class Initialized
INFO - 2018-02-13 06:41:11 --> Output Class Initialized
INFO - 2018-02-13 06:41:11 --> Security Class Initialized
DEBUG - 2018-02-13 06:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:41:11 --> Input Class Initialized
INFO - 2018-02-13 06:41:11 --> Language Class Initialized
INFO - 2018-02-13 06:41:11 --> Loader Class Initialized
INFO - 2018-02-13 06:41:11 --> Helper loaded: url_helper
INFO - 2018-02-13 06:41:11 --> Helper loaded: form_helper
INFO - 2018-02-13 06:41:11 --> Database Driver Class Initialized
DEBUG - 2018-02-13 06:41:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 06:41:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:41:11 --> Form Validation Class Initialized
INFO - 2018-02-13 06:41:11 --> Model Class Initialized
INFO - 2018-02-13 06:41:11 --> Controller Class Initialized
INFO - 2018-02-13 06:41:11 --> Model Class Initialized
DEBUG - 2018-02-13 06:41:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 06:41:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-13 06:41:11 --> Config Class Initialized
INFO - 2018-02-13 06:41:11 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:41:11 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:41:11 --> Utf8 Class Initialized
INFO - 2018-02-13 06:41:11 --> URI Class Initialized
DEBUG - 2018-02-13 06:41:11 --> No URI present. Default controller set.
INFO - 2018-02-13 06:41:11 --> Router Class Initialized
INFO - 2018-02-13 06:41:11 --> Output Class Initialized
INFO - 2018-02-13 06:41:11 --> Security Class Initialized
DEBUG - 2018-02-13 06:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:41:11 --> Input Class Initialized
INFO - 2018-02-13 06:41:11 --> Language Class Initialized
INFO - 2018-02-13 06:41:11 --> Loader Class Initialized
INFO - 2018-02-13 06:41:11 --> Helper loaded: url_helper
INFO - 2018-02-13 06:41:11 --> Helper loaded: form_helper
INFO - 2018-02-13 06:41:11 --> Database Driver Class Initialized
DEBUG - 2018-02-13 06:41:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 06:41:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:41:11 --> Form Validation Class Initialized
INFO - 2018-02-13 06:41:11 --> Model Class Initialized
INFO - 2018-02-13 06:41:11 --> Controller Class Initialized
INFO - 2018-02-13 06:41:11 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 06:41:11 --> Final output sent to browser
DEBUG - 2018-02-13 06:41:11 --> Total execution time: 0.1061
INFO - 2018-02-13 06:41:11 --> Config Class Initialized
INFO - 2018-02-13 06:41:11 --> Hooks Class Initialized
INFO - 2018-02-13 06:41:11 --> Config Class Initialized
INFO - 2018-02-13 06:41:11 --> Hooks Class Initialized
INFO - 2018-02-13 06:41:11 --> Config Class Initialized
INFO - 2018-02-13 06:41:11 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:41:11 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:41:11 --> Utf8 Class Initialized
INFO - 2018-02-13 06:41:11 --> Config Class Initialized
INFO - 2018-02-13 06:41:11 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:41:11 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:41:11 --> URI Class Initialized
INFO - 2018-02-13 06:41:11 --> Utf8 Class Initialized
DEBUG - 2018-02-13 06:41:11 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:41:11 --> Utf8 Class Initialized
INFO - 2018-02-13 06:41:11 --> URI Class Initialized
DEBUG - 2018-02-13 06:41:11 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:41:11 --> Router Class Initialized
INFO - 2018-02-13 06:41:11 --> URI Class Initialized
INFO - 2018-02-13 06:41:11 --> Utf8 Class Initialized
INFO - 2018-02-13 06:41:11 --> Router Class Initialized
INFO - 2018-02-13 06:41:11 --> URI Class Initialized
INFO - 2018-02-13 06:41:11 --> Router Class Initialized
INFO - 2018-02-13 06:41:11 --> Output Class Initialized
INFO - 2018-02-13 06:41:11 --> Output Class Initialized
INFO - 2018-02-13 06:41:11 --> Router Class Initialized
INFO - 2018-02-13 06:41:11 --> Output Class Initialized
INFO - 2018-02-13 06:41:11 --> Security Class Initialized
INFO - 2018-02-13 06:41:11 --> Security Class Initialized
INFO - 2018-02-13 06:41:11 --> Security Class Initialized
DEBUG - 2018-02-13 06:41:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 06:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:41:11 --> Output Class Initialized
INFO - 2018-02-13 06:41:11 --> Input Class Initialized
INFO - 2018-02-13 06:41:11 --> Input Class Initialized
DEBUG - 2018-02-13 06:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:41:11 --> Input Class Initialized
INFO - 2018-02-13 06:41:11 --> Language Class Initialized
INFO - 2018-02-13 06:41:11 --> Language Class Initialized
INFO - 2018-02-13 06:41:11 --> Security Class Initialized
INFO - 2018-02-13 06:41:11 --> Language Class Initialized
ERROR - 2018-02-13 06:41:11 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-13 06:41:11 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-02-13 06:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:41:11 --> Input Class Initialized
ERROR - 2018-02-13 06:41:11 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-13 06:41:11 --> Language Class Initialized
ERROR - 2018-02-13 06:41:11 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-13 06:41:11 --> Config Class Initialized
INFO - 2018-02-13 06:41:11 --> Hooks Class Initialized
INFO - 2018-02-13 06:41:11 --> Config Class Initialized
INFO - 2018-02-13 06:41:11 --> Config Class Initialized
INFO - 2018-02-13 06:41:11 --> Hooks Class Initialized
INFO - 2018-02-13 06:41:11 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:41:11 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:41:11 --> Utf8 Class Initialized
INFO - 2018-02-13 06:41:11 --> URI Class Initialized
DEBUG - 2018-02-13 06:41:11 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:41:11 --> Utf8 Class Initialized
DEBUG - 2018-02-13 06:41:11 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:41:11 --> Utf8 Class Initialized
INFO - 2018-02-13 06:41:11 --> Router Class Initialized
INFO - 2018-02-13 06:41:11 --> URI Class Initialized
INFO - 2018-02-13 06:41:11 --> URI Class Initialized
INFO - 2018-02-13 06:41:11 --> Output Class Initialized
INFO - 2018-02-13 06:41:11 --> Router Class Initialized
INFO - 2018-02-13 06:41:11 --> Router Class Initialized
INFO - 2018-02-13 06:41:11 --> Security Class Initialized
INFO - 2018-02-13 06:41:11 --> Output Class Initialized
DEBUG - 2018-02-13 06:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:41:11 --> Input Class Initialized
INFO - 2018-02-13 06:41:11 --> Output Class Initialized
INFO - 2018-02-13 06:41:11 --> Security Class Initialized
INFO - 2018-02-13 06:41:11 --> Language Class Initialized
INFO - 2018-02-13 06:41:11 --> Security Class Initialized
DEBUG - 2018-02-13 06:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:41:11 --> Input Class Initialized
ERROR - 2018-02-13 06:41:11 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-13 06:41:11 --> Language Class Initialized
DEBUG - 2018-02-13 06:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:41:11 --> Input Class Initialized
ERROR - 2018-02-13 06:41:11 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-13 06:41:11 --> Language Class Initialized
ERROR - 2018-02-13 06:41:11 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-13 06:41:11 --> Config Class Initialized
INFO - 2018-02-13 06:41:11 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:41:11 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:41:11 --> Utf8 Class Initialized
INFO - 2018-02-13 06:41:11 --> URI Class Initialized
INFO - 2018-02-13 06:41:11 --> Router Class Initialized
INFO - 2018-02-13 06:41:11 --> Output Class Initialized
INFO - 2018-02-13 06:41:11 --> Security Class Initialized
DEBUG - 2018-02-13 06:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:41:11 --> Input Class Initialized
INFO - 2018-02-13 06:41:11 --> Language Class Initialized
INFO - 2018-02-13 06:41:11 --> Loader Class Initialized
INFO - 2018-02-13 06:41:11 --> Helper loaded: url_helper
INFO - 2018-02-13 06:41:11 --> Helper loaded: form_helper
INFO - 2018-02-13 06:41:11 --> Database Driver Class Initialized
DEBUG - 2018-02-13 06:41:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 06:41:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:41:11 --> Form Validation Class Initialized
INFO - 2018-02-13 06:41:11 --> Model Class Initialized
INFO - 2018-02-13 06:41:11 --> Controller Class Initialized
INFO - 2018-02-13 06:41:11 --> Model Class Initialized
INFO - 2018-02-13 06:41:11 --> Model Class Initialized
INFO - 2018-02-13 06:41:11 --> Model Class Initialized
INFO - 2018-02-13 06:41:11 --> Model Class Initialized
INFO - 2018-02-13 06:41:11 --> Model Class Initialized
DEBUG - 2018-02-13 06:41:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 06:41:14 --> Config Class Initialized
INFO - 2018-02-13 06:41:14 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:41:14 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:41:14 --> Utf8 Class Initialized
INFO - 2018-02-13 06:41:14 --> URI Class Initialized
INFO - 2018-02-13 06:41:14 --> Router Class Initialized
INFO - 2018-02-13 06:41:14 --> Output Class Initialized
INFO - 2018-02-13 06:41:14 --> Security Class Initialized
DEBUG - 2018-02-13 06:41:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:41:14 --> Input Class Initialized
INFO - 2018-02-13 06:41:14 --> Language Class Initialized
INFO - 2018-02-13 06:41:14 --> Loader Class Initialized
INFO - 2018-02-13 06:41:14 --> Helper loaded: url_helper
INFO - 2018-02-13 06:41:14 --> Helper loaded: form_helper
INFO - 2018-02-13 06:41:14 --> Database Driver Class Initialized
DEBUG - 2018-02-13 06:41:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 06:41:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:41:14 --> Form Validation Class Initialized
INFO - 2018-02-13 06:41:14 --> Model Class Initialized
INFO - 2018-02-13 06:41:14 --> Controller Class Initialized
INFO - 2018-02-13 06:41:14 --> Model Class Initialized
INFO - 2018-02-13 06:41:14 --> Model Class Initialized
INFO - 2018-02-13 06:41:14 --> Model Class Initialized
INFO - 2018-02-13 06:41:14 --> Model Class Initialized
INFO - 2018-02-13 06:41:14 --> Model Class Initialized
DEBUG - 2018-02-13 06:41:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 06:41:14 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 06:41:14 --> Final output sent to browser
DEBUG - 2018-02-13 06:41:14 --> Total execution time: 0.1104
INFO - 2018-02-13 06:41:14 --> Config Class Initialized
INFO - 2018-02-13 06:41:14 --> Hooks Class Initialized
INFO - 2018-02-13 06:41:14 --> Config Class Initialized
INFO - 2018-02-13 06:41:14 --> Hooks Class Initialized
INFO - 2018-02-13 06:41:14 --> Config Class Initialized
DEBUG - 2018-02-13 06:41:14 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:41:14 --> Utf8 Class Initialized
INFO - 2018-02-13 06:41:14 --> Hooks Class Initialized
INFO - 2018-02-13 06:41:14 --> URI Class Initialized
INFO - 2018-02-13 06:41:14 --> Config Class Initialized
DEBUG - 2018-02-13 06:41:14 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:41:14 --> Hooks Class Initialized
INFO - 2018-02-13 06:41:14 --> Utf8 Class Initialized
DEBUG - 2018-02-13 06:41:14 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:41:14 --> Router Class Initialized
INFO - 2018-02-13 06:41:14 --> Utf8 Class Initialized
INFO - 2018-02-13 06:41:14 --> URI Class Initialized
INFO - 2018-02-13 06:41:14 --> URI Class Initialized
DEBUG - 2018-02-13 06:41:14 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:41:14 --> Output Class Initialized
INFO - 2018-02-13 06:41:14 --> Router Class Initialized
INFO - 2018-02-13 06:41:14 --> Utf8 Class Initialized
INFO - 2018-02-13 06:41:14 --> Router Class Initialized
INFO - 2018-02-13 06:41:14 --> URI Class Initialized
INFO - 2018-02-13 06:41:14 --> Security Class Initialized
INFO - 2018-02-13 06:41:14 --> Output Class Initialized
DEBUG - 2018-02-13 06:41:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:41:14 --> Input Class Initialized
INFO - 2018-02-13 06:41:14 --> Output Class Initialized
INFO - 2018-02-13 06:41:14 --> Router Class Initialized
INFO - 2018-02-13 06:41:14 --> Security Class Initialized
INFO - 2018-02-13 06:41:14 --> Language Class Initialized
INFO - 2018-02-13 06:41:14 --> Security Class Initialized
DEBUG - 2018-02-13 06:41:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:41:14 --> Input Class Initialized
INFO - 2018-02-13 06:41:14 --> Output Class Initialized
ERROR - 2018-02-13 06:41:14 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-13 06:41:14 --> Language Class Initialized
DEBUG - 2018-02-13 06:41:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:41:14 --> Input Class Initialized
INFO - 2018-02-13 06:41:14 --> Security Class Initialized
INFO - 2018-02-13 06:41:14 --> Language Class Initialized
ERROR - 2018-02-13 06:41:14 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-02-13 06:41:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:41:14 --> Input Class Initialized
ERROR - 2018-02-13 06:41:14 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-13 06:41:14 --> Language Class Initialized
ERROR - 2018-02-13 06:41:14 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-13 06:41:14 --> Config Class Initialized
INFO - 2018-02-13 06:41:14 --> Config Class Initialized
INFO - 2018-02-13 06:41:14 --> Hooks Class Initialized
INFO - 2018-02-13 06:41:14 --> Config Class Initialized
INFO - 2018-02-13 06:41:14 --> Hooks Class Initialized
INFO - 2018-02-13 06:41:14 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:41:14 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:41:14 --> Utf8 Class Initialized
DEBUG - 2018-02-13 06:41:14 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:41:14 --> Utf8 Class Initialized
DEBUG - 2018-02-13 06:41:14 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:41:14 --> Utf8 Class Initialized
INFO - 2018-02-13 06:41:14 --> URI Class Initialized
INFO - 2018-02-13 06:41:14 --> URI Class Initialized
INFO - 2018-02-13 06:41:14 --> URI Class Initialized
INFO - 2018-02-13 06:41:14 --> Router Class Initialized
INFO - 2018-02-13 06:41:14 --> Router Class Initialized
INFO - 2018-02-13 06:41:14 --> Router Class Initialized
INFO - 2018-02-13 06:41:14 --> Output Class Initialized
INFO - 2018-02-13 06:41:14 --> Security Class Initialized
INFO - 2018-02-13 06:41:14 --> Output Class Initialized
INFO - 2018-02-13 06:41:14 --> Output Class Initialized
DEBUG - 2018-02-13 06:41:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:41:14 --> Security Class Initialized
INFO - 2018-02-13 06:41:14 --> Security Class Initialized
INFO - 2018-02-13 06:41:14 --> Input Class Initialized
INFO - 2018-02-13 06:41:14 --> Language Class Initialized
DEBUG - 2018-02-13 06:41:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 06:41:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:41:14 --> Input Class Initialized
INFO - 2018-02-13 06:41:14 --> Input Class Initialized
ERROR - 2018-02-13 06:41:14 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-13 06:41:14 --> Language Class Initialized
INFO - 2018-02-13 06:41:14 --> Language Class Initialized
ERROR - 2018-02-13 06:41:14 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-13 06:41:14 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-13 06:41:14 --> Config Class Initialized
INFO - 2018-02-13 06:41:14 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:41:14 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:41:14 --> Utf8 Class Initialized
INFO - 2018-02-13 06:41:14 --> URI Class Initialized
INFO - 2018-02-13 06:41:14 --> Router Class Initialized
INFO - 2018-02-13 06:41:14 --> Output Class Initialized
INFO - 2018-02-13 06:41:14 --> Security Class Initialized
DEBUG - 2018-02-13 06:41:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:41:14 --> Input Class Initialized
INFO - 2018-02-13 06:41:14 --> Language Class Initialized
INFO - 2018-02-13 06:41:14 --> Loader Class Initialized
INFO - 2018-02-13 06:41:14 --> Helper loaded: url_helper
INFO - 2018-02-13 06:41:14 --> Helper loaded: form_helper
INFO - 2018-02-13 06:41:14 --> Database Driver Class Initialized
DEBUG - 2018-02-13 06:41:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 06:41:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:41:14 --> Form Validation Class Initialized
INFO - 2018-02-13 06:41:14 --> Model Class Initialized
INFO - 2018-02-13 06:41:14 --> Controller Class Initialized
INFO - 2018-02-13 06:41:14 --> Model Class Initialized
INFO - 2018-02-13 06:41:14 --> Model Class Initialized
INFO - 2018-02-13 06:41:14 --> Model Class Initialized
INFO - 2018-02-13 06:41:14 --> Model Class Initialized
INFO - 2018-02-13 06:41:14 --> Model Class Initialized
DEBUG - 2018-02-13 06:41:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 06:41:16 --> Config Class Initialized
INFO - 2018-02-13 06:41:16 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:41:16 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:41:16 --> Utf8 Class Initialized
INFO - 2018-02-13 06:41:16 --> URI Class Initialized
INFO - 2018-02-13 06:41:16 --> Router Class Initialized
INFO - 2018-02-13 06:41:16 --> Output Class Initialized
INFO - 2018-02-13 06:41:16 --> Security Class Initialized
DEBUG - 2018-02-13 06:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:41:16 --> Input Class Initialized
INFO - 2018-02-13 06:41:16 --> Language Class Initialized
INFO - 2018-02-13 06:41:16 --> Loader Class Initialized
INFO - 2018-02-13 06:41:16 --> Helper loaded: url_helper
INFO - 2018-02-13 06:41:16 --> Helper loaded: form_helper
INFO - 2018-02-13 06:41:16 --> Database Driver Class Initialized
DEBUG - 2018-02-13 06:41:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 06:41:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:41:16 --> Form Validation Class Initialized
INFO - 2018-02-13 06:41:16 --> Model Class Initialized
INFO - 2018-02-13 06:41:16 --> Controller Class Initialized
INFO - 2018-02-13 06:41:16 --> Model Class Initialized
INFO - 2018-02-13 06:41:16 --> Model Class Initialized
INFO - 2018-02-13 06:41:16 --> Model Class Initialized
INFO - 2018-02-13 06:41:16 --> Model Class Initialized
INFO - 2018-02-13 06:41:16 --> Model Class Initialized
DEBUG - 2018-02-13 06:41:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 06:41:17 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 06:41:17 --> Final output sent to browser
DEBUG - 2018-02-13 06:41:17 --> Total execution time: 0.1387
INFO - 2018-02-13 06:41:17 --> Config Class Initialized
INFO - 2018-02-13 06:41:17 --> Config Class Initialized
INFO - 2018-02-13 06:41:17 --> Config Class Initialized
INFO - 2018-02-13 06:41:17 --> Hooks Class Initialized
INFO - 2018-02-13 06:41:17 --> Hooks Class Initialized
INFO - 2018-02-13 06:41:17 --> Hooks Class Initialized
INFO - 2018-02-13 06:41:17 --> Config Class Initialized
INFO - 2018-02-13 06:41:17 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:41:17 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:41:17 --> Utf8 Class Initialized
DEBUG - 2018-02-13 06:41:17 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:41:17 --> Utf8 Class Initialized
DEBUG - 2018-02-13 06:41:17 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 06:41:17 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:41:17 --> Utf8 Class Initialized
INFO - 2018-02-13 06:41:17 --> Utf8 Class Initialized
INFO - 2018-02-13 06:41:17 --> URI Class Initialized
INFO - 2018-02-13 06:41:17 --> URI Class Initialized
INFO - 2018-02-13 06:41:17 --> URI Class Initialized
INFO - 2018-02-13 06:41:17 --> URI Class Initialized
INFO - 2018-02-13 06:41:17 --> Router Class Initialized
INFO - 2018-02-13 06:41:17 --> Router Class Initialized
INFO - 2018-02-13 06:41:17 --> Router Class Initialized
INFO - 2018-02-13 06:41:17 --> Router Class Initialized
INFO - 2018-02-13 06:41:17 --> Output Class Initialized
INFO - 2018-02-13 06:41:17 --> Output Class Initialized
INFO - 2018-02-13 06:41:17 --> Output Class Initialized
INFO - 2018-02-13 06:41:17 --> Output Class Initialized
INFO - 2018-02-13 06:41:17 --> Security Class Initialized
INFO - 2018-02-13 06:41:17 --> Security Class Initialized
INFO - 2018-02-13 06:41:17 --> Security Class Initialized
INFO - 2018-02-13 06:41:17 --> Security Class Initialized
DEBUG - 2018-02-13 06:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:41:17 --> Input Class Initialized
DEBUG - 2018-02-13 06:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:41:17 --> Input Class Initialized
INFO - 2018-02-13 06:41:17 --> Language Class Initialized
DEBUG - 2018-02-13 06:41:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 06:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:41:17 --> Language Class Initialized
INFO - 2018-02-13 06:41:17 --> Input Class Initialized
INFO - 2018-02-13 06:41:17 --> Input Class Initialized
INFO - 2018-02-13 06:41:17 --> Language Class Initialized
ERROR - 2018-02-13 06:41:17 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-13 06:41:17 --> Language Class Initialized
ERROR - 2018-02-13 06:41:17 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-13 06:41:17 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-13 06:41:17 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-13 06:41:17 --> Config Class Initialized
INFO - 2018-02-13 06:41:17 --> Hooks Class Initialized
INFO - 2018-02-13 06:41:17 --> Config Class Initialized
INFO - 2018-02-13 06:41:17 --> Hooks Class Initialized
INFO - 2018-02-13 06:41:17 --> Config Class Initialized
INFO - 2018-02-13 06:41:17 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:41:17 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 06:41:17 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:41:17 --> Utf8 Class Initialized
INFO - 2018-02-13 06:41:17 --> Utf8 Class Initialized
INFO - 2018-02-13 06:41:17 --> URI Class Initialized
DEBUG - 2018-02-13 06:41:17 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:41:17 --> URI Class Initialized
INFO - 2018-02-13 06:41:17 --> Utf8 Class Initialized
INFO - 2018-02-13 06:41:17 --> Router Class Initialized
INFO - 2018-02-13 06:41:17 --> URI Class Initialized
INFO - 2018-02-13 06:41:17 --> Router Class Initialized
INFO - 2018-02-13 06:41:17 --> Router Class Initialized
INFO - 2018-02-13 06:41:17 --> Output Class Initialized
INFO - 2018-02-13 06:41:17 --> Output Class Initialized
INFO - 2018-02-13 06:41:17 --> Output Class Initialized
INFO - 2018-02-13 06:41:17 --> Security Class Initialized
INFO - 2018-02-13 06:41:17 --> Security Class Initialized
INFO - 2018-02-13 06:41:17 --> Security Class Initialized
DEBUG - 2018-02-13 06:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:41:17 --> Input Class Initialized
DEBUG - 2018-02-13 06:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:41:17 --> Input Class Initialized
DEBUG - 2018-02-13 06:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:41:17 --> Language Class Initialized
INFO - 2018-02-13 06:41:17 --> Input Class Initialized
INFO - 2018-02-13 06:41:17 --> Language Class Initialized
INFO - 2018-02-13 06:41:17 --> Language Class Initialized
ERROR - 2018-02-13 06:41:17 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-13 06:41:17 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-13 06:41:17 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-13 06:41:17 --> Config Class Initialized
INFO - 2018-02-13 06:41:17 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:41:17 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:41:17 --> Utf8 Class Initialized
INFO - 2018-02-13 06:41:17 --> URI Class Initialized
INFO - 2018-02-13 06:41:17 --> Router Class Initialized
INFO - 2018-02-13 06:41:17 --> Output Class Initialized
INFO - 2018-02-13 06:41:17 --> Security Class Initialized
DEBUG - 2018-02-13 06:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:41:17 --> Input Class Initialized
INFO - 2018-02-13 06:41:17 --> Language Class Initialized
INFO - 2018-02-13 06:41:17 --> Loader Class Initialized
INFO - 2018-02-13 06:41:17 --> Helper loaded: url_helper
INFO - 2018-02-13 06:41:17 --> Helper loaded: form_helper
INFO - 2018-02-13 06:41:17 --> Database Driver Class Initialized
DEBUG - 2018-02-13 06:41:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 06:41:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:41:17 --> Form Validation Class Initialized
INFO - 2018-02-13 06:41:17 --> Model Class Initialized
INFO - 2018-02-13 06:41:17 --> Controller Class Initialized
INFO - 2018-02-13 06:41:17 --> Model Class Initialized
INFO - 2018-02-13 06:41:17 --> Model Class Initialized
INFO - 2018-02-13 06:41:17 --> Model Class Initialized
INFO - 2018-02-13 06:41:17 --> Model Class Initialized
INFO - 2018-02-13 06:41:17 --> Model Class Initialized
DEBUG - 2018-02-13 06:41:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 06:41:51 --> Config Class Initialized
INFO - 2018-02-13 06:41:51 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:41:51 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:41:51 --> Utf8 Class Initialized
INFO - 2018-02-13 06:41:51 --> URI Class Initialized
INFO - 2018-02-13 06:41:51 --> Router Class Initialized
INFO - 2018-02-13 06:41:51 --> Output Class Initialized
INFO - 2018-02-13 06:41:51 --> Security Class Initialized
DEBUG - 2018-02-13 06:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:41:51 --> Input Class Initialized
INFO - 2018-02-13 06:41:51 --> Language Class Initialized
INFO - 2018-02-13 06:41:51 --> Loader Class Initialized
INFO - 2018-02-13 06:41:51 --> Helper loaded: url_helper
INFO - 2018-02-13 06:41:51 --> Helper loaded: form_helper
INFO - 2018-02-13 06:41:51 --> Database Driver Class Initialized
DEBUG - 2018-02-13 06:41:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 06:41:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:41:51 --> Form Validation Class Initialized
INFO - 2018-02-13 06:41:51 --> Model Class Initialized
INFO - 2018-02-13 06:41:51 --> Controller Class Initialized
INFO - 2018-02-13 06:41:51 --> Model Class Initialized
INFO - 2018-02-13 06:41:51 --> Model Class Initialized
INFO - 2018-02-13 06:41:51 --> Model Class Initialized
INFO - 2018-02-13 06:41:51 --> Model Class Initialized
INFO - 2018-02-13 06:41:51 --> Model Class Initialized
DEBUG - 2018-02-13 06:41:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 06:41:51 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 06:41:51 --> Final output sent to browser
DEBUG - 2018-02-13 06:41:51 --> Total execution time: 0.1027
INFO - 2018-02-13 06:41:51 --> Config Class Initialized
INFO - 2018-02-13 06:41:51 --> Hooks Class Initialized
INFO - 2018-02-13 06:41:51 --> Config Class Initialized
INFO - 2018-02-13 06:41:51 --> Hooks Class Initialized
INFO - 2018-02-13 06:41:51 --> Config Class Initialized
INFO - 2018-02-13 06:41:51 --> Hooks Class Initialized
INFO - 2018-02-13 06:41:51 --> Config Class Initialized
INFO - 2018-02-13 06:41:51 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:41:51 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:41:51 --> Utf8 Class Initialized
DEBUG - 2018-02-13 06:41:51 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 06:41:51 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:41:51 --> Utf8 Class Initialized
INFO - 2018-02-13 06:41:51 --> Utf8 Class Initialized
DEBUG - 2018-02-13 06:41:51 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:41:51 --> URI Class Initialized
INFO - 2018-02-13 06:41:51 --> Utf8 Class Initialized
INFO - 2018-02-13 06:41:51 --> URI Class Initialized
INFO - 2018-02-13 06:41:51 --> URI Class Initialized
INFO - 2018-02-13 06:41:51 --> URI Class Initialized
INFO - 2018-02-13 06:41:51 --> Router Class Initialized
INFO - 2018-02-13 06:41:51 --> Router Class Initialized
INFO - 2018-02-13 06:41:51 --> Router Class Initialized
INFO - 2018-02-13 06:41:51 --> Router Class Initialized
INFO - 2018-02-13 06:41:51 --> Output Class Initialized
INFO - 2018-02-13 06:41:51 --> Output Class Initialized
INFO - 2018-02-13 06:41:51 --> Output Class Initialized
INFO - 2018-02-13 06:41:51 --> Output Class Initialized
INFO - 2018-02-13 06:41:51 --> Security Class Initialized
INFO - 2018-02-13 06:41:51 --> Security Class Initialized
INFO - 2018-02-13 06:41:51 --> Security Class Initialized
DEBUG - 2018-02-13 06:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:41:51 --> Security Class Initialized
INFO - 2018-02-13 06:41:51 --> Input Class Initialized
DEBUG - 2018-02-13 06:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:41:51 --> Input Class Initialized
DEBUG - 2018-02-13 06:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:41:51 --> Input Class Initialized
INFO - 2018-02-13 06:41:51 --> Language Class Initialized
DEBUG - 2018-02-13 06:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:41:51 --> Input Class Initialized
INFO - 2018-02-13 06:41:51 --> Language Class Initialized
INFO - 2018-02-13 06:41:51 --> Language Class Initialized
INFO - 2018-02-13 06:41:51 --> Language Class Initialized
ERROR - 2018-02-13 06:41:51 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-13 06:41:51 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-13 06:41:51 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-13 06:41:51 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-13 06:41:51 --> Config Class Initialized
INFO - 2018-02-13 06:41:51 --> Hooks Class Initialized
INFO - 2018-02-13 06:41:51 --> Config Class Initialized
INFO - 2018-02-13 06:41:51 --> Hooks Class Initialized
INFO - 2018-02-13 06:41:51 --> Config Class Initialized
INFO - 2018-02-13 06:41:51 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:41:51 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:41:51 --> Utf8 Class Initialized
DEBUG - 2018-02-13 06:41:51 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:41:51 --> Utf8 Class Initialized
INFO - 2018-02-13 06:41:51 --> URI Class Initialized
DEBUG - 2018-02-13 06:41:51 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:41:51 --> Utf8 Class Initialized
INFO - 2018-02-13 06:41:51 --> URI Class Initialized
INFO - 2018-02-13 06:41:51 --> Router Class Initialized
INFO - 2018-02-13 06:41:51 --> URI Class Initialized
INFO - 2018-02-13 06:41:51 --> Router Class Initialized
INFO - 2018-02-13 06:41:51 --> Output Class Initialized
INFO - 2018-02-13 06:41:51 --> Router Class Initialized
INFO - 2018-02-13 06:41:51 --> Output Class Initialized
INFO - 2018-02-13 06:41:51 --> Security Class Initialized
INFO - 2018-02-13 06:41:51 --> Output Class Initialized
INFO - 2018-02-13 06:41:51 --> Security Class Initialized
DEBUG - 2018-02-13 06:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:41:51 --> Input Class Initialized
INFO - 2018-02-13 06:41:51 --> Security Class Initialized
DEBUG - 2018-02-13 06:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:41:51 --> Language Class Initialized
INFO - 2018-02-13 06:41:51 --> Input Class Initialized
DEBUG - 2018-02-13 06:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:41:51 --> Input Class Initialized
INFO - 2018-02-13 06:41:51 --> Language Class Initialized
ERROR - 2018-02-13 06:41:51 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-13 06:41:51 --> Language Class Initialized
ERROR - 2018-02-13 06:41:51 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-13 06:41:51 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-13 06:41:51 --> Config Class Initialized
INFO - 2018-02-13 06:41:51 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:41:51 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:41:51 --> Utf8 Class Initialized
INFO - 2018-02-13 06:41:51 --> URI Class Initialized
INFO - 2018-02-13 06:41:51 --> Router Class Initialized
INFO - 2018-02-13 06:41:51 --> Output Class Initialized
INFO - 2018-02-13 06:41:51 --> Security Class Initialized
DEBUG - 2018-02-13 06:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:41:51 --> Input Class Initialized
INFO - 2018-02-13 06:41:51 --> Language Class Initialized
INFO - 2018-02-13 06:41:51 --> Loader Class Initialized
INFO - 2018-02-13 06:41:51 --> Helper loaded: url_helper
INFO - 2018-02-13 06:41:51 --> Helper loaded: form_helper
INFO - 2018-02-13 06:41:51 --> Database Driver Class Initialized
DEBUG - 2018-02-13 06:41:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 06:41:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:41:51 --> Form Validation Class Initialized
INFO - 2018-02-13 06:41:51 --> Model Class Initialized
INFO - 2018-02-13 06:41:51 --> Controller Class Initialized
INFO - 2018-02-13 06:41:51 --> Model Class Initialized
INFO - 2018-02-13 06:41:51 --> Model Class Initialized
INFO - 2018-02-13 06:41:51 --> Model Class Initialized
INFO - 2018-02-13 06:41:51 --> Model Class Initialized
INFO - 2018-02-13 06:41:51 --> Model Class Initialized
DEBUG - 2018-02-13 06:41:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 06:42:17 --> Config Class Initialized
INFO - 2018-02-13 06:42:17 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:42:17 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:42:17 --> Utf8 Class Initialized
INFO - 2018-02-13 06:42:17 --> URI Class Initialized
INFO - 2018-02-13 06:42:17 --> Router Class Initialized
INFO - 2018-02-13 06:42:17 --> Output Class Initialized
INFO - 2018-02-13 06:42:17 --> Security Class Initialized
DEBUG - 2018-02-13 06:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:42:17 --> Input Class Initialized
INFO - 2018-02-13 06:42:17 --> Language Class Initialized
INFO - 2018-02-13 06:42:17 --> Loader Class Initialized
INFO - 2018-02-13 06:42:17 --> Helper loaded: url_helper
INFO - 2018-02-13 06:42:17 --> Helper loaded: form_helper
INFO - 2018-02-13 06:42:17 --> Database Driver Class Initialized
DEBUG - 2018-02-13 06:42:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 06:42:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:42:17 --> Form Validation Class Initialized
INFO - 2018-02-13 06:42:17 --> Model Class Initialized
INFO - 2018-02-13 06:42:17 --> Controller Class Initialized
INFO - 2018-02-13 06:42:17 --> Model Class Initialized
INFO - 2018-02-13 06:42:17 --> Model Class Initialized
INFO - 2018-02-13 06:42:17 --> Model Class Initialized
INFO - 2018-02-13 06:42:17 --> Model Class Initialized
INFO - 2018-02-13 06:42:17 --> Model Class Initialized
DEBUG - 2018-02-13 06:42:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 06:42:17 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 06:42:17 --> Final output sent to browser
DEBUG - 2018-02-13 06:42:17 --> Total execution time: 0.1151
INFO - 2018-02-13 06:42:18 --> Config Class Initialized
INFO - 2018-02-13 06:42:18 --> Hooks Class Initialized
INFO - 2018-02-13 06:42:18 --> Config Class Initialized
INFO - 2018-02-13 06:42:18 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:42:18 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:42:18 --> Utf8 Class Initialized
INFO - 2018-02-13 06:42:18 --> Config Class Initialized
INFO - 2018-02-13 06:42:18 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:42:18 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:42:18 --> Utf8 Class Initialized
INFO - 2018-02-13 06:42:18 --> URI Class Initialized
INFO - 2018-02-13 06:42:18 --> Config Class Initialized
INFO - 2018-02-13 06:42:18 --> Hooks Class Initialized
INFO - 2018-02-13 06:42:18 --> URI Class Initialized
INFO - 2018-02-13 06:42:18 --> Router Class Initialized
DEBUG - 2018-02-13 06:42:18 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:42:18 --> Utf8 Class Initialized
INFO - 2018-02-13 06:42:18 --> Router Class Initialized
DEBUG - 2018-02-13 06:42:18 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:42:18 --> Utf8 Class Initialized
INFO - 2018-02-13 06:42:18 --> URI Class Initialized
INFO - 2018-02-13 06:42:18 --> Output Class Initialized
INFO - 2018-02-13 06:42:18 --> Output Class Initialized
INFO - 2018-02-13 06:42:18 --> URI Class Initialized
INFO - 2018-02-13 06:42:18 --> Router Class Initialized
INFO - 2018-02-13 06:42:18 --> Security Class Initialized
INFO - 2018-02-13 06:42:18 --> Security Class Initialized
INFO - 2018-02-13 06:42:18 --> Router Class Initialized
DEBUG - 2018-02-13 06:42:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:42:18 --> Input Class Initialized
DEBUG - 2018-02-13 06:42:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:42:18 --> Output Class Initialized
INFO - 2018-02-13 06:42:18 --> Input Class Initialized
INFO - 2018-02-13 06:42:18 --> Language Class Initialized
INFO - 2018-02-13 06:42:18 --> Output Class Initialized
INFO - 2018-02-13 06:42:18 --> Language Class Initialized
INFO - 2018-02-13 06:42:18 --> Security Class Initialized
INFO - 2018-02-13 06:42:18 --> Security Class Initialized
ERROR - 2018-02-13 06:42:18 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-13 06:42:18 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-02-13 06:42:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:42:18 --> Input Class Initialized
DEBUG - 2018-02-13 06:42:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:42:18 --> Input Class Initialized
INFO - 2018-02-13 06:42:18 --> Language Class Initialized
INFO - 2018-02-13 06:42:18 --> Language Class Initialized
ERROR - 2018-02-13 06:42:18 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-13 06:42:18 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-13 06:42:18 --> Config Class Initialized
INFO - 2018-02-13 06:42:18 --> Hooks Class Initialized
INFO - 2018-02-13 06:42:18 --> Config Class Initialized
INFO - 2018-02-13 06:42:18 --> Config Class Initialized
INFO - 2018-02-13 06:42:18 --> Hooks Class Initialized
INFO - 2018-02-13 06:42:18 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:42:18 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:42:18 --> Utf8 Class Initialized
DEBUG - 2018-02-13 06:42:18 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 06:42:18 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:42:18 --> Utf8 Class Initialized
INFO - 2018-02-13 06:42:18 --> Utf8 Class Initialized
INFO - 2018-02-13 06:42:18 --> URI Class Initialized
INFO - 2018-02-13 06:42:18 --> URI Class Initialized
INFO - 2018-02-13 06:42:18 --> URI Class Initialized
INFO - 2018-02-13 06:42:18 --> Router Class Initialized
INFO - 2018-02-13 06:42:18 --> Router Class Initialized
INFO - 2018-02-13 06:42:18 --> Router Class Initialized
INFO - 2018-02-13 06:42:18 --> Output Class Initialized
INFO - 2018-02-13 06:42:18 --> Output Class Initialized
INFO - 2018-02-13 06:42:18 --> Output Class Initialized
INFO - 2018-02-13 06:42:18 --> Security Class Initialized
INFO - 2018-02-13 06:42:18 --> Security Class Initialized
INFO - 2018-02-13 06:42:18 --> Security Class Initialized
DEBUG - 2018-02-13 06:42:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:42:18 --> Input Class Initialized
DEBUG - 2018-02-13 06:42:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:42:18 --> Input Class Initialized
INFO - 2018-02-13 06:42:18 --> Language Class Initialized
DEBUG - 2018-02-13 06:42:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:42:18 --> Input Class Initialized
INFO - 2018-02-13 06:42:18 --> Language Class Initialized
INFO - 2018-02-13 06:42:18 --> Language Class Initialized
ERROR - 2018-02-13 06:42:18 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-13 06:42:18 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-13 06:42:18 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-13 06:42:18 --> Config Class Initialized
INFO - 2018-02-13 06:42:18 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:42:18 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:42:18 --> Utf8 Class Initialized
INFO - 2018-02-13 06:42:18 --> URI Class Initialized
INFO - 2018-02-13 06:42:18 --> Router Class Initialized
INFO - 2018-02-13 06:42:18 --> Output Class Initialized
INFO - 2018-02-13 06:42:18 --> Security Class Initialized
DEBUG - 2018-02-13 06:42:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:42:18 --> Input Class Initialized
INFO - 2018-02-13 06:42:18 --> Language Class Initialized
INFO - 2018-02-13 06:42:18 --> Loader Class Initialized
INFO - 2018-02-13 06:42:18 --> Helper loaded: url_helper
INFO - 2018-02-13 06:42:18 --> Helper loaded: form_helper
INFO - 2018-02-13 06:42:18 --> Database Driver Class Initialized
DEBUG - 2018-02-13 06:42:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 06:42:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:42:18 --> Form Validation Class Initialized
INFO - 2018-02-13 06:42:18 --> Model Class Initialized
INFO - 2018-02-13 06:42:18 --> Controller Class Initialized
INFO - 2018-02-13 06:42:18 --> Model Class Initialized
INFO - 2018-02-13 06:42:18 --> Model Class Initialized
INFO - 2018-02-13 06:42:18 --> Model Class Initialized
INFO - 2018-02-13 06:42:18 --> Model Class Initialized
INFO - 2018-02-13 06:42:18 --> Model Class Initialized
DEBUG - 2018-02-13 06:42:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 06:42:19 --> Config Class Initialized
INFO - 2018-02-13 06:42:19 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:42:19 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:42:19 --> Utf8 Class Initialized
INFO - 2018-02-13 06:42:19 --> URI Class Initialized
INFO - 2018-02-13 06:42:19 --> Router Class Initialized
INFO - 2018-02-13 06:42:19 --> Output Class Initialized
INFO - 2018-02-13 06:42:19 --> Security Class Initialized
DEBUG - 2018-02-13 06:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:42:19 --> Input Class Initialized
INFO - 2018-02-13 06:42:19 --> Language Class Initialized
INFO - 2018-02-13 06:42:19 --> Loader Class Initialized
INFO - 2018-02-13 06:42:19 --> Helper loaded: url_helper
INFO - 2018-02-13 06:42:19 --> Helper loaded: form_helper
INFO - 2018-02-13 06:42:19 --> Database Driver Class Initialized
DEBUG - 2018-02-13 06:42:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 06:42:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:42:19 --> Form Validation Class Initialized
INFO - 2018-02-13 06:42:19 --> Model Class Initialized
INFO - 2018-02-13 06:42:19 --> Controller Class Initialized
INFO - 2018-02-13 06:42:19 --> Model Class Initialized
INFO - 2018-02-13 06:42:19 --> Model Class Initialized
INFO - 2018-02-13 06:42:19 --> Model Class Initialized
INFO - 2018-02-13 06:42:19 --> Model Class Initialized
INFO - 2018-02-13 06:42:19 --> Model Class Initialized
DEBUG - 2018-02-13 06:42:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 06:42:19 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 06:42:19 --> Final output sent to browser
DEBUG - 2018-02-13 06:42:19 --> Total execution time: 0.0970
INFO - 2018-02-13 06:42:19 --> Config Class Initialized
INFO - 2018-02-13 06:42:19 --> Hooks Class Initialized
INFO - 2018-02-13 06:42:19 --> Config Class Initialized
INFO - 2018-02-13 06:42:19 --> Hooks Class Initialized
INFO - 2018-02-13 06:42:19 --> Config Class Initialized
INFO - 2018-02-13 06:42:19 --> Hooks Class Initialized
INFO - 2018-02-13 06:42:19 --> Config Class Initialized
INFO - 2018-02-13 06:42:19 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:42:19 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:42:19 --> Utf8 Class Initialized
DEBUG - 2018-02-13 06:42:19 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:42:19 --> Utf8 Class Initialized
INFO - 2018-02-13 06:42:19 --> URI Class Initialized
DEBUG - 2018-02-13 06:42:19 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:42:19 --> Utf8 Class Initialized
INFO - 2018-02-13 06:42:19 --> URI Class Initialized
DEBUG - 2018-02-13 06:42:19 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:42:19 --> Utf8 Class Initialized
INFO - 2018-02-13 06:42:19 --> URI Class Initialized
INFO - 2018-02-13 06:42:19 --> Router Class Initialized
INFO - 2018-02-13 06:42:19 --> URI Class Initialized
INFO - 2018-02-13 06:42:19 --> Router Class Initialized
INFO - 2018-02-13 06:42:19 --> Output Class Initialized
INFO - 2018-02-13 06:42:19 --> Router Class Initialized
INFO - 2018-02-13 06:42:19 --> Router Class Initialized
INFO - 2018-02-13 06:42:19 --> Output Class Initialized
INFO - 2018-02-13 06:42:19 --> Security Class Initialized
INFO - 2018-02-13 06:42:19 --> Security Class Initialized
INFO - 2018-02-13 06:42:19 --> Output Class Initialized
DEBUG - 2018-02-13 06:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:42:19 --> Output Class Initialized
INFO - 2018-02-13 06:42:19 --> Input Class Initialized
DEBUG - 2018-02-13 06:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:42:19 --> Input Class Initialized
INFO - 2018-02-13 06:42:19 --> Language Class Initialized
INFO - 2018-02-13 06:42:19 --> Security Class Initialized
INFO - 2018-02-13 06:42:19 --> Security Class Initialized
INFO - 2018-02-13 06:42:19 --> Language Class Initialized
DEBUG - 2018-02-13 06:42:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 06:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:42:19 --> Input Class Initialized
ERROR - 2018-02-13 06:42:19 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-13 06:42:19 --> Input Class Initialized
ERROR - 2018-02-13 06:42:19 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-13 06:42:19 --> Language Class Initialized
INFO - 2018-02-13 06:42:19 --> Language Class Initialized
ERROR - 2018-02-13 06:42:19 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-13 06:42:19 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-13 06:42:19 --> Config Class Initialized
INFO - 2018-02-13 06:42:19 --> Hooks Class Initialized
INFO - 2018-02-13 06:42:19 --> Config Class Initialized
INFO - 2018-02-13 06:42:19 --> Hooks Class Initialized
INFO - 2018-02-13 06:42:19 --> Config Class Initialized
INFO - 2018-02-13 06:42:19 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:42:19 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:42:19 --> Utf8 Class Initialized
DEBUG - 2018-02-13 06:42:19 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:42:19 --> Utf8 Class Initialized
INFO - 2018-02-13 06:42:19 --> URI Class Initialized
INFO - 2018-02-13 06:42:19 --> URI Class Initialized
DEBUG - 2018-02-13 06:42:19 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:42:19 --> Utf8 Class Initialized
INFO - 2018-02-13 06:42:19 --> Router Class Initialized
INFO - 2018-02-13 06:42:19 --> URI Class Initialized
INFO - 2018-02-13 06:42:19 --> Router Class Initialized
INFO - 2018-02-13 06:42:19 --> Output Class Initialized
INFO - 2018-02-13 06:42:19 --> Router Class Initialized
INFO - 2018-02-13 06:42:19 --> Security Class Initialized
INFO - 2018-02-13 06:42:19 --> Output Class Initialized
INFO - 2018-02-13 06:42:19 --> Output Class Initialized
DEBUG - 2018-02-13 06:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:42:19 --> Input Class Initialized
INFO - 2018-02-13 06:42:19 --> Security Class Initialized
INFO - 2018-02-13 06:42:19 --> Security Class Initialized
INFO - 2018-02-13 06:42:19 --> Language Class Initialized
DEBUG - 2018-02-13 06:42:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 06:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:42:19 --> Input Class Initialized
INFO - 2018-02-13 06:42:19 --> Input Class Initialized
ERROR - 2018-02-13 06:42:19 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-13 06:42:19 --> Language Class Initialized
INFO - 2018-02-13 06:42:19 --> Language Class Initialized
ERROR - 2018-02-13 06:42:19 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-13 06:42:19 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-13 06:42:19 --> Config Class Initialized
INFO - 2018-02-13 06:42:19 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:42:19 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:42:19 --> Utf8 Class Initialized
INFO - 2018-02-13 06:42:19 --> URI Class Initialized
INFO - 2018-02-13 06:42:19 --> Router Class Initialized
INFO - 2018-02-13 06:42:19 --> Output Class Initialized
INFO - 2018-02-13 06:42:19 --> Security Class Initialized
DEBUG - 2018-02-13 06:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:42:19 --> Input Class Initialized
INFO - 2018-02-13 06:42:19 --> Language Class Initialized
INFO - 2018-02-13 06:42:19 --> Loader Class Initialized
INFO - 2018-02-13 06:42:19 --> Helper loaded: url_helper
INFO - 2018-02-13 06:42:19 --> Helper loaded: form_helper
INFO - 2018-02-13 06:42:19 --> Database Driver Class Initialized
DEBUG - 2018-02-13 06:42:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 06:42:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:42:19 --> Form Validation Class Initialized
INFO - 2018-02-13 06:42:19 --> Model Class Initialized
INFO - 2018-02-13 06:42:19 --> Controller Class Initialized
INFO - 2018-02-13 06:42:19 --> Model Class Initialized
INFO - 2018-02-13 06:42:19 --> Model Class Initialized
INFO - 2018-02-13 06:42:19 --> Model Class Initialized
INFO - 2018-02-13 06:42:19 --> Model Class Initialized
INFO - 2018-02-13 06:42:19 --> Model Class Initialized
DEBUG - 2018-02-13 06:42:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 06:42:21 --> Config Class Initialized
INFO - 2018-02-13 06:42:21 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:42:21 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:42:21 --> Utf8 Class Initialized
INFO - 2018-02-13 06:42:21 --> URI Class Initialized
INFO - 2018-02-13 06:42:21 --> Router Class Initialized
INFO - 2018-02-13 06:42:21 --> Output Class Initialized
INFO - 2018-02-13 06:42:21 --> Security Class Initialized
DEBUG - 2018-02-13 06:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:42:21 --> Input Class Initialized
INFO - 2018-02-13 06:42:21 --> Language Class Initialized
INFO - 2018-02-13 06:42:21 --> Loader Class Initialized
INFO - 2018-02-13 06:42:21 --> Helper loaded: url_helper
INFO - 2018-02-13 06:42:21 --> Helper loaded: form_helper
INFO - 2018-02-13 06:42:21 --> Database Driver Class Initialized
DEBUG - 2018-02-13 06:42:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 06:42:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:42:21 --> Form Validation Class Initialized
INFO - 2018-02-13 06:42:21 --> Model Class Initialized
INFO - 2018-02-13 06:42:21 --> Controller Class Initialized
INFO - 2018-02-13 06:42:21 --> Model Class Initialized
INFO - 2018-02-13 06:42:21 --> Model Class Initialized
INFO - 2018-02-13 06:42:21 --> Model Class Initialized
INFO - 2018-02-13 06:42:21 --> Model Class Initialized
INFO - 2018-02-13 06:42:21 --> Model Class Initialized
DEBUG - 2018-02-13 06:42:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 06:42:21 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 06:42:21 --> Final output sent to browser
DEBUG - 2018-02-13 06:42:21 --> Total execution time: 0.1381
INFO - 2018-02-13 06:42:21 --> Config Class Initialized
INFO - 2018-02-13 06:42:21 --> Hooks Class Initialized
INFO - 2018-02-13 06:42:21 --> Config Class Initialized
INFO - 2018-02-13 06:42:21 --> Config Class Initialized
INFO - 2018-02-13 06:42:21 --> Config Class Initialized
INFO - 2018-02-13 06:42:21 --> Hooks Class Initialized
INFO - 2018-02-13 06:42:21 --> Hooks Class Initialized
INFO - 2018-02-13 06:42:21 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:42:21 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:42:21 --> Utf8 Class Initialized
DEBUG - 2018-02-13 06:42:21 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 06:42:21 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:42:21 --> Utf8 Class Initialized
INFO - 2018-02-13 06:42:21 --> Utf8 Class Initialized
DEBUG - 2018-02-13 06:42:21 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:42:21 --> URI Class Initialized
INFO - 2018-02-13 06:42:21 --> Utf8 Class Initialized
INFO - 2018-02-13 06:42:21 --> URI Class Initialized
INFO - 2018-02-13 06:42:21 --> URI Class Initialized
INFO - 2018-02-13 06:42:21 --> URI Class Initialized
INFO - 2018-02-13 06:42:21 --> Router Class Initialized
INFO - 2018-02-13 06:42:21 --> Router Class Initialized
INFO - 2018-02-13 06:42:21 --> Router Class Initialized
INFO - 2018-02-13 06:42:21 --> Router Class Initialized
INFO - 2018-02-13 06:42:21 --> Output Class Initialized
INFO - 2018-02-13 06:42:21 --> Output Class Initialized
INFO - 2018-02-13 06:42:21 --> Output Class Initialized
INFO - 2018-02-13 06:42:21 --> Output Class Initialized
INFO - 2018-02-13 06:42:21 --> Security Class Initialized
INFO - 2018-02-13 06:42:21 --> Security Class Initialized
INFO - 2018-02-13 06:42:21 --> Security Class Initialized
DEBUG - 2018-02-13 06:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:42:21 --> Security Class Initialized
DEBUG - 2018-02-13 06:42:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 06:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:42:21 --> Input Class Initialized
INFO - 2018-02-13 06:42:21 --> Input Class Initialized
INFO - 2018-02-13 06:42:21 --> Input Class Initialized
INFO - 2018-02-13 06:42:21 --> Language Class Initialized
DEBUG - 2018-02-13 06:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:42:21 --> Language Class Initialized
INFO - 2018-02-13 06:42:21 --> Input Class Initialized
INFO - 2018-02-13 06:42:21 --> Language Class Initialized
ERROR - 2018-02-13 06:42:21 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-13 06:42:21 --> Language Class Initialized
ERROR - 2018-02-13 06:42:21 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-13 06:42:21 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-13 06:42:21 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-13 06:42:21 --> Config Class Initialized
INFO - 2018-02-13 06:42:21 --> Hooks Class Initialized
INFO - 2018-02-13 06:42:21 --> Config Class Initialized
INFO - 2018-02-13 06:42:21 --> Hooks Class Initialized
INFO - 2018-02-13 06:42:21 --> Config Class Initialized
INFO - 2018-02-13 06:42:21 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:42:21 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 06:42:21 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 06:42:21 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:42:21 --> Utf8 Class Initialized
INFO - 2018-02-13 06:42:21 --> Utf8 Class Initialized
INFO - 2018-02-13 06:42:21 --> Utf8 Class Initialized
INFO - 2018-02-13 06:42:21 --> URI Class Initialized
INFO - 2018-02-13 06:42:21 --> URI Class Initialized
INFO - 2018-02-13 06:42:21 --> URI Class Initialized
INFO - 2018-02-13 06:42:21 --> Router Class Initialized
INFO - 2018-02-13 06:42:21 --> Router Class Initialized
INFO - 2018-02-13 06:42:21 --> Router Class Initialized
INFO - 2018-02-13 06:42:21 --> Output Class Initialized
INFO - 2018-02-13 06:42:21 --> Output Class Initialized
INFO - 2018-02-13 06:42:21 --> Output Class Initialized
INFO - 2018-02-13 06:42:21 --> Security Class Initialized
INFO - 2018-02-13 06:42:21 --> Security Class Initialized
INFO - 2018-02-13 06:42:21 --> Security Class Initialized
DEBUG - 2018-02-13 06:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:42:21 --> Input Class Initialized
DEBUG - 2018-02-13 06:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:42:21 --> Input Class Initialized
INFO - 2018-02-13 06:42:21 --> Language Class Initialized
DEBUG - 2018-02-13 06:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:42:21 --> Language Class Initialized
INFO - 2018-02-13 06:42:21 --> Input Class Initialized
ERROR - 2018-02-13 06:42:21 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-13 06:42:21 --> Language Class Initialized
ERROR - 2018-02-13 06:42:21 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-13 06:42:21 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-13 06:42:21 --> Config Class Initialized
INFO - 2018-02-13 06:42:21 --> Hooks Class Initialized
INFO - 2018-02-13 06:42:21 --> Config Class Initialized
INFO - 2018-02-13 06:42:21 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:42:21 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:42:21 --> Utf8 Class Initialized
DEBUG - 2018-02-13 06:42:21 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:42:21 --> Utf8 Class Initialized
INFO - 2018-02-13 06:42:21 --> URI Class Initialized
INFO - 2018-02-13 06:42:21 --> URI Class Initialized
INFO - 2018-02-13 06:42:21 --> Router Class Initialized
INFO - 2018-02-13 06:42:21 --> Router Class Initialized
INFO - 2018-02-13 06:42:21 --> Output Class Initialized
INFO - 2018-02-13 06:42:21 --> Output Class Initialized
INFO - 2018-02-13 06:42:21 --> Security Class Initialized
INFO - 2018-02-13 06:42:21 --> Security Class Initialized
DEBUG - 2018-02-13 06:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:42:21 --> Input Class Initialized
DEBUG - 2018-02-13 06:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:42:21 --> Input Class Initialized
INFO - 2018-02-13 06:42:21 --> Language Class Initialized
INFO - 2018-02-13 06:42:21 --> Language Class Initialized
INFO - 2018-02-13 06:42:21 --> Loader Class Initialized
INFO - 2018-02-13 06:42:21 --> Loader Class Initialized
INFO - 2018-02-13 06:42:21 --> Helper loaded: url_helper
INFO - 2018-02-13 06:42:21 --> Helper loaded: url_helper
INFO - 2018-02-13 06:42:21 --> Helper loaded: form_helper
INFO - 2018-02-13 06:42:21 --> Helper loaded: form_helper
INFO - 2018-02-13 06:42:21 --> Database Driver Class Initialized
INFO - 2018-02-13 06:42:21 --> Database Driver Class Initialized
DEBUG - 2018-02-13 06:42:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 06:42:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:42:21 --> Form Validation Class Initialized
INFO - 2018-02-13 06:42:21 --> Model Class Initialized
INFO - 2018-02-13 06:42:21 --> Controller Class Initialized
INFO - 2018-02-13 06:42:21 --> Model Class Initialized
INFO - 2018-02-13 06:42:21 --> Model Class Initialized
INFO - 2018-02-13 06:42:21 --> Model Class Initialized
INFO - 2018-02-13 06:42:21 --> Model Class Initialized
DEBUG - 2018-02-13 06:42:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 06:42:21 --> Model Class Initialized
DEBUG - 2018-02-13 06:42:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 06:42:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:42:21 --> Form Validation Class Initialized
INFO - 2018-02-13 06:42:21 --> Model Class Initialized
INFO - 2018-02-13 06:42:21 --> Controller Class Initialized
INFO - 2018-02-13 06:42:21 --> Model Class Initialized
INFO - 2018-02-13 06:42:21 --> Model Class Initialized
INFO - 2018-02-13 06:42:21 --> Model Class Initialized
INFO - 2018-02-13 06:42:21 --> Model Class Initialized
INFO - 2018-02-13 06:42:21 --> Model Class Initialized
DEBUG - 2018-02-13 06:42:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 06:42:35 --> Config Class Initialized
INFO - 2018-02-13 06:42:35 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:42:35 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:42:35 --> Utf8 Class Initialized
INFO - 2018-02-13 06:42:35 --> URI Class Initialized
INFO - 2018-02-13 06:42:35 --> Router Class Initialized
INFO - 2018-02-13 06:42:35 --> Output Class Initialized
INFO - 2018-02-13 06:42:35 --> Security Class Initialized
DEBUG - 2018-02-13 06:42:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:42:35 --> Input Class Initialized
INFO - 2018-02-13 06:42:35 --> Language Class Initialized
INFO - 2018-02-13 06:42:35 --> Loader Class Initialized
INFO - 2018-02-13 06:42:35 --> Helper loaded: url_helper
INFO - 2018-02-13 06:42:35 --> Helper loaded: form_helper
INFO - 2018-02-13 06:42:35 --> Database Driver Class Initialized
DEBUG - 2018-02-13 06:42:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 06:42:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:42:35 --> Form Validation Class Initialized
INFO - 2018-02-13 06:42:35 --> Model Class Initialized
INFO - 2018-02-13 06:42:35 --> Controller Class Initialized
INFO - 2018-02-13 06:42:35 --> Model Class Initialized
INFO - 2018-02-13 06:42:35 --> Model Class Initialized
INFO - 2018-02-13 06:42:35 --> Model Class Initialized
INFO - 2018-02-13 06:42:35 --> Model Class Initialized
INFO - 2018-02-13 06:42:35 --> Model Class Initialized
DEBUG - 2018-02-13 06:42:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 06:42:35 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 06:42:35 --> Final output sent to browser
DEBUG - 2018-02-13 06:42:35 --> Total execution time: 0.3586
INFO - 2018-02-13 06:42:35 --> Config Class Initialized
INFO - 2018-02-13 06:42:35 --> Hooks Class Initialized
INFO - 2018-02-13 06:42:35 --> Config Class Initialized
INFO - 2018-02-13 06:42:35 --> Hooks Class Initialized
INFO - 2018-02-13 06:42:35 --> Config Class Initialized
INFO - 2018-02-13 06:42:35 --> Hooks Class Initialized
INFO - 2018-02-13 06:42:35 --> Config Class Initialized
INFO - 2018-02-13 06:42:35 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:42:35 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:42:35 --> Utf8 Class Initialized
DEBUG - 2018-02-13 06:42:35 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:42:35 --> Utf8 Class Initialized
INFO - 2018-02-13 06:42:35 --> URI Class Initialized
DEBUG - 2018-02-13 06:42:35 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:42:35 --> URI Class Initialized
INFO - 2018-02-13 06:42:35 --> Utf8 Class Initialized
DEBUG - 2018-02-13 06:42:35 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:42:35 --> Utf8 Class Initialized
INFO - 2018-02-13 06:42:35 --> URI Class Initialized
INFO - 2018-02-13 06:42:35 --> Router Class Initialized
INFO - 2018-02-13 06:42:35 --> Router Class Initialized
INFO - 2018-02-13 06:42:35 --> URI Class Initialized
INFO - 2018-02-13 06:42:35 --> Router Class Initialized
INFO - 2018-02-13 06:42:35 --> Output Class Initialized
INFO - 2018-02-13 06:42:35 --> Router Class Initialized
INFO - 2018-02-13 06:42:35 --> Output Class Initialized
INFO - 2018-02-13 06:42:35 --> Security Class Initialized
INFO - 2018-02-13 06:42:35 --> Output Class Initialized
INFO - 2018-02-13 06:42:35 --> Security Class Initialized
INFO - 2018-02-13 06:42:35 --> Output Class Initialized
DEBUG - 2018-02-13 06:42:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:42:35 --> Security Class Initialized
DEBUG - 2018-02-13 06:42:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:42:35 --> Input Class Initialized
INFO - 2018-02-13 06:42:35 --> Input Class Initialized
INFO - 2018-02-13 06:42:35 --> Security Class Initialized
INFO - 2018-02-13 06:42:35 --> Language Class Initialized
INFO - 2018-02-13 06:42:35 --> Language Class Initialized
DEBUG - 2018-02-13 06:42:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 06:42:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:42:35 --> Input Class Initialized
INFO - 2018-02-13 06:42:35 --> Input Class Initialized
ERROR - 2018-02-13 06:42:35 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-13 06:42:35 --> Language Class Initialized
ERROR - 2018-02-13 06:42:35 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-13 06:42:35 --> Language Class Initialized
ERROR - 2018-02-13 06:42:35 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-13 06:42:35 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-13 06:42:35 --> Config Class Initialized
INFO - 2018-02-13 06:42:35 --> Config Class Initialized
INFO - 2018-02-13 06:42:35 --> Config Class Initialized
INFO - 2018-02-13 06:42:35 --> Hooks Class Initialized
INFO - 2018-02-13 06:42:35 --> Hooks Class Initialized
INFO - 2018-02-13 06:42:35 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:42:35 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 06:42:35 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 06:42:35 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:42:35 --> Utf8 Class Initialized
INFO - 2018-02-13 06:42:35 --> Utf8 Class Initialized
INFO - 2018-02-13 06:42:35 --> Utf8 Class Initialized
INFO - 2018-02-13 06:42:35 --> URI Class Initialized
INFO - 2018-02-13 06:42:35 --> URI Class Initialized
INFO - 2018-02-13 06:42:35 --> URI Class Initialized
INFO - 2018-02-13 06:42:35 --> Router Class Initialized
INFO - 2018-02-13 06:42:35 --> Router Class Initialized
INFO - 2018-02-13 06:42:35 --> Router Class Initialized
INFO - 2018-02-13 06:42:35 --> Output Class Initialized
INFO - 2018-02-13 06:42:35 --> Output Class Initialized
INFO - 2018-02-13 06:42:35 --> Output Class Initialized
INFO - 2018-02-13 06:42:35 --> Security Class Initialized
INFO - 2018-02-13 06:42:35 --> Security Class Initialized
INFO - 2018-02-13 06:42:35 --> Security Class Initialized
DEBUG - 2018-02-13 06:42:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:42:35 --> Input Class Initialized
DEBUG - 2018-02-13 06:42:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:42:35 --> Input Class Initialized
DEBUG - 2018-02-13 06:42:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:42:35 --> Language Class Initialized
INFO - 2018-02-13 06:42:35 --> Input Class Initialized
INFO - 2018-02-13 06:42:35 --> Language Class Initialized
INFO - 2018-02-13 06:42:35 --> Language Class Initialized
ERROR - 2018-02-13 06:42:35 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-13 06:42:35 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-13 06:42:35 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-13 06:42:35 --> Config Class Initialized
INFO - 2018-02-13 06:42:35 --> Hooks Class Initialized
INFO - 2018-02-13 06:42:35 --> Config Class Initialized
INFO - 2018-02-13 06:42:35 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:42:35 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:42:35 --> Utf8 Class Initialized
DEBUG - 2018-02-13 06:42:35 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:42:35 --> Utf8 Class Initialized
INFO - 2018-02-13 06:42:35 --> URI Class Initialized
INFO - 2018-02-13 06:42:35 --> URI Class Initialized
INFO - 2018-02-13 06:42:35 --> Router Class Initialized
INFO - 2018-02-13 06:42:35 --> Router Class Initialized
INFO - 2018-02-13 06:42:35 --> Output Class Initialized
INFO - 2018-02-13 06:42:35 --> Output Class Initialized
INFO - 2018-02-13 06:42:35 --> Security Class Initialized
DEBUG - 2018-02-13 06:42:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:42:35 --> Security Class Initialized
INFO - 2018-02-13 06:42:35 --> Input Class Initialized
INFO - 2018-02-13 06:42:35 --> Language Class Initialized
DEBUG - 2018-02-13 06:42:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:42:35 --> Input Class Initialized
INFO - 2018-02-13 06:42:35 --> Language Class Initialized
INFO - 2018-02-13 06:42:35 --> Loader Class Initialized
INFO - 2018-02-13 06:42:35 --> Loader Class Initialized
INFO - 2018-02-13 06:42:35 --> Helper loaded: url_helper
INFO - 2018-02-13 06:42:35 --> Helper loaded: url_helper
INFO - 2018-02-13 06:42:35 --> Helper loaded: form_helper
INFO - 2018-02-13 06:42:35 --> Helper loaded: form_helper
INFO - 2018-02-13 06:42:35 --> Database Driver Class Initialized
INFO - 2018-02-13 06:42:35 --> Database Driver Class Initialized
DEBUG - 2018-02-13 06:42:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 06:42:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 06:42:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:42:35 --> Form Validation Class Initialized
INFO - 2018-02-13 06:42:35 --> Model Class Initialized
INFO - 2018-02-13 06:42:35 --> Controller Class Initialized
INFO - 2018-02-13 06:42:35 --> Model Class Initialized
INFO - 2018-02-13 06:42:35 --> Model Class Initialized
INFO - 2018-02-13 06:42:35 --> Model Class Initialized
INFO - 2018-02-13 06:42:35 --> Model Class Initialized
INFO - 2018-02-13 06:42:35 --> Model Class Initialized
DEBUG - 2018-02-13 06:42:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 06:42:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:42:35 --> Form Validation Class Initialized
INFO - 2018-02-13 06:42:35 --> Model Class Initialized
INFO - 2018-02-13 06:42:35 --> Controller Class Initialized
INFO - 2018-02-13 06:42:35 --> Model Class Initialized
INFO - 2018-02-13 06:42:35 --> Model Class Initialized
INFO - 2018-02-13 06:42:35 --> Model Class Initialized
INFO - 2018-02-13 06:42:35 --> Model Class Initialized
INFO - 2018-02-13 06:42:35 --> Model Class Initialized
DEBUG - 2018-02-13 06:42:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 06:42:37 --> Config Class Initialized
INFO - 2018-02-13 06:42:37 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:42:37 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:42:37 --> Utf8 Class Initialized
INFO - 2018-02-13 06:42:37 --> URI Class Initialized
INFO - 2018-02-13 06:42:37 --> Router Class Initialized
INFO - 2018-02-13 06:42:37 --> Output Class Initialized
INFO - 2018-02-13 06:42:37 --> Security Class Initialized
DEBUG - 2018-02-13 06:42:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:42:37 --> Input Class Initialized
INFO - 2018-02-13 06:42:37 --> Language Class Initialized
INFO - 2018-02-13 06:42:37 --> Loader Class Initialized
INFO - 2018-02-13 06:42:37 --> Helper loaded: url_helper
INFO - 2018-02-13 06:42:37 --> Helper loaded: form_helper
INFO - 2018-02-13 06:42:37 --> Database Driver Class Initialized
DEBUG - 2018-02-13 06:42:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 06:42:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:42:37 --> Form Validation Class Initialized
INFO - 2018-02-13 06:42:37 --> Model Class Initialized
INFO - 2018-02-13 06:42:37 --> Controller Class Initialized
INFO - 2018-02-13 06:42:37 --> Model Class Initialized
INFO - 2018-02-13 06:42:37 --> Model Class Initialized
INFO - 2018-02-13 06:42:37 --> Model Class Initialized
INFO - 2018-02-13 06:42:37 --> Model Class Initialized
INFO - 2018-02-13 06:42:37 --> Model Class Initialized
DEBUG - 2018-02-13 06:42:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 06:42:37 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 06:42:37 --> Final output sent to browser
DEBUG - 2018-02-13 06:42:37 --> Total execution time: 0.0835
INFO - 2018-02-13 06:42:37 --> Config Class Initialized
INFO - 2018-02-13 06:42:37 --> Hooks Class Initialized
INFO - 2018-02-13 06:42:37 --> Config Class Initialized
INFO - 2018-02-13 06:42:37 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:42:37 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:42:37 --> Utf8 Class Initialized
INFO - 2018-02-13 06:42:37 --> Config Class Initialized
INFO - 2018-02-13 06:42:37 --> Config Class Initialized
INFO - 2018-02-13 06:42:37 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:42:37 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:42:37 --> Hooks Class Initialized
INFO - 2018-02-13 06:42:37 --> Utf8 Class Initialized
INFO - 2018-02-13 06:42:37 --> URI Class Initialized
INFO - 2018-02-13 06:42:37 --> URI Class Initialized
DEBUG - 2018-02-13 06:42:37 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:42:37 --> Router Class Initialized
INFO - 2018-02-13 06:42:37 --> Utf8 Class Initialized
DEBUG - 2018-02-13 06:42:37 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:42:37 --> Router Class Initialized
INFO - 2018-02-13 06:42:37 --> Utf8 Class Initialized
INFO - 2018-02-13 06:42:37 --> URI Class Initialized
INFO - 2018-02-13 06:42:37 --> Output Class Initialized
INFO - 2018-02-13 06:42:37 --> URI Class Initialized
INFO - 2018-02-13 06:42:37 --> Output Class Initialized
INFO - 2018-02-13 06:42:37 --> Router Class Initialized
INFO - 2018-02-13 06:42:37 --> Security Class Initialized
INFO - 2018-02-13 06:42:37 --> Security Class Initialized
INFO - 2018-02-13 06:42:37 --> Router Class Initialized
DEBUG - 2018-02-13 06:42:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:42:37 --> Output Class Initialized
INFO - 2018-02-13 06:42:37 --> Input Class Initialized
DEBUG - 2018-02-13 06:42:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:42:37 --> Input Class Initialized
INFO - 2018-02-13 06:42:37 --> Output Class Initialized
INFO - 2018-02-13 06:42:37 --> Language Class Initialized
INFO - 2018-02-13 06:42:37 --> Language Class Initialized
INFO - 2018-02-13 06:42:37 --> Security Class Initialized
INFO - 2018-02-13 06:42:37 --> Security Class Initialized
ERROR - 2018-02-13 06:42:37 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-13 06:42:37 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-02-13 06:42:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:42:37 --> Input Class Initialized
DEBUG - 2018-02-13 06:42:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:42:37 --> Input Class Initialized
INFO - 2018-02-13 06:42:37 --> Language Class Initialized
INFO - 2018-02-13 06:42:37 --> Language Class Initialized
ERROR - 2018-02-13 06:42:37 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-13 06:42:37 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-13 06:42:37 --> Config Class Initialized
INFO - 2018-02-13 06:42:37 --> Hooks Class Initialized
INFO - 2018-02-13 06:42:37 --> Config Class Initialized
INFO - 2018-02-13 06:42:37 --> Hooks Class Initialized
INFO - 2018-02-13 06:42:37 --> Config Class Initialized
INFO - 2018-02-13 06:42:37 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:42:37 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:42:37 --> Utf8 Class Initialized
DEBUG - 2018-02-13 06:42:37 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:42:37 --> Utf8 Class Initialized
INFO - 2018-02-13 06:42:37 --> URI Class Initialized
INFO - 2018-02-13 06:42:37 --> URI Class Initialized
DEBUG - 2018-02-13 06:42:37 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:42:37 --> Utf8 Class Initialized
INFO - 2018-02-13 06:42:37 --> Router Class Initialized
INFO - 2018-02-13 06:42:37 --> Router Class Initialized
INFO - 2018-02-13 06:42:37 --> URI Class Initialized
INFO - 2018-02-13 06:42:37 --> Output Class Initialized
INFO - 2018-02-13 06:42:37 --> Output Class Initialized
INFO - 2018-02-13 06:42:37 --> Router Class Initialized
INFO - 2018-02-13 06:42:37 --> Security Class Initialized
INFO - 2018-02-13 06:42:37 --> Security Class Initialized
INFO - 2018-02-13 06:42:37 --> Output Class Initialized
DEBUG - 2018-02-13 06:42:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 06:42:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:42:37 --> Input Class Initialized
INFO - 2018-02-13 06:42:37 --> Input Class Initialized
INFO - 2018-02-13 06:42:37 --> Security Class Initialized
INFO - 2018-02-13 06:42:37 --> Language Class Initialized
INFO - 2018-02-13 06:42:37 --> Language Class Initialized
DEBUG - 2018-02-13 06:42:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:42:37 --> Input Class Initialized
ERROR - 2018-02-13 06:42:37 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-13 06:42:37 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-13 06:42:37 --> Language Class Initialized
ERROR - 2018-02-13 06:42:37 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-13 06:42:37 --> Config Class Initialized
INFO - 2018-02-13 06:42:37 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:42:37 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:42:37 --> Utf8 Class Initialized
INFO - 2018-02-13 06:42:37 --> URI Class Initialized
INFO - 2018-02-13 06:42:37 --> Router Class Initialized
INFO - 2018-02-13 06:42:37 --> Output Class Initialized
INFO - 2018-02-13 06:42:37 --> Security Class Initialized
DEBUG - 2018-02-13 06:42:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:42:37 --> Input Class Initialized
INFO - 2018-02-13 06:42:37 --> Language Class Initialized
INFO - 2018-02-13 06:42:37 --> Loader Class Initialized
INFO - 2018-02-13 06:42:37 --> Helper loaded: url_helper
INFO - 2018-02-13 06:42:37 --> Helper loaded: form_helper
INFO - 2018-02-13 06:42:37 --> Database Driver Class Initialized
DEBUG - 2018-02-13 06:42:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 06:42:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:42:37 --> Form Validation Class Initialized
INFO - 2018-02-13 06:42:37 --> Model Class Initialized
INFO - 2018-02-13 06:42:37 --> Controller Class Initialized
INFO - 2018-02-13 06:42:37 --> Model Class Initialized
INFO - 2018-02-13 06:42:37 --> Model Class Initialized
INFO - 2018-02-13 06:42:37 --> Model Class Initialized
INFO - 2018-02-13 06:42:37 --> Model Class Initialized
INFO - 2018-02-13 06:42:37 --> Model Class Initialized
DEBUG - 2018-02-13 06:42:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 06:42:41 --> Config Class Initialized
INFO - 2018-02-13 06:42:41 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:42:41 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:42:41 --> Utf8 Class Initialized
INFO - 2018-02-13 06:42:41 --> URI Class Initialized
INFO - 2018-02-13 06:42:41 --> Router Class Initialized
INFO - 2018-02-13 06:42:41 --> Output Class Initialized
INFO - 2018-02-13 06:42:41 --> Security Class Initialized
DEBUG - 2018-02-13 06:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:42:41 --> Input Class Initialized
INFO - 2018-02-13 06:42:41 --> Language Class Initialized
INFO - 2018-02-13 06:42:41 --> Loader Class Initialized
INFO - 2018-02-13 06:42:41 --> Helper loaded: url_helper
INFO - 2018-02-13 06:42:41 --> Helper loaded: form_helper
INFO - 2018-02-13 06:42:41 --> Database Driver Class Initialized
DEBUG - 2018-02-13 06:42:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 06:42:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:42:41 --> Form Validation Class Initialized
INFO - 2018-02-13 06:42:41 --> Model Class Initialized
INFO - 2018-02-13 06:42:41 --> Controller Class Initialized
INFO - 2018-02-13 06:42:41 --> Model Class Initialized
INFO - 2018-02-13 06:42:41 --> Model Class Initialized
INFO - 2018-02-13 06:42:41 --> Model Class Initialized
INFO - 2018-02-13 06:42:41 --> Model Class Initialized
INFO - 2018-02-13 06:42:41 --> Model Class Initialized
DEBUG - 2018-02-13 06:42:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 06:42:41 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 06:42:41 --> Final output sent to browser
DEBUG - 2018-02-13 06:42:41 --> Total execution time: 0.0816
INFO - 2018-02-13 06:42:41 --> Config Class Initialized
INFO - 2018-02-13 06:42:41 --> Hooks Class Initialized
INFO - 2018-02-13 06:42:41 --> Config Class Initialized
INFO - 2018-02-13 06:42:41 --> Config Class Initialized
INFO - 2018-02-13 06:42:41 --> Hooks Class Initialized
INFO - 2018-02-13 06:42:41 --> Hooks Class Initialized
INFO - 2018-02-13 06:42:41 --> Config Class Initialized
INFO - 2018-02-13 06:42:41 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:42:41 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:42:41 --> Utf8 Class Initialized
DEBUG - 2018-02-13 06:42:41 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:42:41 --> Utf8 Class Initialized
DEBUG - 2018-02-13 06:42:41 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:42:41 --> Utf8 Class Initialized
INFO - 2018-02-13 06:42:41 --> URI Class Initialized
INFO - 2018-02-13 06:42:41 --> URI Class Initialized
INFO - 2018-02-13 06:42:41 --> URI Class Initialized
DEBUG - 2018-02-13 06:42:41 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:42:41 --> Utf8 Class Initialized
INFO - 2018-02-13 06:42:41 --> Router Class Initialized
INFO - 2018-02-13 06:42:41 --> Router Class Initialized
INFO - 2018-02-13 06:42:41 --> URI Class Initialized
INFO - 2018-02-13 06:42:41 --> Router Class Initialized
INFO - 2018-02-13 06:42:41 --> Output Class Initialized
INFO - 2018-02-13 06:42:41 --> Output Class Initialized
INFO - 2018-02-13 06:42:41 --> Router Class Initialized
INFO - 2018-02-13 06:42:41 --> Output Class Initialized
INFO - 2018-02-13 06:42:41 --> Security Class Initialized
INFO - 2018-02-13 06:42:41 --> Security Class Initialized
INFO - 2018-02-13 06:42:41 --> Security Class Initialized
DEBUG - 2018-02-13 06:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:42:41 --> Output Class Initialized
DEBUG - 2018-02-13 06:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:42:41 --> Input Class Initialized
INFO - 2018-02-13 06:42:41 --> Input Class Initialized
DEBUG - 2018-02-13 06:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:42:41 --> Input Class Initialized
INFO - 2018-02-13 06:42:41 --> Language Class Initialized
INFO - 2018-02-13 06:42:41 --> Language Class Initialized
INFO - 2018-02-13 06:42:41 --> Security Class Initialized
INFO - 2018-02-13 06:42:41 --> Language Class Initialized
ERROR - 2018-02-13 06:42:41 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-13 06:42:41 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-02-13 06:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:42:41 --> Input Class Initialized
ERROR - 2018-02-13 06:42:41 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-13 06:42:41 --> Language Class Initialized
ERROR - 2018-02-13 06:42:41 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-13 06:42:41 --> Config Class Initialized
INFO - 2018-02-13 06:42:41 --> Hooks Class Initialized
INFO - 2018-02-13 06:42:41 --> Config Class Initialized
INFO - 2018-02-13 06:42:41 --> Config Class Initialized
INFO - 2018-02-13 06:42:41 --> Hooks Class Initialized
INFO - 2018-02-13 06:42:41 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:42:41 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:42:41 --> Utf8 Class Initialized
DEBUG - 2018-02-13 06:42:41 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:42:41 --> Utf8 Class Initialized
INFO - 2018-02-13 06:42:41 --> URI Class Initialized
DEBUG - 2018-02-13 06:42:41 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:42:41 --> Utf8 Class Initialized
INFO - 2018-02-13 06:42:41 --> URI Class Initialized
INFO - 2018-02-13 06:42:41 --> Router Class Initialized
INFO - 2018-02-13 06:42:41 --> URI Class Initialized
INFO - 2018-02-13 06:42:41 --> Router Class Initialized
INFO - 2018-02-13 06:42:41 --> Output Class Initialized
INFO - 2018-02-13 06:42:41 --> Output Class Initialized
INFO - 2018-02-13 06:42:41 --> Router Class Initialized
INFO - 2018-02-13 06:42:41 --> Security Class Initialized
INFO - 2018-02-13 06:42:41 --> Security Class Initialized
DEBUG - 2018-02-13 06:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:42:41 --> Output Class Initialized
INFO - 2018-02-13 06:42:41 --> Input Class Initialized
DEBUG - 2018-02-13 06:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:42:41 --> Input Class Initialized
INFO - 2018-02-13 06:42:41 --> Language Class Initialized
INFO - 2018-02-13 06:42:41 --> Security Class Initialized
INFO - 2018-02-13 06:42:41 --> Language Class Initialized
ERROR - 2018-02-13 06:42:41 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-02-13 06:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:42:41 --> Input Class Initialized
ERROR - 2018-02-13 06:42:41 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-13 06:42:41 --> Language Class Initialized
ERROR - 2018-02-13 06:42:41 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-13 06:42:41 --> Config Class Initialized
INFO - 2018-02-13 06:42:41 --> Hooks Class Initialized
INFO - 2018-02-13 06:42:41 --> Config Class Initialized
INFO - 2018-02-13 06:42:41 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:42:41 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:42:41 --> Utf8 Class Initialized
DEBUG - 2018-02-13 06:42:41 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:42:41 --> Utf8 Class Initialized
INFO - 2018-02-13 06:42:41 --> URI Class Initialized
INFO - 2018-02-13 06:42:41 --> URI Class Initialized
INFO - 2018-02-13 06:42:41 --> Router Class Initialized
INFO - 2018-02-13 06:42:41 --> Router Class Initialized
INFO - 2018-02-13 06:42:41 --> Output Class Initialized
INFO - 2018-02-13 06:42:41 --> Output Class Initialized
INFO - 2018-02-13 06:42:41 --> Security Class Initialized
INFO - 2018-02-13 06:42:41 --> Security Class Initialized
DEBUG - 2018-02-13 06:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:42:41 --> Input Class Initialized
DEBUG - 2018-02-13 06:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:42:41 --> Input Class Initialized
INFO - 2018-02-13 06:42:41 --> Language Class Initialized
INFO - 2018-02-13 06:42:41 --> Language Class Initialized
INFO - 2018-02-13 06:42:41 --> Loader Class Initialized
INFO - 2018-02-13 06:42:41 --> Loader Class Initialized
INFO - 2018-02-13 06:42:41 --> Helper loaded: url_helper
INFO - 2018-02-13 06:42:41 --> Helper loaded: url_helper
INFO - 2018-02-13 06:42:41 --> Helper loaded: form_helper
INFO - 2018-02-13 06:42:41 --> Helper loaded: form_helper
INFO - 2018-02-13 06:42:41 --> Database Driver Class Initialized
INFO - 2018-02-13 06:42:41 --> Database Driver Class Initialized
DEBUG - 2018-02-13 06:42:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 06:42:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 06:42:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:42:41 --> Form Validation Class Initialized
INFO - 2018-02-13 06:42:41 --> Model Class Initialized
INFO - 2018-02-13 06:42:41 --> Controller Class Initialized
INFO - 2018-02-13 06:42:41 --> Model Class Initialized
INFO - 2018-02-13 06:42:41 --> Model Class Initialized
INFO - 2018-02-13 06:42:41 --> Model Class Initialized
INFO - 2018-02-13 06:42:41 --> Model Class Initialized
INFO - 2018-02-13 06:42:41 --> Model Class Initialized
DEBUG - 2018-02-13 06:42:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 06:42:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:42:41 --> Form Validation Class Initialized
INFO - 2018-02-13 06:42:41 --> Model Class Initialized
INFO - 2018-02-13 06:42:41 --> Controller Class Initialized
INFO - 2018-02-13 06:42:41 --> Model Class Initialized
INFO - 2018-02-13 06:42:41 --> Model Class Initialized
INFO - 2018-02-13 06:42:41 --> Model Class Initialized
INFO - 2018-02-13 06:42:41 --> Model Class Initialized
INFO - 2018-02-13 06:42:41 --> Model Class Initialized
DEBUG - 2018-02-13 06:42:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 06:42:43 --> Config Class Initialized
INFO - 2018-02-13 06:42:43 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:42:43 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:42:43 --> Utf8 Class Initialized
INFO - 2018-02-13 06:42:43 --> URI Class Initialized
INFO - 2018-02-13 06:42:43 --> Router Class Initialized
INFO - 2018-02-13 06:42:43 --> Output Class Initialized
INFO - 2018-02-13 06:42:43 --> Security Class Initialized
DEBUG - 2018-02-13 06:42:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:42:43 --> Input Class Initialized
INFO - 2018-02-13 06:42:43 --> Language Class Initialized
INFO - 2018-02-13 06:42:43 --> Loader Class Initialized
INFO - 2018-02-13 06:42:43 --> Helper loaded: url_helper
INFO - 2018-02-13 06:42:43 --> Helper loaded: form_helper
INFO - 2018-02-13 06:42:43 --> Database Driver Class Initialized
DEBUG - 2018-02-13 06:42:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 06:42:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:42:43 --> Form Validation Class Initialized
INFO - 2018-02-13 06:42:43 --> Model Class Initialized
INFO - 2018-02-13 06:42:43 --> Controller Class Initialized
INFO - 2018-02-13 06:42:43 --> Model Class Initialized
INFO - 2018-02-13 06:42:43 --> Model Class Initialized
INFO - 2018-02-13 06:42:43 --> Model Class Initialized
INFO - 2018-02-13 06:42:43 --> Model Class Initialized
INFO - 2018-02-13 06:42:43 --> Model Class Initialized
DEBUG - 2018-02-13 06:42:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 06:42:43 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 06:42:43 --> Final output sent to browser
DEBUG - 2018-02-13 06:42:43 --> Total execution time: 0.1237
INFO - 2018-02-13 06:42:43 --> Config Class Initialized
INFO - 2018-02-13 06:42:43 --> Hooks Class Initialized
INFO - 2018-02-13 06:42:43 --> Config Class Initialized
INFO - 2018-02-13 06:42:43 --> Config Class Initialized
INFO - 2018-02-13 06:42:43 --> Hooks Class Initialized
INFO - 2018-02-13 06:42:43 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:42:43 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:42:43 --> Utf8 Class Initialized
DEBUG - 2018-02-13 06:42:43 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 06:42:43 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:42:43 --> Utf8 Class Initialized
INFO - 2018-02-13 06:42:43 --> URI Class Initialized
INFO - 2018-02-13 06:42:43 --> Utf8 Class Initialized
INFO - 2018-02-13 06:42:43 --> Config Class Initialized
INFO - 2018-02-13 06:42:43 --> URI Class Initialized
INFO - 2018-02-13 06:42:43 --> Hooks Class Initialized
INFO - 2018-02-13 06:42:43 --> URI Class Initialized
INFO - 2018-02-13 06:42:43 --> Router Class Initialized
INFO - 2018-02-13 06:42:43 --> Router Class Initialized
INFO - 2018-02-13 06:42:43 --> Router Class Initialized
INFO - 2018-02-13 06:42:43 --> Output Class Initialized
DEBUG - 2018-02-13 06:42:43 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:42:43 --> Utf8 Class Initialized
INFO - 2018-02-13 06:42:43 --> Output Class Initialized
INFO - 2018-02-13 06:42:43 --> Security Class Initialized
INFO - 2018-02-13 06:42:43 --> Output Class Initialized
INFO - 2018-02-13 06:42:43 --> URI Class Initialized
INFO - 2018-02-13 06:42:43 --> Security Class Initialized
DEBUG - 2018-02-13 06:42:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:42:44 --> Security Class Initialized
INFO - 2018-02-13 06:42:44 --> Input Class Initialized
INFO - 2018-02-13 06:42:44 --> Router Class Initialized
INFO - 2018-02-13 06:42:44 --> Language Class Initialized
DEBUG - 2018-02-13 06:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:42:44 --> Input Class Initialized
DEBUG - 2018-02-13 06:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:42:44 --> Input Class Initialized
INFO - 2018-02-13 06:42:44 --> Language Class Initialized
INFO - 2018-02-13 06:42:44 --> Output Class Initialized
ERROR - 2018-02-13 06:42:44 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-13 06:42:44 --> Language Class Initialized
ERROR - 2018-02-13 06:42:44 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-13 06:42:44 --> Security Class Initialized
ERROR - 2018-02-13 06:42:44 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-02-13 06:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:42:44 --> Input Class Initialized
INFO - 2018-02-13 06:42:44 --> Language Class Initialized
ERROR - 2018-02-13 06:42:44 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-13 06:42:44 --> Config Class Initialized
INFO - 2018-02-13 06:42:44 --> Hooks Class Initialized
INFO - 2018-02-13 06:42:44 --> Config Class Initialized
INFO - 2018-02-13 06:42:44 --> Hooks Class Initialized
INFO - 2018-02-13 06:42:44 --> Config Class Initialized
INFO - 2018-02-13 06:42:44 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:42:44 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:42:44 --> Utf8 Class Initialized
DEBUG - 2018-02-13 06:42:44 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:42:44 --> Utf8 Class Initialized
INFO - 2018-02-13 06:42:44 --> URI Class Initialized
DEBUG - 2018-02-13 06:42:44 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:42:44 --> Utf8 Class Initialized
INFO - 2018-02-13 06:42:44 --> URI Class Initialized
INFO - 2018-02-13 06:42:44 --> URI Class Initialized
INFO - 2018-02-13 06:42:44 --> Router Class Initialized
INFO - 2018-02-13 06:42:44 --> Router Class Initialized
INFO - 2018-02-13 06:42:44 --> Output Class Initialized
INFO - 2018-02-13 06:42:44 --> Router Class Initialized
INFO - 2018-02-13 06:42:44 --> Output Class Initialized
INFO - 2018-02-13 06:42:44 --> Security Class Initialized
INFO - 2018-02-13 06:42:44 --> Output Class Initialized
INFO - 2018-02-13 06:42:44 --> Security Class Initialized
DEBUG - 2018-02-13 06:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:42:44 --> Input Class Initialized
INFO - 2018-02-13 06:42:44 --> Security Class Initialized
INFO - 2018-02-13 06:42:44 --> Language Class Initialized
DEBUG - 2018-02-13 06:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:42:44 --> Input Class Initialized
DEBUG - 2018-02-13 06:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:42:44 --> Input Class Initialized
ERROR - 2018-02-13 06:42:44 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-13 06:42:44 --> Language Class Initialized
INFO - 2018-02-13 06:42:44 --> Language Class Initialized
ERROR - 2018-02-13 06:42:44 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-13 06:42:44 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-13 06:42:44 --> Config Class Initialized
INFO - 2018-02-13 06:42:44 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:42:44 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:42:44 --> Utf8 Class Initialized
INFO - 2018-02-13 06:42:44 --> URI Class Initialized
INFO - 2018-02-13 06:42:44 --> Router Class Initialized
INFO - 2018-02-13 06:42:44 --> Output Class Initialized
INFO - 2018-02-13 06:42:44 --> Security Class Initialized
DEBUG - 2018-02-13 06:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:42:44 --> Input Class Initialized
INFO - 2018-02-13 06:42:44 --> Language Class Initialized
INFO - 2018-02-13 06:42:44 --> Loader Class Initialized
INFO - 2018-02-13 06:42:44 --> Helper loaded: url_helper
INFO - 2018-02-13 06:42:44 --> Helper loaded: form_helper
INFO - 2018-02-13 06:42:44 --> Database Driver Class Initialized
DEBUG - 2018-02-13 06:42:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 06:42:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:42:44 --> Form Validation Class Initialized
INFO - 2018-02-13 06:42:44 --> Model Class Initialized
INFO - 2018-02-13 06:42:44 --> Controller Class Initialized
INFO - 2018-02-13 06:42:44 --> Model Class Initialized
INFO - 2018-02-13 06:42:44 --> Model Class Initialized
INFO - 2018-02-13 06:42:44 --> Model Class Initialized
INFO - 2018-02-13 06:42:44 --> Model Class Initialized
INFO - 2018-02-13 06:42:44 --> Model Class Initialized
DEBUG - 2018-02-13 06:42:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 06:42:45 --> Config Class Initialized
INFO - 2018-02-13 06:42:45 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:42:45 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:42:45 --> Utf8 Class Initialized
INFO - 2018-02-13 06:42:45 --> URI Class Initialized
INFO - 2018-02-13 06:42:45 --> Router Class Initialized
INFO - 2018-02-13 06:42:45 --> Output Class Initialized
INFO - 2018-02-13 06:42:45 --> Security Class Initialized
DEBUG - 2018-02-13 06:42:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:42:45 --> Input Class Initialized
INFO - 2018-02-13 06:42:45 --> Language Class Initialized
INFO - 2018-02-13 06:42:45 --> Loader Class Initialized
INFO - 2018-02-13 06:42:45 --> Helper loaded: url_helper
INFO - 2018-02-13 06:42:45 --> Helper loaded: form_helper
INFO - 2018-02-13 06:42:45 --> Database Driver Class Initialized
DEBUG - 2018-02-13 06:42:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 06:42:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:42:45 --> Form Validation Class Initialized
INFO - 2018-02-13 06:42:45 --> Model Class Initialized
INFO - 2018-02-13 06:42:45 --> Controller Class Initialized
INFO - 2018-02-13 06:42:45 --> Model Class Initialized
INFO - 2018-02-13 06:42:45 --> Model Class Initialized
INFO - 2018-02-13 06:42:45 --> Model Class Initialized
INFO - 2018-02-13 06:42:45 --> Model Class Initialized
INFO - 2018-02-13 06:42:45 --> Model Class Initialized
DEBUG - 2018-02-13 06:42:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 06:42:45 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 06:42:45 --> Final output sent to browser
DEBUG - 2018-02-13 06:42:45 --> Total execution time: 0.1077
INFO - 2018-02-13 06:42:45 --> Config Class Initialized
INFO - 2018-02-13 06:42:45 --> Config Class Initialized
INFO - 2018-02-13 06:42:45 --> Hooks Class Initialized
INFO - 2018-02-13 06:42:45 --> Hooks Class Initialized
INFO - 2018-02-13 06:42:45 --> Config Class Initialized
INFO - 2018-02-13 06:42:45 --> Hooks Class Initialized
INFO - 2018-02-13 06:42:45 --> Config Class Initialized
INFO - 2018-02-13 06:42:45 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:42:45 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:42:45 --> Utf8 Class Initialized
DEBUG - 2018-02-13 06:42:45 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:42:45 --> Utf8 Class Initialized
DEBUG - 2018-02-13 06:42:45 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:42:45 --> Utf8 Class Initialized
INFO - 2018-02-13 06:42:45 --> URI Class Initialized
INFO - 2018-02-13 06:42:45 --> URI Class Initialized
DEBUG - 2018-02-13 06:42:45 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:42:45 --> URI Class Initialized
INFO - 2018-02-13 06:42:45 --> Utf8 Class Initialized
INFO - 2018-02-13 06:42:45 --> Router Class Initialized
INFO - 2018-02-13 06:42:45 --> Router Class Initialized
INFO - 2018-02-13 06:42:45 --> URI Class Initialized
INFO - 2018-02-13 06:42:45 --> Router Class Initialized
INFO - 2018-02-13 06:42:45 --> Output Class Initialized
INFO - 2018-02-13 06:42:45 --> Output Class Initialized
INFO - 2018-02-13 06:42:45 --> Router Class Initialized
INFO - 2018-02-13 06:42:45 --> Output Class Initialized
INFO - 2018-02-13 06:42:45 --> Security Class Initialized
INFO - 2018-02-13 06:42:45 --> Security Class Initialized
INFO - 2018-02-13 06:42:45 --> Output Class Initialized
DEBUG - 2018-02-13 06:42:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:42:45 --> Security Class Initialized
INFO - 2018-02-13 06:42:45 --> Input Class Initialized
DEBUG - 2018-02-13 06:42:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:42:45 --> Input Class Initialized
INFO - 2018-02-13 06:42:45 --> Security Class Initialized
INFO - 2018-02-13 06:42:45 --> Language Class Initialized
DEBUG - 2018-02-13 06:42:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:42:45 --> Language Class Initialized
INFO - 2018-02-13 06:42:45 --> Input Class Initialized
DEBUG - 2018-02-13 06:42:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:42:45 --> Input Class Initialized
INFO - 2018-02-13 06:42:45 --> Language Class Initialized
ERROR - 2018-02-13 06:42:45 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-13 06:42:45 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-13 06:42:45 --> Language Class Initialized
ERROR - 2018-02-13 06:42:45 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-13 06:42:45 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-13 06:42:45 --> Config Class Initialized
INFO - 2018-02-13 06:42:45 --> Hooks Class Initialized
INFO - 2018-02-13 06:42:45 --> Config Class Initialized
INFO - 2018-02-13 06:42:45 --> Config Class Initialized
INFO - 2018-02-13 06:42:45 --> Hooks Class Initialized
INFO - 2018-02-13 06:42:45 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:42:45 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:42:45 --> Utf8 Class Initialized
DEBUG - 2018-02-13 06:42:45 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 06:42:45 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:42:45 --> URI Class Initialized
INFO - 2018-02-13 06:42:45 --> Utf8 Class Initialized
INFO - 2018-02-13 06:42:45 --> Utf8 Class Initialized
INFO - 2018-02-13 06:42:45 --> URI Class Initialized
INFO - 2018-02-13 06:42:45 --> URI Class Initialized
INFO - 2018-02-13 06:42:45 --> Router Class Initialized
INFO - 2018-02-13 06:42:45 --> Router Class Initialized
INFO - 2018-02-13 06:42:45 --> Router Class Initialized
INFO - 2018-02-13 06:42:45 --> Output Class Initialized
INFO - 2018-02-13 06:42:45 --> Output Class Initialized
INFO - 2018-02-13 06:42:45 --> Security Class Initialized
INFO - 2018-02-13 06:42:45 --> Output Class Initialized
INFO - 2018-02-13 06:42:45 --> Security Class Initialized
DEBUG - 2018-02-13 06:42:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:42:45 --> Security Class Initialized
INFO - 2018-02-13 06:42:45 --> Input Class Initialized
INFO - 2018-02-13 06:42:45 --> Language Class Initialized
DEBUG - 2018-02-13 06:42:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 06:42:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:42:45 --> Input Class Initialized
INFO - 2018-02-13 06:42:45 --> Input Class Initialized
ERROR - 2018-02-13 06:42:45 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-13 06:42:45 --> Language Class Initialized
INFO - 2018-02-13 06:42:45 --> Language Class Initialized
ERROR - 2018-02-13 06:42:45 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-13 06:42:45 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-13 06:42:45 --> Config Class Initialized
INFO - 2018-02-13 06:42:45 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:42:45 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:42:45 --> Utf8 Class Initialized
INFO - 2018-02-13 06:42:45 --> URI Class Initialized
INFO - 2018-02-13 06:42:45 --> Router Class Initialized
INFO - 2018-02-13 06:42:45 --> Output Class Initialized
INFO - 2018-02-13 06:42:45 --> Security Class Initialized
DEBUG - 2018-02-13 06:42:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:42:45 --> Input Class Initialized
INFO - 2018-02-13 06:42:45 --> Language Class Initialized
INFO - 2018-02-13 06:42:45 --> Loader Class Initialized
INFO - 2018-02-13 06:42:45 --> Helper loaded: url_helper
INFO - 2018-02-13 06:42:45 --> Helper loaded: form_helper
INFO - 2018-02-13 06:42:45 --> Database Driver Class Initialized
DEBUG - 2018-02-13 06:42:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 06:42:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:42:45 --> Form Validation Class Initialized
INFO - 2018-02-13 06:42:45 --> Model Class Initialized
INFO - 2018-02-13 06:42:45 --> Controller Class Initialized
INFO - 2018-02-13 06:42:45 --> Model Class Initialized
INFO - 2018-02-13 06:42:45 --> Model Class Initialized
INFO - 2018-02-13 06:42:45 --> Model Class Initialized
INFO - 2018-02-13 06:42:45 --> Model Class Initialized
INFO - 2018-02-13 06:42:45 --> Model Class Initialized
DEBUG - 2018-02-13 06:42:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 06:42:55 --> Config Class Initialized
INFO - 2018-02-13 06:42:55 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:42:55 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:42:55 --> Utf8 Class Initialized
INFO - 2018-02-13 06:42:55 --> URI Class Initialized
INFO - 2018-02-13 06:42:55 --> Router Class Initialized
INFO - 2018-02-13 06:42:55 --> Output Class Initialized
INFO - 2018-02-13 06:42:55 --> Security Class Initialized
DEBUG - 2018-02-13 06:42:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:42:55 --> Input Class Initialized
INFO - 2018-02-13 06:42:55 --> Language Class Initialized
INFO - 2018-02-13 06:42:55 --> Loader Class Initialized
INFO - 2018-02-13 06:42:55 --> Helper loaded: url_helper
INFO - 2018-02-13 06:42:55 --> Helper loaded: form_helper
INFO - 2018-02-13 06:42:55 --> Database Driver Class Initialized
DEBUG - 2018-02-13 06:42:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 06:42:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:42:55 --> Form Validation Class Initialized
INFO - 2018-02-13 06:42:55 --> Model Class Initialized
INFO - 2018-02-13 06:42:55 --> Controller Class Initialized
INFO - 2018-02-13 06:42:55 --> Model Class Initialized
INFO - 2018-02-13 06:42:55 --> Model Class Initialized
INFO - 2018-02-13 06:42:55 --> Model Class Initialized
INFO - 2018-02-13 06:42:55 --> Model Class Initialized
INFO - 2018-02-13 06:42:55 --> Model Class Initialized
DEBUG - 2018-02-13 06:42:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 06:42:55 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 06:42:55 --> Final output sent to browser
DEBUG - 2018-02-13 06:42:55 --> Total execution time: 0.1121
INFO - 2018-02-13 06:42:55 --> Config Class Initialized
INFO - 2018-02-13 06:42:55 --> Hooks Class Initialized
INFO - 2018-02-13 06:42:55 --> Config Class Initialized
INFO - 2018-02-13 06:42:55 --> Hooks Class Initialized
INFO - 2018-02-13 06:42:55 --> Config Class Initialized
INFO - 2018-02-13 06:42:55 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:42:55 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:42:55 --> Utf8 Class Initialized
DEBUG - 2018-02-13 06:42:55 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 06:42:55 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:42:55 --> Utf8 Class Initialized
INFO - 2018-02-13 06:42:55 --> Utf8 Class Initialized
INFO - 2018-02-13 06:42:55 --> URI Class Initialized
INFO - 2018-02-13 06:42:55 --> Config Class Initialized
INFO - 2018-02-13 06:42:55 --> Hooks Class Initialized
INFO - 2018-02-13 06:42:55 --> URI Class Initialized
INFO - 2018-02-13 06:42:55 --> URI Class Initialized
INFO - 2018-02-13 06:42:55 --> Router Class Initialized
INFO - 2018-02-13 06:42:55 --> Router Class Initialized
INFO - 2018-02-13 06:42:55 --> Router Class Initialized
INFO - 2018-02-13 06:42:55 --> Output Class Initialized
INFO - 2018-02-13 06:42:55 --> Output Class Initialized
INFO - 2018-02-13 06:42:55 --> Output Class Initialized
INFO - 2018-02-13 06:42:55 --> Security Class Initialized
DEBUG - 2018-02-13 06:42:55 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:42:55 --> Utf8 Class Initialized
INFO - 2018-02-13 06:42:55 --> Security Class Initialized
INFO - 2018-02-13 06:42:55 --> Security Class Initialized
DEBUG - 2018-02-13 06:42:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:42:55 --> URI Class Initialized
INFO - 2018-02-13 06:42:55 --> Input Class Initialized
DEBUG - 2018-02-13 06:42:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:42:55 --> Input Class Initialized
INFO - 2018-02-13 06:42:55 --> Language Class Initialized
DEBUG - 2018-02-13 06:42:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:42:55 --> Language Class Initialized
INFO - 2018-02-13 06:42:55 --> Input Class Initialized
INFO - 2018-02-13 06:42:55 --> Router Class Initialized
ERROR - 2018-02-13 06:42:55 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-13 06:42:55 --> Language Class Initialized
ERROR - 2018-02-13 06:42:55 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-13 06:42:55 --> Output Class Initialized
ERROR - 2018-02-13 06:42:55 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-13 06:42:55 --> Security Class Initialized
DEBUG - 2018-02-13 06:42:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:42:55 --> Input Class Initialized
INFO - 2018-02-13 06:42:55 --> Language Class Initialized
ERROR - 2018-02-13 06:42:55 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-13 06:42:55 --> Config Class Initialized
INFO - 2018-02-13 06:42:55 --> Config Class Initialized
INFO - 2018-02-13 06:42:55 --> Hooks Class Initialized
INFO - 2018-02-13 06:42:55 --> Config Class Initialized
INFO - 2018-02-13 06:42:55 --> Hooks Class Initialized
INFO - 2018-02-13 06:42:55 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:42:55 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:42:55 --> Utf8 Class Initialized
DEBUG - 2018-02-13 06:42:55 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 06:42:55 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:42:55 --> Utf8 Class Initialized
INFO - 2018-02-13 06:42:55 --> Utf8 Class Initialized
INFO - 2018-02-13 06:42:55 --> URI Class Initialized
INFO - 2018-02-13 06:42:55 --> URI Class Initialized
INFO - 2018-02-13 06:42:55 --> URI Class Initialized
INFO - 2018-02-13 06:42:55 --> Router Class Initialized
INFO - 2018-02-13 06:42:55 --> Router Class Initialized
INFO - 2018-02-13 06:42:55 --> Router Class Initialized
INFO - 2018-02-13 06:42:55 --> Output Class Initialized
INFO - 2018-02-13 06:42:55 --> Output Class Initialized
INFO - 2018-02-13 06:42:55 --> Output Class Initialized
INFO - 2018-02-13 06:42:55 --> Security Class Initialized
INFO - 2018-02-13 06:42:55 --> Security Class Initialized
INFO - 2018-02-13 06:42:55 --> Security Class Initialized
DEBUG - 2018-02-13 06:42:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 06:42:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 06:42:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:42:55 --> Input Class Initialized
INFO - 2018-02-13 06:42:55 --> Input Class Initialized
INFO - 2018-02-13 06:42:55 --> Input Class Initialized
INFO - 2018-02-13 06:42:55 --> Language Class Initialized
INFO - 2018-02-13 06:42:55 --> Language Class Initialized
INFO - 2018-02-13 06:42:55 --> Language Class Initialized
ERROR - 2018-02-13 06:42:55 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-13 06:42:55 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-13 06:42:55 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-13 06:42:55 --> Config Class Initialized
INFO - 2018-02-13 06:42:55 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:42:55 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:42:55 --> Utf8 Class Initialized
INFO - 2018-02-13 06:42:55 --> URI Class Initialized
INFO - 2018-02-13 06:42:55 --> Router Class Initialized
INFO - 2018-02-13 06:42:55 --> Output Class Initialized
INFO - 2018-02-13 06:42:55 --> Security Class Initialized
DEBUG - 2018-02-13 06:42:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:42:55 --> Input Class Initialized
INFO - 2018-02-13 06:42:55 --> Language Class Initialized
INFO - 2018-02-13 06:42:55 --> Loader Class Initialized
INFO - 2018-02-13 06:42:55 --> Helper loaded: url_helper
INFO - 2018-02-13 06:42:55 --> Helper loaded: form_helper
INFO - 2018-02-13 06:42:55 --> Database Driver Class Initialized
DEBUG - 2018-02-13 06:42:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 06:42:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:42:55 --> Form Validation Class Initialized
INFO - 2018-02-13 06:42:55 --> Model Class Initialized
INFO - 2018-02-13 06:42:55 --> Controller Class Initialized
INFO - 2018-02-13 06:42:55 --> Model Class Initialized
INFO - 2018-02-13 06:42:55 --> Model Class Initialized
INFO - 2018-02-13 06:42:55 --> Model Class Initialized
INFO - 2018-02-13 06:42:55 --> Model Class Initialized
INFO - 2018-02-13 06:42:55 --> Model Class Initialized
DEBUG - 2018-02-13 06:42:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 06:43:22 --> Config Class Initialized
INFO - 2018-02-13 06:43:22 --> Config Class Initialized
INFO - 2018-02-13 06:43:22 --> Hooks Class Initialized
INFO - 2018-02-13 06:43:22 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:43:22 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:43:22 --> Utf8 Class Initialized
DEBUG - 2018-02-13 06:43:22 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:43:22 --> Utf8 Class Initialized
INFO - 2018-02-13 06:43:22 --> URI Class Initialized
INFO - 2018-02-13 06:43:22 --> URI Class Initialized
INFO - 2018-02-13 06:43:22 --> Router Class Initialized
INFO - 2018-02-13 06:43:22 --> Router Class Initialized
INFO - 2018-02-13 06:43:22 --> Output Class Initialized
INFO - 2018-02-13 06:43:22 --> Output Class Initialized
INFO - 2018-02-13 06:43:22 --> Security Class Initialized
INFO - 2018-02-13 06:43:22 --> Security Class Initialized
DEBUG - 2018-02-13 06:43:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 06:43:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:43:22 --> Input Class Initialized
INFO - 2018-02-13 06:43:22 --> Input Class Initialized
INFO - 2018-02-13 06:43:22 --> Language Class Initialized
INFO - 2018-02-13 06:43:22 --> Language Class Initialized
INFO - 2018-02-13 06:43:22 --> Loader Class Initialized
INFO - 2018-02-13 06:43:22 --> Loader Class Initialized
INFO - 2018-02-13 06:43:22 --> Helper loaded: url_helper
INFO - 2018-02-13 06:43:22 --> Helper loaded: url_helper
INFO - 2018-02-13 06:43:22 --> Helper loaded: form_helper
INFO - 2018-02-13 06:43:22 --> Helper loaded: form_helper
INFO - 2018-02-13 06:43:22 --> Database Driver Class Initialized
INFO - 2018-02-13 06:43:22 --> Database Driver Class Initialized
DEBUG - 2018-02-13 06:43:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 06:43:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 06:43:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:43:22 --> Form Validation Class Initialized
INFO - 2018-02-13 06:43:22 --> Model Class Initialized
INFO - 2018-02-13 06:43:22 --> Controller Class Initialized
INFO - 2018-02-13 06:43:22 --> Model Class Initialized
INFO - 2018-02-13 06:43:22 --> Model Class Initialized
INFO - 2018-02-13 06:43:22 --> Model Class Initialized
INFO - 2018-02-13 06:43:22 --> Model Class Initialized
INFO - 2018-02-13 06:43:22 --> Model Class Initialized
DEBUG - 2018-02-13 06:43:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 06:43:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:43:22 --> Form Validation Class Initialized
INFO - 2018-02-13 06:43:22 --> Model Class Initialized
INFO - 2018-02-13 06:43:22 --> Controller Class Initialized
INFO - 2018-02-13 06:43:22 --> Model Class Initialized
INFO - 2018-02-13 06:43:22 --> Model Class Initialized
INFO - 2018-02-13 06:43:22 --> Model Class Initialized
INFO - 2018-02-13 06:43:22 --> Model Class Initialized
INFO - 2018-02-13 06:43:22 --> Model Class Initialized
DEBUG - 2018-02-13 06:43:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 06:43:38 --> Config Class Initialized
INFO - 2018-02-13 06:43:38 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:43:38 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:43:38 --> Utf8 Class Initialized
INFO - 2018-02-13 06:43:38 --> URI Class Initialized
INFO - 2018-02-13 06:43:38 --> Router Class Initialized
INFO - 2018-02-13 06:43:38 --> Output Class Initialized
INFO - 2018-02-13 06:43:38 --> Security Class Initialized
DEBUG - 2018-02-13 06:43:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:43:38 --> Input Class Initialized
INFO - 2018-02-13 06:43:38 --> Language Class Initialized
INFO - 2018-02-13 06:43:38 --> Loader Class Initialized
INFO - 2018-02-13 06:43:38 --> Helper loaded: url_helper
INFO - 2018-02-13 06:43:38 --> Helper loaded: form_helper
INFO - 2018-02-13 06:43:38 --> Database Driver Class Initialized
DEBUG - 2018-02-13 06:43:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 06:43:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:43:38 --> Form Validation Class Initialized
INFO - 2018-02-13 06:43:38 --> Model Class Initialized
INFO - 2018-02-13 06:43:38 --> Controller Class Initialized
INFO - 2018-02-13 06:43:38 --> Model Class Initialized
INFO - 2018-02-13 06:43:38 --> Model Class Initialized
INFO - 2018-02-13 06:43:38 --> Model Class Initialized
INFO - 2018-02-13 06:43:38 --> Model Class Initialized
INFO - 2018-02-13 06:43:38 --> Model Class Initialized
DEBUG - 2018-02-13 06:43:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 06:43:38 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 06:43:38 --> Final output sent to browser
DEBUG - 2018-02-13 06:43:38 --> Total execution time: 0.1140
INFO - 2018-02-13 06:43:38 --> Config Class Initialized
INFO - 2018-02-13 06:43:38 --> Hooks Class Initialized
INFO - 2018-02-13 06:43:38 --> Config Class Initialized
INFO - 2018-02-13 06:43:38 --> Hooks Class Initialized
INFO - 2018-02-13 06:43:38 --> Config Class Initialized
INFO - 2018-02-13 06:43:38 --> Hooks Class Initialized
INFO - 2018-02-13 06:43:38 --> Config Class Initialized
INFO - 2018-02-13 06:43:38 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:43:38 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:43:38 --> Utf8 Class Initialized
DEBUG - 2018-02-13 06:43:38 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:43:38 --> Utf8 Class Initialized
INFO - 2018-02-13 06:43:38 --> URI Class Initialized
DEBUG - 2018-02-13 06:43:38 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:43:38 --> URI Class Initialized
INFO - 2018-02-13 06:43:38 --> Utf8 Class Initialized
DEBUG - 2018-02-13 06:43:38 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:43:38 --> Utf8 Class Initialized
INFO - 2018-02-13 06:43:38 --> URI Class Initialized
INFO - 2018-02-13 06:43:38 --> Router Class Initialized
INFO - 2018-02-13 06:43:38 --> URI Class Initialized
INFO - 2018-02-13 06:43:38 --> Router Class Initialized
INFO - 2018-02-13 06:43:38 --> Router Class Initialized
INFO - 2018-02-13 06:43:38 --> Router Class Initialized
INFO - 2018-02-13 06:43:38 --> Output Class Initialized
INFO - 2018-02-13 06:43:38 --> Output Class Initialized
INFO - 2018-02-13 06:43:38 --> Security Class Initialized
INFO - 2018-02-13 06:43:38 --> Output Class Initialized
INFO - 2018-02-13 06:43:38 --> Output Class Initialized
INFO - 2018-02-13 06:43:38 --> Security Class Initialized
DEBUG - 2018-02-13 06:43:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:43:38 --> Input Class Initialized
INFO - 2018-02-13 06:43:38 --> Security Class Initialized
INFO - 2018-02-13 06:43:38 --> Security Class Initialized
INFO - 2018-02-13 06:43:38 --> Language Class Initialized
DEBUG - 2018-02-13 06:43:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:43:38 --> Input Class Initialized
DEBUG - 2018-02-13 06:43:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 06:43:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:43:38 --> Language Class Initialized
ERROR - 2018-02-13 06:43:38 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-13 06:43:38 --> Input Class Initialized
INFO - 2018-02-13 06:43:38 --> Input Class Initialized
INFO - 2018-02-13 06:43:38 --> Language Class Initialized
INFO - 2018-02-13 06:43:38 --> Language Class Initialized
ERROR - 2018-02-13 06:43:38 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-13 06:43:38 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-13 06:43:38 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-13 06:43:38 --> Config Class Initialized
INFO - 2018-02-13 06:43:38 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:43:38 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:43:38 --> Utf8 Class Initialized
INFO - 2018-02-13 06:43:38 --> Config Class Initialized
INFO - 2018-02-13 06:43:38 --> Config Class Initialized
INFO - 2018-02-13 06:43:38 --> Hooks Class Initialized
INFO - 2018-02-13 06:43:38 --> Hooks Class Initialized
INFO - 2018-02-13 06:43:38 --> URI Class Initialized
INFO - 2018-02-13 06:43:38 --> Router Class Initialized
DEBUG - 2018-02-13 06:43:38 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:43:38 --> Utf8 Class Initialized
DEBUG - 2018-02-13 06:43:38 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:43:38 --> Utf8 Class Initialized
INFO - 2018-02-13 06:43:38 --> URI Class Initialized
INFO - 2018-02-13 06:43:39 --> Output Class Initialized
INFO - 2018-02-13 06:43:39 --> URI Class Initialized
INFO - 2018-02-13 06:43:39 --> Router Class Initialized
INFO - 2018-02-13 06:43:39 --> Security Class Initialized
INFO - 2018-02-13 06:43:39 --> Router Class Initialized
DEBUG - 2018-02-13 06:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:43:39 --> Input Class Initialized
INFO - 2018-02-13 06:43:39 --> Output Class Initialized
INFO - 2018-02-13 06:43:39 --> Output Class Initialized
INFO - 2018-02-13 06:43:39 --> Language Class Initialized
INFO - 2018-02-13 06:43:39 --> Security Class Initialized
INFO - 2018-02-13 06:43:39 --> Security Class Initialized
ERROR - 2018-02-13 06:43:39 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-02-13 06:43:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 06:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:43:39 --> Input Class Initialized
INFO - 2018-02-13 06:43:39 --> Input Class Initialized
INFO - 2018-02-13 06:43:39 --> Language Class Initialized
INFO - 2018-02-13 06:43:39 --> Language Class Initialized
ERROR - 2018-02-13 06:43:39 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-13 06:43:39 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-13 06:43:39 --> Config Class Initialized
INFO - 2018-02-13 06:43:39 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:43:39 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:43:39 --> Utf8 Class Initialized
INFO - 2018-02-13 06:43:39 --> URI Class Initialized
INFO - 2018-02-13 06:43:39 --> Router Class Initialized
INFO - 2018-02-13 06:43:39 --> Output Class Initialized
INFO - 2018-02-13 06:43:39 --> Security Class Initialized
DEBUG - 2018-02-13 06:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:43:39 --> Input Class Initialized
INFO - 2018-02-13 06:43:39 --> Language Class Initialized
INFO - 2018-02-13 06:43:39 --> Loader Class Initialized
INFO - 2018-02-13 06:43:39 --> Helper loaded: url_helper
INFO - 2018-02-13 06:43:39 --> Helper loaded: form_helper
INFO - 2018-02-13 06:43:39 --> Database Driver Class Initialized
DEBUG - 2018-02-13 06:43:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 06:43:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:43:39 --> Form Validation Class Initialized
INFO - 2018-02-13 06:43:39 --> Model Class Initialized
INFO - 2018-02-13 06:43:39 --> Controller Class Initialized
INFO - 2018-02-13 06:43:39 --> Model Class Initialized
INFO - 2018-02-13 06:43:39 --> Model Class Initialized
INFO - 2018-02-13 06:43:39 --> Model Class Initialized
INFO - 2018-02-13 06:43:39 --> Model Class Initialized
INFO - 2018-02-13 06:43:39 --> Model Class Initialized
DEBUG - 2018-02-13 06:43:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 06:43:54 --> Config Class Initialized
INFO - 2018-02-13 06:43:54 --> Hooks Class Initialized
INFO - 2018-02-13 06:43:54 --> Config Class Initialized
INFO - 2018-02-13 06:43:54 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:43:54 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 06:43:54 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:43:54 --> Utf8 Class Initialized
INFO - 2018-02-13 06:43:54 --> Utf8 Class Initialized
INFO - 2018-02-13 06:43:54 --> URI Class Initialized
INFO - 2018-02-13 06:43:54 --> URI Class Initialized
INFO - 2018-02-13 06:43:54 --> Router Class Initialized
INFO - 2018-02-13 06:43:54 --> Router Class Initialized
INFO - 2018-02-13 06:43:54 --> Output Class Initialized
INFO - 2018-02-13 06:43:54 --> Output Class Initialized
INFO - 2018-02-13 06:43:54 --> Security Class Initialized
INFO - 2018-02-13 06:43:54 --> Security Class Initialized
DEBUG - 2018-02-13 06:43:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 06:43:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:43:54 --> Input Class Initialized
INFO - 2018-02-13 06:43:54 --> Input Class Initialized
INFO - 2018-02-13 06:43:54 --> Language Class Initialized
INFO - 2018-02-13 06:43:54 --> Language Class Initialized
INFO - 2018-02-13 06:43:54 --> Loader Class Initialized
INFO - 2018-02-13 06:43:54 --> Loader Class Initialized
INFO - 2018-02-13 06:43:54 --> Helper loaded: url_helper
INFO - 2018-02-13 06:43:54 --> Helper loaded: url_helper
INFO - 2018-02-13 06:43:54 --> Helper loaded: form_helper
INFO - 2018-02-13 06:43:54 --> Helper loaded: form_helper
INFO - 2018-02-13 06:43:54 --> Database Driver Class Initialized
INFO - 2018-02-13 06:43:54 --> Database Driver Class Initialized
DEBUG - 2018-02-13 06:43:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 06:43:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-02-13 06:43:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 06:43:54 --> Form Validation Class Initialized
INFO - 2018-02-13 06:43:54 --> Model Class Initialized
INFO - 2018-02-13 06:43:54 --> Controller Class Initialized
INFO - 2018-02-13 06:43:54 --> Model Class Initialized
INFO - 2018-02-13 06:43:54 --> Model Class Initialized
INFO - 2018-02-13 06:43:54 --> Model Class Initialized
INFO - 2018-02-13 06:43:54 --> Model Class Initialized
INFO - 2018-02-13 06:43:54 --> Model Class Initialized
DEBUG - 2018-02-13 06:43:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 06:43:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:43:55 --> Form Validation Class Initialized
INFO - 2018-02-13 06:43:55 --> Model Class Initialized
INFO - 2018-02-13 06:43:55 --> Controller Class Initialized
INFO - 2018-02-13 06:43:55 --> Model Class Initialized
INFO - 2018-02-13 06:43:55 --> Model Class Initialized
INFO - 2018-02-13 06:43:55 --> Model Class Initialized
INFO - 2018-02-13 06:43:55 --> Model Class Initialized
INFO - 2018-02-13 06:43:55 --> Model Class Initialized
DEBUG - 2018-02-13 06:43:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 06:44:21 --> Config Class Initialized
INFO - 2018-02-13 06:44:21 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:44:21 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:44:21 --> Utf8 Class Initialized
INFO - 2018-02-13 06:44:21 --> URI Class Initialized
INFO - 2018-02-13 06:44:21 --> Router Class Initialized
INFO - 2018-02-13 06:44:21 --> Output Class Initialized
INFO - 2018-02-13 06:44:21 --> Security Class Initialized
DEBUG - 2018-02-13 06:44:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:44:21 --> Input Class Initialized
INFO - 2018-02-13 06:44:21 --> Language Class Initialized
INFO - 2018-02-13 06:44:21 --> Loader Class Initialized
INFO - 2018-02-13 06:44:21 --> Helper loaded: url_helper
INFO - 2018-02-13 06:44:21 --> Helper loaded: form_helper
INFO - 2018-02-13 06:44:21 --> Database Driver Class Initialized
DEBUG - 2018-02-13 06:44:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 06:44:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:44:21 --> Form Validation Class Initialized
INFO - 2018-02-13 06:44:21 --> Model Class Initialized
INFO - 2018-02-13 06:44:21 --> Controller Class Initialized
INFO - 2018-02-13 06:44:21 --> Model Class Initialized
INFO - 2018-02-13 06:44:21 --> Model Class Initialized
INFO - 2018-02-13 06:44:21 --> Model Class Initialized
INFO - 2018-02-13 06:44:21 --> Model Class Initialized
INFO - 2018-02-13 06:44:21 --> Model Class Initialized
DEBUG - 2018-02-13 06:44:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 06:44:21 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 06:44:21 --> Final output sent to browser
DEBUG - 2018-02-13 06:44:21 --> Total execution time: 0.1384
INFO - 2018-02-13 06:44:21 --> Config Class Initialized
INFO - 2018-02-13 06:44:21 --> Hooks Class Initialized
INFO - 2018-02-13 06:44:21 --> Config Class Initialized
INFO - 2018-02-13 06:44:21 --> Config Class Initialized
INFO - 2018-02-13 06:44:21 --> Hooks Class Initialized
INFO - 2018-02-13 06:44:21 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:44:21 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:44:21 --> Utf8 Class Initialized
DEBUG - 2018-02-13 06:44:21 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:44:21 --> Utf8 Class Initialized
DEBUG - 2018-02-13 06:44:21 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:44:21 --> Utf8 Class Initialized
INFO - 2018-02-13 06:44:21 --> URI Class Initialized
INFO - 2018-02-13 06:44:21 --> URI Class Initialized
INFO - 2018-02-13 06:44:21 --> URI Class Initialized
INFO - 2018-02-13 06:44:21 --> Router Class Initialized
INFO - 2018-02-13 06:44:21 --> Router Class Initialized
INFO - 2018-02-13 06:44:21 --> Router Class Initialized
INFO - 2018-02-13 06:44:21 --> Output Class Initialized
INFO - 2018-02-13 06:44:21 --> Output Class Initialized
INFO - 2018-02-13 06:44:21 --> Output Class Initialized
INFO - 2018-02-13 06:44:21 --> Security Class Initialized
INFO - 2018-02-13 06:44:21 --> Security Class Initialized
INFO - 2018-02-13 06:44:21 --> Security Class Initialized
DEBUG - 2018-02-13 06:44:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 06:44:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:44:21 --> Input Class Initialized
DEBUG - 2018-02-13 06:44:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:44:21 --> Input Class Initialized
INFO - 2018-02-13 06:44:21 --> Input Class Initialized
INFO - 2018-02-13 06:44:21 --> Language Class Initialized
INFO - 2018-02-13 06:44:21 --> Language Class Initialized
INFO - 2018-02-13 06:44:21 --> Language Class Initialized
ERROR - 2018-02-13 06:44:21 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-13 06:44:21 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-13 06:44:21 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-13 06:44:21 --> Config Class Initialized
INFO - 2018-02-13 06:44:21 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:44:21 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:44:21 --> Utf8 Class Initialized
INFO - 2018-02-13 06:44:21 --> URI Class Initialized
INFO - 2018-02-13 06:44:21 --> Router Class Initialized
INFO - 2018-02-13 06:44:21 --> Output Class Initialized
INFO - 2018-02-13 06:44:21 --> Security Class Initialized
DEBUG - 2018-02-13 06:44:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:44:21 --> Input Class Initialized
INFO - 2018-02-13 06:44:21 --> Language Class Initialized
ERROR - 2018-02-13 06:44:21 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-13 06:44:21 --> Config Class Initialized
INFO - 2018-02-13 06:44:21 --> Hooks Class Initialized
INFO - 2018-02-13 06:44:21 --> Config Class Initialized
INFO - 2018-02-13 06:44:21 --> Hooks Class Initialized
INFO - 2018-02-13 06:44:21 --> Config Class Initialized
INFO - 2018-02-13 06:44:21 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:44:21 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:44:21 --> Utf8 Class Initialized
INFO - 2018-02-13 06:44:21 --> URI Class Initialized
DEBUG - 2018-02-13 06:44:21 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 06:44:21 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:44:21 --> Utf8 Class Initialized
INFO - 2018-02-13 06:44:21 --> Utf8 Class Initialized
INFO - 2018-02-13 06:44:21 --> Router Class Initialized
INFO - 2018-02-13 06:44:21 --> URI Class Initialized
INFO - 2018-02-13 06:44:21 --> URI Class Initialized
INFO - 2018-02-13 06:44:21 --> Output Class Initialized
INFO - 2018-02-13 06:44:21 --> Router Class Initialized
INFO - 2018-02-13 06:44:21 --> Router Class Initialized
INFO - 2018-02-13 06:44:21 --> Security Class Initialized
INFO - 2018-02-13 06:44:21 --> Output Class Initialized
DEBUG - 2018-02-13 06:44:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:44:21 --> Input Class Initialized
INFO - 2018-02-13 06:44:21 --> Output Class Initialized
INFO - 2018-02-13 06:44:21 --> Security Class Initialized
INFO - 2018-02-13 06:44:21 --> Language Class Initialized
DEBUG - 2018-02-13 06:44:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:44:21 --> Input Class Initialized
ERROR - 2018-02-13 06:44:21 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-13 06:44:21 --> Security Class Initialized
INFO - 2018-02-13 06:44:21 --> Language Class Initialized
DEBUG - 2018-02-13 06:44:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-13 06:44:21 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-13 06:44:21 --> Input Class Initialized
INFO - 2018-02-13 06:44:21 --> Language Class Initialized
ERROR - 2018-02-13 06:44:21 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-13 06:44:21 --> Config Class Initialized
INFO - 2018-02-13 06:44:21 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:44:21 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:44:21 --> Utf8 Class Initialized
INFO - 2018-02-13 06:44:21 --> URI Class Initialized
INFO - 2018-02-13 06:44:21 --> Router Class Initialized
INFO - 2018-02-13 06:44:21 --> Output Class Initialized
INFO - 2018-02-13 06:44:21 --> Security Class Initialized
DEBUG - 2018-02-13 06:44:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:44:21 --> Input Class Initialized
INFO - 2018-02-13 06:44:21 --> Language Class Initialized
INFO - 2018-02-13 06:44:21 --> Loader Class Initialized
INFO - 2018-02-13 06:44:21 --> Helper loaded: url_helper
INFO - 2018-02-13 06:44:21 --> Helper loaded: form_helper
INFO - 2018-02-13 06:44:21 --> Database Driver Class Initialized
DEBUG - 2018-02-13 06:44:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 06:44:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:44:21 --> Form Validation Class Initialized
INFO - 2018-02-13 06:44:21 --> Model Class Initialized
INFO - 2018-02-13 06:44:21 --> Controller Class Initialized
INFO - 2018-02-13 06:44:21 --> Model Class Initialized
INFO - 2018-02-13 06:44:21 --> Model Class Initialized
INFO - 2018-02-13 06:44:21 --> Model Class Initialized
INFO - 2018-02-13 06:44:21 --> Model Class Initialized
INFO - 2018-02-13 06:44:21 --> Model Class Initialized
DEBUG - 2018-02-13 06:44:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 06:44:29 --> Config Class Initialized
INFO - 2018-02-13 06:44:29 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:44:29 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:44:29 --> Utf8 Class Initialized
INFO - 2018-02-13 06:44:29 --> URI Class Initialized
INFO - 2018-02-13 06:44:29 --> Router Class Initialized
INFO - 2018-02-13 06:44:29 --> Output Class Initialized
INFO - 2018-02-13 06:44:29 --> Security Class Initialized
DEBUG - 2018-02-13 06:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:44:29 --> Input Class Initialized
INFO - 2018-02-13 06:44:29 --> Language Class Initialized
INFO - 2018-02-13 06:44:29 --> Loader Class Initialized
INFO - 2018-02-13 06:44:29 --> Helper loaded: url_helper
INFO - 2018-02-13 06:44:29 --> Helper loaded: form_helper
INFO - 2018-02-13 06:44:29 --> Database Driver Class Initialized
DEBUG - 2018-02-13 06:44:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 06:44:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:44:29 --> Form Validation Class Initialized
INFO - 2018-02-13 06:44:29 --> Model Class Initialized
INFO - 2018-02-13 06:44:29 --> Controller Class Initialized
INFO - 2018-02-13 06:44:29 --> Model Class Initialized
INFO - 2018-02-13 06:44:29 --> Model Class Initialized
INFO - 2018-02-13 06:44:29 --> Model Class Initialized
INFO - 2018-02-13 06:44:29 --> Model Class Initialized
INFO - 2018-02-13 06:44:29 --> Model Class Initialized
DEBUG - 2018-02-13 06:44:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 06:44:29 --> Config Class Initialized
INFO - 2018-02-13 06:44:29 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:44:29 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:44:29 --> Utf8 Class Initialized
INFO - 2018-02-13 06:44:29 --> URI Class Initialized
INFO - 2018-02-13 06:44:29 --> Router Class Initialized
INFO - 2018-02-13 06:44:29 --> Output Class Initialized
INFO - 2018-02-13 06:44:29 --> Security Class Initialized
DEBUG - 2018-02-13 06:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:44:29 --> Input Class Initialized
INFO - 2018-02-13 06:44:29 --> Language Class Initialized
INFO - 2018-02-13 06:44:29 --> Loader Class Initialized
INFO - 2018-02-13 06:44:29 --> Helper loaded: url_helper
INFO - 2018-02-13 06:44:29 --> Helper loaded: form_helper
INFO - 2018-02-13 06:44:29 --> Database Driver Class Initialized
DEBUG - 2018-02-13 06:44:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 06:44:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:44:29 --> Form Validation Class Initialized
INFO - 2018-02-13 06:44:29 --> Model Class Initialized
INFO - 2018-02-13 06:44:29 --> Controller Class Initialized
INFO - 2018-02-13 06:44:29 --> Model Class Initialized
INFO - 2018-02-13 06:44:29 --> Model Class Initialized
INFO - 2018-02-13 06:44:29 --> Model Class Initialized
INFO - 2018-02-13 06:44:29 --> Model Class Initialized
INFO - 2018-02-13 06:44:29 --> Model Class Initialized
DEBUG - 2018-02-13 06:44:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 06:47:01 --> Config Class Initialized
INFO - 2018-02-13 06:47:01 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:47:01 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:47:01 --> Utf8 Class Initialized
INFO - 2018-02-13 06:47:01 --> URI Class Initialized
INFO - 2018-02-13 06:47:01 --> Router Class Initialized
INFO - 2018-02-13 06:47:01 --> Output Class Initialized
INFO - 2018-02-13 06:47:01 --> Security Class Initialized
DEBUG - 2018-02-13 06:47:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:47:01 --> Input Class Initialized
INFO - 2018-02-13 06:47:01 --> Language Class Initialized
INFO - 2018-02-13 06:47:01 --> Loader Class Initialized
INFO - 2018-02-13 06:47:01 --> Helper loaded: url_helper
INFO - 2018-02-13 06:47:01 --> Helper loaded: form_helper
INFO - 2018-02-13 06:47:01 --> Database Driver Class Initialized
DEBUG - 2018-02-13 06:47:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 06:47:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:47:01 --> Form Validation Class Initialized
INFO - 2018-02-13 06:47:01 --> Model Class Initialized
INFO - 2018-02-13 06:47:01 --> Controller Class Initialized
INFO - 2018-02-13 06:47:01 --> Model Class Initialized
INFO - 2018-02-13 06:47:01 --> Model Class Initialized
DEBUG - 2018-02-13 06:47:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 06:47:01 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 06:47:01 --> Final output sent to browser
DEBUG - 2018-02-13 06:47:01 --> Total execution time: 0.0761
INFO - 2018-02-13 06:47:02 --> Config Class Initialized
INFO - 2018-02-13 06:47:02 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:47:02 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:47:02 --> Utf8 Class Initialized
INFO - 2018-02-13 06:47:02 --> URI Class Initialized
INFO - 2018-02-13 06:47:02 --> Router Class Initialized
INFO - 2018-02-13 06:47:02 --> Output Class Initialized
INFO - 2018-02-13 06:47:02 --> Security Class Initialized
DEBUG - 2018-02-13 06:47:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:47:02 --> Input Class Initialized
INFO - 2018-02-13 06:47:02 --> Language Class Initialized
INFO - 2018-02-13 06:47:02 --> Loader Class Initialized
INFO - 2018-02-13 06:47:02 --> Helper loaded: url_helper
INFO - 2018-02-13 06:47:02 --> Helper loaded: form_helper
INFO - 2018-02-13 06:47:02 --> Database Driver Class Initialized
DEBUG - 2018-02-13 06:47:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 06:47:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:47:02 --> Form Validation Class Initialized
INFO - 2018-02-13 06:47:02 --> Model Class Initialized
INFO - 2018-02-13 06:47:02 --> Controller Class Initialized
INFO - 2018-02-13 06:47:02 --> Model Class Initialized
INFO - 2018-02-13 06:47:02 --> Model Class Initialized
DEBUG - 2018-02-13 06:47:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 06:47:08 --> Config Class Initialized
INFO - 2018-02-13 06:47:08 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:47:08 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:47:08 --> Utf8 Class Initialized
INFO - 2018-02-13 06:47:08 --> URI Class Initialized
INFO - 2018-02-13 06:47:08 --> Router Class Initialized
INFO - 2018-02-13 06:47:08 --> Output Class Initialized
INFO - 2018-02-13 06:47:08 --> Security Class Initialized
DEBUG - 2018-02-13 06:47:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:47:08 --> Input Class Initialized
INFO - 2018-02-13 06:47:08 --> Language Class Initialized
INFO - 2018-02-13 06:47:08 --> Loader Class Initialized
INFO - 2018-02-13 06:47:08 --> Helper loaded: url_helper
INFO - 2018-02-13 06:47:08 --> Helper loaded: form_helper
INFO - 2018-02-13 06:47:08 --> Database Driver Class Initialized
DEBUG - 2018-02-13 06:47:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 06:47:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:47:08 --> Form Validation Class Initialized
INFO - 2018-02-13 06:47:08 --> Model Class Initialized
INFO - 2018-02-13 06:47:08 --> Controller Class Initialized
INFO - 2018-02-13 06:47:08 --> Model Class Initialized
INFO - 2018-02-13 06:47:08 --> Model Class Initialized
DEBUG - 2018-02-13 06:47:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 06:47:08 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 06:47:08 --> Final output sent to browser
DEBUG - 2018-02-13 06:47:08 --> Total execution time: 0.0969
INFO - 2018-02-13 06:47:51 --> Config Class Initialized
INFO - 2018-02-13 06:47:51 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:47:51 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:47:51 --> Utf8 Class Initialized
INFO - 2018-02-13 06:47:51 --> URI Class Initialized
INFO - 2018-02-13 06:47:51 --> Router Class Initialized
INFO - 2018-02-13 06:47:51 --> Output Class Initialized
INFO - 2018-02-13 06:47:51 --> Security Class Initialized
DEBUG - 2018-02-13 06:47:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:47:51 --> Input Class Initialized
INFO - 2018-02-13 06:47:51 --> Language Class Initialized
INFO - 2018-02-13 06:47:51 --> Loader Class Initialized
INFO - 2018-02-13 06:47:51 --> Helper loaded: url_helper
INFO - 2018-02-13 06:47:51 --> Helper loaded: form_helper
INFO - 2018-02-13 06:47:51 --> Database Driver Class Initialized
DEBUG - 2018-02-13 06:47:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 06:47:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:47:51 --> Form Validation Class Initialized
INFO - 2018-02-13 06:47:51 --> Model Class Initialized
INFO - 2018-02-13 06:47:51 --> Controller Class Initialized
INFO - 2018-02-13 06:47:51 --> Model Class Initialized
INFO - 2018-02-13 06:47:51 --> Model Class Initialized
DEBUG - 2018-02-13 06:47:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 06:47:51 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 06:47:51 --> Final output sent to browser
DEBUG - 2018-02-13 06:47:51 --> Total execution time: 0.1128
INFO - 2018-02-13 06:47:55 --> Config Class Initialized
INFO - 2018-02-13 06:47:55 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:47:55 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:47:55 --> Utf8 Class Initialized
INFO - 2018-02-13 06:47:55 --> URI Class Initialized
INFO - 2018-02-13 06:47:55 --> Router Class Initialized
INFO - 2018-02-13 06:47:55 --> Output Class Initialized
INFO - 2018-02-13 06:47:55 --> Security Class Initialized
DEBUG - 2018-02-13 06:47:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:47:55 --> Input Class Initialized
INFO - 2018-02-13 06:47:55 --> Language Class Initialized
INFO - 2018-02-13 06:47:55 --> Loader Class Initialized
INFO - 2018-02-13 06:47:55 --> Helper loaded: url_helper
INFO - 2018-02-13 06:47:55 --> Helper loaded: form_helper
INFO - 2018-02-13 06:47:55 --> Database Driver Class Initialized
DEBUG - 2018-02-13 06:47:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 06:47:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:47:55 --> Form Validation Class Initialized
INFO - 2018-02-13 06:47:55 --> Model Class Initialized
INFO - 2018-02-13 06:47:55 --> Controller Class Initialized
INFO - 2018-02-13 06:47:55 --> Model Class Initialized
INFO - 2018-02-13 06:47:55 --> Model Class Initialized
DEBUG - 2018-02-13 06:47:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 06:49:16 --> Config Class Initialized
INFO - 2018-02-13 06:49:16 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:49:16 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:49:16 --> Utf8 Class Initialized
INFO - 2018-02-13 06:49:16 --> URI Class Initialized
INFO - 2018-02-13 06:49:16 --> Router Class Initialized
INFO - 2018-02-13 06:49:16 --> Output Class Initialized
INFO - 2018-02-13 06:49:16 --> Security Class Initialized
DEBUG - 2018-02-13 06:49:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:49:16 --> Input Class Initialized
INFO - 2018-02-13 06:49:16 --> Language Class Initialized
INFO - 2018-02-13 06:49:16 --> Loader Class Initialized
INFO - 2018-02-13 06:49:16 --> Helper loaded: url_helper
INFO - 2018-02-13 06:49:16 --> Helper loaded: form_helper
INFO - 2018-02-13 06:49:16 --> Database Driver Class Initialized
DEBUG - 2018-02-13 06:49:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 06:49:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:49:16 --> Form Validation Class Initialized
INFO - 2018-02-13 06:49:16 --> Model Class Initialized
INFO - 2018-02-13 06:49:16 --> Controller Class Initialized
INFO - 2018-02-13 06:49:16 --> Model Class Initialized
INFO - 2018-02-13 06:49:16 --> Model Class Initialized
DEBUG - 2018-02-13 06:49:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 06:49:26 --> Config Class Initialized
INFO - 2018-02-13 06:49:26 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:49:26 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:49:26 --> Utf8 Class Initialized
INFO - 2018-02-13 06:49:26 --> URI Class Initialized
INFO - 2018-02-13 06:49:26 --> Router Class Initialized
INFO - 2018-02-13 06:49:26 --> Output Class Initialized
INFO - 2018-02-13 06:49:26 --> Security Class Initialized
DEBUG - 2018-02-13 06:49:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:49:26 --> Input Class Initialized
INFO - 2018-02-13 06:49:26 --> Language Class Initialized
INFO - 2018-02-13 06:49:26 --> Loader Class Initialized
INFO - 2018-02-13 06:49:26 --> Helper loaded: url_helper
INFO - 2018-02-13 06:49:26 --> Helper loaded: form_helper
INFO - 2018-02-13 06:49:26 --> Database Driver Class Initialized
DEBUG - 2018-02-13 06:49:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 06:49:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:49:26 --> Form Validation Class Initialized
INFO - 2018-02-13 06:49:26 --> Model Class Initialized
INFO - 2018-02-13 06:49:26 --> Controller Class Initialized
INFO - 2018-02-13 06:49:26 --> Model Class Initialized
INFO - 2018-02-13 06:49:26 --> Model Class Initialized
DEBUG - 2018-02-13 06:49:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 06:49:26 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 06:49:26 --> Final output sent to browser
DEBUG - 2018-02-13 06:49:26 --> Total execution time: 0.1771
INFO - 2018-02-13 06:50:28 --> Config Class Initialized
INFO - 2018-02-13 06:50:28 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:50:28 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:50:28 --> Utf8 Class Initialized
INFO - 2018-02-13 06:50:28 --> URI Class Initialized
INFO - 2018-02-13 06:50:28 --> Router Class Initialized
INFO - 2018-02-13 06:50:28 --> Output Class Initialized
INFO - 2018-02-13 06:50:28 --> Security Class Initialized
DEBUG - 2018-02-13 06:50:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:50:28 --> Input Class Initialized
INFO - 2018-02-13 06:50:28 --> Language Class Initialized
INFO - 2018-02-13 06:50:28 --> Loader Class Initialized
INFO - 2018-02-13 06:50:28 --> Helper loaded: url_helper
INFO - 2018-02-13 06:50:28 --> Helper loaded: form_helper
INFO - 2018-02-13 06:50:28 --> Database Driver Class Initialized
DEBUG - 2018-02-13 06:50:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 06:50:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:50:28 --> Form Validation Class Initialized
INFO - 2018-02-13 06:50:28 --> Model Class Initialized
INFO - 2018-02-13 06:50:28 --> Controller Class Initialized
INFO - 2018-02-13 06:50:28 --> Model Class Initialized
INFO - 2018-02-13 06:50:28 --> Model Class Initialized
DEBUG - 2018-02-13 06:50:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 06:50:28 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 06:50:28 --> Final output sent to browser
DEBUG - 2018-02-13 06:50:28 --> Total execution time: 0.1498
INFO - 2018-02-13 06:50:29 --> Config Class Initialized
INFO - 2018-02-13 06:50:29 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:50:29 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:50:29 --> Utf8 Class Initialized
INFO - 2018-02-13 06:50:29 --> URI Class Initialized
INFO - 2018-02-13 06:50:29 --> Router Class Initialized
INFO - 2018-02-13 06:50:29 --> Output Class Initialized
INFO - 2018-02-13 06:50:29 --> Security Class Initialized
DEBUG - 2018-02-13 06:50:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:50:29 --> Input Class Initialized
INFO - 2018-02-13 06:50:29 --> Language Class Initialized
INFO - 2018-02-13 06:50:29 --> Loader Class Initialized
INFO - 2018-02-13 06:50:29 --> Helper loaded: url_helper
INFO - 2018-02-13 06:50:29 --> Helper loaded: form_helper
INFO - 2018-02-13 06:50:29 --> Database Driver Class Initialized
DEBUG - 2018-02-13 06:50:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 06:50:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:50:29 --> Form Validation Class Initialized
INFO - 2018-02-13 06:50:29 --> Model Class Initialized
INFO - 2018-02-13 06:50:29 --> Controller Class Initialized
INFO - 2018-02-13 06:50:29 --> Model Class Initialized
INFO - 2018-02-13 06:50:29 --> Model Class Initialized
DEBUG - 2018-02-13 06:50:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 06:50:29 --> Config Class Initialized
INFO - 2018-02-13 06:50:29 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:50:29 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:50:29 --> Utf8 Class Initialized
INFO - 2018-02-13 06:50:29 --> URI Class Initialized
INFO - 2018-02-13 06:50:29 --> Router Class Initialized
INFO - 2018-02-13 06:50:29 --> Output Class Initialized
INFO - 2018-02-13 06:50:29 --> Security Class Initialized
DEBUG - 2018-02-13 06:50:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:50:29 --> Input Class Initialized
INFO - 2018-02-13 06:50:29 --> Language Class Initialized
INFO - 2018-02-13 06:50:29 --> Loader Class Initialized
INFO - 2018-02-13 06:50:29 --> Helper loaded: url_helper
INFO - 2018-02-13 06:50:29 --> Helper loaded: form_helper
INFO - 2018-02-13 06:50:29 --> Database Driver Class Initialized
DEBUG - 2018-02-13 06:50:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 06:50:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:50:29 --> Form Validation Class Initialized
INFO - 2018-02-13 06:50:29 --> Model Class Initialized
INFO - 2018-02-13 06:50:29 --> Controller Class Initialized
INFO - 2018-02-13 06:50:29 --> Model Class Initialized
INFO - 2018-02-13 06:50:29 --> Model Class Initialized
DEBUG - 2018-02-13 06:50:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 06:50:29 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 06:50:29 --> Final output sent to browser
DEBUG - 2018-02-13 06:50:29 --> Total execution time: 0.1414
INFO - 2018-02-13 06:51:10 --> Config Class Initialized
INFO - 2018-02-13 06:51:10 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:51:10 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:51:10 --> Utf8 Class Initialized
INFO - 2018-02-13 06:51:10 --> URI Class Initialized
INFO - 2018-02-13 06:51:10 --> Router Class Initialized
INFO - 2018-02-13 06:51:10 --> Output Class Initialized
INFO - 2018-02-13 06:51:10 --> Security Class Initialized
DEBUG - 2018-02-13 06:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:51:10 --> Input Class Initialized
INFO - 2018-02-13 06:51:10 --> Language Class Initialized
INFO - 2018-02-13 06:51:10 --> Loader Class Initialized
INFO - 2018-02-13 06:51:11 --> Helper loaded: url_helper
INFO - 2018-02-13 06:51:11 --> Helper loaded: form_helper
INFO - 2018-02-13 06:51:11 --> Database Driver Class Initialized
DEBUG - 2018-02-13 06:51:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 06:51:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:51:11 --> Form Validation Class Initialized
INFO - 2018-02-13 06:51:11 --> Model Class Initialized
INFO - 2018-02-13 06:51:11 --> Controller Class Initialized
INFO - 2018-02-13 06:51:11 --> Model Class Initialized
INFO - 2018-02-13 06:51:11 --> Model Class Initialized
DEBUG - 2018-02-13 06:51:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 06:51:11 --> Model Class Initialized
INFO - 2018-02-13 06:51:11 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 06:51:11 --> Final output sent to browser
DEBUG - 2018-02-13 06:51:11 --> Total execution time: 0.5489
INFO - 2018-02-13 06:51:12 --> Config Class Initialized
INFO - 2018-02-13 06:51:12 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:51:12 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:51:12 --> Utf8 Class Initialized
INFO - 2018-02-13 06:51:12 --> URI Class Initialized
INFO - 2018-02-13 06:51:12 --> Router Class Initialized
INFO - 2018-02-13 06:51:12 --> Output Class Initialized
INFO - 2018-02-13 06:51:12 --> Security Class Initialized
DEBUG - 2018-02-13 06:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:51:12 --> Input Class Initialized
INFO - 2018-02-13 06:51:12 --> Language Class Initialized
INFO - 2018-02-13 06:51:12 --> Loader Class Initialized
INFO - 2018-02-13 06:51:12 --> Helper loaded: url_helper
INFO - 2018-02-13 06:51:12 --> Helper loaded: form_helper
INFO - 2018-02-13 06:51:12 --> Database Driver Class Initialized
DEBUG - 2018-02-13 06:51:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 06:51:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:51:12 --> Form Validation Class Initialized
INFO - 2018-02-13 06:51:12 --> Model Class Initialized
INFO - 2018-02-13 06:51:12 --> Controller Class Initialized
INFO - 2018-02-13 06:51:12 --> Model Class Initialized
INFO - 2018-02-13 06:51:12 --> Model Class Initialized
DEBUG - 2018-02-13 06:51:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 06:51:12 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 06:51:12 --> Final output sent to browser
DEBUG - 2018-02-13 06:51:12 --> Total execution time: 0.0457
INFO - 2018-02-13 06:51:13 --> Config Class Initialized
INFO - 2018-02-13 06:51:13 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:51:13 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:51:13 --> Utf8 Class Initialized
INFO - 2018-02-13 06:51:13 --> URI Class Initialized
INFO - 2018-02-13 06:51:13 --> Router Class Initialized
INFO - 2018-02-13 06:51:13 --> Output Class Initialized
INFO - 2018-02-13 06:51:13 --> Security Class Initialized
DEBUG - 2018-02-13 06:51:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:51:13 --> Input Class Initialized
INFO - 2018-02-13 06:51:13 --> Language Class Initialized
INFO - 2018-02-13 06:51:13 --> Loader Class Initialized
INFO - 2018-02-13 06:51:13 --> Helper loaded: url_helper
INFO - 2018-02-13 06:51:13 --> Helper loaded: form_helper
INFO - 2018-02-13 06:51:13 --> Database Driver Class Initialized
DEBUG - 2018-02-13 06:51:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 06:51:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:51:13 --> Form Validation Class Initialized
INFO - 2018-02-13 06:51:13 --> Model Class Initialized
INFO - 2018-02-13 06:51:13 --> Controller Class Initialized
INFO - 2018-02-13 06:51:13 --> Model Class Initialized
INFO - 2018-02-13 06:51:13 --> Model Class Initialized
DEBUG - 2018-02-13 06:51:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 06:51:18 --> Config Class Initialized
INFO - 2018-02-13 06:51:18 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:51:18 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:51:18 --> Utf8 Class Initialized
INFO - 2018-02-13 06:51:18 --> URI Class Initialized
INFO - 2018-02-13 06:51:18 --> Router Class Initialized
INFO - 2018-02-13 06:51:18 --> Output Class Initialized
INFO - 2018-02-13 06:51:18 --> Security Class Initialized
DEBUG - 2018-02-13 06:51:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:51:18 --> Input Class Initialized
INFO - 2018-02-13 06:51:18 --> Language Class Initialized
INFO - 2018-02-13 06:51:18 --> Loader Class Initialized
INFO - 2018-02-13 06:51:18 --> Helper loaded: url_helper
INFO - 2018-02-13 06:51:18 --> Helper loaded: form_helper
INFO - 2018-02-13 06:51:18 --> Database Driver Class Initialized
DEBUG - 2018-02-13 06:51:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 06:51:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:51:18 --> Form Validation Class Initialized
INFO - 2018-02-13 06:51:18 --> Model Class Initialized
INFO - 2018-02-13 06:51:18 --> Controller Class Initialized
INFO - 2018-02-13 06:51:18 --> Model Class Initialized
DEBUG - 2018-02-13 06:51:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 06:51:18 --> Config Class Initialized
INFO - 2018-02-13 06:51:18 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:51:18 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:51:18 --> Utf8 Class Initialized
INFO - 2018-02-13 06:51:18 --> URI Class Initialized
INFO - 2018-02-13 06:51:18 --> Router Class Initialized
INFO - 2018-02-13 06:51:18 --> Output Class Initialized
INFO - 2018-02-13 06:51:18 --> Security Class Initialized
DEBUG - 2018-02-13 06:51:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:51:18 --> Input Class Initialized
INFO - 2018-02-13 06:51:18 --> Language Class Initialized
INFO - 2018-02-13 06:51:18 --> Loader Class Initialized
INFO - 2018-02-13 06:51:18 --> Helper loaded: url_helper
INFO - 2018-02-13 06:51:18 --> Helper loaded: form_helper
INFO - 2018-02-13 06:51:18 --> Database Driver Class Initialized
DEBUG - 2018-02-13 06:51:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 06:51:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:51:18 --> Form Validation Class Initialized
INFO - 2018-02-13 06:51:18 --> Model Class Initialized
INFO - 2018-02-13 06:51:18 --> Controller Class Initialized
INFO - 2018-02-13 06:51:18 --> Model Class Initialized
DEBUG - 2018-02-13 06:51:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 06:51:18 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 06:51:18 --> Final output sent to browser
DEBUG - 2018-02-13 06:51:18 --> Total execution time: 0.0470
INFO - 2018-02-13 06:51:23 --> Config Class Initialized
INFO - 2018-02-13 06:51:23 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:51:23 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:51:23 --> Utf8 Class Initialized
INFO - 2018-02-13 06:51:23 --> URI Class Initialized
INFO - 2018-02-13 06:51:23 --> Router Class Initialized
INFO - 2018-02-13 06:51:23 --> Output Class Initialized
INFO - 2018-02-13 06:51:23 --> Security Class Initialized
DEBUG - 2018-02-13 06:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:51:23 --> Input Class Initialized
INFO - 2018-02-13 06:51:23 --> Language Class Initialized
INFO - 2018-02-13 06:51:23 --> Loader Class Initialized
INFO - 2018-02-13 06:51:23 --> Helper loaded: url_helper
INFO - 2018-02-13 06:51:23 --> Helper loaded: form_helper
INFO - 2018-02-13 06:51:23 --> Database Driver Class Initialized
DEBUG - 2018-02-13 06:51:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 06:51:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:51:23 --> Form Validation Class Initialized
INFO - 2018-02-13 06:51:23 --> Model Class Initialized
INFO - 2018-02-13 06:51:23 --> Controller Class Initialized
INFO - 2018-02-13 06:51:23 --> Model Class Initialized
DEBUG - 2018-02-13 06:51:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 06:51:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-13 06:51:23 --> Config Class Initialized
INFO - 2018-02-13 06:51:23 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:51:23 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:51:23 --> Utf8 Class Initialized
INFO - 2018-02-13 06:51:23 --> URI Class Initialized
DEBUG - 2018-02-13 06:51:23 --> No URI present. Default controller set.
INFO - 2018-02-13 06:51:23 --> Router Class Initialized
INFO - 2018-02-13 06:51:23 --> Output Class Initialized
INFO - 2018-02-13 06:51:23 --> Security Class Initialized
DEBUG - 2018-02-13 06:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:51:23 --> Input Class Initialized
INFO - 2018-02-13 06:51:23 --> Language Class Initialized
INFO - 2018-02-13 06:51:23 --> Loader Class Initialized
INFO - 2018-02-13 06:51:23 --> Helper loaded: url_helper
INFO - 2018-02-13 06:51:23 --> Helper loaded: form_helper
INFO - 2018-02-13 06:51:23 --> Database Driver Class Initialized
DEBUG - 2018-02-13 06:51:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 06:51:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:51:23 --> Form Validation Class Initialized
INFO - 2018-02-13 06:51:23 --> Model Class Initialized
INFO - 2018-02-13 06:51:23 --> Controller Class Initialized
INFO - 2018-02-13 06:51:23 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 06:51:23 --> Final output sent to browser
DEBUG - 2018-02-13 06:51:23 --> Total execution time: 0.0483
INFO - 2018-02-13 06:51:23 --> Config Class Initialized
INFO - 2018-02-13 06:51:23 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:51:23 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:51:23 --> Utf8 Class Initialized
INFO - 2018-02-13 06:51:23 --> URI Class Initialized
INFO - 2018-02-13 06:51:23 --> Router Class Initialized
INFO - 2018-02-13 06:51:23 --> Output Class Initialized
INFO - 2018-02-13 06:51:23 --> Security Class Initialized
DEBUG - 2018-02-13 06:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:51:23 --> Input Class Initialized
INFO - 2018-02-13 06:51:23 --> Language Class Initialized
INFO - 2018-02-13 06:51:23 --> Loader Class Initialized
INFO - 2018-02-13 06:51:23 --> Helper loaded: url_helper
INFO - 2018-02-13 06:51:23 --> Helper loaded: form_helper
INFO - 2018-02-13 06:51:23 --> Database Driver Class Initialized
DEBUG - 2018-02-13 06:51:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 06:51:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:51:23 --> Form Validation Class Initialized
INFO - 2018-02-13 06:51:23 --> Model Class Initialized
INFO - 2018-02-13 06:51:23 --> Controller Class Initialized
INFO - 2018-02-13 06:51:23 --> Model Class Initialized
INFO - 2018-02-13 06:51:23 --> Model Class Initialized
INFO - 2018-02-13 06:51:23 --> Model Class Initialized
INFO - 2018-02-13 06:51:23 --> Model Class Initialized
INFO - 2018-02-13 06:51:23 --> Model Class Initialized
DEBUG - 2018-02-13 06:51:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 06:51:26 --> Config Class Initialized
INFO - 2018-02-13 06:51:26 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:51:26 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:51:26 --> Utf8 Class Initialized
INFO - 2018-02-13 06:51:26 --> URI Class Initialized
INFO - 2018-02-13 06:51:26 --> Router Class Initialized
INFO - 2018-02-13 06:51:26 --> Output Class Initialized
INFO - 2018-02-13 06:51:26 --> Security Class Initialized
DEBUG - 2018-02-13 06:51:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:51:26 --> Input Class Initialized
INFO - 2018-02-13 06:51:26 --> Language Class Initialized
INFO - 2018-02-13 06:51:26 --> Loader Class Initialized
INFO - 2018-02-13 06:51:26 --> Helper loaded: url_helper
INFO - 2018-02-13 06:51:26 --> Helper loaded: form_helper
INFO - 2018-02-13 06:51:26 --> Database Driver Class Initialized
DEBUG - 2018-02-13 06:51:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 06:51:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:51:26 --> Form Validation Class Initialized
INFO - 2018-02-13 06:51:26 --> Model Class Initialized
INFO - 2018-02-13 06:51:26 --> Controller Class Initialized
INFO - 2018-02-13 06:51:26 --> Model Class Initialized
DEBUG - 2018-02-13 06:51:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 06:51:26 --> Config Class Initialized
INFO - 2018-02-13 06:51:26 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:51:26 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:51:26 --> Utf8 Class Initialized
INFO - 2018-02-13 06:51:26 --> URI Class Initialized
INFO - 2018-02-13 06:51:26 --> Router Class Initialized
INFO - 2018-02-13 06:51:26 --> Output Class Initialized
INFO - 2018-02-13 06:51:26 --> Security Class Initialized
DEBUG - 2018-02-13 06:51:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:51:26 --> Input Class Initialized
INFO - 2018-02-13 06:51:26 --> Language Class Initialized
INFO - 2018-02-13 06:51:26 --> Loader Class Initialized
INFO - 2018-02-13 06:51:26 --> Helper loaded: url_helper
INFO - 2018-02-13 06:51:26 --> Helper loaded: form_helper
INFO - 2018-02-13 06:51:26 --> Database Driver Class Initialized
DEBUG - 2018-02-13 06:51:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 06:51:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:51:26 --> Form Validation Class Initialized
INFO - 2018-02-13 06:51:26 --> Model Class Initialized
INFO - 2018-02-13 06:51:26 --> Controller Class Initialized
INFO - 2018-02-13 06:51:26 --> Model Class Initialized
DEBUG - 2018-02-13 06:51:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 06:51:26 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 06:51:26 --> Final output sent to browser
DEBUG - 2018-02-13 06:51:26 --> Total execution time: 0.0580
INFO - 2018-02-13 06:51:28 --> Config Class Initialized
INFO - 2018-02-13 06:51:28 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:51:28 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:51:28 --> Utf8 Class Initialized
INFO - 2018-02-13 06:51:28 --> URI Class Initialized
INFO - 2018-02-13 06:51:28 --> Router Class Initialized
INFO - 2018-02-13 06:51:28 --> Output Class Initialized
INFO - 2018-02-13 06:51:28 --> Security Class Initialized
DEBUG - 2018-02-13 06:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:51:28 --> Input Class Initialized
INFO - 2018-02-13 06:51:28 --> Language Class Initialized
INFO - 2018-02-13 06:51:28 --> Loader Class Initialized
INFO - 2018-02-13 06:51:28 --> Helper loaded: url_helper
INFO - 2018-02-13 06:51:28 --> Helper loaded: form_helper
INFO - 2018-02-13 06:51:28 --> Database Driver Class Initialized
DEBUG - 2018-02-13 06:51:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 06:51:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:51:28 --> Form Validation Class Initialized
INFO - 2018-02-13 06:51:28 --> Model Class Initialized
INFO - 2018-02-13 06:51:28 --> Controller Class Initialized
INFO - 2018-02-13 06:51:28 --> Model Class Initialized
DEBUG - 2018-02-13 06:51:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 06:51:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-13 06:51:28 --> Config Class Initialized
INFO - 2018-02-13 06:51:28 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:51:28 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:51:28 --> Utf8 Class Initialized
INFO - 2018-02-13 06:51:28 --> URI Class Initialized
DEBUG - 2018-02-13 06:51:28 --> No URI present. Default controller set.
INFO - 2018-02-13 06:51:28 --> Router Class Initialized
INFO - 2018-02-13 06:51:28 --> Output Class Initialized
INFO - 2018-02-13 06:51:28 --> Security Class Initialized
DEBUG - 2018-02-13 06:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:51:28 --> Input Class Initialized
INFO - 2018-02-13 06:51:28 --> Language Class Initialized
INFO - 2018-02-13 06:51:28 --> Loader Class Initialized
INFO - 2018-02-13 06:51:28 --> Helper loaded: url_helper
INFO - 2018-02-13 06:51:28 --> Helper loaded: form_helper
INFO - 2018-02-13 06:51:28 --> Database Driver Class Initialized
DEBUG - 2018-02-13 06:51:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 06:51:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:51:28 --> Form Validation Class Initialized
INFO - 2018-02-13 06:51:28 --> Model Class Initialized
INFO - 2018-02-13 06:51:28 --> Controller Class Initialized
INFO - 2018-02-13 06:51:28 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 06:51:28 --> Final output sent to browser
DEBUG - 2018-02-13 06:51:28 --> Total execution time: 0.0988
INFO - 2018-02-13 06:51:28 --> Config Class Initialized
INFO - 2018-02-13 06:51:28 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:51:28 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:51:28 --> Utf8 Class Initialized
INFO - 2018-02-13 06:51:28 --> URI Class Initialized
INFO - 2018-02-13 06:51:28 --> Router Class Initialized
INFO - 2018-02-13 06:51:28 --> Output Class Initialized
INFO - 2018-02-13 06:51:28 --> Security Class Initialized
DEBUG - 2018-02-13 06:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:51:28 --> Input Class Initialized
INFO - 2018-02-13 06:51:28 --> Language Class Initialized
INFO - 2018-02-13 06:51:28 --> Loader Class Initialized
INFO - 2018-02-13 06:51:28 --> Helper loaded: url_helper
INFO - 2018-02-13 06:51:28 --> Helper loaded: form_helper
INFO - 2018-02-13 06:51:28 --> Database Driver Class Initialized
DEBUG - 2018-02-13 06:51:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 06:51:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:51:28 --> Form Validation Class Initialized
INFO - 2018-02-13 06:51:28 --> Model Class Initialized
INFO - 2018-02-13 06:51:28 --> Controller Class Initialized
INFO - 2018-02-13 06:51:28 --> Model Class Initialized
INFO - 2018-02-13 06:51:28 --> Model Class Initialized
INFO - 2018-02-13 06:51:28 --> Model Class Initialized
INFO - 2018-02-13 06:51:28 --> Model Class Initialized
INFO - 2018-02-13 06:51:28 --> Model Class Initialized
DEBUG - 2018-02-13 06:51:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 06:51:33 --> Config Class Initialized
INFO - 2018-02-13 06:51:33 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:51:33 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:51:33 --> Utf8 Class Initialized
INFO - 2018-02-13 06:51:33 --> URI Class Initialized
INFO - 2018-02-13 06:51:33 --> Router Class Initialized
INFO - 2018-02-13 06:51:33 --> Output Class Initialized
INFO - 2018-02-13 06:51:33 --> Security Class Initialized
DEBUG - 2018-02-13 06:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:51:33 --> Input Class Initialized
INFO - 2018-02-13 06:51:33 --> Language Class Initialized
INFO - 2018-02-13 06:51:33 --> Loader Class Initialized
INFO - 2018-02-13 06:51:33 --> Helper loaded: url_helper
INFO - 2018-02-13 06:51:33 --> Helper loaded: form_helper
INFO - 2018-02-13 06:51:33 --> Database Driver Class Initialized
DEBUG - 2018-02-13 06:51:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 06:51:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:51:33 --> Form Validation Class Initialized
INFO - 2018-02-13 06:51:33 --> Model Class Initialized
INFO - 2018-02-13 06:51:33 --> Controller Class Initialized
INFO - 2018-02-13 06:51:33 --> Model Class Initialized
INFO - 2018-02-13 06:51:33 --> Model Class Initialized
INFO - 2018-02-13 06:51:33 --> Model Class Initialized
INFO - 2018-02-13 06:51:33 --> Model Class Initialized
INFO - 2018-02-13 06:51:33 --> Model Class Initialized
DEBUG - 2018-02-13 06:51:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 06:51:33 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 06:51:33 --> Final output sent to browser
DEBUG - 2018-02-13 06:51:33 --> Total execution time: 0.1390
INFO - 2018-02-13 06:51:34 --> Config Class Initialized
INFO - 2018-02-13 06:51:34 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:51:34 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:51:34 --> Utf8 Class Initialized
INFO - 2018-02-13 06:51:34 --> URI Class Initialized
INFO - 2018-02-13 06:51:34 --> Router Class Initialized
INFO - 2018-02-13 06:51:34 --> Output Class Initialized
INFO - 2018-02-13 06:51:34 --> Security Class Initialized
DEBUG - 2018-02-13 06:51:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:51:34 --> Input Class Initialized
INFO - 2018-02-13 06:51:34 --> Language Class Initialized
INFO - 2018-02-13 06:51:34 --> Loader Class Initialized
INFO - 2018-02-13 06:51:34 --> Helper loaded: url_helper
INFO - 2018-02-13 06:51:34 --> Helper loaded: form_helper
INFO - 2018-02-13 06:51:34 --> Database Driver Class Initialized
DEBUG - 2018-02-13 06:51:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 06:51:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:51:34 --> Form Validation Class Initialized
INFO - 2018-02-13 06:51:34 --> Model Class Initialized
INFO - 2018-02-13 06:51:34 --> Controller Class Initialized
INFO - 2018-02-13 06:51:34 --> Model Class Initialized
INFO - 2018-02-13 06:51:34 --> Model Class Initialized
INFO - 2018-02-13 06:51:34 --> Model Class Initialized
INFO - 2018-02-13 06:51:34 --> Model Class Initialized
INFO - 2018-02-13 06:51:34 --> Model Class Initialized
DEBUG - 2018-02-13 06:51:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 06:51:40 --> Config Class Initialized
INFO - 2018-02-13 06:51:40 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:51:40 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:51:40 --> Utf8 Class Initialized
INFO - 2018-02-13 06:51:40 --> URI Class Initialized
DEBUG - 2018-02-13 06:51:40 --> No URI present. Default controller set.
INFO - 2018-02-13 06:51:40 --> Router Class Initialized
INFO - 2018-02-13 06:51:40 --> Output Class Initialized
INFO - 2018-02-13 06:51:40 --> Security Class Initialized
DEBUG - 2018-02-13 06:51:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:51:40 --> Input Class Initialized
INFO - 2018-02-13 06:51:40 --> Language Class Initialized
INFO - 2018-02-13 06:51:40 --> Loader Class Initialized
INFO - 2018-02-13 06:51:40 --> Helper loaded: url_helper
INFO - 2018-02-13 06:51:40 --> Helper loaded: form_helper
INFO - 2018-02-13 06:51:40 --> Database Driver Class Initialized
DEBUG - 2018-02-13 06:51:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 06:51:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:51:40 --> Form Validation Class Initialized
INFO - 2018-02-13 06:51:40 --> Model Class Initialized
INFO - 2018-02-13 06:51:40 --> Controller Class Initialized
INFO - 2018-02-13 06:51:40 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 06:51:40 --> Final output sent to browser
DEBUG - 2018-02-13 06:51:40 --> Total execution time: 0.0841
INFO - 2018-02-13 06:51:40 --> Config Class Initialized
INFO - 2018-02-13 06:51:40 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:51:40 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:51:40 --> Utf8 Class Initialized
INFO - 2018-02-13 06:51:40 --> URI Class Initialized
INFO - 2018-02-13 06:51:40 --> Router Class Initialized
INFO - 2018-02-13 06:51:40 --> Output Class Initialized
INFO - 2018-02-13 06:51:40 --> Security Class Initialized
DEBUG - 2018-02-13 06:51:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:51:40 --> Input Class Initialized
INFO - 2018-02-13 06:51:40 --> Language Class Initialized
INFO - 2018-02-13 06:51:40 --> Loader Class Initialized
INFO - 2018-02-13 06:51:40 --> Helper loaded: url_helper
INFO - 2018-02-13 06:51:40 --> Helper loaded: form_helper
INFO - 2018-02-13 06:51:40 --> Database Driver Class Initialized
DEBUG - 2018-02-13 06:51:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 06:51:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:51:40 --> Form Validation Class Initialized
INFO - 2018-02-13 06:51:40 --> Model Class Initialized
INFO - 2018-02-13 06:51:40 --> Controller Class Initialized
INFO - 2018-02-13 06:51:40 --> Model Class Initialized
INFO - 2018-02-13 06:51:40 --> Model Class Initialized
INFO - 2018-02-13 06:51:40 --> Model Class Initialized
INFO - 2018-02-13 06:51:40 --> Model Class Initialized
INFO - 2018-02-13 06:51:40 --> Model Class Initialized
DEBUG - 2018-02-13 06:51:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 06:51:42 --> Config Class Initialized
INFO - 2018-02-13 06:51:42 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:51:42 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:51:42 --> Utf8 Class Initialized
INFO - 2018-02-13 06:51:42 --> URI Class Initialized
INFO - 2018-02-13 06:51:42 --> Router Class Initialized
INFO - 2018-02-13 06:51:42 --> Output Class Initialized
INFO - 2018-02-13 06:51:42 --> Security Class Initialized
DEBUG - 2018-02-13 06:51:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:51:42 --> Input Class Initialized
INFO - 2018-02-13 06:51:42 --> Language Class Initialized
INFO - 2018-02-13 06:51:42 --> Loader Class Initialized
INFO - 2018-02-13 06:51:42 --> Helper loaded: url_helper
INFO - 2018-02-13 06:51:42 --> Helper loaded: form_helper
INFO - 2018-02-13 06:51:42 --> Database Driver Class Initialized
DEBUG - 2018-02-13 06:51:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 06:51:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:51:42 --> Form Validation Class Initialized
INFO - 2018-02-13 06:51:42 --> Model Class Initialized
INFO - 2018-02-13 06:51:42 --> Controller Class Initialized
INFO - 2018-02-13 06:51:42 --> Model Class Initialized
INFO - 2018-02-13 06:51:42 --> Model Class Initialized
INFO - 2018-02-13 06:51:42 --> Model Class Initialized
INFO - 2018-02-13 06:51:42 --> Model Class Initialized
INFO - 2018-02-13 06:51:42 --> Model Class Initialized
DEBUG - 2018-02-13 06:51:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 06:51:42 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 06:51:42 --> Final output sent to browser
DEBUG - 2018-02-13 06:51:42 --> Total execution time: 0.0992
INFO - 2018-02-13 06:51:42 --> Config Class Initialized
INFO - 2018-02-13 06:51:42 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:51:42 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:51:42 --> Utf8 Class Initialized
INFO - 2018-02-13 06:51:42 --> URI Class Initialized
INFO - 2018-02-13 06:51:42 --> Router Class Initialized
INFO - 2018-02-13 06:51:42 --> Output Class Initialized
INFO - 2018-02-13 06:51:42 --> Security Class Initialized
DEBUG - 2018-02-13 06:51:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:51:42 --> Input Class Initialized
INFO - 2018-02-13 06:51:42 --> Language Class Initialized
INFO - 2018-02-13 06:51:42 --> Loader Class Initialized
INFO - 2018-02-13 06:51:42 --> Helper loaded: url_helper
INFO - 2018-02-13 06:51:42 --> Helper loaded: form_helper
INFO - 2018-02-13 06:51:42 --> Database Driver Class Initialized
DEBUG - 2018-02-13 06:51:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 06:51:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:51:42 --> Form Validation Class Initialized
INFO - 2018-02-13 06:51:42 --> Model Class Initialized
INFO - 2018-02-13 06:51:42 --> Controller Class Initialized
INFO - 2018-02-13 06:51:42 --> Model Class Initialized
INFO - 2018-02-13 06:51:42 --> Model Class Initialized
INFO - 2018-02-13 06:51:42 --> Model Class Initialized
INFO - 2018-02-13 06:51:42 --> Model Class Initialized
INFO - 2018-02-13 06:51:42 --> Model Class Initialized
DEBUG - 2018-02-13 06:51:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 06:51:45 --> Config Class Initialized
INFO - 2018-02-13 06:51:45 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:51:45 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:51:45 --> Utf8 Class Initialized
INFO - 2018-02-13 06:51:45 --> URI Class Initialized
INFO - 2018-02-13 06:51:45 --> Router Class Initialized
INFO - 2018-02-13 06:51:45 --> Output Class Initialized
INFO - 2018-02-13 06:51:45 --> Security Class Initialized
DEBUG - 2018-02-13 06:51:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:51:45 --> Input Class Initialized
INFO - 2018-02-13 06:51:45 --> Language Class Initialized
INFO - 2018-02-13 06:51:45 --> Loader Class Initialized
INFO - 2018-02-13 06:51:45 --> Helper loaded: url_helper
INFO - 2018-02-13 06:51:45 --> Helper loaded: form_helper
INFO - 2018-02-13 06:51:45 --> Database Driver Class Initialized
DEBUG - 2018-02-13 06:51:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 06:51:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:51:45 --> Form Validation Class Initialized
INFO - 2018-02-13 06:51:45 --> Model Class Initialized
INFO - 2018-02-13 06:51:45 --> Controller Class Initialized
INFO - 2018-02-13 06:51:45 --> Model Class Initialized
INFO - 2018-02-13 06:51:45 --> Model Class Initialized
INFO - 2018-02-13 06:51:45 --> Model Class Initialized
INFO - 2018-02-13 06:51:45 --> Model Class Initialized
INFO - 2018-02-13 06:51:45 --> Model Class Initialized
DEBUG - 2018-02-13 06:51:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 06:51:45 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 06:51:45 --> Final output sent to browser
DEBUG - 2018-02-13 06:51:45 --> Total execution time: 0.1388
INFO - 2018-02-13 06:51:45 --> Config Class Initialized
INFO - 2018-02-13 06:51:45 --> Hooks Class Initialized
INFO - 2018-02-13 06:51:45 --> Config Class Initialized
INFO - 2018-02-13 06:51:45 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:51:45 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 06:51:45 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:51:45 --> Utf8 Class Initialized
INFO - 2018-02-13 06:51:45 --> Utf8 Class Initialized
INFO - 2018-02-13 06:51:45 --> URI Class Initialized
INFO - 2018-02-13 06:51:45 --> URI Class Initialized
INFO - 2018-02-13 06:51:45 --> Router Class Initialized
INFO - 2018-02-13 06:51:45 --> Router Class Initialized
INFO - 2018-02-13 06:51:45 --> Output Class Initialized
INFO - 2018-02-13 06:51:45 --> Output Class Initialized
INFO - 2018-02-13 06:51:45 --> Security Class Initialized
INFO - 2018-02-13 06:51:45 --> Security Class Initialized
DEBUG - 2018-02-13 06:51:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:51:45 --> Input Class Initialized
DEBUG - 2018-02-13 06:51:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:51:45 --> Language Class Initialized
INFO - 2018-02-13 06:51:45 --> Input Class Initialized
INFO - 2018-02-13 06:51:45 --> Language Class Initialized
INFO - 2018-02-13 06:51:45 --> Loader Class Initialized
INFO - 2018-02-13 06:51:45 --> Loader Class Initialized
INFO - 2018-02-13 06:51:45 --> Helper loaded: url_helper
INFO - 2018-02-13 06:51:45 --> Helper loaded: form_helper
INFO - 2018-02-13 06:51:45 --> Helper loaded: url_helper
INFO - 2018-02-13 06:51:45 --> Helper loaded: form_helper
INFO - 2018-02-13 06:51:45 --> Database Driver Class Initialized
INFO - 2018-02-13 06:51:45 --> Database Driver Class Initialized
DEBUG - 2018-02-13 06:51:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 06:51:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-02-13 06:51:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 06:51:45 --> Form Validation Class Initialized
INFO - 2018-02-13 06:51:45 --> Model Class Initialized
INFO - 2018-02-13 06:51:45 --> Controller Class Initialized
INFO - 2018-02-13 06:51:45 --> Model Class Initialized
INFO - 2018-02-13 06:51:45 --> Model Class Initialized
INFO - 2018-02-13 06:51:45 --> Model Class Initialized
INFO - 2018-02-13 06:51:45 --> Model Class Initialized
INFO - 2018-02-13 06:51:45 --> Model Class Initialized
DEBUG - 2018-02-13 06:51:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 06:51:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:51:45 --> Form Validation Class Initialized
INFO - 2018-02-13 06:51:45 --> Model Class Initialized
INFO - 2018-02-13 06:51:45 --> Controller Class Initialized
INFO - 2018-02-13 06:51:45 --> Model Class Initialized
INFO - 2018-02-13 06:51:45 --> Model Class Initialized
INFO - 2018-02-13 06:51:45 --> Model Class Initialized
INFO - 2018-02-13 06:51:45 --> Model Class Initialized
INFO - 2018-02-13 06:51:45 --> Model Class Initialized
DEBUG - 2018-02-13 06:51:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 06:51:53 --> Config Class Initialized
INFO - 2018-02-13 06:51:53 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:51:53 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:51:53 --> Utf8 Class Initialized
INFO - 2018-02-13 06:51:53 --> URI Class Initialized
INFO - 2018-02-13 06:51:53 --> Router Class Initialized
INFO - 2018-02-13 06:51:53 --> Output Class Initialized
INFO - 2018-02-13 06:51:53 --> Security Class Initialized
DEBUG - 2018-02-13 06:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:51:53 --> Input Class Initialized
INFO - 2018-02-13 06:51:53 --> Language Class Initialized
INFO - 2018-02-13 06:51:53 --> Loader Class Initialized
INFO - 2018-02-13 06:51:53 --> Helper loaded: url_helper
INFO - 2018-02-13 06:51:53 --> Helper loaded: form_helper
INFO - 2018-02-13 06:51:53 --> Database Driver Class Initialized
DEBUG - 2018-02-13 06:51:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 06:51:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:51:53 --> Form Validation Class Initialized
INFO - 2018-02-13 06:51:53 --> Model Class Initialized
INFO - 2018-02-13 06:51:53 --> Controller Class Initialized
INFO - 2018-02-13 06:51:53 --> Model Class Initialized
INFO - 2018-02-13 06:51:53 --> Model Class Initialized
INFO - 2018-02-13 06:51:53 --> Model Class Initialized
INFO - 2018-02-13 06:51:53 --> Model Class Initialized
INFO - 2018-02-13 06:51:53 --> Model Class Initialized
DEBUG - 2018-02-13 06:51:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 06:51:53 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 06:51:53 --> Final output sent to browser
DEBUG - 2018-02-13 06:51:53 --> Total execution time: 0.3621
INFO - 2018-02-13 06:51:53 --> Config Class Initialized
INFO - 2018-02-13 06:51:53 --> Hooks Class Initialized
INFO - 2018-02-13 06:51:53 --> Config Class Initialized
INFO - 2018-02-13 06:51:53 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:51:53 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:51:53 --> Utf8 Class Initialized
DEBUG - 2018-02-13 06:51:53 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:51:53 --> Utf8 Class Initialized
INFO - 2018-02-13 06:51:53 --> URI Class Initialized
INFO - 2018-02-13 06:51:53 --> URI Class Initialized
INFO - 2018-02-13 06:51:53 --> Router Class Initialized
INFO - 2018-02-13 06:51:53 --> Router Class Initialized
INFO - 2018-02-13 06:51:53 --> Output Class Initialized
INFO - 2018-02-13 06:51:53 --> Output Class Initialized
INFO - 2018-02-13 06:51:53 --> Security Class Initialized
INFO - 2018-02-13 06:51:53 --> Security Class Initialized
DEBUG - 2018-02-13 06:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:51:53 --> Input Class Initialized
DEBUG - 2018-02-13 06:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:51:53 --> Language Class Initialized
INFO - 2018-02-13 06:51:53 --> Input Class Initialized
INFO - 2018-02-13 06:51:53 --> Language Class Initialized
INFO - 2018-02-13 06:51:53 --> Loader Class Initialized
INFO - 2018-02-13 06:51:53 --> Loader Class Initialized
INFO - 2018-02-13 06:51:53 --> Helper loaded: url_helper
INFO - 2018-02-13 06:51:53 --> Helper loaded: url_helper
INFO - 2018-02-13 06:51:53 --> Helper loaded: form_helper
INFO - 2018-02-13 06:51:53 --> Helper loaded: form_helper
INFO - 2018-02-13 06:51:53 --> Database Driver Class Initialized
INFO - 2018-02-13 06:51:53 --> Database Driver Class Initialized
DEBUG - 2018-02-13 06:51:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 06:51:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 06:51:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:51:53 --> Form Validation Class Initialized
INFO - 2018-02-13 06:51:53 --> Model Class Initialized
INFO - 2018-02-13 06:51:53 --> Controller Class Initialized
INFO - 2018-02-13 06:51:53 --> Model Class Initialized
INFO - 2018-02-13 06:51:53 --> Model Class Initialized
INFO - 2018-02-13 06:51:53 --> Model Class Initialized
INFO - 2018-02-13 06:51:53 --> Model Class Initialized
INFO - 2018-02-13 06:51:53 --> Model Class Initialized
DEBUG - 2018-02-13 06:51:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 06:51:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:51:53 --> Form Validation Class Initialized
INFO - 2018-02-13 06:51:53 --> Model Class Initialized
INFO - 2018-02-13 06:51:53 --> Controller Class Initialized
INFO - 2018-02-13 06:51:53 --> Model Class Initialized
INFO - 2018-02-13 06:51:53 --> Model Class Initialized
INFO - 2018-02-13 06:51:53 --> Model Class Initialized
INFO - 2018-02-13 06:51:53 --> Model Class Initialized
INFO - 2018-02-13 06:51:53 --> Model Class Initialized
DEBUG - 2018-02-13 06:51:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 06:51:56 --> Config Class Initialized
INFO - 2018-02-13 06:51:56 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:51:56 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:51:56 --> Utf8 Class Initialized
INFO - 2018-02-13 06:51:56 --> URI Class Initialized
INFO - 2018-02-13 06:51:56 --> Router Class Initialized
INFO - 2018-02-13 06:51:56 --> Output Class Initialized
INFO - 2018-02-13 06:51:56 --> Security Class Initialized
DEBUG - 2018-02-13 06:51:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:51:56 --> Input Class Initialized
INFO - 2018-02-13 06:51:56 --> Language Class Initialized
INFO - 2018-02-13 06:51:56 --> Loader Class Initialized
INFO - 2018-02-13 06:51:56 --> Helper loaded: url_helper
INFO - 2018-02-13 06:51:56 --> Helper loaded: form_helper
INFO - 2018-02-13 06:51:56 --> Database Driver Class Initialized
DEBUG - 2018-02-13 06:51:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 06:51:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:51:56 --> Form Validation Class Initialized
INFO - 2018-02-13 06:51:56 --> Model Class Initialized
INFO - 2018-02-13 06:51:56 --> Controller Class Initialized
INFO - 2018-02-13 06:51:56 --> Model Class Initialized
INFO - 2018-02-13 06:51:56 --> Model Class Initialized
INFO - 2018-02-13 06:51:56 --> Model Class Initialized
INFO - 2018-02-13 06:51:56 --> Model Class Initialized
INFO - 2018-02-13 06:51:56 --> Model Class Initialized
DEBUG - 2018-02-13 06:51:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 06:51:56 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 06:51:56 --> Final output sent to browser
DEBUG - 2018-02-13 06:51:56 --> Total execution time: 0.1166
INFO - 2018-02-13 06:51:56 --> Config Class Initialized
INFO - 2018-02-13 06:51:56 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:51:56 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:51:56 --> Utf8 Class Initialized
INFO - 2018-02-13 06:51:56 --> URI Class Initialized
INFO - 2018-02-13 06:51:56 --> Router Class Initialized
INFO - 2018-02-13 06:51:56 --> Output Class Initialized
INFO - 2018-02-13 06:51:56 --> Security Class Initialized
DEBUG - 2018-02-13 06:51:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:51:56 --> Input Class Initialized
INFO - 2018-02-13 06:51:56 --> Language Class Initialized
INFO - 2018-02-13 06:51:56 --> Loader Class Initialized
INFO - 2018-02-13 06:51:56 --> Helper loaded: url_helper
INFO - 2018-02-13 06:51:56 --> Helper loaded: form_helper
INFO - 2018-02-13 06:51:56 --> Database Driver Class Initialized
DEBUG - 2018-02-13 06:51:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 06:51:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:51:56 --> Form Validation Class Initialized
INFO - 2018-02-13 06:51:56 --> Model Class Initialized
INFO - 2018-02-13 06:51:56 --> Controller Class Initialized
INFO - 2018-02-13 06:51:56 --> Model Class Initialized
INFO - 2018-02-13 06:51:56 --> Model Class Initialized
INFO - 2018-02-13 06:51:56 --> Model Class Initialized
INFO - 2018-02-13 06:51:56 --> Model Class Initialized
INFO - 2018-02-13 06:51:56 --> Model Class Initialized
DEBUG - 2018-02-13 06:51:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 06:51:58 --> Config Class Initialized
INFO - 2018-02-13 06:51:58 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:51:58 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:51:58 --> Utf8 Class Initialized
INFO - 2018-02-13 06:51:58 --> URI Class Initialized
INFO - 2018-02-13 06:51:58 --> Router Class Initialized
INFO - 2018-02-13 06:51:58 --> Output Class Initialized
INFO - 2018-02-13 06:51:58 --> Security Class Initialized
DEBUG - 2018-02-13 06:51:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:51:58 --> Input Class Initialized
INFO - 2018-02-13 06:51:58 --> Language Class Initialized
INFO - 2018-02-13 06:51:58 --> Loader Class Initialized
INFO - 2018-02-13 06:51:58 --> Helper loaded: url_helper
INFO - 2018-02-13 06:51:58 --> Helper loaded: form_helper
INFO - 2018-02-13 06:51:58 --> Database Driver Class Initialized
DEBUG - 2018-02-13 06:51:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 06:51:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:51:58 --> Form Validation Class Initialized
INFO - 2018-02-13 06:51:58 --> Model Class Initialized
INFO - 2018-02-13 06:51:58 --> Controller Class Initialized
INFO - 2018-02-13 06:51:58 --> Model Class Initialized
INFO - 2018-02-13 06:51:58 --> Model Class Initialized
INFO - 2018-02-13 06:51:58 --> Model Class Initialized
INFO - 2018-02-13 06:51:58 --> Model Class Initialized
INFO - 2018-02-13 06:51:58 --> Model Class Initialized
DEBUG - 2018-02-13 06:51:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 06:51:58 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 06:51:58 --> Final output sent to browser
DEBUG - 2018-02-13 06:51:58 --> Total execution time: 0.0932
INFO - 2018-02-13 06:51:58 --> Config Class Initialized
INFO - 2018-02-13 06:51:58 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:51:58 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:51:58 --> Utf8 Class Initialized
INFO - 2018-02-13 06:51:58 --> URI Class Initialized
INFO - 2018-02-13 06:51:58 --> Router Class Initialized
INFO - 2018-02-13 06:51:58 --> Output Class Initialized
INFO - 2018-02-13 06:51:58 --> Security Class Initialized
DEBUG - 2018-02-13 06:51:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:51:58 --> Input Class Initialized
INFO - 2018-02-13 06:51:58 --> Language Class Initialized
INFO - 2018-02-13 06:51:58 --> Loader Class Initialized
INFO - 2018-02-13 06:51:58 --> Helper loaded: url_helper
INFO - 2018-02-13 06:51:58 --> Helper loaded: form_helper
INFO - 2018-02-13 06:51:58 --> Database Driver Class Initialized
DEBUG - 2018-02-13 06:51:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 06:51:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:51:58 --> Form Validation Class Initialized
INFO - 2018-02-13 06:51:58 --> Model Class Initialized
INFO - 2018-02-13 06:51:58 --> Controller Class Initialized
INFO - 2018-02-13 06:51:58 --> Model Class Initialized
INFO - 2018-02-13 06:51:58 --> Model Class Initialized
INFO - 2018-02-13 06:51:58 --> Model Class Initialized
INFO - 2018-02-13 06:51:58 --> Model Class Initialized
INFO - 2018-02-13 06:51:58 --> Model Class Initialized
DEBUG - 2018-02-13 06:51:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 06:52:02 --> Config Class Initialized
INFO - 2018-02-13 06:52:02 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:52:02 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:52:02 --> Utf8 Class Initialized
INFO - 2018-02-13 06:52:02 --> URI Class Initialized
INFO - 2018-02-13 06:52:02 --> Router Class Initialized
INFO - 2018-02-13 06:52:02 --> Output Class Initialized
INFO - 2018-02-13 06:52:02 --> Security Class Initialized
DEBUG - 2018-02-13 06:52:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:52:02 --> Input Class Initialized
INFO - 2018-02-13 06:52:02 --> Language Class Initialized
INFO - 2018-02-13 06:52:02 --> Loader Class Initialized
INFO - 2018-02-13 06:52:02 --> Helper loaded: url_helper
INFO - 2018-02-13 06:52:02 --> Helper loaded: form_helper
INFO - 2018-02-13 06:52:02 --> Database Driver Class Initialized
DEBUG - 2018-02-13 06:52:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 06:52:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:52:02 --> Form Validation Class Initialized
INFO - 2018-02-13 06:52:02 --> Model Class Initialized
INFO - 2018-02-13 06:52:02 --> Controller Class Initialized
INFO - 2018-02-13 06:52:02 --> Model Class Initialized
INFO - 2018-02-13 06:52:02 --> Model Class Initialized
INFO - 2018-02-13 06:52:02 --> Model Class Initialized
INFO - 2018-02-13 06:52:02 --> Model Class Initialized
INFO - 2018-02-13 06:52:02 --> Model Class Initialized
DEBUG - 2018-02-13 06:52:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 06:52:02 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 06:52:02 --> Final output sent to browser
DEBUG - 2018-02-13 06:52:02 --> Total execution time: 0.0876
INFO - 2018-02-13 06:52:03 --> Config Class Initialized
INFO - 2018-02-13 06:52:03 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:52:03 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:52:03 --> Utf8 Class Initialized
INFO - 2018-02-13 06:52:03 --> URI Class Initialized
INFO - 2018-02-13 06:52:03 --> Router Class Initialized
INFO - 2018-02-13 06:52:03 --> Output Class Initialized
INFO - 2018-02-13 06:52:03 --> Security Class Initialized
DEBUG - 2018-02-13 06:52:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:52:03 --> Input Class Initialized
INFO - 2018-02-13 06:52:03 --> Language Class Initialized
INFO - 2018-02-13 06:52:03 --> Loader Class Initialized
INFO - 2018-02-13 06:52:03 --> Helper loaded: url_helper
INFO - 2018-02-13 06:52:03 --> Helper loaded: form_helper
INFO - 2018-02-13 06:52:03 --> Database Driver Class Initialized
DEBUG - 2018-02-13 06:52:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 06:52:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:52:03 --> Form Validation Class Initialized
INFO - 2018-02-13 06:52:03 --> Model Class Initialized
INFO - 2018-02-13 06:52:03 --> Controller Class Initialized
INFO - 2018-02-13 06:52:03 --> Model Class Initialized
INFO - 2018-02-13 06:52:03 --> Model Class Initialized
INFO - 2018-02-13 06:52:03 --> Model Class Initialized
INFO - 2018-02-13 06:52:03 --> Model Class Initialized
INFO - 2018-02-13 06:52:03 --> Model Class Initialized
DEBUG - 2018-02-13 06:52:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 06:52:11 --> Config Class Initialized
INFO - 2018-02-13 06:52:11 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:52:11 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:52:11 --> Utf8 Class Initialized
INFO - 2018-02-13 06:52:11 --> URI Class Initialized
INFO - 2018-02-13 06:52:11 --> Router Class Initialized
INFO - 2018-02-13 06:52:11 --> Output Class Initialized
INFO - 2018-02-13 06:52:11 --> Security Class Initialized
DEBUG - 2018-02-13 06:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:52:11 --> Input Class Initialized
INFO - 2018-02-13 06:52:11 --> Language Class Initialized
INFO - 2018-02-13 06:52:11 --> Loader Class Initialized
INFO - 2018-02-13 06:52:11 --> Helper loaded: url_helper
INFO - 2018-02-13 06:52:11 --> Helper loaded: form_helper
INFO - 2018-02-13 06:52:11 --> Database Driver Class Initialized
DEBUG - 2018-02-13 06:52:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 06:52:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:52:11 --> Form Validation Class Initialized
INFO - 2018-02-13 06:52:11 --> Model Class Initialized
INFO - 2018-02-13 06:52:11 --> Controller Class Initialized
INFO - 2018-02-13 06:52:11 --> Model Class Initialized
INFO - 2018-02-13 06:52:11 --> Model Class Initialized
INFO - 2018-02-13 06:52:11 --> Model Class Initialized
INFO - 2018-02-13 06:52:11 --> Model Class Initialized
INFO - 2018-02-13 06:52:11 --> Model Class Initialized
DEBUG - 2018-02-13 06:52:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 06:52:11 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 06:52:11 --> Final output sent to browser
DEBUG - 2018-02-13 06:52:11 --> Total execution time: 0.1093
INFO - 2018-02-13 06:52:11 --> Config Class Initialized
INFO - 2018-02-13 06:52:11 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:52:11 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:52:11 --> Utf8 Class Initialized
INFO - 2018-02-13 06:52:11 --> URI Class Initialized
INFO - 2018-02-13 06:52:11 --> Router Class Initialized
INFO - 2018-02-13 06:52:11 --> Output Class Initialized
INFO - 2018-02-13 06:52:11 --> Security Class Initialized
DEBUG - 2018-02-13 06:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:52:11 --> Input Class Initialized
INFO - 2018-02-13 06:52:11 --> Language Class Initialized
INFO - 2018-02-13 06:52:11 --> Loader Class Initialized
INFO - 2018-02-13 06:52:11 --> Helper loaded: url_helper
INFO - 2018-02-13 06:52:11 --> Helper loaded: form_helper
INFO - 2018-02-13 06:52:11 --> Database Driver Class Initialized
DEBUG - 2018-02-13 06:52:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 06:52:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:52:11 --> Form Validation Class Initialized
INFO - 2018-02-13 06:52:11 --> Model Class Initialized
INFO - 2018-02-13 06:52:11 --> Controller Class Initialized
INFO - 2018-02-13 06:52:11 --> Model Class Initialized
INFO - 2018-02-13 06:52:11 --> Model Class Initialized
INFO - 2018-02-13 06:52:11 --> Model Class Initialized
INFO - 2018-02-13 06:52:11 --> Model Class Initialized
INFO - 2018-02-13 06:52:11 --> Model Class Initialized
DEBUG - 2018-02-13 06:52:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 06:52:14 --> Config Class Initialized
INFO - 2018-02-13 06:52:14 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:52:14 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:52:14 --> Utf8 Class Initialized
INFO - 2018-02-13 06:52:14 --> URI Class Initialized
INFO - 2018-02-13 06:52:14 --> Router Class Initialized
INFO - 2018-02-13 06:52:14 --> Output Class Initialized
INFO - 2018-02-13 06:52:14 --> Security Class Initialized
DEBUG - 2018-02-13 06:52:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:52:14 --> Input Class Initialized
INFO - 2018-02-13 06:52:14 --> Language Class Initialized
INFO - 2018-02-13 06:52:14 --> Loader Class Initialized
INFO - 2018-02-13 06:52:14 --> Helper loaded: url_helper
INFO - 2018-02-13 06:52:14 --> Helper loaded: form_helper
INFO - 2018-02-13 06:52:14 --> Database Driver Class Initialized
DEBUG - 2018-02-13 06:52:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 06:52:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:52:14 --> Form Validation Class Initialized
INFO - 2018-02-13 06:52:14 --> Model Class Initialized
INFO - 2018-02-13 06:52:14 --> Controller Class Initialized
INFO - 2018-02-13 06:52:14 --> Model Class Initialized
INFO - 2018-02-13 06:52:14 --> Model Class Initialized
INFO - 2018-02-13 06:52:14 --> Model Class Initialized
INFO - 2018-02-13 06:52:14 --> Model Class Initialized
INFO - 2018-02-13 06:52:14 --> Model Class Initialized
DEBUG - 2018-02-13 06:52:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 06:52:14 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 06:52:14 --> Final output sent to browser
DEBUG - 2018-02-13 06:52:14 --> Total execution time: 0.1604
INFO - 2018-02-13 06:52:15 --> Config Class Initialized
INFO - 2018-02-13 06:52:15 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:52:15 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:52:15 --> Utf8 Class Initialized
INFO - 2018-02-13 06:52:15 --> URI Class Initialized
INFO - 2018-02-13 06:52:15 --> Router Class Initialized
INFO - 2018-02-13 06:52:15 --> Output Class Initialized
INFO - 2018-02-13 06:52:15 --> Security Class Initialized
DEBUG - 2018-02-13 06:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:52:15 --> Input Class Initialized
INFO - 2018-02-13 06:52:15 --> Language Class Initialized
INFO - 2018-02-13 06:52:15 --> Loader Class Initialized
INFO - 2018-02-13 06:52:15 --> Helper loaded: url_helper
INFO - 2018-02-13 06:52:15 --> Helper loaded: form_helper
INFO - 2018-02-13 06:52:15 --> Database Driver Class Initialized
DEBUG - 2018-02-13 06:52:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 06:52:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:52:15 --> Form Validation Class Initialized
INFO - 2018-02-13 06:52:15 --> Model Class Initialized
INFO - 2018-02-13 06:52:15 --> Controller Class Initialized
INFO - 2018-02-13 06:52:15 --> Model Class Initialized
INFO - 2018-02-13 06:52:15 --> Model Class Initialized
INFO - 2018-02-13 06:52:15 --> Model Class Initialized
INFO - 2018-02-13 06:52:15 --> Model Class Initialized
INFO - 2018-02-13 06:52:15 --> Model Class Initialized
DEBUG - 2018-02-13 06:52:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 06:52:15 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 06:52:15 --> Final output sent to browser
DEBUG - 2018-02-13 06:52:15 --> Total execution time: 0.0770
INFO - 2018-02-13 06:52:15 --> Config Class Initialized
INFO - 2018-02-13 06:52:15 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:52:15 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:52:15 --> Utf8 Class Initialized
INFO - 2018-02-13 06:52:15 --> URI Class Initialized
INFO - 2018-02-13 06:52:15 --> Router Class Initialized
INFO - 2018-02-13 06:52:15 --> Output Class Initialized
INFO - 2018-02-13 06:52:15 --> Security Class Initialized
DEBUG - 2018-02-13 06:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:52:15 --> Input Class Initialized
INFO - 2018-02-13 06:52:15 --> Language Class Initialized
INFO - 2018-02-13 06:52:15 --> Loader Class Initialized
INFO - 2018-02-13 06:52:15 --> Helper loaded: url_helper
INFO - 2018-02-13 06:52:15 --> Helper loaded: form_helper
INFO - 2018-02-13 06:52:15 --> Database Driver Class Initialized
DEBUG - 2018-02-13 06:52:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 06:52:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:52:15 --> Form Validation Class Initialized
INFO - 2018-02-13 06:52:15 --> Model Class Initialized
INFO - 2018-02-13 06:52:15 --> Controller Class Initialized
INFO - 2018-02-13 06:52:15 --> Model Class Initialized
INFO - 2018-02-13 06:52:15 --> Model Class Initialized
INFO - 2018-02-13 06:52:15 --> Model Class Initialized
INFO - 2018-02-13 06:52:15 --> Model Class Initialized
INFO - 2018-02-13 06:52:15 --> Model Class Initialized
DEBUG - 2018-02-13 06:52:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 06:52:18 --> Config Class Initialized
INFO - 2018-02-13 06:52:18 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:52:18 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:52:18 --> Utf8 Class Initialized
INFO - 2018-02-13 06:52:18 --> URI Class Initialized
INFO - 2018-02-13 06:52:18 --> Router Class Initialized
INFO - 2018-02-13 06:52:18 --> Output Class Initialized
INFO - 2018-02-13 06:52:18 --> Security Class Initialized
DEBUG - 2018-02-13 06:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:52:18 --> Input Class Initialized
INFO - 2018-02-13 06:52:18 --> Language Class Initialized
INFO - 2018-02-13 06:52:18 --> Loader Class Initialized
INFO - 2018-02-13 06:52:18 --> Helper loaded: url_helper
INFO - 2018-02-13 06:52:18 --> Helper loaded: form_helper
INFO - 2018-02-13 06:52:18 --> Database Driver Class Initialized
DEBUG - 2018-02-13 06:52:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 06:52:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:52:18 --> Form Validation Class Initialized
INFO - 2018-02-13 06:52:18 --> Model Class Initialized
INFO - 2018-02-13 06:52:18 --> Controller Class Initialized
INFO - 2018-02-13 06:52:18 --> Model Class Initialized
INFO - 2018-02-13 06:52:18 --> Model Class Initialized
INFO - 2018-02-13 06:52:18 --> Model Class Initialized
INFO - 2018-02-13 06:52:18 --> Model Class Initialized
INFO - 2018-02-13 06:52:18 --> Model Class Initialized
DEBUG - 2018-02-13 06:52:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 06:52:18 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 06:52:18 --> Final output sent to browser
DEBUG - 2018-02-13 06:52:18 --> Total execution time: 0.1342
INFO - 2018-02-13 06:52:21 --> Config Class Initialized
INFO - 2018-02-13 06:52:21 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:52:21 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:52:21 --> Utf8 Class Initialized
INFO - 2018-02-13 06:52:21 --> URI Class Initialized
INFO - 2018-02-13 06:52:21 --> Router Class Initialized
INFO - 2018-02-13 06:52:21 --> Output Class Initialized
INFO - 2018-02-13 06:52:21 --> Security Class Initialized
DEBUG - 2018-02-13 06:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:52:21 --> Input Class Initialized
INFO - 2018-02-13 06:52:21 --> Language Class Initialized
INFO - 2018-02-13 06:52:21 --> Loader Class Initialized
INFO - 2018-02-13 06:52:21 --> Helper loaded: url_helper
INFO - 2018-02-13 06:52:21 --> Helper loaded: form_helper
INFO - 2018-02-13 06:52:21 --> Database Driver Class Initialized
DEBUG - 2018-02-13 06:52:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 06:52:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:52:21 --> Form Validation Class Initialized
INFO - 2018-02-13 06:52:21 --> Model Class Initialized
INFO - 2018-02-13 06:52:21 --> Controller Class Initialized
INFO - 2018-02-13 06:52:21 --> Model Class Initialized
INFO - 2018-02-13 06:52:21 --> Model Class Initialized
INFO - 2018-02-13 06:52:21 --> Model Class Initialized
INFO - 2018-02-13 06:52:21 --> Model Class Initialized
INFO - 2018-02-13 06:52:21 --> Model Class Initialized
DEBUG - 2018-02-13 06:52:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 06:52:21 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 06:52:21 --> Final output sent to browser
DEBUG - 2018-02-13 06:52:21 --> Total execution time: 0.0934
INFO - 2018-02-13 06:52:21 --> Config Class Initialized
INFO - 2018-02-13 06:52:21 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:52:21 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:52:21 --> Utf8 Class Initialized
INFO - 2018-02-13 06:52:21 --> URI Class Initialized
INFO - 2018-02-13 06:52:21 --> Router Class Initialized
INFO - 2018-02-13 06:52:21 --> Output Class Initialized
INFO - 2018-02-13 06:52:21 --> Security Class Initialized
DEBUG - 2018-02-13 06:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:52:21 --> Input Class Initialized
INFO - 2018-02-13 06:52:21 --> Language Class Initialized
INFO - 2018-02-13 06:52:21 --> Loader Class Initialized
INFO - 2018-02-13 06:52:21 --> Helper loaded: url_helper
INFO - 2018-02-13 06:52:21 --> Helper loaded: form_helper
INFO - 2018-02-13 06:52:21 --> Database Driver Class Initialized
DEBUG - 2018-02-13 06:52:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 06:52:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:52:21 --> Form Validation Class Initialized
INFO - 2018-02-13 06:52:21 --> Model Class Initialized
INFO - 2018-02-13 06:52:21 --> Controller Class Initialized
INFO - 2018-02-13 06:52:21 --> Model Class Initialized
INFO - 2018-02-13 06:52:21 --> Model Class Initialized
INFO - 2018-02-13 06:52:21 --> Model Class Initialized
INFO - 2018-02-13 06:52:21 --> Model Class Initialized
INFO - 2018-02-13 06:52:21 --> Model Class Initialized
DEBUG - 2018-02-13 06:52:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 06:52:23 --> Config Class Initialized
INFO - 2018-02-13 06:52:23 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:52:23 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:52:23 --> Utf8 Class Initialized
INFO - 2018-02-13 06:52:23 --> URI Class Initialized
INFO - 2018-02-13 06:52:23 --> Router Class Initialized
INFO - 2018-02-13 06:52:23 --> Output Class Initialized
INFO - 2018-02-13 06:52:23 --> Security Class Initialized
DEBUG - 2018-02-13 06:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:52:23 --> Input Class Initialized
INFO - 2018-02-13 06:52:23 --> Language Class Initialized
INFO - 2018-02-13 06:52:23 --> Loader Class Initialized
INFO - 2018-02-13 06:52:23 --> Helper loaded: url_helper
INFO - 2018-02-13 06:52:23 --> Helper loaded: form_helper
INFO - 2018-02-13 06:52:23 --> Database Driver Class Initialized
DEBUG - 2018-02-13 06:52:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 06:52:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:52:23 --> Form Validation Class Initialized
INFO - 2018-02-13 06:52:23 --> Model Class Initialized
INFO - 2018-02-13 06:52:23 --> Controller Class Initialized
INFO - 2018-02-13 06:52:23 --> Model Class Initialized
INFO - 2018-02-13 06:52:23 --> Model Class Initialized
INFO - 2018-02-13 06:52:23 --> Model Class Initialized
INFO - 2018-02-13 06:52:23 --> Model Class Initialized
INFO - 2018-02-13 06:52:23 --> Model Class Initialized
DEBUG - 2018-02-13 06:52:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 06:52:23 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 06:52:23 --> Final output sent to browser
DEBUG - 2018-02-13 06:52:23 --> Total execution time: 0.1254
INFO - 2018-02-13 06:52:23 --> Config Class Initialized
INFO - 2018-02-13 06:52:23 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:52:23 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:52:23 --> Utf8 Class Initialized
INFO - 2018-02-13 06:52:23 --> URI Class Initialized
INFO - 2018-02-13 06:52:23 --> Router Class Initialized
INFO - 2018-02-13 06:52:23 --> Output Class Initialized
INFO - 2018-02-13 06:52:23 --> Security Class Initialized
DEBUG - 2018-02-13 06:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:52:23 --> Input Class Initialized
INFO - 2018-02-13 06:52:23 --> Language Class Initialized
INFO - 2018-02-13 06:52:23 --> Loader Class Initialized
INFO - 2018-02-13 06:52:23 --> Helper loaded: url_helper
INFO - 2018-02-13 06:52:23 --> Helper loaded: form_helper
INFO - 2018-02-13 06:52:23 --> Database Driver Class Initialized
DEBUG - 2018-02-13 06:52:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 06:52:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:52:23 --> Form Validation Class Initialized
INFO - 2018-02-13 06:52:23 --> Model Class Initialized
INFO - 2018-02-13 06:52:23 --> Controller Class Initialized
INFO - 2018-02-13 06:52:23 --> Model Class Initialized
INFO - 2018-02-13 06:52:23 --> Model Class Initialized
INFO - 2018-02-13 06:52:23 --> Model Class Initialized
INFO - 2018-02-13 06:52:23 --> Model Class Initialized
INFO - 2018-02-13 06:52:23 --> Model Class Initialized
DEBUG - 2018-02-13 06:52:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 06:52:24 --> Config Class Initialized
INFO - 2018-02-13 06:52:24 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:52:24 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:52:24 --> Utf8 Class Initialized
INFO - 2018-02-13 06:52:24 --> URI Class Initialized
INFO - 2018-02-13 06:52:25 --> Router Class Initialized
INFO - 2018-02-13 06:52:25 --> Output Class Initialized
INFO - 2018-02-13 06:52:25 --> Security Class Initialized
DEBUG - 2018-02-13 06:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:52:25 --> Input Class Initialized
INFO - 2018-02-13 06:52:25 --> Language Class Initialized
INFO - 2018-02-13 06:52:25 --> Loader Class Initialized
INFO - 2018-02-13 06:52:25 --> Helper loaded: url_helper
INFO - 2018-02-13 06:52:25 --> Helper loaded: form_helper
INFO - 2018-02-13 06:52:25 --> Database Driver Class Initialized
DEBUG - 2018-02-13 06:52:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 06:52:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:52:25 --> Form Validation Class Initialized
INFO - 2018-02-13 06:52:25 --> Model Class Initialized
INFO - 2018-02-13 06:52:25 --> Controller Class Initialized
INFO - 2018-02-13 06:52:25 --> Model Class Initialized
INFO - 2018-02-13 06:52:25 --> Model Class Initialized
INFO - 2018-02-13 06:52:25 --> Model Class Initialized
INFO - 2018-02-13 06:52:25 --> Model Class Initialized
INFO - 2018-02-13 06:52:25 --> Model Class Initialized
DEBUG - 2018-02-13 06:52:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 06:52:25 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 06:52:25 --> Final output sent to browser
DEBUG - 2018-02-13 06:52:25 --> Total execution time: 0.1571
INFO - 2018-02-13 06:52:25 --> Config Class Initialized
INFO - 2018-02-13 06:52:25 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:52:25 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:52:25 --> Utf8 Class Initialized
INFO - 2018-02-13 06:52:25 --> URI Class Initialized
INFO - 2018-02-13 06:52:25 --> Router Class Initialized
INFO - 2018-02-13 06:52:25 --> Output Class Initialized
INFO - 2018-02-13 06:52:25 --> Security Class Initialized
DEBUG - 2018-02-13 06:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:52:25 --> Input Class Initialized
INFO - 2018-02-13 06:52:25 --> Language Class Initialized
INFO - 2018-02-13 06:52:25 --> Loader Class Initialized
INFO - 2018-02-13 06:52:25 --> Helper loaded: url_helper
INFO - 2018-02-13 06:52:25 --> Helper loaded: form_helper
INFO - 2018-02-13 06:52:25 --> Database Driver Class Initialized
DEBUG - 2018-02-13 06:52:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 06:52:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:52:25 --> Form Validation Class Initialized
INFO - 2018-02-13 06:52:25 --> Model Class Initialized
INFO - 2018-02-13 06:52:25 --> Controller Class Initialized
INFO - 2018-02-13 06:52:25 --> Model Class Initialized
INFO - 2018-02-13 06:52:25 --> Model Class Initialized
INFO - 2018-02-13 06:52:25 --> Model Class Initialized
INFO - 2018-02-13 06:52:25 --> Model Class Initialized
INFO - 2018-02-13 06:52:25 --> Model Class Initialized
DEBUG - 2018-02-13 06:52:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 06:52:29 --> Config Class Initialized
INFO - 2018-02-13 06:52:29 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:52:29 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:52:29 --> Utf8 Class Initialized
INFO - 2018-02-13 06:52:29 --> URI Class Initialized
INFO - 2018-02-13 06:52:29 --> Router Class Initialized
INFO - 2018-02-13 06:52:29 --> Output Class Initialized
INFO - 2018-02-13 06:52:29 --> Security Class Initialized
DEBUG - 2018-02-13 06:52:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:52:29 --> Input Class Initialized
INFO - 2018-02-13 06:52:29 --> Language Class Initialized
INFO - 2018-02-13 06:52:29 --> Loader Class Initialized
INFO - 2018-02-13 06:52:29 --> Helper loaded: url_helper
INFO - 2018-02-13 06:52:29 --> Helper loaded: form_helper
INFO - 2018-02-13 06:52:29 --> Database Driver Class Initialized
DEBUG - 2018-02-13 06:52:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 06:52:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:52:29 --> Form Validation Class Initialized
INFO - 2018-02-13 06:52:29 --> Model Class Initialized
INFO - 2018-02-13 06:52:29 --> Controller Class Initialized
INFO - 2018-02-13 06:52:29 --> Model Class Initialized
INFO - 2018-02-13 06:52:29 --> Model Class Initialized
INFO - 2018-02-13 06:52:29 --> Model Class Initialized
INFO - 2018-02-13 06:52:29 --> Model Class Initialized
INFO - 2018-02-13 06:52:29 --> Model Class Initialized
DEBUG - 2018-02-13 06:52:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 06:52:29 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 06:52:29 --> Final output sent to browser
DEBUG - 2018-02-13 06:52:29 --> Total execution time: 0.1279
INFO - 2018-02-13 06:52:29 --> Config Class Initialized
INFO - 2018-02-13 06:52:29 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:52:29 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:52:29 --> Utf8 Class Initialized
INFO - 2018-02-13 06:52:29 --> URI Class Initialized
INFO - 2018-02-13 06:52:29 --> Router Class Initialized
INFO - 2018-02-13 06:52:29 --> Output Class Initialized
INFO - 2018-02-13 06:52:29 --> Security Class Initialized
DEBUG - 2018-02-13 06:52:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:52:29 --> Input Class Initialized
INFO - 2018-02-13 06:52:29 --> Language Class Initialized
INFO - 2018-02-13 06:52:29 --> Loader Class Initialized
INFO - 2018-02-13 06:52:29 --> Helper loaded: url_helper
INFO - 2018-02-13 06:52:29 --> Helper loaded: form_helper
INFO - 2018-02-13 06:52:29 --> Database Driver Class Initialized
DEBUG - 2018-02-13 06:52:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 06:52:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:52:29 --> Form Validation Class Initialized
INFO - 2018-02-13 06:52:29 --> Model Class Initialized
INFO - 2018-02-13 06:52:29 --> Controller Class Initialized
INFO - 2018-02-13 06:52:29 --> Model Class Initialized
INFO - 2018-02-13 06:52:29 --> Model Class Initialized
INFO - 2018-02-13 06:52:29 --> Model Class Initialized
INFO - 2018-02-13 06:52:29 --> Model Class Initialized
INFO - 2018-02-13 06:52:29 --> Model Class Initialized
DEBUG - 2018-02-13 06:52:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 07:02:15 --> Config Class Initialized
INFO - 2018-02-13 07:02:15 --> Hooks Class Initialized
DEBUG - 2018-02-13 07:02:15 --> UTF-8 Support Enabled
INFO - 2018-02-13 07:02:15 --> Utf8 Class Initialized
INFO - 2018-02-13 07:02:15 --> URI Class Initialized
INFO - 2018-02-13 07:02:15 --> Router Class Initialized
INFO - 2018-02-13 07:02:15 --> Output Class Initialized
INFO - 2018-02-13 07:02:15 --> Security Class Initialized
DEBUG - 2018-02-13 07:02:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 07:02:15 --> Input Class Initialized
INFO - 2018-02-13 07:02:15 --> Language Class Initialized
INFO - 2018-02-13 07:02:15 --> Loader Class Initialized
INFO - 2018-02-13 07:02:15 --> Helper loaded: url_helper
INFO - 2018-02-13 07:02:15 --> Helper loaded: form_helper
INFO - 2018-02-13 07:02:15 --> Database Driver Class Initialized
DEBUG - 2018-02-13 07:02:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 07:02:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 07:02:15 --> Form Validation Class Initialized
INFO - 2018-02-13 07:02:15 --> Model Class Initialized
INFO - 2018-02-13 07:02:15 --> Controller Class Initialized
INFO - 2018-02-13 07:02:15 --> Model Class Initialized
INFO - 2018-02-13 07:02:15 --> Model Class Initialized
INFO - 2018-02-13 07:02:15 --> Model Class Initialized
INFO - 2018-02-13 07:02:15 --> Model Class Initialized
INFO - 2018-02-13 07:02:15 --> Model Class Initialized
DEBUG - 2018-02-13 07:02:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 07:02:15 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 07:02:15 --> Final output sent to browser
DEBUG - 2018-02-13 07:02:15 --> Total execution time: 0.0909
INFO - 2018-02-13 07:02:15 --> Config Class Initialized
INFO - 2018-02-13 07:02:15 --> Hooks Class Initialized
DEBUG - 2018-02-13 07:02:15 --> UTF-8 Support Enabled
INFO - 2018-02-13 07:02:15 --> Utf8 Class Initialized
INFO - 2018-02-13 07:02:15 --> URI Class Initialized
INFO - 2018-02-13 07:02:15 --> Router Class Initialized
INFO - 2018-02-13 07:02:15 --> Output Class Initialized
INFO - 2018-02-13 07:02:15 --> Security Class Initialized
DEBUG - 2018-02-13 07:02:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 07:02:15 --> Input Class Initialized
INFO - 2018-02-13 07:02:15 --> Language Class Initialized
INFO - 2018-02-13 07:02:15 --> Loader Class Initialized
INFO - 2018-02-13 07:02:15 --> Config Class Initialized
INFO - 2018-02-13 07:02:15 --> Hooks Class Initialized
INFO - 2018-02-13 07:02:15 --> Helper loaded: url_helper
INFO - 2018-02-13 07:02:15 --> Helper loaded: form_helper
DEBUG - 2018-02-13 07:02:15 --> UTF-8 Support Enabled
INFO - 2018-02-13 07:02:15 --> Utf8 Class Initialized
INFO - 2018-02-13 07:02:15 --> URI Class Initialized
INFO - 2018-02-13 07:02:15 --> Router Class Initialized
INFO - 2018-02-13 07:02:15 --> Database Driver Class Initialized
INFO - 2018-02-13 07:02:15 --> Output Class Initialized
INFO - 2018-02-13 07:02:15 --> Security Class Initialized
DEBUG - 2018-02-13 07:02:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 07:02:15 --> Input Class Initialized
INFO - 2018-02-13 07:02:15 --> Language Class Initialized
DEBUG - 2018-02-13 07:02:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 07:02:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 07:02:15 --> Form Validation Class Initialized
INFO - 2018-02-13 07:02:15 --> Loader Class Initialized
INFO - 2018-02-13 07:02:15 --> Model Class Initialized
INFO - 2018-02-13 07:02:15 --> Controller Class Initialized
INFO - 2018-02-13 07:02:15 --> Helper loaded: url_helper
INFO - 2018-02-13 07:02:15 --> Helper loaded: form_helper
INFO - 2018-02-13 07:02:15 --> Model Class Initialized
INFO - 2018-02-13 07:02:15 --> Model Class Initialized
INFO - 2018-02-13 07:02:15 --> Model Class Initialized
INFO - 2018-02-13 07:02:15 --> Model Class Initialized
INFO - 2018-02-13 07:02:15 --> Model Class Initialized
DEBUG - 2018-02-13 07:02:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 07:02:15 --> Database Driver Class Initialized
DEBUG - 2018-02-13 07:02:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 07:02:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 07:02:15 --> Form Validation Class Initialized
INFO - 2018-02-13 07:02:15 --> Model Class Initialized
INFO - 2018-02-13 07:02:15 --> Controller Class Initialized
INFO - 2018-02-13 07:02:15 --> Model Class Initialized
INFO - 2018-02-13 07:02:15 --> Model Class Initialized
INFO - 2018-02-13 07:02:15 --> Model Class Initialized
INFO - 2018-02-13 07:02:15 --> Model Class Initialized
INFO - 2018-02-13 07:02:15 --> Model Class Initialized
DEBUG - 2018-02-13 07:02:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 07:02:15 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 07:02:15 --> Final output sent to browser
DEBUG - 2018-02-13 07:02:15 --> Total execution time: 0.0565
INFO - 2018-02-13 07:02:15 --> Config Class Initialized
INFO - 2018-02-13 07:02:15 --> Hooks Class Initialized
DEBUG - 2018-02-13 07:02:15 --> UTF-8 Support Enabled
INFO - 2018-02-13 07:02:15 --> Utf8 Class Initialized
INFO - 2018-02-13 07:02:15 --> URI Class Initialized
INFO - 2018-02-13 07:02:15 --> Router Class Initialized
INFO - 2018-02-13 07:02:15 --> Output Class Initialized
INFO - 2018-02-13 07:02:15 --> Security Class Initialized
DEBUG - 2018-02-13 07:02:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 07:02:15 --> Input Class Initialized
INFO - 2018-02-13 07:02:15 --> Language Class Initialized
INFO - 2018-02-13 07:02:15 --> Loader Class Initialized
INFO - 2018-02-13 07:02:15 --> Helper loaded: url_helper
INFO - 2018-02-13 07:02:15 --> Helper loaded: form_helper
INFO - 2018-02-13 07:02:15 --> Database Driver Class Initialized
DEBUG - 2018-02-13 07:02:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 07:02:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 07:02:15 --> Form Validation Class Initialized
INFO - 2018-02-13 07:02:15 --> Model Class Initialized
INFO - 2018-02-13 07:02:15 --> Controller Class Initialized
INFO - 2018-02-13 07:02:15 --> Model Class Initialized
INFO - 2018-02-13 07:02:15 --> Model Class Initialized
INFO - 2018-02-13 07:02:15 --> Model Class Initialized
INFO - 2018-02-13 07:02:15 --> Model Class Initialized
INFO - 2018-02-13 07:02:15 --> Model Class Initialized
DEBUG - 2018-02-13 07:02:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 07:02:31 --> Config Class Initialized
INFO - 2018-02-13 07:02:31 --> Hooks Class Initialized
DEBUG - 2018-02-13 07:02:31 --> UTF-8 Support Enabled
INFO - 2018-02-13 07:02:31 --> Utf8 Class Initialized
INFO - 2018-02-13 07:02:31 --> URI Class Initialized
INFO - 2018-02-13 07:02:31 --> Router Class Initialized
INFO - 2018-02-13 07:02:31 --> Output Class Initialized
INFO - 2018-02-13 07:02:31 --> Security Class Initialized
DEBUG - 2018-02-13 07:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 07:02:31 --> Input Class Initialized
INFO - 2018-02-13 07:02:31 --> Language Class Initialized
INFO - 2018-02-13 07:02:31 --> Loader Class Initialized
INFO - 2018-02-13 07:02:31 --> Helper loaded: url_helper
INFO - 2018-02-13 07:02:31 --> Helper loaded: form_helper
INFO - 2018-02-13 07:02:31 --> Database Driver Class Initialized
DEBUG - 2018-02-13 07:02:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 07:02:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 07:02:31 --> Form Validation Class Initialized
INFO - 2018-02-13 07:02:31 --> Model Class Initialized
INFO - 2018-02-13 07:02:31 --> Controller Class Initialized
INFO - 2018-02-13 07:02:31 --> Model Class Initialized
INFO - 2018-02-13 07:02:31 --> Model Class Initialized
INFO - 2018-02-13 07:02:31 --> Model Class Initialized
INFO - 2018-02-13 07:02:31 --> Model Class Initialized
INFO - 2018-02-13 07:02:31 --> Model Class Initialized
DEBUG - 2018-02-13 07:02:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 07:02:31 --> Config Class Initialized
INFO - 2018-02-13 07:02:31 --> Hooks Class Initialized
DEBUG - 2018-02-13 07:02:31 --> UTF-8 Support Enabled
INFO - 2018-02-13 07:02:31 --> Utf8 Class Initialized
INFO - 2018-02-13 07:02:31 --> URI Class Initialized
INFO - 2018-02-13 07:02:31 --> Router Class Initialized
INFO - 2018-02-13 07:02:31 --> Output Class Initialized
INFO - 2018-02-13 07:02:31 --> Security Class Initialized
DEBUG - 2018-02-13 07:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 07:02:31 --> Input Class Initialized
INFO - 2018-02-13 07:02:31 --> Language Class Initialized
INFO - 2018-02-13 07:02:31 --> Loader Class Initialized
INFO - 2018-02-13 07:02:31 --> Helper loaded: url_helper
INFO - 2018-02-13 07:02:31 --> Helper loaded: form_helper
INFO - 2018-02-13 07:02:31 --> Database Driver Class Initialized
DEBUG - 2018-02-13 07:02:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 07:02:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 07:02:31 --> Form Validation Class Initialized
INFO - 2018-02-13 07:02:31 --> Model Class Initialized
INFO - 2018-02-13 07:02:31 --> Controller Class Initialized
INFO - 2018-02-13 07:02:31 --> Model Class Initialized
INFO - 2018-02-13 07:02:31 --> Model Class Initialized
INFO - 2018-02-13 07:02:31 --> Model Class Initialized
INFO - 2018-02-13 07:02:31 --> Model Class Initialized
INFO - 2018-02-13 07:02:31 --> Model Class Initialized
DEBUG - 2018-02-13 07:02:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 07:28:14 --> Config Class Initialized
INFO - 2018-02-13 07:28:14 --> Hooks Class Initialized
DEBUG - 2018-02-13 07:28:14 --> UTF-8 Support Enabled
INFO - 2018-02-13 07:28:14 --> Utf8 Class Initialized
INFO - 2018-02-13 07:28:14 --> URI Class Initialized
INFO - 2018-02-13 07:28:14 --> Router Class Initialized
INFO - 2018-02-13 07:28:14 --> Output Class Initialized
INFO - 2018-02-13 07:28:14 --> Security Class Initialized
DEBUG - 2018-02-13 07:28:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 07:28:14 --> Input Class Initialized
INFO - 2018-02-13 07:28:14 --> Language Class Initialized
INFO - 2018-02-13 07:28:14 --> Loader Class Initialized
INFO - 2018-02-13 07:28:14 --> Helper loaded: url_helper
INFO - 2018-02-13 07:28:14 --> Helper loaded: form_helper
INFO - 2018-02-13 07:28:15 --> Database Driver Class Initialized
DEBUG - 2018-02-13 07:28:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 07:28:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 07:28:15 --> Form Validation Class Initialized
INFO - 2018-02-13 07:28:15 --> Model Class Initialized
INFO - 2018-02-13 07:28:15 --> Controller Class Initialized
INFO - 2018-02-13 07:28:15 --> Model Class Initialized
INFO - 2018-02-13 07:28:15 --> Model Class Initialized
INFO - 2018-02-13 07:28:15 --> Model Class Initialized
INFO - 2018-02-13 07:28:15 --> Model Class Initialized
INFO - 2018-02-13 07:28:15 --> Model Class Initialized
DEBUG - 2018-02-13 07:28:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 07:28:15 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 07:28:15 --> Final output sent to browser
DEBUG - 2018-02-13 07:28:15 --> Total execution time: 0.0649
INFO - 2018-02-13 07:28:15 --> Config Class Initialized
INFO - 2018-02-13 07:28:15 --> Hooks Class Initialized
DEBUG - 2018-02-13 07:28:15 --> UTF-8 Support Enabled
INFO - 2018-02-13 07:28:15 --> Utf8 Class Initialized
INFO - 2018-02-13 07:28:15 --> URI Class Initialized
INFO - 2018-02-13 07:28:15 --> Router Class Initialized
INFO - 2018-02-13 07:28:15 --> Output Class Initialized
INFO - 2018-02-13 07:28:15 --> Security Class Initialized
DEBUG - 2018-02-13 07:28:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 07:28:15 --> Input Class Initialized
INFO - 2018-02-13 07:28:15 --> Language Class Initialized
INFO - 2018-02-13 07:28:15 --> Loader Class Initialized
INFO - 2018-02-13 07:28:15 --> Helper loaded: url_helper
INFO - 2018-02-13 07:28:15 --> Helper loaded: form_helper
INFO - 2018-02-13 07:28:15 --> Database Driver Class Initialized
DEBUG - 2018-02-13 07:28:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 07:28:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 07:28:15 --> Form Validation Class Initialized
INFO - 2018-02-13 07:28:15 --> Model Class Initialized
INFO - 2018-02-13 07:28:15 --> Controller Class Initialized
INFO - 2018-02-13 07:28:15 --> Model Class Initialized
INFO - 2018-02-13 07:28:15 --> Model Class Initialized
INFO - 2018-02-13 07:28:15 --> Model Class Initialized
INFO - 2018-02-13 07:28:15 --> Model Class Initialized
INFO - 2018-02-13 07:28:15 --> Model Class Initialized
DEBUG - 2018-02-13 07:28:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 07:31:49 --> Config Class Initialized
INFO - 2018-02-13 07:31:49 --> Hooks Class Initialized
DEBUG - 2018-02-13 07:31:49 --> UTF-8 Support Enabled
INFO - 2018-02-13 07:31:49 --> Utf8 Class Initialized
INFO - 2018-02-13 07:31:49 --> URI Class Initialized
INFO - 2018-02-13 07:31:49 --> Router Class Initialized
INFO - 2018-02-13 07:31:49 --> Output Class Initialized
INFO - 2018-02-13 07:31:49 --> Security Class Initialized
DEBUG - 2018-02-13 07:31:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 07:31:49 --> Input Class Initialized
INFO - 2018-02-13 07:31:49 --> Language Class Initialized
INFO - 2018-02-13 07:31:49 --> Loader Class Initialized
INFO - 2018-02-13 07:31:49 --> Helper loaded: url_helper
INFO - 2018-02-13 07:31:49 --> Helper loaded: form_helper
INFO - 2018-02-13 07:31:49 --> Database Driver Class Initialized
DEBUG - 2018-02-13 07:31:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 07:31:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 07:31:49 --> Form Validation Class Initialized
INFO - 2018-02-13 07:31:49 --> Model Class Initialized
INFO - 2018-02-13 07:31:49 --> Controller Class Initialized
INFO - 2018-02-13 07:31:49 --> Model Class Initialized
INFO - 2018-02-13 07:31:49 --> Model Class Initialized
INFO - 2018-02-13 07:31:49 --> Model Class Initialized
INFO - 2018-02-13 07:31:49 --> Model Class Initialized
INFO - 2018-02-13 07:31:49 --> Model Class Initialized
DEBUG - 2018-02-13 07:31:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 07:31:49 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 07:31:49 --> Final output sent to browser
DEBUG - 2018-02-13 07:31:49 --> Total execution time: 0.0605
INFO - 2018-02-13 07:31:49 --> Config Class Initialized
INFO - 2018-02-13 07:31:49 --> Hooks Class Initialized
DEBUG - 2018-02-13 07:31:49 --> UTF-8 Support Enabled
INFO - 2018-02-13 07:31:49 --> Utf8 Class Initialized
INFO - 2018-02-13 07:31:49 --> URI Class Initialized
INFO - 2018-02-13 07:31:50 --> Router Class Initialized
INFO - 2018-02-13 07:31:50 --> Output Class Initialized
INFO - 2018-02-13 07:31:50 --> Security Class Initialized
DEBUG - 2018-02-13 07:31:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 07:31:50 --> Input Class Initialized
INFO - 2018-02-13 07:31:50 --> Language Class Initialized
INFO - 2018-02-13 07:31:50 --> Loader Class Initialized
INFO - 2018-02-13 07:31:50 --> Helper loaded: url_helper
INFO - 2018-02-13 07:31:50 --> Helper loaded: form_helper
INFO - 2018-02-13 07:31:50 --> Database Driver Class Initialized
DEBUG - 2018-02-13 07:31:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 07:31:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 07:31:50 --> Form Validation Class Initialized
INFO - 2018-02-13 07:31:50 --> Model Class Initialized
INFO - 2018-02-13 07:31:50 --> Controller Class Initialized
INFO - 2018-02-13 07:31:50 --> Model Class Initialized
INFO - 2018-02-13 07:31:50 --> Model Class Initialized
INFO - 2018-02-13 07:31:50 --> Model Class Initialized
INFO - 2018-02-13 07:31:50 --> Model Class Initialized
INFO - 2018-02-13 07:31:50 --> Model Class Initialized
DEBUG - 2018-02-13 07:31:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 07:32:41 --> Config Class Initialized
INFO - 2018-02-13 07:32:41 --> Hooks Class Initialized
DEBUG - 2018-02-13 07:32:41 --> UTF-8 Support Enabled
INFO - 2018-02-13 07:32:41 --> Utf8 Class Initialized
INFO - 2018-02-13 07:32:41 --> URI Class Initialized
INFO - 2018-02-13 07:32:41 --> Router Class Initialized
INFO - 2018-02-13 07:32:41 --> Output Class Initialized
INFO - 2018-02-13 07:32:41 --> Security Class Initialized
DEBUG - 2018-02-13 07:32:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 07:32:41 --> Input Class Initialized
INFO - 2018-02-13 07:32:41 --> Language Class Initialized
INFO - 2018-02-13 07:32:41 --> Loader Class Initialized
INFO - 2018-02-13 07:32:41 --> Helper loaded: url_helper
INFO - 2018-02-13 07:32:41 --> Helper loaded: form_helper
INFO - 2018-02-13 07:32:41 --> Database Driver Class Initialized
DEBUG - 2018-02-13 07:32:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 07:32:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 07:32:41 --> Form Validation Class Initialized
INFO - 2018-02-13 07:32:41 --> Model Class Initialized
INFO - 2018-02-13 07:32:41 --> Controller Class Initialized
INFO - 2018-02-13 07:32:41 --> Model Class Initialized
INFO - 2018-02-13 07:32:41 --> Model Class Initialized
INFO - 2018-02-13 07:32:41 --> Model Class Initialized
INFO - 2018-02-13 07:32:41 --> Model Class Initialized
INFO - 2018-02-13 07:32:41 --> Model Class Initialized
DEBUG - 2018-02-13 07:32:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 07:32:41 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 07:32:41 --> Final output sent to browser
DEBUG - 2018-02-13 07:32:41 --> Total execution time: 0.0669
INFO - 2018-02-13 07:32:41 --> Config Class Initialized
INFO - 2018-02-13 07:32:41 --> Hooks Class Initialized
DEBUG - 2018-02-13 07:32:41 --> UTF-8 Support Enabled
INFO - 2018-02-13 07:32:41 --> Utf8 Class Initialized
INFO - 2018-02-13 07:32:41 --> URI Class Initialized
INFO - 2018-02-13 07:32:41 --> Router Class Initialized
INFO - 2018-02-13 07:32:41 --> Output Class Initialized
INFO - 2018-02-13 07:32:41 --> Security Class Initialized
DEBUG - 2018-02-13 07:32:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 07:32:41 --> Input Class Initialized
INFO - 2018-02-13 07:32:41 --> Language Class Initialized
INFO - 2018-02-13 07:32:41 --> Loader Class Initialized
INFO - 2018-02-13 07:32:41 --> Helper loaded: url_helper
INFO - 2018-02-13 07:32:41 --> Helper loaded: form_helper
INFO - 2018-02-13 07:32:41 --> Database Driver Class Initialized
DEBUG - 2018-02-13 07:32:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 07:32:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 07:32:41 --> Form Validation Class Initialized
INFO - 2018-02-13 07:32:41 --> Model Class Initialized
INFO - 2018-02-13 07:32:41 --> Controller Class Initialized
INFO - 2018-02-13 07:32:41 --> Model Class Initialized
INFO - 2018-02-13 07:32:41 --> Model Class Initialized
INFO - 2018-02-13 07:32:41 --> Model Class Initialized
INFO - 2018-02-13 07:32:41 --> Model Class Initialized
INFO - 2018-02-13 07:32:41 --> Model Class Initialized
DEBUG - 2018-02-13 07:32:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 07:32:42 --> Config Class Initialized
INFO - 2018-02-13 07:32:42 --> Hooks Class Initialized
DEBUG - 2018-02-13 07:32:42 --> UTF-8 Support Enabled
INFO - 2018-02-13 07:32:42 --> Utf8 Class Initialized
INFO - 2018-02-13 07:32:42 --> URI Class Initialized
INFO - 2018-02-13 07:32:42 --> Router Class Initialized
INFO - 2018-02-13 07:32:42 --> Output Class Initialized
INFO - 2018-02-13 07:32:42 --> Security Class Initialized
DEBUG - 2018-02-13 07:32:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 07:32:42 --> Input Class Initialized
INFO - 2018-02-13 07:32:42 --> Language Class Initialized
INFO - 2018-02-13 07:32:42 --> Loader Class Initialized
INFO - 2018-02-13 07:32:42 --> Helper loaded: url_helper
INFO - 2018-02-13 07:32:42 --> Helper loaded: form_helper
INFO - 2018-02-13 07:32:42 --> Database Driver Class Initialized
DEBUG - 2018-02-13 07:32:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 07:32:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 07:32:42 --> Form Validation Class Initialized
INFO - 2018-02-13 07:32:42 --> Model Class Initialized
INFO - 2018-02-13 07:32:42 --> Controller Class Initialized
INFO - 2018-02-13 07:32:42 --> Model Class Initialized
INFO - 2018-02-13 07:32:42 --> Model Class Initialized
INFO - 2018-02-13 07:32:42 --> Model Class Initialized
INFO - 2018-02-13 07:32:42 --> Model Class Initialized
INFO - 2018-02-13 07:32:42 --> Model Class Initialized
DEBUG - 2018-02-13 07:32:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 07:32:42 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 07:32:42 --> Final output sent to browser
DEBUG - 2018-02-13 07:32:42 --> Total execution time: 0.0595
INFO - 2018-02-13 07:32:42 --> Config Class Initialized
INFO - 2018-02-13 07:32:42 --> Hooks Class Initialized
DEBUG - 2018-02-13 07:32:42 --> UTF-8 Support Enabled
INFO - 2018-02-13 07:32:42 --> Utf8 Class Initialized
INFO - 2018-02-13 07:32:42 --> URI Class Initialized
INFO - 2018-02-13 07:32:42 --> Router Class Initialized
INFO - 2018-02-13 07:32:42 --> Output Class Initialized
INFO - 2018-02-13 07:32:42 --> Security Class Initialized
DEBUG - 2018-02-13 07:32:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 07:32:42 --> Input Class Initialized
INFO - 2018-02-13 07:32:42 --> Language Class Initialized
INFO - 2018-02-13 07:32:42 --> Loader Class Initialized
INFO - 2018-02-13 07:32:42 --> Helper loaded: url_helper
INFO - 2018-02-13 07:32:42 --> Helper loaded: form_helper
INFO - 2018-02-13 07:32:42 --> Database Driver Class Initialized
INFO - 2018-02-13 07:32:42 --> Config Class Initialized
INFO - 2018-02-13 07:32:42 --> Hooks Class Initialized
DEBUG - 2018-02-13 07:32:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 07:32:42 --> UTF-8 Support Enabled
INFO - 2018-02-13 07:32:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 07:32:42 --> Utf8 Class Initialized
INFO - 2018-02-13 07:32:42 --> URI Class Initialized
INFO - 2018-02-13 07:32:42 --> Form Validation Class Initialized
INFO - 2018-02-13 07:32:42 --> Router Class Initialized
INFO - 2018-02-13 07:32:42 --> Model Class Initialized
INFO - 2018-02-13 07:32:42 --> Controller Class Initialized
INFO - 2018-02-13 07:32:42 --> Output Class Initialized
INFO - 2018-02-13 07:32:42 --> Model Class Initialized
INFO - 2018-02-13 07:32:42 --> Security Class Initialized
INFO - 2018-02-13 07:32:42 --> Model Class Initialized
INFO - 2018-02-13 07:32:42 --> Model Class Initialized
DEBUG - 2018-02-13 07:32:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 07:32:42 --> Input Class Initialized
INFO - 2018-02-13 07:32:42 --> Model Class Initialized
INFO - 2018-02-13 07:32:42 --> Language Class Initialized
INFO - 2018-02-13 07:32:42 --> Model Class Initialized
DEBUG - 2018-02-13 07:32:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 07:32:42 --> Loader Class Initialized
INFO - 2018-02-13 07:32:42 --> Helper loaded: url_helper
INFO - 2018-02-13 07:32:42 --> Helper loaded: form_helper
INFO - 2018-02-13 07:32:42 --> Database Driver Class Initialized
DEBUG - 2018-02-13 07:32:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 07:32:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 07:32:42 --> Form Validation Class Initialized
INFO - 2018-02-13 07:32:42 --> Model Class Initialized
INFO - 2018-02-13 07:32:42 --> Controller Class Initialized
INFO - 2018-02-13 07:32:42 --> Model Class Initialized
INFO - 2018-02-13 07:32:42 --> Model Class Initialized
INFO - 2018-02-13 07:32:42 --> Model Class Initialized
INFO - 2018-02-13 07:32:42 --> Model Class Initialized
INFO - 2018-02-13 07:32:42 --> Model Class Initialized
DEBUG - 2018-02-13 07:32:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 07:32:42 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 07:32:42 --> Final output sent to browser
DEBUG - 2018-02-13 07:32:42 --> Total execution time: 0.0629
INFO - 2018-02-13 07:32:42 --> Config Class Initialized
INFO - 2018-02-13 07:32:42 --> Hooks Class Initialized
DEBUG - 2018-02-13 07:32:42 --> UTF-8 Support Enabled
INFO - 2018-02-13 07:32:42 --> Utf8 Class Initialized
INFO - 2018-02-13 07:32:42 --> URI Class Initialized
INFO - 2018-02-13 07:32:42 --> Router Class Initialized
INFO - 2018-02-13 07:32:42 --> Output Class Initialized
INFO - 2018-02-13 07:32:42 --> Security Class Initialized
DEBUG - 2018-02-13 07:32:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 07:32:42 --> Input Class Initialized
INFO - 2018-02-13 07:32:42 --> Language Class Initialized
INFO - 2018-02-13 07:32:42 --> Loader Class Initialized
INFO - 2018-02-13 07:32:42 --> Helper loaded: url_helper
INFO - 2018-02-13 07:32:42 --> Helper loaded: form_helper
INFO - 2018-02-13 07:32:42 --> Database Driver Class Initialized
DEBUG - 2018-02-13 07:32:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 07:32:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 07:32:42 --> Form Validation Class Initialized
INFO - 2018-02-13 07:32:42 --> Model Class Initialized
INFO - 2018-02-13 07:32:42 --> Controller Class Initialized
INFO - 2018-02-13 07:32:42 --> Model Class Initialized
INFO - 2018-02-13 07:32:42 --> Model Class Initialized
INFO - 2018-02-13 07:32:42 --> Model Class Initialized
INFO - 2018-02-13 07:32:42 --> Model Class Initialized
INFO - 2018-02-13 07:32:42 --> Model Class Initialized
DEBUG - 2018-02-13 07:32:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 07:33:39 --> Config Class Initialized
INFO - 2018-02-13 07:33:39 --> Hooks Class Initialized
DEBUG - 2018-02-13 07:33:39 --> UTF-8 Support Enabled
INFO - 2018-02-13 07:33:39 --> Utf8 Class Initialized
INFO - 2018-02-13 07:33:39 --> URI Class Initialized
INFO - 2018-02-13 07:33:39 --> Router Class Initialized
INFO - 2018-02-13 07:33:39 --> Output Class Initialized
INFO - 2018-02-13 07:33:39 --> Security Class Initialized
DEBUG - 2018-02-13 07:33:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 07:33:39 --> Input Class Initialized
INFO - 2018-02-13 07:33:39 --> Language Class Initialized
INFO - 2018-02-13 07:33:39 --> Loader Class Initialized
INFO - 2018-02-13 07:33:39 --> Helper loaded: url_helper
INFO - 2018-02-13 07:33:39 --> Helper loaded: form_helper
INFO - 2018-02-13 07:33:39 --> Database Driver Class Initialized
DEBUG - 2018-02-13 07:33:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 07:33:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 07:33:39 --> Form Validation Class Initialized
INFO - 2018-02-13 07:33:39 --> Model Class Initialized
INFO - 2018-02-13 07:33:39 --> Controller Class Initialized
INFO - 2018-02-13 07:33:39 --> Model Class Initialized
INFO - 2018-02-13 07:33:39 --> Model Class Initialized
INFO - 2018-02-13 07:33:39 --> Model Class Initialized
INFO - 2018-02-13 07:33:39 --> Model Class Initialized
INFO - 2018-02-13 07:33:39 --> Model Class Initialized
DEBUG - 2018-02-13 07:33:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 07:33:39 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 07:33:39 --> Final output sent to browser
DEBUG - 2018-02-13 07:33:39 --> Total execution time: 0.0652
INFO - 2018-02-13 07:33:39 --> Config Class Initialized
INFO - 2018-02-13 07:33:39 --> Hooks Class Initialized
DEBUG - 2018-02-13 07:33:39 --> UTF-8 Support Enabled
INFO - 2018-02-13 07:33:39 --> Utf8 Class Initialized
INFO - 2018-02-13 07:33:39 --> URI Class Initialized
INFO - 2018-02-13 07:33:39 --> Router Class Initialized
INFO - 2018-02-13 07:33:39 --> Output Class Initialized
INFO - 2018-02-13 07:33:39 --> Security Class Initialized
DEBUG - 2018-02-13 07:33:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 07:33:39 --> Input Class Initialized
INFO - 2018-02-13 07:33:39 --> Language Class Initialized
INFO - 2018-02-13 07:33:39 --> Loader Class Initialized
INFO - 2018-02-13 07:33:39 --> Helper loaded: url_helper
INFO - 2018-02-13 07:33:39 --> Helper loaded: form_helper
INFO - 2018-02-13 07:33:39 --> Database Driver Class Initialized
DEBUG - 2018-02-13 07:33:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 07:33:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 07:33:39 --> Form Validation Class Initialized
INFO - 2018-02-13 07:33:39 --> Model Class Initialized
INFO - 2018-02-13 07:33:39 --> Controller Class Initialized
INFO - 2018-02-13 07:33:39 --> Model Class Initialized
INFO - 2018-02-13 07:33:39 --> Model Class Initialized
INFO - 2018-02-13 07:33:39 --> Model Class Initialized
INFO - 2018-02-13 07:33:39 --> Model Class Initialized
INFO - 2018-02-13 07:33:39 --> Model Class Initialized
DEBUG - 2018-02-13 07:33:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 07:33:50 --> Config Class Initialized
INFO - 2018-02-13 07:33:50 --> Hooks Class Initialized
DEBUG - 2018-02-13 07:33:50 --> UTF-8 Support Enabled
INFO - 2018-02-13 07:33:50 --> Utf8 Class Initialized
INFO - 2018-02-13 07:33:50 --> URI Class Initialized
INFO - 2018-02-13 07:33:50 --> Router Class Initialized
INFO - 2018-02-13 07:33:50 --> Output Class Initialized
INFO - 2018-02-13 07:33:50 --> Security Class Initialized
DEBUG - 2018-02-13 07:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 07:33:50 --> Input Class Initialized
INFO - 2018-02-13 07:33:50 --> Language Class Initialized
INFO - 2018-02-13 07:33:50 --> Loader Class Initialized
INFO - 2018-02-13 07:33:50 --> Helper loaded: url_helper
INFO - 2018-02-13 07:33:50 --> Helper loaded: form_helper
INFO - 2018-02-13 07:33:50 --> Database Driver Class Initialized
DEBUG - 2018-02-13 07:33:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 07:33:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 07:33:50 --> Form Validation Class Initialized
INFO - 2018-02-13 07:33:50 --> Model Class Initialized
INFO - 2018-02-13 07:33:50 --> Controller Class Initialized
INFO - 2018-02-13 07:33:50 --> Model Class Initialized
INFO - 2018-02-13 07:33:50 --> Model Class Initialized
INFO - 2018-02-13 07:33:50 --> Model Class Initialized
INFO - 2018-02-13 07:33:50 --> Model Class Initialized
INFO - 2018-02-13 07:33:50 --> Model Class Initialized
DEBUG - 2018-02-13 07:33:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 07:33:50 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 07:33:50 --> Final output sent to browser
DEBUG - 2018-02-13 07:33:50 --> Total execution time: 0.0597
INFO - 2018-02-13 07:33:51 --> Config Class Initialized
INFO - 2018-02-13 07:33:51 --> Hooks Class Initialized
DEBUG - 2018-02-13 07:33:51 --> UTF-8 Support Enabled
INFO - 2018-02-13 07:33:51 --> Utf8 Class Initialized
INFO - 2018-02-13 07:33:51 --> URI Class Initialized
INFO - 2018-02-13 07:33:51 --> Router Class Initialized
INFO - 2018-02-13 07:33:51 --> Output Class Initialized
INFO - 2018-02-13 07:33:51 --> Security Class Initialized
DEBUG - 2018-02-13 07:33:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 07:33:51 --> Input Class Initialized
INFO - 2018-02-13 07:33:51 --> Language Class Initialized
INFO - 2018-02-13 07:33:51 --> Loader Class Initialized
INFO - 2018-02-13 07:33:51 --> Helper loaded: url_helper
INFO - 2018-02-13 07:33:51 --> Helper loaded: form_helper
INFO - 2018-02-13 07:33:51 --> Database Driver Class Initialized
DEBUG - 2018-02-13 07:33:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 07:33:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 07:33:51 --> Form Validation Class Initialized
INFO - 2018-02-13 07:33:51 --> Model Class Initialized
INFO - 2018-02-13 07:33:51 --> Controller Class Initialized
INFO - 2018-02-13 07:33:51 --> Model Class Initialized
INFO - 2018-02-13 07:33:51 --> Model Class Initialized
INFO - 2018-02-13 07:33:51 --> Model Class Initialized
INFO - 2018-02-13 07:33:51 --> Model Class Initialized
INFO - 2018-02-13 07:33:51 --> Model Class Initialized
DEBUG - 2018-02-13 07:33:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 07:34:44 --> Config Class Initialized
INFO - 2018-02-13 07:34:44 --> Hooks Class Initialized
DEBUG - 2018-02-13 07:34:44 --> UTF-8 Support Enabled
INFO - 2018-02-13 07:34:44 --> Utf8 Class Initialized
INFO - 2018-02-13 07:34:44 --> URI Class Initialized
INFO - 2018-02-13 07:34:44 --> Router Class Initialized
INFO - 2018-02-13 07:34:44 --> Output Class Initialized
INFO - 2018-02-13 07:34:44 --> Security Class Initialized
DEBUG - 2018-02-13 07:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 07:34:44 --> Input Class Initialized
INFO - 2018-02-13 07:34:44 --> Language Class Initialized
INFO - 2018-02-13 07:34:44 --> Loader Class Initialized
INFO - 2018-02-13 07:34:44 --> Helper loaded: url_helper
INFO - 2018-02-13 07:34:44 --> Helper loaded: form_helper
INFO - 2018-02-13 07:34:44 --> Database Driver Class Initialized
DEBUG - 2018-02-13 07:34:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 07:34:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 07:34:44 --> Form Validation Class Initialized
INFO - 2018-02-13 07:34:44 --> Model Class Initialized
INFO - 2018-02-13 07:34:44 --> Controller Class Initialized
INFO - 2018-02-13 07:34:44 --> Model Class Initialized
INFO - 2018-02-13 07:34:44 --> Model Class Initialized
INFO - 2018-02-13 07:34:44 --> Model Class Initialized
INFO - 2018-02-13 07:34:44 --> Model Class Initialized
INFO - 2018-02-13 07:34:44 --> Model Class Initialized
DEBUG - 2018-02-13 07:34:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 07:34:44 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 07:34:44 --> Final output sent to browser
DEBUG - 2018-02-13 07:34:44 --> Total execution time: 0.0647
INFO - 2018-02-13 07:34:45 --> Config Class Initialized
INFO - 2018-02-13 07:34:45 --> Hooks Class Initialized
DEBUG - 2018-02-13 07:34:45 --> UTF-8 Support Enabled
INFO - 2018-02-13 07:34:45 --> Utf8 Class Initialized
INFO - 2018-02-13 07:34:45 --> URI Class Initialized
INFO - 2018-02-13 07:34:45 --> Router Class Initialized
INFO - 2018-02-13 07:34:45 --> Output Class Initialized
INFO - 2018-02-13 07:34:45 --> Security Class Initialized
DEBUG - 2018-02-13 07:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 07:34:45 --> Input Class Initialized
INFO - 2018-02-13 07:34:45 --> Language Class Initialized
INFO - 2018-02-13 07:34:45 --> Loader Class Initialized
INFO - 2018-02-13 07:34:45 --> Helper loaded: url_helper
INFO - 2018-02-13 07:34:45 --> Helper loaded: form_helper
INFO - 2018-02-13 07:34:45 --> Database Driver Class Initialized
DEBUG - 2018-02-13 07:34:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 07:34:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 07:34:45 --> Form Validation Class Initialized
INFO - 2018-02-13 07:34:45 --> Model Class Initialized
INFO - 2018-02-13 07:34:45 --> Controller Class Initialized
INFO - 2018-02-13 07:34:45 --> Model Class Initialized
INFO - 2018-02-13 07:34:45 --> Model Class Initialized
INFO - 2018-02-13 07:34:45 --> Model Class Initialized
INFO - 2018-02-13 07:34:45 --> Model Class Initialized
INFO - 2018-02-13 07:34:45 --> Model Class Initialized
DEBUG - 2018-02-13 07:34:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 07:39:13 --> Config Class Initialized
INFO - 2018-02-13 07:39:13 --> Hooks Class Initialized
DEBUG - 2018-02-13 07:39:13 --> UTF-8 Support Enabled
INFO - 2018-02-13 07:39:13 --> Utf8 Class Initialized
INFO - 2018-02-13 07:39:13 --> URI Class Initialized
INFO - 2018-02-13 07:39:13 --> Router Class Initialized
INFO - 2018-02-13 07:39:13 --> Output Class Initialized
INFO - 2018-02-13 07:39:13 --> Security Class Initialized
DEBUG - 2018-02-13 07:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 07:39:13 --> Input Class Initialized
INFO - 2018-02-13 07:39:13 --> Language Class Initialized
INFO - 2018-02-13 07:39:13 --> Loader Class Initialized
INFO - 2018-02-13 07:39:13 --> Helper loaded: url_helper
INFO - 2018-02-13 07:39:13 --> Helper loaded: form_helper
INFO - 2018-02-13 07:39:13 --> Database Driver Class Initialized
DEBUG - 2018-02-13 07:39:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 07:39:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 07:39:13 --> Form Validation Class Initialized
INFO - 2018-02-13 07:39:13 --> Model Class Initialized
INFO - 2018-02-13 07:39:13 --> Controller Class Initialized
INFO - 2018-02-13 07:39:13 --> Model Class Initialized
INFO - 2018-02-13 07:39:13 --> Model Class Initialized
INFO - 2018-02-13 07:39:13 --> Model Class Initialized
INFO - 2018-02-13 07:39:13 --> Model Class Initialized
INFO - 2018-02-13 07:39:13 --> Model Class Initialized
DEBUG - 2018-02-13 07:39:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 07:39:13 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 07:39:13 --> Final output sent to browser
DEBUG - 2018-02-13 07:39:13 --> Total execution time: 0.0447
INFO - 2018-02-13 07:39:13 --> Config Class Initialized
INFO - 2018-02-13 07:39:13 --> Hooks Class Initialized
DEBUG - 2018-02-13 07:39:13 --> UTF-8 Support Enabled
INFO - 2018-02-13 07:39:13 --> Utf8 Class Initialized
INFO - 2018-02-13 07:39:13 --> URI Class Initialized
INFO - 2018-02-13 07:39:13 --> Router Class Initialized
INFO - 2018-02-13 07:39:13 --> Output Class Initialized
INFO - 2018-02-13 07:39:13 --> Security Class Initialized
DEBUG - 2018-02-13 07:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 07:39:13 --> Input Class Initialized
INFO - 2018-02-13 07:39:13 --> Language Class Initialized
INFO - 2018-02-13 07:39:13 --> Loader Class Initialized
INFO - 2018-02-13 07:39:13 --> Helper loaded: url_helper
INFO - 2018-02-13 07:39:13 --> Helper loaded: form_helper
INFO - 2018-02-13 07:39:13 --> Database Driver Class Initialized
DEBUG - 2018-02-13 07:39:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 07:39:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 07:39:13 --> Form Validation Class Initialized
INFO - 2018-02-13 07:39:13 --> Model Class Initialized
INFO - 2018-02-13 07:39:13 --> Controller Class Initialized
INFO - 2018-02-13 07:39:13 --> Model Class Initialized
INFO - 2018-02-13 07:39:13 --> Model Class Initialized
INFO - 2018-02-13 07:39:13 --> Model Class Initialized
INFO - 2018-02-13 07:39:13 --> Model Class Initialized
INFO - 2018-02-13 07:39:13 --> Model Class Initialized
DEBUG - 2018-02-13 07:39:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 07:39:15 --> Config Class Initialized
INFO - 2018-02-13 07:39:15 --> Hooks Class Initialized
DEBUG - 2018-02-13 07:39:15 --> UTF-8 Support Enabled
INFO - 2018-02-13 07:39:15 --> Utf8 Class Initialized
INFO - 2018-02-13 07:39:15 --> URI Class Initialized
INFO - 2018-02-13 07:39:15 --> Router Class Initialized
INFO - 2018-02-13 07:39:15 --> Output Class Initialized
INFO - 2018-02-13 07:39:15 --> Security Class Initialized
DEBUG - 2018-02-13 07:39:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 07:39:15 --> Input Class Initialized
INFO - 2018-02-13 07:39:15 --> Language Class Initialized
INFO - 2018-02-13 07:39:15 --> Loader Class Initialized
INFO - 2018-02-13 07:39:15 --> Helper loaded: url_helper
INFO - 2018-02-13 07:39:15 --> Helper loaded: form_helper
INFO - 2018-02-13 07:39:15 --> Database Driver Class Initialized
DEBUG - 2018-02-13 07:39:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 07:39:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 07:39:15 --> Form Validation Class Initialized
INFO - 2018-02-13 07:39:15 --> Model Class Initialized
INFO - 2018-02-13 07:39:15 --> Controller Class Initialized
INFO - 2018-02-13 07:39:15 --> Model Class Initialized
INFO - 2018-02-13 07:39:15 --> Model Class Initialized
INFO - 2018-02-13 07:39:15 --> Model Class Initialized
INFO - 2018-02-13 07:39:15 --> Model Class Initialized
INFO - 2018-02-13 07:39:15 --> Model Class Initialized
DEBUG - 2018-02-13 07:39:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 07:39:15 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 07:39:15 --> Final output sent to browser
DEBUG - 2018-02-13 07:39:15 --> Total execution time: 0.0505
INFO - 2018-02-13 07:39:16 --> Config Class Initialized
INFO - 2018-02-13 07:39:16 --> Hooks Class Initialized
DEBUG - 2018-02-13 07:39:16 --> UTF-8 Support Enabled
INFO - 2018-02-13 07:39:16 --> Utf8 Class Initialized
INFO - 2018-02-13 07:39:16 --> URI Class Initialized
INFO - 2018-02-13 07:39:16 --> Router Class Initialized
INFO - 2018-02-13 07:39:16 --> Output Class Initialized
INFO - 2018-02-13 07:39:16 --> Security Class Initialized
DEBUG - 2018-02-13 07:39:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 07:39:16 --> Input Class Initialized
INFO - 2018-02-13 07:39:16 --> Language Class Initialized
INFO - 2018-02-13 07:39:16 --> Loader Class Initialized
INFO - 2018-02-13 07:39:16 --> Helper loaded: url_helper
INFO - 2018-02-13 07:39:16 --> Helper loaded: form_helper
INFO - 2018-02-13 07:39:16 --> Database Driver Class Initialized
DEBUG - 2018-02-13 07:39:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 07:39:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 07:39:16 --> Form Validation Class Initialized
INFO - 2018-02-13 07:39:16 --> Model Class Initialized
INFO - 2018-02-13 07:39:16 --> Controller Class Initialized
INFO - 2018-02-13 07:39:16 --> Model Class Initialized
INFO - 2018-02-13 07:39:16 --> Model Class Initialized
INFO - 2018-02-13 07:39:16 --> Model Class Initialized
INFO - 2018-02-13 07:39:16 --> Model Class Initialized
INFO - 2018-02-13 07:39:16 --> Model Class Initialized
DEBUG - 2018-02-13 07:39:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 07:39:19 --> Config Class Initialized
INFO - 2018-02-13 07:39:19 --> Hooks Class Initialized
DEBUG - 2018-02-13 07:39:19 --> UTF-8 Support Enabled
INFO - 2018-02-13 07:39:19 --> Utf8 Class Initialized
INFO - 2018-02-13 07:39:19 --> URI Class Initialized
INFO - 2018-02-13 07:39:19 --> Router Class Initialized
INFO - 2018-02-13 07:39:19 --> Output Class Initialized
INFO - 2018-02-13 07:39:19 --> Security Class Initialized
DEBUG - 2018-02-13 07:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 07:39:19 --> Input Class Initialized
INFO - 2018-02-13 07:39:19 --> Language Class Initialized
INFO - 2018-02-13 07:39:19 --> Loader Class Initialized
INFO - 2018-02-13 07:39:19 --> Helper loaded: url_helper
INFO - 2018-02-13 07:39:19 --> Helper loaded: form_helper
INFO - 2018-02-13 07:39:19 --> Database Driver Class Initialized
DEBUG - 2018-02-13 07:39:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 07:39:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 07:39:19 --> Form Validation Class Initialized
INFO - 2018-02-13 07:39:19 --> Model Class Initialized
INFO - 2018-02-13 07:39:19 --> Controller Class Initialized
INFO - 2018-02-13 07:39:19 --> Model Class Initialized
INFO - 2018-02-13 07:39:19 --> Model Class Initialized
INFO - 2018-02-13 07:39:19 --> Model Class Initialized
INFO - 2018-02-13 07:39:19 --> Model Class Initialized
INFO - 2018-02-13 07:39:19 --> Model Class Initialized
DEBUG - 2018-02-13 07:39:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 07:39:19 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 07:39:19 --> Final output sent to browser
DEBUG - 2018-02-13 07:39:19 --> Total execution time: 0.0635
INFO - 2018-02-13 07:39:19 --> Config Class Initialized
INFO - 2018-02-13 07:39:19 --> Hooks Class Initialized
DEBUG - 2018-02-13 07:39:19 --> UTF-8 Support Enabled
INFO - 2018-02-13 07:39:19 --> Utf8 Class Initialized
INFO - 2018-02-13 07:39:19 --> URI Class Initialized
INFO - 2018-02-13 07:39:19 --> Router Class Initialized
INFO - 2018-02-13 07:39:19 --> Output Class Initialized
INFO - 2018-02-13 07:39:19 --> Security Class Initialized
DEBUG - 2018-02-13 07:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 07:39:19 --> Input Class Initialized
INFO - 2018-02-13 07:39:19 --> Language Class Initialized
INFO - 2018-02-13 07:39:19 --> Loader Class Initialized
INFO - 2018-02-13 07:39:19 --> Helper loaded: url_helper
INFO - 2018-02-13 07:39:19 --> Helper loaded: form_helper
INFO - 2018-02-13 07:39:19 --> Database Driver Class Initialized
DEBUG - 2018-02-13 07:39:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 07:39:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 07:39:19 --> Form Validation Class Initialized
INFO - 2018-02-13 07:39:19 --> Model Class Initialized
INFO - 2018-02-13 07:39:19 --> Controller Class Initialized
INFO - 2018-02-13 07:39:19 --> Model Class Initialized
INFO - 2018-02-13 07:39:19 --> Model Class Initialized
INFO - 2018-02-13 07:39:19 --> Model Class Initialized
INFO - 2018-02-13 07:39:19 --> Model Class Initialized
INFO - 2018-02-13 07:39:19 --> Model Class Initialized
DEBUG - 2018-02-13 07:39:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 07:43:42 --> Config Class Initialized
INFO - 2018-02-13 07:43:42 --> Hooks Class Initialized
DEBUG - 2018-02-13 07:43:42 --> UTF-8 Support Enabled
INFO - 2018-02-13 07:43:42 --> Utf8 Class Initialized
INFO - 2018-02-13 07:43:42 --> URI Class Initialized
INFO - 2018-02-13 07:43:42 --> Router Class Initialized
INFO - 2018-02-13 07:43:42 --> Output Class Initialized
INFO - 2018-02-13 07:43:42 --> Security Class Initialized
DEBUG - 2018-02-13 07:43:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 07:43:42 --> Input Class Initialized
INFO - 2018-02-13 07:43:42 --> Language Class Initialized
INFO - 2018-02-13 07:43:42 --> Loader Class Initialized
INFO - 2018-02-13 07:43:42 --> Helper loaded: url_helper
INFO - 2018-02-13 07:43:42 --> Helper loaded: form_helper
INFO - 2018-02-13 07:43:42 --> Database Driver Class Initialized
DEBUG - 2018-02-13 07:43:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 07:43:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 07:43:42 --> Form Validation Class Initialized
INFO - 2018-02-13 07:43:42 --> Model Class Initialized
INFO - 2018-02-13 07:43:42 --> Controller Class Initialized
INFO - 2018-02-13 07:43:42 --> Model Class Initialized
INFO - 2018-02-13 07:43:42 --> Model Class Initialized
INFO - 2018-02-13 07:43:42 --> Model Class Initialized
INFO - 2018-02-13 07:43:42 --> Model Class Initialized
INFO - 2018-02-13 07:43:42 --> Model Class Initialized
DEBUG - 2018-02-13 07:43:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 07:43:42 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 07:43:42 --> Final output sent to browser
DEBUG - 2018-02-13 07:43:42 --> Total execution time: 0.0609
INFO - 2018-02-13 07:43:42 --> Config Class Initialized
INFO - 2018-02-13 07:43:42 --> Hooks Class Initialized
DEBUG - 2018-02-13 07:43:42 --> UTF-8 Support Enabled
INFO - 2018-02-13 07:43:42 --> Utf8 Class Initialized
INFO - 2018-02-13 07:43:42 --> URI Class Initialized
INFO - 2018-02-13 07:43:42 --> Router Class Initialized
INFO - 2018-02-13 07:43:42 --> Output Class Initialized
INFO - 2018-02-13 07:43:42 --> Security Class Initialized
DEBUG - 2018-02-13 07:43:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 07:43:43 --> Input Class Initialized
INFO - 2018-02-13 07:43:43 --> Language Class Initialized
INFO - 2018-02-13 07:43:43 --> Loader Class Initialized
INFO - 2018-02-13 07:43:43 --> Helper loaded: url_helper
INFO - 2018-02-13 07:43:43 --> Helper loaded: form_helper
INFO - 2018-02-13 07:43:43 --> Database Driver Class Initialized
DEBUG - 2018-02-13 07:43:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 07:43:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 07:43:43 --> Form Validation Class Initialized
INFO - 2018-02-13 07:43:43 --> Model Class Initialized
INFO - 2018-02-13 07:43:43 --> Controller Class Initialized
INFO - 2018-02-13 07:43:43 --> Model Class Initialized
INFO - 2018-02-13 07:43:43 --> Model Class Initialized
INFO - 2018-02-13 07:43:43 --> Model Class Initialized
INFO - 2018-02-13 07:43:43 --> Model Class Initialized
INFO - 2018-02-13 07:43:43 --> Model Class Initialized
DEBUG - 2018-02-13 07:43:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 07:43:44 --> Config Class Initialized
INFO - 2018-02-13 07:43:44 --> Hooks Class Initialized
DEBUG - 2018-02-13 07:43:44 --> UTF-8 Support Enabled
INFO - 2018-02-13 07:43:44 --> Utf8 Class Initialized
INFO - 2018-02-13 07:43:44 --> URI Class Initialized
INFO - 2018-02-13 07:43:44 --> Router Class Initialized
INFO - 2018-02-13 07:43:44 --> Output Class Initialized
INFO - 2018-02-13 07:43:44 --> Security Class Initialized
DEBUG - 2018-02-13 07:43:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 07:43:44 --> Input Class Initialized
INFO - 2018-02-13 07:43:44 --> Language Class Initialized
INFO - 2018-02-13 07:43:44 --> Loader Class Initialized
INFO - 2018-02-13 07:43:44 --> Helper loaded: url_helper
INFO - 2018-02-13 07:43:44 --> Helper loaded: form_helper
INFO - 2018-02-13 07:43:44 --> Database Driver Class Initialized
DEBUG - 2018-02-13 07:43:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 07:43:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 07:43:44 --> Form Validation Class Initialized
INFO - 2018-02-13 07:43:44 --> Model Class Initialized
INFO - 2018-02-13 07:43:44 --> Controller Class Initialized
INFO - 2018-02-13 07:43:44 --> Model Class Initialized
INFO - 2018-02-13 07:43:44 --> Model Class Initialized
INFO - 2018-02-13 07:43:44 --> Model Class Initialized
INFO - 2018-02-13 07:43:44 --> Model Class Initialized
INFO - 2018-02-13 07:43:44 --> Model Class Initialized
DEBUG - 2018-02-13 07:43:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 07:43:44 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 07:43:44 --> Final output sent to browser
DEBUG - 2018-02-13 07:43:44 --> Total execution time: 0.0501
INFO - 2018-02-13 07:43:44 --> Config Class Initialized
INFO - 2018-02-13 07:43:44 --> Hooks Class Initialized
DEBUG - 2018-02-13 07:43:44 --> UTF-8 Support Enabled
INFO - 2018-02-13 07:43:44 --> Utf8 Class Initialized
INFO - 2018-02-13 07:43:44 --> URI Class Initialized
INFO - 2018-02-13 07:43:44 --> Router Class Initialized
INFO - 2018-02-13 07:43:44 --> Output Class Initialized
INFO - 2018-02-13 07:43:44 --> Security Class Initialized
DEBUG - 2018-02-13 07:43:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 07:43:44 --> Input Class Initialized
INFO - 2018-02-13 07:43:44 --> Language Class Initialized
INFO - 2018-02-13 07:43:44 --> Loader Class Initialized
INFO - 2018-02-13 07:43:44 --> Helper loaded: url_helper
INFO - 2018-02-13 07:43:44 --> Helper loaded: form_helper
INFO - 2018-02-13 07:43:44 --> Database Driver Class Initialized
DEBUG - 2018-02-13 07:43:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 07:43:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 07:43:44 --> Form Validation Class Initialized
INFO - 2018-02-13 07:43:44 --> Model Class Initialized
INFO - 2018-02-13 07:43:44 --> Controller Class Initialized
INFO - 2018-02-13 07:43:44 --> Model Class Initialized
INFO - 2018-02-13 07:43:44 --> Model Class Initialized
INFO - 2018-02-13 07:43:44 --> Model Class Initialized
INFO - 2018-02-13 07:43:44 --> Model Class Initialized
INFO - 2018-02-13 07:43:44 --> Model Class Initialized
DEBUG - 2018-02-13 07:43:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 07:54:38 --> Config Class Initialized
INFO - 2018-02-13 07:54:38 --> Hooks Class Initialized
DEBUG - 2018-02-13 07:54:38 --> UTF-8 Support Enabled
INFO - 2018-02-13 07:54:38 --> Utf8 Class Initialized
INFO - 2018-02-13 07:54:38 --> URI Class Initialized
INFO - 2018-02-13 07:54:38 --> Router Class Initialized
INFO - 2018-02-13 07:54:38 --> Output Class Initialized
INFO - 2018-02-13 07:54:38 --> Security Class Initialized
DEBUG - 2018-02-13 07:54:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 07:54:38 --> Input Class Initialized
INFO - 2018-02-13 07:54:38 --> Language Class Initialized
INFO - 2018-02-13 07:54:38 --> Loader Class Initialized
INFO - 2018-02-13 07:54:38 --> Helper loaded: url_helper
INFO - 2018-02-13 07:54:38 --> Helper loaded: form_helper
INFO - 2018-02-13 07:54:38 --> Database Driver Class Initialized
DEBUG - 2018-02-13 07:54:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 07:54:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 07:54:38 --> Form Validation Class Initialized
INFO - 2018-02-13 07:54:38 --> Model Class Initialized
INFO - 2018-02-13 07:54:38 --> Controller Class Initialized
INFO - 2018-02-13 07:54:38 --> Model Class Initialized
INFO - 2018-02-13 07:54:38 --> Model Class Initialized
INFO - 2018-02-13 07:54:38 --> Model Class Initialized
INFO - 2018-02-13 07:54:38 --> Model Class Initialized
INFO - 2018-02-13 07:54:38 --> Model Class Initialized
DEBUG - 2018-02-13 07:54:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 07:54:38 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 07:54:38 --> Final output sent to browser
DEBUG - 2018-02-13 07:54:38 --> Total execution time: 0.0485
INFO - 2018-02-13 07:54:38 --> Config Class Initialized
INFO - 2018-02-13 07:54:38 --> Hooks Class Initialized
DEBUG - 2018-02-13 07:54:38 --> UTF-8 Support Enabled
INFO - 2018-02-13 07:54:38 --> Utf8 Class Initialized
INFO - 2018-02-13 07:54:38 --> URI Class Initialized
INFO - 2018-02-13 07:54:38 --> Router Class Initialized
INFO - 2018-02-13 07:54:38 --> Output Class Initialized
INFO - 2018-02-13 07:54:38 --> Security Class Initialized
DEBUG - 2018-02-13 07:54:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 07:54:38 --> Input Class Initialized
INFO - 2018-02-13 07:54:38 --> Language Class Initialized
INFO - 2018-02-13 07:54:38 --> Loader Class Initialized
INFO - 2018-02-13 07:54:38 --> Helper loaded: url_helper
INFO - 2018-02-13 07:54:38 --> Helper loaded: form_helper
INFO - 2018-02-13 07:54:38 --> Database Driver Class Initialized
DEBUG - 2018-02-13 07:54:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 07:54:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 07:54:38 --> Form Validation Class Initialized
INFO - 2018-02-13 07:54:38 --> Model Class Initialized
INFO - 2018-02-13 07:54:38 --> Controller Class Initialized
INFO - 2018-02-13 07:54:38 --> Model Class Initialized
INFO - 2018-02-13 07:54:38 --> Model Class Initialized
INFO - 2018-02-13 07:54:38 --> Model Class Initialized
INFO - 2018-02-13 07:54:38 --> Model Class Initialized
INFO - 2018-02-13 07:54:38 --> Model Class Initialized
DEBUG - 2018-02-13 07:54:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 07:55:01 --> Config Class Initialized
INFO - 2018-02-13 07:55:01 --> Hooks Class Initialized
DEBUG - 2018-02-13 07:55:01 --> UTF-8 Support Enabled
INFO - 2018-02-13 07:55:01 --> Utf8 Class Initialized
INFO - 2018-02-13 07:55:01 --> URI Class Initialized
INFO - 2018-02-13 07:55:01 --> Router Class Initialized
INFO - 2018-02-13 07:55:01 --> Output Class Initialized
INFO - 2018-02-13 07:55:01 --> Security Class Initialized
DEBUG - 2018-02-13 07:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 07:55:01 --> Input Class Initialized
INFO - 2018-02-13 07:55:01 --> Language Class Initialized
INFO - 2018-02-13 07:55:01 --> Loader Class Initialized
INFO - 2018-02-13 07:55:01 --> Helper loaded: url_helper
INFO - 2018-02-13 07:55:01 --> Helper loaded: form_helper
INFO - 2018-02-13 07:55:01 --> Database Driver Class Initialized
DEBUG - 2018-02-13 07:55:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 07:55:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 07:55:01 --> Form Validation Class Initialized
INFO - 2018-02-13 07:55:01 --> Model Class Initialized
INFO - 2018-02-13 07:55:01 --> Controller Class Initialized
INFO - 2018-02-13 07:55:01 --> Model Class Initialized
INFO - 2018-02-13 07:55:01 --> Model Class Initialized
INFO - 2018-02-13 07:55:01 --> Model Class Initialized
INFO - 2018-02-13 07:55:01 --> Model Class Initialized
INFO - 2018-02-13 07:55:01 --> Model Class Initialized
DEBUG - 2018-02-13 07:55:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 07:55:01 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 07:55:01 --> Final output sent to browser
DEBUG - 2018-02-13 07:55:01 --> Total execution time: 0.0536
INFO - 2018-02-13 07:55:01 --> Config Class Initialized
INFO - 2018-02-13 07:55:01 --> Hooks Class Initialized
DEBUG - 2018-02-13 07:55:01 --> UTF-8 Support Enabled
INFO - 2018-02-13 07:55:01 --> Utf8 Class Initialized
INFO - 2018-02-13 07:55:01 --> URI Class Initialized
INFO - 2018-02-13 07:55:01 --> Router Class Initialized
INFO - 2018-02-13 07:55:01 --> Output Class Initialized
INFO - 2018-02-13 07:55:01 --> Security Class Initialized
DEBUG - 2018-02-13 07:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 07:55:01 --> Input Class Initialized
INFO - 2018-02-13 07:55:01 --> Language Class Initialized
INFO - 2018-02-13 07:55:01 --> Loader Class Initialized
INFO - 2018-02-13 07:55:01 --> Helper loaded: url_helper
INFO - 2018-02-13 07:55:01 --> Helper loaded: form_helper
INFO - 2018-02-13 07:55:01 --> Database Driver Class Initialized
DEBUG - 2018-02-13 07:55:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 07:55:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 07:55:01 --> Form Validation Class Initialized
INFO - 2018-02-13 07:55:01 --> Model Class Initialized
INFO - 2018-02-13 07:55:01 --> Controller Class Initialized
INFO - 2018-02-13 07:55:01 --> Model Class Initialized
INFO - 2018-02-13 07:55:01 --> Model Class Initialized
INFO - 2018-02-13 07:55:01 --> Model Class Initialized
INFO - 2018-02-13 07:55:01 --> Model Class Initialized
INFO - 2018-02-13 07:55:01 --> Model Class Initialized
DEBUG - 2018-02-13 07:55:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 07:55:05 --> Config Class Initialized
INFO - 2018-02-13 07:55:05 --> Hooks Class Initialized
DEBUG - 2018-02-13 07:55:05 --> UTF-8 Support Enabled
INFO - 2018-02-13 07:55:05 --> Utf8 Class Initialized
INFO - 2018-02-13 07:55:05 --> URI Class Initialized
INFO - 2018-02-13 07:55:05 --> Router Class Initialized
INFO - 2018-02-13 07:55:05 --> Output Class Initialized
INFO - 2018-02-13 07:55:05 --> Security Class Initialized
DEBUG - 2018-02-13 07:55:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 07:55:05 --> Input Class Initialized
INFO - 2018-02-13 07:55:05 --> Language Class Initialized
INFO - 2018-02-13 07:55:05 --> Loader Class Initialized
INFO - 2018-02-13 07:55:05 --> Helper loaded: url_helper
INFO - 2018-02-13 07:55:05 --> Helper loaded: form_helper
INFO - 2018-02-13 07:55:05 --> Database Driver Class Initialized
DEBUG - 2018-02-13 07:55:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 07:55:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 07:55:05 --> Form Validation Class Initialized
INFO - 2018-02-13 07:55:05 --> Model Class Initialized
INFO - 2018-02-13 07:55:05 --> Controller Class Initialized
INFO - 2018-02-13 07:55:05 --> Model Class Initialized
INFO - 2018-02-13 07:55:05 --> Model Class Initialized
INFO - 2018-02-13 07:55:05 --> Model Class Initialized
INFO - 2018-02-13 07:55:05 --> Model Class Initialized
INFO - 2018-02-13 07:55:05 --> Model Class Initialized
DEBUG - 2018-02-13 07:55:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 07:55:05 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 07:55:05 --> Final output sent to browser
DEBUG - 2018-02-13 07:55:05 --> Total execution time: 0.0870
INFO - 2018-02-13 07:56:05 --> Config Class Initialized
INFO - 2018-02-13 07:56:05 --> Hooks Class Initialized
DEBUG - 2018-02-13 07:56:05 --> UTF-8 Support Enabled
INFO - 2018-02-13 07:56:05 --> Utf8 Class Initialized
INFO - 2018-02-13 07:56:05 --> URI Class Initialized
INFO - 2018-02-13 07:56:05 --> Router Class Initialized
INFO - 2018-02-13 07:56:05 --> Output Class Initialized
INFO - 2018-02-13 07:56:05 --> Security Class Initialized
DEBUG - 2018-02-13 07:56:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 07:56:05 --> Input Class Initialized
INFO - 2018-02-13 07:56:05 --> Language Class Initialized
INFO - 2018-02-13 07:56:05 --> Loader Class Initialized
INFO - 2018-02-13 07:56:05 --> Helper loaded: url_helper
INFO - 2018-02-13 07:56:05 --> Helper loaded: form_helper
INFO - 2018-02-13 07:56:05 --> Database Driver Class Initialized
DEBUG - 2018-02-13 07:56:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 07:56:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 07:56:05 --> Form Validation Class Initialized
INFO - 2018-02-13 07:56:05 --> Model Class Initialized
INFO - 2018-02-13 07:56:05 --> Controller Class Initialized
INFO - 2018-02-13 07:56:05 --> Model Class Initialized
INFO - 2018-02-13 07:56:05 --> Model Class Initialized
INFO - 2018-02-13 07:56:05 --> Model Class Initialized
INFO - 2018-02-13 07:56:05 --> Model Class Initialized
INFO - 2018-02-13 07:56:05 --> Model Class Initialized
DEBUG - 2018-02-13 07:56:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 07:56:05 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 07:56:05 --> Final output sent to browser
DEBUG - 2018-02-13 07:56:05 --> Total execution time: 0.0618
INFO - 2018-02-13 07:59:14 --> Config Class Initialized
INFO - 2018-02-13 07:59:14 --> Hooks Class Initialized
DEBUG - 2018-02-13 07:59:14 --> UTF-8 Support Enabled
INFO - 2018-02-13 07:59:14 --> Utf8 Class Initialized
INFO - 2018-02-13 07:59:14 --> URI Class Initialized
INFO - 2018-02-13 07:59:14 --> Router Class Initialized
INFO - 2018-02-13 07:59:14 --> Output Class Initialized
INFO - 2018-02-13 07:59:14 --> Security Class Initialized
DEBUG - 2018-02-13 07:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 07:59:14 --> Input Class Initialized
INFO - 2018-02-13 07:59:14 --> Language Class Initialized
INFO - 2018-02-13 07:59:14 --> Loader Class Initialized
INFO - 2018-02-13 07:59:14 --> Helper loaded: url_helper
INFO - 2018-02-13 07:59:14 --> Helper loaded: form_helper
INFO - 2018-02-13 07:59:14 --> Database Driver Class Initialized
DEBUG - 2018-02-13 07:59:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 07:59:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 07:59:14 --> Form Validation Class Initialized
INFO - 2018-02-13 07:59:14 --> Model Class Initialized
INFO - 2018-02-13 07:59:14 --> Controller Class Initialized
INFO - 2018-02-13 07:59:14 --> Model Class Initialized
INFO - 2018-02-13 07:59:14 --> Model Class Initialized
INFO - 2018-02-13 07:59:14 --> Model Class Initialized
INFO - 2018-02-13 07:59:14 --> Model Class Initialized
INFO - 2018-02-13 07:59:14 --> Model Class Initialized
DEBUG - 2018-02-13 07:59:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 07:59:14 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 07:59:14 --> Final output sent to browser
DEBUG - 2018-02-13 07:59:14 --> Total execution time: 0.0741
INFO - 2018-02-13 07:59:21 --> Config Class Initialized
INFO - 2018-02-13 07:59:21 --> Hooks Class Initialized
DEBUG - 2018-02-13 07:59:21 --> UTF-8 Support Enabled
INFO - 2018-02-13 07:59:21 --> Utf8 Class Initialized
INFO - 2018-02-13 07:59:21 --> URI Class Initialized
INFO - 2018-02-13 07:59:21 --> Router Class Initialized
INFO - 2018-02-13 07:59:21 --> Output Class Initialized
INFO - 2018-02-13 07:59:21 --> Security Class Initialized
DEBUG - 2018-02-13 07:59:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 07:59:21 --> Input Class Initialized
INFO - 2018-02-13 07:59:21 --> Language Class Initialized
INFO - 2018-02-13 07:59:21 --> Loader Class Initialized
INFO - 2018-02-13 07:59:21 --> Helper loaded: url_helper
INFO - 2018-02-13 07:59:21 --> Helper loaded: form_helper
INFO - 2018-02-13 07:59:21 --> Database Driver Class Initialized
DEBUG - 2018-02-13 07:59:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 07:59:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 07:59:21 --> Form Validation Class Initialized
INFO - 2018-02-13 07:59:21 --> Model Class Initialized
INFO - 2018-02-13 07:59:21 --> Controller Class Initialized
INFO - 2018-02-13 07:59:21 --> Model Class Initialized
INFO - 2018-02-13 07:59:21 --> Model Class Initialized
INFO - 2018-02-13 07:59:21 --> Model Class Initialized
INFO - 2018-02-13 07:59:21 --> Model Class Initialized
INFO - 2018-02-13 07:59:21 --> Model Class Initialized
DEBUG - 2018-02-13 07:59:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 07:59:21 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 07:59:21 --> Final output sent to browser
DEBUG - 2018-02-13 07:59:21 --> Total execution time: 0.0531
INFO - 2018-02-13 07:59:21 --> Config Class Initialized
INFO - 2018-02-13 07:59:21 --> Hooks Class Initialized
DEBUG - 2018-02-13 07:59:21 --> UTF-8 Support Enabled
INFO - 2018-02-13 07:59:21 --> Utf8 Class Initialized
INFO - 2018-02-13 07:59:21 --> URI Class Initialized
INFO - 2018-02-13 07:59:21 --> Router Class Initialized
INFO - 2018-02-13 07:59:21 --> Output Class Initialized
INFO - 2018-02-13 07:59:21 --> Security Class Initialized
DEBUG - 2018-02-13 07:59:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 07:59:21 --> Input Class Initialized
INFO - 2018-02-13 07:59:21 --> Language Class Initialized
INFO - 2018-02-13 07:59:21 --> Loader Class Initialized
INFO - 2018-02-13 07:59:21 --> Helper loaded: url_helper
INFO - 2018-02-13 07:59:21 --> Helper loaded: form_helper
INFO - 2018-02-13 07:59:21 --> Database Driver Class Initialized
DEBUG - 2018-02-13 07:59:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 07:59:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 07:59:21 --> Form Validation Class Initialized
INFO - 2018-02-13 07:59:21 --> Model Class Initialized
INFO - 2018-02-13 07:59:21 --> Controller Class Initialized
INFO - 2018-02-13 07:59:21 --> Model Class Initialized
INFO - 2018-02-13 07:59:21 --> Model Class Initialized
INFO - 2018-02-13 07:59:21 --> Model Class Initialized
INFO - 2018-02-13 07:59:21 --> Model Class Initialized
INFO - 2018-02-13 07:59:21 --> Model Class Initialized
DEBUG - 2018-02-13 07:59:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 07:59:23 --> Config Class Initialized
INFO - 2018-02-13 07:59:23 --> Hooks Class Initialized
DEBUG - 2018-02-13 07:59:23 --> UTF-8 Support Enabled
INFO - 2018-02-13 07:59:23 --> Utf8 Class Initialized
INFO - 2018-02-13 07:59:23 --> URI Class Initialized
INFO - 2018-02-13 07:59:23 --> Router Class Initialized
INFO - 2018-02-13 07:59:23 --> Output Class Initialized
INFO - 2018-02-13 07:59:23 --> Security Class Initialized
DEBUG - 2018-02-13 07:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 07:59:23 --> Input Class Initialized
INFO - 2018-02-13 07:59:23 --> Language Class Initialized
INFO - 2018-02-13 07:59:23 --> Loader Class Initialized
INFO - 2018-02-13 07:59:23 --> Helper loaded: url_helper
INFO - 2018-02-13 07:59:23 --> Helper loaded: form_helper
INFO - 2018-02-13 07:59:23 --> Database Driver Class Initialized
DEBUG - 2018-02-13 07:59:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 07:59:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 07:59:23 --> Form Validation Class Initialized
INFO - 2018-02-13 07:59:23 --> Model Class Initialized
INFO - 2018-02-13 07:59:23 --> Controller Class Initialized
INFO - 2018-02-13 07:59:23 --> Model Class Initialized
INFO - 2018-02-13 07:59:23 --> Model Class Initialized
INFO - 2018-02-13 07:59:23 --> Model Class Initialized
INFO - 2018-02-13 07:59:23 --> Model Class Initialized
INFO - 2018-02-13 07:59:23 --> Model Class Initialized
DEBUG - 2018-02-13 07:59:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 07:59:23 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 07:59:23 --> Final output sent to browser
DEBUG - 2018-02-13 07:59:23 --> Total execution time: 0.0906
INFO - 2018-02-13 07:59:49 --> Config Class Initialized
INFO - 2018-02-13 07:59:49 --> Hooks Class Initialized
DEBUG - 2018-02-13 07:59:49 --> UTF-8 Support Enabled
INFO - 2018-02-13 07:59:49 --> Utf8 Class Initialized
INFO - 2018-02-13 07:59:49 --> URI Class Initialized
INFO - 2018-02-13 07:59:49 --> Router Class Initialized
INFO - 2018-02-13 07:59:49 --> Output Class Initialized
INFO - 2018-02-13 07:59:49 --> Security Class Initialized
DEBUG - 2018-02-13 07:59:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 07:59:49 --> Input Class Initialized
INFO - 2018-02-13 07:59:49 --> Language Class Initialized
INFO - 2018-02-13 07:59:49 --> Loader Class Initialized
INFO - 2018-02-13 07:59:49 --> Helper loaded: url_helper
INFO - 2018-02-13 07:59:49 --> Helper loaded: form_helper
INFO - 2018-02-13 07:59:49 --> Database Driver Class Initialized
DEBUG - 2018-02-13 07:59:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 07:59:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 07:59:49 --> Form Validation Class Initialized
INFO - 2018-02-13 07:59:49 --> Model Class Initialized
INFO - 2018-02-13 07:59:49 --> Controller Class Initialized
INFO - 2018-02-13 07:59:49 --> Model Class Initialized
INFO - 2018-02-13 07:59:49 --> Model Class Initialized
INFO - 2018-02-13 07:59:49 --> Model Class Initialized
INFO - 2018-02-13 07:59:49 --> Model Class Initialized
INFO - 2018-02-13 07:59:49 --> Model Class Initialized
DEBUG - 2018-02-13 07:59:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 07:59:49 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 07:59:49 --> Final output sent to browser
DEBUG - 2018-02-13 07:59:49 --> Total execution time: 0.0571
INFO - 2018-02-13 07:59:49 --> Config Class Initialized
INFO - 2018-02-13 07:59:49 --> Hooks Class Initialized
DEBUG - 2018-02-13 07:59:49 --> UTF-8 Support Enabled
INFO - 2018-02-13 07:59:49 --> Utf8 Class Initialized
INFO - 2018-02-13 07:59:49 --> URI Class Initialized
INFO - 2018-02-13 07:59:49 --> Router Class Initialized
INFO - 2018-02-13 07:59:49 --> Output Class Initialized
INFO - 2018-02-13 07:59:49 --> Security Class Initialized
DEBUG - 2018-02-13 07:59:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 07:59:49 --> Input Class Initialized
INFO - 2018-02-13 07:59:49 --> Language Class Initialized
INFO - 2018-02-13 07:59:49 --> Loader Class Initialized
INFO - 2018-02-13 07:59:49 --> Helper loaded: url_helper
INFO - 2018-02-13 07:59:49 --> Helper loaded: form_helper
INFO - 2018-02-13 07:59:49 --> Database Driver Class Initialized
DEBUG - 2018-02-13 07:59:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 07:59:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 07:59:49 --> Form Validation Class Initialized
INFO - 2018-02-13 07:59:49 --> Model Class Initialized
INFO - 2018-02-13 07:59:49 --> Controller Class Initialized
INFO - 2018-02-13 07:59:49 --> Model Class Initialized
INFO - 2018-02-13 07:59:49 --> Model Class Initialized
INFO - 2018-02-13 07:59:49 --> Model Class Initialized
INFO - 2018-02-13 07:59:49 --> Model Class Initialized
INFO - 2018-02-13 07:59:49 --> Model Class Initialized
DEBUG - 2018-02-13 07:59:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 07:59:50 --> Config Class Initialized
INFO - 2018-02-13 07:59:50 --> Hooks Class Initialized
DEBUG - 2018-02-13 07:59:50 --> UTF-8 Support Enabled
INFO - 2018-02-13 07:59:50 --> Utf8 Class Initialized
INFO - 2018-02-13 07:59:50 --> URI Class Initialized
INFO - 2018-02-13 07:59:50 --> Router Class Initialized
INFO - 2018-02-13 07:59:50 --> Output Class Initialized
INFO - 2018-02-13 07:59:50 --> Security Class Initialized
DEBUG - 2018-02-13 07:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 07:59:50 --> Input Class Initialized
INFO - 2018-02-13 07:59:50 --> Language Class Initialized
INFO - 2018-02-13 07:59:50 --> Loader Class Initialized
INFO - 2018-02-13 07:59:50 --> Helper loaded: url_helper
INFO - 2018-02-13 07:59:50 --> Helper loaded: form_helper
INFO - 2018-02-13 07:59:50 --> Database Driver Class Initialized
DEBUG - 2018-02-13 07:59:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 07:59:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 07:59:50 --> Form Validation Class Initialized
INFO - 2018-02-13 07:59:50 --> Model Class Initialized
INFO - 2018-02-13 07:59:50 --> Controller Class Initialized
INFO - 2018-02-13 07:59:50 --> Model Class Initialized
INFO - 2018-02-13 07:59:50 --> Model Class Initialized
INFO - 2018-02-13 07:59:50 --> Model Class Initialized
INFO - 2018-02-13 07:59:50 --> Model Class Initialized
INFO - 2018-02-13 07:59:50 --> Model Class Initialized
DEBUG - 2018-02-13 07:59:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 07:59:50 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 07:59:50 --> Final output sent to browser
DEBUG - 2018-02-13 07:59:50 --> Total execution time: 0.0501
INFO - 2018-02-13 08:02:31 --> Config Class Initialized
INFO - 2018-02-13 08:02:31 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:02:31 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:02:31 --> Utf8 Class Initialized
INFO - 2018-02-13 08:02:31 --> URI Class Initialized
INFO - 2018-02-13 08:02:31 --> Router Class Initialized
INFO - 2018-02-13 08:02:31 --> Output Class Initialized
INFO - 2018-02-13 08:02:31 --> Security Class Initialized
DEBUG - 2018-02-13 08:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:02:31 --> Input Class Initialized
INFO - 2018-02-13 08:02:31 --> Language Class Initialized
INFO - 2018-02-13 08:02:31 --> Loader Class Initialized
INFO - 2018-02-13 08:02:31 --> Helper loaded: url_helper
INFO - 2018-02-13 08:02:31 --> Helper loaded: form_helper
INFO - 2018-02-13 08:02:31 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:02:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:02:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:02:31 --> Form Validation Class Initialized
INFO - 2018-02-13 08:02:31 --> Model Class Initialized
INFO - 2018-02-13 08:02:31 --> Controller Class Initialized
INFO - 2018-02-13 08:02:31 --> Model Class Initialized
INFO - 2018-02-13 08:02:31 --> Model Class Initialized
INFO - 2018-02-13 08:02:31 --> Model Class Initialized
INFO - 2018-02-13 08:02:31 --> Model Class Initialized
INFO - 2018-02-13 08:02:31 --> Model Class Initialized
DEBUG - 2018-02-13 08:02:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:02:31 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 08:02:31 --> Final output sent to browser
DEBUG - 2018-02-13 08:02:31 --> Total execution time: 0.0754
INFO - 2018-02-13 08:02:36 --> Config Class Initialized
INFO - 2018-02-13 08:02:36 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:02:36 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:02:36 --> Utf8 Class Initialized
INFO - 2018-02-13 08:02:36 --> URI Class Initialized
INFO - 2018-02-13 08:02:36 --> Router Class Initialized
INFO - 2018-02-13 08:02:36 --> Output Class Initialized
INFO - 2018-02-13 08:02:36 --> Security Class Initialized
DEBUG - 2018-02-13 08:02:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:02:36 --> Input Class Initialized
INFO - 2018-02-13 08:02:36 --> Language Class Initialized
INFO - 2018-02-13 08:02:36 --> Loader Class Initialized
INFO - 2018-02-13 08:02:36 --> Helper loaded: url_helper
INFO - 2018-02-13 08:02:36 --> Helper loaded: form_helper
INFO - 2018-02-13 08:02:36 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:02:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:02:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:02:36 --> Form Validation Class Initialized
INFO - 2018-02-13 08:02:36 --> Model Class Initialized
INFO - 2018-02-13 08:02:36 --> Controller Class Initialized
INFO - 2018-02-13 08:02:36 --> Model Class Initialized
INFO - 2018-02-13 08:02:36 --> Model Class Initialized
INFO - 2018-02-13 08:02:36 --> Model Class Initialized
INFO - 2018-02-13 08:02:36 --> Model Class Initialized
INFO - 2018-02-13 08:02:36 --> Model Class Initialized
DEBUG - 2018-02-13 08:02:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:02:36 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 08:02:36 --> Final output sent to browser
DEBUG - 2018-02-13 08:02:36 --> Total execution time: 0.0621
INFO - 2018-02-13 08:02:36 --> Config Class Initialized
INFO - 2018-02-13 08:02:36 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:02:36 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:02:36 --> Utf8 Class Initialized
INFO - 2018-02-13 08:02:36 --> URI Class Initialized
INFO - 2018-02-13 08:02:36 --> Router Class Initialized
INFO - 2018-02-13 08:02:36 --> Output Class Initialized
INFO - 2018-02-13 08:02:36 --> Security Class Initialized
DEBUG - 2018-02-13 08:02:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:02:36 --> Input Class Initialized
INFO - 2018-02-13 08:02:36 --> Language Class Initialized
INFO - 2018-02-13 08:02:36 --> Loader Class Initialized
INFO - 2018-02-13 08:02:36 --> Helper loaded: url_helper
INFO - 2018-02-13 08:02:36 --> Helper loaded: form_helper
INFO - 2018-02-13 08:02:36 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:02:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:02:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:02:36 --> Form Validation Class Initialized
INFO - 2018-02-13 08:02:36 --> Model Class Initialized
INFO - 2018-02-13 08:02:36 --> Controller Class Initialized
INFO - 2018-02-13 08:02:36 --> Model Class Initialized
INFO - 2018-02-13 08:02:36 --> Model Class Initialized
INFO - 2018-02-13 08:02:36 --> Model Class Initialized
INFO - 2018-02-13 08:02:36 --> Model Class Initialized
INFO - 2018-02-13 08:02:36 --> Model Class Initialized
DEBUG - 2018-02-13 08:02:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:02:38 --> Config Class Initialized
INFO - 2018-02-13 08:02:38 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:02:38 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:02:38 --> Utf8 Class Initialized
INFO - 2018-02-13 08:02:38 --> URI Class Initialized
INFO - 2018-02-13 08:02:38 --> Router Class Initialized
INFO - 2018-02-13 08:02:38 --> Output Class Initialized
INFO - 2018-02-13 08:02:38 --> Security Class Initialized
DEBUG - 2018-02-13 08:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:02:38 --> Input Class Initialized
INFO - 2018-02-13 08:02:38 --> Language Class Initialized
INFO - 2018-02-13 08:02:38 --> Loader Class Initialized
INFO - 2018-02-13 08:02:38 --> Helper loaded: url_helper
INFO - 2018-02-13 08:02:38 --> Helper loaded: form_helper
INFO - 2018-02-13 08:02:38 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:02:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:02:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:02:38 --> Form Validation Class Initialized
INFO - 2018-02-13 08:02:38 --> Model Class Initialized
INFO - 2018-02-13 08:02:38 --> Controller Class Initialized
INFO - 2018-02-13 08:02:38 --> Model Class Initialized
INFO - 2018-02-13 08:02:38 --> Model Class Initialized
INFO - 2018-02-13 08:02:38 --> Model Class Initialized
INFO - 2018-02-13 08:02:38 --> Model Class Initialized
INFO - 2018-02-13 08:02:38 --> Model Class Initialized
DEBUG - 2018-02-13 08:02:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:02:38 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 08:02:38 --> Final output sent to browser
DEBUG - 2018-02-13 08:02:38 --> Total execution time: 0.0502
INFO - 2018-02-13 08:02:38 --> Config Class Initialized
INFO - 2018-02-13 08:02:38 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:02:38 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:02:38 --> Utf8 Class Initialized
INFO - 2018-02-13 08:02:38 --> URI Class Initialized
INFO - 2018-02-13 08:02:38 --> Router Class Initialized
INFO - 2018-02-13 08:02:38 --> Output Class Initialized
INFO - 2018-02-13 08:02:38 --> Security Class Initialized
DEBUG - 2018-02-13 08:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:02:38 --> Input Class Initialized
INFO - 2018-02-13 08:02:38 --> Language Class Initialized
INFO - 2018-02-13 08:02:38 --> Loader Class Initialized
INFO - 2018-02-13 08:02:38 --> Helper loaded: url_helper
INFO - 2018-02-13 08:02:38 --> Helper loaded: form_helper
INFO - 2018-02-13 08:02:38 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:02:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:02:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:02:38 --> Form Validation Class Initialized
INFO - 2018-02-13 08:02:38 --> Model Class Initialized
INFO - 2018-02-13 08:02:38 --> Controller Class Initialized
INFO - 2018-02-13 08:02:38 --> Model Class Initialized
INFO - 2018-02-13 08:02:38 --> Model Class Initialized
INFO - 2018-02-13 08:02:38 --> Model Class Initialized
INFO - 2018-02-13 08:02:38 --> Model Class Initialized
INFO - 2018-02-13 08:02:38 --> Model Class Initialized
DEBUG - 2018-02-13 08:02:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:04:01 --> Config Class Initialized
INFO - 2018-02-13 08:04:01 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:04:01 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:04:01 --> Utf8 Class Initialized
INFO - 2018-02-13 08:04:01 --> URI Class Initialized
INFO - 2018-02-13 08:04:01 --> Router Class Initialized
INFO - 2018-02-13 08:04:01 --> Output Class Initialized
INFO - 2018-02-13 08:04:01 --> Security Class Initialized
DEBUG - 2018-02-13 08:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:04:01 --> Input Class Initialized
INFO - 2018-02-13 08:04:01 --> Language Class Initialized
INFO - 2018-02-13 08:04:01 --> Loader Class Initialized
INFO - 2018-02-13 08:04:01 --> Helper loaded: url_helper
INFO - 2018-02-13 08:04:01 --> Helper loaded: form_helper
INFO - 2018-02-13 08:04:01 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:04:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:04:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:04:01 --> Form Validation Class Initialized
INFO - 2018-02-13 08:04:01 --> Model Class Initialized
INFO - 2018-02-13 08:04:01 --> Controller Class Initialized
INFO - 2018-02-13 08:04:01 --> Model Class Initialized
INFO - 2018-02-13 08:04:01 --> Model Class Initialized
INFO - 2018-02-13 08:04:01 --> Model Class Initialized
INFO - 2018-02-13 08:04:01 --> Model Class Initialized
INFO - 2018-02-13 08:04:01 --> Model Class Initialized
DEBUG - 2018-02-13 08:04:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:04:01 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 08:04:01 --> Final output sent to browser
DEBUG - 2018-02-13 08:04:01 --> Total execution time: 0.0488
INFO - 2018-02-13 08:04:01 --> Config Class Initialized
INFO - 2018-02-13 08:04:01 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:04:01 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:04:01 --> Utf8 Class Initialized
INFO - 2018-02-13 08:04:01 --> URI Class Initialized
INFO - 2018-02-13 08:04:01 --> Router Class Initialized
INFO - 2018-02-13 08:04:01 --> Output Class Initialized
INFO - 2018-02-13 08:04:01 --> Security Class Initialized
DEBUG - 2018-02-13 08:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:04:01 --> Input Class Initialized
INFO - 2018-02-13 08:04:01 --> Language Class Initialized
INFO - 2018-02-13 08:04:01 --> Loader Class Initialized
INFO - 2018-02-13 08:04:01 --> Helper loaded: url_helper
INFO - 2018-02-13 08:04:01 --> Helper loaded: form_helper
INFO - 2018-02-13 08:04:01 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:04:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:04:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:04:01 --> Form Validation Class Initialized
INFO - 2018-02-13 08:04:01 --> Model Class Initialized
INFO - 2018-02-13 08:04:01 --> Controller Class Initialized
INFO - 2018-02-13 08:04:01 --> Model Class Initialized
INFO - 2018-02-13 08:04:01 --> Model Class Initialized
INFO - 2018-02-13 08:04:01 --> Model Class Initialized
INFO - 2018-02-13 08:04:01 --> Model Class Initialized
INFO - 2018-02-13 08:04:01 --> Model Class Initialized
DEBUG - 2018-02-13 08:04:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:04:55 --> Config Class Initialized
INFO - 2018-02-13 08:04:55 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:04:55 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:04:55 --> Utf8 Class Initialized
INFO - 2018-02-13 08:04:55 --> URI Class Initialized
INFO - 2018-02-13 08:04:55 --> Router Class Initialized
INFO - 2018-02-13 08:04:55 --> Output Class Initialized
INFO - 2018-02-13 08:04:55 --> Security Class Initialized
DEBUG - 2018-02-13 08:04:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:04:55 --> Input Class Initialized
INFO - 2018-02-13 08:04:55 --> Language Class Initialized
INFO - 2018-02-13 08:04:55 --> Loader Class Initialized
INFO - 2018-02-13 08:04:55 --> Helper loaded: url_helper
INFO - 2018-02-13 08:04:55 --> Helper loaded: form_helper
INFO - 2018-02-13 08:04:55 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:04:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:04:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:04:55 --> Form Validation Class Initialized
INFO - 2018-02-13 08:04:55 --> Model Class Initialized
INFO - 2018-02-13 08:04:55 --> Controller Class Initialized
INFO - 2018-02-13 08:04:55 --> Model Class Initialized
INFO - 2018-02-13 08:04:55 --> Model Class Initialized
INFO - 2018-02-13 08:04:55 --> Model Class Initialized
INFO - 2018-02-13 08:04:55 --> Model Class Initialized
INFO - 2018-02-13 08:04:55 --> Model Class Initialized
DEBUG - 2018-02-13 08:04:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:04:55 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 08:04:55 --> Final output sent to browser
DEBUG - 2018-02-13 08:04:55 --> Total execution time: 0.0657
INFO - 2018-02-13 08:04:55 --> Config Class Initialized
INFO - 2018-02-13 08:04:55 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:04:55 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:04:55 --> Utf8 Class Initialized
INFO - 2018-02-13 08:04:55 --> URI Class Initialized
INFO - 2018-02-13 08:04:55 --> Router Class Initialized
INFO - 2018-02-13 08:04:55 --> Output Class Initialized
INFO - 2018-02-13 08:04:55 --> Security Class Initialized
DEBUG - 2018-02-13 08:04:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:04:55 --> Input Class Initialized
INFO - 2018-02-13 08:04:55 --> Language Class Initialized
INFO - 2018-02-13 08:04:55 --> Loader Class Initialized
INFO - 2018-02-13 08:04:55 --> Helper loaded: url_helper
INFO - 2018-02-13 08:04:55 --> Helper loaded: form_helper
INFO - 2018-02-13 08:04:55 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:04:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:04:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:04:55 --> Form Validation Class Initialized
INFO - 2018-02-13 08:04:55 --> Model Class Initialized
INFO - 2018-02-13 08:04:55 --> Controller Class Initialized
INFO - 2018-02-13 08:04:55 --> Model Class Initialized
INFO - 2018-02-13 08:04:55 --> Model Class Initialized
INFO - 2018-02-13 08:04:55 --> Model Class Initialized
INFO - 2018-02-13 08:04:55 --> Model Class Initialized
INFO - 2018-02-13 08:04:55 --> Model Class Initialized
DEBUG - 2018-02-13 08:04:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:05:08 --> Config Class Initialized
INFO - 2018-02-13 08:05:08 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:05:08 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:05:08 --> Utf8 Class Initialized
INFO - 2018-02-13 08:05:08 --> URI Class Initialized
INFO - 2018-02-13 08:05:08 --> Router Class Initialized
INFO - 2018-02-13 08:05:08 --> Output Class Initialized
INFO - 2018-02-13 08:05:08 --> Security Class Initialized
DEBUG - 2018-02-13 08:05:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:05:08 --> Input Class Initialized
INFO - 2018-02-13 08:05:08 --> Language Class Initialized
INFO - 2018-02-13 08:05:08 --> Loader Class Initialized
INFO - 2018-02-13 08:05:08 --> Helper loaded: url_helper
INFO - 2018-02-13 08:05:08 --> Helper loaded: form_helper
INFO - 2018-02-13 08:05:08 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:05:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:05:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:05:08 --> Form Validation Class Initialized
INFO - 2018-02-13 08:05:08 --> Model Class Initialized
INFO - 2018-02-13 08:05:08 --> Controller Class Initialized
INFO - 2018-02-13 08:05:08 --> Model Class Initialized
INFO - 2018-02-13 08:05:08 --> Model Class Initialized
INFO - 2018-02-13 08:05:08 --> Model Class Initialized
INFO - 2018-02-13 08:05:08 --> Model Class Initialized
INFO - 2018-02-13 08:05:08 --> Model Class Initialized
DEBUG - 2018-02-13 08:05:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:05:08 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 08:05:08 --> Final output sent to browser
DEBUG - 2018-02-13 08:05:08 --> Total execution time: 0.0621
INFO - 2018-02-13 08:05:08 --> Config Class Initialized
INFO - 2018-02-13 08:05:08 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:05:08 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:05:08 --> Utf8 Class Initialized
INFO - 2018-02-13 08:05:08 --> URI Class Initialized
INFO - 2018-02-13 08:05:08 --> Router Class Initialized
INFO - 2018-02-13 08:05:08 --> Output Class Initialized
INFO - 2018-02-13 08:05:08 --> Security Class Initialized
DEBUG - 2018-02-13 08:05:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:05:08 --> Input Class Initialized
INFO - 2018-02-13 08:05:08 --> Language Class Initialized
INFO - 2018-02-13 08:05:08 --> Loader Class Initialized
INFO - 2018-02-13 08:05:08 --> Helper loaded: url_helper
INFO - 2018-02-13 08:05:08 --> Helper loaded: form_helper
INFO - 2018-02-13 08:05:08 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:05:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:05:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:05:08 --> Form Validation Class Initialized
INFO - 2018-02-13 08:05:08 --> Model Class Initialized
INFO - 2018-02-13 08:05:08 --> Controller Class Initialized
INFO - 2018-02-13 08:05:08 --> Model Class Initialized
INFO - 2018-02-13 08:05:08 --> Model Class Initialized
INFO - 2018-02-13 08:05:08 --> Model Class Initialized
INFO - 2018-02-13 08:05:08 --> Model Class Initialized
INFO - 2018-02-13 08:05:08 --> Model Class Initialized
DEBUG - 2018-02-13 08:05:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:05:09 --> Config Class Initialized
INFO - 2018-02-13 08:05:09 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:05:09 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:05:09 --> Utf8 Class Initialized
INFO - 2018-02-13 08:05:09 --> URI Class Initialized
INFO - 2018-02-13 08:05:09 --> Router Class Initialized
INFO - 2018-02-13 08:05:09 --> Output Class Initialized
INFO - 2018-02-13 08:05:09 --> Security Class Initialized
DEBUG - 2018-02-13 08:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:05:09 --> Input Class Initialized
INFO - 2018-02-13 08:05:09 --> Language Class Initialized
INFO - 2018-02-13 08:05:09 --> Loader Class Initialized
INFO - 2018-02-13 08:05:09 --> Helper loaded: url_helper
INFO - 2018-02-13 08:05:09 --> Helper loaded: form_helper
INFO - 2018-02-13 08:05:09 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:05:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:05:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:05:09 --> Form Validation Class Initialized
INFO - 2018-02-13 08:05:09 --> Model Class Initialized
INFO - 2018-02-13 08:05:09 --> Controller Class Initialized
INFO - 2018-02-13 08:05:09 --> Model Class Initialized
INFO - 2018-02-13 08:05:09 --> Model Class Initialized
INFO - 2018-02-13 08:05:09 --> Model Class Initialized
INFO - 2018-02-13 08:05:09 --> Model Class Initialized
INFO - 2018-02-13 08:05:09 --> Model Class Initialized
DEBUG - 2018-02-13 08:05:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:05:09 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 08:05:09 --> Final output sent to browser
DEBUG - 2018-02-13 08:05:09 --> Total execution time: 0.0581
INFO - 2018-02-13 08:05:09 --> Config Class Initialized
INFO - 2018-02-13 08:05:09 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:05:09 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:05:09 --> Utf8 Class Initialized
INFO - 2018-02-13 08:05:09 --> URI Class Initialized
INFO - 2018-02-13 08:05:09 --> Router Class Initialized
INFO - 2018-02-13 08:05:09 --> Output Class Initialized
INFO - 2018-02-13 08:05:09 --> Security Class Initialized
DEBUG - 2018-02-13 08:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:05:09 --> Input Class Initialized
INFO - 2018-02-13 08:05:09 --> Language Class Initialized
INFO - 2018-02-13 08:05:09 --> Loader Class Initialized
INFO - 2018-02-13 08:05:09 --> Helper loaded: url_helper
INFO - 2018-02-13 08:05:09 --> Helper loaded: form_helper
INFO - 2018-02-13 08:05:09 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:05:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:05:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:05:09 --> Form Validation Class Initialized
INFO - 2018-02-13 08:05:09 --> Model Class Initialized
INFO - 2018-02-13 08:05:09 --> Controller Class Initialized
INFO - 2018-02-13 08:05:09 --> Model Class Initialized
INFO - 2018-02-13 08:05:09 --> Model Class Initialized
INFO - 2018-02-13 08:05:09 --> Model Class Initialized
INFO - 2018-02-13 08:05:09 --> Model Class Initialized
INFO - 2018-02-13 08:05:09 --> Model Class Initialized
DEBUG - 2018-02-13 08:05:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:05:15 --> Config Class Initialized
INFO - 2018-02-13 08:05:15 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:05:15 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:05:15 --> Utf8 Class Initialized
INFO - 2018-02-13 08:05:15 --> URI Class Initialized
INFO - 2018-02-13 08:05:15 --> Router Class Initialized
INFO - 2018-02-13 08:05:15 --> Output Class Initialized
INFO - 2018-02-13 08:05:15 --> Security Class Initialized
DEBUG - 2018-02-13 08:05:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:05:15 --> Input Class Initialized
INFO - 2018-02-13 08:05:15 --> Language Class Initialized
INFO - 2018-02-13 08:05:15 --> Loader Class Initialized
INFO - 2018-02-13 08:05:15 --> Helper loaded: url_helper
INFO - 2018-02-13 08:05:15 --> Helper loaded: form_helper
INFO - 2018-02-13 08:05:15 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:05:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:05:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:05:16 --> Form Validation Class Initialized
INFO - 2018-02-13 08:05:16 --> Model Class Initialized
INFO - 2018-02-13 08:05:16 --> Controller Class Initialized
INFO - 2018-02-13 08:05:16 --> Model Class Initialized
INFO - 2018-02-13 08:05:16 --> Model Class Initialized
INFO - 2018-02-13 08:05:16 --> Model Class Initialized
INFO - 2018-02-13 08:05:16 --> Model Class Initialized
INFO - 2018-02-13 08:05:16 --> Model Class Initialized
DEBUG - 2018-02-13 08:05:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:05:16 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 08:05:16 --> Final output sent to browser
DEBUG - 2018-02-13 08:05:16 --> Total execution time: 0.0596
INFO - 2018-02-13 08:05:16 --> Config Class Initialized
INFO - 2018-02-13 08:05:16 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:05:16 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:05:16 --> Utf8 Class Initialized
INFO - 2018-02-13 08:05:16 --> URI Class Initialized
INFO - 2018-02-13 08:05:16 --> Router Class Initialized
INFO - 2018-02-13 08:05:16 --> Output Class Initialized
INFO - 2018-02-13 08:05:16 --> Security Class Initialized
DEBUG - 2018-02-13 08:05:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:05:16 --> Input Class Initialized
INFO - 2018-02-13 08:05:16 --> Language Class Initialized
INFO - 2018-02-13 08:05:16 --> Loader Class Initialized
INFO - 2018-02-13 08:05:16 --> Helper loaded: url_helper
INFO - 2018-02-13 08:05:16 --> Helper loaded: form_helper
INFO - 2018-02-13 08:05:16 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:05:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:05:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:05:16 --> Form Validation Class Initialized
INFO - 2018-02-13 08:05:16 --> Model Class Initialized
INFO - 2018-02-13 08:05:16 --> Controller Class Initialized
INFO - 2018-02-13 08:05:16 --> Model Class Initialized
INFO - 2018-02-13 08:05:16 --> Model Class Initialized
INFO - 2018-02-13 08:05:16 --> Model Class Initialized
INFO - 2018-02-13 08:05:16 --> Model Class Initialized
INFO - 2018-02-13 08:05:16 --> Model Class Initialized
DEBUG - 2018-02-13 08:05:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:05:17 --> Config Class Initialized
INFO - 2018-02-13 08:05:17 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:05:17 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:05:17 --> Utf8 Class Initialized
INFO - 2018-02-13 08:05:17 --> URI Class Initialized
INFO - 2018-02-13 08:05:17 --> Router Class Initialized
INFO - 2018-02-13 08:05:17 --> Output Class Initialized
INFO - 2018-02-13 08:05:17 --> Security Class Initialized
DEBUG - 2018-02-13 08:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:05:17 --> Input Class Initialized
INFO - 2018-02-13 08:05:17 --> Language Class Initialized
INFO - 2018-02-13 08:05:17 --> Loader Class Initialized
INFO - 2018-02-13 08:05:17 --> Helper loaded: url_helper
INFO - 2018-02-13 08:05:17 --> Helper loaded: form_helper
INFO - 2018-02-13 08:05:17 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:05:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:05:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:05:17 --> Form Validation Class Initialized
INFO - 2018-02-13 08:05:17 --> Model Class Initialized
INFO - 2018-02-13 08:05:17 --> Controller Class Initialized
INFO - 2018-02-13 08:05:17 --> Model Class Initialized
INFO - 2018-02-13 08:05:17 --> Model Class Initialized
INFO - 2018-02-13 08:05:17 --> Model Class Initialized
INFO - 2018-02-13 08:05:17 --> Model Class Initialized
INFO - 2018-02-13 08:05:17 --> Model Class Initialized
DEBUG - 2018-02-13 08:05:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:05:17 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 08:05:17 --> Final output sent to browser
DEBUG - 2018-02-13 08:05:17 --> Total execution time: 0.0470
INFO - 2018-02-13 08:05:17 --> Config Class Initialized
INFO - 2018-02-13 08:05:17 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:05:17 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:05:17 --> Utf8 Class Initialized
INFO - 2018-02-13 08:05:17 --> URI Class Initialized
INFO - 2018-02-13 08:05:17 --> Router Class Initialized
INFO - 2018-02-13 08:05:17 --> Output Class Initialized
INFO - 2018-02-13 08:05:17 --> Security Class Initialized
DEBUG - 2018-02-13 08:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:05:17 --> Input Class Initialized
INFO - 2018-02-13 08:05:17 --> Language Class Initialized
INFO - 2018-02-13 08:05:17 --> Loader Class Initialized
INFO - 2018-02-13 08:05:17 --> Helper loaded: url_helper
INFO - 2018-02-13 08:05:17 --> Helper loaded: form_helper
INFO - 2018-02-13 08:05:17 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:05:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:05:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:05:17 --> Form Validation Class Initialized
INFO - 2018-02-13 08:05:17 --> Model Class Initialized
INFO - 2018-02-13 08:05:17 --> Controller Class Initialized
INFO - 2018-02-13 08:05:17 --> Model Class Initialized
INFO - 2018-02-13 08:05:17 --> Model Class Initialized
INFO - 2018-02-13 08:05:17 --> Model Class Initialized
INFO - 2018-02-13 08:05:17 --> Model Class Initialized
INFO - 2018-02-13 08:05:17 --> Model Class Initialized
DEBUG - 2018-02-13 08:05:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:05:19 --> Config Class Initialized
INFO - 2018-02-13 08:05:19 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:05:19 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:05:19 --> Utf8 Class Initialized
INFO - 2018-02-13 08:05:19 --> URI Class Initialized
INFO - 2018-02-13 08:05:19 --> Router Class Initialized
INFO - 2018-02-13 08:05:19 --> Output Class Initialized
INFO - 2018-02-13 08:05:19 --> Security Class Initialized
DEBUG - 2018-02-13 08:05:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:05:19 --> Input Class Initialized
INFO - 2018-02-13 08:05:19 --> Language Class Initialized
INFO - 2018-02-13 08:05:19 --> Loader Class Initialized
INFO - 2018-02-13 08:05:19 --> Helper loaded: url_helper
INFO - 2018-02-13 08:05:19 --> Helper loaded: form_helper
INFO - 2018-02-13 08:05:19 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:05:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:05:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:05:19 --> Form Validation Class Initialized
INFO - 2018-02-13 08:05:19 --> Model Class Initialized
INFO - 2018-02-13 08:05:19 --> Controller Class Initialized
INFO - 2018-02-13 08:05:19 --> Model Class Initialized
INFO - 2018-02-13 08:05:19 --> Model Class Initialized
INFO - 2018-02-13 08:05:19 --> Model Class Initialized
INFO - 2018-02-13 08:05:19 --> Model Class Initialized
INFO - 2018-02-13 08:05:19 --> Model Class Initialized
DEBUG - 2018-02-13 08:05:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:05:19 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 08:05:19 --> Final output sent to browser
DEBUG - 2018-02-13 08:05:19 --> Total execution time: 0.0558
INFO - 2018-02-13 08:05:19 --> Config Class Initialized
INFO - 2018-02-13 08:05:19 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:05:19 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:05:19 --> Utf8 Class Initialized
INFO - 2018-02-13 08:05:19 --> URI Class Initialized
INFO - 2018-02-13 08:05:19 --> Router Class Initialized
INFO - 2018-02-13 08:05:19 --> Output Class Initialized
INFO - 2018-02-13 08:05:19 --> Security Class Initialized
DEBUG - 2018-02-13 08:05:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:05:19 --> Input Class Initialized
INFO - 2018-02-13 08:05:19 --> Language Class Initialized
INFO - 2018-02-13 08:05:19 --> Loader Class Initialized
INFO - 2018-02-13 08:05:19 --> Helper loaded: url_helper
INFO - 2018-02-13 08:05:19 --> Helper loaded: form_helper
INFO - 2018-02-13 08:05:19 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:05:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:05:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:05:19 --> Form Validation Class Initialized
INFO - 2018-02-13 08:05:19 --> Model Class Initialized
INFO - 2018-02-13 08:05:19 --> Controller Class Initialized
INFO - 2018-02-13 08:05:19 --> Model Class Initialized
INFO - 2018-02-13 08:05:19 --> Model Class Initialized
INFO - 2018-02-13 08:05:19 --> Model Class Initialized
INFO - 2018-02-13 08:05:19 --> Model Class Initialized
INFO - 2018-02-13 08:05:19 --> Model Class Initialized
DEBUG - 2018-02-13 08:05:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:05:20 --> Config Class Initialized
INFO - 2018-02-13 08:05:20 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:05:20 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:05:20 --> Utf8 Class Initialized
INFO - 2018-02-13 08:05:20 --> URI Class Initialized
INFO - 2018-02-13 08:05:20 --> Router Class Initialized
INFO - 2018-02-13 08:05:20 --> Output Class Initialized
INFO - 2018-02-13 08:05:20 --> Security Class Initialized
DEBUG - 2018-02-13 08:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:05:20 --> Input Class Initialized
INFO - 2018-02-13 08:05:20 --> Language Class Initialized
INFO - 2018-02-13 08:05:20 --> Loader Class Initialized
INFO - 2018-02-13 08:05:20 --> Helper loaded: url_helper
INFO - 2018-02-13 08:05:20 --> Helper loaded: form_helper
INFO - 2018-02-13 08:05:20 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:05:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:05:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:05:20 --> Form Validation Class Initialized
INFO - 2018-02-13 08:05:20 --> Model Class Initialized
INFO - 2018-02-13 08:05:20 --> Controller Class Initialized
INFO - 2018-02-13 08:05:20 --> Model Class Initialized
INFO - 2018-02-13 08:05:20 --> Model Class Initialized
INFO - 2018-02-13 08:05:20 --> Model Class Initialized
INFO - 2018-02-13 08:05:20 --> Model Class Initialized
INFO - 2018-02-13 08:05:20 --> Model Class Initialized
DEBUG - 2018-02-13 08:05:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:05:20 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 08:05:20 --> Final output sent to browser
DEBUG - 2018-02-13 08:05:20 --> Total execution time: 0.0483
INFO - 2018-02-13 08:05:21 --> Config Class Initialized
INFO - 2018-02-13 08:05:21 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:05:21 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:05:21 --> Utf8 Class Initialized
INFO - 2018-02-13 08:05:21 --> URI Class Initialized
INFO - 2018-02-13 08:05:21 --> Router Class Initialized
INFO - 2018-02-13 08:05:21 --> Output Class Initialized
INFO - 2018-02-13 08:05:21 --> Security Class Initialized
DEBUG - 2018-02-13 08:05:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:05:21 --> Input Class Initialized
INFO - 2018-02-13 08:05:21 --> Language Class Initialized
INFO - 2018-02-13 08:05:21 --> Loader Class Initialized
INFO - 2018-02-13 08:05:21 --> Helper loaded: url_helper
INFO - 2018-02-13 08:05:21 --> Helper loaded: form_helper
INFO - 2018-02-13 08:05:21 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:05:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:05:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:05:21 --> Form Validation Class Initialized
INFO - 2018-02-13 08:05:21 --> Model Class Initialized
INFO - 2018-02-13 08:05:21 --> Controller Class Initialized
INFO - 2018-02-13 08:05:21 --> Model Class Initialized
INFO - 2018-02-13 08:05:21 --> Model Class Initialized
INFO - 2018-02-13 08:05:21 --> Model Class Initialized
INFO - 2018-02-13 08:05:21 --> Model Class Initialized
INFO - 2018-02-13 08:05:21 --> Model Class Initialized
DEBUG - 2018-02-13 08:05:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:06:33 --> Config Class Initialized
INFO - 2018-02-13 08:06:33 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:06:33 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:06:33 --> Utf8 Class Initialized
INFO - 2018-02-13 08:06:33 --> URI Class Initialized
INFO - 2018-02-13 08:06:33 --> Router Class Initialized
INFO - 2018-02-13 08:06:33 --> Output Class Initialized
INFO - 2018-02-13 08:06:33 --> Security Class Initialized
DEBUG - 2018-02-13 08:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:06:33 --> Input Class Initialized
INFO - 2018-02-13 08:06:33 --> Language Class Initialized
INFO - 2018-02-13 08:06:33 --> Loader Class Initialized
INFO - 2018-02-13 08:06:33 --> Helper loaded: url_helper
INFO - 2018-02-13 08:06:33 --> Helper loaded: form_helper
INFO - 2018-02-13 08:06:33 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:06:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:06:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:06:33 --> Form Validation Class Initialized
INFO - 2018-02-13 08:06:33 --> Model Class Initialized
INFO - 2018-02-13 08:06:33 --> Controller Class Initialized
INFO - 2018-02-13 08:06:33 --> Model Class Initialized
INFO - 2018-02-13 08:06:33 --> Model Class Initialized
INFO - 2018-02-13 08:06:33 --> Model Class Initialized
INFO - 2018-02-13 08:06:33 --> Model Class Initialized
INFO - 2018-02-13 08:06:33 --> Model Class Initialized
DEBUG - 2018-02-13 08:06:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:06:33 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 08:06:33 --> Final output sent to browser
DEBUG - 2018-02-13 08:06:33 --> Total execution time: 0.0595
INFO - 2018-02-13 08:06:33 --> Config Class Initialized
INFO - 2018-02-13 08:06:33 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:06:33 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:06:33 --> Utf8 Class Initialized
INFO - 2018-02-13 08:06:33 --> URI Class Initialized
INFO - 2018-02-13 08:06:33 --> Router Class Initialized
INFO - 2018-02-13 08:06:33 --> Output Class Initialized
INFO - 2018-02-13 08:06:33 --> Security Class Initialized
DEBUG - 2018-02-13 08:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:06:33 --> Input Class Initialized
INFO - 2018-02-13 08:06:33 --> Language Class Initialized
INFO - 2018-02-13 08:06:33 --> Loader Class Initialized
INFO - 2018-02-13 08:06:33 --> Helper loaded: url_helper
INFO - 2018-02-13 08:06:33 --> Helper loaded: form_helper
INFO - 2018-02-13 08:06:33 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:06:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:06:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:06:33 --> Form Validation Class Initialized
INFO - 2018-02-13 08:06:33 --> Model Class Initialized
INFO - 2018-02-13 08:06:33 --> Controller Class Initialized
INFO - 2018-02-13 08:06:33 --> Model Class Initialized
INFO - 2018-02-13 08:06:33 --> Model Class Initialized
INFO - 2018-02-13 08:06:33 --> Model Class Initialized
INFO - 2018-02-13 08:06:33 --> Model Class Initialized
INFO - 2018-02-13 08:06:33 --> Model Class Initialized
DEBUG - 2018-02-13 08:06:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:12:42 --> Config Class Initialized
INFO - 2018-02-13 08:12:42 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:12:42 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:12:42 --> Utf8 Class Initialized
INFO - 2018-02-13 08:12:42 --> URI Class Initialized
INFO - 2018-02-13 08:12:42 --> Router Class Initialized
INFO - 2018-02-13 08:12:42 --> Output Class Initialized
INFO - 2018-02-13 08:12:42 --> Security Class Initialized
DEBUG - 2018-02-13 08:12:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:12:42 --> Input Class Initialized
INFO - 2018-02-13 08:12:42 --> Language Class Initialized
INFO - 2018-02-13 08:12:42 --> Loader Class Initialized
INFO - 2018-02-13 08:12:42 --> Helper loaded: url_helper
INFO - 2018-02-13 08:12:42 --> Helper loaded: form_helper
INFO - 2018-02-13 08:12:42 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:12:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:12:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:12:42 --> Form Validation Class Initialized
INFO - 2018-02-13 08:12:42 --> Model Class Initialized
INFO - 2018-02-13 08:12:42 --> Controller Class Initialized
INFO - 2018-02-13 08:12:42 --> Model Class Initialized
INFO - 2018-02-13 08:12:42 --> Model Class Initialized
INFO - 2018-02-13 08:12:42 --> Model Class Initialized
INFO - 2018-02-13 08:12:42 --> Model Class Initialized
INFO - 2018-02-13 08:12:42 --> Model Class Initialized
DEBUG - 2018-02-13 08:12:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:12:42 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 08:12:42 --> Final output sent to browser
DEBUG - 2018-02-13 08:12:42 --> Total execution time: 0.0484
INFO - 2018-02-13 08:12:42 --> Config Class Initialized
INFO - 2018-02-13 08:12:42 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:12:42 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:12:42 --> Utf8 Class Initialized
INFO - 2018-02-13 08:12:42 --> URI Class Initialized
INFO - 2018-02-13 08:12:42 --> Router Class Initialized
INFO - 2018-02-13 08:12:42 --> Output Class Initialized
INFO - 2018-02-13 08:12:42 --> Security Class Initialized
DEBUG - 2018-02-13 08:12:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:12:42 --> Input Class Initialized
INFO - 2018-02-13 08:12:42 --> Language Class Initialized
INFO - 2018-02-13 08:12:42 --> Loader Class Initialized
INFO - 2018-02-13 08:12:42 --> Helper loaded: url_helper
INFO - 2018-02-13 08:12:42 --> Helper loaded: form_helper
INFO - 2018-02-13 08:12:42 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:12:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:12:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:12:42 --> Form Validation Class Initialized
INFO - 2018-02-13 08:12:42 --> Model Class Initialized
INFO - 2018-02-13 08:12:42 --> Controller Class Initialized
INFO - 2018-02-13 08:12:42 --> Model Class Initialized
INFO - 2018-02-13 08:12:42 --> Model Class Initialized
INFO - 2018-02-13 08:12:42 --> Model Class Initialized
INFO - 2018-02-13 08:12:42 --> Model Class Initialized
INFO - 2018-02-13 08:12:42 --> Model Class Initialized
DEBUG - 2018-02-13 08:12:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:29:28 --> Config Class Initialized
INFO - 2018-02-13 08:29:28 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:29:28 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:29:28 --> Utf8 Class Initialized
INFO - 2018-02-13 08:29:28 --> URI Class Initialized
INFO - 2018-02-13 08:29:28 --> Router Class Initialized
INFO - 2018-02-13 08:29:28 --> Output Class Initialized
INFO - 2018-02-13 08:29:28 --> Security Class Initialized
DEBUG - 2018-02-13 08:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:29:28 --> Input Class Initialized
INFO - 2018-02-13 08:29:28 --> Language Class Initialized
INFO - 2018-02-13 08:29:28 --> Loader Class Initialized
INFO - 2018-02-13 08:29:28 --> Helper loaded: url_helper
INFO - 2018-02-13 08:29:28 --> Helper loaded: form_helper
INFO - 2018-02-13 08:29:28 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:29:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:29:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:29:28 --> Form Validation Class Initialized
INFO - 2018-02-13 08:29:28 --> Model Class Initialized
INFO - 2018-02-13 08:29:28 --> Controller Class Initialized
INFO - 2018-02-13 08:29:28 --> Model Class Initialized
INFO - 2018-02-13 08:29:28 --> Model Class Initialized
INFO - 2018-02-13 08:29:28 --> Model Class Initialized
INFO - 2018-02-13 08:29:28 --> Model Class Initialized
INFO - 2018-02-13 08:29:28 --> Model Class Initialized
DEBUG - 2018-02-13 08:29:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:29:28 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 08:29:28 --> Final output sent to browser
DEBUG - 2018-02-13 08:29:28 --> Total execution time: 0.0537
INFO - 2018-02-13 08:29:28 --> Config Class Initialized
INFO - 2018-02-13 08:29:28 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:29:28 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:29:28 --> Utf8 Class Initialized
INFO - 2018-02-13 08:29:28 --> URI Class Initialized
INFO - 2018-02-13 08:29:28 --> Router Class Initialized
INFO - 2018-02-13 08:29:28 --> Output Class Initialized
INFO - 2018-02-13 08:29:28 --> Security Class Initialized
DEBUG - 2018-02-13 08:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:29:28 --> Input Class Initialized
INFO - 2018-02-13 08:29:28 --> Language Class Initialized
INFO - 2018-02-13 08:29:28 --> Loader Class Initialized
INFO - 2018-02-13 08:29:28 --> Helper loaded: url_helper
INFO - 2018-02-13 08:29:28 --> Helper loaded: form_helper
INFO - 2018-02-13 08:29:28 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:29:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:29:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:29:28 --> Form Validation Class Initialized
INFO - 2018-02-13 08:29:28 --> Model Class Initialized
INFO - 2018-02-13 08:29:28 --> Controller Class Initialized
INFO - 2018-02-13 08:29:28 --> Model Class Initialized
INFO - 2018-02-13 08:29:28 --> Model Class Initialized
INFO - 2018-02-13 08:29:28 --> Model Class Initialized
INFO - 2018-02-13 08:29:28 --> Model Class Initialized
INFO - 2018-02-13 08:29:28 --> Model Class Initialized
DEBUG - 2018-02-13 08:29:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:30:10 --> Config Class Initialized
INFO - 2018-02-13 08:30:10 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:30:10 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:30:10 --> Utf8 Class Initialized
INFO - 2018-02-13 08:30:10 --> URI Class Initialized
INFO - 2018-02-13 08:30:10 --> Router Class Initialized
INFO - 2018-02-13 08:30:10 --> Output Class Initialized
INFO - 2018-02-13 08:30:10 --> Security Class Initialized
DEBUG - 2018-02-13 08:30:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:30:10 --> Input Class Initialized
INFO - 2018-02-13 08:30:10 --> Language Class Initialized
INFO - 2018-02-13 08:30:10 --> Loader Class Initialized
INFO - 2018-02-13 08:30:10 --> Helper loaded: url_helper
INFO - 2018-02-13 08:30:10 --> Helper loaded: form_helper
INFO - 2018-02-13 08:30:10 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:30:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:30:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:30:10 --> Form Validation Class Initialized
INFO - 2018-02-13 08:30:10 --> Model Class Initialized
INFO - 2018-02-13 08:30:10 --> Controller Class Initialized
INFO - 2018-02-13 08:30:10 --> Model Class Initialized
INFO - 2018-02-13 08:30:10 --> Model Class Initialized
INFO - 2018-02-13 08:30:10 --> Model Class Initialized
INFO - 2018-02-13 08:30:10 --> Model Class Initialized
INFO - 2018-02-13 08:30:10 --> Model Class Initialized
DEBUG - 2018-02-13 08:30:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:30:10 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 08:30:10 --> Final output sent to browser
DEBUG - 2018-02-13 08:30:10 --> Total execution time: 0.0762
INFO - 2018-02-13 08:30:11 --> Config Class Initialized
INFO - 2018-02-13 08:30:11 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:30:11 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:30:11 --> Utf8 Class Initialized
INFO - 2018-02-13 08:30:11 --> URI Class Initialized
INFO - 2018-02-13 08:30:11 --> Router Class Initialized
INFO - 2018-02-13 08:30:11 --> Output Class Initialized
INFO - 2018-02-13 08:30:11 --> Security Class Initialized
DEBUG - 2018-02-13 08:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:30:11 --> Input Class Initialized
INFO - 2018-02-13 08:30:11 --> Language Class Initialized
INFO - 2018-02-13 08:30:11 --> Loader Class Initialized
INFO - 2018-02-13 08:30:11 --> Helper loaded: url_helper
INFO - 2018-02-13 08:30:11 --> Helper loaded: form_helper
INFO - 2018-02-13 08:30:11 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:30:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:30:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:30:11 --> Form Validation Class Initialized
INFO - 2018-02-13 08:30:11 --> Model Class Initialized
INFO - 2018-02-13 08:30:11 --> Controller Class Initialized
INFO - 2018-02-13 08:30:11 --> Model Class Initialized
INFO - 2018-02-13 08:30:11 --> Model Class Initialized
INFO - 2018-02-13 08:30:11 --> Model Class Initialized
INFO - 2018-02-13 08:30:11 --> Model Class Initialized
INFO - 2018-02-13 08:30:11 --> Model Class Initialized
DEBUG - 2018-02-13 08:30:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:30:23 --> Config Class Initialized
INFO - 2018-02-13 08:30:23 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:30:23 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:30:23 --> Utf8 Class Initialized
INFO - 2018-02-13 08:30:23 --> URI Class Initialized
INFO - 2018-02-13 08:30:23 --> Router Class Initialized
INFO - 2018-02-13 08:30:23 --> Output Class Initialized
INFO - 2018-02-13 08:30:23 --> Security Class Initialized
DEBUG - 2018-02-13 08:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:30:23 --> Input Class Initialized
INFO - 2018-02-13 08:30:23 --> Language Class Initialized
INFO - 2018-02-13 08:30:23 --> Loader Class Initialized
INFO - 2018-02-13 08:30:23 --> Helper loaded: url_helper
INFO - 2018-02-13 08:30:23 --> Helper loaded: form_helper
INFO - 2018-02-13 08:30:23 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:30:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:30:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:30:23 --> Form Validation Class Initialized
INFO - 2018-02-13 08:30:23 --> Model Class Initialized
INFO - 2018-02-13 08:30:23 --> Controller Class Initialized
INFO - 2018-02-13 08:30:23 --> Model Class Initialized
INFO - 2018-02-13 08:30:23 --> Model Class Initialized
INFO - 2018-02-13 08:30:23 --> Model Class Initialized
INFO - 2018-02-13 08:30:23 --> Model Class Initialized
INFO - 2018-02-13 08:30:23 --> Model Class Initialized
DEBUG - 2018-02-13 08:30:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:30:23 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 08:30:23 --> Final output sent to browser
DEBUG - 2018-02-13 08:30:23 --> Total execution time: 0.0561
INFO - 2018-02-13 08:30:23 --> Config Class Initialized
INFO - 2018-02-13 08:30:23 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:30:23 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:30:23 --> Utf8 Class Initialized
INFO - 2018-02-13 08:30:23 --> URI Class Initialized
INFO - 2018-02-13 08:30:23 --> Router Class Initialized
INFO - 2018-02-13 08:30:23 --> Output Class Initialized
INFO - 2018-02-13 08:30:23 --> Security Class Initialized
DEBUG - 2018-02-13 08:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:30:23 --> Input Class Initialized
INFO - 2018-02-13 08:30:23 --> Language Class Initialized
INFO - 2018-02-13 08:30:23 --> Loader Class Initialized
INFO - 2018-02-13 08:30:23 --> Helper loaded: url_helper
INFO - 2018-02-13 08:30:23 --> Helper loaded: form_helper
INFO - 2018-02-13 08:30:23 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:30:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:30:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:30:23 --> Form Validation Class Initialized
INFO - 2018-02-13 08:30:23 --> Model Class Initialized
INFO - 2018-02-13 08:30:23 --> Controller Class Initialized
INFO - 2018-02-13 08:30:23 --> Model Class Initialized
INFO - 2018-02-13 08:30:23 --> Model Class Initialized
INFO - 2018-02-13 08:30:23 --> Model Class Initialized
INFO - 2018-02-13 08:30:23 --> Model Class Initialized
INFO - 2018-02-13 08:30:23 --> Model Class Initialized
DEBUG - 2018-02-13 08:30:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:30:35 --> Config Class Initialized
INFO - 2018-02-13 08:30:35 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:30:35 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:30:35 --> Utf8 Class Initialized
INFO - 2018-02-13 08:30:35 --> URI Class Initialized
INFO - 2018-02-13 08:30:35 --> Router Class Initialized
INFO - 2018-02-13 08:30:35 --> Output Class Initialized
INFO - 2018-02-13 08:30:35 --> Security Class Initialized
DEBUG - 2018-02-13 08:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:30:35 --> Input Class Initialized
INFO - 2018-02-13 08:30:35 --> Language Class Initialized
INFO - 2018-02-13 08:30:35 --> Loader Class Initialized
INFO - 2018-02-13 08:30:35 --> Helper loaded: url_helper
INFO - 2018-02-13 08:30:35 --> Helper loaded: form_helper
INFO - 2018-02-13 08:30:35 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:30:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:30:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:30:35 --> Form Validation Class Initialized
INFO - 2018-02-13 08:30:35 --> Model Class Initialized
INFO - 2018-02-13 08:30:35 --> Controller Class Initialized
INFO - 2018-02-13 08:30:35 --> Model Class Initialized
INFO - 2018-02-13 08:30:35 --> Model Class Initialized
INFO - 2018-02-13 08:30:35 --> Model Class Initialized
INFO - 2018-02-13 08:30:35 --> Model Class Initialized
INFO - 2018-02-13 08:30:35 --> Model Class Initialized
DEBUG - 2018-02-13 08:30:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:30:35 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 08:30:35 --> Final output sent to browser
DEBUG - 2018-02-13 08:30:35 --> Total execution time: 0.0597
INFO - 2018-02-13 08:30:35 --> Config Class Initialized
INFO - 2018-02-13 08:30:35 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:30:35 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:30:35 --> Utf8 Class Initialized
INFO - 2018-02-13 08:30:35 --> URI Class Initialized
INFO - 2018-02-13 08:30:35 --> Router Class Initialized
INFO - 2018-02-13 08:30:35 --> Output Class Initialized
INFO - 2018-02-13 08:30:35 --> Security Class Initialized
DEBUG - 2018-02-13 08:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:30:35 --> Input Class Initialized
INFO - 2018-02-13 08:30:35 --> Language Class Initialized
INFO - 2018-02-13 08:30:35 --> Loader Class Initialized
INFO - 2018-02-13 08:30:35 --> Helper loaded: url_helper
INFO - 2018-02-13 08:30:35 --> Helper loaded: form_helper
INFO - 2018-02-13 08:30:35 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:30:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:30:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:30:35 --> Form Validation Class Initialized
INFO - 2018-02-13 08:30:35 --> Model Class Initialized
INFO - 2018-02-13 08:30:35 --> Controller Class Initialized
INFO - 2018-02-13 08:30:35 --> Model Class Initialized
INFO - 2018-02-13 08:30:35 --> Model Class Initialized
INFO - 2018-02-13 08:30:35 --> Model Class Initialized
INFO - 2018-02-13 08:30:35 --> Model Class Initialized
INFO - 2018-02-13 08:30:35 --> Model Class Initialized
DEBUG - 2018-02-13 08:30:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:32:38 --> Config Class Initialized
INFO - 2018-02-13 08:32:38 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:32:38 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:32:38 --> Utf8 Class Initialized
INFO - 2018-02-13 08:32:38 --> URI Class Initialized
INFO - 2018-02-13 08:32:38 --> Router Class Initialized
INFO - 2018-02-13 08:32:38 --> Output Class Initialized
INFO - 2018-02-13 08:32:38 --> Security Class Initialized
DEBUG - 2018-02-13 08:32:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:32:38 --> Input Class Initialized
INFO - 2018-02-13 08:32:38 --> Language Class Initialized
INFO - 2018-02-13 08:32:38 --> Loader Class Initialized
INFO - 2018-02-13 08:32:38 --> Helper loaded: url_helper
INFO - 2018-02-13 08:32:38 --> Helper loaded: form_helper
INFO - 2018-02-13 08:32:38 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:32:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:32:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:32:38 --> Form Validation Class Initialized
INFO - 2018-02-13 08:32:38 --> Model Class Initialized
INFO - 2018-02-13 08:32:38 --> Controller Class Initialized
INFO - 2018-02-13 08:32:38 --> Model Class Initialized
INFO - 2018-02-13 08:32:38 --> Model Class Initialized
INFO - 2018-02-13 08:32:38 --> Model Class Initialized
INFO - 2018-02-13 08:32:38 --> Model Class Initialized
INFO - 2018-02-13 08:32:38 --> Model Class Initialized
DEBUG - 2018-02-13 08:32:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:32:38 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 08:32:38 --> Final output sent to browser
DEBUG - 2018-02-13 08:32:38 --> Total execution time: 0.0686
INFO - 2018-02-13 08:32:38 --> Config Class Initialized
INFO - 2018-02-13 08:32:38 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:32:38 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:32:38 --> Utf8 Class Initialized
INFO - 2018-02-13 08:32:38 --> URI Class Initialized
INFO - 2018-02-13 08:32:38 --> Router Class Initialized
INFO - 2018-02-13 08:32:38 --> Output Class Initialized
INFO - 2018-02-13 08:32:38 --> Security Class Initialized
DEBUG - 2018-02-13 08:32:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:32:38 --> Input Class Initialized
INFO - 2018-02-13 08:32:38 --> Language Class Initialized
INFO - 2018-02-13 08:32:38 --> Loader Class Initialized
INFO - 2018-02-13 08:32:38 --> Helper loaded: url_helper
INFO - 2018-02-13 08:32:38 --> Helper loaded: form_helper
INFO - 2018-02-13 08:32:38 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:32:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:32:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:32:38 --> Form Validation Class Initialized
INFO - 2018-02-13 08:32:38 --> Model Class Initialized
INFO - 2018-02-13 08:32:38 --> Controller Class Initialized
INFO - 2018-02-13 08:32:38 --> Model Class Initialized
INFO - 2018-02-13 08:32:38 --> Model Class Initialized
INFO - 2018-02-13 08:32:38 --> Model Class Initialized
INFO - 2018-02-13 08:32:38 --> Model Class Initialized
INFO - 2018-02-13 08:32:38 --> Model Class Initialized
DEBUG - 2018-02-13 08:32:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:32:58 --> Config Class Initialized
INFO - 2018-02-13 08:32:58 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:32:58 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:32:58 --> Utf8 Class Initialized
INFO - 2018-02-13 08:32:58 --> URI Class Initialized
INFO - 2018-02-13 08:32:58 --> Router Class Initialized
INFO - 2018-02-13 08:32:58 --> Output Class Initialized
INFO - 2018-02-13 08:32:58 --> Security Class Initialized
DEBUG - 2018-02-13 08:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:32:58 --> Input Class Initialized
INFO - 2018-02-13 08:32:58 --> Language Class Initialized
INFO - 2018-02-13 08:32:58 --> Loader Class Initialized
INFO - 2018-02-13 08:32:58 --> Helper loaded: url_helper
INFO - 2018-02-13 08:32:58 --> Helper loaded: form_helper
INFO - 2018-02-13 08:32:58 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:32:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:32:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:32:58 --> Form Validation Class Initialized
INFO - 2018-02-13 08:32:58 --> Model Class Initialized
INFO - 2018-02-13 08:32:58 --> Controller Class Initialized
INFO - 2018-02-13 08:32:58 --> Model Class Initialized
INFO - 2018-02-13 08:32:58 --> Model Class Initialized
INFO - 2018-02-13 08:32:58 --> Model Class Initialized
INFO - 2018-02-13 08:32:58 --> Model Class Initialized
INFO - 2018-02-13 08:32:58 --> Model Class Initialized
DEBUG - 2018-02-13 08:32:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:32:58 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 08:32:58 --> Final output sent to browser
DEBUG - 2018-02-13 08:32:58 --> Total execution time: 0.0549
INFO - 2018-02-13 08:32:58 --> Config Class Initialized
INFO - 2018-02-13 08:32:58 --> Hooks Class Initialized
INFO - 2018-02-13 08:32:58 --> Config Class Initialized
INFO - 2018-02-13 08:32:58 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:32:58 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:32:58 --> Utf8 Class Initialized
DEBUG - 2018-02-13 08:32:58 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:32:58 --> Utf8 Class Initialized
INFO - 2018-02-13 08:32:58 --> URI Class Initialized
INFO - 2018-02-13 08:32:58 --> URI Class Initialized
INFO - 2018-02-13 08:32:58 --> Router Class Initialized
INFO - 2018-02-13 08:32:58 --> Router Class Initialized
INFO - 2018-02-13 08:32:58 --> Output Class Initialized
INFO - 2018-02-13 08:32:58 --> Output Class Initialized
INFO - 2018-02-13 08:32:58 --> Security Class Initialized
INFO - 2018-02-13 08:32:58 --> Security Class Initialized
DEBUG - 2018-02-13 08:32:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 08:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:32:58 --> Input Class Initialized
INFO - 2018-02-13 08:32:58 --> Input Class Initialized
INFO - 2018-02-13 08:32:58 --> Language Class Initialized
INFO - 2018-02-13 08:32:58 --> Language Class Initialized
INFO - 2018-02-13 08:32:58 --> Loader Class Initialized
INFO - 2018-02-13 08:32:58 --> Loader Class Initialized
INFO - 2018-02-13 08:32:58 --> Helper loaded: url_helper
INFO - 2018-02-13 08:32:58 --> Helper loaded: url_helper
INFO - 2018-02-13 08:32:58 --> Helper loaded: form_helper
INFO - 2018-02-13 08:32:58 --> Helper loaded: form_helper
INFO - 2018-02-13 08:32:58 --> Database Driver Class Initialized
INFO - 2018-02-13 08:32:58 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:32:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 08:32:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:32:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:32:58 --> Form Validation Class Initialized
INFO - 2018-02-13 08:32:58 --> Model Class Initialized
INFO - 2018-02-13 08:32:58 --> Controller Class Initialized
INFO - 2018-02-13 08:32:58 --> Model Class Initialized
INFO - 2018-02-13 08:32:58 --> Model Class Initialized
INFO - 2018-02-13 08:32:58 --> Model Class Initialized
INFO - 2018-02-13 08:32:58 --> Model Class Initialized
INFO - 2018-02-13 08:32:58 --> Model Class Initialized
DEBUG - 2018-02-13 08:32:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:32:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:32:58 --> Form Validation Class Initialized
INFO - 2018-02-13 08:32:58 --> Model Class Initialized
INFO - 2018-02-13 08:32:58 --> Controller Class Initialized
INFO - 2018-02-13 08:32:58 --> Model Class Initialized
INFO - 2018-02-13 08:32:58 --> Model Class Initialized
INFO - 2018-02-13 08:32:58 --> Model Class Initialized
INFO - 2018-02-13 08:32:58 --> Model Class Initialized
INFO - 2018-02-13 08:32:58 --> Model Class Initialized
DEBUG - 2018-02-13 08:32:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:33:06 --> Config Class Initialized
INFO - 2018-02-13 08:33:06 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:33:06 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:33:06 --> Utf8 Class Initialized
INFO - 2018-02-13 08:33:06 --> URI Class Initialized
INFO - 2018-02-13 08:33:06 --> Router Class Initialized
INFO - 2018-02-13 08:33:06 --> Output Class Initialized
INFO - 2018-02-13 08:33:06 --> Security Class Initialized
DEBUG - 2018-02-13 08:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:33:06 --> Input Class Initialized
INFO - 2018-02-13 08:33:06 --> Language Class Initialized
INFO - 2018-02-13 08:33:06 --> Loader Class Initialized
INFO - 2018-02-13 08:33:06 --> Helper loaded: url_helper
INFO - 2018-02-13 08:33:06 --> Helper loaded: form_helper
INFO - 2018-02-13 08:33:07 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:33:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:33:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:33:07 --> Form Validation Class Initialized
INFO - 2018-02-13 08:33:07 --> Model Class Initialized
INFO - 2018-02-13 08:33:07 --> Controller Class Initialized
INFO - 2018-02-13 08:33:07 --> Model Class Initialized
INFO - 2018-02-13 08:33:07 --> Model Class Initialized
INFO - 2018-02-13 08:33:07 --> Model Class Initialized
INFO - 2018-02-13 08:33:07 --> Model Class Initialized
INFO - 2018-02-13 08:33:07 --> Model Class Initialized
DEBUG - 2018-02-13 08:33:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:33:07 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 08:33:07 --> Final output sent to browser
DEBUG - 2018-02-13 08:33:07 --> Total execution time: 0.0579
INFO - 2018-02-13 08:33:07 --> Config Class Initialized
INFO - 2018-02-13 08:33:07 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:33:07 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:33:07 --> Utf8 Class Initialized
INFO - 2018-02-13 08:33:07 --> URI Class Initialized
INFO - 2018-02-13 08:33:07 --> Router Class Initialized
INFO - 2018-02-13 08:33:07 --> Output Class Initialized
INFO - 2018-02-13 08:33:07 --> Security Class Initialized
DEBUG - 2018-02-13 08:33:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:33:07 --> Input Class Initialized
INFO - 2018-02-13 08:33:07 --> Language Class Initialized
INFO - 2018-02-13 08:33:07 --> Loader Class Initialized
INFO - 2018-02-13 08:33:07 --> Helper loaded: url_helper
INFO - 2018-02-13 08:33:07 --> Helper loaded: form_helper
INFO - 2018-02-13 08:33:07 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:33:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:33:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:33:07 --> Form Validation Class Initialized
INFO - 2018-02-13 08:33:07 --> Model Class Initialized
INFO - 2018-02-13 08:33:07 --> Controller Class Initialized
INFO - 2018-02-13 08:33:07 --> Model Class Initialized
INFO - 2018-02-13 08:33:07 --> Model Class Initialized
INFO - 2018-02-13 08:33:07 --> Model Class Initialized
INFO - 2018-02-13 08:33:07 --> Model Class Initialized
INFO - 2018-02-13 08:33:07 --> Model Class Initialized
DEBUG - 2018-02-13 08:33:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:41:44 --> Config Class Initialized
INFO - 2018-02-13 08:41:44 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:41:44 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:41:44 --> Utf8 Class Initialized
INFO - 2018-02-13 08:41:44 --> URI Class Initialized
INFO - 2018-02-13 08:41:44 --> Router Class Initialized
INFO - 2018-02-13 08:41:44 --> Output Class Initialized
INFO - 2018-02-13 08:41:44 --> Security Class Initialized
DEBUG - 2018-02-13 08:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:41:44 --> Input Class Initialized
INFO - 2018-02-13 08:41:44 --> Language Class Initialized
INFO - 2018-02-13 08:41:44 --> Loader Class Initialized
INFO - 2018-02-13 08:41:44 --> Helper loaded: url_helper
INFO - 2018-02-13 08:41:44 --> Helper loaded: form_helper
INFO - 2018-02-13 08:41:44 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:41:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:41:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:41:44 --> Form Validation Class Initialized
INFO - 2018-02-13 08:41:44 --> Model Class Initialized
INFO - 2018-02-13 08:41:44 --> Controller Class Initialized
INFO - 2018-02-13 08:41:44 --> Model Class Initialized
INFO - 2018-02-13 08:41:44 --> Model Class Initialized
INFO - 2018-02-13 08:41:44 --> Model Class Initialized
INFO - 2018-02-13 08:41:44 --> Model Class Initialized
INFO - 2018-02-13 08:41:44 --> Model Class Initialized
DEBUG - 2018-02-13 08:41:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:41:44 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 08:41:44 --> Final output sent to browser
DEBUG - 2018-02-13 08:41:44 --> Total execution time: 0.0564
INFO - 2018-02-13 08:41:44 --> Config Class Initialized
INFO - 2018-02-13 08:41:44 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:41:44 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:41:44 --> Utf8 Class Initialized
INFO - 2018-02-13 08:41:44 --> URI Class Initialized
INFO - 2018-02-13 08:41:44 --> Router Class Initialized
INFO - 2018-02-13 08:41:44 --> Output Class Initialized
INFO - 2018-02-13 08:41:44 --> Security Class Initialized
DEBUG - 2018-02-13 08:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:41:44 --> Input Class Initialized
INFO - 2018-02-13 08:41:44 --> Language Class Initialized
INFO - 2018-02-13 08:41:44 --> Loader Class Initialized
INFO - 2018-02-13 08:41:44 --> Helper loaded: url_helper
INFO - 2018-02-13 08:41:44 --> Helper loaded: form_helper
INFO - 2018-02-13 08:41:44 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:41:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:41:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:41:44 --> Form Validation Class Initialized
INFO - 2018-02-13 08:41:44 --> Model Class Initialized
INFO - 2018-02-13 08:41:44 --> Controller Class Initialized
INFO - 2018-02-13 08:41:44 --> Model Class Initialized
INFO - 2018-02-13 08:41:44 --> Model Class Initialized
INFO - 2018-02-13 08:41:44 --> Model Class Initialized
INFO - 2018-02-13 08:41:44 --> Model Class Initialized
INFO - 2018-02-13 08:41:44 --> Model Class Initialized
DEBUG - 2018-02-13 08:41:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:41:46 --> Config Class Initialized
INFO - 2018-02-13 08:41:46 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:41:46 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:41:46 --> Utf8 Class Initialized
INFO - 2018-02-13 08:41:46 --> URI Class Initialized
INFO - 2018-02-13 08:41:46 --> Router Class Initialized
INFO - 2018-02-13 08:41:46 --> Output Class Initialized
INFO - 2018-02-13 08:41:46 --> Security Class Initialized
DEBUG - 2018-02-13 08:41:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:41:46 --> Input Class Initialized
INFO - 2018-02-13 08:41:46 --> Language Class Initialized
INFO - 2018-02-13 08:41:46 --> Loader Class Initialized
INFO - 2018-02-13 08:41:46 --> Helper loaded: url_helper
INFO - 2018-02-13 08:41:46 --> Helper loaded: form_helper
INFO - 2018-02-13 08:41:46 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:41:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:41:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:41:46 --> Form Validation Class Initialized
INFO - 2018-02-13 08:41:46 --> Model Class Initialized
INFO - 2018-02-13 08:41:46 --> Controller Class Initialized
INFO - 2018-02-13 08:41:46 --> Model Class Initialized
INFO - 2018-02-13 08:41:46 --> Model Class Initialized
INFO - 2018-02-13 08:41:46 --> Model Class Initialized
INFO - 2018-02-13 08:41:46 --> Model Class Initialized
INFO - 2018-02-13 08:41:46 --> Model Class Initialized
DEBUG - 2018-02-13 08:41:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:41:46 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 08:41:46 --> Final output sent to browser
DEBUG - 2018-02-13 08:41:46 --> Total execution time: 0.0550
INFO - 2018-02-13 08:41:46 --> Config Class Initialized
INFO - 2018-02-13 08:41:46 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:41:46 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:41:46 --> Utf8 Class Initialized
INFO - 2018-02-13 08:41:46 --> URI Class Initialized
INFO - 2018-02-13 08:41:46 --> Router Class Initialized
INFO - 2018-02-13 08:41:46 --> Output Class Initialized
INFO - 2018-02-13 08:41:46 --> Security Class Initialized
DEBUG - 2018-02-13 08:41:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:41:46 --> Input Class Initialized
INFO - 2018-02-13 08:41:46 --> Language Class Initialized
INFO - 2018-02-13 08:41:46 --> Loader Class Initialized
INFO - 2018-02-13 08:41:46 --> Helper loaded: url_helper
INFO - 2018-02-13 08:41:46 --> Helper loaded: form_helper
INFO - 2018-02-13 08:41:46 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:41:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:41:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:41:46 --> Form Validation Class Initialized
INFO - 2018-02-13 08:41:46 --> Model Class Initialized
INFO - 2018-02-13 08:41:46 --> Controller Class Initialized
INFO - 2018-02-13 08:41:46 --> Model Class Initialized
INFO - 2018-02-13 08:41:46 --> Model Class Initialized
INFO - 2018-02-13 08:41:46 --> Model Class Initialized
INFO - 2018-02-13 08:41:46 --> Model Class Initialized
INFO - 2018-02-13 08:41:46 --> Model Class Initialized
DEBUG - 2018-02-13 08:41:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:41:48 --> Config Class Initialized
INFO - 2018-02-13 08:41:48 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:41:48 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:41:48 --> Utf8 Class Initialized
INFO - 2018-02-13 08:41:48 --> URI Class Initialized
INFO - 2018-02-13 08:41:48 --> Router Class Initialized
INFO - 2018-02-13 08:41:48 --> Output Class Initialized
INFO - 2018-02-13 08:41:48 --> Security Class Initialized
DEBUG - 2018-02-13 08:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:41:48 --> Input Class Initialized
INFO - 2018-02-13 08:41:48 --> Language Class Initialized
INFO - 2018-02-13 08:41:48 --> Loader Class Initialized
INFO - 2018-02-13 08:41:48 --> Helper loaded: url_helper
INFO - 2018-02-13 08:41:48 --> Helper loaded: form_helper
INFO - 2018-02-13 08:41:48 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:41:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:41:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:41:48 --> Form Validation Class Initialized
INFO - 2018-02-13 08:41:48 --> Model Class Initialized
INFO - 2018-02-13 08:41:48 --> Controller Class Initialized
INFO - 2018-02-13 08:41:48 --> Model Class Initialized
INFO - 2018-02-13 08:41:48 --> Model Class Initialized
INFO - 2018-02-13 08:41:48 --> Model Class Initialized
INFO - 2018-02-13 08:41:48 --> Model Class Initialized
INFO - 2018-02-13 08:41:48 --> Model Class Initialized
DEBUG - 2018-02-13 08:41:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:41:48 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 08:41:48 --> Final output sent to browser
DEBUG - 2018-02-13 08:41:48 --> Total execution time: 0.0534
INFO - 2018-02-13 08:41:48 --> Config Class Initialized
INFO - 2018-02-13 08:41:48 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:41:48 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:41:48 --> Utf8 Class Initialized
INFO - 2018-02-13 08:41:48 --> URI Class Initialized
INFO - 2018-02-13 08:41:48 --> Router Class Initialized
INFO - 2018-02-13 08:41:48 --> Output Class Initialized
INFO - 2018-02-13 08:41:48 --> Security Class Initialized
DEBUG - 2018-02-13 08:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:41:48 --> Input Class Initialized
INFO - 2018-02-13 08:41:48 --> Language Class Initialized
INFO - 2018-02-13 08:41:48 --> Loader Class Initialized
INFO - 2018-02-13 08:41:48 --> Helper loaded: url_helper
INFO - 2018-02-13 08:41:48 --> Helper loaded: form_helper
INFO - 2018-02-13 08:41:48 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:41:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:41:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:41:48 --> Form Validation Class Initialized
INFO - 2018-02-13 08:41:48 --> Model Class Initialized
INFO - 2018-02-13 08:41:48 --> Controller Class Initialized
INFO - 2018-02-13 08:41:48 --> Model Class Initialized
INFO - 2018-02-13 08:41:48 --> Model Class Initialized
INFO - 2018-02-13 08:41:48 --> Model Class Initialized
INFO - 2018-02-13 08:41:48 --> Model Class Initialized
INFO - 2018-02-13 08:41:48 --> Model Class Initialized
DEBUG - 2018-02-13 08:41:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:41:49 --> Config Class Initialized
INFO - 2018-02-13 08:41:49 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:41:49 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:41:49 --> Utf8 Class Initialized
INFO - 2018-02-13 08:41:49 --> URI Class Initialized
INFO - 2018-02-13 08:41:49 --> Router Class Initialized
INFO - 2018-02-13 08:41:49 --> Output Class Initialized
INFO - 2018-02-13 08:41:49 --> Security Class Initialized
DEBUG - 2018-02-13 08:41:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:41:49 --> Input Class Initialized
INFO - 2018-02-13 08:41:49 --> Language Class Initialized
INFO - 2018-02-13 08:41:49 --> Loader Class Initialized
INFO - 2018-02-13 08:41:49 --> Helper loaded: url_helper
INFO - 2018-02-13 08:41:49 --> Helper loaded: form_helper
INFO - 2018-02-13 08:41:49 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:41:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:41:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:41:50 --> Form Validation Class Initialized
INFO - 2018-02-13 08:41:50 --> Model Class Initialized
INFO - 2018-02-13 08:41:50 --> Controller Class Initialized
INFO - 2018-02-13 08:41:50 --> Model Class Initialized
INFO - 2018-02-13 08:41:50 --> Model Class Initialized
INFO - 2018-02-13 08:41:50 --> Model Class Initialized
INFO - 2018-02-13 08:41:50 --> Model Class Initialized
INFO - 2018-02-13 08:41:50 --> Model Class Initialized
DEBUG - 2018-02-13 08:41:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:41:50 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 08:41:50 --> Final output sent to browser
DEBUG - 2018-02-13 08:41:50 --> Total execution time: 0.0587
INFO - 2018-02-13 08:41:50 --> Config Class Initialized
INFO - 2018-02-13 08:41:50 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:41:50 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:41:50 --> Utf8 Class Initialized
INFO - 2018-02-13 08:41:50 --> URI Class Initialized
INFO - 2018-02-13 08:41:50 --> Router Class Initialized
INFO - 2018-02-13 08:41:50 --> Output Class Initialized
INFO - 2018-02-13 08:41:50 --> Security Class Initialized
DEBUG - 2018-02-13 08:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:41:50 --> Input Class Initialized
INFO - 2018-02-13 08:41:50 --> Language Class Initialized
INFO - 2018-02-13 08:41:50 --> Loader Class Initialized
INFO - 2018-02-13 08:41:50 --> Helper loaded: url_helper
INFO - 2018-02-13 08:41:50 --> Helper loaded: form_helper
INFO - 2018-02-13 08:41:50 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:41:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:41:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:41:50 --> Form Validation Class Initialized
INFO - 2018-02-13 08:41:50 --> Model Class Initialized
INFO - 2018-02-13 08:41:50 --> Controller Class Initialized
INFO - 2018-02-13 08:41:50 --> Model Class Initialized
INFO - 2018-02-13 08:41:50 --> Model Class Initialized
INFO - 2018-02-13 08:41:50 --> Model Class Initialized
INFO - 2018-02-13 08:41:50 --> Model Class Initialized
INFO - 2018-02-13 08:41:50 --> Model Class Initialized
DEBUG - 2018-02-13 08:41:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:41:51 --> Config Class Initialized
INFO - 2018-02-13 08:41:51 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:41:51 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:41:51 --> Utf8 Class Initialized
INFO - 2018-02-13 08:41:51 --> URI Class Initialized
INFO - 2018-02-13 08:41:51 --> Router Class Initialized
INFO - 2018-02-13 08:41:51 --> Output Class Initialized
INFO - 2018-02-13 08:41:51 --> Security Class Initialized
DEBUG - 2018-02-13 08:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:41:51 --> Input Class Initialized
INFO - 2018-02-13 08:41:51 --> Language Class Initialized
INFO - 2018-02-13 08:41:51 --> Loader Class Initialized
INFO - 2018-02-13 08:41:51 --> Helper loaded: url_helper
INFO - 2018-02-13 08:41:51 --> Helper loaded: form_helper
INFO - 2018-02-13 08:41:51 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:41:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:41:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:41:51 --> Form Validation Class Initialized
INFO - 2018-02-13 08:41:51 --> Model Class Initialized
INFO - 2018-02-13 08:41:51 --> Controller Class Initialized
INFO - 2018-02-13 08:41:51 --> Model Class Initialized
INFO - 2018-02-13 08:41:51 --> Model Class Initialized
INFO - 2018-02-13 08:41:51 --> Model Class Initialized
INFO - 2018-02-13 08:41:51 --> Model Class Initialized
INFO - 2018-02-13 08:41:51 --> Model Class Initialized
DEBUG - 2018-02-13 08:41:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:41:51 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 08:41:51 --> Final output sent to browser
DEBUG - 2018-02-13 08:41:51 --> Total execution time: 0.0539
INFO - 2018-02-13 08:41:52 --> Config Class Initialized
INFO - 2018-02-13 08:41:52 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:41:52 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:41:52 --> Utf8 Class Initialized
INFO - 2018-02-13 08:41:52 --> URI Class Initialized
INFO - 2018-02-13 08:41:52 --> Router Class Initialized
INFO - 2018-02-13 08:41:52 --> Output Class Initialized
INFO - 2018-02-13 08:41:52 --> Security Class Initialized
DEBUG - 2018-02-13 08:41:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:41:52 --> Input Class Initialized
INFO - 2018-02-13 08:41:52 --> Language Class Initialized
INFO - 2018-02-13 08:41:52 --> Loader Class Initialized
INFO - 2018-02-13 08:41:52 --> Helper loaded: url_helper
INFO - 2018-02-13 08:41:52 --> Helper loaded: form_helper
INFO - 2018-02-13 08:41:52 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:41:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:41:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:41:52 --> Form Validation Class Initialized
INFO - 2018-02-13 08:41:52 --> Model Class Initialized
INFO - 2018-02-13 08:41:52 --> Controller Class Initialized
INFO - 2018-02-13 08:41:52 --> Model Class Initialized
INFO - 2018-02-13 08:41:52 --> Model Class Initialized
INFO - 2018-02-13 08:41:52 --> Model Class Initialized
INFO - 2018-02-13 08:41:52 --> Model Class Initialized
INFO - 2018-02-13 08:41:52 --> Model Class Initialized
DEBUG - 2018-02-13 08:41:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:41:54 --> Config Class Initialized
INFO - 2018-02-13 08:41:54 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:41:54 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:41:54 --> Utf8 Class Initialized
INFO - 2018-02-13 08:41:54 --> URI Class Initialized
INFO - 2018-02-13 08:41:54 --> Router Class Initialized
INFO - 2018-02-13 08:41:54 --> Output Class Initialized
INFO - 2018-02-13 08:41:54 --> Security Class Initialized
DEBUG - 2018-02-13 08:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:41:54 --> Input Class Initialized
INFO - 2018-02-13 08:41:54 --> Language Class Initialized
INFO - 2018-02-13 08:41:54 --> Loader Class Initialized
INFO - 2018-02-13 08:41:54 --> Helper loaded: url_helper
INFO - 2018-02-13 08:41:54 --> Helper loaded: form_helper
INFO - 2018-02-13 08:41:54 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:41:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:41:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:41:54 --> Form Validation Class Initialized
INFO - 2018-02-13 08:41:54 --> Model Class Initialized
INFO - 2018-02-13 08:41:54 --> Controller Class Initialized
INFO - 2018-02-13 08:41:54 --> Model Class Initialized
INFO - 2018-02-13 08:41:54 --> Model Class Initialized
INFO - 2018-02-13 08:41:54 --> Model Class Initialized
INFO - 2018-02-13 08:41:54 --> Model Class Initialized
INFO - 2018-02-13 08:41:54 --> Model Class Initialized
DEBUG - 2018-02-13 08:41:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:41:54 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 08:41:54 --> Final output sent to browser
DEBUG - 2018-02-13 08:41:54 --> Total execution time: 0.0524
INFO - 2018-02-13 08:41:54 --> Config Class Initialized
INFO - 2018-02-13 08:41:54 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:41:54 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:41:54 --> Utf8 Class Initialized
INFO - 2018-02-13 08:41:54 --> URI Class Initialized
INFO - 2018-02-13 08:41:54 --> Router Class Initialized
INFO - 2018-02-13 08:41:54 --> Output Class Initialized
INFO - 2018-02-13 08:41:54 --> Security Class Initialized
DEBUG - 2018-02-13 08:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:41:54 --> Input Class Initialized
INFO - 2018-02-13 08:41:54 --> Language Class Initialized
INFO - 2018-02-13 08:41:54 --> Loader Class Initialized
INFO - 2018-02-13 08:41:54 --> Helper loaded: url_helper
INFO - 2018-02-13 08:41:54 --> Helper loaded: form_helper
INFO - 2018-02-13 08:41:54 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:41:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:41:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:41:54 --> Form Validation Class Initialized
INFO - 2018-02-13 08:41:54 --> Model Class Initialized
INFO - 2018-02-13 08:41:54 --> Controller Class Initialized
INFO - 2018-02-13 08:41:54 --> Model Class Initialized
INFO - 2018-02-13 08:41:54 --> Model Class Initialized
INFO - 2018-02-13 08:41:54 --> Model Class Initialized
INFO - 2018-02-13 08:41:54 --> Model Class Initialized
INFO - 2018-02-13 08:41:54 --> Model Class Initialized
DEBUG - 2018-02-13 08:41:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:41:55 --> Config Class Initialized
INFO - 2018-02-13 08:41:55 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:41:55 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:41:55 --> Utf8 Class Initialized
INFO - 2018-02-13 08:41:55 --> URI Class Initialized
INFO - 2018-02-13 08:41:55 --> Router Class Initialized
INFO - 2018-02-13 08:41:55 --> Output Class Initialized
INFO - 2018-02-13 08:41:55 --> Security Class Initialized
DEBUG - 2018-02-13 08:41:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:41:55 --> Input Class Initialized
INFO - 2018-02-13 08:41:55 --> Language Class Initialized
INFO - 2018-02-13 08:41:55 --> Loader Class Initialized
INFO - 2018-02-13 08:41:55 --> Helper loaded: url_helper
INFO - 2018-02-13 08:41:55 --> Helper loaded: form_helper
INFO - 2018-02-13 08:41:55 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:41:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:41:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:41:55 --> Form Validation Class Initialized
INFO - 2018-02-13 08:41:55 --> Model Class Initialized
INFO - 2018-02-13 08:41:55 --> Controller Class Initialized
INFO - 2018-02-13 08:41:55 --> Model Class Initialized
INFO - 2018-02-13 08:41:55 --> Model Class Initialized
INFO - 2018-02-13 08:41:55 --> Model Class Initialized
INFO - 2018-02-13 08:41:55 --> Model Class Initialized
INFO - 2018-02-13 08:41:55 --> Model Class Initialized
DEBUG - 2018-02-13 08:41:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:41:55 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 08:41:55 --> Final output sent to browser
DEBUG - 2018-02-13 08:41:55 --> Total execution time: 0.0517
INFO - 2018-02-13 08:41:55 --> Config Class Initialized
INFO - 2018-02-13 08:41:55 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:41:55 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:41:55 --> Utf8 Class Initialized
INFO - 2018-02-13 08:41:55 --> URI Class Initialized
INFO - 2018-02-13 08:41:55 --> Router Class Initialized
INFO - 2018-02-13 08:41:55 --> Output Class Initialized
INFO - 2018-02-13 08:41:55 --> Security Class Initialized
DEBUG - 2018-02-13 08:41:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:41:55 --> Input Class Initialized
INFO - 2018-02-13 08:41:55 --> Language Class Initialized
INFO - 2018-02-13 08:41:55 --> Loader Class Initialized
INFO - 2018-02-13 08:41:55 --> Helper loaded: url_helper
INFO - 2018-02-13 08:41:55 --> Helper loaded: form_helper
INFO - 2018-02-13 08:41:55 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:41:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:41:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:41:55 --> Form Validation Class Initialized
INFO - 2018-02-13 08:41:55 --> Model Class Initialized
INFO - 2018-02-13 08:41:55 --> Controller Class Initialized
INFO - 2018-02-13 08:41:55 --> Model Class Initialized
INFO - 2018-02-13 08:41:55 --> Model Class Initialized
INFO - 2018-02-13 08:41:55 --> Model Class Initialized
INFO - 2018-02-13 08:41:55 --> Model Class Initialized
INFO - 2018-02-13 08:41:55 --> Model Class Initialized
DEBUG - 2018-02-13 08:41:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:41:57 --> Config Class Initialized
INFO - 2018-02-13 08:41:57 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:41:57 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:41:57 --> Utf8 Class Initialized
INFO - 2018-02-13 08:41:57 --> URI Class Initialized
INFO - 2018-02-13 08:41:57 --> Router Class Initialized
INFO - 2018-02-13 08:41:57 --> Output Class Initialized
INFO - 2018-02-13 08:41:57 --> Security Class Initialized
DEBUG - 2018-02-13 08:41:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:41:57 --> Input Class Initialized
INFO - 2018-02-13 08:41:57 --> Language Class Initialized
INFO - 2018-02-13 08:41:57 --> Loader Class Initialized
INFO - 2018-02-13 08:41:57 --> Helper loaded: url_helper
INFO - 2018-02-13 08:41:57 --> Helper loaded: form_helper
INFO - 2018-02-13 08:41:57 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:41:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:41:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:41:57 --> Form Validation Class Initialized
INFO - 2018-02-13 08:41:57 --> Model Class Initialized
INFO - 2018-02-13 08:41:57 --> Controller Class Initialized
INFO - 2018-02-13 08:41:57 --> Model Class Initialized
INFO - 2018-02-13 08:41:57 --> Model Class Initialized
INFO - 2018-02-13 08:41:57 --> Model Class Initialized
INFO - 2018-02-13 08:41:57 --> Model Class Initialized
INFO - 2018-02-13 08:41:57 --> Model Class Initialized
DEBUG - 2018-02-13 08:41:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:41:57 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 08:41:57 --> Final output sent to browser
DEBUG - 2018-02-13 08:41:57 --> Total execution time: 0.0447
INFO - 2018-02-13 08:41:58 --> Config Class Initialized
INFO - 2018-02-13 08:41:58 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:41:58 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:41:58 --> Utf8 Class Initialized
INFO - 2018-02-13 08:41:58 --> URI Class Initialized
INFO - 2018-02-13 08:41:58 --> Router Class Initialized
INFO - 2018-02-13 08:41:58 --> Output Class Initialized
INFO - 2018-02-13 08:41:58 --> Security Class Initialized
DEBUG - 2018-02-13 08:41:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:41:58 --> Input Class Initialized
INFO - 2018-02-13 08:41:58 --> Language Class Initialized
INFO - 2018-02-13 08:41:58 --> Loader Class Initialized
INFO - 2018-02-13 08:41:58 --> Helper loaded: url_helper
INFO - 2018-02-13 08:41:58 --> Helper loaded: form_helper
INFO - 2018-02-13 08:41:58 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:41:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:41:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:41:58 --> Form Validation Class Initialized
INFO - 2018-02-13 08:41:58 --> Model Class Initialized
INFO - 2018-02-13 08:41:58 --> Controller Class Initialized
INFO - 2018-02-13 08:41:58 --> Model Class Initialized
INFO - 2018-02-13 08:41:58 --> Model Class Initialized
INFO - 2018-02-13 08:41:58 --> Model Class Initialized
INFO - 2018-02-13 08:41:58 --> Model Class Initialized
INFO - 2018-02-13 08:41:58 --> Model Class Initialized
DEBUG - 2018-02-13 08:41:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:42:03 --> Config Class Initialized
INFO - 2018-02-13 08:42:03 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:42:03 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:42:03 --> Utf8 Class Initialized
INFO - 2018-02-13 08:42:03 --> URI Class Initialized
INFO - 2018-02-13 08:42:03 --> Router Class Initialized
INFO - 2018-02-13 08:42:03 --> Output Class Initialized
INFO - 2018-02-13 08:42:03 --> Security Class Initialized
DEBUG - 2018-02-13 08:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:42:03 --> Input Class Initialized
INFO - 2018-02-13 08:42:03 --> Language Class Initialized
INFO - 2018-02-13 08:42:03 --> Loader Class Initialized
INFO - 2018-02-13 08:42:03 --> Helper loaded: url_helper
INFO - 2018-02-13 08:42:03 --> Helper loaded: form_helper
INFO - 2018-02-13 08:42:03 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:42:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:42:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:42:03 --> Form Validation Class Initialized
INFO - 2018-02-13 08:42:03 --> Model Class Initialized
INFO - 2018-02-13 08:42:03 --> Controller Class Initialized
INFO - 2018-02-13 08:42:03 --> Model Class Initialized
INFO - 2018-02-13 08:42:03 --> Model Class Initialized
INFO - 2018-02-13 08:42:03 --> Model Class Initialized
INFO - 2018-02-13 08:42:03 --> Model Class Initialized
INFO - 2018-02-13 08:42:03 --> Model Class Initialized
DEBUG - 2018-02-13 08:42:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:42:03 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 08:42:03 --> Final output sent to browser
DEBUG - 2018-02-13 08:42:03 --> Total execution time: 0.0495
INFO - 2018-02-13 08:42:04 --> Config Class Initialized
INFO - 2018-02-13 08:42:04 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:42:04 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:42:04 --> Utf8 Class Initialized
INFO - 2018-02-13 08:42:04 --> URI Class Initialized
INFO - 2018-02-13 08:42:04 --> Router Class Initialized
INFO - 2018-02-13 08:42:04 --> Output Class Initialized
INFO - 2018-02-13 08:42:04 --> Security Class Initialized
DEBUG - 2018-02-13 08:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:42:04 --> Input Class Initialized
INFO - 2018-02-13 08:42:04 --> Language Class Initialized
INFO - 2018-02-13 08:42:04 --> Loader Class Initialized
INFO - 2018-02-13 08:42:04 --> Helper loaded: url_helper
INFO - 2018-02-13 08:42:04 --> Helper loaded: form_helper
INFO - 2018-02-13 08:42:04 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:42:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:42:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:42:04 --> Form Validation Class Initialized
INFO - 2018-02-13 08:42:04 --> Model Class Initialized
INFO - 2018-02-13 08:42:04 --> Controller Class Initialized
INFO - 2018-02-13 08:42:04 --> Model Class Initialized
INFO - 2018-02-13 08:42:04 --> Model Class Initialized
INFO - 2018-02-13 08:42:04 --> Model Class Initialized
INFO - 2018-02-13 08:42:04 --> Model Class Initialized
INFO - 2018-02-13 08:42:04 --> Model Class Initialized
DEBUG - 2018-02-13 08:42:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:42:05 --> Config Class Initialized
INFO - 2018-02-13 08:42:05 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:42:05 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:42:05 --> Utf8 Class Initialized
INFO - 2018-02-13 08:42:05 --> URI Class Initialized
INFO - 2018-02-13 08:42:05 --> Router Class Initialized
INFO - 2018-02-13 08:42:05 --> Output Class Initialized
INFO - 2018-02-13 08:42:05 --> Security Class Initialized
DEBUG - 2018-02-13 08:42:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:42:05 --> Input Class Initialized
INFO - 2018-02-13 08:42:05 --> Language Class Initialized
INFO - 2018-02-13 08:42:05 --> Loader Class Initialized
INFO - 2018-02-13 08:42:05 --> Helper loaded: url_helper
INFO - 2018-02-13 08:42:05 --> Helper loaded: form_helper
INFO - 2018-02-13 08:42:05 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:42:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:42:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:42:05 --> Form Validation Class Initialized
INFO - 2018-02-13 08:42:05 --> Model Class Initialized
INFO - 2018-02-13 08:42:05 --> Controller Class Initialized
INFO - 2018-02-13 08:42:05 --> Model Class Initialized
INFO - 2018-02-13 08:42:05 --> Model Class Initialized
INFO - 2018-02-13 08:42:05 --> Model Class Initialized
INFO - 2018-02-13 08:42:05 --> Model Class Initialized
INFO - 2018-02-13 08:42:05 --> Model Class Initialized
DEBUG - 2018-02-13 08:42:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:42:05 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 08:42:05 --> Final output sent to browser
DEBUG - 2018-02-13 08:42:05 --> Total execution time: 0.0518
INFO - 2018-02-13 08:42:05 --> Config Class Initialized
INFO - 2018-02-13 08:42:05 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:42:05 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:42:05 --> Utf8 Class Initialized
INFO - 2018-02-13 08:42:05 --> URI Class Initialized
INFO - 2018-02-13 08:42:05 --> Router Class Initialized
INFO - 2018-02-13 08:42:05 --> Output Class Initialized
INFO - 2018-02-13 08:42:05 --> Security Class Initialized
DEBUG - 2018-02-13 08:42:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:42:05 --> Input Class Initialized
INFO - 2018-02-13 08:42:05 --> Language Class Initialized
INFO - 2018-02-13 08:42:05 --> Loader Class Initialized
INFO - 2018-02-13 08:42:05 --> Helper loaded: url_helper
INFO - 2018-02-13 08:42:05 --> Helper loaded: form_helper
INFO - 2018-02-13 08:42:05 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:42:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:42:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:42:05 --> Form Validation Class Initialized
INFO - 2018-02-13 08:42:05 --> Model Class Initialized
INFO - 2018-02-13 08:42:05 --> Controller Class Initialized
INFO - 2018-02-13 08:42:05 --> Model Class Initialized
INFO - 2018-02-13 08:42:05 --> Model Class Initialized
INFO - 2018-02-13 08:42:05 --> Model Class Initialized
INFO - 2018-02-13 08:42:05 --> Model Class Initialized
INFO - 2018-02-13 08:42:05 --> Model Class Initialized
DEBUG - 2018-02-13 08:42:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:42:07 --> Config Class Initialized
INFO - 2018-02-13 08:42:07 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:42:07 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:42:07 --> Utf8 Class Initialized
INFO - 2018-02-13 08:42:07 --> URI Class Initialized
INFO - 2018-02-13 08:42:07 --> Router Class Initialized
INFO - 2018-02-13 08:42:07 --> Output Class Initialized
INFO - 2018-02-13 08:42:07 --> Security Class Initialized
DEBUG - 2018-02-13 08:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:42:07 --> Input Class Initialized
INFO - 2018-02-13 08:42:07 --> Language Class Initialized
INFO - 2018-02-13 08:42:07 --> Loader Class Initialized
INFO - 2018-02-13 08:42:07 --> Helper loaded: url_helper
INFO - 2018-02-13 08:42:07 --> Helper loaded: form_helper
INFO - 2018-02-13 08:42:07 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:42:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:42:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:42:07 --> Form Validation Class Initialized
INFO - 2018-02-13 08:42:07 --> Model Class Initialized
INFO - 2018-02-13 08:42:07 --> Controller Class Initialized
INFO - 2018-02-13 08:42:07 --> Model Class Initialized
INFO - 2018-02-13 08:42:07 --> Model Class Initialized
INFO - 2018-02-13 08:42:07 --> Model Class Initialized
INFO - 2018-02-13 08:42:07 --> Model Class Initialized
INFO - 2018-02-13 08:42:07 --> Model Class Initialized
DEBUG - 2018-02-13 08:42:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:42:07 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 08:42:07 --> Final output sent to browser
DEBUG - 2018-02-13 08:42:07 --> Total execution time: 0.0506
INFO - 2018-02-13 08:42:07 --> Config Class Initialized
INFO - 2018-02-13 08:42:07 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:42:07 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:42:07 --> Utf8 Class Initialized
INFO - 2018-02-13 08:42:07 --> URI Class Initialized
INFO - 2018-02-13 08:42:07 --> Router Class Initialized
INFO - 2018-02-13 08:42:07 --> Output Class Initialized
INFO - 2018-02-13 08:42:07 --> Security Class Initialized
DEBUG - 2018-02-13 08:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:42:07 --> Input Class Initialized
INFO - 2018-02-13 08:42:07 --> Language Class Initialized
INFO - 2018-02-13 08:42:07 --> Loader Class Initialized
INFO - 2018-02-13 08:42:07 --> Helper loaded: url_helper
INFO - 2018-02-13 08:42:07 --> Helper loaded: form_helper
INFO - 2018-02-13 08:42:07 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:42:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:42:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:42:07 --> Form Validation Class Initialized
INFO - 2018-02-13 08:42:07 --> Model Class Initialized
INFO - 2018-02-13 08:42:07 --> Controller Class Initialized
INFO - 2018-02-13 08:42:07 --> Model Class Initialized
INFO - 2018-02-13 08:42:07 --> Model Class Initialized
INFO - 2018-02-13 08:42:07 --> Model Class Initialized
INFO - 2018-02-13 08:42:07 --> Model Class Initialized
INFO - 2018-02-13 08:42:07 --> Model Class Initialized
DEBUG - 2018-02-13 08:42:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:42:20 --> Config Class Initialized
INFO - 2018-02-13 08:42:20 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:42:20 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:42:20 --> Utf8 Class Initialized
INFO - 2018-02-13 08:42:20 --> URI Class Initialized
INFO - 2018-02-13 08:42:20 --> Router Class Initialized
INFO - 2018-02-13 08:42:20 --> Output Class Initialized
INFO - 2018-02-13 08:42:20 --> Security Class Initialized
DEBUG - 2018-02-13 08:42:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:42:20 --> Input Class Initialized
INFO - 2018-02-13 08:42:20 --> Language Class Initialized
INFO - 2018-02-13 08:42:20 --> Loader Class Initialized
INFO - 2018-02-13 08:42:20 --> Helper loaded: url_helper
INFO - 2018-02-13 08:42:20 --> Helper loaded: form_helper
INFO - 2018-02-13 08:42:20 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:42:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:42:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:42:20 --> Form Validation Class Initialized
INFO - 2018-02-13 08:42:20 --> Model Class Initialized
INFO - 2018-02-13 08:42:20 --> Controller Class Initialized
INFO - 2018-02-13 08:42:20 --> Model Class Initialized
INFO - 2018-02-13 08:42:20 --> Model Class Initialized
INFO - 2018-02-13 08:42:20 --> Model Class Initialized
INFO - 2018-02-13 08:42:20 --> Model Class Initialized
INFO - 2018-02-13 08:42:20 --> Model Class Initialized
DEBUG - 2018-02-13 08:42:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:42:20 --> Config Class Initialized
INFO - 2018-02-13 08:42:20 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:42:20 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:42:20 --> Utf8 Class Initialized
INFO - 2018-02-13 08:42:20 --> URI Class Initialized
INFO - 2018-02-13 08:42:20 --> Router Class Initialized
INFO - 2018-02-13 08:42:20 --> Output Class Initialized
INFO - 2018-02-13 08:42:20 --> Security Class Initialized
DEBUG - 2018-02-13 08:42:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:42:20 --> Input Class Initialized
INFO - 2018-02-13 08:42:20 --> Language Class Initialized
INFO - 2018-02-13 08:42:20 --> Loader Class Initialized
INFO - 2018-02-13 08:42:20 --> Helper loaded: url_helper
INFO - 2018-02-13 08:42:20 --> Helper loaded: form_helper
INFO - 2018-02-13 08:42:20 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:42:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:42:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:42:20 --> Form Validation Class Initialized
INFO - 2018-02-13 08:42:20 --> Model Class Initialized
INFO - 2018-02-13 08:42:20 --> Controller Class Initialized
INFO - 2018-02-13 08:42:20 --> Model Class Initialized
INFO - 2018-02-13 08:42:20 --> Model Class Initialized
INFO - 2018-02-13 08:42:20 --> Model Class Initialized
INFO - 2018-02-13 08:42:20 --> Model Class Initialized
INFO - 2018-02-13 08:42:20 --> Model Class Initialized
DEBUG - 2018-02-13 08:42:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:42:51 --> Config Class Initialized
INFO - 2018-02-13 08:42:51 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:42:51 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:42:51 --> Utf8 Class Initialized
INFO - 2018-02-13 08:42:51 --> URI Class Initialized
INFO - 2018-02-13 08:42:51 --> Router Class Initialized
INFO - 2018-02-13 08:42:51 --> Output Class Initialized
INFO - 2018-02-13 08:42:51 --> Security Class Initialized
DEBUG - 2018-02-13 08:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:42:52 --> Input Class Initialized
INFO - 2018-02-13 08:42:52 --> Language Class Initialized
INFO - 2018-02-13 08:42:52 --> Loader Class Initialized
INFO - 2018-02-13 08:42:52 --> Helper loaded: url_helper
INFO - 2018-02-13 08:42:52 --> Helper loaded: form_helper
INFO - 2018-02-13 08:42:52 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:42:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:42:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:42:52 --> Form Validation Class Initialized
INFO - 2018-02-13 08:42:52 --> Model Class Initialized
INFO - 2018-02-13 08:42:52 --> Controller Class Initialized
INFO - 2018-02-13 08:42:52 --> Model Class Initialized
INFO - 2018-02-13 08:42:52 --> Model Class Initialized
INFO - 2018-02-13 08:42:52 --> Model Class Initialized
INFO - 2018-02-13 08:42:52 --> Model Class Initialized
INFO - 2018-02-13 08:42:52 --> Model Class Initialized
DEBUG - 2018-02-13 08:42:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:42:52 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 08:42:52 --> Final output sent to browser
DEBUG - 2018-02-13 08:42:52 --> Total execution time: 0.0583
INFO - 2018-02-13 08:42:52 --> Config Class Initialized
INFO - 2018-02-13 08:42:52 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:42:52 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:42:52 --> Utf8 Class Initialized
INFO - 2018-02-13 08:42:52 --> URI Class Initialized
INFO - 2018-02-13 08:42:52 --> Router Class Initialized
INFO - 2018-02-13 08:42:52 --> Output Class Initialized
INFO - 2018-02-13 08:42:52 --> Security Class Initialized
DEBUG - 2018-02-13 08:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:42:52 --> Input Class Initialized
INFO - 2018-02-13 08:42:52 --> Language Class Initialized
INFO - 2018-02-13 08:42:52 --> Loader Class Initialized
INFO - 2018-02-13 08:42:52 --> Helper loaded: url_helper
INFO - 2018-02-13 08:42:52 --> Helper loaded: form_helper
INFO - 2018-02-13 08:42:52 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:42:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:42:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:42:52 --> Form Validation Class Initialized
INFO - 2018-02-13 08:42:52 --> Model Class Initialized
INFO - 2018-02-13 08:42:52 --> Controller Class Initialized
INFO - 2018-02-13 08:42:52 --> Model Class Initialized
INFO - 2018-02-13 08:42:52 --> Model Class Initialized
INFO - 2018-02-13 08:42:52 --> Model Class Initialized
INFO - 2018-02-13 08:42:52 --> Model Class Initialized
INFO - 2018-02-13 08:42:52 --> Model Class Initialized
DEBUG - 2018-02-13 08:42:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:42:59 --> Config Class Initialized
INFO - 2018-02-13 08:42:59 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:42:59 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:42:59 --> Utf8 Class Initialized
INFO - 2018-02-13 08:42:59 --> URI Class Initialized
INFO - 2018-02-13 08:42:59 --> Router Class Initialized
INFO - 2018-02-13 08:42:59 --> Output Class Initialized
INFO - 2018-02-13 08:42:59 --> Security Class Initialized
DEBUG - 2018-02-13 08:42:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:42:59 --> Input Class Initialized
INFO - 2018-02-13 08:42:59 --> Language Class Initialized
INFO - 2018-02-13 08:42:59 --> Loader Class Initialized
INFO - 2018-02-13 08:42:59 --> Helper loaded: url_helper
INFO - 2018-02-13 08:42:59 --> Helper loaded: form_helper
INFO - 2018-02-13 08:42:59 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:42:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:42:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:42:59 --> Form Validation Class Initialized
INFO - 2018-02-13 08:42:59 --> Model Class Initialized
INFO - 2018-02-13 08:42:59 --> Controller Class Initialized
INFO - 2018-02-13 08:42:59 --> Model Class Initialized
INFO - 2018-02-13 08:42:59 --> Model Class Initialized
INFO - 2018-02-13 08:42:59 --> Model Class Initialized
INFO - 2018-02-13 08:42:59 --> Model Class Initialized
INFO - 2018-02-13 08:42:59 --> Model Class Initialized
DEBUG - 2018-02-13 08:42:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:42:59 --> Config Class Initialized
INFO - 2018-02-13 08:42:59 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:42:59 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:42:59 --> Utf8 Class Initialized
INFO - 2018-02-13 08:42:59 --> URI Class Initialized
INFO - 2018-02-13 08:42:59 --> Router Class Initialized
INFO - 2018-02-13 08:42:59 --> Output Class Initialized
INFO - 2018-02-13 08:42:59 --> Security Class Initialized
DEBUG - 2018-02-13 08:42:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:42:59 --> Input Class Initialized
INFO - 2018-02-13 08:42:59 --> Language Class Initialized
INFO - 2018-02-13 08:42:59 --> Loader Class Initialized
INFO - 2018-02-13 08:42:59 --> Helper loaded: url_helper
INFO - 2018-02-13 08:42:59 --> Helper loaded: form_helper
INFO - 2018-02-13 08:42:59 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:42:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:42:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:42:59 --> Form Validation Class Initialized
INFO - 2018-02-13 08:42:59 --> Model Class Initialized
INFO - 2018-02-13 08:42:59 --> Controller Class Initialized
INFO - 2018-02-13 08:42:59 --> Model Class Initialized
INFO - 2018-02-13 08:42:59 --> Model Class Initialized
INFO - 2018-02-13 08:42:59 --> Model Class Initialized
INFO - 2018-02-13 08:42:59 --> Model Class Initialized
INFO - 2018-02-13 08:42:59 --> Model Class Initialized
DEBUG - 2018-02-13 08:42:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:43:07 --> Config Class Initialized
INFO - 2018-02-13 08:43:07 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:43:07 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:43:07 --> Utf8 Class Initialized
INFO - 2018-02-13 08:43:07 --> URI Class Initialized
INFO - 2018-02-13 08:43:07 --> Router Class Initialized
INFO - 2018-02-13 08:43:07 --> Output Class Initialized
INFO - 2018-02-13 08:43:07 --> Security Class Initialized
DEBUG - 2018-02-13 08:43:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:43:07 --> Input Class Initialized
INFO - 2018-02-13 08:43:07 --> Language Class Initialized
INFO - 2018-02-13 08:43:07 --> Loader Class Initialized
INFO - 2018-02-13 08:43:07 --> Helper loaded: url_helper
INFO - 2018-02-13 08:43:07 --> Helper loaded: form_helper
INFO - 2018-02-13 08:43:07 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:43:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:43:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:43:07 --> Form Validation Class Initialized
INFO - 2018-02-13 08:43:07 --> Model Class Initialized
INFO - 2018-02-13 08:43:07 --> Controller Class Initialized
INFO - 2018-02-13 08:43:07 --> Model Class Initialized
INFO - 2018-02-13 08:43:07 --> Model Class Initialized
INFO - 2018-02-13 08:43:07 --> Model Class Initialized
INFO - 2018-02-13 08:43:07 --> Model Class Initialized
INFO - 2018-02-13 08:43:07 --> Model Class Initialized
DEBUG - 2018-02-13 08:43:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:43:07 --> Config Class Initialized
INFO - 2018-02-13 08:43:07 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:43:07 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:43:07 --> Utf8 Class Initialized
INFO - 2018-02-13 08:43:07 --> URI Class Initialized
INFO - 2018-02-13 08:43:07 --> Router Class Initialized
INFO - 2018-02-13 08:43:07 --> Output Class Initialized
INFO - 2018-02-13 08:43:07 --> Security Class Initialized
DEBUG - 2018-02-13 08:43:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:43:07 --> Input Class Initialized
INFO - 2018-02-13 08:43:07 --> Language Class Initialized
INFO - 2018-02-13 08:43:07 --> Loader Class Initialized
INFO - 2018-02-13 08:43:07 --> Helper loaded: url_helper
INFO - 2018-02-13 08:43:07 --> Helper loaded: form_helper
INFO - 2018-02-13 08:43:07 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:43:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:43:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:43:07 --> Form Validation Class Initialized
INFO - 2018-02-13 08:43:07 --> Model Class Initialized
INFO - 2018-02-13 08:43:07 --> Controller Class Initialized
INFO - 2018-02-13 08:43:07 --> Model Class Initialized
INFO - 2018-02-13 08:43:07 --> Model Class Initialized
INFO - 2018-02-13 08:43:07 --> Model Class Initialized
INFO - 2018-02-13 08:43:07 --> Model Class Initialized
INFO - 2018-02-13 08:43:07 --> Model Class Initialized
DEBUG - 2018-02-13 08:43:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:43:07 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 08:43:07 --> Final output sent to browser
DEBUG - 2018-02-13 08:43:07 --> Total execution time: 0.0473
INFO - 2018-02-13 08:43:07 --> Config Class Initialized
INFO - 2018-02-13 08:43:07 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:43:07 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:43:07 --> Utf8 Class Initialized
INFO - 2018-02-13 08:43:07 --> URI Class Initialized
INFO - 2018-02-13 08:43:07 --> Router Class Initialized
INFO - 2018-02-13 08:43:07 --> Output Class Initialized
INFO - 2018-02-13 08:43:07 --> Security Class Initialized
DEBUG - 2018-02-13 08:43:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:43:07 --> Input Class Initialized
INFO - 2018-02-13 08:43:07 --> Language Class Initialized
INFO - 2018-02-13 08:43:07 --> Loader Class Initialized
INFO - 2018-02-13 08:43:07 --> Helper loaded: url_helper
INFO - 2018-02-13 08:43:07 --> Helper loaded: form_helper
INFO - 2018-02-13 08:43:08 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:43:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:43:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:43:08 --> Form Validation Class Initialized
INFO - 2018-02-13 08:43:08 --> Model Class Initialized
INFO - 2018-02-13 08:43:08 --> Controller Class Initialized
INFO - 2018-02-13 08:43:08 --> Model Class Initialized
INFO - 2018-02-13 08:43:08 --> Model Class Initialized
INFO - 2018-02-13 08:43:08 --> Model Class Initialized
INFO - 2018-02-13 08:43:08 --> Model Class Initialized
INFO - 2018-02-13 08:43:08 --> Model Class Initialized
DEBUG - 2018-02-13 08:43:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:43:14 --> Config Class Initialized
INFO - 2018-02-13 08:43:14 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:43:14 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:43:14 --> Utf8 Class Initialized
INFO - 2018-02-13 08:43:14 --> URI Class Initialized
INFO - 2018-02-13 08:43:14 --> Router Class Initialized
INFO - 2018-02-13 08:43:14 --> Output Class Initialized
INFO - 2018-02-13 08:43:14 --> Security Class Initialized
DEBUG - 2018-02-13 08:43:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:43:14 --> Input Class Initialized
INFO - 2018-02-13 08:43:14 --> Language Class Initialized
INFO - 2018-02-13 08:43:14 --> Loader Class Initialized
INFO - 2018-02-13 08:43:14 --> Helper loaded: url_helper
INFO - 2018-02-13 08:43:14 --> Helper loaded: form_helper
INFO - 2018-02-13 08:43:14 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:43:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:43:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:43:14 --> Form Validation Class Initialized
INFO - 2018-02-13 08:43:14 --> Model Class Initialized
INFO - 2018-02-13 08:43:14 --> Controller Class Initialized
INFO - 2018-02-13 08:43:14 --> Model Class Initialized
INFO - 2018-02-13 08:43:14 --> Model Class Initialized
INFO - 2018-02-13 08:43:14 --> Model Class Initialized
INFO - 2018-02-13 08:43:14 --> Model Class Initialized
INFO - 2018-02-13 08:43:14 --> Model Class Initialized
DEBUG - 2018-02-13 08:43:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:43:14 --> Config Class Initialized
INFO - 2018-02-13 08:43:14 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:43:14 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:43:14 --> Utf8 Class Initialized
INFO - 2018-02-13 08:43:14 --> URI Class Initialized
INFO - 2018-02-13 08:43:14 --> Router Class Initialized
INFO - 2018-02-13 08:43:14 --> Output Class Initialized
INFO - 2018-02-13 08:43:14 --> Security Class Initialized
DEBUG - 2018-02-13 08:43:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:43:14 --> Input Class Initialized
INFO - 2018-02-13 08:43:14 --> Language Class Initialized
INFO - 2018-02-13 08:43:14 --> Loader Class Initialized
INFO - 2018-02-13 08:43:14 --> Helper loaded: url_helper
INFO - 2018-02-13 08:43:14 --> Helper loaded: form_helper
INFO - 2018-02-13 08:43:14 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:43:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:43:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:43:14 --> Form Validation Class Initialized
INFO - 2018-02-13 08:43:14 --> Model Class Initialized
INFO - 2018-02-13 08:43:14 --> Controller Class Initialized
INFO - 2018-02-13 08:43:14 --> Model Class Initialized
INFO - 2018-02-13 08:43:14 --> Model Class Initialized
INFO - 2018-02-13 08:43:14 --> Model Class Initialized
INFO - 2018-02-13 08:43:14 --> Model Class Initialized
INFO - 2018-02-13 08:43:14 --> Model Class Initialized
DEBUG - 2018-02-13 08:43:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:43:14 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 08:43:14 --> Final output sent to browser
DEBUG - 2018-02-13 08:43:14 --> Total execution time: 0.0478
INFO - 2018-02-13 08:43:14 --> Config Class Initialized
INFO - 2018-02-13 08:43:14 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:43:14 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:43:14 --> Utf8 Class Initialized
INFO - 2018-02-13 08:43:14 --> URI Class Initialized
INFO - 2018-02-13 08:43:14 --> Router Class Initialized
INFO - 2018-02-13 08:43:14 --> Output Class Initialized
INFO - 2018-02-13 08:43:14 --> Security Class Initialized
DEBUG - 2018-02-13 08:43:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:43:14 --> Input Class Initialized
INFO - 2018-02-13 08:43:14 --> Language Class Initialized
INFO - 2018-02-13 08:43:14 --> Loader Class Initialized
INFO - 2018-02-13 08:43:14 --> Helper loaded: url_helper
INFO - 2018-02-13 08:43:14 --> Helper loaded: form_helper
INFO - 2018-02-13 08:43:14 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:43:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:43:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:43:14 --> Form Validation Class Initialized
INFO - 2018-02-13 08:43:14 --> Model Class Initialized
INFO - 2018-02-13 08:43:14 --> Controller Class Initialized
INFO - 2018-02-13 08:43:14 --> Model Class Initialized
INFO - 2018-02-13 08:43:14 --> Model Class Initialized
INFO - 2018-02-13 08:43:14 --> Model Class Initialized
INFO - 2018-02-13 08:43:14 --> Model Class Initialized
INFO - 2018-02-13 08:43:14 --> Model Class Initialized
DEBUG - 2018-02-13 08:43:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:43:17 --> Config Class Initialized
INFO - 2018-02-13 08:43:17 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:43:17 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:43:17 --> Utf8 Class Initialized
INFO - 2018-02-13 08:43:17 --> URI Class Initialized
INFO - 2018-02-13 08:43:17 --> Router Class Initialized
INFO - 2018-02-13 08:43:17 --> Output Class Initialized
INFO - 2018-02-13 08:43:17 --> Security Class Initialized
DEBUG - 2018-02-13 08:43:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:43:17 --> Input Class Initialized
INFO - 2018-02-13 08:43:17 --> Language Class Initialized
INFO - 2018-02-13 08:43:17 --> Loader Class Initialized
INFO - 2018-02-13 08:43:17 --> Helper loaded: url_helper
INFO - 2018-02-13 08:43:17 --> Helper loaded: form_helper
INFO - 2018-02-13 08:43:17 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:43:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:43:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:43:17 --> Form Validation Class Initialized
INFO - 2018-02-13 08:43:17 --> Model Class Initialized
INFO - 2018-02-13 08:43:17 --> Controller Class Initialized
INFO - 2018-02-13 08:43:17 --> Model Class Initialized
INFO - 2018-02-13 08:43:17 --> Model Class Initialized
INFO - 2018-02-13 08:43:17 --> Model Class Initialized
INFO - 2018-02-13 08:43:17 --> Model Class Initialized
INFO - 2018-02-13 08:43:17 --> Model Class Initialized
DEBUG - 2018-02-13 08:43:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:43:17 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 08:43:17 --> Final output sent to browser
DEBUG - 2018-02-13 08:43:17 --> Total execution time: 0.0510
INFO - 2018-02-13 08:43:17 --> Config Class Initialized
INFO - 2018-02-13 08:43:17 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:43:17 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:43:17 --> Utf8 Class Initialized
INFO - 2018-02-13 08:43:17 --> URI Class Initialized
INFO - 2018-02-13 08:43:17 --> Router Class Initialized
INFO - 2018-02-13 08:43:17 --> Output Class Initialized
INFO - 2018-02-13 08:43:17 --> Security Class Initialized
DEBUG - 2018-02-13 08:43:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:43:17 --> Input Class Initialized
INFO - 2018-02-13 08:43:17 --> Language Class Initialized
INFO - 2018-02-13 08:43:17 --> Loader Class Initialized
INFO - 2018-02-13 08:43:17 --> Helper loaded: url_helper
INFO - 2018-02-13 08:43:17 --> Helper loaded: form_helper
INFO - 2018-02-13 08:43:17 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:43:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:43:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:43:17 --> Form Validation Class Initialized
INFO - 2018-02-13 08:43:17 --> Model Class Initialized
INFO - 2018-02-13 08:43:17 --> Controller Class Initialized
INFO - 2018-02-13 08:43:17 --> Model Class Initialized
INFO - 2018-02-13 08:43:17 --> Model Class Initialized
INFO - 2018-02-13 08:43:17 --> Model Class Initialized
INFO - 2018-02-13 08:43:17 --> Model Class Initialized
INFO - 2018-02-13 08:43:17 --> Model Class Initialized
DEBUG - 2018-02-13 08:43:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:43:18 --> Config Class Initialized
INFO - 2018-02-13 08:43:18 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:43:18 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:43:18 --> Utf8 Class Initialized
INFO - 2018-02-13 08:43:18 --> URI Class Initialized
INFO - 2018-02-13 08:43:18 --> Router Class Initialized
INFO - 2018-02-13 08:43:18 --> Output Class Initialized
INFO - 2018-02-13 08:43:18 --> Security Class Initialized
DEBUG - 2018-02-13 08:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:43:18 --> Input Class Initialized
INFO - 2018-02-13 08:43:18 --> Language Class Initialized
INFO - 2018-02-13 08:43:18 --> Loader Class Initialized
INFO - 2018-02-13 08:43:18 --> Helper loaded: url_helper
INFO - 2018-02-13 08:43:18 --> Helper loaded: form_helper
INFO - 2018-02-13 08:43:18 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:43:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:43:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:43:18 --> Form Validation Class Initialized
INFO - 2018-02-13 08:43:18 --> Model Class Initialized
INFO - 2018-02-13 08:43:18 --> Controller Class Initialized
INFO - 2018-02-13 08:43:18 --> Model Class Initialized
INFO - 2018-02-13 08:43:18 --> Model Class Initialized
INFO - 2018-02-13 08:43:18 --> Model Class Initialized
INFO - 2018-02-13 08:43:18 --> Model Class Initialized
INFO - 2018-02-13 08:43:18 --> Model Class Initialized
DEBUG - 2018-02-13 08:43:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:43:18 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 08:43:18 --> Final output sent to browser
DEBUG - 2018-02-13 08:43:18 --> Total execution time: 0.0683
INFO - 2018-02-13 08:43:18 --> Config Class Initialized
INFO - 2018-02-13 08:43:18 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:43:18 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:43:18 --> Utf8 Class Initialized
INFO - 2018-02-13 08:43:18 --> URI Class Initialized
INFO - 2018-02-13 08:43:18 --> Router Class Initialized
INFO - 2018-02-13 08:43:18 --> Output Class Initialized
INFO - 2018-02-13 08:43:18 --> Security Class Initialized
DEBUG - 2018-02-13 08:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:43:18 --> Input Class Initialized
INFO - 2018-02-13 08:43:18 --> Language Class Initialized
INFO - 2018-02-13 08:43:18 --> Loader Class Initialized
INFO - 2018-02-13 08:43:18 --> Helper loaded: url_helper
INFO - 2018-02-13 08:43:18 --> Helper loaded: form_helper
INFO - 2018-02-13 08:43:19 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:43:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:43:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:43:19 --> Form Validation Class Initialized
INFO - 2018-02-13 08:43:19 --> Model Class Initialized
INFO - 2018-02-13 08:43:19 --> Controller Class Initialized
INFO - 2018-02-13 08:43:19 --> Model Class Initialized
INFO - 2018-02-13 08:43:19 --> Model Class Initialized
INFO - 2018-02-13 08:43:19 --> Model Class Initialized
INFO - 2018-02-13 08:43:19 --> Model Class Initialized
INFO - 2018-02-13 08:43:19 --> Model Class Initialized
DEBUG - 2018-02-13 08:43:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:43:20 --> Config Class Initialized
INFO - 2018-02-13 08:43:20 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:43:20 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:43:20 --> Utf8 Class Initialized
INFO - 2018-02-13 08:43:20 --> URI Class Initialized
INFO - 2018-02-13 08:43:20 --> Router Class Initialized
INFO - 2018-02-13 08:43:20 --> Output Class Initialized
INFO - 2018-02-13 08:43:20 --> Security Class Initialized
DEBUG - 2018-02-13 08:43:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:43:20 --> Input Class Initialized
INFO - 2018-02-13 08:43:20 --> Language Class Initialized
INFO - 2018-02-13 08:43:20 --> Loader Class Initialized
INFO - 2018-02-13 08:43:20 --> Helper loaded: url_helper
INFO - 2018-02-13 08:43:20 --> Helper loaded: form_helper
INFO - 2018-02-13 08:43:20 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:43:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:43:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:43:20 --> Form Validation Class Initialized
INFO - 2018-02-13 08:43:20 --> Model Class Initialized
INFO - 2018-02-13 08:43:20 --> Controller Class Initialized
INFO - 2018-02-13 08:43:20 --> Model Class Initialized
INFO - 2018-02-13 08:43:20 --> Model Class Initialized
INFO - 2018-02-13 08:43:20 --> Model Class Initialized
INFO - 2018-02-13 08:43:20 --> Model Class Initialized
INFO - 2018-02-13 08:43:20 --> Model Class Initialized
DEBUG - 2018-02-13 08:43:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:43:20 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 08:43:20 --> Final output sent to browser
DEBUG - 2018-02-13 08:43:20 --> Total execution time: 0.0544
INFO - 2018-02-13 08:43:20 --> Config Class Initialized
INFO - 2018-02-13 08:43:20 --> Hooks Class Initialized
INFO - 2018-02-13 08:43:20 --> Config Class Initialized
INFO - 2018-02-13 08:43:20 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:43:20 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:43:20 --> Utf8 Class Initialized
DEBUG - 2018-02-13 08:43:20 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:43:20 --> URI Class Initialized
INFO - 2018-02-13 08:43:20 --> Utf8 Class Initialized
INFO - 2018-02-13 08:43:20 --> URI Class Initialized
INFO - 2018-02-13 08:43:20 --> Router Class Initialized
INFO - 2018-02-13 08:43:20 --> Router Class Initialized
INFO - 2018-02-13 08:43:20 --> Output Class Initialized
INFO - 2018-02-13 08:43:20 --> Output Class Initialized
INFO - 2018-02-13 08:43:20 --> Security Class Initialized
INFO - 2018-02-13 08:43:20 --> Security Class Initialized
DEBUG - 2018-02-13 08:43:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:43:20 --> Input Class Initialized
INFO - 2018-02-13 08:43:20 --> Language Class Initialized
DEBUG - 2018-02-13 08:43:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:43:20 --> Input Class Initialized
INFO - 2018-02-13 08:43:20 --> Language Class Initialized
INFO - 2018-02-13 08:43:20 --> Loader Class Initialized
INFO - 2018-02-13 08:43:20 --> Loader Class Initialized
INFO - 2018-02-13 08:43:20 --> Helper loaded: url_helper
INFO - 2018-02-13 08:43:20 --> Helper loaded: url_helper
INFO - 2018-02-13 08:43:20 --> Helper loaded: form_helper
INFO - 2018-02-13 08:43:20 --> Helper loaded: form_helper
INFO - 2018-02-13 08:43:20 --> Database Driver Class Initialized
INFO - 2018-02-13 08:43:20 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:43:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:43:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-02-13 08:43:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:43:20 --> Form Validation Class Initialized
INFO - 2018-02-13 08:43:20 --> Model Class Initialized
INFO - 2018-02-13 08:43:20 --> Controller Class Initialized
INFO - 2018-02-13 08:43:20 --> Model Class Initialized
INFO - 2018-02-13 08:43:20 --> Model Class Initialized
INFO - 2018-02-13 08:43:20 --> Model Class Initialized
INFO - 2018-02-13 08:43:20 --> Model Class Initialized
INFO - 2018-02-13 08:43:20 --> Model Class Initialized
DEBUG - 2018-02-13 08:43:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:43:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:43:20 --> Form Validation Class Initialized
INFO - 2018-02-13 08:43:20 --> Model Class Initialized
INFO - 2018-02-13 08:43:20 --> Controller Class Initialized
INFO - 2018-02-13 08:43:20 --> Model Class Initialized
INFO - 2018-02-13 08:43:20 --> Model Class Initialized
INFO - 2018-02-13 08:43:20 --> Model Class Initialized
INFO - 2018-02-13 08:43:20 --> Model Class Initialized
INFO - 2018-02-13 08:43:20 --> Model Class Initialized
DEBUG - 2018-02-13 08:43:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:43:53 --> Config Class Initialized
INFO - 2018-02-13 08:43:53 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:43:53 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:43:53 --> Utf8 Class Initialized
INFO - 2018-02-13 08:43:53 --> URI Class Initialized
INFO - 2018-02-13 08:43:53 --> Router Class Initialized
INFO - 2018-02-13 08:43:53 --> Output Class Initialized
INFO - 2018-02-13 08:43:53 --> Security Class Initialized
DEBUG - 2018-02-13 08:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:43:53 --> Input Class Initialized
INFO - 2018-02-13 08:43:53 --> Language Class Initialized
INFO - 2018-02-13 08:43:53 --> Loader Class Initialized
INFO - 2018-02-13 08:43:53 --> Helper loaded: url_helper
INFO - 2018-02-13 08:43:53 --> Helper loaded: form_helper
INFO - 2018-02-13 08:43:53 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:43:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:43:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:43:53 --> Form Validation Class Initialized
INFO - 2018-02-13 08:43:53 --> Model Class Initialized
INFO - 2018-02-13 08:43:53 --> Controller Class Initialized
INFO - 2018-02-13 08:43:53 --> Model Class Initialized
INFO - 2018-02-13 08:43:53 --> Model Class Initialized
INFO - 2018-02-13 08:43:53 --> Model Class Initialized
INFO - 2018-02-13 08:43:53 --> Model Class Initialized
INFO - 2018-02-13 08:43:53 --> Model Class Initialized
DEBUG - 2018-02-13 08:43:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:43:54 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 08:43:54 --> Final output sent to browser
DEBUG - 2018-02-13 08:43:54 --> Total execution time: 0.3103
INFO - 2018-02-13 08:43:54 --> Config Class Initialized
INFO - 2018-02-13 08:43:54 --> Hooks Class Initialized
INFO - 2018-02-13 08:43:54 --> Config Class Initialized
INFO - 2018-02-13 08:43:54 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:43:54 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:43:54 --> Utf8 Class Initialized
DEBUG - 2018-02-13 08:43:54 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:43:54 --> Utf8 Class Initialized
INFO - 2018-02-13 08:43:54 --> URI Class Initialized
INFO - 2018-02-13 08:43:54 --> URI Class Initialized
INFO - 2018-02-13 08:43:54 --> Router Class Initialized
INFO - 2018-02-13 08:43:54 --> Router Class Initialized
INFO - 2018-02-13 08:43:54 --> Output Class Initialized
INFO - 2018-02-13 08:43:54 --> Output Class Initialized
INFO - 2018-02-13 08:43:54 --> Security Class Initialized
INFO - 2018-02-13 08:43:54 --> Security Class Initialized
DEBUG - 2018-02-13 08:43:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 08:43:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:43:54 --> Input Class Initialized
INFO - 2018-02-13 08:43:54 --> Input Class Initialized
INFO - 2018-02-13 08:43:54 --> Language Class Initialized
INFO - 2018-02-13 08:43:54 --> Language Class Initialized
INFO - 2018-02-13 08:43:54 --> Loader Class Initialized
INFO - 2018-02-13 08:43:54 --> Loader Class Initialized
INFO - 2018-02-13 08:43:54 --> Helper loaded: url_helper
INFO - 2018-02-13 08:43:54 --> Helper loaded: url_helper
INFO - 2018-02-13 08:43:54 --> Helper loaded: form_helper
INFO - 2018-02-13 08:43:54 --> Helper loaded: form_helper
INFO - 2018-02-13 08:43:54 --> Database Driver Class Initialized
INFO - 2018-02-13 08:43:54 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:43:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:43:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-02-13 08:43:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:43:54 --> Form Validation Class Initialized
INFO - 2018-02-13 08:43:54 --> Model Class Initialized
INFO - 2018-02-13 08:43:54 --> Controller Class Initialized
INFO - 2018-02-13 08:43:54 --> Model Class Initialized
INFO - 2018-02-13 08:43:54 --> Model Class Initialized
INFO - 2018-02-13 08:43:54 --> Model Class Initialized
INFO - 2018-02-13 08:43:54 --> Model Class Initialized
INFO - 2018-02-13 08:43:54 --> Model Class Initialized
DEBUG - 2018-02-13 08:43:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:43:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:43:54 --> Form Validation Class Initialized
INFO - 2018-02-13 08:43:54 --> Model Class Initialized
INFO - 2018-02-13 08:43:54 --> Controller Class Initialized
INFO - 2018-02-13 08:43:54 --> Model Class Initialized
INFO - 2018-02-13 08:43:54 --> Model Class Initialized
INFO - 2018-02-13 08:43:54 --> Model Class Initialized
INFO - 2018-02-13 08:43:54 --> Model Class Initialized
INFO - 2018-02-13 08:43:54 --> Model Class Initialized
DEBUG - 2018-02-13 08:43:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:45:13 --> Config Class Initialized
INFO - 2018-02-13 08:45:13 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:45:13 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:45:13 --> Utf8 Class Initialized
INFO - 2018-02-13 08:45:13 --> URI Class Initialized
INFO - 2018-02-13 08:45:13 --> Router Class Initialized
INFO - 2018-02-13 08:45:13 --> Output Class Initialized
INFO - 2018-02-13 08:45:13 --> Security Class Initialized
DEBUG - 2018-02-13 08:45:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:45:13 --> Input Class Initialized
INFO - 2018-02-13 08:45:13 --> Language Class Initialized
INFO - 2018-02-13 08:45:13 --> Loader Class Initialized
INFO - 2018-02-13 08:45:13 --> Helper loaded: url_helper
INFO - 2018-02-13 08:45:13 --> Helper loaded: form_helper
INFO - 2018-02-13 08:45:13 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:45:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:45:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:45:13 --> Form Validation Class Initialized
INFO - 2018-02-13 08:45:13 --> Model Class Initialized
INFO - 2018-02-13 08:45:13 --> Controller Class Initialized
INFO - 2018-02-13 08:45:13 --> Model Class Initialized
INFO - 2018-02-13 08:45:13 --> Model Class Initialized
INFO - 2018-02-13 08:45:13 --> Model Class Initialized
INFO - 2018-02-13 08:45:13 --> Model Class Initialized
INFO - 2018-02-13 08:45:13 --> Model Class Initialized
DEBUG - 2018-02-13 08:45:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:45:13 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 08:45:13 --> Final output sent to browser
DEBUG - 2018-02-13 08:45:13 --> Total execution time: 0.0596
INFO - 2018-02-13 08:45:13 --> Config Class Initialized
INFO - 2018-02-13 08:45:13 --> Hooks Class Initialized
INFO - 2018-02-13 08:45:13 --> Config Class Initialized
INFO - 2018-02-13 08:45:13 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:45:13 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:45:13 --> Utf8 Class Initialized
DEBUG - 2018-02-13 08:45:13 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:45:13 --> Utf8 Class Initialized
INFO - 2018-02-13 08:45:13 --> URI Class Initialized
INFO - 2018-02-13 08:45:13 --> URI Class Initialized
INFO - 2018-02-13 08:45:13 --> Router Class Initialized
INFO - 2018-02-13 08:45:13 --> Router Class Initialized
INFO - 2018-02-13 08:45:13 --> Output Class Initialized
INFO - 2018-02-13 08:45:13 --> Output Class Initialized
INFO - 2018-02-13 08:45:13 --> Security Class Initialized
INFO - 2018-02-13 08:45:13 --> Security Class Initialized
DEBUG - 2018-02-13 08:45:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 08:45:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:45:13 --> Input Class Initialized
INFO - 2018-02-13 08:45:13 --> Input Class Initialized
INFO - 2018-02-13 08:45:13 --> Language Class Initialized
INFO - 2018-02-13 08:45:13 --> Language Class Initialized
INFO - 2018-02-13 08:45:13 --> Loader Class Initialized
INFO - 2018-02-13 08:45:13 --> Loader Class Initialized
INFO - 2018-02-13 08:45:13 --> Helper loaded: url_helper
INFO - 2018-02-13 08:45:13 --> Helper loaded: url_helper
INFO - 2018-02-13 08:45:13 --> Helper loaded: form_helper
INFO - 2018-02-13 08:45:13 --> Helper loaded: form_helper
INFO - 2018-02-13 08:45:13 --> Database Driver Class Initialized
INFO - 2018-02-13 08:45:13 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:45:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:45:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:45:13 --> Form Validation Class Initialized
INFO - 2018-02-13 08:45:13 --> Model Class Initialized
INFO - 2018-02-13 08:45:13 --> Controller Class Initialized
INFO - 2018-02-13 08:45:13 --> Model Class Initialized
INFO - 2018-02-13 08:45:13 --> Model Class Initialized
INFO - 2018-02-13 08:45:13 --> Model Class Initialized
DEBUG - 2018-02-13 08:45:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:45:13 --> Model Class Initialized
INFO - 2018-02-13 08:45:13 --> Model Class Initialized
DEBUG - 2018-02-13 08:45:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:45:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:45:13 --> Form Validation Class Initialized
INFO - 2018-02-13 08:45:13 --> Model Class Initialized
INFO - 2018-02-13 08:45:13 --> Controller Class Initialized
INFO - 2018-02-13 08:45:13 --> Model Class Initialized
INFO - 2018-02-13 08:45:13 --> Model Class Initialized
INFO - 2018-02-13 08:45:13 --> Model Class Initialized
INFO - 2018-02-13 08:45:13 --> Model Class Initialized
INFO - 2018-02-13 08:45:13 --> Model Class Initialized
DEBUG - 2018-02-13 08:45:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:47:37 --> Config Class Initialized
INFO - 2018-02-13 08:47:37 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:47:37 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:47:37 --> Utf8 Class Initialized
INFO - 2018-02-13 08:47:37 --> URI Class Initialized
INFO - 2018-02-13 08:47:37 --> Router Class Initialized
INFO - 2018-02-13 08:47:37 --> Output Class Initialized
INFO - 2018-02-13 08:47:37 --> Security Class Initialized
DEBUG - 2018-02-13 08:47:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:47:37 --> Input Class Initialized
INFO - 2018-02-13 08:47:37 --> Language Class Initialized
INFO - 2018-02-13 08:47:37 --> Loader Class Initialized
INFO - 2018-02-13 08:47:37 --> Helper loaded: url_helper
INFO - 2018-02-13 08:47:37 --> Helper loaded: form_helper
INFO - 2018-02-13 08:47:37 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:47:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:47:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:47:37 --> Form Validation Class Initialized
INFO - 2018-02-13 08:47:37 --> Model Class Initialized
INFO - 2018-02-13 08:47:37 --> Controller Class Initialized
INFO - 2018-02-13 08:47:37 --> Model Class Initialized
INFO - 2018-02-13 08:47:37 --> Model Class Initialized
INFO - 2018-02-13 08:47:37 --> Model Class Initialized
INFO - 2018-02-13 08:47:37 --> Model Class Initialized
INFO - 2018-02-13 08:47:37 --> Model Class Initialized
DEBUG - 2018-02-13 08:47:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:47:38 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 08:47:38 --> Final output sent to browser
DEBUG - 2018-02-13 08:47:38 --> Total execution time: 0.0542
INFO - 2018-02-13 08:47:38 --> Config Class Initialized
INFO - 2018-02-13 08:47:38 --> Hooks Class Initialized
INFO - 2018-02-13 08:47:38 --> Config Class Initialized
INFO - 2018-02-13 08:47:38 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:47:38 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:47:38 --> Utf8 Class Initialized
DEBUG - 2018-02-13 08:47:38 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:47:38 --> Utf8 Class Initialized
INFO - 2018-02-13 08:47:38 --> URI Class Initialized
INFO - 2018-02-13 08:47:38 --> URI Class Initialized
INFO - 2018-02-13 08:47:38 --> Router Class Initialized
INFO - 2018-02-13 08:47:38 --> Router Class Initialized
INFO - 2018-02-13 08:47:38 --> Output Class Initialized
INFO - 2018-02-13 08:47:38 --> Output Class Initialized
INFO - 2018-02-13 08:47:38 --> Security Class Initialized
INFO - 2018-02-13 08:47:38 --> Security Class Initialized
DEBUG - 2018-02-13 08:47:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 08:47:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:47:38 --> Input Class Initialized
INFO - 2018-02-13 08:47:38 --> Input Class Initialized
INFO - 2018-02-13 08:47:38 --> Language Class Initialized
INFO - 2018-02-13 08:47:38 --> Language Class Initialized
INFO - 2018-02-13 08:47:38 --> Loader Class Initialized
INFO - 2018-02-13 08:47:38 --> Loader Class Initialized
INFO - 2018-02-13 08:47:38 --> Helper loaded: url_helper
INFO - 2018-02-13 08:47:38 --> Helper loaded: url_helper
INFO - 2018-02-13 08:47:38 --> Helper loaded: form_helper
INFO - 2018-02-13 08:47:38 --> Helper loaded: form_helper
INFO - 2018-02-13 08:47:38 --> Database Driver Class Initialized
INFO - 2018-02-13 08:47:38 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:47:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 08:47:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:47:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:47:38 --> Form Validation Class Initialized
INFO - 2018-02-13 08:47:38 --> Model Class Initialized
INFO - 2018-02-13 08:47:38 --> Controller Class Initialized
INFO - 2018-02-13 08:47:38 --> Model Class Initialized
INFO - 2018-02-13 08:47:38 --> Model Class Initialized
INFO - 2018-02-13 08:47:38 --> Model Class Initialized
INFO - 2018-02-13 08:47:38 --> Model Class Initialized
INFO - 2018-02-13 08:47:38 --> Model Class Initialized
DEBUG - 2018-02-13 08:47:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:47:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:47:38 --> Form Validation Class Initialized
INFO - 2018-02-13 08:47:38 --> Model Class Initialized
INFO - 2018-02-13 08:47:38 --> Controller Class Initialized
INFO - 2018-02-13 08:47:38 --> Model Class Initialized
INFO - 2018-02-13 08:47:38 --> Model Class Initialized
INFO - 2018-02-13 08:47:38 --> Model Class Initialized
INFO - 2018-02-13 08:47:38 --> Model Class Initialized
INFO - 2018-02-13 08:47:38 --> Model Class Initialized
DEBUG - 2018-02-13 08:47:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:47:43 --> Config Class Initialized
INFO - 2018-02-13 08:47:43 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:47:43 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:47:43 --> Utf8 Class Initialized
INFO - 2018-02-13 08:47:43 --> URI Class Initialized
INFO - 2018-02-13 08:47:43 --> Router Class Initialized
INFO - 2018-02-13 08:47:43 --> Output Class Initialized
INFO - 2018-02-13 08:47:43 --> Security Class Initialized
DEBUG - 2018-02-13 08:47:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:47:43 --> Input Class Initialized
INFO - 2018-02-13 08:47:43 --> Language Class Initialized
INFO - 2018-02-13 08:47:43 --> Loader Class Initialized
INFO - 2018-02-13 08:47:43 --> Helper loaded: url_helper
INFO - 2018-02-13 08:47:43 --> Helper loaded: form_helper
INFO - 2018-02-13 08:47:43 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:47:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:47:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:47:43 --> Form Validation Class Initialized
INFO - 2018-02-13 08:47:43 --> Model Class Initialized
INFO - 2018-02-13 08:47:43 --> Controller Class Initialized
INFO - 2018-02-13 08:47:43 --> Model Class Initialized
INFO - 2018-02-13 08:47:43 --> Model Class Initialized
INFO - 2018-02-13 08:47:43 --> Model Class Initialized
INFO - 2018-02-13 08:47:43 --> Model Class Initialized
INFO - 2018-02-13 08:47:43 --> Model Class Initialized
DEBUG - 2018-02-13 08:47:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:47:43 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 08:47:43 --> Final output sent to browser
DEBUG - 2018-02-13 08:47:43 --> Total execution time: 0.2890
INFO - 2018-02-13 08:47:44 --> Config Class Initialized
INFO - 2018-02-13 08:47:44 --> Hooks Class Initialized
INFO - 2018-02-13 08:47:44 --> Config Class Initialized
INFO - 2018-02-13 08:47:44 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:47:44 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:47:44 --> Utf8 Class Initialized
DEBUG - 2018-02-13 08:47:44 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:47:44 --> Utf8 Class Initialized
INFO - 2018-02-13 08:47:44 --> URI Class Initialized
INFO - 2018-02-13 08:47:44 --> URI Class Initialized
INFO - 2018-02-13 08:47:44 --> Router Class Initialized
INFO - 2018-02-13 08:47:44 --> Router Class Initialized
INFO - 2018-02-13 08:47:44 --> Output Class Initialized
INFO - 2018-02-13 08:47:44 --> Security Class Initialized
INFO - 2018-02-13 08:47:44 --> Output Class Initialized
DEBUG - 2018-02-13 08:47:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:47:44 --> Input Class Initialized
INFO - 2018-02-13 08:47:44 --> Security Class Initialized
INFO - 2018-02-13 08:47:44 --> Language Class Initialized
DEBUG - 2018-02-13 08:47:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:47:44 --> Input Class Initialized
INFO - 2018-02-13 08:47:44 --> Language Class Initialized
INFO - 2018-02-13 08:47:44 --> Loader Class Initialized
INFO - 2018-02-13 08:47:44 --> Helper loaded: url_helper
INFO - 2018-02-13 08:47:44 --> Loader Class Initialized
INFO - 2018-02-13 08:47:44 --> Helper loaded: form_helper
INFO - 2018-02-13 08:47:44 --> Helper loaded: url_helper
INFO - 2018-02-13 08:47:44 --> Helper loaded: form_helper
INFO - 2018-02-13 08:47:44 --> Database Driver Class Initialized
INFO - 2018-02-13 08:47:44 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:47:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:47:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-02-13 08:47:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:47:44 --> Form Validation Class Initialized
INFO - 2018-02-13 08:47:44 --> Model Class Initialized
INFO - 2018-02-13 08:47:44 --> Controller Class Initialized
INFO - 2018-02-13 08:47:44 --> Model Class Initialized
INFO - 2018-02-13 08:47:44 --> Model Class Initialized
INFO - 2018-02-13 08:47:44 --> Model Class Initialized
INFO - 2018-02-13 08:47:44 --> Model Class Initialized
INFO - 2018-02-13 08:47:44 --> Model Class Initialized
DEBUG - 2018-02-13 08:47:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:47:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:47:44 --> Form Validation Class Initialized
INFO - 2018-02-13 08:47:44 --> Model Class Initialized
INFO - 2018-02-13 08:47:44 --> Controller Class Initialized
INFO - 2018-02-13 08:47:44 --> Model Class Initialized
INFO - 2018-02-13 08:47:44 --> Model Class Initialized
INFO - 2018-02-13 08:47:44 --> Model Class Initialized
INFO - 2018-02-13 08:47:44 --> Model Class Initialized
INFO - 2018-02-13 08:47:44 --> Model Class Initialized
DEBUG - 2018-02-13 08:47:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:51:10 --> Config Class Initialized
INFO - 2018-02-13 08:51:10 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:51:10 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:51:10 --> Utf8 Class Initialized
INFO - 2018-02-13 08:51:10 --> URI Class Initialized
INFO - 2018-02-13 08:51:10 --> Router Class Initialized
INFO - 2018-02-13 08:51:10 --> Output Class Initialized
INFO - 2018-02-13 08:51:10 --> Security Class Initialized
DEBUG - 2018-02-13 08:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:51:10 --> Input Class Initialized
INFO - 2018-02-13 08:51:10 --> Language Class Initialized
INFO - 2018-02-13 08:51:10 --> Loader Class Initialized
INFO - 2018-02-13 08:51:10 --> Helper loaded: url_helper
INFO - 2018-02-13 08:51:10 --> Helper loaded: form_helper
INFO - 2018-02-13 08:51:10 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:51:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:51:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:51:10 --> Form Validation Class Initialized
INFO - 2018-02-13 08:51:10 --> Model Class Initialized
INFO - 2018-02-13 08:51:10 --> Controller Class Initialized
INFO - 2018-02-13 08:51:10 --> Model Class Initialized
INFO - 2018-02-13 08:51:10 --> Model Class Initialized
INFO - 2018-02-13 08:51:10 --> Model Class Initialized
INFO - 2018-02-13 08:51:10 --> Model Class Initialized
INFO - 2018-02-13 08:51:10 --> Model Class Initialized
DEBUG - 2018-02-13 08:51:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:51:10 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 08:51:10 --> Final output sent to browser
DEBUG - 2018-02-13 08:51:10 --> Total execution time: 0.0470
INFO - 2018-02-13 08:51:10 --> Config Class Initialized
INFO - 2018-02-13 08:51:10 --> Hooks Class Initialized
INFO - 2018-02-13 08:51:10 --> Config Class Initialized
INFO - 2018-02-13 08:51:10 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:51:10 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:51:10 --> Utf8 Class Initialized
INFO - 2018-02-13 08:51:10 --> URI Class Initialized
DEBUG - 2018-02-13 08:51:10 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:51:10 --> Utf8 Class Initialized
INFO - 2018-02-13 08:51:10 --> Router Class Initialized
INFO - 2018-02-13 08:51:10 --> URI Class Initialized
INFO - 2018-02-13 08:51:10 --> Output Class Initialized
INFO - 2018-02-13 08:51:10 --> Router Class Initialized
INFO - 2018-02-13 08:51:10 --> Security Class Initialized
DEBUG - 2018-02-13 08:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:51:10 --> Input Class Initialized
INFO - 2018-02-13 08:51:10 --> Output Class Initialized
INFO - 2018-02-13 08:51:10 --> Language Class Initialized
INFO - 2018-02-13 08:51:10 --> Security Class Initialized
DEBUG - 2018-02-13 08:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:51:10 --> Input Class Initialized
INFO - 2018-02-13 08:51:10 --> Loader Class Initialized
INFO - 2018-02-13 08:51:10 --> Language Class Initialized
INFO - 2018-02-13 08:51:10 --> Helper loaded: url_helper
INFO - 2018-02-13 08:51:10 --> Loader Class Initialized
INFO - 2018-02-13 08:51:10 --> Helper loaded: form_helper
INFO - 2018-02-13 08:51:10 --> Helper loaded: url_helper
INFO - 2018-02-13 08:51:10 --> Helper loaded: form_helper
INFO - 2018-02-13 08:51:10 --> Database Driver Class Initialized
INFO - 2018-02-13 08:51:10 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:51:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 08:51:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:51:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:51:10 --> Form Validation Class Initialized
INFO - 2018-02-13 08:51:10 --> Model Class Initialized
INFO - 2018-02-13 08:51:10 --> Controller Class Initialized
INFO - 2018-02-13 08:51:10 --> Model Class Initialized
INFO - 2018-02-13 08:51:10 --> Model Class Initialized
INFO - 2018-02-13 08:51:10 --> Model Class Initialized
INFO - 2018-02-13 08:51:10 --> Model Class Initialized
INFO - 2018-02-13 08:51:10 --> Model Class Initialized
DEBUG - 2018-02-13 08:51:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:51:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:51:10 --> Form Validation Class Initialized
INFO - 2018-02-13 08:51:10 --> Model Class Initialized
INFO - 2018-02-13 08:51:10 --> Controller Class Initialized
INFO - 2018-02-13 08:51:10 --> Model Class Initialized
INFO - 2018-02-13 08:51:10 --> Model Class Initialized
INFO - 2018-02-13 08:51:10 --> Model Class Initialized
INFO - 2018-02-13 08:51:10 --> Model Class Initialized
INFO - 2018-02-13 08:51:10 --> Model Class Initialized
DEBUG - 2018-02-13 08:51:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:51:13 --> Config Class Initialized
INFO - 2018-02-13 08:51:13 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:51:13 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:51:13 --> Utf8 Class Initialized
INFO - 2018-02-13 08:51:13 --> URI Class Initialized
INFO - 2018-02-13 08:51:13 --> Router Class Initialized
INFO - 2018-02-13 08:51:13 --> Output Class Initialized
INFO - 2018-02-13 08:51:13 --> Security Class Initialized
DEBUG - 2018-02-13 08:51:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:51:13 --> Input Class Initialized
INFO - 2018-02-13 08:51:13 --> Language Class Initialized
INFO - 2018-02-13 08:51:13 --> Loader Class Initialized
INFO - 2018-02-13 08:51:13 --> Helper loaded: url_helper
INFO - 2018-02-13 08:51:13 --> Helper loaded: form_helper
INFO - 2018-02-13 08:51:13 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:51:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:51:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:51:13 --> Form Validation Class Initialized
INFO - 2018-02-13 08:51:13 --> Model Class Initialized
INFO - 2018-02-13 08:51:13 --> Controller Class Initialized
INFO - 2018-02-13 08:51:13 --> Model Class Initialized
INFO - 2018-02-13 08:51:13 --> Model Class Initialized
INFO - 2018-02-13 08:51:13 --> Model Class Initialized
INFO - 2018-02-13 08:51:13 --> Model Class Initialized
INFO - 2018-02-13 08:51:13 --> Model Class Initialized
DEBUG - 2018-02-13 08:51:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:51:13 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 08:51:13 --> Final output sent to browser
DEBUG - 2018-02-13 08:51:13 --> Total execution time: 0.0576
INFO - 2018-02-13 08:51:13 --> Config Class Initialized
INFO - 2018-02-13 08:51:13 --> Hooks Class Initialized
INFO - 2018-02-13 08:51:13 --> Config Class Initialized
INFO - 2018-02-13 08:51:13 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:51:13 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 08:51:13 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:51:13 --> Utf8 Class Initialized
INFO - 2018-02-13 08:51:13 --> Utf8 Class Initialized
INFO - 2018-02-13 08:51:13 --> URI Class Initialized
INFO - 2018-02-13 08:51:13 --> URI Class Initialized
INFO - 2018-02-13 08:51:13 --> Router Class Initialized
INFO - 2018-02-13 08:51:13 --> Router Class Initialized
INFO - 2018-02-13 08:51:13 --> Output Class Initialized
INFO - 2018-02-13 08:51:13 --> Output Class Initialized
INFO - 2018-02-13 08:51:13 --> Security Class Initialized
INFO - 2018-02-13 08:51:13 --> Security Class Initialized
DEBUG - 2018-02-13 08:51:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 08:51:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:51:13 --> Input Class Initialized
INFO - 2018-02-13 08:51:13 --> Input Class Initialized
INFO - 2018-02-13 08:51:13 --> Language Class Initialized
INFO - 2018-02-13 08:51:13 --> Language Class Initialized
INFO - 2018-02-13 08:51:13 --> Loader Class Initialized
INFO - 2018-02-13 08:51:13 --> Helper loaded: url_helper
INFO - 2018-02-13 08:51:13 --> Loader Class Initialized
INFO - 2018-02-13 08:51:13 --> Helper loaded: form_helper
INFO - 2018-02-13 08:51:13 --> Helper loaded: url_helper
INFO - 2018-02-13 08:51:13 --> Helper loaded: form_helper
INFO - 2018-02-13 08:51:13 --> Database Driver Class Initialized
INFO - 2018-02-13 08:51:13 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:51:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:51:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-02-13 08:51:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:51:13 --> Form Validation Class Initialized
INFO - 2018-02-13 08:51:13 --> Model Class Initialized
INFO - 2018-02-13 08:51:13 --> Controller Class Initialized
INFO - 2018-02-13 08:51:13 --> Model Class Initialized
INFO - 2018-02-13 08:51:13 --> Model Class Initialized
INFO - 2018-02-13 08:51:13 --> Model Class Initialized
INFO - 2018-02-13 08:51:13 --> Model Class Initialized
INFO - 2018-02-13 08:51:13 --> Model Class Initialized
DEBUG - 2018-02-13 08:51:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:51:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:51:13 --> Form Validation Class Initialized
INFO - 2018-02-13 08:51:13 --> Model Class Initialized
INFO - 2018-02-13 08:51:13 --> Controller Class Initialized
INFO - 2018-02-13 08:51:13 --> Model Class Initialized
INFO - 2018-02-13 08:51:13 --> Model Class Initialized
INFO - 2018-02-13 08:51:13 --> Model Class Initialized
INFO - 2018-02-13 08:51:13 --> Model Class Initialized
INFO - 2018-02-13 08:51:13 --> Model Class Initialized
DEBUG - 2018-02-13 08:51:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:51:15 --> Config Class Initialized
INFO - 2018-02-13 08:51:15 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:51:15 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:51:15 --> Utf8 Class Initialized
INFO - 2018-02-13 08:51:15 --> URI Class Initialized
INFO - 2018-02-13 08:51:15 --> Router Class Initialized
INFO - 2018-02-13 08:51:15 --> Output Class Initialized
INFO - 2018-02-13 08:51:15 --> Security Class Initialized
DEBUG - 2018-02-13 08:51:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:51:15 --> Input Class Initialized
INFO - 2018-02-13 08:51:15 --> Language Class Initialized
INFO - 2018-02-13 08:51:15 --> Loader Class Initialized
INFO - 2018-02-13 08:51:15 --> Helper loaded: url_helper
INFO - 2018-02-13 08:51:15 --> Helper loaded: form_helper
INFO - 2018-02-13 08:51:15 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:51:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:51:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:51:15 --> Form Validation Class Initialized
INFO - 2018-02-13 08:51:15 --> Model Class Initialized
INFO - 2018-02-13 08:51:15 --> Controller Class Initialized
INFO - 2018-02-13 08:51:15 --> Model Class Initialized
INFO - 2018-02-13 08:51:15 --> Model Class Initialized
INFO - 2018-02-13 08:51:15 --> Model Class Initialized
INFO - 2018-02-13 08:51:15 --> Model Class Initialized
INFO - 2018-02-13 08:51:15 --> Model Class Initialized
DEBUG - 2018-02-13 08:51:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:51:15 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 08:51:15 --> Final output sent to browser
DEBUG - 2018-02-13 08:51:15 --> Total execution time: 0.0557
INFO - 2018-02-13 08:51:15 --> Config Class Initialized
INFO - 2018-02-13 08:51:15 --> Hooks Class Initialized
INFO - 2018-02-13 08:51:15 --> Config Class Initialized
INFO - 2018-02-13 08:51:15 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:51:15 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:51:15 --> Utf8 Class Initialized
DEBUG - 2018-02-13 08:51:15 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:51:15 --> Utf8 Class Initialized
INFO - 2018-02-13 08:51:15 --> URI Class Initialized
INFO - 2018-02-13 08:51:15 --> URI Class Initialized
INFO - 2018-02-13 08:51:15 --> Router Class Initialized
INFO - 2018-02-13 08:51:15 --> Router Class Initialized
INFO - 2018-02-13 08:51:15 --> Output Class Initialized
INFO - 2018-02-13 08:51:15 --> Output Class Initialized
INFO - 2018-02-13 08:51:15 --> Security Class Initialized
INFO - 2018-02-13 08:51:15 --> Security Class Initialized
DEBUG - 2018-02-13 08:51:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 08:51:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:51:15 --> Input Class Initialized
INFO - 2018-02-13 08:51:15 --> Input Class Initialized
INFO - 2018-02-13 08:51:15 --> Language Class Initialized
INFO - 2018-02-13 08:51:15 --> Language Class Initialized
INFO - 2018-02-13 08:51:15 --> Loader Class Initialized
INFO - 2018-02-13 08:51:15 --> Loader Class Initialized
INFO - 2018-02-13 08:51:15 --> Helper loaded: url_helper
INFO - 2018-02-13 08:51:15 --> Helper loaded: url_helper
INFO - 2018-02-13 08:51:15 --> Helper loaded: form_helper
INFO - 2018-02-13 08:51:15 --> Helper loaded: form_helper
INFO - 2018-02-13 08:51:15 --> Database Driver Class Initialized
INFO - 2018-02-13 08:51:15 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:51:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 08:51:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:51:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:51:15 --> Form Validation Class Initialized
INFO - 2018-02-13 08:51:15 --> Model Class Initialized
INFO - 2018-02-13 08:51:15 --> Controller Class Initialized
INFO - 2018-02-13 08:51:15 --> Model Class Initialized
INFO - 2018-02-13 08:51:15 --> Model Class Initialized
INFO - 2018-02-13 08:51:15 --> Model Class Initialized
INFO - 2018-02-13 08:51:15 --> Model Class Initialized
INFO - 2018-02-13 08:51:15 --> Model Class Initialized
DEBUG - 2018-02-13 08:51:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:51:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:51:15 --> Form Validation Class Initialized
INFO - 2018-02-13 08:51:15 --> Model Class Initialized
INFO - 2018-02-13 08:51:15 --> Controller Class Initialized
INFO - 2018-02-13 08:51:15 --> Model Class Initialized
INFO - 2018-02-13 08:51:15 --> Model Class Initialized
INFO - 2018-02-13 08:51:15 --> Model Class Initialized
INFO - 2018-02-13 08:51:15 --> Model Class Initialized
INFO - 2018-02-13 08:51:15 --> Model Class Initialized
DEBUG - 2018-02-13 08:51:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:51:22 --> Config Class Initialized
INFO - 2018-02-13 08:51:22 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:51:22 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:51:22 --> Utf8 Class Initialized
INFO - 2018-02-13 08:51:22 --> URI Class Initialized
INFO - 2018-02-13 08:51:22 --> Router Class Initialized
INFO - 2018-02-13 08:51:22 --> Output Class Initialized
INFO - 2018-02-13 08:51:22 --> Security Class Initialized
DEBUG - 2018-02-13 08:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:51:22 --> Input Class Initialized
INFO - 2018-02-13 08:51:22 --> Language Class Initialized
INFO - 2018-02-13 08:51:22 --> Loader Class Initialized
INFO - 2018-02-13 08:51:22 --> Helper loaded: url_helper
INFO - 2018-02-13 08:51:22 --> Helper loaded: form_helper
INFO - 2018-02-13 08:51:22 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:51:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:51:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:51:22 --> Form Validation Class Initialized
INFO - 2018-02-13 08:51:22 --> Model Class Initialized
INFO - 2018-02-13 08:51:22 --> Controller Class Initialized
INFO - 2018-02-13 08:51:22 --> Model Class Initialized
INFO - 2018-02-13 08:51:22 --> Model Class Initialized
INFO - 2018-02-13 08:51:22 --> Model Class Initialized
INFO - 2018-02-13 08:51:22 --> Model Class Initialized
INFO - 2018-02-13 08:51:22 --> Model Class Initialized
DEBUG - 2018-02-13 08:51:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:51:22 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 08:51:22 --> Final output sent to browser
DEBUG - 2018-02-13 08:51:22 --> Total execution time: 0.3154
INFO - 2018-02-13 08:51:22 --> Config Class Initialized
INFO - 2018-02-13 08:51:22 --> Hooks Class Initialized
INFO - 2018-02-13 08:51:22 --> Config Class Initialized
INFO - 2018-02-13 08:51:22 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:51:22 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:51:22 --> Utf8 Class Initialized
INFO - 2018-02-13 08:51:22 --> URI Class Initialized
DEBUG - 2018-02-13 08:51:22 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:51:22 --> Utf8 Class Initialized
INFO - 2018-02-13 08:51:22 --> Router Class Initialized
INFO - 2018-02-13 08:51:22 --> URI Class Initialized
INFO - 2018-02-13 08:51:22 --> Output Class Initialized
INFO - 2018-02-13 08:51:22 --> Router Class Initialized
INFO - 2018-02-13 08:51:22 --> Security Class Initialized
INFO - 2018-02-13 08:51:22 --> Output Class Initialized
DEBUG - 2018-02-13 08:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:51:22 --> Input Class Initialized
INFO - 2018-02-13 08:51:22 --> Security Class Initialized
INFO - 2018-02-13 08:51:22 --> Language Class Initialized
DEBUG - 2018-02-13 08:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:51:22 --> Input Class Initialized
INFO - 2018-02-13 08:51:22 --> Language Class Initialized
INFO - 2018-02-13 08:51:22 --> Loader Class Initialized
INFO - 2018-02-13 08:51:22 --> Loader Class Initialized
INFO - 2018-02-13 08:51:22 --> Helper loaded: url_helper
INFO - 2018-02-13 08:51:22 --> Helper loaded: url_helper
INFO - 2018-02-13 08:51:22 --> Helper loaded: form_helper
INFO - 2018-02-13 08:51:22 --> Helper loaded: form_helper
INFO - 2018-02-13 08:51:22 --> Database Driver Class Initialized
INFO - 2018-02-13 08:51:22 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:51:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:51:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-02-13 08:51:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:51:22 --> Form Validation Class Initialized
INFO - 2018-02-13 08:51:22 --> Model Class Initialized
INFO - 2018-02-13 08:51:22 --> Controller Class Initialized
INFO - 2018-02-13 08:51:22 --> Model Class Initialized
INFO - 2018-02-13 08:51:22 --> Model Class Initialized
INFO - 2018-02-13 08:51:22 --> Model Class Initialized
INFO - 2018-02-13 08:51:22 --> Model Class Initialized
INFO - 2018-02-13 08:51:22 --> Model Class Initialized
DEBUG - 2018-02-13 08:51:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:51:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:51:22 --> Form Validation Class Initialized
INFO - 2018-02-13 08:51:22 --> Model Class Initialized
INFO - 2018-02-13 08:51:22 --> Controller Class Initialized
INFO - 2018-02-13 08:51:22 --> Model Class Initialized
INFO - 2018-02-13 08:51:22 --> Model Class Initialized
INFO - 2018-02-13 08:51:22 --> Model Class Initialized
INFO - 2018-02-13 08:51:22 --> Model Class Initialized
INFO - 2018-02-13 08:51:22 --> Model Class Initialized
DEBUG - 2018-02-13 08:51:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:52:57 --> Config Class Initialized
INFO - 2018-02-13 08:52:57 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:52:57 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:52:57 --> Utf8 Class Initialized
INFO - 2018-02-13 08:52:57 --> URI Class Initialized
INFO - 2018-02-13 08:52:57 --> Router Class Initialized
INFO - 2018-02-13 08:52:57 --> Output Class Initialized
INFO - 2018-02-13 08:52:57 --> Security Class Initialized
DEBUG - 2018-02-13 08:52:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:52:57 --> Input Class Initialized
INFO - 2018-02-13 08:52:57 --> Language Class Initialized
INFO - 2018-02-13 08:52:57 --> Loader Class Initialized
INFO - 2018-02-13 08:52:57 --> Helper loaded: url_helper
INFO - 2018-02-13 08:52:57 --> Helper loaded: form_helper
INFO - 2018-02-13 08:52:57 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:52:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:52:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:52:57 --> Form Validation Class Initialized
INFO - 2018-02-13 08:52:57 --> Model Class Initialized
INFO - 2018-02-13 08:52:57 --> Controller Class Initialized
INFO - 2018-02-13 08:52:57 --> Model Class Initialized
INFO - 2018-02-13 08:52:57 --> Model Class Initialized
INFO - 2018-02-13 08:52:57 --> Model Class Initialized
INFO - 2018-02-13 08:52:57 --> Model Class Initialized
INFO - 2018-02-13 08:52:57 --> Model Class Initialized
DEBUG - 2018-02-13 08:52:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:52:57 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 08:52:57 --> Final output sent to browser
DEBUG - 2018-02-13 08:52:57 --> Total execution time: 0.0490
INFO - 2018-02-13 08:52:57 --> Config Class Initialized
INFO - 2018-02-13 08:52:57 --> Hooks Class Initialized
INFO - 2018-02-13 08:52:57 --> Config Class Initialized
INFO - 2018-02-13 08:52:57 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:52:57 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:52:57 --> Utf8 Class Initialized
DEBUG - 2018-02-13 08:52:57 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:52:57 --> Utf8 Class Initialized
INFO - 2018-02-13 08:52:57 --> URI Class Initialized
INFO - 2018-02-13 08:52:57 --> URI Class Initialized
INFO - 2018-02-13 08:52:57 --> Router Class Initialized
INFO - 2018-02-13 08:52:57 --> Output Class Initialized
INFO - 2018-02-13 08:52:57 --> Router Class Initialized
INFO - 2018-02-13 08:52:57 --> Security Class Initialized
INFO - 2018-02-13 08:52:57 --> Output Class Initialized
DEBUG - 2018-02-13 08:52:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:52:57 --> Input Class Initialized
INFO - 2018-02-13 08:52:57 --> Language Class Initialized
INFO - 2018-02-13 08:52:57 --> Security Class Initialized
DEBUG - 2018-02-13 08:52:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:52:57 --> Input Class Initialized
INFO - 2018-02-13 08:52:57 --> Language Class Initialized
INFO - 2018-02-13 08:52:57 --> Loader Class Initialized
INFO - 2018-02-13 08:52:57 --> Helper loaded: url_helper
INFO - 2018-02-13 08:52:57 --> Loader Class Initialized
INFO - 2018-02-13 08:52:57 --> Helper loaded: form_helper
INFO - 2018-02-13 08:52:57 --> Helper loaded: url_helper
INFO - 2018-02-13 08:52:57 --> Helper loaded: form_helper
INFO - 2018-02-13 08:52:57 --> Database Driver Class Initialized
INFO - 2018-02-13 08:52:57 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:52:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:52:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:52:57 --> Form Validation Class Initialized
INFO - 2018-02-13 08:52:57 --> Model Class Initialized
INFO - 2018-02-13 08:52:57 --> Controller Class Initialized
DEBUG - 2018-02-13 08:52:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:52:57 --> Model Class Initialized
INFO - 2018-02-13 08:52:57 --> Model Class Initialized
INFO - 2018-02-13 08:52:57 --> Model Class Initialized
INFO - 2018-02-13 08:52:57 --> Model Class Initialized
INFO - 2018-02-13 08:52:57 --> Model Class Initialized
DEBUG - 2018-02-13 08:52:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:52:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:52:57 --> Form Validation Class Initialized
INFO - 2018-02-13 08:52:57 --> Model Class Initialized
INFO - 2018-02-13 08:52:57 --> Controller Class Initialized
INFO - 2018-02-13 08:52:57 --> Model Class Initialized
INFO - 2018-02-13 08:52:57 --> Model Class Initialized
INFO - 2018-02-13 08:52:57 --> Model Class Initialized
INFO - 2018-02-13 08:52:57 --> Model Class Initialized
INFO - 2018-02-13 08:52:57 --> Model Class Initialized
DEBUG - 2018-02-13 08:52:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:53:03 --> Config Class Initialized
INFO - 2018-02-13 08:53:03 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:53:03 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:53:03 --> Utf8 Class Initialized
INFO - 2018-02-13 08:53:03 --> URI Class Initialized
INFO - 2018-02-13 08:53:03 --> Router Class Initialized
INFO - 2018-02-13 08:53:03 --> Output Class Initialized
INFO - 2018-02-13 08:53:03 --> Security Class Initialized
DEBUG - 2018-02-13 08:53:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:53:03 --> Input Class Initialized
INFO - 2018-02-13 08:53:03 --> Language Class Initialized
INFO - 2018-02-13 08:53:03 --> Loader Class Initialized
INFO - 2018-02-13 08:53:03 --> Helper loaded: url_helper
INFO - 2018-02-13 08:53:03 --> Helper loaded: form_helper
INFO - 2018-02-13 08:53:03 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:53:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:53:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:53:03 --> Form Validation Class Initialized
INFO - 2018-02-13 08:53:03 --> Model Class Initialized
INFO - 2018-02-13 08:53:03 --> Controller Class Initialized
INFO - 2018-02-13 08:53:03 --> Model Class Initialized
INFO - 2018-02-13 08:53:03 --> Model Class Initialized
INFO - 2018-02-13 08:53:03 --> Model Class Initialized
INFO - 2018-02-13 08:53:03 --> Model Class Initialized
INFO - 2018-02-13 08:53:03 --> Model Class Initialized
DEBUG - 2018-02-13 08:53:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:53:03 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 08:53:03 --> Final output sent to browser
DEBUG - 2018-02-13 08:53:03 --> Total execution time: 0.3249
INFO - 2018-02-13 08:53:03 --> Config Class Initialized
INFO - 2018-02-13 08:53:03 --> Hooks Class Initialized
INFO - 2018-02-13 08:53:03 --> Config Class Initialized
INFO - 2018-02-13 08:53:03 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:53:03 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:53:03 --> Utf8 Class Initialized
DEBUG - 2018-02-13 08:53:03 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:53:03 --> Utf8 Class Initialized
INFO - 2018-02-13 08:53:03 --> URI Class Initialized
INFO - 2018-02-13 08:53:03 --> URI Class Initialized
INFO - 2018-02-13 08:53:03 --> Router Class Initialized
INFO - 2018-02-13 08:53:03 --> Router Class Initialized
INFO - 2018-02-13 08:53:03 --> Output Class Initialized
INFO - 2018-02-13 08:53:03 --> Output Class Initialized
INFO - 2018-02-13 08:53:03 --> Security Class Initialized
INFO - 2018-02-13 08:53:03 --> Security Class Initialized
DEBUG - 2018-02-13 08:53:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:53:03 --> Input Class Initialized
DEBUG - 2018-02-13 08:53:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:53:03 --> Input Class Initialized
INFO - 2018-02-13 08:53:03 --> Language Class Initialized
INFO - 2018-02-13 08:53:03 --> Language Class Initialized
INFO - 2018-02-13 08:53:03 --> Loader Class Initialized
INFO - 2018-02-13 08:53:03 --> Loader Class Initialized
INFO - 2018-02-13 08:53:03 --> Helper loaded: url_helper
INFO - 2018-02-13 08:53:03 --> Helper loaded: url_helper
INFO - 2018-02-13 08:53:03 --> Helper loaded: form_helper
INFO - 2018-02-13 08:53:03 --> Helper loaded: form_helper
INFO - 2018-02-13 08:53:03 --> Database Driver Class Initialized
INFO - 2018-02-13 08:53:03 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:53:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:53:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:53:04 --> Form Validation Class Initialized
INFO - 2018-02-13 08:53:04 --> Model Class Initialized
INFO - 2018-02-13 08:53:04 --> Controller Class Initialized
INFO - 2018-02-13 08:53:04 --> Model Class Initialized
INFO - 2018-02-13 08:53:04 --> Model Class Initialized
INFO - 2018-02-13 08:53:04 --> Model Class Initialized
INFO - 2018-02-13 08:53:04 --> Model Class Initialized
INFO - 2018-02-13 08:53:04 --> Model Class Initialized
DEBUG - 2018-02-13 08:53:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-02-13 08:53:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:53:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:53:04 --> Form Validation Class Initialized
INFO - 2018-02-13 08:53:04 --> Model Class Initialized
INFO - 2018-02-13 08:53:04 --> Controller Class Initialized
INFO - 2018-02-13 08:53:04 --> Model Class Initialized
INFO - 2018-02-13 08:53:04 --> Model Class Initialized
INFO - 2018-02-13 08:53:04 --> Model Class Initialized
INFO - 2018-02-13 08:53:04 --> Model Class Initialized
INFO - 2018-02-13 08:53:04 --> Model Class Initialized
DEBUG - 2018-02-13 08:53:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:53:53 --> Config Class Initialized
INFO - 2018-02-13 08:53:53 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:53:53 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:53:53 --> Utf8 Class Initialized
INFO - 2018-02-13 08:53:53 --> URI Class Initialized
INFO - 2018-02-13 08:53:53 --> Router Class Initialized
INFO - 2018-02-13 08:53:53 --> Output Class Initialized
INFO - 2018-02-13 08:53:53 --> Security Class Initialized
DEBUG - 2018-02-13 08:53:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:53:53 --> Input Class Initialized
INFO - 2018-02-13 08:53:53 --> Language Class Initialized
INFO - 2018-02-13 08:53:53 --> Loader Class Initialized
INFO - 2018-02-13 08:53:53 --> Helper loaded: url_helper
INFO - 2018-02-13 08:53:53 --> Helper loaded: form_helper
INFO - 2018-02-13 08:53:53 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:53:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:53:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:53:53 --> Form Validation Class Initialized
INFO - 2018-02-13 08:53:53 --> Model Class Initialized
INFO - 2018-02-13 08:53:53 --> Controller Class Initialized
INFO - 2018-02-13 08:53:53 --> Model Class Initialized
INFO - 2018-02-13 08:53:53 --> Model Class Initialized
INFO - 2018-02-13 08:53:53 --> Model Class Initialized
INFO - 2018-02-13 08:53:53 --> Model Class Initialized
INFO - 2018-02-13 08:53:53 --> Model Class Initialized
DEBUG - 2018-02-13 08:53:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:53:53 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-13 08:53:53 --> Final output sent to browser
DEBUG - 2018-02-13 08:53:53 --> Total execution time: 0.0578
INFO - 2018-02-13 08:53:53 --> Config Class Initialized
INFO - 2018-02-13 08:53:53 --> Hooks Class Initialized
INFO - 2018-02-13 08:53:53 --> Config Class Initialized
INFO - 2018-02-13 08:53:53 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:53:53 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:53:53 --> Utf8 Class Initialized
DEBUG - 2018-02-13 08:53:53 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:53:53 --> Utf8 Class Initialized
INFO - 2018-02-13 08:53:53 --> URI Class Initialized
INFO - 2018-02-13 08:53:53 --> URI Class Initialized
INFO - 2018-02-13 08:53:53 --> Router Class Initialized
INFO - 2018-02-13 08:53:53 --> Router Class Initialized
INFO - 2018-02-13 08:53:53 --> Output Class Initialized
INFO - 2018-02-13 08:53:53 --> Output Class Initialized
INFO - 2018-02-13 08:53:53 --> Security Class Initialized
INFO - 2018-02-13 08:53:53 --> Security Class Initialized
DEBUG - 2018-02-13 08:53:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:53:53 --> Input Class Initialized
INFO - 2018-02-13 08:53:53 --> Language Class Initialized
DEBUG - 2018-02-13 08:53:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:53:53 --> Input Class Initialized
INFO - 2018-02-13 08:53:53 --> Language Class Initialized
INFO - 2018-02-13 08:53:53 --> Loader Class Initialized
INFO - 2018-02-13 08:53:53 --> Loader Class Initialized
INFO - 2018-02-13 08:53:53 --> Helper loaded: url_helper
INFO - 2018-02-13 08:53:53 --> Helper loaded: url_helper
INFO - 2018-02-13 08:53:53 --> Helper loaded: form_helper
INFO - 2018-02-13 08:53:53 --> Helper loaded: form_helper
INFO - 2018-02-13 08:53:53 --> Database Driver Class Initialized
INFO - 2018-02-13 08:53:53 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:53:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:53:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:53:53 --> Form Validation Class Initialized
INFO - 2018-02-13 08:53:53 --> Model Class Initialized
INFO - 2018-02-13 08:53:53 --> Controller Class Initialized
INFO - 2018-02-13 08:53:53 --> Model Class Initialized
INFO - 2018-02-13 08:53:53 --> Model Class Initialized
INFO - 2018-02-13 08:53:53 --> Model Class Initialized
DEBUG - 2018-02-13 08:53:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:53:53 --> Model Class Initialized
INFO - 2018-02-13 08:53:53 --> Model Class Initialized
DEBUG - 2018-02-13 08:53:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:53:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:53:53 --> Form Validation Class Initialized
INFO - 2018-02-13 08:53:53 --> Model Class Initialized
INFO - 2018-02-13 08:53:53 --> Controller Class Initialized
INFO - 2018-02-13 08:53:53 --> Model Class Initialized
INFO - 2018-02-13 08:53:53 --> Model Class Initialized
INFO - 2018-02-13 08:53:53 --> Model Class Initialized
INFO - 2018-02-13 08:53:53 --> Model Class Initialized
INFO - 2018-02-13 08:53:53 --> Model Class Initialized
DEBUG - 2018-02-13 08:53:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:53:59 --> Config Class Initialized
INFO - 2018-02-13 08:53:59 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:53:59 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:53:59 --> Utf8 Class Initialized
INFO - 2018-02-13 08:53:59 --> URI Class Initialized
INFO - 2018-02-13 08:53:59 --> Router Class Initialized
INFO - 2018-02-13 08:53:59 --> Output Class Initialized
INFO - 2018-02-13 08:53:59 --> Security Class Initialized
DEBUG - 2018-02-13 08:53:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:53:59 --> Input Class Initialized
INFO - 2018-02-13 08:53:59 --> Language Class Initialized
INFO - 2018-02-13 08:53:59 --> Loader Class Initialized
INFO - 2018-02-13 08:53:59 --> Helper loaded: url_helper
INFO - 2018-02-13 08:53:59 --> Helper loaded: form_helper
INFO - 2018-02-13 08:53:59 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:53:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:53:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:53:59 --> Form Validation Class Initialized
INFO - 2018-02-13 08:53:59 --> Model Class Initialized
INFO - 2018-02-13 08:53:59 --> Controller Class Initialized
INFO - 2018-02-13 08:53:59 --> Model Class Initialized
INFO - 2018-02-13 08:53:59 --> Model Class Initialized
INFO - 2018-02-13 08:53:59 --> Model Class Initialized
INFO - 2018-02-13 08:53:59 --> Model Class Initialized
INFO - 2018-02-13 08:53:59 --> Model Class Initialized
DEBUG - 2018-02-13 08:53:59 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-13 08:53:59 --> Severity: Notice --> Undefined variable: colaborador_id_viejo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1216
INFO - 2018-02-13 08:54:07 --> Config Class Initialized
INFO - 2018-02-13 08:54:07 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:54:07 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:54:07 --> Utf8 Class Initialized
INFO - 2018-02-13 08:54:07 --> URI Class Initialized
INFO - 2018-02-13 08:54:07 --> Router Class Initialized
INFO - 2018-02-13 08:54:07 --> Output Class Initialized
INFO - 2018-02-13 08:54:07 --> Security Class Initialized
DEBUG - 2018-02-13 08:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:54:07 --> Input Class Initialized
INFO - 2018-02-13 08:54:07 --> Language Class Initialized
INFO - 2018-02-13 08:54:07 --> Loader Class Initialized
INFO - 2018-02-13 08:54:07 --> Helper loaded: url_helper
INFO - 2018-02-13 08:54:07 --> Helper loaded: form_helper
INFO - 2018-02-13 08:54:07 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:54:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:54:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:54:07 --> Form Validation Class Initialized
INFO - 2018-02-13 08:54:07 --> Model Class Initialized
INFO - 2018-02-13 08:54:07 --> Controller Class Initialized
INFO - 2018-02-13 08:54:07 --> Model Class Initialized
INFO - 2018-02-13 08:54:07 --> Model Class Initialized
INFO - 2018-02-13 08:54:07 --> Model Class Initialized
INFO - 2018-02-13 08:54:07 --> Model Class Initialized
INFO - 2018-02-13 08:54:07 --> Model Class Initialized
DEBUG - 2018-02-13 08:54:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-13 08:54:39 --> Config Class Initialized
INFO - 2018-02-13 08:54:39 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:54:39 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:54:39 --> Utf8 Class Initialized
INFO - 2018-02-13 08:54:39 --> URI Class Initialized
INFO - 2018-02-13 08:54:39 --> Router Class Initialized
INFO - 2018-02-13 08:54:39 --> Output Class Initialized
INFO - 2018-02-13 08:54:39 --> Security Class Initialized
DEBUG - 2018-02-13 08:54:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:54:39 --> Input Class Initialized
INFO - 2018-02-13 08:54:39 --> Language Class Initialized
INFO - 2018-02-13 08:54:39 --> Loader Class Initialized
INFO - 2018-02-13 08:54:39 --> Helper loaded: url_helper
INFO - 2018-02-13 08:54:39 --> Helper loaded: form_helper
INFO - 2018-02-13 08:54:39 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:54:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 08:54:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 08:54:39 --> Form Validation Class Initialized
INFO - 2018-02-13 08:54:39 --> Model Class Initialized
INFO - 2018-02-13 08:54:39 --> Controller Class Initialized
INFO - 2018-02-13 08:54:39 --> Model Class Initialized
INFO - 2018-02-13 08:54:39 --> Model Class Initialized
INFO - 2018-02-13 08:54:39 --> Model Class Initialized
INFO - 2018-02-13 08:54:39 --> Model Class Initialized
INFO - 2018-02-13 08:54:39 --> Model Class Initialized
DEBUG - 2018-02-13 08:54:39 --> Form_validation class already loaded. Second attempt ignored.
