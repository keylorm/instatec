<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-01-26 04:47:59 --> Config Class Initialized
INFO - 2018-01-26 04:47:59 --> Hooks Class Initialized
DEBUG - 2018-01-26 04:47:59 --> UTF-8 Support Enabled
INFO - 2018-01-26 04:47:59 --> Utf8 Class Initialized
INFO - 2018-01-26 04:47:59 --> URI Class Initialized
INFO - 2018-01-26 04:47:59 --> Router Class Initialized
INFO - 2018-01-26 04:47:59 --> Output Class Initialized
INFO - 2018-01-26 04:47:59 --> Security Class Initialized
DEBUG - 2018-01-26 04:47:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-26 04:47:59 --> Input Class Initialized
INFO - 2018-01-26 04:47:59 --> Language Class Initialized
INFO - 2018-01-26 04:47:59 --> Loader Class Initialized
INFO - 2018-01-26 04:47:59 --> Helper loaded: url_helper
INFO - 2018-01-26 04:47:59 --> Helper loaded: form_helper
INFO - 2018-01-26 04:47:59 --> Database Driver Class Initialized
DEBUG - 2018-01-26 04:47:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-26 04:47:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-26 04:47:59 --> Form Validation Class Initialized
INFO - 2018-01-26 04:47:59 --> Model Class Initialized
INFO - 2018-01-26 04:47:59 --> Controller Class Initialized
INFO - 2018-01-26 04:47:59 --> Model Class Initialized
DEBUG - 2018-01-26 04:47:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-26 04:47:59 --> Config Class Initialized
INFO - 2018-01-26 04:47:59 --> Hooks Class Initialized
DEBUG - 2018-01-26 04:47:59 --> UTF-8 Support Enabled
INFO - 2018-01-26 04:47:59 --> Utf8 Class Initialized
INFO - 2018-01-26 04:47:59 --> URI Class Initialized
INFO - 2018-01-26 04:47:59 --> Router Class Initialized
INFO - 2018-01-26 04:47:59 --> Output Class Initialized
INFO - 2018-01-26 04:47:59 --> Security Class Initialized
DEBUG - 2018-01-26 04:47:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-26 04:47:59 --> Input Class Initialized
INFO - 2018-01-26 04:47:59 --> Language Class Initialized
INFO - 2018-01-26 04:47:59 --> Loader Class Initialized
INFO - 2018-01-26 04:47:59 --> Helper loaded: url_helper
INFO - 2018-01-26 04:47:59 --> Helper loaded: form_helper
INFO - 2018-01-26 04:47:59 --> Database Driver Class Initialized
DEBUG - 2018-01-26 04:47:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-26 04:47:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-26 04:47:59 --> Form Validation Class Initialized
INFO - 2018-01-26 04:47:59 --> Model Class Initialized
INFO - 2018-01-26 04:47:59 --> Controller Class Initialized
INFO - 2018-01-26 04:47:59 --> Model Class Initialized
DEBUG - 2018-01-26 04:47:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-26 04:47:59 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-26 04:47:59 --> Final output sent to browser
DEBUG - 2018-01-26 04:47:59 --> Total execution time: 0.2734
INFO - 2018-01-26 05:06:23 --> Config Class Initialized
INFO - 2018-01-26 05:06:23 --> Hooks Class Initialized
DEBUG - 2018-01-26 05:06:23 --> UTF-8 Support Enabled
INFO - 2018-01-26 05:06:23 --> Utf8 Class Initialized
INFO - 2018-01-26 05:06:23 --> URI Class Initialized
INFO - 2018-01-26 05:06:23 --> Router Class Initialized
INFO - 2018-01-26 05:06:23 --> Output Class Initialized
INFO - 2018-01-26 05:06:23 --> Security Class Initialized
DEBUG - 2018-01-26 05:06:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-26 05:06:23 --> Input Class Initialized
INFO - 2018-01-26 05:06:23 --> Language Class Initialized
INFO - 2018-01-26 05:06:23 --> Loader Class Initialized
INFO - 2018-01-26 05:06:23 --> Helper loaded: url_helper
INFO - 2018-01-26 05:06:23 --> Helper loaded: form_helper
INFO - 2018-01-26 05:06:23 --> Database Driver Class Initialized
DEBUG - 2018-01-26 05:06:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-26 05:06:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-26 05:06:23 --> Form Validation Class Initialized
INFO - 2018-01-26 05:06:23 --> Model Class Initialized
INFO - 2018-01-26 05:06:23 --> Controller Class Initialized
INFO - 2018-01-26 05:06:23 --> Model Class Initialized
DEBUG - 2018-01-26 05:06:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-26 05:06:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-01-26 05:06:26 --> Config Class Initialized
INFO - 2018-01-26 05:06:26 --> Hooks Class Initialized
DEBUG - 2018-01-26 05:06:26 --> UTF-8 Support Enabled
INFO - 2018-01-26 05:06:26 --> Utf8 Class Initialized
INFO - 2018-01-26 05:06:26 --> URI Class Initialized
DEBUG - 2018-01-26 05:06:26 --> No URI present. Default controller set.
INFO - 2018-01-26 05:06:26 --> Router Class Initialized
INFO - 2018-01-26 05:06:26 --> Output Class Initialized
INFO - 2018-01-26 05:06:26 --> Security Class Initialized
DEBUG - 2018-01-26 05:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-26 05:06:26 --> Input Class Initialized
INFO - 2018-01-26 05:06:26 --> Language Class Initialized
INFO - 2018-01-26 05:06:26 --> Loader Class Initialized
INFO - 2018-01-26 05:06:26 --> Helper loaded: url_helper
INFO - 2018-01-26 05:06:26 --> Helper loaded: form_helper
INFO - 2018-01-26 05:06:26 --> Database Driver Class Initialized
DEBUG - 2018-01-26 05:06:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-26 05:06:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-26 05:06:26 --> Form Validation Class Initialized
INFO - 2018-01-26 05:06:26 --> Model Class Initialized
INFO - 2018-01-26 05:06:26 --> Controller Class Initialized
INFO - 2018-01-26 05:06:26 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-26 05:06:26 --> Final output sent to browser
DEBUG - 2018-01-26 05:06:26 --> Total execution time: 0.1230
INFO - 2018-01-26 05:06:26 --> Config Class Initialized
INFO - 2018-01-26 05:06:26 --> Hooks Class Initialized
DEBUG - 2018-01-26 05:06:26 --> UTF-8 Support Enabled
INFO - 2018-01-26 05:06:26 --> Utf8 Class Initialized
INFO - 2018-01-26 05:06:26 --> URI Class Initialized
INFO - 2018-01-26 05:06:26 --> Router Class Initialized
INFO - 2018-01-26 05:06:26 --> Output Class Initialized
INFO - 2018-01-26 05:06:26 --> Security Class Initialized
DEBUG - 2018-01-26 05:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-26 05:06:26 --> Input Class Initialized
INFO - 2018-01-26 05:06:26 --> Language Class Initialized
INFO - 2018-01-26 05:06:26 --> Loader Class Initialized
INFO - 2018-01-26 05:06:27 --> Helper loaded: url_helper
INFO - 2018-01-26 05:06:27 --> Helper loaded: form_helper
INFO - 2018-01-26 05:06:27 --> Database Driver Class Initialized
DEBUG - 2018-01-26 05:06:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-26 05:06:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-26 05:06:27 --> Form Validation Class Initialized
INFO - 2018-01-26 05:06:27 --> Model Class Initialized
INFO - 2018-01-26 05:06:27 --> Controller Class Initialized
INFO - 2018-01-26 05:06:27 --> Model Class Initialized
INFO - 2018-01-26 05:06:27 --> Model Class Initialized
INFO - 2018-01-26 05:06:27 --> Model Class Initialized
INFO - 2018-01-26 05:06:27 --> Model Class Initialized
DEBUG - 2018-01-26 05:06:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-26 05:23:30 --> Config Class Initialized
INFO - 2018-01-26 05:23:30 --> Hooks Class Initialized
DEBUG - 2018-01-26 05:23:30 --> UTF-8 Support Enabled
INFO - 2018-01-26 05:23:30 --> Utf8 Class Initialized
INFO - 2018-01-26 05:23:30 --> URI Class Initialized
INFO - 2018-01-26 05:23:30 --> Router Class Initialized
INFO - 2018-01-26 05:23:30 --> Output Class Initialized
INFO - 2018-01-26 05:23:30 --> Security Class Initialized
DEBUG - 2018-01-26 05:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-26 05:23:30 --> Input Class Initialized
INFO - 2018-01-26 05:23:30 --> Language Class Initialized
INFO - 2018-01-26 05:23:30 --> Loader Class Initialized
INFO - 2018-01-26 05:23:30 --> Helper loaded: url_helper
INFO - 2018-01-26 05:23:30 --> Helper loaded: form_helper
INFO - 2018-01-26 05:23:30 --> Database Driver Class Initialized
DEBUG - 2018-01-26 05:23:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-26 05:23:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-26 05:23:30 --> Form Validation Class Initialized
INFO - 2018-01-26 05:23:30 --> Model Class Initialized
INFO - 2018-01-26 05:23:30 --> Controller Class Initialized
INFO - 2018-01-26 05:23:30 --> Model Class Initialized
DEBUG - 2018-01-26 05:23:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-26 05:23:30 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-26 05:23:30 --> Final output sent to browser
DEBUG - 2018-01-26 05:23:30 --> Total execution time: 0.0511
INFO - 2018-01-26 05:23:30 --> Config Class Initialized
INFO - 2018-01-26 05:23:30 --> Hooks Class Initialized
DEBUG - 2018-01-26 05:23:30 --> UTF-8 Support Enabled
INFO - 2018-01-26 05:23:30 --> Utf8 Class Initialized
INFO - 2018-01-26 05:23:30 --> URI Class Initialized
INFO - 2018-01-26 05:23:30 --> Router Class Initialized
INFO - 2018-01-26 05:23:30 --> Output Class Initialized
INFO - 2018-01-26 05:23:30 --> Security Class Initialized
DEBUG - 2018-01-26 05:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-26 05:23:30 --> Input Class Initialized
INFO - 2018-01-26 05:23:30 --> Language Class Initialized
INFO - 2018-01-26 05:23:30 --> Loader Class Initialized
INFO - 2018-01-26 05:23:30 --> Helper loaded: url_helper
INFO - 2018-01-26 05:23:30 --> Helper loaded: form_helper
INFO - 2018-01-26 05:23:30 --> Database Driver Class Initialized
DEBUG - 2018-01-26 05:23:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-26 05:23:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-26 05:23:30 --> Form Validation Class Initialized
INFO - 2018-01-26 05:23:30 --> Model Class Initialized
INFO - 2018-01-26 05:23:30 --> Controller Class Initialized
INFO - 2018-01-26 05:23:30 --> Model Class Initialized
DEBUG - 2018-01-26 05:23:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-26 05:23:33 --> Config Class Initialized
INFO - 2018-01-26 05:23:33 --> Hooks Class Initialized
DEBUG - 2018-01-26 05:23:33 --> UTF-8 Support Enabled
INFO - 2018-01-26 05:23:33 --> Utf8 Class Initialized
INFO - 2018-01-26 05:23:33 --> URI Class Initialized
INFO - 2018-01-26 05:23:33 --> Router Class Initialized
INFO - 2018-01-26 05:23:33 --> Output Class Initialized
INFO - 2018-01-26 05:23:33 --> Security Class Initialized
DEBUG - 2018-01-26 05:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-26 05:23:33 --> Input Class Initialized
INFO - 2018-01-26 05:23:33 --> Language Class Initialized
INFO - 2018-01-26 05:23:33 --> Loader Class Initialized
INFO - 2018-01-26 05:23:33 --> Helper loaded: url_helper
INFO - 2018-01-26 05:23:33 --> Helper loaded: form_helper
INFO - 2018-01-26 05:23:33 --> Database Driver Class Initialized
DEBUG - 2018-01-26 05:23:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-26 05:23:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-26 05:23:33 --> Form Validation Class Initialized
INFO - 2018-01-26 05:23:33 --> Model Class Initialized
INFO - 2018-01-26 05:23:33 --> Controller Class Initialized
INFO - 2018-01-26 05:23:33 --> Model Class Initialized
DEBUG - 2018-01-26 05:23:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-26 05:23:33 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-26 05:23:33 --> Final output sent to browser
DEBUG - 2018-01-26 05:23:33 --> Total execution time: 0.0509
INFO - 2018-01-26 05:23:38 --> Config Class Initialized
INFO - 2018-01-26 05:23:38 --> Hooks Class Initialized
DEBUG - 2018-01-26 05:23:38 --> UTF-8 Support Enabled
INFO - 2018-01-26 05:23:38 --> Utf8 Class Initialized
INFO - 2018-01-26 05:23:38 --> URI Class Initialized
INFO - 2018-01-26 05:23:38 --> Router Class Initialized
INFO - 2018-01-26 05:23:38 --> Output Class Initialized
INFO - 2018-01-26 05:23:38 --> Security Class Initialized
DEBUG - 2018-01-26 05:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-26 05:23:38 --> Input Class Initialized
INFO - 2018-01-26 05:23:38 --> Language Class Initialized
INFO - 2018-01-26 05:23:38 --> Loader Class Initialized
INFO - 2018-01-26 05:23:38 --> Helper loaded: url_helper
INFO - 2018-01-26 05:23:38 --> Helper loaded: form_helper
INFO - 2018-01-26 05:23:38 --> Database Driver Class Initialized
DEBUG - 2018-01-26 05:23:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-26 05:23:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-26 05:23:38 --> Form Validation Class Initialized
INFO - 2018-01-26 05:23:38 --> Model Class Initialized
INFO - 2018-01-26 05:23:38 --> Controller Class Initialized
INFO - 2018-01-26 05:23:38 --> Model Class Initialized
DEBUG - 2018-01-26 05:23:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-26 05:23:38 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-26 05:23:38 --> Final output sent to browser
DEBUG - 2018-01-26 05:23:38 --> Total execution time: 0.0575
INFO - 2018-01-26 05:23:38 --> Config Class Initialized
INFO - 2018-01-26 05:23:38 --> Hooks Class Initialized
DEBUG - 2018-01-26 05:23:38 --> UTF-8 Support Enabled
INFO - 2018-01-26 05:23:38 --> Utf8 Class Initialized
INFO - 2018-01-26 05:23:38 --> URI Class Initialized
INFO - 2018-01-26 05:23:38 --> Router Class Initialized
INFO - 2018-01-26 05:23:38 --> Output Class Initialized
INFO - 2018-01-26 05:23:38 --> Security Class Initialized
DEBUG - 2018-01-26 05:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-26 05:23:38 --> Input Class Initialized
INFO - 2018-01-26 05:23:38 --> Language Class Initialized
INFO - 2018-01-26 05:23:38 --> Loader Class Initialized
INFO - 2018-01-26 05:23:38 --> Helper loaded: url_helper
INFO - 2018-01-26 05:23:38 --> Helper loaded: form_helper
INFO - 2018-01-26 05:23:38 --> Database Driver Class Initialized
DEBUG - 2018-01-26 05:23:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-26 05:23:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-26 05:23:38 --> Form Validation Class Initialized
INFO - 2018-01-26 05:23:38 --> Model Class Initialized
INFO - 2018-01-26 05:23:38 --> Controller Class Initialized
INFO - 2018-01-26 05:23:38 --> Model Class Initialized
DEBUG - 2018-01-26 05:23:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-26 05:23:40 --> Config Class Initialized
INFO - 2018-01-26 05:23:40 --> Hooks Class Initialized
DEBUG - 2018-01-26 05:23:40 --> UTF-8 Support Enabled
INFO - 2018-01-26 05:23:40 --> Utf8 Class Initialized
INFO - 2018-01-26 05:23:40 --> URI Class Initialized
INFO - 2018-01-26 05:23:40 --> Router Class Initialized
INFO - 2018-01-26 05:23:40 --> Output Class Initialized
INFO - 2018-01-26 05:23:40 --> Security Class Initialized
DEBUG - 2018-01-26 05:23:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-26 05:23:40 --> Input Class Initialized
INFO - 2018-01-26 05:23:40 --> Language Class Initialized
INFO - 2018-01-26 05:23:40 --> Loader Class Initialized
INFO - 2018-01-26 05:23:40 --> Helper loaded: url_helper
INFO - 2018-01-26 05:23:40 --> Helper loaded: form_helper
INFO - 2018-01-26 05:23:40 --> Database Driver Class Initialized
DEBUG - 2018-01-26 05:23:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-26 05:23:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-26 05:23:40 --> Form Validation Class Initialized
INFO - 2018-01-26 05:23:40 --> Model Class Initialized
INFO - 2018-01-26 05:23:40 --> Controller Class Initialized
INFO - 2018-01-26 05:23:40 --> Model Class Initialized
DEBUG - 2018-01-26 05:23:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-26 05:23:40 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-26 05:23:40 --> Final output sent to browser
DEBUG - 2018-01-26 05:23:40 --> Total execution time: 0.0493
INFO - 2018-01-26 05:23:47 --> Config Class Initialized
INFO - 2018-01-26 05:23:47 --> Hooks Class Initialized
DEBUG - 2018-01-26 05:23:47 --> UTF-8 Support Enabled
INFO - 2018-01-26 05:23:47 --> Utf8 Class Initialized
INFO - 2018-01-26 05:23:47 --> URI Class Initialized
INFO - 2018-01-26 05:23:47 --> Router Class Initialized
INFO - 2018-01-26 05:23:47 --> Output Class Initialized
INFO - 2018-01-26 05:23:47 --> Security Class Initialized
DEBUG - 2018-01-26 05:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-26 05:23:47 --> Input Class Initialized
INFO - 2018-01-26 05:23:47 --> Language Class Initialized
INFO - 2018-01-26 05:23:47 --> Loader Class Initialized
INFO - 2018-01-26 05:23:47 --> Helper loaded: url_helper
INFO - 2018-01-26 05:23:47 --> Helper loaded: form_helper
INFO - 2018-01-26 05:23:47 --> Database Driver Class Initialized
DEBUG - 2018-01-26 05:23:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-26 05:23:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-26 05:23:47 --> Form Validation Class Initialized
INFO - 2018-01-26 05:23:47 --> Model Class Initialized
INFO - 2018-01-26 05:23:47 --> Controller Class Initialized
INFO - 2018-01-26 05:23:47 --> Model Class Initialized
DEBUG - 2018-01-26 05:23:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-26 05:23:47 --> Model Class Initialized
INFO - 2018-01-26 05:23:47 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-26 05:23:47 --> Final output sent to browser
DEBUG - 2018-01-26 05:23:47 --> Total execution time: 0.2318
INFO - 2018-01-26 05:23:51 --> Config Class Initialized
INFO - 2018-01-26 05:23:51 --> Hooks Class Initialized
DEBUG - 2018-01-26 05:23:51 --> UTF-8 Support Enabled
INFO - 2018-01-26 05:23:51 --> Utf8 Class Initialized
INFO - 2018-01-26 05:23:51 --> URI Class Initialized
INFO - 2018-01-26 05:23:51 --> Router Class Initialized
INFO - 2018-01-26 05:23:51 --> Output Class Initialized
INFO - 2018-01-26 05:23:51 --> Security Class Initialized
DEBUG - 2018-01-26 05:23:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-26 05:23:51 --> Input Class Initialized
INFO - 2018-01-26 05:23:51 --> Language Class Initialized
INFO - 2018-01-26 05:23:51 --> Loader Class Initialized
INFO - 2018-01-26 05:23:51 --> Helper loaded: url_helper
INFO - 2018-01-26 05:23:51 --> Helper loaded: form_helper
INFO - 2018-01-26 05:23:51 --> Database Driver Class Initialized
DEBUG - 2018-01-26 05:23:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-26 05:23:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-26 05:23:51 --> Form Validation Class Initialized
INFO - 2018-01-26 05:23:51 --> Model Class Initialized
INFO - 2018-01-26 05:23:51 --> Controller Class Initialized
INFO - 2018-01-26 05:23:51 --> Model Class Initialized
DEBUG - 2018-01-26 05:23:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-26 05:23:52 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-26 05:23:52 --> Final output sent to browser
DEBUG - 2018-01-26 05:23:52 --> Total execution time: 0.2545
INFO - 2018-01-26 05:23:54 --> Config Class Initialized
INFO - 2018-01-26 05:23:54 --> Hooks Class Initialized
DEBUG - 2018-01-26 05:23:54 --> UTF-8 Support Enabled
INFO - 2018-01-26 05:23:54 --> Utf8 Class Initialized
INFO - 2018-01-26 05:23:54 --> URI Class Initialized
INFO - 2018-01-26 05:23:54 --> Router Class Initialized
INFO - 2018-01-26 05:23:54 --> Output Class Initialized
INFO - 2018-01-26 05:23:54 --> Security Class Initialized
DEBUG - 2018-01-26 05:23:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-26 05:23:54 --> Input Class Initialized
INFO - 2018-01-26 05:23:54 --> Language Class Initialized
INFO - 2018-01-26 05:23:54 --> Loader Class Initialized
INFO - 2018-01-26 05:23:54 --> Helper loaded: url_helper
INFO - 2018-01-26 05:23:54 --> Helper loaded: form_helper
INFO - 2018-01-26 05:23:54 --> Database Driver Class Initialized
DEBUG - 2018-01-26 05:23:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-26 05:23:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-26 05:23:54 --> Form Validation Class Initialized
INFO - 2018-01-26 05:23:54 --> Model Class Initialized
INFO - 2018-01-26 05:23:54 --> Controller Class Initialized
INFO - 2018-01-26 05:23:54 --> Model Class Initialized
DEBUG - 2018-01-26 05:23:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-26 05:23:54 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-26 05:23:54 --> Final output sent to browser
DEBUG - 2018-01-26 05:23:54 --> Total execution time: 0.0578
INFO - 2018-01-26 05:23:54 --> Config Class Initialized
INFO - 2018-01-26 05:23:54 --> Hooks Class Initialized
DEBUG - 2018-01-26 05:23:54 --> UTF-8 Support Enabled
INFO - 2018-01-26 05:23:54 --> Utf8 Class Initialized
INFO - 2018-01-26 05:23:54 --> URI Class Initialized
INFO - 2018-01-26 05:23:54 --> Router Class Initialized
INFO - 2018-01-26 05:23:54 --> Output Class Initialized
INFO - 2018-01-26 05:23:54 --> Security Class Initialized
DEBUG - 2018-01-26 05:23:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-26 05:23:54 --> Input Class Initialized
INFO - 2018-01-26 05:23:54 --> Language Class Initialized
INFO - 2018-01-26 05:23:54 --> Loader Class Initialized
INFO - 2018-01-26 05:23:54 --> Helper loaded: url_helper
INFO - 2018-01-26 05:23:54 --> Helper loaded: form_helper
INFO - 2018-01-26 05:23:54 --> Database Driver Class Initialized
DEBUG - 2018-01-26 05:23:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-26 05:23:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-26 05:23:54 --> Form Validation Class Initialized
INFO - 2018-01-26 05:23:54 --> Model Class Initialized
INFO - 2018-01-26 05:23:54 --> Controller Class Initialized
INFO - 2018-01-26 05:23:54 --> Model Class Initialized
DEBUG - 2018-01-26 05:23:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-26 05:24:07 --> Config Class Initialized
INFO - 2018-01-26 05:24:07 --> Hooks Class Initialized
DEBUG - 2018-01-26 05:24:07 --> UTF-8 Support Enabled
INFO - 2018-01-26 05:24:07 --> Utf8 Class Initialized
INFO - 2018-01-26 05:24:07 --> URI Class Initialized
INFO - 2018-01-26 05:24:07 --> Router Class Initialized
INFO - 2018-01-26 05:24:07 --> Output Class Initialized
INFO - 2018-01-26 05:24:07 --> Security Class Initialized
DEBUG - 2018-01-26 05:24:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-26 05:24:07 --> Input Class Initialized
INFO - 2018-01-26 05:24:07 --> Language Class Initialized
INFO - 2018-01-26 05:24:07 --> Loader Class Initialized
INFO - 2018-01-26 05:24:07 --> Helper loaded: url_helper
INFO - 2018-01-26 05:24:07 --> Helper loaded: form_helper
INFO - 2018-01-26 05:24:07 --> Database Driver Class Initialized
DEBUG - 2018-01-26 05:24:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-26 05:24:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-26 05:24:08 --> Form Validation Class Initialized
INFO - 2018-01-26 05:24:08 --> Model Class Initialized
INFO - 2018-01-26 05:24:08 --> Controller Class Initialized
INFO - 2018-01-26 05:24:08 --> Model Class Initialized
DEBUG - 2018-01-26 05:24:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-26 05:24:10 --> Config Class Initialized
INFO - 2018-01-26 05:24:10 --> Hooks Class Initialized
DEBUG - 2018-01-26 05:24:10 --> UTF-8 Support Enabled
INFO - 2018-01-26 05:24:10 --> Utf8 Class Initialized
INFO - 2018-01-26 05:24:10 --> URI Class Initialized
INFO - 2018-01-26 05:24:10 --> Router Class Initialized
INFO - 2018-01-26 05:24:10 --> Output Class Initialized
INFO - 2018-01-26 05:24:10 --> Security Class Initialized
DEBUG - 2018-01-26 05:24:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-26 05:24:10 --> Input Class Initialized
INFO - 2018-01-26 05:24:10 --> Language Class Initialized
INFO - 2018-01-26 05:24:10 --> Loader Class Initialized
INFO - 2018-01-26 05:24:10 --> Helper loaded: url_helper
INFO - 2018-01-26 05:24:10 --> Helper loaded: form_helper
INFO - 2018-01-26 05:24:10 --> Database Driver Class Initialized
DEBUG - 2018-01-26 05:24:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-26 05:24:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-26 05:24:10 --> Form Validation Class Initialized
INFO - 2018-01-26 05:24:10 --> Model Class Initialized
INFO - 2018-01-26 05:24:10 --> Controller Class Initialized
INFO - 2018-01-26 05:24:10 --> Model Class Initialized
DEBUG - 2018-01-26 05:24:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-26 05:24:13 --> Config Class Initialized
INFO - 2018-01-26 05:24:13 --> Hooks Class Initialized
DEBUG - 2018-01-26 05:24:13 --> UTF-8 Support Enabled
INFO - 2018-01-26 05:24:13 --> Utf8 Class Initialized
INFO - 2018-01-26 05:24:13 --> URI Class Initialized
INFO - 2018-01-26 05:24:13 --> Router Class Initialized
INFO - 2018-01-26 05:24:13 --> Output Class Initialized
INFO - 2018-01-26 05:24:13 --> Security Class Initialized
DEBUG - 2018-01-26 05:24:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-26 05:24:13 --> Input Class Initialized
INFO - 2018-01-26 05:24:13 --> Language Class Initialized
INFO - 2018-01-26 05:24:13 --> Loader Class Initialized
INFO - 2018-01-26 05:24:13 --> Helper loaded: url_helper
INFO - 2018-01-26 05:24:13 --> Helper loaded: form_helper
INFO - 2018-01-26 05:24:13 --> Database Driver Class Initialized
DEBUG - 2018-01-26 05:24:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-26 05:24:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-26 05:24:13 --> Form Validation Class Initialized
INFO - 2018-01-26 05:24:13 --> Model Class Initialized
INFO - 2018-01-26 05:24:13 --> Controller Class Initialized
INFO - 2018-01-26 05:24:13 --> Model Class Initialized
DEBUG - 2018-01-26 05:24:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-26 05:24:13 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-26 05:24:13 --> Final output sent to browser
DEBUG - 2018-01-26 05:24:13 --> Total execution time: 0.0593
INFO - 2018-01-26 05:24:14 --> Config Class Initialized
INFO - 2018-01-26 05:24:14 --> Hooks Class Initialized
DEBUG - 2018-01-26 05:24:14 --> UTF-8 Support Enabled
INFO - 2018-01-26 05:24:14 --> Utf8 Class Initialized
INFO - 2018-01-26 05:24:14 --> URI Class Initialized
INFO - 2018-01-26 05:24:14 --> Router Class Initialized
INFO - 2018-01-26 05:24:14 --> Output Class Initialized
INFO - 2018-01-26 05:24:14 --> Security Class Initialized
DEBUG - 2018-01-26 05:24:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-26 05:24:14 --> Input Class Initialized
INFO - 2018-01-26 05:24:14 --> Language Class Initialized
INFO - 2018-01-26 05:24:14 --> Loader Class Initialized
INFO - 2018-01-26 05:24:14 --> Helper loaded: url_helper
INFO - 2018-01-26 05:24:14 --> Helper loaded: form_helper
INFO - 2018-01-26 05:24:14 --> Database Driver Class Initialized
DEBUG - 2018-01-26 05:24:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-26 05:24:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-26 05:24:14 --> Form Validation Class Initialized
INFO - 2018-01-26 05:24:14 --> Model Class Initialized
INFO - 2018-01-26 05:24:14 --> Controller Class Initialized
INFO - 2018-01-26 05:24:14 --> Model Class Initialized
DEBUG - 2018-01-26 05:24:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-26 05:24:14 --> Config Class Initialized
INFO - 2018-01-26 05:24:14 --> Hooks Class Initialized
DEBUG - 2018-01-26 05:24:14 --> UTF-8 Support Enabled
INFO - 2018-01-26 05:24:14 --> Utf8 Class Initialized
INFO - 2018-01-26 05:24:14 --> URI Class Initialized
INFO - 2018-01-26 05:24:14 --> Router Class Initialized
INFO - 2018-01-26 05:24:14 --> Output Class Initialized
INFO - 2018-01-26 05:24:14 --> Security Class Initialized
DEBUG - 2018-01-26 05:24:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-26 05:24:14 --> Input Class Initialized
INFO - 2018-01-26 05:24:14 --> Language Class Initialized
INFO - 2018-01-26 05:24:14 --> Loader Class Initialized
INFO - 2018-01-26 05:24:14 --> Helper loaded: url_helper
INFO - 2018-01-26 05:24:14 --> Helper loaded: form_helper
INFO - 2018-01-26 05:24:14 --> Database Driver Class Initialized
DEBUG - 2018-01-26 05:24:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-26 05:24:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-26 05:24:14 --> Form Validation Class Initialized
INFO - 2018-01-26 05:24:14 --> Model Class Initialized
INFO - 2018-01-26 05:24:14 --> Controller Class Initialized
INFO - 2018-01-26 05:24:14 --> Model Class Initialized
INFO - 2018-01-26 05:24:14 --> Model Class Initialized
INFO - 2018-01-26 05:24:14 --> Model Class Initialized
INFO - 2018-01-26 05:24:14 --> Model Class Initialized
DEBUG - 2018-01-26 05:24:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-26 05:24:14 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-26 05:24:14 --> Final output sent to browser
DEBUG - 2018-01-26 05:24:14 --> Total execution time: 0.2057
INFO - 2018-01-26 05:24:15 --> Config Class Initialized
INFO - 2018-01-26 05:24:15 --> Hooks Class Initialized
DEBUG - 2018-01-26 05:24:15 --> UTF-8 Support Enabled
INFO - 2018-01-26 05:24:15 --> Utf8 Class Initialized
INFO - 2018-01-26 05:24:15 --> URI Class Initialized
INFO - 2018-01-26 05:24:15 --> Router Class Initialized
INFO - 2018-01-26 05:24:15 --> Output Class Initialized
INFO - 2018-01-26 05:24:15 --> Security Class Initialized
DEBUG - 2018-01-26 05:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-26 05:24:15 --> Input Class Initialized
INFO - 2018-01-26 05:24:15 --> Language Class Initialized
INFO - 2018-01-26 05:24:15 --> Loader Class Initialized
INFO - 2018-01-26 05:24:15 --> Helper loaded: url_helper
INFO - 2018-01-26 05:24:15 --> Helper loaded: form_helper
INFO - 2018-01-26 05:24:15 --> Database Driver Class Initialized
DEBUG - 2018-01-26 05:24:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-26 05:24:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-26 05:24:15 --> Form Validation Class Initialized
INFO - 2018-01-26 05:24:15 --> Model Class Initialized
INFO - 2018-01-26 05:24:15 --> Controller Class Initialized
INFO - 2018-01-26 05:24:15 --> Model Class Initialized
INFO - 2018-01-26 05:24:15 --> Model Class Initialized
DEBUG - 2018-01-26 05:24:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-26 05:24:15 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-26 05:24:15 --> Final output sent to browser
DEBUG - 2018-01-26 05:24:15 --> Total execution time: 0.0893
INFO - 2018-01-26 05:24:15 --> Config Class Initialized
INFO - 2018-01-26 05:24:15 --> Hooks Class Initialized
DEBUG - 2018-01-26 05:24:15 --> UTF-8 Support Enabled
INFO - 2018-01-26 05:24:15 --> Utf8 Class Initialized
INFO - 2018-01-26 05:24:15 --> URI Class Initialized
INFO - 2018-01-26 05:24:15 --> Router Class Initialized
INFO - 2018-01-26 05:24:15 --> Output Class Initialized
INFO - 2018-01-26 05:24:15 --> Security Class Initialized
DEBUG - 2018-01-26 05:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-26 05:24:15 --> Input Class Initialized
INFO - 2018-01-26 05:24:15 --> Language Class Initialized
INFO - 2018-01-26 05:24:15 --> Loader Class Initialized
INFO - 2018-01-26 05:24:15 --> Helper loaded: url_helper
INFO - 2018-01-26 05:24:15 --> Helper loaded: form_helper
INFO - 2018-01-26 05:24:15 --> Database Driver Class Initialized
DEBUG - 2018-01-26 05:24:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-26 05:24:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-26 05:24:15 --> Form Validation Class Initialized
INFO - 2018-01-26 05:24:15 --> Model Class Initialized
INFO - 2018-01-26 05:24:15 --> Controller Class Initialized
INFO - 2018-01-26 05:24:15 --> Model Class Initialized
INFO - 2018-01-26 05:24:15 --> Model Class Initialized
DEBUG - 2018-01-26 05:24:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-26 05:24:16 --> Config Class Initialized
INFO - 2018-01-26 05:24:16 --> Hooks Class Initialized
DEBUG - 2018-01-26 05:24:16 --> UTF-8 Support Enabled
INFO - 2018-01-26 05:24:16 --> Utf8 Class Initialized
INFO - 2018-01-26 05:24:16 --> URI Class Initialized
INFO - 2018-01-26 05:24:16 --> Router Class Initialized
INFO - 2018-01-26 05:24:16 --> Output Class Initialized
INFO - 2018-01-26 05:24:16 --> Security Class Initialized
DEBUG - 2018-01-26 05:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-26 05:24:16 --> Input Class Initialized
INFO - 2018-01-26 05:24:16 --> Language Class Initialized
INFO - 2018-01-26 05:24:16 --> Loader Class Initialized
INFO - 2018-01-26 05:24:16 --> Helper loaded: url_helper
INFO - 2018-01-26 05:24:16 --> Helper loaded: form_helper
INFO - 2018-01-26 05:24:16 --> Database Driver Class Initialized
DEBUG - 2018-01-26 05:24:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-26 05:24:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-26 05:24:16 --> Form Validation Class Initialized
INFO - 2018-01-26 05:24:16 --> Model Class Initialized
INFO - 2018-01-26 05:24:16 --> Controller Class Initialized
INFO - 2018-01-26 05:24:16 --> Model Class Initialized
INFO - 2018-01-26 05:24:16 --> Model Class Initialized
DEBUG - 2018-01-26 05:24:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-26 05:24:16 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-26 05:24:16 --> Final output sent to browser
DEBUG - 2018-01-26 05:24:16 --> Total execution time: 0.1317
INFO - 2018-01-26 05:24:16 --> Config Class Initialized
INFO - 2018-01-26 05:24:16 --> Hooks Class Initialized
DEBUG - 2018-01-26 05:24:16 --> UTF-8 Support Enabled
INFO - 2018-01-26 05:24:16 --> Utf8 Class Initialized
INFO - 2018-01-26 05:24:16 --> URI Class Initialized
INFO - 2018-01-26 05:24:16 --> Router Class Initialized
INFO - 2018-01-26 05:24:16 --> Output Class Initialized
INFO - 2018-01-26 05:24:16 --> Security Class Initialized
DEBUG - 2018-01-26 05:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-26 05:24:16 --> Input Class Initialized
INFO - 2018-01-26 05:24:16 --> Language Class Initialized
INFO - 2018-01-26 05:24:16 --> Loader Class Initialized
INFO - 2018-01-26 05:24:16 --> Helper loaded: url_helper
INFO - 2018-01-26 05:24:16 --> Helper loaded: form_helper
INFO - 2018-01-26 05:24:16 --> Database Driver Class Initialized
DEBUG - 2018-01-26 05:24:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-26 05:24:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-26 05:24:16 --> Form Validation Class Initialized
INFO - 2018-01-26 05:24:16 --> Model Class Initialized
INFO - 2018-01-26 05:24:16 --> Controller Class Initialized
INFO - 2018-01-26 05:24:16 --> Model Class Initialized
INFO - 2018-01-26 05:24:16 --> Model Class Initialized
DEBUG - 2018-01-26 05:24:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-26 05:24:17 --> Config Class Initialized
INFO - 2018-01-26 05:24:17 --> Hooks Class Initialized
DEBUG - 2018-01-26 05:24:17 --> UTF-8 Support Enabled
INFO - 2018-01-26 05:24:17 --> Utf8 Class Initialized
INFO - 2018-01-26 05:24:17 --> URI Class Initialized
INFO - 2018-01-26 05:24:17 --> Router Class Initialized
INFO - 2018-01-26 05:24:17 --> Output Class Initialized
INFO - 2018-01-26 05:24:17 --> Security Class Initialized
DEBUG - 2018-01-26 05:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-26 05:24:17 --> Input Class Initialized
INFO - 2018-01-26 05:24:17 --> Language Class Initialized
INFO - 2018-01-26 05:24:17 --> Loader Class Initialized
INFO - 2018-01-26 05:24:17 --> Helper loaded: url_helper
INFO - 2018-01-26 05:24:17 --> Helper loaded: form_helper
INFO - 2018-01-26 05:24:17 --> Database Driver Class Initialized
DEBUG - 2018-01-26 05:24:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-26 05:24:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-26 05:24:17 --> Form Validation Class Initialized
INFO - 2018-01-26 05:24:17 --> Model Class Initialized
INFO - 2018-01-26 05:24:17 --> Controller Class Initialized
INFO - 2018-01-26 05:24:17 --> Model Class Initialized
INFO - 2018-01-26 05:24:17 --> Model Class Initialized
INFO - 2018-01-26 05:24:17 --> Model Class Initialized
INFO - 2018-01-26 05:24:17 --> Model Class Initialized
DEBUG - 2018-01-26 05:24:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-26 05:24:17 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-26 05:24:17 --> Final output sent to browser
DEBUG - 2018-01-26 05:24:17 --> Total execution time: 0.0880
INFO - 2018-01-26 05:24:17 --> Config Class Initialized
INFO - 2018-01-26 05:24:17 --> Hooks Class Initialized
DEBUG - 2018-01-26 05:24:17 --> UTF-8 Support Enabled
INFO - 2018-01-26 05:24:17 --> Utf8 Class Initialized
INFO - 2018-01-26 05:24:17 --> URI Class Initialized
INFO - 2018-01-26 05:24:17 --> Router Class Initialized
INFO - 2018-01-26 05:24:17 --> Output Class Initialized
INFO - 2018-01-26 05:24:17 --> Security Class Initialized
DEBUG - 2018-01-26 05:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-26 05:24:17 --> Input Class Initialized
INFO - 2018-01-26 05:24:17 --> Language Class Initialized
INFO - 2018-01-26 05:24:17 --> Loader Class Initialized
INFO - 2018-01-26 05:24:17 --> Helper loaded: url_helper
INFO - 2018-01-26 05:24:17 --> Helper loaded: form_helper
INFO - 2018-01-26 05:24:17 --> Database Driver Class Initialized
DEBUG - 2018-01-26 05:24:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-26 05:24:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-26 05:24:17 --> Form Validation Class Initialized
INFO - 2018-01-26 05:24:17 --> Model Class Initialized
INFO - 2018-01-26 05:24:17 --> Controller Class Initialized
INFO - 2018-01-26 05:24:17 --> Model Class Initialized
INFO - 2018-01-26 05:24:17 --> Model Class Initialized
INFO - 2018-01-26 05:24:17 --> Model Class Initialized
INFO - 2018-01-26 05:24:17 --> Model Class Initialized
DEBUG - 2018-01-26 05:24:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-26 05:24:18 --> Config Class Initialized
INFO - 2018-01-26 05:24:18 --> Hooks Class Initialized
DEBUG - 2018-01-26 05:24:18 --> UTF-8 Support Enabled
INFO - 2018-01-26 05:24:18 --> Utf8 Class Initialized
INFO - 2018-01-26 05:24:18 --> URI Class Initialized
DEBUG - 2018-01-26 05:24:18 --> No URI present. Default controller set.
INFO - 2018-01-26 05:24:18 --> Router Class Initialized
INFO - 2018-01-26 05:24:18 --> Output Class Initialized
INFO - 2018-01-26 05:24:18 --> Security Class Initialized
DEBUG - 2018-01-26 05:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-26 05:24:18 --> Input Class Initialized
INFO - 2018-01-26 05:24:18 --> Language Class Initialized
INFO - 2018-01-26 05:24:18 --> Loader Class Initialized
INFO - 2018-01-26 05:24:18 --> Helper loaded: url_helper
INFO - 2018-01-26 05:24:18 --> Helper loaded: form_helper
INFO - 2018-01-26 05:24:18 --> Database Driver Class Initialized
DEBUG - 2018-01-26 05:24:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-26 05:24:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-26 05:24:18 --> Form Validation Class Initialized
INFO - 2018-01-26 05:24:18 --> Model Class Initialized
INFO - 2018-01-26 05:24:18 --> Controller Class Initialized
INFO - 2018-01-26 05:24:18 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-26 05:24:18 --> Final output sent to browser
DEBUG - 2018-01-26 05:24:18 --> Total execution time: 0.0436
INFO - 2018-01-26 05:24:18 --> Config Class Initialized
INFO - 2018-01-26 05:24:18 --> Hooks Class Initialized
DEBUG - 2018-01-26 05:24:18 --> UTF-8 Support Enabled
INFO - 2018-01-26 05:24:18 --> Utf8 Class Initialized
INFO - 2018-01-26 05:24:18 --> URI Class Initialized
INFO - 2018-01-26 05:24:18 --> Router Class Initialized
INFO - 2018-01-26 05:24:18 --> Output Class Initialized
INFO - 2018-01-26 05:24:18 --> Security Class Initialized
DEBUG - 2018-01-26 05:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-26 05:24:18 --> Input Class Initialized
INFO - 2018-01-26 05:24:18 --> Language Class Initialized
INFO - 2018-01-26 05:24:18 --> Loader Class Initialized
INFO - 2018-01-26 05:24:18 --> Helper loaded: url_helper
INFO - 2018-01-26 05:24:18 --> Helper loaded: form_helper
INFO - 2018-01-26 05:24:18 --> Database Driver Class Initialized
DEBUG - 2018-01-26 05:24:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-26 05:24:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-26 05:24:18 --> Form Validation Class Initialized
INFO - 2018-01-26 05:24:18 --> Model Class Initialized
INFO - 2018-01-26 05:24:18 --> Controller Class Initialized
INFO - 2018-01-26 05:24:18 --> Model Class Initialized
INFO - 2018-01-26 05:24:18 --> Model Class Initialized
INFO - 2018-01-26 05:24:18 --> Model Class Initialized
INFO - 2018-01-26 05:24:18 --> Model Class Initialized
DEBUG - 2018-01-26 05:24:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-26 05:24:19 --> Config Class Initialized
INFO - 2018-01-26 05:24:19 --> Hooks Class Initialized
DEBUG - 2018-01-26 05:24:19 --> UTF-8 Support Enabled
INFO - 2018-01-26 05:24:19 --> Utf8 Class Initialized
INFO - 2018-01-26 05:24:19 --> URI Class Initialized
INFO - 2018-01-26 05:24:19 --> Router Class Initialized
INFO - 2018-01-26 05:24:19 --> Output Class Initialized
INFO - 2018-01-26 05:24:19 --> Security Class Initialized
DEBUG - 2018-01-26 05:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-26 05:24:19 --> Input Class Initialized
INFO - 2018-01-26 05:24:19 --> Language Class Initialized
INFO - 2018-01-26 05:24:19 --> Loader Class Initialized
INFO - 2018-01-26 05:24:19 --> Helper loaded: url_helper
INFO - 2018-01-26 05:24:19 --> Helper loaded: form_helper
INFO - 2018-01-26 05:24:19 --> Database Driver Class Initialized
DEBUG - 2018-01-26 05:24:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-26 05:24:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-26 05:24:19 --> Form Validation Class Initialized
INFO - 2018-01-26 05:24:19 --> Model Class Initialized
INFO - 2018-01-26 05:24:19 --> Controller Class Initialized
INFO - 2018-01-26 05:24:19 --> Model Class Initialized
DEBUG - 2018-01-26 05:24:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-26 05:24:19 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-26 05:24:19 --> Final output sent to browser
DEBUG - 2018-01-26 05:24:19 --> Total execution time: 0.0465
INFO - 2018-01-26 05:24:19 --> Config Class Initialized
INFO - 2018-01-26 05:24:19 --> Hooks Class Initialized
DEBUG - 2018-01-26 05:24:19 --> UTF-8 Support Enabled
INFO - 2018-01-26 05:24:19 --> Utf8 Class Initialized
INFO - 2018-01-26 05:24:19 --> URI Class Initialized
INFO - 2018-01-26 05:24:19 --> Router Class Initialized
INFO - 2018-01-26 05:24:19 --> Output Class Initialized
INFO - 2018-01-26 05:24:19 --> Security Class Initialized
DEBUG - 2018-01-26 05:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-26 05:24:19 --> Input Class Initialized
INFO - 2018-01-26 05:24:19 --> Language Class Initialized
INFO - 2018-01-26 05:24:19 --> Loader Class Initialized
INFO - 2018-01-26 05:24:19 --> Helper loaded: url_helper
INFO - 2018-01-26 05:24:19 --> Helper loaded: form_helper
INFO - 2018-01-26 05:24:19 --> Database Driver Class Initialized
DEBUG - 2018-01-26 05:24:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-26 05:24:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-26 05:24:19 --> Form Validation Class Initialized
INFO - 2018-01-26 05:24:19 --> Model Class Initialized
INFO - 2018-01-26 05:24:19 --> Controller Class Initialized
INFO - 2018-01-26 05:24:19 --> Model Class Initialized
DEBUG - 2018-01-26 05:24:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-26 05:30:52 --> Config Class Initialized
INFO - 2018-01-26 05:30:52 --> Hooks Class Initialized
DEBUG - 2018-01-26 05:30:52 --> UTF-8 Support Enabled
INFO - 2018-01-26 05:30:52 --> Utf8 Class Initialized
INFO - 2018-01-26 05:30:52 --> URI Class Initialized
INFO - 2018-01-26 05:30:52 --> Router Class Initialized
INFO - 2018-01-26 05:30:53 --> Output Class Initialized
INFO - 2018-01-26 05:30:53 --> Security Class Initialized
DEBUG - 2018-01-26 05:30:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-26 05:30:53 --> Input Class Initialized
INFO - 2018-01-26 05:30:53 --> Language Class Initialized
INFO - 2018-01-26 05:30:53 --> Loader Class Initialized
INFO - 2018-01-26 05:30:53 --> Helper loaded: url_helper
INFO - 2018-01-26 05:30:53 --> Helper loaded: form_helper
INFO - 2018-01-26 05:30:53 --> Database Driver Class Initialized
DEBUG - 2018-01-26 05:30:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-26 05:30:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-26 05:30:53 --> Form Validation Class Initialized
INFO - 2018-01-26 05:30:53 --> Model Class Initialized
INFO - 2018-01-26 05:30:53 --> Controller Class Initialized
INFO - 2018-01-26 05:30:53 --> Model Class Initialized
DEBUG - 2018-01-26 05:30:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-26 05:30:53 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-26 05:30:53 --> Final output sent to browser
DEBUG - 2018-01-26 05:30:53 --> Total execution time: 0.1080
INFO - 2018-01-26 05:30:53 --> Config Class Initialized
INFO - 2018-01-26 05:30:53 --> Hooks Class Initialized
DEBUG - 2018-01-26 05:30:53 --> UTF-8 Support Enabled
INFO - 2018-01-26 05:30:53 --> Utf8 Class Initialized
INFO - 2018-01-26 05:30:53 --> URI Class Initialized
INFO - 2018-01-26 05:30:53 --> Router Class Initialized
INFO - 2018-01-26 05:30:53 --> Output Class Initialized
INFO - 2018-01-26 05:30:53 --> Security Class Initialized
DEBUG - 2018-01-26 05:30:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-26 05:30:53 --> Input Class Initialized
INFO - 2018-01-26 05:30:53 --> Language Class Initialized
INFO - 2018-01-26 05:30:53 --> Loader Class Initialized
INFO - 2018-01-26 05:30:53 --> Helper loaded: url_helper
INFO - 2018-01-26 05:30:53 --> Helper loaded: form_helper
INFO - 2018-01-26 05:30:53 --> Database Driver Class Initialized
DEBUG - 2018-01-26 05:30:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-26 05:30:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-26 05:30:53 --> Form Validation Class Initialized
INFO - 2018-01-26 05:30:53 --> Model Class Initialized
INFO - 2018-01-26 05:30:53 --> Controller Class Initialized
INFO - 2018-01-26 05:30:53 --> Model Class Initialized
DEBUG - 2018-01-26 05:30:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-26 06:46:15 --> Config Class Initialized
INFO - 2018-01-26 06:46:15 --> Hooks Class Initialized
DEBUG - 2018-01-26 06:46:15 --> UTF-8 Support Enabled
INFO - 2018-01-26 06:46:15 --> Utf8 Class Initialized
INFO - 2018-01-26 06:46:15 --> URI Class Initialized
INFO - 2018-01-26 06:46:15 --> Router Class Initialized
INFO - 2018-01-26 06:46:15 --> Output Class Initialized
INFO - 2018-01-26 06:46:15 --> Security Class Initialized
DEBUG - 2018-01-26 06:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-26 06:46:15 --> Input Class Initialized
INFO - 2018-01-26 06:46:15 --> Language Class Initialized
INFO - 2018-01-26 06:46:15 --> Loader Class Initialized
INFO - 2018-01-26 06:46:15 --> Helper loaded: url_helper
INFO - 2018-01-26 06:46:15 --> Helper loaded: form_helper
INFO - 2018-01-26 06:46:15 --> Database Driver Class Initialized
DEBUG - 2018-01-26 06:46:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-26 06:46:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-26 06:46:15 --> Form Validation Class Initialized
INFO - 2018-01-26 06:46:15 --> Model Class Initialized
INFO - 2018-01-26 06:46:15 --> Controller Class Initialized
INFO - 2018-01-26 06:46:15 --> Model Class Initialized
DEBUG - 2018-01-26 06:46:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-26 06:46:15 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-26 06:46:15 --> Final output sent to browser
DEBUG - 2018-01-26 06:46:15 --> Total execution time: 0.0503
INFO - 2018-01-26 06:46:16 --> Config Class Initialized
INFO - 2018-01-26 06:46:16 --> Hooks Class Initialized
DEBUG - 2018-01-26 06:46:16 --> UTF-8 Support Enabled
INFO - 2018-01-26 06:46:16 --> Utf8 Class Initialized
INFO - 2018-01-26 06:46:16 --> URI Class Initialized
INFO - 2018-01-26 06:46:16 --> Router Class Initialized
INFO - 2018-01-26 06:46:16 --> Output Class Initialized
INFO - 2018-01-26 06:46:16 --> Security Class Initialized
DEBUG - 2018-01-26 06:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-26 06:46:16 --> Input Class Initialized
INFO - 2018-01-26 06:46:16 --> Language Class Initialized
INFO - 2018-01-26 06:46:16 --> Loader Class Initialized
INFO - 2018-01-26 06:46:16 --> Helper loaded: url_helper
INFO - 2018-01-26 06:46:16 --> Helper loaded: form_helper
INFO - 2018-01-26 06:46:16 --> Database Driver Class Initialized
DEBUG - 2018-01-26 06:46:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-26 06:46:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-26 06:46:16 --> Form Validation Class Initialized
INFO - 2018-01-26 06:46:16 --> Model Class Initialized
INFO - 2018-01-26 06:46:16 --> Controller Class Initialized
INFO - 2018-01-26 06:46:16 --> Model Class Initialized
DEBUG - 2018-01-26 06:46:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-26 06:46:18 --> Config Class Initialized
INFO - 2018-01-26 06:46:18 --> Hooks Class Initialized
DEBUG - 2018-01-26 06:46:18 --> UTF-8 Support Enabled
INFO - 2018-01-26 06:46:18 --> Utf8 Class Initialized
INFO - 2018-01-26 06:46:18 --> URI Class Initialized
INFO - 2018-01-26 06:46:18 --> Router Class Initialized
INFO - 2018-01-26 06:46:18 --> Output Class Initialized
INFO - 2018-01-26 06:46:18 --> Security Class Initialized
DEBUG - 2018-01-26 06:46:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-26 06:46:18 --> Input Class Initialized
INFO - 2018-01-26 06:46:18 --> Language Class Initialized
INFO - 2018-01-26 06:46:18 --> Loader Class Initialized
INFO - 2018-01-26 06:46:18 --> Helper loaded: url_helper
INFO - 2018-01-26 06:46:18 --> Helper loaded: form_helper
INFO - 2018-01-26 06:46:18 --> Database Driver Class Initialized
DEBUG - 2018-01-26 06:46:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-26 06:46:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-26 06:46:18 --> Form Validation Class Initialized
INFO - 2018-01-26 06:46:18 --> Model Class Initialized
INFO - 2018-01-26 06:46:18 --> Controller Class Initialized
INFO - 2018-01-26 06:46:18 --> Model Class Initialized
DEBUG - 2018-01-26 06:46:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-26 06:46:18 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-26 06:46:18 --> Final output sent to browser
DEBUG - 2018-01-26 06:46:18 --> Total execution time: 0.0431
INFO - 2018-01-26 06:46:19 --> Config Class Initialized
INFO - 2018-01-26 06:46:19 --> Hooks Class Initialized
DEBUG - 2018-01-26 06:46:19 --> UTF-8 Support Enabled
INFO - 2018-01-26 06:46:19 --> Utf8 Class Initialized
INFO - 2018-01-26 06:46:19 --> URI Class Initialized
INFO - 2018-01-26 06:46:19 --> Router Class Initialized
INFO - 2018-01-26 06:46:19 --> Output Class Initialized
INFO - 2018-01-26 06:46:19 --> Security Class Initialized
DEBUG - 2018-01-26 06:46:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-26 06:46:19 --> Input Class Initialized
INFO - 2018-01-26 06:46:19 --> Language Class Initialized
INFO - 2018-01-26 06:46:19 --> Loader Class Initialized
INFO - 2018-01-26 06:46:19 --> Helper loaded: url_helper
INFO - 2018-01-26 06:46:19 --> Helper loaded: form_helper
INFO - 2018-01-26 06:46:19 --> Database Driver Class Initialized
DEBUG - 2018-01-26 06:46:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-26 06:46:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-26 06:46:19 --> Form Validation Class Initialized
INFO - 2018-01-26 06:46:19 --> Model Class Initialized
INFO - 2018-01-26 06:46:19 --> Controller Class Initialized
INFO - 2018-01-26 06:46:19 --> Model Class Initialized
DEBUG - 2018-01-26 06:46:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-26 06:47:04 --> Config Class Initialized
INFO - 2018-01-26 06:47:04 --> Hooks Class Initialized
DEBUG - 2018-01-26 06:47:04 --> UTF-8 Support Enabled
INFO - 2018-01-26 06:47:04 --> Utf8 Class Initialized
INFO - 2018-01-26 06:47:04 --> URI Class Initialized
INFO - 2018-01-26 06:47:04 --> Router Class Initialized
INFO - 2018-01-26 06:47:04 --> Output Class Initialized
INFO - 2018-01-26 06:47:04 --> Security Class Initialized
DEBUG - 2018-01-26 06:47:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-26 06:47:04 --> Input Class Initialized
INFO - 2018-01-26 06:47:04 --> Language Class Initialized
INFO - 2018-01-26 06:47:04 --> Loader Class Initialized
INFO - 2018-01-26 06:47:04 --> Helper loaded: url_helper
INFO - 2018-01-26 06:47:04 --> Helper loaded: form_helper
INFO - 2018-01-26 06:47:04 --> Database Driver Class Initialized
DEBUG - 2018-01-26 06:47:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-26 06:47:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-26 06:47:04 --> Form Validation Class Initialized
INFO - 2018-01-26 06:47:04 --> Model Class Initialized
INFO - 2018-01-26 06:47:04 --> Controller Class Initialized
INFO - 2018-01-26 06:47:04 --> Model Class Initialized
DEBUG - 2018-01-26 06:47:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-26 06:47:04 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-26 06:47:04 --> Final output sent to browser
DEBUG - 2018-01-26 06:47:04 --> Total execution time: 0.0422
INFO - 2018-01-26 06:47:04 --> Config Class Initialized
INFO - 2018-01-26 06:47:04 --> Hooks Class Initialized
DEBUG - 2018-01-26 06:47:04 --> UTF-8 Support Enabled
INFO - 2018-01-26 06:47:04 --> Utf8 Class Initialized
INFO - 2018-01-26 06:47:04 --> URI Class Initialized
INFO - 2018-01-26 06:47:04 --> Router Class Initialized
INFO - 2018-01-26 06:47:04 --> Output Class Initialized
INFO - 2018-01-26 06:47:04 --> Security Class Initialized
DEBUG - 2018-01-26 06:47:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-26 06:47:04 --> Input Class Initialized
INFO - 2018-01-26 06:47:04 --> Language Class Initialized
INFO - 2018-01-26 06:47:04 --> Loader Class Initialized
INFO - 2018-01-26 06:47:04 --> Helper loaded: url_helper
INFO - 2018-01-26 06:47:04 --> Helper loaded: form_helper
INFO - 2018-01-26 06:47:04 --> Database Driver Class Initialized
DEBUG - 2018-01-26 06:47:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-26 06:47:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-26 06:47:04 --> Form Validation Class Initialized
INFO - 2018-01-26 06:47:04 --> Model Class Initialized
INFO - 2018-01-26 06:47:04 --> Controller Class Initialized
INFO - 2018-01-26 06:47:04 --> Model Class Initialized
DEBUG - 2018-01-26 06:47:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-26 06:47:12 --> Config Class Initialized
INFO - 2018-01-26 06:47:12 --> Hooks Class Initialized
DEBUG - 2018-01-26 06:47:12 --> UTF-8 Support Enabled
INFO - 2018-01-26 06:47:12 --> Utf8 Class Initialized
INFO - 2018-01-26 06:47:12 --> URI Class Initialized
INFO - 2018-01-26 06:47:12 --> Router Class Initialized
INFO - 2018-01-26 06:47:12 --> Output Class Initialized
INFO - 2018-01-26 06:47:12 --> Security Class Initialized
DEBUG - 2018-01-26 06:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-26 06:47:12 --> Input Class Initialized
INFO - 2018-01-26 06:47:12 --> Language Class Initialized
INFO - 2018-01-26 06:47:12 --> Loader Class Initialized
INFO - 2018-01-26 06:47:12 --> Helper loaded: url_helper
INFO - 2018-01-26 06:47:12 --> Helper loaded: form_helper
INFO - 2018-01-26 06:47:12 --> Database Driver Class Initialized
DEBUG - 2018-01-26 06:47:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-26 06:47:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-26 06:47:12 --> Form Validation Class Initialized
INFO - 2018-01-26 06:47:12 --> Model Class Initialized
INFO - 2018-01-26 06:47:12 --> Controller Class Initialized
INFO - 2018-01-26 06:47:12 --> Model Class Initialized
DEBUG - 2018-01-26 06:47:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-26 06:48:23 --> Config Class Initialized
INFO - 2018-01-26 06:48:23 --> Hooks Class Initialized
DEBUG - 2018-01-26 06:48:23 --> UTF-8 Support Enabled
INFO - 2018-01-26 06:48:23 --> Utf8 Class Initialized
INFO - 2018-01-26 06:48:23 --> URI Class Initialized
INFO - 2018-01-26 06:48:23 --> Router Class Initialized
INFO - 2018-01-26 06:48:23 --> Output Class Initialized
INFO - 2018-01-26 06:48:23 --> Security Class Initialized
DEBUG - 2018-01-26 06:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-26 06:48:23 --> Input Class Initialized
INFO - 2018-01-26 06:48:23 --> Language Class Initialized
INFO - 2018-01-26 06:48:23 --> Loader Class Initialized
INFO - 2018-01-26 06:48:23 --> Helper loaded: url_helper
INFO - 2018-01-26 06:48:23 --> Helper loaded: form_helper
INFO - 2018-01-26 06:48:23 --> Database Driver Class Initialized
DEBUG - 2018-01-26 06:48:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-26 06:48:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-26 06:48:23 --> Form Validation Class Initialized
INFO - 2018-01-26 06:48:23 --> Model Class Initialized
INFO - 2018-01-26 06:48:23 --> Controller Class Initialized
INFO - 2018-01-26 06:48:23 --> Model Class Initialized
DEBUG - 2018-01-26 06:48:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-26 06:48:23 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-26 06:48:23 --> Final output sent to browser
DEBUG - 2018-01-26 06:48:23 --> Total execution time: 0.0381
INFO - 2018-01-26 06:48:24 --> Config Class Initialized
INFO - 2018-01-26 06:48:24 --> Hooks Class Initialized
DEBUG - 2018-01-26 06:48:24 --> UTF-8 Support Enabled
INFO - 2018-01-26 06:48:24 --> Utf8 Class Initialized
INFO - 2018-01-26 06:48:24 --> URI Class Initialized
INFO - 2018-01-26 06:48:24 --> Router Class Initialized
INFO - 2018-01-26 06:48:24 --> Output Class Initialized
INFO - 2018-01-26 06:48:24 --> Security Class Initialized
DEBUG - 2018-01-26 06:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-26 06:48:24 --> Input Class Initialized
INFO - 2018-01-26 06:48:24 --> Language Class Initialized
INFO - 2018-01-26 06:48:24 --> Loader Class Initialized
INFO - 2018-01-26 06:48:24 --> Helper loaded: url_helper
INFO - 2018-01-26 06:48:24 --> Helper loaded: form_helper
INFO - 2018-01-26 06:48:24 --> Database Driver Class Initialized
DEBUG - 2018-01-26 06:48:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-26 06:48:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-26 06:48:24 --> Form Validation Class Initialized
INFO - 2018-01-26 06:48:24 --> Model Class Initialized
INFO - 2018-01-26 06:48:24 --> Controller Class Initialized
INFO - 2018-01-26 06:48:24 --> Model Class Initialized
DEBUG - 2018-01-26 06:48:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-26 06:48:57 --> Config Class Initialized
INFO - 2018-01-26 06:48:57 --> Hooks Class Initialized
DEBUG - 2018-01-26 06:48:57 --> UTF-8 Support Enabled
INFO - 2018-01-26 06:48:57 --> Utf8 Class Initialized
INFO - 2018-01-26 06:48:57 --> URI Class Initialized
INFO - 2018-01-26 06:48:57 --> Router Class Initialized
INFO - 2018-01-26 06:48:57 --> Output Class Initialized
INFO - 2018-01-26 06:48:57 --> Security Class Initialized
DEBUG - 2018-01-26 06:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-26 06:48:57 --> Input Class Initialized
INFO - 2018-01-26 06:48:57 --> Language Class Initialized
INFO - 2018-01-26 06:48:57 --> Loader Class Initialized
INFO - 2018-01-26 06:48:57 --> Helper loaded: url_helper
INFO - 2018-01-26 06:48:57 --> Helper loaded: form_helper
INFO - 2018-01-26 06:48:57 --> Database Driver Class Initialized
DEBUG - 2018-01-26 06:48:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-26 06:48:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-26 06:48:57 --> Form Validation Class Initialized
INFO - 2018-01-26 06:48:57 --> Model Class Initialized
INFO - 2018-01-26 06:48:57 --> Controller Class Initialized
INFO - 2018-01-26 06:48:57 --> Model Class Initialized
DEBUG - 2018-01-26 06:48:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-26 06:49:00 --> Config Class Initialized
INFO - 2018-01-26 06:49:00 --> Hooks Class Initialized
DEBUG - 2018-01-26 06:49:00 --> UTF-8 Support Enabled
INFO - 2018-01-26 06:49:00 --> Utf8 Class Initialized
INFO - 2018-01-26 06:49:00 --> URI Class Initialized
INFO - 2018-01-26 06:49:00 --> Router Class Initialized
INFO - 2018-01-26 06:49:00 --> Output Class Initialized
INFO - 2018-01-26 06:49:00 --> Security Class Initialized
DEBUG - 2018-01-26 06:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-26 06:49:00 --> Input Class Initialized
INFO - 2018-01-26 06:49:00 --> Language Class Initialized
INFO - 2018-01-26 06:49:00 --> Loader Class Initialized
INFO - 2018-01-26 06:49:00 --> Helper loaded: url_helper
INFO - 2018-01-26 06:49:00 --> Helper loaded: form_helper
INFO - 2018-01-26 06:49:00 --> Database Driver Class Initialized
DEBUG - 2018-01-26 06:49:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-26 06:49:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-26 06:49:00 --> Form Validation Class Initialized
INFO - 2018-01-26 06:49:00 --> Model Class Initialized
INFO - 2018-01-26 06:49:00 --> Controller Class Initialized
INFO - 2018-01-26 06:49:00 --> Model Class Initialized
DEBUG - 2018-01-26 06:49:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-26 06:49:04 --> Config Class Initialized
INFO - 2018-01-26 06:49:04 --> Hooks Class Initialized
DEBUG - 2018-01-26 06:49:04 --> UTF-8 Support Enabled
INFO - 2018-01-26 06:49:04 --> Utf8 Class Initialized
INFO - 2018-01-26 06:49:04 --> URI Class Initialized
INFO - 2018-01-26 06:49:04 --> Router Class Initialized
INFO - 2018-01-26 06:49:04 --> Output Class Initialized
INFO - 2018-01-26 06:49:04 --> Security Class Initialized
DEBUG - 2018-01-26 06:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-26 06:49:04 --> Input Class Initialized
INFO - 2018-01-26 06:49:04 --> Language Class Initialized
INFO - 2018-01-26 06:49:04 --> Loader Class Initialized
INFO - 2018-01-26 06:49:04 --> Helper loaded: url_helper
INFO - 2018-01-26 06:49:04 --> Helper loaded: form_helper
INFO - 2018-01-26 06:49:04 --> Database Driver Class Initialized
DEBUG - 2018-01-26 06:49:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-26 06:49:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-26 06:49:04 --> Form Validation Class Initialized
INFO - 2018-01-26 06:49:04 --> Model Class Initialized
INFO - 2018-01-26 06:49:04 --> Controller Class Initialized
INFO - 2018-01-26 06:49:04 --> Model Class Initialized
DEBUG - 2018-01-26 06:49:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-26 06:49:04 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-26 06:49:04 --> Final output sent to browser
DEBUG - 2018-01-26 06:49:04 --> Total execution time: 0.1169
INFO - 2018-01-26 06:49:25 --> Config Class Initialized
INFO - 2018-01-26 06:49:25 --> Hooks Class Initialized
DEBUG - 2018-01-26 06:49:25 --> UTF-8 Support Enabled
INFO - 2018-01-26 06:49:25 --> Utf8 Class Initialized
INFO - 2018-01-26 06:49:25 --> URI Class Initialized
INFO - 2018-01-26 06:49:25 --> Router Class Initialized
INFO - 2018-01-26 06:49:25 --> Output Class Initialized
INFO - 2018-01-26 06:49:25 --> Security Class Initialized
DEBUG - 2018-01-26 06:49:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-26 06:49:25 --> Input Class Initialized
INFO - 2018-01-26 06:49:25 --> Language Class Initialized
INFO - 2018-01-26 06:49:25 --> Loader Class Initialized
INFO - 2018-01-26 06:49:25 --> Helper loaded: url_helper
INFO - 2018-01-26 06:49:25 --> Helper loaded: form_helper
INFO - 2018-01-26 06:49:25 --> Database Driver Class Initialized
DEBUG - 2018-01-26 06:49:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-26 06:49:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-26 06:49:25 --> Form Validation Class Initialized
INFO - 2018-01-26 06:49:25 --> Model Class Initialized
INFO - 2018-01-26 06:49:25 --> Controller Class Initialized
INFO - 2018-01-26 06:49:25 --> Model Class Initialized
DEBUG - 2018-01-26 06:49:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-26 06:49:25 --> Model Class Initialized
INFO - 2018-01-26 06:49:25 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-26 06:49:25 --> Final output sent to browser
DEBUG - 2018-01-26 06:49:25 --> Total execution time: 0.4711
INFO - 2018-01-26 06:49:27 --> Config Class Initialized
INFO - 2018-01-26 06:49:27 --> Hooks Class Initialized
DEBUG - 2018-01-26 06:49:27 --> UTF-8 Support Enabled
INFO - 2018-01-26 06:49:27 --> Utf8 Class Initialized
INFO - 2018-01-26 06:49:27 --> URI Class Initialized
INFO - 2018-01-26 06:49:27 --> Router Class Initialized
INFO - 2018-01-26 06:49:27 --> Output Class Initialized
INFO - 2018-01-26 06:49:27 --> Security Class Initialized
DEBUG - 2018-01-26 06:49:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-26 06:49:27 --> Input Class Initialized
INFO - 2018-01-26 06:49:27 --> Language Class Initialized
INFO - 2018-01-26 06:49:27 --> Loader Class Initialized
INFO - 2018-01-26 06:49:27 --> Helper loaded: url_helper
INFO - 2018-01-26 06:49:27 --> Helper loaded: form_helper
INFO - 2018-01-26 06:49:27 --> Database Driver Class Initialized
DEBUG - 2018-01-26 06:49:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-26 06:49:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-26 06:49:27 --> Form Validation Class Initialized
INFO - 2018-01-26 06:49:27 --> Model Class Initialized
INFO - 2018-01-26 06:49:27 --> Controller Class Initialized
INFO - 2018-01-26 06:49:27 --> Model Class Initialized
DEBUG - 2018-01-26 06:49:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-26 06:49:27 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-26 06:49:27 --> Final output sent to browser
DEBUG - 2018-01-26 06:49:27 --> Total execution time: 0.0417
INFO - 2018-01-26 06:49:28 --> Config Class Initialized
INFO - 2018-01-26 06:49:28 --> Hooks Class Initialized
DEBUG - 2018-01-26 06:49:28 --> UTF-8 Support Enabled
INFO - 2018-01-26 06:49:28 --> Utf8 Class Initialized
INFO - 2018-01-26 06:49:28 --> URI Class Initialized
INFO - 2018-01-26 06:49:28 --> Router Class Initialized
INFO - 2018-01-26 06:49:28 --> Output Class Initialized
INFO - 2018-01-26 06:49:28 --> Security Class Initialized
DEBUG - 2018-01-26 06:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-26 06:49:28 --> Input Class Initialized
INFO - 2018-01-26 06:49:28 --> Language Class Initialized
INFO - 2018-01-26 06:49:28 --> Loader Class Initialized
INFO - 2018-01-26 06:49:28 --> Helper loaded: url_helper
INFO - 2018-01-26 06:49:28 --> Helper loaded: form_helper
INFO - 2018-01-26 06:49:28 --> Database Driver Class Initialized
DEBUG - 2018-01-26 06:49:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-26 06:49:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-26 06:49:28 --> Form Validation Class Initialized
INFO - 2018-01-26 06:49:28 --> Model Class Initialized
INFO - 2018-01-26 06:49:28 --> Controller Class Initialized
INFO - 2018-01-26 06:49:28 --> Model Class Initialized
DEBUG - 2018-01-26 06:49:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-26 06:49:58 --> Config Class Initialized
INFO - 2018-01-26 06:49:58 --> Hooks Class Initialized
DEBUG - 2018-01-26 06:49:58 --> UTF-8 Support Enabled
INFO - 2018-01-26 06:49:58 --> Utf8 Class Initialized
INFO - 2018-01-26 06:49:58 --> URI Class Initialized
INFO - 2018-01-26 06:49:58 --> Router Class Initialized
INFO - 2018-01-26 06:49:58 --> Output Class Initialized
INFO - 2018-01-26 06:49:58 --> Security Class Initialized
DEBUG - 2018-01-26 06:49:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-26 06:49:58 --> Input Class Initialized
INFO - 2018-01-26 06:49:58 --> Language Class Initialized
INFO - 2018-01-26 06:49:58 --> Loader Class Initialized
INFO - 2018-01-26 06:49:58 --> Helper loaded: url_helper
INFO - 2018-01-26 06:49:58 --> Helper loaded: form_helper
INFO - 2018-01-26 06:49:58 --> Database Driver Class Initialized
DEBUG - 2018-01-26 06:49:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-26 06:49:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-26 06:49:58 --> Form Validation Class Initialized
INFO - 2018-01-26 06:49:58 --> Model Class Initialized
INFO - 2018-01-26 06:49:58 --> Controller Class Initialized
INFO - 2018-01-26 06:49:58 --> Model Class Initialized
DEBUG - 2018-01-26 06:49:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-26 06:50:23 --> Config Class Initialized
INFO - 2018-01-26 06:50:23 --> Hooks Class Initialized
DEBUG - 2018-01-26 06:50:23 --> UTF-8 Support Enabled
INFO - 2018-01-26 06:50:23 --> Utf8 Class Initialized
INFO - 2018-01-26 06:50:23 --> URI Class Initialized
INFO - 2018-01-26 06:50:23 --> Router Class Initialized
INFO - 2018-01-26 06:50:23 --> Output Class Initialized
INFO - 2018-01-26 06:50:23 --> Security Class Initialized
DEBUG - 2018-01-26 06:50:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-26 06:50:23 --> Input Class Initialized
INFO - 2018-01-26 06:50:23 --> Language Class Initialized
INFO - 2018-01-26 06:50:23 --> Loader Class Initialized
INFO - 2018-01-26 06:50:23 --> Helper loaded: url_helper
INFO - 2018-01-26 06:50:23 --> Helper loaded: form_helper
INFO - 2018-01-26 06:50:23 --> Database Driver Class Initialized
DEBUG - 2018-01-26 06:50:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-26 06:50:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-26 06:50:23 --> Form Validation Class Initialized
INFO - 2018-01-26 06:50:23 --> Model Class Initialized
INFO - 2018-01-26 06:50:23 --> Controller Class Initialized
INFO - 2018-01-26 06:50:23 --> Model Class Initialized
DEBUG - 2018-01-26 06:50:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-26 06:50:23 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-26 06:50:23 --> Final output sent to browser
DEBUG - 2018-01-26 06:50:23 --> Total execution time: 0.0510
INFO - 2018-01-26 06:50:23 --> Config Class Initialized
INFO - 2018-01-26 06:50:23 --> Hooks Class Initialized
DEBUG - 2018-01-26 06:50:23 --> UTF-8 Support Enabled
INFO - 2018-01-26 06:50:23 --> Utf8 Class Initialized
INFO - 2018-01-26 06:50:23 --> URI Class Initialized
INFO - 2018-01-26 06:50:23 --> Router Class Initialized
INFO - 2018-01-26 06:50:23 --> Output Class Initialized
INFO - 2018-01-26 06:50:23 --> Security Class Initialized
DEBUG - 2018-01-26 06:50:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-26 06:50:23 --> Input Class Initialized
INFO - 2018-01-26 06:50:23 --> Language Class Initialized
INFO - 2018-01-26 06:50:23 --> Loader Class Initialized
INFO - 2018-01-26 06:50:23 --> Helper loaded: url_helper
INFO - 2018-01-26 06:50:23 --> Helper loaded: form_helper
INFO - 2018-01-26 06:50:23 --> Database Driver Class Initialized
DEBUG - 2018-01-26 06:50:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-26 06:50:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-26 06:50:23 --> Form Validation Class Initialized
INFO - 2018-01-26 06:50:23 --> Model Class Initialized
INFO - 2018-01-26 06:50:23 --> Controller Class Initialized
INFO - 2018-01-26 06:50:23 --> Model Class Initialized
DEBUG - 2018-01-26 06:50:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-26 06:50:41 --> Config Class Initialized
INFO - 2018-01-26 06:50:41 --> Hooks Class Initialized
DEBUG - 2018-01-26 06:50:41 --> UTF-8 Support Enabled
INFO - 2018-01-26 06:50:41 --> Utf8 Class Initialized
INFO - 2018-01-26 06:50:41 --> URI Class Initialized
INFO - 2018-01-26 06:50:41 --> Router Class Initialized
INFO - 2018-01-26 06:50:41 --> Output Class Initialized
INFO - 2018-01-26 06:50:41 --> Security Class Initialized
DEBUG - 2018-01-26 06:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-26 06:50:41 --> Input Class Initialized
INFO - 2018-01-26 06:50:41 --> Language Class Initialized
INFO - 2018-01-26 06:50:41 --> Loader Class Initialized
INFO - 2018-01-26 06:50:41 --> Helper loaded: url_helper
INFO - 2018-01-26 06:50:41 --> Helper loaded: form_helper
INFO - 2018-01-26 06:50:41 --> Database Driver Class Initialized
DEBUG - 2018-01-26 06:50:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-26 06:50:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-26 06:50:41 --> Form Validation Class Initialized
INFO - 2018-01-26 06:50:41 --> Model Class Initialized
INFO - 2018-01-26 06:50:41 --> Controller Class Initialized
INFO - 2018-01-26 06:50:41 --> Model Class Initialized
DEBUG - 2018-01-26 06:50:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-26 06:50:41 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-26 06:50:41 --> Final output sent to browser
DEBUG - 2018-01-26 06:50:41 --> Total execution time: 0.0552
INFO - 2018-01-26 06:50:42 --> Config Class Initialized
INFO - 2018-01-26 06:50:42 --> Hooks Class Initialized
DEBUG - 2018-01-26 06:50:42 --> UTF-8 Support Enabled
INFO - 2018-01-26 06:50:42 --> Utf8 Class Initialized
INFO - 2018-01-26 06:50:42 --> URI Class Initialized
INFO - 2018-01-26 06:50:42 --> Router Class Initialized
INFO - 2018-01-26 06:50:42 --> Output Class Initialized
INFO - 2018-01-26 06:50:42 --> Security Class Initialized
DEBUG - 2018-01-26 06:50:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-26 06:50:42 --> Input Class Initialized
INFO - 2018-01-26 06:50:42 --> Language Class Initialized
INFO - 2018-01-26 06:50:42 --> Loader Class Initialized
INFO - 2018-01-26 06:50:42 --> Helper loaded: url_helper
INFO - 2018-01-26 06:50:42 --> Helper loaded: form_helper
INFO - 2018-01-26 06:50:42 --> Database Driver Class Initialized
DEBUG - 2018-01-26 06:50:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-26 06:50:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-26 06:50:42 --> Form Validation Class Initialized
INFO - 2018-01-26 06:50:42 --> Model Class Initialized
INFO - 2018-01-26 06:50:42 --> Controller Class Initialized
INFO - 2018-01-26 06:50:42 --> Model Class Initialized
DEBUG - 2018-01-26 06:50:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-26 06:50:46 --> Config Class Initialized
INFO - 2018-01-26 06:50:46 --> Hooks Class Initialized
DEBUG - 2018-01-26 06:50:46 --> UTF-8 Support Enabled
INFO - 2018-01-26 06:50:46 --> Utf8 Class Initialized
INFO - 2018-01-26 06:50:46 --> URI Class Initialized
INFO - 2018-01-26 06:50:46 --> Router Class Initialized
INFO - 2018-01-26 06:50:46 --> Output Class Initialized
INFO - 2018-01-26 06:50:46 --> Security Class Initialized
DEBUG - 2018-01-26 06:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-26 06:50:46 --> Input Class Initialized
INFO - 2018-01-26 06:50:46 --> Language Class Initialized
INFO - 2018-01-26 06:50:46 --> Loader Class Initialized
INFO - 2018-01-26 06:50:46 --> Helper loaded: url_helper
INFO - 2018-01-26 06:50:46 --> Helper loaded: form_helper
INFO - 2018-01-26 06:50:46 --> Database Driver Class Initialized
DEBUG - 2018-01-26 06:50:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-26 06:50:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-26 06:50:46 --> Form Validation Class Initialized
INFO - 2018-01-26 06:50:46 --> Model Class Initialized
INFO - 2018-01-26 06:50:46 --> Controller Class Initialized
INFO - 2018-01-26 06:50:46 --> Model Class Initialized
DEBUG - 2018-01-26 06:50:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-26 06:50:46 --> Config Class Initialized
INFO - 2018-01-26 06:50:46 --> Hooks Class Initialized
DEBUG - 2018-01-26 06:50:46 --> UTF-8 Support Enabled
INFO - 2018-01-26 06:50:46 --> Utf8 Class Initialized
INFO - 2018-01-26 06:50:46 --> URI Class Initialized
INFO - 2018-01-26 06:50:46 --> Router Class Initialized
INFO - 2018-01-26 06:50:46 --> Output Class Initialized
INFO - 2018-01-26 06:50:46 --> Security Class Initialized
DEBUG - 2018-01-26 06:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-26 06:50:46 --> Input Class Initialized
INFO - 2018-01-26 06:50:46 --> Language Class Initialized
INFO - 2018-01-26 06:50:46 --> Loader Class Initialized
INFO - 2018-01-26 06:50:46 --> Helper loaded: url_helper
INFO - 2018-01-26 06:50:46 --> Helper loaded: form_helper
INFO - 2018-01-26 06:50:46 --> Database Driver Class Initialized
DEBUG - 2018-01-26 06:50:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-26 06:50:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-26 06:50:46 --> Form Validation Class Initialized
INFO - 2018-01-26 06:50:46 --> Model Class Initialized
INFO - 2018-01-26 06:50:46 --> Controller Class Initialized
INFO - 2018-01-26 06:50:46 --> Model Class Initialized
DEBUG - 2018-01-26 06:50:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-26 06:50:46 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-26 06:50:46 --> Final output sent to browser
DEBUG - 2018-01-26 06:50:46 --> Total execution time: 0.0469
INFO - 2018-01-26 06:50:46 --> Config Class Initialized
INFO - 2018-01-26 06:50:46 --> Hooks Class Initialized
DEBUG - 2018-01-26 06:50:46 --> UTF-8 Support Enabled
INFO - 2018-01-26 06:50:46 --> Utf8 Class Initialized
INFO - 2018-01-26 06:50:46 --> URI Class Initialized
INFO - 2018-01-26 06:50:46 --> Router Class Initialized
INFO - 2018-01-26 06:50:46 --> Output Class Initialized
INFO - 2018-01-26 06:50:46 --> Security Class Initialized
DEBUG - 2018-01-26 06:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-26 06:50:46 --> Input Class Initialized
INFO - 2018-01-26 06:50:46 --> Language Class Initialized
INFO - 2018-01-26 06:50:46 --> Loader Class Initialized
INFO - 2018-01-26 06:50:46 --> Helper loaded: url_helper
INFO - 2018-01-26 06:50:46 --> Helper loaded: form_helper
INFO - 2018-01-26 06:50:46 --> Database Driver Class Initialized
DEBUG - 2018-01-26 06:50:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-26 06:50:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-26 06:50:46 --> Form Validation Class Initialized
INFO - 2018-01-26 06:50:46 --> Model Class Initialized
INFO - 2018-01-26 06:50:46 --> Controller Class Initialized
INFO - 2018-01-26 06:50:46 --> Model Class Initialized
DEBUG - 2018-01-26 06:50:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-26 07:04:56 --> Config Class Initialized
INFO - 2018-01-26 07:04:56 --> Hooks Class Initialized
DEBUG - 2018-01-26 07:04:56 --> UTF-8 Support Enabled
INFO - 2018-01-26 07:04:56 --> Utf8 Class Initialized
INFO - 2018-01-26 07:04:56 --> URI Class Initialized
INFO - 2018-01-26 07:04:56 --> Router Class Initialized
INFO - 2018-01-26 07:04:56 --> Output Class Initialized
INFO - 2018-01-26 07:04:56 --> Security Class Initialized
DEBUG - 2018-01-26 07:04:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-26 07:04:56 --> Input Class Initialized
INFO - 2018-01-26 07:04:56 --> Language Class Initialized
INFO - 2018-01-26 07:04:56 --> Loader Class Initialized
INFO - 2018-01-26 07:04:56 --> Helper loaded: url_helper
INFO - 2018-01-26 07:04:56 --> Helper loaded: form_helper
INFO - 2018-01-26 07:04:56 --> Database Driver Class Initialized
DEBUG - 2018-01-26 07:04:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-26 07:04:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-26 07:04:56 --> Form Validation Class Initialized
INFO - 2018-01-26 07:04:56 --> Model Class Initialized
INFO - 2018-01-26 07:04:56 --> Controller Class Initialized
INFO - 2018-01-26 07:04:56 --> Model Class Initialized
DEBUG - 2018-01-26 07:04:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-26 07:04:56 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-26 07:04:56 --> Final output sent to browser
DEBUG - 2018-01-26 07:04:56 --> Total execution time: 0.0387
INFO - 2018-01-26 07:04:57 --> Config Class Initialized
INFO - 2018-01-26 07:04:57 --> Hooks Class Initialized
DEBUG - 2018-01-26 07:04:57 --> UTF-8 Support Enabled
INFO - 2018-01-26 07:04:57 --> Utf8 Class Initialized
INFO - 2018-01-26 07:04:57 --> URI Class Initialized
INFO - 2018-01-26 07:04:57 --> Router Class Initialized
INFO - 2018-01-26 07:04:57 --> Output Class Initialized
INFO - 2018-01-26 07:04:57 --> Security Class Initialized
DEBUG - 2018-01-26 07:04:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-26 07:04:57 --> Input Class Initialized
INFO - 2018-01-26 07:04:57 --> Language Class Initialized
INFO - 2018-01-26 07:04:57 --> Loader Class Initialized
INFO - 2018-01-26 07:04:57 --> Helper loaded: url_helper
INFO - 2018-01-26 07:04:57 --> Helper loaded: form_helper
INFO - 2018-01-26 07:04:57 --> Database Driver Class Initialized
DEBUG - 2018-01-26 07:04:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-26 07:04:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-26 07:04:57 --> Form Validation Class Initialized
INFO - 2018-01-26 07:04:57 --> Model Class Initialized
INFO - 2018-01-26 07:04:57 --> Controller Class Initialized
INFO - 2018-01-26 07:04:57 --> Model Class Initialized
DEBUG - 2018-01-26 07:04:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-26 07:04:57 --> Config Class Initialized
INFO - 2018-01-26 07:04:57 --> Hooks Class Initialized
DEBUG - 2018-01-26 07:04:57 --> UTF-8 Support Enabled
INFO - 2018-01-26 07:04:57 --> Utf8 Class Initialized
INFO - 2018-01-26 07:04:57 --> URI Class Initialized
INFO - 2018-01-26 07:04:57 --> Router Class Initialized
INFO - 2018-01-26 07:04:57 --> Output Class Initialized
INFO - 2018-01-26 07:04:57 --> Security Class Initialized
DEBUG - 2018-01-26 07:04:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-26 07:04:57 --> Input Class Initialized
INFO - 2018-01-26 07:04:57 --> Language Class Initialized
INFO - 2018-01-26 07:04:57 --> Loader Class Initialized
INFO - 2018-01-26 07:04:57 --> Helper loaded: url_helper
INFO - 2018-01-26 07:04:57 --> Helper loaded: form_helper
INFO - 2018-01-26 07:04:57 --> Database Driver Class Initialized
DEBUG - 2018-01-26 07:04:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-26 07:04:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-26 07:04:57 --> Form Validation Class Initialized
INFO - 2018-01-26 07:04:57 --> Model Class Initialized
INFO - 2018-01-26 07:04:57 --> Controller Class Initialized
INFO - 2018-01-26 07:04:57 --> Model Class Initialized
INFO - 2018-01-26 07:04:57 --> Model Class Initialized
INFO - 2018-01-26 07:04:57 --> Model Class Initialized
INFO - 2018-01-26 07:04:57 --> Model Class Initialized
DEBUG - 2018-01-26 07:04:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-26 07:04:57 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-26 07:04:57 --> Final output sent to browser
DEBUG - 2018-01-26 07:04:57 --> Total execution time: 0.0440
INFO - 2018-01-26 07:04:58 --> Config Class Initialized
INFO - 2018-01-26 07:04:58 --> Hooks Class Initialized
DEBUG - 2018-01-26 07:04:58 --> UTF-8 Support Enabled
INFO - 2018-01-26 07:04:58 --> Utf8 Class Initialized
INFO - 2018-01-26 07:04:58 --> URI Class Initialized
INFO - 2018-01-26 07:04:58 --> Router Class Initialized
INFO - 2018-01-26 07:04:58 --> Output Class Initialized
INFO - 2018-01-26 07:04:58 --> Security Class Initialized
DEBUG - 2018-01-26 07:04:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-26 07:04:58 --> Input Class Initialized
INFO - 2018-01-26 07:04:58 --> Language Class Initialized
INFO - 2018-01-26 07:04:58 --> Loader Class Initialized
INFO - 2018-01-26 07:04:58 --> Helper loaded: url_helper
INFO - 2018-01-26 07:04:58 --> Helper loaded: form_helper
INFO - 2018-01-26 07:04:58 --> Database Driver Class Initialized
DEBUG - 2018-01-26 07:04:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-26 07:04:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-26 07:04:58 --> Form Validation Class Initialized
INFO - 2018-01-26 07:04:58 --> Model Class Initialized
INFO - 2018-01-26 07:04:58 --> Controller Class Initialized
INFO - 2018-01-26 07:04:58 --> Model Class Initialized
INFO - 2018-01-26 07:04:58 --> Model Class Initialized
DEBUG - 2018-01-26 07:04:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-26 07:04:58 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-26 07:04:58 --> Final output sent to browser
DEBUG - 2018-01-26 07:04:58 --> Total execution time: 0.0389
INFO - 2018-01-26 07:04:58 --> Config Class Initialized
INFO - 2018-01-26 07:04:58 --> Hooks Class Initialized
DEBUG - 2018-01-26 07:04:58 --> UTF-8 Support Enabled
INFO - 2018-01-26 07:04:58 --> Utf8 Class Initialized
INFO - 2018-01-26 07:04:58 --> URI Class Initialized
INFO - 2018-01-26 07:04:58 --> Router Class Initialized
INFO - 2018-01-26 07:04:58 --> Output Class Initialized
INFO - 2018-01-26 07:04:58 --> Security Class Initialized
DEBUG - 2018-01-26 07:04:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-26 07:04:58 --> Input Class Initialized
INFO - 2018-01-26 07:04:58 --> Language Class Initialized
INFO - 2018-01-26 07:04:58 --> Loader Class Initialized
INFO - 2018-01-26 07:04:58 --> Helper loaded: url_helper
INFO - 2018-01-26 07:04:58 --> Helper loaded: form_helper
INFO - 2018-01-26 07:04:58 --> Database Driver Class Initialized
DEBUG - 2018-01-26 07:04:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-26 07:04:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-26 07:04:58 --> Form Validation Class Initialized
INFO - 2018-01-26 07:04:58 --> Model Class Initialized
INFO - 2018-01-26 07:04:58 --> Controller Class Initialized
INFO - 2018-01-26 07:04:58 --> Model Class Initialized
INFO - 2018-01-26 07:04:58 --> Model Class Initialized
DEBUG - 2018-01-26 07:04:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-26 07:04:59 --> Config Class Initialized
INFO - 2018-01-26 07:04:59 --> Hooks Class Initialized
DEBUG - 2018-01-26 07:04:59 --> UTF-8 Support Enabled
INFO - 2018-01-26 07:04:59 --> Utf8 Class Initialized
INFO - 2018-01-26 07:04:59 --> URI Class Initialized
INFO - 2018-01-26 07:04:59 --> Router Class Initialized
INFO - 2018-01-26 07:04:59 --> Output Class Initialized
INFO - 2018-01-26 07:04:59 --> Security Class Initialized
DEBUG - 2018-01-26 07:04:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-26 07:04:59 --> Input Class Initialized
INFO - 2018-01-26 07:04:59 --> Language Class Initialized
INFO - 2018-01-26 07:04:59 --> Loader Class Initialized
INFO - 2018-01-26 07:04:59 --> Helper loaded: url_helper
INFO - 2018-01-26 07:04:59 --> Helper loaded: form_helper
INFO - 2018-01-26 07:04:59 --> Database Driver Class Initialized
DEBUG - 2018-01-26 07:04:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-26 07:04:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-26 07:04:59 --> Form Validation Class Initialized
INFO - 2018-01-26 07:04:59 --> Model Class Initialized
INFO - 2018-01-26 07:04:59 --> Controller Class Initialized
INFO - 2018-01-26 07:04:59 --> Model Class Initialized
INFO - 2018-01-26 07:04:59 --> Model Class Initialized
DEBUG - 2018-01-26 07:04:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-26 07:04:59 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-26 07:04:59 --> Final output sent to browser
DEBUG - 2018-01-26 07:04:59 --> Total execution time: 0.0362
INFO - 2018-01-26 07:04:59 --> Config Class Initialized
INFO - 2018-01-26 07:04:59 --> Hooks Class Initialized
DEBUG - 2018-01-26 07:04:59 --> UTF-8 Support Enabled
INFO - 2018-01-26 07:04:59 --> Utf8 Class Initialized
INFO - 2018-01-26 07:04:59 --> URI Class Initialized
INFO - 2018-01-26 07:04:59 --> Router Class Initialized
INFO - 2018-01-26 07:04:59 --> Output Class Initialized
INFO - 2018-01-26 07:04:59 --> Security Class Initialized
DEBUG - 2018-01-26 07:04:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-26 07:04:59 --> Input Class Initialized
INFO - 2018-01-26 07:04:59 --> Language Class Initialized
INFO - 2018-01-26 07:04:59 --> Loader Class Initialized
INFO - 2018-01-26 07:04:59 --> Helper loaded: url_helper
INFO - 2018-01-26 07:04:59 --> Helper loaded: form_helper
INFO - 2018-01-26 07:04:59 --> Database Driver Class Initialized
DEBUG - 2018-01-26 07:04:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-26 07:04:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-26 07:04:59 --> Form Validation Class Initialized
INFO - 2018-01-26 07:04:59 --> Model Class Initialized
INFO - 2018-01-26 07:04:59 --> Controller Class Initialized
INFO - 2018-01-26 07:04:59 --> Model Class Initialized
INFO - 2018-01-26 07:04:59 --> Model Class Initialized
DEBUG - 2018-01-26 07:04:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-26 07:05:01 --> Config Class Initialized
INFO - 2018-01-26 07:05:01 --> Hooks Class Initialized
DEBUG - 2018-01-26 07:05:01 --> UTF-8 Support Enabled
INFO - 2018-01-26 07:05:01 --> Utf8 Class Initialized
INFO - 2018-01-26 07:05:01 --> URI Class Initialized
INFO - 2018-01-26 07:05:01 --> Router Class Initialized
INFO - 2018-01-26 07:05:01 --> Output Class Initialized
INFO - 2018-01-26 07:05:01 --> Security Class Initialized
DEBUG - 2018-01-26 07:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-26 07:05:01 --> Input Class Initialized
INFO - 2018-01-26 07:05:01 --> Language Class Initialized
INFO - 2018-01-26 07:05:01 --> Loader Class Initialized
INFO - 2018-01-26 07:05:01 --> Helper loaded: url_helper
INFO - 2018-01-26 07:05:01 --> Helper loaded: form_helper
INFO - 2018-01-26 07:05:01 --> Database Driver Class Initialized
DEBUG - 2018-01-26 07:05:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-26 07:05:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-26 07:05:01 --> Form Validation Class Initialized
INFO - 2018-01-26 07:05:01 --> Model Class Initialized
INFO - 2018-01-26 07:05:01 --> Controller Class Initialized
INFO - 2018-01-26 07:05:01 --> Model Class Initialized
INFO - 2018-01-26 07:05:01 --> Model Class Initialized
DEBUG - 2018-01-26 07:05:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-26 07:05:01 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-26 07:05:01 --> Final output sent to browser
DEBUG - 2018-01-26 07:05:01 --> Total execution time: 0.0365
INFO - 2018-01-26 07:05:01 --> Config Class Initialized
INFO - 2018-01-26 07:05:01 --> Hooks Class Initialized
DEBUG - 2018-01-26 07:05:01 --> UTF-8 Support Enabled
INFO - 2018-01-26 07:05:01 --> Utf8 Class Initialized
INFO - 2018-01-26 07:05:01 --> URI Class Initialized
INFO - 2018-01-26 07:05:01 --> Router Class Initialized
INFO - 2018-01-26 07:05:01 --> Output Class Initialized
INFO - 2018-01-26 07:05:01 --> Security Class Initialized
DEBUG - 2018-01-26 07:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-26 07:05:01 --> Input Class Initialized
INFO - 2018-01-26 07:05:01 --> Language Class Initialized
INFO - 2018-01-26 07:05:01 --> Loader Class Initialized
INFO - 2018-01-26 07:05:01 --> Helper loaded: url_helper
INFO - 2018-01-26 07:05:01 --> Helper loaded: form_helper
INFO - 2018-01-26 07:05:01 --> Database Driver Class Initialized
DEBUG - 2018-01-26 07:05:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-26 07:05:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-26 07:05:01 --> Form Validation Class Initialized
INFO - 2018-01-26 07:05:01 --> Model Class Initialized
INFO - 2018-01-26 07:05:01 --> Controller Class Initialized
INFO - 2018-01-26 07:05:01 --> Model Class Initialized
INFO - 2018-01-26 07:05:01 --> Model Class Initialized
DEBUG - 2018-01-26 07:05:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-26 07:05:02 --> Config Class Initialized
INFO - 2018-01-26 07:05:02 --> Hooks Class Initialized
DEBUG - 2018-01-26 07:05:02 --> UTF-8 Support Enabled
INFO - 2018-01-26 07:05:02 --> Utf8 Class Initialized
INFO - 2018-01-26 07:05:02 --> URI Class Initialized
INFO - 2018-01-26 07:05:02 --> Router Class Initialized
INFO - 2018-01-26 07:05:02 --> Output Class Initialized
INFO - 2018-01-26 07:05:02 --> Security Class Initialized
DEBUG - 2018-01-26 07:05:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-26 07:05:02 --> Input Class Initialized
INFO - 2018-01-26 07:05:02 --> Language Class Initialized
INFO - 2018-01-26 07:05:02 --> Loader Class Initialized
INFO - 2018-01-26 07:05:02 --> Helper loaded: url_helper
INFO - 2018-01-26 07:05:02 --> Helper loaded: form_helper
INFO - 2018-01-26 07:05:02 --> Database Driver Class Initialized
DEBUG - 2018-01-26 07:05:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-26 07:05:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-26 07:05:02 --> Form Validation Class Initialized
INFO - 2018-01-26 07:05:02 --> Model Class Initialized
INFO - 2018-01-26 07:05:02 --> Controller Class Initialized
INFO - 2018-01-26 07:05:02 --> Model Class Initialized
INFO - 2018-01-26 07:05:02 --> Model Class Initialized
INFO - 2018-01-26 07:05:02 --> Model Class Initialized
INFO - 2018-01-26 07:05:02 --> Model Class Initialized
DEBUG - 2018-01-26 07:05:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-26 07:05:02 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-26 07:05:02 --> Final output sent to browser
DEBUG - 2018-01-26 07:05:02 --> Total execution time: 0.0547
INFO - 2018-01-26 07:05:02 --> Config Class Initialized
INFO - 2018-01-26 07:05:02 --> Hooks Class Initialized
DEBUG - 2018-01-26 07:05:02 --> UTF-8 Support Enabled
INFO - 2018-01-26 07:05:02 --> Utf8 Class Initialized
INFO - 2018-01-26 07:05:02 --> URI Class Initialized
INFO - 2018-01-26 07:05:02 --> Router Class Initialized
INFO - 2018-01-26 07:05:02 --> Output Class Initialized
INFO - 2018-01-26 07:05:02 --> Security Class Initialized
DEBUG - 2018-01-26 07:05:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-26 07:05:02 --> Input Class Initialized
INFO - 2018-01-26 07:05:02 --> Language Class Initialized
INFO - 2018-01-26 07:05:02 --> Loader Class Initialized
INFO - 2018-01-26 07:05:02 --> Helper loaded: url_helper
INFO - 2018-01-26 07:05:02 --> Helper loaded: form_helper
INFO - 2018-01-26 07:05:02 --> Database Driver Class Initialized
DEBUG - 2018-01-26 07:05:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-26 07:05:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-26 07:05:02 --> Form Validation Class Initialized
INFO - 2018-01-26 07:05:02 --> Model Class Initialized
INFO - 2018-01-26 07:05:02 --> Controller Class Initialized
INFO - 2018-01-26 07:05:02 --> Model Class Initialized
INFO - 2018-01-26 07:05:02 --> Model Class Initialized
INFO - 2018-01-26 07:05:02 --> Model Class Initialized
INFO - 2018-01-26 07:05:02 --> Model Class Initialized
DEBUG - 2018-01-26 07:05:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-26 07:05:03 --> Config Class Initialized
INFO - 2018-01-26 07:05:03 --> Hooks Class Initialized
DEBUG - 2018-01-26 07:05:03 --> UTF-8 Support Enabled
INFO - 2018-01-26 07:05:03 --> Utf8 Class Initialized
INFO - 2018-01-26 07:05:03 --> URI Class Initialized
DEBUG - 2018-01-26 07:05:03 --> No URI present. Default controller set.
INFO - 2018-01-26 07:05:03 --> Router Class Initialized
INFO - 2018-01-26 07:05:03 --> Output Class Initialized
INFO - 2018-01-26 07:05:03 --> Security Class Initialized
DEBUG - 2018-01-26 07:05:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-26 07:05:03 --> Input Class Initialized
INFO - 2018-01-26 07:05:03 --> Language Class Initialized
INFO - 2018-01-26 07:05:03 --> Loader Class Initialized
INFO - 2018-01-26 07:05:03 --> Helper loaded: url_helper
INFO - 2018-01-26 07:05:03 --> Helper loaded: form_helper
INFO - 2018-01-26 07:05:03 --> Database Driver Class Initialized
DEBUG - 2018-01-26 07:05:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-26 07:05:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-26 07:05:03 --> Form Validation Class Initialized
INFO - 2018-01-26 07:05:03 --> Model Class Initialized
INFO - 2018-01-26 07:05:03 --> Controller Class Initialized
INFO - 2018-01-26 07:05:03 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-26 07:05:03 --> Final output sent to browser
DEBUG - 2018-01-26 07:05:03 --> Total execution time: 0.0414
INFO - 2018-01-26 07:05:03 --> Config Class Initialized
INFO - 2018-01-26 07:05:03 --> Hooks Class Initialized
DEBUG - 2018-01-26 07:05:03 --> UTF-8 Support Enabled
INFO - 2018-01-26 07:05:03 --> Utf8 Class Initialized
INFO - 2018-01-26 07:05:03 --> URI Class Initialized
INFO - 2018-01-26 07:05:03 --> Router Class Initialized
INFO - 2018-01-26 07:05:03 --> Output Class Initialized
INFO - 2018-01-26 07:05:03 --> Security Class Initialized
DEBUG - 2018-01-26 07:05:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-26 07:05:03 --> Input Class Initialized
INFO - 2018-01-26 07:05:03 --> Language Class Initialized
INFO - 2018-01-26 07:05:03 --> Loader Class Initialized
INFO - 2018-01-26 07:05:03 --> Helper loaded: url_helper
INFO - 2018-01-26 07:05:03 --> Helper loaded: form_helper
INFO - 2018-01-26 07:05:03 --> Database Driver Class Initialized
DEBUG - 2018-01-26 07:05:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-26 07:05:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-26 07:05:03 --> Form Validation Class Initialized
INFO - 2018-01-26 07:05:03 --> Model Class Initialized
INFO - 2018-01-26 07:05:03 --> Controller Class Initialized
INFO - 2018-01-26 07:05:03 --> Model Class Initialized
INFO - 2018-01-26 07:05:03 --> Model Class Initialized
INFO - 2018-01-26 07:05:03 --> Model Class Initialized
INFO - 2018-01-26 07:05:03 --> Model Class Initialized
DEBUG - 2018-01-26 07:05:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-26 07:05:05 --> Config Class Initialized
INFO - 2018-01-26 07:05:05 --> Hooks Class Initialized
DEBUG - 2018-01-26 07:05:05 --> UTF-8 Support Enabled
INFO - 2018-01-26 07:05:05 --> Utf8 Class Initialized
INFO - 2018-01-26 07:05:05 --> URI Class Initialized
INFO - 2018-01-26 07:05:05 --> Router Class Initialized
INFO - 2018-01-26 07:05:05 --> Output Class Initialized
INFO - 2018-01-26 07:05:05 --> Security Class Initialized
DEBUG - 2018-01-26 07:05:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-26 07:05:05 --> Input Class Initialized
INFO - 2018-01-26 07:05:05 --> Language Class Initialized
INFO - 2018-01-26 07:05:05 --> Loader Class Initialized
INFO - 2018-01-26 07:05:05 --> Helper loaded: url_helper
INFO - 2018-01-26 07:05:05 --> Helper loaded: form_helper
INFO - 2018-01-26 07:05:05 --> Database Driver Class Initialized
DEBUG - 2018-01-26 07:05:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-26 07:05:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-26 07:05:05 --> Form Validation Class Initialized
INFO - 2018-01-26 07:05:05 --> Model Class Initialized
INFO - 2018-01-26 07:05:05 --> Controller Class Initialized
INFO - 2018-01-26 07:05:05 --> Model Class Initialized
INFO - 2018-01-26 07:05:05 --> Model Class Initialized
INFO - 2018-01-26 07:05:05 --> Model Class Initialized
INFO - 2018-01-26 07:05:05 --> Model Class Initialized
DEBUG - 2018-01-26 07:05:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-26 07:05:05 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-26 07:05:05 --> Final output sent to browser
DEBUG - 2018-01-26 07:05:05 --> Total execution time: 0.0512
INFO - 2018-01-26 07:05:05 --> Config Class Initialized
INFO - 2018-01-26 07:05:05 --> Hooks Class Initialized
DEBUG - 2018-01-26 07:05:05 --> UTF-8 Support Enabled
INFO - 2018-01-26 07:05:05 --> Utf8 Class Initialized
INFO - 2018-01-26 07:05:05 --> URI Class Initialized
INFO - 2018-01-26 07:05:05 --> Router Class Initialized
INFO - 2018-01-26 07:05:05 --> Output Class Initialized
INFO - 2018-01-26 07:05:05 --> Security Class Initialized
DEBUG - 2018-01-26 07:05:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-26 07:05:05 --> Input Class Initialized
INFO - 2018-01-26 07:05:05 --> Language Class Initialized
INFO - 2018-01-26 07:05:05 --> Loader Class Initialized
INFO - 2018-01-26 07:05:05 --> Helper loaded: url_helper
INFO - 2018-01-26 07:05:05 --> Helper loaded: form_helper
INFO - 2018-01-26 07:05:05 --> Database Driver Class Initialized
DEBUG - 2018-01-26 07:05:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-26 07:05:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-26 07:05:05 --> Form Validation Class Initialized
INFO - 2018-01-26 07:05:05 --> Model Class Initialized
INFO - 2018-01-26 07:05:05 --> Controller Class Initialized
INFO - 2018-01-26 07:05:05 --> Model Class Initialized
INFO - 2018-01-26 07:05:05 --> Model Class Initialized
INFO - 2018-01-26 07:05:05 --> Model Class Initialized
INFO - 2018-01-26 07:05:05 --> Model Class Initialized
DEBUG - 2018-01-26 07:05:05 --> Form_validation class already loaded. Second attempt ignored.
