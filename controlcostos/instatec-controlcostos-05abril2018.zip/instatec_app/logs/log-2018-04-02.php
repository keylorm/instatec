<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-04-02 00:00:01 --> Config Class Initialized
INFO - 2018-04-02 00:00:01 --> Hooks Class Initialized
DEBUG - 2018-04-02 00:00:01 --> UTF-8 Support Enabled
INFO - 2018-04-02 00:00:01 --> Utf8 Class Initialized
INFO - 2018-04-02 00:00:01 --> URI Class Initialized
INFO - 2018-04-02 00:00:01 --> Router Class Initialized
INFO - 2018-04-02 00:00:01 --> Output Class Initialized
INFO - 2018-04-02 00:00:01 --> Security Class Initialized
DEBUG - 2018-04-02 00:00:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 00:00:01 --> Input Class Initialized
INFO - 2018-04-02 00:00:01 --> Language Class Initialized
INFO - 2018-04-02 00:00:01 --> Loader Class Initialized
INFO - 2018-04-02 00:00:01 --> Helper loaded: url_helper
INFO - 2018-04-02 00:00:01 --> Helper loaded: form_helper
INFO - 2018-04-02 00:00:01 --> Database Driver Class Initialized
DEBUG - 2018-04-02 00:00:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 00:00:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 00:00:02 --> Form Validation Class Initialized
INFO - 2018-04-02 00:00:02 --> Model Class Initialized
INFO - 2018-04-02 00:00:02 --> Controller Class Initialized
INFO - 2018-04-02 00:00:02 --> Model Class Initialized
INFO - 2018-04-02 00:00:02 --> Model Class Initialized
INFO - 2018-04-02 00:00:02 --> Model Class Initialized
INFO - 2018-04-02 00:00:02 --> Model Class Initialized
DEBUG - 2018-04-02 00:00:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-02 00:00:03 --> Config Class Initialized
INFO - 2018-04-02 00:00:03 --> Hooks Class Initialized
INFO - 2018-04-02 00:00:03 --> Config Class Initialized
INFO - 2018-04-02 00:00:03 --> Hooks Class Initialized
INFO - 2018-04-02 00:00:03 --> Config Class Initialized
INFO - 2018-04-02 00:00:03 --> Hooks Class Initialized
DEBUG - 2018-04-02 00:00:03 --> UTF-8 Support Enabled
DEBUG - 2018-04-02 00:00:03 --> UTF-8 Support Enabled
INFO - 2018-04-02 00:00:03 --> Utf8 Class Initialized
INFO - 2018-04-02 00:00:03 --> Utf8 Class Initialized
DEBUG - 2018-04-02 00:00:03 --> UTF-8 Support Enabled
INFO - 2018-04-02 00:00:03 --> Utf8 Class Initialized
INFO - 2018-04-02 00:00:03 --> URI Class Initialized
INFO - 2018-04-02 00:00:03 --> URI Class Initialized
INFO - 2018-04-02 00:00:03 --> Config Class Initialized
INFO - 2018-04-02 00:00:03 --> URI Class Initialized
INFO - 2018-04-02 00:00:03 --> Hooks Class Initialized
INFO - 2018-04-02 00:00:03 --> Router Class Initialized
INFO - 2018-04-02 00:00:03 --> Router Class Initialized
INFO - 2018-04-02 00:00:03 --> Router Class Initialized
INFO - 2018-04-02 00:00:03 --> Output Class Initialized
DEBUG - 2018-04-02 00:00:03 --> UTF-8 Support Enabled
INFO - 2018-04-02 00:00:03 --> Output Class Initialized
INFO - 2018-04-02 00:00:03 --> Utf8 Class Initialized
INFO - 2018-04-02 00:00:03 --> Output Class Initialized
INFO - 2018-04-02 00:00:03 --> Security Class Initialized
INFO - 2018-04-02 00:00:03 --> URI Class Initialized
INFO - 2018-04-02 00:00:03 --> Security Class Initialized
INFO - 2018-04-02 00:00:03 --> Security Class Initialized
DEBUG - 2018-04-02 00:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 00:00:03 --> Input Class Initialized
INFO - 2018-04-02 00:00:03 --> Language Class Initialized
DEBUG - 2018-04-02 00:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-02 00:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 00:00:03 --> Router Class Initialized
INFO - 2018-04-02 00:00:03 --> Input Class Initialized
INFO - 2018-04-02 00:00:03 --> Input Class Initialized
INFO - 2018-04-02 00:00:03 --> Language Class Initialized
INFO - 2018-04-02 00:00:03 --> Language Class Initialized
ERROR - 2018-04-02 00:00:03 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-04-02 00:00:03 --> Output Class Initialized
ERROR - 2018-04-02 00:00:03 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-04-02 00:00:03 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-04-02 00:00:03 --> Security Class Initialized
DEBUG - 2018-04-02 00:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 00:00:03 --> Input Class Initialized
INFO - 2018-04-02 00:00:03 --> Language Class Initialized
ERROR - 2018-04-02 00:00:03 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-04-02 00:00:03 --> Config Class Initialized
INFO - 2018-04-02 00:00:03 --> Hooks Class Initialized
INFO - 2018-04-02 00:00:03 --> Config Class Initialized
INFO - 2018-04-02 00:00:03 --> Hooks Class Initialized
INFO - 2018-04-02 00:00:03 --> Config Class Initialized
INFO - 2018-04-02 00:00:03 --> Hooks Class Initialized
DEBUG - 2018-04-02 00:00:03 --> UTF-8 Support Enabled
INFO - 2018-04-02 00:00:03 --> Utf8 Class Initialized
DEBUG - 2018-04-02 00:00:03 --> UTF-8 Support Enabled
INFO - 2018-04-02 00:00:03 --> Utf8 Class Initialized
INFO - 2018-04-02 00:00:03 --> URI Class Initialized
DEBUG - 2018-04-02 00:00:03 --> UTF-8 Support Enabled
INFO - 2018-04-02 00:00:03 --> Utf8 Class Initialized
INFO - 2018-04-02 00:00:03 --> URI Class Initialized
INFO - 2018-04-02 00:00:03 --> Router Class Initialized
INFO - 2018-04-02 00:00:03 --> URI Class Initialized
INFO - 2018-04-02 00:00:03 --> Router Class Initialized
INFO - 2018-04-02 00:00:03 --> Output Class Initialized
INFO - 2018-04-02 00:00:03 --> Router Class Initialized
INFO - 2018-04-02 00:00:03 --> Output Class Initialized
INFO - 2018-04-02 00:00:03 --> Security Class Initialized
INFO - 2018-04-02 00:00:03 --> Output Class Initialized
INFO - 2018-04-02 00:00:03 --> Security Class Initialized
INFO - 2018-04-02 00:00:03 --> Security Class Initialized
DEBUG - 2018-04-02 00:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-02 00:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 00:00:03 --> Input Class Initialized
INFO - 2018-04-02 00:00:03 --> Input Class Initialized
DEBUG - 2018-04-02 00:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 00:00:03 --> Language Class Initialized
INFO - 2018-04-02 00:00:03 --> Language Class Initialized
INFO - 2018-04-02 00:00:03 --> Input Class Initialized
INFO - 2018-04-02 00:00:03 --> Language Class Initialized
ERROR - 2018-04-02 00:00:03 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-04-02 00:00:03 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-04-02 00:00:03 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-04-02 00:00:05 --> Config Class Initialized
INFO - 2018-04-02 00:00:05 --> Hooks Class Initialized
DEBUG - 2018-04-02 00:00:05 --> UTF-8 Support Enabled
INFO - 2018-04-02 00:00:05 --> Utf8 Class Initialized
INFO - 2018-04-02 00:00:05 --> URI Class Initialized
INFO - 2018-04-02 00:00:05 --> Router Class Initialized
INFO - 2018-04-02 00:00:05 --> Output Class Initialized
INFO - 2018-04-02 00:00:05 --> Security Class Initialized
DEBUG - 2018-04-02 00:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 00:00:05 --> Input Class Initialized
INFO - 2018-04-02 00:00:05 --> Language Class Initialized
INFO - 2018-04-02 00:00:05 --> Loader Class Initialized
INFO - 2018-04-02 00:00:05 --> Helper loaded: url_helper
INFO - 2018-04-02 00:00:05 --> Helper loaded: form_helper
INFO - 2018-04-02 00:00:05 --> Database Driver Class Initialized
DEBUG - 2018-04-02 00:00:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 00:00:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 00:00:05 --> Form Validation Class Initialized
INFO - 2018-04-02 00:00:05 --> Model Class Initialized
INFO - 2018-04-02 00:00:05 --> Controller Class Initialized
INFO - 2018-04-02 00:00:05 --> Model Class Initialized
INFO - 2018-04-02 00:00:05 --> Model Class Initialized
INFO - 2018-04-02 00:00:05 --> Model Class Initialized
INFO - 2018-04-02 00:00:05 --> Model Class Initialized
DEBUG - 2018-04-02 00:00:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-02 00:00:19 --> Config Class Initialized
INFO - 2018-04-02 00:00:19 --> Hooks Class Initialized
DEBUG - 2018-04-02 00:00:19 --> UTF-8 Support Enabled
INFO - 2018-04-02 00:00:19 --> Utf8 Class Initialized
INFO - 2018-04-02 00:00:19 --> URI Class Initialized
INFO - 2018-04-02 00:00:19 --> Router Class Initialized
INFO - 2018-04-02 00:00:19 --> Output Class Initialized
INFO - 2018-04-02 00:00:19 --> Security Class Initialized
DEBUG - 2018-04-02 00:00:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 00:00:19 --> Input Class Initialized
INFO - 2018-04-02 00:00:19 --> Language Class Initialized
INFO - 2018-04-02 00:00:19 --> Loader Class Initialized
INFO - 2018-04-02 00:00:19 --> Helper loaded: url_helper
INFO - 2018-04-02 00:00:19 --> Helper loaded: form_helper
INFO - 2018-04-02 00:00:19 --> Database Driver Class Initialized
DEBUG - 2018-04-02 00:00:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 00:00:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 00:00:19 --> Form Validation Class Initialized
INFO - 2018-04-02 00:00:19 --> Model Class Initialized
INFO - 2018-04-02 00:00:19 --> Controller Class Initialized
INFO - 2018-04-02 00:00:19 --> Model Class Initialized
INFO - 2018-04-02 00:00:19 --> Model Class Initialized
INFO - 2018-04-02 00:00:19 --> Model Class Initialized
INFO - 2018-04-02 00:00:19 --> Model Class Initialized
INFO - 2018-04-02 00:00:19 --> Model Class Initialized
DEBUG - 2018-04-02 00:00:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-02 00:01:13 --> Config Class Initialized
INFO - 2018-04-02 00:01:13 --> Hooks Class Initialized
DEBUG - 2018-04-02 00:01:13 --> UTF-8 Support Enabled
INFO - 2018-04-02 00:01:13 --> Utf8 Class Initialized
INFO - 2018-04-02 00:01:13 --> URI Class Initialized
INFO - 2018-04-02 00:01:13 --> Router Class Initialized
INFO - 2018-04-02 00:01:13 --> Output Class Initialized
INFO - 2018-04-02 00:01:13 --> Security Class Initialized
DEBUG - 2018-04-02 00:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 00:01:13 --> Input Class Initialized
INFO - 2018-04-02 00:01:13 --> Language Class Initialized
INFO - 2018-04-02 00:01:13 --> Loader Class Initialized
INFO - 2018-04-02 00:01:13 --> Helper loaded: url_helper
INFO - 2018-04-02 00:01:13 --> Helper loaded: form_helper
INFO - 2018-04-02 00:01:13 --> Database Driver Class Initialized
DEBUG - 2018-04-02 00:01:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 00:01:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 00:01:13 --> Form Validation Class Initialized
INFO - 2018-04-02 00:01:13 --> Model Class Initialized
INFO - 2018-04-02 00:01:13 --> Controller Class Initialized
INFO - 2018-04-02 00:01:13 --> Model Class Initialized
INFO - 2018-04-02 00:01:13 --> Model Class Initialized
INFO - 2018-04-02 00:01:13 --> Model Class Initialized
INFO - 2018-04-02 00:01:13 --> Model Class Initialized
DEBUG - 2018-04-02 00:01:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-02 00:01:13 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-02 00:01:13 --> Final output sent to browser
DEBUG - 2018-04-02 00:01:13 --> Total execution time: 0.0572
INFO - 2018-04-02 00:01:13 --> Config Class Initialized
INFO - 2018-04-02 00:01:13 --> Hooks Class Initialized
INFO - 2018-04-02 00:01:13 --> Config Class Initialized
INFO - 2018-04-02 00:01:13 --> Config Class Initialized
INFO - 2018-04-02 00:01:13 --> Hooks Class Initialized
INFO - 2018-04-02 00:01:13 --> Hooks Class Initialized
DEBUG - 2018-04-02 00:01:13 --> UTF-8 Support Enabled
INFO - 2018-04-02 00:01:13 --> Utf8 Class Initialized
INFO - 2018-04-02 00:01:13 --> URI Class Initialized
DEBUG - 2018-04-02 00:01:13 --> UTF-8 Support Enabled
DEBUG - 2018-04-02 00:01:13 --> UTF-8 Support Enabled
INFO - 2018-04-02 00:01:13 --> Utf8 Class Initialized
INFO - 2018-04-02 00:01:13 --> Utf8 Class Initialized
INFO - 2018-04-02 00:01:13 --> URI Class Initialized
INFO - 2018-04-02 00:01:13 --> URI Class Initialized
INFO - 2018-04-02 00:01:13 --> Router Class Initialized
INFO - 2018-04-02 00:01:13 --> Router Class Initialized
INFO - 2018-04-02 00:01:13 --> Router Class Initialized
INFO - 2018-04-02 00:01:13 --> Output Class Initialized
INFO - 2018-04-02 00:01:13 --> Output Class Initialized
INFO - 2018-04-02 00:01:13 --> Security Class Initialized
INFO - 2018-04-02 00:01:13 --> Output Class Initialized
INFO - 2018-04-02 00:01:13 --> Security Class Initialized
DEBUG - 2018-04-02 00:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 00:01:13 --> Input Class Initialized
INFO - 2018-04-02 00:01:13 --> Security Class Initialized
DEBUG - 2018-04-02 00:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 00:01:13 --> Language Class Initialized
INFO - 2018-04-02 00:01:13 --> Input Class Initialized
DEBUG - 2018-04-02 00:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 00:01:13 --> Language Class Initialized
INFO - 2018-04-02 00:01:13 --> Input Class Initialized
ERROR - 2018-04-02 00:01:13 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-04-02 00:01:13 --> Language Class Initialized
ERROR - 2018-04-02 00:01:13 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-04-02 00:01:13 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-04-02 00:01:14 --> Config Class Initialized
INFO - 2018-04-02 00:01:14 --> Hooks Class Initialized
DEBUG - 2018-04-02 00:01:14 --> UTF-8 Support Enabled
INFO - 2018-04-02 00:01:14 --> Utf8 Class Initialized
INFO - 2018-04-02 00:01:14 --> URI Class Initialized
INFO - 2018-04-02 00:01:14 --> Router Class Initialized
INFO - 2018-04-02 00:01:14 --> Output Class Initialized
INFO - 2018-04-02 00:01:14 --> Security Class Initialized
DEBUG - 2018-04-02 00:01:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 00:01:14 --> Input Class Initialized
INFO - 2018-04-02 00:01:14 --> Language Class Initialized
ERROR - 2018-04-02 00:01:14 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-04-02 00:01:14 --> Config Class Initialized
INFO - 2018-04-02 00:01:14 --> Hooks Class Initialized
INFO - 2018-04-02 00:01:14 --> Config Class Initialized
INFO - 2018-04-02 00:01:14 --> Hooks Class Initialized
INFO - 2018-04-02 00:01:14 --> Config Class Initialized
INFO - 2018-04-02 00:01:14 --> Hooks Class Initialized
DEBUG - 2018-04-02 00:01:14 --> UTF-8 Support Enabled
INFO - 2018-04-02 00:01:14 --> Utf8 Class Initialized
DEBUG - 2018-04-02 00:01:14 --> UTF-8 Support Enabled
INFO - 2018-04-02 00:01:14 --> URI Class Initialized
INFO - 2018-04-02 00:01:14 --> Utf8 Class Initialized
DEBUG - 2018-04-02 00:01:14 --> UTF-8 Support Enabled
INFO - 2018-04-02 00:01:14 --> Utf8 Class Initialized
INFO - 2018-04-02 00:01:14 --> URI Class Initialized
INFO - 2018-04-02 00:01:14 --> URI Class Initialized
INFO - 2018-04-02 00:01:14 --> Router Class Initialized
INFO - 2018-04-02 00:01:14 --> Router Class Initialized
INFO - 2018-04-02 00:01:14 --> Router Class Initialized
INFO - 2018-04-02 00:01:14 --> Output Class Initialized
INFO - 2018-04-02 00:01:14 --> Output Class Initialized
INFO - 2018-04-02 00:01:14 --> Output Class Initialized
INFO - 2018-04-02 00:01:14 --> Security Class Initialized
DEBUG - 2018-04-02 00:01:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 00:01:14 --> Security Class Initialized
INFO - 2018-04-02 00:01:14 --> Security Class Initialized
INFO - 2018-04-02 00:01:14 --> Input Class Initialized
INFO - 2018-04-02 00:01:14 --> Language Class Initialized
DEBUG - 2018-04-02 00:01:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-02 00:01:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 00:01:14 --> Input Class Initialized
INFO - 2018-04-02 00:01:14 --> Input Class Initialized
ERROR - 2018-04-02 00:01:14 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-04-02 00:01:14 --> Language Class Initialized
INFO - 2018-04-02 00:01:14 --> Language Class Initialized
ERROR - 2018-04-02 00:01:14 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-04-02 00:01:14 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-04-02 00:01:14 --> Config Class Initialized
INFO - 2018-04-02 00:01:14 --> Hooks Class Initialized
DEBUG - 2018-04-02 00:01:14 --> UTF-8 Support Enabled
INFO - 2018-04-02 00:01:14 --> Utf8 Class Initialized
INFO - 2018-04-02 00:01:14 --> URI Class Initialized
INFO - 2018-04-02 00:01:14 --> Router Class Initialized
INFO - 2018-04-02 00:01:14 --> Output Class Initialized
INFO - 2018-04-02 00:01:14 --> Security Class Initialized
DEBUG - 2018-04-02 00:01:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 00:01:14 --> Input Class Initialized
INFO - 2018-04-02 00:01:14 --> Language Class Initialized
INFO - 2018-04-02 00:01:14 --> Loader Class Initialized
INFO - 2018-04-02 00:01:14 --> Helper loaded: url_helper
INFO - 2018-04-02 00:01:14 --> Helper loaded: form_helper
INFO - 2018-04-02 00:01:14 --> Database Driver Class Initialized
DEBUG - 2018-04-02 00:01:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 00:01:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 00:01:14 --> Form Validation Class Initialized
INFO - 2018-04-02 00:01:14 --> Model Class Initialized
INFO - 2018-04-02 00:01:14 --> Controller Class Initialized
INFO - 2018-04-02 00:01:14 --> Model Class Initialized
INFO - 2018-04-02 00:01:14 --> Model Class Initialized
INFO - 2018-04-02 00:01:14 --> Model Class Initialized
INFO - 2018-04-02 00:01:14 --> Model Class Initialized
DEBUG - 2018-04-02 00:01:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-02 00:01:21 --> Config Class Initialized
INFO - 2018-04-02 00:01:21 --> Hooks Class Initialized
DEBUG - 2018-04-02 00:01:21 --> UTF-8 Support Enabled
INFO - 2018-04-02 00:01:21 --> Utf8 Class Initialized
INFO - 2018-04-02 00:01:21 --> URI Class Initialized
INFO - 2018-04-02 00:01:21 --> Router Class Initialized
INFO - 2018-04-02 00:01:21 --> Output Class Initialized
INFO - 2018-04-02 00:01:21 --> Security Class Initialized
DEBUG - 2018-04-02 00:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 00:01:21 --> Input Class Initialized
INFO - 2018-04-02 00:01:21 --> Language Class Initialized
INFO - 2018-04-02 00:01:21 --> Loader Class Initialized
INFO - 2018-04-02 00:01:21 --> Helper loaded: url_helper
INFO - 2018-04-02 00:01:21 --> Helper loaded: form_helper
INFO - 2018-04-02 00:01:21 --> Database Driver Class Initialized
DEBUG - 2018-04-02 00:01:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 00:01:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 00:01:21 --> Form Validation Class Initialized
INFO - 2018-04-02 00:01:21 --> Model Class Initialized
INFO - 2018-04-02 00:01:21 --> Controller Class Initialized
INFO - 2018-04-02 00:01:21 --> Model Class Initialized
INFO - 2018-04-02 00:01:21 --> Model Class Initialized
INFO - 2018-04-02 00:01:21 --> Model Class Initialized
INFO - 2018-04-02 00:01:21 --> Model Class Initialized
DEBUG - 2018-04-02 00:01:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-02 00:01:24 --> Config Class Initialized
INFO - 2018-04-02 00:01:24 --> Hooks Class Initialized
DEBUG - 2018-04-02 00:01:24 --> UTF-8 Support Enabled
INFO - 2018-04-02 00:01:24 --> Utf8 Class Initialized
INFO - 2018-04-02 00:01:24 --> URI Class Initialized
INFO - 2018-04-02 00:01:24 --> Router Class Initialized
INFO - 2018-04-02 00:01:24 --> Output Class Initialized
INFO - 2018-04-02 00:01:24 --> Security Class Initialized
DEBUG - 2018-04-02 00:01:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 00:01:24 --> Input Class Initialized
INFO - 2018-04-02 00:01:24 --> Language Class Initialized
INFO - 2018-04-02 00:01:24 --> Loader Class Initialized
INFO - 2018-04-02 00:01:24 --> Helper loaded: url_helper
INFO - 2018-04-02 00:01:24 --> Helper loaded: form_helper
INFO - 2018-04-02 00:01:24 --> Database Driver Class Initialized
DEBUG - 2018-04-02 00:01:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 00:01:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 00:01:24 --> Form Validation Class Initialized
INFO - 2018-04-02 00:01:24 --> Model Class Initialized
INFO - 2018-04-02 00:01:24 --> Controller Class Initialized
INFO - 2018-04-02 00:01:24 --> Model Class Initialized
INFO - 2018-04-02 00:01:24 --> Model Class Initialized
INFO - 2018-04-02 00:01:24 --> Model Class Initialized
INFO - 2018-04-02 00:01:24 --> Model Class Initialized
DEBUG - 2018-04-02 00:01:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-02 00:01:28 --> Config Class Initialized
INFO - 2018-04-02 00:01:28 --> Hooks Class Initialized
DEBUG - 2018-04-02 00:01:28 --> UTF-8 Support Enabled
INFO - 2018-04-02 00:01:28 --> Utf8 Class Initialized
INFO - 2018-04-02 00:01:28 --> URI Class Initialized
INFO - 2018-04-02 00:01:28 --> Router Class Initialized
INFO - 2018-04-02 00:01:28 --> Output Class Initialized
INFO - 2018-04-02 00:01:28 --> Security Class Initialized
DEBUG - 2018-04-02 00:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 00:01:28 --> Input Class Initialized
INFO - 2018-04-02 00:01:28 --> Language Class Initialized
INFO - 2018-04-02 00:01:28 --> Loader Class Initialized
INFO - 2018-04-02 00:01:28 --> Helper loaded: url_helper
INFO - 2018-04-02 00:01:28 --> Helper loaded: form_helper
INFO - 2018-04-02 00:01:28 --> Database Driver Class Initialized
DEBUG - 2018-04-02 00:01:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 00:01:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 00:01:28 --> Form Validation Class Initialized
INFO - 2018-04-02 00:01:28 --> Model Class Initialized
INFO - 2018-04-02 00:01:28 --> Controller Class Initialized
INFO - 2018-04-02 00:01:28 --> Model Class Initialized
INFO - 2018-04-02 00:01:28 --> Model Class Initialized
INFO - 2018-04-02 00:01:28 --> Model Class Initialized
INFO - 2018-04-02 00:01:28 --> Model Class Initialized
DEBUG - 2018-04-02 00:01:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-02 00:01:32 --> Config Class Initialized
INFO - 2018-04-02 00:01:32 --> Hooks Class Initialized
DEBUG - 2018-04-02 00:01:32 --> UTF-8 Support Enabled
INFO - 2018-04-02 00:01:32 --> Utf8 Class Initialized
INFO - 2018-04-02 00:01:32 --> URI Class Initialized
INFO - 2018-04-02 00:01:32 --> Router Class Initialized
INFO - 2018-04-02 00:01:32 --> Output Class Initialized
INFO - 2018-04-02 00:01:32 --> Security Class Initialized
DEBUG - 2018-04-02 00:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 00:01:32 --> Input Class Initialized
INFO - 2018-04-02 00:01:32 --> Language Class Initialized
INFO - 2018-04-02 00:01:32 --> Loader Class Initialized
INFO - 2018-04-02 00:01:32 --> Helper loaded: url_helper
INFO - 2018-04-02 00:01:32 --> Helper loaded: form_helper
INFO - 2018-04-02 00:01:32 --> Database Driver Class Initialized
DEBUG - 2018-04-02 00:01:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 00:01:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 00:01:32 --> Form Validation Class Initialized
INFO - 2018-04-02 00:01:32 --> Model Class Initialized
INFO - 2018-04-02 00:01:32 --> Controller Class Initialized
INFO - 2018-04-02 00:01:32 --> Model Class Initialized
INFO - 2018-04-02 00:01:32 --> Model Class Initialized
INFO - 2018-04-02 00:01:32 --> Model Class Initialized
INFO - 2018-04-02 00:01:32 --> Model Class Initialized
DEBUG - 2018-04-02 00:01:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-02 00:01:36 --> Config Class Initialized
INFO - 2018-04-02 00:01:36 --> Hooks Class Initialized
DEBUG - 2018-04-02 00:01:36 --> UTF-8 Support Enabled
INFO - 2018-04-02 00:01:36 --> Utf8 Class Initialized
INFO - 2018-04-02 00:01:36 --> URI Class Initialized
INFO - 2018-04-02 00:01:36 --> Router Class Initialized
INFO - 2018-04-02 00:01:36 --> Output Class Initialized
INFO - 2018-04-02 00:01:36 --> Security Class Initialized
DEBUG - 2018-04-02 00:01:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 00:01:36 --> Input Class Initialized
INFO - 2018-04-02 00:01:36 --> Language Class Initialized
INFO - 2018-04-02 00:01:36 --> Loader Class Initialized
INFO - 2018-04-02 00:01:36 --> Helper loaded: url_helper
INFO - 2018-04-02 00:01:36 --> Helper loaded: form_helper
INFO - 2018-04-02 00:01:36 --> Database Driver Class Initialized
DEBUG - 2018-04-02 00:01:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 00:01:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 00:01:36 --> Form Validation Class Initialized
INFO - 2018-04-02 00:01:36 --> Model Class Initialized
INFO - 2018-04-02 00:01:36 --> Controller Class Initialized
INFO - 2018-04-02 00:01:36 --> Model Class Initialized
INFO - 2018-04-02 00:01:36 --> Model Class Initialized
INFO - 2018-04-02 00:01:36 --> Model Class Initialized
INFO - 2018-04-02 00:01:36 --> Model Class Initialized
DEBUG - 2018-04-02 00:01:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-02 00:01:39 --> Config Class Initialized
INFO - 2018-04-02 00:01:39 --> Hooks Class Initialized
DEBUG - 2018-04-02 00:01:39 --> UTF-8 Support Enabled
INFO - 2018-04-02 00:01:39 --> Utf8 Class Initialized
INFO - 2018-04-02 00:01:39 --> URI Class Initialized
INFO - 2018-04-02 00:01:39 --> Router Class Initialized
INFO - 2018-04-02 00:01:39 --> Output Class Initialized
INFO - 2018-04-02 00:01:39 --> Security Class Initialized
DEBUG - 2018-04-02 00:01:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 00:01:39 --> Input Class Initialized
INFO - 2018-04-02 00:01:39 --> Language Class Initialized
INFO - 2018-04-02 00:01:39 --> Loader Class Initialized
INFO - 2018-04-02 00:01:39 --> Helper loaded: url_helper
INFO - 2018-04-02 00:01:39 --> Helper loaded: form_helper
INFO - 2018-04-02 00:01:39 --> Database Driver Class Initialized
DEBUG - 2018-04-02 00:01:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 00:01:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 00:01:39 --> Form Validation Class Initialized
INFO - 2018-04-02 00:01:39 --> Model Class Initialized
INFO - 2018-04-02 00:01:39 --> Controller Class Initialized
INFO - 2018-04-02 00:01:39 --> Model Class Initialized
INFO - 2018-04-02 00:01:39 --> Model Class Initialized
INFO - 2018-04-02 00:01:39 --> Model Class Initialized
INFO - 2018-04-02 00:01:39 --> Model Class Initialized
DEBUG - 2018-04-02 00:01:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-02 00:01:44 --> Config Class Initialized
INFO - 2018-04-02 00:01:44 --> Hooks Class Initialized
DEBUG - 2018-04-02 00:01:44 --> UTF-8 Support Enabled
INFO - 2018-04-02 00:01:44 --> Utf8 Class Initialized
INFO - 2018-04-02 00:01:44 --> URI Class Initialized
INFO - 2018-04-02 00:01:44 --> Router Class Initialized
INFO - 2018-04-02 00:01:44 --> Output Class Initialized
INFO - 2018-04-02 00:01:44 --> Security Class Initialized
DEBUG - 2018-04-02 00:01:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 00:01:44 --> Input Class Initialized
INFO - 2018-04-02 00:01:44 --> Language Class Initialized
INFO - 2018-04-02 00:01:44 --> Loader Class Initialized
INFO - 2018-04-02 00:01:44 --> Helper loaded: url_helper
INFO - 2018-04-02 00:01:44 --> Helper loaded: form_helper
INFO - 2018-04-02 00:01:44 --> Database Driver Class Initialized
DEBUG - 2018-04-02 00:01:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 00:01:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 00:01:44 --> Form Validation Class Initialized
INFO - 2018-04-02 00:01:44 --> Model Class Initialized
INFO - 2018-04-02 00:01:44 --> Controller Class Initialized
INFO - 2018-04-02 00:01:44 --> Model Class Initialized
INFO - 2018-04-02 00:01:44 --> Model Class Initialized
INFO - 2018-04-02 00:01:44 --> Model Class Initialized
INFO - 2018-04-02 00:01:44 --> Model Class Initialized
DEBUG - 2018-04-02 00:01:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-02 00:01:50 --> Config Class Initialized
INFO - 2018-04-02 00:01:50 --> Hooks Class Initialized
DEBUG - 2018-04-02 00:01:50 --> UTF-8 Support Enabled
INFO - 2018-04-02 00:01:50 --> Utf8 Class Initialized
INFO - 2018-04-02 00:01:50 --> URI Class Initialized
INFO - 2018-04-02 00:01:50 --> Router Class Initialized
INFO - 2018-04-02 00:01:50 --> Output Class Initialized
INFO - 2018-04-02 00:01:50 --> Security Class Initialized
DEBUG - 2018-04-02 00:01:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 00:01:50 --> Input Class Initialized
INFO - 2018-04-02 00:01:50 --> Language Class Initialized
INFO - 2018-04-02 00:01:50 --> Loader Class Initialized
INFO - 2018-04-02 00:01:50 --> Helper loaded: url_helper
INFO - 2018-04-02 00:01:50 --> Helper loaded: form_helper
INFO - 2018-04-02 00:01:50 --> Database Driver Class Initialized
DEBUG - 2018-04-02 00:01:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 00:01:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 00:01:50 --> Form Validation Class Initialized
INFO - 2018-04-02 00:01:50 --> Model Class Initialized
INFO - 2018-04-02 00:01:50 --> Controller Class Initialized
INFO - 2018-04-02 00:01:50 --> Model Class Initialized
INFO - 2018-04-02 00:01:50 --> Model Class Initialized
INFO - 2018-04-02 00:01:50 --> Model Class Initialized
INFO - 2018-04-02 00:01:50 --> Model Class Initialized
DEBUG - 2018-04-02 00:01:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-02 00:01:55 --> Config Class Initialized
INFO - 2018-04-02 00:01:55 --> Hooks Class Initialized
DEBUG - 2018-04-02 00:01:55 --> UTF-8 Support Enabled
INFO - 2018-04-02 00:01:55 --> Utf8 Class Initialized
INFO - 2018-04-02 00:01:55 --> URI Class Initialized
INFO - 2018-04-02 00:01:55 --> Router Class Initialized
INFO - 2018-04-02 00:01:55 --> Output Class Initialized
INFO - 2018-04-02 00:01:55 --> Security Class Initialized
DEBUG - 2018-04-02 00:01:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 00:01:55 --> Input Class Initialized
INFO - 2018-04-02 00:01:55 --> Language Class Initialized
INFO - 2018-04-02 00:01:55 --> Loader Class Initialized
INFO - 2018-04-02 00:01:55 --> Helper loaded: url_helper
INFO - 2018-04-02 00:01:55 --> Helper loaded: form_helper
INFO - 2018-04-02 00:01:55 --> Database Driver Class Initialized
DEBUG - 2018-04-02 00:01:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 00:01:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 00:01:55 --> Form Validation Class Initialized
INFO - 2018-04-02 00:01:55 --> Model Class Initialized
INFO - 2018-04-02 00:01:55 --> Controller Class Initialized
INFO - 2018-04-02 00:01:55 --> Model Class Initialized
INFO - 2018-04-02 00:01:55 --> Model Class Initialized
INFO - 2018-04-02 00:01:55 --> Model Class Initialized
INFO - 2018-04-02 00:01:55 --> Model Class Initialized
DEBUG - 2018-04-02 00:01:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-02 00:01:58 --> Config Class Initialized
INFO - 2018-04-02 00:01:58 --> Hooks Class Initialized
DEBUG - 2018-04-02 00:01:58 --> UTF-8 Support Enabled
INFO - 2018-04-02 00:01:58 --> Utf8 Class Initialized
INFO - 2018-04-02 00:01:58 --> URI Class Initialized
INFO - 2018-04-02 00:01:58 --> Router Class Initialized
INFO - 2018-04-02 00:01:58 --> Output Class Initialized
INFO - 2018-04-02 00:01:58 --> Security Class Initialized
DEBUG - 2018-04-02 00:01:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 00:01:58 --> Input Class Initialized
INFO - 2018-04-02 00:01:58 --> Language Class Initialized
INFO - 2018-04-02 00:01:58 --> Loader Class Initialized
INFO - 2018-04-02 00:01:58 --> Helper loaded: url_helper
INFO - 2018-04-02 00:01:58 --> Helper loaded: form_helper
INFO - 2018-04-02 00:01:58 --> Database Driver Class Initialized
DEBUG - 2018-04-02 00:01:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 00:01:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 00:01:58 --> Form Validation Class Initialized
INFO - 2018-04-02 00:01:58 --> Model Class Initialized
INFO - 2018-04-02 00:01:58 --> Controller Class Initialized
INFO - 2018-04-02 00:01:58 --> Model Class Initialized
INFO - 2018-04-02 00:01:58 --> Model Class Initialized
INFO - 2018-04-02 00:01:58 --> Model Class Initialized
INFO - 2018-04-02 00:01:58 --> Model Class Initialized
DEBUG - 2018-04-02 00:01:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-02 00:02:00 --> Config Class Initialized
INFO - 2018-04-02 00:02:00 --> Hooks Class Initialized
DEBUG - 2018-04-02 00:02:00 --> UTF-8 Support Enabled
INFO - 2018-04-02 00:02:00 --> Utf8 Class Initialized
INFO - 2018-04-02 00:02:00 --> URI Class Initialized
INFO - 2018-04-02 00:02:00 --> Router Class Initialized
INFO - 2018-04-02 00:02:00 --> Output Class Initialized
INFO - 2018-04-02 00:02:00 --> Security Class Initialized
DEBUG - 2018-04-02 00:02:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 00:02:00 --> Input Class Initialized
INFO - 2018-04-02 00:02:00 --> Language Class Initialized
INFO - 2018-04-02 00:02:00 --> Loader Class Initialized
INFO - 2018-04-02 00:02:00 --> Helper loaded: url_helper
INFO - 2018-04-02 00:02:00 --> Helper loaded: form_helper
INFO - 2018-04-02 00:02:00 --> Database Driver Class Initialized
DEBUG - 2018-04-02 00:02:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 00:02:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 00:02:00 --> Form Validation Class Initialized
INFO - 2018-04-02 00:02:00 --> Model Class Initialized
INFO - 2018-04-02 00:02:00 --> Controller Class Initialized
INFO - 2018-04-02 00:02:00 --> Model Class Initialized
INFO - 2018-04-02 00:02:00 --> Model Class Initialized
INFO - 2018-04-02 00:02:00 --> Model Class Initialized
INFO - 2018-04-02 00:02:00 --> Model Class Initialized
DEBUG - 2018-04-02 00:02:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-02 00:02:02 --> Config Class Initialized
INFO - 2018-04-02 00:02:02 --> Hooks Class Initialized
DEBUG - 2018-04-02 00:02:02 --> UTF-8 Support Enabled
INFO - 2018-04-02 00:02:02 --> Utf8 Class Initialized
INFO - 2018-04-02 00:02:02 --> URI Class Initialized
INFO - 2018-04-02 00:02:02 --> Router Class Initialized
INFO - 2018-04-02 00:02:02 --> Output Class Initialized
INFO - 2018-04-02 00:02:02 --> Security Class Initialized
DEBUG - 2018-04-02 00:02:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 00:02:02 --> Input Class Initialized
INFO - 2018-04-02 00:02:02 --> Language Class Initialized
INFO - 2018-04-02 00:02:02 --> Loader Class Initialized
INFO - 2018-04-02 00:02:02 --> Helper loaded: url_helper
INFO - 2018-04-02 00:02:02 --> Helper loaded: form_helper
INFO - 2018-04-02 00:02:02 --> Database Driver Class Initialized
DEBUG - 2018-04-02 00:02:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 00:02:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 00:02:02 --> Form Validation Class Initialized
INFO - 2018-04-02 00:02:02 --> Model Class Initialized
INFO - 2018-04-02 00:02:02 --> Controller Class Initialized
INFO - 2018-04-02 00:02:02 --> Model Class Initialized
INFO - 2018-04-02 00:02:02 --> Model Class Initialized
INFO - 2018-04-02 00:02:02 --> Model Class Initialized
INFO - 2018-04-02 00:02:02 --> Model Class Initialized
DEBUG - 2018-04-02 00:02:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-02 00:02:04 --> Config Class Initialized
INFO - 2018-04-02 00:02:04 --> Hooks Class Initialized
DEBUG - 2018-04-02 00:02:04 --> UTF-8 Support Enabled
INFO - 2018-04-02 00:02:04 --> Utf8 Class Initialized
INFO - 2018-04-02 00:02:04 --> URI Class Initialized
INFO - 2018-04-02 00:02:04 --> Router Class Initialized
INFO - 2018-04-02 00:02:04 --> Output Class Initialized
INFO - 2018-04-02 00:02:04 --> Security Class Initialized
DEBUG - 2018-04-02 00:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 00:02:04 --> Input Class Initialized
INFO - 2018-04-02 00:02:04 --> Language Class Initialized
INFO - 2018-04-02 00:02:04 --> Loader Class Initialized
INFO - 2018-04-02 00:02:04 --> Helper loaded: url_helper
INFO - 2018-04-02 00:02:04 --> Helper loaded: form_helper
INFO - 2018-04-02 00:02:04 --> Database Driver Class Initialized
DEBUG - 2018-04-02 00:02:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 00:02:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 00:02:04 --> Form Validation Class Initialized
INFO - 2018-04-02 00:02:04 --> Model Class Initialized
INFO - 2018-04-02 00:02:04 --> Controller Class Initialized
INFO - 2018-04-02 00:02:04 --> Model Class Initialized
INFO - 2018-04-02 00:02:04 --> Model Class Initialized
INFO - 2018-04-02 00:02:04 --> Model Class Initialized
INFO - 2018-04-02 00:02:04 --> Model Class Initialized
DEBUG - 2018-04-02 00:02:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-02 00:02:09 --> Config Class Initialized
INFO - 2018-04-02 00:02:09 --> Hooks Class Initialized
DEBUG - 2018-04-02 00:02:09 --> UTF-8 Support Enabled
INFO - 2018-04-02 00:02:09 --> Utf8 Class Initialized
INFO - 2018-04-02 00:02:09 --> URI Class Initialized
INFO - 2018-04-02 00:02:09 --> Router Class Initialized
INFO - 2018-04-02 00:02:09 --> Output Class Initialized
INFO - 2018-04-02 00:02:09 --> Security Class Initialized
DEBUG - 2018-04-02 00:02:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 00:02:09 --> Input Class Initialized
INFO - 2018-04-02 00:02:09 --> Language Class Initialized
INFO - 2018-04-02 00:02:09 --> Loader Class Initialized
INFO - 2018-04-02 00:02:09 --> Helper loaded: url_helper
INFO - 2018-04-02 00:02:09 --> Helper loaded: form_helper
INFO - 2018-04-02 00:02:09 --> Database Driver Class Initialized
DEBUG - 2018-04-02 00:02:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 00:02:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 00:02:09 --> Form Validation Class Initialized
INFO - 2018-04-02 00:02:09 --> Model Class Initialized
INFO - 2018-04-02 00:02:09 --> Controller Class Initialized
INFO - 2018-04-02 00:02:09 --> Model Class Initialized
INFO - 2018-04-02 00:02:09 --> Model Class Initialized
INFO - 2018-04-02 00:02:09 --> Model Class Initialized
INFO - 2018-04-02 00:02:09 --> Model Class Initialized
DEBUG - 2018-04-02 00:02:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-02 00:03:27 --> Config Class Initialized
INFO - 2018-04-02 00:03:27 --> Hooks Class Initialized
DEBUG - 2018-04-02 00:03:27 --> UTF-8 Support Enabled
INFO - 2018-04-02 00:03:27 --> Utf8 Class Initialized
INFO - 2018-04-02 00:03:27 --> URI Class Initialized
INFO - 2018-04-02 00:03:27 --> Router Class Initialized
INFO - 2018-04-02 00:03:27 --> Output Class Initialized
INFO - 2018-04-02 00:03:27 --> Security Class Initialized
DEBUG - 2018-04-02 00:03:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 00:03:27 --> Input Class Initialized
INFO - 2018-04-02 00:03:27 --> Language Class Initialized
INFO - 2018-04-02 00:03:27 --> Loader Class Initialized
INFO - 2018-04-02 00:03:27 --> Helper loaded: url_helper
INFO - 2018-04-02 00:03:27 --> Helper loaded: form_helper
INFO - 2018-04-02 00:03:27 --> Database Driver Class Initialized
DEBUG - 2018-04-02 00:03:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 00:03:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 00:03:27 --> Form Validation Class Initialized
INFO - 2018-04-02 00:03:27 --> Model Class Initialized
INFO - 2018-04-02 00:03:27 --> Controller Class Initialized
INFO - 2018-04-02 00:03:27 --> Model Class Initialized
INFO - 2018-04-02 00:03:27 --> Model Class Initialized
INFO - 2018-04-02 00:03:27 --> Model Class Initialized
INFO - 2018-04-02 00:03:27 --> Model Class Initialized
DEBUG - 2018-04-02 00:03:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-02 00:03:30 --> Config Class Initialized
INFO - 2018-04-02 00:03:30 --> Hooks Class Initialized
DEBUG - 2018-04-02 00:03:30 --> UTF-8 Support Enabled
INFO - 2018-04-02 00:03:30 --> Utf8 Class Initialized
INFO - 2018-04-02 00:03:30 --> URI Class Initialized
INFO - 2018-04-02 00:03:30 --> Router Class Initialized
INFO - 2018-04-02 00:03:30 --> Output Class Initialized
INFO - 2018-04-02 00:03:30 --> Security Class Initialized
DEBUG - 2018-04-02 00:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 00:03:30 --> Input Class Initialized
INFO - 2018-04-02 00:03:30 --> Language Class Initialized
INFO - 2018-04-02 00:03:30 --> Loader Class Initialized
INFO - 2018-04-02 00:03:30 --> Helper loaded: url_helper
INFO - 2018-04-02 00:03:30 --> Helper loaded: form_helper
INFO - 2018-04-02 00:03:30 --> Database Driver Class Initialized
DEBUG - 2018-04-02 00:03:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 00:03:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 00:03:30 --> Form Validation Class Initialized
INFO - 2018-04-02 00:03:30 --> Model Class Initialized
INFO - 2018-04-02 00:03:30 --> Controller Class Initialized
INFO - 2018-04-02 00:03:30 --> Model Class Initialized
INFO - 2018-04-02 00:03:30 --> Model Class Initialized
INFO - 2018-04-02 00:03:30 --> Model Class Initialized
INFO - 2018-04-02 00:03:30 --> Model Class Initialized
DEBUG - 2018-04-02 00:03:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-02 00:03:36 --> Config Class Initialized
INFO - 2018-04-02 00:03:36 --> Hooks Class Initialized
DEBUG - 2018-04-02 00:03:36 --> UTF-8 Support Enabled
INFO - 2018-04-02 00:03:36 --> Utf8 Class Initialized
INFO - 2018-04-02 00:03:36 --> URI Class Initialized
INFO - 2018-04-02 00:03:36 --> Router Class Initialized
INFO - 2018-04-02 00:03:36 --> Output Class Initialized
INFO - 2018-04-02 00:03:36 --> Security Class Initialized
DEBUG - 2018-04-02 00:03:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 00:03:36 --> Input Class Initialized
INFO - 2018-04-02 00:03:36 --> Language Class Initialized
INFO - 2018-04-02 00:03:36 --> Loader Class Initialized
INFO - 2018-04-02 00:03:36 --> Helper loaded: url_helper
INFO - 2018-04-02 00:03:36 --> Helper loaded: form_helper
INFO - 2018-04-02 00:03:36 --> Database Driver Class Initialized
DEBUG - 2018-04-02 00:03:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 00:03:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 00:03:36 --> Form Validation Class Initialized
INFO - 2018-04-02 00:03:36 --> Model Class Initialized
INFO - 2018-04-02 00:03:36 --> Controller Class Initialized
INFO - 2018-04-02 00:03:36 --> Model Class Initialized
INFO - 2018-04-02 00:03:36 --> Model Class Initialized
INFO - 2018-04-02 00:03:36 --> Model Class Initialized
INFO - 2018-04-02 00:03:36 --> Model Class Initialized
DEBUG - 2018-04-02 00:03:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-02 00:03:39 --> Config Class Initialized
INFO - 2018-04-02 00:03:39 --> Hooks Class Initialized
DEBUG - 2018-04-02 00:03:39 --> UTF-8 Support Enabled
INFO - 2018-04-02 00:03:39 --> Utf8 Class Initialized
INFO - 2018-04-02 00:03:39 --> URI Class Initialized
INFO - 2018-04-02 00:03:39 --> Router Class Initialized
INFO - 2018-04-02 00:03:39 --> Output Class Initialized
INFO - 2018-04-02 00:03:39 --> Security Class Initialized
DEBUG - 2018-04-02 00:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 00:03:39 --> Input Class Initialized
INFO - 2018-04-02 00:03:39 --> Language Class Initialized
INFO - 2018-04-02 00:03:39 --> Loader Class Initialized
INFO - 2018-04-02 00:03:39 --> Helper loaded: url_helper
INFO - 2018-04-02 00:03:39 --> Helper loaded: form_helper
INFO - 2018-04-02 00:03:39 --> Database Driver Class Initialized
DEBUG - 2018-04-02 00:03:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 00:03:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 00:03:39 --> Form Validation Class Initialized
INFO - 2018-04-02 00:03:39 --> Model Class Initialized
INFO - 2018-04-02 00:03:39 --> Controller Class Initialized
INFO - 2018-04-02 00:03:39 --> Model Class Initialized
INFO - 2018-04-02 00:03:39 --> Model Class Initialized
INFO - 2018-04-02 00:03:39 --> Model Class Initialized
INFO - 2018-04-02 00:03:39 --> Model Class Initialized
DEBUG - 2018-04-02 00:03:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-02 00:03:51 --> Config Class Initialized
INFO - 2018-04-02 00:03:51 --> Hooks Class Initialized
DEBUG - 2018-04-02 00:03:51 --> UTF-8 Support Enabled
INFO - 2018-04-02 00:03:51 --> Utf8 Class Initialized
INFO - 2018-04-02 00:03:51 --> URI Class Initialized
INFO - 2018-04-02 00:03:51 --> Router Class Initialized
INFO - 2018-04-02 00:03:51 --> Output Class Initialized
INFO - 2018-04-02 00:03:51 --> Security Class Initialized
DEBUG - 2018-04-02 00:03:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 00:03:51 --> Input Class Initialized
INFO - 2018-04-02 00:03:51 --> Language Class Initialized
INFO - 2018-04-02 00:03:51 --> Loader Class Initialized
INFO - 2018-04-02 00:03:51 --> Helper loaded: url_helper
INFO - 2018-04-02 00:03:51 --> Helper loaded: form_helper
INFO - 2018-04-02 00:03:51 --> Database Driver Class Initialized
DEBUG - 2018-04-02 00:03:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 00:03:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 00:03:51 --> Form Validation Class Initialized
INFO - 2018-04-02 00:03:51 --> Model Class Initialized
INFO - 2018-04-02 00:03:51 --> Controller Class Initialized
INFO - 2018-04-02 00:03:51 --> Model Class Initialized
INFO - 2018-04-02 00:03:51 --> Model Class Initialized
INFO - 2018-04-02 00:03:51 --> Model Class Initialized
INFO - 2018-04-02 00:03:51 --> Model Class Initialized
DEBUG - 2018-04-02 00:03:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-02 00:24:02 --> Config Class Initialized
INFO - 2018-04-02 00:24:02 --> Hooks Class Initialized
DEBUG - 2018-04-02 00:24:02 --> UTF-8 Support Enabled
INFO - 2018-04-02 00:24:02 --> Utf8 Class Initialized
INFO - 2018-04-02 00:24:02 --> URI Class Initialized
INFO - 2018-04-02 00:24:02 --> Router Class Initialized
INFO - 2018-04-02 00:24:02 --> Output Class Initialized
INFO - 2018-04-02 00:24:02 --> Security Class Initialized
DEBUG - 2018-04-02 00:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 00:24:02 --> Input Class Initialized
INFO - 2018-04-02 00:24:02 --> Language Class Initialized
INFO - 2018-04-02 00:24:02 --> Loader Class Initialized
INFO - 2018-04-02 00:24:02 --> Helper loaded: url_helper
INFO - 2018-04-02 00:24:02 --> Helper loaded: form_helper
INFO - 2018-04-02 00:24:02 --> Database Driver Class Initialized
DEBUG - 2018-04-02 00:24:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 00:24:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 00:24:02 --> Form Validation Class Initialized
INFO - 2018-04-02 00:24:02 --> Model Class Initialized
INFO - 2018-04-02 00:24:02 --> Controller Class Initialized
INFO - 2018-04-02 00:24:02 --> Model Class Initialized
INFO - 2018-04-02 00:24:02 --> Model Class Initialized
INFO - 2018-04-02 00:24:02 --> Model Class Initialized
INFO - 2018-04-02 00:24:02 --> Model Class Initialized
DEBUG - 2018-04-02 00:24:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-02 00:24:02 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-02 00:24:02 --> Final output sent to browser
DEBUG - 2018-04-02 00:24:02 --> Total execution time: 0.0701
INFO - 2018-04-02 00:24:02 --> Config Class Initialized
INFO - 2018-04-02 00:24:02 --> Hooks Class Initialized
DEBUG - 2018-04-02 00:24:02 --> UTF-8 Support Enabled
INFO - 2018-04-02 00:24:02 --> Utf8 Class Initialized
INFO - 2018-04-02 00:24:02 --> URI Class Initialized
INFO - 2018-04-02 00:24:02 --> Router Class Initialized
INFO - 2018-04-02 00:24:02 --> Output Class Initialized
INFO - 2018-04-02 00:24:02 --> Security Class Initialized
DEBUG - 2018-04-02 00:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 00:24:02 --> Input Class Initialized
INFO - 2018-04-02 00:24:02 --> Language Class Initialized
INFO - 2018-04-02 00:24:02 --> Loader Class Initialized
INFO - 2018-04-02 00:24:02 --> Helper loaded: url_helper
INFO - 2018-04-02 00:24:02 --> Helper loaded: form_helper
INFO - 2018-04-02 00:24:02 --> Database Driver Class Initialized
DEBUG - 2018-04-02 00:24:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 00:24:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 00:24:02 --> Form Validation Class Initialized
INFO - 2018-04-02 00:24:02 --> Model Class Initialized
INFO - 2018-04-02 00:24:02 --> Controller Class Initialized
INFO - 2018-04-02 00:24:02 --> Model Class Initialized
INFO - 2018-04-02 00:24:02 --> Model Class Initialized
INFO - 2018-04-02 00:24:02 --> Model Class Initialized
INFO - 2018-04-02 00:24:02 --> Model Class Initialized
DEBUG - 2018-04-02 00:24:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-02 00:24:10 --> Config Class Initialized
INFO - 2018-04-02 00:24:10 --> Hooks Class Initialized
DEBUG - 2018-04-02 00:24:10 --> UTF-8 Support Enabled
INFO - 2018-04-02 00:24:10 --> Utf8 Class Initialized
INFO - 2018-04-02 00:24:10 --> URI Class Initialized
INFO - 2018-04-02 00:24:10 --> Router Class Initialized
INFO - 2018-04-02 00:24:10 --> Output Class Initialized
INFO - 2018-04-02 00:24:10 --> Security Class Initialized
DEBUG - 2018-04-02 00:24:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 00:24:10 --> Input Class Initialized
INFO - 2018-04-02 00:24:10 --> Language Class Initialized
INFO - 2018-04-02 00:24:10 --> Loader Class Initialized
INFO - 2018-04-02 00:24:10 --> Helper loaded: url_helper
INFO - 2018-04-02 00:24:10 --> Helper loaded: form_helper
INFO - 2018-04-02 00:24:10 --> Database Driver Class Initialized
DEBUG - 2018-04-02 00:24:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 00:24:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 00:24:10 --> Form Validation Class Initialized
INFO - 2018-04-02 00:24:10 --> Model Class Initialized
INFO - 2018-04-02 00:24:10 --> Controller Class Initialized
INFO - 2018-04-02 00:24:10 --> Model Class Initialized
INFO - 2018-04-02 00:24:10 --> Model Class Initialized
INFO - 2018-04-02 00:24:10 --> Model Class Initialized
INFO - 2018-04-02 00:24:10 --> Model Class Initialized
DEBUG - 2018-04-02 00:24:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-02 00:24:10 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-02 00:24:10 --> Final output sent to browser
DEBUG - 2018-04-02 00:24:10 --> Total execution time: 0.0724
INFO - 2018-04-02 00:24:10 --> Config Class Initialized
INFO - 2018-04-02 00:24:10 --> Hooks Class Initialized
DEBUG - 2018-04-02 00:24:10 --> UTF-8 Support Enabled
INFO - 2018-04-02 00:24:10 --> Utf8 Class Initialized
INFO - 2018-04-02 00:24:10 --> URI Class Initialized
INFO - 2018-04-02 00:24:10 --> Router Class Initialized
INFO - 2018-04-02 00:24:10 --> Output Class Initialized
INFO - 2018-04-02 00:24:10 --> Security Class Initialized
DEBUG - 2018-04-02 00:24:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 00:24:10 --> Input Class Initialized
INFO - 2018-04-02 00:24:10 --> Language Class Initialized
INFO - 2018-04-02 00:24:10 --> Loader Class Initialized
INFO - 2018-04-02 00:24:10 --> Helper loaded: url_helper
INFO - 2018-04-02 00:24:10 --> Helper loaded: form_helper
INFO - 2018-04-02 00:24:10 --> Database Driver Class Initialized
DEBUG - 2018-04-02 00:24:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 00:24:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 00:24:10 --> Form Validation Class Initialized
INFO - 2018-04-02 00:24:10 --> Model Class Initialized
INFO - 2018-04-02 00:24:10 --> Controller Class Initialized
INFO - 2018-04-02 00:24:10 --> Model Class Initialized
INFO - 2018-04-02 00:24:10 --> Model Class Initialized
INFO - 2018-04-02 00:24:10 --> Model Class Initialized
INFO - 2018-04-02 00:24:10 --> Model Class Initialized
DEBUG - 2018-04-02 00:24:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-02 00:24:34 --> Config Class Initialized
INFO - 2018-04-02 00:24:34 --> Hooks Class Initialized
DEBUG - 2018-04-02 00:24:34 --> UTF-8 Support Enabled
INFO - 2018-04-02 00:24:34 --> Utf8 Class Initialized
INFO - 2018-04-02 00:24:34 --> URI Class Initialized
INFO - 2018-04-02 00:24:34 --> Router Class Initialized
INFO - 2018-04-02 00:24:34 --> Output Class Initialized
INFO - 2018-04-02 00:24:34 --> Security Class Initialized
DEBUG - 2018-04-02 00:24:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 00:24:34 --> Input Class Initialized
INFO - 2018-04-02 00:24:34 --> Language Class Initialized
INFO - 2018-04-02 00:24:34 --> Loader Class Initialized
INFO - 2018-04-02 00:24:34 --> Helper loaded: url_helper
INFO - 2018-04-02 00:24:34 --> Helper loaded: form_helper
INFO - 2018-04-02 00:24:34 --> Database Driver Class Initialized
DEBUG - 2018-04-02 00:24:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 00:24:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 00:24:34 --> Form Validation Class Initialized
INFO - 2018-04-02 00:24:34 --> Model Class Initialized
INFO - 2018-04-02 00:24:34 --> Controller Class Initialized
INFO - 2018-04-02 00:24:34 --> Model Class Initialized
INFO - 2018-04-02 00:24:34 --> Model Class Initialized
INFO - 2018-04-02 00:24:34 --> Model Class Initialized
INFO - 2018-04-02 00:24:34 --> Model Class Initialized
DEBUG - 2018-04-02 00:24:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-02 00:24:34 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-02 00:24:34 --> Final output sent to browser
DEBUG - 2018-04-02 00:24:34 --> Total execution time: 0.0719
INFO - 2018-04-02 00:24:34 --> Config Class Initialized
INFO - 2018-04-02 00:24:34 --> Hooks Class Initialized
DEBUG - 2018-04-02 00:24:34 --> UTF-8 Support Enabled
INFO - 2018-04-02 00:24:34 --> Utf8 Class Initialized
INFO - 2018-04-02 00:24:34 --> URI Class Initialized
INFO - 2018-04-02 00:24:34 --> Router Class Initialized
INFO - 2018-04-02 00:24:34 --> Output Class Initialized
INFO - 2018-04-02 00:24:34 --> Security Class Initialized
DEBUG - 2018-04-02 00:24:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 00:24:34 --> Input Class Initialized
INFO - 2018-04-02 00:24:34 --> Language Class Initialized
INFO - 2018-04-02 00:24:34 --> Loader Class Initialized
INFO - 2018-04-02 00:24:34 --> Helper loaded: url_helper
INFO - 2018-04-02 00:24:34 --> Helper loaded: form_helper
INFO - 2018-04-02 00:24:34 --> Database Driver Class Initialized
DEBUG - 2018-04-02 00:24:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 00:24:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 00:24:34 --> Form Validation Class Initialized
INFO - 2018-04-02 00:24:34 --> Model Class Initialized
INFO - 2018-04-02 00:24:34 --> Controller Class Initialized
INFO - 2018-04-02 00:24:34 --> Model Class Initialized
INFO - 2018-04-02 00:24:34 --> Model Class Initialized
INFO - 2018-04-02 00:24:34 --> Model Class Initialized
INFO - 2018-04-02 00:24:34 --> Model Class Initialized
DEBUG - 2018-04-02 00:24:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-02 00:48:22 --> Config Class Initialized
INFO - 2018-04-02 00:48:22 --> Hooks Class Initialized
DEBUG - 2018-04-02 00:48:22 --> UTF-8 Support Enabled
INFO - 2018-04-02 00:48:22 --> Utf8 Class Initialized
INFO - 2018-04-02 00:48:22 --> URI Class Initialized
INFO - 2018-04-02 00:48:22 --> Router Class Initialized
INFO - 2018-04-02 00:48:22 --> Output Class Initialized
INFO - 2018-04-02 00:48:22 --> Security Class Initialized
DEBUG - 2018-04-02 00:48:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 00:48:22 --> Input Class Initialized
INFO - 2018-04-02 00:48:22 --> Language Class Initialized
INFO - 2018-04-02 00:48:22 --> Loader Class Initialized
INFO - 2018-04-02 00:48:22 --> Helper loaded: url_helper
INFO - 2018-04-02 00:48:22 --> Helper loaded: form_helper
INFO - 2018-04-02 00:48:22 --> Database Driver Class Initialized
DEBUG - 2018-04-02 00:48:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 00:48:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 00:48:22 --> Form Validation Class Initialized
INFO - 2018-04-02 00:48:22 --> Model Class Initialized
INFO - 2018-04-02 00:48:22 --> Controller Class Initialized
INFO - 2018-04-02 00:48:22 --> Model Class Initialized
INFO - 2018-04-02 00:48:22 --> Model Class Initialized
INFO - 2018-04-02 00:48:22 --> Model Class Initialized
INFO - 2018-04-02 00:48:22 --> Model Class Initialized
DEBUG - 2018-04-02 00:48:22 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-04-02 00:48:22 --> Query error: Unknown column 'proyecto_tipo_cambio.proyecto_gasto_estado' in 'field list' - Invalid query: SELECT `proyecto_tipo_cambio`.`valor_venta`, `proveedor`.`proveedor_id`, `proveedor`.`nombre_proveedor`, `proyecto_gasto`.`fecha_gasto`, `proyecto_gasto_monto`.`proyecto_gasto_monto`, `proyecto_gasto_monto`.`moneda_id`, `proyecto_tipo_cambio`.`proyecto_gasto_estado`
FROM `proyecto_gasto`
JOIN `proyecto_tipo_cambio` ON `proyecto_tipo_cambio`.`proyecto_id` = `proyecto_gasto`.`proyecto_id`
JOIN `proyecto_gasto_monto` ON `proyecto_gasto_monto`.`proyecto_gasto_id` = `proyecto_gasto`.`proyecto_gasto_id` AND `proyecto_gasto_monto`.`estado_registro` = 1
JOIN `proyecto_gasto_detalle` ON `proyecto_gasto_detalle`.`proyecto_gasto_id` = `proyecto_gasto`.`proyecto_gasto_id`
JOIN `proyecto_gasto_estado` ON `proyecto_gasto_estado`.`proyecto_gasto_estado_id` = `proyecto_gasto_detalle`.`proyecto_gasto_estado_id`
JOIN `proveedor` ON `proveedor`.`proveedor_id` = `proyecto_gasto_detalle`.`proveedor_id`
WHERE `proyecto_gasto`.`proyecto_id` = '1'
AND `proyecto_gasto`.`proyecto_gasto_tipo_id` = 1
ORDER BY `proyecto_gasto`.`fecha_gasto` ASC
INFO - 2018-04-02 00:48:22 --> Language file loaded: language/english/db_lang.php
INFO - 2018-04-02 00:48:48 --> Config Class Initialized
INFO - 2018-04-02 00:48:48 --> Hooks Class Initialized
DEBUG - 2018-04-02 00:48:48 --> UTF-8 Support Enabled
INFO - 2018-04-02 00:48:48 --> Utf8 Class Initialized
INFO - 2018-04-02 00:48:48 --> URI Class Initialized
INFO - 2018-04-02 00:48:48 --> Router Class Initialized
INFO - 2018-04-02 00:48:48 --> Output Class Initialized
INFO - 2018-04-02 00:48:48 --> Security Class Initialized
DEBUG - 2018-04-02 00:48:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 00:48:48 --> Input Class Initialized
INFO - 2018-04-02 00:48:48 --> Language Class Initialized
INFO - 2018-04-02 00:48:48 --> Loader Class Initialized
INFO - 2018-04-02 00:48:48 --> Helper loaded: url_helper
INFO - 2018-04-02 00:48:48 --> Helper loaded: form_helper
INFO - 2018-04-02 00:48:48 --> Database Driver Class Initialized
DEBUG - 2018-04-02 00:48:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 00:48:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 00:48:48 --> Form Validation Class Initialized
INFO - 2018-04-02 00:48:48 --> Model Class Initialized
INFO - 2018-04-02 00:48:48 --> Controller Class Initialized
INFO - 2018-04-02 00:48:48 --> Model Class Initialized
INFO - 2018-04-02 00:48:48 --> Model Class Initialized
INFO - 2018-04-02 00:48:48 --> Model Class Initialized
INFO - 2018-04-02 00:48:48 --> Model Class Initialized
DEBUG - 2018-04-02 00:48:48 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-04-02 00:48:48 --> Severity: Notice --> Undefined property: Reporte::$t_proyecto_gasto_estao D:\xampp\htdocs\instateccr\controlcostos\instatec_sys\core\Model.php 77
ERROR - 2018-04-02 00:48:48 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'FROM `proyecto_gasto`
JOIN `proyecto_tipo_cambio` ON `proyecto_tipo_cambio`.`pro' at line 2 - Invalid query: SELECT `proyecto_tipo_cambio`.`valor_venta`, `proveedor`.`proveedor_id`, `proveedor`.`nombre_proveedor`, `proyecto_gasto`.`fecha_gasto`, `proyecto_gasto_monto`.`proyecto_gasto_monto`, `proyecto_gasto_monto`.`moneda_id`, .`proyecto_gasto_estado`
FROM `proyecto_gasto`
JOIN `proyecto_tipo_cambio` ON `proyecto_tipo_cambio`.`proyecto_id` = `proyecto_gasto`.`proyecto_id`
JOIN `proyecto_gasto_monto` ON `proyecto_gasto_monto`.`proyecto_gasto_id` = `proyecto_gasto`.`proyecto_gasto_id` AND `proyecto_gasto_monto`.`estado_registro` = 1
JOIN `proyecto_gasto_detalle` ON `proyecto_gasto_detalle`.`proyecto_gasto_id` = `proyecto_gasto`.`proyecto_gasto_id`
JOIN `proyecto_gasto_estado` ON `proyecto_gasto_estado`.`proyecto_gasto_estado_id` = `proyecto_gasto_detalle`.`proyecto_gasto_estado_id`
JOIN `proveedor` ON `proveedor`.`proveedor_id` = `proyecto_gasto_detalle`.`proveedor_id`
WHERE `proyecto_gasto`.`proyecto_id` = '1'
AND `proyecto_gasto`.`proyecto_gasto_tipo_id` = 1
ORDER BY `proyecto_gasto`.`fecha_gasto` ASC
INFO - 2018-04-02 00:48:48 --> Language file loaded: language/english/db_lang.php
INFO - 2018-04-02 00:48:53 --> Config Class Initialized
INFO - 2018-04-02 00:48:53 --> Hooks Class Initialized
DEBUG - 2018-04-02 00:48:53 --> UTF-8 Support Enabled
INFO - 2018-04-02 00:48:53 --> Utf8 Class Initialized
INFO - 2018-04-02 00:48:53 --> URI Class Initialized
INFO - 2018-04-02 00:48:53 --> Router Class Initialized
INFO - 2018-04-02 00:48:53 --> Output Class Initialized
INFO - 2018-04-02 00:48:53 --> Security Class Initialized
DEBUG - 2018-04-02 00:48:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 00:48:53 --> Input Class Initialized
INFO - 2018-04-02 00:48:53 --> Language Class Initialized
INFO - 2018-04-02 00:48:53 --> Loader Class Initialized
INFO - 2018-04-02 00:48:53 --> Helper loaded: url_helper
INFO - 2018-04-02 00:48:53 --> Helper loaded: form_helper
INFO - 2018-04-02 00:48:53 --> Database Driver Class Initialized
DEBUG - 2018-04-02 00:48:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 00:48:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 00:48:53 --> Form Validation Class Initialized
INFO - 2018-04-02 00:48:53 --> Model Class Initialized
INFO - 2018-04-02 00:48:53 --> Controller Class Initialized
INFO - 2018-04-02 00:48:53 --> Model Class Initialized
INFO - 2018-04-02 00:48:53 --> Model Class Initialized
INFO - 2018-04-02 00:48:53 --> Model Class Initialized
INFO - 2018-04-02 00:48:53 --> Model Class Initialized
DEBUG - 2018-04-02 00:48:53 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-04-02 00:48:53 --> Severity: Notice --> Undefined variable: horas_proyecto D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 1651
ERROR - 2018-04-02 00:48:53 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 1651
INFO - 2018-04-02 00:48:53 --> Final output sent to browser
DEBUG - 2018-04-02 00:48:53 --> Total execution time: 0.1219
INFO - 2018-04-02 00:49:10 --> Config Class Initialized
INFO - 2018-04-02 00:49:10 --> Hooks Class Initialized
DEBUG - 2018-04-02 00:49:10 --> UTF-8 Support Enabled
INFO - 2018-04-02 00:49:10 --> Utf8 Class Initialized
INFO - 2018-04-02 00:49:10 --> URI Class Initialized
INFO - 2018-04-02 00:49:10 --> Router Class Initialized
INFO - 2018-04-02 00:49:10 --> Output Class Initialized
INFO - 2018-04-02 00:49:10 --> Security Class Initialized
DEBUG - 2018-04-02 00:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 00:49:10 --> Input Class Initialized
INFO - 2018-04-02 00:49:10 --> Language Class Initialized
INFO - 2018-04-02 00:49:10 --> Loader Class Initialized
INFO - 2018-04-02 00:49:10 --> Helper loaded: url_helper
INFO - 2018-04-02 00:49:10 --> Helper loaded: form_helper
INFO - 2018-04-02 00:49:10 --> Database Driver Class Initialized
DEBUG - 2018-04-02 00:49:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 00:49:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 00:49:10 --> Form Validation Class Initialized
INFO - 2018-04-02 00:49:10 --> Model Class Initialized
INFO - 2018-04-02 00:49:10 --> Controller Class Initialized
INFO - 2018-04-02 00:49:10 --> Model Class Initialized
INFO - 2018-04-02 00:49:10 --> Model Class Initialized
INFO - 2018-04-02 00:49:10 --> Model Class Initialized
INFO - 2018-04-02 00:49:10 --> Model Class Initialized
DEBUG - 2018-04-02 00:49:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-02 00:49:10 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-02 00:49:10 --> Final output sent to browser
DEBUG - 2018-04-02 00:49:10 --> Total execution time: 0.0588
INFO - 2018-04-02 00:49:10 --> Config Class Initialized
INFO - 2018-04-02 00:49:10 --> Hooks Class Initialized
DEBUG - 2018-04-02 00:49:10 --> UTF-8 Support Enabled
INFO - 2018-04-02 00:49:10 --> Utf8 Class Initialized
INFO - 2018-04-02 00:49:10 --> URI Class Initialized
INFO - 2018-04-02 00:49:10 --> Router Class Initialized
INFO - 2018-04-02 00:49:10 --> Output Class Initialized
INFO - 2018-04-02 00:49:10 --> Security Class Initialized
DEBUG - 2018-04-02 00:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 00:49:10 --> Input Class Initialized
INFO - 2018-04-02 00:49:10 --> Language Class Initialized
INFO - 2018-04-02 00:49:10 --> Loader Class Initialized
INFO - 2018-04-02 00:49:10 --> Helper loaded: url_helper
INFO - 2018-04-02 00:49:10 --> Helper loaded: form_helper
INFO - 2018-04-02 00:49:10 --> Database Driver Class Initialized
DEBUG - 2018-04-02 00:49:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 00:49:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 00:49:10 --> Form Validation Class Initialized
INFO - 2018-04-02 00:49:10 --> Model Class Initialized
INFO - 2018-04-02 00:49:10 --> Controller Class Initialized
INFO - 2018-04-02 00:49:10 --> Model Class Initialized
INFO - 2018-04-02 00:49:10 --> Model Class Initialized
INFO - 2018-04-02 00:49:10 --> Model Class Initialized
INFO - 2018-04-02 00:49:10 --> Model Class Initialized
DEBUG - 2018-04-02 00:49:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-02 00:49:12 --> Config Class Initialized
INFO - 2018-04-02 00:49:12 --> Hooks Class Initialized
DEBUG - 2018-04-02 00:49:12 --> UTF-8 Support Enabled
INFO - 2018-04-02 00:49:12 --> Utf8 Class Initialized
INFO - 2018-04-02 00:49:12 --> URI Class Initialized
INFO - 2018-04-02 00:49:12 --> Router Class Initialized
INFO - 2018-04-02 00:49:12 --> Output Class Initialized
INFO - 2018-04-02 00:49:12 --> Security Class Initialized
DEBUG - 2018-04-02 00:49:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 00:49:12 --> Input Class Initialized
INFO - 2018-04-02 00:49:12 --> Language Class Initialized
INFO - 2018-04-02 00:49:12 --> Loader Class Initialized
INFO - 2018-04-02 00:49:12 --> Helper loaded: url_helper
INFO - 2018-04-02 00:49:12 --> Helper loaded: form_helper
INFO - 2018-04-02 00:49:12 --> Database Driver Class Initialized
DEBUG - 2018-04-02 00:49:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 00:49:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 00:49:12 --> Form Validation Class Initialized
INFO - 2018-04-02 00:49:12 --> Model Class Initialized
INFO - 2018-04-02 00:49:12 --> Controller Class Initialized
INFO - 2018-04-02 00:49:12 --> Model Class Initialized
INFO - 2018-04-02 00:49:12 --> Model Class Initialized
INFO - 2018-04-02 00:49:12 --> Model Class Initialized
INFO - 2018-04-02 00:49:12 --> Model Class Initialized
DEBUG - 2018-04-02 00:49:12 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-04-02 00:49:12 --> Severity: Notice --> Undefined variable: horas_proyecto D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 1651
ERROR - 2018-04-02 00:49:12 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 1651
INFO - 2018-04-02 00:49:12 --> Final output sent to browser
DEBUG - 2018-04-02 00:49:12 --> Total execution time: 0.1328
INFO - 2018-04-02 00:50:13 --> Config Class Initialized
INFO - 2018-04-02 00:50:13 --> Hooks Class Initialized
DEBUG - 2018-04-02 00:50:13 --> UTF-8 Support Enabled
INFO - 2018-04-02 00:50:13 --> Utf8 Class Initialized
INFO - 2018-04-02 00:50:13 --> URI Class Initialized
INFO - 2018-04-02 00:50:13 --> Router Class Initialized
INFO - 2018-04-02 00:50:13 --> Output Class Initialized
INFO - 2018-04-02 00:50:13 --> Security Class Initialized
DEBUG - 2018-04-02 00:50:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 00:50:13 --> Input Class Initialized
INFO - 2018-04-02 00:50:13 --> Language Class Initialized
INFO - 2018-04-02 00:50:13 --> Loader Class Initialized
INFO - 2018-04-02 00:50:13 --> Helper loaded: url_helper
INFO - 2018-04-02 00:50:13 --> Helper loaded: form_helper
INFO - 2018-04-02 00:50:13 --> Database Driver Class Initialized
DEBUG - 2018-04-02 00:50:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 00:50:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 00:50:13 --> Form Validation Class Initialized
INFO - 2018-04-02 00:50:13 --> Model Class Initialized
INFO - 2018-04-02 00:50:13 --> Controller Class Initialized
INFO - 2018-04-02 00:50:13 --> Model Class Initialized
INFO - 2018-04-02 00:50:13 --> Model Class Initialized
INFO - 2018-04-02 00:50:13 --> Model Class Initialized
INFO - 2018-04-02 00:50:13 --> Model Class Initialized
DEBUG - 2018-04-02 00:50:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-02 00:50:13 --> Final output sent to browser
DEBUG - 2018-04-02 00:50:13 --> Total execution time: 0.1154
INFO - 2018-04-02 00:51:42 --> Config Class Initialized
INFO - 2018-04-02 00:51:42 --> Hooks Class Initialized
DEBUG - 2018-04-02 00:51:42 --> UTF-8 Support Enabled
INFO - 2018-04-02 00:51:42 --> Utf8 Class Initialized
INFO - 2018-04-02 00:51:42 --> URI Class Initialized
INFO - 2018-04-02 00:51:42 --> Router Class Initialized
INFO - 2018-04-02 00:51:42 --> Output Class Initialized
INFO - 2018-04-02 00:51:42 --> Security Class Initialized
DEBUG - 2018-04-02 00:51:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 00:51:42 --> Input Class Initialized
INFO - 2018-04-02 00:51:42 --> Language Class Initialized
INFO - 2018-04-02 00:51:42 --> Loader Class Initialized
INFO - 2018-04-02 00:51:42 --> Helper loaded: url_helper
INFO - 2018-04-02 00:51:42 --> Helper loaded: form_helper
INFO - 2018-04-02 00:51:42 --> Database Driver Class Initialized
DEBUG - 2018-04-02 00:51:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 00:51:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 00:51:42 --> Form Validation Class Initialized
INFO - 2018-04-02 00:51:42 --> Model Class Initialized
INFO - 2018-04-02 00:51:42 --> Controller Class Initialized
INFO - 2018-04-02 00:51:42 --> Model Class Initialized
INFO - 2018-04-02 00:51:42 --> Model Class Initialized
INFO - 2018-04-02 00:51:42 --> Model Class Initialized
INFO - 2018-04-02 00:51:42 --> Model Class Initialized
DEBUG - 2018-04-02 00:51:42 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-04-02 00:51:42 --> Severity: Notice --> Undefined variable: horas_proyecto D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 1651
ERROR - 2018-04-02 00:51:42 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 1651
INFO - 2018-04-02 00:51:42 --> Final output sent to browser
DEBUG - 2018-04-02 00:51:42 --> Total execution time: 0.1222
INFO - 2018-04-02 00:52:09 --> Config Class Initialized
INFO - 2018-04-02 00:52:09 --> Hooks Class Initialized
DEBUG - 2018-04-02 00:52:09 --> UTF-8 Support Enabled
INFO - 2018-04-02 00:52:09 --> Utf8 Class Initialized
INFO - 2018-04-02 00:52:09 --> URI Class Initialized
INFO - 2018-04-02 00:52:09 --> Router Class Initialized
INFO - 2018-04-02 00:52:09 --> Output Class Initialized
INFO - 2018-04-02 00:52:09 --> Security Class Initialized
DEBUG - 2018-04-02 00:52:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 00:52:09 --> Input Class Initialized
INFO - 2018-04-02 00:52:09 --> Language Class Initialized
INFO - 2018-04-02 00:52:09 --> Loader Class Initialized
INFO - 2018-04-02 00:52:09 --> Helper loaded: url_helper
INFO - 2018-04-02 00:52:09 --> Helper loaded: form_helper
INFO - 2018-04-02 00:52:09 --> Database Driver Class Initialized
DEBUG - 2018-04-02 00:52:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 00:52:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 00:52:09 --> Form Validation Class Initialized
INFO - 2018-04-02 00:52:09 --> Model Class Initialized
INFO - 2018-04-02 00:52:09 --> Controller Class Initialized
INFO - 2018-04-02 00:52:09 --> Model Class Initialized
INFO - 2018-04-02 00:52:09 --> Model Class Initialized
INFO - 2018-04-02 00:52:09 --> Model Class Initialized
INFO - 2018-04-02 00:52:09 --> Model Class Initialized
DEBUG - 2018-04-02 00:52:09 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-04-02 00:52:09 --> Severity: Notice --> Undefined variable: horas_proyecto D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 1651
ERROR - 2018-04-02 00:52:09 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 1651
INFO - 2018-04-02 00:52:09 --> Final output sent to browser
DEBUG - 2018-04-02 00:52:09 --> Total execution time: 0.1391
INFO - 2018-04-02 00:52:29 --> Config Class Initialized
INFO - 2018-04-02 00:52:29 --> Hooks Class Initialized
DEBUG - 2018-04-02 00:52:29 --> UTF-8 Support Enabled
INFO - 2018-04-02 00:52:29 --> Utf8 Class Initialized
INFO - 2018-04-02 00:52:29 --> URI Class Initialized
INFO - 2018-04-02 00:52:29 --> Router Class Initialized
INFO - 2018-04-02 00:52:29 --> Output Class Initialized
INFO - 2018-04-02 00:52:29 --> Security Class Initialized
DEBUG - 2018-04-02 00:52:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 00:52:29 --> Input Class Initialized
INFO - 2018-04-02 00:52:29 --> Language Class Initialized
INFO - 2018-04-02 00:52:29 --> Loader Class Initialized
INFO - 2018-04-02 00:52:29 --> Helper loaded: url_helper
INFO - 2018-04-02 00:52:29 --> Helper loaded: form_helper
INFO - 2018-04-02 00:52:29 --> Database Driver Class Initialized
DEBUG - 2018-04-02 00:52:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 00:52:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 00:52:29 --> Form Validation Class Initialized
INFO - 2018-04-02 00:52:29 --> Model Class Initialized
INFO - 2018-04-02 00:52:29 --> Controller Class Initialized
INFO - 2018-04-02 00:52:29 --> Model Class Initialized
INFO - 2018-04-02 00:52:29 --> Model Class Initialized
INFO - 2018-04-02 00:52:29 --> Model Class Initialized
INFO - 2018-04-02 00:52:29 --> Model Class Initialized
DEBUG - 2018-04-02 00:52:29 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-04-02 00:52:29 --> Severity: Notice --> Undefined variable: horas_proyecto D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 1651
ERROR - 2018-04-02 00:52:29 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 1651
INFO - 2018-04-02 00:52:29 --> Final output sent to browser
DEBUG - 2018-04-02 00:52:29 --> Total execution time: 0.1211
INFO - 2018-04-02 00:53:42 --> Config Class Initialized
INFO - 2018-04-02 00:53:42 --> Hooks Class Initialized
DEBUG - 2018-04-02 00:53:42 --> UTF-8 Support Enabled
INFO - 2018-04-02 00:53:42 --> Utf8 Class Initialized
INFO - 2018-04-02 00:53:42 --> URI Class Initialized
INFO - 2018-04-02 00:53:42 --> Router Class Initialized
INFO - 2018-04-02 00:53:42 --> Output Class Initialized
INFO - 2018-04-02 00:53:42 --> Security Class Initialized
DEBUG - 2018-04-02 00:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 00:53:42 --> Input Class Initialized
INFO - 2018-04-02 00:53:42 --> Language Class Initialized
INFO - 2018-04-02 00:53:42 --> Loader Class Initialized
INFO - 2018-04-02 00:53:42 --> Helper loaded: url_helper
INFO - 2018-04-02 00:53:42 --> Helper loaded: form_helper
INFO - 2018-04-02 00:53:42 --> Database Driver Class Initialized
DEBUG - 2018-04-02 00:53:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 00:53:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 00:53:42 --> Form Validation Class Initialized
INFO - 2018-04-02 00:53:42 --> Model Class Initialized
INFO - 2018-04-02 00:53:42 --> Controller Class Initialized
INFO - 2018-04-02 00:53:42 --> Model Class Initialized
INFO - 2018-04-02 00:53:42 --> Model Class Initialized
INFO - 2018-04-02 00:53:42 --> Model Class Initialized
INFO - 2018-04-02 00:53:42 --> Model Class Initialized
DEBUG - 2018-04-02 00:53:42 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-04-02 00:53:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 1690
ERROR - 2018-04-02 00:53:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 1695
ERROR - 2018-04-02 00:53:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 1699
ERROR - 2018-04-02 00:53:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 1706
ERROR - 2018-04-02 00:53:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 1690
ERROR - 2018-04-02 00:53:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 1695
ERROR - 2018-04-02 00:53:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 1699
ERROR - 2018-04-02 00:53:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 1706
ERROR - 2018-04-02 00:53:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 1690
ERROR - 2018-04-02 00:53:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 1695
ERROR - 2018-04-02 00:53:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 1699
ERROR - 2018-04-02 00:53:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 1706
ERROR - 2018-04-02 00:53:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 1690
ERROR - 2018-04-02 00:53:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 1695
ERROR - 2018-04-02 00:53:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 1699
ERROR - 2018-04-02 00:53:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 1706
ERROR - 2018-04-02 00:53:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\instateccr\controlcostos\instatec_sys\core\Exceptions.php:271) D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 1739
ERROR - 2018-04-02 00:53:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\instateccr\controlcostos\instatec_sys\core\Exceptions.php:271) D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 1742
INFO - 2018-04-02 00:53:42 --> Final output sent to browser
DEBUG - 2018-04-02 00:53:42 --> Total execution time: 0.1640
INFO - 2018-04-02 00:54:44 --> Config Class Initialized
INFO - 2018-04-02 00:54:44 --> Hooks Class Initialized
DEBUG - 2018-04-02 00:54:44 --> UTF-8 Support Enabled
INFO - 2018-04-02 00:54:44 --> Utf8 Class Initialized
INFO - 2018-04-02 00:54:44 --> URI Class Initialized
INFO - 2018-04-02 00:54:44 --> Router Class Initialized
INFO - 2018-04-02 00:54:44 --> Output Class Initialized
INFO - 2018-04-02 00:54:44 --> Security Class Initialized
DEBUG - 2018-04-02 00:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 00:54:44 --> Input Class Initialized
INFO - 2018-04-02 00:54:44 --> Language Class Initialized
INFO - 2018-04-02 00:54:44 --> Loader Class Initialized
INFO - 2018-04-02 00:54:44 --> Helper loaded: url_helper
INFO - 2018-04-02 00:54:44 --> Helper loaded: form_helper
INFO - 2018-04-02 00:54:44 --> Database Driver Class Initialized
DEBUG - 2018-04-02 00:54:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 00:54:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 00:54:44 --> Form Validation Class Initialized
INFO - 2018-04-02 00:54:44 --> Model Class Initialized
INFO - 2018-04-02 00:54:44 --> Controller Class Initialized
INFO - 2018-04-02 00:54:44 --> Model Class Initialized
INFO - 2018-04-02 00:54:44 --> Model Class Initialized
INFO - 2018-04-02 00:54:44 --> Model Class Initialized
INFO - 2018-04-02 00:54:44 --> Model Class Initialized
DEBUG - 2018-04-02 00:54:44 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-04-02 00:54:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 1690
ERROR - 2018-04-02 00:54:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 1690
ERROR - 2018-04-02 00:54:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 1690
ERROR - 2018-04-02 00:54:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 1690
INFO - 2018-04-02 00:54:44 --> Final output sent to browser
DEBUG - 2018-04-02 00:54:44 --> Total execution time: 0.1481
INFO - 2018-04-02 00:54:53 --> Config Class Initialized
INFO - 2018-04-02 00:54:53 --> Hooks Class Initialized
DEBUG - 2018-04-02 00:54:53 --> UTF-8 Support Enabled
INFO - 2018-04-02 00:54:53 --> Utf8 Class Initialized
INFO - 2018-04-02 00:54:53 --> URI Class Initialized
INFO - 2018-04-02 00:54:53 --> Router Class Initialized
INFO - 2018-04-02 00:54:53 --> Output Class Initialized
INFO - 2018-04-02 00:54:53 --> Security Class Initialized
DEBUG - 2018-04-02 00:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 00:54:53 --> Input Class Initialized
INFO - 2018-04-02 00:54:53 --> Language Class Initialized
INFO - 2018-04-02 00:54:53 --> Loader Class Initialized
INFO - 2018-04-02 00:54:53 --> Helper loaded: url_helper
INFO - 2018-04-02 00:54:53 --> Helper loaded: form_helper
INFO - 2018-04-02 00:54:53 --> Database Driver Class Initialized
DEBUG - 2018-04-02 00:54:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 00:54:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 00:54:53 --> Form Validation Class Initialized
INFO - 2018-04-02 00:54:53 --> Model Class Initialized
INFO - 2018-04-02 00:54:53 --> Controller Class Initialized
INFO - 2018-04-02 00:54:53 --> Model Class Initialized
INFO - 2018-04-02 00:54:53 --> Model Class Initialized
INFO - 2018-04-02 00:54:53 --> Model Class Initialized
INFO - 2018-04-02 00:54:53 --> Model Class Initialized
DEBUG - 2018-04-02 00:54:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-02 00:54:53 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-02 00:54:53 --> Final output sent to browser
DEBUG - 2018-04-02 00:54:53 --> Total execution time: 0.0686
INFO - 2018-04-02 00:54:53 --> Config Class Initialized
INFO - 2018-04-02 00:54:53 --> Hooks Class Initialized
DEBUG - 2018-04-02 00:54:53 --> UTF-8 Support Enabled
INFO - 2018-04-02 00:54:53 --> Utf8 Class Initialized
INFO - 2018-04-02 00:54:53 --> URI Class Initialized
INFO - 2018-04-02 00:54:53 --> Router Class Initialized
INFO - 2018-04-02 00:54:53 --> Output Class Initialized
INFO - 2018-04-02 00:54:53 --> Security Class Initialized
DEBUG - 2018-04-02 00:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 00:54:53 --> Input Class Initialized
INFO - 2018-04-02 00:54:53 --> Language Class Initialized
INFO - 2018-04-02 00:54:53 --> Loader Class Initialized
INFO - 2018-04-02 00:54:53 --> Helper loaded: url_helper
INFO - 2018-04-02 00:54:53 --> Helper loaded: form_helper
INFO - 2018-04-02 00:54:53 --> Database Driver Class Initialized
DEBUG - 2018-04-02 00:54:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 00:54:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 00:54:53 --> Form Validation Class Initialized
INFO - 2018-04-02 00:54:53 --> Model Class Initialized
INFO - 2018-04-02 00:54:53 --> Controller Class Initialized
INFO - 2018-04-02 00:54:53 --> Model Class Initialized
INFO - 2018-04-02 00:54:53 --> Model Class Initialized
INFO - 2018-04-02 00:54:53 --> Model Class Initialized
INFO - 2018-04-02 00:54:53 --> Model Class Initialized
DEBUG - 2018-04-02 00:54:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-02 00:54:54 --> Config Class Initialized
INFO - 2018-04-02 00:54:54 --> Hooks Class Initialized
DEBUG - 2018-04-02 00:54:54 --> UTF-8 Support Enabled
INFO - 2018-04-02 00:54:54 --> Utf8 Class Initialized
INFO - 2018-04-02 00:54:54 --> URI Class Initialized
INFO - 2018-04-02 00:54:54 --> Router Class Initialized
INFO - 2018-04-02 00:54:54 --> Output Class Initialized
INFO - 2018-04-02 00:54:54 --> Security Class Initialized
DEBUG - 2018-04-02 00:54:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 00:54:55 --> Input Class Initialized
INFO - 2018-04-02 00:54:55 --> Language Class Initialized
INFO - 2018-04-02 00:54:55 --> Loader Class Initialized
INFO - 2018-04-02 00:54:55 --> Helper loaded: url_helper
INFO - 2018-04-02 00:54:55 --> Helper loaded: form_helper
INFO - 2018-04-02 00:54:55 --> Database Driver Class Initialized
DEBUG - 2018-04-02 00:54:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 00:54:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 00:54:55 --> Form Validation Class Initialized
INFO - 2018-04-02 00:54:55 --> Model Class Initialized
INFO - 2018-04-02 00:54:55 --> Controller Class Initialized
INFO - 2018-04-02 00:54:55 --> Model Class Initialized
INFO - 2018-04-02 00:54:55 --> Model Class Initialized
INFO - 2018-04-02 00:54:55 --> Model Class Initialized
INFO - 2018-04-02 00:54:55 --> Model Class Initialized
DEBUG - 2018-04-02 00:54:55 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-04-02 00:54:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 1690
ERROR - 2018-04-02 00:54:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 1690
ERROR - 2018-04-02 00:54:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 1690
ERROR - 2018-04-02 00:54:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 1690
INFO - 2018-04-02 00:54:55 --> Final output sent to browser
DEBUG - 2018-04-02 00:54:55 --> Total execution time: 0.1396
INFO - 2018-04-02 00:56:20 --> Config Class Initialized
INFO - 2018-04-02 00:56:20 --> Hooks Class Initialized
DEBUG - 2018-04-02 00:56:20 --> UTF-8 Support Enabled
INFO - 2018-04-02 00:56:20 --> Utf8 Class Initialized
INFO - 2018-04-02 00:56:20 --> URI Class Initialized
INFO - 2018-04-02 00:56:20 --> Router Class Initialized
INFO - 2018-04-02 00:56:20 --> Output Class Initialized
INFO - 2018-04-02 00:56:20 --> Security Class Initialized
DEBUG - 2018-04-02 00:56:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 00:56:20 --> Input Class Initialized
INFO - 2018-04-02 00:56:20 --> Language Class Initialized
INFO - 2018-04-02 00:56:20 --> Loader Class Initialized
INFO - 2018-04-02 00:56:20 --> Helper loaded: url_helper
INFO - 2018-04-02 00:56:20 --> Helper loaded: form_helper
INFO - 2018-04-02 00:56:20 --> Database Driver Class Initialized
DEBUG - 2018-04-02 00:56:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 00:56:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 00:56:20 --> Form Validation Class Initialized
INFO - 2018-04-02 00:56:20 --> Model Class Initialized
INFO - 2018-04-02 00:56:20 --> Controller Class Initialized
INFO - 2018-04-02 00:56:20 --> Model Class Initialized
INFO - 2018-04-02 00:56:20 --> Model Class Initialized
INFO - 2018-04-02 00:56:20 --> Model Class Initialized
INFO - 2018-04-02 00:56:20 --> Model Class Initialized
DEBUG - 2018-04-02 00:56:20 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-04-02 00:56:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 1690
ERROR - 2018-04-02 00:56:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 1690
ERROR - 2018-04-02 00:56:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 1690
ERROR - 2018-04-02 00:56:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 1690
INFO - 2018-04-02 00:56:20 --> Final output sent to browser
DEBUG - 2018-04-02 00:56:20 --> Total execution time: 0.1493
INFO - 2018-04-02 00:59:28 --> Config Class Initialized
INFO - 2018-04-02 00:59:28 --> Hooks Class Initialized
DEBUG - 2018-04-02 00:59:28 --> UTF-8 Support Enabled
INFO - 2018-04-02 00:59:28 --> Utf8 Class Initialized
INFO - 2018-04-02 00:59:28 --> URI Class Initialized
INFO - 2018-04-02 00:59:28 --> Router Class Initialized
INFO - 2018-04-02 00:59:28 --> Output Class Initialized
INFO - 2018-04-02 00:59:28 --> Security Class Initialized
DEBUG - 2018-04-02 00:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 00:59:28 --> Input Class Initialized
INFO - 2018-04-02 00:59:28 --> Language Class Initialized
INFO - 2018-04-02 00:59:28 --> Loader Class Initialized
INFO - 2018-04-02 00:59:28 --> Helper loaded: url_helper
INFO - 2018-04-02 00:59:28 --> Helper loaded: form_helper
INFO - 2018-04-02 00:59:28 --> Database Driver Class Initialized
DEBUG - 2018-04-02 00:59:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 00:59:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 00:59:28 --> Form Validation Class Initialized
INFO - 2018-04-02 00:59:28 --> Model Class Initialized
INFO - 2018-04-02 00:59:28 --> Controller Class Initialized
INFO - 2018-04-02 00:59:28 --> Model Class Initialized
INFO - 2018-04-02 00:59:28 --> Model Class Initialized
INFO - 2018-04-02 00:59:28 --> Model Class Initialized
INFO - 2018-04-02 00:59:28 --> Model Class Initialized
DEBUG - 2018-04-02 00:59:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-02 00:59:28 --> Final output sent to browser
DEBUG - 2018-04-02 00:59:28 --> Total execution time: 0.1366
INFO - 2018-04-02 00:59:59 --> Config Class Initialized
INFO - 2018-04-02 00:59:59 --> Hooks Class Initialized
DEBUG - 2018-04-02 00:59:59 --> UTF-8 Support Enabled
INFO - 2018-04-02 00:59:59 --> Utf8 Class Initialized
INFO - 2018-04-02 00:59:59 --> URI Class Initialized
INFO - 2018-04-02 00:59:59 --> Router Class Initialized
INFO - 2018-04-02 00:59:59 --> Output Class Initialized
INFO - 2018-04-02 00:59:59 --> Security Class Initialized
DEBUG - 2018-04-02 00:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 00:59:59 --> Input Class Initialized
INFO - 2018-04-02 00:59:59 --> Language Class Initialized
INFO - 2018-04-02 00:59:59 --> Loader Class Initialized
INFO - 2018-04-02 00:59:59 --> Helper loaded: url_helper
INFO - 2018-04-02 00:59:59 --> Helper loaded: form_helper
INFO - 2018-04-02 00:59:59 --> Database Driver Class Initialized
DEBUG - 2018-04-02 00:59:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 00:59:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 00:59:59 --> Form Validation Class Initialized
INFO - 2018-04-02 00:59:59 --> Model Class Initialized
INFO - 2018-04-02 00:59:59 --> Controller Class Initialized
INFO - 2018-04-02 00:59:59 --> Model Class Initialized
INFO - 2018-04-02 00:59:59 --> Model Class Initialized
INFO - 2018-04-02 00:59:59 --> Model Class Initialized
INFO - 2018-04-02 00:59:59 --> Model Class Initialized
DEBUG - 2018-04-02 00:59:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-02 00:59:59 --> Final output sent to browser
DEBUG - 2018-04-02 00:59:59 --> Total execution time: 0.1471
INFO - 2018-04-02 01:00:30 --> Config Class Initialized
INFO - 2018-04-02 01:00:30 --> Hooks Class Initialized
DEBUG - 2018-04-02 01:00:30 --> UTF-8 Support Enabled
INFO - 2018-04-02 01:00:30 --> Utf8 Class Initialized
INFO - 2018-04-02 01:00:30 --> URI Class Initialized
INFO - 2018-04-02 01:00:30 --> Router Class Initialized
INFO - 2018-04-02 01:00:30 --> Output Class Initialized
INFO - 2018-04-02 01:00:30 --> Security Class Initialized
DEBUG - 2018-04-02 01:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 01:00:30 --> Input Class Initialized
INFO - 2018-04-02 01:00:30 --> Language Class Initialized
INFO - 2018-04-02 01:00:30 --> Loader Class Initialized
INFO - 2018-04-02 01:00:30 --> Helper loaded: url_helper
INFO - 2018-04-02 01:00:30 --> Helper loaded: form_helper
INFO - 2018-04-02 01:00:30 --> Database Driver Class Initialized
DEBUG - 2018-04-02 01:00:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 01:00:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 01:00:30 --> Form Validation Class Initialized
INFO - 2018-04-02 01:00:30 --> Model Class Initialized
INFO - 2018-04-02 01:00:30 --> Controller Class Initialized
INFO - 2018-04-02 01:00:30 --> Model Class Initialized
INFO - 2018-04-02 01:00:30 --> Model Class Initialized
INFO - 2018-04-02 01:00:30 --> Model Class Initialized
INFO - 2018-04-02 01:00:30 --> Model Class Initialized
DEBUG - 2018-04-02 01:00:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-02 01:00:31 --> Config Class Initialized
INFO - 2018-04-02 01:00:31 --> Hooks Class Initialized
DEBUG - 2018-04-02 01:00:31 --> UTF-8 Support Enabled
INFO - 2018-04-02 01:00:31 --> Utf8 Class Initialized
INFO - 2018-04-02 01:00:31 --> URI Class Initialized
INFO - 2018-04-02 01:00:31 --> Router Class Initialized
INFO - 2018-04-02 01:00:31 --> Output Class Initialized
INFO - 2018-04-02 01:00:31 --> Security Class Initialized
DEBUG - 2018-04-02 01:00:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 01:00:31 --> Input Class Initialized
INFO - 2018-04-02 01:00:31 --> Language Class Initialized
INFO - 2018-04-02 01:00:31 --> Loader Class Initialized
INFO - 2018-04-02 01:00:31 --> Helper loaded: url_helper
INFO - 2018-04-02 01:00:31 --> Helper loaded: form_helper
INFO - 2018-04-02 01:00:31 --> Database Driver Class Initialized
DEBUG - 2018-04-02 01:00:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 01:00:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 01:00:31 --> Form Validation Class Initialized
INFO - 2018-04-02 01:00:31 --> Model Class Initialized
INFO - 2018-04-02 01:00:31 --> Controller Class Initialized
INFO - 2018-04-02 01:00:31 --> Model Class Initialized
INFO - 2018-04-02 01:00:31 --> Model Class Initialized
INFO - 2018-04-02 01:00:31 --> Model Class Initialized
INFO - 2018-04-02 01:00:31 --> Model Class Initialized
DEBUG - 2018-04-02 01:00:31 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-04-02 01:00:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 1547
ERROR - 2018-04-02 01:00:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 1547
INFO - 2018-04-02 01:00:31 --> Final output sent to browser
DEBUG - 2018-04-02 01:00:31 --> Total execution time: 0.1403
INFO - 2018-04-02 01:01:29 --> Config Class Initialized
INFO - 2018-04-02 01:01:29 --> Hooks Class Initialized
DEBUG - 2018-04-02 01:01:29 --> UTF-8 Support Enabled
INFO - 2018-04-02 01:01:29 --> Utf8 Class Initialized
INFO - 2018-04-02 01:01:29 --> URI Class Initialized
INFO - 2018-04-02 01:01:29 --> Router Class Initialized
INFO - 2018-04-02 01:01:29 --> Output Class Initialized
INFO - 2018-04-02 01:01:29 --> Security Class Initialized
DEBUG - 2018-04-02 01:01:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 01:01:29 --> Input Class Initialized
INFO - 2018-04-02 01:01:29 --> Language Class Initialized
INFO - 2018-04-02 01:01:29 --> Loader Class Initialized
INFO - 2018-04-02 01:01:29 --> Helper loaded: url_helper
INFO - 2018-04-02 01:01:29 --> Helper loaded: form_helper
INFO - 2018-04-02 01:01:29 --> Database Driver Class Initialized
DEBUG - 2018-04-02 01:01:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 01:01:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 01:01:29 --> Form Validation Class Initialized
INFO - 2018-04-02 01:01:29 --> Model Class Initialized
INFO - 2018-04-02 01:01:29 --> Controller Class Initialized
INFO - 2018-04-02 01:01:29 --> Model Class Initialized
INFO - 2018-04-02 01:01:29 --> Model Class Initialized
INFO - 2018-04-02 01:01:29 --> Model Class Initialized
INFO - 2018-04-02 01:01:29 --> Model Class Initialized
DEBUG - 2018-04-02 01:01:29 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-04-02 01:01:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 1547
ERROR - 2018-04-02 01:01:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 1547
INFO - 2018-04-02 01:01:29 --> Final output sent to browser
DEBUG - 2018-04-02 01:01:29 --> Total execution time: 0.1358
INFO - 2018-04-02 01:01:40 --> Config Class Initialized
INFO - 2018-04-02 01:01:40 --> Hooks Class Initialized
DEBUG - 2018-04-02 01:01:40 --> UTF-8 Support Enabled
INFO - 2018-04-02 01:01:40 --> Utf8 Class Initialized
INFO - 2018-04-02 01:01:40 --> URI Class Initialized
INFO - 2018-04-02 01:01:40 --> Router Class Initialized
INFO - 2018-04-02 01:01:40 --> Output Class Initialized
INFO - 2018-04-02 01:01:40 --> Security Class Initialized
DEBUG - 2018-04-02 01:01:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 01:01:40 --> Input Class Initialized
INFO - 2018-04-02 01:01:40 --> Language Class Initialized
INFO - 2018-04-02 01:01:40 --> Loader Class Initialized
INFO - 2018-04-02 01:01:40 --> Helper loaded: url_helper
INFO - 2018-04-02 01:01:40 --> Helper loaded: form_helper
INFO - 2018-04-02 01:01:40 --> Database Driver Class Initialized
DEBUG - 2018-04-02 01:01:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 01:01:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 01:01:40 --> Form Validation Class Initialized
INFO - 2018-04-02 01:01:40 --> Model Class Initialized
INFO - 2018-04-02 01:01:40 --> Controller Class Initialized
INFO - 2018-04-02 01:01:40 --> Model Class Initialized
INFO - 2018-04-02 01:01:40 --> Model Class Initialized
INFO - 2018-04-02 01:01:40 --> Model Class Initialized
INFO - 2018-04-02 01:01:40 --> Model Class Initialized
DEBUG - 2018-04-02 01:01:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-02 01:01:49 --> Config Class Initialized
INFO - 2018-04-02 01:01:49 --> Hooks Class Initialized
DEBUG - 2018-04-02 01:01:49 --> UTF-8 Support Enabled
INFO - 2018-04-02 01:01:49 --> Utf8 Class Initialized
INFO - 2018-04-02 01:01:49 --> URI Class Initialized
INFO - 2018-04-02 01:01:49 --> Router Class Initialized
INFO - 2018-04-02 01:01:49 --> Output Class Initialized
INFO - 2018-04-02 01:01:49 --> Security Class Initialized
DEBUG - 2018-04-02 01:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 01:01:49 --> Input Class Initialized
INFO - 2018-04-02 01:01:49 --> Language Class Initialized
INFO - 2018-04-02 01:01:49 --> Loader Class Initialized
INFO - 2018-04-02 01:01:49 --> Helper loaded: url_helper
INFO - 2018-04-02 01:01:49 --> Helper loaded: form_helper
INFO - 2018-04-02 01:01:49 --> Database Driver Class Initialized
DEBUG - 2018-04-02 01:01:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 01:01:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 01:01:49 --> Form Validation Class Initialized
INFO - 2018-04-02 01:01:49 --> Model Class Initialized
INFO - 2018-04-02 01:01:49 --> Controller Class Initialized
INFO - 2018-04-02 01:01:49 --> Model Class Initialized
INFO - 2018-04-02 01:01:49 --> Model Class Initialized
INFO - 2018-04-02 01:01:49 --> Model Class Initialized
INFO - 2018-04-02 01:01:49 --> Model Class Initialized
DEBUG - 2018-04-02 01:01:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-02 01:01:55 --> Config Class Initialized
INFO - 2018-04-02 01:01:55 --> Hooks Class Initialized
DEBUG - 2018-04-02 01:01:55 --> UTF-8 Support Enabled
INFO - 2018-04-02 01:01:55 --> Utf8 Class Initialized
INFO - 2018-04-02 01:01:55 --> URI Class Initialized
INFO - 2018-04-02 01:01:55 --> Router Class Initialized
INFO - 2018-04-02 01:01:55 --> Output Class Initialized
INFO - 2018-04-02 01:01:55 --> Security Class Initialized
DEBUG - 2018-04-02 01:01:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 01:01:55 --> Input Class Initialized
INFO - 2018-04-02 01:01:55 --> Language Class Initialized
INFO - 2018-04-02 01:01:55 --> Loader Class Initialized
INFO - 2018-04-02 01:01:55 --> Helper loaded: url_helper
INFO - 2018-04-02 01:01:55 --> Helper loaded: form_helper
INFO - 2018-04-02 01:01:55 --> Database Driver Class Initialized
DEBUG - 2018-04-02 01:01:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 01:01:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 01:01:55 --> Form Validation Class Initialized
INFO - 2018-04-02 01:01:55 --> Model Class Initialized
INFO - 2018-04-02 01:01:55 --> Controller Class Initialized
INFO - 2018-04-02 01:01:55 --> Model Class Initialized
INFO - 2018-04-02 01:01:55 --> Model Class Initialized
INFO - 2018-04-02 01:01:55 --> Model Class Initialized
INFO - 2018-04-02 01:01:55 --> Model Class Initialized
DEBUG - 2018-04-02 01:01:55 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-04-02 01:01:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 1547
ERROR - 2018-04-02 01:01:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 1547
INFO - 2018-04-02 01:01:56 --> Final output sent to browser
DEBUG - 2018-04-02 01:01:56 --> Total execution time: 0.1381
INFO - 2018-04-02 01:02:44 --> Config Class Initialized
INFO - 2018-04-02 01:02:44 --> Hooks Class Initialized
DEBUG - 2018-04-02 01:02:44 --> UTF-8 Support Enabled
INFO - 2018-04-02 01:02:44 --> Utf8 Class Initialized
INFO - 2018-04-02 01:02:44 --> URI Class Initialized
INFO - 2018-04-02 01:02:44 --> Router Class Initialized
INFO - 2018-04-02 01:02:44 --> Output Class Initialized
INFO - 2018-04-02 01:02:44 --> Security Class Initialized
DEBUG - 2018-04-02 01:02:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 01:02:44 --> Input Class Initialized
INFO - 2018-04-02 01:02:44 --> Language Class Initialized
INFO - 2018-04-02 01:02:44 --> Loader Class Initialized
INFO - 2018-04-02 01:02:44 --> Helper loaded: url_helper
INFO - 2018-04-02 01:02:44 --> Helper loaded: form_helper
INFO - 2018-04-02 01:02:44 --> Database Driver Class Initialized
DEBUG - 2018-04-02 01:02:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 01:02:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 01:02:44 --> Form Validation Class Initialized
INFO - 2018-04-02 01:02:44 --> Model Class Initialized
INFO - 2018-04-02 01:02:44 --> Controller Class Initialized
INFO - 2018-04-02 01:02:44 --> Model Class Initialized
INFO - 2018-04-02 01:02:44 --> Model Class Initialized
INFO - 2018-04-02 01:02:44 --> Model Class Initialized
INFO - 2018-04-02 01:02:44 --> Model Class Initialized
DEBUG - 2018-04-02 01:02:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-02 01:02:44 --> Final output sent to browser
DEBUG - 2018-04-02 01:02:44 --> Total execution time: 0.1261
INFO - 2018-04-02 01:03:07 --> Config Class Initialized
INFO - 2018-04-02 01:03:07 --> Hooks Class Initialized
DEBUG - 2018-04-02 01:03:07 --> UTF-8 Support Enabled
INFO - 2018-04-02 01:03:07 --> Utf8 Class Initialized
INFO - 2018-04-02 01:03:07 --> URI Class Initialized
INFO - 2018-04-02 01:03:07 --> Router Class Initialized
INFO - 2018-04-02 01:03:07 --> Output Class Initialized
INFO - 2018-04-02 01:03:07 --> Security Class Initialized
DEBUG - 2018-04-02 01:03:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 01:03:07 --> Input Class Initialized
INFO - 2018-04-02 01:03:07 --> Language Class Initialized
INFO - 2018-04-02 01:03:07 --> Loader Class Initialized
INFO - 2018-04-02 01:03:07 --> Helper loaded: url_helper
INFO - 2018-04-02 01:03:07 --> Helper loaded: form_helper
INFO - 2018-04-02 01:03:07 --> Database Driver Class Initialized
DEBUG - 2018-04-02 01:03:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 01:03:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 01:03:07 --> Form Validation Class Initialized
INFO - 2018-04-02 01:03:07 --> Model Class Initialized
INFO - 2018-04-02 01:03:07 --> Controller Class Initialized
INFO - 2018-04-02 01:03:07 --> Model Class Initialized
INFO - 2018-04-02 01:03:07 --> Model Class Initialized
INFO - 2018-04-02 01:03:07 --> Model Class Initialized
INFO - 2018-04-02 01:03:07 --> Model Class Initialized
DEBUG - 2018-04-02 01:03:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-02 01:03:09 --> Config Class Initialized
INFO - 2018-04-02 01:03:09 --> Hooks Class Initialized
DEBUG - 2018-04-02 01:03:09 --> UTF-8 Support Enabled
INFO - 2018-04-02 01:03:09 --> Utf8 Class Initialized
INFO - 2018-04-02 01:03:09 --> URI Class Initialized
INFO - 2018-04-02 01:03:09 --> Router Class Initialized
INFO - 2018-04-02 01:03:09 --> Output Class Initialized
INFO - 2018-04-02 01:03:09 --> Security Class Initialized
DEBUG - 2018-04-02 01:03:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 01:03:09 --> Input Class Initialized
INFO - 2018-04-02 01:03:09 --> Language Class Initialized
INFO - 2018-04-02 01:03:09 --> Loader Class Initialized
INFO - 2018-04-02 01:03:09 --> Helper loaded: url_helper
INFO - 2018-04-02 01:03:09 --> Helper loaded: form_helper
INFO - 2018-04-02 01:03:09 --> Database Driver Class Initialized
DEBUG - 2018-04-02 01:03:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 01:03:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 01:03:09 --> Form Validation Class Initialized
INFO - 2018-04-02 01:03:09 --> Model Class Initialized
INFO - 2018-04-02 01:03:09 --> Controller Class Initialized
INFO - 2018-04-02 01:03:09 --> Model Class Initialized
INFO - 2018-04-02 01:03:09 --> Model Class Initialized
INFO - 2018-04-02 01:03:09 --> Model Class Initialized
INFO - 2018-04-02 01:03:09 --> Model Class Initialized
DEBUG - 2018-04-02 01:03:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-02 01:03:10 --> Config Class Initialized
INFO - 2018-04-02 01:03:10 --> Hooks Class Initialized
DEBUG - 2018-04-02 01:03:10 --> UTF-8 Support Enabled
INFO - 2018-04-02 01:03:10 --> Utf8 Class Initialized
INFO - 2018-04-02 01:03:10 --> URI Class Initialized
INFO - 2018-04-02 01:03:10 --> Router Class Initialized
INFO - 2018-04-02 01:03:10 --> Output Class Initialized
INFO - 2018-04-02 01:03:10 --> Security Class Initialized
DEBUG - 2018-04-02 01:03:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 01:03:10 --> Input Class Initialized
INFO - 2018-04-02 01:03:10 --> Language Class Initialized
INFO - 2018-04-02 01:03:10 --> Loader Class Initialized
INFO - 2018-04-02 01:03:10 --> Helper loaded: url_helper
INFO - 2018-04-02 01:03:10 --> Helper loaded: form_helper
INFO - 2018-04-02 01:03:10 --> Database Driver Class Initialized
DEBUG - 2018-04-02 01:03:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 01:03:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 01:03:10 --> Form Validation Class Initialized
INFO - 2018-04-02 01:03:10 --> Model Class Initialized
INFO - 2018-04-02 01:03:10 --> Controller Class Initialized
INFO - 2018-04-02 01:03:10 --> Model Class Initialized
INFO - 2018-04-02 01:03:10 --> Model Class Initialized
INFO - 2018-04-02 01:03:10 --> Model Class Initialized
INFO - 2018-04-02 01:03:10 --> Model Class Initialized
DEBUG - 2018-04-02 01:03:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-02 01:03:10 --> Final output sent to browser
DEBUG - 2018-04-02 01:03:10 --> Total execution time: 0.1312
INFO - 2018-04-02 01:03:35 --> Config Class Initialized
INFO - 2018-04-02 01:03:35 --> Hooks Class Initialized
DEBUG - 2018-04-02 01:03:35 --> UTF-8 Support Enabled
INFO - 2018-04-02 01:03:35 --> Utf8 Class Initialized
INFO - 2018-04-02 01:03:35 --> URI Class Initialized
INFO - 2018-04-02 01:03:35 --> Router Class Initialized
INFO - 2018-04-02 01:03:35 --> Output Class Initialized
INFO - 2018-04-02 01:03:35 --> Security Class Initialized
DEBUG - 2018-04-02 01:03:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 01:03:35 --> Input Class Initialized
INFO - 2018-04-02 01:03:35 --> Language Class Initialized
INFO - 2018-04-02 01:03:35 --> Loader Class Initialized
INFO - 2018-04-02 01:03:35 --> Helper loaded: url_helper
INFO - 2018-04-02 01:03:35 --> Helper loaded: form_helper
INFO - 2018-04-02 01:03:35 --> Database Driver Class Initialized
DEBUG - 2018-04-02 01:03:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 01:03:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 01:03:35 --> Form Validation Class Initialized
INFO - 2018-04-02 01:03:35 --> Model Class Initialized
INFO - 2018-04-02 01:03:35 --> Controller Class Initialized
INFO - 2018-04-02 01:03:35 --> Model Class Initialized
INFO - 2018-04-02 01:03:35 --> Model Class Initialized
INFO - 2018-04-02 01:03:35 --> Model Class Initialized
INFO - 2018-04-02 01:03:35 --> Model Class Initialized
DEBUG - 2018-04-02 01:03:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-02 01:03:39 --> Config Class Initialized
INFO - 2018-04-02 01:03:39 --> Hooks Class Initialized
DEBUG - 2018-04-02 01:03:39 --> UTF-8 Support Enabled
INFO - 2018-04-02 01:03:39 --> Utf8 Class Initialized
INFO - 2018-04-02 01:03:39 --> URI Class Initialized
INFO - 2018-04-02 01:03:39 --> Router Class Initialized
INFO - 2018-04-02 01:03:39 --> Output Class Initialized
INFO - 2018-04-02 01:03:39 --> Security Class Initialized
DEBUG - 2018-04-02 01:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 01:03:39 --> Input Class Initialized
INFO - 2018-04-02 01:03:39 --> Language Class Initialized
INFO - 2018-04-02 01:03:39 --> Loader Class Initialized
INFO - 2018-04-02 01:03:39 --> Helper loaded: url_helper
INFO - 2018-04-02 01:03:39 --> Helper loaded: form_helper
INFO - 2018-04-02 01:03:39 --> Database Driver Class Initialized
DEBUG - 2018-04-02 01:03:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 01:03:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 01:03:39 --> Form Validation Class Initialized
INFO - 2018-04-02 01:03:39 --> Model Class Initialized
INFO - 2018-04-02 01:03:39 --> Controller Class Initialized
INFO - 2018-04-02 01:03:39 --> Model Class Initialized
INFO - 2018-04-02 01:03:39 --> Model Class Initialized
INFO - 2018-04-02 01:03:39 --> Model Class Initialized
INFO - 2018-04-02 01:03:39 --> Model Class Initialized
DEBUG - 2018-04-02 01:03:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-02 01:03:40 --> Final output sent to browser
DEBUG - 2018-04-02 01:03:40 --> Total execution time: 0.1325
INFO - 2018-04-02 01:04:26 --> Config Class Initialized
INFO - 2018-04-02 01:04:26 --> Hooks Class Initialized
DEBUG - 2018-04-02 01:04:26 --> UTF-8 Support Enabled
INFO - 2018-04-02 01:04:26 --> Utf8 Class Initialized
INFO - 2018-04-02 01:04:26 --> URI Class Initialized
INFO - 2018-04-02 01:04:26 --> Router Class Initialized
INFO - 2018-04-02 01:04:26 --> Output Class Initialized
INFO - 2018-04-02 01:04:26 --> Security Class Initialized
DEBUG - 2018-04-02 01:04:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 01:04:26 --> Input Class Initialized
INFO - 2018-04-02 01:04:26 --> Language Class Initialized
INFO - 2018-04-02 01:04:26 --> Loader Class Initialized
INFO - 2018-04-02 01:04:26 --> Helper loaded: url_helper
INFO - 2018-04-02 01:04:26 --> Helper loaded: form_helper
INFO - 2018-04-02 01:04:26 --> Database Driver Class Initialized
DEBUG - 2018-04-02 01:04:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 01:04:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 01:04:26 --> Form Validation Class Initialized
INFO - 2018-04-02 01:04:26 --> Model Class Initialized
INFO - 2018-04-02 01:04:26 --> Controller Class Initialized
INFO - 2018-04-02 01:04:26 --> Model Class Initialized
INFO - 2018-04-02 01:04:26 --> Model Class Initialized
INFO - 2018-04-02 01:04:26 --> Model Class Initialized
INFO - 2018-04-02 01:04:26 --> Model Class Initialized
DEBUG - 2018-04-02 01:04:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-02 01:04:28 --> Config Class Initialized
INFO - 2018-04-02 01:04:28 --> Hooks Class Initialized
DEBUG - 2018-04-02 01:04:28 --> UTF-8 Support Enabled
INFO - 2018-04-02 01:04:28 --> Utf8 Class Initialized
INFO - 2018-04-02 01:04:28 --> URI Class Initialized
INFO - 2018-04-02 01:04:28 --> Router Class Initialized
INFO - 2018-04-02 01:04:28 --> Output Class Initialized
INFO - 2018-04-02 01:04:28 --> Security Class Initialized
DEBUG - 2018-04-02 01:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 01:04:28 --> Input Class Initialized
INFO - 2018-04-02 01:04:28 --> Language Class Initialized
INFO - 2018-04-02 01:04:28 --> Loader Class Initialized
INFO - 2018-04-02 01:04:28 --> Helper loaded: url_helper
INFO - 2018-04-02 01:04:28 --> Helper loaded: form_helper
INFO - 2018-04-02 01:04:28 --> Database Driver Class Initialized
DEBUG - 2018-04-02 01:04:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 01:04:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 01:04:28 --> Form Validation Class Initialized
INFO - 2018-04-02 01:04:28 --> Model Class Initialized
INFO - 2018-04-02 01:04:28 --> Controller Class Initialized
INFO - 2018-04-02 01:04:29 --> Model Class Initialized
INFO - 2018-04-02 01:04:29 --> Model Class Initialized
INFO - 2018-04-02 01:04:29 --> Model Class Initialized
INFO - 2018-04-02 01:04:29 --> Model Class Initialized
DEBUG - 2018-04-02 01:04:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-02 01:04:30 --> Config Class Initialized
INFO - 2018-04-02 01:04:30 --> Hooks Class Initialized
DEBUG - 2018-04-02 01:04:30 --> UTF-8 Support Enabled
INFO - 2018-04-02 01:04:30 --> Utf8 Class Initialized
INFO - 2018-04-02 01:04:30 --> URI Class Initialized
INFO - 2018-04-02 01:04:30 --> Router Class Initialized
INFO - 2018-04-02 01:04:30 --> Output Class Initialized
INFO - 2018-04-02 01:04:30 --> Security Class Initialized
DEBUG - 2018-04-02 01:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 01:04:30 --> Input Class Initialized
INFO - 2018-04-02 01:04:30 --> Language Class Initialized
INFO - 2018-04-02 01:04:30 --> Loader Class Initialized
INFO - 2018-04-02 01:04:30 --> Helper loaded: url_helper
INFO - 2018-04-02 01:04:30 --> Helper loaded: form_helper
INFO - 2018-04-02 01:04:30 --> Database Driver Class Initialized
DEBUG - 2018-04-02 01:04:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 01:04:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 01:04:30 --> Form Validation Class Initialized
INFO - 2018-04-02 01:04:30 --> Model Class Initialized
INFO - 2018-04-02 01:04:30 --> Controller Class Initialized
INFO - 2018-04-02 01:04:30 --> Model Class Initialized
INFO - 2018-04-02 01:04:30 --> Model Class Initialized
INFO - 2018-04-02 01:04:30 --> Model Class Initialized
INFO - 2018-04-02 01:04:30 --> Model Class Initialized
DEBUG - 2018-04-02 01:04:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-02 01:04:30 --> Final output sent to browser
DEBUG - 2018-04-02 01:04:30 --> Total execution time: 0.1262
INFO - 2018-04-02 01:04:37 --> Config Class Initialized
INFO - 2018-04-02 01:04:37 --> Hooks Class Initialized
DEBUG - 2018-04-02 01:04:37 --> UTF-8 Support Enabled
INFO - 2018-04-02 01:04:37 --> Utf8 Class Initialized
INFO - 2018-04-02 01:04:37 --> URI Class Initialized
INFO - 2018-04-02 01:04:37 --> Router Class Initialized
INFO - 2018-04-02 01:04:37 --> Output Class Initialized
INFO - 2018-04-02 01:04:37 --> Security Class Initialized
DEBUG - 2018-04-02 01:04:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 01:04:37 --> Input Class Initialized
INFO - 2018-04-02 01:04:37 --> Language Class Initialized
INFO - 2018-04-02 01:04:37 --> Loader Class Initialized
INFO - 2018-04-02 01:04:37 --> Helper loaded: url_helper
INFO - 2018-04-02 01:04:37 --> Helper loaded: form_helper
INFO - 2018-04-02 01:04:37 --> Database Driver Class Initialized
DEBUG - 2018-04-02 01:04:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 01:04:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 01:04:37 --> Form Validation Class Initialized
INFO - 2018-04-02 01:04:37 --> Model Class Initialized
INFO - 2018-04-02 01:04:37 --> Controller Class Initialized
INFO - 2018-04-02 01:04:37 --> Model Class Initialized
INFO - 2018-04-02 01:04:37 --> Model Class Initialized
INFO - 2018-04-02 01:04:37 --> Model Class Initialized
INFO - 2018-04-02 01:04:37 --> Model Class Initialized
DEBUG - 2018-04-02 01:04:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-02 01:04:40 --> Config Class Initialized
INFO - 2018-04-02 01:04:40 --> Hooks Class Initialized
DEBUG - 2018-04-02 01:04:41 --> UTF-8 Support Enabled
INFO - 2018-04-02 01:04:41 --> Utf8 Class Initialized
INFO - 2018-04-02 01:04:41 --> URI Class Initialized
INFO - 2018-04-02 01:04:41 --> Router Class Initialized
INFO - 2018-04-02 01:04:41 --> Output Class Initialized
INFO - 2018-04-02 01:04:41 --> Security Class Initialized
DEBUG - 2018-04-02 01:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 01:04:41 --> Input Class Initialized
INFO - 2018-04-02 01:04:41 --> Language Class Initialized
INFO - 2018-04-02 01:04:41 --> Loader Class Initialized
INFO - 2018-04-02 01:04:41 --> Helper loaded: url_helper
INFO - 2018-04-02 01:04:41 --> Helper loaded: form_helper
INFO - 2018-04-02 01:04:41 --> Database Driver Class Initialized
DEBUG - 2018-04-02 01:04:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 01:04:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 01:04:41 --> Form Validation Class Initialized
INFO - 2018-04-02 01:04:41 --> Model Class Initialized
INFO - 2018-04-02 01:04:41 --> Controller Class Initialized
INFO - 2018-04-02 01:04:41 --> Model Class Initialized
INFO - 2018-04-02 01:04:41 --> Model Class Initialized
INFO - 2018-04-02 01:04:41 --> Model Class Initialized
INFO - 2018-04-02 01:04:41 --> Model Class Initialized
DEBUG - 2018-04-02 01:04:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-02 01:04:42 --> Config Class Initialized
INFO - 2018-04-02 01:04:42 --> Hooks Class Initialized
DEBUG - 2018-04-02 01:04:42 --> UTF-8 Support Enabled
INFO - 2018-04-02 01:04:42 --> Utf8 Class Initialized
INFO - 2018-04-02 01:04:42 --> URI Class Initialized
INFO - 2018-04-02 01:04:42 --> Router Class Initialized
INFO - 2018-04-02 01:04:42 --> Output Class Initialized
INFO - 2018-04-02 01:04:42 --> Security Class Initialized
DEBUG - 2018-04-02 01:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 01:04:42 --> Input Class Initialized
INFO - 2018-04-02 01:04:42 --> Language Class Initialized
INFO - 2018-04-02 01:04:42 --> Loader Class Initialized
INFO - 2018-04-02 01:04:42 --> Helper loaded: url_helper
INFO - 2018-04-02 01:04:42 --> Helper loaded: form_helper
INFO - 2018-04-02 01:04:42 --> Database Driver Class Initialized
DEBUG - 2018-04-02 01:04:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 01:04:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 01:04:42 --> Form Validation Class Initialized
INFO - 2018-04-02 01:04:42 --> Model Class Initialized
INFO - 2018-04-02 01:04:42 --> Controller Class Initialized
INFO - 2018-04-02 01:04:42 --> Model Class Initialized
INFO - 2018-04-02 01:04:42 --> Model Class Initialized
INFO - 2018-04-02 01:04:42 --> Model Class Initialized
INFO - 2018-04-02 01:04:42 --> Model Class Initialized
DEBUG - 2018-04-02 01:04:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-02 01:04:42 --> Final output sent to browser
DEBUG - 2018-04-02 01:04:42 --> Total execution time: 0.1286
INFO - 2018-04-02 01:06:22 --> Config Class Initialized
INFO - 2018-04-02 01:06:22 --> Hooks Class Initialized
INFO - 2018-04-02 01:06:22 --> Config Class Initialized
INFO - 2018-04-02 01:06:22 --> Config Class Initialized
INFO - 2018-04-02 01:06:22 --> Hooks Class Initialized
INFO - 2018-04-02 01:06:22 --> Config Class Initialized
INFO - 2018-04-02 01:06:22 --> Hooks Class Initialized
INFO - 2018-04-02 01:06:22 --> Config Class Initialized
INFO - 2018-04-02 01:06:22 --> Hooks Class Initialized
INFO - 2018-04-02 01:06:22 --> Config Class Initialized
INFO - 2018-04-02 01:06:22 --> Hooks Class Initialized
INFO - 2018-04-02 01:06:22 --> Hooks Class Initialized
DEBUG - 2018-04-02 01:06:22 --> UTF-8 Support Enabled
INFO - 2018-04-02 01:06:22 --> Utf8 Class Initialized
DEBUG - 2018-04-02 01:06:22 --> UTF-8 Support Enabled
INFO - 2018-04-02 01:06:22 --> Utf8 Class Initialized
DEBUG - 2018-04-02 01:06:22 --> UTF-8 Support Enabled
DEBUG - 2018-04-02 01:06:22 --> UTF-8 Support Enabled
INFO - 2018-04-02 01:06:22 --> Utf8 Class Initialized
DEBUG - 2018-04-02 01:06:22 --> UTF-8 Support Enabled
INFO - 2018-04-02 01:06:22 --> URI Class Initialized
INFO - 2018-04-02 01:06:22 --> Utf8 Class Initialized
INFO - 2018-04-02 01:06:22 --> Utf8 Class Initialized
DEBUG - 2018-04-02 01:06:22 --> UTF-8 Support Enabled
INFO - 2018-04-02 01:06:22 --> URI Class Initialized
INFO - 2018-04-02 01:06:22 --> Utf8 Class Initialized
INFO - 2018-04-02 01:06:22 --> URI Class Initialized
INFO - 2018-04-02 01:06:22 --> URI Class Initialized
INFO - 2018-04-02 01:06:22 --> URI Class Initialized
INFO - 2018-04-02 01:06:22 --> Router Class Initialized
INFO - 2018-04-02 01:06:22 --> URI Class Initialized
INFO - 2018-04-02 01:06:22 --> Router Class Initialized
INFO - 2018-04-02 01:06:22 --> Router Class Initialized
INFO - 2018-04-02 01:06:22 --> Router Class Initialized
INFO - 2018-04-02 01:06:22 --> Router Class Initialized
INFO - 2018-04-02 01:06:22 --> Output Class Initialized
INFO - 2018-04-02 01:06:22 --> Router Class Initialized
INFO - 2018-04-02 01:06:22 --> Output Class Initialized
INFO - 2018-04-02 01:06:22 --> Output Class Initialized
INFO - 2018-04-02 01:06:22 --> Output Class Initialized
INFO - 2018-04-02 01:06:22 --> Security Class Initialized
INFO - 2018-04-02 01:06:22 --> Output Class Initialized
INFO - 2018-04-02 01:06:22 --> Security Class Initialized
INFO - 2018-04-02 01:06:22 --> Output Class Initialized
INFO - 2018-04-02 01:06:22 --> Security Class Initialized
INFO - 2018-04-02 01:06:22 --> Security Class Initialized
INFO - 2018-04-02 01:06:22 --> Security Class Initialized
DEBUG - 2018-04-02 01:06:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-02 01:06:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 01:06:22 --> Input Class Initialized
DEBUG - 2018-04-02 01:06:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 01:06:22 --> Security Class Initialized
INFO - 2018-04-02 01:06:22 --> Input Class Initialized
INFO - 2018-04-02 01:06:22 --> Input Class Initialized
DEBUG - 2018-04-02 01:06:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 01:06:22 --> Language Class Initialized
INFO - 2018-04-02 01:06:22 --> Input Class Initialized
DEBUG - 2018-04-02 01:06:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 01:06:22 --> Language Class Initialized
INFO - 2018-04-02 01:06:22 --> Input Class Initialized
INFO - 2018-04-02 01:06:22 --> Language Class Initialized
DEBUG - 2018-04-02 01:06:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 01:06:22 --> Language Class Initialized
INFO - 2018-04-02 01:06:22 --> Input Class Initialized
INFO - 2018-04-02 01:06:22 --> Language Class Initialized
ERROR - 2018-04-02 01:06:22 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-04-02 01:06:22 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-04-02 01:06:22 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-04-02 01:06:22 --> Language Class Initialized
ERROR - 2018-04-02 01:06:22 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-04-02 01:06:22 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-04-02 01:06:22 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-04-02 01:06:22 --> Config Class Initialized
INFO - 2018-04-02 01:06:22 --> Hooks Class Initialized
DEBUG - 2018-04-02 01:06:22 --> UTF-8 Support Enabled
INFO - 2018-04-02 01:06:22 --> Utf8 Class Initialized
INFO - 2018-04-02 01:06:22 --> URI Class Initialized
INFO - 2018-04-02 01:06:22 --> Router Class Initialized
INFO - 2018-04-02 01:06:22 --> Output Class Initialized
INFO - 2018-04-02 01:06:22 --> Security Class Initialized
DEBUG - 2018-04-02 01:06:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 01:06:22 --> Input Class Initialized
INFO - 2018-04-02 01:06:22 --> Language Class Initialized
ERROR - 2018-04-02 01:06:22 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-04-02 01:06:25 --> Config Class Initialized
INFO - 2018-04-02 01:06:25 --> Hooks Class Initialized
DEBUG - 2018-04-02 01:06:25 --> UTF-8 Support Enabled
INFO - 2018-04-02 01:06:25 --> Utf8 Class Initialized
INFO - 2018-04-02 01:06:25 --> URI Class Initialized
INFO - 2018-04-02 01:06:25 --> Router Class Initialized
INFO - 2018-04-02 01:06:25 --> Output Class Initialized
INFO - 2018-04-02 01:06:25 --> Security Class Initialized
DEBUG - 2018-04-02 01:06:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 01:06:25 --> Input Class Initialized
INFO - 2018-04-02 01:06:25 --> Language Class Initialized
INFO - 2018-04-02 01:06:25 --> Loader Class Initialized
INFO - 2018-04-02 01:06:25 --> Helper loaded: url_helper
INFO - 2018-04-02 01:06:25 --> Helper loaded: form_helper
INFO - 2018-04-02 01:06:25 --> Database Driver Class Initialized
DEBUG - 2018-04-02 01:06:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 01:06:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 01:06:25 --> Form Validation Class Initialized
INFO - 2018-04-02 01:06:25 --> Model Class Initialized
INFO - 2018-04-02 01:06:25 --> Controller Class Initialized
INFO - 2018-04-02 01:06:25 --> Model Class Initialized
INFO - 2018-04-02 01:06:25 --> Model Class Initialized
INFO - 2018-04-02 01:06:25 --> Model Class Initialized
INFO - 2018-04-02 01:06:25 --> Model Class Initialized
DEBUG - 2018-04-02 01:06:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-02 01:06:27 --> Config Class Initialized
INFO - 2018-04-02 01:06:27 --> Hooks Class Initialized
DEBUG - 2018-04-02 01:06:27 --> UTF-8 Support Enabled
INFO - 2018-04-02 01:06:27 --> Utf8 Class Initialized
INFO - 2018-04-02 01:06:27 --> URI Class Initialized
INFO - 2018-04-02 01:06:27 --> Router Class Initialized
INFO - 2018-04-02 01:06:27 --> Output Class Initialized
INFO - 2018-04-02 01:06:27 --> Security Class Initialized
DEBUG - 2018-04-02 01:06:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 01:06:27 --> Input Class Initialized
INFO - 2018-04-02 01:06:27 --> Language Class Initialized
INFO - 2018-04-02 01:06:27 --> Loader Class Initialized
INFO - 2018-04-02 01:06:27 --> Helper loaded: url_helper
INFO - 2018-04-02 01:06:27 --> Helper loaded: form_helper
INFO - 2018-04-02 01:06:27 --> Database Driver Class Initialized
DEBUG - 2018-04-02 01:06:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 01:06:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 01:06:27 --> Form Validation Class Initialized
INFO - 2018-04-02 01:06:27 --> Model Class Initialized
INFO - 2018-04-02 01:06:27 --> Controller Class Initialized
INFO - 2018-04-02 01:06:27 --> Model Class Initialized
INFO - 2018-04-02 01:06:27 --> Model Class Initialized
INFO - 2018-04-02 01:06:27 --> Model Class Initialized
INFO - 2018-04-02 01:06:27 --> Model Class Initialized
DEBUG - 2018-04-02 01:06:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-02 01:06:53 --> Config Class Initialized
INFO - 2018-04-02 01:06:53 --> Hooks Class Initialized
DEBUG - 2018-04-02 01:06:53 --> UTF-8 Support Enabled
INFO - 2018-04-02 01:06:53 --> Utf8 Class Initialized
INFO - 2018-04-02 01:06:53 --> URI Class Initialized
INFO - 2018-04-02 01:06:53 --> Router Class Initialized
INFO - 2018-04-02 01:06:53 --> Output Class Initialized
INFO - 2018-04-02 01:06:53 --> Security Class Initialized
DEBUG - 2018-04-02 01:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 01:06:53 --> Input Class Initialized
INFO - 2018-04-02 01:06:53 --> Language Class Initialized
INFO - 2018-04-02 01:06:53 --> Loader Class Initialized
INFO - 2018-04-02 01:06:53 --> Helper loaded: url_helper
INFO - 2018-04-02 01:06:53 --> Helper loaded: form_helper
INFO - 2018-04-02 01:06:53 --> Database Driver Class Initialized
DEBUG - 2018-04-02 01:06:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 01:06:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 01:06:53 --> Form Validation Class Initialized
INFO - 2018-04-02 01:06:53 --> Model Class Initialized
INFO - 2018-04-02 01:06:53 --> Controller Class Initialized
INFO - 2018-04-02 01:06:53 --> Model Class Initialized
INFO - 2018-04-02 01:06:53 --> Model Class Initialized
INFO - 2018-04-02 01:06:53 --> Model Class Initialized
INFO - 2018-04-02 01:06:53 --> Model Class Initialized
DEBUG - 2018-04-02 01:06:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-02 01:07:18 --> Config Class Initialized
INFO - 2018-04-02 01:07:18 --> Hooks Class Initialized
DEBUG - 2018-04-02 01:07:18 --> UTF-8 Support Enabled
INFO - 2018-04-02 01:07:18 --> Utf8 Class Initialized
INFO - 2018-04-02 01:07:18 --> URI Class Initialized
INFO - 2018-04-02 01:07:18 --> Router Class Initialized
INFO - 2018-04-02 01:07:18 --> Output Class Initialized
INFO - 2018-04-02 01:07:18 --> Security Class Initialized
DEBUG - 2018-04-02 01:07:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 01:07:18 --> Input Class Initialized
INFO - 2018-04-02 01:07:18 --> Language Class Initialized
INFO - 2018-04-02 01:07:18 --> Loader Class Initialized
INFO - 2018-04-02 01:07:18 --> Helper loaded: url_helper
INFO - 2018-04-02 01:07:18 --> Helper loaded: form_helper
INFO - 2018-04-02 01:07:18 --> Database Driver Class Initialized
DEBUG - 2018-04-02 01:07:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 01:07:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 01:07:18 --> Form Validation Class Initialized
INFO - 2018-04-02 01:07:18 --> Model Class Initialized
INFO - 2018-04-02 01:07:18 --> Controller Class Initialized
INFO - 2018-04-02 01:07:18 --> Model Class Initialized
INFO - 2018-04-02 01:07:18 --> Model Class Initialized
INFO - 2018-04-02 01:07:18 --> Model Class Initialized
INFO - 2018-04-02 01:07:18 --> Model Class Initialized
DEBUG - 2018-04-02 01:07:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-02 01:07:21 --> Config Class Initialized
INFO - 2018-04-02 01:07:21 --> Hooks Class Initialized
DEBUG - 2018-04-02 01:07:21 --> UTF-8 Support Enabled
INFO - 2018-04-02 01:07:21 --> Utf8 Class Initialized
INFO - 2018-04-02 01:07:21 --> URI Class Initialized
INFO - 2018-04-02 01:07:21 --> Router Class Initialized
INFO - 2018-04-02 01:07:21 --> Output Class Initialized
INFO - 2018-04-02 01:07:21 --> Security Class Initialized
DEBUG - 2018-04-02 01:07:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 01:07:21 --> Input Class Initialized
INFO - 2018-04-02 01:07:21 --> Language Class Initialized
INFO - 2018-04-02 01:07:21 --> Loader Class Initialized
INFO - 2018-04-02 01:07:21 --> Helper loaded: url_helper
INFO - 2018-04-02 01:07:21 --> Helper loaded: form_helper
INFO - 2018-04-02 01:07:21 --> Database Driver Class Initialized
DEBUG - 2018-04-02 01:07:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 01:07:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 01:07:21 --> Form Validation Class Initialized
INFO - 2018-04-02 01:07:21 --> Model Class Initialized
INFO - 2018-04-02 01:07:21 --> Controller Class Initialized
INFO - 2018-04-02 01:07:21 --> Model Class Initialized
INFO - 2018-04-02 01:07:21 --> Model Class Initialized
INFO - 2018-04-02 01:07:21 --> Model Class Initialized
INFO - 2018-04-02 01:07:21 --> Model Class Initialized
DEBUG - 2018-04-02 01:07:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-02 01:07:23 --> Config Class Initialized
INFO - 2018-04-02 01:07:23 --> Hooks Class Initialized
DEBUG - 2018-04-02 01:07:23 --> UTF-8 Support Enabled
INFO - 2018-04-02 01:07:23 --> Utf8 Class Initialized
INFO - 2018-04-02 01:07:23 --> URI Class Initialized
INFO - 2018-04-02 01:07:23 --> Router Class Initialized
INFO - 2018-04-02 01:07:23 --> Output Class Initialized
INFO - 2018-04-02 01:07:23 --> Security Class Initialized
DEBUG - 2018-04-02 01:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 01:07:23 --> Input Class Initialized
INFO - 2018-04-02 01:07:23 --> Language Class Initialized
INFO - 2018-04-02 01:07:23 --> Loader Class Initialized
INFO - 2018-04-02 01:07:23 --> Helper loaded: url_helper
INFO - 2018-04-02 01:07:23 --> Helper loaded: form_helper
INFO - 2018-04-02 01:07:23 --> Database Driver Class Initialized
DEBUG - 2018-04-02 01:07:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 01:07:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 01:07:23 --> Form Validation Class Initialized
INFO - 2018-04-02 01:07:23 --> Model Class Initialized
INFO - 2018-04-02 01:07:23 --> Controller Class Initialized
INFO - 2018-04-02 01:07:23 --> Model Class Initialized
INFO - 2018-04-02 01:07:23 --> Model Class Initialized
INFO - 2018-04-02 01:07:23 --> Model Class Initialized
INFO - 2018-04-02 01:07:23 --> Model Class Initialized
DEBUG - 2018-04-02 01:07:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-02 01:07:31 --> Config Class Initialized
INFO - 2018-04-02 01:07:31 --> Hooks Class Initialized
DEBUG - 2018-04-02 01:07:31 --> UTF-8 Support Enabled
INFO - 2018-04-02 01:07:31 --> Utf8 Class Initialized
INFO - 2018-04-02 01:07:31 --> URI Class Initialized
INFO - 2018-04-02 01:07:31 --> Router Class Initialized
INFO - 2018-04-02 01:07:31 --> Output Class Initialized
INFO - 2018-04-02 01:07:31 --> Security Class Initialized
DEBUG - 2018-04-02 01:07:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 01:07:31 --> Input Class Initialized
INFO - 2018-04-02 01:07:31 --> Language Class Initialized
INFO - 2018-04-02 01:07:31 --> Loader Class Initialized
INFO - 2018-04-02 01:07:31 --> Helper loaded: url_helper
INFO - 2018-04-02 01:07:31 --> Helper loaded: form_helper
INFO - 2018-04-02 01:07:31 --> Database Driver Class Initialized
DEBUG - 2018-04-02 01:07:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 01:07:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 01:07:31 --> Form Validation Class Initialized
INFO - 2018-04-02 01:07:31 --> Model Class Initialized
INFO - 2018-04-02 01:07:31 --> Controller Class Initialized
INFO - 2018-04-02 01:07:31 --> Model Class Initialized
INFO - 2018-04-02 01:07:31 --> Model Class Initialized
INFO - 2018-04-02 01:07:31 --> Model Class Initialized
INFO - 2018-04-02 01:07:31 --> Model Class Initialized
DEBUG - 2018-04-02 01:07:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-02 01:07:35 --> Config Class Initialized
INFO - 2018-04-02 01:07:35 --> Hooks Class Initialized
DEBUG - 2018-04-02 01:07:35 --> UTF-8 Support Enabled
INFO - 2018-04-02 01:07:35 --> Utf8 Class Initialized
INFO - 2018-04-02 01:07:35 --> URI Class Initialized
INFO - 2018-04-02 01:07:35 --> Router Class Initialized
INFO - 2018-04-02 01:07:35 --> Output Class Initialized
INFO - 2018-04-02 01:07:35 --> Security Class Initialized
DEBUG - 2018-04-02 01:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 01:07:35 --> Input Class Initialized
INFO - 2018-04-02 01:07:35 --> Language Class Initialized
INFO - 2018-04-02 01:07:35 --> Loader Class Initialized
INFO - 2018-04-02 01:07:35 --> Helper loaded: url_helper
INFO - 2018-04-02 01:07:35 --> Helper loaded: form_helper
INFO - 2018-04-02 01:07:35 --> Database Driver Class Initialized
DEBUG - 2018-04-02 01:07:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 01:07:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 01:07:35 --> Form Validation Class Initialized
INFO - 2018-04-02 01:07:35 --> Model Class Initialized
INFO - 2018-04-02 01:07:35 --> Controller Class Initialized
INFO - 2018-04-02 01:07:35 --> Model Class Initialized
INFO - 2018-04-02 01:07:35 --> Model Class Initialized
INFO - 2018-04-02 01:07:35 --> Model Class Initialized
INFO - 2018-04-02 01:07:35 --> Model Class Initialized
DEBUG - 2018-04-02 01:07:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-02 01:07:35 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-02 01:07:35 --> Final output sent to browser
DEBUG - 2018-04-02 01:07:35 --> Total execution time: 0.0685
INFO - 2018-04-02 01:07:35 --> Config Class Initialized
INFO - 2018-04-02 01:07:35 --> Hooks Class Initialized
INFO - 2018-04-02 01:07:35 --> Config Class Initialized
INFO - 2018-04-02 01:07:35 --> Hooks Class Initialized
INFO - 2018-04-02 01:07:35 --> Config Class Initialized
INFO - 2018-04-02 01:07:35 --> Hooks Class Initialized
INFO - 2018-04-02 01:07:35 --> Config Class Initialized
INFO - 2018-04-02 01:07:35 --> Hooks Class Initialized
DEBUG - 2018-04-02 01:07:35 --> UTF-8 Support Enabled
DEBUG - 2018-04-02 01:07:35 --> UTF-8 Support Enabled
DEBUG - 2018-04-02 01:07:35 --> UTF-8 Support Enabled
INFO - 2018-04-02 01:07:35 --> Utf8 Class Initialized
INFO - 2018-04-02 01:07:35 --> Utf8 Class Initialized
INFO - 2018-04-02 01:07:35 --> Utf8 Class Initialized
INFO - 2018-04-02 01:07:35 --> URI Class Initialized
INFO - 2018-04-02 01:07:35 --> URI Class Initialized
INFO - 2018-04-02 01:07:35 --> URI Class Initialized
DEBUG - 2018-04-02 01:07:35 --> UTF-8 Support Enabled
INFO - 2018-04-02 01:07:35 --> Utf8 Class Initialized
INFO - 2018-04-02 01:07:35 --> Router Class Initialized
INFO - 2018-04-02 01:07:35 --> Router Class Initialized
INFO - 2018-04-02 01:07:35 --> Router Class Initialized
INFO - 2018-04-02 01:07:35 --> URI Class Initialized
INFO - 2018-04-02 01:07:35 --> Output Class Initialized
INFO - 2018-04-02 01:07:35 --> Output Class Initialized
INFO - 2018-04-02 01:07:35 --> Output Class Initialized
INFO - 2018-04-02 01:07:35 --> Router Class Initialized
INFO - 2018-04-02 01:07:35 --> Security Class Initialized
INFO - 2018-04-02 01:07:35 --> Security Class Initialized
INFO - 2018-04-02 01:07:35 --> Security Class Initialized
DEBUG - 2018-04-02 01:07:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-02 01:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 01:07:35 --> Input Class Initialized
INFO - 2018-04-02 01:07:35 --> Input Class Initialized
INFO - 2018-04-02 01:07:35 --> Output Class Initialized
DEBUG - 2018-04-02 01:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 01:07:35 --> Input Class Initialized
INFO - 2018-04-02 01:07:35 --> Language Class Initialized
INFO - 2018-04-02 01:07:35 --> Language Class Initialized
INFO - 2018-04-02 01:07:35 --> Language Class Initialized
INFO - 2018-04-02 01:07:35 --> Security Class Initialized
ERROR - 2018-04-02 01:07:35 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-04-02 01:07:35 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-04-02 01:07:35 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-04-02 01:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 01:07:35 --> Input Class Initialized
INFO - 2018-04-02 01:07:35 --> Language Class Initialized
ERROR - 2018-04-02 01:07:35 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-04-02 01:07:35 --> Config Class Initialized
INFO - 2018-04-02 01:07:35 --> Hooks Class Initialized
INFO - 2018-04-02 01:07:35 --> Config Class Initialized
INFO - 2018-04-02 01:07:35 --> Config Class Initialized
INFO - 2018-04-02 01:07:35 --> Hooks Class Initialized
INFO - 2018-04-02 01:07:35 --> Hooks Class Initialized
DEBUG - 2018-04-02 01:07:35 --> UTF-8 Support Enabled
INFO - 2018-04-02 01:07:35 --> Utf8 Class Initialized
INFO - 2018-04-02 01:07:35 --> URI Class Initialized
DEBUG - 2018-04-02 01:07:35 --> UTF-8 Support Enabled
INFO - 2018-04-02 01:07:35 --> Utf8 Class Initialized
DEBUG - 2018-04-02 01:07:35 --> UTF-8 Support Enabled
INFO - 2018-04-02 01:07:35 --> Utf8 Class Initialized
INFO - 2018-04-02 01:07:35 --> Router Class Initialized
INFO - 2018-04-02 01:07:35 --> URI Class Initialized
INFO - 2018-04-02 01:07:35 --> URI Class Initialized
INFO - 2018-04-02 01:07:35 --> Output Class Initialized
INFO - 2018-04-02 01:07:35 --> Router Class Initialized
INFO - 2018-04-02 01:07:35 --> Router Class Initialized
INFO - 2018-04-02 01:07:35 --> Security Class Initialized
INFO - 2018-04-02 01:07:35 --> Output Class Initialized
DEBUG - 2018-04-02 01:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 01:07:35 --> Input Class Initialized
INFO - 2018-04-02 01:07:35 --> Output Class Initialized
INFO - 2018-04-02 01:07:35 --> Security Class Initialized
INFO - 2018-04-02 01:07:35 --> Language Class Initialized
INFO - 2018-04-02 01:07:35 --> Security Class Initialized
DEBUG - 2018-04-02 01:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 01:07:35 --> Input Class Initialized
ERROR - 2018-04-02 01:07:35 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-04-02 01:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 01:07:35 --> Language Class Initialized
INFO - 2018-04-02 01:07:35 --> Input Class Initialized
INFO - 2018-04-02 01:07:35 --> Language Class Initialized
ERROR - 2018-04-02 01:07:35 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-04-02 01:07:35 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-04-02 01:07:35 --> Config Class Initialized
INFO - 2018-04-02 01:07:35 --> Hooks Class Initialized
DEBUG - 2018-04-02 01:07:35 --> UTF-8 Support Enabled
INFO - 2018-04-02 01:07:35 --> Utf8 Class Initialized
INFO - 2018-04-02 01:07:35 --> URI Class Initialized
INFO - 2018-04-02 01:07:35 --> Router Class Initialized
INFO - 2018-04-02 01:07:35 --> Output Class Initialized
INFO - 2018-04-02 01:07:35 --> Security Class Initialized
DEBUG - 2018-04-02 01:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 01:07:35 --> Input Class Initialized
INFO - 2018-04-02 01:07:35 --> Language Class Initialized
INFO - 2018-04-02 01:07:35 --> Loader Class Initialized
INFO - 2018-04-02 01:07:35 --> Helper loaded: url_helper
INFO - 2018-04-02 01:07:35 --> Helper loaded: form_helper
INFO - 2018-04-02 01:07:35 --> Database Driver Class Initialized
DEBUG - 2018-04-02 01:07:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 01:07:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 01:07:35 --> Form Validation Class Initialized
INFO - 2018-04-02 01:07:35 --> Model Class Initialized
INFO - 2018-04-02 01:07:35 --> Controller Class Initialized
INFO - 2018-04-02 01:07:35 --> Model Class Initialized
INFO - 2018-04-02 01:07:35 --> Model Class Initialized
INFO - 2018-04-02 01:07:35 --> Model Class Initialized
INFO - 2018-04-02 01:07:35 --> Model Class Initialized
DEBUG - 2018-04-02 01:07:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-02 01:07:40 --> Config Class Initialized
INFO - 2018-04-02 01:07:40 --> Hooks Class Initialized
DEBUG - 2018-04-02 01:07:40 --> UTF-8 Support Enabled
INFO - 2018-04-02 01:07:40 --> Utf8 Class Initialized
INFO - 2018-04-02 01:07:40 --> URI Class Initialized
INFO - 2018-04-02 01:07:40 --> Router Class Initialized
INFO - 2018-04-02 01:07:40 --> Output Class Initialized
INFO - 2018-04-02 01:07:40 --> Security Class Initialized
DEBUG - 2018-04-02 01:07:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 01:07:40 --> Input Class Initialized
INFO - 2018-04-02 01:07:40 --> Language Class Initialized
INFO - 2018-04-02 01:07:40 --> Loader Class Initialized
INFO - 2018-04-02 01:07:40 --> Helper loaded: url_helper
INFO - 2018-04-02 01:07:40 --> Helper loaded: form_helper
INFO - 2018-04-02 01:07:40 --> Database Driver Class Initialized
DEBUG - 2018-04-02 01:07:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 01:07:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 01:07:40 --> Form Validation Class Initialized
INFO - 2018-04-02 01:07:40 --> Model Class Initialized
INFO - 2018-04-02 01:07:40 --> Controller Class Initialized
INFO - 2018-04-02 01:07:40 --> Model Class Initialized
INFO - 2018-04-02 01:07:40 --> Model Class Initialized
INFO - 2018-04-02 01:07:40 --> Model Class Initialized
INFO - 2018-04-02 01:07:40 --> Model Class Initialized
DEBUG - 2018-04-02 01:07:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-02 01:08:19 --> Config Class Initialized
INFO - 2018-04-02 01:08:19 --> Hooks Class Initialized
DEBUG - 2018-04-02 01:08:19 --> UTF-8 Support Enabled
INFO - 2018-04-02 01:08:19 --> Utf8 Class Initialized
INFO - 2018-04-02 01:08:19 --> URI Class Initialized
INFO - 2018-04-02 01:08:19 --> Router Class Initialized
INFO - 2018-04-02 01:08:19 --> Output Class Initialized
INFO - 2018-04-02 01:08:19 --> Security Class Initialized
DEBUG - 2018-04-02 01:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 01:08:19 --> Input Class Initialized
INFO - 2018-04-02 01:08:19 --> Language Class Initialized
INFO - 2018-04-02 01:08:19 --> Loader Class Initialized
INFO - 2018-04-02 01:08:19 --> Helper loaded: url_helper
INFO - 2018-04-02 01:08:19 --> Helper loaded: form_helper
INFO - 2018-04-02 01:08:19 --> Database Driver Class Initialized
DEBUG - 2018-04-02 01:08:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 01:08:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 01:08:19 --> Form Validation Class Initialized
INFO - 2018-04-02 01:08:19 --> Model Class Initialized
INFO - 2018-04-02 01:08:19 --> Controller Class Initialized
INFO - 2018-04-02 01:08:19 --> Model Class Initialized
INFO - 2018-04-02 01:08:19 --> Model Class Initialized
INFO - 2018-04-02 01:08:19 --> Model Class Initialized
INFO - 2018-04-02 01:08:19 --> Model Class Initialized
DEBUG - 2018-04-02 01:08:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-02 01:08:58 --> Config Class Initialized
INFO - 2018-04-02 01:08:58 --> Hooks Class Initialized
DEBUG - 2018-04-02 01:08:58 --> UTF-8 Support Enabled
INFO - 2018-04-02 01:08:58 --> Utf8 Class Initialized
INFO - 2018-04-02 01:08:58 --> URI Class Initialized
INFO - 2018-04-02 01:08:58 --> Router Class Initialized
INFO - 2018-04-02 01:08:58 --> Output Class Initialized
INFO - 2018-04-02 01:08:58 --> Security Class Initialized
DEBUG - 2018-04-02 01:08:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 01:08:58 --> Input Class Initialized
INFO - 2018-04-02 01:08:58 --> Language Class Initialized
INFO - 2018-04-02 01:08:58 --> Loader Class Initialized
INFO - 2018-04-02 01:08:58 --> Helper loaded: url_helper
INFO - 2018-04-02 01:08:58 --> Helper loaded: form_helper
INFO - 2018-04-02 01:08:58 --> Database Driver Class Initialized
DEBUG - 2018-04-02 01:08:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 01:08:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 01:08:58 --> Form Validation Class Initialized
INFO - 2018-04-02 01:08:58 --> Model Class Initialized
INFO - 2018-04-02 01:08:58 --> Controller Class Initialized
INFO - 2018-04-02 01:08:58 --> Model Class Initialized
INFO - 2018-04-02 01:08:58 --> Model Class Initialized
INFO - 2018-04-02 01:08:58 --> Model Class Initialized
INFO - 2018-04-02 01:08:58 --> Model Class Initialized
DEBUG - 2018-04-02 01:08:58 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-04-02 01:08:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 1548
ERROR - 2018-04-02 01:08:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 1548
INFO - 2018-04-02 01:08:58 --> Final output sent to browser
DEBUG - 2018-04-02 01:08:58 --> Total execution time: 0.1376
INFO - 2018-04-02 01:09:10 --> Config Class Initialized
INFO - 2018-04-02 01:09:10 --> Hooks Class Initialized
DEBUG - 2018-04-02 01:09:11 --> UTF-8 Support Enabled
INFO - 2018-04-02 01:09:11 --> Utf8 Class Initialized
INFO - 2018-04-02 01:09:11 --> URI Class Initialized
INFO - 2018-04-02 01:09:11 --> Router Class Initialized
INFO - 2018-04-02 01:09:11 --> Output Class Initialized
INFO - 2018-04-02 01:09:11 --> Security Class Initialized
DEBUG - 2018-04-02 01:09:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 01:09:11 --> Input Class Initialized
INFO - 2018-04-02 01:09:11 --> Language Class Initialized
INFO - 2018-04-02 01:09:11 --> Loader Class Initialized
INFO - 2018-04-02 01:09:11 --> Helper loaded: url_helper
INFO - 2018-04-02 01:09:11 --> Helper loaded: form_helper
INFO - 2018-04-02 01:09:11 --> Database Driver Class Initialized
DEBUG - 2018-04-02 01:09:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 01:09:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 01:09:11 --> Form Validation Class Initialized
INFO - 2018-04-02 01:09:11 --> Model Class Initialized
INFO - 2018-04-02 01:09:11 --> Controller Class Initialized
INFO - 2018-04-02 01:09:11 --> Model Class Initialized
INFO - 2018-04-02 01:09:11 --> Model Class Initialized
INFO - 2018-04-02 01:09:11 --> Model Class Initialized
INFO - 2018-04-02 01:09:11 --> Model Class Initialized
DEBUG - 2018-04-02 01:09:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-02 01:09:11 --> Final output sent to browser
DEBUG - 2018-04-02 01:09:11 --> Total execution time: 0.1375
INFO - 2018-04-02 01:09:38 --> Config Class Initialized
INFO - 2018-04-02 01:09:38 --> Hooks Class Initialized
DEBUG - 2018-04-02 01:09:38 --> UTF-8 Support Enabled
INFO - 2018-04-02 01:09:38 --> Utf8 Class Initialized
INFO - 2018-04-02 01:09:38 --> URI Class Initialized
INFO - 2018-04-02 01:09:38 --> Router Class Initialized
INFO - 2018-04-02 01:09:38 --> Output Class Initialized
INFO - 2018-04-02 01:09:38 --> Security Class Initialized
DEBUG - 2018-04-02 01:09:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 01:09:38 --> Input Class Initialized
INFO - 2018-04-02 01:09:38 --> Language Class Initialized
INFO - 2018-04-02 01:09:38 --> Loader Class Initialized
INFO - 2018-04-02 01:09:38 --> Helper loaded: url_helper
INFO - 2018-04-02 01:09:38 --> Helper loaded: form_helper
INFO - 2018-04-02 01:09:38 --> Database Driver Class Initialized
DEBUG - 2018-04-02 01:09:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 01:09:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 01:09:38 --> Form Validation Class Initialized
INFO - 2018-04-02 01:09:38 --> Model Class Initialized
INFO - 2018-04-02 01:09:38 --> Controller Class Initialized
INFO - 2018-04-02 01:09:38 --> Model Class Initialized
INFO - 2018-04-02 01:09:38 --> Model Class Initialized
INFO - 2018-04-02 01:09:38 --> Model Class Initialized
INFO - 2018-04-02 01:09:38 --> Model Class Initialized
DEBUG - 2018-04-02 01:09:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-02 01:09:38 --> Final output sent to browser
DEBUG - 2018-04-02 01:09:38 --> Total execution time: 0.1498
INFO - 2018-04-02 01:11:29 --> Config Class Initialized
INFO - 2018-04-02 01:11:29 --> Hooks Class Initialized
DEBUG - 2018-04-02 01:11:29 --> UTF-8 Support Enabled
INFO - 2018-04-02 01:11:29 --> Utf8 Class Initialized
INFO - 2018-04-02 01:11:29 --> URI Class Initialized
INFO - 2018-04-02 01:11:29 --> Router Class Initialized
INFO - 2018-04-02 01:11:29 --> Output Class Initialized
INFO - 2018-04-02 01:11:29 --> Security Class Initialized
DEBUG - 2018-04-02 01:11:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 01:11:29 --> Input Class Initialized
INFO - 2018-04-02 01:11:29 --> Language Class Initialized
INFO - 2018-04-02 01:11:29 --> Loader Class Initialized
INFO - 2018-04-02 01:11:29 --> Helper loaded: url_helper
INFO - 2018-04-02 01:11:29 --> Helper loaded: form_helper
INFO - 2018-04-02 01:11:29 --> Database Driver Class Initialized
DEBUG - 2018-04-02 01:11:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 01:11:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 01:11:29 --> Form Validation Class Initialized
INFO - 2018-04-02 01:11:29 --> Model Class Initialized
INFO - 2018-04-02 01:11:29 --> Controller Class Initialized
INFO - 2018-04-02 01:11:29 --> Model Class Initialized
INFO - 2018-04-02 01:11:29 --> Model Class Initialized
INFO - 2018-04-02 01:11:29 --> Model Class Initialized
INFO - 2018-04-02 01:11:29 --> Model Class Initialized
DEBUG - 2018-04-02 01:11:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-02 01:11:29 --> Final output sent to browser
DEBUG - 2018-04-02 01:11:29 --> Total execution time: 0.1341
INFO - 2018-04-02 01:11:37 --> Config Class Initialized
INFO - 2018-04-02 01:11:37 --> Hooks Class Initialized
DEBUG - 2018-04-02 01:11:37 --> UTF-8 Support Enabled
INFO - 2018-04-02 01:11:37 --> Utf8 Class Initialized
INFO - 2018-04-02 01:11:37 --> URI Class Initialized
INFO - 2018-04-02 01:11:37 --> Router Class Initialized
INFO - 2018-04-02 01:11:37 --> Output Class Initialized
INFO - 2018-04-02 01:11:37 --> Security Class Initialized
DEBUG - 2018-04-02 01:11:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 01:11:37 --> Input Class Initialized
INFO - 2018-04-02 01:11:37 --> Language Class Initialized
INFO - 2018-04-02 01:11:37 --> Loader Class Initialized
INFO - 2018-04-02 01:11:37 --> Helper loaded: url_helper
INFO - 2018-04-02 01:11:37 --> Helper loaded: form_helper
INFO - 2018-04-02 01:11:37 --> Database Driver Class Initialized
DEBUG - 2018-04-02 01:11:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 01:11:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 01:11:37 --> Form Validation Class Initialized
INFO - 2018-04-02 01:11:37 --> Model Class Initialized
INFO - 2018-04-02 01:11:37 --> Controller Class Initialized
INFO - 2018-04-02 01:11:37 --> Model Class Initialized
INFO - 2018-04-02 01:11:37 --> Model Class Initialized
INFO - 2018-04-02 01:11:37 --> Model Class Initialized
INFO - 2018-04-02 01:11:37 --> Model Class Initialized
DEBUG - 2018-04-02 01:11:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-02 01:11:37 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-02 01:11:37 --> Final output sent to browser
DEBUG - 2018-04-02 01:11:37 --> Total execution time: 0.0567
INFO - 2018-04-02 01:11:37 --> Config Class Initialized
INFO - 2018-04-02 01:11:37 --> Hooks Class Initialized
INFO - 2018-04-02 01:11:37 --> Config Class Initialized
INFO - 2018-04-02 01:11:37 --> Hooks Class Initialized
INFO - 2018-04-02 01:11:37 --> Config Class Initialized
INFO - 2018-04-02 01:11:37 --> Hooks Class Initialized
DEBUG - 2018-04-02 01:11:37 --> UTF-8 Support Enabled
INFO - 2018-04-02 01:11:37 --> Utf8 Class Initialized
DEBUG - 2018-04-02 01:11:37 --> UTF-8 Support Enabled
INFO - 2018-04-02 01:11:37 --> Utf8 Class Initialized
DEBUG - 2018-04-02 01:11:37 --> UTF-8 Support Enabled
INFO - 2018-04-02 01:11:37 --> URI Class Initialized
INFO - 2018-04-02 01:11:37 --> Config Class Initialized
INFO - 2018-04-02 01:11:37 --> Utf8 Class Initialized
INFO - 2018-04-02 01:11:37 --> Hooks Class Initialized
INFO - 2018-04-02 01:11:37 --> URI Class Initialized
INFO - 2018-04-02 01:11:37 --> URI Class Initialized
INFO - 2018-04-02 01:11:37 --> Router Class Initialized
INFO - 2018-04-02 01:11:37 --> Router Class Initialized
DEBUG - 2018-04-02 01:11:37 --> UTF-8 Support Enabled
INFO - 2018-04-02 01:11:37 --> Router Class Initialized
INFO - 2018-04-02 01:11:37 --> Utf8 Class Initialized
INFO - 2018-04-02 01:11:37 --> Output Class Initialized
INFO - 2018-04-02 01:11:37 --> Output Class Initialized
INFO - 2018-04-02 01:11:37 --> URI Class Initialized
INFO - 2018-04-02 01:11:37 --> Security Class Initialized
INFO - 2018-04-02 01:11:37 --> Output Class Initialized
INFO - 2018-04-02 01:11:37 --> Security Class Initialized
INFO - 2018-04-02 01:11:37 --> Router Class Initialized
DEBUG - 2018-04-02 01:11:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 01:11:37 --> Security Class Initialized
INFO - 2018-04-02 01:11:37 --> Input Class Initialized
DEBUG - 2018-04-02 01:11:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 01:11:37 --> Input Class Initialized
INFO - 2018-04-02 01:11:37 --> Language Class Initialized
DEBUG - 2018-04-02 01:11:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 01:11:37 --> Input Class Initialized
INFO - 2018-04-02 01:11:37 --> Output Class Initialized
INFO - 2018-04-02 01:11:37 --> Language Class Initialized
INFO - 2018-04-02 01:11:37 --> Language Class Initialized
ERROR - 2018-04-02 01:11:37 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-04-02 01:11:37 --> Security Class Initialized
ERROR - 2018-04-02 01:11:37 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-04-02 01:11:37 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-04-02 01:11:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 01:11:37 --> Input Class Initialized
INFO - 2018-04-02 01:11:37 --> Language Class Initialized
ERROR - 2018-04-02 01:11:37 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-04-02 01:11:37 --> Config Class Initialized
INFO - 2018-04-02 01:11:37 --> Config Class Initialized
INFO - 2018-04-02 01:11:37 --> Hooks Class Initialized
INFO - 2018-04-02 01:11:37 --> Hooks Class Initialized
INFO - 2018-04-02 01:11:37 --> Config Class Initialized
INFO - 2018-04-02 01:11:37 --> Hooks Class Initialized
DEBUG - 2018-04-02 01:11:37 --> UTF-8 Support Enabled
INFO - 2018-04-02 01:11:37 --> Utf8 Class Initialized
DEBUG - 2018-04-02 01:11:37 --> UTF-8 Support Enabled
INFO - 2018-04-02 01:11:37 --> Utf8 Class Initialized
INFO - 2018-04-02 01:11:37 --> URI Class Initialized
INFO - 2018-04-02 01:11:37 --> URI Class Initialized
DEBUG - 2018-04-02 01:11:37 --> UTF-8 Support Enabled
INFO - 2018-04-02 01:11:37 --> Utf8 Class Initialized
INFO - 2018-04-02 01:11:37 --> Router Class Initialized
INFO - 2018-04-02 01:11:37 --> URI Class Initialized
INFO - 2018-04-02 01:11:37 --> Router Class Initialized
INFO - 2018-04-02 01:11:37 --> Output Class Initialized
INFO - 2018-04-02 01:11:37 --> Router Class Initialized
INFO - 2018-04-02 01:11:37 --> Output Class Initialized
INFO - 2018-04-02 01:11:37 --> Security Class Initialized
INFO - 2018-04-02 01:11:37 --> Output Class Initialized
INFO - 2018-04-02 01:11:37 --> Security Class Initialized
DEBUG - 2018-04-02 01:11:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 01:11:37 --> Input Class Initialized
INFO - 2018-04-02 01:11:37 --> Security Class Initialized
DEBUG - 2018-04-02 01:11:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 01:11:37 --> Input Class Initialized
INFO - 2018-04-02 01:11:37 --> Language Class Initialized
INFO - 2018-04-02 01:11:37 --> Language Class Initialized
DEBUG - 2018-04-02 01:11:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 01:11:37 --> Input Class Initialized
ERROR - 2018-04-02 01:11:37 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-04-02 01:11:37 --> Language Class Initialized
ERROR - 2018-04-02 01:11:37 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-04-02 01:11:37 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-04-02 01:11:37 --> Config Class Initialized
INFO - 2018-04-02 01:11:37 --> Hooks Class Initialized
DEBUG - 2018-04-02 01:11:37 --> UTF-8 Support Enabled
INFO - 2018-04-02 01:11:37 --> Utf8 Class Initialized
INFO - 2018-04-02 01:11:37 --> URI Class Initialized
INFO - 2018-04-02 01:11:37 --> Router Class Initialized
INFO - 2018-04-02 01:11:37 --> Output Class Initialized
INFO - 2018-04-02 01:11:37 --> Security Class Initialized
DEBUG - 2018-04-02 01:11:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 01:11:37 --> Input Class Initialized
INFO - 2018-04-02 01:11:37 --> Language Class Initialized
INFO - 2018-04-02 01:11:37 --> Loader Class Initialized
INFO - 2018-04-02 01:11:37 --> Helper loaded: url_helper
INFO - 2018-04-02 01:11:37 --> Helper loaded: form_helper
INFO - 2018-04-02 01:11:37 --> Database Driver Class Initialized
DEBUG - 2018-04-02 01:11:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 01:11:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 01:11:37 --> Form Validation Class Initialized
INFO - 2018-04-02 01:11:37 --> Model Class Initialized
INFO - 2018-04-02 01:11:37 --> Controller Class Initialized
INFO - 2018-04-02 01:11:37 --> Model Class Initialized
INFO - 2018-04-02 01:11:37 --> Model Class Initialized
INFO - 2018-04-02 01:11:37 --> Model Class Initialized
INFO - 2018-04-02 01:11:37 --> Model Class Initialized
DEBUG - 2018-04-02 01:11:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-02 01:11:41 --> Config Class Initialized
INFO - 2018-04-02 01:11:41 --> Hooks Class Initialized
DEBUG - 2018-04-02 01:11:41 --> UTF-8 Support Enabled
INFO - 2018-04-02 01:11:41 --> Utf8 Class Initialized
INFO - 2018-04-02 01:11:41 --> URI Class Initialized
INFO - 2018-04-02 01:11:41 --> Router Class Initialized
INFO - 2018-04-02 01:11:41 --> Output Class Initialized
INFO - 2018-04-02 01:11:41 --> Security Class Initialized
DEBUG - 2018-04-02 01:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 01:11:41 --> Input Class Initialized
INFO - 2018-04-02 01:11:41 --> Language Class Initialized
INFO - 2018-04-02 01:11:41 --> Loader Class Initialized
INFO - 2018-04-02 01:11:41 --> Helper loaded: url_helper
INFO - 2018-04-02 01:11:41 --> Helper loaded: form_helper
INFO - 2018-04-02 01:11:41 --> Database Driver Class Initialized
DEBUG - 2018-04-02 01:11:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 01:11:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 01:11:41 --> Form Validation Class Initialized
INFO - 2018-04-02 01:11:41 --> Model Class Initialized
INFO - 2018-04-02 01:11:41 --> Controller Class Initialized
INFO - 2018-04-02 01:11:41 --> Model Class Initialized
INFO - 2018-04-02 01:11:41 --> Model Class Initialized
INFO - 2018-04-02 01:11:41 --> Model Class Initialized
INFO - 2018-04-02 01:11:41 --> Model Class Initialized
DEBUG - 2018-04-02 01:11:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-02 01:11:42 --> Config Class Initialized
INFO - 2018-04-02 01:11:42 --> Hooks Class Initialized
DEBUG - 2018-04-02 01:11:42 --> UTF-8 Support Enabled
INFO - 2018-04-02 01:11:42 --> Utf8 Class Initialized
INFO - 2018-04-02 01:11:42 --> URI Class Initialized
INFO - 2018-04-02 01:11:42 --> Router Class Initialized
INFO - 2018-04-02 01:11:42 --> Output Class Initialized
INFO - 2018-04-02 01:11:42 --> Security Class Initialized
DEBUG - 2018-04-02 01:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 01:11:42 --> Input Class Initialized
INFO - 2018-04-02 01:11:42 --> Language Class Initialized
INFO - 2018-04-02 01:11:42 --> Loader Class Initialized
INFO - 2018-04-02 01:11:42 --> Helper loaded: url_helper
INFO - 2018-04-02 01:11:42 --> Helper loaded: form_helper
INFO - 2018-04-02 01:11:42 --> Database Driver Class Initialized
DEBUG - 2018-04-02 01:11:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 01:11:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 01:11:42 --> Form Validation Class Initialized
INFO - 2018-04-02 01:11:42 --> Model Class Initialized
INFO - 2018-04-02 01:11:42 --> Controller Class Initialized
INFO - 2018-04-02 01:11:42 --> Model Class Initialized
INFO - 2018-04-02 01:11:42 --> Model Class Initialized
INFO - 2018-04-02 01:11:42 --> Model Class Initialized
INFO - 2018-04-02 01:11:42 --> Model Class Initialized
DEBUG - 2018-04-02 01:11:42 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-04-02 01:11:42 --> Severity: Notice --> Undefined index: proyecto_gasto_estado D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 1571
ERROR - 2018-04-02 01:11:42 --> Severity: Notice --> Undefined index: proyecto_gasto_estado D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 1571
ERROR - 2018-04-02 01:11:42 --> Severity: Notice --> Undefined index: proyecto_gasto_estado D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 1571
INFO - 2018-04-02 01:11:42 --> Final output sent to browser
DEBUG - 2018-04-02 01:11:42 --> Total execution time: 0.1473
INFO - 2018-04-02 01:13:16 --> Config Class Initialized
INFO - 2018-04-02 01:13:16 --> Hooks Class Initialized
DEBUG - 2018-04-02 01:13:16 --> UTF-8 Support Enabled
INFO - 2018-04-02 01:13:16 --> Utf8 Class Initialized
INFO - 2018-04-02 01:13:16 --> URI Class Initialized
INFO - 2018-04-02 01:13:16 --> Router Class Initialized
INFO - 2018-04-02 01:13:16 --> Output Class Initialized
INFO - 2018-04-02 01:13:16 --> Security Class Initialized
DEBUG - 2018-04-02 01:13:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 01:13:16 --> Input Class Initialized
INFO - 2018-04-02 01:13:16 --> Language Class Initialized
INFO - 2018-04-02 01:13:16 --> Loader Class Initialized
INFO - 2018-04-02 01:13:16 --> Helper loaded: url_helper
INFO - 2018-04-02 01:13:16 --> Helper loaded: form_helper
INFO - 2018-04-02 01:13:16 --> Database Driver Class Initialized
DEBUG - 2018-04-02 01:13:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 01:13:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 01:13:16 --> Form Validation Class Initialized
INFO - 2018-04-02 01:13:16 --> Model Class Initialized
INFO - 2018-04-02 01:13:16 --> Controller Class Initialized
INFO - 2018-04-02 01:13:16 --> Model Class Initialized
INFO - 2018-04-02 01:13:16 --> Model Class Initialized
INFO - 2018-04-02 01:13:16 --> Model Class Initialized
INFO - 2018-04-02 01:13:16 --> Model Class Initialized
DEBUG - 2018-04-02 01:13:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-02 01:13:21 --> Config Class Initialized
INFO - 2018-04-02 01:13:21 --> Hooks Class Initialized
DEBUG - 2018-04-02 01:13:21 --> UTF-8 Support Enabled
INFO - 2018-04-02 01:13:21 --> Utf8 Class Initialized
INFO - 2018-04-02 01:13:21 --> URI Class Initialized
INFO - 2018-04-02 01:13:21 --> Router Class Initialized
INFO - 2018-04-02 01:13:21 --> Output Class Initialized
INFO - 2018-04-02 01:13:21 --> Security Class Initialized
DEBUG - 2018-04-02 01:13:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 01:13:21 --> Input Class Initialized
INFO - 2018-04-02 01:13:21 --> Language Class Initialized
INFO - 2018-04-02 01:13:21 --> Loader Class Initialized
INFO - 2018-04-02 01:13:21 --> Helper loaded: url_helper
INFO - 2018-04-02 01:13:21 --> Helper loaded: form_helper
INFO - 2018-04-02 01:13:21 --> Database Driver Class Initialized
DEBUG - 2018-04-02 01:13:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 01:13:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 01:13:21 --> Form Validation Class Initialized
INFO - 2018-04-02 01:13:21 --> Model Class Initialized
INFO - 2018-04-02 01:13:21 --> Controller Class Initialized
INFO - 2018-04-02 01:13:21 --> Model Class Initialized
INFO - 2018-04-02 01:13:21 --> Model Class Initialized
INFO - 2018-04-02 01:13:21 --> Model Class Initialized
INFO - 2018-04-02 01:13:21 --> Model Class Initialized
DEBUG - 2018-04-02 01:13:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-02 01:13:22 --> Config Class Initialized
INFO - 2018-04-02 01:13:22 --> Hooks Class Initialized
DEBUG - 2018-04-02 01:13:22 --> UTF-8 Support Enabled
INFO - 2018-04-02 01:13:22 --> Utf8 Class Initialized
INFO - 2018-04-02 01:13:22 --> URI Class Initialized
INFO - 2018-04-02 01:13:22 --> Router Class Initialized
INFO - 2018-04-02 01:13:22 --> Output Class Initialized
INFO - 2018-04-02 01:13:22 --> Security Class Initialized
DEBUG - 2018-04-02 01:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 01:13:22 --> Input Class Initialized
INFO - 2018-04-02 01:13:22 --> Language Class Initialized
INFO - 2018-04-02 01:13:22 --> Loader Class Initialized
INFO - 2018-04-02 01:13:22 --> Helper loaded: url_helper
INFO - 2018-04-02 01:13:22 --> Helper loaded: form_helper
INFO - 2018-04-02 01:13:22 --> Database Driver Class Initialized
DEBUG - 2018-04-02 01:13:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 01:13:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 01:13:22 --> Form Validation Class Initialized
INFO - 2018-04-02 01:13:22 --> Model Class Initialized
INFO - 2018-04-02 01:13:22 --> Controller Class Initialized
INFO - 2018-04-02 01:13:22 --> Model Class Initialized
INFO - 2018-04-02 01:13:22 --> Model Class Initialized
INFO - 2018-04-02 01:13:22 --> Model Class Initialized
INFO - 2018-04-02 01:13:22 --> Model Class Initialized
DEBUG - 2018-04-02 01:13:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-02 01:13:22 --> Final output sent to browser
DEBUG - 2018-04-02 01:13:22 --> Total execution time: 0.1252
INFO - 2018-04-02 01:13:32 --> Config Class Initialized
INFO - 2018-04-02 01:13:32 --> Hooks Class Initialized
DEBUG - 2018-04-02 01:13:32 --> UTF-8 Support Enabled
INFO - 2018-04-02 01:13:32 --> Utf8 Class Initialized
INFO - 2018-04-02 01:13:32 --> URI Class Initialized
INFO - 2018-04-02 01:13:32 --> Router Class Initialized
INFO - 2018-04-02 01:13:32 --> Output Class Initialized
INFO - 2018-04-02 01:13:32 --> Security Class Initialized
DEBUG - 2018-04-02 01:13:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 01:13:32 --> Input Class Initialized
INFO - 2018-04-02 01:13:32 --> Language Class Initialized
INFO - 2018-04-02 01:13:32 --> Loader Class Initialized
INFO - 2018-04-02 01:13:32 --> Helper loaded: url_helper
INFO - 2018-04-02 01:13:32 --> Helper loaded: form_helper
INFO - 2018-04-02 01:13:32 --> Database Driver Class Initialized
DEBUG - 2018-04-02 01:13:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 01:13:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 01:13:32 --> Form Validation Class Initialized
INFO - 2018-04-02 01:13:32 --> Model Class Initialized
INFO - 2018-04-02 01:13:32 --> Controller Class Initialized
INFO - 2018-04-02 01:13:32 --> Model Class Initialized
INFO - 2018-04-02 01:13:32 --> Model Class Initialized
INFO - 2018-04-02 01:13:32 --> Model Class Initialized
INFO - 2018-04-02 01:13:32 --> Model Class Initialized
DEBUG - 2018-04-02 01:13:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-02 01:13:33 --> Config Class Initialized
INFO - 2018-04-02 01:13:33 --> Hooks Class Initialized
DEBUG - 2018-04-02 01:13:33 --> UTF-8 Support Enabled
INFO - 2018-04-02 01:13:33 --> Utf8 Class Initialized
INFO - 2018-04-02 01:13:33 --> URI Class Initialized
INFO - 2018-04-02 01:13:33 --> Router Class Initialized
INFO - 2018-04-02 01:13:33 --> Output Class Initialized
INFO - 2018-04-02 01:13:33 --> Security Class Initialized
DEBUG - 2018-04-02 01:13:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 01:13:33 --> Input Class Initialized
INFO - 2018-04-02 01:13:33 --> Language Class Initialized
INFO - 2018-04-02 01:13:33 --> Loader Class Initialized
INFO - 2018-04-02 01:13:33 --> Helper loaded: url_helper
INFO - 2018-04-02 01:13:33 --> Helper loaded: form_helper
INFO - 2018-04-02 01:13:33 --> Database Driver Class Initialized
DEBUG - 2018-04-02 01:13:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 01:13:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 01:13:33 --> Form Validation Class Initialized
INFO - 2018-04-02 01:13:33 --> Model Class Initialized
INFO - 2018-04-02 01:13:33 --> Controller Class Initialized
INFO - 2018-04-02 01:13:33 --> Model Class Initialized
INFO - 2018-04-02 01:13:33 --> Model Class Initialized
INFO - 2018-04-02 01:13:33 --> Model Class Initialized
INFO - 2018-04-02 01:13:33 --> Model Class Initialized
DEBUG - 2018-04-02 01:13:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-02 01:13:34 --> Final output sent to browser
DEBUG - 2018-04-02 01:13:34 --> Total execution time: 0.1259
INFO - 2018-04-02 01:14:57 --> Config Class Initialized
INFO - 2018-04-02 01:14:57 --> Hooks Class Initialized
DEBUG - 2018-04-02 01:14:57 --> UTF-8 Support Enabled
INFO - 2018-04-02 01:14:57 --> Utf8 Class Initialized
INFO - 2018-04-02 01:14:57 --> URI Class Initialized
INFO - 2018-04-02 01:14:57 --> Router Class Initialized
INFO - 2018-04-02 01:14:57 --> Output Class Initialized
INFO - 2018-04-02 01:14:57 --> Security Class Initialized
DEBUG - 2018-04-02 01:14:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 01:14:57 --> Input Class Initialized
INFO - 2018-04-02 01:14:57 --> Language Class Initialized
INFO - 2018-04-02 01:14:57 --> Loader Class Initialized
INFO - 2018-04-02 01:14:57 --> Helper loaded: url_helper
INFO - 2018-04-02 01:14:57 --> Helper loaded: form_helper
INFO - 2018-04-02 01:14:57 --> Database Driver Class Initialized
DEBUG - 2018-04-02 01:14:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 01:14:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 01:14:57 --> Form Validation Class Initialized
INFO - 2018-04-02 01:14:57 --> Model Class Initialized
INFO - 2018-04-02 01:14:57 --> Controller Class Initialized
INFO - 2018-04-02 01:14:57 --> Model Class Initialized
INFO - 2018-04-02 01:14:57 --> Model Class Initialized
INFO - 2018-04-02 01:14:57 --> Model Class Initialized
INFO - 2018-04-02 01:14:57 --> Model Class Initialized
DEBUG - 2018-04-02 01:14:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-02 01:14:57 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-02 01:14:57 --> Final output sent to browser
DEBUG - 2018-04-02 01:14:57 --> Total execution time: 0.0793
INFO - 2018-04-02 01:14:57 --> Config Class Initialized
INFO - 2018-04-02 01:14:57 --> Hooks Class Initialized
INFO - 2018-04-02 01:14:57 --> Config Class Initialized
INFO - 2018-04-02 01:14:57 --> Config Class Initialized
INFO - 2018-04-02 01:14:57 --> Config Class Initialized
INFO - 2018-04-02 01:14:57 --> Hooks Class Initialized
INFO - 2018-04-02 01:14:57 --> Hooks Class Initialized
INFO - 2018-04-02 01:14:57 --> Hooks Class Initialized
DEBUG - 2018-04-02 01:14:57 --> UTF-8 Support Enabled
INFO - 2018-04-02 01:14:57 --> Utf8 Class Initialized
DEBUG - 2018-04-02 01:14:57 --> UTF-8 Support Enabled
DEBUG - 2018-04-02 01:14:57 --> UTF-8 Support Enabled
INFO - 2018-04-02 01:14:57 --> Utf8 Class Initialized
DEBUG - 2018-04-02 01:14:57 --> UTF-8 Support Enabled
INFO - 2018-04-02 01:14:57 --> Utf8 Class Initialized
INFO - 2018-04-02 01:14:57 --> Utf8 Class Initialized
INFO - 2018-04-02 01:14:57 --> URI Class Initialized
INFO - 2018-04-02 01:14:57 --> URI Class Initialized
INFO - 2018-04-02 01:14:57 --> URI Class Initialized
INFO - 2018-04-02 01:14:57 --> URI Class Initialized
INFO - 2018-04-02 01:14:57 --> Router Class Initialized
INFO - 2018-04-02 01:14:57 --> Router Class Initialized
INFO - 2018-04-02 01:14:57 --> Router Class Initialized
INFO - 2018-04-02 01:14:57 --> Router Class Initialized
INFO - 2018-04-02 01:14:57 --> Output Class Initialized
INFO - 2018-04-02 01:14:57 --> Output Class Initialized
INFO - 2018-04-02 01:14:57 --> Output Class Initialized
INFO - 2018-04-02 01:14:57 --> Output Class Initialized
INFO - 2018-04-02 01:14:57 --> Security Class Initialized
INFO - 2018-04-02 01:14:57 --> Security Class Initialized
INFO - 2018-04-02 01:14:57 --> Security Class Initialized
INFO - 2018-04-02 01:14:57 --> Security Class Initialized
DEBUG - 2018-04-02 01:14:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 01:14:57 --> Input Class Initialized
DEBUG - 2018-04-02 01:14:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 01:14:57 --> Input Class Initialized
DEBUG - 2018-04-02 01:14:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 01:14:57 --> Input Class Initialized
DEBUG - 2018-04-02 01:14:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 01:14:57 --> Language Class Initialized
INFO - 2018-04-02 01:14:57 --> Language Class Initialized
INFO - 2018-04-02 01:14:57 --> Input Class Initialized
INFO - 2018-04-02 01:14:57 --> Language Class Initialized
INFO - 2018-04-02 01:14:57 --> Language Class Initialized
ERROR - 2018-04-02 01:14:57 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-04-02 01:14:57 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-04-02 01:14:57 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-04-02 01:14:57 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-04-02 01:14:58 --> Config Class Initialized
INFO - 2018-04-02 01:14:58 --> Hooks Class Initialized
INFO - 2018-04-02 01:14:58 --> Config Class Initialized
INFO - 2018-04-02 01:14:58 --> Hooks Class Initialized
INFO - 2018-04-02 01:14:58 --> Config Class Initialized
INFO - 2018-04-02 01:14:58 --> Hooks Class Initialized
DEBUG - 2018-04-02 01:14:58 --> UTF-8 Support Enabled
INFO - 2018-04-02 01:14:58 --> Utf8 Class Initialized
DEBUG - 2018-04-02 01:14:58 --> UTF-8 Support Enabled
INFO - 2018-04-02 01:14:58 --> Utf8 Class Initialized
DEBUG - 2018-04-02 01:14:58 --> UTF-8 Support Enabled
INFO - 2018-04-02 01:14:58 --> URI Class Initialized
INFO - 2018-04-02 01:14:58 --> Utf8 Class Initialized
INFO - 2018-04-02 01:14:58 --> URI Class Initialized
INFO - 2018-04-02 01:14:58 --> URI Class Initialized
INFO - 2018-04-02 01:14:58 --> Router Class Initialized
INFO - 2018-04-02 01:14:58 --> Router Class Initialized
INFO - 2018-04-02 01:14:58 --> Router Class Initialized
INFO - 2018-04-02 01:14:58 --> Output Class Initialized
INFO - 2018-04-02 01:14:58 --> Output Class Initialized
INFO - 2018-04-02 01:14:58 --> Security Class Initialized
INFO - 2018-04-02 01:14:58 --> Output Class Initialized
DEBUG - 2018-04-02 01:14:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 01:14:58 --> Security Class Initialized
INFO - 2018-04-02 01:14:58 --> Input Class Initialized
INFO - 2018-04-02 01:14:58 --> Security Class Initialized
INFO - 2018-04-02 01:14:58 --> Language Class Initialized
DEBUG - 2018-04-02 01:14:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 01:14:58 --> Input Class Initialized
DEBUG - 2018-04-02 01:14:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 01:14:58 --> Language Class Initialized
INFO - 2018-04-02 01:14:58 --> Input Class Initialized
ERROR - 2018-04-02 01:14:58 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-04-02 01:14:58 --> Language Class Initialized
ERROR - 2018-04-02 01:14:58 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-04-02 01:14:58 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-04-02 01:14:58 --> Config Class Initialized
INFO - 2018-04-02 01:14:58 --> Hooks Class Initialized
DEBUG - 2018-04-02 01:14:58 --> UTF-8 Support Enabled
INFO - 2018-04-02 01:14:58 --> Utf8 Class Initialized
INFO - 2018-04-02 01:14:58 --> URI Class Initialized
INFO - 2018-04-02 01:14:58 --> Router Class Initialized
INFO - 2018-04-02 01:14:58 --> Output Class Initialized
INFO - 2018-04-02 01:14:58 --> Security Class Initialized
DEBUG - 2018-04-02 01:14:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 01:14:58 --> Input Class Initialized
INFO - 2018-04-02 01:14:58 --> Language Class Initialized
INFO - 2018-04-02 01:14:58 --> Loader Class Initialized
INFO - 2018-04-02 01:14:58 --> Helper loaded: url_helper
INFO - 2018-04-02 01:14:58 --> Helper loaded: form_helper
INFO - 2018-04-02 01:14:58 --> Database Driver Class Initialized
DEBUG - 2018-04-02 01:14:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 01:14:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 01:14:58 --> Form Validation Class Initialized
INFO - 2018-04-02 01:14:58 --> Model Class Initialized
INFO - 2018-04-02 01:14:58 --> Controller Class Initialized
INFO - 2018-04-02 01:14:58 --> Model Class Initialized
INFO - 2018-04-02 01:14:58 --> Model Class Initialized
INFO - 2018-04-02 01:14:58 --> Model Class Initialized
INFO - 2018-04-02 01:14:58 --> Model Class Initialized
DEBUG - 2018-04-02 01:14:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-02 01:15:20 --> Config Class Initialized
INFO - 2018-04-02 01:15:20 --> Hooks Class Initialized
DEBUG - 2018-04-02 01:15:20 --> UTF-8 Support Enabled
INFO - 2018-04-02 01:15:20 --> Utf8 Class Initialized
INFO - 2018-04-02 01:15:20 --> URI Class Initialized
INFO - 2018-04-02 01:15:20 --> Router Class Initialized
INFO - 2018-04-02 01:15:20 --> Output Class Initialized
INFO - 2018-04-02 01:15:20 --> Security Class Initialized
DEBUG - 2018-04-02 01:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 01:15:20 --> Input Class Initialized
INFO - 2018-04-02 01:15:20 --> Language Class Initialized
INFO - 2018-04-02 01:15:20 --> Loader Class Initialized
INFO - 2018-04-02 01:15:20 --> Helper loaded: url_helper
INFO - 2018-04-02 01:15:20 --> Helper loaded: form_helper
INFO - 2018-04-02 01:15:20 --> Database Driver Class Initialized
DEBUG - 2018-04-02 01:15:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 01:15:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 01:15:20 --> Form Validation Class Initialized
INFO - 2018-04-02 01:15:20 --> Model Class Initialized
INFO - 2018-04-02 01:15:20 --> Controller Class Initialized
INFO - 2018-04-02 01:15:20 --> Model Class Initialized
INFO - 2018-04-02 01:15:20 --> Model Class Initialized
INFO - 2018-04-02 01:15:20 --> Model Class Initialized
INFO - 2018-04-02 01:15:20 --> Model Class Initialized
DEBUG - 2018-04-02 01:15:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-02 01:15:24 --> Config Class Initialized
INFO - 2018-04-02 01:15:24 --> Hooks Class Initialized
DEBUG - 2018-04-02 01:15:24 --> UTF-8 Support Enabled
INFO - 2018-04-02 01:15:24 --> Utf8 Class Initialized
INFO - 2018-04-02 01:15:24 --> URI Class Initialized
INFO - 2018-04-02 01:15:24 --> Router Class Initialized
INFO - 2018-04-02 01:15:24 --> Output Class Initialized
INFO - 2018-04-02 01:15:24 --> Security Class Initialized
DEBUG - 2018-04-02 01:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 01:15:24 --> Input Class Initialized
INFO - 2018-04-02 01:15:24 --> Language Class Initialized
INFO - 2018-04-02 01:15:24 --> Loader Class Initialized
INFO - 2018-04-02 01:15:24 --> Helper loaded: url_helper
INFO - 2018-04-02 01:15:24 --> Helper loaded: form_helper
INFO - 2018-04-02 01:15:24 --> Database Driver Class Initialized
DEBUG - 2018-04-02 01:15:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 01:15:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 01:15:24 --> Form Validation Class Initialized
INFO - 2018-04-02 01:15:24 --> Model Class Initialized
INFO - 2018-04-02 01:15:24 --> Controller Class Initialized
INFO - 2018-04-02 01:15:24 --> Model Class Initialized
INFO - 2018-04-02 01:15:24 --> Model Class Initialized
INFO - 2018-04-02 01:15:24 --> Model Class Initialized
INFO - 2018-04-02 01:15:24 --> Model Class Initialized
DEBUG - 2018-04-02 01:15:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-02 01:15:25 --> Config Class Initialized
INFO - 2018-04-02 01:15:25 --> Hooks Class Initialized
DEBUG - 2018-04-02 01:15:25 --> UTF-8 Support Enabled
INFO - 2018-04-02 01:15:25 --> Utf8 Class Initialized
INFO - 2018-04-02 01:15:25 --> URI Class Initialized
INFO - 2018-04-02 01:15:25 --> Router Class Initialized
INFO - 2018-04-02 01:15:25 --> Output Class Initialized
INFO - 2018-04-02 01:15:25 --> Security Class Initialized
DEBUG - 2018-04-02 01:15:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 01:15:25 --> Input Class Initialized
INFO - 2018-04-02 01:15:25 --> Language Class Initialized
INFO - 2018-04-02 01:15:25 --> Loader Class Initialized
INFO - 2018-04-02 01:15:25 --> Helper loaded: url_helper
INFO - 2018-04-02 01:15:25 --> Helper loaded: form_helper
INFO - 2018-04-02 01:15:25 --> Database Driver Class Initialized
DEBUG - 2018-04-02 01:15:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 01:15:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 01:15:25 --> Form Validation Class Initialized
INFO - 2018-04-02 01:15:25 --> Model Class Initialized
INFO - 2018-04-02 01:15:25 --> Controller Class Initialized
INFO - 2018-04-02 01:15:25 --> Model Class Initialized
INFO - 2018-04-02 01:15:25 --> Model Class Initialized
INFO - 2018-04-02 01:15:25 --> Model Class Initialized
INFO - 2018-04-02 01:15:25 --> Model Class Initialized
DEBUG - 2018-04-02 01:15:25 --> Form_validation class already loaded. Second attempt ignored.
