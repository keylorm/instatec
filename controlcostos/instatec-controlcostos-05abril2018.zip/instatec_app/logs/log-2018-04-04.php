<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-04-04 00:00:50 --> Config Class Initialized
INFO - 2018-04-04 00:00:50 --> Hooks Class Initialized
DEBUG - 2018-04-04 00:00:50 --> UTF-8 Support Enabled
INFO - 2018-04-04 00:00:50 --> Utf8 Class Initialized
INFO - 2018-04-04 00:00:50 --> URI Class Initialized
INFO - 2018-04-04 00:00:50 --> Router Class Initialized
INFO - 2018-04-04 00:00:50 --> Output Class Initialized
INFO - 2018-04-04 00:00:50 --> Security Class Initialized
DEBUG - 2018-04-04 00:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 00:00:50 --> Input Class Initialized
INFO - 2018-04-04 00:00:50 --> Language Class Initialized
INFO - 2018-04-04 00:00:50 --> Loader Class Initialized
INFO - 2018-04-04 00:00:50 --> Helper loaded: url_helper
INFO - 2018-04-04 00:00:50 --> Helper loaded: form_helper
INFO - 2018-04-04 00:00:50 --> Database Driver Class Initialized
DEBUG - 2018-04-04 00:00:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 00:00:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 00:00:50 --> Form Validation Class Initialized
INFO - 2018-04-04 00:00:50 --> Model Class Initialized
INFO - 2018-04-04 00:00:50 --> Controller Class Initialized
INFO - 2018-04-04 00:00:50 --> Model Class Initialized
INFO - 2018-04-04 00:00:50 --> Model Class Initialized
DEBUG - 2018-04-04 00:00:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-04 00:00:50 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-04 00:00:50 --> Final output sent to browser
DEBUG - 2018-04-04 00:00:50 --> Total execution time: 0.3601
INFO - 2018-04-04 00:00:50 --> Config Class Initialized
INFO - 2018-04-04 00:00:50 --> Hooks Class Initialized
DEBUG - 2018-04-04 00:00:50 --> UTF-8 Support Enabled
INFO - 2018-04-04 00:00:50 --> Utf8 Class Initialized
INFO - 2018-04-04 00:00:50 --> URI Class Initialized
INFO - 2018-04-04 00:00:50 --> Router Class Initialized
INFO - 2018-04-04 00:00:50 --> Output Class Initialized
INFO - 2018-04-04 00:00:50 --> Security Class Initialized
DEBUG - 2018-04-04 00:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 00:00:50 --> Input Class Initialized
INFO - 2018-04-04 00:00:50 --> Language Class Initialized
INFO - 2018-04-04 00:00:50 --> Loader Class Initialized
INFO - 2018-04-04 00:00:50 --> Helper loaded: url_helper
INFO - 2018-04-04 00:00:50 --> Helper loaded: form_helper
INFO - 2018-04-04 00:00:50 --> Database Driver Class Initialized
DEBUG - 2018-04-04 00:00:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 00:00:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 00:00:50 --> Form Validation Class Initialized
INFO - 2018-04-04 00:00:50 --> Model Class Initialized
INFO - 2018-04-04 00:00:50 --> Controller Class Initialized
INFO - 2018-04-04 00:00:50 --> Model Class Initialized
INFO - 2018-04-04 00:00:50 --> Model Class Initialized
DEBUG - 2018-04-04 00:00:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-04 00:07:31 --> Config Class Initialized
INFO - 2018-04-04 00:07:31 --> Hooks Class Initialized
DEBUG - 2018-04-04 00:07:31 --> UTF-8 Support Enabled
INFO - 2018-04-04 00:07:31 --> Utf8 Class Initialized
INFO - 2018-04-04 00:07:31 --> URI Class Initialized
INFO - 2018-04-04 00:07:31 --> Router Class Initialized
INFO - 2018-04-04 00:07:31 --> Output Class Initialized
INFO - 2018-04-04 00:07:31 --> Security Class Initialized
DEBUG - 2018-04-04 00:07:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 00:07:31 --> Input Class Initialized
INFO - 2018-04-04 00:07:31 --> Language Class Initialized
INFO - 2018-04-04 00:07:31 --> Loader Class Initialized
INFO - 2018-04-04 00:07:31 --> Helper loaded: url_helper
INFO - 2018-04-04 00:07:31 --> Helper loaded: form_helper
INFO - 2018-04-04 00:07:31 --> Database Driver Class Initialized
DEBUG - 2018-04-04 00:07:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 00:07:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 00:07:32 --> Form Validation Class Initialized
INFO - 2018-04-04 00:07:32 --> Model Class Initialized
INFO - 2018-04-04 00:07:32 --> Controller Class Initialized
INFO - 2018-04-04 00:07:32 --> Model Class Initialized
INFO - 2018-04-04 00:07:32 --> Model Class Initialized
DEBUG - 2018-04-04 00:07:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-04 00:07:32 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-04 00:07:32 --> Final output sent to browser
DEBUG - 2018-04-04 00:07:32 --> Total execution time: 0.3258
INFO - 2018-04-04 00:09:18 --> Config Class Initialized
INFO - 2018-04-04 00:09:18 --> Hooks Class Initialized
DEBUG - 2018-04-04 00:09:18 --> UTF-8 Support Enabled
INFO - 2018-04-04 00:09:18 --> Utf8 Class Initialized
INFO - 2018-04-04 00:09:18 --> URI Class Initialized
INFO - 2018-04-04 00:09:18 --> Router Class Initialized
INFO - 2018-04-04 00:09:18 --> Output Class Initialized
INFO - 2018-04-04 00:09:18 --> Security Class Initialized
DEBUG - 2018-04-04 00:09:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 00:09:18 --> Input Class Initialized
INFO - 2018-04-04 00:09:18 --> Language Class Initialized
INFO - 2018-04-04 00:09:18 --> Loader Class Initialized
INFO - 2018-04-04 00:09:18 --> Helper loaded: url_helper
INFO - 2018-04-04 00:09:18 --> Helper loaded: form_helper
INFO - 2018-04-04 00:09:18 --> Database Driver Class Initialized
DEBUG - 2018-04-04 00:09:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 00:09:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 00:09:18 --> Form Validation Class Initialized
INFO - 2018-04-04 00:09:18 --> Model Class Initialized
INFO - 2018-04-04 00:09:18 --> Controller Class Initialized
INFO - 2018-04-04 00:09:18 --> Model Class Initialized
INFO - 2018-04-04 00:09:18 --> Model Class Initialized
DEBUG - 2018-04-04 00:09:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-04 00:09:18 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-04 00:09:18 --> Final output sent to browser
DEBUG - 2018-04-04 00:09:18 --> Total execution time: 0.0434
INFO - 2018-04-04 00:09:18 --> Config Class Initialized
INFO - 2018-04-04 00:09:18 --> Hooks Class Initialized
DEBUG - 2018-04-04 00:09:18 --> UTF-8 Support Enabled
INFO - 2018-04-04 00:09:18 --> Utf8 Class Initialized
INFO - 2018-04-04 00:09:18 --> URI Class Initialized
INFO - 2018-04-04 00:09:18 --> Router Class Initialized
INFO - 2018-04-04 00:09:18 --> Output Class Initialized
INFO - 2018-04-04 00:09:18 --> Security Class Initialized
DEBUG - 2018-04-04 00:09:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 00:09:19 --> Input Class Initialized
INFO - 2018-04-04 00:09:19 --> Language Class Initialized
INFO - 2018-04-04 00:09:19 --> Loader Class Initialized
INFO - 2018-04-04 00:09:19 --> Helper loaded: url_helper
INFO - 2018-04-04 00:09:19 --> Helper loaded: form_helper
INFO - 2018-04-04 00:09:19 --> Database Driver Class Initialized
DEBUG - 2018-04-04 00:09:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 00:09:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 00:09:19 --> Form Validation Class Initialized
INFO - 2018-04-04 00:09:19 --> Model Class Initialized
INFO - 2018-04-04 00:09:19 --> Controller Class Initialized
INFO - 2018-04-04 00:09:19 --> Model Class Initialized
INFO - 2018-04-04 00:09:19 --> Model Class Initialized
DEBUG - 2018-04-04 00:09:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-04 00:09:20 --> Config Class Initialized
INFO - 2018-04-04 00:09:20 --> Hooks Class Initialized
DEBUG - 2018-04-04 00:09:20 --> UTF-8 Support Enabled
INFO - 2018-04-04 00:09:20 --> Utf8 Class Initialized
INFO - 2018-04-04 00:09:20 --> URI Class Initialized
INFO - 2018-04-04 00:09:20 --> Router Class Initialized
INFO - 2018-04-04 00:09:20 --> Output Class Initialized
INFO - 2018-04-04 00:09:20 --> Security Class Initialized
DEBUG - 2018-04-04 00:09:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 00:09:20 --> Input Class Initialized
INFO - 2018-04-04 00:09:20 --> Language Class Initialized
INFO - 2018-04-04 00:09:20 --> Loader Class Initialized
INFO - 2018-04-04 00:09:20 --> Helper loaded: url_helper
INFO - 2018-04-04 00:09:20 --> Helper loaded: form_helper
INFO - 2018-04-04 00:09:20 --> Database Driver Class Initialized
DEBUG - 2018-04-04 00:09:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 00:09:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 00:09:20 --> Form Validation Class Initialized
INFO - 2018-04-04 00:09:20 --> Model Class Initialized
INFO - 2018-04-04 00:09:20 --> Controller Class Initialized
INFO - 2018-04-04 00:09:20 --> Model Class Initialized
INFO - 2018-04-04 00:09:20 --> Model Class Initialized
DEBUG - 2018-04-04 00:09:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-04 00:09:20 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-04 00:09:20 --> Final output sent to browser
DEBUG - 2018-04-04 00:09:20 --> Total execution time: 0.3263
INFO - 2018-04-04 00:10:14 --> Config Class Initialized
INFO - 2018-04-04 00:10:14 --> Hooks Class Initialized
DEBUG - 2018-04-04 00:10:14 --> UTF-8 Support Enabled
INFO - 2018-04-04 00:10:14 --> Utf8 Class Initialized
INFO - 2018-04-04 00:10:14 --> URI Class Initialized
INFO - 2018-04-04 00:10:14 --> Router Class Initialized
INFO - 2018-04-04 00:10:14 --> Output Class Initialized
INFO - 2018-04-04 00:10:14 --> Security Class Initialized
DEBUG - 2018-04-04 00:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 00:10:14 --> Input Class Initialized
INFO - 2018-04-04 00:10:14 --> Language Class Initialized
INFO - 2018-04-04 00:10:14 --> Loader Class Initialized
INFO - 2018-04-04 00:10:14 --> Helper loaded: url_helper
INFO - 2018-04-04 00:10:14 --> Helper loaded: form_helper
INFO - 2018-04-04 00:10:14 --> Database Driver Class Initialized
DEBUG - 2018-04-04 00:10:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 00:10:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 00:10:14 --> Form Validation Class Initialized
INFO - 2018-04-04 00:10:14 --> Model Class Initialized
INFO - 2018-04-04 00:10:14 --> Controller Class Initialized
INFO - 2018-04-04 00:10:14 --> Model Class Initialized
INFO - 2018-04-04 00:10:14 --> Model Class Initialized
INFO - 2018-04-04 00:10:14 --> Model Class Initialized
INFO - 2018-04-04 00:10:14 --> Model Class Initialized
INFO - 2018-04-04 00:10:14 --> Model Class Initialized
DEBUG - 2018-04-04 00:10:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-04 00:10:14 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-04 00:10:14 --> Final output sent to browser
DEBUG - 2018-04-04 00:10:14 --> Total execution time: 0.0561
INFO - 2018-04-04 00:10:14 --> Config Class Initialized
INFO - 2018-04-04 00:10:14 --> Hooks Class Initialized
DEBUG - 2018-04-04 00:10:14 --> UTF-8 Support Enabled
INFO - 2018-04-04 00:10:14 --> Utf8 Class Initialized
INFO - 2018-04-04 00:10:14 --> URI Class Initialized
INFO - 2018-04-04 00:10:14 --> Router Class Initialized
INFO - 2018-04-04 00:10:14 --> Output Class Initialized
INFO - 2018-04-04 00:10:14 --> Security Class Initialized
DEBUG - 2018-04-04 00:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 00:10:14 --> Input Class Initialized
INFO - 2018-04-04 00:10:14 --> Language Class Initialized
INFO - 2018-04-04 00:10:14 --> Loader Class Initialized
INFO - 2018-04-04 00:10:14 --> Helper loaded: url_helper
INFO - 2018-04-04 00:10:14 --> Helper loaded: form_helper
INFO - 2018-04-04 00:10:14 --> Database Driver Class Initialized
DEBUG - 2018-04-04 00:10:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 00:10:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 00:10:14 --> Form Validation Class Initialized
INFO - 2018-04-04 00:10:14 --> Model Class Initialized
INFO - 2018-04-04 00:10:14 --> Controller Class Initialized
INFO - 2018-04-04 00:10:14 --> Model Class Initialized
INFO - 2018-04-04 00:10:14 --> Model Class Initialized
INFO - 2018-04-04 00:10:14 --> Model Class Initialized
INFO - 2018-04-04 00:10:14 --> Model Class Initialized
INFO - 2018-04-04 00:10:14 --> Model Class Initialized
DEBUG - 2018-04-04 00:10:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-04 22:46:46 --> Config Class Initialized
INFO - 2018-04-04 22:46:46 --> Hooks Class Initialized
DEBUG - 2018-04-04 22:46:46 --> UTF-8 Support Enabled
INFO - 2018-04-04 22:46:46 --> Utf8 Class Initialized
INFO - 2018-04-04 22:46:46 --> URI Class Initialized
INFO - 2018-04-04 22:46:46 --> Router Class Initialized
INFO - 2018-04-04 22:46:46 --> Output Class Initialized
INFO - 2018-04-04 22:46:46 --> Security Class Initialized
DEBUG - 2018-04-04 22:46:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 22:46:46 --> Input Class Initialized
INFO - 2018-04-04 22:46:46 --> Language Class Initialized
INFO - 2018-04-04 22:46:46 --> Loader Class Initialized
INFO - 2018-04-04 22:46:46 --> Helper loaded: url_helper
INFO - 2018-04-04 22:46:46 --> Helper loaded: form_helper
INFO - 2018-04-04 22:46:46 --> Database Driver Class Initialized
DEBUG - 2018-04-04 22:46:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 22:46:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 22:46:46 --> Form Validation Class Initialized
INFO - 2018-04-04 22:46:46 --> Model Class Initialized
INFO - 2018-04-04 22:46:46 --> Controller Class Initialized
INFO - 2018-04-04 22:46:46 --> Model Class Initialized
INFO - 2018-04-04 22:46:46 --> Model Class Initialized
INFO - 2018-04-04 22:46:46 --> Model Class Initialized
INFO - 2018-04-04 22:46:46 --> Model Class Initialized
INFO - 2018-04-04 22:46:46 --> Model Class Initialized
DEBUG - 2018-04-04 22:46:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-04 22:46:46 --> Config Class Initialized
INFO - 2018-04-04 22:46:46 --> Hooks Class Initialized
DEBUG - 2018-04-04 22:46:46 --> UTF-8 Support Enabled
INFO - 2018-04-04 22:46:46 --> Utf8 Class Initialized
INFO - 2018-04-04 22:46:46 --> URI Class Initialized
INFO - 2018-04-04 22:46:46 --> Router Class Initialized
INFO - 2018-04-04 22:46:46 --> Output Class Initialized
INFO - 2018-04-04 22:46:46 --> Security Class Initialized
DEBUG - 2018-04-04 22:46:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 22:46:46 --> Input Class Initialized
INFO - 2018-04-04 22:46:46 --> Language Class Initialized
INFO - 2018-04-04 22:46:47 --> Loader Class Initialized
INFO - 2018-04-04 22:46:47 --> Helper loaded: url_helper
INFO - 2018-04-04 22:46:47 --> Helper loaded: form_helper
INFO - 2018-04-04 22:46:47 --> Database Driver Class Initialized
DEBUG - 2018-04-04 22:46:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 22:46:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 22:46:47 --> Form Validation Class Initialized
INFO - 2018-04-04 22:46:47 --> Model Class Initialized
INFO - 2018-04-04 22:46:47 --> Controller Class Initialized
INFO - 2018-04-04 22:46:47 --> Model Class Initialized
DEBUG - 2018-04-04 22:46:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-04 22:46:47 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-04 22:46:47 --> Final output sent to browser
DEBUG - 2018-04-04 22:46:47 --> Total execution time: 0.3475
INFO - 2018-04-04 22:46:48 --> Config Class Initialized
INFO - 2018-04-04 22:46:48 --> Hooks Class Initialized
DEBUG - 2018-04-04 22:46:48 --> UTF-8 Support Enabled
INFO - 2018-04-04 22:46:48 --> Utf8 Class Initialized
INFO - 2018-04-04 22:46:48 --> URI Class Initialized
INFO - 2018-04-04 22:46:48 --> Router Class Initialized
INFO - 2018-04-04 22:46:48 --> Output Class Initialized
INFO - 2018-04-04 22:46:48 --> Security Class Initialized
DEBUG - 2018-04-04 22:46:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 22:46:48 --> Input Class Initialized
INFO - 2018-04-04 22:46:48 --> Language Class Initialized
INFO - 2018-04-04 22:46:48 --> Loader Class Initialized
INFO - 2018-04-04 22:46:48 --> Helper loaded: url_helper
INFO - 2018-04-04 22:46:48 --> Helper loaded: form_helper
INFO - 2018-04-04 22:46:48 --> Database Driver Class Initialized
DEBUG - 2018-04-04 22:46:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 22:46:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 22:46:48 --> Form Validation Class Initialized
INFO - 2018-04-04 22:46:48 --> Model Class Initialized
INFO - 2018-04-04 22:46:48 --> Controller Class Initialized
INFO - 2018-04-04 22:46:48 --> Model Class Initialized
DEBUG - 2018-04-04 22:46:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-04 22:46:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-04 22:46:48 --> Config Class Initialized
INFO - 2018-04-04 22:46:48 --> Hooks Class Initialized
DEBUG - 2018-04-04 22:46:48 --> UTF-8 Support Enabled
INFO - 2018-04-04 22:46:48 --> Utf8 Class Initialized
INFO - 2018-04-04 22:46:48 --> URI Class Initialized
DEBUG - 2018-04-04 22:46:48 --> No URI present. Default controller set.
INFO - 2018-04-04 22:46:48 --> Router Class Initialized
INFO - 2018-04-04 22:46:48 --> Output Class Initialized
INFO - 2018-04-04 22:46:48 --> Security Class Initialized
DEBUG - 2018-04-04 22:46:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 22:46:48 --> Input Class Initialized
INFO - 2018-04-04 22:46:48 --> Language Class Initialized
INFO - 2018-04-04 22:46:48 --> Loader Class Initialized
INFO - 2018-04-04 22:46:48 --> Helper loaded: url_helper
INFO - 2018-04-04 22:46:48 --> Helper loaded: form_helper
INFO - 2018-04-04 22:46:48 --> Database Driver Class Initialized
DEBUG - 2018-04-04 22:46:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 22:46:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 22:46:48 --> Form Validation Class Initialized
INFO - 2018-04-04 22:46:48 --> Model Class Initialized
INFO - 2018-04-04 22:46:48 --> Controller Class Initialized
INFO - 2018-04-04 22:46:48 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-04 22:46:48 --> Final output sent to browser
DEBUG - 2018-04-04 22:46:48 --> Total execution time: 0.0392
INFO - 2018-04-04 22:46:48 --> Config Class Initialized
INFO - 2018-04-04 22:46:48 --> Hooks Class Initialized
DEBUG - 2018-04-04 22:46:48 --> UTF-8 Support Enabled
INFO - 2018-04-04 22:46:48 --> Utf8 Class Initialized
INFO - 2018-04-04 22:46:48 --> URI Class Initialized
INFO - 2018-04-04 22:46:48 --> Router Class Initialized
INFO - 2018-04-04 22:46:48 --> Output Class Initialized
INFO - 2018-04-04 22:46:48 --> Security Class Initialized
DEBUG - 2018-04-04 22:46:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 22:46:48 --> Input Class Initialized
INFO - 2018-04-04 22:46:48 --> Language Class Initialized
INFO - 2018-04-04 22:46:48 --> Loader Class Initialized
INFO - 2018-04-04 22:46:48 --> Helper loaded: url_helper
INFO - 2018-04-04 22:46:48 --> Helper loaded: form_helper
INFO - 2018-04-04 22:46:48 --> Database Driver Class Initialized
DEBUG - 2018-04-04 22:46:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 22:46:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 22:46:48 --> Form Validation Class Initialized
INFO - 2018-04-04 22:46:48 --> Model Class Initialized
INFO - 2018-04-04 22:46:48 --> Controller Class Initialized
INFO - 2018-04-04 22:46:48 --> Model Class Initialized
INFO - 2018-04-04 22:46:48 --> Model Class Initialized
INFO - 2018-04-04 22:46:48 --> Model Class Initialized
INFO - 2018-04-04 22:46:48 --> Model Class Initialized
INFO - 2018-04-04 22:46:48 --> Model Class Initialized
DEBUG - 2018-04-04 22:46:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-04 22:46:52 --> Config Class Initialized
INFO - 2018-04-04 22:46:52 --> Hooks Class Initialized
DEBUG - 2018-04-04 22:46:52 --> UTF-8 Support Enabled
INFO - 2018-04-04 22:46:52 --> Utf8 Class Initialized
INFO - 2018-04-04 22:46:52 --> URI Class Initialized
INFO - 2018-04-04 22:46:52 --> Router Class Initialized
INFO - 2018-04-04 22:46:52 --> Output Class Initialized
INFO - 2018-04-04 22:46:52 --> Security Class Initialized
DEBUG - 2018-04-04 22:46:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 22:46:52 --> Input Class Initialized
INFO - 2018-04-04 22:46:52 --> Language Class Initialized
INFO - 2018-04-04 22:46:52 --> Loader Class Initialized
INFO - 2018-04-04 22:46:52 --> Helper loaded: url_helper
INFO - 2018-04-04 22:46:52 --> Helper loaded: form_helper
INFO - 2018-04-04 22:46:52 --> Database Driver Class Initialized
DEBUG - 2018-04-04 22:46:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 22:46:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 22:46:52 --> Form Validation Class Initialized
INFO - 2018-04-04 22:46:52 --> Model Class Initialized
INFO - 2018-04-04 22:46:52 --> Controller Class Initialized
INFO - 2018-04-04 22:46:52 --> Model Class Initialized
INFO - 2018-04-04 22:46:52 --> Model Class Initialized
INFO - 2018-04-04 22:46:52 --> Model Class Initialized
INFO - 2018-04-04 22:46:52 --> Model Class Initialized
INFO - 2018-04-04 22:46:52 --> Model Class Initialized
DEBUG - 2018-04-04 22:46:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-04 22:46:52 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-04 22:46:52 --> Final output sent to browser
DEBUG - 2018-04-04 22:46:52 --> Total execution time: 0.0480
INFO - 2018-04-04 22:46:52 --> Config Class Initialized
INFO - 2018-04-04 22:46:52 --> Hooks Class Initialized
DEBUG - 2018-04-04 22:46:52 --> UTF-8 Support Enabled
INFO - 2018-04-04 22:46:52 --> Utf8 Class Initialized
INFO - 2018-04-04 22:46:52 --> URI Class Initialized
INFO - 2018-04-04 22:46:52 --> Router Class Initialized
INFO - 2018-04-04 22:46:52 --> Output Class Initialized
INFO - 2018-04-04 22:46:52 --> Security Class Initialized
DEBUG - 2018-04-04 22:46:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 22:46:52 --> Input Class Initialized
INFO - 2018-04-04 22:46:52 --> Language Class Initialized
INFO - 2018-04-04 22:46:52 --> Loader Class Initialized
INFO - 2018-04-04 22:46:52 --> Helper loaded: url_helper
INFO - 2018-04-04 22:46:52 --> Helper loaded: form_helper
INFO - 2018-04-04 22:46:52 --> Database Driver Class Initialized
DEBUG - 2018-04-04 22:46:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 22:46:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 22:46:52 --> Form Validation Class Initialized
INFO - 2018-04-04 22:46:52 --> Model Class Initialized
INFO - 2018-04-04 22:46:52 --> Controller Class Initialized
INFO - 2018-04-04 22:46:52 --> Model Class Initialized
INFO - 2018-04-04 22:46:52 --> Model Class Initialized
INFO - 2018-04-04 22:46:52 --> Model Class Initialized
INFO - 2018-04-04 22:46:52 --> Model Class Initialized
INFO - 2018-04-04 22:46:52 --> Model Class Initialized
DEBUG - 2018-04-04 22:46:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-04 22:46:59 --> Config Class Initialized
INFO - 2018-04-04 22:46:59 --> Hooks Class Initialized
DEBUG - 2018-04-04 22:46:59 --> UTF-8 Support Enabled
INFO - 2018-04-04 22:46:59 --> Utf8 Class Initialized
INFO - 2018-04-04 22:46:59 --> URI Class Initialized
INFO - 2018-04-04 22:46:59 --> Router Class Initialized
INFO - 2018-04-04 22:46:59 --> Output Class Initialized
INFO - 2018-04-04 22:46:59 --> Security Class Initialized
DEBUG - 2018-04-04 22:46:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 22:46:59 --> Input Class Initialized
INFO - 2018-04-04 22:46:59 --> Language Class Initialized
INFO - 2018-04-04 22:46:59 --> Loader Class Initialized
INFO - 2018-04-04 22:46:59 --> Helper loaded: url_helper
INFO - 2018-04-04 22:46:59 --> Helper loaded: form_helper
INFO - 2018-04-04 22:46:59 --> Database Driver Class Initialized
DEBUG - 2018-04-04 22:46:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 22:46:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 22:46:59 --> Form Validation Class Initialized
INFO - 2018-04-04 22:46:59 --> Model Class Initialized
INFO - 2018-04-04 22:46:59 --> Controller Class Initialized
INFO - 2018-04-04 22:46:59 --> Model Class Initialized
INFO - 2018-04-04 22:46:59 --> Model Class Initialized
INFO - 2018-04-04 22:46:59 --> Model Class Initialized
INFO - 2018-04-04 22:46:59 --> Model Class Initialized
INFO - 2018-04-04 22:46:59 --> Model Class Initialized
DEBUG - 2018-04-04 22:46:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-04 22:46:59 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-04 22:46:59 --> Final output sent to browser
DEBUG - 2018-04-04 22:46:59 --> Total execution time: 0.0634
INFO - 2018-04-04 22:46:59 --> Config Class Initialized
INFO - 2018-04-04 22:46:59 --> Hooks Class Initialized
DEBUG - 2018-04-04 22:46:59 --> UTF-8 Support Enabled
INFO - 2018-04-04 22:46:59 --> Utf8 Class Initialized
INFO - 2018-04-04 22:46:59 --> URI Class Initialized
INFO - 2018-04-04 22:46:59 --> Router Class Initialized
INFO - 2018-04-04 22:46:59 --> Output Class Initialized
INFO - 2018-04-04 22:46:59 --> Security Class Initialized
DEBUG - 2018-04-04 22:46:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 22:46:59 --> Input Class Initialized
INFO - 2018-04-04 22:46:59 --> Language Class Initialized
INFO - 2018-04-04 22:46:59 --> Loader Class Initialized
INFO - 2018-04-04 22:46:59 --> Helper loaded: url_helper
INFO - 2018-04-04 22:46:59 --> Helper loaded: form_helper
INFO - 2018-04-04 22:46:59 --> Database Driver Class Initialized
DEBUG - 2018-04-04 22:46:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 22:46:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 22:46:59 --> Form Validation Class Initialized
INFO - 2018-04-04 22:46:59 --> Model Class Initialized
INFO - 2018-04-04 22:46:59 --> Controller Class Initialized
INFO - 2018-04-04 22:46:59 --> Model Class Initialized
INFO - 2018-04-04 22:46:59 --> Model Class Initialized
INFO - 2018-04-04 22:46:59 --> Model Class Initialized
INFO - 2018-04-04 22:46:59 --> Model Class Initialized
INFO - 2018-04-04 22:46:59 --> Model Class Initialized
DEBUG - 2018-04-04 22:46:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-04 22:47:01 --> Config Class Initialized
INFO - 2018-04-04 22:47:01 --> Hooks Class Initialized
DEBUG - 2018-04-04 22:47:01 --> UTF-8 Support Enabled
INFO - 2018-04-04 22:47:01 --> Utf8 Class Initialized
INFO - 2018-04-04 22:47:01 --> URI Class Initialized
INFO - 2018-04-04 22:47:01 --> Router Class Initialized
INFO - 2018-04-04 22:47:01 --> Output Class Initialized
INFO - 2018-04-04 22:47:01 --> Security Class Initialized
DEBUG - 2018-04-04 22:47:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 22:47:01 --> Input Class Initialized
INFO - 2018-04-04 22:47:01 --> Language Class Initialized
INFO - 2018-04-04 22:47:01 --> Loader Class Initialized
INFO - 2018-04-04 22:47:01 --> Helper loaded: url_helper
INFO - 2018-04-04 22:47:01 --> Helper loaded: form_helper
INFO - 2018-04-04 22:47:01 --> Database Driver Class Initialized
DEBUG - 2018-04-04 22:47:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 22:47:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 22:47:01 --> Form Validation Class Initialized
INFO - 2018-04-04 22:47:01 --> Model Class Initialized
INFO - 2018-04-04 22:47:01 --> Controller Class Initialized
INFO - 2018-04-04 22:47:01 --> Model Class Initialized
INFO - 2018-04-04 22:47:01 --> Model Class Initialized
INFO - 2018-04-04 22:47:01 --> Model Class Initialized
INFO - 2018-04-04 22:47:01 --> Model Class Initialized
INFO - 2018-04-04 22:47:01 --> Model Class Initialized
DEBUG - 2018-04-04 22:47:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-04 22:47:02 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-04-04 22:47:02 --> Final output sent to browser
DEBUG - 2018-04-04 22:47:02 --> Total execution time: 0.0767
INFO - 2018-04-04 22:47:02 --> Config Class Initialized
INFO - 2018-04-04 22:47:02 --> Hooks Class Initialized
DEBUG - 2018-04-04 22:47:02 --> UTF-8 Support Enabled
INFO - 2018-04-04 22:47:02 --> Utf8 Class Initialized
INFO - 2018-04-04 22:47:02 --> URI Class Initialized
INFO - 2018-04-04 22:47:02 --> Router Class Initialized
INFO - 2018-04-04 22:47:02 --> Output Class Initialized
INFO - 2018-04-04 22:47:02 --> Security Class Initialized
DEBUG - 2018-04-04 22:47:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 22:47:02 --> Input Class Initialized
INFO - 2018-04-04 22:47:02 --> Language Class Initialized
INFO - 2018-04-04 22:47:02 --> Loader Class Initialized
INFO - 2018-04-04 22:47:02 --> Helper loaded: url_helper
INFO - 2018-04-04 22:47:02 --> Helper loaded: form_helper
INFO - 2018-04-04 22:47:02 --> Database Driver Class Initialized
DEBUG - 2018-04-04 22:47:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 22:47:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 22:47:02 --> Form Validation Class Initialized
INFO - 2018-04-04 22:47:02 --> Model Class Initialized
INFO - 2018-04-04 22:47:02 --> Controller Class Initialized
INFO - 2018-04-04 22:47:02 --> Model Class Initialized
INFO - 2018-04-04 22:47:02 --> Model Class Initialized
INFO - 2018-04-04 22:47:02 --> Model Class Initialized
INFO - 2018-04-04 22:47:02 --> Model Class Initialized
INFO - 2018-04-04 22:47:02 --> Model Class Initialized
DEBUG - 2018-04-04 22:47:02 --> Form_validation class already loaded. Second attempt ignored.
