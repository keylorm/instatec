<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-02-10 18:48:13 --> Config Class Initialized
INFO - 2018-02-10 18:48:13 --> Hooks Class Initialized
DEBUG - 2018-02-10 18:48:13 --> UTF-8 Support Enabled
INFO - 2018-02-10 18:48:13 --> Utf8 Class Initialized
INFO - 2018-02-10 18:48:13 --> URI Class Initialized
INFO - 2018-02-10 18:48:13 --> Router Class Initialized
INFO - 2018-02-10 18:48:13 --> Output Class Initialized
INFO - 2018-02-10 18:48:13 --> Security Class Initialized
DEBUG - 2018-02-10 18:48:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 18:48:13 --> Input Class Initialized
INFO - 2018-02-10 18:48:14 --> Language Class Initialized
INFO - 2018-02-10 18:48:14 --> Loader Class Initialized
INFO - 2018-02-10 18:48:14 --> Helper loaded: url_helper
INFO - 2018-02-10 18:48:14 --> Helper loaded: form_helper
INFO - 2018-02-10 18:48:14 --> Database Driver Class Initialized
DEBUG - 2018-02-10 18:48:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 18:48:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 18:48:14 --> Form Validation Class Initialized
INFO - 2018-02-10 18:48:14 --> Model Class Initialized
INFO - 2018-02-10 18:48:14 --> Controller Class Initialized
INFO - 2018-02-10 18:48:14 --> Model Class Initialized
DEBUG - 2018-02-10 18:48:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 18:48:14 --> Config Class Initialized
INFO - 2018-02-10 18:48:14 --> Hooks Class Initialized
DEBUG - 2018-02-10 18:48:14 --> UTF-8 Support Enabled
INFO - 2018-02-10 18:48:14 --> Utf8 Class Initialized
INFO - 2018-02-10 18:48:14 --> URI Class Initialized
INFO - 2018-02-10 18:48:14 --> Router Class Initialized
INFO - 2018-02-10 18:48:14 --> Output Class Initialized
INFO - 2018-02-10 18:48:14 --> Security Class Initialized
DEBUG - 2018-02-10 18:48:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 18:48:14 --> Input Class Initialized
INFO - 2018-02-10 18:48:14 --> Language Class Initialized
INFO - 2018-02-10 18:48:14 --> Loader Class Initialized
INFO - 2018-02-10 18:48:14 --> Helper loaded: url_helper
INFO - 2018-02-10 18:48:14 --> Helper loaded: form_helper
INFO - 2018-02-10 18:48:14 --> Database Driver Class Initialized
DEBUG - 2018-02-10 18:48:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 18:48:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 18:48:14 --> Form Validation Class Initialized
INFO - 2018-02-10 18:48:14 --> Model Class Initialized
INFO - 2018-02-10 18:48:14 --> Controller Class Initialized
INFO - 2018-02-10 18:48:14 --> Model Class Initialized
DEBUG - 2018-02-10 18:48:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 18:48:14 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 18:48:14 --> Final output sent to browser
DEBUG - 2018-02-10 18:48:14 --> Total execution time: 0.2364
INFO - 2018-02-10 18:48:16 --> Config Class Initialized
INFO - 2018-02-10 18:48:16 --> Hooks Class Initialized
DEBUG - 2018-02-10 18:48:16 --> UTF-8 Support Enabled
INFO - 2018-02-10 18:48:16 --> Utf8 Class Initialized
INFO - 2018-02-10 18:48:16 --> URI Class Initialized
INFO - 2018-02-10 18:48:16 --> Router Class Initialized
INFO - 2018-02-10 18:48:16 --> Output Class Initialized
INFO - 2018-02-10 18:48:16 --> Security Class Initialized
DEBUG - 2018-02-10 18:48:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 18:48:16 --> Input Class Initialized
INFO - 2018-02-10 18:48:16 --> Language Class Initialized
INFO - 2018-02-10 18:48:16 --> Loader Class Initialized
INFO - 2018-02-10 18:48:16 --> Helper loaded: url_helper
INFO - 2018-02-10 18:48:16 --> Helper loaded: form_helper
INFO - 2018-02-10 18:48:16 --> Database Driver Class Initialized
DEBUG - 2018-02-10 18:48:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 18:48:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 18:48:16 --> Form Validation Class Initialized
INFO - 2018-02-10 18:48:16 --> Model Class Initialized
INFO - 2018-02-10 18:48:16 --> Controller Class Initialized
INFO - 2018-02-10 18:48:16 --> Model Class Initialized
DEBUG - 2018-02-10 18:48:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 18:48:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-10 18:48:16 --> Config Class Initialized
INFO - 2018-02-10 18:48:16 --> Hooks Class Initialized
DEBUG - 2018-02-10 18:48:16 --> UTF-8 Support Enabled
INFO - 2018-02-10 18:48:16 --> Utf8 Class Initialized
INFO - 2018-02-10 18:48:16 --> URI Class Initialized
DEBUG - 2018-02-10 18:48:16 --> No URI present. Default controller set.
INFO - 2018-02-10 18:48:16 --> Router Class Initialized
INFO - 2018-02-10 18:48:16 --> Output Class Initialized
INFO - 2018-02-10 18:48:16 --> Security Class Initialized
DEBUG - 2018-02-10 18:48:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 18:48:16 --> Input Class Initialized
INFO - 2018-02-10 18:48:16 --> Language Class Initialized
INFO - 2018-02-10 18:48:16 --> Loader Class Initialized
INFO - 2018-02-10 18:48:16 --> Helper loaded: url_helper
INFO - 2018-02-10 18:48:16 --> Helper loaded: form_helper
INFO - 2018-02-10 18:48:16 --> Database Driver Class Initialized
DEBUG - 2018-02-10 18:48:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 18:48:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 18:48:16 --> Form Validation Class Initialized
INFO - 2018-02-10 18:48:16 --> Model Class Initialized
INFO - 2018-02-10 18:48:16 --> Controller Class Initialized
INFO - 2018-02-10 18:48:16 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 18:48:16 --> Final output sent to browser
DEBUG - 2018-02-10 18:48:16 --> Total execution time: 0.1378
INFO - 2018-02-10 18:48:16 --> Config Class Initialized
INFO - 2018-02-10 18:48:16 --> Hooks Class Initialized
DEBUG - 2018-02-10 18:48:16 --> UTF-8 Support Enabled
INFO - 2018-02-10 18:48:16 --> Utf8 Class Initialized
INFO - 2018-02-10 18:48:16 --> URI Class Initialized
INFO - 2018-02-10 18:48:16 --> Router Class Initialized
INFO - 2018-02-10 18:48:16 --> Output Class Initialized
INFO - 2018-02-10 18:48:16 --> Security Class Initialized
DEBUG - 2018-02-10 18:48:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 18:48:16 --> Input Class Initialized
INFO - 2018-02-10 18:48:16 --> Language Class Initialized
INFO - 2018-02-10 18:48:17 --> Loader Class Initialized
INFO - 2018-02-10 18:48:17 --> Helper loaded: url_helper
INFO - 2018-02-10 18:48:17 --> Helper loaded: form_helper
INFO - 2018-02-10 18:48:17 --> Database Driver Class Initialized
DEBUG - 2018-02-10 18:48:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 18:48:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 18:48:17 --> Form Validation Class Initialized
INFO - 2018-02-10 18:48:17 --> Model Class Initialized
INFO - 2018-02-10 18:48:17 --> Controller Class Initialized
INFO - 2018-02-10 18:48:17 --> Model Class Initialized
INFO - 2018-02-10 18:48:17 --> Model Class Initialized
INFO - 2018-02-10 18:48:17 --> Model Class Initialized
INFO - 2018-02-10 18:48:17 --> Model Class Initialized
DEBUG - 2018-02-10 18:48:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 18:48:20 --> Config Class Initialized
INFO - 2018-02-10 18:48:20 --> Hooks Class Initialized
DEBUG - 2018-02-10 18:48:20 --> UTF-8 Support Enabled
INFO - 2018-02-10 18:48:20 --> Utf8 Class Initialized
INFO - 2018-02-10 18:48:20 --> URI Class Initialized
INFO - 2018-02-10 18:48:20 --> Router Class Initialized
INFO - 2018-02-10 18:48:20 --> Output Class Initialized
INFO - 2018-02-10 18:48:20 --> Security Class Initialized
DEBUG - 2018-02-10 18:48:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 18:48:20 --> Input Class Initialized
INFO - 2018-02-10 18:48:20 --> Language Class Initialized
INFO - 2018-02-10 18:48:20 --> Loader Class Initialized
INFO - 2018-02-10 18:48:20 --> Helper loaded: url_helper
INFO - 2018-02-10 18:48:20 --> Helper loaded: form_helper
INFO - 2018-02-10 18:48:20 --> Database Driver Class Initialized
DEBUG - 2018-02-10 18:48:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 18:48:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 18:48:20 --> Form Validation Class Initialized
INFO - 2018-02-10 18:48:20 --> Model Class Initialized
INFO - 2018-02-10 18:48:20 --> Controller Class Initialized
INFO - 2018-02-10 18:48:20 --> Model Class Initialized
DEBUG - 2018-02-10 18:48:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 18:48:20 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 18:48:20 --> Final output sent to browser
DEBUG - 2018-02-10 18:48:20 --> Total execution time: 0.1469
INFO - 2018-02-10 18:48:20 --> Config Class Initialized
INFO - 2018-02-10 18:48:20 --> Hooks Class Initialized
DEBUG - 2018-02-10 18:48:20 --> UTF-8 Support Enabled
INFO - 2018-02-10 18:48:20 --> Utf8 Class Initialized
INFO - 2018-02-10 18:48:20 --> URI Class Initialized
INFO - 2018-02-10 18:48:20 --> Router Class Initialized
INFO - 2018-02-10 18:48:20 --> Output Class Initialized
INFO - 2018-02-10 18:48:20 --> Security Class Initialized
DEBUG - 2018-02-10 18:48:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 18:48:20 --> Input Class Initialized
INFO - 2018-02-10 18:48:20 --> Language Class Initialized
INFO - 2018-02-10 18:48:20 --> Loader Class Initialized
INFO - 2018-02-10 18:48:20 --> Helper loaded: url_helper
INFO - 2018-02-10 18:48:20 --> Helper loaded: form_helper
INFO - 2018-02-10 18:48:20 --> Database Driver Class Initialized
DEBUG - 2018-02-10 18:48:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 18:48:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 18:48:20 --> Form Validation Class Initialized
INFO - 2018-02-10 18:48:20 --> Model Class Initialized
INFO - 2018-02-10 18:48:20 --> Controller Class Initialized
INFO - 2018-02-10 18:48:20 --> Model Class Initialized
DEBUG - 2018-02-10 18:48:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 18:48:22 --> Config Class Initialized
INFO - 2018-02-10 18:48:22 --> Hooks Class Initialized
DEBUG - 2018-02-10 18:48:22 --> UTF-8 Support Enabled
INFO - 2018-02-10 18:48:22 --> Utf8 Class Initialized
INFO - 2018-02-10 18:48:22 --> URI Class Initialized
INFO - 2018-02-10 18:48:22 --> Router Class Initialized
INFO - 2018-02-10 18:48:22 --> Output Class Initialized
INFO - 2018-02-10 18:48:22 --> Security Class Initialized
DEBUG - 2018-02-10 18:48:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 18:48:22 --> Input Class Initialized
INFO - 2018-02-10 18:48:22 --> Language Class Initialized
INFO - 2018-02-10 18:48:22 --> Loader Class Initialized
INFO - 2018-02-10 18:48:22 --> Helper loaded: url_helper
INFO - 2018-02-10 18:48:22 --> Helper loaded: form_helper
INFO - 2018-02-10 18:48:22 --> Database Driver Class Initialized
DEBUG - 2018-02-10 18:48:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 18:48:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 18:48:22 --> Form Validation Class Initialized
INFO - 2018-02-10 18:48:22 --> Model Class Initialized
INFO - 2018-02-10 18:48:22 --> Controller Class Initialized
INFO - 2018-02-10 18:48:22 --> Model Class Initialized
DEBUG - 2018-02-10 18:48:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 18:48:25 --> Config Class Initialized
INFO - 2018-02-10 18:48:25 --> Hooks Class Initialized
DEBUG - 2018-02-10 18:48:25 --> UTF-8 Support Enabled
INFO - 2018-02-10 18:48:25 --> Utf8 Class Initialized
INFO - 2018-02-10 18:48:25 --> URI Class Initialized
INFO - 2018-02-10 18:48:25 --> Router Class Initialized
INFO - 2018-02-10 18:48:25 --> Output Class Initialized
INFO - 2018-02-10 18:48:25 --> Security Class Initialized
DEBUG - 2018-02-10 18:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 18:48:25 --> Input Class Initialized
INFO - 2018-02-10 18:48:25 --> Language Class Initialized
INFO - 2018-02-10 18:48:25 --> Loader Class Initialized
INFO - 2018-02-10 18:48:25 --> Helper loaded: url_helper
INFO - 2018-02-10 18:48:25 --> Helper loaded: form_helper
INFO - 2018-02-10 18:48:25 --> Database Driver Class Initialized
DEBUG - 2018-02-10 18:48:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 18:48:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 18:48:25 --> Form Validation Class Initialized
INFO - 2018-02-10 18:48:25 --> Model Class Initialized
INFO - 2018-02-10 18:48:25 --> Controller Class Initialized
INFO - 2018-02-10 18:48:25 --> Model Class Initialized
DEBUG - 2018-02-10 18:48:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 18:48:25 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 18:48:25 --> Final output sent to browser
DEBUG - 2018-02-10 18:48:25 --> Total execution time: 0.1545
INFO - 2018-02-10 18:48:26 --> Config Class Initialized
INFO - 2018-02-10 18:48:26 --> Hooks Class Initialized
DEBUG - 2018-02-10 18:48:26 --> UTF-8 Support Enabled
INFO - 2018-02-10 18:48:26 --> Utf8 Class Initialized
INFO - 2018-02-10 18:48:26 --> URI Class Initialized
INFO - 2018-02-10 18:48:26 --> Router Class Initialized
INFO - 2018-02-10 18:48:26 --> Output Class Initialized
INFO - 2018-02-10 18:48:26 --> Security Class Initialized
DEBUG - 2018-02-10 18:48:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 18:48:26 --> Input Class Initialized
INFO - 2018-02-10 18:48:26 --> Language Class Initialized
INFO - 2018-02-10 18:48:26 --> Loader Class Initialized
INFO - 2018-02-10 18:48:26 --> Helper loaded: url_helper
INFO - 2018-02-10 18:48:26 --> Helper loaded: form_helper
INFO - 2018-02-10 18:48:26 --> Database Driver Class Initialized
DEBUG - 2018-02-10 18:48:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 18:48:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 18:48:26 --> Form Validation Class Initialized
INFO - 2018-02-10 18:48:26 --> Model Class Initialized
INFO - 2018-02-10 18:48:26 --> Controller Class Initialized
INFO - 2018-02-10 18:48:26 --> Model Class Initialized
DEBUG - 2018-02-10 18:48:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 18:48:28 --> Config Class Initialized
INFO - 2018-02-10 18:48:28 --> Hooks Class Initialized
DEBUG - 2018-02-10 18:48:28 --> UTF-8 Support Enabled
INFO - 2018-02-10 18:48:28 --> Utf8 Class Initialized
INFO - 2018-02-10 18:48:28 --> URI Class Initialized
INFO - 2018-02-10 18:48:28 --> Router Class Initialized
INFO - 2018-02-10 18:48:28 --> Output Class Initialized
INFO - 2018-02-10 18:48:28 --> Security Class Initialized
DEBUG - 2018-02-10 18:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 18:48:28 --> Input Class Initialized
INFO - 2018-02-10 18:48:28 --> Language Class Initialized
INFO - 2018-02-10 18:48:28 --> Loader Class Initialized
INFO - 2018-02-10 18:48:28 --> Helper loaded: url_helper
INFO - 2018-02-10 18:48:28 --> Helper loaded: form_helper
INFO - 2018-02-10 18:48:28 --> Database Driver Class Initialized
DEBUG - 2018-02-10 18:48:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 18:48:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 18:48:28 --> Form Validation Class Initialized
INFO - 2018-02-10 18:48:28 --> Model Class Initialized
INFO - 2018-02-10 18:48:28 --> Controller Class Initialized
INFO - 2018-02-10 18:48:28 --> Model Class Initialized
DEBUG - 2018-02-10 18:48:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 18:49:05 --> Config Class Initialized
INFO - 2018-02-10 18:49:05 --> Hooks Class Initialized
DEBUG - 2018-02-10 18:49:05 --> UTF-8 Support Enabled
INFO - 2018-02-10 18:49:05 --> Utf8 Class Initialized
INFO - 2018-02-10 18:49:05 --> URI Class Initialized
INFO - 2018-02-10 18:49:05 --> Router Class Initialized
INFO - 2018-02-10 18:49:05 --> Output Class Initialized
INFO - 2018-02-10 18:49:05 --> Security Class Initialized
DEBUG - 2018-02-10 18:49:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 18:49:05 --> Input Class Initialized
INFO - 2018-02-10 18:49:05 --> Language Class Initialized
INFO - 2018-02-10 18:49:05 --> Loader Class Initialized
INFO - 2018-02-10 18:49:05 --> Helper loaded: url_helper
INFO - 2018-02-10 18:49:05 --> Helper loaded: form_helper
INFO - 2018-02-10 18:49:05 --> Database Driver Class Initialized
DEBUG - 2018-02-10 18:49:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 18:49:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 18:49:05 --> Form Validation Class Initialized
INFO - 2018-02-10 18:49:05 --> Model Class Initialized
INFO - 2018-02-10 18:49:05 --> Controller Class Initialized
INFO - 2018-02-10 18:49:05 --> Model Class Initialized
DEBUG - 2018-02-10 18:49:05 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-10 18:49:05 --> Severity: Notice --> Undefined variable: vrow D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\usuario\agregarUsuario.php 94
ERROR - 2018-02-10 18:49:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\usuario\agregarUsuario.php 94
ERROR - 2018-02-10 18:49:05 --> Severity: Notice --> Undefined variable: vrow D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\usuario\agregarUsuario.php 94
ERROR - 2018-02-10 18:49:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\usuario\agregarUsuario.php 94
ERROR - 2018-02-10 18:49:05 --> Severity: Notice --> Undefined variable: vrow D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\usuario\agregarUsuario.php 94
ERROR - 2018-02-10 18:49:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\usuario\agregarUsuario.php 94
INFO - 2018-02-10 18:49:05 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 18:49:05 --> Final output sent to browser
DEBUG - 2018-02-10 18:49:05 --> Total execution time: 0.1411
INFO - 2018-02-10 18:49:46 --> Config Class Initialized
INFO - 2018-02-10 18:49:46 --> Hooks Class Initialized
DEBUG - 2018-02-10 18:49:46 --> UTF-8 Support Enabled
INFO - 2018-02-10 18:49:46 --> Utf8 Class Initialized
INFO - 2018-02-10 18:49:46 --> URI Class Initialized
INFO - 2018-02-10 18:49:46 --> Router Class Initialized
INFO - 2018-02-10 18:49:46 --> Output Class Initialized
INFO - 2018-02-10 18:49:46 --> Security Class Initialized
DEBUG - 2018-02-10 18:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 18:49:46 --> Input Class Initialized
INFO - 2018-02-10 18:49:46 --> Language Class Initialized
INFO - 2018-02-10 18:49:46 --> Loader Class Initialized
INFO - 2018-02-10 18:49:46 --> Helper loaded: url_helper
INFO - 2018-02-10 18:49:46 --> Helper loaded: form_helper
INFO - 2018-02-10 18:49:46 --> Database Driver Class Initialized
DEBUG - 2018-02-10 18:49:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 18:49:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 18:49:46 --> Form Validation Class Initialized
INFO - 2018-02-10 18:49:46 --> Model Class Initialized
INFO - 2018-02-10 18:49:46 --> Controller Class Initialized
INFO - 2018-02-10 18:49:46 --> Model Class Initialized
DEBUG - 2018-02-10 18:49:46 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-10 18:49:46 --> Severity: Notice --> Undefined variable: vrow D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\usuario\agregarUsuario.php 94
ERROR - 2018-02-10 18:49:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\usuario\agregarUsuario.php 94
ERROR - 2018-02-10 18:49:46 --> Severity: Notice --> Undefined variable: vrow D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\usuario\agregarUsuario.php 94
ERROR - 2018-02-10 18:49:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\usuario\agregarUsuario.php 94
ERROR - 2018-02-10 18:49:46 --> Severity: Notice --> Undefined variable: vrow D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\usuario\agregarUsuario.php 94
ERROR - 2018-02-10 18:49:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\usuario\agregarUsuario.php 94
INFO - 2018-02-10 18:49:46 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 18:49:46 --> Final output sent to browser
DEBUG - 2018-02-10 18:49:46 --> Total execution time: 0.0808
INFO - 2018-02-10 18:50:10 --> Config Class Initialized
INFO - 2018-02-10 18:50:10 --> Hooks Class Initialized
DEBUG - 2018-02-10 18:50:10 --> UTF-8 Support Enabled
INFO - 2018-02-10 18:50:10 --> Utf8 Class Initialized
INFO - 2018-02-10 18:50:10 --> URI Class Initialized
INFO - 2018-02-10 18:50:10 --> Router Class Initialized
INFO - 2018-02-10 18:50:10 --> Output Class Initialized
INFO - 2018-02-10 18:50:10 --> Security Class Initialized
DEBUG - 2018-02-10 18:50:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 18:50:10 --> Input Class Initialized
INFO - 2018-02-10 18:50:10 --> Language Class Initialized
INFO - 2018-02-10 18:50:10 --> Loader Class Initialized
INFO - 2018-02-10 18:50:10 --> Helper loaded: url_helper
INFO - 2018-02-10 18:50:10 --> Helper loaded: form_helper
INFO - 2018-02-10 18:50:10 --> Database Driver Class Initialized
DEBUG - 2018-02-10 18:50:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 18:50:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 18:50:10 --> Form Validation Class Initialized
INFO - 2018-02-10 18:50:10 --> Model Class Initialized
INFO - 2018-02-10 18:50:10 --> Controller Class Initialized
INFO - 2018-02-10 18:50:10 --> Model Class Initialized
DEBUG - 2018-02-10 18:50:10 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-10 18:50:10 --> Severity: Notice --> Undefined variable: vrow D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\usuario\agregarUsuario.php 94
ERROR - 2018-02-10 18:50:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\usuario\agregarUsuario.php 94
ERROR - 2018-02-10 18:50:10 --> Severity: Notice --> Undefined variable: vrow D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\usuario\agregarUsuario.php 94
ERROR - 2018-02-10 18:50:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\usuario\agregarUsuario.php 94
ERROR - 2018-02-10 18:50:10 --> Severity: Notice --> Undefined variable: vrow D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\usuario\agregarUsuario.php 94
ERROR - 2018-02-10 18:50:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\usuario\agregarUsuario.php 94
INFO - 2018-02-10 18:50:10 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 18:50:10 --> Final output sent to browser
DEBUG - 2018-02-10 18:50:10 --> Total execution time: 0.0788
INFO - 2018-02-10 18:50:13 --> Config Class Initialized
INFO - 2018-02-10 18:50:13 --> Hooks Class Initialized
INFO - 2018-02-10 18:50:13 --> Config Class Initialized
INFO - 2018-02-10 18:50:13 --> Hooks Class Initialized
INFO - 2018-02-10 18:50:13 --> Config Class Initialized
INFO - 2018-02-10 18:50:13 --> Hooks Class Initialized
DEBUG - 2018-02-10 18:50:13 --> UTF-8 Support Enabled
INFO - 2018-02-10 18:50:13 --> Utf8 Class Initialized
DEBUG - 2018-02-10 18:50:13 --> UTF-8 Support Enabled
INFO - 2018-02-10 18:50:13 --> Utf8 Class Initialized
INFO - 2018-02-10 18:50:13 --> Config Class Initialized
INFO - 2018-02-10 18:50:13 --> URI Class Initialized
INFO - 2018-02-10 18:50:13 --> Hooks Class Initialized
INFO - 2018-02-10 18:50:13 --> URI Class Initialized
INFO - 2018-02-10 18:50:13 --> Router Class Initialized
DEBUG - 2018-02-10 18:50:13 --> UTF-8 Support Enabled
INFO - 2018-02-10 18:50:13 --> Utf8 Class Initialized
INFO - 2018-02-10 18:50:13 --> Router Class Initialized
DEBUG - 2018-02-10 18:50:13 --> UTF-8 Support Enabled
INFO - 2018-02-10 18:50:13 --> URI Class Initialized
INFO - 2018-02-10 18:50:13 --> Output Class Initialized
INFO - 2018-02-10 18:50:13 --> Utf8 Class Initialized
INFO - 2018-02-10 18:50:13 --> Output Class Initialized
INFO - 2018-02-10 18:50:13 --> URI Class Initialized
INFO - 2018-02-10 18:50:13 --> Security Class Initialized
INFO - 2018-02-10 18:50:13 --> Router Class Initialized
INFO - 2018-02-10 18:50:13 --> Security Class Initialized
INFO - 2018-02-10 18:50:13 --> Router Class Initialized
DEBUG - 2018-02-10 18:50:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 18:50:13 --> Input Class Initialized
DEBUG - 2018-02-10 18:50:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 18:50:13 --> Input Class Initialized
INFO - 2018-02-10 18:50:13 --> Output Class Initialized
INFO - 2018-02-10 18:50:13 --> Language Class Initialized
INFO - 2018-02-10 18:50:13 --> Output Class Initialized
INFO - 2018-02-10 18:50:13 --> Language Class Initialized
INFO - 2018-02-10 18:50:13 --> Security Class Initialized
ERROR - 2018-02-10 18:50:13 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-10 18:50:13 --> Security Class Initialized
ERROR - 2018-02-10 18:50:13 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-02-10 18:50:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 18:50:13 --> Input Class Initialized
DEBUG - 2018-02-10 18:50:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 18:50:13 --> Input Class Initialized
INFO - 2018-02-10 18:50:13 --> Language Class Initialized
INFO - 2018-02-10 18:50:13 --> Language Class Initialized
ERROR - 2018-02-10 18:50:13 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-10 18:50:13 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-10 18:50:13 --> Config Class Initialized
INFO - 2018-02-10 18:50:13 --> Hooks Class Initialized
INFO - 2018-02-10 18:50:13 --> Config Class Initialized
INFO - 2018-02-10 18:50:13 --> Hooks Class Initialized
DEBUG - 2018-02-10 18:50:13 --> UTF-8 Support Enabled
INFO - 2018-02-10 18:50:13 --> Utf8 Class Initialized
DEBUG - 2018-02-10 18:50:13 --> UTF-8 Support Enabled
INFO - 2018-02-10 18:50:13 --> Utf8 Class Initialized
INFO - 2018-02-10 18:50:13 --> URI Class Initialized
INFO - 2018-02-10 18:50:13 --> URI Class Initialized
INFO - 2018-02-10 18:50:13 --> Router Class Initialized
INFO - 2018-02-10 18:50:13 --> Config Class Initialized
INFO - 2018-02-10 18:50:13 --> Router Class Initialized
INFO - 2018-02-10 18:50:13 --> Hooks Class Initialized
INFO - 2018-02-10 18:50:13 --> Output Class Initialized
INFO - 2018-02-10 18:50:13 --> Output Class Initialized
INFO - 2018-02-10 18:50:13 --> Security Class Initialized
DEBUG - 2018-02-10 18:50:13 --> UTF-8 Support Enabled
INFO - 2018-02-10 18:50:13 --> Security Class Initialized
INFO - 2018-02-10 18:50:13 --> Utf8 Class Initialized
DEBUG - 2018-02-10 18:50:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 18:50:13 --> Input Class Initialized
INFO - 2018-02-10 18:50:13 --> URI Class Initialized
DEBUG - 2018-02-10 18:50:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 18:50:13 --> Language Class Initialized
INFO - 2018-02-10 18:50:13 --> Input Class Initialized
INFO - 2018-02-10 18:50:13 --> Language Class Initialized
ERROR - 2018-02-10 18:50:13 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-10 18:50:13 --> Router Class Initialized
ERROR - 2018-02-10 18:50:13 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-10 18:50:13 --> Output Class Initialized
INFO - 2018-02-10 18:50:13 --> Security Class Initialized
DEBUG - 2018-02-10 18:50:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 18:50:13 --> Input Class Initialized
INFO - 2018-02-10 18:50:13 --> Language Class Initialized
ERROR - 2018-02-10 18:50:13 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-10 18:50:26 --> Config Class Initialized
INFO - 2018-02-10 18:50:26 --> Hooks Class Initialized
DEBUG - 2018-02-10 18:50:26 --> UTF-8 Support Enabled
INFO - 2018-02-10 18:50:26 --> Utf8 Class Initialized
INFO - 2018-02-10 18:50:26 --> URI Class Initialized
INFO - 2018-02-10 18:50:26 --> Router Class Initialized
INFO - 2018-02-10 18:50:26 --> Output Class Initialized
INFO - 2018-02-10 18:50:26 --> Security Class Initialized
DEBUG - 2018-02-10 18:50:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 18:50:26 --> Input Class Initialized
INFO - 2018-02-10 18:50:26 --> Language Class Initialized
INFO - 2018-02-10 18:50:26 --> Loader Class Initialized
INFO - 2018-02-10 18:50:26 --> Helper loaded: url_helper
INFO - 2018-02-10 18:50:26 --> Helper loaded: form_helper
INFO - 2018-02-10 18:50:26 --> Database Driver Class Initialized
DEBUG - 2018-02-10 18:50:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 18:50:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 18:50:26 --> Form Validation Class Initialized
INFO - 2018-02-10 18:50:26 --> Model Class Initialized
INFO - 2018-02-10 18:50:26 --> Controller Class Initialized
INFO - 2018-02-10 18:50:26 --> Model Class Initialized
DEBUG - 2018-02-10 18:50:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 18:50:26 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 18:50:26 --> Final output sent to browser
DEBUG - 2018-02-10 18:50:26 --> Total execution time: 0.0542
INFO - 2018-02-10 18:50:27 --> Config Class Initialized
INFO - 2018-02-10 18:50:27 --> Hooks Class Initialized
INFO - 2018-02-10 18:50:27 --> Config Class Initialized
INFO - 2018-02-10 18:50:27 --> Hooks Class Initialized
DEBUG - 2018-02-10 18:50:27 --> UTF-8 Support Enabled
INFO - 2018-02-10 18:50:27 --> Utf8 Class Initialized
DEBUG - 2018-02-10 18:50:27 --> UTF-8 Support Enabled
INFO - 2018-02-10 18:50:27 --> Config Class Initialized
INFO - 2018-02-10 18:50:27 --> Utf8 Class Initialized
INFO - 2018-02-10 18:50:27 --> Hooks Class Initialized
INFO - 2018-02-10 18:50:27 --> Config Class Initialized
INFO - 2018-02-10 18:50:27 --> URI Class Initialized
INFO - 2018-02-10 18:50:27 --> Hooks Class Initialized
INFO - 2018-02-10 18:50:27 --> URI Class Initialized
INFO - 2018-02-10 18:50:27 --> Router Class Initialized
INFO - 2018-02-10 18:50:27 --> Router Class Initialized
DEBUG - 2018-02-10 18:50:27 --> UTF-8 Support Enabled
DEBUG - 2018-02-10 18:50:27 --> UTF-8 Support Enabled
INFO - 2018-02-10 18:50:27 --> Utf8 Class Initialized
INFO - 2018-02-10 18:50:27 --> Utf8 Class Initialized
INFO - 2018-02-10 18:50:27 --> Output Class Initialized
INFO - 2018-02-10 18:50:27 --> URI Class Initialized
INFO - 2018-02-10 18:50:27 --> URI Class Initialized
INFO - 2018-02-10 18:50:27 --> Output Class Initialized
INFO - 2018-02-10 18:50:27 --> Security Class Initialized
INFO - 2018-02-10 18:50:27 --> Router Class Initialized
INFO - 2018-02-10 18:50:27 --> Security Class Initialized
INFO - 2018-02-10 18:50:27 --> Router Class Initialized
DEBUG - 2018-02-10 18:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 18:50:27 --> Input Class Initialized
DEBUG - 2018-02-10 18:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 18:50:27 --> Input Class Initialized
INFO - 2018-02-10 18:50:27 --> Output Class Initialized
INFO - 2018-02-10 18:50:27 --> Language Class Initialized
INFO - 2018-02-10 18:50:27 --> Output Class Initialized
INFO - 2018-02-10 18:50:27 --> Language Class Initialized
INFO - 2018-02-10 18:50:27 --> Security Class Initialized
ERROR - 2018-02-10 18:50:27 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-10 18:50:27 --> Security Class Initialized
ERROR - 2018-02-10 18:50:27 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-02-10 18:50:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-10 18:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 18:50:27 --> Input Class Initialized
INFO - 2018-02-10 18:50:27 --> Input Class Initialized
INFO - 2018-02-10 18:50:27 --> Language Class Initialized
INFO - 2018-02-10 18:50:27 --> Language Class Initialized
ERROR - 2018-02-10 18:50:27 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-10 18:50:27 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-10 18:50:27 --> Config Class Initialized
INFO - 2018-02-10 18:50:27 --> Hooks Class Initialized
INFO - 2018-02-10 18:50:27 --> Config Class Initialized
INFO - 2018-02-10 18:50:27 --> Config Class Initialized
INFO - 2018-02-10 18:50:27 --> Hooks Class Initialized
INFO - 2018-02-10 18:50:27 --> Hooks Class Initialized
DEBUG - 2018-02-10 18:50:27 --> UTF-8 Support Enabled
INFO - 2018-02-10 18:50:27 --> Utf8 Class Initialized
INFO - 2018-02-10 18:50:27 --> URI Class Initialized
DEBUG - 2018-02-10 18:50:27 --> UTF-8 Support Enabled
INFO - 2018-02-10 18:50:27 --> Utf8 Class Initialized
DEBUG - 2018-02-10 18:50:27 --> UTF-8 Support Enabled
INFO - 2018-02-10 18:50:27 --> Utf8 Class Initialized
INFO - 2018-02-10 18:50:27 --> Router Class Initialized
INFO - 2018-02-10 18:50:27 --> URI Class Initialized
INFO - 2018-02-10 18:50:27 --> URI Class Initialized
INFO - 2018-02-10 18:50:27 --> Output Class Initialized
INFO - 2018-02-10 18:50:27 --> Router Class Initialized
INFO - 2018-02-10 18:50:27 --> Router Class Initialized
INFO - 2018-02-10 18:50:27 --> Security Class Initialized
INFO - 2018-02-10 18:50:27 --> Output Class Initialized
INFO - 2018-02-10 18:50:27 --> Output Class Initialized
DEBUG - 2018-02-10 18:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 18:50:27 --> Input Class Initialized
INFO - 2018-02-10 18:50:27 --> Security Class Initialized
INFO - 2018-02-10 18:50:27 --> Security Class Initialized
INFO - 2018-02-10 18:50:27 --> Language Class Initialized
DEBUG - 2018-02-10 18:50:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-10 18:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 18:50:27 --> Input Class Initialized
INFO - 2018-02-10 18:50:27 --> Input Class Initialized
ERROR - 2018-02-10 18:50:27 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-10 18:50:27 --> Language Class Initialized
INFO - 2018-02-10 18:50:27 --> Language Class Initialized
ERROR - 2018-02-10 18:50:27 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-10 18:50:27 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-10 18:51:43 --> Config Class Initialized
INFO - 2018-02-10 18:51:43 --> Hooks Class Initialized
DEBUG - 2018-02-10 18:51:43 --> UTF-8 Support Enabled
INFO - 2018-02-10 18:51:43 --> Utf8 Class Initialized
INFO - 2018-02-10 18:51:43 --> URI Class Initialized
INFO - 2018-02-10 18:51:43 --> Router Class Initialized
INFO - 2018-02-10 18:51:43 --> Output Class Initialized
INFO - 2018-02-10 18:51:43 --> Security Class Initialized
DEBUG - 2018-02-10 18:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 18:51:43 --> Input Class Initialized
INFO - 2018-02-10 18:51:43 --> Language Class Initialized
INFO - 2018-02-10 18:51:43 --> Loader Class Initialized
INFO - 2018-02-10 18:51:43 --> Helper loaded: url_helper
INFO - 2018-02-10 18:51:43 --> Helper loaded: form_helper
INFO - 2018-02-10 18:51:43 --> Database Driver Class Initialized
DEBUG - 2018-02-10 18:51:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 18:51:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 18:51:43 --> Form Validation Class Initialized
INFO - 2018-02-10 18:51:43 --> Model Class Initialized
INFO - 2018-02-10 18:51:43 --> Controller Class Initialized
INFO - 2018-02-10 18:51:43 --> Model Class Initialized
DEBUG - 2018-02-10 18:51:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 18:51:43 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 18:51:43 --> Final output sent to browser
DEBUG - 2018-02-10 18:51:43 --> Total execution time: 0.0440
INFO - 2018-02-10 18:51:43 --> Config Class Initialized
INFO - 2018-02-10 18:51:43 --> Hooks Class Initialized
DEBUG - 2018-02-10 18:51:43 --> UTF-8 Support Enabled
INFO - 2018-02-10 18:51:43 --> Utf8 Class Initialized
INFO - 2018-02-10 18:51:43 --> URI Class Initialized
INFO - 2018-02-10 18:51:43 --> Router Class Initialized
INFO - 2018-02-10 18:51:43 --> Output Class Initialized
INFO - 2018-02-10 18:51:43 --> Security Class Initialized
DEBUG - 2018-02-10 18:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 18:51:43 --> Input Class Initialized
INFO - 2018-02-10 18:51:43 --> Language Class Initialized
INFO - 2018-02-10 18:51:43 --> Loader Class Initialized
INFO - 2018-02-10 18:51:43 --> Helper loaded: url_helper
INFO - 2018-02-10 18:51:43 --> Helper loaded: form_helper
INFO - 2018-02-10 18:51:43 --> Database Driver Class Initialized
DEBUG - 2018-02-10 18:51:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 18:51:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 18:51:43 --> Form Validation Class Initialized
INFO - 2018-02-10 18:51:43 --> Model Class Initialized
INFO - 2018-02-10 18:51:43 --> Controller Class Initialized
INFO - 2018-02-10 18:51:43 --> Model Class Initialized
DEBUG - 2018-02-10 18:51:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 18:52:31 --> Config Class Initialized
INFO - 2018-02-10 18:52:31 --> Hooks Class Initialized
DEBUG - 2018-02-10 18:52:31 --> UTF-8 Support Enabled
INFO - 2018-02-10 18:52:31 --> Utf8 Class Initialized
INFO - 2018-02-10 18:52:31 --> URI Class Initialized
INFO - 2018-02-10 18:52:31 --> Router Class Initialized
INFO - 2018-02-10 18:52:31 --> Output Class Initialized
INFO - 2018-02-10 18:52:31 --> Security Class Initialized
DEBUG - 2018-02-10 18:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 18:52:31 --> Input Class Initialized
INFO - 2018-02-10 18:52:31 --> Language Class Initialized
INFO - 2018-02-10 18:52:31 --> Loader Class Initialized
INFO - 2018-02-10 18:52:31 --> Helper loaded: url_helper
INFO - 2018-02-10 18:52:31 --> Helper loaded: form_helper
INFO - 2018-02-10 18:52:31 --> Database Driver Class Initialized
DEBUG - 2018-02-10 18:52:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 18:52:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 18:52:31 --> Form Validation Class Initialized
INFO - 2018-02-10 18:52:31 --> Model Class Initialized
INFO - 2018-02-10 18:52:31 --> Controller Class Initialized
INFO - 2018-02-10 18:52:31 --> Model Class Initialized
DEBUG - 2018-02-10 18:52:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 18:52:31 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 18:52:31 --> Final output sent to browser
DEBUG - 2018-02-10 18:52:31 --> Total execution time: 0.0824
INFO - 2018-02-10 18:52:31 --> Config Class Initialized
INFO - 2018-02-10 18:52:31 --> Hooks Class Initialized
DEBUG - 2018-02-10 18:52:31 --> UTF-8 Support Enabled
INFO - 2018-02-10 18:52:31 --> Utf8 Class Initialized
INFO - 2018-02-10 18:52:31 --> URI Class Initialized
INFO - 2018-02-10 18:52:31 --> Router Class Initialized
INFO - 2018-02-10 18:52:31 --> Output Class Initialized
INFO - 2018-02-10 18:52:31 --> Security Class Initialized
DEBUG - 2018-02-10 18:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 18:52:31 --> Input Class Initialized
INFO - 2018-02-10 18:52:31 --> Language Class Initialized
INFO - 2018-02-10 18:52:31 --> Loader Class Initialized
INFO - 2018-02-10 18:52:31 --> Helper loaded: url_helper
INFO - 2018-02-10 18:52:31 --> Helper loaded: form_helper
INFO - 2018-02-10 18:52:31 --> Database Driver Class Initialized
DEBUG - 2018-02-10 18:52:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 18:52:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 18:52:31 --> Form Validation Class Initialized
INFO - 2018-02-10 18:52:31 --> Model Class Initialized
INFO - 2018-02-10 18:52:31 --> Controller Class Initialized
INFO - 2018-02-10 18:52:31 --> Model Class Initialized
DEBUG - 2018-02-10 18:52:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 18:52:34 --> Config Class Initialized
INFO - 2018-02-10 18:52:34 --> Hooks Class Initialized
DEBUG - 2018-02-10 18:52:34 --> UTF-8 Support Enabled
INFO - 2018-02-10 18:52:34 --> Utf8 Class Initialized
INFO - 2018-02-10 18:52:34 --> URI Class Initialized
INFO - 2018-02-10 18:52:34 --> Router Class Initialized
INFO - 2018-02-10 18:52:34 --> Output Class Initialized
INFO - 2018-02-10 18:52:34 --> Security Class Initialized
DEBUG - 2018-02-10 18:52:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 18:52:34 --> Input Class Initialized
INFO - 2018-02-10 18:52:34 --> Language Class Initialized
INFO - 2018-02-10 18:52:34 --> Loader Class Initialized
INFO - 2018-02-10 18:52:34 --> Helper loaded: url_helper
INFO - 2018-02-10 18:52:34 --> Helper loaded: form_helper
INFO - 2018-02-10 18:52:34 --> Database Driver Class Initialized
DEBUG - 2018-02-10 18:52:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 18:52:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 18:52:34 --> Form Validation Class Initialized
INFO - 2018-02-10 18:52:34 --> Model Class Initialized
INFO - 2018-02-10 18:52:34 --> Controller Class Initialized
INFO - 2018-02-10 18:52:34 --> Model Class Initialized
DEBUG - 2018-02-10 18:52:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 18:52:34 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 18:52:34 --> Final output sent to browser
DEBUG - 2018-02-10 18:52:34 --> Total execution time: 0.0491
INFO - 2018-02-10 18:53:06 --> Config Class Initialized
INFO - 2018-02-10 18:53:06 --> Hooks Class Initialized
DEBUG - 2018-02-10 18:53:06 --> UTF-8 Support Enabled
INFO - 2018-02-10 18:53:06 --> Utf8 Class Initialized
INFO - 2018-02-10 18:53:06 --> URI Class Initialized
INFO - 2018-02-10 18:53:06 --> Router Class Initialized
INFO - 2018-02-10 18:53:06 --> Output Class Initialized
INFO - 2018-02-10 18:53:06 --> Security Class Initialized
DEBUG - 2018-02-10 18:53:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 18:53:06 --> Input Class Initialized
INFO - 2018-02-10 18:53:06 --> Language Class Initialized
INFO - 2018-02-10 18:53:06 --> Loader Class Initialized
INFO - 2018-02-10 18:53:06 --> Helper loaded: url_helper
INFO - 2018-02-10 18:53:06 --> Helper loaded: form_helper
INFO - 2018-02-10 18:53:06 --> Database Driver Class Initialized
DEBUG - 2018-02-10 18:53:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 18:53:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 18:53:06 --> Form Validation Class Initialized
INFO - 2018-02-10 18:53:06 --> Model Class Initialized
INFO - 2018-02-10 18:53:06 --> Controller Class Initialized
INFO - 2018-02-10 18:53:06 --> Model Class Initialized
DEBUG - 2018-02-10 18:53:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 18:53:07 --> Model Class Initialized
INFO - 2018-02-10 18:53:07 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 18:53:07 --> Final output sent to browser
DEBUG - 2018-02-10 18:53:07 --> Total execution time: 0.7230
INFO - 2018-02-10 18:53:09 --> Config Class Initialized
INFO - 2018-02-10 18:53:09 --> Hooks Class Initialized
DEBUG - 2018-02-10 18:53:09 --> UTF-8 Support Enabled
INFO - 2018-02-10 18:53:09 --> Utf8 Class Initialized
INFO - 2018-02-10 18:53:09 --> URI Class Initialized
INFO - 2018-02-10 18:53:09 --> Router Class Initialized
INFO - 2018-02-10 18:53:09 --> Output Class Initialized
INFO - 2018-02-10 18:53:09 --> Security Class Initialized
DEBUG - 2018-02-10 18:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 18:53:09 --> Input Class Initialized
INFO - 2018-02-10 18:53:09 --> Language Class Initialized
INFO - 2018-02-10 18:53:09 --> Loader Class Initialized
INFO - 2018-02-10 18:53:09 --> Helper loaded: url_helper
INFO - 2018-02-10 18:53:09 --> Helper loaded: form_helper
INFO - 2018-02-10 18:53:09 --> Database Driver Class Initialized
DEBUG - 2018-02-10 18:53:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 18:53:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 18:53:09 --> Form Validation Class Initialized
INFO - 2018-02-10 18:53:09 --> Model Class Initialized
INFO - 2018-02-10 18:53:09 --> Controller Class Initialized
INFO - 2018-02-10 18:53:09 --> Model Class Initialized
DEBUG - 2018-02-10 18:53:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 18:53:09 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 18:53:09 --> Final output sent to browser
DEBUG - 2018-02-10 18:53:09 --> Total execution time: 0.0535
INFO - 2018-02-10 18:53:09 --> Config Class Initialized
INFO - 2018-02-10 18:53:09 --> Hooks Class Initialized
DEBUG - 2018-02-10 18:53:09 --> UTF-8 Support Enabled
INFO - 2018-02-10 18:53:09 --> Utf8 Class Initialized
INFO - 2018-02-10 18:53:09 --> URI Class Initialized
INFO - 2018-02-10 18:53:09 --> Router Class Initialized
INFO - 2018-02-10 18:53:09 --> Output Class Initialized
INFO - 2018-02-10 18:53:09 --> Security Class Initialized
DEBUG - 2018-02-10 18:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 18:53:09 --> Input Class Initialized
INFO - 2018-02-10 18:53:09 --> Language Class Initialized
INFO - 2018-02-10 18:53:09 --> Loader Class Initialized
INFO - 2018-02-10 18:53:09 --> Helper loaded: url_helper
INFO - 2018-02-10 18:53:09 --> Helper loaded: form_helper
INFO - 2018-02-10 18:53:09 --> Database Driver Class Initialized
DEBUG - 2018-02-10 18:53:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 18:53:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 18:53:09 --> Form Validation Class Initialized
INFO - 2018-02-10 18:53:09 --> Model Class Initialized
INFO - 2018-02-10 18:53:09 --> Controller Class Initialized
INFO - 2018-02-10 18:53:09 --> Model Class Initialized
DEBUG - 2018-02-10 18:53:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 18:53:12 --> Config Class Initialized
INFO - 2018-02-10 18:53:13 --> Hooks Class Initialized
DEBUG - 2018-02-10 18:53:13 --> UTF-8 Support Enabled
INFO - 2018-02-10 18:53:13 --> Utf8 Class Initialized
INFO - 2018-02-10 18:53:13 --> URI Class Initialized
INFO - 2018-02-10 18:53:13 --> Router Class Initialized
INFO - 2018-02-10 18:53:13 --> Output Class Initialized
INFO - 2018-02-10 18:53:13 --> Security Class Initialized
DEBUG - 2018-02-10 18:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 18:53:13 --> Input Class Initialized
INFO - 2018-02-10 18:53:13 --> Language Class Initialized
INFO - 2018-02-10 18:53:13 --> Loader Class Initialized
INFO - 2018-02-10 18:53:13 --> Helper loaded: url_helper
INFO - 2018-02-10 18:53:13 --> Helper loaded: form_helper
INFO - 2018-02-10 18:53:13 --> Database Driver Class Initialized
DEBUG - 2018-02-10 18:53:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 18:53:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 18:53:13 --> Form Validation Class Initialized
INFO - 2018-02-10 18:53:13 --> Model Class Initialized
INFO - 2018-02-10 18:53:13 --> Controller Class Initialized
INFO - 2018-02-10 18:53:13 --> Model Class Initialized
DEBUG - 2018-02-10 18:53:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 18:53:13 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 18:53:13 --> Final output sent to browser
DEBUG - 2018-02-10 18:53:13 --> Total execution time: 0.0986
INFO - 2018-02-10 18:53:13 --> Config Class Initialized
INFO - 2018-02-10 18:53:13 --> Hooks Class Initialized
DEBUG - 2018-02-10 18:53:13 --> UTF-8 Support Enabled
INFO - 2018-02-10 18:53:13 --> Utf8 Class Initialized
INFO - 2018-02-10 18:53:13 --> URI Class Initialized
INFO - 2018-02-10 18:53:13 --> Router Class Initialized
INFO - 2018-02-10 18:53:13 --> Output Class Initialized
INFO - 2018-02-10 18:53:13 --> Security Class Initialized
DEBUG - 2018-02-10 18:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 18:53:13 --> Input Class Initialized
INFO - 2018-02-10 18:53:13 --> Language Class Initialized
INFO - 2018-02-10 18:53:13 --> Loader Class Initialized
INFO - 2018-02-10 18:53:13 --> Helper loaded: url_helper
INFO - 2018-02-10 18:53:13 --> Helper loaded: form_helper
INFO - 2018-02-10 18:53:13 --> Database Driver Class Initialized
DEBUG - 2018-02-10 18:53:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 18:53:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 18:53:13 --> Form Validation Class Initialized
INFO - 2018-02-10 18:53:13 --> Model Class Initialized
INFO - 2018-02-10 18:53:13 --> Controller Class Initialized
INFO - 2018-02-10 18:53:13 --> Model Class Initialized
DEBUG - 2018-02-10 18:53:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 18:53:15 --> Config Class Initialized
INFO - 2018-02-10 18:53:15 --> Hooks Class Initialized
DEBUG - 2018-02-10 18:53:15 --> UTF-8 Support Enabled
INFO - 2018-02-10 18:53:15 --> Utf8 Class Initialized
INFO - 2018-02-10 18:53:15 --> URI Class Initialized
INFO - 2018-02-10 18:53:15 --> Router Class Initialized
INFO - 2018-02-10 18:53:15 --> Output Class Initialized
INFO - 2018-02-10 18:53:15 --> Security Class Initialized
DEBUG - 2018-02-10 18:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 18:53:15 --> Input Class Initialized
INFO - 2018-02-10 18:53:15 --> Language Class Initialized
INFO - 2018-02-10 18:53:15 --> Loader Class Initialized
INFO - 2018-02-10 18:53:15 --> Helper loaded: url_helper
INFO - 2018-02-10 18:53:15 --> Helper loaded: form_helper
INFO - 2018-02-10 18:53:15 --> Database Driver Class Initialized
DEBUG - 2018-02-10 18:53:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 18:53:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 18:53:15 --> Form Validation Class Initialized
INFO - 2018-02-10 18:53:15 --> Model Class Initialized
INFO - 2018-02-10 18:53:15 --> Controller Class Initialized
INFO - 2018-02-10 18:53:15 --> Model Class Initialized
DEBUG - 2018-02-10 18:53:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 18:53:15 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 18:53:15 --> Final output sent to browser
DEBUG - 2018-02-10 18:53:15 --> Total execution time: 0.0441
INFO - 2018-02-10 18:53:15 --> Config Class Initialized
INFO - 2018-02-10 18:53:15 --> Hooks Class Initialized
DEBUG - 2018-02-10 18:53:15 --> UTF-8 Support Enabled
INFO - 2018-02-10 18:53:15 --> Utf8 Class Initialized
INFO - 2018-02-10 18:53:15 --> URI Class Initialized
INFO - 2018-02-10 18:53:15 --> Router Class Initialized
INFO - 2018-02-10 18:53:15 --> Output Class Initialized
INFO - 2018-02-10 18:53:15 --> Security Class Initialized
DEBUG - 2018-02-10 18:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 18:53:15 --> Input Class Initialized
INFO - 2018-02-10 18:53:15 --> Language Class Initialized
INFO - 2018-02-10 18:53:15 --> Loader Class Initialized
INFO - 2018-02-10 18:53:15 --> Helper loaded: url_helper
INFO - 2018-02-10 18:53:15 --> Helper loaded: form_helper
INFO - 2018-02-10 18:53:15 --> Database Driver Class Initialized
DEBUG - 2018-02-10 18:53:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 18:53:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 18:53:15 --> Form Validation Class Initialized
INFO - 2018-02-10 18:53:15 --> Model Class Initialized
INFO - 2018-02-10 18:53:15 --> Controller Class Initialized
INFO - 2018-02-10 18:53:15 --> Model Class Initialized
DEBUG - 2018-02-10 18:53:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 18:53:17 --> Config Class Initialized
INFO - 2018-02-10 18:53:17 --> Hooks Class Initialized
DEBUG - 2018-02-10 18:53:17 --> UTF-8 Support Enabled
INFO - 2018-02-10 18:53:17 --> Utf8 Class Initialized
INFO - 2018-02-10 18:53:17 --> URI Class Initialized
INFO - 2018-02-10 18:53:17 --> Router Class Initialized
INFO - 2018-02-10 18:53:17 --> Output Class Initialized
INFO - 2018-02-10 18:53:17 --> Security Class Initialized
DEBUG - 2018-02-10 18:53:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 18:53:17 --> Input Class Initialized
INFO - 2018-02-10 18:53:17 --> Language Class Initialized
INFO - 2018-02-10 18:53:17 --> Loader Class Initialized
INFO - 2018-02-10 18:53:17 --> Helper loaded: url_helper
INFO - 2018-02-10 18:53:17 --> Helper loaded: form_helper
INFO - 2018-02-10 18:53:17 --> Database Driver Class Initialized
DEBUG - 2018-02-10 18:53:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 18:53:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 18:53:17 --> Form Validation Class Initialized
INFO - 2018-02-10 18:53:17 --> Model Class Initialized
INFO - 2018-02-10 18:53:17 --> Controller Class Initialized
INFO - 2018-02-10 18:53:17 --> Model Class Initialized
DEBUG - 2018-02-10 18:53:17 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-10 18:53:17 --> Severity: Notice --> Undefined variable: vrow D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\usuario\editarUsuario.php 97
ERROR - 2018-02-10 18:53:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\usuario\editarUsuario.php 97
ERROR - 2018-02-10 18:53:17 --> Severity: Notice --> Undefined variable: vrow D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\usuario\editarUsuario.php 97
ERROR - 2018-02-10 18:53:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\usuario\editarUsuario.php 97
ERROR - 2018-02-10 18:53:17 --> Severity: Notice --> Undefined variable: vrow D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\usuario\editarUsuario.php 97
ERROR - 2018-02-10 18:53:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\usuario\editarUsuario.php 97
INFO - 2018-02-10 18:53:17 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 18:53:17 --> Final output sent to browser
DEBUG - 2018-02-10 18:53:17 --> Total execution time: 0.1079
INFO - 2018-02-10 18:54:08 --> Config Class Initialized
INFO - 2018-02-10 18:54:08 --> Hooks Class Initialized
DEBUG - 2018-02-10 18:54:08 --> UTF-8 Support Enabled
INFO - 2018-02-10 18:54:08 --> Utf8 Class Initialized
INFO - 2018-02-10 18:54:08 --> URI Class Initialized
INFO - 2018-02-10 18:54:08 --> Router Class Initialized
INFO - 2018-02-10 18:54:08 --> Output Class Initialized
INFO - 2018-02-10 18:54:08 --> Security Class Initialized
DEBUG - 2018-02-10 18:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 18:54:08 --> Input Class Initialized
INFO - 2018-02-10 18:54:08 --> Language Class Initialized
INFO - 2018-02-10 18:54:08 --> Loader Class Initialized
INFO - 2018-02-10 18:54:08 --> Helper loaded: url_helper
INFO - 2018-02-10 18:54:08 --> Helper loaded: form_helper
INFO - 2018-02-10 18:54:08 --> Database Driver Class Initialized
DEBUG - 2018-02-10 18:54:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 18:54:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 18:54:08 --> Form Validation Class Initialized
INFO - 2018-02-10 18:54:08 --> Model Class Initialized
INFO - 2018-02-10 18:54:08 --> Controller Class Initialized
INFO - 2018-02-10 18:54:08 --> Model Class Initialized
DEBUG - 2018-02-10 18:54:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 18:54:08 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 18:54:08 --> Final output sent to browser
DEBUG - 2018-02-10 18:54:08 --> Total execution time: 0.1419
INFO - 2018-02-10 18:54:13 --> Config Class Initialized
INFO - 2018-02-10 18:54:13 --> Hooks Class Initialized
DEBUG - 2018-02-10 18:54:13 --> UTF-8 Support Enabled
INFO - 2018-02-10 18:54:13 --> Utf8 Class Initialized
INFO - 2018-02-10 18:54:13 --> URI Class Initialized
INFO - 2018-02-10 18:54:13 --> Router Class Initialized
INFO - 2018-02-10 18:54:13 --> Output Class Initialized
INFO - 2018-02-10 18:54:13 --> Security Class Initialized
DEBUG - 2018-02-10 18:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 18:54:13 --> Input Class Initialized
INFO - 2018-02-10 18:54:13 --> Language Class Initialized
INFO - 2018-02-10 18:54:13 --> Loader Class Initialized
INFO - 2018-02-10 18:54:13 --> Helper loaded: url_helper
INFO - 2018-02-10 18:54:13 --> Helper loaded: form_helper
INFO - 2018-02-10 18:54:13 --> Database Driver Class Initialized
DEBUG - 2018-02-10 18:54:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 18:54:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 18:54:13 --> Form Validation Class Initialized
INFO - 2018-02-10 18:54:13 --> Model Class Initialized
INFO - 2018-02-10 18:54:13 --> Controller Class Initialized
INFO - 2018-02-10 18:54:13 --> Model Class Initialized
DEBUG - 2018-02-10 18:54:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 18:54:13 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 18:54:13 --> Final output sent to browser
DEBUG - 2018-02-10 18:54:13 --> Total execution time: 0.0988
INFO - 2018-02-10 18:54:14 --> Config Class Initialized
INFO - 2018-02-10 18:54:14 --> Hooks Class Initialized
DEBUG - 2018-02-10 18:54:14 --> UTF-8 Support Enabled
INFO - 2018-02-10 18:54:14 --> Utf8 Class Initialized
INFO - 2018-02-10 18:54:14 --> URI Class Initialized
INFO - 2018-02-10 18:54:14 --> Router Class Initialized
INFO - 2018-02-10 18:54:14 --> Output Class Initialized
INFO - 2018-02-10 18:54:14 --> Security Class Initialized
DEBUG - 2018-02-10 18:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 18:54:14 --> Input Class Initialized
INFO - 2018-02-10 18:54:14 --> Language Class Initialized
INFO - 2018-02-10 18:54:14 --> Loader Class Initialized
INFO - 2018-02-10 18:54:14 --> Helper loaded: url_helper
INFO - 2018-02-10 18:54:14 --> Helper loaded: form_helper
INFO - 2018-02-10 18:54:14 --> Database Driver Class Initialized
DEBUG - 2018-02-10 18:54:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 18:54:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 18:54:14 --> Form Validation Class Initialized
INFO - 2018-02-10 18:54:14 --> Model Class Initialized
INFO - 2018-02-10 18:54:14 --> Controller Class Initialized
INFO - 2018-02-10 18:54:14 --> Model Class Initialized
DEBUG - 2018-02-10 18:54:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 18:54:23 --> Config Class Initialized
INFO - 2018-02-10 18:54:23 --> Hooks Class Initialized
DEBUG - 2018-02-10 18:54:23 --> UTF-8 Support Enabled
INFO - 2018-02-10 18:54:23 --> Utf8 Class Initialized
INFO - 2018-02-10 18:54:23 --> URI Class Initialized
INFO - 2018-02-10 18:54:23 --> Router Class Initialized
INFO - 2018-02-10 18:54:23 --> Output Class Initialized
INFO - 2018-02-10 18:54:23 --> Security Class Initialized
DEBUG - 2018-02-10 18:54:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 18:54:23 --> Input Class Initialized
INFO - 2018-02-10 18:54:23 --> Language Class Initialized
INFO - 2018-02-10 18:54:23 --> Loader Class Initialized
INFO - 2018-02-10 18:54:23 --> Helper loaded: url_helper
INFO - 2018-02-10 18:54:23 --> Helper loaded: form_helper
INFO - 2018-02-10 18:54:23 --> Database Driver Class Initialized
DEBUG - 2018-02-10 18:54:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 18:54:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 18:54:23 --> Form Validation Class Initialized
INFO - 2018-02-10 18:54:23 --> Model Class Initialized
INFO - 2018-02-10 18:54:23 --> Controller Class Initialized
INFO - 2018-02-10 18:54:23 --> Model Class Initialized
DEBUG - 2018-02-10 18:54:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 18:54:23 --> Config Class Initialized
INFO - 2018-02-10 18:54:23 --> Hooks Class Initialized
DEBUG - 2018-02-10 18:54:23 --> UTF-8 Support Enabled
INFO - 2018-02-10 18:54:23 --> Utf8 Class Initialized
INFO - 2018-02-10 18:54:23 --> URI Class Initialized
INFO - 2018-02-10 18:54:23 --> Router Class Initialized
INFO - 2018-02-10 18:54:23 --> Output Class Initialized
INFO - 2018-02-10 18:54:23 --> Security Class Initialized
DEBUG - 2018-02-10 18:54:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 18:54:23 --> Input Class Initialized
INFO - 2018-02-10 18:54:23 --> Language Class Initialized
INFO - 2018-02-10 18:54:23 --> Loader Class Initialized
INFO - 2018-02-10 18:54:23 --> Helper loaded: url_helper
INFO - 2018-02-10 18:54:23 --> Helper loaded: form_helper
INFO - 2018-02-10 18:54:23 --> Database Driver Class Initialized
DEBUG - 2018-02-10 18:54:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 18:54:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 18:54:23 --> Form Validation Class Initialized
INFO - 2018-02-10 18:54:23 --> Model Class Initialized
INFO - 2018-02-10 18:54:23 --> Controller Class Initialized
INFO - 2018-02-10 18:54:23 --> Model Class Initialized
DEBUG - 2018-02-10 18:54:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 18:54:23 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 18:54:23 --> Final output sent to browser
DEBUG - 2018-02-10 18:54:23 --> Total execution time: 0.1458
INFO - 2018-02-10 18:54:28 --> Config Class Initialized
INFO - 2018-02-10 18:54:28 --> Hooks Class Initialized
DEBUG - 2018-02-10 18:54:28 --> UTF-8 Support Enabled
INFO - 2018-02-10 18:54:28 --> Utf8 Class Initialized
INFO - 2018-02-10 18:54:28 --> URI Class Initialized
INFO - 2018-02-10 18:54:28 --> Router Class Initialized
INFO - 2018-02-10 18:54:28 --> Output Class Initialized
INFO - 2018-02-10 18:54:28 --> Security Class Initialized
DEBUG - 2018-02-10 18:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 18:54:28 --> Input Class Initialized
INFO - 2018-02-10 18:54:28 --> Language Class Initialized
INFO - 2018-02-10 18:54:28 --> Loader Class Initialized
INFO - 2018-02-10 18:54:28 --> Helper loaded: url_helper
INFO - 2018-02-10 18:54:28 --> Helper loaded: form_helper
INFO - 2018-02-10 18:54:28 --> Database Driver Class Initialized
DEBUG - 2018-02-10 18:54:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 18:54:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 18:54:28 --> Form Validation Class Initialized
INFO - 2018-02-10 18:54:28 --> Model Class Initialized
INFO - 2018-02-10 18:54:28 --> Controller Class Initialized
INFO - 2018-02-10 18:54:28 --> Model Class Initialized
DEBUG - 2018-02-10 18:54:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 18:54:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-10 18:54:29 --> Config Class Initialized
INFO - 2018-02-10 18:54:29 --> Hooks Class Initialized
DEBUG - 2018-02-10 18:54:29 --> UTF-8 Support Enabled
INFO - 2018-02-10 18:54:29 --> Utf8 Class Initialized
INFO - 2018-02-10 18:54:29 --> URI Class Initialized
DEBUG - 2018-02-10 18:54:29 --> No URI present. Default controller set.
INFO - 2018-02-10 18:54:29 --> Router Class Initialized
INFO - 2018-02-10 18:54:29 --> Output Class Initialized
INFO - 2018-02-10 18:54:29 --> Security Class Initialized
DEBUG - 2018-02-10 18:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 18:54:29 --> Input Class Initialized
INFO - 2018-02-10 18:54:29 --> Language Class Initialized
INFO - 2018-02-10 18:54:29 --> Loader Class Initialized
INFO - 2018-02-10 18:54:29 --> Helper loaded: url_helper
INFO - 2018-02-10 18:54:29 --> Helper loaded: form_helper
INFO - 2018-02-10 18:54:29 --> Database Driver Class Initialized
DEBUG - 2018-02-10 18:54:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 18:54:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 18:54:29 --> Form Validation Class Initialized
INFO - 2018-02-10 18:54:29 --> Model Class Initialized
INFO - 2018-02-10 18:54:29 --> Controller Class Initialized
INFO - 2018-02-10 18:54:29 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 18:54:29 --> Final output sent to browser
DEBUG - 2018-02-10 18:54:29 --> Total execution time: 0.0781
INFO - 2018-02-10 18:54:29 --> Config Class Initialized
INFO - 2018-02-10 18:54:29 --> Hooks Class Initialized
DEBUG - 2018-02-10 18:54:29 --> UTF-8 Support Enabled
INFO - 2018-02-10 18:54:29 --> Utf8 Class Initialized
INFO - 2018-02-10 18:54:29 --> URI Class Initialized
INFO - 2018-02-10 18:54:29 --> Router Class Initialized
INFO - 2018-02-10 18:54:29 --> Output Class Initialized
INFO - 2018-02-10 18:54:29 --> Security Class Initialized
DEBUG - 2018-02-10 18:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 18:54:29 --> Input Class Initialized
INFO - 2018-02-10 18:54:29 --> Language Class Initialized
INFO - 2018-02-10 18:54:29 --> Loader Class Initialized
INFO - 2018-02-10 18:54:29 --> Helper loaded: url_helper
INFO - 2018-02-10 18:54:29 --> Helper loaded: form_helper
INFO - 2018-02-10 18:54:29 --> Database Driver Class Initialized
DEBUG - 2018-02-10 18:54:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 18:54:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 18:54:29 --> Form Validation Class Initialized
INFO - 2018-02-10 18:54:29 --> Model Class Initialized
INFO - 2018-02-10 18:54:29 --> Controller Class Initialized
INFO - 2018-02-10 18:54:29 --> Model Class Initialized
INFO - 2018-02-10 18:54:29 --> Model Class Initialized
INFO - 2018-02-10 18:54:29 --> Model Class Initialized
INFO - 2018-02-10 18:54:29 --> Model Class Initialized
DEBUG - 2018-02-10 18:54:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 19:22:29 --> Config Class Initialized
INFO - 2018-02-10 19:22:29 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:22:29 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:22:29 --> Utf8 Class Initialized
INFO - 2018-02-10 19:22:29 --> URI Class Initialized
DEBUG - 2018-02-10 19:22:29 --> No URI present. Default controller set.
INFO - 2018-02-10 19:22:29 --> Router Class Initialized
INFO - 2018-02-10 19:22:29 --> Output Class Initialized
INFO - 2018-02-10 19:22:29 --> Security Class Initialized
DEBUG - 2018-02-10 19:22:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:22:29 --> Input Class Initialized
INFO - 2018-02-10 19:22:29 --> Language Class Initialized
INFO - 2018-02-10 19:22:29 --> Loader Class Initialized
INFO - 2018-02-10 19:22:29 --> Helper loaded: url_helper
INFO - 2018-02-10 19:22:29 --> Helper loaded: form_helper
INFO - 2018-02-10 19:22:29 --> Database Driver Class Initialized
DEBUG - 2018-02-10 19:22:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 19:22:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 19:22:29 --> Form Validation Class Initialized
INFO - 2018-02-10 19:22:29 --> Model Class Initialized
INFO - 2018-02-10 19:22:29 --> Controller Class Initialized
INFO - 2018-02-10 19:22:29 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 19:22:29 --> Final output sent to browser
DEBUG - 2018-02-10 19:22:29 --> Total execution time: 0.0444
INFO - 2018-02-10 19:22:29 --> Config Class Initialized
INFO - 2018-02-10 19:22:29 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:22:29 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:22:29 --> Utf8 Class Initialized
INFO - 2018-02-10 19:22:29 --> URI Class Initialized
INFO - 2018-02-10 19:22:29 --> Router Class Initialized
INFO - 2018-02-10 19:22:29 --> Output Class Initialized
INFO - 2018-02-10 19:22:29 --> Security Class Initialized
DEBUG - 2018-02-10 19:22:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:22:29 --> Input Class Initialized
INFO - 2018-02-10 19:22:29 --> Language Class Initialized
INFO - 2018-02-10 19:22:29 --> Loader Class Initialized
INFO - 2018-02-10 19:22:29 --> Helper loaded: url_helper
INFO - 2018-02-10 19:22:29 --> Helper loaded: form_helper
INFO - 2018-02-10 19:22:29 --> Database Driver Class Initialized
DEBUG - 2018-02-10 19:22:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 19:22:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 19:22:29 --> Form Validation Class Initialized
INFO - 2018-02-10 19:22:29 --> Model Class Initialized
INFO - 2018-02-10 19:22:29 --> Controller Class Initialized
INFO - 2018-02-10 19:22:29 --> Model Class Initialized
INFO - 2018-02-10 19:22:29 --> Model Class Initialized
INFO - 2018-02-10 19:22:29 --> Model Class Initialized
INFO - 2018-02-10 19:22:29 --> Model Class Initialized
DEBUG - 2018-02-10 19:22:29 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-10 19:22:29 --> Severity: Notice --> Use of undefined constant usuario_id - assumed 'usuario_id' D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Proyecto.php 455
ERROR - 2018-02-10 19:22:29 --> Severity: Notice --> Object of class Proyecto could not be converted to int D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Proyecto.php 455
INFO - 2018-02-10 19:22:29 --> Config Class Initialized
INFO - 2018-02-10 19:22:29 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:22:29 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:22:29 --> Utf8 Class Initialized
INFO - 2018-02-10 19:22:29 --> URI Class Initialized
DEBUG - 2018-02-10 19:22:29 --> No URI present. Default controller set.
INFO - 2018-02-10 19:22:29 --> Router Class Initialized
INFO - 2018-02-10 19:22:29 --> Output Class Initialized
INFO - 2018-02-10 19:22:29 --> Security Class Initialized
DEBUG - 2018-02-10 19:22:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:22:29 --> Input Class Initialized
INFO - 2018-02-10 19:22:29 --> Language Class Initialized
INFO - 2018-02-10 19:22:29 --> Loader Class Initialized
INFO - 2018-02-10 19:22:29 --> Helper loaded: url_helper
INFO - 2018-02-10 19:22:29 --> Helper loaded: form_helper
INFO - 2018-02-10 19:22:29 --> Database Driver Class Initialized
DEBUG - 2018-02-10 19:22:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 19:22:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 19:22:29 --> Form Validation Class Initialized
INFO - 2018-02-10 19:22:29 --> Model Class Initialized
INFO - 2018-02-10 19:22:29 --> Controller Class Initialized
INFO - 2018-02-10 19:22:29 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 19:22:29 --> Final output sent to browser
DEBUG - 2018-02-10 19:22:29 --> Total execution time: 0.0419
INFO - 2018-02-10 19:22:30 --> Config Class Initialized
INFO - 2018-02-10 19:22:30 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:22:30 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:22:30 --> Utf8 Class Initialized
INFO - 2018-02-10 19:22:30 --> URI Class Initialized
INFO - 2018-02-10 19:22:30 --> Router Class Initialized
INFO - 2018-02-10 19:22:30 --> Output Class Initialized
INFO - 2018-02-10 19:22:30 --> Security Class Initialized
DEBUG - 2018-02-10 19:22:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:22:30 --> Input Class Initialized
INFO - 2018-02-10 19:22:30 --> Language Class Initialized
INFO - 2018-02-10 19:22:30 --> Loader Class Initialized
INFO - 2018-02-10 19:22:30 --> Helper loaded: url_helper
INFO - 2018-02-10 19:22:30 --> Helper loaded: form_helper
INFO - 2018-02-10 19:22:30 --> Database Driver Class Initialized
DEBUG - 2018-02-10 19:22:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 19:22:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 19:22:30 --> Form Validation Class Initialized
INFO - 2018-02-10 19:22:30 --> Model Class Initialized
INFO - 2018-02-10 19:22:30 --> Controller Class Initialized
INFO - 2018-02-10 19:22:30 --> Model Class Initialized
INFO - 2018-02-10 19:22:30 --> Model Class Initialized
INFO - 2018-02-10 19:22:30 --> Model Class Initialized
INFO - 2018-02-10 19:22:30 --> Model Class Initialized
DEBUG - 2018-02-10 19:22:30 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-10 19:22:30 --> Severity: Notice --> Use of undefined constant usuario_id - assumed 'usuario_id' D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Proyecto.php 455
ERROR - 2018-02-10 19:22:30 --> Severity: Notice --> Object of class Proyecto could not be converted to int D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Proyecto.php 455
INFO - 2018-02-10 19:22:30 --> Config Class Initialized
INFO - 2018-02-10 19:22:30 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:22:30 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:22:30 --> Utf8 Class Initialized
INFO - 2018-02-10 19:22:30 --> URI Class Initialized
DEBUG - 2018-02-10 19:22:30 --> No URI present. Default controller set.
INFO - 2018-02-10 19:22:30 --> Router Class Initialized
INFO - 2018-02-10 19:22:30 --> Output Class Initialized
INFO - 2018-02-10 19:22:30 --> Security Class Initialized
DEBUG - 2018-02-10 19:22:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:22:30 --> Input Class Initialized
INFO - 2018-02-10 19:22:30 --> Language Class Initialized
INFO - 2018-02-10 19:22:30 --> Loader Class Initialized
INFO - 2018-02-10 19:22:30 --> Helper loaded: url_helper
INFO - 2018-02-10 19:22:30 --> Helper loaded: form_helper
INFO - 2018-02-10 19:22:30 --> Database Driver Class Initialized
DEBUG - 2018-02-10 19:22:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 19:22:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 19:22:30 --> Form Validation Class Initialized
INFO - 2018-02-10 19:22:30 --> Model Class Initialized
INFO - 2018-02-10 19:22:30 --> Controller Class Initialized
INFO - 2018-02-10 19:22:30 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 19:22:30 --> Final output sent to browser
DEBUG - 2018-02-10 19:22:30 --> Total execution time: 0.0547
INFO - 2018-02-10 19:22:30 --> Config Class Initialized
INFO - 2018-02-10 19:22:30 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:22:30 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:22:30 --> Utf8 Class Initialized
INFO - 2018-02-10 19:22:30 --> URI Class Initialized
INFO - 2018-02-10 19:22:30 --> Router Class Initialized
INFO - 2018-02-10 19:22:30 --> Output Class Initialized
INFO - 2018-02-10 19:22:30 --> Security Class Initialized
DEBUG - 2018-02-10 19:22:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:22:30 --> Input Class Initialized
INFO - 2018-02-10 19:22:30 --> Language Class Initialized
INFO - 2018-02-10 19:22:30 --> Loader Class Initialized
INFO - 2018-02-10 19:22:30 --> Helper loaded: url_helper
INFO - 2018-02-10 19:22:30 --> Helper loaded: form_helper
INFO - 2018-02-10 19:22:30 --> Database Driver Class Initialized
DEBUG - 2018-02-10 19:22:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 19:22:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 19:22:30 --> Form Validation Class Initialized
INFO - 2018-02-10 19:22:30 --> Model Class Initialized
INFO - 2018-02-10 19:22:30 --> Controller Class Initialized
INFO - 2018-02-10 19:22:30 --> Model Class Initialized
INFO - 2018-02-10 19:22:30 --> Model Class Initialized
INFO - 2018-02-10 19:22:30 --> Model Class Initialized
INFO - 2018-02-10 19:22:30 --> Model Class Initialized
DEBUG - 2018-02-10 19:22:30 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-10 19:22:30 --> Severity: Notice --> Use of undefined constant usuario_id - assumed 'usuario_id' D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Proyecto.php 455
ERROR - 2018-02-10 19:22:30 --> Severity: Notice --> Object of class Proyecto could not be converted to int D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Proyecto.php 455
INFO - 2018-02-10 19:22:31 --> Config Class Initialized
INFO - 2018-02-10 19:22:31 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:22:31 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:22:31 --> Utf8 Class Initialized
INFO - 2018-02-10 19:22:31 --> URI Class Initialized
DEBUG - 2018-02-10 19:22:31 --> No URI present. Default controller set.
INFO - 2018-02-10 19:22:31 --> Router Class Initialized
INFO - 2018-02-10 19:22:31 --> Output Class Initialized
INFO - 2018-02-10 19:22:31 --> Security Class Initialized
DEBUG - 2018-02-10 19:22:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:22:31 --> Input Class Initialized
INFO - 2018-02-10 19:22:31 --> Language Class Initialized
INFO - 2018-02-10 19:22:31 --> Loader Class Initialized
INFO - 2018-02-10 19:22:31 --> Helper loaded: url_helper
INFO - 2018-02-10 19:22:31 --> Helper loaded: form_helper
INFO - 2018-02-10 19:22:31 --> Database Driver Class Initialized
DEBUG - 2018-02-10 19:22:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 19:22:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 19:22:31 --> Form Validation Class Initialized
INFO - 2018-02-10 19:22:31 --> Model Class Initialized
INFO - 2018-02-10 19:22:31 --> Controller Class Initialized
INFO - 2018-02-10 19:22:31 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 19:22:31 --> Final output sent to browser
DEBUG - 2018-02-10 19:22:31 --> Total execution time: 0.0413
INFO - 2018-02-10 19:22:31 --> Config Class Initialized
INFO - 2018-02-10 19:22:31 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:22:31 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:22:31 --> Utf8 Class Initialized
INFO - 2018-02-10 19:22:31 --> URI Class Initialized
INFO - 2018-02-10 19:22:31 --> Router Class Initialized
INFO - 2018-02-10 19:22:31 --> Output Class Initialized
INFO - 2018-02-10 19:22:31 --> Security Class Initialized
DEBUG - 2018-02-10 19:22:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:22:31 --> Input Class Initialized
INFO - 2018-02-10 19:22:31 --> Language Class Initialized
INFO - 2018-02-10 19:22:31 --> Loader Class Initialized
INFO - 2018-02-10 19:22:31 --> Helper loaded: url_helper
INFO - 2018-02-10 19:22:31 --> Helper loaded: form_helper
INFO - 2018-02-10 19:22:31 --> Database Driver Class Initialized
DEBUG - 2018-02-10 19:22:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 19:22:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 19:22:31 --> Form Validation Class Initialized
INFO - 2018-02-10 19:22:31 --> Model Class Initialized
INFO - 2018-02-10 19:22:31 --> Controller Class Initialized
INFO - 2018-02-10 19:22:31 --> Model Class Initialized
INFO - 2018-02-10 19:22:31 --> Model Class Initialized
INFO - 2018-02-10 19:22:31 --> Model Class Initialized
INFO - 2018-02-10 19:22:31 --> Model Class Initialized
DEBUG - 2018-02-10 19:22:31 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-10 19:22:31 --> Severity: Notice --> Use of undefined constant usuario_id - assumed 'usuario_id' D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Proyecto.php 455
ERROR - 2018-02-10 19:22:31 --> Severity: Notice --> Object of class Proyecto could not be converted to int D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Proyecto.php 455
INFO - 2018-02-10 19:22:31 --> Config Class Initialized
INFO - 2018-02-10 19:22:31 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:22:31 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:22:31 --> Utf8 Class Initialized
INFO - 2018-02-10 19:22:31 --> URI Class Initialized
DEBUG - 2018-02-10 19:22:31 --> No URI present. Default controller set.
INFO - 2018-02-10 19:22:31 --> Router Class Initialized
INFO - 2018-02-10 19:22:31 --> Output Class Initialized
INFO - 2018-02-10 19:22:31 --> Security Class Initialized
DEBUG - 2018-02-10 19:22:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:22:31 --> Input Class Initialized
INFO - 2018-02-10 19:22:31 --> Language Class Initialized
INFO - 2018-02-10 19:22:31 --> Loader Class Initialized
INFO - 2018-02-10 19:22:31 --> Helper loaded: url_helper
INFO - 2018-02-10 19:22:31 --> Helper loaded: form_helper
INFO - 2018-02-10 19:22:31 --> Database Driver Class Initialized
DEBUG - 2018-02-10 19:22:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 19:22:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 19:22:31 --> Form Validation Class Initialized
INFO - 2018-02-10 19:22:31 --> Model Class Initialized
INFO - 2018-02-10 19:22:31 --> Controller Class Initialized
INFO - 2018-02-10 19:22:31 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 19:22:31 --> Final output sent to browser
DEBUG - 2018-02-10 19:22:31 --> Total execution time: 0.0377
INFO - 2018-02-10 19:22:31 --> Config Class Initialized
INFO - 2018-02-10 19:22:31 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:22:31 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:22:31 --> Utf8 Class Initialized
INFO - 2018-02-10 19:22:31 --> URI Class Initialized
INFO - 2018-02-10 19:22:31 --> Router Class Initialized
INFO - 2018-02-10 19:22:31 --> Output Class Initialized
INFO - 2018-02-10 19:22:31 --> Security Class Initialized
DEBUG - 2018-02-10 19:22:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:22:31 --> Input Class Initialized
INFO - 2018-02-10 19:22:31 --> Language Class Initialized
INFO - 2018-02-10 19:22:31 --> Loader Class Initialized
INFO - 2018-02-10 19:22:31 --> Helper loaded: url_helper
INFO - 2018-02-10 19:22:31 --> Helper loaded: form_helper
INFO - 2018-02-10 19:22:31 --> Database Driver Class Initialized
DEBUG - 2018-02-10 19:22:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 19:22:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 19:22:32 --> Form Validation Class Initialized
INFO - 2018-02-10 19:22:32 --> Model Class Initialized
INFO - 2018-02-10 19:22:32 --> Controller Class Initialized
INFO - 2018-02-10 19:22:32 --> Model Class Initialized
INFO - 2018-02-10 19:22:32 --> Model Class Initialized
INFO - 2018-02-10 19:22:32 --> Model Class Initialized
INFO - 2018-02-10 19:22:32 --> Model Class Initialized
DEBUG - 2018-02-10 19:22:32 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-10 19:22:32 --> Severity: Notice --> Use of undefined constant usuario_id - assumed 'usuario_id' D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Proyecto.php 455
ERROR - 2018-02-10 19:22:32 --> Severity: Notice --> Object of class Proyecto could not be converted to int D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Proyecto.php 455
INFO - 2018-02-10 19:22:32 --> Config Class Initialized
INFO - 2018-02-10 19:22:32 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:22:32 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:22:32 --> Utf8 Class Initialized
INFO - 2018-02-10 19:22:32 --> URI Class Initialized
DEBUG - 2018-02-10 19:22:32 --> No URI present. Default controller set.
INFO - 2018-02-10 19:22:32 --> Router Class Initialized
INFO - 2018-02-10 19:22:32 --> Output Class Initialized
INFO - 2018-02-10 19:22:32 --> Security Class Initialized
DEBUG - 2018-02-10 19:22:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:22:32 --> Input Class Initialized
INFO - 2018-02-10 19:22:32 --> Language Class Initialized
INFO - 2018-02-10 19:22:32 --> Loader Class Initialized
INFO - 2018-02-10 19:22:32 --> Helper loaded: url_helper
INFO - 2018-02-10 19:22:32 --> Helper loaded: form_helper
INFO - 2018-02-10 19:22:32 --> Database Driver Class Initialized
DEBUG - 2018-02-10 19:22:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 19:22:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 19:22:32 --> Form Validation Class Initialized
INFO - 2018-02-10 19:22:32 --> Model Class Initialized
INFO - 2018-02-10 19:22:32 --> Controller Class Initialized
INFO - 2018-02-10 19:22:32 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 19:22:32 --> Final output sent to browser
DEBUG - 2018-02-10 19:22:32 --> Total execution time: 0.0441
INFO - 2018-02-10 19:22:32 --> Config Class Initialized
INFO - 2018-02-10 19:22:32 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:22:32 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:22:32 --> Utf8 Class Initialized
INFO - 2018-02-10 19:22:32 --> URI Class Initialized
INFO - 2018-02-10 19:22:32 --> Router Class Initialized
INFO - 2018-02-10 19:22:32 --> Output Class Initialized
INFO - 2018-02-10 19:22:32 --> Security Class Initialized
DEBUG - 2018-02-10 19:22:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:22:32 --> Input Class Initialized
INFO - 2018-02-10 19:22:32 --> Language Class Initialized
INFO - 2018-02-10 19:22:32 --> Loader Class Initialized
INFO - 2018-02-10 19:22:32 --> Helper loaded: url_helper
INFO - 2018-02-10 19:22:32 --> Helper loaded: form_helper
INFO - 2018-02-10 19:22:32 --> Database Driver Class Initialized
DEBUG - 2018-02-10 19:22:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 19:22:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 19:22:32 --> Form Validation Class Initialized
INFO - 2018-02-10 19:22:32 --> Model Class Initialized
INFO - 2018-02-10 19:22:32 --> Controller Class Initialized
INFO - 2018-02-10 19:22:32 --> Model Class Initialized
INFO - 2018-02-10 19:22:32 --> Model Class Initialized
INFO - 2018-02-10 19:22:32 --> Model Class Initialized
INFO - 2018-02-10 19:22:32 --> Model Class Initialized
DEBUG - 2018-02-10 19:22:32 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-10 19:22:32 --> Severity: Notice --> Use of undefined constant usuario_id - assumed 'usuario_id' D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Proyecto.php 455
ERROR - 2018-02-10 19:22:32 --> Severity: Notice --> Object of class Proyecto could not be converted to int D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Proyecto.php 455
INFO - 2018-02-10 19:26:51 --> Config Class Initialized
INFO - 2018-02-10 19:26:51 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:26:51 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:26:51 --> Utf8 Class Initialized
INFO - 2018-02-10 19:26:51 --> URI Class Initialized
DEBUG - 2018-02-10 19:26:51 --> No URI present. Default controller set.
INFO - 2018-02-10 19:26:51 --> Router Class Initialized
INFO - 2018-02-10 19:26:51 --> Output Class Initialized
INFO - 2018-02-10 19:26:51 --> Security Class Initialized
DEBUG - 2018-02-10 19:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:26:51 --> Input Class Initialized
INFO - 2018-02-10 19:26:51 --> Language Class Initialized
INFO - 2018-02-10 19:26:51 --> Loader Class Initialized
INFO - 2018-02-10 19:26:51 --> Helper loaded: url_helper
INFO - 2018-02-10 19:26:51 --> Helper loaded: form_helper
INFO - 2018-02-10 19:26:51 --> Database Driver Class Initialized
DEBUG - 2018-02-10 19:26:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 19:26:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 19:26:51 --> Form Validation Class Initialized
INFO - 2018-02-10 19:26:51 --> Model Class Initialized
INFO - 2018-02-10 19:26:51 --> Controller Class Initialized
INFO - 2018-02-10 19:26:51 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 19:26:51 --> Final output sent to browser
DEBUG - 2018-02-10 19:26:51 --> Total execution time: 0.0379
INFO - 2018-02-10 19:26:51 --> Config Class Initialized
INFO - 2018-02-10 19:26:51 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:26:51 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:26:51 --> Utf8 Class Initialized
INFO - 2018-02-10 19:26:51 --> URI Class Initialized
INFO - 2018-02-10 19:26:51 --> Router Class Initialized
INFO - 2018-02-10 19:26:51 --> Output Class Initialized
INFO - 2018-02-10 19:26:51 --> Security Class Initialized
DEBUG - 2018-02-10 19:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:26:51 --> Input Class Initialized
INFO - 2018-02-10 19:26:51 --> Language Class Initialized
INFO - 2018-02-10 19:26:51 --> Loader Class Initialized
INFO - 2018-02-10 19:26:51 --> Helper loaded: url_helper
INFO - 2018-02-10 19:26:51 --> Helper loaded: form_helper
INFO - 2018-02-10 19:26:51 --> Database Driver Class Initialized
DEBUG - 2018-02-10 19:26:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 19:26:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 19:26:51 --> Form Validation Class Initialized
INFO - 2018-02-10 19:26:51 --> Model Class Initialized
INFO - 2018-02-10 19:26:51 --> Controller Class Initialized
INFO - 2018-02-10 19:26:51 --> Model Class Initialized
INFO - 2018-02-10 19:26:51 --> Model Class Initialized
INFO - 2018-02-10 19:26:51 --> Model Class Initialized
INFO - 2018-02-10 19:26:51 --> Model Class Initialized
DEBUG - 2018-02-10 19:26:51 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-10 19:26:51 --> Severity: Notice --> Use of undefined constant usuario_id - assumed 'usuario_id' D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Proyecto.php 455
ERROR - 2018-02-10 19:26:51 --> Severity: Notice --> Object of class Proyecto could not be converted to int D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Proyecto.php 455
INFO - 2018-02-10 19:26:51 --> Config Class Initialized
INFO - 2018-02-10 19:26:51 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:26:51 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:26:51 --> Utf8 Class Initialized
INFO - 2018-02-10 19:26:51 --> URI Class Initialized
DEBUG - 2018-02-10 19:26:51 --> No URI present. Default controller set.
INFO - 2018-02-10 19:26:51 --> Router Class Initialized
INFO - 2018-02-10 19:26:51 --> Output Class Initialized
INFO - 2018-02-10 19:26:51 --> Security Class Initialized
DEBUG - 2018-02-10 19:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:26:51 --> Input Class Initialized
INFO - 2018-02-10 19:26:51 --> Language Class Initialized
INFO - 2018-02-10 19:26:51 --> Loader Class Initialized
INFO - 2018-02-10 19:26:51 --> Helper loaded: url_helper
INFO - 2018-02-10 19:26:51 --> Helper loaded: form_helper
INFO - 2018-02-10 19:26:51 --> Database Driver Class Initialized
DEBUG - 2018-02-10 19:26:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 19:26:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 19:26:51 --> Form Validation Class Initialized
INFO - 2018-02-10 19:26:51 --> Model Class Initialized
INFO - 2018-02-10 19:26:51 --> Controller Class Initialized
INFO - 2018-02-10 19:26:51 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 19:26:51 --> Final output sent to browser
DEBUG - 2018-02-10 19:26:51 --> Total execution time: 0.0371
INFO - 2018-02-10 19:26:52 --> Config Class Initialized
INFO - 2018-02-10 19:26:52 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:26:52 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:26:52 --> Utf8 Class Initialized
INFO - 2018-02-10 19:26:52 --> URI Class Initialized
INFO - 2018-02-10 19:26:52 --> Router Class Initialized
INFO - 2018-02-10 19:26:52 --> Output Class Initialized
INFO - 2018-02-10 19:26:52 --> Security Class Initialized
DEBUG - 2018-02-10 19:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:26:52 --> Input Class Initialized
INFO - 2018-02-10 19:26:52 --> Language Class Initialized
INFO - 2018-02-10 19:26:52 --> Loader Class Initialized
INFO - 2018-02-10 19:26:52 --> Helper loaded: url_helper
INFO - 2018-02-10 19:26:52 --> Helper loaded: form_helper
INFO - 2018-02-10 19:26:52 --> Database Driver Class Initialized
DEBUG - 2018-02-10 19:26:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 19:26:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 19:26:52 --> Form Validation Class Initialized
INFO - 2018-02-10 19:26:52 --> Model Class Initialized
INFO - 2018-02-10 19:26:52 --> Controller Class Initialized
INFO - 2018-02-10 19:26:52 --> Model Class Initialized
INFO - 2018-02-10 19:26:52 --> Model Class Initialized
INFO - 2018-02-10 19:26:52 --> Model Class Initialized
INFO - 2018-02-10 19:26:52 --> Model Class Initialized
DEBUG - 2018-02-10 19:26:52 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-10 19:26:52 --> Severity: Notice --> Use of undefined constant usuario_id - assumed 'usuario_id' D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Proyecto.php 455
ERROR - 2018-02-10 19:26:52 --> Severity: Notice --> Object of class Proyecto could not be converted to int D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Proyecto.php 455
INFO - 2018-02-10 19:27:06 --> Config Class Initialized
INFO - 2018-02-10 19:27:06 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:27:06 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:27:06 --> Utf8 Class Initialized
INFO - 2018-02-10 19:27:06 --> URI Class Initialized
DEBUG - 2018-02-10 19:27:06 --> No URI present. Default controller set.
INFO - 2018-02-10 19:27:06 --> Router Class Initialized
INFO - 2018-02-10 19:27:06 --> Output Class Initialized
INFO - 2018-02-10 19:27:06 --> Security Class Initialized
DEBUG - 2018-02-10 19:27:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:27:06 --> Input Class Initialized
INFO - 2018-02-10 19:27:06 --> Language Class Initialized
INFO - 2018-02-10 19:27:06 --> Loader Class Initialized
INFO - 2018-02-10 19:27:06 --> Helper loaded: url_helper
INFO - 2018-02-10 19:27:06 --> Helper loaded: form_helper
INFO - 2018-02-10 19:27:06 --> Database Driver Class Initialized
DEBUG - 2018-02-10 19:27:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 19:27:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 19:27:06 --> Form Validation Class Initialized
INFO - 2018-02-10 19:27:06 --> Model Class Initialized
INFO - 2018-02-10 19:27:06 --> Controller Class Initialized
INFO - 2018-02-10 19:27:06 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 19:27:06 --> Final output sent to browser
DEBUG - 2018-02-10 19:27:06 --> Total execution time: 0.0940
INFO - 2018-02-10 19:27:07 --> Config Class Initialized
INFO - 2018-02-10 19:27:07 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:27:07 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:27:07 --> Utf8 Class Initialized
INFO - 2018-02-10 19:27:07 --> URI Class Initialized
INFO - 2018-02-10 19:27:07 --> Router Class Initialized
INFO - 2018-02-10 19:27:07 --> Output Class Initialized
INFO - 2018-02-10 19:27:07 --> Security Class Initialized
DEBUG - 2018-02-10 19:27:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:27:07 --> Input Class Initialized
INFO - 2018-02-10 19:27:07 --> Language Class Initialized
INFO - 2018-02-10 19:27:07 --> Loader Class Initialized
INFO - 2018-02-10 19:27:07 --> Helper loaded: url_helper
INFO - 2018-02-10 19:27:07 --> Helper loaded: form_helper
INFO - 2018-02-10 19:27:07 --> Database Driver Class Initialized
DEBUG - 2018-02-10 19:27:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 19:27:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 19:27:07 --> Form Validation Class Initialized
INFO - 2018-02-10 19:27:07 --> Model Class Initialized
INFO - 2018-02-10 19:27:07 --> Controller Class Initialized
INFO - 2018-02-10 19:27:07 --> Model Class Initialized
INFO - 2018-02-10 19:27:07 --> Model Class Initialized
INFO - 2018-02-10 19:27:07 --> Model Class Initialized
INFO - 2018-02-10 19:27:07 --> Model Class Initialized
DEBUG - 2018-02-10 19:27:07 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-10 19:27:07 --> Severity: Notice --> Use of undefined constant usuario_id - assumed 'usuario_id' D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Proyecto.php 455
ERROR - 2018-02-10 19:27:07 --> Severity: Notice --> Object of class Proyecto could not be converted to int D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Proyecto.php 455
INFO - 2018-02-10 19:28:22 --> Config Class Initialized
INFO - 2018-02-10 19:28:22 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:28:22 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:28:22 --> Utf8 Class Initialized
INFO - 2018-02-10 19:28:22 --> URI Class Initialized
DEBUG - 2018-02-10 19:28:22 --> No URI present. Default controller set.
INFO - 2018-02-10 19:28:22 --> Router Class Initialized
INFO - 2018-02-10 19:28:22 --> Output Class Initialized
INFO - 2018-02-10 19:28:22 --> Security Class Initialized
DEBUG - 2018-02-10 19:28:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:28:22 --> Input Class Initialized
INFO - 2018-02-10 19:28:22 --> Language Class Initialized
INFO - 2018-02-10 19:28:22 --> Loader Class Initialized
INFO - 2018-02-10 19:28:22 --> Helper loaded: url_helper
INFO - 2018-02-10 19:28:22 --> Helper loaded: form_helper
INFO - 2018-02-10 19:28:22 --> Database Driver Class Initialized
DEBUG - 2018-02-10 19:28:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 19:28:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 19:28:22 --> Form Validation Class Initialized
INFO - 2018-02-10 19:28:22 --> Model Class Initialized
INFO - 2018-02-10 19:28:22 --> Controller Class Initialized
INFO - 2018-02-10 19:28:22 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 19:28:22 --> Final output sent to browser
DEBUG - 2018-02-10 19:28:22 --> Total execution time: 0.0813
INFO - 2018-02-10 19:28:23 --> Config Class Initialized
INFO - 2018-02-10 19:28:23 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:28:23 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:28:23 --> Utf8 Class Initialized
INFO - 2018-02-10 19:28:23 --> URI Class Initialized
INFO - 2018-02-10 19:28:23 --> Router Class Initialized
INFO - 2018-02-10 19:28:23 --> Output Class Initialized
INFO - 2018-02-10 19:28:23 --> Security Class Initialized
DEBUG - 2018-02-10 19:28:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:28:23 --> Input Class Initialized
INFO - 2018-02-10 19:28:23 --> Language Class Initialized
INFO - 2018-02-10 19:28:23 --> Loader Class Initialized
INFO - 2018-02-10 19:28:23 --> Helper loaded: url_helper
INFO - 2018-02-10 19:28:23 --> Helper loaded: form_helper
INFO - 2018-02-10 19:28:23 --> Database Driver Class Initialized
DEBUG - 2018-02-10 19:28:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 19:28:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 19:28:23 --> Form Validation Class Initialized
INFO - 2018-02-10 19:28:23 --> Model Class Initialized
INFO - 2018-02-10 19:28:23 --> Controller Class Initialized
INFO - 2018-02-10 19:28:23 --> Model Class Initialized
INFO - 2018-02-10 19:28:23 --> Model Class Initialized
INFO - 2018-02-10 19:28:23 --> Model Class Initialized
INFO - 2018-02-10 19:28:23 --> Model Class Initialized
DEBUG - 2018-02-10 19:28:23 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-10 19:28:23 --> Severity: Notice --> Use of undefined constant usuario_id - assumed 'usuario_id' D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Proyecto.php 455
ERROR - 2018-02-10 19:28:23 --> Severity: Notice --> Object of class Proyecto could not be converted to int D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Proyecto.php 455
INFO - 2018-02-10 19:28:24 --> Config Class Initialized
INFO - 2018-02-10 19:28:24 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:28:24 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:28:24 --> Utf8 Class Initialized
INFO - 2018-02-10 19:28:24 --> URI Class Initialized
DEBUG - 2018-02-10 19:28:24 --> No URI present. Default controller set.
INFO - 2018-02-10 19:28:24 --> Router Class Initialized
INFO - 2018-02-10 19:28:24 --> Output Class Initialized
INFO - 2018-02-10 19:28:24 --> Security Class Initialized
DEBUG - 2018-02-10 19:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:28:24 --> Input Class Initialized
INFO - 2018-02-10 19:28:24 --> Language Class Initialized
INFO - 2018-02-10 19:28:24 --> Loader Class Initialized
INFO - 2018-02-10 19:28:25 --> Helper loaded: url_helper
INFO - 2018-02-10 19:28:25 --> Helper loaded: form_helper
INFO - 2018-02-10 19:28:25 --> Database Driver Class Initialized
DEBUG - 2018-02-10 19:28:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 19:28:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 19:28:25 --> Form Validation Class Initialized
INFO - 2018-02-10 19:28:25 --> Model Class Initialized
INFO - 2018-02-10 19:28:25 --> Controller Class Initialized
INFO - 2018-02-10 19:28:25 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 19:28:25 --> Final output sent to browser
DEBUG - 2018-02-10 19:28:25 --> Total execution time: 0.0453
INFO - 2018-02-10 19:28:25 --> Config Class Initialized
INFO - 2018-02-10 19:28:25 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:28:25 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:28:25 --> Utf8 Class Initialized
INFO - 2018-02-10 19:28:25 --> URI Class Initialized
INFO - 2018-02-10 19:28:25 --> Router Class Initialized
INFO - 2018-02-10 19:28:25 --> Output Class Initialized
INFO - 2018-02-10 19:28:25 --> Security Class Initialized
DEBUG - 2018-02-10 19:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:28:25 --> Input Class Initialized
INFO - 2018-02-10 19:28:25 --> Language Class Initialized
INFO - 2018-02-10 19:28:25 --> Loader Class Initialized
INFO - 2018-02-10 19:28:25 --> Helper loaded: url_helper
INFO - 2018-02-10 19:28:25 --> Helper loaded: form_helper
INFO - 2018-02-10 19:28:25 --> Database Driver Class Initialized
DEBUG - 2018-02-10 19:28:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 19:28:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 19:28:25 --> Form Validation Class Initialized
INFO - 2018-02-10 19:28:25 --> Model Class Initialized
INFO - 2018-02-10 19:28:25 --> Controller Class Initialized
INFO - 2018-02-10 19:28:25 --> Model Class Initialized
INFO - 2018-02-10 19:28:25 --> Model Class Initialized
INFO - 2018-02-10 19:28:25 --> Model Class Initialized
INFO - 2018-02-10 19:28:25 --> Model Class Initialized
DEBUG - 2018-02-10 19:28:25 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-10 19:28:25 --> Severity: Notice --> Use of undefined constant usuario_id - assumed 'usuario_id' D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Proyecto.php 455
ERROR - 2018-02-10 19:28:25 --> Severity: Notice --> Object of class Proyecto could not be converted to int D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Proyecto.php 455
INFO - 2018-02-10 19:29:05 --> Config Class Initialized
INFO - 2018-02-10 19:29:05 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:29:05 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:29:05 --> Utf8 Class Initialized
INFO - 2018-02-10 19:29:05 --> URI Class Initialized
DEBUG - 2018-02-10 19:29:05 --> No URI present. Default controller set.
INFO - 2018-02-10 19:29:05 --> Router Class Initialized
INFO - 2018-02-10 19:29:05 --> Output Class Initialized
INFO - 2018-02-10 19:29:05 --> Security Class Initialized
DEBUG - 2018-02-10 19:29:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:29:05 --> Input Class Initialized
INFO - 2018-02-10 19:29:05 --> Language Class Initialized
INFO - 2018-02-10 19:29:05 --> Loader Class Initialized
INFO - 2018-02-10 19:29:05 --> Helper loaded: url_helper
INFO - 2018-02-10 19:29:05 --> Helper loaded: form_helper
INFO - 2018-02-10 19:29:05 --> Database Driver Class Initialized
DEBUG - 2018-02-10 19:29:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 19:29:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 19:29:05 --> Form Validation Class Initialized
INFO - 2018-02-10 19:29:05 --> Model Class Initialized
INFO - 2018-02-10 19:29:05 --> Controller Class Initialized
INFO - 2018-02-10 19:29:05 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 19:29:05 --> Final output sent to browser
DEBUG - 2018-02-10 19:29:05 --> Total execution time: 0.0747
INFO - 2018-02-10 19:29:05 --> Config Class Initialized
INFO - 2018-02-10 19:29:05 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:29:05 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:29:05 --> Utf8 Class Initialized
INFO - 2018-02-10 19:29:05 --> URI Class Initialized
INFO - 2018-02-10 19:29:05 --> Router Class Initialized
INFO - 2018-02-10 19:29:05 --> Output Class Initialized
INFO - 2018-02-10 19:29:05 --> Security Class Initialized
DEBUG - 2018-02-10 19:29:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:29:05 --> Input Class Initialized
INFO - 2018-02-10 19:29:05 --> Language Class Initialized
INFO - 2018-02-10 19:29:05 --> Loader Class Initialized
INFO - 2018-02-10 19:29:05 --> Helper loaded: url_helper
INFO - 2018-02-10 19:29:05 --> Helper loaded: form_helper
INFO - 2018-02-10 19:29:05 --> Database Driver Class Initialized
DEBUG - 2018-02-10 19:29:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 19:29:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 19:29:05 --> Form Validation Class Initialized
INFO - 2018-02-10 19:29:05 --> Model Class Initialized
INFO - 2018-02-10 19:29:05 --> Controller Class Initialized
INFO - 2018-02-10 19:29:05 --> Model Class Initialized
INFO - 2018-02-10 19:29:05 --> Model Class Initialized
INFO - 2018-02-10 19:29:05 --> Model Class Initialized
INFO - 2018-02-10 19:29:05 --> Model Class Initialized
DEBUG - 2018-02-10 19:29:05 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-10 19:29:05 --> Severity: Notice --> Use of undefined constant usuario_id - assumed 'usuario_id' D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Proyecto.php 455
ERROR - 2018-02-10 19:29:05 --> Severity: Notice --> Object of class Proyecto could not be converted to int D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Proyecto.php 455
INFO - 2018-02-10 19:29:10 --> Config Class Initialized
INFO - 2018-02-10 19:29:10 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:29:10 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:29:10 --> Utf8 Class Initialized
INFO - 2018-02-10 19:29:10 --> URI Class Initialized
DEBUG - 2018-02-10 19:29:10 --> No URI present. Default controller set.
INFO - 2018-02-10 19:29:10 --> Router Class Initialized
INFO - 2018-02-10 19:29:10 --> Output Class Initialized
INFO - 2018-02-10 19:29:10 --> Security Class Initialized
DEBUG - 2018-02-10 19:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:29:10 --> Input Class Initialized
INFO - 2018-02-10 19:29:10 --> Language Class Initialized
INFO - 2018-02-10 19:29:10 --> Loader Class Initialized
INFO - 2018-02-10 19:29:10 --> Helper loaded: url_helper
INFO - 2018-02-10 19:29:10 --> Helper loaded: form_helper
INFO - 2018-02-10 19:29:10 --> Database Driver Class Initialized
DEBUG - 2018-02-10 19:29:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 19:29:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 19:29:10 --> Form Validation Class Initialized
INFO - 2018-02-10 19:29:10 --> Model Class Initialized
INFO - 2018-02-10 19:29:10 --> Controller Class Initialized
INFO - 2018-02-10 19:29:10 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 19:29:10 --> Final output sent to browser
DEBUG - 2018-02-10 19:29:10 --> Total execution time: 0.0842
INFO - 2018-02-10 19:29:10 --> Config Class Initialized
INFO - 2018-02-10 19:29:10 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:29:10 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:29:10 --> Utf8 Class Initialized
INFO - 2018-02-10 19:29:10 --> URI Class Initialized
INFO - 2018-02-10 19:29:10 --> Router Class Initialized
INFO - 2018-02-10 19:29:10 --> Output Class Initialized
INFO - 2018-02-10 19:29:10 --> Security Class Initialized
DEBUG - 2018-02-10 19:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:29:10 --> Input Class Initialized
INFO - 2018-02-10 19:29:10 --> Language Class Initialized
INFO - 2018-02-10 19:29:10 --> Loader Class Initialized
INFO - 2018-02-10 19:29:10 --> Helper loaded: url_helper
INFO - 2018-02-10 19:29:10 --> Helper loaded: form_helper
INFO - 2018-02-10 19:29:10 --> Database Driver Class Initialized
DEBUG - 2018-02-10 19:29:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 19:29:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 19:29:10 --> Form Validation Class Initialized
INFO - 2018-02-10 19:29:10 --> Model Class Initialized
INFO - 2018-02-10 19:29:10 --> Controller Class Initialized
INFO - 2018-02-10 19:29:10 --> Model Class Initialized
INFO - 2018-02-10 19:29:10 --> Model Class Initialized
INFO - 2018-02-10 19:29:10 --> Model Class Initialized
INFO - 2018-02-10 19:29:10 --> Model Class Initialized
DEBUG - 2018-02-10 19:29:10 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-10 19:29:10 --> Severity: Notice --> Use of undefined constant usuario_id - assumed 'usuario_id' D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Proyecto.php 455
ERROR - 2018-02-10 19:29:10 --> Severity: Notice --> Object of class Proyecto could not be converted to int D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Proyecto.php 455
INFO - 2018-02-10 19:29:10 --> Config Class Initialized
INFO - 2018-02-10 19:29:10 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:29:10 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:29:10 --> Utf8 Class Initialized
INFO - 2018-02-10 19:29:10 --> URI Class Initialized
DEBUG - 2018-02-10 19:29:10 --> No URI present. Default controller set.
INFO - 2018-02-10 19:29:10 --> Router Class Initialized
INFO - 2018-02-10 19:29:10 --> Output Class Initialized
INFO - 2018-02-10 19:29:10 --> Security Class Initialized
DEBUG - 2018-02-10 19:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:29:10 --> Input Class Initialized
INFO - 2018-02-10 19:29:10 --> Language Class Initialized
INFO - 2018-02-10 19:29:10 --> Loader Class Initialized
INFO - 2018-02-10 19:29:10 --> Helper loaded: url_helper
INFO - 2018-02-10 19:29:10 --> Helper loaded: form_helper
INFO - 2018-02-10 19:29:10 --> Database Driver Class Initialized
DEBUG - 2018-02-10 19:29:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 19:29:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 19:29:10 --> Form Validation Class Initialized
INFO - 2018-02-10 19:29:10 --> Model Class Initialized
INFO - 2018-02-10 19:29:10 --> Controller Class Initialized
INFO - 2018-02-10 19:29:10 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 19:29:10 --> Final output sent to browser
DEBUG - 2018-02-10 19:29:10 --> Total execution time: 0.0938
INFO - 2018-02-10 19:29:11 --> Config Class Initialized
INFO - 2018-02-10 19:29:11 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:29:11 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:29:11 --> Utf8 Class Initialized
INFO - 2018-02-10 19:29:11 --> URI Class Initialized
INFO - 2018-02-10 19:29:11 --> Router Class Initialized
INFO - 2018-02-10 19:29:11 --> Output Class Initialized
INFO - 2018-02-10 19:29:11 --> Security Class Initialized
DEBUG - 2018-02-10 19:29:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:29:11 --> Input Class Initialized
INFO - 2018-02-10 19:29:11 --> Language Class Initialized
INFO - 2018-02-10 19:29:11 --> Loader Class Initialized
INFO - 2018-02-10 19:29:11 --> Helper loaded: url_helper
INFO - 2018-02-10 19:29:11 --> Config Class Initialized
INFO - 2018-02-10 19:29:11 --> Hooks Class Initialized
INFO - 2018-02-10 19:29:11 --> Helper loaded: form_helper
DEBUG - 2018-02-10 19:29:11 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:29:11 --> Utf8 Class Initialized
INFO - 2018-02-10 19:29:11 --> URI Class Initialized
DEBUG - 2018-02-10 19:29:11 --> No URI present. Default controller set.
INFO - 2018-02-10 19:29:11 --> Router Class Initialized
INFO - 2018-02-10 19:29:11 --> Database Driver Class Initialized
INFO - 2018-02-10 19:29:11 --> Output Class Initialized
INFO - 2018-02-10 19:29:11 --> Security Class Initialized
DEBUG - 2018-02-10 19:29:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-10 19:29:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 19:29:11 --> Input Class Initialized
INFO - 2018-02-10 19:29:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 19:29:11 --> Language Class Initialized
INFO - 2018-02-10 19:29:11 --> Form Validation Class Initialized
INFO - 2018-02-10 19:29:11 --> Loader Class Initialized
INFO - 2018-02-10 19:29:11 --> Model Class Initialized
INFO - 2018-02-10 19:29:11 --> Controller Class Initialized
INFO - 2018-02-10 19:29:11 --> Helper loaded: url_helper
INFO - 2018-02-10 19:29:11 --> Helper loaded: form_helper
INFO - 2018-02-10 19:29:11 --> Model Class Initialized
INFO - 2018-02-10 19:29:11 --> Model Class Initialized
INFO - 2018-02-10 19:29:11 --> Model Class Initialized
INFO - 2018-02-10 19:29:11 --> Model Class Initialized
DEBUG - 2018-02-10 19:29:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 19:29:11 --> Database Driver Class Initialized
ERROR - 2018-02-10 19:29:11 --> Severity: Notice --> Use of undefined constant usuario_id - assumed 'usuario_id' D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Proyecto.php 455
ERROR - 2018-02-10 19:29:11 --> Severity: Notice --> Object of class Proyecto could not be converted to int D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Proyecto.php 455
DEBUG - 2018-02-10 19:29:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 19:29:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 19:29:11 --> Form Validation Class Initialized
INFO - 2018-02-10 19:29:11 --> Model Class Initialized
INFO - 2018-02-10 19:29:11 --> Controller Class Initialized
INFO - 2018-02-10 19:29:11 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 19:29:11 --> Final output sent to browser
DEBUG - 2018-02-10 19:29:11 --> Total execution time: 0.0745
INFO - 2018-02-10 19:29:11 --> Config Class Initialized
INFO - 2018-02-10 19:29:11 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:29:11 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:29:11 --> Utf8 Class Initialized
INFO - 2018-02-10 19:29:11 --> URI Class Initialized
INFO - 2018-02-10 19:29:11 --> Router Class Initialized
INFO - 2018-02-10 19:29:11 --> Output Class Initialized
INFO - 2018-02-10 19:29:11 --> Security Class Initialized
DEBUG - 2018-02-10 19:29:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:29:11 --> Input Class Initialized
INFO - 2018-02-10 19:29:11 --> Language Class Initialized
INFO - 2018-02-10 19:29:11 --> Loader Class Initialized
INFO - 2018-02-10 19:29:11 --> Config Class Initialized
INFO - 2018-02-10 19:29:11 --> Helper loaded: url_helper
INFO - 2018-02-10 19:29:11 --> Hooks Class Initialized
INFO - 2018-02-10 19:29:11 --> Helper loaded: form_helper
DEBUG - 2018-02-10 19:29:11 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:29:11 --> Utf8 Class Initialized
INFO - 2018-02-10 19:29:11 --> URI Class Initialized
DEBUG - 2018-02-10 19:29:11 --> No URI present. Default controller set.
INFO - 2018-02-10 19:29:11 --> Router Class Initialized
INFO - 2018-02-10 19:29:11 --> Database Driver Class Initialized
INFO - 2018-02-10 19:29:11 --> Output Class Initialized
INFO - 2018-02-10 19:29:11 --> Security Class Initialized
DEBUG - 2018-02-10 19:29:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:29:11 --> Input Class Initialized
INFO - 2018-02-10 19:29:11 --> Language Class Initialized
DEBUG - 2018-02-10 19:29:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 19:29:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 19:29:11 --> Loader Class Initialized
INFO - 2018-02-10 19:29:11 --> Form Validation Class Initialized
INFO - 2018-02-10 19:29:11 --> Helper loaded: url_helper
INFO - 2018-02-10 19:29:11 --> Model Class Initialized
INFO - 2018-02-10 19:29:11 --> Controller Class Initialized
INFO - 2018-02-10 19:29:11 --> Helper loaded: form_helper
INFO - 2018-02-10 19:29:11 --> Model Class Initialized
INFO - 2018-02-10 19:29:11 --> Model Class Initialized
INFO - 2018-02-10 19:29:11 --> Model Class Initialized
INFO - 2018-02-10 19:29:11 --> Model Class Initialized
DEBUG - 2018-02-10 19:29:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 19:29:11 --> Database Driver Class Initialized
ERROR - 2018-02-10 19:29:11 --> Severity: Notice --> Use of undefined constant usuario_id - assumed 'usuario_id' D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Proyecto.php 455
ERROR - 2018-02-10 19:29:11 --> Severity: Notice --> Object of class Proyecto could not be converted to int D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Proyecto.php 455
DEBUG - 2018-02-10 19:29:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 19:29:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 19:29:11 --> Form Validation Class Initialized
INFO - 2018-02-10 19:29:11 --> Model Class Initialized
INFO - 2018-02-10 19:29:11 --> Controller Class Initialized
INFO - 2018-02-10 19:29:11 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 19:29:11 --> Final output sent to browser
DEBUG - 2018-02-10 19:29:11 --> Total execution time: 0.0529
INFO - 2018-02-10 19:29:11 --> Config Class Initialized
INFO - 2018-02-10 19:29:11 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:29:11 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:29:11 --> Utf8 Class Initialized
INFO - 2018-02-10 19:29:11 --> URI Class Initialized
INFO - 2018-02-10 19:29:11 --> Router Class Initialized
INFO - 2018-02-10 19:29:11 --> Output Class Initialized
INFO - 2018-02-10 19:29:11 --> Security Class Initialized
DEBUG - 2018-02-10 19:29:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:29:11 --> Input Class Initialized
INFO - 2018-02-10 19:29:11 --> Language Class Initialized
INFO - 2018-02-10 19:29:11 --> Loader Class Initialized
INFO - 2018-02-10 19:29:11 --> Helper loaded: url_helper
INFO - 2018-02-10 19:29:11 --> Helper loaded: form_helper
INFO - 2018-02-10 19:29:11 --> Database Driver Class Initialized
DEBUG - 2018-02-10 19:29:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 19:29:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 19:29:11 --> Form Validation Class Initialized
INFO - 2018-02-10 19:29:11 --> Model Class Initialized
INFO - 2018-02-10 19:29:11 --> Controller Class Initialized
INFO - 2018-02-10 19:29:11 --> Model Class Initialized
INFO - 2018-02-10 19:29:11 --> Model Class Initialized
INFO - 2018-02-10 19:29:11 --> Model Class Initialized
INFO - 2018-02-10 19:29:11 --> Model Class Initialized
DEBUG - 2018-02-10 19:29:11 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-10 19:29:11 --> Severity: Notice --> Use of undefined constant usuario_id - assumed 'usuario_id' D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Proyecto.php 455
ERROR - 2018-02-10 19:29:11 --> Severity: Notice --> Object of class Proyecto could not be converted to int D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Proyecto.php 455
INFO - 2018-02-10 19:29:57 --> Config Class Initialized
INFO - 2018-02-10 19:29:57 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:29:57 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:29:57 --> Utf8 Class Initialized
INFO - 2018-02-10 19:29:57 --> URI Class Initialized
DEBUG - 2018-02-10 19:29:57 --> No URI present. Default controller set.
INFO - 2018-02-10 19:29:57 --> Router Class Initialized
INFO - 2018-02-10 19:29:57 --> Output Class Initialized
INFO - 2018-02-10 19:29:57 --> Security Class Initialized
DEBUG - 2018-02-10 19:29:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:29:57 --> Input Class Initialized
INFO - 2018-02-10 19:29:57 --> Language Class Initialized
INFO - 2018-02-10 19:29:57 --> Loader Class Initialized
INFO - 2018-02-10 19:29:57 --> Helper loaded: url_helper
INFO - 2018-02-10 19:29:57 --> Helper loaded: form_helper
INFO - 2018-02-10 19:29:57 --> Database Driver Class Initialized
DEBUG - 2018-02-10 19:29:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 19:29:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 19:29:57 --> Form Validation Class Initialized
INFO - 2018-02-10 19:29:57 --> Model Class Initialized
INFO - 2018-02-10 19:29:57 --> Controller Class Initialized
INFO - 2018-02-10 19:29:57 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 19:29:57 --> Final output sent to browser
DEBUG - 2018-02-10 19:29:57 --> Total execution time: 0.0727
INFO - 2018-02-10 19:29:57 --> Config Class Initialized
INFO - 2018-02-10 19:29:57 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:29:57 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:29:57 --> Utf8 Class Initialized
INFO - 2018-02-10 19:29:57 --> URI Class Initialized
INFO - 2018-02-10 19:29:57 --> Router Class Initialized
INFO - 2018-02-10 19:29:57 --> Output Class Initialized
INFO - 2018-02-10 19:29:57 --> Security Class Initialized
DEBUG - 2018-02-10 19:29:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:29:57 --> Input Class Initialized
INFO - 2018-02-10 19:29:57 --> Language Class Initialized
INFO - 2018-02-10 19:29:57 --> Loader Class Initialized
INFO - 2018-02-10 19:29:57 --> Helper loaded: url_helper
INFO - 2018-02-10 19:29:57 --> Helper loaded: form_helper
INFO - 2018-02-10 19:29:57 --> Database Driver Class Initialized
DEBUG - 2018-02-10 19:29:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 19:29:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 19:29:57 --> Form Validation Class Initialized
INFO - 2018-02-10 19:29:57 --> Model Class Initialized
INFO - 2018-02-10 19:29:57 --> Controller Class Initialized
INFO - 2018-02-10 19:29:57 --> Model Class Initialized
INFO - 2018-02-10 19:29:57 --> Model Class Initialized
INFO - 2018-02-10 19:29:57 --> Model Class Initialized
INFO - 2018-02-10 19:29:57 --> Model Class Initialized
DEBUG - 2018-02-10 19:29:57 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-10 19:29:57 --> Severity: Notice --> Use of undefined constant usuario_id - assumed 'usuario_id' D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Proyecto.php 455
ERROR - 2018-02-10 19:29:57 --> Severity: Notice --> Object of class Proyecto could not be converted to int D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Proyecto.php 455
INFO - 2018-02-10 19:29:58 --> Config Class Initialized
INFO - 2018-02-10 19:29:58 --> Hooks Class Initialized
INFO - 2018-02-10 19:29:58 --> Config Class Initialized
INFO - 2018-02-10 19:29:58 --> Hooks Class Initialized
INFO - 2018-02-10 19:29:58 --> Config Class Initialized
INFO - 2018-02-10 19:29:58 --> Hooks Class Initialized
INFO - 2018-02-10 19:29:58 --> Config Class Initialized
INFO - 2018-02-10 19:29:58 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:29:58 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:29:58 --> Utf8 Class Initialized
DEBUG - 2018-02-10 19:29:58 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:29:58 --> URI Class Initialized
DEBUG - 2018-02-10 19:29:58 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:29:58 --> Utf8 Class Initialized
DEBUG - 2018-02-10 19:29:58 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:29:58 --> Utf8 Class Initialized
INFO - 2018-02-10 19:29:58 --> Utf8 Class Initialized
INFO - 2018-02-10 19:29:58 --> Router Class Initialized
INFO - 2018-02-10 19:29:58 --> URI Class Initialized
INFO - 2018-02-10 19:29:58 --> URI Class Initialized
INFO - 2018-02-10 19:29:58 --> URI Class Initialized
INFO - 2018-02-10 19:29:58 --> Router Class Initialized
INFO - 2018-02-10 19:29:58 --> Output Class Initialized
INFO - 2018-02-10 19:29:58 --> Router Class Initialized
INFO - 2018-02-10 19:29:58 --> Router Class Initialized
INFO - 2018-02-10 19:29:58 --> Security Class Initialized
INFO - 2018-02-10 19:29:58 --> Output Class Initialized
INFO - 2018-02-10 19:29:58 --> Output Class Initialized
INFO - 2018-02-10 19:29:58 --> Output Class Initialized
DEBUG - 2018-02-10 19:29:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:29:58 --> Security Class Initialized
INFO - 2018-02-10 19:29:58 --> Input Class Initialized
INFO - 2018-02-10 19:29:58 --> Security Class Initialized
INFO - 2018-02-10 19:29:58 --> Security Class Initialized
INFO - 2018-02-10 19:29:58 --> Language Class Initialized
DEBUG - 2018-02-10 19:29:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:29:58 --> Input Class Initialized
DEBUG - 2018-02-10 19:29:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-10 19:29:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:29:58 --> Input Class Initialized
INFO - 2018-02-10 19:29:58 --> Input Class Initialized
ERROR - 2018-02-10 19:29:58 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-10 19:29:58 --> Language Class Initialized
INFO - 2018-02-10 19:29:58 --> Language Class Initialized
INFO - 2018-02-10 19:29:58 --> Language Class Initialized
ERROR - 2018-02-10 19:29:58 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-10 19:29:58 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-10 19:29:58 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-10 19:29:58 --> Config Class Initialized
INFO - 2018-02-10 19:29:58 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:29:58 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:29:58 --> Utf8 Class Initialized
INFO - 2018-02-10 19:29:58 --> Config Class Initialized
INFO - 2018-02-10 19:29:58 --> Config Class Initialized
INFO - 2018-02-10 19:29:58 --> Hooks Class Initialized
INFO - 2018-02-10 19:29:58 --> Hooks Class Initialized
INFO - 2018-02-10 19:29:58 --> URI Class Initialized
INFO - 2018-02-10 19:29:58 --> Router Class Initialized
DEBUG - 2018-02-10 19:29:58 --> UTF-8 Support Enabled
DEBUG - 2018-02-10 19:29:58 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:29:58 --> Utf8 Class Initialized
INFO - 2018-02-10 19:29:58 --> Utf8 Class Initialized
INFO - 2018-02-10 19:29:58 --> Output Class Initialized
INFO - 2018-02-10 19:29:58 --> URI Class Initialized
INFO - 2018-02-10 19:29:58 --> URI Class Initialized
INFO - 2018-02-10 19:29:58 --> Security Class Initialized
INFO - 2018-02-10 19:29:58 --> Router Class Initialized
DEBUG - 2018-02-10 19:29:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:29:58 --> Input Class Initialized
INFO - 2018-02-10 19:29:58 --> Router Class Initialized
INFO - 2018-02-10 19:29:58 --> Language Class Initialized
INFO - 2018-02-10 19:29:58 --> Output Class Initialized
INFO - 2018-02-10 19:29:58 --> Output Class Initialized
ERROR - 2018-02-10 19:29:58 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-10 19:29:58 --> Security Class Initialized
INFO - 2018-02-10 19:29:58 --> Security Class Initialized
DEBUG - 2018-02-10 19:29:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:29:58 --> Input Class Initialized
DEBUG - 2018-02-10 19:29:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:29:58 --> Input Class Initialized
INFO - 2018-02-10 19:29:58 --> Language Class Initialized
INFO - 2018-02-10 19:29:58 --> Language Class Initialized
ERROR - 2018-02-10 19:29:58 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-10 19:29:58 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-10 19:33:48 --> Config Class Initialized
INFO - 2018-02-10 19:33:48 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:33:48 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:33:48 --> Utf8 Class Initialized
INFO - 2018-02-10 19:33:48 --> URI Class Initialized
DEBUG - 2018-02-10 19:33:48 --> No URI present. Default controller set.
INFO - 2018-02-10 19:33:48 --> Router Class Initialized
INFO - 2018-02-10 19:33:48 --> Output Class Initialized
INFO - 2018-02-10 19:33:48 --> Security Class Initialized
DEBUG - 2018-02-10 19:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:33:48 --> Input Class Initialized
INFO - 2018-02-10 19:33:48 --> Language Class Initialized
INFO - 2018-02-10 19:33:48 --> Loader Class Initialized
INFO - 2018-02-10 19:33:48 --> Helper loaded: url_helper
INFO - 2018-02-10 19:33:48 --> Helper loaded: form_helper
INFO - 2018-02-10 19:33:48 --> Database Driver Class Initialized
DEBUG - 2018-02-10 19:33:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 19:33:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 19:33:48 --> Form Validation Class Initialized
INFO - 2018-02-10 19:33:48 --> Model Class Initialized
INFO - 2018-02-10 19:33:48 --> Controller Class Initialized
INFO - 2018-02-10 19:33:48 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 19:33:48 --> Final output sent to browser
DEBUG - 2018-02-10 19:33:48 --> Total execution time: 0.0818
INFO - 2018-02-10 19:33:48 --> Config Class Initialized
INFO - 2018-02-10 19:33:48 --> Hooks Class Initialized
INFO - 2018-02-10 19:33:48 --> Config Class Initialized
INFO - 2018-02-10 19:33:48 --> Config Class Initialized
INFO - 2018-02-10 19:33:48 --> Hooks Class Initialized
INFO - 2018-02-10 19:33:48 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:33:48 --> UTF-8 Support Enabled
DEBUG - 2018-02-10 19:33:48 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:33:48 --> Utf8 Class Initialized
DEBUG - 2018-02-10 19:33:48 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:33:48 --> Utf8 Class Initialized
INFO - 2018-02-10 19:33:48 --> Utf8 Class Initialized
INFO - 2018-02-10 19:33:48 --> URI Class Initialized
INFO - 2018-02-10 19:33:48 --> URI Class Initialized
INFO - 2018-02-10 19:33:48 --> URI Class Initialized
INFO - 2018-02-10 19:33:48 --> Router Class Initialized
INFO - 2018-02-10 19:33:48 --> Router Class Initialized
INFO - 2018-02-10 19:33:48 --> Router Class Initialized
INFO - 2018-02-10 19:33:48 --> Output Class Initialized
INFO - 2018-02-10 19:33:48 --> Output Class Initialized
INFO - 2018-02-10 19:33:48 --> Output Class Initialized
INFO - 2018-02-10 19:33:48 --> Security Class Initialized
INFO - 2018-02-10 19:33:48 --> Security Class Initialized
INFO - 2018-02-10 19:33:48 --> Security Class Initialized
DEBUG - 2018-02-10 19:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:33:48 --> Input Class Initialized
DEBUG - 2018-02-10 19:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:33:48 --> Input Class Initialized
INFO - 2018-02-10 19:33:48 --> Language Class Initialized
DEBUG - 2018-02-10 19:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:33:48 --> Input Class Initialized
INFO - 2018-02-10 19:33:48 --> Language Class Initialized
ERROR - 2018-02-10 19:33:48 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-10 19:33:48 --> Language Class Initialized
ERROR - 2018-02-10 19:33:48 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-10 19:33:48 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-10 19:33:48 --> Config Class Initialized
INFO - 2018-02-10 19:33:48 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:33:48 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:33:48 --> Utf8 Class Initialized
INFO - 2018-02-10 19:33:48 --> URI Class Initialized
INFO - 2018-02-10 19:33:48 --> Router Class Initialized
INFO - 2018-02-10 19:33:48 --> Output Class Initialized
INFO - 2018-02-10 19:33:48 --> Security Class Initialized
DEBUG - 2018-02-10 19:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:33:48 --> Input Class Initialized
INFO - 2018-02-10 19:33:48 --> Language Class Initialized
ERROR - 2018-02-10 19:33:48 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-10 19:33:48 --> Config Class Initialized
INFO - 2018-02-10 19:33:48 --> Hooks Class Initialized
INFO - 2018-02-10 19:33:48 --> Config Class Initialized
INFO - 2018-02-10 19:33:48 --> Hooks Class Initialized
INFO - 2018-02-10 19:33:48 --> Config Class Initialized
INFO - 2018-02-10 19:33:48 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:33:48 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:33:48 --> Utf8 Class Initialized
DEBUG - 2018-02-10 19:33:48 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:33:48 --> Utf8 Class Initialized
DEBUG - 2018-02-10 19:33:48 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:33:48 --> URI Class Initialized
INFO - 2018-02-10 19:33:48 --> Utf8 Class Initialized
INFO - 2018-02-10 19:33:48 --> URI Class Initialized
INFO - 2018-02-10 19:33:48 --> URI Class Initialized
INFO - 2018-02-10 19:33:48 --> Router Class Initialized
INFO - 2018-02-10 19:33:48 --> Router Class Initialized
INFO - 2018-02-10 19:33:48 --> Router Class Initialized
INFO - 2018-02-10 19:33:48 --> Output Class Initialized
INFO - 2018-02-10 19:33:48 --> Output Class Initialized
INFO - 2018-02-10 19:33:48 --> Security Class Initialized
INFO - 2018-02-10 19:33:48 --> Security Class Initialized
INFO - 2018-02-10 19:33:48 --> Output Class Initialized
DEBUG - 2018-02-10 19:33:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-10 19:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:33:48 --> Input Class Initialized
INFO - 2018-02-10 19:33:48 --> Input Class Initialized
INFO - 2018-02-10 19:33:48 --> Security Class Initialized
INFO - 2018-02-10 19:33:48 --> Language Class Initialized
INFO - 2018-02-10 19:33:48 --> Language Class Initialized
DEBUG - 2018-02-10 19:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:33:48 --> Input Class Initialized
ERROR - 2018-02-10 19:33:48 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-10 19:33:48 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-10 19:33:48 --> Language Class Initialized
ERROR - 2018-02-10 19:33:48 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-10 19:33:48 --> Config Class Initialized
INFO - 2018-02-10 19:33:48 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:33:48 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:33:48 --> Utf8 Class Initialized
INFO - 2018-02-10 19:33:48 --> URI Class Initialized
INFO - 2018-02-10 19:33:48 --> Router Class Initialized
INFO - 2018-02-10 19:33:48 --> Output Class Initialized
INFO - 2018-02-10 19:33:48 --> Security Class Initialized
DEBUG - 2018-02-10 19:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:33:48 --> Input Class Initialized
INFO - 2018-02-10 19:33:48 --> Language Class Initialized
INFO - 2018-02-10 19:33:48 --> Loader Class Initialized
INFO - 2018-02-10 19:33:48 --> Helper loaded: url_helper
INFO - 2018-02-10 19:33:48 --> Helper loaded: form_helper
INFO - 2018-02-10 19:33:48 --> Database Driver Class Initialized
DEBUG - 2018-02-10 19:33:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 19:33:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 19:33:48 --> Form Validation Class Initialized
INFO - 2018-02-10 19:33:48 --> Model Class Initialized
INFO - 2018-02-10 19:33:48 --> Controller Class Initialized
INFO - 2018-02-10 19:33:48 --> Model Class Initialized
INFO - 2018-02-10 19:33:48 --> Model Class Initialized
INFO - 2018-02-10 19:33:48 --> Model Class Initialized
INFO - 2018-02-10 19:33:48 --> Model Class Initialized
DEBUG - 2018-02-10 19:33:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 19:34:54 --> Config Class Initialized
INFO - 2018-02-10 19:34:54 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:34:54 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:34:54 --> Utf8 Class Initialized
INFO - 2018-02-10 19:34:54 --> URI Class Initialized
DEBUG - 2018-02-10 19:34:54 --> No URI present. Default controller set.
INFO - 2018-02-10 19:34:54 --> Router Class Initialized
INFO - 2018-02-10 19:34:54 --> Output Class Initialized
INFO - 2018-02-10 19:34:54 --> Security Class Initialized
DEBUG - 2018-02-10 19:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:34:54 --> Input Class Initialized
INFO - 2018-02-10 19:34:54 --> Language Class Initialized
INFO - 2018-02-10 19:34:54 --> Loader Class Initialized
INFO - 2018-02-10 19:34:54 --> Helper loaded: url_helper
INFO - 2018-02-10 19:34:54 --> Helper loaded: form_helper
INFO - 2018-02-10 19:34:54 --> Database Driver Class Initialized
DEBUG - 2018-02-10 19:34:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 19:34:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 19:34:54 --> Form Validation Class Initialized
INFO - 2018-02-10 19:34:54 --> Model Class Initialized
INFO - 2018-02-10 19:34:54 --> Controller Class Initialized
INFO - 2018-02-10 19:34:54 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 19:34:54 --> Final output sent to browser
DEBUG - 2018-02-10 19:34:54 --> Total execution time: 0.0881
INFO - 2018-02-10 19:34:54 --> Config Class Initialized
INFO - 2018-02-10 19:34:54 --> Hooks Class Initialized
INFO - 2018-02-10 19:34:54 --> Config Class Initialized
INFO - 2018-02-10 19:34:54 --> Hooks Class Initialized
INFO - 2018-02-10 19:34:54 --> Config Class Initialized
INFO - 2018-02-10 19:34:54 --> Hooks Class Initialized
INFO - 2018-02-10 19:34:54 --> Config Class Initialized
INFO - 2018-02-10 19:34:54 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:34:54 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:34:54 --> Utf8 Class Initialized
DEBUG - 2018-02-10 19:34:54 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:34:54 --> Utf8 Class Initialized
DEBUG - 2018-02-10 19:34:54 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:34:54 --> URI Class Initialized
INFO - 2018-02-10 19:34:54 --> Utf8 Class Initialized
INFO - 2018-02-10 19:34:54 --> URI Class Initialized
DEBUG - 2018-02-10 19:34:54 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:34:54 --> Utf8 Class Initialized
INFO - 2018-02-10 19:34:54 --> URI Class Initialized
INFO - 2018-02-10 19:34:54 --> Router Class Initialized
INFO - 2018-02-10 19:34:54 --> URI Class Initialized
INFO - 2018-02-10 19:34:54 --> Router Class Initialized
INFO - 2018-02-10 19:34:54 --> Router Class Initialized
INFO - 2018-02-10 19:34:54 --> Output Class Initialized
INFO - 2018-02-10 19:34:54 --> Router Class Initialized
INFO - 2018-02-10 19:34:54 --> Output Class Initialized
INFO - 2018-02-10 19:34:54 --> Security Class Initialized
INFO - 2018-02-10 19:34:54 --> Output Class Initialized
DEBUG - 2018-02-10 19:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:34:54 --> Security Class Initialized
INFO - 2018-02-10 19:34:54 --> Output Class Initialized
INFO - 2018-02-10 19:34:54 --> Input Class Initialized
INFO - 2018-02-10 19:34:54 --> Security Class Initialized
INFO - 2018-02-10 19:34:54 --> Language Class Initialized
DEBUG - 2018-02-10 19:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:34:54 --> Security Class Initialized
INFO - 2018-02-10 19:34:54 --> Input Class Initialized
DEBUG - 2018-02-10 19:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:34:54 --> Input Class Initialized
INFO - 2018-02-10 19:34:54 --> Language Class Initialized
ERROR - 2018-02-10 19:34:54 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-02-10 19:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:34:54 --> Language Class Initialized
INFO - 2018-02-10 19:34:54 --> Input Class Initialized
ERROR - 2018-02-10 19:34:54 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-10 19:34:54 --> Language Class Initialized
ERROR - 2018-02-10 19:34:54 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-10 19:34:54 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-10 19:34:54 --> Config Class Initialized
INFO - 2018-02-10 19:34:54 --> Hooks Class Initialized
INFO - 2018-02-10 19:34:54 --> Config Class Initialized
INFO - 2018-02-10 19:34:54 --> Hooks Class Initialized
INFO - 2018-02-10 19:34:54 --> Config Class Initialized
INFO - 2018-02-10 19:34:54 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:34:54 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:34:54 --> Utf8 Class Initialized
DEBUG - 2018-02-10 19:34:54 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:34:54 --> URI Class Initialized
DEBUG - 2018-02-10 19:34:54 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:34:54 --> Utf8 Class Initialized
INFO - 2018-02-10 19:34:54 --> Utf8 Class Initialized
INFO - 2018-02-10 19:34:54 --> URI Class Initialized
INFO - 2018-02-10 19:34:54 --> URI Class Initialized
INFO - 2018-02-10 19:34:54 --> Router Class Initialized
INFO - 2018-02-10 19:34:54 --> Router Class Initialized
INFO - 2018-02-10 19:34:54 --> Output Class Initialized
INFO - 2018-02-10 19:34:54 --> Router Class Initialized
INFO - 2018-02-10 19:34:54 --> Output Class Initialized
INFO - 2018-02-10 19:34:54 --> Security Class Initialized
INFO - 2018-02-10 19:34:54 --> Output Class Initialized
INFO - 2018-02-10 19:34:54 --> Security Class Initialized
DEBUG - 2018-02-10 19:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:34:54 --> Input Class Initialized
INFO - 2018-02-10 19:34:54 --> Security Class Initialized
DEBUG - 2018-02-10 19:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:34:54 --> Input Class Initialized
INFO - 2018-02-10 19:34:54 --> Language Class Initialized
DEBUG - 2018-02-10 19:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:34:54 --> Input Class Initialized
INFO - 2018-02-10 19:34:54 --> Language Class Initialized
ERROR - 2018-02-10 19:34:54 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-10 19:34:54 --> Language Class Initialized
ERROR - 2018-02-10 19:34:54 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-10 19:34:54 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-10 19:34:54 --> Config Class Initialized
INFO - 2018-02-10 19:34:54 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:34:54 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:34:54 --> Utf8 Class Initialized
INFO - 2018-02-10 19:34:54 --> URI Class Initialized
INFO - 2018-02-10 19:34:54 --> Router Class Initialized
INFO - 2018-02-10 19:34:54 --> Output Class Initialized
INFO - 2018-02-10 19:34:54 --> Security Class Initialized
DEBUG - 2018-02-10 19:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:34:54 --> Input Class Initialized
INFO - 2018-02-10 19:34:54 --> Language Class Initialized
INFO - 2018-02-10 19:34:54 --> Loader Class Initialized
INFO - 2018-02-10 19:34:54 --> Helper loaded: url_helper
INFO - 2018-02-10 19:34:54 --> Helper loaded: form_helper
INFO - 2018-02-10 19:34:54 --> Database Driver Class Initialized
DEBUG - 2018-02-10 19:34:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 19:34:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 19:34:54 --> Form Validation Class Initialized
INFO - 2018-02-10 19:34:54 --> Model Class Initialized
INFO - 2018-02-10 19:34:54 --> Controller Class Initialized
INFO - 2018-02-10 19:34:54 --> Model Class Initialized
INFO - 2018-02-10 19:34:54 --> Model Class Initialized
INFO - 2018-02-10 19:34:54 --> Model Class Initialized
INFO - 2018-02-10 19:34:54 --> Model Class Initialized
DEBUG - 2018-02-10 19:34:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 19:37:05 --> Config Class Initialized
INFO - 2018-02-10 19:37:05 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:37:05 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:37:05 --> Utf8 Class Initialized
INFO - 2018-02-10 19:37:05 --> URI Class Initialized
DEBUG - 2018-02-10 19:37:05 --> No URI present. Default controller set.
INFO - 2018-02-10 19:37:05 --> Router Class Initialized
INFO - 2018-02-10 19:37:05 --> Output Class Initialized
INFO - 2018-02-10 19:37:05 --> Security Class Initialized
DEBUG - 2018-02-10 19:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:37:05 --> Input Class Initialized
INFO - 2018-02-10 19:37:05 --> Language Class Initialized
INFO - 2018-02-10 19:37:05 --> Loader Class Initialized
INFO - 2018-02-10 19:37:05 --> Helper loaded: url_helper
INFO - 2018-02-10 19:37:05 --> Helper loaded: form_helper
INFO - 2018-02-10 19:37:05 --> Database Driver Class Initialized
DEBUG - 2018-02-10 19:37:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 19:37:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 19:37:05 --> Form Validation Class Initialized
INFO - 2018-02-10 19:37:05 --> Model Class Initialized
INFO - 2018-02-10 19:37:05 --> Controller Class Initialized
ERROR - 2018-02-10 19:37:05 --> Severity: Notice --> Undefined property: General::$usuario_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\General.php 33
INFO - 2018-02-10 19:37:07 --> Config Class Initialized
INFO - 2018-02-10 19:37:07 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:37:07 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:37:07 --> Utf8 Class Initialized
INFO - 2018-02-10 19:37:07 --> URI Class Initialized
DEBUG - 2018-02-10 19:37:07 --> No URI present. Default controller set.
INFO - 2018-02-10 19:37:07 --> Router Class Initialized
INFO - 2018-02-10 19:37:07 --> Output Class Initialized
INFO - 2018-02-10 19:37:07 --> Security Class Initialized
DEBUG - 2018-02-10 19:37:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:37:07 --> Input Class Initialized
INFO - 2018-02-10 19:37:07 --> Language Class Initialized
INFO - 2018-02-10 19:37:07 --> Loader Class Initialized
INFO - 2018-02-10 19:37:07 --> Helper loaded: url_helper
INFO - 2018-02-10 19:37:07 --> Helper loaded: form_helper
INFO - 2018-02-10 19:37:07 --> Database Driver Class Initialized
DEBUG - 2018-02-10 19:37:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 19:37:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 19:37:07 --> Form Validation Class Initialized
INFO - 2018-02-10 19:37:07 --> Model Class Initialized
INFO - 2018-02-10 19:37:07 --> Controller Class Initialized
ERROR - 2018-02-10 19:37:07 --> Severity: Notice --> Undefined property: General::$usuario_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\General.php 33
INFO - 2018-02-10 19:41:49 --> Config Class Initialized
INFO - 2018-02-10 19:41:49 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:41:49 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:41:49 --> Utf8 Class Initialized
INFO - 2018-02-10 19:41:49 --> URI Class Initialized
DEBUG - 2018-02-10 19:41:49 --> No URI present. Default controller set.
INFO - 2018-02-10 19:41:49 --> Router Class Initialized
INFO - 2018-02-10 19:41:49 --> Output Class Initialized
INFO - 2018-02-10 19:41:49 --> Security Class Initialized
DEBUG - 2018-02-10 19:41:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:41:49 --> Input Class Initialized
INFO - 2018-02-10 19:41:49 --> Language Class Initialized
INFO - 2018-02-10 19:41:49 --> Loader Class Initialized
INFO - 2018-02-10 19:41:49 --> Helper loaded: url_helper
INFO - 2018-02-10 19:41:49 --> Helper loaded: form_helper
INFO - 2018-02-10 19:41:49 --> Database Driver Class Initialized
DEBUG - 2018-02-10 19:41:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 19:41:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 19:41:49 --> Form Validation Class Initialized
INFO - 2018-02-10 19:41:49 --> Model Class Initialized
INFO - 2018-02-10 19:41:49 --> Controller Class Initialized
INFO - 2018-02-10 19:42:32 --> Config Class Initialized
INFO - 2018-02-10 19:42:32 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:42:32 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:42:32 --> Utf8 Class Initialized
INFO - 2018-02-10 19:42:32 --> URI Class Initialized
DEBUG - 2018-02-10 19:42:32 --> No URI present. Default controller set.
INFO - 2018-02-10 19:42:32 --> Router Class Initialized
INFO - 2018-02-10 19:42:32 --> Output Class Initialized
INFO - 2018-02-10 19:42:32 --> Security Class Initialized
DEBUG - 2018-02-10 19:42:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:42:32 --> Input Class Initialized
INFO - 2018-02-10 19:42:32 --> Language Class Initialized
INFO - 2018-02-10 19:42:32 --> Loader Class Initialized
INFO - 2018-02-10 19:42:32 --> Helper loaded: url_helper
INFO - 2018-02-10 19:42:32 --> Helper loaded: form_helper
INFO - 2018-02-10 19:42:32 --> Database Driver Class Initialized
DEBUG - 2018-02-10 19:42:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 19:42:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 19:42:32 --> Form Validation Class Initialized
INFO - 2018-02-10 19:42:32 --> Model Class Initialized
INFO - 2018-02-10 19:42:32 --> Controller Class Initialized
INFO - 2018-02-10 19:42:32 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 19:42:32 --> Final output sent to browser
DEBUG - 2018-02-10 19:42:32 --> Total execution time: 0.1174
INFO - 2018-02-10 19:42:32 --> Config Class Initialized
INFO - 2018-02-10 19:42:32 --> Hooks Class Initialized
INFO - 2018-02-10 19:42:32 --> Config Class Initialized
INFO - 2018-02-10 19:42:32 --> Hooks Class Initialized
INFO - 2018-02-10 19:42:32 --> Config Class Initialized
INFO - 2018-02-10 19:42:32 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:42:32 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:42:32 --> Config Class Initialized
INFO - 2018-02-10 19:42:32 --> Utf8 Class Initialized
DEBUG - 2018-02-10 19:42:32 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:42:32 --> Hooks Class Initialized
INFO - 2018-02-10 19:42:32 --> Utf8 Class Initialized
DEBUG - 2018-02-10 19:42:32 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:42:32 --> Utf8 Class Initialized
INFO - 2018-02-10 19:42:32 --> URI Class Initialized
INFO - 2018-02-10 19:42:32 --> URI Class Initialized
INFO - 2018-02-10 19:42:32 --> URI Class Initialized
DEBUG - 2018-02-10 19:42:32 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:42:32 --> Router Class Initialized
INFO - 2018-02-10 19:42:32 --> Utf8 Class Initialized
INFO - 2018-02-10 19:42:32 --> Router Class Initialized
INFO - 2018-02-10 19:42:32 --> Router Class Initialized
INFO - 2018-02-10 19:42:32 --> URI Class Initialized
INFO - 2018-02-10 19:42:32 --> Output Class Initialized
INFO - 2018-02-10 19:42:32 --> Output Class Initialized
INFO - 2018-02-10 19:42:32 --> Output Class Initialized
INFO - 2018-02-10 19:42:32 --> Router Class Initialized
INFO - 2018-02-10 19:42:32 --> Security Class Initialized
INFO - 2018-02-10 19:42:32 --> Security Class Initialized
INFO - 2018-02-10 19:42:32 --> Security Class Initialized
DEBUG - 2018-02-10 19:42:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:42:32 --> Output Class Initialized
INFO - 2018-02-10 19:42:32 --> Input Class Initialized
DEBUG - 2018-02-10 19:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-10 19:42:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:42:32 --> Input Class Initialized
INFO - 2018-02-10 19:42:32 --> Input Class Initialized
INFO - 2018-02-10 19:42:32 --> Language Class Initialized
INFO - 2018-02-10 19:42:32 --> Language Class Initialized
INFO - 2018-02-10 19:42:32 --> Security Class Initialized
INFO - 2018-02-10 19:42:32 --> Language Class Initialized
ERROR - 2018-02-10 19:42:32 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-10 19:42:32 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-02-10 19:42:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-10 19:42:32 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-10 19:42:32 --> Input Class Initialized
INFO - 2018-02-10 19:42:32 --> Language Class Initialized
ERROR - 2018-02-10 19:42:32 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-10 19:42:32 --> Config Class Initialized
INFO - 2018-02-10 19:42:32 --> Config Class Initialized
INFO - 2018-02-10 19:42:32 --> Hooks Class Initialized
INFO - 2018-02-10 19:42:32 --> Config Class Initialized
INFO - 2018-02-10 19:42:32 --> Hooks Class Initialized
INFO - 2018-02-10 19:42:32 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:42:32 --> UTF-8 Support Enabled
DEBUG - 2018-02-10 19:42:32 --> UTF-8 Support Enabled
DEBUG - 2018-02-10 19:42:32 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:42:32 --> Utf8 Class Initialized
INFO - 2018-02-10 19:42:32 --> Utf8 Class Initialized
INFO - 2018-02-10 19:42:32 --> Utf8 Class Initialized
INFO - 2018-02-10 19:42:32 --> URI Class Initialized
INFO - 2018-02-10 19:42:32 --> URI Class Initialized
INFO - 2018-02-10 19:42:32 --> URI Class Initialized
INFO - 2018-02-10 19:42:32 --> Router Class Initialized
INFO - 2018-02-10 19:42:32 --> Router Class Initialized
INFO - 2018-02-10 19:42:32 --> Router Class Initialized
INFO - 2018-02-10 19:42:32 --> Output Class Initialized
INFO - 2018-02-10 19:42:32 --> Output Class Initialized
INFO - 2018-02-10 19:42:32 --> Output Class Initialized
INFO - 2018-02-10 19:42:32 --> Security Class Initialized
INFO - 2018-02-10 19:42:32 --> Security Class Initialized
INFO - 2018-02-10 19:42:32 --> Security Class Initialized
DEBUG - 2018-02-10 19:42:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:42:32 --> Input Class Initialized
DEBUG - 2018-02-10 19:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-10 19:42:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:42:32 --> Input Class Initialized
INFO - 2018-02-10 19:42:32 --> Input Class Initialized
INFO - 2018-02-10 19:42:32 --> Language Class Initialized
INFO - 2018-02-10 19:42:32 --> Language Class Initialized
INFO - 2018-02-10 19:42:32 --> Language Class Initialized
ERROR - 2018-02-10 19:42:32 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-10 19:42:32 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-10 19:42:32 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-10 19:42:32 --> Config Class Initialized
INFO - 2018-02-10 19:42:32 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:42:32 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:42:32 --> Utf8 Class Initialized
INFO - 2018-02-10 19:42:32 --> URI Class Initialized
INFO - 2018-02-10 19:42:32 --> Router Class Initialized
INFO - 2018-02-10 19:42:32 --> Output Class Initialized
INFO - 2018-02-10 19:42:32 --> Security Class Initialized
DEBUG - 2018-02-10 19:42:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:42:32 --> Input Class Initialized
INFO - 2018-02-10 19:42:32 --> Language Class Initialized
INFO - 2018-02-10 19:42:32 --> Loader Class Initialized
INFO - 2018-02-10 19:42:32 --> Helper loaded: url_helper
INFO - 2018-02-10 19:42:32 --> Helper loaded: form_helper
INFO - 2018-02-10 19:42:32 --> Database Driver Class Initialized
DEBUG - 2018-02-10 19:42:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 19:42:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 19:42:32 --> Form Validation Class Initialized
INFO - 2018-02-10 19:42:32 --> Model Class Initialized
INFO - 2018-02-10 19:42:32 --> Controller Class Initialized
INFO - 2018-02-10 19:42:32 --> Model Class Initialized
INFO - 2018-02-10 19:42:32 --> Model Class Initialized
INFO - 2018-02-10 19:42:32 --> Model Class Initialized
INFO - 2018-02-10 19:42:32 --> Model Class Initialized
DEBUG - 2018-02-10 19:42:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 19:42:34 --> Config Class Initialized
INFO - 2018-02-10 19:42:34 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:42:34 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:42:34 --> Utf8 Class Initialized
INFO - 2018-02-10 19:42:34 --> URI Class Initialized
DEBUG - 2018-02-10 19:42:34 --> No URI present. Default controller set.
INFO - 2018-02-10 19:42:34 --> Router Class Initialized
INFO - 2018-02-10 19:42:34 --> Output Class Initialized
INFO - 2018-02-10 19:42:34 --> Security Class Initialized
DEBUG - 2018-02-10 19:42:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:42:34 --> Input Class Initialized
INFO - 2018-02-10 19:42:34 --> Language Class Initialized
INFO - 2018-02-10 19:42:34 --> Loader Class Initialized
INFO - 2018-02-10 19:42:34 --> Helper loaded: url_helper
INFO - 2018-02-10 19:42:34 --> Helper loaded: form_helper
INFO - 2018-02-10 19:42:34 --> Database Driver Class Initialized
DEBUG - 2018-02-10 19:42:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 19:42:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 19:42:34 --> Form Validation Class Initialized
INFO - 2018-02-10 19:42:34 --> Model Class Initialized
INFO - 2018-02-10 19:42:34 --> Controller Class Initialized
INFO - 2018-02-10 19:42:34 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 19:42:34 --> Final output sent to browser
DEBUG - 2018-02-10 19:42:34 --> Total execution time: 0.0667
INFO - 2018-02-10 19:42:34 --> Config Class Initialized
INFO - 2018-02-10 19:42:34 --> Hooks Class Initialized
INFO - 2018-02-10 19:42:34 --> Config Class Initialized
INFO - 2018-02-10 19:42:34 --> Config Class Initialized
INFO - 2018-02-10 19:42:34 --> Hooks Class Initialized
INFO - 2018-02-10 19:42:34 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:42:34 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:42:34 --> Utf8 Class Initialized
DEBUG - 2018-02-10 19:42:34 --> UTF-8 Support Enabled
DEBUG - 2018-02-10 19:42:34 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:42:34 --> Utf8 Class Initialized
INFO - 2018-02-10 19:42:34 --> Utf8 Class Initialized
INFO - 2018-02-10 19:42:34 --> URI Class Initialized
INFO - 2018-02-10 19:42:34 --> URI Class Initialized
INFO - 2018-02-10 19:42:34 --> URI Class Initialized
INFO - 2018-02-10 19:42:34 --> Router Class Initialized
INFO - 2018-02-10 19:42:34 --> Router Class Initialized
INFO - 2018-02-10 19:42:34 --> Router Class Initialized
INFO - 2018-02-10 19:42:34 --> Output Class Initialized
INFO - 2018-02-10 19:42:34 --> Output Class Initialized
INFO - 2018-02-10 19:42:34 --> Output Class Initialized
INFO - 2018-02-10 19:42:34 --> Security Class Initialized
INFO - 2018-02-10 19:42:34 --> Security Class Initialized
INFO - 2018-02-10 19:42:34 --> Security Class Initialized
DEBUG - 2018-02-10 19:42:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-10 19:42:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-10 19:42:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:42:34 --> Input Class Initialized
INFO - 2018-02-10 19:42:34 --> Input Class Initialized
INFO - 2018-02-10 19:42:34 --> Input Class Initialized
INFO - 2018-02-10 19:42:34 --> Language Class Initialized
INFO - 2018-02-10 19:42:34 --> Language Class Initialized
INFO - 2018-02-10 19:42:34 --> Language Class Initialized
ERROR - 2018-02-10 19:42:34 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-10 19:42:34 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-10 19:42:34 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-10 19:42:34 --> Config Class Initialized
INFO - 2018-02-10 19:42:34 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:42:34 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:42:34 --> Utf8 Class Initialized
INFO - 2018-02-10 19:42:34 --> URI Class Initialized
INFO - 2018-02-10 19:42:34 --> Router Class Initialized
INFO - 2018-02-10 19:42:34 --> Output Class Initialized
INFO - 2018-02-10 19:42:34 --> Security Class Initialized
DEBUG - 2018-02-10 19:42:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:42:34 --> Input Class Initialized
INFO - 2018-02-10 19:42:34 --> Language Class Initialized
ERROR - 2018-02-10 19:42:34 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-10 19:42:34 --> Config Class Initialized
INFO - 2018-02-10 19:42:34 --> Hooks Class Initialized
INFO - 2018-02-10 19:42:34 --> Config Class Initialized
INFO - 2018-02-10 19:42:34 --> Config Class Initialized
INFO - 2018-02-10 19:42:34 --> Hooks Class Initialized
INFO - 2018-02-10 19:42:34 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:42:34 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:42:34 --> Utf8 Class Initialized
DEBUG - 2018-02-10 19:42:34 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:42:34 --> Utf8 Class Initialized
INFO - 2018-02-10 19:42:34 --> URI Class Initialized
DEBUG - 2018-02-10 19:42:34 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:42:34 --> Utf8 Class Initialized
INFO - 2018-02-10 19:42:34 --> URI Class Initialized
INFO - 2018-02-10 19:42:34 --> Router Class Initialized
INFO - 2018-02-10 19:42:34 --> URI Class Initialized
INFO - 2018-02-10 19:42:34 --> Router Class Initialized
INFO - 2018-02-10 19:42:34 --> Output Class Initialized
INFO - 2018-02-10 19:42:34 --> Router Class Initialized
INFO - 2018-02-10 19:42:34 --> Output Class Initialized
INFO - 2018-02-10 19:42:34 --> Security Class Initialized
INFO - 2018-02-10 19:42:34 --> Output Class Initialized
INFO - 2018-02-10 19:42:34 --> Security Class Initialized
DEBUG - 2018-02-10 19:42:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:42:34 --> Input Class Initialized
INFO - 2018-02-10 19:42:34 --> Security Class Initialized
DEBUG - 2018-02-10 19:42:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:42:34 --> Input Class Initialized
INFO - 2018-02-10 19:42:34 --> Language Class Initialized
DEBUG - 2018-02-10 19:42:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:42:34 --> Language Class Initialized
INFO - 2018-02-10 19:42:34 --> Input Class Initialized
ERROR - 2018-02-10 19:42:34 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-10 19:42:34 --> Language Class Initialized
ERROR - 2018-02-10 19:42:34 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-10 19:42:34 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-10 19:42:34 --> Config Class Initialized
INFO - 2018-02-10 19:42:34 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:42:34 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:42:34 --> Utf8 Class Initialized
INFO - 2018-02-10 19:42:34 --> URI Class Initialized
INFO - 2018-02-10 19:42:34 --> Router Class Initialized
INFO - 2018-02-10 19:42:34 --> Output Class Initialized
INFO - 2018-02-10 19:42:34 --> Security Class Initialized
DEBUG - 2018-02-10 19:42:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:42:34 --> Input Class Initialized
INFO - 2018-02-10 19:42:34 --> Language Class Initialized
INFO - 2018-02-10 19:42:34 --> Loader Class Initialized
INFO - 2018-02-10 19:42:34 --> Helper loaded: url_helper
INFO - 2018-02-10 19:42:34 --> Helper loaded: form_helper
INFO - 2018-02-10 19:42:34 --> Database Driver Class Initialized
DEBUG - 2018-02-10 19:42:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 19:42:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 19:42:34 --> Form Validation Class Initialized
INFO - 2018-02-10 19:42:34 --> Model Class Initialized
INFO - 2018-02-10 19:42:34 --> Controller Class Initialized
INFO - 2018-02-10 19:42:34 --> Model Class Initialized
INFO - 2018-02-10 19:42:34 --> Model Class Initialized
INFO - 2018-02-10 19:42:34 --> Model Class Initialized
INFO - 2018-02-10 19:42:34 --> Model Class Initialized
DEBUG - 2018-02-10 19:42:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 19:45:17 --> Config Class Initialized
INFO - 2018-02-10 19:45:17 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:45:17 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:45:17 --> Utf8 Class Initialized
INFO - 2018-02-10 19:45:17 --> URI Class Initialized
DEBUG - 2018-02-10 19:45:17 --> No URI present. Default controller set.
INFO - 2018-02-10 19:45:17 --> Router Class Initialized
INFO - 2018-02-10 19:45:17 --> Output Class Initialized
INFO - 2018-02-10 19:45:17 --> Security Class Initialized
DEBUG - 2018-02-10 19:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:45:17 --> Input Class Initialized
INFO - 2018-02-10 19:45:17 --> Language Class Initialized
INFO - 2018-02-10 19:45:17 --> Loader Class Initialized
INFO - 2018-02-10 19:45:17 --> Helper loaded: url_helper
INFO - 2018-02-10 19:45:17 --> Helper loaded: form_helper
INFO - 2018-02-10 19:45:17 --> Database Driver Class Initialized
DEBUG - 2018-02-10 19:45:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 19:45:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 19:45:17 --> Form Validation Class Initialized
INFO - 2018-02-10 19:45:17 --> Model Class Initialized
INFO - 2018-02-10 19:45:17 --> Controller Class Initialized
INFO - 2018-02-10 19:45:17 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 19:45:17 --> Final output sent to browser
DEBUG - 2018-02-10 19:45:17 --> Total execution time: 0.0717
INFO - 2018-02-10 19:45:17 --> Config Class Initialized
INFO - 2018-02-10 19:45:17 --> Hooks Class Initialized
INFO - 2018-02-10 19:45:17 --> Config Class Initialized
INFO - 2018-02-10 19:45:17 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:45:17 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:45:17 --> Config Class Initialized
INFO - 2018-02-10 19:45:17 --> Utf8 Class Initialized
INFO - 2018-02-10 19:45:17 --> Hooks Class Initialized
INFO - 2018-02-10 19:45:17 --> Config Class Initialized
DEBUG - 2018-02-10 19:45:17 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:45:17 --> Hooks Class Initialized
INFO - 2018-02-10 19:45:17 --> Utf8 Class Initialized
INFO - 2018-02-10 19:45:17 --> URI Class Initialized
INFO - 2018-02-10 19:45:17 --> URI Class Initialized
INFO - 2018-02-10 19:45:17 --> Router Class Initialized
DEBUG - 2018-02-10 19:45:17 --> UTF-8 Support Enabled
DEBUG - 2018-02-10 19:45:17 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:45:17 --> Router Class Initialized
INFO - 2018-02-10 19:45:17 --> Utf8 Class Initialized
INFO - 2018-02-10 19:45:17 --> Utf8 Class Initialized
INFO - 2018-02-10 19:45:17 --> URI Class Initialized
INFO - 2018-02-10 19:45:17 --> URI Class Initialized
INFO - 2018-02-10 19:45:17 --> Output Class Initialized
INFO - 2018-02-10 19:45:17 --> Output Class Initialized
INFO - 2018-02-10 19:45:17 --> Router Class Initialized
INFO - 2018-02-10 19:45:17 --> Security Class Initialized
INFO - 2018-02-10 19:45:17 --> Security Class Initialized
INFO - 2018-02-10 19:45:17 --> Router Class Initialized
DEBUG - 2018-02-10 19:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:45:17 --> Output Class Initialized
DEBUG - 2018-02-10 19:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:45:17 --> Input Class Initialized
INFO - 2018-02-10 19:45:17 --> Input Class Initialized
INFO - 2018-02-10 19:45:17 --> Language Class Initialized
INFO - 2018-02-10 19:45:17 --> Output Class Initialized
INFO - 2018-02-10 19:45:17 --> Language Class Initialized
INFO - 2018-02-10 19:45:17 --> Security Class Initialized
ERROR - 2018-02-10 19:45:17 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-10 19:45:17 --> Security Class Initialized
ERROR - 2018-02-10 19:45:17 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-02-10 19:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:45:17 --> Input Class Initialized
INFO - 2018-02-10 19:45:17 --> Language Class Initialized
DEBUG - 2018-02-10 19:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:45:17 --> Input Class Initialized
INFO - 2018-02-10 19:45:17 --> Language Class Initialized
ERROR - 2018-02-10 19:45:17 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-10 19:45:17 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-10 19:45:17 --> Config Class Initialized
INFO - 2018-02-10 19:45:17 --> Hooks Class Initialized
INFO - 2018-02-10 19:45:17 --> Config Class Initialized
INFO - 2018-02-10 19:45:17 --> Hooks Class Initialized
INFO - 2018-02-10 19:45:17 --> Config Class Initialized
INFO - 2018-02-10 19:45:17 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:45:17 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:45:17 --> Utf8 Class Initialized
INFO - 2018-02-10 19:45:17 --> URI Class Initialized
DEBUG - 2018-02-10 19:45:17 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:45:17 --> Utf8 Class Initialized
DEBUG - 2018-02-10 19:45:17 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:45:17 --> Router Class Initialized
INFO - 2018-02-10 19:45:17 --> Utf8 Class Initialized
INFO - 2018-02-10 19:45:17 --> URI Class Initialized
INFO - 2018-02-10 19:45:17 --> URI Class Initialized
INFO - 2018-02-10 19:45:17 --> Output Class Initialized
INFO - 2018-02-10 19:45:17 --> Router Class Initialized
INFO - 2018-02-10 19:45:17 --> Router Class Initialized
INFO - 2018-02-10 19:45:17 --> Security Class Initialized
INFO - 2018-02-10 19:45:17 --> Output Class Initialized
DEBUG - 2018-02-10 19:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:45:17 --> Input Class Initialized
INFO - 2018-02-10 19:45:17 --> Output Class Initialized
INFO - 2018-02-10 19:45:17 --> Security Class Initialized
INFO - 2018-02-10 19:45:17 --> Language Class Initialized
INFO - 2018-02-10 19:45:17 --> Security Class Initialized
DEBUG - 2018-02-10 19:45:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-10 19:45:17 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-10 19:45:17 --> Input Class Initialized
DEBUG - 2018-02-10 19:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:45:17 --> Language Class Initialized
INFO - 2018-02-10 19:45:17 --> Input Class Initialized
INFO - 2018-02-10 19:45:17 --> Language Class Initialized
ERROR - 2018-02-10 19:45:17 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-10 19:45:17 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-10 19:45:17 --> Config Class Initialized
INFO - 2018-02-10 19:45:17 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:45:17 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:45:17 --> Utf8 Class Initialized
INFO - 2018-02-10 19:45:17 --> URI Class Initialized
INFO - 2018-02-10 19:45:17 --> Router Class Initialized
INFO - 2018-02-10 19:45:17 --> Output Class Initialized
INFO - 2018-02-10 19:45:17 --> Security Class Initialized
DEBUG - 2018-02-10 19:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:45:18 --> Input Class Initialized
INFO - 2018-02-10 19:45:18 --> Language Class Initialized
INFO - 2018-02-10 19:45:18 --> Loader Class Initialized
INFO - 2018-02-10 19:45:18 --> Helper loaded: url_helper
INFO - 2018-02-10 19:45:18 --> Helper loaded: form_helper
INFO - 2018-02-10 19:45:18 --> Database Driver Class Initialized
DEBUG - 2018-02-10 19:45:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 19:45:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 19:45:18 --> Form Validation Class Initialized
INFO - 2018-02-10 19:45:18 --> Model Class Initialized
INFO - 2018-02-10 19:45:18 --> Controller Class Initialized
INFO - 2018-02-10 19:45:18 --> Model Class Initialized
INFO - 2018-02-10 19:45:18 --> Model Class Initialized
INFO - 2018-02-10 19:45:18 --> Model Class Initialized
INFO - 2018-02-10 19:45:18 --> Model Class Initialized
DEBUG - 2018-02-10 19:45:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 19:48:46 --> Config Class Initialized
INFO - 2018-02-10 19:48:46 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:48:46 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:48:46 --> Utf8 Class Initialized
INFO - 2018-02-10 19:48:46 --> URI Class Initialized
DEBUG - 2018-02-10 19:48:46 --> No URI present. Default controller set.
INFO - 2018-02-10 19:48:46 --> Router Class Initialized
INFO - 2018-02-10 19:48:46 --> Output Class Initialized
INFO - 2018-02-10 19:48:46 --> Security Class Initialized
DEBUG - 2018-02-10 19:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:48:46 --> Input Class Initialized
INFO - 2018-02-10 19:48:46 --> Language Class Initialized
INFO - 2018-02-10 19:48:46 --> Loader Class Initialized
INFO - 2018-02-10 19:48:46 --> Helper loaded: url_helper
INFO - 2018-02-10 19:48:46 --> Helper loaded: form_helper
INFO - 2018-02-10 19:48:46 --> Database Driver Class Initialized
DEBUG - 2018-02-10 19:48:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 19:48:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 19:48:46 --> Form Validation Class Initialized
INFO - 2018-02-10 19:48:46 --> Model Class Initialized
INFO - 2018-02-10 19:48:46 --> Controller Class Initialized
INFO - 2018-02-10 19:48:46 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 19:48:46 --> Final output sent to browser
DEBUG - 2018-02-10 19:48:46 --> Total execution time: 0.1409
INFO - 2018-02-10 19:48:46 --> Config Class Initialized
INFO - 2018-02-10 19:48:46 --> Config Class Initialized
INFO - 2018-02-10 19:48:46 --> Hooks Class Initialized
INFO - 2018-02-10 19:48:46 --> Hooks Class Initialized
INFO - 2018-02-10 19:48:46 --> Config Class Initialized
INFO - 2018-02-10 19:48:46 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:48:46 --> UTF-8 Support Enabled
DEBUG - 2018-02-10 19:48:46 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:48:46 --> Utf8 Class Initialized
INFO - 2018-02-10 19:48:46 --> Utf8 Class Initialized
INFO - 2018-02-10 19:48:46 --> Config Class Initialized
INFO - 2018-02-10 19:48:46 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:48:46 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:48:46 --> Utf8 Class Initialized
INFO - 2018-02-10 19:48:46 --> URI Class Initialized
INFO - 2018-02-10 19:48:46 --> URI Class Initialized
INFO - 2018-02-10 19:48:46 --> URI Class Initialized
INFO - 2018-02-10 19:48:46 --> Router Class Initialized
INFO - 2018-02-10 19:48:46 --> Router Class Initialized
DEBUG - 2018-02-10 19:48:46 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:48:46 --> Router Class Initialized
INFO - 2018-02-10 19:48:46 --> Utf8 Class Initialized
INFO - 2018-02-10 19:48:46 --> Output Class Initialized
INFO - 2018-02-10 19:48:46 --> URI Class Initialized
INFO - 2018-02-10 19:48:46 --> Output Class Initialized
INFO - 2018-02-10 19:48:46 --> Output Class Initialized
INFO - 2018-02-10 19:48:46 --> Security Class Initialized
INFO - 2018-02-10 19:48:46 --> Security Class Initialized
INFO - 2018-02-10 19:48:46 --> Security Class Initialized
INFO - 2018-02-10 19:48:46 --> Router Class Initialized
DEBUG - 2018-02-10 19:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:48:46 --> Input Class Initialized
DEBUG - 2018-02-10 19:48:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-10 19:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:48:46 --> Input Class Initialized
INFO - 2018-02-10 19:48:46 --> Input Class Initialized
INFO - 2018-02-10 19:48:46 --> Output Class Initialized
INFO - 2018-02-10 19:48:46 --> Language Class Initialized
INFO - 2018-02-10 19:48:46 --> Language Class Initialized
INFO - 2018-02-10 19:48:46 --> Language Class Initialized
INFO - 2018-02-10 19:48:46 --> Security Class Initialized
ERROR - 2018-02-10 19:48:46 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-10 19:48:46 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-10 19:48:46 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-02-10 19:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:48:46 --> Input Class Initialized
INFO - 2018-02-10 19:48:46 --> Language Class Initialized
ERROR - 2018-02-10 19:48:46 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-10 19:48:46 --> Config Class Initialized
INFO - 2018-02-10 19:48:46 --> Hooks Class Initialized
INFO - 2018-02-10 19:48:46 --> Config Class Initialized
INFO - 2018-02-10 19:48:46 --> Hooks Class Initialized
INFO - 2018-02-10 19:48:46 --> Config Class Initialized
INFO - 2018-02-10 19:48:46 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:48:46 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:48:46 --> Utf8 Class Initialized
DEBUG - 2018-02-10 19:48:46 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:48:46 --> Utf8 Class Initialized
INFO - 2018-02-10 19:48:46 --> URI Class Initialized
DEBUG - 2018-02-10 19:48:46 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:48:46 --> Utf8 Class Initialized
INFO - 2018-02-10 19:48:46 --> URI Class Initialized
INFO - 2018-02-10 19:48:46 --> URI Class Initialized
INFO - 2018-02-10 19:48:46 --> Router Class Initialized
INFO - 2018-02-10 19:48:46 --> Router Class Initialized
INFO - 2018-02-10 19:48:46 --> Router Class Initialized
INFO - 2018-02-10 19:48:46 --> Output Class Initialized
INFO - 2018-02-10 19:48:46 --> Output Class Initialized
INFO - 2018-02-10 19:48:46 --> Security Class Initialized
INFO - 2018-02-10 19:48:46 --> Output Class Initialized
INFO - 2018-02-10 19:48:46 --> Security Class Initialized
DEBUG - 2018-02-10 19:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:48:46 --> Security Class Initialized
INFO - 2018-02-10 19:48:46 --> Input Class Initialized
DEBUG - 2018-02-10 19:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:48:46 --> Input Class Initialized
INFO - 2018-02-10 19:48:46 --> Language Class Initialized
DEBUG - 2018-02-10 19:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:48:46 --> Language Class Initialized
INFO - 2018-02-10 19:48:46 --> Input Class Initialized
ERROR - 2018-02-10 19:48:46 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-10 19:48:46 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-10 19:48:46 --> Language Class Initialized
ERROR - 2018-02-10 19:48:46 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-10 19:48:46 --> Config Class Initialized
INFO - 2018-02-10 19:48:46 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:48:46 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:48:46 --> Utf8 Class Initialized
INFO - 2018-02-10 19:48:46 --> URI Class Initialized
INFO - 2018-02-10 19:48:46 --> Router Class Initialized
INFO - 2018-02-10 19:48:46 --> Output Class Initialized
INFO - 2018-02-10 19:48:46 --> Security Class Initialized
DEBUG - 2018-02-10 19:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:48:46 --> Input Class Initialized
INFO - 2018-02-10 19:48:46 --> Language Class Initialized
INFO - 2018-02-10 19:48:46 --> Loader Class Initialized
INFO - 2018-02-10 19:48:46 --> Helper loaded: url_helper
INFO - 2018-02-10 19:48:46 --> Helper loaded: form_helper
INFO - 2018-02-10 19:48:46 --> Database Driver Class Initialized
DEBUG - 2018-02-10 19:48:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 19:48:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 19:48:46 --> Form Validation Class Initialized
INFO - 2018-02-10 19:48:46 --> Model Class Initialized
INFO - 2018-02-10 19:48:46 --> Controller Class Initialized
INFO - 2018-02-10 19:48:46 --> Model Class Initialized
INFO - 2018-02-10 19:48:46 --> Model Class Initialized
INFO - 2018-02-10 19:48:46 --> Model Class Initialized
INFO - 2018-02-10 19:48:46 --> Model Class Initialized
DEBUG - 2018-02-10 19:48:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 19:48:47 --> Config Class Initialized
INFO - 2018-02-10 19:48:47 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:48:47 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:48:47 --> Utf8 Class Initialized
INFO - 2018-02-10 19:48:47 --> URI Class Initialized
DEBUG - 2018-02-10 19:48:47 --> No URI present. Default controller set.
INFO - 2018-02-10 19:48:47 --> Router Class Initialized
INFO - 2018-02-10 19:48:47 --> Output Class Initialized
INFO - 2018-02-10 19:48:47 --> Security Class Initialized
DEBUG - 2018-02-10 19:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:48:47 --> Input Class Initialized
INFO - 2018-02-10 19:48:47 --> Language Class Initialized
INFO - 2018-02-10 19:48:47 --> Loader Class Initialized
INFO - 2018-02-10 19:48:47 --> Helper loaded: url_helper
INFO - 2018-02-10 19:48:47 --> Helper loaded: form_helper
INFO - 2018-02-10 19:48:47 --> Database Driver Class Initialized
DEBUG - 2018-02-10 19:48:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 19:48:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 19:48:47 --> Form Validation Class Initialized
INFO - 2018-02-10 19:48:47 --> Model Class Initialized
INFO - 2018-02-10 19:48:47 --> Controller Class Initialized
INFO - 2018-02-10 19:48:47 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 19:48:47 --> Final output sent to browser
DEBUG - 2018-02-10 19:48:47 --> Total execution time: 0.0408
INFO - 2018-02-10 19:48:47 --> Config Class Initialized
INFO - 2018-02-10 19:48:47 --> Hooks Class Initialized
INFO - 2018-02-10 19:48:47 --> Config Class Initialized
INFO - 2018-02-10 19:48:47 --> Hooks Class Initialized
INFO - 2018-02-10 19:48:47 --> Config Class Initialized
INFO - 2018-02-10 19:48:47 --> Hooks Class Initialized
INFO - 2018-02-10 19:48:47 --> Config Class Initialized
INFO - 2018-02-10 19:48:47 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:48:47 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:48:47 --> Utf8 Class Initialized
DEBUG - 2018-02-10 19:48:47 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:48:47 --> Utf8 Class Initialized
DEBUG - 2018-02-10 19:48:47 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:48:47 --> URI Class Initialized
INFO - 2018-02-10 19:48:47 --> Utf8 Class Initialized
INFO - 2018-02-10 19:48:47 --> URI Class Initialized
DEBUG - 2018-02-10 19:48:47 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:48:47 --> Utf8 Class Initialized
INFO - 2018-02-10 19:48:47 --> URI Class Initialized
INFO - 2018-02-10 19:48:47 --> Router Class Initialized
INFO - 2018-02-10 19:48:47 --> URI Class Initialized
INFO - 2018-02-10 19:48:47 --> Router Class Initialized
INFO - 2018-02-10 19:48:47 --> Router Class Initialized
INFO - 2018-02-10 19:48:47 --> Output Class Initialized
INFO - 2018-02-10 19:48:47 --> Router Class Initialized
INFO - 2018-02-10 19:48:47 --> Output Class Initialized
INFO - 2018-02-10 19:48:47 --> Output Class Initialized
INFO - 2018-02-10 19:48:47 --> Security Class Initialized
INFO - 2018-02-10 19:48:47 --> Security Class Initialized
INFO - 2018-02-10 19:48:47 --> Output Class Initialized
INFO - 2018-02-10 19:48:47 --> Security Class Initialized
DEBUG - 2018-02-10 19:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:48:47 --> Input Class Initialized
DEBUG - 2018-02-10 19:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:48:47 --> Input Class Initialized
INFO - 2018-02-10 19:48:47 --> Security Class Initialized
DEBUG - 2018-02-10 19:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:48:47 --> Language Class Initialized
INFO - 2018-02-10 19:48:47 --> Input Class Initialized
INFO - 2018-02-10 19:48:47 --> Language Class Initialized
INFO - 2018-02-10 19:48:47 --> Language Class Initialized
DEBUG - 2018-02-10 19:48:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-10 19:48:47 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-10 19:48:47 --> Input Class Initialized
ERROR - 2018-02-10 19:48:47 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-10 19:48:47 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-10 19:48:47 --> Language Class Initialized
ERROR - 2018-02-10 19:48:47 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-10 19:48:47 --> Config Class Initialized
INFO - 2018-02-10 19:48:47 --> Config Class Initialized
INFO - 2018-02-10 19:48:47 --> Config Class Initialized
INFO - 2018-02-10 19:48:47 --> Hooks Class Initialized
INFO - 2018-02-10 19:48:47 --> Config Class Initialized
INFO - 2018-02-10 19:48:47 --> Hooks Class Initialized
INFO - 2018-02-10 19:48:47 --> Hooks Class Initialized
INFO - 2018-02-10 19:48:47 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:48:47 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:48:47 --> Utf8 Class Initialized
DEBUG - 2018-02-10 19:48:47 --> UTF-8 Support Enabled
DEBUG - 2018-02-10 19:48:47 --> UTF-8 Support Enabled
DEBUG - 2018-02-10 19:48:47 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:48:47 --> Utf8 Class Initialized
INFO - 2018-02-10 19:48:47 --> Utf8 Class Initialized
INFO - 2018-02-10 19:48:47 --> Utf8 Class Initialized
INFO - 2018-02-10 19:48:47 --> URI Class Initialized
INFO - 2018-02-10 19:48:47 --> URI Class Initialized
INFO - 2018-02-10 19:48:47 --> URI Class Initialized
INFO - 2018-02-10 19:48:47 --> URI Class Initialized
INFO - 2018-02-10 19:48:47 --> Router Class Initialized
INFO - 2018-02-10 19:48:47 --> Router Class Initialized
INFO - 2018-02-10 19:48:47 --> Router Class Initialized
INFO - 2018-02-10 19:48:47 --> Router Class Initialized
INFO - 2018-02-10 19:48:47 --> Output Class Initialized
INFO - 2018-02-10 19:48:47 --> Output Class Initialized
INFO - 2018-02-10 19:48:47 --> Output Class Initialized
INFO - 2018-02-10 19:48:47 --> Output Class Initialized
INFO - 2018-02-10 19:48:47 --> Security Class Initialized
INFO - 2018-02-10 19:48:47 --> Security Class Initialized
INFO - 2018-02-10 19:48:47 --> Security Class Initialized
INFO - 2018-02-10 19:48:47 --> Security Class Initialized
DEBUG - 2018-02-10 19:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:48:47 --> Input Class Initialized
DEBUG - 2018-02-10 19:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:48:47 --> Input Class Initialized
INFO - 2018-02-10 19:48:47 --> Language Class Initialized
DEBUG - 2018-02-10 19:48:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-10 19:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:48:47 --> Language Class Initialized
INFO - 2018-02-10 19:48:47 --> Input Class Initialized
INFO - 2018-02-10 19:48:47 --> Input Class Initialized
ERROR - 2018-02-10 19:48:47 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-10 19:48:47 --> Language Class Initialized
INFO - 2018-02-10 19:48:47 --> Language Class Initialized
ERROR - 2018-02-10 19:48:47 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-10 19:48:47 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-10 19:48:47 --> Loader Class Initialized
INFO - 2018-02-10 19:48:47 --> Helper loaded: url_helper
INFO - 2018-02-10 19:48:47 --> Helper loaded: form_helper
INFO - 2018-02-10 19:48:47 --> Database Driver Class Initialized
DEBUG - 2018-02-10 19:48:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 19:48:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 19:48:47 --> Form Validation Class Initialized
INFO - 2018-02-10 19:48:47 --> Model Class Initialized
INFO - 2018-02-10 19:48:47 --> Controller Class Initialized
INFO - 2018-02-10 19:48:47 --> Model Class Initialized
INFO - 2018-02-10 19:48:47 --> Model Class Initialized
INFO - 2018-02-10 19:48:47 --> Model Class Initialized
INFO - 2018-02-10 19:48:47 --> Model Class Initialized
DEBUG - 2018-02-10 19:48:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 19:49:15 --> Config Class Initialized
INFO - 2018-02-10 19:49:15 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:49:15 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:49:15 --> Utf8 Class Initialized
INFO - 2018-02-10 19:49:15 --> URI Class Initialized
DEBUG - 2018-02-10 19:49:15 --> No URI present. Default controller set.
INFO - 2018-02-10 19:49:15 --> Router Class Initialized
INFO - 2018-02-10 19:49:15 --> Output Class Initialized
INFO - 2018-02-10 19:49:15 --> Security Class Initialized
DEBUG - 2018-02-10 19:49:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:49:15 --> Input Class Initialized
INFO - 2018-02-10 19:49:15 --> Language Class Initialized
INFO - 2018-02-10 19:49:15 --> Loader Class Initialized
INFO - 2018-02-10 19:49:15 --> Helper loaded: url_helper
INFO - 2018-02-10 19:49:15 --> Helper loaded: form_helper
INFO - 2018-02-10 19:49:15 --> Database Driver Class Initialized
DEBUG - 2018-02-10 19:49:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 19:49:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 19:49:15 --> Form Validation Class Initialized
INFO - 2018-02-10 19:49:15 --> Model Class Initialized
INFO - 2018-02-10 19:49:15 --> Controller Class Initialized
INFO - 2018-02-10 19:49:15 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 19:49:15 --> Final output sent to browser
DEBUG - 2018-02-10 19:49:15 --> Total execution time: 0.1317
INFO - 2018-02-10 19:49:15 --> Config Class Initialized
INFO - 2018-02-10 19:49:15 --> Hooks Class Initialized
INFO - 2018-02-10 19:49:15 --> Config Class Initialized
INFO - 2018-02-10 19:49:15 --> Config Class Initialized
INFO - 2018-02-10 19:49:15 --> Hooks Class Initialized
INFO - 2018-02-10 19:49:15 --> Hooks Class Initialized
INFO - 2018-02-10 19:49:15 --> Config Class Initialized
INFO - 2018-02-10 19:49:15 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:49:15 --> UTF-8 Support Enabled
DEBUG - 2018-02-10 19:49:15 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:49:15 --> Utf8 Class Initialized
DEBUG - 2018-02-10 19:49:15 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:49:15 --> Utf8 Class Initialized
INFO - 2018-02-10 19:49:15 --> Utf8 Class Initialized
INFO - 2018-02-10 19:49:15 --> URI Class Initialized
INFO - 2018-02-10 19:49:15 --> URI Class Initialized
DEBUG - 2018-02-10 19:49:15 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:49:15 --> URI Class Initialized
INFO - 2018-02-10 19:49:15 --> Utf8 Class Initialized
INFO - 2018-02-10 19:49:15 --> Router Class Initialized
INFO - 2018-02-10 19:49:15 --> URI Class Initialized
INFO - 2018-02-10 19:49:15 --> Router Class Initialized
INFO - 2018-02-10 19:49:15 --> Router Class Initialized
INFO - 2018-02-10 19:49:15 --> Output Class Initialized
INFO - 2018-02-10 19:49:15 --> Router Class Initialized
INFO - 2018-02-10 19:49:15 --> Output Class Initialized
INFO - 2018-02-10 19:49:15 --> Output Class Initialized
INFO - 2018-02-10 19:49:15 --> Security Class Initialized
INFO - 2018-02-10 19:49:15 --> Security Class Initialized
INFO - 2018-02-10 19:49:15 --> Security Class Initialized
INFO - 2018-02-10 19:49:15 --> Output Class Initialized
DEBUG - 2018-02-10 19:49:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-10 19:49:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:49:15 --> Input Class Initialized
DEBUG - 2018-02-10 19:49:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:49:15 --> Input Class Initialized
INFO - 2018-02-10 19:49:15 --> Security Class Initialized
INFO - 2018-02-10 19:49:15 --> Input Class Initialized
INFO - 2018-02-10 19:49:15 --> Language Class Initialized
INFO - 2018-02-10 19:49:15 --> Language Class Initialized
INFO - 2018-02-10 19:49:15 --> Language Class Initialized
DEBUG - 2018-02-10 19:49:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:49:15 --> Input Class Initialized
ERROR - 2018-02-10 19:49:15 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-10 19:49:15 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-10 19:49:15 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-10 19:49:15 --> Language Class Initialized
ERROR - 2018-02-10 19:49:15 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-10 19:49:15 --> Config Class Initialized
INFO - 2018-02-10 19:49:15 --> Hooks Class Initialized
INFO - 2018-02-10 19:49:15 --> Config Class Initialized
INFO - 2018-02-10 19:49:15 --> Hooks Class Initialized
INFO - 2018-02-10 19:49:15 --> Config Class Initialized
INFO - 2018-02-10 19:49:15 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:49:15 --> UTF-8 Support Enabled
DEBUG - 2018-02-10 19:49:15 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:49:15 --> Utf8 Class Initialized
INFO - 2018-02-10 19:49:15 --> Utf8 Class Initialized
DEBUG - 2018-02-10 19:49:15 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:49:15 --> Utf8 Class Initialized
INFO - 2018-02-10 19:49:15 --> URI Class Initialized
INFO - 2018-02-10 19:49:15 --> URI Class Initialized
INFO - 2018-02-10 19:49:15 --> URI Class Initialized
INFO - 2018-02-10 19:49:15 --> Router Class Initialized
INFO - 2018-02-10 19:49:15 --> Router Class Initialized
INFO - 2018-02-10 19:49:15 --> Router Class Initialized
INFO - 2018-02-10 19:49:15 --> Output Class Initialized
INFO - 2018-02-10 19:49:15 --> Output Class Initialized
INFO - 2018-02-10 19:49:15 --> Output Class Initialized
INFO - 2018-02-10 19:49:15 --> Security Class Initialized
INFO - 2018-02-10 19:49:15 --> Security Class Initialized
INFO - 2018-02-10 19:49:15 --> Security Class Initialized
DEBUG - 2018-02-10 19:49:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:49:15 --> Input Class Initialized
DEBUG - 2018-02-10 19:49:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:49:15 --> Input Class Initialized
DEBUG - 2018-02-10 19:49:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:49:15 --> Language Class Initialized
INFO - 2018-02-10 19:49:15 --> Input Class Initialized
INFO - 2018-02-10 19:49:15 --> Language Class Initialized
INFO - 2018-02-10 19:49:15 --> Language Class Initialized
ERROR - 2018-02-10 19:49:15 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-10 19:49:15 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-10 19:49:15 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-10 19:49:15 --> Config Class Initialized
INFO - 2018-02-10 19:49:15 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:49:15 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:49:15 --> Utf8 Class Initialized
INFO - 2018-02-10 19:49:15 --> URI Class Initialized
INFO - 2018-02-10 19:49:15 --> Router Class Initialized
INFO - 2018-02-10 19:49:15 --> Output Class Initialized
INFO - 2018-02-10 19:49:15 --> Security Class Initialized
DEBUG - 2018-02-10 19:49:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:49:15 --> Input Class Initialized
INFO - 2018-02-10 19:49:15 --> Language Class Initialized
INFO - 2018-02-10 19:49:15 --> Loader Class Initialized
INFO - 2018-02-10 19:49:15 --> Helper loaded: url_helper
INFO - 2018-02-10 19:49:15 --> Helper loaded: form_helper
INFO - 2018-02-10 19:49:15 --> Database Driver Class Initialized
DEBUG - 2018-02-10 19:49:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 19:49:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 19:49:15 --> Form Validation Class Initialized
INFO - 2018-02-10 19:49:15 --> Model Class Initialized
INFO - 2018-02-10 19:49:15 --> Controller Class Initialized
INFO - 2018-02-10 19:49:15 --> Model Class Initialized
INFO - 2018-02-10 19:49:15 --> Model Class Initialized
INFO - 2018-02-10 19:49:15 --> Model Class Initialized
INFO - 2018-02-10 19:49:15 --> Model Class Initialized
DEBUG - 2018-02-10 19:49:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 19:52:34 --> Config Class Initialized
INFO - 2018-02-10 19:52:34 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:52:34 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:52:34 --> Utf8 Class Initialized
INFO - 2018-02-10 19:52:34 --> URI Class Initialized
DEBUG - 2018-02-10 19:52:34 --> No URI present. Default controller set.
INFO - 2018-02-10 19:52:34 --> Router Class Initialized
INFO - 2018-02-10 19:52:34 --> Output Class Initialized
INFO - 2018-02-10 19:52:34 --> Security Class Initialized
DEBUG - 2018-02-10 19:52:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:52:34 --> Input Class Initialized
INFO - 2018-02-10 19:52:34 --> Language Class Initialized
INFO - 2018-02-10 19:52:34 --> Loader Class Initialized
INFO - 2018-02-10 19:52:34 --> Helper loaded: url_helper
INFO - 2018-02-10 19:52:34 --> Helper loaded: form_helper
INFO - 2018-02-10 19:52:34 --> Database Driver Class Initialized
DEBUG - 2018-02-10 19:52:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 19:52:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 19:52:34 --> Form Validation Class Initialized
INFO - 2018-02-10 19:52:34 --> Model Class Initialized
INFO - 2018-02-10 19:52:34 --> Controller Class Initialized
INFO - 2018-02-10 19:52:34 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 19:52:34 --> Final output sent to browser
DEBUG - 2018-02-10 19:52:34 --> Total execution time: 0.0992
INFO - 2018-02-10 19:52:34 --> Config Class Initialized
INFO - 2018-02-10 19:52:34 --> Hooks Class Initialized
INFO - 2018-02-10 19:52:34 --> Config Class Initialized
INFO - 2018-02-10 19:52:34 --> Hooks Class Initialized
INFO - 2018-02-10 19:52:34 --> Config Class Initialized
INFO - 2018-02-10 19:52:34 --> Hooks Class Initialized
INFO - 2018-02-10 19:52:34 --> Config Class Initialized
INFO - 2018-02-10 19:52:34 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:52:34 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:52:34 --> Utf8 Class Initialized
INFO - 2018-02-10 19:52:34 --> URI Class Initialized
DEBUG - 2018-02-10 19:52:34 --> UTF-8 Support Enabled
DEBUG - 2018-02-10 19:52:34 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:52:34 --> Utf8 Class Initialized
DEBUG - 2018-02-10 19:52:34 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:52:34 --> Utf8 Class Initialized
INFO - 2018-02-10 19:52:34 --> Utf8 Class Initialized
INFO - 2018-02-10 19:52:34 --> URI Class Initialized
INFO - 2018-02-10 19:52:34 --> Router Class Initialized
INFO - 2018-02-10 19:52:34 --> URI Class Initialized
INFO - 2018-02-10 19:52:34 --> URI Class Initialized
INFO - 2018-02-10 19:52:34 --> Router Class Initialized
INFO - 2018-02-10 19:52:34 --> Output Class Initialized
INFO - 2018-02-10 19:52:34 --> Router Class Initialized
INFO - 2018-02-10 19:52:34 --> Router Class Initialized
INFO - 2018-02-10 19:52:34 --> Output Class Initialized
INFO - 2018-02-10 19:52:34 --> Security Class Initialized
INFO - 2018-02-10 19:52:34 --> Output Class Initialized
INFO - 2018-02-10 19:52:34 --> Output Class Initialized
INFO - 2018-02-10 19:52:34 --> Security Class Initialized
DEBUG - 2018-02-10 19:52:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:52:34 --> Security Class Initialized
INFO - 2018-02-10 19:52:34 --> Security Class Initialized
INFO - 2018-02-10 19:52:34 --> Input Class Initialized
DEBUG - 2018-02-10 19:52:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-10 19:52:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:52:34 --> Input Class Initialized
INFO - 2018-02-10 19:52:34 --> Input Class Initialized
INFO - 2018-02-10 19:52:34 --> Language Class Initialized
DEBUG - 2018-02-10 19:52:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:52:34 --> Input Class Initialized
INFO - 2018-02-10 19:52:34 --> Language Class Initialized
INFO - 2018-02-10 19:52:34 --> Language Class Initialized
INFO - 2018-02-10 19:52:34 --> Language Class Initialized
ERROR - 2018-02-10 19:52:34 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-10 19:52:34 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-10 19:52:34 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-10 19:52:34 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-10 19:52:34 --> Config Class Initialized
INFO - 2018-02-10 19:52:34 --> Config Class Initialized
INFO - 2018-02-10 19:52:34 --> Hooks Class Initialized
INFO - 2018-02-10 19:52:34 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:52:34 --> UTF-8 Support Enabled
DEBUG - 2018-02-10 19:52:34 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:52:34 --> Utf8 Class Initialized
INFO - 2018-02-10 19:52:34 --> Utf8 Class Initialized
INFO - 2018-02-10 19:52:34 --> Config Class Initialized
INFO - 2018-02-10 19:52:34 --> URI Class Initialized
INFO - 2018-02-10 19:52:34 --> Hooks Class Initialized
INFO - 2018-02-10 19:52:34 --> URI Class Initialized
INFO - 2018-02-10 19:52:34 --> Router Class Initialized
INFO - 2018-02-10 19:52:34 --> Router Class Initialized
DEBUG - 2018-02-10 19:52:34 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:52:34 --> Utf8 Class Initialized
INFO - 2018-02-10 19:52:34 --> Output Class Initialized
INFO - 2018-02-10 19:52:34 --> Output Class Initialized
INFO - 2018-02-10 19:52:34 --> URI Class Initialized
INFO - 2018-02-10 19:52:34 --> Security Class Initialized
INFO - 2018-02-10 19:52:34 --> Security Class Initialized
INFO - 2018-02-10 19:52:34 --> Router Class Initialized
DEBUG - 2018-02-10 19:52:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:52:34 --> Input Class Initialized
DEBUG - 2018-02-10 19:52:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:52:34 --> Input Class Initialized
INFO - 2018-02-10 19:52:34 --> Language Class Initialized
INFO - 2018-02-10 19:52:34 --> Output Class Initialized
INFO - 2018-02-10 19:52:34 --> Language Class Initialized
ERROR - 2018-02-10 19:52:34 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-10 19:52:34 --> Security Class Initialized
ERROR - 2018-02-10 19:52:34 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-02-10 19:52:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:52:34 --> Input Class Initialized
INFO - 2018-02-10 19:52:34 --> Language Class Initialized
ERROR - 2018-02-10 19:52:34 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-10 19:52:34 --> Config Class Initialized
INFO - 2018-02-10 19:52:34 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:52:34 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:52:34 --> Utf8 Class Initialized
INFO - 2018-02-10 19:52:34 --> URI Class Initialized
INFO - 2018-02-10 19:52:34 --> Router Class Initialized
INFO - 2018-02-10 19:52:34 --> Output Class Initialized
INFO - 2018-02-10 19:52:34 --> Security Class Initialized
DEBUG - 2018-02-10 19:52:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:52:34 --> Input Class Initialized
INFO - 2018-02-10 19:52:34 --> Language Class Initialized
INFO - 2018-02-10 19:52:34 --> Loader Class Initialized
INFO - 2018-02-10 19:52:34 --> Helper loaded: url_helper
INFO - 2018-02-10 19:52:34 --> Helper loaded: form_helper
INFO - 2018-02-10 19:52:34 --> Database Driver Class Initialized
DEBUG - 2018-02-10 19:52:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 19:52:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 19:52:34 --> Form Validation Class Initialized
INFO - 2018-02-10 19:52:34 --> Model Class Initialized
INFO - 2018-02-10 19:52:34 --> Controller Class Initialized
INFO - 2018-02-10 19:52:34 --> Model Class Initialized
INFO - 2018-02-10 19:52:34 --> Model Class Initialized
INFO - 2018-02-10 19:52:34 --> Model Class Initialized
INFO - 2018-02-10 19:52:34 --> Model Class Initialized
DEBUG - 2018-02-10 19:52:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 19:53:13 --> Config Class Initialized
INFO - 2018-02-10 19:53:13 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:53:13 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:53:13 --> Utf8 Class Initialized
INFO - 2018-02-10 19:53:13 --> URI Class Initialized
DEBUG - 2018-02-10 19:53:13 --> No URI present. Default controller set.
INFO - 2018-02-10 19:53:13 --> Router Class Initialized
INFO - 2018-02-10 19:53:13 --> Output Class Initialized
INFO - 2018-02-10 19:53:13 --> Security Class Initialized
DEBUG - 2018-02-10 19:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:53:13 --> Input Class Initialized
INFO - 2018-02-10 19:53:13 --> Language Class Initialized
INFO - 2018-02-10 19:53:13 --> Loader Class Initialized
INFO - 2018-02-10 19:53:13 --> Helper loaded: url_helper
INFO - 2018-02-10 19:53:13 --> Helper loaded: form_helper
INFO - 2018-02-10 19:53:13 --> Database Driver Class Initialized
DEBUG - 2018-02-10 19:53:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 19:53:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 19:53:13 --> Form Validation Class Initialized
INFO - 2018-02-10 19:53:13 --> Model Class Initialized
INFO - 2018-02-10 19:53:13 --> Controller Class Initialized
INFO - 2018-02-10 19:53:13 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 19:53:13 --> Final output sent to browser
DEBUG - 2018-02-10 19:53:13 --> Total execution time: 0.1123
INFO - 2018-02-10 19:53:13 --> Config Class Initialized
INFO - 2018-02-10 19:53:13 --> Hooks Class Initialized
INFO - 2018-02-10 19:53:13 --> Config Class Initialized
INFO - 2018-02-10 19:53:13 --> Hooks Class Initialized
INFO - 2018-02-10 19:53:13 --> Config Class Initialized
INFO - 2018-02-10 19:53:13 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:53:13 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:53:13 --> Utf8 Class Initialized
INFO - 2018-02-10 19:53:13 --> Config Class Initialized
DEBUG - 2018-02-10 19:53:13 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:53:13 --> Hooks Class Initialized
INFO - 2018-02-10 19:53:13 --> Utf8 Class Initialized
INFO - 2018-02-10 19:53:13 --> URI Class Initialized
DEBUG - 2018-02-10 19:53:13 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:53:13 --> Utf8 Class Initialized
INFO - 2018-02-10 19:53:13 --> URI Class Initialized
INFO - 2018-02-10 19:53:13 --> Router Class Initialized
INFO - 2018-02-10 19:53:13 --> URI Class Initialized
DEBUG - 2018-02-10 19:53:13 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:53:13 --> Utf8 Class Initialized
INFO - 2018-02-10 19:53:13 --> Router Class Initialized
INFO - 2018-02-10 19:53:13 --> Output Class Initialized
INFO - 2018-02-10 19:53:13 --> Router Class Initialized
INFO - 2018-02-10 19:53:13 --> URI Class Initialized
INFO - 2018-02-10 19:53:13 --> Security Class Initialized
INFO - 2018-02-10 19:53:13 --> Output Class Initialized
INFO - 2018-02-10 19:53:13 --> Output Class Initialized
INFO - 2018-02-10 19:53:13 --> Router Class Initialized
DEBUG - 2018-02-10 19:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:53:13 --> Input Class Initialized
INFO - 2018-02-10 19:53:13 --> Security Class Initialized
INFO - 2018-02-10 19:53:13 --> Security Class Initialized
INFO - 2018-02-10 19:53:13 --> Language Class Initialized
INFO - 2018-02-10 19:53:13 --> Output Class Initialized
DEBUG - 2018-02-10 19:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:53:13 --> Input Class Initialized
DEBUG - 2018-02-10 19:53:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-10 19:53:13 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-10 19:53:13 --> Input Class Initialized
INFO - 2018-02-10 19:53:13 --> Language Class Initialized
INFO - 2018-02-10 19:53:13 --> Security Class Initialized
INFO - 2018-02-10 19:53:13 --> Language Class Initialized
ERROR - 2018-02-10 19:53:13 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-02-10 19:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:53:13 --> Input Class Initialized
ERROR - 2018-02-10 19:53:13 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-10 19:53:13 --> Language Class Initialized
ERROR - 2018-02-10 19:53:13 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-10 19:53:13 --> Config Class Initialized
INFO - 2018-02-10 19:53:13 --> Hooks Class Initialized
INFO - 2018-02-10 19:53:13 --> Config Class Initialized
INFO - 2018-02-10 19:53:13 --> Config Class Initialized
INFO - 2018-02-10 19:53:13 --> Hooks Class Initialized
INFO - 2018-02-10 19:53:13 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:53:13 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:53:13 --> Utf8 Class Initialized
INFO - 2018-02-10 19:53:13 --> URI Class Initialized
DEBUG - 2018-02-10 19:53:13 --> UTF-8 Support Enabled
DEBUG - 2018-02-10 19:53:13 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:53:13 --> Utf8 Class Initialized
INFO - 2018-02-10 19:53:13 --> Utf8 Class Initialized
INFO - 2018-02-10 19:53:13 --> Router Class Initialized
INFO - 2018-02-10 19:53:13 --> URI Class Initialized
INFO - 2018-02-10 19:53:13 --> URI Class Initialized
INFO - 2018-02-10 19:53:13 --> Output Class Initialized
INFO - 2018-02-10 19:53:13 --> Router Class Initialized
INFO - 2018-02-10 19:53:13 --> Router Class Initialized
INFO - 2018-02-10 19:53:13 --> Security Class Initialized
INFO - 2018-02-10 19:53:13 --> Output Class Initialized
INFO - 2018-02-10 19:53:13 --> Output Class Initialized
DEBUG - 2018-02-10 19:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:53:13 --> Input Class Initialized
INFO - 2018-02-10 19:53:13 --> Security Class Initialized
INFO - 2018-02-10 19:53:13 --> Language Class Initialized
INFO - 2018-02-10 19:53:13 --> Security Class Initialized
DEBUG - 2018-02-10 19:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:53:13 --> Input Class Initialized
ERROR - 2018-02-10 19:53:13 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-02-10 19:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:53:13 --> Input Class Initialized
INFO - 2018-02-10 19:53:13 --> Language Class Initialized
INFO - 2018-02-10 19:53:13 --> Language Class Initialized
ERROR - 2018-02-10 19:53:13 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-10 19:53:13 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-10 19:53:13 --> Config Class Initialized
INFO - 2018-02-10 19:53:13 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:53:13 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:53:13 --> Utf8 Class Initialized
INFO - 2018-02-10 19:53:13 --> URI Class Initialized
INFO - 2018-02-10 19:53:13 --> Router Class Initialized
INFO - 2018-02-10 19:53:13 --> Output Class Initialized
INFO - 2018-02-10 19:53:14 --> Security Class Initialized
DEBUG - 2018-02-10 19:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:53:14 --> Input Class Initialized
INFO - 2018-02-10 19:53:14 --> Language Class Initialized
INFO - 2018-02-10 19:53:14 --> Loader Class Initialized
INFO - 2018-02-10 19:53:14 --> Helper loaded: url_helper
INFO - 2018-02-10 19:53:14 --> Helper loaded: form_helper
INFO - 2018-02-10 19:53:14 --> Database Driver Class Initialized
DEBUG - 2018-02-10 19:53:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 19:53:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 19:53:14 --> Form Validation Class Initialized
INFO - 2018-02-10 19:53:14 --> Model Class Initialized
INFO - 2018-02-10 19:53:14 --> Controller Class Initialized
INFO - 2018-02-10 19:53:14 --> Model Class Initialized
INFO - 2018-02-10 19:53:14 --> Model Class Initialized
INFO - 2018-02-10 19:53:14 --> Model Class Initialized
INFO - 2018-02-10 19:53:14 --> Model Class Initialized
DEBUG - 2018-02-10 19:53:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 19:53:14 --> Config Class Initialized
INFO - 2018-02-10 19:53:14 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:53:14 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:53:14 --> Utf8 Class Initialized
INFO - 2018-02-10 19:53:14 --> URI Class Initialized
DEBUG - 2018-02-10 19:53:14 --> No URI present. Default controller set.
INFO - 2018-02-10 19:53:14 --> Router Class Initialized
INFO - 2018-02-10 19:53:14 --> Output Class Initialized
INFO - 2018-02-10 19:53:14 --> Security Class Initialized
DEBUG - 2018-02-10 19:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:53:14 --> Input Class Initialized
INFO - 2018-02-10 19:53:14 --> Language Class Initialized
INFO - 2018-02-10 19:53:14 --> Loader Class Initialized
INFO - 2018-02-10 19:53:14 --> Helper loaded: url_helper
INFO - 2018-02-10 19:53:14 --> Helper loaded: form_helper
INFO - 2018-02-10 19:53:14 --> Database Driver Class Initialized
DEBUG - 2018-02-10 19:53:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 19:53:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 19:53:14 --> Form Validation Class Initialized
INFO - 2018-02-10 19:53:14 --> Model Class Initialized
INFO - 2018-02-10 19:53:14 --> Controller Class Initialized
INFO - 2018-02-10 19:53:14 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 19:53:14 --> Final output sent to browser
DEBUG - 2018-02-10 19:53:14 --> Total execution time: 0.0996
INFO - 2018-02-10 19:53:14 --> Config Class Initialized
INFO - 2018-02-10 19:53:14 --> Hooks Class Initialized
INFO - 2018-02-10 19:53:14 --> Config Class Initialized
INFO - 2018-02-10 19:53:14 --> Hooks Class Initialized
INFO - 2018-02-10 19:53:14 --> Config Class Initialized
INFO - 2018-02-10 19:53:14 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:53:14 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:53:14 --> Utf8 Class Initialized
INFO - 2018-02-10 19:53:14 --> Config Class Initialized
INFO - 2018-02-10 19:53:14 --> Hooks Class Initialized
INFO - 2018-02-10 19:53:14 --> URI Class Initialized
DEBUG - 2018-02-10 19:53:14 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:53:14 --> Utf8 Class Initialized
DEBUG - 2018-02-10 19:53:14 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:53:14 --> Utf8 Class Initialized
INFO - 2018-02-10 19:53:14 --> URI Class Initialized
INFO - 2018-02-10 19:53:14 --> Router Class Initialized
DEBUG - 2018-02-10 19:53:14 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:53:14 --> URI Class Initialized
INFO - 2018-02-10 19:53:14 --> Utf8 Class Initialized
INFO - 2018-02-10 19:53:14 --> Output Class Initialized
INFO - 2018-02-10 19:53:14 --> Router Class Initialized
INFO - 2018-02-10 19:53:14 --> URI Class Initialized
INFO - 2018-02-10 19:53:14 --> Router Class Initialized
INFO - 2018-02-10 19:53:14 --> Security Class Initialized
INFO - 2018-02-10 19:53:14 --> Output Class Initialized
INFO - 2018-02-10 19:53:14 --> Router Class Initialized
INFO - 2018-02-10 19:53:14 --> Output Class Initialized
DEBUG - 2018-02-10 19:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:53:14 --> Input Class Initialized
INFO - 2018-02-10 19:53:14 --> Security Class Initialized
INFO - 2018-02-10 19:53:14 --> Security Class Initialized
INFO - 2018-02-10 19:53:14 --> Language Class Initialized
INFO - 2018-02-10 19:53:14 --> Output Class Initialized
DEBUG - 2018-02-10 19:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:53:14 --> Input Class Initialized
DEBUG - 2018-02-10 19:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:53:14 --> Input Class Initialized
INFO - 2018-02-10 19:53:14 --> Language Class Initialized
ERROR - 2018-02-10 19:53:14 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-10 19:53:14 --> Security Class Initialized
INFO - 2018-02-10 19:53:14 --> Language Class Initialized
ERROR - 2018-02-10 19:53:14 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-02-10 19:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:53:14 --> Input Class Initialized
ERROR - 2018-02-10 19:53:14 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-10 19:53:14 --> Language Class Initialized
ERROR - 2018-02-10 19:53:14 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-10 19:53:14 --> Config Class Initialized
INFO - 2018-02-10 19:53:14 --> Hooks Class Initialized
INFO - 2018-02-10 19:53:14 --> Config Class Initialized
INFO - 2018-02-10 19:53:14 --> Config Class Initialized
INFO - 2018-02-10 19:53:14 --> Hooks Class Initialized
INFO - 2018-02-10 19:53:14 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:53:14 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:53:14 --> Utf8 Class Initialized
INFO - 2018-02-10 19:53:14 --> URI Class Initialized
DEBUG - 2018-02-10 19:53:14 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:53:14 --> Utf8 Class Initialized
DEBUG - 2018-02-10 19:53:14 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:53:14 --> Utf8 Class Initialized
INFO - 2018-02-10 19:53:14 --> Router Class Initialized
INFO - 2018-02-10 19:53:14 --> URI Class Initialized
INFO - 2018-02-10 19:53:14 --> URI Class Initialized
INFO - 2018-02-10 19:53:14 --> Output Class Initialized
INFO - 2018-02-10 19:53:14 --> Router Class Initialized
INFO - 2018-02-10 19:53:14 --> Router Class Initialized
INFO - 2018-02-10 19:53:14 --> Security Class Initialized
INFO - 2018-02-10 19:53:14 --> Output Class Initialized
INFO - 2018-02-10 19:53:14 --> Output Class Initialized
DEBUG - 2018-02-10 19:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:53:14 --> Input Class Initialized
INFO - 2018-02-10 19:53:14 --> Security Class Initialized
INFO - 2018-02-10 19:53:14 --> Security Class Initialized
INFO - 2018-02-10 19:53:14 --> Language Class Initialized
DEBUG - 2018-02-10 19:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:53:14 --> Input Class Initialized
DEBUG - 2018-02-10 19:53:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-10 19:53:14 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-10 19:53:14 --> Input Class Initialized
INFO - 2018-02-10 19:53:14 --> Language Class Initialized
INFO - 2018-02-10 19:53:14 --> Language Class Initialized
ERROR - 2018-02-10 19:53:14 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-10 19:53:14 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-10 19:53:14 --> Config Class Initialized
INFO - 2018-02-10 19:53:14 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:53:14 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:53:14 --> Utf8 Class Initialized
INFO - 2018-02-10 19:53:14 --> URI Class Initialized
INFO - 2018-02-10 19:53:14 --> Router Class Initialized
INFO - 2018-02-10 19:53:14 --> Output Class Initialized
INFO - 2018-02-10 19:53:14 --> Security Class Initialized
DEBUG - 2018-02-10 19:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:53:14 --> Input Class Initialized
INFO - 2018-02-10 19:53:14 --> Language Class Initialized
INFO - 2018-02-10 19:53:14 --> Loader Class Initialized
INFO - 2018-02-10 19:53:14 --> Helper loaded: url_helper
INFO - 2018-02-10 19:53:14 --> Helper loaded: form_helper
INFO - 2018-02-10 19:53:14 --> Database Driver Class Initialized
DEBUG - 2018-02-10 19:53:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 19:53:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 19:53:14 --> Form Validation Class Initialized
INFO - 2018-02-10 19:53:14 --> Model Class Initialized
INFO - 2018-02-10 19:53:14 --> Controller Class Initialized
INFO - 2018-02-10 19:53:14 --> Model Class Initialized
INFO - 2018-02-10 19:53:14 --> Model Class Initialized
INFO - 2018-02-10 19:53:14 --> Model Class Initialized
INFO - 2018-02-10 19:53:14 --> Model Class Initialized
DEBUG - 2018-02-10 19:53:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 19:53:53 --> Config Class Initialized
INFO - 2018-02-10 19:53:53 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:53:53 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:53:53 --> Utf8 Class Initialized
INFO - 2018-02-10 19:53:53 --> URI Class Initialized
DEBUG - 2018-02-10 19:53:53 --> No URI present. Default controller set.
INFO - 2018-02-10 19:53:53 --> Router Class Initialized
INFO - 2018-02-10 19:53:53 --> Output Class Initialized
INFO - 2018-02-10 19:53:53 --> Security Class Initialized
DEBUG - 2018-02-10 19:53:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:53:53 --> Input Class Initialized
INFO - 2018-02-10 19:53:53 --> Language Class Initialized
INFO - 2018-02-10 19:53:53 --> Loader Class Initialized
INFO - 2018-02-10 19:53:53 --> Helper loaded: url_helper
INFO - 2018-02-10 19:53:53 --> Helper loaded: form_helper
INFO - 2018-02-10 19:53:53 --> Database Driver Class Initialized
DEBUG - 2018-02-10 19:53:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 19:53:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 19:53:53 --> Form Validation Class Initialized
INFO - 2018-02-10 19:53:53 --> Model Class Initialized
INFO - 2018-02-10 19:53:53 --> Controller Class Initialized
INFO - 2018-02-10 19:53:53 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 19:53:53 --> Final output sent to browser
DEBUG - 2018-02-10 19:53:53 --> Total execution time: 0.0483
INFO - 2018-02-10 19:53:54 --> Config Class Initialized
INFO - 2018-02-10 19:53:54 --> Config Class Initialized
INFO - 2018-02-10 19:53:54 --> Hooks Class Initialized
INFO - 2018-02-10 19:53:54 --> Config Class Initialized
INFO - 2018-02-10 19:53:54 --> Hooks Class Initialized
INFO - 2018-02-10 19:53:54 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:53:54 --> UTF-8 Support Enabled
DEBUG - 2018-02-10 19:53:54 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:53:54 --> Utf8 Class Initialized
DEBUG - 2018-02-10 19:53:54 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:53:54 --> Utf8 Class Initialized
INFO - 2018-02-10 19:53:54 --> Utf8 Class Initialized
INFO - 2018-02-10 19:53:54 --> URI Class Initialized
INFO - 2018-02-10 19:53:54 --> URI Class Initialized
INFO - 2018-02-10 19:53:54 --> URI Class Initialized
INFO - 2018-02-10 19:53:54 --> Router Class Initialized
INFO - 2018-02-10 19:53:54 --> Router Class Initialized
INFO - 2018-02-10 19:53:54 --> Router Class Initialized
INFO - 2018-02-10 19:53:54 --> Output Class Initialized
INFO - 2018-02-10 19:53:54 --> Output Class Initialized
INFO - 2018-02-10 19:53:54 --> Output Class Initialized
INFO - 2018-02-10 19:53:54 --> Security Class Initialized
INFO - 2018-02-10 19:53:54 --> Security Class Initialized
INFO - 2018-02-10 19:53:54 --> Security Class Initialized
DEBUG - 2018-02-10 19:53:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-10 19:53:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-10 19:53:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:53:54 --> Input Class Initialized
INFO - 2018-02-10 19:53:54 --> Input Class Initialized
INFO - 2018-02-10 19:53:54 --> Input Class Initialized
INFO - 2018-02-10 19:53:54 --> Language Class Initialized
INFO - 2018-02-10 19:53:54 --> Language Class Initialized
INFO - 2018-02-10 19:53:54 --> Language Class Initialized
ERROR - 2018-02-10 19:53:54 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-10 19:53:54 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-10 19:53:54 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-10 19:53:54 --> Config Class Initialized
INFO - 2018-02-10 19:53:54 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:53:54 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:53:54 --> Utf8 Class Initialized
INFO - 2018-02-10 19:53:54 --> URI Class Initialized
INFO - 2018-02-10 19:53:54 --> Router Class Initialized
INFO - 2018-02-10 19:53:54 --> Output Class Initialized
INFO - 2018-02-10 19:53:54 --> Security Class Initialized
DEBUG - 2018-02-10 19:53:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:53:54 --> Input Class Initialized
INFO - 2018-02-10 19:53:54 --> Language Class Initialized
ERROR - 2018-02-10 19:53:54 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-10 19:53:54 --> Config Class Initialized
INFO - 2018-02-10 19:53:54 --> Hooks Class Initialized
INFO - 2018-02-10 19:53:54 --> Config Class Initialized
INFO - 2018-02-10 19:53:54 --> Hooks Class Initialized
INFO - 2018-02-10 19:53:54 --> Config Class Initialized
INFO - 2018-02-10 19:53:54 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:53:54 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:53:54 --> Utf8 Class Initialized
INFO - 2018-02-10 19:53:54 --> URI Class Initialized
DEBUG - 2018-02-10 19:53:54 --> UTF-8 Support Enabled
DEBUG - 2018-02-10 19:53:54 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:53:54 --> Utf8 Class Initialized
INFO - 2018-02-10 19:53:54 --> Utf8 Class Initialized
INFO - 2018-02-10 19:53:54 --> Router Class Initialized
INFO - 2018-02-10 19:53:54 --> URI Class Initialized
INFO - 2018-02-10 19:53:54 --> URI Class Initialized
INFO - 2018-02-10 19:53:54 --> Output Class Initialized
INFO - 2018-02-10 19:53:54 --> Router Class Initialized
INFO - 2018-02-10 19:53:54 --> Router Class Initialized
INFO - 2018-02-10 19:53:54 --> Security Class Initialized
INFO - 2018-02-10 19:53:54 --> Output Class Initialized
DEBUG - 2018-02-10 19:53:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:53:54 --> Output Class Initialized
INFO - 2018-02-10 19:53:54 --> Input Class Initialized
INFO - 2018-02-10 19:53:54 --> Security Class Initialized
INFO - 2018-02-10 19:53:54 --> Language Class Initialized
INFO - 2018-02-10 19:53:54 --> Security Class Initialized
DEBUG - 2018-02-10 19:53:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:53:54 --> Input Class Initialized
ERROR - 2018-02-10 19:53:54 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-02-10 19:53:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:53:54 --> Language Class Initialized
INFO - 2018-02-10 19:53:54 --> Input Class Initialized
INFO - 2018-02-10 19:53:54 --> Language Class Initialized
ERROR - 2018-02-10 19:53:54 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-10 19:53:54 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-10 19:53:54 --> Config Class Initialized
INFO - 2018-02-10 19:53:54 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:53:54 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:53:54 --> Utf8 Class Initialized
INFO - 2018-02-10 19:53:54 --> URI Class Initialized
INFO - 2018-02-10 19:53:54 --> Router Class Initialized
INFO - 2018-02-10 19:53:54 --> Output Class Initialized
INFO - 2018-02-10 19:53:54 --> Security Class Initialized
DEBUG - 2018-02-10 19:53:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:53:54 --> Input Class Initialized
INFO - 2018-02-10 19:53:54 --> Language Class Initialized
INFO - 2018-02-10 19:53:54 --> Loader Class Initialized
INFO - 2018-02-10 19:53:54 --> Helper loaded: url_helper
INFO - 2018-02-10 19:53:54 --> Helper loaded: form_helper
INFO - 2018-02-10 19:53:54 --> Database Driver Class Initialized
DEBUG - 2018-02-10 19:53:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 19:53:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 19:53:54 --> Form Validation Class Initialized
INFO - 2018-02-10 19:53:54 --> Model Class Initialized
INFO - 2018-02-10 19:53:54 --> Controller Class Initialized
INFO - 2018-02-10 19:53:54 --> Model Class Initialized
INFO - 2018-02-10 19:53:54 --> Model Class Initialized
INFO - 2018-02-10 19:53:54 --> Model Class Initialized
INFO - 2018-02-10 19:53:54 --> Model Class Initialized
DEBUG - 2018-02-10 19:53:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 19:54:55 --> Config Class Initialized
INFO - 2018-02-10 19:54:55 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:54:55 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:54:55 --> Utf8 Class Initialized
INFO - 2018-02-10 19:54:55 --> URI Class Initialized
DEBUG - 2018-02-10 19:54:55 --> No URI present. Default controller set.
INFO - 2018-02-10 19:54:55 --> Router Class Initialized
INFO - 2018-02-10 19:54:55 --> Output Class Initialized
INFO - 2018-02-10 19:54:55 --> Security Class Initialized
DEBUG - 2018-02-10 19:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:54:56 --> Input Class Initialized
INFO - 2018-02-10 19:54:56 --> Language Class Initialized
INFO - 2018-02-10 19:54:56 --> Loader Class Initialized
INFO - 2018-02-10 19:54:56 --> Helper loaded: url_helper
INFO - 2018-02-10 19:54:56 --> Helper loaded: form_helper
INFO - 2018-02-10 19:54:56 --> Database Driver Class Initialized
DEBUG - 2018-02-10 19:54:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 19:54:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 19:54:56 --> Form Validation Class Initialized
INFO - 2018-02-10 19:54:56 --> Model Class Initialized
INFO - 2018-02-10 19:54:56 --> Controller Class Initialized
INFO - 2018-02-10 19:54:56 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 19:54:56 --> Final output sent to browser
DEBUG - 2018-02-10 19:54:56 --> Total execution time: 0.1036
INFO - 2018-02-10 19:54:56 --> Config Class Initialized
INFO - 2018-02-10 19:54:56 --> Hooks Class Initialized
INFO - 2018-02-10 19:54:56 --> Config Class Initialized
INFO - 2018-02-10 19:54:56 --> Hooks Class Initialized
INFO - 2018-02-10 19:54:56 --> Config Class Initialized
INFO - 2018-02-10 19:54:56 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:54:56 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:54:56 --> Utf8 Class Initialized
INFO - 2018-02-10 19:54:56 --> Config Class Initialized
INFO - 2018-02-10 19:54:56 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:54:56 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:54:56 --> Utf8 Class Initialized
DEBUG - 2018-02-10 19:54:56 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:54:56 --> URI Class Initialized
INFO - 2018-02-10 19:54:56 --> Utf8 Class Initialized
INFO - 2018-02-10 19:54:56 --> URI Class Initialized
INFO - 2018-02-10 19:54:56 --> URI Class Initialized
INFO - 2018-02-10 19:54:56 --> Router Class Initialized
DEBUG - 2018-02-10 19:54:56 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:54:56 --> Utf8 Class Initialized
INFO - 2018-02-10 19:54:56 --> Router Class Initialized
INFO - 2018-02-10 19:54:56 --> Router Class Initialized
INFO - 2018-02-10 19:54:56 --> URI Class Initialized
INFO - 2018-02-10 19:54:56 --> Output Class Initialized
INFO - 2018-02-10 19:54:56 --> Output Class Initialized
INFO - 2018-02-10 19:54:56 --> Security Class Initialized
INFO - 2018-02-10 19:54:56 --> Output Class Initialized
INFO - 2018-02-10 19:54:56 --> Router Class Initialized
DEBUG - 2018-02-10 19:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:54:56 --> Security Class Initialized
INFO - 2018-02-10 19:54:56 --> Input Class Initialized
INFO - 2018-02-10 19:54:56 --> Security Class Initialized
INFO - 2018-02-10 19:54:56 --> Output Class Initialized
INFO - 2018-02-10 19:54:56 --> Language Class Initialized
DEBUG - 2018-02-10 19:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:54:56 --> Input Class Initialized
DEBUG - 2018-02-10 19:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:54:56 --> Security Class Initialized
INFO - 2018-02-10 19:54:56 --> Input Class Initialized
INFO - 2018-02-10 19:54:56 --> Language Class Initialized
ERROR - 2018-02-10 19:54:56 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-10 19:54:56 --> Language Class Initialized
DEBUG - 2018-02-10 19:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:54:56 --> Input Class Initialized
ERROR - 2018-02-10 19:54:56 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-10 19:54:56 --> Language Class Initialized
ERROR - 2018-02-10 19:54:56 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-10 19:54:56 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-10 19:54:56 --> Config Class Initialized
INFO - 2018-02-10 19:54:56 --> Config Class Initialized
INFO - 2018-02-10 19:54:56 --> Config Class Initialized
INFO - 2018-02-10 19:54:56 --> Hooks Class Initialized
INFO - 2018-02-10 19:54:56 --> Hooks Class Initialized
INFO - 2018-02-10 19:54:56 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:54:56 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:54:56 --> Utf8 Class Initialized
DEBUG - 2018-02-10 19:54:56 --> UTF-8 Support Enabled
DEBUG - 2018-02-10 19:54:56 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:54:56 --> Utf8 Class Initialized
INFO - 2018-02-10 19:54:56 --> Utf8 Class Initialized
INFO - 2018-02-10 19:54:56 --> URI Class Initialized
INFO - 2018-02-10 19:54:56 --> URI Class Initialized
INFO - 2018-02-10 19:54:56 --> URI Class Initialized
INFO - 2018-02-10 19:54:56 --> Router Class Initialized
INFO - 2018-02-10 19:54:56 --> Router Class Initialized
INFO - 2018-02-10 19:54:56 --> Router Class Initialized
INFO - 2018-02-10 19:54:56 --> Output Class Initialized
INFO - 2018-02-10 19:54:56 --> Output Class Initialized
INFO - 2018-02-10 19:54:56 --> Output Class Initialized
INFO - 2018-02-10 19:54:56 --> Security Class Initialized
INFO - 2018-02-10 19:54:56 --> Security Class Initialized
INFO - 2018-02-10 19:54:56 --> Security Class Initialized
DEBUG - 2018-02-10 19:54:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-10 19:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:54:56 --> Input Class Initialized
INFO - 2018-02-10 19:54:56 --> Input Class Initialized
DEBUG - 2018-02-10 19:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:54:56 --> Input Class Initialized
INFO - 2018-02-10 19:54:56 --> Language Class Initialized
INFO - 2018-02-10 19:54:56 --> Language Class Initialized
INFO - 2018-02-10 19:54:56 --> Language Class Initialized
ERROR - 2018-02-10 19:54:56 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-10 19:54:56 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-10 19:54:56 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-10 19:54:56 --> Config Class Initialized
INFO - 2018-02-10 19:54:56 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:54:56 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:54:56 --> Utf8 Class Initialized
INFO - 2018-02-10 19:54:56 --> URI Class Initialized
INFO - 2018-02-10 19:54:56 --> Router Class Initialized
INFO - 2018-02-10 19:54:56 --> Output Class Initialized
INFO - 2018-02-10 19:54:56 --> Security Class Initialized
DEBUG - 2018-02-10 19:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:54:56 --> Input Class Initialized
INFO - 2018-02-10 19:54:56 --> Language Class Initialized
INFO - 2018-02-10 19:54:56 --> Loader Class Initialized
INFO - 2018-02-10 19:54:56 --> Helper loaded: url_helper
INFO - 2018-02-10 19:54:56 --> Helper loaded: form_helper
INFO - 2018-02-10 19:54:56 --> Database Driver Class Initialized
DEBUG - 2018-02-10 19:54:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 19:54:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 19:54:56 --> Form Validation Class Initialized
INFO - 2018-02-10 19:54:56 --> Model Class Initialized
INFO - 2018-02-10 19:54:56 --> Controller Class Initialized
INFO - 2018-02-10 19:54:56 --> Model Class Initialized
INFO - 2018-02-10 19:54:56 --> Model Class Initialized
INFO - 2018-02-10 19:54:56 --> Model Class Initialized
INFO - 2018-02-10 19:54:56 --> Model Class Initialized
DEBUG - 2018-02-10 19:54:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 19:58:00 --> Config Class Initialized
INFO - 2018-02-10 19:58:00 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:58:00 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:58:00 --> Utf8 Class Initialized
INFO - 2018-02-10 19:58:00 --> URI Class Initialized
DEBUG - 2018-02-10 19:58:00 --> No URI present. Default controller set.
INFO - 2018-02-10 19:58:00 --> Router Class Initialized
INFO - 2018-02-10 19:58:00 --> Output Class Initialized
INFO - 2018-02-10 19:58:00 --> Security Class Initialized
DEBUG - 2018-02-10 19:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:58:00 --> Input Class Initialized
INFO - 2018-02-10 19:58:00 --> Language Class Initialized
INFO - 2018-02-10 19:58:00 --> Loader Class Initialized
INFO - 2018-02-10 19:58:00 --> Helper loaded: url_helper
INFO - 2018-02-10 19:58:00 --> Helper loaded: form_helper
INFO - 2018-02-10 19:58:00 --> Database Driver Class Initialized
DEBUG - 2018-02-10 19:58:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 19:58:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 19:58:00 --> Form Validation Class Initialized
INFO - 2018-02-10 19:58:00 --> Model Class Initialized
INFO - 2018-02-10 19:58:00 --> Controller Class Initialized
INFO - 2018-02-10 19:58:00 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 19:58:00 --> Final output sent to browser
DEBUG - 2018-02-10 19:58:00 --> Total execution time: 0.0693
INFO - 2018-02-10 19:58:01 --> Config Class Initialized
INFO - 2018-02-10 19:58:01 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:58:01 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:58:01 --> Utf8 Class Initialized
INFO - 2018-02-10 19:58:01 --> Config Class Initialized
INFO - 2018-02-10 19:58:01 --> Hooks Class Initialized
INFO - 2018-02-10 19:58:01 --> URI Class Initialized
INFO - 2018-02-10 19:58:01 --> Config Class Initialized
INFO - 2018-02-10 19:58:01 --> Hooks Class Initialized
INFO - 2018-02-10 19:58:01 --> Router Class Initialized
DEBUG - 2018-02-10 19:58:01 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:58:01 --> Config Class Initialized
DEBUG - 2018-02-10 19:58:01 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:58:01 --> Utf8 Class Initialized
INFO - 2018-02-10 19:58:01 --> Hooks Class Initialized
INFO - 2018-02-10 19:58:01 --> Utf8 Class Initialized
INFO - 2018-02-10 19:58:01 --> Output Class Initialized
INFO - 2018-02-10 19:58:01 --> URI Class Initialized
INFO - 2018-02-10 19:58:01 --> URI Class Initialized
INFO - 2018-02-10 19:58:01 --> Security Class Initialized
DEBUG - 2018-02-10 19:58:01 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:58:01 --> Utf8 Class Initialized
DEBUG - 2018-02-10 19:58:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:58:01 --> Router Class Initialized
INFO - 2018-02-10 19:58:01 --> Input Class Initialized
INFO - 2018-02-10 19:58:01 --> Router Class Initialized
INFO - 2018-02-10 19:58:01 --> URI Class Initialized
INFO - 2018-02-10 19:58:01 --> Language Class Initialized
INFO - 2018-02-10 19:58:01 --> Output Class Initialized
INFO - 2018-02-10 19:58:01 --> Router Class Initialized
ERROR - 2018-02-10 19:58:01 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-10 19:58:01 --> Output Class Initialized
INFO - 2018-02-10 19:58:01 --> Security Class Initialized
INFO - 2018-02-10 19:58:01 --> Security Class Initialized
INFO - 2018-02-10 19:58:01 --> Output Class Initialized
DEBUG - 2018-02-10 19:58:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:58:01 --> Input Class Initialized
DEBUG - 2018-02-10 19:58:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:58:01 --> Input Class Initialized
INFO - 2018-02-10 19:58:01 --> Language Class Initialized
INFO - 2018-02-10 19:58:01 --> Security Class Initialized
INFO - 2018-02-10 19:58:01 --> Language Class Initialized
ERROR - 2018-02-10 19:58:01 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-10 19:58:01 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-02-10 19:58:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:58:01 --> Input Class Initialized
INFO - 2018-02-10 19:58:01 --> Language Class Initialized
ERROR - 2018-02-10 19:58:01 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-10 19:58:01 --> Config Class Initialized
INFO - 2018-02-10 19:58:01 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:58:01 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:58:01 --> Utf8 Class Initialized
INFO - 2018-02-10 19:58:01 --> URI Class Initialized
INFO - 2018-02-10 19:58:01 --> Config Class Initialized
INFO - 2018-02-10 19:58:01 --> Hooks Class Initialized
INFO - 2018-02-10 19:58:01 --> Config Class Initialized
INFO - 2018-02-10 19:58:01 --> Router Class Initialized
INFO - 2018-02-10 19:58:01 --> Hooks Class Initialized
INFO - 2018-02-10 19:58:01 --> Output Class Initialized
DEBUG - 2018-02-10 19:58:01 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:58:01 --> Utf8 Class Initialized
DEBUG - 2018-02-10 19:58:01 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:58:01 --> Utf8 Class Initialized
INFO - 2018-02-10 19:58:01 --> Security Class Initialized
INFO - 2018-02-10 19:58:01 --> URI Class Initialized
INFO - 2018-02-10 19:58:01 --> URI Class Initialized
DEBUG - 2018-02-10 19:58:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:58:01 --> Input Class Initialized
INFO - 2018-02-10 19:58:01 --> Router Class Initialized
INFO - 2018-02-10 19:58:01 --> Language Class Initialized
INFO - 2018-02-10 19:58:01 --> Router Class Initialized
ERROR - 2018-02-10 19:58:01 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-10 19:58:01 --> Output Class Initialized
INFO - 2018-02-10 19:58:01 --> Output Class Initialized
INFO - 2018-02-10 19:58:01 --> Security Class Initialized
INFO - 2018-02-10 19:58:01 --> Security Class Initialized
DEBUG - 2018-02-10 19:58:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-10 19:58:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:58:01 --> Input Class Initialized
INFO - 2018-02-10 19:58:01 --> Input Class Initialized
INFO - 2018-02-10 19:58:01 --> Language Class Initialized
INFO - 2018-02-10 19:58:01 --> Language Class Initialized
ERROR - 2018-02-10 19:58:01 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-10 19:58:01 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-10 19:58:01 --> Config Class Initialized
INFO - 2018-02-10 19:58:01 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:58:01 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:58:01 --> Utf8 Class Initialized
INFO - 2018-02-10 19:58:01 --> URI Class Initialized
INFO - 2018-02-10 19:58:01 --> Router Class Initialized
INFO - 2018-02-10 19:58:01 --> Output Class Initialized
INFO - 2018-02-10 19:58:01 --> Security Class Initialized
DEBUG - 2018-02-10 19:58:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:58:01 --> Input Class Initialized
INFO - 2018-02-10 19:58:01 --> Language Class Initialized
INFO - 2018-02-10 19:58:01 --> Loader Class Initialized
INFO - 2018-02-10 19:58:01 --> Helper loaded: url_helper
INFO - 2018-02-10 19:58:01 --> Helper loaded: form_helper
INFO - 2018-02-10 19:58:01 --> Database Driver Class Initialized
DEBUG - 2018-02-10 19:58:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 19:58:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 19:58:01 --> Form Validation Class Initialized
INFO - 2018-02-10 19:58:01 --> Model Class Initialized
INFO - 2018-02-10 19:58:01 --> Controller Class Initialized
ERROR - 2018-02-10 19:58:01 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 176
INFO - 2018-02-10 19:58:18 --> Config Class Initialized
INFO - 2018-02-10 19:58:18 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:58:18 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:58:18 --> Utf8 Class Initialized
INFO - 2018-02-10 19:58:18 --> URI Class Initialized
DEBUG - 2018-02-10 19:58:18 --> No URI present. Default controller set.
INFO - 2018-02-10 19:58:18 --> Router Class Initialized
INFO - 2018-02-10 19:58:18 --> Output Class Initialized
INFO - 2018-02-10 19:58:18 --> Security Class Initialized
DEBUG - 2018-02-10 19:58:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:58:18 --> Input Class Initialized
INFO - 2018-02-10 19:58:18 --> Language Class Initialized
INFO - 2018-02-10 19:58:18 --> Loader Class Initialized
INFO - 2018-02-10 19:58:18 --> Helper loaded: url_helper
INFO - 2018-02-10 19:58:18 --> Helper loaded: form_helper
INFO - 2018-02-10 19:58:18 --> Database Driver Class Initialized
DEBUG - 2018-02-10 19:58:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 19:58:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 19:58:18 --> Form Validation Class Initialized
INFO - 2018-02-10 19:58:18 --> Model Class Initialized
INFO - 2018-02-10 19:58:18 --> Controller Class Initialized
INFO - 2018-02-10 19:58:18 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 19:58:18 --> Final output sent to browser
DEBUG - 2018-02-10 19:58:18 --> Total execution time: 0.0915
INFO - 2018-02-10 19:58:18 --> Config Class Initialized
INFO - 2018-02-10 19:58:18 --> Hooks Class Initialized
INFO - 2018-02-10 19:58:18 --> Config Class Initialized
INFO - 2018-02-10 19:58:18 --> Hooks Class Initialized
INFO - 2018-02-10 19:58:18 --> Config Class Initialized
INFO - 2018-02-10 19:58:18 --> Hooks Class Initialized
INFO - 2018-02-10 19:58:18 --> Config Class Initialized
DEBUG - 2018-02-10 19:58:18 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:58:18 --> Hooks Class Initialized
INFO - 2018-02-10 19:58:18 --> Utf8 Class Initialized
DEBUG - 2018-02-10 19:58:18 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:58:18 --> Utf8 Class Initialized
DEBUG - 2018-02-10 19:58:18 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:58:18 --> Utf8 Class Initialized
INFO - 2018-02-10 19:58:18 --> URI Class Initialized
INFO - 2018-02-10 19:58:18 --> URI Class Initialized
INFO - 2018-02-10 19:58:18 --> URI Class Initialized
DEBUG - 2018-02-10 19:58:18 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:58:18 --> Router Class Initialized
INFO - 2018-02-10 19:58:18 --> Utf8 Class Initialized
INFO - 2018-02-10 19:58:18 --> Router Class Initialized
INFO - 2018-02-10 19:58:18 --> URI Class Initialized
INFO - 2018-02-10 19:58:18 --> Router Class Initialized
INFO - 2018-02-10 19:58:18 --> Output Class Initialized
INFO - 2018-02-10 19:58:18 --> Output Class Initialized
INFO - 2018-02-10 19:58:18 --> Router Class Initialized
INFO - 2018-02-10 19:58:18 --> Output Class Initialized
INFO - 2018-02-10 19:58:18 --> Security Class Initialized
INFO - 2018-02-10 19:58:18 --> Security Class Initialized
DEBUG - 2018-02-10 19:58:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:58:18 --> Security Class Initialized
INFO - 2018-02-10 19:58:18 --> Input Class Initialized
INFO - 2018-02-10 19:58:18 --> Output Class Initialized
DEBUG - 2018-02-10 19:58:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:58:18 --> Language Class Initialized
INFO - 2018-02-10 19:58:18 --> Input Class Initialized
DEBUG - 2018-02-10 19:58:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:58:18 --> Input Class Initialized
INFO - 2018-02-10 19:58:18 --> Security Class Initialized
INFO - 2018-02-10 19:58:18 --> Language Class Initialized
ERROR - 2018-02-10 19:58:18 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-10 19:58:18 --> Language Class Initialized
DEBUG - 2018-02-10 19:58:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-10 19:58:18 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-10 19:58:18 --> Input Class Initialized
ERROR - 2018-02-10 19:58:18 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-10 19:58:18 --> Language Class Initialized
ERROR - 2018-02-10 19:58:18 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-10 19:58:18 --> Config Class Initialized
INFO - 2018-02-10 19:58:18 --> Hooks Class Initialized
INFO - 2018-02-10 19:58:18 --> Config Class Initialized
INFO - 2018-02-10 19:58:18 --> Hooks Class Initialized
INFO - 2018-02-10 19:58:18 --> Config Class Initialized
INFO - 2018-02-10 19:58:18 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:58:18 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:58:18 --> Utf8 Class Initialized
DEBUG - 2018-02-10 19:58:18 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:58:18 --> Utf8 Class Initialized
DEBUG - 2018-02-10 19:58:18 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:58:18 --> Utf8 Class Initialized
INFO - 2018-02-10 19:58:18 --> URI Class Initialized
INFO - 2018-02-10 19:58:18 --> URI Class Initialized
INFO - 2018-02-10 19:58:18 --> URI Class Initialized
INFO - 2018-02-10 19:58:18 --> Router Class Initialized
INFO - 2018-02-10 19:58:18 --> Router Class Initialized
INFO - 2018-02-10 19:58:18 --> Router Class Initialized
INFO - 2018-02-10 19:58:18 --> Output Class Initialized
INFO - 2018-02-10 19:58:18 --> Output Class Initialized
INFO - 2018-02-10 19:58:18 --> Output Class Initialized
INFO - 2018-02-10 19:58:18 --> Security Class Initialized
INFO - 2018-02-10 19:58:18 --> Security Class Initialized
INFO - 2018-02-10 19:58:18 --> Security Class Initialized
DEBUG - 2018-02-10 19:58:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-10 19:58:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-10 19:58:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:58:18 --> Input Class Initialized
INFO - 2018-02-10 19:58:18 --> Input Class Initialized
INFO - 2018-02-10 19:58:18 --> Input Class Initialized
INFO - 2018-02-10 19:58:18 --> Language Class Initialized
INFO - 2018-02-10 19:58:18 --> Language Class Initialized
INFO - 2018-02-10 19:58:18 --> Language Class Initialized
ERROR - 2018-02-10 19:58:18 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-10 19:58:18 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-10 19:58:18 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-10 19:58:18 --> Config Class Initialized
INFO - 2018-02-10 19:58:18 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:58:18 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:58:18 --> Utf8 Class Initialized
INFO - 2018-02-10 19:58:18 --> URI Class Initialized
INFO - 2018-02-10 19:58:18 --> Router Class Initialized
INFO - 2018-02-10 19:58:18 --> Output Class Initialized
INFO - 2018-02-10 19:58:18 --> Security Class Initialized
DEBUG - 2018-02-10 19:58:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:58:18 --> Input Class Initialized
INFO - 2018-02-10 19:58:18 --> Language Class Initialized
INFO - 2018-02-10 19:58:18 --> Loader Class Initialized
INFO - 2018-02-10 19:58:18 --> Helper loaded: url_helper
INFO - 2018-02-10 19:58:18 --> Helper loaded: form_helper
INFO - 2018-02-10 19:58:18 --> Database Driver Class Initialized
DEBUG - 2018-02-10 19:58:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 19:58:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 19:58:18 --> Form Validation Class Initialized
INFO - 2018-02-10 19:58:18 --> Model Class Initialized
INFO - 2018-02-10 19:58:18 --> Controller Class Initialized
INFO - 2018-02-10 19:58:18 --> Model Class Initialized
INFO - 2018-02-10 19:58:18 --> Model Class Initialized
INFO - 2018-02-10 19:58:18 --> Model Class Initialized
INFO - 2018-02-10 19:58:18 --> Model Class Initialized
DEBUG - 2018-02-10 19:58:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 19:58:31 --> Config Class Initialized
INFO - 2018-02-10 19:58:31 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:58:31 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:58:31 --> Utf8 Class Initialized
INFO - 2018-02-10 19:58:31 --> URI Class Initialized
DEBUG - 2018-02-10 19:58:31 --> No URI present. Default controller set.
INFO - 2018-02-10 19:58:31 --> Router Class Initialized
INFO - 2018-02-10 19:58:31 --> Output Class Initialized
INFO - 2018-02-10 19:58:31 --> Security Class Initialized
DEBUG - 2018-02-10 19:58:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:58:31 --> Input Class Initialized
INFO - 2018-02-10 19:58:31 --> Language Class Initialized
INFO - 2018-02-10 19:58:31 --> Loader Class Initialized
INFO - 2018-02-10 19:58:31 --> Helper loaded: url_helper
INFO - 2018-02-10 19:58:31 --> Helper loaded: form_helper
INFO - 2018-02-10 19:58:31 --> Database Driver Class Initialized
DEBUG - 2018-02-10 19:58:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 19:58:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 19:58:31 --> Form Validation Class Initialized
INFO - 2018-02-10 19:58:31 --> Model Class Initialized
INFO - 2018-02-10 19:58:31 --> Controller Class Initialized
INFO - 2018-02-10 19:58:31 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 19:58:31 --> Final output sent to browser
DEBUG - 2018-02-10 19:58:31 --> Total execution time: 0.0384
INFO - 2018-02-10 19:58:31 --> Config Class Initialized
INFO - 2018-02-10 19:58:31 --> Hooks Class Initialized
INFO - 2018-02-10 19:58:31 --> Config Class Initialized
INFO - 2018-02-10 19:58:31 --> Config Class Initialized
INFO - 2018-02-10 19:58:31 --> Hooks Class Initialized
INFO - 2018-02-10 19:58:31 --> Hooks Class Initialized
INFO - 2018-02-10 19:58:31 --> Config Class Initialized
INFO - 2018-02-10 19:58:31 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:58:31 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:58:31 --> Utf8 Class Initialized
DEBUG - 2018-02-10 19:58:31 --> UTF-8 Support Enabled
DEBUG - 2018-02-10 19:58:31 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:58:31 --> Utf8 Class Initialized
INFO - 2018-02-10 19:58:31 --> URI Class Initialized
INFO - 2018-02-10 19:58:31 --> Utf8 Class Initialized
DEBUG - 2018-02-10 19:58:31 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:58:31 --> Utf8 Class Initialized
INFO - 2018-02-10 19:58:31 --> URI Class Initialized
INFO - 2018-02-10 19:58:31 --> URI Class Initialized
INFO - 2018-02-10 19:58:31 --> URI Class Initialized
INFO - 2018-02-10 19:58:31 --> Router Class Initialized
INFO - 2018-02-10 19:58:31 --> Router Class Initialized
INFO - 2018-02-10 19:58:31 --> Router Class Initialized
INFO - 2018-02-10 19:58:31 --> Router Class Initialized
INFO - 2018-02-10 19:58:31 --> Output Class Initialized
INFO - 2018-02-10 19:58:31 --> Output Class Initialized
INFO - 2018-02-10 19:58:31 --> Output Class Initialized
INFO - 2018-02-10 19:58:31 --> Output Class Initialized
INFO - 2018-02-10 19:58:31 --> Security Class Initialized
INFO - 2018-02-10 19:58:31 --> Security Class Initialized
INFO - 2018-02-10 19:58:31 --> Security Class Initialized
INFO - 2018-02-10 19:58:31 --> Security Class Initialized
DEBUG - 2018-02-10 19:58:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-10 19:58:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:58:31 --> Input Class Initialized
INFO - 2018-02-10 19:58:31 --> Input Class Initialized
DEBUG - 2018-02-10 19:58:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-10 19:58:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:58:31 --> Language Class Initialized
INFO - 2018-02-10 19:58:31 --> Input Class Initialized
INFO - 2018-02-10 19:58:31 --> Input Class Initialized
INFO - 2018-02-10 19:58:31 --> Language Class Initialized
INFO - 2018-02-10 19:58:31 --> Language Class Initialized
INFO - 2018-02-10 19:58:31 --> Language Class Initialized
ERROR - 2018-02-10 19:58:31 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-10 19:58:31 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-10 19:58:31 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-10 19:58:31 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-10 19:58:31 --> Config Class Initialized
INFO - 2018-02-10 19:58:31 --> Hooks Class Initialized
INFO - 2018-02-10 19:58:31 --> Config Class Initialized
INFO - 2018-02-10 19:58:31 --> Hooks Class Initialized
INFO - 2018-02-10 19:58:31 --> Config Class Initialized
INFO - 2018-02-10 19:58:31 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:58:31 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:58:31 --> Utf8 Class Initialized
DEBUG - 2018-02-10 19:58:31 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:58:31 --> Utf8 Class Initialized
INFO - 2018-02-10 19:58:31 --> URI Class Initialized
DEBUG - 2018-02-10 19:58:31 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:58:31 --> URI Class Initialized
INFO - 2018-02-10 19:58:31 --> Utf8 Class Initialized
INFO - 2018-02-10 19:58:31 --> Router Class Initialized
INFO - 2018-02-10 19:58:31 --> URI Class Initialized
INFO - 2018-02-10 19:58:31 --> Router Class Initialized
INFO - 2018-02-10 19:58:31 --> Output Class Initialized
INFO - 2018-02-10 19:58:31 --> Router Class Initialized
INFO - 2018-02-10 19:58:31 --> Output Class Initialized
INFO - 2018-02-10 19:58:31 --> Security Class Initialized
INFO - 2018-02-10 19:58:31 --> Output Class Initialized
INFO - 2018-02-10 19:58:31 --> Security Class Initialized
DEBUG - 2018-02-10 19:58:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:58:31 --> Input Class Initialized
INFO - 2018-02-10 19:58:31 --> Security Class Initialized
INFO - 2018-02-10 19:58:31 --> Language Class Initialized
DEBUG - 2018-02-10 19:58:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:58:31 --> Input Class Initialized
DEBUG - 2018-02-10 19:58:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:58:31 --> Input Class Initialized
INFO - 2018-02-10 19:58:31 --> Language Class Initialized
ERROR - 2018-02-10 19:58:31 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-10 19:58:31 --> Language Class Initialized
ERROR - 2018-02-10 19:58:31 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-10 19:58:31 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-10 19:58:31 --> Config Class Initialized
INFO - 2018-02-10 19:58:31 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:58:31 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:58:31 --> Utf8 Class Initialized
INFO - 2018-02-10 19:58:31 --> URI Class Initialized
INFO - 2018-02-10 19:58:31 --> Router Class Initialized
INFO - 2018-02-10 19:58:31 --> Output Class Initialized
INFO - 2018-02-10 19:58:31 --> Security Class Initialized
DEBUG - 2018-02-10 19:58:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:58:31 --> Input Class Initialized
INFO - 2018-02-10 19:58:31 --> Language Class Initialized
INFO - 2018-02-10 19:58:31 --> Loader Class Initialized
INFO - 2018-02-10 19:58:31 --> Helper loaded: url_helper
INFO - 2018-02-10 19:58:31 --> Helper loaded: form_helper
INFO - 2018-02-10 19:58:31 --> Database Driver Class Initialized
DEBUG - 2018-02-10 19:58:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 19:58:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 19:58:31 --> Form Validation Class Initialized
INFO - 2018-02-10 19:58:31 --> Model Class Initialized
INFO - 2018-02-10 19:58:31 --> Controller Class Initialized
INFO - 2018-02-10 19:58:31 --> Model Class Initialized
INFO - 2018-02-10 19:58:31 --> Model Class Initialized
INFO - 2018-02-10 19:58:31 --> Model Class Initialized
INFO - 2018-02-10 19:58:31 --> Model Class Initialized
DEBUG - 2018-02-10 19:58:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 19:58:39 --> Config Class Initialized
INFO - 2018-02-10 19:58:39 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:58:39 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:58:39 --> Utf8 Class Initialized
INFO - 2018-02-10 19:58:39 --> URI Class Initialized
DEBUG - 2018-02-10 19:58:39 --> No URI present. Default controller set.
INFO - 2018-02-10 19:58:39 --> Router Class Initialized
INFO - 2018-02-10 19:58:39 --> Output Class Initialized
INFO - 2018-02-10 19:58:39 --> Security Class Initialized
DEBUG - 2018-02-10 19:58:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:58:39 --> Input Class Initialized
INFO - 2018-02-10 19:58:39 --> Language Class Initialized
INFO - 2018-02-10 19:58:39 --> Loader Class Initialized
INFO - 2018-02-10 19:58:39 --> Helper loaded: url_helper
INFO - 2018-02-10 19:58:39 --> Helper loaded: form_helper
INFO - 2018-02-10 19:58:39 --> Database Driver Class Initialized
DEBUG - 2018-02-10 19:58:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 19:58:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 19:58:39 --> Form Validation Class Initialized
INFO - 2018-02-10 19:58:39 --> Model Class Initialized
INFO - 2018-02-10 19:58:39 --> Controller Class Initialized
INFO - 2018-02-10 19:58:39 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 19:58:39 --> Final output sent to browser
DEBUG - 2018-02-10 19:58:39 --> Total execution time: 0.1170
INFO - 2018-02-10 19:58:39 --> Config Class Initialized
INFO - 2018-02-10 19:58:39 --> Hooks Class Initialized
INFO - 2018-02-10 19:58:39 --> Config Class Initialized
INFO - 2018-02-10 19:58:39 --> Hooks Class Initialized
INFO - 2018-02-10 19:58:39 --> Config Class Initialized
INFO - 2018-02-10 19:58:39 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:58:39 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:58:39 --> Utf8 Class Initialized
INFO - 2018-02-10 19:58:39 --> Config Class Initialized
DEBUG - 2018-02-10 19:58:39 --> UTF-8 Support Enabled
DEBUG - 2018-02-10 19:58:39 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:58:39 --> Hooks Class Initialized
INFO - 2018-02-10 19:58:39 --> Utf8 Class Initialized
INFO - 2018-02-10 19:58:39 --> URI Class Initialized
INFO - 2018-02-10 19:58:39 --> Utf8 Class Initialized
INFO - 2018-02-10 19:58:39 --> URI Class Initialized
INFO - 2018-02-10 19:58:39 --> URI Class Initialized
INFO - 2018-02-10 19:58:39 --> Router Class Initialized
DEBUG - 2018-02-10 19:58:39 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:58:39 --> Utf8 Class Initialized
INFO - 2018-02-10 19:58:39 --> Router Class Initialized
INFO - 2018-02-10 19:58:39 --> Router Class Initialized
INFO - 2018-02-10 19:58:39 --> Output Class Initialized
INFO - 2018-02-10 19:58:39 --> URI Class Initialized
INFO - 2018-02-10 19:58:39 --> Output Class Initialized
INFO - 2018-02-10 19:58:39 --> Output Class Initialized
INFO - 2018-02-10 19:58:39 --> Security Class Initialized
INFO - 2018-02-10 19:58:39 --> Router Class Initialized
INFO - 2018-02-10 19:58:39 --> Security Class Initialized
INFO - 2018-02-10 19:58:39 --> Security Class Initialized
DEBUG - 2018-02-10 19:58:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:58:39 --> Input Class Initialized
INFO - 2018-02-10 19:58:39 --> Output Class Initialized
DEBUG - 2018-02-10 19:58:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:58:39 --> Language Class Initialized
DEBUG - 2018-02-10 19:58:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:58:39 --> Input Class Initialized
INFO - 2018-02-10 19:58:39 --> Input Class Initialized
INFO - 2018-02-10 19:58:39 --> Security Class Initialized
INFO - 2018-02-10 19:58:39 --> Language Class Initialized
INFO - 2018-02-10 19:58:39 --> Language Class Initialized
ERROR - 2018-02-10 19:58:39 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-02-10 19:58:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-10 19:58:39 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-10 19:58:39 --> Input Class Initialized
ERROR - 2018-02-10 19:58:39 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-10 19:58:39 --> Language Class Initialized
ERROR - 2018-02-10 19:58:39 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-10 19:58:39 --> Config Class Initialized
INFO - 2018-02-10 19:58:39 --> Config Class Initialized
INFO - 2018-02-10 19:58:39 --> Hooks Class Initialized
INFO - 2018-02-10 19:58:39 --> Config Class Initialized
INFO - 2018-02-10 19:58:39 --> Hooks Class Initialized
INFO - 2018-02-10 19:58:39 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:58:39 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:58:39 --> Utf8 Class Initialized
DEBUG - 2018-02-10 19:58:39 --> UTF-8 Support Enabled
DEBUG - 2018-02-10 19:58:39 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:58:39 --> Utf8 Class Initialized
INFO - 2018-02-10 19:58:39 --> Utf8 Class Initialized
INFO - 2018-02-10 19:58:39 --> URI Class Initialized
INFO - 2018-02-10 19:58:39 --> URI Class Initialized
INFO - 2018-02-10 19:58:39 --> URI Class Initialized
INFO - 2018-02-10 19:58:39 --> Router Class Initialized
INFO - 2018-02-10 19:58:39 --> Router Class Initialized
INFO - 2018-02-10 19:58:39 --> Router Class Initialized
INFO - 2018-02-10 19:58:39 --> Output Class Initialized
INFO - 2018-02-10 19:58:39 --> Output Class Initialized
INFO - 2018-02-10 19:58:39 --> Security Class Initialized
INFO - 2018-02-10 19:58:39 --> Output Class Initialized
INFO - 2018-02-10 19:58:39 --> Security Class Initialized
DEBUG - 2018-02-10 19:58:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:58:39 --> Input Class Initialized
INFO - 2018-02-10 19:58:39 --> Security Class Initialized
DEBUG - 2018-02-10 19:58:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:58:39 --> Input Class Initialized
INFO - 2018-02-10 19:58:39 --> Language Class Initialized
INFO - 2018-02-10 19:58:39 --> Language Class Initialized
DEBUG - 2018-02-10 19:58:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:58:39 --> Input Class Initialized
ERROR - 2018-02-10 19:58:39 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-10 19:58:39 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-10 19:58:39 --> Language Class Initialized
ERROR - 2018-02-10 19:58:39 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-10 19:58:39 --> Config Class Initialized
INFO - 2018-02-10 19:58:39 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:58:39 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:58:39 --> Utf8 Class Initialized
INFO - 2018-02-10 19:58:39 --> URI Class Initialized
INFO - 2018-02-10 19:58:39 --> Router Class Initialized
INFO - 2018-02-10 19:58:39 --> Output Class Initialized
INFO - 2018-02-10 19:58:39 --> Security Class Initialized
DEBUG - 2018-02-10 19:58:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:58:39 --> Input Class Initialized
INFO - 2018-02-10 19:58:39 --> Language Class Initialized
INFO - 2018-02-10 19:58:39 --> Loader Class Initialized
INFO - 2018-02-10 19:58:39 --> Helper loaded: url_helper
INFO - 2018-02-10 19:58:39 --> Helper loaded: form_helper
INFO - 2018-02-10 19:58:39 --> Database Driver Class Initialized
DEBUG - 2018-02-10 19:58:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 19:58:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 19:58:40 --> Form Validation Class Initialized
INFO - 2018-02-10 19:58:40 --> Model Class Initialized
INFO - 2018-02-10 19:58:40 --> Controller Class Initialized
INFO - 2018-02-10 19:58:40 --> Model Class Initialized
INFO - 2018-02-10 19:58:40 --> Model Class Initialized
INFO - 2018-02-10 19:58:40 --> Model Class Initialized
INFO - 2018-02-10 19:58:40 --> Model Class Initialized
DEBUG - 2018-02-10 19:58:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 19:58:41 --> Config Class Initialized
INFO - 2018-02-10 19:58:41 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:58:41 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:58:41 --> Utf8 Class Initialized
INFO - 2018-02-10 19:58:41 --> URI Class Initialized
DEBUG - 2018-02-10 19:58:41 --> No URI present. Default controller set.
INFO - 2018-02-10 19:58:41 --> Router Class Initialized
INFO - 2018-02-10 19:58:41 --> Output Class Initialized
INFO - 2018-02-10 19:58:41 --> Security Class Initialized
DEBUG - 2018-02-10 19:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:58:41 --> Input Class Initialized
INFO - 2018-02-10 19:58:41 --> Language Class Initialized
INFO - 2018-02-10 19:58:41 --> Loader Class Initialized
INFO - 2018-02-10 19:58:41 --> Helper loaded: url_helper
INFO - 2018-02-10 19:58:41 --> Helper loaded: form_helper
INFO - 2018-02-10 19:58:41 --> Database Driver Class Initialized
DEBUG - 2018-02-10 19:58:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 19:58:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 19:58:41 --> Form Validation Class Initialized
INFO - 2018-02-10 19:58:41 --> Model Class Initialized
INFO - 2018-02-10 19:58:41 --> Controller Class Initialized
INFO - 2018-02-10 19:58:41 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 19:58:41 --> Final output sent to browser
DEBUG - 2018-02-10 19:58:41 --> Total execution time: 0.0970
INFO - 2018-02-10 19:58:42 --> Config Class Initialized
INFO - 2018-02-10 19:58:42 --> Hooks Class Initialized
INFO - 2018-02-10 19:58:42 --> Config Class Initialized
INFO - 2018-02-10 19:58:42 --> Hooks Class Initialized
INFO - 2018-02-10 19:58:42 --> Config Class Initialized
INFO - 2018-02-10 19:58:42 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:58:42 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:58:42 --> Utf8 Class Initialized
DEBUG - 2018-02-10 19:58:42 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:58:42 --> Utf8 Class Initialized
DEBUG - 2018-02-10 19:58:42 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:58:42 --> Utf8 Class Initialized
INFO - 2018-02-10 19:58:42 --> URI Class Initialized
INFO - 2018-02-10 19:58:42 --> URI Class Initialized
INFO - 2018-02-10 19:58:42 --> URI Class Initialized
INFO - 2018-02-10 19:58:42 --> Router Class Initialized
INFO - 2018-02-10 19:58:42 --> Router Class Initialized
INFO - 2018-02-10 19:58:42 --> Router Class Initialized
INFO - 2018-02-10 19:58:42 --> Output Class Initialized
INFO - 2018-02-10 19:58:42 --> Output Class Initialized
INFO - 2018-02-10 19:58:42 --> Security Class Initialized
INFO - 2018-02-10 19:58:42 --> Output Class Initialized
INFO - 2018-02-10 19:58:42 --> Security Class Initialized
DEBUG - 2018-02-10 19:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:58:42 --> Input Class Initialized
INFO - 2018-02-10 19:58:42 --> Security Class Initialized
INFO - 2018-02-10 19:58:42 --> Language Class Initialized
DEBUG - 2018-02-10 19:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:58:42 --> Input Class Initialized
DEBUG - 2018-02-10 19:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:58:42 --> Input Class Initialized
INFO - 2018-02-10 19:58:42 --> Language Class Initialized
ERROR - 2018-02-10 19:58:42 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-10 19:58:42 --> Language Class Initialized
ERROR - 2018-02-10 19:58:42 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-10 19:58:42 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-10 19:58:42 --> Config Class Initialized
INFO - 2018-02-10 19:58:42 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:58:42 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:58:42 --> Utf8 Class Initialized
INFO - 2018-02-10 19:58:42 --> URI Class Initialized
INFO - 2018-02-10 19:58:42 --> Router Class Initialized
INFO - 2018-02-10 19:58:42 --> Output Class Initialized
INFO - 2018-02-10 19:58:42 --> Security Class Initialized
DEBUG - 2018-02-10 19:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:58:42 --> Input Class Initialized
INFO - 2018-02-10 19:58:42 --> Language Class Initialized
ERROR - 2018-02-10 19:58:42 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-10 19:58:42 --> Config Class Initialized
INFO - 2018-02-10 19:58:42 --> Hooks Class Initialized
INFO - 2018-02-10 19:58:42 --> Config Class Initialized
INFO - 2018-02-10 19:58:42 --> Hooks Class Initialized
INFO - 2018-02-10 19:58:42 --> Config Class Initialized
INFO - 2018-02-10 19:58:42 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:58:42 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:58:42 --> Utf8 Class Initialized
DEBUG - 2018-02-10 19:58:42 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:58:42 --> Utf8 Class Initialized
DEBUG - 2018-02-10 19:58:42 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:58:42 --> Utf8 Class Initialized
INFO - 2018-02-10 19:58:42 --> URI Class Initialized
INFO - 2018-02-10 19:58:42 --> URI Class Initialized
INFO - 2018-02-10 19:58:42 --> URI Class Initialized
INFO - 2018-02-10 19:58:42 --> Router Class Initialized
INFO - 2018-02-10 19:58:42 --> Router Class Initialized
INFO - 2018-02-10 19:58:42 --> Router Class Initialized
INFO - 2018-02-10 19:58:42 --> Output Class Initialized
INFO - 2018-02-10 19:58:42 --> Output Class Initialized
INFO - 2018-02-10 19:58:42 --> Output Class Initialized
INFO - 2018-02-10 19:58:42 --> Security Class Initialized
INFO - 2018-02-10 19:58:42 --> Security Class Initialized
INFO - 2018-02-10 19:58:42 --> Security Class Initialized
DEBUG - 2018-02-10 19:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:58:42 --> Input Class Initialized
DEBUG - 2018-02-10 19:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:58:42 --> Input Class Initialized
DEBUG - 2018-02-10 19:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:58:42 --> Language Class Initialized
INFO - 2018-02-10 19:58:42 --> Input Class Initialized
INFO - 2018-02-10 19:58:42 --> Language Class Initialized
INFO - 2018-02-10 19:58:42 --> Language Class Initialized
ERROR - 2018-02-10 19:58:42 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-10 19:58:42 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-10 19:58:42 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-10 19:58:42 --> Config Class Initialized
INFO - 2018-02-10 19:58:42 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:58:42 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:58:42 --> Utf8 Class Initialized
INFO - 2018-02-10 19:58:42 --> URI Class Initialized
INFO - 2018-02-10 19:58:42 --> Router Class Initialized
INFO - 2018-02-10 19:58:42 --> Output Class Initialized
INFO - 2018-02-10 19:58:42 --> Security Class Initialized
DEBUG - 2018-02-10 19:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:58:42 --> Input Class Initialized
INFO - 2018-02-10 19:58:42 --> Language Class Initialized
INFO - 2018-02-10 19:58:42 --> Loader Class Initialized
INFO - 2018-02-10 19:58:42 --> Helper loaded: url_helper
INFO - 2018-02-10 19:58:42 --> Helper loaded: form_helper
INFO - 2018-02-10 19:58:42 --> Database Driver Class Initialized
DEBUG - 2018-02-10 19:58:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 19:58:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 19:58:42 --> Form Validation Class Initialized
INFO - 2018-02-10 19:58:42 --> Model Class Initialized
INFO - 2018-02-10 19:58:42 --> Controller Class Initialized
INFO - 2018-02-10 19:58:42 --> Model Class Initialized
INFO - 2018-02-10 19:58:42 --> Model Class Initialized
INFO - 2018-02-10 19:58:42 --> Model Class Initialized
INFO - 2018-02-10 19:58:42 --> Model Class Initialized
DEBUG - 2018-02-10 19:58:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 19:59:04 --> Config Class Initialized
INFO - 2018-02-10 19:59:04 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:59:04 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:59:04 --> Utf8 Class Initialized
INFO - 2018-02-10 19:59:04 --> URI Class Initialized
DEBUG - 2018-02-10 19:59:04 --> No URI present. Default controller set.
INFO - 2018-02-10 19:59:04 --> Router Class Initialized
INFO - 2018-02-10 19:59:04 --> Output Class Initialized
INFO - 2018-02-10 19:59:04 --> Security Class Initialized
DEBUG - 2018-02-10 19:59:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:59:04 --> Input Class Initialized
INFO - 2018-02-10 19:59:04 --> Language Class Initialized
INFO - 2018-02-10 19:59:04 --> Loader Class Initialized
INFO - 2018-02-10 19:59:04 --> Helper loaded: url_helper
INFO - 2018-02-10 19:59:04 --> Helper loaded: form_helper
INFO - 2018-02-10 19:59:04 --> Database Driver Class Initialized
DEBUG - 2018-02-10 19:59:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 19:59:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 19:59:04 --> Form Validation Class Initialized
INFO - 2018-02-10 19:59:04 --> Model Class Initialized
INFO - 2018-02-10 19:59:04 --> Controller Class Initialized
INFO - 2018-02-10 19:59:04 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 19:59:04 --> Final output sent to browser
DEBUG - 2018-02-10 19:59:04 --> Total execution time: 0.1318
INFO - 2018-02-10 19:59:04 --> Config Class Initialized
INFO - 2018-02-10 19:59:04 --> Config Class Initialized
INFO - 2018-02-10 19:59:04 --> Hooks Class Initialized
INFO - 2018-02-10 19:59:04 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:59:04 --> UTF-8 Support Enabled
DEBUG - 2018-02-10 19:59:04 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:59:04 --> Utf8 Class Initialized
INFO - 2018-02-10 19:59:04 --> Utf8 Class Initialized
INFO - 2018-02-10 19:59:04 --> URI Class Initialized
INFO - 2018-02-10 19:59:04 --> URI Class Initialized
INFO - 2018-02-10 19:59:04 --> Router Class Initialized
INFO - 2018-02-10 19:59:04 --> Router Class Initialized
INFO - 2018-02-10 19:59:04 --> Output Class Initialized
INFO - 2018-02-10 19:59:04 --> Output Class Initialized
INFO - 2018-02-10 19:59:04 --> Security Class Initialized
INFO - 2018-02-10 19:59:04 --> Security Class Initialized
DEBUG - 2018-02-10 19:59:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-10 19:59:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:59:04 --> Input Class Initialized
INFO - 2018-02-10 19:59:04 --> Input Class Initialized
INFO - 2018-02-10 19:59:04 --> Language Class Initialized
INFO - 2018-02-10 19:59:04 --> Language Class Initialized
ERROR - 2018-02-10 19:59:04 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-10 19:59:04 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-10 19:59:04 --> Config Class Initialized
INFO - 2018-02-10 19:59:04 --> Config Class Initialized
INFO - 2018-02-10 19:59:04 --> Hooks Class Initialized
INFO - 2018-02-10 19:59:04 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:59:04 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:59:04 --> Utf8 Class Initialized
DEBUG - 2018-02-10 19:59:04 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:59:04 --> Utf8 Class Initialized
INFO - 2018-02-10 19:59:04 --> URI Class Initialized
INFO - 2018-02-10 19:59:04 --> URI Class Initialized
INFO - 2018-02-10 19:59:04 --> Router Class Initialized
INFO - 2018-02-10 19:59:04 --> Router Class Initialized
INFO - 2018-02-10 19:59:04 --> Output Class Initialized
INFO - 2018-02-10 19:59:04 --> Output Class Initialized
INFO - 2018-02-10 19:59:04 --> Security Class Initialized
INFO - 2018-02-10 19:59:04 --> Security Class Initialized
DEBUG - 2018-02-10 19:59:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-10 19:59:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:59:04 --> Input Class Initialized
INFO - 2018-02-10 19:59:04 --> Input Class Initialized
INFO - 2018-02-10 19:59:04 --> Language Class Initialized
INFO - 2018-02-10 19:59:04 --> Language Class Initialized
ERROR - 2018-02-10 19:59:04 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-10 19:59:04 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-10 19:59:04 --> Config Class Initialized
INFO - 2018-02-10 19:59:04 --> Hooks Class Initialized
INFO - 2018-02-10 19:59:04 --> Config Class Initialized
INFO - 2018-02-10 19:59:04 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:59:04 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:59:04 --> Config Class Initialized
INFO - 2018-02-10 19:59:04 --> Utf8 Class Initialized
INFO - 2018-02-10 19:59:04 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:59:04 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:59:04 --> Utf8 Class Initialized
INFO - 2018-02-10 19:59:04 --> URI Class Initialized
INFO - 2018-02-10 19:59:04 --> URI Class Initialized
DEBUG - 2018-02-10 19:59:04 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:59:04 --> Router Class Initialized
INFO - 2018-02-10 19:59:04 --> Utf8 Class Initialized
INFO - 2018-02-10 19:59:04 --> Router Class Initialized
INFO - 2018-02-10 19:59:04 --> URI Class Initialized
INFO - 2018-02-10 19:59:04 --> Output Class Initialized
INFO - 2018-02-10 19:59:04 --> Output Class Initialized
INFO - 2018-02-10 19:59:04 --> Router Class Initialized
INFO - 2018-02-10 19:59:04 --> Security Class Initialized
INFO - 2018-02-10 19:59:04 --> Security Class Initialized
DEBUG - 2018-02-10 19:59:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-10 19:59:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:59:04 --> Input Class Initialized
INFO - 2018-02-10 19:59:04 --> Output Class Initialized
INFO - 2018-02-10 19:59:04 --> Input Class Initialized
INFO - 2018-02-10 19:59:04 --> Language Class Initialized
INFO - 2018-02-10 19:59:04 --> Language Class Initialized
INFO - 2018-02-10 19:59:04 --> Security Class Initialized
ERROR - 2018-02-10 19:59:04 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-10 19:59:04 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-02-10 19:59:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:59:04 --> Input Class Initialized
INFO - 2018-02-10 19:59:04 --> Language Class Initialized
ERROR - 2018-02-10 19:59:04 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-10 19:59:04 --> Config Class Initialized
INFO - 2018-02-10 19:59:04 --> Hooks Class Initialized
DEBUG - 2018-02-10 19:59:04 --> UTF-8 Support Enabled
INFO - 2018-02-10 19:59:04 --> Utf8 Class Initialized
INFO - 2018-02-10 19:59:04 --> URI Class Initialized
INFO - 2018-02-10 19:59:04 --> Router Class Initialized
INFO - 2018-02-10 19:59:04 --> Output Class Initialized
INFO - 2018-02-10 19:59:04 --> Security Class Initialized
DEBUG - 2018-02-10 19:59:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 19:59:04 --> Input Class Initialized
INFO - 2018-02-10 19:59:04 --> Language Class Initialized
INFO - 2018-02-10 19:59:04 --> Loader Class Initialized
INFO - 2018-02-10 19:59:04 --> Helper loaded: url_helper
INFO - 2018-02-10 19:59:04 --> Helper loaded: form_helper
INFO - 2018-02-10 19:59:04 --> Database Driver Class Initialized
DEBUG - 2018-02-10 19:59:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 19:59:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 19:59:04 --> Form Validation Class Initialized
INFO - 2018-02-10 19:59:04 --> Model Class Initialized
INFO - 2018-02-10 19:59:04 --> Controller Class Initialized
INFO - 2018-02-10 19:59:04 --> Model Class Initialized
INFO - 2018-02-10 19:59:04 --> Model Class Initialized
INFO - 2018-02-10 19:59:04 --> Model Class Initialized
INFO - 2018-02-10 19:59:04 --> Model Class Initialized
DEBUG - 2018-02-10 19:59:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 20:02:11 --> Config Class Initialized
INFO - 2018-02-10 20:02:11 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:02:11 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:02:11 --> Utf8 Class Initialized
INFO - 2018-02-10 20:02:11 --> URI Class Initialized
DEBUG - 2018-02-10 20:02:11 --> No URI present. Default controller set.
INFO - 2018-02-10 20:02:11 --> Router Class Initialized
INFO - 2018-02-10 20:02:11 --> Output Class Initialized
INFO - 2018-02-10 20:02:11 --> Security Class Initialized
DEBUG - 2018-02-10 20:02:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:02:11 --> Input Class Initialized
INFO - 2018-02-10 20:02:11 --> Language Class Initialized
INFO - 2018-02-10 20:02:11 --> Loader Class Initialized
INFO - 2018-02-10 20:02:11 --> Helper loaded: url_helper
INFO - 2018-02-10 20:02:11 --> Helper loaded: form_helper
INFO - 2018-02-10 20:02:11 --> Database Driver Class Initialized
DEBUG - 2018-02-10 20:02:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:02:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 20:02:11 --> Form Validation Class Initialized
INFO - 2018-02-10 20:02:11 --> Model Class Initialized
INFO - 2018-02-10 20:02:11 --> Controller Class Initialized
INFO - 2018-02-10 20:02:11 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 20:02:11 --> Final output sent to browser
DEBUG - 2018-02-10 20:02:11 --> Total execution time: 0.0843
INFO - 2018-02-10 20:02:12 --> Config Class Initialized
INFO - 2018-02-10 20:02:12 --> Config Class Initialized
INFO - 2018-02-10 20:02:12 --> Hooks Class Initialized
INFO - 2018-02-10 20:02:12 --> Config Class Initialized
INFO - 2018-02-10 20:02:12 --> Hooks Class Initialized
INFO - 2018-02-10 20:02:12 --> Config Class Initialized
INFO - 2018-02-10 20:02:12 --> Hooks Class Initialized
INFO - 2018-02-10 20:02:12 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:02:12 --> UTF-8 Support Enabled
DEBUG - 2018-02-10 20:02:12 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:02:12 --> Utf8 Class Initialized
INFO - 2018-02-10 20:02:12 --> Utf8 Class Initialized
DEBUG - 2018-02-10 20:02:12 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:02:12 --> Utf8 Class Initialized
DEBUG - 2018-02-10 20:02:12 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:02:12 --> URI Class Initialized
INFO - 2018-02-10 20:02:12 --> Utf8 Class Initialized
INFO - 2018-02-10 20:02:12 --> URI Class Initialized
INFO - 2018-02-10 20:02:12 --> URI Class Initialized
INFO - 2018-02-10 20:02:12 --> URI Class Initialized
INFO - 2018-02-10 20:02:12 --> Router Class Initialized
INFO - 2018-02-10 20:02:12 --> Router Class Initialized
INFO - 2018-02-10 20:02:12 --> Router Class Initialized
INFO - 2018-02-10 20:02:12 --> Router Class Initialized
INFO - 2018-02-10 20:02:12 --> Output Class Initialized
INFO - 2018-02-10 20:02:12 --> Output Class Initialized
INFO - 2018-02-10 20:02:12 --> Output Class Initialized
INFO - 2018-02-10 20:02:12 --> Output Class Initialized
INFO - 2018-02-10 20:02:12 --> Security Class Initialized
INFO - 2018-02-10 20:02:12 --> Security Class Initialized
INFO - 2018-02-10 20:02:12 --> Security Class Initialized
DEBUG - 2018-02-10 20:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:02:12 --> Input Class Initialized
INFO - 2018-02-10 20:02:12 --> Security Class Initialized
DEBUG - 2018-02-10 20:02:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-10 20:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:02:12 --> Input Class Initialized
INFO - 2018-02-10 20:02:12 --> Language Class Initialized
INFO - 2018-02-10 20:02:12 --> Input Class Initialized
INFO - 2018-02-10 20:02:12 --> Language Class Initialized
DEBUG - 2018-02-10 20:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:02:12 --> Language Class Initialized
INFO - 2018-02-10 20:02:12 --> Input Class Initialized
ERROR - 2018-02-10 20:02:12 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-10 20:02:12 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-10 20:02:12 --> Language Class Initialized
ERROR - 2018-02-10 20:02:12 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-10 20:02:12 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-10 20:02:12 --> Config Class Initialized
INFO - 2018-02-10 20:02:12 --> Hooks Class Initialized
INFO - 2018-02-10 20:02:12 --> Config Class Initialized
INFO - 2018-02-10 20:02:12 --> Hooks Class Initialized
INFO - 2018-02-10 20:02:12 --> Config Class Initialized
INFO - 2018-02-10 20:02:12 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:02:12 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:02:12 --> Utf8 Class Initialized
DEBUG - 2018-02-10 20:02:12 --> UTF-8 Support Enabled
DEBUG - 2018-02-10 20:02:12 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:02:12 --> Utf8 Class Initialized
INFO - 2018-02-10 20:02:12 --> Utf8 Class Initialized
INFO - 2018-02-10 20:02:12 --> URI Class Initialized
INFO - 2018-02-10 20:02:12 --> URI Class Initialized
INFO - 2018-02-10 20:02:12 --> URI Class Initialized
INFO - 2018-02-10 20:02:12 --> Router Class Initialized
INFO - 2018-02-10 20:02:12 --> Router Class Initialized
INFO - 2018-02-10 20:02:12 --> Router Class Initialized
INFO - 2018-02-10 20:02:12 --> Output Class Initialized
INFO - 2018-02-10 20:02:12 --> Output Class Initialized
INFO - 2018-02-10 20:02:12 --> Output Class Initialized
INFO - 2018-02-10 20:02:12 --> Security Class Initialized
INFO - 2018-02-10 20:02:12 --> Security Class Initialized
INFO - 2018-02-10 20:02:12 --> Security Class Initialized
DEBUG - 2018-02-10 20:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:02:12 --> Input Class Initialized
INFO - 2018-02-10 20:02:12 --> Language Class Initialized
DEBUG - 2018-02-10 20:02:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-10 20:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:02:12 --> Input Class Initialized
INFO - 2018-02-10 20:02:12 --> Input Class Initialized
INFO - 2018-02-10 20:02:12 --> Language Class Initialized
ERROR - 2018-02-10 20:02:12 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-10 20:02:12 --> Language Class Initialized
ERROR - 2018-02-10 20:02:12 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-10 20:02:12 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-10 20:02:12 --> Config Class Initialized
INFO - 2018-02-10 20:02:12 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:02:12 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:02:12 --> Utf8 Class Initialized
INFO - 2018-02-10 20:02:12 --> URI Class Initialized
INFO - 2018-02-10 20:02:12 --> Router Class Initialized
INFO - 2018-02-10 20:02:12 --> Output Class Initialized
INFO - 2018-02-10 20:02:12 --> Security Class Initialized
DEBUG - 2018-02-10 20:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:02:12 --> Input Class Initialized
INFO - 2018-02-10 20:02:12 --> Language Class Initialized
INFO - 2018-02-10 20:02:12 --> Loader Class Initialized
INFO - 2018-02-10 20:02:12 --> Helper loaded: url_helper
INFO - 2018-02-10 20:02:12 --> Helper loaded: form_helper
INFO - 2018-02-10 20:02:12 --> Database Driver Class Initialized
DEBUG - 2018-02-10 20:02:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:02:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 20:02:12 --> Form Validation Class Initialized
INFO - 2018-02-10 20:02:12 --> Model Class Initialized
INFO - 2018-02-10 20:02:12 --> Controller Class Initialized
INFO - 2018-02-10 20:02:12 --> Model Class Initialized
INFO - 2018-02-10 20:02:12 --> Model Class Initialized
INFO - 2018-02-10 20:02:12 --> Model Class Initialized
INFO - 2018-02-10 20:02:12 --> Model Class Initialized
DEBUG - 2018-02-10 20:02:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 20:02:13 --> Config Class Initialized
INFO - 2018-02-10 20:02:13 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:02:13 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:02:13 --> Utf8 Class Initialized
INFO - 2018-02-10 20:02:13 --> URI Class Initialized
INFO - 2018-02-10 20:02:13 --> Router Class Initialized
INFO - 2018-02-10 20:02:13 --> Output Class Initialized
INFO - 2018-02-10 20:02:13 --> Security Class Initialized
DEBUG - 2018-02-10 20:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:02:13 --> Input Class Initialized
INFO - 2018-02-10 20:02:13 --> Language Class Initialized
INFO - 2018-02-10 20:02:13 --> Loader Class Initialized
INFO - 2018-02-10 20:02:13 --> Helper loaded: url_helper
INFO - 2018-02-10 20:02:13 --> Helper loaded: form_helper
INFO - 2018-02-10 20:02:13 --> Database Driver Class Initialized
DEBUG - 2018-02-10 20:02:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:02:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 20:02:13 --> Form Validation Class Initialized
INFO - 2018-02-10 20:02:13 --> Model Class Initialized
INFO - 2018-02-10 20:02:13 --> Controller Class Initialized
INFO - 2018-02-10 20:02:13 --> Model Class Initialized
INFO - 2018-02-10 20:02:13 --> Model Class Initialized
INFO - 2018-02-10 20:02:13 --> Model Class Initialized
INFO - 2018-02-10 20:02:13 --> Model Class Initialized
DEBUG - 2018-02-10 20:02:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 20:02:13 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 20:02:13 --> Final output sent to browser
DEBUG - 2018-02-10 20:02:13 --> Total execution time: 0.0562
INFO - 2018-02-10 20:02:13 --> Config Class Initialized
INFO - 2018-02-10 20:02:13 --> Hooks Class Initialized
INFO - 2018-02-10 20:02:13 --> Config Class Initialized
INFO - 2018-02-10 20:02:13 --> Hooks Class Initialized
INFO - 2018-02-10 20:02:13 --> Config Class Initialized
INFO - 2018-02-10 20:02:13 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:02:13 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:02:13 --> Utf8 Class Initialized
INFO - 2018-02-10 20:02:13 --> Config Class Initialized
INFO - 2018-02-10 20:02:13 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:02:13 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:02:13 --> URI Class Initialized
INFO - 2018-02-10 20:02:13 --> Utf8 Class Initialized
DEBUG - 2018-02-10 20:02:13 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:02:13 --> Utf8 Class Initialized
INFO - 2018-02-10 20:02:13 --> URI Class Initialized
INFO - 2018-02-10 20:02:13 --> Router Class Initialized
INFO - 2018-02-10 20:02:13 --> URI Class Initialized
DEBUG - 2018-02-10 20:02:13 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:02:13 --> Utf8 Class Initialized
INFO - 2018-02-10 20:02:13 --> Router Class Initialized
INFO - 2018-02-10 20:02:13 --> Output Class Initialized
INFO - 2018-02-10 20:02:13 --> Router Class Initialized
INFO - 2018-02-10 20:02:13 --> URI Class Initialized
INFO - 2018-02-10 20:02:13 --> Security Class Initialized
INFO - 2018-02-10 20:02:13 --> Output Class Initialized
INFO - 2018-02-10 20:02:13 --> Router Class Initialized
INFO - 2018-02-10 20:02:13 --> Output Class Initialized
DEBUG - 2018-02-10 20:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:02:13 --> Input Class Initialized
INFO - 2018-02-10 20:02:13 --> Security Class Initialized
INFO - 2018-02-10 20:02:13 --> Language Class Initialized
INFO - 2018-02-10 20:02:13 --> Security Class Initialized
INFO - 2018-02-10 20:02:13 --> Output Class Initialized
DEBUG - 2018-02-10 20:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:02:13 --> Input Class Initialized
ERROR - 2018-02-10 20:02:13 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-10 20:02:13 --> Language Class Initialized
DEBUG - 2018-02-10 20:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:02:13 --> Security Class Initialized
INFO - 2018-02-10 20:02:13 --> Input Class Initialized
INFO - 2018-02-10 20:02:13 --> Language Class Initialized
DEBUG - 2018-02-10 20:02:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-10 20:02:13 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-10 20:02:13 --> Input Class Initialized
ERROR - 2018-02-10 20:02:13 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-10 20:02:13 --> Language Class Initialized
ERROR - 2018-02-10 20:02:13 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-10 20:02:13 --> Config Class Initialized
INFO - 2018-02-10 20:02:13 --> Config Class Initialized
INFO - 2018-02-10 20:02:13 --> Hooks Class Initialized
INFO - 2018-02-10 20:02:13 --> Config Class Initialized
INFO - 2018-02-10 20:02:13 --> Hooks Class Initialized
INFO - 2018-02-10 20:02:13 --> Hooks Class Initialized
INFO - 2018-02-10 20:02:13 --> Config Class Initialized
INFO - 2018-02-10 20:02:13 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:02:13 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:02:13 --> Utf8 Class Initialized
DEBUG - 2018-02-10 20:02:13 --> UTF-8 Support Enabled
DEBUG - 2018-02-10 20:02:13 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:02:13 --> Utf8 Class Initialized
INFO - 2018-02-10 20:02:13 --> Utf8 Class Initialized
INFO - 2018-02-10 20:02:13 --> URI Class Initialized
DEBUG - 2018-02-10 20:02:13 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:02:13 --> Utf8 Class Initialized
INFO - 2018-02-10 20:02:13 --> URI Class Initialized
INFO - 2018-02-10 20:02:13 --> URI Class Initialized
INFO - 2018-02-10 20:02:13 --> Router Class Initialized
INFO - 2018-02-10 20:02:13 --> URI Class Initialized
INFO - 2018-02-10 20:02:13 --> Router Class Initialized
INFO - 2018-02-10 20:02:13 --> Router Class Initialized
INFO - 2018-02-10 20:02:13 --> Output Class Initialized
INFO - 2018-02-10 20:02:13 --> Router Class Initialized
INFO - 2018-02-10 20:02:13 --> Security Class Initialized
INFO - 2018-02-10 20:02:13 --> Output Class Initialized
INFO - 2018-02-10 20:02:13 --> Output Class Initialized
DEBUG - 2018-02-10 20:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:02:13 --> Input Class Initialized
INFO - 2018-02-10 20:02:13 --> Output Class Initialized
INFO - 2018-02-10 20:02:13 --> Security Class Initialized
INFO - 2018-02-10 20:02:13 --> Security Class Initialized
INFO - 2018-02-10 20:02:13 --> Language Class Initialized
INFO - 2018-02-10 20:02:13 --> Security Class Initialized
DEBUG - 2018-02-10 20:02:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-10 20:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:02:13 --> Input Class Initialized
ERROR - 2018-02-10 20:02:13 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-10 20:02:13 --> Input Class Initialized
DEBUG - 2018-02-10 20:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:02:13 --> Input Class Initialized
INFO - 2018-02-10 20:02:13 --> Language Class Initialized
INFO - 2018-02-10 20:02:13 --> Language Class Initialized
INFO - 2018-02-10 20:02:13 --> Language Class Initialized
ERROR - 2018-02-10 20:02:13 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-10 20:02:13 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-10 20:02:13 --> Loader Class Initialized
INFO - 2018-02-10 20:02:13 --> Helper loaded: url_helper
INFO - 2018-02-10 20:02:13 --> Helper loaded: form_helper
INFO - 2018-02-10 20:02:13 --> Database Driver Class Initialized
DEBUG - 2018-02-10 20:02:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:02:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 20:02:13 --> Form Validation Class Initialized
INFO - 2018-02-10 20:02:13 --> Model Class Initialized
INFO - 2018-02-10 20:02:13 --> Controller Class Initialized
INFO - 2018-02-10 20:02:13 --> Model Class Initialized
INFO - 2018-02-10 20:02:13 --> Model Class Initialized
INFO - 2018-02-10 20:02:13 --> Model Class Initialized
INFO - 2018-02-10 20:02:13 --> Model Class Initialized
DEBUG - 2018-02-10 20:02:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 20:02:15 --> Config Class Initialized
INFO - 2018-02-10 20:02:15 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:02:15 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:02:15 --> Utf8 Class Initialized
INFO - 2018-02-10 20:02:15 --> URI Class Initialized
INFO - 2018-02-10 20:02:15 --> Router Class Initialized
INFO - 2018-02-10 20:02:15 --> Output Class Initialized
INFO - 2018-02-10 20:02:15 --> Security Class Initialized
DEBUG - 2018-02-10 20:02:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:02:15 --> Input Class Initialized
INFO - 2018-02-10 20:02:15 --> Language Class Initialized
INFO - 2018-02-10 20:02:15 --> Loader Class Initialized
INFO - 2018-02-10 20:02:15 --> Helper loaded: url_helper
INFO - 2018-02-10 20:02:15 --> Helper loaded: form_helper
INFO - 2018-02-10 20:02:15 --> Database Driver Class Initialized
DEBUG - 2018-02-10 20:02:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:02:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 20:02:15 --> Form Validation Class Initialized
INFO - 2018-02-10 20:02:15 --> Model Class Initialized
INFO - 2018-02-10 20:02:15 --> Controller Class Initialized
INFO - 2018-02-10 20:02:15 --> Model Class Initialized
INFO - 2018-02-10 20:02:15 --> Model Class Initialized
INFO - 2018-02-10 20:02:15 --> Model Class Initialized
INFO - 2018-02-10 20:02:15 --> Model Class Initialized
DEBUG - 2018-02-10 20:02:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 20:02:15 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 20:02:15 --> Final output sent to browser
DEBUG - 2018-02-10 20:02:15 --> Total execution time: 0.0685
INFO - 2018-02-10 20:02:15 --> Config Class Initialized
INFO - 2018-02-10 20:02:15 --> Hooks Class Initialized
INFO - 2018-02-10 20:02:15 --> Config Class Initialized
INFO - 2018-02-10 20:02:15 --> Hooks Class Initialized
INFO - 2018-02-10 20:02:15 --> Config Class Initialized
INFO - 2018-02-10 20:02:15 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:02:15 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:02:15 --> Config Class Initialized
DEBUG - 2018-02-10 20:02:15 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:02:15 --> Hooks Class Initialized
INFO - 2018-02-10 20:02:15 --> Utf8 Class Initialized
INFO - 2018-02-10 20:02:15 --> Utf8 Class Initialized
DEBUG - 2018-02-10 20:02:15 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:02:15 --> Utf8 Class Initialized
INFO - 2018-02-10 20:02:15 --> URI Class Initialized
INFO - 2018-02-10 20:02:15 --> URI Class Initialized
INFO - 2018-02-10 20:02:15 --> URI Class Initialized
DEBUG - 2018-02-10 20:02:15 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:02:15 --> Router Class Initialized
INFO - 2018-02-10 20:02:15 --> Utf8 Class Initialized
INFO - 2018-02-10 20:02:15 --> Router Class Initialized
INFO - 2018-02-10 20:02:15 --> Router Class Initialized
INFO - 2018-02-10 20:02:15 --> URI Class Initialized
INFO - 2018-02-10 20:02:15 --> Output Class Initialized
INFO - 2018-02-10 20:02:15 --> Output Class Initialized
INFO - 2018-02-10 20:02:15 --> Output Class Initialized
INFO - 2018-02-10 20:02:15 --> Router Class Initialized
INFO - 2018-02-10 20:02:15 --> Security Class Initialized
INFO - 2018-02-10 20:02:15 --> Security Class Initialized
INFO - 2018-02-10 20:02:15 --> Security Class Initialized
DEBUG - 2018-02-10 20:02:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-10 20:02:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-10 20:02:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:02:15 --> Input Class Initialized
INFO - 2018-02-10 20:02:15 --> Output Class Initialized
INFO - 2018-02-10 20:02:15 --> Input Class Initialized
INFO - 2018-02-10 20:02:15 --> Input Class Initialized
INFO - 2018-02-10 20:02:15 --> Language Class Initialized
INFO - 2018-02-10 20:02:15 --> Language Class Initialized
INFO - 2018-02-10 20:02:15 --> Language Class Initialized
INFO - 2018-02-10 20:02:15 --> Security Class Initialized
ERROR - 2018-02-10 20:02:15 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-10 20:02:15 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-10 20:02:15 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-02-10 20:02:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:02:15 --> Input Class Initialized
INFO - 2018-02-10 20:02:15 --> Language Class Initialized
ERROR - 2018-02-10 20:02:15 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-10 20:02:15 --> Config Class Initialized
INFO - 2018-02-10 20:02:15 --> Config Class Initialized
INFO - 2018-02-10 20:02:15 --> Config Class Initialized
INFO - 2018-02-10 20:02:15 --> Hooks Class Initialized
INFO - 2018-02-10 20:02:15 --> Hooks Class Initialized
INFO - 2018-02-10 20:02:15 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:02:15 --> UTF-8 Support Enabled
DEBUG - 2018-02-10 20:02:15 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:02:15 --> Utf8 Class Initialized
DEBUG - 2018-02-10 20:02:15 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:02:15 --> Utf8 Class Initialized
INFO - 2018-02-10 20:02:15 --> Utf8 Class Initialized
INFO - 2018-02-10 20:02:15 --> URI Class Initialized
INFO - 2018-02-10 20:02:15 --> URI Class Initialized
INFO - 2018-02-10 20:02:15 --> URI Class Initialized
INFO - 2018-02-10 20:02:15 --> Router Class Initialized
INFO - 2018-02-10 20:02:15 --> Router Class Initialized
INFO - 2018-02-10 20:02:15 --> Router Class Initialized
INFO - 2018-02-10 20:02:15 --> Output Class Initialized
INFO - 2018-02-10 20:02:15 --> Output Class Initialized
INFO - 2018-02-10 20:02:15 --> Output Class Initialized
INFO - 2018-02-10 20:02:15 --> Security Class Initialized
INFO - 2018-02-10 20:02:15 --> Security Class Initialized
INFO - 2018-02-10 20:02:15 --> Security Class Initialized
DEBUG - 2018-02-10 20:02:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-10 20:02:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:02:15 --> Input Class Initialized
INFO - 2018-02-10 20:02:15 --> Input Class Initialized
DEBUG - 2018-02-10 20:02:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:02:15 --> Input Class Initialized
INFO - 2018-02-10 20:02:15 --> Language Class Initialized
INFO - 2018-02-10 20:02:15 --> Language Class Initialized
INFO - 2018-02-10 20:02:15 --> Language Class Initialized
ERROR - 2018-02-10 20:02:15 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-10 20:02:15 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-10 20:02:15 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-10 20:02:15 --> Config Class Initialized
INFO - 2018-02-10 20:02:15 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:02:15 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:02:15 --> Utf8 Class Initialized
INFO - 2018-02-10 20:02:15 --> URI Class Initialized
INFO - 2018-02-10 20:02:15 --> Router Class Initialized
INFO - 2018-02-10 20:02:15 --> Output Class Initialized
INFO - 2018-02-10 20:02:15 --> Security Class Initialized
DEBUG - 2018-02-10 20:02:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:02:15 --> Input Class Initialized
INFO - 2018-02-10 20:02:15 --> Language Class Initialized
INFO - 2018-02-10 20:02:15 --> Loader Class Initialized
INFO - 2018-02-10 20:02:15 --> Helper loaded: url_helper
INFO - 2018-02-10 20:02:15 --> Helper loaded: form_helper
INFO - 2018-02-10 20:02:15 --> Database Driver Class Initialized
DEBUG - 2018-02-10 20:02:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:02:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 20:02:15 --> Form Validation Class Initialized
INFO - 2018-02-10 20:02:15 --> Model Class Initialized
INFO - 2018-02-10 20:02:15 --> Controller Class Initialized
INFO - 2018-02-10 20:02:15 --> Model Class Initialized
INFO - 2018-02-10 20:02:15 --> Model Class Initialized
INFO - 2018-02-10 20:02:15 --> Model Class Initialized
INFO - 2018-02-10 20:02:15 --> Model Class Initialized
DEBUG - 2018-02-10 20:02:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 20:03:40 --> Config Class Initialized
INFO - 2018-02-10 20:03:40 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:03:40 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:03:40 --> Utf8 Class Initialized
INFO - 2018-02-10 20:03:40 --> URI Class Initialized
INFO - 2018-02-10 20:03:40 --> Router Class Initialized
INFO - 2018-02-10 20:03:40 --> Output Class Initialized
INFO - 2018-02-10 20:03:40 --> Security Class Initialized
DEBUG - 2018-02-10 20:03:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:03:40 --> Input Class Initialized
INFO - 2018-02-10 20:03:40 --> Language Class Initialized
INFO - 2018-02-10 20:03:40 --> Loader Class Initialized
INFO - 2018-02-10 20:03:40 --> Helper loaded: url_helper
INFO - 2018-02-10 20:03:40 --> Helper loaded: form_helper
INFO - 2018-02-10 20:03:40 --> Database Driver Class Initialized
DEBUG - 2018-02-10 20:03:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:03:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 20:03:40 --> Form Validation Class Initialized
INFO - 2018-02-10 20:03:40 --> Model Class Initialized
INFO - 2018-02-10 20:03:40 --> Controller Class Initialized
INFO - 2018-02-10 20:03:40 --> Model Class Initialized
INFO - 2018-02-10 20:03:40 --> Model Class Initialized
INFO - 2018-02-10 20:03:40 --> Model Class Initialized
INFO - 2018-02-10 20:03:40 --> Model Class Initialized
DEBUG - 2018-02-10 20:03:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 20:03:40 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 20:03:40 --> Final output sent to browser
DEBUG - 2018-02-10 20:03:40 --> Total execution time: 0.1124
INFO - 2018-02-10 20:03:40 --> Config Class Initialized
INFO - 2018-02-10 20:03:40 --> Config Class Initialized
INFO - 2018-02-10 20:03:40 --> Hooks Class Initialized
INFO - 2018-02-10 20:03:40 --> Hooks Class Initialized
INFO - 2018-02-10 20:03:40 --> Config Class Initialized
INFO - 2018-02-10 20:03:40 --> Hooks Class Initialized
INFO - 2018-02-10 20:03:40 --> Config Class Initialized
INFO - 2018-02-10 20:03:40 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:03:40 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:03:40 --> Utf8 Class Initialized
DEBUG - 2018-02-10 20:03:40 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:03:40 --> Utf8 Class Initialized
DEBUG - 2018-02-10 20:03:40 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:03:40 --> Utf8 Class Initialized
INFO - 2018-02-10 20:03:40 --> URI Class Initialized
INFO - 2018-02-10 20:03:40 --> URI Class Initialized
DEBUG - 2018-02-10 20:03:40 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:03:40 --> Utf8 Class Initialized
INFO - 2018-02-10 20:03:40 --> URI Class Initialized
INFO - 2018-02-10 20:03:40 --> Router Class Initialized
INFO - 2018-02-10 20:03:40 --> Router Class Initialized
INFO - 2018-02-10 20:03:40 --> URI Class Initialized
INFO - 2018-02-10 20:03:40 --> Output Class Initialized
INFO - 2018-02-10 20:03:40 --> Router Class Initialized
INFO - 2018-02-10 20:03:40 --> Output Class Initialized
INFO - 2018-02-10 20:03:40 --> Router Class Initialized
INFO - 2018-02-10 20:03:40 --> Security Class Initialized
INFO - 2018-02-10 20:03:40 --> Output Class Initialized
INFO - 2018-02-10 20:03:40 --> Security Class Initialized
DEBUG - 2018-02-10 20:03:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:03:40 --> Security Class Initialized
INFO - 2018-02-10 20:03:40 --> Output Class Initialized
INFO - 2018-02-10 20:03:40 --> Input Class Initialized
DEBUG - 2018-02-10 20:03:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:03:40 --> Input Class Initialized
INFO - 2018-02-10 20:03:40 --> Language Class Initialized
DEBUG - 2018-02-10 20:03:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:03:40 --> Language Class Initialized
INFO - 2018-02-10 20:03:40 --> Input Class Initialized
INFO - 2018-02-10 20:03:40 --> Security Class Initialized
INFO - 2018-02-10 20:03:40 --> Language Class Initialized
ERROR - 2018-02-10 20:03:40 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-10 20:03:40 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-02-10 20:03:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:03:40 --> Input Class Initialized
ERROR - 2018-02-10 20:03:40 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-10 20:03:40 --> Language Class Initialized
ERROR - 2018-02-10 20:03:40 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-10 20:03:40 --> Config Class Initialized
INFO - 2018-02-10 20:03:40 --> Hooks Class Initialized
INFO - 2018-02-10 20:03:40 --> Config Class Initialized
INFO - 2018-02-10 20:03:40 --> Hooks Class Initialized
INFO - 2018-02-10 20:03:40 --> Config Class Initialized
INFO - 2018-02-10 20:03:40 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:03:40 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:03:40 --> Utf8 Class Initialized
DEBUG - 2018-02-10 20:03:40 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:03:40 --> Utf8 Class Initialized
DEBUG - 2018-02-10 20:03:40 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:03:40 --> URI Class Initialized
INFO - 2018-02-10 20:03:40 --> Utf8 Class Initialized
INFO - 2018-02-10 20:03:40 --> URI Class Initialized
INFO - 2018-02-10 20:03:40 --> Router Class Initialized
INFO - 2018-02-10 20:03:40 --> URI Class Initialized
INFO - 2018-02-10 20:03:40 --> Router Class Initialized
INFO - 2018-02-10 20:03:40 --> Output Class Initialized
INFO - 2018-02-10 20:03:40 --> Output Class Initialized
INFO - 2018-02-10 20:03:40 --> Router Class Initialized
INFO - 2018-02-10 20:03:40 --> Security Class Initialized
INFO - 2018-02-10 20:03:40 --> Security Class Initialized
INFO - 2018-02-10 20:03:40 --> Output Class Initialized
DEBUG - 2018-02-10 20:03:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-10 20:03:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:03:40 --> Input Class Initialized
INFO - 2018-02-10 20:03:40 --> Input Class Initialized
INFO - 2018-02-10 20:03:40 --> Security Class Initialized
INFO - 2018-02-10 20:03:40 --> Language Class Initialized
INFO - 2018-02-10 20:03:40 --> Language Class Initialized
DEBUG - 2018-02-10 20:03:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:03:40 --> Input Class Initialized
ERROR - 2018-02-10 20:03:40 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-10 20:03:40 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-10 20:03:40 --> Language Class Initialized
ERROR - 2018-02-10 20:03:40 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-10 20:03:40 --> Config Class Initialized
INFO - 2018-02-10 20:03:40 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:03:40 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:03:40 --> Utf8 Class Initialized
INFO - 2018-02-10 20:03:40 --> URI Class Initialized
INFO - 2018-02-10 20:03:40 --> Router Class Initialized
INFO - 2018-02-10 20:03:40 --> Output Class Initialized
INFO - 2018-02-10 20:03:40 --> Security Class Initialized
DEBUG - 2018-02-10 20:03:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:03:40 --> Input Class Initialized
INFO - 2018-02-10 20:03:40 --> Language Class Initialized
INFO - 2018-02-10 20:03:40 --> Loader Class Initialized
INFO - 2018-02-10 20:03:40 --> Helper loaded: url_helper
INFO - 2018-02-10 20:03:40 --> Helper loaded: form_helper
INFO - 2018-02-10 20:03:40 --> Database Driver Class Initialized
DEBUG - 2018-02-10 20:03:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:03:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 20:03:40 --> Form Validation Class Initialized
INFO - 2018-02-10 20:03:40 --> Model Class Initialized
INFO - 2018-02-10 20:03:40 --> Controller Class Initialized
INFO - 2018-02-10 20:03:40 --> Model Class Initialized
INFO - 2018-02-10 20:03:40 --> Model Class Initialized
INFO - 2018-02-10 20:03:40 --> Model Class Initialized
INFO - 2018-02-10 20:03:40 --> Model Class Initialized
DEBUG - 2018-02-10 20:03:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 20:04:00 --> Config Class Initialized
INFO - 2018-02-10 20:04:00 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:04:00 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:04:00 --> Utf8 Class Initialized
INFO - 2018-02-10 20:04:00 --> URI Class Initialized
INFO - 2018-02-10 20:04:00 --> Router Class Initialized
INFO - 2018-02-10 20:04:00 --> Output Class Initialized
INFO - 2018-02-10 20:04:00 --> Security Class Initialized
DEBUG - 2018-02-10 20:04:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:04:00 --> Input Class Initialized
INFO - 2018-02-10 20:04:00 --> Language Class Initialized
INFO - 2018-02-10 20:04:00 --> Loader Class Initialized
INFO - 2018-02-10 20:04:00 --> Helper loaded: url_helper
INFO - 2018-02-10 20:04:00 --> Helper loaded: form_helper
INFO - 2018-02-10 20:04:00 --> Database Driver Class Initialized
DEBUG - 2018-02-10 20:04:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:04:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 20:04:00 --> Form Validation Class Initialized
INFO - 2018-02-10 20:04:00 --> Model Class Initialized
INFO - 2018-02-10 20:04:00 --> Controller Class Initialized
INFO - 2018-02-10 20:04:00 --> Model Class Initialized
INFO - 2018-02-10 20:04:00 --> Model Class Initialized
INFO - 2018-02-10 20:04:00 --> Model Class Initialized
INFO - 2018-02-10 20:04:00 --> Model Class Initialized
DEBUG - 2018-02-10 20:04:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 20:04:00 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 20:04:00 --> Final output sent to browser
DEBUG - 2018-02-10 20:04:00 --> Total execution time: 0.1527
INFO - 2018-02-10 20:04:00 --> Config Class Initialized
INFO - 2018-02-10 20:04:00 --> Config Class Initialized
INFO - 2018-02-10 20:04:00 --> Hooks Class Initialized
INFO - 2018-02-10 20:04:00 --> Hooks Class Initialized
INFO - 2018-02-10 20:04:00 --> Config Class Initialized
INFO - 2018-02-10 20:04:00 --> Hooks Class Initialized
INFO - 2018-02-10 20:04:00 --> Config Class Initialized
INFO - 2018-02-10 20:04:00 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:04:00 --> UTF-8 Support Enabled
DEBUG - 2018-02-10 20:04:00 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:04:00 --> Utf8 Class Initialized
INFO - 2018-02-10 20:04:00 --> Utf8 Class Initialized
DEBUG - 2018-02-10 20:04:00 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:04:00 --> Utf8 Class Initialized
INFO - 2018-02-10 20:04:00 --> URI Class Initialized
INFO - 2018-02-10 20:04:00 --> URI Class Initialized
DEBUG - 2018-02-10 20:04:00 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:04:00 --> Utf8 Class Initialized
INFO - 2018-02-10 20:04:00 --> URI Class Initialized
INFO - 2018-02-10 20:04:00 --> URI Class Initialized
INFO - 2018-02-10 20:04:00 --> Router Class Initialized
INFO - 2018-02-10 20:04:00 --> Router Class Initialized
INFO - 2018-02-10 20:04:00 --> Router Class Initialized
INFO - 2018-02-10 20:04:00 --> Router Class Initialized
INFO - 2018-02-10 20:04:00 --> Output Class Initialized
INFO - 2018-02-10 20:04:00 --> Output Class Initialized
INFO - 2018-02-10 20:04:00 --> Output Class Initialized
INFO - 2018-02-10 20:04:00 --> Security Class Initialized
INFO - 2018-02-10 20:04:00 --> Output Class Initialized
INFO - 2018-02-10 20:04:00 --> Security Class Initialized
INFO - 2018-02-10 20:04:00 --> Security Class Initialized
DEBUG - 2018-02-10 20:04:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:04:00 --> Input Class Initialized
INFO - 2018-02-10 20:04:00 --> Security Class Initialized
DEBUG - 2018-02-10 20:04:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-10 20:04:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:04:00 --> Input Class Initialized
INFO - 2018-02-10 20:04:00 --> Language Class Initialized
INFO - 2018-02-10 20:04:00 --> Input Class Initialized
DEBUG - 2018-02-10 20:04:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:04:00 --> Language Class Initialized
INFO - 2018-02-10 20:04:00 --> Input Class Initialized
INFO - 2018-02-10 20:04:00 --> Language Class Initialized
ERROR - 2018-02-10 20:04:00 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-10 20:04:00 --> Language Class Initialized
ERROR - 2018-02-10 20:04:00 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-10 20:04:00 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-10 20:04:00 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-10 20:04:00 --> Config Class Initialized
INFO - 2018-02-10 20:04:00 --> Hooks Class Initialized
INFO - 2018-02-10 20:04:00 --> Config Class Initialized
INFO - 2018-02-10 20:04:00 --> Hooks Class Initialized
INFO - 2018-02-10 20:04:00 --> Config Class Initialized
INFO - 2018-02-10 20:04:00 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:04:00 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:04:00 --> Utf8 Class Initialized
DEBUG - 2018-02-10 20:04:00 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:04:00 --> Utf8 Class Initialized
INFO - 2018-02-10 20:04:00 --> URI Class Initialized
DEBUG - 2018-02-10 20:04:00 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:04:00 --> URI Class Initialized
INFO - 2018-02-10 20:04:00 --> Utf8 Class Initialized
INFO - 2018-02-10 20:04:00 --> Router Class Initialized
INFO - 2018-02-10 20:04:00 --> Router Class Initialized
INFO - 2018-02-10 20:04:00 --> URI Class Initialized
INFO - 2018-02-10 20:04:00 --> Output Class Initialized
INFO - 2018-02-10 20:04:00 --> Output Class Initialized
INFO - 2018-02-10 20:04:00 --> Router Class Initialized
INFO - 2018-02-10 20:04:00 --> Security Class Initialized
INFO - 2018-02-10 20:04:00 --> Security Class Initialized
DEBUG - 2018-02-10 20:04:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-10 20:04:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:04:00 --> Output Class Initialized
INFO - 2018-02-10 20:04:00 --> Input Class Initialized
INFO - 2018-02-10 20:04:00 --> Input Class Initialized
INFO - 2018-02-10 20:04:00 --> Language Class Initialized
INFO - 2018-02-10 20:04:00 --> Language Class Initialized
INFO - 2018-02-10 20:04:00 --> Security Class Initialized
ERROR - 2018-02-10 20:04:00 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-10 20:04:00 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-02-10 20:04:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:04:00 --> Input Class Initialized
INFO - 2018-02-10 20:04:00 --> Language Class Initialized
ERROR - 2018-02-10 20:04:00 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-10 20:04:00 --> Config Class Initialized
INFO - 2018-02-10 20:04:00 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:04:00 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:04:00 --> Utf8 Class Initialized
INFO - 2018-02-10 20:04:00 --> URI Class Initialized
INFO - 2018-02-10 20:04:00 --> Router Class Initialized
INFO - 2018-02-10 20:04:00 --> Output Class Initialized
INFO - 2018-02-10 20:04:00 --> Security Class Initialized
DEBUG - 2018-02-10 20:04:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:04:00 --> Input Class Initialized
INFO - 2018-02-10 20:04:00 --> Language Class Initialized
INFO - 2018-02-10 20:04:00 --> Loader Class Initialized
INFO - 2018-02-10 20:04:00 --> Helper loaded: url_helper
INFO - 2018-02-10 20:04:00 --> Helper loaded: form_helper
INFO - 2018-02-10 20:04:00 --> Database Driver Class Initialized
DEBUG - 2018-02-10 20:04:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:04:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 20:04:00 --> Form Validation Class Initialized
INFO - 2018-02-10 20:04:00 --> Model Class Initialized
INFO - 2018-02-10 20:04:00 --> Controller Class Initialized
INFO - 2018-02-10 20:04:00 --> Model Class Initialized
INFO - 2018-02-10 20:04:00 --> Model Class Initialized
INFO - 2018-02-10 20:04:00 --> Model Class Initialized
INFO - 2018-02-10 20:04:00 --> Model Class Initialized
DEBUG - 2018-02-10 20:04:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 20:04:01 --> Config Class Initialized
INFO - 2018-02-10 20:04:01 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:04:01 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:04:01 --> Utf8 Class Initialized
INFO - 2018-02-10 20:04:01 --> URI Class Initialized
INFO - 2018-02-10 20:04:01 --> Router Class Initialized
INFO - 2018-02-10 20:04:01 --> Output Class Initialized
INFO - 2018-02-10 20:04:01 --> Security Class Initialized
DEBUG - 2018-02-10 20:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:04:01 --> Input Class Initialized
INFO - 2018-02-10 20:04:01 --> Language Class Initialized
INFO - 2018-02-10 20:04:01 --> Loader Class Initialized
INFO - 2018-02-10 20:04:01 --> Helper loaded: url_helper
INFO - 2018-02-10 20:04:01 --> Helper loaded: form_helper
INFO - 2018-02-10 20:04:01 --> Database Driver Class Initialized
DEBUG - 2018-02-10 20:04:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:04:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 20:04:01 --> Form Validation Class Initialized
INFO - 2018-02-10 20:04:01 --> Model Class Initialized
INFO - 2018-02-10 20:04:01 --> Controller Class Initialized
INFO - 2018-02-10 20:04:01 --> Model Class Initialized
INFO - 2018-02-10 20:04:01 --> Model Class Initialized
INFO - 2018-02-10 20:04:01 --> Model Class Initialized
INFO - 2018-02-10 20:04:01 --> Model Class Initialized
DEBUG - 2018-02-10 20:04:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 20:04:01 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 20:04:01 --> Final output sent to browser
DEBUG - 2018-02-10 20:04:01 --> Total execution time: 0.0840
INFO - 2018-02-10 20:04:02 --> Config Class Initialized
INFO - 2018-02-10 20:04:02 --> Hooks Class Initialized
INFO - 2018-02-10 20:04:02 --> Config Class Initialized
INFO - 2018-02-10 20:04:02 --> Hooks Class Initialized
INFO - 2018-02-10 20:04:02 --> Config Class Initialized
INFO - 2018-02-10 20:04:02 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:04:02 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:04:02 --> Utf8 Class Initialized
DEBUG - 2018-02-10 20:04:02 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:04:02 --> Utf8 Class Initialized
INFO - 2018-02-10 20:04:02 --> URI Class Initialized
DEBUG - 2018-02-10 20:04:02 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:04:02 --> URI Class Initialized
INFO - 2018-02-10 20:04:02 --> Utf8 Class Initialized
INFO - 2018-02-10 20:04:02 --> Router Class Initialized
INFO - 2018-02-10 20:04:02 --> URI Class Initialized
INFO - 2018-02-10 20:04:02 --> Router Class Initialized
INFO - 2018-02-10 20:04:02 --> Output Class Initialized
INFO - 2018-02-10 20:04:02 --> Router Class Initialized
INFO - 2018-02-10 20:04:02 --> Security Class Initialized
INFO - 2018-02-10 20:04:02 --> Output Class Initialized
DEBUG - 2018-02-10 20:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:04:02 --> Input Class Initialized
INFO - 2018-02-10 20:04:02 --> Output Class Initialized
INFO - 2018-02-10 20:04:02 --> Security Class Initialized
INFO - 2018-02-10 20:04:02 --> Language Class Initialized
DEBUG - 2018-02-10 20:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:04:02 --> Security Class Initialized
ERROR - 2018-02-10 20:04:02 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-10 20:04:02 --> Input Class Initialized
INFO - 2018-02-10 20:04:02 --> Language Class Initialized
DEBUG - 2018-02-10 20:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:04:02 --> Input Class Initialized
INFO - 2018-02-10 20:04:02 --> Language Class Initialized
ERROR - 2018-02-10 20:04:02 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-10 20:04:02 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-10 20:04:02 --> Config Class Initialized
INFO - 2018-02-10 20:04:02 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:04:02 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:04:02 --> Utf8 Class Initialized
INFO - 2018-02-10 20:04:02 --> URI Class Initialized
INFO - 2018-02-10 20:04:02 --> Router Class Initialized
INFO - 2018-02-10 20:04:02 --> Output Class Initialized
INFO - 2018-02-10 20:04:02 --> Security Class Initialized
DEBUG - 2018-02-10 20:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:04:02 --> Input Class Initialized
INFO - 2018-02-10 20:04:02 --> Language Class Initialized
ERROR - 2018-02-10 20:04:02 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-10 20:04:02 --> Config Class Initialized
INFO - 2018-02-10 20:04:02 --> Hooks Class Initialized
INFO - 2018-02-10 20:04:02 --> Config Class Initialized
INFO - 2018-02-10 20:04:02 --> Hooks Class Initialized
INFO - 2018-02-10 20:04:02 --> Config Class Initialized
INFO - 2018-02-10 20:04:02 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:04:02 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:04:02 --> Utf8 Class Initialized
INFO - 2018-02-10 20:04:02 --> URI Class Initialized
DEBUG - 2018-02-10 20:04:02 --> UTF-8 Support Enabled
DEBUG - 2018-02-10 20:04:02 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:04:02 --> Utf8 Class Initialized
INFO - 2018-02-10 20:04:02 --> Router Class Initialized
INFO - 2018-02-10 20:04:02 --> Utf8 Class Initialized
INFO - 2018-02-10 20:04:02 --> URI Class Initialized
INFO - 2018-02-10 20:04:02 --> URI Class Initialized
INFO - 2018-02-10 20:04:02 --> Output Class Initialized
INFO - 2018-02-10 20:04:02 --> Router Class Initialized
INFO - 2018-02-10 20:04:02 --> Router Class Initialized
INFO - 2018-02-10 20:04:02 --> Security Class Initialized
INFO - 2018-02-10 20:04:02 --> Output Class Initialized
INFO - 2018-02-10 20:04:02 --> Output Class Initialized
DEBUG - 2018-02-10 20:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:04:02 --> Input Class Initialized
INFO - 2018-02-10 20:04:02 --> Security Class Initialized
INFO - 2018-02-10 20:04:02 --> Language Class Initialized
INFO - 2018-02-10 20:04:02 --> Security Class Initialized
DEBUG - 2018-02-10 20:04:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-10 20:04:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-10 20:04:02 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-10 20:04:02 --> Input Class Initialized
INFO - 2018-02-10 20:04:02 --> Input Class Initialized
INFO - 2018-02-10 20:04:02 --> Language Class Initialized
INFO - 2018-02-10 20:04:02 --> Language Class Initialized
ERROR - 2018-02-10 20:04:02 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-10 20:04:02 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-10 20:04:02 --> Config Class Initialized
INFO - 2018-02-10 20:04:02 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:04:02 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:04:02 --> Utf8 Class Initialized
INFO - 2018-02-10 20:04:02 --> URI Class Initialized
INFO - 2018-02-10 20:04:02 --> Router Class Initialized
INFO - 2018-02-10 20:04:02 --> Output Class Initialized
INFO - 2018-02-10 20:04:02 --> Security Class Initialized
DEBUG - 2018-02-10 20:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:04:02 --> Input Class Initialized
INFO - 2018-02-10 20:04:02 --> Language Class Initialized
INFO - 2018-02-10 20:04:02 --> Loader Class Initialized
INFO - 2018-02-10 20:04:02 --> Helper loaded: url_helper
INFO - 2018-02-10 20:04:02 --> Helper loaded: form_helper
INFO - 2018-02-10 20:04:02 --> Database Driver Class Initialized
DEBUG - 2018-02-10 20:04:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:04:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 20:04:02 --> Form Validation Class Initialized
INFO - 2018-02-10 20:04:02 --> Model Class Initialized
INFO - 2018-02-10 20:04:02 --> Controller Class Initialized
INFO - 2018-02-10 20:04:02 --> Model Class Initialized
INFO - 2018-02-10 20:04:02 --> Model Class Initialized
INFO - 2018-02-10 20:04:02 --> Model Class Initialized
INFO - 2018-02-10 20:04:02 --> Model Class Initialized
DEBUG - 2018-02-10 20:04:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 20:04:25 --> Config Class Initialized
INFO - 2018-02-10 20:04:25 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:04:25 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:04:25 --> Utf8 Class Initialized
INFO - 2018-02-10 20:04:25 --> URI Class Initialized
INFO - 2018-02-10 20:04:25 --> Router Class Initialized
INFO - 2018-02-10 20:04:25 --> Output Class Initialized
INFO - 2018-02-10 20:04:25 --> Security Class Initialized
DEBUG - 2018-02-10 20:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:04:25 --> Input Class Initialized
INFO - 2018-02-10 20:04:25 --> Language Class Initialized
INFO - 2018-02-10 20:04:25 --> Loader Class Initialized
INFO - 2018-02-10 20:04:25 --> Helper loaded: url_helper
INFO - 2018-02-10 20:04:25 --> Helper loaded: form_helper
INFO - 2018-02-10 20:04:25 --> Database Driver Class Initialized
DEBUG - 2018-02-10 20:04:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:04:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 20:04:25 --> Form Validation Class Initialized
INFO - 2018-02-10 20:04:25 --> Model Class Initialized
INFO - 2018-02-10 20:04:25 --> Controller Class Initialized
INFO - 2018-02-10 20:04:25 --> Model Class Initialized
INFO - 2018-02-10 20:04:25 --> Model Class Initialized
INFO - 2018-02-10 20:04:25 --> Model Class Initialized
INFO - 2018-02-10 20:04:25 --> Model Class Initialized
DEBUG - 2018-02-10 20:04:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 20:04:25 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 20:04:25 --> Final output sent to browser
DEBUG - 2018-02-10 20:04:25 --> Total execution time: 0.1032
INFO - 2018-02-10 20:04:25 --> Config Class Initialized
INFO - 2018-02-10 20:04:25 --> Hooks Class Initialized
INFO - 2018-02-10 20:04:25 --> Config Class Initialized
INFO - 2018-02-10 20:04:25 --> Hooks Class Initialized
INFO - 2018-02-10 20:04:25 --> Config Class Initialized
INFO - 2018-02-10 20:04:25 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:04:25 --> UTF-8 Support Enabled
DEBUG - 2018-02-10 20:04:25 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:04:25 --> Utf8 Class Initialized
DEBUG - 2018-02-10 20:04:25 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:04:25 --> Utf8 Class Initialized
INFO - 2018-02-10 20:04:25 --> Utf8 Class Initialized
INFO - 2018-02-10 20:04:25 --> URI Class Initialized
INFO - 2018-02-10 20:04:25 --> URI Class Initialized
INFO - 2018-02-10 20:04:25 --> URI Class Initialized
INFO - 2018-02-10 20:04:25 --> Router Class Initialized
INFO - 2018-02-10 20:04:25 --> Router Class Initialized
INFO - 2018-02-10 20:04:25 --> Output Class Initialized
INFO - 2018-02-10 20:04:25 --> Output Class Initialized
INFO - 2018-02-10 20:04:25 --> Router Class Initialized
INFO - 2018-02-10 20:04:25 --> Security Class Initialized
INFO - 2018-02-10 20:04:25 --> Security Class Initialized
DEBUG - 2018-02-10 20:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:04:25 --> Input Class Initialized
INFO - 2018-02-10 20:04:25 --> Output Class Initialized
DEBUG - 2018-02-10 20:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:04:25 --> Language Class Initialized
INFO - 2018-02-10 20:04:25 --> Input Class Initialized
INFO - 2018-02-10 20:04:25 --> Security Class Initialized
INFO - 2018-02-10 20:04:25 --> Language Class Initialized
ERROR - 2018-02-10 20:04:25 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-02-10 20:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:04:25 --> Input Class Initialized
ERROR - 2018-02-10 20:04:25 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-10 20:04:25 --> Language Class Initialized
ERROR - 2018-02-10 20:04:25 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-10 20:04:25 --> Config Class Initialized
INFO - 2018-02-10 20:04:25 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:04:25 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:04:25 --> Utf8 Class Initialized
INFO - 2018-02-10 20:04:25 --> URI Class Initialized
INFO - 2018-02-10 20:04:25 --> Router Class Initialized
INFO - 2018-02-10 20:04:25 --> Output Class Initialized
INFO - 2018-02-10 20:04:25 --> Security Class Initialized
DEBUG - 2018-02-10 20:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:04:25 --> Input Class Initialized
INFO - 2018-02-10 20:04:25 --> Language Class Initialized
ERROR - 2018-02-10 20:04:25 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-10 20:04:25 --> Config Class Initialized
INFO - 2018-02-10 20:04:25 --> Hooks Class Initialized
INFO - 2018-02-10 20:04:25 --> Config Class Initialized
INFO - 2018-02-10 20:04:25 --> Hooks Class Initialized
INFO - 2018-02-10 20:04:25 --> Config Class Initialized
INFO - 2018-02-10 20:04:25 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:04:25 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:04:25 --> Utf8 Class Initialized
DEBUG - 2018-02-10 20:04:25 --> UTF-8 Support Enabled
DEBUG - 2018-02-10 20:04:25 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:04:25 --> Utf8 Class Initialized
INFO - 2018-02-10 20:04:25 --> Utf8 Class Initialized
INFO - 2018-02-10 20:04:25 --> URI Class Initialized
INFO - 2018-02-10 20:04:25 --> URI Class Initialized
INFO - 2018-02-10 20:04:25 --> URI Class Initialized
INFO - 2018-02-10 20:04:25 --> Router Class Initialized
INFO - 2018-02-10 20:04:25 --> Router Class Initialized
INFO - 2018-02-10 20:04:25 --> Router Class Initialized
INFO - 2018-02-10 20:04:25 --> Output Class Initialized
INFO - 2018-02-10 20:04:25 --> Output Class Initialized
INFO - 2018-02-10 20:04:25 --> Output Class Initialized
INFO - 2018-02-10 20:04:25 --> Security Class Initialized
DEBUG - 2018-02-10 20:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:04:25 --> Security Class Initialized
INFO - 2018-02-10 20:04:25 --> Input Class Initialized
INFO - 2018-02-10 20:04:25 --> Security Class Initialized
INFO - 2018-02-10 20:04:25 --> Language Class Initialized
DEBUG - 2018-02-10 20:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:04:25 --> Input Class Initialized
DEBUG - 2018-02-10 20:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:04:25 --> Input Class Initialized
ERROR - 2018-02-10 20:04:25 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-10 20:04:25 --> Language Class Initialized
INFO - 2018-02-10 20:04:25 --> Language Class Initialized
ERROR - 2018-02-10 20:04:25 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-10 20:04:25 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-10 20:04:25 --> Config Class Initialized
INFO - 2018-02-10 20:04:25 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:04:25 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:04:25 --> Utf8 Class Initialized
INFO - 2018-02-10 20:04:25 --> URI Class Initialized
INFO - 2018-02-10 20:04:25 --> Router Class Initialized
INFO - 2018-02-10 20:04:25 --> Output Class Initialized
INFO - 2018-02-10 20:04:25 --> Security Class Initialized
DEBUG - 2018-02-10 20:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:04:25 --> Input Class Initialized
INFO - 2018-02-10 20:04:25 --> Language Class Initialized
INFO - 2018-02-10 20:04:25 --> Loader Class Initialized
INFO - 2018-02-10 20:04:25 --> Helper loaded: url_helper
INFO - 2018-02-10 20:04:25 --> Helper loaded: form_helper
INFO - 2018-02-10 20:04:25 --> Database Driver Class Initialized
DEBUG - 2018-02-10 20:04:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:04:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 20:04:25 --> Form Validation Class Initialized
INFO - 2018-02-10 20:04:25 --> Model Class Initialized
INFO - 2018-02-10 20:04:25 --> Controller Class Initialized
INFO - 2018-02-10 20:04:25 --> Model Class Initialized
INFO - 2018-02-10 20:04:25 --> Model Class Initialized
INFO - 2018-02-10 20:04:25 --> Model Class Initialized
INFO - 2018-02-10 20:04:25 --> Model Class Initialized
DEBUG - 2018-02-10 20:04:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 20:04:40 --> Config Class Initialized
INFO - 2018-02-10 20:04:40 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:04:40 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:04:40 --> Utf8 Class Initialized
INFO - 2018-02-10 20:04:40 --> URI Class Initialized
INFO - 2018-02-10 20:04:40 --> Router Class Initialized
INFO - 2018-02-10 20:04:40 --> Output Class Initialized
INFO - 2018-02-10 20:04:40 --> Security Class Initialized
DEBUG - 2018-02-10 20:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:04:40 --> Input Class Initialized
INFO - 2018-02-10 20:04:40 --> Language Class Initialized
INFO - 2018-02-10 20:04:40 --> Loader Class Initialized
INFO - 2018-02-10 20:04:40 --> Helper loaded: url_helper
INFO - 2018-02-10 20:04:40 --> Helper loaded: form_helper
INFO - 2018-02-10 20:04:40 --> Database Driver Class Initialized
DEBUG - 2018-02-10 20:04:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:04:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 20:04:40 --> Form Validation Class Initialized
INFO - 2018-02-10 20:04:40 --> Model Class Initialized
INFO - 2018-02-10 20:04:40 --> Controller Class Initialized
INFO - 2018-02-10 20:04:40 --> Model Class Initialized
INFO - 2018-02-10 20:04:40 --> Model Class Initialized
INFO - 2018-02-10 20:04:40 --> Model Class Initialized
INFO - 2018-02-10 20:04:40 --> Model Class Initialized
DEBUG - 2018-02-10 20:04:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 20:04:40 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 20:04:40 --> Final output sent to browser
DEBUG - 2018-02-10 20:04:40 --> Total execution time: 0.0826
INFO - 2018-02-10 20:04:40 --> Config Class Initialized
INFO - 2018-02-10 20:04:40 --> Config Class Initialized
INFO - 2018-02-10 20:04:40 --> Config Class Initialized
INFO - 2018-02-10 20:04:40 --> Hooks Class Initialized
INFO - 2018-02-10 20:04:40 --> Hooks Class Initialized
INFO - 2018-02-10 20:04:40 --> Hooks Class Initialized
INFO - 2018-02-10 20:04:40 --> Config Class Initialized
INFO - 2018-02-10 20:04:40 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:04:40 --> UTF-8 Support Enabled
DEBUG - 2018-02-10 20:04:40 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:04:40 --> Utf8 Class Initialized
DEBUG - 2018-02-10 20:04:40 --> UTF-8 Support Enabled
DEBUG - 2018-02-10 20:04:40 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:04:40 --> Utf8 Class Initialized
INFO - 2018-02-10 20:04:40 --> Utf8 Class Initialized
INFO - 2018-02-10 20:04:40 --> Utf8 Class Initialized
INFO - 2018-02-10 20:04:40 --> URI Class Initialized
INFO - 2018-02-10 20:04:40 --> URI Class Initialized
INFO - 2018-02-10 20:04:40 --> URI Class Initialized
INFO - 2018-02-10 20:04:40 --> URI Class Initialized
INFO - 2018-02-10 20:04:40 --> Router Class Initialized
INFO - 2018-02-10 20:04:40 --> Router Class Initialized
INFO - 2018-02-10 20:04:40 --> Router Class Initialized
INFO - 2018-02-10 20:04:40 --> Router Class Initialized
INFO - 2018-02-10 20:04:40 --> Output Class Initialized
INFO - 2018-02-10 20:04:40 --> Output Class Initialized
INFO - 2018-02-10 20:04:40 --> Output Class Initialized
INFO - 2018-02-10 20:04:40 --> Output Class Initialized
INFO - 2018-02-10 20:04:40 --> Security Class Initialized
INFO - 2018-02-10 20:04:40 --> Security Class Initialized
INFO - 2018-02-10 20:04:40 --> Security Class Initialized
INFO - 2018-02-10 20:04:40 --> Security Class Initialized
DEBUG - 2018-02-10 20:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:04:40 --> Input Class Initialized
DEBUG - 2018-02-10 20:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:04:40 --> Input Class Initialized
INFO - 2018-02-10 20:04:40 --> Language Class Initialized
DEBUG - 2018-02-10 20:04:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-10 20:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:04:40 --> Input Class Initialized
INFO - 2018-02-10 20:04:40 --> Input Class Initialized
INFO - 2018-02-10 20:04:40 --> Language Class Initialized
ERROR - 2018-02-10 20:04:40 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-10 20:04:40 --> Language Class Initialized
INFO - 2018-02-10 20:04:40 --> Language Class Initialized
ERROR - 2018-02-10 20:04:40 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-10 20:04:40 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-10 20:04:40 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-10 20:04:40 --> Config Class Initialized
INFO - 2018-02-10 20:04:40 --> Hooks Class Initialized
INFO - 2018-02-10 20:04:40 --> Config Class Initialized
INFO - 2018-02-10 20:04:40 --> Config Class Initialized
INFO - 2018-02-10 20:04:40 --> Hooks Class Initialized
INFO - 2018-02-10 20:04:40 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:04:40 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:04:40 --> Utf8 Class Initialized
DEBUG - 2018-02-10 20:04:40 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:04:40 --> Utf8 Class Initialized
DEBUG - 2018-02-10 20:04:40 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:04:40 --> Utf8 Class Initialized
INFO - 2018-02-10 20:04:40 --> URI Class Initialized
INFO - 2018-02-10 20:04:40 --> URI Class Initialized
INFO - 2018-02-10 20:04:40 --> URI Class Initialized
INFO - 2018-02-10 20:04:40 --> Router Class Initialized
INFO - 2018-02-10 20:04:40 --> Router Class Initialized
INFO - 2018-02-10 20:04:40 --> Router Class Initialized
INFO - 2018-02-10 20:04:40 --> Output Class Initialized
INFO - 2018-02-10 20:04:40 --> Output Class Initialized
INFO - 2018-02-10 20:04:40 --> Output Class Initialized
INFO - 2018-02-10 20:04:40 --> Security Class Initialized
INFO - 2018-02-10 20:04:40 --> Security Class Initialized
INFO - 2018-02-10 20:04:40 --> Security Class Initialized
DEBUG - 2018-02-10 20:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:04:40 --> Input Class Initialized
DEBUG - 2018-02-10 20:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:04:40 --> Input Class Initialized
DEBUG - 2018-02-10 20:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:04:40 --> Language Class Initialized
INFO - 2018-02-10 20:04:40 --> Input Class Initialized
INFO - 2018-02-10 20:04:40 --> Language Class Initialized
INFO - 2018-02-10 20:04:40 --> Language Class Initialized
ERROR - 2018-02-10 20:04:40 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-10 20:04:40 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-10 20:04:40 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-10 20:04:40 --> Config Class Initialized
INFO - 2018-02-10 20:04:40 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:04:40 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:04:40 --> Utf8 Class Initialized
INFO - 2018-02-10 20:04:40 --> URI Class Initialized
INFO - 2018-02-10 20:04:40 --> Router Class Initialized
INFO - 2018-02-10 20:04:40 --> Output Class Initialized
INFO - 2018-02-10 20:04:40 --> Security Class Initialized
DEBUG - 2018-02-10 20:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:04:40 --> Input Class Initialized
INFO - 2018-02-10 20:04:40 --> Language Class Initialized
INFO - 2018-02-10 20:04:40 --> Loader Class Initialized
INFO - 2018-02-10 20:04:40 --> Helper loaded: url_helper
INFO - 2018-02-10 20:04:40 --> Helper loaded: form_helper
INFO - 2018-02-10 20:04:40 --> Database Driver Class Initialized
DEBUG - 2018-02-10 20:04:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:04:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 20:04:40 --> Form Validation Class Initialized
INFO - 2018-02-10 20:04:40 --> Model Class Initialized
INFO - 2018-02-10 20:04:40 --> Controller Class Initialized
INFO - 2018-02-10 20:04:40 --> Model Class Initialized
INFO - 2018-02-10 20:04:40 --> Model Class Initialized
INFO - 2018-02-10 20:04:40 --> Model Class Initialized
INFO - 2018-02-10 20:04:40 --> Model Class Initialized
DEBUG - 2018-02-10 20:04:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 20:05:03 --> Config Class Initialized
INFO - 2018-02-10 20:05:03 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:05:03 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:05:03 --> Utf8 Class Initialized
INFO - 2018-02-10 20:05:03 --> URI Class Initialized
INFO - 2018-02-10 20:05:03 --> Router Class Initialized
INFO - 2018-02-10 20:05:03 --> Output Class Initialized
INFO - 2018-02-10 20:05:03 --> Security Class Initialized
DEBUG - 2018-02-10 20:05:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:05:03 --> Input Class Initialized
INFO - 2018-02-10 20:05:03 --> Language Class Initialized
INFO - 2018-02-10 20:05:03 --> Loader Class Initialized
INFO - 2018-02-10 20:05:03 --> Helper loaded: url_helper
INFO - 2018-02-10 20:05:03 --> Helper loaded: form_helper
INFO - 2018-02-10 20:05:03 --> Database Driver Class Initialized
DEBUG - 2018-02-10 20:05:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:05:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 20:05:03 --> Form Validation Class Initialized
INFO - 2018-02-10 20:05:03 --> Model Class Initialized
INFO - 2018-02-10 20:05:03 --> Controller Class Initialized
INFO - 2018-02-10 20:05:03 --> Model Class Initialized
INFO - 2018-02-10 20:05:03 --> Model Class Initialized
INFO - 2018-02-10 20:05:03 --> Model Class Initialized
INFO - 2018-02-10 20:05:03 --> Model Class Initialized
DEBUG - 2018-02-10 20:05:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 20:05:03 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 20:05:03 --> Final output sent to browser
DEBUG - 2018-02-10 20:05:03 --> Total execution time: 0.0868
INFO - 2018-02-10 20:05:03 --> Config Class Initialized
INFO - 2018-02-10 20:05:03 --> Config Class Initialized
INFO - 2018-02-10 20:05:03 --> Hooks Class Initialized
INFO - 2018-02-10 20:05:03 --> Hooks Class Initialized
INFO - 2018-02-10 20:05:03 --> Config Class Initialized
INFO - 2018-02-10 20:05:03 --> Hooks Class Initialized
INFO - 2018-02-10 20:05:03 --> Config Class Initialized
INFO - 2018-02-10 20:05:03 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:05:03 --> UTF-8 Support Enabled
DEBUG - 2018-02-10 20:05:03 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:05:03 --> Utf8 Class Initialized
INFO - 2018-02-10 20:05:03 --> Utf8 Class Initialized
DEBUG - 2018-02-10 20:05:03 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:05:03 --> Utf8 Class Initialized
INFO - 2018-02-10 20:05:03 --> URI Class Initialized
INFO - 2018-02-10 20:05:03 --> URI Class Initialized
INFO - 2018-02-10 20:05:03 --> URI Class Initialized
DEBUG - 2018-02-10 20:05:03 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:05:03 --> Utf8 Class Initialized
INFO - 2018-02-10 20:05:03 --> Router Class Initialized
INFO - 2018-02-10 20:05:03 --> Router Class Initialized
INFO - 2018-02-10 20:05:03 --> URI Class Initialized
INFO - 2018-02-10 20:05:03 --> Router Class Initialized
INFO - 2018-02-10 20:05:03 --> Output Class Initialized
INFO - 2018-02-10 20:05:03 --> Output Class Initialized
INFO - 2018-02-10 20:05:03 --> Router Class Initialized
INFO - 2018-02-10 20:05:03 --> Output Class Initialized
INFO - 2018-02-10 20:05:03 --> Security Class Initialized
INFO - 2018-02-10 20:05:03 --> Security Class Initialized
INFO - 2018-02-10 20:05:03 --> Output Class Initialized
INFO - 2018-02-10 20:05:03 --> Security Class Initialized
DEBUG - 2018-02-10 20:05:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:05:03 --> Input Class Initialized
DEBUG - 2018-02-10 20:05:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:05:03 --> Input Class Initialized
INFO - 2018-02-10 20:05:03 --> Security Class Initialized
DEBUG - 2018-02-10 20:05:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:05:03 --> Language Class Initialized
INFO - 2018-02-10 20:05:03 --> Language Class Initialized
INFO - 2018-02-10 20:05:03 --> Input Class Initialized
DEBUG - 2018-02-10 20:05:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:05:03 --> Language Class Initialized
ERROR - 2018-02-10 20:05:03 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-10 20:05:04 --> Input Class Initialized
ERROR - 2018-02-10 20:05:04 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-10 20:05:04 --> Language Class Initialized
ERROR - 2018-02-10 20:05:04 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-10 20:05:04 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-10 20:05:04 --> Config Class Initialized
INFO - 2018-02-10 20:05:04 --> Hooks Class Initialized
INFO - 2018-02-10 20:05:04 --> Config Class Initialized
INFO - 2018-02-10 20:05:04 --> Config Class Initialized
INFO - 2018-02-10 20:05:04 --> Hooks Class Initialized
INFO - 2018-02-10 20:05:04 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:05:04 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:05:04 --> Utf8 Class Initialized
INFO - 2018-02-10 20:05:04 --> URI Class Initialized
DEBUG - 2018-02-10 20:05:04 --> UTF-8 Support Enabled
DEBUG - 2018-02-10 20:05:04 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:05:04 --> Utf8 Class Initialized
INFO - 2018-02-10 20:05:04 --> Utf8 Class Initialized
INFO - 2018-02-10 20:05:04 --> Router Class Initialized
INFO - 2018-02-10 20:05:04 --> URI Class Initialized
INFO - 2018-02-10 20:05:04 --> URI Class Initialized
INFO - 2018-02-10 20:05:04 --> Output Class Initialized
INFO - 2018-02-10 20:05:04 --> Router Class Initialized
INFO - 2018-02-10 20:05:04 --> Router Class Initialized
INFO - 2018-02-10 20:05:04 --> Security Class Initialized
INFO - 2018-02-10 20:05:04 --> Output Class Initialized
INFO - 2018-02-10 20:05:04 --> Output Class Initialized
DEBUG - 2018-02-10 20:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:05:04 --> Input Class Initialized
INFO - 2018-02-10 20:05:04 --> Security Class Initialized
INFO - 2018-02-10 20:05:04 --> Language Class Initialized
INFO - 2018-02-10 20:05:04 --> Security Class Initialized
DEBUG - 2018-02-10 20:05:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-10 20:05:04 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-02-10 20:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:05:04 --> Input Class Initialized
INFO - 2018-02-10 20:05:04 --> Input Class Initialized
INFO - 2018-02-10 20:05:04 --> Language Class Initialized
INFO - 2018-02-10 20:05:04 --> Language Class Initialized
ERROR - 2018-02-10 20:05:04 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-10 20:05:04 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-10 20:05:04 --> Config Class Initialized
INFO - 2018-02-10 20:05:04 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:05:04 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:05:04 --> Utf8 Class Initialized
INFO - 2018-02-10 20:05:04 --> URI Class Initialized
INFO - 2018-02-10 20:05:04 --> Router Class Initialized
INFO - 2018-02-10 20:05:04 --> Output Class Initialized
INFO - 2018-02-10 20:05:04 --> Security Class Initialized
DEBUG - 2018-02-10 20:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:05:04 --> Input Class Initialized
INFO - 2018-02-10 20:05:04 --> Language Class Initialized
INFO - 2018-02-10 20:05:04 --> Loader Class Initialized
INFO - 2018-02-10 20:05:04 --> Helper loaded: url_helper
INFO - 2018-02-10 20:05:04 --> Helper loaded: form_helper
INFO - 2018-02-10 20:05:04 --> Database Driver Class Initialized
DEBUG - 2018-02-10 20:05:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:05:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 20:05:04 --> Form Validation Class Initialized
INFO - 2018-02-10 20:05:04 --> Model Class Initialized
INFO - 2018-02-10 20:05:04 --> Controller Class Initialized
INFO - 2018-02-10 20:05:04 --> Model Class Initialized
INFO - 2018-02-10 20:05:04 --> Model Class Initialized
INFO - 2018-02-10 20:05:04 --> Model Class Initialized
INFO - 2018-02-10 20:05:04 --> Model Class Initialized
DEBUG - 2018-02-10 20:05:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 20:05:07 --> Config Class Initialized
INFO - 2018-02-10 20:05:07 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:05:07 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:05:07 --> Utf8 Class Initialized
INFO - 2018-02-10 20:05:07 --> URI Class Initialized
INFO - 2018-02-10 20:05:07 --> Router Class Initialized
INFO - 2018-02-10 20:05:07 --> Output Class Initialized
INFO - 2018-02-10 20:05:07 --> Security Class Initialized
DEBUG - 2018-02-10 20:05:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:05:07 --> Input Class Initialized
INFO - 2018-02-10 20:05:07 --> Language Class Initialized
INFO - 2018-02-10 20:05:07 --> Loader Class Initialized
INFO - 2018-02-10 20:05:07 --> Helper loaded: url_helper
INFO - 2018-02-10 20:05:07 --> Helper loaded: form_helper
INFO - 2018-02-10 20:05:07 --> Database Driver Class Initialized
DEBUG - 2018-02-10 20:05:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:05:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 20:05:07 --> Form Validation Class Initialized
INFO - 2018-02-10 20:05:07 --> Model Class Initialized
INFO - 2018-02-10 20:05:07 --> Controller Class Initialized
INFO - 2018-02-10 20:05:07 --> Model Class Initialized
INFO - 2018-02-10 20:05:07 --> Model Class Initialized
INFO - 2018-02-10 20:05:07 --> Model Class Initialized
INFO - 2018-02-10 20:05:07 --> Model Class Initialized
DEBUG - 2018-02-10 20:05:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 20:05:07 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 20:05:07 --> Final output sent to browser
DEBUG - 2018-02-10 20:05:07 --> Total execution time: 0.0601
INFO - 2018-02-10 20:05:07 --> Config Class Initialized
INFO - 2018-02-10 20:05:07 --> Config Class Initialized
INFO - 2018-02-10 20:05:07 --> Config Class Initialized
INFO - 2018-02-10 20:05:07 --> Hooks Class Initialized
INFO - 2018-02-10 20:05:07 --> Hooks Class Initialized
INFO - 2018-02-10 20:05:07 --> Hooks Class Initialized
INFO - 2018-02-10 20:05:07 --> Config Class Initialized
INFO - 2018-02-10 20:05:07 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:05:07 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:05:07 --> Utf8 Class Initialized
DEBUG - 2018-02-10 20:05:07 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:05:07 --> Utf8 Class Initialized
DEBUG - 2018-02-10 20:05:07 --> UTF-8 Support Enabled
DEBUG - 2018-02-10 20:05:07 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:05:07 --> Utf8 Class Initialized
INFO - 2018-02-10 20:05:07 --> Utf8 Class Initialized
INFO - 2018-02-10 20:05:07 --> URI Class Initialized
INFO - 2018-02-10 20:05:07 --> URI Class Initialized
INFO - 2018-02-10 20:05:07 --> URI Class Initialized
INFO - 2018-02-10 20:05:07 --> URI Class Initialized
INFO - 2018-02-10 20:05:07 --> Router Class Initialized
INFO - 2018-02-10 20:05:07 --> Router Class Initialized
INFO - 2018-02-10 20:05:07 --> Router Class Initialized
INFO - 2018-02-10 20:05:07 --> Router Class Initialized
INFO - 2018-02-10 20:05:07 --> Output Class Initialized
INFO - 2018-02-10 20:05:07 --> Output Class Initialized
INFO - 2018-02-10 20:05:07 --> Output Class Initialized
INFO - 2018-02-10 20:05:07 --> Output Class Initialized
INFO - 2018-02-10 20:05:07 --> Security Class Initialized
INFO - 2018-02-10 20:05:07 --> Security Class Initialized
INFO - 2018-02-10 20:05:07 --> Security Class Initialized
INFO - 2018-02-10 20:05:07 --> Security Class Initialized
DEBUG - 2018-02-10 20:05:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:05:07 --> Input Class Initialized
DEBUG - 2018-02-10 20:05:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-10 20:05:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:05:07 --> Language Class Initialized
INFO - 2018-02-10 20:05:07 --> Input Class Initialized
INFO - 2018-02-10 20:05:07 --> Input Class Initialized
DEBUG - 2018-02-10 20:05:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:05:07 --> Input Class Initialized
INFO - 2018-02-10 20:05:07 --> Language Class Initialized
INFO - 2018-02-10 20:05:07 --> Language Class Initialized
ERROR - 2018-02-10 20:05:07 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-10 20:05:07 --> Language Class Initialized
ERROR - 2018-02-10 20:05:07 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-10 20:05:07 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-10 20:05:07 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-10 20:05:07 --> Config Class Initialized
INFO - 2018-02-10 20:05:07 --> Hooks Class Initialized
INFO - 2018-02-10 20:05:07 --> Config Class Initialized
INFO - 2018-02-10 20:05:07 --> Config Class Initialized
INFO - 2018-02-10 20:05:07 --> Hooks Class Initialized
INFO - 2018-02-10 20:05:07 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:05:07 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:05:07 --> Utf8 Class Initialized
DEBUG - 2018-02-10 20:05:07 --> UTF-8 Support Enabled
DEBUG - 2018-02-10 20:05:07 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:05:07 --> Utf8 Class Initialized
INFO - 2018-02-10 20:05:07 --> Utf8 Class Initialized
INFO - 2018-02-10 20:05:07 --> URI Class Initialized
INFO - 2018-02-10 20:05:07 --> URI Class Initialized
INFO - 2018-02-10 20:05:07 --> URI Class Initialized
INFO - 2018-02-10 20:05:07 --> Router Class Initialized
INFO - 2018-02-10 20:05:07 --> Router Class Initialized
INFO - 2018-02-10 20:05:07 --> Router Class Initialized
INFO - 2018-02-10 20:05:07 --> Output Class Initialized
INFO - 2018-02-10 20:05:07 --> Output Class Initialized
INFO - 2018-02-10 20:05:07 --> Security Class Initialized
INFO - 2018-02-10 20:05:07 --> Security Class Initialized
INFO - 2018-02-10 20:05:07 --> Output Class Initialized
DEBUG - 2018-02-10 20:05:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:05:07 --> Input Class Initialized
DEBUG - 2018-02-10 20:05:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:05:07 --> Input Class Initialized
INFO - 2018-02-10 20:05:07 --> Security Class Initialized
INFO - 2018-02-10 20:05:07 --> Language Class Initialized
INFO - 2018-02-10 20:05:07 --> Language Class Initialized
DEBUG - 2018-02-10 20:05:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:05:07 --> Input Class Initialized
ERROR - 2018-02-10 20:05:07 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-10 20:05:07 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-10 20:05:07 --> Language Class Initialized
ERROR - 2018-02-10 20:05:07 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-10 20:05:07 --> Config Class Initialized
INFO - 2018-02-10 20:05:07 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:05:07 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:05:07 --> Utf8 Class Initialized
INFO - 2018-02-10 20:05:07 --> URI Class Initialized
INFO - 2018-02-10 20:05:07 --> Router Class Initialized
INFO - 2018-02-10 20:05:07 --> Output Class Initialized
INFO - 2018-02-10 20:05:07 --> Security Class Initialized
DEBUG - 2018-02-10 20:05:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:05:07 --> Input Class Initialized
INFO - 2018-02-10 20:05:07 --> Language Class Initialized
INFO - 2018-02-10 20:05:07 --> Loader Class Initialized
INFO - 2018-02-10 20:05:07 --> Helper loaded: url_helper
INFO - 2018-02-10 20:05:07 --> Helper loaded: form_helper
INFO - 2018-02-10 20:05:07 --> Database Driver Class Initialized
DEBUG - 2018-02-10 20:05:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:05:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 20:05:07 --> Form Validation Class Initialized
INFO - 2018-02-10 20:05:07 --> Model Class Initialized
INFO - 2018-02-10 20:05:07 --> Controller Class Initialized
INFO - 2018-02-10 20:05:07 --> Model Class Initialized
INFO - 2018-02-10 20:05:07 --> Model Class Initialized
INFO - 2018-02-10 20:05:07 --> Model Class Initialized
INFO - 2018-02-10 20:05:07 --> Model Class Initialized
DEBUG - 2018-02-10 20:05:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 20:05:07 --> Config Class Initialized
INFO - 2018-02-10 20:05:07 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:05:07 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:05:07 --> Utf8 Class Initialized
INFO - 2018-02-10 20:05:07 --> URI Class Initialized
INFO - 2018-02-10 20:05:07 --> Router Class Initialized
INFO - 2018-02-10 20:05:07 --> Output Class Initialized
INFO - 2018-02-10 20:05:07 --> Security Class Initialized
DEBUG - 2018-02-10 20:05:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:05:07 --> Input Class Initialized
INFO - 2018-02-10 20:05:07 --> Language Class Initialized
INFO - 2018-02-10 20:05:07 --> Loader Class Initialized
INFO - 2018-02-10 20:05:07 --> Helper loaded: url_helper
INFO - 2018-02-10 20:05:07 --> Helper loaded: form_helper
INFO - 2018-02-10 20:05:07 --> Database Driver Class Initialized
DEBUG - 2018-02-10 20:05:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:05:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 20:05:07 --> Form Validation Class Initialized
INFO - 2018-02-10 20:05:07 --> Model Class Initialized
INFO - 2018-02-10 20:05:07 --> Controller Class Initialized
INFO - 2018-02-10 20:05:07 --> Model Class Initialized
DEBUG - 2018-02-10 20:05:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 20:05:08 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 20:05:08 --> Final output sent to browser
DEBUG - 2018-02-10 20:05:08 --> Total execution time: 0.1128
INFO - 2018-02-10 20:05:08 --> Config Class Initialized
INFO - 2018-02-10 20:05:08 --> Hooks Class Initialized
INFO - 2018-02-10 20:05:08 --> Config Class Initialized
INFO - 2018-02-10 20:05:08 --> Hooks Class Initialized
INFO - 2018-02-10 20:05:08 --> Config Class Initialized
INFO - 2018-02-10 20:05:08 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:05:08 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:05:08 --> Utf8 Class Initialized
INFO - 2018-02-10 20:05:08 --> Config Class Initialized
DEBUG - 2018-02-10 20:05:08 --> UTF-8 Support Enabled
DEBUG - 2018-02-10 20:05:08 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:05:08 --> Hooks Class Initialized
INFO - 2018-02-10 20:05:08 --> Utf8 Class Initialized
INFO - 2018-02-10 20:05:08 --> Utf8 Class Initialized
INFO - 2018-02-10 20:05:08 --> URI Class Initialized
INFO - 2018-02-10 20:05:08 --> URI Class Initialized
INFO - 2018-02-10 20:05:08 --> URI Class Initialized
INFO - 2018-02-10 20:05:08 --> Router Class Initialized
DEBUG - 2018-02-10 20:05:08 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:05:08 --> Router Class Initialized
INFO - 2018-02-10 20:05:08 --> Router Class Initialized
INFO - 2018-02-10 20:05:08 --> Utf8 Class Initialized
INFO - 2018-02-10 20:05:08 --> Output Class Initialized
INFO - 2018-02-10 20:05:08 --> URI Class Initialized
INFO - 2018-02-10 20:05:08 --> Output Class Initialized
INFO - 2018-02-10 20:05:08 --> Output Class Initialized
INFO - 2018-02-10 20:05:08 --> Security Class Initialized
INFO - 2018-02-10 20:05:08 --> Security Class Initialized
INFO - 2018-02-10 20:05:08 --> Router Class Initialized
INFO - 2018-02-10 20:05:08 --> Security Class Initialized
DEBUG - 2018-02-10 20:05:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-10 20:05:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:05:08 --> Input Class Initialized
INFO - 2018-02-10 20:05:08 --> Input Class Initialized
INFO - 2018-02-10 20:05:08 --> Output Class Initialized
DEBUG - 2018-02-10 20:05:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:05:08 --> Language Class Initialized
INFO - 2018-02-10 20:05:08 --> Input Class Initialized
INFO - 2018-02-10 20:05:08 --> Language Class Initialized
INFO - 2018-02-10 20:05:08 --> Security Class Initialized
INFO - 2018-02-10 20:05:08 --> Language Class Initialized
ERROR - 2018-02-10 20:05:08 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-10 20:05:08 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-02-10 20:05:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-10 20:05:08 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-10 20:05:08 --> Input Class Initialized
INFO - 2018-02-10 20:05:08 --> Language Class Initialized
ERROR - 2018-02-10 20:05:08 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-10 20:05:08 --> Config Class Initialized
INFO - 2018-02-10 20:05:08 --> Hooks Class Initialized
INFO - 2018-02-10 20:05:08 --> Config Class Initialized
INFO - 2018-02-10 20:05:08 --> Hooks Class Initialized
INFO - 2018-02-10 20:05:08 --> Config Class Initialized
INFO - 2018-02-10 20:05:08 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:05:08 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:05:08 --> Utf8 Class Initialized
INFO - 2018-02-10 20:05:08 --> URI Class Initialized
DEBUG - 2018-02-10 20:05:08 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:05:08 --> Utf8 Class Initialized
DEBUG - 2018-02-10 20:05:08 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:05:08 --> Utf8 Class Initialized
INFO - 2018-02-10 20:05:08 --> Router Class Initialized
INFO - 2018-02-10 20:05:08 --> URI Class Initialized
INFO - 2018-02-10 20:05:08 --> URI Class Initialized
INFO - 2018-02-10 20:05:08 --> Router Class Initialized
INFO - 2018-02-10 20:05:08 --> Router Class Initialized
INFO - 2018-02-10 20:05:08 --> Output Class Initialized
INFO - 2018-02-10 20:05:08 --> Security Class Initialized
INFO - 2018-02-10 20:05:08 --> Output Class Initialized
INFO - 2018-02-10 20:05:08 --> Output Class Initialized
DEBUG - 2018-02-10 20:05:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:05:08 --> Security Class Initialized
INFO - 2018-02-10 20:05:08 --> Security Class Initialized
INFO - 2018-02-10 20:05:08 --> Input Class Initialized
INFO - 2018-02-10 20:05:08 --> Language Class Initialized
DEBUG - 2018-02-10 20:05:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-10 20:05:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:05:08 --> Input Class Initialized
INFO - 2018-02-10 20:05:08 --> Input Class Initialized
INFO - 2018-02-10 20:05:08 --> Language Class Initialized
ERROR - 2018-02-10 20:05:08 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-10 20:05:08 --> Language Class Initialized
ERROR - 2018-02-10 20:05:08 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-10 20:05:08 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-10 20:05:08 --> Config Class Initialized
INFO - 2018-02-10 20:05:08 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:05:08 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:05:08 --> Utf8 Class Initialized
INFO - 2018-02-10 20:05:08 --> URI Class Initialized
INFO - 2018-02-10 20:05:08 --> Router Class Initialized
INFO - 2018-02-10 20:05:08 --> Output Class Initialized
INFO - 2018-02-10 20:05:08 --> Security Class Initialized
DEBUG - 2018-02-10 20:05:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:05:08 --> Input Class Initialized
INFO - 2018-02-10 20:05:08 --> Language Class Initialized
INFO - 2018-02-10 20:05:08 --> Loader Class Initialized
INFO - 2018-02-10 20:05:08 --> Helper loaded: url_helper
INFO - 2018-02-10 20:05:08 --> Helper loaded: form_helper
INFO - 2018-02-10 20:05:08 --> Database Driver Class Initialized
DEBUG - 2018-02-10 20:05:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:05:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 20:05:08 --> Form Validation Class Initialized
INFO - 2018-02-10 20:05:08 --> Model Class Initialized
INFO - 2018-02-10 20:05:08 --> Controller Class Initialized
INFO - 2018-02-10 20:05:08 --> Model Class Initialized
DEBUG - 2018-02-10 20:05:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 20:06:26 --> Config Class Initialized
INFO - 2018-02-10 20:06:26 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:06:26 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:06:26 --> Utf8 Class Initialized
INFO - 2018-02-10 20:06:26 --> URI Class Initialized
INFO - 2018-02-10 20:06:26 --> Router Class Initialized
INFO - 2018-02-10 20:06:26 --> Output Class Initialized
INFO - 2018-02-10 20:06:26 --> Security Class Initialized
DEBUG - 2018-02-10 20:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:06:26 --> Input Class Initialized
INFO - 2018-02-10 20:06:26 --> Language Class Initialized
INFO - 2018-02-10 20:06:26 --> Loader Class Initialized
INFO - 2018-02-10 20:06:26 --> Helper loaded: url_helper
INFO - 2018-02-10 20:06:26 --> Helper loaded: form_helper
INFO - 2018-02-10 20:06:26 --> Database Driver Class Initialized
DEBUG - 2018-02-10 20:06:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:06:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 20:06:27 --> Form Validation Class Initialized
INFO - 2018-02-10 20:06:27 --> Model Class Initialized
INFO - 2018-02-10 20:06:27 --> Controller Class Initialized
INFO - 2018-02-10 20:06:27 --> Model Class Initialized
DEBUG - 2018-02-10 20:06:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 20:06:27 --> Config Class Initialized
INFO - 2018-02-10 20:06:27 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:06:27 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:06:27 --> Utf8 Class Initialized
INFO - 2018-02-10 20:06:27 --> URI Class Initialized
INFO - 2018-02-10 20:06:27 --> Router Class Initialized
INFO - 2018-02-10 20:06:27 --> Output Class Initialized
INFO - 2018-02-10 20:06:27 --> Security Class Initialized
DEBUG - 2018-02-10 20:06:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:06:27 --> Input Class Initialized
INFO - 2018-02-10 20:06:27 --> Language Class Initialized
INFO - 2018-02-10 20:06:27 --> Loader Class Initialized
INFO - 2018-02-10 20:06:27 --> Helper loaded: url_helper
INFO - 2018-02-10 20:06:27 --> Helper loaded: form_helper
INFO - 2018-02-10 20:06:27 --> Database Driver Class Initialized
DEBUG - 2018-02-10 20:06:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:06:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 20:06:27 --> Form Validation Class Initialized
INFO - 2018-02-10 20:06:27 --> Model Class Initialized
INFO - 2018-02-10 20:06:27 --> Controller Class Initialized
INFO - 2018-02-10 20:06:27 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 20:06:27 --> Final output sent to browser
DEBUG - 2018-02-10 20:06:27 --> Total execution time: 0.1048
INFO - 2018-02-10 20:06:28 --> Config Class Initialized
INFO - 2018-02-10 20:06:28 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:06:28 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:06:28 --> Utf8 Class Initialized
INFO - 2018-02-10 20:06:28 --> URI Class Initialized
INFO - 2018-02-10 20:06:28 --> Router Class Initialized
INFO - 2018-02-10 20:06:28 --> Output Class Initialized
INFO - 2018-02-10 20:06:28 --> Security Class Initialized
DEBUG - 2018-02-10 20:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:06:28 --> Input Class Initialized
INFO - 2018-02-10 20:06:28 --> Language Class Initialized
INFO - 2018-02-10 20:06:28 --> Loader Class Initialized
INFO - 2018-02-10 20:06:28 --> Helper loaded: url_helper
INFO - 2018-02-10 20:06:28 --> Helper loaded: form_helper
INFO - 2018-02-10 20:06:28 --> Database Driver Class Initialized
DEBUG - 2018-02-10 20:06:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:06:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 20:06:28 --> Form Validation Class Initialized
INFO - 2018-02-10 20:06:28 --> Model Class Initialized
INFO - 2018-02-10 20:06:28 --> Controller Class Initialized
INFO - 2018-02-10 20:06:28 --> Model Class Initialized
INFO - 2018-02-10 20:06:28 --> Model Class Initialized
INFO - 2018-02-10 20:06:28 --> Model Class Initialized
INFO - 2018-02-10 20:06:28 --> Model Class Initialized
DEBUG - 2018-02-10 20:06:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 20:06:28 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 20:06:28 --> Final output sent to browser
DEBUG - 2018-02-10 20:06:28 --> Total execution time: 0.0670
INFO - 2018-02-10 20:06:28 --> Config Class Initialized
INFO - 2018-02-10 20:06:28 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:06:28 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:06:28 --> Utf8 Class Initialized
INFO - 2018-02-10 20:06:28 --> URI Class Initialized
INFO - 2018-02-10 20:06:28 --> Router Class Initialized
INFO - 2018-02-10 20:06:28 --> Output Class Initialized
INFO - 2018-02-10 20:06:28 --> Security Class Initialized
DEBUG - 2018-02-10 20:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:06:28 --> Input Class Initialized
INFO - 2018-02-10 20:06:28 --> Language Class Initialized
INFO - 2018-02-10 20:06:28 --> Loader Class Initialized
INFO - 2018-02-10 20:06:28 --> Helper loaded: url_helper
INFO - 2018-02-10 20:06:28 --> Helper loaded: form_helper
INFO - 2018-02-10 20:06:28 --> Database Driver Class Initialized
DEBUG - 2018-02-10 20:06:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:06:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 20:06:28 --> Form Validation Class Initialized
INFO - 2018-02-10 20:06:28 --> Model Class Initialized
INFO - 2018-02-10 20:06:28 --> Controller Class Initialized
INFO - 2018-02-10 20:06:28 --> Model Class Initialized
INFO - 2018-02-10 20:06:28 --> Model Class Initialized
INFO - 2018-02-10 20:06:28 --> Model Class Initialized
INFO - 2018-02-10 20:06:28 --> Model Class Initialized
DEBUG - 2018-02-10 20:06:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 20:06:29 --> Config Class Initialized
INFO - 2018-02-10 20:06:29 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:06:29 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:06:29 --> Utf8 Class Initialized
INFO - 2018-02-10 20:06:29 --> URI Class Initialized
DEBUG - 2018-02-10 20:06:29 --> No URI present. Default controller set.
INFO - 2018-02-10 20:06:29 --> Router Class Initialized
INFO - 2018-02-10 20:06:29 --> Output Class Initialized
INFO - 2018-02-10 20:06:29 --> Security Class Initialized
DEBUG - 2018-02-10 20:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:06:29 --> Input Class Initialized
INFO - 2018-02-10 20:06:29 --> Language Class Initialized
INFO - 2018-02-10 20:06:29 --> Loader Class Initialized
INFO - 2018-02-10 20:06:29 --> Helper loaded: url_helper
INFO - 2018-02-10 20:06:29 --> Helper loaded: form_helper
INFO - 2018-02-10 20:06:29 --> Database Driver Class Initialized
DEBUG - 2018-02-10 20:06:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:06:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 20:06:29 --> Form Validation Class Initialized
INFO - 2018-02-10 20:06:29 --> Model Class Initialized
INFO - 2018-02-10 20:06:29 --> Controller Class Initialized
INFO - 2018-02-10 20:06:29 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 20:06:29 --> Final output sent to browser
DEBUG - 2018-02-10 20:06:29 --> Total execution time: 0.0425
INFO - 2018-02-10 20:06:29 --> Config Class Initialized
INFO - 2018-02-10 20:06:29 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:06:29 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:06:29 --> Utf8 Class Initialized
INFO - 2018-02-10 20:06:29 --> URI Class Initialized
INFO - 2018-02-10 20:06:29 --> Router Class Initialized
INFO - 2018-02-10 20:06:29 --> Output Class Initialized
INFO - 2018-02-10 20:06:29 --> Security Class Initialized
DEBUG - 2018-02-10 20:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:06:29 --> Input Class Initialized
INFO - 2018-02-10 20:06:29 --> Language Class Initialized
INFO - 2018-02-10 20:06:29 --> Loader Class Initialized
INFO - 2018-02-10 20:06:29 --> Helper loaded: url_helper
INFO - 2018-02-10 20:06:29 --> Helper loaded: form_helper
INFO - 2018-02-10 20:06:29 --> Database Driver Class Initialized
DEBUG - 2018-02-10 20:06:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:06:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 20:06:29 --> Form Validation Class Initialized
INFO - 2018-02-10 20:06:29 --> Model Class Initialized
INFO - 2018-02-10 20:06:29 --> Controller Class Initialized
INFO - 2018-02-10 20:06:29 --> Model Class Initialized
INFO - 2018-02-10 20:06:29 --> Model Class Initialized
INFO - 2018-02-10 20:06:29 --> Model Class Initialized
INFO - 2018-02-10 20:06:29 --> Model Class Initialized
DEBUG - 2018-02-10 20:06:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 20:06:29 --> Config Class Initialized
INFO - 2018-02-10 20:06:29 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:06:29 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:06:29 --> Utf8 Class Initialized
INFO - 2018-02-10 20:06:29 --> URI Class Initialized
INFO - 2018-02-10 20:06:29 --> Router Class Initialized
INFO - 2018-02-10 20:06:29 --> Output Class Initialized
INFO - 2018-02-10 20:06:29 --> Security Class Initialized
DEBUG - 2018-02-10 20:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:06:29 --> Input Class Initialized
INFO - 2018-02-10 20:06:29 --> Language Class Initialized
INFO - 2018-02-10 20:06:29 --> Loader Class Initialized
INFO - 2018-02-10 20:06:29 --> Helper loaded: url_helper
INFO - 2018-02-10 20:06:29 --> Helper loaded: form_helper
INFO - 2018-02-10 20:06:29 --> Database Driver Class Initialized
DEBUG - 2018-02-10 20:06:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:06:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 20:06:29 --> Form Validation Class Initialized
INFO - 2018-02-10 20:06:29 --> Model Class Initialized
INFO - 2018-02-10 20:06:29 --> Controller Class Initialized
INFO - 2018-02-10 20:06:29 --> Model Class Initialized
INFO - 2018-02-10 20:06:29 --> Model Class Initialized
INFO - 2018-02-10 20:06:29 --> Model Class Initialized
INFO - 2018-02-10 20:06:29 --> Model Class Initialized
DEBUG - 2018-02-10 20:06:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 20:06:29 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 20:06:29 --> Final output sent to browser
DEBUG - 2018-02-10 20:06:29 --> Total execution time: 0.0624
INFO - 2018-02-10 20:06:30 --> Config Class Initialized
INFO - 2018-02-10 20:06:30 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:06:30 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:06:30 --> Utf8 Class Initialized
INFO - 2018-02-10 20:06:30 --> URI Class Initialized
INFO - 2018-02-10 20:06:30 --> Router Class Initialized
INFO - 2018-02-10 20:06:30 --> Output Class Initialized
INFO - 2018-02-10 20:06:30 --> Security Class Initialized
DEBUG - 2018-02-10 20:06:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:06:30 --> Input Class Initialized
INFO - 2018-02-10 20:06:30 --> Language Class Initialized
INFO - 2018-02-10 20:06:30 --> Loader Class Initialized
INFO - 2018-02-10 20:06:30 --> Helper loaded: url_helper
INFO - 2018-02-10 20:06:30 --> Helper loaded: form_helper
INFO - 2018-02-10 20:06:30 --> Database Driver Class Initialized
DEBUG - 2018-02-10 20:06:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:06:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 20:06:30 --> Form Validation Class Initialized
INFO - 2018-02-10 20:06:30 --> Model Class Initialized
INFO - 2018-02-10 20:06:30 --> Controller Class Initialized
INFO - 2018-02-10 20:06:30 --> Model Class Initialized
INFO - 2018-02-10 20:06:30 --> Model Class Initialized
INFO - 2018-02-10 20:06:30 --> Model Class Initialized
INFO - 2018-02-10 20:06:30 --> Model Class Initialized
DEBUG - 2018-02-10 20:06:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 20:06:30 --> Config Class Initialized
INFO - 2018-02-10 20:06:30 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:06:30 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:06:30 --> Utf8 Class Initialized
INFO - 2018-02-10 20:06:30 --> URI Class Initialized
INFO - 2018-02-10 20:06:30 --> Router Class Initialized
INFO - 2018-02-10 20:06:30 --> Output Class Initialized
INFO - 2018-02-10 20:06:30 --> Security Class Initialized
DEBUG - 2018-02-10 20:06:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:06:30 --> Input Class Initialized
INFO - 2018-02-10 20:06:30 --> Language Class Initialized
INFO - 2018-02-10 20:06:30 --> Loader Class Initialized
INFO - 2018-02-10 20:06:30 --> Helper loaded: url_helper
INFO - 2018-02-10 20:06:30 --> Helper loaded: form_helper
INFO - 2018-02-10 20:06:30 --> Database Driver Class Initialized
DEBUG - 2018-02-10 20:06:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:06:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 20:06:30 --> Form Validation Class Initialized
INFO - 2018-02-10 20:06:30 --> Model Class Initialized
INFO - 2018-02-10 20:06:30 --> Controller Class Initialized
INFO - 2018-02-10 20:06:30 --> Model Class Initialized
INFO - 2018-02-10 20:06:30 --> Model Class Initialized
INFO - 2018-02-10 20:06:30 --> Model Class Initialized
INFO - 2018-02-10 20:06:30 --> Model Class Initialized
DEBUG - 2018-02-10 20:06:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 20:06:30 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 20:06:30 --> Final output sent to browser
DEBUG - 2018-02-10 20:06:30 --> Total execution time: 0.0634
INFO - 2018-02-10 20:06:30 --> Config Class Initialized
INFO - 2018-02-10 20:06:30 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:06:30 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:06:30 --> Utf8 Class Initialized
INFO - 2018-02-10 20:06:30 --> URI Class Initialized
INFO - 2018-02-10 20:06:30 --> Router Class Initialized
INFO - 2018-02-10 20:06:30 --> Output Class Initialized
INFO - 2018-02-10 20:06:30 --> Security Class Initialized
DEBUG - 2018-02-10 20:06:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:06:30 --> Input Class Initialized
INFO - 2018-02-10 20:06:30 --> Language Class Initialized
INFO - 2018-02-10 20:06:30 --> Loader Class Initialized
INFO - 2018-02-10 20:06:30 --> Helper loaded: url_helper
INFO - 2018-02-10 20:06:30 --> Helper loaded: form_helper
INFO - 2018-02-10 20:06:30 --> Database Driver Class Initialized
DEBUG - 2018-02-10 20:06:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:06:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 20:06:30 --> Form Validation Class Initialized
INFO - 2018-02-10 20:06:30 --> Model Class Initialized
INFO - 2018-02-10 20:06:30 --> Controller Class Initialized
INFO - 2018-02-10 20:06:30 --> Model Class Initialized
INFO - 2018-02-10 20:06:30 --> Model Class Initialized
INFO - 2018-02-10 20:06:30 --> Model Class Initialized
INFO - 2018-02-10 20:06:30 --> Model Class Initialized
DEBUG - 2018-02-10 20:06:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 20:06:31 --> Config Class Initialized
INFO - 2018-02-10 20:06:31 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:06:31 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:06:31 --> Utf8 Class Initialized
INFO - 2018-02-10 20:06:31 --> URI Class Initialized
INFO - 2018-02-10 20:06:31 --> Router Class Initialized
INFO - 2018-02-10 20:06:31 --> Output Class Initialized
INFO - 2018-02-10 20:06:31 --> Security Class Initialized
DEBUG - 2018-02-10 20:06:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:06:31 --> Input Class Initialized
INFO - 2018-02-10 20:06:31 --> Language Class Initialized
INFO - 2018-02-10 20:06:31 --> Loader Class Initialized
INFO - 2018-02-10 20:06:31 --> Helper loaded: url_helper
INFO - 2018-02-10 20:06:31 --> Helper loaded: form_helper
INFO - 2018-02-10 20:06:31 --> Database Driver Class Initialized
DEBUG - 2018-02-10 20:06:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:06:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 20:06:31 --> Form Validation Class Initialized
INFO - 2018-02-10 20:06:31 --> Model Class Initialized
INFO - 2018-02-10 20:06:31 --> Controller Class Initialized
INFO - 2018-02-10 20:06:31 --> Model Class Initialized
DEBUG - 2018-02-10 20:06:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 20:06:31 --> Config Class Initialized
INFO - 2018-02-10 20:06:31 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:06:31 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:06:31 --> Utf8 Class Initialized
INFO - 2018-02-10 20:06:31 --> URI Class Initialized
INFO - 2018-02-10 20:06:31 --> Router Class Initialized
INFO - 2018-02-10 20:06:31 --> Output Class Initialized
INFO - 2018-02-10 20:06:31 --> Security Class Initialized
DEBUG - 2018-02-10 20:06:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:06:31 --> Input Class Initialized
INFO - 2018-02-10 20:06:31 --> Language Class Initialized
INFO - 2018-02-10 20:06:31 --> Loader Class Initialized
INFO - 2018-02-10 20:06:31 --> Helper loaded: url_helper
INFO - 2018-02-10 20:06:31 --> Helper loaded: form_helper
INFO - 2018-02-10 20:06:31 --> Database Driver Class Initialized
DEBUG - 2018-02-10 20:06:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:06:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 20:06:31 --> Form Validation Class Initialized
INFO - 2018-02-10 20:06:31 --> Model Class Initialized
INFO - 2018-02-10 20:06:31 --> Controller Class Initialized
INFO - 2018-02-10 20:06:31 --> Model Class Initialized
DEBUG - 2018-02-10 20:06:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 20:06:31 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 20:06:31 --> Final output sent to browser
DEBUG - 2018-02-10 20:06:31 --> Total execution time: 0.0894
INFO - 2018-02-10 20:06:35 --> Config Class Initialized
INFO - 2018-02-10 20:06:35 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:06:35 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:06:35 --> Utf8 Class Initialized
INFO - 2018-02-10 20:06:35 --> URI Class Initialized
INFO - 2018-02-10 20:06:35 --> Router Class Initialized
INFO - 2018-02-10 20:06:35 --> Output Class Initialized
INFO - 2018-02-10 20:06:35 --> Security Class Initialized
DEBUG - 2018-02-10 20:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:06:35 --> Input Class Initialized
INFO - 2018-02-10 20:06:35 --> Language Class Initialized
INFO - 2018-02-10 20:06:35 --> Loader Class Initialized
INFO - 2018-02-10 20:06:35 --> Helper loaded: url_helper
INFO - 2018-02-10 20:06:35 --> Helper loaded: form_helper
INFO - 2018-02-10 20:06:35 --> Database Driver Class Initialized
DEBUG - 2018-02-10 20:06:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:06:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 20:06:35 --> Form Validation Class Initialized
INFO - 2018-02-10 20:06:35 --> Model Class Initialized
INFO - 2018-02-10 20:06:35 --> Controller Class Initialized
INFO - 2018-02-10 20:06:35 --> Model Class Initialized
DEBUG - 2018-02-10 20:06:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 20:06:35 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-10 20:06:35 --> Config Class Initialized
INFO - 2018-02-10 20:06:35 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:06:35 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:06:35 --> Utf8 Class Initialized
INFO - 2018-02-10 20:06:35 --> URI Class Initialized
DEBUG - 2018-02-10 20:06:35 --> No URI present. Default controller set.
INFO - 2018-02-10 20:06:35 --> Router Class Initialized
INFO - 2018-02-10 20:06:35 --> Output Class Initialized
INFO - 2018-02-10 20:06:35 --> Security Class Initialized
DEBUG - 2018-02-10 20:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:06:35 --> Input Class Initialized
INFO - 2018-02-10 20:06:35 --> Language Class Initialized
INFO - 2018-02-10 20:06:35 --> Loader Class Initialized
INFO - 2018-02-10 20:06:35 --> Helper loaded: url_helper
INFO - 2018-02-10 20:06:35 --> Helper loaded: form_helper
INFO - 2018-02-10 20:06:35 --> Database Driver Class Initialized
DEBUG - 2018-02-10 20:06:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:06:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 20:06:35 --> Form Validation Class Initialized
INFO - 2018-02-10 20:06:35 --> Model Class Initialized
INFO - 2018-02-10 20:06:35 --> Controller Class Initialized
INFO - 2018-02-10 20:06:35 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 20:06:35 --> Final output sent to browser
DEBUG - 2018-02-10 20:06:35 --> Total execution time: 0.0948
INFO - 2018-02-10 20:06:35 --> Config Class Initialized
INFO - 2018-02-10 20:06:35 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:06:35 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:06:35 --> Utf8 Class Initialized
INFO - 2018-02-10 20:06:35 --> URI Class Initialized
INFO - 2018-02-10 20:06:35 --> Router Class Initialized
INFO - 2018-02-10 20:06:35 --> Output Class Initialized
INFO - 2018-02-10 20:06:35 --> Security Class Initialized
DEBUG - 2018-02-10 20:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:06:35 --> Input Class Initialized
INFO - 2018-02-10 20:06:35 --> Language Class Initialized
INFO - 2018-02-10 20:06:35 --> Loader Class Initialized
INFO - 2018-02-10 20:06:35 --> Helper loaded: url_helper
INFO - 2018-02-10 20:06:35 --> Helper loaded: form_helper
INFO - 2018-02-10 20:06:35 --> Database Driver Class Initialized
DEBUG - 2018-02-10 20:06:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:06:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 20:06:35 --> Form Validation Class Initialized
INFO - 2018-02-10 20:06:35 --> Model Class Initialized
INFO - 2018-02-10 20:06:35 --> Controller Class Initialized
INFO - 2018-02-10 20:06:35 --> Model Class Initialized
INFO - 2018-02-10 20:06:35 --> Model Class Initialized
INFO - 2018-02-10 20:06:35 --> Model Class Initialized
INFO - 2018-02-10 20:06:35 --> Model Class Initialized
DEBUG - 2018-02-10 20:06:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 20:07:26 --> Config Class Initialized
INFO - 2018-02-10 20:07:26 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:07:26 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:07:26 --> Utf8 Class Initialized
INFO - 2018-02-10 20:07:26 --> URI Class Initialized
INFO - 2018-02-10 20:07:26 --> Router Class Initialized
INFO - 2018-02-10 20:07:26 --> Output Class Initialized
INFO - 2018-02-10 20:07:26 --> Security Class Initialized
DEBUG - 2018-02-10 20:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:07:26 --> Input Class Initialized
INFO - 2018-02-10 20:07:26 --> Language Class Initialized
INFO - 2018-02-10 20:07:26 --> Loader Class Initialized
INFO - 2018-02-10 20:07:26 --> Helper loaded: url_helper
INFO - 2018-02-10 20:07:26 --> Helper loaded: form_helper
INFO - 2018-02-10 20:07:26 --> Database Driver Class Initialized
DEBUG - 2018-02-10 20:07:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:07:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 20:07:26 --> Form Validation Class Initialized
INFO - 2018-02-10 20:07:26 --> Model Class Initialized
INFO - 2018-02-10 20:07:26 --> Controller Class Initialized
INFO - 2018-02-10 20:07:26 --> Model Class Initialized
INFO - 2018-02-10 20:07:26 --> Model Class Initialized
INFO - 2018-02-10 20:07:26 --> Model Class Initialized
INFO - 2018-02-10 20:07:26 --> Model Class Initialized
DEBUG - 2018-02-10 20:07:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 20:07:26 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 20:07:26 --> Final output sent to browser
DEBUG - 2018-02-10 20:07:26 --> Total execution time: 0.0651
INFO - 2018-02-10 20:07:26 --> Config Class Initialized
INFO - 2018-02-10 20:07:26 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:07:26 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:07:26 --> Utf8 Class Initialized
INFO - 2018-02-10 20:07:26 --> URI Class Initialized
INFO - 2018-02-10 20:07:26 --> Router Class Initialized
INFO - 2018-02-10 20:07:26 --> Output Class Initialized
INFO - 2018-02-10 20:07:26 --> Security Class Initialized
DEBUG - 2018-02-10 20:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:07:26 --> Input Class Initialized
INFO - 2018-02-10 20:07:26 --> Language Class Initialized
INFO - 2018-02-10 20:07:26 --> Loader Class Initialized
INFO - 2018-02-10 20:07:26 --> Helper loaded: url_helper
INFO - 2018-02-10 20:07:26 --> Helper loaded: form_helper
INFO - 2018-02-10 20:07:26 --> Database Driver Class Initialized
DEBUG - 2018-02-10 20:07:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:07:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 20:07:26 --> Form Validation Class Initialized
INFO - 2018-02-10 20:07:26 --> Model Class Initialized
INFO - 2018-02-10 20:07:26 --> Controller Class Initialized
INFO - 2018-02-10 20:07:26 --> Model Class Initialized
INFO - 2018-02-10 20:07:26 --> Model Class Initialized
INFO - 2018-02-10 20:07:26 --> Model Class Initialized
INFO - 2018-02-10 20:07:26 --> Model Class Initialized
DEBUG - 2018-02-10 20:07:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 20:08:23 --> Config Class Initialized
INFO - 2018-02-10 20:08:23 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:08:23 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:08:23 --> Utf8 Class Initialized
INFO - 2018-02-10 20:08:23 --> URI Class Initialized
INFO - 2018-02-10 20:08:23 --> Router Class Initialized
INFO - 2018-02-10 20:08:23 --> Output Class Initialized
INFO - 2018-02-10 20:08:23 --> Security Class Initialized
DEBUG - 2018-02-10 20:08:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:08:23 --> Input Class Initialized
INFO - 2018-02-10 20:08:23 --> Language Class Initialized
INFO - 2018-02-10 20:08:23 --> Loader Class Initialized
INFO - 2018-02-10 20:08:23 --> Helper loaded: url_helper
INFO - 2018-02-10 20:08:23 --> Helper loaded: form_helper
INFO - 2018-02-10 20:08:23 --> Database Driver Class Initialized
DEBUG - 2018-02-10 20:08:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:08:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 20:08:23 --> Form Validation Class Initialized
INFO - 2018-02-10 20:08:23 --> Model Class Initialized
INFO - 2018-02-10 20:08:23 --> Controller Class Initialized
INFO - 2018-02-10 20:08:23 --> Model Class Initialized
INFO - 2018-02-10 20:08:23 --> Model Class Initialized
INFO - 2018-02-10 20:08:23 --> Model Class Initialized
INFO - 2018-02-10 20:08:23 --> Model Class Initialized
DEBUG - 2018-02-10 20:08:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 20:08:23 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 20:08:23 --> Final output sent to browser
DEBUG - 2018-02-10 20:08:23 --> Total execution time: 0.0955
INFO - 2018-02-10 20:08:23 --> Config Class Initialized
INFO - 2018-02-10 20:08:23 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:08:23 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:08:23 --> Utf8 Class Initialized
INFO - 2018-02-10 20:08:23 --> URI Class Initialized
INFO - 2018-02-10 20:08:23 --> Router Class Initialized
INFO - 2018-02-10 20:08:23 --> Output Class Initialized
INFO - 2018-02-10 20:08:23 --> Security Class Initialized
DEBUG - 2018-02-10 20:08:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:08:23 --> Input Class Initialized
INFO - 2018-02-10 20:08:23 --> Language Class Initialized
INFO - 2018-02-10 20:08:23 --> Loader Class Initialized
INFO - 2018-02-10 20:08:23 --> Helper loaded: url_helper
INFO - 2018-02-10 20:08:23 --> Helper loaded: form_helper
INFO - 2018-02-10 20:08:23 --> Database Driver Class Initialized
DEBUG - 2018-02-10 20:08:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:08:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 20:08:23 --> Form Validation Class Initialized
INFO - 2018-02-10 20:08:23 --> Model Class Initialized
INFO - 2018-02-10 20:08:23 --> Controller Class Initialized
INFO - 2018-02-10 20:08:23 --> Model Class Initialized
INFO - 2018-02-10 20:08:23 --> Model Class Initialized
INFO - 2018-02-10 20:08:23 --> Model Class Initialized
INFO - 2018-02-10 20:08:23 --> Model Class Initialized
DEBUG - 2018-02-10 20:08:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 20:08:30 --> Config Class Initialized
INFO - 2018-02-10 20:08:30 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:08:30 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:08:30 --> Utf8 Class Initialized
INFO - 2018-02-10 20:08:30 --> URI Class Initialized
INFO - 2018-02-10 20:08:30 --> Router Class Initialized
INFO - 2018-02-10 20:08:30 --> Output Class Initialized
INFO - 2018-02-10 20:08:30 --> Security Class Initialized
DEBUG - 2018-02-10 20:08:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:08:30 --> Input Class Initialized
INFO - 2018-02-10 20:08:30 --> Language Class Initialized
INFO - 2018-02-10 20:08:30 --> Loader Class Initialized
INFO - 2018-02-10 20:08:30 --> Helper loaded: url_helper
INFO - 2018-02-10 20:08:30 --> Helper loaded: form_helper
INFO - 2018-02-10 20:08:30 --> Database Driver Class Initialized
DEBUG - 2018-02-10 20:08:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:08:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 20:08:31 --> Form Validation Class Initialized
INFO - 2018-02-10 20:08:31 --> Model Class Initialized
INFO - 2018-02-10 20:08:31 --> Controller Class Initialized
INFO - 2018-02-10 20:08:31 --> Model Class Initialized
INFO - 2018-02-10 20:08:31 --> Model Class Initialized
INFO - 2018-02-10 20:08:31 --> Model Class Initialized
INFO - 2018-02-10 20:08:31 --> Model Class Initialized
DEBUG - 2018-02-10 20:08:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 20:08:31 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 20:08:31 --> Final output sent to browser
DEBUG - 2018-02-10 20:08:31 --> Total execution time: 0.1218
INFO - 2018-02-10 20:08:31 --> Config Class Initialized
INFO - 2018-02-10 20:08:31 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:08:31 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:08:31 --> Utf8 Class Initialized
INFO - 2018-02-10 20:08:31 --> Config Class Initialized
INFO - 2018-02-10 20:08:31 --> Hooks Class Initialized
INFO - 2018-02-10 20:08:31 --> URI Class Initialized
INFO - 2018-02-10 20:08:31 --> Router Class Initialized
DEBUG - 2018-02-10 20:08:31 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:08:31 --> Utf8 Class Initialized
INFO - 2018-02-10 20:08:31 --> URI Class Initialized
INFO - 2018-02-10 20:08:31 --> Output Class Initialized
INFO - 2018-02-10 20:08:31 --> Security Class Initialized
INFO - 2018-02-10 20:08:31 --> Router Class Initialized
DEBUG - 2018-02-10 20:08:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:08:31 --> Input Class Initialized
INFO - 2018-02-10 20:08:31 --> Output Class Initialized
INFO - 2018-02-10 20:08:31 --> Language Class Initialized
INFO - 2018-02-10 20:08:31 --> Security Class Initialized
DEBUG - 2018-02-10 20:08:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:08:31 --> Input Class Initialized
INFO - 2018-02-10 20:08:31 --> Loader Class Initialized
INFO - 2018-02-10 20:08:31 --> Language Class Initialized
INFO - 2018-02-10 20:08:31 --> Helper loaded: url_helper
INFO - 2018-02-10 20:08:31 --> Helper loaded: form_helper
INFO - 2018-02-10 20:08:31 --> Loader Class Initialized
INFO - 2018-02-10 20:08:31 --> Helper loaded: url_helper
INFO - 2018-02-10 20:08:31 --> Helper loaded: form_helper
INFO - 2018-02-10 20:08:31 --> Database Driver Class Initialized
INFO - 2018-02-10 20:08:31 --> Database Driver Class Initialized
DEBUG - 2018-02-10 20:08:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:08:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 20:08:31 --> Form Validation Class Initialized
DEBUG - 2018-02-10 20:08:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:08:31 --> Model Class Initialized
INFO - 2018-02-10 20:08:31 --> Controller Class Initialized
INFO - 2018-02-10 20:08:31 --> Model Class Initialized
INFO - 2018-02-10 20:08:31 --> Model Class Initialized
INFO - 2018-02-10 20:08:31 --> Model Class Initialized
INFO - 2018-02-10 20:08:31 --> Model Class Initialized
DEBUG - 2018-02-10 20:08:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 20:08:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 20:08:31 --> Form Validation Class Initialized
INFO - 2018-02-10 20:08:31 --> Model Class Initialized
INFO - 2018-02-10 20:08:31 --> Controller Class Initialized
INFO - 2018-02-10 20:08:31 --> Model Class Initialized
INFO - 2018-02-10 20:08:31 --> Model Class Initialized
INFO - 2018-02-10 20:08:31 --> Model Class Initialized
INFO - 2018-02-10 20:08:31 --> Model Class Initialized
DEBUG - 2018-02-10 20:08:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 20:23:46 --> Config Class Initialized
INFO - 2018-02-10 20:23:46 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:23:46 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:23:46 --> Utf8 Class Initialized
INFO - 2018-02-10 20:23:46 --> URI Class Initialized
INFO - 2018-02-10 20:23:46 --> Router Class Initialized
INFO - 2018-02-10 20:23:46 --> Output Class Initialized
INFO - 2018-02-10 20:23:46 --> Security Class Initialized
DEBUG - 2018-02-10 20:23:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:23:46 --> Input Class Initialized
INFO - 2018-02-10 20:23:46 --> Language Class Initialized
INFO - 2018-02-10 20:23:46 --> Loader Class Initialized
INFO - 2018-02-10 20:23:46 --> Helper loaded: url_helper
INFO - 2018-02-10 20:23:46 --> Helper loaded: form_helper
INFO - 2018-02-10 20:23:46 --> Database Driver Class Initialized
DEBUG - 2018-02-10 20:23:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:23:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 20:23:46 --> Form Validation Class Initialized
INFO - 2018-02-10 20:23:46 --> Model Class Initialized
INFO - 2018-02-10 20:23:46 --> Controller Class Initialized
INFO - 2018-02-10 20:23:46 --> Model Class Initialized
INFO - 2018-02-10 20:23:46 --> Model Class Initialized
INFO - 2018-02-10 20:23:46 --> Model Class Initialized
INFO - 2018-02-10 20:23:46 --> Model Class Initialized
INFO - 2018-02-10 20:23:46 --> Model Class Initialized
DEBUG - 2018-02-10 20:23:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 20:23:46 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 20:23:46 --> Final output sent to browser
DEBUG - 2018-02-10 20:23:46 --> Total execution time: 0.0595
INFO - 2018-02-10 20:23:46 --> Config Class Initialized
INFO - 2018-02-10 20:23:46 --> Hooks Class Initialized
INFO - 2018-02-10 20:23:46 --> Config Class Initialized
INFO - 2018-02-10 20:23:46 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:23:46 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:23:46 --> Utf8 Class Initialized
DEBUG - 2018-02-10 20:23:46 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:23:46 --> Utf8 Class Initialized
INFO - 2018-02-10 20:23:46 --> URI Class Initialized
INFO - 2018-02-10 20:23:46 --> URI Class Initialized
INFO - 2018-02-10 20:23:46 --> Router Class Initialized
INFO - 2018-02-10 20:23:46 --> Router Class Initialized
INFO - 2018-02-10 20:23:46 --> Output Class Initialized
INFO - 2018-02-10 20:23:46 --> Security Class Initialized
INFO - 2018-02-10 20:23:46 --> Output Class Initialized
DEBUG - 2018-02-10 20:23:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:23:46 --> Security Class Initialized
INFO - 2018-02-10 20:23:46 --> Input Class Initialized
INFO - 2018-02-10 20:23:46 --> Language Class Initialized
DEBUG - 2018-02-10 20:23:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:23:46 --> Input Class Initialized
INFO - 2018-02-10 20:23:46 --> Language Class Initialized
INFO - 2018-02-10 20:23:46 --> Loader Class Initialized
INFO - 2018-02-10 20:23:46 --> Loader Class Initialized
INFO - 2018-02-10 20:23:46 --> Helper loaded: url_helper
INFO - 2018-02-10 20:23:46 --> Helper loaded: url_helper
INFO - 2018-02-10 20:23:46 --> Helper loaded: form_helper
INFO - 2018-02-10 20:23:46 --> Helper loaded: form_helper
INFO - 2018-02-10 20:23:46 --> Database Driver Class Initialized
INFO - 2018-02-10 20:23:46 --> Database Driver Class Initialized
DEBUG - 2018-02-10 20:23:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:23:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-02-10 20:23:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:23:46 --> Form Validation Class Initialized
INFO - 2018-02-10 20:23:46 --> Model Class Initialized
INFO - 2018-02-10 20:23:46 --> Controller Class Initialized
INFO - 2018-02-10 20:23:46 --> Model Class Initialized
INFO - 2018-02-10 20:23:46 --> Model Class Initialized
INFO - 2018-02-10 20:23:46 --> Model Class Initialized
INFO - 2018-02-10 20:23:46 --> Model Class Initialized
INFO - 2018-02-10 20:23:46 --> Model Class Initialized
DEBUG - 2018-02-10 20:23:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 20:23:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 20:23:46 --> Form Validation Class Initialized
INFO - 2018-02-10 20:23:46 --> Model Class Initialized
INFO - 2018-02-10 20:23:46 --> Controller Class Initialized
INFO - 2018-02-10 20:23:46 --> Model Class Initialized
INFO - 2018-02-10 20:23:46 --> Model Class Initialized
INFO - 2018-02-10 20:23:46 --> Model Class Initialized
INFO - 2018-02-10 20:23:46 --> Model Class Initialized
INFO - 2018-02-10 20:23:46 --> Model Class Initialized
DEBUG - 2018-02-10 20:23:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 20:23:49 --> Config Class Initialized
INFO - 2018-02-10 20:23:49 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:23:49 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:23:49 --> Utf8 Class Initialized
INFO - 2018-02-10 20:23:49 --> URI Class Initialized
INFO - 2018-02-10 20:23:49 --> Router Class Initialized
INFO - 2018-02-10 20:23:49 --> Output Class Initialized
INFO - 2018-02-10 20:23:49 --> Security Class Initialized
DEBUG - 2018-02-10 20:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:23:49 --> Input Class Initialized
INFO - 2018-02-10 20:23:49 --> Language Class Initialized
INFO - 2018-02-10 20:23:49 --> Loader Class Initialized
INFO - 2018-02-10 20:23:49 --> Helper loaded: url_helper
INFO - 2018-02-10 20:23:49 --> Helper loaded: form_helper
INFO - 2018-02-10 20:23:49 --> Database Driver Class Initialized
DEBUG - 2018-02-10 20:23:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:23:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 20:23:49 --> Form Validation Class Initialized
INFO - 2018-02-10 20:23:49 --> Model Class Initialized
INFO - 2018-02-10 20:23:49 --> Controller Class Initialized
INFO - 2018-02-10 20:23:49 --> Model Class Initialized
INFO - 2018-02-10 20:23:49 --> Model Class Initialized
INFO - 2018-02-10 20:23:49 --> Model Class Initialized
INFO - 2018-02-10 20:23:49 --> Model Class Initialized
INFO - 2018-02-10 20:23:49 --> Model Class Initialized
DEBUG - 2018-02-10 20:23:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 20:23:49 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 20:23:49 --> Final output sent to browser
DEBUG - 2018-02-10 20:23:49 --> Total execution time: 0.0653
INFO - 2018-02-10 20:23:49 --> Config Class Initialized
INFO - 2018-02-10 20:23:49 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:23:49 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:23:49 --> Utf8 Class Initialized
INFO - 2018-02-10 20:23:49 --> URI Class Initialized
INFO - 2018-02-10 20:23:49 --> Router Class Initialized
INFO - 2018-02-10 20:23:49 --> Output Class Initialized
INFO - 2018-02-10 20:23:49 --> Security Class Initialized
DEBUG - 2018-02-10 20:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:23:49 --> Input Class Initialized
INFO - 2018-02-10 20:23:49 --> Language Class Initialized
INFO - 2018-02-10 20:23:49 --> Loader Class Initialized
INFO - 2018-02-10 20:23:49 --> Helper loaded: url_helper
INFO - 2018-02-10 20:23:49 --> Helper loaded: form_helper
INFO - 2018-02-10 20:23:49 --> Database Driver Class Initialized
DEBUG - 2018-02-10 20:23:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:23:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 20:23:49 --> Form Validation Class Initialized
INFO - 2018-02-10 20:23:49 --> Model Class Initialized
INFO - 2018-02-10 20:23:49 --> Controller Class Initialized
INFO - 2018-02-10 20:23:49 --> Model Class Initialized
INFO - 2018-02-10 20:23:49 --> Model Class Initialized
INFO - 2018-02-10 20:23:49 --> Model Class Initialized
INFO - 2018-02-10 20:23:49 --> Model Class Initialized
INFO - 2018-02-10 20:23:49 --> Model Class Initialized
DEBUG - 2018-02-10 20:23:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 20:23:52 --> Config Class Initialized
INFO - 2018-02-10 20:23:52 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:23:52 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:23:52 --> Utf8 Class Initialized
INFO - 2018-02-10 20:23:52 --> URI Class Initialized
INFO - 2018-02-10 20:23:52 --> Router Class Initialized
INFO - 2018-02-10 20:23:52 --> Output Class Initialized
INFO - 2018-02-10 20:23:52 --> Security Class Initialized
DEBUG - 2018-02-10 20:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:23:52 --> Input Class Initialized
INFO - 2018-02-10 20:23:52 --> Language Class Initialized
INFO - 2018-02-10 20:23:52 --> Loader Class Initialized
INFO - 2018-02-10 20:23:52 --> Helper loaded: url_helper
INFO - 2018-02-10 20:23:52 --> Helper loaded: form_helper
INFO - 2018-02-10 20:23:52 --> Database Driver Class Initialized
DEBUG - 2018-02-10 20:23:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:23:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 20:23:52 --> Form Validation Class Initialized
INFO - 2018-02-10 20:23:52 --> Model Class Initialized
INFO - 2018-02-10 20:23:52 --> Controller Class Initialized
INFO - 2018-02-10 20:23:52 --> Model Class Initialized
INFO - 2018-02-10 20:23:52 --> Model Class Initialized
INFO - 2018-02-10 20:23:52 --> Model Class Initialized
INFO - 2018-02-10 20:23:52 --> Model Class Initialized
INFO - 2018-02-10 20:23:52 --> Model Class Initialized
DEBUG - 2018-02-10 20:23:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 20:23:52 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 20:23:52 --> Final output sent to browser
DEBUG - 2018-02-10 20:23:52 --> Total execution time: 0.0594
INFO - 2018-02-10 20:23:52 --> Config Class Initialized
INFO - 2018-02-10 20:23:52 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:23:52 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:23:52 --> Utf8 Class Initialized
INFO - 2018-02-10 20:23:52 --> URI Class Initialized
INFO - 2018-02-10 20:23:52 --> Router Class Initialized
INFO - 2018-02-10 20:23:52 --> Output Class Initialized
INFO - 2018-02-10 20:23:52 --> Security Class Initialized
DEBUG - 2018-02-10 20:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:23:52 --> Input Class Initialized
INFO - 2018-02-10 20:23:52 --> Language Class Initialized
INFO - 2018-02-10 20:23:52 --> Loader Class Initialized
INFO - 2018-02-10 20:23:52 --> Helper loaded: url_helper
INFO - 2018-02-10 20:23:52 --> Helper loaded: form_helper
INFO - 2018-02-10 20:23:52 --> Database Driver Class Initialized
DEBUG - 2018-02-10 20:23:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:23:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 20:23:52 --> Form Validation Class Initialized
INFO - 2018-02-10 20:23:52 --> Model Class Initialized
INFO - 2018-02-10 20:23:52 --> Controller Class Initialized
INFO - 2018-02-10 20:23:52 --> Model Class Initialized
INFO - 2018-02-10 20:23:52 --> Model Class Initialized
INFO - 2018-02-10 20:23:52 --> Model Class Initialized
INFO - 2018-02-10 20:23:52 --> Model Class Initialized
INFO - 2018-02-10 20:23:52 --> Model Class Initialized
DEBUG - 2018-02-10 20:23:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 20:23:53 --> Config Class Initialized
INFO - 2018-02-10 20:23:53 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:23:53 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:23:53 --> Utf8 Class Initialized
INFO - 2018-02-10 20:23:53 --> URI Class Initialized
INFO - 2018-02-10 20:23:53 --> Router Class Initialized
INFO - 2018-02-10 20:23:53 --> Output Class Initialized
INFO - 2018-02-10 20:23:53 --> Security Class Initialized
DEBUG - 2018-02-10 20:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:23:53 --> Input Class Initialized
INFO - 2018-02-10 20:23:53 --> Language Class Initialized
INFO - 2018-02-10 20:23:53 --> Loader Class Initialized
INFO - 2018-02-10 20:23:53 --> Helper loaded: url_helper
INFO - 2018-02-10 20:23:53 --> Helper loaded: form_helper
INFO - 2018-02-10 20:23:53 --> Database Driver Class Initialized
DEBUG - 2018-02-10 20:23:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:23:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 20:23:53 --> Form Validation Class Initialized
INFO - 2018-02-10 20:23:53 --> Model Class Initialized
INFO - 2018-02-10 20:23:53 --> Controller Class Initialized
INFO - 2018-02-10 20:23:53 --> Model Class Initialized
INFO - 2018-02-10 20:23:53 --> Model Class Initialized
INFO - 2018-02-10 20:23:53 --> Model Class Initialized
INFO - 2018-02-10 20:23:53 --> Model Class Initialized
INFO - 2018-02-10 20:23:53 --> Model Class Initialized
DEBUG - 2018-02-10 20:23:53 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-10 20:23:53 --> Severity: Notice --> Undefined property: stdClass::$jefe_proyecto_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\proyecto\agregarProyecto.php 99
ERROR - 2018-02-10 20:23:53 --> Severity: Notice --> Undefined property: stdClass::$jefe_proyecto_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\proyecto\agregarProyecto.php 99
INFO - 2018-02-10 20:23:53 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 20:23:53 --> Final output sent to browser
DEBUG - 2018-02-10 20:23:53 --> Total execution time: 0.0517
INFO - 2018-02-10 20:24:12 --> Config Class Initialized
INFO - 2018-02-10 20:24:12 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:24:12 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:24:12 --> Utf8 Class Initialized
INFO - 2018-02-10 20:24:12 --> URI Class Initialized
INFO - 2018-02-10 20:24:12 --> Router Class Initialized
INFO - 2018-02-10 20:24:12 --> Output Class Initialized
INFO - 2018-02-10 20:24:12 --> Security Class Initialized
DEBUG - 2018-02-10 20:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:24:12 --> Input Class Initialized
INFO - 2018-02-10 20:24:12 --> Language Class Initialized
INFO - 2018-02-10 20:24:12 --> Loader Class Initialized
INFO - 2018-02-10 20:24:12 --> Helper loaded: url_helper
INFO - 2018-02-10 20:24:12 --> Helper loaded: form_helper
INFO - 2018-02-10 20:24:12 --> Database Driver Class Initialized
DEBUG - 2018-02-10 20:24:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:24:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 20:24:12 --> Form Validation Class Initialized
INFO - 2018-02-10 20:24:12 --> Model Class Initialized
INFO - 2018-02-10 20:24:12 --> Controller Class Initialized
INFO - 2018-02-10 20:24:12 --> Model Class Initialized
INFO - 2018-02-10 20:24:12 --> Model Class Initialized
INFO - 2018-02-10 20:24:12 --> Model Class Initialized
INFO - 2018-02-10 20:24:12 --> Model Class Initialized
INFO - 2018-02-10 20:24:12 --> Model Class Initialized
DEBUG - 2018-02-10 20:24:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 20:24:12 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 20:24:12 --> Final output sent to browser
DEBUG - 2018-02-10 20:24:12 --> Total execution time: 0.0675
INFO - 2018-02-10 20:24:18 --> Config Class Initialized
INFO - 2018-02-10 20:24:18 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:24:18 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:24:18 --> Utf8 Class Initialized
INFO - 2018-02-10 20:24:18 --> URI Class Initialized
INFO - 2018-02-10 20:24:18 --> Router Class Initialized
INFO - 2018-02-10 20:24:18 --> Output Class Initialized
INFO - 2018-02-10 20:24:18 --> Security Class Initialized
DEBUG - 2018-02-10 20:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:24:18 --> Input Class Initialized
INFO - 2018-02-10 20:24:18 --> Language Class Initialized
INFO - 2018-02-10 20:24:18 --> Loader Class Initialized
INFO - 2018-02-10 20:24:18 --> Helper loaded: url_helper
INFO - 2018-02-10 20:24:18 --> Helper loaded: form_helper
INFO - 2018-02-10 20:24:18 --> Database Driver Class Initialized
DEBUG - 2018-02-10 20:24:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:24:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 20:24:18 --> Form Validation Class Initialized
INFO - 2018-02-10 20:24:18 --> Model Class Initialized
INFO - 2018-02-10 20:24:18 --> Controller Class Initialized
INFO - 2018-02-10 20:24:18 --> Model Class Initialized
DEBUG - 2018-02-10 20:24:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 20:24:18 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 20:24:18 --> Final output sent to browser
DEBUG - 2018-02-10 20:24:18 --> Total execution time: 0.0456
INFO - 2018-02-10 20:24:18 --> Config Class Initialized
INFO - 2018-02-10 20:24:18 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:24:18 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:24:18 --> Utf8 Class Initialized
INFO - 2018-02-10 20:24:18 --> URI Class Initialized
INFO - 2018-02-10 20:24:18 --> Router Class Initialized
INFO - 2018-02-10 20:24:18 --> Output Class Initialized
INFO - 2018-02-10 20:24:18 --> Security Class Initialized
DEBUG - 2018-02-10 20:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:24:18 --> Input Class Initialized
INFO - 2018-02-10 20:24:18 --> Language Class Initialized
INFO - 2018-02-10 20:24:18 --> Loader Class Initialized
INFO - 2018-02-10 20:24:18 --> Helper loaded: url_helper
INFO - 2018-02-10 20:24:19 --> Helper loaded: form_helper
INFO - 2018-02-10 20:24:19 --> Database Driver Class Initialized
DEBUG - 2018-02-10 20:24:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:24:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 20:24:19 --> Form Validation Class Initialized
INFO - 2018-02-10 20:24:19 --> Model Class Initialized
INFO - 2018-02-10 20:24:19 --> Controller Class Initialized
INFO - 2018-02-10 20:24:19 --> Model Class Initialized
DEBUG - 2018-02-10 20:24:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 20:24:25 --> Config Class Initialized
INFO - 2018-02-10 20:24:25 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:24:25 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:24:25 --> Utf8 Class Initialized
INFO - 2018-02-10 20:24:25 --> URI Class Initialized
INFO - 2018-02-10 20:24:25 --> Router Class Initialized
INFO - 2018-02-10 20:24:25 --> Output Class Initialized
INFO - 2018-02-10 20:24:25 --> Security Class Initialized
DEBUG - 2018-02-10 20:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:24:25 --> Input Class Initialized
INFO - 2018-02-10 20:24:25 --> Language Class Initialized
INFO - 2018-02-10 20:24:25 --> Loader Class Initialized
INFO - 2018-02-10 20:24:25 --> Helper loaded: url_helper
INFO - 2018-02-10 20:24:25 --> Helper loaded: form_helper
INFO - 2018-02-10 20:24:25 --> Database Driver Class Initialized
DEBUG - 2018-02-10 20:24:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:24:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 20:24:25 --> Form Validation Class Initialized
INFO - 2018-02-10 20:24:25 --> Model Class Initialized
INFO - 2018-02-10 20:24:25 --> Controller Class Initialized
INFO - 2018-02-10 20:24:25 --> Model Class Initialized
DEBUG - 2018-02-10 20:24:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 20:24:25 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 20:24:25 --> Final output sent to browser
DEBUG - 2018-02-10 20:24:25 --> Total execution time: 0.0579
INFO - 2018-02-10 20:24:26 --> Config Class Initialized
INFO - 2018-02-10 20:24:26 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:24:26 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:24:26 --> Utf8 Class Initialized
INFO - 2018-02-10 20:24:26 --> URI Class Initialized
INFO - 2018-02-10 20:24:26 --> Router Class Initialized
INFO - 2018-02-10 20:24:26 --> Output Class Initialized
INFO - 2018-02-10 20:24:26 --> Security Class Initialized
DEBUG - 2018-02-10 20:24:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:24:26 --> Input Class Initialized
INFO - 2018-02-10 20:24:26 --> Language Class Initialized
INFO - 2018-02-10 20:24:26 --> Loader Class Initialized
INFO - 2018-02-10 20:24:26 --> Helper loaded: url_helper
INFO - 2018-02-10 20:24:26 --> Helper loaded: form_helper
INFO - 2018-02-10 20:24:26 --> Database Driver Class Initialized
DEBUG - 2018-02-10 20:24:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:24:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 20:24:26 --> Form Validation Class Initialized
INFO - 2018-02-10 20:24:26 --> Model Class Initialized
INFO - 2018-02-10 20:24:26 --> Controller Class Initialized
INFO - 2018-02-10 20:24:26 --> Model Class Initialized
DEBUG - 2018-02-10 20:24:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 20:24:27 --> Config Class Initialized
INFO - 2018-02-10 20:24:27 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:24:27 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:24:27 --> Utf8 Class Initialized
INFO - 2018-02-10 20:24:27 --> URI Class Initialized
INFO - 2018-02-10 20:24:27 --> Router Class Initialized
INFO - 2018-02-10 20:24:27 --> Output Class Initialized
INFO - 2018-02-10 20:24:27 --> Security Class Initialized
DEBUG - 2018-02-10 20:24:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:24:27 --> Input Class Initialized
INFO - 2018-02-10 20:24:27 --> Language Class Initialized
INFO - 2018-02-10 20:24:27 --> Loader Class Initialized
INFO - 2018-02-10 20:24:27 --> Helper loaded: url_helper
INFO - 2018-02-10 20:24:27 --> Helper loaded: form_helper
INFO - 2018-02-10 20:24:27 --> Database Driver Class Initialized
DEBUG - 2018-02-10 20:24:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:24:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 20:24:27 --> Form Validation Class Initialized
INFO - 2018-02-10 20:24:27 --> Model Class Initialized
INFO - 2018-02-10 20:24:27 --> Controller Class Initialized
INFO - 2018-02-10 20:24:27 --> Model Class Initialized
INFO - 2018-02-10 20:24:27 --> Model Class Initialized
DEBUG - 2018-02-10 20:24:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 20:24:27 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 20:24:27 --> Final output sent to browser
DEBUG - 2018-02-10 20:24:27 --> Total execution time: 0.1693
INFO - 2018-02-10 20:24:28 --> Config Class Initialized
INFO - 2018-02-10 20:24:28 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:24:28 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:24:28 --> Utf8 Class Initialized
INFO - 2018-02-10 20:24:28 --> URI Class Initialized
INFO - 2018-02-10 20:24:28 --> Router Class Initialized
INFO - 2018-02-10 20:24:28 --> Output Class Initialized
INFO - 2018-02-10 20:24:28 --> Security Class Initialized
DEBUG - 2018-02-10 20:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:24:28 --> Input Class Initialized
INFO - 2018-02-10 20:24:28 --> Language Class Initialized
INFO - 2018-02-10 20:24:28 --> Loader Class Initialized
INFO - 2018-02-10 20:24:28 --> Helper loaded: url_helper
INFO - 2018-02-10 20:24:28 --> Helper loaded: form_helper
INFO - 2018-02-10 20:24:28 --> Database Driver Class Initialized
DEBUG - 2018-02-10 20:24:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:24:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 20:24:28 --> Form Validation Class Initialized
INFO - 2018-02-10 20:24:28 --> Model Class Initialized
INFO - 2018-02-10 20:24:28 --> Controller Class Initialized
INFO - 2018-02-10 20:24:28 --> Model Class Initialized
INFO - 2018-02-10 20:24:28 --> Model Class Initialized
DEBUG - 2018-02-10 20:24:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 20:24:29 --> Config Class Initialized
INFO - 2018-02-10 20:24:29 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:24:29 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:24:29 --> Utf8 Class Initialized
INFO - 2018-02-10 20:24:29 --> URI Class Initialized
INFO - 2018-02-10 20:24:29 --> Router Class Initialized
INFO - 2018-02-10 20:24:29 --> Output Class Initialized
INFO - 2018-02-10 20:24:29 --> Security Class Initialized
DEBUG - 2018-02-10 20:24:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:24:29 --> Input Class Initialized
INFO - 2018-02-10 20:24:29 --> Language Class Initialized
INFO - 2018-02-10 20:24:29 --> Loader Class Initialized
INFO - 2018-02-10 20:24:29 --> Helper loaded: url_helper
INFO - 2018-02-10 20:24:29 --> Helper loaded: form_helper
INFO - 2018-02-10 20:24:29 --> Database Driver Class Initialized
DEBUG - 2018-02-10 20:24:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:24:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 20:24:29 --> Form Validation Class Initialized
INFO - 2018-02-10 20:24:29 --> Model Class Initialized
INFO - 2018-02-10 20:24:29 --> Controller Class Initialized
INFO - 2018-02-10 20:24:29 --> Model Class Initialized
INFO - 2018-02-10 20:24:29 --> Model Class Initialized
INFO - 2018-02-10 20:24:29 --> Model Class Initialized
INFO - 2018-02-10 20:24:29 --> Model Class Initialized
INFO - 2018-02-10 20:24:29 --> Model Class Initialized
DEBUG - 2018-02-10 20:24:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 20:24:29 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 20:24:29 --> Final output sent to browser
DEBUG - 2018-02-10 20:24:29 --> Total execution time: 0.0490
INFO - 2018-02-10 20:24:29 --> Config Class Initialized
INFO - 2018-02-10 20:24:29 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:24:29 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:24:29 --> Utf8 Class Initialized
INFO - 2018-02-10 20:24:29 --> URI Class Initialized
INFO - 2018-02-10 20:24:29 --> Router Class Initialized
INFO - 2018-02-10 20:24:29 --> Output Class Initialized
INFO - 2018-02-10 20:24:29 --> Security Class Initialized
DEBUG - 2018-02-10 20:24:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:24:29 --> Input Class Initialized
INFO - 2018-02-10 20:24:29 --> Language Class Initialized
INFO - 2018-02-10 20:24:29 --> Loader Class Initialized
INFO - 2018-02-10 20:24:29 --> Helper loaded: url_helper
INFO - 2018-02-10 20:24:29 --> Helper loaded: form_helper
INFO - 2018-02-10 20:24:29 --> Database Driver Class Initialized
DEBUG - 2018-02-10 20:24:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:24:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 20:24:29 --> Form Validation Class Initialized
INFO - 2018-02-10 20:24:29 --> Model Class Initialized
INFO - 2018-02-10 20:24:29 --> Controller Class Initialized
INFO - 2018-02-10 20:24:29 --> Model Class Initialized
INFO - 2018-02-10 20:24:29 --> Model Class Initialized
INFO - 2018-02-10 20:24:29 --> Model Class Initialized
INFO - 2018-02-10 20:24:29 --> Model Class Initialized
INFO - 2018-02-10 20:24:29 --> Model Class Initialized
DEBUG - 2018-02-10 20:24:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 20:24:31 --> Config Class Initialized
INFO - 2018-02-10 20:24:31 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:24:31 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:24:31 --> Utf8 Class Initialized
INFO - 2018-02-10 20:24:31 --> URI Class Initialized
INFO - 2018-02-10 20:24:31 --> Router Class Initialized
INFO - 2018-02-10 20:24:31 --> Output Class Initialized
INFO - 2018-02-10 20:24:31 --> Security Class Initialized
DEBUG - 2018-02-10 20:24:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:24:31 --> Input Class Initialized
INFO - 2018-02-10 20:24:31 --> Language Class Initialized
INFO - 2018-02-10 20:24:31 --> Loader Class Initialized
INFO - 2018-02-10 20:24:31 --> Helper loaded: url_helper
INFO - 2018-02-10 20:24:31 --> Helper loaded: form_helper
INFO - 2018-02-10 20:24:31 --> Database Driver Class Initialized
DEBUG - 2018-02-10 20:24:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:24:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 20:24:31 --> Form Validation Class Initialized
INFO - 2018-02-10 20:24:31 --> Model Class Initialized
INFO - 2018-02-10 20:24:31 --> Controller Class Initialized
INFO - 2018-02-10 20:24:31 --> Model Class Initialized
INFO - 2018-02-10 20:24:31 --> Model Class Initialized
INFO - 2018-02-10 20:24:31 --> Model Class Initialized
INFO - 2018-02-10 20:24:31 --> Model Class Initialized
INFO - 2018-02-10 20:24:31 --> Model Class Initialized
DEBUG - 2018-02-10 20:24:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 20:24:31 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 20:24:31 --> Final output sent to browser
DEBUG - 2018-02-10 20:24:31 --> Total execution time: 0.0550
INFO - 2018-02-10 20:31:09 --> Config Class Initialized
INFO - 2018-02-10 20:31:09 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:31:09 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:31:09 --> Utf8 Class Initialized
INFO - 2018-02-10 20:31:09 --> URI Class Initialized
INFO - 2018-02-10 20:31:09 --> Router Class Initialized
INFO - 2018-02-10 20:31:09 --> Output Class Initialized
INFO - 2018-02-10 20:31:09 --> Security Class Initialized
DEBUG - 2018-02-10 20:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:31:09 --> Input Class Initialized
INFO - 2018-02-10 20:31:09 --> Language Class Initialized
INFO - 2018-02-10 20:31:09 --> Loader Class Initialized
INFO - 2018-02-10 20:31:09 --> Helper loaded: url_helper
INFO - 2018-02-10 20:31:09 --> Helper loaded: form_helper
INFO - 2018-02-10 20:31:09 --> Database Driver Class Initialized
DEBUG - 2018-02-10 20:31:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:31:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 20:31:09 --> Form Validation Class Initialized
INFO - 2018-02-10 20:31:09 --> Model Class Initialized
INFO - 2018-02-10 20:31:09 --> Controller Class Initialized
INFO - 2018-02-10 20:31:09 --> Model Class Initialized
INFO - 2018-02-10 20:31:09 --> Model Class Initialized
INFO - 2018-02-10 20:31:09 --> Model Class Initialized
INFO - 2018-02-10 20:31:09 --> Model Class Initialized
INFO - 2018-02-10 20:31:09 --> Model Class Initialized
DEBUG - 2018-02-10 20:31:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 20:31:09 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 20:31:09 --> Final output sent to browser
DEBUG - 2018-02-10 20:31:09 --> Total execution time: 0.0467
INFO - 2018-02-10 20:31:11 --> Config Class Initialized
INFO - 2018-02-10 20:31:11 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:31:11 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:31:11 --> Utf8 Class Initialized
INFO - 2018-02-10 20:31:11 --> URI Class Initialized
INFO - 2018-02-10 20:31:11 --> Router Class Initialized
INFO - 2018-02-10 20:31:11 --> Output Class Initialized
INFO - 2018-02-10 20:31:11 --> Security Class Initialized
DEBUG - 2018-02-10 20:31:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:31:11 --> Input Class Initialized
INFO - 2018-02-10 20:31:11 --> Language Class Initialized
INFO - 2018-02-10 20:31:11 --> Loader Class Initialized
INFO - 2018-02-10 20:31:11 --> Helper loaded: url_helper
INFO - 2018-02-10 20:31:11 --> Helper loaded: form_helper
INFO - 2018-02-10 20:31:11 --> Database Driver Class Initialized
DEBUG - 2018-02-10 20:31:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:31:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 20:31:11 --> Form Validation Class Initialized
INFO - 2018-02-10 20:31:11 --> Model Class Initialized
INFO - 2018-02-10 20:31:11 --> Controller Class Initialized
INFO - 2018-02-10 20:31:11 --> Model Class Initialized
INFO - 2018-02-10 20:31:11 --> Model Class Initialized
INFO - 2018-02-10 20:31:11 --> Model Class Initialized
INFO - 2018-02-10 20:31:11 --> Model Class Initialized
INFO - 2018-02-10 20:31:11 --> Model Class Initialized
DEBUG - 2018-02-10 20:31:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 20:31:11 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 20:31:11 --> Final output sent to browser
DEBUG - 2018-02-10 20:31:11 --> Total execution time: 0.0584
INFO - 2018-02-10 20:31:11 --> Config Class Initialized
INFO - 2018-02-10 20:31:11 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:31:11 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:31:11 --> Utf8 Class Initialized
INFO - 2018-02-10 20:31:11 --> URI Class Initialized
INFO - 2018-02-10 20:31:11 --> Router Class Initialized
INFO - 2018-02-10 20:31:11 --> Output Class Initialized
INFO - 2018-02-10 20:31:11 --> Security Class Initialized
DEBUG - 2018-02-10 20:31:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:31:11 --> Input Class Initialized
INFO - 2018-02-10 20:31:11 --> Language Class Initialized
INFO - 2018-02-10 20:31:11 --> Loader Class Initialized
INFO - 2018-02-10 20:31:11 --> Helper loaded: url_helper
INFO - 2018-02-10 20:31:11 --> Helper loaded: form_helper
INFO - 2018-02-10 20:31:11 --> Database Driver Class Initialized
DEBUG - 2018-02-10 20:31:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:31:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 20:31:11 --> Form Validation Class Initialized
INFO - 2018-02-10 20:31:11 --> Model Class Initialized
INFO - 2018-02-10 20:31:11 --> Controller Class Initialized
INFO - 2018-02-10 20:31:11 --> Model Class Initialized
INFO - 2018-02-10 20:31:11 --> Model Class Initialized
INFO - 2018-02-10 20:31:11 --> Model Class Initialized
INFO - 2018-02-10 20:31:12 --> Model Class Initialized
INFO - 2018-02-10 20:31:12 --> Model Class Initialized
DEBUG - 2018-02-10 20:31:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 20:31:14 --> Config Class Initialized
INFO - 2018-02-10 20:31:14 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:31:14 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:31:14 --> Utf8 Class Initialized
INFO - 2018-02-10 20:31:14 --> URI Class Initialized
INFO - 2018-02-10 20:31:14 --> Router Class Initialized
INFO - 2018-02-10 20:31:14 --> Output Class Initialized
INFO - 2018-02-10 20:31:14 --> Security Class Initialized
DEBUG - 2018-02-10 20:31:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:31:14 --> Input Class Initialized
INFO - 2018-02-10 20:31:14 --> Language Class Initialized
INFO - 2018-02-10 20:31:14 --> Loader Class Initialized
INFO - 2018-02-10 20:31:14 --> Helper loaded: url_helper
INFO - 2018-02-10 20:31:14 --> Helper loaded: form_helper
INFO - 2018-02-10 20:31:14 --> Database Driver Class Initialized
DEBUG - 2018-02-10 20:31:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:31:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 20:31:14 --> Form Validation Class Initialized
INFO - 2018-02-10 20:31:14 --> Model Class Initialized
INFO - 2018-02-10 20:31:14 --> Controller Class Initialized
INFO - 2018-02-10 20:31:14 --> Model Class Initialized
INFO - 2018-02-10 20:31:14 --> Model Class Initialized
INFO - 2018-02-10 20:31:14 --> Model Class Initialized
INFO - 2018-02-10 20:31:14 --> Model Class Initialized
INFO - 2018-02-10 20:31:14 --> Model Class Initialized
DEBUG - 2018-02-10 20:31:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 20:31:14 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 20:31:14 --> Final output sent to browser
DEBUG - 2018-02-10 20:31:14 --> Total execution time: 0.0645
INFO - 2018-02-10 20:31:14 --> Config Class Initialized
INFO - 2018-02-10 20:31:14 --> Hooks Class Initialized
INFO - 2018-02-10 20:31:14 --> Config Class Initialized
INFO - 2018-02-10 20:31:14 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:31:14 --> UTF-8 Support Enabled
DEBUG - 2018-02-10 20:31:14 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:31:14 --> Utf8 Class Initialized
INFO - 2018-02-10 20:31:14 --> Utf8 Class Initialized
INFO - 2018-02-10 20:31:14 --> URI Class Initialized
INFO - 2018-02-10 20:31:14 --> URI Class Initialized
INFO - 2018-02-10 20:31:14 --> Router Class Initialized
INFO - 2018-02-10 20:31:14 --> Router Class Initialized
INFO - 2018-02-10 20:31:14 --> Output Class Initialized
INFO - 2018-02-10 20:31:14 --> Output Class Initialized
INFO - 2018-02-10 20:31:14 --> Security Class Initialized
INFO - 2018-02-10 20:31:14 --> Security Class Initialized
DEBUG - 2018-02-10 20:31:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-10 20:31:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:31:14 --> Input Class Initialized
INFO - 2018-02-10 20:31:14 --> Input Class Initialized
INFO - 2018-02-10 20:31:14 --> Language Class Initialized
INFO - 2018-02-10 20:31:14 --> Language Class Initialized
INFO - 2018-02-10 20:31:14 --> Loader Class Initialized
INFO - 2018-02-10 20:31:14 --> Loader Class Initialized
INFO - 2018-02-10 20:31:14 --> Helper loaded: url_helper
INFO - 2018-02-10 20:31:14 --> Helper loaded: url_helper
INFO - 2018-02-10 20:31:14 --> Helper loaded: form_helper
INFO - 2018-02-10 20:31:14 --> Helper loaded: form_helper
INFO - 2018-02-10 20:31:14 --> Database Driver Class Initialized
INFO - 2018-02-10 20:31:14 --> Database Driver Class Initialized
DEBUG - 2018-02-10 20:31:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-10 20:31:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:31:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 20:31:14 --> Form Validation Class Initialized
INFO - 2018-02-10 20:31:14 --> Model Class Initialized
INFO - 2018-02-10 20:31:14 --> Controller Class Initialized
INFO - 2018-02-10 20:31:14 --> Model Class Initialized
INFO - 2018-02-10 20:31:14 --> Model Class Initialized
INFO - 2018-02-10 20:31:14 --> Model Class Initialized
INFO - 2018-02-10 20:31:14 --> Model Class Initialized
INFO - 2018-02-10 20:31:14 --> Model Class Initialized
DEBUG - 2018-02-10 20:31:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 20:31:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 20:31:14 --> Form Validation Class Initialized
INFO - 2018-02-10 20:31:14 --> Model Class Initialized
INFO - 2018-02-10 20:31:14 --> Controller Class Initialized
INFO - 2018-02-10 20:31:14 --> Model Class Initialized
INFO - 2018-02-10 20:31:14 --> Model Class Initialized
INFO - 2018-02-10 20:31:14 --> Model Class Initialized
INFO - 2018-02-10 20:31:14 --> Model Class Initialized
INFO - 2018-02-10 20:31:14 --> Model Class Initialized
DEBUG - 2018-02-10 20:31:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 20:31:19 --> Config Class Initialized
INFO - 2018-02-10 20:31:19 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:31:19 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:31:19 --> Utf8 Class Initialized
INFO - 2018-02-10 20:31:19 --> URI Class Initialized
INFO - 2018-02-10 20:31:19 --> Router Class Initialized
INFO - 2018-02-10 20:31:19 --> Output Class Initialized
INFO - 2018-02-10 20:31:19 --> Security Class Initialized
DEBUG - 2018-02-10 20:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:31:19 --> Input Class Initialized
INFO - 2018-02-10 20:31:19 --> Language Class Initialized
INFO - 2018-02-10 20:31:19 --> Loader Class Initialized
INFO - 2018-02-10 20:31:19 --> Helper loaded: url_helper
INFO - 2018-02-10 20:31:19 --> Helper loaded: form_helper
INFO - 2018-02-10 20:31:19 --> Database Driver Class Initialized
DEBUG - 2018-02-10 20:31:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:31:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 20:31:19 --> Form Validation Class Initialized
INFO - 2018-02-10 20:31:19 --> Model Class Initialized
INFO - 2018-02-10 20:31:19 --> Controller Class Initialized
INFO - 2018-02-10 20:31:19 --> Model Class Initialized
INFO - 2018-02-10 20:31:19 --> Model Class Initialized
INFO - 2018-02-10 20:31:19 --> Model Class Initialized
INFO - 2018-02-10 20:31:19 --> Model Class Initialized
INFO - 2018-02-10 20:31:19 --> Model Class Initialized
DEBUG - 2018-02-10 20:31:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 20:31:20 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 20:31:20 --> Final output sent to browser
DEBUG - 2018-02-10 20:31:20 --> Total execution time: 0.8652
INFO - 2018-02-10 20:31:20 --> Config Class Initialized
INFO - 2018-02-10 20:31:20 --> Hooks Class Initialized
INFO - 2018-02-10 20:31:20 --> Config Class Initialized
INFO - 2018-02-10 20:31:20 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:31:20 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:31:20 --> Utf8 Class Initialized
INFO - 2018-02-10 20:31:20 --> URI Class Initialized
DEBUG - 2018-02-10 20:31:20 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:31:20 --> Utf8 Class Initialized
INFO - 2018-02-10 20:31:20 --> Router Class Initialized
INFO - 2018-02-10 20:31:20 --> URI Class Initialized
INFO - 2018-02-10 20:31:20 --> Output Class Initialized
INFO - 2018-02-10 20:31:20 --> Security Class Initialized
INFO - 2018-02-10 20:31:20 --> Router Class Initialized
DEBUG - 2018-02-10 20:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:31:20 --> Input Class Initialized
INFO - 2018-02-10 20:31:20 --> Language Class Initialized
INFO - 2018-02-10 20:31:20 --> Output Class Initialized
INFO - 2018-02-10 20:31:20 --> Security Class Initialized
INFO - 2018-02-10 20:31:20 --> Loader Class Initialized
DEBUG - 2018-02-10 20:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:31:20 --> Input Class Initialized
INFO - 2018-02-10 20:31:20 --> Helper loaded: url_helper
INFO - 2018-02-10 20:31:20 --> Language Class Initialized
INFO - 2018-02-10 20:31:20 --> Helper loaded: form_helper
INFO - 2018-02-10 20:31:20 --> Loader Class Initialized
INFO - 2018-02-10 20:31:20 --> Helper loaded: url_helper
INFO - 2018-02-10 20:31:20 --> Database Driver Class Initialized
INFO - 2018-02-10 20:31:20 --> Helper loaded: form_helper
INFO - 2018-02-10 20:31:20 --> Database Driver Class Initialized
DEBUG - 2018-02-10 20:31:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:31:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-02-10 20:31:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:31:20 --> Form Validation Class Initialized
INFO - 2018-02-10 20:31:20 --> Model Class Initialized
INFO - 2018-02-10 20:31:20 --> Controller Class Initialized
INFO - 2018-02-10 20:31:20 --> Model Class Initialized
INFO - 2018-02-10 20:31:20 --> Model Class Initialized
INFO - 2018-02-10 20:31:20 --> Model Class Initialized
INFO - 2018-02-10 20:31:20 --> Model Class Initialized
INFO - 2018-02-10 20:31:20 --> Model Class Initialized
DEBUG - 2018-02-10 20:31:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 20:31:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 20:31:20 --> Form Validation Class Initialized
INFO - 2018-02-10 20:31:20 --> Model Class Initialized
INFO - 2018-02-10 20:31:20 --> Controller Class Initialized
INFO - 2018-02-10 20:31:20 --> Model Class Initialized
INFO - 2018-02-10 20:31:20 --> Model Class Initialized
INFO - 2018-02-10 20:31:20 --> Model Class Initialized
INFO - 2018-02-10 20:31:20 --> Model Class Initialized
INFO - 2018-02-10 20:31:20 --> Model Class Initialized
DEBUG - 2018-02-10 20:31:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 20:33:23 --> Config Class Initialized
INFO - 2018-02-10 20:33:23 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:33:23 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:33:23 --> Utf8 Class Initialized
INFO - 2018-02-10 20:33:23 --> URI Class Initialized
INFO - 2018-02-10 20:33:23 --> Router Class Initialized
INFO - 2018-02-10 20:33:23 --> Output Class Initialized
INFO - 2018-02-10 20:33:23 --> Security Class Initialized
DEBUG - 2018-02-10 20:33:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:33:23 --> Input Class Initialized
INFO - 2018-02-10 20:33:23 --> Language Class Initialized
INFO - 2018-02-10 20:33:23 --> Loader Class Initialized
INFO - 2018-02-10 20:33:23 --> Helper loaded: url_helper
INFO - 2018-02-10 20:33:23 --> Helper loaded: form_helper
INFO - 2018-02-10 20:33:23 --> Database Driver Class Initialized
DEBUG - 2018-02-10 20:33:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:33:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 20:33:23 --> Form Validation Class Initialized
INFO - 2018-02-10 20:33:23 --> Model Class Initialized
INFO - 2018-02-10 20:33:23 --> Controller Class Initialized
INFO - 2018-02-10 20:33:23 --> Model Class Initialized
INFO - 2018-02-10 20:33:23 --> Model Class Initialized
INFO - 2018-02-10 20:33:23 --> Model Class Initialized
INFO - 2018-02-10 20:33:23 --> Model Class Initialized
INFO - 2018-02-10 20:33:23 --> Model Class Initialized
DEBUG - 2018-02-10 20:33:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 20:33:23 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 20:33:23 --> Final output sent to browser
DEBUG - 2018-02-10 20:33:23 --> Total execution time: 0.0555
INFO - 2018-02-10 20:33:23 --> Config Class Initialized
INFO - 2018-02-10 20:33:23 --> Hooks Class Initialized
INFO - 2018-02-10 20:33:23 --> Config Class Initialized
INFO - 2018-02-10 20:33:23 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:33:23 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:33:23 --> Utf8 Class Initialized
DEBUG - 2018-02-10 20:33:23 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:33:23 --> Utf8 Class Initialized
INFO - 2018-02-10 20:33:23 --> URI Class Initialized
INFO - 2018-02-10 20:33:23 --> URI Class Initialized
INFO - 2018-02-10 20:33:23 --> Router Class Initialized
INFO - 2018-02-10 20:33:23 --> Router Class Initialized
INFO - 2018-02-10 20:33:23 --> Output Class Initialized
INFO - 2018-02-10 20:33:23 --> Output Class Initialized
INFO - 2018-02-10 20:33:23 --> Security Class Initialized
INFO - 2018-02-10 20:33:23 --> Security Class Initialized
DEBUG - 2018-02-10 20:33:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:33:23 --> Input Class Initialized
DEBUG - 2018-02-10 20:33:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:33:23 --> Input Class Initialized
INFO - 2018-02-10 20:33:23 --> Language Class Initialized
INFO - 2018-02-10 20:33:23 --> Language Class Initialized
INFO - 2018-02-10 20:33:23 --> Loader Class Initialized
INFO - 2018-02-10 20:33:23 --> Loader Class Initialized
INFO - 2018-02-10 20:33:23 --> Helper loaded: url_helper
INFO - 2018-02-10 20:33:23 --> Helper loaded: url_helper
INFO - 2018-02-10 20:33:23 --> Helper loaded: form_helper
INFO - 2018-02-10 20:33:23 --> Helper loaded: form_helper
INFO - 2018-02-10 20:33:23 --> Database Driver Class Initialized
INFO - 2018-02-10 20:33:23 --> Database Driver Class Initialized
DEBUG - 2018-02-10 20:33:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:33:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-02-10 20:33:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:33:23 --> Form Validation Class Initialized
INFO - 2018-02-10 20:33:23 --> Model Class Initialized
INFO - 2018-02-10 20:33:23 --> Controller Class Initialized
INFO - 2018-02-10 20:33:23 --> Model Class Initialized
INFO - 2018-02-10 20:33:23 --> Model Class Initialized
INFO - 2018-02-10 20:33:23 --> Model Class Initialized
INFO - 2018-02-10 20:33:23 --> Model Class Initialized
INFO - 2018-02-10 20:33:23 --> Model Class Initialized
DEBUG - 2018-02-10 20:33:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 20:33:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 20:33:23 --> Form Validation Class Initialized
INFO - 2018-02-10 20:33:23 --> Model Class Initialized
INFO - 2018-02-10 20:33:23 --> Controller Class Initialized
INFO - 2018-02-10 20:33:23 --> Model Class Initialized
INFO - 2018-02-10 20:33:23 --> Model Class Initialized
INFO - 2018-02-10 20:33:23 --> Model Class Initialized
INFO - 2018-02-10 20:33:23 --> Model Class Initialized
INFO - 2018-02-10 20:33:23 --> Model Class Initialized
DEBUG - 2018-02-10 20:33:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 20:33:31 --> Config Class Initialized
INFO - 2018-02-10 20:33:31 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:33:31 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:33:31 --> Utf8 Class Initialized
INFO - 2018-02-10 20:33:31 --> URI Class Initialized
DEBUG - 2018-02-10 20:33:31 --> No URI present. Default controller set.
INFO - 2018-02-10 20:33:31 --> Router Class Initialized
INFO - 2018-02-10 20:33:31 --> Output Class Initialized
INFO - 2018-02-10 20:33:32 --> Security Class Initialized
DEBUG - 2018-02-10 20:33:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:33:32 --> Input Class Initialized
INFO - 2018-02-10 20:33:32 --> Language Class Initialized
INFO - 2018-02-10 20:33:32 --> Loader Class Initialized
INFO - 2018-02-10 20:33:32 --> Helper loaded: url_helper
INFO - 2018-02-10 20:33:32 --> Helper loaded: form_helper
INFO - 2018-02-10 20:33:32 --> Database Driver Class Initialized
DEBUG - 2018-02-10 20:33:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:33:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 20:33:32 --> Form Validation Class Initialized
INFO - 2018-02-10 20:33:32 --> Model Class Initialized
INFO - 2018-02-10 20:33:32 --> Controller Class Initialized
INFO - 2018-02-10 20:33:32 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 20:33:32 --> Final output sent to browser
DEBUG - 2018-02-10 20:33:32 --> Total execution time: 0.0563
INFO - 2018-02-10 20:33:32 --> Config Class Initialized
INFO - 2018-02-10 20:33:32 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:33:32 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:33:32 --> Utf8 Class Initialized
INFO - 2018-02-10 20:33:32 --> URI Class Initialized
INFO - 2018-02-10 20:33:32 --> Router Class Initialized
INFO - 2018-02-10 20:33:32 --> Output Class Initialized
INFO - 2018-02-10 20:33:32 --> Security Class Initialized
DEBUG - 2018-02-10 20:33:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:33:32 --> Input Class Initialized
INFO - 2018-02-10 20:33:32 --> Language Class Initialized
INFO - 2018-02-10 20:33:32 --> Loader Class Initialized
INFO - 2018-02-10 20:33:32 --> Helper loaded: url_helper
INFO - 2018-02-10 20:33:32 --> Helper loaded: form_helper
INFO - 2018-02-10 20:33:32 --> Database Driver Class Initialized
DEBUG - 2018-02-10 20:33:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:33:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 20:33:32 --> Form Validation Class Initialized
INFO - 2018-02-10 20:33:32 --> Model Class Initialized
INFO - 2018-02-10 20:33:32 --> Controller Class Initialized
INFO - 2018-02-10 20:33:32 --> Model Class Initialized
INFO - 2018-02-10 20:33:32 --> Model Class Initialized
INFO - 2018-02-10 20:33:32 --> Model Class Initialized
INFO - 2018-02-10 20:33:32 --> Model Class Initialized
INFO - 2018-02-10 20:33:32 --> Model Class Initialized
DEBUG - 2018-02-10 20:33:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 20:33:35 --> Config Class Initialized
INFO - 2018-02-10 20:33:35 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:33:35 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:33:35 --> Utf8 Class Initialized
INFO - 2018-02-10 20:33:35 --> URI Class Initialized
INFO - 2018-02-10 20:33:35 --> Router Class Initialized
INFO - 2018-02-10 20:33:35 --> Output Class Initialized
INFO - 2018-02-10 20:33:35 --> Security Class Initialized
DEBUG - 2018-02-10 20:33:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:33:35 --> Input Class Initialized
INFO - 2018-02-10 20:33:35 --> Language Class Initialized
INFO - 2018-02-10 20:33:35 --> Loader Class Initialized
INFO - 2018-02-10 20:33:35 --> Helper loaded: url_helper
INFO - 2018-02-10 20:33:35 --> Helper loaded: form_helper
INFO - 2018-02-10 20:33:35 --> Database Driver Class Initialized
DEBUG - 2018-02-10 20:33:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:33:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 20:33:35 --> Form Validation Class Initialized
INFO - 2018-02-10 20:33:35 --> Model Class Initialized
INFO - 2018-02-10 20:33:35 --> Controller Class Initialized
INFO - 2018-02-10 20:33:35 --> Model Class Initialized
INFO - 2018-02-10 20:33:35 --> Model Class Initialized
INFO - 2018-02-10 20:33:35 --> Model Class Initialized
INFO - 2018-02-10 20:33:35 --> Model Class Initialized
INFO - 2018-02-10 20:33:35 --> Model Class Initialized
DEBUG - 2018-02-10 20:33:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 20:33:35 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 20:33:35 --> Final output sent to browser
DEBUG - 2018-02-10 20:33:35 --> Total execution time: 0.0690
INFO - 2018-02-10 20:33:35 --> Config Class Initialized
INFO - 2018-02-10 20:33:35 --> Hooks Class Initialized
INFO - 2018-02-10 20:33:35 --> Config Class Initialized
INFO - 2018-02-10 20:33:35 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:33:35 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:33:35 --> Utf8 Class Initialized
INFO - 2018-02-10 20:33:35 --> URI Class Initialized
DEBUG - 2018-02-10 20:33:35 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:33:35 --> Utf8 Class Initialized
INFO - 2018-02-10 20:33:35 --> Router Class Initialized
INFO - 2018-02-10 20:33:35 --> URI Class Initialized
INFO - 2018-02-10 20:33:35 --> Output Class Initialized
INFO - 2018-02-10 20:33:35 --> Router Class Initialized
INFO - 2018-02-10 20:33:35 --> Security Class Initialized
INFO - 2018-02-10 20:33:35 --> Output Class Initialized
DEBUG - 2018-02-10 20:33:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:33:35 --> Input Class Initialized
INFO - 2018-02-10 20:33:35 --> Language Class Initialized
INFO - 2018-02-10 20:33:35 --> Security Class Initialized
DEBUG - 2018-02-10 20:33:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:33:35 --> Input Class Initialized
INFO - 2018-02-10 20:33:35 --> Loader Class Initialized
INFO - 2018-02-10 20:33:35 --> Language Class Initialized
INFO - 2018-02-10 20:33:35 --> Helper loaded: url_helper
INFO - 2018-02-10 20:33:35 --> Helper loaded: form_helper
INFO - 2018-02-10 20:33:35 --> Loader Class Initialized
INFO - 2018-02-10 20:33:35 --> Helper loaded: url_helper
INFO - 2018-02-10 20:33:35 --> Helper loaded: form_helper
INFO - 2018-02-10 20:33:35 --> Database Driver Class Initialized
INFO - 2018-02-10 20:33:35 --> Database Driver Class Initialized
DEBUG - 2018-02-10 20:33:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:33:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 20:33:35 --> Form Validation Class Initialized
INFO - 2018-02-10 20:33:35 --> Model Class Initialized
INFO - 2018-02-10 20:33:35 --> Controller Class Initialized
DEBUG - 2018-02-10 20:33:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:33:35 --> Model Class Initialized
INFO - 2018-02-10 20:33:35 --> Model Class Initialized
INFO - 2018-02-10 20:33:35 --> Model Class Initialized
INFO - 2018-02-10 20:33:35 --> Model Class Initialized
INFO - 2018-02-10 20:33:35 --> Model Class Initialized
DEBUG - 2018-02-10 20:33:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 20:33:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 20:33:35 --> Form Validation Class Initialized
INFO - 2018-02-10 20:33:35 --> Model Class Initialized
INFO - 2018-02-10 20:33:35 --> Controller Class Initialized
INFO - 2018-02-10 20:33:35 --> Model Class Initialized
INFO - 2018-02-10 20:33:35 --> Model Class Initialized
INFO - 2018-02-10 20:33:35 --> Model Class Initialized
INFO - 2018-02-10 20:33:35 --> Model Class Initialized
INFO - 2018-02-10 20:33:35 --> Model Class Initialized
DEBUG - 2018-02-10 20:33:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 20:33:37 --> Config Class Initialized
INFO - 2018-02-10 20:33:37 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:33:37 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:33:37 --> Utf8 Class Initialized
INFO - 2018-02-10 20:33:37 --> URI Class Initialized
DEBUG - 2018-02-10 20:33:37 --> No URI present. Default controller set.
INFO - 2018-02-10 20:33:37 --> Router Class Initialized
INFO - 2018-02-10 20:33:37 --> Output Class Initialized
INFO - 2018-02-10 20:33:37 --> Security Class Initialized
DEBUG - 2018-02-10 20:33:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:33:37 --> Input Class Initialized
INFO - 2018-02-10 20:33:37 --> Language Class Initialized
INFO - 2018-02-10 20:33:37 --> Loader Class Initialized
INFO - 2018-02-10 20:33:37 --> Helper loaded: url_helper
INFO - 2018-02-10 20:33:37 --> Helper loaded: form_helper
INFO - 2018-02-10 20:33:37 --> Database Driver Class Initialized
DEBUG - 2018-02-10 20:33:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:33:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 20:33:37 --> Form Validation Class Initialized
INFO - 2018-02-10 20:33:37 --> Model Class Initialized
INFO - 2018-02-10 20:33:37 --> Controller Class Initialized
INFO - 2018-02-10 20:33:37 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 20:33:37 --> Final output sent to browser
DEBUG - 2018-02-10 20:33:37 --> Total execution time: 0.0529
INFO - 2018-02-10 20:33:37 --> Config Class Initialized
INFO - 2018-02-10 20:33:37 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:33:37 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:33:37 --> Utf8 Class Initialized
INFO - 2018-02-10 20:33:37 --> URI Class Initialized
INFO - 2018-02-10 20:33:37 --> Router Class Initialized
INFO - 2018-02-10 20:33:37 --> Output Class Initialized
INFO - 2018-02-10 20:33:37 --> Security Class Initialized
DEBUG - 2018-02-10 20:33:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:33:37 --> Input Class Initialized
INFO - 2018-02-10 20:33:37 --> Language Class Initialized
INFO - 2018-02-10 20:33:37 --> Loader Class Initialized
INFO - 2018-02-10 20:33:37 --> Helper loaded: url_helper
INFO - 2018-02-10 20:33:37 --> Helper loaded: form_helper
INFO - 2018-02-10 20:33:37 --> Database Driver Class Initialized
DEBUG - 2018-02-10 20:33:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:33:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 20:33:37 --> Form Validation Class Initialized
INFO - 2018-02-10 20:33:37 --> Model Class Initialized
INFO - 2018-02-10 20:33:37 --> Controller Class Initialized
INFO - 2018-02-10 20:33:37 --> Model Class Initialized
INFO - 2018-02-10 20:33:37 --> Model Class Initialized
INFO - 2018-02-10 20:33:37 --> Model Class Initialized
INFO - 2018-02-10 20:33:37 --> Model Class Initialized
INFO - 2018-02-10 20:33:37 --> Model Class Initialized
DEBUG - 2018-02-10 20:33:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 20:33:39 --> Config Class Initialized
INFO - 2018-02-10 20:33:39 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:33:39 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:33:39 --> Utf8 Class Initialized
INFO - 2018-02-10 20:33:39 --> URI Class Initialized
INFO - 2018-02-10 20:33:39 --> Router Class Initialized
INFO - 2018-02-10 20:33:39 --> Output Class Initialized
INFO - 2018-02-10 20:33:39 --> Security Class Initialized
DEBUG - 2018-02-10 20:33:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:33:39 --> Input Class Initialized
INFO - 2018-02-10 20:33:39 --> Language Class Initialized
INFO - 2018-02-10 20:33:39 --> Loader Class Initialized
INFO - 2018-02-10 20:33:39 --> Helper loaded: url_helper
INFO - 2018-02-10 20:33:39 --> Helper loaded: form_helper
INFO - 2018-02-10 20:33:39 --> Database Driver Class Initialized
DEBUG - 2018-02-10 20:33:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:33:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 20:33:39 --> Form Validation Class Initialized
INFO - 2018-02-10 20:33:39 --> Model Class Initialized
INFO - 2018-02-10 20:33:39 --> Controller Class Initialized
INFO - 2018-02-10 20:33:39 --> Model Class Initialized
INFO - 2018-02-10 20:33:39 --> Model Class Initialized
INFO - 2018-02-10 20:33:39 --> Model Class Initialized
INFO - 2018-02-10 20:33:39 --> Model Class Initialized
INFO - 2018-02-10 20:33:39 --> Model Class Initialized
DEBUG - 2018-02-10 20:33:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 20:33:39 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 20:33:39 --> Final output sent to browser
DEBUG - 2018-02-10 20:33:39 --> Total execution time: 0.0506
INFO - 2018-02-10 20:33:39 --> Config Class Initialized
INFO - 2018-02-10 20:33:39 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:33:39 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:33:39 --> Utf8 Class Initialized
INFO - 2018-02-10 20:33:39 --> URI Class Initialized
INFO - 2018-02-10 20:33:39 --> Router Class Initialized
INFO - 2018-02-10 20:33:39 --> Output Class Initialized
INFO - 2018-02-10 20:33:39 --> Security Class Initialized
DEBUG - 2018-02-10 20:33:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:33:39 --> Input Class Initialized
INFO - 2018-02-10 20:33:39 --> Language Class Initialized
INFO - 2018-02-10 20:33:39 --> Loader Class Initialized
INFO - 2018-02-10 20:33:39 --> Helper loaded: url_helper
INFO - 2018-02-10 20:33:39 --> Helper loaded: form_helper
INFO - 2018-02-10 20:33:39 --> Database Driver Class Initialized
DEBUG - 2018-02-10 20:33:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:33:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 20:33:39 --> Form Validation Class Initialized
INFO - 2018-02-10 20:33:39 --> Model Class Initialized
INFO - 2018-02-10 20:33:39 --> Controller Class Initialized
INFO - 2018-02-10 20:33:39 --> Model Class Initialized
INFO - 2018-02-10 20:33:39 --> Model Class Initialized
INFO - 2018-02-10 20:33:39 --> Model Class Initialized
INFO - 2018-02-10 20:33:39 --> Model Class Initialized
INFO - 2018-02-10 20:33:39 --> Model Class Initialized
DEBUG - 2018-02-10 20:33:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 20:33:42 --> Config Class Initialized
INFO - 2018-02-10 20:33:42 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:33:42 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:33:42 --> Utf8 Class Initialized
INFO - 2018-02-10 20:33:42 --> URI Class Initialized
INFO - 2018-02-10 20:33:42 --> Router Class Initialized
INFO - 2018-02-10 20:33:42 --> Output Class Initialized
INFO - 2018-02-10 20:33:42 --> Security Class Initialized
DEBUG - 2018-02-10 20:33:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:33:42 --> Input Class Initialized
INFO - 2018-02-10 20:33:42 --> Language Class Initialized
INFO - 2018-02-10 20:33:42 --> Loader Class Initialized
INFO - 2018-02-10 20:33:42 --> Helper loaded: url_helper
INFO - 2018-02-10 20:33:42 --> Helper loaded: form_helper
INFO - 2018-02-10 20:33:42 --> Database Driver Class Initialized
DEBUG - 2018-02-10 20:33:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:33:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 20:33:42 --> Form Validation Class Initialized
INFO - 2018-02-10 20:33:42 --> Model Class Initialized
INFO - 2018-02-10 20:33:42 --> Controller Class Initialized
INFO - 2018-02-10 20:33:42 --> Model Class Initialized
INFO - 2018-02-10 20:33:42 --> Model Class Initialized
INFO - 2018-02-10 20:33:42 --> Model Class Initialized
INFO - 2018-02-10 20:33:42 --> Model Class Initialized
INFO - 2018-02-10 20:33:42 --> Model Class Initialized
DEBUG - 2018-02-10 20:33:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 20:33:42 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 20:33:42 --> Final output sent to browser
DEBUG - 2018-02-10 20:33:42 --> Total execution time: 0.0540
INFO - 2018-02-10 20:33:42 --> Config Class Initialized
INFO - 2018-02-10 20:33:42 --> Hooks Class Initialized
INFO - 2018-02-10 20:33:42 --> Config Class Initialized
INFO - 2018-02-10 20:33:42 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:33:42 --> UTF-8 Support Enabled
DEBUG - 2018-02-10 20:33:42 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:33:42 --> Utf8 Class Initialized
INFO - 2018-02-10 20:33:42 --> Utf8 Class Initialized
INFO - 2018-02-10 20:33:42 --> URI Class Initialized
INFO - 2018-02-10 20:33:42 --> URI Class Initialized
INFO - 2018-02-10 20:33:42 --> Router Class Initialized
INFO - 2018-02-10 20:33:42 --> Router Class Initialized
INFO - 2018-02-10 20:33:42 --> Output Class Initialized
INFO - 2018-02-10 20:33:42 --> Security Class Initialized
INFO - 2018-02-10 20:33:42 --> Output Class Initialized
INFO - 2018-02-10 20:33:42 --> Security Class Initialized
DEBUG - 2018-02-10 20:33:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:33:42 --> Input Class Initialized
INFO - 2018-02-10 20:33:42 --> Language Class Initialized
DEBUG - 2018-02-10 20:33:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:33:42 --> Input Class Initialized
INFO - 2018-02-10 20:33:42 --> Language Class Initialized
INFO - 2018-02-10 20:33:42 --> Loader Class Initialized
INFO - 2018-02-10 20:33:42 --> Helper loaded: url_helper
INFO - 2018-02-10 20:33:42 --> Loader Class Initialized
INFO - 2018-02-10 20:33:42 --> Helper loaded: form_helper
INFO - 2018-02-10 20:33:42 --> Helper loaded: url_helper
INFO - 2018-02-10 20:33:42 --> Helper loaded: form_helper
INFO - 2018-02-10 20:33:42 --> Database Driver Class Initialized
INFO - 2018-02-10 20:33:42 --> Database Driver Class Initialized
DEBUG - 2018-02-10 20:33:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:33:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-02-10 20:33:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:33:42 --> Form Validation Class Initialized
INFO - 2018-02-10 20:33:42 --> Model Class Initialized
INFO - 2018-02-10 20:33:42 --> Controller Class Initialized
INFO - 2018-02-10 20:33:42 --> Model Class Initialized
INFO - 2018-02-10 20:33:42 --> Model Class Initialized
INFO - 2018-02-10 20:33:42 --> Model Class Initialized
INFO - 2018-02-10 20:33:42 --> Model Class Initialized
INFO - 2018-02-10 20:33:42 --> Model Class Initialized
DEBUG - 2018-02-10 20:33:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 20:33:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 20:33:42 --> Form Validation Class Initialized
INFO - 2018-02-10 20:33:42 --> Model Class Initialized
INFO - 2018-02-10 20:33:42 --> Controller Class Initialized
INFO - 2018-02-10 20:33:42 --> Model Class Initialized
INFO - 2018-02-10 20:33:42 --> Model Class Initialized
INFO - 2018-02-10 20:33:42 --> Model Class Initialized
INFO - 2018-02-10 20:33:42 --> Model Class Initialized
INFO - 2018-02-10 20:33:42 --> Model Class Initialized
DEBUG - 2018-02-10 20:33:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 20:33:48 --> Config Class Initialized
INFO - 2018-02-10 20:33:48 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:33:48 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:33:48 --> Utf8 Class Initialized
INFO - 2018-02-10 20:33:48 --> URI Class Initialized
INFO - 2018-02-10 20:33:48 --> Router Class Initialized
INFO - 2018-02-10 20:33:48 --> Output Class Initialized
INFO - 2018-02-10 20:33:48 --> Security Class Initialized
DEBUG - 2018-02-10 20:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:33:48 --> Input Class Initialized
INFO - 2018-02-10 20:33:48 --> Language Class Initialized
INFO - 2018-02-10 20:33:48 --> Loader Class Initialized
INFO - 2018-02-10 20:33:48 --> Helper loaded: url_helper
INFO - 2018-02-10 20:33:48 --> Helper loaded: form_helper
INFO - 2018-02-10 20:33:48 --> Database Driver Class Initialized
DEBUG - 2018-02-10 20:33:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:33:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 20:33:48 --> Form Validation Class Initialized
INFO - 2018-02-10 20:33:48 --> Model Class Initialized
INFO - 2018-02-10 20:33:48 --> Controller Class Initialized
INFO - 2018-02-10 20:33:48 --> Model Class Initialized
INFO - 2018-02-10 20:33:48 --> Model Class Initialized
INFO - 2018-02-10 20:33:48 --> Model Class Initialized
INFO - 2018-02-10 20:33:48 --> Model Class Initialized
INFO - 2018-02-10 20:33:48 --> Model Class Initialized
DEBUG - 2018-02-10 20:33:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 20:33:48 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 20:33:48 --> Final output sent to browser
DEBUG - 2018-02-10 20:33:48 --> Total execution time: 0.3167
INFO - 2018-02-10 20:33:49 --> Config Class Initialized
INFO - 2018-02-10 20:33:49 --> Hooks Class Initialized
INFO - 2018-02-10 20:33:49 --> Config Class Initialized
INFO - 2018-02-10 20:33:49 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:33:49 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:33:49 --> Utf8 Class Initialized
DEBUG - 2018-02-10 20:33:49 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:33:49 --> Utf8 Class Initialized
INFO - 2018-02-10 20:33:49 --> URI Class Initialized
INFO - 2018-02-10 20:33:49 --> URI Class Initialized
INFO - 2018-02-10 20:33:49 --> Router Class Initialized
INFO - 2018-02-10 20:33:49 --> Router Class Initialized
INFO - 2018-02-10 20:33:49 --> Output Class Initialized
INFO - 2018-02-10 20:33:49 --> Output Class Initialized
INFO - 2018-02-10 20:33:49 --> Security Class Initialized
DEBUG - 2018-02-10 20:33:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:33:49 --> Security Class Initialized
INFO - 2018-02-10 20:33:49 --> Input Class Initialized
INFO - 2018-02-10 20:33:49 --> Language Class Initialized
DEBUG - 2018-02-10 20:33:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:33:49 --> Input Class Initialized
INFO - 2018-02-10 20:33:49 --> Language Class Initialized
INFO - 2018-02-10 20:33:49 --> Loader Class Initialized
INFO - 2018-02-10 20:33:49 --> Loader Class Initialized
INFO - 2018-02-10 20:33:49 --> Helper loaded: url_helper
INFO - 2018-02-10 20:33:49 --> Helper loaded: url_helper
INFO - 2018-02-10 20:33:49 --> Helper loaded: form_helper
INFO - 2018-02-10 20:33:49 --> Helper loaded: form_helper
INFO - 2018-02-10 20:33:49 --> Database Driver Class Initialized
INFO - 2018-02-10 20:33:49 --> Database Driver Class Initialized
DEBUG - 2018-02-10 20:33:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:33:49 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-02-10 20:33:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:33:49 --> Form Validation Class Initialized
INFO - 2018-02-10 20:33:49 --> Model Class Initialized
INFO - 2018-02-10 20:33:49 --> Controller Class Initialized
INFO - 2018-02-10 20:33:49 --> Model Class Initialized
INFO - 2018-02-10 20:33:49 --> Model Class Initialized
INFO - 2018-02-10 20:33:49 --> Model Class Initialized
INFO - 2018-02-10 20:33:49 --> Model Class Initialized
INFO - 2018-02-10 20:33:49 --> Model Class Initialized
DEBUG - 2018-02-10 20:33:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 20:33:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 20:33:49 --> Form Validation Class Initialized
INFO - 2018-02-10 20:33:49 --> Model Class Initialized
INFO - 2018-02-10 20:33:49 --> Controller Class Initialized
INFO - 2018-02-10 20:33:49 --> Model Class Initialized
INFO - 2018-02-10 20:33:49 --> Model Class Initialized
INFO - 2018-02-10 20:33:49 --> Model Class Initialized
INFO - 2018-02-10 20:33:49 --> Model Class Initialized
INFO - 2018-02-10 20:33:49 --> Model Class Initialized
DEBUG - 2018-02-10 20:33:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 20:33:51 --> Config Class Initialized
INFO - 2018-02-10 20:33:51 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:33:51 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:33:51 --> Utf8 Class Initialized
INFO - 2018-02-10 20:33:51 --> URI Class Initialized
INFO - 2018-02-10 20:33:51 --> Router Class Initialized
INFO - 2018-02-10 20:33:51 --> Output Class Initialized
INFO - 2018-02-10 20:33:51 --> Security Class Initialized
DEBUG - 2018-02-10 20:33:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:33:51 --> Input Class Initialized
INFO - 2018-02-10 20:33:51 --> Language Class Initialized
INFO - 2018-02-10 20:33:51 --> Loader Class Initialized
INFO - 2018-02-10 20:33:51 --> Helper loaded: url_helper
INFO - 2018-02-10 20:33:51 --> Helper loaded: form_helper
INFO - 2018-02-10 20:33:51 --> Database Driver Class Initialized
DEBUG - 2018-02-10 20:33:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:33:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 20:33:51 --> Form Validation Class Initialized
INFO - 2018-02-10 20:33:51 --> Model Class Initialized
INFO - 2018-02-10 20:33:51 --> Controller Class Initialized
INFO - 2018-02-10 20:33:51 --> Model Class Initialized
INFO - 2018-02-10 20:33:51 --> Model Class Initialized
INFO - 2018-02-10 20:33:51 --> Model Class Initialized
INFO - 2018-02-10 20:33:51 --> Model Class Initialized
INFO - 2018-02-10 20:33:51 --> Model Class Initialized
DEBUG - 2018-02-10 20:33:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 20:33:51 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 20:33:51 --> Final output sent to browser
DEBUG - 2018-02-10 20:33:51 --> Total execution time: 0.0732
INFO - 2018-02-10 20:33:51 --> Config Class Initialized
INFO - 2018-02-10 20:33:51 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:33:51 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:33:51 --> Utf8 Class Initialized
INFO - 2018-02-10 20:33:51 --> URI Class Initialized
INFO - 2018-02-10 20:33:51 --> Router Class Initialized
INFO - 2018-02-10 20:33:51 --> Output Class Initialized
INFO - 2018-02-10 20:33:51 --> Security Class Initialized
DEBUG - 2018-02-10 20:33:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:33:51 --> Input Class Initialized
INFO - 2018-02-10 20:33:51 --> Language Class Initialized
INFO - 2018-02-10 20:33:51 --> Loader Class Initialized
INFO - 2018-02-10 20:33:51 --> Helper loaded: url_helper
INFO - 2018-02-10 20:33:51 --> Helper loaded: form_helper
INFO - 2018-02-10 20:33:51 --> Database Driver Class Initialized
DEBUG - 2018-02-10 20:33:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:33:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 20:33:51 --> Form Validation Class Initialized
INFO - 2018-02-10 20:33:51 --> Model Class Initialized
INFO - 2018-02-10 20:33:51 --> Controller Class Initialized
INFO - 2018-02-10 20:33:51 --> Model Class Initialized
INFO - 2018-02-10 20:33:51 --> Model Class Initialized
INFO - 2018-02-10 20:33:51 --> Model Class Initialized
INFO - 2018-02-10 20:33:51 --> Model Class Initialized
INFO - 2018-02-10 20:33:51 --> Model Class Initialized
DEBUG - 2018-02-10 20:33:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 20:37:46 --> Config Class Initialized
INFO - 2018-02-10 20:37:46 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:37:46 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:37:46 --> Utf8 Class Initialized
INFO - 2018-02-10 20:37:46 --> URI Class Initialized
INFO - 2018-02-10 20:37:46 --> Router Class Initialized
INFO - 2018-02-10 20:37:46 --> Output Class Initialized
INFO - 2018-02-10 20:37:46 --> Security Class Initialized
DEBUG - 2018-02-10 20:37:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:37:46 --> Input Class Initialized
INFO - 2018-02-10 20:37:46 --> Language Class Initialized
INFO - 2018-02-10 20:37:46 --> Loader Class Initialized
INFO - 2018-02-10 20:37:46 --> Helper loaded: url_helper
INFO - 2018-02-10 20:37:46 --> Helper loaded: form_helper
INFO - 2018-02-10 20:37:46 --> Database Driver Class Initialized
DEBUG - 2018-02-10 20:37:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:37:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 20:37:46 --> Form Validation Class Initialized
INFO - 2018-02-10 20:37:46 --> Model Class Initialized
INFO - 2018-02-10 20:37:46 --> Controller Class Initialized
INFO - 2018-02-10 20:37:46 --> Model Class Initialized
INFO - 2018-02-10 20:37:46 --> Model Class Initialized
INFO - 2018-02-10 20:37:46 --> Model Class Initialized
INFO - 2018-02-10 20:37:46 --> Model Class Initialized
INFO - 2018-02-10 20:37:46 --> Model Class Initialized
DEBUG - 2018-02-10 20:37:46 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-10 20:37:46 --> Severity: Notice --> Undefined property: Proyecto::$t_colaborador D:\xampp\htdocs\instateccr\controlcostos\instatec_sys\core\Model.php 77
ERROR - 2018-02-10 20:37:46 --> Severity: Notice --> Undefined property: Proyecto::$t_colaborador D:\xampp\htdocs\instateccr\controlcostos\instatec_sys\core\Model.php 77
ERROR - 2018-02-10 20:37:46 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ON .`colaborador_id` = `proyecto`.`jefe_proyecto_id`
WHERE `proyecto_id` = '2'' at line 8 - Invalid query: SELECT *
FROM `proyecto`
LEFT JOIN `proyecto_estado` ON `proyecto_estado`.`proyecto_estado_id` = `proyecto`.`proyecto_estado_id`
LEFT JOIN `cliente` ON `cliente`.`cliente_id` = `proyecto`.`cliente_id`
LEFT JOIN `distrito` ON `distrito`.`distrito_id` = `proyecto`.`distrito_id`
LEFT JOIN `canton` ON `canton`.`canton_id` = `distrito`.`canton_id`
LEFT JOIN `provincia` ON `provincia`.`provincia_id` = `canton`.`provincia_id`
LEFT JOIN  ON .`colaborador_id` = `proyecto`.`jefe_proyecto_id`
WHERE `proyecto_id` = '2'
INFO - 2018-02-10 20:37:46 --> Language file loaded: language/english/db_lang.php
INFO - 2018-02-10 20:38:04 --> Config Class Initialized
INFO - 2018-02-10 20:38:04 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:38:04 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:38:04 --> Utf8 Class Initialized
INFO - 2018-02-10 20:38:04 --> URI Class Initialized
INFO - 2018-02-10 20:38:04 --> Router Class Initialized
INFO - 2018-02-10 20:38:04 --> Output Class Initialized
INFO - 2018-02-10 20:38:04 --> Security Class Initialized
DEBUG - 2018-02-10 20:38:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:38:04 --> Input Class Initialized
INFO - 2018-02-10 20:38:04 --> Language Class Initialized
INFO - 2018-02-10 20:38:04 --> Loader Class Initialized
INFO - 2018-02-10 20:38:04 --> Helper loaded: url_helper
INFO - 2018-02-10 20:38:04 --> Helper loaded: form_helper
INFO - 2018-02-10 20:38:04 --> Database Driver Class Initialized
DEBUG - 2018-02-10 20:38:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:38:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 20:38:04 --> Form Validation Class Initialized
INFO - 2018-02-10 20:38:04 --> Model Class Initialized
INFO - 2018-02-10 20:38:04 --> Controller Class Initialized
INFO - 2018-02-10 20:38:04 --> Model Class Initialized
INFO - 2018-02-10 20:38:04 --> Model Class Initialized
INFO - 2018-02-10 20:38:04 --> Model Class Initialized
INFO - 2018-02-10 20:38:04 --> Model Class Initialized
INFO - 2018-02-10 20:38:04 --> Model Class Initialized
DEBUG - 2018-02-10 20:38:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 20:38:04 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 20:38:04 --> Final output sent to browser
DEBUG - 2018-02-10 20:38:04 --> Total execution time: 0.0774
INFO - 2018-02-10 20:38:04 --> Config Class Initialized
INFO - 2018-02-10 20:38:04 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:38:04 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:38:04 --> Utf8 Class Initialized
INFO - 2018-02-10 20:38:04 --> URI Class Initialized
INFO - 2018-02-10 20:38:04 --> Router Class Initialized
INFO - 2018-02-10 20:38:04 --> Output Class Initialized
INFO - 2018-02-10 20:38:04 --> Security Class Initialized
DEBUG - 2018-02-10 20:38:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:38:04 --> Input Class Initialized
INFO - 2018-02-10 20:38:04 --> Language Class Initialized
INFO - 2018-02-10 20:38:04 --> Loader Class Initialized
INFO - 2018-02-10 20:38:04 --> Helper loaded: url_helper
INFO - 2018-02-10 20:38:04 --> Helper loaded: form_helper
INFO - 2018-02-10 20:38:04 --> Database Driver Class Initialized
DEBUG - 2018-02-10 20:38:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:38:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 20:38:04 --> Form Validation Class Initialized
INFO - 2018-02-10 20:38:04 --> Model Class Initialized
INFO - 2018-02-10 20:38:04 --> Controller Class Initialized
INFO - 2018-02-10 20:38:04 --> Model Class Initialized
INFO - 2018-02-10 20:38:04 --> Model Class Initialized
INFO - 2018-02-10 20:38:04 --> Model Class Initialized
INFO - 2018-02-10 20:38:04 --> Model Class Initialized
INFO - 2018-02-10 20:38:04 --> Model Class Initialized
DEBUG - 2018-02-10 20:38:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 20:38:23 --> Config Class Initialized
INFO - 2018-02-10 20:38:23 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:38:23 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:38:23 --> Utf8 Class Initialized
INFO - 2018-02-10 20:38:23 --> URI Class Initialized
INFO - 2018-02-10 20:38:23 --> Router Class Initialized
INFO - 2018-02-10 20:38:23 --> Output Class Initialized
INFO - 2018-02-10 20:38:23 --> Security Class Initialized
DEBUG - 2018-02-10 20:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:38:23 --> Input Class Initialized
INFO - 2018-02-10 20:38:23 --> Language Class Initialized
INFO - 2018-02-10 20:38:23 --> Loader Class Initialized
INFO - 2018-02-10 20:38:23 --> Helper loaded: url_helper
INFO - 2018-02-10 20:38:23 --> Helper loaded: form_helper
INFO - 2018-02-10 20:38:23 --> Database Driver Class Initialized
DEBUG - 2018-02-10 20:38:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:38:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 20:38:23 --> Form Validation Class Initialized
INFO - 2018-02-10 20:38:23 --> Model Class Initialized
INFO - 2018-02-10 20:38:23 --> Controller Class Initialized
INFO - 2018-02-10 20:38:23 --> Model Class Initialized
INFO - 2018-02-10 20:38:23 --> Model Class Initialized
INFO - 2018-02-10 20:38:23 --> Model Class Initialized
INFO - 2018-02-10 20:38:23 --> Model Class Initialized
INFO - 2018-02-10 20:38:23 --> Model Class Initialized
DEBUG - 2018-02-10 20:38:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 20:38:23 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 20:38:23 --> Final output sent to browser
DEBUG - 2018-02-10 20:38:23 --> Total execution time: 0.0671
INFO - 2018-02-10 20:38:23 --> Config Class Initialized
INFO - 2018-02-10 20:38:23 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:38:23 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:38:23 --> Utf8 Class Initialized
INFO - 2018-02-10 20:38:23 --> URI Class Initialized
INFO - 2018-02-10 20:38:23 --> Router Class Initialized
INFO - 2018-02-10 20:38:23 --> Output Class Initialized
INFO - 2018-02-10 20:38:23 --> Security Class Initialized
DEBUG - 2018-02-10 20:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:38:23 --> Input Class Initialized
INFO - 2018-02-10 20:38:23 --> Language Class Initialized
INFO - 2018-02-10 20:38:23 --> Loader Class Initialized
INFO - 2018-02-10 20:38:23 --> Helper loaded: url_helper
INFO - 2018-02-10 20:38:23 --> Helper loaded: form_helper
INFO - 2018-02-10 20:38:23 --> Database Driver Class Initialized
DEBUG - 2018-02-10 20:38:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:38:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 20:38:23 --> Form Validation Class Initialized
INFO - 2018-02-10 20:38:23 --> Model Class Initialized
INFO - 2018-02-10 20:38:23 --> Controller Class Initialized
INFO - 2018-02-10 20:38:23 --> Model Class Initialized
INFO - 2018-02-10 20:38:23 --> Model Class Initialized
INFO - 2018-02-10 20:38:23 --> Model Class Initialized
INFO - 2018-02-10 20:38:23 --> Model Class Initialized
INFO - 2018-02-10 20:38:23 --> Model Class Initialized
DEBUG - 2018-02-10 20:38:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 20:38:26 --> Config Class Initialized
INFO - 2018-02-10 20:38:26 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:38:26 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:38:26 --> Utf8 Class Initialized
INFO - 2018-02-10 20:38:26 --> URI Class Initialized
INFO - 2018-02-10 20:38:26 --> Router Class Initialized
INFO - 2018-02-10 20:38:26 --> Output Class Initialized
INFO - 2018-02-10 20:38:26 --> Security Class Initialized
DEBUG - 2018-02-10 20:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:38:26 --> Input Class Initialized
INFO - 2018-02-10 20:38:26 --> Language Class Initialized
INFO - 2018-02-10 20:38:26 --> Loader Class Initialized
INFO - 2018-02-10 20:38:26 --> Helper loaded: url_helper
INFO - 2018-02-10 20:38:26 --> Helper loaded: form_helper
INFO - 2018-02-10 20:38:26 --> Database Driver Class Initialized
DEBUG - 2018-02-10 20:38:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:38:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 20:38:26 --> Form Validation Class Initialized
INFO - 2018-02-10 20:38:26 --> Model Class Initialized
INFO - 2018-02-10 20:38:26 --> Controller Class Initialized
INFO - 2018-02-10 20:38:26 --> Model Class Initialized
INFO - 2018-02-10 20:38:26 --> Model Class Initialized
INFO - 2018-02-10 20:38:26 --> Model Class Initialized
INFO - 2018-02-10 20:38:26 --> Model Class Initialized
INFO - 2018-02-10 20:38:26 --> Model Class Initialized
DEBUG - 2018-02-10 20:38:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 20:38:26 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 20:38:26 --> Final output sent to browser
DEBUG - 2018-02-10 20:38:26 --> Total execution time: 0.0659
INFO - 2018-02-10 20:38:26 --> Config Class Initialized
INFO - 2018-02-10 20:38:26 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:38:26 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:38:26 --> Utf8 Class Initialized
INFO - 2018-02-10 20:38:26 --> URI Class Initialized
INFO - 2018-02-10 20:38:26 --> Router Class Initialized
INFO - 2018-02-10 20:38:26 --> Output Class Initialized
INFO - 2018-02-10 20:38:26 --> Security Class Initialized
DEBUG - 2018-02-10 20:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:38:26 --> Input Class Initialized
INFO - 2018-02-10 20:38:26 --> Language Class Initialized
INFO - 2018-02-10 20:38:26 --> Loader Class Initialized
INFO - 2018-02-10 20:38:26 --> Helper loaded: url_helper
INFO - 2018-02-10 20:38:26 --> Helper loaded: form_helper
INFO - 2018-02-10 20:38:26 --> Database Driver Class Initialized
DEBUG - 2018-02-10 20:38:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:38:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 20:38:26 --> Form Validation Class Initialized
INFO - 2018-02-10 20:38:26 --> Model Class Initialized
INFO - 2018-02-10 20:38:26 --> Controller Class Initialized
INFO - 2018-02-10 20:38:26 --> Model Class Initialized
INFO - 2018-02-10 20:38:26 --> Model Class Initialized
INFO - 2018-02-10 20:38:26 --> Model Class Initialized
INFO - 2018-02-10 20:38:26 --> Model Class Initialized
INFO - 2018-02-10 20:38:26 --> Model Class Initialized
DEBUG - 2018-02-10 20:38:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 20:39:58 --> Config Class Initialized
INFO - 2018-02-10 20:39:58 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:39:58 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:39:58 --> Utf8 Class Initialized
INFO - 2018-02-10 20:39:58 --> URI Class Initialized
INFO - 2018-02-10 20:39:58 --> Router Class Initialized
INFO - 2018-02-10 20:39:58 --> Output Class Initialized
INFO - 2018-02-10 20:39:58 --> Security Class Initialized
DEBUG - 2018-02-10 20:39:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:39:58 --> Input Class Initialized
INFO - 2018-02-10 20:39:58 --> Language Class Initialized
INFO - 2018-02-10 20:39:58 --> Loader Class Initialized
INFO - 2018-02-10 20:39:58 --> Helper loaded: url_helper
INFO - 2018-02-10 20:39:58 --> Helper loaded: form_helper
INFO - 2018-02-10 20:39:58 --> Database Driver Class Initialized
DEBUG - 2018-02-10 20:39:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:39:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 20:39:58 --> Form Validation Class Initialized
INFO - 2018-02-10 20:39:58 --> Model Class Initialized
INFO - 2018-02-10 20:39:58 --> Controller Class Initialized
INFO - 2018-02-10 20:39:58 --> Model Class Initialized
INFO - 2018-02-10 20:39:58 --> Model Class Initialized
INFO - 2018-02-10 20:39:58 --> Model Class Initialized
INFO - 2018-02-10 20:39:58 --> Model Class Initialized
INFO - 2018-02-10 20:39:58 --> Model Class Initialized
DEBUG - 2018-02-10 20:39:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 20:39:58 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 20:39:58 --> Final output sent to browser
DEBUG - 2018-02-10 20:39:58 --> Total execution time: 0.1632
INFO - 2018-02-10 20:39:59 --> Config Class Initialized
INFO - 2018-02-10 20:39:59 --> Hooks Class Initialized
DEBUG - 2018-02-10 20:39:59 --> UTF-8 Support Enabled
INFO - 2018-02-10 20:39:59 --> Utf8 Class Initialized
INFO - 2018-02-10 20:39:59 --> URI Class Initialized
INFO - 2018-02-10 20:39:59 --> Router Class Initialized
INFO - 2018-02-10 20:39:59 --> Output Class Initialized
INFO - 2018-02-10 20:39:59 --> Security Class Initialized
DEBUG - 2018-02-10 20:39:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 20:39:59 --> Input Class Initialized
INFO - 2018-02-10 20:39:59 --> Language Class Initialized
INFO - 2018-02-10 20:39:59 --> Loader Class Initialized
INFO - 2018-02-10 20:39:59 --> Helper loaded: url_helper
INFO - 2018-02-10 20:39:59 --> Helper loaded: form_helper
INFO - 2018-02-10 20:39:59 --> Database Driver Class Initialized
DEBUG - 2018-02-10 20:39:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 20:39:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 20:39:59 --> Form Validation Class Initialized
INFO - 2018-02-10 20:39:59 --> Model Class Initialized
INFO - 2018-02-10 20:39:59 --> Controller Class Initialized
INFO - 2018-02-10 20:39:59 --> Model Class Initialized
INFO - 2018-02-10 20:39:59 --> Model Class Initialized
INFO - 2018-02-10 20:39:59 --> Model Class Initialized
INFO - 2018-02-10 20:39:59 --> Model Class Initialized
INFO - 2018-02-10 20:39:59 --> Model Class Initialized
DEBUG - 2018-02-10 20:39:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 21:14:44 --> Config Class Initialized
INFO - 2018-02-10 21:14:44 --> Hooks Class Initialized
DEBUG - 2018-02-10 21:14:44 --> UTF-8 Support Enabled
INFO - 2018-02-10 21:14:44 --> Utf8 Class Initialized
INFO - 2018-02-10 21:14:44 --> URI Class Initialized
INFO - 2018-02-10 21:14:44 --> Router Class Initialized
INFO - 2018-02-10 21:14:44 --> Output Class Initialized
INFO - 2018-02-10 21:14:44 --> Security Class Initialized
DEBUG - 2018-02-10 21:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 21:14:44 --> Input Class Initialized
INFO - 2018-02-10 21:14:44 --> Language Class Initialized
ERROR - 2018-02-10 21:14:44 --> 404 Page Not Found: Proyectos/colaboradores
INFO - 2018-02-10 21:14:44 --> Config Class Initialized
INFO - 2018-02-10 21:14:44 --> Hooks Class Initialized
DEBUG - 2018-02-10 21:14:44 --> UTF-8 Support Enabled
INFO - 2018-02-10 21:14:44 --> Utf8 Class Initialized
INFO - 2018-02-10 21:14:44 --> URI Class Initialized
INFO - 2018-02-10 21:14:44 --> Router Class Initialized
INFO - 2018-02-10 21:14:44 --> Output Class Initialized
INFO - 2018-02-10 21:14:44 --> Security Class Initialized
DEBUG - 2018-02-10 21:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 21:14:44 --> Input Class Initialized
INFO - 2018-02-10 21:14:44 --> Language Class Initialized
INFO - 2018-02-10 21:14:44 --> Loader Class Initialized
INFO - 2018-02-10 21:14:44 --> Helper loaded: url_helper
INFO - 2018-02-10 21:14:44 --> Helper loaded: form_helper
INFO - 2018-02-10 21:14:44 --> Database Driver Class Initialized
DEBUG - 2018-02-10 21:14:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 21:14:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 21:14:44 --> Form Validation Class Initialized
INFO - 2018-02-10 21:14:44 --> Model Class Initialized
INFO - 2018-02-10 21:14:44 --> Controller Class Initialized
INFO - 2018-02-10 21:14:44 --> Model Class Initialized
INFO - 2018-02-10 21:14:44 --> Model Class Initialized
INFO - 2018-02-10 21:14:44 --> Model Class Initialized
INFO - 2018-02-10 21:14:44 --> Model Class Initialized
INFO - 2018-02-10 21:14:44 --> Model Class Initialized
DEBUG - 2018-02-10 21:14:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 21:14:44 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 21:14:44 --> Final output sent to browser
DEBUG - 2018-02-10 21:14:44 --> Total execution time: 0.0498
INFO - 2018-02-10 21:14:44 --> Config Class Initialized
INFO - 2018-02-10 21:14:44 --> Hooks Class Initialized
DEBUG - 2018-02-10 21:14:44 --> UTF-8 Support Enabled
INFO - 2018-02-10 21:14:44 --> Utf8 Class Initialized
INFO - 2018-02-10 21:14:44 --> URI Class Initialized
INFO - 2018-02-10 21:14:44 --> Router Class Initialized
INFO - 2018-02-10 21:14:44 --> Output Class Initialized
INFO - 2018-02-10 21:14:44 --> Security Class Initialized
DEBUG - 2018-02-10 21:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 21:14:44 --> Input Class Initialized
INFO - 2018-02-10 21:14:44 --> Language Class Initialized
INFO - 2018-02-10 21:14:44 --> Loader Class Initialized
INFO - 2018-02-10 21:14:44 --> Helper loaded: url_helper
INFO - 2018-02-10 21:14:44 --> Helper loaded: form_helper
INFO - 2018-02-10 21:14:44 --> Database Driver Class Initialized
DEBUG - 2018-02-10 21:14:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 21:14:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 21:14:44 --> Form Validation Class Initialized
INFO - 2018-02-10 21:14:44 --> Model Class Initialized
INFO - 2018-02-10 21:14:44 --> Controller Class Initialized
INFO - 2018-02-10 21:14:44 --> Model Class Initialized
INFO - 2018-02-10 21:14:45 --> Model Class Initialized
INFO - 2018-02-10 21:14:45 --> Model Class Initialized
INFO - 2018-02-10 21:14:45 --> Model Class Initialized
INFO - 2018-02-10 21:14:45 --> Model Class Initialized
DEBUG - 2018-02-10 21:14:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 21:14:46 --> Config Class Initialized
INFO - 2018-02-10 21:14:46 --> Hooks Class Initialized
DEBUG - 2018-02-10 21:14:46 --> UTF-8 Support Enabled
INFO - 2018-02-10 21:14:46 --> Utf8 Class Initialized
INFO - 2018-02-10 21:14:46 --> URI Class Initialized
INFO - 2018-02-10 21:14:46 --> Router Class Initialized
INFO - 2018-02-10 21:14:46 --> Output Class Initialized
INFO - 2018-02-10 21:14:46 --> Security Class Initialized
DEBUG - 2018-02-10 21:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 21:14:46 --> Input Class Initialized
INFO - 2018-02-10 21:14:46 --> Language Class Initialized
ERROR - 2018-02-10 21:14:46 --> 404 Page Not Found: Proyectos/colaboradores
INFO - 2018-02-10 21:14:47 --> Config Class Initialized
INFO - 2018-02-10 21:14:47 --> Hooks Class Initialized
DEBUG - 2018-02-10 21:14:47 --> UTF-8 Support Enabled
INFO - 2018-02-10 21:14:47 --> Utf8 Class Initialized
INFO - 2018-02-10 21:14:47 --> URI Class Initialized
INFO - 2018-02-10 21:14:47 --> Router Class Initialized
INFO - 2018-02-10 21:14:47 --> Output Class Initialized
INFO - 2018-02-10 21:14:47 --> Security Class Initialized
DEBUG - 2018-02-10 21:14:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 21:14:47 --> Input Class Initialized
INFO - 2018-02-10 21:14:47 --> Language Class Initialized
INFO - 2018-02-10 21:14:47 --> Loader Class Initialized
INFO - 2018-02-10 21:14:47 --> Helper loaded: url_helper
INFO - 2018-02-10 21:14:47 --> Helper loaded: form_helper
INFO - 2018-02-10 21:14:47 --> Database Driver Class Initialized
DEBUG - 2018-02-10 21:14:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 21:14:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 21:14:47 --> Form Validation Class Initialized
INFO - 2018-02-10 21:14:47 --> Model Class Initialized
INFO - 2018-02-10 21:14:47 --> Controller Class Initialized
INFO - 2018-02-10 21:14:47 --> Model Class Initialized
INFO - 2018-02-10 21:14:47 --> Model Class Initialized
INFO - 2018-02-10 21:14:47 --> Model Class Initialized
INFO - 2018-02-10 21:14:47 --> Model Class Initialized
INFO - 2018-02-10 21:14:47 --> Model Class Initialized
DEBUG - 2018-02-10 21:14:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-10 21:14:47 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-10 21:14:47 --> Final output sent to browser
DEBUG - 2018-02-10 21:14:47 --> Total execution time: 0.0604
INFO - 2018-02-10 21:14:47 --> Config Class Initialized
INFO - 2018-02-10 21:14:47 --> Hooks Class Initialized
DEBUG - 2018-02-10 21:14:47 --> UTF-8 Support Enabled
INFO - 2018-02-10 21:14:47 --> Utf8 Class Initialized
INFO - 2018-02-10 21:14:47 --> URI Class Initialized
INFO - 2018-02-10 21:14:47 --> Router Class Initialized
INFO - 2018-02-10 21:14:47 --> Output Class Initialized
INFO - 2018-02-10 21:14:47 --> Security Class Initialized
DEBUG - 2018-02-10 21:14:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-10 21:14:47 --> Input Class Initialized
INFO - 2018-02-10 21:14:47 --> Language Class Initialized
INFO - 2018-02-10 21:14:47 --> Loader Class Initialized
INFO - 2018-02-10 21:14:47 --> Helper loaded: url_helper
INFO - 2018-02-10 21:14:47 --> Helper loaded: form_helper
INFO - 2018-02-10 21:14:47 --> Database Driver Class Initialized
DEBUG - 2018-02-10 21:14:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-10 21:14:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-10 21:14:47 --> Form Validation Class Initialized
INFO - 2018-02-10 21:14:47 --> Model Class Initialized
INFO - 2018-02-10 21:14:47 --> Controller Class Initialized
INFO - 2018-02-10 21:14:47 --> Model Class Initialized
INFO - 2018-02-10 21:14:47 --> Model Class Initialized
INFO - 2018-02-10 21:14:47 --> Model Class Initialized
INFO - 2018-02-10 21:14:47 --> Model Class Initialized
INFO - 2018-02-10 21:14:47 --> Model Class Initialized
DEBUG - 2018-02-10 21:14:47 --> Form_validation class already loaded. Second attempt ignored.
