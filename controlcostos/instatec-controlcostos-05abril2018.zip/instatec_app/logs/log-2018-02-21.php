<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-02-21 00:01:22 --> Config Class Initialized
INFO - 2018-02-21 00:01:22 --> Hooks Class Initialized
DEBUG - 2018-02-21 00:01:22 --> UTF-8 Support Enabled
INFO - 2018-02-21 00:01:22 --> Utf8 Class Initialized
INFO - 2018-02-21 00:01:22 --> URI Class Initialized
INFO - 2018-02-21 00:01:22 --> Router Class Initialized
INFO - 2018-02-21 00:01:22 --> Output Class Initialized
INFO - 2018-02-21 00:01:22 --> Security Class Initialized
DEBUG - 2018-02-21 00:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 00:01:22 --> Input Class Initialized
INFO - 2018-02-21 00:01:22 --> Language Class Initialized
INFO - 2018-02-21 00:01:22 --> Loader Class Initialized
INFO - 2018-02-21 00:01:22 --> Helper loaded: url_helper
INFO - 2018-02-21 00:01:22 --> Helper loaded: form_helper
INFO - 2018-02-21 00:01:22 --> Database Driver Class Initialized
DEBUG - 2018-02-21 00:01:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 00:01:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 00:01:22 --> Form Validation Class Initialized
INFO - 2018-02-21 00:01:22 --> Model Class Initialized
INFO - 2018-02-21 00:01:22 --> Controller Class Initialized
INFO - 2018-02-21 00:01:22 --> Model Class Initialized
INFO - 2018-02-21 00:01:22 --> Model Class Initialized
INFO - 2018-02-21 00:01:22 --> Model Class Initialized
INFO - 2018-02-21 00:01:22 --> Model Class Initialized
INFO - 2018-02-21 00:01:22 --> Model Class Initialized
DEBUG - 2018-02-21 00:01:22 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-21 00:01:22 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\proyecto\verProyecto.php 300
INFO - 2018-02-21 00:02:10 --> Config Class Initialized
INFO - 2018-02-21 00:02:10 --> Hooks Class Initialized
DEBUG - 2018-02-21 00:02:10 --> UTF-8 Support Enabled
INFO - 2018-02-21 00:02:10 --> Utf8 Class Initialized
INFO - 2018-02-21 00:02:10 --> URI Class Initialized
INFO - 2018-02-21 00:02:10 --> Router Class Initialized
INFO - 2018-02-21 00:02:10 --> Output Class Initialized
INFO - 2018-02-21 00:02:10 --> Security Class Initialized
DEBUG - 2018-02-21 00:02:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 00:02:10 --> Input Class Initialized
INFO - 2018-02-21 00:02:10 --> Language Class Initialized
INFO - 2018-02-21 00:02:10 --> Loader Class Initialized
INFO - 2018-02-21 00:02:10 --> Helper loaded: url_helper
INFO - 2018-02-21 00:02:10 --> Helper loaded: form_helper
INFO - 2018-02-21 00:02:10 --> Database Driver Class Initialized
DEBUG - 2018-02-21 00:02:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 00:02:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 00:02:10 --> Form Validation Class Initialized
INFO - 2018-02-21 00:02:10 --> Model Class Initialized
INFO - 2018-02-21 00:02:10 --> Controller Class Initialized
INFO - 2018-02-21 00:02:10 --> Model Class Initialized
INFO - 2018-02-21 00:02:10 --> Model Class Initialized
INFO - 2018-02-21 00:02:10 --> Model Class Initialized
INFO - 2018-02-21 00:02:10 --> Model Class Initialized
INFO - 2018-02-21 00:02:10 --> Model Class Initialized
DEBUG - 2018-02-21 00:02:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-21 00:02:10 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-21 00:02:10 --> Final output sent to browser
DEBUG - 2018-02-21 00:02:10 --> Total execution time: 0.0480
INFO - 2018-02-21 00:02:10 --> Config Class Initialized
INFO - 2018-02-21 00:02:10 --> Hooks Class Initialized
DEBUG - 2018-02-21 00:02:10 --> UTF-8 Support Enabled
INFO - 2018-02-21 00:02:10 --> Utf8 Class Initialized
INFO - 2018-02-21 00:02:10 --> URI Class Initialized
INFO - 2018-02-21 00:02:10 --> Router Class Initialized
INFO - 2018-02-21 00:02:10 --> Output Class Initialized
INFO - 2018-02-21 00:02:10 --> Security Class Initialized
DEBUG - 2018-02-21 00:02:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 00:02:10 --> Input Class Initialized
INFO - 2018-02-21 00:02:10 --> Language Class Initialized
INFO - 2018-02-21 00:02:10 --> Loader Class Initialized
INFO - 2018-02-21 00:02:10 --> Helper loaded: url_helper
INFO - 2018-02-21 00:02:10 --> Helper loaded: form_helper
INFO - 2018-02-21 00:02:10 --> Database Driver Class Initialized
DEBUG - 2018-02-21 00:02:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 00:02:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 00:02:10 --> Form Validation Class Initialized
INFO - 2018-02-21 00:02:10 --> Model Class Initialized
INFO - 2018-02-21 00:02:10 --> Controller Class Initialized
INFO - 2018-02-21 00:02:10 --> Model Class Initialized
INFO - 2018-02-21 00:02:10 --> Model Class Initialized
INFO - 2018-02-21 00:02:10 --> Model Class Initialized
INFO - 2018-02-21 00:02:10 --> Model Class Initialized
INFO - 2018-02-21 00:02:10 --> Model Class Initialized
DEBUG - 2018-02-21 00:02:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-21 00:03:18 --> Config Class Initialized
INFO - 2018-02-21 00:03:18 --> Hooks Class Initialized
DEBUG - 2018-02-21 00:03:18 --> UTF-8 Support Enabled
INFO - 2018-02-21 00:03:18 --> Utf8 Class Initialized
INFO - 2018-02-21 00:03:18 --> URI Class Initialized
INFO - 2018-02-21 00:03:18 --> Router Class Initialized
INFO - 2018-02-21 00:03:18 --> Output Class Initialized
INFO - 2018-02-21 00:03:18 --> Security Class Initialized
DEBUG - 2018-02-21 00:03:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 00:03:18 --> Input Class Initialized
INFO - 2018-02-21 00:03:18 --> Language Class Initialized
INFO - 2018-02-21 00:03:18 --> Loader Class Initialized
INFO - 2018-02-21 00:03:18 --> Helper loaded: url_helper
INFO - 2018-02-21 00:03:18 --> Helper loaded: form_helper
INFO - 2018-02-21 00:03:18 --> Database Driver Class Initialized
DEBUG - 2018-02-21 00:03:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 00:03:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 00:03:18 --> Form Validation Class Initialized
INFO - 2018-02-21 00:03:18 --> Model Class Initialized
INFO - 2018-02-21 00:03:18 --> Controller Class Initialized
INFO - 2018-02-21 00:03:18 --> Model Class Initialized
INFO - 2018-02-21 00:03:18 --> Model Class Initialized
INFO - 2018-02-21 00:03:18 --> Model Class Initialized
INFO - 2018-02-21 00:03:18 --> Model Class Initialized
INFO - 2018-02-21 00:03:18 --> Model Class Initialized
DEBUG - 2018-02-21 00:03:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-21 00:03:18 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-21 00:03:18 --> Final output sent to browser
DEBUG - 2018-02-21 00:03:18 --> Total execution time: 0.0498
INFO - 2018-02-21 00:03:18 --> Config Class Initialized
INFO - 2018-02-21 00:03:18 --> Hooks Class Initialized
DEBUG - 2018-02-21 00:03:18 --> UTF-8 Support Enabled
INFO - 2018-02-21 00:03:18 --> Utf8 Class Initialized
INFO - 2018-02-21 00:03:18 --> URI Class Initialized
INFO - 2018-02-21 00:03:18 --> Router Class Initialized
INFO - 2018-02-21 00:03:18 --> Output Class Initialized
INFO - 2018-02-21 00:03:18 --> Security Class Initialized
DEBUG - 2018-02-21 00:03:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 00:03:18 --> Input Class Initialized
INFO - 2018-02-21 00:03:18 --> Language Class Initialized
INFO - 2018-02-21 00:03:18 --> Loader Class Initialized
INFO - 2018-02-21 00:03:18 --> Helper loaded: url_helper
INFO - 2018-02-21 00:03:18 --> Helper loaded: form_helper
INFO - 2018-02-21 00:03:18 --> Database Driver Class Initialized
DEBUG - 2018-02-21 00:03:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 00:03:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 00:03:18 --> Form Validation Class Initialized
INFO - 2018-02-21 00:03:18 --> Model Class Initialized
INFO - 2018-02-21 00:03:18 --> Controller Class Initialized
INFO - 2018-02-21 00:03:18 --> Model Class Initialized
INFO - 2018-02-21 00:03:18 --> Model Class Initialized
INFO - 2018-02-21 00:03:18 --> Model Class Initialized
INFO - 2018-02-21 00:03:18 --> Model Class Initialized
INFO - 2018-02-21 00:03:18 --> Model Class Initialized
DEBUG - 2018-02-21 00:03:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-21 00:05:18 --> Config Class Initialized
INFO - 2018-02-21 00:05:18 --> Hooks Class Initialized
DEBUG - 2018-02-21 00:05:18 --> UTF-8 Support Enabled
INFO - 2018-02-21 00:05:18 --> Utf8 Class Initialized
INFO - 2018-02-21 00:05:18 --> URI Class Initialized
INFO - 2018-02-21 00:05:18 --> Router Class Initialized
INFO - 2018-02-21 00:05:18 --> Output Class Initialized
INFO - 2018-02-21 00:05:18 --> Security Class Initialized
DEBUG - 2018-02-21 00:05:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 00:05:18 --> Input Class Initialized
INFO - 2018-02-21 00:05:18 --> Language Class Initialized
INFO - 2018-02-21 00:05:18 --> Loader Class Initialized
INFO - 2018-02-21 00:05:18 --> Helper loaded: url_helper
INFO - 2018-02-21 00:05:19 --> Helper loaded: form_helper
INFO - 2018-02-21 00:05:19 --> Database Driver Class Initialized
DEBUG - 2018-02-21 00:05:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 00:05:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 00:05:19 --> Form Validation Class Initialized
INFO - 2018-02-21 00:05:19 --> Model Class Initialized
INFO - 2018-02-21 00:05:19 --> Controller Class Initialized
INFO - 2018-02-21 00:05:19 --> Model Class Initialized
INFO - 2018-02-21 00:05:19 --> Model Class Initialized
INFO - 2018-02-21 00:05:19 --> Model Class Initialized
INFO - 2018-02-21 00:05:19 --> Model Class Initialized
INFO - 2018-02-21 00:05:19 --> Model Class Initialized
DEBUG - 2018-02-21 00:05:19 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-21 00:05:19 --> Severity: Notice --> Undefined index: proyecto_extensiones D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\proyecto\verProyecto.php 267
ERROR - 2018-02-21 00:05:19 --> Severity: Notice --> Undefined index: reporte_proyecto_especifico D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\proyecto\verProyecto.php 273
ERROR - 2018-02-21 00:05:19 --> Severity: Notice --> Undefined index: edit D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\proyecto\verProyecto.php 276
ERROR - 2018-02-21 00:05:19 --> Severity: Notice --> Undefined index: delete D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\proyecto\verProyecto.php 279
INFO - 2018-02-21 00:05:19 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-21 00:05:19 --> Final output sent to browser
DEBUG - 2018-02-21 00:05:19 --> Total execution time: 0.0617
INFO - 2018-02-21 00:05:19 --> Config Class Initialized
INFO - 2018-02-21 00:05:19 --> Hooks Class Initialized
DEBUG - 2018-02-21 00:05:19 --> UTF-8 Support Enabled
INFO - 2018-02-21 00:05:19 --> Utf8 Class Initialized
INFO - 2018-02-21 00:05:19 --> URI Class Initialized
INFO - 2018-02-21 00:05:19 --> Router Class Initialized
INFO - 2018-02-21 00:05:19 --> Output Class Initialized
INFO - 2018-02-21 00:05:19 --> Security Class Initialized
DEBUG - 2018-02-21 00:05:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 00:05:19 --> Input Class Initialized
INFO - 2018-02-21 00:05:19 --> Language Class Initialized
INFO - 2018-02-21 00:05:19 --> Loader Class Initialized
INFO - 2018-02-21 00:05:19 --> Helper loaded: url_helper
INFO - 2018-02-21 00:05:19 --> Helper loaded: form_helper
INFO - 2018-02-21 00:05:19 --> Database Driver Class Initialized
DEBUG - 2018-02-21 00:05:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 00:05:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 00:05:19 --> Form Validation Class Initialized
INFO - 2018-02-21 00:05:19 --> Model Class Initialized
INFO - 2018-02-21 00:05:19 --> Controller Class Initialized
INFO - 2018-02-21 00:05:19 --> Model Class Initialized
INFO - 2018-02-21 00:05:19 --> Model Class Initialized
INFO - 2018-02-21 00:05:19 --> Model Class Initialized
INFO - 2018-02-21 00:05:19 --> Model Class Initialized
INFO - 2018-02-21 00:05:19 --> Model Class Initialized
DEBUG - 2018-02-21 00:05:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-21 00:05:58 --> Config Class Initialized
INFO - 2018-02-21 00:05:58 --> Hooks Class Initialized
DEBUG - 2018-02-21 00:05:58 --> UTF-8 Support Enabled
INFO - 2018-02-21 00:05:58 --> Utf8 Class Initialized
INFO - 2018-02-21 00:05:58 --> URI Class Initialized
INFO - 2018-02-21 00:05:58 --> Router Class Initialized
INFO - 2018-02-21 00:05:58 --> Output Class Initialized
INFO - 2018-02-21 00:05:58 --> Security Class Initialized
DEBUG - 2018-02-21 00:05:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 00:05:58 --> Input Class Initialized
INFO - 2018-02-21 00:05:58 --> Language Class Initialized
INFO - 2018-02-21 00:05:58 --> Loader Class Initialized
INFO - 2018-02-21 00:05:58 --> Helper loaded: url_helper
INFO - 2018-02-21 00:05:58 --> Helper loaded: form_helper
INFO - 2018-02-21 00:05:58 --> Database Driver Class Initialized
DEBUG - 2018-02-21 00:05:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 00:05:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 00:05:58 --> Form Validation Class Initialized
INFO - 2018-02-21 00:05:58 --> Model Class Initialized
INFO - 2018-02-21 00:05:58 --> Controller Class Initialized
INFO - 2018-02-21 00:05:58 --> Model Class Initialized
INFO - 2018-02-21 00:05:58 --> Model Class Initialized
INFO - 2018-02-21 00:05:58 --> Model Class Initialized
INFO - 2018-02-21 00:05:58 --> Model Class Initialized
INFO - 2018-02-21 00:05:58 --> Model Class Initialized
DEBUG - 2018-02-21 00:05:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-21 00:05:58 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-21 00:05:58 --> Final output sent to browser
DEBUG - 2018-02-21 00:05:58 --> Total execution time: 0.0504
INFO - 2018-02-21 00:05:58 --> Config Class Initialized
INFO - 2018-02-21 00:05:58 --> Hooks Class Initialized
DEBUG - 2018-02-21 00:05:58 --> UTF-8 Support Enabled
INFO - 2018-02-21 00:05:58 --> Utf8 Class Initialized
INFO - 2018-02-21 00:05:58 --> URI Class Initialized
INFO - 2018-02-21 00:05:58 --> Router Class Initialized
INFO - 2018-02-21 00:05:58 --> Output Class Initialized
INFO - 2018-02-21 00:05:58 --> Security Class Initialized
DEBUG - 2018-02-21 00:05:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 00:05:58 --> Input Class Initialized
INFO - 2018-02-21 00:05:58 --> Language Class Initialized
INFO - 2018-02-21 00:05:58 --> Loader Class Initialized
INFO - 2018-02-21 00:05:58 --> Helper loaded: url_helper
INFO - 2018-02-21 00:05:58 --> Helper loaded: form_helper
INFO - 2018-02-21 00:05:58 --> Database Driver Class Initialized
DEBUG - 2018-02-21 00:05:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 00:05:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 00:05:58 --> Form Validation Class Initialized
INFO - 2018-02-21 00:05:58 --> Model Class Initialized
INFO - 2018-02-21 00:05:58 --> Controller Class Initialized
INFO - 2018-02-21 00:05:58 --> Model Class Initialized
INFO - 2018-02-21 00:05:58 --> Model Class Initialized
INFO - 2018-02-21 00:05:58 --> Model Class Initialized
INFO - 2018-02-21 00:05:58 --> Model Class Initialized
INFO - 2018-02-21 00:05:58 --> Model Class Initialized
DEBUG - 2018-02-21 00:05:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-21 00:06:02 --> Config Class Initialized
INFO - 2018-02-21 00:06:02 --> Hooks Class Initialized
DEBUG - 2018-02-21 00:06:02 --> UTF-8 Support Enabled
INFO - 2018-02-21 00:06:02 --> Utf8 Class Initialized
INFO - 2018-02-21 00:06:02 --> URI Class Initialized
INFO - 2018-02-21 00:06:02 --> Router Class Initialized
INFO - 2018-02-21 00:06:02 --> Output Class Initialized
INFO - 2018-02-21 00:06:02 --> Security Class Initialized
DEBUG - 2018-02-21 00:06:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 00:06:02 --> Input Class Initialized
INFO - 2018-02-21 00:06:02 --> Language Class Initialized
INFO - 2018-02-21 00:06:02 --> Loader Class Initialized
INFO - 2018-02-21 00:06:02 --> Helper loaded: url_helper
INFO - 2018-02-21 00:06:02 --> Helper loaded: form_helper
INFO - 2018-02-21 00:06:02 --> Database Driver Class Initialized
DEBUG - 2018-02-21 00:06:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 00:06:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 00:06:02 --> Form Validation Class Initialized
INFO - 2018-02-21 00:06:02 --> Model Class Initialized
INFO - 2018-02-21 00:06:02 --> Controller Class Initialized
INFO - 2018-02-21 00:06:02 --> Model Class Initialized
INFO - 2018-02-21 00:06:02 --> Model Class Initialized
INFO - 2018-02-21 00:06:02 --> Model Class Initialized
INFO - 2018-02-21 00:06:02 --> Model Class Initialized
INFO - 2018-02-21 00:06:02 --> Model Class Initialized
DEBUG - 2018-02-21 00:06:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-21 00:06:02 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-21 00:06:02 --> Final output sent to browser
DEBUG - 2018-02-21 00:06:02 --> Total execution time: 0.0513
INFO - 2018-02-21 00:06:02 --> Config Class Initialized
INFO - 2018-02-21 00:06:02 --> Hooks Class Initialized
DEBUG - 2018-02-21 00:06:02 --> UTF-8 Support Enabled
INFO - 2018-02-21 00:06:02 --> Utf8 Class Initialized
INFO - 2018-02-21 00:06:02 --> URI Class Initialized
INFO - 2018-02-21 00:06:02 --> Router Class Initialized
INFO - 2018-02-21 00:06:02 --> Output Class Initialized
INFO - 2018-02-21 00:06:02 --> Security Class Initialized
DEBUG - 2018-02-21 00:06:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 00:06:02 --> Input Class Initialized
INFO - 2018-02-21 00:06:02 --> Language Class Initialized
INFO - 2018-02-21 00:06:02 --> Loader Class Initialized
INFO - 2018-02-21 00:06:02 --> Helper loaded: url_helper
INFO - 2018-02-21 00:06:02 --> Helper loaded: form_helper
INFO - 2018-02-21 00:06:02 --> Database Driver Class Initialized
DEBUG - 2018-02-21 00:06:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 00:06:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 00:06:02 --> Form Validation Class Initialized
INFO - 2018-02-21 00:06:02 --> Model Class Initialized
INFO - 2018-02-21 00:06:02 --> Controller Class Initialized
INFO - 2018-02-21 00:06:02 --> Model Class Initialized
INFO - 2018-02-21 00:06:02 --> Model Class Initialized
INFO - 2018-02-21 00:06:02 --> Model Class Initialized
INFO - 2018-02-21 00:06:02 --> Model Class Initialized
INFO - 2018-02-21 00:06:02 --> Model Class Initialized
DEBUG - 2018-02-21 00:06:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-21 00:06:05 --> Config Class Initialized
INFO - 2018-02-21 00:06:05 --> Hooks Class Initialized
DEBUG - 2018-02-21 00:06:05 --> UTF-8 Support Enabled
INFO - 2018-02-21 00:06:05 --> Utf8 Class Initialized
INFO - 2018-02-21 00:06:05 --> URI Class Initialized
INFO - 2018-02-21 00:06:05 --> Router Class Initialized
INFO - 2018-02-21 00:06:05 --> Output Class Initialized
INFO - 2018-02-21 00:06:05 --> Security Class Initialized
DEBUG - 2018-02-21 00:06:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 00:06:05 --> Input Class Initialized
INFO - 2018-02-21 00:06:05 --> Language Class Initialized
INFO - 2018-02-21 00:06:05 --> Loader Class Initialized
INFO - 2018-02-21 00:06:05 --> Helper loaded: url_helper
INFO - 2018-02-21 00:06:05 --> Helper loaded: form_helper
INFO - 2018-02-21 00:06:05 --> Database Driver Class Initialized
DEBUG - 2018-02-21 00:06:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 00:06:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 00:06:05 --> Form Validation Class Initialized
INFO - 2018-02-21 00:06:05 --> Model Class Initialized
INFO - 2018-02-21 00:06:05 --> Controller Class Initialized
INFO - 2018-02-21 00:06:05 --> Model Class Initialized
INFO - 2018-02-21 00:06:05 --> Model Class Initialized
INFO - 2018-02-21 00:06:05 --> Model Class Initialized
INFO - 2018-02-21 00:06:05 --> Model Class Initialized
INFO - 2018-02-21 00:06:05 --> Model Class Initialized
DEBUG - 2018-02-21 00:06:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-21 00:06:05 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-21 00:06:05 --> Final output sent to browser
DEBUG - 2018-02-21 00:06:05 --> Total execution time: 0.0478
INFO - 2018-02-21 00:06:05 --> Config Class Initialized
INFO - 2018-02-21 00:06:05 --> Hooks Class Initialized
DEBUG - 2018-02-21 00:06:05 --> UTF-8 Support Enabled
INFO - 2018-02-21 00:06:05 --> Utf8 Class Initialized
INFO - 2018-02-21 00:06:05 --> URI Class Initialized
INFO - 2018-02-21 00:06:05 --> Router Class Initialized
INFO - 2018-02-21 00:06:05 --> Output Class Initialized
INFO - 2018-02-21 00:06:05 --> Security Class Initialized
DEBUG - 2018-02-21 00:06:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 00:06:05 --> Input Class Initialized
INFO - 2018-02-21 00:06:05 --> Language Class Initialized
INFO - 2018-02-21 00:06:05 --> Loader Class Initialized
INFO - 2018-02-21 00:06:05 --> Helper loaded: url_helper
INFO - 2018-02-21 00:06:05 --> Helper loaded: form_helper
INFO - 2018-02-21 00:06:05 --> Database Driver Class Initialized
DEBUG - 2018-02-21 00:06:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 00:06:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 00:06:05 --> Form Validation Class Initialized
INFO - 2018-02-21 00:06:05 --> Model Class Initialized
INFO - 2018-02-21 00:06:05 --> Controller Class Initialized
INFO - 2018-02-21 00:06:05 --> Model Class Initialized
INFO - 2018-02-21 00:06:05 --> Model Class Initialized
INFO - 2018-02-21 00:06:05 --> Model Class Initialized
INFO - 2018-02-21 00:06:05 --> Model Class Initialized
INFO - 2018-02-21 00:06:05 --> Model Class Initialized
DEBUG - 2018-02-21 00:06:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-21 00:06:06 --> Config Class Initialized
INFO - 2018-02-21 00:06:06 --> Hooks Class Initialized
DEBUG - 2018-02-21 00:06:06 --> UTF-8 Support Enabled
INFO - 2018-02-21 00:06:06 --> Utf8 Class Initialized
INFO - 2018-02-21 00:06:06 --> URI Class Initialized
INFO - 2018-02-21 00:06:06 --> Router Class Initialized
INFO - 2018-02-21 00:06:06 --> Output Class Initialized
INFO - 2018-02-21 00:06:06 --> Security Class Initialized
DEBUG - 2018-02-21 00:06:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 00:06:06 --> Input Class Initialized
INFO - 2018-02-21 00:06:06 --> Language Class Initialized
INFO - 2018-02-21 00:06:06 --> Loader Class Initialized
INFO - 2018-02-21 00:06:06 --> Helper loaded: url_helper
INFO - 2018-02-21 00:06:06 --> Helper loaded: form_helper
INFO - 2018-02-21 00:06:06 --> Database Driver Class Initialized
DEBUG - 2018-02-21 00:06:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 00:06:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 00:06:06 --> Form Validation Class Initialized
INFO - 2018-02-21 00:06:06 --> Model Class Initialized
INFO - 2018-02-21 00:06:06 --> Controller Class Initialized
INFO - 2018-02-21 00:06:06 --> Model Class Initialized
INFO - 2018-02-21 00:06:06 --> Model Class Initialized
INFO - 2018-02-21 00:06:06 --> Model Class Initialized
INFO - 2018-02-21 00:06:06 --> Model Class Initialized
INFO - 2018-02-21 00:06:06 --> Model Class Initialized
DEBUG - 2018-02-21 00:06:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-21 00:06:06 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-21 00:06:06 --> Final output sent to browser
DEBUG - 2018-02-21 00:06:06 --> Total execution time: 0.0517
INFO - 2018-02-21 00:06:07 --> Config Class Initialized
INFO - 2018-02-21 00:06:07 --> Hooks Class Initialized
DEBUG - 2018-02-21 00:06:07 --> UTF-8 Support Enabled
INFO - 2018-02-21 00:06:07 --> Utf8 Class Initialized
INFO - 2018-02-21 00:06:07 --> URI Class Initialized
INFO - 2018-02-21 00:06:07 --> Router Class Initialized
INFO - 2018-02-21 00:06:07 --> Output Class Initialized
INFO - 2018-02-21 00:06:07 --> Security Class Initialized
DEBUG - 2018-02-21 00:06:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 00:06:07 --> Input Class Initialized
INFO - 2018-02-21 00:06:07 --> Language Class Initialized
INFO - 2018-02-21 00:06:07 --> Loader Class Initialized
INFO - 2018-02-21 00:06:07 --> Helper loaded: url_helper
INFO - 2018-02-21 00:06:07 --> Helper loaded: form_helper
INFO - 2018-02-21 00:06:07 --> Database Driver Class Initialized
DEBUG - 2018-02-21 00:06:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 00:06:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 00:06:07 --> Form Validation Class Initialized
INFO - 2018-02-21 00:06:07 --> Model Class Initialized
INFO - 2018-02-21 00:06:07 --> Controller Class Initialized
INFO - 2018-02-21 00:06:07 --> Model Class Initialized
INFO - 2018-02-21 00:06:07 --> Model Class Initialized
INFO - 2018-02-21 00:06:07 --> Model Class Initialized
INFO - 2018-02-21 00:06:07 --> Model Class Initialized
INFO - 2018-02-21 00:06:07 --> Model Class Initialized
DEBUG - 2018-02-21 00:06:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-21 00:06:09 --> Config Class Initialized
INFO - 2018-02-21 00:06:09 --> Hooks Class Initialized
DEBUG - 2018-02-21 00:06:09 --> UTF-8 Support Enabled
INFO - 2018-02-21 00:06:09 --> Utf8 Class Initialized
INFO - 2018-02-21 00:06:09 --> URI Class Initialized
INFO - 2018-02-21 00:06:09 --> Router Class Initialized
INFO - 2018-02-21 00:06:09 --> Output Class Initialized
INFO - 2018-02-21 00:06:09 --> Security Class Initialized
DEBUG - 2018-02-21 00:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 00:06:09 --> Input Class Initialized
INFO - 2018-02-21 00:06:09 --> Language Class Initialized
INFO - 2018-02-21 00:06:09 --> Loader Class Initialized
INFO - 2018-02-21 00:06:09 --> Helper loaded: url_helper
INFO - 2018-02-21 00:06:09 --> Helper loaded: form_helper
INFO - 2018-02-21 00:06:09 --> Database Driver Class Initialized
DEBUG - 2018-02-21 00:06:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 00:06:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 00:06:09 --> Form Validation Class Initialized
INFO - 2018-02-21 00:06:09 --> Model Class Initialized
INFO - 2018-02-21 00:06:09 --> Controller Class Initialized
INFO - 2018-02-21 00:06:09 --> Model Class Initialized
INFO - 2018-02-21 00:06:09 --> Model Class Initialized
INFO - 2018-02-21 00:06:09 --> Model Class Initialized
INFO - 2018-02-21 00:06:09 --> Model Class Initialized
INFO - 2018-02-21 00:06:09 --> Model Class Initialized
DEBUG - 2018-02-21 00:06:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-21 00:06:09 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-21 00:06:09 --> Final output sent to browser
DEBUG - 2018-02-21 00:06:09 --> Total execution time: 0.0507
INFO - 2018-02-21 00:06:09 --> Config Class Initialized
INFO - 2018-02-21 00:06:09 --> Hooks Class Initialized
DEBUG - 2018-02-21 00:06:09 --> UTF-8 Support Enabled
INFO - 2018-02-21 00:06:09 --> Utf8 Class Initialized
INFO - 2018-02-21 00:06:09 --> URI Class Initialized
INFO - 2018-02-21 00:06:09 --> Router Class Initialized
INFO - 2018-02-21 00:06:09 --> Output Class Initialized
INFO - 2018-02-21 00:06:09 --> Security Class Initialized
DEBUG - 2018-02-21 00:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 00:06:09 --> Input Class Initialized
INFO - 2018-02-21 00:06:09 --> Language Class Initialized
INFO - 2018-02-21 00:06:09 --> Loader Class Initialized
INFO - 2018-02-21 00:06:09 --> Helper loaded: url_helper
INFO - 2018-02-21 00:06:09 --> Helper loaded: form_helper
INFO - 2018-02-21 00:06:09 --> Database Driver Class Initialized
DEBUG - 2018-02-21 00:06:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 00:06:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 00:06:09 --> Form Validation Class Initialized
INFO - 2018-02-21 00:06:09 --> Model Class Initialized
INFO - 2018-02-21 00:06:09 --> Controller Class Initialized
INFO - 2018-02-21 00:06:09 --> Model Class Initialized
INFO - 2018-02-21 00:06:09 --> Model Class Initialized
INFO - 2018-02-21 00:06:09 --> Model Class Initialized
INFO - 2018-02-21 00:06:09 --> Model Class Initialized
INFO - 2018-02-21 00:06:09 --> Model Class Initialized
DEBUG - 2018-02-21 00:06:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-21 00:07:05 --> Config Class Initialized
INFO - 2018-02-21 00:07:05 --> Hooks Class Initialized
DEBUG - 2018-02-21 00:07:05 --> UTF-8 Support Enabled
INFO - 2018-02-21 00:07:05 --> Utf8 Class Initialized
INFO - 2018-02-21 00:07:05 --> URI Class Initialized
INFO - 2018-02-21 00:07:05 --> Router Class Initialized
INFO - 2018-02-21 00:07:05 --> Output Class Initialized
INFO - 2018-02-21 00:07:05 --> Security Class Initialized
DEBUG - 2018-02-21 00:07:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 00:07:05 --> Input Class Initialized
INFO - 2018-02-21 00:07:05 --> Language Class Initialized
INFO - 2018-02-21 00:07:05 --> Loader Class Initialized
INFO - 2018-02-21 00:07:05 --> Helper loaded: url_helper
INFO - 2018-02-21 00:07:05 --> Helper loaded: form_helper
INFO - 2018-02-21 00:07:05 --> Database Driver Class Initialized
DEBUG - 2018-02-21 00:07:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 00:07:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 00:07:05 --> Form Validation Class Initialized
INFO - 2018-02-21 00:07:05 --> Model Class Initialized
INFO - 2018-02-21 00:07:05 --> Controller Class Initialized
INFO - 2018-02-21 00:07:05 --> Model Class Initialized
INFO - 2018-02-21 00:07:05 --> Model Class Initialized
INFO - 2018-02-21 00:07:05 --> Model Class Initialized
INFO - 2018-02-21 00:07:05 --> Model Class Initialized
INFO - 2018-02-21 00:07:05 --> Model Class Initialized
DEBUG - 2018-02-21 00:07:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-21 00:07:05 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-21 00:07:05 --> Final output sent to browser
DEBUG - 2018-02-21 00:07:05 --> Total execution time: 0.0572
INFO - 2018-02-21 00:07:05 --> Config Class Initialized
INFO - 2018-02-21 00:07:05 --> Hooks Class Initialized
DEBUG - 2018-02-21 00:07:05 --> UTF-8 Support Enabled
INFO - 2018-02-21 00:07:05 --> Utf8 Class Initialized
INFO - 2018-02-21 00:07:05 --> URI Class Initialized
INFO - 2018-02-21 00:07:05 --> Router Class Initialized
INFO - 2018-02-21 00:07:05 --> Output Class Initialized
INFO - 2018-02-21 00:07:05 --> Security Class Initialized
DEBUG - 2018-02-21 00:07:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 00:07:05 --> Input Class Initialized
INFO - 2018-02-21 00:07:05 --> Language Class Initialized
INFO - 2018-02-21 00:07:05 --> Loader Class Initialized
INFO - 2018-02-21 00:07:05 --> Helper loaded: url_helper
INFO - 2018-02-21 00:07:05 --> Helper loaded: form_helper
INFO - 2018-02-21 00:07:05 --> Database Driver Class Initialized
DEBUG - 2018-02-21 00:07:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 00:07:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 00:07:05 --> Form Validation Class Initialized
INFO - 2018-02-21 00:07:05 --> Model Class Initialized
INFO - 2018-02-21 00:07:05 --> Controller Class Initialized
INFO - 2018-02-21 00:07:05 --> Model Class Initialized
INFO - 2018-02-21 00:07:05 --> Model Class Initialized
INFO - 2018-02-21 00:07:05 --> Model Class Initialized
INFO - 2018-02-21 00:07:05 --> Model Class Initialized
INFO - 2018-02-21 00:07:05 --> Model Class Initialized
DEBUG - 2018-02-21 00:07:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-21 00:08:12 --> Config Class Initialized
INFO - 2018-02-21 00:08:12 --> Hooks Class Initialized
DEBUG - 2018-02-21 00:08:12 --> UTF-8 Support Enabled
INFO - 2018-02-21 00:08:12 --> Utf8 Class Initialized
INFO - 2018-02-21 00:08:12 --> URI Class Initialized
INFO - 2018-02-21 00:08:12 --> Router Class Initialized
INFO - 2018-02-21 00:08:12 --> Output Class Initialized
INFO - 2018-02-21 00:08:12 --> Security Class Initialized
DEBUG - 2018-02-21 00:08:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 00:08:12 --> Input Class Initialized
INFO - 2018-02-21 00:08:12 --> Language Class Initialized
INFO - 2018-02-21 00:08:12 --> Loader Class Initialized
INFO - 2018-02-21 00:08:12 --> Helper loaded: url_helper
INFO - 2018-02-21 00:08:12 --> Helper loaded: form_helper
INFO - 2018-02-21 00:08:12 --> Database Driver Class Initialized
DEBUG - 2018-02-21 00:08:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 00:08:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 00:08:12 --> Form Validation Class Initialized
INFO - 2018-02-21 00:08:12 --> Model Class Initialized
INFO - 2018-02-21 00:08:12 --> Controller Class Initialized
INFO - 2018-02-21 00:08:12 --> Model Class Initialized
INFO - 2018-02-21 00:08:12 --> Model Class Initialized
INFO - 2018-02-21 00:08:12 --> Model Class Initialized
INFO - 2018-02-21 00:08:12 --> Model Class Initialized
INFO - 2018-02-21 00:08:12 --> Model Class Initialized
DEBUG - 2018-02-21 00:08:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-21 00:08:12 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-21 00:08:12 --> Final output sent to browser
DEBUG - 2018-02-21 00:08:12 --> Total execution time: 0.0596
INFO - 2018-02-21 00:08:13 --> Config Class Initialized
INFO - 2018-02-21 00:08:13 --> Hooks Class Initialized
DEBUG - 2018-02-21 00:08:13 --> UTF-8 Support Enabled
INFO - 2018-02-21 00:08:13 --> Utf8 Class Initialized
INFO - 2018-02-21 00:08:13 --> URI Class Initialized
INFO - 2018-02-21 00:08:13 --> Router Class Initialized
INFO - 2018-02-21 00:08:13 --> Output Class Initialized
INFO - 2018-02-21 00:08:13 --> Security Class Initialized
DEBUG - 2018-02-21 00:08:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 00:08:13 --> Input Class Initialized
INFO - 2018-02-21 00:08:13 --> Language Class Initialized
INFO - 2018-02-21 00:08:13 --> Loader Class Initialized
INFO - 2018-02-21 00:08:13 --> Helper loaded: url_helper
INFO - 2018-02-21 00:08:13 --> Helper loaded: form_helper
INFO - 2018-02-21 00:08:13 --> Database Driver Class Initialized
DEBUG - 2018-02-21 00:08:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 00:08:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 00:08:13 --> Form Validation Class Initialized
INFO - 2018-02-21 00:08:13 --> Model Class Initialized
INFO - 2018-02-21 00:08:13 --> Controller Class Initialized
INFO - 2018-02-21 00:08:13 --> Model Class Initialized
INFO - 2018-02-21 00:08:13 --> Model Class Initialized
INFO - 2018-02-21 00:08:13 --> Model Class Initialized
INFO - 2018-02-21 00:08:13 --> Model Class Initialized
INFO - 2018-02-21 00:08:13 --> Model Class Initialized
DEBUG - 2018-02-21 00:08:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-21 00:09:09 --> Config Class Initialized
INFO - 2018-02-21 00:09:09 --> Hooks Class Initialized
DEBUG - 2018-02-21 00:09:09 --> UTF-8 Support Enabled
INFO - 2018-02-21 00:09:09 --> Utf8 Class Initialized
INFO - 2018-02-21 00:09:09 --> URI Class Initialized
INFO - 2018-02-21 00:09:09 --> Router Class Initialized
INFO - 2018-02-21 00:09:09 --> Output Class Initialized
INFO - 2018-02-21 00:09:09 --> Security Class Initialized
DEBUG - 2018-02-21 00:09:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 00:09:09 --> Input Class Initialized
INFO - 2018-02-21 00:09:09 --> Language Class Initialized
INFO - 2018-02-21 00:09:09 --> Loader Class Initialized
INFO - 2018-02-21 00:09:09 --> Helper loaded: url_helper
INFO - 2018-02-21 00:09:09 --> Helper loaded: form_helper
INFO - 2018-02-21 00:09:09 --> Database Driver Class Initialized
DEBUG - 2018-02-21 00:09:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 00:09:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 00:09:09 --> Form Validation Class Initialized
INFO - 2018-02-21 00:09:09 --> Model Class Initialized
INFO - 2018-02-21 00:09:09 --> Controller Class Initialized
INFO - 2018-02-21 00:09:09 --> Model Class Initialized
INFO - 2018-02-21 00:09:09 --> Model Class Initialized
INFO - 2018-02-21 00:09:09 --> Model Class Initialized
INFO - 2018-02-21 00:09:09 --> Model Class Initialized
INFO - 2018-02-21 00:09:09 --> Model Class Initialized
DEBUG - 2018-02-21 00:09:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-21 00:09:09 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-21 00:09:09 --> Final output sent to browser
DEBUG - 2018-02-21 00:09:09 --> Total execution time: 0.0581
INFO - 2018-02-21 00:09:09 --> Config Class Initialized
INFO - 2018-02-21 00:09:09 --> Hooks Class Initialized
DEBUG - 2018-02-21 00:09:09 --> UTF-8 Support Enabled
INFO - 2018-02-21 00:09:09 --> Utf8 Class Initialized
INFO - 2018-02-21 00:09:09 --> URI Class Initialized
INFO - 2018-02-21 00:09:09 --> Router Class Initialized
INFO - 2018-02-21 00:09:09 --> Output Class Initialized
INFO - 2018-02-21 00:09:09 --> Security Class Initialized
DEBUG - 2018-02-21 00:09:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 00:09:09 --> Input Class Initialized
INFO - 2018-02-21 00:09:09 --> Language Class Initialized
INFO - 2018-02-21 00:09:09 --> Loader Class Initialized
INFO - 2018-02-21 00:09:09 --> Helper loaded: url_helper
INFO - 2018-02-21 00:09:09 --> Helper loaded: form_helper
INFO - 2018-02-21 00:09:09 --> Database Driver Class Initialized
DEBUG - 2018-02-21 00:09:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 00:09:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 00:09:09 --> Form Validation Class Initialized
INFO - 2018-02-21 00:09:09 --> Model Class Initialized
INFO - 2018-02-21 00:09:09 --> Controller Class Initialized
INFO - 2018-02-21 00:09:09 --> Model Class Initialized
INFO - 2018-02-21 00:09:09 --> Model Class Initialized
INFO - 2018-02-21 00:09:09 --> Model Class Initialized
INFO - 2018-02-21 00:09:09 --> Model Class Initialized
INFO - 2018-02-21 00:09:09 --> Model Class Initialized
DEBUG - 2018-02-21 00:09:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-21 00:09:14 --> Config Class Initialized
INFO - 2018-02-21 00:09:14 --> Hooks Class Initialized
DEBUG - 2018-02-21 00:09:14 --> UTF-8 Support Enabled
INFO - 2018-02-21 00:09:14 --> Utf8 Class Initialized
INFO - 2018-02-21 00:09:14 --> URI Class Initialized
INFO - 2018-02-21 00:09:14 --> Router Class Initialized
INFO - 2018-02-21 00:09:14 --> Output Class Initialized
INFO - 2018-02-21 00:09:14 --> Security Class Initialized
DEBUG - 2018-02-21 00:09:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 00:09:14 --> Input Class Initialized
INFO - 2018-02-21 00:09:14 --> Language Class Initialized
INFO - 2018-02-21 00:09:14 --> Loader Class Initialized
INFO - 2018-02-21 00:09:14 --> Helper loaded: url_helper
INFO - 2018-02-21 00:09:14 --> Helper loaded: form_helper
INFO - 2018-02-21 00:09:14 --> Database Driver Class Initialized
DEBUG - 2018-02-21 00:09:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 00:09:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 00:09:14 --> Form Validation Class Initialized
INFO - 2018-02-21 00:09:14 --> Model Class Initialized
INFO - 2018-02-21 00:09:14 --> Controller Class Initialized
INFO - 2018-02-21 00:09:14 --> Model Class Initialized
INFO - 2018-02-21 00:09:14 --> Model Class Initialized
INFO - 2018-02-21 00:09:14 --> Model Class Initialized
INFO - 2018-02-21 00:09:14 --> Model Class Initialized
INFO - 2018-02-21 00:09:14 --> Model Class Initialized
DEBUG - 2018-02-21 00:09:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-21 00:09:14 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-21 00:09:14 --> Final output sent to browser
DEBUG - 2018-02-21 00:09:14 --> Total execution time: 0.0625
INFO - 2018-02-21 00:09:16 --> Config Class Initialized
INFO - 2018-02-21 00:09:16 --> Hooks Class Initialized
DEBUG - 2018-02-21 00:09:16 --> UTF-8 Support Enabled
INFO - 2018-02-21 00:09:16 --> Utf8 Class Initialized
INFO - 2018-02-21 00:09:16 --> URI Class Initialized
INFO - 2018-02-21 00:09:16 --> Router Class Initialized
INFO - 2018-02-21 00:09:16 --> Output Class Initialized
INFO - 2018-02-21 00:09:16 --> Security Class Initialized
DEBUG - 2018-02-21 00:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 00:09:16 --> Input Class Initialized
INFO - 2018-02-21 00:09:16 --> Language Class Initialized
INFO - 2018-02-21 00:09:16 --> Loader Class Initialized
INFO - 2018-02-21 00:09:16 --> Helper loaded: url_helper
INFO - 2018-02-21 00:09:16 --> Helper loaded: form_helper
INFO - 2018-02-21 00:09:16 --> Database Driver Class Initialized
DEBUG - 2018-02-21 00:09:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 00:09:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 00:09:16 --> Form Validation Class Initialized
INFO - 2018-02-21 00:09:16 --> Model Class Initialized
INFO - 2018-02-21 00:09:16 --> Controller Class Initialized
INFO - 2018-02-21 00:09:16 --> Model Class Initialized
INFO - 2018-02-21 00:09:16 --> Model Class Initialized
INFO - 2018-02-21 00:09:16 --> Model Class Initialized
INFO - 2018-02-21 00:09:16 --> Model Class Initialized
INFO - 2018-02-21 00:09:16 --> Model Class Initialized
DEBUG - 2018-02-21 00:09:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-21 00:09:16 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-21 00:09:16 --> Final output sent to browser
DEBUG - 2018-02-21 00:09:16 --> Total execution time: 0.0541
INFO - 2018-02-21 00:09:16 --> Config Class Initialized
INFO - 2018-02-21 00:09:16 --> Hooks Class Initialized
DEBUG - 2018-02-21 00:09:16 --> UTF-8 Support Enabled
INFO - 2018-02-21 00:09:16 --> Utf8 Class Initialized
INFO - 2018-02-21 00:09:16 --> URI Class Initialized
INFO - 2018-02-21 00:09:16 --> Router Class Initialized
INFO - 2018-02-21 00:09:16 --> Output Class Initialized
INFO - 2018-02-21 00:09:16 --> Security Class Initialized
DEBUG - 2018-02-21 00:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 00:09:16 --> Input Class Initialized
INFO - 2018-02-21 00:09:16 --> Language Class Initialized
INFO - 2018-02-21 00:09:16 --> Loader Class Initialized
INFO - 2018-02-21 00:09:16 --> Helper loaded: url_helper
INFO - 2018-02-21 00:09:16 --> Helper loaded: form_helper
INFO - 2018-02-21 00:09:16 --> Database Driver Class Initialized
DEBUG - 2018-02-21 00:09:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 00:09:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 00:09:16 --> Form Validation Class Initialized
INFO - 2018-02-21 00:09:16 --> Model Class Initialized
INFO - 2018-02-21 00:09:16 --> Controller Class Initialized
INFO - 2018-02-21 00:09:16 --> Model Class Initialized
INFO - 2018-02-21 00:09:16 --> Model Class Initialized
INFO - 2018-02-21 00:09:16 --> Model Class Initialized
INFO - 2018-02-21 00:09:16 --> Model Class Initialized
INFO - 2018-02-21 00:09:16 --> Model Class Initialized
DEBUG - 2018-02-21 00:09:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-21 00:09:17 --> Config Class Initialized
INFO - 2018-02-21 00:09:17 --> Hooks Class Initialized
DEBUG - 2018-02-21 00:09:17 --> UTF-8 Support Enabled
INFO - 2018-02-21 00:09:17 --> Utf8 Class Initialized
INFO - 2018-02-21 00:09:17 --> URI Class Initialized
INFO - 2018-02-21 00:09:17 --> Router Class Initialized
INFO - 2018-02-21 00:09:17 --> Output Class Initialized
INFO - 2018-02-21 00:09:17 --> Security Class Initialized
DEBUG - 2018-02-21 00:09:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 00:09:17 --> Input Class Initialized
INFO - 2018-02-21 00:09:17 --> Language Class Initialized
INFO - 2018-02-21 00:09:17 --> Loader Class Initialized
INFO - 2018-02-21 00:09:17 --> Helper loaded: url_helper
INFO - 2018-02-21 00:09:17 --> Helper loaded: form_helper
INFO - 2018-02-21 00:09:17 --> Database Driver Class Initialized
DEBUG - 2018-02-21 00:09:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 00:09:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 00:09:17 --> Form Validation Class Initialized
INFO - 2018-02-21 00:09:17 --> Model Class Initialized
INFO - 2018-02-21 00:09:17 --> Controller Class Initialized
INFO - 2018-02-21 00:09:17 --> Model Class Initialized
INFO - 2018-02-21 00:09:17 --> Model Class Initialized
INFO - 2018-02-21 00:09:17 --> Model Class Initialized
INFO - 2018-02-21 00:09:17 --> Model Class Initialized
INFO - 2018-02-21 00:09:17 --> Model Class Initialized
DEBUG - 2018-02-21 00:09:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-21 00:09:17 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-21 00:09:17 --> Final output sent to browser
DEBUG - 2018-02-21 00:09:17 --> Total execution time: 0.0607
INFO - 2018-02-21 00:09:17 --> Config Class Initialized
INFO - 2018-02-21 00:09:17 --> Hooks Class Initialized
DEBUG - 2018-02-21 00:09:17 --> UTF-8 Support Enabled
INFO - 2018-02-21 00:09:17 --> Utf8 Class Initialized
INFO - 2018-02-21 00:09:17 --> URI Class Initialized
INFO - 2018-02-21 00:09:17 --> Router Class Initialized
INFO - 2018-02-21 00:09:17 --> Output Class Initialized
INFO - 2018-02-21 00:09:17 --> Security Class Initialized
DEBUG - 2018-02-21 00:09:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 00:09:17 --> Input Class Initialized
INFO - 2018-02-21 00:09:17 --> Language Class Initialized
INFO - 2018-02-21 00:09:17 --> Loader Class Initialized
INFO - 2018-02-21 00:09:17 --> Helper loaded: url_helper
INFO - 2018-02-21 00:09:17 --> Helper loaded: form_helper
INFO - 2018-02-21 00:09:17 --> Database Driver Class Initialized
DEBUG - 2018-02-21 00:09:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 00:09:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 00:09:17 --> Form Validation Class Initialized
INFO - 2018-02-21 00:09:17 --> Model Class Initialized
INFO - 2018-02-21 00:09:17 --> Controller Class Initialized
INFO - 2018-02-21 00:09:17 --> Model Class Initialized
INFO - 2018-02-21 00:09:17 --> Model Class Initialized
INFO - 2018-02-21 00:09:17 --> Model Class Initialized
INFO - 2018-02-21 00:09:17 --> Model Class Initialized
INFO - 2018-02-21 00:09:17 --> Model Class Initialized
DEBUG - 2018-02-21 00:09:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-21 00:09:20 --> Config Class Initialized
INFO - 2018-02-21 00:09:20 --> Hooks Class Initialized
DEBUG - 2018-02-21 00:09:20 --> UTF-8 Support Enabled
INFO - 2018-02-21 00:09:20 --> Utf8 Class Initialized
INFO - 2018-02-21 00:09:20 --> URI Class Initialized
INFO - 2018-02-21 00:09:20 --> Router Class Initialized
INFO - 2018-02-21 00:09:20 --> Output Class Initialized
INFO - 2018-02-21 00:09:20 --> Security Class Initialized
DEBUG - 2018-02-21 00:09:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 00:09:20 --> Input Class Initialized
INFO - 2018-02-21 00:09:20 --> Language Class Initialized
INFO - 2018-02-21 00:09:20 --> Loader Class Initialized
INFO - 2018-02-21 00:09:20 --> Helper loaded: url_helper
INFO - 2018-02-21 00:09:20 --> Helper loaded: form_helper
INFO - 2018-02-21 00:09:20 --> Database Driver Class Initialized
DEBUG - 2018-02-21 00:09:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 00:09:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 00:09:20 --> Form Validation Class Initialized
INFO - 2018-02-21 00:09:20 --> Model Class Initialized
INFO - 2018-02-21 00:09:20 --> Controller Class Initialized
INFO - 2018-02-21 00:09:20 --> Model Class Initialized
INFO - 2018-02-21 00:09:20 --> Model Class Initialized
INFO - 2018-02-21 00:09:20 --> Model Class Initialized
INFO - 2018-02-21 00:09:20 --> Model Class Initialized
INFO - 2018-02-21 00:09:20 --> Model Class Initialized
DEBUG - 2018-02-21 00:09:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-21 00:09:20 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-21 00:09:20 --> Final output sent to browser
DEBUG - 2018-02-21 00:09:20 --> Total execution time: 0.0608
INFO - 2018-02-21 00:09:20 --> Config Class Initialized
INFO - 2018-02-21 00:09:20 --> Hooks Class Initialized
DEBUG - 2018-02-21 00:09:20 --> UTF-8 Support Enabled
INFO - 2018-02-21 00:09:20 --> Utf8 Class Initialized
INFO - 2018-02-21 00:09:20 --> URI Class Initialized
INFO - 2018-02-21 00:09:20 --> Router Class Initialized
INFO - 2018-02-21 00:09:20 --> Output Class Initialized
INFO - 2018-02-21 00:09:20 --> Security Class Initialized
DEBUG - 2018-02-21 00:09:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 00:09:20 --> Input Class Initialized
INFO - 2018-02-21 00:09:20 --> Language Class Initialized
INFO - 2018-02-21 00:09:20 --> Loader Class Initialized
INFO - 2018-02-21 00:09:20 --> Helper loaded: url_helper
INFO - 2018-02-21 00:09:20 --> Helper loaded: form_helper
INFO - 2018-02-21 00:09:20 --> Database Driver Class Initialized
DEBUG - 2018-02-21 00:09:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 00:09:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 00:09:20 --> Form Validation Class Initialized
INFO - 2018-02-21 00:09:20 --> Model Class Initialized
INFO - 2018-02-21 00:09:20 --> Controller Class Initialized
INFO - 2018-02-21 00:09:20 --> Model Class Initialized
INFO - 2018-02-21 00:09:20 --> Model Class Initialized
INFO - 2018-02-21 00:09:20 --> Model Class Initialized
INFO - 2018-02-21 00:09:20 --> Model Class Initialized
INFO - 2018-02-21 00:09:20 --> Model Class Initialized
DEBUG - 2018-02-21 00:09:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-21 00:11:14 --> Config Class Initialized
INFO - 2018-02-21 00:11:14 --> Hooks Class Initialized
DEBUG - 2018-02-21 00:11:14 --> UTF-8 Support Enabled
INFO - 2018-02-21 00:11:14 --> Utf8 Class Initialized
INFO - 2018-02-21 00:11:14 --> URI Class Initialized
INFO - 2018-02-21 00:11:14 --> Router Class Initialized
INFO - 2018-02-21 00:11:14 --> Output Class Initialized
INFO - 2018-02-21 00:11:14 --> Security Class Initialized
DEBUG - 2018-02-21 00:11:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 00:11:14 --> Input Class Initialized
INFO - 2018-02-21 00:11:14 --> Language Class Initialized
INFO - 2018-02-21 00:11:14 --> Loader Class Initialized
INFO - 2018-02-21 00:11:14 --> Helper loaded: url_helper
INFO - 2018-02-21 00:11:14 --> Helper loaded: form_helper
INFO - 2018-02-21 00:11:14 --> Database Driver Class Initialized
DEBUG - 2018-02-21 00:11:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 00:11:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 00:11:14 --> Form Validation Class Initialized
INFO - 2018-02-21 00:11:15 --> Model Class Initialized
INFO - 2018-02-21 00:11:15 --> Controller Class Initialized
INFO - 2018-02-21 00:11:15 --> Model Class Initialized
INFO - 2018-02-21 00:11:15 --> Model Class Initialized
INFO - 2018-02-21 00:11:15 --> Model Class Initialized
INFO - 2018-02-21 00:11:15 --> Model Class Initialized
INFO - 2018-02-21 00:11:15 --> Model Class Initialized
DEBUG - 2018-02-21 00:11:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-21 00:11:15 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-21 00:11:15 --> Final output sent to browser
DEBUG - 2018-02-21 00:11:15 --> Total execution time: 0.0590
INFO - 2018-02-21 00:11:15 --> Config Class Initialized
INFO - 2018-02-21 00:11:15 --> Hooks Class Initialized
DEBUG - 2018-02-21 00:11:15 --> UTF-8 Support Enabled
INFO - 2018-02-21 00:11:15 --> Utf8 Class Initialized
INFO - 2018-02-21 00:11:15 --> URI Class Initialized
INFO - 2018-02-21 00:11:15 --> Router Class Initialized
INFO - 2018-02-21 00:11:15 --> Output Class Initialized
INFO - 2018-02-21 00:11:15 --> Security Class Initialized
DEBUG - 2018-02-21 00:11:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 00:11:15 --> Input Class Initialized
INFO - 2018-02-21 00:11:15 --> Language Class Initialized
INFO - 2018-02-21 00:11:15 --> Loader Class Initialized
INFO - 2018-02-21 00:11:15 --> Helper loaded: url_helper
INFO - 2018-02-21 00:11:15 --> Helper loaded: form_helper
INFO - 2018-02-21 00:11:15 --> Database Driver Class Initialized
DEBUG - 2018-02-21 00:11:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 00:11:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 00:11:15 --> Form Validation Class Initialized
INFO - 2018-02-21 00:11:15 --> Model Class Initialized
INFO - 2018-02-21 00:11:15 --> Controller Class Initialized
INFO - 2018-02-21 00:11:15 --> Model Class Initialized
INFO - 2018-02-21 00:11:15 --> Model Class Initialized
INFO - 2018-02-21 00:11:15 --> Model Class Initialized
INFO - 2018-02-21 00:11:15 --> Model Class Initialized
INFO - 2018-02-21 00:11:15 --> Model Class Initialized
DEBUG - 2018-02-21 00:11:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-21 00:13:06 --> Config Class Initialized
INFO - 2018-02-21 00:13:06 --> Hooks Class Initialized
DEBUG - 2018-02-21 00:13:06 --> UTF-8 Support Enabled
INFO - 2018-02-21 00:13:06 --> Utf8 Class Initialized
INFO - 2018-02-21 00:13:06 --> URI Class Initialized
INFO - 2018-02-21 00:13:06 --> Router Class Initialized
INFO - 2018-02-21 00:13:06 --> Output Class Initialized
INFO - 2018-02-21 00:13:06 --> Security Class Initialized
DEBUG - 2018-02-21 00:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 00:13:06 --> Input Class Initialized
INFO - 2018-02-21 00:13:06 --> Language Class Initialized
INFO - 2018-02-21 00:13:06 --> Loader Class Initialized
INFO - 2018-02-21 00:13:06 --> Helper loaded: url_helper
INFO - 2018-02-21 00:13:06 --> Helper loaded: form_helper
INFO - 2018-02-21 00:13:06 --> Database Driver Class Initialized
DEBUG - 2018-02-21 00:13:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 00:13:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 00:13:06 --> Form Validation Class Initialized
INFO - 2018-02-21 00:13:06 --> Model Class Initialized
INFO - 2018-02-21 00:13:06 --> Controller Class Initialized
INFO - 2018-02-21 00:13:06 --> Model Class Initialized
INFO - 2018-02-21 00:13:06 --> Model Class Initialized
INFO - 2018-02-21 00:13:06 --> Model Class Initialized
INFO - 2018-02-21 00:13:06 --> Model Class Initialized
INFO - 2018-02-21 00:13:06 --> Model Class Initialized
DEBUG - 2018-02-21 00:13:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-21 00:13:06 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-21 00:13:06 --> Final output sent to browser
DEBUG - 2018-02-21 00:13:06 --> Total execution time: 0.0574
INFO - 2018-02-21 00:13:06 --> Config Class Initialized
INFO - 2018-02-21 00:13:06 --> Hooks Class Initialized
DEBUG - 2018-02-21 00:13:06 --> UTF-8 Support Enabled
INFO - 2018-02-21 00:13:06 --> Utf8 Class Initialized
INFO - 2018-02-21 00:13:06 --> URI Class Initialized
INFO - 2018-02-21 00:13:06 --> Router Class Initialized
INFO - 2018-02-21 00:13:06 --> Output Class Initialized
INFO - 2018-02-21 00:13:06 --> Security Class Initialized
DEBUG - 2018-02-21 00:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 00:13:06 --> Input Class Initialized
INFO - 2018-02-21 00:13:06 --> Language Class Initialized
INFO - 2018-02-21 00:13:06 --> Loader Class Initialized
INFO - 2018-02-21 00:13:06 --> Helper loaded: url_helper
INFO - 2018-02-21 00:13:06 --> Helper loaded: form_helper
INFO - 2018-02-21 00:13:06 --> Database Driver Class Initialized
DEBUG - 2018-02-21 00:13:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 00:13:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 00:13:06 --> Form Validation Class Initialized
INFO - 2018-02-21 00:13:06 --> Model Class Initialized
INFO - 2018-02-21 00:13:06 --> Controller Class Initialized
INFO - 2018-02-21 00:13:06 --> Model Class Initialized
INFO - 2018-02-21 00:13:06 --> Model Class Initialized
INFO - 2018-02-21 00:13:06 --> Model Class Initialized
INFO - 2018-02-21 00:13:06 --> Model Class Initialized
INFO - 2018-02-21 00:13:06 --> Model Class Initialized
DEBUG - 2018-02-21 00:13:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-21 00:13:07 --> Config Class Initialized
INFO - 2018-02-21 00:13:07 --> Hooks Class Initialized
DEBUG - 2018-02-21 00:13:07 --> UTF-8 Support Enabled
INFO - 2018-02-21 00:13:07 --> Utf8 Class Initialized
INFO - 2018-02-21 00:13:07 --> URI Class Initialized
INFO - 2018-02-21 00:13:07 --> Router Class Initialized
INFO - 2018-02-21 00:13:07 --> Output Class Initialized
INFO - 2018-02-21 00:13:07 --> Security Class Initialized
DEBUG - 2018-02-21 00:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 00:13:07 --> Input Class Initialized
INFO - 2018-02-21 00:13:07 --> Language Class Initialized
INFO - 2018-02-21 00:13:07 --> Loader Class Initialized
INFO - 2018-02-21 00:13:07 --> Helper loaded: url_helper
INFO - 2018-02-21 00:13:07 --> Helper loaded: form_helper
INFO - 2018-02-21 00:13:07 --> Database Driver Class Initialized
DEBUG - 2018-02-21 00:13:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 00:13:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 00:13:07 --> Form Validation Class Initialized
INFO - 2018-02-21 00:13:07 --> Model Class Initialized
INFO - 2018-02-21 00:13:07 --> Controller Class Initialized
INFO - 2018-02-21 00:13:07 --> Model Class Initialized
INFO - 2018-02-21 00:13:07 --> Model Class Initialized
INFO - 2018-02-21 00:13:07 --> Model Class Initialized
INFO - 2018-02-21 00:13:07 --> Model Class Initialized
INFO - 2018-02-21 00:13:07 --> Model Class Initialized
DEBUG - 2018-02-21 00:13:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-21 00:13:07 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-21 00:13:07 --> Final output sent to browser
DEBUG - 2018-02-21 00:13:07 --> Total execution time: 0.0575
INFO - 2018-02-21 00:13:07 --> Config Class Initialized
INFO - 2018-02-21 00:13:07 --> Hooks Class Initialized
DEBUG - 2018-02-21 00:13:07 --> UTF-8 Support Enabled
INFO - 2018-02-21 00:13:07 --> Utf8 Class Initialized
INFO - 2018-02-21 00:13:07 --> URI Class Initialized
INFO - 2018-02-21 00:13:07 --> Router Class Initialized
INFO - 2018-02-21 00:13:07 --> Output Class Initialized
INFO - 2018-02-21 00:13:07 --> Security Class Initialized
DEBUG - 2018-02-21 00:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 00:13:07 --> Input Class Initialized
INFO - 2018-02-21 00:13:07 --> Language Class Initialized
INFO - 2018-02-21 00:13:07 --> Loader Class Initialized
INFO - 2018-02-21 00:13:07 --> Helper loaded: url_helper
INFO - 2018-02-21 00:13:07 --> Helper loaded: form_helper
INFO - 2018-02-21 00:13:07 --> Database Driver Class Initialized
DEBUG - 2018-02-21 00:13:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 00:13:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 00:13:07 --> Form Validation Class Initialized
INFO - 2018-02-21 00:13:07 --> Model Class Initialized
INFO - 2018-02-21 00:13:07 --> Controller Class Initialized
INFO - 2018-02-21 00:13:07 --> Model Class Initialized
INFO - 2018-02-21 00:13:07 --> Model Class Initialized
INFO - 2018-02-21 00:13:07 --> Model Class Initialized
INFO - 2018-02-21 00:13:07 --> Model Class Initialized
INFO - 2018-02-21 00:13:07 --> Model Class Initialized
DEBUG - 2018-02-21 00:13:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-21 00:13:07 --> Config Class Initialized
INFO - 2018-02-21 00:13:07 --> Hooks Class Initialized
DEBUG - 2018-02-21 00:13:07 --> UTF-8 Support Enabled
INFO - 2018-02-21 00:13:07 --> Utf8 Class Initialized
INFO - 2018-02-21 00:13:07 --> URI Class Initialized
INFO - 2018-02-21 00:13:07 --> Router Class Initialized
INFO - 2018-02-21 00:13:08 --> Output Class Initialized
INFO - 2018-02-21 00:13:08 --> Security Class Initialized
DEBUG - 2018-02-21 00:13:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 00:13:08 --> Input Class Initialized
INFO - 2018-02-21 00:13:08 --> Language Class Initialized
INFO - 2018-02-21 00:13:08 --> Loader Class Initialized
INFO - 2018-02-21 00:13:08 --> Helper loaded: url_helper
INFO - 2018-02-21 00:13:08 --> Helper loaded: form_helper
INFO - 2018-02-21 00:13:08 --> Database Driver Class Initialized
DEBUG - 2018-02-21 00:13:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 00:13:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 00:13:08 --> Form Validation Class Initialized
INFO - 2018-02-21 00:13:08 --> Model Class Initialized
INFO - 2018-02-21 00:13:08 --> Controller Class Initialized
INFO - 2018-02-21 00:13:08 --> Model Class Initialized
INFO - 2018-02-21 00:13:08 --> Model Class Initialized
INFO - 2018-02-21 00:13:08 --> Model Class Initialized
INFO - 2018-02-21 00:13:08 --> Model Class Initialized
INFO - 2018-02-21 00:13:08 --> Model Class Initialized
DEBUG - 2018-02-21 00:13:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-21 00:13:08 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-21 00:13:08 --> Final output sent to browser
DEBUG - 2018-02-21 00:13:08 --> Total execution time: 0.0596
INFO - 2018-02-21 00:13:08 --> Config Class Initialized
INFO - 2018-02-21 00:13:08 --> Hooks Class Initialized
DEBUG - 2018-02-21 00:13:08 --> UTF-8 Support Enabled
INFO - 2018-02-21 00:13:08 --> Utf8 Class Initialized
INFO - 2018-02-21 00:13:08 --> URI Class Initialized
INFO - 2018-02-21 00:13:08 --> Router Class Initialized
INFO - 2018-02-21 00:13:08 --> Output Class Initialized
INFO - 2018-02-21 00:13:08 --> Security Class Initialized
DEBUG - 2018-02-21 00:13:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 00:13:08 --> Input Class Initialized
INFO - 2018-02-21 00:13:08 --> Language Class Initialized
INFO - 2018-02-21 00:13:08 --> Loader Class Initialized
INFO - 2018-02-21 00:13:08 --> Helper loaded: url_helper
INFO - 2018-02-21 00:13:08 --> Helper loaded: form_helper
INFO - 2018-02-21 00:13:08 --> Database Driver Class Initialized
DEBUG - 2018-02-21 00:13:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 00:13:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 00:13:08 --> Form Validation Class Initialized
INFO - 2018-02-21 00:13:08 --> Model Class Initialized
INFO - 2018-02-21 00:13:08 --> Controller Class Initialized
INFO - 2018-02-21 00:13:08 --> Model Class Initialized
INFO - 2018-02-21 00:13:08 --> Model Class Initialized
INFO - 2018-02-21 00:13:08 --> Model Class Initialized
INFO - 2018-02-21 00:13:08 --> Model Class Initialized
INFO - 2018-02-21 00:13:08 --> Model Class Initialized
DEBUG - 2018-02-21 00:13:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-21 00:13:19 --> Config Class Initialized
INFO - 2018-02-21 00:13:19 --> Hooks Class Initialized
DEBUG - 2018-02-21 00:13:19 --> UTF-8 Support Enabled
INFO - 2018-02-21 00:13:19 --> Utf8 Class Initialized
INFO - 2018-02-21 00:13:19 --> URI Class Initialized
INFO - 2018-02-21 00:13:19 --> Router Class Initialized
INFO - 2018-02-21 00:13:19 --> Output Class Initialized
INFO - 2018-02-21 00:13:19 --> Security Class Initialized
DEBUG - 2018-02-21 00:13:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 00:13:19 --> Input Class Initialized
INFO - 2018-02-21 00:13:19 --> Language Class Initialized
INFO - 2018-02-21 00:13:19 --> Loader Class Initialized
INFO - 2018-02-21 00:13:19 --> Helper loaded: url_helper
INFO - 2018-02-21 00:13:19 --> Helper loaded: form_helper
INFO - 2018-02-21 00:13:19 --> Database Driver Class Initialized
DEBUG - 2018-02-21 00:13:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 00:13:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 00:13:19 --> Form Validation Class Initialized
INFO - 2018-02-21 00:13:19 --> Model Class Initialized
INFO - 2018-02-21 00:13:19 --> Controller Class Initialized
INFO - 2018-02-21 00:13:19 --> Model Class Initialized
DEBUG - 2018-02-21 00:13:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-21 00:13:19 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-21 00:13:19 --> Final output sent to browser
DEBUG - 2018-02-21 00:13:19 --> Total execution time: 0.0482
INFO - 2018-02-21 00:13:19 --> Config Class Initialized
INFO - 2018-02-21 00:13:19 --> Hooks Class Initialized
DEBUG - 2018-02-21 00:13:19 --> UTF-8 Support Enabled
INFO - 2018-02-21 00:13:19 --> Utf8 Class Initialized
INFO - 2018-02-21 00:13:19 --> URI Class Initialized
INFO - 2018-02-21 00:13:19 --> Router Class Initialized
INFO - 2018-02-21 00:13:19 --> Output Class Initialized
INFO - 2018-02-21 00:13:19 --> Security Class Initialized
DEBUG - 2018-02-21 00:13:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 00:13:19 --> Input Class Initialized
INFO - 2018-02-21 00:13:19 --> Language Class Initialized
INFO - 2018-02-21 00:13:19 --> Loader Class Initialized
INFO - 2018-02-21 00:13:19 --> Helper loaded: url_helper
INFO - 2018-02-21 00:13:19 --> Helper loaded: form_helper
INFO - 2018-02-21 00:13:20 --> Database Driver Class Initialized
DEBUG - 2018-02-21 00:13:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 00:13:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 00:13:20 --> Form Validation Class Initialized
INFO - 2018-02-21 00:13:20 --> Model Class Initialized
INFO - 2018-02-21 00:13:20 --> Controller Class Initialized
INFO - 2018-02-21 00:13:20 --> Model Class Initialized
DEBUG - 2018-02-21 00:13:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-21 00:13:24 --> Config Class Initialized
INFO - 2018-02-21 00:13:24 --> Hooks Class Initialized
DEBUG - 2018-02-21 00:13:24 --> UTF-8 Support Enabled
INFO - 2018-02-21 00:13:24 --> Utf8 Class Initialized
INFO - 2018-02-21 00:13:24 --> URI Class Initialized
INFO - 2018-02-21 00:13:24 --> Router Class Initialized
INFO - 2018-02-21 00:13:24 --> Output Class Initialized
INFO - 2018-02-21 00:13:24 --> Security Class Initialized
DEBUG - 2018-02-21 00:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 00:13:24 --> Input Class Initialized
INFO - 2018-02-21 00:13:24 --> Language Class Initialized
INFO - 2018-02-21 00:13:24 --> Loader Class Initialized
INFO - 2018-02-21 00:13:24 --> Helper loaded: url_helper
INFO - 2018-02-21 00:13:24 --> Helper loaded: form_helper
INFO - 2018-02-21 00:13:24 --> Database Driver Class Initialized
DEBUG - 2018-02-21 00:13:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 00:13:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 00:13:24 --> Form Validation Class Initialized
INFO - 2018-02-21 00:13:24 --> Model Class Initialized
INFO - 2018-02-21 00:13:24 --> Controller Class Initialized
INFO - 2018-02-21 00:13:24 --> Model Class Initialized
DEBUG - 2018-02-21 00:13:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-21 00:13:24 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-21 00:13:24 --> Final output sent to browser
DEBUG - 2018-02-21 00:13:24 --> Total execution time: 0.0402
INFO - 2018-02-21 00:13:27 --> Config Class Initialized
INFO - 2018-02-21 00:13:27 --> Hooks Class Initialized
DEBUG - 2018-02-21 00:13:27 --> UTF-8 Support Enabled
INFO - 2018-02-21 00:13:27 --> Utf8 Class Initialized
INFO - 2018-02-21 00:13:27 --> URI Class Initialized
INFO - 2018-02-21 00:13:27 --> Router Class Initialized
INFO - 2018-02-21 00:13:27 --> Output Class Initialized
INFO - 2018-02-21 00:13:27 --> Security Class Initialized
DEBUG - 2018-02-21 00:13:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 00:13:27 --> Input Class Initialized
INFO - 2018-02-21 00:13:27 --> Language Class Initialized
INFO - 2018-02-21 00:13:27 --> Loader Class Initialized
INFO - 2018-02-21 00:13:27 --> Helper loaded: url_helper
INFO - 2018-02-21 00:13:27 --> Helper loaded: form_helper
INFO - 2018-02-21 00:13:27 --> Database Driver Class Initialized
DEBUG - 2018-02-21 00:13:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 00:13:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 00:13:27 --> Form Validation Class Initialized
INFO - 2018-02-21 00:13:27 --> Model Class Initialized
INFO - 2018-02-21 00:13:27 --> Controller Class Initialized
INFO - 2018-02-21 00:13:27 --> Model Class Initialized
INFO - 2018-02-21 00:13:27 --> Model Class Initialized
DEBUG - 2018-02-21 00:13:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-21 00:13:27 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-21 00:13:27 --> Final output sent to browser
DEBUG - 2018-02-21 00:13:27 --> Total execution time: 0.0747
INFO - 2018-02-21 00:13:27 --> Config Class Initialized
INFO - 2018-02-21 00:13:27 --> Hooks Class Initialized
DEBUG - 2018-02-21 00:13:27 --> UTF-8 Support Enabled
INFO - 2018-02-21 00:13:27 --> Utf8 Class Initialized
INFO - 2018-02-21 00:13:27 --> URI Class Initialized
INFO - 2018-02-21 00:13:27 --> Router Class Initialized
INFO - 2018-02-21 00:13:27 --> Output Class Initialized
INFO - 2018-02-21 00:13:27 --> Security Class Initialized
DEBUG - 2018-02-21 00:13:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 00:13:27 --> Input Class Initialized
INFO - 2018-02-21 00:13:27 --> Language Class Initialized
INFO - 2018-02-21 00:13:27 --> Loader Class Initialized
INFO - 2018-02-21 00:13:27 --> Helper loaded: url_helper
INFO - 2018-02-21 00:13:27 --> Helper loaded: form_helper
INFO - 2018-02-21 00:13:27 --> Database Driver Class Initialized
DEBUG - 2018-02-21 00:13:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 00:13:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 00:13:27 --> Form Validation Class Initialized
INFO - 2018-02-21 00:13:27 --> Model Class Initialized
INFO - 2018-02-21 00:13:27 --> Controller Class Initialized
INFO - 2018-02-21 00:13:27 --> Model Class Initialized
INFO - 2018-02-21 00:13:27 --> Model Class Initialized
DEBUG - 2018-02-21 00:13:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-21 00:13:28 --> Config Class Initialized
INFO - 2018-02-21 00:13:28 --> Hooks Class Initialized
DEBUG - 2018-02-21 00:13:28 --> UTF-8 Support Enabled
INFO - 2018-02-21 00:13:28 --> Utf8 Class Initialized
INFO - 2018-02-21 00:13:28 --> URI Class Initialized
INFO - 2018-02-21 00:13:28 --> Router Class Initialized
INFO - 2018-02-21 00:13:28 --> Output Class Initialized
INFO - 2018-02-21 00:13:28 --> Security Class Initialized
DEBUG - 2018-02-21 00:13:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 00:13:28 --> Input Class Initialized
INFO - 2018-02-21 00:13:28 --> Language Class Initialized
INFO - 2018-02-21 00:13:28 --> Loader Class Initialized
INFO - 2018-02-21 00:13:28 --> Helper loaded: url_helper
INFO - 2018-02-21 00:13:28 --> Helper loaded: form_helper
INFO - 2018-02-21 00:13:28 --> Database Driver Class Initialized
DEBUG - 2018-02-21 00:13:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 00:13:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 00:13:28 --> Form Validation Class Initialized
INFO - 2018-02-21 00:13:28 --> Model Class Initialized
INFO - 2018-02-21 00:13:28 --> Controller Class Initialized
INFO - 2018-02-21 00:13:28 --> Model Class Initialized
INFO - 2018-02-21 00:13:28 --> Model Class Initialized
DEBUG - 2018-02-21 00:13:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-21 00:13:28 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-21 00:13:28 --> Final output sent to browser
DEBUG - 2018-02-21 00:13:28 --> Total execution time: 0.0421
INFO - 2018-02-21 00:13:32 --> Config Class Initialized
INFO - 2018-02-21 00:13:32 --> Hooks Class Initialized
DEBUG - 2018-02-21 00:13:32 --> UTF-8 Support Enabled
INFO - 2018-02-21 00:13:32 --> Utf8 Class Initialized
INFO - 2018-02-21 00:13:32 --> URI Class Initialized
INFO - 2018-02-21 00:13:32 --> Router Class Initialized
INFO - 2018-02-21 00:13:32 --> Output Class Initialized
INFO - 2018-02-21 00:13:32 --> Security Class Initialized
DEBUG - 2018-02-21 00:13:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 00:13:32 --> Input Class Initialized
INFO - 2018-02-21 00:13:32 --> Language Class Initialized
INFO - 2018-02-21 00:13:32 --> Loader Class Initialized
INFO - 2018-02-21 00:13:32 --> Helper loaded: url_helper
INFO - 2018-02-21 00:13:32 --> Helper loaded: form_helper
INFO - 2018-02-21 00:13:32 --> Database Driver Class Initialized
DEBUG - 2018-02-21 00:13:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 00:13:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 00:13:32 --> Form Validation Class Initialized
INFO - 2018-02-21 00:13:32 --> Model Class Initialized
INFO - 2018-02-21 00:13:32 --> Controller Class Initialized
INFO - 2018-02-21 00:13:32 --> Model Class Initialized
INFO - 2018-02-21 00:13:32 --> Model Class Initialized
INFO - 2018-02-21 00:13:32 --> Model Class Initialized
INFO - 2018-02-21 00:13:32 --> Model Class Initialized
DEBUG - 2018-02-21 00:13:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-21 00:13:32 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-21 00:13:32 --> Final output sent to browser
DEBUG - 2018-02-21 00:13:32 --> Total execution time: 0.0499
INFO - 2018-02-21 00:13:33 --> Config Class Initialized
INFO - 2018-02-21 00:13:33 --> Hooks Class Initialized
DEBUG - 2018-02-21 00:13:33 --> UTF-8 Support Enabled
INFO - 2018-02-21 00:13:33 --> Utf8 Class Initialized
INFO - 2018-02-21 00:13:33 --> URI Class Initialized
INFO - 2018-02-21 00:13:33 --> Router Class Initialized
INFO - 2018-02-21 00:13:33 --> Output Class Initialized
INFO - 2018-02-21 00:13:33 --> Security Class Initialized
DEBUG - 2018-02-21 00:13:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 00:13:33 --> Input Class Initialized
INFO - 2018-02-21 00:13:33 --> Language Class Initialized
INFO - 2018-02-21 00:13:33 --> Loader Class Initialized
INFO - 2018-02-21 00:13:33 --> Helper loaded: url_helper
INFO - 2018-02-21 00:13:33 --> Helper loaded: form_helper
INFO - 2018-02-21 00:13:33 --> Database Driver Class Initialized
DEBUG - 2018-02-21 00:13:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 00:13:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 00:13:33 --> Form Validation Class Initialized
INFO - 2018-02-21 00:13:33 --> Model Class Initialized
INFO - 2018-02-21 00:13:33 --> Controller Class Initialized
INFO - 2018-02-21 00:13:33 --> Model Class Initialized
INFO - 2018-02-21 00:13:33 --> Model Class Initialized
DEBUG - 2018-02-21 00:13:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-21 00:13:33 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-21 00:13:33 --> Final output sent to browser
DEBUG - 2018-02-21 00:13:33 --> Total execution time: 0.0477
INFO - 2018-02-21 00:13:33 --> Config Class Initialized
INFO - 2018-02-21 00:13:33 --> Hooks Class Initialized
DEBUG - 2018-02-21 00:13:33 --> UTF-8 Support Enabled
INFO - 2018-02-21 00:13:33 --> Utf8 Class Initialized
INFO - 2018-02-21 00:13:33 --> URI Class Initialized
INFO - 2018-02-21 00:13:33 --> Router Class Initialized
INFO - 2018-02-21 00:13:33 --> Output Class Initialized
INFO - 2018-02-21 00:13:33 --> Security Class Initialized
DEBUG - 2018-02-21 00:13:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 00:13:33 --> Input Class Initialized
INFO - 2018-02-21 00:13:33 --> Language Class Initialized
INFO - 2018-02-21 00:13:33 --> Loader Class Initialized
INFO - 2018-02-21 00:13:33 --> Helper loaded: url_helper
INFO - 2018-02-21 00:13:33 --> Helper loaded: form_helper
INFO - 2018-02-21 00:13:33 --> Database Driver Class Initialized
DEBUG - 2018-02-21 00:13:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 00:13:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 00:13:33 --> Form Validation Class Initialized
INFO - 2018-02-21 00:13:33 --> Model Class Initialized
INFO - 2018-02-21 00:13:33 --> Controller Class Initialized
INFO - 2018-02-21 00:13:33 --> Model Class Initialized
INFO - 2018-02-21 00:13:33 --> Model Class Initialized
DEBUG - 2018-02-21 00:13:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-21 00:13:34 --> Config Class Initialized
INFO - 2018-02-21 00:13:34 --> Hooks Class Initialized
DEBUG - 2018-02-21 00:13:34 --> UTF-8 Support Enabled
INFO - 2018-02-21 00:13:34 --> Utf8 Class Initialized
INFO - 2018-02-21 00:13:34 --> URI Class Initialized
INFO - 2018-02-21 00:13:34 --> Router Class Initialized
INFO - 2018-02-21 00:13:34 --> Output Class Initialized
INFO - 2018-02-21 00:13:34 --> Security Class Initialized
DEBUG - 2018-02-21 00:13:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 00:13:34 --> Input Class Initialized
INFO - 2018-02-21 00:13:34 --> Language Class Initialized
INFO - 2018-02-21 00:13:34 --> Loader Class Initialized
INFO - 2018-02-21 00:13:34 --> Helper loaded: url_helper
INFO - 2018-02-21 00:13:34 --> Helper loaded: form_helper
INFO - 2018-02-21 00:13:34 --> Database Driver Class Initialized
DEBUG - 2018-02-21 00:13:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 00:13:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 00:13:34 --> Form Validation Class Initialized
INFO - 2018-02-21 00:13:34 --> Model Class Initialized
INFO - 2018-02-21 00:13:34 --> Controller Class Initialized
INFO - 2018-02-21 00:13:34 --> Model Class Initialized
INFO - 2018-02-21 00:13:34 --> Model Class Initialized
DEBUG - 2018-02-21 00:13:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-21 00:13:34 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-21 00:13:34 --> Final output sent to browser
DEBUG - 2018-02-21 00:13:34 --> Total execution time: 0.0398
INFO - 2018-02-21 00:13:34 --> Config Class Initialized
INFO - 2018-02-21 00:13:34 --> Hooks Class Initialized
DEBUG - 2018-02-21 00:13:34 --> UTF-8 Support Enabled
INFO - 2018-02-21 00:13:34 --> Utf8 Class Initialized
INFO - 2018-02-21 00:13:34 --> URI Class Initialized
INFO - 2018-02-21 00:13:34 --> Router Class Initialized
INFO - 2018-02-21 00:13:34 --> Output Class Initialized
INFO - 2018-02-21 00:13:34 --> Security Class Initialized
DEBUG - 2018-02-21 00:13:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 00:13:34 --> Input Class Initialized
INFO - 2018-02-21 00:13:34 --> Language Class Initialized
INFO - 2018-02-21 00:13:34 --> Loader Class Initialized
INFO - 2018-02-21 00:13:34 --> Helper loaded: url_helper
INFO - 2018-02-21 00:13:34 --> Helper loaded: form_helper
INFO - 2018-02-21 00:13:34 --> Database Driver Class Initialized
DEBUG - 2018-02-21 00:13:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 00:13:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 00:13:34 --> Form Validation Class Initialized
INFO - 2018-02-21 00:13:34 --> Model Class Initialized
INFO - 2018-02-21 00:13:34 --> Controller Class Initialized
INFO - 2018-02-21 00:13:34 --> Model Class Initialized
INFO - 2018-02-21 00:13:34 --> Model Class Initialized
DEBUG - 2018-02-21 00:13:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-21 00:13:35 --> Config Class Initialized
INFO - 2018-02-21 00:13:35 --> Hooks Class Initialized
DEBUG - 2018-02-21 00:13:35 --> UTF-8 Support Enabled
INFO - 2018-02-21 00:13:35 --> Utf8 Class Initialized
INFO - 2018-02-21 00:13:35 --> URI Class Initialized
INFO - 2018-02-21 00:13:35 --> Router Class Initialized
INFO - 2018-02-21 00:13:35 --> Output Class Initialized
INFO - 2018-02-21 00:13:35 --> Security Class Initialized
DEBUG - 2018-02-21 00:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 00:13:35 --> Input Class Initialized
INFO - 2018-02-21 00:13:35 --> Language Class Initialized
INFO - 2018-02-21 00:13:35 --> Loader Class Initialized
INFO - 2018-02-21 00:13:35 --> Helper loaded: url_helper
INFO - 2018-02-21 00:13:35 --> Helper loaded: form_helper
INFO - 2018-02-21 00:13:35 --> Database Driver Class Initialized
DEBUG - 2018-02-21 00:13:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 00:13:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 00:13:35 --> Form Validation Class Initialized
INFO - 2018-02-21 00:13:35 --> Model Class Initialized
INFO - 2018-02-21 00:13:35 --> Controller Class Initialized
INFO - 2018-02-21 00:13:35 --> Model Class Initialized
INFO - 2018-02-21 00:13:35 --> Model Class Initialized
INFO - 2018-02-21 00:13:35 --> Model Class Initialized
INFO - 2018-02-21 00:13:35 --> Model Class Initialized
INFO - 2018-02-21 00:13:35 --> Model Class Initialized
DEBUG - 2018-02-21 00:13:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-21 00:13:35 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-21 00:13:35 --> Final output sent to browser
DEBUG - 2018-02-21 00:13:35 --> Total execution time: 0.0558
INFO - 2018-02-21 00:13:35 --> Config Class Initialized
INFO - 2018-02-21 00:13:35 --> Hooks Class Initialized
DEBUG - 2018-02-21 00:13:35 --> UTF-8 Support Enabled
INFO - 2018-02-21 00:13:35 --> Utf8 Class Initialized
INFO - 2018-02-21 00:13:35 --> URI Class Initialized
INFO - 2018-02-21 00:13:35 --> Router Class Initialized
INFO - 2018-02-21 00:13:35 --> Output Class Initialized
INFO - 2018-02-21 00:13:35 --> Security Class Initialized
DEBUG - 2018-02-21 00:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 00:13:35 --> Input Class Initialized
INFO - 2018-02-21 00:13:35 --> Language Class Initialized
INFO - 2018-02-21 00:13:35 --> Loader Class Initialized
INFO - 2018-02-21 00:13:35 --> Helper loaded: url_helper
INFO - 2018-02-21 00:13:35 --> Helper loaded: form_helper
INFO - 2018-02-21 00:13:35 --> Database Driver Class Initialized
DEBUG - 2018-02-21 00:13:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 00:13:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 00:13:35 --> Form Validation Class Initialized
INFO - 2018-02-21 00:13:35 --> Model Class Initialized
INFO - 2018-02-21 00:13:35 --> Controller Class Initialized
INFO - 2018-02-21 00:13:35 --> Model Class Initialized
INFO - 2018-02-21 00:13:35 --> Model Class Initialized
INFO - 2018-02-21 00:13:35 --> Model Class Initialized
INFO - 2018-02-21 00:13:35 --> Model Class Initialized
INFO - 2018-02-21 00:13:35 --> Model Class Initialized
DEBUG - 2018-02-21 00:13:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-21 00:13:35 --> Config Class Initialized
INFO - 2018-02-21 00:13:35 --> Hooks Class Initialized
DEBUG - 2018-02-21 00:13:35 --> UTF-8 Support Enabled
INFO - 2018-02-21 00:13:35 --> Utf8 Class Initialized
INFO - 2018-02-21 00:13:35 --> URI Class Initialized
DEBUG - 2018-02-21 00:13:35 --> No URI present. Default controller set.
INFO - 2018-02-21 00:13:35 --> Router Class Initialized
INFO - 2018-02-21 00:13:35 --> Output Class Initialized
INFO - 2018-02-21 00:13:35 --> Security Class Initialized
DEBUG - 2018-02-21 00:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 00:13:35 --> Input Class Initialized
INFO - 2018-02-21 00:13:35 --> Language Class Initialized
INFO - 2018-02-21 00:13:35 --> Loader Class Initialized
INFO - 2018-02-21 00:13:35 --> Helper loaded: url_helper
INFO - 2018-02-21 00:13:35 --> Helper loaded: form_helper
INFO - 2018-02-21 00:13:35 --> Database Driver Class Initialized
DEBUG - 2018-02-21 00:13:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 00:13:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 00:13:35 --> Form Validation Class Initialized
INFO - 2018-02-21 00:13:35 --> Model Class Initialized
INFO - 2018-02-21 00:13:35 --> Controller Class Initialized
INFO - 2018-02-21 00:13:35 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-21 00:13:35 --> Final output sent to browser
DEBUG - 2018-02-21 00:13:35 --> Total execution time: 0.0392
INFO - 2018-02-21 00:13:36 --> Config Class Initialized
INFO - 2018-02-21 00:13:36 --> Hooks Class Initialized
DEBUG - 2018-02-21 00:13:36 --> UTF-8 Support Enabled
INFO - 2018-02-21 00:13:36 --> Utf8 Class Initialized
INFO - 2018-02-21 00:13:36 --> URI Class Initialized
INFO - 2018-02-21 00:13:36 --> Router Class Initialized
INFO - 2018-02-21 00:13:36 --> Output Class Initialized
INFO - 2018-02-21 00:13:36 --> Security Class Initialized
DEBUG - 2018-02-21 00:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 00:13:36 --> Input Class Initialized
INFO - 2018-02-21 00:13:36 --> Language Class Initialized
INFO - 2018-02-21 00:13:36 --> Loader Class Initialized
INFO - 2018-02-21 00:13:36 --> Helper loaded: url_helper
INFO - 2018-02-21 00:13:36 --> Helper loaded: form_helper
INFO - 2018-02-21 00:13:36 --> Database Driver Class Initialized
DEBUG - 2018-02-21 00:13:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 00:13:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 00:13:36 --> Form Validation Class Initialized
INFO - 2018-02-21 00:13:36 --> Model Class Initialized
INFO - 2018-02-21 00:13:36 --> Controller Class Initialized
INFO - 2018-02-21 00:13:36 --> Model Class Initialized
INFO - 2018-02-21 00:13:36 --> Model Class Initialized
INFO - 2018-02-21 00:13:36 --> Model Class Initialized
INFO - 2018-02-21 00:13:36 --> Model Class Initialized
INFO - 2018-02-21 00:13:36 --> Model Class Initialized
DEBUG - 2018-02-21 00:13:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-21 00:13:44 --> Config Class Initialized
INFO - 2018-02-21 00:13:44 --> Hooks Class Initialized
DEBUG - 2018-02-21 00:13:44 --> UTF-8 Support Enabled
INFO - 2018-02-21 00:13:44 --> Utf8 Class Initialized
INFO - 2018-02-21 00:13:44 --> URI Class Initialized
INFO - 2018-02-21 00:13:44 --> Router Class Initialized
INFO - 2018-02-21 00:13:44 --> Output Class Initialized
INFO - 2018-02-21 00:13:44 --> Security Class Initialized
DEBUG - 2018-02-21 00:13:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 00:13:44 --> Input Class Initialized
INFO - 2018-02-21 00:13:44 --> Language Class Initialized
INFO - 2018-02-21 00:13:44 --> Loader Class Initialized
INFO - 2018-02-21 00:13:44 --> Helper loaded: url_helper
INFO - 2018-02-21 00:13:44 --> Helper loaded: form_helper
INFO - 2018-02-21 00:13:45 --> Database Driver Class Initialized
DEBUG - 2018-02-21 00:13:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 00:13:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 00:13:45 --> Form Validation Class Initialized
INFO - 2018-02-21 00:13:45 --> Model Class Initialized
INFO - 2018-02-21 00:13:45 --> Controller Class Initialized
INFO - 2018-02-21 00:13:45 --> Model Class Initialized
DEBUG - 2018-02-21 00:13:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-21 00:13:45 --> Config Class Initialized
INFO - 2018-02-21 00:13:45 --> Hooks Class Initialized
DEBUG - 2018-02-21 00:13:45 --> UTF-8 Support Enabled
INFO - 2018-02-21 00:13:45 --> Utf8 Class Initialized
INFO - 2018-02-21 00:13:45 --> URI Class Initialized
INFO - 2018-02-21 00:13:45 --> Router Class Initialized
INFO - 2018-02-21 00:13:45 --> Output Class Initialized
INFO - 2018-02-21 00:13:45 --> Security Class Initialized
DEBUG - 2018-02-21 00:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 00:13:45 --> Input Class Initialized
INFO - 2018-02-21 00:13:45 --> Language Class Initialized
INFO - 2018-02-21 00:13:45 --> Loader Class Initialized
INFO - 2018-02-21 00:13:45 --> Helper loaded: url_helper
INFO - 2018-02-21 00:13:45 --> Helper loaded: form_helper
INFO - 2018-02-21 00:13:45 --> Database Driver Class Initialized
DEBUG - 2018-02-21 00:13:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 00:13:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 00:13:45 --> Form Validation Class Initialized
INFO - 2018-02-21 00:13:45 --> Model Class Initialized
INFO - 2018-02-21 00:13:45 --> Controller Class Initialized
INFO - 2018-02-21 00:13:45 --> Model Class Initialized
DEBUG - 2018-02-21 00:13:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-21 00:13:45 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-21 00:13:45 --> Final output sent to browser
DEBUG - 2018-02-21 00:13:45 --> Total execution time: 0.0472
INFO - 2018-02-21 00:13:50 --> Config Class Initialized
INFO - 2018-02-21 00:13:50 --> Hooks Class Initialized
DEBUG - 2018-02-21 00:13:50 --> UTF-8 Support Enabled
INFO - 2018-02-21 00:13:50 --> Utf8 Class Initialized
INFO - 2018-02-21 00:13:50 --> URI Class Initialized
INFO - 2018-02-21 00:13:50 --> Router Class Initialized
INFO - 2018-02-21 00:13:50 --> Output Class Initialized
INFO - 2018-02-21 00:13:50 --> Security Class Initialized
DEBUG - 2018-02-21 00:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 00:13:50 --> Input Class Initialized
INFO - 2018-02-21 00:13:50 --> Language Class Initialized
INFO - 2018-02-21 00:13:50 --> Loader Class Initialized
INFO - 2018-02-21 00:13:50 --> Helper loaded: url_helper
INFO - 2018-02-21 00:13:50 --> Helper loaded: form_helper
INFO - 2018-02-21 00:13:50 --> Database Driver Class Initialized
DEBUG - 2018-02-21 00:13:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 00:13:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 00:13:50 --> Form Validation Class Initialized
INFO - 2018-02-21 00:13:50 --> Model Class Initialized
INFO - 2018-02-21 00:13:50 --> Controller Class Initialized
INFO - 2018-02-21 00:13:50 --> Model Class Initialized
DEBUG - 2018-02-21 00:13:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-21 00:13:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-21 00:13:50 --> Config Class Initialized
INFO - 2018-02-21 00:13:50 --> Hooks Class Initialized
DEBUG - 2018-02-21 00:13:50 --> UTF-8 Support Enabled
INFO - 2018-02-21 00:13:50 --> Utf8 Class Initialized
INFO - 2018-02-21 00:13:50 --> URI Class Initialized
INFO - 2018-02-21 00:13:50 --> Router Class Initialized
INFO - 2018-02-21 00:13:50 --> Output Class Initialized
INFO - 2018-02-21 00:13:50 --> Config Class Initialized
INFO - 2018-02-21 00:13:50 --> Hooks Class Initialized
INFO - 2018-02-21 00:13:50 --> Security Class Initialized
DEBUG - 2018-02-21 00:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 00:13:50 --> Input Class Initialized
DEBUG - 2018-02-21 00:13:50 --> UTF-8 Support Enabled
INFO - 2018-02-21 00:13:50 --> Utf8 Class Initialized
INFO - 2018-02-21 00:13:50 --> Language Class Initialized
INFO - 2018-02-21 00:13:50 --> URI Class Initialized
DEBUG - 2018-02-21 00:13:50 --> No URI present. Default controller set.
INFO - 2018-02-21 00:13:50 --> Loader Class Initialized
INFO - 2018-02-21 00:13:50 --> Router Class Initialized
INFO - 2018-02-21 00:13:50 --> Helper loaded: url_helper
INFO - 2018-02-21 00:13:50 --> Output Class Initialized
INFO - 2018-02-21 00:13:50 --> Helper loaded: form_helper
INFO - 2018-02-21 00:13:50 --> Security Class Initialized
DEBUG - 2018-02-21 00:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 00:13:50 --> Input Class Initialized
INFO - 2018-02-21 00:13:50 --> Language Class Initialized
INFO - 2018-02-21 00:13:50 --> Loader Class Initialized
INFO - 2018-02-21 00:13:50 --> Database Driver Class Initialized
INFO - 2018-02-21 00:13:50 --> Helper loaded: url_helper
INFO - 2018-02-21 00:13:50 --> Helper loaded: form_helper
DEBUG - 2018-02-21 00:13:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 00:13:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 00:13:50 --> Form Validation Class Initialized
INFO - 2018-02-21 00:13:50 --> Database Driver Class Initialized
INFO - 2018-02-21 00:13:50 --> Model Class Initialized
INFO - 2018-02-21 00:13:50 --> Controller Class Initialized
INFO - 2018-02-21 00:13:50 --> Model Class Initialized
DEBUG - 2018-02-21 00:13:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-21 00:13:50 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2018-02-21 00:13:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 00:13:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 00:13:50 --> Form Validation Class Initialized
INFO - 2018-02-21 00:13:50 --> Model Class Initialized
INFO - 2018-02-21 00:13:50 --> Controller Class Initialized
INFO - 2018-02-21 00:13:50 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-21 00:13:50 --> Final output sent to browser
DEBUG - 2018-02-21 00:13:50 --> Total execution time: 0.1347
INFO - 2018-02-21 00:13:50 --> Config Class Initialized
INFO - 2018-02-21 00:13:50 --> Hooks Class Initialized
DEBUG - 2018-02-21 00:13:50 --> UTF-8 Support Enabled
INFO - 2018-02-21 00:13:50 --> Utf8 Class Initialized
INFO - 2018-02-21 00:13:50 --> URI Class Initialized
INFO - 2018-02-21 00:13:50 --> Router Class Initialized
INFO - 2018-02-21 00:13:50 --> Output Class Initialized
INFO - 2018-02-21 00:13:50 --> Security Class Initialized
DEBUG - 2018-02-21 00:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 00:13:50 --> Input Class Initialized
INFO - 2018-02-21 00:13:50 --> Language Class Initialized
INFO - 2018-02-21 00:13:50 --> Loader Class Initialized
INFO - 2018-02-21 00:13:50 --> Helper loaded: url_helper
INFO - 2018-02-21 00:13:50 --> Helper loaded: form_helper
INFO - 2018-02-21 00:13:50 --> Database Driver Class Initialized
DEBUG - 2018-02-21 00:13:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 00:13:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 00:13:50 --> Form Validation Class Initialized
INFO - 2018-02-21 00:13:50 --> Model Class Initialized
INFO - 2018-02-21 00:13:50 --> Controller Class Initialized
INFO - 2018-02-21 00:13:50 --> Model Class Initialized
INFO - 2018-02-21 00:13:50 --> Model Class Initialized
INFO - 2018-02-21 00:13:50 --> Model Class Initialized
INFO - 2018-02-21 00:13:50 --> Model Class Initialized
INFO - 2018-02-21 00:13:50 --> Model Class Initialized
DEBUG - 2018-02-21 00:13:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-21 00:13:52 --> Config Class Initialized
INFO - 2018-02-21 00:13:52 --> Hooks Class Initialized
DEBUG - 2018-02-21 00:13:52 --> UTF-8 Support Enabled
INFO - 2018-02-21 00:13:52 --> Utf8 Class Initialized
INFO - 2018-02-21 00:13:52 --> URI Class Initialized
INFO - 2018-02-21 00:13:52 --> Router Class Initialized
INFO - 2018-02-21 00:13:52 --> Output Class Initialized
INFO - 2018-02-21 00:13:52 --> Security Class Initialized
DEBUG - 2018-02-21 00:13:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 00:13:52 --> Input Class Initialized
INFO - 2018-02-21 00:13:52 --> Language Class Initialized
INFO - 2018-02-21 00:13:52 --> Loader Class Initialized
INFO - 2018-02-21 00:13:52 --> Helper loaded: url_helper
INFO - 2018-02-21 00:13:52 --> Helper loaded: form_helper
INFO - 2018-02-21 00:13:52 --> Database Driver Class Initialized
DEBUG - 2018-02-21 00:13:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 00:13:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 00:13:52 --> Form Validation Class Initialized
INFO - 2018-02-21 00:13:52 --> Model Class Initialized
INFO - 2018-02-21 00:13:52 --> Controller Class Initialized
INFO - 2018-02-21 00:13:52 --> Model Class Initialized
INFO - 2018-02-21 00:13:52 --> Model Class Initialized
INFO - 2018-02-21 00:13:52 --> Model Class Initialized
INFO - 2018-02-21 00:13:52 --> Model Class Initialized
INFO - 2018-02-21 00:13:52 --> Model Class Initialized
DEBUG - 2018-02-21 00:13:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-21 00:13:52 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-21 00:13:52 --> Final output sent to browser
DEBUG - 2018-02-21 00:13:52 --> Total execution time: 0.0430
INFO - 2018-02-21 00:13:52 --> Config Class Initialized
INFO - 2018-02-21 00:13:52 --> Hooks Class Initialized
DEBUG - 2018-02-21 00:13:52 --> UTF-8 Support Enabled
INFO - 2018-02-21 00:13:52 --> Utf8 Class Initialized
INFO - 2018-02-21 00:13:52 --> URI Class Initialized
INFO - 2018-02-21 00:13:52 --> Router Class Initialized
INFO - 2018-02-21 00:13:52 --> Output Class Initialized
INFO - 2018-02-21 00:13:52 --> Security Class Initialized
DEBUG - 2018-02-21 00:13:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 00:13:52 --> Input Class Initialized
INFO - 2018-02-21 00:13:52 --> Language Class Initialized
INFO - 2018-02-21 00:13:52 --> Loader Class Initialized
INFO - 2018-02-21 00:13:52 --> Helper loaded: url_helper
INFO - 2018-02-21 00:13:52 --> Helper loaded: form_helper
INFO - 2018-02-21 00:13:52 --> Database Driver Class Initialized
DEBUG - 2018-02-21 00:13:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 00:13:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 00:13:52 --> Form Validation Class Initialized
INFO - 2018-02-21 00:13:52 --> Model Class Initialized
INFO - 2018-02-21 00:13:52 --> Controller Class Initialized
INFO - 2018-02-21 00:13:52 --> Model Class Initialized
INFO - 2018-02-21 00:13:52 --> Model Class Initialized
INFO - 2018-02-21 00:13:52 --> Model Class Initialized
INFO - 2018-02-21 00:13:52 --> Model Class Initialized
INFO - 2018-02-21 00:13:52 --> Model Class Initialized
DEBUG - 2018-02-21 00:13:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-21 00:13:53 --> Config Class Initialized
INFO - 2018-02-21 00:13:53 --> Hooks Class Initialized
DEBUG - 2018-02-21 00:13:53 --> UTF-8 Support Enabled
INFO - 2018-02-21 00:13:53 --> Utf8 Class Initialized
INFO - 2018-02-21 00:13:53 --> URI Class Initialized
INFO - 2018-02-21 00:13:53 --> Router Class Initialized
INFO - 2018-02-21 00:13:53 --> Output Class Initialized
INFO - 2018-02-21 00:13:53 --> Security Class Initialized
DEBUG - 2018-02-21 00:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 00:13:53 --> Input Class Initialized
INFO - 2018-02-21 00:13:53 --> Language Class Initialized
INFO - 2018-02-21 00:13:53 --> Loader Class Initialized
INFO - 2018-02-21 00:13:53 --> Helper loaded: url_helper
INFO - 2018-02-21 00:13:53 --> Helper loaded: form_helper
INFO - 2018-02-21 00:13:53 --> Database Driver Class Initialized
DEBUG - 2018-02-21 00:13:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 00:13:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 00:13:53 --> Form Validation Class Initialized
INFO - 2018-02-21 00:13:53 --> Model Class Initialized
INFO - 2018-02-21 00:13:53 --> Controller Class Initialized
INFO - 2018-02-21 00:13:53 --> Model Class Initialized
INFO - 2018-02-21 00:13:53 --> Model Class Initialized
INFO - 2018-02-21 00:13:53 --> Model Class Initialized
INFO - 2018-02-21 00:13:53 --> Model Class Initialized
INFO - 2018-02-21 00:13:53 --> Model Class Initialized
DEBUG - 2018-02-21 00:13:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-21 00:13:53 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-21 00:13:53 --> Final output sent to browser
DEBUG - 2018-02-21 00:13:53 --> Total execution time: 0.0547
INFO - 2018-02-21 00:13:53 --> Config Class Initialized
INFO - 2018-02-21 00:13:53 --> Hooks Class Initialized
DEBUG - 2018-02-21 00:13:53 --> UTF-8 Support Enabled
INFO - 2018-02-21 00:13:53 --> Utf8 Class Initialized
INFO - 2018-02-21 00:13:53 --> URI Class Initialized
INFO - 2018-02-21 00:13:53 --> Router Class Initialized
INFO - 2018-02-21 00:13:53 --> Output Class Initialized
INFO - 2018-02-21 00:13:53 --> Security Class Initialized
DEBUG - 2018-02-21 00:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-21 00:13:53 --> Input Class Initialized
INFO - 2018-02-21 00:13:53 --> Language Class Initialized
INFO - 2018-02-21 00:13:53 --> Loader Class Initialized
INFO - 2018-02-21 00:13:53 --> Helper loaded: url_helper
INFO - 2018-02-21 00:13:53 --> Helper loaded: form_helper
INFO - 2018-02-21 00:13:53 --> Database Driver Class Initialized
DEBUG - 2018-02-21 00:13:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-21 00:13:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-21 00:13:53 --> Form Validation Class Initialized
INFO - 2018-02-21 00:13:53 --> Model Class Initialized
INFO - 2018-02-21 00:13:53 --> Controller Class Initialized
INFO - 2018-02-21 00:13:53 --> Model Class Initialized
INFO - 2018-02-21 00:13:53 --> Model Class Initialized
INFO - 2018-02-21 00:13:53 --> Model Class Initialized
INFO - 2018-02-21 00:13:53 --> Model Class Initialized
INFO - 2018-02-21 00:13:53 --> Model Class Initialized
DEBUG - 2018-02-21 00:13:53 --> Form_validation class already loaded. Second attempt ignored.
