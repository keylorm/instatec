<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-03-07 23:25:41 --> Config Class Initialized
INFO - 2018-03-07 23:25:41 --> Hooks Class Initialized
DEBUG - 2018-03-07 23:25:41 --> UTF-8 Support Enabled
INFO - 2018-03-07 23:25:41 --> Utf8 Class Initialized
INFO - 2018-03-07 23:25:41 --> URI Class Initialized
DEBUG - 2018-03-07 23:25:41 --> No URI present. Default controller set.
INFO - 2018-03-07 23:25:41 --> Router Class Initialized
INFO - 2018-03-07 23:25:41 --> Output Class Initialized
INFO - 2018-03-07 23:25:41 --> Security Class Initialized
DEBUG - 2018-03-07 23:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 23:25:41 --> Input Class Initialized
INFO - 2018-03-07 23:25:41 --> Language Class Initialized
INFO - 2018-03-07 23:25:41 --> Loader Class Initialized
INFO - 2018-03-07 23:25:41 --> Helper loaded: url_helper
INFO - 2018-03-07 23:25:41 --> Helper loaded: form_helper
INFO - 2018-03-07 23:25:41 --> Database Driver Class Initialized
DEBUG - 2018-03-07 23:25:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-07 23:25:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-07 23:25:41 --> Form Validation Class Initialized
INFO - 2018-03-07 23:25:41 --> Model Class Initialized
INFO - 2018-03-07 23:25:41 --> Controller Class Initialized
INFO - 2018-03-07 23:25:41 --> Config Class Initialized
INFO - 2018-03-07 23:25:41 --> Hooks Class Initialized
DEBUG - 2018-03-07 23:25:41 --> UTF-8 Support Enabled
INFO - 2018-03-07 23:25:41 --> Utf8 Class Initialized
INFO - 2018-03-07 23:25:41 --> URI Class Initialized
INFO - 2018-03-07 23:25:41 --> Router Class Initialized
INFO - 2018-03-07 23:25:41 --> Output Class Initialized
INFO - 2018-03-07 23:25:41 --> Security Class Initialized
DEBUG - 2018-03-07 23:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 23:25:41 --> Input Class Initialized
INFO - 2018-03-07 23:25:41 --> Language Class Initialized
INFO - 2018-03-07 23:25:41 --> Loader Class Initialized
INFO - 2018-03-07 23:25:41 --> Helper loaded: url_helper
INFO - 2018-03-07 23:25:41 --> Helper loaded: form_helper
INFO - 2018-03-07 23:25:41 --> Database Driver Class Initialized
DEBUG - 2018-03-07 23:25:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-07 23:25:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-07 23:25:41 --> Form Validation Class Initialized
INFO - 2018-03-07 23:25:41 --> Model Class Initialized
INFO - 2018-03-07 23:25:41 --> Controller Class Initialized
INFO - 2018-03-07 23:25:41 --> Model Class Initialized
DEBUG - 2018-03-07 23:25:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-07 23:25:41 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-07 23:25:41 --> Final output sent to browser
DEBUG - 2018-03-07 23:25:41 --> Total execution time: 0.0514
INFO - 2018-03-07 23:25:42 --> Config Class Initialized
INFO - 2018-03-07 23:25:42 --> Hooks Class Initialized
DEBUG - 2018-03-07 23:25:42 --> UTF-8 Support Enabled
INFO - 2018-03-07 23:25:42 --> Utf8 Class Initialized
INFO - 2018-03-07 23:25:42 --> URI Class Initialized
INFO - 2018-03-07 23:25:42 --> Router Class Initialized
INFO - 2018-03-07 23:25:42 --> Output Class Initialized
INFO - 2018-03-07 23:25:42 --> Security Class Initialized
DEBUG - 2018-03-07 23:25:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 23:25:42 --> Input Class Initialized
INFO - 2018-03-07 23:25:42 --> Language Class Initialized
INFO - 2018-03-07 23:25:42 --> Loader Class Initialized
INFO - 2018-03-07 23:25:42 --> Helper loaded: url_helper
INFO - 2018-03-07 23:25:42 --> Helper loaded: form_helper
INFO - 2018-03-07 23:25:42 --> Database Driver Class Initialized
DEBUG - 2018-03-07 23:25:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-07 23:25:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-07 23:25:42 --> Form Validation Class Initialized
INFO - 2018-03-07 23:25:42 --> Model Class Initialized
INFO - 2018-03-07 23:25:42 --> Controller Class Initialized
INFO - 2018-03-07 23:25:42 --> Model Class Initialized
DEBUG - 2018-03-07 23:25:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-07 23:25:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-07 23:25:42 --> Config Class Initialized
INFO - 2018-03-07 23:25:42 --> Hooks Class Initialized
DEBUG - 2018-03-07 23:25:43 --> UTF-8 Support Enabled
INFO - 2018-03-07 23:25:43 --> Utf8 Class Initialized
INFO - 2018-03-07 23:25:43 --> URI Class Initialized
DEBUG - 2018-03-07 23:25:43 --> No URI present. Default controller set.
INFO - 2018-03-07 23:25:43 --> Router Class Initialized
INFO - 2018-03-07 23:25:43 --> Output Class Initialized
INFO - 2018-03-07 23:25:43 --> Security Class Initialized
DEBUG - 2018-03-07 23:25:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 23:25:43 --> Input Class Initialized
INFO - 2018-03-07 23:25:43 --> Language Class Initialized
INFO - 2018-03-07 23:25:43 --> Loader Class Initialized
INFO - 2018-03-07 23:25:43 --> Helper loaded: url_helper
INFO - 2018-03-07 23:25:43 --> Helper loaded: form_helper
INFO - 2018-03-07 23:25:43 --> Database Driver Class Initialized
DEBUG - 2018-03-07 23:25:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-07 23:25:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-07 23:25:43 --> Form Validation Class Initialized
INFO - 2018-03-07 23:25:43 --> Model Class Initialized
INFO - 2018-03-07 23:25:43 --> Controller Class Initialized
INFO - 2018-03-07 23:25:43 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-07 23:25:43 --> Final output sent to browser
DEBUG - 2018-03-07 23:25:43 --> Total execution time: 0.0449
INFO - 2018-03-07 23:25:43 --> Config Class Initialized
INFO - 2018-03-07 23:25:43 --> Hooks Class Initialized
DEBUG - 2018-03-07 23:25:43 --> UTF-8 Support Enabled
INFO - 2018-03-07 23:25:43 --> Utf8 Class Initialized
INFO - 2018-03-07 23:25:43 --> URI Class Initialized
INFO - 2018-03-07 23:25:43 --> Router Class Initialized
INFO - 2018-03-07 23:25:43 --> Output Class Initialized
INFO - 2018-03-07 23:25:43 --> Security Class Initialized
DEBUG - 2018-03-07 23:25:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 23:25:43 --> Input Class Initialized
INFO - 2018-03-07 23:25:43 --> Language Class Initialized
INFO - 2018-03-07 23:25:43 --> Loader Class Initialized
INFO - 2018-03-07 23:25:43 --> Helper loaded: url_helper
INFO - 2018-03-07 23:25:43 --> Helper loaded: form_helper
INFO - 2018-03-07 23:25:43 --> Database Driver Class Initialized
DEBUG - 2018-03-07 23:25:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-07 23:25:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-07 23:25:43 --> Form Validation Class Initialized
INFO - 2018-03-07 23:25:43 --> Model Class Initialized
INFO - 2018-03-07 23:25:43 --> Controller Class Initialized
INFO - 2018-03-07 23:25:43 --> Model Class Initialized
INFO - 2018-03-07 23:25:43 --> Model Class Initialized
INFO - 2018-03-07 23:25:43 --> Model Class Initialized
INFO - 2018-03-07 23:25:43 --> Model Class Initialized
INFO - 2018-03-07 23:25:43 --> Model Class Initialized
DEBUG - 2018-03-07 23:25:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-07 23:25:46 --> Config Class Initialized
INFO - 2018-03-07 23:25:46 --> Hooks Class Initialized
DEBUG - 2018-03-07 23:25:46 --> UTF-8 Support Enabled
INFO - 2018-03-07 23:25:46 --> Utf8 Class Initialized
INFO - 2018-03-07 23:25:46 --> URI Class Initialized
INFO - 2018-03-07 23:25:46 --> Router Class Initialized
INFO - 2018-03-07 23:25:46 --> Output Class Initialized
INFO - 2018-03-07 23:25:46 --> Security Class Initialized
DEBUG - 2018-03-07 23:25:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 23:25:46 --> Input Class Initialized
INFO - 2018-03-07 23:25:46 --> Language Class Initialized
INFO - 2018-03-07 23:25:46 --> Loader Class Initialized
INFO - 2018-03-07 23:25:46 --> Helper loaded: url_helper
INFO - 2018-03-07 23:25:46 --> Helper loaded: form_helper
INFO - 2018-03-07 23:25:46 --> Database Driver Class Initialized
DEBUG - 2018-03-07 23:25:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-07 23:25:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-07 23:25:46 --> Form Validation Class Initialized
INFO - 2018-03-07 23:25:46 --> Model Class Initialized
INFO - 2018-03-07 23:25:46 --> Controller Class Initialized
INFO - 2018-03-07 23:25:46 --> Model Class Initialized
INFO - 2018-03-07 23:25:46 --> Model Class Initialized
DEBUG - 2018-03-07 23:25:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-07 23:25:46 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-07 23:25:46 --> Final output sent to browser
DEBUG - 2018-03-07 23:25:46 --> Total execution time: 0.0500
INFO - 2018-03-07 23:25:46 --> Config Class Initialized
INFO - 2018-03-07 23:25:46 --> Hooks Class Initialized
DEBUG - 2018-03-07 23:25:46 --> UTF-8 Support Enabled
INFO - 2018-03-07 23:25:46 --> Utf8 Class Initialized
INFO - 2018-03-07 23:25:46 --> URI Class Initialized
INFO - 2018-03-07 23:25:46 --> Router Class Initialized
INFO - 2018-03-07 23:25:46 --> Output Class Initialized
INFO - 2018-03-07 23:25:46 --> Security Class Initialized
DEBUG - 2018-03-07 23:25:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 23:25:46 --> Input Class Initialized
INFO - 2018-03-07 23:25:46 --> Language Class Initialized
INFO - 2018-03-07 23:25:46 --> Loader Class Initialized
INFO - 2018-03-07 23:25:46 --> Helper loaded: url_helper
INFO - 2018-03-07 23:25:46 --> Helper loaded: form_helper
INFO - 2018-03-07 23:25:46 --> Database Driver Class Initialized
DEBUG - 2018-03-07 23:25:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-07 23:25:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-07 23:25:46 --> Form Validation Class Initialized
INFO - 2018-03-07 23:25:46 --> Model Class Initialized
INFO - 2018-03-07 23:25:46 --> Controller Class Initialized
INFO - 2018-03-07 23:25:46 --> Model Class Initialized
INFO - 2018-03-07 23:25:46 --> Model Class Initialized
DEBUG - 2018-03-07 23:25:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-07 23:25:47 --> Config Class Initialized
INFO - 2018-03-07 23:25:47 --> Hooks Class Initialized
DEBUG - 2018-03-07 23:25:47 --> UTF-8 Support Enabled
INFO - 2018-03-07 23:25:47 --> Utf8 Class Initialized
INFO - 2018-03-07 23:25:47 --> URI Class Initialized
INFO - 2018-03-07 23:25:47 --> Router Class Initialized
INFO - 2018-03-07 23:25:47 --> Output Class Initialized
INFO - 2018-03-07 23:25:47 --> Security Class Initialized
DEBUG - 2018-03-07 23:25:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 23:25:47 --> Input Class Initialized
INFO - 2018-03-07 23:25:47 --> Language Class Initialized
INFO - 2018-03-07 23:25:47 --> Loader Class Initialized
INFO - 2018-03-07 23:25:47 --> Helper loaded: url_helper
INFO - 2018-03-07 23:25:47 --> Helper loaded: form_helper
INFO - 2018-03-07 23:25:47 --> Database Driver Class Initialized
DEBUG - 2018-03-07 23:25:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-07 23:25:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-07 23:25:47 --> Form Validation Class Initialized
INFO - 2018-03-07 23:25:47 --> Model Class Initialized
INFO - 2018-03-07 23:25:47 --> Controller Class Initialized
INFO - 2018-03-07 23:25:47 --> Model Class Initialized
INFO - 2018-03-07 23:25:47 --> Model Class Initialized
DEBUG - 2018-03-07 23:25:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-07 23:25:47 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-07 23:25:47 --> Final output sent to browser
DEBUG - 2018-03-07 23:25:47 --> Total execution time: 0.0491
INFO - 2018-03-07 23:25:47 --> Config Class Initialized
INFO - 2018-03-07 23:25:47 --> Hooks Class Initialized
DEBUG - 2018-03-07 23:25:47 --> UTF-8 Support Enabled
INFO - 2018-03-07 23:25:47 --> Utf8 Class Initialized
INFO - 2018-03-07 23:25:47 --> URI Class Initialized
INFO - 2018-03-07 23:25:47 --> Router Class Initialized
INFO - 2018-03-07 23:25:47 --> Output Class Initialized
INFO - 2018-03-07 23:25:47 --> Security Class Initialized
DEBUG - 2018-03-07 23:25:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 23:25:47 --> Input Class Initialized
INFO - 2018-03-07 23:25:47 --> Language Class Initialized
INFO - 2018-03-07 23:25:47 --> Loader Class Initialized
INFO - 2018-03-07 23:25:47 --> Helper loaded: url_helper
INFO - 2018-03-07 23:25:47 --> Helper loaded: form_helper
INFO - 2018-03-07 23:25:47 --> Database Driver Class Initialized
DEBUG - 2018-03-07 23:25:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-07 23:25:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-07 23:25:47 --> Form Validation Class Initialized
INFO - 2018-03-07 23:25:47 --> Model Class Initialized
INFO - 2018-03-07 23:25:47 --> Controller Class Initialized
INFO - 2018-03-07 23:25:47 --> Model Class Initialized
INFO - 2018-03-07 23:25:47 --> Model Class Initialized
DEBUG - 2018-03-07 23:25:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-07 23:25:48 --> Config Class Initialized
INFO - 2018-03-07 23:25:48 --> Hooks Class Initialized
DEBUG - 2018-03-07 23:25:48 --> UTF-8 Support Enabled
INFO - 2018-03-07 23:25:48 --> Utf8 Class Initialized
INFO - 2018-03-07 23:25:48 --> URI Class Initialized
INFO - 2018-03-07 23:25:48 --> Router Class Initialized
INFO - 2018-03-07 23:25:48 --> Output Class Initialized
INFO - 2018-03-07 23:25:48 --> Security Class Initialized
DEBUG - 2018-03-07 23:25:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 23:25:48 --> Input Class Initialized
INFO - 2018-03-07 23:25:48 --> Language Class Initialized
INFO - 2018-03-07 23:25:48 --> Loader Class Initialized
INFO - 2018-03-07 23:25:48 --> Helper loaded: url_helper
INFO - 2018-03-07 23:25:48 --> Helper loaded: form_helper
INFO - 2018-03-07 23:25:48 --> Database Driver Class Initialized
DEBUG - 2018-03-07 23:25:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-07 23:25:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-07 23:25:48 --> Form Validation Class Initialized
INFO - 2018-03-07 23:25:48 --> Model Class Initialized
INFO - 2018-03-07 23:25:48 --> Controller Class Initialized
INFO - 2018-03-07 23:25:48 --> Model Class Initialized
INFO - 2018-03-07 23:25:48 --> Model Class Initialized
INFO - 2018-03-07 23:25:48 --> Model Class Initialized
INFO - 2018-03-07 23:25:48 --> Model Class Initialized
INFO - 2018-03-07 23:25:48 --> Model Class Initialized
DEBUG - 2018-03-07 23:25:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-07 23:25:48 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-07 23:25:48 --> Final output sent to browser
DEBUG - 2018-03-07 23:25:48 --> Total execution time: 0.0550
INFO - 2018-03-07 23:25:48 --> Config Class Initialized
INFO - 2018-03-07 23:25:48 --> Hooks Class Initialized
DEBUG - 2018-03-07 23:25:48 --> UTF-8 Support Enabled
INFO - 2018-03-07 23:25:48 --> Utf8 Class Initialized
INFO - 2018-03-07 23:25:48 --> URI Class Initialized
INFO - 2018-03-07 23:25:48 --> Router Class Initialized
INFO - 2018-03-07 23:25:48 --> Output Class Initialized
INFO - 2018-03-07 23:25:48 --> Security Class Initialized
DEBUG - 2018-03-07 23:25:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 23:25:48 --> Input Class Initialized
INFO - 2018-03-07 23:25:48 --> Language Class Initialized
INFO - 2018-03-07 23:25:48 --> Loader Class Initialized
INFO - 2018-03-07 23:25:48 --> Helper loaded: url_helper
INFO - 2018-03-07 23:25:48 --> Helper loaded: form_helper
INFO - 2018-03-07 23:25:48 --> Database Driver Class Initialized
DEBUG - 2018-03-07 23:25:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-07 23:25:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-07 23:25:48 --> Form Validation Class Initialized
INFO - 2018-03-07 23:25:48 --> Model Class Initialized
INFO - 2018-03-07 23:25:48 --> Controller Class Initialized
INFO - 2018-03-07 23:25:48 --> Model Class Initialized
INFO - 2018-03-07 23:25:48 --> Model Class Initialized
INFO - 2018-03-07 23:25:48 --> Model Class Initialized
INFO - 2018-03-07 23:25:48 --> Model Class Initialized
INFO - 2018-03-07 23:25:48 --> Model Class Initialized
DEBUG - 2018-03-07 23:25:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-07 23:25:51 --> Config Class Initialized
INFO - 2018-03-07 23:25:51 --> Hooks Class Initialized
DEBUG - 2018-03-07 23:25:51 --> UTF-8 Support Enabled
INFO - 2018-03-07 23:25:51 --> Utf8 Class Initialized
INFO - 2018-03-07 23:25:51 --> URI Class Initialized
INFO - 2018-03-07 23:25:51 --> Router Class Initialized
INFO - 2018-03-07 23:25:51 --> Output Class Initialized
INFO - 2018-03-07 23:25:51 --> Security Class Initialized
DEBUG - 2018-03-07 23:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 23:25:51 --> Input Class Initialized
INFO - 2018-03-07 23:25:51 --> Language Class Initialized
INFO - 2018-03-07 23:25:51 --> Loader Class Initialized
INFO - 2018-03-07 23:25:51 --> Helper loaded: url_helper
INFO - 2018-03-07 23:25:51 --> Helper loaded: form_helper
INFO - 2018-03-07 23:25:51 --> Database Driver Class Initialized
DEBUG - 2018-03-07 23:25:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-07 23:25:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-07 23:25:51 --> Form Validation Class Initialized
INFO - 2018-03-07 23:25:51 --> Model Class Initialized
INFO - 2018-03-07 23:25:51 --> Controller Class Initialized
INFO - 2018-03-07 23:25:51 --> Model Class Initialized
INFO - 2018-03-07 23:25:51 --> Model Class Initialized
INFO - 2018-03-07 23:25:51 --> Model Class Initialized
INFO - 2018-03-07 23:25:51 --> Model Class Initialized
INFO - 2018-03-07 23:25:51 --> Model Class Initialized
DEBUG - 2018-03-07 23:25:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-07 23:25:51 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-07 23:25:51 --> Final output sent to browser
DEBUG - 2018-03-07 23:25:51 --> Total execution time: 0.0511
INFO - 2018-03-07 23:25:51 --> Config Class Initialized
INFO - 2018-03-07 23:25:51 --> Hooks Class Initialized
DEBUG - 2018-03-07 23:25:51 --> UTF-8 Support Enabled
INFO - 2018-03-07 23:25:51 --> Utf8 Class Initialized
INFO - 2018-03-07 23:25:51 --> URI Class Initialized
INFO - 2018-03-07 23:25:51 --> Router Class Initialized
INFO - 2018-03-07 23:25:51 --> Output Class Initialized
INFO - 2018-03-07 23:25:51 --> Security Class Initialized
DEBUG - 2018-03-07 23:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 23:25:51 --> Input Class Initialized
INFO - 2018-03-07 23:25:51 --> Language Class Initialized
INFO - 2018-03-07 23:25:51 --> Loader Class Initialized
INFO - 2018-03-07 23:25:51 --> Helper loaded: url_helper
INFO - 2018-03-07 23:25:51 --> Helper loaded: form_helper
INFO - 2018-03-07 23:25:51 --> Database Driver Class Initialized
DEBUG - 2018-03-07 23:25:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-07 23:25:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-07 23:25:51 --> Form Validation Class Initialized
INFO - 2018-03-07 23:25:51 --> Model Class Initialized
INFO - 2018-03-07 23:25:51 --> Controller Class Initialized
INFO - 2018-03-07 23:25:51 --> Model Class Initialized
INFO - 2018-03-07 23:25:51 --> Model Class Initialized
INFO - 2018-03-07 23:25:51 --> Model Class Initialized
INFO - 2018-03-07 23:25:51 --> Model Class Initialized
INFO - 2018-03-07 23:25:51 --> Model Class Initialized
DEBUG - 2018-03-07 23:25:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-07 23:25:58 --> Config Class Initialized
INFO - 2018-03-07 23:25:58 --> Hooks Class Initialized
DEBUG - 2018-03-07 23:25:58 --> UTF-8 Support Enabled
INFO - 2018-03-07 23:25:58 --> Utf8 Class Initialized
INFO - 2018-03-07 23:25:58 --> URI Class Initialized
INFO - 2018-03-07 23:25:58 --> Router Class Initialized
INFO - 2018-03-07 23:25:58 --> Output Class Initialized
INFO - 2018-03-07 23:25:58 --> Security Class Initialized
DEBUG - 2018-03-07 23:25:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 23:25:58 --> Input Class Initialized
INFO - 2018-03-07 23:25:58 --> Language Class Initialized
INFO - 2018-03-07 23:25:58 --> Loader Class Initialized
INFO - 2018-03-07 23:25:58 --> Helper loaded: url_helper
INFO - 2018-03-07 23:25:58 --> Helper loaded: form_helper
INFO - 2018-03-07 23:25:58 --> Database Driver Class Initialized
DEBUG - 2018-03-07 23:25:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-07 23:25:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-07 23:25:58 --> Form Validation Class Initialized
INFO - 2018-03-07 23:25:58 --> Model Class Initialized
INFO - 2018-03-07 23:25:58 --> Controller Class Initialized
INFO - 2018-03-07 23:25:58 --> Model Class Initialized
INFO - 2018-03-07 23:25:58 --> Model Class Initialized
INFO - 2018-03-07 23:25:58 --> Model Class Initialized
INFO - 2018-03-07 23:25:58 --> Model Class Initialized
INFO - 2018-03-07 23:25:58 --> Model Class Initialized
DEBUG - 2018-03-07 23:25:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-07 23:25:58 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-07 23:25:58 --> Final output sent to browser
DEBUG - 2018-03-07 23:25:58 --> Total execution time: 0.0630
INFO - 2018-03-07 23:25:58 --> Config Class Initialized
INFO - 2018-03-07 23:25:58 --> Hooks Class Initialized
DEBUG - 2018-03-07 23:25:58 --> UTF-8 Support Enabled
INFO - 2018-03-07 23:25:58 --> Utf8 Class Initialized
INFO - 2018-03-07 23:25:58 --> URI Class Initialized
INFO - 2018-03-07 23:25:58 --> Router Class Initialized
INFO - 2018-03-07 23:25:58 --> Output Class Initialized
INFO - 2018-03-07 23:25:58 --> Security Class Initialized
DEBUG - 2018-03-07 23:25:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 23:25:58 --> Input Class Initialized
INFO - 2018-03-07 23:25:58 --> Language Class Initialized
INFO - 2018-03-07 23:25:58 --> Loader Class Initialized
INFO - 2018-03-07 23:25:58 --> Helper loaded: url_helper
INFO - 2018-03-07 23:25:58 --> Helper loaded: form_helper
INFO - 2018-03-07 23:25:58 --> Database Driver Class Initialized
DEBUG - 2018-03-07 23:25:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-07 23:25:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-07 23:25:58 --> Form Validation Class Initialized
INFO - 2018-03-07 23:25:58 --> Model Class Initialized
INFO - 2018-03-07 23:25:58 --> Controller Class Initialized
INFO - 2018-03-07 23:25:58 --> Model Class Initialized
INFO - 2018-03-07 23:25:58 --> Model Class Initialized
INFO - 2018-03-07 23:25:58 --> Model Class Initialized
INFO - 2018-03-07 23:25:58 --> Model Class Initialized
INFO - 2018-03-07 23:25:58 --> Model Class Initialized
DEBUG - 2018-03-07 23:25:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-07 23:38:28 --> Config Class Initialized
INFO - 2018-03-07 23:38:28 --> Hooks Class Initialized
DEBUG - 2018-03-07 23:38:28 --> UTF-8 Support Enabled
INFO - 2018-03-07 23:38:28 --> Utf8 Class Initialized
INFO - 2018-03-07 23:38:28 --> URI Class Initialized
INFO - 2018-03-07 23:38:28 --> Router Class Initialized
INFO - 2018-03-07 23:38:28 --> Output Class Initialized
INFO - 2018-03-07 23:38:28 --> Security Class Initialized
DEBUG - 2018-03-07 23:38:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 23:38:28 --> Input Class Initialized
INFO - 2018-03-07 23:38:28 --> Language Class Initialized
INFO - 2018-03-07 23:38:28 --> Loader Class Initialized
INFO - 2018-03-07 23:38:28 --> Helper loaded: url_helper
INFO - 2018-03-07 23:38:28 --> Helper loaded: form_helper
INFO - 2018-03-07 23:38:28 --> Database Driver Class Initialized
DEBUG - 2018-03-07 23:38:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-07 23:38:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-07 23:38:28 --> Form Validation Class Initialized
INFO - 2018-03-07 23:38:28 --> Model Class Initialized
INFO - 2018-03-07 23:38:28 --> Controller Class Initialized
INFO - 2018-03-07 23:38:28 --> Model Class Initialized
INFO - 2018-03-07 23:38:28 --> Model Class Initialized
INFO - 2018-03-07 23:38:28 --> Model Class Initialized
INFO - 2018-03-07 23:38:28 --> Model Class Initialized
INFO - 2018-03-07 23:38:28 --> Model Class Initialized
DEBUG - 2018-03-07 23:38:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-07 23:38:28 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-07 23:38:28 --> Final output sent to browser
DEBUG - 2018-03-07 23:38:28 --> Total execution time: 0.0519
INFO - 2018-03-07 23:38:28 --> Config Class Initialized
INFO - 2018-03-07 23:38:28 --> Hooks Class Initialized
DEBUG - 2018-03-07 23:38:28 --> UTF-8 Support Enabled
INFO - 2018-03-07 23:38:28 --> Utf8 Class Initialized
INFO - 2018-03-07 23:38:28 --> URI Class Initialized
INFO - 2018-03-07 23:38:28 --> Router Class Initialized
INFO - 2018-03-07 23:38:28 --> Output Class Initialized
INFO - 2018-03-07 23:38:28 --> Security Class Initialized
DEBUG - 2018-03-07 23:38:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 23:38:28 --> Input Class Initialized
INFO - 2018-03-07 23:38:28 --> Language Class Initialized
INFO - 2018-03-07 23:38:28 --> Loader Class Initialized
INFO - 2018-03-07 23:38:28 --> Helper loaded: url_helper
INFO - 2018-03-07 23:38:28 --> Helper loaded: form_helper
INFO - 2018-03-07 23:38:28 --> Database Driver Class Initialized
DEBUG - 2018-03-07 23:38:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-07 23:38:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-07 23:38:28 --> Form Validation Class Initialized
INFO - 2018-03-07 23:38:28 --> Model Class Initialized
INFO - 2018-03-07 23:38:28 --> Controller Class Initialized
INFO - 2018-03-07 23:38:28 --> Model Class Initialized
INFO - 2018-03-07 23:38:28 --> Model Class Initialized
INFO - 2018-03-07 23:38:28 --> Model Class Initialized
INFO - 2018-03-07 23:38:28 --> Model Class Initialized
INFO - 2018-03-07 23:38:28 --> Model Class Initialized
DEBUG - 2018-03-07 23:38:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-07 23:38:30 --> Config Class Initialized
INFO - 2018-03-07 23:38:30 --> Hooks Class Initialized
DEBUG - 2018-03-07 23:38:30 --> UTF-8 Support Enabled
INFO - 2018-03-07 23:38:30 --> Utf8 Class Initialized
INFO - 2018-03-07 23:38:30 --> URI Class Initialized
INFO - 2018-03-07 23:38:30 --> Router Class Initialized
INFO - 2018-03-07 23:38:30 --> Output Class Initialized
INFO - 2018-03-07 23:38:30 --> Security Class Initialized
DEBUG - 2018-03-07 23:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 23:38:30 --> Input Class Initialized
INFO - 2018-03-07 23:38:30 --> Language Class Initialized
INFO - 2018-03-07 23:38:30 --> Loader Class Initialized
INFO - 2018-03-07 23:38:30 --> Helper loaded: url_helper
INFO - 2018-03-07 23:38:30 --> Helper loaded: form_helper
INFO - 2018-03-07 23:38:30 --> Database Driver Class Initialized
DEBUG - 2018-03-07 23:38:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-07 23:38:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-07 23:38:30 --> Form Validation Class Initialized
INFO - 2018-03-07 23:38:30 --> Model Class Initialized
INFO - 2018-03-07 23:38:30 --> Controller Class Initialized
INFO - 2018-03-07 23:38:30 --> Model Class Initialized
INFO - 2018-03-07 23:38:30 --> Model Class Initialized
INFO - 2018-03-07 23:38:30 --> Model Class Initialized
INFO - 2018-03-07 23:38:30 --> Model Class Initialized
INFO - 2018-03-07 23:38:30 --> Model Class Initialized
DEBUG - 2018-03-07 23:38:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-07 23:38:30 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-07 23:38:30 --> Final output sent to browser
DEBUG - 2018-03-07 23:38:30 --> Total execution time: 0.0595
INFO - 2018-03-07 23:38:30 --> Config Class Initialized
INFO - 2018-03-07 23:38:30 --> Hooks Class Initialized
DEBUG - 2018-03-07 23:38:30 --> UTF-8 Support Enabled
INFO - 2018-03-07 23:38:30 --> Utf8 Class Initialized
INFO - 2018-03-07 23:38:30 --> URI Class Initialized
INFO - 2018-03-07 23:38:30 --> Router Class Initialized
INFO - 2018-03-07 23:38:30 --> Output Class Initialized
INFO - 2018-03-07 23:38:30 --> Security Class Initialized
DEBUG - 2018-03-07 23:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 23:38:30 --> Input Class Initialized
INFO - 2018-03-07 23:38:30 --> Language Class Initialized
INFO - 2018-03-07 23:38:30 --> Loader Class Initialized
INFO - 2018-03-07 23:38:30 --> Helper loaded: url_helper
INFO - 2018-03-07 23:38:30 --> Helper loaded: form_helper
INFO - 2018-03-07 23:38:30 --> Database Driver Class Initialized
DEBUG - 2018-03-07 23:38:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-07 23:38:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-07 23:38:30 --> Form Validation Class Initialized
INFO - 2018-03-07 23:38:30 --> Model Class Initialized
INFO - 2018-03-07 23:38:30 --> Controller Class Initialized
INFO - 2018-03-07 23:38:30 --> Model Class Initialized
INFO - 2018-03-07 23:38:30 --> Model Class Initialized
INFO - 2018-03-07 23:38:30 --> Model Class Initialized
INFO - 2018-03-07 23:38:30 --> Model Class Initialized
INFO - 2018-03-07 23:38:30 --> Model Class Initialized
DEBUG - 2018-03-07 23:38:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-07 23:55:50 --> Config Class Initialized
INFO - 2018-03-07 23:55:50 --> Hooks Class Initialized
DEBUG - 2018-03-07 23:55:50 --> UTF-8 Support Enabled
INFO - 2018-03-07 23:55:50 --> Utf8 Class Initialized
INFO - 2018-03-07 23:55:50 --> URI Class Initialized
INFO - 2018-03-07 23:55:50 --> Router Class Initialized
INFO - 2018-03-07 23:55:50 --> Output Class Initialized
INFO - 2018-03-07 23:55:50 --> Security Class Initialized
DEBUG - 2018-03-07 23:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 23:55:50 --> Input Class Initialized
INFO - 2018-03-07 23:55:50 --> Language Class Initialized
INFO - 2018-03-07 23:55:50 --> Loader Class Initialized
INFO - 2018-03-07 23:55:50 --> Helper loaded: url_helper
INFO - 2018-03-07 23:55:50 --> Helper loaded: form_helper
INFO - 2018-03-07 23:55:50 --> Database Driver Class Initialized
DEBUG - 2018-03-07 23:55:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-07 23:55:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-07 23:55:50 --> Form Validation Class Initialized
INFO - 2018-03-07 23:55:50 --> Model Class Initialized
INFO - 2018-03-07 23:55:50 --> Controller Class Initialized
INFO - 2018-03-07 23:55:50 --> Model Class Initialized
INFO - 2018-03-07 23:55:50 --> Model Class Initialized
INFO - 2018-03-07 23:55:50 --> Model Class Initialized
INFO - 2018-03-07 23:55:50 --> Model Class Initialized
INFO - 2018-03-07 23:55:50 --> Model Class Initialized
DEBUG - 2018-03-07 23:55:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-07 23:55:50 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-07 23:55:50 --> Final output sent to browser
DEBUG - 2018-03-07 23:55:50 --> Total execution time: 0.0793
INFO - 2018-03-07 23:55:50 --> Config Class Initialized
INFO - 2018-03-07 23:55:50 --> Hooks Class Initialized
DEBUG - 2018-03-07 23:55:50 --> UTF-8 Support Enabled
INFO - 2018-03-07 23:55:50 --> Utf8 Class Initialized
INFO - 2018-03-07 23:55:50 --> URI Class Initialized
INFO - 2018-03-07 23:55:50 --> Router Class Initialized
INFO - 2018-03-07 23:55:50 --> Output Class Initialized
INFO - 2018-03-07 23:55:50 --> Security Class Initialized
DEBUG - 2018-03-07 23:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 23:55:50 --> Input Class Initialized
INFO - 2018-03-07 23:55:50 --> Language Class Initialized
INFO - 2018-03-07 23:55:50 --> Loader Class Initialized
INFO - 2018-03-07 23:55:50 --> Helper loaded: url_helper
INFO - 2018-03-07 23:55:50 --> Helper loaded: form_helper
INFO - 2018-03-07 23:55:50 --> Database Driver Class Initialized
DEBUG - 2018-03-07 23:55:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-07 23:55:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-07 23:55:50 --> Form Validation Class Initialized
INFO - 2018-03-07 23:55:50 --> Model Class Initialized
INFO - 2018-03-07 23:55:50 --> Controller Class Initialized
INFO - 2018-03-07 23:55:50 --> Model Class Initialized
INFO - 2018-03-07 23:55:50 --> Model Class Initialized
INFO - 2018-03-07 23:55:50 --> Model Class Initialized
INFO - 2018-03-07 23:55:50 --> Model Class Initialized
INFO - 2018-03-07 23:55:50 --> Model Class Initialized
DEBUG - 2018-03-07 23:55:50 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-03-07 23:55:50 --> Severity: Notice --> Undefined property: Proyecto::$proyecto_gasto_mano_obra D:\xampp\htdocs\instateccr\controlcostos\instatec_sys\core\Model.php 77
ERROR - 2018-03-07 23:55:50 --> Severity: Notice --> Undefined property: Proyecto::$proyecto_gasto_mano_obra D:\xampp\htdocs\instateccr\controlcostos\instatec_sys\core\Model.php 77
ERROR - 2018-03-07 23:55:50 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ON .`proyecto_colaborador_id` = `proyecto_colaborador`.`proyecto_colaborador_id`' at line 5 - Invalid query: SELECT *
FROM `proyecto_colaborador`
LEFT JOIN `colaborador` ON `colaborador`.`colaborador_id` = `proyecto_colaborador`.`colaborador_id`
JOIN `colaborador_puesto` ON `colaborador_puesto`.`colaborador_puesto_id` = `colaborador`.`colaborador_puesto_id`
LEFT JOIN  ON .`proyecto_colaborador_id` = `proyecto_colaborador`.`proyecto_colaborador_id`
WHERE `proyecto_colaborador`.`proyecto_id` = '1'
AND `proyecto_colaborador`.`estado_registro` = 1
INFO - 2018-03-07 23:55:50 --> Language file loaded: language/english/db_lang.php
INFO - 2018-03-07 23:55:51 --> Config Class Initialized
INFO - 2018-03-07 23:55:51 --> Hooks Class Initialized
DEBUG - 2018-03-07 23:55:51 --> UTF-8 Support Enabled
INFO - 2018-03-07 23:55:51 --> Utf8 Class Initialized
INFO - 2018-03-07 23:55:51 --> URI Class Initialized
INFO - 2018-03-07 23:55:51 --> Router Class Initialized
INFO - 2018-03-07 23:55:51 --> Output Class Initialized
INFO - 2018-03-07 23:55:51 --> Security Class Initialized
DEBUG - 2018-03-07 23:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 23:55:51 --> Input Class Initialized
INFO - 2018-03-07 23:55:51 --> Language Class Initialized
INFO - 2018-03-07 23:55:51 --> Loader Class Initialized
INFO - 2018-03-07 23:55:51 --> Helper loaded: url_helper
INFO - 2018-03-07 23:55:51 --> Helper loaded: form_helper
INFO - 2018-03-07 23:55:51 --> Database Driver Class Initialized
DEBUG - 2018-03-07 23:55:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-07 23:55:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-07 23:55:51 --> Form Validation Class Initialized
INFO - 2018-03-07 23:55:51 --> Model Class Initialized
INFO - 2018-03-07 23:55:51 --> Controller Class Initialized
INFO - 2018-03-07 23:55:51 --> Model Class Initialized
INFO - 2018-03-07 23:55:51 --> Model Class Initialized
INFO - 2018-03-07 23:55:51 --> Model Class Initialized
INFO - 2018-03-07 23:55:51 --> Model Class Initialized
INFO - 2018-03-07 23:55:51 --> Model Class Initialized
DEBUG - 2018-03-07 23:55:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-07 23:55:51 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-07 23:55:51 --> Final output sent to browser
DEBUG - 2018-03-07 23:55:51 --> Total execution time: 0.0538
INFO - 2018-03-07 23:55:51 --> Config Class Initialized
INFO - 2018-03-07 23:55:51 --> Hooks Class Initialized
DEBUG - 2018-03-07 23:55:51 --> UTF-8 Support Enabled
INFO - 2018-03-07 23:55:51 --> Utf8 Class Initialized
INFO - 2018-03-07 23:55:51 --> URI Class Initialized
INFO - 2018-03-07 23:55:51 --> Router Class Initialized
INFO - 2018-03-07 23:55:51 --> Output Class Initialized
INFO - 2018-03-07 23:55:51 --> Security Class Initialized
DEBUG - 2018-03-07 23:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 23:55:51 --> Input Class Initialized
INFO - 2018-03-07 23:55:51 --> Language Class Initialized
INFO - 2018-03-07 23:55:51 --> Loader Class Initialized
INFO - 2018-03-07 23:55:51 --> Helper loaded: url_helper
INFO - 2018-03-07 23:55:51 --> Helper loaded: form_helper
INFO - 2018-03-07 23:55:51 --> Database Driver Class Initialized
DEBUG - 2018-03-07 23:55:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-07 23:55:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-07 23:55:51 --> Form Validation Class Initialized
INFO - 2018-03-07 23:55:51 --> Model Class Initialized
INFO - 2018-03-07 23:55:51 --> Controller Class Initialized
INFO - 2018-03-07 23:55:51 --> Model Class Initialized
INFO - 2018-03-07 23:55:51 --> Model Class Initialized
INFO - 2018-03-07 23:55:51 --> Model Class Initialized
INFO - 2018-03-07 23:55:51 --> Model Class Initialized
INFO - 2018-03-07 23:55:51 --> Model Class Initialized
DEBUG - 2018-03-07 23:55:51 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-03-07 23:55:51 --> Severity: Notice --> Undefined property: Proyecto::$proyecto_gasto_mano_obra D:\xampp\htdocs\instateccr\controlcostos\instatec_sys\core\Model.php 77
ERROR - 2018-03-07 23:55:51 --> Severity: Notice --> Undefined property: Proyecto::$proyecto_gasto_mano_obra D:\xampp\htdocs\instateccr\controlcostos\instatec_sys\core\Model.php 77
ERROR - 2018-03-07 23:55:51 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ON .`proyecto_colaborador_id` = `proyecto_colaborador`.`proyecto_colaborador_id`' at line 5 - Invalid query: SELECT *
FROM `proyecto_colaborador`
LEFT JOIN `colaborador` ON `colaborador`.`colaborador_id` = `proyecto_colaborador`.`colaborador_id`
JOIN `colaborador_puesto` ON `colaborador_puesto`.`colaborador_puesto_id` = `colaborador`.`colaborador_puesto_id`
LEFT JOIN  ON .`proyecto_colaborador_id` = `proyecto_colaborador`.`proyecto_colaborador_id`
WHERE `proyecto_colaborador`.`proyecto_id` = '1'
AND `proyecto_colaborador`.`estado_registro` = 1
INFO - 2018-03-07 23:55:51 --> Language file loaded: language/english/db_lang.php
INFO - 2018-03-07 23:55:51 --> Config Class Initialized
INFO - 2018-03-07 23:55:51 --> Hooks Class Initialized
DEBUG - 2018-03-07 23:55:51 --> UTF-8 Support Enabled
INFO - 2018-03-07 23:55:51 --> Utf8 Class Initialized
INFO - 2018-03-07 23:55:51 --> URI Class Initialized
INFO - 2018-03-07 23:55:51 --> Router Class Initialized
INFO - 2018-03-07 23:55:51 --> Output Class Initialized
INFO - 2018-03-07 23:55:51 --> Security Class Initialized
DEBUG - 2018-03-07 23:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 23:55:51 --> Input Class Initialized
INFO - 2018-03-07 23:55:51 --> Language Class Initialized
INFO - 2018-03-07 23:55:51 --> Loader Class Initialized
INFO - 2018-03-07 23:55:51 --> Helper loaded: url_helper
INFO - 2018-03-07 23:55:51 --> Helper loaded: form_helper
INFO - 2018-03-07 23:55:51 --> Database Driver Class Initialized
DEBUG - 2018-03-07 23:55:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-07 23:55:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-07 23:55:51 --> Form Validation Class Initialized
INFO - 2018-03-07 23:55:51 --> Model Class Initialized
INFO - 2018-03-07 23:55:51 --> Controller Class Initialized
INFO - 2018-03-07 23:55:51 --> Model Class Initialized
INFO - 2018-03-07 23:55:51 --> Model Class Initialized
INFO - 2018-03-07 23:55:51 --> Model Class Initialized
INFO - 2018-03-07 23:55:51 --> Model Class Initialized
INFO - 2018-03-07 23:55:51 --> Model Class Initialized
DEBUG - 2018-03-07 23:55:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-07 23:55:51 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-07 23:55:51 --> Final output sent to browser
DEBUG - 2018-03-07 23:55:51 --> Total execution time: 0.0542
INFO - 2018-03-07 23:55:52 --> Config Class Initialized
INFO - 2018-03-07 23:55:52 --> Hooks Class Initialized
DEBUG - 2018-03-07 23:55:52 --> UTF-8 Support Enabled
INFO - 2018-03-07 23:55:52 --> Utf8 Class Initialized
INFO - 2018-03-07 23:55:52 --> URI Class Initialized
INFO - 2018-03-07 23:55:52 --> Router Class Initialized
INFO - 2018-03-07 23:55:52 --> Output Class Initialized
INFO - 2018-03-07 23:55:52 --> Security Class Initialized
DEBUG - 2018-03-07 23:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 23:55:52 --> Input Class Initialized
INFO - 2018-03-07 23:55:52 --> Language Class Initialized
INFO - 2018-03-07 23:55:52 --> Loader Class Initialized
INFO - 2018-03-07 23:55:52 --> Helper loaded: url_helper
INFO - 2018-03-07 23:55:52 --> Helper loaded: form_helper
INFO - 2018-03-07 23:55:52 --> Database Driver Class Initialized
DEBUG - 2018-03-07 23:55:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-07 23:55:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-07 23:55:52 --> Form Validation Class Initialized
INFO - 2018-03-07 23:55:52 --> Model Class Initialized
INFO - 2018-03-07 23:55:52 --> Controller Class Initialized
INFO - 2018-03-07 23:55:52 --> Model Class Initialized
INFO - 2018-03-07 23:55:52 --> Model Class Initialized
INFO - 2018-03-07 23:55:52 --> Model Class Initialized
INFO - 2018-03-07 23:55:52 --> Model Class Initialized
INFO - 2018-03-07 23:55:52 --> Model Class Initialized
DEBUG - 2018-03-07 23:55:52 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-03-07 23:55:52 --> Severity: Notice --> Undefined property: Proyecto::$proyecto_gasto_mano_obra D:\xampp\htdocs\instateccr\controlcostos\instatec_sys\core\Model.php 77
ERROR - 2018-03-07 23:55:52 --> Severity: Notice --> Undefined property: Proyecto::$proyecto_gasto_mano_obra D:\xampp\htdocs\instateccr\controlcostos\instatec_sys\core\Model.php 77
ERROR - 2018-03-07 23:55:52 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ON .`proyecto_colaborador_id` = `proyecto_colaborador`.`proyecto_colaborador_id`' at line 5 - Invalid query: SELECT *
FROM `proyecto_colaborador`
LEFT JOIN `colaborador` ON `colaborador`.`colaborador_id` = `proyecto_colaborador`.`colaborador_id`
JOIN `colaborador_puesto` ON `colaborador_puesto`.`colaborador_puesto_id` = `colaborador`.`colaborador_puesto_id`
LEFT JOIN  ON .`proyecto_colaborador_id` = `proyecto_colaborador`.`proyecto_colaborador_id`
WHERE `proyecto_colaborador`.`proyecto_id` = '1'
AND `proyecto_colaborador`.`estado_registro` = 1
INFO - 2018-03-07 23:55:52 --> Language file loaded: language/english/db_lang.php
INFO - 2018-03-07 23:55:52 --> Config Class Initialized
INFO - 2018-03-07 23:55:52 --> Hooks Class Initialized
DEBUG - 2018-03-07 23:55:52 --> UTF-8 Support Enabled
INFO - 2018-03-07 23:55:52 --> Utf8 Class Initialized
INFO - 2018-03-07 23:55:52 --> URI Class Initialized
INFO - 2018-03-07 23:55:52 --> Router Class Initialized
INFO - 2018-03-07 23:55:52 --> Output Class Initialized
INFO - 2018-03-07 23:55:52 --> Security Class Initialized
DEBUG - 2018-03-07 23:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 23:55:52 --> Input Class Initialized
INFO - 2018-03-07 23:55:52 --> Language Class Initialized
INFO - 2018-03-07 23:55:52 --> Loader Class Initialized
INFO - 2018-03-07 23:55:52 --> Helper loaded: url_helper
INFO - 2018-03-07 23:55:52 --> Helper loaded: form_helper
INFO - 2018-03-07 23:55:52 --> Database Driver Class Initialized
DEBUG - 2018-03-07 23:55:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-07 23:55:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-07 23:55:52 --> Form Validation Class Initialized
INFO - 2018-03-07 23:55:52 --> Model Class Initialized
INFO - 2018-03-07 23:55:52 --> Controller Class Initialized
INFO - 2018-03-07 23:55:52 --> Model Class Initialized
INFO - 2018-03-07 23:55:52 --> Model Class Initialized
INFO - 2018-03-07 23:55:52 --> Model Class Initialized
INFO - 2018-03-07 23:55:52 --> Model Class Initialized
INFO - 2018-03-07 23:55:52 --> Model Class Initialized
DEBUG - 2018-03-07 23:55:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-07 23:55:52 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-07 23:55:52 --> Final output sent to browser
DEBUG - 2018-03-07 23:55:52 --> Total execution time: 0.0621
INFO - 2018-03-07 23:55:52 --> Config Class Initialized
INFO - 2018-03-07 23:55:52 --> Hooks Class Initialized
DEBUG - 2018-03-07 23:55:52 --> UTF-8 Support Enabled
INFO - 2018-03-07 23:55:52 --> Utf8 Class Initialized
INFO - 2018-03-07 23:55:52 --> URI Class Initialized
INFO - 2018-03-07 23:55:52 --> Router Class Initialized
INFO - 2018-03-07 23:55:52 --> Output Class Initialized
INFO - 2018-03-07 23:55:52 --> Security Class Initialized
DEBUG - 2018-03-07 23:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 23:55:52 --> Input Class Initialized
INFO - 2018-03-07 23:55:52 --> Language Class Initialized
INFO - 2018-03-07 23:55:52 --> Loader Class Initialized
INFO - 2018-03-07 23:55:52 --> Helper loaded: url_helper
INFO - 2018-03-07 23:55:52 --> Helper loaded: form_helper
INFO - 2018-03-07 23:55:52 --> Database Driver Class Initialized
DEBUG - 2018-03-07 23:55:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-07 23:55:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-07 23:55:52 --> Form Validation Class Initialized
INFO - 2018-03-07 23:55:52 --> Model Class Initialized
INFO - 2018-03-07 23:55:52 --> Controller Class Initialized
INFO - 2018-03-07 23:55:52 --> Model Class Initialized
INFO - 2018-03-07 23:55:52 --> Model Class Initialized
INFO - 2018-03-07 23:55:52 --> Model Class Initialized
INFO - 2018-03-07 23:55:52 --> Model Class Initialized
INFO - 2018-03-07 23:55:52 --> Model Class Initialized
DEBUG - 2018-03-07 23:55:52 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-03-07 23:55:52 --> Severity: Notice --> Undefined property: Proyecto::$proyecto_gasto_mano_obra D:\xampp\htdocs\instateccr\controlcostos\instatec_sys\core\Model.php 77
ERROR - 2018-03-07 23:55:52 --> Severity: Notice --> Undefined property: Proyecto::$proyecto_gasto_mano_obra D:\xampp\htdocs\instateccr\controlcostos\instatec_sys\core\Model.php 77
ERROR - 2018-03-07 23:55:52 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ON .`proyecto_colaborador_id` = `proyecto_colaborador`.`proyecto_colaborador_id`' at line 5 - Invalid query: SELECT *
FROM `proyecto_colaborador`
LEFT JOIN `colaborador` ON `colaborador`.`colaborador_id` = `proyecto_colaborador`.`colaborador_id`
JOIN `colaborador_puesto` ON `colaborador_puesto`.`colaborador_puesto_id` = `colaborador`.`colaborador_puesto_id`
LEFT JOIN  ON .`proyecto_colaborador_id` = `proyecto_colaborador`.`proyecto_colaborador_id`
WHERE `proyecto_colaborador`.`proyecto_id` = '1'
AND `proyecto_colaborador`.`estado_registro` = 1
INFO - 2018-03-07 23:55:52 --> Language file loaded: language/english/db_lang.php
INFO - 2018-03-07 23:55:52 --> Config Class Initialized
INFO - 2018-03-07 23:55:52 --> Hooks Class Initialized
DEBUG - 2018-03-07 23:55:52 --> UTF-8 Support Enabled
INFO - 2018-03-07 23:55:52 --> Utf8 Class Initialized
INFO - 2018-03-07 23:55:52 --> URI Class Initialized
INFO - 2018-03-07 23:55:52 --> Router Class Initialized
INFO - 2018-03-07 23:55:52 --> Output Class Initialized
INFO - 2018-03-07 23:55:52 --> Security Class Initialized
DEBUG - 2018-03-07 23:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 23:55:52 --> Input Class Initialized
INFO - 2018-03-07 23:55:52 --> Language Class Initialized
INFO - 2018-03-07 23:55:52 --> Loader Class Initialized
INFO - 2018-03-07 23:55:52 --> Helper loaded: url_helper
INFO - 2018-03-07 23:55:52 --> Helper loaded: form_helper
INFO - 2018-03-07 23:55:52 --> Database Driver Class Initialized
DEBUG - 2018-03-07 23:55:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-07 23:55:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-07 23:55:52 --> Form Validation Class Initialized
INFO - 2018-03-07 23:55:52 --> Model Class Initialized
INFO - 2018-03-07 23:55:52 --> Controller Class Initialized
INFO - 2018-03-07 23:55:52 --> Model Class Initialized
INFO - 2018-03-07 23:55:52 --> Model Class Initialized
INFO - 2018-03-07 23:55:52 --> Model Class Initialized
INFO - 2018-03-07 23:55:52 --> Model Class Initialized
INFO - 2018-03-07 23:55:52 --> Model Class Initialized
DEBUG - 2018-03-07 23:55:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-07 23:55:52 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-07 23:55:52 --> Final output sent to browser
DEBUG - 2018-03-07 23:55:52 --> Total execution time: 0.0557
INFO - 2018-03-07 23:55:52 --> Config Class Initialized
INFO - 2018-03-07 23:55:52 --> Hooks Class Initialized
DEBUG - 2018-03-07 23:55:52 --> UTF-8 Support Enabled
INFO - 2018-03-07 23:55:52 --> Utf8 Class Initialized
INFO - 2018-03-07 23:55:52 --> URI Class Initialized
INFO - 2018-03-07 23:55:52 --> Router Class Initialized
INFO - 2018-03-07 23:55:52 --> Output Class Initialized
INFO - 2018-03-07 23:55:52 --> Security Class Initialized
DEBUG - 2018-03-07 23:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 23:55:52 --> Input Class Initialized
INFO - 2018-03-07 23:55:52 --> Language Class Initialized
INFO - 2018-03-07 23:55:52 --> Loader Class Initialized
INFO - 2018-03-07 23:55:52 --> Helper loaded: url_helper
INFO - 2018-03-07 23:55:52 --> Helper loaded: form_helper
INFO - 2018-03-07 23:55:52 --> Database Driver Class Initialized
DEBUG - 2018-03-07 23:55:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-07 23:55:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-07 23:55:52 --> Form Validation Class Initialized
INFO - 2018-03-07 23:55:52 --> Model Class Initialized
INFO - 2018-03-07 23:55:52 --> Controller Class Initialized
INFO - 2018-03-07 23:55:52 --> Model Class Initialized
INFO - 2018-03-07 23:55:52 --> Model Class Initialized
INFO - 2018-03-07 23:55:52 --> Model Class Initialized
INFO - 2018-03-07 23:55:52 --> Model Class Initialized
INFO - 2018-03-07 23:55:52 --> Model Class Initialized
DEBUG - 2018-03-07 23:55:52 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-03-07 23:55:52 --> Severity: Notice --> Undefined property: Proyecto::$proyecto_gasto_mano_obra D:\xampp\htdocs\instateccr\controlcostos\instatec_sys\core\Model.php 77
ERROR - 2018-03-07 23:55:52 --> Severity: Notice --> Undefined property: Proyecto::$proyecto_gasto_mano_obra D:\xampp\htdocs\instateccr\controlcostos\instatec_sys\core\Model.php 77
ERROR - 2018-03-07 23:55:52 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ON .`proyecto_colaborador_id` = `proyecto_colaborador`.`proyecto_colaborador_id`' at line 5 - Invalid query: SELECT *
FROM `proyecto_colaborador`
LEFT JOIN `colaborador` ON `colaborador`.`colaborador_id` = `proyecto_colaborador`.`colaborador_id`
JOIN `colaborador_puesto` ON `colaborador_puesto`.`colaborador_puesto_id` = `colaborador`.`colaborador_puesto_id`
LEFT JOIN  ON .`proyecto_colaborador_id` = `proyecto_colaborador`.`proyecto_colaborador_id`
WHERE `proyecto_colaborador`.`proyecto_id` = '1'
AND `proyecto_colaborador`.`estado_registro` = 1
INFO - 2018-03-07 23:55:52 --> Language file loaded: language/english/db_lang.php
INFO - 2018-03-07 23:56:08 --> Config Class Initialized
INFO - 2018-03-07 23:56:08 --> Hooks Class Initialized
INFO - 2018-03-07 23:56:08 --> Config Class Initialized
INFO - 2018-03-07 23:56:08 --> Hooks Class Initialized
INFO - 2018-03-07 23:56:08 --> Config Class Initialized
INFO - 2018-03-07 23:56:08 --> Hooks Class Initialized
DEBUG - 2018-03-07 23:56:08 --> UTF-8 Support Enabled
INFO - 2018-03-07 23:56:08 --> Utf8 Class Initialized
DEBUG - 2018-03-07 23:56:08 --> UTF-8 Support Enabled
INFO - 2018-03-07 23:56:08 --> URI Class Initialized
INFO - 2018-03-07 23:56:08 --> Utf8 Class Initialized
DEBUG - 2018-03-07 23:56:08 --> UTF-8 Support Enabled
INFO - 2018-03-07 23:56:08 --> Utf8 Class Initialized
INFO - 2018-03-07 23:56:08 --> URI Class Initialized
INFO - 2018-03-07 23:56:08 --> Router Class Initialized
INFO - 2018-03-07 23:56:08 --> URI Class Initialized
INFO - 2018-03-07 23:56:08 --> Output Class Initialized
INFO - 2018-03-07 23:56:08 --> Router Class Initialized
INFO - 2018-03-07 23:56:08 --> Security Class Initialized
DEBUG - 2018-03-07 23:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 23:56:08 --> Input Class Initialized
INFO - 2018-03-07 23:56:08 --> Output Class Initialized
INFO - 2018-03-07 23:56:08 --> Language Class Initialized
INFO - 2018-03-07 23:56:08 --> Router Class Initialized
ERROR - 2018-03-07 23:56:08 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-07 23:56:08 --> Security Class Initialized
INFO - 2018-03-07 23:56:08 --> Output Class Initialized
DEBUG - 2018-03-07 23:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 23:56:08 --> Input Class Initialized
INFO - 2018-03-07 23:56:08 --> Security Class Initialized
INFO - 2018-03-07 23:56:08 --> Language Class Initialized
ERROR - 2018-03-07 23:56:08 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-03-07 23:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 23:56:08 --> Input Class Initialized
INFO - 2018-03-07 23:56:08 --> Language Class Initialized
ERROR - 2018-03-07 23:56:08 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-07 23:56:40 --> Config Class Initialized
INFO - 2018-03-07 23:56:40 --> Hooks Class Initialized
DEBUG - 2018-03-07 23:56:40 --> UTF-8 Support Enabled
INFO - 2018-03-07 23:56:40 --> Utf8 Class Initialized
INFO - 2018-03-07 23:56:40 --> URI Class Initialized
INFO - 2018-03-07 23:56:40 --> Router Class Initialized
INFO - 2018-03-07 23:56:40 --> Output Class Initialized
INFO - 2018-03-07 23:56:40 --> Security Class Initialized
DEBUG - 2018-03-07 23:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 23:56:40 --> Input Class Initialized
INFO - 2018-03-07 23:56:40 --> Language Class Initialized
INFO - 2018-03-07 23:56:40 --> Loader Class Initialized
INFO - 2018-03-07 23:56:40 --> Helper loaded: url_helper
INFO - 2018-03-07 23:56:40 --> Helper loaded: form_helper
INFO - 2018-03-07 23:56:40 --> Database Driver Class Initialized
DEBUG - 2018-03-07 23:56:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-07 23:56:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-07 23:56:40 --> Form Validation Class Initialized
INFO - 2018-03-07 23:56:40 --> Model Class Initialized
INFO - 2018-03-07 23:56:40 --> Controller Class Initialized
INFO - 2018-03-07 23:56:40 --> Model Class Initialized
INFO - 2018-03-07 23:56:40 --> Model Class Initialized
INFO - 2018-03-07 23:56:40 --> Model Class Initialized
INFO - 2018-03-07 23:56:40 --> Model Class Initialized
INFO - 2018-03-07 23:56:40 --> Model Class Initialized
DEBUG - 2018-03-07 23:56:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-07 23:56:40 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-07 23:56:40 --> Final output sent to browser
DEBUG - 2018-03-07 23:56:40 --> Total execution time: 0.0654
INFO - 2018-03-07 23:56:40 --> Config Class Initialized
INFO - 2018-03-07 23:56:40 --> Config Class Initialized
INFO - 2018-03-07 23:56:40 --> Hooks Class Initialized
INFO - 2018-03-07 23:56:40 --> Config Class Initialized
INFO - 2018-03-07 23:56:40 --> Hooks Class Initialized
INFO - 2018-03-07 23:56:40 --> Hooks Class Initialized
DEBUG - 2018-03-07 23:56:40 --> UTF-8 Support Enabled
INFO - 2018-03-07 23:56:40 --> Utf8 Class Initialized
DEBUG - 2018-03-07 23:56:40 --> UTF-8 Support Enabled
DEBUG - 2018-03-07 23:56:40 --> UTF-8 Support Enabled
INFO - 2018-03-07 23:56:40 --> Utf8 Class Initialized
INFO - 2018-03-07 23:56:40 --> Utf8 Class Initialized
INFO - 2018-03-07 23:56:40 --> Config Class Initialized
INFO - 2018-03-07 23:56:40 --> Hooks Class Initialized
INFO - 2018-03-07 23:56:40 --> URI Class Initialized
INFO - 2018-03-07 23:56:40 --> URI Class Initialized
INFO - 2018-03-07 23:56:40 --> URI Class Initialized
INFO - 2018-03-07 23:56:40 --> Router Class Initialized
INFO - 2018-03-07 23:56:40 --> Router Class Initialized
DEBUG - 2018-03-07 23:56:40 --> UTF-8 Support Enabled
INFO - 2018-03-07 23:56:40 --> Utf8 Class Initialized
INFO - 2018-03-07 23:56:40 --> Router Class Initialized
INFO - 2018-03-07 23:56:40 --> Output Class Initialized
INFO - 2018-03-07 23:56:40 --> URI Class Initialized
INFO - 2018-03-07 23:56:40 --> Output Class Initialized
INFO - 2018-03-07 23:56:40 --> Security Class Initialized
INFO - 2018-03-07 23:56:40 --> Output Class Initialized
INFO - 2018-03-07 23:56:40 --> Security Class Initialized
INFO - 2018-03-07 23:56:40 --> Router Class Initialized
DEBUG - 2018-03-07 23:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 23:56:40 --> Input Class Initialized
INFO - 2018-03-07 23:56:40 --> Security Class Initialized
DEBUG - 2018-03-07 23:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 23:56:40 --> Input Class Initialized
INFO - 2018-03-07 23:56:40 --> Language Class Initialized
INFO - 2018-03-07 23:56:40 --> Output Class Initialized
DEBUG - 2018-03-07 23:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 23:56:40 --> Input Class Initialized
INFO - 2018-03-07 23:56:40 --> Language Class Initialized
ERROR - 2018-03-07 23:56:40 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-07 23:56:40 --> Language Class Initialized
INFO - 2018-03-07 23:56:40 --> Security Class Initialized
ERROR - 2018-03-07 23:56:40 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-07 23:56:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-03-07 23:56:40 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-07 23:56:40 --> Input Class Initialized
INFO - 2018-03-07 23:56:40 --> Language Class Initialized
ERROR - 2018-03-07 23:56:40 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-07 23:56:40 --> Config Class Initialized
INFO - 2018-03-07 23:56:40 --> Hooks Class Initialized
INFO - 2018-03-07 23:56:40 --> Config Class Initialized
INFO - 2018-03-07 23:56:40 --> Hooks Class Initialized
INFO - 2018-03-07 23:56:40 --> Config Class Initialized
INFO - 2018-03-07 23:56:40 --> Hooks Class Initialized
DEBUG - 2018-03-07 23:56:40 --> UTF-8 Support Enabled
INFO - 2018-03-07 23:56:40 --> Utf8 Class Initialized
DEBUG - 2018-03-07 23:56:40 --> UTF-8 Support Enabled
INFO - 2018-03-07 23:56:40 --> Utf8 Class Initialized
DEBUG - 2018-03-07 23:56:40 --> UTF-8 Support Enabled
INFO - 2018-03-07 23:56:40 --> Utf8 Class Initialized
INFO - 2018-03-07 23:56:40 --> URI Class Initialized
INFO - 2018-03-07 23:56:40 --> URI Class Initialized
INFO - 2018-03-07 23:56:40 --> URI Class Initialized
INFO - 2018-03-07 23:56:40 --> Router Class Initialized
INFO - 2018-03-07 23:56:40 --> Router Class Initialized
INFO - 2018-03-07 23:56:40 --> Router Class Initialized
INFO - 2018-03-07 23:56:40 --> Output Class Initialized
INFO - 2018-03-07 23:56:40 --> Output Class Initialized
INFO - 2018-03-07 23:56:40 --> Output Class Initialized
INFO - 2018-03-07 23:56:40 --> Security Class Initialized
INFO - 2018-03-07 23:56:40 --> Security Class Initialized
DEBUG - 2018-03-07 23:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 23:56:40 --> Security Class Initialized
INFO - 2018-03-07 23:56:40 --> Input Class Initialized
INFO - 2018-03-07 23:56:40 --> Language Class Initialized
DEBUG - 2018-03-07 23:56:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-07 23:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 23:56:40 --> Input Class Initialized
INFO - 2018-03-07 23:56:40 --> Input Class Initialized
ERROR - 2018-03-07 23:56:40 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-07 23:56:40 --> Language Class Initialized
INFO - 2018-03-07 23:56:40 --> Language Class Initialized
ERROR - 2018-03-07 23:56:40 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-07 23:56:40 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-07 23:56:41 --> Config Class Initialized
INFO - 2018-03-07 23:56:41 --> Hooks Class Initialized
DEBUG - 2018-03-07 23:56:41 --> UTF-8 Support Enabled
INFO - 2018-03-07 23:56:41 --> Utf8 Class Initialized
INFO - 2018-03-07 23:56:41 --> URI Class Initialized
INFO - 2018-03-07 23:56:41 --> Router Class Initialized
INFO - 2018-03-07 23:56:41 --> Output Class Initialized
INFO - 2018-03-07 23:56:41 --> Security Class Initialized
DEBUG - 2018-03-07 23:56:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 23:56:41 --> Input Class Initialized
INFO - 2018-03-07 23:56:41 --> Language Class Initialized
INFO - 2018-03-07 23:56:41 --> Loader Class Initialized
INFO - 2018-03-07 23:56:41 --> Helper loaded: url_helper
INFO - 2018-03-07 23:56:41 --> Helper loaded: form_helper
INFO - 2018-03-07 23:56:41 --> Database Driver Class Initialized
DEBUG - 2018-03-07 23:56:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-07 23:56:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-07 23:56:41 --> Form Validation Class Initialized
INFO - 2018-03-07 23:56:41 --> Model Class Initialized
INFO - 2018-03-07 23:56:41 --> Controller Class Initialized
INFO - 2018-03-07 23:56:41 --> Model Class Initialized
INFO - 2018-03-07 23:56:41 --> Model Class Initialized
INFO - 2018-03-07 23:56:41 --> Model Class Initialized
INFO - 2018-03-07 23:56:41 --> Model Class Initialized
INFO - 2018-03-07 23:56:41 --> Model Class Initialized
DEBUG - 2018-03-07 23:56:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-07 23:57:37 --> Config Class Initialized
INFO - 2018-03-07 23:57:37 --> Hooks Class Initialized
DEBUG - 2018-03-07 23:57:37 --> UTF-8 Support Enabled
INFO - 2018-03-07 23:57:37 --> Utf8 Class Initialized
INFO - 2018-03-07 23:57:37 --> URI Class Initialized
INFO - 2018-03-07 23:57:37 --> Router Class Initialized
INFO - 2018-03-07 23:57:37 --> Output Class Initialized
INFO - 2018-03-07 23:57:37 --> Security Class Initialized
DEBUG - 2018-03-07 23:57:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 23:57:37 --> Input Class Initialized
INFO - 2018-03-07 23:57:37 --> Language Class Initialized
INFO - 2018-03-07 23:57:37 --> Loader Class Initialized
INFO - 2018-03-07 23:57:37 --> Helper loaded: url_helper
INFO - 2018-03-07 23:57:37 --> Helper loaded: form_helper
INFO - 2018-03-07 23:57:37 --> Database Driver Class Initialized
DEBUG - 2018-03-07 23:57:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-07 23:57:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-07 23:57:37 --> Form Validation Class Initialized
INFO - 2018-03-07 23:57:37 --> Model Class Initialized
INFO - 2018-03-07 23:57:37 --> Controller Class Initialized
INFO - 2018-03-07 23:57:37 --> Model Class Initialized
INFO - 2018-03-07 23:57:37 --> Model Class Initialized
INFO - 2018-03-07 23:57:37 --> Model Class Initialized
INFO - 2018-03-07 23:57:37 --> Model Class Initialized
INFO - 2018-03-07 23:57:37 --> Model Class Initialized
DEBUG - 2018-03-07 23:57:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-07 23:57:37 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-07 23:57:37 --> Final output sent to browser
DEBUG - 2018-03-07 23:57:37 --> Total execution time: 0.0803
INFO - 2018-03-07 23:57:37 --> Config Class Initialized
INFO - 2018-03-07 23:57:37 --> Hooks Class Initialized
DEBUG - 2018-03-07 23:57:37 --> UTF-8 Support Enabled
INFO - 2018-03-07 23:57:37 --> Utf8 Class Initialized
INFO - 2018-03-07 23:57:37 --> URI Class Initialized
INFO - 2018-03-07 23:57:37 --> Router Class Initialized
INFO - 2018-03-07 23:57:37 --> Output Class Initialized
INFO - 2018-03-07 23:57:37 --> Security Class Initialized
DEBUG - 2018-03-07 23:57:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 23:57:37 --> Input Class Initialized
INFO - 2018-03-07 23:57:37 --> Language Class Initialized
INFO - 2018-03-07 23:57:37 --> Loader Class Initialized
INFO - 2018-03-07 23:57:37 --> Helper loaded: url_helper
INFO - 2018-03-07 23:57:37 --> Helper loaded: form_helper
INFO - 2018-03-07 23:57:37 --> Database Driver Class Initialized
DEBUG - 2018-03-07 23:57:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-07 23:57:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-07 23:57:37 --> Form Validation Class Initialized
INFO - 2018-03-07 23:57:37 --> Model Class Initialized
INFO - 2018-03-07 23:57:37 --> Controller Class Initialized
INFO - 2018-03-07 23:57:37 --> Model Class Initialized
INFO - 2018-03-07 23:57:37 --> Model Class Initialized
INFO - 2018-03-07 23:57:37 --> Model Class Initialized
INFO - 2018-03-07 23:57:37 --> Model Class Initialized
INFO - 2018-03-07 23:57:37 --> Model Class Initialized
DEBUG - 2018-03-07 23:57:37 --> Form_validation class already loaded. Second attempt ignored.
