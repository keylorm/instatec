<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-02-18 17:49:54 --> Config Class Initialized
INFO - 2018-02-18 17:49:54 --> Hooks Class Initialized
DEBUG - 2018-02-18 17:49:54 --> UTF-8 Support Enabled
INFO - 2018-02-18 17:49:54 --> Utf8 Class Initialized
INFO - 2018-02-18 17:49:54 --> URI Class Initialized
INFO - 2018-02-18 17:49:54 --> Router Class Initialized
INFO - 2018-02-18 17:49:54 --> Output Class Initialized
INFO - 2018-02-18 17:49:54 --> Security Class Initialized
DEBUG - 2018-02-18 17:49:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 17:49:54 --> Input Class Initialized
INFO - 2018-02-18 17:49:56 --> Language Class Initialized
INFO - 2018-02-18 17:49:56 --> Loader Class Initialized
INFO - 2018-02-18 17:49:56 --> Helper loaded: url_helper
INFO - 2018-02-18 17:49:56 --> Helper loaded: form_helper
INFO - 2018-02-18 17:49:56 --> Database Driver Class Initialized
DEBUG - 2018-02-18 17:49:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 17:49:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 17:49:56 --> Form Validation Class Initialized
INFO - 2018-02-18 17:49:56 --> Model Class Initialized
INFO - 2018-02-18 17:49:56 --> Controller Class Initialized
INFO - 2018-02-18 17:49:56 --> Model Class Initialized
INFO - 2018-02-18 17:49:56 --> Model Class Initialized
INFO - 2018-02-18 17:49:56 --> Model Class Initialized
INFO - 2018-02-18 17:49:56 --> Model Class Initialized
INFO - 2018-02-18 17:49:56 --> Model Class Initialized
DEBUG - 2018-02-18 17:49:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 17:49:56 --> Config Class Initialized
INFO - 2018-02-18 17:49:56 --> Hooks Class Initialized
DEBUG - 2018-02-18 17:49:56 --> UTF-8 Support Enabled
INFO - 2018-02-18 17:49:56 --> Utf8 Class Initialized
INFO - 2018-02-18 17:49:56 --> URI Class Initialized
INFO - 2018-02-18 17:49:56 --> Router Class Initialized
INFO - 2018-02-18 17:49:56 --> Output Class Initialized
INFO - 2018-02-18 17:49:56 --> Security Class Initialized
DEBUG - 2018-02-18 17:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 17:49:56 --> Input Class Initialized
INFO - 2018-02-18 17:49:56 --> Language Class Initialized
INFO - 2018-02-18 17:49:56 --> Loader Class Initialized
INFO - 2018-02-18 17:49:56 --> Helper loaded: url_helper
INFO - 2018-02-18 17:49:56 --> Helper loaded: form_helper
INFO - 2018-02-18 17:49:56 --> Database Driver Class Initialized
DEBUG - 2018-02-18 17:49:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 17:49:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 17:49:56 --> Form Validation Class Initialized
INFO - 2018-02-18 17:49:56 --> Model Class Initialized
INFO - 2018-02-18 17:49:56 --> Controller Class Initialized
INFO - 2018-02-18 17:49:56 --> Model Class Initialized
DEBUG - 2018-02-18 17:49:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 17:49:56 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 17:49:56 --> Final output sent to browser
DEBUG - 2018-02-18 17:49:56 --> Total execution time: 0.0945
INFO - 2018-02-18 17:49:58 --> Config Class Initialized
INFO - 2018-02-18 17:49:58 --> Hooks Class Initialized
DEBUG - 2018-02-18 17:49:58 --> UTF-8 Support Enabled
INFO - 2018-02-18 17:49:58 --> Utf8 Class Initialized
INFO - 2018-02-18 17:49:58 --> URI Class Initialized
INFO - 2018-02-18 17:49:58 --> Router Class Initialized
INFO - 2018-02-18 17:49:58 --> Output Class Initialized
INFO - 2018-02-18 17:49:58 --> Security Class Initialized
DEBUG - 2018-02-18 17:49:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 17:49:58 --> Input Class Initialized
INFO - 2018-02-18 17:49:58 --> Language Class Initialized
INFO - 2018-02-18 17:49:58 --> Loader Class Initialized
INFO - 2018-02-18 17:49:58 --> Helper loaded: url_helper
INFO - 2018-02-18 17:49:58 --> Helper loaded: form_helper
INFO - 2018-02-18 17:49:58 --> Database Driver Class Initialized
DEBUG - 2018-02-18 17:49:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 17:49:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 17:49:58 --> Form Validation Class Initialized
INFO - 2018-02-18 17:49:58 --> Model Class Initialized
INFO - 2018-02-18 17:49:58 --> Controller Class Initialized
INFO - 2018-02-18 17:49:58 --> Model Class Initialized
DEBUG - 2018-02-18 17:49:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 17:49:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-18 17:49:58 --> Config Class Initialized
INFO - 2018-02-18 17:49:58 --> Hooks Class Initialized
DEBUG - 2018-02-18 17:49:58 --> UTF-8 Support Enabled
INFO - 2018-02-18 17:49:58 --> Utf8 Class Initialized
INFO - 2018-02-18 17:49:58 --> URI Class Initialized
DEBUG - 2018-02-18 17:49:58 --> No URI present. Default controller set.
INFO - 2018-02-18 17:49:58 --> Router Class Initialized
INFO - 2018-02-18 17:49:58 --> Output Class Initialized
INFO - 2018-02-18 17:49:58 --> Security Class Initialized
DEBUG - 2018-02-18 17:49:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 17:49:58 --> Input Class Initialized
INFO - 2018-02-18 17:49:58 --> Language Class Initialized
INFO - 2018-02-18 17:49:58 --> Loader Class Initialized
INFO - 2018-02-18 17:49:58 --> Helper loaded: url_helper
INFO - 2018-02-18 17:49:58 --> Helper loaded: form_helper
INFO - 2018-02-18 17:49:58 --> Database Driver Class Initialized
DEBUG - 2018-02-18 17:49:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 17:49:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 17:49:58 --> Form Validation Class Initialized
INFO - 2018-02-18 17:49:58 --> Model Class Initialized
INFO - 2018-02-18 17:49:58 --> Controller Class Initialized
INFO - 2018-02-18 17:49:58 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 17:49:58 --> Final output sent to browser
DEBUG - 2018-02-18 17:49:58 --> Total execution time: 0.0910
INFO - 2018-02-18 17:49:58 --> Config Class Initialized
INFO - 2018-02-18 17:49:58 --> Hooks Class Initialized
DEBUG - 2018-02-18 17:49:58 --> UTF-8 Support Enabled
INFO - 2018-02-18 17:49:58 --> Utf8 Class Initialized
INFO - 2018-02-18 17:49:58 --> URI Class Initialized
INFO - 2018-02-18 17:49:58 --> Router Class Initialized
INFO - 2018-02-18 17:49:58 --> Output Class Initialized
INFO - 2018-02-18 17:49:58 --> Security Class Initialized
DEBUG - 2018-02-18 17:49:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 17:49:58 --> Input Class Initialized
INFO - 2018-02-18 17:49:58 --> Language Class Initialized
INFO - 2018-02-18 17:49:58 --> Loader Class Initialized
INFO - 2018-02-18 17:49:58 --> Helper loaded: url_helper
INFO - 2018-02-18 17:49:58 --> Helper loaded: form_helper
INFO - 2018-02-18 17:49:58 --> Database Driver Class Initialized
DEBUG - 2018-02-18 17:49:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 17:49:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 17:49:58 --> Form Validation Class Initialized
INFO - 2018-02-18 17:49:58 --> Model Class Initialized
INFO - 2018-02-18 17:49:58 --> Controller Class Initialized
INFO - 2018-02-18 17:49:58 --> Model Class Initialized
INFO - 2018-02-18 17:49:58 --> Model Class Initialized
INFO - 2018-02-18 17:49:58 --> Model Class Initialized
INFO - 2018-02-18 17:49:58 --> Model Class Initialized
INFO - 2018-02-18 17:49:58 --> Model Class Initialized
DEBUG - 2018-02-18 17:49:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 17:50:05 --> Config Class Initialized
INFO - 2018-02-18 17:50:05 --> Hooks Class Initialized
DEBUG - 2018-02-18 17:50:05 --> UTF-8 Support Enabled
INFO - 2018-02-18 17:50:05 --> Utf8 Class Initialized
INFO - 2018-02-18 17:50:05 --> URI Class Initialized
INFO - 2018-02-18 17:50:05 --> Router Class Initialized
INFO - 2018-02-18 17:50:05 --> Output Class Initialized
INFO - 2018-02-18 17:50:05 --> Security Class Initialized
DEBUG - 2018-02-18 17:50:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 17:50:05 --> Input Class Initialized
INFO - 2018-02-18 17:50:05 --> Language Class Initialized
INFO - 2018-02-18 17:50:05 --> Loader Class Initialized
INFO - 2018-02-18 17:50:05 --> Helper loaded: url_helper
INFO - 2018-02-18 17:50:05 --> Helper loaded: form_helper
INFO - 2018-02-18 17:50:05 --> Database Driver Class Initialized
DEBUG - 2018-02-18 17:50:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 17:50:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 17:50:05 --> Form Validation Class Initialized
INFO - 2018-02-18 17:50:05 --> Model Class Initialized
INFO - 2018-02-18 17:50:05 --> Controller Class Initialized
INFO - 2018-02-18 17:50:05 --> Model Class Initialized
INFO - 2018-02-18 17:50:05 --> Model Class Initialized
INFO - 2018-02-18 17:50:05 --> Model Class Initialized
INFO - 2018-02-18 17:50:05 --> Model Class Initialized
INFO - 2018-02-18 17:50:05 --> Model Class Initialized
DEBUG - 2018-02-18 17:50:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 17:50:05 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 17:50:05 --> Final output sent to browser
DEBUG - 2018-02-18 17:50:05 --> Total execution time: 0.0940
INFO - 2018-02-18 17:50:06 --> Config Class Initialized
INFO - 2018-02-18 17:50:06 --> Hooks Class Initialized
DEBUG - 2018-02-18 17:50:06 --> UTF-8 Support Enabled
INFO - 2018-02-18 17:50:06 --> Utf8 Class Initialized
INFO - 2018-02-18 17:50:06 --> URI Class Initialized
INFO - 2018-02-18 17:50:06 --> Router Class Initialized
INFO - 2018-02-18 17:50:06 --> Output Class Initialized
INFO - 2018-02-18 17:50:06 --> Security Class Initialized
DEBUG - 2018-02-18 17:50:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 17:50:06 --> Input Class Initialized
INFO - 2018-02-18 17:50:06 --> Language Class Initialized
INFO - 2018-02-18 17:50:06 --> Loader Class Initialized
INFO - 2018-02-18 17:50:06 --> Helper loaded: url_helper
INFO - 2018-02-18 17:50:06 --> Helper loaded: form_helper
INFO - 2018-02-18 17:50:06 --> Database Driver Class Initialized
DEBUG - 2018-02-18 17:50:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 17:50:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 17:50:06 --> Form Validation Class Initialized
INFO - 2018-02-18 17:50:06 --> Model Class Initialized
INFO - 2018-02-18 17:50:06 --> Controller Class Initialized
INFO - 2018-02-18 17:50:06 --> Model Class Initialized
INFO - 2018-02-18 17:50:06 --> Model Class Initialized
INFO - 2018-02-18 17:50:06 --> Model Class Initialized
INFO - 2018-02-18 17:50:06 --> Model Class Initialized
INFO - 2018-02-18 17:50:06 --> Model Class Initialized
DEBUG - 2018-02-18 17:50:06 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-18 17:50:06 --> Severity: Warning --> Division by zero D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 534
INFO - 2018-02-18 17:50:08 --> Config Class Initialized
INFO - 2018-02-18 17:50:08 --> Hooks Class Initialized
INFO - 2018-02-18 17:50:08 --> Config Class Initialized
INFO - 2018-02-18 17:50:08 --> Hooks Class Initialized
DEBUG - 2018-02-18 17:50:08 --> UTF-8 Support Enabled
INFO - 2018-02-18 17:50:08 --> Utf8 Class Initialized
INFO - 2018-02-18 17:50:08 --> URI Class Initialized
INFO - 2018-02-18 17:50:08 --> Config Class Initialized
INFO - 2018-02-18 17:50:08 --> Hooks Class Initialized
DEBUG - 2018-02-18 17:50:08 --> UTF-8 Support Enabled
INFO - 2018-02-18 17:50:08 --> Utf8 Class Initialized
INFO - 2018-02-18 17:50:08 --> Router Class Initialized
INFO - 2018-02-18 17:50:08 --> URI Class Initialized
DEBUG - 2018-02-18 17:50:08 --> UTF-8 Support Enabled
INFO - 2018-02-18 17:50:08 --> Output Class Initialized
INFO - 2018-02-18 17:50:08 --> Utf8 Class Initialized
INFO - 2018-02-18 17:50:08 --> Router Class Initialized
INFO - 2018-02-18 17:50:08 --> URI Class Initialized
INFO - 2018-02-18 17:50:08 --> Security Class Initialized
DEBUG - 2018-02-18 17:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 17:50:08 --> Input Class Initialized
INFO - 2018-02-18 17:50:08 --> Output Class Initialized
INFO - 2018-02-18 17:50:08 --> Router Class Initialized
INFO - 2018-02-18 17:50:08 --> Language Class Initialized
INFO - 2018-02-18 17:50:08 --> Security Class Initialized
ERROR - 2018-02-18 17:50:08 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-18 17:50:08 --> Output Class Initialized
DEBUG - 2018-02-18 17:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 17:50:08 --> Input Class Initialized
INFO - 2018-02-18 17:50:08 --> Security Class Initialized
INFO - 2018-02-18 17:50:08 --> Language Class Initialized
DEBUG - 2018-02-18 17:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 17:50:08 --> Input Class Initialized
ERROR - 2018-02-18 17:50:08 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-18 17:50:08 --> Language Class Initialized
ERROR - 2018-02-18 17:50:08 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-18 17:51:28 --> Config Class Initialized
INFO - 2018-02-18 17:51:28 --> Hooks Class Initialized
DEBUG - 2018-02-18 17:51:28 --> UTF-8 Support Enabled
INFO - 2018-02-18 17:51:28 --> Utf8 Class Initialized
INFO - 2018-02-18 17:51:28 --> URI Class Initialized
INFO - 2018-02-18 17:51:28 --> Router Class Initialized
INFO - 2018-02-18 17:51:28 --> Output Class Initialized
INFO - 2018-02-18 17:51:28 --> Security Class Initialized
DEBUG - 2018-02-18 17:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 17:51:28 --> Input Class Initialized
INFO - 2018-02-18 17:51:28 --> Language Class Initialized
INFO - 2018-02-18 17:51:28 --> Loader Class Initialized
INFO - 2018-02-18 17:51:28 --> Helper loaded: url_helper
INFO - 2018-02-18 17:51:28 --> Helper loaded: form_helper
INFO - 2018-02-18 17:51:28 --> Database Driver Class Initialized
DEBUG - 2018-02-18 17:51:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 17:51:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 17:51:28 --> Form Validation Class Initialized
INFO - 2018-02-18 17:51:28 --> Model Class Initialized
INFO - 2018-02-18 17:51:28 --> Controller Class Initialized
INFO - 2018-02-18 17:51:28 --> Model Class Initialized
INFO - 2018-02-18 17:51:28 --> Model Class Initialized
INFO - 2018-02-18 17:51:28 --> Model Class Initialized
INFO - 2018-02-18 17:51:28 --> Model Class Initialized
INFO - 2018-02-18 17:51:28 --> Model Class Initialized
DEBUG - 2018-02-18 17:51:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 17:51:28 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 17:51:28 --> Final output sent to browser
DEBUG - 2018-02-18 17:51:28 --> Total execution time: 0.0865
INFO - 2018-02-18 17:51:28 --> Config Class Initialized
INFO - 2018-02-18 17:51:28 --> Hooks Class Initialized
INFO - 2018-02-18 17:51:28 --> Config Class Initialized
INFO - 2018-02-18 17:51:28 --> Hooks Class Initialized
DEBUG - 2018-02-18 17:51:28 --> UTF-8 Support Enabled
INFO - 2018-02-18 17:51:28 --> Utf8 Class Initialized
INFO - 2018-02-18 17:51:28 --> URI Class Initialized
DEBUG - 2018-02-18 17:51:28 --> UTF-8 Support Enabled
INFO - 2018-02-18 17:51:28 --> Utf8 Class Initialized
INFO - 2018-02-18 17:51:28 --> Router Class Initialized
INFO - 2018-02-18 17:51:28 --> URI Class Initialized
INFO - 2018-02-18 17:51:28 --> Output Class Initialized
INFO - 2018-02-18 17:51:28 --> Router Class Initialized
INFO - 2018-02-18 17:51:28 --> Security Class Initialized
DEBUG - 2018-02-18 17:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 17:51:28 --> Input Class Initialized
INFO - 2018-02-18 17:51:28 --> Output Class Initialized
INFO - 2018-02-18 17:51:28 --> Language Class Initialized
INFO - 2018-02-18 17:51:28 --> Security Class Initialized
ERROR - 2018-02-18 17:51:28 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-02-18 17:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 17:51:28 --> Input Class Initialized
INFO - 2018-02-18 17:51:28 --> Language Class Initialized
ERROR - 2018-02-18 17:51:28 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-18 17:51:28 --> Config Class Initialized
INFO - 2018-02-18 17:51:28 --> Hooks Class Initialized
INFO - 2018-02-18 17:51:28 --> Config Class Initialized
INFO - 2018-02-18 17:51:28 --> Hooks Class Initialized
DEBUG - 2018-02-18 17:51:28 --> UTF-8 Support Enabled
INFO - 2018-02-18 17:51:28 --> Utf8 Class Initialized
INFO - 2018-02-18 17:51:28 --> URI Class Initialized
DEBUG - 2018-02-18 17:51:28 --> UTF-8 Support Enabled
INFO - 2018-02-18 17:51:28 --> Utf8 Class Initialized
INFO - 2018-02-18 17:51:28 --> URI Class Initialized
INFO - 2018-02-18 17:51:28 --> Router Class Initialized
INFO - 2018-02-18 17:51:28 --> Router Class Initialized
INFO - 2018-02-18 17:51:28 --> Output Class Initialized
INFO - 2018-02-18 17:51:28 --> Security Class Initialized
INFO - 2018-02-18 17:51:28 --> Output Class Initialized
DEBUG - 2018-02-18 17:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 17:51:28 --> Security Class Initialized
INFO - 2018-02-18 17:51:28 --> Input Class Initialized
INFO - 2018-02-18 17:51:28 --> Language Class Initialized
DEBUG - 2018-02-18 17:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 17:51:28 --> Input Class Initialized
ERROR - 2018-02-18 17:51:28 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-18 17:51:28 --> Language Class Initialized
ERROR - 2018-02-18 17:51:28 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-18 17:51:28 --> Config Class Initialized
INFO - 2018-02-18 17:51:28 --> Config Class Initialized
INFO - 2018-02-18 17:51:28 --> Hooks Class Initialized
INFO - 2018-02-18 17:51:28 --> Hooks Class Initialized
INFO - 2018-02-18 17:51:28 --> Config Class Initialized
INFO - 2018-02-18 17:51:28 --> Hooks Class Initialized
DEBUG - 2018-02-18 17:51:28 --> UTF-8 Support Enabled
DEBUG - 2018-02-18 17:51:28 --> UTF-8 Support Enabled
INFO - 2018-02-18 17:51:28 --> Utf8 Class Initialized
INFO - 2018-02-18 17:51:28 --> Utf8 Class Initialized
DEBUG - 2018-02-18 17:51:28 --> UTF-8 Support Enabled
INFO - 2018-02-18 17:51:28 --> Utf8 Class Initialized
INFO - 2018-02-18 17:51:28 --> URI Class Initialized
INFO - 2018-02-18 17:51:28 --> URI Class Initialized
INFO - 2018-02-18 17:51:28 --> URI Class Initialized
INFO - 2018-02-18 17:51:28 --> Router Class Initialized
INFO - 2018-02-18 17:51:28 --> Router Class Initialized
INFO - 2018-02-18 17:51:28 --> Output Class Initialized
INFO - 2018-02-18 17:51:28 --> Router Class Initialized
INFO - 2018-02-18 17:51:28 --> Output Class Initialized
INFO - 2018-02-18 17:51:28 --> Security Class Initialized
INFO - 2018-02-18 17:51:28 --> Security Class Initialized
INFO - 2018-02-18 17:51:28 --> Output Class Initialized
DEBUG - 2018-02-18 17:51:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-18 17:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 17:51:28 --> Input Class Initialized
INFO - 2018-02-18 17:51:28 --> Security Class Initialized
INFO - 2018-02-18 17:51:28 --> Input Class Initialized
INFO - 2018-02-18 17:51:28 --> Language Class Initialized
INFO - 2018-02-18 17:51:28 --> Language Class Initialized
DEBUG - 2018-02-18 17:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 17:51:28 --> Input Class Initialized
ERROR - 2018-02-18 17:51:28 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-18 17:51:28 --> Language Class Initialized
ERROR - 2018-02-18 17:51:28 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-18 17:51:28 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-18 17:51:29 --> Config Class Initialized
INFO - 2018-02-18 17:51:29 --> Hooks Class Initialized
DEBUG - 2018-02-18 17:51:29 --> UTF-8 Support Enabled
INFO - 2018-02-18 17:51:29 --> Utf8 Class Initialized
INFO - 2018-02-18 17:51:29 --> URI Class Initialized
INFO - 2018-02-18 17:51:29 --> Router Class Initialized
INFO - 2018-02-18 17:51:29 --> Output Class Initialized
INFO - 2018-02-18 17:51:29 --> Security Class Initialized
DEBUG - 2018-02-18 17:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 17:51:29 --> Input Class Initialized
INFO - 2018-02-18 17:51:29 --> Language Class Initialized
INFO - 2018-02-18 17:51:29 --> Loader Class Initialized
INFO - 2018-02-18 17:51:29 --> Helper loaded: url_helper
INFO - 2018-02-18 17:51:29 --> Helper loaded: form_helper
INFO - 2018-02-18 17:51:29 --> Database Driver Class Initialized
DEBUG - 2018-02-18 17:51:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 17:51:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 17:51:29 --> Form Validation Class Initialized
INFO - 2018-02-18 17:51:29 --> Model Class Initialized
INFO - 2018-02-18 17:51:29 --> Controller Class Initialized
INFO - 2018-02-18 17:51:29 --> Model Class Initialized
INFO - 2018-02-18 17:51:29 --> Model Class Initialized
INFO - 2018-02-18 17:51:29 --> Model Class Initialized
INFO - 2018-02-18 17:51:29 --> Model Class Initialized
INFO - 2018-02-18 17:51:29 --> Model Class Initialized
DEBUG - 2018-02-18 17:51:29 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-18 17:51:29 --> Severity: Warning --> Division by zero D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 534
INFO - 2018-02-18 17:52:12 --> Config Class Initialized
INFO - 2018-02-18 17:52:12 --> Hooks Class Initialized
DEBUG - 2018-02-18 17:52:12 --> UTF-8 Support Enabled
INFO - 2018-02-18 17:52:12 --> Utf8 Class Initialized
INFO - 2018-02-18 17:52:12 --> URI Class Initialized
INFO - 2018-02-18 17:52:12 --> Router Class Initialized
INFO - 2018-02-18 17:52:12 --> Output Class Initialized
INFO - 2018-02-18 17:52:12 --> Security Class Initialized
DEBUG - 2018-02-18 17:52:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 17:52:12 --> Input Class Initialized
INFO - 2018-02-18 17:52:12 --> Language Class Initialized
INFO - 2018-02-18 17:52:12 --> Loader Class Initialized
INFO - 2018-02-18 17:52:12 --> Helper loaded: url_helper
INFO - 2018-02-18 17:52:12 --> Helper loaded: form_helper
INFO - 2018-02-18 17:52:12 --> Database Driver Class Initialized
DEBUG - 2018-02-18 17:52:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 17:52:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 17:52:12 --> Form Validation Class Initialized
INFO - 2018-02-18 17:52:12 --> Model Class Initialized
INFO - 2018-02-18 17:52:12 --> Controller Class Initialized
INFO - 2018-02-18 17:52:12 --> Model Class Initialized
INFO - 2018-02-18 17:52:12 --> Model Class Initialized
INFO - 2018-02-18 17:52:12 --> Model Class Initialized
INFO - 2018-02-18 17:52:12 --> Model Class Initialized
INFO - 2018-02-18 17:52:12 --> Model Class Initialized
DEBUG - 2018-02-18 17:52:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 17:52:12 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 17:52:12 --> Final output sent to browser
DEBUG - 2018-02-18 17:52:12 --> Total execution time: 0.1034
INFO - 2018-02-18 17:52:13 --> Config Class Initialized
INFO - 2018-02-18 17:52:13 --> Config Class Initialized
INFO - 2018-02-18 17:52:13 --> Hooks Class Initialized
INFO - 2018-02-18 17:52:13 --> Hooks Class Initialized
INFO - 2018-02-18 17:52:13 --> Config Class Initialized
INFO - 2018-02-18 17:52:13 --> Hooks Class Initialized
DEBUG - 2018-02-18 17:52:13 --> UTF-8 Support Enabled
INFO - 2018-02-18 17:52:13 --> Utf8 Class Initialized
INFO - 2018-02-18 17:52:13 --> Config Class Initialized
DEBUG - 2018-02-18 17:52:13 --> UTF-8 Support Enabled
INFO - 2018-02-18 17:52:13 --> Hooks Class Initialized
INFO - 2018-02-18 17:52:13 --> Utf8 Class Initialized
DEBUG - 2018-02-18 17:52:13 --> UTF-8 Support Enabled
INFO - 2018-02-18 17:52:13 --> URI Class Initialized
INFO - 2018-02-18 17:52:13 --> Utf8 Class Initialized
INFO - 2018-02-18 17:52:13 --> URI Class Initialized
INFO - 2018-02-18 17:52:13 --> URI Class Initialized
INFO - 2018-02-18 17:52:13 --> Router Class Initialized
DEBUG - 2018-02-18 17:52:13 --> UTF-8 Support Enabled
INFO - 2018-02-18 17:52:13 --> Utf8 Class Initialized
INFO - 2018-02-18 17:52:13 --> Router Class Initialized
INFO - 2018-02-18 17:52:13 --> Router Class Initialized
INFO - 2018-02-18 17:52:13 --> Output Class Initialized
INFO - 2018-02-18 17:52:13 --> URI Class Initialized
INFO - 2018-02-18 17:52:13 --> Output Class Initialized
INFO - 2018-02-18 17:52:13 --> Security Class Initialized
INFO - 2018-02-18 17:52:13 --> Output Class Initialized
INFO - 2018-02-18 17:52:13 --> Router Class Initialized
INFO - 2018-02-18 17:52:13 --> Security Class Initialized
DEBUG - 2018-02-18 17:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 17:52:13 --> Security Class Initialized
INFO - 2018-02-18 17:52:13 --> Input Class Initialized
DEBUG - 2018-02-18 17:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 17:52:13 --> Language Class Initialized
INFO - 2018-02-18 17:52:13 --> Input Class Initialized
INFO - 2018-02-18 17:52:13 --> Output Class Initialized
DEBUG - 2018-02-18 17:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 17:52:13 --> Input Class Initialized
INFO - 2018-02-18 17:52:13 --> Language Class Initialized
ERROR - 2018-02-18 17:52:13 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-18 17:52:13 --> Language Class Initialized
INFO - 2018-02-18 17:52:13 --> Security Class Initialized
ERROR - 2018-02-18 17:52:13 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-18 17:52:13 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-02-18 17:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 17:52:13 --> Input Class Initialized
INFO - 2018-02-18 17:52:13 --> Language Class Initialized
ERROR - 2018-02-18 17:52:13 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-18 17:52:13 --> Config Class Initialized
INFO - 2018-02-18 17:52:13 --> Hooks Class Initialized
INFO - 2018-02-18 17:52:13 --> Config Class Initialized
INFO - 2018-02-18 17:52:13 --> Config Class Initialized
INFO - 2018-02-18 17:52:13 --> Hooks Class Initialized
INFO - 2018-02-18 17:52:13 --> Hooks Class Initialized
DEBUG - 2018-02-18 17:52:13 --> UTF-8 Support Enabled
INFO - 2018-02-18 17:52:13 --> Utf8 Class Initialized
DEBUG - 2018-02-18 17:52:13 --> UTF-8 Support Enabled
DEBUG - 2018-02-18 17:52:13 --> UTF-8 Support Enabled
INFO - 2018-02-18 17:52:13 --> Utf8 Class Initialized
INFO - 2018-02-18 17:52:13 --> Utf8 Class Initialized
INFO - 2018-02-18 17:52:13 --> URI Class Initialized
INFO - 2018-02-18 17:52:13 --> URI Class Initialized
INFO - 2018-02-18 17:52:13 --> URI Class Initialized
INFO - 2018-02-18 17:52:13 --> Router Class Initialized
INFO - 2018-02-18 17:52:13 --> Router Class Initialized
INFO - 2018-02-18 17:52:13 --> Router Class Initialized
INFO - 2018-02-18 17:52:13 --> Output Class Initialized
INFO - 2018-02-18 17:52:13 --> Output Class Initialized
INFO - 2018-02-18 17:52:13 --> Output Class Initialized
INFO - 2018-02-18 17:52:13 --> Security Class Initialized
INFO - 2018-02-18 17:52:13 --> Security Class Initialized
INFO - 2018-02-18 17:52:13 --> Security Class Initialized
DEBUG - 2018-02-18 17:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 17:52:13 --> Input Class Initialized
DEBUG - 2018-02-18 17:52:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-18 17:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 17:52:13 --> Input Class Initialized
INFO - 2018-02-18 17:52:13 --> Input Class Initialized
INFO - 2018-02-18 17:52:13 --> Language Class Initialized
INFO - 2018-02-18 17:52:13 --> Language Class Initialized
INFO - 2018-02-18 17:52:13 --> Language Class Initialized
ERROR - 2018-02-18 17:52:13 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-18 17:52:13 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-18 17:52:13 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-18 17:52:13 --> Config Class Initialized
INFO - 2018-02-18 17:52:13 --> Hooks Class Initialized
INFO - 2018-02-18 17:52:13 --> Config Class Initialized
INFO - 2018-02-18 17:52:13 --> Hooks Class Initialized
DEBUG - 2018-02-18 17:52:13 --> UTF-8 Support Enabled
INFO - 2018-02-18 17:52:13 --> Utf8 Class Initialized
INFO - 2018-02-18 17:52:13 --> URI Class Initialized
DEBUG - 2018-02-18 17:52:13 --> UTF-8 Support Enabled
INFO - 2018-02-18 17:52:13 --> Utf8 Class Initialized
INFO - 2018-02-18 17:52:13 --> Router Class Initialized
INFO - 2018-02-18 17:52:13 --> URI Class Initialized
INFO - 2018-02-18 17:52:13 --> Output Class Initialized
INFO - 2018-02-18 17:52:13 --> Router Class Initialized
INFO - 2018-02-18 17:52:13 --> Security Class Initialized
INFO - 2018-02-18 17:52:13 --> Output Class Initialized
DEBUG - 2018-02-18 17:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 17:52:13 --> Input Class Initialized
INFO - 2018-02-18 17:52:13 --> Security Class Initialized
INFO - 2018-02-18 17:52:13 --> Language Class Initialized
DEBUG - 2018-02-18 17:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 17:52:13 --> Input Class Initialized
INFO - 2018-02-18 17:52:13 --> Language Class Initialized
INFO - 2018-02-18 17:52:13 --> Loader Class Initialized
INFO - 2018-02-18 17:52:13 --> Helper loaded: url_helper
INFO - 2018-02-18 17:52:13 --> Loader Class Initialized
INFO - 2018-02-18 17:52:13 --> Helper loaded: form_helper
INFO - 2018-02-18 17:52:13 --> Helper loaded: url_helper
INFO - 2018-02-18 17:52:13 --> Helper loaded: form_helper
INFO - 2018-02-18 17:52:13 --> Database Driver Class Initialized
DEBUG - 2018-02-18 17:52:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 17:52:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 17:52:13 --> Database Driver Class Initialized
INFO - 2018-02-18 17:52:13 --> Form Validation Class Initialized
INFO - 2018-02-18 17:52:13 --> Model Class Initialized
INFO - 2018-02-18 17:52:13 --> Controller Class Initialized
DEBUG - 2018-02-18 17:52:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 17:52:13 --> Model Class Initialized
INFO - 2018-02-18 17:52:13 --> Model Class Initialized
INFO - 2018-02-18 17:52:13 --> Model Class Initialized
INFO - 2018-02-18 17:52:13 --> Model Class Initialized
INFO - 2018-02-18 17:52:13 --> Model Class Initialized
DEBUG - 2018-02-18 17:52:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 17:52:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 17:52:13 --> Form Validation Class Initialized
INFO - 2018-02-18 17:52:13 --> Model Class Initialized
INFO - 2018-02-18 17:52:13 --> Controller Class Initialized
INFO - 2018-02-18 17:52:13 --> Model Class Initialized
INFO - 2018-02-18 17:52:13 --> Model Class Initialized
INFO - 2018-02-18 17:52:13 --> Model Class Initialized
INFO - 2018-02-18 17:52:13 --> Model Class Initialized
INFO - 2018-02-18 17:52:13 --> Model Class Initialized
DEBUG - 2018-02-18 17:52:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 17:52:30 --> Config Class Initialized
INFO - 2018-02-18 17:52:30 --> Hooks Class Initialized
DEBUG - 2018-02-18 17:52:30 --> UTF-8 Support Enabled
INFO - 2018-02-18 17:52:30 --> Utf8 Class Initialized
INFO - 2018-02-18 17:52:30 --> URI Class Initialized
INFO - 2018-02-18 17:52:30 --> Router Class Initialized
INFO - 2018-02-18 17:52:30 --> Output Class Initialized
INFO - 2018-02-18 17:52:30 --> Security Class Initialized
DEBUG - 2018-02-18 17:52:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 17:52:30 --> Input Class Initialized
INFO - 2018-02-18 17:52:30 --> Language Class Initialized
INFO - 2018-02-18 17:52:30 --> Loader Class Initialized
INFO - 2018-02-18 17:52:30 --> Helper loaded: url_helper
INFO - 2018-02-18 17:52:30 --> Helper loaded: form_helper
INFO - 2018-02-18 17:52:30 --> Database Driver Class Initialized
DEBUG - 2018-02-18 17:52:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 17:52:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 17:52:30 --> Form Validation Class Initialized
INFO - 2018-02-18 17:52:30 --> Model Class Initialized
INFO - 2018-02-18 17:52:30 --> Controller Class Initialized
INFO - 2018-02-18 17:52:30 --> Model Class Initialized
INFO - 2018-02-18 17:52:30 --> Model Class Initialized
INFO - 2018-02-18 17:52:30 --> Model Class Initialized
INFO - 2018-02-18 17:52:30 --> Model Class Initialized
INFO - 2018-02-18 17:52:30 --> Model Class Initialized
DEBUG - 2018-02-18 17:52:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 17:52:31 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 17:52:31 --> Final output sent to browser
DEBUG - 2018-02-18 17:52:31 --> Total execution time: 0.4747
INFO - 2018-02-18 17:52:31 --> Config Class Initialized
INFO - 2018-02-18 17:52:31 --> Hooks Class Initialized
INFO - 2018-02-18 17:52:31 --> Config Class Initialized
INFO - 2018-02-18 17:52:31 --> Config Class Initialized
INFO - 2018-02-18 17:52:31 --> Hooks Class Initialized
INFO - 2018-02-18 17:52:31 --> Hooks Class Initialized
DEBUG - 2018-02-18 17:52:31 --> UTF-8 Support Enabled
INFO - 2018-02-18 17:52:31 --> Utf8 Class Initialized
INFO - 2018-02-18 17:52:31 --> Config Class Initialized
INFO - 2018-02-18 17:52:31 --> Hooks Class Initialized
INFO - 2018-02-18 17:52:31 --> URI Class Initialized
DEBUG - 2018-02-18 17:52:31 --> UTF-8 Support Enabled
DEBUG - 2018-02-18 17:52:31 --> UTF-8 Support Enabled
INFO - 2018-02-18 17:52:31 --> Utf8 Class Initialized
INFO - 2018-02-18 17:52:31 --> Utf8 Class Initialized
INFO - 2018-02-18 17:52:31 --> URI Class Initialized
INFO - 2018-02-18 17:52:31 --> Router Class Initialized
INFO - 2018-02-18 17:52:31 --> URI Class Initialized
DEBUG - 2018-02-18 17:52:31 --> UTF-8 Support Enabled
INFO - 2018-02-18 17:52:31 --> Utf8 Class Initialized
INFO - 2018-02-18 17:52:31 --> URI Class Initialized
INFO - 2018-02-18 17:52:31 --> Router Class Initialized
INFO - 2018-02-18 17:52:31 --> Output Class Initialized
INFO - 2018-02-18 17:52:31 --> Router Class Initialized
INFO - 2018-02-18 17:52:31 --> Router Class Initialized
INFO - 2018-02-18 17:52:31 --> Security Class Initialized
INFO - 2018-02-18 17:52:31 --> Output Class Initialized
INFO - 2018-02-18 17:52:31 --> Output Class Initialized
DEBUG - 2018-02-18 17:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 17:52:31 --> Output Class Initialized
INFO - 2018-02-18 17:52:31 --> Input Class Initialized
INFO - 2018-02-18 17:52:31 --> Security Class Initialized
INFO - 2018-02-18 17:52:31 --> Language Class Initialized
INFO - 2018-02-18 17:52:31 --> Security Class Initialized
INFO - 2018-02-18 17:52:31 --> Security Class Initialized
DEBUG - 2018-02-18 17:52:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-18 17:52:31 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-18 17:52:31 --> Input Class Initialized
DEBUG - 2018-02-18 17:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 17:52:31 --> Input Class Initialized
DEBUG - 2018-02-18 17:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 17:52:31 --> Input Class Initialized
INFO - 2018-02-18 17:52:31 --> Language Class Initialized
INFO - 2018-02-18 17:52:31 --> Language Class Initialized
INFO - 2018-02-18 17:52:31 --> Language Class Initialized
ERROR - 2018-02-18 17:52:31 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-18 17:52:31 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-18 17:52:31 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-18 17:52:31 --> Config Class Initialized
INFO - 2018-02-18 17:52:31 --> Hooks Class Initialized
INFO - 2018-02-18 17:52:31 --> Config Class Initialized
INFO - 2018-02-18 17:52:31 --> Config Class Initialized
INFO - 2018-02-18 17:52:31 --> Hooks Class Initialized
INFO - 2018-02-18 17:52:31 --> Hooks Class Initialized
DEBUG - 2018-02-18 17:52:31 --> UTF-8 Support Enabled
INFO - 2018-02-18 17:52:31 --> Utf8 Class Initialized
INFO - 2018-02-18 17:52:31 --> URI Class Initialized
DEBUG - 2018-02-18 17:52:31 --> UTF-8 Support Enabled
DEBUG - 2018-02-18 17:52:31 --> UTF-8 Support Enabled
INFO - 2018-02-18 17:52:31 --> Utf8 Class Initialized
INFO - 2018-02-18 17:52:31 --> Utf8 Class Initialized
INFO - 2018-02-18 17:52:31 --> Router Class Initialized
INFO - 2018-02-18 17:52:31 --> URI Class Initialized
INFO - 2018-02-18 17:52:31 --> URI Class Initialized
INFO - 2018-02-18 17:52:31 --> Output Class Initialized
INFO - 2018-02-18 17:52:31 --> Router Class Initialized
INFO - 2018-02-18 17:52:31 --> Router Class Initialized
INFO - 2018-02-18 17:52:31 --> Security Class Initialized
INFO - 2018-02-18 17:52:31 --> Output Class Initialized
INFO - 2018-02-18 17:52:31 --> Output Class Initialized
DEBUG - 2018-02-18 17:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 17:52:31 --> Input Class Initialized
INFO - 2018-02-18 17:52:31 --> Security Class Initialized
INFO - 2018-02-18 17:52:31 --> Security Class Initialized
INFO - 2018-02-18 17:52:31 --> Language Class Initialized
DEBUG - 2018-02-18 17:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 17:52:31 --> Input Class Initialized
DEBUG - 2018-02-18 17:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 17:52:31 --> Input Class Initialized
ERROR - 2018-02-18 17:52:31 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-18 17:52:31 --> Language Class Initialized
INFO - 2018-02-18 17:52:31 --> Language Class Initialized
ERROR - 2018-02-18 17:52:31 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-18 17:52:31 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-18 17:52:31 --> Config Class Initialized
INFO - 2018-02-18 17:52:31 --> Hooks Class Initialized
INFO - 2018-02-18 17:52:31 --> Config Class Initialized
INFO - 2018-02-18 17:52:31 --> Hooks Class Initialized
DEBUG - 2018-02-18 17:52:31 --> UTF-8 Support Enabled
INFO - 2018-02-18 17:52:31 --> Utf8 Class Initialized
INFO - 2018-02-18 17:52:31 --> URI Class Initialized
DEBUG - 2018-02-18 17:52:31 --> UTF-8 Support Enabled
INFO - 2018-02-18 17:52:31 --> Utf8 Class Initialized
INFO - 2018-02-18 17:52:31 --> Router Class Initialized
INFO - 2018-02-18 17:52:31 --> URI Class Initialized
INFO - 2018-02-18 17:52:31 --> Output Class Initialized
INFO - 2018-02-18 17:52:31 --> Router Class Initialized
INFO - 2018-02-18 17:52:31 --> Security Class Initialized
INFO - 2018-02-18 17:52:31 --> Output Class Initialized
DEBUG - 2018-02-18 17:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 17:52:31 --> Input Class Initialized
INFO - 2018-02-18 17:52:31 --> Language Class Initialized
INFO - 2018-02-18 17:52:31 --> Security Class Initialized
DEBUG - 2018-02-18 17:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 17:52:31 --> Input Class Initialized
INFO - 2018-02-18 17:52:31 --> Language Class Initialized
INFO - 2018-02-18 17:52:31 --> Loader Class Initialized
INFO - 2018-02-18 17:52:31 --> Helper loaded: url_helper
INFO - 2018-02-18 17:52:31 --> Helper loaded: form_helper
INFO - 2018-02-18 17:52:31 --> Loader Class Initialized
INFO - 2018-02-18 17:52:31 --> Helper loaded: url_helper
INFO - 2018-02-18 17:52:31 --> Helper loaded: form_helper
INFO - 2018-02-18 17:52:31 --> Database Driver Class Initialized
INFO - 2018-02-18 17:52:31 --> Database Driver Class Initialized
DEBUG - 2018-02-18 17:52:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 17:52:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-02-18 17:52:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 17:52:31 --> Form Validation Class Initialized
INFO - 2018-02-18 17:52:31 --> Model Class Initialized
INFO - 2018-02-18 17:52:31 --> Controller Class Initialized
INFO - 2018-02-18 17:52:31 --> Model Class Initialized
INFO - 2018-02-18 17:52:31 --> Model Class Initialized
INFO - 2018-02-18 17:52:31 --> Model Class Initialized
INFO - 2018-02-18 17:52:31 --> Model Class Initialized
INFO - 2018-02-18 17:52:31 --> Model Class Initialized
DEBUG - 2018-02-18 17:52:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 17:52:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 17:52:31 --> Form Validation Class Initialized
INFO - 2018-02-18 17:52:31 --> Model Class Initialized
INFO - 2018-02-18 17:52:31 --> Controller Class Initialized
INFO - 2018-02-18 17:52:31 --> Model Class Initialized
INFO - 2018-02-18 17:52:31 --> Model Class Initialized
INFO - 2018-02-18 17:52:31 --> Model Class Initialized
INFO - 2018-02-18 17:52:31 --> Model Class Initialized
INFO - 2018-02-18 17:52:31 --> Model Class Initialized
DEBUG - 2018-02-18 17:52:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 17:52:34 --> Config Class Initialized
INFO - 2018-02-18 17:52:34 --> Hooks Class Initialized
DEBUG - 2018-02-18 17:52:34 --> UTF-8 Support Enabled
INFO - 2018-02-18 17:52:34 --> Utf8 Class Initialized
INFO - 2018-02-18 17:52:34 --> URI Class Initialized
INFO - 2018-02-18 17:52:34 --> Router Class Initialized
INFO - 2018-02-18 17:52:34 --> Output Class Initialized
INFO - 2018-02-18 17:52:34 --> Security Class Initialized
DEBUG - 2018-02-18 17:52:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 17:52:34 --> Input Class Initialized
INFO - 2018-02-18 17:52:34 --> Language Class Initialized
INFO - 2018-02-18 17:52:34 --> Loader Class Initialized
INFO - 2018-02-18 17:52:34 --> Helper loaded: url_helper
INFO - 2018-02-18 17:52:34 --> Helper loaded: form_helper
INFO - 2018-02-18 17:52:34 --> Database Driver Class Initialized
DEBUG - 2018-02-18 17:52:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 17:52:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 17:52:34 --> Form Validation Class Initialized
INFO - 2018-02-18 17:52:34 --> Model Class Initialized
INFO - 2018-02-18 17:52:34 --> Controller Class Initialized
INFO - 2018-02-18 17:52:34 --> Model Class Initialized
INFO - 2018-02-18 17:52:34 --> Model Class Initialized
INFO - 2018-02-18 17:52:34 --> Model Class Initialized
INFO - 2018-02-18 17:52:34 --> Model Class Initialized
INFO - 2018-02-18 17:52:34 --> Model Class Initialized
DEBUG - 2018-02-18 17:52:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 17:52:34 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 17:52:34 --> Final output sent to browser
DEBUG - 2018-02-18 17:52:34 --> Total execution time: 0.0982
INFO - 2018-02-18 17:52:34 --> Config Class Initialized
INFO - 2018-02-18 17:52:34 --> Hooks Class Initialized
DEBUG - 2018-02-18 17:52:34 --> UTF-8 Support Enabled
INFO - 2018-02-18 17:52:34 --> Utf8 Class Initialized
INFO - 2018-02-18 17:52:34 --> URI Class Initialized
INFO - 2018-02-18 17:52:34 --> Router Class Initialized
INFO - 2018-02-18 17:52:34 --> Output Class Initialized
INFO - 2018-02-18 17:52:34 --> Security Class Initialized
DEBUG - 2018-02-18 17:52:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 17:52:34 --> Input Class Initialized
INFO - 2018-02-18 17:52:34 --> Language Class Initialized
INFO - 2018-02-18 17:52:34 --> Loader Class Initialized
INFO - 2018-02-18 17:52:34 --> Helper loaded: url_helper
INFO - 2018-02-18 17:52:34 --> Helper loaded: form_helper
INFO - 2018-02-18 17:52:34 --> Database Driver Class Initialized
DEBUG - 2018-02-18 17:52:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 17:52:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 17:52:34 --> Form Validation Class Initialized
INFO - 2018-02-18 17:52:34 --> Model Class Initialized
INFO - 2018-02-18 17:52:34 --> Controller Class Initialized
INFO - 2018-02-18 17:52:34 --> Model Class Initialized
INFO - 2018-02-18 17:52:34 --> Model Class Initialized
INFO - 2018-02-18 17:52:34 --> Model Class Initialized
INFO - 2018-02-18 17:52:34 --> Model Class Initialized
INFO - 2018-02-18 17:52:34 --> Model Class Initialized
DEBUG - 2018-02-18 17:52:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 17:52:45 --> Config Class Initialized
INFO - 2018-02-18 17:52:45 --> Hooks Class Initialized
DEBUG - 2018-02-18 17:52:45 --> UTF-8 Support Enabled
INFO - 2018-02-18 17:52:45 --> Utf8 Class Initialized
INFO - 2018-02-18 17:52:45 --> URI Class Initialized
INFO - 2018-02-18 17:52:45 --> Router Class Initialized
INFO - 2018-02-18 17:52:45 --> Output Class Initialized
INFO - 2018-02-18 17:52:45 --> Security Class Initialized
DEBUG - 2018-02-18 17:52:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 17:52:45 --> Input Class Initialized
INFO - 2018-02-18 17:52:45 --> Language Class Initialized
INFO - 2018-02-18 17:52:45 --> Loader Class Initialized
INFO - 2018-02-18 17:52:45 --> Helper loaded: url_helper
INFO - 2018-02-18 17:52:45 --> Helper loaded: form_helper
INFO - 2018-02-18 17:52:45 --> Database Driver Class Initialized
DEBUG - 2018-02-18 17:52:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 17:52:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 17:52:45 --> Form Validation Class Initialized
INFO - 2018-02-18 17:52:45 --> Model Class Initialized
INFO - 2018-02-18 17:52:45 --> Controller Class Initialized
INFO - 2018-02-18 17:52:45 --> Model Class Initialized
INFO - 2018-02-18 17:52:45 --> Model Class Initialized
INFO - 2018-02-18 17:52:45 --> Model Class Initialized
INFO - 2018-02-18 17:52:45 --> Model Class Initialized
INFO - 2018-02-18 17:52:45 --> Model Class Initialized
DEBUG - 2018-02-18 17:52:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 17:52:45 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 17:52:45 --> Final output sent to browser
DEBUG - 2018-02-18 17:52:45 --> Total execution time: 0.0992
INFO - 2018-02-18 17:52:45 --> Config Class Initialized
INFO - 2018-02-18 17:52:45 --> Hooks Class Initialized
DEBUG - 2018-02-18 17:52:45 --> UTF-8 Support Enabled
INFO - 2018-02-18 17:52:45 --> Utf8 Class Initialized
INFO - 2018-02-18 17:52:45 --> URI Class Initialized
INFO - 2018-02-18 17:52:45 --> Router Class Initialized
INFO - 2018-02-18 17:52:45 --> Output Class Initialized
INFO - 2018-02-18 17:52:45 --> Security Class Initialized
DEBUG - 2018-02-18 17:52:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 17:52:45 --> Input Class Initialized
INFO - 2018-02-18 17:52:45 --> Language Class Initialized
INFO - 2018-02-18 17:52:45 --> Loader Class Initialized
INFO - 2018-02-18 17:52:45 --> Helper loaded: url_helper
INFO - 2018-02-18 17:52:45 --> Helper loaded: form_helper
INFO - 2018-02-18 17:52:45 --> Database Driver Class Initialized
DEBUG - 2018-02-18 17:52:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 17:52:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 17:52:45 --> Form Validation Class Initialized
INFO - 2018-02-18 17:52:45 --> Model Class Initialized
INFO - 2018-02-18 17:52:45 --> Controller Class Initialized
INFO - 2018-02-18 17:52:45 --> Model Class Initialized
INFO - 2018-02-18 17:52:45 --> Model Class Initialized
INFO - 2018-02-18 17:52:45 --> Model Class Initialized
INFO - 2018-02-18 17:52:45 --> Model Class Initialized
INFO - 2018-02-18 17:52:45 --> Model Class Initialized
DEBUG - 2018-02-18 17:52:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 18:03:11 --> Config Class Initialized
INFO - 2018-02-18 18:03:11 --> Hooks Class Initialized
DEBUG - 2018-02-18 18:03:11 --> UTF-8 Support Enabled
INFO - 2018-02-18 18:03:11 --> Utf8 Class Initialized
INFO - 2018-02-18 18:03:11 --> URI Class Initialized
INFO - 2018-02-18 18:03:11 --> Router Class Initialized
INFO - 2018-02-18 18:03:11 --> Output Class Initialized
INFO - 2018-02-18 18:03:11 --> Security Class Initialized
DEBUG - 2018-02-18 18:03:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 18:03:11 --> Input Class Initialized
INFO - 2018-02-18 18:03:11 --> Language Class Initialized
INFO - 2018-02-18 18:03:11 --> Loader Class Initialized
INFO - 2018-02-18 18:03:11 --> Helper loaded: url_helper
INFO - 2018-02-18 18:03:11 --> Helper loaded: form_helper
INFO - 2018-02-18 18:03:11 --> Database Driver Class Initialized
DEBUG - 2018-02-18 18:03:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 18:03:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 18:03:11 --> Form Validation Class Initialized
INFO - 2018-02-18 18:03:11 --> Model Class Initialized
INFO - 2018-02-18 18:03:11 --> Controller Class Initialized
INFO - 2018-02-18 18:03:11 --> Model Class Initialized
INFO - 2018-02-18 18:03:11 --> Model Class Initialized
INFO - 2018-02-18 18:03:11 --> Model Class Initialized
INFO - 2018-02-18 18:03:11 --> Model Class Initialized
INFO - 2018-02-18 18:03:11 --> Model Class Initialized
DEBUG - 2018-02-18 18:03:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 18:03:11 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 18:03:11 --> Final output sent to browser
DEBUG - 2018-02-18 18:03:11 --> Total execution time: 0.1292
INFO - 2018-02-18 18:03:12 --> Config Class Initialized
INFO - 2018-02-18 18:03:12 --> Hooks Class Initialized
DEBUG - 2018-02-18 18:03:12 --> UTF-8 Support Enabled
INFO - 2018-02-18 18:03:12 --> Utf8 Class Initialized
INFO - 2018-02-18 18:03:12 --> URI Class Initialized
INFO - 2018-02-18 18:03:12 --> Router Class Initialized
INFO - 2018-02-18 18:03:12 --> Output Class Initialized
INFO - 2018-02-18 18:03:12 --> Security Class Initialized
DEBUG - 2018-02-18 18:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 18:03:12 --> Input Class Initialized
INFO - 2018-02-18 18:03:12 --> Language Class Initialized
INFO - 2018-02-18 18:03:12 --> Loader Class Initialized
INFO - 2018-02-18 18:03:12 --> Helper loaded: url_helper
INFO - 2018-02-18 18:03:12 --> Helper loaded: form_helper
INFO - 2018-02-18 18:03:12 --> Database Driver Class Initialized
DEBUG - 2018-02-18 18:03:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 18:03:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 18:03:12 --> Form Validation Class Initialized
INFO - 2018-02-18 18:03:12 --> Model Class Initialized
INFO - 2018-02-18 18:03:12 --> Controller Class Initialized
INFO - 2018-02-18 18:03:12 --> Model Class Initialized
INFO - 2018-02-18 18:03:12 --> Model Class Initialized
INFO - 2018-02-18 18:03:12 --> Model Class Initialized
INFO - 2018-02-18 18:03:12 --> Model Class Initialized
INFO - 2018-02-18 18:03:12 --> Model Class Initialized
DEBUG - 2018-02-18 18:03:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 18:03:13 --> Config Class Initialized
INFO - 2018-02-18 18:03:13 --> Hooks Class Initialized
DEBUG - 2018-02-18 18:03:13 --> UTF-8 Support Enabled
INFO - 2018-02-18 18:03:13 --> Utf8 Class Initialized
INFO - 2018-02-18 18:03:13 --> URI Class Initialized
INFO - 2018-02-18 18:03:13 --> Router Class Initialized
INFO - 2018-02-18 18:03:13 --> Output Class Initialized
INFO - 2018-02-18 18:03:13 --> Security Class Initialized
DEBUG - 2018-02-18 18:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 18:03:13 --> Input Class Initialized
INFO - 2018-02-18 18:03:13 --> Language Class Initialized
INFO - 2018-02-18 18:03:13 --> Loader Class Initialized
INFO - 2018-02-18 18:03:13 --> Helper loaded: url_helper
INFO - 2018-02-18 18:03:13 --> Helper loaded: form_helper
INFO - 2018-02-18 18:03:13 --> Database Driver Class Initialized
DEBUG - 2018-02-18 18:03:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 18:03:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 18:03:13 --> Form Validation Class Initialized
INFO - 2018-02-18 18:03:13 --> Model Class Initialized
INFO - 2018-02-18 18:03:13 --> Controller Class Initialized
INFO - 2018-02-18 18:03:13 --> Model Class Initialized
INFO - 2018-02-18 18:03:13 --> Model Class Initialized
INFO - 2018-02-18 18:03:13 --> Model Class Initialized
INFO - 2018-02-18 18:03:13 --> Model Class Initialized
INFO - 2018-02-18 18:03:13 --> Model Class Initialized
DEBUG - 2018-02-18 18:03:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 18:03:13 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 18:03:13 --> Final output sent to browser
DEBUG - 2018-02-18 18:03:13 --> Total execution time: 0.2249
INFO - 2018-02-18 18:03:14 --> Config Class Initialized
INFO - 2018-02-18 18:03:14 --> Hooks Class Initialized
DEBUG - 2018-02-18 18:03:14 --> UTF-8 Support Enabled
INFO - 2018-02-18 18:03:14 --> Utf8 Class Initialized
INFO - 2018-02-18 18:03:14 --> URI Class Initialized
INFO - 2018-02-18 18:03:14 --> Router Class Initialized
INFO - 2018-02-18 18:03:14 --> Output Class Initialized
INFO - 2018-02-18 18:03:14 --> Security Class Initialized
DEBUG - 2018-02-18 18:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 18:03:14 --> Input Class Initialized
INFO - 2018-02-18 18:03:14 --> Language Class Initialized
INFO - 2018-02-18 18:03:14 --> Loader Class Initialized
INFO - 2018-02-18 18:03:14 --> Helper loaded: url_helper
INFO - 2018-02-18 18:03:14 --> Helper loaded: form_helper
INFO - 2018-02-18 18:03:14 --> Database Driver Class Initialized
DEBUG - 2018-02-18 18:03:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 18:03:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 18:03:14 --> Form Validation Class Initialized
INFO - 2018-02-18 18:03:14 --> Model Class Initialized
INFO - 2018-02-18 18:03:14 --> Controller Class Initialized
INFO - 2018-02-18 18:03:14 --> Model Class Initialized
INFO - 2018-02-18 18:03:14 --> Model Class Initialized
INFO - 2018-02-18 18:03:14 --> Model Class Initialized
INFO - 2018-02-18 18:03:14 --> Model Class Initialized
INFO - 2018-02-18 18:03:14 --> Model Class Initialized
DEBUG - 2018-02-18 18:03:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 18:03:14 --> Config Class Initialized
INFO - 2018-02-18 18:03:14 --> Hooks Class Initialized
DEBUG - 2018-02-18 18:03:14 --> UTF-8 Support Enabled
INFO - 2018-02-18 18:03:14 --> Utf8 Class Initialized
INFO - 2018-02-18 18:03:14 --> URI Class Initialized
INFO - 2018-02-18 18:03:14 --> Router Class Initialized
INFO - 2018-02-18 18:03:14 --> Output Class Initialized
INFO - 2018-02-18 18:03:14 --> Security Class Initialized
DEBUG - 2018-02-18 18:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 18:03:14 --> Input Class Initialized
INFO - 2018-02-18 18:03:14 --> Language Class Initialized
INFO - 2018-02-18 18:03:14 --> Loader Class Initialized
INFO - 2018-02-18 18:03:14 --> Helper loaded: url_helper
INFO - 2018-02-18 18:03:14 --> Helper loaded: form_helper
INFO - 2018-02-18 18:03:14 --> Database Driver Class Initialized
DEBUG - 2018-02-18 18:03:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 18:03:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 18:03:14 --> Form Validation Class Initialized
INFO - 2018-02-18 18:03:14 --> Model Class Initialized
INFO - 2018-02-18 18:03:14 --> Controller Class Initialized
INFO - 2018-02-18 18:03:14 --> Model Class Initialized
INFO - 2018-02-18 18:03:14 --> Model Class Initialized
INFO - 2018-02-18 18:03:14 --> Model Class Initialized
INFO - 2018-02-18 18:03:14 --> Model Class Initialized
INFO - 2018-02-18 18:03:14 --> Model Class Initialized
DEBUG - 2018-02-18 18:03:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 18:03:14 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 18:03:14 --> Final output sent to browser
DEBUG - 2018-02-18 18:03:14 --> Total execution time: 0.0924
INFO - 2018-02-18 18:04:33 --> Config Class Initialized
INFO - 2018-02-18 18:04:33 --> Hooks Class Initialized
DEBUG - 2018-02-18 18:04:33 --> UTF-8 Support Enabled
INFO - 2018-02-18 18:04:33 --> Utf8 Class Initialized
INFO - 2018-02-18 18:04:33 --> URI Class Initialized
INFO - 2018-02-18 18:04:33 --> Router Class Initialized
INFO - 2018-02-18 18:04:33 --> Output Class Initialized
INFO - 2018-02-18 18:04:33 --> Security Class Initialized
DEBUG - 2018-02-18 18:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 18:04:33 --> Input Class Initialized
INFO - 2018-02-18 18:04:33 --> Language Class Initialized
INFO - 2018-02-18 18:04:33 --> Loader Class Initialized
INFO - 2018-02-18 18:04:33 --> Helper loaded: url_helper
INFO - 2018-02-18 18:04:33 --> Helper loaded: form_helper
INFO - 2018-02-18 18:04:33 --> Database Driver Class Initialized
DEBUG - 2018-02-18 18:04:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 18:04:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 18:04:33 --> Form Validation Class Initialized
INFO - 2018-02-18 18:04:33 --> Model Class Initialized
INFO - 2018-02-18 18:04:33 --> Controller Class Initialized
INFO - 2018-02-18 18:04:33 --> Model Class Initialized
INFO - 2018-02-18 18:04:33 --> Model Class Initialized
INFO - 2018-02-18 18:04:33 --> Model Class Initialized
INFO - 2018-02-18 18:04:33 --> Model Class Initialized
INFO - 2018-02-18 18:04:33 --> Model Class Initialized
DEBUG - 2018-02-18 18:04:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 18:04:33 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 18:04:33 --> Final output sent to browser
DEBUG - 2018-02-18 18:04:33 --> Total execution time: 0.0806
INFO - 2018-02-18 18:04:37 --> Config Class Initialized
INFO - 2018-02-18 18:04:37 --> Hooks Class Initialized
DEBUG - 2018-02-18 18:04:37 --> UTF-8 Support Enabled
INFO - 2018-02-18 18:04:37 --> Utf8 Class Initialized
INFO - 2018-02-18 18:04:37 --> URI Class Initialized
INFO - 2018-02-18 18:04:37 --> Router Class Initialized
INFO - 2018-02-18 18:04:37 --> Output Class Initialized
INFO - 2018-02-18 18:04:37 --> Security Class Initialized
DEBUG - 2018-02-18 18:04:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 18:04:37 --> Input Class Initialized
INFO - 2018-02-18 18:04:37 --> Language Class Initialized
INFO - 2018-02-18 18:04:37 --> Loader Class Initialized
INFO - 2018-02-18 18:04:37 --> Helper loaded: url_helper
INFO - 2018-02-18 18:04:37 --> Helper loaded: form_helper
INFO - 2018-02-18 18:04:37 --> Database Driver Class Initialized
DEBUG - 2018-02-18 18:04:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 18:04:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 18:04:37 --> Form Validation Class Initialized
INFO - 2018-02-18 18:04:37 --> Model Class Initialized
INFO - 2018-02-18 18:04:37 --> Controller Class Initialized
INFO - 2018-02-18 18:04:37 --> Model Class Initialized
INFO - 2018-02-18 18:04:37 --> Model Class Initialized
INFO - 2018-02-18 18:04:37 --> Model Class Initialized
INFO - 2018-02-18 18:04:37 --> Model Class Initialized
INFO - 2018-02-18 18:04:37 --> Model Class Initialized
DEBUG - 2018-02-18 18:04:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 18:04:37 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 18:04:37 --> Final output sent to browser
DEBUG - 2018-02-18 18:04:37 --> Total execution time: 0.0666
INFO - 2018-02-18 18:06:05 --> Config Class Initialized
INFO - 2018-02-18 18:06:05 --> Hooks Class Initialized
DEBUG - 2018-02-18 18:06:05 --> UTF-8 Support Enabled
INFO - 2018-02-18 18:06:05 --> Utf8 Class Initialized
INFO - 2018-02-18 18:06:05 --> URI Class Initialized
INFO - 2018-02-18 18:06:05 --> Router Class Initialized
INFO - 2018-02-18 18:06:05 --> Output Class Initialized
INFO - 2018-02-18 18:06:05 --> Security Class Initialized
DEBUG - 2018-02-18 18:06:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 18:06:05 --> Input Class Initialized
INFO - 2018-02-18 18:06:05 --> Language Class Initialized
INFO - 2018-02-18 18:06:05 --> Loader Class Initialized
INFO - 2018-02-18 18:06:05 --> Helper loaded: url_helper
INFO - 2018-02-18 18:06:05 --> Helper loaded: form_helper
INFO - 2018-02-18 18:06:05 --> Database Driver Class Initialized
DEBUG - 2018-02-18 18:06:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 18:06:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 18:06:06 --> Form Validation Class Initialized
INFO - 2018-02-18 18:06:06 --> Model Class Initialized
INFO - 2018-02-18 18:06:06 --> Controller Class Initialized
INFO - 2018-02-18 18:06:06 --> Model Class Initialized
INFO - 2018-02-18 18:06:06 --> Model Class Initialized
INFO - 2018-02-18 18:06:06 --> Model Class Initialized
INFO - 2018-02-18 18:06:06 --> Model Class Initialized
INFO - 2018-02-18 18:06:06 --> Model Class Initialized
DEBUG - 2018-02-18 18:06:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 18:06:06 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 18:06:06 --> Final output sent to browser
DEBUG - 2018-02-18 18:06:06 --> Total execution time: 0.0855
INFO - 2018-02-18 18:06:06 --> Config Class Initialized
INFO - 2018-02-18 18:06:06 --> Hooks Class Initialized
DEBUG - 2018-02-18 18:06:06 --> UTF-8 Support Enabled
INFO - 2018-02-18 18:06:06 --> Utf8 Class Initialized
INFO - 2018-02-18 18:06:06 --> URI Class Initialized
INFO - 2018-02-18 18:06:06 --> Router Class Initialized
INFO - 2018-02-18 18:06:06 --> Output Class Initialized
INFO - 2018-02-18 18:06:06 --> Security Class Initialized
DEBUG - 2018-02-18 18:06:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 18:06:06 --> Input Class Initialized
INFO - 2018-02-18 18:06:06 --> Language Class Initialized
INFO - 2018-02-18 18:06:06 --> Loader Class Initialized
INFO - 2018-02-18 18:06:06 --> Helper loaded: url_helper
INFO - 2018-02-18 18:06:06 --> Helper loaded: form_helper
INFO - 2018-02-18 18:06:06 --> Database Driver Class Initialized
DEBUG - 2018-02-18 18:06:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 18:06:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 18:06:06 --> Form Validation Class Initialized
INFO - 2018-02-18 18:06:06 --> Model Class Initialized
INFO - 2018-02-18 18:06:06 --> Controller Class Initialized
INFO - 2018-02-18 18:06:06 --> Model Class Initialized
INFO - 2018-02-18 18:06:06 --> Model Class Initialized
INFO - 2018-02-18 18:06:06 --> Model Class Initialized
INFO - 2018-02-18 18:06:06 --> Model Class Initialized
INFO - 2018-02-18 18:06:06 --> Model Class Initialized
DEBUG - 2018-02-18 18:06:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 18:06:08 --> Config Class Initialized
INFO - 2018-02-18 18:06:08 --> Hooks Class Initialized
DEBUG - 2018-02-18 18:06:08 --> UTF-8 Support Enabled
INFO - 2018-02-18 18:06:08 --> Utf8 Class Initialized
INFO - 2018-02-18 18:06:08 --> URI Class Initialized
INFO - 2018-02-18 18:06:08 --> Router Class Initialized
INFO - 2018-02-18 18:06:08 --> Output Class Initialized
INFO - 2018-02-18 18:06:08 --> Security Class Initialized
DEBUG - 2018-02-18 18:06:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 18:06:08 --> Input Class Initialized
INFO - 2018-02-18 18:06:08 --> Language Class Initialized
INFO - 2018-02-18 18:06:08 --> Loader Class Initialized
INFO - 2018-02-18 18:06:08 --> Helper loaded: url_helper
INFO - 2018-02-18 18:06:08 --> Helper loaded: form_helper
INFO - 2018-02-18 18:06:08 --> Database Driver Class Initialized
DEBUG - 2018-02-18 18:06:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 18:06:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 18:06:08 --> Form Validation Class Initialized
INFO - 2018-02-18 18:06:08 --> Model Class Initialized
INFO - 2018-02-18 18:06:08 --> Controller Class Initialized
INFO - 2018-02-18 18:06:08 --> Model Class Initialized
INFO - 2018-02-18 18:06:08 --> Model Class Initialized
INFO - 2018-02-18 18:06:08 --> Model Class Initialized
INFO - 2018-02-18 18:06:08 --> Model Class Initialized
INFO - 2018-02-18 18:06:08 --> Model Class Initialized
DEBUG - 2018-02-18 18:06:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 18:06:08 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 18:06:08 --> Final output sent to browser
DEBUG - 2018-02-18 18:06:08 --> Total execution time: 0.1244
INFO - 2018-02-18 18:06:09 --> Config Class Initialized
INFO - 2018-02-18 18:06:09 --> Hooks Class Initialized
DEBUG - 2018-02-18 18:06:09 --> UTF-8 Support Enabled
INFO - 2018-02-18 18:06:09 --> Utf8 Class Initialized
INFO - 2018-02-18 18:06:09 --> URI Class Initialized
INFO - 2018-02-18 18:06:09 --> Router Class Initialized
INFO - 2018-02-18 18:06:09 --> Output Class Initialized
INFO - 2018-02-18 18:06:09 --> Security Class Initialized
DEBUG - 2018-02-18 18:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 18:06:09 --> Input Class Initialized
INFO - 2018-02-18 18:06:09 --> Language Class Initialized
INFO - 2018-02-18 18:06:09 --> Loader Class Initialized
INFO - 2018-02-18 18:06:09 --> Helper loaded: url_helper
INFO - 2018-02-18 18:06:09 --> Helper loaded: form_helper
INFO - 2018-02-18 18:06:09 --> Database Driver Class Initialized
DEBUG - 2018-02-18 18:06:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 18:06:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 18:06:09 --> Form Validation Class Initialized
INFO - 2018-02-18 18:06:09 --> Model Class Initialized
INFO - 2018-02-18 18:06:09 --> Controller Class Initialized
INFO - 2018-02-18 18:06:09 --> Model Class Initialized
INFO - 2018-02-18 18:06:09 --> Model Class Initialized
INFO - 2018-02-18 18:06:09 --> Model Class Initialized
INFO - 2018-02-18 18:06:09 --> Model Class Initialized
INFO - 2018-02-18 18:06:09 --> Model Class Initialized
DEBUG - 2018-02-18 18:06:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 18:06:13 --> Config Class Initialized
INFO - 2018-02-18 18:06:13 --> Hooks Class Initialized
DEBUG - 2018-02-18 18:06:13 --> UTF-8 Support Enabled
INFO - 2018-02-18 18:06:13 --> Utf8 Class Initialized
INFO - 2018-02-18 18:06:13 --> URI Class Initialized
INFO - 2018-02-18 18:06:13 --> Router Class Initialized
INFO - 2018-02-18 18:06:13 --> Output Class Initialized
INFO - 2018-02-18 18:06:13 --> Security Class Initialized
DEBUG - 2018-02-18 18:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 18:06:13 --> Input Class Initialized
INFO - 2018-02-18 18:06:13 --> Language Class Initialized
INFO - 2018-02-18 18:06:13 --> Loader Class Initialized
INFO - 2018-02-18 18:06:13 --> Helper loaded: url_helper
INFO - 2018-02-18 18:06:13 --> Helper loaded: form_helper
INFO - 2018-02-18 18:06:13 --> Database Driver Class Initialized
DEBUG - 2018-02-18 18:06:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 18:06:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 18:06:13 --> Form Validation Class Initialized
INFO - 2018-02-18 18:06:13 --> Model Class Initialized
INFO - 2018-02-18 18:06:13 --> Controller Class Initialized
INFO - 2018-02-18 18:06:13 --> Model Class Initialized
INFO - 2018-02-18 18:06:13 --> Model Class Initialized
INFO - 2018-02-18 18:06:13 --> Model Class Initialized
INFO - 2018-02-18 18:06:13 --> Model Class Initialized
INFO - 2018-02-18 18:06:13 --> Model Class Initialized
DEBUG - 2018-02-18 18:06:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 18:06:13 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 18:06:13 --> Final output sent to browser
DEBUG - 2018-02-18 18:06:13 --> Total execution time: 0.0946
INFO - 2018-02-18 18:06:13 --> Config Class Initialized
INFO - 2018-02-18 18:06:13 --> Hooks Class Initialized
DEBUG - 2018-02-18 18:06:13 --> UTF-8 Support Enabled
INFO - 2018-02-18 18:06:13 --> Utf8 Class Initialized
INFO - 2018-02-18 18:06:13 --> URI Class Initialized
INFO - 2018-02-18 18:06:13 --> Router Class Initialized
INFO - 2018-02-18 18:06:13 --> Output Class Initialized
INFO - 2018-02-18 18:06:13 --> Security Class Initialized
DEBUG - 2018-02-18 18:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 18:06:13 --> Input Class Initialized
INFO - 2018-02-18 18:06:13 --> Language Class Initialized
INFO - 2018-02-18 18:06:13 --> Loader Class Initialized
INFO - 2018-02-18 18:06:13 --> Helper loaded: url_helper
INFO - 2018-02-18 18:06:13 --> Helper loaded: form_helper
INFO - 2018-02-18 18:06:13 --> Database Driver Class Initialized
DEBUG - 2018-02-18 18:06:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 18:06:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 18:06:13 --> Form Validation Class Initialized
INFO - 2018-02-18 18:06:13 --> Model Class Initialized
INFO - 2018-02-18 18:06:13 --> Controller Class Initialized
INFO - 2018-02-18 18:06:13 --> Model Class Initialized
INFO - 2018-02-18 18:06:13 --> Model Class Initialized
INFO - 2018-02-18 18:06:13 --> Model Class Initialized
INFO - 2018-02-18 18:06:13 --> Model Class Initialized
INFO - 2018-02-18 18:06:13 --> Model Class Initialized
DEBUG - 2018-02-18 18:06:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 18:06:18 --> Config Class Initialized
INFO - 2018-02-18 18:06:18 --> Hooks Class Initialized
DEBUG - 2018-02-18 18:06:18 --> UTF-8 Support Enabled
INFO - 2018-02-18 18:06:18 --> Utf8 Class Initialized
INFO - 2018-02-18 18:06:18 --> URI Class Initialized
INFO - 2018-02-18 18:06:18 --> Router Class Initialized
INFO - 2018-02-18 18:06:18 --> Output Class Initialized
INFO - 2018-02-18 18:06:18 --> Security Class Initialized
DEBUG - 2018-02-18 18:06:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 18:06:18 --> Input Class Initialized
INFO - 2018-02-18 18:06:18 --> Language Class Initialized
INFO - 2018-02-18 18:06:18 --> Loader Class Initialized
INFO - 2018-02-18 18:06:18 --> Helper loaded: url_helper
INFO - 2018-02-18 18:06:18 --> Helper loaded: form_helper
INFO - 2018-02-18 18:06:18 --> Database Driver Class Initialized
DEBUG - 2018-02-18 18:06:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 18:06:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 18:06:18 --> Form Validation Class Initialized
INFO - 2018-02-18 18:06:18 --> Model Class Initialized
INFO - 2018-02-18 18:06:18 --> Controller Class Initialized
INFO - 2018-02-18 18:06:18 --> Model Class Initialized
INFO - 2018-02-18 18:06:18 --> Model Class Initialized
INFO - 2018-02-18 18:06:18 --> Model Class Initialized
INFO - 2018-02-18 18:06:18 --> Model Class Initialized
INFO - 2018-02-18 18:06:18 --> Model Class Initialized
DEBUG - 2018-02-18 18:06:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 18:06:18 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 18:06:18 --> Final output sent to browser
DEBUG - 2018-02-18 18:06:18 --> Total execution time: 0.1016
INFO - 2018-02-18 18:06:18 --> Config Class Initialized
INFO - 2018-02-18 18:06:18 --> Hooks Class Initialized
DEBUG - 2018-02-18 18:06:18 --> UTF-8 Support Enabled
INFO - 2018-02-18 18:06:18 --> Utf8 Class Initialized
INFO - 2018-02-18 18:06:18 --> URI Class Initialized
INFO - 2018-02-18 18:06:18 --> Router Class Initialized
INFO - 2018-02-18 18:06:18 --> Output Class Initialized
INFO - 2018-02-18 18:06:18 --> Security Class Initialized
DEBUG - 2018-02-18 18:06:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 18:06:18 --> Input Class Initialized
INFO - 2018-02-18 18:06:18 --> Language Class Initialized
INFO - 2018-02-18 18:06:18 --> Loader Class Initialized
INFO - 2018-02-18 18:06:18 --> Helper loaded: url_helper
INFO - 2018-02-18 18:06:18 --> Helper loaded: form_helper
INFO - 2018-02-18 18:06:18 --> Database Driver Class Initialized
DEBUG - 2018-02-18 18:06:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 18:06:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 18:06:18 --> Form Validation Class Initialized
INFO - 2018-02-18 18:06:18 --> Model Class Initialized
INFO - 2018-02-18 18:06:18 --> Controller Class Initialized
INFO - 2018-02-18 18:06:18 --> Model Class Initialized
INFO - 2018-02-18 18:06:18 --> Model Class Initialized
INFO - 2018-02-18 18:06:18 --> Model Class Initialized
INFO - 2018-02-18 18:06:18 --> Model Class Initialized
INFO - 2018-02-18 18:06:18 --> Model Class Initialized
DEBUG - 2018-02-18 18:06:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 18:06:24 --> Config Class Initialized
INFO - 2018-02-18 18:06:24 --> Hooks Class Initialized
DEBUG - 2018-02-18 18:06:24 --> UTF-8 Support Enabled
INFO - 2018-02-18 18:06:24 --> Utf8 Class Initialized
INFO - 2018-02-18 18:06:24 --> URI Class Initialized
INFO - 2018-02-18 18:06:24 --> Router Class Initialized
INFO - 2018-02-18 18:06:24 --> Output Class Initialized
INFO - 2018-02-18 18:06:24 --> Security Class Initialized
DEBUG - 2018-02-18 18:06:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 18:06:24 --> Input Class Initialized
INFO - 2018-02-18 18:06:24 --> Language Class Initialized
INFO - 2018-02-18 18:06:24 --> Loader Class Initialized
INFO - 2018-02-18 18:06:24 --> Helper loaded: url_helper
INFO - 2018-02-18 18:06:24 --> Helper loaded: form_helper
INFO - 2018-02-18 18:06:24 --> Database Driver Class Initialized
DEBUG - 2018-02-18 18:06:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 18:06:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 18:06:24 --> Form Validation Class Initialized
INFO - 2018-02-18 18:06:24 --> Model Class Initialized
INFO - 2018-02-18 18:06:24 --> Controller Class Initialized
INFO - 2018-02-18 18:06:24 --> Model Class Initialized
INFO - 2018-02-18 18:06:24 --> Model Class Initialized
INFO - 2018-02-18 18:06:24 --> Model Class Initialized
INFO - 2018-02-18 18:06:24 --> Model Class Initialized
INFO - 2018-02-18 18:06:24 --> Model Class Initialized
DEBUG - 2018-02-18 18:06:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 18:06:30 --> Config Class Initialized
INFO - 2018-02-18 18:06:30 --> Hooks Class Initialized
DEBUG - 2018-02-18 18:06:30 --> UTF-8 Support Enabled
INFO - 2018-02-18 18:06:30 --> Utf8 Class Initialized
INFO - 2018-02-18 18:06:30 --> URI Class Initialized
INFO - 2018-02-18 18:06:30 --> Router Class Initialized
INFO - 2018-02-18 18:06:30 --> Output Class Initialized
INFO - 2018-02-18 18:06:30 --> Security Class Initialized
DEBUG - 2018-02-18 18:06:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 18:06:30 --> Input Class Initialized
INFO - 2018-02-18 18:06:30 --> Language Class Initialized
INFO - 2018-02-18 18:06:30 --> Loader Class Initialized
INFO - 2018-02-18 18:06:30 --> Helper loaded: url_helper
INFO - 2018-02-18 18:06:30 --> Helper loaded: form_helper
INFO - 2018-02-18 18:06:30 --> Database Driver Class Initialized
DEBUG - 2018-02-18 18:06:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 18:06:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 18:06:30 --> Form Validation Class Initialized
INFO - 2018-02-18 18:06:30 --> Model Class Initialized
INFO - 2018-02-18 18:06:30 --> Controller Class Initialized
INFO - 2018-02-18 18:06:30 --> Model Class Initialized
INFO - 2018-02-18 18:06:30 --> Model Class Initialized
INFO - 2018-02-18 18:06:30 --> Model Class Initialized
INFO - 2018-02-18 18:06:30 --> Model Class Initialized
INFO - 2018-02-18 18:06:30 --> Model Class Initialized
DEBUG - 2018-02-18 18:06:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 18:06:35 --> Config Class Initialized
INFO - 2018-02-18 18:06:35 --> Hooks Class Initialized
DEBUG - 2018-02-18 18:06:35 --> UTF-8 Support Enabled
INFO - 2018-02-18 18:06:35 --> Utf8 Class Initialized
INFO - 2018-02-18 18:06:35 --> URI Class Initialized
INFO - 2018-02-18 18:06:35 --> Router Class Initialized
INFO - 2018-02-18 18:06:35 --> Output Class Initialized
INFO - 2018-02-18 18:06:35 --> Security Class Initialized
DEBUG - 2018-02-18 18:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 18:06:35 --> Input Class Initialized
INFO - 2018-02-18 18:06:35 --> Language Class Initialized
INFO - 2018-02-18 18:06:35 --> Loader Class Initialized
INFO - 2018-02-18 18:06:35 --> Helper loaded: url_helper
INFO - 2018-02-18 18:06:35 --> Helper loaded: form_helper
INFO - 2018-02-18 18:06:35 --> Database Driver Class Initialized
DEBUG - 2018-02-18 18:06:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 18:06:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 18:06:35 --> Form Validation Class Initialized
INFO - 2018-02-18 18:06:35 --> Model Class Initialized
INFO - 2018-02-18 18:06:35 --> Controller Class Initialized
INFO - 2018-02-18 18:06:35 --> Model Class Initialized
INFO - 2018-02-18 18:06:35 --> Model Class Initialized
INFO - 2018-02-18 18:06:35 --> Model Class Initialized
INFO - 2018-02-18 18:06:35 --> Model Class Initialized
INFO - 2018-02-18 18:06:35 --> Model Class Initialized
DEBUG - 2018-02-18 18:06:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 18:06:40 --> Config Class Initialized
INFO - 2018-02-18 18:06:40 --> Hooks Class Initialized
DEBUG - 2018-02-18 18:06:40 --> UTF-8 Support Enabled
INFO - 2018-02-18 18:06:40 --> Utf8 Class Initialized
INFO - 2018-02-18 18:06:40 --> URI Class Initialized
INFO - 2018-02-18 18:06:40 --> Router Class Initialized
INFO - 2018-02-18 18:06:40 --> Output Class Initialized
INFO - 2018-02-18 18:06:40 --> Security Class Initialized
DEBUG - 2018-02-18 18:06:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 18:06:40 --> Input Class Initialized
INFO - 2018-02-18 18:06:40 --> Language Class Initialized
INFO - 2018-02-18 18:06:40 --> Loader Class Initialized
INFO - 2018-02-18 18:06:40 --> Helper loaded: url_helper
INFO - 2018-02-18 18:06:40 --> Helper loaded: form_helper
INFO - 2018-02-18 18:06:40 --> Database Driver Class Initialized
DEBUG - 2018-02-18 18:06:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 18:06:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 18:06:40 --> Form Validation Class Initialized
INFO - 2018-02-18 18:06:40 --> Model Class Initialized
INFO - 2018-02-18 18:06:40 --> Controller Class Initialized
INFO - 2018-02-18 18:06:40 --> Model Class Initialized
INFO - 2018-02-18 18:06:40 --> Model Class Initialized
INFO - 2018-02-18 18:06:40 --> Model Class Initialized
INFO - 2018-02-18 18:06:40 --> Model Class Initialized
INFO - 2018-02-18 18:06:40 --> Model Class Initialized
DEBUG - 2018-02-18 18:06:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 18:06:43 --> Config Class Initialized
INFO - 2018-02-18 18:06:43 --> Hooks Class Initialized
DEBUG - 2018-02-18 18:06:43 --> UTF-8 Support Enabled
INFO - 2018-02-18 18:06:43 --> Utf8 Class Initialized
INFO - 2018-02-18 18:06:43 --> URI Class Initialized
INFO - 2018-02-18 18:06:43 --> Router Class Initialized
INFO - 2018-02-18 18:06:43 --> Output Class Initialized
INFO - 2018-02-18 18:06:43 --> Security Class Initialized
DEBUG - 2018-02-18 18:06:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 18:06:43 --> Input Class Initialized
INFO - 2018-02-18 18:06:43 --> Language Class Initialized
INFO - 2018-02-18 18:06:43 --> Loader Class Initialized
INFO - 2018-02-18 18:06:43 --> Helper loaded: url_helper
INFO - 2018-02-18 18:06:43 --> Helper loaded: form_helper
INFO - 2018-02-18 18:06:43 --> Database Driver Class Initialized
DEBUG - 2018-02-18 18:06:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 18:06:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 18:06:43 --> Form Validation Class Initialized
INFO - 2018-02-18 18:06:43 --> Model Class Initialized
INFO - 2018-02-18 18:06:43 --> Controller Class Initialized
INFO - 2018-02-18 18:06:43 --> Model Class Initialized
INFO - 2018-02-18 18:06:43 --> Model Class Initialized
INFO - 2018-02-18 18:06:43 --> Model Class Initialized
INFO - 2018-02-18 18:06:43 --> Model Class Initialized
INFO - 2018-02-18 18:06:43 --> Model Class Initialized
DEBUG - 2018-02-18 18:06:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 18:15:58 --> Config Class Initialized
INFO - 2018-02-18 18:15:58 --> Hooks Class Initialized
DEBUG - 2018-02-18 18:15:58 --> UTF-8 Support Enabled
INFO - 2018-02-18 18:15:58 --> Utf8 Class Initialized
INFO - 2018-02-18 18:15:58 --> URI Class Initialized
INFO - 2018-02-18 18:15:58 --> Router Class Initialized
INFO - 2018-02-18 18:15:58 --> Output Class Initialized
INFO - 2018-02-18 18:15:58 --> Security Class Initialized
DEBUG - 2018-02-18 18:15:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 18:15:58 --> Input Class Initialized
INFO - 2018-02-18 18:15:58 --> Language Class Initialized
INFO - 2018-02-18 18:15:58 --> Loader Class Initialized
INFO - 2018-02-18 18:15:58 --> Helper loaded: url_helper
INFO - 2018-02-18 18:15:58 --> Helper loaded: form_helper
INFO - 2018-02-18 18:15:58 --> Database Driver Class Initialized
DEBUG - 2018-02-18 18:15:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 18:15:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 18:15:58 --> Form Validation Class Initialized
INFO - 2018-02-18 18:15:58 --> Model Class Initialized
INFO - 2018-02-18 18:15:58 --> Controller Class Initialized
INFO - 2018-02-18 18:15:58 --> Model Class Initialized
INFO - 2018-02-18 18:15:58 --> Model Class Initialized
INFO - 2018-02-18 18:15:58 --> Model Class Initialized
INFO - 2018-02-18 18:15:58 --> Model Class Initialized
INFO - 2018-02-18 18:15:58 --> Model Class Initialized
DEBUG - 2018-02-18 18:15:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 18:15:58 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 18:15:58 --> Final output sent to browser
DEBUG - 2018-02-18 18:15:58 --> Total execution time: 0.1049
INFO - 2018-02-18 18:15:59 --> Config Class Initialized
INFO - 2018-02-18 18:15:59 --> Hooks Class Initialized
DEBUG - 2018-02-18 18:15:59 --> UTF-8 Support Enabled
INFO - 2018-02-18 18:15:59 --> Utf8 Class Initialized
INFO - 2018-02-18 18:15:59 --> URI Class Initialized
INFO - 2018-02-18 18:15:59 --> Router Class Initialized
INFO - 2018-02-18 18:15:59 --> Output Class Initialized
INFO - 2018-02-18 18:15:59 --> Security Class Initialized
DEBUG - 2018-02-18 18:15:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 18:15:59 --> Input Class Initialized
INFO - 2018-02-18 18:15:59 --> Language Class Initialized
INFO - 2018-02-18 18:15:59 --> Loader Class Initialized
INFO - 2018-02-18 18:15:59 --> Helper loaded: url_helper
INFO - 2018-02-18 18:15:59 --> Helper loaded: form_helper
INFO - 2018-02-18 18:15:59 --> Database Driver Class Initialized
DEBUG - 2018-02-18 18:15:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 18:15:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 18:15:59 --> Form Validation Class Initialized
INFO - 2018-02-18 18:15:59 --> Model Class Initialized
INFO - 2018-02-18 18:15:59 --> Controller Class Initialized
INFO - 2018-02-18 18:15:59 --> Model Class Initialized
INFO - 2018-02-18 18:15:59 --> Model Class Initialized
INFO - 2018-02-18 18:15:59 --> Model Class Initialized
INFO - 2018-02-18 18:15:59 --> Model Class Initialized
INFO - 2018-02-18 18:15:59 --> Model Class Initialized
DEBUG - 2018-02-18 18:15:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 18:16:03 --> Config Class Initialized
INFO - 2018-02-18 18:16:03 --> Hooks Class Initialized
DEBUG - 2018-02-18 18:16:03 --> UTF-8 Support Enabled
INFO - 2018-02-18 18:16:03 --> Utf8 Class Initialized
INFO - 2018-02-18 18:16:03 --> URI Class Initialized
INFO - 2018-02-18 18:16:03 --> Router Class Initialized
INFO - 2018-02-18 18:16:03 --> Output Class Initialized
INFO - 2018-02-18 18:16:03 --> Security Class Initialized
DEBUG - 2018-02-18 18:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 18:16:03 --> Input Class Initialized
INFO - 2018-02-18 18:16:03 --> Language Class Initialized
INFO - 2018-02-18 18:16:03 --> Loader Class Initialized
INFO - 2018-02-18 18:16:03 --> Helper loaded: url_helper
INFO - 2018-02-18 18:16:03 --> Helper loaded: form_helper
INFO - 2018-02-18 18:16:03 --> Database Driver Class Initialized
DEBUG - 2018-02-18 18:16:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 18:16:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 18:16:03 --> Form Validation Class Initialized
INFO - 2018-02-18 18:16:03 --> Model Class Initialized
INFO - 2018-02-18 18:16:03 --> Controller Class Initialized
INFO - 2018-02-18 18:16:03 --> Model Class Initialized
INFO - 2018-02-18 18:16:03 --> Model Class Initialized
INFO - 2018-02-18 18:16:03 --> Model Class Initialized
INFO - 2018-02-18 18:16:03 --> Model Class Initialized
INFO - 2018-02-18 18:16:03 --> Model Class Initialized
DEBUG - 2018-02-18 18:16:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 18:16:08 --> Config Class Initialized
INFO - 2018-02-18 18:16:08 --> Hooks Class Initialized
DEBUG - 2018-02-18 18:16:08 --> UTF-8 Support Enabled
INFO - 2018-02-18 18:16:08 --> Utf8 Class Initialized
INFO - 2018-02-18 18:16:08 --> URI Class Initialized
INFO - 2018-02-18 18:16:08 --> Router Class Initialized
INFO - 2018-02-18 18:16:08 --> Output Class Initialized
INFO - 2018-02-18 18:16:08 --> Security Class Initialized
DEBUG - 2018-02-18 18:16:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 18:16:08 --> Input Class Initialized
INFO - 2018-02-18 18:16:08 --> Language Class Initialized
INFO - 2018-02-18 18:16:08 --> Loader Class Initialized
INFO - 2018-02-18 18:16:08 --> Helper loaded: url_helper
INFO - 2018-02-18 18:16:08 --> Helper loaded: form_helper
INFO - 2018-02-18 18:16:08 --> Database Driver Class Initialized
DEBUG - 2018-02-18 18:16:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 18:16:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 18:16:08 --> Form Validation Class Initialized
INFO - 2018-02-18 18:16:08 --> Model Class Initialized
INFO - 2018-02-18 18:16:08 --> Controller Class Initialized
INFO - 2018-02-18 18:16:08 --> Model Class Initialized
INFO - 2018-02-18 18:16:08 --> Model Class Initialized
INFO - 2018-02-18 18:16:08 --> Model Class Initialized
INFO - 2018-02-18 18:16:08 --> Model Class Initialized
INFO - 2018-02-18 18:16:08 --> Model Class Initialized
DEBUG - 2018-02-18 18:16:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 18:16:11 --> Config Class Initialized
INFO - 2018-02-18 18:16:11 --> Hooks Class Initialized
DEBUG - 2018-02-18 18:16:11 --> UTF-8 Support Enabled
INFO - 2018-02-18 18:16:11 --> Utf8 Class Initialized
INFO - 2018-02-18 18:16:11 --> URI Class Initialized
INFO - 2018-02-18 18:16:11 --> Router Class Initialized
INFO - 2018-02-18 18:16:11 --> Output Class Initialized
INFO - 2018-02-18 18:16:11 --> Security Class Initialized
DEBUG - 2018-02-18 18:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 18:16:11 --> Input Class Initialized
INFO - 2018-02-18 18:16:11 --> Language Class Initialized
INFO - 2018-02-18 18:16:11 --> Loader Class Initialized
INFO - 2018-02-18 18:16:11 --> Helper loaded: url_helper
INFO - 2018-02-18 18:16:11 --> Helper loaded: form_helper
INFO - 2018-02-18 18:16:11 --> Database Driver Class Initialized
DEBUG - 2018-02-18 18:16:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 18:16:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 18:16:11 --> Form Validation Class Initialized
INFO - 2018-02-18 18:16:11 --> Model Class Initialized
INFO - 2018-02-18 18:16:11 --> Controller Class Initialized
INFO - 2018-02-18 18:16:11 --> Model Class Initialized
INFO - 2018-02-18 18:16:11 --> Model Class Initialized
INFO - 2018-02-18 18:16:11 --> Model Class Initialized
INFO - 2018-02-18 18:16:11 --> Model Class Initialized
INFO - 2018-02-18 18:16:11 --> Model Class Initialized
DEBUG - 2018-02-18 18:16:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 18:17:05 --> Config Class Initialized
INFO - 2018-02-18 18:17:05 --> Hooks Class Initialized
DEBUG - 2018-02-18 18:17:05 --> UTF-8 Support Enabled
INFO - 2018-02-18 18:17:05 --> Utf8 Class Initialized
INFO - 2018-02-18 18:17:05 --> URI Class Initialized
INFO - 2018-02-18 18:17:05 --> Router Class Initialized
INFO - 2018-02-18 18:17:05 --> Output Class Initialized
INFO - 2018-02-18 18:17:05 --> Security Class Initialized
DEBUG - 2018-02-18 18:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 18:17:05 --> Input Class Initialized
INFO - 2018-02-18 18:17:05 --> Language Class Initialized
INFO - 2018-02-18 18:17:05 --> Loader Class Initialized
INFO - 2018-02-18 18:17:05 --> Helper loaded: url_helper
INFO - 2018-02-18 18:17:05 --> Helper loaded: form_helper
INFO - 2018-02-18 18:17:05 --> Database Driver Class Initialized
DEBUG - 2018-02-18 18:17:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 18:17:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 18:17:05 --> Form Validation Class Initialized
INFO - 2018-02-18 18:17:05 --> Model Class Initialized
INFO - 2018-02-18 18:17:05 --> Controller Class Initialized
INFO - 2018-02-18 18:17:05 --> Model Class Initialized
INFO - 2018-02-18 18:17:05 --> Model Class Initialized
INFO - 2018-02-18 18:17:05 --> Model Class Initialized
INFO - 2018-02-18 18:17:05 --> Model Class Initialized
INFO - 2018-02-18 18:17:05 --> Model Class Initialized
DEBUG - 2018-02-18 18:17:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 18:17:05 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 18:17:05 --> Final output sent to browser
DEBUG - 2018-02-18 18:17:05 --> Total execution time: 0.0967
INFO - 2018-02-18 18:17:05 --> Config Class Initialized
INFO - 2018-02-18 18:17:05 --> Hooks Class Initialized
DEBUG - 2018-02-18 18:17:05 --> UTF-8 Support Enabled
INFO - 2018-02-18 18:17:05 --> Utf8 Class Initialized
INFO - 2018-02-18 18:17:05 --> URI Class Initialized
INFO - 2018-02-18 18:17:05 --> Router Class Initialized
INFO - 2018-02-18 18:17:05 --> Output Class Initialized
INFO - 2018-02-18 18:17:05 --> Security Class Initialized
DEBUG - 2018-02-18 18:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 18:17:05 --> Input Class Initialized
INFO - 2018-02-18 18:17:05 --> Language Class Initialized
INFO - 2018-02-18 18:17:05 --> Loader Class Initialized
INFO - 2018-02-18 18:17:05 --> Helper loaded: url_helper
INFO - 2018-02-18 18:17:05 --> Helper loaded: form_helper
INFO - 2018-02-18 18:17:05 --> Database Driver Class Initialized
DEBUG - 2018-02-18 18:17:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 18:17:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 18:17:05 --> Form Validation Class Initialized
INFO - 2018-02-18 18:17:05 --> Model Class Initialized
INFO - 2018-02-18 18:17:05 --> Controller Class Initialized
INFO - 2018-02-18 18:17:05 --> Model Class Initialized
INFO - 2018-02-18 18:17:05 --> Model Class Initialized
INFO - 2018-02-18 18:17:05 --> Model Class Initialized
INFO - 2018-02-18 18:17:05 --> Model Class Initialized
INFO - 2018-02-18 18:17:05 --> Model Class Initialized
DEBUG - 2018-02-18 18:17:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 18:17:13 --> Config Class Initialized
INFO - 2018-02-18 18:17:13 --> Hooks Class Initialized
DEBUG - 2018-02-18 18:17:13 --> UTF-8 Support Enabled
INFO - 2018-02-18 18:17:13 --> Utf8 Class Initialized
INFO - 2018-02-18 18:17:13 --> URI Class Initialized
INFO - 2018-02-18 18:17:13 --> Router Class Initialized
INFO - 2018-02-18 18:17:13 --> Output Class Initialized
INFO - 2018-02-18 18:17:13 --> Security Class Initialized
DEBUG - 2018-02-18 18:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 18:17:13 --> Input Class Initialized
INFO - 2018-02-18 18:17:13 --> Language Class Initialized
INFO - 2018-02-18 18:17:13 --> Loader Class Initialized
INFO - 2018-02-18 18:17:13 --> Helper loaded: url_helper
INFO - 2018-02-18 18:17:13 --> Helper loaded: form_helper
INFO - 2018-02-18 18:17:13 --> Database Driver Class Initialized
DEBUG - 2018-02-18 18:17:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 18:17:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 18:17:13 --> Form Validation Class Initialized
INFO - 2018-02-18 18:17:13 --> Model Class Initialized
INFO - 2018-02-18 18:17:13 --> Controller Class Initialized
INFO - 2018-02-18 18:17:13 --> Model Class Initialized
INFO - 2018-02-18 18:17:13 --> Model Class Initialized
INFO - 2018-02-18 18:17:13 --> Model Class Initialized
INFO - 2018-02-18 18:17:13 --> Model Class Initialized
INFO - 2018-02-18 18:17:13 --> Model Class Initialized
DEBUG - 2018-02-18 18:17:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 18:17:13 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 18:17:13 --> Final output sent to browser
DEBUG - 2018-02-18 18:17:13 --> Total execution time: 0.0849
INFO - 2018-02-18 18:17:13 --> Config Class Initialized
INFO - 2018-02-18 18:17:13 --> Hooks Class Initialized
DEBUG - 2018-02-18 18:17:13 --> UTF-8 Support Enabled
INFO - 2018-02-18 18:17:13 --> Utf8 Class Initialized
INFO - 2018-02-18 18:17:13 --> URI Class Initialized
INFO - 2018-02-18 18:17:13 --> Router Class Initialized
INFO - 2018-02-18 18:17:13 --> Output Class Initialized
INFO - 2018-02-18 18:17:13 --> Security Class Initialized
DEBUG - 2018-02-18 18:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 18:17:13 --> Input Class Initialized
INFO - 2018-02-18 18:17:13 --> Language Class Initialized
INFO - 2018-02-18 18:17:13 --> Loader Class Initialized
INFO - 2018-02-18 18:17:13 --> Helper loaded: url_helper
INFO - 2018-02-18 18:17:13 --> Helper loaded: form_helper
INFO - 2018-02-18 18:17:13 --> Database Driver Class Initialized
DEBUG - 2018-02-18 18:17:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 18:17:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 18:17:13 --> Form Validation Class Initialized
INFO - 2018-02-18 18:17:13 --> Model Class Initialized
INFO - 2018-02-18 18:17:13 --> Controller Class Initialized
INFO - 2018-02-18 18:17:13 --> Model Class Initialized
INFO - 2018-02-18 18:17:13 --> Model Class Initialized
INFO - 2018-02-18 18:17:13 --> Model Class Initialized
INFO - 2018-02-18 18:17:13 --> Model Class Initialized
INFO - 2018-02-18 18:17:13 --> Model Class Initialized
DEBUG - 2018-02-18 18:17:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 18:41:11 --> Config Class Initialized
INFO - 2018-02-18 18:41:11 --> Hooks Class Initialized
DEBUG - 2018-02-18 18:41:11 --> UTF-8 Support Enabled
INFO - 2018-02-18 18:41:11 --> Utf8 Class Initialized
INFO - 2018-02-18 18:41:11 --> URI Class Initialized
INFO - 2018-02-18 18:41:11 --> Router Class Initialized
INFO - 2018-02-18 18:41:11 --> Output Class Initialized
INFO - 2018-02-18 18:41:11 --> Security Class Initialized
DEBUG - 2018-02-18 18:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 18:41:11 --> Input Class Initialized
INFO - 2018-02-18 18:41:11 --> Language Class Initialized
INFO - 2018-02-18 18:41:11 --> Loader Class Initialized
INFO - 2018-02-18 18:41:11 --> Helper loaded: url_helper
INFO - 2018-02-18 18:41:11 --> Helper loaded: form_helper
INFO - 2018-02-18 18:41:11 --> Database Driver Class Initialized
DEBUG - 2018-02-18 18:41:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 18:41:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 18:41:11 --> Form Validation Class Initialized
INFO - 2018-02-18 18:41:11 --> Model Class Initialized
INFO - 2018-02-18 18:41:11 --> Controller Class Initialized
INFO - 2018-02-18 18:41:11 --> Model Class Initialized
INFO - 2018-02-18 18:41:11 --> Model Class Initialized
INFO - 2018-02-18 18:41:11 --> Model Class Initialized
INFO - 2018-02-18 18:41:11 --> Model Class Initialized
INFO - 2018-02-18 18:41:11 --> Model Class Initialized
DEBUG - 2018-02-18 18:41:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 18:41:11 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 18:41:11 --> Final output sent to browser
DEBUG - 2018-02-18 18:41:11 --> Total execution time: 0.5539
INFO - 2018-02-18 18:41:12 --> Config Class Initialized
INFO - 2018-02-18 18:41:12 --> Hooks Class Initialized
DEBUG - 2018-02-18 18:41:12 --> UTF-8 Support Enabled
INFO - 2018-02-18 18:41:12 --> Utf8 Class Initialized
INFO - 2018-02-18 18:41:12 --> URI Class Initialized
INFO - 2018-02-18 18:41:12 --> Router Class Initialized
INFO - 2018-02-18 18:41:12 --> Output Class Initialized
INFO - 2018-02-18 18:41:12 --> Security Class Initialized
DEBUG - 2018-02-18 18:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 18:41:12 --> Input Class Initialized
INFO - 2018-02-18 18:41:12 --> Language Class Initialized
INFO - 2018-02-18 18:41:12 --> Loader Class Initialized
INFO - 2018-02-18 18:41:12 --> Helper loaded: url_helper
INFO - 2018-02-18 18:41:12 --> Helper loaded: form_helper
INFO - 2018-02-18 18:41:12 --> Database Driver Class Initialized
DEBUG - 2018-02-18 18:41:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 18:41:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 18:41:12 --> Form Validation Class Initialized
INFO - 2018-02-18 18:41:12 --> Model Class Initialized
INFO - 2018-02-18 18:41:12 --> Controller Class Initialized
INFO - 2018-02-18 18:41:12 --> Model Class Initialized
INFO - 2018-02-18 18:41:12 --> Model Class Initialized
INFO - 2018-02-18 18:41:12 --> Model Class Initialized
INFO - 2018-02-18 18:41:12 --> Model Class Initialized
INFO - 2018-02-18 18:41:12 --> Model Class Initialized
DEBUG - 2018-02-18 18:41:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 18:41:17 --> Config Class Initialized
INFO - 2018-02-18 18:41:17 --> Hooks Class Initialized
DEBUG - 2018-02-18 18:41:17 --> UTF-8 Support Enabled
INFO - 2018-02-18 18:41:17 --> Utf8 Class Initialized
INFO - 2018-02-18 18:41:17 --> URI Class Initialized
INFO - 2018-02-18 18:41:17 --> Router Class Initialized
INFO - 2018-02-18 18:41:17 --> Output Class Initialized
INFO - 2018-02-18 18:41:17 --> Security Class Initialized
DEBUG - 2018-02-18 18:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 18:41:17 --> Input Class Initialized
INFO - 2018-02-18 18:41:17 --> Language Class Initialized
INFO - 2018-02-18 18:41:17 --> Loader Class Initialized
INFO - 2018-02-18 18:41:17 --> Helper loaded: url_helper
INFO - 2018-02-18 18:41:17 --> Helper loaded: form_helper
INFO - 2018-02-18 18:41:17 --> Database Driver Class Initialized
DEBUG - 2018-02-18 18:41:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 18:41:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 18:41:17 --> Form Validation Class Initialized
INFO - 2018-02-18 18:41:17 --> Model Class Initialized
INFO - 2018-02-18 18:41:17 --> Controller Class Initialized
INFO - 2018-02-18 18:41:17 --> Model Class Initialized
INFO - 2018-02-18 18:41:17 --> Model Class Initialized
INFO - 2018-02-18 18:41:17 --> Model Class Initialized
INFO - 2018-02-18 18:41:17 --> Model Class Initialized
INFO - 2018-02-18 18:41:17 --> Model Class Initialized
DEBUG - 2018-02-18 18:41:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 18:41:21 --> Config Class Initialized
INFO - 2018-02-18 18:41:21 --> Hooks Class Initialized
DEBUG - 2018-02-18 18:41:21 --> UTF-8 Support Enabled
INFO - 2018-02-18 18:41:21 --> Utf8 Class Initialized
INFO - 2018-02-18 18:41:21 --> URI Class Initialized
INFO - 2018-02-18 18:41:21 --> Router Class Initialized
INFO - 2018-02-18 18:41:21 --> Output Class Initialized
INFO - 2018-02-18 18:41:21 --> Security Class Initialized
DEBUG - 2018-02-18 18:41:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 18:41:21 --> Input Class Initialized
INFO - 2018-02-18 18:41:21 --> Language Class Initialized
INFO - 2018-02-18 18:41:21 --> Loader Class Initialized
INFO - 2018-02-18 18:41:21 --> Helper loaded: url_helper
INFO - 2018-02-18 18:41:21 --> Helper loaded: form_helper
INFO - 2018-02-18 18:41:21 --> Database Driver Class Initialized
DEBUG - 2018-02-18 18:41:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 18:41:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 18:41:21 --> Form Validation Class Initialized
INFO - 2018-02-18 18:41:21 --> Model Class Initialized
INFO - 2018-02-18 18:41:21 --> Controller Class Initialized
INFO - 2018-02-18 18:41:21 --> Model Class Initialized
INFO - 2018-02-18 18:41:21 --> Model Class Initialized
INFO - 2018-02-18 18:41:21 --> Model Class Initialized
INFO - 2018-02-18 18:41:21 --> Model Class Initialized
INFO - 2018-02-18 18:41:21 --> Model Class Initialized
DEBUG - 2018-02-18 18:41:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 18:41:27 --> Config Class Initialized
INFO - 2018-02-18 18:41:27 --> Hooks Class Initialized
DEBUG - 2018-02-18 18:41:27 --> UTF-8 Support Enabled
INFO - 2018-02-18 18:41:27 --> Utf8 Class Initialized
INFO - 2018-02-18 18:41:27 --> URI Class Initialized
INFO - 2018-02-18 18:41:27 --> Router Class Initialized
INFO - 2018-02-18 18:41:27 --> Output Class Initialized
INFO - 2018-02-18 18:41:27 --> Security Class Initialized
DEBUG - 2018-02-18 18:41:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 18:41:27 --> Input Class Initialized
INFO - 2018-02-18 18:41:27 --> Language Class Initialized
INFO - 2018-02-18 18:41:27 --> Loader Class Initialized
INFO - 2018-02-18 18:41:27 --> Helper loaded: url_helper
INFO - 2018-02-18 18:41:27 --> Helper loaded: form_helper
INFO - 2018-02-18 18:41:27 --> Database Driver Class Initialized
DEBUG - 2018-02-18 18:41:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 18:41:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 18:41:27 --> Form Validation Class Initialized
INFO - 2018-02-18 18:41:27 --> Model Class Initialized
INFO - 2018-02-18 18:41:27 --> Controller Class Initialized
INFO - 2018-02-18 18:41:27 --> Model Class Initialized
INFO - 2018-02-18 18:41:27 --> Model Class Initialized
INFO - 2018-02-18 18:41:27 --> Model Class Initialized
INFO - 2018-02-18 18:41:27 --> Model Class Initialized
INFO - 2018-02-18 18:41:27 --> Model Class Initialized
DEBUG - 2018-02-18 18:41:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 18:41:35 --> Config Class Initialized
INFO - 2018-02-18 18:41:35 --> Hooks Class Initialized
DEBUG - 2018-02-18 18:41:35 --> UTF-8 Support Enabled
INFO - 2018-02-18 18:41:35 --> Utf8 Class Initialized
INFO - 2018-02-18 18:41:35 --> URI Class Initialized
INFO - 2018-02-18 18:41:35 --> Router Class Initialized
INFO - 2018-02-18 18:41:35 --> Output Class Initialized
INFO - 2018-02-18 18:41:35 --> Security Class Initialized
DEBUG - 2018-02-18 18:41:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 18:41:35 --> Input Class Initialized
INFO - 2018-02-18 18:41:35 --> Language Class Initialized
INFO - 2018-02-18 18:41:35 --> Loader Class Initialized
INFO - 2018-02-18 18:41:35 --> Helper loaded: url_helper
INFO - 2018-02-18 18:41:35 --> Helper loaded: form_helper
INFO - 2018-02-18 18:41:35 --> Database Driver Class Initialized
DEBUG - 2018-02-18 18:41:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 18:41:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 18:41:35 --> Form Validation Class Initialized
INFO - 2018-02-18 18:41:35 --> Model Class Initialized
INFO - 2018-02-18 18:41:35 --> Controller Class Initialized
INFO - 2018-02-18 18:41:35 --> Model Class Initialized
INFO - 2018-02-18 18:41:35 --> Model Class Initialized
INFO - 2018-02-18 18:41:35 --> Model Class Initialized
INFO - 2018-02-18 18:41:35 --> Model Class Initialized
INFO - 2018-02-18 18:41:35 --> Model Class Initialized
DEBUG - 2018-02-18 18:41:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 18:41:40 --> Config Class Initialized
INFO - 2018-02-18 18:41:40 --> Hooks Class Initialized
DEBUG - 2018-02-18 18:41:40 --> UTF-8 Support Enabled
INFO - 2018-02-18 18:41:40 --> Utf8 Class Initialized
INFO - 2018-02-18 18:41:40 --> URI Class Initialized
INFO - 2018-02-18 18:41:40 --> Router Class Initialized
INFO - 2018-02-18 18:41:40 --> Output Class Initialized
INFO - 2018-02-18 18:41:40 --> Security Class Initialized
DEBUG - 2018-02-18 18:41:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 18:41:40 --> Input Class Initialized
INFO - 2018-02-18 18:41:40 --> Language Class Initialized
INFO - 2018-02-18 18:41:40 --> Loader Class Initialized
INFO - 2018-02-18 18:41:40 --> Helper loaded: url_helper
INFO - 2018-02-18 18:41:40 --> Helper loaded: form_helper
INFO - 2018-02-18 18:41:40 --> Database Driver Class Initialized
DEBUG - 2018-02-18 18:41:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 18:41:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 18:41:40 --> Form Validation Class Initialized
INFO - 2018-02-18 18:41:40 --> Model Class Initialized
INFO - 2018-02-18 18:41:40 --> Controller Class Initialized
INFO - 2018-02-18 18:41:40 --> Model Class Initialized
INFO - 2018-02-18 18:41:40 --> Model Class Initialized
INFO - 2018-02-18 18:41:40 --> Model Class Initialized
INFO - 2018-02-18 18:41:40 --> Model Class Initialized
INFO - 2018-02-18 18:41:40 --> Model Class Initialized
DEBUG - 2018-02-18 18:41:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 18:41:40 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 18:41:40 --> Final output sent to browser
DEBUG - 2018-02-18 18:41:40 --> Total execution time: 0.5220
INFO - 2018-02-18 18:41:41 --> Config Class Initialized
INFO - 2018-02-18 18:41:41 --> Hooks Class Initialized
DEBUG - 2018-02-18 18:41:41 --> UTF-8 Support Enabled
INFO - 2018-02-18 18:41:41 --> Utf8 Class Initialized
INFO - 2018-02-18 18:41:41 --> URI Class Initialized
INFO - 2018-02-18 18:41:41 --> Router Class Initialized
INFO - 2018-02-18 18:41:41 --> Output Class Initialized
INFO - 2018-02-18 18:41:41 --> Security Class Initialized
DEBUG - 2018-02-18 18:41:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 18:41:41 --> Input Class Initialized
INFO - 2018-02-18 18:41:41 --> Language Class Initialized
INFO - 2018-02-18 18:41:41 --> Loader Class Initialized
INFO - 2018-02-18 18:41:41 --> Helper loaded: url_helper
INFO - 2018-02-18 18:41:41 --> Helper loaded: form_helper
INFO - 2018-02-18 18:41:41 --> Database Driver Class Initialized
DEBUG - 2018-02-18 18:41:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 18:41:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 18:41:41 --> Form Validation Class Initialized
INFO - 2018-02-18 18:41:41 --> Model Class Initialized
INFO - 2018-02-18 18:41:41 --> Controller Class Initialized
INFO - 2018-02-18 18:41:41 --> Model Class Initialized
INFO - 2018-02-18 18:41:41 --> Model Class Initialized
INFO - 2018-02-18 18:41:41 --> Model Class Initialized
INFO - 2018-02-18 18:41:41 --> Model Class Initialized
INFO - 2018-02-18 18:41:41 --> Model Class Initialized
DEBUG - 2018-02-18 18:41:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 18:41:45 --> Config Class Initialized
INFO - 2018-02-18 18:41:45 --> Hooks Class Initialized
DEBUG - 2018-02-18 18:41:45 --> UTF-8 Support Enabled
INFO - 2018-02-18 18:41:45 --> Utf8 Class Initialized
INFO - 2018-02-18 18:41:45 --> URI Class Initialized
INFO - 2018-02-18 18:41:45 --> Router Class Initialized
INFO - 2018-02-18 18:41:45 --> Output Class Initialized
INFO - 2018-02-18 18:41:45 --> Security Class Initialized
DEBUG - 2018-02-18 18:41:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 18:41:45 --> Input Class Initialized
INFO - 2018-02-18 18:41:45 --> Language Class Initialized
INFO - 2018-02-18 18:41:45 --> Loader Class Initialized
INFO - 2018-02-18 18:41:45 --> Helper loaded: url_helper
INFO - 2018-02-18 18:41:45 --> Helper loaded: form_helper
INFO - 2018-02-18 18:41:45 --> Database Driver Class Initialized
DEBUG - 2018-02-18 18:41:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 18:41:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 18:41:45 --> Form Validation Class Initialized
INFO - 2018-02-18 18:41:45 --> Model Class Initialized
INFO - 2018-02-18 18:41:45 --> Controller Class Initialized
INFO - 2018-02-18 18:41:45 --> Model Class Initialized
INFO - 2018-02-18 18:41:45 --> Model Class Initialized
INFO - 2018-02-18 18:41:45 --> Model Class Initialized
INFO - 2018-02-18 18:41:45 --> Model Class Initialized
INFO - 2018-02-18 18:41:45 --> Model Class Initialized
DEBUG - 2018-02-18 18:41:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 18:41:45 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 18:41:45 --> Final output sent to browser
DEBUG - 2018-02-18 18:41:45 --> Total execution time: 0.1029
INFO - 2018-02-18 18:41:45 --> Config Class Initialized
INFO - 2018-02-18 18:41:45 --> Hooks Class Initialized
DEBUG - 2018-02-18 18:41:45 --> UTF-8 Support Enabled
INFO - 2018-02-18 18:41:45 --> Utf8 Class Initialized
INFO - 2018-02-18 18:41:45 --> URI Class Initialized
INFO - 2018-02-18 18:41:45 --> Router Class Initialized
INFO - 2018-02-18 18:41:45 --> Output Class Initialized
INFO - 2018-02-18 18:41:45 --> Security Class Initialized
DEBUG - 2018-02-18 18:41:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 18:41:45 --> Input Class Initialized
INFO - 2018-02-18 18:41:45 --> Language Class Initialized
INFO - 2018-02-18 18:41:45 --> Loader Class Initialized
INFO - 2018-02-18 18:41:45 --> Helper loaded: url_helper
INFO - 2018-02-18 18:41:45 --> Helper loaded: form_helper
INFO - 2018-02-18 18:41:45 --> Database Driver Class Initialized
DEBUG - 2018-02-18 18:41:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 18:41:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 18:41:45 --> Form Validation Class Initialized
INFO - 2018-02-18 18:41:45 --> Model Class Initialized
INFO - 2018-02-18 18:41:45 --> Controller Class Initialized
INFO - 2018-02-18 18:41:45 --> Model Class Initialized
INFO - 2018-02-18 18:41:45 --> Model Class Initialized
INFO - 2018-02-18 18:41:45 --> Model Class Initialized
INFO - 2018-02-18 18:41:45 --> Model Class Initialized
INFO - 2018-02-18 18:41:45 --> Model Class Initialized
DEBUG - 2018-02-18 18:41:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 18:41:47 --> Config Class Initialized
INFO - 2018-02-18 18:41:47 --> Hooks Class Initialized
DEBUG - 2018-02-18 18:41:47 --> UTF-8 Support Enabled
INFO - 2018-02-18 18:41:47 --> Utf8 Class Initialized
INFO - 2018-02-18 18:41:47 --> URI Class Initialized
INFO - 2018-02-18 18:41:47 --> Router Class Initialized
INFO - 2018-02-18 18:41:47 --> Output Class Initialized
INFO - 2018-02-18 18:41:47 --> Security Class Initialized
DEBUG - 2018-02-18 18:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 18:41:47 --> Input Class Initialized
INFO - 2018-02-18 18:41:47 --> Language Class Initialized
INFO - 2018-02-18 18:41:47 --> Loader Class Initialized
INFO - 2018-02-18 18:41:48 --> Helper loaded: url_helper
INFO - 2018-02-18 18:41:48 --> Helper loaded: form_helper
INFO - 2018-02-18 18:41:48 --> Database Driver Class Initialized
DEBUG - 2018-02-18 18:41:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 18:41:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 18:41:48 --> Form Validation Class Initialized
INFO - 2018-02-18 18:41:48 --> Model Class Initialized
INFO - 2018-02-18 18:41:48 --> Controller Class Initialized
INFO - 2018-02-18 18:41:48 --> Model Class Initialized
INFO - 2018-02-18 18:41:48 --> Model Class Initialized
INFO - 2018-02-18 18:41:48 --> Model Class Initialized
INFO - 2018-02-18 18:41:48 --> Model Class Initialized
INFO - 2018-02-18 18:41:48 --> Model Class Initialized
DEBUG - 2018-02-18 18:41:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 18:41:48 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 18:41:48 --> Final output sent to browser
DEBUG - 2018-02-18 18:41:48 --> Total execution time: 0.1136
INFO - 2018-02-18 18:41:48 --> Config Class Initialized
INFO - 2018-02-18 18:41:48 --> Hooks Class Initialized
DEBUG - 2018-02-18 18:41:48 --> UTF-8 Support Enabled
INFO - 2018-02-18 18:41:48 --> Utf8 Class Initialized
INFO - 2018-02-18 18:41:48 --> URI Class Initialized
INFO - 2018-02-18 18:41:48 --> Router Class Initialized
INFO - 2018-02-18 18:41:48 --> Output Class Initialized
INFO - 2018-02-18 18:41:48 --> Security Class Initialized
DEBUG - 2018-02-18 18:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 18:41:48 --> Input Class Initialized
INFO - 2018-02-18 18:41:48 --> Language Class Initialized
INFO - 2018-02-18 18:41:48 --> Loader Class Initialized
INFO - 2018-02-18 18:41:48 --> Helper loaded: url_helper
INFO - 2018-02-18 18:41:48 --> Helper loaded: form_helper
INFO - 2018-02-18 18:41:48 --> Database Driver Class Initialized
DEBUG - 2018-02-18 18:41:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 18:41:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 18:41:48 --> Form Validation Class Initialized
INFO - 2018-02-18 18:41:48 --> Model Class Initialized
INFO - 2018-02-18 18:41:48 --> Controller Class Initialized
INFO - 2018-02-18 18:41:48 --> Model Class Initialized
INFO - 2018-02-18 18:41:48 --> Model Class Initialized
INFO - 2018-02-18 18:41:48 --> Model Class Initialized
INFO - 2018-02-18 18:41:48 --> Model Class Initialized
INFO - 2018-02-18 18:41:48 --> Model Class Initialized
DEBUG - 2018-02-18 18:41:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 18:41:49 --> Config Class Initialized
INFO - 2018-02-18 18:41:49 --> Hooks Class Initialized
DEBUG - 2018-02-18 18:41:49 --> UTF-8 Support Enabled
INFO - 2018-02-18 18:41:49 --> Utf8 Class Initialized
INFO - 2018-02-18 18:41:49 --> URI Class Initialized
INFO - 2018-02-18 18:41:49 --> Router Class Initialized
INFO - 2018-02-18 18:41:49 --> Output Class Initialized
INFO - 2018-02-18 18:41:49 --> Security Class Initialized
DEBUG - 2018-02-18 18:41:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 18:41:49 --> Input Class Initialized
INFO - 2018-02-18 18:41:49 --> Language Class Initialized
INFO - 2018-02-18 18:41:49 --> Loader Class Initialized
INFO - 2018-02-18 18:41:49 --> Helper loaded: url_helper
INFO - 2018-02-18 18:41:49 --> Helper loaded: form_helper
INFO - 2018-02-18 18:41:49 --> Database Driver Class Initialized
DEBUG - 2018-02-18 18:41:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 18:41:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 18:41:49 --> Form Validation Class Initialized
INFO - 2018-02-18 18:41:49 --> Model Class Initialized
INFO - 2018-02-18 18:41:49 --> Controller Class Initialized
INFO - 2018-02-18 18:41:49 --> Model Class Initialized
INFO - 2018-02-18 18:41:49 --> Model Class Initialized
INFO - 2018-02-18 18:41:49 --> Model Class Initialized
INFO - 2018-02-18 18:41:49 --> Model Class Initialized
INFO - 2018-02-18 18:41:49 --> Model Class Initialized
DEBUG - 2018-02-18 18:41:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 18:41:49 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 18:41:49 --> Final output sent to browser
DEBUG - 2018-02-18 18:41:49 --> Total execution time: 0.1020
INFO - 2018-02-18 18:41:49 --> Config Class Initialized
INFO - 2018-02-18 18:41:49 --> Hooks Class Initialized
DEBUG - 2018-02-18 18:41:49 --> UTF-8 Support Enabled
INFO - 2018-02-18 18:41:49 --> Utf8 Class Initialized
INFO - 2018-02-18 18:41:49 --> URI Class Initialized
INFO - 2018-02-18 18:41:49 --> Router Class Initialized
INFO - 2018-02-18 18:41:49 --> Output Class Initialized
INFO - 2018-02-18 18:41:49 --> Security Class Initialized
DEBUG - 2018-02-18 18:41:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 18:41:49 --> Input Class Initialized
INFO - 2018-02-18 18:41:49 --> Language Class Initialized
INFO - 2018-02-18 18:41:49 --> Loader Class Initialized
INFO - 2018-02-18 18:41:49 --> Helper loaded: url_helper
INFO - 2018-02-18 18:41:49 --> Helper loaded: form_helper
INFO - 2018-02-18 18:41:49 --> Database Driver Class Initialized
DEBUG - 2018-02-18 18:41:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 18:41:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 18:41:49 --> Form Validation Class Initialized
INFO - 2018-02-18 18:41:49 --> Model Class Initialized
INFO - 2018-02-18 18:41:49 --> Controller Class Initialized
INFO - 2018-02-18 18:41:49 --> Model Class Initialized
INFO - 2018-02-18 18:41:49 --> Model Class Initialized
INFO - 2018-02-18 18:41:49 --> Model Class Initialized
INFO - 2018-02-18 18:41:49 --> Model Class Initialized
INFO - 2018-02-18 18:41:49 --> Model Class Initialized
DEBUG - 2018-02-18 18:41:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 18:42:29 --> Config Class Initialized
INFO - 2018-02-18 18:42:29 --> Hooks Class Initialized
DEBUG - 2018-02-18 18:42:29 --> UTF-8 Support Enabled
INFO - 2018-02-18 18:42:29 --> Utf8 Class Initialized
INFO - 2018-02-18 18:42:29 --> URI Class Initialized
INFO - 2018-02-18 18:42:29 --> Router Class Initialized
INFO - 2018-02-18 18:42:29 --> Output Class Initialized
INFO - 2018-02-18 18:42:29 --> Security Class Initialized
DEBUG - 2018-02-18 18:42:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 18:42:29 --> Input Class Initialized
INFO - 2018-02-18 18:42:29 --> Language Class Initialized
INFO - 2018-02-18 18:42:29 --> Loader Class Initialized
INFO - 2018-02-18 18:42:29 --> Helper loaded: url_helper
INFO - 2018-02-18 18:42:29 --> Helper loaded: form_helper
INFO - 2018-02-18 18:42:29 --> Database Driver Class Initialized
DEBUG - 2018-02-18 18:42:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 18:42:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 18:42:29 --> Form Validation Class Initialized
INFO - 2018-02-18 18:42:29 --> Model Class Initialized
INFO - 2018-02-18 18:42:29 --> Controller Class Initialized
INFO - 2018-02-18 18:42:29 --> Model Class Initialized
INFO - 2018-02-18 18:42:29 --> Model Class Initialized
INFO - 2018-02-18 18:42:29 --> Model Class Initialized
INFO - 2018-02-18 18:42:29 --> Model Class Initialized
INFO - 2018-02-18 18:42:29 --> Model Class Initialized
DEBUG - 2018-02-18 18:42:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 18:42:29 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 18:42:29 --> Final output sent to browser
DEBUG - 2018-02-18 18:42:29 --> Total execution time: 0.0674
INFO - 2018-02-18 18:42:30 --> Config Class Initialized
INFO - 2018-02-18 18:42:30 --> Hooks Class Initialized
DEBUG - 2018-02-18 18:42:30 --> UTF-8 Support Enabled
INFO - 2018-02-18 18:42:30 --> Utf8 Class Initialized
INFO - 2018-02-18 18:42:30 --> URI Class Initialized
INFO - 2018-02-18 18:42:30 --> Router Class Initialized
INFO - 2018-02-18 18:42:30 --> Output Class Initialized
INFO - 2018-02-18 18:42:30 --> Security Class Initialized
DEBUG - 2018-02-18 18:42:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 18:42:30 --> Input Class Initialized
INFO - 2018-02-18 18:42:30 --> Language Class Initialized
INFO - 2018-02-18 18:42:30 --> Loader Class Initialized
INFO - 2018-02-18 18:42:30 --> Helper loaded: url_helper
INFO - 2018-02-18 18:42:30 --> Helper loaded: form_helper
INFO - 2018-02-18 18:42:30 --> Database Driver Class Initialized
DEBUG - 2018-02-18 18:42:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 18:42:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 18:42:30 --> Form Validation Class Initialized
INFO - 2018-02-18 18:42:30 --> Model Class Initialized
INFO - 2018-02-18 18:42:30 --> Controller Class Initialized
INFO - 2018-02-18 18:42:30 --> Model Class Initialized
INFO - 2018-02-18 18:42:30 --> Model Class Initialized
INFO - 2018-02-18 18:42:30 --> Model Class Initialized
INFO - 2018-02-18 18:42:30 --> Model Class Initialized
INFO - 2018-02-18 18:42:30 --> Model Class Initialized
DEBUG - 2018-02-18 18:42:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 18:42:34 --> Config Class Initialized
INFO - 2018-02-18 18:42:34 --> Hooks Class Initialized
DEBUG - 2018-02-18 18:42:34 --> UTF-8 Support Enabled
INFO - 2018-02-18 18:42:34 --> Utf8 Class Initialized
INFO - 2018-02-18 18:42:34 --> URI Class Initialized
INFO - 2018-02-18 18:42:34 --> Router Class Initialized
INFO - 2018-02-18 18:42:34 --> Output Class Initialized
INFO - 2018-02-18 18:42:34 --> Security Class Initialized
DEBUG - 2018-02-18 18:42:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 18:42:34 --> Input Class Initialized
INFO - 2018-02-18 18:42:34 --> Language Class Initialized
INFO - 2018-02-18 18:42:34 --> Loader Class Initialized
INFO - 2018-02-18 18:42:34 --> Helper loaded: url_helper
INFO - 2018-02-18 18:42:34 --> Helper loaded: form_helper
INFO - 2018-02-18 18:42:34 --> Database Driver Class Initialized
DEBUG - 2018-02-18 18:42:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 18:42:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 18:42:34 --> Form Validation Class Initialized
INFO - 2018-02-18 18:42:34 --> Model Class Initialized
INFO - 2018-02-18 18:42:34 --> Controller Class Initialized
INFO - 2018-02-18 18:42:34 --> Model Class Initialized
INFO - 2018-02-18 18:42:34 --> Model Class Initialized
INFO - 2018-02-18 18:42:34 --> Model Class Initialized
INFO - 2018-02-18 18:42:34 --> Model Class Initialized
INFO - 2018-02-18 18:42:34 --> Model Class Initialized
DEBUG - 2018-02-18 18:42:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 18:42:34 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 18:42:34 --> Final output sent to browser
DEBUG - 2018-02-18 18:42:34 --> Total execution time: 0.0608
INFO - 2018-02-18 18:42:34 --> Config Class Initialized
INFO - 2018-02-18 18:42:34 --> Hooks Class Initialized
DEBUG - 2018-02-18 18:42:34 --> UTF-8 Support Enabled
INFO - 2018-02-18 18:42:34 --> Utf8 Class Initialized
INFO - 2018-02-18 18:42:34 --> URI Class Initialized
INFO - 2018-02-18 18:42:34 --> Router Class Initialized
INFO - 2018-02-18 18:42:34 --> Output Class Initialized
INFO - 2018-02-18 18:42:34 --> Security Class Initialized
DEBUG - 2018-02-18 18:42:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 18:42:34 --> Input Class Initialized
INFO - 2018-02-18 18:42:34 --> Language Class Initialized
INFO - 2018-02-18 18:42:34 --> Loader Class Initialized
INFO - 2018-02-18 18:42:34 --> Helper loaded: url_helper
INFO - 2018-02-18 18:42:34 --> Helper loaded: form_helper
INFO - 2018-02-18 18:42:34 --> Database Driver Class Initialized
DEBUG - 2018-02-18 18:42:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 18:42:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 18:42:34 --> Form Validation Class Initialized
INFO - 2018-02-18 18:42:34 --> Model Class Initialized
INFO - 2018-02-18 18:42:34 --> Controller Class Initialized
INFO - 2018-02-18 18:42:34 --> Model Class Initialized
INFO - 2018-02-18 18:42:34 --> Model Class Initialized
INFO - 2018-02-18 18:42:34 --> Model Class Initialized
INFO - 2018-02-18 18:42:34 --> Model Class Initialized
INFO - 2018-02-18 18:42:34 --> Model Class Initialized
DEBUG - 2018-02-18 18:42:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 18:42:36 --> Config Class Initialized
INFO - 2018-02-18 18:42:36 --> Hooks Class Initialized
DEBUG - 2018-02-18 18:42:36 --> UTF-8 Support Enabled
INFO - 2018-02-18 18:42:36 --> Utf8 Class Initialized
INFO - 2018-02-18 18:42:36 --> URI Class Initialized
INFO - 2018-02-18 18:42:36 --> Router Class Initialized
INFO - 2018-02-18 18:42:36 --> Output Class Initialized
INFO - 2018-02-18 18:42:36 --> Security Class Initialized
DEBUG - 2018-02-18 18:42:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 18:42:36 --> Input Class Initialized
INFO - 2018-02-18 18:42:36 --> Language Class Initialized
INFO - 2018-02-18 18:42:36 --> Loader Class Initialized
INFO - 2018-02-18 18:42:36 --> Helper loaded: url_helper
INFO - 2018-02-18 18:42:36 --> Helper loaded: form_helper
INFO - 2018-02-18 18:42:36 --> Database Driver Class Initialized
DEBUG - 2018-02-18 18:42:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 18:42:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 18:42:36 --> Form Validation Class Initialized
INFO - 2018-02-18 18:42:36 --> Model Class Initialized
INFO - 2018-02-18 18:42:36 --> Controller Class Initialized
INFO - 2018-02-18 18:42:36 --> Model Class Initialized
INFO - 2018-02-18 18:42:36 --> Model Class Initialized
INFO - 2018-02-18 18:42:36 --> Model Class Initialized
INFO - 2018-02-18 18:42:36 --> Model Class Initialized
INFO - 2018-02-18 18:42:36 --> Model Class Initialized
DEBUG - 2018-02-18 18:42:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 18:42:36 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 18:42:36 --> Final output sent to browser
DEBUG - 2018-02-18 18:42:36 --> Total execution time: 0.0562
INFO - 2018-02-18 18:42:36 --> Config Class Initialized
INFO - 2018-02-18 18:42:36 --> Hooks Class Initialized
DEBUG - 2018-02-18 18:42:36 --> UTF-8 Support Enabled
INFO - 2018-02-18 18:42:36 --> Utf8 Class Initialized
INFO - 2018-02-18 18:42:36 --> URI Class Initialized
INFO - 2018-02-18 18:42:36 --> Router Class Initialized
INFO - 2018-02-18 18:42:36 --> Output Class Initialized
INFO - 2018-02-18 18:42:36 --> Security Class Initialized
DEBUG - 2018-02-18 18:42:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 18:42:36 --> Input Class Initialized
INFO - 2018-02-18 18:42:36 --> Language Class Initialized
INFO - 2018-02-18 18:42:36 --> Loader Class Initialized
INFO - 2018-02-18 18:42:36 --> Helper loaded: url_helper
INFO - 2018-02-18 18:42:36 --> Helper loaded: form_helper
INFO - 2018-02-18 18:42:36 --> Database Driver Class Initialized
DEBUG - 2018-02-18 18:42:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 18:42:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 18:42:36 --> Form Validation Class Initialized
INFO - 2018-02-18 18:42:36 --> Model Class Initialized
INFO - 2018-02-18 18:42:36 --> Controller Class Initialized
INFO - 2018-02-18 18:42:36 --> Model Class Initialized
INFO - 2018-02-18 18:42:36 --> Model Class Initialized
INFO - 2018-02-18 18:42:36 --> Model Class Initialized
INFO - 2018-02-18 18:42:36 --> Model Class Initialized
INFO - 2018-02-18 18:42:36 --> Model Class Initialized
DEBUG - 2018-02-18 18:42:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 18:42:37 --> Config Class Initialized
INFO - 2018-02-18 18:42:37 --> Hooks Class Initialized
DEBUG - 2018-02-18 18:42:37 --> UTF-8 Support Enabled
INFO - 2018-02-18 18:42:37 --> Utf8 Class Initialized
INFO - 2018-02-18 18:42:37 --> URI Class Initialized
INFO - 2018-02-18 18:42:37 --> Router Class Initialized
INFO - 2018-02-18 18:42:37 --> Output Class Initialized
INFO - 2018-02-18 18:42:37 --> Security Class Initialized
DEBUG - 2018-02-18 18:42:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 18:42:37 --> Input Class Initialized
INFO - 2018-02-18 18:42:37 --> Language Class Initialized
INFO - 2018-02-18 18:42:37 --> Loader Class Initialized
INFO - 2018-02-18 18:42:37 --> Helper loaded: url_helper
INFO - 2018-02-18 18:42:37 --> Helper loaded: form_helper
INFO - 2018-02-18 18:42:37 --> Database Driver Class Initialized
DEBUG - 2018-02-18 18:42:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 18:42:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 18:42:37 --> Form Validation Class Initialized
INFO - 2018-02-18 18:42:37 --> Model Class Initialized
INFO - 2018-02-18 18:42:37 --> Controller Class Initialized
INFO - 2018-02-18 18:42:37 --> Model Class Initialized
INFO - 2018-02-18 18:42:37 --> Model Class Initialized
INFO - 2018-02-18 18:42:37 --> Model Class Initialized
INFO - 2018-02-18 18:42:37 --> Model Class Initialized
INFO - 2018-02-18 18:42:37 --> Model Class Initialized
DEBUG - 2018-02-18 18:42:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 18:42:37 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 18:42:37 --> Final output sent to browser
DEBUG - 2018-02-18 18:42:37 --> Total execution time: 0.0707
INFO - 2018-02-18 18:42:38 --> Config Class Initialized
INFO - 2018-02-18 18:42:38 --> Hooks Class Initialized
DEBUG - 2018-02-18 18:42:38 --> UTF-8 Support Enabled
INFO - 2018-02-18 18:42:38 --> Utf8 Class Initialized
INFO - 2018-02-18 18:42:38 --> URI Class Initialized
INFO - 2018-02-18 18:42:38 --> Router Class Initialized
INFO - 2018-02-18 18:42:38 --> Output Class Initialized
INFO - 2018-02-18 18:42:38 --> Security Class Initialized
DEBUG - 2018-02-18 18:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 18:42:38 --> Input Class Initialized
INFO - 2018-02-18 18:42:38 --> Language Class Initialized
INFO - 2018-02-18 18:42:38 --> Loader Class Initialized
INFO - 2018-02-18 18:42:38 --> Helper loaded: url_helper
INFO - 2018-02-18 18:42:38 --> Helper loaded: form_helper
INFO - 2018-02-18 18:42:38 --> Database Driver Class Initialized
DEBUG - 2018-02-18 18:42:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 18:42:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 18:42:38 --> Form Validation Class Initialized
INFO - 2018-02-18 18:42:38 --> Model Class Initialized
INFO - 2018-02-18 18:42:38 --> Controller Class Initialized
INFO - 2018-02-18 18:42:38 --> Model Class Initialized
INFO - 2018-02-18 18:42:38 --> Model Class Initialized
INFO - 2018-02-18 18:42:38 --> Model Class Initialized
INFO - 2018-02-18 18:42:38 --> Model Class Initialized
INFO - 2018-02-18 18:42:38 --> Model Class Initialized
DEBUG - 2018-02-18 18:42:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 18:51:46 --> Config Class Initialized
INFO - 2018-02-18 18:51:46 --> Hooks Class Initialized
DEBUG - 2018-02-18 18:51:46 --> UTF-8 Support Enabled
INFO - 2018-02-18 18:51:46 --> Utf8 Class Initialized
INFO - 2018-02-18 18:51:46 --> URI Class Initialized
INFO - 2018-02-18 18:51:46 --> Router Class Initialized
INFO - 2018-02-18 18:51:46 --> Output Class Initialized
INFO - 2018-02-18 18:51:46 --> Security Class Initialized
DEBUG - 2018-02-18 18:51:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 18:51:46 --> Input Class Initialized
INFO - 2018-02-18 18:51:46 --> Language Class Initialized
INFO - 2018-02-18 18:51:46 --> Loader Class Initialized
INFO - 2018-02-18 18:51:46 --> Helper loaded: url_helper
INFO - 2018-02-18 18:51:46 --> Helper loaded: form_helper
INFO - 2018-02-18 18:51:46 --> Database Driver Class Initialized
DEBUG - 2018-02-18 18:51:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 18:51:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 18:51:47 --> Form Validation Class Initialized
INFO - 2018-02-18 18:51:47 --> Model Class Initialized
INFO - 2018-02-18 18:51:47 --> Controller Class Initialized
INFO - 2018-02-18 18:51:47 --> Model Class Initialized
INFO - 2018-02-18 18:51:47 --> Model Class Initialized
INFO - 2018-02-18 18:51:47 --> Model Class Initialized
INFO - 2018-02-18 18:51:47 --> Model Class Initialized
INFO - 2018-02-18 18:51:47 --> Model Class Initialized
DEBUG - 2018-02-18 18:51:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 18:51:47 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 18:51:47 --> Final output sent to browser
DEBUG - 2018-02-18 18:51:47 --> Total execution time: 0.0777
INFO - 2018-02-18 18:51:47 --> Config Class Initialized
INFO - 2018-02-18 18:51:47 --> Hooks Class Initialized
DEBUG - 2018-02-18 18:51:47 --> UTF-8 Support Enabled
INFO - 2018-02-18 18:51:47 --> Utf8 Class Initialized
INFO - 2018-02-18 18:51:47 --> URI Class Initialized
INFO - 2018-02-18 18:51:47 --> Router Class Initialized
INFO - 2018-02-18 18:51:47 --> Output Class Initialized
INFO - 2018-02-18 18:51:47 --> Security Class Initialized
DEBUG - 2018-02-18 18:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 18:51:47 --> Input Class Initialized
INFO - 2018-02-18 18:51:47 --> Language Class Initialized
INFO - 2018-02-18 18:51:47 --> Loader Class Initialized
INFO - 2018-02-18 18:51:47 --> Helper loaded: url_helper
INFO - 2018-02-18 18:51:47 --> Helper loaded: form_helper
INFO - 2018-02-18 18:51:47 --> Database Driver Class Initialized
DEBUG - 2018-02-18 18:51:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 18:51:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 18:51:47 --> Form Validation Class Initialized
INFO - 2018-02-18 18:51:47 --> Model Class Initialized
INFO - 2018-02-18 18:51:47 --> Controller Class Initialized
INFO - 2018-02-18 18:51:47 --> Model Class Initialized
INFO - 2018-02-18 18:51:47 --> Model Class Initialized
INFO - 2018-02-18 18:51:47 --> Model Class Initialized
INFO - 2018-02-18 18:51:47 --> Model Class Initialized
INFO - 2018-02-18 18:51:47 --> Model Class Initialized
DEBUG - 2018-02-18 18:51:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 18:51:47 --> Config Class Initialized
INFO - 2018-02-18 18:51:47 --> Hooks Class Initialized
DEBUG - 2018-02-18 18:51:47 --> UTF-8 Support Enabled
INFO - 2018-02-18 18:51:47 --> Utf8 Class Initialized
INFO - 2018-02-18 18:51:47 --> URI Class Initialized
INFO - 2018-02-18 18:51:47 --> Router Class Initialized
INFO - 2018-02-18 18:51:47 --> Output Class Initialized
INFO - 2018-02-18 18:51:47 --> Security Class Initialized
DEBUG - 2018-02-18 18:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 18:51:47 --> Input Class Initialized
INFO - 2018-02-18 18:51:47 --> Language Class Initialized
INFO - 2018-02-18 18:51:47 --> Loader Class Initialized
INFO - 2018-02-18 18:51:47 --> Helper loaded: url_helper
INFO - 2018-02-18 18:51:47 --> Helper loaded: form_helper
INFO - 2018-02-18 18:51:48 --> Database Driver Class Initialized
DEBUG - 2018-02-18 18:51:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 18:51:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 18:51:48 --> Form Validation Class Initialized
INFO - 2018-02-18 18:51:48 --> Model Class Initialized
INFO - 2018-02-18 18:51:48 --> Controller Class Initialized
INFO - 2018-02-18 18:51:48 --> Model Class Initialized
INFO - 2018-02-18 18:51:48 --> Model Class Initialized
INFO - 2018-02-18 18:51:48 --> Model Class Initialized
INFO - 2018-02-18 18:51:48 --> Model Class Initialized
INFO - 2018-02-18 18:51:48 --> Model Class Initialized
DEBUG - 2018-02-18 18:51:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 18:51:48 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 18:51:48 --> Final output sent to browser
DEBUG - 2018-02-18 18:51:48 --> Total execution time: 0.0866
INFO - 2018-02-18 18:51:48 --> Config Class Initialized
INFO - 2018-02-18 18:51:48 --> Hooks Class Initialized
DEBUG - 2018-02-18 18:51:48 --> UTF-8 Support Enabled
INFO - 2018-02-18 18:51:48 --> Utf8 Class Initialized
INFO - 2018-02-18 18:51:48 --> URI Class Initialized
INFO - 2018-02-18 18:51:48 --> Router Class Initialized
INFO - 2018-02-18 18:51:48 --> Output Class Initialized
INFO - 2018-02-18 18:51:48 --> Security Class Initialized
DEBUG - 2018-02-18 18:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 18:51:48 --> Input Class Initialized
INFO - 2018-02-18 18:51:48 --> Language Class Initialized
INFO - 2018-02-18 18:51:48 --> Loader Class Initialized
INFO - 2018-02-18 18:51:48 --> Helper loaded: url_helper
INFO - 2018-02-18 18:51:48 --> Helper loaded: form_helper
INFO - 2018-02-18 18:51:48 --> Database Driver Class Initialized
DEBUG - 2018-02-18 18:51:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 18:51:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 18:51:48 --> Form Validation Class Initialized
INFO - 2018-02-18 18:51:48 --> Model Class Initialized
INFO - 2018-02-18 18:51:48 --> Controller Class Initialized
INFO - 2018-02-18 18:51:48 --> Model Class Initialized
INFO - 2018-02-18 18:51:48 --> Model Class Initialized
INFO - 2018-02-18 18:51:48 --> Model Class Initialized
INFO - 2018-02-18 18:51:48 --> Model Class Initialized
INFO - 2018-02-18 18:51:48 --> Model Class Initialized
DEBUG - 2018-02-18 18:51:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 18:52:10 --> Config Class Initialized
INFO - 2018-02-18 18:52:10 --> Hooks Class Initialized
DEBUG - 2018-02-18 18:52:10 --> UTF-8 Support Enabled
INFO - 2018-02-18 18:52:10 --> Utf8 Class Initialized
INFO - 2018-02-18 18:52:10 --> URI Class Initialized
INFO - 2018-02-18 18:52:10 --> Router Class Initialized
INFO - 2018-02-18 18:52:10 --> Output Class Initialized
INFO - 2018-02-18 18:52:10 --> Security Class Initialized
DEBUG - 2018-02-18 18:52:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 18:52:10 --> Input Class Initialized
INFO - 2018-02-18 18:52:10 --> Language Class Initialized
INFO - 2018-02-18 18:52:10 --> Loader Class Initialized
INFO - 2018-02-18 18:52:10 --> Helper loaded: url_helper
INFO - 2018-02-18 18:52:10 --> Helper loaded: form_helper
INFO - 2018-02-18 18:52:10 --> Database Driver Class Initialized
DEBUG - 2018-02-18 18:52:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 18:52:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 18:52:10 --> Form Validation Class Initialized
INFO - 2018-02-18 18:52:10 --> Model Class Initialized
INFO - 2018-02-18 18:52:10 --> Controller Class Initialized
INFO - 2018-02-18 18:52:10 --> Model Class Initialized
INFO - 2018-02-18 18:52:10 --> Model Class Initialized
INFO - 2018-02-18 18:52:10 --> Model Class Initialized
INFO - 2018-02-18 18:52:10 --> Model Class Initialized
INFO - 2018-02-18 18:52:10 --> Model Class Initialized
DEBUG - 2018-02-18 18:52:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 18:52:10 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 18:52:10 --> Final output sent to browser
DEBUG - 2018-02-18 18:52:10 --> Total execution time: 0.1036
INFO - 2018-02-18 18:52:28 --> Config Class Initialized
INFO - 2018-02-18 18:52:28 --> Hooks Class Initialized
DEBUG - 2018-02-18 18:52:28 --> UTF-8 Support Enabled
INFO - 2018-02-18 18:52:28 --> Utf8 Class Initialized
INFO - 2018-02-18 18:52:28 --> URI Class Initialized
INFO - 2018-02-18 18:52:28 --> Router Class Initialized
INFO - 2018-02-18 18:52:28 --> Output Class Initialized
INFO - 2018-02-18 18:52:28 --> Security Class Initialized
DEBUG - 2018-02-18 18:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 18:52:28 --> Input Class Initialized
INFO - 2018-02-18 18:52:28 --> Language Class Initialized
INFO - 2018-02-18 18:52:28 --> Loader Class Initialized
INFO - 2018-02-18 18:52:28 --> Helper loaded: url_helper
INFO - 2018-02-18 18:52:28 --> Helper loaded: form_helper
INFO - 2018-02-18 18:52:28 --> Database Driver Class Initialized
DEBUG - 2018-02-18 18:52:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 18:52:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 18:52:28 --> Form Validation Class Initialized
INFO - 2018-02-18 18:52:28 --> Model Class Initialized
INFO - 2018-02-18 18:52:28 --> Controller Class Initialized
INFO - 2018-02-18 18:52:28 --> Model Class Initialized
INFO - 2018-02-18 18:52:28 --> Model Class Initialized
INFO - 2018-02-18 18:52:28 --> Model Class Initialized
INFO - 2018-02-18 18:52:28 --> Model Class Initialized
INFO - 2018-02-18 18:52:28 --> Model Class Initialized
DEBUG - 2018-02-18 18:52:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 18:52:29 --> Config Class Initialized
INFO - 2018-02-18 18:52:29 --> Hooks Class Initialized
DEBUG - 2018-02-18 18:52:29 --> UTF-8 Support Enabled
INFO - 2018-02-18 18:52:29 --> Utf8 Class Initialized
INFO - 2018-02-18 18:52:29 --> URI Class Initialized
INFO - 2018-02-18 18:52:29 --> Router Class Initialized
INFO - 2018-02-18 18:52:29 --> Output Class Initialized
INFO - 2018-02-18 18:52:29 --> Security Class Initialized
DEBUG - 2018-02-18 18:52:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 18:52:29 --> Input Class Initialized
INFO - 2018-02-18 18:52:29 --> Language Class Initialized
INFO - 2018-02-18 18:52:29 --> Loader Class Initialized
INFO - 2018-02-18 18:52:29 --> Helper loaded: url_helper
INFO - 2018-02-18 18:52:29 --> Helper loaded: form_helper
INFO - 2018-02-18 18:52:29 --> Database Driver Class Initialized
DEBUG - 2018-02-18 18:52:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 18:52:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 18:52:29 --> Form Validation Class Initialized
INFO - 2018-02-18 18:52:29 --> Model Class Initialized
INFO - 2018-02-18 18:52:29 --> Controller Class Initialized
INFO - 2018-02-18 18:52:29 --> Model Class Initialized
INFO - 2018-02-18 18:52:29 --> Model Class Initialized
INFO - 2018-02-18 18:52:29 --> Model Class Initialized
INFO - 2018-02-18 18:52:29 --> Model Class Initialized
INFO - 2018-02-18 18:52:29 --> Model Class Initialized
DEBUG - 2018-02-18 18:52:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 18:52:29 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 18:52:29 --> Final output sent to browser
DEBUG - 2018-02-18 18:52:29 --> Total execution time: 0.0655
INFO - 2018-02-18 18:52:29 --> Config Class Initialized
INFO - 2018-02-18 18:52:29 --> Hooks Class Initialized
DEBUG - 2018-02-18 18:52:29 --> UTF-8 Support Enabled
INFO - 2018-02-18 18:52:29 --> Utf8 Class Initialized
INFO - 2018-02-18 18:52:29 --> URI Class Initialized
INFO - 2018-02-18 18:52:29 --> Router Class Initialized
INFO - 2018-02-18 18:52:29 --> Output Class Initialized
INFO - 2018-02-18 18:52:29 --> Security Class Initialized
DEBUG - 2018-02-18 18:52:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 18:52:29 --> Input Class Initialized
INFO - 2018-02-18 18:52:29 --> Language Class Initialized
INFO - 2018-02-18 18:52:29 --> Loader Class Initialized
INFO - 2018-02-18 18:52:29 --> Helper loaded: url_helper
INFO - 2018-02-18 18:52:29 --> Helper loaded: form_helper
INFO - 2018-02-18 18:52:29 --> Database Driver Class Initialized
DEBUG - 2018-02-18 18:52:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 18:52:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 18:52:29 --> Form Validation Class Initialized
INFO - 2018-02-18 18:52:29 --> Model Class Initialized
INFO - 2018-02-18 18:52:29 --> Controller Class Initialized
INFO - 2018-02-18 18:52:29 --> Model Class Initialized
INFO - 2018-02-18 18:52:29 --> Model Class Initialized
INFO - 2018-02-18 18:52:29 --> Model Class Initialized
INFO - 2018-02-18 18:52:29 --> Model Class Initialized
INFO - 2018-02-18 18:52:29 --> Model Class Initialized
DEBUG - 2018-02-18 18:52:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 18:52:37 --> Config Class Initialized
INFO - 2018-02-18 18:52:37 --> Hooks Class Initialized
DEBUG - 2018-02-18 18:52:37 --> UTF-8 Support Enabled
INFO - 2018-02-18 18:52:37 --> Utf8 Class Initialized
INFO - 2018-02-18 18:52:37 --> URI Class Initialized
INFO - 2018-02-18 18:52:37 --> Router Class Initialized
INFO - 2018-02-18 18:52:37 --> Output Class Initialized
INFO - 2018-02-18 18:52:37 --> Security Class Initialized
DEBUG - 2018-02-18 18:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 18:52:37 --> Input Class Initialized
INFO - 2018-02-18 18:52:37 --> Language Class Initialized
INFO - 2018-02-18 18:52:37 --> Loader Class Initialized
INFO - 2018-02-18 18:52:37 --> Helper loaded: url_helper
INFO - 2018-02-18 18:52:37 --> Helper loaded: form_helper
INFO - 2018-02-18 18:52:37 --> Database Driver Class Initialized
DEBUG - 2018-02-18 18:52:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 18:52:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 18:52:37 --> Form Validation Class Initialized
INFO - 2018-02-18 18:52:37 --> Model Class Initialized
INFO - 2018-02-18 18:52:37 --> Controller Class Initialized
INFO - 2018-02-18 18:52:37 --> Model Class Initialized
INFO - 2018-02-18 18:52:37 --> Model Class Initialized
INFO - 2018-02-18 18:52:37 --> Model Class Initialized
INFO - 2018-02-18 18:52:37 --> Model Class Initialized
INFO - 2018-02-18 18:52:37 --> Model Class Initialized
DEBUG - 2018-02-18 18:52:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 18:52:37 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 18:52:37 --> Final output sent to browser
DEBUG - 2018-02-18 18:52:37 --> Total execution time: 0.0726
INFO - 2018-02-18 18:52:37 --> Config Class Initialized
INFO - 2018-02-18 18:52:37 --> Hooks Class Initialized
DEBUG - 2018-02-18 18:52:37 --> UTF-8 Support Enabled
INFO - 2018-02-18 18:52:37 --> Utf8 Class Initialized
INFO - 2018-02-18 18:52:37 --> URI Class Initialized
INFO - 2018-02-18 18:52:37 --> Router Class Initialized
INFO - 2018-02-18 18:52:37 --> Output Class Initialized
INFO - 2018-02-18 18:52:37 --> Security Class Initialized
DEBUG - 2018-02-18 18:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 18:52:37 --> Input Class Initialized
INFO - 2018-02-18 18:52:37 --> Language Class Initialized
INFO - 2018-02-18 18:52:37 --> Loader Class Initialized
INFO - 2018-02-18 18:52:37 --> Helper loaded: url_helper
INFO - 2018-02-18 18:52:37 --> Helper loaded: form_helper
INFO - 2018-02-18 18:52:37 --> Database Driver Class Initialized
DEBUG - 2018-02-18 18:52:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 18:52:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 18:52:37 --> Form Validation Class Initialized
INFO - 2018-02-18 18:52:37 --> Model Class Initialized
INFO - 2018-02-18 18:52:37 --> Controller Class Initialized
INFO - 2018-02-18 18:52:37 --> Model Class Initialized
INFO - 2018-02-18 18:52:37 --> Model Class Initialized
INFO - 2018-02-18 18:52:37 --> Model Class Initialized
INFO - 2018-02-18 18:52:37 --> Model Class Initialized
INFO - 2018-02-18 18:52:37 --> Model Class Initialized
DEBUG - 2018-02-18 18:52:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:00:07 --> Config Class Initialized
INFO - 2018-02-18 19:00:07 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:00:07 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:00:07 --> Utf8 Class Initialized
INFO - 2018-02-18 19:00:07 --> URI Class Initialized
INFO - 2018-02-18 19:00:07 --> Router Class Initialized
INFO - 2018-02-18 19:00:07 --> Output Class Initialized
INFO - 2018-02-18 19:00:07 --> Security Class Initialized
DEBUG - 2018-02-18 19:00:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:00:07 --> Input Class Initialized
INFO - 2018-02-18 19:00:07 --> Language Class Initialized
INFO - 2018-02-18 19:00:07 --> Loader Class Initialized
INFO - 2018-02-18 19:00:07 --> Helper loaded: url_helper
INFO - 2018-02-18 19:00:07 --> Helper loaded: form_helper
INFO - 2018-02-18 19:00:07 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:00:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:00:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:00:07 --> Form Validation Class Initialized
INFO - 2018-02-18 19:00:07 --> Model Class Initialized
INFO - 2018-02-18 19:00:07 --> Controller Class Initialized
INFO - 2018-02-18 19:00:07 --> Model Class Initialized
INFO - 2018-02-18 19:00:07 --> Model Class Initialized
INFO - 2018-02-18 19:00:07 --> Model Class Initialized
INFO - 2018-02-18 19:00:07 --> Model Class Initialized
INFO - 2018-02-18 19:00:07 --> Model Class Initialized
DEBUG - 2018-02-18 19:00:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:00:07 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 19:00:07 --> Final output sent to browser
DEBUG - 2018-02-18 19:00:07 --> Total execution time: 0.0743
INFO - 2018-02-18 19:00:07 --> Config Class Initialized
INFO - 2018-02-18 19:00:07 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:00:07 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:00:07 --> Utf8 Class Initialized
INFO - 2018-02-18 19:00:07 --> URI Class Initialized
INFO - 2018-02-18 19:00:07 --> Router Class Initialized
INFO - 2018-02-18 19:00:07 --> Output Class Initialized
INFO - 2018-02-18 19:00:07 --> Security Class Initialized
DEBUG - 2018-02-18 19:00:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:00:07 --> Input Class Initialized
INFO - 2018-02-18 19:00:07 --> Language Class Initialized
INFO - 2018-02-18 19:00:07 --> Loader Class Initialized
INFO - 2018-02-18 19:00:07 --> Helper loaded: url_helper
INFO - 2018-02-18 19:00:07 --> Helper loaded: form_helper
INFO - 2018-02-18 19:00:07 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:00:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:00:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:00:07 --> Form Validation Class Initialized
INFO - 2018-02-18 19:00:07 --> Model Class Initialized
INFO - 2018-02-18 19:00:07 --> Controller Class Initialized
INFO - 2018-02-18 19:00:07 --> Model Class Initialized
INFO - 2018-02-18 19:00:07 --> Model Class Initialized
INFO - 2018-02-18 19:00:07 --> Model Class Initialized
INFO - 2018-02-18 19:00:07 --> Model Class Initialized
INFO - 2018-02-18 19:00:07 --> Model Class Initialized
DEBUG - 2018-02-18 19:00:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:00:08 --> Config Class Initialized
INFO - 2018-02-18 19:00:08 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:00:08 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:00:08 --> Utf8 Class Initialized
INFO - 2018-02-18 19:00:08 --> URI Class Initialized
INFO - 2018-02-18 19:00:08 --> Router Class Initialized
INFO - 2018-02-18 19:00:08 --> Output Class Initialized
INFO - 2018-02-18 19:00:08 --> Security Class Initialized
DEBUG - 2018-02-18 19:00:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:00:08 --> Input Class Initialized
INFO - 2018-02-18 19:00:08 --> Language Class Initialized
INFO - 2018-02-18 19:00:08 --> Loader Class Initialized
INFO - 2018-02-18 19:00:08 --> Helper loaded: url_helper
INFO - 2018-02-18 19:00:08 --> Helper loaded: form_helper
INFO - 2018-02-18 19:00:08 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:00:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:00:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:00:08 --> Form Validation Class Initialized
INFO - 2018-02-18 19:00:08 --> Model Class Initialized
INFO - 2018-02-18 19:00:08 --> Controller Class Initialized
INFO - 2018-02-18 19:00:08 --> Model Class Initialized
INFO - 2018-02-18 19:00:08 --> Model Class Initialized
INFO - 2018-02-18 19:00:08 --> Model Class Initialized
INFO - 2018-02-18 19:00:08 --> Model Class Initialized
INFO - 2018-02-18 19:00:08 --> Model Class Initialized
DEBUG - 2018-02-18 19:00:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:00:08 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 19:00:08 --> Final output sent to browser
DEBUG - 2018-02-18 19:00:08 --> Total execution time: 0.0669
INFO - 2018-02-18 19:00:08 --> Config Class Initialized
INFO - 2018-02-18 19:00:08 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:00:08 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:00:08 --> Utf8 Class Initialized
INFO - 2018-02-18 19:00:08 --> URI Class Initialized
INFO - 2018-02-18 19:00:08 --> Router Class Initialized
INFO - 2018-02-18 19:00:08 --> Output Class Initialized
INFO - 2018-02-18 19:00:08 --> Security Class Initialized
DEBUG - 2018-02-18 19:00:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:00:08 --> Input Class Initialized
INFO - 2018-02-18 19:00:08 --> Language Class Initialized
INFO - 2018-02-18 19:00:08 --> Loader Class Initialized
INFO - 2018-02-18 19:00:08 --> Helper loaded: url_helper
INFO - 2018-02-18 19:00:08 --> Helper loaded: form_helper
INFO - 2018-02-18 19:00:08 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:00:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:00:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:00:08 --> Form Validation Class Initialized
INFO - 2018-02-18 19:00:08 --> Model Class Initialized
INFO - 2018-02-18 19:00:08 --> Controller Class Initialized
INFO - 2018-02-18 19:00:08 --> Model Class Initialized
INFO - 2018-02-18 19:00:08 --> Model Class Initialized
INFO - 2018-02-18 19:00:08 --> Model Class Initialized
INFO - 2018-02-18 19:00:08 --> Model Class Initialized
INFO - 2018-02-18 19:00:08 --> Model Class Initialized
DEBUG - 2018-02-18 19:00:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:00:08 --> Config Class Initialized
INFO - 2018-02-18 19:00:08 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:00:08 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:00:08 --> Utf8 Class Initialized
INFO - 2018-02-18 19:00:09 --> URI Class Initialized
INFO - 2018-02-18 19:00:09 --> Router Class Initialized
INFO - 2018-02-18 19:00:09 --> Output Class Initialized
INFO - 2018-02-18 19:00:09 --> Security Class Initialized
DEBUG - 2018-02-18 19:00:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:00:09 --> Input Class Initialized
INFO - 2018-02-18 19:00:09 --> Language Class Initialized
INFO - 2018-02-18 19:00:09 --> Loader Class Initialized
INFO - 2018-02-18 19:00:09 --> Helper loaded: url_helper
INFO - 2018-02-18 19:00:09 --> Helper loaded: form_helper
INFO - 2018-02-18 19:00:09 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:00:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:00:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:00:09 --> Form Validation Class Initialized
INFO - 2018-02-18 19:00:09 --> Model Class Initialized
INFO - 2018-02-18 19:00:09 --> Controller Class Initialized
INFO - 2018-02-18 19:00:09 --> Model Class Initialized
INFO - 2018-02-18 19:00:09 --> Model Class Initialized
INFO - 2018-02-18 19:00:09 --> Model Class Initialized
INFO - 2018-02-18 19:00:09 --> Model Class Initialized
INFO - 2018-02-18 19:00:09 --> Model Class Initialized
DEBUG - 2018-02-18 19:00:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:00:09 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 19:00:09 --> Final output sent to browser
DEBUG - 2018-02-18 19:00:09 --> Total execution time: 0.0793
INFO - 2018-02-18 19:00:09 --> Config Class Initialized
INFO - 2018-02-18 19:00:09 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:00:09 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:00:09 --> Utf8 Class Initialized
INFO - 2018-02-18 19:00:09 --> URI Class Initialized
INFO - 2018-02-18 19:00:09 --> Router Class Initialized
INFO - 2018-02-18 19:00:09 --> Output Class Initialized
INFO - 2018-02-18 19:00:09 --> Security Class Initialized
DEBUG - 2018-02-18 19:00:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:00:09 --> Input Class Initialized
INFO - 2018-02-18 19:00:09 --> Language Class Initialized
INFO - 2018-02-18 19:00:09 --> Loader Class Initialized
INFO - 2018-02-18 19:00:09 --> Helper loaded: url_helper
INFO - 2018-02-18 19:00:09 --> Helper loaded: form_helper
INFO - 2018-02-18 19:00:09 --> Config Class Initialized
INFO - 2018-02-18 19:00:09 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:00:09 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:00:09 --> Utf8 Class Initialized
INFO - 2018-02-18 19:00:09 --> URI Class Initialized
INFO - 2018-02-18 19:00:09 --> Database Driver Class Initialized
INFO - 2018-02-18 19:00:09 --> Router Class Initialized
INFO - 2018-02-18 19:00:09 --> Output Class Initialized
INFO - 2018-02-18 19:00:09 --> Security Class Initialized
DEBUG - 2018-02-18 19:00:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-18 19:00:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:00:09 --> Input Class Initialized
INFO - 2018-02-18 19:00:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:00:09 --> Language Class Initialized
INFO - 2018-02-18 19:00:09 --> Form Validation Class Initialized
INFO - 2018-02-18 19:00:09 --> Model Class Initialized
INFO - 2018-02-18 19:00:09 --> Controller Class Initialized
INFO - 2018-02-18 19:00:09 --> Loader Class Initialized
INFO - 2018-02-18 19:00:09 --> Helper loaded: url_helper
INFO - 2018-02-18 19:00:09 --> Model Class Initialized
INFO - 2018-02-18 19:00:09 --> Model Class Initialized
INFO - 2018-02-18 19:00:09 --> Helper loaded: form_helper
INFO - 2018-02-18 19:00:09 --> Model Class Initialized
INFO - 2018-02-18 19:00:09 --> Model Class Initialized
INFO - 2018-02-18 19:00:09 --> Model Class Initialized
DEBUG - 2018-02-18 19:00:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:00:09 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:00:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:00:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:00:09 --> Form Validation Class Initialized
INFO - 2018-02-18 19:00:09 --> Model Class Initialized
INFO - 2018-02-18 19:00:09 --> Controller Class Initialized
INFO - 2018-02-18 19:00:09 --> Model Class Initialized
INFO - 2018-02-18 19:00:09 --> Model Class Initialized
INFO - 2018-02-18 19:00:09 --> Model Class Initialized
INFO - 2018-02-18 19:00:09 --> Model Class Initialized
INFO - 2018-02-18 19:00:09 --> Model Class Initialized
DEBUG - 2018-02-18 19:00:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:00:09 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 19:00:09 --> Final output sent to browser
DEBUG - 2018-02-18 19:00:09 --> Total execution time: 0.0532
INFO - 2018-02-18 19:00:09 --> Config Class Initialized
INFO - 2018-02-18 19:00:09 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:00:09 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:00:09 --> Utf8 Class Initialized
INFO - 2018-02-18 19:00:09 --> URI Class Initialized
INFO - 2018-02-18 19:00:09 --> Router Class Initialized
INFO - 2018-02-18 19:00:09 --> Output Class Initialized
INFO - 2018-02-18 19:00:09 --> Security Class Initialized
DEBUG - 2018-02-18 19:00:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:00:09 --> Input Class Initialized
INFO - 2018-02-18 19:00:09 --> Language Class Initialized
INFO - 2018-02-18 19:00:09 --> Loader Class Initialized
INFO - 2018-02-18 19:00:09 --> Helper loaded: url_helper
INFO - 2018-02-18 19:00:09 --> Helper loaded: form_helper
INFO - 2018-02-18 19:00:09 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:00:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:00:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:00:09 --> Form Validation Class Initialized
INFO - 2018-02-18 19:00:09 --> Model Class Initialized
INFO - 2018-02-18 19:00:09 --> Controller Class Initialized
INFO - 2018-02-18 19:00:09 --> Model Class Initialized
INFO - 2018-02-18 19:00:09 --> Model Class Initialized
INFO - 2018-02-18 19:00:09 --> Model Class Initialized
INFO - 2018-02-18 19:00:09 --> Model Class Initialized
INFO - 2018-02-18 19:00:09 --> Model Class Initialized
DEBUG - 2018-02-18 19:00:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:00:11 --> Config Class Initialized
INFO - 2018-02-18 19:00:11 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:00:11 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:00:11 --> Utf8 Class Initialized
INFO - 2018-02-18 19:00:11 --> URI Class Initialized
INFO - 2018-02-18 19:00:11 --> Router Class Initialized
INFO - 2018-02-18 19:00:11 --> Output Class Initialized
INFO - 2018-02-18 19:00:11 --> Security Class Initialized
DEBUG - 2018-02-18 19:00:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:00:11 --> Input Class Initialized
INFO - 2018-02-18 19:00:11 --> Language Class Initialized
INFO - 2018-02-18 19:00:11 --> Loader Class Initialized
INFO - 2018-02-18 19:00:11 --> Helper loaded: url_helper
INFO - 2018-02-18 19:00:11 --> Helper loaded: form_helper
INFO - 2018-02-18 19:00:11 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:00:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:00:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:00:11 --> Form Validation Class Initialized
INFO - 2018-02-18 19:00:11 --> Model Class Initialized
INFO - 2018-02-18 19:00:11 --> Controller Class Initialized
INFO - 2018-02-18 19:00:11 --> Model Class Initialized
INFO - 2018-02-18 19:00:11 --> Model Class Initialized
INFO - 2018-02-18 19:00:11 --> Model Class Initialized
INFO - 2018-02-18 19:00:11 --> Model Class Initialized
INFO - 2018-02-18 19:00:11 --> Model Class Initialized
DEBUG - 2018-02-18 19:00:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:00:11 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 19:00:11 --> Final output sent to browser
DEBUG - 2018-02-18 19:00:11 --> Total execution time: 0.0477
INFO - 2018-02-18 19:00:11 --> Config Class Initialized
INFO - 2018-02-18 19:00:11 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:00:11 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:00:11 --> Utf8 Class Initialized
INFO - 2018-02-18 19:00:11 --> URI Class Initialized
INFO - 2018-02-18 19:00:11 --> Router Class Initialized
INFO - 2018-02-18 19:00:11 --> Output Class Initialized
INFO - 2018-02-18 19:00:11 --> Security Class Initialized
DEBUG - 2018-02-18 19:00:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:00:11 --> Input Class Initialized
INFO - 2018-02-18 19:00:11 --> Language Class Initialized
INFO - 2018-02-18 19:00:11 --> Loader Class Initialized
INFO - 2018-02-18 19:00:11 --> Helper loaded: url_helper
INFO - 2018-02-18 19:00:11 --> Helper loaded: form_helper
INFO - 2018-02-18 19:00:11 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:00:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:00:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:00:11 --> Form Validation Class Initialized
INFO - 2018-02-18 19:00:11 --> Model Class Initialized
INFO - 2018-02-18 19:00:11 --> Controller Class Initialized
INFO - 2018-02-18 19:00:11 --> Model Class Initialized
INFO - 2018-02-18 19:00:11 --> Model Class Initialized
INFO - 2018-02-18 19:00:11 --> Model Class Initialized
INFO - 2018-02-18 19:00:11 --> Model Class Initialized
INFO - 2018-02-18 19:00:11 --> Model Class Initialized
DEBUG - 2018-02-18 19:00:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:00:15 --> Config Class Initialized
INFO - 2018-02-18 19:00:15 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:00:15 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:00:15 --> Utf8 Class Initialized
INFO - 2018-02-18 19:00:15 --> URI Class Initialized
INFO - 2018-02-18 19:00:15 --> Router Class Initialized
INFO - 2018-02-18 19:00:15 --> Output Class Initialized
INFO - 2018-02-18 19:00:15 --> Security Class Initialized
DEBUG - 2018-02-18 19:00:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:00:15 --> Input Class Initialized
INFO - 2018-02-18 19:00:15 --> Language Class Initialized
INFO - 2018-02-18 19:00:15 --> Loader Class Initialized
INFO - 2018-02-18 19:00:15 --> Helper loaded: url_helper
INFO - 2018-02-18 19:00:15 --> Helper loaded: form_helper
INFO - 2018-02-18 19:00:15 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:00:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:00:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:00:15 --> Form Validation Class Initialized
INFO - 2018-02-18 19:00:15 --> Model Class Initialized
INFO - 2018-02-18 19:00:15 --> Controller Class Initialized
INFO - 2018-02-18 19:00:15 --> Model Class Initialized
INFO - 2018-02-18 19:00:15 --> Model Class Initialized
INFO - 2018-02-18 19:00:15 --> Model Class Initialized
INFO - 2018-02-18 19:00:15 --> Model Class Initialized
INFO - 2018-02-18 19:00:15 --> Model Class Initialized
DEBUG - 2018-02-18 19:00:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:00:15 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 19:00:15 --> Final output sent to browser
DEBUG - 2018-02-18 19:00:15 --> Total execution time: 0.0670
INFO - 2018-02-18 19:00:15 --> Config Class Initialized
INFO - 2018-02-18 19:00:15 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:00:15 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:00:15 --> Utf8 Class Initialized
INFO - 2018-02-18 19:00:15 --> URI Class Initialized
INFO - 2018-02-18 19:00:15 --> Router Class Initialized
INFO - 2018-02-18 19:00:15 --> Output Class Initialized
INFO - 2018-02-18 19:00:15 --> Security Class Initialized
DEBUG - 2018-02-18 19:00:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:00:15 --> Input Class Initialized
INFO - 2018-02-18 19:00:15 --> Language Class Initialized
INFO - 2018-02-18 19:00:15 --> Loader Class Initialized
INFO - 2018-02-18 19:00:15 --> Helper loaded: url_helper
INFO - 2018-02-18 19:00:15 --> Helper loaded: form_helper
INFO - 2018-02-18 19:00:15 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:00:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:00:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:00:15 --> Form Validation Class Initialized
INFO - 2018-02-18 19:00:15 --> Model Class Initialized
INFO - 2018-02-18 19:00:15 --> Controller Class Initialized
INFO - 2018-02-18 19:00:15 --> Model Class Initialized
INFO - 2018-02-18 19:00:15 --> Model Class Initialized
INFO - 2018-02-18 19:00:15 --> Model Class Initialized
INFO - 2018-02-18 19:00:15 --> Model Class Initialized
INFO - 2018-02-18 19:00:15 --> Model Class Initialized
DEBUG - 2018-02-18 19:00:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:00:19 --> Config Class Initialized
INFO - 2018-02-18 19:00:19 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:00:19 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:00:19 --> Utf8 Class Initialized
INFO - 2018-02-18 19:00:19 --> URI Class Initialized
INFO - 2018-02-18 19:00:19 --> Router Class Initialized
INFO - 2018-02-18 19:00:19 --> Output Class Initialized
INFO - 2018-02-18 19:00:19 --> Security Class Initialized
DEBUG - 2018-02-18 19:00:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:00:19 --> Input Class Initialized
INFO - 2018-02-18 19:00:19 --> Language Class Initialized
INFO - 2018-02-18 19:00:19 --> Loader Class Initialized
INFO - 2018-02-18 19:00:19 --> Helper loaded: url_helper
INFO - 2018-02-18 19:00:19 --> Helper loaded: form_helper
INFO - 2018-02-18 19:00:19 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:00:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:00:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:00:19 --> Form Validation Class Initialized
INFO - 2018-02-18 19:00:19 --> Model Class Initialized
INFO - 2018-02-18 19:00:19 --> Controller Class Initialized
INFO - 2018-02-18 19:00:19 --> Model Class Initialized
INFO - 2018-02-18 19:00:19 --> Model Class Initialized
INFO - 2018-02-18 19:00:19 --> Model Class Initialized
INFO - 2018-02-18 19:00:19 --> Model Class Initialized
INFO - 2018-02-18 19:00:19 --> Model Class Initialized
DEBUG - 2018-02-18 19:00:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:00:19 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 19:00:19 --> Final output sent to browser
DEBUG - 2018-02-18 19:00:19 --> Total execution time: 0.0795
INFO - 2018-02-18 19:00:19 --> Config Class Initialized
INFO - 2018-02-18 19:00:19 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:00:19 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:00:19 --> Utf8 Class Initialized
INFO - 2018-02-18 19:00:19 --> URI Class Initialized
INFO - 2018-02-18 19:00:19 --> Router Class Initialized
INFO - 2018-02-18 19:00:19 --> Output Class Initialized
INFO - 2018-02-18 19:00:19 --> Security Class Initialized
DEBUG - 2018-02-18 19:00:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:00:19 --> Input Class Initialized
INFO - 2018-02-18 19:00:19 --> Language Class Initialized
INFO - 2018-02-18 19:00:19 --> Loader Class Initialized
INFO - 2018-02-18 19:00:19 --> Helper loaded: url_helper
INFO - 2018-02-18 19:00:19 --> Helper loaded: form_helper
INFO - 2018-02-18 19:00:19 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:00:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:00:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:00:19 --> Form Validation Class Initialized
INFO - 2018-02-18 19:00:19 --> Model Class Initialized
INFO - 2018-02-18 19:00:19 --> Controller Class Initialized
INFO - 2018-02-18 19:00:19 --> Model Class Initialized
INFO - 2018-02-18 19:00:19 --> Model Class Initialized
INFO - 2018-02-18 19:00:19 --> Model Class Initialized
INFO - 2018-02-18 19:00:19 --> Model Class Initialized
INFO - 2018-02-18 19:00:19 --> Model Class Initialized
DEBUG - 2018-02-18 19:00:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:00:23 --> Config Class Initialized
INFO - 2018-02-18 19:00:23 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:00:23 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:00:23 --> Utf8 Class Initialized
INFO - 2018-02-18 19:00:23 --> URI Class Initialized
INFO - 2018-02-18 19:00:23 --> Router Class Initialized
INFO - 2018-02-18 19:00:23 --> Output Class Initialized
INFO - 2018-02-18 19:00:23 --> Security Class Initialized
DEBUG - 2018-02-18 19:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:00:23 --> Input Class Initialized
INFO - 2018-02-18 19:00:23 --> Language Class Initialized
INFO - 2018-02-18 19:00:23 --> Loader Class Initialized
INFO - 2018-02-18 19:00:23 --> Helper loaded: url_helper
INFO - 2018-02-18 19:00:23 --> Helper loaded: form_helper
INFO - 2018-02-18 19:00:23 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:00:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:00:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:00:23 --> Form Validation Class Initialized
INFO - 2018-02-18 19:00:23 --> Model Class Initialized
INFO - 2018-02-18 19:00:23 --> Controller Class Initialized
INFO - 2018-02-18 19:00:23 --> Model Class Initialized
INFO - 2018-02-18 19:00:23 --> Model Class Initialized
INFO - 2018-02-18 19:00:23 --> Model Class Initialized
INFO - 2018-02-18 19:00:23 --> Model Class Initialized
INFO - 2018-02-18 19:00:23 --> Model Class Initialized
DEBUG - 2018-02-18 19:00:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:00:23 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 19:00:23 --> Final output sent to browser
DEBUG - 2018-02-18 19:00:23 --> Total execution time: 0.0660
INFO - 2018-02-18 19:00:23 --> Config Class Initialized
INFO - 2018-02-18 19:00:23 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:00:23 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:00:23 --> Utf8 Class Initialized
INFO - 2018-02-18 19:00:23 --> URI Class Initialized
INFO - 2018-02-18 19:00:23 --> Router Class Initialized
INFO - 2018-02-18 19:00:23 --> Output Class Initialized
INFO - 2018-02-18 19:00:23 --> Security Class Initialized
DEBUG - 2018-02-18 19:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:00:23 --> Input Class Initialized
INFO - 2018-02-18 19:00:23 --> Language Class Initialized
INFO - 2018-02-18 19:00:23 --> Loader Class Initialized
INFO - 2018-02-18 19:00:23 --> Helper loaded: url_helper
INFO - 2018-02-18 19:00:23 --> Helper loaded: form_helper
INFO - 2018-02-18 19:00:23 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:00:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:00:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:00:23 --> Form Validation Class Initialized
INFO - 2018-02-18 19:00:23 --> Model Class Initialized
INFO - 2018-02-18 19:00:23 --> Controller Class Initialized
INFO - 2018-02-18 19:00:23 --> Model Class Initialized
INFO - 2018-02-18 19:00:23 --> Model Class Initialized
INFO - 2018-02-18 19:00:23 --> Model Class Initialized
INFO - 2018-02-18 19:00:23 --> Model Class Initialized
INFO - 2018-02-18 19:00:23 --> Model Class Initialized
DEBUG - 2018-02-18 19:00:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:00:57 --> Config Class Initialized
INFO - 2018-02-18 19:00:57 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:00:57 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:00:57 --> Utf8 Class Initialized
INFO - 2018-02-18 19:00:57 --> URI Class Initialized
INFO - 2018-02-18 19:00:57 --> Router Class Initialized
INFO - 2018-02-18 19:00:57 --> Output Class Initialized
INFO - 2018-02-18 19:00:57 --> Security Class Initialized
DEBUG - 2018-02-18 19:00:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:00:57 --> Input Class Initialized
INFO - 2018-02-18 19:00:57 --> Language Class Initialized
INFO - 2018-02-18 19:00:57 --> Loader Class Initialized
INFO - 2018-02-18 19:00:57 --> Helper loaded: url_helper
INFO - 2018-02-18 19:00:57 --> Helper loaded: form_helper
INFO - 2018-02-18 19:00:57 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:00:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:00:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:00:57 --> Form Validation Class Initialized
INFO - 2018-02-18 19:00:57 --> Model Class Initialized
INFO - 2018-02-18 19:00:57 --> Controller Class Initialized
INFO - 2018-02-18 19:00:57 --> Model Class Initialized
INFO - 2018-02-18 19:00:57 --> Model Class Initialized
INFO - 2018-02-18 19:00:57 --> Model Class Initialized
INFO - 2018-02-18 19:00:57 --> Model Class Initialized
INFO - 2018-02-18 19:00:57 --> Model Class Initialized
DEBUG - 2018-02-18 19:00:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:01:11 --> Config Class Initialized
INFO - 2018-02-18 19:01:11 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:01:11 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:01:11 --> Utf8 Class Initialized
INFO - 2018-02-18 19:01:11 --> URI Class Initialized
INFO - 2018-02-18 19:01:11 --> Router Class Initialized
INFO - 2018-02-18 19:01:11 --> Output Class Initialized
INFO - 2018-02-18 19:01:11 --> Security Class Initialized
DEBUG - 2018-02-18 19:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:01:11 --> Input Class Initialized
INFO - 2018-02-18 19:01:11 --> Language Class Initialized
INFO - 2018-02-18 19:01:11 --> Loader Class Initialized
INFO - 2018-02-18 19:01:11 --> Helper loaded: url_helper
INFO - 2018-02-18 19:01:11 --> Helper loaded: form_helper
INFO - 2018-02-18 19:01:11 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:01:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:01:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:01:11 --> Form Validation Class Initialized
INFO - 2018-02-18 19:01:11 --> Model Class Initialized
INFO - 2018-02-18 19:01:11 --> Controller Class Initialized
INFO - 2018-02-18 19:01:11 --> Model Class Initialized
INFO - 2018-02-18 19:01:11 --> Model Class Initialized
INFO - 2018-02-18 19:01:11 --> Model Class Initialized
INFO - 2018-02-18 19:01:11 --> Model Class Initialized
INFO - 2018-02-18 19:01:11 --> Model Class Initialized
DEBUG - 2018-02-18 19:01:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:01:29 --> Config Class Initialized
INFO - 2018-02-18 19:01:29 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:01:29 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:01:29 --> Utf8 Class Initialized
INFO - 2018-02-18 19:01:29 --> URI Class Initialized
INFO - 2018-02-18 19:01:29 --> Router Class Initialized
INFO - 2018-02-18 19:01:29 --> Output Class Initialized
INFO - 2018-02-18 19:01:29 --> Security Class Initialized
DEBUG - 2018-02-18 19:01:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:01:29 --> Input Class Initialized
INFO - 2018-02-18 19:01:29 --> Language Class Initialized
INFO - 2018-02-18 19:01:29 --> Loader Class Initialized
INFO - 2018-02-18 19:01:29 --> Helper loaded: url_helper
INFO - 2018-02-18 19:01:29 --> Helper loaded: form_helper
INFO - 2018-02-18 19:01:29 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:01:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:01:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:01:29 --> Form Validation Class Initialized
INFO - 2018-02-18 19:01:29 --> Model Class Initialized
INFO - 2018-02-18 19:01:29 --> Controller Class Initialized
INFO - 2018-02-18 19:01:29 --> Model Class Initialized
INFO - 2018-02-18 19:01:29 --> Model Class Initialized
INFO - 2018-02-18 19:01:29 --> Model Class Initialized
INFO - 2018-02-18 19:01:29 --> Model Class Initialized
INFO - 2018-02-18 19:01:29 --> Model Class Initialized
DEBUG - 2018-02-18 19:01:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:02:04 --> Config Class Initialized
INFO - 2018-02-18 19:02:04 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:02:04 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:02:04 --> Utf8 Class Initialized
INFO - 2018-02-18 19:02:04 --> URI Class Initialized
INFO - 2018-02-18 19:02:04 --> Router Class Initialized
INFO - 2018-02-18 19:02:04 --> Output Class Initialized
INFO - 2018-02-18 19:02:04 --> Security Class Initialized
DEBUG - 2018-02-18 19:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:02:04 --> Input Class Initialized
INFO - 2018-02-18 19:02:04 --> Language Class Initialized
INFO - 2018-02-18 19:02:04 --> Loader Class Initialized
INFO - 2018-02-18 19:02:04 --> Helper loaded: url_helper
INFO - 2018-02-18 19:02:04 --> Helper loaded: form_helper
INFO - 2018-02-18 19:02:04 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:02:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:02:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:02:04 --> Form Validation Class Initialized
INFO - 2018-02-18 19:02:04 --> Model Class Initialized
INFO - 2018-02-18 19:02:04 --> Controller Class Initialized
INFO - 2018-02-18 19:02:04 --> Model Class Initialized
INFO - 2018-02-18 19:02:04 --> Model Class Initialized
INFO - 2018-02-18 19:02:04 --> Model Class Initialized
INFO - 2018-02-18 19:02:04 --> Model Class Initialized
INFO - 2018-02-18 19:02:04 --> Model Class Initialized
DEBUG - 2018-02-18 19:02:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:02:04 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 19:02:04 --> Final output sent to browser
DEBUG - 2018-02-18 19:02:04 --> Total execution time: 0.0539
INFO - 2018-02-18 19:02:04 --> Config Class Initialized
INFO - 2018-02-18 19:02:04 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:02:04 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:02:04 --> Utf8 Class Initialized
INFO - 2018-02-18 19:02:04 --> URI Class Initialized
INFO - 2018-02-18 19:02:04 --> Router Class Initialized
INFO - 2018-02-18 19:02:04 --> Output Class Initialized
INFO - 2018-02-18 19:02:04 --> Security Class Initialized
DEBUG - 2018-02-18 19:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:02:04 --> Input Class Initialized
INFO - 2018-02-18 19:02:04 --> Language Class Initialized
INFO - 2018-02-18 19:02:04 --> Loader Class Initialized
INFO - 2018-02-18 19:02:04 --> Helper loaded: url_helper
INFO - 2018-02-18 19:02:04 --> Helper loaded: form_helper
INFO - 2018-02-18 19:02:04 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:02:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:02:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:02:04 --> Form Validation Class Initialized
INFO - 2018-02-18 19:02:04 --> Model Class Initialized
INFO - 2018-02-18 19:02:04 --> Controller Class Initialized
INFO - 2018-02-18 19:02:04 --> Model Class Initialized
INFO - 2018-02-18 19:02:04 --> Model Class Initialized
INFO - 2018-02-18 19:02:04 --> Model Class Initialized
INFO - 2018-02-18 19:02:04 --> Model Class Initialized
INFO - 2018-02-18 19:02:04 --> Model Class Initialized
DEBUG - 2018-02-18 19:02:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:02:40 --> Config Class Initialized
INFO - 2018-02-18 19:02:40 --> Config Class Initialized
INFO - 2018-02-18 19:02:40 --> Config Class Initialized
INFO - 2018-02-18 19:02:40 --> Hooks Class Initialized
INFO - 2018-02-18 19:02:40 --> Hooks Class Initialized
INFO - 2018-02-18 19:02:40 --> Config Class Initialized
INFO - 2018-02-18 19:02:40 --> Hooks Class Initialized
INFO - 2018-02-18 19:02:40 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:02:40 --> UTF-8 Support Enabled
DEBUG - 2018-02-18 19:02:40 --> UTF-8 Support Enabled
DEBUG - 2018-02-18 19:02:40 --> UTF-8 Support Enabled
DEBUG - 2018-02-18 19:02:40 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:02:40 --> Utf8 Class Initialized
INFO - 2018-02-18 19:02:40 --> Utf8 Class Initialized
INFO - 2018-02-18 19:02:40 --> Utf8 Class Initialized
INFO - 2018-02-18 19:02:40 --> Utf8 Class Initialized
INFO - 2018-02-18 19:02:40 --> URI Class Initialized
INFO - 2018-02-18 19:02:40 --> URI Class Initialized
INFO - 2018-02-18 19:02:40 --> URI Class Initialized
INFO - 2018-02-18 19:02:40 --> URI Class Initialized
INFO - 2018-02-18 19:02:40 --> Router Class Initialized
INFO - 2018-02-18 19:02:40 --> Router Class Initialized
INFO - 2018-02-18 19:02:40 --> Router Class Initialized
INFO - 2018-02-18 19:02:40 --> Router Class Initialized
INFO - 2018-02-18 19:02:40 --> Output Class Initialized
INFO - 2018-02-18 19:02:40 --> Output Class Initialized
INFO - 2018-02-18 19:02:40 --> Output Class Initialized
INFO - 2018-02-18 19:02:40 --> Output Class Initialized
INFO - 2018-02-18 19:02:40 --> Security Class Initialized
INFO - 2018-02-18 19:02:40 --> Security Class Initialized
INFO - 2018-02-18 19:02:40 --> Security Class Initialized
INFO - 2018-02-18 19:02:40 --> Security Class Initialized
DEBUG - 2018-02-18 19:02:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:02:40 --> Input Class Initialized
DEBUG - 2018-02-18 19:02:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-18 19:02:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-18 19:02:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:02:40 --> Input Class Initialized
INFO - 2018-02-18 19:02:40 --> Input Class Initialized
INFO - 2018-02-18 19:02:40 --> Input Class Initialized
INFO - 2018-02-18 19:02:40 --> Language Class Initialized
INFO - 2018-02-18 19:02:40 --> Language Class Initialized
INFO - 2018-02-18 19:02:40 --> Language Class Initialized
INFO - 2018-02-18 19:02:40 --> Language Class Initialized
INFO - 2018-02-18 19:02:40 --> Config Class Initialized
INFO - 2018-02-18 19:02:40 --> Hooks Class Initialized
INFO - 2018-02-18 19:02:40 --> Config Class Initialized
INFO - 2018-02-18 19:02:40 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:02:40 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:02:40 --> Utf8 Class Initialized
DEBUG - 2018-02-18 19:02:40 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:02:40 --> Utf8 Class Initialized
INFO - 2018-02-18 19:02:40 --> URI Class Initialized
INFO - 2018-02-18 19:02:40 --> URI Class Initialized
INFO - 2018-02-18 19:02:40 --> Router Class Initialized
INFO - 2018-02-18 19:02:40 --> Router Class Initialized
INFO - 2018-02-18 19:02:40 --> Output Class Initialized
INFO - 2018-02-18 19:02:40 --> Output Class Initialized
INFO - 2018-02-18 19:02:40 --> Security Class Initialized
INFO - 2018-02-18 19:02:40 --> Security Class Initialized
DEBUG - 2018-02-18 19:02:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:02:40 --> Input Class Initialized
DEBUG - 2018-02-18 19:02:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:02:40 --> Input Class Initialized
INFO - 2018-02-18 19:02:40 --> Language Class Initialized
INFO - 2018-02-18 19:02:40 --> Language Class Initialized
ERROR - 2018-02-18 19:02:40 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-18 19:02:40 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-18 19:02:40 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-18 19:02:40 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-18 19:02:40 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-18 19:02:40 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-18 19:02:40 --> Config Class Initialized
INFO - 2018-02-18 19:02:40 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:02:40 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:02:40 --> Utf8 Class Initialized
INFO - 2018-02-18 19:02:40 --> URI Class Initialized
INFO - 2018-02-18 19:02:40 --> Router Class Initialized
INFO - 2018-02-18 19:02:40 --> Output Class Initialized
INFO - 2018-02-18 19:02:40 --> Security Class Initialized
DEBUG - 2018-02-18 19:02:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:02:40 --> Input Class Initialized
INFO - 2018-02-18 19:02:40 --> Language Class Initialized
ERROR - 2018-02-18 19:02:40 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-18 19:03:16 --> Config Class Initialized
INFO - 2018-02-18 19:03:16 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:03:16 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:03:16 --> Utf8 Class Initialized
INFO - 2018-02-18 19:03:16 --> URI Class Initialized
INFO - 2018-02-18 19:03:16 --> Router Class Initialized
INFO - 2018-02-18 19:03:16 --> Output Class Initialized
INFO - 2018-02-18 19:03:16 --> Security Class Initialized
DEBUG - 2018-02-18 19:03:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:03:16 --> Input Class Initialized
INFO - 2018-02-18 19:03:16 --> Language Class Initialized
INFO - 2018-02-18 19:03:16 --> Loader Class Initialized
INFO - 2018-02-18 19:03:16 --> Helper loaded: url_helper
INFO - 2018-02-18 19:03:16 --> Helper loaded: form_helper
INFO - 2018-02-18 19:03:16 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:03:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:03:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:03:16 --> Form Validation Class Initialized
INFO - 2018-02-18 19:03:16 --> Model Class Initialized
INFO - 2018-02-18 19:03:16 --> Controller Class Initialized
INFO - 2018-02-18 19:03:16 --> Model Class Initialized
INFO - 2018-02-18 19:03:16 --> Model Class Initialized
INFO - 2018-02-18 19:03:16 --> Model Class Initialized
INFO - 2018-02-18 19:03:16 --> Model Class Initialized
INFO - 2018-02-18 19:03:16 --> Model Class Initialized
DEBUG - 2018-02-18 19:03:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:03:16 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 19:03:16 --> Final output sent to browser
DEBUG - 2018-02-18 19:03:16 --> Total execution time: 0.0721
INFO - 2018-02-18 19:03:16 --> Config Class Initialized
INFO - 2018-02-18 19:03:16 --> Hooks Class Initialized
INFO - 2018-02-18 19:03:16 --> Config Class Initialized
INFO - 2018-02-18 19:03:16 --> Config Class Initialized
INFO - 2018-02-18 19:03:16 --> Hooks Class Initialized
INFO - 2018-02-18 19:03:16 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:03:16 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:03:16 --> Utf8 Class Initialized
INFO - 2018-02-18 19:03:16 --> URI Class Initialized
DEBUG - 2018-02-18 19:03:16 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:03:16 --> Utf8 Class Initialized
DEBUG - 2018-02-18 19:03:16 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:03:16 --> Utf8 Class Initialized
INFO - 2018-02-18 19:03:16 --> URI Class Initialized
INFO - 2018-02-18 19:03:16 --> URI Class Initialized
INFO - 2018-02-18 19:03:16 --> Router Class Initialized
INFO - 2018-02-18 19:03:16 --> Router Class Initialized
INFO - 2018-02-18 19:03:16 --> Router Class Initialized
INFO - 2018-02-18 19:03:16 --> Output Class Initialized
INFO - 2018-02-18 19:03:16 --> Config Class Initialized
INFO - 2018-02-18 19:03:16 --> Hooks Class Initialized
INFO - 2018-02-18 19:03:16 --> Output Class Initialized
INFO - 2018-02-18 19:03:16 --> Security Class Initialized
INFO - 2018-02-18 19:03:16 --> Output Class Initialized
DEBUG - 2018-02-18 19:03:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:03:16 --> Security Class Initialized
INFO - 2018-02-18 19:03:16 --> Input Class Initialized
INFO - 2018-02-18 19:03:16 --> Security Class Initialized
DEBUG - 2018-02-18 19:03:16 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:03:16 --> Language Class Initialized
INFO - 2018-02-18 19:03:16 --> Utf8 Class Initialized
DEBUG - 2018-02-18 19:03:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:03:16 --> Input Class Initialized
DEBUG - 2018-02-18 19:03:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:03:16 --> URI Class Initialized
INFO - 2018-02-18 19:03:16 --> Input Class Initialized
ERROR - 2018-02-18 19:03:16 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-18 19:03:16 --> Language Class Initialized
INFO - 2018-02-18 19:03:16 --> Language Class Initialized
ERROR - 2018-02-18 19:03:16 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-18 19:03:16 --> Router Class Initialized
ERROR - 2018-02-18 19:03:16 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-18 19:03:16 --> Output Class Initialized
INFO - 2018-02-18 19:03:16 --> Security Class Initialized
DEBUG - 2018-02-18 19:03:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:03:16 --> Input Class Initialized
INFO - 2018-02-18 19:03:16 --> Language Class Initialized
ERROR - 2018-02-18 19:03:16 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-18 19:03:16 --> Config Class Initialized
INFO - 2018-02-18 19:03:16 --> Hooks Class Initialized
INFO - 2018-02-18 19:03:16 --> Config Class Initialized
INFO - 2018-02-18 19:03:16 --> Hooks Class Initialized
INFO - 2018-02-18 19:03:16 --> Config Class Initialized
INFO - 2018-02-18 19:03:16 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:03:16 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:03:16 --> Utf8 Class Initialized
DEBUG - 2018-02-18 19:03:16 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:03:16 --> Utf8 Class Initialized
DEBUG - 2018-02-18 19:03:16 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:03:16 --> URI Class Initialized
INFO - 2018-02-18 19:03:16 --> Utf8 Class Initialized
INFO - 2018-02-18 19:03:16 --> URI Class Initialized
INFO - 2018-02-18 19:03:16 --> Router Class Initialized
INFO - 2018-02-18 19:03:16 --> URI Class Initialized
INFO - 2018-02-18 19:03:16 --> Router Class Initialized
INFO - 2018-02-18 19:03:16 --> Output Class Initialized
INFO - 2018-02-18 19:03:16 --> Router Class Initialized
INFO - 2018-02-18 19:03:16 --> Output Class Initialized
INFO - 2018-02-18 19:03:16 --> Security Class Initialized
INFO - 2018-02-18 19:03:16 --> Output Class Initialized
INFO - 2018-02-18 19:03:16 --> Security Class Initialized
DEBUG - 2018-02-18 19:03:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:03:16 --> Input Class Initialized
INFO - 2018-02-18 19:03:16 --> Language Class Initialized
DEBUG - 2018-02-18 19:03:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:03:16 --> Input Class Initialized
INFO - 2018-02-18 19:03:16 --> Security Class Initialized
INFO - 2018-02-18 19:03:16 --> Language Class Initialized
ERROR - 2018-02-18 19:03:16 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-02-18 19:03:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:03:16 --> Input Class Initialized
ERROR - 2018-02-18 19:03:16 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-18 19:03:16 --> Language Class Initialized
ERROR - 2018-02-18 19:03:16 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-18 19:03:16 --> Config Class Initialized
INFO - 2018-02-18 19:03:16 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:03:16 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:03:16 --> Utf8 Class Initialized
INFO - 2018-02-18 19:03:16 --> URI Class Initialized
INFO - 2018-02-18 19:03:16 --> Router Class Initialized
INFO - 2018-02-18 19:03:16 --> Output Class Initialized
INFO - 2018-02-18 19:03:16 --> Security Class Initialized
DEBUG - 2018-02-18 19:03:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:03:16 --> Input Class Initialized
INFO - 2018-02-18 19:03:16 --> Language Class Initialized
INFO - 2018-02-18 19:03:16 --> Loader Class Initialized
INFO - 2018-02-18 19:03:16 --> Helper loaded: url_helper
INFO - 2018-02-18 19:03:16 --> Helper loaded: form_helper
INFO - 2018-02-18 19:03:17 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:03:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:03:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:03:17 --> Form Validation Class Initialized
INFO - 2018-02-18 19:03:17 --> Model Class Initialized
INFO - 2018-02-18 19:03:17 --> Controller Class Initialized
INFO - 2018-02-18 19:03:17 --> Model Class Initialized
INFO - 2018-02-18 19:03:17 --> Model Class Initialized
INFO - 2018-02-18 19:03:17 --> Model Class Initialized
INFO - 2018-02-18 19:03:17 --> Model Class Initialized
INFO - 2018-02-18 19:03:17 --> Model Class Initialized
DEBUG - 2018-02-18 19:03:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:03:17 --> Config Class Initialized
INFO - 2018-02-18 19:03:17 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:03:17 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:03:17 --> Utf8 Class Initialized
INFO - 2018-02-18 19:03:17 --> URI Class Initialized
INFO - 2018-02-18 19:03:17 --> Router Class Initialized
INFO - 2018-02-18 19:03:17 --> Output Class Initialized
INFO - 2018-02-18 19:03:17 --> Security Class Initialized
DEBUG - 2018-02-18 19:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:03:17 --> Input Class Initialized
INFO - 2018-02-18 19:03:17 --> Language Class Initialized
INFO - 2018-02-18 19:03:17 --> Loader Class Initialized
INFO - 2018-02-18 19:03:17 --> Helper loaded: url_helper
INFO - 2018-02-18 19:03:17 --> Helper loaded: form_helper
INFO - 2018-02-18 19:03:17 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:03:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:03:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:03:17 --> Form Validation Class Initialized
INFO - 2018-02-18 19:03:17 --> Model Class Initialized
INFO - 2018-02-18 19:03:17 --> Controller Class Initialized
INFO - 2018-02-18 19:03:17 --> Model Class Initialized
INFO - 2018-02-18 19:03:17 --> Model Class Initialized
INFO - 2018-02-18 19:03:17 --> Model Class Initialized
INFO - 2018-02-18 19:03:17 --> Model Class Initialized
INFO - 2018-02-18 19:03:17 --> Model Class Initialized
DEBUG - 2018-02-18 19:03:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:03:17 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 19:03:17 --> Final output sent to browser
DEBUG - 2018-02-18 19:03:17 --> Total execution time: 0.0761
INFO - 2018-02-18 19:03:17 --> Config Class Initialized
INFO - 2018-02-18 19:03:17 --> Hooks Class Initialized
INFO - 2018-02-18 19:03:17 --> Config Class Initialized
INFO - 2018-02-18 19:03:17 --> Hooks Class Initialized
INFO - 2018-02-18 19:03:17 --> Config Class Initialized
INFO - 2018-02-18 19:03:17 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:03:17 --> UTF-8 Support Enabled
DEBUG - 2018-02-18 19:03:17 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:03:17 --> Utf8 Class Initialized
INFO - 2018-02-18 19:03:17 --> Utf8 Class Initialized
DEBUG - 2018-02-18 19:03:17 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:03:17 --> Utf8 Class Initialized
INFO - 2018-02-18 19:03:17 --> URI Class Initialized
INFO - 2018-02-18 19:03:17 --> URI Class Initialized
INFO - 2018-02-18 19:03:17 --> URI Class Initialized
INFO - 2018-02-18 19:03:17 --> Router Class Initialized
INFO - 2018-02-18 19:03:17 --> Router Class Initialized
INFO - 2018-02-18 19:03:17 --> Config Class Initialized
INFO - 2018-02-18 19:03:17 --> Hooks Class Initialized
INFO - 2018-02-18 19:03:17 --> Router Class Initialized
INFO - 2018-02-18 19:03:17 --> Output Class Initialized
INFO - 2018-02-18 19:03:17 --> Output Class Initialized
INFO - 2018-02-18 19:03:17 --> Security Class Initialized
INFO - 2018-02-18 19:03:17 --> Output Class Initialized
DEBUG - 2018-02-18 19:03:17 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:03:17 --> Utf8 Class Initialized
INFO - 2018-02-18 19:03:17 --> Security Class Initialized
DEBUG - 2018-02-18 19:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:03:17 --> URI Class Initialized
INFO - 2018-02-18 19:03:17 --> Security Class Initialized
DEBUG - 2018-02-18 19:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:03:17 --> Input Class Initialized
INFO - 2018-02-18 19:03:17 --> Input Class Initialized
DEBUG - 2018-02-18 19:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:03:17 --> Language Class Initialized
INFO - 2018-02-18 19:03:17 --> Language Class Initialized
INFO - 2018-02-18 19:03:17 --> Input Class Initialized
INFO - 2018-02-18 19:03:17 --> Router Class Initialized
INFO - 2018-02-18 19:03:17 --> Language Class Initialized
ERROR - 2018-02-18 19:03:17 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-18 19:03:17 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-18 19:03:17 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-18 19:03:17 --> Output Class Initialized
INFO - 2018-02-18 19:03:17 --> Security Class Initialized
DEBUG - 2018-02-18 19:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:03:17 --> Input Class Initialized
INFO - 2018-02-18 19:03:17 --> Language Class Initialized
ERROR - 2018-02-18 19:03:17 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-18 19:03:17 --> Config Class Initialized
INFO - 2018-02-18 19:03:17 --> Config Class Initialized
INFO - 2018-02-18 19:03:17 --> Hooks Class Initialized
INFO - 2018-02-18 19:03:17 --> Hooks Class Initialized
INFO - 2018-02-18 19:03:17 --> Config Class Initialized
INFO - 2018-02-18 19:03:17 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:03:17 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:03:17 --> Utf8 Class Initialized
DEBUG - 2018-02-18 19:03:17 --> UTF-8 Support Enabled
DEBUG - 2018-02-18 19:03:17 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:03:17 --> Utf8 Class Initialized
INFO - 2018-02-18 19:03:17 --> Utf8 Class Initialized
INFO - 2018-02-18 19:03:17 --> URI Class Initialized
INFO - 2018-02-18 19:03:17 --> URI Class Initialized
INFO - 2018-02-18 19:03:17 --> URI Class Initialized
INFO - 2018-02-18 19:03:17 --> Router Class Initialized
INFO - 2018-02-18 19:03:17 --> Router Class Initialized
INFO - 2018-02-18 19:03:17 --> Router Class Initialized
INFO - 2018-02-18 19:03:17 --> Output Class Initialized
INFO - 2018-02-18 19:03:17 --> Output Class Initialized
INFO - 2018-02-18 19:03:17 --> Security Class Initialized
INFO - 2018-02-18 19:03:17 --> Output Class Initialized
INFO - 2018-02-18 19:03:17 --> Security Class Initialized
DEBUG - 2018-02-18 19:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:03:17 --> Input Class Initialized
INFO - 2018-02-18 19:03:17 --> Security Class Initialized
DEBUG - 2018-02-18 19:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:03:17 --> Language Class Initialized
INFO - 2018-02-18 19:03:17 --> Input Class Initialized
DEBUG - 2018-02-18 19:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:03:17 --> Language Class Initialized
INFO - 2018-02-18 19:03:17 --> Input Class Initialized
ERROR - 2018-02-18 19:03:17 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-18 19:03:17 --> Language Class Initialized
ERROR - 2018-02-18 19:03:17 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-18 19:03:17 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-18 19:03:17 --> Config Class Initialized
INFO - 2018-02-18 19:03:17 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:03:17 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:03:17 --> Utf8 Class Initialized
INFO - 2018-02-18 19:03:17 --> URI Class Initialized
INFO - 2018-02-18 19:03:17 --> Router Class Initialized
INFO - 2018-02-18 19:03:17 --> Output Class Initialized
INFO - 2018-02-18 19:03:17 --> Security Class Initialized
DEBUG - 2018-02-18 19:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:03:17 --> Input Class Initialized
INFO - 2018-02-18 19:03:17 --> Language Class Initialized
INFO - 2018-02-18 19:03:17 --> Loader Class Initialized
INFO - 2018-02-18 19:03:17 --> Helper loaded: url_helper
INFO - 2018-02-18 19:03:17 --> Helper loaded: form_helper
INFO - 2018-02-18 19:03:17 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:03:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:03:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:03:17 --> Form Validation Class Initialized
INFO - 2018-02-18 19:03:17 --> Model Class Initialized
INFO - 2018-02-18 19:03:17 --> Controller Class Initialized
INFO - 2018-02-18 19:03:17 --> Model Class Initialized
INFO - 2018-02-18 19:03:17 --> Model Class Initialized
INFO - 2018-02-18 19:03:17 --> Model Class Initialized
INFO - 2018-02-18 19:03:17 --> Model Class Initialized
INFO - 2018-02-18 19:03:17 --> Model Class Initialized
DEBUG - 2018-02-18 19:03:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:04:42 --> Config Class Initialized
INFO - 2018-02-18 19:04:42 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:04:42 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:04:42 --> Utf8 Class Initialized
INFO - 2018-02-18 19:04:42 --> URI Class Initialized
INFO - 2018-02-18 19:04:42 --> Router Class Initialized
INFO - 2018-02-18 19:04:42 --> Output Class Initialized
INFO - 2018-02-18 19:04:42 --> Security Class Initialized
DEBUG - 2018-02-18 19:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:04:42 --> Input Class Initialized
INFO - 2018-02-18 19:04:42 --> Language Class Initialized
INFO - 2018-02-18 19:04:42 --> Loader Class Initialized
INFO - 2018-02-18 19:04:42 --> Helper loaded: url_helper
INFO - 2018-02-18 19:04:42 --> Helper loaded: form_helper
INFO - 2018-02-18 19:04:42 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:04:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:04:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:04:42 --> Form Validation Class Initialized
INFO - 2018-02-18 19:04:42 --> Model Class Initialized
INFO - 2018-02-18 19:04:42 --> Controller Class Initialized
INFO - 2018-02-18 19:04:42 --> Model Class Initialized
INFO - 2018-02-18 19:04:42 --> Model Class Initialized
INFO - 2018-02-18 19:04:42 --> Model Class Initialized
INFO - 2018-02-18 19:04:42 --> Model Class Initialized
INFO - 2018-02-18 19:04:42 --> Model Class Initialized
DEBUG - 2018-02-18 19:04:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:04:42 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 19:04:42 --> Final output sent to browser
DEBUG - 2018-02-18 19:04:42 --> Total execution time: 0.0735
INFO - 2018-02-18 19:04:43 --> Config Class Initialized
INFO - 2018-02-18 19:04:43 --> Hooks Class Initialized
INFO - 2018-02-18 19:04:43 --> Config Class Initialized
INFO - 2018-02-18 19:04:43 --> Hooks Class Initialized
INFO - 2018-02-18 19:04:43 --> Config Class Initialized
INFO - 2018-02-18 19:04:43 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:04:43 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:04:43 --> Utf8 Class Initialized
DEBUG - 2018-02-18 19:04:43 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:04:43 --> Utf8 Class Initialized
INFO - 2018-02-18 19:04:43 --> URI Class Initialized
INFO - 2018-02-18 19:04:43 --> Config Class Initialized
INFO - 2018-02-18 19:04:43 --> URI Class Initialized
DEBUG - 2018-02-18 19:04:43 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:04:43 --> Hooks Class Initialized
INFO - 2018-02-18 19:04:43 --> Utf8 Class Initialized
INFO - 2018-02-18 19:04:43 --> Router Class Initialized
INFO - 2018-02-18 19:04:43 --> URI Class Initialized
INFO - 2018-02-18 19:04:43 --> Router Class Initialized
DEBUG - 2018-02-18 19:04:43 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:04:43 --> Output Class Initialized
INFO - 2018-02-18 19:04:43 --> Router Class Initialized
INFO - 2018-02-18 19:04:43 --> Utf8 Class Initialized
INFO - 2018-02-18 19:04:43 --> Output Class Initialized
INFO - 2018-02-18 19:04:43 --> Security Class Initialized
INFO - 2018-02-18 19:04:43 --> URI Class Initialized
INFO - 2018-02-18 19:04:43 --> Output Class Initialized
INFO - 2018-02-18 19:04:43 --> Security Class Initialized
DEBUG - 2018-02-18 19:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:04:43 --> Router Class Initialized
INFO - 2018-02-18 19:04:43 --> Input Class Initialized
DEBUG - 2018-02-18 19:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:04:43 --> Security Class Initialized
INFO - 2018-02-18 19:04:43 --> Input Class Initialized
INFO - 2018-02-18 19:04:43 --> Language Class Initialized
INFO - 2018-02-18 19:04:43 --> Language Class Initialized
INFO - 2018-02-18 19:04:43 --> Output Class Initialized
DEBUG - 2018-02-18 19:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:04:43 --> Input Class Initialized
ERROR - 2018-02-18 19:04:43 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-18 19:04:43 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-18 19:04:43 --> Language Class Initialized
INFO - 2018-02-18 19:04:43 --> Security Class Initialized
ERROR - 2018-02-18 19:04:43 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-02-18 19:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:04:43 --> Input Class Initialized
INFO - 2018-02-18 19:04:43 --> Language Class Initialized
ERROR - 2018-02-18 19:04:43 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-18 19:04:43 --> Config Class Initialized
INFO - 2018-02-18 19:04:43 --> Hooks Class Initialized
INFO - 2018-02-18 19:04:43 --> Config Class Initialized
INFO - 2018-02-18 19:04:43 --> Hooks Class Initialized
INFO - 2018-02-18 19:04:43 --> Config Class Initialized
INFO - 2018-02-18 19:04:43 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:04:43 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:04:43 --> Utf8 Class Initialized
INFO - 2018-02-18 19:04:43 --> URI Class Initialized
DEBUG - 2018-02-18 19:04:43 --> UTF-8 Support Enabled
DEBUG - 2018-02-18 19:04:43 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:04:43 --> Utf8 Class Initialized
INFO - 2018-02-18 19:04:43 --> Utf8 Class Initialized
INFO - 2018-02-18 19:04:43 --> Router Class Initialized
INFO - 2018-02-18 19:04:43 --> URI Class Initialized
INFO - 2018-02-18 19:04:43 --> URI Class Initialized
INFO - 2018-02-18 19:04:43 --> Output Class Initialized
INFO - 2018-02-18 19:04:43 --> Router Class Initialized
INFO - 2018-02-18 19:04:43 --> Router Class Initialized
INFO - 2018-02-18 19:04:43 --> Security Class Initialized
INFO - 2018-02-18 19:04:43 --> Output Class Initialized
INFO - 2018-02-18 19:04:43 --> Output Class Initialized
DEBUG - 2018-02-18 19:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:04:43 --> Input Class Initialized
INFO - 2018-02-18 19:04:43 --> Language Class Initialized
INFO - 2018-02-18 19:04:43 --> Security Class Initialized
INFO - 2018-02-18 19:04:43 --> Security Class Initialized
DEBUG - 2018-02-18 19:04:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-18 19:04:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-18 19:04:43 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-18 19:04:43 --> Input Class Initialized
INFO - 2018-02-18 19:04:43 --> Language Class Initialized
INFO - 2018-02-18 19:04:43 --> Input Class Initialized
ERROR - 2018-02-18 19:04:43 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-18 19:04:43 --> Language Class Initialized
ERROR - 2018-02-18 19:04:43 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-18 19:04:43 --> Config Class Initialized
INFO - 2018-02-18 19:04:43 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:04:43 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:04:43 --> Utf8 Class Initialized
INFO - 2018-02-18 19:04:43 --> URI Class Initialized
INFO - 2018-02-18 19:04:43 --> Router Class Initialized
INFO - 2018-02-18 19:04:43 --> Output Class Initialized
INFO - 2018-02-18 19:04:43 --> Security Class Initialized
DEBUG - 2018-02-18 19:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:04:43 --> Input Class Initialized
INFO - 2018-02-18 19:04:43 --> Language Class Initialized
INFO - 2018-02-18 19:04:43 --> Loader Class Initialized
INFO - 2018-02-18 19:04:43 --> Helper loaded: url_helper
INFO - 2018-02-18 19:04:43 --> Helper loaded: form_helper
INFO - 2018-02-18 19:04:43 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:04:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:04:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:04:43 --> Form Validation Class Initialized
INFO - 2018-02-18 19:04:43 --> Model Class Initialized
INFO - 2018-02-18 19:04:43 --> Controller Class Initialized
INFO - 2018-02-18 19:04:43 --> Model Class Initialized
INFO - 2018-02-18 19:04:43 --> Model Class Initialized
INFO - 2018-02-18 19:04:43 --> Model Class Initialized
INFO - 2018-02-18 19:04:43 --> Model Class Initialized
INFO - 2018-02-18 19:04:43 --> Model Class Initialized
DEBUG - 2018-02-18 19:04:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:10:50 --> Config Class Initialized
INFO - 2018-02-18 19:10:50 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:10:50 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:10:50 --> Utf8 Class Initialized
INFO - 2018-02-18 19:10:50 --> URI Class Initialized
INFO - 2018-02-18 19:10:50 --> Router Class Initialized
INFO - 2018-02-18 19:10:50 --> Output Class Initialized
INFO - 2018-02-18 19:10:50 --> Security Class Initialized
DEBUG - 2018-02-18 19:10:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:10:50 --> Input Class Initialized
INFO - 2018-02-18 19:10:50 --> Language Class Initialized
INFO - 2018-02-18 19:10:50 --> Loader Class Initialized
INFO - 2018-02-18 19:10:50 --> Helper loaded: url_helper
INFO - 2018-02-18 19:10:50 --> Helper loaded: form_helper
INFO - 2018-02-18 19:10:50 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:10:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:10:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:10:50 --> Form Validation Class Initialized
INFO - 2018-02-18 19:10:50 --> Model Class Initialized
INFO - 2018-02-18 19:10:50 --> Controller Class Initialized
INFO - 2018-02-18 19:10:50 --> Model Class Initialized
INFO - 2018-02-18 19:10:50 --> Model Class Initialized
INFO - 2018-02-18 19:10:50 --> Model Class Initialized
INFO - 2018-02-18 19:10:50 --> Model Class Initialized
INFO - 2018-02-18 19:10:50 --> Model Class Initialized
DEBUG - 2018-02-18 19:10:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:10:50 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 19:10:50 --> Final output sent to browser
DEBUG - 2018-02-18 19:10:50 --> Total execution time: 0.0709
INFO - 2018-02-18 19:10:50 --> Config Class Initialized
INFO - 2018-02-18 19:10:50 --> Hooks Class Initialized
INFO - 2018-02-18 19:10:50 --> Config Class Initialized
INFO - 2018-02-18 19:10:50 --> Hooks Class Initialized
INFO - 2018-02-18 19:10:50 --> Config Class Initialized
INFO - 2018-02-18 19:10:50 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:10:50 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:10:50 --> Utf8 Class Initialized
DEBUG - 2018-02-18 19:10:50 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:10:50 --> Utf8 Class Initialized
DEBUG - 2018-02-18 19:10:50 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:10:50 --> URI Class Initialized
INFO - 2018-02-18 19:10:50 --> Utf8 Class Initialized
INFO - 2018-02-18 19:10:50 --> URI Class Initialized
INFO - 2018-02-18 19:10:50 --> URI Class Initialized
INFO - 2018-02-18 19:10:50 --> Router Class Initialized
INFO - 2018-02-18 19:10:50 --> Router Class Initialized
INFO - 2018-02-18 19:10:50 --> Router Class Initialized
INFO - 2018-02-18 19:10:50 --> Output Class Initialized
INFO - 2018-02-18 19:10:50 --> Output Class Initialized
INFO - 2018-02-18 19:10:50 --> Output Class Initialized
INFO - 2018-02-18 19:10:50 --> Security Class Initialized
INFO - 2018-02-18 19:10:50 --> Security Class Initialized
INFO - 2018-02-18 19:10:50 --> Security Class Initialized
DEBUG - 2018-02-18 19:10:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-18 19:10:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-18 19:10:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:10:50 --> Input Class Initialized
INFO - 2018-02-18 19:10:50 --> Input Class Initialized
INFO - 2018-02-18 19:10:50 --> Input Class Initialized
INFO - 2018-02-18 19:10:50 --> Language Class Initialized
INFO - 2018-02-18 19:10:50 --> Language Class Initialized
INFO - 2018-02-18 19:10:50 --> Language Class Initialized
ERROR - 2018-02-18 19:10:50 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-18 19:10:50 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-18 19:10:50 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-18 19:10:50 --> Config Class Initialized
INFO - 2018-02-18 19:10:50 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:10:50 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:10:50 --> Utf8 Class Initialized
INFO - 2018-02-18 19:10:50 --> URI Class Initialized
INFO - 2018-02-18 19:10:50 --> Router Class Initialized
INFO - 2018-02-18 19:10:50 --> Output Class Initialized
INFO - 2018-02-18 19:10:50 --> Security Class Initialized
DEBUG - 2018-02-18 19:10:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:10:50 --> Input Class Initialized
INFO - 2018-02-18 19:10:50 --> Language Class Initialized
ERROR - 2018-02-18 19:10:50 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-18 19:10:50 --> Config Class Initialized
INFO - 2018-02-18 19:10:50 --> Hooks Class Initialized
INFO - 2018-02-18 19:10:50 --> Config Class Initialized
INFO - 2018-02-18 19:10:50 --> Hooks Class Initialized
INFO - 2018-02-18 19:10:50 --> Config Class Initialized
INFO - 2018-02-18 19:10:50 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:10:50 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:10:50 --> Utf8 Class Initialized
DEBUG - 2018-02-18 19:10:50 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:10:50 --> Utf8 Class Initialized
DEBUG - 2018-02-18 19:10:50 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:10:50 --> Utf8 Class Initialized
INFO - 2018-02-18 19:10:50 --> URI Class Initialized
INFO - 2018-02-18 19:10:50 --> URI Class Initialized
INFO - 2018-02-18 19:10:50 --> URI Class Initialized
INFO - 2018-02-18 19:10:50 --> Router Class Initialized
INFO - 2018-02-18 19:10:50 --> Router Class Initialized
INFO - 2018-02-18 19:10:50 --> Router Class Initialized
INFO - 2018-02-18 19:10:50 --> Output Class Initialized
INFO - 2018-02-18 19:10:50 --> Output Class Initialized
INFO - 2018-02-18 19:10:50 --> Output Class Initialized
INFO - 2018-02-18 19:10:50 --> Security Class Initialized
INFO - 2018-02-18 19:10:50 --> Security Class Initialized
INFO - 2018-02-18 19:10:50 --> Security Class Initialized
DEBUG - 2018-02-18 19:10:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-18 19:10:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:10:50 --> Input Class Initialized
INFO - 2018-02-18 19:10:50 --> Input Class Initialized
DEBUG - 2018-02-18 19:10:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:10:50 --> Input Class Initialized
INFO - 2018-02-18 19:10:50 --> Language Class Initialized
INFO - 2018-02-18 19:10:50 --> Language Class Initialized
INFO - 2018-02-18 19:10:50 --> Language Class Initialized
ERROR - 2018-02-18 19:10:50 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-18 19:10:50 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-18 19:10:50 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-18 19:10:51 --> Config Class Initialized
INFO - 2018-02-18 19:10:51 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:10:51 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:10:51 --> Utf8 Class Initialized
INFO - 2018-02-18 19:10:51 --> URI Class Initialized
INFO - 2018-02-18 19:10:51 --> Router Class Initialized
INFO - 2018-02-18 19:10:51 --> Output Class Initialized
INFO - 2018-02-18 19:10:51 --> Security Class Initialized
DEBUG - 2018-02-18 19:10:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:10:51 --> Input Class Initialized
INFO - 2018-02-18 19:10:51 --> Language Class Initialized
INFO - 2018-02-18 19:10:51 --> Loader Class Initialized
INFO - 2018-02-18 19:10:51 --> Helper loaded: url_helper
INFO - 2018-02-18 19:10:51 --> Helper loaded: form_helper
INFO - 2018-02-18 19:10:51 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:10:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:10:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:10:51 --> Form Validation Class Initialized
INFO - 2018-02-18 19:10:51 --> Model Class Initialized
INFO - 2018-02-18 19:10:51 --> Controller Class Initialized
INFO - 2018-02-18 19:10:51 --> Model Class Initialized
INFO - 2018-02-18 19:10:51 --> Model Class Initialized
INFO - 2018-02-18 19:10:51 --> Model Class Initialized
INFO - 2018-02-18 19:10:51 --> Model Class Initialized
INFO - 2018-02-18 19:10:51 --> Model Class Initialized
DEBUG - 2018-02-18 19:10:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:11:48 --> Config Class Initialized
INFO - 2018-02-18 19:11:48 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:11:48 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:11:48 --> Utf8 Class Initialized
INFO - 2018-02-18 19:11:48 --> URI Class Initialized
INFO - 2018-02-18 19:11:48 --> Router Class Initialized
INFO - 2018-02-18 19:11:48 --> Output Class Initialized
INFO - 2018-02-18 19:11:48 --> Security Class Initialized
DEBUG - 2018-02-18 19:11:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:11:48 --> Input Class Initialized
INFO - 2018-02-18 19:11:48 --> Language Class Initialized
INFO - 2018-02-18 19:11:48 --> Loader Class Initialized
INFO - 2018-02-18 19:11:48 --> Helper loaded: url_helper
INFO - 2018-02-18 19:11:48 --> Helper loaded: form_helper
INFO - 2018-02-18 19:11:48 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:11:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:11:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:11:48 --> Form Validation Class Initialized
INFO - 2018-02-18 19:11:48 --> Model Class Initialized
INFO - 2018-02-18 19:11:48 --> Controller Class Initialized
INFO - 2018-02-18 19:11:48 --> Model Class Initialized
INFO - 2018-02-18 19:11:48 --> Model Class Initialized
INFO - 2018-02-18 19:11:48 --> Model Class Initialized
INFO - 2018-02-18 19:11:48 --> Model Class Initialized
INFO - 2018-02-18 19:11:48 --> Model Class Initialized
DEBUG - 2018-02-18 19:11:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:11:48 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 19:11:48 --> Final output sent to browser
DEBUG - 2018-02-18 19:11:48 --> Total execution time: 0.0637
INFO - 2018-02-18 19:11:49 --> Config Class Initialized
INFO - 2018-02-18 19:11:49 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:11:49 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:11:49 --> Utf8 Class Initialized
INFO - 2018-02-18 19:11:49 --> URI Class Initialized
INFO - 2018-02-18 19:11:49 --> Router Class Initialized
INFO - 2018-02-18 19:11:49 --> Output Class Initialized
INFO - 2018-02-18 19:11:49 --> Security Class Initialized
DEBUG - 2018-02-18 19:11:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:11:49 --> Input Class Initialized
INFO - 2018-02-18 19:11:49 --> Language Class Initialized
INFO - 2018-02-18 19:11:49 --> Loader Class Initialized
INFO - 2018-02-18 19:11:49 --> Helper loaded: url_helper
INFO - 2018-02-18 19:11:49 --> Helper loaded: form_helper
INFO - 2018-02-18 19:11:49 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:11:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:11:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:11:49 --> Form Validation Class Initialized
INFO - 2018-02-18 19:11:49 --> Model Class Initialized
INFO - 2018-02-18 19:11:49 --> Controller Class Initialized
INFO - 2018-02-18 19:11:49 --> Model Class Initialized
INFO - 2018-02-18 19:11:49 --> Model Class Initialized
INFO - 2018-02-18 19:11:49 --> Model Class Initialized
INFO - 2018-02-18 19:11:49 --> Model Class Initialized
INFO - 2018-02-18 19:11:49 --> Model Class Initialized
DEBUG - 2018-02-18 19:11:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:13:25 --> Config Class Initialized
INFO - 2018-02-18 19:13:25 --> Config Class Initialized
INFO - 2018-02-18 19:13:25 --> Hooks Class Initialized
INFO - 2018-02-18 19:13:25 --> Hooks Class Initialized
INFO - 2018-02-18 19:13:25 --> Config Class Initialized
INFO - 2018-02-18 19:13:25 --> Hooks Class Initialized
INFO - 2018-02-18 19:13:25 --> Config Class Initialized
INFO - 2018-02-18 19:13:25 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:13:25 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:13:25 --> Utf8 Class Initialized
DEBUG - 2018-02-18 19:13:25 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:13:25 --> Utf8 Class Initialized
DEBUG - 2018-02-18 19:13:25 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:13:25 --> Utf8 Class Initialized
INFO - 2018-02-18 19:13:25 --> URI Class Initialized
DEBUG - 2018-02-18 19:13:25 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:13:25 --> Utf8 Class Initialized
INFO - 2018-02-18 19:13:25 --> URI Class Initialized
INFO - 2018-02-18 19:13:25 --> URI Class Initialized
INFO - 2018-02-18 19:13:25 --> URI Class Initialized
INFO - 2018-02-18 19:13:25 --> Router Class Initialized
INFO - 2018-02-18 19:13:25 --> Router Class Initialized
INFO - 2018-02-18 19:13:25 --> Router Class Initialized
INFO - 2018-02-18 19:13:25 --> Router Class Initialized
INFO - 2018-02-18 19:13:25 --> Output Class Initialized
INFO - 2018-02-18 19:13:25 --> Output Class Initialized
INFO - 2018-02-18 19:13:25 --> Output Class Initialized
INFO - 2018-02-18 19:13:25 --> Output Class Initialized
INFO - 2018-02-18 19:13:25 --> Security Class Initialized
INFO - 2018-02-18 19:13:25 --> Security Class Initialized
INFO - 2018-02-18 19:13:25 --> Security Class Initialized
INFO - 2018-02-18 19:13:25 --> Security Class Initialized
DEBUG - 2018-02-18 19:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:13:25 --> Input Class Initialized
DEBUG - 2018-02-18 19:13:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-18 19:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:13:25 --> Input Class Initialized
DEBUG - 2018-02-18 19:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:13:25 --> Input Class Initialized
INFO - 2018-02-18 19:13:25 --> Input Class Initialized
INFO - 2018-02-18 19:13:25 --> Language Class Initialized
INFO - 2018-02-18 19:13:25 --> Language Class Initialized
INFO - 2018-02-18 19:13:25 --> Language Class Initialized
INFO - 2018-02-18 19:13:25 --> Language Class Initialized
ERROR - 2018-02-18 19:13:25 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-18 19:13:25 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-18 19:13:25 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-18 19:13:25 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-18 19:13:25 --> Config Class Initialized
INFO - 2018-02-18 19:13:25 --> Hooks Class Initialized
INFO - 2018-02-18 19:13:25 --> Config Class Initialized
INFO - 2018-02-18 19:13:25 --> Hooks Class Initialized
INFO - 2018-02-18 19:13:25 --> Config Class Initialized
INFO - 2018-02-18 19:13:25 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:13:25 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:13:25 --> Utf8 Class Initialized
DEBUG - 2018-02-18 19:13:25 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:13:25 --> Utf8 Class Initialized
DEBUG - 2018-02-18 19:13:25 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:13:25 --> Utf8 Class Initialized
INFO - 2018-02-18 19:13:25 --> URI Class Initialized
INFO - 2018-02-18 19:13:25 --> URI Class Initialized
INFO - 2018-02-18 19:13:25 --> URI Class Initialized
INFO - 2018-02-18 19:13:25 --> Router Class Initialized
INFO - 2018-02-18 19:13:25 --> Router Class Initialized
INFO - 2018-02-18 19:13:25 --> Router Class Initialized
INFO - 2018-02-18 19:13:25 --> Output Class Initialized
INFO - 2018-02-18 19:13:25 --> Output Class Initialized
INFO - 2018-02-18 19:13:25 --> Output Class Initialized
INFO - 2018-02-18 19:13:25 --> Security Class Initialized
INFO - 2018-02-18 19:13:25 --> Security Class Initialized
INFO - 2018-02-18 19:13:25 --> Security Class Initialized
DEBUG - 2018-02-18 19:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:13:25 --> Input Class Initialized
DEBUG - 2018-02-18 19:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:13:25 --> Input Class Initialized
INFO - 2018-02-18 19:13:25 --> Language Class Initialized
DEBUG - 2018-02-18 19:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:13:25 --> Input Class Initialized
INFO - 2018-02-18 19:13:25 --> Language Class Initialized
ERROR - 2018-02-18 19:13:25 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-18 19:13:25 --> Language Class Initialized
ERROR - 2018-02-18 19:13:25 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-18 19:13:25 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-18 19:13:26 --> Config Class Initialized
INFO - 2018-02-18 19:13:26 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:13:26 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:13:26 --> Utf8 Class Initialized
INFO - 2018-02-18 19:13:26 --> URI Class Initialized
INFO - 2018-02-18 19:13:26 --> Router Class Initialized
INFO - 2018-02-18 19:13:26 --> Output Class Initialized
INFO - 2018-02-18 19:13:26 --> Security Class Initialized
DEBUG - 2018-02-18 19:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:13:26 --> Input Class Initialized
INFO - 2018-02-18 19:13:26 --> Language Class Initialized
INFO - 2018-02-18 19:13:26 --> Loader Class Initialized
INFO - 2018-02-18 19:13:26 --> Helper loaded: url_helper
INFO - 2018-02-18 19:13:26 --> Helper loaded: form_helper
INFO - 2018-02-18 19:13:26 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:13:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:13:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:13:26 --> Form Validation Class Initialized
INFO - 2018-02-18 19:13:26 --> Model Class Initialized
INFO - 2018-02-18 19:13:26 --> Controller Class Initialized
INFO - 2018-02-18 19:13:26 --> Model Class Initialized
INFO - 2018-02-18 19:13:26 --> Model Class Initialized
INFO - 2018-02-18 19:13:26 --> Model Class Initialized
INFO - 2018-02-18 19:13:26 --> Model Class Initialized
INFO - 2018-02-18 19:13:26 --> Model Class Initialized
DEBUG - 2018-02-18 19:13:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:13:26 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 19:13:26 --> Final output sent to browser
DEBUG - 2018-02-18 19:13:26 --> Total execution time: 0.0820
INFO - 2018-02-18 19:13:26 --> Config Class Initialized
INFO - 2018-02-18 19:13:26 --> Hooks Class Initialized
INFO - 2018-02-18 19:13:26 --> Config Class Initialized
INFO - 2018-02-18 19:13:26 --> Hooks Class Initialized
INFO - 2018-02-18 19:13:26 --> Config Class Initialized
INFO - 2018-02-18 19:13:26 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:13:26 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:13:26 --> Utf8 Class Initialized
DEBUG - 2018-02-18 19:13:26 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:13:26 --> Utf8 Class Initialized
INFO - 2018-02-18 19:13:26 --> URI Class Initialized
DEBUG - 2018-02-18 19:13:26 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:13:26 --> Utf8 Class Initialized
INFO - 2018-02-18 19:13:26 --> URI Class Initialized
INFO - 2018-02-18 19:13:26 --> URI Class Initialized
INFO - 2018-02-18 19:13:26 --> Router Class Initialized
INFO - 2018-02-18 19:13:26 --> Router Class Initialized
INFO - 2018-02-18 19:13:26 --> Router Class Initialized
INFO - 2018-02-18 19:13:26 --> Output Class Initialized
INFO - 2018-02-18 19:13:26 --> Output Class Initialized
INFO - 2018-02-18 19:13:26 --> Security Class Initialized
INFO - 2018-02-18 19:13:26 --> Output Class Initialized
INFO - 2018-02-18 19:13:26 --> Security Class Initialized
DEBUG - 2018-02-18 19:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:13:26 --> Input Class Initialized
INFO - 2018-02-18 19:13:26 --> Security Class Initialized
DEBUG - 2018-02-18 19:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:13:26 --> Language Class Initialized
INFO - 2018-02-18 19:13:26 --> Input Class Initialized
DEBUG - 2018-02-18 19:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:13:26 --> Language Class Initialized
INFO - 2018-02-18 19:13:26 --> Input Class Initialized
ERROR - 2018-02-18 19:13:26 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-18 19:13:26 --> Language Class Initialized
ERROR - 2018-02-18 19:13:26 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-18 19:13:26 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-18 19:13:26 --> Config Class Initialized
INFO - 2018-02-18 19:13:26 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:13:26 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:13:26 --> Utf8 Class Initialized
INFO - 2018-02-18 19:13:26 --> URI Class Initialized
INFO - 2018-02-18 19:13:26 --> Router Class Initialized
INFO - 2018-02-18 19:13:26 --> Output Class Initialized
INFO - 2018-02-18 19:13:26 --> Security Class Initialized
DEBUG - 2018-02-18 19:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:13:26 --> Input Class Initialized
INFO - 2018-02-18 19:13:26 --> Language Class Initialized
ERROR - 2018-02-18 19:13:26 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-18 19:13:26 --> Config Class Initialized
INFO - 2018-02-18 19:13:26 --> Hooks Class Initialized
INFO - 2018-02-18 19:13:26 --> Config Class Initialized
INFO - 2018-02-18 19:13:26 --> Hooks Class Initialized
INFO - 2018-02-18 19:13:26 --> Config Class Initialized
INFO - 2018-02-18 19:13:26 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:13:26 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:13:26 --> Utf8 Class Initialized
INFO - 2018-02-18 19:13:26 --> URI Class Initialized
DEBUG - 2018-02-18 19:13:26 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:13:26 --> Utf8 Class Initialized
DEBUG - 2018-02-18 19:13:26 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:13:26 --> Utf8 Class Initialized
INFO - 2018-02-18 19:13:26 --> URI Class Initialized
INFO - 2018-02-18 19:13:26 --> Router Class Initialized
INFO - 2018-02-18 19:13:26 --> URI Class Initialized
INFO - 2018-02-18 19:13:26 --> Output Class Initialized
INFO - 2018-02-18 19:13:26 --> Router Class Initialized
INFO - 2018-02-18 19:13:26 --> Router Class Initialized
INFO - 2018-02-18 19:13:26 --> Security Class Initialized
INFO - 2018-02-18 19:13:26 --> Output Class Initialized
INFO - 2018-02-18 19:13:26 --> Output Class Initialized
DEBUG - 2018-02-18 19:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:13:26 --> Input Class Initialized
INFO - 2018-02-18 19:13:26 --> Security Class Initialized
INFO - 2018-02-18 19:13:26 --> Language Class Initialized
INFO - 2018-02-18 19:13:26 --> Security Class Initialized
DEBUG - 2018-02-18 19:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:13:26 --> Input Class Initialized
ERROR - 2018-02-18 19:13:26 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-02-18 19:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:13:26 --> Language Class Initialized
INFO - 2018-02-18 19:13:26 --> Input Class Initialized
INFO - 2018-02-18 19:13:26 --> Language Class Initialized
ERROR - 2018-02-18 19:13:26 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-18 19:13:26 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-18 19:13:27 --> Config Class Initialized
INFO - 2018-02-18 19:13:27 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:13:27 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:13:27 --> Utf8 Class Initialized
INFO - 2018-02-18 19:13:27 --> URI Class Initialized
INFO - 2018-02-18 19:13:27 --> Router Class Initialized
INFO - 2018-02-18 19:13:27 --> Output Class Initialized
INFO - 2018-02-18 19:13:27 --> Security Class Initialized
DEBUG - 2018-02-18 19:13:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:13:27 --> Input Class Initialized
INFO - 2018-02-18 19:13:27 --> Language Class Initialized
INFO - 2018-02-18 19:13:27 --> Loader Class Initialized
INFO - 2018-02-18 19:13:27 --> Helper loaded: url_helper
INFO - 2018-02-18 19:13:27 --> Helper loaded: form_helper
INFO - 2018-02-18 19:13:27 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:13:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:13:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:13:27 --> Form Validation Class Initialized
INFO - 2018-02-18 19:13:27 --> Model Class Initialized
INFO - 2018-02-18 19:13:27 --> Controller Class Initialized
INFO - 2018-02-18 19:13:27 --> Model Class Initialized
INFO - 2018-02-18 19:13:27 --> Model Class Initialized
INFO - 2018-02-18 19:13:27 --> Model Class Initialized
INFO - 2018-02-18 19:13:27 --> Model Class Initialized
INFO - 2018-02-18 19:13:27 --> Model Class Initialized
DEBUG - 2018-02-18 19:13:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:13:53 --> Config Class Initialized
INFO - 2018-02-18 19:13:53 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:13:53 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:13:53 --> Utf8 Class Initialized
INFO - 2018-02-18 19:13:53 --> URI Class Initialized
INFO - 2018-02-18 19:13:53 --> Router Class Initialized
INFO - 2018-02-18 19:13:53 --> Output Class Initialized
INFO - 2018-02-18 19:13:53 --> Security Class Initialized
DEBUG - 2018-02-18 19:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:13:53 --> Input Class Initialized
INFO - 2018-02-18 19:13:53 --> Language Class Initialized
INFO - 2018-02-18 19:13:53 --> Loader Class Initialized
INFO - 2018-02-18 19:13:53 --> Helper loaded: url_helper
INFO - 2018-02-18 19:13:53 --> Helper loaded: form_helper
INFO - 2018-02-18 19:13:53 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:13:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:13:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:13:53 --> Form Validation Class Initialized
INFO - 2018-02-18 19:13:53 --> Model Class Initialized
INFO - 2018-02-18 19:13:53 --> Controller Class Initialized
INFO - 2018-02-18 19:13:53 --> Model Class Initialized
INFO - 2018-02-18 19:13:53 --> Model Class Initialized
INFO - 2018-02-18 19:13:53 --> Model Class Initialized
INFO - 2018-02-18 19:13:53 --> Model Class Initialized
INFO - 2018-02-18 19:13:53 --> Model Class Initialized
DEBUG - 2018-02-18 19:13:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:13:53 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 19:13:53 --> Final output sent to browser
DEBUG - 2018-02-18 19:13:53 --> Total execution time: 0.0630
INFO - 2018-02-18 19:13:54 --> Config Class Initialized
INFO - 2018-02-18 19:13:54 --> Hooks Class Initialized
INFO - 2018-02-18 19:13:54 --> Config Class Initialized
INFO - 2018-02-18 19:13:54 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:13:54 --> UTF-8 Support Enabled
DEBUG - 2018-02-18 19:13:54 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:13:54 --> Utf8 Class Initialized
INFO - 2018-02-18 19:13:54 --> Utf8 Class Initialized
INFO - 2018-02-18 19:13:54 --> URI Class Initialized
INFO - 2018-02-18 19:13:54 --> URI Class Initialized
INFO - 2018-02-18 19:13:54 --> Router Class Initialized
INFO - 2018-02-18 19:13:54 --> Router Class Initialized
INFO - 2018-02-18 19:13:54 --> Output Class Initialized
INFO - 2018-02-18 19:13:54 --> Output Class Initialized
INFO - 2018-02-18 19:13:54 --> Security Class Initialized
INFO - 2018-02-18 19:13:54 --> Security Class Initialized
DEBUG - 2018-02-18 19:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:13:54 --> Input Class Initialized
DEBUG - 2018-02-18 19:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:13:54 --> Input Class Initialized
INFO - 2018-02-18 19:13:54 --> Language Class Initialized
INFO - 2018-02-18 19:13:54 --> Language Class Initialized
ERROR - 2018-02-18 19:13:54 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-18 19:13:54 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-18 19:13:54 --> Config Class Initialized
INFO - 2018-02-18 19:13:54 --> Hooks Class Initialized
INFO - 2018-02-18 19:13:54 --> Config Class Initialized
INFO - 2018-02-18 19:13:54 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:13:54 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:13:54 --> Utf8 Class Initialized
INFO - 2018-02-18 19:13:54 --> URI Class Initialized
DEBUG - 2018-02-18 19:13:54 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:13:54 --> Utf8 Class Initialized
INFO - 2018-02-18 19:13:54 --> Router Class Initialized
INFO - 2018-02-18 19:13:54 --> URI Class Initialized
INFO - 2018-02-18 19:13:54 --> Router Class Initialized
INFO - 2018-02-18 19:13:54 --> Output Class Initialized
INFO - 2018-02-18 19:13:54 --> Output Class Initialized
INFO - 2018-02-18 19:13:54 --> Security Class Initialized
INFO - 2018-02-18 19:13:54 --> Security Class Initialized
DEBUG - 2018-02-18 19:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:13:54 --> Input Class Initialized
INFO - 2018-02-18 19:13:54 --> Language Class Initialized
DEBUG - 2018-02-18 19:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:13:54 --> Input Class Initialized
INFO - 2018-02-18 19:13:54 --> Language Class Initialized
ERROR - 2018-02-18 19:13:54 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-18 19:13:54 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-18 19:13:54 --> Config Class Initialized
INFO - 2018-02-18 19:13:54 --> Hooks Class Initialized
INFO - 2018-02-18 19:13:54 --> Config Class Initialized
INFO - 2018-02-18 19:13:54 --> Config Class Initialized
INFO - 2018-02-18 19:13:54 --> Hooks Class Initialized
INFO - 2018-02-18 19:13:54 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:13:54 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:13:54 --> Utf8 Class Initialized
INFO - 2018-02-18 19:13:54 --> URI Class Initialized
DEBUG - 2018-02-18 19:13:54 --> UTF-8 Support Enabled
DEBUG - 2018-02-18 19:13:54 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:13:54 --> Utf8 Class Initialized
INFO - 2018-02-18 19:13:54 --> Utf8 Class Initialized
INFO - 2018-02-18 19:13:54 --> Router Class Initialized
INFO - 2018-02-18 19:13:54 --> URI Class Initialized
INFO - 2018-02-18 19:13:54 --> URI Class Initialized
INFO - 2018-02-18 19:13:54 --> Output Class Initialized
INFO - 2018-02-18 19:13:54 --> Router Class Initialized
INFO - 2018-02-18 19:13:54 --> Security Class Initialized
INFO - 2018-02-18 19:13:54 --> Router Class Initialized
INFO - 2018-02-18 19:13:54 --> Output Class Initialized
DEBUG - 2018-02-18 19:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:13:54 --> Input Class Initialized
INFO - 2018-02-18 19:13:54 --> Security Class Initialized
INFO - 2018-02-18 19:13:54 --> Output Class Initialized
INFO - 2018-02-18 19:13:54 --> Language Class Initialized
DEBUG - 2018-02-18 19:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:13:54 --> Security Class Initialized
INFO - 2018-02-18 19:13:54 --> Input Class Initialized
ERROR - 2018-02-18 19:13:54 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-18 19:13:54 --> Language Class Initialized
DEBUG - 2018-02-18 19:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:13:54 --> Input Class Initialized
INFO - 2018-02-18 19:13:54 --> Language Class Initialized
ERROR - 2018-02-18 19:13:54 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-18 19:13:54 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-18 19:13:54 --> Config Class Initialized
INFO - 2018-02-18 19:13:54 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:13:54 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:13:54 --> Utf8 Class Initialized
INFO - 2018-02-18 19:13:54 --> URI Class Initialized
INFO - 2018-02-18 19:13:54 --> Router Class Initialized
INFO - 2018-02-18 19:13:54 --> Output Class Initialized
INFO - 2018-02-18 19:13:54 --> Security Class Initialized
DEBUG - 2018-02-18 19:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:13:54 --> Input Class Initialized
INFO - 2018-02-18 19:13:54 --> Language Class Initialized
INFO - 2018-02-18 19:13:54 --> Loader Class Initialized
INFO - 2018-02-18 19:13:54 --> Helper loaded: url_helper
INFO - 2018-02-18 19:13:54 --> Helper loaded: form_helper
INFO - 2018-02-18 19:13:54 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:13:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:13:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:13:54 --> Form Validation Class Initialized
INFO - 2018-02-18 19:13:54 --> Model Class Initialized
INFO - 2018-02-18 19:13:54 --> Controller Class Initialized
INFO - 2018-02-18 19:13:54 --> Model Class Initialized
INFO - 2018-02-18 19:13:54 --> Model Class Initialized
INFO - 2018-02-18 19:13:54 --> Model Class Initialized
INFO - 2018-02-18 19:13:54 --> Model Class Initialized
INFO - 2018-02-18 19:13:54 --> Model Class Initialized
DEBUG - 2018-02-18 19:13:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:14:13 --> Config Class Initialized
INFO - 2018-02-18 19:14:13 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:14:13 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:14:13 --> Utf8 Class Initialized
INFO - 2018-02-18 19:14:13 --> URI Class Initialized
INFO - 2018-02-18 19:14:13 --> Router Class Initialized
INFO - 2018-02-18 19:14:13 --> Output Class Initialized
INFO - 2018-02-18 19:14:13 --> Security Class Initialized
DEBUG - 2018-02-18 19:14:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:14:13 --> Input Class Initialized
INFO - 2018-02-18 19:14:13 --> Language Class Initialized
INFO - 2018-02-18 19:14:13 --> Loader Class Initialized
INFO - 2018-02-18 19:14:13 --> Helper loaded: url_helper
INFO - 2018-02-18 19:14:13 --> Helper loaded: form_helper
INFO - 2018-02-18 19:14:14 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:14:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:14:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:14:14 --> Form Validation Class Initialized
INFO - 2018-02-18 19:14:14 --> Model Class Initialized
INFO - 2018-02-18 19:14:14 --> Controller Class Initialized
INFO - 2018-02-18 19:14:14 --> Model Class Initialized
INFO - 2018-02-18 19:14:14 --> Model Class Initialized
INFO - 2018-02-18 19:14:14 --> Model Class Initialized
INFO - 2018-02-18 19:14:14 --> Model Class Initialized
INFO - 2018-02-18 19:14:14 --> Model Class Initialized
DEBUG - 2018-02-18 19:14:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:14:14 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 19:14:14 --> Final output sent to browser
DEBUG - 2018-02-18 19:14:14 --> Total execution time: 0.0729
INFO - 2018-02-18 19:14:14 --> Config Class Initialized
INFO - 2018-02-18 19:14:14 --> Config Class Initialized
INFO - 2018-02-18 19:14:14 --> Hooks Class Initialized
INFO - 2018-02-18 19:14:14 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:14:14 --> UTF-8 Support Enabled
DEBUG - 2018-02-18 19:14:14 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:14:14 --> Utf8 Class Initialized
INFO - 2018-02-18 19:14:14 --> Utf8 Class Initialized
INFO - 2018-02-18 19:14:14 --> URI Class Initialized
INFO - 2018-02-18 19:14:14 --> URI Class Initialized
INFO - 2018-02-18 19:14:14 --> Router Class Initialized
INFO - 2018-02-18 19:14:14 --> Router Class Initialized
INFO - 2018-02-18 19:14:14 --> Output Class Initialized
INFO - 2018-02-18 19:14:14 --> Output Class Initialized
INFO - 2018-02-18 19:14:14 --> Security Class Initialized
INFO - 2018-02-18 19:14:14 --> Security Class Initialized
DEBUG - 2018-02-18 19:14:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:14:14 --> Input Class Initialized
DEBUG - 2018-02-18 19:14:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:14:14 --> Input Class Initialized
INFO - 2018-02-18 19:14:14 --> Language Class Initialized
INFO - 2018-02-18 19:14:14 --> Language Class Initialized
ERROR - 2018-02-18 19:14:14 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-18 19:14:14 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-18 19:14:14 --> Config Class Initialized
INFO - 2018-02-18 19:14:14 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:14:14 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:14:14 --> Config Class Initialized
INFO - 2018-02-18 19:14:14 --> Utf8 Class Initialized
INFO - 2018-02-18 19:14:14 --> Hooks Class Initialized
INFO - 2018-02-18 19:14:14 --> URI Class Initialized
DEBUG - 2018-02-18 19:14:14 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:14:14 --> Utf8 Class Initialized
INFO - 2018-02-18 19:14:14 --> Router Class Initialized
INFO - 2018-02-18 19:14:14 --> URI Class Initialized
INFO - 2018-02-18 19:14:14 --> Output Class Initialized
INFO - 2018-02-18 19:14:14 --> Router Class Initialized
INFO - 2018-02-18 19:14:14 --> Security Class Initialized
DEBUG - 2018-02-18 19:14:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:14:14 --> Input Class Initialized
INFO - 2018-02-18 19:14:14 --> Output Class Initialized
INFO - 2018-02-18 19:14:14 --> Language Class Initialized
INFO - 2018-02-18 19:14:14 --> Security Class Initialized
ERROR - 2018-02-18 19:14:14 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-02-18 19:14:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:14:14 --> Input Class Initialized
INFO - 2018-02-18 19:14:14 --> Language Class Initialized
ERROR - 2018-02-18 19:14:14 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-18 19:14:14 --> Config Class Initialized
INFO - 2018-02-18 19:14:14 --> Hooks Class Initialized
INFO - 2018-02-18 19:14:14 --> Config Class Initialized
INFO - 2018-02-18 19:14:14 --> Config Class Initialized
INFO - 2018-02-18 19:14:14 --> Hooks Class Initialized
INFO - 2018-02-18 19:14:14 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:14:14 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:14:14 --> Utf8 Class Initialized
INFO - 2018-02-18 19:14:14 --> URI Class Initialized
DEBUG - 2018-02-18 19:14:14 --> UTF-8 Support Enabled
DEBUG - 2018-02-18 19:14:14 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:14:14 --> Utf8 Class Initialized
INFO - 2018-02-18 19:14:14 --> Utf8 Class Initialized
INFO - 2018-02-18 19:14:14 --> Router Class Initialized
INFO - 2018-02-18 19:14:14 --> URI Class Initialized
INFO - 2018-02-18 19:14:14 --> URI Class Initialized
INFO - 2018-02-18 19:14:14 --> Output Class Initialized
INFO - 2018-02-18 19:14:14 --> Router Class Initialized
INFO - 2018-02-18 19:14:14 --> Router Class Initialized
INFO - 2018-02-18 19:14:14 --> Security Class Initialized
INFO - 2018-02-18 19:14:14 --> Output Class Initialized
DEBUG - 2018-02-18 19:14:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:14:14 --> Input Class Initialized
INFO - 2018-02-18 19:14:14 --> Output Class Initialized
INFO - 2018-02-18 19:14:14 --> Security Class Initialized
INFO - 2018-02-18 19:14:14 --> Language Class Initialized
INFO - 2018-02-18 19:14:14 --> Security Class Initialized
DEBUG - 2018-02-18 19:14:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:14:14 --> Input Class Initialized
ERROR - 2018-02-18 19:14:14 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-02-18 19:14:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:14:14 --> Input Class Initialized
INFO - 2018-02-18 19:14:14 --> Language Class Initialized
INFO - 2018-02-18 19:14:14 --> Language Class Initialized
ERROR - 2018-02-18 19:14:14 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-18 19:14:14 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-18 19:14:14 --> Config Class Initialized
INFO - 2018-02-18 19:14:14 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:14:14 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:14:14 --> Utf8 Class Initialized
INFO - 2018-02-18 19:14:14 --> URI Class Initialized
INFO - 2018-02-18 19:14:14 --> Router Class Initialized
INFO - 2018-02-18 19:14:14 --> Output Class Initialized
INFO - 2018-02-18 19:14:14 --> Security Class Initialized
DEBUG - 2018-02-18 19:14:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:14:14 --> Input Class Initialized
INFO - 2018-02-18 19:14:14 --> Language Class Initialized
INFO - 2018-02-18 19:14:14 --> Loader Class Initialized
INFO - 2018-02-18 19:14:14 --> Helper loaded: url_helper
INFO - 2018-02-18 19:14:14 --> Helper loaded: form_helper
INFO - 2018-02-18 19:14:14 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:14:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:14:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:14:14 --> Form Validation Class Initialized
INFO - 2018-02-18 19:14:14 --> Model Class Initialized
INFO - 2018-02-18 19:14:14 --> Controller Class Initialized
INFO - 2018-02-18 19:14:14 --> Model Class Initialized
INFO - 2018-02-18 19:14:14 --> Model Class Initialized
INFO - 2018-02-18 19:14:14 --> Model Class Initialized
INFO - 2018-02-18 19:14:14 --> Model Class Initialized
INFO - 2018-02-18 19:14:14 --> Model Class Initialized
DEBUG - 2018-02-18 19:14:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:14:32 --> Config Class Initialized
INFO - 2018-02-18 19:14:32 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:14:32 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:14:32 --> Utf8 Class Initialized
INFO - 2018-02-18 19:14:32 --> URI Class Initialized
INFO - 2018-02-18 19:14:32 --> Router Class Initialized
INFO - 2018-02-18 19:14:32 --> Output Class Initialized
INFO - 2018-02-18 19:14:32 --> Security Class Initialized
DEBUG - 2018-02-18 19:14:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:14:32 --> Input Class Initialized
INFO - 2018-02-18 19:14:32 --> Language Class Initialized
INFO - 2018-02-18 19:14:32 --> Loader Class Initialized
INFO - 2018-02-18 19:14:32 --> Helper loaded: url_helper
INFO - 2018-02-18 19:14:32 --> Helper loaded: form_helper
INFO - 2018-02-18 19:14:32 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:14:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:14:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:14:32 --> Form Validation Class Initialized
INFO - 2018-02-18 19:14:32 --> Model Class Initialized
INFO - 2018-02-18 19:14:32 --> Controller Class Initialized
INFO - 2018-02-18 19:14:32 --> Model Class Initialized
INFO - 2018-02-18 19:14:32 --> Model Class Initialized
INFO - 2018-02-18 19:14:32 --> Model Class Initialized
INFO - 2018-02-18 19:14:32 --> Model Class Initialized
INFO - 2018-02-18 19:14:32 --> Model Class Initialized
DEBUG - 2018-02-18 19:14:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:14:32 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 19:14:32 --> Final output sent to browser
DEBUG - 2018-02-18 19:14:32 --> Total execution time: 0.0610
INFO - 2018-02-18 19:14:33 --> Config Class Initialized
INFO - 2018-02-18 19:14:33 --> Config Class Initialized
INFO - 2018-02-18 19:14:33 --> Hooks Class Initialized
INFO - 2018-02-18 19:14:33 --> Hooks Class Initialized
INFO - 2018-02-18 19:14:33 --> Config Class Initialized
INFO - 2018-02-18 19:14:33 --> Hooks Class Initialized
INFO - 2018-02-18 19:14:33 --> Config Class Initialized
INFO - 2018-02-18 19:14:33 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:14:33 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:14:33 --> Utf8 Class Initialized
DEBUG - 2018-02-18 19:14:33 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:14:33 --> URI Class Initialized
INFO - 2018-02-18 19:14:33 --> Utf8 Class Initialized
DEBUG - 2018-02-18 19:14:33 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:14:33 --> Utf8 Class Initialized
INFO - 2018-02-18 19:14:33 --> URI Class Initialized
DEBUG - 2018-02-18 19:14:33 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:14:33 --> Router Class Initialized
INFO - 2018-02-18 19:14:33 --> Utf8 Class Initialized
INFO - 2018-02-18 19:14:33 --> URI Class Initialized
INFO - 2018-02-18 19:14:33 --> Router Class Initialized
INFO - 2018-02-18 19:14:33 --> URI Class Initialized
INFO - 2018-02-18 19:14:33 --> Output Class Initialized
INFO - 2018-02-18 19:14:33 --> Router Class Initialized
INFO - 2018-02-18 19:14:33 --> Security Class Initialized
INFO - 2018-02-18 19:14:33 --> Output Class Initialized
INFO - 2018-02-18 19:14:33 --> Router Class Initialized
INFO - 2018-02-18 19:14:33 --> Output Class Initialized
DEBUG - 2018-02-18 19:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:14:33 --> Security Class Initialized
INFO - 2018-02-18 19:14:33 --> Input Class Initialized
INFO - 2018-02-18 19:14:33 --> Output Class Initialized
INFO - 2018-02-18 19:14:33 --> Security Class Initialized
INFO - 2018-02-18 19:14:33 --> Language Class Initialized
DEBUG - 2018-02-18 19:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:14:33 --> Input Class Initialized
INFO - 2018-02-18 19:14:33 --> Security Class Initialized
DEBUG - 2018-02-18 19:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:14:33 --> Input Class Initialized
ERROR - 2018-02-18 19:14:33 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-18 19:14:33 --> Language Class Initialized
DEBUG - 2018-02-18 19:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:14:33 --> Language Class Initialized
INFO - 2018-02-18 19:14:33 --> Input Class Initialized
ERROR - 2018-02-18 19:14:33 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-18 19:14:33 --> Language Class Initialized
ERROR - 2018-02-18 19:14:33 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-18 19:14:33 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-18 19:14:33 --> Config Class Initialized
INFO - 2018-02-18 19:14:33 --> Hooks Class Initialized
INFO - 2018-02-18 19:14:33 --> Config Class Initialized
INFO - 2018-02-18 19:14:33 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:14:33 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:14:33 --> Utf8 Class Initialized
INFO - 2018-02-18 19:14:33 --> Config Class Initialized
INFO - 2018-02-18 19:14:33 --> Hooks Class Initialized
INFO - 2018-02-18 19:14:33 --> URI Class Initialized
DEBUG - 2018-02-18 19:14:33 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:14:33 --> Utf8 Class Initialized
INFO - 2018-02-18 19:14:33 --> Router Class Initialized
INFO - 2018-02-18 19:14:33 --> URI Class Initialized
DEBUG - 2018-02-18 19:14:33 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:14:33 --> Utf8 Class Initialized
INFO - 2018-02-18 19:14:33 --> Router Class Initialized
INFO - 2018-02-18 19:14:33 --> Output Class Initialized
INFO - 2018-02-18 19:14:33 --> URI Class Initialized
INFO - 2018-02-18 19:14:33 --> Security Class Initialized
INFO - 2018-02-18 19:14:33 --> Output Class Initialized
INFO - 2018-02-18 19:14:33 --> Router Class Initialized
DEBUG - 2018-02-18 19:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:14:33 --> Security Class Initialized
INFO - 2018-02-18 19:14:33 --> Input Class Initialized
INFO - 2018-02-18 19:14:33 --> Language Class Initialized
DEBUG - 2018-02-18 19:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:14:33 --> Input Class Initialized
INFO - 2018-02-18 19:14:33 --> Output Class Initialized
ERROR - 2018-02-18 19:14:33 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-18 19:14:33 --> Language Class Initialized
INFO - 2018-02-18 19:14:33 --> Security Class Initialized
ERROR - 2018-02-18 19:14:33 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-02-18 19:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:14:33 --> Input Class Initialized
INFO - 2018-02-18 19:14:33 --> Language Class Initialized
ERROR - 2018-02-18 19:14:33 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-18 19:14:33 --> Config Class Initialized
INFO - 2018-02-18 19:14:33 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:14:33 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:14:33 --> Utf8 Class Initialized
INFO - 2018-02-18 19:14:33 --> URI Class Initialized
INFO - 2018-02-18 19:14:33 --> Router Class Initialized
INFO - 2018-02-18 19:14:33 --> Output Class Initialized
INFO - 2018-02-18 19:14:33 --> Security Class Initialized
DEBUG - 2018-02-18 19:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:14:33 --> Input Class Initialized
INFO - 2018-02-18 19:14:33 --> Language Class Initialized
INFO - 2018-02-18 19:14:33 --> Loader Class Initialized
INFO - 2018-02-18 19:14:33 --> Helper loaded: url_helper
INFO - 2018-02-18 19:14:33 --> Helper loaded: form_helper
INFO - 2018-02-18 19:14:33 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:14:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:14:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:14:33 --> Form Validation Class Initialized
INFO - 2018-02-18 19:14:33 --> Model Class Initialized
INFO - 2018-02-18 19:14:33 --> Controller Class Initialized
INFO - 2018-02-18 19:14:33 --> Model Class Initialized
INFO - 2018-02-18 19:14:33 --> Model Class Initialized
INFO - 2018-02-18 19:14:33 --> Model Class Initialized
INFO - 2018-02-18 19:14:33 --> Model Class Initialized
INFO - 2018-02-18 19:14:33 --> Model Class Initialized
DEBUG - 2018-02-18 19:14:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:14:56 --> Config Class Initialized
INFO - 2018-02-18 19:14:56 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:14:56 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:14:56 --> Utf8 Class Initialized
INFO - 2018-02-18 19:14:56 --> URI Class Initialized
INFO - 2018-02-18 19:14:56 --> Router Class Initialized
INFO - 2018-02-18 19:14:56 --> Output Class Initialized
INFO - 2018-02-18 19:14:56 --> Security Class Initialized
DEBUG - 2018-02-18 19:14:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:14:56 --> Input Class Initialized
INFO - 2018-02-18 19:14:56 --> Language Class Initialized
INFO - 2018-02-18 19:14:56 --> Loader Class Initialized
INFO - 2018-02-18 19:14:56 --> Helper loaded: url_helper
INFO - 2018-02-18 19:14:56 --> Helper loaded: form_helper
INFO - 2018-02-18 19:14:56 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:14:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:14:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:14:56 --> Form Validation Class Initialized
INFO - 2018-02-18 19:14:56 --> Model Class Initialized
INFO - 2018-02-18 19:14:56 --> Controller Class Initialized
INFO - 2018-02-18 19:14:56 --> Model Class Initialized
INFO - 2018-02-18 19:14:56 --> Model Class Initialized
INFO - 2018-02-18 19:14:56 --> Model Class Initialized
INFO - 2018-02-18 19:14:56 --> Model Class Initialized
INFO - 2018-02-18 19:14:56 --> Model Class Initialized
DEBUG - 2018-02-18 19:14:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:14:56 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 19:14:56 --> Final output sent to browser
DEBUG - 2018-02-18 19:14:56 --> Total execution time: 0.0537
INFO - 2018-02-18 19:14:56 --> Config Class Initialized
INFO - 2018-02-18 19:14:56 --> Hooks Class Initialized
INFO - 2018-02-18 19:14:56 --> Config Class Initialized
INFO - 2018-02-18 19:14:56 --> Hooks Class Initialized
INFO - 2018-02-18 19:14:56 --> Config Class Initialized
INFO - 2018-02-18 19:14:56 --> Hooks Class Initialized
INFO - 2018-02-18 19:14:56 --> Config Class Initialized
INFO - 2018-02-18 19:14:56 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:14:56 --> UTF-8 Support Enabled
DEBUG - 2018-02-18 19:14:56 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:14:56 --> Utf8 Class Initialized
DEBUG - 2018-02-18 19:14:56 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:14:56 --> Utf8 Class Initialized
INFO - 2018-02-18 19:14:56 --> Utf8 Class Initialized
DEBUG - 2018-02-18 19:14:56 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:14:56 --> URI Class Initialized
INFO - 2018-02-18 19:14:56 --> URI Class Initialized
INFO - 2018-02-18 19:14:56 --> URI Class Initialized
INFO - 2018-02-18 19:14:56 --> Utf8 Class Initialized
INFO - 2018-02-18 19:14:56 --> URI Class Initialized
INFO - 2018-02-18 19:14:56 --> Router Class Initialized
INFO - 2018-02-18 19:14:56 --> Router Class Initialized
INFO - 2018-02-18 19:14:56 --> Router Class Initialized
INFO - 2018-02-18 19:14:56 --> Router Class Initialized
INFO - 2018-02-18 19:14:56 --> Output Class Initialized
INFO - 2018-02-18 19:14:56 --> Output Class Initialized
INFO - 2018-02-18 19:14:56 --> Output Class Initialized
INFO - 2018-02-18 19:14:56 --> Output Class Initialized
INFO - 2018-02-18 19:14:56 --> Security Class Initialized
INFO - 2018-02-18 19:14:56 --> Security Class Initialized
INFO - 2018-02-18 19:14:56 --> Security Class Initialized
INFO - 2018-02-18 19:14:56 --> Security Class Initialized
DEBUG - 2018-02-18 19:14:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-18 19:14:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:14:56 --> Input Class Initialized
INFO - 2018-02-18 19:14:56 --> Input Class Initialized
DEBUG - 2018-02-18 19:14:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-18 19:14:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:14:56 --> Language Class Initialized
INFO - 2018-02-18 19:14:56 --> Language Class Initialized
INFO - 2018-02-18 19:14:56 --> Input Class Initialized
INFO - 2018-02-18 19:14:56 --> Input Class Initialized
INFO - 2018-02-18 19:14:56 --> Language Class Initialized
INFO - 2018-02-18 19:14:56 --> Language Class Initialized
ERROR - 2018-02-18 19:14:56 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-18 19:14:56 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-18 19:14:56 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-18 19:14:56 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-18 19:14:56 --> Config Class Initialized
INFO - 2018-02-18 19:14:56 --> Hooks Class Initialized
INFO - 2018-02-18 19:14:56 --> Config Class Initialized
INFO - 2018-02-18 19:14:56 --> Config Class Initialized
INFO - 2018-02-18 19:14:56 --> Hooks Class Initialized
INFO - 2018-02-18 19:14:56 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:14:56 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:14:56 --> Utf8 Class Initialized
DEBUG - 2018-02-18 19:14:56 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:14:56 --> Utf8 Class Initialized
DEBUG - 2018-02-18 19:14:56 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:14:56 --> URI Class Initialized
INFO - 2018-02-18 19:14:56 --> Utf8 Class Initialized
INFO - 2018-02-18 19:14:56 --> URI Class Initialized
INFO - 2018-02-18 19:14:56 --> URI Class Initialized
INFO - 2018-02-18 19:14:56 --> Router Class Initialized
INFO - 2018-02-18 19:14:56 --> Router Class Initialized
INFO - 2018-02-18 19:14:56 --> Router Class Initialized
INFO - 2018-02-18 19:14:56 --> Output Class Initialized
INFO - 2018-02-18 19:14:56 --> Output Class Initialized
INFO - 2018-02-18 19:14:56 --> Output Class Initialized
INFO - 2018-02-18 19:14:56 --> Security Class Initialized
INFO - 2018-02-18 19:14:56 --> Security Class Initialized
INFO - 2018-02-18 19:14:56 --> Security Class Initialized
DEBUG - 2018-02-18 19:14:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-18 19:14:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:14:56 --> Input Class Initialized
INFO - 2018-02-18 19:14:56 --> Input Class Initialized
DEBUG - 2018-02-18 19:14:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:14:56 --> Input Class Initialized
INFO - 2018-02-18 19:14:56 --> Language Class Initialized
INFO - 2018-02-18 19:14:56 --> Language Class Initialized
INFO - 2018-02-18 19:14:56 --> Language Class Initialized
ERROR - 2018-02-18 19:14:56 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-18 19:14:56 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-18 19:14:56 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-18 19:14:56 --> Config Class Initialized
INFO - 2018-02-18 19:14:56 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:14:56 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:14:56 --> Utf8 Class Initialized
INFO - 2018-02-18 19:14:56 --> URI Class Initialized
INFO - 2018-02-18 19:14:56 --> Router Class Initialized
INFO - 2018-02-18 19:14:56 --> Output Class Initialized
INFO - 2018-02-18 19:14:56 --> Security Class Initialized
DEBUG - 2018-02-18 19:14:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:14:56 --> Input Class Initialized
INFO - 2018-02-18 19:14:56 --> Language Class Initialized
INFO - 2018-02-18 19:14:56 --> Loader Class Initialized
INFO - 2018-02-18 19:14:56 --> Helper loaded: url_helper
INFO - 2018-02-18 19:14:56 --> Helper loaded: form_helper
INFO - 2018-02-18 19:14:56 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:14:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:14:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:14:56 --> Form Validation Class Initialized
INFO - 2018-02-18 19:14:56 --> Model Class Initialized
INFO - 2018-02-18 19:14:56 --> Controller Class Initialized
INFO - 2018-02-18 19:14:56 --> Model Class Initialized
INFO - 2018-02-18 19:14:56 --> Model Class Initialized
INFO - 2018-02-18 19:14:56 --> Model Class Initialized
INFO - 2018-02-18 19:14:56 --> Model Class Initialized
INFO - 2018-02-18 19:14:56 --> Model Class Initialized
DEBUG - 2018-02-18 19:14:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:15:13 --> Config Class Initialized
INFO - 2018-02-18 19:15:13 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:15:13 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:15:13 --> Utf8 Class Initialized
INFO - 2018-02-18 19:15:13 --> URI Class Initialized
INFO - 2018-02-18 19:15:13 --> Router Class Initialized
INFO - 2018-02-18 19:15:13 --> Output Class Initialized
INFO - 2018-02-18 19:15:13 --> Security Class Initialized
DEBUG - 2018-02-18 19:15:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:15:13 --> Input Class Initialized
INFO - 2018-02-18 19:15:13 --> Language Class Initialized
INFO - 2018-02-18 19:15:13 --> Loader Class Initialized
INFO - 2018-02-18 19:15:13 --> Helper loaded: url_helper
INFO - 2018-02-18 19:15:13 --> Helper loaded: form_helper
INFO - 2018-02-18 19:15:13 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:15:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:15:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:15:13 --> Form Validation Class Initialized
INFO - 2018-02-18 19:15:13 --> Model Class Initialized
INFO - 2018-02-18 19:15:13 --> Controller Class Initialized
INFO - 2018-02-18 19:15:13 --> Model Class Initialized
INFO - 2018-02-18 19:15:13 --> Model Class Initialized
INFO - 2018-02-18 19:15:13 --> Model Class Initialized
INFO - 2018-02-18 19:15:13 --> Model Class Initialized
INFO - 2018-02-18 19:15:13 --> Model Class Initialized
DEBUG - 2018-02-18 19:15:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:15:13 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 19:15:13 --> Final output sent to browser
DEBUG - 2018-02-18 19:15:13 --> Total execution time: 0.0665
INFO - 2018-02-18 19:15:13 --> Config Class Initialized
INFO - 2018-02-18 19:15:13 --> Hooks Class Initialized
INFO - 2018-02-18 19:15:13 --> Config Class Initialized
INFO - 2018-02-18 19:15:13 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:15:13 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:15:13 --> Config Class Initialized
INFO - 2018-02-18 19:15:13 --> Utf8 Class Initialized
INFO - 2018-02-18 19:15:13 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:15:13 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:15:13 --> Utf8 Class Initialized
INFO - 2018-02-18 19:15:13 --> URI Class Initialized
INFO - 2018-02-18 19:15:13 --> URI Class Initialized
INFO - 2018-02-18 19:15:13 --> Config Class Initialized
INFO - 2018-02-18 19:15:13 --> Hooks Class Initialized
INFO - 2018-02-18 19:15:13 --> Router Class Initialized
DEBUG - 2018-02-18 19:15:13 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:15:13 --> Utf8 Class Initialized
INFO - 2018-02-18 19:15:13 --> Router Class Initialized
INFO - 2018-02-18 19:15:13 --> Output Class Initialized
INFO - 2018-02-18 19:15:13 --> URI Class Initialized
INFO - 2018-02-18 19:15:13 --> Output Class Initialized
DEBUG - 2018-02-18 19:15:13 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:15:13 --> Security Class Initialized
INFO - 2018-02-18 19:15:13 --> Utf8 Class Initialized
INFO - 2018-02-18 19:15:13 --> Router Class Initialized
INFO - 2018-02-18 19:15:13 --> Security Class Initialized
DEBUG - 2018-02-18 19:15:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:15:13 --> URI Class Initialized
INFO - 2018-02-18 19:15:13 --> Input Class Initialized
DEBUG - 2018-02-18 19:15:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:15:13 --> Output Class Initialized
INFO - 2018-02-18 19:15:13 --> Language Class Initialized
INFO - 2018-02-18 19:15:13 --> Input Class Initialized
INFO - 2018-02-18 19:15:13 --> Router Class Initialized
INFO - 2018-02-18 19:15:13 --> Language Class Initialized
ERROR - 2018-02-18 19:15:13 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-18 19:15:13 --> Security Class Initialized
ERROR - 2018-02-18 19:15:13 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-02-18 19:15:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:15:13 --> Output Class Initialized
INFO - 2018-02-18 19:15:13 --> Input Class Initialized
INFO - 2018-02-18 19:15:13 --> Language Class Initialized
INFO - 2018-02-18 19:15:13 --> Security Class Initialized
ERROR - 2018-02-18 19:15:13 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-02-18 19:15:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:15:13 --> Input Class Initialized
INFO - 2018-02-18 19:15:13 --> Language Class Initialized
ERROR - 2018-02-18 19:15:13 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-18 19:15:13 --> Config Class Initialized
INFO - 2018-02-18 19:15:13 --> Config Class Initialized
INFO - 2018-02-18 19:15:13 --> Hooks Class Initialized
INFO - 2018-02-18 19:15:13 --> Hooks Class Initialized
INFO - 2018-02-18 19:15:13 --> Config Class Initialized
INFO - 2018-02-18 19:15:13 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:15:13 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:15:13 --> Utf8 Class Initialized
DEBUG - 2018-02-18 19:15:13 --> UTF-8 Support Enabled
DEBUG - 2018-02-18 19:15:13 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:15:13 --> Utf8 Class Initialized
INFO - 2018-02-18 19:15:13 --> Utf8 Class Initialized
INFO - 2018-02-18 19:15:13 --> URI Class Initialized
INFO - 2018-02-18 19:15:13 --> URI Class Initialized
INFO - 2018-02-18 19:15:13 --> URI Class Initialized
INFO - 2018-02-18 19:15:13 --> Router Class Initialized
INFO - 2018-02-18 19:15:13 --> Router Class Initialized
INFO - 2018-02-18 19:15:13 --> Router Class Initialized
INFO - 2018-02-18 19:15:13 --> Output Class Initialized
INFO - 2018-02-18 19:15:13 --> Output Class Initialized
INFO - 2018-02-18 19:15:13 --> Output Class Initialized
INFO - 2018-02-18 19:15:13 --> Security Class Initialized
INFO - 2018-02-18 19:15:13 --> Security Class Initialized
INFO - 2018-02-18 19:15:13 --> Security Class Initialized
DEBUG - 2018-02-18 19:15:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:15:13 --> Input Class Initialized
INFO - 2018-02-18 19:15:13 --> Language Class Initialized
DEBUG - 2018-02-18 19:15:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-18 19:15:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:15:13 --> Input Class Initialized
INFO - 2018-02-18 19:15:13 --> Input Class Initialized
INFO - 2018-02-18 19:15:13 --> Language Class Initialized
INFO - 2018-02-18 19:15:13 --> Language Class Initialized
ERROR - 2018-02-18 19:15:13 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-18 19:15:13 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-18 19:15:13 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-18 19:15:13 --> Config Class Initialized
INFO - 2018-02-18 19:15:13 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:15:13 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:15:13 --> Utf8 Class Initialized
INFO - 2018-02-18 19:15:13 --> URI Class Initialized
INFO - 2018-02-18 19:15:13 --> Router Class Initialized
INFO - 2018-02-18 19:15:13 --> Output Class Initialized
INFO - 2018-02-18 19:15:13 --> Security Class Initialized
DEBUG - 2018-02-18 19:15:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:15:13 --> Input Class Initialized
INFO - 2018-02-18 19:15:13 --> Language Class Initialized
INFO - 2018-02-18 19:15:13 --> Loader Class Initialized
INFO - 2018-02-18 19:15:13 --> Helper loaded: url_helper
INFO - 2018-02-18 19:15:13 --> Helper loaded: form_helper
INFO - 2018-02-18 19:15:13 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:15:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:15:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:15:13 --> Form Validation Class Initialized
INFO - 2018-02-18 19:15:13 --> Model Class Initialized
INFO - 2018-02-18 19:15:13 --> Controller Class Initialized
INFO - 2018-02-18 19:15:13 --> Model Class Initialized
INFO - 2018-02-18 19:15:13 --> Model Class Initialized
INFO - 2018-02-18 19:15:13 --> Model Class Initialized
INFO - 2018-02-18 19:15:13 --> Model Class Initialized
INFO - 2018-02-18 19:15:13 --> Model Class Initialized
DEBUG - 2018-02-18 19:15:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:15:53 --> Config Class Initialized
INFO - 2018-02-18 19:15:53 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:15:53 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:15:53 --> Utf8 Class Initialized
INFO - 2018-02-18 19:15:53 --> URI Class Initialized
INFO - 2018-02-18 19:15:53 --> Router Class Initialized
INFO - 2018-02-18 19:15:53 --> Output Class Initialized
INFO - 2018-02-18 19:15:53 --> Security Class Initialized
DEBUG - 2018-02-18 19:15:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:15:53 --> Input Class Initialized
INFO - 2018-02-18 19:15:53 --> Language Class Initialized
INFO - 2018-02-18 19:15:53 --> Loader Class Initialized
INFO - 2018-02-18 19:15:53 --> Helper loaded: url_helper
INFO - 2018-02-18 19:15:53 --> Helper loaded: form_helper
INFO - 2018-02-18 19:15:53 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:15:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:15:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:15:53 --> Form Validation Class Initialized
INFO - 2018-02-18 19:15:53 --> Model Class Initialized
INFO - 2018-02-18 19:15:53 --> Controller Class Initialized
INFO - 2018-02-18 19:15:53 --> Model Class Initialized
INFO - 2018-02-18 19:15:53 --> Model Class Initialized
INFO - 2018-02-18 19:15:53 --> Model Class Initialized
INFO - 2018-02-18 19:15:53 --> Model Class Initialized
INFO - 2018-02-18 19:15:53 --> Model Class Initialized
DEBUG - 2018-02-18 19:15:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:15:53 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 19:15:53 --> Final output sent to browser
DEBUG - 2018-02-18 19:15:53 --> Total execution time: 0.0730
INFO - 2018-02-18 19:15:53 --> Config Class Initialized
INFO - 2018-02-18 19:15:53 --> Hooks Class Initialized
INFO - 2018-02-18 19:15:53 --> Config Class Initialized
INFO - 2018-02-18 19:15:53 --> Hooks Class Initialized
INFO - 2018-02-18 19:15:53 --> Config Class Initialized
INFO - 2018-02-18 19:15:53 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:15:53 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:15:53 --> Utf8 Class Initialized
DEBUG - 2018-02-18 19:15:53 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:15:53 --> Utf8 Class Initialized
INFO - 2018-02-18 19:15:53 --> Config Class Initialized
DEBUG - 2018-02-18 19:15:53 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:15:53 --> Hooks Class Initialized
INFO - 2018-02-18 19:15:53 --> URI Class Initialized
INFO - 2018-02-18 19:15:53 --> Utf8 Class Initialized
INFO - 2018-02-18 19:15:53 --> URI Class Initialized
INFO - 2018-02-18 19:15:53 --> URI Class Initialized
INFO - 2018-02-18 19:15:53 --> Router Class Initialized
INFO - 2018-02-18 19:15:53 --> Router Class Initialized
DEBUG - 2018-02-18 19:15:53 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:15:53 --> Utf8 Class Initialized
INFO - 2018-02-18 19:15:53 --> Router Class Initialized
INFO - 2018-02-18 19:15:53 --> Output Class Initialized
INFO - 2018-02-18 19:15:53 --> URI Class Initialized
INFO - 2018-02-18 19:15:53 --> Output Class Initialized
INFO - 2018-02-18 19:15:53 --> Security Class Initialized
INFO - 2018-02-18 19:15:53 --> Output Class Initialized
INFO - 2018-02-18 19:15:53 --> Security Class Initialized
INFO - 2018-02-18 19:15:53 --> Router Class Initialized
DEBUG - 2018-02-18 19:15:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:15:53 --> Security Class Initialized
DEBUG - 2018-02-18 19:15:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:15:53 --> Input Class Initialized
INFO - 2018-02-18 19:15:53 --> Output Class Initialized
INFO - 2018-02-18 19:15:53 --> Input Class Initialized
DEBUG - 2018-02-18 19:15:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:15:53 --> Input Class Initialized
INFO - 2018-02-18 19:15:53 --> Language Class Initialized
INFO - 2018-02-18 19:15:53 --> Language Class Initialized
INFO - 2018-02-18 19:15:53 --> Security Class Initialized
INFO - 2018-02-18 19:15:53 --> Language Class Initialized
ERROR - 2018-02-18 19:15:53 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-02-18 19:15:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-18 19:15:53 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-18 19:15:53 --> Input Class Initialized
INFO - 2018-02-18 19:15:53 --> Language Class Initialized
ERROR - 2018-02-18 19:15:53 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-18 19:15:53 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-18 19:15:53 --> Config Class Initialized
INFO - 2018-02-18 19:15:53 --> Hooks Class Initialized
INFO - 2018-02-18 19:15:53 --> Config Class Initialized
INFO - 2018-02-18 19:15:53 --> Config Class Initialized
INFO - 2018-02-18 19:15:53 --> Hooks Class Initialized
INFO - 2018-02-18 19:15:53 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:15:53 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:15:53 --> Utf8 Class Initialized
DEBUG - 2018-02-18 19:15:53 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:15:53 --> Utf8 Class Initialized
DEBUG - 2018-02-18 19:15:53 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:15:53 --> Utf8 Class Initialized
INFO - 2018-02-18 19:15:53 --> URI Class Initialized
INFO - 2018-02-18 19:15:53 --> URI Class Initialized
INFO - 2018-02-18 19:15:53 --> URI Class Initialized
INFO - 2018-02-18 19:15:53 --> Router Class Initialized
INFO - 2018-02-18 19:15:53 --> Router Class Initialized
INFO - 2018-02-18 19:15:53 --> Router Class Initialized
INFO - 2018-02-18 19:15:53 --> Output Class Initialized
INFO - 2018-02-18 19:15:53 --> Output Class Initialized
INFO - 2018-02-18 19:15:53 --> Security Class Initialized
INFO - 2018-02-18 19:15:53 --> Output Class Initialized
INFO - 2018-02-18 19:15:53 --> Security Class Initialized
DEBUG - 2018-02-18 19:15:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:15:53 --> Security Class Initialized
INFO - 2018-02-18 19:15:53 --> Input Class Initialized
INFO - 2018-02-18 19:15:53 --> Language Class Initialized
DEBUG - 2018-02-18 19:15:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:15:53 --> Input Class Initialized
DEBUG - 2018-02-18 19:15:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:15:53 --> Input Class Initialized
INFO - 2018-02-18 19:15:53 --> Language Class Initialized
ERROR - 2018-02-18 19:15:53 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-18 19:15:53 --> Language Class Initialized
ERROR - 2018-02-18 19:15:53 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-18 19:15:53 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-18 19:15:53 --> Config Class Initialized
INFO - 2018-02-18 19:15:53 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:15:53 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:15:53 --> Utf8 Class Initialized
INFO - 2018-02-18 19:15:53 --> URI Class Initialized
INFO - 2018-02-18 19:15:53 --> Router Class Initialized
INFO - 2018-02-18 19:15:53 --> Output Class Initialized
INFO - 2018-02-18 19:15:53 --> Security Class Initialized
DEBUG - 2018-02-18 19:15:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:15:53 --> Input Class Initialized
INFO - 2018-02-18 19:15:53 --> Language Class Initialized
INFO - 2018-02-18 19:15:53 --> Loader Class Initialized
INFO - 2018-02-18 19:15:53 --> Helper loaded: url_helper
INFO - 2018-02-18 19:15:53 --> Helper loaded: form_helper
INFO - 2018-02-18 19:15:53 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:15:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:15:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:15:53 --> Form Validation Class Initialized
INFO - 2018-02-18 19:15:53 --> Model Class Initialized
INFO - 2018-02-18 19:15:53 --> Controller Class Initialized
INFO - 2018-02-18 19:15:53 --> Model Class Initialized
INFO - 2018-02-18 19:15:53 --> Model Class Initialized
INFO - 2018-02-18 19:15:53 --> Model Class Initialized
INFO - 2018-02-18 19:15:53 --> Model Class Initialized
INFO - 2018-02-18 19:15:53 --> Model Class Initialized
DEBUG - 2018-02-18 19:15:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:16:18 --> Config Class Initialized
INFO - 2018-02-18 19:16:18 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:16:18 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:16:18 --> Utf8 Class Initialized
INFO - 2018-02-18 19:16:18 --> URI Class Initialized
INFO - 2018-02-18 19:16:18 --> Router Class Initialized
INFO - 2018-02-18 19:16:18 --> Output Class Initialized
INFO - 2018-02-18 19:16:18 --> Security Class Initialized
DEBUG - 2018-02-18 19:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:16:18 --> Input Class Initialized
INFO - 2018-02-18 19:16:18 --> Language Class Initialized
INFO - 2018-02-18 19:16:18 --> Loader Class Initialized
INFO - 2018-02-18 19:16:18 --> Helper loaded: url_helper
INFO - 2018-02-18 19:16:18 --> Helper loaded: form_helper
INFO - 2018-02-18 19:16:18 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:16:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:16:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:16:18 --> Form Validation Class Initialized
INFO - 2018-02-18 19:16:18 --> Model Class Initialized
INFO - 2018-02-18 19:16:18 --> Controller Class Initialized
INFO - 2018-02-18 19:16:18 --> Model Class Initialized
INFO - 2018-02-18 19:16:18 --> Model Class Initialized
INFO - 2018-02-18 19:16:18 --> Model Class Initialized
INFO - 2018-02-18 19:16:18 --> Model Class Initialized
INFO - 2018-02-18 19:16:18 --> Model Class Initialized
DEBUG - 2018-02-18 19:16:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:16:52 --> Config Class Initialized
INFO - 2018-02-18 19:16:52 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:16:52 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:16:52 --> Utf8 Class Initialized
INFO - 2018-02-18 19:16:52 --> URI Class Initialized
INFO - 2018-02-18 19:16:52 --> Router Class Initialized
INFO - 2018-02-18 19:16:52 --> Output Class Initialized
INFO - 2018-02-18 19:16:52 --> Security Class Initialized
DEBUG - 2018-02-18 19:16:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:16:52 --> Input Class Initialized
INFO - 2018-02-18 19:16:52 --> Language Class Initialized
INFO - 2018-02-18 19:16:52 --> Loader Class Initialized
INFO - 2018-02-18 19:16:52 --> Helper loaded: url_helper
INFO - 2018-02-18 19:16:52 --> Helper loaded: form_helper
INFO - 2018-02-18 19:16:52 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:16:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:16:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:16:52 --> Form Validation Class Initialized
INFO - 2018-02-18 19:16:52 --> Model Class Initialized
INFO - 2018-02-18 19:16:52 --> Controller Class Initialized
INFO - 2018-02-18 19:16:52 --> Model Class Initialized
INFO - 2018-02-18 19:16:52 --> Model Class Initialized
INFO - 2018-02-18 19:16:52 --> Model Class Initialized
INFO - 2018-02-18 19:16:52 --> Model Class Initialized
INFO - 2018-02-18 19:16:52 --> Model Class Initialized
DEBUG - 2018-02-18 19:16:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:16:52 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 19:16:52 --> Final output sent to browser
DEBUG - 2018-02-18 19:16:52 --> Total execution time: 0.0606
INFO - 2018-02-18 19:16:52 --> Config Class Initialized
INFO - 2018-02-18 19:16:52 --> Hooks Class Initialized
INFO - 2018-02-18 19:16:52 --> Config Class Initialized
INFO - 2018-02-18 19:16:52 --> Hooks Class Initialized
INFO - 2018-02-18 19:16:52 --> Config Class Initialized
INFO - 2018-02-18 19:16:52 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:16:52 --> UTF-8 Support Enabled
DEBUG - 2018-02-18 19:16:52 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:16:52 --> Utf8 Class Initialized
INFO - 2018-02-18 19:16:52 --> Utf8 Class Initialized
DEBUG - 2018-02-18 19:16:52 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:16:52 --> URI Class Initialized
INFO - 2018-02-18 19:16:52 --> Utf8 Class Initialized
INFO - 2018-02-18 19:16:52 --> URI Class Initialized
INFO - 2018-02-18 19:16:52 --> URI Class Initialized
INFO - 2018-02-18 19:16:52 --> Router Class Initialized
INFO - 2018-02-18 19:16:52 --> Router Class Initialized
INFO - 2018-02-18 19:16:52 --> Router Class Initialized
INFO - 2018-02-18 19:16:52 --> Output Class Initialized
INFO - 2018-02-18 19:16:52 --> Output Class Initialized
INFO - 2018-02-18 19:16:52 --> Output Class Initialized
INFO - 2018-02-18 19:16:52 --> Security Class Initialized
INFO - 2018-02-18 19:16:52 --> Security Class Initialized
INFO - 2018-02-18 19:16:52 --> Security Class Initialized
DEBUG - 2018-02-18 19:16:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:16:52 --> Input Class Initialized
DEBUG - 2018-02-18 19:16:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:16:52 --> Language Class Initialized
DEBUG - 2018-02-18 19:16:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:16:52 --> Input Class Initialized
INFO - 2018-02-18 19:16:52 --> Input Class Initialized
INFO - 2018-02-18 19:16:52 --> Language Class Initialized
ERROR - 2018-02-18 19:16:52 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-18 19:16:52 --> Language Class Initialized
ERROR - 2018-02-18 19:16:52 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-18 19:16:52 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-18 19:16:52 --> Config Class Initialized
INFO - 2018-02-18 19:16:52 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:16:52 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:16:52 --> Utf8 Class Initialized
INFO - 2018-02-18 19:16:52 --> URI Class Initialized
INFO - 2018-02-18 19:16:52 --> Router Class Initialized
INFO - 2018-02-18 19:16:52 --> Output Class Initialized
INFO - 2018-02-18 19:16:52 --> Security Class Initialized
DEBUG - 2018-02-18 19:16:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:16:52 --> Input Class Initialized
INFO - 2018-02-18 19:16:52 --> Language Class Initialized
ERROR - 2018-02-18 19:16:52 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-18 19:16:52 --> Config Class Initialized
INFO - 2018-02-18 19:16:52 --> Hooks Class Initialized
INFO - 2018-02-18 19:16:52 --> Config Class Initialized
INFO - 2018-02-18 19:16:52 --> Hooks Class Initialized
INFO - 2018-02-18 19:16:52 --> Config Class Initialized
INFO - 2018-02-18 19:16:52 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:16:52 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:16:52 --> Utf8 Class Initialized
DEBUG - 2018-02-18 19:16:52 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:16:52 --> URI Class Initialized
INFO - 2018-02-18 19:16:52 --> Utf8 Class Initialized
DEBUG - 2018-02-18 19:16:52 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:16:52 --> Utf8 Class Initialized
INFO - 2018-02-18 19:16:52 --> URI Class Initialized
INFO - 2018-02-18 19:16:52 --> URI Class Initialized
INFO - 2018-02-18 19:16:52 --> Router Class Initialized
INFO - 2018-02-18 19:16:52 --> Router Class Initialized
INFO - 2018-02-18 19:16:52 --> Router Class Initialized
INFO - 2018-02-18 19:16:52 --> Output Class Initialized
INFO - 2018-02-18 19:16:52 --> Output Class Initialized
INFO - 2018-02-18 19:16:52 --> Output Class Initialized
INFO - 2018-02-18 19:16:52 --> Security Class Initialized
INFO - 2018-02-18 19:16:52 --> Security Class Initialized
INFO - 2018-02-18 19:16:52 --> Security Class Initialized
DEBUG - 2018-02-18 19:16:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:16:52 --> Input Class Initialized
INFO - 2018-02-18 19:16:52 --> Language Class Initialized
DEBUG - 2018-02-18 19:16:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-18 19:16:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:16:52 --> Input Class Initialized
INFO - 2018-02-18 19:16:52 --> Input Class Initialized
INFO - 2018-02-18 19:16:52 --> Language Class Initialized
INFO - 2018-02-18 19:16:52 --> Language Class Initialized
ERROR - 2018-02-18 19:16:52 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-18 19:16:52 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-18 19:16:52 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-18 19:16:52 --> Config Class Initialized
INFO - 2018-02-18 19:16:52 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:16:52 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:16:52 --> Utf8 Class Initialized
INFO - 2018-02-18 19:16:52 --> URI Class Initialized
INFO - 2018-02-18 19:16:52 --> Router Class Initialized
INFO - 2018-02-18 19:16:52 --> Output Class Initialized
INFO - 2018-02-18 19:16:52 --> Security Class Initialized
DEBUG - 2018-02-18 19:16:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:16:52 --> Input Class Initialized
INFO - 2018-02-18 19:16:52 --> Language Class Initialized
INFO - 2018-02-18 19:16:52 --> Loader Class Initialized
INFO - 2018-02-18 19:16:52 --> Helper loaded: url_helper
INFO - 2018-02-18 19:16:52 --> Helper loaded: form_helper
INFO - 2018-02-18 19:16:52 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:16:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:16:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:16:52 --> Form Validation Class Initialized
INFO - 2018-02-18 19:16:52 --> Model Class Initialized
INFO - 2018-02-18 19:16:52 --> Controller Class Initialized
INFO - 2018-02-18 19:16:52 --> Model Class Initialized
INFO - 2018-02-18 19:16:52 --> Model Class Initialized
INFO - 2018-02-18 19:16:52 --> Model Class Initialized
INFO - 2018-02-18 19:16:52 --> Model Class Initialized
INFO - 2018-02-18 19:16:52 --> Model Class Initialized
DEBUG - 2018-02-18 19:16:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:17:59 --> Config Class Initialized
INFO - 2018-02-18 19:17:59 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:17:59 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:17:59 --> Utf8 Class Initialized
INFO - 2018-02-18 19:17:59 --> URI Class Initialized
INFO - 2018-02-18 19:17:59 --> Router Class Initialized
INFO - 2018-02-18 19:17:59 --> Output Class Initialized
INFO - 2018-02-18 19:17:59 --> Security Class Initialized
DEBUG - 2018-02-18 19:17:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:17:59 --> Input Class Initialized
INFO - 2018-02-18 19:17:59 --> Language Class Initialized
INFO - 2018-02-18 19:17:59 --> Loader Class Initialized
INFO - 2018-02-18 19:17:59 --> Helper loaded: url_helper
INFO - 2018-02-18 19:17:59 --> Helper loaded: form_helper
INFO - 2018-02-18 19:17:59 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:17:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:17:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:17:59 --> Form Validation Class Initialized
INFO - 2018-02-18 19:17:59 --> Model Class Initialized
INFO - 2018-02-18 19:17:59 --> Controller Class Initialized
INFO - 2018-02-18 19:17:59 --> Model Class Initialized
INFO - 2018-02-18 19:17:59 --> Model Class Initialized
INFO - 2018-02-18 19:17:59 --> Model Class Initialized
INFO - 2018-02-18 19:17:59 --> Model Class Initialized
INFO - 2018-02-18 19:17:59 --> Model Class Initialized
DEBUG - 2018-02-18 19:17:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:17:59 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 19:17:59 --> Final output sent to browser
DEBUG - 2018-02-18 19:17:59 --> Total execution time: 0.0660
INFO - 2018-02-18 19:17:59 --> Config Class Initialized
INFO - 2018-02-18 19:17:59 --> Hooks Class Initialized
INFO - 2018-02-18 19:17:59 --> Config Class Initialized
INFO - 2018-02-18 19:17:59 --> Hooks Class Initialized
INFO - 2018-02-18 19:17:59 --> Config Class Initialized
INFO - 2018-02-18 19:17:59 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:17:59 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:17:59 --> Config Class Initialized
INFO - 2018-02-18 19:17:59 --> Utf8 Class Initialized
DEBUG - 2018-02-18 19:17:59 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:17:59 --> Hooks Class Initialized
INFO - 2018-02-18 19:17:59 --> Utf8 Class Initialized
INFO - 2018-02-18 19:17:59 --> URI Class Initialized
INFO - 2018-02-18 19:17:59 --> URI Class Initialized
DEBUG - 2018-02-18 19:17:59 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:17:59 --> Utf8 Class Initialized
INFO - 2018-02-18 19:17:59 --> Router Class Initialized
INFO - 2018-02-18 19:17:59 --> Router Class Initialized
DEBUG - 2018-02-18 19:17:59 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:17:59 --> URI Class Initialized
INFO - 2018-02-18 19:17:59 --> Utf8 Class Initialized
INFO - 2018-02-18 19:17:59 --> Output Class Initialized
INFO - 2018-02-18 19:17:59 --> URI Class Initialized
INFO - 2018-02-18 19:17:59 --> Output Class Initialized
INFO - 2018-02-18 19:17:59 --> Router Class Initialized
INFO - 2018-02-18 19:17:59 --> Security Class Initialized
INFO - 2018-02-18 19:17:59 --> Router Class Initialized
INFO - 2018-02-18 19:17:59 --> Security Class Initialized
INFO - 2018-02-18 19:17:59 --> Output Class Initialized
DEBUG - 2018-02-18 19:17:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:17:59 --> Input Class Initialized
DEBUG - 2018-02-18 19:17:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:17:59 --> Output Class Initialized
INFO - 2018-02-18 19:17:59 --> Security Class Initialized
INFO - 2018-02-18 19:17:59 --> Input Class Initialized
INFO - 2018-02-18 19:17:59 --> Language Class Initialized
INFO - 2018-02-18 19:17:59 --> Language Class Initialized
INFO - 2018-02-18 19:17:59 --> Security Class Initialized
DEBUG - 2018-02-18 19:17:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-18 19:17:59 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-18 19:17:59 --> Input Class Initialized
DEBUG - 2018-02-18 19:17:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:17:59 --> Input Class Initialized
ERROR - 2018-02-18 19:17:59 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-18 19:17:59 --> Language Class Initialized
INFO - 2018-02-18 19:17:59 --> Language Class Initialized
ERROR - 2018-02-18 19:17:59 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-18 19:17:59 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-18 19:17:59 --> Config Class Initialized
INFO - 2018-02-18 19:17:59 --> Hooks Class Initialized
INFO - 2018-02-18 19:17:59 --> Config Class Initialized
INFO - 2018-02-18 19:17:59 --> Config Class Initialized
INFO - 2018-02-18 19:17:59 --> Hooks Class Initialized
INFO - 2018-02-18 19:17:59 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:17:59 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:17:59 --> Utf8 Class Initialized
INFO - 2018-02-18 19:17:59 --> URI Class Initialized
DEBUG - 2018-02-18 19:17:59 --> UTF-8 Support Enabled
DEBUG - 2018-02-18 19:17:59 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:17:59 --> Utf8 Class Initialized
INFO - 2018-02-18 19:17:59 --> Utf8 Class Initialized
INFO - 2018-02-18 19:17:59 --> Router Class Initialized
INFO - 2018-02-18 19:17:59 --> URI Class Initialized
INFO - 2018-02-18 19:17:59 --> URI Class Initialized
INFO - 2018-02-18 19:17:59 --> Output Class Initialized
INFO - 2018-02-18 19:17:59 --> Router Class Initialized
INFO - 2018-02-18 19:17:59 --> Router Class Initialized
INFO - 2018-02-18 19:17:59 --> Security Class Initialized
INFO - 2018-02-18 19:17:59 --> Output Class Initialized
INFO - 2018-02-18 19:17:59 --> Output Class Initialized
DEBUG - 2018-02-18 19:17:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:17:59 --> Input Class Initialized
INFO - 2018-02-18 19:17:59 --> Security Class Initialized
INFO - 2018-02-18 19:17:59 --> Security Class Initialized
INFO - 2018-02-18 19:17:59 --> Language Class Initialized
DEBUG - 2018-02-18 19:17:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:17:59 --> Input Class Initialized
DEBUG - 2018-02-18 19:17:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-18 19:17:59 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-18 19:17:59 --> Language Class Initialized
INFO - 2018-02-18 19:17:59 --> Input Class Initialized
INFO - 2018-02-18 19:17:59 --> Language Class Initialized
ERROR - 2018-02-18 19:17:59 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-18 19:17:59 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-18 19:17:59 --> Config Class Initialized
INFO - 2018-02-18 19:17:59 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:17:59 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:17:59 --> Utf8 Class Initialized
INFO - 2018-02-18 19:17:59 --> URI Class Initialized
INFO - 2018-02-18 19:17:59 --> Router Class Initialized
INFO - 2018-02-18 19:17:59 --> Output Class Initialized
INFO - 2018-02-18 19:17:59 --> Security Class Initialized
DEBUG - 2018-02-18 19:17:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:17:59 --> Input Class Initialized
INFO - 2018-02-18 19:17:59 --> Language Class Initialized
INFO - 2018-02-18 19:17:59 --> Loader Class Initialized
INFO - 2018-02-18 19:17:59 --> Helper loaded: url_helper
INFO - 2018-02-18 19:17:59 --> Helper loaded: form_helper
INFO - 2018-02-18 19:17:59 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:17:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:17:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:17:59 --> Form Validation Class Initialized
INFO - 2018-02-18 19:17:59 --> Model Class Initialized
INFO - 2018-02-18 19:17:59 --> Controller Class Initialized
INFO - 2018-02-18 19:17:59 --> Model Class Initialized
INFO - 2018-02-18 19:17:59 --> Model Class Initialized
INFO - 2018-02-18 19:17:59 --> Model Class Initialized
INFO - 2018-02-18 19:17:59 --> Model Class Initialized
INFO - 2018-02-18 19:17:59 --> Model Class Initialized
DEBUG - 2018-02-18 19:17:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:18:26 --> Config Class Initialized
INFO - 2018-02-18 19:18:26 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:18:26 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:18:26 --> Utf8 Class Initialized
INFO - 2018-02-18 19:18:26 --> URI Class Initialized
INFO - 2018-02-18 19:18:26 --> Router Class Initialized
INFO - 2018-02-18 19:18:26 --> Output Class Initialized
INFO - 2018-02-18 19:18:26 --> Security Class Initialized
DEBUG - 2018-02-18 19:18:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:18:26 --> Input Class Initialized
INFO - 2018-02-18 19:18:26 --> Language Class Initialized
INFO - 2018-02-18 19:18:26 --> Loader Class Initialized
INFO - 2018-02-18 19:18:26 --> Helper loaded: url_helper
INFO - 2018-02-18 19:18:26 --> Helper loaded: form_helper
INFO - 2018-02-18 19:18:26 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:18:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:18:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:18:26 --> Form Validation Class Initialized
INFO - 2018-02-18 19:18:26 --> Model Class Initialized
INFO - 2018-02-18 19:18:26 --> Controller Class Initialized
INFO - 2018-02-18 19:18:26 --> Model Class Initialized
INFO - 2018-02-18 19:18:26 --> Model Class Initialized
INFO - 2018-02-18 19:18:26 --> Model Class Initialized
INFO - 2018-02-18 19:18:26 --> Model Class Initialized
INFO - 2018-02-18 19:18:26 --> Model Class Initialized
DEBUG - 2018-02-18 19:18:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:18:26 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 19:18:26 --> Final output sent to browser
DEBUG - 2018-02-18 19:18:26 --> Total execution time: 0.0668
INFO - 2018-02-18 19:18:26 --> Config Class Initialized
INFO - 2018-02-18 19:18:26 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:18:26 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:18:26 --> Utf8 Class Initialized
INFO - 2018-02-18 19:18:26 --> URI Class Initialized
INFO - 2018-02-18 19:18:26 --> Router Class Initialized
INFO - 2018-02-18 19:18:26 --> Output Class Initialized
INFO - 2018-02-18 19:18:26 --> Security Class Initialized
DEBUG - 2018-02-18 19:18:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:18:26 --> Input Class Initialized
INFO - 2018-02-18 19:18:26 --> Language Class Initialized
INFO - 2018-02-18 19:18:26 --> Loader Class Initialized
INFO - 2018-02-18 19:18:26 --> Helper loaded: url_helper
INFO - 2018-02-18 19:18:26 --> Helper loaded: form_helper
INFO - 2018-02-18 19:18:26 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:18:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:18:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:18:26 --> Form Validation Class Initialized
INFO - 2018-02-18 19:18:26 --> Model Class Initialized
INFO - 2018-02-18 19:18:26 --> Controller Class Initialized
INFO - 2018-02-18 19:18:26 --> Model Class Initialized
INFO - 2018-02-18 19:18:26 --> Model Class Initialized
INFO - 2018-02-18 19:18:26 --> Model Class Initialized
INFO - 2018-02-18 19:18:26 --> Model Class Initialized
INFO - 2018-02-18 19:18:26 --> Model Class Initialized
DEBUG - 2018-02-18 19:18:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:18:33 --> Config Class Initialized
INFO - 2018-02-18 19:18:33 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:18:33 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:18:33 --> Utf8 Class Initialized
INFO - 2018-02-18 19:18:33 --> URI Class Initialized
INFO - 2018-02-18 19:18:33 --> Router Class Initialized
INFO - 2018-02-18 19:18:33 --> Output Class Initialized
INFO - 2018-02-18 19:18:33 --> Security Class Initialized
DEBUG - 2018-02-18 19:18:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:18:33 --> Input Class Initialized
INFO - 2018-02-18 19:18:33 --> Language Class Initialized
INFO - 2018-02-18 19:18:33 --> Loader Class Initialized
INFO - 2018-02-18 19:18:33 --> Helper loaded: url_helper
INFO - 2018-02-18 19:18:33 --> Helper loaded: form_helper
INFO - 2018-02-18 19:18:33 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:18:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:18:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:18:33 --> Form Validation Class Initialized
INFO - 2018-02-18 19:18:33 --> Model Class Initialized
INFO - 2018-02-18 19:18:33 --> Controller Class Initialized
INFO - 2018-02-18 19:18:33 --> Model Class Initialized
INFO - 2018-02-18 19:18:33 --> Model Class Initialized
INFO - 2018-02-18 19:18:33 --> Model Class Initialized
INFO - 2018-02-18 19:18:33 --> Model Class Initialized
INFO - 2018-02-18 19:18:33 --> Model Class Initialized
DEBUG - 2018-02-18 19:18:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:18:33 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 19:18:33 --> Final output sent to browser
DEBUG - 2018-02-18 19:18:33 --> Total execution time: 0.0583
INFO - 2018-02-18 19:18:33 --> Config Class Initialized
INFO - 2018-02-18 19:18:33 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:18:33 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:18:33 --> Utf8 Class Initialized
INFO - 2018-02-18 19:18:33 --> URI Class Initialized
INFO - 2018-02-18 19:18:33 --> Router Class Initialized
INFO - 2018-02-18 19:18:33 --> Output Class Initialized
INFO - 2018-02-18 19:18:33 --> Security Class Initialized
DEBUG - 2018-02-18 19:18:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:18:33 --> Input Class Initialized
INFO - 2018-02-18 19:18:33 --> Language Class Initialized
INFO - 2018-02-18 19:18:33 --> Loader Class Initialized
INFO - 2018-02-18 19:18:33 --> Helper loaded: url_helper
INFO - 2018-02-18 19:18:33 --> Helper loaded: form_helper
INFO - 2018-02-18 19:18:33 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:18:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:18:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:18:33 --> Form Validation Class Initialized
INFO - 2018-02-18 19:18:33 --> Model Class Initialized
INFO - 2018-02-18 19:18:33 --> Controller Class Initialized
INFO - 2018-02-18 19:18:33 --> Model Class Initialized
INFO - 2018-02-18 19:18:33 --> Model Class Initialized
INFO - 2018-02-18 19:18:33 --> Model Class Initialized
INFO - 2018-02-18 19:18:33 --> Model Class Initialized
INFO - 2018-02-18 19:18:33 --> Model Class Initialized
DEBUG - 2018-02-18 19:18:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:18:42 --> Config Class Initialized
INFO - 2018-02-18 19:18:42 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:18:42 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:18:42 --> Utf8 Class Initialized
INFO - 2018-02-18 19:18:42 --> URI Class Initialized
INFO - 2018-02-18 19:18:42 --> Router Class Initialized
INFO - 2018-02-18 19:18:42 --> Output Class Initialized
INFO - 2018-02-18 19:18:42 --> Security Class Initialized
DEBUG - 2018-02-18 19:18:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:18:42 --> Input Class Initialized
INFO - 2018-02-18 19:18:42 --> Language Class Initialized
INFO - 2018-02-18 19:18:42 --> Loader Class Initialized
INFO - 2018-02-18 19:18:42 --> Helper loaded: url_helper
INFO - 2018-02-18 19:18:42 --> Helper loaded: form_helper
INFO - 2018-02-18 19:18:42 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:18:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:18:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:18:42 --> Form Validation Class Initialized
INFO - 2018-02-18 19:18:42 --> Model Class Initialized
INFO - 2018-02-18 19:18:42 --> Controller Class Initialized
INFO - 2018-02-18 19:18:42 --> Model Class Initialized
INFO - 2018-02-18 19:18:42 --> Model Class Initialized
INFO - 2018-02-18 19:18:42 --> Model Class Initialized
INFO - 2018-02-18 19:18:42 --> Model Class Initialized
INFO - 2018-02-18 19:18:42 --> Model Class Initialized
DEBUG - 2018-02-18 19:18:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:18:42 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 19:18:42 --> Final output sent to browser
DEBUG - 2018-02-18 19:18:42 --> Total execution time: 0.0462
INFO - 2018-02-18 19:18:43 --> Config Class Initialized
INFO - 2018-02-18 19:18:43 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:18:43 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:18:43 --> Utf8 Class Initialized
INFO - 2018-02-18 19:18:43 --> URI Class Initialized
INFO - 2018-02-18 19:18:43 --> Router Class Initialized
INFO - 2018-02-18 19:18:43 --> Output Class Initialized
INFO - 2018-02-18 19:18:43 --> Security Class Initialized
DEBUG - 2018-02-18 19:18:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:18:43 --> Input Class Initialized
INFO - 2018-02-18 19:18:43 --> Language Class Initialized
INFO - 2018-02-18 19:18:43 --> Loader Class Initialized
INFO - 2018-02-18 19:18:43 --> Helper loaded: url_helper
INFO - 2018-02-18 19:18:43 --> Helper loaded: form_helper
INFO - 2018-02-18 19:18:43 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:18:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:18:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:18:43 --> Form Validation Class Initialized
INFO - 2018-02-18 19:18:43 --> Model Class Initialized
INFO - 2018-02-18 19:18:43 --> Controller Class Initialized
INFO - 2018-02-18 19:18:43 --> Model Class Initialized
INFO - 2018-02-18 19:18:43 --> Model Class Initialized
INFO - 2018-02-18 19:18:43 --> Model Class Initialized
INFO - 2018-02-18 19:18:43 --> Model Class Initialized
INFO - 2018-02-18 19:18:43 --> Model Class Initialized
DEBUG - 2018-02-18 19:18:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:18:53 --> Config Class Initialized
INFO - 2018-02-18 19:18:53 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:18:53 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:18:53 --> Utf8 Class Initialized
INFO - 2018-02-18 19:18:53 --> URI Class Initialized
INFO - 2018-02-18 19:18:53 --> Router Class Initialized
INFO - 2018-02-18 19:18:53 --> Output Class Initialized
INFO - 2018-02-18 19:18:53 --> Security Class Initialized
DEBUG - 2018-02-18 19:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:18:53 --> Input Class Initialized
INFO - 2018-02-18 19:18:53 --> Language Class Initialized
INFO - 2018-02-18 19:18:53 --> Loader Class Initialized
INFO - 2018-02-18 19:18:53 --> Helper loaded: url_helper
INFO - 2018-02-18 19:18:53 --> Helper loaded: form_helper
INFO - 2018-02-18 19:18:53 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:18:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:18:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:18:53 --> Form Validation Class Initialized
INFO - 2018-02-18 19:18:53 --> Model Class Initialized
INFO - 2018-02-18 19:18:53 --> Controller Class Initialized
INFO - 2018-02-18 19:18:53 --> Model Class Initialized
INFO - 2018-02-18 19:18:53 --> Model Class Initialized
INFO - 2018-02-18 19:18:53 --> Model Class Initialized
INFO - 2018-02-18 19:18:53 --> Model Class Initialized
INFO - 2018-02-18 19:18:53 --> Model Class Initialized
DEBUG - 2018-02-18 19:18:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:18:53 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 19:18:53 --> Final output sent to browser
DEBUG - 2018-02-18 19:18:53 --> Total execution time: 0.0624
INFO - 2018-02-18 19:18:53 --> Config Class Initialized
INFO - 2018-02-18 19:18:53 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:18:53 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:18:53 --> Utf8 Class Initialized
INFO - 2018-02-18 19:18:53 --> URI Class Initialized
INFO - 2018-02-18 19:18:53 --> Router Class Initialized
INFO - 2018-02-18 19:18:53 --> Output Class Initialized
INFO - 2018-02-18 19:18:53 --> Security Class Initialized
DEBUG - 2018-02-18 19:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:18:53 --> Input Class Initialized
INFO - 2018-02-18 19:18:53 --> Language Class Initialized
INFO - 2018-02-18 19:18:53 --> Loader Class Initialized
INFO - 2018-02-18 19:18:53 --> Helper loaded: url_helper
INFO - 2018-02-18 19:18:53 --> Helper loaded: form_helper
INFO - 2018-02-18 19:18:53 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:18:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:18:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:18:53 --> Form Validation Class Initialized
INFO - 2018-02-18 19:18:53 --> Model Class Initialized
INFO - 2018-02-18 19:18:53 --> Controller Class Initialized
INFO - 2018-02-18 19:18:53 --> Model Class Initialized
INFO - 2018-02-18 19:18:53 --> Model Class Initialized
INFO - 2018-02-18 19:18:53 --> Model Class Initialized
INFO - 2018-02-18 19:18:53 --> Model Class Initialized
INFO - 2018-02-18 19:18:53 --> Model Class Initialized
DEBUG - 2018-02-18 19:18:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:18:55 --> Config Class Initialized
INFO - 2018-02-18 19:18:55 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:18:55 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:18:55 --> Utf8 Class Initialized
INFO - 2018-02-18 19:18:55 --> URI Class Initialized
INFO - 2018-02-18 19:18:55 --> Router Class Initialized
INFO - 2018-02-18 19:18:55 --> Output Class Initialized
INFO - 2018-02-18 19:18:55 --> Security Class Initialized
DEBUG - 2018-02-18 19:18:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:18:55 --> Input Class Initialized
INFO - 2018-02-18 19:18:55 --> Language Class Initialized
INFO - 2018-02-18 19:18:55 --> Loader Class Initialized
INFO - 2018-02-18 19:18:55 --> Helper loaded: url_helper
INFO - 2018-02-18 19:18:55 --> Helper loaded: form_helper
INFO - 2018-02-18 19:18:55 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:18:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:18:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:18:55 --> Form Validation Class Initialized
INFO - 2018-02-18 19:18:55 --> Model Class Initialized
INFO - 2018-02-18 19:18:55 --> Controller Class Initialized
INFO - 2018-02-18 19:18:55 --> Model Class Initialized
INFO - 2018-02-18 19:18:55 --> Model Class Initialized
INFO - 2018-02-18 19:18:55 --> Model Class Initialized
INFO - 2018-02-18 19:18:55 --> Model Class Initialized
INFO - 2018-02-18 19:18:55 --> Model Class Initialized
DEBUG - 2018-02-18 19:18:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:18:55 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 19:18:55 --> Final output sent to browser
DEBUG - 2018-02-18 19:18:55 --> Total execution time: 0.0703
INFO - 2018-02-18 19:18:56 --> Config Class Initialized
INFO - 2018-02-18 19:18:56 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:18:56 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:18:56 --> Utf8 Class Initialized
INFO - 2018-02-18 19:18:56 --> URI Class Initialized
INFO - 2018-02-18 19:18:56 --> Router Class Initialized
INFO - 2018-02-18 19:18:56 --> Output Class Initialized
INFO - 2018-02-18 19:18:56 --> Security Class Initialized
DEBUG - 2018-02-18 19:18:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:18:56 --> Input Class Initialized
INFO - 2018-02-18 19:18:56 --> Language Class Initialized
INFO - 2018-02-18 19:18:56 --> Loader Class Initialized
INFO - 2018-02-18 19:18:56 --> Helper loaded: url_helper
INFO - 2018-02-18 19:18:56 --> Helper loaded: form_helper
INFO - 2018-02-18 19:18:56 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:18:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:18:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:18:56 --> Form Validation Class Initialized
INFO - 2018-02-18 19:18:56 --> Model Class Initialized
INFO - 2018-02-18 19:18:56 --> Controller Class Initialized
INFO - 2018-02-18 19:18:56 --> Model Class Initialized
INFO - 2018-02-18 19:18:56 --> Model Class Initialized
INFO - 2018-02-18 19:18:56 --> Model Class Initialized
INFO - 2018-02-18 19:18:56 --> Model Class Initialized
INFO - 2018-02-18 19:18:56 --> Model Class Initialized
DEBUG - 2018-02-18 19:18:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:19:03 --> Config Class Initialized
INFO - 2018-02-18 19:19:03 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:19:03 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:19:03 --> Utf8 Class Initialized
INFO - 2018-02-18 19:19:03 --> URI Class Initialized
INFO - 2018-02-18 19:19:03 --> Router Class Initialized
INFO - 2018-02-18 19:19:03 --> Output Class Initialized
INFO - 2018-02-18 19:19:03 --> Security Class Initialized
DEBUG - 2018-02-18 19:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:19:03 --> Input Class Initialized
INFO - 2018-02-18 19:19:03 --> Language Class Initialized
INFO - 2018-02-18 19:19:03 --> Loader Class Initialized
INFO - 2018-02-18 19:19:03 --> Helper loaded: url_helper
INFO - 2018-02-18 19:19:03 --> Helper loaded: form_helper
INFO - 2018-02-18 19:19:03 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:19:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:19:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:19:03 --> Form Validation Class Initialized
INFO - 2018-02-18 19:19:03 --> Model Class Initialized
INFO - 2018-02-18 19:19:03 --> Controller Class Initialized
INFO - 2018-02-18 19:19:03 --> Model Class Initialized
INFO - 2018-02-18 19:19:03 --> Model Class Initialized
INFO - 2018-02-18 19:19:03 --> Model Class Initialized
INFO - 2018-02-18 19:19:03 --> Model Class Initialized
INFO - 2018-02-18 19:19:03 --> Model Class Initialized
DEBUG - 2018-02-18 19:19:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:19:03 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 19:19:03 --> Final output sent to browser
DEBUG - 2018-02-18 19:19:03 --> Total execution time: 0.0627
INFO - 2018-02-18 19:19:03 --> Config Class Initialized
INFO - 2018-02-18 19:19:03 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:19:03 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:19:03 --> Utf8 Class Initialized
INFO - 2018-02-18 19:19:03 --> URI Class Initialized
INFO - 2018-02-18 19:19:03 --> Router Class Initialized
INFO - 2018-02-18 19:19:03 --> Output Class Initialized
INFO - 2018-02-18 19:19:03 --> Security Class Initialized
DEBUG - 2018-02-18 19:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:19:03 --> Input Class Initialized
INFO - 2018-02-18 19:19:03 --> Language Class Initialized
INFO - 2018-02-18 19:19:03 --> Loader Class Initialized
INFO - 2018-02-18 19:19:03 --> Helper loaded: url_helper
INFO - 2018-02-18 19:19:03 --> Helper loaded: form_helper
INFO - 2018-02-18 19:19:03 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:19:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:19:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:19:03 --> Form Validation Class Initialized
INFO - 2018-02-18 19:19:03 --> Model Class Initialized
INFO - 2018-02-18 19:19:03 --> Controller Class Initialized
INFO - 2018-02-18 19:19:03 --> Model Class Initialized
INFO - 2018-02-18 19:19:03 --> Model Class Initialized
INFO - 2018-02-18 19:19:03 --> Model Class Initialized
INFO - 2018-02-18 19:19:03 --> Model Class Initialized
INFO - 2018-02-18 19:19:03 --> Model Class Initialized
DEBUG - 2018-02-18 19:19:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:20:29 --> Config Class Initialized
INFO - 2018-02-18 19:20:29 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:20:29 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:20:29 --> Utf8 Class Initialized
INFO - 2018-02-18 19:20:29 --> URI Class Initialized
INFO - 2018-02-18 19:20:29 --> Router Class Initialized
INFO - 2018-02-18 19:20:29 --> Output Class Initialized
INFO - 2018-02-18 19:20:29 --> Security Class Initialized
DEBUG - 2018-02-18 19:20:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:20:29 --> Input Class Initialized
INFO - 2018-02-18 19:20:29 --> Language Class Initialized
INFO - 2018-02-18 19:20:29 --> Loader Class Initialized
INFO - 2018-02-18 19:20:29 --> Helper loaded: url_helper
INFO - 2018-02-18 19:20:29 --> Helper loaded: form_helper
INFO - 2018-02-18 19:20:29 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:20:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:20:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:20:29 --> Form Validation Class Initialized
INFO - 2018-02-18 19:20:29 --> Model Class Initialized
INFO - 2018-02-18 19:20:29 --> Controller Class Initialized
INFO - 2018-02-18 19:20:29 --> Model Class Initialized
INFO - 2018-02-18 19:20:29 --> Model Class Initialized
INFO - 2018-02-18 19:20:29 --> Model Class Initialized
INFO - 2018-02-18 19:20:29 --> Model Class Initialized
INFO - 2018-02-18 19:20:29 --> Model Class Initialized
DEBUG - 2018-02-18 19:20:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:20:29 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 19:20:29 --> Final output sent to browser
DEBUG - 2018-02-18 19:20:29 --> Total execution time: 0.0607
INFO - 2018-02-18 19:20:30 --> Config Class Initialized
INFO - 2018-02-18 19:20:30 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:20:30 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:20:30 --> Utf8 Class Initialized
INFO - 2018-02-18 19:20:30 --> URI Class Initialized
INFO - 2018-02-18 19:20:30 --> Router Class Initialized
INFO - 2018-02-18 19:20:30 --> Output Class Initialized
INFO - 2018-02-18 19:20:30 --> Security Class Initialized
DEBUG - 2018-02-18 19:20:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:20:30 --> Input Class Initialized
INFO - 2018-02-18 19:20:30 --> Language Class Initialized
INFO - 2018-02-18 19:20:30 --> Loader Class Initialized
INFO - 2018-02-18 19:20:30 --> Helper loaded: url_helper
INFO - 2018-02-18 19:20:30 --> Helper loaded: form_helper
INFO - 2018-02-18 19:20:30 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:20:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:20:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:20:30 --> Form Validation Class Initialized
INFO - 2018-02-18 19:20:30 --> Model Class Initialized
INFO - 2018-02-18 19:20:30 --> Controller Class Initialized
INFO - 2018-02-18 19:20:30 --> Model Class Initialized
INFO - 2018-02-18 19:20:30 --> Model Class Initialized
INFO - 2018-02-18 19:20:30 --> Model Class Initialized
INFO - 2018-02-18 19:20:30 --> Model Class Initialized
INFO - 2018-02-18 19:20:30 --> Model Class Initialized
DEBUG - 2018-02-18 19:20:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:22:22 --> Config Class Initialized
INFO - 2018-02-18 19:22:22 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:22:22 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:22:22 --> Utf8 Class Initialized
INFO - 2018-02-18 19:22:22 --> URI Class Initialized
INFO - 2018-02-18 19:22:22 --> Router Class Initialized
INFO - 2018-02-18 19:22:22 --> Output Class Initialized
INFO - 2018-02-18 19:22:22 --> Security Class Initialized
DEBUG - 2018-02-18 19:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:22:22 --> Input Class Initialized
INFO - 2018-02-18 19:22:22 --> Language Class Initialized
INFO - 2018-02-18 19:22:22 --> Loader Class Initialized
INFO - 2018-02-18 19:22:22 --> Helper loaded: url_helper
INFO - 2018-02-18 19:22:22 --> Helper loaded: form_helper
INFO - 2018-02-18 19:22:22 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:22:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:22:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:22:22 --> Form Validation Class Initialized
INFO - 2018-02-18 19:22:22 --> Model Class Initialized
INFO - 2018-02-18 19:22:22 --> Controller Class Initialized
INFO - 2018-02-18 19:22:22 --> Model Class Initialized
INFO - 2018-02-18 19:22:22 --> Model Class Initialized
INFO - 2018-02-18 19:22:22 --> Model Class Initialized
INFO - 2018-02-18 19:22:22 --> Model Class Initialized
INFO - 2018-02-18 19:22:22 --> Model Class Initialized
DEBUG - 2018-02-18 19:22:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:22:22 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 19:22:22 --> Final output sent to browser
DEBUG - 2018-02-18 19:22:22 --> Total execution time: 0.0634
INFO - 2018-02-18 19:22:23 --> Config Class Initialized
INFO - 2018-02-18 19:22:23 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:22:23 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:22:23 --> Utf8 Class Initialized
INFO - 2018-02-18 19:22:23 --> URI Class Initialized
INFO - 2018-02-18 19:22:23 --> Router Class Initialized
INFO - 2018-02-18 19:22:23 --> Output Class Initialized
INFO - 2018-02-18 19:22:23 --> Security Class Initialized
DEBUG - 2018-02-18 19:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:22:23 --> Input Class Initialized
INFO - 2018-02-18 19:22:23 --> Language Class Initialized
INFO - 2018-02-18 19:22:23 --> Loader Class Initialized
INFO - 2018-02-18 19:22:23 --> Helper loaded: url_helper
INFO - 2018-02-18 19:22:23 --> Helper loaded: form_helper
INFO - 2018-02-18 19:22:23 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:22:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:22:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:22:23 --> Form Validation Class Initialized
INFO - 2018-02-18 19:22:23 --> Model Class Initialized
INFO - 2018-02-18 19:22:23 --> Controller Class Initialized
INFO - 2018-02-18 19:22:23 --> Model Class Initialized
INFO - 2018-02-18 19:22:23 --> Model Class Initialized
INFO - 2018-02-18 19:22:23 --> Model Class Initialized
INFO - 2018-02-18 19:22:23 --> Model Class Initialized
INFO - 2018-02-18 19:22:23 --> Model Class Initialized
DEBUG - 2018-02-18 19:22:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:24:44 --> Config Class Initialized
INFO - 2018-02-18 19:24:44 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:24:44 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:24:44 --> Utf8 Class Initialized
INFO - 2018-02-18 19:24:44 --> URI Class Initialized
INFO - 2018-02-18 19:24:44 --> Router Class Initialized
INFO - 2018-02-18 19:24:44 --> Output Class Initialized
INFO - 2018-02-18 19:24:44 --> Security Class Initialized
DEBUG - 2018-02-18 19:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:24:44 --> Input Class Initialized
INFO - 2018-02-18 19:24:44 --> Language Class Initialized
INFO - 2018-02-18 19:24:44 --> Loader Class Initialized
INFO - 2018-02-18 19:24:44 --> Helper loaded: url_helper
INFO - 2018-02-18 19:24:44 --> Helper loaded: form_helper
INFO - 2018-02-18 19:24:44 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:24:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:24:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:24:44 --> Form Validation Class Initialized
INFO - 2018-02-18 19:24:44 --> Model Class Initialized
INFO - 2018-02-18 19:24:44 --> Controller Class Initialized
INFO - 2018-02-18 19:24:44 --> Model Class Initialized
INFO - 2018-02-18 19:24:44 --> Model Class Initialized
INFO - 2018-02-18 19:24:44 --> Model Class Initialized
INFO - 2018-02-18 19:24:44 --> Model Class Initialized
INFO - 2018-02-18 19:24:44 --> Model Class Initialized
DEBUG - 2018-02-18 19:24:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:24:44 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 19:24:44 --> Final output sent to browser
DEBUG - 2018-02-18 19:24:44 --> Total execution time: 0.0550
INFO - 2018-02-18 19:24:44 --> Config Class Initialized
INFO - 2018-02-18 19:24:44 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:24:44 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:24:44 --> Utf8 Class Initialized
INFO - 2018-02-18 19:24:44 --> URI Class Initialized
INFO - 2018-02-18 19:24:44 --> Router Class Initialized
INFO - 2018-02-18 19:24:44 --> Output Class Initialized
INFO - 2018-02-18 19:24:44 --> Security Class Initialized
DEBUG - 2018-02-18 19:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:24:44 --> Input Class Initialized
INFO - 2018-02-18 19:24:44 --> Language Class Initialized
INFO - 2018-02-18 19:24:44 --> Loader Class Initialized
INFO - 2018-02-18 19:24:44 --> Helper loaded: url_helper
INFO - 2018-02-18 19:24:44 --> Helper loaded: form_helper
INFO - 2018-02-18 19:24:44 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:24:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:24:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:24:44 --> Form Validation Class Initialized
INFO - 2018-02-18 19:24:44 --> Model Class Initialized
INFO - 2018-02-18 19:24:44 --> Controller Class Initialized
INFO - 2018-02-18 19:24:44 --> Model Class Initialized
INFO - 2018-02-18 19:24:44 --> Model Class Initialized
INFO - 2018-02-18 19:24:44 --> Model Class Initialized
INFO - 2018-02-18 19:24:44 --> Model Class Initialized
INFO - 2018-02-18 19:24:44 --> Model Class Initialized
DEBUG - 2018-02-18 19:24:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:24:50 --> Config Class Initialized
INFO - 2018-02-18 19:24:50 --> Hooks Class Initialized
INFO - 2018-02-18 19:24:50 --> Config Class Initialized
INFO - 2018-02-18 19:24:50 --> Hooks Class Initialized
INFO - 2018-02-18 19:24:50 --> Config Class Initialized
INFO - 2018-02-18 19:24:50 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:24:50 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:24:50 --> Utf8 Class Initialized
DEBUG - 2018-02-18 19:24:50 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:24:50 --> Utf8 Class Initialized
DEBUG - 2018-02-18 19:24:50 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:24:50 --> Utf8 Class Initialized
INFO - 2018-02-18 19:24:50 --> Config Class Initialized
INFO - 2018-02-18 19:24:50 --> Hooks Class Initialized
INFO - 2018-02-18 19:24:50 --> URI Class Initialized
INFO - 2018-02-18 19:24:50 --> URI Class Initialized
INFO - 2018-02-18 19:24:50 --> URI Class Initialized
INFO - 2018-02-18 19:24:50 --> Router Class Initialized
INFO - 2018-02-18 19:24:50 --> Router Class Initialized
INFO - 2018-02-18 19:24:50 --> Router Class Initialized
DEBUG - 2018-02-18 19:24:50 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:24:50 --> Utf8 Class Initialized
INFO - 2018-02-18 19:24:50 --> Output Class Initialized
INFO - 2018-02-18 19:24:50 --> URI Class Initialized
INFO - 2018-02-18 19:24:50 --> Output Class Initialized
INFO - 2018-02-18 19:24:50 --> Output Class Initialized
INFO - 2018-02-18 19:24:50 --> Security Class Initialized
INFO - 2018-02-18 19:24:50 --> Router Class Initialized
INFO - 2018-02-18 19:24:50 --> Security Class Initialized
INFO - 2018-02-18 19:24:50 --> Security Class Initialized
DEBUG - 2018-02-18 19:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:24:50 --> Input Class Initialized
INFO - 2018-02-18 19:24:50 --> Output Class Initialized
DEBUG - 2018-02-18 19:24:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-18 19:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:24:50 --> Input Class Initialized
INFO - 2018-02-18 19:24:50 --> Input Class Initialized
INFO - 2018-02-18 19:24:50 --> Language Class Initialized
INFO - 2018-02-18 19:24:50 --> Language Class Initialized
INFO - 2018-02-18 19:24:50 --> Language Class Initialized
INFO - 2018-02-18 19:24:50 --> Security Class Initialized
ERROR - 2018-02-18 19:24:50 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-18 19:24:50 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-18 19:24:50 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-02-18 19:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:24:50 --> Input Class Initialized
INFO - 2018-02-18 19:24:50 --> Language Class Initialized
ERROR - 2018-02-18 19:24:50 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-18 19:24:50 --> Config Class Initialized
INFO - 2018-02-18 19:24:50 --> Hooks Class Initialized
INFO - 2018-02-18 19:24:50 --> Config Class Initialized
INFO - 2018-02-18 19:24:50 --> Hooks Class Initialized
INFO - 2018-02-18 19:24:50 --> Config Class Initialized
INFO - 2018-02-18 19:24:50 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:24:50 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:24:50 --> Utf8 Class Initialized
DEBUG - 2018-02-18 19:24:50 --> UTF-8 Support Enabled
DEBUG - 2018-02-18 19:24:50 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:24:50 --> Utf8 Class Initialized
INFO - 2018-02-18 19:24:50 --> URI Class Initialized
INFO - 2018-02-18 19:24:50 --> Utf8 Class Initialized
INFO - 2018-02-18 19:24:50 --> URI Class Initialized
INFO - 2018-02-18 19:24:50 --> URI Class Initialized
INFO - 2018-02-18 19:24:50 --> Router Class Initialized
INFO - 2018-02-18 19:24:50 --> Router Class Initialized
INFO - 2018-02-18 19:24:50 --> Output Class Initialized
INFO - 2018-02-18 19:24:50 --> Router Class Initialized
INFO - 2018-02-18 19:24:50 --> Output Class Initialized
INFO - 2018-02-18 19:24:50 --> Security Class Initialized
INFO - 2018-02-18 19:24:50 --> Security Class Initialized
DEBUG - 2018-02-18 19:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:24:50 --> Input Class Initialized
INFO - 2018-02-18 19:24:50 --> Output Class Initialized
INFO - 2018-02-18 19:24:50 --> Language Class Initialized
DEBUG - 2018-02-18 19:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:24:50 --> Input Class Initialized
INFO - 2018-02-18 19:24:50 --> Security Class Initialized
INFO - 2018-02-18 19:24:50 --> Language Class Initialized
ERROR - 2018-02-18 19:24:50 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-02-18 19:24:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-18 19:24:50 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-18 19:24:50 --> Input Class Initialized
INFO - 2018-02-18 19:24:50 --> Language Class Initialized
ERROR - 2018-02-18 19:24:50 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-18 19:24:52 --> Config Class Initialized
INFO - 2018-02-18 19:24:52 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:24:52 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:24:52 --> Utf8 Class Initialized
INFO - 2018-02-18 19:24:52 --> URI Class Initialized
INFO - 2018-02-18 19:24:52 --> Router Class Initialized
INFO - 2018-02-18 19:24:52 --> Output Class Initialized
INFO - 2018-02-18 19:24:52 --> Security Class Initialized
DEBUG - 2018-02-18 19:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:24:52 --> Input Class Initialized
INFO - 2018-02-18 19:24:52 --> Language Class Initialized
INFO - 2018-02-18 19:24:52 --> Loader Class Initialized
INFO - 2018-02-18 19:24:52 --> Helper loaded: url_helper
INFO - 2018-02-18 19:24:52 --> Helper loaded: form_helper
INFO - 2018-02-18 19:24:52 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:24:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:24:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:24:52 --> Form Validation Class Initialized
INFO - 2018-02-18 19:24:52 --> Model Class Initialized
INFO - 2018-02-18 19:24:52 --> Controller Class Initialized
INFO - 2018-02-18 19:24:52 --> Model Class Initialized
INFO - 2018-02-18 19:24:52 --> Model Class Initialized
INFO - 2018-02-18 19:24:52 --> Model Class Initialized
INFO - 2018-02-18 19:24:52 --> Model Class Initialized
INFO - 2018-02-18 19:24:52 --> Model Class Initialized
DEBUG - 2018-02-18 19:24:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:24:52 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 19:24:52 --> Final output sent to browser
DEBUG - 2018-02-18 19:24:52 --> Total execution time: 0.0483
INFO - 2018-02-18 19:24:53 --> Config Class Initialized
INFO - 2018-02-18 19:24:53 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:24:53 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:24:53 --> Utf8 Class Initialized
INFO - 2018-02-18 19:24:53 --> URI Class Initialized
INFO - 2018-02-18 19:24:53 --> Router Class Initialized
INFO - 2018-02-18 19:24:53 --> Output Class Initialized
INFO - 2018-02-18 19:24:53 --> Security Class Initialized
DEBUG - 2018-02-18 19:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:24:53 --> Input Class Initialized
INFO - 2018-02-18 19:24:53 --> Language Class Initialized
INFO - 2018-02-18 19:24:53 --> Loader Class Initialized
INFO - 2018-02-18 19:24:53 --> Helper loaded: url_helper
INFO - 2018-02-18 19:24:53 --> Helper loaded: form_helper
INFO - 2018-02-18 19:24:53 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:24:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:24:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:24:53 --> Form Validation Class Initialized
INFO - 2018-02-18 19:24:53 --> Model Class Initialized
INFO - 2018-02-18 19:24:53 --> Controller Class Initialized
INFO - 2018-02-18 19:24:53 --> Model Class Initialized
INFO - 2018-02-18 19:24:53 --> Model Class Initialized
INFO - 2018-02-18 19:24:53 --> Model Class Initialized
INFO - 2018-02-18 19:24:53 --> Model Class Initialized
INFO - 2018-02-18 19:24:53 --> Model Class Initialized
DEBUG - 2018-02-18 19:24:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:30:01 --> Config Class Initialized
INFO - 2018-02-18 19:30:01 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:30:01 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:30:01 --> Utf8 Class Initialized
INFO - 2018-02-18 19:30:01 --> URI Class Initialized
INFO - 2018-02-18 19:30:01 --> Router Class Initialized
INFO - 2018-02-18 19:30:01 --> Output Class Initialized
INFO - 2018-02-18 19:30:01 --> Security Class Initialized
DEBUG - 2018-02-18 19:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:30:01 --> Input Class Initialized
INFO - 2018-02-18 19:30:01 --> Language Class Initialized
INFO - 2018-02-18 19:30:01 --> Loader Class Initialized
INFO - 2018-02-18 19:30:01 --> Helper loaded: url_helper
INFO - 2018-02-18 19:30:01 --> Helper loaded: form_helper
INFO - 2018-02-18 19:30:01 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:30:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:30:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:30:01 --> Form Validation Class Initialized
INFO - 2018-02-18 19:30:01 --> Model Class Initialized
INFO - 2018-02-18 19:30:01 --> Controller Class Initialized
INFO - 2018-02-18 19:30:01 --> Model Class Initialized
INFO - 2018-02-18 19:30:01 --> Model Class Initialized
INFO - 2018-02-18 19:30:01 --> Model Class Initialized
INFO - 2018-02-18 19:30:01 --> Model Class Initialized
INFO - 2018-02-18 19:30:01 --> Model Class Initialized
DEBUG - 2018-02-18 19:30:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:30:02 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 19:30:02 --> Final output sent to browser
DEBUG - 2018-02-18 19:30:02 --> Total execution time: 0.3412
INFO - 2018-02-18 19:30:04 --> Config Class Initialized
INFO - 2018-02-18 19:30:04 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:30:04 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:30:04 --> Utf8 Class Initialized
INFO - 2018-02-18 19:30:04 --> URI Class Initialized
INFO - 2018-02-18 19:30:04 --> Router Class Initialized
INFO - 2018-02-18 19:30:04 --> Output Class Initialized
INFO - 2018-02-18 19:30:04 --> Security Class Initialized
DEBUG - 2018-02-18 19:30:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:30:04 --> Input Class Initialized
INFO - 2018-02-18 19:30:04 --> Language Class Initialized
INFO - 2018-02-18 19:30:04 --> Loader Class Initialized
INFO - 2018-02-18 19:30:04 --> Helper loaded: url_helper
INFO - 2018-02-18 19:30:04 --> Helper loaded: form_helper
INFO - 2018-02-18 19:30:04 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:30:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:30:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:30:04 --> Form Validation Class Initialized
INFO - 2018-02-18 19:30:04 --> Model Class Initialized
INFO - 2018-02-18 19:30:04 --> Controller Class Initialized
INFO - 2018-02-18 19:30:04 --> Model Class Initialized
INFO - 2018-02-18 19:30:04 --> Model Class Initialized
INFO - 2018-02-18 19:30:04 --> Model Class Initialized
INFO - 2018-02-18 19:30:04 --> Model Class Initialized
INFO - 2018-02-18 19:30:04 --> Model Class Initialized
DEBUG - 2018-02-18 19:30:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:30:04 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 19:30:04 --> Final output sent to browser
DEBUG - 2018-02-18 19:30:04 --> Total execution time: 0.0732
INFO - 2018-02-18 19:30:04 --> Config Class Initialized
INFO - 2018-02-18 19:30:04 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:30:04 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:30:04 --> Utf8 Class Initialized
INFO - 2018-02-18 19:30:04 --> URI Class Initialized
INFO - 2018-02-18 19:30:04 --> Router Class Initialized
INFO - 2018-02-18 19:30:04 --> Output Class Initialized
INFO - 2018-02-18 19:30:04 --> Security Class Initialized
DEBUG - 2018-02-18 19:30:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:30:04 --> Input Class Initialized
INFO - 2018-02-18 19:30:04 --> Language Class Initialized
INFO - 2018-02-18 19:30:04 --> Loader Class Initialized
INFO - 2018-02-18 19:30:04 --> Helper loaded: url_helper
INFO - 2018-02-18 19:30:04 --> Helper loaded: form_helper
INFO - 2018-02-18 19:30:04 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:30:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:30:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:30:04 --> Form Validation Class Initialized
INFO - 2018-02-18 19:30:04 --> Model Class Initialized
INFO - 2018-02-18 19:30:04 --> Controller Class Initialized
INFO - 2018-02-18 19:30:04 --> Model Class Initialized
INFO - 2018-02-18 19:30:04 --> Model Class Initialized
INFO - 2018-02-18 19:30:04 --> Model Class Initialized
INFO - 2018-02-18 19:30:04 --> Model Class Initialized
INFO - 2018-02-18 19:30:04 --> Model Class Initialized
DEBUG - 2018-02-18 19:30:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:30:08 --> Config Class Initialized
INFO - 2018-02-18 19:30:08 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:30:08 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:30:08 --> Utf8 Class Initialized
INFO - 2018-02-18 19:30:08 --> URI Class Initialized
INFO - 2018-02-18 19:30:08 --> Router Class Initialized
INFO - 2018-02-18 19:30:08 --> Output Class Initialized
INFO - 2018-02-18 19:30:08 --> Security Class Initialized
DEBUG - 2018-02-18 19:30:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:30:08 --> Input Class Initialized
INFO - 2018-02-18 19:30:08 --> Language Class Initialized
INFO - 2018-02-18 19:30:08 --> Loader Class Initialized
INFO - 2018-02-18 19:30:08 --> Helper loaded: url_helper
INFO - 2018-02-18 19:30:08 --> Helper loaded: form_helper
INFO - 2018-02-18 19:30:08 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:30:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:30:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:30:08 --> Form Validation Class Initialized
INFO - 2018-02-18 19:30:08 --> Model Class Initialized
INFO - 2018-02-18 19:30:08 --> Controller Class Initialized
INFO - 2018-02-18 19:30:08 --> Model Class Initialized
INFO - 2018-02-18 19:30:08 --> Model Class Initialized
INFO - 2018-02-18 19:30:08 --> Model Class Initialized
INFO - 2018-02-18 19:30:08 --> Model Class Initialized
INFO - 2018-02-18 19:30:08 --> Model Class Initialized
DEBUG - 2018-02-18 19:30:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:30:08 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 19:30:08 --> Final output sent to browser
DEBUG - 2018-02-18 19:30:08 --> Total execution time: 0.0647
INFO - 2018-02-18 19:30:08 --> Config Class Initialized
INFO - 2018-02-18 19:30:08 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:30:08 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:30:08 --> Utf8 Class Initialized
INFO - 2018-02-18 19:30:08 --> URI Class Initialized
INFO - 2018-02-18 19:30:08 --> Router Class Initialized
INFO - 2018-02-18 19:30:08 --> Output Class Initialized
INFO - 2018-02-18 19:30:08 --> Security Class Initialized
DEBUG - 2018-02-18 19:30:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:30:08 --> Input Class Initialized
INFO - 2018-02-18 19:30:08 --> Language Class Initialized
INFO - 2018-02-18 19:30:08 --> Loader Class Initialized
INFO - 2018-02-18 19:30:08 --> Helper loaded: url_helper
INFO - 2018-02-18 19:30:08 --> Helper loaded: form_helper
INFO - 2018-02-18 19:30:08 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:30:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:30:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:30:09 --> Form Validation Class Initialized
INFO - 2018-02-18 19:30:09 --> Model Class Initialized
INFO - 2018-02-18 19:30:09 --> Controller Class Initialized
INFO - 2018-02-18 19:30:09 --> Model Class Initialized
INFO - 2018-02-18 19:30:09 --> Model Class Initialized
INFO - 2018-02-18 19:30:09 --> Model Class Initialized
INFO - 2018-02-18 19:30:09 --> Model Class Initialized
INFO - 2018-02-18 19:30:09 --> Model Class Initialized
DEBUG - 2018-02-18 19:30:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:31:07 --> Config Class Initialized
INFO - 2018-02-18 19:31:07 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:31:07 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:31:07 --> Utf8 Class Initialized
INFO - 2018-02-18 19:31:07 --> URI Class Initialized
INFO - 2018-02-18 19:31:07 --> Router Class Initialized
INFO - 2018-02-18 19:31:07 --> Output Class Initialized
INFO - 2018-02-18 19:31:07 --> Security Class Initialized
DEBUG - 2018-02-18 19:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:31:07 --> Input Class Initialized
INFO - 2018-02-18 19:31:07 --> Language Class Initialized
INFO - 2018-02-18 19:31:07 --> Loader Class Initialized
INFO - 2018-02-18 19:31:07 --> Helper loaded: url_helper
INFO - 2018-02-18 19:31:07 --> Helper loaded: form_helper
INFO - 2018-02-18 19:31:07 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:31:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:31:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:31:07 --> Form Validation Class Initialized
INFO - 2018-02-18 19:31:07 --> Model Class Initialized
INFO - 2018-02-18 19:31:07 --> Controller Class Initialized
INFO - 2018-02-18 19:31:07 --> Model Class Initialized
INFO - 2018-02-18 19:31:07 --> Model Class Initialized
INFO - 2018-02-18 19:31:07 --> Model Class Initialized
INFO - 2018-02-18 19:31:07 --> Model Class Initialized
INFO - 2018-02-18 19:31:07 --> Model Class Initialized
DEBUG - 2018-02-18 19:31:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:31:07 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 19:31:07 --> Final output sent to browser
DEBUG - 2018-02-18 19:31:07 --> Total execution time: 0.0638
INFO - 2018-02-18 19:31:07 --> Config Class Initialized
INFO - 2018-02-18 19:31:07 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:31:07 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:31:07 --> Utf8 Class Initialized
INFO - 2018-02-18 19:31:07 --> URI Class Initialized
INFO - 2018-02-18 19:31:07 --> Router Class Initialized
INFO - 2018-02-18 19:31:07 --> Output Class Initialized
INFO - 2018-02-18 19:31:07 --> Security Class Initialized
DEBUG - 2018-02-18 19:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:31:07 --> Input Class Initialized
INFO - 2018-02-18 19:31:07 --> Language Class Initialized
INFO - 2018-02-18 19:31:07 --> Loader Class Initialized
INFO - 2018-02-18 19:31:07 --> Helper loaded: url_helper
INFO - 2018-02-18 19:31:07 --> Helper loaded: form_helper
INFO - 2018-02-18 19:31:07 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:31:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:31:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:31:07 --> Form Validation Class Initialized
INFO - 2018-02-18 19:31:07 --> Model Class Initialized
INFO - 2018-02-18 19:31:07 --> Controller Class Initialized
INFO - 2018-02-18 19:31:07 --> Model Class Initialized
INFO - 2018-02-18 19:31:07 --> Model Class Initialized
INFO - 2018-02-18 19:31:07 --> Model Class Initialized
INFO - 2018-02-18 19:31:07 --> Model Class Initialized
INFO - 2018-02-18 19:31:07 --> Model Class Initialized
DEBUG - 2018-02-18 19:31:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:31:13 --> Config Class Initialized
INFO - 2018-02-18 19:31:13 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:31:13 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:31:13 --> Utf8 Class Initialized
INFO - 2018-02-18 19:31:13 --> URI Class Initialized
INFO - 2018-02-18 19:31:13 --> Router Class Initialized
INFO - 2018-02-18 19:31:13 --> Output Class Initialized
INFO - 2018-02-18 19:31:13 --> Security Class Initialized
DEBUG - 2018-02-18 19:31:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:31:13 --> Input Class Initialized
INFO - 2018-02-18 19:31:13 --> Language Class Initialized
INFO - 2018-02-18 19:31:13 --> Loader Class Initialized
INFO - 2018-02-18 19:31:13 --> Helper loaded: url_helper
INFO - 2018-02-18 19:31:13 --> Helper loaded: form_helper
INFO - 2018-02-18 19:31:13 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:31:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:31:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:31:13 --> Form Validation Class Initialized
INFO - 2018-02-18 19:31:13 --> Model Class Initialized
INFO - 2018-02-18 19:31:13 --> Controller Class Initialized
INFO - 2018-02-18 19:31:13 --> Model Class Initialized
INFO - 2018-02-18 19:31:13 --> Model Class Initialized
INFO - 2018-02-18 19:31:13 --> Model Class Initialized
INFO - 2018-02-18 19:31:13 --> Model Class Initialized
INFO - 2018-02-18 19:31:13 --> Model Class Initialized
DEBUG - 2018-02-18 19:31:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:31:13 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 19:31:13 --> Final output sent to browser
DEBUG - 2018-02-18 19:31:13 --> Total execution time: 0.0513
INFO - 2018-02-18 19:31:13 --> Config Class Initialized
INFO - 2018-02-18 19:31:13 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:31:13 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:31:13 --> Utf8 Class Initialized
INFO - 2018-02-18 19:31:13 --> URI Class Initialized
INFO - 2018-02-18 19:31:13 --> Router Class Initialized
INFO - 2018-02-18 19:31:13 --> Output Class Initialized
INFO - 2018-02-18 19:31:13 --> Security Class Initialized
DEBUG - 2018-02-18 19:31:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:31:13 --> Input Class Initialized
INFO - 2018-02-18 19:31:13 --> Language Class Initialized
INFO - 2018-02-18 19:31:13 --> Loader Class Initialized
INFO - 2018-02-18 19:31:13 --> Helper loaded: url_helper
INFO - 2018-02-18 19:31:13 --> Helper loaded: form_helper
INFO - 2018-02-18 19:31:13 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:31:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:31:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:31:13 --> Form Validation Class Initialized
INFO - 2018-02-18 19:31:13 --> Model Class Initialized
INFO - 2018-02-18 19:31:13 --> Controller Class Initialized
INFO - 2018-02-18 19:31:13 --> Model Class Initialized
INFO - 2018-02-18 19:31:13 --> Model Class Initialized
INFO - 2018-02-18 19:31:13 --> Model Class Initialized
INFO - 2018-02-18 19:31:13 --> Model Class Initialized
INFO - 2018-02-18 19:31:13 --> Model Class Initialized
DEBUG - 2018-02-18 19:31:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:31:45 --> Config Class Initialized
INFO - 2018-02-18 19:31:45 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:31:45 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:31:45 --> Utf8 Class Initialized
INFO - 2018-02-18 19:31:45 --> URI Class Initialized
INFO - 2018-02-18 19:31:45 --> Router Class Initialized
INFO - 2018-02-18 19:31:45 --> Output Class Initialized
INFO - 2018-02-18 19:31:45 --> Security Class Initialized
DEBUG - 2018-02-18 19:31:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:31:45 --> Input Class Initialized
INFO - 2018-02-18 19:31:45 --> Language Class Initialized
INFO - 2018-02-18 19:31:45 --> Loader Class Initialized
INFO - 2018-02-18 19:31:45 --> Helper loaded: url_helper
INFO - 2018-02-18 19:31:45 --> Helper loaded: form_helper
INFO - 2018-02-18 19:31:45 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:31:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:31:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:31:45 --> Form Validation Class Initialized
INFO - 2018-02-18 19:31:45 --> Model Class Initialized
INFO - 2018-02-18 19:31:45 --> Controller Class Initialized
INFO - 2018-02-18 19:31:45 --> Model Class Initialized
INFO - 2018-02-18 19:31:45 --> Model Class Initialized
INFO - 2018-02-18 19:31:45 --> Model Class Initialized
INFO - 2018-02-18 19:31:45 --> Model Class Initialized
INFO - 2018-02-18 19:31:45 --> Model Class Initialized
DEBUG - 2018-02-18 19:31:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:31:45 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 19:31:45 --> Final output sent to browser
DEBUG - 2018-02-18 19:31:45 --> Total execution time: 0.0563
INFO - 2018-02-18 19:31:45 --> Config Class Initialized
INFO - 2018-02-18 19:31:45 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:31:45 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:31:45 --> Utf8 Class Initialized
INFO - 2018-02-18 19:31:45 --> URI Class Initialized
INFO - 2018-02-18 19:31:45 --> Router Class Initialized
INFO - 2018-02-18 19:31:45 --> Output Class Initialized
INFO - 2018-02-18 19:31:45 --> Security Class Initialized
DEBUG - 2018-02-18 19:31:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:31:45 --> Input Class Initialized
INFO - 2018-02-18 19:31:45 --> Language Class Initialized
INFO - 2018-02-18 19:31:45 --> Loader Class Initialized
INFO - 2018-02-18 19:31:45 --> Helper loaded: url_helper
INFO - 2018-02-18 19:31:45 --> Helper loaded: form_helper
INFO - 2018-02-18 19:31:45 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:31:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:31:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:31:45 --> Form Validation Class Initialized
INFO - 2018-02-18 19:31:45 --> Model Class Initialized
INFO - 2018-02-18 19:31:45 --> Controller Class Initialized
INFO - 2018-02-18 19:31:45 --> Model Class Initialized
INFO - 2018-02-18 19:31:45 --> Model Class Initialized
INFO - 2018-02-18 19:31:45 --> Model Class Initialized
INFO - 2018-02-18 19:31:45 --> Model Class Initialized
INFO - 2018-02-18 19:31:45 --> Model Class Initialized
DEBUG - 2018-02-18 19:31:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:32:32 --> Config Class Initialized
INFO - 2018-02-18 19:32:32 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:32:32 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:32:32 --> Utf8 Class Initialized
INFO - 2018-02-18 19:32:32 --> URI Class Initialized
INFO - 2018-02-18 19:32:32 --> Router Class Initialized
INFO - 2018-02-18 19:32:32 --> Output Class Initialized
INFO - 2018-02-18 19:32:32 --> Security Class Initialized
DEBUG - 2018-02-18 19:32:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:32:32 --> Input Class Initialized
INFO - 2018-02-18 19:32:32 --> Language Class Initialized
INFO - 2018-02-18 19:32:32 --> Loader Class Initialized
INFO - 2018-02-18 19:32:32 --> Helper loaded: url_helper
INFO - 2018-02-18 19:32:32 --> Helper loaded: form_helper
INFO - 2018-02-18 19:32:32 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:32:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:32:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:32:32 --> Form Validation Class Initialized
INFO - 2018-02-18 19:32:32 --> Model Class Initialized
INFO - 2018-02-18 19:32:32 --> Controller Class Initialized
INFO - 2018-02-18 19:32:32 --> Model Class Initialized
INFO - 2018-02-18 19:32:32 --> Model Class Initialized
INFO - 2018-02-18 19:32:32 --> Model Class Initialized
INFO - 2018-02-18 19:32:32 --> Model Class Initialized
INFO - 2018-02-18 19:32:32 --> Model Class Initialized
DEBUG - 2018-02-18 19:32:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:32:32 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 19:32:32 --> Final output sent to browser
DEBUG - 2018-02-18 19:32:32 --> Total execution time: 0.0755
INFO - 2018-02-18 19:32:32 --> Config Class Initialized
INFO - 2018-02-18 19:32:32 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:32:32 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:32:32 --> Utf8 Class Initialized
INFO - 2018-02-18 19:32:32 --> URI Class Initialized
INFO - 2018-02-18 19:32:32 --> Router Class Initialized
INFO - 2018-02-18 19:32:32 --> Output Class Initialized
INFO - 2018-02-18 19:32:32 --> Security Class Initialized
DEBUG - 2018-02-18 19:32:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:32:32 --> Input Class Initialized
INFO - 2018-02-18 19:32:32 --> Language Class Initialized
INFO - 2018-02-18 19:32:32 --> Loader Class Initialized
INFO - 2018-02-18 19:32:32 --> Helper loaded: url_helper
INFO - 2018-02-18 19:32:32 --> Helper loaded: form_helper
INFO - 2018-02-18 19:32:32 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:32:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:32:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:32:32 --> Form Validation Class Initialized
INFO - 2018-02-18 19:32:32 --> Model Class Initialized
INFO - 2018-02-18 19:32:32 --> Controller Class Initialized
INFO - 2018-02-18 19:32:32 --> Model Class Initialized
INFO - 2018-02-18 19:32:32 --> Model Class Initialized
INFO - 2018-02-18 19:32:32 --> Model Class Initialized
INFO - 2018-02-18 19:32:32 --> Model Class Initialized
INFO - 2018-02-18 19:32:32 --> Model Class Initialized
DEBUG - 2018-02-18 19:32:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:32:47 --> Config Class Initialized
INFO - 2018-02-18 19:32:47 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:32:47 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:32:47 --> Utf8 Class Initialized
INFO - 2018-02-18 19:32:47 --> URI Class Initialized
INFO - 2018-02-18 19:32:47 --> Router Class Initialized
INFO - 2018-02-18 19:32:47 --> Output Class Initialized
INFO - 2018-02-18 19:32:47 --> Security Class Initialized
DEBUG - 2018-02-18 19:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:32:47 --> Input Class Initialized
INFO - 2018-02-18 19:32:47 --> Language Class Initialized
INFO - 2018-02-18 19:32:48 --> Loader Class Initialized
INFO - 2018-02-18 19:32:48 --> Helper loaded: url_helper
INFO - 2018-02-18 19:32:48 --> Helper loaded: form_helper
INFO - 2018-02-18 19:32:48 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:32:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:32:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:32:48 --> Form Validation Class Initialized
INFO - 2018-02-18 19:32:48 --> Model Class Initialized
INFO - 2018-02-18 19:32:48 --> Controller Class Initialized
INFO - 2018-02-18 19:32:48 --> Model Class Initialized
INFO - 2018-02-18 19:32:48 --> Model Class Initialized
INFO - 2018-02-18 19:32:48 --> Model Class Initialized
INFO - 2018-02-18 19:32:48 --> Model Class Initialized
INFO - 2018-02-18 19:32:48 --> Model Class Initialized
DEBUG - 2018-02-18 19:32:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:32:48 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 19:32:48 --> Final output sent to browser
DEBUG - 2018-02-18 19:32:48 --> Total execution time: 0.0776
INFO - 2018-02-18 19:32:48 --> Config Class Initialized
INFO - 2018-02-18 19:32:48 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:32:48 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:32:48 --> Utf8 Class Initialized
INFO - 2018-02-18 19:32:48 --> URI Class Initialized
INFO - 2018-02-18 19:32:48 --> Router Class Initialized
INFO - 2018-02-18 19:32:48 --> Output Class Initialized
INFO - 2018-02-18 19:32:48 --> Security Class Initialized
DEBUG - 2018-02-18 19:32:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:32:48 --> Input Class Initialized
INFO - 2018-02-18 19:32:48 --> Language Class Initialized
INFO - 2018-02-18 19:32:48 --> Loader Class Initialized
INFO - 2018-02-18 19:32:48 --> Helper loaded: url_helper
INFO - 2018-02-18 19:32:48 --> Helper loaded: form_helper
INFO - 2018-02-18 19:32:48 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:32:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:32:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:32:48 --> Form Validation Class Initialized
INFO - 2018-02-18 19:32:48 --> Model Class Initialized
INFO - 2018-02-18 19:32:48 --> Controller Class Initialized
INFO - 2018-02-18 19:32:48 --> Model Class Initialized
INFO - 2018-02-18 19:32:48 --> Model Class Initialized
INFO - 2018-02-18 19:32:48 --> Model Class Initialized
INFO - 2018-02-18 19:32:48 --> Model Class Initialized
INFO - 2018-02-18 19:32:48 --> Model Class Initialized
DEBUG - 2018-02-18 19:32:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:34:03 --> Config Class Initialized
INFO - 2018-02-18 19:34:03 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:34:03 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:34:03 --> Utf8 Class Initialized
INFO - 2018-02-18 19:34:03 --> URI Class Initialized
INFO - 2018-02-18 19:34:03 --> Router Class Initialized
INFO - 2018-02-18 19:34:03 --> Output Class Initialized
INFO - 2018-02-18 19:34:03 --> Security Class Initialized
DEBUG - 2018-02-18 19:34:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:34:03 --> Input Class Initialized
INFO - 2018-02-18 19:34:03 --> Language Class Initialized
INFO - 2018-02-18 19:34:03 --> Loader Class Initialized
INFO - 2018-02-18 19:34:03 --> Helper loaded: url_helper
INFO - 2018-02-18 19:34:03 --> Helper loaded: form_helper
INFO - 2018-02-18 19:34:03 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:34:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:34:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:34:03 --> Form Validation Class Initialized
INFO - 2018-02-18 19:34:03 --> Model Class Initialized
INFO - 2018-02-18 19:34:03 --> Controller Class Initialized
INFO - 2018-02-18 19:34:03 --> Model Class Initialized
INFO - 2018-02-18 19:34:03 --> Model Class Initialized
INFO - 2018-02-18 19:34:03 --> Model Class Initialized
INFO - 2018-02-18 19:34:03 --> Model Class Initialized
INFO - 2018-02-18 19:34:03 --> Model Class Initialized
DEBUG - 2018-02-18 19:34:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:34:03 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 19:34:03 --> Final output sent to browser
DEBUG - 2018-02-18 19:34:03 --> Total execution time: 0.0508
INFO - 2018-02-18 19:34:03 --> Config Class Initialized
INFO - 2018-02-18 19:34:03 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:34:03 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:34:03 --> Utf8 Class Initialized
INFO - 2018-02-18 19:34:03 --> URI Class Initialized
INFO - 2018-02-18 19:34:03 --> Router Class Initialized
INFO - 2018-02-18 19:34:03 --> Output Class Initialized
INFO - 2018-02-18 19:34:03 --> Security Class Initialized
DEBUG - 2018-02-18 19:34:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:34:03 --> Input Class Initialized
INFO - 2018-02-18 19:34:03 --> Language Class Initialized
INFO - 2018-02-18 19:34:03 --> Loader Class Initialized
INFO - 2018-02-18 19:34:03 --> Helper loaded: url_helper
INFO - 2018-02-18 19:34:03 --> Helper loaded: form_helper
INFO - 2018-02-18 19:34:03 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:34:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:34:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:34:03 --> Form Validation Class Initialized
INFO - 2018-02-18 19:34:03 --> Model Class Initialized
INFO - 2018-02-18 19:34:03 --> Controller Class Initialized
INFO - 2018-02-18 19:34:03 --> Model Class Initialized
INFO - 2018-02-18 19:34:03 --> Model Class Initialized
INFO - 2018-02-18 19:34:03 --> Model Class Initialized
INFO - 2018-02-18 19:34:03 --> Model Class Initialized
INFO - 2018-02-18 19:34:03 --> Model Class Initialized
DEBUG - 2018-02-18 19:34:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:34:46 --> Config Class Initialized
INFO - 2018-02-18 19:34:46 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:34:46 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:34:46 --> Utf8 Class Initialized
INFO - 2018-02-18 19:34:46 --> URI Class Initialized
INFO - 2018-02-18 19:34:46 --> Router Class Initialized
INFO - 2018-02-18 19:34:46 --> Output Class Initialized
INFO - 2018-02-18 19:34:46 --> Security Class Initialized
DEBUG - 2018-02-18 19:34:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:34:46 --> Input Class Initialized
INFO - 2018-02-18 19:34:46 --> Language Class Initialized
INFO - 2018-02-18 19:34:46 --> Loader Class Initialized
INFO - 2018-02-18 19:34:46 --> Helper loaded: url_helper
INFO - 2018-02-18 19:34:46 --> Helper loaded: form_helper
INFO - 2018-02-18 19:34:46 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:34:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:34:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:34:46 --> Form Validation Class Initialized
INFO - 2018-02-18 19:34:46 --> Model Class Initialized
INFO - 2018-02-18 19:34:46 --> Controller Class Initialized
INFO - 2018-02-18 19:34:46 --> Model Class Initialized
INFO - 2018-02-18 19:34:46 --> Model Class Initialized
INFO - 2018-02-18 19:34:46 --> Model Class Initialized
INFO - 2018-02-18 19:34:46 --> Model Class Initialized
INFO - 2018-02-18 19:34:46 --> Model Class Initialized
DEBUG - 2018-02-18 19:34:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:34:46 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 19:34:46 --> Final output sent to browser
DEBUG - 2018-02-18 19:34:46 --> Total execution time: 0.0661
INFO - 2018-02-18 19:34:47 --> Config Class Initialized
INFO - 2018-02-18 19:34:47 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:34:47 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:34:47 --> Utf8 Class Initialized
INFO - 2018-02-18 19:34:47 --> URI Class Initialized
INFO - 2018-02-18 19:34:47 --> Router Class Initialized
INFO - 2018-02-18 19:34:47 --> Output Class Initialized
INFO - 2018-02-18 19:34:47 --> Security Class Initialized
DEBUG - 2018-02-18 19:34:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:34:47 --> Input Class Initialized
INFO - 2018-02-18 19:34:47 --> Language Class Initialized
INFO - 2018-02-18 19:34:47 --> Loader Class Initialized
INFO - 2018-02-18 19:34:47 --> Helper loaded: url_helper
INFO - 2018-02-18 19:34:47 --> Helper loaded: form_helper
INFO - 2018-02-18 19:34:47 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:34:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:34:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:34:47 --> Form Validation Class Initialized
INFO - 2018-02-18 19:34:47 --> Model Class Initialized
INFO - 2018-02-18 19:34:47 --> Controller Class Initialized
INFO - 2018-02-18 19:34:47 --> Model Class Initialized
INFO - 2018-02-18 19:34:47 --> Model Class Initialized
INFO - 2018-02-18 19:34:47 --> Model Class Initialized
INFO - 2018-02-18 19:34:47 --> Model Class Initialized
INFO - 2018-02-18 19:34:47 --> Model Class Initialized
DEBUG - 2018-02-18 19:34:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:35:20 --> Config Class Initialized
INFO - 2018-02-18 19:35:20 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:35:20 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:35:20 --> Utf8 Class Initialized
INFO - 2018-02-18 19:35:20 --> URI Class Initialized
INFO - 2018-02-18 19:35:20 --> Router Class Initialized
INFO - 2018-02-18 19:35:20 --> Output Class Initialized
INFO - 2018-02-18 19:35:20 --> Security Class Initialized
DEBUG - 2018-02-18 19:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:35:20 --> Input Class Initialized
INFO - 2018-02-18 19:35:20 --> Language Class Initialized
INFO - 2018-02-18 19:35:20 --> Loader Class Initialized
INFO - 2018-02-18 19:35:20 --> Helper loaded: url_helper
INFO - 2018-02-18 19:35:20 --> Helper loaded: form_helper
INFO - 2018-02-18 19:35:20 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:35:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:35:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:35:20 --> Form Validation Class Initialized
INFO - 2018-02-18 19:35:20 --> Model Class Initialized
INFO - 2018-02-18 19:35:20 --> Controller Class Initialized
INFO - 2018-02-18 19:35:20 --> Model Class Initialized
INFO - 2018-02-18 19:35:20 --> Model Class Initialized
INFO - 2018-02-18 19:35:20 --> Model Class Initialized
INFO - 2018-02-18 19:35:20 --> Model Class Initialized
INFO - 2018-02-18 19:35:20 --> Model Class Initialized
DEBUG - 2018-02-18 19:35:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:35:20 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 19:35:20 --> Final output sent to browser
DEBUG - 2018-02-18 19:35:20 --> Total execution time: 0.0793
INFO - 2018-02-18 19:35:20 --> Config Class Initialized
INFO - 2018-02-18 19:35:20 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:35:20 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:35:20 --> Utf8 Class Initialized
INFO - 2018-02-18 19:35:20 --> URI Class Initialized
INFO - 2018-02-18 19:35:20 --> Router Class Initialized
INFO - 2018-02-18 19:35:20 --> Output Class Initialized
INFO - 2018-02-18 19:35:20 --> Security Class Initialized
DEBUG - 2018-02-18 19:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:35:20 --> Input Class Initialized
INFO - 2018-02-18 19:35:20 --> Language Class Initialized
INFO - 2018-02-18 19:35:20 --> Loader Class Initialized
INFO - 2018-02-18 19:35:20 --> Helper loaded: url_helper
INFO - 2018-02-18 19:35:20 --> Helper loaded: form_helper
INFO - 2018-02-18 19:35:20 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:35:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:35:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:35:20 --> Form Validation Class Initialized
INFO - 2018-02-18 19:35:20 --> Model Class Initialized
INFO - 2018-02-18 19:35:20 --> Controller Class Initialized
INFO - 2018-02-18 19:35:20 --> Model Class Initialized
INFO - 2018-02-18 19:35:20 --> Model Class Initialized
INFO - 2018-02-18 19:35:20 --> Model Class Initialized
INFO - 2018-02-18 19:35:20 --> Model Class Initialized
INFO - 2018-02-18 19:35:20 --> Model Class Initialized
DEBUG - 2018-02-18 19:35:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:35:32 --> Config Class Initialized
INFO - 2018-02-18 19:35:32 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:35:32 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:35:32 --> Utf8 Class Initialized
INFO - 2018-02-18 19:35:32 --> URI Class Initialized
INFO - 2018-02-18 19:35:32 --> Router Class Initialized
INFO - 2018-02-18 19:35:32 --> Output Class Initialized
INFO - 2018-02-18 19:35:32 --> Security Class Initialized
DEBUG - 2018-02-18 19:35:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:35:32 --> Input Class Initialized
INFO - 2018-02-18 19:35:32 --> Language Class Initialized
INFO - 2018-02-18 19:35:32 --> Loader Class Initialized
INFO - 2018-02-18 19:35:32 --> Helper loaded: url_helper
INFO - 2018-02-18 19:35:32 --> Helper loaded: form_helper
INFO - 2018-02-18 19:35:32 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:35:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:35:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:35:32 --> Form Validation Class Initialized
INFO - 2018-02-18 19:35:32 --> Model Class Initialized
INFO - 2018-02-18 19:35:32 --> Controller Class Initialized
INFO - 2018-02-18 19:35:32 --> Model Class Initialized
INFO - 2018-02-18 19:35:32 --> Model Class Initialized
INFO - 2018-02-18 19:35:32 --> Model Class Initialized
INFO - 2018-02-18 19:35:32 --> Model Class Initialized
INFO - 2018-02-18 19:35:32 --> Model Class Initialized
DEBUG - 2018-02-18 19:35:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:35:32 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 19:35:32 --> Final output sent to browser
DEBUG - 2018-02-18 19:35:32 --> Total execution time: 0.0670
INFO - 2018-02-18 19:35:33 --> Config Class Initialized
INFO - 2018-02-18 19:35:33 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:35:33 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:35:33 --> Utf8 Class Initialized
INFO - 2018-02-18 19:35:33 --> URI Class Initialized
INFO - 2018-02-18 19:35:33 --> Router Class Initialized
INFO - 2018-02-18 19:35:33 --> Output Class Initialized
INFO - 2018-02-18 19:35:33 --> Security Class Initialized
DEBUG - 2018-02-18 19:35:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:35:33 --> Input Class Initialized
INFO - 2018-02-18 19:35:33 --> Language Class Initialized
INFO - 2018-02-18 19:35:33 --> Loader Class Initialized
INFO - 2018-02-18 19:35:33 --> Helper loaded: url_helper
INFO - 2018-02-18 19:35:33 --> Helper loaded: form_helper
INFO - 2018-02-18 19:35:33 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:35:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:35:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:35:33 --> Form Validation Class Initialized
INFO - 2018-02-18 19:35:33 --> Model Class Initialized
INFO - 2018-02-18 19:35:33 --> Controller Class Initialized
INFO - 2018-02-18 19:35:33 --> Model Class Initialized
INFO - 2018-02-18 19:35:33 --> Model Class Initialized
INFO - 2018-02-18 19:35:33 --> Model Class Initialized
INFO - 2018-02-18 19:35:33 --> Model Class Initialized
INFO - 2018-02-18 19:35:33 --> Model Class Initialized
DEBUG - 2018-02-18 19:35:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:35:50 --> Config Class Initialized
INFO - 2018-02-18 19:35:50 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:35:50 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:35:50 --> Utf8 Class Initialized
INFO - 2018-02-18 19:35:50 --> URI Class Initialized
INFO - 2018-02-18 19:35:50 --> Router Class Initialized
INFO - 2018-02-18 19:35:50 --> Output Class Initialized
INFO - 2018-02-18 19:35:50 --> Security Class Initialized
DEBUG - 2018-02-18 19:35:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:35:50 --> Input Class Initialized
INFO - 2018-02-18 19:35:50 --> Language Class Initialized
INFO - 2018-02-18 19:35:50 --> Loader Class Initialized
INFO - 2018-02-18 19:35:50 --> Helper loaded: url_helper
INFO - 2018-02-18 19:35:50 --> Helper loaded: form_helper
INFO - 2018-02-18 19:35:50 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:35:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:35:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:35:50 --> Form Validation Class Initialized
INFO - 2018-02-18 19:35:50 --> Model Class Initialized
INFO - 2018-02-18 19:35:50 --> Controller Class Initialized
INFO - 2018-02-18 19:35:50 --> Model Class Initialized
INFO - 2018-02-18 19:35:50 --> Model Class Initialized
INFO - 2018-02-18 19:35:50 --> Model Class Initialized
INFO - 2018-02-18 19:35:50 --> Model Class Initialized
INFO - 2018-02-18 19:35:50 --> Model Class Initialized
DEBUG - 2018-02-18 19:35:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:35:50 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 19:35:50 --> Final output sent to browser
DEBUG - 2018-02-18 19:35:50 --> Total execution time: 0.0742
INFO - 2018-02-18 19:35:51 --> Config Class Initialized
INFO - 2018-02-18 19:35:51 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:35:51 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:35:51 --> Utf8 Class Initialized
INFO - 2018-02-18 19:35:51 --> URI Class Initialized
INFO - 2018-02-18 19:35:51 --> Router Class Initialized
INFO - 2018-02-18 19:35:51 --> Output Class Initialized
INFO - 2018-02-18 19:35:51 --> Security Class Initialized
DEBUG - 2018-02-18 19:35:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:35:51 --> Input Class Initialized
INFO - 2018-02-18 19:35:51 --> Language Class Initialized
INFO - 2018-02-18 19:35:51 --> Loader Class Initialized
INFO - 2018-02-18 19:35:51 --> Helper loaded: url_helper
INFO - 2018-02-18 19:35:51 --> Helper loaded: form_helper
INFO - 2018-02-18 19:35:51 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:35:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:35:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:35:51 --> Form Validation Class Initialized
INFO - 2018-02-18 19:35:51 --> Model Class Initialized
INFO - 2018-02-18 19:35:51 --> Controller Class Initialized
INFO - 2018-02-18 19:35:51 --> Model Class Initialized
INFO - 2018-02-18 19:35:51 --> Model Class Initialized
INFO - 2018-02-18 19:35:51 --> Model Class Initialized
INFO - 2018-02-18 19:35:51 --> Model Class Initialized
INFO - 2018-02-18 19:35:51 --> Model Class Initialized
DEBUG - 2018-02-18 19:35:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:36:27 --> Config Class Initialized
INFO - 2018-02-18 19:36:27 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:36:27 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:36:27 --> Utf8 Class Initialized
INFO - 2018-02-18 19:36:27 --> URI Class Initialized
INFO - 2018-02-18 19:36:27 --> Router Class Initialized
INFO - 2018-02-18 19:36:27 --> Output Class Initialized
INFO - 2018-02-18 19:36:27 --> Security Class Initialized
DEBUG - 2018-02-18 19:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:36:27 --> Input Class Initialized
INFO - 2018-02-18 19:36:27 --> Language Class Initialized
INFO - 2018-02-18 19:36:27 --> Loader Class Initialized
INFO - 2018-02-18 19:36:27 --> Helper loaded: url_helper
INFO - 2018-02-18 19:36:27 --> Helper loaded: form_helper
INFO - 2018-02-18 19:36:27 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:36:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:36:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:36:27 --> Form Validation Class Initialized
INFO - 2018-02-18 19:36:27 --> Model Class Initialized
INFO - 2018-02-18 19:36:27 --> Controller Class Initialized
INFO - 2018-02-18 19:36:27 --> Model Class Initialized
INFO - 2018-02-18 19:36:27 --> Model Class Initialized
INFO - 2018-02-18 19:36:27 --> Model Class Initialized
INFO - 2018-02-18 19:36:27 --> Model Class Initialized
INFO - 2018-02-18 19:36:27 --> Model Class Initialized
DEBUG - 2018-02-18 19:36:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:36:27 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 19:36:27 --> Final output sent to browser
DEBUG - 2018-02-18 19:36:27 --> Total execution time: 0.0623
INFO - 2018-02-18 19:36:28 --> Config Class Initialized
INFO - 2018-02-18 19:36:28 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:36:28 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:36:28 --> Utf8 Class Initialized
INFO - 2018-02-18 19:36:28 --> URI Class Initialized
INFO - 2018-02-18 19:36:28 --> Router Class Initialized
INFO - 2018-02-18 19:36:28 --> Output Class Initialized
INFO - 2018-02-18 19:36:28 --> Security Class Initialized
DEBUG - 2018-02-18 19:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:36:28 --> Input Class Initialized
INFO - 2018-02-18 19:36:28 --> Language Class Initialized
INFO - 2018-02-18 19:36:28 --> Loader Class Initialized
INFO - 2018-02-18 19:36:28 --> Helper loaded: url_helper
INFO - 2018-02-18 19:36:28 --> Helper loaded: form_helper
INFO - 2018-02-18 19:36:28 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:36:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:36:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:36:28 --> Form Validation Class Initialized
INFO - 2018-02-18 19:36:28 --> Model Class Initialized
INFO - 2018-02-18 19:36:28 --> Controller Class Initialized
INFO - 2018-02-18 19:36:28 --> Model Class Initialized
INFO - 2018-02-18 19:36:28 --> Model Class Initialized
INFO - 2018-02-18 19:36:28 --> Model Class Initialized
INFO - 2018-02-18 19:36:28 --> Model Class Initialized
INFO - 2018-02-18 19:36:28 --> Model Class Initialized
DEBUG - 2018-02-18 19:36:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:36:37 --> Config Class Initialized
INFO - 2018-02-18 19:36:37 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:36:37 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:36:37 --> Utf8 Class Initialized
INFO - 2018-02-18 19:36:37 --> URI Class Initialized
INFO - 2018-02-18 19:36:37 --> Router Class Initialized
INFO - 2018-02-18 19:36:37 --> Output Class Initialized
INFO - 2018-02-18 19:36:37 --> Security Class Initialized
DEBUG - 2018-02-18 19:36:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:36:37 --> Input Class Initialized
INFO - 2018-02-18 19:36:37 --> Language Class Initialized
INFO - 2018-02-18 19:36:37 --> Loader Class Initialized
INFO - 2018-02-18 19:36:37 --> Helper loaded: url_helper
INFO - 2018-02-18 19:36:37 --> Helper loaded: form_helper
INFO - 2018-02-18 19:36:37 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:36:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:36:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:36:37 --> Form Validation Class Initialized
INFO - 2018-02-18 19:36:37 --> Model Class Initialized
INFO - 2018-02-18 19:36:37 --> Controller Class Initialized
INFO - 2018-02-18 19:36:37 --> Model Class Initialized
INFO - 2018-02-18 19:36:37 --> Model Class Initialized
INFO - 2018-02-18 19:36:37 --> Model Class Initialized
INFO - 2018-02-18 19:36:37 --> Model Class Initialized
INFO - 2018-02-18 19:36:37 --> Model Class Initialized
DEBUG - 2018-02-18 19:36:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:36:37 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 19:36:37 --> Final output sent to browser
DEBUG - 2018-02-18 19:36:37 --> Total execution time: 0.0660
INFO - 2018-02-18 19:36:37 --> Config Class Initialized
INFO - 2018-02-18 19:36:37 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:36:37 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:36:37 --> Utf8 Class Initialized
INFO - 2018-02-18 19:36:37 --> URI Class Initialized
INFO - 2018-02-18 19:36:37 --> Router Class Initialized
INFO - 2018-02-18 19:36:37 --> Output Class Initialized
INFO - 2018-02-18 19:36:37 --> Security Class Initialized
DEBUG - 2018-02-18 19:36:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:36:37 --> Input Class Initialized
INFO - 2018-02-18 19:36:37 --> Language Class Initialized
INFO - 2018-02-18 19:36:37 --> Loader Class Initialized
INFO - 2018-02-18 19:36:37 --> Helper loaded: url_helper
INFO - 2018-02-18 19:36:37 --> Helper loaded: form_helper
INFO - 2018-02-18 19:36:37 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:36:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:36:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:36:37 --> Form Validation Class Initialized
INFO - 2018-02-18 19:36:37 --> Model Class Initialized
INFO - 2018-02-18 19:36:37 --> Controller Class Initialized
INFO - 2018-02-18 19:36:37 --> Model Class Initialized
INFO - 2018-02-18 19:36:37 --> Model Class Initialized
INFO - 2018-02-18 19:36:37 --> Model Class Initialized
INFO - 2018-02-18 19:36:37 --> Model Class Initialized
INFO - 2018-02-18 19:36:37 --> Model Class Initialized
DEBUG - 2018-02-18 19:36:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:36:47 --> Config Class Initialized
INFO - 2018-02-18 19:36:47 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:36:47 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:36:47 --> Utf8 Class Initialized
INFO - 2018-02-18 19:36:47 --> URI Class Initialized
INFO - 2018-02-18 19:36:47 --> Router Class Initialized
INFO - 2018-02-18 19:36:47 --> Output Class Initialized
INFO - 2018-02-18 19:36:47 --> Security Class Initialized
DEBUG - 2018-02-18 19:36:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:36:47 --> Input Class Initialized
INFO - 2018-02-18 19:36:47 --> Language Class Initialized
INFO - 2018-02-18 19:36:47 --> Loader Class Initialized
INFO - 2018-02-18 19:36:47 --> Helper loaded: url_helper
INFO - 2018-02-18 19:36:47 --> Helper loaded: form_helper
INFO - 2018-02-18 19:36:47 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:36:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:36:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:36:47 --> Form Validation Class Initialized
INFO - 2018-02-18 19:36:47 --> Model Class Initialized
INFO - 2018-02-18 19:36:47 --> Controller Class Initialized
INFO - 2018-02-18 19:36:47 --> Model Class Initialized
INFO - 2018-02-18 19:36:47 --> Model Class Initialized
INFO - 2018-02-18 19:36:47 --> Model Class Initialized
INFO - 2018-02-18 19:36:47 --> Model Class Initialized
INFO - 2018-02-18 19:36:47 --> Model Class Initialized
DEBUG - 2018-02-18 19:36:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:36:47 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 19:36:47 --> Final output sent to browser
DEBUG - 2018-02-18 19:36:47 --> Total execution time: 0.0689
INFO - 2018-02-18 19:36:47 --> Config Class Initialized
INFO - 2018-02-18 19:36:47 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:36:47 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:36:47 --> Utf8 Class Initialized
INFO - 2018-02-18 19:36:47 --> URI Class Initialized
INFO - 2018-02-18 19:36:47 --> Router Class Initialized
INFO - 2018-02-18 19:36:47 --> Output Class Initialized
INFO - 2018-02-18 19:36:47 --> Security Class Initialized
DEBUG - 2018-02-18 19:36:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:36:47 --> Input Class Initialized
INFO - 2018-02-18 19:36:47 --> Language Class Initialized
INFO - 2018-02-18 19:36:47 --> Loader Class Initialized
INFO - 2018-02-18 19:36:47 --> Helper loaded: url_helper
INFO - 2018-02-18 19:36:47 --> Helper loaded: form_helper
INFO - 2018-02-18 19:36:47 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:36:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:36:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:36:47 --> Form Validation Class Initialized
INFO - 2018-02-18 19:36:47 --> Model Class Initialized
INFO - 2018-02-18 19:36:47 --> Controller Class Initialized
INFO - 2018-02-18 19:36:47 --> Model Class Initialized
INFO - 2018-02-18 19:36:47 --> Model Class Initialized
INFO - 2018-02-18 19:36:47 --> Model Class Initialized
INFO - 2018-02-18 19:36:47 --> Model Class Initialized
INFO - 2018-02-18 19:36:47 --> Model Class Initialized
DEBUG - 2018-02-18 19:36:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:39:42 --> Config Class Initialized
INFO - 2018-02-18 19:39:42 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:39:42 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:39:42 --> Utf8 Class Initialized
INFO - 2018-02-18 19:39:42 --> URI Class Initialized
INFO - 2018-02-18 19:39:42 --> Router Class Initialized
INFO - 2018-02-18 19:39:42 --> Output Class Initialized
INFO - 2018-02-18 19:39:42 --> Security Class Initialized
DEBUG - 2018-02-18 19:39:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:39:42 --> Input Class Initialized
INFO - 2018-02-18 19:39:42 --> Language Class Initialized
INFO - 2018-02-18 19:39:43 --> Loader Class Initialized
INFO - 2018-02-18 19:39:43 --> Helper loaded: url_helper
INFO - 2018-02-18 19:39:43 --> Helper loaded: form_helper
INFO - 2018-02-18 19:39:43 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:39:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:39:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:39:43 --> Form Validation Class Initialized
INFO - 2018-02-18 19:39:43 --> Model Class Initialized
INFO - 2018-02-18 19:39:43 --> Controller Class Initialized
INFO - 2018-02-18 19:39:43 --> Model Class Initialized
INFO - 2018-02-18 19:39:43 --> Model Class Initialized
DEBUG - 2018-02-18 19:39:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:39:43 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 19:39:43 --> Final output sent to browser
DEBUG - 2018-02-18 19:39:43 --> Total execution time: 0.1059
INFO - 2018-02-18 19:39:43 --> Config Class Initialized
INFO - 2018-02-18 19:39:43 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:39:43 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:39:43 --> Utf8 Class Initialized
INFO - 2018-02-18 19:39:43 --> URI Class Initialized
INFO - 2018-02-18 19:39:43 --> Router Class Initialized
INFO - 2018-02-18 19:39:43 --> Output Class Initialized
INFO - 2018-02-18 19:39:43 --> Security Class Initialized
DEBUG - 2018-02-18 19:39:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:39:43 --> Input Class Initialized
INFO - 2018-02-18 19:39:43 --> Language Class Initialized
INFO - 2018-02-18 19:39:43 --> Loader Class Initialized
INFO - 2018-02-18 19:39:43 --> Helper loaded: url_helper
INFO - 2018-02-18 19:39:43 --> Helper loaded: form_helper
INFO - 2018-02-18 19:39:43 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:39:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:39:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:39:43 --> Form Validation Class Initialized
INFO - 2018-02-18 19:39:43 --> Model Class Initialized
INFO - 2018-02-18 19:39:43 --> Controller Class Initialized
INFO - 2018-02-18 19:39:43 --> Model Class Initialized
INFO - 2018-02-18 19:39:43 --> Model Class Initialized
DEBUG - 2018-02-18 19:39:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:40:14 --> Config Class Initialized
INFO - 2018-02-18 19:40:14 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:40:14 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:40:14 --> Utf8 Class Initialized
INFO - 2018-02-18 19:40:14 --> URI Class Initialized
INFO - 2018-02-18 19:40:14 --> Router Class Initialized
INFO - 2018-02-18 19:40:14 --> Output Class Initialized
INFO - 2018-02-18 19:40:14 --> Security Class Initialized
DEBUG - 2018-02-18 19:40:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:40:14 --> Input Class Initialized
INFO - 2018-02-18 19:40:14 --> Language Class Initialized
INFO - 2018-02-18 19:40:14 --> Loader Class Initialized
INFO - 2018-02-18 19:40:14 --> Helper loaded: url_helper
INFO - 2018-02-18 19:40:14 --> Helper loaded: form_helper
INFO - 2018-02-18 19:40:14 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:40:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:40:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:40:14 --> Form Validation Class Initialized
INFO - 2018-02-18 19:40:14 --> Model Class Initialized
INFO - 2018-02-18 19:40:14 --> Controller Class Initialized
INFO - 2018-02-18 19:40:14 --> Model Class Initialized
INFO - 2018-02-18 19:40:14 --> Model Class Initialized
DEBUG - 2018-02-18 19:40:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:40:14 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 19:40:14 --> Final output sent to browser
DEBUG - 2018-02-18 19:40:14 --> Total execution time: 0.0529
INFO - 2018-02-18 19:40:14 --> Config Class Initialized
INFO - 2018-02-18 19:40:14 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:40:14 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:40:14 --> Utf8 Class Initialized
INFO - 2018-02-18 19:40:14 --> URI Class Initialized
INFO - 2018-02-18 19:40:14 --> Router Class Initialized
INFO - 2018-02-18 19:40:14 --> Output Class Initialized
INFO - 2018-02-18 19:40:14 --> Security Class Initialized
DEBUG - 2018-02-18 19:40:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:40:14 --> Input Class Initialized
INFO - 2018-02-18 19:40:14 --> Language Class Initialized
INFO - 2018-02-18 19:40:14 --> Loader Class Initialized
INFO - 2018-02-18 19:40:14 --> Helper loaded: url_helper
INFO - 2018-02-18 19:40:14 --> Helper loaded: form_helper
INFO - 2018-02-18 19:40:14 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:40:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:40:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:40:14 --> Form Validation Class Initialized
INFO - 2018-02-18 19:40:14 --> Model Class Initialized
INFO - 2018-02-18 19:40:14 --> Controller Class Initialized
INFO - 2018-02-18 19:40:14 --> Model Class Initialized
INFO - 2018-02-18 19:40:14 --> Model Class Initialized
DEBUG - 2018-02-18 19:40:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:46:06 --> Config Class Initialized
INFO - 2018-02-18 19:46:06 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:46:06 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:46:06 --> Utf8 Class Initialized
INFO - 2018-02-18 19:46:06 --> URI Class Initialized
INFO - 2018-02-18 19:46:06 --> Router Class Initialized
INFO - 2018-02-18 19:46:06 --> Output Class Initialized
INFO - 2018-02-18 19:46:06 --> Security Class Initialized
DEBUG - 2018-02-18 19:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:46:06 --> Input Class Initialized
INFO - 2018-02-18 19:46:06 --> Language Class Initialized
INFO - 2018-02-18 19:46:06 --> Loader Class Initialized
INFO - 2018-02-18 19:46:06 --> Helper loaded: url_helper
INFO - 2018-02-18 19:46:06 --> Helper loaded: form_helper
INFO - 2018-02-18 19:46:06 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:46:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:46:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:46:06 --> Form Validation Class Initialized
INFO - 2018-02-18 19:46:06 --> Model Class Initialized
INFO - 2018-02-18 19:46:06 --> Controller Class Initialized
INFO - 2018-02-18 19:46:06 --> Model Class Initialized
INFO - 2018-02-18 19:46:06 --> Model Class Initialized
INFO - 2018-02-18 19:46:06 --> Model Class Initialized
INFO - 2018-02-18 19:46:06 --> Model Class Initialized
INFO - 2018-02-18 19:46:06 --> Model Class Initialized
DEBUG - 2018-02-18 19:46:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:46:06 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 19:46:06 --> Final output sent to browser
DEBUG - 2018-02-18 19:46:06 --> Total execution time: 0.0440
INFO - 2018-02-18 19:46:06 --> Config Class Initialized
INFO - 2018-02-18 19:46:06 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:46:06 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:46:06 --> Utf8 Class Initialized
INFO - 2018-02-18 19:46:06 --> URI Class Initialized
INFO - 2018-02-18 19:46:06 --> Router Class Initialized
INFO - 2018-02-18 19:46:06 --> Output Class Initialized
INFO - 2018-02-18 19:46:06 --> Security Class Initialized
DEBUG - 2018-02-18 19:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:46:06 --> Input Class Initialized
INFO - 2018-02-18 19:46:06 --> Language Class Initialized
INFO - 2018-02-18 19:46:06 --> Loader Class Initialized
INFO - 2018-02-18 19:46:06 --> Helper loaded: url_helper
INFO - 2018-02-18 19:46:06 --> Helper loaded: form_helper
INFO - 2018-02-18 19:46:06 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:46:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:46:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:46:06 --> Form Validation Class Initialized
INFO - 2018-02-18 19:46:06 --> Model Class Initialized
INFO - 2018-02-18 19:46:06 --> Controller Class Initialized
INFO - 2018-02-18 19:46:06 --> Model Class Initialized
INFO - 2018-02-18 19:46:06 --> Model Class Initialized
INFO - 2018-02-18 19:46:06 --> Model Class Initialized
INFO - 2018-02-18 19:46:06 --> Model Class Initialized
INFO - 2018-02-18 19:46:06 --> Model Class Initialized
DEBUG - 2018-02-18 19:46:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:46:08 --> Config Class Initialized
INFO - 2018-02-18 19:46:08 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:46:08 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:46:08 --> Utf8 Class Initialized
INFO - 2018-02-18 19:46:08 --> URI Class Initialized
INFO - 2018-02-18 19:46:08 --> Router Class Initialized
INFO - 2018-02-18 19:46:08 --> Output Class Initialized
INFO - 2018-02-18 19:46:08 --> Security Class Initialized
DEBUG - 2018-02-18 19:46:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:46:08 --> Input Class Initialized
INFO - 2018-02-18 19:46:08 --> Language Class Initialized
INFO - 2018-02-18 19:46:08 --> Loader Class Initialized
INFO - 2018-02-18 19:46:08 --> Helper loaded: url_helper
INFO - 2018-02-18 19:46:08 --> Helper loaded: form_helper
INFO - 2018-02-18 19:46:08 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:46:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:46:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:46:08 --> Form Validation Class Initialized
INFO - 2018-02-18 19:46:08 --> Model Class Initialized
INFO - 2018-02-18 19:46:08 --> Controller Class Initialized
INFO - 2018-02-18 19:46:08 --> Model Class Initialized
INFO - 2018-02-18 19:46:08 --> Model Class Initialized
INFO - 2018-02-18 19:46:08 --> Model Class Initialized
INFO - 2018-02-18 19:46:08 --> Model Class Initialized
INFO - 2018-02-18 19:46:08 --> Model Class Initialized
DEBUG - 2018-02-18 19:46:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:46:08 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 19:46:08 --> Final output sent to browser
DEBUG - 2018-02-18 19:46:08 --> Total execution time: 0.0620
INFO - 2018-02-18 19:46:08 --> Config Class Initialized
INFO - 2018-02-18 19:46:08 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:46:08 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:46:08 --> Utf8 Class Initialized
INFO - 2018-02-18 19:46:08 --> URI Class Initialized
INFO - 2018-02-18 19:46:08 --> Router Class Initialized
INFO - 2018-02-18 19:46:08 --> Output Class Initialized
INFO - 2018-02-18 19:46:08 --> Security Class Initialized
DEBUG - 2018-02-18 19:46:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:46:08 --> Input Class Initialized
INFO - 2018-02-18 19:46:08 --> Language Class Initialized
INFO - 2018-02-18 19:46:08 --> Loader Class Initialized
INFO - 2018-02-18 19:46:08 --> Helper loaded: url_helper
INFO - 2018-02-18 19:46:08 --> Helper loaded: form_helper
INFO - 2018-02-18 19:46:08 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:46:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:46:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:46:08 --> Form Validation Class Initialized
INFO - 2018-02-18 19:46:08 --> Model Class Initialized
INFO - 2018-02-18 19:46:08 --> Controller Class Initialized
INFO - 2018-02-18 19:46:08 --> Model Class Initialized
INFO - 2018-02-18 19:46:08 --> Model Class Initialized
INFO - 2018-02-18 19:46:08 --> Model Class Initialized
INFO - 2018-02-18 19:46:08 --> Model Class Initialized
INFO - 2018-02-18 19:46:08 --> Model Class Initialized
DEBUG - 2018-02-18 19:46:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:46:22 --> Config Class Initialized
INFO - 2018-02-18 19:46:22 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:46:22 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:46:22 --> Utf8 Class Initialized
INFO - 2018-02-18 19:46:22 --> URI Class Initialized
INFO - 2018-02-18 19:46:22 --> Router Class Initialized
INFO - 2018-02-18 19:46:22 --> Output Class Initialized
INFO - 2018-02-18 19:46:22 --> Security Class Initialized
DEBUG - 2018-02-18 19:46:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:46:22 --> Input Class Initialized
INFO - 2018-02-18 19:46:22 --> Language Class Initialized
INFO - 2018-02-18 19:46:22 --> Loader Class Initialized
INFO - 2018-02-18 19:46:22 --> Helper loaded: url_helper
INFO - 2018-02-18 19:46:22 --> Helper loaded: form_helper
INFO - 2018-02-18 19:46:22 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:46:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:46:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:46:22 --> Form Validation Class Initialized
INFO - 2018-02-18 19:46:22 --> Model Class Initialized
INFO - 2018-02-18 19:46:22 --> Controller Class Initialized
INFO - 2018-02-18 19:46:22 --> Model Class Initialized
INFO - 2018-02-18 19:46:22 --> Model Class Initialized
INFO - 2018-02-18 19:46:22 --> Model Class Initialized
INFO - 2018-02-18 19:46:22 --> Model Class Initialized
INFO - 2018-02-18 19:46:22 --> Model Class Initialized
DEBUG - 2018-02-18 19:46:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:46:22 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 19:46:22 --> Final output sent to browser
DEBUG - 2018-02-18 19:46:22 --> Total execution time: 0.0696
INFO - 2018-02-18 19:46:22 --> Config Class Initialized
INFO - 2018-02-18 19:46:22 --> Hooks Class Initialized
INFO - 2018-02-18 19:46:22 --> Config Class Initialized
INFO - 2018-02-18 19:46:22 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:46:22 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:46:22 --> Utf8 Class Initialized
DEBUG - 2018-02-18 19:46:22 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:46:22 --> Utf8 Class Initialized
INFO - 2018-02-18 19:46:22 --> URI Class Initialized
INFO - 2018-02-18 19:46:22 --> URI Class Initialized
INFO - 2018-02-18 19:46:22 --> Router Class Initialized
INFO - 2018-02-18 19:46:22 --> Router Class Initialized
INFO - 2018-02-18 19:46:22 --> Output Class Initialized
INFO - 2018-02-18 19:46:22 --> Output Class Initialized
INFO - 2018-02-18 19:46:22 --> Security Class Initialized
INFO - 2018-02-18 19:46:22 --> Security Class Initialized
DEBUG - 2018-02-18 19:46:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-18 19:46:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:46:22 --> Input Class Initialized
INFO - 2018-02-18 19:46:22 --> Input Class Initialized
INFO - 2018-02-18 19:46:22 --> Language Class Initialized
INFO - 2018-02-18 19:46:22 --> Language Class Initialized
ERROR - 2018-02-18 19:46:22 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-02-18 19:46:22 --> Loader Class Initialized
INFO - 2018-02-18 19:46:22 --> Helper loaded: url_helper
INFO - 2018-02-18 19:46:22 --> Helper loaded: form_helper
INFO - 2018-02-18 19:46:22 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:46:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:46:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:46:22 --> Form Validation Class Initialized
INFO - 2018-02-18 19:46:22 --> Model Class Initialized
INFO - 2018-02-18 19:46:22 --> Controller Class Initialized
INFO - 2018-02-18 19:46:22 --> Model Class Initialized
INFO - 2018-02-18 19:46:22 --> Model Class Initialized
INFO - 2018-02-18 19:46:22 --> Model Class Initialized
INFO - 2018-02-18 19:46:22 --> Model Class Initialized
INFO - 2018-02-18 19:46:22 --> Model Class Initialized
DEBUG - 2018-02-18 19:46:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:46:26 --> Config Class Initialized
INFO - 2018-02-18 19:46:26 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:46:26 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:46:26 --> Utf8 Class Initialized
INFO - 2018-02-18 19:46:26 --> URI Class Initialized
INFO - 2018-02-18 19:46:26 --> Router Class Initialized
INFO - 2018-02-18 19:46:26 --> Output Class Initialized
INFO - 2018-02-18 19:46:26 --> Security Class Initialized
DEBUG - 2018-02-18 19:46:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:46:26 --> Input Class Initialized
INFO - 2018-02-18 19:46:26 --> Language Class Initialized
INFO - 2018-02-18 19:46:26 --> Loader Class Initialized
INFO - 2018-02-18 19:46:26 --> Helper loaded: url_helper
INFO - 2018-02-18 19:46:26 --> Helper loaded: form_helper
INFO - 2018-02-18 19:46:26 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:46:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:46:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:46:26 --> Form Validation Class Initialized
INFO - 2018-02-18 19:46:26 --> Model Class Initialized
INFO - 2018-02-18 19:46:26 --> Controller Class Initialized
INFO - 2018-02-18 19:46:26 --> Model Class Initialized
INFO - 2018-02-18 19:46:26 --> Model Class Initialized
INFO - 2018-02-18 19:46:26 --> Model Class Initialized
INFO - 2018-02-18 19:46:26 --> Model Class Initialized
INFO - 2018-02-18 19:46:26 --> Model Class Initialized
DEBUG - 2018-02-18 19:46:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:46:26 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 19:46:26 --> Final output sent to browser
DEBUG - 2018-02-18 19:46:26 --> Total execution time: 0.0725
INFO - 2018-02-18 19:46:26 --> Config Class Initialized
INFO - 2018-02-18 19:46:26 --> Hooks Class Initialized
INFO - 2018-02-18 19:46:26 --> Config Class Initialized
INFO - 2018-02-18 19:46:26 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:46:26 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:46:26 --> Utf8 Class Initialized
DEBUG - 2018-02-18 19:46:26 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:46:26 --> Utf8 Class Initialized
INFO - 2018-02-18 19:46:26 --> URI Class Initialized
INFO - 2018-02-18 19:46:26 --> URI Class Initialized
INFO - 2018-02-18 19:46:26 --> Router Class Initialized
INFO - 2018-02-18 19:46:26 --> Router Class Initialized
INFO - 2018-02-18 19:46:26 --> Output Class Initialized
INFO - 2018-02-18 19:46:26 --> Output Class Initialized
INFO - 2018-02-18 19:46:26 --> Security Class Initialized
INFO - 2018-02-18 19:46:26 --> Security Class Initialized
DEBUG - 2018-02-18 19:46:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:46:26 --> Input Class Initialized
DEBUG - 2018-02-18 19:46:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:46:26 --> Input Class Initialized
INFO - 2018-02-18 19:46:26 --> Language Class Initialized
INFO - 2018-02-18 19:46:26 --> Language Class Initialized
ERROR - 2018-02-18 19:46:26 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-02-18 19:46:26 --> Loader Class Initialized
INFO - 2018-02-18 19:46:26 --> Helper loaded: url_helper
INFO - 2018-02-18 19:46:26 --> Helper loaded: form_helper
INFO - 2018-02-18 19:46:26 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:46:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:46:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:46:26 --> Form Validation Class Initialized
INFO - 2018-02-18 19:46:26 --> Model Class Initialized
INFO - 2018-02-18 19:46:26 --> Controller Class Initialized
INFO - 2018-02-18 19:46:26 --> Model Class Initialized
INFO - 2018-02-18 19:46:26 --> Model Class Initialized
INFO - 2018-02-18 19:46:26 --> Model Class Initialized
INFO - 2018-02-18 19:46:26 --> Model Class Initialized
INFO - 2018-02-18 19:46:26 --> Model Class Initialized
DEBUG - 2018-02-18 19:46:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:46:32 --> Config Class Initialized
INFO - 2018-02-18 19:46:32 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:46:32 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:46:32 --> Utf8 Class Initialized
INFO - 2018-02-18 19:46:32 --> URI Class Initialized
INFO - 2018-02-18 19:46:32 --> Router Class Initialized
INFO - 2018-02-18 19:46:32 --> Output Class Initialized
INFO - 2018-02-18 19:46:32 --> Security Class Initialized
DEBUG - 2018-02-18 19:46:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:46:32 --> Input Class Initialized
INFO - 2018-02-18 19:46:32 --> Language Class Initialized
INFO - 2018-02-18 19:46:32 --> Loader Class Initialized
INFO - 2018-02-18 19:46:32 --> Helper loaded: url_helper
INFO - 2018-02-18 19:46:32 --> Helper loaded: form_helper
INFO - 2018-02-18 19:46:32 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:46:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:46:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:46:32 --> Form Validation Class Initialized
INFO - 2018-02-18 19:46:32 --> Model Class Initialized
INFO - 2018-02-18 19:46:32 --> Controller Class Initialized
INFO - 2018-02-18 19:46:32 --> Model Class Initialized
INFO - 2018-02-18 19:46:32 --> Model Class Initialized
INFO - 2018-02-18 19:46:32 --> Model Class Initialized
INFO - 2018-02-18 19:46:32 --> Model Class Initialized
INFO - 2018-02-18 19:46:32 --> Model Class Initialized
DEBUG - 2018-02-18 19:46:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:46:32 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 19:46:32 --> Final output sent to browser
DEBUG - 2018-02-18 19:46:32 --> Total execution time: 0.0579
INFO - 2018-02-18 19:46:32 --> Config Class Initialized
INFO - 2018-02-18 19:46:32 --> Config Class Initialized
INFO - 2018-02-18 19:46:32 --> Hooks Class Initialized
INFO - 2018-02-18 19:46:32 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:46:32 --> UTF-8 Support Enabled
DEBUG - 2018-02-18 19:46:32 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:46:32 --> Utf8 Class Initialized
INFO - 2018-02-18 19:46:32 --> Utf8 Class Initialized
INFO - 2018-02-18 19:46:32 --> URI Class Initialized
INFO - 2018-02-18 19:46:32 --> URI Class Initialized
INFO - 2018-02-18 19:46:32 --> Router Class Initialized
INFO - 2018-02-18 19:46:32 --> Router Class Initialized
INFO - 2018-02-18 19:46:32 --> Output Class Initialized
INFO - 2018-02-18 19:46:32 --> Output Class Initialized
INFO - 2018-02-18 19:46:32 --> Security Class Initialized
INFO - 2018-02-18 19:46:32 --> Security Class Initialized
DEBUG - 2018-02-18 19:46:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-18 19:46:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:46:32 --> Input Class Initialized
INFO - 2018-02-18 19:46:32 --> Input Class Initialized
INFO - 2018-02-18 19:46:32 --> Language Class Initialized
INFO - 2018-02-18 19:46:32 --> Language Class Initialized
INFO - 2018-02-18 19:46:32 --> Loader Class Initialized
INFO - 2018-02-18 19:46:32 --> Helper loaded: url_helper
INFO - 2018-02-18 19:46:32 --> Loader Class Initialized
INFO - 2018-02-18 19:46:32 --> Helper loaded: form_helper
INFO - 2018-02-18 19:46:32 --> Helper loaded: url_helper
INFO - 2018-02-18 19:46:32 --> Helper loaded: form_helper
INFO - 2018-02-18 19:46:32 --> Database Driver Class Initialized
INFO - 2018-02-18 19:46:32 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:46:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:46:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-02-18 19:46:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:46:32 --> Form Validation Class Initialized
INFO - 2018-02-18 19:46:32 --> Model Class Initialized
INFO - 2018-02-18 19:46:32 --> Controller Class Initialized
INFO - 2018-02-18 19:46:32 --> Model Class Initialized
INFO - 2018-02-18 19:46:32 --> Model Class Initialized
INFO - 2018-02-18 19:46:32 --> Model Class Initialized
INFO - 2018-02-18 19:46:32 --> Model Class Initialized
INFO - 2018-02-18 19:46:32 --> Model Class Initialized
DEBUG - 2018-02-18 19:46:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:46:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:46:32 --> Form Validation Class Initialized
INFO - 2018-02-18 19:46:32 --> Model Class Initialized
INFO - 2018-02-18 19:46:32 --> Controller Class Initialized
INFO - 2018-02-18 19:46:32 --> Model Class Initialized
INFO - 2018-02-18 19:46:32 --> Model Class Initialized
INFO - 2018-02-18 19:46:32 --> Model Class Initialized
INFO - 2018-02-18 19:46:32 --> Model Class Initialized
INFO - 2018-02-18 19:46:32 --> Model Class Initialized
DEBUG - 2018-02-18 19:46:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:48:14 --> Config Class Initialized
INFO - 2018-02-18 19:48:14 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:48:14 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:48:14 --> Utf8 Class Initialized
INFO - 2018-02-18 19:48:14 --> URI Class Initialized
INFO - 2018-02-18 19:48:14 --> Router Class Initialized
INFO - 2018-02-18 19:48:14 --> Output Class Initialized
INFO - 2018-02-18 19:48:14 --> Security Class Initialized
DEBUG - 2018-02-18 19:48:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:48:14 --> Input Class Initialized
INFO - 2018-02-18 19:48:14 --> Language Class Initialized
INFO - 2018-02-18 19:48:14 --> Loader Class Initialized
INFO - 2018-02-18 19:48:14 --> Helper loaded: url_helper
INFO - 2018-02-18 19:48:14 --> Helper loaded: form_helper
INFO - 2018-02-18 19:48:14 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:48:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:48:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:48:14 --> Form Validation Class Initialized
INFO - 2018-02-18 19:48:14 --> Model Class Initialized
INFO - 2018-02-18 19:48:14 --> Controller Class Initialized
INFO - 2018-02-18 19:48:14 --> Model Class Initialized
INFO - 2018-02-18 19:48:14 --> Model Class Initialized
INFO - 2018-02-18 19:48:14 --> Model Class Initialized
INFO - 2018-02-18 19:48:14 --> Model Class Initialized
INFO - 2018-02-18 19:48:14 --> Model Class Initialized
DEBUG - 2018-02-18 19:48:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:48:14 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 19:48:14 --> Final output sent to browser
DEBUG - 2018-02-18 19:48:14 --> Total execution time: 0.0804
INFO - 2018-02-18 19:48:14 --> Config Class Initialized
INFO - 2018-02-18 19:48:14 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:48:14 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:48:14 --> Utf8 Class Initialized
INFO - 2018-02-18 19:48:14 --> URI Class Initialized
INFO - 2018-02-18 19:48:14 --> Router Class Initialized
INFO - 2018-02-18 19:48:14 --> Output Class Initialized
INFO - 2018-02-18 19:48:14 --> Security Class Initialized
DEBUG - 2018-02-18 19:48:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:48:14 --> Input Class Initialized
INFO - 2018-02-18 19:48:14 --> Language Class Initialized
INFO - 2018-02-18 19:48:14 --> Loader Class Initialized
INFO - 2018-02-18 19:48:14 --> Helper loaded: url_helper
INFO - 2018-02-18 19:48:14 --> Helper loaded: form_helper
INFO - 2018-02-18 19:48:14 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:48:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:48:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:48:14 --> Form Validation Class Initialized
INFO - 2018-02-18 19:48:14 --> Model Class Initialized
INFO - 2018-02-18 19:48:14 --> Controller Class Initialized
INFO - 2018-02-18 19:48:14 --> Model Class Initialized
INFO - 2018-02-18 19:48:14 --> Model Class Initialized
INFO - 2018-02-18 19:48:14 --> Model Class Initialized
INFO - 2018-02-18 19:48:14 --> Model Class Initialized
INFO - 2018-02-18 19:48:14 --> Model Class Initialized
DEBUG - 2018-02-18 19:48:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:48:19 --> Config Class Initialized
INFO - 2018-02-18 19:48:19 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:48:19 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:48:19 --> Utf8 Class Initialized
INFO - 2018-02-18 19:48:19 --> URI Class Initialized
INFO - 2018-02-18 19:48:19 --> Router Class Initialized
INFO - 2018-02-18 19:48:19 --> Output Class Initialized
INFO - 2018-02-18 19:48:19 --> Security Class Initialized
DEBUG - 2018-02-18 19:48:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:48:19 --> Input Class Initialized
INFO - 2018-02-18 19:48:19 --> Language Class Initialized
INFO - 2018-02-18 19:48:19 --> Loader Class Initialized
INFO - 2018-02-18 19:48:19 --> Helper loaded: url_helper
INFO - 2018-02-18 19:48:19 --> Helper loaded: form_helper
INFO - 2018-02-18 19:48:19 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:48:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:48:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:48:19 --> Form Validation Class Initialized
INFO - 2018-02-18 19:48:19 --> Model Class Initialized
INFO - 2018-02-18 19:48:19 --> Controller Class Initialized
INFO - 2018-02-18 19:48:19 --> Model Class Initialized
DEBUG - 2018-02-18 19:48:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:48:19 --> Config Class Initialized
INFO - 2018-02-18 19:48:19 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:48:19 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:48:19 --> Utf8 Class Initialized
INFO - 2018-02-18 19:48:19 --> URI Class Initialized
INFO - 2018-02-18 19:48:19 --> Router Class Initialized
INFO - 2018-02-18 19:48:19 --> Output Class Initialized
INFO - 2018-02-18 19:48:19 --> Security Class Initialized
DEBUG - 2018-02-18 19:48:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:48:19 --> Input Class Initialized
INFO - 2018-02-18 19:48:19 --> Language Class Initialized
INFO - 2018-02-18 19:48:19 --> Loader Class Initialized
INFO - 2018-02-18 19:48:19 --> Helper loaded: url_helper
INFO - 2018-02-18 19:48:19 --> Helper loaded: form_helper
INFO - 2018-02-18 19:48:19 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:48:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:48:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:48:19 --> Form Validation Class Initialized
INFO - 2018-02-18 19:48:19 --> Model Class Initialized
INFO - 2018-02-18 19:48:19 --> Controller Class Initialized
INFO - 2018-02-18 19:48:19 --> Model Class Initialized
DEBUG - 2018-02-18 19:48:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:48:19 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 19:48:19 --> Final output sent to browser
DEBUG - 2018-02-18 19:48:19 --> Total execution time: 0.0573
INFO - 2018-02-18 19:48:23 --> Config Class Initialized
INFO - 2018-02-18 19:48:23 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:48:23 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:48:23 --> Utf8 Class Initialized
INFO - 2018-02-18 19:48:23 --> URI Class Initialized
INFO - 2018-02-18 19:48:23 --> Router Class Initialized
INFO - 2018-02-18 19:48:23 --> Output Class Initialized
INFO - 2018-02-18 19:48:23 --> Security Class Initialized
DEBUG - 2018-02-18 19:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:48:23 --> Input Class Initialized
INFO - 2018-02-18 19:48:23 --> Language Class Initialized
INFO - 2018-02-18 19:48:23 --> Loader Class Initialized
INFO - 2018-02-18 19:48:23 --> Helper loaded: url_helper
INFO - 2018-02-18 19:48:23 --> Helper loaded: form_helper
INFO - 2018-02-18 19:48:23 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:48:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:48:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:48:23 --> Form Validation Class Initialized
INFO - 2018-02-18 19:48:23 --> Model Class Initialized
INFO - 2018-02-18 19:48:23 --> Controller Class Initialized
INFO - 2018-02-18 19:48:23 --> Model Class Initialized
DEBUG - 2018-02-18 19:48:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:48:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-18 19:48:24 --> Config Class Initialized
INFO - 2018-02-18 19:48:24 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:48:24 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:48:24 --> Utf8 Class Initialized
INFO - 2018-02-18 19:48:24 --> URI Class Initialized
DEBUG - 2018-02-18 19:48:24 --> No URI present. Default controller set.
INFO - 2018-02-18 19:48:24 --> Router Class Initialized
INFO - 2018-02-18 19:48:24 --> Output Class Initialized
INFO - 2018-02-18 19:48:24 --> Security Class Initialized
DEBUG - 2018-02-18 19:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:48:24 --> Input Class Initialized
INFO - 2018-02-18 19:48:24 --> Language Class Initialized
INFO - 2018-02-18 19:48:24 --> Loader Class Initialized
INFO - 2018-02-18 19:48:24 --> Helper loaded: url_helper
INFO - 2018-02-18 19:48:24 --> Helper loaded: form_helper
INFO - 2018-02-18 19:48:24 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:48:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:48:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:48:24 --> Form Validation Class Initialized
INFO - 2018-02-18 19:48:24 --> Model Class Initialized
INFO - 2018-02-18 19:48:24 --> Controller Class Initialized
INFO - 2018-02-18 19:48:24 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 19:48:24 --> Final output sent to browser
DEBUG - 2018-02-18 19:48:24 --> Total execution time: 0.0639
INFO - 2018-02-18 19:48:24 --> Config Class Initialized
INFO - 2018-02-18 19:48:24 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:48:24 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:48:24 --> Utf8 Class Initialized
INFO - 2018-02-18 19:48:24 --> URI Class Initialized
INFO - 2018-02-18 19:48:24 --> Router Class Initialized
INFO - 2018-02-18 19:48:24 --> Output Class Initialized
INFO - 2018-02-18 19:48:24 --> Security Class Initialized
DEBUG - 2018-02-18 19:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:48:24 --> Input Class Initialized
INFO - 2018-02-18 19:48:24 --> Language Class Initialized
INFO - 2018-02-18 19:48:24 --> Loader Class Initialized
INFO - 2018-02-18 19:48:24 --> Helper loaded: url_helper
INFO - 2018-02-18 19:48:24 --> Helper loaded: form_helper
INFO - 2018-02-18 19:48:24 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:48:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:48:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:48:24 --> Form Validation Class Initialized
INFO - 2018-02-18 19:48:24 --> Model Class Initialized
INFO - 2018-02-18 19:48:24 --> Controller Class Initialized
INFO - 2018-02-18 19:48:24 --> Model Class Initialized
INFO - 2018-02-18 19:48:24 --> Model Class Initialized
INFO - 2018-02-18 19:48:24 --> Model Class Initialized
INFO - 2018-02-18 19:48:24 --> Model Class Initialized
INFO - 2018-02-18 19:48:24 --> Model Class Initialized
DEBUG - 2018-02-18 19:48:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:48:28 --> Config Class Initialized
INFO - 2018-02-18 19:48:28 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:48:28 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:48:28 --> Utf8 Class Initialized
INFO - 2018-02-18 19:48:28 --> URI Class Initialized
INFO - 2018-02-18 19:48:28 --> Router Class Initialized
INFO - 2018-02-18 19:48:28 --> Output Class Initialized
INFO - 2018-02-18 19:48:28 --> Security Class Initialized
DEBUG - 2018-02-18 19:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:48:28 --> Input Class Initialized
INFO - 2018-02-18 19:48:28 --> Language Class Initialized
INFO - 2018-02-18 19:48:28 --> Loader Class Initialized
INFO - 2018-02-18 19:48:28 --> Helper loaded: url_helper
INFO - 2018-02-18 19:48:28 --> Helper loaded: form_helper
INFO - 2018-02-18 19:48:28 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:48:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:48:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:48:28 --> Form Validation Class Initialized
INFO - 2018-02-18 19:48:28 --> Model Class Initialized
INFO - 2018-02-18 19:48:28 --> Controller Class Initialized
INFO - 2018-02-18 19:48:28 --> Model Class Initialized
INFO - 2018-02-18 19:48:28 --> Model Class Initialized
INFO - 2018-02-18 19:48:28 --> Model Class Initialized
INFO - 2018-02-18 19:48:28 --> Model Class Initialized
INFO - 2018-02-18 19:48:28 --> Model Class Initialized
DEBUG - 2018-02-18 19:48:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:48:28 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 19:48:28 --> Final output sent to browser
DEBUG - 2018-02-18 19:48:28 --> Total execution time: 0.0579
INFO - 2018-02-18 19:48:28 --> Config Class Initialized
INFO - 2018-02-18 19:48:28 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:48:28 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:48:28 --> Utf8 Class Initialized
INFO - 2018-02-18 19:48:28 --> URI Class Initialized
INFO - 2018-02-18 19:48:28 --> Router Class Initialized
INFO - 2018-02-18 19:48:28 --> Output Class Initialized
INFO - 2018-02-18 19:48:28 --> Security Class Initialized
DEBUG - 2018-02-18 19:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:48:28 --> Input Class Initialized
INFO - 2018-02-18 19:48:28 --> Language Class Initialized
INFO - 2018-02-18 19:48:28 --> Loader Class Initialized
INFO - 2018-02-18 19:48:28 --> Helper loaded: url_helper
INFO - 2018-02-18 19:48:28 --> Helper loaded: form_helper
INFO - 2018-02-18 19:48:28 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:48:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:48:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:48:28 --> Form Validation Class Initialized
INFO - 2018-02-18 19:48:28 --> Model Class Initialized
INFO - 2018-02-18 19:48:28 --> Controller Class Initialized
INFO - 2018-02-18 19:48:28 --> Model Class Initialized
INFO - 2018-02-18 19:48:28 --> Model Class Initialized
INFO - 2018-02-18 19:48:28 --> Model Class Initialized
INFO - 2018-02-18 19:48:28 --> Model Class Initialized
INFO - 2018-02-18 19:48:28 --> Model Class Initialized
DEBUG - 2018-02-18 19:48:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:48:46 --> Config Class Initialized
INFO - 2018-02-18 19:48:46 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:48:46 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:48:46 --> Utf8 Class Initialized
INFO - 2018-02-18 19:48:46 --> URI Class Initialized
INFO - 2018-02-18 19:48:46 --> Router Class Initialized
INFO - 2018-02-18 19:48:46 --> Output Class Initialized
INFO - 2018-02-18 19:48:46 --> Security Class Initialized
DEBUG - 2018-02-18 19:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:48:46 --> Input Class Initialized
INFO - 2018-02-18 19:48:46 --> Language Class Initialized
INFO - 2018-02-18 19:48:46 --> Loader Class Initialized
INFO - 2018-02-18 19:48:46 --> Helper loaded: url_helper
INFO - 2018-02-18 19:48:46 --> Helper loaded: form_helper
INFO - 2018-02-18 19:48:46 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:48:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:48:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:48:46 --> Form Validation Class Initialized
INFO - 2018-02-18 19:48:46 --> Model Class Initialized
INFO - 2018-02-18 19:48:46 --> Controller Class Initialized
INFO - 2018-02-18 19:48:46 --> Model Class Initialized
INFO - 2018-02-18 19:48:46 --> Model Class Initialized
INFO - 2018-02-18 19:48:46 --> Model Class Initialized
INFO - 2018-02-18 19:48:46 --> Model Class Initialized
INFO - 2018-02-18 19:48:46 --> Model Class Initialized
DEBUG - 2018-02-18 19:48:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:48:46 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 19:48:46 --> Final output sent to browser
DEBUG - 2018-02-18 19:48:46 --> Total execution time: 0.0636
INFO - 2018-02-18 19:48:46 --> Config Class Initialized
INFO - 2018-02-18 19:48:46 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:48:46 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:48:46 --> Utf8 Class Initialized
INFO - 2018-02-18 19:48:46 --> URI Class Initialized
INFO - 2018-02-18 19:48:46 --> Router Class Initialized
INFO - 2018-02-18 19:48:46 --> Output Class Initialized
INFO - 2018-02-18 19:48:46 --> Security Class Initialized
DEBUG - 2018-02-18 19:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:48:46 --> Input Class Initialized
INFO - 2018-02-18 19:48:46 --> Language Class Initialized
INFO - 2018-02-18 19:48:46 --> Loader Class Initialized
INFO - 2018-02-18 19:48:46 --> Helper loaded: url_helper
INFO - 2018-02-18 19:48:46 --> Helper loaded: form_helper
INFO - 2018-02-18 19:48:46 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:48:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:48:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:48:46 --> Form Validation Class Initialized
INFO - 2018-02-18 19:48:46 --> Model Class Initialized
INFO - 2018-02-18 19:48:46 --> Controller Class Initialized
INFO - 2018-02-18 19:48:46 --> Model Class Initialized
INFO - 2018-02-18 19:48:46 --> Model Class Initialized
INFO - 2018-02-18 19:48:46 --> Model Class Initialized
INFO - 2018-02-18 19:48:46 --> Model Class Initialized
INFO - 2018-02-18 19:48:46 --> Model Class Initialized
DEBUG - 2018-02-18 19:48:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:48:53 --> Config Class Initialized
INFO - 2018-02-18 19:48:53 --> Config Class Initialized
INFO - 2018-02-18 19:48:53 --> Hooks Class Initialized
INFO - 2018-02-18 19:48:53 --> Hooks Class Initialized
INFO - 2018-02-18 19:48:53 --> Config Class Initialized
INFO - 2018-02-18 19:48:53 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:48:53 --> UTF-8 Support Enabled
DEBUG - 2018-02-18 19:48:53 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:48:53 --> Utf8 Class Initialized
INFO - 2018-02-18 19:48:53 --> Utf8 Class Initialized
DEBUG - 2018-02-18 19:48:53 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:48:53 --> Utf8 Class Initialized
INFO - 2018-02-18 19:48:53 --> URI Class Initialized
INFO - 2018-02-18 19:48:53 --> URI Class Initialized
INFO - 2018-02-18 19:48:53 --> URI Class Initialized
INFO - 2018-02-18 19:48:53 --> Router Class Initialized
INFO - 2018-02-18 19:48:53 --> Router Class Initialized
INFO - 2018-02-18 19:48:53 --> Router Class Initialized
INFO - 2018-02-18 19:48:53 --> Output Class Initialized
INFO - 2018-02-18 19:48:53 --> Output Class Initialized
INFO - 2018-02-18 19:48:53 --> Output Class Initialized
INFO - 2018-02-18 19:48:53 --> Security Class Initialized
INFO - 2018-02-18 19:48:53 --> Security Class Initialized
INFO - 2018-02-18 19:48:53 --> Security Class Initialized
DEBUG - 2018-02-18 19:48:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-18 19:48:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:48:53 --> Input Class Initialized
INFO - 2018-02-18 19:48:53 --> Input Class Initialized
DEBUG - 2018-02-18 19:48:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:48:53 --> Input Class Initialized
INFO - 2018-02-18 19:48:53 --> Language Class Initialized
INFO - 2018-02-18 19:48:53 --> Language Class Initialized
INFO - 2018-02-18 19:48:53 --> Language Class Initialized
ERROR - 2018-02-18 19:48:53 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-18 19:48:53 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-18 19:48:53 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-18 19:49:51 --> Config Class Initialized
INFO - 2018-02-18 19:49:51 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:49:51 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:49:51 --> Utf8 Class Initialized
INFO - 2018-02-18 19:49:51 --> URI Class Initialized
INFO - 2018-02-18 19:49:51 --> Router Class Initialized
INFO - 2018-02-18 19:49:51 --> Output Class Initialized
INFO - 2018-02-18 19:49:51 --> Security Class Initialized
DEBUG - 2018-02-18 19:49:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:49:51 --> Input Class Initialized
INFO - 2018-02-18 19:49:51 --> Language Class Initialized
INFO - 2018-02-18 19:49:51 --> Loader Class Initialized
INFO - 2018-02-18 19:49:51 --> Helper loaded: url_helper
INFO - 2018-02-18 19:49:51 --> Helper loaded: form_helper
INFO - 2018-02-18 19:49:51 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:49:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:49:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:49:51 --> Form Validation Class Initialized
INFO - 2018-02-18 19:49:51 --> Model Class Initialized
INFO - 2018-02-18 19:49:51 --> Controller Class Initialized
INFO - 2018-02-18 19:49:51 --> Model Class Initialized
INFO - 2018-02-18 19:49:51 --> Model Class Initialized
INFO - 2018-02-18 19:49:51 --> Model Class Initialized
INFO - 2018-02-18 19:49:51 --> Model Class Initialized
INFO - 2018-02-18 19:49:51 --> Model Class Initialized
DEBUG - 2018-02-18 19:49:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:49:51 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 19:49:51 --> Final output sent to browser
DEBUG - 2018-02-18 19:49:51 --> Total execution time: 0.5626
INFO - 2018-02-18 19:49:51 --> Config Class Initialized
INFO - 2018-02-18 19:49:51 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:49:51 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:49:51 --> Utf8 Class Initialized
INFO - 2018-02-18 19:49:51 --> URI Class Initialized
INFO - 2018-02-18 19:49:51 --> Router Class Initialized
INFO - 2018-02-18 19:49:51 --> Output Class Initialized
INFO - 2018-02-18 19:49:51 --> Security Class Initialized
DEBUG - 2018-02-18 19:49:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:49:52 --> Input Class Initialized
INFO - 2018-02-18 19:49:52 --> Language Class Initialized
INFO - 2018-02-18 19:49:52 --> Loader Class Initialized
INFO - 2018-02-18 19:49:52 --> Helper loaded: url_helper
INFO - 2018-02-18 19:49:52 --> Helper loaded: form_helper
INFO - 2018-02-18 19:49:52 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:49:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:49:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:49:52 --> Form Validation Class Initialized
INFO - 2018-02-18 19:49:52 --> Model Class Initialized
INFO - 2018-02-18 19:49:52 --> Controller Class Initialized
INFO - 2018-02-18 19:49:52 --> Model Class Initialized
INFO - 2018-02-18 19:49:52 --> Model Class Initialized
INFO - 2018-02-18 19:49:52 --> Model Class Initialized
INFO - 2018-02-18 19:49:52 --> Model Class Initialized
INFO - 2018-02-18 19:49:52 --> Model Class Initialized
DEBUG - 2018-02-18 19:49:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:50:01 --> Config Class Initialized
INFO - 2018-02-18 19:50:01 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:50:01 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:50:01 --> Utf8 Class Initialized
INFO - 2018-02-18 19:50:01 --> URI Class Initialized
INFO - 2018-02-18 19:50:01 --> Router Class Initialized
INFO - 2018-02-18 19:50:01 --> Output Class Initialized
INFO - 2018-02-18 19:50:01 --> Security Class Initialized
DEBUG - 2018-02-18 19:50:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:50:01 --> Input Class Initialized
INFO - 2018-02-18 19:50:01 --> Language Class Initialized
INFO - 2018-02-18 19:50:01 --> Loader Class Initialized
INFO - 2018-02-18 19:50:01 --> Helper loaded: url_helper
INFO - 2018-02-18 19:50:01 --> Helper loaded: form_helper
INFO - 2018-02-18 19:50:01 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:50:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:50:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:50:01 --> Form Validation Class Initialized
INFO - 2018-02-18 19:50:01 --> Model Class Initialized
INFO - 2018-02-18 19:50:01 --> Controller Class Initialized
INFO - 2018-02-18 19:50:01 --> Model Class Initialized
INFO - 2018-02-18 19:50:01 --> Model Class Initialized
INFO - 2018-02-18 19:50:01 --> Model Class Initialized
INFO - 2018-02-18 19:50:01 --> Model Class Initialized
INFO - 2018-02-18 19:50:01 --> Model Class Initialized
DEBUG - 2018-02-18 19:50:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:50:07 --> Config Class Initialized
INFO - 2018-02-18 19:50:07 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:50:07 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:50:07 --> Utf8 Class Initialized
INFO - 2018-02-18 19:50:07 --> URI Class Initialized
INFO - 2018-02-18 19:50:07 --> Router Class Initialized
INFO - 2018-02-18 19:50:07 --> Output Class Initialized
INFO - 2018-02-18 19:50:07 --> Security Class Initialized
DEBUG - 2018-02-18 19:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:50:07 --> Input Class Initialized
INFO - 2018-02-18 19:50:07 --> Language Class Initialized
INFO - 2018-02-18 19:50:07 --> Loader Class Initialized
INFO - 2018-02-18 19:50:07 --> Helper loaded: url_helper
INFO - 2018-02-18 19:50:07 --> Helper loaded: form_helper
INFO - 2018-02-18 19:50:07 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:50:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:50:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:50:07 --> Form Validation Class Initialized
INFO - 2018-02-18 19:50:07 --> Model Class Initialized
INFO - 2018-02-18 19:50:07 --> Controller Class Initialized
INFO - 2018-02-18 19:50:07 --> Model Class Initialized
INFO - 2018-02-18 19:50:07 --> Model Class Initialized
INFO - 2018-02-18 19:50:07 --> Model Class Initialized
INFO - 2018-02-18 19:50:07 --> Model Class Initialized
INFO - 2018-02-18 19:50:07 --> Model Class Initialized
DEBUG - 2018-02-18 19:50:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:51:04 --> Config Class Initialized
INFO - 2018-02-18 19:51:04 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:51:04 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:51:04 --> Utf8 Class Initialized
INFO - 2018-02-18 19:51:04 --> URI Class Initialized
INFO - 2018-02-18 19:51:04 --> Router Class Initialized
INFO - 2018-02-18 19:51:04 --> Output Class Initialized
INFO - 2018-02-18 19:51:04 --> Security Class Initialized
DEBUG - 2018-02-18 19:51:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:51:04 --> Input Class Initialized
INFO - 2018-02-18 19:51:04 --> Language Class Initialized
INFO - 2018-02-18 19:51:04 --> Loader Class Initialized
INFO - 2018-02-18 19:51:04 --> Helper loaded: url_helper
INFO - 2018-02-18 19:51:04 --> Helper loaded: form_helper
INFO - 2018-02-18 19:51:04 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:51:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:51:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:51:04 --> Form Validation Class Initialized
INFO - 2018-02-18 19:51:04 --> Model Class Initialized
INFO - 2018-02-18 19:51:04 --> Controller Class Initialized
INFO - 2018-02-18 19:51:04 --> Model Class Initialized
INFO - 2018-02-18 19:51:04 --> Model Class Initialized
INFO - 2018-02-18 19:51:04 --> Model Class Initialized
INFO - 2018-02-18 19:51:04 --> Model Class Initialized
INFO - 2018-02-18 19:51:04 --> Model Class Initialized
DEBUG - 2018-02-18 19:51:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:51:04 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 19:51:04 --> Final output sent to browser
DEBUG - 2018-02-18 19:51:04 --> Total execution time: 0.0613
INFO - 2018-02-18 19:51:05 --> Config Class Initialized
INFO - 2018-02-18 19:51:05 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:51:05 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:51:05 --> Utf8 Class Initialized
INFO - 2018-02-18 19:51:05 --> URI Class Initialized
INFO - 2018-02-18 19:51:05 --> Router Class Initialized
INFO - 2018-02-18 19:51:05 --> Output Class Initialized
INFO - 2018-02-18 19:51:05 --> Security Class Initialized
DEBUG - 2018-02-18 19:51:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:51:05 --> Input Class Initialized
INFO - 2018-02-18 19:51:05 --> Language Class Initialized
INFO - 2018-02-18 19:51:05 --> Loader Class Initialized
INFO - 2018-02-18 19:51:05 --> Helper loaded: url_helper
INFO - 2018-02-18 19:51:05 --> Helper loaded: form_helper
INFO - 2018-02-18 19:51:05 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:51:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:51:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:51:05 --> Form Validation Class Initialized
INFO - 2018-02-18 19:51:05 --> Model Class Initialized
INFO - 2018-02-18 19:51:05 --> Controller Class Initialized
INFO - 2018-02-18 19:51:05 --> Model Class Initialized
INFO - 2018-02-18 19:51:05 --> Model Class Initialized
INFO - 2018-02-18 19:51:05 --> Model Class Initialized
INFO - 2018-02-18 19:51:05 --> Model Class Initialized
INFO - 2018-02-18 19:51:05 --> Model Class Initialized
DEBUG - 2018-02-18 19:51:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:51:14 --> Config Class Initialized
INFO - 2018-02-18 19:51:14 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:51:14 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:51:14 --> Utf8 Class Initialized
INFO - 2018-02-18 19:51:14 --> URI Class Initialized
INFO - 2018-02-18 19:51:14 --> Router Class Initialized
INFO - 2018-02-18 19:51:14 --> Output Class Initialized
INFO - 2018-02-18 19:51:14 --> Security Class Initialized
DEBUG - 2018-02-18 19:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:51:14 --> Input Class Initialized
INFO - 2018-02-18 19:51:14 --> Language Class Initialized
INFO - 2018-02-18 19:51:14 --> Loader Class Initialized
INFO - 2018-02-18 19:51:14 --> Helper loaded: url_helper
INFO - 2018-02-18 19:51:14 --> Helper loaded: form_helper
INFO - 2018-02-18 19:51:14 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:51:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:51:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:51:14 --> Form Validation Class Initialized
INFO - 2018-02-18 19:51:14 --> Model Class Initialized
INFO - 2018-02-18 19:51:14 --> Controller Class Initialized
INFO - 2018-02-18 19:51:14 --> Model Class Initialized
INFO - 2018-02-18 19:51:14 --> Model Class Initialized
INFO - 2018-02-18 19:51:14 --> Model Class Initialized
INFO - 2018-02-18 19:51:14 --> Model Class Initialized
INFO - 2018-02-18 19:51:14 --> Model Class Initialized
DEBUG - 2018-02-18 19:51:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:51:14 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 19:51:14 --> Final output sent to browser
DEBUG - 2018-02-18 19:51:14 --> Total execution time: 0.0572
INFO - 2018-02-18 19:51:14 --> Config Class Initialized
INFO - 2018-02-18 19:51:14 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:51:14 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:51:14 --> Utf8 Class Initialized
INFO - 2018-02-18 19:51:14 --> URI Class Initialized
INFO - 2018-02-18 19:51:14 --> Router Class Initialized
INFO - 2018-02-18 19:51:14 --> Output Class Initialized
INFO - 2018-02-18 19:51:14 --> Security Class Initialized
DEBUG - 2018-02-18 19:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:51:14 --> Input Class Initialized
INFO - 2018-02-18 19:51:14 --> Language Class Initialized
INFO - 2018-02-18 19:51:14 --> Loader Class Initialized
INFO - 2018-02-18 19:51:14 --> Helper loaded: url_helper
INFO - 2018-02-18 19:51:14 --> Helper loaded: form_helper
INFO - 2018-02-18 19:51:14 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:51:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:51:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:51:14 --> Form Validation Class Initialized
INFO - 2018-02-18 19:51:14 --> Model Class Initialized
INFO - 2018-02-18 19:51:14 --> Controller Class Initialized
INFO - 2018-02-18 19:51:14 --> Model Class Initialized
INFO - 2018-02-18 19:51:14 --> Model Class Initialized
INFO - 2018-02-18 19:51:14 --> Model Class Initialized
INFO - 2018-02-18 19:51:14 --> Model Class Initialized
INFO - 2018-02-18 19:51:14 --> Model Class Initialized
DEBUG - 2018-02-18 19:51:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:51:16 --> Config Class Initialized
INFO - 2018-02-18 19:51:16 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:51:16 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:51:16 --> Utf8 Class Initialized
INFO - 2018-02-18 19:51:16 --> URI Class Initialized
INFO - 2018-02-18 19:51:16 --> Router Class Initialized
INFO - 2018-02-18 19:51:16 --> Output Class Initialized
INFO - 2018-02-18 19:51:16 --> Security Class Initialized
DEBUG - 2018-02-18 19:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:51:16 --> Input Class Initialized
INFO - 2018-02-18 19:51:16 --> Language Class Initialized
INFO - 2018-02-18 19:51:16 --> Loader Class Initialized
INFO - 2018-02-18 19:51:16 --> Helper loaded: url_helper
INFO - 2018-02-18 19:51:16 --> Helper loaded: form_helper
INFO - 2018-02-18 19:51:16 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:51:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:51:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:51:16 --> Form Validation Class Initialized
INFO - 2018-02-18 19:51:16 --> Model Class Initialized
INFO - 2018-02-18 19:51:16 --> Controller Class Initialized
INFO - 2018-02-18 19:51:16 --> Model Class Initialized
INFO - 2018-02-18 19:51:16 --> Model Class Initialized
INFO - 2018-02-18 19:51:16 --> Model Class Initialized
INFO - 2018-02-18 19:51:16 --> Model Class Initialized
INFO - 2018-02-18 19:51:16 --> Model Class Initialized
DEBUG - 2018-02-18 19:51:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:51:16 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 19:51:16 --> Final output sent to browser
DEBUG - 2018-02-18 19:51:16 --> Total execution time: 0.0872
INFO - 2018-02-18 19:51:16 --> Config Class Initialized
INFO - 2018-02-18 19:51:16 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:51:16 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:51:16 --> Utf8 Class Initialized
INFO - 2018-02-18 19:51:16 --> URI Class Initialized
INFO - 2018-02-18 19:51:16 --> Router Class Initialized
INFO - 2018-02-18 19:51:16 --> Output Class Initialized
INFO - 2018-02-18 19:51:16 --> Security Class Initialized
DEBUG - 2018-02-18 19:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:51:16 --> Input Class Initialized
INFO - 2018-02-18 19:51:16 --> Language Class Initialized
INFO - 2018-02-18 19:51:16 --> Loader Class Initialized
INFO - 2018-02-18 19:51:16 --> Helper loaded: url_helper
INFO - 2018-02-18 19:51:16 --> Helper loaded: form_helper
INFO - 2018-02-18 19:51:16 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:51:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:51:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:51:16 --> Form Validation Class Initialized
INFO - 2018-02-18 19:51:16 --> Model Class Initialized
INFO - 2018-02-18 19:51:16 --> Controller Class Initialized
INFO - 2018-02-18 19:51:16 --> Model Class Initialized
INFO - 2018-02-18 19:51:16 --> Model Class Initialized
INFO - 2018-02-18 19:51:16 --> Model Class Initialized
INFO - 2018-02-18 19:51:16 --> Model Class Initialized
INFO - 2018-02-18 19:51:16 --> Model Class Initialized
DEBUG - 2018-02-18 19:51:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:51:22 --> Config Class Initialized
INFO - 2018-02-18 19:51:22 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:51:22 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:51:22 --> Utf8 Class Initialized
INFO - 2018-02-18 19:51:22 --> URI Class Initialized
INFO - 2018-02-18 19:51:22 --> Router Class Initialized
INFO - 2018-02-18 19:51:22 --> Output Class Initialized
INFO - 2018-02-18 19:51:22 --> Security Class Initialized
DEBUG - 2018-02-18 19:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:51:22 --> Input Class Initialized
INFO - 2018-02-18 19:51:22 --> Language Class Initialized
INFO - 2018-02-18 19:51:22 --> Loader Class Initialized
INFO - 2018-02-18 19:51:22 --> Helper loaded: url_helper
INFO - 2018-02-18 19:51:22 --> Helper loaded: form_helper
INFO - 2018-02-18 19:51:22 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:51:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:51:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:51:22 --> Form Validation Class Initialized
INFO - 2018-02-18 19:51:22 --> Model Class Initialized
INFO - 2018-02-18 19:51:22 --> Controller Class Initialized
INFO - 2018-02-18 19:51:22 --> Model Class Initialized
INFO - 2018-02-18 19:51:22 --> Model Class Initialized
INFO - 2018-02-18 19:51:22 --> Model Class Initialized
INFO - 2018-02-18 19:51:22 --> Model Class Initialized
INFO - 2018-02-18 19:51:22 --> Model Class Initialized
DEBUG - 2018-02-18 19:51:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:51:22 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 19:51:22 --> Final output sent to browser
DEBUG - 2018-02-18 19:51:22 --> Total execution time: 0.0594
INFO - 2018-02-18 19:51:22 --> Config Class Initialized
INFO - 2018-02-18 19:51:22 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:51:22 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:51:22 --> Utf8 Class Initialized
INFO - 2018-02-18 19:51:22 --> URI Class Initialized
INFO - 2018-02-18 19:51:22 --> Router Class Initialized
INFO - 2018-02-18 19:51:22 --> Output Class Initialized
INFO - 2018-02-18 19:51:22 --> Security Class Initialized
DEBUG - 2018-02-18 19:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:51:22 --> Input Class Initialized
INFO - 2018-02-18 19:51:22 --> Language Class Initialized
INFO - 2018-02-18 19:51:22 --> Loader Class Initialized
INFO - 2018-02-18 19:51:22 --> Helper loaded: url_helper
INFO - 2018-02-18 19:51:22 --> Helper loaded: form_helper
INFO - 2018-02-18 19:51:22 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:51:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:51:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:51:22 --> Form Validation Class Initialized
INFO - 2018-02-18 19:51:22 --> Model Class Initialized
INFO - 2018-02-18 19:51:22 --> Controller Class Initialized
INFO - 2018-02-18 19:51:22 --> Model Class Initialized
INFO - 2018-02-18 19:51:22 --> Model Class Initialized
INFO - 2018-02-18 19:51:22 --> Model Class Initialized
INFO - 2018-02-18 19:51:22 --> Model Class Initialized
INFO - 2018-02-18 19:51:22 --> Model Class Initialized
DEBUG - 2018-02-18 19:51:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:58:03 --> Config Class Initialized
INFO - 2018-02-18 19:58:03 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:58:03 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:58:03 --> Utf8 Class Initialized
INFO - 2018-02-18 19:58:03 --> URI Class Initialized
INFO - 2018-02-18 19:58:03 --> Router Class Initialized
INFO - 2018-02-18 19:58:03 --> Output Class Initialized
INFO - 2018-02-18 19:58:03 --> Security Class Initialized
DEBUG - 2018-02-18 19:58:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:58:03 --> Input Class Initialized
INFO - 2018-02-18 19:58:03 --> Language Class Initialized
INFO - 2018-02-18 19:58:03 --> Loader Class Initialized
INFO - 2018-02-18 19:58:03 --> Helper loaded: url_helper
INFO - 2018-02-18 19:58:03 --> Helper loaded: form_helper
INFO - 2018-02-18 19:58:03 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:58:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:58:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:58:03 --> Form Validation Class Initialized
INFO - 2018-02-18 19:58:03 --> Model Class Initialized
INFO - 2018-02-18 19:58:03 --> Controller Class Initialized
INFO - 2018-02-18 19:58:03 --> Model Class Initialized
INFO - 2018-02-18 19:58:03 --> Model Class Initialized
INFO - 2018-02-18 19:58:03 --> Model Class Initialized
INFO - 2018-02-18 19:58:03 --> Model Class Initialized
INFO - 2018-02-18 19:58:03 --> Model Class Initialized
DEBUG - 2018-02-18 19:58:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 19:58:03 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 19:58:03 --> Final output sent to browser
DEBUG - 2018-02-18 19:58:03 --> Total execution time: 0.0674
INFO - 2018-02-18 19:58:03 --> Config Class Initialized
INFO - 2018-02-18 19:58:03 --> Hooks Class Initialized
DEBUG - 2018-02-18 19:58:03 --> UTF-8 Support Enabled
INFO - 2018-02-18 19:58:03 --> Utf8 Class Initialized
INFO - 2018-02-18 19:58:03 --> URI Class Initialized
INFO - 2018-02-18 19:58:03 --> Router Class Initialized
INFO - 2018-02-18 19:58:03 --> Output Class Initialized
INFO - 2018-02-18 19:58:03 --> Security Class Initialized
DEBUG - 2018-02-18 19:58:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 19:58:03 --> Input Class Initialized
INFO - 2018-02-18 19:58:03 --> Language Class Initialized
INFO - 2018-02-18 19:58:03 --> Loader Class Initialized
INFO - 2018-02-18 19:58:03 --> Helper loaded: url_helper
INFO - 2018-02-18 19:58:03 --> Helper loaded: form_helper
INFO - 2018-02-18 19:58:03 --> Database Driver Class Initialized
DEBUG - 2018-02-18 19:58:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 19:58:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 19:58:03 --> Form Validation Class Initialized
INFO - 2018-02-18 19:58:03 --> Model Class Initialized
INFO - 2018-02-18 19:58:03 --> Controller Class Initialized
INFO - 2018-02-18 19:58:03 --> Model Class Initialized
INFO - 2018-02-18 19:58:03 --> Model Class Initialized
INFO - 2018-02-18 19:58:03 --> Model Class Initialized
INFO - 2018-02-18 19:58:03 --> Model Class Initialized
INFO - 2018-02-18 19:58:03 --> Model Class Initialized
DEBUG - 2018-02-18 19:58:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 20:02:59 --> Config Class Initialized
INFO - 2018-02-18 20:02:59 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:02:59 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:02:59 --> Utf8 Class Initialized
INFO - 2018-02-18 20:02:59 --> URI Class Initialized
INFO - 2018-02-18 20:02:59 --> Router Class Initialized
INFO - 2018-02-18 20:02:59 --> Output Class Initialized
INFO - 2018-02-18 20:02:59 --> Security Class Initialized
DEBUG - 2018-02-18 20:02:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:02:59 --> Input Class Initialized
INFO - 2018-02-18 20:02:59 --> Language Class Initialized
INFO - 2018-02-18 20:02:59 --> Loader Class Initialized
INFO - 2018-02-18 20:02:59 --> Helper loaded: url_helper
INFO - 2018-02-18 20:02:59 --> Helper loaded: form_helper
INFO - 2018-02-18 20:02:59 --> Database Driver Class Initialized
DEBUG - 2018-02-18 20:02:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 20:02:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 20:02:59 --> Form Validation Class Initialized
INFO - 2018-02-18 20:02:59 --> Model Class Initialized
INFO - 2018-02-18 20:02:59 --> Controller Class Initialized
INFO - 2018-02-18 20:02:59 --> Model Class Initialized
INFO - 2018-02-18 20:02:59 --> Model Class Initialized
INFO - 2018-02-18 20:02:59 --> Model Class Initialized
INFO - 2018-02-18 20:02:59 --> Model Class Initialized
INFO - 2018-02-18 20:02:59 --> Model Class Initialized
DEBUG - 2018-02-18 20:02:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 20:02:59 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 20:02:59 --> Final output sent to browser
DEBUG - 2018-02-18 20:02:59 --> Total execution time: 0.0713
INFO - 2018-02-18 20:02:59 --> Config Class Initialized
INFO - 2018-02-18 20:02:59 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:02:59 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:02:59 --> Utf8 Class Initialized
INFO - 2018-02-18 20:02:59 --> URI Class Initialized
INFO - 2018-02-18 20:02:59 --> Router Class Initialized
INFO - 2018-02-18 20:02:59 --> Output Class Initialized
INFO - 2018-02-18 20:02:59 --> Security Class Initialized
DEBUG - 2018-02-18 20:02:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:02:59 --> Input Class Initialized
INFO - 2018-02-18 20:02:59 --> Language Class Initialized
INFO - 2018-02-18 20:02:59 --> Loader Class Initialized
INFO - 2018-02-18 20:02:59 --> Helper loaded: url_helper
INFO - 2018-02-18 20:02:59 --> Helper loaded: form_helper
INFO - 2018-02-18 20:02:59 --> Database Driver Class Initialized
DEBUG - 2018-02-18 20:02:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 20:02:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 20:02:59 --> Form Validation Class Initialized
INFO - 2018-02-18 20:02:59 --> Model Class Initialized
INFO - 2018-02-18 20:02:59 --> Controller Class Initialized
INFO - 2018-02-18 20:02:59 --> Model Class Initialized
INFO - 2018-02-18 20:02:59 --> Model Class Initialized
INFO - 2018-02-18 20:02:59 --> Model Class Initialized
INFO - 2018-02-18 20:02:59 --> Model Class Initialized
INFO - 2018-02-18 20:02:59 --> Model Class Initialized
DEBUG - 2018-02-18 20:02:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 20:03:07 --> Config Class Initialized
INFO - 2018-02-18 20:03:07 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:03:07 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:03:07 --> Utf8 Class Initialized
INFO - 2018-02-18 20:03:07 --> URI Class Initialized
INFO - 2018-02-18 20:03:07 --> Router Class Initialized
INFO - 2018-02-18 20:03:07 --> Output Class Initialized
INFO - 2018-02-18 20:03:07 --> Security Class Initialized
DEBUG - 2018-02-18 20:03:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:03:07 --> Input Class Initialized
INFO - 2018-02-18 20:03:07 --> Language Class Initialized
INFO - 2018-02-18 20:03:07 --> Loader Class Initialized
INFO - 2018-02-18 20:03:07 --> Helper loaded: url_helper
INFO - 2018-02-18 20:03:07 --> Helper loaded: form_helper
INFO - 2018-02-18 20:03:07 --> Database Driver Class Initialized
DEBUG - 2018-02-18 20:03:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 20:03:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 20:03:07 --> Form Validation Class Initialized
INFO - 2018-02-18 20:03:07 --> Model Class Initialized
INFO - 2018-02-18 20:03:07 --> Controller Class Initialized
INFO - 2018-02-18 20:03:07 --> Model Class Initialized
INFO - 2018-02-18 20:03:07 --> Model Class Initialized
INFO - 2018-02-18 20:03:07 --> Model Class Initialized
INFO - 2018-02-18 20:03:07 --> Model Class Initialized
INFO - 2018-02-18 20:03:07 --> Model Class Initialized
DEBUG - 2018-02-18 20:03:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 20:03:11 --> Config Class Initialized
INFO - 2018-02-18 20:03:11 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:03:11 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:03:11 --> Utf8 Class Initialized
INFO - 2018-02-18 20:03:11 --> URI Class Initialized
INFO - 2018-02-18 20:03:11 --> Router Class Initialized
INFO - 2018-02-18 20:03:11 --> Output Class Initialized
INFO - 2018-02-18 20:03:11 --> Security Class Initialized
DEBUG - 2018-02-18 20:03:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:03:11 --> Input Class Initialized
INFO - 2018-02-18 20:03:11 --> Language Class Initialized
INFO - 2018-02-18 20:03:11 --> Loader Class Initialized
INFO - 2018-02-18 20:03:11 --> Helper loaded: url_helper
INFO - 2018-02-18 20:03:11 --> Helper loaded: form_helper
INFO - 2018-02-18 20:03:11 --> Database Driver Class Initialized
DEBUG - 2018-02-18 20:03:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 20:03:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 20:03:11 --> Form Validation Class Initialized
INFO - 2018-02-18 20:03:11 --> Model Class Initialized
INFO - 2018-02-18 20:03:11 --> Controller Class Initialized
INFO - 2018-02-18 20:03:11 --> Model Class Initialized
INFO - 2018-02-18 20:03:11 --> Model Class Initialized
INFO - 2018-02-18 20:03:11 --> Model Class Initialized
INFO - 2018-02-18 20:03:11 --> Model Class Initialized
INFO - 2018-02-18 20:03:11 --> Model Class Initialized
DEBUG - 2018-02-18 20:03:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 20:03:14 --> Config Class Initialized
INFO - 2018-02-18 20:03:14 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:03:14 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:03:14 --> Utf8 Class Initialized
INFO - 2018-02-18 20:03:14 --> URI Class Initialized
INFO - 2018-02-18 20:03:14 --> Router Class Initialized
INFO - 2018-02-18 20:03:14 --> Output Class Initialized
INFO - 2018-02-18 20:03:14 --> Security Class Initialized
DEBUG - 2018-02-18 20:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:03:14 --> Input Class Initialized
INFO - 2018-02-18 20:03:14 --> Language Class Initialized
INFO - 2018-02-18 20:03:14 --> Loader Class Initialized
INFO - 2018-02-18 20:03:14 --> Helper loaded: url_helper
INFO - 2018-02-18 20:03:14 --> Helper loaded: form_helper
INFO - 2018-02-18 20:03:14 --> Database Driver Class Initialized
DEBUG - 2018-02-18 20:03:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 20:03:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 20:03:14 --> Form Validation Class Initialized
INFO - 2018-02-18 20:03:14 --> Model Class Initialized
INFO - 2018-02-18 20:03:14 --> Controller Class Initialized
INFO - 2018-02-18 20:03:14 --> Model Class Initialized
INFO - 2018-02-18 20:03:14 --> Model Class Initialized
INFO - 2018-02-18 20:03:14 --> Model Class Initialized
INFO - 2018-02-18 20:03:14 --> Model Class Initialized
INFO - 2018-02-18 20:03:14 --> Model Class Initialized
DEBUG - 2018-02-18 20:03:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 20:03:22 --> Config Class Initialized
INFO - 2018-02-18 20:03:22 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:03:22 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:03:22 --> Utf8 Class Initialized
INFO - 2018-02-18 20:03:22 --> URI Class Initialized
INFO - 2018-02-18 20:03:22 --> Router Class Initialized
INFO - 2018-02-18 20:03:22 --> Output Class Initialized
INFO - 2018-02-18 20:03:22 --> Security Class Initialized
DEBUG - 2018-02-18 20:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:03:22 --> Input Class Initialized
INFO - 2018-02-18 20:03:22 --> Language Class Initialized
INFO - 2018-02-18 20:03:22 --> Loader Class Initialized
INFO - 2018-02-18 20:03:22 --> Helper loaded: url_helper
INFO - 2018-02-18 20:03:22 --> Helper loaded: form_helper
INFO - 2018-02-18 20:03:22 --> Database Driver Class Initialized
DEBUG - 2018-02-18 20:03:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 20:03:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 20:03:23 --> Form Validation Class Initialized
INFO - 2018-02-18 20:03:23 --> Model Class Initialized
INFO - 2018-02-18 20:03:23 --> Controller Class Initialized
INFO - 2018-02-18 20:03:23 --> Model Class Initialized
INFO - 2018-02-18 20:03:23 --> Model Class Initialized
INFO - 2018-02-18 20:03:23 --> Model Class Initialized
INFO - 2018-02-18 20:03:23 --> Model Class Initialized
INFO - 2018-02-18 20:03:23 --> Model Class Initialized
DEBUG - 2018-02-18 20:03:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 20:03:23 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 20:03:23 --> Final output sent to browser
DEBUG - 2018-02-18 20:03:23 --> Total execution time: 0.0820
INFO - 2018-02-18 20:03:23 --> Config Class Initialized
INFO - 2018-02-18 20:03:23 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:03:23 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:03:23 --> Utf8 Class Initialized
INFO - 2018-02-18 20:03:23 --> URI Class Initialized
INFO - 2018-02-18 20:03:23 --> Router Class Initialized
INFO - 2018-02-18 20:03:23 --> Output Class Initialized
INFO - 2018-02-18 20:03:23 --> Security Class Initialized
DEBUG - 2018-02-18 20:03:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:03:23 --> Input Class Initialized
INFO - 2018-02-18 20:03:23 --> Language Class Initialized
INFO - 2018-02-18 20:03:23 --> Loader Class Initialized
INFO - 2018-02-18 20:03:23 --> Helper loaded: url_helper
INFO - 2018-02-18 20:03:23 --> Helper loaded: form_helper
INFO - 2018-02-18 20:03:23 --> Database Driver Class Initialized
DEBUG - 2018-02-18 20:03:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 20:03:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 20:03:23 --> Form Validation Class Initialized
INFO - 2018-02-18 20:03:23 --> Model Class Initialized
INFO - 2018-02-18 20:03:23 --> Controller Class Initialized
INFO - 2018-02-18 20:03:23 --> Model Class Initialized
INFO - 2018-02-18 20:03:23 --> Model Class Initialized
INFO - 2018-02-18 20:03:23 --> Model Class Initialized
INFO - 2018-02-18 20:03:23 --> Model Class Initialized
INFO - 2018-02-18 20:03:23 --> Model Class Initialized
DEBUG - 2018-02-18 20:03:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 20:05:28 --> Config Class Initialized
INFO - 2018-02-18 20:05:28 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:05:28 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:05:28 --> Utf8 Class Initialized
INFO - 2018-02-18 20:05:28 --> URI Class Initialized
INFO - 2018-02-18 20:05:28 --> Router Class Initialized
INFO - 2018-02-18 20:05:28 --> Output Class Initialized
INFO - 2018-02-18 20:05:28 --> Security Class Initialized
DEBUG - 2018-02-18 20:05:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:05:28 --> Input Class Initialized
INFO - 2018-02-18 20:05:28 --> Language Class Initialized
INFO - 2018-02-18 20:05:28 --> Loader Class Initialized
INFO - 2018-02-18 20:05:28 --> Helper loaded: url_helper
INFO - 2018-02-18 20:05:28 --> Helper loaded: form_helper
INFO - 2018-02-18 20:05:28 --> Database Driver Class Initialized
DEBUG - 2018-02-18 20:05:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 20:05:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 20:05:28 --> Form Validation Class Initialized
INFO - 2018-02-18 20:05:28 --> Model Class Initialized
INFO - 2018-02-18 20:05:28 --> Controller Class Initialized
INFO - 2018-02-18 20:05:28 --> Model Class Initialized
INFO - 2018-02-18 20:05:28 --> Model Class Initialized
INFO - 2018-02-18 20:05:28 --> Model Class Initialized
INFO - 2018-02-18 20:05:28 --> Model Class Initialized
INFO - 2018-02-18 20:05:28 --> Model Class Initialized
DEBUG - 2018-02-18 20:05:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 20:05:28 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 20:05:28 --> Final output sent to browser
DEBUG - 2018-02-18 20:05:28 --> Total execution time: 0.0582
INFO - 2018-02-18 20:05:28 --> Config Class Initialized
INFO - 2018-02-18 20:05:28 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:05:28 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:05:28 --> Utf8 Class Initialized
INFO - 2018-02-18 20:05:28 --> URI Class Initialized
INFO - 2018-02-18 20:05:28 --> Router Class Initialized
INFO - 2018-02-18 20:05:28 --> Output Class Initialized
INFO - 2018-02-18 20:05:28 --> Security Class Initialized
DEBUG - 2018-02-18 20:05:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:05:28 --> Input Class Initialized
INFO - 2018-02-18 20:05:28 --> Language Class Initialized
INFO - 2018-02-18 20:05:28 --> Loader Class Initialized
INFO - 2018-02-18 20:05:28 --> Helper loaded: url_helper
INFO - 2018-02-18 20:05:28 --> Helper loaded: form_helper
INFO - 2018-02-18 20:05:28 --> Database Driver Class Initialized
DEBUG - 2018-02-18 20:05:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 20:05:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 20:05:28 --> Form Validation Class Initialized
INFO - 2018-02-18 20:05:28 --> Model Class Initialized
INFO - 2018-02-18 20:05:28 --> Controller Class Initialized
INFO - 2018-02-18 20:05:28 --> Model Class Initialized
INFO - 2018-02-18 20:05:28 --> Model Class Initialized
INFO - 2018-02-18 20:05:28 --> Model Class Initialized
INFO - 2018-02-18 20:05:28 --> Model Class Initialized
INFO - 2018-02-18 20:05:28 --> Model Class Initialized
DEBUG - 2018-02-18 20:05:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 20:05:43 --> Config Class Initialized
INFO - 2018-02-18 20:05:43 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:05:43 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:05:43 --> Utf8 Class Initialized
INFO - 2018-02-18 20:05:43 --> URI Class Initialized
INFO - 2018-02-18 20:05:43 --> Router Class Initialized
INFO - 2018-02-18 20:05:43 --> Output Class Initialized
INFO - 2018-02-18 20:05:43 --> Security Class Initialized
DEBUG - 2018-02-18 20:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:05:43 --> Input Class Initialized
INFO - 2018-02-18 20:05:43 --> Language Class Initialized
INFO - 2018-02-18 20:05:43 --> Loader Class Initialized
INFO - 2018-02-18 20:05:43 --> Helper loaded: url_helper
INFO - 2018-02-18 20:05:43 --> Helper loaded: form_helper
INFO - 2018-02-18 20:05:43 --> Database Driver Class Initialized
DEBUG - 2018-02-18 20:05:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 20:05:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 20:05:43 --> Form Validation Class Initialized
INFO - 2018-02-18 20:05:43 --> Model Class Initialized
INFO - 2018-02-18 20:05:43 --> Controller Class Initialized
INFO - 2018-02-18 20:05:43 --> Model Class Initialized
INFO - 2018-02-18 20:05:43 --> Model Class Initialized
INFO - 2018-02-18 20:05:43 --> Model Class Initialized
INFO - 2018-02-18 20:05:43 --> Model Class Initialized
INFO - 2018-02-18 20:05:43 --> Model Class Initialized
DEBUG - 2018-02-18 20:05:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 20:05:43 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 20:05:43 --> Final output sent to browser
DEBUG - 2018-02-18 20:05:43 --> Total execution time: 0.0603
INFO - 2018-02-18 20:05:43 --> Config Class Initialized
INFO - 2018-02-18 20:05:43 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:05:43 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:05:43 --> Utf8 Class Initialized
INFO - 2018-02-18 20:05:43 --> URI Class Initialized
INFO - 2018-02-18 20:05:43 --> Router Class Initialized
INFO - 2018-02-18 20:05:43 --> Output Class Initialized
INFO - 2018-02-18 20:05:43 --> Security Class Initialized
DEBUG - 2018-02-18 20:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:05:43 --> Input Class Initialized
INFO - 2018-02-18 20:05:43 --> Language Class Initialized
INFO - 2018-02-18 20:05:43 --> Loader Class Initialized
INFO - 2018-02-18 20:05:43 --> Helper loaded: url_helper
INFO - 2018-02-18 20:05:43 --> Helper loaded: form_helper
INFO - 2018-02-18 20:05:43 --> Database Driver Class Initialized
DEBUG - 2018-02-18 20:05:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 20:05:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 20:05:43 --> Form Validation Class Initialized
INFO - 2018-02-18 20:05:43 --> Model Class Initialized
INFO - 2018-02-18 20:05:43 --> Controller Class Initialized
INFO - 2018-02-18 20:05:43 --> Model Class Initialized
INFO - 2018-02-18 20:05:43 --> Model Class Initialized
INFO - 2018-02-18 20:05:43 --> Model Class Initialized
INFO - 2018-02-18 20:05:43 --> Model Class Initialized
INFO - 2018-02-18 20:05:43 --> Model Class Initialized
DEBUG - 2018-02-18 20:05:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 20:06:46 --> Config Class Initialized
INFO - 2018-02-18 20:06:46 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:06:46 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:06:46 --> Utf8 Class Initialized
INFO - 2018-02-18 20:06:46 --> URI Class Initialized
INFO - 2018-02-18 20:06:46 --> Router Class Initialized
INFO - 2018-02-18 20:06:46 --> Output Class Initialized
INFO - 2018-02-18 20:06:46 --> Security Class Initialized
DEBUG - 2018-02-18 20:06:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:06:46 --> Input Class Initialized
INFO - 2018-02-18 20:06:46 --> Language Class Initialized
INFO - 2018-02-18 20:06:46 --> Loader Class Initialized
INFO - 2018-02-18 20:06:46 --> Helper loaded: url_helper
INFO - 2018-02-18 20:06:46 --> Helper loaded: form_helper
INFO - 2018-02-18 20:06:46 --> Database Driver Class Initialized
DEBUG - 2018-02-18 20:06:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 20:06:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 20:06:46 --> Form Validation Class Initialized
INFO - 2018-02-18 20:06:47 --> Model Class Initialized
INFO - 2018-02-18 20:06:47 --> Controller Class Initialized
INFO - 2018-02-18 20:06:47 --> Model Class Initialized
INFO - 2018-02-18 20:06:47 --> Model Class Initialized
INFO - 2018-02-18 20:06:47 --> Model Class Initialized
INFO - 2018-02-18 20:06:47 --> Model Class Initialized
INFO - 2018-02-18 20:06:47 --> Model Class Initialized
DEBUG - 2018-02-18 20:06:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 20:06:47 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 20:06:47 --> Final output sent to browser
DEBUG - 2018-02-18 20:06:47 --> Total execution time: 0.0675
INFO - 2018-02-18 20:06:47 --> Config Class Initialized
INFO - 2018-02-18 20:06:47 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:06:47 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:06:47 --> Utf8 Class Initialized
INFO - 2018-02-18 20:06:47 --> URI Class Initialized
INFO - 2018-02-18 20:06:47 --> Router Class Initialized
INFO - 2018-02-18 20:06:47 --> Output Class Initialized
INFO - 2018-02-18 20:06:47 --> Security Class Initialized
DEBUG - 2018-02-18 20:06:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:06:47 --> Input Class Initialized
INFO - 2018-02-18 20:06:47 --> Language Class Initialized
INFO - 2018-02-18 20:06:47 --> Loader Class Initialized
INFO - 2018-02-18 20:06:47 --> Helper loaded: url_helper
INFO - 2018-02-18 20:06:47 --> Helper loaded: form_helper
INFO - 2018-02-18 20:06:47 --> Database Driver Class Initialized
DEBUG - 2018-02-18 20:06:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 20:06:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 20:06:47 --> Form Validation Class Initialized
INFO - 2018-02-18 20:06:47 --> Model Class Initialized
INFO - 2018-02-18 20:06:47 --> Controller Class Initialized
INFO - 2018-02-18 20:06:47 --> Model Class Initialized
INFO - 2018-02-18 20:06:47 --> Model Class Initialized
INFO - 2018-02-18 20:06:47 --> Model Class Initialized
INFO - 2018-02-18 20:06:47 --> Model Class Initialized
INFO - 2018-02-18 20:06:47 --> Model Class Initialized
DEBUG - 2018-02-18 20:06:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 20:07:15 --> Config Class Initialized
INFO - 2018-02-18 20:07:15 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:07:15 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:07:15 --> Utf8 Class Initialized
INFO - 2018-02-18 20:07:15 --> URI Class Initialized
INFO - 2018-02-18 20:07:15 --> Router Class Initialized
INFO - 2018-02-18 20:07:15 --> Output Class Initialized
INFO - 2018-02-18 20:07:15 --> Security Class Initialized
DEBUG - 2018-02-18 20:07:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:07:15 --> Input Class Initialized
INFO - 2018-02-18 20:07:15 --> Language Class Initialized
INFO - 2018-02-18 20:07:15 --> Loader Class Initialized
INFO - 2018-02-18 20:07:15 --> Helper loaded: url_helper
INFO - 2018-02-18 20:07:15 --> Helper loaded: form_helper
INFO - 2018-02-18 20:07:15 --> Database Driver Class Initialized
DEBUG - 2018-02-18 20:07:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 20:07:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 20:07:15 --> Form Validation Class Initialized
INFO - 2018-02-18 20:07:15 --> Model Class Initialized
INFO - 2018-02-18 20:07:15 --> Controller Class Initialized
INFO - 2018-02-18 20:07:15 --> Model Class Initialized
INFO - 2018-02-18 20:07:15 --> Model Class Initialized
INFO - 2018-02-18 20:07:15 --> Model Class Initialized
INFO - 2018-02-18 20:07:15 --> Model Class Initialized
INFO - 2018-02-18 20:07:15 --> Model Class Initialized
DEBUG - 2018-02-18 20:07:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 20:07:15 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 20:07:15 --> Final output sent to browser
DEBUG - 2018-02-18 20:07:15 --> Total execution time: 0.0638
INFO - 2018-02-18 20:07:16 --> Config Class Initialized
INFO - 2018-02-18 20:07:16 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:07:16 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:07:16 --> Utf8 Class Initialized
INFO - 2018-02-18 20:07:16 --> URI Class Initialized
INFO - 2018-02-18 20:07:16 --> Router Class Initialized
INFO - 2018-02-18 20:07:16 --> Output Class Initialized
INFO - 2018-02-18 20:07:16 --> Security Class Initialized
DEBUG - 2018-02-18 20:07:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:07:16 --> Input Class Initialized
INFO - 2018-02-18 20:07:16 --> Language Class Initialized
INFO - 2018-02-18 20:07:16 --> Loader Class Initialized
INFO - 2018-02-18 20:07:16 --> Helper loaded: url_helper
INFO - 2018-02-18 20:07:16 --> Helper loaded: form_helper
INFO - 2018-02-18 20:07:16 --> Database Driver Class Initialized
DEBUG - 2018-02-18 20:07:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 20:07:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 20:07:16 --> Form Validation Class Initialized
INFO - 2018-02-18 20:07:16 --> Model Class Initialized
INFO - 2018-02-18 20:07:16 --> Controller Class Initialized
INFO - 2018-02-18 20:07:16 --> Model Class Initialized
INFO - 2018-02-18 20:07:16 --> Model Class Initialized
INFO - 2018-02-18 20:07:16 --> Model Class Initialized
INFO - 2018-02-18 20:07:16 --> Model Class Initialized
INFO - 2018-02-18 20:07:16 --> Model Class Initialized
DEBUG - 2018-02-18 20:07:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 20:07:21 --> Config Class Initialized
INFO - 2018-02-18 20:07:21 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:07:21 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:07:21 --> Utf8 Class Initialized
INFO - 2018-02-18 20:07:21 --> URI Class Initialized
INFO - 2018-02-18 20:07:21 --> Router Class Initialized
INFO - 2018-02-18 20:07:21 --> Output Class Initialized
INFO - 2018-02-18 20:07:21 --> Security Class Initialized
DEBUG - 2018-02-18 20:07:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:07:21 --> Input Class Initialized
INFO - 2018-02-18 20:07:21 --> Language Class Initialized
INFO - 2018-02-18 20:07:21 --> Loader Class Initialized
INFO - 2018-02-18 20:07:21 --> Helper loaded: url_helper
INFO - 2018-02-18 20:07:21 --> Helper loaded: form_helper
INFO - 2018-02-18 20:07:21 --> Database Driver Class Initialized
DEBUG - 2018-02-18 20:07:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 20:07:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 20:07:21 --> Form Validation Class Initialized
INFO - 2018-02-18 20:07:21 --> Model Class Initialized
INFO - 2018-02-18 20:07:21 --> Controller Class Initialized
INFO - 2018-02-18 20:07:21 --> Model Class Initialized
INFO - 2018-02-18 20:07:21 --> Model Class Initialized
INFO - 2018-02-18 20:07:21 --> Model Class Initialized
INFO - 2018-02-18 20:07:21 --> Model Class Initialized
INFO - 2018-02-18 20:07:21 --> Model Class Initialized
DEBUG - 2018-02-18 20:07:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 20:07:21 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 20:07:21 --> Final output sent to browser
DEBUG - 2018-02-18 20:07:21 --> Total execution time: 0.0729
INFO - 2018-02-18 20:07:21 --> Config Class Initialized
INFO - 2018-02-18 20:07:21 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:07:21 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:07:21 --> Utf8 Class Initialized
INFO - 2018-02-18 20:07:21 --> URI Class Initialized
INFO - 2018-02-18 20:07:21 --> Router Class Initialized
INFO - 2018-02-18 20:07:21 --> Output Class Initialized
INFO - 2018-02-18 20:07:21 --> Security Class Initialized
DEBUG - 2018-02-18 20:07:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:07:21 --> Input Class Initialized
INFO - 2018-02-18 20:07:21 --> Language Class Initialized
INFO - 2018-02-18 20:07:21 --> Loader Class Initialized
INFO - 2018-02-18 20:07:21 --> Helper loaded: url_helper
INFO - 2018-02-18 20:07:21 --> Helper loaded: form_helper
INFO - 2018-02-18 20:07:21 --> Database Driver Class Initialized
DEBUG - 2018-02-18 20:07:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 20:07:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 20:07:21 --> Form Validation Class Initialized
INFO - 2018-02-18 20:07:21 --> Model Class Initialized
INFO - 2018-02-18 20:07:21 --> Controller Class Initialized
INFO - 2018-02-18 20:07:21 --> Model Class Initialized
INFO - 2018-02-18 20:07:21 --> Model Class Initialized
INFO - 2018-02-18 20:07:21 --> Model Class Initialized
INFO - 2018-02-18 20:07:21 --> Model Class Initialized
INFO - 2018-02-18 20:07:21 --> Model Class Initialized
DEBUG - 2018-02-18 20:07:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 20:07:25 --> Config Class Initialized
INFO - 2018-02-18 20:07:25 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:07:25 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:07:25 --> Utf8 Class Initialized
INFO - 2018-02-18 20:07:25 --> URI Class Initialized
INFO - 2018-02-18 20:07:25 --> Router Class Initialized
INFO - 2018-02-18 20:07:25 --> Output Class Initialized
INFO - 2018-02-18 20:07:25 --> Security Class Initialized
DEBUG - 2018-02-18 20:07:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:07:25 --> Input Class Initialized
INFO - 2018-02-18 20:07:25 --> Language Class Initialized
INFO - 2018-02-18 20:07:25 --> Loader Class Initialized
INFO - 2018-02-18 20:07:25 --> Helper loaded: url_helper
INFO - 2018-02-18 20:07:25 --> Helper loaded: form_helper
INFO - 2018-02-18 20:07:25 --> Database Driver Class Initialized
DEBUG - 2018-02-18 20:07:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 20:07:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 20:07:25 --> Form Validation Class Initialized
INFO - 2018-02-18 20:07:25 --> Model Class Initialized
INFO - 2018-02-18 20:07:25 --> Controller Class Initialized
INFO - 2018-02-18 20:07:25 --> Model Class Initialized
INFO - 2018-02-18 20:07:25 --> Model Class Initialized
INFO - 2018-02-18 20:07:25 --> Model Class Initialized
INFO - 2018-02-18 20:07:25 --> Model Class Initialized
INFO - 2018-02-18 20:07:25 --> Model Class Initialized
DEBUG - 2018-02-18 20:07:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 20:07:25 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 20:07:25 --> Final output sent to browser
DEBUG - 2018-02-18 20:07:25 --> Total execution time: 0.0571
INFO - 2018-02-18 20:07:26 --> Config Class Initialized
INFO - 2018-02-18 20:07:26 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:07:26 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:07:26 --> Utf8 Class Initialized
INFO - 2018-02-18 20:07:26 --> URI Class Initialized
INFO - 2018-02-18 20:07:26 --> Router Class Initialized
INFO - 2018-02-18 20:07:26 --> Output Class Initialized
INFO - 2018-02-18 20:07:26 --> Security Class Initialized
DEBUG - 2018-02-18 20:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:07:26 --> Input Class Initialized
INFO - 2018-02-18 20:07:26 --> Language Class Initialized
INFO - 2018-02-18 20:07:26 --> Loader Class Initialized
INFO - 2018-02-18 20:07:26 --> Helper loaded: url_helper
INFO - 2018-02-18 20:07:26 --> Helper loaded: form_helper
INFO - 2018-02-18 20:07:26 --> Database Driver Class Initialized
DEBUG - 2018-02-18 20:07:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 20:07:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 20:07:26 --> Form Validation Class Initialized
INFO - 2018-02-18 20:07:26 --> Model Class Initialized
INFO - 2018-02-18 20:07:26 --> Controller Class Initialized
INFO - 2018-02-18 20:07:26 --> Model Class Initialized
INFO - 2018-02-18 20:07:26 --> Model Class Initialized
INFO - 2018-02-18 20:07:26 --> Model Class Initialized
INFO - 2018-02-18 20:07:26 --> Model Class Initialized
INFO - 2018-02-18 20:07:26 --> Model Class Initialized
DEBUG - 2018-02-18 20:07:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 20:07:29 --> Config Class Initialized
INFO - 2018-02-18 20:07:29 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:07:29 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:07:29 --> Utf8 Class Initialized
INFO - 2018-02-18 20:07:29 --> URI Class Initialized
INFO - 2018-02-18 20:07:29 --> Router Class Initialized
INFO - 2018-02-18 20:07:29 --> Output Class Initialized
INFO - 2018-02-18 20:07:29 --> Security Class Initialized
DEBUG - 2018-02-18 20:07:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:07:29 --> Input Class Initialized
INFO - 2018-02-18 20:07:29 --> Language Class Initialized
INFO - 2018-02-18 20:07:29 --> Loader Class Initialized
INFO - 2018-02-18 20:07:29 --> Helper loaded: url_helper
INFO - 2018-02-18 20:07:29 --> Helper loaded: form_helper
INFO - 2018-02-18 20:07:29 --> Database Driver Class Initialized
DEBUG - 2018-02-18 20:07:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 20:07:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 20:07:29 --> Form Validation Class Initialized
INFO - 2018-02-18 20:07:29 --> Model Class Initialized
INFO - 2018-02-18 20:07:29 --> Controller Class Initialized
INFO - 2018-02-18 20:07:29 --> Model Class Initialized
INFO - 2018-02-18 20:07:29 --> Model Class Initialized
INFO - 2018-02-18 20:07:29 --> Model Class Initialized
INFO - 2018-02-18 20:07:29 --> Model Class Initialized
INFO - 2018-02-18 20:07:29 --> Model Class Initialized
DEBUG - 2018-02-18 20:07:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 20:07:29 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 20:07:29 --> Final output sent to browser
DEBUG - 2018-02-18 20:07:29 --> Total execution time: 0.0574
INFO - 2018-02-18 20:07:29 --> Config Class Initialized
INFO - 2018-02-18 20:07:29 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:07:29 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:07:29 --> Utf8 Class Initialized
INFO - 2018-02-18 20:07:29 --> URI Class Initialized
INFO - 2018-02-18 20:07:29 --> Router Class Initialized
INFO - 2018-02-18 20:07:29 --> Output Class Initialized
INFO - 2018-02-18 20:07:29 --> Security Class Initialized
DEBUG - 2018-02-18 20:07:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:07:29 --> Input Class Initialized
INFO - 2018-02-18 20:07:29 --> Language Class Initialized
INFO - 2018-02-18 20:07:29 --> Loader Class Initialized
INFO - 2018-02-18 20:07:29 --> Helper loaded: url_helper
INFO - 2018-02-18 20:07:29 --> Helper loaded: form_helper
INFO - 2018-02-18 20:07:29 --> Database Driver Class Initialized
DEBUG - 2018-02-18 20:07:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 20:07:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 20:07:29 --> Form Validation Class Initialized
INFO - 2018-02-18 20:07:29 --> Model Class Initialized
INFO - 2018-02-18 20:07:29 --> Controller Class Initialized
INFO - 2018-02-18 20:07:29 --> Model Class Initialized
INFO - 2018-02-18 20:07:29 --> Model Class Initialized
INFO - 2018-02-18 20:07:29 --> Model Class Initialized
INFO - 2018-02-18 20:07:29 --> Model Class Initialized
INFO - 2018-02-18 20:07:29 --> Model Class Initialized
DEBUG - 2018-02-18 20:07:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 20:07:40 --> Config Class Initialized
INFO - 2018-02-18 20:07:40 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:07:40 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:07:40 --> Utf8 Class Initialized
INFO - 2018-02-18 20:07:40 --> URI Class Initialized
INFO - 2018-02-18 20:07:40 --> Router Class Initialized
INFO - 2018-02-18 20:07:40 --> Output Class Initialized
INFO - 2018-02-18 20:07:40 --> Security Class Initialized
DEBUG - 2018-02-18 20:07:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:07:40 --> Input Class Initialized
INFO - 2018-02-18 20:07:40 --> Language Class Initialized
INFO - 2018-02-18 20:07:40 --> Loader Class Initialized
INFO - 2018-02-18 20:07:40 --> Helper loaded: url_helper
INFO - 2018-02-18 20:07:40 --> Helper loaded: form_helper
INFO - 2018-02-18 20:07:40 --> Database Driver Class Initialized
DEBUG - 2018-02-18 20:07:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 20:07:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 20:07:40 --> Form Validation Class Initialized
INFO - 2018-02-18 20:07:40 --> Model Class Initialized
INFO - 2018-02-18 20:07:40 --> Controller Class Initialized
INFO - 2018-02-18 20:07:40 --> Model Class Initialized
INFO - 2018-02-18 20:07:40 --> Model Class Initialized
INFO - 2018-02-18 20:07:40 --> Model Class Initialized
INFO - 2018-02-18 20:07:40 --> Model Class Initialized
INFO - 2018-02-18 20:07:40 --> Model Class Initialized
DEBUG - 2018-02-18 20:07:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 20:07:40 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 20:07:40 --> Final output sent to browser
DEBUG - 2018-02-18 20:07:40 --> Total execution time: 0.0533
INFO - 2018-02-18 20:07:40 --> Config Class Initialized
INFO - 2018-02-18 20:07:40 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:07:40 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:07:40 --> Utf8 Class Initialized
INFO - 2018-02-18 20:07:40 --> URI Class Initialized
INFO - 2018-02-18 20:07:40 --> Router Class Initialized
INFO - 2018-02-18 20:07:40 --> Output Class Initialized
INFO - 2018-02-18 20:07:40 --> Security Class Initialized
DEBUG - 2018-02-18 20:07:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:07:40 --> Input Class Initialized
INFO - 2018-02-18 20:07:40 --> Language Class Initialized
INFO - 2018-02-18 20:07:40 --> Loader Class Initialized
INFO - 2018-02-18 20:07:40 --> Helper loaded: url_helper
INFO - 2018-02-18 20:07:40 --> Helper loaded: form_helper
INFO - 2018-02-18 20:07:40 --> Database Driver Class Initialized
DEBUG - 2018-02-18 20:07:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 20:07:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 20:07:40 --> Form Validation Class Initialized
INFO - 2018-02-18 20:07:40 --> Model Class Initialized
INFO - 2018-02-18 20:07:40 --> Controller Class Initialized
INFO - 2018-02-18 20:07:40 --> Model Class Initialized
INFO - 2018-02-18 20:07:40 --> Model Class Initialized
INFO - 2018-02-18 20:07:40 --> Model Class Initialized
INFO - 2018-02-18 20:07:40 --> Model Class Initialized
INFO - 2018-02-18 20:07:40 --> Model Class Initialized
DEBUG - 2018-02-18 20:07:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 20:07:43 --> Config Class Initialized
INFO - 2018-02-18 20:07:43 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:07:43 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:07:43 --> Utf8 Class Initialized
INFO - 2018-02-18 20:07:43 --> URI Class Initialized
INFO - 2018-02-18 20:07:43 --> Router Class Initialized
INFO - 2018-02-18 20:07:43 --> Output Class Initialized
INFO - 2018-02-18 20:07:43 --> Security Class Initialized
DEBUG - 2018-02-18 20:07:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:07:43 --> Input Class Initialized
INFO - 2018-02-18 20:07:43 --> Language Class Initialized
INFO - 2018-02-18 20:07:43 --> Loader Class Initialized
INFO - 2018-02-18 20:07:43 --> Helper loaded: url_helper
INFO - 2018-02-18 20:07:43 --> Helper loaded: form_helper
INFO - 2018-02-18 20:07:43 --> Database Driver Class Initialized
DEBUG - 2018-02-18 20:07:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 20:07:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 20:07:43 --> Form Validation Class Initialized
INFO - 2018-02-18 20:07:43 --> Model Class Initialized
INFO - 2018-02-18 20:07:43 --> Controller Class Initialized
INFO - 2018-02-18 20:07:43 --> Model Class Initialized
INFO - 2018-02-18 20:07:43 --> Model Class Initialized
INFO - 2018-02-18 20:07:43 --> Model Class Initialized
INFO - 2018-02-18 20:07:43 --> Model Class Initialized
INFO - 2018-02-18 20:07:43 --> Model Class Initialized
DEBUG - 2018-02-18 20:07:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 20:07:43 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 20:07:43 --> Final output sent to browser
DEBUG - 2018-02-18 20:07:43 --> Total execution time: 0.0801
INFO - 2018-02-18 20:07:43 --> Config Class Initialized
INFO - 2018-02-18 20:07:43 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:07:43 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:07:43 --> Utf8 Class Initialized
INFO - 2018-02-18 20:07:43 --> URI Class Initialized
INFO - 2018-02-18 20:07:43 --> Router Class Initialized
INFO - 2018-02-18 20:07:43 --> Output Class Initialized
INFO - 2018-02-18 20:07:43 --> Security Class Initialized
DEBUG - 2018-02-18 20:07:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:07:43 --> Input Class Initialized
INFO - 2018-02-18 20:07:43 --> Language Class Initialized
INFO - 2018-02-18 20:07:43 --> Loader Class Initialized
INFO - 2018-02-18 20:07:43 --> Helper loaded: url_helper
INFO - 2018-02-18 20:07:43 --> Helper loaded: form_helper
INFO - 2018-02-18 20:07:43 --> Database Driver Class Initialized
DEBUG - 2018-02-18 20:07:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 20:07:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 20:07:43 --> Form Validation Class Initialized
INFO - 2018-02-18 20:07:43 --> Model Class Initialized
INFO - 2018-02-18 20:07:43 --> Controller Class Initialized
INFO - 2018-02-18 20:07:43 --> Model Class Initialized
INFO - 2018-02-18 20:07:43 --> Model Class Initialized
INFO - 2018-02-18 20:07:43 --> Model Class Initialized
INFO - 2018-02-18 20:07:43 --> Model Class Initialized
INFO - 2018-02-18 20:07:43 --> Model Class Initialized
DEBUG - 2018-02-18 20:07:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 20:07:45 --> Config Class Initialized
INFO - 2018-02-18 20:07:45 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:07:45 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:07:45 --> Utf8 Class Initialized
INFO - 2018-02-18 20:07:45 --> URI Class Initialized
INFO - 2018-02-18 20:07:45 --> Router Class Initialized
INFO - 2018-02-18 20:07:45 --> Output Class Initialized
INFO - 2018-02-18 20:07:45 --> Security Class Initialized
DEBUG - 2018-02-18 20:07:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:07:45 --> Input Class Initialized
INFO - 2018-02-18 20:07:45 --> Language Class Initialized
INFO - 2018-02-18 20:07:45 --> Loader Class Initialized
INFO - 2018-02-18 20:07:45 --> Helper loaded: url_helper
INFO - 2018-02-18 20:07:45 --> Helper loaded: form_helper
INFO - 2018-02-18 20:07:45 --> Database Driver Class Initialized
DEBUG - 2018-02-18 20:07:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 20:07:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 20:07:45 --> Form Validation Class Initialized
INFO - 2018-02-18 20:07:45 --> Model Class Initialized
INFO - 2018-02-18 20:07:45 --> Controller Class Initialized
INFO - 2018-02-18 20:07:45 --> Model Class Initialized
INFO - 2018-02-18 20:07:45 --> Model Class Initialized
INFO - 2018-02-18 20:07:45 --> Model Class Initialized
INFO - 2018-02-18 20:07:45 --> Model Class Initialized
INFO - 2018-02-18 20:07:45 --> Model Class Initialized
DEBUG - 2018-02-18 20:07:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 20:07:45 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 20:07:45 --> Final output sent to browser
DEBUG - 2018-02-18 20:07:45 --> Total execution time: 0.0508
INFO - 2018-02-18 20:07:45 --> Config Class Initialized
INFO - 2018-02-18 20:07:45 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:07:45 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:07:45 --> Utf8 Class Initialized
INFO - 2018-02-18 20:07:45 --> URI Class Initialized
INFO - 2018-02-18 20:07:45 --> Router Class Initialized
INFO - 2018-02-18 20:07:45 --> Output Class Initialized
INFO - 2018-02-18 20:07:45 --> Security Class Initialized
DEBUG - 2018-02-18 20:07:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:07:45 --> Input Class Initialized
INFO - 2018-02-18 20:07:45 --> Language Class Initialized
INFO - 2018-02-18 20:07:45 --> Loader Class Initialized
INFO - 2018-02-18 20:07:45 --> Helper loaded: url_helper
INFO - 2018-02-18 20:07:45 --> Helper loaded: form_helper
INFO - 2018-02-18 20:07:45 --> Database Driver Class Initialized
DEBUG - 2018-02-18 20:07:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 20:07:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 20:07:45 --> Form Validation Class Initialized
INFO - 2018-02-18 20:07:45 --> Model Class Initialized
INFO - 2018-02-18 20:07:45 --> Controller Class Initialized
INFO - 2018-02-18 20:07:45 --> Model Class Initialized
INFO - 2018-02-18 20:07:45 --> Model Class Initialized
INFO - 2018-02-18 20:07:45 --> Model Class Initialized
INFO - 2018-02-18 20:07:45 --> Model Class Initialized
INFO - 2018-02-18 20:07:45 --> Model Class Initialized
DEBUG - 2018-02-18 20:07:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 20:07:46 --> Config Class Initialized
INFO - 2018-02-18 20:07:46 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:07:46 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:07:46 --> Utf8 Class Initialized
INFO - 2018-02-18 20:07:46 --> URI Class Initialized
INFO - 2018-02-18 20:07:46 --> Router Class Initialized
INFO - 2018-02-18 20:07:46 --> Output Class Initialized
INFO - 2018-02-18 20:07:46 --> Security Class Initialized
DEBUG - 2018-02-18 20:07:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:07:46 --> Input Class Initialized
INFO - 2018-02-18 20:07:46 --> Language Class Initialized
INFO - 2018-02-18 20:07:46 --> Loader Class Initialized
INFO - 2018-02-18 20:07:46 --> Helper loaded: url_helper
INFO - 2018-02-18 20:07:46 --> Helper loaded: form_helper
INFO - 2018-02-18 20:07:46 --> Database Driver Class Initialized
DEBUG - 2018-02-18 20:07:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 20:07:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 20:07:46 --> Form Validation Class Initialized
INFO - 2018-02-18 20:07:46 --> Model Class Initialized
INFO - 2018-02-18 20:07:46 --> Controller Class Initialized
INFO - 2018-02-18 20:07:46 --> Model Class Initialized
INFO - 2018-02-18 20:07:46 --> Model Class Initialized
INFO - 2018-02-18 20:07:46 --> Model Class Initialized
INFO - 2018-02-18 20:07:46 --> Model Class Initialized
INFO - 2018-02-18 20:07:46 --> Model Class Initialized
DEBUG - 2018-02-18 20:07:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 20:07:46 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 20:07:46 --> Final output sent to browser
DEBUG - 2018-02-18 20:07:46 --> Total execution time: 0.0811
INFO - 2018-02-18 20:07:46 --> Config Class Initialized
INFO - 2018-02-18 20:07:46 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:07:46 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:07:46 --> Utf8 Class Initialized
INFO - 2018-02-18 20:07:46 --> URI Class Initialized
INFO - 2018-02-18 20:07:46 --> Router Class Initialized
INFO - 2018-02-18 20:07:46 --> Output Class Initialized
INFO - 2018-02-18 20:07:46 --> Security Class Initialized
DEBUG - 2018-02-18 20:07:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:07:46 --> Input Class Initialized
INFO - 2018-02-18 20:07:46 --> Language Class Initialized
INFO - 2018-02-18 20:07:46 --> Loader Class Initialized
INFO - 2018-02-18 20:07:46 --> Helper loaded: url_helper
INFO - 2018-02-18 20:07:46 --> Helper loaded: form_helper
INFO - 2018-02-18 20:07:46 --> Database Driver Class Initialized
DEBUG - 2018-02-18 20:07:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 20:07:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 20:07:46 --> Form Validation Class Initialized
INFO - 2018-02-18 20:07:46 --> Model Class Initialized
INFO - 2018-02-18 20:07:46 --> Controller Class Initialized
INFO - 2018-02-18 20:07:46 --> Model Class Initialized
INFO - 2018-02-18 20:07:46 --> Model Class Initialized
INFO - 2018-02-18 20:07:46 --> Model Class Initialized
INFO - 2018-02-18 20:07:46 --> Model Class Initialized
INFO - 2018-02-18 20:07:46 --> Model Class Initialized
DEBUG - 2018-02-18 20:07:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 20:07:53 --> Config Class Initialized
INFO - 2018-02-18 20:07:53 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:07:53 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:07:53 --> Utf8 Class Initialized
INFO - 2018-02-18 20:07:53 --> URI Class Initialized
INFO - 2018-02-18 20:07:53 --> Router Class Initialized
INFO - 2018-02-18 20:07:53 --> Output Class Initialized
INFO - 2018-02-18 20:07:53 --> Security Class Initialized
DEBUG - 2018-02-18 20:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:07:53 --> Input Class Initialized
INFO - 2018-02-18 20:07:53 --> Language Class Initialized
INFO - 2018-02-18 20:07:53 --> Loader Class Initialized
INFO - 2018-02-18 20:07:53 --> Helper loaded: url_helper
INFO - 2018-02-18 20:07:53 --> Helper loaded: form_helper
INFO - 2018-02-18 20:07:53 --> Database Driver Class Initialized
DEBUG - 2018-02-18 20:07:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 20:07:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 20:07:53 --> Form Validation Class Initialized
INFO - 2018-02-18 20:07:53 --> Model Class Initialized
INFO - 2018-02-18 20:07:53 --> Controller Class Initialized
INFO - 2018-02-18 20:07:53 --> Model Class Initialized
INFO - 2018-02-18 20:07:53 --> Model Class Initialized
INFO - 2018-02-18 20:07:53 --> Model Class Initialized
INFO - 2018-02-18 20:07:53 --> Model Class Initialized
INFO - 2018-02-18 20:07:53 --> Model Class Initialized
DEBUG - 2018-02-18 20:07:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 20:07:53 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 20:07:53 --> Final output sent to browser
DEBUG - 2018-02-18 20:07:53 --> Total execution time: 0.0572
INFO - 2018-02-18 20:07:53 --> Config Class Initialized
INFO - 2018-02-18 20:07:53 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:07:53 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:07:53 --> Utf8 Class Initialized
INFO - 2018-02-18 20:07:53 --> URI Class Initialized
INFO - 2018-02-18 20:07:53 --> Router Class Initialized
INFO - 2018-02-18 20:07:53 --> Output Class Initialized
INFO - 2018-02-18 20:07:53 --> Security Class Initialized
DEBUG - 2018-02-18 20:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:07:53 --> Input Class Initialized
INFO - 2018-02-18 20:07:53 --> Language Class Initialized
INFO - 2018-02-18 20:07:53 --> Loader Class Initialized
INFO - 2018-02-18 20:07:53 --> Helper loaded: url_helper
INFO - 2018-02-18 20:07:53 --> Helper loaded: form_helper
INFO - 2018-02-18 20:07:53 --> Database Driver Class Initialized
DEBUG - 2018-02-18 20:07:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 20:07:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 20:07:53 --> Form Validation Class Initialized
INFO - 2018-02-18 20:07:53 --> Model Class Initialized
INFO - 2018-02-18 20:07:53 --> Controller Class Initialized
INFO - 2018-02-18 20:07:53 --> Model Class Initialized
INFO - 2018-02-18 20:07:53 --> Model Class Initialized
INFO - 2018-02-18 20:07:53 --> Model Class Initialized
INFO - 2018-02-18 20:07:53 --> Model Class Initialized
INFO - 2018-02-18 20:07:53 --> Model Class Initialized
DEBUG - 2018-02-18 20:07:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 20:07:55 --> Config Class Initialized
INFO - 2018-02-18 20:07:55 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:07:55 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:07:55 --> Utf8 Class Initialized
INFO - 2018-02-18 20:07:55 --> URI Class Initialized
INFO - 2018-02-18 20:07:55 --> Router Class Initialized
INFO - 2018-02-18 20:07:55 --> Output Class Initialized
INFO - 2018-02-18 20:07:55 --> Security Class Initialized
DEBUG - 2018-02-18 20:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:07:55 --> Input Class Initialized
INFO - 2018-02-18 20:07:55 --> Language Class Initialized
INFO - 2018-02-18 20:07:55 --> Loader Class Initialized
INFO - 2018-02-18 20:07:55 --> Helper loaded: url_helper
INFO - 2018-02-18 20:07:55 --> Helper loaded: form_helper
INFO - 2018-02-18 20:07:55 --> Database Driver Class Initialized
DEBUG - 2018-02-18 20:07:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 20:07:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 20:07:55 --> Form Validation Class Initialized
INFO - 2018-02-18 20:07:55 --> Model Class Initialized
INFO - 2018-02-18 20:07:55 --> Controller Class Initialized
INFO - 2018-02-18 20:07:55 --> Model Class Initialized
INFO - 2018-02-18 20:07:55 --> Model Class Initialized
INFO - 2018-02-18 20:07:55 --> Model Class Initialized
INFO - 2018-02-18 20:07:55 --> Model Class Initialized
INFO - 2018-02-18 20:07:55 --> Model Class Initialized
DEBUG - 2018-02-18 20:07:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 20:07:55 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 20:07:55 --> Final output sent to browser
DEBUG - 2018-02-18 20:07:55 --> Total execution time: 0.0632
INFO - 2018-02-18 20:07:56 --> Config Class Initialized
INFO - 2018-02-18 20:07:56 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:07:56 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:07:56 --> Utf8 Class Initialized
INFO - 2018-02-18 20:07:56 --> URI Class Initialized
INFO - 2018-02-18 20:07:56 --> Router Class Initialized
INFO - 2018-02-18 20:07:56 --> Output Class Initialized
INFO - 2018-02-18 20:07:56 --> Security Class Initialized
DEBUG - 2018-02-18 20:07:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:07:56 --> Input Class Initialized
INFO - 2018-02-18 20:07:56 --> Language Class Initialized
INFO - 2018-02-18 20:07:56 --> Loader Class Initialized
INFO - 2018-02-18 20:07:56 --> Helper loaded: url_helper
INFO - 2018-02-18 20:07:56 --> Helper loaded: form_helper
INFO - 2018-02-18 20:07:56 --> Database Driver Class Initialized
DEBUG - 2018-02-18 20:07:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 20:07:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 20:07:56 --> Form Validation Class Initialized
INFO - 2018-02-18 20:07:56 --> Model Class Initialized
INFO - 2018-02-18 20:07:56 --> Controller Class Initialized
INFO - 2018-02-18 20:07:56 --> Model Class Initialized
INFO - 2018-02-18 20:07:56 --> Model Class Initialized
INFO - 2018-02-18 20:07:56 --> Model Class Initialized
INFO - 2018-02-18 20:07:56 --> Model Class Initialized
INFO - 2018-02-18 20:07:56 --> Model Class Initialized
DEBUG - 2018-02-18 20:07:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 20:08:00 --> Config Class Initialized
INFO - 2018-02-18 20:08:00 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:08:00 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:08:00 --> Utf8 Class Initialized
INFO - 2018-02-18 20:08:00 --> URI Class Initialized
INFO - 2018-02-18 20:08:00 --> Router Class Initialized
INFO - 2018-02-18 20:08:00 --> Output Class Initialized
INFO - 2018-02-18 20:08:00 --> Security Class Initialized
DEBUG - 2018-02-18 20:08:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:08:00 --> Input Class Initialized
INFO - 2018-02-18 20:08:00 --> Language Class Initialized
INFO - 2018-02-18 20:08:00 --> Loader Class Initialized
INFO - 2018-02-18 20:08:00 --> Helper loaded: url_helper
INFO - 2018-02-18 20:08:00 --> Helper loaded: form_helper
INFO - 2018-02-18 20:08:00 --> Database Driver Class Initialized
DEBUG - 2018-02-18 20:08:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 20:08:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 20:08:00 --> Form Validation Class Initialized
INFO - 2018-02-18 20:08:00 --> Model Class Initialized
INFO - 2018-02-18 20:08:00 --> Controller Class Initialized
INFO - 2018-02-18 20:08:00 --> Model Class Initialized
INFO - 2018-02-18 20:08:00 --> Model Class Initialized
INFO - 2018-02-18 20:08:00 --> Model Class Initialized
INFO - 2018-02-18 20:08:00 --> Model Class Initialized
INFO - 2018-02-18 20:08:00 --> Model Class Initialized
DEBUG - 2018-02-18 20:08:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 20:08:10 --> Config Class Initialized
INFO - 2018-02-18 20:08:10 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:08:10 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:08:10 --> Utf8 Class Initialized
INFO - 2018-02-18 20:08:10 --> URI Class Initialized
INFO - 2018-02-18 20:08:10 --> Router Class Initialized
INFO - 2018-02-18 20:08:10 --> Output Class Initialized
INFO - 2018-02-18 20:08:10 --> Security Class Initialized
DEBUG - 2018-02-18 20:08:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:08:10 --> Input Class Initialized
INFO - 2018-02-18 20:08:10 --> Language Class Initialized
INFO - 2018-02-18 20:08:10 --> Loader Class Initialized
INFO - 2018-02-18 20:08:10 --> Helper loaded: url_helper
INFO - 2018-02-18 20:08:10 --> Helper loaded: form_helper
INFO - 2018-02-18 20:08:10 --> Database Driver Class Initialized
DEBUG - 2018-02-18 20:08:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 20:08:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 20:08:10 --> Form Validation Class Initialized
INFO - 2018-02-18 20:08:10 --> Model Class Initialized
INFO - 2018-02-18 20:08:10 --> Controller Class Initialized
INFO - 2018-02-18 20:08:10 --> Model Class Initialized
INFO - 2018-02-18 20:08:10 --> Model Class Initialized
INFO - 2018-02-18 20:08:10 --> Model Class Initialized
INFO - 2018-02-18 20:08:10 --> Model Class Initialized
INFO - 2018-02-18 20:08:10 --> Model Class Initialized
DEBUG - 2018-02-18 20:08:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 20:08:10 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 20:08:10 --> Final output sent to browser
DEBUG - 2018-02-18 20:08:10 --> Total execution time: 0.0663
INFO - 2018-02-18 20:08:11 --> Config Class Initialized
INFO - 2018-02-18 20:08:11 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:08:11 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:08:11 --> Utf8 Class Initialized
INFO - 2018-02-18 20:08:11 --> URI Class Initialized
INFO - 2018-02-18 20:08:11 --> Router Class Initialized
INFO - 2018-02-18 20:08:11 --> Output Class Initialized
INFO - 2018-02-18 20:08:11 --> Security Class Initialized
DEBUG - 2018-02-18 20:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:08:11 --> Input Class Initialized
INFO - 2018-02-18 20:08:11 --> Language Class Initialized
INFO - 2018-02-18 20:08:11 --> Loader Class Initialized
INFO - 2018-02-18 20:08:11 --> Helper loaded: url_helper
INFO - 2018-02-18 20:08:11 --> Helper loaded: form_helper
INFO - 2018-02-18 20:08:11 --> Database Driver Class Initialized
DEBUG - 2018-02-18 20:08:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 20:08:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 20:08:11 --> Form Validation Class Initialized
INFO - 2018-02-18 20:08:11 --> Model Class Initialized
INFO - 2018-02-18 20:08:11 --> Controller Class Initialized
INFO - 2018-02-18 20:08:11 --> Model Class Initialized
INFO - 2018-02-18 20:08:11 --> Model Class Initialized
INFO - 2018-02-18 20:08:11 --> Model Class Initialized
INFO - 2018-02-18 20:08:11 --> Model Class Initialized
INFO - 2018-02-18 20:08:11 --> Model Class Initialized
DEBUG - 2018-02-18 20:08:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 20:11:37 --> Config Class Initialized
INFO - 2018-02-18 20:11:37 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:11:37 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:11:37 --> Utf8 Class Initialized
INFO - 2018-02-18 20:11:37 --> URI Class Initialized
INFO - 2018-02-18 20:11:37 --> Router Class Initialized
INFO - 2018-02-18 20:11:37 --> Output Class Initialized
INFO - 2018-02-18 20:11:37 --> Security Class Initialized
DEBUG - 2018-02-18 20:11:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:11:37 --> Input Class Initialized
INFO - 2018-02-18 20:11:37 --> Language Class Initialized
INFO - 2018-02-18 20:11:37 --> Loader Class Initialized
INFO - 2018-02-18 20:11:37 --> Helper loaded: url_helper
INFO - 2018-02-18 20:11:37 --> Helper loaded: form_helper
INFO - 2018-02-18 20:11:37 --> Database Driver Class Initialized
DEBUG - 2018-02-18 20:11:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 20:11:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 20:11:37 --> Form Validation Class Initialized
INFO - 2018-02-18 20:11:37 --> Model Class Initialized
INFO - 2018-02-18 20:11:37 --> Controller Class Initialized
INFO - 2018-02-18 20:11:37 --> Model Class Initialized
INFO - 2018-02-18 20:11:37 --> Model Class Initialized
INFO - 2018-02-18 20:11:37 --> Model Class Initialized
INFO - 2018-02-18 20:11:37 --> Model Class Initialized
INFO - 2018-02-18 20:11:37 --> Model Class Initialized
DEBUG - 2018-02-18 20:11:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 20:11:37 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 20:11:37 --> Final output sent to browser
DEBUG - 2018-02-18 20:11:37 --> Total execution time: 0.0600
INFO - 2018-02-18 20:11:37 --> Config Class Initialized
INFO - 2018-02-18 20:11:37 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:11:37 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:11:37 --> Utf8 Class Initialized
INFO - 2018-02-18 20:11:37 --> URI Class Initialized
INFO - 2018-02-18 20:11:37 --> Router Class Initialized
INFO - 2018-02-18 20:11:37 --> Output Class Initialized
INFO - 2018-02-18 20:11:37 --> Security Class Initialized
DEBUG - 2018-02-18 20:11:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:11:37 --> Input Class Initialized
INFO - 2018-02-18 20:11:37 --> Language Class Initialized
INFO - 2018-02-18 20:11:37 --> Loader Class Initialized
INFO - 2018-02-18 20:11:37 --> Helper loaded: url_helper
INFO - 2018-02-18 20:11:37 --> Helper loaded: form_helper
INFO - 2018-02-18 20:11:37 --> Database Driver Class Initialized
DEBUG - 2018-02-18 20:11:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 20:11:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 20:11:37 --> Form Validation Class Initialized
INFO - 2018-02-18 20:11:37 --> Model Class Initialized
INFO - 2018-02-18 20:11:37 --> Controller Class Initialized
INFO - 2018-02-18 20:11:37 --> Model Class Initialized
INFO - 2018-02-18 20:11:37 --> Model Class Initialized
INFO - 2018-02-18 20:11:37 --> Model Class Initialized
INFO - 2018-02-18 20:11:37 --> Model Class Initialized
INFO - 2018-02-18 20:11:37 --> Model Class Initialized
DEBUG - 2018-02-18 20:11:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 20:11:40 --> Config Class Initialized
INFO - 2018-02-18 20:11:40 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:11:40 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:11:40 --> Utf8 Class Initialized
INFO - 2018-02-18 20:11:40 --> URI Class Initialized
INFO - 2018-02-18 20:11:40 --> Router Class Initialized
INFO - 2018-02-18 20:11:40 --> Output Class Initialized
INFO - 2018-02-18 20:11:40 --> Security Class Initialized
DEBUG - 2018-02-18 20:11:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:11:40 --> Input Class Initialized
INFO - 2018-02-18 20:11:40 --> Language Class Initialized
INFO - 2018-02-18 20:11:40 --> Loader Class Initialized
INFO - 2018-02-18 20:11:40 --> Helper loaded: url_helper
INFO - 2018-02-18 20:11:40 --> Helper loaded: form_helper
INFO - 2018-02-18 20:11:40 --> Database Driver Class Initialized
DEBUG - 2018-02-18 20:11:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 20:11:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 20:11:40 --> Form Validation Class Initialized
INFO - 2018-02-18 20:11:40 --> Model Class Initialized
INFO - 2018-02-18 20:11:40 --> Controller Class Initialized
INFO - 2018-02-18 20:11:40 --> Model Class Initialized
INFO - 2018-02-18 20:11:40 --> Model Class Initialized
INFO - 2018-02-18 20:11:40 --> Model Class Initialized
INFO - 2018-02-18 20:11:40 --> Model Class Initialized
INFO - 2018-02-18 20:11:40 --> Model Class Initialized
DEBUG - 2018-02-18 20:11:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 20:11:40 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 20:11:40 --> Final output sent to browser
DEBUG - 2018-02-18 20:11:40 --> Total execution time: 0.0496
INFO - 2018-02-18 20:11:40 --> Config Class Initialized
INFO - 2018-02-18 20:11:40 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:11:40 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:11:40 --> Utf8 Class Initialized
INFO - 2018-02-18 20:11:40 --> URI Class Initialized
INFO - 2018-02-18 20:11:40 --> Router Class Initialized
INFO - 2018-02-18 20:11:40 --> Output Class Initialized
INFO - 2018-02-18 20:11:40 --> Security Class Initialized
DEBUG - 2018-02-18 20:11:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:11:40 --> Input Class Initialized
INFO - 2018-02-18 20:11:40 --> Language Class Initialized
INFO - 2018-02-18 20:11:40 --> Loader Class Initialized
INFO - 2018-02-18 20:11:40 --> Helper loaded: url_helper
INFO - 2018-02-18 20:11:40 --> Helper loaded: form_helper
INFO - 2018-02-18 20:11:40 --> Database Driver Class Initialized
DEBUG - 2018-02-18 20:11:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 20:11:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 20:11:40 --> Form Validation Class Initialized
INFO - 2018-02-18 20:11:40 --> Model Class Initialized
INFO - 2018-02-18 20:11:40 --> Controller Class Initialized
INFO - 2018-02-18 20:11:40 --> Model Class Initialized
INFO - 2018-02-18 20:11:40 --> Model Class Initialized
INFO - 2018-02-18 20:11:40 --> Model Class Initialized
INFO - 2018-02-18 20:11:40 --> Model Class Initialized
INFO - 2018-02-18 20:11:40 --> Model Class Initialized
DEBUG - 2018-02-18 20:11:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 20:11:51 --> Config Class Initialized
INFO - 2018-02-18 20:11:51 --> Hooks Class Initialized
INFO - 2018-02-18 20:11:51 --> Config Class Initialized
INFO - 2018-02-18 20:11:51 --> Hooks Class Initialized
INFO - 2018-02-18 20:11:51 --> Config Class Initialized
INFO - 2018-02-18 20:11:51 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:11:51 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:11:51 --> Utf8 Class Initialized
DEBUG - 2018-02-18 20:11:51 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:11:51 --> Config Class Initialized
INFO - 2018-02-18 20:11:51 --> Utf8 Class Initialized
INFO - 2018-02-18 20:11:51 --> Hooks Class Initialized
INFO - 2018-02-18 20:11:51 --> URI Class Initialized
INFO - 2018-02-18 20:11:51 --> URI Class Initialized
DEBUG - 2018-02-18 20:11:51 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:11:51 --> Utf8 Class Initialized
INFO - 2018-02-18 20:11:51 --> Router Class Initialized
INFO - 2018-02-18 20:11:51 --> Router Class Initialized
INFO - 2018-02-18 20:11:51 --> URI Class Initialized
INFO - 2018-02-18 20:11:51 --> Output Class Initialized
INFO - 2018-02-18 20:11:51 --> Router Class Initialized
DEBUG - 2018-02-18 20:11:51 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:11:51 --> Output Class Initialized
INFO - 2018-02-18 20:11:51 --> Utf8 Class Initialized
INFO - 2018-02-18 20:11:51 --> Security Class Initialized
INFO - 2018-02-18 20:11:51 --> URI Class Initialized
INFO - 2018-02-18 20:11:51 --> Security Class Initialized
INFO - 2018-02-18 20:11:51 --> Output Class Initialized
DEBUG - 2018-02-18 20:11:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:11:51 --> Input Class Initialized
INFO - 2018-02-18 20:11:51 --> Language Class Initialized
DEBUG - 2018-02-18 20:11:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:11:51 --> Security Class Initialized
INFO - 2018-02-18 20:11:51 --> Router Class Initialized
INFO - 2018-02-18 20:11:51 --> Input Class Initialized
INFO - 2018-02-18 20:11:51 --> Language Class Initialized
ERROR - 2018-02-18 20:11:51 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-02-18 20:11:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:11:51 --> Input Class Initialized
INFO - 2018-02-18 20:11:51 --> Output Class Initialized
INFO - 2018-02-18 20:11:51 --> Language Class Initialized
ERROR - 2018-02-18 20:11:51 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-18 20:11:51 --> Security Class Initialized
ERROR - 2018-02-18 20:11:51 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-02-18 20:11:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:11:51 --> Input Class Initialized
INFO - 2018-02-18 20:11:51 --> Language Class Initialized
ERROR - 2018-02-18 20:11:51 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-18 20:11:51 --> Config Class Initialized
INFO - 2018-02-18 20:11:51 --> Hooks Class Initialized
INFO - 2018-02-18 20:11:51 --> Config Class Initialized
INFO - 2018-02-18 20:11:51 --> Hooks Class Initialized
INFO - 2018-02-18 20:11:51 --> Config Class Initialized
INFO - 2018-02-18 20:11:51 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:11:51 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:11:51 --> Utf8 Class Initialized
DEBUG - 2018-02-18 20:11:51 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:11:51 --> Utf8 Class Initialized
INFO - 2018-02-18 20:11:51 --> URI Class Initialized
DEBUG - 2018-02-18 20:11:51 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:11:51 --> Utf8 Class Initialized
INFO - 2018-02-18 20:11:51 --> URI Class Initialized
INFO - 2018-02-18 20:11:51 --> URI Class Initialized
INFO - 2018-02-18 20:11:51 --> Router Class Initialized
INFO - 2018-02-18 20:11:51 --> Router Class Initialized
INFO - 2018-02-18 20:11:51 --> Router Class Initialized
INFO - 2018-02-18 20:11:51 --> Output Class Initialized
INFO - 2018-02-18 20:11:51 --> Output Class Initialized
INFO - 2018-02-18 20:11:51 --> Output Class Initialized
INFO - 2018-02-18 20:11:51 --> Security Class Initialized
INFO - 2018-02-18 20:11:51 --> Security Class Initialized
INFO - 2018-02-18 20:11:51 --> Security Class Initialized
DEBUG - 2018-02-18 20:11:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-18 20:11:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:11:51 --> Input Class Initialized
INFO - 2018-02-18 20:11:51 --> Input Class Initialized
DEBUG - 2018-02-18 20:11:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:11:51 --> Input Class Initialized
INFO - 2018-02-18 20:11:51 --> Language Class Initialized
INFO - 2018-02-18 20:11:51 --> Language Class Initialized
INFO - 2018-02-18 20:11:51 --> Language Class Initialized
ERROR - 2018-02-18 20:11:51 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-18 20:11:51 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-18 20:11:51 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-18 20:11:53 --> Config Class Initialized
INFO - 2018-02-18 20:11:53 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:11:53 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:11:53 --> Utf8 Class Initialized
INFO - 2018-02-18 20:11:53 --> URI Class Initialized
INFO - 2018-02-18 20:11:53 --> Router Class Initialized
INFO - 2018-02-18 20:11:53 --> Output Class Initialized
INFO - 2018-02-18 20:11:53 --> Security Class Initialized
DEBUG - 2018-02-18 20:11:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:11:53 --> Input Class Initialized
INFO - 2018-02-18 20:11:53 --> Language Class Initialized
INFO - 2018-02-18 20:11:53 --> Loader Class Initialized
INFO - 2018-02-18 20:11:53 --> Helper loaded: url_helper
INFO - 2018-02-18 20:11:53 --> Helper loaded: form_helper
INFO - 2018-02-18 20:11:53 --> Database Driver Class Initialized
DEBUG - 2018-02-18 20:11:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 20:11:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 20:11:53 --> Form Validation Class Initialized
INFO - 2018-02-18 20:11:53 --> Model Class Initialized
INFO - 2018-02-18 20:11:53 --> Controller Class Initialized
INFO - 2018-02-18 20:11:53 --> Model Class Initialized
INFO - 2018-02-18 20:11:53 --> Model Class Initialized
INFO - 2018-02-18 20:11:53 --> Model Class Initialized
INFO - 2018-02-18 20:11:53 --> Model Class Initialized
INFO - 2018-02-18 20:11:53 --> Model Class Initialized
DEBUG - 2018-02-18 20:11:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 20:11:53 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 20:11:53 --> Final output sent to browser
DEBUG - 2018-02-18 20:11:53 --> Total execution time: 0.0776
INFO - 2018-02-18 20:11:53 --> Config Class Initialized
INFO - 2018-02-18 20:11:53 --> Hooks Class Initialized
INFO - 2018-02-18 20:11:53 --> Config Class Initialized
INFO - 2018-02-18 20:11:53 --> Hooks Class Initialized
INFO - 2018-02-18 20:11:53 --> Config Class Initialized
DEBUG - 2018-02-18 20:11:53 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:11:53 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:11:53 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:11:53 --> Utf8 Class Initialized
INFO - 2018-02-18 20:11:53 --> Utf8 Class Initialized
INFO - 2018-02-18 20:11:53 --> URI Class Initialized
INFO - 2018-02-18 20:11:53 --> URI Class Initialized
DEBUG - 2018-02-18 20:11:53 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:11:53 --> Utf8 Class Initialized
INFO - 2018-02-18 20:11:53 --> Router Class Initialized
INFO - 2018-02-18 20:11:53 --> Router Class Initialized
INFO - 2018-02-18 20:11:53 --> URI Class Initialized
INFO - 2018-02-18 20:11:53 --> Output Class Initialized
INFO - 2018-02-18 20:11:53 --> Output Class Initialized
INFO - 2018-02-18 20:11:53 --> Security Class Initialized
INFO - 2018-02-18 20:11:53 --> Router Class Initialized
INFO - 2018-02-18 20:11:53 --> Security Class Initialized
DEBUG - 2018-02-18 20:11:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:11:53 --> Input Class Initialized
INFO - 2018-02-18 20:11:53 --> Output Class Initialized
DEBUG - 2018-02-18 20:11:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:11:53 --> Language Class Initialized
INFO - 2018-02-18 20:11:53 --> Input Class Initialized
INFO - 2018-02-18 20:11:53 --> Language Class Initialized
INFO - 2018-02-18 20:11:53 --> Security Class Initialized
ERROR - 2018-02-18 20:11:53 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-02-18 20:11:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-18 20:11:53 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-18 20:11:53 --> Input Class Initialized
INFO - 2018-02-18 20:11:53 --> Language Class Initialized
ERROR - 2018-02-18 20:11:53 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-18 20:11:53 --> Config Class Initialized
INFO - 2018-02-18 20:11:53 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:11:53 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:11:53 --> Utf8 Class Initialized
INFO - 2018-02-18 20:11:53 --> URI Class Initialized
INFO - 2018-02-18 20:11:53 --> Router Class Initialized
INFO - 2018-02-18 20:11:53 --> Output Class Initialized
INFO - 2018-02-18 20:11:53 --> Security Class Initialized
DEBUG - 2018-02-18 20:11:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:11:53 --> Input Class Initialized
INFO - 2018-02-18 20:11:53 --> Language Class Initialized
ERROR - 2018-02-18 20:11:53 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-18 20:11:53 --> Config Class Initialized
INFO - 2018-02-18 20:11:53 --> Hooks Class Initialized
INFO - 2018-02-18 20:11:53 --> Config Class Initialized
INFO - 2018-02-18 20:11:53 --> Hooks Class Initialized
INFO - 2018-02-18 20:11:53 --> Config Class Initialized
INFO - 2018-02-18 20:11:53 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:11:53 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:11:53 --> Utf8 Class Initialized
INFO - 2018-02-18 20:11:53 --> URI Class Initialized
DEBUG - 2018-02-18 20:11:53 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:11:53 --> Utf8 Class Initialized
DEBUG - 2018-02-18 20:11:53 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:11:53 --> Router Class Initialized
INFO - 2018-02-18 20:11:53 --> Utf8 Class Initialized
INFO - 2018-02-18 20:11:53 --> URI Class Initialized
INFO - 2018-02-18 20:11:53 --> URI Class Initialized
INFO - 2018-02-18 20:11:53 --> Router Class Initialized
INFO - 2018-02-18 20:11:53 --> Output Class Initialized
INFO - 2018-02-18 20:11:53 --> Router Class Initialized
INFO - 2018-02-18 20:11:53 --> Output Class Initialized
INFO - 2018-02-18 20:11:53 --> Security Class Initialized
INFO - 2018-02-18 20:11:53 --> Security Class Initialized
INFO - 2018-02-18 20:11:53 --> Output Class Initialized
DEBUG - 2018-02-18 20:11:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:11:53 --> Input Class Initialized
INFO - 2018-02-18 20:11:53 --> Language Class Initialized
INFO - 2018-02-18 20:11:53 --> Security Class Initialized
DEBUG - 2018-02-18 20:11:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:11:53 --> Input Class Initialized
ERROR - 2018-02-18 20:11:53 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-18 20:11:53 --> Language Class Initialized
DEBUG - 2018-02-18 20:11:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:11:53 --> Input Class Initialized
INFO - 2018-02-18 20:11:53 --> Language Class Initialized
ERROR - 2018-02-18 20:11:53 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-18 20:11:53 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-18 20:11:53 --> Config Class Initialized
INFO - 2018-02-18 20:11:53 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:11:53 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:11:53 --> Utf8 Class Initialized
INFO - 2018-02-18 20:11:53 --> URI Class Initialized
INFO - 2018-02-18 20:11:53 --> Router Class Initialized
INFO - 2018-02-18 20:11:53 --> Output Class Initialized
INFO - 2018-02-18 20:11:53 --> Security Class Initialized
DEBUG - 2018-02-18 20:11:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:11:53 --> Input Class Initialized
INFO - 2018-02-18 20:11:53 --> Language Class Initialized
INFO - 2018-02-18 20:11:53 --> Loader Class Initialized
INFO - 2018-02-18 20:11:53 --> Helper loaded: url_helper
INFO - 2018-02-18 20:11:53 --> Helper loaded: form_helper
INFO - 2018-02-18 20:11:53 --> Database Driver Class Initialized
DEBUG - 2018-02-18 20:11:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 20:11:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 20:11:53 --> Form Validation Class Initialized
INFO - 2018-02-18 20:11:53 --> Model Class Initialized
INFO - 2018-02-18 20:11:53 --> Controller Class Initialized
INFO - 2018-02-18 20:11:53 --> Model Class Initialized
INFO - 2018-02-18 20:11:53 --> Model Class Initialized
INFO - 2018-02-18 20:11:53 --> Model Class Initialized
INFO - 2018-02-18 20:11:53 --> Model Class Initialized
INFO - 2018-02-18 20:11:53 --> Model Class Initialized
DEBUG - 2018-02-18 20:11:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 20:12:02 --> Config Class Initialized
INFO - 2018-02-18 20:12:02 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:12:02 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:12:02 --> Utf8 Class Initialized
INFO - 2018-02-18 20:12:02 --> URI Class Initialized
INFO - 2018-02-18 20:12:02 --> Router Class Initialized
INFO - 2018-02-18 20:12:02 --> Output Class Initialized
INFO - 2018-02-18 20:12:02 --> Security Class Initialized
DEBUG - 2018-02-18 20:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:12:02 --> Input Class Initialized
INFO - 2018-02-18 20:12:02 --> Language Class Initialized
INFO - 2018-02-18 20:12:02 --> Loader Class Initialized
INFO - 2018-02-18 20:12:02 --> Helper loaded: url_helper
INFO - 2018-02-18 20:12:02 --> Helper loaded: form_helper
INFO - 2018-02-18 20:12:02 --> Database Driver Class Initialized
DEBUG - 2018-02-18 20:12:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 20:12:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 20:12:02 --> Form Validation Class Initialized
INFO - 2018-02-18 20:12:02 --> Model Class Initialized
INFO - 2018-02-18 20:12:02 --> Controller Class Initialized
INFO - 2018-02-18 20:12:02 --> Model Class Initialized
INFO - 2018-02-18 20:12:02 --> Model Class Initialized
INFO - 2018-02-18 20:12:02 --> Model Class Initialized
INFO - 2018-02-18 20:12:02 --> Model Class Initialized
INFO - 2018-02-18 20:12:02 --> Model Class Initialized
DEBUG - 2018-02-18 20:12:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 20:12:02 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 20:12:02 --> Final output sent to browser
DEBUG - 2018-02-18 20:12:02 --> Total execution time: 0.0633
INFO - 2018-02-18 20:12:02 --> Config Class Initialized
INFO - 2018-02-18 20:12:02 --> Hooks Class Initialized
INFO - 2018-02-18 20:12:02 --> Config Class Initialized
INFO - 2018-02-18 20:12:02 --> Hooks Class Initialized
INFO - 2018-02-18 20:12:02 --> Config Class Initialized
INFO - 2018-02-18 20:12:02 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:12:02 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:12:02 --> Utf8 Class Initialized
DEBUG - 2018-02-18 20:12:02 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:12:02 --> URI Class Initialized
INFO - 2018-02-18 20:12:02 --> Utf8 Class Initialized
DEBUG - 2018-02-18 20:12:02 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:12:02 --> Utf8 Class Initialized
INFO - 2018-02-18 20:12:02 --> URI Class Initialized
INFO - 2018-02-18 20:12:02 --> URI Class Initialized
INFO - 2018-02-18 20:12:02 --> Router Class Initialized
INFO - 2018-02-18 20:12:02 --> Router Class Initialized
INFO - 2018-02-18 20:12:02 --> Output Class Initialized
INFO - 2018-02-18 20:12:02 --> Router Class Initialized
INFO - 2018-02-18 20:12:02 --> Security Class Initialized
INFO - 2018-02-18 20:12:02 --> Output Class Initialized
INFO - 2018-02-18 20:12:02 --> Output Class Initialized
DEBUG - 2018-02-18 20:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:12:02 --> Input Class Initialized
INFO - 2018-02-18 20:12:02 --> Security Class Initialized
INFO - 2018-02-18 20:12:02 --> Security Class Initialized
INFO - 2018-02-18 20:12:02 --> Language Class Initialized
DEBUG - 2018-02-18 20:12:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-18 20:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:12:02 --> Input Class Initialized
ERROR - 2018-02-18 20:12:02 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-18 20:12:02 --> Input Class Initialized
INFO - 2018-02-18 20:12:02 --> Language Class Initialized
INFO - 2018-02-18 20:12:02 --> Language Class Initialized
ERROR - 2018-02-18 20:12:02 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-18 20:12:02 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-18 20:12:03 --> Config Class Initialized
INFO - 2018-02-18 20:12:03 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:12:03 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:12:03 --> Utf8 Class Initialized
INFO - 2018-02-18 20:12:03 --> URI Class Initialized
INFO - 2018-02-18 20:12:03 --> Router Class Initialized
INFO - 2018-02-18 20:12:03 --> Output Class Initialized
INFO - 2018-02-18 20:12:03 --> Security Class Initialized
DEBUG - 2018-02-18 20:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:12:03 --> Input Class Initialized
INFO - 2018-02-18 20:12:03 --> Language Class Initialized
ERROR - 2018-02-18 20:12:03 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-18 20:12:03 --> Config Class Initialized
INFO - 2018-02-18 20:12:03 --> Hooks Class Initialized
INFO - 2018-02-18 20:12:03 --> Config Class Initialized
INFO - 2018-02-18 20:12:03 --> Hooks Class Initialized
INFO - 2018-02-18 20:12:03 --> Config Class Initialized
INFO - 2018-02-18 20:12:03 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:12:03 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:12:03 --> Utf8 Class Initialized
DEBUG - 2018-02-18 20:12:03 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:12:03 --> Utf8 Class Initialized
DEBUG - 2018-02-18 20:12:03 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:12:03 --> Utf8 Class Initialized
INFO - 2018-02-18 20:12:03 --> URI Class Initialized
INFO - 2018-02-18 20:12:03 --> URI Class Initialized
INFO - 2018-02-18 20:12:03 --> URI Class Initialized
INFO - 2018-02-18 20:12:03 --> Router Class Initialized
INFO - 2018-02-18 20:12:03 --> Router Class Initialized
INFO - 2018-02-18 20:12:03 --> Router Class Initialized
INFO - 2018-02-18 20:12:03 --> Output Class Initialized
INFO - 2018-02-18 20:12:03 --> Output Class Initialized
INFO - 2018-02-18 20:12:03 --> Output Class Initialized
INFO - 2018-02-18 20:12:03 --> Security Class Initialized
INFO - 2018-02-18 20:12:03 --> Security Class Initialized
DEBUG - 2018-02-18 20:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:12:03 --> Security Class Initialized
INFO - 2018-02-18 20:12:03 --> Input Class Initialized
DEBUG - 2018-02-18 20:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:12:03 --> Input Class Initialized
INFO - 2018-02-18 20:12:03 --> Language Class Initialized
DEBUG - 2018-02-18 20:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:12:03 --> Language Class Initialized
INFO - 2018-02-18 20:12:03 --> Input Class Initialized
ERROR - 2018-02-18 20:12:03 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-18 20:12:03 --> Language Class Initialized
ERROR - 2018-02-18 20:12:03 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-18 20:12:03 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-18 20:12:03 --> Config Class Initialized
INFO - 2018-02-18 20:12:03 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:12:03 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:12:03 --> Utf8 Class Initialized
INFO - 2018-02-18 20:12:03 --> URI Class Initialized
INFO - 2018-02-18 20:12:03 --> Router Class Initialized
INFO - 2018-02-18 20:12:03 --> Output Class Initialized
INFO - 2018-02-18 20:12:03 --> Security Class Initialized
DEBUG - 2018-02-18 20:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:12:03 --> Input Class Initialized
INFO - 2018-02-18 20:12:03 --> Language Class Initialized
INFO - 2018-02-18 20:12:03 --> Loader Class Initialized
INFO - 2018-02-18 20:12:03 --> Helper loaded: url_helper
INFO - 2018-02-18 20:12:03 --> Helper loaded: form_helper
INFO - 2018-02-18 20:12:03 --> Database Driver Class Initialized
DEBUG - 2018-02-18 20:12:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 20:12:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 20:12:03 --> Form Validation Class Initialized
INFO - 2018-02-18 20:12:03 --> Model Class Initialized
INFO - 2018-02-18 20:12:03 --> Controller Class Initialized
INFO - 2018-02-18 20:12:03 --> Model Class Initialized
INFO - 2018-02-18 20:12:03 --> Model Class Initialized
INFO - 2018-02-18 20:12:03 --> Model Class Initialized
INFO - 2018-02-18 20:12:03 --> Model Class Initialized
INFO - 2018-02-18 20:12:03 --> Model Class Initialized
DEBUG - 2018-02-18 20:12:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 20:12:19 --> Config Class Initialized
INFO - 2018-02-18 20:12:19 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:12:19 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:12:19 --> Utf8 Class Initialized
INFO - 2018-02-18 20:12:19 --> URI Class Initialized
INFO - 2018-02-18 20:12:19 --> Router Class Initialized
INFO - 2018-02-18 20:12:19 --> Output Class Initialized
INFO - 2018-02-18 20:12:19 --> Security Class Initialized
DEBUG - 2018-02-18 20:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:12:19 --> Input Class Initialized
INFO - 2018-02-18 20:12:19 --> Language Class Initialized
INFO - 2018-02-18 20:12:19 --> Loader Class Initialized
INFO - 2018-02-18 20:12:19 --> Helper loaded: url_helper
INFO - 2018-02-18 20:12:19 --> Helper loaded: form_helper
INFO - 2018-02-18 20:12:19 --> Database Driver Class Initialized
DEBUG - 2018-02-18 20:12:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 20:12:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 20:12:19 --> Form Validation Class Initialized
INFO - 2018-02-18 20:12:19 --> Model Class Initialized
INFO - 2018-02-18 20:12:19 --> Controller Class Initialized
INFO - 2018-02-18 20:12:19 --> Model Class Initialized
INFO - 2018-02-18 20:12:19 --> Model Class Initialized
INFO - 2018-02-18 20:12:19 --> Model Class Initialized
INFO - 2018-02-18 20:12:19 --> Model Class Initialized
INFO - 2018-02-18 20:12:19 --> Model Class Initialized
DEBUG - 2018-02-18 20:12:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 20:12:19 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 20:12:19 --> Final output sent to browser
DEBUG - 2018-02-18 20:12:19 --> Total execution time: 0.0744
INFO - 2018-02-18 20:12:19 --> Config Class Initialized
INFO - 2018-02-18 20:12:19 --> Hooks Class Initialized
INFO - 2018-02-18 20:12:19 --> Config Class Initialized
INFO - 2018-02-18 20:12:19 --> Hooks Class Initialized
INFO - 2018-02-18 20:12:19 --> Config Class Initialized
INFO - 2018-02-18 20:12:19 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:12:19 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:12:19 --> Utf8 Class Initialized
DEBUG - 2018-02-18 20:12:19 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:12:19 --> Utf8 Class Initialized
INFO - 2018-02-18 20:12:19 --> URI Class Initialized
DEBUG - 2018-02-18 20:12:19 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:12:19 --> URI Class Initialized
INFO - 2018-02-18 20:12:19 --> Utf8 Class Initialized
INFO - 2018-02-18 20:12:19 --> Router Class Initialized
INFO - 2018-02-18 20:12:19 --> URI Class Initialized
INFO - 2018-02-18 20:12:19 --> Router Class Initialized
INFO - 2018-02-18 20:12:19 --> Output Class Initialized
INFO - 2018-02-18 20:12:19 --> Router Class Initialized
INFO - 2018-02-18 20:12:19 --> Security Class Initialized
INFO - 2018-02-18 20:12:19 --> Output Class Initialized
DEBUG - 2018-02-18 20:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:12:19 --> Input Class Initialized
INFO - 2018-02-18 20:12:19 --> Output Class Initialized
INFO - 2018-02-18 20:12:19 --> Security Class Initialized
INFO - 2018-02-18 20:12:19 --> Language Class Initialized
INFO - 2018-02-18 20:12:19 --> Security Class Initialized
DEBUG - 2018-02-18 20:12:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-18 20:12:19 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-18 20:12:19 --> Input Class Initialized
DEBUG - 2018-02-18 20:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:12:19 --> Input Class Initialized
INFO - 2018-02-18 20:12:19 --> Language Class Initialized
INFO - 2018-02-18 20:12:19 --> Language Class Initialized
ERROR - 2018-02-18 20:12:19 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-18 20:12:19 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-18 20:12:19 --> Config Class Initialized
INFO - 2018-02-18 20:12:19 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:12:19 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:12:19 --> Utf8 Class Initialized
INFO - 2018-02-18 20:12:19 --> URI Class Initialized
INFO - 2018-02-18 20:12:19 --> Router Class Initialized
INFO - 2018-02-18 20:12:19 --> Output Class Initialized
INFO - 2018-02-18 20:12:19 --> Security Class Initialized
DEBUG - 2018-02-18 20:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:12:19 --> Input Class Initialized
INFO - 2018-02-18 20:12:19 --> Language Class Initialized
ERROR - 2018-02-18 20:12:19 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-18 20:12:19 --> Config Class Initialized
INFO - 2018-02-18 20:12:19 --> Hooks Class Initialized
INFO - 2018-02-18 20:12:19 --> Config Class Initialized
INFO - 2018-02-18 20:12:19 --> Config Class Initialized
INFO - 2018-02-18 20:12:19 --> Hooks Class Initialized
INFO - 2018-02-18 20:12:19 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:12:19 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:12:19 --> Utf8 Class Initialized
DEBUG - 2018-02-18 20:12:19 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:12:19 --> URI Class Initialized
DEBUG - 2018-02-18 20:12:19 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:12:19 --> Utf8 Class Initialized
INFO - 2018-02-18 20:12:19 --> Utf8 Class Initialized
INFO - 2018-02-18 20:12:19 --> URI Class Initialized
INFO - 2018-02-18 20:12:19 --> URI Class Initialized
INFO - 2018-02-18 20:12:19 --> Router Class Initialized
INFO - 2018-02-18 20:12:19 --> Router Class Initialized
INFO - 2018-02-18 20:12:19 --> Router Class Initialized
INFO - 2018-02-18 20:12:19 --> Output Class Initialized
INFO - 2018-02-18 20:12:19 --> Security Class Initialized
INFO - 2018-02-18 20:12:19 --> Output Class Initialized
INFO - 2018-02-18 20:12:19 --> Output Class Initialized
DEBUG - 2018-02-18 20:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:12:19 --> Input Class Initialized
INFO - 2018-02-18 20:12:19 --> Security Class Initialized
INFO - 2018-02-18 20:12:19 --> Security Class Initialized
INFO - 2018-02-18 20:12:19 --> Language Class Initialized
DEBUG - 2018-02-18 20:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:12:19 --> Input Class Initialized
DEBUG - 2018-02-18 20:12:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-18 20:12:19 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-18 20:12:19 --> Input Class Initialized
INFO - 2018-02-18 20:12:19 --> Language Class Initialized
INFO - 2018-02-18 20:12:19 --> Language Class Initialized
ERROR - 2018-02-18 20:12:19 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-18 20:12:19 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-18 20:12:19 --> Config Class Initialized
INFO - 2018-02-18 20:12:19 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:12:19 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:12:19 --> Utf8 Class Initialized
INFO - 2018-02-18 20:12:19 --> URI Class Initialized
INFO - 2018-02-18 20:12:19 --> Router Class Initialized
INFO - 2018-02-18 20:12:19 --> Output Class Initialized
INFO - 2018-02-18 20:12:19 --> Security Class Initialized
DEBUG - 2018-02-18 20:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:12:19 --> Input Class Initialized
INFO - 2018-02-18 20:12:19 --> Language Class Initialized
INFO - 2018-02-18 20:12:19 --> Loader Class Initialized
INFO - 2018-02-18 20:12:19 --> Helper loaded: url_helper
INFO - 2018-02-18 20:12:19 --> Helper loaded: form_helper
INFO - 2018-02-18 20:12:19 --> Database Driver Class Initialized
DEBUG - 2018-02-18 20:12:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 20:12:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 20:12:20 --> Form Validation Class Initialized
INFO - 2018-02-18 20:12:20 --> Model Class Initialized
INFO - 2018-02-18 20:12:20 --> Controller Class Initialized
INFO - 2018-02-18 20:12:20 --> Model Class Initialized
INFO - 2018-02-18 20:12:20 --> Model Class Initialized
INFO - 2018-02-18 20:12:20 --> Model Class Initialized
INFO - 2018-02-18 20:12:20 --> Model Class Initialized
INFO - 2018-02-18 20:12:20 --> Model Class Initialized
DEBUG - 2018-02-18 20:12:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 20:12:37 --> Config Class Initialized
INFO - 2018-02-18 20:12:37 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:12:37 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:12:37 --> Utf8 Class Initialized
INFO - 2018-02-18 20:12:37 --> URI Class Initialized
INFO - 2018-02-18 20:12:37 --> Router Class Initialized
INFO - 2018-02-18 20:12:37 --> Output Class Initialized
INFO - 2018-02-18 20:12:37 --> Security Class Initialized
DEBUG - 2018-02-18 20:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:12:37 --> Input Class Initialized
INFO - 2018-02-18 20:12:37 --> Language Class Initialized
INFO - 2018-02-18 20:12:37 --> Loader Class Initialized
INFO - 2018-02-18 20:12:37 --> Helper loaded: url_helper
INFO - 2018-02-18 20:12:37 --> Helper loaded: form_helper
INFO - 2018-02-18 20:12:37 --> Database Driver Class Initialized
DEBUG - 2018-02-18 20:12:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 20:12:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 20:12:37 --> Form Validation Class Initialized
INFO - 2018-02-18 20:12:37 --> Model Class Initialized
INFO - 2018-02-18 20:12:37 --> Controller Class Initialized
INFO - 2018-02-18 20:12:37 --> Model Class Initialized
INFO - 2018-02-18 20:12:37 --> Model Class Initialized
INFO - 2018-02-18 20:12:37 --> Model Class Initialized
INFO - 2018-02-18 20:12:37 --> Model Class Initialized
INFO - 2018-02-18 20:12:37 --> Model Class Initialized
DEBUG - 2018-02-18 20:12:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 20:12:37 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 20:12:37 --> Final output sent to browser
DEBUG - 2018-02-18 20:12:37 --> Total execution time: 0.0758
INFO - 2018-02-18 20:12:37 --> Config Class Initialized
INFO - 2018-02-18 20:12:37 --> Config Class Initialized
INFO - 2018-02-18 20:12:37 --> Hooks Class Initialized
INFO - 2018-02-18 20:12:37 --> Hooks Class Initialized
INFO - 2018-02-18 20:12:37 --> Config Class Initialized
INFO - 2018-02-18 20:12:37 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:12:37 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:12:37 --> Utf8 Class Initialized
DEBUG - 2018-02-18 20:12:37 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:12:37 --> Utf8 Class Initialized
INFO - 2018-02-18 20:12:37 --> URI Class Initialized
INFO - 2018-02-18 20:12:37 --> URI Class Initialized
DEBUG - 2018-02-18 20:12:37 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:12:37 --> Utf8 Class Initialized
INFO - 2018-02-18 20:12:37 --> Router Class Initialized
INFO - 2018-02-18 20:12:37 --> URI Class Initialized
INFO - 2018-02-18 20:12:37 --> Router Class Initialized
INFO - 2018-02-18 20:12:37 --> Output Class Initialized
INFO - 2018-02-18 20:12:37 --> Router Class Initialized
INFO - 2018-02-18 20:12:37 --> Output Class Initialized
INFO - 2018-02-18 20:12:37 --> Security Class Initialized
INFO - 2018-02-18 20:12:37 --> Security Class Initialized
INFO - 2018-02-18 20:12:37 --> Output Class Initialized
DEBUG - 2018-02-18 20:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:12:37 --> Input Class Initialized
DEBUG - 2018-02-18 20:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:12:37 --> Input Class Initialized
INFO - 2018-02-18 20:12:37 --> Language Class Initialized
INFO - 2018-02-18 20:12:37 --> Security Class Initialized
INFO - 2018-02-18 20:12:37 --> Language Class Initialized
ERROR - 2018-02-18 20:12:37 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-18 20:12:37 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-02-18 20:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:12:37 --> Input Class Initialized
INFO - 2018-02-18 20:12:37 --> Language Class Initialized
ERROR - 2018-02-18 20:12:37 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-18 20:12:37 --> Config Class Initialized
INFO - 2018-02-18 20:12:37 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:12:37 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:12:37 --> Utf8 Class Initialized
INFO - 2018-02-18 20:12:37 --> URI Class Initialized
INFO - 2018-02-18 20:12:37 --> Router Class Initialized
INFO - 2018-02-18 20:12:37 --> Output Class Initialized
INFO - 2018-02-18 20:12:37 --> Security Class Initialized
DEBUG - 2018-02-18 20:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:12:37 --> Input Class Initialized
INFO - 2018-02-18 20:12:37 --> Language Class Initialized
ERROR - 2018-02-18 20:12:37 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-18 20:12:37 --> Config Class Initialized
INFO - 2018-02-18 20:12:37 --> Config Class Initialized
INFO - 2018-02-18 20:12:37 --> Hooks Class Initialized
INFO - 2018-02-18 20:12:37 --> Hooks Class Initialized
INFO - 2018-02-18 20:12:37 --> Config Class Initialized
INFO - 2018-02-18 20:12:37 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:12:37 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:12:37 --> Utf8 Class Initialized
DEBUG - 2018-02-18 20:12:37 --> UTF-8 Support Enabled
DEBUG - 2018-02-18 20:12:37 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:12:37 --> Utf8 Class Initialized
INFO - 2018-02-18 20:12:37 --> Utf8 Class Initialized
INFO - 2018-02-18 20:12:37 --> URI Class Initialized
INFO - 2018-02-18 20:12:37 --> URI Class Initialized
INFO - 2018-02-18 20:12:37 --> URI Class Initialized
INFO - 2018-02-18 20:12:37 --> Router Class Initialized
INFO - 2018-02-18 20:12:37 --> Router Class Initialized
INFO - 2018-02-18 20:12:37 --> Router Class Initialized
INFO - 2018-02-18 20:12:37 --> Output Class Initialized
INFO - 2018-02-18 20:12:37 --> Output Class Initialized
INFO - 2018-02-18 20:12:37 --> Output Class Initialized
INFO - 2018-02-18 20:12:37 --> Security Class Initialized
INFO - 2018-02-18 20:12:37 --> Security Class Initialized
INFO - 2018-02-18 20:12:37 --> Security Class Initialized
DEBUG - 2018-02-18 20:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:12:37 --> Input Class Initialized
DEBUG - 2018-02-18 20:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:12:37 --> Input Class Initialized
DEBUG - 2018-02-18 20:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:12:37 --> Language Class Initialized
INFO - 2018-02-18 20:12:37 --> Input Class Initialized
INFO - 2018-02-18 20:12:37 --> Language Class Initialized
INFO - 2018-02-18 20:12:37 --> Language Class Initialized
ERROR - 2018-02-18 20:12:37 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-18 20:12:37 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-18 20:12:37 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-18 20:12:38 --> Config Class Initialized
INFO - 2018-02-18 20:12:38 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:12:38 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:12:38 --> Utf8 Class Initialized
INFO - 2018-02-18 20:12:38 --> URI Class Initialized
INFO - 2018-02-18 20:12:38 --> Router Class Initialized
INFO - 2018-02-18 20:12:38 --> Output Class Initialized
INFO - 2018-02-18 20:12:38 --> Security Class Initialized
DEBUG - 2018-02-18 20:12:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:12:38 --> Input Class Initialized
INFO - 2018-02-18 20:12:38 --> Language Class Initialized
INFO - 2018-02-18 20:12:38 --> Loader Class Initialized
INFO - 2018-02-18 20:12:38 --> Helper loaded: url_helper
INFO - 2018-02-18 20:12:38 --> Helper loaded: form_helper
INFO - 2018-02-18 20:12:38 --> Database Driver Class Initialized
DEBUG - 2018-02-18 20:12:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 20:12:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 20:12:38 --> Form Validation Class Initialized
INFO - 2018-02-18 20:12:38 --> Model Class Initialized
INFO - 2018-02-18 20:12:38 --> Controller Class Initialized
INFO - 2018-02-18 20:12:38 --> Model Class Initialized
INFO - 2018-02-18 20:12:38 --> Model Class Initialized
INFO - 2018-02-18 20:12:38 --> Model Class Initialized
INFO - 2018-02-18 20:12:38 --> Model Class Initialized
INFO - 2018-02-18 20:12:38 --> Model Class Initialized
DEBUG - 2018-02-18 20:12:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 20:13:12 --> Config Class Initialized
INFO - 2018-02-18 20:13:12 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:13:12 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:13:12 --> Utf8 Class Initialized
INFO - 2018-02-18 20:13:12 --> URI Class Initialized
INFO - 2018-02-18 20:13:12 --> Router Class Initialized
INFO - 2018-02-18 20:13:12 --> Output Class Initialized
INFO - 2018-02-18 20:13:12 --> Security Class Initialized
DEBUG - 2018-02-18 20:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:13:12 --> Input Class Initialized
INFO - 2018-02-18 20:13:12 --> Language Class Initialized
INFO - 2018-02-18 20:13:12 --> Loader Class Initialized
INFO - 2018-02-18 20:13:12 --> Helper loaded: url_helper
INFO - 2018-02-18 20:13:12 --> Helper loaded: form_helper
INFO - 2018-02-18 20:13:12 --> Database Driver Class Initialized
DEBUG - 2018-02-18 20:13:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 20:13:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 20:13:12 --> Form Validation Class Initialized
INFO - 2018-02-18 20:13:12 --> Model Class Initialized
INFO - 2018-02-18 20:13:12 --> Controller Class Initialized
INFO - 2018-02-18 20:13:12 --> Model Class Initialized
INFO - 2018-02-18 20:13:12 --> Model Class Initialized
INFO - 2018-02-18 20:13:12 --> Model Class Initialized
INFO - 2018-02-18 20:13:12 --> Model Class Initialized
INFO - 2018-02-18 20:13:12 --> Model Class Initialized
DEBUG - 2018-02-18 20:13:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 20:13:12 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 20:13:12 --> Final output sent to browser
DEBUG - 2018-02-18 20:13:12 --> Total execution time: 0.0766
INFO - 2018-02-18 20:13:12 --> Config Class Initialized
INFO - 2018-02-18 20:13:12 --> Config Class Initialized
INFO - 2018-02-18 20:13:12 --> Hooks Class Initialized
INFO - 2018-02-18 20:13:12 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:13:12 --> UTF-8 Support Enabled
DEBUG - 2018-02-18 20:13:12 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:13:12 --> Utf8 Class Initialized
INFO - 2018-02-18 20:13:12 --> Utf8 Class Initialized
INFO - 2018-02-18 20:13:12 --> URI Class Initialized
INFO - 2018-02-18 20:13:12 --> URI Class Initialized
INFO - 2018-02-18 20:13:12 --> Router Class Initialized
INFO - 2018-02-18 20:13:12 --> Router Class Initialized
INFO - 2018-02-18 20:13:12 --> Output Class Initialized
INFO - 2018-02-18 20:13:12 --> Output Class Initialized
INFO - 2018-02-18 20:13:12 --> Security Class Initialized
INFO - 2018-02-18 20:13:12 --> Security Class Initialized
DEBUG - 2018-02-18 20:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:13:12 --> Input Class Initialized
DEBUG - 2018-02-18 20:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:13:12 --> Input Class Initialized
INFO - 2018-02-18 20:13:12 --> Language Class Initialized
INFO - 2018-02-18 20:13:12 --> Language Class Initialized
ERROR - 2018-02-18 20:13:12 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-18 20:13:12 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-18 20:13:12 --> Config Class Initialized
INFO - 2018-02-18 20:13:12 --> Hooks Class Initialized
INFO - 2018-02-18 20:13:12 --> Config Class Initialized
INFO - 2018-02-18 20:13:12 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:13:12 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:13:12 --> Utf8 Class Initialized
INFO - 2018-02-18 20:13:12 --> URI Class Initialized
DEBUG - 2018-02-18 20:13:12 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:13:12 --> Utf8 Class Initialized
INFO - 2018-02-18 20:13:12 --> Router Class Initialized
INFO - 2018-02-18 20:13:12 --> URI Class Initialized
INFO - 2018-02-18 20:13:12 --> Output Class Initialized
INFO - 2018-02-18 20:13:12 --> Router Class Initialized
INFO - 2018-02-18 20:13:12 --> Security Class Initialized
INFO - 2018-02-18 20:13:12 --> Output Class Initialized
DEBUG - 2018-02-18 20:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:13:12 --> Input Class Initialized
INFO - 2018-02-18 20:13:12 --> Security Class Initialized
INFO - 2018-02-18 20:13:12 --> Language Class Initialized
DEBUG - 2018-02-18 20:13:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-18 20:13:12 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-18 20:13:12 --> Input Class Initialized
INFO - 2018-02-18 20:13:12 --> Language Class Initialized
ERROR - 2018-02-18 20:13:12 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-18 20:13:12 --> Config Class Initialized
INFO - 2018-02-18 20:13:12 --> Config Class Initialized
INFO - 2018-02-18 20:13:12 --> Hooks Class Initialized
INFO - 2018-02-18 20:13:12 --> Hooks Class Initialized
INFO - 2018-02-18 20:13:12 --> Config Class Initialized
INFO - 2018-02-18 20:13:12 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:13:12 --> UTF-8 Support Enabled
DEBUG - 2018-02-18 20:13:12 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:13:12 --> Utf8 Class Initialized
INFO - 2018-02-18 20:13:12 --> Utf8 Class Initialized
DEBUG - 2018-02-18 20:13:12 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:13:12 --> Utf8 Class Initialized
INFO - 2018-02-18 20:13:12 --> URI Class Initialized
INFO - 2018-02-18 20:13:12 --> URI Class Initialized
INFO - 2018-02-18 20:13:12 --> URI Class Initialized
INFO - 2018-02-18 20:13:12 --> Router Class Initialized
INFO - 2018-02-18 20:13:12 --> Router Class Initialized
INFO - 2018-02-18 20:13:12 --> Router Class Initialized
INFO - 2018-02-18 20:13:12 --> Output Class Initialized
INFO - 2018-02-18 20:13:12 --> Output Class Initialized
INFO - 2018-02-18 20:13:12 --> Output Class Initialized
INFO - 2018-02-18 20:13:12 --> Security Class Initialized
INFO - 2018-02-18 20:13:12 --> Security Class Initialized
INFO - 2018-02-18 20:13:12 --> Security Class Initialized
DEBUG - 2018-02-18 20:13:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-18 20:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:13:12 --> Input Class Initialized
DEBUG - 2018-02-18 20:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:13:12 --> Input Class Initialized
INFO - 2018-02-18 20:13:12 --> Input Class Initialized
INFO - 2018-02-18 20:13:12 --> Language Class Initialized
INFO - 2018-02-18 20:13:12 --> Language Class Initialized
INFO - 2018-02-18 20:13:12 --> Language Class Initialized
ERROR - 2018-02-18 20:13:12 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-18 20:13:12 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-18 20:13:12 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-18 20:13:12 --> Config Class Initialized
INFO - 2018-02-18 20:13:12 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:13:12 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:13:12 --> Utf8 Class Initialized
INFO - 2018-02-18 20:13:12 --> URI Class Initialized
INFO - 2018-02-18 20:13:12 --> Router Class Initialized
INFO - 2018-02-18 20:13:12 --> Output Class Initialized
INFO - 2018-02-18 20:13:12 --> Security Class Initialized
DEBUG - 2018-02-18 20:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:13:12 --> Input Class Initialized
INFO - 2018-02-18 20:13:12 --> Language Class Initialized
INFO - 2018-02-18 20:13:12 --> Loader Class Initialized
INFO - 2018-02-18 20:13:12 --> Helper loaded: url_helper
INFO - 2018-02-18 20:13:12 --> Helper loaded: form_helper
INFO - 2018-02-18 20:13:12 --> Database Driver Class Initialized
DEBUG - 2018-02-18 20:13:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 20:13:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 20:13:12 --> Form Validation Class Initialized
INFO - 2018-02-18 20:13:12 --> Model Class Initialized
INFO - 2018-02-18 20:13:12 --> Controller Class Initialized
INFO - 2018-02-18 20:13:12 --> Model Class Initialized
INFO - 2018-02-18 20:13:12 --> Model Class Initialized
INFO - 2018-02-18 20:13:12 --> Model Class Initialized
INFO - 2018-02-18 20:13:12 --> Model Class Initialized
INFO - 2018-02-18 20:13:12 --> Model Class Initialized
DEBUG - 2018-02-18 20:13:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 20:13:46 --> Config Class Initialized
INFO - 2018-02-18 20:13:46 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:13:46 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:13:46 --> Utf8 Class Initialized
INFO - 2018-02-18 20:13:46 --> URI Class Initialized
INFO - 2018-02-18 20:13:46 --> Router Class Initialized
INFO - 2018-02-18 20:13:46 --> Output Class Initialized
INFO - 2018-02-18 20:13:46 --> Security Class Initialized
DEBUG - 2018-02-18 20:13:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:13:46 --> Input Class Initialized
INFO - 2018-02-18 20:13:46 --> Language Class Initialized
INFO - 2018-02-18 20:13:46 --> Loader Class Initialized
INFO - 2018-02-18 20:13:46 --> Helper loaded: url_helper
INFO - 2018-02-18 20:13:46 --> Helper loaded: form_helper
INFO - 2018-02-18 20:13:46 --> Database Driver Class Initialized
DEBUG - 2018-02-18 20:13:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 20:13:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 20:13:46 --> Form Validation Class Initialized
INFO - 2018-02-18 20:13:46 --> Model Class Initialized
INFO - 2018-02-18 20:13:46 --> Controller Class Initialized
INFO - 2018-02-18 20:13:46 --> Model Class Initialized
INFO - 2018-02-18 20:13:46 --> Model Class Initialized
INFO - 2018-02-18 20:13:46 --> Model Class Initialized
INFO - 2018-02-18 20:13:46 --> Model Class Initialized
INFO - 2018-02-18 20:13:46 --> Model Class Initialized
DEBUG - 2018-02-18 20:13:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 20:13:46 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 20:13:46 --> Final output sent to browser
DEBUG - 2018-02-18 20:13:46 --> Total execution time: 0.0751
INFO - 2018-02-18 20:13:47 --> Config Class Initialized
INFO - 2018-02-18 20:13:47 --> Hooks Class Initialized
INFO - 2018-02-18 20:13:47 --> Config Class Initialized
INFO - 2018-02-18 20:13:47 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:13:47 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:13:47 --> Utf8 Class Initialized
INFO - 2018-02-18 20:13:47 --> Config Class Initialized
INFO - 2018-02-18 20:13:47 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:13:47 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:13:47 --> URI Class Initialized
INFO - 2018-02-18 20:13:47 --> Utf8 Class Initialized
INFO - 2018-02-18 20:13:47 --> URI Class Initialized
INFO - 2018-02-18 20:13:47 --> Router Class Initialized
DEBUG - 2018-02-18 20:13:47 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:13:47 --> Utf8 Class Initialized
INFO - 2018-02-18 20:13:47 --> URI Class Initialized
INFO - 2018-02-18 20:13:47 --> Router Class Initialized
INFO - 2018-02-18 20:13:47 --> Output Class Initialized
INFO - 2018-02-18 20:13:47 --> Router Class Initialized
INFO - 2018-02-18 20:13:47 --> Security Class Initialized
INFO - 2018-02-18 20:13:47 --> Output Class Initialized
DEBUG - 2018-02-18 20:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:13:47 --> Input Class Initialized
INFO - 2018-02-18 20:13:47 --> Security Class Initialized
INFO - 2018-02-18 20:13:47 --> Output Class Initialized
INFO - 2018-02-18 20:13:47 --> Language Class Initialized
INFO - 2018-02-18 20:13:47 --> Security Class Initialized
DEBUG - 2018-02-18 20:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:13:47 --> Input Class Initialized
ERROR - 2018-02-18 20:13:47 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-18 20:13:47 --> Language Class Initialized
DEBUG - 2018-02-18 20:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:13:47 --> Input Class Initialized
INFO - 2018-02-18 20:13:47 --> Language Class Initialized
ERROR - 2018-02-18 20:13:47 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-18 20:13:47 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-18 20:13:47 --> Config Class Initialized
INFO - 2018-02-18 20:13:47 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:13:47 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:13:47 --> Utf8 Class Initialized
INFO - 2018-02-18 20:13:47 --> URI Class Initialized
INFO - 2018-02-18 20:13:47 --> Router Class Initialized
INFO - 2018-02-18 20:13:47 --> Output Class Initialized
INFO - 2018-02-18 20:13:47 --> Security Class Initialized
DEBUG - 2018-02-18 20:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:13:47 --> Input Class Initialized
INFO - 2018-02-18 20:13:47 --> Language Class Initialized
ERROR - 2018-02-18 20:13:47 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-18 20:13:47 --> Config Class Initialized
INFO - 2018-02-18 20:13:47 --> Hooks Class Initialized
INFO - 2018-02-18 20:13:47 --> Config Class Initialized
INFO - 2018-02-18 20:13:47 --> Hooks Class Initialized
INFO - 2018-02-18 20:13:47 --> Config Class Initialized
DEBUG - 2018-02-18 20:13:47 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:13:47 --> Hooks Class Initialized
INFO - 2018-02-18 20:13:47 --> Utf8 Class Initialized
INFO - 2018-02-18 20:13:47 --> URI Class Initialized
DEBUG - 2018-02-18 20:13:47 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:13:47 --> Utf8 Class Initialized
DEBUG - 2018-02-18 20:13:47 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:13:47 --> Utf8 Class Initialized
INFO - 2018-02-18 20:13:47 --> URI Class Initialized
INFO - 2018-02-18 20:13:47 --> Router Class Initialized
INFO - 2018-02-18 20:13:47 --> URI Class Initialized
INFO - 2018-02-18 20:13:47 --> Router Class Initialized
INFO - 2018-02-18 20:13:47 --> Output Class Initialized
INFO - 2018-02-18 20:13:47 --> Router Class Initialized
INFO - 2018-02-18 20:13:47 --> Security Class Initialized
INFO - 2018-02-18 20:13:47 --> Output Class Initialized
INFO - 2018-02-18 20:13:47 --> Output Class Initialized
DEBUG - 2018-02-18 20:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:13:47 --> Input Class Initialized
INFO - 2018-02-18 20:13:47 --> Security Class Initialized
INFO - 2018-02-18 20:13:47 --> Language Class Initialized
INFO - 2018-02-18 20:13:47 --> Security Class Initialized
DEBUG - 2018-02-18 20:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:13:47 --> Input Class Initialized
DEBUG - 2018-02-18 20:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:13:47 --> Language Class Initialized
ERROR - 2018-02-18 20:13:47 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-18 20:13:47 --> Input Class Initialized
ERROR - 2018-02-18 20:13:47 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-18 20:13:47 --> Language Class Initialized
ERROR - 2018-02-18 20:13:47 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-18 20:13:47 --> Config Class Initialized
INFO - 2018-02-18 20:13:47 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:13:47 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:13:47 --> Utf8 Class Initialized
INFO - 2018-02-18 20:13:47 --> URI Class Initialized
INFO - 2018-02-18 20:13:47 --> Router Class Initialized
INFO - 2018-02-18 20:13:47 --> Output Class Initialized
INFO - 2018-02-18 20:13:47 --> Security Class Initialized
DEBUG - 2018-02-18 20:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:13:47 --> Input Class Initialized
INFO - 2018-02-18 20:13:47 --> Language Class Initialized
INFO - 2018-02-18 20:13:47 --> Loader Class Initialized
INFO - 2018-02-18 20:13:47 --> Helper loaded: url_helper
INFO - 2018-02-18 20:13:47 --> Helper loaded: form_helper
INFO - 2018-02-18 20:13:47 --> Database Driver Class Initialized
DEBUG - 2018-02-18 20:13:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 20:13:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 20:13:47 --> Form Validation Class Initialized
INFO - 2018-02-18 20:13:47 --> Model Class Initialized
INFO - 2018-02-18 20:13:47 --> Controller Class Initialized
INFO - 2018-02-18 20:13:47 --> Model Class Initialized
INFO - 2018-02-18 20:13:47 --> Model Class Initialized
INFO - 2018-02-18 20:13:47 --> Model Class Initialized
INFO - 2018-02-18 20:13:47 --> Model Class Initialized
INFO - 2018-02-18 20:13:47 --> Model Class Initialized
DEBUG - 2018-02-18 20:13:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 20:14:22 --> Config Class Initialized
INFO - 2018-02-18 20:14:22 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:14:22 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:14:22 --> Utf8 Class Initialized
INFO - 2018-02-18 20:14:22 --> URI Class Initialized
INFO - 2018-02-18 20:14:22 --> Router Class Initialized
INFO - 2018-02-18 20:14:22 --> Output Class Initialized
INFO - 2018-02-18 20:14:22 --> Security Class Initialized
DEBUG - 2018-02-18 20:14:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:14:22 --> Input Class Initialized
INFO - 2018-02-18 20:14:22 --> Language Class Initialized
INFO - 2018-02-18 20:14:22 --> Loader Class Initialized
INFO - 2018-02-18 20:14:22 --> Helper loaded: url_helper
INFO - 2018-02-18 20:14:22 --> Helper loaded: form_helper
INFO - 2018-02-18 20:14:22 --> Database Driver Class Initialized
DEBUG - 2018-02-18 20:14:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 20:14:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 20:14:22 --> Form Validation Class Initialized
INFO - 2018-02-18 20:14:22 --> Model Class Initialized
INFO - 2018-02-18 20:14:22 --> Controller Class Initialized
INFO - 2018-02-18 20:14:22 --> Model Class Initialized
INFO - 2018-02-18 20:14:22 --> Model Class Initialized
INFO - 2018-02-18 20:14:22 --> Model Class Initialized
INFO - 2018-02-18 20:14:22 --> Model Class Initialized
INFO - 2018-02-18 20:14:22 --> Model Class Initialized
DEBUG - 2018-02-18 20:14:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 20:14:22 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 20:14:22 --> Final output sent to browser
DEBUG - 2018-02-18 20:14:22 --> Total execution time: 0.0773
INFO - 2018-02-18 20:14:23 --> Config Class Initialized
INFO - 2018-02-18 20:14:23 --> Hooks Class Initialized
INFO - 2018-02-18 20:14:23 --> Config Class Initialized
INFO - 2018-02-18 20:14:23 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:14:23 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:14:23 --> Utf8 Class Initialized
INFO - 2018-02-18 20:14:23 --> Config Class Initialized
INFO - 2018-02-18 20:14:23 --> Hooks Class Initialized
INFO - 2018-02-18 20:14:23 --> URI Class Initialized
DEBUG - 2018-02-18 20:14:23 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:14:23 --> Utf8 Class Initialized
INFO - 2018-02-18 20:14:23 --> Router Class Initialized
INFO - 2018-02-18 20:14:23 --> URI Class Initialized
DEBUG - 2018-02-18 20:14:23 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:14:23 --> Utf8 Class Initialized
INFO - 2018-02-18 20:14:23 --> Output Class Initialized
INFO - 2018-02-18 20:14:23 --> Router Class Initialized
INFO - 2018-02-18 20:14:23 --> URI Class Initialized
INFO - 2018-02-18 20:14:23 --> Security Class Initialized
INFO - 2018-02-18 20:14:23 --> Output Class Initialized
INFO - 2018-02-18 20:14:23 --> Router Class Initialized
DEBUG - 2018-02-18 20:14:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:14:23 --> Input Class Initialized
INFO - 2018-02-18 20:14:23 --> Language Class Initialized
INFO - 2018-02-18 20:14:23 --> Security Class Initialized
INFO - 2018-02-18 20:14:23 --> Output Class Initialized
ERROR - 2018-02-18 20:14:23 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-02-18 20:14:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:14:23 --> Security Class Initialized
INFO - 2018-02-18 20:14:23 --> Input Class Initialized
INFO - 2018-02-18 20:14:23 --> Language Class Initialized
DEBUG - 2018-02-18 20:14:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:14:23 --> Input Class Initialized
ERROR - 2018-02-18 20:14:23 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-18 20:14:23 --> Language Class Initialized
ERROR - 2018-02-18 20:14:23 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-18 20:14:23 --> Config Class Initialized
INFO - 2018-02-18 20:14:23 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:14:23 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:14:23 --> Utf8 Class Initialized
INFO - 2018-02-18 20:14:23 --> URI Class Initialized
INFO - 2018-02-18 20:14:23 --> Router Class Initialized
INFO - 2018-02-18 20:14:23 --> Output Class Initialized
INFO - 2018-02-18 20:14:23 --> Security Class Initialized
DEBUG - 2018-02-18 20:14:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:14:23 --> Input Class Initialized
INFO - 2018-02-18 20:14:23 --> Language Class Initialized
ERROR - 2018-02-18 20:14:23 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-18 20:14:23 --> Config Class Initialized
INFO - 2018-02-18 20:14:23 --> Config Class Initialized
INFO - 2018-02-18 20:14:23 --> Hooks Class Initialized
INFO - 2018-02-18 20:14:23 --> Hooks Class Initialized
INFO - 2018-02-18 20:14:23 --> Config Class Initialized
INFO - 2018-02-18 20:14:23 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:14:23 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:14:23 --> Utf8 Class Initialized
DEBUG - 2018-02-18 20:14:23 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:14:23 --> Utf8 Class Initialized
INFO - 2018-02-18 20:14:23 --> URI Class Initialized
DEBUG - 2018-02-18 20:14:23 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:14:23 --> URI Class Initialized
INFO - 2018-02-18 20:14:23 --> Utf8 Class Initialized
INFO - 2018-02-18 20:14:23 --> Router Class Initialized
INFO - 2018-02-18 20:14:23 --> URI Class Initialized
INFO - 2018-02-18 20:14:23 --> Router Class Initialized
INFO - 2018-02-18 20:14:23 --> Router Class Initialized
INFO - 2018-02-18 20:14:23 --> Output Class Initialized
INFO - 2018-02-18 20:14:23 --> Output Class Initialized
INFO - 2018-02-18 20:14:23 --> Output Class Initialized
INFO - 2018-02-18 20:14:23 --> Security Class Initialized
INFO - 2018-02-18 20:14:23 --> Security Class Initialized
INFO - 2018-02-18 20:14:23 --> Security Class Initialized
DEBUG - 2018-02-18 20:14:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-18 20:14:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:14:23 --> Input Class Initialized
INFO - 2018-02-18 20:14:23 --> Input Class Initialized
DEBUG - 2018-02-18 20:14:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:14:23 --> Language Class Initialized
INFO - 2018-02-18 20:14:23 --> Input Class Initialized
INFO - 2018-02-18 20:14:23 --> Language Class Initialized
INFO - 2018-02-18 20:14:23 --> Language Class Initialized
ERROR - 2018-02-18 20:14:23 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-18 20:14:23 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-18 20:14:23 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-18 20:14:23 --> Config Class Initialized
INFO - 2018-02-18 20:14:23 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:14:23 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:14:23 --> Utf8 Class Initialized
INFO - 2018-02-18 20:14:23 --> URI Class Initialized
INFO - 2018-02-18 20:14:23 --> Router Class Initialized
INFO - 2018-02-18 20:14:23 --> Output Class Initialized
INFO - 2018-02-18 20:14:23 --> Security Class Initialized
DEBUG - 2018-02-18 20:14:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:14:23 --> Input Class Initialized
INFO - 2018-02-18 20:14:23 --> Language Class Initialized
INFO - 2018-02-18 20:14:23 --> Loader Class Initialized
INFO - 2018-02-18 20:14:23 --> Helper loaded: url_helper
INFO - 2018-02-18 20:14:23 --> Helper loaded: form_helper
INFO - 2018-02-18 20:14:23 --> Database Driver Class Initialized
DEBUG - 2018-02-18 20:14:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 20:14:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 20:14:23 --> Form Validation Class Initialized
INFO - 2018-02-18 20:14:23 --> Model Class Initialized
INFO - 2018-02-18 20:14:23 --> Controller Class Initialized
INFO - 2018-02-18 20:14:23 --> Model Class Initialized
INFO - 2018-02-18 20:14:23 --> Model Class Initialized
INFO - 2018-02-18 20:14:23 --> Model Class Initialized
INFO - 2018-02-18 20:14:23 --> Model Class Initialized
INFO - 2018-02-18 20:14:23 --> Model Class Initialized
DEBUG - 2018-02-18 20:14:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 20:15:16 --> Config Class Initialized
INFO - 2018-02-18 20:15:16 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:15:16 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:15:16 --> Utf8 Class Initialized
INFO - 2018-02-18 20:15:16 --> URI Class Initialized
INFO - 2018-02-18 20:15:16 --> Router Class Initialized
INFO - 2018-02-18 20:15:16 --> Output Class Initialized
INFO - 2018-02-18 20:15:16 --> Security Class Initialized
DEBUG - 2018-02-18 20:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:15:16 --> Input Class Initialized
INFO - 2018-02-18 20:15:16 --> Language Class Initialized
INFO - 2018-02-18 20:15:16 --> Loader Class Initialized
INFO - 2018-02-18 20:15:16 --> Helper loaded: url_helper
INFO - 2018-02-18 20:15:16 --> Helper loaded: form_helper
INFO - 2018-02-18 20:15:16 --> Database Driver Class Initialized
DEBUG - 2018-02-18 20:15:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 20:15:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 20:15:17 --> Form Validation Class Initialized
INFO - 2018-02-18 20:15:17 --> Model Class Initialized
INFO - 2018-02-18 20:15:17 --> Controller Class Initialized
INFO - 2018-02-18 20:15:17 --> Model Class Initialized
INFO - 2018-02-18 20:15:17 --> Model Class Initialized
INFO - 2018-02-18 20:15:17 --> Model Class Initialized
INFO - 2018-02-18 20:15:17 --> Model Class Initialized
INFO - 2018-02-18 20:15:17 --> Model Class Initialized
DEBUG - 2018-02-18 20:15:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 20:15:17 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 20:15:17 --> Final output sent to browser
DEBUG - 2018-02-18 20:15:17 --> Total execution time: 0.0682
INFO - 2018-02-18 20:15:17 --> Config Class Initialized
INFO - 2018-02-18 20:15:17 --> Hooks Class Initialized
INFO - 2018-02-18 20:15:17 --> Config Class Initialized
INFO - 2018-02-18 20:15:17 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:15:17 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:15:17 --> Utf8 Class Initialized
DEBUG - 2018-02-18 20:15:17 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:15:17 --> Utf8 Class Initialized
INFO - 2018-02-18 20:15:17 --> URI Class Initialized
INFO - 2018-02-18 20:15:17 --> URI Class Initialized
INFO - 2018-02-18 20:15:17 --> Router Class Initialized
INFO - 2018-02-18 20:15:17 --> Router Class Initialized
INFO - 2018-02-18 20:15:17 --> Output Class Initialized
INFO - 2018-02-18 20:15:17 --> Output Class Initialized
INFO - 2018-02-18 20:15:17 --> Security Class Initialized
INFO - 2018-02-18 20:15:17 --> Security Class Initialized
DEBUG - 2018-02-18 20:15:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-18 20:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:15:17 --> Input Class Initialized
INFO - 2018-02-18 20:15:17 --> Input Class Initialized
INFO - 2018-02-18 20:15:17 --> Language Class Initialized
INFO - 2018-02-18 20:15:17 --> Language Class Initialized
ERROR - 2018-02-18 20:15:17 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-18 20:15:17 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-18 20:15:17 --> Config Class Initialized
INFO - 2018-02-18 20:15:17 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:15:17 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:15:17 --> Utf8 Class Initialized
INFO - 2018-02-18 20:15:17 --> Config Class Initialized
INFO - 2018-02-18 20:15:17 --> Hooks Class Initialized
INFO - 2018-02-18 20:15:17 --> URI Class Initialized
INFO - 2018-02-18 20:15:17 --> Router Class Initialized
DEBUG - 2018-02-18 20:15:17 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:15:17 --> Utf8 Class Initialized
INFO - 2018-02-18 20:15:17 --> Output Class Initialized
INFO - 2018-02-18 20:15:17 --> URI Class Initialized
INFO - 2018-02-18 20:15:17 --> Security Class Initialized
INFO - 2018-02-18 20:15:17 --> Router Class Initialized
DEBUG - 2018-02-18 20:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:15:17 --> Input Class Initialized
INFO - 2018-02-18 20:15:17 --> Output Class Initialized
INFO - 2018-02-18 20:15:17 --> Language Class Initialized
INFO - 2018-02-18 20:15:17 --> Security Class Initialized
ERROR - 2018-02-18 20:15:17 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-02-18 20:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:15:17 --> Input Class Initialized
INFO - 2018-02-18 20:15:17 --> Language Class Initialized
ERROR - 2018-02-18 20:15:17 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-18 20:15:17 --> Config Class Initialized
INFO - 2018-02-18 20:15:17 --> Hooks Class Initialized
INFO - 2018-02-18 20:15:17 --> Config Class Initialized
INFO - 2018-02-18 20:15:17 --> Config Class Initialized
INFO - 2018-02-18 20:15:17 --> Hooks Class Initialized
INFO - 2018-02-18 20:15:17 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:15:17 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:15:17 --> Utf8 Class Initialized
DEBUG - 2018-02-18 20:15:17 --> UTF-8 Support Enabled
DEBUG - 2018-02-18 20:15:17 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:15:17 --> Utf8 Class Initialized
INFO - 2018-02-18 20:15:17 --> Utf8 Class Initialized
INFO - 2018-02-18 20:15:17 --> URI Class Initialized
INFO - 2018-02-18 20:15:17 --> URI Class Initialized
INFO - 2018-02-18 20:15:17 --> URI Class Initialized
INFO - 2018-02-18 20:15:17 --> Router Class Initialized
INFO - 2018-02-18 20:15:17 --> Router Class Initialized
INFO - 2018-02-18 20:15:17 --> Router Class Initialized
INFO - 2018-02-18 20:15:17 --> Output Class Initialized
INFO - 2018-02-18 20:15:17 --> Output Class Initialized
INFO - 2018-02-18 20:15:17 --> Security Class Initialized
INFO - 2018-02-18 20:15:17 --> Output Class Initialized
INFO - 2018-02-18 20:15:17 --> Security Class Initialized
DEBUG - 2018-02-18 20:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:15:17 --> Input Class Initialized
DEBUG - 2018-02-18 20:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:15:17 --> Input Class Initialized
INFO - 2018-02-18 20:15:17 --> Security Class Initialized
INFO - 2018-02-18 20:15:17 --> Language Class Initialized
INFO - 2018-02-18 20:15:17 --> Language Class Initialized
DEBUG - 2018-02-18 20:15:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-18 20:15:17 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-18 20:15:17 --> Input Class Initialized
ERROR - 2018-02-18 20:15:17 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-18 20:15:17 --> Language Class Initialized
ERROR - 2018-02-18 20:15:17 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-18 20:15:17 --> Config Class Initialized
INFO - 2018-02-18 20:15:17 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:15:17 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:15:17 --> Utf8 Class Initialized
INFO - 2018-02-18 20:15:17 --> URI Class Initialized
INFO - 2018-02-18 20:15:17 --> Router Class Initialized
INFO - 2018-02-18 20:15:17 --> Output Class Initialized
INFO - 2018-02-18 20:15:17 --> Security Class Initialized
DEBUG - 2018-02-18 20:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:15:17 --> Input Class Initialized
INFO - 2018-02-18 20:15:17 --> Language Class Initialized
INFO - 2018-02-18 20:15:17 --> Loader Class Initialized
INFO - 2018-02-18 20:15:17 --> Helper loaded: url_helper
INFO - 2018-02-18 20:15:17 --> Helper loaded: form_helper
INFO - 2018-02-18 20:15:17 --> Database Driver Class Initialized
DEBUG - 2018-02-18 20:15:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 20:15:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 20:15:17 --> Form Validation Class Initialized
INFO - 2018-02-18 20:15:17 --> Model Class Initialized
INFO - 2018-02-18 20:15:17 --> Controller Class Initialized
INFO - 2018-02-18 20:15:17 --> Model Class Initialized
INFO - 2018-02-18 20:15:17 --> Model Class Initialized
INFO - 2018-02-18 20:15:17 --> Model Class Initialized
INFO - 2018-02-18 20:15:17 --> Model Class Initialized
INFO - 2018-02-18 20:15:17 --> Model Class Initialized
DEBUG - 2018-02-18 20:15:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 20:15:26 --> Config Class Initialized
INFO - 2018-02-18 20:15:26 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:15:26 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:15:26 --> Utf8 Class Initialized
INFO - 2018-02-18 20:15:26 --> URI Class Initialized
INFO - 2018-02-18 20:15:26 --> Router Class Initialized
INFO - 2018-02-18 20:15:26 --> Output Class Initialized
INFO - 2018-02-18 20:15:26 --> Security Class Initialized
DEBUG - 2018-02-18 20:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:15:26 --> Input Class Initialized
INFO - 2018-02-18 20:15:26 --> Language Class Initialized
INFO - 2018-02-18 20:15:26 --> Loader Class Initialized
INFO - 2018-02-18 20:15:26 --> Helper loaded: url_helper
INFO - 2018-02-18 20:15:26 --> Helper loaded: form_helper
INFO - 2018-02-18 20:15:26 --> Database Driver Class Initialized
DEBUG - 2018-02-18 20:15:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 20:15:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 20:15:26 --> Form Validation Class Initialized
INFO - 2018-02-18 20:15:26 --> Model Class Initialized
INFO - 2018-02-18 20:15:26 --> Controller Class Initialized
INFO - 2018-02-18 20:15:26 --> Model Class Initialized
INFO - 2018-02-18 20:15:26 --> Model Class Initialized
INFO - 2018-02-18 20:15:26 --> Model Class Initialized
INFO - 2018-02-18 20:15:26 --> Model Class Initialized
INFO - 2018-02-18 20:15:26 --> Model Class Initialized
DEBUG - 2018-02-18 20:15:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 20:15:26 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 20:15:26 --> Final output sent to browser
DEBUG - 2018-02-18 20:15:26 --> Total execution time: 0.0603
INFO - 2018-02-18 20:15:26 --> Config Class Initialized
INFO - 2018-02-18 20:15:26 --> Hooks Class Initialized
INFO - 2018-02-18 20:15:26 --> Config Class Initialized
INFO - 2018-02-18 20:15:26 --> Config Class Initialized
INFO - 2018-02-18 20:15:26 --> Hooks Class Initialized
INFO - 2018-02-18 20:15:26 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:15:26 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:15:26 --> Utf8 Class Initialized
INFO - 2018-02-18 20:15:26 --> URI Class Initialized
DEBUG - 2018-02-18 20:15:26 --> UTF-8 Support Enabled
DEBUG - 2018-02-18 20:15:26 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:15:26 --> Utf8 Class Initialized
INFO - 2018-02-18 20:15:26 --> Utf8 Class Initialized
INFO - 2018-02-18 20:15:26 --> Router Class Initialized
INFO - 2018-02-18 20:15:26 --> URI Class Initialized
INFO - 2018-02-18 20:15:26 --> URI Class Initialized
INFO - 2018-02-18 20:15:26 --> Output Class Initialized
INFO - 2018-02-18 20:15:26 --> Router Class Initialized
INFO - 2018-02-18 20:15:26 --> Router Class Initialized
INFO - 2018-02-18 20:15:26 --> Security Class Initialized
INFO - 2018-02-18 20:15:26 --> Output Class Initialized
DEBUG - 2018-02-18 20:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:15:26 --> Input Class Initialized
INFO - 2018-02-18 20:15:26 --> Output Class Initialized
INFO - 2018-02-18 20:15:26 --> Security Class Initialized
INFO - 2018-02-18 20:15:26 --> Language Class Initialized
INFO - 2018-02-18 20:15:26 --> Security Class Initialized
DEBUG - 2018-02-18 20:15:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-18 20:15:26 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-18 20:15:26 --> Input Class Initialized
DEBUG - 2018-02-18 20:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:15:26 --> Input Class Initialized
INFO - 2018-02-18 20:15:26 --> Language Class Initialized
INFO - 2018-02-18 20:15:26 --> Language Class Initialized
ERROR - 2018-02-18 20:15:26 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-18 20:15:26 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-18 20:15:26 --> Config Class Initialized
INFO - 2018-02-18 20:15:26 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:15:26 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:15:26 --> Utf8 Class Initialized
INFO - 2018-02-18 20:15:26 --> URI Class Initialized
INFO - 2018-02-18 20:15:26 --> Router Class Initialized
INFO - 2018-02-18 20:15:26 --> Output Class Initialized
INFO - 2018-02-18 20:15:26 --> Security Class Initialized
DEBUG - 2018-02-18 20:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:15:26 --> Input Class Initialized
INFO - 2018-02-18 20:15:26 --> Language Class Initialized
ERROR - 2018-02-18 20:15:26 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-18 20:15:26 --> Config Class Initialized
INFO - 2018-02-18 20:15:26 --> Hooks Class Initialized
INFO - 2018-02-18 20:15:26 --> Config Class Initialized
INFO - 2018-02-18 20:15:26 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:15:26 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:15:26 --> Utf8 Class Initialized
INFO - 2018-02-18 20:15:26 --> Config Class Initialized
INFO - 2018-02-18 20:15:26 --> Hooks Class Initialized
INFO - 2018-02-18 20:15:26 --> URI Class Initialized
DEBUG - 2018-02-18 20:15:26 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:15:26 --> Utf8 Class Initialized
INFO - 2018-02-18 20:15:26 --> Router Class Initialized
INFO - 2018-02-18 20:15:26 --> URI Class Initialized
DEBUG - 2018-02-18 20:15:26 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:15:26 --> Utf8 Class Initialized
INFO - 2018-02-18 20:15:26 --> Output Class Initialized
INFO - 2018-02-18 20:15:26 --> URI Class Initialized
INFO - 2018-02-18 20:15:26 --> Router Class Initialized
INFO - 2018-02-18 20:15:26 --> Security Class Initialized
INFO - 2018-02-18 20:15:26 --> Router Class Initialized
INFO - 2018-02-18 20:15:26 --> Output Class Initialized
DEBUG - 2018-02-18 20:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:15:26 --> Input Class Initialized
INFO - 2018-02-18 20:15:26 --> Output Class Initialized
INFO - 2018-02-18 20:15:26 --> Security Class Initialized
INFO - 2018-02-18 20:15:26 --> Language Class Initialized
INFO - 2018-02-18 20:15:26 --> Security Class Initialized
DEBUG - 2018-02-18 20:15:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-18 20:15:26 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-18 20:15:26 --> Input Class Initialized
DEBUG - 2018-02-18 20:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:15:26 --> Input Class Initialized
INFO - 2018-02-18 20:15:26 --> Language Class Initialized
INFO - 2018-02-18 20:15:26 --> Language Class Initialized
ERROR - 2018-02-18 20:15:26 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-18 20:15:26 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-18 20:15:26 --> Config Class Initialized
INFO - 2018-02-18 20:15:26 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:15:26 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:15:26 --> Utf8 Class Initialized
INFO - 2018-02-18 20:15:26 --> URI Class Initialized
INFO - 2018-02-18 20:15:26 --> Router Class Initialized
INFO - 2018-02-18 20:15:26 --> Output Class Initialized
INFO - 2018-02-18 20:15:26 --> Security Class Initialized
DEBUG - 2018-02-18 20:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:15:26 --> Input Class Initialized
INFO - 2018-02-18 20:15:26 --> Language Class Initialized
INFO - 2018-02-18 20:15:26 --> Loader Class Initialized
INFO - 2018-02-18 20:15:26 --> Helper loaded: url_helper
INFO - 2018-02-18 20:15:26 --> Helper loaded: form_helper
INFO - 2018-02-18 20:15:26 --> Database Driver Class Initialized
DEBUG - 2018-02-18 20:15:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 20:15:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 20:15:26 --> Form Validation Class Initialized
INFO - 2018-02-18 20:15:26 --> Model Class Initialized
INFO - 2018-02-18 20:15:26 --> Controller Class Initialized
INFO - 2018-02-18 20:15:26 --> Model Class Initialized
INFO - 2018-02-18 20:15:26 --> Model Class Initialized
INFO - 2018-02-18 20:15:26 --> Model Class Initialized
INFO - 2018-02-18 20:15:26 --> Model Class Initialized
INFO - 2018-02-18 20:15:26 --> Model Class Initialized
DEBUG - 2018-02-18 20:15:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 20:15:55 --> Config Class Initialized
INFO - 2018-02-18 20:15:55 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:15:55 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:15:55 --> Utf8 Class Initialized
INFO - 2018-02-18 20:15:55 --> URI Class Initialized
INFO - 2018-02-18 20:15:55 --> Router Class Initialized
INFO - 2018-02-18 20:15:55 --> Output Class Initialized
INFO - 2018-02-18 20:15:55 --> Security Class Initialized
DEBUG - 2018-02-18 20:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:15:55 --> Input Class Initialized
INFO - 2018-02-18 20:15:55 --> Language Class Initialized
INFO - 2018-02-18 20:15:55 --> Loader Class Initialized
INFO - 2018-02-18 20:15:55 --> Helper loaded: url_helper
INFO - 2018-02-18 20:15:55 --> Helper loaded: form_helper
INFO - 2018-02-18 20:15:55 --> Database Driver Class Initialized
DEBUG - 2018-02-18 20:15:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 20:15:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 20:15:55 --> Form Validation Class Initialized
INFO - 2018-02-18 20:15:55 --> Model Class Initialized
INFO - 2018-02-18 20:15:55 --> Controller Class Initialized
INFO - 2018-02-18 20:15:55 --> Model Class Initialized
INFO - 2018-02-18 20:15:55 --> Model Class Initialized
INFO - 2018-02-18 20:15:55 --> Model Class Initialized
INFO - 2018-02-18 20:15:55 --> Model Class Initialized
INFO - 2018-02-18 20:15:55 --> Model Class Initialized
DEBUG - 2018-02-18 20:15:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 20:15:55 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 20:15:55 --> Final output sent to browser
DEBUG - 2018-02-18 20:15:55 --> Total execution time: 0.0818
INFO - 2018-02-18 20:15:55 --> Config Class Initialized
INFO - 2018-02-18 20:15:55 --> Config Class Initialized
INFO - 2018-02-18 20:15:55 --> Hooks Class Initialized
INFO - 2018-02-18 20:15:55 --> Hooks Class Initialized
INFO - 2018-02-18 20:15:55 --> Config Class Initialized
INFO - 2018-02-18 20:15:55 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:15:55 --> UTF-8 Support Enabled
DEBUG - 2018-02-18 20:15:55 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:15:55 --> Utf8 Class Initialized
INFO - 2018-02-18 20:15:55 --> Utf8 Class Initialized
INFO - 2018-02-18 20:15:55 --> URI Class Initialized
INFO - 2018-02-18 20:15:55 --> URI Class Initialized
DEBUG - 2018-02-18 20:15:55 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:15:55 --> Utf8 Class Initialized
INFO - 2018-02-18 20:15:55 --> Router Class Initialized
INFO - 2018-02-18 20:15:55 --> Router Class Initialized
INFO - 2018-02-18 20:15:55 --> URI Class Initialized
INFO - 2018-02-18 20:15:55 --> Output Class Initialized
INFO - 2018-02-18 20:15:55 --> Output Class Initialized
INFO - 2018-02-18 20:15:55 --> Router Class Initialized
INFO - 2018-02-18 20:15:55 --> Security Class Initialized
INFO - 2018-02-18 20:15:55 --> Security Class Initialized
INFO - 2018-02-18 20:15:55 --> Output Class Initialized
DEBUG - 2018-02-18 20:15:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-18 20:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:15:55 --> Input Class Initialized
INFO - 2018-02-18 20:15:55 --> Input Class Initialized
INFO - 2018-02-18 20:15:55 --> Security Class Initialized
INFO - 2018-02-18 20:15:55 --> Language Class Initialized
INFO - 2018-02-18 20:15:55 --> Language Class Initialized
DEBUG - 2018-02-18 20:15:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-18 20:15:55 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-18 20:15:55 --> Input Class Initialized
ERROR - 2018-02-18 20:15:55 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-18 20:15:55 --> Language Class Initialized
ERROR - 2018-02-18 20:15:55 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-18 20:15:55 --> Config Class Initialized
INFO - 2018-02-18 20:15:55 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:15:55 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:15:55 --> Utf8 Class Initialized
INFO - 2018-02-18 20:15:55 --> URI Class Initialized
INFO - 2018-02-18 20:15:55 --> Router Class Initialized
INFO - 2018-02-18 20:15:55 --> Output Class Initialized
INFO - 2018-02-18 20:15:55 --> Security Class Initialized
DEBUG - 2018-02-18 20:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:15:55 --> Input Class Initialized
INFO - 2018-02-18 20:15:55 --> Language Class Initialized
ERROR - 2018-02-18 20:15:55 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-18 20:15:56 --> Config Class Initialized
INFO - 2018-02-18 20:15:56 --> Hooks Class Initialized
INFO - 2018-02-18 20:15:56 --> Config Class Initialized
INFO - 2018-02-18 20:15:56 --> Hooks Class Initialized
INFO - 2018-02-18 20:15:56 --> Config Class Initialized
INFO - 2018-02-18 20:15:56 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:15:56 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:15:56 --> Utf8 Class Initialized
INFO - 2018-02-18 20:15:56 --> URI Class Initialized
DEBUG - 2018-02-18 20:15:56 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:15:56 --> Utf8 Class Initialized
DEBUG - 2018-02-18 20:15:56 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:15:56 --> Utf8 Class Initialized
INFO - 2018-02-18 20:15:56 --> URI Class Initialized
INFO - 2018-02-18 20:15:56 --> URI Class Initialized
INFO - 2018-02-18 20:15:56 --> Router Class Initialized
INFO - 2018-02-18 20:15:56 --> Router Class Initialized
INFO - 2018-02-18 20:15:56 --> Router Class Initialized
INFO - 2018-02-18 20:15:56 --> Output Class Initialized
INFO - 2018-02-18 20:15:56 --> Security Class Initialized
INFO - 2018-02-18 20:15:56 --> Output Class Initialized
INFO - 2018-02-18 20:15:56 --> Output Class Initialized
DEBUG - 2018-02-18 20:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:15:56 --> Security Class Initialized
INFO - 2018-02-18 20:15:56 --> Input Class Initialized
INFO - 2018-02-18 20:15:56 --> Security Class Initialized
INFO - 2018-02-18 20:15:56 --> Language Class Initialized
DEBUG - 2018-02-18 20:15:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-18 20:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:15:56 --> Input Class Initialized
ERROR - 2018-02-18 20:15:56 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-18 20:15:56 --> Input Class Initialized
INFO - 2018-02-18 20:15:56 --> Language Class Initialized
INFO - 2018-02-18 20:15:56 --> Language Class Initialized
ERROR - 2018-02-18 20:15:56 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-18 20:15:56 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-18 20:16:00 --> Config Class Initialized
INFO - 2018-02-18 20:16:00 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:16:00 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:16:00 --> Utf8 Class Initialized
INFO - 2018-02-18 20:16:00 --> URI Class Initialized
INFO - 2018-02-18 20:16:00 --> Router Class Initialized
INFO - 2018-02-18 20:16:00 --> Output Class Initialized
INFO - 2018-02-18 20:16:00 --> Security Class Initialized
DEBUG - 2018-02-18 20:16:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:16:00 --> Input Class Initialized
INFO - 2018-02-18 20:16:00 --> Language Class Initialized
INFO - 2018-02-18 20:16:00 --> Loader Class Initialized
INFO - 2018-02-18 20:16:00 --> Helper loaded: url_helper
INFO - 2018-02-18 20:16:00 --> Helper loaded: form_helper
INFO - 2018-02-18 20:16:00 --> Database Driver Class Initialized
DEBUG - 2018-02-18 20:16:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 20:16:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 20:16:00 --> Form Validation Class Initialized
INFO - 2018-02-18 20:16:00 --> Model Class Initialized
INFO - 2018-02-18 20:16:00 --> Controller Class Initialized
INFO - 2018-02-18 20:16:00 --> Model Class Initialized
INFO - 2018-02-18 20:16:00 --> Model Class Initialized
INFO - 2018-02-18 20:16:00 --> Model Class Initialized
INFO - 2018-02-18 20:16:00 --> Model Class Initialized
INFO - 2018-02-18 20:16:00 --> Model Class Initialized
DEBUG - 2018-02-18 20:16:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 20:16:00 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 20:16:00 --> Final output sent to browser
DEBUG - 2018-02-18 20:16:00 --> Total execution time: 0.0689
INFO - 2018-02-18 20:16:01 --> Config Class Initialized
INFO - 2018-02-18 20:16:01 --> Config Class Initialized
INFO - 2018-02-18 20:16:01 --> Hooks Class Initialized
INFO - 2018-02-18 20:16:01 --> Hooks Class Initialized
INFO - 2018-02-18 20:16:01 --> Config Class Initialized
INFO - 2018-02-18 20:16:01 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:16:01 --> UTF-8 Support Enabled
DEBUG - 2018-02-18 20:16:01 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:16:01 --> Utf8 Class Initialized
INFO - 2018-02-18 20:16:01 --> Utf8 Class Initialized
INFO - 2018-02-18 20:16:01 --> URI Class Initialized
INFO - 2018-02-18 20:16:01 --> URI Class Initialized
DEBUG - 2018-02-18 20:16:01 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:16:01 --> Utf8 Class Initialized
INFO - 2018-02-18 20:16:01 --> Router Class Initialized
INFO - 2018-02-18 20:16:01 --> Router Class Initialized
INFO - 2018-02-18 20:16:01 --> URI Class Initialized
INFO - 2018-02-18 20:16:01 --> Output Class Initialized
INFO - 2018-02-18 20:16:01 --> Router Class Initialized
INFO - 2018-02-18 20:16:01 --> Output Class Initialized
INFO - 2018-02-18 20:16:01 --> Security Class Initialized
INFO - 2018-02-18 20:16:01 --> Output Class Initialized
INFO - 2018-02-18 20:16:01 --> Security Class Initialized
DEBUG - 2018-02-18 20:16:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:16:01 --> Input Class Initialized
INFO - 2018-02-18 20:16:01 --> Security Class Initialized
INFO - 2018-02-18 20:16:01 --> Language Class Initialized
DEBUG - 2018-02-18 20:16:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:16:01 --> Input Class Initialized
DEBUG - 2018-02-18 20:16:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:16:01 --> Input Class Initialized
ERROR - 2018-02-18 20:16:01 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-18 20:16:01 --> Language Class Initialized
INFO - 2018-02-18 20:16:01 --> Language Class Initialized
ERROR - 2018-02-18 20:16:01 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-18 20:16:01 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-18 20:16:01 --> Config Class Initialized
INFO - 2018-02-18 20:16:01 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:16:01 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:16:01 --> Utf8 Class Initialized
INFO - 2018-02-18 20:16:01 --> URI Class Initialized
INFO - 2018-02-18 20:16:01 --> Router Class Initialized
INFO - 2018-02-18 20:16:01 --> Output Class Initialized
INFO - 2018-02-18 20:16:01 --> Security Class Initialized
DEBUG - 2018-02-18 20:16:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:16:01 --> Input Class Initialized
INFO - 2018-02-18 20:16:01 --> Language Class Initialized
ERROR - 2018-02-18 20:16:01 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-18 20:16:01 --> Config Class Initialized
INFO - 2018-02-18 20:16:01 --> Hooks Class Initialized
INFO - 2018-02-18 20:16:01 --> Config Class Initialized
INFO - 2018-02-18 20:16:01 --> Hooks Class Initialized
INFO - 2018-02-18 20:16:01 --> Config Class Initialized
INFO - 2018-02-18 20:16:01 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:16:01 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:16:01 --> Utf8 Class Initialized
DEBUG - 2018-02-18 20:16:01 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:16:01 --> Utf8 Class Initialized
INFO - 2018-02-18 20:16:01 --> URI Class Initialized
DEBUG - 2018-02-18 20:16:01 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:16:01 --> Utf8 Class Initialized
INFO - 2018-02-18 20:16:01 --> URI Class Initialized
INFO - 2018-02-18 20:16:01 --> URI Class Initialized
INFO - 2018-02-18 20:16:01 --> Router Class Initialized
INFO - 2018-02-18 20:16:01 --> Router Class Initialized
INFO - 2018-02-18 20:16:01 --> Router Class Initialized
INFO - 2018-02-18 20:16:01 --> Output Class Initialized
INFO - 2018-02-18 20:16:01 --> Output Class Initialized
INFO - 2018-02-18 20:16:01 --> Output Class Initialized
INFO - 2018-02-18 20:16:01 --> Security Class Initialized
INFO - 2018-02-18 20:16:01 --> Security Class Initialized
INFO - 2018-02-18 20:16:01 --> Security Class Initialized
DEBUG - 2018-02-18 20:16:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-18 20:16:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:16:01 --> Input Class Initialized
INFO - 2018-02-18 20:16:01 --> Input Class Initialized
DEBUG - 2018-02-18 20:16:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:16:01 --> Input Class Initialized
INFO - 2018-02-18 20:16:01 --> Language Class Initialized
INFO - 2018-02-18 20:16:01 --> Language Class Initialized
INFO - 2018-02-18 20:16:01 --> Language Class Initialized
ERROR - 2018-02-18 20:16:01 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-18 20:16:01 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-18 20:16:01 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-18 20:16:01 --> Config Class Initialized
INFO - 2018-02-18 20:16:01 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:16:01 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:16:01 --> Utf8 Class Initialized
INFO - 2018-02-18 20:16:01 --> URI Class Initialized
INFO - 2018-02-18 20:16:01 --> Router Class Initialized
INFO - 2018-02-18 20:16:01 --> Output Class Initialized
INFO - 2018-02-18 20:16:01 --> Security Class Initialized
DEBUG - 2018-02-18 20:16:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:16:01 --> Input Class Initialized
INFO - 2018-02-18 20:16:01 --> Language Class Initialized
INFO - 2018-02-18 20:16:01 --> Loader Class Initialized
INFO - 2018-02-18 20:16:01 --> Helper loaded: url_helper
INFO - 2018-02-18 20:16:01 --> Helper loaded: form_helper
INFO - 2018-02-18 20:16:01 --> Database Driver Class Initialized
DEBUG - 2018-02-18 20:16:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 20:16:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 20:16:01 --> Form Validation Class Initialized
INFO - 2018-02-18 20:16:01 --> Model Class Initialized
INFO - 2018-02-18 20:16:01 --> Controller Class Initialized
INFO - 2018-02-18 20:16:01 --> Model Class Initialized
INFO - 2018-02-18 20:16:01 --> Model Class Initialized
INFO - 2018-02-18 20:16:01 --> Model Class Initialized
INFO - 2018-02-18 20:16:01 --> Model Class Initialized
INFO - 2018-02-18 20:16:01 --> Model Class Initialized
DEBUG - 2018-02-18 20:16:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 20:17:29 --> Config Class Initialized
INFO - 2018-02-18 20:17:29 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:17:29 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:17:29 --> Utf8 Class Initialized
INFO - 2018-02-18 20:17:29 --> URI Class Initialized
INFO - 2018-02-18 20:17:29 --> Router Class Initialized
INFO - 2018-02-18 20:17:29 --> Output Class Initialized
INFO - 2018-02-18 20:17:29 --> Security Class Initialized
DEBUG - 2018-02-18 20:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:17:29 --> Input Class Initialized
INFO - 2018-02-18 20:17:29 --> Language Class Initialized
INFO - 2018-02-18 20:17:29 --> Loader Class Initialized
INFO - 2018-02-18 20:17:29 --> Helper loaded: url_helper
INFO - 2018-02-18 20:17:29 --> Helper loaded: form_helper
INFO - 2018-02-18 20:17:29 --> Database Driver Class Initialized
DEBUG - 2018-02-18 20:17:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 20:17:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 20:17:29 --> Form Validation Class Initialized
INFO - 2018-02-18 20:17:29 --> Model Class Initialized
INFO - 2018-02-18 20:17:29 --> Controller Class Initialized
INFO - 2018-02-18 20:17:29 --> Model Class Initialized
INFO - 2018-02-18 20:17:29 --> Model Class Initialized
INFO - 2018-02-18 20:17:29 --> Model Class Initialized
INFO - 2018-02-18 20:17:29 --> Model Class Initialized
INFO - 2018-02-18 20:17:29 --> Model Class Initialized
DEBUG - 2018-02-18 20:17:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-18 20:17:29 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-18 20:17:29 --> Final output sent to browser
DEBUG - 2018-02-18 20:17:29 --> Total execution time: 0.0728
INFO - 2018-02-18 20:17:29 --> Config Class Initialized
INFO - 2018-02-18 20:17:29 --> Hooks Class Initialized
INFO - 2018-02-18 20:17:29 --> Config Class Initialized
INFO - 2018-02-18 20:17:29 --> Hooks Class Initialized
INFO - 2018-02-18 20:17:29 --> Config Class Initialized
INFO - 2018-02-18 20:17:29 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:17:29 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:17:29 --> Utf8 Class Initialized
DEBUG - 2018-02-18 20:17:29 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:17:29 --> Utf8 Class Initialized
INFO - 2018-02-18 20:17:29 --> Config Class Initialized
INFO - 2018-02-18 20:17:29 --> URI Class Initialized
INFO - 2018-02-18 20:17:29 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:17:29 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:17:29 --> URI Class Initialized
INFO - 2018-02-18 20:17:29 --> Utf8 Class Initialized
INFO - 2018-02-18 20:17:29 --> Router Class Initialized
INFO - 2018-02-18 20:17:29 --> URI Class Initialized
INFO - 2018-02-18 20:17:29 --> Router Class Initialized
DEBUG - 2018-02-18 20:17:29 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:17:29 --> Output Class Initialized
INFO - 2018-02-18 20:17:29 --> Utf8 Class Initialized
INFO - 2018-02-18 20:17:29 --> Router Class Initialized
INFO - 2018-02-18 20:17:29 --> Output Class Initialized
INFO - 2018-02-18 20:17:29 --> URI Class Initialized
INFO - 2018-02-18 20:17:29 --> Security Class Initialized
INFO - 2018-02-18 20:17:29 --> Output Class Initialized
INFO - 2018-02-18 20:17:29 --> Security Class Initialized
DEBUG - 2018-02-18 20:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:17:29 --> Router Class Initialized
INFO - 2018-02-18 20:17:29 --> Input Class Initialized
DEBUG - 2018-02-18 20:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:17:29 --> Security Class Initialized
INFO - 2018-02-18 20:17:29 --> Input Class Initialized
INFO - 2018-02-18 20:17:29 --> Language Class Initialized
DEBUG - 2018-02-18 20:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:17:29 --> Language Class Initialized
INFO - 2018-02-18 20:17:29 --> Output Class Initialized
INFO - 2018-02-18 20:17:29 --> Input Class Initialized
ERROR - 2018-02-18 20:17:29 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-18 20:17:29 --> Language Class Initialized
ERROR - 2018-02-18 20:17:29 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-18 20:17:29 --> Security Class Initialized
ERROR - 2018-02-18 20:17:29 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-02-18 20:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:17:29 --> Input Class Initialized
INFO - 2018-02-18 20:17:29 --> Language Class Initialized
ERROR - 2018-02-18 20:17:29 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-18 20:17:29 --> Config Class Initialized
INFO - 2018-02-18 20:17:29 --> Hooks Class Initialized
INFO - 2018-02-18 20:17:29 --> Config Class Initialized
INFO - 2018-02-18 20:17:29 --> Hooks Class Initialized
INFO - 2018-02-18 20:17:29 --> Config Class Initialized
INFO - 2018-02-18 20:17:29 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:17:29 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:17:29 --> Utf8 Class Initialized
DEBUG - 2018-02-18 20:17:29 --> UTF-8 Support Enabled
DEBUG - 2018-02-18 20:17:29 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:17:29 --> Utf8 Class Initialized
INFO - 2018-02-18 20:17:29 --> Utf8 Class Initialized
INFO - 2018-02-18 20:17:29 --> URI Class Initialized
INFO - 2018-02-18 20:17:29 --> URI Class Initialized
INFO - 2018-02-18 20:17:29 --> URI Class Initialized
INFO - 2018-02-18 20:17:29 --> Router Class Initialized
INFO - 2018-02-18 20:17:29 --> Router Class Initialized
INFO - 2018-02-18 20:17:29 --> Router Class Initialized
INFO - 2018-02-18 20:17:29 --> Output Class Initialized
INFO - 2018-02-18 20:17:29 --> Output Class Initialized
INFO - 2018-02-18 20:17:29 --> Security Class Initialized
INFO - 2018-02-18 20:17:29 --> Output Class Initialized
INFO - 2018-02-18 20:17:29 --> Security Class Initialized
DEBUG - 2018-02-18 20:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:17:29 --> Input Class Initialized
INFO - 2018-02-18 20:17:29 --> Security Class Initialized
INFO - 2018-02-18 20:17:29 --> Language Class Initialized
DEBUG - 2018-02-18 20:17:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-18 20:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:17:29 --> Input Class Initialized
INFO - 2018-02-18 20:17:29 --> Input Class Initialized
ERROR - 2018-02-18 20:17:29 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-18 20:17:29 --> Language Class Initialized
INFO - 2018-02-18 20:17:29 --> Language Class Initialized
ERROR - 2018-02-18 20:17:29 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-18 20:17:29 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-18 20:17:29 --> Config Class Initialized
INFO - 2018-02-18 20:17:29 --> Hooks Class Initialized
DEBUG - 2018-02-18 20:17:29 --> UTF-8 Support Enabled
INFO - 2018-02-18 20:17:29 --> Utf8 Class Initialized
INFO - 2018-02-18 20:17:29 --> URI Class Initialized
INFO - 2018-02-18 20:17:29 --> Router Class Initialized
INFO - 2018-02-18 20:17:29 --> Output Class Initialized
INFO - 2018-02-18 20:17:29 --> Security Class Initialized
DEBUG - 2018-02-18 20:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-18 20:17:29 --> Input Class Initialized
INFO - 2018-02-18 20:17:29 --> Language Class Initialized
INFO - 2018-02-18 20:17:29 --> Loader Class Initialized
INFO - 2018-02-18 20:17:29 --> Helper loaded: url_helper
INFO - 2018-02-18 20:17:29 --> Helper loaded: form_helper
INFO - 2018-02-18 20:17:29 --> Database Driver Class Initialized
DEBUG - 2018-02-18 20:17:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-18 20:17:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-18 20:17:29 --> Form Validation Class Initialized
INFO - 2018-02-18 20:17:29 --> Model Class Initialized
INFO - 2018-02-18 20:17:29 --> Controller Class Initialized
INFO - 2018-02-18 20:17:29 --> Model Class Initialized
INFO - 2018-02-18 20:17:29 --> Model Class Initialized
INFO - 2018-02-18 20:17:29 --> Model Class Initialized
INFO - 2018-02-18 20:17:29 --> Model Class Initialized
INFO - 2018-02-18 20:17:29 --> Model Class Initialized
DEBUG - 2018-02-18 20:17:29 --> Form_validation class already loaded. Second attempt ignored.
