<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-01-23 07:07:49 --> Config Class Initialized
INFO - 2018-01-23 07:07:49 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:07:49 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:07:49 --> Utf8 Class Initialized
INFO - 2018-01-23 07:07:49 --> URI Class Initialized
DEBUG - 2018-01-23 07:07:49 --> No URI present. Default controller set.
INFO - 2018-01-23 07:07:49 --> Router Class Initialized
INFO - 2018-01-23 07:07:49 --> Output Class Initialized
INFO - 2018-01-23 07:07:49 --> Security Class Initialized
DEBUG - 2018-01-23 07:07:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:07:49 --> Input Class Initialized
INFO - 2018-01-23 07:07:49 --> Language Class Initialized
INFO - 2018-01-23 07:07:49 --> Loader Class Initialized
INFO - 2018-01-23 07:07:49 --> Helper loaded: url_helper
INFO - 2018-01-23 07:07:49 --> Helper loaded: form_helper
INFO - 2018-01-23 07:07:49 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:07:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:07:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:07:49 --> Form Validation Class Initialized
INFO - 2018-01-23 07:07:49 --> Model Class Initialized
INFO - 2018-01-23 07:07:49 --> Controller Class Initialized
INFO - 2018-01-23 07:07:49 --> Config Class Initialized
INFO - 2018-01-23 07:07:49 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:07:49 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:07:49 --> Utf8 Class Initialized
INFO - 2018-01-23 07:07:49 --> URI Class Initialized
INFO - 2018-01-23 07:07:49 --> Router Class Initialized
INFO - 2018-01-23 07:07:49 --> Output Class Initialized
INFO - 2018-01-23 07:07:49 --> Security Class Initialized
DEBUG - 2018-01-23 07:07:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:07:49 --> Input Class Initialized
INFO - 2018-01-23 07:07:49 --> Language Class Initialized
INFO - 2018-01-23 07:07:49 --> Loader Class Initialized
INFO - 2018-01-23 07:07:49 --> Helper loaded: url_helper
INFO - 2018-01-23 07:07:49 --> Helper loaded: form_helper
INFO - 2018-01-23 07:07:49 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:07:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:07:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:07:49 --> Form Validation Class Initialized
INFO - 2018-01-23 07:07:49 --> Model Class Initialized
INFO - 2018-01-23 07:07:49 --> Controller Class Initialized
INFO - 2018-01-23 07:07:49 --> Model Class Initialized
DEBUG - 2018-01-23 07:07:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:07:49 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-23 07:07:49 --> Final output sent to browser
DEBUG - 2018-01-23 07:07:49 --> Total execution time: 0.0402
INFO - 2018-01-23 07:11:46 --> Config Class Initialized
INFO - 2018-01-23 07:11:46 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:11:46 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:11:46 --> Utf8 Class Initialized
INFO - 2018-01-23 07:11:46 --> URI Class Initialized
INFO - 2018-01-23 07:11:46 --> Router Class Initialized
INFO - 2018-01-23 07:11:46 --> Output Class Initialized
INFO - 2018-01-23 07:11:46 --> Security Class Initialized
DEBUG - 2018-01-23 07:11:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:11:46 --> Input Class Initialized
INFO - 2018-01-23 07:11:46 --> Language Class Initialized
INFO - 2018-01-23 07:11:46 --> Loader Class Initialized
INFO - 2018-01-23 07:11:46 --> Helper loaded: url_helper
INFO - 2018-01-23 07:11:46 --> Helper loaded: form_helper
INFO - 2018-01-23 07:11:46 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:11:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:11:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:11:46 --> Form Validation Class Initialized
INFO - 2018-01-23 07:11:46 --> Model Class Initialized
INFO - 2018-01-23 07:11:46 --> Controller Class Initialized
INFO - 2018-01-23 07:11:46 --> Model Class Initialized
INFO - 2018-01-23 07:11:46 --> Model Class Initialized
DEBUG - 2018-01-23 07:11:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:11:46 --> Config Class Initialized
INFO - 2018-01-23 07:11:46 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:11:46 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:11:46 --> Utf8 Class Initialized
INFO - 2018-01-23 07:11:46 --> URI Class Initialized
INFO - 2018-01-23 07:11:46 --> Router Class Initialized
INFO - 2018-01-23 07:11:46 --> Output Class Initialized
INFO - 2018-01-23 07:11:46 --> Security Class Initialized
DEBUG - 2018-01-23 07:11:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:11:46 --> Input Class Initialized
INFO - 2018-01-23 07:11:46 --> Language Class Initialized
INFO - 2018-01-23 07:11:46 --> Loader Class Initialized
INFO - 2018-01-23 07:11:46 --> Helper loaded: url_helper
INFO - 2018-01-23 07:11:46 --> Helper loaded: form_helper
INFO - 2018-01-23 07:11:46 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:11:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:11:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:11:46 --> Form Validation Class Initialized
INFO - 2018-01-23 07:11:46 --> Model Class Initialized
INFO - 2018-01-23 07:11:46 --> Controller Class Initialized
INFO - 2018-01-23 07:11:46 --> Model Class Initialized
DEBUG - 2018-01-23 07:11:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:11:46 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-23 07:11:46 --> Final output sent to browser
DEBUG - 2018-01-23 07:11:46 --> Total execution time: 0.0421
INFO - 2018-01-23 07:11:50 --> Config Class Initialized
INFO - 2018-01-23 07:11:50 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:11:50 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:11:50 --> Utf8 Class Initialized
INFO - 2018-01-23 07:11:50 --> URI Class Initialized
INFO - 2018-01-23 07:11:50 --> Router Class Initialized
INFO - 2018-01-23 07:11:50 --> Output Class Initialized
INFO - 2018-01-23 07:11:50 --> Security Class Initialized
DEBUG - 2018-01-23 07:11:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:11:50 --> Input Class Initialized
INFO - 2018-01-23 07:11:50 --> Language Class Initialized
INFO - 2018-01-23 07:11:50 --> Loader Class Initialized
INFO - 2018-01-23 07:11:50 --> Helper loaded: url_helper
INFO - 2018-01-23 07:11:50 --> Helper loaded: form_helper
INFO - 2018-01-23 07:11:50 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:11:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:11:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:11:50 --> Form Validation Class Initialized
INFO - 2018-01-23 07:11:50 --> Model Class Initialized
INFO - 2018-01-23 07:11:50 --> Controller Class Initialized
INFO - 2018-01-23 07:11:50 --> Model Class Initialized
DEBUG - 2018-01-23 07:11:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:11:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-01-23 07:11:50 --> Config Class Initialized
INFO - 2018-01-23 07:11:50 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:11:50 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:11:50 --> Utf8 Class Initialized
INFO - 2018-01-23 07:11:50 --> URI Class Initialized
DEBUG - 2018-01-23 07:11:50 --> No URI present. Default controller set.
INFO - 2018-01-23 07:11:50 --> Router Class Initialized
INFO - 2018-01-23 07:11:50 --> Output Class Initialized
INFO - 2018-01-23 07:11:50 --> Security Class Initialized
DEBUG - 2018-01-23 07:11:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:11:50 --> Input Class Initialized
INFO - 2018-01-23 07:11:50 --> Language Class Initialized
INFO - 2018-01-23 07:11:50 --> Loader Class Initialized
INFO - 2018-01-23 07:11:50 --> Helper loaded: url_helper
INFO - 2018-01-23 07:11:50 --> Helper loaded: form_helper
INFO - 2018-01-23 07:11:50 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:11:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:11:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:11:50 --> Form Validation Class Initialized
INFO - 2018-01-23 07:11:50 --> Model Class Initialized
INFO - 2018-01-23 07:11:50 --> Controller Class Initialized
INFO - 2018-01-23 07:11:50 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-23 07:11:50 --> Final output sent to browser
DEBUG - 2018-01-23 07:11:50 --> Total execution time: 0.0384
INFO - 2018-01-23 07:11:50 --> Config Class Initialized
INFO - 2018-01-23 07:11:50 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:11:50 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:11:50 --> Utf8 Class Initialized
INFO - 2018-01-23 07:11:50 --> URI Class Initialized
INFO - 2018-01-23 07:11:50 --> Router Class Initialized
INFO - 2018-01-23 07:11:50 --> Output Class Initialized
INFO - 2018-01-23 07:11:50 --> Security Class Initialized
DEBUG - 2018-01-23 07:11:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:11:50 --> Input Class Initialized
INFO - 2018-01-23 07:11:50 --> Language Class Initialized
INFO - 2018-01-23 07:11:50 --> Loader Class Initialized
INFO - 2018-01-23 07:11:50 --> Helper loaded: url_helper
INFO - 2018-01-23 07:11:50 --> Helper loaded: form_helper
INFO - 2018-01-23 07:11:50 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:11:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:11:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:11:50 --> Form Validation Class Initialized
INFO - 2018-01-23 07:11:50 --> Model Class Initialized
INFO - 2018-01-23 07:11:50 --> Controller Class Initialized
INFO - 2018-01-23 07:11:50 --> Model Class Initialized
INFO - 2018-01-23 07:11:50 --> Model Class Initialized
INFO - 2018-01-23 07:11:50 --> Model Class Initialized
INFO - 2018-01-23 07:11:50 --> Model Class Initialized
DEBUG - 2018-01-23 07:11:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:11:52 --> Config Class Initialized
INFO - 2018-01-23 07:11:52 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:11:52 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:11:52 --> Utf8 Class Initialized
INFO - 2018-01-23 07:11:52 --> URI Class Initialized
INFO - 2018-01-23 07:11:52 --> Router Class Initialized
INFO - 2018-01-23 07:11:52 --> Output Class Initialized
INFO - 2018-01-23 07:11:52 --> Security Class Initialized
DEBUG - 2018-01-23 07:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:11:52 --> Input Class Initialized
INFO - 2018-01-23 07:11:52 --> Language Class Initialized
INFO - 2018-01-23 07:11:52 --> Loader Class Initialized
INFO - 2018-01-23 07:11:52 --> Helper loaded: url_helper
INFO - 2018-01-23 07:11:52 --> Helper loaded: form_helper
INFO - 2018-01-23 07:11:52 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:11:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:11:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:11:52 --> Form Validation Class Initialized
INFO - 2018-01-23 07:11:52 --> Model Class Initialized
INFO - 2018-01-23 07:11:52 --> Controller Class Initialized
INFO - 2018-01-23 07:11:52 --> Model Class Initialized
DEBUG - 2018-01-23 07:11:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:11:52 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-23 07:11:52 --> Final output sent to browser
DEBUG - 2018-01-23 07:11:52 --> Total execution time: 0.0345
INFO - 2018-01-23 07:11:53 --> Config Class Initialized
INFO - 2018-01-23 07:11:53 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:11:53 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:11:53 --> Utf8 Class Initialized
INFO - 2018-01-23 07:11:53 --> URI Class Initialized
INFO - 2018-01-23 07:11:53 --> Router Class Initialized
INFO - 2018-01-23 07:11:53 --> Output Class Initialized
INFO - 2018-01-23 07:11:53 --> Security Class Initialized
DEBUG - 2018-01-23 07:11:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:11:53 --> Input Class Initialized
INFO - 2018-01-23 07:11:53 --> Language Class Initialized
INFO - 2018-01-23 07:11:53 --> Loader Class Initialized
INFO - 2018-01-23 07:11:53 --> Helper loaded: url_helper
INFO - 2018-01-23 07:11:53 --> Helper loaded: form_helper
INFO - 2018-01-23 07:11:53 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:11:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:11:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:11:53 --> Form Validation Class Initialized
INFO - 2018-01-23 07:11:53 --> Model Class Initialized
INFO - 2018-01-23 07:11:53 --> Controller Class Initialized
INFO - 2018-01-23 07:11:53 --> Model Class Initialized
DEBUG - 2018-01-23 07:11:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:13:54 --> Config Class Initialized
INFO - 2018-01-23 07:13:54 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:13:55 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:13:55 --> Utf8 Class Initialized
INFO - 2018-01-23 07:13:55 --> URI Class Initialized
INFO - 2018-01-23 07:13:55 --> Router Class Initialized
INFO - 2018-01-23 07:13:55 --> Output Class Initialized
INFO - 2018-01-23 07:13:55 --> Security Class Initialized
DEBUG - 2018-01-23 07:13:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:13:55 --> Input Class Initialized
INFO - 2018-01-23 07:13:55 --> Language Class Initialized
INFO - 2018-01-23 07:13:55 --> Loader Class Initialized
INFO - 2018-01-23 07:13:55 --> Helper loaded: url_helper
INFO - 2018-01-23 07:13:55 --> Helper loaded: form_helper
INFO - 2018-01-23 07:13:55 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:13:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:13:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:13:55 --> Form Validation Class Initialized
INFO - 2018-01-23 07:13:55 --> Model Class Initialized
INFO - 2018-01-23 07:13:55 --> Controller Class Initialized
INFO - 2018-01-23 07:13:55 --> Model Class Initialized
DEBUG - 2018-01-23 07:13:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:13:55 --> Config Class Initialized
INFO - 2018-01-23 07:13:55 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:13:55 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:13:55 --> Utf8 Class Initialized
INFO - 2018-01-23 07:13:55 --> URI Class Initialized
INFO - 2018-01-23 07:13:55 --> Router Class Initialized
INFO - 2018-01-23 07:13:55 --> Output Class Initialized
INFO - 2018-01-23 07:13:55 --> Security Class Initialized
DEBUG - 2018-01-23 07:13:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:13:55 --> Input Class Initialized
INFO - 2018-01-23 07:13:55 --> Language Class Initialized
INFO - 2018-01-23 07:13:55 --> Loader Class Initialized
INFO - 2018-01-23 07:13:55 --> Helper loaded: url_helper
INFO - 2018-01-23 07:13:55 --> Helper loaded: form_helper
INFO - 2018-01-23 07:13:55 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:13:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:13:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:13:55 --> Form Validation Class Initialized
INFO - 2018-01-23 07:13:55 --> Model Class Initialized
INFO - 2018-01-23 07:13:55 --> Controller Class Initialized
INFO - 2018-01-23 07:13:55 --> Model Class Initialized
DEBUG - 2018-01-23 07:13:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:13:55 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-23 07:13:55 --> Final output sent to browser
DEBUG - 2018-01-23 07:13:55 --> Total execution time: 0.0396
INFO - 2018-01-23 07:14:01 --> Config Class Initialized
INFO - 2018-01-23 07:14:01 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:14:01 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:14:01 --> Utf8 Class Initialized
INFO - 2018-01-23 07:14:01 --> URI Class Initialized
INFO - 2018-01-23 07:14:01 --> Router Class Initialized
INFO - 2018-01-23 07:14:01 --> Output Class Initialized
INFO - 2018-01-23 07:14:01 --> Security Class Initialized
DEBUG - 2018-01-23 07:14:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:14:01 --> Input Class Initialized
INFO - 2018-01-23 07:14:01 --> Language Class Initialized
INFO - 2018-01-23 07:14:01 --> Loader Class Initialized
INFO - 2018-01-23 07:14:01 --> Helper loaded: url_helper
INFO - 2018-01-23 07:14:01 --> Helper loaded: form_helper
INFO - 2018-01-23 07:14:01 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:14:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:14:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:14:01 --> Form Validation Class Initialized
INFO - 2018-01-23 07:14:01 --> Model Class Initialized
INFO - 2018-01-23 07:14:01 --> Controller Class Initialized
INFO - 2018-01-23 07:14:01 --> Model Class Initialized
DEBUG - 2018-01-23 07:14:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:14:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-01-23 07:14:01 --> Config Class Initialized
INFO - 2018-01-23 07:14:01 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:14:01 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:14:01 --> Utf8 Class Initialized
INFO - 2018-01-23 07:14:01 --> URI Class Initialized
DEBUG - 2018-01-23 07:14:01 --> No URI present. Default controller set.
INFO - 2018-01-23 07:14:01 --> Router Class Initialized
INFO - 2018-01-23 07:14:01 --> Output Class Initialized
INFO - 2018-01-23 07:14:01 --> Security Class Initialized
DEBUG - 2018-01-23 07:14:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:14:01 --> Input Class Initialized
INFO - 2018-01-23 07:14:01 --> Language Class Initialized
INFO - 2018-01-23 07:14:01 --> Loader Class Initialized
INFO - 2018-01-23 07:14:01 --> Helper loaded: url_helper
INFO - 2018-01-23 07:14:01 --> Helper loaded: form_helper
INFO - 2018-01-23 07:14:01 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:14:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:14:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:14:01 --> Form Validation Class Initialized
INFO - 2018-01-23 07:14:01 --> Model Class Initialized
INFO - 2018-01-23 07:14:01 --> Controller Class Initialized
INFO - 2018-01-23 07:14:01 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-23 07:14:01 --> Final output sent to browser
DEBUG - 2018-01-23 07:14:01 --> Total execution time: 0.0465
INFO - 2018-01-23 07:14:02 --> Config Class Initialized
INFO - 2018-01-23 07:14:02 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:14:02 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:14:02 --> Utf8 Class Initialized
INFO - 2018-01-23 07:14:02 --> URI Class Initialized
INFO - 2018-01-23 07:14:02 --> Router Class Initialized
INFO - 2018-01-23 07:14:02 --> Output Class Initialized
INFO - 2018-01-23 07:14:02 --> Security Class Initialized
DEBUG - 2018-01-23 07:14:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:14:02 --> Input Class Initialized
INFO - 2018-01-23 07:14:02 --> Language Class Initialized
INFO - 2018-01-23 07:14:02 --> Loader Class Initialized
INFO - 2018-01-23 07:14:02 --> Helper loaded: url_helper
INFO - 2018-01-23 07:14:02 --> Helper loaded: form_helper
INFO - 2018-01-23 07:14:02 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:14:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:14:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:14:02 --> Form Validation Class Initialized
INFO - 2018-01-23 07:14:02 --> Model Class Initialized
INFO - 2018-01-23 07:14:02 --> Controller Class Initialized
INFO - 2018-01-23 07:14:02 --> Model Class Initialized
INFO - 2018-01-23 07:14:02 --> Model Class Initialized
INFO - 2018-01-23 07:14:02 --> Model Class Initialized
INFO - 2018-01-23 07:14:02 --> Model Class Initialized
DEBUG - 2018-01-23 07:14:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:14:03 --> Config Class Initialized
INFO - 2018-01-23 07:14:03 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:14:03 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:14:03 --> Utf8 Class Initialized
INFO - 2018-01-23 07:14:03 --> URI Class Initialized
INFO - 2018-01-23 07:14:03 --> Router Class Initialized
INFO - 2018-01-23 07:14:03 --> Output Class Initialized
INFO - 2018-01-23 07:14:03 --> Security Class Initialized
DEBUG - 2018-01-23 07:14:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:14:03 --> Input Class Initialized
INFO - 2018-01-23 07:14:03 --> Language Class Initialized
INFO - 2018-01-23 07:14:03 --> Loader Class Initialized
INFO - 2018-01-23 07:14:03 --> Helper loaded: url_helper
INFO - 2018-01-23 07:14:03 --> Helper loaded: form_helper
INFO - 2018-01-23 07:14:03 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:14:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:14:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:14:03 --> Form Validation Class Initialized
INFO - 2018-01-23 07:14:03 --> Model Class Initialized
INFO - 2018-01-23 07:14:03 --> Controller Class Initialized
INFO - 2018-01-23 07:14:03 --> Model Class Initialized
DEBUG - 2018-01-23 07:14:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:14:03 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-23 07:14:03 --> Final output sent to browser
DEBUG - 2018-01-23 07:14:03 --> Total execution time: 0.0364
INFO - 2018-01-23 07:14:03 --> Config Class Initialized
INFO - 2018-01-23 07:14:03 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:14:03 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:14:03 --> Utf8 Class Initialized
INFO - 2018-01-23 07:14:03 --> URI Class Initialized
INFO - 2018-01-23 07:14:03 --> Router Class Initialized
INFO - 2018-01-23 07:14:03 --> Output Class Initialized
INFO - 2018-01-23 07:14:03 --> Security Class Initialized
DEBUG - 2018-01-23 07:14:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:14:03 --> Input Class Initialized
INFO - 2018-01-23 07:14:03 --> Language Class Initialized
INFO - 2018-01-23 07:14:03 --> Loader Class Initialized
INFO - 2018-01-23 07:14:03 --> Helper loaded: url_helper
INFO - 2018-01-23 07:14:03 --> Helper loaded: form_helper
INFO - 2018-01-23 07:14:03 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:14:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:14:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:14:03 --> Form Validation Class Initialized
INFO - 2018-01-23 07:14:03 --> Model Class Initialized
INFO - 2018-01-23 07:14:03 --> Controller Class Initialized
INFO - 2018-01-23 07:14:03 --> Model Class Initialized
DEBUG - 2018-01-23 07:14:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:15:21 --> Config Class Initialized
INFO - 2018-01-23 07:15:21 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:15:21 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:15:21 --> Utf8 Class Initialized
INFO - 2018-01-23 07:15:21 --> URI Class Initialized
INFO - 2018-01-23 07:15:21 --> Router Class Initialized
INFO - 2018-01-23 07:15:21 --> Output Class Initialized
INFO - 2018-01-23 07:15:21 --> Security Class Initialized
DEBUG - 2018-01-23 07:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:15:21 --> Input Class Initialized
INFO - 2018-01-23 07:15:21 --> Language Class Initialized
INFO - 2018-01-23 07:15:21 --> Loader Class Initialized
INFO - 2018-01-23 07:15:21 --> Helper loaded: url_helper
INFO - 2018-01-23 07:15:21 --> Helper loaded: form_helper
INFO - 2018-01-23 07:15:21 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:15:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:15:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:15:21 --> Form Validation Class Initialized
INFO - 2018-01-23 07:15:21 --> Model Class Initialized
INFO - 2018-01-23 07:15:21 --> Controller Class Initialized
INFO - 2018-01-23 07:15:21 --> Model Class Initialized
DEBUG - 2018-01-23 07:15:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:15:21 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-23 07:15:21 --> Final output sent to browser
DEBUG - 2018-01-23 07:15:21 --> Total execution time: 0.0360
INFO - 2018-01-23 07:15:22 --> Config Class Initialized
INFO - 2018-01-23 07:15:22 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:15:22 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:15:22 --> Utf8 Class Initialized
INFO - 2018-01-23 07:15:22 --> URI Class Initialized
INFO - 2018-01-23 07:15:22 --> Router Class Initialized
INFO - 2018-01-23 07:15:22 --> Output Class Initialized
INFO - 2018-01-23 07:15:22 --> Security Class Initialized
DEBUG - 2018-01-23 07:15:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:15:22 --> Input Class Initialized
INFO - 2018-01-23 07:15:22 --> Language Class Initialized
INFO - 2018-01-23 07:15:22 --> Loader Class Initialized
INFO - 2018-01-23 07:15:22 --> Helper loaded: url_helper
INFO - 2018-01-23 07:15:22 --> Helper loaded: form_helper
INFO - 2018-01-23 07:15:22 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:15:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:15:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:15:22 --> Form Validation Class Initialized
INFO - 2018-01-23 07:15:22 --> Model Class Initialized
INFO - 2018-01-23 07:15:22 --> Controller Class Initialized
INFO - 2018-01-23 07:15:22 --> Model Class Initialized
DEBUG - 2018-01-23 07:15:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:15:31 --> Config Class Initialized
INFO - 2018-01-23 07:15:31 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:15:31 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:15:31 --> Utf8 Class Initialized
INFO - 2018-01-23 07:15:31 --> URI Class Initialized
INFO - 2018-01-23 07:15:31 --> Router Class Initialized
INFO - 2018-01-23 07:15:31 --> Output Class Initialized
INFO - 2018-01-23 07:15:31 --> Security Class Initialized
DEBUG - 2018-01-23 07:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:15:31 --> Input Class Initialized
INFO - 2018-01-23 07:15:31 --> Language Class Initialized
INFO - 2018-01-23 07:15:31 --> Loader Class Initialized
INFO - 2018-01-23 07:15:31 --> Helper loaded: url_helper
INFO - 2018-01-23 07:15:31 --> Helper loaded: form_helper
INFO - 2018-01-23 07:15:31 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:15:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:15:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:15:31 --> Form Validation Class Initialized
INFO - 2018-01-23 07:15:31 --> Model Class Initialized
INFO - 2018-01-23 07:15:31 --> Controller Class Initialized
INFO - 2018-01-23 07:15:31 --> Model Class Initialized
DEBUG - 2018-01-23 07:15:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:15:31 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-23 07:15:31 --> Final output sent to browser
DEBUG - 2018-01-23 07:15:31 --> Total execution time: 0.0407
INFO - 2018-01-23 07:15:31 --> Config Class Initialized
INFO - 2018-01-23 07:15:31 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:15:31 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:15:31 --> Utf8 Class Initialized
INFO - 2018-01-23 07:15:31 --> URI Class Initialized
INFO - 2018-01-23 07:15:31 --> Router Class Initialized
INFO - 2018-01-23 07:15:31 --> Output Class Initialized
INFO - 2018-01-23 07:15:31 --> Security Class Initialized
DEBUG - 2018-01-23 07:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:15:31 --> Input Class Initialized
INFO - 2018-01-23 07:15:31 --> Language Class Initialized
INFO - 2018-01-23 07:15:32 --> Loader Class Initialized
INFO - 2018-01-23 07:15:32 --> Helper loaded: url_helper
INFO - 2018-01-23 07:15:32 --> Helper loaded: form_helper
INFO - 2018-01-23 07:15:32 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:15:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:15:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:15:32 --> Form Validation Class Initialized
INFO - 2018-01-23 07:15:32 --> Model Class Initialized
INFO - 2018-01-23 07:15:32 --> Controller Class Initialized
INFO - 2018-01-23 07:15:32 --> Model Class Initialized
DEBUG - 2018-01-23 07:15:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:15:48 --> Config Class Initialized
INFO - 2018-01-23 07:15:48 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:15:48 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:15:48 --> Utf8 Class Initialized
INFO - 2018-01-23 07:15:48 --> URI Class Initialized
INFO - 2018-01-23 07:15:48 --> Router Class Initialized
INFO - 2018-01-23 07:15:48 --> Output Class Initialized
INFO - 2018-01-23 07:15:48 --> Security Class Initialized
DEBUG - 2018-01-23 07:15:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:15:48 --> Input Class Initialized
INFO - 2018-01-23 07:15:48 --> Language Class Initialized
INFO - 2018-01-23 07:15:48 --> Loader Class Initialized
INFO - 2018-01-23 07:15:48 --> Helper loaded: url_helper
INFO - 2018-01-23 07:15:48 --> Helper loaded: form_helper
INFO - 2018-01-23 07:15:48 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:15:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:15:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:15:48 --> Form Validation Class Initialized
INFO - 2018-01-23 07:15:48 --> Model Class Initialized
INFO - 2018-01-23 07:15:48 --> Controller Class Initialized
INFO - 2018-01-23 07:15:48 --> Model Class Initialized
DEBUG - 2018-01-23 07:15:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:15:48 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-23 07:15:48 --> Final output sent to browser
DEBUG - 2018-01-23 07:15:48 --> Total execution time: 0.0561
INFO - 2018-01-23 07:15:49 --> Config Class Initialized
INFO - 2018-01-23 07:15:49 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:15:49 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:15:49 --> Utf8 Class Initialized
INFO - 2018-01-23 07:15:49 --> URI Class Initialized
INFO - 2018-01-23 07:15:49 --> Router Class Initialized
INFO - 2018-01-23 07:15:49 --> Output Class Initialized
INFO - 2018-01-23 07:15:49 --> Security Class Initialized
DEBUG - 2018-01-23 07:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:15:49 --> Input Class Initialized
INFO - 2018-01-23 07:15:49 --> Language Class Initialized
INFO - 2018-01-23 07:15:49 --> Loader Class Initialized
INFO - 2018-01-23 07:15:49 --> Helper loaded: url_helper
INFO - 2018-01-23 07:15:49 --> Helper loaded: form_helper
INFO - 2018-01-23 07:15:49 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:15:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:15:49 --> Form Validation Class Initialized
INFO - 2018-01-23 07:15:49 --> Model Class Initialized
INFO - 2018-01-23 07:15:49 --> Controller Class Initialized
INFO - 2018-01-23 07:15:49 --> Model Class Initialized
DEBUG - 2018-01-23 07:15:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:15:55 --> Config Class Initialized
INFO - 2018-01-23 07:15:55 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:15:55 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:15:55 --> Utf8 Class Initialized
INFO - 2018-01-23 07:15:55 --> URI Class Initialized
INFO - 2018-01-23 07:15:55 --> Router Class Initialized
INFO - 2018-01-23 07:15:55 --> Output Class Initialized
INFO - 2018-01-23 07:15:55 --> Security Class Initialized
DEBUG - 2018-01-23 07:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:15:55 --> Input Class Initialized
INFO - 2018-01-23 07:15:55 --> Language Class Initialized
INFO - 2018-01-23 07:15:55 --> Loader Class Initialized
INFO - 2018-01-23 07:15:55 --> Helper loaded: url_helper
INFO - 2018-01-23 07:15:55 --> Helper loaded: form_helper
INFO - 2018-01-23 07:15:55 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:15:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:15:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:15:55 --> Form Validation Class Initialized
INFO - 2018-01-23 07:15:55 --> Model Class Initialized
INFO - 2018-01-23 07:15:55 --> Controller Class Initialized
INFO - 2018-01-23 07:15:55 --> Model Class Initialized
DEBUG - 2018-01-23 07:15:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:15:55 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-23 07:15:55 --> Final output sent to browser
DEBUG - 2018-01-23 07:15:55 --> Total execution time: 0.0473
INFO - 2018-01-23 07:15:56 --> Config Class Initialized
INFO - 2018-01-23 07:15:56 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:15:56 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:15:56 --> Utf8 Class Initialized
INFO - 2018-01-23 07:15:56 --> URI Class Initialized
INFO - 2018-01-23 07:15:56 --> Router Class Initialized
INFO - 2018-01-23 07:15:56 --> Output Class Initialized
INFO - 2018-01-23 07:15:56 --> Security Class Initialized
DEBUG - 2018-01-23 07:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:15:56 --> Input Class Initialized
INFO - 2018-01-23 07:15:56 --> Language Class Initialized
INFO - 2018-01-23 07:15:56 --> Loader Class Initialized
INFO - 2018-01-23 07:15:56 --> Helper loaded: url_helper
INFO - 2018-01-23 07:15:56 --> Helper loaded: form_helper
INFO - 2018-01-23 07:15:56 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:15:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:15:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:15:56 --> Form Validation Class Initialized
INFO - 2018-01-23 07:15:56 --> Model Class Initialized
INFO - 2018-01-23 07:15:56 --> Controller Class Initialized
INFO - 2018-01-23 07:15:56 --> Model Class Initialized
DEBUG - 2018-01-23 07:15:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:18:14 --> Config Class Initialized
INFO - 2018-01-23 07:18:14 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:18:14 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:18:14 --> Utf8 Class Initialized
INFO - 2018-01-23 07:18:14 --> URI Class Initialized
INFO - 2018-01-23 07:18:14 --> Router Class Initialized
INFO - 2018-01-23 07:18:14 --> Output Class Initialized
INFO - 2018-01-23 07:18:14 --> Security Class Initialized
DEBUG - 2018-01-23 07:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:18:14 --> Input Class Initialized
INFO - 2018-01-23 07:18:14 --> Language Class Initialized
INFO - 2018-01-23 07:18:14 --> Loader Class Initialized
INFO - 2018-01-23 07:18:14 --> Helper loaded: url_helper
INFO - 2018-01-23 07:18:14 --> Helper loaded: form_helper
INFO - 2018-01-23 07:18:14 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:18:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:18:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:18:14 --> Form Validation Class Initialized
INFO - 2018-01-23 07:18:14 --> Model Class Initialized
INFO - 2018-01-23 07:18:14 --> Controller Class Initialized
INFO - 2018-01-23 07:18:14 --> Model Class Initialized
DEBUG - 2018-01-23 07:18:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:18:14 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-23 07:18:14 --> Final output sent to browser
DEBUG - 2018-01-23 07:18:14 --> Total execution time: 0.0430
INFO - 2018-01-23 07:18:15 --> Config Class Initialized
INFO - 2018-01-23 07:18:15 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:18:15 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:18:15 --> Utf8 Class Initialized
INFO - 2018-01-23 07:18:15 --> URI Class Initialized
INFO - 2018-01-23 07:18:15 --> Router Class Initialized
INFO - 2018-01-23 07:18:15 --> Output Class Initialized
INFO - 2018-01-23 07:18:15 --> Security Class Initialized
DEBUG - 2018-01-23 07:18:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:18:15 --> Input Class Initialized
INFO - 2018-01-23 07:18:15 --> Language Class Initialized
INFO - 2018-01-23 07:18:15 --> Loader Class Initialized
INFO - 2018-01-23 07:18:15 --> Helper loaded: url_helper
INFO - 2018-01-23 07:18:15 --> Helper loaded: form_helper
INFO - 2018-01-23 07:18:15 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:18:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:18:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:18:15 --> Form Validation Class Initialized
INFO - 2018-01-23 07:18:15 --> Model Class Initialized
INFO - 2018-01-23 07:18:15 --> Controller Class Initialized
INFO - 2018-01-23 07:18:15 --> Model Class Initialized
DEBUG - 2018-01-23 07:18:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:19:09 --> Config Class Initialized
INFO - 2018-01-23 07:19:09 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:19:09 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:19:09 --> Utf8 Class Initialized
INFO - 2018-01-23 07:19:09 --> URI Class Initialized
INFO - 2018-01-23 07:19:09 --> Router Class Initialized
INFO - 2018-01-23 07:19:09 --> Output Class Initialized
INFO - 2018-01-23 07:19:09 --> Security Class Initialized
DEBUG - 2018-01-23 07:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:19:09 --> Input Class Initialized
INFO - 2018-01-23 07:19:09 --> Language Class Initialized
INFO - 2018-01-23 07:19:09 --> Loader Class Initialized
INFO - 2018-01-23 07:19:09 --> Helper loaded: url_helper
INFO - 2018-01-23 07:19:09 --> Helper loaded: form_helper
INFO - 2018-01-23 07:19:09 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:19:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:19:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:19:09 --> Form Validation Class Initialized
INFO - 2018-01-23 07:19:09 --> Model Class Initialized
INFO - 2018-01-23 07:19:09 --> Controller Class Initialized
INFO - 2018-01-23 07:19:09 --> Model Class Initialized
DEBUG - 2018-01-23 07:19:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:19:09 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-23 07:19:09 --> Final output sent to browser
DEBUG - 2018-01-23 07:19:09 --> Total execution time: 0.0462
INFO - 2018-01-23 07:19:10 --> Config Class Initialized
INFO - 2018-01-23 07:19:10 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:19:10 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:19:10 --> Utf8 Class Initialized
INFO - 2018-01-23 07:19:10 --> URI Class Initialized
INFO - 2018-01-23 07:19:10 --> Router Class Initialized
INFO - 2018-01-23 07:19:10 --> Output Class Initialized
INFO - 2018-01-23 07:19:10 --> Security Class Initialized
DEBUG - 2018-01-23 07:19:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:19:10 --> Input Class Initialized
INFO - 2018-01-23 07:19:10 --> Language Class Initialized
INFO - 2018-01-23 07:19:10 --> Loader Class Initialized
INFO - 2018-01-23 07:19:10 --> Helper loaded: url_helper
INFO - 2018-01-23 07:19:10 --> Helper loaded: form_helper
INFO - 2018-01-23 07:19:10 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:19:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:19:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:19:10 --> Form Validation Class Initialized
INFO - 2018-01-23 07:19:10 --> Model Class Initialized
INFO - 2018-01-23 07:19:10 --> Controller Class Initialized
INFO - 2018-01-23 07:19:10 --> Model Class Initialized
DEBUG - 2018-01-23 07:19:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:24:37 --> Config Class Initialized
INFO - 2018-01-23 07:24:37 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:24:37 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:24:37 --> Utf8 Class Initialized
INFO - 2018-01-23 07:24:37 --> URI Class Initialized
INFO - 2018-01-23 07:24:37 --> Router Class Initialized
INFO - 2018-01-23 07:24:37 --> Output Class Initialized
INFO - 2018-01-23 07:24:37 --> Security Class Initialized
DEBUG - 2018-01-23 07:24:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:24:37 --> Input Class Initialized
INFO - 2018-01-23 07:24:37 --> Language Class Initialized
INFO - 2018-01-23 07:24:37 --> Loader Class Initialized
INFO - 2018-01-23 07:24:37 --> Helper loaded: url_helper
INFO - 2018-01-23 07:24:37 --> Helper loaded: form_helper
INFO - 2018-01-23 07:24:37 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:24:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:24:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:24:37 --> Form Validation Class Initialized
INFO - 2018-01-23 07:24:37 --> Model Class Initialized
INFO - 2018-01-23 07:24:37 --> Controller Class Initialized
INFO - 2018-01-23 07:24:37 --> Model Class Initialized
DEBUG - 2018-01-23 07:24:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:24:37 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-23 07:24:37 --> Final output sent to browser
DEBUG - 2018-01-23 07:24:37 --> Total execution time: 0.0375
INFO - 2018-01-23 07:24:38 --> Config Class Initialized
INFO - 2018-01-23 07:24:38 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:24:38 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:24:38 --> Utf8 Class Initialized
INFO - 2018-01-23 07:24:38 --> URI Class Initialized
INFO - 2018-01-23 07:24:38 --> Router Class Initialized
INFO - 2018-01-23 07:24:38 --> Output Class Initialized
INFO - 2018-01-23 07:24:38 --> Security Class Initialized
DEBUG - 2018-01-23 07:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:24:38 --> Input Class Initialized
INFO - 2018-01-23 07:24:38 --> Language Class Initialized
INFO - 2018-01-23 07:24:38 --> Loader Class Initialized
INFO - 2018-01-23 07:24:38 --> Helper loaded: url_helper
INFO - 2018-01-23 07:24:38 --> Helper loaded: form_helper
INFO - 2018-01-23 07:24:38 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:24:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:24:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:24:38 --> Form Validation Class Initialized
INFO - 2018-01-23 07:24:38 --> Model Class Initialized
INFO - 2018-01-23 07:24:38 --> Controller Class Initialized
INFO - 2018-01-23 07:24:38 --> Model Class Initialized
DEBUG - 2018-01-23 07:24:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:24:48 --> Config Class Initialized
INFO - 2018-01-23 07:24:48 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:24:48 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:24:48 --> Utf8 Class Initialized
INFO - 2018-01-23 07:24:48 --> URI Class Initialized
INFO - 2018-01-23 07:24:48 --> Router Class Initialized
INFO - 2018-01-23 07:24:48 --> Output Class Initialized
INFO - 2018-01-23 07:24:48 --> Security Class Initialized
DEBUG - 2018-01-23 07:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:24:48 --> Input Class Initialized
INFO - 2018-01-23 07:24:48 --> Language Class Initialized
INFO - 2018-01-23 07:24:48 --> Loader Class Initialized
INFO - 2018-01-23 07:24:48 --> Helper loaded: url_helper
INFO - 2018-01-23 07:24:48 --> Helper loaded: form_helper
INFO - 2018-01-23 07:24:48 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:24:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:24:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:24:48 --> Form Validation Class Initialized
INFO - 2018-01-23 07:24:48 --> Model Class Initialized
INFO - 2018-01-23 07:24:48 --> Controller Class Initialized
INFO - 2018-01-23 07:24:48 --> Model Class Initialized
DEBUG - 2018-01-23 07:24:48 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-01-23 07:24:48 --> Query error: Column 'rol_id' in where clause is ambiguous - Invalid query: SELECT *
FROM `usuario`
JOIN `usuario_estado` ON `usuario_estado`.`estado_id` = `usuario`.`estado_id`
JOIN `usuario_detalle` ON `usuario_detalle`.`usuario_id` = `usuario`.`usuario_id`
JOIN `usuario_rol` ON `usuario_rol`.`rol_id` = `usuario`.`rol_id`
WHERE `usuario` LIKE '%%' ESCAPE '!'
AND  `usuario_detalle`.`nombre` LIKE '%%' ESCAPE '!'
AND  `usuario_detalle`.`correo` LIKE '%%' ESCAPE '!'
AND `usuario`.`estado_id` = 1
AND `rol_id` = '1'
INFO - 2018-01-23 07:24:48 --> Language file loaded: language/english/db_lang.php
INFO - 2018-01-23 07:24:50 --> Config Class Initialized
INFO - 2018-01-23 07:24:50 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:24:50 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:24:50 --> Utf8 Class Initialized
INFO - 2018-01-23 07:24:50 --> URI Class Initialized
INFO - 2018-01-23 07:24:50 --> Router Class Initialized
INFO - 2018-01-23 07:24:50 --> Output Class Initialized
INFO - 2018-01-23 07:24:50 --> Security Class Initialized
DEBUG - 2018-01-23 07:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:24:50 --> Input Class Initialized
INFO - 2018-01-23 07:24:50 --> Language Class Initialized
INFO - 2018-01-23 07:24:50 --> Loader Class Initialized
INFO - 2018-01-23 07:24:50 --> Helper loaded: url_helper
INFO - 2018-01-23 07:24:50 --> Helper loaded: form_helper
INFO - 2018-01-23 07:24:50 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:24:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:24:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:24:50 --> Form Validation Class Initialized
INFO - 2018-01-23 07:24:50 --> Model Class Initialized
INFO - 2018-01-23 07:24:50 --> Controller Class Initialized
INFO - 2018-01-23 07:24:50 --> Model Class Initialized
DEBUG - 2018-01-23 07:24:50 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-01-23 07:24:50 --> Query error: Column 'rol_id' in where clause is ambiguous - Invalid query: SELECT *
FROM `usuario`
JOIN `usuario_estado` ON `usuario_estado`.`estado_id` = `usuario`.`estado_id`
JOIN `usuario_detalle` ON `usuario_detalle`.`usuario_id` = `usuario`.`usuario_id`
JOIN `usuario_rol` ON `usuario_rol`.`rol_id` = `usuario`.`rol_id`
WHERE `usuario` LIKE '%%' ESCAPE '!'
AND  `usuario_detalle`.`nombre` LIKE '%%' ESCAPE '!'
AND  `usuario_detalle`.`correo` LIKE '%%' ESCAPE '!'
AND `usuario`.`estado_id` = 1
AND `rol_id` = '2'
INFO - 2018-01-23 07:24:50 --> Language file loaded: language/english/db_lang.php
INFO - 2018-01-23 07:24:51 --> Config Class Initialized
INFO - 2018-01-23 07:24:51 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:24:51 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:24:51 --> Utf8 Class Initialized
INFO - 2018-01-23 07:24:51 --> URI Class Initialized
INFO - 2018-01-23 07:24:51 --> Router Class Initialized
INFO - 2018-01-23 07:24:51 --> Output Class Initialized
INFO - 2018-01-23 07:24:51 --> Security Class Initialized
DEBUG - 2018-01-23 07:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:24:51 --> Input Class Initialized
INFO - 2018-01-23 07:24:51 --> Language Class Initialized
INFO - 2018-01-23 07:24:51 --> Loader Class Initialized
INFO - 2018-01-23 07:24:51 --> Helper loaded: url_helper
INFO - 2018-01-23 07:24:51 --> Helper loaded: form_helper
INFO - 2018-01-23 07:24:51 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:24:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:24:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:24:51 --> Form Validation Class Initialized
INFO - 2018-01-23 07:24:51 --> Model Class Initialized
INFO - 2018-01-23 07:24:51 --> Controller Class Initialized
INFO - 2018-01-23 07:24:51 --> Model Class Initialized
DEBUG - 2018-01-23 07:24:51 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-01-23 07:24:51 --> Query error: Column 'rol_id' in where clause is ambiguous - Invalid query: SELECT *
FROM `usuario`
JOIN `usuario_estado` ON `usuario_estado`.`estado_id` = `usuario`.`estado_id`
JOIN `usuario_detalle` ON `usuario_detalle`.`usuario_id` = `usuario`.`usuario_id`
JOIN `usuario_rol` ON `usuario_rol`.`rol_id` = `usuario`.`rol_id`
WHERE `usuario` LIKE '%%' ESCAPE '!'
AND  `usuario_detalle`.`nombre` LIKE '%%' ESCAPE '!'
AND  `usuario_detalle`.`correo` LIKE '%%' ESCAPE '!'
AND `usuario`.`estado_id` = 1
AND `rol_id` = '2'
INFO - 2018-01-23 07:24:51 --> Language file loaded: language/english/db_lang.php
INFO - 2018-01-23 07:25:44 --> Config Class Initialized
INFO - 2018-01-23 07:25:44 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:25:44 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:25:44 --> Utf8 Class Initialized
INFO - 2018-01-23 07:25:44 --> URI Class Initialized
INFO - 2018-01-23 07:25:44 --> Router Class Initialized
INFO - 2018-01-23 07:25:44 --> Output Class Initialized
INFO - 2018-01-23 07:25:44 --> Security Class Initialized
DEBUG - 2018-01-23 07:25:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:25:44 --> Input Class Initialized
INFO - 2018-01-23 07:25:44 --> Language Class Initialized
INFO - 2018-01-23 07:25:44 --> Loader Class Initialized
INFO - 2018-01-23 07:25:44 --> Helper loaded: url_helper
INFO - 2018-01-23 07:25:44 --> Helper loaded: form_helper
INFO - 2018-01-23 07:25:44 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:25:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:25:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:25:44 --> Form Validation Class Initialized
INFO - 2018-01-23 07:25:44 --> Model Class Initialized
INFO - 2018-01-23 07:25:44 --> Controller Class Initialized
INFO - 2018-01-23 07:25:44 --> Model Class Initialized
DEBUG - 2018-01-23 07:25:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:25:44 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-23 07:25:44 --> Final output sent to browser
DEBUG - 2018-01-23 07:25:44 --> Total execution time: 0.0386
INFO - 2018-01-23 07:25:45 --> Config Class Initialized
INFO - 2018-01-23 07:25:45 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:25:45 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:25:45 --> Utf8 Class Initialized
INFO - 2018-01-23 07:25:45 --> URI Class Initialized
INFO - 2018-01-23 07:25:45 --> Router Class Initialized
INFO - 2018-01-23 07:25:45 --> Output Class Initialized
INFO - 2018-01-23 07:25:45 --> Security Class Initialized
DEBUG - 2018-01-23 07:25:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:25:45 --> Input Class Initialized
INFO - 2018-01-23 07:25:45 --> Language Class Initialized
INFO - 2018-01-23 07:25:45 --> Loader Class Initialized
INFO - 2018-01-23 07:25:45 --> Helper loaded: url_helper
INFO - 2018-01-23 07:25:45 --> Helper loaded: form_helper
INFO - 2018-01-23 07:25:45 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:25:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:25:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:25:45 --> Form Validation Class Initialized
INFO - 2018-01-23 07:25:45 --> Model Class Initialized
INFO - 2018-01-23 07:25:45 --> Controller Class Initialized
INFO - 2018-01-23 07:25:45 --> Model Class Initialized
DEBUG - 2018-01-23 07:25:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:25:52 --> Config Class Initialized
INFO - 2018-01-23 07:25:52 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:25:52 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:25:52 --> Utf8 Class Initialized
INFO - 2018-01-23 07:25:52 --> URI Class Initialized
INFO - 2018-01-23 07:25:52 --> Router Class Initialized
INFO - 2018-01-23 07:25:52 --> Output Class Initialized
INFO - 2018-01-23 07:25:52 --> Security Class Initialized
DEBUG - 2018-01-23 07:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:25:52 --> Input Class Initialized
INFO - 2018-01-23 07:25:52 --> Language Class Initialized
INFO - 2018-01-23 07:25:52 --> Loader Class Initialized
INFO - 2018-01-23 07:25:52 --> Helper loaded: url_helper
INFO - 2018-01-23 07:25:52 --> Helper loaded: form_helper
INFO - 2018-01-23 07:25:52 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:25:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:25:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:25:52 --> Form Validation Class Initialized
INFO - 2018-01-23 07:25:52 --> Model Class Initialized
INFO - 2018-01-23 07:25:52 --> Controller Class Initialized
INFO - 2018-01-23 07:25:52 --> Model Class Initialized
DEBUG - 2018-01-23 07:25:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:25:54 --> Config Class Initialized
INFO - 2018-01-23 07:25:54 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:25:54 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:25:54 --> Utf8 Class Initialized
INFO - 2018-01-23 07:25:54 --> URI Class Initialized
INFO - 2018-01-23 07:25:54 --> Router Class Initialized
INFO - 2018-01-23 07:25:54 --> Output Class Initialized
INFO - 2018-01-23 07:25:54 --> Security Class Initialized
DEBUG - 2018-01-23 07:25:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:25:54 --> Input Class Initialized
INFO - 2018-01-23 07:25:54 --> Language Class Initialized
INFO - 2018-01-23 07:25:54 --> Loader Class Initialized
INFO - 2018-01-23 07:25:54 --> Helper loaded: url_helper
INFO - 2018-01-23 07:25:54 --> Helper loaded: form_helper
INFO - 2018-01-23 07:25:54 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:25:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:25:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:25:54 --> Form Validation Class Initialized
INFO - 2018-01-23 07:25:54 --> Model Class Initialized
INFO - 2018-01-23 07:25:54 --> Controller Class Initialized
INFO - 2018-01-23 07:25:54 --> Model Class Initialized
DEBUG - 2018-01-23 07:25:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:25:56 --> Config Class Initialized
INFO - 2018-01-23 07:25:56 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:25:56 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:25:56 --> Utf8 Class Initialized
INFO - 2018-01-23 07:25:56 --> URI Class Initialized
INFO - 2018-01-23 07:25:56 --> Router Class Initialized
INFO - 2018-01-23 07:25:56 --> Output Class Initialized
INFO - 2018-01-23 07:25:56 --> Security Class Initialized
DEBUG - 2018-01-23 07:25:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:25:56 --> Input Class Initialized
INFO - 2018-01-23 07:25:56 --> Language Class Initialized
INFO - 2018-01-23 07:25:56 --> Loader Class Initialized
INFO - 2018-01-23 07:25:56 --> Helper loaded: url_helper
INFO - 2018-01-23 07:25:56 --> Helper loaded: form_helper
INFO - 2018-01-23 07:25:56 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:25:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:25:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:25:56 --> Form Validation Class Initialized
INFO - 2018-01-23 07:25:56 --> Model Class Initialized
INFO - 2018-01-23 07:25:56 --> Controller Class Initialized
INFO - 2018-01-23 07:25:56 --> Model Class Initialized
DEBUG - 2018-01-23 07:25:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:26:55 --> Config Class Initialized
INFO - 2018-01-23 07:26:55 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:26:55 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:26:55 --> Utf8 Class Initialized
INFO - 2018-01-23 07:26:55 --> URI Class Initialized
INFO - 2018-01-23 07:26:55 --> Router Class Initialized
INFO - 2018-01-23 07:26:55 --> Output Class Initialized
INFO - 2018-01-23 07:26:55 --> Security Class Initialized
DEBUG - 2018-01-23 07:26:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:26:55 --> Input Class Initialized
INFO - 2018-01-23 07:26:55 --> Language Class Initialized
INFO - 2018-01-23 07:26:55 --> Loader Class Initialized
INFO - 2018-01-23 07:26:55 --> Helper loaded: url_helper
INFO - 2018-01-23 07:26:55 --> Helper loaded: form_helper
INFO - 2018-01-23 07:26:55 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:26:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:26:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:26:55 --> Form Validation Class Initialized
INFO - 2018-01-23 07:26:55 --> Model Class Initialized
INFO - 2018-01-23 07:26:55 --> Controller Class Initialized
INFO - 2018-01-23 07:26:55 --> Model Class Initialized
DEBUG - 2018-01-23 07:26:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:26:55 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-23 07:26:55 --> Final output sent to browser
DEBUG - 2018-01-23 07:26:55 --> Total execution time: 0.0378
INFO - 2018-01-23 07:26:57 --> Config Class Initialized
INFO - 2018-01-23 07:26:57 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:26:57 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:26:57 --> Utf8 Class Initialized
INFO - 2018-01-23 07:26:57 --> URI Class Initialized
INFO - 2018-01-23 07:26:57 --> Router Class Initialized
INFO - 2018-01-23 07:26:57 --> Output Class Initialized
INFO - 2018-01-23 07:26:57 --> Security Class Initialized
DEBUG - 2018-01-23 07:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:26:57 --> Input Class Initialized
INFO - 2018-01-23 07:26:57 --> Language Class Initialized
INFO - 2018-01-23 07:26:57 --> Loader Class Initialized
INFO - 2018-01-23 07:26:57 --> Helper loaded: url_helper
INFO - 2018-01-23 07:26:57 --> Helper loaded: form_helper
INFO - 2018-01-23 07:26:57 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:26:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:26:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:26:57 --> Form Validation Class Initialized
INFO - 2018-01-23 07:26:57 --> Model Class Initialized
INFO - 2018-01-23 07:26:57 --> Controller Class Initialized
INFO - 2018-01-23 07:26:57 --> Model Class Initialized
DEBUG - 2018-01-23 07:26:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:27:01 --> Config Class Initialized
INFO - 2018-01-23 07:27:01 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:27:01 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:27:01 --> Utf8 Class Initialized
INFO - 2018-01-23 07:27:01 --> URI Class Initialized
INFO - 2018-01-23 07:27:01 --> Router Class Initialized
INFO - 2018-01-23 07:27:01 --> Output Class Initialized
INFO - 2018-01-23 07:27:01 --> Security Class Initialized
DEBUG - 2018-01-23 07:27:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:27:01 --> Input Class Initialized
INFO - 2018-01-23 07:27:01 --> Language Class Initialized
INFO - 2018-01-23 07:27:01 --> Loader Class Initialized
INFO - 2018-01-23 07:27:01 --> Helper loaded: url_helper
INFO - 2018-01-23 07:27:01 --> Helper loaded: form_helper
INFO - 2018-01-23 07:27:01 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:27:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:27:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:27:01 --> Form Validation Class Initialized
INFO - 2018-01-23 07:27:01 --> Model Class Initialized
INFO - 2018-01-23 07:27:01 --> Controller Class Initialized
INFO - 2018-01-23 07:27:01 --> Model Class Initialized
DEBUG - 2018-01-23 07:27:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:27:03 --> Config Class Initialized
INFO - 2018-01-23 07:27:03 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:27:03 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:27:03 --> Utf8 Class Initialized
INFO - 2018-01-23 07:27:03 --> URI Class Initialized
INFO - 2018-01-23 07:27:03 --> Router Class Initialized
INFO - 2018-01-23 07:27:03 --> Output Class Initialized
INFO - 2018-01-23 07:27:03 --> Security Class Initialized
DEBUG - 2018-01-23 07:27:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:27:03 --> Input Class Initialized
INFO - 2018-01-23 07:27:03 --> Language Class Initialized
INFO - 2018-01-23 07:27:03 --> Loader Class Initialized
INFO - 2018-01-23 07:27:03 --> Helper loaded: url_helper
INFO - 2018-01-23 07:27:03 --> Helper loaded: form_helper
INFO - 2018-01-23 07:27:03 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:27:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:27:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:27:03 --> Form Validation Class Initialized
INFO - 2018-01-23 07:27:03 --> Model Class Initialized
INFO - 2018-01-23 07:27:03 --> Controller Class Initialized
INFO - 2018-01-23 07:27:03 --> Model Class Initialized
DEBUG - 2018-01-23 07:27:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:27:05 --> Config Class Initialized
INFO - 2018-01-23 07:27:05 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:27:05 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:27:05 --> Utf8 Class Initialized
INFO - 2018-01-23 07:27:05 --> URI Class Initialized
INFO - 2018-01-23 07:27:05 --> Router Class Initialized
INFO - 2018-01-23 07:27:05 --> Output Class Initialized
INFO - 2018-01-23 07:27:05 --> Security Class Initialized
DEBUG - 2018-01-23 07:27:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:27:05 --> Input Class Initialized
INFO - 2018-01-23 07:27:05 --> Language Class Initialized
INFO - 2018-01-23 07:27:05 --> Loader Class Initialized
INFO - 2018-01-23 07:27:05 --> Helper loaded: url_helper
INFO - 2018-01-23 07:27:05 --> Helper loaded: form_helper
INFO - 2018-01-23 07:27:05 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:27:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:27:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:27:05 --> Form Validation Class Initialized
INFO - 2018-01-23 07:27:05 --> Model Class Initialized
INFO - 2018-01-23 07:27:05 --> Controller Class Initialized
INFO - 2018-01-23 07:27:05 --> Model Class Initialized
DEBUG - 2018-01-23 07:27:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:27:07 --> Config Class Initialized
INFO - 2018-01-23 07:27:07 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:27:07 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:27:07 --> Utf8 Class Initialized
INFO - 2018-01-23 07:27:07 --> URI Class Initialized
INFO - 2018-01-23 07:27:07 --> Router Class Initialized
INFO - 2018-01-23 07:27:07 --> Output Class Initialized
INFO - 2018-01-23 07:27:07 --> Security Class Initialized
DEBUG - 2018-01-23 07:27:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:27:07 --> Input Class Initialized
INFO - 2018-01-23 07:27:07 --> Language Class Initialized
INFO - 2018-01-23 07:27:07 --> Loader Class Initialized
INFO - 2018-01-23 07:27:07 --> Helper loaded: url_helper
INFO - 2018-01-23 07:27:07 --> Helper loaded: form_helper
INFO - 2018-01-23 07:27:07 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:27:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:27:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:27:07 --> Form Validation Class Initialized
INFO - 2018-01-23 07:27:07 --> Model Class Initialized
INFO - 2018-01-23 07:27:07 --> Controller Class Initialized
INFO - 2018-01-23 07:27:07 --> Model Class Initialized
DEBUG - 2018-01-23 07:27:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:27:09 --> Config Class Initialized
INFO - 2018-01-23 07:27:09 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:27:09 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:27:09 --> Utf8 Class Initialized
INFO - 2018-01-23 07:27:09 --> URI Class Initialized
INFO - 2018-01-23 07:27:09 --> Router Class Initialized
INFO - 2018-01-23 07:27:09 --> Output Class Initialized
INFO - 2018-01-23 07:27:09 --> Security Class Initialized
DEBUG - 2018-01-23 07:27:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:27:09 --> Input Class Initialized
INFO - 2018-01-23 07:27:09 --> Language Class Initialized
INFO - 2018-01-23 07:27:09 --> Loader Class Initialized
INFO - 2018-01-23 07:27:09 --> Helper loaded: url_helper
INFO - 2018-01-23 07:27:09 --> Helper loaded: form_helper
INFO - 2018-01-23 07:27:09 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:27:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:27:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:27:09 --> Form Validation Class Initialized
INFO - 2018-01-23 07:27:09 --> Model Class Initialized
INFO - 2018-01-23 07:27:09 --> Controller Class Initialized
INFO - 2018-01-23 07:27:09 --> Model Class Initialized
DEBUG - 2018-01-23 07:27:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:27:55 --> Config Class Initialized
INFO - 2018-01-23 07:27:55 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:27:55 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:27:55 --> Utf8 Class Initialized
INFO - 2018-01-23 07:27:55 --> URI Class Initialized
INFO - 2018-01-23 07:27:55 --> Router Class Initialized
INFO - 2018-01-23 07:27:55 --> Output Class Initialized
INFO - 2018-01-23 07:27:55 --> Security Class Initialized
DEBUG - 2018-01-23 07:27:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:27:55 --> Input Class Initialized
INFO - 2018-01-23 07:27:55 --> Language Class Initialized
INFO - 2018-01-23 07:27:55 --> Loader Class Initialized
INFO - 2018-01-23 07:27:55 --> Helper loaded: url_helper
INFO - 2018-01-23 07:27:55 --> Helper loaded: form_helper
INFO - 2018-01-23 07:27:55 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:27:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:27:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:27:55 --> Form Validation Class Initialized
INFO - 2018-01-23 07:27:55 --> Model Class Initialized
INFO - 2018-01-23 07:27:55 --> Controller Class Initialized
INFO - 2018-01-23 07:27:55 --> Model Class Initialized
DEBUG - 2018-01-23 07:27:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:27:55 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-23 07:27:55 --> Final output sent to browser
DEBUG - 2018-01-23 07:27:55 --> Total execution time: 0.0381
INFO - 2018-01-23 07:27:55 --> Config Class Initialized
INFO - 2018-01-23 07:27:55 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:27:55 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:27:55 --> Utf8 Class Initialized
INFO - 2018-01-23 07:27:55 --> URI Class Initialized
INFO - 2018-01-23 07:27:55 --> Router Class Initialized
INFO - 2018-01-23 07:27:55 --> Output Class Initialized
INFO - 2018-01-23 07:27:55 --> Security Class Initialized
DEBUG - 2018-01-23 07:27:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:27:55 --> Input Class Initialized
INFO - 2018-01-23 07:27:55 --> Language Class Initialized
INFO - 2018-01-23 07:27:55 --> Loader Class Initialized
INFO - 2018-01-23 07:27:55 --> Helper loaded: url_helper
INFO - 2018-01-23 07:27:55 --> Helper loaded: form_helper
INFO - 2018-01-23 07:27:55 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:27:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:27:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:27:55 --> Form Validation Class Initialized
INFO - 2018-01-23 07:27:55 --> Model Class Initialized
INFO - 2018-01-23 07:27:55 --> Controller Class Initialized
INFO - 2018-01-23 07:27:55 --> Model Class Initialized
DEBUG - 2018-01-23 07:27:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:28:00 --> Config Class Initialized
INFO - 2018-01-23 07:28:00 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:28:00 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:28:00 --> Utf8 Class Initialized
INFO - 2018-01-23 07:28:00 --> URI Class Initialized
INFO - 2018-01-23 07:28:00 --> Router Class Initialized
INFO - 2018-01-23 07:28:00 --> Output Class Initialized
INFO - 2018-01-23 07:28:00 --> Security Class Initialized
DEBUG - 2018-01-23 07:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:28:00 --> Input Class Initialized
INFO - 2018-01-23 07:28:00 --> Language Class Initialized
INFO - 2018-01-23 07:28:00 --> Loader Class Initialized
INFO - 2018-01-23 07:28:00 --> Helper loaded: url_helper
INFO - 2018-01-23 07:28:00 --> Helper loaded: form_helper
INFO - 2018-01-23 07:28:00 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:28:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:28:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:28:00 --> Form Validation Class Initialized
INFO - 2018-01-23 07:28:00 --> Model Class Initialized
INFO - 2018-01-23 07:28:00 --> Controller Class Initialized
INFO - 2018-01-23 07:28:00 --> Model Class Initialized
DEBUG - 2018-01-23 07:28:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:28:01 --> Config Class Initialized
INFO - 2018-01-23 07:28:01 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:28:01 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:28:01 --> Utf8 Class Initialized
INFO - 2018-01-23 07:28:01 --> URI Class Initialized
INFO - 2018-01-23 07:28:01 --> Router Class Initialized
INFO - 2018-01-23 07:28:01 --> Output Class Initialized
INFO - 2018-01-23 07:28:01 --> Security Class Initialized
DEBUG - 2018-01-23 07:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:28:01 --> Input Class Initialized
INFO - 2018-01-23 07:28:01 --> Language Class Initialized
INFO - 2018-01-23 07:28:01 --> Loader Class Initialized
INFO - 2018-01-23 07:28:01 --> Helper loaded: url_helper
INFO - 2018-01-23 07:28:01 --> Helper loaded: form_helper
INFO - 2018-01-23 07:28:01 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:28:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:28:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:28:01 --> Form Validation Class Initialized
INFO - 2018-01-23 07:28:01 --> Model Class Initialized
INFO - 2018-01-23 07:28:01 --> Controller Class Initialized
INFO - 2018-01-23 07:28:01 --> Model Class Initialized
DEBUG - 2018-01-23 07:28:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:28:04 --> Config Class Initialized
INFO - 2018-01-23 07:28:04 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:28:04 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:28:04 --> Utf8 Class Initialized
INFO - 2018-01-23 07:28:04 --> URI Class Initialized
INFO - 2018-01-23 07:28:04 --> Router Class Initialized
INFO - 2018-01-23 07:28:04 --> Output Class Initialized
INFO - 2018-01-23 07:28:04 --> Security Class Initialized
DEBUG - 2018-01-23 07:28:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:28:04 --> Input Class Initialized
INFO - 2018-01-23 07:28:04 --> Language Class Initialized
INFO - 2018-01-23 07:28:04 --> Loader Class Initialized
INFO - 2018-01-23 07:28:04 --> Helper loaded: url_helper
INFO - 2018-01-23 07:28:04 --> Helper loaded: form_helper
INFO - 2018-01-23 07:28:04 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:28:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:28:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:28:04 --> Form Validation Class Initialized
INFO - 2018-01-23 07:28:04 --> Model Class Initialized
INFO - 2018-01-23 07:28:04 --> Controller Class Initialized
INFO - 2018-01-23 07:28:04 --> Model Class Initialized
DEBUG - 2018-01-23 07:28:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:28:05 --> Config Class Initialized
INFO - 2018-01-23 07:28:05 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:28:05 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:28:05 --> Utf8 Class Initialized
INFO - 2018-01-23 07:28:05 --> URI Class Initialized
INFO - 2018-01-23 07:28:05 --> Router Class Initialized
INFO - 2018-01-23 07:28:06 --> Output Class Initialized
INFO - 2018-01-23 07:28:06 --> Security Class Initialized
DEBUG - 2018-01-23 07:28:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:28:06 --> Input Class Initialized
INFO - 2018-01-23 07:28:06 --> Language Class Initialized
INFO - 2018-01-23 07:28:06 --> Loader Class Initialized
INFO - 2018-01-23 07:28:06 --> Helper loaded: url_helper
INFO - 2018-01-23 07:28:06 --> Helper loaded: form_helper
INFO - 2018-01-23 07:28:06 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:28:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:28:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:28:06 --> Form Validation Class Initialized
INFO - 2018-01-23 07:28:06 --> Model Class Initialized
INFO - 2018-01-23 07:28:06 --> Controller Class Initialized
INFO - 2018-01-23 07:28:06 --> Model Class Initialized
DEBUG - 2018-01-23 07:28:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:28:07 --> Config Class Initialized
INFO - 2018-01-23 07:28:07 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:28:07 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:28:07 --> Utf8 Class Initialized
INFO - 2018-01-23 07:28:07 --> URI Class Initialized
INFO - 2018-01-23 07:28:07 --> Router Class Initialized
INFO - 2018-01-23 07:28:07 --> Output Class Initialized
INFO - 2018-01-23 07:28:07 --> Security Class Initialized
DEBUG - 2018-01-23 07:28:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:28:07 --> Input Class Initialized
INFO - 2018-01-23 07:28:07 --> Language Class Initialized
INFO - 2018-01-23 07:28:07 --> Loader Class Initialized
INFO - 2018-01-23 07:28:07 --> Helper loaded: url_helper
INFO - 2018-01-23 07:28:07 --> Helper loaded: form_helper
INFO - 2018-01-23 07:28:07 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:28:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:28:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:28:07 --> Form Validation Class Initialized
INFO - 2018-01-23 07:28:07 --> Model Class Initialized
INFO - 2018-01-23 07:28:07 --> Controller Class Initialized
INFO - 2018-01-23 07:28:07 --> Model Class Initialized
DEBUG - 2018-01-23 07:28:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:28:09 --> Config Class Initialized
INFO - 2018-01-23 07:28:09 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:28:09 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:28:09 --> Utf8 Class Initialized
INFO - 2018-01-23 07:28:09 --> URI Class Initialized
INFO - 2018-01-23 07:28:09 --> Router Class Initialized
INFO - 2018-01-23 07:28:09 --> Output Class Initialized
INFO - 2018-01-23 07:28:09 --> Security Class Initialized
DEBUG - 2018-01-23 07:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:28:09 --> Input Class Initialized
INFO - 2018-01-23 07:28:09 --> Language Class Initialized
INFO - 2018-01-23 07:28:09 --> Loader Class Initialized
INFO - 2018-01-23 07:28:09 --> Helper loaded: url_helper
INFO - 2018-01-23 07:28:09 --> Helper loaded: form_helper
INFO - 2018-01-23 07:28:09 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:28:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:28:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:28:09 --> Form Validation Class Initialized
INFO - 2018-01-23 07:28:09 --> Model Class Initialized
INFO - 2018-01-23 07:28:09 --> Controller Class Initialized
INFO - 2018-01-23 07:28:09 --> Model Class Initialized
INFO - 2018-01-23 07:28:09 --> Model Class Initialized
DEBUG - 2018-01-23 07:28:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:28:09 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-23 07:28:09 --> Final output sent to browser
DEBUG - 2018-01-23 07:28:09 --> Total execution time: 0.0393
INFO - 2018-01-23 07:28:10 --> Config Class Initialized
INFO - 2018-01-23 07:28:10 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:28:10 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:28:10 --> Utf8 Class Initialized
INFO - 2018-01-23 07:28:10 --> URI Class Initialized
INFO - 2018-01-23 07:28:10 --> Router Class Initialized
INFO - 2018-01-23 07:28:10 --> Output Class Initialized
INFO - 2018-01-23 07:28:10 --> Security Class Initialized
DEBUG - 2018-01-23 07:28:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:28:10 --> Input Class Initialized
INFO - 2018-01-23 07:28:10 --> Language Class Initialized
INFO - 2018-01-23 07:28:10 --> Loader Class Initialized
INFO - 2018-01-23 07:28:10 --> Helper loaded: url_helper
INFO - 2018-01-23 07:28:10 --> Helper loaded: form_helper
INFO - 2018-01-23 07:28:10 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:28:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:28:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:28:10 --> Form Validation Class Initialized
INFO - 2018-01-23 07:28:10 --> Model Class Initialized
INFO - 2018-01-23 07:28:10 --> Controller Class Initialized
INFO - 2018-01-23 07:28:10 --> Model Class Initialized
INFO - 2018-01-23 07:28:10 --> Model Class Initialized
DEBUG - 2018-01-23 07:28:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:28:16 --> Config Class Initialized
INFO - 2018-01-23 07:28:16 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:28:16 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:28:16 --> Utf8 Class Initialized
INFO - 2018-01-23 07:28:16 --> URI Class Initialized
INFO - 2018-01-23 07:28:16 --> Router Class Initialized
INFO - 2018-01-23 07:28:16 --> Output Class Initialized
INFO - 2018-01-23 07:28:16 --> Security Class Initialized
DEBUG - 2018-01-23 07:28:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:28:16 --> Input Class Initialized
INFO - 2018-01-23 07:28:16 --> Language Class Initialized
INFO - 2018-01-23 07:28:16 --> Loader Class Initialized
INFO - 2018-01-23 07:28:16 --> Helper loaded: url_helper
INFO - 2018-01-23 07:28:16 --> Helper loaded: form_helper
INFO - 2018-01-23 07:28:16 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:28:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:28:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:28:16 --> Form Validation Class Initialized
INFO - 2018-01-23 07:28:16 --> Model Class Initialized
INFO - 2018-01-23 07:28:16 --> Controller Class Initialized
INFO - 2018-01-23 07:28:16 --> Model Class Initialized
INFO - 2018-01-23 07:28:16 --> Model Class Initialized
DEBUG - 2018-01-23 07:28:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:29:21 --> Config Class Initialized
INFO - 2018-01-23 07:29:21 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:29:21 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:29:21 --> Utf8 Class Initialized
INFO - 2018-01-23 07:29:21 --> URI Class Initialized
INFO - 2018-01-23 07:29:21 --> Router Class Initialized
INFO - 2018-01-23 07:29:21 --> Output Class Initialized
INFO - 2018-01-23 07:29:21 --> Security Class Initialized
DEBUG - 2018-01-23 07:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:29:21 --> Input Class Initialized
INFO - 2018-01-23 07:29:21 --> Language Class Initialized
INFO - 2018-01-23 07:29:21 --> Loader Class Initialized
INFO - 2018-01-23 07:29:21 --> Helper loaded: url_helper
INFO - 2018-01-23 07:29:21 --> Helper loaded: form_helper
INFO - 2018-01-23 07:29:21 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:29:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:29:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:29:21 --> Form Validation Class Initialized
INFO - 2018-01-23 07:29:21 --> Model Class Initialized
INFO - 2018-01-23 07:29:21 --> Controller Class Initialized
INFO - 2018-01-23 07:29:21 --> Model Class Initialized
INFO - 2018-01-23 07:29:21 --> Model Class Initialized
DEBUG - 2018-01-23 07:29:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:29:21 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-23 07:29:21 --> Final output sent to browser
DEBUG - 2018-01-23 07:29:21 --> Total execution time: 0.0527
INFO - 2018-01-23 07:29:22 --> Config Class Initialized
INFO - 2018-01-23 07:29:22 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:29:22 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:29:22 --> Utf8 Class Initialized
INFO - 2018-01-23 07:29:22 --> URI Class Initialized
INFO - 2018-01-23 07:29:22 --> Router Class Initialized
INFO - 2018-01-23 07:29:22 --> Output Class Initialized
INFO - 2018-01-23 07:29:22 --> Security Class Initialized
DEBUG - 2018-01-23 07:29:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:29:22 --> Input Class Initialized
INFO - 2018-01-23 07:29:22 --> Language Class Initialized
INFO - 2018-01-23 07:29:22 --> Loader Class Initialized
INFO - 2018-01-23 07:29:22 --> Helper loaded: url_helper
INFO - 2018-01-23 07:29:22 --> Helper loaded: form_helper
INFO - 2018-01-23 07:29:22 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:29:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:29:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:29:22 --> Form Validation Class Initialized
INFO - 2018-01-23 07:29:22 --> Model Class Initialized
INFO - 2018-01-23 07:29:22 --> Controller Class Initialized
INFO - 2018-01-23 07:29:22 --> Model Class Initialized
INFO - 2018-01-23 07:29:22 --> Model Class Initialized
DEBUG - 2018-01-23 07:29:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:29:23 --> Config Class Initialized
INFO - 2018-01-23 07:29:23 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:29:23 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:29:23 --> Utf8 Class Initialized
INFO - 2018-01-23 07:29:23 --> URI Class Initialized
INFO - 2018-01-23 07:29:23 --> Router Class Initialized
INFO - 2018-01-23 07:29:23 --> Output Class Initialized
INFO - 2018-01-23 07:29:23 --> Security Class Initialized
DEBUG - 2018-01-23 07:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:29:23 --> Input Class Initialized
INFO - 2018-01-23 07:29:23 --> Language Class Initialized
INFO - 2018-01-23 07:29:23 --> Loader Class Initialized
INFO - 2018-01-23 07:29:23 --> Helper loaded: url_helper
INFO - 2018-01-23 07:29:23 --> Helper loaded: form_helper
INFO - 2018-01-23 07:29:23 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:29:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:29:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:29:23 --> Form Validation Class Initialized
INFO - 2018-01-23 07:29:23 --> Model Class Initialized
INFO - 2018-01-23 07:29:23 --> Controller Class Initialized
INFO - 2018-01-23 07:29:23 --> Model Class Initialized
DEBUG - 2018-01-23 07:29:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:29:23 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-23 07:29:23 --> Final output sent to browser
DEBUG - 2018-01-23 07:29:23 --> Total execution time: 0.0466
INFO - 2018-01-23 07:29:24 --> Config Class Initialized
INFO - 2018-01-23 07:29:24 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:29:24 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:29:24 --> Utf8 Class Initialized
INFO - 2018-01-23 07:29:24 --> URI Class Initialized
INFO - 2018-01-23 07:29:24 --> Router Class Initialized
INFO - 2018-01-23 07:29:24 --> Output Class Initialized
INFO - 2018-01-23 07:29:24 --> Security Class Initialized
DEBUG - 2018-01-23 07:29:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:29:24 --> Input Class Initialized
INFO - 2018-01-23 07:29:24 --> Language Class Initialized
INFO - 2018-01-23 07:29:24 --> Loader Class Initialized
INFO - 2018-01-23 07:29:24 --> Helper loaded: url_helper
INFO - 2018-01-23 07:29:24 --> Helper loaded: form_helper
INFO - 2018-01-23 07:29:24 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:29:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:29:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:29:24 --> Form Validation Class Initialized
INFO - 2018-01-23 07:29:24 --> Model Class Initialized
INFO - 2018-01-23 07:29:24 --> Controller Class Initialized
INFO - 2018-01-23 07:29:24 --> Model Class Initialized
DEBUG - 2018-01-23 07:29:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:29:29 --> Config Class Initialized
INFO - 2018-01-23 07:29:29 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:29:29 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:29:29 --> Utf8 Class Initialized
INFO - 2018-01-23 07:29:29 --> URI Class Initialized
INFO - 2018-01-23 07:29:29 --> Router Class Initialized
INFO - 2018-01-23 07:29:29 --> Output Class Initialized
INFO - 2018-01-23 07:29:29 --> Security Class Initialized
DEBUG - 2018-01-23 07:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:29:29 --> Input Class Initialized
INFO - 2018-01-23 07:29:29 --> Language Class Initialized
INFO - 2018-01-23 07:29:29 --> Loader Class Initialized
INFO - 2018-01-23 07:29:29 --> Helper loaded: url_helper
INFO - 2018-01-23 07:29:29 --> Helper loaded: form_helper
INFO - 2018-01-23 07:29:29 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:29:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:29:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:29:29 --> Form Validation Class Initialized
INFO - 2018-01-23 07:29:29 --> Model Class Initialized
INFO - 2018-01-23 07:29:29 --> Controller Class Initialized
INFO - 2018-01-23 07:29:29 --> Model Class Initialized
DEBUG - 2018-01-23 07:29:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:29:30 --> Config Class Initialized
INFO - 2018-01-23 07:29:30 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:29:30 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:29:30 --> Utf8 Class Initialized
INFO - 2018-01-23 07:29:30 --> URI Class Initialized
INFO - 2018-01-23 07:29:30 --> Router Class Initialized
INFO - 2018-01-23 07:29:30 --> Output Class Initialized
INFO - 2018-01-23 07:29:30 --> Security Class Initialized
DEBUG - 2018-01-23 07:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:29:30 --> Input Class Initialized
INFO - 2018-01-23 07:29:30 --> Language Class Initialized
INFO - 2018-01-23 07:29:30 --> Loader Class Initialized
INFO - 2018-01-23 07:29:30 --> Helper loaded: url_helper
INFO - 2018-01-23 07:29:30 --> Helper loaded: form_helper
INFO - 2018-01-23 07:29:30 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:29:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:29:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:29:30 --> Form Validation Class Initialized
INFO - 2018-01-23 07:29:30 --> Model Class Initialized
INFO - 2018-01-23 07:29:30 --> Controller Class Initialized
INFO - 2018-01-23 07:29:30 --> Model Class Initialized
DEBUG - 2018-01-23 07:29:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:29:30 --> Config Class Initialized
INFO - 2018-01-23 07:29:30 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:29:30 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:29:30 --> Utf8 Class Initialized
INFO - 2018-01-23 07:29:30 --> URI Class Initialized
INFO - 2018-01-23 07:29:30 --> Router Class Initialized
INFO - 2018-01-23 07:29:30 --> Output Class Initialized
INFO - 2018-01-23 07:29:30 --> Security Class Initialized
DEBUG - 2018-01-23 07:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:29:30 --> Input Class Initialized
INFO - 2018-01-23 07:29:30 --> Language Class Initialized
INFO - 2018-01-23 07:29:30 --> Loader Class Initialized
INFO - 2018-01-23 07:29:30 --> Helper loaded: url_helper
INFO - 2018-01-23 07:29:30 --> Helper loaded: form_helper
INFO - 2018-01-23 07:29:30 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:29:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:29:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:29:30 --> Form Validation Class Initialized
INFO - 2018-01-23 07:29:30 --> Model Class Initialized
INFO - 2018-01-23 07:29:30 --> Controller Class Initialized
INFO - 2018-01-23 07:29:30 --> Model Class Initialized
DEBUG - 2018-01-23 07:29:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:29:32 --> Config Class Initialized
INFO - 2018-01-23 07:29:32 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:29:32 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:29:32 --> Utf8 Class Initialized
INFO - 2018-01-23 07:29:32 --> URI Class Initialized
INFO - 2018-01-23 07:29:32 --> Router Class Initialized
INFO - 2018-01-23 07:29:32 --> Output Class Initialized
INFO - 2018-01-23 07:29:32 --> Security Class Initialized
DEBUG - 2018-01-23 07:29:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:29:32 --> Input Class Initialized
INFO - 2018-01-23 07:29:32 --> Language Class Initialized
INFO - 2018-01-23 07:29:32 --> Loader Class Initialized
INFO - 2018-01-23 07:29:32 --> Helper loaded: url_helper
INFO - 2018-01-23 07:29:32 --> Helper loaded: form_helper
INFO - 2018-01-23 07:29:32 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:29:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:29:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:29:32 --> Form Validation Class Initialized
INFO - 2018-01-23 07:29:32 --> Model Class Initialized
INFO - 2018-01-23 07:29:32 --> Controller Class Initialized
INFO - 2018-01-23 07:29:32 --> Model Class Initialized
DEBUG - 2018-01-23 07:29:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:29:32 --> Config Class Initialized
INFO - 2018-01-23 07:29:32 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:29:32 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:29:32 --> Utf8 Class Initialized
INFO - 2018-01-23 07:29:32 --> URI Class Initialized
INFO - 2018-01-23 07:29:32 --> Router Class Initialized
INFO - 2018-01-23 07:29:32 --> Output Class Initialized
INFO - 2018-01-23 07:29:32 --> Security Class Initialized
DEBUG - 2018-01-23 07:29:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:29:32 --> Input Class Initialized
INFO - 2018-01-23 07:29:32 --> Language Class Initialized
INFO - 2018-01-23 07:29:32 --> Loader Class Initialized
INFO - 2018-01-23 07:29:32 --> Helper loaded: url_helper
INFO - 2018-01-23 07:29:32 --> Helper loaded: form_helper
INFO - 2018-01-23 07:29:32 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:29:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:29:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:29:32 --> Form Validation Class Initialized
INFO - 2018-01-23 07:29:32 --> Model Class Initialized
INFO - 2018-01-23 07:29:32 --> Controller Class Initialized
INFO - 2018-01-23 07:29:32 --> Model Class Initialized
DEBUG - 2018-01-23 07:29:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:29:32 --> Config Class Initialized
INFO - 2018-01-23 07:29:33 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:29:33 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:29:33 --> Utf8 Class Initialized
INFO - 2018-01-23 07:29:33 --> URI Class Initialized
INFO - 2018-01-23 07:29:33 --> Router Class Initialized
INFO - 2018-01-23 07:29:33 --> Output Class Initialized
INFO - 2018-01-23 07:29:33 --> Security Class Initialized
DEBUG - 2018-01-23 07:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:29:33 --> Input Class Initialized
INFO - 2018-01-23 07:29:33 --> Language Class Initialized
INFO - 2018-01-23 07:29:33 --> Loader Class Initialized
INFO - 2018-01-23 07:29:33 --> Helper loaded: url_helper
INFO - 2018-01-23 07:29:33 --> Helper loaded: form_helper
INFO - 2018-01-23 07:29:33 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:29:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:29:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:29:33 --> Form Validation Class Initialized
INFO - 2018-01-23 07:29:33 --> Model Class Initialized
INFO - 2018-01-23 07:29:33 --> Controller Class Initialized
INFO - 2018-01-23 07:29:33 --> Model Class Initialized
DEBUG - 2018-01-23 07:29:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:29:37 --> Config Class Initialized
INFO - 2018-01-23 07:29:37 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:29:37 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:29:37 --> Utf8 Class Initialized
INFO - 2018-01-23 07:29:37 --> URI Class Initialized
INFO - 2018-01-23 07:29:37 --> Router Class Initialized
INFO - 2018-01-23 07:29:37 --> Output Class Initialized
INFO - 2018-01-23 07:29:37 --> Security Class Initialized
DEBUG - 2018-01-23 07:29:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:29:37 --> Input Class Initialized
INFO - 2018-01-23 07:29:37 --> Language Class Initialized
INFO - 2018-01-23 07:29:37 --> Loader Class Initialized
INFO - 2018-01-23 07:29:37 --> Helper loaded: url_helper
INFO - 2018-01-23 07:29:37 --> Helper loaded: form_helper
INFO - 2018-01-23 07:29:37 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:29:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:29:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:29:37 --> Form Validation Class Initialized
INFO - 2018-01-23 07:29:37 --> Model Class Initialized
INFO - 2018-01-23 07:29:37 --> Controller Class Initialized
INFO - 2018-01-23 07:29:37 --> Model Class Initialized
DEBUG - 2018-01-23 07:29:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:29:39 --> Config Class Initialized
INFO - 2018-01-23 07:29:39 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:29:39 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:29:39 --> Utf8 Class Initialized
INFO - 2018-01-23 07:29:39 --> URI Class Initialized
INFO - 2018-01-23 07:29:39 --> Router Class Initialized
INFO - 2018-01-23 07:29:39 --> Output Class Initialized
INFO - 2018-01-23 07:29:39 --> Security Class Initialized
DEBUG - 2018-01-23 07:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:29:39 --> Input Class Initialized
INFO - 2018-01-23 07:29:39 --> Language Class Initialized
INFO - 2018-01-23 07:29:39 --> Loader Class Initialized
INFO - 2018-01-23 07:29:39 --> Helper loaded: url_helper
INFO - 2018-01-23 07:29:39 --> Helper loaded: form_helper
INFO - 2018-01-23 07:29:39 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:29:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:29:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:29:39 --> Form Validation Class Initialized
INFO - 2018-01-23 07:29:39 --> Model Class Initialized
INFO - 2018-01-23 07:29:39 --> Controller Class Initialized
INFO - 2018-01-23 07:29:39 --> Model Class Initialized
DEBUG - 2018-01-23 07:29:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:31:14 --> Config Class Initialized
INFO - 2018-01-23 07:31:14 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:31:14 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:31:14 --> Utf8 Class Initialized
INFO - 2018-01-23 07:31:14 --> URI Class Initialized
INFO - 2018-01-23 07:31:14 --> Router Class Initialized
INFO - 2018-01-23 07:31:14 --> Output Class Initialized
INFO - 2018-01-23 07:31:14 --> Security Class Initialized
DEBUG - 2018-01-23 07:31:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:31:14 --> Input Class Initialized
INFO - 2018-01-23 07:31:14 --> Language Class Initialized
INFO - 2018-01-23 07:31:14 --> Loader Class Initialized
INFO - 2018-01-23 07:31:14 --> Helper loaded: url_helper
INFO - 2018-01-23 07:31:14 --> Helper loaded: form_helper
INFO - 2018-01-23 07:31:14 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:31:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:31:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:31:14 --> Form Validation Class Initialized
INFO - 2018-01-23 07:31:14 --> Model Class Initialized
INFO - 2018-01-23 07:31:14 --> Controller Class Initialized
INFO - 2018-01-23 07:31:14 --> Model Class Initialized
DEBUG - 2018-01-23 07:31:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:31:14 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-23 07:31:14 --> Final output sent to browser
DEBUG - 2018-01-23 07:31:14 --> Total execution time: 0.1086
INFO - 2018-01-23 07:31:16 --> Config Class Initialized
INFO - 2018-01-23 07:31:16 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:31:16 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:31:16 --> Utf8 Class Initialized
INFO - 2018-01-23 07:31:16 --> URI Class Initialized
INFO - 2018-01-23 07:31:16 --> Router Class Initialized
INFO - 2018-01-23 07:31:16 --> Output Class Initialized
INFO - 2018-01-23 07:31:16 --> Security Class Initialized
DEBUG - 2018-01-23 07:31:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:31:16 --> Input Class Initialized
INFO - 2018-01-23 07:31:16 --> Language Class Initialized
INFO - 2018-01-23 07:31:16 --> Loader Class Initialized
INFO - 2018-01-23 07:31:16 --> Helper loaded: url_helper
INFO - 2018-01-23 07:31:16 --> Helper loaded: form_helper
INFO - 2018-01-23 07:31:16 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:31:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:31:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:31:16 --> Form Validation Class Initialized
INFO - 2018-01-23 07:31:16 --> Model Class Initialized
INFO - 2018-01-23 07:31:16 --> Controller Class Initialized
INFO - 2018-01-23 07:31:16 --> Model Class Initialized
DEBUG - 2018-01-23 07:31:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:31:19 --> Config Class Initialized
INFO - 2018-01-23 07:31:19 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:31:19 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:31:19 --> Utf8 Class Initialized
INFO - 2018-01-23 07:31:19 --> URI Class Initialized
INFO - 2018-01-23 07:31:19 --> Router Class Initialized
INFO - 2018-01-23 07:31:19 --> Output Class Initialized
INFO - 2018-01-23 07:31:19 --> Security Class Initialized
DEBUG - 2018-01-23 07:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:31:19 --> Input Class Initialized
INFO - 2018-01-23 07:31:19 --> Language Class Initialized
INFO - 2018-01-23 07:31:19 --> Loader Class Initialized
INFO - 2018-01-23 07:31:19 --> Helper loaded: url_helper
INFO - 2018-01-23 07:31:19 --> Helper loaded: form_helper
INFO - 2018-01-23 07:31:19 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:31:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:31:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:31:19 --> Form Validation Class Initialized
INFO - 2018-01-23 07:31:19 --> Model Class Initialized
INFO - 2018-01-23 07:31:19 --> Controller Class Initialized
INFO - 2018-01-23 07:31:19 --> Model Class Initialized
DEBUG - 2018-01-23 07:31:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:31:22 --> Config Class Initialized
INFO - 2018-01-23 07:31:22 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:31:22 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:31:22 --> Utf8 Class Initialized
INFO - 2018-01-23 07:31:22 --> URI Class Initialized
INFO - 2018-01-23 07:31:22 --> Router Class Initialized
INFO - 2018-01-23 07:31:22 --> Output Class Initialized
INFO - 2018-01-23 07:31:22 --> Security Class Initialized
DEBUG - 2018-01-23 07:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:31:22 --> Input Class Initialized
INFO - 2018-01-23 07:31:22 --> Language Class Initialized
INFO - 2018-01-23 07:31:22 --> Loader Class Initialized
INFO - 2018-01-23 07:31:22 --> Helper loaded: url_helper
INFO - 2018-01-23 07:31:22 --> Helper loaded: form_helper
INFO - 2018-01-23 07:31:22 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:31:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:31:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:31:22 --> Form Validation Class Initialized
INFO - 2018-01-23 07:31:22 --> Model Class Initialized
INFO - 2018-01-23 07:31:22 --> Controller Class Initialized
INFO - 2018-01-23 07:31:22 --> Model Class Initialized
DEBUG - 2018-01-23 07:31:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:31:25 --> Config Class Initialized
INFO - 2018-01-23 07:31:25 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:31:25 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:31:25 --> Utf8 Class Initialized
INFO - 2018-01-23 07:31:25 --> URI Class Initialized
INFO - 2018-01-23 07:31:25 --> Router Class Initialized
INFO - 2018-01-23 07:31:25 --> Output Class Initialized
INFO - 2018-01-23 07:31:25 --> Security Class Initialized
DEBUG - 2018-01-23 07:31:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:31:25 --> Input Class Initialized
INFO - 2018-01-23 07:31:25 --> Language Class Initialized
INFO - 2018-01-23 07:31:25 --> Loader Class Initialized
INFO - 2018-01-23 07:31:25 --> Helper loaded: url_helper
INFO - 2018-01-23 07:31:25 --> Helper loaded: form_helper
INFO - 2018-01-23 07:31:25 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:31:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:31:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:31:25 --> Form Validation Class Initialized
INFO - 2018-01-23 07:31:25 --> Model Class Initialized
INFO - 2018-01-23 07:31:25 --> Controller Class Initialized
INFO - 2018-01-23 07:31:25 --> Model Class Initialized
DEBUG - 2018-01-23 07:31:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:31:29 --> Config Class Initialized
INFO - 2018-01-23 07:31:29 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:31:29 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:31:29 --> Utf8 Class Initialized
INFO - 2018-01-23 07:31:29 --> URI Class Initialized
INFO - 2018-01-23 07:31:29 --> Router Class Initialized
INFO - 2018-01-23 07:31:29 --> Output Class Initialized
INFO - 2018-01-23 07:31:29 --> Security Class Initialized
DEBUG - 2018-01-23 07:31:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:31:29 --> Input Class Initialized
INFO - 2018-01-23 07:31:29 --> Language Class Initialized
INFO - 2018-01-23 07:31:29 --> Loader Class Initialized
INFO - 2018-01-23 07:31:29 --> Helper loaded: url_helper
INFO - 2018-01-23 07:31:29 --> Helper loaded: form_helper
INFO - 2018-01-23 07:31:29 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:31:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:31:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:31:29 --> Form Validation Class Initialized
INFO - 2018-01-23 07:31:29 --> Model Class Initialized
INFO - 2018-01-23 07:31:29 --> Controller Class Initialized
INFO - 2018-01-23 07:31:29 --> Model Class Initialized
DEBUG - 2018-01-23 07:31:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:31:31 --> Config Class Initialized
INFO - 2018-01-23 07:31:31 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:31:31 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:31:31 --> Utf8 Class Initialized
INFO - 2018-01-23 07:31:31 --> URI Class Initialized
INFO - 2018-01-23 07:31:31 --> Router Class Initialized
INFO - 2018-01-23 07:31:31 --> Output Class Initialized
INFO - 2018-01-23 07:31:31 --> Security Class Initialized
DEBUG - 2018-01-23 07:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:31:31 --> Input Class Initialized
INFO - 2018-01-23 07:31:31 --> Language Class Initialized
INFO - 2018-01-23 07:31:31 --> Loader Class Initialized
INFO - 2018-01-23 07:31:31 --> Helper loaded: url_helper
INFO - 2018-01-23 07:31:31 --> Helper loaded: form_helper
INFO - 2018-01-23 07:31:31 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:31:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:31:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:31:31 --> Form Validation Class Initialized
INFO - 2018-01-23 07:31:31 --> Model Class Initialized
INFO - 2018-01-23 07:31:31 --> Controller Class Initialized
INFO - 2018-01-23 07:31:31 --> Model Class Initialized
DEBUG - 2018-01-23 07:31:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:33:38 --> Config Class Initialized
INFO - 2018-01-23 07:33:38 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:33:38 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:33:38 --> Utf8 Class Initialized
INFO - 2018-01-23 07:33:38 --> URI Class Initialized
INFO - 2018-01-23 07:33:38 --> Router Class Initialized
INFO - 2018-01-23 07:33:38 --> Output Class Initialized
INFO - 2018-01-23 07:33:38 --> Security Class Initialized
DEBUG - 2018-01-23 07:33:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:33:38 --> Input Class Initialized
INFO - 2018-01-23 07:33:38 --> Language Class Initialized
INFO - 2018-01-23 07:33:38 --> Loader Class Initialized
INFO - 2018-01-23 07:33:38 --> Helper loaded: url_helper
INFO - 2018-01-23 07:33:38 --> Helper loaded: form_helper
INFO - 2018-01-23 07:33:38 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:33:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:33:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:33:38 --> Form Validation Class Initialized
INFO - 2018-01-23 07:33:38 --> Model Class Initialized
INFO - 2018-01-23 07:33:38 --> Controller Class Initialized
INFO - 2018-01-23 07:33:38 --> Model Class Initialized
DEBUG - 2018-01-23 07:33:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:33:54 --> Config Class Initialized
INFO - 2018-01-23 07:33:54 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:33:54 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:33:54 --> Utf8 Class Initialized
INFO - 2018-01-23 07:33:54 --> URI Class Initialized
INFO - 2018-01-23 07:33:54 --> Router Class Initialized
INFO - 2018-01-23 07:33:54 --> Output Class Initialized
INFO - 2018-01-23 07:33:54 --> Security Class Initialized
DEBUG - 2018-01-23 07:33:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:33:54 --> Input Class Initialized
INFO - 2018-01-23 07:33:54 --> Language Class Initialized
INFO - 2018-01-23 07:33:54 --> Loader Class Initialized
INFO - 2018-01-23 07:33:54 --> Helper loaded: url_helper
INFO - 2018-01-23 07:33:54 --> Helper loaded: form_helper
INFO - 2018-01-23 07:33:54 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:33:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:33:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:33:54 --> Form Validation Class Initialized
INFO - 2018-01-23 07:33:54 --> Model Class Initialized
INFO - 2018-01-23 07:33:54 --> Controller Class Initialized
INFO - 2018-01-23 07:33:54 --> Model Class Initialized
DEBUG - 2018-01-23 07:33:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:33:54 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-23 07:33:54 --> Final output sent to browser
DEBUG - 2018-01-23 07:33:54 --> Total execution time: 0.0390
INFO - 2018-01-23 07:33:55 --> Config Class Initialized
INFO - 2018-01-23 07:33:55 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:33:55 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:33:55 --> Utf8 Class Initialized
INFO - 2018-01-23 07:33:55 --> URI Class Initialized
INFO - 2018-01-23 07:33:55 --> Router Class Initialized
INFO - 2018-01-23 07:33:55 --> Output Class Initialized
INFO - 2018-01-23 07:33:55 --> Security Class Initialized
DEBUG - 2018-01-23 07:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:33:55 --> Input Class Initialized
INFO - 2018-01-23 07:33:55 --> Language Class Initialized
INFO - 2018-01-23 07:33:55 --> Loader Class Initialized
INFO - 2018-01-23 07:33:55 --> Helper loaded: url_helper
INFO - 2018-01-23 07:33:55 --> Helper loaded: form_helper
INFO - 2018-01-23 07:33:55 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:33:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:33:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:33:55 --> Form Validation Class Initialized
INFO - 2018-01-23 07:33:55 --> Model Class Initialized
INFO - 2018-01-23 07:33:55 --> Controller Class Initialized
INFO - 2018-01-23 07:33:55 --> Model Class Initialized
DEBUG - 2018-01-23 07:33:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:34:04 --> Config Class Initialized
INFO - 2018-01-23 07:34:04 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:34:04 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:34:04 --> Utf8 Class Initialized
INFO - 2018-01-23 07:34:04 --> URI Class Initialized
INFO - 2018-01-23 07:34:04 --> Router Class Initialized
INFO - 2018-01-23 07:34:04 --> Output Class Initialized
INFO - 2018-01-23 07:34:04 --> Security Class Initialized
DEBUG - 2018-01-23 07:34:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:34:04 --> Input Class Initialized
INFO - 2018-01-23 07:34:04 --> Language Class Initialized
INFO - 2018-01-23 07:34:04 --> Loader Class Initialized
INFO - 2018-01-23 07:34:04 --> Helper loaded: url_helper
INFO - 2018-01-23 07:34:04 --> Helper loaded: form_helper
INFO - 2018-01-23 07:34:04 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:34:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:34:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:34:04 --> Form Validation Class Initialized
INFO - 2018-01-23 07:34:04 --> Model Class Initialized
INFO - 2018-01-23 07:34:04 --> Controller Class Initialized
INFO - 2018-01-23 07:34:04 --> Model Class Initialized
DEBUG - 2018-01-23 07:34:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:34:09 --> Config Class Initialized
INFO - 2018-01-23 07:34:09 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:34:09 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:34:09 --> Utf8 Class Initialized
INFO - 2018-01-23 07:34:09 --> URI Class Initialized
INFO - 2018-01-23 07:34:09 --> Router Class Initialized
INFO - 2018-01-23 07:34:09 --> Output Class Initialized
INFO - 2018-01-23 07:34:09 --> Security Class Initialized
DEBUG - 2018-01-23 07:34:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:34:09 --> Input Class Initialized
INFO - 2018-01-23 07:34:09 --> Language Class Initialized
INFO - 2018-01-23 07:34:09 --> Loader Class Initialized
INFO - 2018-01-23 07:34:09 --> Helper loaded: url_helper
INFO - 2018-01-23 07:34:09 --> Helper loaded: form_helper
INFO - 2018-01-23 07:34:09 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:34:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:34:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:34:09 --> Form Validation Class Initialized
INFO - 2018-01-23 07:34:09 --> Model Class Initialized
INFO - 2018-01-23 07:34:09 --> Controller Class Initialized
INFO - 2018-01-23 07:34:09 --> Model Class Initialized
DEBUG - 2018-01-23 07:34:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:34:16 --> Config Class Initialized
INFO - 2018-01-23 07:34:16 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:34:16 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:34:16 --> Utf8 Class Initialized
INFO - 2018-01-23 07:34:16 --> URI Class Initialized
INFO - 2018-01-23 07:34:16 --> Router Class Initialized
INFO - 2018-01-23 07:34:16 --> Output Class Initialized
INFO - 2018-01-23 07:34:16 --> Security Class Initialized
DEBUG - 2018-01-23 07:34:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:34:16 --> Input Class Initialized
INFO - 2018-01-23 07:34:16 --> Language Class Initialized
INFO - 2018-01-23 07:34:16 --> Loader Class Initialized
INFO - 2018-01-23 07:34:16 --> Helper loaded: url_helper
INFO - 2018-01-23 07:34:16 --> Helper loaded: form_helper
INFO - 2018-01-23 07:34:16 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:34:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:34:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:34:16 --> Form Validation Class Initialized
INFO - 2018-01-23 07:34:16 --> Model Class Initialized
INFO - 2018-01-23 07:34:16 --> Controller Class Initialized
INFO - 2018-01-23 07:34:16 --> Model Class Initialized
DEBUG - 2018-01-23 07:34:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:34:19 --> Config Class Initialized
INFO - 2018-01-23 07:34:19 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:34:19 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:34:19 --> Utf8 Class Initialized
INFO - 2018-01-23 07:34:19 --> URI Class Initialized
INFO - 2018-01-23 07:34:19 --> Router Class Initialized
INFO - 2018-01-23 07:34:19 --> Output Class Initialized
INFO - 2018-01-23 07:34:19 --> Security Class Initialized
DEBUG - 2018-01-23 07:34:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:34:19 --> Input Class Initialized
INFO - 2018-01-23 07:34:19 --> Language Class Initialized
INFO - 2018-01-23 07:34:19 --> Loader Class Initialized
INFO - 2018-01-23 07:34:19 --> Helper loaded: url_helper
INFO - 2018-01-23 07:34:19 --> Helper loaded: form_helper
INFO - 2018-01-23 07:34:19 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:34:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:34:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:34:19 --> Form Validation Class Initialized
INFO - 2018-01-23 07:34:19 --> Model Class Initialized
INFO - 2018-01-23 07:34:19 --> Controller Class Initialized
INFO - 2018-01-23 07:34:19 --> Model Class Initialized
DEBUG - 2018-01-23 07:34:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:34:23 --> Config Class Initialized
INFO - 2018-01-23 07:34:23 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:34:23 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:34:23 --> Utf8 Class Initialized
INFO - 2018-01-23 07:34:23 --> URI Class Initialized
INFO - 2018-01-23 07:34:23 --> Router Class Initialized
INFO - 2018-01-23 07:34:23 --> Output Class Initialized
INFO - 2018-01-23 07:34:23 --> Security Class Initialized
DEBUG - 2018-01-23 07:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:34:23 --> Input Class Initialized
INFO - 2018-01-23 07:34:23 --> Language Class Initialized
INFO - 2018-01-23 07:34:23 --> Loader Class Initialized
INFO - 2018-01-23 07:34:23 --> Helper loaded: url_helper
INFO - 2018-01-23 07:34:23 --> Helper loaded: form_helper
INFO - 2018-01-23 07:34:23 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:34:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:34:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:34:23 --> Form Validation Class Initialized
INFO - 2018-01-23 07:34:23 --> Model Class Initialized
INFO - 2018-01-23 07:34:23 --> Controller Class Initialized
INFO - 2018-01-23 07:34:23 --> Model Class Initialized
DEBUG - 2018-01-23 07:34:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:34:23 --> Config Class Initialized
INFO - 2018-01-23 07:34:23 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:34:23 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:34:23 --> Utf8 Class Initialized
INFO - 2018-01-23 07:34:23 --> URI Class Initialized
INFO - 2018-01-23 07:34:23 --> Router Class Initialized
INFO - 2018-01-23 07:34:23 --> Output Class Initialized
INFO - 2018-01-23 07:34:23 --> Security Class Initialized
DEBUG - 2018-01-23 07:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:34:23 --> Input Class Initialized
INFO - 2018-01-23 07:34:23 --> Language Class Initialized
INFO - 2018-01-23 07:34:23 --> Loader Class Initialized
INFO - 2018-01-23 07:34:23 --> Helper loaded: url_helper
INFO - 2018-01-23 07:34:23 --> Helper loaded: form_helper
INFO - 2018-01-23 07:34:23 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:34:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:34:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:34:23 --> Form Validation Class Initialized
INFO - 2018-01-23 07:34:23 --> Model Class Initialized
INFO - 2018-01-23 07:34:23 --> Controller Class Initialized
INFO - 2018-01-23 07:34:23 --> Model Class Initialized
DEBUG - 2018-01-23 07:34:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:34:24 --> Config Class Initialized
INFO - 2018-01-23 07:34:24 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:34:24 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:34:24 --> Utf8 Class Initialized
INFO - 2018-01-23 07:34:24 --> URI Class Initialized
INFO - 2018-01-23 07:34:24 --> Router Class Initialized
INFO - 2018-01-23 07:34:24 --> Output Class Initialized
INFO - 2018-01-23 07:34:24 --> Security Class Initialized
DEBUG - 2018-01-23 07:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:34:24 --> Input Class Initialized
INFO - 2018-01-23 07:34:24 --> Language Class Initialized
INFO - 2018-01-23 07:34:24 --> Loader Class Initialized
INFO - 2018-01-23 07:34:24 --> Helper loaded: url_helper
INFO - 2018-01-23 07:34:24 --> Helper loaded: form_helper
INFO - 2018-01-23 07:34:24 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:34:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:34:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:34:24 --> Form Validation Class Initialized
INFO - 2018-01-23 07:34:24 --> Model Class Initialized
INFO - 2018-01-23 07:34:24 --> Controller Class Initialized
INFO - 2018-01-23 07:34:24 --> Model Class Initialized
DEBUG - 2018-01-23 07:34:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:35:43 --> Config Class Initialized
INFO - 2018-01-23 07:35:43 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:35:43 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:35:43 --> Utf8 Class Initialized
INFO - 2018-01-23 07:35:43 --> URI Class Initialized
INFO - 2018-01-23 07:35:43 --> Router Class Initialized
INFO - 2018-01-23 07:35:43 --> Output Class Initialized
INFO - 2018-01-23 07:35:43 --> Security Class Initialized
DEBUG - 2018-01-23 07:35:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:35:43 --> Input Class Initialized
INFO - 2018-01-23 07:35:43 --> Language Class Initialized
INFO - 2018-01-23 07:35:43 --> Loader Class Initialized
INFO - 2018-01-23 07:35:43 --> Helper loaded: url_helper
INFO - 2018-01-23 07:35:43 --> Helper loaded: form_helper
INFO - 2018-01-23 07:35:43 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:35:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:35:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:35:43 --> Form Validation Class Initialized
INFO - 2018-01-23 07:35:43 --> Model Class Initialized
INFO - 2018-01-23 07:35:43 --> Controller Class Initialized
INFO - 2018-01-23 07:35:43 --> Model Class Initialized
DEBUG - 2018-01-23 07:35:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:35:55 --> Config Class Initialized
INFO - 2018-01-23 07:35:55 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:35:55 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:35:55 --> Utf8 Class Initialized
INFO - 2018-01-23 07:35:55 --> URI Class Initialized
INFO - 2018-01-23 07:35:55 --> Router Class Initialized
INFO - 2018-01-23 07:35:55 --> Output Class Initialized
INFO - 2018-01-23 07:35:55 --> Security Class Initialized
DEBUG - 2018-01-23 07:35:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:35:55 --> Input Class Initialized
INFO - 2018-01-23 07:35:55 --> Language Class Initialized
INFO - 2018-01-23 07:35:55 --> Loader Class Initialized
INFO - 2018-01-23 07:35:55 --> Helper loaded: url_helper
INFO - 2018-01-23 07:35:55 --> Helper loaded: form_helper
INFO - 2018-01-23 07:35:56 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:35:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:35:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:35:56 --> Form Validation Class Initialized
INFO - 2018-01-23 07:35:56 --> Model Class Initialized
INFO - 2018-01-23 07:35:56 --> Controller Class Initialized
INFO - 2018-01-23 07:35:56 --> Model Class Initialized
DEBUG - 2018-01-23 07:35:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:36:02 --> Config Class Initialized
INFO - 2018-01-23 07:36:02 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:36:02 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:36:02 --> Utf8 Class Initialized
INFO - 2018-01-23 07:36:02 --> URI Class Initialized
INFO - 2018-01-23 07:36:02 --> Router Class Initialized
INFO - 2018-01-23 07:36:02 --> Output Class Initialized
INFO - 2018-01-23 07:36:02 --> Security Class Initialized
DEBUG - 2018-01-23 07:36:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:36:02 --> Input Class Initialized
INFO - 2018-01-23 07:36:02 --> Language Class Initialized
INFO - 2018-01-23 07:36:02 --> Loader Class Initialized
INFO - 2018-01-23 07:36:02 --> Helper loaded: url_helper
INFO - 2018-01-23 07:36:02 --> Helper loaded: form_helper
INFO - 2018-01-23 07:36:02 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:36:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:36:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:36:02 --> Form Validation Class Initialized
INFO - 2018-01-23 07:36:02 --> Model Class Initialized
INFO - 2018-01-23 07:36:02 --> Controller Class Initialized
INFO - 2018-01-23 07:36:02 --> Model Class Initialized
DEBUG - 2018-01-23 07:36:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:36:05 --> Config Class Initialized
INFO - 2018-01-23 07:36:05 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:36:05 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:36:05 --> Utf8 Class Initialized
INFO - 2018-01-23 07:36:05 --> URI Class Initialized
INFO - 2018-01-23 07:36:05 --> Router Class Initialized
INFO - 2018-01-23 07:36:05 --> Output Class Initialized
INFO - 2018-01-23 07:36:05 --> Security Class Initialized
DEBUG - 2018-01-23 07:36:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:36:05 --> Input Class Initialized
INFO - 2018-01-23 07:36:05 --> Language Class Initialized
INFO - 2018-01-23 07:36:05 --> Loader Class Initialized
INFO - 2018-01-23 07:36:05 --> Helper loaded: url_helper
INFO - 2018-01-23 07:36:05 --> Helper loaded: form_helper
INFO - 2018-01-23 07:36:05 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:36:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:36:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:36:05 --> Form Validation Class Initialized
INFO - 2018-01-23 07:36:05 --> Model Class Initialized
INFO - 2018-01-23 07:36:05 --> Controller Class Initialized
INFO - 2018-01-23 07:36:05 --> Model Class Initialized
DEBUG - 2018-01-23 07:36:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:36:08 --> Config Class Initialized
INFO - 2018-01-23 07:36:08 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:36:08 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:36:08 --> Utf8 Class Initialized
INFO - 2018-01-23 07:36:08 --> URI Class Initialized
INFO - 2018-01-23 07:36:08 --> Router Class Initialized
INFO - 2018-01-23 07:36:08 --> Output Class Initialized
INFO - 2018-01-23 07:36:08 --> Security Class Initialized
DEBUG - 2018-01-23 07:36:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:36:08 --> Input Class Initialized
INFO - 2018-01-23 07:36:08 --> Language Class Initialized
INFO - 2018-01-23 07:36:08 --> Loader Class Initialized
INFO - 2018-01-23 07:36:08 --> Helper loaded: url_helper
INFO - 2018-01-23 07:36:08 --> Helper loaded: form_helper
INFO - 2018-01-23 07:36:08 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:36:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:36:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:36:08 --> Form Validation Class Initialized
INFO - 2018-01-23 07:36:08 --> Model Class Initialized
INFO - 2018-01-23 07:36:08 --> Controller Class Initialized
INFO - 2018-01-23 07:36:08 --> Model Class Initialized
DEBUG - 2018-01-23 07:36:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:36:29 --> Config Class Initialized
INFO - 2018-01-23 07:36:29 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:36:29 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:36:29 --> Utf8 Class Initialized
INFO - 2018-01-23 07:36:29 --> URI Class Initialized
INFO - 2018-01-23 07:36:29 --> Router Class Initialized
INFO - 2018-01-23 07:36:29 --> Output Class Initialized
INFO - 2018-01-23 07:36:29 --> Security Class Initialized
DEBUG - 2018-01-23 07:36:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:36:29 --> Input Class Initialized
INFO - 2018-01-23 07:36:29 --> Language Class Initialized
INFO - 2018-01-23 07:36:29 --> Loader Class Initialized
INFO - 2018-01-23 07:36:29 --> Helper loaded: url_helper
INFO - 2018-01-23 07:36:29 --> Helper loaded: form_helper
INFO - 2018-01-23 07:36:29 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:36:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:36:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:36:29 --> Form Validation Class Initialized
INFO - 2018-01-23 07:36:29 --> Model Class Initialized
INFO - 2018-01-23 07:36:29 --> Controller Class Initialized
INFO - 2018-01-23 07:36:29 --> Model Class Initialized
DEBUG - 2018-01-23 07:36:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:36:29 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-23 07:36:29 --> Final output sent to browser
DEBUG - 2018-01-23 07:36:29 --> Total execution time: 0.0377
INFO - 2018-01-23 07:36:30 --> Config Class Initialized
INFO - 2018-01-23 07:36:30 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:36:30 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:36:30 --> Utf8 Class Initialized
INFO - 2018-01-23 07:36:30 --> URI Class Initialized
INFO - 2018-01-23 07:36:30 --> Router Class Initialized
INFO - 2018-01-23 07:36:30 --> Output Class Initialized
INFO - 2018-01-23 07:36:30 --> Security Class Initialized
DEBUG - 2018-01-23 07:36:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:36:30 --> Input Class Initialized
INFO - 2018-01-23 07:36:31 --> Language Class Initialized
INFO - 2018-01-23 07:36:31 --> Loader Class Initialized
INFO - 2018-01-23 07:36:31 --> Helper loaded: url_helper
INFO - 2018-01-23 07:36:31 --> Helper loaded: form_helper
INFO - 2018-01-23 07:36:31 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:36:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:36:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:36:31 --> Form Validation Class Initialized
INFO - 2018-01-23 07:36:31 --> Model Class Initialized
INFO - 2018-01-23 07:36:31 --> Controller Class Initialized
INFO - 2018-01-23 07:36:31 --> Model Class Initialized
DEBUG - 2018-01-23 07:36:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:36:42 --> Config Class Initialized
INFO - 2018-01-23 07:36:42 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:36:42 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:36:42 --> Utf8 Class Initialized
INFO - 2018-01-23 07:36:42 --> URI Class Initialized
INFO - 2018-01-23 07:36:42 --> Router Class Initialized
INFO - 2018-01-23 07:36:42 --> Output Class Initialized
INFO - 2018-01-23 07:36:42 --> Security Class Initialized
DEBUG - 2018-01-23 07:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:36:42 --> Input Class Initialized
INFO - 2018-01-23 07:36:42 --> Language Class Initialized
INFO - 2018-01-23 07:36:42 --> Loader Class Initialized
INFO - 2018-01-23 07:36:42 --> Helper loaded: url_helper
INFO - 2018-01-23 07:36:42 --> Helper loaded: form_helper
INFO - 2018-01-23 07:36:42 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:36:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:36:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:36:42 --> Form Validation Class Initialized
INFO - 2018-01-23 07:36:42 --> Model Class Initialized
INFO - 2018-01-23 07:36:42 --> Controller Class Initialized
INFO - 2018-01-23 07:36:42 --> Model Class Initialized
DEBUG - 2018-01-23 07:36:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:37:40 --> Config Class Initialized
INFO - 2018-01-23 07:37:40 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:37:40 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:37:40 --> Utf8 Class Initialized
INFO - 2018-01-23 07:37:40 --> URI Class Initialized
INFO - 2018-01-23 07:37:40 --> Router Class Initialized
INFO - 2018-01-23 07:37:40 --> Output Class Initialized
INFO - 2018-01-23 07:37:40 --> Security Class Initialized
DEBUG - 2018-01-23 07:37:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:37:40 --> Input Class Initialized
INFO - 2018-01-23 07:37:40 --> Language Class Initialized
INFO - 2018-01-23 07:37:40 --> Loader Class Initialized
INFO - 2018-01-23 07:37:40 --> Helper loaded: url_helper
INFO - 2018-01-23 07:37:40 --> Helper loaded: form_helper
INFO - 2018-01-23 07:37:40 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:37:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:37:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:37:40 --> Form Validation Class Initialized
INFO - 2018-01-23 07:37:40 --> Model Class Initialized
INFO - 2018-01-23 07:37:40 --> Controller Class Initialized
INFO - 2018-01-23 07:37:40 --> Model Class Initialized
DEBUG - 2018-01-23 07:37:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:38:48 --> Config Class Initialized
INFO - 2018-01-23 07:38:48 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:38:48 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:38:48 --> Utf8 Class Initialized
INFO - 2018-01-23 07:38:48 --> URI Class Initialized
INFO - 2018-01-23 07:38:48 --> Router Class Initialized
INFO - 2018-01-23 07:38:48 --> Output Class Initialized
INFO - 2018-01-23 07:38:48 --> Security Class Initialized
DEBUG - 2018-01-23 07:38:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:38:48 --> Input Class Initialized
INFO - 2018-01-23 07:38:48 --> Language Class Initialized
INFO - 2018-01-23 07:38:48 --> Loader Class Initialized
INFO - 2018-01-23 07:38:48 --> Helper loaded: url_helper
INFO - 2018-01-23 07:38:48 --> Helper loaded: form_helper
INFO - 2018-01-23 07:38:48 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:38:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:38:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:38:48 --> Form Validation Class Initialized
INFO - 2018-01-23 07:38:48 --> Model Class Initialized
INFO - 2018-01-23 07:38:48 --> Controller Class Initialized
INFO - 2018-01-23 07:38:48 --> Model Class Initialized
DEBUG - 2018-01-23 07:38:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:38:48 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-23 07:38:48 --> Final output sent to browser
DEBUG - 2018-01-23 07:38:48 --> Total execution time: 0.0432
INFO - 2018-01-23 07:38:49 --> Config Class Initialized
INFO - 2018-01-23 07:38:49 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:38:49 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:38:49 --> Utf8 Class Initialized
INFO - 2018-01-23 07:38:49 --> URI Class Initialized
INFO - 2018-01-23 07:38:49 --> Router Class Initialized
INFO - 2018-01-23 07:38:49 --> Output Class Initialized
INFO - 2018-01-23 07:38:49 --> Security Class Initialized
DEBUG - 2018-01-23 07:38:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:38:49 --> Input Class Initialized
INFO - 2018-01-23 07:38:49 --> Language Class Initialized
INFO - 2018-01-23 07:38:49 --> Loader Class Initialized
INFO - 2018-01-23 07:38:49 --> Helper loaded: url_helper
INFO - 2018-01-23 07:38:49 --> Helper loaded: form_helper
INFO - 2018-01-23 07:38:49 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:38:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:38:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:38:49 --> Form Validation Class Initialized
INFO - 2018-01-23 07:38:49 --> Model Class Initialized
INFO - 2018-01-23 07:38:49 --> Controller Class Initialized
INFO - 2018-01-23 07:38:49 --> Model Class Initialized
DEBUG - 2018-01-23 07:38:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:38:53 --> Config Class Initialized
INFO - 2018-01-23 07:38:53 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:38:53 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:38:53 --> Utf8 Class Initialized
INFO - 2018-01-23 07:38:53 --> URI Class Initialized
INFO - 2018-01-23 07:38:53 --> Router Class Initialized
INFO - 2018-01-23 07:38:53 --> Output Class Initialized
INFO - 2018-01-23 07:38:53 --> Security Class Initialized
DEBUG - 2018-01-23 07:38:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:38:53 --> Input Class Initialized
INFO - 2018-01-23 07:38:53 --> Language Class Initialized
INFO - 2018-01-23 07:38:53 --> Loader Class Initialized
INFO - 2018-01-23 07:38:53 --> Helper loaded: url_helper
INFO - 2018-01-23 07:38:53 --> Helper loaded: form_helper
INFO - 2018-01-23 07:38:53 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:38:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:38:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:38:53 --> Form Validation Class Initialized
INFO - 2018-01-23 07:38:53 --> Model Class Initialized
INFO - 2018-01-23 07:38:53 --> Controller Class Initialized
INFO - 2018-01-23 07:38:53 --> Model Class Initialized
DEBUG - 2018-01-23 07:38:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:39:46 --> Config Class Initialized
INFO - 2018-01-23 07:39:46 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:39:46 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:39:46 --> Utf8 Class Initialized
INFO - 2018-01-23 07:39:46 --> URI Class Initialized
INFO - 2018-01-23 07:39:46 --> Router Class Initialized
INFO - 2018-01-23 07:39:46 --> Output Class Initialized
INFO - 2018-01-23 07:39:46 --> Security Class Initialized
DEBUG - 2018-01-23 07:39:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:39:46 --> Input Class Initialized
INFO - 2018-01-23 07:39:46 --> Language Class Initialized
INFO - 2018-01-23 07:39:46 --> Loader Class Initialized
INFO - 2018-01-23 07:39:46 --> Helper loaded: url_helper
INFO - 2018-01-23 07:39:46 --> Helper loaded: form_helper
INFO - 2018-01-23 07:39:46 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:39:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:39:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:39:46 --> Form Validation Class Initialized
INFO - 2018-01-23 07:39:46 --> Model Class Initialized
INFO - 2018-01-23 07:39:46 --> Controller Class Initialized
INFO - 2018-01-23 07:39:46 --> Model Class Initialized
DEBUG - 2018-01-23 07:39:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:39:46 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-23 07:39:46 --> Final output sent to browser
DEBUG - 2018-01-23 07:39:46 --> Total execution time: 0.0518
INFO - 2018-01-23 07:39:47 --> Config Class Initialized
INFO - 2018-01-23 07:39:47 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:39:47 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:39:47 --> Utf8 Class Initialized
INFO - 2018-01-23 07:39:47 --> URI Class Initialized
INFO - 2018-01-23 07:39:47 --> Router Class Initialized
INFO - 2018-01-23 07:39:47 --> Output Class Initialized
INFO - 2018-01-23 07:39:47 --> Security Class Initialized
DEBUG - 2018-01-23 07:39:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:39:47 --> Input Class Initialized
INFO - 2018-01-23 07:39:47 --> Language Class Initialized
INFO - 2018-01-23 07:39:47 --> Loader Class Initialized
INFO - 2018-01-23 07:39:47 --> Helper loaded: url_helper
INFO - 2018-01-23 07:39:47 --> Helper loaded: form_helper
INFO - 2018-01-23 07:39:47 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:39:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:39:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:39:47 --> Form Validation Class Initialized
INFO - 2018-01-23 07:39:47 --> Model Class Initialized
INFO - 2018-01-23 07:39:47 --> Controller Class Initialized
INFO - 2018-01-23 07:39:47 --> Model Class Initialized
DEBUG - 2018-01-23 07:39:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:39:50 --> Config Class Initialized
INFO - 2018-01-23 07:39:50 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:39:50 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:39:50 --> Utf8 Class Initialized
INFO - 2018-01-23 07:39:50 --> URI Class Initialized
INFO - 2018-01-23 07:39:50 --> Router Class Initialized
INFO - 2018-01-23 07:39:50 --> Output Class Initialized
INFO - 2018-01-23 07:39:50 --> Security Class Initialized
DEBUG - 2018-01-23 07:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:39:50 --> Input Class Initialized
INFO - 2018-01-23 07:39:50 --> Language Class Initialized
INFO - 2018-01-23 07:39:50 --> Loader Class Initialized
INFO - 2018-01-23 07:39:50 --> Helper loaded: url_helper
INFO - 2018-01-23 07:39:50 --> Helper loaded: form_helper
INFO - 2018-01-23 07:39:50 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:39:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:39:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:39:50 --> Form Validation Class Initialized
INFO - 2018-01-23 07:39:50 --> Model Class Initialized
INFO - 2018-01-23 07:39:50 --> Controller Class Initialized
INFO - 2018-01-23 07:39:50 --> Model Class Initialized
DEBUG - 2018-01-23 07:39:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:41:00 --> Config Class Initialized
INFO - 2018-01-23 07:41:00 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:41:00 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:41:00 --> Utf8 Class Initialized
INFO - 2018-01-23 07:41:00 --> URI Class Initialized
INFO - 2018-01-23 07:41:00 --> Router Class Initialized
INFO - 2018-01-23 07:41:00 --> Output Class Initialized
INFO - 2018-01-23 07:41:00 --> Security Class Initialized
DEBUG - 2018-01-23 07:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:41:00 --> Input Class Initialized
INFO - 2018-01-23 07:41:00 --> Language Class Initialized
INFO - 2018-01-23 07:41:00 --> Loader Class Initialized
INFO - 2018-01-23 07:41:00 --> Helper loaded: url_helper
INFO - 2018-01-23 07:41:00 --> Helper loaded: form_helper
INFO - 2018-01-23 07:41:00 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:41:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:41:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:41:00 --> Form Validation Class Initialized
INFO - 2018-01-23 07:41:00 --> Model Class Initialized
INFO - 2018-01-23 07:41:00 --> Controller Class Initialized
INFO - 2018-01-23 07:41:00 --> Model Class Initialized
DEBUG - 2018-01-23 07:41:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:41:00 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-23 07:41:00 --> Final output sent to browser
DEBUG - 2018-01-23 07:41:00 --> Total execution time: 0.0384
INFO - 2018-01-23 07:41:01 --> Config Class Initialized
INFO - 2018-01-23 07:41:01 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:41:01 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:41:01 --> Utf8 Class Initialized
INFO - 2018-01-23 07:41:01 --> URI Class Initialized
INFO - 2018-01-23 07:41:01 --> Router Class Initialized
INFO - 2018-01-23 07:41:01 --> Output Class Initialized
INFO - 2018-01-23 07:41:01 --> Security Class Initialized
DEBUG - 2018-01-23 07:41:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:41:01 --> Input Class Initialized
INFO - 2018-01-23 07:41:01 --> Language Class Initialized
INFO - 2018-01-23 07:41:01 --> Loader Class Initialized
INFO - 2018-01-23 07:41:01 --> Helper loaded: url_helper
INFO - 2018-01-23 07:41:01 --> Helper loaded: form_helper
INFO - 2018-01-23 07:41:01 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:41:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:41:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:41:01 --> Form Validation Class Initialized
INFO - 2018-01-23 07:41:01 --> Model Class Initialized
INFO - 2018-01-23 07:41:01 --> Controller Class Initialized
INFO - 2018-01-23 07:41:01 --> Model Class Initialized
DEBUG - 2018-01-23 07:41:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:41:05 --> Config Class Initialized
INFO - 2018-01-23 07:41:05 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:41:05 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:41:05 --> Utf8 Class Initialized
INFO - 2018-01-23 07:41:05 --> URI Class Initialized
INFO - 2018-01-23 07:41:05 --> Router Class Initialized
INFO - 2018-01-23 07:41:05 --> Output Class Initialized
INFO - 2018-01-23 07:41:05 --> Security Class Initialized
DEBUG - 2018-01-23 07:41:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:41:05 --> Input Class Initialized
INFO - 2018-01-23 07:41:05 --> Language Class Initialized
INFO - 2018-01-23 07:41:05 --> Loader Class Initialized
INFO - 2018-01-23 07:41:05 --> Helper loaded: url_helper
INFO - 2018-01-23 07:41:05 --> Helper loaded: form_helper
INFO - 2018-01-23 07:41:05 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:41:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:41:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:41:05 --> Form Validation Class Initialized
INFO - 2018-01-23 07:41:05 --> Model Class Initialized
INFO - 2018-01-23 07:41:05 --> Controller Class Initialized
INFO - 2018-01-23 07:41:05 --> Model Class Initialized
DEBUG - 2018-01-23 07:41:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:41:12 --> Config Class Initialized
INFO - 2018-01-23 07:41:12 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:41:12 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:41:12 --> Utf8 Class Initialized
INFO - 2018-01-23 07:41:12 --> URI Class Initialized
INFO - 2018-01-23 07:41:12 --> Router Class Initialized
INFO - 2018-01-23 07:41:12 --> Output Class Initialized
INFO - 2018-01-23 07:41:12 --> Security Class Initialized
DEBUG - 2018-01-23 07:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:41:12 --> Input Class Initialized
INFO - 2018-01-23 07:41:12 --> Language Class Initialized
INFO - 2018-01-23 07:41:12 --> Loader Class Initialized
INFO - 2018-01-23 07:41:12 --> Helper loaded: url_helper
INFO - 2018-01-23 07:41:12 --> Helper loaded: form_helper
INFO - 2018-01-23 07:41:12 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:41:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:41:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:41:12 --> Form Validation Class Initialized
INFO - 2018-01-23 07:41:12 --> Model Class Initialized
INFO - 2018-01-23 07:41:12 --> Controller Class Initialized
INFO - 2018-01-23 07:41:12 --> Model Class Initialized
DEBUG - 2018-01-23 07:41:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:41:16 --> Config Class Initialized
INFO - 2018-01-23 07:41:16 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:41:16 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:41:16 --> Utf8 Class Initialized
INFO - 2018-01-23 07:41:16 --> URI Class Initialized
INFO - 2018-01-23 07:41:16 --> Router Class Initialized
INFO - 2018-01-23 07:41:16 --> Output Class Initialized
INFO - 2018-01-23 07:41:16 --> Security Class Initialized
DEBUG - 2018-01-23 07:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:41:16 --> Input Class Initialized
INFO - 2018-01-23 07:41:16 --> Language Class Initialized
INFO - 2018-01-23 07:41:16 --> Loader Class Initialized
INFO - 2018-01-23 07:41:16 --> Helper loaded: url_helper
INFO - 2018-01-23 07:41:16 --> Helper loaded: form_helper
INFO - 2018-01-23 07:41:16 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:41:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:41:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:41:16 --> Form Validation Class Initialized
INFO - 2018-01-23 07:41:16 --> Model Class Initialized
INFO - 2018-01-23 07:41:16 --> Controller Class Initialized
INFO - 2018-01-23 07:41:16 --> Model Class Initialized
DEBUG - 2018-01-23 07:41:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:41:27 --> Config Class Initialized
INFO - 2018-01-23 07:41:27 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:41:27 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:41:27 --> Utf8 Class Initialized
INFO - 2018-01-23 07:41:27 --> URI Class Initialized
INFO - 2018-01-23 07:41:27 --> Router Class Initialized
INFO - 2018-01-23 07:41:27 --> Output Class Initialized
INFO - 2018-01-23 07:41:27 --> Security Class Initialized
DEBUG - 2018-01-23 07:41:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:41:27 --> Input Class Initialized
INFO - 2018-01-23 07:41:27 --> Language Class Initialized
INFO - 2018-01-23 07:41:27 --> Loader Class Initialized
INFO - 2018-01-23 07:41:27 --> Helper loaded: url_helper
INFO - 2018-01-23 07:41:27 --> Helper loaded: form_helper
INFO - 2018-01-23 07:41:27 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:41:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:41:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:41:27 --> Form Validation Class Initialized
INFO - 2018-01-23 07:41:27 --> Model Class Initialized
INFO - 2018-01-23 07:41:27 --> Controller Class Initialized
INFO - 2018-01-23 07:41:27 --> Model Class Initialized
DEBUG - 2018-01-23 07:41:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:41:30 --> Config Class Initialized
INFO - 2018-01-23 07:41:30 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:41:30 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:41:30 --> Utf8 Class Initialized
INFO - 2018-01-23 07:41:30 --> URI Class Initialized
INFO - 2018-01-23 07:41:30 --> Router Class Initialized
INFO - 2018-01-23 07:41:30 --> Output Class Initialized
INFO - 2018-01-23 07:41:30 --> Security Class Initialized
DEBUG - 2018-01-23 07:41:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:41:30 --> Input Class Initialized
INFO - 2018-01-23 07:41:30 --> Language Class Initialized
INFO - 2018-01-23 07:41:30 --> Loader Class Initialized
INFO - 2018-01-23 07:41:30 --> Helper loaded: url_helper
INFO - 2018-01-23 07:41:30 --> Helper loaded: form_helper
INFO - 2018-01-23 07:41:30 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:41:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:41:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:41:30 --> Form Validation Class Initialized
INFO - 2018-01-23 07:41:30 --> Model Class Initialized
INFO - 2018-01-23 07:41:30 --> Controller Class Initialized
INFO - 2018-01-23 07:41:30 --> Model Class Initialized
DEBUG - 2018-01-23 07:41:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:41:33 --> Config Class Initialized
INFO - 2018-01-23 07:41:33 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:41:33 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:41:33 --> Utf8 Class Initialized
INFO - 2018-01-23 07:41:33 --> URI Class Initialized
INFO - 2018-01-23 07:41:33 --> Router Class Initialized
INFO - 2018-01-23 07:41:33 --> Output Class Initialized
INFO - 2018-01-23 07:41:33 --> Security Class Initialized
DEBUG - 2018-01-23 07:41:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:41:33 --> Input Class Initialized
INFO - 2018-01-23 07:41:33 --> Language Class Initialized
INFO - 2018-01-23 07:41:33 --> Loader Class Initialized
INFO - 2018-01-23 07:41:33 --> Helper loaded: url_helper
INFO - 2018-01-23 07:41:33 --> Helper loaded: form_helper
INFO - 2018-01-23 07:41:33 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:41:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:41:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:41:33 --> Form Validation Class Initialized
INFO - 2018-01-23 07:41:33 --> Model Class Initialized
INFO - 2018-01-23 07:41:33 --> Controller Class Initialized
INFO - 2018-01-23 07:41:33 --> Model Class Initialized
DEBUG - 2018-01-23 07:41:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:41:53 --> Config Class Initialized
INFO - 2018-01-23 07:41:53 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:41:53 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:41:53 --> Utf8 Class Initialized
INFO - 2018-01-23 07:41:53 --> URI Class Initialized
INFO - 2018-01-23 07:41:53 --> Router Class Initialized
INFO - 2018-01-23 07:41:53 --> Output Class Initialized
INFO - 2018-01-23 07:41:53 --> Security Class Initialized
DEBUG - 2018-01-23 07:41:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:41:53 --> Input Class Initialized
INFO - 2018-01-23 07:41:53 --> Language Class Initialized
INFO - 2018-01-23 07:41:53 --> Loader Class Initialized
INFO - 2018-01-23 07:41:53 --> Helper loaded: url_helper
INFO - 2018-01-23 07:41:53 --> Helper loaded: form_helper
INFO - 2018-01-23 07:41:53 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:41:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:41:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:41:53 --> Form Validation Class Initialized
INFO - 2018-01-23 07:41:53 --> Model Class Initialized
INFO - 2018-01-23 07:41:53 --> Controller Class Initialized
INFO - 2018-01-23 07:41:53 --> Model Class Initialized
DEBUG - 2018-01-23 07:41:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:41:57 --> Config Class Initialized
INFO - 2018-01-23 07:41:57 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:41:57 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:41:57 --> Utf8 Class Initialized
INFO - 2018-01-23 07:41:57 --> URI Class Initialized
INFO - 2018-01-23 07:41:57 --> Router Class Initialized
INFO - 2018-01-23 07:41:57 --> Output Class Initialized
INFO - 2018-01-23 07:41:57 --> Security Class Initialized
DEBUG - 2018-01-23 07:41:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:41:57 --> Input Class Initialized
INFO - 2018-01-23 07:41:57 --> Language Class Initialized
INFO - 2018-01-23 07:41:57 --> Loader Class Initialized
INFO - 2018-01-23 07:41:57 --> Helper loaded: url_helper
INFO - 2018-01-23 07:41:57 --> Helper loaded: form_helper
INFO - 2018-01-23 07:41:57 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:41:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:41:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:41:57 --> Form Validation Class Initialized
INFO - 2018-01-23 07:41:57 --> Model Class Initialized
INFO - 2018-01-23 07:41:57 --> Controller Class Initialized
INFO - 2018-01-23 07:41:57 --> Model Class Initialized
DEBUG - 2018-01-23 07:41:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:42:05 --> Config Class Initialized
INFO - 2018-01-23 07:42:05 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:42:05 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:42:05 --> Utf8 Class Initialized
INFO - 2018-01-23 07:42:05 --> URI Class Initialized
INFO - 2018-01-23 07:42:05 --> Router Class Initialized
INFO - 2018-01-23 07:42:05 --> Output Class Initialized
INFO - 2018-01-23 07:42:05 --> Security Class Initialized
DEBUG - 2018-01-23 07:42:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:42:05 --> Input Class Initialized
INFO - 2018-01-23 07:42:05 --> Language Class Initialized
INFO - 2018-01-23 07:42:05 --> Loader Class Initialized
INFO - 2018-01-23 07:42:05 --> Helper loaded: url_helper
INFO - 2018-01-23 07:42:05 --> Helper loaded: form_helper
INFO - 2018-01-23 07:42:05 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:42:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:42:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:42:05 --> Form Validation Class Initialized
INFO - 2018-01-23 07:42:05 --> Model Class Initialized
INFO - 2018-01-23 07:42:05 --> Controller Class Initialized
INFO - 2018-01-23 07:42:05 --> Model Class Initialized
DEBUG - 2018-01-23 07:42:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:42:07 --> Config Class Initialized
INFO - 2018-01-23 07:42:07 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:42:07 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:42:07 --> Utf8 Class Initialized
INFO - 2018-01-23 07:42:07 --> URI Class Initialized
INFO - 2018-01-23 07:42:07 --> Router Class Initialized
INFO - 2018-01-23 07:42:07 --> Output Class Initialized
INFO - 2018-01-23 07:42:07 --> Security Class Initialized
DEBUG - 2018-01-23 07:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:42:07 --> Input Class Initialized
INFO - 2018-01-23 07:42:07 --> Language Class Initialized
INFO - 2018-01-23 07:42:07 --> Loader Class Initialized
INFO - 2018-01-23 07:42:07 --> Helper loaded: url_helper
INFO - 2018-01-23 07:42:07 --> Helper loaded: form_helper
INFO - 2018-01-23 07:42:07 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:42:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:42:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:42:07 --> Form Validation Class Initialized
INFO - 2018-01-23 07:42:07 --> Model Class Initialized
INFO - 2018-01-23 07:42:07 --> Controller Class Initialized
INFO - 2018-01-23 07:42:07 --> Model Class Initialized
DEBUG - 2018-01-23 07:42:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:42:10 --> Config Class Initialized
INFO - 2018-01-23 07:42:10 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:42:10 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:42:10 --> Utf8 Class Initialized
INFO - 2018-01-23 07:42:10 --> URI Class Initialized
INFO - 2018-01-23 07:42:10 --> Router Class Initialized
INFO - 2018-01-23 07:42:10 --> Output Class Initialized
INFO - 2018-01-23 07:42:10 --> Security Class Initialized
DEBUG - 2018-01-23 07:42:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:42:10 --> Input Class Initialized
INFO - 2018-01-23 07:42:10 --> Language Class Initialized
INFO - 2018-01-23 07:42:10 --> Loader Class Initialized
INFO - 2018-01-23 07:42:10 --> Helper loaded: url_helper
INFO - 2018-01-23 07:42:10 --> Helper loaded: form_helper
INFO - 2018-01-23 07:42:10 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:42:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:42:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:42:10 --> Form Validation Class Initialized
INFO - 2018-01-23 07:42:10 --> Model Class Initialized
INFO - 2018-01-23 07:42:10 --> Controller Class Initialized
INFO - 2018-01-23 07:42:10 --> Model Class Initialized
DEBUG - 2018-01-23 07:42:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:42:20 --> Config Class Initialized
INFO - 2018-01-23 07:42:20 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:42:20 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:42:20 --> Utf8 Class Initialized
INFO - 2018-01-23 07:42:20 --> URI Class Initialized
INFO - 2018-01-23 07:42:20 --> Router Class Initialized
INFO - 2018-01-23 07:42:20 --> Output Class Initialized
INFO - 2018-01-23 07:42:20 --> Security Class Initialized
DEBUG - 2018-01-23 07:42:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:42:20 --> Input Class Initialized
INFO - 2018-01-23 07:42:20 --> Language Class Initialized
INFO - 2018-01-23 07:42:20 --> Loader Class Initialized
INFO - 2018-01-23 07:42:20 --> Helper loaded: url_helper
INFO - 2018-01-23 07:42:20 --> Helper loaded: form_helper
INFO - 2018-01-23 07:42:20 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:42:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:42:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:42:20 --> Form Validation Class Initialized
INFO - 2018-01-23 07:42:20 --> Model Class Initialized
INFO - 2018-01-23 07:42:20 --> Controller Class Initialized
INFO - 2018-01-23 07:42:20 --> Model Class Initialized
DEBUG - 2018-01-23 07:42:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:42:20 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-23 07:42:20 --> Final output sent to browser
DEBUG - 2018-01-23 07:42:20 --> Total execution time: 0.0392
INFO - 2018-01-23 07:42:20 --> Config Class Initialized
INFO - 2018-01-23 07:42:20 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:42:20 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:42:20 --> Utf8 Class Initialized
INFO - 2018-01-23 07:42:20 --> URI Class Initialized
INFO - 2018-01-23 07:42:20 --> Router Class Initialized
INFO - 2018-01-23 07:42:20 --> Output Class Initialized
INFO - 2018-01-23 07:42:20 --> Security Class Initialized
DEBUG - 2018-01-23 07:42:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:42:20 --> Input Class Initialized
INFO - 2018-01-23 07:42:20 --> Language Class Initialized
INFO - 2018-01-23 07:42:20 --> Loader Class Initialized
INFO - 2018-01-23 07:42:20 --> Helper loaded: url_helper
INFO - 2018-01-23 07:42:20 --> Helper loaded: form_helper
INFO - 2018-01-23 07:42:20 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:42:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:42:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:42:20 --> Form Validation Class Initialized
INFO - 2018-01-23 07:42:20 --> Model Class Initialized
INFO - 2018-01-23 07:42:20 --> Controller Class Initialized
INFO - 2018-01-23 07:42:20 --> Model Class Initialized
DEBUG - 2018-01-23 07:42:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:42:28 --> Config Class Initialized
INFO - 2018-01-23 07:42:28 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:42:28 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:42:28 --> Utf8 Class Initialized
INFO - 2018-01-23 07:42:28 --> URI Class Initialized
INFO - 2018-01-23 07:42:28 --> Router Class Initialized
INFO - 2018-01-23 07:42:28 --> Output Class Initialized
INFO - 2018-01-23 07:42:28 --> Security Class Initialized
DEBUG - 2018-01-23 07:42:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:42:28 --> Input Class Initialized
INFO - 2018-01-23 07:42:28 --> Language Class Initialized
ERROR - 2018-01-23 07:42:28 --> 404 Page Not Found: Usuario/agregarUsuario
INFO - 2018-01-23 07:43:49 --> Config Class Initialized
INFO - 2018-01-23 07:43:49 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:43:49 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:43:49 --> Utf8 Class Initialized
INFO - 2018-01-23 07:43:49 --> URI Class Initialized
INFO - 2018-01-23 07:43:49 --> Router Class Initialized
INFO - 2018-01-23 07:43:49 --> Output Class Initialized
INFO - 2018-01-23 07:43:49 --> Security Class Initialized
DEBUG - 2018-01-23 07:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:43:49 --> Input Class Initialized
INFO - 2018-01-23 07:43:49 --> Language Class Initialized
INFO - 2018-01-23 07:43:49 --> Loader Class Initialized
INFO - 2018-01-23 07:43:49 --> Helper loaded: url_helper
INFO - 2018-01-23 07:43:49 --> Helper loaded: form_helper
INFO - 2018-01-23 07:43:49 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:43:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:43:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:43:49 --> Form Validation Class Initialized
INFO - 2018-01-23 07:43:49 --> Model Class Initialized
INFO - 2018-01-23 07:43:49 --> Controller Class Initialized
INFO - 2018-01-23 07:43:49 --> Model Class Initialized
DEBUG - 2018-01-23 07:43:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:43:49 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-23 07:43:49 --> Final output sent to browser
DEBUG - 2018-01-23 07:43:49 --> Total execution time: 0.0444
INFO - 2018-01-23 07:45:54 --> Config Class Initialized
INFO - 2018-01-23 07:45:54 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:45:54 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:45:54 --> Utf8 Class Initialized
INFO - 2018-01-23 07:45:54 --> URI Class Initialized
INFO - 2018-01-23 07:45:54 --> Router Class Initialized
INFO - 2018-01-23 07:45:54 --> Output Class Initialized
INFO - 2018-01-23 07:45:54 --> Security Class Initialized
DEBUG - 2018-01-23 07:45:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:45:54 --> Input Class Initialized
INFO - 2018-01-23 07:45:54 --> Language Class Initialized
INFO - 2018-01-23 07:45:54 --> Loader Class Initialized
INFO - 2018-01-23 07:45:54 --> Helper loaded: url_helper
INFO - 2018-01-23 07:45:54 --> Helper loaded: form_helper
INFO - 2018-01-23 07:45:54 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:45:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:45:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:45:54 --> Form Validation Class Initialized
INFO - 2018-01-23 07:45:54 --> Model Class Initialized
INFO - 2018-01-23 07:45:54 --> Controller Class Initialized
INFO - 2018-01-23 07:45:54 --> Model Class Initialized
DEBUG - 2018-01-23 07:45:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:45:54 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-23 07:45:54 --> Final output sent to browser
DEBUG - 2018-01-23 07:45:54 --> Total execution time: 0.0617
INFO - 2018-01-23 07:46:07 --> Config Class Initialized
INFO - 2018-01-23 07:46:07 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:46:07 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:46:07 --> Utf8 Class Initialized
INFO - 2018-01-23 07:46:07 --> URI Class Initialized
INFO - 2018-01-23 07:46:07 --> Router Class Initialized
INFO - 2018-01-23 07:46:07 --> Output Class Initialized
INFO - 2018-01-23 07:46:07 --> Security Class Initialized
DEBUG - 2018-01-23 07:46:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:46:07 --> Input Class Initialized
INFO - 2018-01-23 07:46:07 --> Language Class Initialized
INFO - 2018-01-23 07:46:07 --> Loader Class Initialized
INFO - 2018-01-23 07:46:07 --> Helper loaded: url_helper
INFO - 2018-01-23 07:46:07 --> Helper loaded: form_helper
INFO - 2018-01-23 07:46:07 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:46:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:46:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:46:07 --> Form Validation Class Initialized
INFO - 2018-01-23 07:46:07 --> Model Class Initialized
INFO - 2018-01-23 07:46:07 --> Controller Class Initialized
INFO - 2018-01-23 07:46:07 --> Model Class Initialized
DEBUG - 2018-01-23 07:46:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:46:07 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-23 07:46:07 --> Final output sent to browser
DEBUG - 2018-01-23 07:46:07 --> Total execution time: 0.0377
INFO - 2018-01-23 07:46:18 --> Config Class Initialized
INFO - 2018-01-23 07:46:18 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:46:18 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:46:18 --> Utf8 Class Initialized
INFO - 2018-01-23 07:46:18 --> URI Class Initialized
INFO - 2018-01-23 07:46:18 --> Router Class Initialized
INFO - 2018-01-23 07:46:18 --> Output Class Initialized
INFO - 2018-01-23 07:46:18 --> Security Class Initialized
DEBUG - 2018-01-23 07:46:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:46:18 --> Input Class Initialized
INFO - 2018-01-23 07:46:18 --> Language Class Initialized
INFO - 2018-01-23 07:46:18 --> Loader Class Initialized
INFO - 2018-01-23 07:46:18 --> Helper loaded: url_helper
INFO - 2018-01-23 07:46:18 --> Helper loaded: form_helper
INFO - 2018-01-23 07:46:18 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:46:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:46:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:46:18 --> Form Validation Class Initialized
INFO - 2018-01-23 07:46:18 --> Model Class Initialized
INFO - 2018-01-23 07:46:18 --> Controller Class Initialized
INFO - 2018-01-23 07:46:18 --> Model Class Initialized
DEBUG - 2018-01-23 07:46:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:46:19 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-23 07:46:19 --> Final output sent to browser
DEBUG - 2018-01-23 07:46:19 --> Total execution time: 0.0355
INFO - 2018-01-23 07:46:19 --> Config Class Initialized
INFO - 2018-01-23 07:46:19 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:46:19 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:46:19 --> Utf8 Class Initialized
INFO - 2018-01-23 07:46:19 --> URI Class Initialized
INFO - 2018-01-23 07:46:19 --> Router Class Initialized
INFO - 2018-01-23 07:46:19 --> Output Class Initialized
INFO - 2018-01-23 07:46:19 --> Security Class Initialized
DEBUG - 2018-01-23 07:46:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:46:19 --> Input Class Initialized
INFO - 2018-01-23 07:46:19 --> Language Class Initialized
INFO - 2018-01-23 07:46:19 --> Loader Class Initialized
INFO - 2018-01-23 07:46:19 --> Helper loaded: url_helper
INFO - 2018-01-23 07:46:19 --> Helper loaded: form_helper
INFO - 2018-01-23 07:46:19 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:46:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:46:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:46:19 --> Form Validation Class Initialized
INFO - 2018-01-23 07:46:19 --> Model Class Initialized
INFO - 2018-01-23 07:46:19 --> Controller Class Initialized
INFO - 2018-01-23 07:46:19 --> Model Class Initialized
DEBUG - 2018-01-23 07:46:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:46:21 --> Config Class Initialized
INFO - 2018-01-23 07:46:21 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:46:21 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:46:21 --> Utf8 Class Initialized
INFO - 2018-01-23 07:46:21 --> URI Class Initialized
INFO - 2018-01-23 07:46:21 --> Router Class Initialized
INFO - 2018-01-23 07:46:21 --> Output Class Initialized
INFO - 2018-01-23 07:46:21 --> Security Class Initialized
DEBUG - 2018-01-23 07:46:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:46:21 --> Input Class Initialized
INFO - 2018-01-23 07:46:21 --> Language Class Initialized
INFO - 2018-01-23 07:46:21 --> Loader Class Initialized
INFO - 2018-01-23 07:46:21 --> Helper loaded: url_helper
INFO - 2018-01-23 07:46:21 --> Helper loaded: form_helper
INFO - 2018-01-23 07:46:21 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:46:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:46:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:46:21 --> Form Validation Class Initialized
INFO - 2018-01-23 07:46:21 --> Model Class Initialized
INFO - 2018-01-23 07:46:21 --> Controller Class Initialized
INFO - 2018-01-23 07:46:21 --> Model Class Initialized
INFO - 2018-01-23 07:46:21 --> Model Class Initialized
DEBUG - 2018-01-23 07:46:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:46:21 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-23 07:46:21 --> Final output sent to browser
DEBUG - 2018-01-23 07:46:21 --> Total execution time: 0.0370
INFO - 2018-01-23 07:46:22 --> Config Class Initialized
INFO - 2018-01-23 07:46:22 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:46:22 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:46:22 --> Utf8 Class Initialized
INFO - 2018-01-23 07:46:22 --> URI Class Initialized
INFO - 2018-01-23 07:46:22 --> Router Class Initialized
INFO - 2018-01-23 07:46:22 --> Output Class Initialized
INFO - 2018-01-23 07:46:22 --> Security Class Initialized
DEBUG - 2018-01-23 07:46:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:46:22 --> Input Class Initialized
INFO - 2018-01-23 07:46:22 --> Language Class Initialized
INFO - 2018-01-23 07:46:22 --> Loader Class Initialized
INFO - 2018-01-23 07:46:22 --> Helper loaded: url_helper
INFO - 2018-01-23 07:46:22 --> Helper loaded: form_helper
INFO - 2018-01-23 07:46:22 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:46:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:46:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:46:22 --> Form Validation Class Initialized
INFO - 2018-01-23 07:46:22 --> Model Class Initialized
INFO - 2018-01-23 07:46:22 --> Controller Class Initialized
INFO - 2018-01-23 07:46:22 --> Model Class Initialized
INFO - 2018-01-23 07:46:22 --> Model Class Initialized
DEBUG - 2018-01-23 07:46:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:47:46 --> Config Class Initialized
INFO - 2018-01-23 07:47:46 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:47:46 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:47:46 --> Utf8 Class Initialized
INFO - 2018-01-23 07:47:46 --> URI Class Initialized
INFO - 2018-01-23 07:47:46 --> Router Class Initialized
INFO - 2018-01-23 07:47:46 --> Output Class Initialized
INFO - 2018-01-23 07:47:46 --> Security Class Initialized
DEBUG - 2018-01-23 07:47:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:47:46 --> Input Class Initialized
INFO - 2018-01-23 07:47:46 --> Language Class Initialized
INFO - 2018-01-23 07:47:46 --> Loader Class Initialized
INFO - 2018-01-23 07:47:46 --> Helper loaded: url_helper
INFO - 2018-01-23 07:47:46 --> Helper loaded: form_helper
INFO - 2018-01-23 07:47:46 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:47:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:47:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:47:46 --> Form Validation Class Initialized
INFO - 2018-01-23 07:47:46 --> Model Class Initialized
INFO - 2018-01-23 07:47:46 --> Controller Class Initialized
INFO - 2018-01-23 07:47:46 --> Model Class Initialized
INFO - 2018-01-23 07:47:46 --> Model Class Initialized
DEBUG - 2018-01-23 07:47:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:47:46 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-23 07:47:46 --> Final output sent to browser
DEBUG - 2018-01-23 07:47:46 --> Total execution time: 0.0500
INFO - 2018-01-23 07:47:46 --> Config Class Initialized
INFO - 2018-01-23 07:47:46 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:47:46 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:47:46 --> Utf8 Class Initialized
INFO - 2018-01-23 07:47:46 --> URI Class Initialized
INFO - 2018-01-23 07:47:46 --> Router Class Initialized
INFO - 2018-01-23 07:47:46 --> Output Class Initialized
INFO - 2018-01-23 07:47:46 --> Security Class Initialized
DEBUG - 2018-01-23 07:47:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:47:46 --> Input Class Initialized
INFO - 2018-01-23 07:47:46 --> Language Class Initialized
INFO - 2018-01-23 07:47:46 --> Loader Class Initialized
INFO - 2018-01-23 07:47:46 --> Helper loaded: url_helper
INFO - 2018-01-23 07:47:46 --> Helper loaded: form_helper
INFO - 2018-01-23 07:47:46 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:47:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:47:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:47:46 --> Form Validation Class Initialized
INFO - 2018-01-23 07:47:46 --> Model Class Initialized
INFO - 2018-01-23 07:47:46 --> Controller Class Initialized
INFO - 2018-01-23 07:47:46 --> Model Class Initialized
INFO - 2018-01-23 07:47:46 --> Model Class Initialized
DEBUG - 2018-01-23 07:47:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:47:48 --> Config Class Initialized
INFO - 2018-01-23 07:47:48 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:47:48 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:47:48 --> Utf8 Class Initialized
INFO - 2018-01-23 07:47:48 --> URI Class Initialized
INFO - 2018-01-23 07:47:48 --> Router Class Initialized
INFO - 2018-01-23 07:47:48 --> Output Class Initialized
INFO - 2018-01-23 07:47:48 --> Security Class Initialized
DEBUG - 2018-01-23 07:47:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:47:48 --> Input Class Initialized
INFO - 2018-01-23 07:47:48 --> Language Class Initialized
INFO - 2018-01-23 07:47:48 --> Loader Class Initialized
INFO - 2018-01-23 07:47:48 --> Helper loaded: url_helper
INFO - 2018-01-23 07:47:48 --> Helper loaded: form_helper
INFO - 2018-01-23 07:47:48 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:47:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:47:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:47:48 --> Form Validation Class Initialized
INFO - 2018-01-23 07:47:48 --> Model Class Initialized
INFO - 2018-01-23 07:47:48 --> Controller Class Initialized
INFO - 2018-01-23 07:47:48 --> Model Class Initialized
INFO - 2018-01-23 07:47:48 --> Model Class Initialized
DEBUG - 2018-01-23 07:47:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:47:48 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-23 07:47:48 --> Final output sent to browser
DEBUG - 2018-01-23 07:47:48 --> Total execution time: 0.0379
INFO - 2018-01-23 07:47:50 --> Config Class Initialized
INFO - 2018-01-23 07:47:50 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:47:50 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:47:50 --> Utf8 Class Initialized
INFO - 2018-01-23 07:47:50 --> URI Class Initialized
INFO - 2018-01-23 07:47:50 --> Router Class Initialized
INFO - 2018-01-23 07:47:50 --> Output Class Initialized
INFO - 2018-01-23 07:47:50 --> Security Class Initialized
DEBUG - 2018-01-23 07:47:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:47:50 --> Input Class Initialized
INFO - 2018-01-23 07:47:50 --> Language Class Initialized
INFO - 2018-01-23 07:47:50 --> Loader Class Initialized
INFO - 2018-01-23 07:47:50 --> Helper loaded: url_helper
INFO - 2018-01-23 07:47:50 --> Helper loaded: form_helper
INFO - 2018-01-23 07:47:50 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:47:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:47:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:47:50 --> Form Validation Class Initialized
INFO - 2018-01-23 07:47:50 --> Model Class Initialized
INFO - 2018-01-23 07:47:50 --> Controller Class Initialized
INFO - 2018-01-23 07:47:50 --> Model Class Initialized
INFO - 2018-01-23 07:47:50 --> Model Class Initialized
DEBUG - 2018-01-23 07:47:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:47:50 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-23 07:47:50 --> Final output sent to browser
DEBUG - 2018-01-23 07:47:50 --> Total execution time: 0.0590
INFO - 2018-01-23 07:48:05 --> Config Class Initialized
INFO - 2018-01-23 07:48:05 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:48:05 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:48:05 --> Utf8 Class Initialized
INFO - 2018-01-23 07:48:05 --> URI Class Initialized
INFO - 2018-01-23 07:48:05 --> Router Class Initialized
INFO - 2018-01-23 07:48:05 --> Output Class Initialized
INFO - 2018-01-23 07:48:05 --> Security Class Initialized
DEBUG - 2018-01-23 07:48:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:48:05 --> Input Class Initialized
INFO - 2018-01-23 07:48:05 --> Language Class Initialized
INFO - 2018-01-23 07:48:05 --> Loader Class Initialized
INFO - 2018-01-23 07:48:05 --> Helper loaded: url_helper
INFO - 2018-01-23 07:48:05 --> Helper loaded: form_helper
INFO - 2018-01-23 07:48:05 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:48:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:48:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:48:05 --> Form Validation Class Initialized
INFO - 2018-01-23 07:48:05 --> Model Class Initialized
INFO - 2018-01-23 07:48:05 --> Controller Class Initialized
INFO - 2018-01-23 07:48:05 --> Model Class Initialized
INFO - 2018-01-23 07:48:05 --> Model Class Initialized
DEBUG - 2018-01-23 07:48:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:48:05 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-23 07:48:05 --> Final output sent to browser
DEBUG - 2018-01-23 07:48:05 --> Total execution time: 0.0469
INFO - 2018-01-23 07:48:05 --> Config Class Initialized
INFO - 2018-01-23 07:48:05 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:48:05 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:48:05 --> Utf8 Class Initialized
INFO - 2018-01-23 07:48:05 --> URI Class Initialized
INFO - 2018-01-23 07:48:05 --> Router Class Initialized
INFO - 2018-01-23 07:48:05 --> Output Class Initialized
INFO - 2018-01-23 07:48:05 --> Security Class Initialized
DEBUG - 2018-01-23 07:48:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:48:05 --> Input Class Initialized
INFO - 2018-01-23 07:48:05 --> Language Class Initialized
INFO - 2018-01-23 07:48:05 --> Loader Class Initialized
INFO - 2018-01-23 07:48:05 --> Helper loaded: url_helper
INFO - 2018-01-23 07:48:05 --> Helper loaded: form_helper
INFO - 2018-01-23 07:48:05 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:48:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:48:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:48:05 --> Form Validation Class Initialized
INFO - 2018-01-23 07:48:05 --> Model Class Initialized
INFO - 2018-01-23 07:48:05 --> Controller Class Initialized
INFO - 2018-01-23 07:48:05 --> Model Class Initialized
INFO - 2018-01-23 07:48:05 --> Model Class Initialized
DEBUG - 2018-01-23 07:48:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:48:07 --> Config Class Initialized
INFO - 2018-01-23 07:48:07 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:48:07 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:48:07 --> Utf8 Class Initialized
INFO - 2018-01-23 07:48:07 --> URI Class Initialized
INFO - 2018-01-23 07:48:07 --> Router Class Initialized
INFO - 2018-01-23 07:48:07 --> Output Class Initialized
INFO - 2018-01-23 07:48:07 --> Security Class Initialized
DEBUG - 2018-01-23 07:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:48:07 --> Input Class Initialized
INFO - 2018-01-23 07:48:07 --> Language Class Initialized
INFO - 2018-01-23 07:48:07 --> Loader Class Initialized
INFO - 2018-01-23 07:48:07 --> Helper loaded: url_helper
INFO - 2018-01-23 07:48:07 --> Helper loaded: form_helper
INFO - 2018-01-23 07:48:07 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:48:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:48:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:48:07 --> Form Validation Class Initialized
INFO - 2018-01-23 07:48:07 --> Model Class Initialized
INFO - 2018-01-23 07:48:07 --> Controller Class Initialized
INFO - 2018-01-23 07:48:07 --> Model Class Initialized
DEBUG - 2018-01-23 07:48:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:48:07 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-23 07:48:07 --> Final output sent to browser
DEBUG - 2018-01-23 07:48:07 --> Total execution time: 0.0463
INFO - 2018-01-23 07:48:07 --> Config Class Initialized
INFO - 2018-01-23 07:48:07 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:48:07 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:48:07 --> Utf8 Class Initialized
INFO - 2018-01-23 07:48:07 --> URI Class Initialized
INFO - 2018-01-23 07:48:07 --> Router Class Initialized
INFO - 2018-01-23 07:48:07 --> Output Class Initialized
INFO - 2018-01-23 07:48:07 --> Security Class Initialized
DEBUG - 2018-01-23 07:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:48:07 --> Input Class Initialized
INFO - 2018-01-23 07:48:07 --> Language Class Initialized
INFO - 2018-01-23 07:48:07 --> Loader Class Initialized
INFO - 2018-01-23 07:48:07 --> Helper loaded: url_helper
INFO - 2018-01-23 07:48:07 --> Helper loaded: form_helper
INFO - 2018-01-23 07:48:07 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:48:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:48:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:48:07 --> Form Validation Class Initialized
INFO - 2018-01-23 07:48:07 --> Model Class Initialized
INFO - 2018-01-23 07:48:07 --> Controller Class Initialized
INFO - 2018-01-23 07:48:07 --> Model Class Initialized
DEBUG - 2018-01-23 07:48:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:48:09 --> Config Class Initialized
INFO - 2018-01-23 07:48:09 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:48:09 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:48:09 --> Utf8 Class Initialized
INFO - 2018-01-23 07:48:09 --> URI Class Initialized
INFO - 2018-01-23 07:48:09 --> Router Class Initialized
INFO - 2018-01-23 07:48:09 --> Output Class Initialized
INFO - 2018-01-23 07:48:09 --> Security Class Initialized
DEBUG - 2018-01-23 07:48:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:48:09 --> Input Class Initialized
INFO - 2018-01-23 07:48:09 --> Language Class Initialized
INFO - 2018-01-23 07:48:09 --> Loader Class Initialized
INFO - 2018-01-23 07:48:09 --> Helper loaded: url_helper
INFO - 2018-01-23 07:48:09 --> Helper loaded: form_helper
INFO - 2018-01-23 07:48:09 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:48:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:48:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:48:09 --> Form Validation Class Initialized
INFO - 2018-01-23 07:48:09 --> Model Class Initialized
INFO - 2018-01-23 07:48:09 --> Controller Class Initialized
INFO - 2018-01-23 07:48:09 --> Model Class Initialized
DEBUG - 2018-01-23 07:48:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:48:09 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-23 07:48:09 --> Final output sent to browser
DEBUG - 2018-01-23 07:48:09 --> Total execution time: 0.0443
INFO - 2018-01-23 07:48:12 --> Config Class Initialized
INFO - 2018-01-23 07:48:12 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:48:12 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:48:12 --> Utf8 Class Initialized
INFO - 2018-01-23 07:48:12 --> URI Class Initialized
INFO - 2018-01-23 07:48:12 --> Router Class Initialized
INFO - 2018-01-23 07:48:12 --> Output Class Initialized
INFO - 2018-01-23 07:48:12 --> Security Class Initialized
DEBUG - 2018-01-23 07:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:48:12 --> Input Class Initialized
INFO - 2018-01-23 07:48:12 --> Language Class Initialized
INFO - 2018-01-23 07:48:12 --> Loader Class Initialized
INFO - 2018-01-23 07:48:12 --> Helper loaded: url_helper
INFO - 2018-01-23 07:48:12 --> Helper loaded: form_helper
INFO - 2018-01-23 07:48:12 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:48:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:48:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:48:12 --> Form Validation Class Initialized
INFO - 2018-01-23 07:48:12 --> Model Class Initialized
INFO - 2018-01-23 07:48:12 --> Controller Class Initialized
INFO - 2018-01-23 07:48:12 --> Model Class Initialized
DEBUG - 2018-01-23 07:48:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:48:12 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-23 07:48:12 --> Final output sent to browser
DEBUG - 2018-01-23 07:48:12 --> Total execution time: 0.0464
INFO - 2018-01-23 07:48:12 --> Config Class Initialized
INFO - 2018-01-23 07:48:12 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:48:12 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:48:12 --> Utf8 Class Initialized
INFO - 2018-01-23 07:48:12 --> URI Class Initialized
INFO - 2018-01-23 07:48:12 --> Router Class Initialized
INFO - 2018-01-23 07:48:12 --> Output Class Initialized
INFO - 2018-01-23 07:48:12 --> Security Class Initialized
DEBUG - 2018-01-23 07:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:48:12 --> Input Class Initialized
INFO - 2018-01-23 07:48:12 --> Language Class Initialized
INFO - 2018-01-23 07:48:12 --> Loader Class Initialized
INFO - 2018-01-23 07:48:12 --> Helper loaded: url_helper
INFO - 2018-01-23 07:48:12 --> Helper loaded: form_helper
INFO - 2018-01-23 07:48:12 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:48:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:48:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:48:12 --> Form Validation Class Initialized
INFO - 2018-01-23 07:48:12 --> Model Class Initialized
INFO - 2018-01-23 07:48:12 --> Controller Class Initialized
INFO - 2018-01-23 07:48:12 --> Model Class Initialized
DEBUG - 2018-01-23 07:48:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:48:12 --> Config Class Initialized
INFO - 2018-01-23 07:48:12 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:48:12 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:48:12 --> Utf8 Class Initialized
INFO - 2018-01-23 07:48:12 --> URI Class Initialized
INFO - 2018-01-23 07:48:12 --> Router Class Initialized
INFO - 2018-01-23 07:48:12 --> Output Class Initialized
INFO - 2018-01-23 07:48:12 --> Security Class Initialized
DEBUG - 2018-01-23 07:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:48:12 --> Input Class Initialized
INFO - 2018-01-23 07:48:12 --> Language Class Initialized
INFO - 2018-01-23 07:48:12 --> Loader Class Initialized
INFO - 2018-01-23 07:48:12 --> Helper loaded: url_helper
INFO - 2018-01-23 07:48:12 --> Helper loaded: form_helper
INFO - 2018-01-23 07:48:12 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:48:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:48:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:48:12 --> Form Validation Class Initialized
INFO - 2018-01-23 07:48:12 --> Model Class Initialized
INFO - 2018-01-23 07:48:12 --> Controller Class Initialized
INFO - 2018-01-23 07:48:12 --> Model Class Initialized
DEBUG - 2018-01-23 07:48:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:48:12 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-23 07:48:12 --> Final output sent to browser
DEBUG - 2018-01-23 07:48:12 --> Total execution time: 0.0460
INFO - 2018-01-23 07:48:47 --> Config Class Initialized
INFO - 2018-01-23 07:48:47 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:48:47 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:48:47 --> Utf8 Class Initialized
INFO - 2018-01-23 07:48:47 --> URI Class Initialized
INFO - 2018-01-23 07:48:47 --> Router Class Initialized
INFO - 2018-01-23 07:48:47 --> Output Class Initialized
INFO - 2018-01-23 07:48:47 --> Security Class Initialized
DEBUG - 2018-01-23 07:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:48:47 --> Input Class Initialized
INFO - 2018-01-23 07:48:47 --> Language Class Initialized
INFO - 2018-01-23 07:48:47 --> Loader Class Initialized
INFO - 2018-01-23 07:48:47 --> Helper loaded: url_helper
INFO - 2018-01-23 07:48:47 --> Helper loaded: form_helper
INFO - 2018-01-23 07:48:47 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:48:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:48:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:48:47 --> Form Validation Class Initialized
INFO - 2018-01-23 07:48:47 --> Model Class Initialized
INFO - 2018-01-23 07:48:47 --> Controller Class Initialized
INFO - 2018-01-23 07:48:47 --> Model Class Initialized
INFO - 2018-01-23 07:48:47 --> Model Class Initialized
DEBUG - 2018-01-23 07:48:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:48:47 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-23 07:48:47 --> Final output sent to browser
DEBUG - 2018-01-23 07:48:47 --> Total execution time: 0.0454
INFO - 2018-01-23 07:48:47 --> Config Class Initialized
INFO - 2018-01-23 07:48:47 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:48:47 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:48:47 --> Utf8 Class Initialized
INFO - 2018-01-23 07:48:47 --> URI Class Initialized
INFO - 2018-01-23 07:48:47 --> Router Class Initialized
INFO - 2018-01-23 07:48:47 --> Output Class Initialized
INFO - 2018-01-23 07:48:47 --> Security Class Initialized
DEBUG - 2018-01-23 07:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:48:47 --> Input Class Initialized
INFO - 2018-01-23 07:48:47 --> Language Class Initialized
INFO - 2018-01-23 07:48:47 --> Loader Class Initialized
INFO - 2018-01-23 07:48:47 --> Helper loaded: url_helper
INFO - 2018-01-23 07:48:47 --> Helper loaded: form_helper
INFO - 2018-01-23 07:48:47 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:48:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:48:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:48:47 --> Form Validation Class Initialized
INFO - 2018-01-23 07:48:47 --> Model Class Initialized
INFO - 2018-01-23 07:48:47 --> Controller Class Initialized
INFO - 2018-01-23 07:48:47 --> Model Class Initialized
INFO - 2018-01-23 07:48:47 --> Model Class Initialized
DEBUG - 2018-01-23 07:48:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:48:48 --> Config Class Initialized
INFO - 2018-01-23 07:48:48 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:48:48 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:48:48 --> Utf8 Class Initialized
INFO - 2018-01-23 07:48:48 --> URI Class Initialized
INFO - 2018-01-23 07:48:48 --> Router Class Initialized
INFO - 2018-01-23 07:48:48 --> Output Class Initialized
INFO - 2018-01-23 07:48:48 --> Security Class Initialized
DEBUG - 2018-01-23 07:48:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:48:48 --> Input Class Initialized
INFO - 2018-01-23 07:48:48 --> Language Class Initialized
INFO - 2018-01-23 07:48:48 --> Loader Class Initialized
INFO - 2018-01-23 07:48:48 --> Helper loaded: url_helper
INFO - 2018-01-23 07:48:48 --> Helper loaded: form_helper
INFO - 2018-01-23 07:48:48 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:48:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:48:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:48:48 --> Form Validation Class Initialized
INFO - 2018-01-23 07:48:48 --> Model Class Initialized
INFO - 2018-01-23 07:48:48 --> Controller Class Initialized
INFO - 2018-01-23 07:48:48 --> Model Class Initialized
INFO - 2018-01-23 07:48:48 --> Model Class Initialized
DEBUG - 2018-01-23 07:48:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:48:48 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-23 07:48:48 --> Final output sent to browser
DEBUG - 2018-01-23 07:48:48 --> Total execution time: 0.0475
INFO - 2018-01-23 07:48:49 --> Config Class Initialized
INFO - 2018-01-23 07:48:49 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:48:49 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:48:49 --> Utf8 Class Initialized
INFO - 2018-01-23 07:48:49 --> URI Class Initialized
INFO - 2018-01-23 07:48:49 --> Router Class Initialized
INFO - 2018-01-23 07:48:49 --> Output Class Initialized
INFO - 2018-01-23 07:48:49 --> Security Class Initialized
DEBUG - 2018-01-23 07:48:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:48:50 --> Input Class Initialized
INFO - 2018-01-23 07:48:50 --> Language Class Initialized
INFO - 2018-01-23 07:48:50 --> Loader Class Initialized
INFO - 2018-01-23 07:48:50 --> Helper loaded: url_helper
INFO - 2018-01-23 07:48:50 --> Helper loaded: form_helper
INFO - 2018-01-23 07:48:50 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:48:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:48:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:48:50 --> Form Validation Class Initialized
INFO - 2018-01-23 07:48:50 --> Model Class Initialized
INFO - 2018-01-23 07:48:50 --> Controller Class Initialized
INFO - 2018-01-23 07:48:50 --> Model Class Initialized
INFO - 2018-01-23 07:48:50 --> Model Class Initialized
DEBUG - 2018-01-23 07:48:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:48:50 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-23 07:48:50 --> Final output sent to browser
DEBUG - 2018-01-23 07:48:50 --> Total execution time: 0.0377
INFO - 2018-01-23 07:48:50 --> Config Class Initialized
INFO - 2018-01-23 07:48:50 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:48:50 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:48:50 --> Utf8 Class Initialized
INFO - 2018-01-23 07:48:50 --> URI Class Initialized
INFO - 2018-01-23 07:48:50 --> Router Class Initialized
INFO - 2018-01-23 07:48:50 --> Output Class Initialized
INFO - 2018-01-23 07:48:50 --> Security Class Initialized
DEBUG - 2018-01-23 07:48:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:48:50 --> Input Class Initialized
INFO - 2018-01-23 07:48:50 --> Language Class Initialized
INFO - 2018-01-23 07:48:50 --> Loader Class Initialized
INFO - 2018-01-23 07:48:50 --> Helper loaded: url_helper
INFO - 2018-01-23 07:48:50 --> Helper loaded: form_helper
INFO - 2018-01-23 07:48:50 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:48:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:48:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:48:50 --> Form Validation Class Initialized
INFO - 2018-01-23 07:48:50 --> Model Class Initialized
INFO - 2018-01-23 07:48:50 --> Controller Class Initialized
INFO - 2018-01-23 07:48:50 --> Model Class Initialized
INFO - 2018-01-23 07:48:50 --> Model Class Initialized
DEBUG - 2018-01-23 07:48:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:48:51 --> Config Class Initialized
INFO - 2018-01-23 07:48:51 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:48:51 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:48:51 --> Utf8 Class Initialized
INFO - 2018-01-23 07:48:51 --> URI Class Initialized
INFO - 2018-01-23 07:48:51 --> Router Class Initialized
INFO - 2018-01-23 07:48:51 --> Output Class Initialized
INFO - 2018-01-23 07:48:51 --> Security Class Initialized
DEBUG - 2018-01-23 07:48:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:48:51 --> Input Class Initialized
INFO - 2018-01-23 07:48:51 --> Language Class Initialized
INFO - 2018-01-23 07:48:51 --> Loader Class Initialized
INFO - 2018-01-23 07:48:51 --> Helper loaded: url_helper
INFO - 2018-01-23 07:48:51 --> Helper loaded: form_helper
INFO - 2018-01-23 07:48:51 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:48:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:48:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:48:51 --> Form Validation Class Initialized
INFO - 2018-01-23 07:48:51 --> Model Class Initialized
INFO - 2018-01-23 07:48:51 --> Controller Class Initialized
INFO - 2018-01-23 07:48:51 --> Model Class Initialized
DEBUG - 2018-01-23 07:48:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:48:51 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-23 07:48:51 --> Final output sent to browser
DEBUG - 2018-01-23 07:48:51 --> Total execution time: 0.0461
INFO - 2018-01-23 07:48:51 --> Config Class Initialized
INFO - 2018-01-23 07:48:51 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:48:51 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:48:51 --> Utf8 Class Initialized
INFO - 2018-01-23 07:48:51 --> URI Class Initialized
INFO - 2018-01-23 07:48:51 --> Router Class Initialized
INFO - 2018-01-23 07:48:51 --> Output Class Initialized
INFO - 2018-01-23 07:48:51 --> Security Class Initialized
DEBUG - 2018-01-23 07:48:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:48:51 --> Input Class Initialized
INFO - 2018-01-23 07:48:51 --> Language Class Initialized
INFO - 2018-01-23 07:48:51 --> Loader Class Initialized
INFO - 2018-01-23 07:48:51 --> Helper loaded: url_helper
INFO - 2018-01-23 07:48:51 --> Helper loaded: form_helper
INFO - 2018-01-23 07:48:51 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:48:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:48:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:48:51 --> Form Validation Class Initialized
INFO - 2018-01-23 07:48:51 --> Model Class Initialized
INFO - 2018-01-23 07:48:51 --> Controller Class Initialized
INFO - 2018-01-23 07:48:51 --> Model Class Initialized
DEBUG - 2018-01-23 07:48:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:48:52 --> Config Class Initialized
INFO - 2018-01-23 07:48:52 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:48:52 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:48:52 --> Utf8 Class Initialized
INFO - 2018-01-23 07:48:52 --> URI Class Initialized
INFO - 2018-01-23 07:48:52 --> Router Class Initialized
INFO - 2018-01-23 07:48:52 --> Output Class Initialized
INFO - 2018-01-23 07:48:52 --> Security Class Initialized
DEBUG - 2018-01-23 07:48:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:48:52 --> Input Class Initialized
INFO - 2018-01-23 07:48:52 --> Language Class Initialized
INFO - 2018-01-23 07:48:52 --> Loader Class Initialized
INFO - 2018-01-23 07:48:52 --> Helper loaded: url_helper
INFO - 2018-01-23 07:48:52 --> Helper loaded: form_helper
INFO - 2018-01-23 07:48:52 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:48:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:48:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:48:52 --> Form Validation Class Initialized
INFO - 2018-01-23 07:48:52 --> Model Class Initialized
INFO - 2018-01-23 07:48:52 --> Controller Class Initialized
INFO - 2018-01-23 07:48:52 --> Model Class Initialized
DEBUG - 2018-01-23 07:48:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:48:52 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-23 07:48:52 --> Final output sent to browser
DEBUG - 2018-01-23 07:48:52 --> Total execution time: 0.0490
INFO - 2018-01-23 07:48:53 --> Config Class Initialized
INFO - 2018-01-23 07:48:53 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:48:53 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:48:53 --> Utf8 Class Initialized
INFO - 2018-01-23 07:48:53 --> URI Class Initialized
INFO - 2018-01-23 07:48:53 --> Router Class Initialized
INFO - 2018-01-23 07:48:53 --> Output Class Initialized
INFO - 2018-01-23 07:48:53 --> Security Class Initialized
DEBUG - 2018-01-23 07:48:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:48:53 --> Input Class Initialized
INFO - 2018-01-23 07:48:53 --> Language Class Initialized
INFO - 2018-01-23 07:48:53 --> Loader Class Initialized
INFO - 2018-01-23 07:48:53 --> Helper loaded: url_helper
INFO - 2018-01-23 07:48:53 --> Helper loaded: form_helper
INFO - 2018-01-23 07:48:53 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:48:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:48:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:48:53 --> Form Validation Class Initialized
INFO - 2018-01-23 07:48:53 --> Model Class Initialized
INFO - 2018-01-23 07:48:53 --> Controller Class Initialized
INFO - 2018-01-23 07:48:53 --> Model Class Initialized
DEBUG - 2018-01-23 07:48:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:48:53 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-23 07:48:53 --> Final output sent to browser
DEBUG - 2018-01-23 07:48:53 --> Total execution time: 0.0496
INFO - 2018-01-23 07:48:53 --> Config Class Initialized
INFO - 2018-01-23 07:48:53 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:48:53 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:48:53 --> Utf8 Class Initialized
INFO - 2018-01-23 07:48:53 --> URI Class Initialized
INFO - 2018-01-23 07:48:53 --> Router Class Initialized
INFO - 2018-01-23 07:48:53 --> Output Class Initialized
INFO - 2018-01-23 07:48:53 --> Security Class Initialized
DEBUG - 2018-01-23 07:48:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:48:53 --> Input Class Initialized
INFO - 2018-01-23 07:48:53 --> Language Class Initialized
INFO - 2018-01-23 07:48:53 --> Loader Class Initialized
INFO - 2018-01-23 07:48:53 --> Helper loaded: url_helper
INFO - 2018-01-23 07:48:53 --> Helper loaded: form_helper
INFO - 2018-01-23 07:48:53 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:48:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:48:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:48:53 --> Form Validation Class Initialized
INFO - 2018-01-23 07:48:53 --> Model Class Initialized
INFO - 2018-01-23 07:48:53 --> Controller Class Initialized
INFO - 2018-01-23 07:48:53 --> Model Class Initialized
DEBUG - 2018-01-23 07:48:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:49:39 --> Config Class Initialized
INFO - 2018-01-23 07:49:39 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:49:39 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:49:39 --> Utf8 Class Initialized
INFO - 2018-01-23 07:49:39 --> URI Class Initialized
INFO - 2018-01-23 07:49:39 --> Router Class Initialized
INFO - 2018-01-23 07:49:39 --> Output Class Initialized
INFO - 2018-01-23 07:49:39 --> Security Class Initialized
DEBUG - 2018-01-23 07:49:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:49:39 --> Input Class Initialized
INFO - 2018-01-23 07:49:39 --> Language Class Initialized
INFO - 2018-01-23 07:49:39 --> Loader Class Initialized
INFO - 2018-01-23 07:49:39 --> Helper loaded: url_helper
INFO - 2018-01-23 07:49:39 --> Helper loaded: form_helper
INFO - 2018-01-23 07:49:39 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:49:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:49:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:49:39 --> Form Validation Class Initialized
INFO - 2018-01-23 07:49:39 --> Model Class Initialized
INFO - 2018-01-23 07:49:39 --> Controller Class Initialized
INFO - 2018-01-23 07:49:39 --> Model Class Initialized
DEBUG - 2018-01-23 07:49:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:49:39 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-23 07:49:39 --> Final output sent to browser
DEBUG - 2018-01-23 07:49:39 --> Total execution time: 0.0634
INFO - 2018-01-23 07:49:40 --> Config Class Initialized
INFO - 2018-01-23 07:49:40 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:49:40 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:49:40 --> Utf8 Class Initialized
INFO - 2018-01-23 07:49:40 --> URI Class Initialized
INFO - 2018-01-23 07:49:40 --> Router Class Initialized
INFO - 2018-01-23 07:49:40 --> Output Class Initialized
INFO - 2018-01-23 07:49:40 --> Security Class Initialized
DEBUG - 2018-01-23 07:49:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:49:40 --> Input Class Initialized
INFO - 2018-01-23 07:49:40 --> Language Class Initialized
INFO - 2018-01-23 07:49:40 --> Loader Class Initialized
INFO - 2018-01-23 07:49:40 --> Helper loaded: url_helper
INFO - 2018-01-23 07:49:40 --> Helper loaded: form_helper
INFO - 2018-01-23 07:49:40 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:49:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:49:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:49:40 --> Form Validation Class Initialized
INFO - 2018-01-23 07:49:40 --> Model Class Initialized
INFO - 2018-01-23 07:49:40 --> Controller Class Initialized
INFO - 2018-01-23 07:49:40 --> Model Class Initialized
DEBUG - 2018-01-23 07:49:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:49:41 --> Config Class Initialized
INFO - 2018-01-23 07:49:41 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:49:41 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:49:41 --> Utf8 Class Initialized
INFO - 2018-01-23 07:49:41 --> URI Class Initialized
INFO - 2018-01-23 07:49:41 --> Router Class Initialized
INFO - 2018-01-23 07:49:41 --> Output Class Initialized
INFO - 2018-01-23 07:49:41 --> Security Class Initialized
DEBUG - 2018-01-23 07:49:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:49:41 --> Input Class Initialized
INFO - 2018-01-23 07:49:41 --> Language Class Initialized
INFO - 2018-01-23 07:49:41 --> Loader Class Initialized
INFO - 2018-01-23 07:49:41 --> Helper loaded: url_helper
INFO - 2018-01-23 07:49:41 --> Helper loaded: form_helper
INFO - 2018-01-23 07:49:41 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:49:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:49:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:49:41 --> Form Validation Class Initialized
INFO - 2018-01-23 07:49:41 --> Model Class Initialized
INFO - 2018-01-23 07:49:41 --> Controller Class Initialized
INFO - 2018-01-23 07:49:41 --> Model Class Initialized
INFO - 2018-01-23 07:49:41 --> Model Class Initialized
DEBUG - 2018-01-23 07:49:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:49:41 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-23 07:49:41 --> Final output sent to browser
DEBUG - 2018-01-23 07:49:41 --> Total execution time: 0.0453
INFO - 2018-01-23 07:49:41 --> Config Class Initialized
INFO - 2018-01-23 07:49:41 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:49:41 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:49:41 --> Utf8 Class Initialized
INFO - 2018-01-23 07:49:41 --> URI Class Initialized
INFO - 2018-01-23 07:49:41 --> Router Class Initialized
INFO - 2018-01-23 07:49:41 --> Output Class Initialized
INFO - 2018-01-23 07:49:41 --> Security Class Initialized
DEBUG - 2018-01-23 07:49:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:49:41 --> Input Class Initialized
INFO - 2018-01-23 07:49:41 --> Language Class Initialized
INFO - 2018-01-23 07:49:41 --> Loader Class Initialized
INFO - 2018-01-23 07:49:41 --> Helper loaded: url_helper
INFO - 2018-01-23 07:49:41 --> Helper loaded: form_helper
INFO - 2018-01-23 07:49:41 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:49:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:49:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:49:41 --> Form Validation Class Initialized
INFO - 2018-01-23 07:49:41 --> Model Class Initialized
INFO - 2018-01-23 07:49:41 --> Controller Class Initialized
INFO - 2018-01-23 07:49:41 --> Model Class Initialized
INFO - 2018-01-23 07:49:41 --> Model Class Initialized
DEBUG - 2018-01-23 07:49:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:49:42 --> Config Class Initialized
INFO - 2018-01-23 07:49:42 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:49:42 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:49:42 --> Utf8 Class Initialized
INFO - 2018-01-23 07:49:42 --> URI Class Initialized
INFO - 2018-01-23 07:49:42 --> Router Class Initialized
INFO - 2018-01-23 07:49:42 --> Output Class Initialized
INFO - 2018-01-23 07:49:42 --> Security Class Initialized
DEBUG - 2018-01-23 07:49:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:49:42 --> Input Class Initialized
INFO - 2018-01-23 07:49:42 --> Language Class Initialized
INFO - 2018-01-23 07:49:42 --> Loader Class Initialized
INFO - 2018-01-23 07:49:42 --> Helper loaded: url_helper
INFO - 2018-01-23 07:49:42 --> Helper loaded: form_helper
INFO - 2018-01-23 07:49:42 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:49:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:49:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:49:42 --> Form Validation Class Initialized
INFO - 2018-01-23 07:49:42 --> Model Class Initialized
INFO - 2018-01-23 07:49:42 --> Controller Class Initialized
INFO - 2018-01-23 07:49:42 --> Model Class Initialized
INFO - 2018-01-23 07:49:42 --> Model Class Initialized
DEBUG - 2018-01-23 07:49:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:49:42 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-23 07:49:42 --> Final output sent to browser
DEBUG - 2018-01-23 07:49:42 --> Total execution time: 0.0463
INFO - 2018-01-23 07:49:43 --> Config Class Initialized
INFO - 2018-01-23 07:49:43 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:49:43 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:49:43 --> Utf8 Class Initialized
INFO - 2018-01-23 07:49:43 --> URI Class Initialized
INFO - 2018-01-23 07:49:43 --> Router Class Initialized
INFO - 2018-01-23 07:49:43 --> Output Class Initialized
INFO - 2018-01-23 07:49:43 --> Security Class Initialized
DEBUG - 2018-01-23 07:49:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:49:43 --> Input Class Initialized
INFO - 2018-01-23 07:49:43 --> Language Class Initialized
INFO - 2018-01-23 07:49:43 --> Loader Class Initialized
INFO - 2018-01-23 07:49:43 --> Helper loaded: url_helper
INFO - 2018-01-23 07:49:43 --> Helper loaded: form_helper
INFO - 2018-01-23 07:49:43 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:49:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:49:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:49:43 --> Form Validation Class Initialized
INFO - 2018-01-23 07:49:43 --> Model Class Initialized
INFO - 2018-01-23 07:49:43 --> Controller Class Initialized
INFO - 2018-01-23 07:49:43 --> Model Class Initialized
INFO - 2018-01-23 07:49:43 --> Model Class Initialized
DEBUG - 2018-01-23 07:49:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:49:43 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-23 07:49:43 --> Final output sent to browser
DEBUG - 2018-01-23 07:49:43 --> Total execution time: 0.0495
INFO - 2018-01-23 07:49:43 --> Config Class Initialized
INFO - 2018-01-23 07:49:43 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:49:43 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:49:43 --> Utf8 Class Initialized
INFO - 2018-01-23 07:49:43 --> URI Class Initialized
INFO - 2018-01-23 07:49:43 --> Router Class Initialized
INFO - 2018-01-23 07:49:43 --> Output Class Initialized
INFO - 2018-01-23 07:49:43 --> Security Class Initialized
DEBUG - 2018-01-23 07:49:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:49:43 --> Input Class Initialized
INFO - 2018-01-23 07:49:43 --> Language Class Initialized
INFO - 2018-01-23 07:49:43 --> Loader Class Initialized
INFO - 2018-01-23 07:49:43 --> Helper loaded: url_helper
INFO - 2018-01-23 07:49:43 --> Helper loaded: form_helper
INFO - 2018-01-23 07:49:43 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:49:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:49:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:49:43 --> Form Validation Class Initialized
INFO - 2018-01-23 07:49:43 --> Model Class Initialized
INFO - 2018-01-23 07:49:43 --> Controller Class Initialized
INFO - 2018-01-23 07:49:43 --> Model Class Initialized
INFO - 2018-01-23 07:49:43 --> Model Class Initialized
DEBUG - 2018-01-23 07:49:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:49:44 --> Config Class Initialized
INFO - 2018-01-23 07:49:44 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:49:44 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:49:44 --> Utf8 Class Initialized
INFO - 2018-01-23 07:49:44 --> URI Class Initialized
INFO - 2018-01-23 07:49:44 --> Router Class Initialized
INFO - 2018-01-23 07:49:44 --> Output Class Initialized
INFO - 2018-01-23 07:49:44 --> Security Class Initialized
DEBUG - 2018-01-23 07:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:49:44 --> Input Class Initialized
INFO - 2018-01-23 07:49:44 --> Language Class Initialized
INFO - 2018-01-23 07:49:44 --> Loader Class Initialized
INFO - 2018-01-23 07:49:44 --> Helper loaded: url_helper
INFO - 2018-01-23 07:49:44 --> Helper loaded: form_helper
INFO - 2018-01-23 07:49:44 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:49:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:49:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:49:44 --> Form Validation Class Initialized
INFO - 2018-01-23 07:49:44 --> Model Class Initialized
INFO - 2018-01-23 07:49:44 --> Controller Class Initialized
INFO - 2018-01-23 07:49:44 --> Model Class Initialized
DEBUG - 2018-01-23 07:49:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:49:44 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-23 07:49:45 --> Final output sent to browser
DEBUG - 2018-01-23 07:49:45 --> Total execution time: 0.0359
INFO - 2018-01-23 07:49:45 --> Config Class Initialized
INFO - 2018-01-23 07:49:45 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:49:45 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:49:45 --> Utf8 Class Initialized
INFO - 2018-01-23 07:49:45 --> URI Class Initialized
INFO - 2018-01-23 07:49:45 --> Router Class Initialized
INFO - 2018-01-23 07:49:45 --> Output Class Initialized
INFO - 2018-01-23 07:49:45 --> Security Class Initialized
DEBUG - 2018-01-23 07:49:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:49:45 --> Input Class Initialized
INFO - 2018-01-23 07:49:45 --> Language Class Initialized
INFO - 2018-01-23 07:49:45 --> Loader Class Initialized
INFO - 2018-01-23 07:49:45 --> Helper loaded: url_helper
INFO - 2018-01-23 07:49:45 --> Helper loaded: form_helper
INFO - 2018-01-23 07:49:45 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:49:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:49:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:49:45 --> Form Validation Class Initialized
INFO - 2018-01-23 07:49:45 --> Model Class Initialized
INFO - 2018-01-23 07:49:45 --> Controller Class Initialized
INFO - 2018-01-23 07:49:45 --> Model Class Initialized
DEBUG - 2018-01-23 07:49:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:49:56 --> Config Class Initialized
INFO - 2018-01-23 07:49:56 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:49:56 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:49:56 --> Utf8 Class Initialized
INFO - 2018-01-23 07:49:56 --> URI Class Initialized
INFO - 2018-01-23 07:49:56 --> Router Class Initialized
INFO - 2018-01-23 07:49:56 --> Output Class Initialized
INFO - 2018-01-23 07:49:56 --> Security Class Initialized
DEBUG - 2018-01-23 07:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:49:56 --> Input Class Initialized
INFO - 2018-01-23 07:49:56 --> Language Class Initialized
INFO - 2018-01-23 07:49:56 --> Loader Class Initialized
INFO - 2018-01-23 07:49:56 --> Helper loaded: url_helper
INFO - 2018-01-23 07:49:56 --> Helper loaded: form_helper
INFO - 2018-01-23 07:49:56 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:49:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:49:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:49:56 --> Form Validation Class Initialized
INFO - 2018-01-23 07:49:56 --> Model Class Initialized
INFO - 2018-01-23 07:49:56 --> Controller Class Initialized
INFO - 2018-01-23 07:49:56 --> Model Class Initialized
DEBUG - 2018-01-23 07:49:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:49:56 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-23 07:49:56 --> Final output sent to browser
DEBUG - 2018-01-23 07:49:56 --> Total execution time: 0.0460
INFO - 2018-01-23 07:53:37 --> Config Class Initialized
INFO - 2018-01-23 07:53:37 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:53:37 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:53:37 --> Utf8 Class Initialized
INFO - 2018-01-23 07:53:37 --> URI Class Initialized
INFO - 2018-01-23 07:53:37 --> Router Class Initialized
INFO - 2018-01-23 07:53:37 --> Output Class Initialized
INFO - 2018-01-23 07:53:37 --> Security Class Initialized
DEBUG - 2018-01-23 07:53:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:53:37 --> Input Class Initialized
INFO - 2018-01-23 07:53:37 --> Language Class Initialized
INFO - 2018-01-23 07:53:37 --> Loader Class Initialized
INFO - 2018-01-23 07:53:37 --> Helper loaded: url_helper
INFO - 2018-01-23 07:53:37 --> Helper loaded: form_helper
INFO - 2018-01-23 07:53:37 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:53:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:53:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:53:37 --> Form Validation Class Initialized
INFO - 2018-01-23 07:53:37 --> Model Class Initialized
INFO - 2018-01-23 07:53:37 --> Controller Class Initialized
INFO - 2018-01-23 07:53:37 --> Model Class Initialized
DEBUG - 2018-01-23 07:53:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:53:37 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-23 07:53:37 --> Final output sent to browser
DEBUG - 2018-01-23 07:53:37 --> Total execution time: 0.0471
INFO - 2018-01-23 07:54:34 --> Config Class Initialized
INFO - 2018-01-23 07:54:34 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:54:34 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:54:34 --> Utf8 Class Initialized
INFO - 2018-01-23 07:54:34 --> URI Class Initialized
INFO - 2018-01-23 07:54:34 --> Router Class Initialized
INFO - 2018-01-23 07:54:34 --> Output Class Initialized
INFO - 2018-01-23 07:54:34 --> Security Class Initialized
DEBUG - 2018-01-23 07:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:54:34 --> Input Class Initialized
INFO - 2018-01-23 07:54:34 --> Language Class Initialized
INFO - 2018-01-23 07:54:34 --> Loader Class Initialized
INFO - 2018-01-23 07:54:34 --> Helper loaded: url_helper
INFO - 2018-01-23 07:54:34 --> Helper loaded: form_helper
INFO - 2018-01-23 07:54:34 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:54:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:54:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:54:34 --> Form Validation Class Initialized
INFO - 2018-01-23 07:54:34 --> Model Class Initialized
INFO - 2018-01-23 07:54:34 --> Controller Class Initialized
INFO - 2018-01-23 07:54:34 --> Model Class Initialized
DEBUG - 2018-01-23 07:54:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:54:34 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-23 07:54:34 --> Final output sent to browser
DEBUG - 2018-01-23 07:54:34 --> Total execution time: 0.0571
INFO - 2018-01-23 07:55:03 --> Config Class Initialized
INFO - 2018-01-23 07:55:03 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:55:03 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:55:03 --> Utf8 Class Initialized
INFO - 2018-01-23 07:55:03 --> URI Class Initialized
INFO - 2018-01-23 07:55:03 --> Router Class Initialized
INFO - 2018-01-23 07:55:03 --> Output Class Initialized
INFO - 2018-01-23 07:55:03 --> Security Class Initialized
DEBUG - 2018-01-23 07:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:55:03 --> Input Class Initialized
INFO - 2018-01-23 07:55:03 --> Language Class Initialized
INFO - 2018-01-23 07:55:03 --> Loader Class Initialized
INFO - 2018-01-23 07:55:03 --> Helper loaded: url_helper
INFO - 2018-01-23 07:55:03 --> Helper loaded: form_helper
INFO - 2018-01-23 07:55:03 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:55:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:55:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:55:03 --> Form Validation Class Initialized
INFO - 2018-01-23 07:55:03 --> Model Class Initialized
INFO - 2018-01-23 07:55:03 --> Controller Class Initialized
INFO - 2018-01-23 07:55:03 --> Model Class Initialized
DEBUG - 2018-01-23 07:55:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:55:03 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-23 07:55:03 --> Final output sent to browser
DEBUG - 2018-01-23 07:55:03 --> Total execution time: 0.0518
INFO - 2018-01-23 07:56:05 --> Config Class Initialized
INFO - 2018-01-23 07:56:05 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:56:05 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:56:05 --> Utf8 Class Initialized
INFO - 2018-01-23 07:56:05 --> URI Class Initialized
INFO - 2018-01-23 07:56:05 --> Router Class Initialized
INFO - 2018-01-23 07:56:05 --> Output Class Initialized
INFO - 2018-01-23 07:56:05 --> Security Class Initialized
DEBUG - 2018-01-23 07:56:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:56:05 --> Input Class Initialized
INFO - 2018-01-23 07:56:05 --> Language Class Initialized
INFO - 2018-01-23 07:56:05 --> Loader Class Initialized
INFO - 2018-01-23 07:56:05 --> Helper loaded: url_helper
INFO - 2018-01-23 07:56:05 --> Helper loaded: form_helper
INFO - 2018-01-23 07:56:05 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:56:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:56:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:56:05 --> Form Validation Class Initialized
INFO - 2018-01-23 07:56:05 --> Model Class Initialized
INFO - 2018-01-23 07:56:05 --> Controller Class Initialized
INFO - 2018-01-23 07:56:05 --> Model Class Initialized
DEBUG - 2018-01-23 07:56:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:56:05 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-23 07:56:05 --> Final output sent to browser
DEBUG - 2018-01-23 07:56:05 --> Total execution time: 0.0558
INFO - 2018-01-23 07:56:25 --> Config Class Initialized
INFO - 2018-01-23 07:56:25 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:56:25 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:56:25 --> Utf8 Class Initialized
INFO - 2018-01-23 07:56:25 --> URI Class Initialized
INFO - 2018-01-23 07:56:25 --> Router Class Initialized
INFO - 2018-01-23 07:56:25 --> Output Class Initialized
INFO - 2018-01-23 07:56:25 --> Security Class Initialized
DEBUG - 2018-01-23 07:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:56:25 --> Input Class Initialized
INFO - 2018-01-23 07:56:25 --> Language Class Initialized
INFO - 2018-01-23 07:56:25 --> Loader Class Initialized
INFO - 2018-01-23 07:56:25 --> Helper loaded: url_helper
INFO - 2018-01-23 07:56:25 --> Helper loaded: form_helper
INFO - 2018-01-23 07:56:25 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:56:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:56:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:56:25 --> Form Validation Class Initialized
INFO - 2018-01-23 07:56:25 --> Model Class Initialized
INFO - 2018-01-23 07:56:25 --> Controller Class Initialized
INFO - 2018-01-23 07:56:25 --> Model Class Initialized
DEBUG - 2018-01-23 07:56:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:56:25 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-23 07:56:25 --> Final output sent to browser
DEBUG - 2018-01-23 07:56:25 --> Total execution time: 0.0600
INFO - 2018-01-23 07:56:52 --> Config Class Initialized
INFO - 2018-01-23 07:56:52 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:56:52 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:56:52 --> Utf8 Class Initialized
INFO - 2018-01-23 07:56:52 --> URI Class Initialized
INFO - 2018-01-23 07:56:52 --> Router Class Initialized
INFO - 2018-01-23 07:56:52 --> Output Class Initialized
INFO - 2018-01-23 07:56:52 --> Security Class Initialized
DEBUG - 2018-01-23 07:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:56:52 --> Input Class Initialized
INFO - 2018-01-23 07:56:52 --> Language Class Initialized
INFO - 2018-01-23 07:56:52 --> Loader Class Initialized
INFO - 2018-01-23 07:56:52 --> Helper loaded: url_helper
INFO - 2018-01-23 07:56:52 --> Helper loaded: form_helper
INFO - 2018-01-23 07:56:52 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:56:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:56:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:56:52 --> Form Validation Class Initialized
INFO - 2018-01-23 07:56:52 --> Model Class Initialized
INFO - 2018-01-23 07:56:52 --> Controller Class Initialized
INFO - 2018-01-23 07:56:52 --> Model Class Initialized
DEBUG - 2018-01-23 07:56:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:56:52 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-23 07:56:52 --> Final output sent to browser
DEBUG - 2018-01-23 07:56:52 --> Total execution time: 0.0438
INFO - 2018-01-23 07:57:32 --> Config Class Initialized
INFO - 2018-01-23 07:57:32 --> Hooks Class Initialized
DEBUG - 2018-01-23 07:57:32 --> UTF-8 Support Enabled
INFO - 2018-01-23 07:57:32 --> Utf8 Class Initialized
INFO - 2018-01-23 07:57:32 --> URI Class Initialized
INFO - 2018-01-23 07:57:32 --> Router Class Initialized
INFO - 2018-01-23 07:57:32 --> Output Class Initialized
INFO - 2018-01-23 07:57:32 --> Security Class Initialized
DEBUG - 2018-01-23 07:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 07:57:32 --> Input Class Initialized
INFO - 2018-01-23 07:57:32 --> Language Class Initialized
INFO - 2018-01-23 07:57:32 --> Loader Class Initialized
INFO - 2018-01-23 07:57:32 --> Helper loaded: url_helper
INFO - 2018-01-23 07:57:32 --> Helper loaded: form_helper
INFO - 2018-01-23 07:57:32 --> Database Driver Class Initialized
DEBUG - 2018-01-23 07:57:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 07:57:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 07:57:32 --> Form Validation Class Initialized
INFO - 2018-01-23 07:57:32 --> Model Class Initialized
INFO - 2018-01-23 07:57:32 --> Controller Class Initialized
INFO - 2018-01-23 07:57:32 --> Model Class Initialized
DEBUG - 2018-01-23 07:57:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 07:57:32 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-23 07:57:32 --> Final output sent to browser
DEBUG - 2018-01-23 07:57:32 --> Total execution time: 0.0438
INFO - 2018-01-23 08:00:29 --> Config Class Initialized
INFO - 2018-01-23 08:00:29 --> Hooks Class Initialized
DEBUG - 2018-01-23 08:00:29 --> UTF-8 Support Enabled
INFO - 2018-01-23 08:00:29 --> Utf8 Class Initialized
INFO - 2018-01-23 08:00:29 --> URI Class Initialized
INFO - 2018-01-23 08:00:29 --> Router Class Initialized
INFO - 2018-01-23 08:00:29 --> Output Class Initialized
INFO - 2018-01-23 08:00:29 --> Security Class Initialized
DEBUG - 2018-01-23 08:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 08:00:29 --> Input Class Initialized
INFO - 2018-01-23 08:00:29 --> Language Class Initialized
INFO - 2018-01-23 08:00:29 --> Loader Class Initialized
INFO - 2018-01-23 08:00:29 --> Helper loaded: url_helper
INFO - 2018-01-23 08:00:29 --> Helper loaded: form_helper
INFO - 2018-01-23 08:00:29 --> Database Driver Class Initialized
DEBUG - 2018-01-23 08:00:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 08:00:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 08:00:29 --> Form Validation Class Initialized
INFO - 2018-01-23 08:00:29 --> Model Class Initialized
INFO - 2018-01-23 08:00:29 --> Controller Class Initialized
INFO - 2018-01-23 08:00:29 --> Model Class Initialized
DEBUG - 2018-01-23 08:00:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 08:00:29 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-23 08:00:29 --> Final output sent to browser
DEBUG - 2018-01-23 08:00:29 --> Total execution time: 0.0516
INFO - 2018-01-23 08:00:38 --> Config Class Initialized
INFO - 2018-01-23 08:00:38 --> Hooks Class Initialized
DEBUG - 2018-01-23 08:00:38 --> UTF-8 Support Enabled
INFO - 2018-01-23 08:00:38 --> Utf8 Class Initialized
INFO - 2018-01-23 08:00:38 --> URI Class Initialized
INFO - 2018-01-23 08:00:38 --> Router Class Initialized
INFO - 2018-01-23 08:00:38 --> Output Class Initialized
INFO - 2018-01-23 08:00:38 --> Security Class Initialized
DEBUG - 2018-01-23 08:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 08:00:38 --> Input Class Initialized
INFO - 2018-01-23 08:00:38 --> Language Class Initialized
INFO - 2018-01-23 08:00:38 --> Loader Class Initialized
INFO - 2018-01-23 08:00:38 --> Helper loaded: url_helper
INFO - 2018-01-23 08:00:38 --> Helper loaded: form_helper
INFO - 2018-01-23 08:00:38 --> Database Driver Class Initialized
DEBUG - 2018-01-23 08:00:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 08:00:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 08:00:38 --> Form Validation Class Initialized
INFO - 2018-01-23 08:00:38 --> Model Class Initialized
INFO - 2018-01-23 08:00:38 --> Controller Class Initialized
INFO - 2018-01-23 08:00:38 --> Model Class Initialized
DEBUG - 2018-01-23 08:00:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 08:00:38 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-23 08:00:38 --> Final output sent to browser
DEBUG - 2018-01-23 08:00:38 --> Total execution time: 0.0614
INFO - 2018-01-23 08:01:21 --> Config Class Initialized
INFO - 2018-01-23 08:01:21 --> Hooks Class Initialized
DEBUG - 2018-01-23 08:01:21 --> UTF-8 Support Enabled
INFO - 2018-01-23 08:01:21 --> Utf8 Class Initialized
INFO - 2018-01-23 08:01:21 --> URI Class Initialized
INFO - 2018-01-23 08:01:21 --> Router Class Initialized
INFO - 2018-01-23 08:01:21 --> Output Class Initialized
INFO - 2018-01-23 08:01:21 --> Security Class Initialized
DEBUG - 2018-01-23 08:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 08:01:21 --> Input Class Initialized
INFO - 2018-01-23 08:01:21 --> Language Class Initialized
INFO - 2018-01-23 08:01:21 --> Loader Class Initialized
INFO - 2018-01-23 08:01:21 --> Helper loaded: url_helper
INFO - 2018-01-23 08:01:21 --> Helper loaded: form_helper
INFO - 2018-01-23 08:01:21 --> Database Driver Class Initialized
DEBUG - 2018-01-23 08:01:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 08:01:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 08:01:21 --> Form Validation Class Initialized
INFO - 2018-01-23 08:01:21 --> Model Class Initialized
INFO - 2018-01-23 08:01:21 --> Controller Class Initialized
INFO - 2018-01-23 08:01:21 --> Model Class Initialized
DEBUG - 2018-01-23 08:01:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 08:01:21 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-23 08:01:21 --> Final output sent to browser
DEBUG - 2018-01-23 08:01:21 --> Total execution time: 0.0373
INFO - 2018-01-23 08:05:22 --> Config Class Initialized
INFO - 2018-01-23 08:05:22 --> Hooks Class Initialized
DEBUG - 2018-01-23 08:05:22 --> UTF-8 Support Enabled
INFO - 2018-01-23 08:05:22 --> Utf8 Class Initialized
INFO - 2018-01-23 08:05:22 --> URI Class Initialized
INFO - 2018-01-23 08:05:22 --> Router Class Initialized
INFO - 2018-01-23 08:05:22 --> Output Class Initialized
INFO - 2018-01-23 08:05:22 --> Security Class Initialized
DEBUG - 2018-01-23 08:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 08:05:22 --> Input Class Initialized
INFO - 2018-01-23 08:05:22 --> Language Class Initialized
INFO - 2018-01-23 08:05:22 --> Loader Class Initialized
INFO - 2018-01-23 08:05:22 --> Helper loaded: url_helper
INFO - 2018-01-23 08:05:22 --> Helper loaded: form_helper
INFO - 2018-01-23 08:05:22 --> Database Driver Class Initialized
DEBUG - 2018-01-23 08:05:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 08:05:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 08:05:22 --> Form Validation Class Initialized
INFO - 2018-01-23 08:05:22 --> Model Class Initialized
INFO - 2018-01-23 08:05:22 --> Controller Class Initialized
INFO - 2018-01-23 08:05:22 --> Model Class Initialized
DEBUG - 2018-01-23 08:05:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 08:05:22 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-23 08:05:22 --> Final output sent to browser
DEBUG - 2018-01-23 08:05:22 --> Total execution time: 0.0615
INFO - 2018-01-23 08:05:39 --> Config Class Initialized
INFO - 2018-01-23 08:05:39 --> Hooks Class Initialized
DEBUG - 2018-01-23 08:05:39 --> UTF-8 Support Enabled
INFO - 2018-01-23 08:05:39 --> Utf8 Class Initialized
INFO - 2018-01-23 08:05:39 --> URI Class Initialized
INFO - 2018-01-23 08:05:39 --> Router Class Initialized
INFO - 2018-01-23 08:05:39 --> Output Class Initialized
INFO - 2018-01-23 08:05:39 --> Security Class Initialized
DEBUG - 2018-01-23 08:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 08:05:39 --> Input Class Initialized
INFO - 2018-01-23 08:05:39 --> Language Class Initialized
INFO - 2018-01-23 08:05:39 --> Loader Class Initialized
INFO - 2018-01-23 08:05:39 --> Helper loaded: url_helper
INFO - 2018-01-23 08:05:39 --> Helper loaded: form_helper
INFO - 2018-01-23 08:05:39 --> Database Driver Class Initialized
DEBUG - 2018-01-23 08:05:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 08:05:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 08:05:39 --> Form Validation Class Initialized
INFO - 2018-01-23 08:05:39 --> Model Class Initialized
INFO - 2018-01-23 08:05:39 --> Controller Class Initialized
INFO - 2018-01-23 08:05:39 --> Model Class Initialized
DEBUG - 2018-01-23 08:05:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 08:05:39 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-23 08:05:39 --> Final output sent to browser
DEBUG - 2018-01-23 08:05:39 --> Total execution time: 0.0509
INFO - 2018-01-23 08:06:08 --> Config Class Initialized
INFO - 2018-01-23 08:06:08 --> Hooks Class Initialized
DEBUG - 2018-01-23 08:06:08 --> UTF-8 Support Enabled
INFO - 2018-01-23 08:06:08 --> Utf8 Class Initialized
INFO - 2018-01-23 08:06:08 --> URI Class Initialized
INFO - 2018-01-23 08:06:08 --> Router Class Initialized
INFO - 2018-01-23 08:06:08 --> Output Class Initialized
INFO - 2018-01-23 08:06:08 --> Security Class Initialized
DEBUG - 2018-01-23 08:06:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 08:06:08 --> Input Class Initialized
INFO - 2018-01-23 08:06:08 --> Language Class Initialized
INFO - 2018-01-23 08:06:08 --> Loader Class Initialized
INFO - 2018-01-23 08:06:08 --> Helper loaded: url_helper
INFO - 2018-01-23 08:06:08 --> Helper loaded: form_helper
INFO - 2018-01-23 08:06:08 --> Database Driver Class Initialized
DEBUG - 2018-01-23 08:06:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 08:06:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 08:06:08 --> Form Validation Class Initialized
INFO - 2018-01-23 08:06:08 --> Model Class Initialized
INFO - 2018-01-23 08:06:08 --> Controller Class Initialized
INFO - 2018-01-23 08:06:08 --> Model Class Initialized
DEBUG - 2018-01-23 08:06:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 08:06:08 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-23 08:06:08 --> Final output sent to browser
DEBUG - 2018-01-23 08:06:08 --> Total execution time: 0.0399
INFO - 2018-01-23 08:08:03 --> Config Class Initialized
INFO - 2018-01-23 08:08:03 --> Hooks Class Initialized
DEBUG - 2018-01-23 08:08:03 --> UTF-8 Support Enabled
INFO - 2018-01-23 08:08:03 --> Utf8 Class Initialized
INFO - 2018-01-23 08:08:03 --> URI Class Initialized
INFO - 2018-01-23 08:08:03 --> Router Class Initialized
INFO - 2018-01-23 08:08:03 --> Output Class Initialized
INFO - 2018-01-23 08:08:03 --> Security Class Initialized
DEBUG - 2018-01-23 08:08:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 08:08:03 --> Input Class Initialized
INFO - 2018-01-23 08:08:03 --> Language Class Initialized
INFO - 2018-01-23 08:08:03 --> Loader Class Initialized
INFO - 2018-01-23 08:08:03 --> Helper loaded: url_helper
INFO - 2018-01-23 08:08:03 --> Helper loaded: form_helper
INFO - 2018-01-23 08:08:03 --> Database Driver Class Initialized
DEBUG - 2018-01-23 08:08:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 08:08:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 08:08:03 --> Form Validation Class Initialized
INFO - 2018-01-23 08:08:03 --> Model Class Initialized
INFO - 2018-01-23 08:08:03 --> Controller Class Initialized
INFO - 2018-01-23 08:08:03 --> Model Class Initialized
DEBUG - 2018-01-23 08:08:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 08:08:03 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-23 08:08:03 --> Final output sent to browser
DEBUG - 2018-01-23 08:08:03 --> Total execution time: 0.0398
INFO - 2018-01-23 08:08:08 --> Config Class Initialized
INFO - 2018-01-23 08:08:08 --> Hooks Class Initialized
DEBUG - 2018-01-23 08:08:08 --> UTF-8 Support Enabled
INFO - 2018-01-23 08:08:08 --> Utf8 Class Initialized
INFO - 2018-01-23 08:08:08 --> URI Class Initialized
INFO - 2018-01-23 08:08:08 --> Router Class Initialized
INFO - 2018-01-23 08:08:08 --> Output Class Initialized
INFO - 2018-01-23 08:08:08 --> Security Class Initialized
DEBUG - 2018-01-23 08:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 08:08:08 --> Input Class Initialized
INFO - 2018-01-23 08:08:08 --> Language Class Initialized
INFO - 2018-01-23 08:08:08 --> Loader Class Initialized
INFO - 2018-01-23 08:08:08 --> Helper loaded: url_helper
INFO - 2018-01-23 08:08:08 --> Helper loaded: form_helper
INFO - 2018-01-23 08:08:08 --> Database Driver Class Initialized
DEBUG - 2018-01-23 08:08:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 08:08:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 08:08:08 --> Form Validation Class Initialized
INFO - 2018-01-23 08:08:08 --> Model Class Initialized
INFO - 2018-01-23 08:08:08 --> Controller Class Initialized
INFO - 2018-01-23 08:08:08 --> Model Class Initialized
DEBUG - 2018-01-23 08:08:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 08:08:08 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-23 08:08:08 --> Final output sent to browser
DEBUG - 2018-01-23 08:08:08 --> Total execution time: 0.0413
INFO - 2018-01-23 08:08:24 --> Config Class Initialized
INFO - 2018-01-23 08:08:24 --> Hooks Class Initialized
DEBUG - 2018-01-23 08:08:24 --> UTF-8 Support Enabled
INFO - 2018-01-23 08:08:24 --> Utf8 Class Initialized
INFO - 2018-01-23 08:08:24 --> URI Class Initialized
INFO - 2018-01-23 08:08:24 --> Router Class Initialized
INFO - 2018-01-23 08:08:24 --> Output Class Initialized
INFO - 2018-01-23 08:08:24 --> Security Class Initialized
DEBUG - 2018-01-23 08:08:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 08:08:24 --> Input Class Initialized
INFO - 2018-01-23 08:08:24 --> Language Class Initialized
INFO - 2018-01-23 08:08:24 --> Loader Class Initialized
INFO - 2018-01-23 08:08:24 --> Helper loaded: url_helper
INFO - 2018-01-23 08:08:24 --> Helper loaded: form_helper
INFO - 2018-01-23 08:08:24 --> Database Driver Class Initialized
DEBUG - 2018-01-23 08:08:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 08:08:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 08:08:24 --> Form Validation Class Initialized
INFO - 2018-01-23 08:08:24 --> Model Class Initialized
INFO - 2018-01-23 08:08:24 --> Controller Class Initialized
INFO - 2018-01-23 08:08:24 --> Model Class Initialized
DEBUG - 2018-01-23 08:08:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 08:08:24 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-23 08:08:24 --> Final output sent to browser
DEBUG - 2018-01-23 08:08:24 --> Total execution time: 0.0515
INFO - 2018-01-23 08:10:18 --> Config Class Initialized
INFO - 2018-01-23 08:10:18 --> Hooks Class Initialized
DEBUG - 2018-01-23 08:10:18 --> UTF-8 Support Enabled
INFO - 2018-01-23 08:10:18 --> Utf8 Class Initialized
INFO - 2018-01-23 08:10:18 --> URI Class Initialized
INFO - 2018-01-23 08:10:18 --> Router Class Initialized
INFO - 2018-01-23 08:10:18 --> Output Class Initialized
INFO - 2018-01-23 08:10:18 --> Security Class Initialized
DEBUG - 2018-01-23 08:10:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 08:10:18 --> Input Class Initialized
INFO - 2018-01-23 08:10:18 --> Language Class Initialized
INFO - 2018-01-23 08:10:18 --> Loader Class Initialized
INFO - 2018-01-23 08:10:18 --> Helper loaded: url_helper
INFO - 2018-01-23 08:10:18 --> Helper loaded: form_helper
INFO - 2018-01-23 08:10:18 --> Database Driver Class Initialized
DEBUG - 2018-01-23 08:10:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 08:10:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 08:10:18 --> Form Validation Class Initialized
INFO - 2018-01-23 08:10:18 --> Model Class Initialized
INFO - 2018-01-23 08:10:18 --> Controller Class Initialized
INFO - 2018-01-23 08:10:18 --> Model Class Initialized
DEBUG - 2018-01-23 08:10:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 08:10:18 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-23 08:10:18 --> Final output sent to browser
DEBUG - 2018-01-23 08:10:18 --> Total execution time: 0.0492
INFO - 2018-01-23 08:10:48 --> Config Class Initialized
INFO - 2018-01-23 08:10:48 --> Hooks Class Initialized
DEBUG - 2018-01-23 08:10:48 --> UTF-8 Support Enabled
INFO - 2018-01-23 08:10:48 --> Utf8 Class Initialized
INFO - 2018-01-23 08:10:48 --> URI Class Initialized
INFO - 2018-01-23 08:10:48 --> Router Class Initialized
INFO - 2018-01-23 08:10:48 --> Output Class Initialized
INFO - 2018-01-23 08:10:48 --> Security Class Initialized
DEBUG - 2018-01-23 08:10:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-23 08:10:48 --> Input Class Initialized
INFO - 2018-01-23 08:10:48 --> Language Class Initialized
INFO - 2018-01-23 08:10:48 --> Loader Class Initialized
INFO - 2018-01-23 08:10:48 --> Helper loaded: url_helper
INFO - 2018-01-23 08:10:48 --> Helper loaded: form_helper
INFO - 2018-01-23 08:10:48 --> Database Driver Class Initialized
DEBUG - 2018-01-23 08:10:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-23 08:10:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-23 08:10:48 --> Form Validation Class Initialized
INFO - 2018-01-23 08:10:48 --> Model Class Initialized
INFO - 2018-01-23 08:10:48 --> Controller Class Initialized
INFO - 2018-01-23 08:10:48 --> Model Class Initialized
DEBUG - 2018-01-23 08:10:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-23 08:10:48 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-23 08:10:48 --> Final output sent to browser
DEBUG - 2018-01-23 08:10:48 --> Total execution time: 0.0505
