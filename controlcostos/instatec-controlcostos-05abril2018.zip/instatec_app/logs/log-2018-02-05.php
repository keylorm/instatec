<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-02-05 00:04:20 --> Config Class Initialized
INFO - 2018-02-05 00:04:20 --> Hooks Class Initialized
DEBUG - 2018-02-05 00:04:20 --> UTF-8 Support Enabled
INFO - 2018-02-05 00:04:20 --> Utf8 Class Initialized
INFO - 2018-02-05 00:04:20 --> URI Class Initialized
INFO - 2018-02-05 00:04:20 --> Router Class Initialized
INFO - 2018-02-05 00:04:20 --> Output Class Initialized
INFO - 2018-02-05 00:04:20 --> Security Class Initialized
DEBUG - 2018-02-05 00:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-05 00:04:20 --> Input Class Initialized
INFO - 2018-02-05 00:04:20 --> Language Class Initialized
INFO - 2018-02-05 00:04:20 --> Loader Class Initialized
INFO - 2018-02-05 00:04:20 --> Helper loaded: url_helper
INFO - 2018-02-05 00:04:20 --> Helper loaded: form_helper
INFO - 2018-02-05 00:04:20 --> Database Driver Class Initialized
DEBUG - 2018-02-05 00:04:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-05 00:04:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-05 00:04:20 --> Form Validation Class Initialized
INFO - 2018-02-05 00:04:20 --> Model Class Initialized
INFO - 2018-02-05 00:04:20 --> Controller Class Initialized
INFO - 2018-02-05 00:04:20 --> Model Class Initialized
DEBUG - 2018-02-05 00:04:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-05 00:04:20 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-05 00:04:20 --> Final output sent to browser
DEBUG - 2018-02-05 00:04:20 --> Total execution time: 0.0777
INFO - 2018-02-05 00:04:20 --> Config Class Initialized
INFO - 2018-02-05 00:04:20 --> Hooks Class Initialized
INFO - 2018-02-05 00:04:20 --> Config Class Initialized
INFO - 2018-02-05 00:04:20 --> Config Class Initialized
INFO - 2018-02-05 00:04:20 --> Hooks Class Initialized
INFO - 2018-02-05 00:04:20 --> Hooks Class Initialized
DEBUG - 2018-02-05 00:04:20 --> UTF-8 Support Enabled
INFO - 2018-02-05 00:04:20 --> Utf8 Class Initialized
DEBUG - 2018-02-05 00:04:20 --> UTF-8 Support Enabled
INFO - 2018-02-05 00:04:20 --> Config Class Initialized
INFO - 2018-02-05 00:04:20 --> Utf8 Class Initialized
DEBUG - 2018-02-05 00:04:20 --> UTF-8 Support Enabled
INFO - 2018-02-05 00:04:20 --> Hooks Class Initialized
INFO - 2018-02-05 00:04:20 --> Utf8 Class Initialized
INFO - 2018-02-05 00:04:20 --> URI Class Initialized
INFO - 2018-02-05 00:04:20 --> URI Class Initialized
INFO - 2018-02-05 00:04:20 --> URI Class Initialized
INFO - 2018-02-05 00:04:20 --> Router Class Initialized
INFO - 2018-02-05 00:04:20 --> Router Class Initialized
DEBUG - 2018-02-05 00:04:20 --> UTF-8 Support Enabled
INFO - 2018-02-05 00:04:20 --> Utf8 Class Initialized
INFO - 2018-02-05 00:04:20 --> Router Class Initialized
INFO - 2018-02-05 00:04:20 --> URI Class Initialized
INFO - 2018-02-05 00:04:20 --> Output Class Initialized
INFO - 2018-02-05 00:04:20 --> Output Class Initialized
INFO - 2018-02-05 00:04:20 --> Security Class Initialized
INFO - 2018-02-05 00:04:20 --> Security Class Initialized
INFO - 2018-02-05 00:04:20 --> Router Class Initialized
INFO - 2018-02-05 00:04:20 --> Output Class Initialized
DEBUG - 2018-02-05 00:04:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 00:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-05 00:04:20 --> Security Class Initialized
INFO - 2018-02-05 00:04:20 --> Input Class Initialized
INFO - 2018-02-05 00:04:20 --> Input Class Initialized
INFO - 2018-02-05 00:04:20 --> Output Class Initialized
INFO - 2018-02-05 00:04:20 --> Language Class Initialized
INFO - 2018-02-05 00:04:20 --> Language Class Initialized
DEBUG - 2018-02-05 00:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-05 00:04:20 --> Input Class Initialized
INFO - 2018-02-05 00:04:20 --> Security Class Initialized
ERROR - 2018-02-05 00:04:20 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-05 00:04:20 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-05 00:04:20 --> Language Class Initialized
DEBUG - 2018-02-05 00:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-05 00:04:20 --> Input Class Initialized
ERROR - 2018-02-05 00:04:20 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-05 00:04:20 --> Language Class Initialized
ERROR - 2018-02-05 00:04:20 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-05 00:04:20 --> Config Class Initialized
INFO - 2018-02-05 00:04:20 --> Hooks Class Initialized
INFO - 2018-02-05 00:04:20 --> Config Class Initialized
INFO - 2018-02-05 00:04:20 --> Hooks Class Initialized
INFO - 2018-02-05 00:04:20 --> Config Class Initialized
INFO - 2018-02-05 00:04:20 --> Hooks Class Initialized
DEBUG - 2018-02-05 00:04:20 --> UTF-8 Support Enabled
INFO - 2018-02-05 00:04:20 --> Utf8 Class Initialized
DEBUG - 2018-02-05 00:04:20 --> UTF-8 Support Enabled
INFO - 2018-02-05 00:04:20 --> URI Class Initialized
INFO - 2018-02-05 00:04:20 --> Utf8 Class Initialized
DEBUG - 2018-02-05 00:04:20 --> UTF-8 Support Enabled
INFO - 2018-02-05 00:04:20 --> Utf8 Class Initialized
INFO - 2018-02-05 00:04:20 --> URI Class Initialized
INFO - 2018-02-05 00:04:20 --> Router Class Initialized
INFO - 2018-02-05 00:04:20 --> URI Class Initialized
INFO - 2018-02-05 00:04:20 --> Router Class Initialized
INFO - 2018-02-05 00:04:20 --> Output Class Initialized
INFO - 2018-02-05 00:04:20 --> Router Class Initialized
INFO - 2018-02-05 00:04:20 --> Output Class Initialized
INFO - 2018-02-05 00:04:20 --> Security Class Initialized
INFO - 2018-02-05 00:04:20 --> Output Class Initialized
INFO - 2018-02-05 00:04:20 --> Security Class Initialized
INFO - 2018-02-05 00:04:20 --> Security Class Initialized
DEBUG - 2018-02-05 00:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-05 00:04:20 --> Input Class Initialized
INFO - 2018-02-05 00:04:20 --> Language Class Initialized
DEBUG - 2018-02-05 00:04:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 00:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-05 00:04:20 --> Input Class Initialized
INFO - 2018-02-05 00:04:20 --> Input Class Initialized
INFO - 2018-02-05 00:04:20 --> Language Class Initialized
INFO - 2018-02-05 00:04:20 --> Language Class Initialized
ERROR - 2018-02-05 00:04:20 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-05 00:04:20 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-05 00:04:20 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-05 00:04:55 --> Config Class Initialized
INFO - 2018-02-05 00:04:55 --> Hooks Class Initialized
DEBUG - 2018-02-05 00:04:55 --> UTF-8 Support Enabled
INFO - 2018-02-05 00:04:55 --> Utf8 Class Initialized
INFO - 2018-02-05 00:04:55 --> URI Class Initialized
INFO - 2018-02-05 00:04:55 --> Router Class Initialized
INFO - 2018-02-05 00:04:55 --> Output Class Initialized
INFO - 2018-02-05 00:04:55 --> Security Class Initialized
DEBUG - 2018-02-05 00:04:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-05 00:04:55 --> Input Class Initialized
INFO - 2018-02-05 00:04:55 --> Language Class Initialized
INFO - 2018-02-05 00:04:55 --> Loader Class Initialized
INFO - 2018-02-05 00:04:55 --> Helper loaded: url_helper
INFO - 2018-02-05 00:04:55 --> Helper loaded: form_helper
INFO - 2018-02-05 00:04:55 --> Database Driver Class Initialized
DEBUG - 2018-02-05 00:04:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-05 00:04:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-05 00:04:55 --> Form Validation Class Initialized
INFO - 2018-02-05 00:04:55 --> Model Class Initialized
INFO - 2018-02-05 00:04:55 --> Controller Class Initialized
INFO - 2018-02-05 00:04:55 --> Model Class Initialized
DEBUG - 2018-02-05 00:04:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-05 00:04:55 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-05 00:04:55 --> Final output sent to browser
DEBUG - 2018-02-05 00:04:55 --> Total execution time: 0.0971
INFO - 2018-02-05 00:23:50 --> Config Class Initialized
INFO - 2018-02-05 00:23:50 --> Hooks Class Initialized
DEBUG - 2018-02-05 00:23:50 --> UTF-8 Support Enabled
INFO - 2018-02-05 00:23:50 --> Utf8 Class Initialized
INFO - 2018-02-05 00:23:50 --> URI Class Initialized
INFO - 2018-02-05 00:23:50 --> Router Class Initialized
INFO - 2018-02-05 00:23:50 --> Output Class Initialized
INFO - 2018-02-05 00:23:50 --> Security Class Initialized
DEBUG - 2018-02-05 00:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-05 00:23:50 --> Input Class Initialized
INFO - 2018-02-05 00:23:50 --> Language Class Initialized
INFO - 2018-02-05 00:23:50 --> Loader Class Initialized
INFO - 2018-02-05 00:23:50 --> Helper loaded: url_helper
INFO - 2018-02-05 00:23:50 --> Helper loaded: form_helper
INFO - 2018-02-05 00:23:50 --> Database Driver Class Initialized
DEBUG - 2018-02-05 00:23:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-05 00:23:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-05 00:23:50 --> Form Validation Class Initialized
INFO - 2018-02-05 00:23:50 --> Model Class Initialized
INFO - 2018-02-05 00:23:50 --> Controller Class Initialized
INFO - 2018-02-05 00:23:50 --> Model Class Initialized
DEBUG - 2018-02-05 00:23:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-05 00:23:50 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-05 00:23:50 --> Final output sent to browser
DEBUG - 2018-02-05 00:23:50 --> Total execution time: 0.0871
INFO - 2018-02-05 00:24:15 --> Config Class Initialized
INFO - 2018-02-05 00:24:15 --> Hooks Class Initialized
DEBUG - 2018-02-05 00:24:15 --> UTF-8 Support Enabled
INFO - 2018-02-05 00:24:15 --> Utf8 Class Initialized
INFO - 2018-02-05 00:24:15 --> URI Class Initialized
INFO - 2018-02-05 00:24:15 --> Router Class Initialized
INFO - 2018-02-05 00:24:15 --> Output Class Initialized
INFO - 2018-02-05 00:24:15 --> Security Class Initialized
DEBUG - 2018-02-05 00:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-05 00:24:15 --> Input Class Initialized
INFO - 2018-02-05 00:24:15 --> Language Class Initialized
INFO - 2018-02-05 00:24:15 --> Loader Class Initialized
INFO - 2018-02-05 00:24:15 --> Helper loaded: url_helper
INFO - 2018-02-05 00:24:15 --> Helper loaded: form_helper
INFO - 2018-02-05 00:24:15 --> Database Driver Class Initialized
DEBUG - 2018-02-05 00:24:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-05 00:24:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-05 00:24:15 --> Form Validation Class Initialized
INFO - 2018-02-05 00:24:15 --> Model Class Initialized
INFO - 2018-02-05 00:24:15 --> Controller Class Initialized
INFO - 2018-02-05 00:24:15 --> Model Class Initialized
DEBUG - 2018-02-05 00:24:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-05 00:24:15 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-05 00:24:15 --> Final output sent to browser
DEBUG - 2018-02-05 00:24:15 --> Total execution time: 0.0535
INFO - 2018-02-05 00:24:59 --> Config Class Initialized
INFO - 2018-02-05 00:24:59 --> Hooks Class Initialized
DEBUG - 2018-02-05 00:24:59 --> UTF-8 Support Enabled
INFO - 2018-02-05 00:24:59 --> Utf8 Class Initialized
INFO - 2018-02-05 00:24:59 --> URI Class Initialized
INFO - 2018-02-05 00:24:59 --> Router Class Initialized
INFO - 2018-02-05 00:24:59 --> Output Class Initialized
INFO - 2018-02-05 00:24:59 --> Security Class Initialized
DEBUG - 2018-02-05 00:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-05 00:24:59 --> Input Class Initialized
INFO - 2018-02-05 00:24:59 --> Language Class Initialized
INFO - 2018-02-05 00:24:59 --> Loader Class Initialized
INFO - 2018-02-05 00:24:59 --> Helper loaded: url_helper
INFO - 2018-02-05 00:24:59 --> Helper loaded: form_helper
INFO - 2018-02-05 00:24:59 --> Database Driver Class Initialized
DEBUG - 2018-02-05 00:24:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-05 00:24:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-05 00:24:59 --> Form Validation Class Initialized
INFO - 2018-02-05 00:24:59 --> Model Class Initialized
INFO - 2018-02-05 00:24:59 --> Controller Class Initialized
INFO - 2018-02-05 00:24:59 --> Model Class Initialized
DEBUG - 2018-02-05 00:24:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-05 00:24:59 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-05 00:24:59 --> Final output sent to browser
DEBUG - 2018-02-05 00:24:59 --> Total execution time: 0.0479
INFO - 2018-02-05 00:25:56 --> Config Class Initialized
INFO - 2018-02-05 00:25:56 --> Hooks Class Initialized
DEBUG - 2018-02-05 00:25:56 --> UTF-8 Support Enabled
INFO - 2018-02-05 00:25:56 --> Utf8 Class Initialized
INFO - 2018-02-05 00:25:56 --> URI Class Initialized
INFO - 2018-02-05 00:25:56 --> Router Class Initialized
INFO - 2018-02-05 00:25:56 --> Output Class Initialized
INFO - 2018-02-05 00:25:56 --> Security Class Initialized
DEBUG - 2018-02-05 00:25:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-05 00:25:56 --> Input Class Initialized
INFO - 2018-02-05 00:25:56 --> Language Class Initialized
INFO - 2018-02-05 00:25:56 --> Loader Class Initialized
INFO - 2018-02-05 00:25:56 --> Helper loaded: url_helper
INFO - 2018-02-05 00:25:56 --> Helper loaded: form_helper
INFO - 2018-02-05 00:25:56 --> Database Driver Class Initialized
DEBUG - 2018-02-05 00:25:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-05 00:25:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-05 00:25:56 --> Form Validation Class Initialized
INFO - 2018-02-05 00:25:56 --> Model Class Initialized
INFO - 2018-02-05 00:25:56 --> Controller Class Initialized
INFO - 2018-02-05 00:25:56 --> Model Class Initialized
DEBUG - 2018-02-05 00:25:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-05 00:25:56 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-05 00:25:56 --> Final output sent to browser
DEBUG - 2018-02-05 00:25:56 --> Total execution time: 0.0558
INFO - 2018-02-05 00:26:36 --> Config Class Initialized
INFO - 2018-02-05 00:26:36 --> Hooks Class Initialized
DEBUG - 2018-02-05 00:26:36 --> UTF-8 Support Enabled
INFO - 2018-02-05 00:26:36 --> Utf8 Class Initialized
INFO - 2018-02-05 00:26:36 --> URI Class Initialized
INFO - 2018-02-05 00:26:36 --> Router Class Initialized
INFO - 2018-02-05 00:26:36 --> Output Class Initialized
INFO - 2018-02-05 00:26:36 --> Security Class Initialized
DEBUG - 2018-02-05 00:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-05 00:26:36 --> Input Class Initialized
INFO - 2018-02-05 00:26:36 --> Language Class Initialized
INFO - 2018-02-05 00:26:36 --> Loader Class Initialized
INFO - 2018-02-05 00:26:36 --> Helper loaded: url_helper
INFO - 2018-02-05 00:26:36 --> Helper loaded: form_helper
INFO - 2018-02-05 00:26:36 --> Database Driver Class Initialized
DEBUG - 2018-02-05 00:26:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-05 00:26:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-05 00:26:36 --> Form Validation Class Initialized
INFO - 2018-02-05 00:26:36 --> Model Class Initialized
INFO - 2018-02-05 00:26:36 --> Controller Class Initialized
INFO - 2018-02-05 00:26:36 --> Model Class Initialized
DEBUG - 2018-02-05 00:26:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-05 00:26:36 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-05 00:26:36 --> Final output sent to browser
DEBUG - 2018-02-05 00:26:36 --> Total execution time: 0.0967
INFO - 2018-02-05 00:26:48 --> Config Class Initialized
INFO - 2018-02-05 00:26:48 --> Hooks Class Initialized
INFO - 2018-02-05 00:26:48 --> Config Class Initialized
INFO - 2018-02-05 00:26:48 --> Config Class Initialized
INFO - 2018-02-05 00:26:48 --> Hooks Class Initialized
INFO - 2018-02-05 00:26:48 --> Hooks Class Initialized
INFO - 2018-02-05 00:26:48 --> Config Class Initialized
DEBUG - 2018-02-05 00:26:48 --> UTF-8 Support Enabled
INFO - 2018-02-05 00:26:48 --> Hooks Class Initialized
INFO - 2018-02-05 00:26:48 --> Utf8 Class Initialized
DEBUG - 2018-02-05 00:26:48 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 00:26:48 --> UTF-8 Support Enabled
INFO - 2018-02-05 00:26:48 --> URI Class Initialized
INFO - 2018-02-05 00:26:48 --> Utf8 Class Initialized
INFO - 2018-02-05 00:26:48 --> Utf8 Class Initialized
DEBUG - 2018-02-05 00:26:48 --> UTF-8 Support Enabled
INFO - 2018-02-05 00:26:48 --> Utf8 Class Initialized
INFO - 2018-02-05 00:26:48 --> URI Class Initialized
INFO - 2018-02-05 00:26:48 --> URI Class Initialized
INFO - 2018-02-05 00:26:48 --> Router Class Initialized
INFO - 2018-02-05 00:26:48 --> URI Class Initialized
INFO - 2018-02-05 00:26:48 --> Router Class Initialized
INFO - 2018-02-05 00:26:48 --> Router Class Initialized
INFO - 2018-02-05 00:26:48 --> Output Class Initialized
INFO - 2018-02-05 00:26:48 --> Output Class Initialized
INFO - 2018-02-05 00:26:48 --> Router Class Initialized
INFO - 2018-02-05 00:26:48 --> Output Class Initialized
INFO - 2018-02-05 00:26:48 --> Security Class Initialized
INFO - 2018-02-05 00:26:48 --> Security Class Initialized
INFO - 2018-02-05 00:26:48 --> Security Class Initialized
DEBUG - 2018-02-05 00:26:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 00:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-05 00:26:48 --> Output Class Initialized
INFO - 2018-02-05 00:26:48 --> Input Class Initialized
INFO - 2018-02-05 00:26:48 --> Input Class Initialized
INFO - 2018-02-05 00:26:48 --> Language Class Initialized
DEBUG - 2018-02-05 00:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-05 00:26:48 --> Input Class Initialized
INFO - 2018-02-05 00:26:48 --> Language Class Initialized
INFO - 2018-02-05 00:26:48 --> Security Class Initialized
ERROR - 2018-02-05 00:26:48 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-05 00:26:48 --> Language Class Initialized
ERROR - 2018-02-05 00:26:48 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-02-05 00:26:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-05 00:26:48 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-05 00:26:48 --> Input Class Initialized
INFO - 2018-02-05 00:26:48 --> Language Class Initialized
ERROR - 2018-02-05 00:26:48 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-05 00:26:48 --> Config Class Initialized
INFO - 2018-02-05 00:26:48 --> Config Class Initialized
INFO - 2018-02-05 00:26:48 --> Config Class Initialized
INFO - 2018-02-05 00:26:48 --> Hooks Class Initialized
INFO - 2018-02-05 00:26:48 --> Hooks Class Initialized
INFO - 2018-02-05 00:26:48 --> Hooks Class Initialized
DEBUG - 2018-02-05 00:26:48 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 00:26:48 --> UTF-8 Support Enabled
INFO - 2018-02-05 00:26:48 --> Utf8 Class Initialized
INFO - 2018-02-05 00:26:48 --> Utf8 Class Initialized
DEBUG - 2018-02-05 00:26:48 --> UTF-8 Support Enabled
INFO - 2018-02-05 00:26:48 --> Utf8 Class Initialized
INFO - 2018-02-05 00:26:48 --> URI Class Initialized
INFO - 2018-02-05 00:26:48 --> URI Class Initialized
INFO - 2018-02-05 00:26:48 --> URI Class Initialized
INFO - 2018-02-05 00:26:48 --> Router Class Initialized
INFO - 2018-02-05 00:26:48 --> Router Class Initialized
INFO - 2018-02-05 00:26:48 --> Router Class Initialized
INFO - 2018-02-05 00:26:48 --> Output Class Initialized
INFO - 2018-02-05 00:26:48 --> Output Class Initialized
INFO - 2018-02-05 00:26:48 --> Output Class Initialized
INFO - 2018-02-05 00:26:48 --> Security Class Initialized
INFO - 2018-02-05 00:26:48 --> Security Class Initialized
INFO - 2018-02-05 00:26:48 --> Security Class Initialized
DEBUG - 2018-02-05 00:26:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 00:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-05 00:26:48 --> Input Class Initialized
INFO - 2018-02-05 00:26:48 --> Input Class Initialized
DEBUG - 2018-02-05 00:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-05 00:26:48 --> Language Class Initialized
INFO - 2018-02-05 00:26:48 --> Language Class Initialized
INFO - 2018-02-05 00:26:48 --> Input Class Initialized
INFO - 2018-02-05 00:26:48 --> Language Class Initialized
ERROR - 2018-02-05 00:26:48 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-05 00:26:48 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-05 00:26:48 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-05 00:27:09 --> Config Class Initialized
INFO - 2018-02-05 00:27:09 --> Hooks Class Initialized
DEBUG - 2018-02-05 00:27:09 --> UTF-8 Support Enabled
INFO - 2018-02-05 00:27:09 --> Utf8 Class Initialized
INFO - 2018-02-05 00:27:09 --> URI Class Initialized
INFO - 2018-02-05 00:27:09 --> Router Class Initialized
INFO - 2018-02-05 00:27:09 --> Output Class Initialized
INFO - 2018-02-05 00:27:09 --> Security Class Initialized
DEBUG - 2018-02-05 00:27:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-05 00:27:09 --> Input Class Initialized
INFO - 2018-02-05 00:27:09 --> Language Class Initialized
INFO - 2018-02-05 00:27:09 --> Loader Class Initialized
INFO - 2018-02-05 00:27:09 --> Helper loaded: url_helper
INFO - 2018-02-05 00:27:09 --> Helper loaded: form_helper
INFO - 2018-02-05 00:27:09 --> Database Driver Class Initialized
DEBUG - 2018-02-05 00:27:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-05 00:27:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-05 00:27:09 --> Form Validation Class Initialized
INFO - 2018-02-05 00:27:09 --> Model Class Initialized
INFO - 2018-02-05 00:27:09 --> Controller Class Initialized
INFO - 2018-02-05 00:27:09 --> Model Class Initialized
DEBUG - 2018-02-05 00:27:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-05 00:27:09 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-05 00:27:09 --> Final output sent to browser
DEBUG - 2018-02-05 00:27:09 --> Total execution time: 0.0525
INFO - 2018-02-05 00:27:10 --> Config Class Initialized
INFO - 2018-02-05 00:27:10 --> Config Class Initialized
INFO - 2018-02-05 00:27:10 --> Hooks Class Initialized
INFO - 2018-02-05 00:27:10 --> Hooks Class Initialized
DEBUG - 2018-02-05 00:27:10 --> UTF-8 Support Enabled
INFO - 2018-02-05 00:27:10 --> Utf8 Class Initialized
DEBUG - 2018-02-05 00:27:10 --> UTF-8 Support Enabled
INFO - 2018-02-05 00:27:10 --> Utf8 Class Initialized
INFO - 2018-02-05 00:27:10 --> URI Class Initialized
INFO - 2018-02-05 00:27:10 --> URI Class Initialized
INFO - 2018-02-05 00:27:10 --> Router Class Initialized
INFO - 2018-02-05 00:27:10 --> Router Class Initialized
INFO - 2018-02-05 00:27:10 --> Output Class Initialized
INFO - 2018-02-05 00:27:10 --> Output Class Initialized
INFO - 2018-02-05 00:27:10 --> Security Class Initialized
INFO - 2018-02-05 00:27:10 --> Security Class Initialized
DEBUG - 2018-02-05 00:27:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 00:27:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-05 00:27:10 --> Input Class Initialized
INFO - 2018-02-05 00:27:10 --> Input Class Initialized
INFO - 2018-02-05 00:27:10 --> Language Class Initialized
INFO - 2018-02-05 00:27:10 --> Language Class Initialized
ERROR - 2018-02-05 00:27:10 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-05 00:27:10 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-05 00:27:10 --> Config Class Initialized
INFO - 2018-02-05 00:27:10 --> Hooks Class Initialized
INFO - 2018-02-05 00:27:10 --> Config Class Initialized
INFO - 2018-02-05 00:27:10 --> Hooks Class Initialized
DEBUG - 2018-02-05 00:27:10 --> UTF-8 Support Enabled
INFO - 2018-02-05 00:27:10 --> Utf8 Class Initialized
INFO - 2018-02-05 00:27:10 --> URI Class Initialized
DEBUG - 2018-02-05 00:27:10 --> UTF-8 Support Enabled
INFO - 2018-02-05 00:27:10 --> Utf8 Class Initialized
INFO - 2018-02-05 00:27:10 --> Router Class Initialized
INFO - 2018-02-05 00:27:10 --> URI Class Initialized
INFO - 2018-02-05 00:27:10 --> Output Class Initialized
INFO - 2018-02-05 00:27:10 --> Router Class Initialized
INFO - 2018-02-05 00:27:10 --> Security Class Initialized
INFO - 2018-02-05 00:27:10 --> Output Class Initialized
DEBUG - 2018-02-05 00:27:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-05 00:27:10 --> Input Class Initialized
INFO - 2018-02-05 00:27:10 --> Security Class Initialized
INFO - 2018-02-05 00:27:10 --> Language Class Initialized
DEBUG - 2018-02-05 00:27:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-05 00:27:10 --> Input Class Initialized
ERROR - 2018-02-05 00:27:10 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-05 00:27:10 --> Language Class Initialized
ERROR - 2018-02-05 00:27:10 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-05 00:27:10 --> Config Class Initialized
INFO - 2018-02-05 00:27:10 --> Hooks Class Initialized
INFO - 2018-02-05 00:27:10 --> Config Class Initialized
INFO - 2018-02-05 00:27:10 --> Config Class Initialized
INFO - 2018-02-05 00:27:10 --> Hooks Class Initialized
INFO - 2018-02-05 00:27:10 --> Hooks Class Initialized
DEBUG - 2018-02-05 00:27:10 --> UTF-8 Support Enabled
INFO - 2018-02-05 00:27:10 --> Utf8 Class Initialized
INFO - 2018-02-05 00:27:10 --> URI Class Initialized
DEBUG - 2018-02-05 00:27:10 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 00:27:10 --> UTF-8 Support Enabled
INFO - 2018-02-05 00:27:10 --> Router Class Initialized
INFO - 2018-02-05 00:27:10 --> Utf8 Class Initialized
INFO - 2018-02-05 00:27:10 --> Utf8 Class Initialized
INFO - 2018-02-05 00:27:10 --> URI Class Initialized
INFO - 2018-02-05 00:27:10 --> URI Class Initialized
INFO - 2018-02-05 00:27:10 --> Output Class Initialized
INFO - 2018-02-05 00:27:10 --> Security Class Initialized
INFO - 2018-02-05 00:27:10 --> Router Class Initialized
INFO - 2018-02-05 00:27:10 --> Router Class Initialized
DEBUG - 2018-02-05 00:27:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-05 00:27:10 --> Input Class Initialized
INFO - 2018-02-05 00:27:10 --> Output Class Initialized
INFO - 2018-02-05 00:27:10 --> Language Class Initialized
INFO - 2018-02-05 00:27:10 --> Output Class Initialized
INFO - 2018-02-05 00:27:10 --> Security Class Initialized
ERROR - 2018-02-05 00:27:10 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-05 00:27:10 --> Security Class Initialized
DEBUG - 2018-02-05 00:27:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-05 00:27:10 --> Input Class Initialized
DEBUG - 2018-02-05 00:27:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-05 00:27:10 --> Input Class Initialized
INFO - 2018-02-05 00:27:10 --> Language Class Initialized
INFO - 2018-02-05 00:27:10 --> Language Class Initialized
ERROR - 2018-02-05 00:27:10 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-05 00:27:10 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-05 00:30:34 --> Config Class Initialized
INFO - 2018-02-05 00:30:34 --> Hooks Class Initialized
DEBUG - 2018-02-05 00:30:34 --> UTF-8 Support Enabled
INFO - 2018-02-05 00:30:34 --> Utf8 Class Initialized
INFO - 2018-02-05 00:30:34 --> URI Class Initialized
INFO - 2018-02-05 00:30:34 --> Router Class Initialized
INFO - 2018-02-05 00:30:34 --> Output Class Initialized
INFO - 2018-02-05 00:30:34 --> Security Class Initialized
DEBUG - 2018-02-05 00:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-05 00:30:34 --> Input Class Initialized
INFO - 2018-02-05 00:30:34 --> Language Class Initialized
INFO - 2018-02-05 00:30:34 --> Loader Class Initialized
INFO - 2018-02-05 00:30:34 --> Helper loaded: url_helper
INFO - 2018-02-05 00:30:34 --> Helper loaded: form_helper
INFO - 2018-02-05 00:30:34 --> Database Driver Class Initialized
DEBUG - 2018-02-05 00:30:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-05 00:30:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-05 00:30:34 --> Form Validation Class Initialized
INFO - 2018-02-05 00:30:34 --> Model Class Initialized
INFO - 2018-02-05 00:30:34 --> Controller Class Initialized
INFO - 2018-02-05 00:30:34 --> Model Class Initialized
DEBUG - 2018-02-05 00:30:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-05 00:30:34 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-05 00:30:34 --> Final output sent to browser
DEBUG - 2018-02-05 00:30:34 --> Total execution time: 0.0809
