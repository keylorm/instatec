<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-03-24 00:02:50 --> Config Class Initialized
INFO - 2018-03-24 00:02:50 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:02:50 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:02:50 --> Utf8 Class Initialized
INFO - 2018-03-24 00:02:50 --> URI Class Initialized
INFO - 2018-03-24 00:02:50 --> Router Class Initialized
INFO - 2018-03-24 00:02:50 --> Output Class Initialized
INFO - 2018-03-24 00:02:50 --> Security Class Initialized
DEBUG - 2018-03-24 00:02:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:02:50 --> Input Class Initialized
INFO - 2018-03-24 00:02:50 --> Language Class Initialized
INFO - 2018-03-24 00:02:50 --> Loader Class Initialized
INFO - 2018-03-24 00:02:50 --> Helper loaded: url_helper
INFO - 2018-03-24 00:02:50 --> Helper loaded: form_helper
INFO - 2018-03-24 00:02:50 --> Database Driver Class Initialized
DEBUG - 2018-03-24 00:02:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 00:02:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 00:02:50 --> Form Validation Class Initialized
INFO - 2018-03-24 00:02:50 --> Model Class Initialized
INFO - 2018-03-24 00:02:50 --> Controller Class Initialized
ERROR - 2018-03-24 00:02:50 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1717
INFO - 2018-03-24 00:03:04 --> Config Class Initialized
INFO - 2018-03-24 00:03:04 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:03:04 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:03:04 --> Utf8 Class Initialized
INFO - 2018-03-24 00:03:04 --> URI Class Initialized
INFO - 2018-03-24 00:03:04 --> Router Class Initialized
INFO - 2018-03-24 00:03:04 --> Output Class Initialized
INFO - 2018-03-24 00:03:04 --> Security Class Initialized
DEBUG - 2018-03-24 00:03:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:03:04 --> Input Class Initialized
INFO - 2018-03-24 00:03:04 --> Language Class Initialized
INFO - 2018-03-24 00:03:04 --> Loader Class Initialized
INFO - 2018-03-24 00:03:04 --> Helper loaded: url_helper
INFO - 2018-03-24 00:03:04 --> Helper loaded: form_helper
INFO - 2018-03-24 00:03:04 --> Database Driver Class Initialized
DEBUG - 2018-03-24 00:03:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 00:03:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 00:03:04 --> Form Validation Class Initialized
INFO - 2018-03-24 00:03:04 --> Model Class Initialized
INFO - 2018-03-24 00:03:04 --> Controller Class Initialized
INFO - 2018-03-24 00:03:04 --> Model Class Initialized
INFO - 2018-03-24 00:03:04 --> Model Class Initialized
INFO - 2018-03-24 00:03:04 --> Model Class Initialized
INFO - 2018-03-24 00:03:04 --> Model Class Initialized
DEBUG - 2018-03-24 00:03:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 00:03:04 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-24 00:03:04 --> Final output sent to browser
DEBUG - 2018-03-24 00:03:04 --> Total execution time: 0.1577
INFO - 2018-03-24 00:03:05 --> Config Class Initialized
INFO - 2018-03-24 00:03:05 --> Hooks Class Initialized
INFO - 2018-03-24 00:03:05 --> Config Class Initialized
INFO - 2018-03-24 00:03:05 --> Hooks Class Initialized
INFO - 2018-03-24 00:03:05 --> Config Class Initialized
INFO - 2018-03-24 00:03:05 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:03:05 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:03:05 --> Utf8 Class Initialized
DEBUG - 2018-03-24 00:03:05 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:03:05 --> Utf8 Class Initialized
INFO - 2018-03-24 00:03:05 --> Config Class Initialized
INFO - 2018-03-24 00:03:05 --> Hooks Class Initialized
INFO - 2018-03-24 00:03:05 --> URI Class Initialized
DEBUG - 2018-03-24 00:03:05 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:03:05 --> URI Class Initialized
INFO - 2018-03-24 00:03:05 --> Utf8 Class Initialized
INFO - 2018-03-24 00:03:05 --> URI Class Initialized
INFO - 2018-03-24 00:03:05 --> Router Class Initialized
INFO - 2018-03-24 00:03:05 --> Router Class Initialized
DEBUG - 2018-03-24 00:03:05 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:03:05 --> Utf8 Class Initialized
INFO - 2018-03-24 00:03:05 --> Router Class Initialized
INFO - 2018-03-24 00:03:05 --> Output Class Initialized
INFO - 2018-03-24 00:03:05 --> Output Class Initialized
INFO - 2018-03-24 00:03:05 --> URI Class Initialized
INFO - 2018-03-24 00:03:05 --> Output Class Initialized
INFO - 2018-03-24 00:03:05 --> Security Class Initialized
INFO - 2018-03-24 00:03:05 --> Security Class Initialized
INFO - 2018-03-24 00:03:05 --> Router Class Initialized
INFO - 2018-03-24 00:03:05 --> Security Class Initialized
DEBUG - 2018-03-24 00:03:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-24 00:03:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:03:05 --> Input Class Initialized
INFO - 2018-03-24 00:03:05 --> Input Class Initialized
INFO - 2018-03-24 00:03:05 --> Output Class Initialized
DEBUG - 2018-03-24 00:03:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:03:05 --> Language Class Initialized
INFO - 2018-03-24 00:03:05 --> Input Class Initialized
INFO - 2018-03-24 00:03:05 --> Language Class Initialized
INFO - 2018-03-24 00:03:05 --> Language Class Initialized
INFO - 2018-03-24 00:03:05 --> Security Class Initialized
ERROR - 2018-03-24 00:03:05 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-24 00:03:05 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-24 00:03:05 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-24 00:03:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:03:05 --> Input Class Initialized
INFO - 2018-03-24 00:03:05 --> Language Class Initialized
ERROR - 2018-03-24 00:03:05 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-24 00:03:05 --> Config Class Initialized
INFO - 2018-03-24 00:03:05 --> Hooks Class Initialized
INFO - 2018-03-24 00:03:05 --> Config Class Initialized
INFO - 2018-03-24 00:03:05 --> Config Class Initialized
INFO - 2018-03-24 00:03:05 --> Hooks Class Initialized
INFO - 2018-03-24 00:03:05 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:03:05 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:03:05 --> Utf8 Class Initialized
DEBUG - 2018-03-24 00:03:05 --> UTF-8 Support Enabled
DEBUG - 2018-03-24 00:03:05 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:03:05 --> Utf8 Class Initialized
INFO - 2018-03-24 00:03:05 --> Utf8 Class Initialized
INFO - 2018-03-24 00:03:05 --> URI Class Initialized
INFO - 2018-03-24 00:03:05 --> URI Class Initialized
INFO - 2018-03-24 00:03:05 --> URI Class Initialized
INFO - 2018-03-24 00:03:05 --> Router Class Initialized
INFO - 2018-03-24 00:03:05 --> Router Class Initialized
INFO - 2018-03-24 00:03:05 --> Router Class Initialized
INFO - 2018-03-24 00:03:05 --> Output Class Initialized
INFO - 2018-03-24 00:03:05 --> Output Class Initialized
INFO - 2018-03-24 00:03:05 --> Output Class Initialized
INFO - 2018-03-24 00:03:05 --> Security Class Initialized
INFO - 2018-03-24 00:03:05 --> Security Class Initialized
INFO - 2018-03-24 00:03:05 --> Security Class Initialized
DEBUG - 2018-03-24 00:03:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:03:05 --> Input Class Initialized
DEBUG - 2018-03-24 00:03:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:03:05 --> Input Class Initialized
INFO - 2018-03-24 00:03:05 --> Language Class Initialized
DEBUG - 2018-03-24 00:03:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:03:05 --> Input Class Initialized
INFO - 2018-03-24 00:03:05 --> Language Class Initialized
INFO - 2018-03-24 00:03:05 --> Language Class Initialized
ERROR - 2018-03-24 00:03:05 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-24 00:03:05 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-24 00:03:05 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-24 00:03:05 --> Config Class Initialized
INFO - 2018-03-24 00:03:05 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:03:05 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:03:05 --> Utf8 Class Initialized
INFO - 2018-03-24 00:03:05 --> URI Class Initialized
INFO - 2018-03-24 00:03:05 --> Router Class Initialized
INFO - 2018-03-24 00:03:05 --> Output Class Initialized
INFO - 2018-03-24 00:03:05 --> Security Class Initialized
DEBUG - 2018-03-24 00:03:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:03:05 --> Input Class Initialized
INFO - 2018-03-24 00:03:05 --> Language Class Initialized
INFO - 2018-03-24 00:03:05 --> Loader Class Initialized
INFO - 2018-03-24 00:03:05 --> Helper loaded: url_helper
INFO - 2018-03-24 00:03:05 --> Helper loaded: form_helper
INFO - 2018-03-24 00:03:05 --> Database Driver Class Initialized
DEBUG - 2018-03-24 00:03:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 00:03:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 00:03:05 --> Form Validation Class Initialized
INFO - 2018-03-24 00:03:05 --> Model Class Initialized
INFO - 2018-03-24 00:03:05 --> Controller Class Initialized
INFO - 2018-03-24 00:03:05 --> Model Class Initialized
INFO - 2018-03-24 00:03:05 --> Model Class Initialized
INFO - 2018-03-24 00:03:05 --> Model Class Initialized
INFO - 2018-03-24 00:03:05 --> Model Class Initialized
DEBUG - 2018-03-24 00:03:05 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-03-24 00:03:05 --> Severity: Notice --> Undefined variable: result_fetch D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1711
ERROR - 2018-03-24 00:03:05 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1711
ERROR - 2018-03-24 00:03:05 --> Severity: Notice --> Undefined variable: result_fetch D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1728
INFO - 2018-03-24 00:03:39 --> Config Class Initialized
INFO - 2018-03-24 00:03:39 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:03:39 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:03:39 --> Utf8 Class Initialized
INFO - 2018-03-24 00:03:39 --> URI Class Initialized
INFO - 2018-03-24 00:03:39 --> Router Class Initialized
INFO - 2018-03-24 00:03:39 --> Output Class Initialized
INFO - 2018-03-24 00:03:39 --> Security Class Initialized
DEBUG - 2018-03-24 00:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:03:39 --> Input Class Initialized
INFO - 2018-03-24 00:03:39 --> Language Class Initialized
INFO - 2018-03-24 00:03:39 --> Loader Class Initialized
INFO - 2018-03-24 00:03:39 --> Helper loaded: url_helper
INFO - 2018-03-24 00:03:39 --> Helper loaded: form_helper
INFO - 2018-03-24 00:03:39 --> Database Driver Class Initialized
DEBUG - 2018-03-24 00:03:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 00:03:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 00:03:39 --> Form Validation Class Initialized
INFO - 2018-03-24 00:03:39 --> Model Class Initialized
INFO - 2018-03-24 00:03:39 --> Controller Class Initialized
INFO - 2018-03-24 00:03:39 --> Model Class Initialized
INFO - 2018-03-24 00:03:39 --> Model Class Initialized
INFO - 2018-03-24 00:03:39 --> Model Class Initialized
INFO - 2018-03-24 00:03:39 --> Model Class Initialized
DEBUG - 2018-03-24 00:03:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 00:03:39 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-24 00:03:39 --> Final output sent to browser
DEBUG - 2018-03-24 00:03:39 --> Total execution time: 0.0928
INFO - 2018-03-24 00:03:39 --> Config Class Initialized
INFO - 2018-03-24 00:03:39 --> Hooks Class Initialized
INFO - 2018-03-24 00:03:39 --> Config Class Initialized
INFO - 2018-03-24 00:03:39 --> Config Class Initialized
INFO - 2018-03-24 00:03:39 --> Hooks Class Initialized
INFO - 2018-03-24 00:03:39 --> Hooks Class Initialized
INFO - 2018-03-24 00:03:39 --> Config Class Initialized
INFO - 2018-03-24 00:03:39 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:03:39 --> UTF-8 Support Enabled
DEBUG - 2018-03-24 00:03:39 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:03:39 --> Utf8 Class Initialized
DEBUG - 2018-03-24 00:03:39 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:03:39 --> Utf8 Class Initialized
INFO - 2018-03-24 00:03:39 --> Utf8 Class Initialized
INFO - 2018-03-24 00:03:39 --> URI Class Initialized
INFO - 2018-03-24 00:03:39 --> URI Class Initialized
INFO - 2018-03-24 00:03:39 --> URI Class Initialized
DEBUG - 2018-03-24 00:03:39 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:03:39 --> Utf8 Class Initialized
INFO - 2018-03-24 00:03:39 --> URI Class Initialized
INFO - 2018-03-24 00:03:39 --> Router Class Initialized
INFO - 2018-03-24 00:03:39 --> Router Class Initialized
INFO - 2018-03-24 00:03:39 --> Router Class Initialized
INFO - 2018-03-24 00:03:39 --> Output Class Initialized
INFO - 2018-03-24 00:03:39 --> Router Class Initialized
INFO - 2018-03-24 00:03:39 --> Output Class Initialized
INFO - 2018-03-24 00:03:39 --> Output Class Initialized
INFO - 2018-03-24 00:03:39 --> Security Class Initialized
INFO - 2018-03-24 00:03:39 --> Security Class Initialized
INFO - 2018-03-24 00:03:39 --> Security Class Initialized
INFO - 2018-03-24 00:03:39 --> Output Class Initialized
DEBUG - 2018-03-24 00:03:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-24 00:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:03:39 --> Input Class Initialized
DEBUG - 2018-03-24 00:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:03:39 --> Input Class Initialized
INFO - 2018-03-24 00:03:39 --> Security Class Initialized
INFO - 2018-03-24 00:03:39 --> Input Class Initialized
INFO - 2018-03-24 00:03:39 --> Language Class Initialized
INFO - 2018-03-24 00:03:39 --> Language Class Initialized
INFO - 2018-03-24 00:03:39 --> Language Class Initialized
DEBUG - 2018-03-24 00:03:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-03-24 00:03:39 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-24 00:03:39 --> Input Class Initialized
ERROR - 2018-03-24 00:03:39 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-24 00:03:39 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-24 00:03:39 --> Language Class Initialized
ERROR - 2018-03-24 00:03:39 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-24 00:03:39 --> Config Class Initialized
INFO - 2018-03-24 00:03:39 --> Hooks Class Initialized
INFO - 2018-03-24 00:03:39 --> Config Class Initialized
INFO - 2018-03-24 00:03:39 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:03:39 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:03:39 --> Utf8 Class Initialized
INFO - 2018-03-24 00:03:39 --> Config Class Initialized
INFO - 2018-03-24 00:03:39 --> Hooks Class Initialized
INFO - 2018-03-24 00:03:39 --> URI Class Initialized
DEBUG - 2018-03-24 00:03:39 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:03:39 --> Utf8 Class Initialized
INFO - 2018-03-24 00:03:39 --> URI Class Initialized
DEBUG - 2018-03-24 00:03:39 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:03:39 --> Utf8 Class Initialized
INFO - 2018-03-24 00:03:39 --> Router Class Initialized
INFO - 2018-03-24 00:03:39 --> URI Class Initialized
INFO - 2018-03-24 00:03:39 --> Router Class Initialized
INFO - 2018-03-24 00:03:39 --> Output Class Initialized
INFO - 2018-03-24 00:03:39 --> Router Class Initialized
INFO - 2018-03-24 00:03:39 --> Output Class Initialized
INFO - 2018-03-24 00:03:39 --> Security Class Initialized
INFO - 2018-03-24 00:03:39 --> Security Class Initialized
INFO - 2018-03-24 00:03:39 --> Output Class Initialized
DEBUG - 2018-03-24 00:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:03:39 --> Input Class Initialized
INFO - 2018-03-24 00:03:39 --> Language Class Initialized
DEBUG - 2018-03-24 00:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:03:39 --> Security Class Initialized
INFO - 2018-03-24 00:03:39 --> Input Class Initialized
ERROR - 2018-03-24 00:03:39 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-24 00:03:39 --> Language Class Initialized
DEBUG - 2018-03-24 00:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:03:39 --> Input Class Initialized
INFO - 2018-03-24 00:03:39 --> Language Class Initialized
ERROR - 2018-03-24 00:03:39 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-24 00:03:39 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-24 00:03:39 --> Config Class Initialized
INFO - 2018-03-24 00:03:39 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:03:39 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:03:39 --> Utf8 Class Initialized
INFO - 2018-03-24 00:03:39 --> URI Class Initialized
INFO - 2018-03-24 00:03:39 --> Router Class Initialized
INFO - 2018-03-24 00:03:39 --> Output Class Initialized
INFO - 2018-03-24 00:03:39 --> Security Class Initialized
DEBUG - 2018-03-24 00:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:03:39 --> Input Class Initialized
INFO - 2018-03-24 00:03:39 --> Language Class Initialized
INFO - 2018-03-24 00:03:39 --> Loader Class Initialized
INFO - 2018-03-24 00:03:39 --> Helper loaded: url_helper
INFO - 2018-03-24 00:03:39 --> Helper loaded: form_helper
INFO - 2018-03-24 00:03:39 --> Database Driver Class Initialized
DEBUG - 2018-03-24 00:03:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 00:03:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 00:03:39 --> Form Validation Class Initialized
INFO - 2018-03-24 00:03:39 --> Model Class Initialized
INFO - 2018-03-24 00:03:39 --> Controller Class Initialized
INFO - 2018-03-24 00:03:39 --> Model Class Initialized
INFO - 2018-03-24 00:03:39 --> Model Class Initialized
INFO - 2018-03-24 00:03:39 --> Model Class Initialized
INFO - 2018-03-24 00:03:39 --> Model Class Initialized
DEBUG - 2018-03-24 00:03:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 00:03:53 --> Config Class Initialized
INFO - 2018-03-24 00:03:53 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:03:53 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:03:53 --> Utf8 Class Initialized
INFO - 2018-03-24 00:03:53 --> URI Class Initialized
INFO - 2018-03-24 00:03:53 --> Router Class Initialized
INFO - 2018-03-24 00:03:53 --> Output Class Initialized
INFO - 2018-03-24 00:03:53 --> Security Class Initialized
DEBUG - 2018-03-24 00:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:03:53 --> Input Class Initialized
INFO - 2018-03-24 00:03:53 --> Language Class Initialized
INFO - 2018-03-24 00:03:53 --> Loader Class Initialized
INFO - 2018-03-24 00:03:53 --> Helper loaded: url_helper
INFO - 2018-03-24 00:03:53 --> Helper loaded: form_helper
INFO - 2018-03-24 00:03:53 --> Database Driver Class Initialized
DEBUG - 2018-03-24 00:03:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 00:03:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 00:03:53 --> Form Validation Class Initialized
INFO - 2018-03-24 00:03:53 --> Model Class Initialized
INFO - 2018-03-24 00:03:53 --> Controller Class Initialized
INFO - 2018-03-24 00:03:53 --> Model Class Initialized
INFO - 2018-03-24 00:03:53 --> Model Class Initialized
INFO - 2018-03-24 00:03:53 --> Model Class Initialized
INFO - 2018-03-24 00:03:53 --> Model Class Initialized
DEBUG - 2018-03-24 00:03:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 00:03:53 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-24 00:03:53 --> Final output sent to browser
DEBUG - 2018-03-24 00:03:53 --> Total execution time: 0.1309
INFO - 2018-03-24 00:03:53 --> Config Class Initialized
INFO - 2018-03-24 00:03:53 --> Hooks Class Initialized
INFO - 2018-03-24 00:03:53 --> Config Class Initialized
INFO - 2018-03-24 00:03:53 --> Hooks Class Initialized
INFO - 2018-03-24 00:03:53 --> Config Class Initialized
INFO - 2018-03-24 00:03:53 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:03:53 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:03:53 --> Utf8 Class Initialized
INFO - 2018-03-24 00:03:53 --> Config Class Initialized
INFO - 2018-03-24 00:03:53 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:03:53 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:03:53 --> Utf8 Class Initialized
DEBUG - 2018-03-24 00:03:53 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:03:53 --> URI Class Initialized
INFO - 2018-03-24 00:03:53 --> Utf8 Class Initialized
INFO - 2018-03-24 00:03:53 --> URI Class Initialized
INFO - 2018-03-24 00:03:53 --> URI Class Initialized
INFO - 2018-03-24 00:03:53 --> Router Class Initialized
DEBUG - 2018-03-24 00:03:53 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:03:53 --> Utf8 Class Initialized
INFO - 2018-03-24 00:03:53 --> Router Class Initialized
INFO - 2018-03-24 00:03:53 --> URI Class Initialized
INFO - 2018-03-24 00:03:53 --> Output Class Initialized
INFO - 2018-03-24 00:03:53 --> Router Class Initialized
INFO - 2018-03-24 00:03:53 --> Router Class Initialized
INFO - 2018-03-24 00:03:53 --> Output Class Initialized
INFO - 2018-03-24 00:03:53 --> Security Class Initialized
INFO - 2018-03-24 00:03:53 --> Output Class Initialized
INFO - 2018-03-24 00:03:53 --> Security Class Initialized
DEBUG - 2018-03-24 00:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:03:53 --> Input Class Initialized
INFO - 2018-03-24 00:03:53 --> Output Class Initialized
INFO - 2018-03-24 00:03:53 --> Security Class Initialized
DEBUG - 2018-03-24 00:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:03:53 --> Language Class Initialized
INFO - 2018-03-24 00:03:53 --> Input Class Initialized
INFO - 2018-03-24 00:03:53 --> Security Class Initialized
DEBUG - 2018-03-24 00:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:03:53 --> Input Class Initialized
INFO - 2018-03-24 00:03:53 --> Language Class Initialized
ERROR - 2018-03-24 00:03:53 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-24 00:03:53 --> Language Class Initialized
DEBUG - 2018-03-24 00:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:03:53 --> Input Class Initialized
ERROR - 2018-03-24 00:03:53 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-24 00:03:53 --> Language Class Initialized
ERROR - 2018-03-24 00:03:53 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-24 00:03:53 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-24 00:03:53 --> Config Class Initialized
INFO - 2018-03-24 00:03:53 --> Hooks Class Initialized
INFO - 2018-03-24 00:03:53 --> Config Class Initialized
INFO - 2018-03-24 00:03:53 --> Hooks Class Initialized
INFO - 2018-03-24 00:03:53 --> Config Class Initialized
INFO - 2018-03-24 00:03:53 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:03:53 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:03:53 --> Utf8 Class Initialized
INFO - 2018-03-24 00:03:53 --> URI Class Initialized
DEBUG - 2018-03-24 00:03:53 --> UTF-8 Support Enabled
DEBUG - 2018-03-24 00:03:53 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:03:53 --> Utf8 Class Initialized
INFO - 2018-03-24 00:03:53 --> Utf8 Class Initialized
INFO - 2018-03-24 00:03:53 --> Router Class Initialized
INFO - 2018-03-24 00:03:53 --> URI Class Initialized
INFO - 2018-03-24 00:03:53 --> URI Class Initialized
INFO - 2018-03-24 00:03:53 --> Router Class Initialized
INFO - 2018-03-24 00:03:53 --> Output Class Initialized
INFO - 2018-03-24 00:03:53 --> Router Class Initialized
INFO - 2018-03-24 00:03:53 --> Security Class Initialized
INFO - 2018-03-24 00:03:53 --> Output Class Initialized
INFO - 2018-03-24 00:03:53 --> Output Class Initialized
DEBUG - 2018-03-24 00:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:03:53 --> Input Class Initialized
INFO - 2018-03-24 00:03:53 --> Security Class Initialized
INFO - 2018-03-24 00:03:53 --> Security Class Initialized
INFO - 2018-03-24 00:03:53 --> Language Class Initialized
DEBUG - 2018-03-24 00:03:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-24 00:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:03:53 --> Input Class Initialized
INFO - 2018-03-24 00:03:53 --> Input Class Initialized
ERROR - 2018-03-24 00:03:53 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-24 00:03:53 --> Language Class Initialized
INFO - 2018-03-24 00:03:53 --> Language Class Initialized
ERROR - 2018-03-24 00:03:53 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-24 00:03:53 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-24 00:03:53 --> Config Class Initialized
INFO - 2018-03-24 00:03:53 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:03:53 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:03:53 --> Utf8 Class Initialized
INFO - 2018-03-24 00:03:53 --> URI Class Initialized
INFO - 2018-03-24 00:03:53 --> Router Class Initialized
INFO - 2018-03-24 00:03:53 --> Output Class Initialized
INFO - 2018-03-24 00:03:53 --> Security Class Initialized
DEBUG - 2018-03-24 00:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:03:53 --> Input Class Initialized
INFO - 2018-03-24 00:03:53 --> Language Class Initialized
INFO - 2018-03-24 00:03:53 --> Loader Class Initialized
INFO - 2018-03-24 00:03:53 --> Helper loaded: url_helper
INFO - 2018-03-24 00:03:53 --> Helper loaded: form_helper
INFO - 2018-03-24 00:03:53 --> Database Driver Class Initialized
DEBUG - 2018-03-24 00:03:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 00:03:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 00:03:53 --> Form Validation Class Initialized
INFO - 2018-03-24 00:03:53 --> Model Class Initialized
INFO - 2018-03-24 00:03:53 --> Controller Class Initialized
INFO - 2018-03-24 00:03:53 --> Model Class Initialized
INFO - 2018-03-24 00:03:53 --> Model Class Initialized
INFO - 2018-03-24 00:03:53 --> Model Class Initialized
INFO - 2018-03-24 00:03:53 --> Model Class Initialized
DEBUG - 2018-03-24 00:03:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 00:08:40 --> Config Class Initialized
INFO - 2018-03-24 00:08:40 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:08:40 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:08:40 --> Utf8 Class Initialized
INFO - 2018-03-24 00:08:40 --> URI Class Initialized
INFO - 2018-03-24 00:08:40 --> Router Class Initialized
INFO - 2018-03-24 00:08:40 --> Output Class Initialized
INFO - 2018-03-24 00:08:40 --> Security Class Initialized
DEBUG - 2018-03-24 00:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:08:40 --> Input Class Initialized
INFO - 2018-03-24 00:08:40 --> Language Class Initialized
INFO - 2018-03-24 00:08:40 --> Loader Class Initialized
INFO - 2018-03-24 00:08:40 --> Helper loaded: url_helper
INFO - 2018-03-24 00:08:40 --> Helper loaded: form_helper
INFO - 2018-03-24 00:08:40 --> Database Driver Class Initialized
DEBUG - 2018-03-24 00:08:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 00:08:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 00:08:40 --> Form Validation Class Initialized
INFO - 2018-03-24 00:08:40 --> Model Class Initialized
INFO - 2018-03-24 00:08:40 --> Controller Class Initialized
INFO - 2018-03-24 00:08:40 --> Model Class Initialized
INFO - 2018-03-24 00:08:40 --> Model Class Initialized
INFO - 2018-03-24 00:08:40 --> Model Class Initialized
INFO - 2018-03-24 00:08:40 --> Model Class Initialized
DEBUG - 2018-03-24 00:08:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 00:08:40 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-24 00:08:40 --> Final output sent to browser
DEBUG - 2018-03-24 00:08:40 --> Total execution time: 0.1240
INFO - 2018-03-24 00:08:41 --> Config Class Initialized
INFO - 2018-03-24 00:08:41 --> Hooks Class Initialized
INFO - 2018-03-24 00:08:41 --> Config Class Initialized
INFO - 2018-03-24 00:08:41 --> Hooks Class Initialized
INFO - 2018-03-24 00:08:41 --> Config Class Initialized
INFO - 2018-03-24 00:08:41 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:08:41 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:08:41 --> Utf8 Class Initialized
INFO - 2018-03-24 00:08:41 --> Config Class Initialized
DEBUG - 2018-03-24 00:08:41 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:08:41 --> Hooks Class Initialized
INFO - 2018-03-24 00:08:41 --> Utf8 Class Initialized
DEBUG - 2018-03-24 00:08:41 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:08:41 --> URI Class Initialized
INFO - 2018-03-24 00:08:41 --> Utf8 Class Initialized
INFO - 2018-03-24 00:08:41 --> URI Class Initialized
INFO - 2018-03-24 00:08:41 --> URI Class Initialized
INFO - 2018-03-24 00:08:41 --> Router Class Initialized
DEBUG - 2018-03-24 00:08:41 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:08:41 --> Router Class Initialized
INFO - 2018-03-24 00:08:41 --> Utf8 Class Initialized
INFO - 2018-03-24 00:08:41 --> Router Class Initialized
INFO - 2018-03-24 00:08:41 --> Output Class Initialized
INFO - 2018-03-24 00:08:41 --> URI Class Initialized
INFO - 2018-03-24 00:08:41 --> Output Class Initialized
INFO - 2018-03-24 00:08:41 --> Security Class Initialized
INFO - 2018-03-24 00:08:41 --> Output Class Initialized
INFO - 2018-03-24 00:08:41 --> Security Class Initialized
INFO - 2018-03-24 00:08:41 --> Router Class Initialized
DEBUG - 2018-03-24 00:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:08:41 --> Input Class Initialized
INFO - 2018-03-24 00:08:41 --> Security Class Initialized
DEBUG - 2018-03-24 00:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:08:41 --> Input Class Initialized
INFO - 2018-03-24 00:08:41 --> Language Class Initialized
INFO - 2018-03-24 00:08:41 --> Output Class Initialized
DEBUG - 2018-03-24 00:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:08:41 --> Language Class Initialized
INFO - 2018-03-24 00:08:41 --> Input Class Initialized
INFO - 2018-03-24 00:08:41 --> Security Class Initialized
ERROR - 2018-03-24 00:08:41 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-24 00:08:41 --> Language Class Initialized
ERROR - 2018-03-24 00:08:41 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-24 00:08:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-03-24 00:08:41 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-24 00:08:41 --> Input Class Initialized
INFO - 2018-03-24 00:08:41 --> Language Class Initialized
ERROR - 2018-03-24 00:08:41 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-24 00:08:41 --> Config Class Initialized
INFO - 2018-03-24 00:08:41 --> Hooks Class Initialized
INFO - 2018-03-24 00:08:41 --> Config Class Initialized
INFO - 2018-03-24 00:08:41 --> Config Class Initialized
INFO - 2018-03-24 00:08:41 --> Hooks Class Initialized
INFO - 2018-03-24 00:08:41 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:08:41 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:08:41 --> Utf8 Class Initialized
INFO - 2018-03-24 00:08:41 --> URI Class Initialized
DEBUG - 2018-03-24 00:08:41 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:08:41 --> Utf8 Class Initialized
DEBUG - 2018-03-24 00:08:41 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:08:41 --> Utf8 Class Initialized
INFO - 2018-03-24 00:08:41 --> URI Class Initialized
INFO - 2018-03-24 00:08:41 --> Router Class Initialized
INFO - 2018-03-24 00:08:41 --> URI Class Initialized
INFO - 2018-03-24 00:08:41 --> Router Class Initialized
INFO - 2018-03-24 00:08:41 --> Output Class Initialized
INFO - 2018-03-24 00:08:41 --> Router Class Initialized
INFO - 2018-03-24 00:08:41 --> Security Class Initialized
INFO - 2018-03-24 00:08:41 --> Output Class Initialized
INFO - 2018-03-24 00:08:41 --> Output Class Initialized
DEBUG - 2018-03-24 00:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:08:41 --> Security Class Initialized
INFO - 2018-03-24 00:08:41 --> Input Class Initialized
INFO - 2018-03-24 00:08:41 --> Security Class Initialized
INFO - 2018-03-24 00:08:41 --> Language Class Initialized
DEBUG - 2018-03-24 00:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:08:41 --> Input Class Initialized
DEBUG - 2018-03-24 00:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:08:41 --> Input Class Initialized
INFO - 2018-03-24 00:08:41 --> Language Class Initialized
ERROR - 2018-03-24 00:08:41 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-24 00:08:41 --> Language Class Initialized
ERROR - 2018-03-24 00:08:41 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-24 00:08:41 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-24 00:08:41 --> Config Class Initialized
INFO - 2018-03-24 00:08:41 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:08:41 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:08:41 --> Utf8 Class Initialized
INFO - 2018-03-24 00:08:41 --> URI Class Initialized
INFO - 2018-03-24 00:08:41 --> Router Class Initialized
INFO - 2018-03-24 00:08:41 --> Output Class Initialized
INFO - 2018-03-24 00:08:41 --> Security Class Initialized
DEBUG - 2018-03-24 00:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:08:41 --> Input Class Initialized
INFO - 2018-03-24 00:08:41 --> Language Class Initialized
INFO - 2018-03-24 00:08:41 --> Loader Class Initialized
INFO - 2018-03-24 00:08:41 --> Helper loaded: url_helper
INFO - 2018-03-24 00:08:41 --> Helper loaded: form_helper
INFO - 2018-03-24 00:08:41 --> Database Driver Class Initialized
DEBUG - 2018-03-24 00:08:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 00:08:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 00:08:41 --> Form Validation Class Initialized
INFO - 2018-03-24 00:08:41 --> Model Class Initialized
INFO - 2018-03-24 00:08:41 --> Controller Class Initialized
INFO - 2018-03-24 00:08:41 --> Model Class Initialized
INFO - 2018-03-24 00:08:41 --> Model Class Initialized
INFO - 2018-03-24 00:08:41 --> Model Class Initialized
INFO - 2018-03-24 00:08:41 --> Model Class Initialized
DEBUG - 2018-03-24 00:08:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 00:08:56 --> Config Class Initialized
INFO - 2018-03-24 00:08:56 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:08:56 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:08:56 --> Utf8 Class Initialized
INFO - 2018-03-24 00:08:56 --> URI Class Initialized
INFO - 2018-03-24 00:08:56 --> Router Class Initialized
INFO - 2018-03-24 00:08:56 --> Output Class Initialized
INFO - 2018-03-24 00:08:56 --> Security Class Initialized
DEBUG - 2018-03-24 00:08:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:08:56 --> Input Class Initialized
INFO - 2018-03-24 00:08:56 --> Language Class Initialized
INFO - 2018-03-24 00:08:56 --> Loader Class Initialized
INFO - 2018-03-24 00:08:56 --> Helper loaded: url_helper
INFO - 2018-03-24 00:08:56 --> Helper loaded: form_helper
INFO - 2018-03-24 00:08:56 --> Database Driver Class Initialized
DEBUG - 2018-03-24 00:08:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 00:08:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 00:08:56 --> Form Validation Class Initialized
INFO - 2018-03-24 00:08:56 --> Model Class Initialized
INFO - 2018-03-24 00:08:56 --> Controller Class Initialized
INFO - 2018-03-24 00:08:56 --> Model Class Initialized
INFO - 2018-03-24 00:08:56 --> Model Class Initialized
INFO - 2018-03-24 00:08:56 --> Model Class Initialized
INFO - 2018-03-24 00:08:56 --> Model Class Initialized
DEBUG - 2018-03-24 00:08:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 00:08:56 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-24 00:08:56 --> Final output sent to browser
DEBUG - 2018-03-24 00:08:56 --> Total execution time: 0.1296
INFO - 2018-03-24 00:08:56 --> Config Class Initialized
INFO - 2018-03-24 00:08:56 --> Hooks Class Initialized
INFO - 2018-03-24 00:08:56 --> Config Class Initialized
INFO - 2018-03-24 00:08:56 --> Hooks Class Initialized
INFO - 2018-03-24 00:08:56 --> Config Class Initialized
INFO - 2018-03-24 00:08:56 --> Hooks Class Initialized
INFO - 2018-03-24 00:08:56 --> Config Class Initialized
INFO - 2018-03-24 00:08:56 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:08:56 --> UTF-8 Support Enabled
DEBUG - 2018-03-24 00:08:56 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:08:56 --> Utf8 Class Initialized
INFO - 2018-03-24 00:08:56 --> Utf8 Class Initialized
INFO - 2018-03-24 00:08:56 --> URI Class Initialized
DEBUG - 2018-03-24 00:08:56 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:08:56 --> URI Class Initialized
INFO - 2018-03-24 00:08:56 --> Utf8 Class Initialized
DEBUG - 2018-03-24 00:08:56 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:08:56 --> URI Class Initialized
INFO - 2018-03-24 00:08:56 --> Utf8 Class Initialized
INFO - 2018-03-24 00:08:56 --> Router Class Initialized
INFO - 2018-03-24 00:08:56 --> Router Class Initialized
INFO - 2018-03-24 00:08:56 --> URI Class Initialized
INFO - 2018-03-24 00:08:56 --> Router Class Initialized
INFO - 2018-03-24 00:08:56 --> Output Class Initialized
INFO - 2018-03-24 00:08:56 --> Router Class Initialized
INFO - 2018-03-24 00:08:56 --> Output Class Initialized
INFO - 2018-03-24 00:08:56 --> Output Class Initialized
INFO - 2018-03-24 00:08:56 --> Security Class Initialized
INFO - 2018-03-24 00:08:56 --> Security Class Initialized
INFO - 2018-03-24 00:08:56 --> Output Class Initialized
INFO - 2018-03-24 00:08:56 --> Security Class Initialized
DEBUG - 2018-03-24 00:08:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:08:56 --> Input Class Initialized
DEBUG - 2018-03-24 00:08:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:08:56 --> Input Class Initialized
DEBUG - 2018-03-24 00:08:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:08:56 --> Language Class Initialized
INFO - 2018-03-24 00:08:56 --> Input Class Initialized
INFO - 2018-03-24 00:08:56 --> Security Class Initialized
INFO - 2018-03-24 00:08:56 --> Language Class Initialized
INFO - 2018-03-24 00:08:56 --> Language Class Initialized
ERROR - 2018-03-24 00:08:56 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-24 00:08:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:08:56 --> Input Class Initialized
ERROR - 2018-03-24 00:08:56 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-24 00:08:56 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-24 00:08:56 --> Language Class Initialized
ERROR - 2018-03-24 00:08:56 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-24 00:08:56 --> Config Class Initialized
INFO - 2018-03-24 00:08:56 --> Hooks Class Initialized
INFO - 2018-03-24 00:08:56 --> Config Class Initialized
INFO - 2018-03-24 00:08:56 --> Hooks Class Initialized
INFO - 2018-03-24 00:08:56 --> Config Class Initialized
INFO - 2018-03-24 00:08:56 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:08:56 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:08:56 --> Utf8 Class Initialized
DEBUG - 2018-03-24 00:08:56 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:08:56 --> Utf8 Class Initialized
DEBUG - 2018-03-24 00:08:56 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:08:56 --> URI Class Initialized
INFO - 2018-03-24 00:08:56 --> Utf8 Class Initialized
INFO - 2018-03-24 00:08:56 --> URI Class Initialized
INFO - 2018-03-24 00:08:56 --> URI Class Initialized
INFO - 2018-03-24 00:08:56 --> Router Class Initialized
INFO - 2018-03-24 00:08:56 --> Router Class Initialized
INFO - 2018-03-24 00:08:56 --> Router Class Initialized
INFO - 2018-03-24 00:08:56 --> Output Class Initialized
INFO - 2018-03-24 00:08:56 --> Output Class Initialized
INFO - 2018-03-24 00:08:56 --> Output Class Initialized
INFO - 2018-03-24 00:08:56 --> Security Class Initialized
INFO - 2018-03-24 00:08:56 --> Security Class Initialized
INFO - 2018-03-24 00:08:56 --> Security Class Initialized
DEBUG - 2018-03-24 00:08:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:08:56 --> Input Class Initialized
DEBUG - 2018-03-24 00:08:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-24 00:08:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:08:56 --> Input Class Initialized
INFO - 2018-03-24 00:08:56 --> Language Class Initialized
INFO - 2018-03-24 00:08:56 --> Input Class Initialized
INFO - 2018-03-24 00:08:56 --> Language Class Initialized
INFO - 2018-03-24 00:08:56 --> Language Class Initialized
ERROR - 2018-03-24 00:08:56 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-24 00:08:56 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-24 00:08:56 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-24 00:08:56 --> Config Class Initialized
INFO - 2018-03-24 00:08:56 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:08:56 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:08:56 --> Utf8 Class Initialized
INFO - 2018-03-24 00:08:56 --> URI Class Initialized
INFO - 2018-03-24 00:08:56 --> Router Class Initialized
INFO - 2018-03-24 00:08:56 --> Output Class Initialized
INFO - 2018-03-24 00:08:56 --> Security Class Initialized
DEBUG - 2018-03-24 00:08:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:08:56 --> Input Class Initialized
INFO - 2018-03-24 00:08:56 --> Language Class Initialized
INFO - 2018-03-24 00:08:56 --> Loader Class Initialized
INFO - 2018-03-24 00:08:56 --> Helper loaded: url_helper
INFO - 2018-03-24 00:08:56 --> Helper loaded: form_helper
INFO - 2018-03-24 00:08:56 --> Database Driver Class Initialized
DEBUG - 2018-03-24 00:08:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 00:08:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 00:08:56 --> Form Validation Class Initialized
INFO - 2018-03-24 00:08:56 --> Model Class Initialized
INFO - 2018-03-24 00:08:56 --> Controller Class Initialized
INFO - 2018-03-24 00:08:56 --> Model Class Initialized
INFO - 2018-03-24 00:08:56 --> Model Class Initialized
INFO - 2018-03-24 00:08:56 --> Model Class Initialized
INFO - 2018-03-24 00:08:56 --> Model Class Initialized
DEBUG - 2018-03-24 00:08:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 00:09:59 --> Config Class Initialized
INFO - 2018-03-24 00:09:59 --> Hooks Class Initialized
INFO - 2018-03-24 00:09:59 --> Config Class Initialized
INFO - 2018-03-24 00:09:59 --> Config Class Initialized
INFO - 2018-03-24 00:09:59 --> Hooks Class Initialized
INFO - 2018-03-24 00:09:59 --> Hooks Class Initialized
INFO - 2018-03-24 00:09:59 --> Config Class Initialized
INFO - 2018-03-24 00:09:59 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:09:59 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:09:59 --> Utf8 Class Initialized
DEBUG - 2018-03-24 00:09:59 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:09:59 --> Utf8 Class Initialized
DEBUG - 2018-03-24 00:09:59 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:09:59 --> URI Class Initialized
INFO - 2018-03-24 00:09:59 --> Utf8 Class Initialized
INFO - 2018-03-24 00:09:59 --> URI Class Initialized
INFO - 2018-03-24 00:09:59 --> URI Class Initialized
DEBUG - 2018-03-24 00:09:59 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:09:59 --> Utf8 Class Initialized
INFO - 2018-03-24 00:09:59 --> Router Class Initialized
INFO - 2018-03-24 00:09:59 --> Router Class Initialized
INFO - 2018-03-24 00:09:59 --> URI Class Initialized
INFO - 2018-03-24 00:09:59 --> Router Class Initialized
INFO - 2018-03-24 00:09:59 --> Output Class Initialized
INFO - 2018-03-24 00:09:59 --> Output Class Initialized
INFO - 2018-03-24 00:09:59 --> Router Class Initialized
INFO - 2018-03-24 00:09:59 --> Output Class Initialized
INFO - 2018-03-24 00:09:59 --> Security Class Initialized
INFO - 2018-03-24 00:09:59 --> Security Class Initialized
DEBUG - 2018-03-24 00:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:09:59 --> Output Class Initialized
INFO - 2018-03-24 00:09:59 --> Input Class Initialized
INFO - 2018-03-24 00:09:59 --> Security Class Initialized
DEBUG - 2018-03-24 00:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:09:59 --> Input Class Initialized
INFO - 2018-03-24 00:09:59 --> Language Class Initialized
INFO - 2018-03-24 00:09:59 --> Security Class Initialized
DEBUG - 2018-03-24 00:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:09:59 --> Language Class Initialized
INFO - 2018-03-24 00:09:59 --> Input Class Initialized
ERROR - 2018-03-24 00:09:59 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-24 00:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:09:59 --> Language Class Initialized
INFO - 2018-03-24 00:09:59 --> Input Class Initialized
ERROR - 2018-03-24 00:09:59 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-24 00:09:59 --> Language Class Initialized
ERROR - 2018-03-24 00:09:59 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-24 00:09:59 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-24 00:09:59 --> Config Class Initialized
INFO - 2018-03-24 00:09:59 --> Hooks Class Initialized
INFO - 2018-03-24 00:09:59 --> Config Class Initialized
INFO - 2018-03-24 00:09:59 --> Hooks Class Initialized
INFO - 2018-03-24 00:09:59 --> Config Class Initialized
INFO - 2018-03-24 00:09:59 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:09:59 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:09:59 --> Utf8 Class Initialized
INFO - 2018-03-24 00:09:59 --> URI Class Initialized
DEBUG - 2018-03-24 00:09:59 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:09:59 --> Utf8 Class Initialized
DEBUG - 2018-03-24 00:09:59 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:09:59 --> Utf8 Class Initialized
INFO - 2018-03-24 00:09:59 --> Router Class Initialized
INFO - 2018-03-24 00:09:59 --> URI Class Initialized
INFO - 2018-03-24 00:09:59 --> URI Class Initialized
INFO - 2018-03-24 00:10:00 --> Output Class Initialized
INFO - 2018-03-24 00:10:00 --> Router Class Initialized
INFO - 2018-03-24 00:10:00 --> Router Class Initialized
INFO - 2018-03-24 00:10:00 --> Security Class Initialized
INFO - 2018-03-24 00:10:00 --> Output Class Initialized
DEBUG - 2018-03-24 00:10:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:10:00 --> Output Class Initialized
INFO - 2018-03-24 00:10:00 --> Input Class Initialized
INFO - 2018-03-24 00:10:00 --> Security Class Initialized
INFO - 2018-03-24 00:10:00 --> Language Class Initialized
INFO - 2018-03-24 00:10:00 --> Security Class Initialized
DEBUG - 2018-03-24 00:10:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-03-24 00:10:00 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-24 00:10:00 --> Input Class Initialized
DEBUG - 2018-03-24 00:10:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:10:00 --> Input Class Initialized
INFO - 2018-03-24 00:10:00 --> Language Class Initialized
INFO - 2018-03-24 00:10:00 --> Language Class Initialized
ERROR - 2018-03-24 00:10:00 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-24 00:10:00 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-24 00:10:03 --> Config Class Initialized
INFO - 2018-03-24 00:10:03 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:10:03 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:10:03 --> Utf8 Class Initialized
INFO - 2018-03-24 00:10:03 --> URI Class Initialized
INFO - 2018-03-24 00:10:03 --> Router Class Initialized
INFO - 2018-03-24 00:10:03 --> Output Class Initialized
INFO - 2018-03-24 00:10:03 --> Security Class Initialized
DEBUG - 2018-03-24 00:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:10:03 --> Input Class Initialized
INFO - 2018-03-24 00:10:03 --> Language Class Initialized
INFO - 2018-03-24 00:10:03 --> Loader Class Initialized
INFO - 2018-03-24 00:10:03 --> Helper loaded: url_helper
INFO - 2018-03-24 00:10:03 --> Helper loaded: form_helper
INFO - 2018-03-24 00:10:03 --> Database Driver Class Initialized
DEBUG - 2018-03-24 00:10:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 00:10:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 00:10:03 --> Form Validation Class Initialized
INFO - 2018-03-24 00:10:03 --> Model Class Initialized
INFO - 2018-03-24 00:10:03 --> Controller Class Initialized
INFO - 2018-03-24 00:10:03 --> Model Class Initialized
INFO - 2018-03-24 00:10:03 --> Model Class Initialized
INFO - 2018-03-24 00:10:03 --> Model Class Initialized
INFO - 2018-03-24 00:10:03 --> Model Class Initialized
DEBUG - 2018-03-24 00:10:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 00:10:03 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-24 00:10:03 --> Final output sent to browser
DEBUG - 2018-03-24 00:10:03 --> Total execution time: 0.0978
INFO - 2018-03-24 00:10:03 --> Config Class Initialized
INFO - 2018-03-24 00:10:03 --> Hooks Class Initialized
INFO - 2018-03-24 00:10:03 --> Config Class Initialized
INFO - 2018-03-24 00:10:03 --> Config Class Initialized
INFO - 2018-03-24 00:10:03 --> Hooks Class Initialized
INFO - 2018-03-24 00:10:03 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:10:03 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:10:03 --> Utf8 Class Initialized
INFO - 2018-03-24 00:10:03 --> Config Class Initialized
INFO - 2018-03-24 00:10:03 --> Hooks Class Initialized
INFO - 2018-03-24 00:10:03 --> URI Class Initialized
DEBUG - 2018-03-24 00:10:03 --> UTF-8 Support Enabled
DEBUG - 2018-03-24 00:10:03 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:10:03 --> Utf8 Class Initialized
INFO - 2018-03-24 00:10:03 --> Utf8 Class Initialized
DEBUG - 2018-03-24 00:10:03 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:10:03 --> URI Class Initialized
INFO - 2018-03-24 00:10:03 --> URI Class Initialized
INFO - 2018-03-24 00:10:03 --> Router Class Initialized
INFO - 2018-03-24 00:10:03 --> Utf8 Class Initialized
INFO - 2018-03-24 00:10:03 --> URI Class Initialized
INFO - 2018-03-24 00:10:03 --> Router Class Initialized
INFO - 2018-03-24 00:10:03 --> Router Class Initialized
INFO - 2018-03-24 00:10:03 --> Output Class Initialized
INFO - 2018-03-24 00:10:03 --> Security Class Initialized
INFO - 2018-03-24 00:10:03 --> Router Class Initialized
INFO - 2018-03-24 00:10:03 --> Output Class Initialized
INFO - 2018-03-24 00:10:03 --> Output Class Initialized
DEBUG - 2018-03-24 00:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:10:03 --> Input Class Initialized
INFO - 2018-03-24 00:10:03 --> Security Class Initialized
INFO - 2018-03-24 00:10:03 --> Language Class Initialized
INFO - 2018-03-24 00:10:03 --> Security Class Initialized
INFO - 2018-03-24 00:10:03 --> Output Class Initialized
DEBUG - 2018-03-24 00:10:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-03-24 00:10:03 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-24 00:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:10:03 --> Input Class Initialized
INFO - 2018-03-24 00:10:03 --> Input Class Initialized
INFO - 2018-03-24 00:10:03 --> Security Class Initialized
INFO - 2018-03-24 00:10:03 --> Language Class Initialized
INFO - 2018-03-24 00:10:03 --> Language Class Initialized
DEBUG - 2018-03-24 00:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:10:03 --> Input Class Initialized
ERROR - 2018-03-24 00:10:03 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-24 00:10:03 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-24 00:10:03 --> Language Class Initialized
ERROR - 2018-03-24 00:10:03 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-24 00:10:03 --> Config Class Initialized
INFO - 2018-03-24 00:10:03 --> Hooks Class Initialized
INFO - 2018-03-24 00:10:03 --> Config Class Initialized
INFO - 2018-03-24 00:10:03 --> Hooks Class Initialized
INFO - 2018-03-24 00:10:03 --> Config Class Initialized
INFO - 2018-03-24 00:10:03 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:10:03 --> UTF-8 Support Enabled
DEBUG - 2018-03-24 00:10:03 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:10:03 --> Utf8 Class Initialized
INFO - 2018-03-24 00:10:03 --> Utf8 Class Initialized
DEBUG - 2018-03-24 00:10:03 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:10:03 --> Utf8 Class Initialized
INFO - 2018-03-24 00:10:03 --> URI Class Initialized
INFO - 2018-03-24 00:10:03 --> URI Class Initialized
INFO - 2018-03-24 00:10:03 --> URI Class Initialized
INFO - 2018-03-24 00:10:03 --> Router Class Initialized
INFO - 2018-03-24 00:10:03 --> Router Class Initialized
INFO - 2018-03-24 00:10:03 --> Router Class Initialized
INFO - 2018-03-24 00:10:03 --> Output Class Initialized
INFO - 2018-03-24 00:10:03 --> Output Class Initialized
INFO - 2018-03-24 00:10:03 --> Output Class Initialized
INFO - 2018-03-24 00:10:03 --> Security Class Initialized
INFO - 2018-03-24 00:10:03 --> Security Class Initialized
INFO - 2018-03-24 00:10:03 --> Security Class Initialized
DEBUG - 2018-03-24 00:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:10:03 --> Input Class Initialized
DEBUG - 2018-03-24 00:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:10:03 --> Input Class Initialized
DEBUG - 2018-03-24 00:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:10:03 --> Language Class Initialized
INFO - 2018-03-24 00:10:03 --> Input Class Initialized
INFO - 2018-03-24 00:10:03 --> Language Class Initialized
INFO - 2018-03-24 00:10:03 --> Language Class Initialized
ERROR - 2018-03-24 00:10:03 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-24 00:10:03 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-24 00:10:03 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-24 00:10:03 --> Config Class Initialized
INFO - 2018-03-24 00:10:03 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:10:03 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:10:03 --> Utf8 Class Initialized
INFO - 2018-03-24 00:10:03 --> URI Class Initialized
INFO - 2018-03-24 00:10:03 --> Router Class Initialized
INFO - 2018-03-24 00:10:03 --> Output Class Initialized
INFO - 2018-03-24 00:10:03 --> Security Class Initialized
DEBUG - 2018-03-24 00:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:10:03 --> Input Class Initialized
INFO - 2018-03-24 00:10:03 --> Language Class Initialized
INFO - 2018-03-24 00:10:03 --> Loader Class Initialized
INFO - 2018-03-24 00:10:03 --> Helper loaded: url_helper
INFO - 2018-03-24 00:10:03 --> Helper loaded: form_helper
INFO - 2018-03-24 00:10:03 --> Database Driver Class Initialized
DEBUG - 2018-03-24 00:10:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 00:10:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 00:10:03 --> Form Validation Class Initialized
INFO - 2018-03-24 00:10:03 --> Model Class Initialized
INFO - 2018-03-24 00:10:03 --> Controller Class Initialized
INFO - 2018-03-24 00:10:03 --> Model Class Initialized
INFO - 2018-03-24 00:10:03 --> Model Class Initialized
INFO - 2018-03-24 00:10:03 --> Model Class Initialized
INFO - 2018-03-24 00:10:03 --> Model Class Initialized
DEBUG - 2018-03-24 00:10:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 00:10:04 --> Config Class Initialized
INFO - 2018-03-24 00:10:04 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:10:04 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:10:04 --> Utf8 Class Initialized
INFO - 2018-03-24 00:10:04 --> URI Class Initialized
INFO - 2018-03-24 00:10:04 --> Router Class Initialized
INFO - 2018-03-24 00:10:04 --> Output Class Initialized
INFO - 2018-03-24 00:10:04 --> Security Class Initialized
DEBUG - 2018-03-24 00:10:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:10:04 --> Input Class Initialized
INFO - 2018-03-24 00:10:04 --> Language Class Initialized
INFO - 2018-03-24 00:10:04 --> Loader Class Initialized
INFO - 2018-03-24 00:10:04 --> Helper loaded: url_helper
INFO - 2018-03-24 00:10:04 --> Helper loaded: form_helper
INFO - 2018-03-24 00:10:04 --> Database Driver Class Initialized
DEBUG - 2018-03-24 00:10:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 00:10:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 00:10:04 --> Form Validation Class Initialized
INFO - 2018-03-24 00:10:04 --> Model Class Initialized
INFO - 2018-03-24 00:10:04 --> Controller Class Initialized
INFO - 2018-03-24 00:10:04 --> Model Class Initialized
INFO - 2018-03-24 00:10:04 --> Model Class Initialized
INFO - 2018-03-24 00:10:04 --> Model Class Initialized
INFO - 2018-03-24 00:10:04 --> Model Class Initialized
DEBUG - 2018-03-24 00:10:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 00:10:04 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-24 00:10:04 --> Final output sent to browser
DEBUG - 2018-03-24 00:10:04 --> Total execution time: 0.1063
INFO - 2018-03-24 00:10:04 --> Config Class Initialized
INFO - 2018-03-24 00:10:04 --> Hooks Class Initialized
INFO - 2018-03-24 00:10:04 --> Config Class Initialized
INFO - 2018-03-24 00:10:04 --> Config Class Initialized
INFO - 2018-03-24 00:10:04 --> Hooks Class Initialized
INFO - 2018-03-24 00:10:04 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:10:04 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:10:04 --> Utf8 Class Initialized
DEBUG - 2018-03-24 00:10:04 --> UTF-8 Support Enabled
DEBUG - 2018-03-24 00:10:04 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:10:04 --> Utf8 Class Initialized
INFO - 2018-03-24 00:10:04 --> Utf8 Class Initialized
INFO - 2018-03-24 00:10:04 --> URI Class Initialized
INFO - 2018-03-24 00:10:04 --> URI Class Initialized
INFO - 2018-03-24 00:10:04 --> URI Class Initialized
INFO - 2018-03-24 00:10:04 --> Router Class Initialized
INFO - 2018-03-24 00:10:04 --> Router Class Initialized
INFO - 2018-03-24 00:10:04 --> Router Class Initialized
INFO - 2018-03-24 00:10:04 --> Output Class Initialized
INFO - 2018-03-24 00:10:04 --> Output Class Initialized
INFO - 2018-03-24 00:10:04 --> Output Class Initialized
INFO - 2018-03-24 00:10:04 --> Security Class Initialized
INFO - 2018-03-24 00:10:04 --> Security Class Initialized
INFO - 2018-03-24 00:10:04 --> Security Class Initialized
DEBUG - 2018-03-24 00:10:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:10:04 --> Input Class Initialized
DEBUG - 2018-03-24 00:10:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-24 00:10:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:10:04 --> Input Class Initialized
INFO - 2018-03-24 00:10:04 --> Input Class Initialized
INFO - 2018-03-24 00:10:04 --> Language Class Initialized
INFO - 2018-03-24 00:10:04 --> Language Class Initialized
INFO - 2018-03-24 00:10:04 --> Language Class Initialized
ERROR - 2018-03-24 00:10:04 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-24 00:10:04 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-24 00:10:04 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-24 00:10:04 --> Config Class Initialized
INFO - 2018-03-24 00:10:04 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:10:04 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:10:04 --> Utf8 Class Initialized
INFO - 2018-03-24 00:10:04 --> URI Class Initialized
INFO - 2018-03-24 00:10:04 --> Router Class Initialized
INFO - 2018-03-24 00:10:04 --> Output Class Initialized
INFO - 2018-03-24 00:10:04 --> Security Class Initialized
DEBUG - 2018-03-24 00:10:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:10:04 --> Input Class Initialized
INFO - 2018-03-24 00:10:04 --> Language Class Initialized
ERROR - 2018-03-24 00:10:04 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-24 00:10:04 --> Config Class Initialized
INFO - 2018-03-24 00:10:04 --> Hooks Class Initialized
INFO - 2018-03-24 00:10:04 --> Config Class Initialized
INFO - 2018-03-24 00:10:04 --> Config Class Initialized
INFO - 2018-03-24 00:10:04 --> Hooks Class Initialized
INFO - 2018-03-24 00:10:04 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:10:04 --> UTF-8 Support Enabled
DEBUG - 2018-03-24 00:10:04 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:10:04 --> Utf8 Class Initialized
DEBUG - 2018-03-24 00:10:04 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:10:04 --> Utf8 Class Initialized
INFO - 2018-03-24 00:10:04 --> Utf8 Class Initialized
INFO - 2018-03-24 00:10:04 --> URI Class Initialized
INFO - 2018-03-24 00:10:04 --> URI Class Initialized
INFO - 2018-03-24 00:10:04 --> URI Class Initialized
INFO - 2018-03-24 00:10:04 --> Router Class Initialized
INFO - 2018-03-24 00:10:04 --> Router Class Initialized
INFO - 2018-03-24 00:10:04 --> Router Class Initialized
INFO - 2018-03-24 00:10:04 --> Output Class Initialized
INFO - 2018-03-24 00:10:04 --> Output Class Initialized
INFO - 2018-03-24 00:10:04 --> Output Class Initialized
INFO - 2018-03-24 00:10:04 --> Security Class Initialized
INFO - 2018-03-24 00:10:04 --> Security Class Initialized
INFO - 2018-03-24 00:10:04 --> Security Class Initialized
DEBUG - 2018-03-24 00:10:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-24 00:10:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:10:04 --> Input Class Initialized
DEBUG - 2018-03-24 00:10:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:10:04 --> Input Class Initialized
INFO - 2018-03-24 00:10:04 --> Input Class Initialized
INFO - 2018-03-24 00:10:04 --> Language Class Initialized
INFO - 2018-03-24 00:10:04 --> Language Class Initialized
INFO - 2018-03-24 00:10:04 --> Language Class Initialized
ERROR - 2018-03-24 00:10:04 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-24 00:10:04 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-24 00:10:04 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-24 00:10:04 --> Config Class Initialized
INFO - 2018-03-24 00:10:04 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:10:04 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:10:04 --> Utf8 Class Initialized
INFO - 2018-03-24 00:10:04 --> URI Class Initialized
INFO - 2018-03-24 00:10:05 --> Router Class Initialized
INFO - 2018-03-24 00:10:05 --> Output Class Initialized
INFO - 2018-03-24 00:10:05 --> Security Class Initialized
DEBUG - 2018-03-24 00:10:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:10:05 --> Input Class Initialized
INFO - 2018-03-24 00:10:05 --> Language Class Initialized
INFO - 2018-03-24 00:10:05 --> Loader Class Initialized
INFO - 2018-03-24 00:10:05 --> Helper loaded: url_helper
INFO - 2018-03-24 00:10:05 --> Helper loaded: form_helper
INFO - 2018-03-24 00:10:05 --> Database Driver Class Initialized
DEBUG - 2018-03-24 00:10:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 00:10:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 00:10:05 --> Form Validation Class Initialized
INFO - 2018-03-24 00:10:05 --> Model Class Initialized
INFO - 2018-03-24 00:10:05 --> Controller Class Initialized
INFO - 2018-03-24 00:10:05 --> Model Class Initialized
INFO - 2018-03-24 00:10:05 --> Model Class Initialized
INFO - 2018-03-24 00:10:05 --> Model Class Initialized
INFO - 2018-03-24 00:10:05 --> Model Class Initialized
DEBUG - 2018-03-24 00:10:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 00:11:32 --> Config Class Initialized
INFO - 2018-03-24 00:11:32 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:11:32 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:11:32 --> Utf8 Class Initialized
INFO - 2018-03-24 00:11:32 --> URI Class Initialized
INFO - 2018-03-24 00:11:32 --> Router Class Initialized
INFO - 2018-03-24 00:11:32 --> Output Class Initialized
INFO - 2018-03-24 00:11:32 --> Security Class Initialized
DEBUG - 2018-03-24 00:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:11:32 --> Input Class Initialized
INFO - 2018-03-24 00:11:32 --> Language Class Initialized
INFO - 2018-03-24 00:11:32 --> Loader Class Initialized
INFO - 2018-03-24 00:11:32 --> Helper loaded: url_helper
INFO - 2018-03-24 00:11:32 --> Helper loaded: form_helper
INFO - 2018-03-24 00:11:32 --> Database Driver Class Initialized
DEBUG - 2018-03-24 00:11:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 00:11:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 00:11:32 --> Form Validation Class Initialized
INFO - 2018-03-24 00:11:32 --> Model Class Initialized
INFO - 2018-03-24 00:11:32 --> Controller Class Initialized
INFO - 2018-03-24 00:11:32 --> Model Class Initialized
INFO - 2018-03-24 00:11:32 --> Model Class Initialized
INFO - 2018-03-24 00:11:32 --> Model Class Initialized
INFO - 2018-03-24 00:11:32 --> Model Class Initialized
DEBUG - 2018-03-24 00:11:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 00:11:32 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-24 00:11:32 --> Final output sent to browser
DEBUG - 2018-03-24 00:11:32 --> Total execution time: 0.1098
INFO - 2018-03-24 00:11:32 --> Config Class Initialized
INFO - 2018-03-24 00:11:32 --> Hooks Class Initialized
INFO - 2018-03-24 00:11:32 --> Config Class Initialized
INFO - 2018-03-24 00:11:32 --> Hooks Class Initialized
INFO - 2018-03-24 00:11:32 --> Config Class Initialized
INFO - 2018-03-24 00:11:32 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:11:32 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:11:32 --> Utf8 Class Initialized
DEBUG - 2018-03-24 00:11:32 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:11:32 --> Config Class Initialized
INFO - 2018-03-24 00:11:32 --> Utf8 Class Initialized
INFO - 2018-03-24 00:11:32 --> Hooks Class Initialized
INFO - 2018-03-24 00:11:32 --> URI Class Initialized
INFO - 2018-03-24 00:11:32 --> URI Class Initialized
DEBUG - 2018-03-24 00:11:32 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:11:32 --> Utf8 Class Initialized
INFO - 2018-03-24 00:11:32 --> Router Class Initialized
DEBUG - 2018-03-24 00:11:32 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:11:32 --> Router Class Initialized
INFO - 2018-03-24 00:11:32 --> Utf8 Class Initialized
INFO - 2018-03-24 00:11:32 --> URI Class Initialized
INFO - 2018-03-24 00:11:32 --> Output Class Initialized
INFO - 2018-03-24 00:11:32 --> URI Class Initialized
INFO - 2018-03-24 00:11:32 --> Output Class Initialized
INFO - 2018-03-24 00:11:32 --> Router Class Initialized
INFO - 2018-03-24 00:11:32 --> Security Class Initialized
INFO - 2018-03-24 00:11:32 --> Security Class Initialized
INFO - 2018-03-24 00:11:32 --> Router Class Initialized
DEBUG - 2018-03-24 00:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:11:32 --> Output Class Initialized
INFO - 2018-03-24 00:11:32 --> Input Class Initialized
DEBUG - 2018-03-24 00:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:11:32 --> Input Class Initialized
INFO - 2018-03-24 00:11:32 --> Language Class Initialized
INFO - 2018-03-24 00:11:32 --> Output Class Initialized
INFO - 2018-03-24 00:11:32 --> Security Class Initialized
INFO - 2018-03-24 00:11:32 --> Language Class Initialized
ERROR - 2018-03-24 00:11:32 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-24 00:11:32 --> Security Class Initialized
ERROR - 2018-03-24 00:11:32 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-24 00:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:11:32 --> Input Class Initialized
DEBUG - 2018-03-24 00:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:11:32 --> Input Class Initialized
INFO - 2018-03-24 00:11:32 --> Language Class Initialized
INFO - 2018-03-24 00:11:32 --> Language Class Initialized
ERROR - 2018-03-24 00:11:32 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-24 00:11:32 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-24 00:11:32 --> Config Class Initialized
INFO - 2018-03-24 00:11:32 --> Hooks Class Initialized
INFO - 2018-03-24 00:11:32 --> Config Class Initialized
INFO - 2018-03-24 00:11:32 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:11:32 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:11:32 --> Utf8 Class Initialized
INFO - 2018-03-24 00:11:32 --> Config Class Initialized
INFO - 2018-03-24 00:11:32 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:11:32 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:11:32 --> URI Class Initialized
INFO - 2018-03-24 00:11:32 --> Utf8 Class Initialized
INFO - 2018-03-24 00:11:32 --> URI Class Initialized
INFO - 2018-03-24 00:11:32 --> Router Class Initialized
DEBUG - 2018-03-24 00:11:32 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:11:32 --> Utf8 Class Initialized
INFO - 2018-03-24 00:11:32 --> Router Class Initialized
INFO - 2018-03-24 00:11:32 --> Output Class Initialized
INFO - 2018-03-24 00:11:32 --> URI Class Initialized
INFO - 2018-03-24 00:11:32 --> Output Class Initialized
INFO - 2018-03-24 00:11:32 --> Security Class Initialized
INFO - 2018-03-24 00:11:32 --> Router Class Initialized
INFO - 2018-03-24 00:11:32 --> Security Class Initialized
DEBUG - 2018-03-24 00:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:11:32 --> Input Class Initialized
INFO - 2018-03-24 00:11:32 --> Output Class Initialized
DEBUG - 2018-03-24 00:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:11:32 --> Language Class Initialized
INFO - 2018-03-24 00:11:32 --> Input Class Initialized
INFO - 2018-03-24 00:11:32 --> Security Class Initialized
INFO - 2018-03-24 00:11:32 --> Language Class Initialized
ERROR - 2018-03-24 00:11:32 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-03-24 00:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:11:32 --> Input Class Initialized
ERROR - 2018-03-24 00:11:32 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-24 00:11:32 --> Language Class Initialized
ERROR - 2018-03-24 00:11:32 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-24 00:11:32 --> Config Class Initialized
INFO - 2018-03-24 00:11:32 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:11:32 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:11:32 --> Utf8 Class Initialized
INFO - 2018-03-24 00:11:32 --> URI Class Initialized
INFO - 2018-03-24 00:11:32 --> Router Class Initialized
INFO - 2018-03-24 00:11:32 --> Output Class Initialized
INFO - 2018-03-24 00:11:32 --> Security Class Initialized
DEBUG - 2018-03-24 00:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:11:32 --> Input Class Initialized
INFO - 2018-03-24 00:11:32 --> Language Class Initialized
INFO - 2018-03-24 00:11:32 --> Loader Class Initialized
INFO - 2018-03-24 00:11:32 --> Helper loaded: url_helper
INFO - 2018-03-24 00:11:32 --> Helper loaded: form_helper
INFO - 2018-03-24 00:11:32 --> Database Driver Class Initialized
DEBUG - 2018-03-24 00:11:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 00:11:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 00:11:32 --> Form Validation Class Initialized
INFO - 2018-03-24 00:11:32 --> Model Class Initialized
INFO - 2018-03-24 00:11:32 --> Controller Class Initialized
INFO - 2018-03-24 00:11:32 --> Model Class Initialized
INFO - 2018-03-24 00:11:32 --> Model Class Initialized
INFO - 2018-03-24 00:11:32 --> Model Class Initialized
INFO - 2018-03-24 00:11:32 --> Model Class Initialized
DEBUG - 2018-03-24 00:11:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 00:11:34 --> Config Class Initialized
INFO - 2018-03-24 00:11:34 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:11:34 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:11:34 --> Utf8 Class Initialized
INFO - 2018-03-24 00:11:34 --> URI Class Initialized
INFO - 2018-03-24 00:11:34 --> Router Class Initialized
INFO - 2018-03-24 00:11:34 --> Output Class Initialized
INFO - 2018-03-24 00:11:34 --> Security Class Initialized
DEBUG - 2018-03-24 00:11:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:11:34 --> Input Class Initialized
INFO - 2018-03-24 00:11:34 --> Language Class Initialized
INFO - 2018-03-24 00:11:34 --> Loader Class Initialized
INFO - 2018-03-24 00:11:34 --> Helper loaded: url_helper
INFO - 2018-03-24 00:11:34 --> Helper loaded: form_helper
INFO - 2018-03-24 00:11:34 --> Database Driver Class Initialized
DEBUG - 2018-03-24 00:11:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 00:11:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 00:11:34 --> Form Validation Class Initialized
INFO - 2018-03-24 00:11:34 --> Model Class Initialized
INFO - 2018-03-24 00:11:34 --> Controller Class Initialized
INFO - 2018-03-24 00:11:34 --> Model Class Initialized
INFO - 2018-03-24 00:11:34 --> Model Class Initialized
INFO - 2018-03-24 00:11:34 --> Model Class Initialized
INFO - 2018-03-24 00:11:34 --> Model Class Initialized
DEBUG - 2018-03-24 00:11:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 00:11:34 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-24 00:11:34 --> Final output sent to browser
DEBUG - 2018-03-24 00:11:34 --> Total execution time: 0.1160
INFO - 2018-03-24 00:11:34 --> Config Class Initialized
INFO - 2018-03-24 00:11:34 --> Hooks Class Initialized
INFO - 2018-03-24 00:11:34 --> Config Class Initialized
INFO - 2018-03-24 00:11:34 --> Hooks Class Initialized
INFO - 2018-03-24 00:11:34 --> Config Class Initialized
INFO - 2018-03-24 00:11:34 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:11:34 --> UTF-8 Support Enabled
DEBUG - 2018-03-24 00:11:34 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:11:34 --> Utf8 Class Initialized
INFO - 2018-03-24 00:11:34 --> Utf8 Class Initialized
INFO - 2018-03-24 00:11:34 --> URI Class Initialized
INFO - 2018-03-24 00:11:34 --> URI Class Initialized
DEBUG - 2018-03-24 00:11:34 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:11:34 --> Utf8 Class Initialized
INFO - 2018-03-24 00:11:34 --> Router Class Initialized
INFO - 2018-03-24 00:11:34 --> URI Class Initialized
INFO - 2018-03-24 00:11:34 --> Router Class Initialized
INFO - 2018-03-24 00:11:34 --> Output Class Initialized
INFO - 2018-03-24 00:11:34 --> Output Class Initialized
INFO - 2018-03-24 00:11:34 --> Router Class Initialized
INFO - 2018-03-24 00:11:34 --> Security Class Initialized
INFO - 2018-03-24 00:11:34 --> Security Class Initialized
INFO - 2018-03-24 00:11:34 --> Output Class Initialized
DEBUG - 2018-03-24 00:11:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:11:34 --> Input Class Initialized
DEBUG - 2018-03-24 00:11:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:11:34 --> Input Class Initialized
INFO - 2018-03-24 00:11:34 --> Security Class Initialized
INFO - 2018-03-24 00:11:34 --> Language Class Initialized
INFO - 2018-03-24 00:11:34 --> Language Class Initialized
DEBUG - 2018-03-24 00:11:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-03-24 00:11:34 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-24 00:11:34 --> Input Class Initialized
ERROR - 2018-03-24 00:11:34 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-24 00:11:34 --> Language Class Initialized
ERROR - 2018-03-24 00:11:34 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-24 00:11:34 --> Config Class Initialized
INFO - 2018-03-24 00:11:34 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:11:34 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:11:34 --> Utf8 Class Initialized
INFO - 2018-03-24 00:11:34 --> URI Class Initialized
INFO - 2018-03-24 00:11:34 --> Router Class Initialized
INFO - 2018-03-24 00:11:34 --> Output Class Initialized
INFO - 2018-03-24 00:11:34 --> Security Class Initialized
DEBUG - 2018-03-24 00:11:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:11:34 --> Input Class Initialized
INFO - 2018-03-24 00:11:34 --> Language Class Initialized
ERROR - 2018-03-24 00:11:34 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-24 00:11:34 --> Config Class Initialized
INFO - 2018-03-24 00:11:34 --> Hooks Class Initialized
INFO - 2018-03-24 00:11:34 --> Config Class Initialized
INFO - 2018-03-24 00:11:34 --> Hooks Class Initialized
INFO - 2018-03-24 00:11:34 --> Config Class Initialized
INFO - 2018-03-24 00:11:34 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:11:34 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:11:34 --> Utf8 Class Initialized
DEBUG - 2018-03-24 00:11:34 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:11:34 --> Utf8 Class Initialized
INFO - 2018-03-24 00:11:34 --> URI Class Initialized
INFO - 2018-03-24 00:11:34 --> URI Class Initialized
DEBUG - 2018-03-24 00:11:34 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:11:34 --> Utf8 Class Initialized
INFO - 2018-03-24 00:11:34 --> Router Class Initialized
INFO - 2018-03-24 00:11:34 --> URI Class Initialized
INFO - 2018-03-24 00:11:34 --> Router Class Initialized
INFO - 2018-03-24 00:11:34 --> Output Class Initialized
INFO - 2018-03-24 00:11:34 --> Output Class Initialized
INFO - 2018-03-24 00:11:34 --> Router Class Initialized
INFO - 2018-03-24 00:11:34 --> Security Class Initialized
INFO - 2018-03-24 00:11:34 --> Security Class Initialized
DEBUG - 2018-03-24 00:11:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:11:34 --> Output Class Initialized
INFO - 2018-03-24 00:11:34 --> Input Class Initialized
DEBUG - 2018-03-24 00:11:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:11:34 --> Input Class Initialized
INFO - 2018-03-24 00:11:34 --> Language Class Initialized
INFO - 2018-03-24 00:11:34 --> Security Class Initialized
INFO - 2018-03-24 00:11:34 --> Language Class Initialized
ERROR - 2018-03-24 00:11:34 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-03-24 00:11:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:11:34 --> Input Class Initialized
ERROR - 2018-03-24 00:11:34 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-24 00:11:34 --> Language Class Initialized
ERROR - 2018-03-24 00:11:34 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-24 00:11:34 --> Config Class Initialized
INFO - 2018-03-24 00:11:34 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:11:34 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:11:34 --> Utf8 Class Initialized
INFO - 2018-03-24 00:11:34 --> URI Class Initialized
INFO - 2018-03-24 00:11:34 --> Router Class Initialized
INFO - 2018-03-24 00:11:34 --> Output Class Initialized
INFO - 2018-03-24 00:11:34 --> Security Class Initialized
DEBUG - 2018-03-24 00:11:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:11:34 --> Input Class Initialized
INFO - 2018-03-24 00:11:34 --> Language Class Initialized
INFO - 2018-03-24 00:11:34 --> Loader Class Initialized
INFO - 2018-03-24 00:11:34 --> Helper loaded: url_helper
INFO - 2018-03-24 00:11:34 --> Helper loaded: form_helper
INFO - 2018-03-24 00:11:34 --> Database Driver Class Initialized
DEBUG - 2018-03-24 00:11:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 00:11:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 00:11:34 --> Form Validation Class Initialized
INFO - 2018-03-24 00:11:34 --> Model Class Initialized
INFO - 2018-03-24 00:11:34 --> Controller Class Initialized
INFO - 2018-03-24 00:11:34 --> Model Class Initialized
INFO - 2018-03-24 00:11:34 --> Model Class Initialized
INFO - 2018-03-24 00:11:34 --> Model Class Initialized
INFO - 2018-03-24 00:11:34 --> Model Class Initialized
DEBUG - 2018-03-24 00:11:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 00:11:42 --> Config Class Initialized
INFO - 2018-03-24 00:11:42 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:11:42 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:11:42 --> Utf8 Class Initialized
INFO - 2018-03-24 00:11:42 --> URI Class Initialized
INFO - 2018-03-24 00:11:42 --> Router Class Initialized
INFO - 2018-03-24 00:11:42 --> Output Class Initialized
INFO - 2018-03-24 00:11:42 --> Security Class Initialized
DEBUG - 2018-03-24 00:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:11:42 --> Input Class Initialized
INFO - 2018-03-24 00:11:42 --> Language Class Initialized
INFO - 2018-03-24 00:11:42 --> Loader Class Initialized
INFO - 2018-03-24 00:11:42 --> Helper loaded: url_helper
INFO - 2018-03-24 00:11:42 --> Helper loaded: form_helper
INFO - 2018-03-24 00:11:42 --> Database Driver Class Initialized
DEBUG - 2018-03-24 00:11:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 00:11:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 00:11:42 --> Form Validation Class Initialized
INFO - 2018-03-24 00:11:42 --> Model Class Initialized
INFO - 2018-03-24 00:11:42 --> Controller Class Initialized
INFO - 2018-03-24 00:11:42 --> Model Class Initialized
INFO - 2018-03-24 00:11:42 --> Model Class Initialized
INFO - 2018-03-24 00:11:42 --> Model Class Initialized
INFO - 2018-03-24 00:11:42 --> Model Class Initialized
DEBUG - 2018-03-24 00:11:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 00:12:09 --> Config Class Initialized
INFO - 2018-03-24 00:12:09 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:12:09 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:12:09 --> Utf8 Class Initialized
INFO - 2018-03-24 00:12:09 --> URI Class Initialized
INFO - 2018-03-24 00:12:09 --> Router Class Initialized
INFO - 2018-03-24 00:12:09 --> Output Class Initialized
INFO - 2018-03-24 00:12:09 --> Security Class Initialized
DEBUG - 2018-03-24 00:12:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:12:09 --> Input Class Initialized
INFO - 2018-03-24 00:12:09 --> Language Class Initialized
INFO - 2018-03-24 00:12:09 --> Loader Class Initialized
INFO - 2018-03-24 00:12:09 --> Helper loaded: url_helper
INFO - 2018-03-24 00:12:09 --> Helper loaded: form_helper
INFO - 2018-03-24 00:12:09 --> Database Driver Class Initialized
DEBUG - 2018-03-24 00:12:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 00:12:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 00:12:09 --> Form Validation Class Initialized
INFO - 2018-03-24 00:12:09 --> Model Class Initialized
INFO - 2018-03-24 00:12:09 --> Controller Class Initialized
INFO - 2018-03-24 00:12:09 --> Model Class Initialized
INFO - 2018-03-24 00:12:09 --> Model Class Initialized
INFO - 2018-03-24 00:12:09 --> Model Class Initialized
INFO - 2018-03-24 00:12:09 --> Model Class Initialized
DEBUG - 2018-03-24 00:12:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 00:12:44 --> Config Class Initialized
INFO - 2018-03-24 00:12:44 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:12:44 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:12:44 --> Utf8 Class Initialized
INFO - 2018-03-24 00:12:44 --> URI Class Initialized
INFO - 2018-03-24 00:12:44 --> Router Class Initialized
INFO - 2018-03-24 00:12:44 --> Output Class Initialized
INFO - 2018-03-24 00:12:44 --> Security Class Initialized
DEBUG - 2018-03-24 00:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:12:44 --> Input Class Initialized
INFO - 2018-03-24 00:12:44 --> Language Class Initialized
INFO - 2018-03-24 00:12:44 --> Loader Class Initialized
INFO - 2018-03-24 00:12:44 --> Helper loaded: url_helper
INFO - 2018-03-24 00:12:44 --> Helper loaded: form_helper
INFO - 2018-03-24 00:12:44 --> Database Driver Class Initialized
DEBUG - 2018-03-24 00:12:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 00:12:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 00:12:44 --> Form Validation Class Initialized
INFO - 2018-03-24 00:12:44 --> Model Class Initialized
INFO - 2018-03-24 00:12:44 --> Controller Class Initialized
INFO - 2018-03-24 00:12:44 --> Model Class Initialized
INFO - 2018-03-24 00:12:44 --> Model Class Initialized
INFO - 2018-03-24 00:12:44 --> Model Class Initialized
INFO - 2018-03-24 00:12:44 --> Model Class Initialized
DEBUG - 2018-03-24 00:12:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 00:12:44 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-24 00:12:44 --> Final output sent to browser
DEBUG - 2018-03-24 00:12:44 --> Total execution time: 0.1145
INFO - 2018-03-24 00:12:44 --> Config Class Initialized
INFO - 2018-03-24 00:12:44 --> Hooks Class Initialized
INFO - 2018-03-24 00:12:44 --> Config Class Initialized
INFO - 2018-03-24 00:12:44 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:12:44 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:12:44 --> Utf8 Class Initialized
INFO - 2018-03-24 00:12:44 --> URI Class Initialized
DEBUG - 2018-03-24 00:12:44 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:12:44 --> Utf8 Class Initialized
INFO - 2018-03-24 00:12:44 --> Router Class Initialized
INFO - 2018-03-24 00:12:44 --> URI Class Initialized
INFO - 2018-03-24 00:12:45 --> Router Class Initialized
INFO - 2018-03-24 00:12:45 --> Output Class Initialized
INFO - 2018-03-24 00:12:45 --> Security Class Initialized
INFO - 2018-03-24 00:12:45 --> Output Class Initialized
DEBUG - 2018-03-24 00:12:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:12:45 --> Input Class Initialized
INFO - 2018-03-24 00:12:45 --> Security Class Initialized
INFO - 2018-03-24 00:12:45 --> Language Class Initialized
DEBUG - 2018-03-24 00:12:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:12:45 --> Input Class Initialized
ERROR - 2018-03-24 00:12:45 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-24 00:12:45 --> Language Class Initialized
ERROR - 2018-03-24 00:12:45 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-24 00:12:45 --> Config Class Initialized
INFO - 2018-03-24 00:12:45 --> Hooks Class Initialized
INFO - 2018-03-24 00:12:45 --> Config Class Initialized
INFO - 2018-03-24 00:12:45 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:12:45 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:12:45 --> Utf8 Class Initialized
INFO - 2018-03-24 00:12:45 --> URI Class Initialized
DEBUG - 2018-03-24 00:12:45 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:12:45 --> Utf8 Class Initialized
INFO - 2018-03-24 00:12:45 --> URI Class Initialized
INFO - 2018-03-24 00:12:45 --> Router Class Initialized
INFO - 2018-03-24 00:12:45 --> Router Class Initialized
INFO - 2018-03-24 00:12:45 --> Output Class Initialized
INFO - 2018-03-24 00:12:45 --> Security Class Initialized
INFO - 2018-03-24 00:12:45 --> Output Class Initialized
DEBUG - 2018-03-24 00:12:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:12:45 --> Security Class Initialized
INFO - 2018-03-24 00:12:45 --> Input Class Initialized
INFO - 2018-03-24 00:12:45 --> Language Class Initialized
DEBUG - 2018-03-24 00:12:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:12:45 --> Input Class Initialized
INFO - 2018-03-24 00:12:45 --> Language Class Initialized
ERROR - 2018-03-24 00:12:45 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-24 00:12:45 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-24 00:12:45 --> Config Class Initialized
INFO - 2018-03-24 00:12:45 --> Hooks Class Initialized
INFO - 2018-03-24 00:12:45 --> Config Class Initialized
INFO - 2018-03-24 00:12:45 --> Config Class Initialized
DEBUG - 2018-03-24 00:12:45 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:12:45 --> Hooks Class Initialized
INFO - 2018-03-24 00:12:45 --> Hooks Class Initialized
INFO - 2018-03-24 00:12:45 --> Utf8 Class Initialized
INFO - 2018-03-24 00:12:45 --> URI Class Initialized
DEBUG - 2018-03-24 00:12:45 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:12:45 --> Utf8 Class Initialized
DEBUG - 2018-03-24 00:12:45 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:12:45 --> Router Class Initialized
INFO - 2018-03-24 00:12:45 --> Utf8 Class Initialized
INFO - 2018-03-24 00:12:45 --> URI Class Initialized
INFO - 2018-03-24 00:12:45 --> URI Class Initialized
INFO - 2018-03-24 00:12:45 --> Output Class Initialized
INFO - 2018-03-24 00:12:45 --> Router Class Initialized
INFO - 2018-03-24 00:12:45 --> Security Class Initialized
INFO - 2018-03-24 00:12:45 --> Router Class Initialized
INFO - 2018-03-24 00:12:45 --> Output Class Initialized
DEBUG - 2018-03-24 00:12:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:12:45 --> Input Class Initialized
INFO - 2018-03-24 00:12:45 --> Output Class Initialized
INFO - 2018-03-24 00:12:45 --> Language Class Initialized
INFO - 2018-03-24 00:12:45 --> Security Class Initialized
INFO - 2018-03-24 00:12:45 --> Security Class Initialized
DEBUG - 2018-03-24 00:12:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-03-24 00:12:45 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-24 00:12:45 --> Input Class Initialized
INFO - 2018-03-24 00:12:45 --> Language Class Initialized
DEBUG - 2018-03-24 00:12:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:12:45 --> Input Class Initialized
INFO - 2018-03-24 00:12:45 --> Language Class Initialized
ERROR - 2018-03-24 00:12:45 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-24 00:12:45 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-24 00:12:45 --> Config Class Initialized
INFO - 2018-03-24 00:12:45 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:12:45 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:12:45 --> Utf8 Class Initialized
INFO - 2018-03-24 00:12:45 --> URI Class Initialized
INFO - 2018-03-24 00:12:45 --> Router Class Initialized
INFO - 2018-03-24 00:12:45 --> Output Class Initialized
INFO - 2018-03-24 00:12:45 --> Security Class Initialized
DEBUG - 2018-03-24 00:12:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:12:45 --> Input Class Initialized
INFO - 2018-03-24 00:12:45 --> Language Class Initialized
INFO - 2018-03-24 00:12:45 --> Loader Class Initialized
INFO - 2018-03-24 00:12:45 --> Helper loaded: url_helper
INFO - 2018-03-24 00:12:45 --> Helper loaded: form_helper
INFO - 2018-03-24 00:12:45 --> Database Driver Class Initialized
DEBUG - 2018-03-24 00:12:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 00:12:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 00:12:45 --> Form Validation Class Initialized
INFO - 2018-03-24 00:12:45 --> Model Class Initialized
INFO - 2018-03-24 00:12:45 --> Controller Class Initialized
INFO - 2018-03-24 00:12:45 --> Model Class Initialized
INFO - 2018-03-24 00:12:45 --> Model Class Initialized
INFO - 2018-03-24 00:12:45 --> Model Class Initialized
INFO - 2018-03-24 00:12:45 --> Model Class Initialized
DEBUG - 2018-03-24 00:12:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 00:12:50 --> Config Class Initialized
INFO - 2018-03-24 00:12:50 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:12:50 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:12:50 --> Utf8 Class Initialized
INFO - 2018-03-24 00:12:51 --> URI Class Initialized
INFO - 2018-03-24 00:12:51 --> Router Class Initialized
INFO - 2018-03-24 00:12:51 --> Output Class Initialized
INFO - 2018-03-24 00:12:51 --> Security Class Initialized
DEBUG - 2018-03-24 00:12:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:12:51 --> Input Class Initialized
INFO - 2018-03-24 00:12:51 --> Language Class Initialized
INFO - 2018-03-24 00:12:51 --> Loader Class Initialized
INFO - 2018-03-24 00:12:51 --> Helper loaded: url_helper
INFO - 2018-03-24 00:12:51 --> Helper loaded: form_helper
INFO - 2018-03-24 00:12:51 --> Database Driver Class Initialized
DEBUG - 2018-03-24 00:12:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 00:12:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 00:12:51 --> Form Validation Class Initialized
INFO - 2018-03-24 00:12:51 --> Model Class Initialized
INFO - 2018-03-24 00:12:51 --> Controller Class Initialized
INFO - 2018-03-24 00:12:51 --> Model Class Initialized
INFO - 2018-03-24 00:12:51 --> Model Class Initialized
INFO - 2018-03-24 00:12:51 --> Model Class Initialized
INFO - 2018-03-24 00:12:51 --> Model Class Initialized
DEBUG - 2018-03-24 00:12:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 00:12:54 --> Config Class Initialized
INFO - 2018-03-24 00:12:54 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:12:54 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:12:54 --> Utf8 Class Initialized
INFO - 2018-03-24 00:12:54 --> URI Class Initialized
INFO - 2018-03-24 00:12:54 --> Router Class Initialized
INFO - 2018-03-24 00:12:54 --> Output Class Initialized
INFO - 2018-03-24 00:12:54 --> Security Class Initialized
DEBUG - 2018-03-24 00:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:12:54 --> Input Class Initialized
INFO - 2018-03-24 00:12:54 --> Language Class Initialized
INFO - 2018-03-24 00:12:54 --> Loader Class Initialized
INFO - 2018-03-24 00:12:54 --> Helper loaded: url_helper
INFO - 2018-03-24 00:12:54 --> Helper loaded: form_helper
INFO - 2018-03-24 00:12:54 --> Database Driver Class Initialized
DEBUG - 2018-03-24 00:12:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 00:12:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 00:12:54 --> Form Validation Class Initialized
INFO - 2018-03-24 00:12:54 --> Model Class Initialized
INFO - 2018-03-24 00:12:54 --> Controller Class Initialized
INFO - 2018-03-24 00:12:54 --> Model Class Initialized
INFO - 2018-03-24 00:12:54 --> Model Class Initialized
INFO - 2018-03-24 00:12:54 --> Model Class Initialized
INFO - 2018-03-24 00:12:54 --> Model Class Initialized
DEBUG - 2018-03-24 00:12:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 00:12:57 --> Config Class Initialized
INFO - 2018-03-24 00:12:57 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:12:57 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:12:57 --> Utf8 Class Initialized
INFO - 2018-03-24 00:12:57 --> URI Class Initialized
INFO - 2018-03-24 00:12:57 --> Router Class Initialized
INFO - 2018-03-24 00:12:57 --> Output Class Initialized
INFO - 2018-03-24 00:12:57 --> Security Class Initialized
DEBUG - 2018-03-24 00:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:12:57 --> Input Class Initialized
INFO - 2018-03-24 00:12:57 --> Language Class Initialized
INFO - 2018-03-24 00:12:57 --> Loader Class Initialized
INFO - 2018-03-24 00:12:57 --> Helper loaded: url_helper
INFO - 2018-03-24 00:12:57 --> Helper loaded: form_helper
INFO - 2018-03-24 00:12:57 --> Database Driver Class Initialized
DEBUG - 2018-03-24 00:12:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 00:12:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 00:12:57 --> Form Validation Class Initialized
INFO - 2018-03-24 00:12:57 --> Model Class Initialized
INFO - 2018-03-24 00:12:57 --> Controller Class Initialized
INFO - 2018-03-24 00:12:57 --> Model Class Initialized
INFO - 2018-03-24 00:12:57 --> Model Class Initialized
INFO - 2018-03-24 00:12:57 --> Model Class Initialized
INFO - 2018-03-24 00:12:57 --> Model Class Initialized
DEBUG - 2018-03-24 00:12:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 00:13:46 --> Config Class Initialized
INFO - 2018-03-24 00:13:46 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:13:46 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:13:46 --> Utf8 Class Initialized
INFO - 2018-03-24 00:13:46 --> URI Class Initialized
INFO - 2018-03-24 00:13:46 --> Router Class Initialized
INFO - 2018-03-24 00:13:46 --> Output Class Initialized
INFO - 2018-03-24 00:13:46 --> Security Class Initialized
DEBUG - 2018-03-24 00:13:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:13:46 --> Input Class Initialized
INFO - 2018-03-24 00:13:46 --> Language Class Initialized
INFO - 2018-03-24 00:13:46 --> Loader Class Initialized
INFO - 2018-03-24 00:13:46 --> Helper loaded: url_helper
INFO - 2018-03-24 00:13:46 --> Helper loaded: form_helper
INFO - 2018-03-24 00:13:46 --> Database Driver Class Initialized
DEBUG - 2018-03-24 00:13:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 00:13:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 00:13:46 --> Form Validation Class Initialized
INFO - 2018-03-24 00:13:46 --> Model Class Initialized
INFO - 2018-03-24 00:13:46 --> Controller Class Initialized
INFO - 2018-03-24 00:13:46 --> Model Class Initialized
INFO - 2018-03-24 00:13:46 --> Model Class Initialized
INFO - 2018-03-24 00:13:46 --> Model Class Initialized
INFO - 2018-03-24 00:13:46 --> Model Class Initialized
DEBUG - 2018-03-24 00:13:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 00:13:46 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-24 00:13:46 --> Final output sent to browser
DEBUG - 2018-03-24 00:13:46 --> Total execution time: 0.1061
INFO - 2018-03-24 00:13:46 --> Config Class Initialized
INFO - 2018-03-24 00:13:46 --> Hooks Class Initialized
INFO - 2018-03-24 00:13:46 --> Config Class Initialized
INFO - 2018-03-24 00:13:46 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:13:46 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:13:46 --> Utf8 Class Initialized
DEBUG - 2018-03-24 00:13:46 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:13:46 --> Utf8 Class Initialized
INFO - 2018-03-24 00:13:46 --> URI Class Initialized
INFO - 2018-03-24 00:13:46 --> URI Class Initialized
INFO - 2018-03-24 00:13:46 --> Router Class Initialized
INFO - 2018-03-24 00:13:46 --> Router Class Initialized
INFO - 2018-03-24 00:13:46 --> Output Class Initialized
INFO - 2018-03-24 00:13:46 --> Output Class Initialized
INFO - 2018-03-24 00:13:46 --> Security Class Initialized
INFO - 2018-03-24 00:13:46 --> Security Class Initialized
DEBUG - 2018-03-24 00:13:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:13:46 --> Input Class Initialized
DEBUG - 2018-03-24 00:13:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:13:46 --> Language Class Initialized
INFO - 2018-03-24 00:13:46 --> Input Class Initialized
INFO - 2018-03-24 00:13:46 --> Language Class Initialized
ERROR - 2018-03-24 00:13:46 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-24 00:13:46 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-24 00:13:46 --> Config Class Initialized
INFO - 2018-03-24 00:13:46 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:13:46 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:13:46 --> Config Class Initialized
INFO - 2018-03-24 00:13:46 --> Utf8 Class Initialized
INFO - 2018-03-24 00:13:46 --> Hooks Class Initialized
INFO - 2018-03-24 00:13:46 --> URI Class Initialized
DEBUG - 2018-03-24 00:13:46 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:13:46 --> Router Class Initialized
INFO - 2018-03-24 00:13:46 --> Utf8 Class Initialized
INFO - 2018-03-24 00:13:46 --> URI Class Initialized
INFO - 2018-03-24 00:13:46 --> Output Class Initialized
INFO - 2018-03-24 00:13:46 --> Router Class Initialized
INFO - 2018-03-24 00:13:46 --> Security Class Initialized
DEBUG - 2018-03-24 00:13:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:13:46 --> Input Class Initialized
INFO - 2018-03-24 00:13:46 --> Output Class Initialized
INFO - 2018-03-24 00:13:46 --> Language Class Initialized
INFO - 2018-03-24 00:13:46 --> Security Class Initialized
ERROR - 2018-03-24 00:13:46 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-24 00:13:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:13:46 --> Input Class Initialized
INFO - 2018-03-24 00:13:46 --> Language Class Initialized
INFO - 2018-03-24 00:13:46 --> Config Class Initialized
INFO - 2018-03-24 00:13:46 --> Hooks Class Initialized
ERROR - 2018-03-24 00:13:46 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-24 00:13:46 --> Config Class Initialized
INFO - 2018-03-24 00:13:46 --> Config Class Initialized
INFO - 2018-03-24 00:13:46 --> Hooks Class Initialized
INFO - 2018-03-24 00:13:46 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:13:46 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:13:46 --> Utf8 Class Initialized
DEBUG - 2018-03-24 00:13:46 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:13:46 --> URI Class Initialized
INFO - 2018-03-24 00:13:46 --> Utf8 Class Initialized
DEBUG - 2018-03-24 00:13:46 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:13:46 --> Utf8 Class Initialized
INFO - 2018-03-24 00:13:46 --> URI Class Initialized
INFO - 2018-03-24 00:13:46 --> URI Class Initialized
INFO - 2018-03-24 00:13:46 --> Router Class Initialized
INFO - 2018-03-24 00:13:46 --> Router Class Initialized
INFO - 2018-03-24 00:13:46 --> Router Class Initialized
INFO - 2018-03-24 00:13:46 --> Output Class Initialized
INFO - 2018-03-24 00:13:46 --> Output Class Initialized
INFO - 2018-03-24 00:13:46 --> Output Class Initialized
INFO - 2018-03-24 00:13:46 --> Security Class Initialized
INFO - 2018-03-24 00:13:46 --> Security Class Initialized
INFO - 2018-03-24 00:13:46 --> Security Class Initialized
DEBUG - 2018-03-24 00:13:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-24 00:13:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:13:46 --> Input Class Initialized
DEBUG - 2018-03-24 00:13:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:13:46 --> Input Class Initialized
INFO - 2018-03-24 00:13:46 --> Input Class Initialized
INFO - 2018-03-24 00:13:46 --> Language Class Initialized
INFO - 2018-03-24 00:13:46 --> Language Class Initialized
INFO - 2018-03-24 00:13:46 --> Language Class Initialized
ERROR - 2018-03-24 00:13:46 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-24 00:13:46 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-24 00:13:46 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-24 00:13:47 --> Config Class Initialized
INFO - 2018-03-24 00:13:47 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:13:47 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:13:47 --> Utf8 Class Initialized
INFO - 2018-03-24 00:13:47 --> URI Class Initialized
INFO - 2018-03-24 00:13:47 --> Router Class Initialized
INFO - 2018-03-24 00:13:47 --> Output Class Initialized
INFO - 2018-03-24 00:13:47 --> Security Class Initialized
DEBUG - 2018-03-24 00:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:13:47 --> Input Class Initialized
INFO - 2018-03-24 00:13:47 --> Language Class Initialized
INFO - 2018-03-24 00:13:47 --> Loader Class Initialized
INFO - 2018-03-24 00:13:47 --> Helper loaded: url_helper
INFO - 2018-03-24 00:13:47 --> Helper loaded: form_helper
INFO - 2018-03-24 00:13:47 --> Database Driver Class Initialized
DEBUG - 2018-03-24 00:13:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 00:13:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 00:13:47 --> Form Validation Class Initialized
INFO - 2018-03-24 00:13:47 --> Model Class Initialized
INFO - 2018-03-24 00:13:47 --> Controller Class Initialized
INFO - 2018-03-24 00:13:47 --> Model Class Initialized
INFO - 2018-03-24 00:13:47 --> Model Class Initialized
INFO - 2018-03-24 00:13:47 --> Model Class Initialized
INFO - 2018-03-24 00:13:47 --> Model Class Initialized
DEBUG - 2018-03-24 00:13:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 00:13:50 --> Config Class Initialized
INFO - 2018-03-24 00:13:50 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:13:50 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:13:50 --> Utf8 Class Initialized
INFO - 2018-03-24 00:13:50 --> URI Class Initialized
INFO - 2018-03-24 00:13:50 --> Router Class Initialized
INFO - 2018-03-24 00:13:50 --> Output Class Initialized
INFO - 2018-03-24 00:13:50 --> Security Class Initialized
DEBUG - 2018-03-24 00:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:13:50 --> Input Class Initialized
INFO - 2018-03-24 00:13:50 --> Language Class Initialized
INFO - 2018-03-24 00:13:50 --> Loader Class Initialized
INFO - 2018-03-24 00:13:50 --> Helper loaded: url_helper
INFO - 2018-03-24 00:13:50 --> Helper loaded: form_helper
INFO - 2018-03-24 00:13:50 --> Database Driver Class Initialized
DEBUG - 2018-03-24 00:13:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 00:13:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 00:13:50 --> Form Validation Class Initialized
INFO - 2018-03-24 00:13:50 --> Model Class Initialized
INFO - 2018-03-24 00:13:50 --> Controller Class Initialized
INFO - 2018-03-24 00:13:50 --> Model Class Initialized
INFO - 2018-03-24 00:13:50 --> Model Class Initialized
INFO - 2018-03-24 00:13:50 --> Model Class Initialized
INFO - 2018-03-24 00:13:50 --> Model Class Initialized
DEBUG - 2018-03-24 00:13:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 00:14:44 --> Config Class Initialized
INFO - 2018-03-24 00:14:44 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:14:44 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:14:44 --> Utf8 Class Initialized
INFO - 2018-03-24 00:14:44 --> URI Class Initialized
INFO - 2018-03-24 00:14:44 --> Router Class Initialized
INFO - 2018-03-24 00:14:44 --> Output Class Initialized
INFO - 2018-03-24 00:14:44 --> Security Class Initialized
DEBUG - 2018-03-24 00:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:14:44 --> Input Class Initialized
INFO - 2018-03-24 00:14:44 --> Language Class Initialized
INFO - 2018-03-24 00:14:44 --> Loader Class Initialized
INFO - 2018-03-24 00:14:44 --> Helper loaded: url_helper
INFO - 2018-03-24 00:14:44 --> Helper loaded: form_helper
INFO - 2018-03-24 00:14:44 --> Database Driver Class Initialized
DEBUG - 2018-03-24 00:14:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 00:14:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 00:14:44 --> Form Validation Class Initialized
INFO - 2018-03-24 00:14:44 --> Model Class Initialized
INFO - 2018-03-24 00:14:44 --> Controller Class Initialized
INFO - 2018-03-24 00:14:44 --> Model Class Initialized
INFO - 2018-03-24 00:14:44 --> Model Class Initialized
INFO - 2018-03-24 00:14:44 --> Model Class Initialized
INFO - 2018-03-24 00:14:44 --> Model Class Initialized
DEBUG - 2018-03-24 00:14:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 00:14:44 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-24 00:14:44 --> Final output sent to browser
DEBUG - 2018-03-24 00:14:44 --> Total execution time: 0.0837
INFO - 2018-03-24 00:14:44 --> Config Class Initialized
INFO - 2018-03-24 00:14:44 --> Hooks Class Initialized
INFO - 2018-03-24 00:14:44 --> Config Class Initialized
INFO - 2018-03-24 00:14:44 --> Hooks Class Initialized
INFO - 2018-03-24 00:14:44 --> Config Class Initialized
INFO - 2018-03-24 00:14:44 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:14:44 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:14:44 --> Utf8 Class Initialized
INFO - 2018-03-24 00:14:44 --> URI Class Initialized
INFO - 2018-03-24 00:14:44 --> Config Class Initialized
DEBUG - 2018-03-24 00:14:44 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:14:44 --> Hooks Class Initialized
INFO - 2018-03-24 00:14:44 --> Utf8 Class Initialized
DEBUG - 2018-03-24 00:14:44 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:14:44 --> Utf8 Class Initialized
INFO - 2018-03-24 00:14:44 --> Router Class Initialized
INFO - 2018-03-24 00:14:44 --> URI Class Initialized
INFO - 2018-03-24 00:14:44 --> URI Class Initialized
DEBUG - 2018-03-24 00:14:44 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:14:44 --> Output Class Initialized
INFO - 2018-03-24 00:14:44 --> Router Class Initialized
INFO - 2018-03-24 00:14:44 --> Utf8 Class Initialized
INFO - 2018-03-24 00:14:44 --> Security Class Initialized
INFO - 2018-03-24 00:14:44 --> Router Class Initialized
INFO - 2018-03-24 00:14:44 --> URI Class Initialized
INFO - 2018-03-24 00:14:44 --> Output Class Initialized
DEBUG - 2018-03-24 00:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:14:44 --> Input Class Initialized
INFO - 2018-03-24 00:14:44 --> Router Class Initialized
INFO - 2018-03-24 00:14:44 --> Output Class Initialized
INFO - 2018-03-24 00:14:44 --> Security Class Initialized
INFO - 2018-03-24 00:14:44 --> Language Class Initialized
INFO - 2018-03-24 00:14:44 --> Security Class Initialized
DEBUG - 2018-03-24 00:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:14:44 --> Output Class Initialized
ERROR - 2018-03-24 00:14:44 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-24 00:14:44 --> Input Class Initialized
DEBUG - 2018-03-24 00:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:14:44 --> Input Class Initialized
INFO - 2018-03-24 00:14:44 --> Language Class Initialized
INFO - 2018-03-24 00:14:44 --> Security Class Initialized
INFO - 2018-03-24 00:14:44 --> Language Class Initialized
ERROR - 2018-03-24 00:14:44 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-24 00:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:14:44 --> Input Class Initialized
ERROR - 2018-03-24 00:14:44 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-24 00:14:44 --> Language Class Initialized
ERROR - 2018-03-24 00:14:44 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-24 00:14:44 --> Config Class Initialized
INFO - 2018-03-24 00:14:44 --> Hooks Class Initialized
INFO - 2018-03-24 00:14:44 --> Config Class Initialized
INFO - 2018-03-24 00:14:44 --> Hooks Class Initialized
INFO - 2018-03-24 00:14:44 --> Config Class Initialized
INFO - 2018-03-24 00:14:44 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:14:44 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:14:44 --> Utf8 Class Initialized
DEBUG - 2018-03-24 00:14:44 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:14:44 --> Utf8 Class Initialized
INFO - 2018-03-24 00:14:44 --> URI Class Initialized
DEBUG - 2018-03-24 00:14:44 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:14:44 --> Utf8 Class Initialized
INFO - 2018-03-24 00:14:44 --> URI Class Initialized
INFO - 2018-03-24 00:14:44 --> Router Class Initialized
INFO - 2018-03-24 00:14:44 --> URI Class Initialized
INFO - 2018-03-24 00:14:44 --> Router Class Initialized
INFO - 2018-03-24 00:14:44 --> Output Class Initialized
INFO - 2018-03-24 00:14:44 --> Router Class Initialized
INFO - 2018-03-24 00:14:44 --> Output Class Initialized
INFO - 2018-03-24 00:14:44 --> Security Class Initialized
INFO - 2018-03-24 00:14:44 --> Output Class Initialized
INFO - 2018-03-24 00:14:44 --> Security Class Initialized
DEBUG - 2018-03-24 00:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:14:44 --> Security Class Initialized
INFO - 2018-03-24 00:14:44 --> Input Class Initialized
DEBUG - 2018-03-24 00:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:14:44 --> Input Class Initialized
INFO - 2018-03-24 00:14:44 --> Language Class Initialized
DEBUG - 2018-03-24 00:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:14:44 --> Input Class Initialized
INFO - 2018-03-24 00:14:44 --> Language Class Initialized
INFO - 2018-03-24 00:14:44 --> Language Class Initialized
ERROR - 2018-03-24 00:14:44 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-24 00:14:44 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-24 00:14:44 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-24 00:14:44 --> Config Class Initialized
INFO - 2018-03-24 00:14:44 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:14:44 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:14:44 --> Utf8 Class Initialized
INFO - 2018-03-24 00:14:44 --> URI Class Initialized
INFO - 2018-03-24 00:14:44 --> Router Class Initialized
INFO - 2018-03-24 00:14:44 --> Output Class Initialized
INFO - 2018-03-24 00:14:44 --> Security Class Initialized
DEBUG - 2018-03-24 00:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:14:44 --> Input Class Initialized
INFO - 2018-03-24 00:14:44 --> Language Class Initialized
INFO - 2018-03-24 00:14:44 --> Loader Class Initialized
INFO - 2018-03-24 00:14:44 --> Helper loaded: url_helper
INFO - 2018-03-24 00:14:44 --> Helper loaded: form_helper
INFO - 2018-03-24 00:14:44 --> Database Driver Class Initialized
DEBUG - 2018-03-24 00:14:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 00:14:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 00:14:44 --> Form Validation Class Initialized
INFO - 2018-03-24 00:14:44 --> Model Class Initialized
INFO - 2018-03-24 00:14:44 --> Controller Class Initialized
INFO - 2018-03-24 00:14:44 --> Model Class Initialized
INFO - 2018-03-24 00:14:44 --> Model Class Initialized
INFO - 2018-03-24 00:14:44 --> Model Class Initialized
INFO - 2018-03-24 00:14:44 --> Model Class Initialized
DEBUG - 2018-03-24 00:14:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 00:14:52 --> Config Class Initialized
INFO - 2018-03-24 00:14:52 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:14:52 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:14:52 --> Utf8 Class Initialized
INFO - 2018-03-24 00:14:52 --> URI Class Initialized
INFO - 2018-03-24 00:14:52 --> Router Class Initialized
INFO - 2018-03-24 00:14:52 --> Output Class Initialized
INFO - 2018-03-24 00:14:52 --> Security Class Initialized
DEBUG - 2018-03-24 00:14:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:14:52 --> Input Class Initialized
INFO - 2018-03-24 00:14:52 --> Language Class Initialized
INFO - 2018-03-24 00:14:52 --> Loader Class Initialized
INFO - 2018-03-24 00:14:52 --> Helper loaded: url_helper
INFO - 2018-03-24 00:14:52 --> Helper loaded: form_helper
INFO - 2018-03-24 00:14:52 --> Database Driver Class Initialized
DEBUG - 2018-03-24 00:14:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 00:14:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 00:14:52 --> Form Validation Class Initialized
INFO - 2018-03-24 00:14:52 --> Model Class Initialized
INFO - 2018-03-24 00:14:52 --> Controller Class Initialized
INFO - 2018-03-24 00:14:52 --> Model Class Initialized
INFO - 2018-03-24 00:14:52 --> Model Class Initialized
INFO - 2018-03-24 00:14:52 --> Model Class Initialized
INFO - 2018-03-24 00:14:52 --> Model Class Initialized
DEBUG - 2018-03-24 00:14:52 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-03-24 00:14:52 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1726
ERROR - 2018-03-24 00:14:52 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1726
ERROR - 2018-03-24 00:14:52 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1726
INFO - 2018-03-24 00:17:16 --> Config Class Initialized
INFO - 2018-03-24 00:17:16 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:17:16 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:17:16 --> Utf8 Class Initialized
INFO - 2018-03-24 00:17:16 --> URI Class Initialized
INFO - 2018-03-24 00:17:16 --> Router Class Initialized
INFO - 2018-03-24 00:17:16 --> Output Class Initialized
INFO - 2018-03-24 00:17:16 --> Security Class Initialized
DEBUG - 2018-03-24 00:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:17:16 --> Input Class Initialized
INFO - 2018-03-24 00:17:16 --> Language Class Initialized
INFO - 2018-03-24 00:17:16 --> Loader Class Initialized
INFO - 2018-03-24 00:17:16 --> Helper loaded: url_helper
INFO - 2018-03-24 00:17:16 --> Helper loaded: form_helper
INFO - 2018-03-24 00:17:16 --> Database Driver Class Initialized
DEBUG - 2018-03-24 00:17:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 00:17:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 00:17:16 --> Form Validation Class Initialized
INFO - 2018-03-24 00:17:16 --> Model Class Initialized
INFO - 2018-03-24 00:17:16 --> Controller Class Initialized
INFO - 2018-03-24 00:17:16 --> Model Class Initialized
INFO - 2018-03-24 00:17:16 --> Model Class Initialized
INFO - 2018-03-24 00:17:16 --> Model Class Initialized
INFO - 2018-03-24 00:17:16 --> Model Class Initialized
DEBUG - 2018-03-24 00:17:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 00:17:16 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-24 00:17:16 --> Final output sent to browser
DEBUG - 2018-03-24 00:17:16 --> Total execution time: 0.0909
INFO - 2018-03-24 00:17:16 --> Config Class Initialized
INFO - 2018-03-24 00:17:16 --> Config Class Initialized
INFO - 2018-03-24 00:17:16 --> Hooks Class Initialized
INFO - 2018-03-24 00:17:16 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:17:16 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:17:16 --> Utf8 Class Initialized
DEBUG - 2018-03-24 00:17:16 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:17:16 --> Utf8 Class Initialized
INFO - 2018-03-24 00:17:16 --> URI Class Initialized
INFO - 2018-03-24 00:17:16 --> URI Class Initialized
INFO - 2018-03-24 00:17:16 --> Router Class Initialized
INFO - 2018-03-24 00:17:16 --> Router Class Initialized
INFO - 2018-03-24 00:17:16 --> Output Class Initialized
INFO - 2018-03-24 00:17:16 --> Output Class Initialized
INFO - 2018-03-24 00:17:16 --> Security Class Initialized
INFO - 2018-03-24 00:17:16 --> Security Class Initialized
DEBUG - 2018-03-24 00:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:17:16 --> Input Class Initialized
DEBUG - 2018-03-24 00:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:17:16 --> Language Class Initialized
INFO - 2018-03-24 00:17:16 --> Input Class Initialized
INFO - 2018-03-24 00:17:16 --> Language Class Initialized
ERROR - 2018-03-24 00:17:16 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-24 00:17:16 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-24 00:17:16 --> Config Class Initialized
INFO - 2018-03-24 00:17:16 --> Hooks Class Initialized
INFO - 2018-03-24 00:17:16 --> Config Class Initialized
DEBUG - 2018-03-24 00:17:16 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:17:16 --> Hooks Class Initialized
INFO - 2018-03-24 00:17:16 --> Utf8 Class Initialized
INFO - 2018-03-24 00:17:16 --> URI Class Initialized
DEBUG - 2018-03-24 00:17:16 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:17:16 --> Utf8 Class Initialized
INFO - 2018-03-24 00:17:16 --> Router Class Initialized
INFO - 2018-03-24 00:17:16 --> URI Class Initialized
INFO - 2018-03-24 00:17:16 --> Output Class Initialized
INFO - 2018-03-24 00:17:16 --> Router Class Initialized
INFO - 2018-03-24 00:17:16 --> Security Class Initialized
INFO - 2018-03-24 00:17:16 --> Output Class Initialized
DEBUG - 2018-03-24 00:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:17:16 --> Input Class Initialized
INFO - 2018-03-24 00:17:16 --> Security Class Initialized
INFO - 2018-03-24 00:17:16 --> Language Class Initialized
DEBUG - 2018-03-24 00:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:17:16 --> Input Class Initialized
ERROR - 2018-03-24 00:17:16 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-24 00:17:16 --> Language Class Initialized
ERROR - 2018-03-24 00:17:16 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-24 00:17:16 --> Config Class Initialized
INFO - 2018-03-24 00:17:16 --> Hooks Class Initialized
INFO - 2018-03-24 00:17:16 --> Config Class Initialized
INFO - 2018-03-24 00:17:16 --> Hooks Class Initialized
INFO - 2018-03-24 00:17:16 --> Config Class Initialized
INFO - 2018-03-24 00:17:16 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:17:16 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:17:16 --> Utf8 Class Initialized
DEBUG - 2018-03-24 00:17:16 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:17:16 --> URI Class Initialized
INFO - 2018-03-24 00:17:16 --> Utf8 Class Initialized
DEBUG - 2018-03-24 00:17:16 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:17:16 --> URI Class Initialized
INFO - 2018-03-24 00:17:16 --> Utf8 Class Initialized
INFO - 2018-03-24 00:17:16 --> Router Class Initialized
INFO - 2018-03-24 00:17:16 --> URI Class Initialized
INFO - 2018-03-24 00:17:16 --> Router Class Initialized
INFO - 2018-03-24 00:17:16 --> Output Class Initialized
INFO - 2018-03-24 00:17:16 --> Router Class Initialized
INFO - 2018-03-24 00:17:16 --> Output Class Initialized
INFO - 2018-03-24 00:17:16 --> Security Class Initialized
INFO - 2018-03-24 00:17:16 --> Security Class Initialized
INFO - 2018-03-24 00:17:16 --> Output Class Initialized
DEBUG - 2018-03-24 00:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:17:16 --> Input Class Initialized
INFO - 2018-03-24 00:17:16 --> Language Class Initialized
DEBUG - 2018-03-24 00:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:17:16 --> Security Class Initialized
INFO - 2018-03-24 00:17:16 --> Input Class Initialized
ERROR - 2018-03-24 00:17:16 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-24 00:17:16 --> Language Class Initialized
DEBUG - 2018-03-24 00:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:17:16 --> Input Class Initialized
INFO - 2018-03-24 00:17:16 --> Language Class Initialized
ERROR - 2018-03-24 00:17:16 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-24 00:17:16 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-24 00:17:16 --> Config Class Initialized
INFO - 2018-03-24 00:17:16 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:17:16 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:17:16 --> Utf8 Class Initialized
INFO - 2018-03-24 00:17:16 --> URI Class Initialized
INFO - 2018-03-24 00:17:16 --> Router Class Initialized
INFO - 2018-03-24 00:17:16 --> Output Class Initialized
INFO - 2018-03-24 00:17:16 --> Security Class Initialized
DEBUG - 2018-03-24 00:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:17:16 --> Input Class Initialized
INFO - 2018-03-24 00:17:16 --> Language Class Initialized
INFO - 2018-03-24 00:17:16 --> Loader Class Initialized
INFO - 2018-03-24 00:17:16 --> Helper loaded: url_helper
INFO - 2018-03-24 00:17:16 --> Helper loaded: form_helper
INFO - 2018-03-24 00:17:16 --> Database Driver Class Initialized
DEBUG - 2018-03-24 00:17:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 00:17:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 00:17:16 --> Form Validation Class Initialized
INFO - 2018-03-24 00:17:16 --> Model Class Initialized
INFO - 2018-03-24 00:17:16 --> Controller Class Initialized
INFO - 2018-03-24 00:17:16 --> Model Class Initialized
INFO - 2018-03-24 00:17:16 --> Model Class Initialized
INFO - 2018-03-24 00:17:16 --> Model Class Initialized
INFO - 2018-03-24 00:17:16 --> Model Class Initialized
DEBUG - 2018-03-24 00:17:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 00:17:21 --> Config Class Initialized
INFO - 2018-03-24 00:17:21 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:17:21 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:17:21 --> Utf8 Class Initialized
INFO - 2018-03-24 00:17:21 --> URI Class Initialized
INFO - 2018-03-24 00:17:21 --> Router Class Initialized
INFO - 2018-03-24 00:17:21 --> Output Class Initialized
INFO - 2018-03-24 00:17:21 --> Security Class Initialized
DEBUG - 2018-03-24 00:17:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:17:21 --> Input Class Initialized
INFO - 2018-03-24 00:17:21 --> Language Class Initialized
INFO - 2018-03-24 00:17:21 --> Loader Class Initialized
INFO - 2018-03-24 00:17:21 --> Helper loaded: url_helper
INFO - 2018-03-24 00:17:21 --> Helper loaded: form_helper
INFO - 2018-03-24 00:17:21 --> Database Driver Class Initialized
DEBUG - 2018-03-24 00:17:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 00:17:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 00:17:21 --> Form Validation Class Initialized
INFO - 2018-03-24 00:17:21 --> Model Class Initialized
INFO - 2018-03-24 00:17:21 --> Controller Class Initialized
INFO - 2018-03-24 00:17:21 --> Model Class Initialized
INFO - 2018-03-24 00:17:21 --> Model Class Initialized
INFO - 2018-03-24 00:17:21 --> Model Class Initialized
INFO - 2018-03-24 00:17:21 --> Model Class Initialized
DEBUG - 2018-03-24 00:17:21 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-03-24 00:17:21 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1724
ERROR - 2018-03-24 00:17:21 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1724
ERROR - 2018-03-24 00:17:21 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1724
INFO - 2018-03-24 00:22:43 --> Config Class Initialized
INFO - 2018-03-24 00:22:43 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:22:43 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:22:43 --> Utf8 Class Initialized
INFO - 2018-03-24 00:22:43 --> URI Class Initialized
INFO - 2018-03-24 00:22:43 --> Router Class Initialized
INFO - 2018-03-24 00:22:43 --> Output Class Initialized
INFO - 2018-03-24 00:22:43 --> Security Class Initialized
DEBUG - 2018-03-24 00:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:22:43 --> Input Class Initialized
INFO - 2018-03-24 00:22:43 --> Language Class Initialized
INFO - 2018-03-24 00:22:43 --> Loader Class Initialized
INFO - 2018-03-24 00:22:43 --> Helper loaded: url_helper
INFO - 2018-03-24 00:22:43 --> Helper loaded: form_helper
INFO - 2018-03-24 00:22:43 --> Database Driver Class Initialized
DEBUG - 2018-03-24 00:22:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 00:22:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 00:22:43 --> Form Validation Class Initialized
INFO - 2018-03-24 00:22:43 --> Model Class Initialized
INFO - 2018-03-24 00:22:43 --> Controller Class Initialized
INFO - 2018-03-24 00:22:43 --> Model Class Initialized
INFO - 2018-03-24 00:22:43 --> Model Class Initialized
INFO - 2018-03-24 00:22:43 --> Model Class Initialized
INFO - 2018-03-24 00:22:43 --> Model Class Initialized
DEBUG - 2018-03-24 00:22:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 00:22:43 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-24 00:22:43 --> Final output sent to browser
DEBUG - 2018-03-24 00:22:43 --> Total execution time: 0.0680
INFO - 2018-03-24 00:22:43 --> Config Class Initialized
INFO - 2018-03-24 00:22:43 --> Hooks Class Initialized
INFO - 2018-03-24 00:22:43 --> Config Class Initialized
INFO - 2018-03-24 00:22:43 --> Config Class Initialized
INFO - 2018-03-24 00:22:43 --> Hooks Class Initialized
INFO - 2018-03-24 00:22:43 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:22:43 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:22:43 --> Utf8 Class Initialized
INFO - 2018-03-24 00:22:43 --> Config Class Initialized
INFO - 2018-03-24 00:22:43 --> Hooks Class Initialized
INFO - 2018-03-24 00:22:43 --> URI Class Initialized
DEBUG - 2018-03-24 00:22:43 --> UTF-8 Support Enabled
DEBUG - 2018-03-24 00:22:43 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:22:43 --> Utf8 Class Initialized
INFO - 2018-03-24 00:22:43 --> Utf8 Class Initialized
INFO - 2018-03-24 00:22:43 --> Router Class Initialized
INFO - 2018-03-24 00:22:43 --> URI Class Initialized
INFO - 2018-03-24 00:22:43 --> URI Class Initialized
DEBUG - 2018-03-24 00:22:43 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:22:43 --> Utf8 Class Initialized
INFO - 2018-03-24 00:22:43 --> Router Class Initialized
INFO - 2018-03-24 00:22:43 --> URI Class Initialized
INFO - 2018-03-24 00:22:43 --> Router Class Initialized
INFO - 2018-03-24 00:22:43 --> Output Class Initialized
INFO - 2018-03-24 00:22:43 --> Output Class Initialized
INFO - 2018-03-24 00:22:43 --> Output Class Initialized
INFO - 2018-03-24 00:22:43 --> Router Class Initialized
INFO - 2018-03-24 00:22:43 --> Security Class Initialized
INFO - 2018-03-24 00:22:43 --> Security Class Initialized
INFO - 2018-03-24 00:22:43 --> Security Class Initialized
DEBUG - 2018-03-24 00:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:22:43 --> Output Class Initialized
DEBUG - 2018-03-24 00:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:22:43 --> Input Class Initialized
INFO - 2018-03-24 00:22:43 --> Input Class Initialized
DEBUG - 2018-03-24 00:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:22:43 --> Input Class Initialized
INFO - 2018-03-24 00:22:43 --> Language Class Initialized
INFO - 2018-03-24 00:22:43 --> Language Class Initialized
INFO - 2018-03-24 00:22:43 --> Security Class Initialized
INFO - 2018-03-24 00:22:43 --> Language Class Initialized
ERROR - 2018-03-24 00:22:43 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-24 00:22:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-03-24 00:22:43 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-24 00:22:43 --> Input Class Initialized
ERROR - 2018-03-24 00:22:43 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-24 00:22:43 --> Language Class Initialized
ERROR - 2018-03-24 00:22:43 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-24 00:22:44 --> Config Class Initialized
INFO - 2018-03-24 00:22:44 --> Hooks Class Initialized
INFO - 2018-03-24 00:22:44 --> Config Class Initialized
INFO - 2018-03-24 00:22:44 --> Config Class Initialized
INFO - 2018-03-24 00:22:44 --> Hooks Class Initialized
INFO - 2018-03-24 00:22:44 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:22:44 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:22:44 --> Utf8 Class Initialized
DEBUG - 2018-03-24 00:22:44 --> UTF-8 Support Enabled
DEBUG - 2018-03-24 00:22:44 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:22:44 --> Utf8 Class Initialized
INFO - 2018-03-24 00:22:44 --> Utf8 Class Initialized
INFO - 2018-03-24 00:22:44 --> URI Class Initialized
INFO - 2018-03-24 00:22:44 --> URI Class Initialized
INFO - 2018-03-24 00:22:44 --> URI Class Initialized
INFO - 2018-03-24 00:22:44 --> Router Class Initialized
INFO - 2018-03-24 00:22:44 --> Router Class Initialized
INFO - 2018-03-24 00:22:44 --> Output Class Initialized
INFO - 2018-03-24 00:22:44 --> Router Class Initialized
INFO - 2018-03-24 00:22:44 --> Output Class Initialized
INFO - 2018-03-24 00:22:44 --> Security Class Initialized
INFO - 2018-03-24 00:22:44 --> Output Class Initialized
DEBUG - 2018-03-24 00:22:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:22:44 --> Security Class Initialized
INFO - 2018-03-24 00:22:44 --> Input Class Initialized
INFO - 2018-03-24 00:22:44 --> Security Class Initialized
INFO - 2018-03-24 00:22:44 --> Language Class Initialized
DEBUG - 2018-03-24 00:22:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:22:44 --> Input Class Initialized
DEBUG - 2018-03-24 00:22:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:22:44 --> Input Class Initialized
ERROR - 2018-03-24 00:22:44 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-24 00:22:44 --> Language Class Initialized
INFO - 2018-03-24 00:22:44 --> Language Class Initialized
ERROR - 2018-03-24 00:22:44 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-24 00:22:44 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-24 00:22:44 --> Config Class Initialized
INFO - 2018-03-24 00:22:44 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:22:44 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:22:44 --> Utf8 Class Initialized
INFO - 2018-03-24 00:22:44 --> URI Class Initialized
INFO - 2018-03-24 00:22:44 --> Router Class Initialized
INFO - 2018-03-24 00:22:44 --> Output Class Initialized
INFO - 2018-03-24 00:22:44 --> Security Class Initialized
DEBUG - 2018-03-24 00:22:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:22:44 --> Input Class Initialized
INFO - 2018-03-24 00:22:44 --> Language Class Initialized
INFO - 2018-03-24 00:22:44 --> Loader Class Initialized
INFO - 2018-03-24 00:22:44 --> Helper loaded: url_helper
INFO - 2018-03-24 00:22:44 --> Helper loaded: form_helper
INFO - 2018-03-24 00:22:44 --> Database Driver Class Initialized
DEBUG - 2018-03-24 00:22:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 00:22:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 00:22:44 --> Form Validation Class Initialized
INFO - 2018-03-24 00:22:44 --> Model Class Initialized
INFO - 2018-03-24 00:22:44 --> Controller Class Initialized
INFO - 2018-03-24 00:22:44 --> Model Class Initialized
INFO - 2018-03-24 00:22:44 --> Model Class Initialized
INFO - 2018-03-24 00:22:44 --> Model Class Initialized
INFO - 2018-03-24 00:22:44 --> Model Class Initialized
DEBUG - 2018-03-24 00:22:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 00:22:49 --> Config Class Initialized
INFO - 2018-03-24 00:22:49 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:22:49 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:22:49 --> Utf8 Class Initialized
INFO - 2018-03-24 00:22:49 --> URI Class Initialized
INFO - 2018-03-24 00:22:49 --> Router Class Initialized
INFO - 2018-03-24 00:22:49 --> Output Class Initialized
INFO - 2018-03-24 00:22:49 --> Security Class Initialized
DEBUG - 2018-03-24 00:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:22:49 --> Input Class Initialized
INFO - 2018-03-24 00:22:49 --> Language Class Initialized
INFO - 2018-03-24 00:22:49 --> Loader Class Initialized
INFO - 2018-03-24 00:22:49 --> Helper loaded: url_helper
INFO - 2018-03-24 00:22:49 --> Helper loaded: form_helper
INFO - 2018-03-24 00:22:49 --> Database Driver Class Initialized
DEBUG - 2018-03-24 00:22:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 00:22:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 00:22:49 --> Form Validation Class Initialized
INFO - 2018-03-24 00:22:49 --> Model Class Initialized
INFO - 2018-03-24 00:22:49 --> Controller Class Initialized
INFO - 2018-03-24 00:22:49 --> Model Class Initialized
INFO - 2018-03-24 00:22:49 --> Model Class Initialized
INFO - 2018-03-24 00:22:49 --> Model Class Initialized
INFO - 2018-03-24 00:22:49 --> Model Class Initialized
DEBUG - 2018-03-24 00:22:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 00:25:14 --> Config Class Initialized
INFO - 2018-03-24 00:25:14 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:25:14 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:25:14 --> Utf8 Class Initialized
INFO - 2018-03-24 00:25:14 --> URI Class Initialized
INFO - 2018-03-24 00:25:14 --> Router Class Initialized
INFO - 2018-03-24 00:25:14 --> Output Class Initialized
INFO - 2018-03-24 00:25:14 --> Security Class Initialized
DEBUG - 2018-03-24 00:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:25:14 --> Input Class Initialized
INFO - 2018-03-24 00:25:14 --> Language Class Initialized
INFO - 2018-03-24 00:25:14 --> Loader Class Initialized
INFO - 2018-03-24 00:25:14 --> Helper loaded: url_helper
INFO - 2018-03-24 00:25:14 --> Helper loaded: form_helper
INFO - 2018-03-24 00:25:14 --> Database Driver Class Initialized
DEBUG - 2018-03-24 00:25:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 00:25:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 00:25:14 --> Form Validation Class Initialized
INFO - 2018-03-24 00:25:14 --> Model Class Initialized
INFO - 2018-03-24 00:25:14 --> Controller Class Initialized
INFO - 2018-03-24 00:25:14 --> Model Class Initialized
INFO - 2018-03-24 00:25:14 --> Model Class Initialized
INFO - 2018-03-24 00:25:14 --> Model Class Initialized
INFO - 2018-03-24 00:25:14 --> Model Class Initialized
DEBUG - 2018-03-24 00:25:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 00:25:14 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-24 00:25:14 --> Final output sent to browser
DEBUG - 2018-03-24 00:25:14 --> Total execution time: 0.1415
INFO - 2018-03-24 00:25:14 --> Config Class Initialized
INFO - 2018-03-24 00:25:14 --> Config Class Initialized
INFO - 2018-03-24 00:25:14 --> Hooks Class Initialized
INFO - 2018-03-24 00:25:14 --> Config Class Initialized
INFO - 2018-03-24 00:25:14 --> Hooks Class Initialized
INFO - 2018-03-24 00:25:14 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:25:14 --> UTF-8 Support Enabled
DEBUG - 2018-03-24 00:25:14 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:25:14 --> Utf8 Class Initialized
INFO - 2018-03-24 00:25:14 --> Config Class Initialized
DEBUG - 2018-03-24 00:25:14 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:25:14 --> Utf8 Class Initialized
INFO - 2018-03-24 00:25:14 --> Hooks Class Initialized
INFO - 2018-03-24 00:25:14 --> Utf8 Class Initialized
INFO - 2018-03-24 00:25:14 --> URI Class Initialized
INFO - 2018-03-24 00:25:14 --> URI Class Initialized
INFO - 2018-03-24 00:25:14 --> URI Class Initialized
DEBUG - 2018-03-24 00:25:14 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:25:14 --> Router Class Initialized
INFO - 2018-03-24 00:25:14 --> Router Class Initialized
INFO - 2018-03-24 00:25:14 --> Utf8 Class Initialized
INFO - 2018-03-24 00:25:14 --> Router Class Initialized
INFO - 2018-03-24 00:25:14 --> Output Class Initialized
INFO - 2018-03-24 00:25:14 --> URI Class Initialized
INFO - 2018-03-24 00:25:14 --> Output Class Initialized
INFO - 2018-03-24 00:25:14 --> Output Class Initialized
INFO - 2018-03-24 00:25:14 --> Security Class Initialized
INFO - 2018-03-24 00:25:14 --> Security Class Initialized
INFO - 2018-03-24 00:25:14 --> Router Class Initialized
INFO - 2018-03-24 00:25:14 --> Security Class Initialized
DEBUG - 2018-03-24 00:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:25:14 --> Input Class Initialized
DEBUG - 2018-03-24 00:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:25:14 --> Input Class Initialized
INFO - 2018-03-24 00:25:14 --> Output Class Initialized
DEBUG - 2018-03-24 00:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:25:14 --> Language Class Initialized
INFO - 2018-03-24 00:25:14 --> Language Class Initialized
INFO - 2018-03-24 00:25:14 --> Input Class Initialized
INFO - 2018-03-24 00:25:14 --> Language Class Initialized
ERROR - 2018-03-24 00:25:14 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-24 00:25:14 --> Security Class Initialized
ERROR - 2018-03-24 00:25:14 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-24 00:25:14 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-24 00:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:25:14 --> Input Class Initialized
INFO - 2018-03-24 00:25:14 --> Language Class Initialized
ERROR - 2018-03-24 00:25:14 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-24 00:25:14 --> Config Class Initialized
INFO - 2018-03-24 00:25:14 --> Hooks Class Initialized
INFO - 2018-03-24 00:25:14 --> Config Class Initialized
INFO - 2018-03-24 00:25:14 --> Config Class Initialized
INFO - 2018-03-24 00:25:14 --> Hooks Class Initialized
INFO - 2018-03-24 00:25:14 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:25:14 --> UTF-8 Support Enabled
DEBUG - 2018-03-24 00:25:14 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:25:14 --> Utf8 Class Initialized
INFO - 2018-03-24 00:25:14 --> Utf8 Class Initialized
DEBUG - 2018-03-24 00:25:14 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:25:14 --> Utf8 Class Initialized
INFO - 2018-03-24 00:25:14 --> URI Class Initialized
INFO - 2018-03-24 00:25:14 --> URI Class Initialized
INFO - 2018-03-24 00:25:14 --> URI Class Initialized
INFO - 2018-03-24 00:25:14 --> Router Class Initialized
INFO - 2018-03-24 00:25:14 --> Router Class Initialized
INFO - 2018-03-24 00:25:14 --> Router Class Initialized
INFO - 2018-03-24 00:25:14 --> Output Class Initialized
INFO - 2018-03-24 00:25:14 --> Output Class Initialized
INFO - 2018-03-24 00:25:14 --> Output Class Initialized
INFO - 2018-03-24 00:25:14 --> Security Class Initialized
INFO - 2018-03-24 00:25:14 --> Security Class Initialized
INFO - 2018-03-24 00:25:14 --> Security Class Initialized
DEBUG - 2018-03-24 00:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:25:14 --> Input Class Initialized
DEBUG - 2018-03-24 00:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:25:14 --> Input Class Initialized
DEBUG - 2018-03-24 00:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:25:14 --> Language Class Initialized
INFO - 2018-03-24 00:25:14 --> Input Class Initialized
INFO - 2018-03-24 00:25:14 --> Language Class Initialized
INFO - 2018-03-24 00:25:14 --> Language Class Initialized
ERROR - 2018-03-24 00:25:14 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-24 00:25:14 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-24 00:25:14 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-24 00:25:14 --> Config Class Initialized
INFO - 2018-03-24 00:25:14 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:25:14 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:25:14 --> Utf8 Class Initialized
INFO - 2018-03-24 00:25:14 --> URI Class Initialized
INFO - 2018-03-24 00:25:14 --> Router Class Initialized
INFO - 2018-03-24 00:25:14 --> Output Class Initialized
INFO - 2018-03-24 00:25:14 --> Security Class Initialized
DEBUG - 2018-03-24 00:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:25:14 --> Input Class Initialized
INFO - 2018-03-24 00:25:14 --> Language Class Initialized
INFO - 2018-03-24 00:25:14 --> Loader Class Initialized
INFO - 2018-03-24 00:25:14 --> Helper loaded: url_helper
INFO - 2018-03-24 00:25:14 --> Helper loaded: form_helper
INFO - 2018-03-24 00:25:14 --> Database Driver Class Initialized
DEBUG - 2018-03-24 00:25:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 00:25:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 00:25:14 --> Form Validation Class Initialized
INFO - 2018-03-24 00:25:14 --> Model Class Initialized
INFO - 2018-03-24 00:25:14 --> Controller Class Initialized
INFO - 2018-03-24 00:25:14 --> Model Class Initialized
INFO - 2018-03-24 00:25:14 --> Model Class Initialized
INFO - 2018-03-24 00:25:14 --> Model Class Initialized
INFO - 2018-03-24 00:25:14 --> Model Class Initialized
DEBUG - 2018-03-24 00:25:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 00:25:24 --> Config Class Initialized
INFO - 2018-03-24 00:25:24 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:25:24 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:25:24 --> Utf8 Class Initialized
INFO - 2018-03-24 00:25:24 --> URI Class Initialized
INFO - 2018-03-24 00:25:24 --> Router Class Initialized
INFO - 2018-03-24 00:25:24 --> Output Class Initialized
INFO - 2018-03-24 00:25:24 --> Security Class Initialized
DEBUG - 2018-03-24 00:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:25:24 --> Input Class Initialized
INFO - 2018-03-24 00:25:24 --> Language Class Initialized
INFO - 2018-03-24 00:25:24 --> Loader Class Initialized
INFO - 2018-03-24 00:25:24 --> Helper loaded: url_helper
INFO - 2018-03-24 00:25:24 --> Helper loaded: form_helper
INFO - 2018-03-24 00:25:24 --> Database Driver Class Initialized
DEBUG - 2018-03-24 00:25:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 00:25:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 00:25:24 --> Form Validation Class Initialized
INFO - 2018-03-24 00:25:24 --> Model Class Initialized
INFO - 2018-03-24 00:25:24 --> Controller Class Initialized
INFO - 2018-03-24 00:25:24 --> Model Class Initialized
INFO - 2018-03-24 00:25:24 --> Model Class Initialized
INFO - 2018-03-24 00:25:24 --> Model Class Initialized
INFO - 2018-03-24 00:25:24 --> Model Class Initialized
DEBUG - 2018-03-24 00:25:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 00:25:51 --> Config Class Initialized
INFO - 2018-03-24 00:25:51 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:25:51 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:25:51 --> Utf8 Class Initialized
INFO - 2018-03-24 00:25:51 --> URI Class Initialized
INFO - 2018-03-24 00:25:51 --> Router Class Initialized
INFO - 2018-03-24 00:25:51 --> Output Class Initialized
INFO - 2018-03-24 00:25:51 --> Security Class Initialized
DEBUG - 2018-03-24 00:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:25:51 --> Input Class Initialized
INFO - 2018-03-24 00:25:51 --> Language Class Initialized
INFO - 2018-03-24 00:25:51 --> Loader Class Initialized
INFO - 2018-03-24 00:25:51 --> Helper loaded: url_helper
INFO - 2018-03-24 00:25:51 --> Helper loaded: form_helper
INFO - 2018-03-24 00:25:51 --> Database Driver Class Initialized
DEBUG - 2018-03-24 00:25:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 00:25:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 00:25:51 --> Form Validation Class Initialized
INFO - 2018-03-24 00:25:51 --> Model Class Initialized
INFO - 2018-03-24 00:25:51 --> Controller Class Initialized
INFO - 2018-03-24 00:25:51 --> Model Class Initialized
INFO - 2018-03-24 00:25:51 --> Model Class Initialized
DEBUG - 2018-03-24 00:25:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 00:25:51 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-24 00:25:51 --> Final output sent to browser
DEBUG - 2018-03-24 00:25:51 --> Total execution time: 0.1031
INFO - 2018-03-24 00:25:51 --> Config Class Initialized
INFO - 2018-03-24 00:25:51 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:25:51 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:25:51 --> Utf8 Class Initialized
INFO - 2018-03-24 00:25:51 --> URI Class Initialized
INFO - 2018-03-24 00:25:51 --> Router Class Initialized
INFO - 2018-03-24 00:25:51 --> Output Class Initialized
INFO - 2018-03-24 00:25:51 --> Security Class Initialized
DEBUG - 2018-03-24 00:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:25:51 --> Input Class Initialized
INFO - 2018-03-24 00:25:51 --> Language Class Initialized
INFO - 2018-03-24 00:25:51 --> Loader Class Initialized
INFO - 2018-03-24 00:25:51 --> Helper loaded: url_helper
INFO - 2018-03-24 00:25:51 --> Helper loaded: form_helper
INFO - 2018-03-24 00:25:51 --> Database Driver Class Initialized
DEBUG - 2018-03-24 00:25:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 00:25:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 00:25:51 --> Form Validation Class Initialized
INFO - 2018-03-24 00:25:51 --> Model Class Initialized
INFO - 2018-03-24 00:25:51 --> Controller Class Initialized
INFO - 2018-03-24 00:25:51 --> Model Class Initialized
INFO - 2018-03-24 00:25:51 --> Model Class Initialized
DEBUG - 2018-03-24 00:25:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 00:25:56 --> Config Class Initialized
INFO - 2018-03-24 00:25:56 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:25:56 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:25:56 --> Utf8 Class Initialized
INFO - 2018-03-24 00:25:56 --> URI Class Initialized
INFO - 2018-03-24 00:25:56 --> Router Class Initialized
INFO - 2018-03-24 00:25:56 --> Output Class Initialized
INFO - 2018-03-24 00:25:56 --> Security Class Initialized
DEBUG - 2018-03-24 00:25:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:25:56 --> Input Class Initialized
INFO - 2018-03-24 00:25:56 --> Language Class Initialized
INFO - 2018-03-24 00:25:56 --> Loader Class Initialized
INFO - 2018-03-24 00:25:56 --> Helper loaded: url_helper
INFO - 2018-03-24 00:25:56 --> Helper loaded: form_helper
INFO - 2018-03-24 00:25:56 --> Database Driver Class Initialized
DEBUG - 2018-03-24 00:25:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 00:25:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 00:25:56 --> Form Validation Class Initialized
INFO - 2018-03-24 00:25:56 --> Model Class Initialized
INFO - 2018-03-24 00:25:56 --> Controller Class Initialized
INFO - 2018-03-24 00:25:56 --> Model Class Initialized
INFO - 2018-03-24 00:25:56 --> Model Class Initialized
DEBUG - 2018-03-24 00:25:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 00:25:56 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-24 00:25:56 --> Final output sent to browser
DEBUG - 2018-03-24 00:25:56 --> Total execution time: 0.1311
INFO - 2018-03-24 00:26:53 --> Config Class Initialized
INFO - 2018-03-24 00:26:53 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:26:53 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:26:53 --> Utf8 Class Initialized
INFO - 2018-03-24 00:26:53 --> URI Class Initialized
INFO - 2018-03-24 00:26:53 --> Router Class Initialized
INFO - 2018-03-24 00:26:53 --> Output Class Initialized
INFO - 2018-03-24 00:26:53 --> Security Class Initialized
DEBUG - 2018-03-24 00:26:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:26:53 --> Input Class Initialized
INFO - 2018-03-24 00:26:53 --> Language Class Initialized
INFO - 2018-03-24 00:26:53 --> Loader Class Initialized
INFO - 2018-03-24 00:26:53 --> Helper loaded: url_helper
INFO - 2018-03-24 00:26:53 --> Helper loaded: form_helper
INFO - 2018-03-24 00:26:53 --> Database Driver Class Initialized
DEBUG - 2018-03-24 00:26:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 00:26:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 00:26:53 --> Form Validation Class Initialized
INFO - 2018-03-24 00:26:53 --> Model Class Initialized
INFO - 2018-03-24 00:26:53 --> Controller Class Initialized
INFO - 2018-03-24 00:26:53 --> Model Class Initialized
INFO - 2018-03-24 00:26:53 --> Model Class Initialized
DEBUG - 2018-03-24 00:26:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 00:26:53 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-24 00:26:53 --> Final output sent to browser
DEBUG - 2018-03-24 00:26:53 --> Total execution time: 0.0925
INFO - 2018-03-24 00:26:53 --> Config Class Initialized
INFO - 2018-03-24 00:26:53 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:26:53 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:26:53 --> Utf8 Class Initialized
INFO - 2018-03-24 00:26:53 --> URI Class Initialized
INFO - 2018-03-24 00:26:53 --> Router Class Initialized
INFO - 2018-03-24 00:26:53 --> Output Class Initialized
INFO - 2018-03-24 00:26:53 --> Security Class Initialized
DEBUG - 2018-03-24 00:26:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:26:53 --> Input Class Initialized
INFO - 2018-03-24 00:26:53 --> Language Class Initialized
INFO - 2018-03-24 00:26:53 --> Loader Class Initialized
INFO - 2018-03-24 00:26:53 --> Helper loaded: url_helper
INFO - 2018-03-24 00:26:53 --> Helper loaded: form_helper
INFO - 2018-03-24 00:26:53 --> Database Driver Class Initialized
DEBUG - 2018-03-24 00:26:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 00:26:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 00:26:53 --> Form Validation Class Initialized
INFO - 2018-03-24 00:26:53 --> Model Class Initialized
INFO - 2018-03-24 00:26:53 --> Controller Class Initialized
INFO - 2018-03-24 00:26:53 --> Model Class Initialized
INFO - 2018-03-24 00:26:53 --> Model Class Initialized
DEBUG - 2018-03-24 00:26:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 00:26:58 --> Config Class Initialized
INFO - 2018-03-24 00:26:58 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:26:58 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:26:58 --> Utf8 Class Initialized
INFO - 2018-03-24 00:26:58 --> URI Class Initialized
INFO - 2018-03-24 00:26:58 --> Router Class Initialized
INFO - 2018-03-24 00:26:58 --> Output Class Initialized
INFO - 2018-03-24 00:26:58 --> Security Class Initialized
DEBUG - 2018-03-24 00:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:26:58 --> Input Class Initialized
INFO - 2018-03-24 00:26:58 --> Language Class Initialized
INFO - 2018-03-24 00:26:58 --> Loader Class Initialized
INFO - 2018-03-24 00:26:58 --> Helper loaded: url_helper
INFO - 2018-03-24 00:26:58 --> Helper loaded: form_helper
INFO - 2018-03-24 00:26:58 --> Database Driver Class Initialized
DEBUG - 2018-03-24 00:26:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 00:26:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 00:26:58 --> Form Validation Class Initialized
INFO - 2018-03-24 00:26:58 --> Model Class Initialized
INFO - 2018-03-24 00:26:58 --> Controller Class Initialized
INFO - 2018-03-24 00:26:58 --> Model Class Initialized
INFO - 2018-03-24 00:26:58 --> Model Class Initialized
DEBUG - 2018-03-24 00:26:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 00:26:58 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-24 00:26:58 --> Final output sent to browser
DEBUG - 2018-03-24 00:26:58 --> Total execution time: 0.0574
INFO - 2018-03-24 00:27:23 --> Config Class Initialized
INFO - 2018-03-24 00:27:23 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:27:23 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:27:23 --> Utf8 Class Initialized
INFO - 2018-03-24 00:27:23 --> URI Class Initialized
INFO - 2018-03-24 00:27:23 --> Router Class Initialized
INFO - 2018-03-24 00:27:23 --> Output Class Initialized
INFO - 2018-03-24 00:27:23 --> Security Class Initialized
DEBUG - 2018-03-24 00:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:27:23 --> Input Class Initialized
INFO - 2018-03-24 00:27:23 --> Language Class Initialized
INFO - 2018-03-24 00:27:23 --> Loader Class Initialized
INFO - 2018-03-24 00:27:23 --> Helper loaded: url_helper
INFO - 2018-03-24 00:27:23 --> Helper loaded: form_helper
INFO - 2018-03-24 00:27:23 --> Database Driver Class Initialized
DEBUG - 2018-03-24 00:27:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 00:27:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 00:27:23 --> Form Validation Class Initialized
INFO - 2018-03-24 00:27:23 --> Model Class Initialized
INFO - 2018-03-24 00:27:23 --> Controller Class Initialized
INFO - 2018-03-24 00:27:23 --> Model Class Initialized
INFO - 2018-03-24 00:27:23 --> Model Class Initialized
DEBUG - 2018-03-24 00:27:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 00:27:23 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-24 00:27:23 --> Final output sent to browser
DEBUG - 2018-03-24 00:27:23 --> Total execution time: 0.0826
INFO - 2018-03-24 00:27:23 --> Config Class Initialized
INFO - 2018-03-24 00:27:23 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:27:23 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:27:23 --> Utf8 Class Initialized
INFO - 2018-03-24 00:27:23 --> URI Class Initialized
INFO - 2018-03-24 00:27:23 --> Router Class Initialized
INFO - 2018-03-24 00:27:23 --> Output Class Initialized
INFO - 2018-03-24 00:27:23 --> Security Class Initialized
DEBUG - 2018-03-24 00:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:27:23 --> Input Class Initialized
INFO - 2018-03-24 00:27:23 --> Language Class Initialized
INFO - 2018-03-24 00:27:23 --> Loader Class Initialized
INFO - 2018-03-24 00:27:23 --> Helper loaded: url_helper
INFO - 2018-03-24 00:27:23 --> Helper loaded: form_helper
INFO - 2018-03-24 00:27:23 --> Database Driver Class Initialized
DEBUG - 2018-03-24 00:27:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 00:27:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 00:27:23 --> Form Validation Class Initialized
INFO - 2018-03-24 00:27:23 --> Model Class Initialized
INFO - 2018-03-24 00:27:23 --> Controller Class Initialized
INFO - 2018-03-24 00:27:23 --> Model Class Initialized
INFO - 2018-03-24 00:27:23 --> Model Class Initialized
DEBUG - 2018-03-24 00:27:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 00:27:33 --> Config Class Initialized
INFO - 2018-03-24 00:27:33 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:27:33 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:27:33 --> Utf8 Class Initialized
INFO - 2018-03-24 00:27:33 --> URI Class Initialized
INFO - 2018-03-24 00:27:33 --> Router Class Initialized
INFO - 2018-03-24 00:27:33 --> Output Class Initialized
INFO - 2018-03-24 00:27:33 --> Security Class Initialized
DEBUG - 2018-03-24 00:27:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:27:33 --> Input Class Initialized
INFO - 2018-03-24 00:27:33 --> Language Class Initialized
INFO - 2018-03-24 00:27:33 --> Loader Class Initialized
INFO - 2018-03-24 00:27:33 --> Helper loaded: url_helper
INFO - 2018-03-24 00:27:33 --> Helper loaded: form_helper
INFO - 2018-03-24 00:27:33 --> Database Driver Class Initialized
DEBUG - 2018-03-24 00:27:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 00:27:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 00:27:33 --> Form Validation Class Initialized
INFO - 2018-03-24 00:27:33 --> Model Class Initialized
INFO - 2018-03-24 00:27:33 --> Controller Class Initialized
INFO - 2018-03-24 00:27:33 --> Model Class Initialized
INFO - 2018-03-24 00:27:33 --> Model Class Initialized
DEBUG - 2018-03-24 00:27:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 00:27:33 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-24 00:27:33 --> Final output sent to browser
DEBUG - 2018-03-24 00:27:33 --> Total execution time: 0.0847
INFO - 2018-03-24 00:41:32 --> Config Class Initialized
INFO - 2018-03-24 00:41:32 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:41:32 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:41:32 --> Utf8 Class Initialized
INFO - 2018-03-24 00:41:32 --> URI Class Initialized
INFO - 2018-03-24 00:41:32 --> Router Class Initialized
INFO - 2018-03-24 00:41:32 --> Output Class Initialized
INFO - 2018-03-24 00:41:32 --> Security Class Initialized
DEBUG - 2018-03-24 00:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:41:32 --> Input Class Initialized
INFO - 2018-03-24 00:41:32 --> Language Class Initialized
INFO - 2018-03-24 00:41:32 --> Loader Class Initialized
INFO - 2018-03-24 00:41:32 --> Helper loaded: url_helper
INFO - 2018-03-24 00:41:32 --> Helper loaded: form_helper
INFO - 2018-03-24 00:41:32 --> Database Driver Class Initialized
DEBUG - 2018-03-24 00:41:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 00:41:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 00:41:32 --> Form Validation Class Initialized
INFO - 2018-03-24 00:41:32 --> Model Class Initialized
INFO - 2018-03-24 00:41:32 --> Controller Class Initialized
INFO - 2018-03-24 00:41:32 --> Model Class Initialized
INFO - 2018-03-24 00:41:32 --> Model Class Initialized
INFO - 2018-03-24 00:41:32 --> Model Class Initialized
INFO - 2018-03-24 00:41:32 --> Model Class Initialized
DEBUG - 2018-03-24 00:41:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 00:41:32 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-24 00:41:32 --> Final output sent to browser
DEBUG - 2018-03-24 00:41:32 --> Total execution time: 0.0670
INFO - 2018-03-24 00:41:33 --> Config Class Initialized
INFO - 2018-03-24 00:41:33 --> Hooks Class Initialized
INFO - 2018-03-24 00:41:33 --> Config Class Initialized
INFO - 2018-03-24 00:41:33 --> Hooks Class Initialized
INFO - 2018-03-24 00:41:33 --> Config Class Initialized
INFO - 2018-03-24 00:41:33 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:41:33 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:41:33 --> Utf8 Class Initialized
DEBUG - 2018-03-24 00:41:33 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:41:33 --> Utf8 Class Initialized
INFO - 2018-03-24 00:41:33 --> Config Class Initialized
DEBUG - 2018-03-24 00:41:33 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:41:33 --> Hooks Class Initialized
INFO - 2018-03-24 00:41:33 --> Utf8 Class Initialized
INFO - 2018-03-24 00:41:33 --> URI Class Initialized
INFO - 2018-03-24 00:41:33 --> URI Class Initialized
INFO - 2018-03-24 00:41:33 --> URI Class Initialized
INFO - 2018-03-24 00:41:33 --> Router Class Initialized
INFO - 2018-03-24 00:41:33 --> Router Class Initialized
DEBUG - 2018-03-24 00:41:33 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:41:33 --> Utf8 Class Initialized
INFO - 2018-03-24 00:41:33 --> Router Class Initialized
INFO - 2018-03-24 00:41:33 --> Output Class Initialized
INFO - 2018-03-24 00:41:33 --> URI Class Initialized
INFO - 2018-03-24 00:41:33 --> Output Class Initialized
INFO - 2018-03-24 00:41:33 --> Output Class Initialized
INFO - 2018-03-24 00:41:33 --> Security Class Initialized
INFO - 2018-03-24 00:41:33 --> Security Class Initialized
INFO - 2018-03-24 00:41:33 --> Router Class Initialized
INFO - 2018-03-24 00:41:33 --> Security Class Initialized
DEBUG - 2018-03-24 00:41:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:41:33 --> Input Class Initialized
DEBUG - 2018-03-24 00:41:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:41:33 --> Input Class Initialized
INFO - 2018-03-24 00:41:33 --> Output Class Initialized
DEBUG - 2018-03-24 00:41:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:41:33 --> Language Class Initialized
INFO - 2018-03-24 00:41:33 --> Input Class Initialized
INFO - 2018-03-24 00:41:33 --> Language Class Initialized
INFO - 2018-03-24 00:41:33 --> Security Class Initialized
INFO - 2018-03-24 00:41:33 --> Language Class Initialized
ERROR - 2018-03-24 00:41:33 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-24 00:41:33 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-24 00:41:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-03-24 00:41:33 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-24 00:41:33 --> Input Class Initialized
INFO - 2018-03-24 00:41:33 --> Language Class Initialized
ERROR - 2018-03-24 00:41:33 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-24 00:41:33 --> Config Class Initialized
INFO - 2018-03-24 00:41:33 --> Config Class Initialized
INFO - 2018-03-24 00:41:33 --> Hooks Class Initialized
INFO - 2018-03-24 00:41:33 --> Hooks Class Initialized
INFO - 2018-03-24 00:41:33 --> Config Class Initialized
INFO - 2018-03-24 00:41:33 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:41:33 --> UTF-8 Support Enabled
DEBUG - 2018-03-24 00:41:33 --> UTF-8 Support Enabled
DEBUG - 2018-03-24 00:41:33 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:41:33 --> Utf8 Class Initialized
INFO - 2018-03-24 00:41:33 --> Utf8 Class Initialized
INFO - 2018-03-24 00:41:33 --> Utf8 Class Initialized
INFO - 2018-03-24 00:41:33 --> URI Class Initialized
INFO - 2018-03-24 00:41:33 --> URI Class Initialized
INFO - 2018-03-24 00:41:33 --> URI Class Initialized
INFO - 2018-03-24 00:41:33 --> Router Class Initialized
INFO - 2018-03-24 00:41:33 --> Router Class Initialized
INFO - 2018-03-24 00:41:33 --> Router Class Initialized
INFO - 2018-03-24 00:41:33 --> Output Class Initialized
INFO - 2018-03-24 00:41:33 --> Output Class Initialized
INFO - 2018-03-24 00:41:33 --> Output Class Initialized
INFO - 2018-03-24 00:41:33 --> Security Class Initialized
INFO - 2018-03-24 00:41:33 --> Security Class Initialized
DEBUG - 2018-03-24 00:41:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:41:33 --> Security Class Initialized
INFO - 2018-03-24 00:41:33 --> Input Class Initialized
DEBUG - 2018-03-24 00:41:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:41:33 --> Input Class Initialized
INFO - 2018-03-24 00:41:33 --> Language Class Initialized
DEBUG - 2018-03-24 00:41:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:41:33 --> Input Class Initialized
INFO - 2018-03-24 00:41:33 --> Language Class Initialized
ERROR - 2018-03-24 00:41:33 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-24 00:41:33 --> Language Class Initialized
ERROR - 2018-03-24 00:41:33 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-24 00:41:33 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-24 00:41:33 --> Config Class Initialized
INFO - 2018-03-24 00:41:33 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:41:33 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:41:33 --> Utf8 Class Initialized
INFO - 2018-03-24 00:41:33 --> URI Class Initialized
INFO - 2018-03-24 00:41:33 --> Router Class Initialized
INFO - 2018-03-24 00:41:33 --> Output Class Initialized
INFO - 2018-03-24 00:41:33 --> Security Class Initialized
DEBUG - 2018-03-24 00:41:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:41:33 --> Input Class Initialized
INFO - 2018-03-24 00:41:33 --> Language Class Initialized
INFO - 2018-03-24 00:41:33 --> Loader Class Initialized
INFO - 2018-03-24 00:41:33 --> Helper loaded: url_helper
INFO - 2018-03-24 00:41:33 --> Helper loaded: form_helper
INFO - 2018-03-24 00:41:33 --> Database Driver Class Initialized
DEBUG - 2018-03-24 00:41:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 00:41:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 00:41:33 --> Form Validation Class Initialized
INFO - 2018-03-24 00:41:33 --> Model Class Initialized
INFO - 2018-03-24 00:41:33 --> Controller Class Initialized
INFO - 2018-03-24 00:41:33 --> Model Class Initialized
INFO - 2018-03-24 00:41:33 --> Model Class Initialized
INFO - 2018-03-24 00:41:33 --> Model Class Initialized
INFO - 2018-03-24 00:41:33 --> Model Class Initialized
DEBUG - 2018-03-24 00:41:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 00:41:38 --> Config Class Initialized
INFO - 2018-03-24 00:41:38 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:41:38 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:41:38 --> Utf8 Class Initialized
INFO - 2018-03-24 00:41:38 --> URI Class Initialized
INFO - 2018-03-24 00:41:38 --> Router Class Initialized
INFO - 2018-03-24 00:41:38 --> Output Class Initialized
INFO - 2018-03-24 00:41:38 --> Security Class Initialized
DEBUG - 2018-03-24 00:41:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:41:38 --> Input Class Initialized
INFO - 2018-03-24 00:41:38 --> Language Class Initialized
INFO - 2018-03-24 00:41:38 --> Loader Class Initialized
INFO - 2018-03-24 00:41:38 --> Helper loaded: url_helper
INFO - 2018-03-24 00:41:38 --> Helper loaded: form_helper
INFO - 2018-03-24 00:41:38 --> Database Driver Class Initialized
DEBUG - 2018-03-24 00:41:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 00:41:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 00:41:38 --> Form Validation Class Initialized
INFO - 2018-03-24 00:41:38 --> Model Class Initialized
INFO - 2018-03-24 00:41:38 --> Controller Class Initialized
INFO - 2018-03-24 00:41:38 --> Model Class Initialized
INFO - 2018-03-24 00:41:38 --> Model Class Initialized
INFO - 2018-03-24 00:41:38 --> Model Class Initialized
INFO - 2018-03-24 00:41:38 --> Model Class Initialized
DEBUG - 2018-03-24 00:41:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 00:41:43 --> Config Class Initialized
INFO - 2018-03-24 00:41:43 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:41:43 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:41:43 --> Utf8 Class Initialized
INFO - 2018-03-24 00:41:43 --> URI Class Initialized
INFO - 2018-03-24 00:41:43 --> Router Class Initialized
INFO - 2018-03-24 00:41:43 --> Output Class Initialized
INFO - 2018-03-24 00:41:43 --> Security Class Initialized
DEBUG - 2018-03-24 00:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:41:43 --> Input Class Initialized
INFO - 2018-03-24 00:41:43 --> Language Class Initialized
INFO - 2018-03-24 00:41:43 --> Loader Class Initialized
INFO - 2018-03-24 00:41:43 --> Helper loaded: url_helper
INFO - 2018-03-24 00:41:43 --> Helper loaded: form_helper
INFO - 2018-03-24 00:41:43 --> Database Driver Class Initialized
DEBUG - 2018-03-24 00:41:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 00:41:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 00:41:43 --> Form Validation Class Initialized
INFO - 2018-03-24 00:41:43 --> Model Class Initialized
INFO - 2018-03-24 00:41:43 --> Controller Class Initialized
INFO - 2018-03-24 00:41:43 --> Model Class Initialized
INFO - 2018-03-24 00:41:43 --> Model Class Initialized
INFO - 2018-03-24 00:41:43 --> Model Class Initialized
INFO - 2018-03-24 00:41:43 --> Model Class Initialized
DEBUG - 2018-03-24 00:41:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 00:41:43 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-24 00:41:43 --> Final output sent to browser
DEBUG - 2018-03-24 00:41:43 --> Total execution time: 0.1077
INFO - 2018-03-24 00:41:43 --> Config Class Initialized
INFO - 2018-03-24 00:41:43 --> Hooks Class Initialized
INFO - 2018-03-24 00:41:43 --> Config Class Initialized
INFO - 2018-03-24 00:41:43 --> Config Class Initialized
INFO - 2018-03-24 00:41:43 --> Hooks Class Initialized
INFO - 2018-03-24 00:41:43 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:41:43 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:41:43 --> Utf8 Class Initialized
DEBUG - 2018-03-24 00:41:43 --> UTF-8 Support Enabled
DEBUG - 2018-03-24 00:41:43 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:41:43 --> Utf8 Class Initialized
INFO - 2018-03-24 00:41:43 --> Utf8 Class Initialized
INFO - 2018-03-24 00:41:43 --> URI Class Initialized
INFO - 2018-03-24 00:41:43 --> URI Class Initialized
INFO - 2018-03-24 00:41:43 --> URI Class Initialized
INFO - 2018-03-24 00:41:43 --> Router Class Initialized
INFO - 2018-03-24 00:41:43 --> Router Class Initialized
INFO - 2018-03-24 00:41:43 --> Router Class Initialized
INFO - 2018-03-24 00:41:43 --> Output Class Initialized
INFO - 2018-03-24 00:41:43 --> Output Class Initialized
INFO - 2018-03-24 00:41:43 --> Output Class Initialized
INFO - 2018-03-24 00:41:43 --> Security Class Initialized
INFO - 2018-03-24 00:41:43 --> Security Class Initialized
INFO - 2018-03-24 00:41:43 --> Security Class Initialized
DEBUG - 2018-03-24 00:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:41:43 --> Input Class Initialized
DEBUG - 2018-03-24 00:41:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-24 00:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:41:43 --> Input Class Initialized
INFO - 2018-03-24 00:41:43 --> Language Class Initialized
INFO - 2018-03-24 00:41:43 --> Input Class Initialized
INFO - 2018-03-24 00:41:43 --> Language Class Initialized
INFO - 2018-03-24 00:41:43 --> Language Class Initialized
ERROR - 2018-03-24 00:41:43 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-24 00:41:43 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-24 00:41:43 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-24 00:41:43 --> Config Class Initialized
INFO - 2018-03-24 00:41:43 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:41:43 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:41:43 --> Utf8 Class Initialized
INFO - 2018-03-24 00:41:43 --> URI Class Initialized
INFO - 2018-03-24 00:41:43 --> Router Class Initialized
INFO - 2018-03-24 00:41:43 --> Output Class Initialized
INFO - 2018-03-24 00:41:43 --> Security Class Initialized
DEBUG - 2018-03-24 00:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:41:43 --> Input Class Initialized
INFO - 2018-03-24 00:41:43 --> Language Class Initialized
ERROR - 2018-03-24 00:41:43 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-24 00:41:43 --> Config Class Initialized
INFO - 2018-03-24 00:41:43 --> Config Class Initialized
INFO - 2018-03-24 00:41:43 --> Hooks Class Initialized
INFO - 2018-03-24 00:41:43 --> Hooks Class Initialized
INFO - 2018-03-24 00:41:43 --> Config Class Initialized
INFO - 2018-03-24 00:41:43 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:41:43 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:41:43 --> Utf8 Class Initialized
DEBUG - 2018-03-24 00:41:43 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:41:43 --> Utf8 Class Initialized
DEBUG - 2018-03-24 00:41:43 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:41:43 --> URI Class Initialized
INFO - 2018-03-24 00:41:43 --> Utf8 Class Initialized
INFO - 2018-03-24 00:41:43 --> URI Class Initialized
INFO - 2018-03-24 00:41:43 --> URI Class Initialized
INFO - 2018-03-24 00:41:43 --> Router Class Initialized
INFO - 2018-03-24 00:41:43 --> Router Class Initialized
INFO - 2018-03-24 00:41:43 --> Output Class Initialized
INFO - 2018-03-24 00:41:43 --> Router Class Initialized
INFO - 2018-03-24 00:41:43 --> Output Class Initialized
INFO - 2018-03-24 00:41:43 --> Security Class Initialized
INFO - 2018-03-24 00:41:43 --> Security Class Initialized
INFO - 2018-03-24 00:41:43 --> Output Class Initialized
DEBUG - 2018-03-24 00:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:41:43 --> Input Class Initialized
DEBUG - 2018-03-24 00:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:41:43 --> Input Class Initialized
INFO - 2018-03-24 00:41:43 --> Language Class Initialized
INFO - 2018-03-24 00:41:43 --> Security Class Initialized
INFO - 2018-03-24 00:41:43 --> Language Class Initialized
ERROR - 2018-03-24 00:41:43 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-03-24 00:41:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-03-24 00:41:43 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-24 00:41:43 --> Input Class Initialized
INFO - 2018-03-24 00:41:43 --> Language Class Initialized
ERROR - 2018-03-24 00:41:43 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-24 00:41:43 --> Config Class Initialized
INFO - 2018-03-24 00:41:43 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:41:43 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:41:43 --> Utf8 Class Initialized
INFO - 2018-03-24 00:41:43 --> URI Class Initialized
INFO - 2018-03-24 00:41:43 --> Router Class Initialized
INFO - 2018-03-24 00:41:44 --> Output Class Initialized
INFO - 2018-03-24 00:41:44 --> Security Class Initialized
DEBUG - 2018-03-24 00:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:41:44 --> Input Class Initialized
INFO - 2018-03-24 00:41:44 --> Language Class Initialized
INFO - 2018-03-24 00:41:44 --> Loader Class Initialized
INFO - 2018-03-24 00:41:44 --> Helper loaded: url_helper
INFO - 2018-03-24 00:41:44 --> Helper loaded: form_helper
INFO - 2018-03-24 00:41:44 --> Database Driver Class Initialized
DEBUG - 2018-03-24 00:41:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 00:41:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 00:41:44 --> Form Validation Class Initialized
INFO - 2018-03-24 00:41:44 --> Model Class Initialized
INFO - 2018-03-24 00:41:44 --> Controller Class Initialized
INFO - 2018-03-24 00:41:44 --> Model Class Initialized
INFO - 2018-03-24 00:41:44 --> Model Class Initialized
INFO - 2018-03-24 00:41:44 --> Model Class Initialized
INFO - 2018-03-24 00:41:44 --> Model Class Initialized
DEBUG - 2018-03-24 00:41:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 00:41:47 --> Config Class Initialized
INFO - 2018-03-24 00:41:47 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:41:48 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:41:48 --> Utf8 Class Initialized
INFO - 2018-03-24 00:41:48 --> URI Class Initialized
INFO - 2018-03-24 00:41:48 --> Router Class Initialized
INFO - 2018-03-24 00:41:48 --> Output Class Initialized
INFO - 2018-03-24 00:41:48 --> Security Class Initialized
DEBUG - 2018-03-24 00:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:41:48 --> Input Class Initialized
INFO - 2018-03-24 00:41:48 --> Language Class Initialized
INFO - 2018-03-24 00:41:48 --> Loader Class Initialized
INFO - 2018-03-24 00:41:48 --> Helper loaded: url_helper
INFO - 2018-03-24 00:41:48 --> Helper loaded: form_helper
INFO - 2018-03-24 00:41:48 --> Database Driver Class Initialized
DEBUG - 2018-03-24 00:41:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 00:41:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 00:41:48 --> Form Validation Class Initialized
INFO - 2018-03-24 00:41:48 --> Model Class Initialized
INFO - 2018-03-24 00:41:48 --> Controller Class Initialized
INFO - 2018-03-24 00:41:48 --> Model Class Initialized
INFO - 2018-03-24 00:41:48 --> Model Class Initialized
INFO - 2018-03-24 00:41:48 --> Model Class Initialized
INFO - 2018-03-24 00:41:48 --> Model Class Initialized
DEBUG - 2018-03-24 00:41:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 00:41:57 --> Config Class Initialized
INFO - 2018-03-24 00:41:57 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:41:57 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:41:57 --> Utf8 Class Initialized
INFO - 2018-03-24 00:41:57 --> URI Class Initialized
INFO - 2018-03-24 00:41:57 --> Router Class Initialized
INFO - 2018-03-24 00:41:57 --> Output Class Initialized
INFO - 2018-03-24 00:41:57 --> Security Class Initialized
DEBUG - 2018-03-24 00:41:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:41:57 --> Input Class Initialized
INFO - 2018-03-24 00:41:57 --> Language Class Initialized
INFO - 2018-03-24 00:41:57 --> Loader Class Initialized
INFO - 2018-03-24 00:41:57 --> Helper loaded: url_helper
INFO - 2018-03-24 00:41:57 --> Helper loaded: form_helper
INFO - 2018-03-24 00:41:57 --> Database Driver Class Initialized
DEBUG - 2018-03-24 00:41:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 00:41:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 00:41:57 --> Form Validation Class Initialized
INFO - 2018-03-24 00:41:57 --> Model Class Initialized
INFO - 2018-03-24 00:41:57 --> Controller Class Initialized
INFO - 2018-03-24 00:41:57 --> Model Class Initialized
INFO - 2018-03-24 00:41:57 --> Model Class Initialized
INFO - 2018-03-24 00:41:57 --> Model Class Initialized
INFO - 2018-03-24 00:41:57 --> Model Class Initialized
DEBUG - 2018-03-24 00:41:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 00:42:02 --> Config Class Initialized
INFO - 2018-03-24 00:42:02 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:42:02 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:42:02 --> Utf8 Class Initialized
INFO - 2018-03-24 00:42:02 --> URI Class Initialized
INFO - 2018-03-24 00:42:02 --> Router Class Initialized
INFO - 2018-03-24 00:42:02 --> Output Class Initialized
INFO - 2018-03-24 00:42:02 --> Security Class Initialized
DEBUG - 2018-03-24 00:42:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:42:02 --> Input Class Initialized
INFO - 2018-03-24 00:42:02 --> Language Class Initialized
INFO - 2018-03-24 00:42:02 --> Loader Class Initialized
INFO - 2018-03-24 00:42:02 --> Helper loaded: url_helper
INFO - 2018-03-24 00:42:02 --> Helper loaded: form_helper
INFO - 2018-03-24 00:42:02 --> Database Driver Class Initialized
DEBUG - 2018-03-24 00:42:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 00:42:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 00:42:02 --> Form Validation Class Initialized
INFO - 2018-03-24 00:42:02 --> Model Class Initialized
INFO - 2018-03-24 00:42:02 --> Controller Class Initialized
INFO - 2018-03-24 00:42:02 --> Model Class Initialized
INFO - 2018-03-24 00:42:02 --> Model Class Initialized
INFO - 2018-03-24 00:42:02 --> Model Class Initialized
INFO - 2018-03-24 00:42:02 --> Model Class Initialized
DEBUG - 2018-03-24 00:42:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 00:42:07 --> Config Class Initialized
INFO - 2018-03-24 00:42:07 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:42:07 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:42:07 --> Utf8 Class Initialized
INFO - 2018-03-24 00:42:07 --> URI Class Initialized
INFO - 2018-03-24 00:42:07 --> Router Class Initialized
INFO - 2018-03-24 00:42:07 --> Output Class Initialized
INFO - 2018-03-24 00:42:07 --> Security Class Initialized
DEBUG - 2018-03-24 00:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:42:07 --> Input Class Initialized
INFO - 2018-03-24 00:42:07 --> Language Class Initialized
INFO - 2018-03-24 00:42:07 --> Loader Class Initialized
INFO - 2018-03-24 00:42:07 --> Helper loaded: url_helper
INFO - 2018-03-24 00:42:07 --> Helper loaded: form_helper
INFO - 2018-03-24 00:42:07 --> Database Driver Class Initialized
DEBUG - 2018-03-24 00:42:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 00:42:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 00:42:07 --> Form Validation Class Initialized
INFO - 2018-03-24 00:42:07 --> Model Class Initialized
INFO - 2018-03-24 00:42:07 --> Controller Class Initialized
INFO - 2018-03-24 00:42:07 --> Model Class Initialized
INFO - 2018-03-24 00:42:07 --> Model Class Initialized
INFO - 2018-03-24 00:42:07 --> Model Class Initialized
INFO - 2018-03-24 00:42:07 --> Model Class Initialized
DEBUG - 2018-03-24 00:42:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 00:42:15 --> Config Class Initialized
INFO - 2018-03-24 00:42:15 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:42:15 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:42:15 --> Utf8 Class Initialized
INFO - 2018-03-24 00:42:15 --> URI Class Initialized
INFO - 2018-03-24 00:42:15 --> Router Class Initialized
INFO - 2018-03-24 00:42:15 --> Output Class Initialized
INFO - 2018-03-24 00:42:15 --> Security Class Initialized
DEBUG - 2018-03-24 00:42:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:42:15 --> Input Class Initialized
INFO - 2018-03-24 00:42:15 --> Language Class Initialized
INFO - 2018-03-24 00:42:15 --> Loader Class Initialized
INFO - 2018-03-24 00:42:15 --> Helper loaded: url_helper
INFO - 2018-03-24 00:42:15 --> Helper loaded: form_helper
INFO - 2018-03-24 00:42:15 --> Database Driver Class Initialized
DEBUG - 2018-03-24 00:42:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 00:42:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 00:42:15 --> Form Validation Class Initialized
INFO - 2018-03-24 00:42:15 --> Model Class Initialized
INFO - 2018-03-24 00:42:15 --> Controller Class Initialized
INFO - 2018-03-24 00:42:15 --> Model Class Initialized
INFO - 2018-03-24 00:42:15 --> Model Class Initialized
INFO - 2018-03-24 00:42:15 --> Model Class Initialized
INFO - 2018-03-24 00:42:15 --> Model Class Initialized
DEBUG - 2018-03-24 00:42:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 00:42:18 --> Config Class Initialized
INFO - 2018-03-24 00:42:18 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:42:18 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:42:18 --> Utf8 Class Initialized
INFO - 2018-03-24 00:42:18 --> URI Class Initialized
INFO - 2018-03-24 00:42:18 --> Router Class Initialized
INFO - 2018-03-24 00:42:18 --> Output Class Initialized
INFO - 2018-03-24 00:42:18 --> Security Class Initialized
DEBUG - 2018-03-24 00:42:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:42:18 --> Input Class Initialized
INFO - 2018-03-24 00:42:18 --> Language Class Initialized
INFO - 2018-03-24 00:42:18 --> Loader Class Initialized
INFO - 2018-03-24 00:42:18 --> Helper loaded: url_helper
INFO - 2018-03-24 00:42:18 --> Helper loaded: form_helper
INFO - 2018-03-24 00:42:18 --> Database Driver Class Initialized
DEBUG - 2018-03-24 00:42:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 00:42:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 00:42:18 --> Form Validation Class Initialized
INFO - 2018-03-24 00:42:18 --> Model Class Initialized
INFO - 2018-03-24 00:42:18 --> Controller Class Initialized
INFO - 2018-03-24 00:42:18 --> Model Class Initialized
INFO - 2018-03-24 00:42:18 --> Model Class Initialized
INFO - 2018-03-24 00:42:18 --> Model Class Initialized
INFO - 2018-03-24 00:42:18 --> Model Class Initialized
DEBUG - 2018-03-24 00:42:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 00:42:36 --> Config Class Initialized
INFO - 2018-03-24 00:42:36 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:42:36 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:42:36 --> Utf8 Class Initialized
INFO - 2018-03-24 00:42:36 --> URI Class Initialized
INFO - 2018-03-24 00:42:36 --> Router Class Initialized
INFO - 2018-03-24 00:42:36 --> Output Class Initialized
INFO - 2018-03-24 00:42:36 --> Security Class Initialized
DEBUG - 2018-03-24 00:42:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:42:36 --> Input Class Initialized
INFO - 2018-03-24 00:42:36 --> Language Class Initialized
INFO - 2018-03-24 00:42:36 --> Loader Class Initialized
INFO - 2018-03-24 00:42:36 --> Helper loaded: url_helper
INFO - 2018-03-24 00:42:36 --> Helper loaded: form_helper
INFO - 2018-03-24 00:42:36 --> Database Driver Class Initialized
DEBUG - 2018-03-24 00:42:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 00:42:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 00:42:36 --> Form Validation Class Initialized
INFO - 2018-03-24 00:42:36 --> Model Class Initialized
INFO - 2018-03-24 00:42:36 --> Controller Class Initialized
INFO - 2018-03-24 00:42:36 --> Model Class Initialized
INFO - 2018-03-24 00:42:36 --> Model Class Initialized
INFO - 2018-03-24 00:42:36 --> Model Class Initialized
INFO - 2018-03-24 00:42:36 --> Model Class Initialized
DEBUG - 2018-03-24 00:42:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 00:42:36 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-24 00:42:36 --> Final output sent to browser
DEBUG - 2018-03-24 00:42:36 --> Total execution time: 0.1139
INFO - 2018-03-24 00:42:36 --> Config Class Initialized
INFO - 2018-03-24 00:42:36 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:42:36 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:42:36 --> Utf8 Class Initialized
INFO - 2018-03-24 00:42:36 --> URI Class Initialized
INFO - 2018-03-24 00:42:36 --> Router Class Initialized
INFO - 2018-03-24 00:42:36 --> Output Class Initialized
INFO - 2018-03-24 00:42:36 --> Security Class Initialized
DEBUG - 2018-03-24 00:42:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:42:36 --> Input Class Initialized
INFO - 2018-03-24 00:42:36 --> Language Class Initialized
INFO - 2018-03-24 00:42:36 --> Loader Class Initialized
INFO - 2018-03-24 00:42:36 --> Helper loaded: url_helper
INFO - 2018-03-24 00:42:36 --> Helper loaded: form_helper
INFO - 2018-03-24 00:42:36 --> Database Driver Class Initialized
DEBUG - 2018-03-24 00:42:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 00:42:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 00:42:36 --> Form Validation Class Initialized
INFO - 2018-03-24 00:42:36 --> Model Class Initialized
INFO - 2018-03-24 00:42:36 --> Controller Class Initialized
INFO - 2018-03-24 00:42:36 --> Model Class Initialized
INFO - 2018-03-24 00:42:36 --> Model Class Initialized
INFO - 2018-03-24 00:42:36 --> Model Class Initialized
INFO - 2018-03-24 00:42:36 --> Model Class Initialized
DEBUG - 2018-03-24 00:42:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 00:42:44 --> Config Class Initialized
INFO - 2018-03-24 00:42:44 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:42:44 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:42:44 --> Utf8 Class Initialized
INFO - 2018-03-24 00:42:44 --> URI Class Initialized
INFO - 2018-03-24 00:42:44 --> Router Class Initialized
INFO - 2018-03-24 00:42:44 --> Output Class Initialized
INFO - 2018-03-24 00:42:44 --> Security Class Initialized
DEBUG - 2018-03-24 00:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:42:44 --> Input Class Initialized
INFO - 2018-03-24 00:42:44 --> Language Class Initialized
INFO - 2018-03-24 00:42:44 --> Loader Class Initialized
INFO - 2018-03-24 00:42:44 --> Helper loaded: url_helper
INFO - 2018-03-24 00:42:44 --> Helper loaded: form_helper
INFO - 2018-03-24 00:42:44 --> Database Driver Class Initialized
DEBUG - 2018-03-24 00:42:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 00:42:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 00:42:44 --> Form Validation Class Initialized
INFO - 2018-03-24 00:42:44 --> Model Class Initialized
INFO - 2018-03-24 00:42:44 --> Controller Class Initialized
INFO - 2018-03-24 00:42:44 --> Model Class Initialized
INFO - 2018-03-24 00:42:44 --> Model Class Initialized
INFO - 2018-03-24 00:42:44 --> Model Class Initialized
INFO - 2018-03-24 00:42:44 --> Model Class Initialized
DEBUG - 2018-03-24 00:42:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 00:42:44 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-24 00:42:44 --> Final output sent to browser
DEBUG - 2018-03-24 00:42:44 --> Total execution time: 0.1491
INFO - 2018-03-24 00:42:45 --> Config Class Initialized
INFO - 2018-03-24 00:42:45 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:42:45 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:42:45 --> Utf8 Class Initialized
INFO - 2018-03-24 00:42:45 --> URI Class Initialized
INFO - 2018-03-24 00:42:45 --> Router Class Initialized
INFO - 2018-03-24 00:42:45 --> Output Class Initialized
INFO - 2018-03-24 00:42:45 --> Security Class Initialized
DEBUG - 2018-03-24 00:42:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:42:45 --> Input Class Initialized
INFO - 2018-03-24 00:42:45 --> Language Class Initialized
INFO - 2018-03-24 00:42:45 --> Loader Class Initialized
INFO - 2018-03-24 00:42:45 --> Helper loaded: url_helper
INFO - 2018-03-24 00:42:45 --> Helper loaded: form_helper
INFO - 2018-03-24 00:42:45 --> Database Driver Class Initialized
DEBUG - 2018-03-24 00:42:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 00:42:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 00:42:45 --> Form Validation Class Initialized
INFO - 2018-03-24 00:42:45 --> Model Class Initialized
INFO - 2018-03-24 00:42:45 --> Controller Class Initialized
INFO - 2018-03-24 00:42:45 --> Model Class Initialized
INFO - 2018-03-24 00:42:45 --> Model Class Initialized
INFO - 2018-03-24 00:42:45 --> Model Class Initialized
INFO - 2018-03-24 00:42:45 --> Model Class Initialized
INFO - 2018-03-24 00:42:45 --> Model Class Initialized
DEBUG - 2018-03-24 00:42:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 00:42:46 --> Config Class Initialized
INFO - 2018-03-24 00:42:46 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:42:46 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:42:46 --> Utf8 Class Initialized
INFO - 2018-03-24 00:42:46 --> URI Class Initialized
INFO - 2018-03-24 00:42:46 --> Router Class Initialized
INFO - 2018-03-24 00:42:46 --> Output Class Initialized
INFO - 2018-03-24 00:42:46 --> Security Class Initialized
DEBUG - 2018-03-24 00:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:42:46 --> Input Class Initialized
INFO - 2018-03-24 00:42:46 --> Language Class Initialized
INFO - 2018-03-24 00:42:46 --> Loader Class Initialized
INFO - 2018-03-24 00:42:46 --> Helper loaded: url_helper
INFO - 2018-03-24 00:42:46 --> Helper loaded: form_helper
INFO - 2018-03-24 00:42:46 --> Database Driver Class Initialized
DEBUG - 2018-03-24 00:42:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 00:42:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 00:42:46 --> Form Validation Class Initialized
INFO - 2018-03-24 00:42:46 --> Model Class Initialized
INFO - 2018-03-24 00:42:46 --> Controller Class Initialized
INFO - 2018-03-24 00:42:46 --> Model Class Initialized
INFO - 2018-03-24 00:42:46 --> Model Class Initialized
INFO - 2018-03-24 00:42:46 --> Model Class Initialized
INFO - 2018-03-24 00:42:46 --> Model Class Initialized
DEBUG - 2018-03-24 00:42:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 00:42:46 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-24 00:42:46 --> Final output sent to browser
DEBUG - 2018-03-24 00:42:46 --> Total execution time: 0.0890
INFO - 2018-03-24 00:42:46 --> Config Class Initialized
INFO - 2018-03-24 00:42:46 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:42:46 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:42:46 --> Utf8 Class Initialized
INFO - 2018-03-24 00:42:46 --> URI Class Initialized
INFO - 2018-03-24 00:42:46 --> Router Class Initialized
INFO - 2018-03-24 00:42:46 --> Output Class Initialized
INFO - 2018-03-24 00:42:46 --> Security Class Initialized
DEBUG - 2018-03-24 00:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:42:46 --> Input Class Initialized
INFO - 2018-03-24 00:42:46 --> Language Class Initialized
INFO - 2018-03-24 00:42:46 --> Loader Class Initialized
INFO - 2018-03-24 00:42:46 --> Helper loaded: url_helper
INFO - 2018-03-24 00:42:46 --> Helper loaded: form_helper
INFO - 2018-03-24 00:42:46 --> Database Driver Class Initialized
DEBUG - 2018-03-24 00:42:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 00:42:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 00:42:46 --> Form Validation Class Initialized
INFO - 2018-03-24 00:42:46 --> Model Class Initialized
INFO - 2018-03-24 00:42:46 --> Controller Class Initialized
INFO - 2018-03-24 00:42:46 --> Model Class Initialized
INFO - 2018-03-24 00:42:46 --> Model Class Initialized
INFO - 2018-03-24 00:42:47 --> Model Class Initialized
INFO - 2018-03-24 00:42:47 --> Model Class Initialized
DEBUG - 2018-03-24 00:42:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 00:42:51 --> Config Class Initialized
INFO - 2018-03-24 00:42:51 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:42:51 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:42:51 --> Utf8 Class Initialized
INFO - 2018-03-24 00:42:51 --> URI Class Initialized
INFO - 2018-03-24 00:42:51 --> Router Class Initialized
INFO - 2018-03-24 00:42:51 --> Output Class Initialized
INFO - 2018-03-24 00:42:51 --> Security Class Initialized
DEBUG - 2018-03-24 00:42:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:42:51 --> Input Class Initialized
INFO - 2018-03-24 00:42:51 --> Language Class Initialized
INFO - 2018-03-24 00:42:51 --> Loader Class Initialized
INFO - 2018-03-24 00:42:51 --> Helper loaded: url_helper
INFO - 2018-03-24 00:42:51 --> Helper loaded: form_helper
INFO - 2018-03-24 00:42:51 --> Database Driver Class Initialized
DEBUG - 2018-03-24 00:42:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 00:42:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 00:42:51 --> Form Validation Class Initialized
INFO - 2018-03-24 00:42:51 --> Model Class Initialized
INFO - 2018-03-24 00:42:51 --> Controller Class Initialized
INFO - 2018-03-24 00:42:51 --> Model Class Initialized
INFO - 2018-03-24 00:42:51 --> Model Class Initialized
INFO - 2018-03-24 00:42:51 --> Model Class Initialized
INFO - 2018-03-24 00:42:51 --> Model Class Initialized
DEBUG - 2018-03-24 00:42:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 00:42:52 --> Config Class Initialized
INFO - 2018-03-24 00:42:52 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:42:52 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:42:52 --> Utf8 Class Initialized
INFO - 2018-03-24 00:42:52 --> URI Class Initialized
INFO - 2018-03-24 00:42:52 --> Router Class Initialized
INFO - 2018-03-24 00:42:52 --> Output Class Initialized
INFO - 2018-03-24 00:42:52 --> Security Class Initialized
DEBUG - 2018-03-24 00:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:42:52 --> Input Class Initialized
INFO - 2018-03-24 00:42:52 --> Language Class Initialized
INFO - 2018-03-24 00:42:52 --> Loader Class Initialized
INFO - 2018-03-24 00:42:52 --> Helper loaded: url_helper
INFO - 2018-03-24 00:42:52 --> Helper loaded: form_helper
INFO - 2018-03-24 00:42:52 --> Database Driver Class Initialized
DEBUG - 2018-03-24 00:42:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 00:42:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 00:42:53 --> Form Validation Class Initialized
INFO - 2018-03-24 00:42:53 --> Model Class Initialized
INFO - 2018-03-24 00:42:53 --> Controller Class Initialized
INFO - 2018-03-24 00:42:53 --> Model Class Initialized
INFO - 2018-03-24 00:42:53 --> Model Class Initialized
INFO - 2018-03-24 00:42:53 --> Model Class Initialized
INFO - 2018-03-24 00:42:53 --> Model Class Initialized
DEBUG - 2018-03-24 00:42:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 00:42:53 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-24 00:42:53 --> Final output sent to browser
DEBUG - 2018-03-24 00:42:53 --> Total execution time: 0.1091
INFO - 2018-03-24 00:42:53 --> Config Class Initialized
INFO - 2018-03-24 00:42:53 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:42:53 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:42:53 --> Utf8 Class Initialized
INFO - 2018-03-24 00:42:53 --> URI Class Initialized
INFO - 2018-03-24 00:42:53 --> Router Class Initialized
INFO - 2018-03-24 00:42:53 --> Output Class Initialized
INFO - 2018-03-24 00:42:53 --> Security Class Initialized
DEBUG - 2018-03-24 00:42:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:42:53 --> Input Class Initialized
INFO - 2018-03-24 00:42:53 --> Language Class Initialized
INFO - 2018-03-24 00:42:53 --> Loader Class Initialized
INFO - 2018-03-24 00:42:53 --> Helper loaded: url_helper
INFO - 2018-03-24 00:42:53 --> Helper loaded: form_helper
INFO - 2018-03-24 00:42:53 --> Database Driver Class Initialized
DEBUG - 2018-03-24 00:42:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 00:42:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 00:42:53 --> Form Validation Class Initialized
INFO - 2018-03-24 00:42:53 --> Model Class Initialized
INFO - 2018-03-24 00:42:53 --> Controller Class Initialized
INFO - 2018-03-24 00:42:53 --> Model Class Initialized
INFO - 2018-03-24 00:42:53 --> Model Class Initialized
INFO - 2018-03-24 00:42:53 --> Model Class Initialized
INFO - 2018-03-24 00:42:53 --> Model Class Initialized
INFO - 2018-03-24 00:42:53 --> Model Class Initialized
DEBUG - 2018-03-24 00:42:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 00:42:55 --> Config Class Initialized
INFO - 2018-03-24 00:42:55 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:42:55 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:42:55 --> Utf8 Class Initialized
INFO - 2018-03-24 00:42:55 --> URI Class Initialized
INFO - 2018-03-24 00:42:55 --> Router Class Initialized
INFO - 2018-03-24 00:42:55 --> Output Class Initialized
INFO - 2018-03-24 00:42:55 --> Security Class Initialized
DEBUG - 2018-03-24 00:42:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:42:55 --> Input Class Initialized
INFO - 2018-03-24 00:42:55 --> Language Class Initialized
INFO - 2018-03-24 00:42:55 --> Loader Class Initialized
INFO - 2018-03-24 00:42:55 --> Helper loaded: url_helper
INFO - 2018-03-24 00:42:55 --> Helper loaded: form_helper
INFO - 2018-03-24 00:42:55 --> Database Driver Class Initialized
DEBUG - 2018-03-24 00:42:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 00:42:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 00:42:55 --> Form Validation Class Initialized
INFO - 2018-03-24 00:42:55 --> Model Class Initialized
INFO - 2018-03-24 00:42:55 --> Controller Class Initialized
INFO - 2018-03-24 00:42:55 --> Model Class Initialized
INFO - 2018-03-24 00:42:55 --> Model Class Initialized
INFO - 2018-03-24 00:42:55 --> Model Class Initialized
INFO - 2018-03-24 00:42:55 --> Model Class Initialized
DEBUG - 2018-03-24 00:42:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 00:42:55 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-24 00:42:55 --> Final output sent to browser
DEBUG - 2018-03-24 00:42:55 --> Total execution time: 0.1183
INFO - 2018-03-24 00:42:55 --> Config Class Initialized
INFO - 2018-03-24 00:42:55 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:42:55 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:42:55 --> Utf8 Class Initialized
INFO - 2018-03-24 00:42:55 --> URI Class Initialized
INFO - 2018-03-24 00:42:55 --> Router Class Initialized
INFO - 2018-03-24 00:42:56 --> Output Class Initialized
INFO - 2018-03-24 00:42:56 --> Security Class Initialized
DEBUG - 2018-03-24 00:42:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:42:56 --> Input Class Initialized
INFO - 2018-03-24 00:42:56 --> Language Class Initialized
INFO - 2018-03-24 00:42:56 --> Loader Class Initialized
INFO - 2018-03-24 00:42:56 --> Helper loaded: url_helper
INFO - 2018-03-24 00:42:56 --> Helper loaded: form_helper
INFO - 2018-03-24 00:42:56 --> Database Driver Class Initialized
DEBUG - 2018-03-24 00:42:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 00:42:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 00:42:56 --> Form Validation Class Initialized
INFO - 2018-03-24 00:42:56 --> Model Class Initialized
INFO - 2018-03-24 00:42:56 --> Controller Class Initialized
INFO - 2018-03-24 00:42:56 --> Model Class Initialized
INFO - 2018-03-24 00:42:56 --> Model Class Initialized
INFO - 2018-03-24 00:42:56 --> Model Class Initialized
INFO - 2018-03-24 00:42:56 --> Model Class Initialized
DEBUG - 2018-03-24 00:42:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 00:43:01 --> Config Class Initialized
INFO - 2018-03-24 00:43:01 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:43:01 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:43:01 --> Utf8 Class Initialized
INFO - 2018-03-24 00:43:01 --> URI Class Initialized
INFO - 2018-03-24 00:43:01 --> Router Class Initialized
INFO - 2018-03-24 00:43:01 --> Output Class Initialized
INFO - 2018-03-24 00:43:01 --> Security Class Initialized
DEBUG - 2018-03-24 00:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:43:01 --> Input Class Initialized
INFO - 2018-03-24 00:43:01 --> Language Class Initialized
INFO - 2018-03-24 00:43:01 --> Loader Class Initialized
INFO - 2018-03-24 00:43:01 --> Helper loaded: url_helper
INFO - 2018-03-24 00:43:01 --> Helper loaded: form_helper
INFO - 2018-03-24 00:43:01 --> Database Driver Class Initialized
DEBUG - 2018-03-24 00:43:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 00:43:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 00:43:01 --> Form Validation Class Initialized
INFO - 2018-03-24 00:43:01 --> Model Class Initialized
INFO - 2018-03-24 00:43:01 --> Controller Class Initialized
INFO - 2018-03-24 00:43:01 --> Model Class Initialized
INFO - 2018-03-24 00:43:01 --> Model Class Initialized
INFO - 2018-03-24 00:43:01 --> Model Class Initialized
INFO - 2018-03-24 00:43:01 --> Model Class Initialized
DEBUG - 2018-03-24 00:43:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 00:43:06 --> Config Class Initialized
INFO - 2018-03-24 00:43:06 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:43:06 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:43:06 --> Utf8 Class Initialized
INFO - 2018-03-24 00:43:06 --> URI Class Initialized
INFO - 2018-03-24 00:43:06 --> Router Class Initialized
INFO - 2018-03-24 00:43:06 --> Output Class Initialized
INFO - 2018-03-24 00:43:06 --> Security Class Initialized
DEBUG - 2018-03-24 00:43:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:43:06 --> Input Class Initialized
INFO - 2018-03-24 00:43:06 --> Language Class Initialized
INFO - 2018-03-24 00:43:06 --> Loader Class Initialized
INFO - 2018-03-24 00:43:06 --> Helper loaded: url_helper
INFO - 2018-03-24 00:43:06 --> Helper loaded: form_helper
INFO - 2018-03-24 00:43:06 --> Database Driver Class Initialized
DEBUG - 2018-03-24 00:43:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 00:43:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 00:43:06 --> Form Validation Class Initialized
INFO - 2018-03-24 00:43:06 --> Model Class Initialized
INFO - 2018-03-24 00:43:06 --> Controller Class Initialized
INFO - 2018-03-24 00:43:06 --> Model Class Initialized
INFO - 2018-03-24 00:43:06 --> Model Class Initialized
INFO - 2018-03-24 00:43:06 --> Model Class Initialized
INFO - 2018-03-24 00:43:06 --> Model Class Initialized
DEBUG - 2018-03-24 00:43:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 00:43:06 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-24 00:43:06 --> Final output sent to browser
DEBUG - 2018-03-24 00:43:06 --> Total execution time: 0.1024
INFO - 2018-03-24 00:43:07 --> Config Class Initialized
INFO - 2018-03-24 00:43:07 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:43:07 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:43:07 --> Utf8 Class Initialized
INFO - 2018-03-24 00:43:07 --> URI Class Initialized
INFO - 2018-03-24 00:43:07 --> Router Class Initialized
INFO - 2018-03-24 00:43:07 --> Output Class Initialized
INFO - 2018-03-24 00:43:07 --> Security Class Initialized
DEBUG - 2018-03-24 00:43:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:43:07 --> Input Class Initialized
INFO - 2018-03-24 00:43:07 --> Language Class Initialized
INFO - 2018-03-24 00:43:07 --> Loader Class Initialized
INFO - 2018-03-24 00:43:07 --> Helper loaded: url_helper
INFO - 2018-03-24 00:43:07 --> Helper loaded: form_helper
INFO - 2018-03-24 00:43:07 --> Database Driver Class Initialized
DEBUG - 2018-03-24 00:43:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 00:43:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 00:43:07 --> Form Validation Class Initialized
INFO - 2018-03-24 00:43:07 --> Model Class Initialized
INFO - 2018-03-24 00:43:07 --> Controller Class Initialized
INFO - 2018-03-24 00:43:07 --> Model Class Initialized
INFO - 2018-03-24 00:43:07 --> Model Class Initialized
INFO - 2018-03-24 00:43:07 --> Model Class Initialized
INFO - 2018-03-24 00:43:07 --> Model Class Initialized
INFO - 2018-03-24 00:43:07 --> Model Class Initialized
DEBUG - 2018-03-24 00:43:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 00:43:11 --> Config Class Initialized
INFO - 2018-03-24 00:43:11 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:43:11 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:43:11 --> Utf8 Class Initialized
INFO - 2018-03-24 00:43:11 --> URI Class Initialized
INFO - 2018-03-24 00:43:11 --> Router Class Initialized
INFO - 2018-03-24 00:43:11 --> Output Class Initialized
INFO - 2018-03-24 00:43:11 --> Security Class Initialized
DEBUG - 2018-03-24 00:43:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:43:11 --> Input Class Initialized
INFO - 2018-03-24 00:43:11 --> Language Class Initialized
INFO - 2018-03-24 00:43:11 --> Loader Class Initialized
INFO - 2018-03-24 00:43:11 --> Helper loaded: url_helper
INFO - 2018-03-24 00:43:11 --> Helper loaded: form_helper
INFO - 2018-03-24 00:43:11 --> Database Driver Class Initialized
DEBUG - 2018-03-24 00:43:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 00:43:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 00:43:11 --> Form Validation Class Initialized
INFO - 2018-03-24 00:43:11 --> Model Class Initialized
INFO - 2018-03-24 00:43:11 --> Controller Class Initialized
INFO - 2018-03-24 00:43:11 --> Model Class Initialized
INFO - 2018-03-24 00:43:11 --> Model Class Initialized
INFO - 2018-03-24 00:43:11 --> Model Class Initialized
INFO - 2018-03-24 00:43:11 --> Model Class Initialized
DEBUG - 2018-03-24 00:43:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 00:43:11 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-24 00:43:11 --> Final output sent to browser
DEBUG - 2018-03-24 00:43:11 --> Total execution time: 0.1600
INFO - 2018-03-24 00:43:12 --> Config Class Initialized
INFO - 2018-03-24 00:43:12 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:43:12 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:43:12 --> Utf8 Class Initialized
INFO - 2018-03-24 00:43:12 --> URI Class Initialized
INFO - 2018-03-24 00:43:12 --> Router Class Initialized
INFO - 2018-03-24 00:43:12 --> Output Class Initialized
INFO - 2018-03-24 00:43:12 --> Security Class Initialized
DEBUG - 2018-03-24 00:43:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:43:12 --> Input Class Initialized
INFO - 2018-03-24 00:43:12 --> Language Class Initialized
INFO - 2018-03-24 00:43:12 --> Loader Class Initialized
INFO - 2018-03-24 00:43:12 --> Helper loaded: url_helper
INFO - 2018-03-24 00:43:12 --> Helper loaded: form_helper
INFO - 2018-03-24 00:43:12 --> Database Driver Class Initialized
DEBUG - 2018-03-24 00:43:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 00:43:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 00:43:12 --> Form Validation Class Initialized
INFO - 2018-03-24 00:43:12 --> Model Class Initialized
INFO - 2018-03-24 00:43:12 --> Controller Class Initialized
INFO - 2018-03-24 00:43:12 --> Model Class Initialized
INFO - 2018-03-24 00:43:12 --> Model Class Initialized
INFO - 2018-03-24 00:43:12 --> Model Class Initialized
INFO - 2018-03-24 00:43:12 --> Model Class Initialized
DEBUG - 2018-03-24 00:43:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 00:43:20 --> Config Class Initialized
INFO - 2018-03-24 00:43:20 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:43:20 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:43:20 --> Utf8 Class Initialized
INFO - 2018-03-24 00:43:20 --> URI Class Initialized
INFO - 2018-03-24 00:43:20 --> Router Class Initialized
INFO - 2018-03-24 00:43:20 --> Output Class Initialized
INFO - 2018-03-24 00:43:20 --> Security Class Initialized
DEBUG - 2018-03-24 00:43:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:43:20 --> Input Class Initialized
INFO - 2018-03-24 00:43:20 --> Language Class Initialized
INFO - 2018-03-24 00:43:20 --> Loader Class Initialized
INFO - 2018-03-24 00:43:20 --> Helper loaded: url_helper
INFO - 2018-03-24 00:43:20 --> Helper loaded: form_helper
INFO - 2018-03-24 00:43:20 --> Database Driver Class Initialized
DEBUG - 2018-03-24 00:43:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 00:43:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 00:43:20 --> Form Validation Class Initialized
INFO - 2018-03-24 00:43:20 --> Model Class Initialized
INFO - 2018-03-24 00:43:20 --> Controller Class Initialized
INFO - 2018-03-24 00:43:20 --> Model Class Initialized
INFO - 2018-03-24 00:43:20 --> Model Class Initialized
INFO - 2018-03-24 00:43:20 --> Model Class Initialized
INFO - 2018-03-24 00:43:20 --> Model Class Initialized
DEBUG - 2018-03-24 00:43:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 00:43:20 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-24 00:43:20 --> Final output sent to browser
DEBUG - 2018-03-24 00:43:20 --> Total execution time: 0.0560
INFO - 2018-03-24 00:43:21 --> Config Class Initialized
INFO - 2018-03-24 00:43:21 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:43:21 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:43:21 --> Utf8 Class Initialized
INFO - 2018-03-24 00:43:21 --> URI Class Initialized
INFO - 2018-03-24 00:43:21 --> Router Class Initialized
INFO - 2018-03-24 00:43:21 --> Output Class Initialized
INFO - 2018-03-24 00:43:21 --> Security Class Initialized
DEBUG - 2018-03-24 00:43:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:43:21 --> Input Class Initialized
INFO - 2018-03-24 00:43:21 --> Language Class Initialized
INFO - 2018-03-24 00:43:21 --> Loader Class Initialized
INFO - 2018-03-24 00:43:21 --> Helper loaded: url_helper
INFO - 2018-03-24 00:43:21 --> Helper loaded: form_helper
INFO - 2018-03-24 00:43:21 --> Database Driver Class Initialized
DEBUG - 2018-03-24 00:43:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 00:43:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 00:43:21 --> Form Validation Class Initialized
INFO - 2018-03-24 00:43:21 --> Model Class Initialized
INFO - 2018-03-24 00:43:21 --> Controller Class Initialized
INFO - 2018-03-24 00:43:21 --> Model Class Initialized
INFO - 2018-03-24 00:43:21 --> Model Class Initialized
INFO - 2018-03-24 00:43:21 --> Model Class Initialized
INFO - 2018-03-24 00:43:21 --> Model Class Initialized
INFO - 2018-03-24 00:43:21 --> Model Class Initialized
DEBUG - 2018-03-24 00:43:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 00:43:22 --> Config Class Initialized
INFO - 2018-03-24 00:43:22 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:43:22 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:43:22 --> Utf8 Class Initialized
INFO - 2018-03-24 00:43:22 --> URI Class Initialized
INFO - 2018-03-24 00:43:22 --> Router Class Initialized
INFO - 2018-03-24 00:43:22 --> Output Class Initialized
INFO - 2018-03-24 00:43:22 --> Security Class Initialized
DEBUG - 2018-03-24 00:43:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:43:22 --> Input Class Initialized
INFO - 2018-03-24 00:43:22 --> Language Class Initialized
INFO - 2018-03-24 00:43:22 --> Loader Class Initialized
INFO - 2018-03-24 00:43:22 --> Helper loaded: url_helper
INFO - 2018-03-24 00:43:22 --> Helper loaded: form_helper
INFO - 2018-03-24 00:43:22 --> Database Driver Class Initialized
DEBUG - 2018-03-24 00:43:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 00:43:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 00:43:22 --> Form Validation Class Initialized
INFO - 2018-03-24 00:43:22 --> Model Class Initialized
INFO - 2018-03-24 00:43:22 --> Controller Class Initialized
INFO - 2018-03-24 00:43:22 --> Model Class Initialized
INFO - 2018-03-24 00:43:22 --> Model Class Initialized
INFO - 2018-03-24 00:43:22 --> Model Class Initialized
INFO - 2018-03-24 00:43:22 --> Model Class Initialized
DEBUG - 2018-03-24 00:43:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 00:43:22 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-24 00:43:22 --> Final output sent to browser
DEBUG - 2018-03-24 00:43:22 --> Total execution time: 0.1040
INFO - 2018-03-24 00:43:22 --> Config Class Initialized
INFO - 2018-03-24 00:43:22 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:43:22 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:43:22 --> Utf8 Class Initialized
INFO - 2018-03-24 00:43:22 --> URI Class Initialized
INFO - 2018-03-24 00:43:22 --> Router Class Initialized
INFO - 2018-03-24 00:43:22 --> Output Class Initialized
INFO - 2018-03-24 00:43:22 --> Security Class Initialized
DEBUG - 2018-03-24 00:43:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:43:22 --> Input Class Initialized
INFO - 2018-03-24 00:43:22 --> Language Class Initialized
INFO - 2018-03-24 00:43:22 --> Loader Class Initialized
INFO - 2018-03-24 00:43:22 --> Helper loaded: url_helper
INFO - 2018-03-24 00:43:22 --> Helper loaded: form_helper
INFO - 2018-03-24 00:43:22 --> Database Driver Class Initialized
DEBUG - 2018-03-24 00:43:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 00:43:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 00:43:22 --> Form Validation Class Initialized
INFO - 2018-03-24 00:43:22 --> Model Class Initialized
INFO - 2018-03-24 00:43:22 --> Controller Class Initialized
INFO - 2018-03-24 00:43:22 --> Model Class Initialized
INFO - 2018-03-24 00:43:22 --> Model Class Initialized
INFO - 2018-03-24 00:43:22 --> Model Class Initialized
INFO - 2018-03-24 00:43:22 --> Model Class Initialized
DEBUG - 2018-03-24 00:43:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 00:43:38 --> Config Class Initialized
INFO - 2018-03-24 00:43:38 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:43:38 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:43:38 --> Utf8 Class Initialized
INFO - 2018-03-24 00:43:38 --> URI Class Initialized
INFO - 2018-03-24 00:43:38 --> Router Class Initialized
INFO - 2018-03-24 00:43:38 --> Output Class Initialized
INFO - 2018-03-24 00:43:38 --> Security Class Initialized
DEBUG - 2018-03-24 00:43:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:43:38 --> Input Class Initialized
INFO - 2018-03-24 00:43:38 --> Language Class Initialized
INFO - 2018-03-24 00:43:38 --> Loader Class Initialized
INFO - 2018-03-24 00:43:38 --> Helper loaded: url_helper
INFO - 2018-03-24 00:43:38 --> Helper loaded: form_helper
INFO - 2018-03-24 00:43:38 --> Database Driver Class Initialized
DEBUG - 2018-03-24 00:43:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 00:43:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 00:43:38 --> Form Validation Class Initialized
INFO - 2018-03-24 00:43:38 --> Model Class Initialized
INFO - 2018-03-24 00:43:38 --> Controller Class Initialized
INFO - 2018-03-24 00:43:38 --> Model Class Initialized
INFO - 2018-03-24 00:43:38 --> Model Class Initialized
INFO - 2018-03-24 00:43:38 --> Model Class Initialized
INFO - 2018-03-24 00:43:38 --> Model Class Initialized
DEBUG - 2018-03-24 00:43:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 00:43:43 --> Config Class Initialized
INFO - 2018-03-24 00:43:43 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:43:43 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:43:43 --> Utf8 Class Initialized
INFO - 2018-03-24 00:43:43 --> URI Class Initialized
INFO - 2018-03-24 00:43:43 --> Router Class Initialized
INFO - 2018-03-24 00:43:43 --> Output Class Initialized
INFO - 2018-03-24 00:43:43 --> Security Class Initialized
DEBUG - 2018-03-24 00:43:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:43:43 --> Input Class Initialized
INFO - 2018-03-24 00:43:43 --> Language Class Initialized
INFO - 2018-03-24 00:43:43 --> Loader Class Initialized
INFO - 2018-03-24 00:43:43 --> Helper loaded: url_helper
INFO - 2018-03-24 00:43:43 --> Helper loaded: form_helper
INFO - 2018-03-24 00:43:43 --> Database Driver Class Initialized
DEBUG - 2018-03-24 00:43:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 00:43:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 00:43:43 --> Form Validation Class Initialized
INFO - 2018-03-24 00:43:43 --> Model Class Initialized
INFO - 2018-03-24 00:43:43 --> Controller Class Initialized
INFO - 2018-03-24 00:43:43 --> Model Class Initialized
INFO - 2018-03-24 00:43:43 --> Model Class Initialized
INFO - 2018-03-24 00:43:43 --> Model Class Initialized
INFO - 2018-03-24 00:43:43 --> Model Class Initialized
DEBUG - 2018-03-24 00:43:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 00:44:02 --> Config Class Initialized
INFO - 2018-03-24 00:44:02 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:44:02 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:44:02 --> Utf8 Class Initialized
INFO - 2018-03-24 00:44:02 --> URI Class Initialized
INFO - 2018-03-24 00:44:02 --> Router Class Initialized
INFO - 2018-03-24 00:44:02 --> Output Class Initialized
INFO - 2018-03-24 00:44:02 --> Security Class Initialized
DEBUG - 2018-03-24 00:44:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:44:02 --> Input Class Initialized
INFO - 2018-03-24 00:44:02 --> Language Class Initialized
INFO - 2018-03-24 00:44:02 --> Loader Class Initialized
INFO - 2018-03-24 00:44:02 --> Helper loaded: url_helper
INFO - 2018-03-24 00:44:02 --> Helper loaded: form_helper
INFO - 2018-03-24 00:44:02 --> Database Driver Class Initialized
DEBUG - 2018-03-24 00:44:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 00:44:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 00:44:02 --> Form Validation Class Initialized
INFO - 2018-03-24 00:44:02 --> Model Class Initialized
INFO - 2018-03-24 00:44:02 --> Controller Class Initialized
INFO - 2018-03-24 00:44:02 --> Model Class Initialized
INFO - 2018-03-24 00:44:02 --> Model Class Initialized
INFO - 2018-03-24 00:44:02 --> Model Class Initialized
INFO - 2018-03-24 00:44:02 --> Model Class Initialized
DEBUG - 2018-03-24 00:44:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 00:44:06 --> Config Class Initialized
INFO - 2018-03-24 00:44:06 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:44:06 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:44:06 --> Utf8 Class Initialized
INFO - 2018-03-24 00:44:06 --> URI Class Initialized
INFO - 2018-03-24 00:44:06 --> Router Class Initialized
INFO - 2018-03-24 00:44:06 --> Output Class Initialized
INFO - 2018-03-24 00:44:06 --> Security Class Initialized
DEBUG - 2018-03-24 00:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:44:06 --> Input Class Initialized
INFO - 2018-03-24 00:44:06 --> Language Class Initialized
INFO - 2018-03-24 00:44:06 --> Loader Class Initialized
INFO - 2018-03-24 00:44:06 --> Helper loaded: url_helper
INFO - 2018-03-24 00:44:06 --> Helper loaded: form_helper
INFO - 2018-03-24 00:44:06 --> Database Driver Class Initialized
DEBUG - 2018-03-24 00:44:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 00:44:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 00:44:06 --> Form Validation Class Initialized
INFO - 2018-03-24 00:44:06 --> Model Class Initialized
INFO - 2018-03-24 00:44:06 --> Controller Class Initialized
INFO - 2018-03-24 00:44:06 --> Model Class Initialized
INFO - 2018-03-24 00:44:06 --> Model Class Initialized
INFO - 2018-03-24 00:44:06 --> Model Class Initialized
INFO - 2018-03-24 00:44:06 --> Model Class Initialized
DEBUG - 2018-03-24 00:44:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 00:44:36 --> Config Class Initialized
INFO - 2018-03-24 00:44:36 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:44:36 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:44:36 --> Utf8 Class Initialized
INFO - 2018-03-24 00:44:36 --> URI Class Initialized
INFO - 2018-03-24 00:44:36 --> Router Class Initialized
INFO - 2018-03-24 00:44:36 --> Output Class Initialized
INFO - 2018-03-24 00:44:36 --> Security Class Initialized
DEBUG - 2018-03-24 00:44:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:44:36 --> Input Class Initialized
INFO - 2018-03-24 00:44:36 --> Language Class Initialized
INFO - 2018-03-24 00:44:36 --> Loader Class Initialized
INFO - 2018-03-24 00:44:36 --> Helper loaded: url_helper
INFO - 2018-03-24 00:44:36 --> Helper loaded: form_helper
INFO - 2018-03-24 00:44:36 --> Database Driver Class Initialized
DEBUG - 2018-03-24 00:44:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 00:44:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 00:44:36 --> Form Validation Class Initialized
INFO - 2018-03-24 00:44:36 --> Model Class Initialized
INFO - 2018-03-24 00:44:36 --> Controller Class Initialized
INFO - 2018-03-24 00:44:36 --> Model Class Initialized
INFO - 2018-03-24 00:44:36 --> Model Class Initialized
INFO - 2018-03-24 00:44:36 --> Model Class Initialized
INFO - 2018-03-24 00:44:36 --> Model Class Initialized
DEBUG - 2018-03-24 00:44:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 00:45:52 --> Config Class Initialized
INFO - 2018-03-24 00:45:52 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:45:52 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:45:52 --> Utf8 Class Initialized
INFO - 2018-03-24 00:45:52 --> URI Class Initialized
INFO - 2018-03-24 00:45:52 --> Router Class Initialized
INFO - 2018-03-24 00:45:52 --> Output Class Initialized
INFO - 2018-03-24 00:45:52 --> Security Class Initialized
DEBUG - 2018-03-24 00:45:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:45:52 --> Input Class Initialized
INFO - 2018-03-24 00:45:52 --> Language Class Initialized
INFO - 2018-03-24 00:45:52 --> Loader Class Initialized
INFO - 2018-03-24 00:45:52 --> Helper loaded: url_helper
INFO - 2018-03-24 00:45:52 --> Helper loaded: form_helper
INFO - 2018-03-24 00:45:52 --> Database Driver Class Initialized
DEBUG - 2018-03-24 00:45:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 00:45:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 00:45:52 --> Form Validation Class Initialized
INFO - 2018-03-24 00:45:52 --> Model Class Initialized
INFO - 2018-03-24 00:45:52 --> Controller Class Initialized
INFO - 2018-03-24 00:45:52 --> Model Class Initialized
INFO - 2018-03-24 00:45:52 --> Model Class Initialized
INFO - 2018-03-24 00:45:52 --> Model Class Initialized
INFO - 2018-03-24 00:45:52 --> Model Class Initialized
DEBUG - 2018-03-24 00:45:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 00:45:58 --> Config Class Initialized
INFO - 2018-03-24 00:45:58 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:45:58 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:45:58 --> Utf8 Class Initialized
INFO - 2018-03-24 00:45:58 --> URI Class Initialized
INFO - 2018-03-24 00:45:58 --> Router Class Initialized
INFO - 2018-03-24 00:45:58 --> Output Class Initialized
INFO - 2018-03-24 00:45:58 --> Security Class Initialized
DEBUG - 2018-03-24 00:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:45:58 --> Input Class Initialized
INFO - 2018-03-24 00:45:58 --> Language Class Initialized
INFO - 2018-03-24 00:45:58 --> Loader Class Initialized
INFO - 2018-03-24 00:45:58 --> Helper loaded: url_helper
INFO - 2018-03-24 00:45:58 --> Helper loaded: form_helper
INFO - 2018-03-24 00:45:58 --> Database Driver Class Initialized
DEBUG - 2018-03-24 00:45:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 00:45:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 00:45:58 --> Form Validation Class Initialized
INFO - 2018-03-24 00:45:58 --> Model Class Initialized
INFO - 2018-03-24 00:45:58 --> Controller Class Initialized
INFO - 2018-03-24 00:45:58 --> Model Class Initialized
INFO - 2018-03-24 00:45:58 --> Model Class Initialized
INFO - 2018-03-24 00:45:58 --> Model Class Initialized
INFO - 2018-03-24 00:45:58 --> Model Class Initialized
DEBUG - 2018-03-24 00:45:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 00:50:07 --> Config Class Initialized
INFO - 2018-03-24 00:50:07 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:50:07 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:50:07 --> Utf8 Class Initialized
INFO - 2018-03-24 00:50:07 --> URI Class Initialized
INFO - 2018-03-24 00:50:07 --> Router Class Initialized
INFO - 2018-03-24 00:50:07 --> Output Class Initialized
INFO - 2018-03-24 00:50:07 --> Security Class Initialized
DEBUG - 2018-03-24 00:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:50:07 --> Input Class Initialized
INFO - 2018-03-24 00:50:07 --> Language Class Initialized
INFO - 2018-03-24 00:50:07 --> Loader Class Initialized
INFO - 2018-03-24 00:50:07 --> Helper loaded: url_helper
INFO - 2018-03-24 00:50:08 --> Helper loaded: form_helper
INFO - 2018-03-24 00:50:08 --> Database Driver Class Initialized
DEBUG - 2018-03-24 00:50:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 00:50:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 00:50:08 --> Form Validation Class Initialized
INFO - 2018-03-24 00:50:08 --> Model Class Initialized
INFO - 2018-03-24 00:50:08 --> Controller Class Initialized
INFO - 2018-03-24 00:50:08 --> Model Class Initialized
INFO - 2018-03-24 00:50:08 --> Model Class Initialized
INFO - 2018-03-24 00:50:08 --> Model Class Initialized
INFO - 2018-03-24 00:50:08 --> Model Class Initialized
INFO - 2018-03-24 00:50:08 --> Model Class Initialized
DEBUG - 2018-03-24 00:50:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 00:50:08 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-24 00:50:08 --> Final output sent to browser
DEBUG - 2018-03-24 00:50:08 --> Total execution time: 0.1152
INFO - 2018-03-24 00:50:08 --> Config Class Initialized
INFO - 2018-03-24 00:50:08 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:50:08 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:50:08 --> Utf8 Class Initialized
INFO - 2018-03-24 00:50:08 --> URI Class Initialized
INFO - 2018-03-24 00:50:08 --> Router Class Initialized
INFO - 2018-03-24 00:50:08 --> Output Class Initialized
INFO - 2018-03-24 00:50:08 --> Security Class Initialized
DEBUG - 2018-03-24 00:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:50:08 --> Input Class Initialized
INFO - 2018-03-24 00:50:08 --> Language Class Initialized
INFO - 2018-03-24 00:50:08 --> Loader Class Initialized
INFO - 2018-03-24 00:50:08 --> Helper loaded: url_helper
INFO - 2018-03-24 00:50:08 --> Helper loaded: form_helper
INFO - 2018-03-24 00:50:08 --> Database Driver Class Initialized
DEBUG - 2018-03-24 00:50:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 00:50:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 00:50:08 --> Form Validation Class Initialized
INFO - 2018-03-24 00:50:08 --> Model Class Initialized
INFO - 2018-03-24 00:50:08 --> Controller Class Initialized
INFO - 2018-03-24 00:50:08 --> Model Class Initialized
INFO - 2018-03-24 00:50:08 --> Model Class Initialized
INFO - 2018-03-24 00:50:08 --> Model Class Initialized
INFO - 2018-03-24 00:50:08 --> Model Class Initialized
INFO - 2018-03-24 00:50:08 --> Model Class Initialized
DEBUG - 2018-03-24 00:50:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 00:50:09 --> Config Class Initialized
INFO - 2018-03-24 00:50:09 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:50:09 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:50:09 --> Utf8 Class Initialized
INFO - 2018-03-24 00:50:09 --> URI Class Initialized
INFO - 2018-03-24 00:50:09 --> Router Class Initialized
INFO - 2018-03-24 00:50:09 --> Output Class Initialized
INFO - 2018-03-24 00:50:09 --> Security Class Initialized
DEBUG - 2018-03-24 00:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:50:09 --> Input Class Initialized
INFO - 2018-03-24 00:50:09 --> Language Class Initialized
INFO - 2018-03-24 00:50:09 --> Loader Class Initialized
INFO - 2018-03-24 00:50:09 --> Helper loaded: url_helper
INFO - 2018-03-24 00:50:09 --> Helper loaded: form_helper
INFO - 2018-03-24 00:50:09 --> Database Driver Class Initialized
DEBUG - 2018-03-24 00:50:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 00:50:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 00:50:09 --> Form Validation Class Initialized
INFO - 2018-03-24 00:50:09 --> Model Class Initialized
INFO - 2018-03-24 00:50:09 --> Controller Class Initialized
INFO - 2018-03-24 00:50:09 --> Model Class Initialized
INFO - 2018-03-24 00:50:09 --> Model Class Initialized
INFO - 2018-03-24 00:50:09 --> Model Class Initialized
INFO - 2018-03-24 00:50:09 --> Model Class Initialized
INFO - 2018-03-24 00:50:09 --> Model Class Initialized
DEBUG - 2018-03-24 00:50:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 00:50:09 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-24 00:50:09 --> Final output sent to browser
DEBUG - 2018-03-24 00:50:09 --> Total execution time: 0.1280
INFO - 2018-03-24 00:50:09 --> Config Class Initialized
INFO - 2018-03-24 00:50:09 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:50:09 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:50:09 --> Utf8 Class Initialized
INFO - 2018-03-24 00:50:09 --> URI Class Initialized
INFO - 2018-03-24 00:50:09 --> Router Class Initialized
INFO - 2018-03-24 00:50:09 --> Output Class Initialized
INFO - 2018-03-24 00:50:09 --> Security Class Initialized
DEBUG - 2018-03-24 00:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:50:09 --> Input Class Initialized
INFO - 2018-03-24 00:50:09 --> Language Class Initialized
INFO - 2018-03-24 00:50:09 --> Loader Class Initialized
INFO - 2018-03-24 00:50:09 --> Helper loaded: url_helper
INFO - 2018-03-24 00:50:09 --> Helper loaded: form_helper
INFO - 2018-03-24 00:50:09 --> Database Driver Class Initialized
DEBUG - 2018-03-24 00:50:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 00:50:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 00:50:09 --> Form Validation Class Initialized
INFO - 2018-03-24 00:50:09 --> Model Class Initialized
INFO - 2018-03-24 00:50:09 --> Controller Class Initialized
INFO - 2018-03-24 00:50:09 --> Model Class Initialized
INFO - 2018-03-24 00:50:09 --> Model Class Initialized
INFO - 2018-03-24 00:50:09 --> Model Class Initialized
INFO - 2018-03-24 00:50:09 --> Model Class Initialized
INFO - 2018-03-24 00:50:09 --> Model Class Initialized
DEBUG - 2018-03-24 00:50:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 00:50:32 --> Config Class Initialized
INFO - 2018-03-24 00:50:32 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:50:32 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:50:32 --> Utf8 Class Initialized
INFO - 2018-03-24 00:50:32 --> URI Class Initialized
INFO - 2018-03-24 00:50:32 --> Router Class Initialized
INFO - 2018-03-24 00:50:32 --> Output Class Initialized
INFO - 2018-03-24 00:50:32 --> Security Class Initialized
DEBUG - 2018-03-24 00:50:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:50:32 --> Input Class Initialized
INFO - 2018-03-24 00:50:32 --> Language Class Initialized
INFO - 2018-03-24 00:50:32 --> Loader Class Initialized
INFO - 2018-03-24 00:50:32 --> Helper loaded: url_helper
INFO - 2018-03-24 00:50:32 --> Helper loaded: form_helper
INFO - 2018-03-24 00:50:32 --> Database Driver Class Initialized
DEBUG - 2018-03-24 00:50:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 00:50:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 00:50:32 --> Form Validation Class Initialized
INFO - 2018-03-24 00:50:32 --> Model Class Initialized
INFO - 2018-03-24 00:50:32 --> Controller Class Initialized
INFO - 2018-03-24 00:50:32 --> Model Class Initialized
INFO - 2018-03-24 00:50:32 --> Model Class Initialized
INFO - 2018-03-24 00:50:32 --> Model Class Initialized
INFO - 2018-03-24 00:50:32 --> Model Class Initialized
INFO - 2018-03-24 00:50:32 --> Model Class Initialized
DEBUG - 2018-03-24 00:50:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 00:50:32 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-24 00:50:32 --> Final output sent to browser
DEBUG - 2018-03-24 00:50:32 --> Total execution time: 0.0855
INFO - 2018-03-24 00:50:32 --> Config Class Initialized
INFO - 2018-03-24 00:50:32 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:50:32 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:50:32 --> Utf8 Class Initialized
INFO - 2018-03-24 00:50:32 --> URI Class Initialized
INFO - 2018-03-24 00:50:32 --> Router Class Initialized
INFO - 2018-03-24 00:50:32 --> Output Class Initialized
INFO - 2018-03-24 00:50:32 --> Security Class Initialized
DEBUG - 2018-03-24 00:50:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:50:32 --> Input Class Initialized
INFO - 2018-03-24 00:50:32 --> Language Class Initialized
INFO - 2018-03-24 00:50:32 --> Loader Class Initialized
INFO - 2018-03-24 00:50:32 --> Helper loaded: url_helper
INFO - 2018-03-24 00:50:32 --> Helper loaded: form_helper
INFO - 2018-03-24 00:50:32 --> Database Driver Class Initialized
DEBUG - 2018-03-24 00:50:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 00:50:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 00:50:32 --> Form Validation Class Initialized
INFO - 2018-03-24 00:50:32 --> Model Class Initialized
INFO - 2018-03-24 00:50:32 --> Controller Class Initialized
INFO - 2018-03-24 00:50:32 --> Model Class Initialized
INFO - 2018-03-24 00:50:32 --> Model Class Initialized
INFO - 2018-03-24 00:50:32 --> Model Class Initialized
INFO - 2018-03-24 00:50:32 --> Model Class Initialized
INFO - 2018-03-24 00:50:32 --> Model Class Initialized
DEBUG - 2018-03-24 00:50:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 00:52:26 --> Config Class Initialized
INFO - 2018-03-24 00:52:26 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:52:26 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:52:26 --> Utf8 Class Initialized
INFO - 2018-03-24 00:52:26 --> URI Class Initialized
INFO - 2018-03-24 00:52:26 --> Router Class Initialized
INFO - 2018-03-24 00:52:26 --> Output Class Initialized
INFO - 2018-03-24 00:52:26 --> Security Class Initialized
DEBUG - 2018-03-24 00:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:52:26 --> Input Class Initialized
INFO - 2018-03-24 00:52:26 --> Language Class Initialized
INFO - 2018-03-24 00:52:26 --> Loader Class Initialized
INFO - 2018-03-24 00:52:26 --> Helper loaded: url_helper
INFO - 2018-03-24 00:52:26 --> Helper loaded: form_helper
INFO - 2018-03-24 00:52:26 --> Database Driver Class Initialized
DEBUG - 2018-03-24 00:52:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 00:52:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 00:52:26 --> Form Validation Class Initialized
INFO - 2018-03-24 00:52:26 --> Model Class Initialized
INFO - 2018-03-24 00:52:26 --> Controller Class Initialized
INFO - 2018-03-24 00:52:26 --> Model Class Initialized
INFO - 2018-03-24 00:52:26 --> Model Class Initialized
INFO - 2018-03-24 00:52:26 --> Model Class Initialized
INFO - 2018-03-24 00:52:26 --> Model Class Initialized
INFO - 2018-03-24 00:52:26 --> Model Class Initialized
DEBUG - 2018-03-24 00:52:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 00:52:26 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-24 00:52:26 --> Final output sent to browser
DEBUG - 2018-03-24 00:52:26 --> Total execution time: 0.1017
INFO - 2018-03-24 00:52:27 --> Config Class Initialized
INFO - 2018-03-24 00:52:27 --> Hooks Class Initialized
DEBUG - 2018-03-24 00:52:27 --> UTF-8 Support Enabled
INFO - 2018-03-24 00:52:27 --> Utf8 Class Initialized
INFO - 2018-03-24 00:52:27 --> URI Class Initialized
INFO - 2018-03-24 00:52:27 --> Router Class Initialized
INFO - 2018-03-24 00:52:27 --> Output Class Initialized
INFO - 2018-03-24 00:52:27 --> Security Class Initialized
DEBUG - 2018-03-24 00:52:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 00:52:27 --> Input Class Initialized
INFO - 2018-03-24 00:52:27 --> Language Class Initialized
INFO - 2018-03-24 00:52:27 --> Loader Class Initialized
INFO - 2018-03-24 00:52:27 --> Helper loaded: url_helper
INFO - 2018-03-24 00:52:27 --> Helper loaded: form_helper
INFO - 2018-03-24 00:52:27 --> Database Driver Class Initialized
DEBUG - 2018-03-24 00:52:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 00:52:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 00:52:27 --> Form Validation Class Initialized
INFO - 2018-03-24 00:52:27 --> Model Class Initialized
INFO - 2018-03-24 00:52:27 --> Controller Class Initialized
INFO - 2018-03-24 00:52:27 --> Model Class Initialized
INFO - 2018-03-24 00:52:27 --> Model Class Initialized
INFO - 2018-03-24 00:52:27 --> Model Class Initialized
INFO - 2018-03-24 00:52:27 --> Model Class Initialized
INFO - 2018-03-24 00:52:27 --> Model Class Initialized
DEBUG - 2018-03-24 00:52:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 01:06:04 --> Config Class Initialized
INFO - 2018-03-24 01:06:04 --> Hooks Class Initialized
DEBUG - 2018-03-24 01:06:04 --> UTF-8 Support Enabled
INFO - 2018-03-24 01:06:04 --> Utf8 Class Initialized
INFO - 2018-03-24 01:06:04 --> URI Class Initialized
INFO - 2018-03-24 01:06:04 --> Router Class Initialized
INFO - 2018-03-24 01:06:04 --> Output Class Initialized
INFO - 2018-03-24 01:06:04 --> Security Class Initialized
DEBUG - 2018-03-24 01:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 01:06:04 --> Input Class Initialized
INFO - 2018-03-24 01:06:04 --> Language Class Initialized
INFO - 2018-03-24 01:06:04 --> Loader Class Initialized
INFO - 2018-03-24 01:06:04 --> Helper loaded: url_helper
INFO - 2018-03-24 01:06:04 --> Helper loaded: form_helper
INFO - 2018-03-24 01:06:04 --> Database Driver Class Initialized
DEBUG - 2018-03-24 01:06:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 01:06:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 01:06:04 --> Form Validation Class Initialized
INFO - 2018-03-24 01:06:04 --> Model Class Initialized
INFO - 2018-03-24 01:06:04 --> Controller Class Initialized
INFO - 2018-03-24 01:06:04 --> Model Class Initialized
INFO - 2018-03-24 01:06:04 --> Model Class Initialized
INFO - 2018-03-24 01:06:04 --> Model Class Initialized
INFO - 2018-03-24 01:06:04 --> Model Class Initialized
DEBUG - 2018-03-24 01:06:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 01:06:04 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-24 01:06:04 --> Final output sent to browser
DEBUG - 2018-03-24 01:06:04 --> Total execution time: 0.1367
INFO - 2018-03-24 01:06:04 --> Config Class Initialized
INFO - 2018-03-24 01:06:04 --> Hooks Class Initialized
DEBUG - 2018-03-24 01:06:04 --> UTF-8 Support Enabled
INFO - 2018-03-24 01:06:04 --> Utf8 Class Initialized
INFO - 2018-03-24 01:06:04 --> URI Class Initialized
INFO - 2018-03-24 01:06:04 --> Router Class Initialized
INFO - 2018-03-24 01:06:04 --> Output Class Initialized
INFO - 2018-03-24 01:06:04 --> Security Class Initialized
DEBUG - 2018-03-24 01:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 01:06:04 --> Input Class Initialized
INFO - 2018-03-24 01:06:04 --> Language Class Initialized
INFO - 2018-03-24 01:06:04 --> Loader Class Initialized
INFO - 2018-03-24 01:06:04 --> Helper loaded: url_helper
INFO - 2018-03-24 01:06:04 --> Helper loaded: form_helper
INFO - 2018-03-24 01:06:04 --> Database Driver Class Initialized
DEBUG - 2018-03-24 01:06:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 01:06:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 01:06:04 --> Form Validation Class Initialized
INFO - 2018-03-24 01:06:04 --> Model Class Initialized
INFO - 2018-03-24 01:06:04 --> Controller Class Initialized
INFO - 2018-03-24 01:06:04 --> Model Class Initialized
INFO - 2018-03-24 01:06:04 --> Model Class Initialized
INFO - 2018-03-24 01:06:04 --> Model Class Initialized
INFO - 2018-03-24 01:06:04 --> Model Class Initialized
DEBUG - 2018-03-24 01:06:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 01:06:05 --> Config Class Initialized
INFO - 2018-03-24 01:06:05 --> Hooks Class Initialized
DEBUG - 2018-03-24 01:06:05 --> UTF-8 Support Enabled
INFO - 2018-03-24 01:06:05 --> Utf8 Class Initialized
INFO - 2018-03-24 01:06:05 --> URI Class Initialized
INFO - 2018-03-24 01:06:05 --> Router Class Initialized
INFO - 2018-03-24 01:06:05 --> Output Class Initialized
INFO - 2018-03-24 01:06:05 --> Security Class Initialized
DEBUG - 2018-03-24 01:06:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 01:06:05 --> Input Class Initialized
INFO - 2018-03-24 01:06:05 --> Language Class Initialized
INFO - 2018-03-24 01:06:05 --> Loader Class Initialized
INFO - 2018-03-24 01:06:05 --> Helper loaded: url_helper
INFO - 2018-03-24 01:06:05 --> Helper loaded: form_helper
INFO - 2018-03-24 01:06:05 --> Database Driver Class Initialized
DEBUG - 2018-03-24 01:06:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 01:06:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 01:06:05 --> Form Validation Class Initialized
INFO - 2018-03-24 01:06:05 --> Model Class Initialized
INFO - 2018-03-24 01:06:05 --> Controller Class Initialized
INFO - 2018-03-24 01:06:05 --> Model Class Initialized
INFO - 2018-03-24 01:06:05 --> Model Class Initialized
INFO - 2018-03-24 01:06:05 --> Model Class Initialized
INFO - 2018-03-24 01:06:05 --> Model Class Initialized
DEBUG - 2018-03-24 01:06:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 01:06:05 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-24 01:06:05 --> Final output sent to browser
DEBUG - 2018-03-24 01:06:05 --> Total execution time: 0.0990
INFO - 2018-03-24 01:06:05 --> Config Class Initialized
INFO - 2018-03-24 01:06:05 --> Hooks Class Initialized
DEBUG - 2018-03-24 01:06:05 --> UTF-8 Support Enabled
INFO - 2018-03-24 01:06:05 --> Utf8 Class Initialized
INFO - 2018-03-24 01:06:05 --> URI Class Initialized
INFO - 2018-03-24 01:06:05 --> Router Class Initialized
INFO - 2018-03-24 01:06:05 --> Output Class Initialized
INFO - 2018-03-24 01:06:05 --> Security Class Initialized
DEBUG - 2018-03-24 01:06:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 01:06:05 --> Input Class Initialized
INFO - 2018-03-24 01:06:05 --> Language Class Initialized
INFO - 2018-03-24 01:06:05 --> Loader Class Initialized
INFO - 2018-03-24 01:06:05 --> Helper loaded: url_helper
INFO - 2018-03-24 01:06:05 --> Helper loaded: form_helper
INFO - 2018-03-24 01:06:05 --> Database Driver Class Initialized
DEBUG - 2018-03-24 01:06:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 01:06:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 01:06:05 --> Form Validation Class Initialized
INFO - 2018-03-24 01:06:05 --> Model Class Initialized
INFO - 2018-03-24 01:06:05 --> Controller Class Initialized
INFO - 2018-03-24 01:06:05 --> Model Class Initialized
INFO - 2018-03-24 01:06:05 --> Model Class Initialized
INFO - 2018-03-24 01:06:05 --> Model Class Initialized
INFO - 2018-03-24 01:06:05 --> Model Class Initialized
DEBUG - 2018-03-24 01:06:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 01:06:08 --> Config Class Initialized
INFO - 2018-03-24 01:06:08 --> Hooks Class Initialized
DEBUG - 2018-03-24 01:06:08 --> UTF-8 Support Enabled
INFO - 2018-03-24 01:06:08 --> Utf8 Class Initialized
INFO - 2018-03-24 01:06:08 --> URI Class Initialized
INFO - 2018-03-24 01:06:08 --> Router Class Initialized
INFO - 2018-03-24 01:06:08 --> Output Class Initialized
INFO - 2018-03-24 01:06:08 --> Security Class Initialized
DEBUG - 2018-03-24 01:06:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 01:06:08 --> Input Class Initialized
INFO - 2018-03-24 01:06:08 --> Language Class Initialized
INFO - 2018-03-24 01:06:08 --> Loader Class Initialized
INFO - 2018-03-24 01:06:08 --> Helper loaded: url_helper
INFO - 2018-03-24 01:06:08 --> Helper loaded: form_helper
INFO - 2018-03-24 01:06:08 --> Database Driver Class Initialized
DEBUG - 2018-03-24 01:06:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 01:06:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 01:06:08 --> Form Validation Class Initialized
INFO - 2018-03-24 01:06:08 --> Model Class Initialized
INFO - 2018-03-24 01:06:08 --> Controller Class Initialized
INFO - 2018-03-24 01:06:08 --> Model Class Initialized
INFO - 2018-03-24 01:06:08 --> Model Class Initialized
INFO - 2018-03-24 01:06:08 --> Model Class Initialized
INFO - 2018-03-24 01:06:08 --> Model Class Initialized
DEBUG - 2018-03-24 01:06:08 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 488
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 494
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 494
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 500
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 506
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 512
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 518
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 524
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 530
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 553
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 558
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:06:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\instateccr\controlcostos\instatec_sys\core\Exceptions.php:271) D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 632
ERROR - 2018-03-24 01:06:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 635
ERROR - 2018-03-24 01:06:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\instateccr\controlcostos\instatec_sys\core\Exceptions.php:271) D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 635
INFO - 2018-03-24 01:06:09 --> Final output sent to browser
DEBUG - 2018-03-24 01:06:09 --> Total execution time: 1.1052
INFO - 2018-03-24 01:06:50 --> Config Class Initialized
INFO - 2018-03-24 01:06:50 --> Hooks Class Initialized
DEBUG - 2018-03-24 01:06:50 --> UTF-8 Support Enabled
INFO - 2018-03-24 01:06:50 --> Utf8 Class Initialized
INFO - 2018-03-24 01:06:50 --> URI Class Initialized
INFO - 2018-03-24 01:06:50 --> Router Class Initialized
INFO - 2018-03-24 01:06:50 --> Output Class Initialized
INFO - 2018-03-24 01:06:50 --> Security Class Initialized
DEBUG - 2018-03-24 01:06:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 01:06:50 --> Input Class Initialized
INFO - 2018-03-24 01:06:50 --> Language Class Initialized
INFO - 2018-03-24 01:06:50 --> Loader Class Initialized
INFO - 2018-03-24 01:06:50 --> Helper loaded: url_helper
INFO - 2018-03-24 01:06:50 --> Helper loaded: form_helper
INFO - 2018-03-24 01:06:50 --> Database Driver Class Initialized
DEBUG - 2018-03-24 01:06:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 01:06:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 01:06:50 --> Form Validation Class Initialized
INFO - 2018-03-24 01:06:51 --> Model Class Initialized
INFO - 2018-03-24 01:06:51 --> Controller Class Initialized
INFO - 2018-03-24 01:06:51 --> Model Class Initialized
INFO - 2018-03-24 01:06:51 --> Model Class Initialized
INFO - 2018-03-24 01:06:51 --> Model Class Initialized
INFO - 2018-03-24 01:06:51 --> Model Class Initialized
DEBUG - 2018-03-24 01:06:51 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$orden_comra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 506
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 553
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 558
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:51 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:06:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\instateccr\controlcostos\instatec_sys\core\Exceptions.php:271) D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 632
ERROR - 2018-03-24 01:06:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\instateccr\controlcostos\instatec_sys\core\Exceptions.php:271) D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 635
INFO - 2018-03-24 01:06:51 --> Final output sent to browser
DEBUG - 2018-03-24 01:06:51 --> Total execution time: 0.4590
INFO - 2018-03-24 01:06:52 --> Config Class Initialized
INFO - 2018-03-24 01:06:52 --> Hooks Class Initialized
DEBUG - 2018-03-24 01:06:52 --> UTF-8 Support Enabled
INFO - 2018-03-24 01:06:52 --> Utf8 Class Initialized
INFO - 2018-03-24 01:06:52 --> URI Class Initialized
INFO - 2018-03-24 01:06:52 --> Router Class Initialized
INFO - 2018-03-24 01:06:52 --> Output Class Initialized
INFO - 2018-03-24 01:06:52 --> Security Class Initialized
DEBUG - 2018-03-24 01:06:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 01:06:52 --> Input Class Initialized
INFO - 2018-03-24 01:06:52 --> Language Class Initialized
INFO - 2018-03-24 01:06:52 --> Loader Class Initialized
INFO - 2018-03-24 01:06:52 --> Helper loaded: url_helper
INFO - 2018-03-24 01:06:52 --> Helper loaded: form_helper
INFO - 2018-03-24 01:06:52 --> Database Driver Class Initialized
DEBUG - 2018-03-24 01:06:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 01:06:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 01:06:52 --> Form Validation Class Initialized
INFO - 2018-03-24 01:06:52 --> Model Class Initialized
INFO - 2018-03-24 01:06:52 --> Controller Class Initialized
INFO - 2018-03-24 01:06:52 --> Model Class Initialized
INFO - 2018-03-24 01:06:52 --> Model Class Initialized
INFO - 2018-03-24 01:06:52 --> Model Class Initialized
INFO - 2018-03-24 01:06:52 --> Model Class Initialized
DEBUG - 2018-03-24 01:06:52 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-03-24 01:06:52 --> Severity: Notice --> Undefined property: stdClass::$orden_comra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 506
ERROR - 2018-03-24 01:06:52 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 553
ERROR - 2018-03-24 01:06:52 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 558
ERROR - 2018-03-24 01:06:52 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:06:52 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:06:52 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:06:52 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:06:52 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:06:52 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:52 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:52 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:06:52 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:06:52 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:06:52 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:06:52 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:06:52 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:06:52 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:52 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:52 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:06:52 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:06:52 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:06:52 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:06:52 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:06:52 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:06:52 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:52 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:52 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:06:52 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:06:52 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:06:52 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:06:53 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:06:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\instateccr\controlcostos\instatec_sys\core\Exceptions.php:271) D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 632
ERROR - 2018-03-24 01:06:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\instateccr\controlcostos\instatec_sys\core\Exceptions.php:271) D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 635
INFO - 2018-03-24 01:06:53 --> Final output sent to browser
DEBUG - 2018-03-24 01:06:53 --> Total execution time: 0.3797
INFO - 2018-03-24 01:07:07 --> Config Class Initialized
INFO - 2018-03-24 01:07:07 --> Hooks Class Initialized
DEBUG - 2018-03-24 01:07:07 --> UTF-8 Support Enabled
INFO - 2018-03-24 01:07:07 --> Utf8 Class Initialized
INFO - 2018-03-24 01:07:07 --> URI Class Initialized
INFO - 2018-03-24 01:07:07 --> Router Class Initialized
INFO - 2018-03-24 01:07:07 --> Output Class Initialized
INFO - 2018-03-24 01:07:07 --> Security Class Initialized
DEBUG - 2018-03-24 01:07:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 01:07:07 --> Input Class Initialized
INFO - 2018-03-24 01:07:07 --> Language Class Initialized
INFO - 2018-03-24 01:07:07 --> Loader Class Initialized
INFO - 2018-03-24 01:07:07 --> Helper loaded: url_helper
INFO - 2018-03-24 01:07:07 --> Helper loaded: form_helper
INFO - 2018-03-24 01:07:07 --> Database Driver Class Initialized
DEBUG - 2018-03-24 01:07:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 01:07:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 01:07:07 --> Form Validation Class Initialized
INFO - 2018-03-24 01:07:07 --> Model Class Initialized
INFO - 2018-03-24 01:07:07 --> Controller Class Initialized
INFO - 2018-03-24 01:07:07 --> Model Class Initialized
INFO - 2018-03-24 01:07:07 --> Model Class Initialized
INFO - 2018-03-24 01:07:07 --> Model Class Initialized
INFO - 2018-03-24 01:07:07 --> Model Class Initialized
DEBUG - 2018-03-24 01:07:07 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-03-24 01:07:07 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 553
ERROR - 2018-03-24 01:07:07 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 558
ERROR - 2018-03-24 01:07:07 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:07:07 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:07:07 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:07:07 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:07:07 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:07:07 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:07:07 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:07:07 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:07:07 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:07:07 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:07:07 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:07:07 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:07:07 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:07:07 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:07:07 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:07:07 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:07:07 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:07:07 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:07:07 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:07:07 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:07:07 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:07:07 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:07:07 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:07:07 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:07:07 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:07:07 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:07:07 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:07:07 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:07:07 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:07:07 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:07:07 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:07:07 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:07:07 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:07:07 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:07:07 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:07:07 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:07:07 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:07:07 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:07:07 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:07:07 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:07:07 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:07:07 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:07:07 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:07:07 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:07:07 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:07:07 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:07:07 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:07:07 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:07:07 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:07:07 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:07:07 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:07:07 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:07:07 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:07:07 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:07:07 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:07:07 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:07:07 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:07:07 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:07:07 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:07:07 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:07:07 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:07:07 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:07:07 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:07:07 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:07:07 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:07:07 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:07:07 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:07:07 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:07:07 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:07:07 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:07:07 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:07:07 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:07:07 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:07:07 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:07:07 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:07:07 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:07:07 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:07:07 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:07:07 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:07:07 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:07:07 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:07:07 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:07:07 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:07:07 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:07:07 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:07:08 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:07:08 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\instateccr\controlcostos\instatec_sys\core\Exceptions.php:271) D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 632
ERROR - 2018-03-24 01:07:08 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\instateccr\controlcostos\instatec_sys\core\Exceptions.php:271) D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 635
INFO - 2018-03-24 01:07:08 --> Final output sent to browser
DEBUG - 2018-03-24 01:07:08 --> Total execution time: 0.3880
INFO - 2018-03-24 01:07:38 --> Config Class Initialized
INFO - 2018-03-24 01:07:38 --> Hooks Class Initialized
DEBUG - 2018-03-24 01:07:38 --> UTF-8 Support Enabled
INFO - 2018-03-24 01:07:38 --> Utf8 Class Initialized
INFO - 2018-03-24 01:07:38 --> URI Class Initialized
INFO - 2018-03-24 01:07:38 --> Router Class Initialized
INFO - 2018-03-24 01:07:38 --> Output Class Initialized
INFO - 2018-03-24 01:07:38 --> Security Class Initialized
DEBUG - 2018-03-24 01:07:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 01:07:38 --> Input Class Initialized
INFO - 2018-03-24 01:07:38 --> Language Class Initialized
INFO - 2018-03-24 01:07:38 --> Loader Class Initialized
INFO - 2018-03-24 01:07:38 --> Helper loaded: url_helper
INFO - 2018-03-24 01:07:38 --> Helper loaded: form_helper
INFO - 2018-03-24 01:07:38 --> Database Driver Class Initialized
DEBUG - 2018-03-24 01:07:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 01:07:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 01:07:38 --> Form Validation Class Initialized
INFO - 2018-03-24 01:07:38 --> Model Class Initialized
INFO - 2018-03-24 01:07:38 --> Controller Class Initialized
INFO - 2018-03-24 01:07:38 --> Model Class Initialized
INFO - 2018-03-24 01:07:38 --> Model Class Initialized
INFO - 2018-03-24 01:07:38 --> Model Class Initialized
INFO - 2018-03-24 01:07:38 --> Model Class Initialized
DEBUG - 2018-03-24 01:07:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 01:07:55 --> Config Class Initialized
INFO - 2018-03-24 01:07:55 --> Hooks Class Initialized
DEBUG - 2018-03-24 01:07:55 --> UTF-8 Support Enabled
INFO - 2018-03-24 01:07:55 --> Utf8 Class Initialized
INFO - 2018-03-24 01:07:55 --> URI Class Initialized
INFO - 2018-03-24 01:07:55 --> Router Class Initialized
INFO - 2018-03-24 01:07:55 --> Output Class Initialized
INFO - 2018-03-24 01:07:55 --> Security Class Initialized
DEBUG - 2018-03-24 01:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 01:07:55 --> Input Class Initialized
INFO - 2018-03-24 01:07:55 --> Language Class Initialized
INFO - 2018-03-24 01:07:55 --> Loader Class Initialized
INFO - 2018-03-24 01:07:55 --> Helper loaded: url_helper
INFO - 2018-03-24 01:07:55 --> Helper loaded: form_helper
INFO - 2018-03-24 01:07:55 --> Database Driver Class Initialized
DEBUG - 2018-03-24 01:07:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 01:07:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 01:07:55 --> Form Validation Class Initialized
INFO - 2018-03-24 01:07:55 --> Model Class Initialized
INFO - 2018-03-24 01:07:55 --> Controller Class Initialized
INFO - 2018-03-24 01:07:55 --> Model Class Initialized
INFO - 2018-03-24 01:07:55 --> Model Class Initialized
INFO - 2018-03-24 01:07:55 --> Model Class Initialized
INFO - 2018-03-24 01:07:55 --> Model Class Initialized
DEBUG - 2018-03-24 01:07:55 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 553
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 558
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 578
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined index: group_by D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 583
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:07:55 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:07:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\instateccr\controlcostos\instatec_sys\core\Exceptions.php:271) D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 632
ERROR - 2018-03-24 01:07:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\instateccr\controlcostos\instatec_sys\core\Exceptions.php:271) D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 635
INFO - 2018-03-24 01:07:55 --> Final output sent to browser
DEBUG - 2018-03-24 01:07:55 --> Total execution time: 0.4915
INFO - 2018-03-24 01:10:23 --> Config Class Initialized
INFO - 2018-03-24 01:10:23 --> Hooks Class Initialized
DEBUG - 2018-03-24 01:10:23 --> UTF-8 Support Enabled
INFO - 2018-03-24 01:10:23 --> Utf8 Class Initialized
INFO - 2018-03-24 01:10:23 --> URI Class Initialized
INFO - 2018-03-24 01:10:23 --> Router Class Initialized
INFO - 2018-03-24 01:10:23 --> Output Class Initialized
INFO - 2018-03-24 01:10:23 --> Security Class Initialized
DEBUG - 2018-03-24 01:10:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 01:10:23 --> Input Class Initialized
INFO - 2018-03-24 01:10:23 --> Language Class Initialized
INFO - 2018-03-24 01:10:23 --> Loader Class Initialized
INFO - 2018-03-24 01:10:23 --> Helper loaded: url_helper
INFO - 2018-03-24 01:10:23 --> Helper loaded: form_helper
INFO - 2018-03-24 01:10:23 --> Database Driver Class Initialized
DEBUG - 2018-03-24 01:10:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 01:10:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 01:10:23 --> Form Validation Class Initialized
INFO - 2018-03-24 01:10:23 --> Model Class Initialized
INFO - 2018-03-24 01:10:23 --> Controller Class Initialized
INFO - 2018-03-24 01:10:23 --> Model Class Initialized
INFO - 2018-03-24 01:10:23 --> Model Class Initialized
INFO - 2018-03-24 01:10:23 --> Model Class Initialized
INFO - 2018-03-24 01:10:23 --> Model Class Initialized
DEBUG - 2018-03-24 01:10:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 01:11:27 --> Config Class Initialized
INFO - 2018-03-24 01:11:27 --> Hooks Class Initialized
DEBUG - 2018-03-24 01:11:27 --> UTF-8 Support Enabled
INFO - 2018-03-24 01:11:27 --> Utf8 Class Initialized
INFO - 2018-03-24 01:11:27 --> URI Class Initialized
INFO - 2018-03-24 01:11:27 --> Router Class Initialized
INFO - 2018-03-24 01:11:27 --> Output Class Initialized
INFO - 2018-03-24 01:11:27 --> Security Class Initialized
DEBUG - 2018-03-24 01:11:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 01:11:27 --> Input Class Initialized
INFO - 2018-03-24 01:11:27 --> Language Class Initialized
INFO - 2018-03-24 01:11:27 --> Loader Class Initialized
INFO - 2018-03-24 01:11:27 --> Helper loaded: url_helper
INFO - 2018-03-24 01:11:27 --> Helper loaded: form_helper
INFO - 2018-03-24 01:11:27 --> Database Driver Class Initialized
DEBUG - 2018-03-24 01:11:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 01:11:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 01:11:27 --> Form Validation Class Initialized
INFO - 2018-03-24 01:11:27 --> Model Class Initialized
INFO - 2018-03-24 01:11:27 --> Controller Class Initialized
INFO - 2018-03-24 01:11:27 --> Model Class Initialized
INFO - 2018-03-24 01:11:27 --> Model Class Initialized
INFO - 2018-03-24 01:11:27 --> Model Class Initialized
INFO - 2018-03-24 01:11:27 --> Model Class Initialized
DEBUG - 2018-03-24 01:11:27 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 589
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 592
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 595
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_horas D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_horas_extra D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 601
ERROR - 2018-03-24 01:11:27 --> Severity: Notice --> Undefined property: stdClass::$total_costo D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 602
ERROR - 2018-03-24 01:11:27 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\instateccr\controlcostos\instatec_sys\core\Exceptions.php:271) D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 632
ERROR - 2018-03-24 01:11:27 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\instateccr\controlcostos\instatec_sys\core\Exceptions.php:271) D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 635
INFO - 2018-03-24 01:11:27 --> Final output sent to browser
DEBUG - 2018-03-24 01:11:27 --> Total execution time: 0.3880
INFO - 2018-03-24 01:13:45 --> Config Class Initialized
INFO - 2018-03-24 01:13:45 --> Hooks Class Initialized
DEBUG - 2018-03-24 01:13:45 --> UTF-8 Support Enabled
INFO - 2018-03-24 01:13:45 --> Utf8 Class Initialized
INFO - 2018-03-24 01:13:45 --> URI Class Initialized
INFO - 2018-03-24 01:13:45 --> Router Class Initialized
INFO - 2018-03-24 01:13:45 --> Output Class Initialized
INFO - 2018-03-24 01:13:45 --> Security Class Initialized
DEBUG - 2018-03-24 01:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 01:13:45 --> Input Class Initialized
INFO - 2018-03-24 01:13:45 --> Language Class Initialized
INFO - 2018-03-24 01:13:45 --> Loader Class Initialized
INFO - 2018-03-24 01:13:45 --> Helper loaded: url_helper
INFO - 2018-03-24 01:13:45 --> Helper loaded: form_helper
INFO - 2018-03-24 01:13:45 --> Database Driver Class Initialized
DEBUG - 2018-03-24 01:13:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 01:13:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 01:13:45 --> Form Validation Class Initialized
INFO - 2018-03-24 01:13:45 --> Model Class Initialized
INFO - 2018-03-24 01:13:45 --> Controller Class Initialized
INFO - 2018-03-24 01:13:45 --> Model Class Initialized
INFO - 2018-03-24 01:13:45 --> Model Class Initialized
INFO - 2018-03-24 01:13:45 --> Model Class Initialized
INFO - 2018-03-24 01:13:45 --> Model Class Initialized
DEBUG - 2018-03-24 01:13:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 01:13:56 --> Config Class Initialized
INFO - 2018-03-24 01:13:56 --> Hooks Class Initialized
DEBUG - 2018-03-24 01:13:56 --> UTF-8 Support Enabled
INFO - 2018-03-24 01:13:56 --> Utf8 Class Initialized
INFO - 2018-03-24 01:13:56 --> URI Class Initialized
INFO - 2018-03-24 01:13:56 --> Router Class Initialized
INFO - 2018-03-24 01:13:56 --> Output Class Initialized
INFO - 2018-03-24 01:13:56 --> Security Class Initialized
DEBUG - 2018-03-24 01:13:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 01:13:56 --> Input Class Initialized
INFO - 2018-03-24 01:13:56 --> Language Class Initialized
INFO - 2018-03-24 01:13:56 --> Loader Class Initialized
INFO - 2018-03-24 01:13:56 --> Helper loaded: url_helper
INFO - 2018-03-24 01:13:56 --> Helper loaded: form_helper
INFO - 2018-03-24 01:13:56 --> Database Driver Class Initialized
DEBUG - 2018-03-24 01:13:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 01:13:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 01:13:56 --> Form Validation Class Initialized
INFO - 2018-03-24 01:13:56 --> Model Class Initialized
INFO - 2018-03-24 01:13:56 --> Controller Class Initialized
INFO - 2018-03-24 01:13:56 --> Model Class Initialized
INFO - 2018-03-24 01:13:56 --> Model Class Initialized
INFO - 2018-03-24 01:13:56 --> Model Class Initialized
INFO - 2018-03-24 01:13:56 --> Model Class Initialized
DEBUG - 2018-03-24 01:13:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 01:14:44 --> Config Class Initialized
INFO - 2018-03-24 01:14:44 --> Hooks Class Initialized
DEBUG - 2018-03-24 01:14:44 --> UTF-8 Support Enabled
INFO - 2018-03-24 01:14:44 --> Utf8 Class Initialized
INFO - 2018-03-24 01:14:44 --> URI Class Initialized
INFO - 2018-03-24 01:14:44 --> Router Class Initialized
INFO - 2018-03-24 01:14:44 --> Output Class Initialized
INFO - 2018-03-24 01:14:44 --> Security Class Initialized
DEBUG - 2018-03-24 01:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 01:14:44 --> Input Class Initialized
INFO - 2018-03-24 01:14:44 --> Language Class Initialized
INFO - 2018-03-24 01:14:44 --> Loader Class Initialized
INFO - 2018-03-24 01:14:44 --> Helper loaded: url_helper
INFO - 2018-03-24 01:14:44 --> Helper loaded: form_helper
INFO - 2018-03-24 01:14:44 --> Database Driver Class Initialized
DEBUG - 2018-03-24 01:14:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 01:14:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 01:14:44 --> Form Validation Class Initialized
INFO - 2018-03-24 01:14:44 --> Model Class Initialized
INFO - 2018-03-24 01:14:44 --> Controller Class Initialized
INFO - 2018-03-24 01:14:44 --> Model Class Initialized
INFO - 2018-03-24 01:14:44 --> Model Class Initialized
INFO - 2018-03-24 01:14:44 --> Model Class Initialized
INFO - 2018-03-24 01:14:44 --> Model Class Initialized
DEBUG - 2018-03-24 01:14:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 01:15:00 --> Config Class Initialized
INFO - 2018-03-24 01:15:00 --> Hooks Class Initialized
DEBUG - 2018-03-24 01:15:00 --> UTF-8 Support Enabled
INFO - 2018-03-24 01:15:00 --> Utf8 Class Initialized
INFO - 2018-03-24 01:15:00 --> URI Class Initialized
INFO - 2018-03-24 01:15:00 --> Router Class Initialized
INFO - 2018-03-24 01:15:00 --> Output Class Initialized
INFO - 2018-03-24 01:15:00 --> Security Class Initialized
DEBUG - 2018-03-24 01:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 01:15:00 --> Input Class Initialized
INFO - 2018-03-24 01:15:00 --> Language Class Initialized
INFO - 2018-03-24 01:15:00 --> Loader Class Initialized
INFO - 2018-03-24 01:15:00 --> Helper loaded: url_helper
INFO - 2018-03-24 01:15:00 --> Helper loaded: form_helper
INFO - 2018-03-24 01:15:00 --> Database Driver Class Initialized
DEBUG - 2018-03-24 01:15:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 01:15:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 01:15:00 --> Form Validation Class Initialized
INFO - 2018-03-24 01:15:00 --> Model Class Initialized
INFO - 2018-03-24 01:15:00 --> Controller Class Initialized
INFO - 2018-03-24 01:15:00 --> Model Class Initialized
INFO - 2018-03-24 01:15:00 --> Model Class Initialized
INFO - 2018-03-24 01:15:00 --> Model Class Initialized
INFO - 2018-03-24 01:15:00 --> Model Class Initialized
DEBUG - 2018-03-24 01:15:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 01:15:00 --> Final output sent to browser
DEBUG - 2018-03-24 01:15:00 --> Total execution time: 0.2267
INFO - 2018-03-24 01:16:31 --> Config Class Initialized
INFO - 2018-03-24 01:16:31 --> Hooks Class Initialized
DEBUG - 2018-03-24 01:16:31 --> UTF-8 Support Enabled
INFO - 2018-03-24 01:16:31 --> Utf8 Class Initialized
INFO - 2018-03-24 01:16:31 --> URI Class Initialized
INFO - 2018-03-24 01:16:31 --> Router Class Initialized
INFO - 2018-03-24 01:16:31 --> Output Class Initialized
INFO - 2018-03-24 01:16:31 --> Security Class Initialized
DEBUG - 2018-03-24 01:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 01:16:31 --> Input Class Initialized
INFO - 2018-03-24 01:16:31 --> Language Class Initialized
INFO - 2018-03-24 01:16:31 --> Loader Class Initialized
INFO - 2018-03-24 01:16:31 --> Helper loaded: url_helper
INFO - 2018-03-24 01:16:31 --> Helper loaded: form_helper
INFO - 2018-03-24 01:16:31 --> Database Driver Class Initialized
DEBUG - 2018-03-24 01:16:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 01:16:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 01:16:31 --> Form Validation Class Initialized
INFO - 2018-03-24 01:16:31 --> Model Class Initialized
INFO - 2018-03-24 01:16:31 --> Controller Class Initialized
INFO - 2018-03-24 01:16:31 --> Model Class Initialized
INFO - 2018-03-24 01:16:31 --> Model Class Initialized
INFO - 2018-03-24 01:16:31 --> Model Class Initialized
INFO - 2018-03-24 01:16:31 --> Model Class Initialized
DEBUG - 2018-03-24 01:16:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 01:16:31 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-24 01:16:31 --> Final output sent to browser
DEBUG - 2018-03-24 01:16:31 --> Total execution time: 0.0952
INFO - 2018-03-24 01:16:31 --> Config Class Initialized
INFO - 2018-03-24 01:16:31 --> Hooks Class Initialized
DEBUG - 2018-03-24 01:16:31 --> UTF-8 Support Enabled
INFO - 2018-03-24 01:16:31 --> Utf8 Class Initialized
INFO - 2018-03-24 01:16:31 --> URI Class Initialized
INFO - 2018-03-24 01:16:31 --> Router Class Initialized
INFO - 2018-03-24 01:16:31 --> Output Class Initialized
INFO - 2018-03-24 01:16:31 --> Security Class Initialized
DEBUG - 2018-03-24 01:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 01:16:31 --> Input Class Initialized
INFO - 2018-03-24 01:16:31 --> Language Class Initialized
INFO - 2018-03-24 01:16:31 --> Loader Class Initialized
INFO - 2018-03-24 01:16:31 --> Helper loaded: url_helper
INFO - 2018-03-24 01:16:31 --> Helper loaded: form_helper
INFO - 2018-03-24 01:16:31 --> Database Driver Class Initialized
DEBUG - 2018-03-24 01:16:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 01:16:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 01:16:31 --> Form Validation Class Initialized
INFO - 2018-03-24 01:16:31 --> Model Class Initialized
INFO - 2018-03-24 01:16:31 --> Controller Class Initialized
INFO - 2018-03-24 01:16:31 --> Model Class Initialized
INFO - 2018-03-24 01:16:31 --> Model Class Initialized
INFO - 2018-03-24 01:16:31 --> Model Class Initialized
INFO - 2018-03-24 01:16:31 --> Model Class Initialized
DEBUG - 2018-03-24 01:16:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 01:16:34 --> Config Class Initialized
INFO - 2018-03-24 01:16:34 --> Hooks Class Initialized
DEBUG - 2018-03-24 01:16:34 --> UTF-8 Support Enabled
INFO - 2018-03-24 01:16:34 --> Utf8 Class Initialized
INFO - 2018-03-24 01:16:34 --> URI Class Initialized
INFO - 2018-03-24 01:16:34 --> Router Class Initialized
INFO - 2018-03-24 01:16:34 --> Output Class Initialized
INFO - 2018-03-24 01:16:34 --> Security Class Initialized
DEBUG - 2018-03-24 01:16:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 01:16:34 --> Input Class Initialized
INFO - 2018-03-24 01:16:34 --> Language Class Initialized
INFO - 2018-03-24 01:16:34 --> Loader Class Initialized
INFO - 2018-03-24 01:16:34 --> Helper loaded: url_helper
INFO - 2018-03-24 01:16:34 --> Helper loaded: form_helper
INFO - 2018-03-24 01:16:34 --> Database Driver Class Initialized
DEBUG - 2018-03-24 01:16:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 01:16:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 01:16:34 --> Form Validation Class Initialized
INFO - 2018-03-24 01:16:34 --> Model Class Initialized
INFO - 2018-03-24 01:16:34 --> Controller Class Initialized
INFO - 2018-03-24 01:16:34 --> Model Class Initialized
INFO - 2018-03-24 01:16:34 --> Model Class Initialized
INFO - 2018-03-24 01:16:34 --> Model Class Initialized
INFO - 2018-03-24 01:16:34 --> Model Class Initialized
DEBUG - 2018-03-24 01:16:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 01:16:34 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-24 01:16:34 --> Final output sent to browser
DEBUG - 2018-03-24 01:16:34 --> Total execution time: 0.1034
INFO - 2018-03-24 01:16:34 --> Config Class Initialized
INFO - 2018-03-24 01:16:34 --> Hooks Class Initialized
DEBUG - 2018-03-24 01:16:34 --> UTF-8 Support Enabled
INFO - 2018-03-24 01:16:34 --> Utf8 Class Initialized
INFO - 2018-03-24 01:16:34 --> URI Class Initialized
INFO - 2018-03-24 01:16:34 --> Router Class Initialized
INFO - 2018-03-24 01:16:34 --> Output Class Initialized
INFO - 2018-03-24 01:16:34 --> Security Class Initialized
DEBUG - 2018-03-24 01:16:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 01:16:34 --> Input Class Initialized
INFO - 2018-03-24 01:16:34 --> Language Class Initialized
INFO - 2018-03-24 01:16:34 --> Loader Class Initialized
INFO - 2018-03-24 01:16:34 --> Helper loaded: url_helper
INFO - 2018-03-24 01:16:34 --> Helper loaded: form_helper
INFO - 2018-03-24 01:16:34 --> Database Driver Class Initialized
DEBUG - 2018-03-24 01:16:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 01:16:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 01:16:34 --> Form Validation Class Initialized
INFO - 2018-03-24 01:16:34 --> Model Class Initialized
INFO - 2018-03-24 01:16:34 --> Controller Class Initialized
INFO - 2018-03-24 01:16:34 --> Model Class Initialized
INFO - 2018-03-24 01:16:34 --> Model Class Initialized
INFO - 2018-03-24 01:16:34 --> Model Class Initialized
INFO - 2018-03-24 01:16:34 --> Model Class Initialized
DEBUG - 2018-03-24 01:16:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 01:16:37 --> Config Class Initialized
INFO - 2018-03-24 01:16:37 --> Hooks Class Initialized
DEBUG - 2018-03-24 01:16:37 --> UTF-8 Support Enabled
INFO - 2018-03-24 01:16:37 --> Utf8 Class Initialized
INFO - 2018-03-24 01:16:37 --> URI Class Initialized
INFO - 2018-03-24 01:16:37 --> Router Class Initialized
INFO - 2018-03-24 01:16:37 --> Output Class Initialized
INFO - 2018-03-24 01:16:37 --> Security Class Initialized
DEBUG - 2018-03-24 01:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 01:16:37 --> Input Class Initialized
INFO - 2018-03-24 01:16:37 --> Language Class Initialized
INFO - 2018-03-24 01:16:37 --> Loader Class Initialized
INFO - 2018-03-24 01:16:37 --> Helper loaded: url_helper
INFO - 2018-03-24 01:16:37 --> Helper loaded: form_helper
INFO - 2018-03-24 01:16:37 --> Database Driver Class Initialized
DEBUG - 2018-03-24 01:16:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 01:16:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 01:16:37 --> Form Validation Class Initialized
INFO - 2018-03-24 01:16:37 --> Model Class Initialized
INFO - 2018-03-24 01:16:37 --> Controller Class Initialized
INFO - 2018-03-24 01:16:37 --> Model Class Initialized
INFO - 2018-03-24 01:16:37 --> Model Class Initialized
INFO - 2018-03-24 01:16:37 --> Model Class Initialized
INFO - 2018-03-24 01:16:37 --> Model Class Initialized
DEBUG - 2018-03-24 01:16:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 01:16:38 --> Final output sent to browser
DEBUG - 2018-03-24 01:16:38 --> Total execution time: 0.2619
INFO - 2018-03-24 01:18:15 --> Config Class Initialized
INFO - 2018-03-24 01:18:15 --> Hooks Class Initialized
DEBUG - 2018-03-24 01:18:15 --> UTF-8 Support Enabled
INFO - 2018-03-24 01:18:15 --> Utf8 Class Initialized
INFO - 2018-03-24 01:18:15 --> URI Class Initialized
INFO - 2018-03-24 01:18:15 --> Router Class Initialized
INFO - 2018-03-24 01:18:15 --> Output Class Initialized
INFO - 2018-03-24 01:18:15 --> Security Class Initialized
DEBUG - 2018-03-24 01:18:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 01:18:15 --> Input Class Initialized
INFO - 2018-03-24 01:18:15 --> Language Class Initialized
INFO - 2018-03-24 01:18:15 --> Loader Class Initialized
INFO - 2018-03-24 01:18:15 --> Helper loaded: url_helper
INFO - 2018-03-24 01:18:15 --> Helper loaded: form_helper
INFO - 2018-03-24 01:18:15 --> Database Driver Class Initialized
DEBUG - 2018-03-24 01:18:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 01:18:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 01:18:15 --> Form Validation Class Initialized
INFO - 2018-03-24 01:18:15 --> Model Class Initialized
INFO - 2018-03-24 01:18:15 --> Controller Class Initialized
INFO - 2018-03-24 01:18:15 --> Model Class Initialized
INFO - 2018-03-24 01:18:15 --> Model Class Initialized
INFO - 2018-03-24 01:18:15 --> Model Class Initialized
INFO - 2018-03-24 01:18:15 --> Model Class Initialized
DEBUG - 2018-03-24 01:18:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 01:18:17 --> Config Class Initialized
INFO - 2018-03-24 01:18:17 --> Hooks Class Initialized
DEBUG - 2018-03-24 01:18:17 --> UTF-8 Support Enabled
INFO - 2018-03-24 01:18:17 --> Utf8 Class Initialized
INFO - 2018-03-24 01:18:17 --> URI Class Initialized
INFO - 2018-03-24 01:18:17 --> Router Class Initialized
INFO - 2018-03-24 01:18:17 --> Output Class Initialized
INFO - 2018-03-24 01:18:17 --> Security Class Initialized
DEBUG - 2018-03-24 01:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 01:18:17 --> Input Class Initialized
INFO - 2018-03-24 01:18:17 --> Language Class Initialized
INFO - 2018-03-24 01:18:17 --> Loader Class Initialized
INFO - 2018-03-24 01:18:17 --> Helper loaded: url_helper
INFO - 2018-03-24 01:18:17 --> Helper loaded: form_helper
INFO - 2018-03-24 01:18:17 --> Database Driver Class Initialized
DEBUG - 2018-03-24 01:18:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 01:18:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 01:18:17 --> Form Validation Class Initialized
INFO - 2018-03-24 01:18:17 --> Model Class Initialized
INFO - 2018-03-24 01:18:17 --> Controller Class Initialized
INFO - 2018-03-24 01:18:17 --> Model Class Initialized
INFO - 2018-03-24 01:18:17 --> Model Class Initialized
INFO - 2018-03-24 01:18:17 --> Model Class Initialized
INFO - 2018-03-24 01:18:17 --> Model Class Initialized
DEBUG - 2018-03-24 01:18:17 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-03-24 01:18:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 579
ERROR - 2018-03-24 01:18:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 585
ERROR - 2018-03-24 01:18:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 588
ERROR - 2018-03-24 01:18:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 591
ERROR - 2018-03-24 01:18:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 597
ERROR - 2018-03-24 01:18:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 597
ERROR - 2018-03-24 01:18:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 598
ERROR - 2018-03-24 01:18:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 579
ERROR - 2018-03-24 01:18:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 585
ERROR - 2018-03-24 01:18:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 588
ERROR - 2018-03-24 01:18:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 591
ERROR - 2018-03-24 01:18:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 597
ERROR - 2018-03-24 01:18:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 597
ERROR - 2018-03-24 01:18:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 598
ERROR - 2018-03-24 01:18:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 579
ERROR - 2018-03-24 01:18:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 585
ERROR - 2018-03-24 01:18:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 588
ERROR - 2018-03-24 01:18:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 591
ERROR - 2018-03-24 01:18:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 597
ERROR - 2018-03-24 01:18:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 597
ERROR - 2018-03-24 01:18:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 598
ERROR - 2018-03-24 01:18:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\instateccr\controlcostos\instatec_sys\core\Exceptions.php:271) D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 628
ERROR - 2018-03-24 01:18:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\instateccr\controlcostos\instatec_sys\core\Exceptions.php:271) D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Reporte.php 631
INFO - 2018-03-24 01:18:18 --> Final output sent to browser
DEBUG - 2018-03-24 01:18:18 --> Total execution time: 0.3772
INFO - 2018-03-24 01:19:05 --> Config Class Initialized
INFO - 2018-03-24 01:19:05 --> Hooks Class Initialized
DEBUG - 2018-03-24 01:19:05 --> UTF-8 Support Enabled
INFO - 2018-03-24 01:19:05 --> Utf8 Class Initialized
INFO - 2018-03-24 01:19:05 --> URI Class Initialized
INFO - 2018-03-24 01:19:05 --> Router Class Initialized
INFO - 2018-03-24 01:19:05 --> Output Class Initialized
INFO - 2018-03-24 01:19:05 --> Security Class Initialized
DEBUG - 2018-03-24 01:19:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 01:19:05 --> Input Class Initialized
INFO - 2018-03-24 01:19:05 --> Language Class Initialized
INFO - 2018-03-24 01:19:05 --> Loader Class Initialized
INFO - 2018-03-24 01:19:05 --> Helper loaded: url_helper
INFO - 2018-03-24 01:19:05 --> Helper loaded: form_helper
INFO - 2018-03-24 01:19:05 --> Database Driver Class Initialized
DEBUG - 2018-03-24 01:19:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 01:19:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 01:19:05 --> Form Validation Class Initialized
INFO - 2018-03-24 01:19:05 --> Model Class Initialized
INFO - 2018-03-24 01:19:05 --> Controller Class Initialized
INFO - 2018-03-24 01:19:05 --> Model Class Initialized
INFO - 2018-03-24 01:19:05 --> Model Class Initialized
INFO - 2018-03-24 01:19:05 --> Model Class Initialized
INFO - 2018-03-24 01:19:05 --> Model Class Initialized
DEBUG - 2018-03-24 01:19:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 01:19:44 --> Config Class Initialized
INFO - 2018-03-24 01:19:44 --> Hooks Class Initialized
DEBUG - 2018-03-24 01:19:44 --> UTF-8 Support Enabled
INFO - 2018-03-24 01:19:44 --> Utf8 Class Initialized
INFO - 2018-03-24 01:19:44 --> URI Class Initialized
INFO - 2018-03-24 01:19:44 --> Router Class Initialized
INFO - 2018-03-24 01:19:44 --> Output Class Initialized
INFO - 2018-03-24 01:19:44 --> Security Class Initialized
DEBUG - 2018-03-24 01:19:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 01:19:44 --> Input Class Initialized
INFO - 2018-03-24 01:19:44 --> Language Class Initialized
INFO - 2018-03-24 01:19:44 --> Loader Class Initialized
INFO - 2018-03-24 01:19:44 --> Helper loaded: url_helper
INFO - 2018-03-24 01:19:44 --> Helper loaded: form_helper
INFO - 2018-03-24 01:19:44 --> Database Driver Class Initialized
DEBUG - 2018-03-24 01:19:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 01:19:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 01:19:44 --> Form Validation Class Initialized
INFO - 2018-03-24 01:19:44 --> Model Class Initialized
INFO - 2018-03-24 01:19:44 --> Controller Class Initialized
INFO - 2018-03-24 01:19:44 --> Model Class Initialized
INFO - 2018-03-24 01:19:44 --> Model Class Initialized
INFO - 2018-03-24 01:19:44 --> Model Class Initialized
INFO - 2018-03-24 01:19:44 --> Model Class Initialized
DEBUG - 2018-03-24 01:19:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 01:21:09 --> Config Class Initialized
INFO - 2018-03-24 01:21:09 --> Hooks Class Initialized
DEBUG - 2018-03-24 01:21:09 --> UTF-8 Support Enabled
INFO - 2018-03-24 01:21:09 --> Utf8 Class Initialized
INFO - 2018-03-24 01:21:09 --> URI Class Initialized
INFO - 2018-03-24 01:21:09 --> Router Class Initialized
INFO - 2018-03-24 01:21:09 --> Output Class Initialized
INFO - 2018-03-24 01:21:09 --> Security Class Initialized
DEBUG - 2018-03-24 01:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 01:21:09 --> Input Class Initialized
INFO - 2018-03-24 01:21:09 --> Language Class Initialized
INFO - 2018-03-24 01:21:09 --> Loader Class Initialized
INFO - 2018-03-24 01:21:09 --> Helper loaded: url_helper
INFO - 2018-03-24 01:21:09 --> Helper loaded: form_helper
INFO - 2018-03-24 01:21:09 --> Database Driver Class Initialized
DEBUG - 2018-03-24 01:21:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 01:21:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 01:21:09 --> Form Validation Class Initialized
INFO - 2018-03-24 01:21:09 --> Model Class Initialized
INFO - 2018-03-24 01:21:09 --> Controller Class Initialized
INFO - 2018-03-24 01:21:09 --> Model Class Initialized
INFO - 2018-03-24 01:21:09 --> Model Class Initialized
INFO - 2018-03-24 01:21:09 --> Model Class Initialized
INFO - 2018-03-24 01:21:09 --> Model Class Initialized
DEBUG - 2018-03-24 01:21:09 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-03-24 01:21:09 --> Severity: Warning --> Creating default object from empty value D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1716
ERROR - 2018-03-24 01:21:09 --> Severity: Warning --> Creating default object from empty value D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1716
ERROR - 2018-03-24 01:21:09 --> Severity: Warning --> Creating default object from empty value D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1716
INFO - 2018-03-24 01:21:50 --> Config Class Initialized
INFO - 2018-03-24 01:21:50 --> Hooks Class Initialized
DEBUG - 2018-03-24 01:21:50 --> UTF-8 Support Enabled
INFO - 2018-03-24 01:21:50 --> Utf8 Class Initialized
INFO - 2018-03-24 01:21:50 --> URI Class Initialized
INFO - 2018-03-24 01:21:50 --> Router Class Initialized
INFO - 2018-03-24 01:21:50 --> Output Class Initialized
INFO - 2018-03-24 01:21:50 --> Security Class Initialized
DEBUG - 2018-03-24 01:21:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 01:21:50 --> Input Class Initialized
INFO - 2018-03-24 01:21:50 --> Language Class Initialized
INFO - 2018-03-24 01:21:50 --> Loader Class Initialized
INFO - 2018-03-24 01:21:50 --> Helper loaded: url_helper
INFO - 2018-03-24 01:21:50 --> Helper loaded: form_helper
INFO - 2018-03-24 01:21:50 --> Database Driver Class Initialized
DEBUG - 2018-03-24 01:21:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 01:21:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 01:21:50 --> Form Validation Class Initialized
INFO - 2018-03-24 01:21:50 --> Model Class Initialized
INFO - 2018-03-24 01:21:50 --> Controller Class Initialized
INFO - 2018-03-24 01:21:50 --> Model Class Initialized
INFO - 2018-03-24 01:21:50 --> Model Class Initialized
INFO - 2018-03-24 01:21:50 --> Model Class Initialized
INFO - 2018-03-24 01:21:50 --> Model Class Initialized
DEBUG - 2018-03-24 01:21:50 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-03-24 01:21:50 --> Severity: Error --> Call to undefined function Object() D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_proyecto.php 1716
INFO - 2018-03-24 01:24:32 --> Config Class Initialized
INFO - 2018-03-24 01:24:32 --> Hooks Class Initialized
DEBUG - 2018-03-24 01:24:32 --> UTF-8 Support Enabled
INFO - 2018-03-24 01:24:32 --> Utf8 Class Initialized
INFO - 2018-03-24 01:24:32 --> URI Class Initialized
INFO - 2018-03-24 01:24:32 --> Router Class Initialized
INFO - 2018-03-24 01:24:32 --> Output Class Initialized
INFO - 2018-03-24 01:24:32 --> Security Class Initialized
DEBUG - 2018-03-24 01:24:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 01:24:32 --> Input Class Initialized
INFO - 2018-03-24 01:24:32 --> Language Class Initialized
INFO - 2018-03-24 01:24:33 --> Loader Class Initialized
INFO - 2018-03-24 01:24:33 --> Helper loaded: url_helper
INFO - 2018-03-24 01:24:33 --> Helper loaded: form_helper
INFO - 2018-03-24 01:24:33 --> Database Driver Class Initialized
DEBUG - 2018-03-24 01:24:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 01:24:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 01:24:33 --> Form Validation Class Initialized
INFO - 2018-03-24 01:24:33 --> Model Class Initialized
INFO - 2018-03-24 01:24:33 --> Controller Class Initialized
INFO - 2018-03-24 01:24:33 --> Model Class Initialized
INFO - 2018-03-24 01:24:33 --> Model Class Initialized
INFO - 2018-03-24 01:24:33 --> Model Class Initialized
INFO - 2018-03-24 01:24:33 --> Model Class Initialized
DEBUG - 2018-03-24 01:24:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 01:24:46 --> Config Class Initialized
INFO - 2018-03-24 01:24:46 --> Hooks Class Initialized
DEBUG - 2018-03-24 01:24:46 --> UTF-8 Support Enabled
INFO - 2018-03-24 01:24:46 --> Utf8 Class Initialized
INFO - 2018-03-24 01:24:46 --> URI Class Initialized
INFO - 2018-03-24 01:24:46 --> Router Class Initialized
INFO - 2018-03-24 01:24:46 --> Output Class Initialized
INFO - 2018-03-24 01:24:46 --> Security Class Initialized
DEBUG - 2018-03-24 01:24:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 01:24:46 --> Input Class Initialized
INFO - 2018-03-24 01:24:46 --> Language Class Initialized
INFO - 2018-03-24 01:24:46 --> Loader Class Initialized
INFO - 2018-03-24 01:24:46 --> Helper loaded: url_helper
INFO - 2018-03-24 01:24:46 --> Helper loaded: form_helper
INFO - 2018-03-24 01:24:46 --> Database Driver Class Initialized
DEBUG - 2018-03-24 01:24:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 01:24:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 01:24:47 --> Form Validation Class Initialized
INFO - 2018-03-24 01:24:47 --> Model Class Initialized
INFO - 2018-03-24 01:24:47 --> Controller Class Initialized
INFO - 2018-03-24 01:24:47 --> Model Class Initialized
INFO - 2018-03-24 01:24:47 --> Model Class Initialized
INFO - 2018-03-24 01:24:47 --> Model Class Initialized
INFO - 2018-03-24 01:24:47 --> Model Class Initialized
DEBUG - 2018-03-24 01:24:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 01:24:47 --> Final output sent to browser
DEBUG - 2018-03-24 01:24:47 --> Total execution time: 0.2601
INFO - 2018-03-24 01:25:41 --> Config Class Initialized
INFO - 2018-03-24 01:25:41 --> Hooks Class Initialized
DEBUG - 2018-03-24 01:25:41 --> UTF-8 Support Enabled
INFO - 2018-03-24 01:25:41 --> Utf8 Class Initialized
INFO - 2018-03-24 01:25:41 --> URI Class Initialized
INFO - 2018-03-24 01:25:41 --> Router Class Initialized
INFO - 2018-03-24 01:25:41 --> Output Class Initialized
INFO - 2018-03-24 01:25:41 --> Security Class Initialized
DEBUG - 2018-03-24 01:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 01:25:41 --> Input Class Initialized
INFO - 2018-03-24 01:25:41 --> Language Class Initialized
INFO - 2018-03-24 01:25:41 --> Loader Class Initialized
INFO - 2018-03-24 01:25:41 --> Helper loaded: url_helper
INFO - 2018-03-24 01:25:41 --> Helper loaded: form_helper
INFO - 2018-03-24 01:25:41 --> Database Driver Class Initialized
DEBUG - 2018-03-24 01:25:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 01:25:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 01:25:41 --> Form Validation Class Initialized
INFO - 2018-03-24 01:25:41 --> Model Class Initialized
INFO - 2018-03-24 01:25:41 --> Controller Class Initialized
INFO - 2018-03-24 01:25:41 --> Model Class Initialized
INFO - 2018-03-24 01:25:41 --> Model Class Initialized
INFO - 2018-03-24 01:25:41 --> Model Class Initialized
INFO - 2018-03-24 01:25:41 --> Model Class Initialized
DEBUG - 2018-03-24 01:25:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 01:25:41 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-24 01:25:41 --> Final output sent to browser
DEBUG - 2018-03-24 01:25:41 --> Total execution time: 0.1102
INFO - 2018-03-24 01:25:42 --> Config Class Initialized
INFO - 2018-03-24 01:25:42 --> Hooks Class Initialized
DEBUG - 2018-03-24 01:25:42 --> UTF-8 Support Enabled
INFO - 2018-03-24 01:25:42 --> Utf8 Class Initialized
INFO - 2018-03-24 01:25:42 --> URI Class Initialized
INFO - 2018-03-24 01:25:42 --> Router Class Initialized
INFO - 2018-03-24 01:25:42 --> Output Class Initialized
INFO - 2018-03-24 01:25:42 --> Security Class Initialized
DEBUG - 2018-03-24 01:25:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 01:25:42 --> Input Class Initialized
INFO - 2018-03-24 01:25:42 --> Language Class Initialized
INFO - 2018-03-24 01:25:42 --> Loader Class Initialized
INFO - 2018-03-24 01:25:42 --> Helper loaded: url_helper
INFO - 2018-03-24 01:25:42 --> Helper loaded: form_helper
INFO - 2018-03-24 01:25:42 --> Database Driver Class Initialized
DEBUG - 2018-03-24 01:25:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 01:25:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 01:25:42 --> Form Validation Class Initialized
INFO - 2018-03-24 01:25:42 --> Model Class Initialized
INFO - 2018-03-24 01:25:42 --> Controller Class Initialized
INFO - 2018-03-24 01:25:42 --> Model Class Initialized
INFO - 2018-03-24 01:25:42 --> Model Class Initialized
INFO - 2018-03-24 01:25:42 --> Model Class Initialized
INFO - 2018-03-24 01:25:42 --> Model Class Initialized
DEBUG - 2018-03-24 01:25:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 01:25:48 --> Config Class Initialized
INFO - 2018-03-24 01:25:48 --> Hooks Class Initialized
DEBUG - 2018-03-24 01:25:48 --> UTF-8 Support Enabled
INFO - 2018-03-24 01:25:48 --> Utf8 Class Initialized
INFO - 2018-03-24 01:25:48 --> URI Class Initialized
INFO - 2018-03-24 01:25:48 --> Router Class Initialized
INFO - 2018-03-24 01:25:48 --> Output Class Initialized
INFO - 2018-03-24 01:25:48 --> Security Class Initialized
DEBUG - 2018-03-24 01:25:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 01:25:48 --> Input Class Initialized
INFO - 2018-03-24 01:25:48 --> Language Class Initialized
INFO - 2018-03-24 01:25:48 --> Loader Class Initialized
INFO - 2018-03-24 01:25:48 --> Helper loaded: url_helper
INFO - 2018-03-24 01:25:48 --> Helper loaded: form_helper
INFO - 2018-03-24 01:25:48 --> Database Driver Class Initialized
DEBUG - 2018-03-24 01:25:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 01:25:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 01:25:48 --> Form Validation Class Initialized
INFO - 2018-03-24 01:25:48 --> Model Class Initialized
INFO - 2018-03-24 01:25:48 --> Controller Class Initialized
INFO - 2018-03-24 01:25:48 --> Model Class Initialized
INFO - 2018-03-24 01:25:48 --> Model Class Initialized
INFO - 2018-03-24 01:25:48 --> Model Class Initialized
INFO - 2018-03-24 01:25:48 --> Model Class Initialized
DEBUG - 2018-03-24 01:25:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 01:25:50 --> Config Class Initialized
INFO - 2018-03-24 01:25:50 --> Hooks Class Initialized
DEBUG - 2018-03-24 01:25:50 --> UTF-8 Support Enabled
INFO - 2018-03-24 01:25:50 --> Utf8 Class Initialized
INFO - 2018-03-24 01:25:50 --> URI Class Initialized
INFO - 2018-03-24 01:25:50 --> Router Class Initialized
INFO - 2018-03-24 01:25:50 --> Output Class Initialized
INFO - 2018-03-24 01:25:50 --> Security Class Initialized
DEBUG - 2018-03-24 01:25:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 01:25:50 --> Input Class Initialized
INFO - 2018-03-24 01:25:50 --> Language Class Initialized
INFO - 2018-03-24 01:25:50 --> Loader Class Initialized
INFO - 2018-03-24 01:25:50 --> Helper loaded: url_helper
INFO - 2018-03-24 01:25:50 --> Helper loaded: form_helper
INFO - 2018-03-24 01:25:50 --> Database Driver Class Initialized
DEBUG - 2018-03-24 01:25:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 01:25:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 01:25:50 --> Form Validation Class Initialized
INFO - 2018-03-24 01:25:50 --> Model Class Initialized
INFO - 2018-03-24 01:25:50 --> Controller Class Initialized
INFO - 2018-03-24 01:25:50 --> Model Class Initialized
INFO - 2018-03-24 01:25:50 --> Model Class Initialized
INFO - 2018-03-24 01:25:50 --> Model Class Initialized
INFO - 2018-03-24 01:25:50 --> Model Class Initialized
DEBUG - 2018-03-24 01:25:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 01:25:50 --> Final output sent to browser
DEBUG - 2018-03-24 01:25:50 --> Total execution time: 0.2755
INFO - 2018-03-24 01:26:11 --> Config Class Initialized
INFO - 2018-03-24 01:26:11 --> Hooks Class Initialized
DEBUG - 2018-03-24 01:26:11 --> UTF-8 Support Enabled
INFO - 2018-03-24 01:26:11 --> Utf8 Class Initialized
INFO - 2018-03-24 01:26:11 --> URI Class Initialized
INFO - 2018-03-24 01:26:11 --> Router Class Initialized
INFO - 2018-03-24 01:26:11 --> Output Class Initialized
INFO - 2018-03-24 01:26:11 --> Security Class Initialized
DEBUG - 2018-03-24 01:26:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 01:26:11 --> Input Class Initialized
INFO - 2018-03-24 01:26:11 --> Language Class Initialized
INFO - 2018-03-24 01:26:11 --> Loader Class Initialized
INFO - 2018-03-24 01:26:11 --> Helper loaded: url_helper
INFO - 2018-03-24 01:26:11 --> Helper loaded: form_helper
INFO - 2018-03-24 01:26:11 --> Database Driver Class Initialized
DEBUG - 2018-03-24 01:26:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 01:26:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 01:26:11 --> Form Validation Class Initialized
INFO - 2018-03-24 01:26:11 --> Model Class Initialized
INFO - 2018-03-24 01:26:11 --> Controller Class Initialized
INFO - 2018-03-24 01:26:11 --> Model Class Initialized
INFO - 2018-03-24 01:26:11 --> Model Class Initialized
INFO - 2018-03-24 01:26:11 --> Model Class Initialized
INFO - 2018-03-24 01:26:11 --> Model Class Initialized
DEBUG - 2018-03-24 01:26:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 01:26:13 --> Config Class Initialized
INFO - 2018-03-24 01:26:13 --> Hooks Class Initialized
DEBUG - 2018-03-24 01:26:13 --> UTF-8 Support Enabled
INFO - 2018-03-24 01:26:13 --> Utf8 Class Initialized
INFO - 2018-03-24 01:26:13 --> URI Class Initialized
INFO - 2018-03-24 01:26:13 --> Router Class Initialized
INFO - 2018-03-24 01:26:13 --> Output Class Initialized
INFO - 2018-03-24 01:26:13 --> Security Class Initialized
DEBUG - 2018-03-24 01:26:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 01:26:13 --> Input Class Initialized
INFO - 2018-03-24 01:26:13 --> Language Class Initialized
INFO - 2018-03-24 01:26:13 --> Loader Class Initialized
INFO - 2018-03-24 01:26:13 --> Helper loaded: url_helper
INFO - 2018-03-24 01:26:13 --> Helper loaded: form_helper
INFO - 2018-03-24 01:26:13 --> Database Driver Class Initialized
DEBUG - 2018-03-24 01:26:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 01:26:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 01:26:13 --> Form Validation Class Initialized
INFO - 2018-03-24 01:26:13 --> Model Class Initialized
INFO - 2018-03-24 01:26:13 --> Controller Class Initialized
INFO - 2018-03-24 01:26:13 --> Model Class Initialized
INFO - 2018-03-24 01:26:13 --> Model Class Initialized
INFO - 2018-03-24 01:26:13 --> Model Class Initialized
INFO - 2018-03-24 01:26:13 --> Model Class Initialized
DEBUG - 2018-03-24 01:26:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 01:26:13 --> Final output sent to browser
DEBUG - 2018-03-24 01:26:13 --> Total execution time: 0.2595
INFO - 2018-03-24 01:26:30 --> Config Class Initialized
INFO - 2018-03-24 01:26:30 --> Hooks Class Initialized
DEBUG - 2018-03-24 01:26:30 --> UTF-8 Support Enabled
INFO - 2018-03-24 01:26:30 --> Utf8 Class Initialized
INFO - 2018-03-24 01:26:30 --> URI Class Initialized
INFO - 2018-03-24 01:26:30 --> Router Class Initialized
INFO - 2018-03-24 01:26:30 --> Output Class Initialized
INFO - 2018-03-24 01:26:30 --> Security Class Initialized
DEBUG - 2018-03-24 01:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 01:26:30 --> Input Class Initialized
INFO - 2018-03-24 01:26:30 --> Language Class Initialized
INFO - 2018-03-24 01:26:30 --> Loader Class Initialized
INFO - 2018-03-24 01:26:30 --> Helper loaded: url_helper
INFO - 2018-03-24 01:26:30 --> Helper loaded: form_helper
INFO - 2018-03-24 01:26:30 --> Database Driver Class Initialized
DEBUG - 2018-03-24 01:26:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 01:26:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 01:26:30 --> Form Validation Class Initialized
INFO - 2018-03-24 01:26:30 --> Model Class Initialized
INFO - 2018-03-24 01:26:30 --> Controller Class Initialized
INFO - 2018-03-24 01:26:30 --> Model Class Initialized
INFO - 2018-03-24 01:26:30 --> Model Class Initialized
INFO - 2018-03-24 01:26:30 --> Model Class Initialized
INFO - 2018-03-24 01:26:30 --> Model Class Initialized
DEBUG - 2018-03-24 01:26:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 01:26:34 --> Config Class Initialized
INFO - 2018-03-24 01:26:34 --> Hooks Class Initialized
DEBUG - 2018-03-24 01:26:34 --> UTF-8 Support Enabled
INFO - 2018-03-24 01:26:34 --> Utf8 Class Initialized
INFO - 2018-03-24 01:26:34 --> URI Class Initialized
INFO - 2018-03-24 01:26:34 --> Router Class Initialized
INFO - 2018-03-24 01:26:34 --> Output Class Initialized
INFO - 2018-03-24 01:26:34 --> Security Class Initialized
DEBUG - 2018-03-24 01:26:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 01:26:34 --> Input Class Initialized
INFO - 2018-03-24 01:26:34 --> Language Class Initialized
INFO - 2018-03-24 01:26:34 --> Loader Class Initialized
INFO - 2018-03-24 01:26:34 --> Helper loaded: url_helper
INFO - 2018-03-24 01:26:34 --> Helper loaded: form_helper
INFO - 2018-03-24 01:26:34 --> Database Driver Class Initialized
DEBUG - 2018-03-24 01:26:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 01:26:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 01:26:34 --> Form Validation Class Initialized
INFO - 2018-03-24 01:26:34 --> Model Class Initialized
INFO - 2018-03-24 01:26:34 --> Controller Class Initialized
INFO - 2018-03-24 01:26:34 --> Model Class Initialized
INFO - 2018-03-24 01:26:34 --> Model Class Initialized
INFO - 2018-03-24 01:26:34 --> Model Class Initialized
INFO - 2018-03-24 01:26:34 --> Model Class Initialized
DEBUG - 2018-03-24 01:26:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 01:26:34 --> Final output sent to browser
DEBUG - 2018-03-24 01:26:34 --> Total execution time: 0.2370
INFO - 2018-03-24 01:27:04 --> Config Class Initialized
INFO - 2018-03-24 01:27:04 --> Hooks Class Initialized
DEBUG - 2018-03-24 01:27:04 --> UTF-8 Support Enabled
INFO - 2018-03-24 01:27:04 --> Utf8 Class Initialized
INFO - 2018-03-24 01:27:04 --> URI Class Initialized
INFO - 2018-03-24 01:27:04 --> Router Class Initialized
INFO - 2018-03-24 01:27:04 --> Output Class Initialized
INFO - 2018-03-24 01:27:04 --> Security Class Initialized
DEBUG - 2018-03-24 01:27:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 01:27:04 --> Input Class Initialized
INFO - 2018-03-24 01:27:04 --> Language Class Initialized
INFO - 2018-03-24 01:27:04 --> Loader Class Initialized
INFO - 2018-03-24 01:27:04 --> Helper loaded: url_helper
INFO - 2018-03-24 01:27:04 --> Helper loaded: form_helper
INFO - 2018-03-24 01:27:04 --> Database Driver Class Initialized
DEBUG - 2018-03-24 01:27:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 01:27:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 01:27:04 --> Form Validation Class Initialized
INFO - 2018-03-24 01:27:04 --> Model Class Initialized
INFO - 2018-03-24 01:27:04 --> Controller Class Initialized
INFO - 2018-03-24 01:27:04 --> Model Class Initialized
INFO - 2018-03-24 01:27:04 --> Model Class Initialized
INFO - 2018-03-24 01:27:04 --> Model Class Initialized
INFO - 2018-03-24 01:27:04 --> Model Class Initialized
DEBUG - 2018-03-24 01:27:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 01:27:06 --> Config Class Initialized
INFO - 2018-03-24 01:27:06 --> Hooks Class Initialized
DEBUG - 2018-03-24 01:27:06 --> UTF-8 Support Enabled
INFO - 2018-03-24 01:27:06 --> Utf8 Class Initialized
INFO - 2018-03-24 01:27:06 --> URI Class Initialized
INFO - 2018-03-24 01:27:06 --> Router Class Initialized
INFO - 2018-03-24 01:27:06 --> Output Class Initialized
INFO - 2018-03-24 01:27:06 --> Security Class Initialized
DEBUG - 2018-03-24 01:27:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 01:27:06 --> Input Class Initialized
INFO - 2018-03-24 01:27:06 --> Language Class Initialized
INFO - 2018-03-24 01:27:06 --> Loader Class Initialized
INFO - 2018-03-24 01:27:06 --> Helper loaded: url_helper
INFO - 2018-03-24 01:27:06 --> Helper loaded: form_helper
INFO - 2018-03-24 01:27:07 --> Database Driver Class Initialized
DEBUG - 2018-03-24 01:27:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 01:27:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 01:27:07 --> Form Validation Class Initialized
INFO - 2018-03-24 01:27:07 --> Model Class Initialized
INFO - 2018-03-24 01:27:07 --> Controller Class Initialized
INFO - 2018-03-24 01:27:07 --> Model Class Initialized
INFO - 2018-03-24 01:27:07 --> Model Class Initialized
INFO - 2018-03-24 01:27:07 --> Model Class Initialized
INFO - 2018-03-24 01:27:07 --> Model Class Initialized
DEBUG - 2018-03-24 01:27:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 01:27:07 --> Final output sent to browser
DEBUG - 2018-03-24 01:27:07 --> Total execution time: 0.2428
INFO - 2018-03-24 01:29:54 --> Config Class Initialized
INFO - 2018-03-24 01:29:54 --> Hooks Class Initialized
DEBUG - 2018-03-24 01:29:54 --> UTF-8 Support Enabled
INFO - 2018-03-24 01:29:54 --> Utf8 Class Initialized
INFO - 2018-03-24 01:29:54 --> URI Class Initialized
INFO - 2018-03-24 01:29:54 --> Router Class Initialized
INFO - 2018-03-24 01:29:54 --> Output Class Initialized
INFO - 2018-03-24 01:29:54 --> Security Class Initialized
DEBUG - 2018-03-24 01:29:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 01:29:54 --> Input Class Initialized
INFO - 2018-03-24 01:29:54 --> Language Class Initialized
INFO - 2018-03-24 01:29:54 --> Loader Class Initialized
INFO - 2018-03-24 01:29:54 --> Helper loaded: url_helper
INFO - 2018-03-24 01:29:54 --> Helper loaded: form_helper
INFO - 2018-03-24 01:29:55 --> Database Driver Class Initialized
DEBUG - 2018-03-24 01:29:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 01:29:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 01:29:55 --> Form Validation Class Initialized
INFO - 2018-03-24 01:29:55 --> Model Class Initialized
INFO - 2018-03-24 01:29:55 --> Controller Class Initialized
INFO - 2018-03-24 01:29:55 --> Model Class Initialized
INFO - 2018-03-24 01:29:55 --> Model Class Initialized
INFO - 2018-03-24 01:29:55 --> Model Class Initialized
INFO - 2018-03-24 01:29:55 --> Model Class Initialized
DEBUG - 2018-03-24 01:29:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 01:29:55 --> Model Class Initialized
INFO - 2018-03-24 01:29:55 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-24 01:29:55 --> Final output sent to browser
DEBUG - 2018-03-24 01:29:55 --> Total execution time: 0.0924
INFO - 2018-03-24 01:29:55 --> Config Class Initialized
INFO - 2018-03-24 01:29:55 --> Hooks Class Initialized
DEBUG - 2018-03-24 01:29:55 --> UTF-8 Support Enabled
INFO - 2018-03-24 01:29:55 --> Utf8 Class Initialized
INFO - 2018-03-24 01:29:55 --> URI Class Initialized
INFO - 2018-03-24 01:29:55 --> Router Class Initialized
INFO - 2018-03-24 01:29:55 --> Output Class Initialized
INFO - 2018-03-24 01:29:55 --> Security Class Initialized
DEBUG - 2018-03-24 01:29:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 01:29:55 --> Input Class Initialized
INFO - 2018-03-24 01:29:55 --> Language Class Initialized
INFO - 2018-03-24 01:29:55 --> Loader Class Initialized
INFO - 2018-03-24 01:29:55 --> Helper loaded: url_helper
INFO - 2018-03-24 01:29:55 --> Helper loaded: form_helper
INFO - 2018-03-24 01:29:55 --> Database Driver Class Initialized
DEBUG - 2018-03-24 01:29:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 01:29:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 01:29:55 --> Form Validation Class Initialized
INFO - 2018-03-24 01:29:55 --> Model Class Initialized
INFO - 2018-03-24 01:29:55 --> Controller Class Initialized
INFO - 2018-03-24 01:29:55 --> Model Class Initialized
INFO - 2018-03-24 01:29:55 --> Model Class Initialized
DEBUG - 2018-03-24 01:29:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 01:30:01 --> Config Class Initialized
INFO - 2018-03-24 01:30:01 --> Hooks Class Initialized
DEBUG - 2018-03-24 01:30:01 --> UTF-8 Support Enabled
INFO - 2018-03-24 01:30:01 --> Utf8 Class Initialized
INFO - 2018-03-24 01:30:01 --> URI Class Initialized
INFO - 2018-03-24 01:30:01 --> Router Class Initialized
INFO - 2018-03-24 01:30:01 --> Output Class Initialized
INFO - 2018-03-24 01:30:01 --> Security Class Initialized
DEBUG - 2018-03-24 01:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 01:30:01 --> Input Class Initialized
INFO - 2018-03-24 01:30:01 --> Language Class Initialized
INFO - 2018-03-24 01:30:01 --> Loader Class Initialized
INFO - 2018-03-24 01:30:01 --> Helper loaded: url_helper
INFO - 2018-03-24 01:30:01 --> Helper loaded: form_helper
INFO - 2018-03-24 01:30:01 --> Database Driver Class Initialized
DEBUG - 2018-03-24 01:30:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 01:30:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 01:30:01 --> Form Validation Class Initialized
INFO - 2018-03-24 01:30:01 --> Model Class Initialized
INFO - 2018-03-24 01:30:01 --> Controller Class Initialized
INFO - 2018-03-24 01:30:01 --> Model Class Initialized
INFO - 2018-03-24 01:30:01 --> Model Class Initialized
INFO - 2018-03-24 01:30:01 --> Model Class Initialized
INFO - 2018-03-24 01:30:01 --> Model Class Initialized
DEBUG - 2018-03-24 01:30:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 01:30:01 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-24 01:30:01 --> Final output sent to browser
DEBUG - 2018-03-24 01:30:01 --> Total execution time: 0.1072
INFO - 2018-03-24 01:30:03 --> Config Class Initialized
INFO - 2018-03-24 01:30:03 --> Hooks Class Initialized
DEBUG - 2018-03-24 01:30:03 --> UTF-8 Support Enabled
INFO - 2018-03-24 01:30:03 --> Utf8 Class Initialized
INFO - 2018-03-24 01:30:03 --> URI Class Initialized
INFO - 2018-03-24 01:30:03 --> Router Class Initialized
INFO - 2018-03-24 01:30:03 --> Output Class Initialized
INFO - 2018-03-24 01:30:03 --> Security Class Initialized
DEBUG - 2018-03-24 01:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 01:30:03 --> Input Class Initialized
INFO - 2018-03-24 01:30:03 --> Language Class Initialized
INFO - 2018-03-24 01:30:03 --> Loader Class Initialized
INFO - 2018-03-24 01:30:03 --> Helper loaded: url_helper
INFO - 2018-03-24 01:30:03 --> Helper loaded: form_helper
INFO - 2018-03-24 01:30:03 --> Database Driver Class Initialized
DEBUG - 2018-03-24 01:30:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 01:30:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 01:30:03 --> Form Validation Class Initialized
INFO - 2018-03-24 01:30:03 --> Model Class Initialized
INFO - 2018-03-24 01:30:03 --> Controller Class Initialized
INFO - 2018-03-24 01:30:03 --> Model Class Initialized
INFO - 2018-03-24 01:30:03 --> Model Class Initialized
INFO - 2018-03-24 01:30:03 --> Model Class Initialized
INFO - 2018-03-24 01:30:03 --> Model Class Initialized
DEBUG - 2018-03-24 01:30:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 01:30:03 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-24 01:30:03 --> Final output sent to browser
DEBUG - 2018-03-24 01:30:03 --> Total execution time: 0.1070
INFO - 2018-03-24 01:30:03 --> Config Class Initialized
INFO - 2018-03-24 01:30:03 --> Hooks Class Initialized
DEBUG - 2018-03-24 01:30:03 --> UTF-8 Support Enabled
INFO - 2018-03-24 01:30:03 --> Utf8 Class Initialized
INFO - 2018-03-24 01:30:03 --> URI Class Initialized
INFO - 2018-03-24 01:30:03 --> Router Class Initialized
INFO - 2018-03-24 01:30:03 --> Output Class Initialized
INFO - 2018-03-24 01:30:03 --> Security Class Initialized
DEBUG - 2018-03-24 01:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 01:30:03 --> Input Class Initialized
INFO - 2018-03-24 01:30:03 --> Language Class Initialized
INFO - 2018-03-24 01:30:03 --> Loader Class Initialized
INFO - 2018-03-24 01:30:03 --> Helper loaded: url_helper
INFO - 2018-03-24 01:30:03 --> Helper loaded: form_helper
INFO - 2018-03-24 01:30:03 --> Database Driver Class Initialized
DEBUG - 2018-03-24 01:30:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 01:30:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 01:30:03 --> Form Validation Class Initialized
INFO - 2018-03-24 01:30:03 --> Model Class Initialized
INFO - 2018-03-24 01:30:03 --> Controller Class Initialized
INFO - 2018-03-24 01:30:03 --> Model Class Initialized
INFO - 2018-03-24 01:30:03 --> Model Class Initialized
INFO - 2018-03-24 01:30:03 --> Model Class Initialized
INFO - 2018-03-24 01:30:03 --> Model Class Initialized
INFO - 2018-03-24 01:30:03 --> Model Class Initialized
DEBUG - 2018-03-24 01:30:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 01:30:06 --> Config Class Initialized
INFO - 2018-03-24 01:30:06 --> Hooks Class Initialized
DEBUG - 2018-03-24 01:30:06 --> UTF-8 Support Enabled
INFO - 2018-03-24 01:30:06 --> Utf8 Class Initialized
INFO - 2018-03-24 01:30:06 --> URI Class Initialized
INFO - 2018-03-24 01:30:06 --> Router Class Initialized
INFO - 2018-03-24 01:30:06 --> Output Class Initialized
INFO - 2018-03-24 01:30:06 --> Security Class Initialized
DEBUG - 2018-03-24 01:30:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 01:30:06 --> Input Class Initialized
INFO - 2018-03-24 01:30:06 --> Language Class Initialized
INFO - 2018-03-24 01:30:06 --> Loader Class Initialized
INFO - 2018-03-24 01:30:06 --> Helper loaded: url_helper
INFO - 2018-03-24 01:30:06 --> Helper loaded: form_helper
INFO - 2018-03-24 01:30:06 --> Database Driver Class Initialized
DEBUG - 2018-03-24 01:30:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 01:30:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 01:30:06 --> Form Validation Class Initialized
INFO - 2018-03-24 01:30:06 --> Model Class Initialized
INFO - 2018-03-24 01:30:06 --> Controller Class Initialized
INFO - 2018-03-24 01:30:06 --> Model Class Initialized
INFO - 2018-03-24 01:30:06 --> Model Class Initialized
INFO - 2018-03-24 01:30:06 --> Model Class Initialized
INFO - 2018-03-24 01:30:06 --> Model Class Initialized
DEBUG - 2018-03-24 01:30:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 01:30:06 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-24 01:30:06 --> Final output sent to browser
DEBUG - 2018-03-24 01:30:06 --> Total execution time: 0.0929
INFO - 2018-03-24 01:30:06 --> Config Class Initialized
INFO - 2018-03-24 01:30:06 --> Hooks Class Initialized
DEBUG - 2018-03-24 01:30:06 --> UTF-8 Support Enabled
INFO - 2018-03-24 01:30:06 --> Utf8 Class Initialized
INFO - 2018-03-24 01:30:06 --> URI Class Initialized
INFO - 2018-03-24 01:30:06 --> Router Class Initialized
INFO - 2018-03-24 01:30:06 --> Output Class Initialized
INFO - 2018-03-24 01:30:06 --> Security Class Initialized
DEBUG - 2018-03-24 01:30:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 01:30:06 --> Input Class Initialized
INFO - 2018-03-24 01:30:06 --> Language Class Initialized
INFO - 2018-03-24 01:30:06 --> Loader Class Initialized
INFO - 2018-03-24 01:30:06 --> Helper loaded: url_helper
INFO - 2018-03-24 01:30:06 --> Helper loaded: form_helper
INFO - 2018-03-24 01:30:07 --> Database Driver Class Initialized
DEBUG - 2018-03-24 01:30:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 01:30:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 01:30:07 --> Form Validation Class Initialized
INFO - 2018-03-24 01:30:07 --> Model Class Initialized
INFO - 2018-03-24 01:30:07 --> Controller Class Initialized
INFO - 2018-03-24 01:30:07 --> Model Class Initialized
INFO - 2018-03-24 01:30:07 --> Model Class Initialized
INFO - 2018-03-24 01:30:07 --> Model Class Initialized
INFO - 2018-03-24 01:30:07 --> Model Class Initialized
DEBUG - 2018-03-24 01:30:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 01:30:27 --> Config Class Initialized
INFO - 2018-03-24 01:30:27 --> Hooks Class Initialized
DEBUG - 2018-03-24 01:30:27 --> UTF-8 Support Enabled
INFO - 2018-03-24 01:30:27 --> Utf8 Class Initialized
INFO - 2018-03-24 01:30:27 --> URI Class Initialized
INFO - 2018-03-24 01:30:27 --> Router Class Initialized
INFO - 2018-03-24 01:30:27 --> Output Class Initialized
INFO - 2018-03-24 01:30:27 --> Security Class Initialized
DEBUG - 2018-03-24 01:30:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 01:30:27 --> Input Class Initialized
INFO - 2018-03-24 01:30:27 --> Language Class Initialized
INFO - 2018-03-24 01:30:27 --> Loader Class Initialized
INFO - 2018-03-24 01:30:27 --> Helper loaded: url_helper
INFO - 2018-03-24 01:30:27 --> Helper loaded: form_helper
INFO - 2018-03-24 01:30:27 --> Database Driver Class Initialized
DEBUG - 2018-03-24 01:30:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 01:30:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 01:30:27 --> Form Validation Class Initialized
INFO - 2018-03-24 01:30:27 --> Model Class Initialized
INFO - 2018-03-24 01:30:27 --> Controller Class Initialized
INFO - 2018-03-24 01:30:27 --> Model Class Initialized
INFO - 2018-03-24 01:30:27 --> Model Class Initialized
INFO - 2018-03-24 01:30:27 --> Model Class Initialized
INFO - 2018-03-24 01:30:27 --> Model Class Initialized
DEBUG - 2018-03-24 01:30:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 01:30:27 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-24 01:30:27 --> Final output sent to browser
DEBUG - 2018-03-24 01:30:27 --> Total execution time: 0.1168
INFO - 2018-03-24 01:30:28 --> Config Class Initialized
INFO - 2018-03-24 01:30:28 --> Hooks Class Initialized
DEBUG - 2018-03-24 01:30:28 --> UTF-8 Support Enabled
INFO - 2018-03-24 01:30:28 --> Utf8 Class Initialized
INFO - 2018-03-24 01:30:28 --> URI Class Initialized
INFO - 2018-03-24 01:30:28 --> Router Class Initialized
INFO - 2018-03-24 01:30:28 --> Output Class Initialized
INFO - 2018-03-24 01:30:28 --> Security Class Initialized
DEBUG - 2018-03-24 01:30:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 01:30:28 --> Input Class Initialized
INFO - 2018-03-24 01:30:28 --> Language Class Initialized
INFO - 2018-03-24 01:30:28 --> Loader Class Initialized
INFO - 2018-03-24 01:30:28 --> Helper loaded: url_helper
INFO - 2018-03-24 01:30:28 --> Helper loaded: form_helper
INFO - 2018-03-24 01:30:28 --> Database Driver Class Initialized
DEBUG - 2018-03-24 01:30:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 01:30:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 01:30:28 --> Form Validation Class Initialized
INFO - 2018-03-24 01:30:28 --> Model Class Initialized
INFO - 2018-03-24 01:30:28 --> Controller Class Initialized
INFO - 2018-03-24 01:30:28 --> Model Class Initialized
INFO - 2018-03-24 01:30:28 --> Model Class Initialized
INFO - 2018-03-24 01:30:28 --> Model Class Initialized
INFO - 2018-03-24 01:30:28 --> Model Class Initialized
DEBUG - 2018-03-24 01:30:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 01:30:29 --> Config Class Initialized
INFO - 2018-03-24 01:30:29 --> Hooks Class Initialized
DEBUG - 2018-03-24 01:30:29 --> UTF-8 Support Enabled
INFO - 2018-03-24 01:30:29 --> Utf8 Class Initialized
INFO - 2018-03-24 01:30:29 --> URI Class Initialized
INFO - 2018-03-24 01:30:29 --> Router Class Initialized
INFO - 2018-03-24 01:30:29 --> Output Class Initialized
INFO - 2018-03-24 01:30:29 --> Security Class Initialized
DEBUG - 2018-03-24 01:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 01:30:29 --> Input Class Initialized
INFO - 2018-03-24 01:30:29 --> Language Class Initialized
INFO - 2018-03-24 01:30:29 --> Loader Class Initialized
INFO - 2018-03-24 01:30:29 --> Helper loaded: url_helper
INFO - 2018-03-24 01:30:29 --> Helper loaded: form_helper
INFO - 2018-03-24 01:30:29 --> Database Driver Class Initialized
DEBUG - 2018-03-24 01:30:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 01:30:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 01:30:29 --> Form Validation Class Initialized
INFO - 2018-03-24 01:30:29 --> Model Class Initialized
INFO - 2018-03-24 01:30:29 --> Controller Class Initialized
INFO - 2018-03-24 01:30:29 --> Model Class Initialized
INFO - 2018-03-24 01:30:29 --> Model Class Initialized
INFO - 2018-03-24 01:30:29 --> Model Class Initialized
INFO - 2018-03-24 01:30:29 --> Model Class Initialized
DEBUG - 2018-03-24 01:30:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 01:30:29 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-24 01:30:29 --> Final output sent to browser
DEBUG - 2018-03-24 01:30:29 --> Total execution time: 0.0822
INFO - 2018-03-24 01:30:29 --> Config Class Initialized
INFO - 2018-03-24 01:30:29 --> Hooks Class Initialized
DEBUG - 2018-03-24 01:30:29 --> UTF-8 Support Enabled
INFO - 2018-03-24 01:30:29 --> Utf8 Class Initialized
INFO - 2018-03-24 01:30:29 --> URI Class Initialized
INFO - 2018-03-24 01:30:29 --> Router Class Initialized
INFO - 2018-03-24 01:30:29 --> Output Class Initialized
INFO - 2018-03-24 01:30:29 --> Security Class Initialized
DEBUG - 2018-03-24 01:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 01:30:29 --> Input Class Initialized
INFO - 2018-03-24 01:30:29 --> Language Class Initialized
INFO - 2018-03-24 01:30:29 --> Loader Class Initialized
INFO - 2018-03-24 01:30:29 --> Helper loaded: url_helper
INFO - 2018-03-24 01:30:29 --> Helper loaded: form_helper
INFO - 2018-03-24 01:30:29 --> Database Driver Class Initialized
DEBUG - 2018-03-24 01:30:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 01:30:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 01:30:29 --> Form Validation Class Initialized
INFO - 2018-03-24 01:30:29 --> Model Class Initialized
INFO - 2018-03-24 01:30:29 --> Controller Class Initialized
INFO - 2018-03-24 01:30:29 --> Model Class Initialized
INFO - 2018-03-24 01:30:29 --> Model Class Initialized
INFO - 2018-03-24 01:30:29 --> Model Class Initialized
INFO - 2018-03-24 01:30:29 --> Model Class Initialized
INFO - 2018-03-24 01:30:29 --> Model Class Initialized
DEBUG - 2018-03-24 01:30:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 01:30:35 --> Config Class Initialized
INFO - 2018-03-24 01:30:35 --> Hooks Class Initialized
DEBUG - 2018-03-24 01:30:35 --> UTF-8 Support Enabled
INFO - 2018-03-24 01:30:35 --> Utf8 Class Initialized
INFO - 2018-03-24 01:30:35 --> URI Class Initialized
INFO - 2018-03-24 01:30:35 --> Router Class Initialized
INFO - 2018-03-24 01:30:35 --> Output Class Initialized
INFO - 2018-03-24 01:30:35 --> Security Class Initialized
DEBUG - 2018-03-24 01:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 01:30:35 --> Input Class Initialized
INFO - 2018-03-24 01:30:35 --> Language Class Initialized
INFO - 2018-03-24 01:30:35 --> Loader Class Initialized
INFO - 2018-03-24 01:30:35 --> Helper loaded: url_helper
INFO - 2018-03-24 01:30:35 --> Helper loaded: form_helper
INFO - 2018-03-24 01:30:35 --> Database Driver Class Initialized
DEBUG - 2018-03-24 01:30:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 01:30:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 01:30:35 --> Form Validation Class Initialized
INFO - 2018-03-24 01:30:35 --> Model Class Initialized
INFO - 2018-03-24 01:30:35 --> Controller Class Initialized
INFO - 2018-03-24 01:30:35 --> Model Class Initialized
INFO - 2018-03-24 01:30:35 --> Model Class Initialized
INFO - 2018-03-24 01:30:35 --> Model Class Initialized
INFO - 2018-03-24 01:30:35 --> Model Class Initialized
DEBUG - 2018-03-24 01:30:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 01:30:35 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-24 01:30:35 --> Final output sent to browser
DEBUG - 2018-03-24 01:30:35 --> Total execution time: 0.0902
INFO - 2018-03-24 01:31:26 --> Config Class Initialized
INFO - 2018-03-24 01:31:26 --> Hooks Class Initialized
DEBUG - 2018-03-24 01:31:26 --> UTF-8 Support Enabled
INFO - 2018-03-24 01:31:26 --> Utf8 Class Initialized
INFO - 2018-03-24 01:31:26 --> URI Class Initialized
INFO - 2018-03-24 01:31:26 --> Router Class Initialized
INFO - 2018-03-24 01:31:26 --> Output Class Initialized
INFO - 2018-03-24 01:31:26 --> Security Class Initialized
DEBUG - 2018-03-24 01:31:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 01:31:26 --> Input Class Initialized
INFO - 2018-03-24 01:31:26 --> Language Class Initialized
INFO - 2018-03-24 01:31:26 --> Loader Class Initialized
INFO - 2018-03-24 01:31:26 --> Helper loaded: url_helper
INFO - 2018-03-24 01:31:26 --> Helper loaded: form_helper
INFO - 2018-03-24 01:31:26 --> Database Driver Class Initialized
DEBUG - 2018-03-24 01:31:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 01:31:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 01:31:26 --> Form Validation Class Initialized
INFO - 2018-03-24 01:31:26 --> Model Class Initialized
INFO - 2018-03-24 01:31:26 --> Controller Class Initialized
INFO - 2018-03-24 01:31:26 --> Model Class Initialized
INFO - 2018-03-24 01:31:26 --> Model Class Initialized
INFO - 2018-03-24 01:31:26 --> Model Class Initialized
INFO - 2018-03-24 01:31:26 --> Model Class Initialized
DEBUG - 2018-03-24 01:31:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 01:31:26 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-24 01:31:26 --> Final output sent to browser
DEBUG - 2018-03-24 01:31:26 --> Total execution time: 0.1104
INFO - 2018-03-24 01:31:28 --> Config Class Initialized
INFO - 2018-03-24 01:31:28 --> Hooks Class Initialized
DEBUG - 2018-03-24 01:31:28 --> UTF-8 Support Enabled
INFO - 2018-03-24 01:31:28 --> Utf8 Class Initialized
INFO - 2018-03-24 01:31:28 --> URI Class Initialized
INFO - 2018-03-24 01:31:28 --> Router Class Initialized
INFO - 2018-03-24 01:31:28 --> Output Class Initialized
INFO - 2018-03-24 01:31:28 --> Security Class Initialized
DEBUG - 2018-03-24 01:31:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 01:31:28 --> Input Class Initialized
INFO - 2018-03-24 01:31:28 --> Language Class Initialized
INFO - 2018-03-24 01:31:28 --> Loader Class Initialized
INFO - 2018-03-24 01:31:28 --> Helper loaded: url_helper
INFO - 2018-03-24 01:31:28 --> Helper loaded: form_helper
INFO - 2018-03-24 01:31:28 --> Database Driver Class Initialized
DEBUG - 2018-03-24 01:31:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 01:31:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 01:31:28 --> Form Validation Class Initialized
INFO - 2018-03-24 01:31:28 --> Model Class Initialized
INFO - 2018-03-24 01:31:28 --> Controller Class Initialized
INFO - 2018-03-24 01:31:28 --> Model Class Initialized
INFO - 2018-03-24 01:31:28 --> Model Class Initialized
INFO - 2018-03-24 01:31:28 --> Model Class Initialized
INFO - 2018-03-24 01:31:28 --> Model Class Initialized
DEBUG - 2018-03-24 01:31:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 01:31:28 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-24 01:31:28 --> Final output sent to browser
DEBUG - 2018-03-24 01:31:28 --> Total execution time: 0.0795
INFO - 2018-03-24 01:31:29 --> Config Class Initialized
INFO - 2018-03-24 01:31:29 --> Hooks Class Initialized
DEBUG - 2018-03-24 01:31:29 --> UTF-8 Support Enabled
INFO - 2018-03-24 01:31:29 --> Utf8 Class Initialized
INFO - 2018-03-24 01:31:29 --> URI Class Initialized
INFO - 2018-03-24 01:31:29 --> Router Class Initialized
INFO - 2018-03-24 01:31:29 --> Output Class Initialized
INFO - 2018-03-24 01:31:29 --> Security Class Initialized
DEBUG - 2018-03-24 01:31:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 01:31:29 --> Input Class Initialized
INFO - 2018-03-24 01:31:29 --> Language Class Initialized
INFO - 2018-03-24 01:31:29 --> Loader Class Initialized
INFO - 2018-03-24 01:31:29 --> Helper loaded: url_helper
INFO - 2018-03-24 01:31:29 --> Helper loaded: form_helper
INFO - 2018-03-24 01:31:29 --> Database Driver Class Initialized
DEBUG - 2018-03-24 01:31:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 01:31:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 01:31:29 --> Form Validation Class Initialized
INFO - 2018-03-24 01:31:29 --> Model Class Initialized
INFO - 2018-03-24 01:31:29 --> Controller Class Initialized
INFO - 2018-03-24 01:31:29 --> Model Class Initialized
INFO - 2018-03-24 01:31:29 --> Model Class Initialized
INFO - 2018-03-24 01:31:29 --> Model Class Initialized
INFO - 2018-03-24 01:31:29 --> Model Class Initialized
DEBUG - 2018-03-24 01:31:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 01:31:29 --> Model Class Initialized
INFO - 2018-03-24 01:31:29 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-24 01:31:29 --> Final output sent to browser
DEBUG - 2018-03-24 01:31:29 --> Total execution time: 0.0779
INFO - 2018-03-24 01:31:29 --> Config Class Initialized
INFO - 2018-03-24 01:31:29 --> Hooks Class Initialized
DEBUG - 2018-03-24 01:31:29 --> UTF-8 Support Enabled
INFO - 2018-03-24 01:31:29 --> Utf8 Class Initialized
INFO - 2018-03-24 01:31:29 --> URI Class Initialized
INFO - 2018-03-24 01:31:29 --> Router Class Initialized
INFO - 2018-03-24 01:31:29 --> Output Class Initialized
INFO - 2018-03-24 01:31:29 --> Security Class Initialized
DEBUG - 2018-03-24 01:31:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 01:31:29 --> Input Class Initialized
INFO - 2018-03-24 01:31:29 --> Language Class Initialized
INFO - 2018-03-24 01:31:29 --> Loader Class Initialized
INFO - 2018-03-24 01:31:29 --> Helper loaded: url_helper
INFO - 2018-03-24 01:31:29 --> Helper loaded: form_helper
INFO - 2018-03-24 01:31:29 --> Database Driver Class Initialized
DEBUG - 2018-03-24 01:31:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 01:31:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 01:31:29 --> Form Validation Class Initialized
INFO - 2018-03-24 01:31:29 --> Model Class Initialized
INFO - 2018-03-24 01:31:29 --> Controller Class Initialized
INFO - 2018-03-24 01:31:29 --> Model Class Initialized
INFO - 2018-03-24 01:31:29 --> Model Class Initialized
DEBUG - 2018-03-24 01:31:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 01:31:33 --> Config Class Initialized
INFO - 2018-03-24 01:31:33 --> Hooks Class Initialized
DEBUG - 2018-03-24 01:31:33 --> UTF-8 Support Enabled
INFO - 2018-03-24 01:31:33 --> Utf8 Class Initialized
INFO - 2018-03-24 01:31:33 --> URI Class Initialized
INFO - 2018-03-24 01:31:33 --> Router Class Initialized
INFO - 2018-03-24 01:31:33 --> Output Class Initialized
INFO - 2018-03-24 01:31:33 --> Security Class Initialized
DEBUG - 2018-03-24 01:31:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 01:31:33 --> Input Class Initialized
INFO - 2018-03-24 01:31:33 --> Language Class Initialized
INFO - 2018-03-24 01:31:33 --> Loader Class Initialized
INFO - 2018-03-24 01:31:33 --> Helper loaded: url_helper
INFO - 2018-03-24 01:31:33 --> Helper loaded: form_helper
INFO - 2018-03-24 01:31:34 --> Database Driver Class Initialized
DEBUG - 2018-03-24 01:31:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 01:31:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 01:31:34 --> Form Validation Class Initialized
INFO - 2018-03-24 01:31:34 --> Model Class Initialized
INFO - 2018-03-24 01:31:34 --> Controller Class Initialized
INFO - 2018-03-24 01:31:34 --> Model Class Initialized
INFO - 2018-03-24 01:31:34 --> Model Class Initialized
INFO - 2018-03-24 01:31:34 --> Model Class Initialized
INFO - 2018-03-24 01:31:34 --> Model Class Initialized
DEBUG - 2018-03-24 01:31:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-24 01:31:34 --> Model Class Initialized
INFO - 2018-03-24 01:31:34 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-24 01:31:34 --> Final output sent to browser
DEBUG - 2018-03-24 01:31:34 --> Total execution time: 0.0941
INFO - 2018-03-24 01:31:34 --> Config Class Initialized
INFO - 2018-03-24 01:31:34 --> Hooks Class Initialized
DEBUG - 2018-03-24 01:31:34 --> UTF-8 Support Enabled
INFO - 2018-03-24 01:31:34 --> Utf8 Class Initialized
INFO - 2018-03-24 01:31:34 --> URI Class Initialized
INFO - 2018-03-24 01:31:34 --> Router Class Initialized
INFO - 2018-03-24 01:31:34 --> Output Class Initialized
INFO - 2018-03-24 01:31:34 --> Security Class Initialized
DEBUG - 2018-03-24 01:31:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 01:31:34 --> Input Class Initialized
INFO - 2018-03-24 01:31:34 --> Language Class Initialized
INFO - 2018-03-24 01:31:34 --> Loader Class Initialized
INFO - 2018-03-24 01:31:34 --> Helper loaded: url_helper
INFO - 2018-03-24 01:31:34 --> Helper loaded: form_helper
INFO - 2018-03-24 01:31:34 --> Database Driver Class Initialized
DEBUG - 2018-03-24 01:31:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 01:31:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 01:31:34 --> Form Validation Class Initialized
INFO - 2018-03-24 01:31:34 --> Model Class Initialized
INFO - 2018-03-24 01:31:34 --> Controller Class Initialized
INFO - 2018-03-24 01:31:34 --> Model Class Initialized
INFO - 2018-03-24 01:31:34 --> Model Class Initialized
INFO - 2018-03-24 01:31:34 --> Model Class Initialized
INFO - 2018-03-24 01:31:34 --> Model Class Initialized
DEBUG - 2018-03-24 01:31:34 --> Form_validation class already loaded. Second attempt ignored.
