<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-02-11 00:11:29 --> Config Class Initialized
INFO - 2018-02-11 00:11:29 --> Hooks Class Initialized
DEBUG - 2018-02-11 00:11:29 --> UTF-8 Support Enabled
INFO - 2018-02-11 00:11:29 --> Utf8 Class Initialized
INFO - 2018-02-11 00:11:29 --> URI Class Initialized
INFO - 2018-02-11 00:11:29 --> Router Class Initialized
INFO - 2018-02-11 00:11:29 --> Output Class Initialized
INFO - 2018-02-11 00:11:29 --> Security Class Initialized
DEBUG - 2018-02-11 00:11:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 00:11:29 --> Input Class Initialized
INFO - 2018-02-11 00:11:29 --> Language Class Initialized
INFO - 2018-02-11 00:11:29 --> Loader Class Initialized
INFO - 2018-02-11 00:11:29 --> Helper loaded: url_helper
INFO - 2018-02-11 00:11:29 --> Helper loaded: form_helper
INFO - 2018-02-11 00:11:29 --> Database Driver Class Initialized
DEBUG - 2018-02-11 00:11:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 00:11:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 00:11:29 --> Form Validation Class Initialized
INFO - 2018-02-11 00:11:29 --> Model Class Initialized
INFO - 2018-02-11 00:11:29 --> Controller Class Initialized
INFO - 2018-02-11 00:11:29 --> Model Class Initialized
INFO - 2018-02-11 00:11:29 --> Model Class Initialized
INFO - 2018-02-11 00:11:29 --> Model Class Initialized
INFO - 2018-02-11 00:11:29 --> Model Class Initialized
INFO - 2018-02-11 00:11:29 --> Model Class Initialized
DEBUG - 2018-02-11 00:11:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 00:11:29 --> Config Class Initialized
INFO - 2018-02-11 00:11:29 --> Hooks Class Initialized
DEBUG - 2018-02-11 00:11:29 --> UTF-8 Support Enabled
INFO - 2018-02-11 00:11:29 --> Utf8 Class Initialized
INFO - 2018-02-11 00:11:29 --> URI Class Initialized
INFO - 2018-02-11 00:11:29 --> Router Class Initialized
INFO - 2018-02-11 00:11:29 --> Output Class Initialized
INFO - 2018-02-11 00:11:29 --> Security Class Initialized
DEBUG - 2018-02-11 00:11:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 00:11:29 --> Input Class Initialized
INFO - 2018-02-11 00:11:29 --> Language Class Initialized
INFO - 2018-02-11 00:11:29 --> Loader Class Initialized
INFO - 2018-02-11 00:11:29 --> Helper loaded: url_helper
INFO - 2018-02-11 00:11:29 --> Helper loaded: form_helper
INFO - 2018-02-11 00:11:29 --> Database Driver Class Initialized
DEBUG - 2018-02-11 00:11:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 00:11:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 00:11:29 --> Form Validation Class Initialized
INFO - 2018-02-11 00:11:29 --> Model Class Initialized
INFO - 2018-02-11 00:11:29 --> Controller Class Initialized
INFO - 2018-02-11 00:11:29 --> Model Class Initialized
DEBUG - 2018-02-11 00:11:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 00:11:30 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-11 00:11:30 --> Final output sent to browser
DEBUG - 2018-02-11 00:11:30 --> Total execution time: 0.1241
INFO - 2018-02-11 00:11:31 --> Config Class Initialized
INFO - 2018-02-11 00:11:31 --> Hooks Class Initialized
DEBUG - 2018-02-11 00:11:31 --> UTF-8 Support Enabled
INFO - 2018-02-11 00:11:31 --> Utf8 Class Initialized
INFO - 2018-02-11 00:11:31 --> URI Class Initialized
INFO - 2018-02-11 00:11:31 --> Router Class Initialized
INFO - 2018-02-11 00:11:31 --> Output Class Initialized
INFO - 2018-02-11 00:11:31 --> Security Class Initialized
DEBUG - 2018-02-11 00:11:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 00:11:31 --> Input Class Initialized
INFO - 2018-02-11 00:11:31 --> Language Class Initialized
INFO - 2018-02-11 00:11:31 --> Loader Class Initialized
INFO - 2018-02-11 00:11:31 --> Helper loaded: url_helper
INFO - 2018-02-11 00:11:31 --> Helper loaded: form_helper
INFO - 2018-02-11 00:11:31 --> Database Driver Class Initialized
DEBUG - 2018-02-11 00:11:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 00:11:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 00:11:31 --> Form Validation Class Initialized
INFO - 2018-02-11 00:11:31 --> Model Class Initialized
INFO - 2018-02-11 00:11:31 --> Controller Class Initialized
INFO - 2018-02-11 00:11:31 --> Model Class Initialized
DEBUG - 2018-02-11 00:11:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 00:11:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-11 00:11:31 --> Config Class Initialized
INFO - 2018-02-11 00:11:31 --> Hooks Class Initialized
DEBUG - 2018-02-11 00:11:31 --> UTF-8 Support Enabled
INFO - 2018-02-11 00:11:31 --> Utf8 Class Initialized
INFO - 2018-02-11 00:11:31 --> URI Class Initialized
DEBUG - 2018-02-11 00:11:31 --> No URI present. Default controller set.
INFO - 2018-02-11 00:11:31 --> Router Class Initialized
INFO - 2018-02-11 00:11:31 --> Output Class Initialized
INFO - 2018-02-11 00:11:31 --> Security Class Initialized
DEBUG - 2018-02-11 00:11:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 00:11:31 --> Input Class Initialized
INFO - 2018-02-11 00:11:31 --> Language Class Initialized
INFO - 2018-02-11 00:11:31 --> Loader Class Initialized
INFO - 2018-02-11 00:11:31 --> Helper loaded: url_helper
INFO - 2018-02-11 00:11:31 --> Helper loaded: form_helper
INFO - 2018-02-11 00:11:31 --> Database Driver Class Initialized
DEBUG - 2018-02-11 00:11:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 00:11:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 00:11:31 --> Form Validation Class Initialized
INFO - 2018-02-11 00:11:31 --> Model Class Initialized
INFO - 2018-02-11 00:11:31 --> Controller Class Initialized
INFO - 2018-02-11 00:11:31 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-11 00:11:31 --> Final output sent to browser
DEBUG - 2018-02-11 00:11:31 --> Total execution time: 0.0739
INFO - 2018-02-11 00:11:31 --> Config Class Initialized
INFO - 2018-02-11 00:11:31 --> Hooks Class Initialized
DEBUG - 2018-02-11 00:11:31 --> UTF-8 Support Enabled
INFO - 2018-02-11 00:11:31 --> Utf8 Class Initialized
INFO - 2018-02-11 00:11:31 --> URI Class Initialized
INFO - 2018-02-11 00:11:31 --> Router Class Initialized
INFO - 2018-02-11 00:11:31 --> Output Class Initialized
INFO - 2018-02-11 00:11:31 --> Security Class Initialized
DEBUG - 2018-02-11 00:11:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 00:11:31 --> Input Class Initialized
INFO - 2018-02-11 00:11:31 --> Language Class Initialized
INFO - 2018-02-11 00:11:31 --> Loader Class Initialized
INFO - 2018-02-11 00:11:31 --> Helper loaded: url_helper
INFO - 2018-02-11 00:11:31 --> Helper loaded: form_helper
INFO - 2018-02-11 00:11:31 --> Database Driver Class Initialized
DEBUG - 2018-02-11 00:11:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 00:11:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 00:11:31 --> Form Validation Class Initialized
INFO - 2018-02-11 00:11:31 --> Model Class Initialized
INFO - 2018-02-11 00:11:31 --> Controller Class Initialized
INFO - 2018-02-11 00:11:31 --> Model Class Initialized
INFO - 2018-02-11 00:11:31 --> Model Class Initialized
INFO - 2018-02-11 00:11:31 --> Model Class Initialized
INFO - 2018-02-11 00:11:31 --> Model Class Initialized
INFO - 2018-02-11 00:11:31 --> Model Class Initialized
DEBUG - 2018-02-11 00:11:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 00:11:34 --> Config Class Initialized
INFO - 2018-02-11 00:11:34 --> Hooks Class Initialized
DEBUG - 2018-02-11 00:11:34 --> UTF-8 Support Enabled
INFO - 2018-02-11 00:11:34 --> Utf8 Class Initialized
INFO - 2018-02-11 00:11:34 --> URI Class Initialized
INFO - 2018-02-11 00:11:34 --> Router Class Initialized
INFO - 2018-02-11 00:11:34 --> Output Class Initialized
INFO - 2018-02-11 00:11:34 --> Security Class Initialized
DEBUG - 2018-02-11 00:11:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 00:11:34 --> Input Class Initialized
INFO - 2018-02-11 00:11:34 --> Language Class Initialized
INFO - 2018-02-11 00:11:34 --> Loader Class Initialized
INFO - 2018-02-11 00:11:34 --> Helper loaded: url_helper
INFO - 2018-02-11 00:11:34 --> Helper loaded: form_helper
INFO - 2018-02-11 00:11:34 --> Database Driver Class Initialized
DEBUG - 2018-02-11 00:11:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 00:11:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 00:11:34 --> Form Validation Class Initialized
INFO - 2018-02-11 00:11:34 --> Model Class Initialized
INFO - 2018-02-11 00:11:34 --> Controller Class Initialized
INFO - 2018-02-11 00:11:34 --> Model Class Initialized
INFO - 2018-02-11 00:11:34 --> Model Class Initialized
INFO - 2018-02-11 00:11:34 --> Model Class Initialized
INFO - 2018-02-11 00:11:34 --> Model Class Initialized
INFO - 2018-02-11 00:11:34 --> Model Class Initialized
DEBUG - 2018-02-11 00:11:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 00:11:34 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-11 00:11:34 --> Final output sent to browser
DEBUG - 2018-02-11 00:11:34 --> Total execution time: 0.0523
INFO - 2018-02-11 00:11:34 --> Config Class Initialized
INFO - 2018-02-11 00:11:34 --> Hooks Class Initialized
DEBUG - 2018-02-11 00:11:34 --> UTF-8 Support Enabled
INFO - 2018-02-11 00:11:34 --> Utf8 Class Initialized
INFO - 2018-02-11 00:11:34 --> URI Class Initialized
INFO - 2018-02-11 00:11:34 --> Router Class Initialized
INFO - 2018-02-11 00:11:34 --> Output Class Initialized
INFO - 2018-02-11 00:11:34 --> Security Class Initialized
DEBUG - 2018-02-11 00:11:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 00:11:34 --> Input Class Initialized
INFO - 2018-02-11 00:11:34 --> Language Class Initialized
INFO - 2018-02-11 00:11:34 --> Loader Class Initialized
INFO - 2018-02-11 00:11:34 --> Helper loaded: url_helper
INFO - 2018-02-11 00:11:34 --> Helper loaded: form_helper
INFO - 2018-02-11 00:11:34 --> Database Driver Class Initialized
DEBUG - 2018-02-11 00:11:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 00:11:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 00:11:34 --> Form Validation Class Initialized
INFO - 2018-02-11 00:11:34 --> Model Class Initialized
INFO - 2018-02-11 00:11:34 --> Controller Class Initialized
INFO - 2018-02-11 00:11:34 --> Model Class Initialized
INFO - 2018-02-11 00:11:34 --> Model Class Initialized
INFO - 2018-02-11 00:11:34 --> Model Class Initialized
INFO - 2018-02-11 00:11:34 --> Model Class Initialized
INFO - 2018-02-11 00:11:34 --> Model Class Initialized
DEBUG - 2018-02-11 00:11:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 00:11:35 --> Config Class Initialized
INFO - 2018-02-11 00:11:35 --> Hooks Class Initialized
DEBUG - 2018-02-11 00:11:35 --> UTF-8 Support Enabled
INFO - 2018-02-11 00:11:35 --> Utf8 Class Initialized
INFO - 2018-02-11 00:11:35 --> URI Class Initialized
INFO - 2018-02-11 00:11:35 --> Router Class Initialized
INFO - 2018-02-11 00:11:35 --> Output Class Initialized
INFO - 2018-02-11 00:11:35 --> Security Class Initialized
DEBUG - 2018-02-11 00:11:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 00:11:35 --> Input Class Initialized
INFO - 2018-02-11 00:11:35 --> Language Class Initialized
INFO - 2018-02-11 00:11:35 --> Loader Class Initialized
INFO - 2018-02-11 00:11:35 --> Helper loaded: url_helper
INFO - 2018-02-11 00:11:35 --> Helper loaded: form_helper
INFO - 2018-02-11 00:11:35 --> Database Driver Class Initialized
DEBUG - 2018-02-11 00:11:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 00:11:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 00:11:35 --> Form Validation Class Initialized
INFO - 2018-02-11 00:11:35 --> Model Class Initialized
INFO - 2018-02-11 00:11:35 --> Controller Class Initialized
INFO - 2018-02-11 00:11:35 --> Model Class Initialized
INFO - 2018-02-11 00:11:35 --> Model Class Initialized
INFO - 2018-02-11 00:11:35 --> Model Class Initialized
INFO - 2018-02-11 00:11:35 --> Model Class Initialized
INFO - 2018-02-11 00:11:35 --> Model Class Initialized
DEBUG - 2018-02-11 00:11:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 00:11:35 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-11 00:11:35 --> Final output sent to browser
DEBUG - 2018-02-11 00:11:35 --> Total execution time: 0.0698
INFO - 2018-02-11 00:11:36 --> Config Class Initialized
INFO - 2018-02-11 00:11:36 --> Hooks Class Initialized
DEBUG - 2018-02-11 00:11:36 --> UTF-8 Support Enabled
INFO - 2018-02-11 00:11:36 --> Utf8 Class Initialized
INFO - 2018-02-11 00:11:36 --> URI Class Initialized
INFO - 2018-02-11 00:11:36 --> Router Class Initialized
INFO - 2018-02-11 00:11:36 --> Output Class Initialized
INFO - 2018-02-11 00:11:36 --> Security Class Initialized
DEBUG - 2018-02-11 00:11:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 00:11:36 --> Input Class Initialized
INFO - 2018-02-11 00:11:36 --> Language Class Initialized
INFO - 2018-02-11 00:11:36 --> Loader Class Initialized
INFO - 2018-02-11 00:11:36 --> Helper loaded: url_helper
INFO - 2018-02-11 00:11:36 --> Helper loaded: form_helper
INFO - 2018-02-11 00:11:36 --> Database Driver Class Initialized
DEBUG - 2018-02-11 00:11:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 00:11:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 00:11:36 --> Form Validation Class Initialized
INFO - 2018-02-11 00:11:36 --> Model Class Initialized
INFO - 2018-02-11 00:11:36 --> Controller Class Initialized
INFO - 2018-02-11 00:11:36 --> Model Class Initialized
INFO - 2018-02-11 00:11:36 --> Model Class Initialized
INFO - 2018-02-11 00:11:36 --> Model Class Initialized
INFO - 2018-02-11 00:11:36 --> Model Class Initialized
INFO - 2018-02-11 00:11:36 --> Model Class Initialized
DEBUG - 2018-02-11 00:11:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 00:11:37 --> Config Class Initialized
INFO - 2018-02-11 00:11:37 --> Hooks Class Initialized
DEBUG - 2018-02-11 00:11:37 --> UTF-8 Support Enabled
INFO - 2018-02-11 00:11:37 --> Utf8 Class Initialized
INFO - 2018-02-11 00:11:37 --> URI Class Initialized
INFO - 2018-02-11 00:11:37 --> Router Class Initialized
INFO - 2018-02-11 00:11:37 --> Output Class Initialized
INFO - 2018-02-11 00:11:37 --> Security Class Initialized
DEBUG - 2018-02-11 00:11:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 00:11:37 --> Input Class Initialized
INFO - 2018-02-11 00:11:37 --> Language Class Initialized
INFO - 2018-02-11 00:11:37 --> Loader Class Initialized
INFO - 2018-02-11 00:11:37 --> Helper loaded: url_helper
INFO - 2018-02-11 00:11:37 --> Helper loaded: form_helper
INFO - 2018-02-11 00:11:37 --> Database Driver Class Initialized
DEBUG - 2018-02-11 00:11:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 00:11:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 00:11:37 --> Form Validation Class Initialized
INFO - 2018-02-11 00:11:37 --> Model Class Initialized
INFO - 2018-02-11 00:11:37 --> Controller Class Initialized
INFO - 2018-02-11 00:11:37 --> Model Class Initialized
INFO - 2018-02-11 00:11:37 --> Model Class Initialized
INFO - 2018-02-11 00:11:37 --> Model Class Initialized
INFO - 2018-02-11 00:11:37 --> Model Class Initialized
INFO - 2018-02-11 00:11:37 --> Model Class Initialized
DEBUG - 2018-02-11 00:11:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 00:11:37 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-11 00:11:37 --> Final output sent to browser
DEBUG - 2018-02-11 00:11:37 --> Total execution time: 0.0733
INFO - 2018-02-11 00:26:56 --> Config Class Initialized
INFO - 2018-02-11 00:26:56 --> Hooks Class Initialized
DEBUG - 2018-02-11 00:26:56 --> UTF-8 Support Enabled
INFO - 2018-02-11 00:26:56 --> Utf8 Class Initialized
INFO - 2018-02-11 00:26:56 --> URI Class Initialized
INFO - 2018-02-11 00:26:56 --> Router Class Initialized
INFO - 2018-02-11 00:26:56 --> Output Class Initialized
INFO - 2018-02-11 00:26:56 --> Security Class Initialized
DEBUG - 2018-02-11 00:26:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 00:26:56 --> Input Class Initialized
INFO - 2018-02-11 00:26:56 --> Language Class Initialized
INFO - 2018-02-11 00:26:56 --> Loader Class Initialized
INFO - 2018-02-11 00:26:56 --> Helper loaded: url_helper
INFO - 2018-02-11 00:26:56 --> Helper loaded: form_helper
INFO - 2018-02-11 00:26:56 --> Database Driver Class Initialized
DEBUG - 2018-02-11 00:26:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 00:26:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 00:26:56 --> Form Validation Class Initialized
INFO - 2018-02-11 00:26:56 --> Model Class Initialized
INFO - 2018-02-11 00:26:56 --> Controller Class Initialized
INFO - 2018-02-11 00:26:56 --> Model Class Initialized
INFO - 2018-02-11 00:26:56 --> Model Class Initialized
INFO - 2018-02-11 00:26:56 --> Model Class Initialized
INFO - 2018-02-11 00:26:56 --> Model Class Initialized
INFO - 2018-02-11 00:26:56 --> Model Class Initialized
DEBUG - 2018-02-11 00:26:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 00:26:56 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-11 00:26:56 --> Final output sent to browser
DEBUG - 2018-02-11 00:26:56 --> Total execution time: 0.0589
INFO - 2018-02-11 00:27:22 --> Config Class Initialized
INFO - 2018-02-11 00:27:22 --> Hooks Class Initialized
DEBUG - 2018-02-11 00:27:22 --> UTF-8 Support Enabled
INFO - 2018-02-11 00:27:22 --> Utf8 Class Initialized
INFO - 2018-02-11 00:27:22 --> URI Class Initialized
INFO - 2018-02-11 00:27:22 --> Router Class Initialized
INFO - 2018-02-11 00:27:22 --> Output Class Initialized
INFO - 2018-02-11 00:27:22 --> Security Class Initialized
DEBUG - 2018-02-11 00:27:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 00:27:22 --> Input Class Initialized
INFO - 2018-02-11 00:27:22 --> Language Class Initialized
INFO - 2018-02-11 00:27:22 --> Loader Class Initialized
INFO - 2018-02-11 00:27:22 --> Helper loaded: url_helper
INFO - 2018-02-11 00:27:22 --> Helper loaded: form_helper
INFO - 2018-02-11 00:27:22 --> Database Driver Class Initialized
DEBUG - 2018-02-11 00:27:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 00:27:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 00:27:23 --> Form Validation Class Initialized
INFO - 2018-02-11 00:27:23 --> Model Class Initialized
INFO - 2018-02-11 00:27:23 --> Controller Class Initialized
INFO - 2018-02-11 00:27:23 --> Model Class Initialized
INFO - 2018-02-11 00:27:23 --> Model Class Initialized
INFO - 2018-02-11 00:27:23 --> Model Class Initialized
INFO - 2018-02-11 00:27:23 --> Model Class Initialized
INFO - 2018-02-11 00:27:23 --> Model Class Initialized
DEBUG - 2018-02-11 00:27:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 00:27:23 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-11 00:27:23 --> Final output sent to browser
DEBUG - 2018-02-11 00:27:23 --> Total execution time: 0.0719
INFO - 2018-02-11 00:27:51 --> Config Class Initialized
INFO - 2018-02-11 00:27:51 --> Hooks Class Initialized
DEBUG - 2018-02-11 00:27:51 --> UTF-8 Support Enabled
INFO - 2018-02-11 00:27:51 --> Utf8 Class Initialized
INFO - 2018-02-11 00:27:51 --> URI Class Initialized
INFO - 2018-02-11 00:27:51 --> Router Class Initialized
INFO - 2018-02-11 00:27:51 --> Output Class Initialized
INFO - 2018-02-11 00:27:51 --> Security Class Initialized
DEBUG - 2018-02-11 00:27:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 00:27:51 --> Input Class Initialized
INFO - 2018-02-11 00:27:51 --> Language Class Initialized
INFO - 2018-02-11 00:27:51 --> Loader Class Initialized
INFO - 2018-02-11 00:27:51 --> Helper loaded: url_helper
INFO - 2018-02-11 00:27:51 --> Helper loaded: form_helper
INFO - 2018-02-11 00:27:51 --> Database Driver Class Initialized
DEBUG - 2018-02-11 00:27:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 00:27:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 00:27:51 --> Form Validation Class Initialized
INFO - 2018-02-11 00:27:51 --> Model Class Initialized
INFO - 2018-02-11 00:27:51 --> Controller Class Initialized
INFO - 2018-02-11 00:27:51 --> Model Class Initialized
INFO - 2018-02-11 00:27:51 --> Model Class Initialized
INFO - 2018-02-11 00:27:51 --> Model Class Initialized
INFO - 2018-02-11 00:27:51 --> Model Class Initialized
INFO - 2018-02-11 00:27:51 --> Model Class Initialized
DEBUG - 2018-02-11 00:27:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 00:27:51 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-11 00:27:51 --> Final output sent to browser
DEBUG - 2018-02-11 00:27:51 --> Total execution time: 0.0765
INFO - 2018-02-11 00:27:59 --> Config Class Initialized
INFO - 2018-02-11 00:27:59 --> Hooks Class Initialized
DEBUG - 2018-02-11 00:27:59 --> UTF-8 Support Enabled
INFO - 2018-02-11 00:27:59 --> Utf8 Class Initialized
INFO - 2018-02-11 00:27:59 --> URI Class Initialized
INFO - 2018-02-11 00:27:59 --> Router Class Initialized
INFO - 2018-02-11 00:27:59 --> Output Class Initialized
INFO - 2018-02-11 00:27:59 --> Security Class Initialized
DEBUG - 2018-02-11 00:27:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 00:27:59 --> Input Class Initialized
INFO - 2018-02-11 00:27:59 --> Language Class Initialized
INFO - 2018-02-11 00:27:59 --> Loader Class Initialized
INFO - 2018-02-11 00:27:59 --> Helper loaded: url_helper
INFO - 2018-02-11 00:27:59 --> Helper loaded: form_helper
INFO - 2018-02-11 00:27:59 --> Database Driver Class Initialized
DEBUG - 2018-02-11 00:27:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 00:27:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 00:27:59 --> Form Validation Class Initialized
INFO - 2018-02-11 00:27:59 --> Model Class Initialized
INFO - 2018-02-11 00:27:59 --> Controller Class Initialized
INFO - 2018-02-11 00:27:59 --> Model Class Initialized
INFO - 2018-02-11 00:27:59 --> Model Class Initialized
INFO - 2018-02-11 00:27:59 --> Model Class Initialized
INFO - 2018-02-11 00:27:59 --> Model Class Initialized
INFO - 2018-02-11 00:27:59 --> Model Class Initialized
DEBUG - 2018-02-11 00:27:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 00:27:59 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-11 00:27:59 --> Final output sent to browser
DEBUG - 2018-02-11 00:27:59 --> Total execution time: 0.0629
INFO - 2018-02-11 00:27:59 --> Config Class Initialized
INFO - 2018-02-11 00:27:59 --> Hooks Class Initialized
DEBUG - 2018-02-11 00:27:59 --> UTF-8 Support Enabled
INFO - 2018-02-11 00:27:59 --> Utf8 Class Initialized
INFO - 2018-02-11 00:27:59 --> URI Class Initialized
INFO - 2018-02-11 00:27:59 --> Router Class Initialized
INFO - 2018-02-11 00:27:59 --> Output Class Initialized
INFO - 2018-02-11 00:27:59 --> Security Class Initialized
DEBUG - 2018-02-11 00:27:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 00:27:59 --> Input Class Initialized
INFO - 2018-02-11 00:27:59 --> Language Class Initialized
INFO - 2018-02-11 00:27:59 --> Loader Class Initialized
INFO - 2018-02-11 00:27:59 --> Helper loaded: url_helper
INFO - 2018-02-11 00:27:59 --> Helper loaded: form_helper
INFO - 2018-02-11 00:27:59 --> Database Driver Class Initialized
DEBUG - 2018-02-11 00:27:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 00:27:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 00:27:59 --> Form Validation Class Initialized
INFO - 2018-02-11 00:27:59 --> Model Class Initialized
INFO - 2018-02-11 00:27:59 --> Controller Class Initialized
INFO - 2018-02-11 00:27:59 --> Model Class Initialized
INFO - 2018-02-11 00:27:59 --> Model Class Initialized
INFO - 2018-02-11 00:27:59 --> Model Class Initialized
INFO - 2018-02-11 00:27:59 --> Model Class Initialized
INFO - 2018-02-11 00:27:59 --> Model Class Initialized
DEBUG - 2018-02-11 00:27:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 00:28:00 --> Config Class Initialized
INFO - 2018-02-11 00:28:00 --> Hooks Class Initialized
DEBUG - 2018-02-11 00:28:00 --> UTF-8 Support Enabled
INFO - 2018-02-11 00:28:00 --> Utf8 Class Initialized
INFO - 2018-02-11 00:28:00 --> URI Class Initialized
INFO - 2018-02-11 00:28:00 --> Router Class Initialized
INFO - 2018-02-11 00:28:00 --> Output Class Initialized
INFO - 2018-02-11 00:28:00 --> Security Class Initialized
DEBUG - 2018-02-11 00:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 00:28:00 --> Input Class Initialized
INFO - 2018-02-11 00:28:00 --> Language Class Initialized
INFO - 2018-02-11 00:28:00 --> Loader Class Initialized
INFO - 2018-02-11 00:28:00 --> Helper loaded: url_helper
INFO - 2018-02-11 00:28:00 --> Helper loaded: form_helper
INFO - 2018-02-11 00:28:00 --> Database Driver Class Initialized
DEBUG - 2018-02-11 00:28:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 00:28:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 00:28:00 --> Form Validation Class Initialized
INFO - 2018-02-11 00:28:00 --> Model Class Initialized
INFO - 2018-02-11 00:28:00 --> Controller Class Initialized
INFO - 2018-02-11 00:28:00 --> Model Class Initialized
INFO - 2018-02-11 00:28:00 --> Model Class Initialized
INFO - 2018-02-11 00:28:00 --> Model Class Initialized
INFO - 2018-02-11 00:28:00 --> Model Class Initialized
INFO - 2018-02-11 00:28:00 --> Model Class Initialized
DEBUG - 2018-02-11 00:28:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 00:28:00 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-11 00:28:00 --> Final output sent to browser
DEBUG - 2018-02-11 00:28:00 --> Total execution time: 0.0502
INFO - 2018-02-11 00:28:02 --> Config Class Initialized
INFO - 2018-02-11 00:28:02 --> Hooks Class Initialized
DEBUG - 2018-02-11 00:28:02 --> UTF-8 Support Enabled
INFO - 2018-02-11 00:28:02 --> Utf8 Class Initialized
INFO - 2018-02-11 00:28:02 --> URI Class Initialized
INFO - 2018-02-11 00:28:02 --> Router Class Initialized
INFO - 2018-02-11 00:28:02 --> Output Class Initialized
INFO - 2018-02-11 00:28:02 --> Security Class Initialized
DEBUG - 2018-02-11 00:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 00:28:02 --> Input Class Initialized
INFO - 2018-02-11 00:28:02 --> Language Class Initialized
INFO - 2018-02-11 00:28:02 --> Loader Class Initialized
INFO - 2018-02-11 00:28:02 --> Helper loaded: url_helper
INFO - 2018-02-11 00:28:02 --> Helper loaded: form_helper
INFO - 2018-02-11 00:28:02 --> Database Driver Class Initialized
DEBUG - 2018-02-11 00:28:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 00:28:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 00:28:02 --> Form Validation Class Initialized
INFO - 2018-02-11 00:28:02 --> Model Class Initialized
INFO - 2018-02-11 00:28:02 --> Controller Class Initialized
INFO - 2018-02-11 00:28:02 --> Model Class Initialized
INFO - 2018-02-11 00:28:02 --> Model Class Initialized
INFO - 2018-02-11 00:28:02 --> Model Class Initialized
INFO - 2018-02-11 00:28:02 --> Model Class Initialized
INFO - 2018-02-11 00:28:02 --> Model Class Initialized
DEBUG - 2018-02-11 00:28:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 00:28:02 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-11 00:28:02 --> Final output sent to browser
DEBUG - 2018-02-11 00:28:02 --> Total execution time: 0.0601
INFO - 2018-02-11 00:48:30 --> Config Class Initialized
INFO - 2018-02-11 00:48:30 --> Hooks Class Initialized
DEBUG - 2018-02-11 00:48:30 --> UTF-8 Support Enabled
INFO - 2018-02-11 00:48:30 --> Utf8 Class Initialized
INFO - 2018-02-11 00:48:30 --> URI Class Initialized
INFO - 2018-02-11 00:48:30 --> Router Class Initialized
INFO - 2018-02-11 00:48:30 --> Output Class Initialized
INFO - 2018-02-11 00:48:30 --> Security Class Initialized
DEBUG - 2018-02-11 00:48:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 00:48:30 --> Input Class Initialized
INFO - 2018-02-11 00:48:30 --> Language Class Initialized
INFO - 2018-02-11 00:48:30 --> Loader Class Initialized
INFO - 2018-02-11 00:48:30 --> Helper loaded: url_helper
INFO - 2018-02-11 00:48:30 --> Helper loaded: form_helper
INFO - 2018-02-11 00:48:30 --> Database Driver Class Initialized
DEBUG - 2018-02-11 00:48:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 00:48:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 00:48:30 --> Form Validation Class Initialized
INFO - 2018-02-11 00:48:30 --> Model Class Initialized
INFO - 2018-02-11 00:48:30 --> Controller Class Initialized
INFO - 2018-02-11 00:48:30 --> Model Class Initialized
INFO - 2018-02-11 00:48:30 --> Model Class Initialized
INFO - 2018-02-11 00:48:30 --> Model Class Initialized
INFO - 2018-02-11 00:48:30 --> Model Class Initialized
INFO - 2018-02-11 00:48:30 --> Model Class Initialized
DEBUG - 2018-02-11 00:48:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 00:48:30 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-11 00:48:30 --> Final output sent to browser
DEBUG - 2018-02-11 00:48:30 --> Total execution time: 0.0481
INFO - 2018-02-11 00:48:32 --> Config Class Initialized
INFO - 2018-02-11 00:48:32 --> Hooks Class Initialized
DEBUG - 2018-02-11 00:48:32 --> UTF-8 Support Enabled
INFO - 2018-02-11 00:48:32 --> Utf8 Class Initialized
INFO - 2018-02-11 00:48:32 --> URI Class Initialized
INFO - 2018-02-11 00:48:32 --> Router Class Initialized
INFO - 2018-02-11 00:48:32 --> Output Class Initialized
INFO - 2018-02-11 00:48:32 --> Security Class Initialized
DEBUG - 2018-02-11 00:48:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 00:48:32 --> Input Class Initialized
INFO - 2018-02-11 00:48:32 --> Language Class Initialized
INFO - 2018-02-11 00:48:32 --> Loader Class Initialized
INFO - 2018-02-11 00:48:32 --> Helper loaded: url_helper
INFO - 2018-02-11 00:48:32 --> Helper loaded: form_helper
INFO - 2018-02-11 00:48:32 --> Database Driver Class Initialized
DEBUG - 2018-02-11 00:48:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 00:48:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 00:48:32 --> Form Validation Class Initialized
INFO - 2018-02-11 00:48:32 --> Model Class Initialized
INFO - 2018-02-11 00:48:32 --> Controller Class Initialized
INFO - 2018-02-11 00:48:32 --> Model Class Initialized
INFO - 2018-02-11 00:48:32 --> Model Class Initialized
INFO - 2018-02-11 00:48:32 --> Model Class Initialized
INFO - 2018-02-11 00:48:32 --> Model Class Initialized
INFO - 2018-02-11 00:48:32 --> Model Class Initialized
DEBUG - 2018-02-11 00:48:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 00:48:32 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-11 00:48:32 --> Final output sent to browser
DEBUG - 2018-02-11 00:48:32 --> Total execution time: 0.0596
INFO - 2018-02-11 00:48:32 --> Config Class Initialized
INFO - 2018-02-11 00:48:32 --> Hooks Class Initialized
DEBUG - 2018-02-11 00:48:32 --> UTF-8 Support Enabled
INFO - 2018-02-11 00:48:32 --> Utf8 Class Initialized
INFO - 2018-02-11 00:48:32 --> URI Class Initialized
INFO - 2018-02-11 00:48:32 --> Router Class Initialized
INFO - 2018-02-11 00:48:32 --> Output Class Initialized
INFO - 2018-02-11 00:48:32 --> Security Class Initialized
DEBUG - 2018-02-11 00:48:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 00:48:32 --> Input Class Initialized
INFO - 2018-02-11 00:48:32 --> Language Class Initialized
INFO - 2018-02-11 00:48:32 --> Loader Class Initialized
INFO - 2018-02-11 00:48:32 --> Helper loaded: url_helper
INFO - 2018-02-11 00:48:32 --> Helper loaded: form_helper
INFO - 2018-02-11 00:48:32 --> Database Driver Class Initialized
DEBUG - 2018-02-11 00:48:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 00:48:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 00:48:32 --> Form Validation Class Initialized
INFO - 2018-02-11 00:48:32 --> Model Class Initialized
INFO - 2018-02-11 00:48:32 --> Controller Class Initialized
INFO - 2018-02-11 00:48:32 --> Model Class Initialized
INFO - 2018-02-11 00:48:32 --> Model Class Initialized
INFO - 2018-02-11 00:48:32 --> Model Class Initialized
INFO - 2018-02-11 00:48:32 --> Model Class Initialized
INFO - 2018-02-11 00:48:32 --> Model Class Initialized
DEBUG - 2018-02-11 00:48:32 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-11 00:48:32 --> Severity: Notice --> Undefined index: proyecto_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Proyecto.php 580
INFO - 2018-02-11 00:48:34 --> Config Class Initialized
INFO - 2018-02-11 00:48:34 --> Hooks Class Initialized
DEBUG - 2018-02-11 00:48:34 --> UTF-8 Support Enabled
INFO - 2018-02-11 00:48:34 --> Utf8 Class Initialized
INFO - 2018-02-11 00:48:34 --> URI Class Initialized
INFO - 2018-02-11 00:48:34 --> Router Class Initialized
INFO - 2018-02-11 00:48:34 --> Output Class Initialized
INFO - 2018-02-11 00:48:34 --> Security Class Initialized
DEBUG - 2018-02-11 00:48:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 00:48:34 --> Input Class Initialized
INFO - 2018-02-11 00:48:34 --> Language Class Initialized
INFO - 2018-02-11 00:48:34 --> Loader Class Initialized
INFO - 2018-02-11 00:48:34 --> Helper loaded: url_helper
INFO - 2018-02-11 00:48:34 --> Helper loaded: form_helper
INFO - 2018-02-11 00:48:34 --> Database Driver Class Initialized
DEBUG - 2018-02-11 00:48:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 00:48:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 00:48:34 --> Form Validation Class Initialized
INFO - 2018-02-11 00:48:34 --> Model Class Initialized
INFO - 2018-02-11 00:48:34 --> Controller Class Initialized
INFO - 2018-02-11 00:48:34 --> Model Class Initialized
INFO - 2018-02-11 00:48:34 --> Model Class Initialized
INFO - 2018-02-11 00:48:34 --> Model Class Initialized
INFO - 2018-02-11 00:48:34 --> Model Class Initialized
INFO - 2018-02-11 00:48:34 --> Model Class Initialized
DEBUG - 2018-02-11 00:48:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 00:48:34 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-11 00:48:34 --> Final output sent to browser
DEBUG - 2018-02-11 00:48:34 --> Total execution time: 0.0469
INFO - 2018-02-11 00:48:34 --> Config Class Initialized
INFO - 2018-02-11 00:48:34 --> Hooks Class Initialized
DEBUG - 2018-02-11 00:48:34 --> UTF-8 Support Enabled
INFO - 2018-02-11 00:48:34 --> Utf8 Class Initialized
INFO - 2018-02-11 00:48:34 --> URI Class Initialized
INFO - 2018-02-11 00:48:34 --> Router Class Initialized
INFO - 2018-02-11 00:48:34 --> Output Class Initialized
INFO - 2018-02-11 00:48:34 --> Security Class Initialized
DEBUG - 2018-02-11 00:48:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 00:48:34 --> Input Class Initialized
INFO - 2018-02-11 00:48:34 --> Language Class Initialized
INFO - 2018-02-11 00:48:34 --> Loader Class Initialized
INFO - 2018-02-11 00:48:34 --> Helper loaded: url_helper
INFO - 2018-02-11 00:48:34 --> Helper loaded: form_helper
INFO - 2018-02-11 00:48:34 --> Database Driver Class Initialized
DEBUG - 2018-02-11 00:48:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 00:48:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 00:48:34 --> Form Validation Class Initialized
INFO - 2018-02-11 00:48:34 --> Model Class Initialized
INFO - 2018-02-11 00:48:34 --> Controller Class Initialized
INFO - 2018-02-11 00:48:34 --> Model Class Initialized
INFO - 2018-02-11 00:48:34 --> Model Class Initialized
INFO - 2018-02-11 00:48:34 --> Model Class Initialized
INFO - 2018-02-11 00:48:34 --> Model Class Initialized
INFO - 2018-02-11 00:48:34 --> Model Class Initialized
DEBUG - 2018-02-11 00:48:34 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-11 00:48:34 --> Severity: Notice --> Undefined index: proyecto_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Proyecto.php 580
INFO - 2018-02-11 00:52:35 --> Config Class Initialized
INFO - 2018-02-11 00:52:35 --> Hooks Class Initialized
DEBUG - 2018-02-11 00:52:35 --> UTF-8 Support Enabled
INFO - 2018-02-11 00:52:35 --> Utf8 Class Initialized
INFO - 2018-02-11 00:52:35 --> URI Class Initialized
INFO - 2018-02-11 00:52:35 --> Router Class Initialized
INFO - 2018-02-11 00:52:35 --> Output Class Initialized
INFO - 2018-02-11 00:52:35 --> Security Class Initialized
DEBUG - 2018-02-11 00:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 00:52:35 --> Input Class Initialized
INFO - 2018-02-11 00:52:35 --> Language Class Initialized
INFO - 2018-02-11 00:52:35 --> Loader Class Initialized
INFO - 2018-02-11 00:52:35 --> Helper loaded: url_helper
INFO - 2018-02-11 00:52:35 --> Helper loaded: form_helper
INFO - 2018-02-11 00:52:35 --> Database Driver Class Initialized
DEBUG - 2018-02-11 00:52:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 00:52:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 00:52:35 --> Form Validation Class Initialized
INFO - 2018-02-11 00:52:35 --> Model Class Initialized
INFO - 2018-02-11 00:52:35 --> Controller Class Initialized
INFO - 2018-02-11 00:52:35 --> Model Class Initialized
INFO - 2018-02-11 00:52:35 --> Model Class Initialized
INFO - 2018-02-11 00:52:35 --> Model Class Initialized
INFO - 2018-02-11 00:52:35 --> Model Class Initialized
INFO - 2018-02-11 00:52:35 --> Model Class Initialized
DEBUG - 2018-02-11 00:52:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 00:52:35 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-11 00:52:35 --> Final output sent to browser
DEBUG - 2018-02-11 00:52:35 --> Total execution time: 0.0474
INFO - 2018-02-11 00:52:35 --> Config Class Initialized
INFO - 2018-02-11 00:52:35 --> Hooks Class Initialized
DEBUG - 2018-02-11 00:52:35 --> UTF-8 Support Enabled
INFO - 2018-02-11 00:52:35 --> Utf8 Class Initialized
INFO - 2018-02-11 00:52:35 --> URI Class Initialized
INFO - 2018-02-11 00:52:35 --> Router Class Initialized
INFO - 2018-02-11 00:52:35 --> Output Class Initialized
INFO - 2018-02-11 00:52:35 --> Security Class Initialized
DEBUG - 2018-02-11 00:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 00:52:35 --> Input Class Initialized
INFO - 2018-02-11 00:52:35 --> Language Class Initialized
INFO - 2018-02-11 00:52:35 --> Loader Class Initialized
INFO - 2018-02-11 00:52:35 --> Helper loaded: url_helper
INFO - 2018-02-11 00:52:35 --> Helper loaded: form_helper
INFO - 2018-02-11 00:52:35 --> Database Driver Class Initialized
DEBUG - 2018-02-11 00:52:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 00:52:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 00:52:35 --> Form Validation Class Initialized
INFO - 2018-02-11 00:52:35 --> Model Class Initialized
INFO - 2018-02-11 00:52:35 --> Controller Class Initialized
INFO - 2018-02-11 00:52:35 --> Model Class Initialized
INFO - 2018-02-11 00:52:35 --> Model Class Initialized
INFO - 2018-02-11 00:52:35 --> Model Class Initialized
INFO - 2018-02-11 00:52:35 --> Model Class Initialized
INFO - 2018-02-11 00:52:35 --> Model Class Initialized
DEBUG - 2018-02-11 00:52:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 00:52:36 --> Config Class Initialized
INFO - 2018-02-11 00:52:36 --> Hooks Class Initialized
DEBUG - 2018-02-11 00:52:36 --> UTF-8 Support Enabled
INFO - 2018-02-11 00:52:36 --> Utf8 Class Initialized
INFO - 2018-02-11 00:52:36 --> URI Class Initialized
INFO - 2018-02-11 00:52:36 --> Router Class Initialized
INFO - 2018-02-11 00:52:36 --> Output Class Initialized
INFO - 2018-02-11 00:52:36 --> Security Class Initialized
DEBUG - 2018-02-11 00:52:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 00:52:36 --> Input Class Initialized
INFO - 2018-02-11 00:52:36 --> Language Class Initialized
INFO - 2018-02-11 00:52:36 --> Loader Class Initialized
INFO - 2018-02-11 00:52:36 --> Helper loaded: url_helper
INFO - 2018-02-11 00:52:36 --> Helper loaded: form_helper
INFO - 2018-02-11 00:52:36 --> Database Driver Class Initialized
DEBUG - 2018-02-11 00:52:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 00:52:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 00:52:36 --> Form Validation Class Initialized
INFO - 2018-02-11 00:52:36 --> Model Class Initialized
INFO - 2018-02-11 00:52:36 --> Controller Class Initialized
INFO - 2018-02-11 00:52:36 --> Model Class Initialized
INFO - 2018-02-11 00:52:36 --> Model Class Initialized
INFO - 2018-02-11 00:52:36 --> Model Class Initialized
INFO - 2018-02-11 00:52:36 --> Model Class Initialized
INFO - 2018-02-11 00:52:36 --> Model Class Initialized
DEBUG - 2018-02-11 00:52:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 00:52:36 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-11 00:52:36 --> Final output sent to browser
DEBUG - 2018-02-11 00:52:36 --> Total execution time: 0.0586
INFO - 2018-02-11 00:52:36 --> Config Class Initialized
INFO - 2018-02-11 00:52:36 --> Hooks Class Initialized
DEBUG - 2018-02-11 00:52:36 --> UTF-8 Support Enabled
INFO - 2018-02-11 00:52:36 --> Utf8 Class Initialized
INFO - 2018-02-11 00:52:36 --> URI Class Initialized
INFO - 2018-02-11 00:52:36 --> Router Class Initialized
INFO - 2018-02-11 00:52:36 --> Output Class Initialized
INFO - 2018-02-11 00:52:36 --> Security Class Initialized
DEBUG - 2018-02-11 00:52:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 00:52:36 --> Input Class Initialized
INFO - 2018-02-11 00:52:36 --> Language Class Initialized
INFO - 2018-02-11 00:52:36 --> Loader Class Initialized
INFO - 2018-02-11 00:52:36 --> Helper loaded: url_helper
INFO - 2018-02-11 00:52:36 --> Helper loaded: form_helper
INFO - 2018-02-11 00:52:36 --> Database Driver Class Initialized
DEBUG - 2018-02-11 00:52:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 00:52:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 00:52:36 --> Form Validation Class Initialized
INFO - 2018-02-11 00:52:36 --> Model Class Initialized
INFO - 2018-02-11 00:52:36 --> Controller Class Initialized
INFO - 2018-02-11 00:52:36 --> Model Class Initialized
INFO - 2018-02-11 00:52:36 --> Model Class Initialized
INFO - 2018-02-11 00:52:36 --> Model Class Initialized
INFO - 2018-02-11 00:52:36 --> Model Class Initialized
INFO - 2018-02-11 00:52:36 --> Model Class Initialized
DEBUG - 2018-02-11 00:52:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 01:05:51 --> Config Class Initialized
INFO - 2018-02-11 01:05:51 --> Hooks Class Initialized
DEBUG - 2018-02-11 01:05:51 --> UTF-8 Support Enabled
INFO - 2018-02-11 01:05:51 --> Utf8 Class Initialized
INFO - 2018-02-11 01:05:51 --> URI Class Initialized
INFO - 2018-02-11 01:05:51 --> Router Class Initialized
INFO - 2018-02-11 01:05:51 --> Output Class Initialized
INFO - 2018-02-11 01:05:51 --> Security Class Initialized
DEBUG - 2018-02-11 01:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 01:05:51 --> Input Class Initialized
INFO - 2018-02-11 01:05:51 --> Language Class Initialized
INFO - 2018-02-11 01:05:51 --> Loader Class Initialized
INFO - 2018-02-11 01:05:51 --> Helper loaded: url_helper
INFO - 2018-02-11 01:05:51 --> Helper loaded: form_helper
INFO - 2018-02-11 01:05:51 --> Database Driver Class Initialized
DEBUG - 2018-02-11 01:05:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 01:05:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 01:05:51 --> Form Validation Class Initialized
INFO - 2018-02-11 01:05:51 --> Model Class Initialized
INFO - 2018-02-11 01:05:51 --> Controller Class Initialized
INFO - 2018-02-11 01:05:51 --> Model Class Initialized
INFO - 2018-02-11 01:05:51 --> Model Class Initialized
INFO - 2018-02-11 01:05:51 --> Model Class Initialized
INFO - 2018-02-11 01:05:51 --> Model Class Initialized
INFO - 2018-02-11 01:05:51 --> Model Class Initialized
DEBUG - 2018-02-11 01:05:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 01:05:51 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-11 01:05:51 --> Final output sent to browser
DEBUG - 2018-02-11 01:05:51 --> Total execution time: 0.0461
INFO - 2018-02-11 01:05:51 --> Config Class Initialized
INFO - 2018-02-11 01:05:51 --> Hooks Class Initialized
DEBUG - 2018-02-11 01:05:51 --> UTF-8 Support Enabled
INFO - 2018-02-11 01:05:51 --> Utf8 Class Initialized
INFO - 2018-02-11 01:05:51 --> URI Class Initialized
INFO - 2018-02-11 01:05:51 --> Router Class Initialized
INFO - 2018-02-11 01:05:51 --> Output Class Initialized
INFO - 2018-02-11 01:05:51 --> Security Class Initialized
DEBUG - 2018-02-11 01:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 01:05:51 --> Input Class Initialized
INFO - 2018-02-11 01:05:51 --> Language Class Initialized
INFO - 2018-02-11 01:05:51 --> Loader Class Initialized
INFO - 2018-02-11 01:05:51 --> Helper loaded: url_helper
INFO - 2018-02-11 01:05:51 --> Helper loaded: form_helper
INFO - 2018-02-11 01:05:51 --> Database Driver Class Initialized
DEBUG - 2018-02-11 01:05:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 01:05:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 01:05:51 --> Form Validation Class Initialized
INFO - 2018-02-11 01:05:51 --> Model Class Initialized
INFO - 2018-02-11 01:05:51 --> Controller Class Initialized
INFO - 2018-02-11 01:05:51 --> Model Class Initialized
INFO - 2018-02-11 01:05:51 --> Model Class Initialized
INFO - 2018-02-11 01:05:51 --> Model Class Initialized
INFO - 2018-02-11 01:05:51 --> Model Class Initialized
INFO - 2018-02-11 01:05:51 --> Model Class Initialized
DEBUG - 2018-02-11 01:05:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 01:05:52 --> Config Class Initialized
INFO - 2018-02-11 01:05:52 --> Hooks Class Initialized
DEBUG - 2018-02-11 01:05:52 --> UTF-8 Support Enabled
INFO - 2018-02-11 01:05:52 --> Utf8 Class Initialized
INFO - 2018-02-11 01:05:52 --> URI Class Initialized
INFO - 2018-02-11 01:05:52 --> Router Class Initialized
INFO - 2018-02-11 01:05:52 --> Output Class Initialized
INFO - 2018-02-11 01:05:52 --> Security Class Initialized
DEBUG - 2018-02-11 01:05:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 01:05:52 --> Input Class Initialized
INFO - 2018-02-11 01:05:52 --> Language Class Initialized
INFO - 2018-02-11 01:05:52 --> Loader Class Initialized
INFO - 2018-02-11 01:05:52 --> Helper loaded: url_helper
INFO - 2018-02-11 01:05:52 --> Helper loaded: form_helper
INFO - 2018-02-11 01:05:52 --> Database Driver Class Initialized
DEBUG - 2018-02-11 01:05:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 01:05:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 01:05:52 --> Form Validation Class Initialized
INFO - 2018-02-11 01:05:52 --> Model Class Initialized
INFO - 2018-02-11 01:05:52 --> Controller Class Initialized
INFO - 2018-02-11 01:05:52 --> Model Class Initialized
INFO - 2018-02-11 01:05:52 --> Model Class Initialized
INFO - 2018-02-11 01:05:52 --> Model Class Initialized
INFO - 2018-02-11 01:05:52 --> Model Class Initialized
INFO - 2018-02-11 01:05:52 --> Model Class Initialized
DEBUG - 2018-02-11 01:05:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 01:05:52 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-11 01:05:52 --> Final output sent to browser
DEBUG - 2018-02-11 01:05:52 --> Total execution time: 0.0517
INFO - 2018-02-11 01:05:54 --> Config Class Initialized
INFO - 2018-02-11 01:05:54 --> Hooks Class Initialized
DEBUG - 2018-02-11 01:05:54 --> UTF-8 Support Enabled
INFO - 2018-02-11 01:05:54 --> Utf8 Class Initialized
INFO - 2018-02-11 01:05:54 --> URI Class Initialized
INFO - 2018-02-11 01:05:54 --> Router Class Initialized
INFO - 2018-02-11 01:05:54 --> Output Class Initialized
INFO - 2018-02-11 01:05:54 --> Security Class Initialized
DEBUG - 2018-02-11 01:05:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 01:05:54 --> Input Class Initialized
INFO - 2018-02-11 01:05:54 --> Language Class Initialized
INFO - 2018-02-11 01:05:54 --> Loader Class Initialized
INFO - 2018-02-11 01:05:54 --> Helper loaded: url_helper
INFO - 2018-02-11 01:05:54 --> Helper loaded: form_helper
INFO - 2018-02-11 01:05:54 --> Database Driver Class Initialized
DEBUG - 2018-02-11 01:05:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 01:05:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 01:05:54 --> Form Validation Class Initialized
INFO - 2018-02-11 01:05:54 --> Model Class Initialized
INFO - 2018-02-11 01:05:54 --> Controller Class Initialized
INFO - 2018-02-11 01:05:54 --> Model Class Initialized
INFO - 2018-02-11 01:05:54 --> Model Class Initialized
INFO - 2018-02-11 01:05:54 --> Model Class Initialized
INFO - 2018-02-11 01:05:54 --> Model Class Initialized
INFO - 2018-02-11 01:05:54 --> Model Class Initialized
DEBUG - 2018-02-11 01:05:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 01:05:54 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-11 01:05:54 --> Final output sent to browser
DEBUG - 2018-02-11 01:05:54 --> Total execution time: 0.0782
INFO - 2018-02-11 01:05:54 --> Config Class Initialized
INFO - 2018-02-11 01:05:54 --> Hooks Class Initialized
DEBUG - 2018-02-11 01:05:54 --> UTF-8 Support Enabled
INFO - 2018-02-11 01:05:54 --> Utf8 Class Initialized
INFO - 2018-02-11 01:05:54 --> URI Class Initialized
INFO - 2018-02-11 01:05:54 --> Router Class Initialized
INFO - 2018-02-11 01:05:54 --> Output Class Initialized
INFO - 2018-02-11 01:05:54 --> Security Class Initialized
DEBUG - 2018-02-11 01:05:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 01:05:54 --> Input Class Initialized
INFO - 2018-02-11 01:05:54 --> Language Class Initialized
INFO - 2018-02-11 01:05:54 --> Loader Class Initialized
INFO - 2018-02-11 01:05:54 --> Helper loaded: url_helper
INFO - 2018-02-11 01:05:54 --> Helper loaded: form_helper
INFO - 2018-02-11 01:05:54 --> Database Driver Class Initialized
DEBUG - 2018-02-11 01:05:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 01:05:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 01:05:54 --> Form Validation Class Initialized
INFO - 2018-02-11 01:05:54 --> Model Class Initialized
INFO - 2018-02-11 01:05:54 --> Controller Class Initialized
INFO - 2018-02-11 01:05:54 --> Model Class Initialized
INFO - 2018-02-11 01:05:54 --> Model Class Initialized
INFO - 2018-02-11 01:05:54 --> Model Class Initialized
INFO - 2018-02-11 01:05:54 --> Model Class Initialized
INFO - 2018-02-11 01:05:54 --> Model Class Initialized
DEBUG - 2018-02-11 01:05:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 01:05:54 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-11 01:05:54 --> Final output sent to browser
DEBUG - 2018-02-11 01:05:54 --> Total execution time: 0.0776
INFO - 2018-02-11 01:05:55 --> Config Class Initialized
INFO - 2018-02-11 01:05:55 --> Hooks Class Initialized
DEBUG - 2018-02-11 01:05:55 --> UTF-8 Support Enabled
INFO - 2018-02-11 01:05:55 --> Utf8 Class Initialized
INFO - 2018-02-11 01:05:55 --> URI Class Initialized
INFO - 2018-02-11 01:05:55 --> Router Class Initialized
INFO - 2018-02-11 01:05:55 --> Output Class Initialized
INFO - 2018-02-11 01:05:55 --> Security Class Initialized
DEBUG - 2018-02-11 01:05:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 01:05:55 --> Input Class Initialized
INFO - 2018-02-11 01:05:55 --> Language Class Initialized
INFO - 2018-02-11 01:05:55 --> Loader Class Initialized
INFO - 2018-02-11 01:05:55 --> Helper loaded: url_helper
INFO - 2018-02-11 01:05:55 --> Helper loaded: form_helper
INFO - 2018-02-11 01:05:55 --> Database Driver Class Initialized
DEBUG - 2018-02-11 01:05:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 01:05:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 01:05:55 --> Form Validation Class Initialized
INFO - 2018-02-11 01:05:55 --> Model Class Initialized
INFO - 2018-02-11 01:05:55 --> Controller Class Initialized
INFO - 2018-02-11 01:05:55 --> Model Class Initialized
INFO - 2018-02-11 01:05:55 --> Model Class Initialized
INFO - 2018-02-11 01:05:55 --> Model Class Initialized
INFO - 2018-02-11 01:05:55 --> Model Class Initialized
INFO - 2018-02-11 01:05:55 --> Model Class Initialized
DEBUG - 2018-02-11 01:05:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 01:05:55 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-11 01:05:55 --> Final output sent to browser
DEBUG - 2018-02-11 01:05:55 --> Total execution time: 0.0670
INFO - 2018-02-11 01:05:55 --> Config Class Initialized
INFO - 2018-02-11 01:05:55 --> Hooks Class Initialized
DEBUG - 2018-02-11 01:05:55 --> UTF-8 Support Enabled
INFO - 2018-02-11 01:05:55 --> Utf8 Class Initialized
INFO - 2018-02-11 01:05:55 --> URI Class Initialized
INFO - 2018-02-11 01:05:55 --> Router Class Initialized
INFO - 2018-02-11 01:05:55 --> Output Class Initialized
INFO - 2018-02-11 01:05:55 --> Security Class Initialized
DEBUG - 2018-02-11 01:05:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 01:05:55 --> Input Class Initialized
INFO - 2018-02-11 01:05:55 --> Language Class Initialized
INFO - 2018-02-11 01:05:55 --> Loader Class Initialized
INFO - 2018-02-11 01:05:55 --> Helper loaded: url_helper
INFO - 2018-02-11 01:05:55 --> Helper loaded: form_helper
INFO - 2018-02-11 01:05:55 --> Database Driver Class Initialized
DEBUG - 2018-02-11 01:05:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 01:05:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 01:05:55 --> Form Validation Class Initialized
INFO - 2018-02-11 01:05:55 --> Model Class Initialized
INFO - 2018-02-11 01:05:55 --> Controller Class Initialized
INFO - 2018-02-11 01:05:55 --> Model Class Initialized
INFO - 2018-02-11 01:05:55 --> Model Class Initialized
INFO - 2018-02-11 01:05:55 --> Model Class Initialized
INFO - 2018-02-11 01:05:55 --> Model Class Initialized
INFO - 2018-02-11 01:05:55 --> Model Class Initialized
DEBUG - 2018-02-11 01:05:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 01:05:55 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-11 01:05:55 --> Final output sent to browser
DEBUG - 2018-02-11 01:05:55 --> Total execution time: 0.0751
INFO - 2018-02-11 01:06:15 --> Config Class Initialized
INFO - 2018-02-11 01:06:15 --> Hooks Class Initialized
DEBUG - 2018-02-11 01:06:15 --> UTF-8 Support Enabled
INFO - 2018-02-11 01:06:15 --> Utf8 Class Initialized
INFO - 2018-02-11 01:06:15 --> URI Class Initialized
INFO - 2018-02-11 01:06:15 --> Router Class Initialized
INFO - 2018-02-11 01:06:15 --> Output Class Initialized
INFO - 2018-02-11 01:06:15 --> Security Class Initialized
DEBUG - 2018-02-11 01:06:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 01:06:15 --> Input Class Initialized
INFO - 2018-02-11 01:06:15 --> Language Class Initialized
INFO - 2018-02-11 01:06:15 --> Loader Class Initialized
INFO - 2018-02-11 01:06:15 --> Helper loaded: url_helper
INFO - 2018-02-11 01:06:15 --> Helper loaded: form_helper
INFO - 2018-02-11 01:06:15 --> Database Driver Class Initialized
DEBUG - 2018-02-11 01:06:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 01:06:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 01:06:15 --> Form Validation Class Initialized
INFO - 2018-02-11 01:06:15 --> Model Class Initialized
INFO - 2018-02-11 01:06:15 --> Controller Class Initialized
INFO - 2018-02-11 01:06:15 --> Model Class Initialized
INFO - 2018-02-11 01:06:15 --> Model Class Initialized
INFO - 2018-02-11 01:06:15 --> Model Class Initialized
INFO - 2018-02-11 01:06:15 --> Model Class Initialized
INFO - 2018-02-11 01:06:15 --> Model Class Initialized
DEBUG - 2018-02-11 01:06:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 01:06:15 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-11 01:06:15 --> Final output sent to browser
DEBUG - 2018-02-11 01:06:15 --> Total execution time: 0.0721
INFO - 2018-02-11 01:06:27 --> Config Class Initialized
INFO - 2018-02-11 01:06:27 --> Hooks Class Initialized
DEBUG - 2018-02-11 01:06:27 --> UTF-8 Support Enabled
INFO - 2018-02-11 01:06:27 --> Utf8 Class Initialized
INFO - 2018-02-11 01:06:27 --> URI Class Initialized
INFO - 2018-02-11 01:06:27 --> Router Class Initialized
INFO - 2018-02-11 01:06:27 --> Output Class Initialized
INFO - 2018-02-11 01:06:27 --> Security Class Initialized
DEBUG - 2018-02-11 01:06:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 01:06:27 --> Input Class Initialized
INFO - 2018-02-11 01:06:27 --> Language Class Initialized
INFO - 2018-02-11 01:06:27 --> Loader Class Initialized
INFO - 2018-02-11 01:06:27 --> Helper loaded: url_helper
INFO - 2018-02-11 01:06:27 --> Helper loaded: form_helper
INFO - 2018-02-11 01:06:27 --> Database Driver Class Initialized
DEBUG - 2018-02-11 01:06:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 01:06:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 01:06:27 --> Form Validation Class Initialized
INFO - 2018-02-11 01:06:27 --> Model Class Initialized
INFO - 2018-02-11 01:06:27 --> Controller Class Initialized
INFO - 2018-02-11 01:06:27 --> Model Class Initialized
INFO - 2018-02-11 01:06:27 --> Model Class Initialized
INFO - 2018-02-11 01:06:27 --> Model Class Initialized
INFO - 2018-02-11 01:06:27 --> Model Class Initialized
INFO - 2018-02-11 01:06:27 --> Model Class Initialized
DEBUG - 2018-02-11 01:06:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 01:06:27 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-11 01:06:27 --> Final output sent to browser
DEBUG - 2018-02-11 01:06:27 --> Total execution time: 0.0761
INFO - 2018-02-11 01:06:35 --> Config Class Initialized
INFO - 2018-02-11 01:06:35 --> Hooks Class Initialized
DEBUG - 2018-02-11 01:06:35 --> UTF-8 Support Enabled
INFO - 2018-02-11 01:06:35 --> Utf8 Class Initialized
INFO - 2018-02-11 01:06:35 --> URI Class Initialized
INFO - 2018-02-11 01:06:35 --> Router Class Initialized
INFO - 2018-02-11 01:06:35 --> Output Class Initialized
INFO - 2018-02-11 01:06:35 --> Security Class Initialized
DEBUG - 2018-02-11 01:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 01:06:35 --> Input Class Initialized
INFO - 2018-02-11 01:06:35 --> Language Class Initialized
INFO - 2018-02-11 01:06:35 --> Loader Class Initialized
INFO - 2018-02-11 01:06:35 --> Helper loaded: url_helper
INFO - 2018-02-11 01:06:35 --> Helper loaded: form_helper
INFO - 2018-02-11 01:06:35 --> Database Driver Class Initialized
DEBUG - 2018-02-11 01:06:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 01:06:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 01:06:35 --> Form Validation Class Initialized
INFO - 2018-02-11 01:06:35 --> Model Class Initialized
INFO - 2018-02-11 01:06:35 --> Controller Class Initialized
INFO - 2018-02-11 01:06:35 --> Model Class Initialized
INFO - 2018-02-11 01:06:35 --> Model Class Initialized
INFO - 2018-02-11 01:06:35 --> Model Class Initialized
INFO - 2018-02-11 01:06:35 --> Model Class Initialized
INFO - 2018-02-11 01:06:35 --> Model Class Initialized
DEBUG - 2018-02-11 01:06:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 01:06:35 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-11 01:06:35 --> Final output sent to browser
DEBUG - 2018-02-11 01:06:35 --> Total execution time: 0.0620
INFO - 2018-02-11 01:07:07 --> Config Class Initialized
INFO - 2018-02-11 01:07:07 --> Hooks Class Initialized
DEBUG - 2018-02-11 01:07:07 --> UTF-8 Support Enabled
INFO - 2018-02-11 01:07:07 --> Utf8 Class Initialized
INFO - 2018-02-11 01:07:07 --> URI Class Initialized
INFO - 2018-02-11 01:07:07 --> Router Class Initialized
INFO - 2018-02-11 01:07:07 --> Output Class Initialized
INFO - 2018-02-11 01:07:07 --> Security Class Initialized
DEBUG - 2018-02-11 01:07:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 01:07:07 --> Input Class Initialized
INFO - 2018-02-11 01:07:07 --> Language Class Initialized
INFO - 2018-02-11 01:07:07 --> Loader Class Initialized
INFO - 2018-02-11 01:07:07 --> Helper loaded: url_helper
INFO - 2018-02-11 01:07:07 --> Helper loaded: form_helper
INFO - 2018-02-11 01:07:07 --> Database Driver Class Initialized
DEBUG - 2018-02-11 01:07:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 01:07:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 01:07:07 --> Form Validation Class Initialized
INFO - 2018-02-11 01:07:07 --> Model Class Initialized
INFO - 2018-02-11 01:07:07 --> Controller Class Initialized
INFO - 2018-02-11 01:07:07 --> Model Class Initialized
INFO - 2018-02-11 01:07:07 --> Model Class Initialized
INFO - 2018-02-11 01:07:07 --> Model Class Initialized
INFO - 2018-02-11 01:07:07 --> Model Class Initialized
INFO - 2018-02-11 01:07:07 --> Model Class Initialized
DEBUG - 2018-02-11 01:07:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 01:07:07 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-11 01:07:07 --> Final output sent to browser
DEBUG - 2018-02-11 01:07:07 --> Total execution time: 0.0707
INFO - 2018-02-11 01:07:07 --> Config Class Initialized
INFO - 2018-02-11 01:07:07 --> Hooks Class Initialized
DEBUG - 2018-02-11 01:07:07 --> UTF-8 Support Enabled
INFO - 2018-02-11 01:07:07 --> Utf8 Class Initialized
INFO - 2018-02-11 01:07:07 --> URI Class Initialized
INFO - 2018-02-11 01:07:07 --> Router Class Initialized
INFO - 2018-02-11 01:07:07 --> Output Class Initialized
INFO - 2018-02-11 01:07:07 --> Security Class Initialized
DEBUG - 2018-02-11 01:07:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 01:07:07 --> Input Class Initialized
INFO - 2018-02-11 01:07:07 --> Language Class Initialized
ERROR - 2018-02-11 01:07:07 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-02-11 01:07:09 --> Config Class Initialized
INFO - 2018-02-11 01:07:09 --> Hooks Class Initialized
DEBUG - 2018-02-11 01:07:09 --> UTF-8 Support Enabled
INFO - 2018-02-11 01:07:09 --> Utf8 Class Initialized
INFO - 2018-02-11 01:07:09 --> URI Class Initialized
INFO - 2018-02-11 01:07:09 --> Router Class Initialized
INFO - 2018-02-11 01:07:09 --> Output Class Initialized
INFO - 2018-02-11 01:07:09 --> Security Class Initialized
DEBUG - 2018-02-11 01:07:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 01:07:09 --> Input Class Initialized
INFO - 2018-02-11 01:07:09 --> Language Class Initialized
INFO - 2018-02-11 01:07:09 --> Loader Class Initialized
INFO - 2018-02-11 01:07:09 --> Helper loaded: url_helper
INFO - 2018-02-11 01:07:09 --> Helper loaded: form_helper
INFO - 2018-02-11 01:07:09 --> Database Driver Class Initialized
DEBUG - 2018-02-11 01:07:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 01:07:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 01:07:09 --> Form Validation Class Initialized
INFO - 2018-02-11 01:07:09 --> Model Class Initialized
INFO - 2018-02-11 01:07:09 --> Controller Class Initialized
INFO - 2018-02-11 01:07:09 --> Model Class Initialized
INFO - 2018-02-11 01:07:09 --> Model Class Initialized
INFO - 2018-02-11 01:07:09 --> Model Class Initialized
INFO - 2018-02-11 01:07:09 --> Model Class Initialized
INFO - 2018-02-11 01:07:09 --> Model Class Initialized
DEBUG - 2018-02-11 01:07:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 01:07:09 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-11 01:07:09 --> Final output sent to browser
DEBUG - 2018-02-11 01:07:09 --> Total execution time: 0.0445
INFO - 2018-02-11 01:07:09 --> Config Class Initialized
INFO - 2018-02-11 01:07:09 --> Hooks Class Initialized
DEBUG - 2018-02-11 01:07:09 --> UTF-8 Support Enabled
INFO - 2018-02-11 01:07:09 --> Utf8 Class Initialized
INFO - 2018-02-11 01:07:09 --> URI Class Initialized
INFO - 2018-02-11 01:07:09 --> Router Class Initialized
INFO - 2018-02-11 01:07:09 --> Output Class Initialized
INFO - 2018-02-11 01:07:09 --> Security Class Initialized
DEBUG - 2018-02-11 01:07:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 01:07:09 --> Input Class Initialized
INFO - 2018-02-11 01:07:09 --> Language Class Initialized
ERROR - 2018-02-11 01:07:09 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-02-11 01:07:12 --> Config Class Initialized
INFO - 2018-02-11 01:07:12 --> Hooks Class Initialized
DEBUG - 2018-02-11 01:07:12 --> UTF-8 Support Enabled
INFO - 2018-02-11 01:07:12 --> Utf8 Class Initialized
INFO - 2018-02-11 01:07:12 --> URI Class Initialized
INFO - 2018-02-11 01:07:12 --> Router Class Initialized
INFO - 2018-02-11 01:07:12 --> Output Class Initialized
INFO - 2018-02-11 01:07:12 --> Security Class Initialized
DEBUG - 2018-02-11 01:07:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 01:07:12 --> Input Class Initialized
INFO - 2018-02-11 01:07:12 --> Language Class Initialized
ERROR - 2018-02-11 01:07:12 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-11 01:07:12 --> Config Class Initialized
INFO - 2018-02-11 01:07:12 --> Hooks Class Initialized
INFO - 2018-02-11 01:07:12 --> Config Class Initialized
INFO - 2018-02-11 01:07:12 --> Config Class Initialized
INFO - 2018-02-11 01:07:12 --> Hooks Class Initialized
INFO - 2018-02-11 01:07:12 --> Hooks Class Initialized
DEBUG - 2018-02-11 01:07:12 --> UTF-8 Support Enabled
INFO - 2018-02-11 01:07:12 --> Utf8 Class Initialized
INFO - 2018-02-11 01:07:12 --> URI Class Initialized
DEBUG - 2018-02-11 01:07:12 --> UTF-8 Support Enabled
DEBUG - 2018-02-11 01:07:12 --> UTF-8 Support Enabled
INFO - 2018-02-11 01:07:12 --> Utf8 Class Initialized
INFO - 2018-02-11 01:07:12 --> Utf8 Class Initialized
INFO - 2018-02-11 01:07:12 --> Router Class Initialized
INFO - 2018-02-11 01:07:12 --> URI Class Initialized
INFO - 2018-02-11 01:07:12 --> URI Class Initialized
INFO - 2018-02-11 01:07:12 --> Output Class Initialized
INFO - 2018-02-11 01:07:12 --> Router Class Initialized
INFO - 2018-02-11 01:07:12 --> Router Class Initialized
INFO - 2018-02-11 01:07:12 --> Security Class Initialized
INFO - 2018-02-11 01:07:12 --> Output Class Initialized
DEBUG - 2018-02-11 01:07:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 01:07:12 --> Input Class Initialized
INFO - 2018-02-11 01:07:12 --> Output Class Initialized
INFO - 2018-02-11 01:07:12 --> Language Class Initialized
INFO - 2018-02-11 01:07:12 --> Security Class Initialized
INFO - 2018-02-11 01:07:12 --> Security Class Initialized
ERROR - 2018-02-11 01:07:12 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-02-11 01:07:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 01:07:12 --> Input Class Initialized
DEBUG - 2018-02-11 01:07:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 01:07:12 --> Input Class Initialized
INFO - 2018-02-11 01:07:12 --> Language Class Initialized
INFO - 2018-02-11 01:07:12 --> Language Class Initialized
ERROR - 2018-02-11 01:07:12 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-11 01:07:12 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-11 20:46:38 --> Config Class Initialized
INFO - 2018-02-11 20:46:38 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:46:38 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:46:38 --> Utf8 Class Initialized
INFO - 2018-02-11 20:46:38 --> URI Class Initialized
INFO - 2018-02-11 20:46:38 --> Router Class Initialized
INFO - 2018-02-11 20:46:38 --> Output Class Initialized
INFO - 2018-02-11 20:46:38 --> Security Class Initialized
DEBUG - 2018-02-11 20:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:46:38 --> Input Class Initialized
INFO - 2018-02-11 20:46:38 --> Language Class Initialized
INFO - 2018-02-11 20:46:38 --> Loader Class Initialized
INFO - 2018-02-11 20:46:38 --> Helper loaded: url_helper
INFO - 2018-02-11 20:46:38 --> Helper loaded: form_helper
INFO - 2018-02-11 20:46:38 --> Database Driver Class Initialized
DEBUG - 2018-02-11 20:46:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 20:46:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 20:46:38 --> Form Validation Class Initialized
INFO - 2018-02-11 20:46:38 --> Model Class Initialized
INFO - 2018-02-11 20:46:38 --> Controller Class Initialized
INFO - 2018-02-11 20:46:38 --> Model Class Initialized
INFO - 2018-02-11 20:46:38 --> Model Class Initialized
INFO - 2018-02-11 20:46:38 --> Model Class Initialized
INFO - 2018-02-11 20:46:38 --> Model Class Initialized
INFO - 2018-02-11 20:46:38 --> Model Class Initialized
DEBUG - 2018-02-11 20:46:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 20:46:38 --> Config Class Initialized
INFO - 2018-02-11 20:46:38 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:46:38 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:46:38 --> Utf8 Class Initialized
INFO - 2018-02-11 20:46:38 --> URI Class Initialized
INFO - 2018-02-11 20:46:38 --> Router Class Initialized
INFO - 2018-02-11 20:46:38 --> Output Class Initialized
INFO - 2018-02-11 20:46:38 --> Security Class Initialized
DEBUG - 2018-02-11 20:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:46:38 --> Input Class Initialized
INFO - 2018-02-11 20:46:38 --> Language Class Initialized
INFO - 2018-02-11 20:46:38 --> Loader Class Initialized
INFO - 2018-02-11 20:46:38 --> Helper loaded: url_helper
INFO - 2018-02-11 20:46:38 --> Helper loaded: form_helper
INFO - 2018-02-11 20:46:38 --> Database Driver Class Initialized
DEBUG - 2018-02-11 20:46:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 20:46:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 20:46:38 --> Form Validation Class Initialized
INFO - 2018-02-11 20:46:38 --> Model Class Initialized
INFO - 2018-02-11 20:46:38 --> Controller Class Initialized
INFO - 2018-02-11 20:46:38 --> Model Class Initialized
DEBUG - 2018-02-11 20:46:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 20:46:38 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-11 20:46:38 --> Final output sent to browser
DEBUG - 2018-02-11 20:46:38 --> Total execution time: 0.0395
INFO - 2018-02-11 20:46:38 --> Config Class Initialized
INFO - 2018-02-11 20:46:38 --> Hooks Class Initialized
INFO - 2018-02-11 20:46:38 --> Config Class Initialized
INFO - 2018-02-11 20:46:38 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:46:38 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:46:38 --> Utf8 Class Initialized
INFO - 2018-02-11 20:46:38 --> Config Class Initialized
INFO - 2018-02-11 20:46:38 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:46:38 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:46:38 --> URI Class Initialized
INFO - 2018-02-11 20:46:38 --> Config Class Initialized
INFO - 2018-02-11 20:46:38 --> Utf8 Class Initialized
INFO - 2018-02-11 20:46:38 --> Config Class Initialized
INFO - 2018-02-11 20:46:38 --> Hooks Class Initialized
INFO - 2018-02-11 20:46:38 --> Hooks Class Initialized
INFO - 2018-02-11 20:46:38 --> Router Class Initialized
INFO - 2018-02-11 20:46:38 --> URI Class Initialized
DEBUG - 2018-02-11 20:46:38 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:46:38 --> Utf8 Class Initialized
DEBUG - 2018-02-11 20:46:38 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:46:38 --> Utf8 Class Initialized
INFO - 2018-02-11 20:46:38 --> URI Class Initialized
DEBUG - 2018-02-11 20:46:38 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:46:38 --> Output Class Initialized
INFO - 2018-02-11 20:46:38 --> Router Class Initialized
INFO - 2018-02-11 20:46:38 --> Utf8 Class Initialized
INFO - 2018-02-11 20:46:38 --> URI Class Initialized
INFO - 2018-02-11 20:46:38 --> Router Class Initialized
INFO - 2018-02-11 20:46:38 --> URI Class Initialized
INFO - 2018-02-11 20:46:38 --> Config Class Initialized
INFO - 2018-02-11 20:46:38 --> Router Class Initialized
INFO - 2018-02-11 20:46:38 --> Hooks Class Initialized
INFO - 2018-02-11 20:46:38 --> Output Class Initialized
INFO - 2018-02-11 20:46:38 --> Security Class Initialized
INFO - 2018-02-11 20:46:38 --> Output Class Initialized
INFO - 2018-02-11 20:46:38 --> Output Class Initialized
INFO - 2018-02-11 20:46:38 --> Router Class Initialized
INFO - 2018-02-11 20:46:38 --> Security Class Initialized
DEBUG - 2018-02-11 20:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:46:38 --> Security Class Initialized
INFO - 2018-02-11 20:46:38 --> Input Class Initialized
DEBUG - 2018-02-11 20:46:38 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:46:38 --> Utf8 Class Initialized
INFO - 2018-02-11 20:46:38 --> Language Class Initialized
INFO - 2018-02-11 20:46:38 --> Security Class Initialized
DEBUG - 2018-02-11 20:46:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-11 20:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:46:38 --> Output Class Initialized
INFO - 2018-02-11 20:46:38 --> Input Class Initialized
INFO - 2018-02-11 20:46:38 --> Input Class Initialized
INFO - 2018-02-11 20:46:38 --> URI Class Initialized
DEBUG - 2018-02-11 20:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:46:38 --> Language Class Initialized
ERROR - 2018-02-11 20:46:38 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-11 20:46:38 --> Language Class Initialized
INFO - 2018-02-11 20:46:38 --> Input Class Initialized
INFO - 2018-02-11 20:46:38 --> Security Class Initialized
INFO - 2018-02-11 20:46:38 --> Language Class Initialized
INFO - 2018-02-11 20:46:38 --> Router Class Initialized
ERROR - 2018-02-11 20:46:38 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-11 20:46:38 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-02-11 20:46:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-11 20:46:38 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-11 20:46:38 --> Input Class Initialized
INFO - 2018-02-11 20:46:38 --> Output Class Initialized
INFO - 2018-02-11 20:46:38 --> Language Class Initialized
INFO - 2018-02-11 20:46:38 --> Security Class Initialized
ERROR - 2018-02-11 20:46:38 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-02-11 20:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:46:38 --> Input Class Initialized
INFO - 2018-02-11 20:46:38 --> Language Class Initialized
ERROR - 2018-02-11 20:46:38 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-11 20:46:38 --> Config Class Initialized
INFO - 2018-02-11 20:46:38 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:46:38 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:46:38 --> Utf8 Class Initialized
INFO - 2018-02-11 20:46:38 --> URI Class Initialized
INFO - 2018-02-11 20:46:38 --> Router Class Initialized
INFO - 2018-02-11 20:46:38 --> Output Class Initialized
INFO - 2018-02-11 20:46:38 --> Security Class Initialized
DEBUG - 2018-02-11 20:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:46:38 --> Input Class Initialized
INFO - 2018-02-11 20:46:38 --> Language Class Initialized
ERROR - 2018-02-11 20:46:38 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-11 20:46:40 --> Config Class Initialized
INFO - 2018-02-11 20:46:40 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:46:40 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:46:40 --> Utf8 Class Initialized
INFO - 2018-02-11 20:46:40 --> URI Class Initialized
INFO - 2018-02-11 20:46:40 --> Router Class Initialized
INFO - 2018-02-11 20:46:40 --> Output Class Initialized
INFO - 2018-02-11 20:46:40 --> Security Class Initialized
DEBUG - 2018-02-11 20:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:46:40 --> Input Class Initialized
INFO - 2018-02-11 20:46:40 --> Language Class Initialized
INFO - 2018-02-11 20:46:40 --> Loader Class Initialized
INFO - 2018-02-11 20:46:40 --> Helper loaded: url_helper
INFO - 2018-02-11 20:46:40 --> Helper loaded: form_helper
INFO - 2018-02-11 20:46:40 --> Database Driver Class Initialized
DEBUG - 2018-02-11 20:46:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 20:46:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 20:46:40 --> Form Validation Class Initialized
INFO - 2018-02-11 20:46:40 --> Model Class Initialized
INFO - 2018-02-11 20:46:40 --> Controller Class Initialized
INFO - 2018-02-11 20:46:40 --> Model Class Initialized
DEBUG - 2018-02-11 20:46:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 20:46:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-11 20:46:40 --> Config Class Initialized
INFO - 2018-02-11 20:46:40 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:46:40 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:46:40 --> Utf8 Class Initialized
INFO - 2018-02-11 20:46:40 --> URI Class Initialized
DEBUG - 2018-02-11 20:46:40 --> No URI present. Default controller set.
INFO - 2018-02-11 20:46:40 --> Router Class Initialized
INFO - 2018-02-11 20:46:40 --> Output Class Initialized
INFO - 2018-02-11 20:46:40 --> Security Class Initialized
DEBUG - 2018-02-11 20:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:46:40 --> Input Class Initialized
INFO - 2018-02-11 20:46:40 --> Language Class Initialized
INFO - 2018-02-11 20:46:40 --> Loader Class Initialized
INFO - 2018-02-11 20:46:40 --> Helper loaded: url_helper
INFO - 2018-02-11 20:46:40 --> Helper loaded: form_helper
INFO - 2018-02-11 20:46:40 --> Database Driver Class Initialized
DEBUG - 2018-02-11 20:46:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 20:46:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 20:46:40 --> Form Validation Class Initialized
INFO - 2018-02-11 20:46:40 --> Model Class Initialized
INFO - 2018-02-11 20:46:40 --> Controller Class Initialized
INFO - 2018-02-11 20:46:40 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-11 20:46:40 --> Final output sent to browser
DEBUG - 2018-02-11 20:46:40 --> Total execution time: 0.0460
INFO - 2018-02-11 20:46:40 --> Config Class Initialized
INFO - 2018-02-11 20:46:40 --> Config Class Initialized
INFO - 2018-02-11 20:46:40 --> Hooks Class Initialized
INFO - 2018-02-11 20:46:40 --> Hooks Class Initialized
INFO - 2018-02-11 20:46:40 --> Config Class Initialized
INFO - 2018-02-11 20:46:40 --> Hooks Class Initialized
INFO - 2018-02-11 20:46:40 --> Config Class Initialized
INFO - 2018-02-11 20:46:40 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:46:40 --> UTF-8 Support Enabled
DEBUG - 2018-02-11 20:46:40 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:46:40 --> Utf8 Class Initialized
INFO - 2018-02-11 20:46:40 --> Utf8 Class Initialized
DEBUG - 2018-02-11 20:46:40 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:46:40 --> Utf8 Class Initialized
INFO - 2018-02-11 20:46:40 --> URI Class Initialized
INFO - 2018-02-11 20:46:40 --> URI Class Initialized
DEBUG - 2018-02-11 20:46:40 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:46:40 --> URI Class Initialized
INFO - 2018-02-11 20:46:40 --> Utf8 Class Initialized
INFO - 2018-02-11 20:46:40 --> Router Class Initialized
INFO - 2018-02-11 20:46:40 --> URI Class Initialized
INFO - 2018-02-11 20:46:40 --> Router Class Initialized
INFO - 2018-02-11 20:46:40 --> Router Class Initialized
INFO - 2018-02-11 20:46:40 --> Output Class Initialized
INFO - 2018-02-11 20:46:40 --> Router Class Initialized
INFO - 2018-02-11 20:46:40 --> Output Class Initialized
INFO - 2018-02-11 20:46:40 --> Output Class Initialized
INFO - 2018-02-11 20:46:40 --> Security Class Initialized
INFO - 2018-02-11 20:46:40 --> Security Class Initialized
INFO - 2018-02-11 20:46:40 --> Security Class Initialized
INFO - 2018-02-11 20:46:40 --> Output Class Initialized
DEBUG - 2018-02-11 20:46:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-11 20:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:46:40 --> Input Class Initialized
DEBUG - 2018-02-11 20:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:46:40 --> Security Class Initialized
INFO - 2018-02-11 20:46:40 --> Input Class Initialized
INFO - 2018-02-11 20:46:40 --> Input Class Initialized
INFO - 2018-02-11 20:46:40 --> Language Class Initialized
INFO - 2018-02-11 20:46:40 --> Language Class Initialized
INFO - 2018-02-11 20:46:40 --> Language Class Initialized
DEBUG - 2018-02-11 20:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:46:40 --> Input Class Initialized
ERROR - 2018-02-11 20:46:40 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-11 20:46:40 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-11 20:46:40 --> Language Class Initialized
ERROR - 2018-02-11 20:46:40 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-11 20:46:40 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-11 20:46:40 --> Config Class Initialized
INFO - 2018-02-11 20:46:40 --> Config Class Initialized
INFO - 2018-02-11 20:46:40 --> Hooks Class Initialized
INFO - 2018-02-11 20:46:40 --> Hooks Class Initialized
INFO - 2018-02-11 20:46:40 --> Config Class Initialized
INFO - 2018-02-11 20:46:40 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:46:40 --> UTF-8 Support Enabled
DEBUG - 2018-02-11 20:46:40 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:46:40 --> Utf8 Class Initialized
INFO - 2018-02-11 20:46:40 --> Utf8 Class Initialized
DEBUG - 2018-02-11 20:46:40 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:46:40 --> Utf8 Class Initialized
INFO - 2018-02-11 20:46:40 --> URI Class Initialized
INFO - 2018-02-11 20:46:40 --> URI Class Initialized
INFO - 2018-02-11 20:46:40 --> URI Class Initialized
INFO - 2018-02-11 20:46:40 --> Router Class Initialized
INFO - 2018-02-11 20:46:40 --> Router Class Initialized
INFO - 2018-02-11 20:46:40 --> Router Class Initialized
INFO - 2018-02-11 20:46:40 --> Output Class Initialized
INFO - 2018-02-11 20:46:40 --> Output Class Initialized
INFO - 2018-02-11 20:46:40 --> Output Class Initialized
INFO - 2018-02-11 20:46:40 --> Security Class Initialized
INFO - 2018-02-11 20:46:40 --> Security Class Initialized
INFO - 2018-02-11 20:46:40 --> Security Class Initialized
DEBUG - 2018-02-11 20:46:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-11 20:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:46:40 --> Input Class Initialized
DEBUG - 2018-02-11 20:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:46:40 --> Input Class Initialized
INFO - 2018-02-11 20:46:40 --> Input Class Initialized
INFO - 2018-02-11 20:46:40 --> Language Class Initialized
INFO - 2018-02-11 20:46:40 --> Language Class Initialized
INFO - 2018-02-11 20:46:40 --> Language Class Initialized
ERROR - 2018-02-11 20:46:40 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-11 20:46:40 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-11 20:46:40 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-11 20:46:40 --> Config Class Initialized
INFO - 2018-02-11 20:46:40 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:46:40 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:46:40 --> Utf8 Class Initialized
INFO - 2018-02-11 20:46:40 --> URI Class Initialized
INFO - 2018-02-11 20:46:40 --> Router Class Initialized
INFO - 2018-02-11 20:46:40 --> Output Class Initialized
INFO - 2018-02-11 20:46:40 --> Security Class Initialized
DEBUG - 2018-02-11 20:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:46:40 --> Input Class Initialized
INFO - 2018-02-11 20:46:40 --> Language Class Initialized
INFO - 2018-02-11 20:46:40 --> Loader Class Initialized
INFO - 2018-02-11 20:46:40 --> Helper loaded: url_helper
INFO - 2018-02-11 20:46:40 --> Helper loaded: form_helper
INFO - 2018-02-11 20:46:40 --> Database Driver Class Initialized
DEBUG - 2018-02-11 20:46:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 20:46:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 20:46:40 --> Form Validation Class Initialized
INFO - 2018-02-11 20:46:40 --> Model Class Initialized
INFO - 2018-02-11 20:46:40 --> Controller Class Initialized
INFO - 2018-02-11 20:46:40 --> Model Class Initialized
INFO - 2018-02-11 20:46:40 --> Model Class Initialized
INFO - 2018-02-11 20:46:40 --> Model Class Initialized
INFO - 2018-02-11 20:46:40 --> Model Class Initialized
INFO - 2018-02-11 20:46:40 --> Model Class Initialized
DEBUG - 2018-02-11 20:46:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 20:46:48 --> Config Class Initialized
INFO - 2018-02-11 20:46:48 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:46:48 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:46:48 --> Utf8 Class Initialized
INFO - 2018-02-11 20:46:48 --> URI Class Initialized
INFO - 2018-02-11 20:46:48 --> Router Class Initialized
INFO - 2018-02-11 20:46:48 --> Output Class Initialized
INFO - 2018-02-11 20:46:48 --> Security Class Initialized
DEBUG - 2018-02-11 20:46:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:46:48 --> Input Class Initialized
INFO - 2018-02-11 20:46:49 --> Language Class Initialized
INFO - 2018-02-11 20:46:49 --> Loader Class Initialized
INFO - 2018-02-11 20:46:49 --> Helper loaded: url_helper
INFO - 2018-02-11 20:46:49 --> Helper loaded: form_helper
INFO - 2018-02-11 20:46:49 --> Database Driver Class Initialized
DEBUG - 2018-02-11 20:46:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 20:46:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 20:46:49 --> Form Validation Class Initialized
INFO - 2018-02-11 20:46:49 --> Model Class Initialized
INFO - 2018-02-11 20:46:49 --> Controller Class Initialized
INFO - 2018-02-11 20:46:49 --> Model Class Initialized
INFO - 2018-02-11 20:46:49 --> Model Class Initialized
INFO - 2018-02-11 20:46:49 --> Model Class Initialized
INFO - 2018-02-11 20:46:49 --> Model Class Initialized
INFO - 2018-02-11 20:46:49 --> Model Class Initialized
DEBUG - 2018-02-11 20:46:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 20:46:49 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-11 20:46:49 --> Final output sent to browser
DEBUG - 2018-02-11 20:46:49 --> Total execution time: 0.0536
INFO - 2018-02-11 20:46:49 --> Config Class Initialized
INFO - 2018-02-11 20:46:49 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:46:49 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:46:49 --> Utf8 Class Initialized
INFO - 2018-02-11 20:46:49 --> URI Class Initialized
INFO - 2018-02-11 20:46:49 --> Router Class Initialized
INFO - 2018-02-11 20:46:49 --> Output Class Initialized
INFO - 2018-02-11 20:46:49 --> Security Class Initialized
DEBUG - 2018-02-11 20:46:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:46:49 --> Input Class Initialized
INFO - 2018-02-11 20:46:49 --> Language Class Initialized
INFO - 2018-02-11 20:46:49 --> Loader Class Initialized
INFO - 2018-02-11 20:46:49 --> Helper loaded: url_helper
INFO - 2018-02-11 20:46:49 --> Helper loaded: form_helper
INFO - 2018-02-11 20:46:49 --> Database Driver Class Initialized
DEBUG - 2018-02-11 20:46:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 20:46:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 20:46:49 --> Form Validation Class Initialized
INFO - 2018-02-11 20:46:49 --> Model Class Initialized
INFO - 2018-02-11 20:46:49 --> Controller Class Initialized
INFO - 2018-02-11 20:46:49 --> Model Class Initialized
INFO - 2018-02-11 20:46:49 --> Model Class Initialized
INFO - 2018-02-11 20:46:49 --> Model Class Initialized
INFO - 2018-02-11 20:46:49 --> Model Class Initialized
INFO - 2018-02-11 20:46:49 --> Model Class Initialized
DEBUG - 2018-02-11 20:46:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 20:46:51 --> Config Class Initialized
INFO - 2018-02-11 20:46:51 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:46:51 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:46:51 --> Utf8 Class Initialized
INFO - 2018-02-11 20:46:51 --> URI Class Initialized
INFO - 2018-02-11 20:46:51 --> Router Class Initialized
INFO - 2018-02-11 20:46:51 --> Output Class Initialized
INFO - 2018-02-11 20:46:51 --> Security Class Initialized
DEBUG - 2018-02-11 20:46:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:46:51 --> Input Class Initialized
INFO - 2018-02-11 20:46:51 --> Language Class Initialized
INFO - 2018-02-11 20:46:51 --> Loader Class Initialized
INFO - 2018-02-11 20:46:51 --> Helper loaded: url_helper
INFO - 2018-02-11 20:46:51 --> Helper loaded: form_helper
INFO - 2018-02-11 20:46:51 --> Database Driver Class Initialized
DEBUG - 2018-02-11 20:46:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 20:46:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 20:46:51 --> Form Validation Class Initialized
INFO - 2018-02-11 20:46:51 --> Model Class Initialized
INFO - 2018-02-11 20:46:51 --> Controller Class Initialized
INFO - 2018-02-11 20:46:51 --> Model Class Initialized
INFO - 2018-02-11 20:46:51 --> Model Class Initialized
INFO - 2018-02-11 20:46:51 --> Model Class Initialized
INFO - 2018-02-11 20:46:51 --> Model Class Initialized
INFO - 2018-02-11 20:46:51 --> Model Class Initialized
DEBUG - 2018-02-11 20:46:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 20:46:51 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-11 20:46:51 --> Final output sent to browser
DEBUG - 2018-02-11 20:46:51 --> Total execution time: 0.0546
INFO - 2018-02-11 20:46:51 --> Config Class Initialized
INFO - 2018-02-11 20:46:51 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:46:51 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:46:51 --> Utf8 Class Initialized
INFO - 2018-02-11 20:46:51 --> URI Class Initialized
INFO - 2018-02-11 20:46:51 --> Router Class Initialized
INFO - 2018-02-11 20:46:51 --> Output Class Initialized
INFO - 2018-02-11 20:46:51 --> Security Class Initialized
DEBUG - 2018-02-11 20:46:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:46:51 --> Input Class Initialized
INFO - 2018-02-11 20:46:51 --> Language Class Initialized
INFO - 2018-02-11 20:46:51 --> Loader Class Initialized
INFO - 2018-02-11 20:46:51 --> Helper loaded: url_helper
INFO - 2018-02-11 20:46:51 --> Helper loaded: form_helper
INFO - 2018-02-11 20:46:51 --> Database Driver Class Initialized
DEBUG - 2018-02-11 20:46:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 20:46:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 20:46:51 --> Form Validation Class Initialized
INFO - 2018-02-11 20:46:51 --> Model Class Initialized
INFO - 2018-02-11 20:46:51 --> Controller Class Initialized
INFO - 2018-02-11 20:46:51 --> Model Class Initialized
INFO - 2018-02-11 20:46:51 --> Model Class Initialized
INFO - 2018-02-11 20:46:51 --> Model Class Initialized
INFO - 2018-02-11 20:46:51 --> Model Class Initialized
INFO - 2018-02-11 20:46:51 --> Model Class Initialized
DEBUG - 2018-02-11 20:46:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 20:46:52 --> Config Class Initialized
INFO - 2018-02-11 20:46:52 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:46:52 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:46:52 --> Utf8 Class Initialized
INFO - 2018-02-11 20:46:52 --> URI Class Initialized
INFO - 2018-02-11 20:46:52 --> Router Class Initialized
INFO - 2018-02-11 20:46:52 --> Output Class Initialized
INFO - 2018-02-11 20:46:52 --> Security Class Initialized
DEBUG - 2018-02-11 20:46:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:46:52 --> Input Class Initialized
INFO - 2018-02-11 20:46:52 --> Language Class Initialized
INFO - 2018-02-11 20:46:52 --> Loader Class Initialized
INFO - 2018-02-11 20:46:52 --> Helper loaded: url_helper
INFO - 2018-02-11 20:46:52 --> Helper loaded: form_helper
INFO - 2018-02-11 20:46:52 --> Database Driver Class Initialized
DEBUG - 2018-02-11 20:46:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 20:46:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 20:46:52 --> Form Validation Class Initialized
INFO - 2018-02-11 20:46:52 --> Model Class Initialized
INFO - 2018-02-11 20:46:52 --> Controller Class Initialized
INFO - 2018-02-11 20:46:52 --> Model Class Initialized
INFO - 2018-02-11 20:46:52 --> Model Class Initialized
INFO - 2018-02-11 20:46:52 --> Model Class Initialized
INFO - 2018-02-11 20:46:52 --> Model Class Initialized
INFO - 2018-02-11 20:46:52 --> Model Class Initialized
DEBUG - 2018-02-11 20:46:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 20:46:52 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-11 20:46:52 --> Final output sent to browser
DEBUG - 2018-02-11 20:46:52 --> Total execution time: 0.0561
INFO - 2018-02-11 20:46:52 --> Config Class Initialized
INFO - 2018-02-11 20:46:52 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:46:52 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:46:52 --> Utf8 Class Initialized
INFO - 2018-02-11 20:46:52 --> URI Class Initialized
INFO - 2018-02-11 20:46:52 --> Router Class Initialized
INFO - 2018-02-11 20:46:52 --> Output Class Initialized
INFO - 2018-02-11 20:46:52 --> Security Class Initialized
DEBUG - 2018-02-11 20:46:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:46:52 --> Input Class Initialized
INFO - 2018-02-11 20:46:52 --> Language Class Initialized
INFO - 2018-02-11 20:46:52 --> Loader Class Initialized
INFO - 2018-02-11 20:46:52 --> Helper loaded: url_helper
INFO - 2018-02-11 20:46:52 --> Helper loaded: form_helper
INFO - 2018-02-11 20:46:52 --> Database Driver Class Initialized
DEBUG - 2018-02-11 20:46:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 20:46:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 20:46:52 --> Form Validation Class Initialized
INFO - 2018-02-11 20:46:52 --> Model Class Initialized
INFO - 2018-02-11 20:46:52 --> Controller Class Initialized
INFO - 2018-02-11 20:46:52 --> Model Class Initialized
INFO - 2018-02-11 20:46:52 --> Model Class Initialized
INFO - 2018-02-11 20:46:52 --> Model Class Initialized
INFO - 2018-02-11 20:46:52 --> Model Class Initialized
INFO - 2018-02-11 20:46:52 --> Model Class Initialized
DEBUG - 2018-02-11 20:46:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 20:46:55 --> Config Class Initialized
INFO - 2018-02-11 20:46:55 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:46:55 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:46:55 --> Utf8 Class Initialized
INFO - 2018-02-11 20:46:55 --> URI Class Initialized
INFO - 2018-02-11 20:46:55 --> Router Class Initialized
INFO - 2018-02-11 20:46:55 --> Output Class Initialized
INFO - 2018-02-11 20:46:55 --> Security Class Initialized
DEBUG - 2018-02-11 20:46:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:46:55 --> Input Class Initialized
INFO - 2018-02-11 20:46:55 --> Language Class Initialized
INFO - 2018-02-11 20:46:55 --> Loader Class Initialized
INFO - 2018-02-11 20:46:55 --> Helper loaded: url_helper
INFO - 2018-02-11 20:46:55 --> Helper loaded: form_helper
INFO - 2018-02-11 20:46:55 --> Database Driver Class Initialized
DEBUG - 2018-02-11 20:46:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 20:46:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 20:46:55 --> Form Validation Class Initialized
INFO - 2018-02-11 20:46:55 --> Model Class Initialized
INFO - 2018-02-11 20:46:55 --> Controller Class Initialized
INFO - 2018-02-11 20:46:55 --> Model Class Initialized
INFO - 2018-02-11 20:46:55 --> Model Class Initialized
INFO - 2018-02-11 20:46:55 --> Model Class Initialized
INFO - 2018-02-11 20:46:55 --> Model Class Initialized
INFO - 2018-02-11 20:46:55 --> Model Class Initialized
DEBUG - 2018-02-11 20:46:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 20:46:55 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-11 20:46:55 --> Final output sent to browser
DEBUG - 2018-02-11 20:46:55 --> Total execution time: 0.0618
INFO - 2018-02-11 20:46:55 --> Config Class Initialized
INFO - 2018-02-11 20:46:55 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:46:55 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:46:55 --> Utf8 Class Initialized
INFO - 2018-02-11 20:46:55 --> URI Class Initialized
INFO - 2018-02-11 20:46:55 --> Router Class Initialized
INFO - 2018-02-11 20:46:55 --> Output Class Initialized
INFO - 2018-02-11 20:46:55 --> Security Class Initialized
DEBUG - 2018-02-11 20:46:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:46:55 --> Input Class Initialized
INFO - 2018-02-11 20:46:55 --> Language Class Initialized
ERROR - 2018-02-11 20:46:55 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-02-11 20:46:56 --> Config Class Initialized
INFO - 2018-02-11 20:46:56 --> Hooks Class Initialized
INFO - 2018-02-11 20:46:56 --> Config Class Initialized
INFO - 2018-02-11 20:46:56 --> Hooks Class Initialized
INFO - 2018-02-11 20:46:56 --> Config Class Initialized
INFO - 2018-02-11 20:46:56 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:46:56 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:46:56 --> Utf8 Class Initialized
INFO - 2018-02-11 20:46:56 --> URI Class Initialized
DEBUG - 2018-02-11 20:46:56 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:46:56 --> Utf8 Class Initialized
DEBUG - 2018-02-11 20:46:56 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:46:56 --> Utf8 Class Initialized
INFO - 2018-02-11 20:46:56 --> URI Class Initialized
INFO - 2018-02-11 20:46:56 --> Router Class Initialized
INFO - 2018-02-11 20:46:56 --> URI Class Initialized
INFO - 2018-02-11 20:46:56 --> Router Class Initialized
INFO - 2018-02-11 20:46:56 --> Output Class Initialized
INFO - 2018-02-11 20:46:56 --> Router Class Initialized
INFO - 2018-02-11 20:46:56 --> Security Class Initialized
INFO - 2018-02-11 20:46:56 --> Output Class Initialized
INFO - 2018-02-11 20:46:56 --> Output Class Initialized
INFO - 2018-02-11 20:46:56 --> Security Class Initialized
DEBUG - 2018-02-11 20:46:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:46:56 --> Input Class Initialized
INFO - 2018-02-11 20:46:56 --> Security Class Initialized
DEBUG - 2018-02-11 20:46:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:46:56 --> Language Class Initialized
INFO - 2018-02-11 20:46:56 --> Input Class Initialized
INFO - 2018-02-11 20:46:56 --> Language Class Initialized
DEBUG - 2018-02-11 20:46:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:46:56 --> Input Class Initialized
ERROR - 2018-02-11 20:46:56 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-11 20:46:56 --> Language Class Initialized
ERROR - 2018-02-11 20:46:56 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-11 20:46:56 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-11 20:47:31 --> Config Class Initialized
INFO - 2018-02-11 20:47:31 --> Config Class Initialized
INFO - 2018-02-11 20:47:31 --> Hooks Class Initialized
INFO - 2018-02-11 20:47:31 --> Hooks Class Initialized
INFO - 2018-02-11 20:47:31 --> Config Class Initialized
INFO - 2018-02-11 20:47:31 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:47:31 --> UTF-8 Support Enabled
DEBUG - 2018-02-11 20:47:31 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:47:31 --> Utf8 Class Initialized
INFO - 2018-02-11 20:47:31 --> Utf8 Class Initialized
DEBUG - 2018-02-11 20:47:31 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:47:31 --> Utf8 Class Initialized
INFO - 2018-02-11 20:47:31 --> URI Class Initialized
INFO - 2018-02-11 20:47:31 --> URI Class Initialized
INFO - 2018-02-11 20:47:31 --> URI Class Initialized
INFO - 2018-02-11 20:47:31 --> Router Class Initialized
INFO - 2018-02-11 20:47:31 --> Router Class Initialized
INFO - 2018-02-11 20:47:31 --> Router Class Initialized
INFO - 2018-02-11 20:47:31 --> Output Class Initialized
INFO - 2018-02-11 20:47:31 --> Output Class Initialized
INFO - 2018-02-11 20:47:31 --> Security Class Initialized
INFO - 2018-02-11 20:47:31 --> Output Class Initialized
INFO - 2018-02-11 20:47:31 --> Security Class Initialized
DEBUG - 2018-02-11 20:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:47:31 --> Security Class Initialized
INFO - 2018-02-11 20:47:31 --> Input Class Initialized
DEBUG - 2018-02-11 20:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:47:31 --> Input Class Initialized
INFO - 2018-02-11 20:47:31 --> Language Class Initialized
DEBUG - 2018-02-11 20:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:47:31 --> Language Class Initialized
INFO - 2018-02-11 20:47:31 --> Input Class Initialized
ERROR - 2018-02-11 20:47:31 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-11 20:47:31 --> Language Class Initialized
ERROR - 2018-02-11 20:47:31 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-11 20:47:31 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-11 20:48:23 --> Config Class Initialized
INFO - 2018-02-11 20:48:23 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:48:23 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:48:23 --> Utf8 Class Initialized
INFO - 2018-02-11 20:48:23 --> URI Class Initialized
INFO - 2018-02-11 20:48:23 --> Router Class Initialized
INFO - 2018-02-11 20:48:23 --> Output Class Initialized
INFO - 2018-02-11 20:48:23 --> Security Class Initialized
DEBUG - 2018-02-11 20:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:48:23 --> Input Class Initialized
INFO - 2018-02-11 20:48:23 --> Language Class Initialized
INFO - 2018-02-11 20:48:23 --> Loader Class Initialized
INFO - 2018-02-11 20:48:23 --> Helper loaded: url_helper
INFO - 2018-02-11 20:48:23 --> Helper loaded: form_helper
INFO - 2018-02-11 20:48:23 --> Database Driver Class Initialized
DEBUG - 2018-02-11 20:48:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 20:48:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 20:48:23 --> Form Validation Class Initialized
INFO - 2018-02-11 20:48:23 --> Model Class Initialized
INFO - 2018-02-11 20:48:23 --> Controller Class Initialized
INFO - 2018-02-11 20:48:23 --> Model Class Initialized
INFO - 2018-02-11 20:48:23 --> Model Class Initialized
INFO - 2018-02-11 20:48:23 --> Model Class Initialized
INFO - 2018-02-11 20:48:23 --> Model Class Initialized
INFO - 2018-02-11 20:48:23 --> Model Class Initialized
DEBUG - 2018-02-11 20:48:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 20:48:23 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-11 20:48:23 --> Final output sent to browser
DEBUG - 2018-02-11 20:48:23 --> Total execution time: 0.0627
INFO - 2018-02-11 20:48:23 --> Config Class Initialized
INFO - 2018-02-11 20:48:23 --> Hooks Class Initialized
INFO - 2018-02-11 20:48:23 --> Config Class Initialized
INFO - 2018-02-11 20:48:23 --> Config Class Initialized
INFO - 2018-02-11 20:48:23 --> Hooks Class Initialized
INFO - 2018-02-11 20:48:23 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:48:23 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:48:23 --> Utf8 Class Initialized
DEBUG - 2018-02-11 20:48:23 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:48:23 --> Utf8 Class Initialized
DEBUG - 2018-02-11 20:48:23 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:48:23 --> Utf8 Class Initialized
INFO - 2018-02-11 20:48:23 --> URI Class Initialized
INFO - 2018-02-11 20:48:23 --> URI Class Initialized
INFO - 2018-02-11 20:48:23 --> URI Class Initialized
INFO - 2018-02-11 20:48:23 --> Router Class Initialized
INFO - 2018-02-11 20:48:23 --> Router Class Initialized
INFO - 2018-02-11 20:48:23 --> Router Class Initialized
INFO - 2018-02-11 20:48:23 --> Output Class Initialized
INFO - 2018-02-11 20:48:23 --> Output Class Initialized
INFO - 2018-02-11 20:48:23 --> Output Class Initialized
INFO - 2018-02-11 20:48:23 --> Security Class Initialized
INFO - 2018-02-11 20:48:23 --> Security Class Initialized
INFO - 2018-02-11 20:48:23 --> Security Class Initialized
DEBUG - 2018-02-11 20:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:48:23 --> Input Class Initialized
INFO - 2018-02-11 20:48:23 --> Language Class Initialized
DEBUG - 2018-02-11 20:48:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-11 20:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:48:23 --> Input Class Initialized
INFO - 2018-02-11 20:48:23 --> Input Class Initialized
ERROR - 2018-02-11 20:48:23 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-11 20:48:23 --> Language Class Initialized
INFO - 2018-02-11 20:48:23 --> Language Class Initialized
ERROR - 2018-02-11 20:48:23 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-11 20:48:23 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-11 20:48:23 --> Config Class Initialized
INFO - 2018-02-11 20:48:23 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:48:23 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:48:23 --> Utf8 Class Initialized
INFO - 2018-02-11 20:48:23 --> URI Class Initialized
INFO - 2018-02-11 20:48:23 --> Router Class Initialized
INFO - 2018-02-11 20:48:23 --> Output Class Initialized
INFO - 2018-02-11 20:48:23 --> Security Class Initialized
DEBUG - 2018-02-11 20:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:48:23 --> Input Class Initialized
INFO - 2018-02-11 20:48:23 --> Language Class Initialized
ERROR - 2018-02-11 20:48:23 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-11 20:48:23 --> Config Class Initialized
INFO - 2018-02-11 20:48:23 --> Hooks Class Initialized
INFO - 2018-02-11 20:48:23 --> Config Class Initialized
INFO - 2018-02-11 20:48:23 --> Config Class Initialized
INFO - 2018-02-11 20:48:23 --> Hooks Class Initialized
INFO - 2018-02-11 20:48:23 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:48:23 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:48:23 --> Utf8 Class Initialized
INFO - 2018-02-11 20:48:23 --> URI Class Initialized
DEBUG - 2018-02-11 20:48:23 --> UTF-8 Support Enabled
DEBUG - 2018-02-11 20:48:23 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:48:23 --> Utf8 Class Initialized
INFO - 2018-02-11 20:48:23 --> Utf8 Class Initialized
INFO - 2018-02-11 20:48:23 --> URI Class Initialized
INFO - 2018-02-11 20:48:23 --> URI Class Initialized
INFO - 2018-02-11 20:48:23 --> Router Class Initialized
INFO - 2018-02-11 20:48:23 --> Router Class Initialized
INFO - 2018-02-11 20:48:23 --> Router Class Initialized
INFO - 2018-02-11 20:48:23 --> Output Class Initialized
INFO - 2018-02-11 20:48:23 --> Output Class Initialized
INFO - 2018-02-11 20:48:23 --> Output Class Initialized
INFO - 2018-02-11 20:48:23 --> Security Class Initialized
INFO - 2018-02-11 20:48:23 --> Security Class Initialized
INFO - 2018-02-11 20:48:23 --> Security Class Initialized
DEBUG - 2018-02-11 20:48:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-11 20:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:48:23 --> Input Class Initialized
INFO - 2018-02-11 20:48:23 --> Input Class Initialized
INFO - 2018-02-11 20:48:23 --> Language Class Initialized
INFO - 2018-02-11 20:48:23 --> Language Class Initialized
DEBUG - 2018-02-11 20:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:48:23 --> Input Class Initialized
ERROR - 2018-02-11 20:48:23 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-11 20:48:23 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-11 20:48:23 --> Language Class Initialized
ERROR - 2018-02-11 20:48:23 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-11 20:48:23 --> Config Class Initialized
INFO - 2018-02-11 20:48:23 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:48:23 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:48:23 --> Utf8 Class Initialized
INFO - 2018-02-11 20:48:23 --> URI Class Initialized
INFO - 2018-02-11 20:48:23 --> Router Class Initialized
INFO - 2018-02-11 20:48:23 --> Output Class Initialized
INFO - 2018-02-11 20:48:23 --> Security Class Initialized
DEBUG - 2018-02-11 20:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:48:23 --> Input Class Initialized
INFO - 2018-02-11 20:48:23 --> Language Class Initialized
ERROR - 2018-02-11 20:48:23 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-02-11 20:48:57 --> Config Class Initialized
INFO - 2018-02-11 20:48:57 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:48:57 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:48:57 --> Utf8 Class Initialized
INFO - 2018-02-11 20:48:57 --> URI Class Initialized
INFO - 2018-02-11 20:48:57 --> Router Class Initialized
INFO - 2018-02-11 20:48:57 --> Output Class Initialized
INFO - 2018-02-11 20:48:57 --> Security Class Initialized
DEBUG - 2018-02-11 20:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:48:57 --> Input Class Initialized
INFO - 2018-02-11 20:48:57 --> Language Class Initialized
INFO - 2018-02-11 20:48:57 --> Loader Class Initialized
INFO - 2018-02-11 20:48:57 --> Helper loaded: url_helper
INFO - 2018-02-11 20:48:57 --> Helper loaded: form_helper
INFO - 2018-02-11 20:48:57 --> Database Driver Class Initialized
DEBUG - 2018-02-11 20:48:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 20:48:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 20:48:57 --> Form Validation Class Initialized
INFO - 2018-02-11 20:48:57 --> Model Class Initialized
INFO - 2018-02-11 20:48:57 --> Controller Class Initialized
INFO - 2018-02-11 20:48:57 --> Model Class Initialized
INFO - 2018-02-11 20:48:57 --> Model Class Initialized
INFO - 2018-02-11 20:48:57 --> Model Class Initialized
INFO - 2018-02-11 20:48:57 --> Model Class Initialized
INFO - 2018-02-11 20:48:57 --> Model Class Initialized
DEBUG - 2018-02-11 20:48:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 20:48:57 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-11 20:48:57 --> Final output sent to browser
DEBUG - 2018-02-11 20:48:57 --> Total execution time: 0.0615
INFO - 2018-02-11 20:48:57 --> Config Class Initialized
INFO - 2018-02-11 20:48:57 --> Config Class Initialized
INFO - 2018-02-11 20:48:57 --> Hooks Class Initialized
INFO - 2018-02-11 20:48:57 --> Hooks Class Initialized
INFO - 2018-02-11 20:48:57 --> Config Class Initialized
INFO - 2018-02-11 20:48:57 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:48:57 --> UTF-8 Support Enabled
DEBUG - 2018-02-11 20:48:57 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:48:57 --> Utf8 Class Initialized
INFO - 2018-02-11 20:48:57 --> Utf8 Class Initialized
DEBUG - 2018-02-11 20:48:57 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:48:57 --> Utf8 Class Initialized
INFO - 2018-02-11 20:48:57 --> URI Class Initialized
INFO - 2018-02-11 20:48:57 --> URI Class Initialized
INFO - 2018-02-11 20:48:57 --> URI Class Initialized
INFO - 2018-02-11 20:48:57 --> Router Class Initialized
INFO - 2018-02-11 20:48:57 --> Router Class Initialized
INFO - 2018-02-11 20:48:57 --> Router Class Initialized
INFO - 2018-02-11 20:48:57 --> Output Class Initialized
INFO - 2018-02-11 20:48:57 --> Output Class Initialized
INFO - 2018-02-11 20:48:57 --> Output Class Initialized
INFO - 2018-02-11 20:48:57 --> Security Class Initialized
INFO - 2018-02-11 20:48:57 --> Security Class Initialized
INFO - 2018-02-11 20:48:57 --> Security Class Initialized
DEBUG - 2018-02-11 20:48:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-11 20:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:48:57 --> Input Class Initialized
INFO - 2018-02-11 20:48:57 --> Input Class Initialized
INFO - 2018-02-11 20:48:57 --> Language Class Initialized
INFO - 2018-02-11 20:48:57 --> Language Class Initialized
DEBUG - 2018-02-11 20:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:48:57 --> Input Class Initialized
ERROR - 2018-02-11 20:48:57 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-11 20:48:57 --> Language Class Initialized
ERROR - 2018-02-11 20:48:57 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-11 20:48:57 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-11 20:48:57 --> Config Class Initialized
INFO - 2018-02-11 20:48:57 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:48:57 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:48:57 --> Utf8 Class Initialized
INFO - 2018-02-11 20:48:57 --> URI Class Initialized
INFO - 2018-02-11 20:48:57 --> Router Class Initialized
INFO - 2018-02-11 20:48:57 --> Output Class Initialized
INFO - 2018-02-11 20:48:57 --> Security Class Initialized
DEBUG - 2018-02-11 20:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:48:57 --> Input Class Initialized
INFO - 2018-02-11 20:48:57 --> Language Class Initialized
ERROR - 2018-02-11 20:48:57 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-11 20:48:57 --> Config Class Initialized
INFO - 2018-02-11 20:48:57 --> Hooks Class Initialized
INFO - 2018-02-11 20:48:57 --> Config Class Initialized
INFO - 2018-02-11 20:48:57 --> Config Class Initialized
INFO - 2018-02-11 20:48:57 --> Hooks Class Initialized
INFO - 2018-02-11 20:48:57 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:48:57 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:48:57 --> Utf8 Class Initialized
INFO - 2018-02-11 20:48:57 --> URI Class Initialized
DEBUG - 2018-02-11 20:48:57 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:48:57 --> Utf8 Class Initialized
DEBUG - 2018-02-11 20:48:57 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:48:57 --> Utf8 Class Initialized
INFO - 2018-02-11 20:48:57 --> Router Class Initialized
INFO - 2018-02-11 20:48:57 --> URI Class Initialized
INFO - 2018-02-11 20:48:57 --> URI Class Initialized
INFO - 2018-02-11 20:48:57 --> Output Class Initialized
INFO - 2018-02-11 20:48:57 --> Router Class Initialized
INFO - 2018-02-11 20:48:57 --> Router Class Initialized
INFO - 2018-02-11 20:48:57 --> Security Class Initialized
INFO - 2018-02-11 20:48:57 --> Output Class Initialized
INFO - 2018-02-11 20:48:57 --> Output Class Initialized
DEBUG - 2018-02-11 20:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:48:57 --> Input Class Initialized
INFO - 2018-02-11 20:48:57 --> Security Class Initialized
INFO - 2018-02-11 20:48:57 --> Language Class Initialized
INFO - 2018-02-11 20:48:57 --> Security Class Initialized
ERROR - 2018-02-11 20:48:57 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-02-11 20:48:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-11 20:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:48:57 --> Input Class Initialized
INFO - 2018-02-11 20:48:57 --> Input Class Initialized
INFO - 2018-02-11 20:48:57 --> Language Class Initialized
INFO - 2018-02-11 20:48:57 --> Language Class Initialized
ERROR - 2018-02-11 20:48:57 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-11 20:48:57 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-11 20:48:57 --> Config Class Initialized
INFO - 2018-02-11 20:48:57 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:48:57 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:48:57 --> Utf8 Class Initialized
INFO - 2018-02-11 20:48:57 --> URI Class Initialized
INFO - 2018-02-11 20:48:57 --> Router Class Initialized
INFO - 2018-02-11 20:48:57 --> Output Class Initialized
INFO - 2018-02-11 20:48:57 --> Security Class Initialized
DEBUG - 2018-02-11 20:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:48:57 --> Input Class Initialized
INFO - 2018-02-11 20:48:57 --> Language Class Initialized
INFO - 2018-02-11 20:48:57 --> Loader Class Initialized
INFO - 2018-02-11 20:48:57 --> Helper loaded: url_helper
INFO - 2018-02-11 20:48:57 --> Helper loaded: form_helper
INFO - 2018-02-11 20:48:57 --> Database Driver Class Initialized
DEBUG - 2018-02-11 20:48:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 20:48:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 20:48:57 --> Form Validation Class Initialized
INFO - 2018-02-11 20:48:57 --> Model Class Initialized
INFO - 2018-02-11 20:48:57 --> Controller Class Initialized
INFO - 2018-02-11 20:48:57 --> Model Class Initialized
INFO - 2018-02-11 20:48:57 --> Model Class Initialized
INFO - 2018-02-11 20:48:57 --> Model Class Initialized
INFO - 2018-02-11 20:48:57 --> Model Class Initialized
INFO - 2018-02-11 20:48:57 --> Model Class Initialized
DEBUG - 2018-02-11 20:48:57 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-11 20:48:57 --> Severity: Notice --> Undefined property: Proyecto::$t_cliente D:\xampp\htdocs\instateccr\controlcostos\instatec_sys\core\Model.php 77
ERROR - 2018-02-11 20:48:57 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'WHERE `estado_cliente` = 1
AND `estado_row` = 1' at line 2 - Invalid query: SELECT *
WHERE `estado_cliente` = 1
AND `estado_row` = 1
INFO - 2018-02-11 20:48:57 --> Language file loaded: language/english/db_lang.php
INFO - 2018-02-11 20:49:03 --> Config Class Initialized
INFO - 2018-02-11 20:49:03 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:49:03 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:49:03 --> Utf8 Class Initialized
INFO - 2018-02-11 20:49:03 --> URI Class Initialized
INFO - 2018-02-11 20:49:03 --> Router Class Initialized
INFO - 2018-02-11 20:49:03 --> Output Class Initialized
INFO - 2018-02-11 20:49:03 --> Security Class Initialized
DEBUG - 2018-02-11 20:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:49:03 --> Input Class Initialized
INFO - 2018-02-11 20:49:03 --> Language Class Initialized
INFO - 2018-02-11 20:49:03 --> Loader Class Initialized
INFO - 2018-02-11 20:49:03 --> Helper loaded: url_helper
INFO - 2018-02-11 20:49:03 --> Helper loaded: form_helper
INFO - 2018-02-11 20:49:03 --> Database Driver Class Initialized
DEBUG - 2018-02-11 20:49:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 20:49:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 20:49:04 --> Form Validation Class Initialized
INFO - 2018-02-11 20:49:04 --> Model Class Initialized
INFO - 2018-02-11 20:49:04 --> Controller Class Initialized
INFO - 2018-02-11 20:49:04 --> Model Class Initialized
INFO - 2018-02-11 20:49:04 --> Model Class Initialized
INFO - 2018-02-11 20:49:04 --> Model Class Initialized
INFO - 2018-02-11 20:49:04 --> Model Class Initialized
INFO - 2018-02-11 20:49:04 --> Model Class Initialized
DEBUG - 2018-02-11 20:49:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 20:49:04 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-11 20:49:04 --> Final output sent to browser
DEBUG - 2018-02-11 20:49:04 --> Total execution time: 0.0709
INFO - 2018-02-11 20:49:04 --> Config Class Initialized
INFO - 2018-02-11 20:49:04 --> Config Class Initialized
INFO - 2018-02-11 20:49:04 --> Hooks Class Initialized
INFO - 2018-02-11 20:49:04 --> Hooks Class Initialized
INFO - 2018-02-11 20:49:04 --> Config Class Initialized
INFO - 2018-02-11 20:49:04 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:49:04 --> UTF-8 Support Enabled
DEBUG - 2018-02-11 20:49:04 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:49:04 --> Utf8 Class Initialized
INFO - 2018-02-11 20:49:04 --> Utf8 Class Initialized
DEBUG - 2018-02-11 20:49:04 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:49:04 --> Utf8 Class Initialized
INFO - 2018-02-11 20:49:04 --> URI Class Initialized
INFO - 2018-02-11 20:49:04 --> URI Class Initialized
INFO - 2018-02-11 20:49:04 --> URI Class Initialized
INFO - 2018-02-11 20:49:04 --> Router Class Initialized
INFO - 2018-02-11 20:49:04 --> Router Class Initialized
INFO - 2018-02-11 20:49:04 --> Router Class Initialized
INFO - 2018-02-11 20:49:04 --> Output Class Initialized
INFO - 2018-02-11 20:49:04 --> Output Class Initialized
INFO - 2018-02-11 20:49:04 --> Output Class Initialized
INFO - 2018-02-11 20:49:04 --> Security Class Initialized
INFO - 2018-02-11 20:49:04 --> Security Class Initialized
INFO - 2018-02-11 20:49:04 --> Security Class Initialized
DEBUG - 2018-02-11 20:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:49:04 --> Input Class Initialized
DEBUG - 2018-02-11 20:49:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-11 20:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:49:04 --> Language Class Initialized
INFO - 2018-02-11 20:49:04 --> Input Class Initialized
INFO - 2018-02-11 20:49:04 --> Input Class Initialized
INFO - 2018-02-11 20:49:04 --> Language Class Initialized
INFO - 2018-02-11 20:49:04 --> Language Class Initialized
ERROR - 2018-02-11 20:49:04 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-11 20:49:04 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-11 20:49:04 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-11 20:49:04 --> Config Class Initialized
INFO - 2018-02-11 20:49:04 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:49:04 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:49:04 --> Utf8 Class Initialized
INFO - 2018-02-11 20:49:04 --> URI Class Initialized
INFO - 2018-02-11 20:49:04 --> Router Class Initialized
INFO - 2018-02-11 20:49:04 --> Output Class Initialized
INFO - 2018-02-11 20:49:04 --> Security Class Initialized
DEBUG - 2018-02-11 20:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:49:04 --> Input Class Initialized
INFO - 2018-02-11 20:49:04 --> Language Class Initialized
ERROR - 2018-02-11 20:49:04 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-11 20:49:04 --> Config Class Initialized
INFO - 2018-02-11 20:49:04 --> Hooks Class Initialized
INFO - 2018-02-11 20:49:04 --> Config Class Initialized
INFO - 2018-02-11 20:49:04 --> Hooks Class Initialized
INFO - 2018-02-11 20:49:04 --> Config Class Initialized
INFO - 2018-02-11 20:49:04 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:49:04 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:49:04 --> Utf8 Class Initialized
DEBUG - 2018-02-11 20:49:04 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:49:04 --> Utf8 Class Initialized
INFO - 2018-02-11 20:49:04 --> URI Class Initialized
DEBUG - 2018-02-11 20:49:04 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:49:04 --> Utf8 Class Initialized
INFO - 2018-02-11 20:49:04 --> URI Class Initialized
INFO - 2018-02-11 20:49:04 --> Router Class Initialized
INFO - 2018-02-11 20:49:04 --> URI Class Initialized
INFO - 2018-02-11 20:49:04 --> Router Class Initialized
INFO - 2018-02-11 20:49:04 --> Output Class Initialized
INFO - 2018-02-11 20:49:04 --> Security Class Initialized
INFO - 2018-02-11 20:49:04 --> Router Class Initialized
INFO - 2018-02-11 20:49:04 --> Output Class Initialized
DEBUG - 2018-02-11 20:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:49:04 --> Input Class Initialized
INFO - 2018-02-11 20:49:04 --> Output Class Initialized
INFO - 2018-02-11 20:49:04 --> Security Class Initialized
INFO - 2018-02-11 20:49:04 --> Language Class Initialized
INFO - 2018-02-11 20:49:04 --> Security Class Initialized
DEBUG - 2018-02-11 20:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:49:04 --> Input Class Initialized
ERROR - 2018-02-11 20:49:04 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-11 20:49:04 --> Language Class Initialized
DEBUG - 2018-02-11 20:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:49:04 --> Input Class Initialized
ERROR - 2018-02-11 20:49:04 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-11 20:49:04 --> Language Class Initialized
ERROR - 2018-02-11 20:49:04 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-11 20:49:04 --> Config Class Initialized
INFO - 2018-02-11 20:49:04 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:49:04 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:49:04 --> Utf8 Class Initialized
INFO - 2018-02-11 20:49:04 --> URI Class Initialized
INFO - 2018-02-11 20:49:04 --> Router Class Initialized
INFO - 2018-02-11 20:49:04 --> Output Class Initialized
INFO - 2018-02-11 20:49:04 --> Security Class Initialized
DEBUG - 2018-02-11 20:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:49:04 --> Input Class Initialized
INFO - 2018-02-11 20:49:04 --> Language Class Initialized
ERROR - 2018-02-11 20:49:04 --> 404 Page Not Found: Proyectos/colaboradores
INFO - 2018-02-11 20:49:10 --> Config Class Initialized
INFO - 2018-02-11 20:49:10 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:49:10 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:49:10 --> Utf8 Class Initialized
INFO - 2018-02-11 20:49:10 --> URI Class Initialized
INFO - 2018-02-11 20:49:10 --> Router Class Initialized
INFO - 2018-02-11 20:49:10 --> Output Class Initialized
INFO - 2018-02-11 20:49:10 --> Security Class Initialized
DEBUG - 2018-02-11 20:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:49:10 --> Input Class Initialized
INFO - 2018-02-11 20:49:10 --> Language Class Initialized
INFO - 2018-02-11 20:49:10 --> Loader Class Initialized
INFO - 2018-02-11 20:49:10 --> Helper loaded: url_helper
INFO - 2018-02-11 20:49:10 --> Helper loaded: form_helper
INFO - 2018-02-11 20:49:10 --> Database Driver Class Initialized
DEBUG - 2018-02-11 20:49:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 20:49:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 20:49:10 --> Form Validation Class Initialized
INFO - 2018-02-11 20:49:10 --> Model Class Initialized
INFO - 2018-02-11 20:49:10 --> Controller Class Initialized
INFO - 2018-02-11 20:49:10 --> Model Class Initialized
INFO - 2018-02-11 20:49:10 --> Model Class Initialized
INFO - 2018-02-11 20:49:10 --> Model Class Initialized
INFO - 2018-02-11 20:49:10 --> Model Class Initialized
INFO - 2018-02-11 20:49:10 --> Model Class Initialized
DEBUG - 2018-02-11 20:49:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 20:49:10 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-11 20:49:10 --> Final output sent to browser
DEBUG - 2018-02-11 20:49:10 --> Total execution time: 0.0464
INFO - 2018-02-11 20:49:10 --> Config Class Initialized
INFO - 2018-02-11 20:49:10 --> Hooks Class Initialized
INFO - 2018-02-11 20:49:10 --> Config Class Initialized
INFO - 2018-02-11 20:49:10 --> Hooks Class Initialized
INFO - 2018-02-11 20:49:10 --> Config Class Initialized
INFO - 2018-02-11 20:49:10 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:49:10 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:49:10 --> Utf8 Class Initialized
INFO - 2018-02-11 20:49:10 --> Config Class Initialized
INFO - 2018-02-11 20:49:10 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:49:10 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:49:10 --> Utf8 Class Initialized
INFO - 2018-02-11 20:49:10 --> URI Class Initialized
DEBUG - 2018-02-11 20:49:10 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:49:10 --> Utf8 Class Initialized
INFO - 2018-02-11 20:49:10 --> URI Class Initialized
INFO - 2018-02-11 20:49:10 --> URI Class Initialized
INFO - 2018-02-11 20:49:10 --> Router Class Initialized
DEBUG - 2018-02-11 20:49:10 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:49:10 --> Utf8 Class Initialized
INFO - 2018-02-11 20:49:10 --> Router Class Initialized
INFO - 2018-02-11 20:49:10 --> Router Class Initialized
INFO - 2018-02-11 20:49:10 --> URI Class Initialized
INFO - 2018-02-11 20:49:10 --> Output Class Initialized
INFO - 2018-02-11 20:49:10 --> Output Class Initialized
INFO - 2018-02-11 20:49:10 --> Output Class Initialized
INFO - 2018-02-11 20:49:10 --> Security Class Initialized
INFO - 2018-02-11 20:49:10 --> Security Class Initialized
INFO - 2018-02-11 20:49:10 --> Router Class Initialized
DEBUG - 2018-02-11 20:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:49:10 --> Security Class Initialized
INFO - 2018-02-11 20:49:10 --> Input Class Initialized
DEBUG - 2018-02-11 20:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:49:10 --> Input Class Initialized
INFO - 2018-02-11 20:49:10 --> Language Class Initialized
INFO - 2018-02-11 20:49:10 --> Output Class Initialized
DEBUG - 2018-02-11 20:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:49:10 --> Language Class Initialized
INFO - 2018-02-11 20:49:10 --> Input Class Initialized
ERROR - 2018-02-11 20:49:10 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-11 20:49:10 --> Language Class Initialized
INFO - 2018-02-11 20:49:10 --> Security Class Initialized
ERROR - 2018-02-11 20:49:10 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-11 20:49:10 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-02-11 20:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:49:10 --> Input Class Initialized
INFO - 2018-02-11 20:49:10 --> Language Class Initialized
ERROR - 2018-02-11 20:49:10 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-11 20:49:10 --> Config Class Initialized
INFO - 2018-02-11 20:49:10 --> Hooks Class Initialized
INFO - 2018-02-11 20:49:10 --> Config Class Initialized
INFO - 2018-02-11 20:49:10 --> Hooks Class Initialized
INFO - 2018-02-11 20:49:10 --> Config Class Initialized
INFO - 2018-02-11 20:49:10 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:49:10 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:49:10 --> Utf8 Class Initialized
DEBUG - 2018-02-11 20:49:10 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:49:10 --> Utf8 Class Initialized
DEBUG - 2018-02-11 20:49:10 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:49:10 --> URI Class Initialized
INFO - 2018-02-11 20:49:10 --> Utf8 Class Initialized
INFO - 2018-02-11 20:49:10 --> URI Class Initialized
INFO - 2018-02-11 20:49:10 --> Router Class Initialized
INFO - 2018-02-11 20:49:10 --> URI Class Initialized
INFO - 2018-02-11 20:49:10 --> Router Class Initialized
INFO - 2018-02-11 20:49:10 --> Output Class Initialized
INFO - 2018-02-11 20:49:10 --> Router Class Initialized
INFO - 2018-02-11 20:49:10 --> Output Class Initialized
INFO - 2018-02-11 20:49:10 --> Security Class Initialized
INFO - 2018-02-11 20:49:10 --> Output Class Initialized
INFO - 2018-02-11 20:49:10 --> Security Class Initialized
DEBUG - 2018-02-11 20:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:49:10 --> Input Class Initialized
DEBUG - 2018-02-11 20:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:49:10 --> Security Class Initialized
INFO - 2018-02-11 20:49:10 --> Language Class Initialized
INFO - 2018-02-11 20:49:10 --> Input Class Initialized
INFO - 2018-02-11 20:49:10 --> Language Class Initialized
ERROR - 2018-02-11 20:49:10 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-02-11 20:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:49:10 --> Input Class Initialized
INFO - 2018-02-11 20:49:10 --> Language Class Initialized
ERROR - 2018-02-11 20:49:10 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-11 20:49:10 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-11 20:49:10 --> Config Class Initialized
INFO - 2018-02-11 20:49:10 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:49:10 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:49:10 --> Utf8 Class Initialized
INFO - 2018-02-11 20:49:10 --> URI Class Initialized
INFO - 2018-02-11 20:49:10 --> Router Class Initialized
INFO - 2018-02-11 20:49:10 --> Output Class Initialized
INFO - 2018-02-11 20:49:10 --> Security Class Initialized
DEBUG - 2018-02-11 20:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:49:10 --> Input Class Initialized
INFO - 2018-02-11 20:49:10 --> Language Class Initialized
ERROR - 2018-02-11 20:49:10 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-02-11 20:49:34 --> Config Class Initialized
INFO - 2018-02-11 20:49:34 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:49:34 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:49:34 --> Utf8 Class Initialized
INFO - 2018-02-11 20:49:34 --> URI Class Initialized
INFO - 2018-02-11 20:49:34 --> Router Class Initialized
INFO - 2018-02-11 20:49:34 --> Output Class Initialized
INFO - 2018-02-11 20:49:34 --> Security Class Initialized
DEBUG - 2018-02-11 20:49:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:49:34 --> Input Class Initialized
INFO - 2018-02-11 20:49:34 --> Language Class Initialized
INFO - 2018-02-11 20:49:34 --> Loader Class Initialized
INFO - 2018-02-11 20:49:34 --> Helper loaded: url_helper
INFO - 2018-02-11 20:49:34 --> Helper loaded: form_helper
INFO - 2018-02-11 20:49:34 --> Database Driver Class Initialized
DEBUG - 2018-02-11 20:49:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 20:49:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 20:49:34 --> Form Validation Class Initialized
INFO - 2018-02-11 20:49:34 --> Model Class Initialized
INFO - 2018-02-11 20:49:34 --> Controller Class Initialized
INFO - 2018-02-11 20:49:34 --> Model Class Initialized
INFO - 2018-02-11 20:49:34 --> Model Class Initialized
INFO - 2018-02-11 20:49:34 --> Model Class Initialized
INFO - 2018-02-11 20:49:34 --> Model Class Initialized
INFO - 2018-02-11 20:49:34 --> Model Class Initialized
DEBUG - 2018-02-11 20:49:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 20:49:34 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-11 20:49:34 --> Final output sent to browser
DEBUG - 2018-02-11 20:49:34 --> Total execution time: 0.0552
INFO - 2018-02-11 20:49:34 --> Config Class Initialized
INFO - 2018-02-11 20:49:34 --> Hooks Class Initialized
INFO - 2018-02-11 20:49:34 --> Config Class Initialized
INFO - 2018-02-11 20:49:34 --> Hooks Class Initialized
INFO - 2018-02-11 20:49:34 --> Config Class Initialized
INFO - 2018-02-11 20:49:34 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:49:34 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:49:34 --> Utf8 Class Initialized
INFO - 2018-02-11 20:49:34 --> URI Class Initialized
DEBUG - 2018-02-11 20:49:34 --> UTF-8 Support Enabled
DEBUG - 2018-02-11 20:49:34 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:49:34 --> Utf8 Class Initialized
INFO - 2018-02-11 20:49:34 --> Utf8 Class Initialized
INFO - 2018-02-11 20:49:34 --> Router Class Initialized
INFO - 2018-02-11 20:49:34 --> URI Class Initialized
INFO - 2018-02-11 20:49:34 --> URI Class Initialized
INFO - 2018-02-11 20:49:34 --> Output Class Initialized
INFO - 2018-02-11 20:49:34 --> Router Class Initialized
INFO - 2018-02-11 20:49:34 --> Router Class Initialized
INFO - 2018-02-11 20:49:34 --> Security Class Initialized
INFO - 2018-02-11 20:49:34 --> Output Class Initialized
INFO - 2018-02-11 20:49:35 --> Output Class Initialized
DEBUG - 2018-02-11 20:49:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:49:35 --> Input Class Initialized
INFO - 2018-02-11 20:49:35 --> Security Class Initialized
INFO - 2018-02-11 20:49:35 --> Security Class Initialized
INFO - 2018-02-11 20:49:35 --> Language Class Initialized
DEBUG - 2018-02-11 20:49:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-11 20:49:35 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-02-11 20:49:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:49:35 --> Input Class Initialized
INFO - 2018-02-11 20:49:35 --> Input Class Initialized
INFO - 2018-02-11 20:49:35 --> Language Class Initialized
INFO - 2018-02-11 20:49:35 --> Language Class Initialized
ERROR - 2018-02-11 20:49:35 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-11 20:49:35 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-11 20:49:35 --> Config Class Initialized
INFO - 2018-02-11 20:49:35 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:49:35 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:49:35 --> Utf8 Class Initialized
INFO - 2018-02-11 20:49:35 --> URI Class Initialized
INFO - 2018-02-11 20:49:35 --> Router Class Initialized
INFO - 2018-02-11 20:49:35 --> Output Class Initialized
INFO - 2018-02-11 20:49:35 --> Security Class Initialized
DEBUG - 2018-02-11 20:49:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:49:35 --> Input Class Initialized
INFO - 2018-02-11 20:49:35 --> Language Class Initialized
ERROR - 2018-02-11 20:49:35 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-11 20:49:35 --> Config Class Initialized
INFO - 2018-02-11 20:49:35 --> Hooks Class Initialized
INFO - 2018-02-11 20:49:35 --> Config Class Initialized
INFO - 2018-02-11 20:49:35 --> Hooks Class Initialized
INFO - 2018-02-11 20:49:35 --> Config Class Initialized
INFO - 2018-02-11 20:49:35 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:49:35 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:49:35 --> Utf8 Class Initialized
DEBUG - 2018-02-11 20:49:35 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:49:35 --> URI Class Initialized
DEBUG - 2018-02-11 20:49:35 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:49:35 --> Utf8 Class Initialized
INFO - 2018-02-11 20:49:35 --> Utf8 Class Initialized
INFO - 2018-02-11 20:49:35 --> URI Class Initialized
INFO - 2018-02-11 20:49:35 --> Router Class Initialized
INFO - 2018-02-11 20:49:35 --> URI Class Initialized
INFO - 2018-02-11 20:49:35 --> Router Class Initialized
INFO - 2018-02-11 20:49:35 --> Router Class Initialized
INFO - 2018-02-11 20:49:35 --> Output Class Initialized
INFO - 2018-02-11 20:49:35 --> Output Class Initialized
INFO - 2018-02-11 20:49:35 --> Security Class Initialized
INFO - 2018-02-11 20:49:35 --> Output Class Initialized
INFO - 2018-02-11 20:49:35 --> Security Class Initialized
DEBUG - 2018-02-11 20:49:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:49:35 --> Security Class Initialized
INFO - 2018-02-11 20:49:35 --> Input Class Initialized
DEBUG - 2018-02-11 20:49:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:49:35 --> Language Class Initialized
INFO - 2018-02-11 20:49:35 --> Input Class Initialized
DEBUG - 2018-02-11 20:49:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:49:35 --> Input Class Initialized
INFO - 2018-02-11 20:49:35 --> Language Class Initialized
ERROR - 2018-02-11 20:49:35 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-11 20:49:35 --> Language Class Initialized
ERROR - 2018-02-11 20:49:35 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-11 20:49:35 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-11 20:49:35 --> Config Class Initialized
INFO - 2018-02-11 20:49:35 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:49:35 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:49:35 --> Utf8 Class Initialized
INFO - 2018-02-11 20:49:35 --> URI Class Initialized
INFO - 2018-02-11 20:49:35 --> Router Class Initialized
INFO - 2018-02-11 20:49:35 --> Output Class Initialized
INFO - 2018-02-11 20:49:35 --> Security Class Initialized
DEBUG - 2018-02-11 20:49:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:49:35 --> Input Class Initialized
INFO - 2018-02-11 20:49:35 --> Language Class Initialized
INFO - 2018-02-11 20:49:35 --> Loader Class Initialized
INFO - 2018-02-11 20:49:35 --> Helper loaded: url_helper
INFO - 2018-02-11 20:49:35 --> Helper loaded: form_helper
INFO - 2018-02-11 20:49:35 --> Database Driver Class Initialized
DEBUG - 2018-02-11 20:49:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 20:49:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 20:49:35 --> Form Validation Class Initialized
INFO - 2018-02-11 20:49:35 --> Model Class Initialized
INFO - 2018-02-11 20:49:35 --> Controller Class Initialized
INFO - 2018-02-11 20:49:35 --> Model Class Initialized
INFO - 2018-02-11 20:49:35 --> Model Class Initialized
INFO - 2018-02-11 20:49:35 --> Model Class Initialized
INFO - 2018-02-11 20:49:35 --> Model Class Initialized
INFO - 2018-02-11 20:49:35 --> Model Class Initialized
DEBUG - 2018-02-11 20:49:35 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-11 20:49:35 --> Severity: Notice --> Undefined property: Proyecto::$t_cliente D:\xampp\htdocs\instateccr\controlcostos\instatec_sys\core\Model.php 77
ERROR - 2018-02-11 20:49:35 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'WHERE `estado_cliente` = 1
AND `estado_row` = 1' at line 2 - Invalid query: SELECT *
WHERE `estado_cliente` = 1
AND `estado_row` = 1
INFO - 2018-02-11 20:49:35 --> Language file loaded: language/english/db_lang.php
INFO - 2018-02-11 20:50:04 --> Config Class Initialized
INFO - 2018-02-11 20:50:04 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:50:04 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:50:04 --> Utf8 Class Initialized
INFO - 2018-02-11 20:50:04 --> URI Class Initialized
INFO - 2018-02-11 20:50:04 --> Router Class Initialized
INFO - 2018-02-11 20:50:04 --> Output Class Initialized
INFO - 2018-02-11 20:50:04 --> Security Class Initialized
DEBUG - 2018-02-11 20:50:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:50:04 --> Input Class Initialized
INFO - 2018-02-11 20:50:04 --> Language Class Initialized
INFO - 2018-02-11 20:50:04 --> Loader Class Initialized
INFO - 2018-02-11 20:50:04 --> Helper loaded: url_helper
INFO - 2018-02-11 20:50:04 --> Helper loaded: form_helper
INFO - 2018-02-11 20:50:04 --> Database Driver Class Initialized
DEBUG - 2018-02-11 20:50:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 20:50:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 20:50:04 --> Form Validation Class Initialized
INFO - 2018-02-11 20:50:04 --> Model Class Initialized
INFO - 2018-02-11 20:50:04 --> Controller Class Initialized
INFO - 2018-02-11 20:50:04 --> Model Class Initialized
INFO - 2018-02-11 20:50:04 --> Model Class Initialized
INFO - 2018-02-11 20:50:04 --> Model Class Initialized
INFO - 2018-02-11 20:50:04 --> Model Class Initialized
INFO - 2018-02-11 20:50:04 --> Model Class Initialized
DEBUG - 2018-02-11 20:50:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 20:50:04 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-11 20:50:04 --> Final output sent to browser
DEBUG - 2018-02-11 20:50:04 --> Total execution time: 0.0638
INFO - 2018-02-11 20:50:04 --> Config Class Initialized
INFO - 2018-02-11 20:50:04 --> Config Class Initialized
INFO - 2018-02-11 20:50:04 --> Hooks Class Initialized
INFO - 2018-02-11 20:50:04 --> Config Class Initialized
INFO - 2018-02-11 20:50:04 --> Hooks Class Initialized
INFO - 2018-02-11 20:50:04 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:50:04 --> UTF-8 Support Enabled
DEBUG - 2018-02-11 20:50:04 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:50:04 --> Utf8 Class Initialized
DEBUG - 2018-02-11 20:50:04 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:50:04 --> Utf8 Class Initialized
INFO - 2018-02-11 20:50:04 --> Utf8 Class Initialized
INFO - 2018-02-11 20:50:04 --> URI Class Initialized
INFO - 2018-02-11 20:50:04 --> URI Class Initialized
INFO - 2018-02-11 20:50:04 --> URI Class Initialized
INFO - 2018-02-11 20:50:04 --> Router Class Initialized
INFO - 2018-02-11 20:50:04 --> Router Class Initialized
INFO - 2018-02-11 20:50:04 --> Router Class Initialized
INFO - 2018-02-11 20:50:04 --> Output Class Initialized
INFO - 2018-02-11 20:50:04 --> Output Class Initialized
INFO - 2018-02-11 20:50:04 --> Output Class Initialized
INFO - 2018-02-11 20:50:04 --> Security Class Initialized
INFO - 2018-02-11 20:50:04 --> Security Class Initialized
INFO - 2018-02-11 20:50:04 --> Security Class Initialized
DEBUG - 2018-02-11 20:50:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:50:04 --> Input Class Initialized
DEBUG - 2018-02-11 20:50:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-11 20:50:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:50:04 --> Input Class Initialized
INFO - 2018-02-11 20:50:04 --> Language Class Initialized
INFO - 2018-02-11 20:50:04 --> Input Class Initialized
INFO - 2018-02-11 20:50:04 --> Language Class Initialized
INFO - 2018-02-11 20:50:04 --> Language Class Initialized
ERROR - 2018-02-11 20:50:04 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-11 20:50:04 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-11 20:50:04 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-11 20:50:04 --> Config Class Initialized
INFO - 2018-02-11 20:50:04 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:50:04 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:50:04 --> Utf8 Class Initialized
INFO - 2018-02-11 20:50:04 --> URI Class Initialized
INFO - 2018-02-11 20:50:04 --> Router Class Initialized
INFO - 2018-02-11 20:50:04 --> Output Class Initialized
INFO - 2018-02-11 20:50:04 --> Security Class Initialized
DEBUG - 2018-02-11 20:50:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:50:04 --> Input Class Initialized
INFO - 2018-02-11 20:50:04 --> Language Class Initialized
ERROR - 2018-02-11 20:50:04 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-11 20:50:04 --> Config Class Initialized
INFO - 2018-02-11 20:50:04 --> Hooks Class Initialized
INFO - 2018-02-11 20:50:04 --> Config Class Initialized
INFO - 2018-02-11 20:50:04 --> Hooks Class Initialized
INFO - 2018-02-11 20:50:04 --> Config Class Initialized
INFO - 2018-02-11 20:50:04 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:50:04 --> UTF-8 Support Enabled
DEBUG - 2018-02-11 20:50:04 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:50:04 --> Utf8 Class Initialized
INFO - 2018-02-11 20:50:04 --> Utf8 Class Initialized
DEBUG - 2018-02-11 20:50:04 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:50:04 --> Utf8 Class Initialized
INFO - 2018-02-11 20:50:04 --> URI Class Initialized
INFO - 2018-02-11 20:50:04 --> URI Class Initialized
INFO - 2018-02-11 20:50:04 --> URI Class Initialized
INFO - 2018-02-11 20:50:04 --> Router Class Initialized
INFO - 2018-02-11 20:50:04 --> Router Class Initialized
INFO - 2018-02-11 20:50:04 --> Router Class Initialized
INFO - 2018-02-11 20:50:04 --> Output Class Initialized
INFO - 2018-02-11 20:50:04 --> Output Class Initialized
INFO - 2018-02-11 20:50:04 --> Output Class Initialized
INFO - 2018-02-11 20:50:04 --> Security Class Initialized
INFO - 2018-02-11 20:50:04 --> Security Class Initialized
INFO - 2018-02-11 20:50:04 --> Security Class Initialized
DEBUG - 2018-02-11 20:50:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-11 20:50:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:50:04 --> Input Class Initialized
INFO - 2018-02-11 20:50:04 --> Input Class Initialized
DEBUG - 2018-02-11 20:50:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:50:04 --> Language Class Initialized
INFO - 2018-02-11 20:50:04 --> Input Class Initialized
INFO - 2018-02-11 20:50:04 --> Language Class Initialized
INFO - 2018-02-11 20:50:04 --> Language Class Initialized
ERROR - 2018-02-11 20:50:04 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-11 20:50:04 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-11 20:50:04 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-11 20:50:04 --> Config Class Initialized
INFO - 2018-02-11 20:50:04 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:50:04 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:50:04 --> Utf8 Class Initialized
INFO - 2018-02-11 20:50:04 --> URI Class Initialized
INFO - 2018-02-11 20:50:04 --> Router Class Initialized
INFO - 2018-02-11 20:50:04 --> Output Class Initialized
INFO - 2018-02-11 20:50:04 --> Security Class Initialized
DEBUG - 2018-02-11 20:50:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:50:04 --> Input Class Initialized
INFO - 2018-02-11 20:50:04 --> Language Class Initialized
INFO - 2018-02-11 20:50:04 --> Loader Class Initialized
INFO - 2018-02-11 20:50:04 --> Helper loaded: url_helper
INFO - 2018-02-11 20:50:04 --> Helper loaded: form_helper
INFO - 2018-02-11 20:50:04 --> Database Driver Class Initialized
DEBUG - 2018-02-11 20:50:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 20:50:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 20:50:04 --> Form Validation Class Initialized
INFO - 2018-02-11 20:50:04 --> Model Class Initialized
INFO - 2018-02-11 20:50:04 --> Controller Class Initialized
INFO - 2018-02-11 20:50:04 --> Model Class Initialized
INFO - 2018-02-11 20:50:04 --> Model Class Initialized
INFO - 2018-02-11 20:50:04 --> Model Class Initialized
INFO - 2018-02-11 20:50:04 --> Model Class Initialized
INFO - 2018-02-11 20:50:04 --> Model Class Initialized
DEBUG - 2018-02-11 20:50:04 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-11 20:50:04 --> Severity: Notice --> Undefined property: Proyecto::$t_cliente D:\xampp\htdocs\instateccr\controlcostos\instatec_sys\core\Model.php 77
ERROR - 2018-02-11 20:50:04 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'WHERE `estado_cliente` = 1
AND `estado_row` = 1' at line 2 - Invalid query: SELECT *
WHERE `estado_cliente` = 1
AND `estado_row` = 1
INFO - 2018-02-11 20:50:04 --> Language file loaded: language/english/db_lang.php
INFO - 2018-02-11 20:50:27 --> Config Class Initialized
INFO - 2018-02-11 20:50:27 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:50:27 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:50:27 --> Utf8 Class Initialized
INFO - 2018-02-11 20:50:27 --> URI Class Initialized
INFO - 2018-02-11 20:50:27 --> Router Class Initialized
INFO - 2018-02-11 20:50:27 --> Output Class Initialized
INFO - 2018-02-11 20:50:27 --> Security Class Initialized
DEBUG - 2018-02-11 20:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:50:27 --> Input Class Initialized
INFO - 2018-02-11 20:50:27 --> Language Class Initialized
INFO - 2018-02-11 20:50:27 --> Loader Class Initialized
INFO - 2018-02-11 20:50:27 --> Helper loaded: url_helper
INFO - 2018-02-11 20:50:27 --> Helper loaded: form_helper
INFO - 2018-02-11 20:50:27 --> Database Driver Class Initialized
DEBUG - 2018-02-11 20:50:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 20:50:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 20:50:27 --> Form Validation Class Initialized
INFO - 2018-02-11 20:50:27 --> Model Class Initialized
INFO - 2018-02-11 20:50:27 --> Controller Class Initialized
INFO - 2018-02-11 20:50:27 --> Model Class Initialized
INFO - 2018-02-11 20:50:27 --> Model Class Initialized
INFO - 2018-02-11 20:50:27 --> Model Class Initialized
INFO - 2018-02-11 20:50:27 --> Model Class Initialized
INFO - 2018-02-11 20:50:27 --> Model Class Initialized
DEBUG - 2018-02-11 20:50:27 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-11 20:50:27 --> Severity: Notice --> Undefined property: Proyecto::$t_cliente D:\xampp\htdocs\instateccr\controlcostos\instatec_sys\core\Model.php 77
ERROR - 2018-02-11 20:50:27 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'WHERE `estado_cliente` = 1
AND `estado_row` = 1' at line 2 - Invalid query: SELECT *
WHERE `estado_cliente` = 1
AND `estado_row` = 1
INFO - 2018-02-11 20:50:27 --> Language file loaded: language/english/db_lang.php
INFO - 2018-02-11 20:51:32 --> Config Class Initialized
INFO - 2018-02-11 20:51:32 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:51:32 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:51:32 --> Utf8 Class Initialized
INFO - 2018-02-11 20:51:32 --> URI Class Initialized
INFO - 2018-02-11 20:51:32 --> Router Class Initialized
INFO - 2018-02-11 20:51:32 --> Output Class Initialized
INFO - 2018-02-11 20:51:32 --> Security Class Initialized
DEBUG - 2018-02-11 20:51:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:51:32 --> Input Class Initialized
INFO - 2018-02-11 20:51:32 --> Language Class Initialized
INFO - 2018-02-11 20:51:32 --> Loader Class Initialized
INFO - 2018-02-11 20:51:32 --> Helper loaded: url_helper
INFO - 2018-02-11 20:51:32 --> Helper loaded: form_helper
INFO - 2018-02-11 20:51:32 --> Database Driver Class Initialized
DEBUG - 2018-02-11 20:51:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 20:51:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 20:51:32 --> Form Validation Class Initialized
INFO - 2018-02-11 20:51:32 --> Model Class Initialized
INFO - 2018-02-11 20:51:32 --> Controller Class Initialized
INFO - 2018-02-11 20:51:32 --> Model Class Initialized
INFO - 2018-02-11 20:51:32 --> Model Class Initialized
INFO - 2018-02-11 20:51:32 --> Model Class Initialized
INFO - 2018-02-11 20:51:32 --> Model Class Initialized
INFO - 2018-02-11 20:51:32 --> Model Class Initialized
DEBUG - 2018-02-11 20:51:32 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-11 20:51:32 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\instateccr\controlcostos\instatec_app\controllers\Proyecto.php 629
INFO - 2018-02-11 20:52:40 --> Config Class Initialized
INFO - 2018-02-11 20:52:40 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:52:40 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:52:40 --> Utf8 Class Initialized
INFO - 2018-02-11 20:52:40 --> URI Class Initialized
INFO - 2018-02-11 20:52:40 --> Router Class Initialized
INFO - 2018-02-11 20:52:40 --> Output Class Initialized
INFO - 2018-02-11 20:52:40 --> Security Class Initialized
DEBUG - 2018-02-11 20:52:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:52:40 --> Input Class Initialized
INFO - 2018-02-11 20:52:40 --> Language Class Initialized
INFO - 2018-02-11 20:52:40 --> Loader Class Initialized
INFO - 2018-02-11 20:52:40 --> Helper loaded: url_helper
INFO - 2018-02-11 20:52:40 --> Helper loaded: form_helper
INFO - 2018-02-11 20:52:40 --> Database Driver Class Initialized
DEBUG - 2018-02-11 20:52:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 20:52:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 20:52:40 --> Form Validation Class Initialized
INFO - 2018-02-11 20:52:40 --> Model Class Initialized
INFO - 2018-02-11 20:52:40 --> Controller Class Initialized
INFO - 2018-02-11 20:52:40 --> Model Class Initialized
INFO - 2018-02-11 20:52:40 --> Model Class Initialized
INFO - 2018-02-11 20:52:40 --> Model Class Initialized
INFO - 2018-02-11 20:52:40 --> Model Class Initialized
INFO - 2018-02-11 20:52:40 --> Model Class Initialized
DEBUG - 2018-02-11 20:52:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 20:52:48 --> Config Class Initialized
INFO - 2018-02-11 20:52:48 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:52:48 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:52:48 --> Utf8 Class Initialized
INFO - 2018-02-11 20:52:48 --> URI Class Initialized
INFO - 2018-02-11 20:52:48 --> Router Class Initialized
INFO - 2018-02-11 20:52:48 --> Output Class Initialized
INFO - 2018-02-11 20:52:48 --> Security Class Initialized
DEBUG - 2018-02-11 20:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:52:48 --> Input Class Initialized
INFO - 2018-02-11 20:52:48 --> Language Class Initialized
INFO - 2018-02-11 20:52:48 --> Loader Class Initialized
INFO - 2018-02-11 20:52:48 --> Helper loaded: url_helper
INFO - 2018-02-11 20:52:48 --> Helper loaded: form_helper
INFO - 2018-02-11 20:52:48 --> Database Driver Class Initialized
DEBUG - 2018-02-11 20:52:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 20:52:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 20:52:48 --> Form Validation Class Initialized
INFO - 2018-02-11 20:52:48 --> Model Class Initialized
INFO - 2018-02-11 20:52:48 --> Controller Class Initialized
INFO - 2018-02-11 20:52:48 --> Model Class Initialized
INFO - 2018-02-11 20:52:48 --> Model Class Initialized
INFO - 2018-02-11 20:52:48 --> Model Class Initialized
INFO - 2018-02-11 20:52:48 --> Model Class Initialized
INFO - 2018-02-11 20:52:48 --> Model Class Initialized
DEBUG - 2018-02-11 20:52:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 20:52:49 --> Config Class Initialized
INFO - 2018-02-11 20:52:49 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:52:49 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:52:49 --> Utf8 Class Initialized
INFO - 2018-02-11 20:52:49 --> URI Class Initialized
INFO - 2018-02-11 20:52:49 --> Router Class Initialized
INFO - 2018-02-11 20:52:49 --> Output Class Initialized
INFO - 2018-02-11 20:52:49 --> Security Class Initialized
DEBUG - 2018-02-11 20:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:52:49 --> Input Class Initialized
INFO - 2018-02-11 20:52:49 --> Language Class Initialized
INFO - 2018-02-11 20:52:49 --> Loader Class Initialized
INFO - 2018-02-11 20:52:49 --> Helper loaded: url_helper
INFO - 2018-02-11 20:52:49 --> Helper loaded: form_helper
INFO - 2018-02-11 20:52:49 --> Database Driver Class Initialized
DEBUG - 2018-02-11 20:52:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 20:52:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 20:52:49 --> Form Validation Class Initialized
INFO - 2018-02-11 20:52:49 --> Model Class Initialized
INFO - 2018-02-11 20:52:49 --> Controller Class Initialized
INFO - 2018-02-11 20:52:49 --> Model Class Initialized
INFO - 2018-02-11 20:52:49 --> Model Class Initialized
INFO - 2018-02-11 20:52:49 --> Model Class Initialized
INFO - 2018-02-11 20:52:49 --> Model Class Initialized
INFO - 2018-02-11 20:52:49 --> Model Class Initialized
DEBUG - 2018-02-11 20:52:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 20:52:49 --> Config Class Initialized
INFO - 2018-02-11 20:52:49 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:52:49 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:52:49 --> Utf8 Class Initialized
INFO - 2018-02-11 20:52:49 --> URI Class Initialized
INFO - 2018-02-11 20:52:49 --> Router Class Initialized
INFO - 2018-02-11 20:52:49 --> Output Class Initialized
INFO - 2018-02-11 20:52:49 --> Security Class Initialized
DEBUG - 2018-02-11 20:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:52:49 --> Input Class Initialized
INFO - 2018-02-11 20:52:49 --> Language Class Initialized
INFO - 2018-02-11 20:52:49 --> Loader Class Initialized
INFO - 2018-02-11 20:52:49 --> Helper loaded: url_helper
INFO - 2018-02-11 20:52:49 --> Helper loaded: form_helper
INFO - 2018-02-11 20:52:49 --> Database Driver Class Initialized
DEBUG - 2018-02-11 20:52:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 20:52:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 20:52:49 --> Form Validation Class Initialized
INFO - 2018-02-11 20:52:49 --> Model Class Initialized
INFO - 2018-02-11 20:52:49 --> Controller Class Initialized
INFO - 2018-02-11 20:52:49 --> Model Class Initialized
INFO - 2018-02-11 20:52:49 --> Model Class Initialized
INFO - 2018-02-11 20:52:49 --> Model Class Initialized
INFO - 2018-02-11 20:52:49 --> Model Class Initialized
INFO - 2018-02-11 20:52:49 --> Model Class Initialized
DEBUG - 2018-02-11 20:52:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 20:52:49 --> Config Class Initialized
INFO - 2018-02-11 20:52:49 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:52:49 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:52:49 --> Utf8 Class Initialized
INFO - 2018-02-11 20:52:49 --> URI Class Initialized
INFO - 2018-02-11 20:52:49 --> Router Class Initialized
INFO - 2018-02-11 20:52:49 --> Output Class Initialized
INFO - 2018-02-11 20:52:49 --> Security Class Initialized
DEBUG - 2018-02-11 20:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:52:49 --> Input Class Initialized
INFO - 2018-02-11 20:52:49 --> Language Class Initialized
INFO - 2018-02-11 20:52:49 --> Loader Class Initialized
INFO - 2018-02-11 20:52:49 --> Helper loaded: url_helper
INFO - 2018-02-11 20:52:49 --> Helper loaded: form_helper
INFO - 2018-02-11 20:52:49 --> Database Driver Class Initialized
DEBUG - 2018-02-11 20:52:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 20:52:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 20:52:49 --> Form Validation Class Initialized
INFO - 2018-02-11 20:52:49 --> Model Class Initialized
INFO - 2018-02-11 20:52:49 --> Controller Class Initialized
INFO - 2018-02-11 20:52:49 --> Model Class Initialized
INFO - 2018-02-11 20:52:49 --> Model Class Initialized
INFO - 2018-02-11 20:52:49 --> Model Class Initialized
INFO - 2018-02-11 20:52:49 --> Model Class Initialized
INFO - 2018-02-11 20:52:49 --> Model Class Initialized
DEBUG - 2018-02-11 20:52:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 20:52:52 --> Config Class Initialized
INFO - 2018-02-11 20:52:52 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:52:52 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:52:52 --> Utf8 Class Initialized
INFO - 2018-02-11 20:52:52 --> URI Class Initialized
INFO - 2018-02-11 20:52:52 --> Router Class Initialized
INFO - 2018-02-11 20:52:52 --> Output Class Initialized
INFO - 2018-02-11 20:52:52 --> Security Class Initialized
DEBUG - 2018-02-11 20:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:52:52 --> Input Class Initialized
INFO - 2018-02-11 20:52:52 --> Language Class Initialized
INFO - 2018-02-11 20:52:52 --> Loader Class Initialized
INFO - 2018-02-11 20:52:52 --> Helper loaded: url_helper
INFO - 2018-02-11 20:52:52 --> Helper loaded: form_helper
INFO - 2018-02-11 20:52:52 --> Database Driver Class Initialized
DEBUG - 2018-02-11 20:52:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 20:52:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 20:52:52 --> Form Validation Class Initialized
INFO - 2018-02-11 20:52:52 --> Model Class Initialized
INFO - 2018-02-11 20:52:52 --> Controller Class Initialized
INFO - 2018-02-11 20:52:52 --> Model Class Initialized
INFO - 2018-02-11 20:52:52 --> Model Class Initialized
INFO - 2018-02-11 20:52:52 --> Model Class Initialized
INFO - 2018-02-11 20:52:52 --> Model Class Initialized
INFO - 2018-02-11 20:52:52 --> Model Class Initialized
DEBUG - 2018-02-11 20:52:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 20:52:52 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-11 20:52:52 --> Final output sent to browser
DEBUG - 2018-02-11 20:52:52 --> Total execution time: 0.0561
INFO - 2018-02-11 20:52:52 --> Config Class Initialized
INFO - 2018-02-11 20:52:52 --> Config Class Initialized
INFO - 2018-02-11 20:52:52 --> Hooks Class Initialized
INFO - 2018-02-11 20:52:52 --> Config Class Initialized
INFO - 2018-02-11 20:52:52 --> Hooks Class Initialized
INFO - 2018-02-11 20:52:52 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:52:52 --> UTF-8 Support Enabled
DEBUG - 2018-02-11 20:52:52 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:52:52 --> Utf8 Class Initialized
INFO - 2018-02-11 20:52:52 --> Utf8 Class Initialized
DEBUG - 2018-02-11 20:52:52 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:52:52 --> Utf8 Class Initialized
INFO - 2018-02-11 20:52:52 --> URI Class Initialized
INFO - 2018-02-11 20:52:52 --> URI Class Initialized
INFO - 2018-02-11 20:52:52 --> URI Class Initialized
INFO - 2018-02-11 20:52:52 --> Router Class Initialized
INFO - 2018-02-11 20:52:52 --> Router Class Initialized
INFO - 2018-02-11 20:52:52 --> Router Class Initialized
INFO - 2018-02-11 20:52:52 --> Output Class Initialized
INFO - 2018-02-11 20:52:52 --> Output Class Initialized
INFO - 2018-02-11 20:52:52 --> Output Class Initialized
INFO - 2018-02-11 20:52:52 --> Security Class Initialized
INFO - 2018-02-11 20:52:52 --> Security Class Initialized
DEBUG - 2018-02-11 20:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:52:52 --> Security Class Initialized
INFO - 2018-02-11 20:52:52 --> Input Class Initialized
DEBUG - 2018-02-11 20:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:52:52 --> Language Class Initialized
INFO - 2018-02-11 20:52:52 --> Input Class Initialized
DEBUG - 2018-02-11 20:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:52:52 --> Input Class Initialized
INFO - 2018-02-11 20:52:52 --> Language Class Initialized
INFO - 2018-02-11 20:52:52 --> Language Class Initialized
ERROR - 2018-02-11 20:52:52 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-11 20:52:52 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-11 20:52:52 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-11 20:52:52 --> Config Class Initialized
INFO - 2018-02-11 20:52:52 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:52:52 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:52:52 --> Utf8 Class Initialized
INFO - 2018-02-11 20:52:52 --> URI Class Initialized
INFO - 2018-02-11 20:52:52 --> Router Class Initialized
INFO - 2018-02-11 20:52:52 --> Output Class Initialized
INFO - 2018-02-11 20:52:52 --> Security Class Initialized
DEBUG - 2018-02-11 20:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:52:52 --> Input Class Initialized
INFO - 2018-02-11 20:52:52 --> Language Class Initialized
ERROR - 2018-02-11 20:52:52 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-11 20:52:52 --> Config Class Initialized
INFO - 2018-02-11 20:52:52 --> Config Class Initialized
INFO - 2018-02-11 20:52:52 --> Hooks Class Initialized
INFO - 2018-02-11 20:52:52 --> Config Class Initialized
INFO - 2018-02-11 20:52:52 --> Hooks Class Initialized
INFO - 2018-02-11 20:52:52 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:52:52 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:52:52 --> Utf8 Class Initialized
DEBUG - 2018-02-11 20:52:52 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:52:52 --> Utf8 Class Initialized
DEBUG - 2018-02-11 20:52:52 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:52:52 --> URI Class Initialized
INFO - 2018-02-11 20:52:52 --> Utf8 Class Initialized
INFO - 2018-02-11 20:52:52 --> URI Class Initialized
INFO - 2018-02-11 20:52:52 --> URI Class Initialized
INFO - 2018-02-11 20:52:52 --> Router Class Initialized
INFO - 2018-02-11 20:52:52 --> Router Class Initialized
INFO - 2018-02-11 20:52:52 --> Router Class Initialized
INFO - 2018-02-11 20:52:52 --> Output Class Initialized
INFO - 2018-02-11 20:52:52 --> Output Class Initialized
INFO - 2018-02-11 20:52:52 --> Output Class Initialized
INFO - 2018-02-11 20:52:52 --> Security Class Initialized
INFO - 2018-02-11 20:52:52 --> Security Class Initialized
INFO - 2018-02-11 20:52:52 --> Security Class Initialized
DEBUG - 2018-02-11 20:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:52:52 --> Input Class Initialized
DEBUG - 2018-02-11 20:52:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-11 20:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:52:52 --> Input Class Initialized
INFO - 2018-02-11 20:52:52 --> Input Class Initialized
INFO - 2018-02-11 20:52:52 --> Language Class Initialized
INFO - 2018-02-11 20:52:52 --> Language Class Initialized
INFO - 2018-02-11 20:52:52 --> Language Class Initialized
ERROR - 2018-02-11 20:52:52 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-11 20:52:52 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-11 20:52:52 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-11 20:52:52 --> Config Class Initialized
INFO - 2018-02-11 20:52:52 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:52:52 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:52:52 --> Utf8 Class Initialized
INFO - 2018-02-11 20:52:52 --> URI Class Initialized
INFO - 2018-02-11 20:52:52 --> Router Class Initialized
INFO - 2018-02-11 20:52:52 --> Output Class Initialized
INFO - 2018-02-11 20:52:52 --> Security Class Initialized
DEBUG - 2018-02-11 20:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:52:52 --> Input Class Initialized
INFO - 2018-02-11 20:52:52 --> Language Class Initialized
INFO - 2018-02-11 20:52:52 --> Loader Class Initialized
INFO - 2018-02-11 20:52:52 --> Helper loaded: url_helper
INFO - 2018-02-11 20:52:52 --> Helper loaded: form_helper
INFO - 2018-02-11 20:52:52 --> Database Driver Class Initialized
DEBUG - 2018-02-11 20:52:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 20:52:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 20:52:52 --> Form Validation Class Initialized
INFO - 2018-02-11 20:52:52 --> Model Class Initialized
INFO - 2018-02-11 20:52:52 --> Controller Class Initialized
INFO - 2018-02-11 20:52:52 --> Model Class Initialized
INFO - 2018-02-11 20:52:52 --> Model Class Initialized
INFO - 2018-02-11 20:52:52 --> Model Class Initialized
INFO - 2018-02-11 20:52:52 --> Model Class Initialized
INFO - 2018-02-11 20:52:52 --> Model Class Initialized
DEBUG - 2018-02-11 20:52:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 20:53:13 --> Config Class Initialized
INFO - 2018-02-11 20:53:13 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:53:13 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:53:13 --> Utf8 Class Initialized
INFO - 2018-02-11 20:53:13 --> URI Class Initialized
INFO - 2018-02-11 20:53:13 --> Router Class Initialized
INFO - 2018-02-11 20:53:13 --> Output Class Initialized
INFO - 2018-02-11 20:53:13 --> Security Class Initialized
DEBUG - 2018-02-11 20:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:53:13 --> Input Class Initialized
INFO - 2018-02-11 20:53:13 --> Language Class Initialized
INFO - 2018-02-11 20:53:13 --> Loader Class Initialized
INFO - 2018-02-11 20:53:13 --> Helper loaded: url_helper
INFO - 2018-02-11 20:53:13 --> Helper loaded: form_helper
INFO - 2018-02-11 20:53:13 --> Database Driver Class Initialized
DEBUG - 2018-02-11 20:53:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 20:53:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 20:53:13 --> Form Validation Class Initialized
INFO - 2018-02-11 20:53:13 --> Model Class Initialized
INFO - 2018-02-11 20:53:13 --> Controller Class Initialized
INFO - 2018-02-11 20:53:13 --> Model Class Initialized
INFO - 2018-02-11 20:53:13 --> Model Class Initialized
INFO - 2018-02-11 20:53:14 --> Model Class Initialized
INFO - 2018-02-11 20:53:14 --> Model Class Initialized
INFO - 2018-02-11 20:53:14 --> Model Class Initialized
DEBUG - 2018-02-11 20:53:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 20:53:14 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-11 20:53:14 --> Final output sent to browser
DEBUG - 2018-02-11 20:53:14 --> Total execution time: 0.0636
INFO - 2018-02-11 20:53:14 --> Config Class Initialized
INFO - 2018-02-11 20:53:14 --> Hooks Class Initialized
INFO - 2018-02-11 20:53:14 --> Config Class Initialized
INFO - 2018-02-11 20:53:14 --> Config Class Initialized
INFO - 2018-02-11 20:53:14 --> Hooks Class Initialized
INFO - 2018-02-11 20:53:14 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:53:14 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:53:14 --> Utf8 Class Initialized
DEBUG - 2018-02-11 20:53:14 --> UTF-8 Support Enabled
DEBUG - 2018-02-11 20:53:14 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:53:14 --> Utf8 Class Initialized
INFO - 2018-02-11 20:53:14 --> Utf8 Class Initialized
INFO - 2018-02-11 20:53:14 --> URI Class Initialized
INFO - 2018-02-11 20:53:14 --> URI Class Initialized
INFO - 2018-02-11 20:53:14 --> URI Class Initialized
INFO - 2018-02-11 20:53:14 --> Router Class Initialized
INFO - 2018-02-11 20:53:14 --> Router Class Initialized
INFO - 2018-02-11 20:53:14 --> Router Class Initialized
INFO - 2018-02-11 20:53:14 --> Output Class Initialized
INFO - 2018-02-11 20:53:14 --> Output Class Initialized
INFO - 2018-02-11 20:53:14 --> Security Class Initialized
INFO - 2018-02-11 20:53:14 --> Output Class Initialized
INFO - 2018-02-11 20:53:14 --> Security Class Initialized
DEBUG - 2018-02-11 20:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:53:14 --> Input Class Initialized
INFO - 2018-02-11 20:53:14 --> Security Class Initialized
DEBUG - 2018-02-11 20:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:53:14 --> Language Class Initialized
INFO - 2018-02-11 20:53:14 --> Input Class Initialized
DEBUG - 2018-02-11 20:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:53:14 --> Input Class Initialized
INFO - 2018-02-11 20:53:14 --> Language Class Initialized
ERROR - 2018-02-11 20:53:14 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-11 20:53:14 --> Language Class Initialized
ERROR - 2018-02-11 20:53:14 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-11 20:53:14 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-11 20:53:14 --> Config Class Initialized
INFO - 2018-02-11 20:53:14 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:53:14 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:53:14 --> Utf8 Class Initialized
INFO - 2018-02-11 20:53:14 --> URI Class Initialized
INFO - 2018-02-11 20:53:14 --> Router Class Initialized
INFO - 2018-02-11 20:53:14 --> Output Class Initialized
INFO - 2018-02-11 20:53:14 --> Security Class Initialized
DEBUG - 2018-02-11 20:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:53:14 --> Input Class Initialized
INFO - 2018-02-11 20:53:14 --> Language Class Initialized
ERROR - 2018-02-11 20:53:14 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-11 20:53:14 --> Config Class Initialized
INFO - 2018-02-11 20:53:14 --> Hooks Class Initialized
INFO - 2018-02-11 20:53:14 --> Config Class Initialized
INFO - 2018-02-11 20:53:14 --> Hooks Class Initialized
INFO - 2018-02-11 20:53:14 --> Config Class Initialized
INFO - 2018-02-11 20:53:14 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:53:14 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:53:14 --> Utf8 Class Initialized
DEBUG - 2018-02-11 20:53:14 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:53:14 --> Utf8 Class Initialized
DEBUG - 2018-02-11 20:53:14 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:53:14 --> URI Class Initialized
INFO - 2018-02-11 20:53:14 --> Utf8 Class Initialized
INFO - 2018-02-11 20:53:14 --> URI Class Initialized
INFO - 2018-02-11 20:53:14 --> URI Class Initialized
INFO - 2018-02-11 20:53:14 --> Router Class Initialized
INFO - 2018-02-11 20:53:14 --> Router Class Initialized
INFO - 2018-02-11 20:53:14 --> Router Class Initialized
INFO - 2018-02-11 20:53:14 --> Output Class Initialized
INFO - 2018-02-11 20:53:14 --> Output Class Initialized
INFO - 2018-02-11 20:53:14 --> Output Class Initialized
INFO - 2018-02-11 20:53:14 --> Security Class Initialized
INFO - 2018-02-11 20:53:14 --> Security Class Initialized
INFO - 2018-02-11 20:53:14 --> Security Class Initialized
DEBUG - 2018-02-11 20:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:53:14 --> Input Class Initialized
DEBUG - 2018-02-11 20:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:53:14 --> Input Class Initialized
DEBUG - 2018-02-11 20:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:53:14 --> Language Class Initialized
INFO - 2018-02-11 20:53:14 --> Input Class Initialized
INFO - 2018-02-11 20:53:14 --> Language Class Initialized
INFO - 2018-02-11 20:53:14 --> Language Class Initialized
ERROR - 2018-02-11 20:53:14 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-11 20:53:14 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-11 20:53:14 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-11 20:53:14 --> Config Class Initialized
INFO - 2018-02-11 20:53:14 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:53:14 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:53:14 --> Utf8 Class Initialized
INFO - 2018-02-11 20:53:14 --> URI Class Initialized
INFO - 2018-02-11 20:53:14 --> Router Class Initialized
INFO - 2018-02-11 20:53:14 --> Output Class Initialized
INFO - 2018-02-11 20:53:14 --> Security Class Initialized
DEBUG - 2018-02-11 20:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:53:14 --> Input Class Initialized
INFO - 2018-02-11 20:53:14 --> Language Class Initialized
INFO - 2018-02-11 20:53:14 --> Loader Class Initialized
INFO - 2018-02-11 20:53:14 --> Helper loaded: url_helper
INFO - 2018-02-11 20:53:14 --> Helper loaded: form_helper
INFO - 2018-02-11 20:53:14 --> Database Driver Class Initialized
DEBUG - 2018-02-11 20:53:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 20:53:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 20:53:14 --> Form Validation Class Initialized
INFO - 2018-02-11 20:53:14 --> Model Class Initialized
INFO - 2018-02-11 20:53:14 --> Controller Class Initialized
INFO - 2018-02-11 20:53:14 --> Model Class Initialized
INFO - 2018-02-11 20:53:14 --> Model Class Initialized
INFO - 2018-02-11 20:53:14 --> Model Class Initialized
INFO - 2018-02-11 20:53:14 --> Model Class Initialized
INFO - 2018-02-11 20:53:14 --> Model Class Initialized
DEBUG - 2018-02-11 20:53:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 20:54:25 --> Config Class Initialized
INFO - 2018-02-11 20:54:25 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:54:25 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:54:25 --> Utf8 Class Initialized
INFO - 2018-02-11 20:54:25 --> URI Class Initialized
INFO - 2018-02-11 20:54:25 --> Router Class Initialized
INFO - 2018-02-11 20:54:25 --> Output Class Initialized
INFO - 2018-02-11 20:54:25 --> Security Class Initialized
DEBUG - 2018-02-11 20:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:54:25 --> Input Class Initialized
INFO - 2018-02-11 20:54:25 --> Language Class Initialized
INFO - 2018-02-11 20:54:25 --> Loader Class Initialized
INFO - 2018-02-11 20:54:25 --> Helper loaded: url_helper
INFO - 2018-02-11 20:54:25 --> Helper loaded: form_helper
INFO - 2018-02-11 20:54:25 --> Database Driver Class Initialized
DEBUG - 2018-02-11 20:54:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 20:54:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 20:54:25 --> Form Validation Class Initialized
INFO - 2018-02-11 20:54:25 --> Model Class Initialized
INFO - 2018-02-11 20:54:25 --> Controller Class Initialized
INFO - 2018-02-11 20:54:25 --> Model Class Initialized
INFO - 2018-02-11 20:54:25 --> Model Class Initialized
INFO - 2018-02-11 20:54:25 --> Model Class Initialized
INFO - 2018-02-11 20:54:25 --> Model Class Initialized
INFO - 2018-02-11 20:54:25 --> Model Class Initialized
DEBUG - 2018-02-11 20:54:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 20:54:25 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-11 20:54:25 --> Final output sent to browser
DEBUG - 2018-02-11 20:54:25 --> Total execution time: 0.0580
INFO - 2018-02-11 20:54:25 --> Config Class Initialized
INFO - 2018-02-11 20:54:25 --> Config Class Initialized
INFO - 2018-02-11 20:54:25 --> Config Class Initialized
INFO - 2018-02-11 20:54:25 --> Hooks Class Initialized
INFO - 2018-02-11 20:54:25 --> Hooks Class Initialized
INFO - 2018-02-11 20:54:25 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:54:25 --> UTF-8 Support Enabled
DEBUG - 2018-02-11 20:54:25 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:54:25 --> Utf8 Class Initialized
INFO - 2018-02-11 20:54:25 --> Utf8 Class Initialized
DEBUG - 2018-02-11 20:54:25 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:54:25 --> Utf8 Class Initialized
INFO - 2018-02-11 20:54:25 --> URI Class Initialized
INFO - 2018-02-11 20:54:25 --> URI Class Initialized
INFO - 2018-02-11 20:54:25 --> URI Class Initialized
INFO - 2018-02-11 20:54:25 --> Router Class Initialized
INFO - 2018-02-11 20:54:25 --> Router Class Initialized
INFO - 2018-02-11 20:54:25 --> Router Class Initialized
INFO - 2018-02-11 20:54:25 --> Output Class Initialized
INFO - 2018-02-11 20:54:25 --> Output Class Initialized
INFO - 2018-02-11 20:54:25 --> Output Class Initialized
INFO - 2018-02-11 20:54:25 --> Security Class Initialized
INFO - 2018-02-11 20:54:25 --> Security Class Initialized
INFO - 2018-02-11 20:54:25 --> Security Class Initialized
DEBUG - 2018-02-11 20:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:54:25 --> Input Class Initialized
DEBUG - 2018-02-11 20:54:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-11 20:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:54:25 --> Input Class Initialized
INFO - 2018-02-11 20:54:25 --> Input Class Initialized
INFO - 2018-02-11 20:54:25 --> Language Class Initialized
INFO - 2018-02-11 20:54:25 --> Language Class Initialized
INFO - 2018-02-11 20:54:25 --> Language Class Initialized
ERROR - 2018-02-11 20:54:25 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-11 20:54:25 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-11 20:54:25 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-11 20:54:25 --> Config Class Initialized
INFO - 2018-02-11 20:54:25 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:54:25 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:54:25 --> Utf8 Class Initialized
INFO - 2018-02-11 20:54:25 --> URI Class Initialized
INFO - 2018-02-11 20:54:25 --> Router Class Initialized
INFO - 2018-02-11 20:54:25 --> Output Class Initialized
INFO - 2018-02-11 20:54:25 --> Security Class Initialized
DEBUG - 2018-02-11 20:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:54:25 --> Input Class Initialized
INFO - 2018-02-11 20:54:25 --> Language Class Initialized
ERROR - 2018-02-11 20:54:25 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-11 20:54:25 --> Config Class Initialized
INFO - 2018-02-11 20:54:25 --> Hooks Class Initialized
INFO - 2018-02-11 20:54:25 --> Config Class Initialized
INFO - 2018-02-11 20:54:25 --> Config Class Initialized
INFO - 2018-02-11 20:54:25 --> Hooks Class Initialized
INFO - 2018-02-11 20:54:25 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:54:25 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:54:25 --> Utf8 Class Initialized
DEBUG - 2018-02-11 20:54:25 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:54:25 --> Utf8 Class Initialized
DEBUG - 2018-02-11 20:54:25 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:54:25 --> Utf8 Class Initialized
INFO - 2018-02-11 20:54:25 --> URI Class Initialized
INFO - 2018-02-11 20:54:25 --> URI Class Initialized
INFO - 2018-02-11 20:54:25 --> URI Class Initialized
INFO - 2018-02-11 20:54:25 --> Router Class Initialized
INFO - 2018-02-11 20:54:25 --> Router Class Initialized
INFO - 2018-02-11 20:54:25 --> Router Class Initialized
INFO - 2018-02-11 20:54:25 --> Output Class Initialized
INFO - 2018-02-11 20:54:25 --> Output Class Initialized
INFO - 2018-02-11 20:54:25 --> Output Class Initialized
INFO - 2018-02-11 20:54:25 --> Security Class Initialized
INFO - 2018-02-11 20:54:25 --> Security Class Initialized
INFO - 2018-02-11 20:54:25 --> Security Class Initialized
DEBUG - 2018-02-11 20:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:54:25 --> Input Class Initialized
DEBUG - 2018-02-11 20:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:54:25 --> Input Class Initialized
INFO - 2018-02-11 20:54:25 --> Language Class Initialized
DEBUG - 2018-02-11 20:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:54:25 --> Input Class Initialized
INFO - 2018-02-11 20:54:25 --> Language Class Initialized
INFO - 2018-02-11 20:54:25 --> Language Class Initialized
ERROR - 2018-02-11 20:54:25 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-11 20:54:25 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-11 20:54:25 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-11 20:54:25 --> Config Class Initialized
INFO - 2018-02-11 20:54:25 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:54:25 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:54:25 --> Utf8 Class Initialized
INFO - 2018-02-11 20:54:25 --> URI Class Initialized
INFO - 2018-02-11 20:54:25 --> Router Class Initialized
INFO - 2018-02-11 20:54:25 --> Output Class Initialized
INFO - 2018-02-11 20:54:25 --> Security Class Initialized
DEBUG - 2018-02-11 20:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:54:25 --> Input Class Initialized
INFO - 2018-02-11 20:54:25 --> Language Class Initialized
INFO - 2018-02-11 20:54:25 --> Loader Class Initialized
INFO - 2018-02-11 20:54:25 --> Helper loaded: url_helper
INFO - 2018-02-11 20:54:25 --> Helper loaded: form_helper
INFO - 2018-02-11 20:54:25 --> Database Driver Class Initialized
DEBUG - 2018-02-11 20:54:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 20:54:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 20:54:25 --> Form Validation Class Initialized
INFO - 2018-02-11 20:54:25 --> Model Class Initialized
INFO - 2018-02-11 20:54:25 --> Controller Class Initialized
INFO - 2018-02-11 20:54:25 --> Model Class Initialized
INFO - 2018-02-11 20:54:25 --> Model Class Initialized
INFO - 2018-02-11 20:54:25 --> Model Class Initialized
INFO - 2018-02-11 20:54:25 --> Model Class Initialized
INFO - 2018-02-11 20:54:25 --> Model Class Initialized
DEBUG - 2018-02-11 20:54:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 20:54:42 --> Config Class Initialized
INFO - 2018-02-11 20:54:42 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:54:42 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:54:42 --> Utf8 Class Initialized
INFO - 2018-02-11 20:54:42 --> URI Class Initialized
INFO - 2018-02-11 20:54:42 --> Router Class Initialized
INFO - 2018-02-11 20:54:42 --> Output Class Initialized
INFO - 2018-02-11 20:54:42 --> Security Class Initialized
DEBUG - 2018-02-11 20:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:54:42 --> Input Class Initialized
INFO - 2018-02-11 20:54:42 --> Language Class Initialized
INFO - 2018-02-11 20:54:42 --> Loader Class Initialized
INFO - 2018-02-11 20:54:42 --> Helper loaded: url_helper
INFO - 2018-02-11 20:54:42 --> Helper loaded: form_helper
INFO - 2018-02-11 20:54:42 --> Database Driver Class Initialized
DEBUG - 2018-02-11 20:54:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 20:54:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 20:54:42 --> Form Validation Class Initialized
INFO - 2018-02-11 20:54:42 --> Model Class Initialized
INFO - 2018-02-11 20:54:42 --> Controller Class Initialized
INFO - 2018-02-11 20:54:42 --> Model Class Initialized
INFO - 2018-02-11 20:54:42 --> Model Class Initialized
INFO - 2018-02-11 20:54:42 --> Model Class Initialized
INFO - 2018-02-11 20:54:42 --> Model Class Initialized
INFO - 2018-02-11 20:54:42 --> Model Class Initialized
DEBUG - 2018-02-11 20:54:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 20:54:42 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-11 20:54:42 --> Final output sent to browser
DEBUG - 2018-02-11 20:54:42 --> Total execution time: 0.0639
INFO - 2018-02-11 20:54:42 --> Config Class Initialized
INFO - 2018-02-11 20:54:42 --> Config Class Initialized
INFO - 2018-02-11 20:54:42 --> Hooks Class Initialized
INFO - 2018-02-11 20:54:42 --> Hooks Class Initialized
INFO - 2018-02-11 20:54:42 --> Config Class Initialized
INFO - 2018-02-11 20:54:42 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:54:42 --> UTF-8 Support Enabled
DEBUG - 2018-02-11 20:54:42 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:54:42 --> Utf8 Class Initialized
INFO - 2018-02-11 20:54:42 --> Utf8 Class Initialized
DEBUG - 2018-02-11 20:54:42 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:54:42 --> Utf8 Class Initialized
INFO - 2018-02-11 20:54:42 --> URI Class Initialized
INFO - 2018-02-11 20:54:42 --> URI Class Initialized
INFO - 2018-02-11 20:54:42 --> URI Class Initialized
INFO - 2018-02-11 20:54:42 --> Router Class Initialized
INFO - 2018-02-11 20:54:42 --> Router Class Initialized
INFO - 2018-02-11 20:54:42 --> Router Class Initialized
INFO - 2018-02-11 20:54:42 --> Output Class Initialized
INFO - 2018-02-11 20:54:42 --> Output Class Initialized
INFO - 2018-02-11 20:54:42 --> Security Class Initialized
INFO - 2018-02-11 20:54:42 --> Output Class Initialized
INFO - 2018-02-11 20:54:42 --> Security Class Initialized
DEBUG - 2018-02-11 20:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:54:42 --> Input Class Initialized
INFO - 2018-02-11 20:54:42 --> Security Class Initialized
INFO - 2018-02-11 20:54:42 --> Language Class Initialized
DEBUG - 2018-02-11 20:54:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-11 20:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:54:42 --> Input Class Initialized
INFO - 2018-02-11 20:54:42 --> Input Class Initialized
ERROR - 2018-02-11 20:54:42 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-11 20:54:42 --> Language Class Initialized
INFO - 2018-02-11 20:54:42 --> Language Class Initialized
ERROR - 2018-02-11 20:54:42 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-11 20:54:42 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-11 20:54:42 --> Config Class Initialized
INFO - 2018-02-11 20:54:42 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:54:42 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:54:42 --> Utf8 Class Initialized
INFO - 2018-02-11 20:54:42 --> URI Class Initialized
INFO - 2018-02-11 20:54:42 --> Router Class Initialized
INFO - 2018-02-11 20:54:42 --> Output Class Initialized
INFO - 2018-02-11 20:54:42 --> Security Class Initialized
DEBUG - 2018-02-11 20:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:54:42 --> Input Class Initialized
INFO - 2018-02-11 20:54:42 --> Language Class Initialized
ERROR - 2018-02-11 20:54:42 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-11 20:54:42 --> Config Class Initialized
INFO - 2018-02-11 20:54:42 --> Hooks Class Initialized
INFO - 2018-02-11 20:54:42 --> Config Class Initialized
INFO - 2018-02-11 20:54:42 --> Hooks Class Initialized
INFO - 2018-02-11 20:54:42 --> Config Class Initialized
INFO - 2018-02-11 20:54:42 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:54:42 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:54:42 --> Utf8 Class Initialized
INFO - 2018-02-11 20:54:42 --> URI Class Initialized
DEBUG - 2018-02-11 20:54:42 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:54:42 --> Utf8 Class Initialized
DEBUG - 2018-02-11 20:54:42 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:54:42 --> Utf8 Class Initialized
INFO - 2018-02-11 20:54:42 --> URI Class Initialized
INFO - 2018-02-11 20:54:42 --> URI Class Initialized
INFO - 2018-02-11 20:54:42 --> Router Class Initialized
INFO - 2018-02-11 20:54:42 --> Router Class Initialized
INFO - 2018-02-11 20:54:42 --> Output Class Initialized
INFO - 2018-02-11 20:54:42 --> Router Class Initialized
INFO - 2018-02-11 20:54:42 --> Security Class Initialized
INFO - 2018-02-11 20:54:42 --> Output Class Initialized
INFO - 2018-02-11 20:54:42 --> Output Class Initialized
DEBUG - 2018-02-11 20:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:54:42 --> Input Class Initialized
INFO - 2018-02-11 20:54:42 --> Security Class Initialized
INFO - 2018-02-11 20:54:42 --> Language Class Initialized
INFO - 2018-02-11 20:54:42 --> Security Class Initialized
DEBUG - 2018-02-11 20:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:54:42 --> Input Class Initialized
ERROR - 2018-02-11 20:54:42 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-02-11 20:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:54:42 --> Input Class Initialized
INFO - 2018-02-11 20:54:42 --> Language Class Initialized
INFO - 2018-02-11 20:54:42 --> Language Class Initialized
ERROR - 2018-02-11 20:54:42 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-11 20:54:42 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-11 20:54:42 --> Config Class Initialized
INFO - 2018-02-11 20:54:42 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:54:42 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:54:42 --> Utf8 Class Initialized
INFO - 2018-02-11 20:54:42 --> URI Class Initialized
INFO - 2018-02-11 20:54:42 --> Router Class Initialized
INFO - 2018-02-11 20:54:42 --> Output Class Initialized
INFO - 2018-02-11 20:54:42 --> Security Class Initialized
DEBUG - 2018-02-11 20:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:54:42 --> Input Class Initialized
INFO - 2018-02-11 20:54:42 --> Language Class Initialized
INFO - 2018-02-11 20:54:42 --> Loader Class Initialized
INFO - 2018-02-11 20:54:42 --> Helper loaded: url_helper
INFO - 2018-02-11 20:54:42 --> Helper loaded: form_helper
INFO - 2018-02-11 20:54:42 --> Database Driver Class Initialized
DEBUG - 2018-02-11 20:54:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 20:54:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 20:54:42 --> Form Validation Class Initialized
INFO - 2018-02-11 20:54:42 --> Model Class Initialized
INFO - 2018-02-11 20:54:42 --> Controller Class Initialized
INFO - 2018-02-11 20:54:42 --> Model Class Initialized
INFO - 2018-02-11 20:54:42 --> Model Class Initialized
INFO - 2018-02-11 20:54:42 --> Model Class Initialized
INFO - 2018-02-11 20:54:42 --> Model Class Initialized
INFO - 2018-02-11 20:54:42 --> Model Class Initialized
DEBUG - 2018-02-11 20:54:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 20:54:56 --> Config Class Initialized
INFO - 2018-02-11 20:54:56 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:54:56 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:54:56 --> Utf8 Class Initialized
INFO - 2018-02-11 20:54:56 --> URI Class Initialized
INFO - 2018-02-11 20:54:56 --> Router Class Initialized
INFO - 2018-02-11 20:54:56 --> Output Class Initialized
INFO - 2018-02-11 20:54:56 --> Security Class Initialized
DEBUG - 2018-02-11 20:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:54:56 --> Input Class Initialized
INFO - 2018-02-11 20:54:56 --> Language Class Initialized
INFO - 2018-02-11 20:54:56 --> Loader Class Initialized
INFO - 2018-02-11 20:54:56 --> Helper loaded: url_helper
INFO - 2018-02-11 20:54:56 --> Helper loaded: form_helper
INFO - 2018-02-11 20:54:56 --> Database Driver Class Initialized
DEBUG - 2018-02-11 20:54:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 20:54:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 20:54:56 --> Form Validation Class Initialized
INFO - 2018-02-11 20:54:56 --> Model Class Initialized
INFO - 2018-02-11 20:54:56 --> Controller Class Initialized
INFO - 2018-02-11 20:54:56 --> Model Class Initialized
INFO - 2018-02-11 20:54:56 --> Model Class Initialized
INFO - 2018-02-11 20:54:56 --> Model Class Initialized
INFO - 2018-02-11 20:54:56 --> Model Class Initialized
INFO - 2018-02-11 20:54:56 --> Model Class Initialized
DEBUG - 2018-02-11 20:54:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 20:54:56 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-11 20:54:56 --> Final output sent to browser
DEBUG - 2018-02-11 20:54:56 --> Total execution time: 0.0566
INFO - 2018-02-11 20:54:56 --> Config Class Initialized
INFO - 2018-02-11 20:54:56 --> Config Class Initialized
INFO - 2018-02-11 20:54:56 --> Hooks Class Initialized
INFO - 2018-02-11 20:54:56 --> Config Class Initialized
INFO - 2018-02-11 20:54:56 --> Hooks Class Initialized
INFO - 2018-02-11 20:54:56 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:54:56 --> UTF-8 Support Enabled
DEBUG - 2018-02-11 20:54:56 --> UTF-8 Support Enabled
DEBUG - 2018-02-11 20:54:56 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:54:56 --> Utf8 Class Initialized
INFO - 2018-02-11 20:54:56 --> Utf8 Class Initialized
INFO - 2018-02-11 20:54:56 --> Utf8 Class Initialized
INFO - 2018-02-11 20:54:56 --> URI Class Initialized
INFO - 2018-02-11 20:54:56 --> URI Class Initialized
INFO - 2018-02-11 20:54:56 --> URI Class Initialized
INFO - 2018-02-11 20:54:56 --> Router Class Initialized
INFO - 2018-02-11 20:54:56 --> Router Class Initialized
INFO - 2018-02-11 20:54:56 --> Router Class Initialized
INFO - 2018-02-11 20:54:56 --> Output Class Initialized
INFO - 2018-02-11 20:54:56 --> Output Class Initialized
INFO - 2018-02-11 20:54:56 --> Output Class Initialized
INFO - 2018-02-11 20:54:56 --> Security Class Initialized
INFO - 2018-02-11 20:54:56 --> Security Class Initialized
INFO - 2018-02-11 20:54:56 --> Security Class Initialized
DEBUG - 2018-02-11 20:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:54:56 --> Input Class Initialized
DEBUG - 2018-02-11 20:54:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-11 20:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:54:56 --> Input Class Initialized
INFO - 2018-02-11 20:54:56 --> Input Class Initialized
INFO - 2018-02-11 20:54:56 --> Language Class Initialized
INFO - 2018-02-11 20:54:56 --> Language Class Initialized
INFO - 2018-02-11 20:54:56 --> Language Class Initialized
ERROR - 2018-02-11 20:54:56 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-11 20:54:56 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-11 20:54:56 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-11 20:54:56 --> Config Class Initialized
INFO - 2018-02-11 20:54:56 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:54:56 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:54:56 --> Utf8 Class Initialized
INFO - 2018-02-11 20:54:56 --> URI Class Initialized
INFO - 2018-02-11 20:54:56 --> Router Class Initialized
INFO - 2018-02-11 20:54:56 --> Output Class Initialized
INFO - 2018-02-11 20:54:56 --> Security Class Initialized
DEBUG - 2018-02-11 20:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:54:56 --> Input Class Initialized
INFO - 2018-02-11 20:54:56 --> Language Class Initialized
ERROR - 2018-02-11 20:54:56 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-11 20:54:56 --> Config Class Initialized
INFO - 2018-02-11 20:54:56 --> Hooks Class Initialized
INFO - 2018-02-11 20:54:56 --> Config Class Initialized
INFO - 2018-02-11 20:54:56 --> Hooks Class Initialized
INFO - 2018-02-11 20:54:56 --> Config Class Initialized
INFO - 2018-02-11 20:54:56 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:54:56 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:54:56 --> Utf8 Class Initialized
DEBUG - 2018-02-11 20:54:56 --> UTF-8 Support Enabled
DEBUG - 2018-02-11 20:54:56 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:54:56 --> URI Class Initialized
INFO - 2018-02-11 20:54:56 --> Utf8 Class Initialized
INFO - 2018-02-11 20:54:56 --> Utf8 Class Initialized
INFO - 2018-02-11 20:54:56 --> URI Class Initialized
INFO - 2018-02-11 20:54:56 --> URI Class Initialized
INFO - 2018-02-11 20:54:56 --> Router Class Initialized
INFO - 2018-02-11 20:54:56 --> Router Class Initialized
INFO - 2018-02-11 20:54:56 --> Router Class Initialized
INFO - 2018-02-11 20:54:56 --> Output Class Initialized
INFO - 2018-02-11 20:54:56 --> Output Class Initialized
INFO - 2018-02-11 20:54:56 --> Output Class Initialized
INFO - 2018-02-11 20:54:56 --> Security Class Initialized
INFO - 2018-02-11 20:54:56 --> Security Class Initialized
INFO - 2018-02-11 20:54:56 --> Security Class Initialized
DEBUG - 2018-02-11 20:54:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-11 20:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:54:56 --> Input Class Initialized
INFO - 2018-02-11 20:54:56 --> Input Class Initialized
DEBUG - 2018-02-11 20:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:54:56 --> Input Class Initialized
INFO - 2018-02-11 20:54:56 --> Language Class Initialized
INFO - 2018-02-11 20:54:56 --> Language Class Initialized
INFO - 2018-02-11 20:54:56 --> Language Class Initialized
ERROR - 2018-02-11 20:54:56 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-11 20:54:56 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-11 20:54:56 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-11 20:54:56 --> Config Class Initialized
INFO - 2018-02-11 20:54:56 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:54:56 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:54:56 --> Utf8 Class Initialized
INFO - 2018-02-11 20:54:56 --> URI Class Initialized
INFO - 2018-02-11 20:54:56 --> Router Class Initialized
INFO - 2018-02-11 20:54:56 --> Output Class Initialized
INFO - 2018-02-11 20:54:56 --> Security Class Initialized
DEBUG - 2018-02-11 20:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:54:56 --> Input Class Initialized
INFO - 2018-02-11 20:54:56 --> Language Class Initialized
INFO - 2018-02-11 20:54:56 --> Loader Class Initialized
INFO - 2018-02-11 20:54:56 --> Helper loaded: url_helper
INFO - 2018-02-11 20:54:56 --> Helper loaded: form_helper
INFO - 2018-02-11 20:54:56 --> Database Driver Class Initialized
DEBUG - 2018-02-11 20:54:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 20:54:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 20:54:56 --> Form Validation Class Initialized
INFO - 2018-02-11 20:54:56 --> Model Class Initialized
INFO - 2018-02-11 20:54:56 --> Controller Class Initialized
INFO - 2018-02-11 20:54:56 --> Model Class Initialized
INFO - 2018-02-11 20:54:56 --> Model Class Initialized
INFO - 2018-02-11 20:54:56 --> Model Class Initialized
INFO - 2018-02-11 20:54:56 --> Model Class Initialized
INFO - 2018-02-11 20:54:56 --> Model Class Initialized
DEBUG - 2018-02-11 20:54:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 20:57:08 --> Config Class Initialized
INFO - 2018-02-11 20:57:08 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:57:08 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:57:08 --> Utf8 Class Initialized
INFO - 2018-02-11 20:57:08 --> URI Class Initialized
INFO - 2018-02-11 20:57:08 --> Router Class Initialized
INFO - 2018-02-11 20:57:08 --> Output Class Initialized
INFO - 2018-02-11 20:57:08 --> Security Class Initialized
DEBUG - 2018-02-11 20:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:57:08 --> Input Class Initialized
INFO - 2018-02-11 20:57:08 --> Language Class Initialized
INFO - 2018-02-11 20:57:08 --> Loader Class Initialized
INFO - 2018-02-11 20:57:08 --> Helper loaded: url_helper
INFO - 2018-02-11 20:57:09 --> Helper loaded: form_helper
INFO - 2018-02-11 20:57:09 --> Database Driver Class Initialized
DEBUG - 2018-02-11 20:57:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 20:57:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 20:57:09 --> Form Validation Class Initialized
INFO - 2018-02-11 20:57:09 --> Model Class Initialized
INFO - 2018-02-11 20:57:09 --> Controller Class Initialized
INFO - 2018-02-11 20:57:09 --> Model Class Initialized
INFO - 2018-02-11 20:57:09 --> Model Class Initialized
INFO - 2018-02-11 20:57:09 --> Model Class Initialized
INFO - 2018-02-11 20:57:09 --> Model Class Initialized
INFO - 2018-02-11 20:57:09 --> Model Class Initialized
DEBUG - 2018-02-11 20:57:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 20:57:09 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-11 20:57:09 --> Final output sent to browser
DEBUG - 2018-02-11 20:57:09 --> Total execution time: 0.0668
INFO - 2018-02-11 20:57:09 --> Config Class Initialized
INFO - 2018-02-11 20:57:09 --> Hooks Class Initialized
INFO - 2018-02-11 20:57:09 --> Config Class Initialized
INFO - 2018-02-11 20:57:09 --> Hooks Class Initialized
INFO - 2018-02-11 20:57:09 --> Config Class Initialized
DEBUG - 2018-02-11 20:57:09 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:57:09 --> Hooks Class Initialized
INFO - 2018-02-11 20:57:09 --> Utf8 Class Initialized
DEBUG - 2018-02-11 20:57:09 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:57:09 --> Utf8 Class Initialized
INFO - 2018-02-11 20:57:09 --> URI Class Initialized
INFO - 2018-02-11 20:57:09 --> URI Class Initialized
DEBUG - 2018-02-11 20:57:09 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:57:09 --> Utf8 Class Initialized
INFO - 2018-02-11 20:57:09 --> Router Class Initialized
INFO - 2018-02-11 20:57:09 --> Router Class Initialized
INFO - 2018-02-11 20:57:09 --> URI Class Initialized
INFO - 2018-02-11 20:57:09 --> Output Class Initialized
INFO - 2018-02-11 20:57:09 --> Output Class Initialized
INFO - 2018-02-11 20:57:09 --> Router Class Initialized
INFO - 2018-02-11 20:57:09 --> Security Class Initialized
INFO - 2018-02-11 20:57:09 --> Security Class Initialized
INFO - 2018-02-11 20:57:09 --> Output Class Initialized
DEBUG - 2018-02-11 20:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:57:09 --> Input Class Initialized
DEBUG - 2018-02-11 20:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:57:09 --> Input Class Initialized
INFO - 2018-02-11 20:57:09 --> Security Class Initialized
INFO - 2018-02-11 20:57:09 --> Language Class Initialized
INFO - 2018-02-11 20:57:09 --> Language Class Initialized
DEBUG - 2018-02-11 20:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:57:09 --> Input Class Initialized
ERROR - 2018-02-11 20:57:09 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-11 20:57:09 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-11 20:57:09 --> Language Class Initialized
ERROR - 2018-02-11 20:57:09 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-11 20:57:09 --> Config Class Initialized
INFO - 2018-02-11 20:57:09 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:57:09 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:57:09 --> Utf8 Class Initialized
INFO - 2018-02-11 20:57:09 --> URI Class Initialized
INFO - 2018-02-11 20:57:09 --> Router Class Initialized
INFO - 2018-02-11 20:57:09 --> Output Class Initialized
INFO - 2018-02-11 20:57:09 --> Security Class Initialized
DEBUG - 2018-02-11 20:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:57:09 --> Input Class Initialized
INFO - 2018-02-11 20:57:09 --> Language Class Initialized
ERROR - 2018-02-11 20:57:09 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-11 20:57:09 --> Config Class Initialized
INFO - 2018-02-11 20:57:09 --> Hooks Class Initialized
INFO - 2018-02-11 20:57:09 --> Config Class Initialized
INFO - 2018-02-11 20:57:09 --> Config Class Initialized
INFO - 2018-02-11 20:57:09 --> Hooks Class Initialized
INFO - 2018-02-11 20:57:09 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:57:09 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:57:09 --> Utf8 Class Initialized
DEBUG - 2018-02-11 20:57:09 --> UTF-8 Support Enabled
DEBUG - 2018-02-11 20:57:09 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:57:09 --> Utf8 Class Initialized
INFO - 2018-02-11 20:57:09 --> Utf8 Class Initialized
INFO - 2018-02-11 20:57:09 --> URI Class Initialized
INFO - 2018-02-11 20:57:09 --> URI Class Initialized
INFO - 2018-02-11 20:57:09 --> URI Class Initialized
INFO - 2018-02-11 20:57:09 --> Router Class Initialized
INFO - 2018-02-11 20:57:09 --> Router Class Initialized
INFO - 2018-02-11 20:57:09 --> Router Class Initialized
INFO - 2018-02-11 20:57:09 --> Output Class Initialized
INFO - 2018-02-11 20:57:09 --> Output Class Initialized
INFO - 2018-02-11 20:57:09 --> Output Class Initialized
INFO - 2018-02-11 20:57:09 --> Security Class Initialized
INFO - 2018-02-11 20:57:09 --> Security Class Initialized
INFO - 2018-02-11 20:57:09 --> Security Class Initialized
DEBUG - 2018-02-11 20:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:57:09 --> Input Class Initialized
DEBUG - 2018-02-11 20:57:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-11 20:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:57:09 --> Input Class Initialized
INFO - 2018-02-11 20:57:09 --> Input Class Initialized
INFO - 2018-02-11 20:57:09 --> Language Class Initialized
INFO - 2018-02-11 20:57:09 --> Language Class Initialized
INFO - 2018-02-11 20:57:09 --> Language Class Initialized
ERROR - 2018-02-11 20:57:09 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-11 20:57:09 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-11 20:57:09 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-11 20:57:09 --> Config Class Initialized
INFO - 2018-02-11 20:57:09 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:57:09 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:57:09 --> Utf8 Class Initialized
INFO - 2018-02-11 20:57:09 --> URI Class Initialized
INFO - 2018-02-11 20:57:09 --> Router Class Initialized
INFO - 2018-02-11 20:57:09 --> Output Class Initialized
INFO - 2018-02-11 20:57:09 --> Security Class Initialized
DEBUG - 2018-02-11 20:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:57:09 --> Input Class Initialized
INFO - 2018-02-11 20:57:09 --> Language Class Initialized
INFO - 2018-02-11 20:57:09 --> Loader Class Initialized
INFO - 2018-02-11 20:57:09 --> Helper loaded: url_helper
INFO - 2018-02-11 20:57:09 --> Helper loaded: form_helper
INFO - 2018-02-11 20:57:09 --> Database Driver Class Initialized
DEBUG - 2018-02-11 20:57:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 20:57:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 20:57:09 --> Form Validation Class Initialized
INFO - 2018-02-11 20:57:09 --> Model Class Initialized
INFO - 2018-02-11 20:57:09 --> Controller Class Initialized
INFO - 2018-02-11 20:57:09 --> Model Class Initialized
INFO - 2018-02-11 20:57:09 --> Model Class Initialized
INFO - 2018-02-11 20:57:09 --> Model Class Initialized
INFO - 2018-02-11 20:57:09 --> Model Class Initialized
INFO - 2018-02-11 20:57:09 --> Model Class Initialized
DEBUG - 2018-02-11 20:57:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 20:57:19 --> Config Class Initialized
INFO - 2018-02-11 20:57:19 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:57:19 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:57:19 --> Utf8 Class Initialized
INFO - 2018-02-11 20:57:19 --> URI Class Initialized
INFO - 2018-02-11 20:57:19 --> Router Class Initialized
INFO - 2018-02-11 20:57:19 --> Output Class Initialized
INFO - 2018-02-11 20:57:19 --> Security Class Initialized
DEBUG - 2018-02-11 20:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:57:19 --> Input Class Initialized
INFO - 2018-02-11 20:57:19 --> Language Class Initialized
INFO - 2018-02-11 20:57:19 --> Loader Class Initialized
INFO - 2018-02-11 20:57:19 --> Helper loaded: url_helper
INFO - 2018-02-11 20:57:19 --> Helper loaded: form_helper
INFO - 2018-02-11 20:57:19 --> Database Driver Class Initialized
DEBUG - 2018-02-11 20:57:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 20:57:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 20:57:19 --> Form Validation Class Initialized
INFO - 2018-02-11 20:57:19 --> Model Class Initialized
INFO - 2018-02-11 20:57:19 --> Controller Class Initialized
INFO - 2018-02-11 20:57:19 --> Model Class Initialized
INFO - 2018-02-11 20:57:19 --> Model Class Initialized
INFO - 2018-02-11 20:57:19 --> Model Class Initialized
INFO - 2018-02-11 20:57:19 --> Model Class Initialized
INFO - 2018-02-11 20:57:19 --> Model Class Initialized
DEBUG - 2018-02-11 20:57:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 20:57:19 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-11 20:57:19 --> Final output sent to browser
DEBUG - 2018-02-11 20:57:19 --> Total execution time: 0.0624
INFO - 2018-02-11 20:57:19 --> Config Class Initialized
INFO - 2018-02-11 20:57:19 --> Config Class Initialized
INFO - 2018-02-11 20:57:19 --> Hooks Class Initialized
INFO - 2018-02-11 20:57:19 --> Config Class Initialized
INFO - 2018-02-11 20:57:19 --> Hooks Class Initialized
INFO - 2018-02-11 20:57:19 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:57:19 --> UTF-8 Support Enabled
DEBUG - 2018-02-11 20:57:19 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:57:19 --> Utf8 Class Initialized
INFO - 2018-02-11 20:57:19 --> Config Class Initialized
DEBUG - 2018-02-11 20:57:19 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:57:19 --> Utf8 Class Initialized
INFO - 2018-02-11 20:57:19 --> Hooks Class Initialized
INFO - 2018-02-11 20:57:19 --> Utf8 Class Initialized
INFO - 2018-02-11 20:57:19 --> URI Class Initialized
INFO - 2018-02-11 20:57:19 --> URI Class Initialized
INFO - 2018-02-11 20:57:19 --> URI Class Initialized
INFO - 2018-02-11 20:57:19 --> Router Class Initialized
DEBUG - 2018-02-11 20:57:19 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:57:19 --> Router Class Initialized
INFO - 2018-02-11 20:57:19 --> Utf8 Class Initialized
INFO - 2018-02-11 20:57:19 --> Router Class Initialized
INFO - 2018-02-11 20:57:19 --> Output Class Initialized
INFO - 2018-02-11 20:57:19 --> URI Class Initialized
INFO - 2018-02-11 20:57:19 --> Output Class Initialized
INFO - 2018-02-11 20:57:19 --> Security Class Initialized
INFO - 2018-02-11 20:57:19 --> Output Class Initialized
INFO - 2018-02-11 20:57:19 --> Router Class Initialized
INFO - 2018-02-11 20:57:19 --> Security Class Initialized
DEBUG - 2018-02-11 20:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:57:19 --> Security Class Initialized
INFO - 2018-02-11 20:57:19 --> Input Class Initialized
DEBUG - 2018-02-11 20:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:57:19 --> Input Class Initialized
INFO - 2018-02-11 20:57:19 --> Language Class Initialized
INFO - 2018-02-11 20:57:19 --> Output Class Initialized
DEBUG - 2018-02-11 20:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:57:19 --> Input Class Initialized
INFO - 2018-02-11 20:57:19 --> Language Class Initialized
INFO - 2018-02-11 20:57:19 --> Security Class Initialized
ERROR - 2018-02-11 20:57:19 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-11 20:57:19 --> Language Class Initialized
ERROR - 2018-02-11 20:57:19 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-02-11 20:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:57:19 --> Input Class Initialized
INFO - 2018-02-11 20:57:19 --> Language Class Initialized
ERROR - 2018-02-11 20:57:19 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-11 20:57:19 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-11 20:57:19 --> Config Class Initialized
INFO - 2018-02-11 20:57:19 --> Hooks Class Initialized
INFO - 2018-02-11 20:57:19 --> Config Class Initialized
INFO - 2018-02-11 20:57:19 --> Config Class Initialized
INFO - 2018-02-11 20:57:19 --> Hooks Class Initialized
INFO - 2018-02-11 20:57:19 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:57:19 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:57:19 --> Utf8 Class Initialized
DEBUG - 2018-02-11 20:57:19 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:57:19 --> Utf8 Class Initialized
DEBUG - 2018-02-11 20:57:19 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:57:19 --> URI Class Initialized
INFO - 2018-02-11 20:57:19 --> URI Class Initialized
INFO - 2018-02-11 20:57:19 --> Utf8 Class Initialized
INFO - 2018-02-11 20:57:19 --> URI Class Initialized
INFO - 2018-02-11 20:57:19 --> Router Class Initialized
INFO - 2018-02-11 20:57:19 --> Router Class Initialized
INFO - 2018-02-11 20:57:19 --> Router Class Initialized
INFO - 2018-02-11 20:57:19 --> Output Class Initialized
INFO - 2018-02-11 20:57:19 --> Output Class Initialized
INFO - 2018-02-11 20:57:19 --> Output Class Initialized
INFO - 2018-02-11 20:57:19 --> Security Class Initialized
INFO - 2018-02-11 20:57:19 --> Security Class Initialized
INFO - 2018-02-11 20:57:19 --> Security Class Initialized
DEBUG - 2018-02-11 20:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:57:19 --> Input Class Initialized
DEBUG - 2018-02-11 20:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:57:19 --> Input Class Initialized
DEBUG - 2018-02-11 20:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:57:19 --> Language Class Initialized
INFO - 2018-02-11 20:57:19 --> Input Class Initialized
INFO - 2018-02-11 20:57:19 --> Language Class Initialized
INFO - 2018-02-11 20:57:19 --> Language Class Initialized
ERROR - 2018-02-11 20:57:19 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-11 20:57:19 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-11 20:57:19 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-11 20:57:19 --> Config Class Initialized
INFO - 2018-02-11 20:57:19 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:57:19 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:57:19 --> Utf8 Class Initialized
INFO - 2018-02-11 20:57:19 --> URI Class Initialized
INFO - 2018-02-11 20:57:19 --> Router Class Initialized
INFO - 2018-02-11 20:57:19 --> Output Class Initialized
INFO - 2018-02-11 20:57:19 --> Security Class Initialized
DEBUG - 2018-02-11 20:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:57:19 --> Input Class Initialized
INFO - 2018-02-11 20:57:19 --> Language Class Initialized
INFO - 2018-02-11 20:57:19 --> Loader Class Initialized
INFO - 2018-02-11 20:57:19 --> Helper loaded: url_helper
INFO - 2018-02-11 20:57:19 --> Helper loaded: form_helper
INFO - 2018-02-11 20:57:19 --> Database Driver Class Initialized
DEBUG - 2018-02-11 20:57:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 20:57:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 20:57:19 --> Form Validation Class Initialized
INFO - 2018-02-11 20:57:19 --> Model Class Initialized
INFO - 2018-02-11 20:57:19 --> Controller Class Initialized
INFO - 2018-02-11 20:57:19 --> Model Class Initialized
INFO - 2018-02-11 20:57:19 --> Model Class Initialized
INFO - 2018-02-11 20:57:19 --> Model Class Initialized
INFO - 2018-02-11 20:57:19 --> Model Class Initialized
INFO - 2018-02-11 20:57:19 --> Model Class Initialized
DEBUG - 2018-02-11 20:57:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 20:57:42 --> Config Class Initialized
INFO - 2018-02-11 20:57:42 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:57:42 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:57:42 --> Utf8 Class Initialized
INFO - 2018-02-11 20:57:42 --> URI Class Initialized
INFO - 2018-02-11 20:57:42 --> Router Class Initialized
INFO - 2018-02-11 20:57:42 --> Output Class Initialized
INFO - 2018-02-11 20:57:42 --> Security Class Initialized
DEBUG - 2018-02-11 20:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:57:42 --> Input Class Initialized
INFO - 2018-02-11 20:57:42 --> Language Class Initialized
INFO - 2018-02-11 20:57:42 --> Loader Class Initialized
INFO - 2018-02-11 20:57:42 --> Helper loaded: url_helper
INFO - 2018-02-11 20:57:42 --> Helper loaded: form_helper
INFO - 2018-02-11 20:57:42 --> Database Driver Class Initialized
DEBUG - 2018-02-11 20:57:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 20:57:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 20:57:42 --> Form Validation Class Initialized
INFO - 2018-02-11 20:57:42 --> Model Class Initialized
INFO - 2018-02-11 20:57:42 --> Controller Class Initialized
INFO - 2018-02-11 20:57:42 --> Model Class Initialized
INFO - 2018-02-11 20:57:42 --> Model Class Initialized
INFO - 2018-02-11 20:57:42 --> Model Class Initialized
INFO - 2018-02-11 20:57:42 --> Model Class Initialized
INFO - 2018-02-11 20:57:42 --> Model Class Initialized
DEBUG - 2018-02-11 20:57:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 20:57:42 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-11 20:57:42 --> Final output sent to browser
DEBUG - 2018-02-11 20:57:42 --> Total execution time: 0.0632
INFO - 2018-02-11 20:57:43 --> Config Class Initialized
INFO - 2018-02-11 20:57:43 --> Config Class Initialized
INFO - 2018-02-11 20:57:43 --> Hooks Class Initialized
INFO - 2018-02-11 20:57:43 --> Hooks Class Initialized
INFO - 2018-02-11 20:57:43 --> Config Class Initialized
INFO - 2018-02-11 20:57:43 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:57:43 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:57:43 --> Utf8 Class Initialized
DEBUG - 2018-02-11 20:57:43 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:57:43 --> Utf8 Class Initialized
DEBUG - 2018-02-11 20:57:43 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:57:43 --> URI Class Initialized
INFO - 2018-02-11 20:57:43 --> Utf8 Class Initialized
INFO - 2018-02-11 20:57:43 --> URI Class Initialized
INFO - 2018-02-11 20:57:43 --> URI Class Initialized
INFO - 2018-02-11 20:57:43 --> Router Class Initialized
INFO - 2018-02-11 20:57:43 --> Router Class Initialized
INFO - 2018-02-11 20:57:43 --> Output Class Initialized
INFO - 2018-02-11 20:57:43 --> Router Class Initialized
INFO - 2018-02-11 20:57:43 --> Output Class Initialized
INFO - 2018-02-11 20:57:43 --> Output Class Initialized
INFO - 2018-02-11 20:57:43 --> Security Class Initialized
INFO - 2018-02-11 20:57:43 --> Security Class Initialized
DEBUG - 2018-02-11 20:57:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:57:43 --> Security Class Initialized
INFO - 2018-02-11 20:57:43 --> Input Class Initialized
DEBUG - 2018-02-11 20:57:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:57:43 --> Language Class Initialized
INFO - 2018-02-11 20:57:43 --> Input Class Initialized
DEBUG - 2018-02-11 20:57:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:57:43 --> Input Class Initialized
INFO - 2018-02-11 20:57:43 --> Language Class Initialized
INFO - 2018-02-11 20:57:43 --> Language Class Initialized
ERROR - 2018-02-11 20:57:43 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-11 20:57:43 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-11 20:57:43 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-11 20:57:43 --> Config Class Initialized
INFO - 2018-02-11 20:57:43 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:57:43 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:57:43 --> Utf8 Class Initialized
INFO - 2018-02-11 20:57:43 --> URI Class Initialized
INFO - 2018-02-11 20:57:43 --> Router Class Initialized
INFO - 2018-02-11 20:57:43 --> Output Class Initialized
INFO - 2018-02-11 20:57:43 --> Security Class Initialized
DEBUG - 2018-02-11 20:57:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:57:43 --> Input Class Initialized
INFO - 2018-02-11 20:57:43 --> Language Class Initialized
ERROR - 2018-02-11 20:57:43 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-11 20:57:43 --> Config Class Initialized
INFO - 2018-02-11 20:57:43 --> Hooks Class Initialized
INFO - 2018-02-11 20:57:43 --> Config Class Initialized
INFO - 2018-02-11 20:57:43 --> Hooks Class Initialized
INFO - 2018-02-11 20:57:43 --> Config Class Initialized
INFO - 2018-02-11 20:57:43 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:57:43 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:57:43 --> Utf8 Class Initialized
DEBUG - 2018-02-11 20:57:43 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:57:43 --> Utf8 Class Initialized
INFO - 2018-02-11 20:57:43 --> URI Class Initialized
INFO - 2018-02-11 20:57:43 --> URI Class Initialized
DEBUG - 2018-02-11 20:57:43 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:57:43 --> Router Class Initialized
INFO - 2018-02-11 20:57:43 --> Utf8 Class Initialized
INFO - 2018-02-11 20:57:43 --> Router Class Initialized
INFO - 2018-02-11 20:57:43 --> URI Class Initialized
INFO - 2018-02-11 20:57:43 --> Output Class Initialized
INFO - 2018-02-11 20:57:43 --> Router Class Initialized
INFO - 2018-02-11 20:57:43 --> Output Class Initialized
INFO - 2018-02-11 20:57:43 --> Security Class Initialized
INFO - 2018-02-11 20:57:43 --> Security Class Initialized
DEBUG - 2018-02-11 20:57:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:57:43 --> Output Class Initialized
INFO - 2018-02-11 20:57:43 --> Input Class Initialized
INFO - 2018-02-11 20:57:43 --> Language Class Initialized
DEBUG - 2018-02-11 20:57:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:57:43 --> Input Class Initialized
INFO - 2018-02-11 20:57:43 --> Security Class Initialized
INFO - 2018-02-11 20:57:43 --> Language Class Initialized
ERROR - 2018-02-11 20:57:43 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-02-11 20:57:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:57:43 --> Input Class Initialized
ERROR - 2018-02-11 20:57:43 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-11 20:57:43 --> Language Class Initialized
ERROR - 2018-02-11 20:57:43 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-11 20:57:43 --> Config Class Initialized
INFO - 2018-02-11 20:57:43 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:57:43 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:57:43 --> Utf8 Class Initialized
INFO - 2018-02-11 20:57:43 --> URI Class Initialized
INFO - 2018-02-11 20:57:43 --> Router Class Initialized
INFO - 2018-02-11 20:57:43 --> Output Class Initialized
INFO - 2018-02-11 20:57:43 --> Security Class Initialized
DEBUG - 2018-02-11 20:57:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:57:43 --> Input Class Initialized
INFO - 2018-02-11 20:57:43 --> Language Class Initialized
INFO - 2018-02-11 20:57:43 --> Loader Class Initialized
INFO - 2018-02-11 20:57:43 --> Helper loaded: url_helper
INFO - 2018-02-11 20:57:43 --> Helper loaded: form_helper
INFO - 2018-02-11 20:57:43 --> Database Driver Class Initialized
DEBUG - 2018-02-11 20:57:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 20:57:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 20:57:43 --> Form Validation Class Initialized
INFO - 2018-02-11 20:57:43 --> Model Class Initialized
INFO - 2018-02-11 20:57:43 --> Controller Class Initialized
INFO - 2018-02-11 20:57:43 --> Model Class Initialized
INFO - 2018-02-11 20:57:43 --> Model Class Initialized
INFO - 2018-02-11 20:57:43 --> Model Class Initialized
INFO - 2018-02-11 20:57:43 --> Model Class Initialized
INFO - 2018-02-11 20:57:43 --> Model Class Initialized
DEBUG - 2018-02-11 20:57:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 20:57:48 --> Config Class Initialized
INFO - 2018-02-11 20:57:48 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:57:48 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:57:48 --> Utf8 Class Initialized
INFO - 2018-02-11 20:57:48 --> URI Class Initialized
INFO - 2018-02-11 20:57:48 --> Router Class Initialized
INFO - 2018-02-11 20:57:48 --> Output Class Initialized
INFO - 2018-02-11 20:57:48 --> Security Class Initialized
DEBUG - 2018-02-11 20:57:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:57:48 --> Input Class Initialized
INFO - 2018-02-11 20:57:48 --> Language Class Initialized
INFO - 2018-02-11 20:57:48 --> Loader Class Initialized
INFO - 2018-02-11 20:57:48 --> Helper loaded: url_helper
INFO - 2018-02-11 20:57:48 --> Helper loaded: form_helper
INFO - 2018-02-11 20:57:48 --> Database Driver Class Initialized
DEBUG - 2018-02-11 20:57:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 20:57:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 20:57:48 --> Form Validation Class Initialized
INFO - 2018-02-11 20:57:48 --> Model Class Initialized
INFO - 2018-02-11 20:57:48 --> Controller Class Initialized
INFO - 2018-02-11 20:57:48 --> Model Class Initialized
INFO - 2018-02-11 20:57:48 --> Model Class Initialized
INFO - 2018-02-11 20:57:48 --> Model Class Initialized
INFO - 2018-02-11 20:57:48 --> Model Class Initialized
INFO - 2018-02-11 20:57:48 --> Model Class Initialized
DEBUG - 2018-02-11 20:57:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 20:57:48 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-11 20:57:48 --> Final output sent to browser
DEBUG - 2018-02-11 20:57:48 --> Total execution time: 0.0559
INFO - 2018-02-11 20:57:48 --> Config Class Initialized
INFO - 2018-02-11 20:57:48 --> Hooks Class Initialized
INFO - 2018-02-11 20:57:48 --> Config Class Initialized
INFO - 2018-02-11 20:57:48 --> Config Class Initialized
INFO - 2018-02-11 20:57:48 --> Hooks Class Initialized
INFO - 2018-02-11 20:57:48 --> Hooks Class Initialized
INFO - 2018-02-11 20:57:48 --> Config Class Initialized
INFO - 2018-02-11 20:57:48 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:57:48 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:57:48 --> Utf8 Class Initialized
DEBUG - 2018-02-11 20:57:48 --> UTF-8 Support Enabled
DEBUG - 2018-02-11 20:57:48 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:57:48 --> URI Class Initialized
INFO - 2018-02-11 20:57:48 --> Utf8 Class Initialized
INFO - 2018-02-11 20:57:48 --> Utf8 Class Initialized
DEBUG - 2018-02-11 20:57:48 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:57:48 --> Utf8 Class Initialized
INFO - 2018-02-11 20:57:48 --> URI Class Initialized
INFO - 2018-02-11 20:57:48 --> URI Class Initialized
INFO - 2018-02-11 20:57:48 --> Router Class Initialized
INFO - 2018-02-11 20:57:48 --> URI Class Initialized
INFO - 2018-02-11 20:57:48 --> Router Class Initialized
INFO - 2018-02-11 20:57:48 --> Router Class Initialized
INFO - 2018-02-11 20:57:48 --> Output Class Initialized
INFO - 2018-02-11 20:57:48 --> Router Class Initialized
INFO - 2018-02-11 20:57:48 --> Output Class Initialized
INFO - 2018-02-11 20:57:48 --> Security Class Initialized
INFO - 2018-02-11 20:57:48 --> Output Class Initialized
INFO - 2018-02-11 20:57:48 --> Output Class Initialized
DEBUG - 2018-02-11 20:57:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:57:48 --> Security Class Initialized
INFO - 2018-02-11 20:57:48 --> Input Class Initialized
INFO - 2018-02-11 20:57:48 --> Security Class Initialized
INFO - 2018-02-11 20:57:48 --> Security Class Initialized
INFO - 2018-02-11 20:57:48 --> Language Class Initialized
DEBUG - 2018-02-11 20:57:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:57:48 --> Input Class Initialized
DEBUG - 2018-02-11 20:57:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-11 20:57:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-11 20:57:48 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-11 20:57:48 --> Input Class Initialized
INFO - 2018-02-11 20:57:48 --> Input Class Initialized
INFO - 2018-02-11 20:57:48 --> Language Class Initialized
INFO - 2018-02-11 20:57:48 --> Language Class Initialized
INFO - 2018-02-11 20:57:48 --> Language Class Initialized
ERROR - 2018-02-11 20:57:48 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-11 20:57:48 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-11 20:57:48 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-11 20:57:48 --> Config Class Initialized
INFO - 2018-02-11 20:57:48 --> Hooks Class Initialized
INFO - 2018-02-11 20:57:48 --> Config Class Initialized
INFO - 2018-02-11 20:57:48 --> Config Class Initialized
INFO - 2018-02-11 20:57:48 --> Hooks Class Initialized
INFO - 2018-02-11 20:57:48 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:57:48 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:57:48 --> Utf8 Class Initialized
DEBUG - 2018-02-11 20:57:48 --> UTF-8 Support Enabled
DEBUG - 2018-02-11 20:57:48 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:57:48 --> URI Class Initialized
INFO - 2018-02-11 20:57:48 --> Utf8 Class Initialized
INFO - 2018-02-11 20:57:48 --> Utf8 Class Initialized
INFO - 2018-02-11 20:57:48 --> URI Class Initialized
INFO - 2018-02-11 20:57:48 --> URI Class Initialized
INFO - 2018-02-11 20:57:48 --> Router Class Initialized
INFO - 2018-02-11 20:57:48 --> Router Class Initialized
INFO - 2018-02-11 20:57:48 --> Router Class Initialized
INFO - 2018-02-11 20:57:48 --> Output Class Initialized
INFO - 2018-02-11 20:57:48 --> Output Class Initialized
INFO - 2018-02-11 20:57:48 --> Output Class Initialized
INFO - 2018-02-11 20:57:48 --> Security Class Initialized
INFO - 2018-02-11 20:57:48 --> Security Class Initialized
INFO - 2018-02-11 20:57:48 --> Security Class Initialized
DEBUG - 2018-02-11 20:57:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:57:48 --> Input Class Initialized
DEBUG - 2018-02-11 20:57:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:57:48 --> Input Class Initialized
INFO - 2018-02-11 20:57:48 --> Language Class Initialized
DEBUG - 2018-02-11 20:57:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:57:48 --> Input Class Initialized
INFO - 2018-02-11 20:57:48 --> Language Class Initialized
INFO - 2018-02-11 20:57:48 --> Language Class Initialized
ERROR - 2018-02-11 20:57:48 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-11 20:57:48 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-11 20:57:48 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-11 20:57:48 --> Config Class Initialized
INFO - 2018-02-11 20:57:48 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:57:48 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:57:48 --> Utf8 Class Initialized
INFO - 2018-02-11 20:57:48 --> URI Class Initialized
INFO - 2018-02-11 20:57:48 --> Router Class Initialized
INFO - 2018-02-11 20:57:48 --> Output Class Initialized
INFO - 2018-02-11 20:57:48 --> Security Class Initialized
DEBUG - 2018-02-11 20:57:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:57:48 --> Input Class Initialized
INFO - 2018-02-11 20:57:48 --> Language Class Initialized
INFO - 2018-02-11 20:57:48 --> Loader Class Initialized
INFO - 2018-02-11 20:57:48 --> Helper loaded: url_helper
INFO - 2018-02-11 20:57:48 --> Helper loaded: form_helper
INFO - 2018-02-11 20:57:48 --> Database Driver Class Initialized
DEBUG - 2018-02-11 20:57:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 20:57:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 20:57:48 --> Form Validation Class Initialized
INFO - 2018-02-11 20:57:48 --> Model Class Initialized
INFO - 2018-02-11 20:57:48 --> Controller Class Initialized
INFO - 2018-02-11 20:57:48 --> Model Class Initialized
INFO - 2018-02-11 20:57:48 --> Model Class Initialized
INFO - 2018-02-11 20:57:48 --> Model Class Initialized
INFO - 2018-02-11 20:57:48 --> Model Class Initialized
INFO - 2018-02-11 20:57:48 --> Model Class Initialized
DEBUG - 2018-02-11 20:57:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 20:59:42 --> Config Class Initialized
INFO - 2018-02-11 20:59:42 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:59:42 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:59:42 --> Utf8 Class Initialized
INFO - 2018-02-11 20:59:42 --> URI Class Initialized
INFO - 2018-02-11 20:59:42 --> Router Class Initialized
INFO - 2018-02-11 20:59:42 --> Output Class Initialized
INFO - 2018-02-11 20:59:42 --> Security Class Initialized
DEBUG - 2018-02-11 20:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:59:42 --> Input Class Initialized
INFO - 2018-02-11 20:59:42 --> Language Class Initialized
INFO - 2018-02-11 20:59:42 --> Loader Class Initialized
INFO - 2018-02-11 20:59:42 --> Helper loaded: url_helper
INFO - 2018-02-11 20:59:42 --> Helper loaded: form_helper
INFO - 2018-02-11 20:59:42 --> Database Driver Class Initialized
DEBUG - 2018-02-11 20:59:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 20:59:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 20:59:42 --> Form Validation Class Initialized
INFO - 2018-02-11 20:59:42 --> Model Class Initialized
INFO - 2018-02-11 20:59:42 --> Controller Class Initialized
INFO - 2018-02-11 20:59:42 --> Model Class Initialized
INFO - 2018-02-11 20:59:42 --> Model Class Initialized
INFO - 2018-02-11 20:59:42 --> Model Class Initialized
INFO - 2018-02-11 20:59:42 --> Model Class Initialized
INFO - 2018-02-11 20:59:42 --> Model Class Initialized
DEBUG - 2018-02-11 20:59:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 20:59:42 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-11 20:59:42 --> Final output sent to browser
DEBUG - 2018-02-11 20:59:42 --> Total execution time: 0.0675
INFO - 2018-02-11 20:59:42 --> Config Class Initialized
INFO - 2018-02-11 20:59:42 --> Config Class Initialized
INFO - 2018-02-11 20:59:42 --> Config Class Initialized
INFO - 2018-02-11 20:59:42 --> Hooks Class Initialized
INFO - 2018-02-11 20:59:42 --> Hooks Class Initialized
INFO - 2018-02-11 20:59:42 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:59:42 --> UTF-8 Support Enabled
DEBUG - 2018-02-11 20:59:42 --> UTF-8 Support Enabled
DEBUG - 2018-02-11 20:59:42 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:59:42 --> Utf8 Class Initialized
INFO - 2018-02-11 20:59:42 --> Utf8 Class Initialized
INFO - 2018-02-11 20:59:42 --> Utf8 Class Initialized
INFO - 2018-02-11 20:59:42 --> URI Class Initialized
INFO - 2018-02-11 20:59:42 --> URI Class Initialized
INFO - 2018-02-11 20:59:42 --> URI Class Initialized
INFO - 2018-02-11 20:59:42 --> Router Class Initialized
INFO - 2018-02-11 20:59:42 --> Router Class Initialized
INFO - 2018-02-11 20:59:42 --> Router Class Initialized
INFO - 2018-02-11 20:59:42 --> Output Class Initialized
INFO - 2018-02-11 20:59:42 --> Output Class Initialized
INFO - 2018-02-11 20:59:42 --> Security Class Initialized
INFO - 2018-02-11 20:59:42 --> Output Class Initialized
INFO - 2018-02-11 20:59:42 --> Security Class Initialized
DEBUG - 2018-02-11 20:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:59:42 --> Input Class Initialized
INFO - 2018-02-11 20:59:42 --> Security Class Initialized
DEBUG - 2018-02-11 20:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:59:42 --> Input Class Initialized
INFO - 2018-02-11 20:59:42 --> Language Class Initialized
INFO - 2018-02-11 20:59:42 --> Language Class Initialized
DEBUG - 2018-02-11 20:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:59:42 --> Input Class Initialized
ERROR - 2018-02-11 20:59:42 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-11 20:59:42 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-11 20:59:42 --> Language Class Initialized
ERROR - 2018-02-11 20:59:42 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-11 20:59:42 --> Config Class Initialized
INFO - 2018-02-11 20:59:42 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:59:42 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:59:42 --> Utf8 Class Initialized
INFO - 2018-02-11 20:59:42 --> URI Class Initialized
INFO - 2018-02-11 20:59:42 --> Router Class Initialized
INFO - 2018-02-11 20:59:42 --> Output Class Initialized
INFO - 2018-02-11 20:59:42 --> Security Class Initialized
DEBUG - 2018-02-11 20:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:59:42 --> Input Class Initialized
INFO - 2018-02-11 20:59:42 --> Language Class Initialized
ERROR - 2018-02-11 20:59:42 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-11 20:59:42 --> Config Class Initialized
INFO - 2018-02-11 20:59:42 --> Hooks Class Initialized
INFO - 2018-02-11 20:59:42 --> Config Class Initialized
INFO - 2018-02-11 20:59:42 --> Hooks Class Initialized
INFO - 2018-02-11 20:59:42 --> Config Class Initialized
INFO - 2018-02-11 20:59:42 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:59:42 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:59:42 --> Utf8 Class Initialized
DEBUG - 2018-02-11 20:59:42 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:59:42 --> Utf8 Class Initialized
INFO - 2018-02-11 20:59:42 --> URI Class Initialized
DEBUG - 2018-02-11 20:59:42 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:59:42 --> Utf8 Class Initialized
INFO - 2018-02-11 20:59:42 --> URI Class Initialized
INFO - 2018-02-11 20:59:42 --> URI Class Initialized
INFO - 2018-02-11 20:59:42 --> Router Class Initialized
INFO - 2018-02-11 20:59:42 --> Router Class Initialized
INFO - 2018-02-11 20:59:42 --> Router Class Initialized
INFO - 2018-02-11 20:59:42 --> Output Class Initialized
INFO - 2018-02-11 20:59:42 --> Output Class Initialized
INFO - 2018-02-11 20:59:42 --> Output Class Initialized
INFO - 2018-02-11 20:59:42 --> Security Class Initialized
INFO - 2018-02-11 20:59:42 --> Security Class Initialized
INFO - 2018-02-11 20:59:42 --> Security Class Initialized
DEBUG - 2018-02-11 20:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:59:42 --> Input Class Initialized
DEBUG - 2018-02-11 20:59:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-11 20:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:59:42 --> Input Class Initialized
INFO - 2018-02-11 20:59:42 --> Input Class Initialized
INFO - 2018-02-11 20:59:42 --> Language Class Initialized
INFO - 2018-02-11 20:59:42 --> Language Class Initialized
INFO - 2018-02-11 20:59:42 --> Language Class Initialized
ERROR - 2018-02-11 20:59:42 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-11 20:59:42 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-11 20:59:42 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-11 20:59:42 --> Config Class Initialized
INFO - 2018-02-11 20:59:42 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:59:42 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:59:42 --> Utf8 Class Initialized
INFO - 2018-02-11 20:59:42 --> URI Class Initialized
INFO - 2018-02-11 20:59:42 --> Router Class Initialized
INFO - 2018-02-11 20:59:42 --> Output Class Initialized
INFO - 2018-02-11 20:59:42 --> Security Class Initialized
DEBUG - 2018-02-11 20:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:59:42 --> Input Class Initialized
INFO - 2018-02-11 20:59:42 --> Language Class Initialized
INFO - 2018-02-11 20:59:42 --> Loader Class Initialized
INFO - 2018-02-11 20:59:42 --> Helper loaded: url_helper
INFO - 2018-02-11 20:59:42 --> Helper loaded: form_helper
INFO - 2018-02-11 20:59:42 --> Database Driver Class Initialized
DEBUG - 2018-02-11 20:59:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 20:59:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 20:59:42 --> Form Validation Class Initialized
INFO - 2018-02-11 20:59:42 --> Model Class Initialized
INFO - 2018-02-11 20:59:42 --> Controller Class Initialized
INFO - 2018-02-11 20:59:42 --> Model Class Initialized
INFO - 2018-02-11 20:59:42 --> Model Class Initialized
INFO - 2018-02-11 20:59:42 --> Model Class Initialized
INFO - 2018-02-11 20:59:42 --> Model Class Initialized
INFO - 2018-02-11 20:59:42 --> Model Class Initialized
DEBUG - 2018-02-11 20:59:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 20:59:42 --> Config Class Initialized
INFO - 2018-02-11 20:59:42 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:59:42 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:59:42 --> Utf8 Class Initialized
INFO - 2018-02-11 20:59:42 --> URI Class Initialized
INFO - 2018-02-11 20:59:42 --> Router Class Initialized
INFO - 2018-02-11 20:59:42 --> Output Class Initialized
INFO - 2018-02-11 20:59:42 --> Security Class Initialized
DEBUG - 2018-02-11 20:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:59:42 --> Input Class Initialized
INFO - 2018-02-11 20:59:42 --> Language Class Initialized
INFO - 2018-02-11 20:59:42 --> Loader Class Initialized
INFO - 2018-02-11 20:59:42 --> Helper loaded: url_helper
INFO - 2018-02-11 20:59:42 --> Helper loaded: form_helper
INFO - 2018-02-11 20:59:42 --> Database Driver Class Initialized
DEBUG - 2018-02-11 20:59:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 20:59:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 20:59:42 --> Form Validation Class Initialized
INFO - 2018-02-11 20:59:42 --> Model Class Initialized
INFO - 2018-02-11 20:59:42 --> Controller Class Initialized
INFO - 2018-02-11 20:59:42 --> Model Class Initialized
INFO - 2018-02-11 20:59:42 --> Model Class Initialized
INFO - 2018-02-11 20:59:42 --> Model Class Initialized
INFO - 2018-02-11 20:59:42 --> Model Class Initialized
INFO - 2018-02-11 20:59:42 --> Model Class Initialized
DEBUG - 2018-02-11 20:59:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 20:59:42 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-11 20:59:42 --> Final output sent to browser
DEBUG - 2018-02-11 20:59:42 --> Total execution time: 0.0768
INFO - 2018-02-11 20:59:42 --> Config Class Initialized
INFO - 2018-02-11 20:59:42 --> Hooks Class Initialized
INFO - 2018-02-11 20:59:42 --> Config Class Initialized
INFO - 2018-02-11 20:59:42 --> Hooks Class Initialized
INFO - 2018-02-11 20:59:42 --> Config Class Initialized
INFO - 2018-02-11 20:59:42 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:59:42 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:59:42 --> Config Class Initialized
INFO - 2018-02-11 20:59:42 --> Utf8 Class Initialized
INFO - 2018-02-11 20:59:42 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:59:42 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:59:42 --> Utf8 Class Initialized
DEBUG - 2018-02-11 20:59:42 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:59:42 --> URI Class Initialized
INFO - 2018-02-11 20:59:42 --> Utf8 Class Initialized
INFO - 2018-02-11 20:59:42 --> URI Class Initialized
INFO - 2018-02-11 20:59:42 --> URI Class Initialized
INFO - 2018-02-11 20:59:42 --> Router Class Initialized
DEBUG - 2018-02-11 20:59:42 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:59:42 --> Utf8 Class Initialized
INFO - 2018-02-11 20:59:42 --> Router Class Initialized
INFO - 2018-02-11 20:59:42 --> Router Class Initialized
INFO - 2018-02-11 20:59:42 --> URI Class Initialized
INFO - 2018-02-11 20:59:42 --> Output Class Initialized
INFO - 2018-02-11 20:59:42 --> Output Class Initialized
INFO - 2018-02-11 20:59:42 --> Output Class Initialized
INFO - 2018-02-11 20:59:43 --> Router Class Initialized
INFO - 2018-02-11 20:59:43 --> Security Class Initialized
INFO - 2018-02-11 20:59:43 --> Security Class Initialized
INFO - 2018-02-11 20:59:43 --> Security Class Initialized
INFO - 2018-02-11 20:59:43 --> Output Class Initialized
DEBUG - 2018-02-11 20:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:59:43 --> Input Class Initialized
DEBUG - 2018-02-11 20:59:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-11 20:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:59:43 --> Input Class Initialized
INFO - 2018-02-11 20:59:43 --> Input Class Initialized
INFO - 2018-02-11 20:59:43 --> Security Class Initialized
INFO - 2018-02-11 20:59:43 --> Language Class Initialized
INFO - 2018-02-11 20:59:43 --> Language Class Initialized
DEBUG - 2018-02-11 20:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:59:43 --> Input Class Initialized
ERROR - 2018-02-11 20:59:43 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-11 20:59:43 --> Language Class Initialized
ERROR - 2018-02-11 20:59:43 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-11 20:59:43 --> Language Class Initialized
ERROR - 2018-02-11 20:59:43 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-11 20:59:43 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-11 20:59:43 --> Config Class Initialized
INFO - 2018-02-11 20:59:43 --> Config Class Initialized
INFO - 2018-02-11 20:59:43 --> Hooks Class Initialized
INFO - 2018-02-11 20:59:43 --> Hooks Class Initialized
INFO - 2018-02-11 20:59:43 --> Config Class Initialized
INFO - 2018-02-11 20:59:43 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:59:43 --> UTF-8 Support Enabled
DEBUG - 2018-02-11 20:59:43 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:59:43 --> Utf8 Class Initialized
INFO - 2018-02-11 20:59:43 --> Utf8 Class Initialized
DEBUG - 2018-02-11 20:59:43 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:59:43 --> Utf8 Class Initialized
INFO - 2018-02-11 20:59:43 --> URI Class Initialized
INFO - 2018-02-11 20:59:43 --> URI Class Initialized
INFO - 2018-02-11 20:59:43 --> URI Class Initialized
INFO - 2018-02-11 20:59:43 --> Router Class Initialized
INFO - 2018-02-11 20:59:43 --> Router Class Initialized
INFO - 2018-02-11 20:59:43 --> Router Class Initialized
INFO - 2018-02-11 20:59:43 --> Output Class Initialized
INFO - 2018-02-11 20:59:43 --> Output Class Initialized
INFO - 2018-02-11 20:59:43 --> Output Class Initialized
INFO - 2018-02-11 20:59:43 --> Security Class Initialized
INFO - 2018-02-11 20:59:43 --> Security Class Initialized
INFO - 2018-02-11 20:59:43 --> Security Class Initialized
DEBUG - 2018-02-11 20:59:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-11 20:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:59:43 --> Input Class Initialized
INFO - 2018-02-11 20:59:43 --> Input Class Initialized
DEBUG - 2018-02-11 20:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:59:43 --> Input Class Initialized
INFO - 2018-02-11 20:59:43 --> Language Class Initialized
INFO - 2018-02-11 20:59:43 --> Language Class Initialized
INFO - 2018-02-11 20:59:43 --> Language Class Initialized
ERROR - 2018-02-11 20:59:43 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-11 20:59:43 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-11 20:59:43 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-11 20:59:43 --> Config Class Initialized
INFO - 2018-02-11 20:59:43 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:59:43 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:59:43 --> Utf8 Class Initialized
INFO - 2018-02-11 20:59:43 --> URI Class Initialized
INFO - 2018-02-11 20:59:43 --> Router Class Initialized
INFO - 2018-02-11 20:59:43 --> Output Class Initialized
INFO - 2018-02-11 20:59:43 --> Security Class Initialized
DEBUG - 2018-02-11 20:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:59:43 --> Input Class Initialized
INFO - 2018-02-11 20:59:43 --> Language Class Initialized
INFO - 2018-02-11 20:59:43 --> Loader Class Initialized
INFO - 2018-02-11 20:59:43 --> Helper loaded: url_helper
INFO - 2018-02-11 20:59:43 --> Helper loaded: form_helper
INFO - 2018-02-11 20:59:43 --> Database Driver Class Initialized
DEBUG - 2018-02-11 20:59:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 20:59:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 20:59:43 --> Form Validation Class Initialized
INFO - 2018-02-11 20:59:43 --> Config Class Initialized
INFO - 2018-02-11 20:59:43 --> Hooks Class Initialized
INFO - 2018-02-11 20:59:43 --> Model Class Initialized
INFO - 2018-02-11 20:59:43 --> Controller Class Initialized
DEBUG - 2018-02-11 20:59:43 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:59:43 --> Utf8 Class Initialized
INFO - 2018-02-11 20:59:43 --> Model Class Initialized
INFO - 2018-02-11 20:59:43 --> Model Class Initialized
INFO - 2018-02-11 20:59:43 --> URI Class Initialized
INFO - 2018-02-11 20:59:43 --> Model Class Initialized
INFO - 2018-02-11 20:59:43 --> Model Class Initialized
INFO - 2018-02-11 20:59:43 --> Router Class Initialized
INFO - 2018-02-11 20:59:43 --> Model Class Initialized
DEBUG - 2018-02-11 20:59:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 20:59:43 --> Output Class Initialized
INFO - 2018-02-11 20:59:43 --> Security Class Initialized
DEBUG - 2018-02-11 20:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:59:43 --> Input Class Initialized
INFO - 2018-02-11 20:59:43 --> Language Class Initialized
INFO - 2018-02-11 20:59:43 --> Loader Class Initialized
INFO - 2018-02-11 20:59:43 --> Helper loaded: url_helper
INFO - 2018-02-11 20:59:43 --> Helper loaded: form_helper
INFO - 2018-02-11 20:59:43 --> Database Driver Class Initialized
DEBUG - 2018-02-11 20:59:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 20:59:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 20:59:43 --> Form Validation Class Initialized
INFO - 2018-02-11 20:59:43 --> Model Class Initialized
INFO - 2018-02-11 20:59:43 --> Controller Class Initialized
INFO - 2018-02-11 20:59:43 --> Model Class Initialized
INFO - 2018-02-11 20:59:43 --> Model Class Initialized
INFO - 2018-02-11 20:59:43 --> Model Class Initialized
INFO - 2018-02-11 20:59:43 --> Model Class Initialized
INFO - 2018-02-11 20:59:43 --> Model Class Initialized
DEBUG - 2018-02-11 20:59:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 20:59:43 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-11 20:59:43 --> Final output sent to browser
DEBUG - 2018-02-11 20:59:43 --> Total execution time: 0.0503
INFO - 2018-02-11 20:59:43 --> Config Class Initialized
INFO - 2018-02-11 20:59:43 --> Hooks Class Initialized
INFO - 2018-02-11 20:59:43 --> Config Class Initialized
INFO - 2018-02-11 20:59:43 --> Hooks Class Initialized
INFO - 2018-02-11 20:59:43 --> Config Class Initialized
INFO - 2018-02-11 20:59:43 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:59:43 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:59:43 --> Utf8 Class Initialized
DEBUG - 2018-02-11 20:59:43 --> UTF-8 Support Enabled
DEBUG - 2018-02-11 20:59:43 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:59:43 --> Utf8 Class Initialized
INFO - 2018-02-11 20:59:43 --> URI Class Initialized
INFO - 2018-02-11 20:59:43 --> Utf8 Class Initialized
INFO - 2018-02-11 20:59:43 --> URI Class Initialized
INFO - 2018-02-11 20:59:43 --> URI Class Initialized
INFO - 2018-02-11 20:59:43 --> Router Class Initialized
INFO - 2018-02-11 20:59:43 --> Router Class Initialized
INFO - 2018-02-11 20:59:43 --> Router Class Initialized
INFO - 2018-02-11 20:59:43 --> Output Class Initialized
INFO - 2018-02-11 20:59:43 --> Output Class Initialized
INFO - 2018-02-11 20:59:43 --> Security Class Initialized
INFO - 2018-02-11 20:59:43 --> Output Class Initialized
INFO - 2018-02-11 20:59:43 --> Security Class Initialized
DEBUG - 2018-02-11 20:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:59:43 --> Input Class Initialized
INFO - 2018-02-11 20:59:43 --> Security Class Initialized
DEBUG - 2018-02-11 20:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:59:43 --> Language Class Initialized
INFO - 2018-02-11 20:59:43 --> Input Class Initialized
INFO - 2018-02-11 20:59:43 --> Language Class Initialized
DEBUG - 2018-02-11 20:59:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-11 20:59:43 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-11 20:59:43 --> Input Class Initialized
ERROR - 2018-02-11 20:59:43 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-11 20:59:43 --> Language Class Initialized
ERROR - 2018-02-11 20:59:43 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-11 20:59:43 --> Config Class Initialized
INFO - 2018-02-11 20:59:43 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:59:43 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:59:43 --> Utf8 Class Initialized
INFO - 2018-02-11 20:59:43 --> URI Class Initialized
INFO - 2018-02-11 20:59:43 --> Router Class Initialized
INFO - 2018-02-11 20:59:43 --> Output Class Initialized
INFO - 2018-02-11 20:59:43 --> Security Class Initialized
DEBUG - 2018-02-11 20:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:59:43 --> Input Class Initialized
INFO - 2018-02-11 20:59:43 --> Language Class Initialized
ERROR - 2018-02-11 20:59:43 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-11 20:59:43 --> Config Class Initialized
INFO - 2018-02-11 20:59:43 --> Hooks Class Initialized
INFO - 2018-02-11 20:59:43 --> Config Class Initialized
INFO - 2018-02-11 20:59:43 --> Hooks Class Initialized
INFO - 2018-02-11 20:59:43 --> Config Class Initialized
INFO - 2018-02-11 20:59:43 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:59:43 --> UTF-8 Support Enabled
DEBUG - 2018-02-11 20:59:43 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:59:43 --> Utf8 Class Initialized
INFO - 2018-02-11 20:59:43 --> Utf8 Class Initialized
DEBUG - 2018-02-11 20:59:43 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:59:43 --> Utf8 Class Initialized
INFO - 2018-02-11 20:59:43 --> URI Class Initialized
INFO - 2018-02-11 20:59:43 --> URI Class Initialized
INFO - 2018-02-11 20:59:43 --> URI Class Initialized
INFO - 2018-02-11 20:59:43 --> Router Class Initialized
INFO - 2018-02-11 20:59:43 --> Router Class Initialized
INFO - 2018-02-11 20:59:43 --> Router Class Initialized
INFO - 2018-02-11 20:59:43 --> Output Class Initialized
INFO - 2018-02-11 20:59:43 --> Output Class Initialized
INFO - 2018-02-11 20:59:43 --> Output Class Initialized
INFO - 2018-02-11 20:59:43 --> Security Class Initialized
INFO - 2018-02-11 20:59:43 --> Security Class Initialized
INFO - 2018-02-11 20:59:43 --> Security Class Initialized
DEBUG - 2018-02-11 20:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:59:43 --> Input Class Initialized
DEBUG - 2018-02-11 20:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:59:43 --> Language Class Initialized
INFO - 2018-02-11 20:59:43 --> Input Class Initialized
DEBUG - 2018-02-11 20:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:59:43 --> Input Class Initialized
INFO - 2018-02-11 20:59:43 --> Language Class Initialized
ERROR - 2018-02-11 20:59:43 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-11 20:59:43 --> Language Class Initialized
ERROR - 2018-02-11 20:59:43 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-11 20:59:43 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-11 20:59:43 --> Config Class Initialized
INFO - 2018-02-11 20:59:43 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:59:43 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:59:43 --> Utf8 Class Initialized
INFO - 2018-02-11 20:59:43 --> URI Class Initialized
INFO - 2018-02-11 20:59:43 --> Router Class Initialized
INFO - 2018-02-11 20:59:43 --> Output Class Initialized
INFO - 2018-02-11 20:59:43 --> Security Class Initialized
DEBUG - 2018-02-11 20:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:59:43 --> Input Class Initialized
INFO - 2018-02-11 20:59:43 --> Language Class Initialized
INFO - 2018-02-11 20:59:43 --> Loader Class Initialized
INFO - 2018-02-11 20:59:43 --> Helper loaded: url_helper
INFO - 2018-02-11 20:59:43 --> Helper loaded: form_helper
INFO - 2018-02-11 20:59:43 --> Database Driver Class Initialized
INFO - 2018-02-11 20:59:43 --> Config Class Initialized
INFO - 2018-02-11 20:59:43 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:59:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 20:59:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-02-11 20:59:43 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:59:43 --> Utf8 Class Initialized
INFO - 2018-02-11 20:59:43 --> Form Validation Class Initialized
INFO - 2018-02-11 20:59:43 --> URI Class Initialized
INFO - 2018-02-11 20:59:43 --> Model Class Initialized
INFO - 2018-02-11 20:59:43 --> Controller Class Initialized
INFO - 2018-02-11 20:59:43 --> Router Class Initialized
INFO - 2018-02-11 20:59:43 --> Model Class Initialized
INFO - 2018-02-11 20:59:43 --> Output Class Initialized
INFO - 2018-02-11 20:59:43 --> Model Class Initialized
INFO - 2018-02-11 20:59:43 --> Model Class Initialized
INFO - 2018-02-11 20:59:43 --> Security Class Initialized
INFO - 2018-02-11 20:59:43 --> Model Class Initialized
DEBUG - 2018-02-11 20:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:59:43 --> Input Class Initialized
INFO - 2018-02-11 20:59:43 --> Model Class Initialized
DEBUG - 2018-02-11 20:59:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 20:59:43 --> Language Class Initialized
INFO - 2018-02-11 20:59:43 --> Loader Class Initialized
INFO - 2018-02-11 20:59:43 --> Helper loaded: url_helper
INFO - 2018-02-11 20:59:43 --> Helper loaded: form_helper
INFO - 2018-02-11 20:59:43 --> Database Driver Class Initialized
DEBUG - 2018-02-11 20:59:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 20:59:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 20:59:43 --> Form Validation Class Initialized
INFO - 2018-02-11 20:59:43 --> Model Class Initialized
INFO - 2018-02-11 20:59:43 --> Controller Class Initialized
INFO - 2018-02-11 20:59:43 --> Model Class Initialized
INFO - 2018-02-11 20:59:43 --> Model Class Initialized
INFO - 2018-02-11 20:59:43 --> Model Class Initialized
INFO - 2018-02-11 20:59:43 --> Model Class Initialized
INFO - 2018-02-11 20:59:43 --> Model Class Initialized
DEBUG - 2018-02-11 20:59:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 20:59:43 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-11 20:59:43 --> Final output sent to browser
DEBUG - 2018-02-11 20:59:43 --> Total execution time: 0.0495
INFO - 2018-02-11 20:59:43 --> Config Class Initialized
INFO - 2018-02-11 20:59:43 --> Hooks Class Initialized
INFO - 2018-02-11 20:59:43 --> Config Class Initialized
INFO - 2018-02-11 20:59:43 --> Config Class Initialized
INFO - 2018-02-11 20:59:43 --> Hooks Class Initialized
INFO - 2018-02-11 20:59:43 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:59:43 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:59:43 --> Utf8 Class Initialized
DEBUG - 2018-02-11 20:59:43 --> UTF-8 Support Enabled
DEBUG - 2018-02-11 20:59:43 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:59:43 --> Utf8 Class Initialized
INFO - 2018-02-11 20:59:43 --> Utf8 Class Initialized
INFO - 2018-02-11 20:59:43 --> URI Class Initialized
INFO - 2018-02-11 20:59:43 --> URI Class Initialized
INFO - 2018-02-11 20:59:43 --> URI Class Initialized
INFO - 2018-02-11 20:59:43 --> Router Class Initialized
INFO - 2018-02-11 20:59:43 --> Router Class Initialized
INFO - 2018-02-11 20:59:43 --> Router Class Initialized
INFO - 2018-02-11 20:59:43 --> Output Class Initialized
INFO - 2018-02-11 20:59:43 --> Output Class Initialized
INFO - 2018-02-11 20:59:43 --> Output Class Initialized
INFO - 2018-02-11 20:59:43 --> Security Class Initialized
INFO - 2018-02-11 20:59:43 --> Security Class Initialized
INFO - 2018-02-11 20:59:43 --> Security Class Initialized
DEBUG - 2018-02-11 20:59:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-11 20:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:59:43 --> Input Class Initialized
DEBUG - 2018-02-11 20:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:59:43 --> Input Class Initialized
INFO - 2018-02-11 20:59:43 --> Input Class Initialized
INFO - 2018-02-11 20:59:43 --> Language Class Initialized
INFO - 2018-02-11 20:59:43 --> Language Class Initialized
INFO - 2018-02-11 20:59:43 --> Language Class Initialized
ERROR - 2018-02-11 20:59:43 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-11 20:59:43 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-11 20:59:43 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-11 20:59:43 --> Config Class Initialized
INFO - 2018-02-11 20:59:43 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:59:43 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:59:43 --> Utf8 Class Initialized
INFO - 2018-02-11 20:59:43 --> URI Class Initialized
INFO - 2018-02-11 20:59:43 --> Router Class Initialized
INFO - 2018-02-11 20:59:43 --> Output Class Initialized
INFO - 2018-02-11 20:59:43 --> Security Class Initialized
DEBUG - 2018-02-11 20:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:59:43 --> Input Class Initialized
INFO - 2018-02-11 20:59:43 --> Language Class Initialized
ERROR - 2018-02-11 20:59:43 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-11 20:59:43 --> Config Class Initialized
INFO - 2018-02-11 20:59:43 --> Hooks Class Initialized
INFO - 2018-02-11 20:59:43 --> Config Class Initialized
INFO - 2018-02-11 20:59:43 --> Hooks Class Initialized
INFO - 2018-02-11 20:59:43 --> Config Class Initialized
INFO - 2018-02-11 20:59:43 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:59:43 --> UTF-8 Support Enabled
DEBUG - 2018-02-11 20:59:43 --> UTF-8 Support Enabled
DEBUG - 2018-02-11 20:59:43 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:59:43 --> Utf8 Class Initialized
INFO - 2018-02-11 20:59:43 --> Utf8 Class Initialized
INFO - 2018-02-11 20:59:43 --> Utf8 Class Initialized
INFO - 2018-02-11 20:59:43 --> URI Class Initialized
INFO - 2018-02-11 20:59:43 --> URI Class Initialized
INFO - 2018-02-11 20:59:43 --> URI Class Initialized
INFO - 2018-02-11 20:59:43 --> Router Class Initialized
INFO - 2018-02-11 20:59:43 --> Router Class Initialized
INFO - 2018-02-11 20:59:43 --> Router Class Initialized
INFO - 2018-02-11 20:59:43 --> Output Class Initialized
INFO - 2018-02-11 20:59:43 --> Output Class Initialized
INFO - 2018-02-11 20:59:43 --> Output Class Initialized
INFO - 2018-02-11 20:59:43 --> Security Class Initialized
INFO - 2018-02-11 20:59:43 --> Security Class Initialized
INFO - 2018-02-11 20:59:43 --> Security Class Initialized
DEBUG - 2018-02-11 20:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:59:43 --> Input Class Initialized
DEBUG - 2018-02-11 20:59:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-11 20:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:59:43 --> Input Class Initialized
INFO - 2018-02-11 20:59:43 --> Input Class Initialized
INFO - 2018-02-11 20:59:43 --> Language Class Initialized
INFO - 2018-02-11 20:59:43 --> Language Class Initialized
INFO - 2018-02-11 20:59:43 --> Language Class Initialized
ERROR - 2018-02-11 20:59:43 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-11 20:59:43 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-11 20:59:43 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-11 20:59:43 --> Config Class Initialized
INFO - 2018-02-11 20:59:43 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:59:43 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:59:43 --> Utf8 Class Initialized
INFO - 2018-02-11 20:59:43 --> URI Class Initialized
INFO - 2018-02-11 20:59:43 --> Router Class Initialized
INFO - 2018-02-11 20:59:43 --> Output Class Initialized
INFO - 2018-02-11 20:59:43 --> Security Class Initialized
DEBUG - 2018-02-11 20:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:59:43 --> Input Class Initialized
INFO - 2018-02-11 20:59:43 --> Language Class Initialized
INFO - 2018-02-11 20:59:43 --> Loader Class Initialized
INFO - 2018-02-11 20:59:43 --> Helper loaded: url_helper
INFO - 2018-02-11 20:59:43 --> Helper loaded: form_helper
INFO - 2018-02-11 20:59:43 --> Database Driver Class Initialized
INFO - 2018-02-11 20:59:43 --> Config Class Initialized
INFO - 2018-02-11 20:59:43 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:59:43 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:59:43 --> Utf8 Class Initialized
DEBUG - 2018-02-11 20:59:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 20:59:43 --> URI Class Initialized
INFO - 2018-02-11 20:59:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 20:59:43 --> Router Class Initialized
INFO - 2018-02-11 20:59:43 --> Form Validation Class Initialized
INFO - 2018-02-11 20:59:43 --> Model Class Initialized
INFO - 2018-02-11 20:59:43 --> Controller Class Initialized
INFO - 2018-02-11 20:59:43 --> Output Class Initialized
INFO - 2018-02-11 20:59:43 --> Security Class Initialized
INFO - 2018-02-11 20:59:43 --> Model Class Initialized
DEBUG - 2018-02-11 20:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:59:43 --> Model Class Initialized
INFO - 2018-02-11 20:59:43 --> Input Class Initialized
INFO - 2018-02-11 20:59:43 --> Model Class Initialized
INFO - 2018-02-11 20:59:43 --> Language Class Initialized
INFO - 2018-02-11 20:59:43 --> Model Class Initialized
INFO - 2018-02-11 20:59:43 --> Model Class Initialized
DEBUG - 2018-02-11 20:59:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 20:59:43 --> Loader Class Initialized
INFO - 2018-02-11 20:59:43 --> Helper loaded: url_helper
INFO - 2018-02-11 20:59:43 --> Helper loaded: form_helper
INFO - 2018-02-11 20:59:43 --> Database Driver Class Initialized
DEBUG - 2018-02-11 20:59:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 20:59:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 20:59:43 --> Form Validation Class Initialized
INFO - 2018-02-11 20:59:43 --> Model Class Initialized
INFO - 2018-02-11 20:59:43 --> Controller Class Initialized
INFO - 2018-02-11 20:59:43 --> Model Class Initialized
INFO - 2018-02-11 20:59:43 --> Model Class Initialized
INFO - 2018-02-11 20:59:43 --> Model Class Initialized
INFO - 2018-02-11 20:59:43 --> Model Class Initialized
INFO - 2018-02-11 20:59:43 --> Model Class Initialized
DEBUG - 2018-02-11 20:59:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 20:59:43 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-11 20:59:43 --> Final output sent to browser
DEBUG - 2018-02-11 20:59:43 --> Total execution time: 0.0475
INFO - 2018-02-11 20:59:43 --> Config Class Initialized
INFO - 2018-02-11 20:59:43 --> Hooks Class Initialized
INFO - 2018-02-11 20:59:43 --> Config Class Initialized
INFO - 2018-02-11 20:59:43 --> Hooks Class Initialized
INFO - 2018-02-11 20:59:43 --> Config Class Initialized
INFO - 2018-02-11 20:59:43 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:59:43 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:59:43 --> Utf8 Class Initialized
INFO - 2018-02-11 20:59:43 --> URI Class Initialized
DEBUG - 2018-02-11 20:59:43 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:59:43 --> Utf8 Class Initialized
INFO - 2018-02-11 20:59:43 --> URI Class Initialized
DEBUG - 2018-02-11 20:59:43 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:59:43 --> Router Class Initialized
INFO - 2018-02-11 20:59:43 --> Utf8 Class Initialized
INFO - 2018-02-11 20:59:43 --> URI Class Initialized
INFO - 2018-02-11 20:59:43 --> Router Class Initialized
INFO - 2018-02-11 20:59:43 --> Output Class Initialized
INFO - 2018-02-11 20:59:43 --> Security Class Initialized
INFO - 2018-02-11 20:59:43 --> Router Class Initialized
INFO - 2018-02-11 20:59:43 --> Output Class Initialized
DEBUG - 2018-02-11 20:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:59:43 --> Input Class Initialized
INFO - 2018-02-11 20:59:43 --> Security Class Initialized
INFO - 2018-02-11 20:59:43 --> Output Class Initialized
INFO - 2018-02-11 20:59:43 --> Language Class Initialized
DEBUG - 2018-02-11 20:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:59:43 --> Security Class Initialized
INFO - 2018-02-11 20:59:43 --> Input Class Initialized
ERROR - 2018-02-11 20:59:43 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-11 20:59:43 --> Language Class Initialized
DEBUG - 2018-02-11 20:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:59:43 --> Input Class Initialized
INFO - 2018-02-11 20:59:43 --> Language Class Initialized
ERROR - 2018-02-11 20:59:43 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-11 20:59:43 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-11 20:59:43 --> Config Class Initialized
INFO - 2018-02-11 20:59:43 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:59:43 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:59:43 --> Utf8 Class Initialized
INFO - 2018-02-11 20:59:43 --> URI Class Initialized
INFO - 2018-02-11 20:59:43 --> Router Class Initialized
INFO - 2018-02-11 20:59:43 --> Output Class Initialized
INFO - 2018-02-11 20:59:43 --> Security Class Initialized
DEBUG - 2018-02-11 20:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:59:43 --> Input Class Initialized
INFO - 2018-02-11 20:59:43 --> Language Class Initialized
ERROR - 2018-02-11 20:59:43 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-11 20:59:43 --> Config Class Initialized
INFO - 2018-02-11 20:59:43 --> Hooks Class Initialized
INFO - 2018-02-11 20:59:43 --> Config Class Initialized
INFO - 2018-02-11 20:59:43 --> Hooks Class Initialized
INFO - 2018-02-11 20:59:43 --> Config Class Initialized
INFO - 2018-02-11 20:59:43 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:59:43 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:59:43 --> Utf8 Class Initialized
INFO - 2018-02-11 20:59:43 --> URI Class Initialized
DEBUG - 2018-02-11 20:59:43 --> UTF-8 Support Enabled
DEBUG - 2018-02-11 20:59:43 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:59:43 --> Utf8 Class Initialized
INFO - 2018-02-11 20:59:43 --> Utf8 Class Initialized
INFO - 2018-02-11 20:59:43 --> URI Class Initialized
INFO - 2018-02-11 20:59:43 --> Router Class Initialized
INFO - 2018-02-11 20:59:43 --> URI Class Initialized
INFO - 2018-02-11 20:59:43 --> Config Class Initialized
INFO - 2018-02-11 20:59:43 --> Hooks Class Initialized
INFO - 2018-02-11 20:59:43 --> Router Class Initialized
INFO - 2018-02-11 20:59:43 --> Router Class Initialized
INFO - 2018-02-11 20:59:43 --> Output Class Initialized
INFO - 2018-02-11 20:59:43 --> Security Class Initialized
INFO - 2018-02-11 20:59:43 --> Output Class Initialized
DEBUG - 2018-02-11 20:59:43 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:59:43 --> Output Class Initialized
INFO - 2018-02-11 20:59:43 --> Utf8 Class Initialized
DEBUG - 2018-02-11 20:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:59:43 --> Security Class Initialized
INFO - 2018-02-11 20:59:43 --> Input Class Initialized
INFO - 2018-02-11 20:59:43 --> URI Class Initialized
INFO - 2018-02-11 20:59:43 --> Security Class Initialized
INFO - 2018-02-11 20:59:43 --> Language Class Initialized
DEBUG - 2018-02-11 20:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:59:43 --> Input Class Initialized
DEBUG - 2018-02-11 20:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:59:43 --> Router Class Initialized
INFO - 2018-02-11 20:59:43 --> Input Class Initialized
INFO - 2018-02-11 20:59:43 --> Language Class Initialized
ERROR - 2018-02-11 20:59:43 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-11 20:59:43 --> Language Class Initialized
ERROR - 2018-02-11 20:59:43 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-11 20:59:43 --> Output Class Initialized
ERROR - 2018-02-11 20:59:43 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-11 20:59:43 --> Security Class Initialized
DEBUG - 2018-02-11 20:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:59:43 --> Input Class Initialized
INFO - 2018-02-11 20:59:43 --> Language Class Initialized
INFO - 2018-02-11 20:59:43 --> Loader Class Initialized
INFO - 2018-02-11 20:59:43 --> Helper loaded: url_helper
INFO - 2018-02-11 20:59:43 --> Helper loaded: form_helper
INFO - 2018-02-11 20:59:43 --> Database Driver Class Initialized
DEBUG - 2018-02-11 20:59:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 20:59:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 20:59:43 --> Config Class Initialized
INFO - 2018-02-11 20:59:43 --> Hooks Class Initialized
INFO - 2018-02-11 20:59:43 --> Form Validation Class Initialized
INFO - 2018-02-11 20:59:43 --> Model Class Initialized
INFO - 2018-02-11 20:59:43 --> Controller Class Initialized
DEBUG - 2018-02-11 20:59:43 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:59:43 --> Utf8 Class Initialized
INFO - 2018-02-11 20:59:43 --> URI Class Initialized
INFO - 2018-02-11 20:59:43 --> Model Class Initialized
INFO - 2018-02-11 20:59:43 --> Model Class Initialized
INFO - 2018-02-11 20:59:43 --> Router Class Initialized
INFO - 2018-02-11 20:59:43 --> Model Class Initialized
INFO - 2018-02-11 20:59:43 --> Model Class Initialized
INFO - 2018-02-11 20:59:43 --> Output Class Initialized
INFO - 2018-02-11 20:59:43 --> Model Class Initialized
DEBUG - 2018-02-11 20:59:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 20:59:43 --> Security Class Initialized
DEBUG - 2018-02-11 20:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:59:43 --> Input Class Initialized
INFO - 2018-02-11 20:59:43 --> Language Class Initialized
INFO - 2018-02-11 20:59:43 --> Loader Class Initialized
INFO - 2018-02-11 20:59:43 --> Helper loaded: url_helper
INFO - 2018-02-11 20:59:43 --> Helper loaded: form_helper
INFO - 2018-02-11 20:59:43 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-11 20:59:43 --> Final output sent to browser
DEBUG - 2018-02-11 20:59:43 --> Total execution time: 0.0552
INFO - 2018-02-11 20:59:43 --> Database Driver Class Initialized
DEBUG - 2018-02-11 20:59:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 20:59:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 20:59:43 --> Form Validation Class Initialized
INFO - 2018-02-11 20:59:43 --> Model Class Initialized
INFO - 2018-02-11 20:59:43 --> Controller Class Initialized
INFO - 2018-02-11 20:59:43 --> Model Class Initialized
INFO - 2018-02-11 20:59:43 --> Model Class Initialized
INFO - 2018-02-11 20:59:43 --> Model Class Initialized
INFO - 2018-02-11 20:59:43 --> Model Class Initialized
INFO - 2018-02-11 20:59:43 --> Model Class Initialized
DEBUG - 2018-02-11 20:59:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 20:59:44 --> Config Class Initialized
INFO - 2018-02-11 20:59:44 --> Hooks Class Initialized
INFO - 2018-02-11 20:59:44 --> Config Class Initialized
INFO - 2018-02-11 20:59:44 --> Hooks Class Initialized
INFO - 2018-02-11 20:59:44 --> Config Class Initialized
INFO - 2018-02-11 20:59:44 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:59:44 --> UTF-8 Support Enabled
DEBUG - 2018-02-11 20:59:44 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:59:44 --> Utf8 Class Initialized
DEBUG - 2018-02-11 20:59:44 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:59:44 --> Utf8 Class Initialized
INFO - 2018-02-11 20:59:44 --> Utf8 Class Initialized
INFO - 2018-02-11 20:59:44 --> URI Class Initialized
INFO - 2018-02-11 20:59:44 --> URI Class Initialized
INFO - 2018-02-11 20:59:44 --> URI Class Initialized
INFO - 2018-02-11 20:59:44 --> Router Class Initialized
INFO - 2018-02-11 20:59:44 --> Router Class Initialized
INFO - 2018-02-11 20:59:44 --> Router Class Initialized
INFO - 2018-02-11 20:59:44 --> Output Class Initialized
INFO - 2018-02-11 20:59:44 --> Output Class Initialized
INFO - 2018-02-11 20:59:44 --> Output Class Initialized
INFO - 2018-02-11 20:59:44 --> Security Class Initialized
INFO - 2018-02-11 20:59:44 --> Security Class Initialized
INFO - 2018-02-11 20:59:44 --> Security Class Initialized
DEBUG - 2018-02-11 20:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:59:44 --> Input Class Initialized
DEBUG - 2018-02-11 20:59:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-11 20:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:59:44 --> Input Class Initialized
INFO - 2018-02-11 20:59:44 --> Input Class Initialized
INFO - 2018-02-11 20:59:44 --> Language Class Initialized
INFO - 2018-02-11 20:59:44 --> Language Class Initialized
INFO - 2018-02-11 20:59:44 --> Language Class Initialized
ERROR - 2018-02-11 20:59:44 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-11 20:59:44 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-11 20:59:44 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-11 20:59:44 --> Config Class Initialized
INFO - 2018-02-11 20:59:44 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:59:44 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:59:44 --> Utf8 Class Initialized
INFO - 2018-02-11 20:59:44 --> URI Class Initialized
INFO - 2018-02-11 20:59:44 --> Router Class Initialized
INFO - 2018-02-11 20:59:44 --> Output Class Initialized
INFO - 2018-02-11 20:59:44 --> Security Class Initialized
DEBUG - 2018-02-11 20:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:59:44 --> Input Class Initialized
INFO - 2018-02-11 20:59:44 --> Language Class Initialized
ERROR - 2018-02-11 20:59:44 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-11 20:59:44 --> Config Class Initialized
INFO - 2018-02-11 20:59:44 --> Hooks Class Initialized
INFO - 2018-02-11 20:59:44 --> Config Class Initialized
INFO - 2018-02-11 20:59:44 --> Hooks Class Initialized
INFO - 2018-02-11 20:59:44 --> Config Class Initialized
INFO - 2018-02-11 20:59:44 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:59:44 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:59:44 --> Utf8 Class Initialized
DEBUG - 2018-02-11 20:59:44 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:59:44 --> Utf8 Class Initialized
DEBUG - 2018-02-11 20:59:44 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:59:44 --> URI Class Initialized
INFO - 2018-02-11 20:59:44 --> Utf8 Class Initialized
INFO - 2018-02-11 20:59:44 --> URI Class Initialized
INFO - 2018-02-11 20:59:44 --> URI Class Initialized
INFO - 2018-02-11 20:59:44 --> Router Class Initialized
INFO - 2018-02-11 20:59:44 --> Router Class Initialized
INFO - 2018-02-11 20:59:44 --> Router Class Initialized
INFO - 2018-02-11 20:59:44 --> Output Class Initialized
INFO - 2018-02-11 20:59:44 --> Output Class Initialized
INFO - 2018-02-11 20:59:44 --> Output Class Initialized
INFO - 2018-02-11 20:59:44 --> Security Class Initialized
INFO - 2018-02-11 20:59:44 --> Security Class Initialized
INFO - 2018-02-11 20:59:44 --> Security Class Initialized
DEBUG - 2018-02-11 20:59:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-11 20:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:59:44 --> Input Class Initialized
INFO - 2018-02-11 20:59:44 --> Input Class Initialized
DEBUG - 2018-02-11 20:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:59:44 --> Input Class Initialized
INFO - 2018-02-11 20:59:44 --> Language Class Initialized
INFO - 2018-02-11 20:59:44 --> Language Class Initialized
INFO - 2018-02-11 20:59:44 --> Language Class Initialized
ERROR - 2018-02-11 20:59:44 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-11 20:59:44 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-11 20:59:44 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-11 20:59:44 --> Config Class Initialized
INFO - 2018-02-11 20:59:44 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:59:44 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:59:44 --> Utf8 Class Initialized
INFO - 2018-02-11 20:59:44 --> URI Class Initialized
INFO - 2018-02-11 20:59:44 --> Router Class Initialized
INFO - 2018-02-11 20:59:44 --> Output Class Initialized
INFO - 2018-02-11 20:59:44 --> Security Class Initialized
DEBUG - 2018-02-11 20:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:59:44 --> Input Class Initialized
INFO - 2018-02-11 20:59:44 --> Language Class Initialized
INFO - 2018-02-11 20:59:44 --> Loader Class Initialized
INFO - 2018-02-11 20:59:44 --> Helper loaded: url_helper
INFO - 2018-02-11 20:59:44 --> Helper loaded: form_helper
INFO - 2018-02-11 20:59:44 --> Database Driver Class Initialized
DEBUG - 2018-02-11 20:59:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 20:59:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 20:59:44 --> Form Validation Class Initialized
INFO - 2018-02-11 20:59:44 --> Model Class Initialized
INFO - 2018-02-11 20:59:44 --> Controller Class Initialized
INFO - 2018-02-11 20:59:44 --> Model Class Initialized
INFO - 2018-02-11 20:59:44 --> Model Class Initialized
INFO - 2018-02-11 20:59:44 --> Model Class Initialized
INFO - 2018-02-11 20:59:44 --> Model Class Initialized
INFO - 2018-02-11 20:59:44 --> Model Class Initialized
DEBUG - 2018-02-11 20:59:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 20:59:53 --> Config Class Initialized
INFO - 2018-02-11 20:59:53 --> Hooks Class Initialized
INFO - 2018-02-11 20:59:53 --> Config Class Initialized
INFO - 2018-02-11 20:59:53 --> Hooks Class Initialized
INFO - 2018-02-11 20:59:53 --> Config Class Initialized
INFO - 2018-02-11 20:59:53 --> Hooks Class Initialized
INFO - 2018-02-11 20:59:53 --> Config Class Initialized
INFO - 2018-02-11 20:59:53 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:59:53 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:59:53 --> Utf8 Class Initialized
DEBUG - 2018-02-11 20:59:53 --> UTF-8 Support Enabled
DEBUG - 2018-02-11 20:59:53 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:59:53 --> Utf8 Class Initialized
INFO - 2018-02-11 20:59:53 --> Utf8 Class Initialized
INFO - 2018-02-11 20:59:53 --> URI Class Initialized
DEBUG - 2018-02-11 20:59:53 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:59:53 --> Utf8 Class Initialized
INFO - 2018-02-11 20:59:53 --> URI Class Initialized
INFO - 2018-02-11 20:59:53 --> URI Class Initialized
INFO - 2018-02-11 20:59:53 --> URI Class Initialized
INFO - 2018-02-11 20:59:53 --> Router Class Initialized
INFO - 2018-02-11 20:59:53 --> Router Class Initialized
INFO - 2018-02-11 20:59:53 --> Router Class Initialized
INFO - 2018-02-11 20:59:53 --> Router Class Initialized
INFO - 2018-02-11 20:59:53 --> Output Class Initialized
INFO - 2018-02-11 20:59:53 --> Output Class Initialized
INFO - 2018-02-11 20:59:53 --> Output Class Initialized
INFO - 2018-02-11 20:59:53 --> Output Class Initialized
INFO - 2018-02-11 20:59:53 --> Security Class Initialized
INFO - 2018-02-11 20:59:53 --> Security Class Initialized
INFO - 2018-02-11 20:59:53 --> Security Class Initialized
INFO - 2018-02-11 20:59:53 --> Security Class Initialized
DEBUG - 2018-02-11 20:59:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-11 20:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:59:53 --> Input Class Initialized
INFO - 2018-02-11 20:59:53 --> Input Class Initialized
DEBUG - 2018-02-11 20:59:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-11 20:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:59:53 --> Language Class Initialized
INFO - 2018-02-11 20:59:53 --> Input Class Initialized
INFO - 2018-02-11 20:59:53 --> Input Class Initialized
INFO - 2018-02-11 20:59:53 --> Language Class Initialized
INFO - 2018-02-11 20:59:53 --> Language Class Initialized
ERROR - 2018-02-11 20:59:53 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-11 20:59:53 --> Language Class Initialized
ERROR - 2018-02-11 20:59:53 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-11 20:59:53 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-11 20:59:53 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-11 20:59:53 --> Config Class Initialized
INFO - 2018-02-11 20:59:53 --> Hooks Class Initialized
INFO - 2018-02-11 20:59:53 --> Config Class Initialized
INFO - 2018-02-11 20:59:53 --> Config Class Initialized
DEBUG - 2018-02-11 20:59:53 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:59:53 --> Hooks Class Initialized
INFO - 2018-02-11 20:59:53 --> Hooks Class Initialized
INFO - 2018-02-11 20:59:53 --> Utf8 Class Initialized
INFO - 2018-02-11 20:59:53 --> URI Class Initialized
DEBUG - 2018-02-11 20:59:53 --> UTF-8 Support Enabled
DEBUG - 2018-02-11 20:59:53 --> UTF-8 Support Enabled
INFO - 2018-02-11 20:59:53 --> Router Class Initialized
INFO - 2018-02-11 20:59:53 --> Utf8 Class Initialized
INFO - 2018-02-11 20:59:53 --> Utf8 Class Initialized
INFO - 2018-02-11 20:59:53 --> URI Class Initialized
INFO - 2018-02-11 20:59:53 --> URI Class Initialized
INFO - 2018-02-11 20:59:53 --> Output Class Initialized
INFO - 2018-02-11 20:59:53 --> Router Class Initialized
INFO - 2018-02-11 20:59:53 --> Security Class Initialized
INFO - 2018-02-11 20:59:53 --> Router Class Initialized
DEBUG - 2018-02-11 20:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:59:53 --> Output Class Initialized
INFO - 2018-02-11 20:59:53 --> Input Class Initialized
INFO - 2018-02-11 20:59:53 --> Output Class Initialized
INFO - 2018-02-11 20:59:53 --> Language Class Initialized
INFO - 2018-02-11 20:59:53 --> Security Class Initialized
INFO - 2018-02-11 20:59:53 --> Security Class Initialized
ERROR - 2018-02-11 20:59:53 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-02-11 20:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:59:53 --> Input Class Initialized
DEBUG - 2018-02-11 20:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 20:59:53 --> Input Class Initialized
INFO - 2018-02-11 20:59:53 --> Language Class Initialized
INFO - 2018-02-11 20:59:53 --> Language Class Initialized
ERROR - 2018-02-11 20:59:53 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-11 20:59:53 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-11 21:00:09 --> Config Class Initialized
INFO - 2018-02-11 21:00:09 --> Hooks Class Initialized
DEBUG - 2018-02-11 21:00:09 --> UTF-8 Support Enabled
INFO - 2018-02-11 21:00:09 --> Utf8 Class Initialized
INFO - 2018-02-11 21:00:09 --> URI Class Initialized
INFO - 2018-02-11 21:00:09 --> Router Class Initialized
INFO - 2018-02-11 21:00:09 --> Output Class Initialized
INFO - 2018-02-11 21:00:09 --> Security Class Initialized
DEBUG - 2018-02-11 21:00:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 21:00:09 --> Input Class Initialized
INFO - 2018-02-11 21:00:09 --> Language Class Initialized
INFO - 2018-02-11 21:00:09 --> Loader Class Initialized
INFO - 2018-02-11 21:00:09 --> Helper loaded: url_helper
INFO - 2018-02-11 21:00:09 --> Helper loaded: form_helper
INFO - 2018-02-11 21:00:09 --> Database Driver Class Initialized
DEBUG - 2018-02-11 21:00:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 21:00:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 21:00:09 --> Form Validation Class Initialized
INFO - 2018-02-11 21:00:09 --> Model Class Initialized
INFO - 2018-02-11 21:00:09 --> Controller Class Initialized
INFO - 2018-02-11 21:00:09 --> Model Class Initialized
INFO - 2018-02-11 21:00:09 --> Model Class Initialized
INFO - 2018-02-11 21:00:09 --> Model Class Initialized
INFO - 2018-02-11 21:00:09 --> Model Class Initialized
INFO - 2018-02-11 21:00:09 --> Model Class Initialized
DEBUG - 2018-02-11 21:00:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 21:00:09 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-11 21:00:09 --> Final output sent to browser
DEBUG - 2018-02-11 21:00:09 --> Total execution time: 0.0668
INFO - 2018-02-11 21:00:09 --> Config Class Initialized
INFO - 2018-02-11 21:00:09 --> Hooks Class Initialized
DEBUG - 2018-02-11 21:00:09 --> UTF-8 Support Enabled
INFO - 2018-02-11 21:00:09 --> Utf8 Class Initialized
INFO - 2018-02-11 21:00:09 --> URI Class Initialized
INFO - 2018-02-11 21:00:09 --> Router Class Initialized
INFO - 2018-02-11 21:00:09 --> Output Class Initialized
INFO - 2018-02-11 21:00:09 --> Security Class Initialized
DEBUG - 2018-02-11 21:00:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 21:00:09 --> Input Class Initialized
INFO - 2018-02-11 21:00:09 --> Language Class Initialized
INFO - 2018-02-11 21:00:09 --> Loader Class Initialized
INFO - 2018-02-11 21:00:09 --> Helper loaded: url_helper
INFO - 2018-02-11 21:00:09 --> Helper loaded: form_helper
INFO - 2018-02-11 21:00:09 --> Database Driver Class Initialized
DEBUG - 2018-02-11 21:00:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 21:00:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 21:00:09 --> Form Validation Class Initialized
INFO - 2018-02-11 21:00:09 --> Model Class Initialized
INFO - 2018-02-11 21:00:09 --> Controller Class Initialized
INFO - 2018-02-11 21:00:09 --> Model Class Initialized
INFO - 2018-02-11 21:00:09 --> Model Class Initialized
INFO - 2018-02-11 21:00:09 --> Model Class Initialized
INFO - 2018-02-11 21:00:09 --> Model Class Initialized
INFO - 2018-02-11 21:00:09 --> Model Class Initialized
DEBUG - 2018-02-11 21:00:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 21:41:17 --> Config Class Initialized
INFO - 2018-02-11 21:41:17 --> Hooks Class Initialized
DEBUG - 2018-02-11 21:41:17 --> UTF-8 Support Enabled
INFO - 2018-02-11 21:41:17 --> Utf8 Class Initialized
INFO - 2018-02-11 21:41:17 --> URI Class Initialized
INFO - 2018-02-11 21:41:17 --> Router Class Initialized
INFO - 2018-02-11 21:41:17 --> Output Class Initialized
INFO - 2018-02-11 21:41:17 --> Security Class Initialized
DEBUG - 2018-02-11 21:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 21:41:17 --> Input Class Initialized
INFO - 2018-02-11 21:41:17 --> Language Class Initialized
INFO - 2018-02-11 21:41:17 --> Loader Class Initialized
INFO - 2018-02-11 21:41:17 --> Helper loaded: url_helper
INFO - 2018-02-11 21:41:17 --> Helper loaded: form_helper
INFO - 2018-02-11 21:41:17 --> Database Driver Class Initialized
DEBUG - 2018-02-11 21:41:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 21:41:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 21:41:17 --> Form Validation Class Initialized
INFO - 2018-02-11 21:41:17 --> Model Class Initialized
INFO - 2018-02-11 21:41:17 --> Controller Class Initialized
INFO - 2018-02-11 21:41:17 --> Model Class Initialized
INFO - 2018-02-11 21:41:17 --> Model Class Initialized
INFO - 2018-02-11 21:41:17 --> Model Class Initialized
INFO - 2018-02-11 21:41:17 --> Model Class Initialized
INFO - 2018-02-11 21:41:17 --> Model Class Initialized
DEBUG - 2018-02-11 21:41:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 21:41:17 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-11 21:41:17 --> Final output sent to browser
DEBUG - 2018-02-11 21:41:17 --> Total execution time: 0.0623
INFO - 2018-02-11 21:41:17 --> Config Class Initialized
INFO - 2018-02-11 21:41:17 --> Hooks Class Initialized
DEBUG - 2018-02-11 21:41:17 --> UTF-8 Support Enabled
INFO - 2018-02-11 21:41:17 --> Utf8 Class Initialized
INFO - 2018-02-11 21:41:17 --> URI Class Initialized
INFO - 2018-02-11 21:41:17 --> Router Class Initialized
INFO - 2018-02-11 21:41:17 --> Output Class Initialized
INFO - 2018-02-11 21:41:17 --> Security Class Initialized
DEBUG - 2018-02-11 21:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 21:41:17 --> Input Class Initialized
INFO - 2018-02-11 21:41:17 --> Language Class Initialized
INFO - 2018-02-11 21:41:17 --> Loader Class Initialized
INFO - 2018-02-11 21:41:17 --> Helper loaded: url_helper
INFO - 2018-02-11 21:41:17 --> Helper loaded: form_helper
INFO - 2018-02-11 21:41:17 --> Database Driver Class Initialized
DEBUG - 2018-02-11 21:41:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 21:41:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 21:41:17 --> Form Validation Class Initialized
INFO - 2018-02-11 21:41:17 --> Model Class Initialized
INFO - 2018-02-11 21:41:17 --> Controller Class Initialized
INFO - 2018-02-11 21:41:17 --> Model Class Initialized
INFO - 2018-02-11 21:41:17 --> Model Class Initialized
INFO - 2018-02-11 21:41:17 --> Model Class Initialized
INFO - 2018-02-11 21:41:17 --> Model Class Initialized
INFO - 2018-02-11 21:41:17 --> Model Class Initialized
DEBUG - 2018-02-11 21:41:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 21:41:18 --> Config Class Initialized
INFO - 2018-02-11 21:41:18 --> Hooks Class Initialized
DEBUG - 2018-02-11 21:41:18 --> UTF-8 Support Enabled
INFO - 2018-02-11 21:41:18 --> Utf8 Class Initialized
INFO - 2018-02-11 21:41:18 --> URI Class Initialized
INFO - 2018-02-11 21:41:18 --> Router Class Initialized
INFO - 2018-02-11 21:41:18 --> Output Class Initialized
INFO - 2018-02-11 21:41:18 --> Security Class Initialized
DEBUG - 2018-02-11 21:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 21:41:18 --> Input Class Initialized
INFO - 2018-02-11 21:41:18 --> Language Class Initialized
INFO - 2018-02-11 21:41:18 --> Loader Class Initialized
INFO - 2018-02-11 21:41:18 --> Helper loaded: url_helper
INFO - 2018-02-11 21:41:18 --> Helper loaded: form_helper
INFO - 2018-02-11 21:41:18 --> Database Driver Class Initialized
DEBUG - 2018-02-11 21:41:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 21:41:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 21:41:18 --> Form Validation Class Initialized
INFO - 2018-02-11 21:41:18 --> Model Class Initialized
INFO - 2018-02-11 21:41:18 --> Controller Class Initialized
INFO - 2018-02-11 21:41:18 --> Model Class Initialized
INFO - 2018-02-11 21:41:18 --> Model Class Initialized
INFO - 2018-02-11 21:41:18 --> Model Class Initialized
INFO - 2018-02-11 21:41:18 --> Model Class Initialized
INFO - 2018-02-11 21:41:18 --> Model Class Initialized
DEBUG - 2018-02-11 21:41:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 21:41:18 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-11 21:41:18 --> Final output sent to browser
DEBUG - 2018-02-11 21:41:18 --> Total execution time: 0.0534
INFO - 2018-02-11 21:41:24 --> Config Class Initialized
INFO - 2018-02-11 21:41:24 --> Hooks Class Initialized
DEBUG - 2018-02-11 21:41:24 --> UTF-8 Support Enabled
INFO - 2018-02-11 21:41:24 --> Utf8 Class Initialized
INFO - 2018-02-11 21:41:24 --> URI Class Initialized
INFO - 2018-02-11 21:41:24 --> Router Class Initialized
INFO - 2018-02-11 21:41:25 --> Output Class Initialized
INFO - 2018-02-11 21:41:25 --> Security Class Initialized
DEBUG - 2018-02-11 21:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 21:41:25 --> Input Class Initialized
INFO - 2018-02-11 21:41:25 --> Language Class Initialized
INFO - 2018-02-11 21:41:25 --> Loader Class Initialized
INFO - 2018-02-11 21:41:25 --> Helper loaded: url_helper
INFO - 2018-02-11 21:41:25 --> Helper loaded: form_helper
INFO - 2018-02-11 21:41:25 --> Database Driver Class Initialized
DEBUG - 2018-02-11 21:41:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 21:41:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 21:41:25 --> Form Validation Class Initialized
INFO - 2018-02-11 21:41:25 --> Model Class Initialized
INFO - 2018-02-11 21:41:25 --> Controller Class Initialized
INFO - 2018-02-11 21:41:25 --> Model Class Initialized
INFO - 2018-02-11 21:41:25 --> Model Class Initialized
DEBUG - 2018-02-11 21:41:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 21:41:25 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-11 21:41:25 --> Final output sent to browser
DEBUG - 2018-02-11 21:41:25 --> Total execution time: 0.1189
INFO - 2018-02-11 21:41:25 --> Config Class Initialized
INFO - 2018-02-11 21:41:25 --> Hooks Class Initialized
DEBUG - 2018-02-11 21:41:25 --> UTF-8 Support Enabled
INFO - 2018-02-11 21:41:25 --> Utf8 Class Initialized
INFO - 2018-02-11 21:41:25 --> URI Class Initialized
INFO - 2018-02-11 21:41:25 --> Router Class Initialized
INFO - 2018-02-11 21:41:25 --> Output Class Initialized
INFO - 2018-02-11 21:41:25 --> Security Class Initialized
DEBUG - 2018-02-11 21:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 21:41:25 --> Input Class Initialized
INFO - 2018-02-11 21:41:25 --> Language Class Initialized
INFO - 2018-02-11 21:41:25 --> Loader Class Initialized
INFO - 2018-02-11 21:41:25 --> Helper loaded: url_helper
INFO - 2018-02-11 21:41:25 --> Helper loaded: form_helper
INFO - 2018-02-11 21:41:25 --> Database Driver Class Initialized
DEBUG - 2018-02-11 21:41:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 21:41:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 21:41:25 --> Form Validation Class Initialized
INFO - 2018-02-11 21:41:25 --> Model Class Initialized
INFO - 2018-02-11 21:41:25 --> Controller Class Initialized
INFO - 2018-02-11 21:41:25 --> Model Class Initialized
INFO - 2018-02-11 21:41:25 --> Model Class Initialized
DEBUG - 2018-02-11 21:41:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 21:41:26 --> Config Class Initialized
INFO - 2018-02-11 21:41:26 --> Hooks Class Initialized
DEBUG - 2018-02-11 21:41:26 --> UTF-8 Support Enabled
INFO - 2018-02-11 21:41:26 --> Utf8 Class Initialized
INFO - 2018-02-11 21:41:26 --> URI Class Initialized
INFO - 2018-02-11 21:41:26 --> Router Class Initialized
INFO - 2018-02-11 21:41:26 --> Output Class Initialized
INFO - 2018-02-11 21:41:26 --> Security Class Initialized
DEBUG - 2018-02-11 21:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 21:41:26 --> Input Class Initialized
INFO - 2018-02-11 21:41:26 --> Language Class Initialized
INFO - 2018-02-11 21:41:26 --> Loader Class Initialized
INFO - 2018-02-11 21:41:26 --> Helper loaded: url_helper
INFO - 2018-02-11 21:41:26 --> Helper loaded: form_helper
INFO - 2018-02-11 21:41:26 --> Database Driver Class Initialized
DEBUG - 2018-02-11 21:41:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 21:41:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 21:41:26 --> Form Validation Class Initialized
INFO - 2018-02-11 21:41:26 --> Model Class Initialized
INFO - 2018-02-11 21:41:26 --> Controller Class Initialized
INFO - 2018-02-11 21:41:26 --> Model Class Initialized
INFO - 2018-02-11 21:41:26 --> Model Class Initialized
INFO - 2018-02-11 21:41:26 --> Model Class Initialized
INFO - 2018-02-11 21:41:26 --> Model Class Initialized
INFO - 2018-02-11 21:41:26 --> Model Class Initialized
DEBUG - 2018-02-11 21:41:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 21:41:26 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-11 21:41:26 --> Final output sent to browser
DEBUG - 2018-02-11 21:41:26 --> Total execution time: 0.0631
INFO - 2018-02-11 21:41:26 --> Config Class Initialized
INFO - 2018-02-11 21:41:26 --> Hooks Class Initialized
DEBUG - 2018-02-11 21:41:26 --> UTF-8 Support Enabled
INFO - 2018-02-11 21:41:26 --> Utf8 Class Initialized
INFO - 2018-02-11 21:41:26 --> URI Class Initialized
INFO - 2018-02-11 21:41:26 --> Router Class Initialized
INFO - 2018-02-11 21:41:26 --> Output Class Initialized
INFO - 2018-02-11 21:41:26 --> Security Class Initialized
DEBUG - 2018-02-11 21:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 21:41:26 --> Input Class Initialized
INFO - 2018-02-11 21:41:26 --> Language Class Initialized
INFO - 2018-02-11 21:41:26 --> Loader Class Initialized
INFO - 2018-02-11 21:41:26 --> Helper loaded: url_helper
INFO - 2018-02-11 21:41:26 --> Helper loaded: form_helper
INFO - 2018-02-11 21:41:26 --> Database Driver Class Initialized
DEBUG - 2018-02-11 21:41:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 21:41:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 21:41:26 --> Form Validation Class Initialized
INFO - 2018-02-11 21:41:26 --> Model Class Initialized
INFO - 2018-02-11 21:41:26 --> Controller Class Initialized
INFO - 2018-02-11 21:41:26 --> Model Class Initialized
INFO - 2018-02-11 21:41:26 --> Model Class Initialized
INFO - 2018-02-11 21:41:26 --> Model Class Initialized
INFO - 2018-02-11 21:41:26 --> Model Class Initialized
INFO - 2018-02-11 21:41:26 --> Model Class Initialized
DEBUG - 2018-02-11 21:41:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 21:41:31 --> Config Class Initialized
INFO - 2018-02-11 21:41:31 --> Hooks Class Initialized
DEBUG - 2018-02-11 21:41:31 --> UTF-8 Support Enabled
INFO - 2018-02-11 21:41:31 --> Utf8 Class Initialized
INFO - 2018-02-11 21:41:31 --> URI Class Initialized
INFO - 2018-02-11 21:41:31 --> Router Class Initialized
INFO - 2018-02-11 21:41:31 --> Output Class Initialized
INFO - 2018-02-11 21:41:31 --> Security Class Initialized
DEBUG - 2018-02-11 21:41:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 21:41:31 --> Input Class Initialized
INFO - 2018-02-11 21:41:31 --> Language Class Initialized
INFO - 2018-02-11 21:41:31 --> Loader Class Initialized
INFO - 2018-02-11 21:41:31 --> Helper loaded: url_helper
INFO - 2018-02-11 21:41:31 --> Helper loaded: form_helper
INFO - 2018-02-11 21:41:31 --> Database Driver Class Initialized
DEBUG - 2018-02-11 21:41:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 21:41:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 21:41:31 --> Form Validation Class Initialized
INFO - 2018-02-11 21:41:31 --> Model Class Initialized
INFO - 2018-02-11 21:41:31 --> Controller Class Initialized
INFO - 2018-02-11 21:41:31 --> Model Class Initialized
INFO - 2018-02-11 21:41:31 --> Model Class Initialized
INFO - 2018-02-11 21:41:31 --> Model Class Initialized
INFO - 2018-02-11 21:41:31 --> Model Class Initialized
INFO - 2018-02-11 21:41:31 --> Model Class Initialized
DEBUG - 2018-02-11 21:41:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 21:41:31 --> Final output sent to browser
DEBUG - 2018-02-11 21:41:31 --> Total execution time: 0.0527
INFO - 2018-02-11 21:41:32 --> Config Class Initialized
INFO - 2018-02-11 21:41:32 --> Hooks Class Initialized
DEBUG - 2018-02-11 21:41:32 --> UTF-8 Support Enabled
INFO - 2018-02-11 21:41:32 --> Utf8 Class Initialized
INFO - 2018-02-11 21:41:32 --> URI Class Initialized
INFO - 2018-02-11 21:41:32 --> Router Class Initialized
INFO - 2018-02-11 21:41:32 --> Output Class Initialized
INFO - 2018-02-11 21:41:32 --> Security Class Initialized
DEBUG - 2018-02-11 21:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 21:41:32 --> Input Class Initialized
INFO - 2018-02-11 21:41:32 --> Language Class Initialized
INFO - 2018-02-11 21:41:32 --> Loader Class Initialized
INFO - 2018-02-11 21:41:32 --> Helper loaded: url_helper
INFO - 2018-02-11 21:41:32 --> Helper loaded: form_helper
INFO - 2018-02-11 21:41:32 --> Database Driver Class Initialized
DEBUG - 2018-02-11 21:41:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 21:41:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 21:41:32 --> Form Validation Class Initialized
INFO - 2018-02-11 21:41:32 --> Model Class Initialized
INFO - 2018-02-11 21:41:32 --> Controller Class Initialized
INFO - 2018-02-11 21:41:32 --> Model Class Initialized
INFO - 2018-02-11 21:41:32 --> Model Class Initialized
INFO - 2018-02-11 21:41:32 --> Model Class Initialized
INFO - 2018-02-11 21:41:32 --> Model Class Initialized
INFO - 2018-02-11 21:41:32 --> Model Class Initialized
DEBUG - 2018-02-11 21:41:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 21:41:33 --> Config Class Initialized
INFO - 2018-02-11 21:41:33 --> Hooks Class Initialized
DEBUG - 2018-02-11 21:41:33 --> UTF-8 Support Enabled
INFO - 2018-02-11 21:41:33 --> Utf8 Class Initialized
INFO - 2018-02-11 21:41:33 --> URI Class Initialized
INFO - 2018-02-11 21:41:33 --> Router Class Initialized
INFO - 2018-02-11 21:41:33 --> Output Class Initialized
INFO - 2018-02-11 21:41:33 --> Security Class Initialized
DEBUG - 2018-02-11 21:41:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 21:41:33 --> Input Class Initialized
INFO - 2018-02-11 21:41:33 --> Language Class Initialized
INFO - 2018-02-11 21:41:33 --> Loader Class Initialized
INFO - 2018-02-11 21:41:33 --> Helper loaded: url_helper
INFO - 2018-02-11 21:41:33 --> Helper loaded: form_helper
INFO - 2018-02-11 21:41:33 --> Database Driver Class Initialized
DEBUG - 2018-02-11 21:41:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 21:41:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 21:41:33 --> Form Validation Class Initialized
INFO - 2018-02-11 21:41:33 --> Model Class Initialized
INFO - 2018-02-11 21:41:33 --> Controller Class Initialized
INFO - 2018-02-11 21:41:33 --> Model Class Initialized
INFO - 2018-02-11 21:41:33 --> Model Class Initialized
INFO - 2018-02-11 21:41:33 --> Model Class Initialized
INFO - 2018-02-11 21:41:33 --> Model Class Initialized
INFO - 2018-02-11 21:41:33 --> Model Class Initialized
DEBUG - 2018-02-11 21:41:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 21:41:34 --> Config Class Initialized
INFO - 2018-02-11 21:41:34 --> Hooks Class Initialized
DEBUG - 2018-02-11 21:41:34 --> UTF-8 Support Enabled
INFO - 2018-02-11 21:41:34 --> Utf8 Class Initialized
INFO - 2018-02-11 21:41:34 --> URI Class Initialized
INFO - 2018-02-11 21:41:34 --> Router Class Initialized
INFO - 2018-02-11 21:41:34 --> Output Class Initialized
INFO - 2018-02-11 21:41:34 --> Security Class Initialized
DEBUG - 2018-02-11 21:41:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 21:41:34 --> Input Class Initialized
INFO - 2018-02-11 21:41:34 --> Language Class Initialized
INFO - 2018-02-11 21:41:34 --> Loader Class Initialized
INFO - 2018-02-11 21:41:34 --> Helper loaded: url_helper
INFO - 2018-02-11 21:41:34 --> Helper loaded: form_helper
INFO - 2018-02-11 21:41:34 --> Database Driver Class Initialized
DEBUG - 2018-02-11 21:41:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 21:41:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 21:41:34 --> Form Validation Class Initialized
INFO - 2018-02-11 21:41:34 --> Model Class Initialized
INFO - 2018-02-11 21:41:34 --> Controller Class Initialized
INFO - 2018-02-11 21:41:34 --> Model Class Initialized
INFO - 2018-02-11 21:41:34 --> Model Class Initialized
INFO - 2018-02-11 21:41:34 --> Model Class Initialized
INFO - 2018-02-11 21:41:34 --> Model Class Initialized
INFO - 2018-02-11 21:41:34 --> Model Class Initialized
DEBUG - 2018-02-11 21:41:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 21:42:27 --> Config Class Initialized
INFO - 2018-02-11 21:42:27 --> Hooks Class Initialized
DEBUG - 2018-02-11 21:42:27 --> UTF-8 Support Enabled
INFO - 2018-02-11 21:42:27 --> Utf8 Class Initialized
INFO - 2018-02-11 21:42:27 --> URI Class Initialized
INFO - 2018-02-11 21:42:27 --> Router Class Initialized
INFO - 2018-02-11 21:42:27 --> Output Class Initialized
INFO - 2018-02-11 21:42:27 --> Security Class Initialized
DEBUG - 2018-02-11 21:42:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 21:42:27 --> Input Class Initialized
INFO - 2018-02-11 21:42:27 --> Language Class Initialized
INFO - 2018-02-11 21:42:27 --> Loader Class Initialized
INFO - 2018-02-11 21:42:27 --> Helper loaded: url_helper
INFO - 2018-02-11 21:42:27 --> Helper loaded: form_helper
INFO - 2018-02-11 21:42:27 --> Database Driver Class Initialized
DEBUG - 2018-02-11 21:42:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 21:42:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 21:42:27 --> Form Validation Class Initialized
INFO - 2018-02-11 21:42:27 --> Model Class Initialized
INFO - 2018-02-11 21:42:27 --> Controller Class Initialized
INFO - 2018-02-11 21:42:27 --> Model Class Initialized
INFO - 2018-02-11 21:42:27 --> Model Class Initialized
INFO - 2018-02-11 21:42:27 --> Model Class Initialized
INFO - 2018-02-11 21:42:27 --> Model Class Initialized
INFO - 2018-02-11 21:42:27 --> Model Class Initialized
DEBUG - 2018-02-11 21:42:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 21:42:27 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-11 21:42:27 --> Final output sent to browser
DEBUG - 2018-02-11 21:42:27 --> Total execution time: 0.0590
INFO - 2018-02-11 21:42:27 --> Config Class Initialized
INFO - 2018-02-11 21:42:27 --> Hooks Class Initialized
DEBUG - 2018-02-11 21:42:27 --> UTF-8 Support Enabled
INFO - 2018-02-11 21:42:27 --> Utf8 Class Initialized
INFO - 2018-02-11 21:42:27 --> URI Class Initialized
INFO - 2018-02-11 21:42:27 --> Router Class Initialized
INFO - 2018-02-11 21:42:27 --> Output Class Initialized
INFO - 2018-02-11 21:42:27 --> Security Class Initialized
DEBUG - 2018-02-11 21:42:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 21:42:27 --> Input Class Initialized
INFO - 2018-02-11 21:42:27 --> Language Class Initialized
INFO - 2018-02-11 21:42:27 --> Loader Class Initialized
INFO - 2018-02-11 21:42:27 --> Helper loaded: url_helper
INFO - 2018-02-11 21:42:27 --> Helper loaded: form_helper
INFO - 2018-02-11 21:42:27 --> Database Driver Class Initialized
DEBUG - 2018-02-11 21:42:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 21:42:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 21:42:27 --> Form Validation Class Initialized
INFO - 2018-02-11 21:42:27 --> Model Class Initialized
INFO - 2018-02-11 21:42:27 --> Controller Class Initialized
INFO - 2018-02-11 21:42:27 --> Model Class Initialized
INFO - 2018-02-11 21:42:27 --> Model Class Initialized
INFO - 2018-02-11 21:42:27 --> Model Class Initialized
INFO - 2018-02-11 21:42:27 --> Model Class Initialized
INFO - 2018-02-11 21:42:27 --> Model Class Initialized
DEBUG - 2018-02-11 21:42:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 21:42:30 --> Config Class Initialized
INFO - 2018-02-11 21:42:30 --> Hooks Class Initialized
DEBUG - 2018-02-11 21:42:30 --> UTF-8 Support Enabled
INFO - 2018-02-11 21:42:30 --> Utf8 Class Initialized
INFO - 2018-02-11 21:42:30 --> URI Class Initialized
INFO - 2018-02-11 21:42:30 --> Router Class Initialized
INFO - 2018-02-11 21:42:30 --> Output Class Initialized
INFO - 2018-02-11 21:42:30 --> Security Class Initialized
DEBUG - 2018-02-11 21:42:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 21:42:30 --> Input Class Initialized
INFO - 2018-02-11 21:42:30 --> Language Class Initialized
INFO - 2018-02-11 21:42:30 --> Loader Class Initialized
INFO - 2018-02-11 21:42:30 --> Helper loaded: url_helper
INFO - 2018-02-11 21:42:30 --> Helper loaded: form_helper
INFO - 2018-02-11 21:42:30 --> Database Driver Class Initialized
DEBUG - 2018-02-11 21:42:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 21:42:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 21:42:30 --> Form Validation Class Initialized
INFO - 2018-02-11 21:42:30 --> Model Class Initialized
INFO - 2018-02-11 21:42:30 --> Controller Class Initialized
INFO - 2018-02-11 21:42:30 --> Model Class Initialized
INFO - 2018-02-11 21:42:30 --> Model Class Initialized
INFO - 2018-02-11 21:42:30 --> Model Class Initialized
INFO - 2018-02-11 21:42:30 --> Model Class Initialized
INFO - 2018-02-11 21:42:30 --> Model Class Initialized
DEBUG - 2018-02-11 21:42:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 21:42:30 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-11 21:42:30 --> Final output sent to browser
DEBUG - 2018-02-11 21:42:30 --> Total execution time: 0.0775
INFO - 2018-02-11 21:42:30 --> Config Class Initialized
INFO - 2018-02-11 21:42:30 --> Hooks Class Initialized
DEBUG - 2018-02-11 21:42:30 --> UTF-8 Support Enabled
INFO - 2018-02-11 21:42:30 --> Utf8 Class Initialized
INFO - 2018-02-11 21:42:30 --> URI Class Initialized
INFO - 2018-02-11 21:42:30 --> Router Class Initialized
INFO - 2018-02-11 21:42:30 --> Output Class Initialized
INFO - 2018-02-11 21:42:30 --> Security Class Initialized
DEBUG - 2018-02-11 21:42:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 21:42:30 --> Input Class Initialized
INFO - 2018-02-11 21:42:30 --> Language Class Initialized
INFO - 2018-02-11 21:42:30 --> Loader Class Initialized
INFO - 2018-02-11 21:42:30 --> Helper loaded: url_helper
INFO - 2018-02-11 21:42:30 --> Helper loaded: form_helper
INFO - 2018-02-11 21:42:30 --> Database Driver Class Initialized
DEBUG - 2018-02-11 21:42:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 21:42:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 21:42:30 --> Form Validation Class Initialized
INFO - 2018-02-11 21:42:30 --> Model Class Initialized
INFO - 2018-02-11 21:42:30 --> Controller Class Initialized
INFO - 2018-02-11 21:42:30 --> Model Class Initialized
INFO - 2018-02-11 21:42:30 --> Model Class Initialized
INFO - 2018-02-11 21:42:30 --> Model Class Initialized
INFO - 2018-02-11 21:42:30 --> Model Class Initialized
INFO - 2018-02-11 21:42:30 --> Model Class Initialized
DEBUG - 2018-02-11 21:42:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 21:42:33 --> Config Class Initialized
INFO - 2018-02-11 21:42:33 --> Hooks Class Initialized
DEBUG - 2018-02-11 21:42:33 --> UTF-8 Support Enabled
INFO - 2018-02-11 21:42:33 --> Utf8 Class Initialized
INFO - 2018-02-11 21:42:33 --> URI Class Initialized
INFO - 2018-02-11 21:42:33 --> Router Class Initialized
INFO - 2018-02-11 21:42:33 --> Output Class Initialized
INFO - 2018-02-11 21:42:33 --> Security Class Initialized
DEBUG - 2018-02-11 21:42:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 21:42:33 --> Input Class Initialized
INFO - 2018-02-11 21:42:33 --> Language Class Initialized
INFO - 2018-02-11 21:42:33 --> Loader Class Initialized
INFO - 2018-02-11 21:42:33 --> Helper loaded: url_helper
INFO - 2018-02-11 21:42:33 --> Helper loaded: form_helper
INFO - 2018-02-11 21:42:33 --> Database Driver Class Initialized
DEBUG - 2018-02-11 21:42:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 21:42:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 21:42:33 --> Form Validation Class Initialized
INFO - 2018-02-11 21:42:33 --> Model Class Initialized
INFO - 2018-02-11 21:42:33 --> Controller Class Initialized
INFO - 2018-02-11 21:42:33 --> Model Class Initialized
INFO - 2018-02-11 21:42:33 --> Model Class Initialized
INFO - 2018-02-11 21:42:33 --> Model Class Initialized
INFO - 2018-02-11 21:42:33 --> Model Class Initialized
INFO - 2018-02-11 21:42:33 --> Model Class Initialized
DEBUG - 2018-02-11 21:42:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 21:42:33 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-11 21:42:33 --> Final output sent to browser
DEBUG - 2018-02-11 21:42:33 --> Total execution time: 0.0775
INFO - 2018-02-11 21:42:33 --> Config Class Initialized
INFO - 2018-02-11 21:42:33 --> Hooks Class Initialized
DEBUG - 2018-02-11 21:42:33 --> UTF-8 Support Enabled
INFO - 2018-02-11 21:42:33 --> Utf8 Class Initialized
INFO - 2018-02-11 21:42:33 --> URI Class Initialized
INFO - 2018-02-11 21:42:33 --> Router Class Initialized
INFO - 2018-02-11 21:42:33 --> Output Class Initialized
INFO - 2018-02-11 21:42:33 --> Security Class Initialized
DEBUG - 2018-02-11 21:42:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 21:42:33 --> Input Class Initialized
INFO - 2018-02-11 21:42:33 --> Language Class Initialized
INFO - 2018-02-11 21:42:33 --> Loader Class Initialized
INFO - 2018-02-11 21:42:33 --> Helper loaded: url_helper
INFO - 2018-02-11 21:42:33 --> Helper loaded: form_helper
INFO - 2018-02-11 21:42:33 --> Database Driver Class Initialized
DEBUG - 2018-02-11 21:42:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 21:42:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 21:42:33 --> Form Validation Class Initialized
INFO - 2018-02-11 21:42:33 --> Model Class Initialized
INFO - 2018-02-11 21:42:33 --> Controller Class Initialized
INFO - 2018-02-11 21:42:33 --> Model Class Initialized
INFO - 2018-02-11 21:42:33 --> Model Class Initialized
INFO - 2018-02-11 21:42:33 --> Model Class Initialized
INFO - 2018-02-11 21:42:33 --> Model Class Initialized
INFO - 2018-02-11 21:42:33 --> Model Class Initialized
DEBUG - 2018-02-11 21:42:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 21:42:35 --> Config Class Initialized
INFO - 2018-02-11 21:42:35 --> Hooks Class Initialized
DEBUG - 2018-02-11 21:42:35 --> UTF-8 Support Enabled
INFO - 2018-02-11 21:42:35 --> Utf8 Class Initialized
INFO - 2018-02-11 21:42:35 --> URI Class Initialized
INFO - 2018-02-11 21:42:35 --> Router Class Initialized
INFO - 2018-02-11 21:42:35 --> Output Class Initialized
INFO - 2018-02-11 21:42:35 --> Security Class Initialized
DEBUG - 2018-02-11 21:42:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 21:42:35 --> Input Class Initialized
INFO - 2018-02-11 21:42:35 --> Language Class Initialized
INFO - 2018-02-11 21:42:35 --> Loader Class Initialized
INFO - 2018-02-11 21:42:35 --> Helper loaded: url_helper
INFO - 2018-02-11 21:42:35 --> Helper loaded: form_helper
INFO - 2018-02-11 21:42:35 --> Database Driver Class Initialized
DEBUG - 2018-02-11 21:42:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 21:42:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 21:42:35 --> Form Validation Class Initialized
INFO - 2018-02-11 21:42:35 --> Model Class Initialized
INFO - 2018-02-11 21:42:35 --> Controller Class Initialized
INFO - 2018-02-11 21:42:35 --> Model Class Initialized
INFO - 2018-02-11 21:42:35 --> Model Class Initialized
INFO - 2018-02-11 21:42:35 --> Model Class Initialized
INFO - 2018-02-11 21:42:35 --> Model Class Initialized
INFO - 2018-02-11 21:42:35 --> Model Class Initialized
DEBUG - 2018-02-11 21:42:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 21:42:35 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-11 21:42:35 --> Final output sent to browser
DEBUG - 2018-02-11 21:42:35 --> Total execution time: 0.0665
INFO - 2018-02-11 21:42:35 --> Config Class Initialized
INFO - 2018-02-11 21:42:35 --> Hooks Class Initialized
DEBUG - 2018-02-11 21:42:35 --> UTF-8 Support Enabled
INFO - 2018-02-11 21:42:35 --> Utf8 Class Initialized
INFO - 2018-02-11 21:42:35 --> URI Class Initialized
INFO - 2018-02-11 21:42:35 --> Router Class Initialized
INFO - 2018-02-11 21:42:35 --> Output Class Initialized
INFO - 2018-02-11 21:42:35 --> Security Class Initialized
DEBUG - 2018-02-11 21:42:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 21:42:35 --> Input Class Initialized
INFO - 2018-02-11 21:42:35 --> Language Class Initialized
INFO - 2018-02-11 21:42:35 --> Loader Class Initialized
INFO - 2018-02-11 21:42:35 --> Helper loaded: url_helper
INFO - 2018-02-11 21:42:35 --> Helper loaded: form_helper
INFO - 2018-02-11 21:42:35 --> Database Driver Class Initialized
DEBUG - 2018-02-11 21:42:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 21:42:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 21:42:35 --> Form Validation Class Initialized
INFO - 2018-02-11 21:42:35 --> Model Class Initialized
INFO - 2018-02-11 21:42:35 --> Controller Class Initialized
INFO - 2018-02-11 21:42:35 --> Model Class Initialized
INFO - 2018-02-11 21:42:35 --> Model Class Initialized
INFO - 2018-02-11 21:42:35 --> Model Class Initialized
INFO - 2018-02-11 21:42:35 --> Model Class Initialized
INFO - 2018-02-11 21:42:35 --> Model Class Initialized
DEBUG - 2018-02-11 21:42:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 21:42:41 --> Config Class Initialized
INFO - 2018-02-11 21:42:41 --> Hooks Class Initialized
INFO - 2018-02-11 21:42:41 --> Config Class Initialized
INFO - 2018-02-11 21:42:41 --> Config Class Initialized
INFO - 2018-02-11 21:42:41 --> Hooks Class Initialized
INFO - 2018-02-11 21:42:41 --> Hooks Class Initialized
DEBUG - 2018-02-11 21:42:41 --> UTF-8 Support Enabled
DEBUG - 2018-02-11 21:42:41 --> UTF-8 Support Enabled
INFO - 2018-02-11 21:42:41 --> Utf8 Class Initialized
DEBUG - 2018-02-11 21:42:41 --> UTF-8 Support Enabled
INFO - 2018-02-11 21:42:41 --> Utf8 Class Initialized
INFO - 2018-02-11 21:42:41 --> Utf8 Class Initialized
INFO - 2018-02-11 21:42:41 --> URI Class Initialized
INFO - 2018-02-11 21:42:41 --> URI Class Initialized
INFO - 2018-02-11 21:42:41 --> URI Class Initialized
INFO - 2018-02-11 21:42:41 --> Router Class Initialized
INFO - 2018-02-11 21:42:41 --> Router Class Initialized
INFO - 2018-02-11 21:42:41 --> Router Class Initialized
INFO - 2018-02-11 21:42:41 --> Output Class Initialized
INFO - 2018-02-11 21:42:41 --> Output Class Initialized
INFO - 2018-02-11 21:42:41 --> Output Class Initialized
INFO - 2018-02-11 21:42:41 --> Security Class Initialized
INFO - 2018-02-11 21:42:41 --> Security Class Initialized
INFO - 2018-02-11 21:42:41 --> Security Class Initialized
DEBUG - 2018-02-11 21:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 21:42:41 --> Input Class Initialized
DEBUG - 2018-02-11 21:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 21:42:41 --> Input Class Initialized
DEBUG - 2018-02-11 21:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 21:42:41 --> Language Class Initialized
INFO - 2018-02-11 21:42:41 --> Input Class Initialized
INFO - 2018-02-11 21:42:41 --> Language Class Initialized
INFO - 2018-02-11 21:42:41 --> Language Class Initialized
ERROR - 2018-02-11 21:42:41 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-11 21:42:41 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-11 21:42:41 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-11 21:43:44 --> Config Class Initialized
INFO - 2018-02-11 21:43:44 --> Hooks Class Initialized
DEBUG - 2018-02-11 21:43:44 --> UTF-8 Support Enabled
INFO - 2018-02-11 21:43:44 --> Utf8 Class Initialized
INFO - 2018-02-11 21:43:44 --> URI Class Initialized
INFO - 2018-02-11 21:43:44 --> Router Class Initialized
INFO - 2018-02-11 21:43:44 --> Output Class Initialized
INFO - 2018-02-11 21:43:44 --> Security Class Initialized
DEBUG - 2018-02-11 21:43:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 21:43:44 --> Input Class Initialized
INFO - 2018-02-11 21:43:44 --> Language Class Initialized
INFO - 2018-02-11 21:43:44 --> Loader Class Initialized
INFO - 2018-02-11 21:43:44 --> Helper loaded: url_helper
INFO - 2018-02-11 21:43:44 --> Helper loaded: form_helper
INFO - 2018-02-11 21:43:44 --> Database Driver Class Initialized
DEBUG - 2018-02-11 21:43:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 21:43:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 21:43:44 --> Form Validation Class Initialized
INFO - 2018-02-11 21:43:44 --> Model Class Initialized
INFO - 2018-02-11 21:43:44 --> Controller Class Initialized
INFO - 2018-02-11 21:43:44 --> Model Class Initialized
INFO - 2018-02-11 21:43:44 --> Model Class Initialized
INFO - 2018-02-11 21:43:44 --> Model Class Initialized
INFO - 2018-02-11 21:43:44 --> Model Class Initialized
INFO - 2018-02-11 21:43:44 --> Model Class Initialized
DEBUG - 2018-02-11 21:43:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 21:43:44 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-11 21:43:44 --> Final output sent to browser
DEBUG - 2018-02-11 21:43:44 --> Total execution time: 0.0612
INFO - 2018-02-11 21:43:44 --> Config Class Initialized
INFO - 2018-02-11 21:43:44 --> Config Class Initialized
INFO - 2018-02-11 21:43:44 --> Hooks Class Initialized
INFO - 2018-02-11 21:43:44 --> Hooks Class Initialized
INFO - 2018-02-11 21:43:44 --> Config Class Initialized
INFO - 2018-02-11 21:43:44 --> Hooks Class Initialized
DEBUG - 2018-02-11 21:43:44 --> UTF-8 Support Enabled
DEBUG - 2018-02-11 21:43:44 --> UTF-8 Support Enabled
INFO - 2018-02-11 21:43:44 --> Utf8 Class Initialized
DEBUG - 2018-02-11 21:43:44 --> UTF-8 Support Enabled
INFO - 2018-02-11 21:43:44 --> Utf8 Class Initialized
INFO - 2018-02-11 21:43:44 --> Utf8 Class Initialized
INFO - 2018-02-11 21:43:44 --> URI Class Initialized
INFO - 2018-02-11 21:43:44 --> URI Class Initialized
INFO - 2018-02-11 21:43:44 --> URI Class Initialized
INFO - 2018-02-11 21:43:44 --> Router Class Initialized
INFO - 2018-02-11 21:43:44 --> Router Class Initialized
INFO - 2018-02-11 21:43:44 --> Router Class Initialized
INFO - 2018-02-11 21:43:44 --> Output Class Initialized
INFO - 2018-02-11 21:43:44 --> Output Class Initialized
INFO - 2018-02-11 21:43:44 --> Output Class Initialized
INFO - 2018-02-11 21:43:44 --> Security Class Initialized
INFO - 2018-02-11 21:43:44 --> Security Class Initialized
INFO - 2018-02-11 21:43:44 --> Security Class Initialized
DEBUG - 2018-02-11 21:43:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-11 21:43:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 21:43:44 --> Input Class Initialized
DEBUG - 2018-02-11 21:43:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 21:43:44 --> Input Class Initialized
INFO - 2018-02-11 21:43:44 --> Input Class Initialized
INFO - 2018-02-11 21:43:44 --> Language Class Initialized
INFO - 2018-02-11 21:43:44 --> Language Class Initialized
INFO - 2018-02-11 21:43:44 --> Language Class Initialized
ERROR - 2018-02-11 21:43:44 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-11 21:43:44 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-11 21:43:44 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-11 21:43:44 --> Config Class Initialized
INFO - 2018-02-11 21:43:44 --> Hooks Class Initialized
DEBUG - 2018-02-11 21:43:44 --> UTF-8 Support Enabled
INFO - 2018-02-11 21:43:44 --> Utf8 Class Initialized
INFO - 2018-02-11 21:43:44 --> URI Class Initialized
INFO - 2018-02-11 21:43:44 --> Router Class Initialized
INFO - 2018-02-11 21:43:44 --> Output Class Initialized
INFO - 2018-02-11 21:43:44 --> Security Class Initialized
DEBUG - 2018-02-11 21:43:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 21:43:44 --> Input Class Initialized
INFO - 2018-02-11 21:43:44 --> Language Class Initialized
ERROR - 2018-02-11 21:43:44 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-11 21:43:44 --> Config Class Initialized
INFO - 2018-02-11 21:43:44 --> Hooks Class Initialized
INFO - 2018-02-11 21:43:44 --> Config Class Initialized
INFO - 2018-02-11 21:43:44 --> Hooks Class Initialized
INFO - 2018-02-11 21:43:44 --> Config Class Initialized
DEBUG - 2018-02-11 21:43:44 --> UTF-8 Support Enabled
INFO - 2018-02-11 21:43:44 --> Hooks Class Initialized
INFO - 2018-02-11 21:43:44 --> Utf8 Class Initialized
INFO - 2018-02-11 21:43:44 --> URI Class Initialized
DEBUG - 2018-02-11 21:43:44 --> UTF-8 Support Enabled
DEBUG - 2018-02-11 21:43:44 --> UTF-8 Support Enabled
INFO - 2018-02-11 21:43:44 --> Utf8 Class Initialized
INFO - 2018-02-11 21:43:44 --> Utf8 Class Initialized
INFO - 2018-02-11 21:43:44 --> Router Class Initialized
INFO - 2018-02-11 21:43:44 --> URI Class Initialized
INFO - 2018-02-11 21:43:44 --> URI Class Initialized
INFO - 2018-02-11 21:43:44 --> Output Class Initialized
INFO - 2018-02-11 21:43:44 --> Router Class Initialized
INFO - 2018-02-11 21:43:44 --> Router Class Initialized
INFO - 2018-02-11 21:43:44 --> Security Class Initialized
INFO - 2018-02-11 21:43:44 --> Output Class Initialized
DEBUG - 2018-02-11 21:43:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 21:43:44 --> Output Class Initialized
INFO - 2018-02-11 21:43:44 --> Input Class Initialized
INFO - 2018-02-11 21:43:44 --> Language Class Initialized
INFO - 2018-02-11 21:43:44 --> Security Class Initialized
INFO - 2018-02-11 21:43:44 --> Security Class Initialized
ERROR - 2018-02-11 21:43:44 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-02-11 21:43:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-11 21:43:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 21:43:44 --> Input Class Initialized
INFO - 2018-02-11 21:43:44 --> Input Class Initialized
INFO - 2018-02-11 21:43:44 --> Language Class Initialized
INFO - 2018-02-11 21:43:44 --> Language Class Initialized
ERROR - 2018-02-11 21:43:44 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-11 21:43:44 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-11 21:43:44 --> Config Class Initialized
INFO - 2018-02-11 21:43:44 --> Hooks Class Initialized
DEBUG - 2018-02-11 21:43:44 --> UTF-8 Support Enabled
INFO - 2018-02-11 21:43:44 --> Utf8 Class Initialized
INFO - 2018-02-11 21:43:44 --> URI Class Initialized
INFO - 2018-02-11 21:43:44 --> Router Class Initialized
INFO - 2018-02-11 21:43:44 --> Output Class Initialized
INFO - 2018-02-11 21:43:44 --> Security Class Initialized
DEBUG - 2018-02-11 21:43:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 21:43:44 --> Input Class Initialized
INFO - 2018-02-11 21:43:44 --> Language Class Initialized
INFO - 2018-02-11 21:43:44 --> Loader Class Initialized
INFO - 2018-02-11 21:43:44 --> Helper loaded: url_helper
INFO - 2018-02-11 21:43:45 --> Helper loaded: form_helper
INFO - 2018-02-11 21:43:45 --> Database Driver Class Initialized
DEBUG - 2018-02-11 21:43:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 21:43:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 21:43:45 --> Form Validation Class Initialized
INFO - 2018-02-11 21:43:45 --> Model Class Initialized
INFO - 2018-02-11 21:43:45 --> Controller Class Initialized
INFO - 2018-02-11 21:43:45 --> Model Class Initialized
INFO - 2018-02-11 21:43:45 --> Model Class Initialized
INFO - 2018-02-11 21:43:45 --> Model Class Initialized
INFO - 2018-02-11 21:43:45 --> Model Class Initialized
INFO - 2018-02-11 21:43:45 --> Model Class Initialized
DEBUG - 2018-02-11 21:43:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 21:43:54 --> Config Class Initialized
INFO - 2018-02-11 21:43:54 --> Hooks Class Initialized
DEBUG - 2018-02-11 21:43:54 --> UTF-8 Support Enabled
INFO - 2018-02-11 21:43:54 --> Utf8 Class Initialized
INFO - 2018-02-11 21:43:54 --> URI Class Initialized
INFO - 2018-02-11 21:43:54 --> Router Class Initialized
INFO - 2018-02-11 21:43:54 --> Output Class Initialized
INFO - 2018-02-11 21:43:54 --> Security Class Initialized
DEBUG - 2018-02-11 21:43:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 21:43:54 --> Input Class Initialized
INFO - 2018-02-11 21:43:54 --> Language Class Initialized
INFO - 2018-02-11 21:43:54 --> Loader Class Initialized
INFO - 2018-02-11 21:43:54 --> Helper loaded: url_helper
INFO - 2018-02-11 21:43:54 --> Helper loaded: form_helper
INFO - 2018-02-11 21:43:54 --> Database Driver Class Initialized
DEBUG - 2018-02-11 21:43:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 21:43:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 21:43:54 --> Form Validation Class Initialized
INFO - 2018-02-11 21:43:54 --> Model Class Initialized
INFO - 2018-02-11 21:43:54 --> Controller Class Initialized
INFO - 2018-02-11 21:43:54 --> Model Class Initialized
INFO - 2018-02-11 21:43:54 --> Model Class Initialized
INFO - 2018-02-11 21:43:54 --> Model Class Initialized
INFO - 2018-02-11 21:43:54 --> Model Class Initialized
INFO - 2018-02-11 21:43:54 --> Model Class Initialized
DEBUG - 2018-02-11 21:43:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 21:43:54 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-11 21:43:54 --> Final output sent to browser
DEBUG - 2018-02-11 21:43:54 --> Total execution time: 0.0547
INFO - 2018-02-11 21:43:54 --> Config Class Initialized
INFO - 2018-02-11 21:43:54 --> Hooks Class Initialized
INFO - 2018-02-11 21:43:54 --> Config Class Initialized
INFO - 2018-02-11 21:43:54 --> Hooks Class Initialized
INFO - 2018-02-11 21:43:54 --> Config Class Initialized
INFO - 2018-02-11 21:43:54 --> Hooks Class Initialized
DEBUG - 2018-02-11 21:43:54 --> UTF-8 Support Enabled
INFO - 2018-02-11 21:43:54 --> Utf8 Class Initialized
DEBUG - 2018-02-11 21:43:54 --> UTF-8 Support Enabled
INFO - 2018-02-11 21:43:54 --> Config Class Initialized
INFO - 2018-02-11 21:43:54 --> Utf8 Class Initialized
INFO - 2018-02-11 21:43:54 --> URI Class Initialized
INFO - 2018-02-11 21:43:54 --> Hooks Class Initialized
DEBUG - 2018-02-11 21:43:54 --> UTF-8 Support Enabled
INFO - 2018-02-11 21:43:54 --> URI Class Initialized
INFO - 2018-02-11 21:43:54 --> Utf8 Class Initialized
INFO - 2018-02-11 21:43:54 --> Router Class Initialized
INFO - 2018-02-11 21:43:54 --> URI Class Initialized
INFO - 2018-02-11 21:43:54 --> Router Class Initialized
DEBUG - 2018-02-11 21:43:54 --> UTF-8 Support Enabled
INFO - 2018-02-11 21:43:54 --> Utf8 Class Initialized
INFO - 2018-02-11 21:43:54 --> Output Class Initialized
INFO - 2018-02-11 21:43:54 --> Router Class Initialized
INFO - 2018-02-11 21:43:54 --> URI Class Initialized
INFO - 2018-02-11 21:43:54 --> Output Class Initialized
INFO - 2018-02-11 21:43:54 --> Security Class Initialized
INFO - 2018-02-11 21:43:54 --> Output Class Initialized
INFO - 2018-02-11 21:43:54 --> Security Class Initialized
INFO - 2018-02-11 21:43:54 --> Router Class Initialized
DEBUG - 2018-02-11 21:43:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 21:43:54 --> Input Class Initialized
INFO - 2018-02-11 21:43:54 --> Security Class Initialized
DEBUG - 2018-02-11 21:43:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 21:43:54 --> Input Class Initialized
INFO - 2018-02-11 21:43:54 --> Language Class Initialized
INFO - 2018-02-11 21:43:54 --> Output Class Initialized
DEBUG - 2018-02-11 21:43:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 21:43:54 --> Language Class Initialized
INFO - 2018-02-11 21:43:54 --> Input Class Initialized
ERROR - 2018-02-11 21:43:54 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-11 21:43:54 --> Language Class Initialized
INFO - 2018-02-11 21:43:54 --> Security Class Initialized
ERROR - 2018-02-11 21:43:54 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-11 21:43:54 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-02-11 21:43:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 21:43:54 --> Input Class Initialized
INFO - 2018-02-11 21:43:54 --> Language Class Initialized
ERROR - 2018-02-11 21:43:54 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-11 21:43:54 --> Config Class Initialized
INFO - 2018-02-11 21:43:54 --> Hooks Class Initialized
INFO - 2018-02-11 21:43:54 --> Config Class Initialized
INFO - 2018-02-11 21:43:54 --> Hooks Class Initialized
INFO - 2018-02-11 21:43:54 --> Config Class Initialized
INFO - 2018-02-11 21:43:54 --> Hooks Class Initialized
DEBUG - 2018-02-11 21:43:54 --> UTF-8 Support Enabled
DEBUG - 2018-02-11 21:43:54 --> UTF-8 Support Enabled
INFO - 2018-02-11 21:43:54 --> Utf8 Class Initialized
INFO - 2018-02-11 21:43:54 --> Utf8 Class Initialized
DEBUG - 2018-02-11 21:43:54 --> UTF-8 Support Enabled
INFO - 2018-02-11 21:43:54 --> Utf8 Class Initialized
INFO - 2018-02-11 21:43:54 --> URI Class Initialized
INFO - 2018-02-11 21:43:54 --> URI Class Initialized
INFO - 2018-02-11 21:43:54 --> URI Class Initialized
INFO - 2018-02-11 21:43:54 --> Router Class Initialized
INFO - 2018-02-11 21:43:54 --> Router Class Initialized
INFO - 2018-02-11 21:43:54 --> Router Class Initialized
INFO - 2018-02-11 21:43:54 --> Output Class Initialized
INFO - 2018-02-11 21:43:54 --> Output Class Initialized
INFO - 2018-02-11 21:43:54 --> Output Class Initialized
INFO - 2018-02-11 21:43:54 --> Security Class Initialized
INFO - 2018-02-11 21:43:54 --> Security Class Initialized
INFO - 2018-02-11 21:43:54 --> Security Class Initialized
DEBUG - 2018-02-11 21:43:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-11 21:43:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 21:43:54 --> Input Class Initialized
DEBUG - 2018-02-11 21:43:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 21:43:54 --> Input Class Initialized
INFO - 2018-02-11 21:43:54 --> Input Class Initialized
INFO - 2018-02-11 21:43:54 --> Language Class Initialized
INFO - 2018-02-11 21:43:54 --> Language Class Initialized
INFO - 2018-02-11 21:43:54 --> Language Class Initialized
ERROR - 2018-02-11 21:43:54 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-11 21:43:54 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-11 21:43:54 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-11 21:43:54 --> Config Class Initialized
INFO - 2018-02-11 21:43:54 --> Hooks Class Initialized
DEBUG - 2018-02-11 21:43:54 --> UTF-8 Support Enabled
INFO - 2018-02-11 21:43:54 --> Utf8 Class Initialized
INFO - 2018-02-11 21:43:54 --> URI Class Initialized
INFO - 2018-02-11 21:43:54 --> Router Class Initialized
INFO - 2018-02-11 21:43:54 --> Output Class Initialized
INFO - 2018-02-11 21:43:54 --> Security Class Initialized
DEBUG - 2018-02-11 21:43:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 21:43:54 --> Input Class Initialized
INFO - 2018-02-11 21:43:54 --> Language Class Initialized
INFO - 2018-02-11 21:43:54 --> Loader Class Initialized
INFO - 2018-02-11 21:43:54 --> Helper loaded: url_helper
INFO - 2018-02-11 21:43:54 --> Helper loaded: form_helper
INFO - 2018-02-11 21:43:54 --> Database Driver Class Initialized
DEBUG - 2018-02-11 21:43:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 21:43:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 21:43:54 --> Form Validation Class Initialized
INFO - 2018-02-11 21:43:54 --> Model Class Initialized
INFO - 2018-02-11 21:43:54 --> Controller Class Initialized
INFO - 2018-02-11 21:43:54 --> Model Class Initialized
INFO - 2018-02-11 21:43:54 --> Model Class Initialized
INFO - 2018-02-11 21:43:54 --> Model Class Initialized
INFO - 2018-02-11 21:43:54 --> Model Class Initialized
INFO - 2018-02-11 21:43:54 --> Model Class Initialized
DEBUG - 2018-02-11 21:43:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 21:44:34 --> Config Class Initialized
INFO - 2018-02-11 21:44:34 --> Hooks Class Initialized
DEBUG - 2018-02-11 21:44:34 --> UTF-8 Support Enabled
INFO - 2018-02-11 21:44:34 --> Utf8 Class Initialized
INFO - 2018-02-11 21:44:34 --> URI Class Initialized
INFO - 2018-02-11 21:44:34 --> Router Class Initialized
INFO - 2018-02-11 21:44:34 --> Output Class Initialized
INFO - 2018-02-11 21:44:34 --> Security Class Initialized
DEBUG - 2018-02-11 21:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 21:44:34 --> Input Class Initialized
INFO - 2018-02-11 21:44:34 --> Language Class Initialized
INFO - 2018-02-11 21:44:34 --> Loader Class Initialized
INFO - 2018-02-11 21:44:34 --> Helper loaded: url_helper
INFO - 2018-02-11 21:44:34 --> Helper loaded: form_helper
INFO - 2018-02-11 21:44:34 --> Database Driver Class Initialized
DEBUG - 2018-02-11 21:44:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 21:44:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 21:44:34 --> Form Validation Class Initialized
INFO - 2018-02-11 21:44:34 --> Model Class Initialized
INFO - 2018-02-11 21:44:34 --> Controller Class Initialized
INFO - 2018-02-11 21:44:34 --> Model Class Initialized
INFO - 2018-02-11 21:44:34 --> Model Class Initialized
INFO - 2018-02-11 21:44:34 --> Model Class Initialized
INFO - 2018-02-11 21:44:34 --> Model Class Initialized
INFO - 2018-02-11 21:44:34 --> Model Class Initialized
DEBUG - 2018-02-11 21:44:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 21:44:34 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-11 21:44:34 --> Final output sent to browser
DEBUG - 2018-02-11 21:44:34 --> Total execution time: 0.0718
INFO - 2018-02-11 21:44:34 --> Config Class Initialized
INFO - 2018-02-11 21:44:34 --> Hooks Class Initialized
INFO - 2018-02-11 21:44:34 --> Config Class Initialized
INFO - 2018-02-11 21:44:34 --> Hooks Class Initialized
INFO - 2018-02-11 21:44:34 --> Config Class Initialized
INFO - 2018-02-11 21:44:34 --> Hooks Class Initialized
DEBUG - 2018-02-11 21:44:34 --> UTF-8 Support Enabled
INFO - 2018-02-11 21:44:34 --> Utf8 Class Initialized
INFO - 2018-02-11 21:44:34 --> URI Class Initialized
DEBUG - 2018-02-11 21:44:34 --> UTF-8 Support Enabled
INFO - 2018-02-11 21:44:34 --> Utf8 Class Initialized
DEBUG - 2018-02-11 21:44:34 --> UTF-8 Support Enabled
INFO - 2018-02-11 21:44:34 --> Utf8 Class Initialized
INFO - 2018-02-11 21:44:34 --> Router Class Initialized
INFO - 2018-02-11 21:44:34 --> URI Class Initialized
INFO - 2018-02-11 21:44:34 --> URI Class Initialized
INFO - 2018-02-11 21:44:34 --> Output Class Initialized
INFO - 2018-02-11 21:44:34 --> Router Class Initialized
INFO - 2018-02-11 21:44:34 --> Router Class Initialized
INFO - 2018-02-11 21:44:34 --> Security Class Initialized
INFO - 2018-02-11 21:44:34 --> Output Class Initialized
INFO - 2018-02-11 21:44:34 --> Output Class Initialized
DEBUG - 2018-02-11 21:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 21:44:34 --> Input Class Initialized
INFO - 2018-02-11 21:44:34 --> Security Class Initialized
INFO - 2018-02-11 21:44:34 --> Language Class Initialized
INFO - 2018-02-11 21:44:34 --> Security Class Initialized
DEBUG - 2018-02-11 21:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 21:44:34 --> Input Class Initialized
ERROR - 2018-02-11 21:44:34 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-11 21:44:34 --> Language Class Initialized
DEBUG - 2018-02-11 21:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 21:44:34 --> Input Class Initialized
INFO - 2018-02-11 21:44:34 --> Language Class Initialized
ERROR - 2018-02-11 21:44:34 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-11 21:44:34 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-11 21:44:34 --> Config Class Initialized
INFO - 2018-02-11 21:44:34 --> Hooks Class Initialized
DEBUG - 2018-02-11 21:44:34 --> UTF-8 Support Enabled
INFO - 2018-02-11 21:44:34 --> Utf8 Class Initialized
INFO - 2018-02-11 21:44:34 --> URI Class Initialized
INFO - 2018-02-11 21:44:34 --> Router Class Initialized
INFO - 2018-02-11 21:44:34 --> Output Class Initialized
INFO - 2018-02-11 21:44:34 --> Security Class Initialized
DEBUG - 2018-02-11 21:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 21:44:34 --> Input Class Initialized
INFO - 2018-02-11 21:44:34 --> Language Class Initialized
ERROR - 2018-02-11 21:44:34 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-11 21:44:34 --> Config Class Initialized
INFO - 2018-02-11 21:44:34 --> Hooks Class Initialized
INFO - 2018-02-11 21:44:34 --> Config Class Initialized
INFO - 2018-02-11 21:44:34 --> Hooks Class Initialized
DEBUG - 2018-02-11 21:44:34 --> UTF-8 Support Enabled
INFO - 2018-02-11 21:44:34 --> Utf8 Class Initialized
INFO - 2018-02-11 21:44:34 --> Config Class Initialized
DEBUG - 2018-02-11 21:44:34 --> UTF-8 Support Enabled
INFO - 2018-02-11 21:44:34 --> Hooks Class Initialized
INFO - 2018-02-11 21:44:34 --> Utf8 Class Initialized
INFO - 2018-02-11 21:44:34 --> URI Class Initialized
INFO - 2018-02-11 21:44:34 --> URI Class Initialized
INFO - 2018-02-11 21:44:34 --> Router Class Initialized
DEBUG - 2018-02-11 21:44:34 --> UTF-8 Support Enabled
INFO - 2018-02-11 21:44:34 --> Router Class Initialized
INFO - 2018-02-11 21:44:34 --> Utf8 Class Initialized
INFO - 2018-02-11 21:44:34 --> URI Class Initialized
INFO - 2018-02-11 21:44:34 --> Output Class Initialized
INFO - 2018-02-11 21:44:34 --> Output Class Initialized
INFO - 2018-02-11 21:44:34 --> Router Class Initialized
INFO - 2018-02-11 21:44:34 --> Security Class Initialized
INFO - 2018-02-11 21:44:34 --> Security Class Initialized
DEBUG - 2018-02-11 21:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 21:44:34 --> Output Class Initialized
DEBUG - 2018-02-11 21:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 21:44:34 --> Input Class Initialized
INFO - 2018-02-11 21:44:34 --> Input Class Initialized
INFO - 2018-02-11 21:44:34 --> Language Class Initialized
INFO - 2018-02-11 21:44:34 --> Security Class Initialized
INFO - 2018-02-11 21:44:34 --> Language Class Initialized
ERROR - 2018-02-11 21:44:34 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-02-11 21:44:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-11 21:44:34 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-11 21:44:34 --> Input Class Initialized
INFO - 2018-02-11 21:44:34 --> Language Class Initialized
ERROR - 2018-02-11 21:44:34 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-11 21:44:34 --> Config Class Initialized
INFO - 2018-02-11 21:44:34 --> Hooks Class Initialized
DEBUG - 2018-02-11 21:44:34 --> UTF-8 Support Enabled
INFO - 2018-02-11 21:44:34 --> Utf8 Class Initialized
INFO - 2018-02-11 21:44:34 --> URI Class Initialized
INFO - 2018-02-11 21:44:34 --> Router Class Initialized
INFO - 2018-02-11 21:44:34 --> Output Class Initialized
INFO - 2018-02-11 21:44:34 --> Security Class Initialized
DEBUG - 2018-02-11 21:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 21:44:34 --> Input Class Initialized
INFO - 2018-02-11 21:44:34 --> Language Class Initialized
INFO - 2018-02-11 21:44:34 --> Loader Class Initialized
INFO - 2018-02-11 21:44:34 --> Helper loaded: url_helper
INFO - 2018-02-11 21:44:34 --> Helper loaded: form_helper
INFO - 2018-02-11 21:44:34 --> Database Driver Class Initialized
DEBUG - 2018-02-11 21:44:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 21:44:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 21:44:34 --> Form Validation Class Initialized
INFO - 2018-02-11 21:44:34 --> Model Class Initialized
INFO - 2018-02-11 21:44:34 --> Controller Class Initialized
INFO - 2018-02-11 21:44:34 --> Model Class Initialized
INFO - 2018-02-11 21:44:34 --> Model Class Initialized
INFO - 2018-02-11 21:44:34 --> Model Class Initialized
INFO - 2018-02-11 21:44:34 --> Model Class Initialized
INFO - 2018-02-11 21:44:34 --> Model Class Initialized
DEBUG - 2018-02-11 21:44:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 21:49:51 --> Config Class Initialized
INFO - 2018-02-11 21:49:51 --> Hooks Class Initialized
DEBUG - 2018-02-11 21:49:51 --> UTF-8 Support Enabled
INFO - 2018-02-11 21:49:51 --> Utf8 Class Initialized
INFO - 2018-02-11 21:49:51 --> URI Class Initialized
INFO - 2018-02-11 21:49:51 --> Router Class Initialized
INFO - 2018-02-11 21:49:51 --> Output Class Initialized
INFO - 2018-02-11 21:49:51 --> Security Class Initialized
DEBUG - 2018-02-11 21:49:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 21:49:51 --> Input Class Initialized
INFO - 2018-02-11 21:49:51 --> Language Class Initialized
INFO - 2018-02-11 21:49:51 --> Loader Class Initialized
INFO - 2018-02-11 21:49:51 --> Helper loaded: url_helper
INFO - 2018-02-11 21:49:51 --> Helper loaded: form_helper
INFO - 2018-02-11 21:49:51 --> Database Driver Class Initialized
DEBUG - 2018-02-11 21:49:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 21:49:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 21:49:51 --> Form Validation Class Initialized
INFO - 2018-02-11 21:49:51 --> Model Class Initialized
INFO - 2018-02-11 21:49:51 --> Controller Class Initialized
INFO - 2018-02-11 21:49:51 --> Model Class Initialized
INFO - 2018-02-11 21:49:51 --> Model Class Initialized
INFO - 2018-02-11 21:49:51 --> Model Class Initialized
INFO - 2018-02-11 21:49:51 --> Model Class Initialized
INFO - 2018-02-11 21:49:51 --> Model Class Initialized
DEBUG - 2018-02-11 21:49:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 21:49:51 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-11 21:49:51 --> Final output sent to browser
DEBUG - 2018-02-11 21:49:51 --> Total execution time: 0.0861
INFO - 2018-02-11 21:49:51 --> Config Class Initialized
INFO - 2018-02-11 21:49:51 --> Hooks Class Initialized
INFO - 2018-02-11 21:49:51 --> Config Class Initialized
INFO - 2018-02-11 21:49:51 --> Hooks Class Initialized
INFO - 2018-02-11 21:49:51 --> Config Class Initialized
INFO - 2018-02-11 21:49:51 --> Hooks Class Initialized
DEBUG - 2018-02-11 21:49:51 --> UTF-8 Support Enabled
INFO - 2018-02-11 21:49:51 --> Utf8 Class Initialized
DEBUG - 2018-02-11 21:49:51 --> UTF-8 Support Enabled
INFO - 2018-02-11 21:49:51 --> Utf8 Class Initialized
INFO - 2018-02-11 21:49:51 --> URI Class Initialized
DEBUG - 2018-02-11 21:49:51 --> UTF-8 Support Enabled
INFO - 2018-02-11 21:49:51 --> Utf8 Class Initialized
INFO - 2018-02-11 21:49:51 --> URI Class Initialized
INFO - 2018-02-11 21:49:51 --> Router Class Initialized
INFO - 2018-02-11 21:49:51 --> URI Class Initialized
INFO - 2018-02-11 21:49:51 --> Router Class Initialized
INFO - 2018-02-11 21:49:51 --> Output Class Initialized
INFO - 2018-02-11 21:49:51 --> Router Class Initialized
INFO - 2018-02-11 21:49:51 --> Security Class Initialized
INFO - 2018-02-11 21:49:51 --> Output Class Initialized
INFO - 2018-02-11 21:49:51 --> Output Class Initialized
DEBUG - 2018-02-11 21:49:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 21:49:51 --> Input Class Initialized
INFO - 2018-02-11 21:49:51 --> Security Class Initialized
INFO - 2018-02-11 21:49:51 --> Security Class Initialized
INFO - 2018-02-11 21:49:51 --> Language Class Initialized
DEBUG - 2018-02-11 21:49:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 21:49:51 --> Input Class Initialized
DEBUG - 2018-02-11 21:49:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 21:49:51 --> Input Class Initialized
ERROR - 2018-02-11 21:49:51 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-11 21:49:51 --> Language Class Initialized
INFO - 2018-02-11 21:49:51 --> Language Class Initialized
ERROR - 2018-02-11 21:49:51 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-11 21:49:51 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-11 21:49:51 --> Config Class Initialized
INFO - 2018-02-11 21:49:51 --> Hooks Class Initialized
DEBUG - 2018-02-11 21:49:51 --> UTF-8 Support Enabled
INFO - 2018-02-11 21:49:51 --> Utf8 Class Initialized
INFO - 2018-02-11 21:49:51 --> URI Class Initialized
INFO - 2018-02-11 21:49:51 --> Router Class Initialized
INFO - 2018-02-11 21:49:51 --> Output Class Initialized
INFO - 2018-02-11 21:49:51 --> Security Class Initialized
DEBUG - 2018-02-11 21:49:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 21:49:51 --> Input Class Initialized
INFO - 2018-02-11 21:49:51 --> Language Class Initialized
ERROR - 2018-02-11 21:49:51 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-11 21:49:51 --> Config Class Initialized
INFO - 2018-02-11 21:49:51 --> Config Class Initialized
INFO - 2018-02-11 21:49:51 --> Hooks Class Initialized
INFO - 2018-02-11 21:49:51 --> Hooks Class Initialized
INFO - 2018-02-11 21:49:51 --> Config Class Initialized
INFO - 2018-02-11 21:49:51 --> Hooks Class Initialized
DEBUG - 2018-02-11 21:49:51 --> UTF-8 Support Enabled
DEBUG - 2018-02-11 21:49:51 --> UTF-8 Support Enabled
INFO - 2018-02-11 21:49:51 --> Utf8 Class Initialized
INFO - 2018-02-11 21:49:51 --> Utf8 Class Initialized
DEBUG - 2018-02-11 21:49:51 --> UTF-8 Support Enabled
INFO - 2018-02-11 21:49:51 --> Utf8 Class Initialized
INFO - 2018-02-11 21:49:51 --> URI Class Initialized
INFO - 2018-02-11 21:49:51 --> URI Class Initialized
INFO - 2018-02-11 21:49:51 --> URI Class Initialized
INFO - 2018-02-11 21:49:51 --> Router Class Initialized
INFO - 2018-02-11 21:49:51 --> Router Class Initialized
INFO - 2018-02-11 21:49:51 --> Router Class Initialized
INFO - 2018-02-11 21:49:51 --> Output Class Initialized
INFO - 2018-02-11 21:49:51 --> Output Class Initialized
INFO - 2018-02-11 21:49:51 --> Output Class Initialized
INFO - 2018-02-11 21:49:51 --> Security Class Initialized
INFO - 2018-02-11 21:49:51 --> Security Class Initialized
INFO - 2018-02-11 21:49:51 --> Security Class Initialized
DEBUG - 2018-02-11 21:49:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 21:49:51 --> Input Class Initialized
DEBUG - 2018-02-11 21:49:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-11 21:49:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 21:49:51 --> Input Class Initialized
INFO - 2018-02-11 21:49:51 --> Input Class Initialized
INFO - 2018-02-11 21:49:51 --> Language Class Initialized
INFO - 2018-02-11 21:49:51 --> Language Class Initialized
INFO - 2018-02-11 21:49:51 --> Language Class Initialized
ERROR - 2018-02-11 21:49:51 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-11 21:49:51 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-11 21:49:51 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-11 21:49:51 --> Config Class Initialized
INFO - 2018-02-11 21:49:51 --> Hooks Class Initialized
DEBUG - 2018-02-11 21:49:51 --> UTF-8 Support Enabled
INFO - 2018-02-11 21:49:51 --> Utf8 Class Initialized
INFO - 2018-02-11 21:49:51 --> URI Class Initialized
INFO - 2018-02-11 21:49:51 --> Router Class Initialized
INFO - 2018-02-11 21:49:51 --> Output Class Initialized
INFO - 2018-02-11 21:49:51 --> Security Class Initialized
DEBUG - 2018-02-11 21:49:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 21:49:51 --> Input Class Initialized
INFO - 2018-02-11 21:49:51 --> Language Class Initialized
INFO - 2018-02-11 21:49:51 --> Loader Class Initialized
INFO - 2018-02-11 21:49:51 --> Helper loaded: url_helper
INFO - 2018-02-11 21:49:51 --> Helper loaded: form_helper
INFO - 2018-02-11 21:49:51 --> Database Driver Class Initialized
DEBUG - 2018-02-11 21:49:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 21:49:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 21:49:51 --> Form Validation Class Initialized
INFO - 2018-02-11 21:49:51 --> Model Class Initialized
INFO - 2018-02-11 21:49:51 --> Controller Class Initialized
INFO - 2018-02-11 21:49:51 --> Model Class Initialized
INFO - 2018-02-11 21:49:51 --> Model Class Initialized
INFO - 2018-02-11 21:49:51 --> Model Class Initialized
INFO - 2018-02-11 21:49:51 --> Model Class Initialized
INFO - 2018-02-11 21:49:51 --> Model Class Initialized
DEBUG - 2018-02-11 21:49:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 21:50:21 --> Config Class Initialized
INFO - 2018-02-11 21:50:21 --> Hooks Class Initialized
DEBUG - 2018-02-11 21:50:21 --> UTF-8 Support Enabled
INFO - 2018-02-11 21:50:21 --> Utf8 Class Initialized
INFO - 2018-02-11 21:50:21 --> URI Class Initialized
INFO - 2018-02-11 21:50:21 --> Router Class Initialized
INFO - 2018-02-11 21:50:21 --> Output Class Initialized
INFO - 2018-02-11 21:50:21 --> Security Class Initialized
DEBUG - 2018-02-11 21:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 21:50:21 --> Input Class Initialized
INFO - 2018-02-11 21:50:21 --> Language Class Initialized
INFO - 2018-02-11 21:50:21 --> Loader Class Initialized
INFO - 2018-02-11 21:50:21 --> Helper loaded: url_helper
INFO - 2018-02-11 21:50:21 --> Helper loaded: form_helper
INFO - 2018-02-11 21:50:21 --> Database Driver Class Initialized
DEBUG - 2018-02-11 21:50:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 21:50:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 21:50:21 --> Form Validation Class Initialized
INFO - 2018-02-11 21:50:21 --> Model Class Initialized
INFO - 2018-02-11 21:50:21 --> Controller Class Initialized
INFO - 2018-02-11 21:50:21 --> Model Class Initialized
INFO - 2018-02-11 21:50:21 --> Model Class Initialized
INFO - 2018-02-11 21:50:21 --> Model Class Initialized
INFO - 2018-02-11 21:50:21 --> Model Class Initialized
INFO - 2018-02-11 21:50:21 --> Model Class Initialized
DEBUG - 2018-02-11 21:50:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 21:50:21 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-11 21:50:21 --> Final output sent to browser
DEBUG - 2018-02-11 21:50:21 --> Total execution time: 0.0497
INFO - 2018-02-11 21:50:21 --> Config Class Initialized
INFO - 2018-02-11 21:50:21 --> Hooks Class Initialized
INFO - 2018-02-11 21:50:21 --> Config Class Initialized
INFO - 2018-02-11 21:50:21 --> Hooks Class Initialized
INFO - 2018-02-11 21:50:21 --> Config Class Initialized
INFO - 2018-02-11 21:50:21 --> Hooks Class Initialized
DEBUG - 2018-02-11 21:50:21 --> UTF-8 Support Enabled
INFO - 2018-02-11 21:50:21 --> Utf8 Class Initialized
DEBUG - 2018-02-11 21:50:21 --> UTF-8 Support Enabled
INFO - 2018-02-11 21:50:21 --> URI Class Initialized
INFO - 2018-02-11 21:50:21 --> Utf8 Class Initialized
DEBUG - 2018-02-11 21:50:21 --> UTF-8 Support Enabled
INFO - 2018-02-11 21:50:21 --> Utf8 Class Initialized
INFO - 2018-02-11 21:50:21 --> URI Class Initialized
INFO - 2018-02-11 21:50:21 --> Router Class Initialized
INFO - 2018-02-11 21:50:21 --> URI Class Initialized
INFO - 2018-02-11 21:50:21 --> Router Class Initialized
INFO - 2018-02-11 21:50:21 --> Output Class Initialized
INFO - 2018-02-11 21:50:21 --> Router Class Initialized
INFO - 2018-02-11 21:50:21 --> Security Class Initialized
INFO - 2018-02-11 21:50:21 --> Output Class Initialized
INFO - 2018-02-11 21:50:21 --> Output Class Initialized
DEBUG - 2018-02-11 21:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 21:50:21 --> Input Class Initialized
INFO - 2018-02-11 21:50:21 --> Security Class Initialized
INFO - 2018-02-11 21:50:21 --> Security Class Initialized
INFO - 2018-02-11 21:50:21 --> Language Class Initialized
DEBUG - 2018-02-11 21:50:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-11 21:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 21:50:21 --> Input Class Initialized
INFO - 2018-02-11 21:50:21 --> Input Class Initialized
ERROR - 2018-02-11 21:50:21 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-11 21:50:21 --> Language Class Initialized
INFO - 2018-02-11 21:50:21 --> Language Class Initialized
ERROR - 2018-02-11 21:50:21 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-11 21:50:21 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-11 21:50:21 --> Config Class Initialized
INFO - 2018-02-11 21:50:21 --> Hooks Class Initialized
DEBUG - 2018-02-11 21:50:21 --> UTF-8 Support Enabled
INFO - 2018-02-11 21:50:21 --> Utf8 Class Initialized
INFO - 2018-02-11 21:50:21 --> URI Class Initialized
INFO - 2018-02-11 21:50:21 --> Router Class Initialized
INFO - 2018-02-11 21:50:21 --> Output Class Initialized
INFO - 2018-02-11 21:50:21 --> Security Class Initialized
DEBUG - 2018-02-11 21:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 21:50:21 --> Input Class Initialized
INFO - 2018-02-11 21:50:21 --> Language Class Initialized
ERROR - 2018-02-11 21:50:21 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-11 21:50:21 --> Config Class Initialized
INFO - 2018-02-11 21:50:21 --> Hooks Class Initialized
INFO - 2018-02-11 21:50:21 --> Config Class Initialized
INFO - 2018-02-11 21:50:21 --> Hooks Class Initialized
INFO - 2018-02-11 21:50:21 --> Config Class Initialized
INFO - 2018-02-11 21:50:21 --> Hooks Class Initialized
DEBUG - 2018-02-11 21:50:21 --> UTF-8 Support Enabled
INFO - 2018-02-11 21:50:21 --> Utf8 Class Initialized
DEBUG - 2018-02-11 21:50:21 --> UTF-8 Support Enabled
INFO - 2018-02-11 21:50:21 --> Utf8 Class Initialized
INFO - 2018-02-11 21:50:21 --> URI Class Initialized
DEBUG - 2018-02-11 21:50:21 --> UTF-8 Support Enabled
INFO - 2018-02-11 21:50:21 --> URI Class Initialized
INFO - 2018-02-11 21:50:21 --> Utf8 Class Initialized
INFO - 2018-02-11 21:50:21 --> URI Class Initialized
INFO - 2018-02-11 21:50:21 --> Router Class Initialized
INFO - 2018-02-11 21:50:21 --> Router Class Initialized
INFO - 2018-02-11 21:50:21 --> Router Class Initialized
INFO - 2018-02-11 21:50:21 --> Output Class Initialized
INFO - 2018-02-11 21:50:21 --> Output Class Initialized
INFO - 2018-02-11 21:50:21 --> Security Class Initialized
INFO - 2018-02-11 21:50:21 --> Output Class Initialized
INFO - 2018-02-11 21:50:21 --> Security Class Initialized
DEBUG - 2018-02-11 21:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 21:50:21 --> Input Class Initialized
INFO - 2018-02-11 21:50:21 --> Security Class Initialized
DEBUG - 2018-02-11 21:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 21:50:21 --> Input Class Initialized
INFO - 2018-02-11 21:50:21 --> Language Class Initialized
INFO - 2018-02-11 21:50:21 --> Language Class Initialized
DEBUG - 2018-02-11 21:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 21:50:21 --> Input Class Initialized
ERROR - 2018-02-11 21:50:21 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-11 21:50:21 --> Language Class Initialized
ERROR - 2018-02-11 21:50:21 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-11 21:50:21 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-11 21:50:21 --> Config Class Initialized
INFO - 2018-02-11 21:50:21 --> Hooks Class Initialized
DEBUG - 2018-02-11 21:50:21 --> UTF-8 Support Enabled
INFO - 2018-02-11 21:50:21 --> Utf8 Class Initialized
INFO - 2018-02-11 21:50:21 --> URI Class Initialized
INFO - 2018-02-11 21:50:21 --> Router Class Initialized
INFO - 2018-02-11 21:50:21 --> Output Class Initialized
INFO - 2018-02-11 21:50:21 --> Security Class Initialized
DEBUG - 2018-02-11 21:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 21:50:21 --> Input Class Initialized
INFO - 2018-02-11 21:50:21 --> Language Class Initialized
INFO - 2018-02-11 21:50:21 --> Loader Class Initialized
INFO - 2018-02-11 21:50:21 --> Helper loaded: url_helper
INFO - 2018-02-11 21:50:21 --> Helper loaded: form_helper
INFO - 2018-02-11 21:50:21 --> Database Driver Class Initialized
DEBUG - 2018-02-11 21:50:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 21:50:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 21:50:21 --> Form Validation Class Initialized
INFO - 2018-02-11 21:50:21 --> Model Class Initialized
INFO - 2018-02-11 21:50:21 --> Controller Class Initialized
INFO - 2018-02-11 21:50:21 --> Model Class Initialized
INFO - 2018-02-11 21:50:21 --> Model Class Initialized
INFO - 2018-02-11 21:50:21 --> Model Class Initialized
INFO - 2018-02-11 21:50:21 --> Model Class Initialized
INFO - 2018-02-11 21:50:21 --> Model Class Initialized
DEBUG - 2018-02-11 21:50:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 22:03:28 --> Config Class Initialized
INFO - 2018-02-11 22:03:28 --> Hooks Class Initialized
DEBUG - 2018-02-11 22:03:28 --> UTF-8 Support Enabled
INFO - 2018-02-11 22:03:28 --> Utf8 Class Initialized
INFO - 2018-02-11 22:03:28 --> URI Class Initialized
INFO - 2018-02-11 22:03:28 --> Router Class Initialized
INFO - 2018-02-11 22:03:28 --> Output Class Initialized
INFO - 2018-02-11 22:03:28 --> Security Class Initialized
DEBUG - 2018-02-11 22:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 22:03:29 --> Input Class Initialized
INFO - 2018-02-11 22:03:29 --> Language Class Initialized
INFO - 2018-02-11 22:03:29 --> Loader Class Initialized
INFO - 2018-02-11 22:03:29 --> Helper loaded: url_helper
INFO - 2018-02-11 22:03:29 --> Helper loaded: form_helper
INFO - 2018-02-11 22:03:29 --> Database Driver Class Initialized
DEBUG - 2018-02-11 22:03:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 22:03:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 22:03:29 --> Form Validation Class Initialized
INFO - 2018-02-11 22:03:29 --> Model Class Initialized
INFO - 2018-02-11 22:03:29 --> Controller Class Initialized
INFO - 2018-02-11 22:03:29 --> Model Class Initialized
INFO - 2018-02-11 22:03:29 --> Model Class Initialized
INFO - 2018-02-11 22:03:29 --> Model Class Initialized
INFO - 2018-02-11 22:03:29 --> Model Class Initialized
INFO - 2018-02-11 22:03:29 --> Model Class Initialized
DEBUG - 2018-02-11 22:03:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 22:03:29 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-11 22:03:29 --> Final output sent to browser
DEBUG - 2018-02-11 22:03:29 --> Total execution time: 0.0678
INFO - 2018-02-11 22:03:29 --> Config Class Initialized
INFO - 2018-02-11 22:03:29 --> Config Class Initialized
INFO - 2018-02-11 22:03:29 --> Hooks Class Initialized
INFO - 2018-02-11 22:03:29 --> Config Class Initialized
INFO - 2018-02-11 22:03:29 --> Hooks Class Initialized
INFO - 2018-02-11 22:03:29 --> Hooks Class Initialized
DEBUG - 2018-02-11 22:03:29 --> UTF-8 Support Enabled
DEBUG - 2018-02-11 22:03:29 --> UTF-8 Support Enabled
INFO - 2018-02-11 22:03:29 --> Utf8 Class Initialized
INFO - 2018-02-11 22:03:29 --> Utf8 Class Initialized
DEBUG - 2018-02-11 22:03:29 --> UTF-8 Support Enabled
INFO - 2018-02-11 22:03:29 --> Utf8 Class Initialized
INFO - 2018-02-11 22:03:29 --> URI Class Initialized
INFO - 2018-02-11 22:03:29 --> URI Class Initialized
INFO - 2018-02-11 22:03:29 --> URI Class Initialized
INFO - 2018-02-11 22:03:29 --> Router Class Initialized
INFO - 2018-02-11 22:03:29 --> Router Class Initialized
INFO - 2018-02-11 22:03:29 --> Router Class Initialized
INFO - 2018-02-11 22:03:29 --> Output Class Initialized
INFO - 2018-02-11 22:03:29 --> Output Class Initialized
INFO - 2018-02-11 22:03:29 --> Output Class Initialized
INFO - 2018-02-11 22:03:29 --> Security Class Initialized
INFO - 2018-02-11 22:03:29 --> Security Class Initialized
INFO - 2018-02-11 22:03:29 --> Security Class Initialized
DEBUG - 2018-02-11 22:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 22:03:29 --> Input Class Initialized
DEBUG - 2018-02-11 22:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 22:03:29 --> Input Class Initialized
INFO - 2018-02-11 22:03:29 --> Language Class Initialized
DEBUG - 2018-02-11 22:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 22:03:29 --> Input Class Initialized
INFO - 2018-02-11 22:03:29 --> Language Class Initialized
ERROR - 2018-02-11 22:03:29 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-11 22:03:29 --> Language Class Initialized
ERROR - 2018-02-11 22:03:29 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-11 22:03:29 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-11 22:03:29 --> Config Class Initialized
INFO - 2018-02-11 22:03:29 --> Hooks Class Initialized
DEBUG - 2018-02-11 22:03:29 --> UTF-8 Support Enabled
INFO - 2018-02-11 22:03:29 --> Utf8 Class Initialized
INFO - 2018-02-11 22:03:29 --> URI Class Initialized
INFO - 2018-02-11 22:03:29 --> Router Class Initialized
INFO - 2018-02-11 22:03:29 --> Output Class Initialized
INFO - 2018-02-11 22:03:29 --> Security Class Initialized
DEBUG - 2018-02-11 22:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 22:03:29 --> Input Class Initialized
INFO - 2018-02-11 22:03:29 --> Language Class Initialized
ERROR - 2018-02-11 22:03:29 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-11 22:03:29 --> Config Class Initialized
INFO - 2018-02-11 22:03:29 --> Hooks Class Initialized
INFO - 2018-02-11 22:03:29 --> Config Class Initialized
INFO - 2018-02-11 22:03:29 --> Hooks Class Initialized
INFO - 2018-02-11 22:03:29 --> Config Class Initialized
INFO - 2018-02-11 22:03:29 --> Hooks Class Initialized
DEBUG - 2018-02-11 22:03:29 --> UTF-8 Support Enabled
INFO - 2018-02-11 22:03:29 --> Utf8 Class Initialized
DEBUG - 2018-02-11 22:03:29 --> UTF-8 Support Enabled
INFO - 2018-02-11 22:03:29 --> Utf8 Class Initialized
INFO - 2018-02-11 22:03:29 --> URI Class Initialized
DEBUG - 2018-02-11 22:03:29 --> UTF-8 Support Enabled
INFO - 2018-02-11 22:03:29 --> Utf8 Class Initialized
INFO - 2018-02-11 22:03:29 --> URI Class Initialized
INFO - 2018-02-11 22:03:29 --> URI Class Initialized
INFO - 2018-02-11 22:03:29 --> Router Class Initialized
INFO - 2018-02-11 22:03:29 --> Router Class Initialized
INFO - 2018-02-11 22:03:29 --> Router Class Initialized
INFO - 2018-02-11 22:03:29 --> Output Class Initialized
INFO - 2018-02-11 22:03:29 --> Output Class Initialized
INFO - 2018-02-11 22:03:29 --> Security Class Initialized
INFO - 2018-02-11 22:03:29 --> Output Class Initialized
INFO - 2018-02-11 22:03:29 --> Security Class Initialized
DEBUG - 2018-02-11 22:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 22:03:29 --> Security Class Initialized
INFO - 2018-02-11 22:03:29 --> Input Class Initialized
DEBUG - 2018-02-11 22:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 22:03:29 --> Language Class Initialized
INFO - 2018-02-11 22:03:29 --> Input Class Initialized
DEBUG - 2018-02-11 22:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 22:03:29 --> Input Class Initialized
INFO - 2018-02-11 22:03:29 --> Language Class Initialized
ERROR - 2018-02-11 22:03:29 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-11 22:03:29 --> Language Class Initialized
ERROR - 2018-02-11 22:03:29 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-11 22:03:29 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-11 22:03:29 --> Config Class Initialized
INFO - 2018-02-11 22:03:29 --> Hooks Class Initialized
INFO - 2018-02-11 22:03:29 --> Config Class Initialized
INFO - 2018-02-11 22:03:29 --> Hooks Class Initialized
DEBUG - 2018-02-11 22:03:29 --> UTF-8 Support Enabled
INFO - 2018-02-11 22:03:29 --> Utf8 Class Initialized
DEBUG - 2018-02-11 22:03:29 --> UTF-8 Support Enabled
INFO - 2018-02-11 22:03:29 --> Utf8 Class Initialized
INFO - 2018-02-11 22:03:29 --> URI Class Initialized
INFO - 2018-02-11 22:03:29 --> URI Class Initialized
INFO - 2018-02-11 22:03:29 --> Router Class Initialized
INFO - 2018-02-11 22:03:29 --> Router Class Initialized
INFO - 2018-02-11 22:03:29 --> Output Class Initialized
INFO - 2018-02-11 22:03:29 --> Output Class Initialized
INFO - 2018-02-11 22:03:29 --> Security Class Initialized
INFO - 2018-02-11 22:03:29 --> Security Class Initialized
DEBUG - 2018-02-11 22:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 22:03:29 --> Input Class Initialized
INFO - 2018-02-11 22:03:29 --> Language Class Initialized
DEBUG - 2018-02-11 22:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 22:03:29 --> Input Class Initialized
INFO - 2018-02-11 22:03:29 --> Language Class Initialized
ERROR - 2018-02-11 22:03:29 --> 404 Page Not Found: Proyectos/proyecto
INFO - 2018-02-11 22:03:29 --> Loader Class Initialized
INFO - 2018-02-11 22:03:29 --> Helper loaded: url_helper
INFO - 2018-02-11 22:03:29 --> Helper loaded: form_helper
INFO - 2018-02-11 22:03:29 --> Database Driver Class Initialized
DEBUG - 2018-02-11 22:03:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 22:03:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 22:03:29 --> Form Validation Class Initialized
INFO - 2018-02-11 22:03:29 --> Model Class Initialized
INFO - 2018-02-11 22:03:29 --> Controller Class Initialized
INFO - 2018-02-11 22:03:29 --> Model Class Initialized
INFO - 2018-02-11 22:03:29 --> Model Class Initialized
INFO - 2018-02-11 22:03:29 --> Model Class Initialized
INFO - 2018-02-11 22:03:29 --> Model Class Initialized
INFO - 2018-02-11 22:03:29 --> Model Class Initialized
DEBUG - 2018-02-11 22:03:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 22:03:43 --> Config Class Initialized
INFO - 2018-02-11 22:03:43 --> Hooks Class Initialized
DEBUG - 2018-02-11 22:03:43 --> UTF-8 Support Enabled
INFO - 2018-02-11 22:03:43 --> Utf8 Class Initialized
INFO - 2018-02-11 22:03:43 --> URI Class Initialized
INFO - 2018-02-11 22:03:43 --> Router Class Initialized
INFO - 2018-02-11 22:03:43 --> Output Class Initialized
INFO - 2018-02-11 22:03:43 --> Security Class Initialized
DEBUG - 2018-02-11 22:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 22:03:43 --> Input Class Initialized
INFO - 2018-02-11 22:03:43 --> Language Class Initialized
INFO - 2018-02-11 22:03:43 --> Loader Class Initialized
INFO - 2018-02-11 22:03:43 --> Helper loaded: url_helper
INFO - 2018-02-11 22:03:43 --> Helper loaded: form_helper
INFO - 2018-02-11 22:03:43 --> Database Driver Class Initialized
DEBUG - 2018-02-11 22:03:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 22:03:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 22:03:43 --> Form Validation Class Initialized
INFO - 2018-02-11 22:03:43 --> Model Class Initialized
INFO - 2018-02-11 22:03:43 --> Controller Class Initialized
INFO - 2018-02-11 22:03:43 --> Model Class Initialized
INFO - 2018-02-11 22:03:43 --> Model Class Initialized
INFO - 2018-02-11 22:03:43 --> Model Class Initialized
INFO - 2018-02-11 22:03:43 --> Model Class Initialized
INFO - 2018-02-11 22:03:43 --> Model Class Initialized
DEBUG - 2018-02-11 22:03:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 22:03:43 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-11 22:03:43 --> Final output sent to browser
DEBUG - 2018-02-11 22:03:43 --> Total execution time: 0.0703
INFO - 2018-02-11 22:03:43 --> Config Class Initialized
INFO - 2018-02-11 22:03:43 --> Hooks Class Initialized
INFO - 2018-02-11 22:03:43 --> Config Class Initialized
INFO - 2018-02-11 22:03:43 --> Hooks Class Initialized
INFO - 2018-02-11 22:03:43 --> Config Class Initialized
INFO - 2018-02-11 22:03:43 --> Hooks Class Initialized
DEBUG - 2018-02-11 22:03:43 --> UTF-8 Support Enabled
INFO - 2018-02-11 22:03:43 --> Utf8 Class Initialized
DEBUG - 2018-02-11 22:03:43 --> UTF-8 Support Enabled
INFO - 2018-02-11 22:03:43 --> Utf8 Class Initialized
DEBUG - 2018-02-11 22:03:43 --> UTF-8 Support Enabled
INFO - 2018-02-11 22:03:43 --> URI Class Initialized
INFO - 2018-02-11 22:03:43 --> Utf8 Class Initialized
INFO - 2018-02-11 22:03:43 --> URI Class Initialized
INFO - 2018-02-11 22:03:43 --> URI Class Initialized
INFO - 2018-02-11 22:03:43 --> Router Class Initialized
INFO - 2018-02-11 22:03:43 --> Router Class Initialized
INFO - 2018-02-11 22:03:43 --> Router Class Initialized
INFO - 2018-02-11 22:03:43 --> Output Class Initialized
INFO - 2018-02-11 22:03:43 --> Output Class Initialized
INFO - 2018-02-11 22:03:43 --> Output Class Initialized
INFO - 2018-02-11 22:03:43 --> Security Class Initialized
INFO - 2018-02-11 22:03:43 --> Security Class Initialized
INFO - 2018-02-11 22:03:43 --> Security Class Initialized
DEBUG - 2018-02-11 22:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 22:03:43 --> Input Class Initialized
DEBUG - 2018-02-11 22:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 22:03:43 --> Input Class Initialized
DEBUG - 2018-02-11 22:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 22:03:43 --> Language Class Initialized
INFO - 2018-02-11 22:03:43 --> Input Class Initialized
INFO - 2018-02-11 22:03:43 --> Language Class Initialized
INFO - 2018-02-11 22:03:43 --> Language Class Initialized
ERROR - 2018-02-11 22:03:43 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-11 22:03:43 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-11 22:03:43 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-11 22:03:43 --> Config Class Initialized
INFO - 2018-02-11 22:03:43 --> Hooks Class Initialized
DEBUG - 2018-02-11 22:03:43 --> UTF-8 Support Enabled
INFO - 2018-02-11 22:03:43 --> Utf8 Class Initialized
INFO - 2018-02-11 22:03:43 --> URI Class Initialized
INFO - 2018-02-11 22:03:43 --> Router Class Initialized
INFO - 2018-02-11 22:03:43 --> Output Class Initialized
INFO - 2018-02-11 22:03:43 --> Security Class Initialized
DEBUG - 2018-02-11 22:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 22:03:43 --> Input Class Initialized
INFO - 2018-02-11 22:03:43 --> Language Class Initialized
ERROR - 2018-02-11 22:03:43 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-11 22:03:43 --> Config Class Initialized
INFO - 2018-02-11 22:03:43 --> Hooks Class Initialized
INFO - 2018-02-11 22:03:43 --> Config Class Initialized
INFO - 2018-02-11 22:03:43 --> Hooks Class Initialized
INFO - 2018-02-11 22:03:43 --> Config Class Initialized
INFO - 2018-02-11 22:03:43 --> Hooks Class Initialized
DEBUG - 2018-02-11 22:03:43 --> UTF-8 Support Enabled
INFO - 2018-02-11 22:03:43 --> Utf8 Class Initialized
DEBUG - 2018-02-11 22:03:43 --> UTF-8 Support Enabled
INFO - 2018-02-11 22:03:43 --> Utf8 Class Initialized
INFO - 2018-02-11 22:03:43 --> URI Class Initialized
DEBUG - 2018-02-11 22:03:43 --> UTF-8 Support Enabled
INFO - 2018-02-11 22:03:43 --> Utf8 Class Initialized
INFO - 2018-02-11 22:03:43 --> URI Class Initialized
INFO - 2018-02-11 22:03:43 --> URI Class Initialized
INFO - 2018-02-11 22:03:43 --> Router Class Initialized
INFO - 2018-02-11 22:03:43 --> Router Class Initialized
INFO - 2018-02-11 22:03:43 --> Router Class Initialized
INFO - 2018-02-11 22:03:43 --> Output Class Initialized
INFO - 2018-02-11 22:03:43 --> Output Class Initialized
INFO - 2018-02-11 22:03:43 --> Output Class Initialized
INFO - 2018-02-11 22:03:43 --> Security Class Initialized
INFO - 2018-02-11 22:03:43 --> Security Class Initialized
INFO - 2018-02-11 22:03:43 --> Security Class Initialized
DEBUG - 2018-02-11 22:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 22:03:43 --> Input Class Initialized
DEBUG - 2018-02-11 22:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 22:03:43 --> Input Class Initialized
DEBUG - 2018-02-11 22:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 22:03:43 --> Input Class Initialized
INFO - 2018-02-11 22:03:43 --> Language Class Initialized
INFO - 2018-02-11 22:03:43 --> Language Class Initialized
INFO - 2018-02-11 22:03:43 --> Language Class Initialized
ERROR - 2018-02-11 22:03:43 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-11 22:03:43 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-11 22:03:43 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-11 22:03:43 --> Config Class Initialized
INFO - 2018-02-11 22:03:43 --> Hooks Class Initialized
INFO - 2018-02-11 22:03:43 --> Config Class Initialized
INFO - 2018-02-11 22:03:43 --> Hooks Class Initialized
DEBUG - 2018-02-11 22:03:43 --> UTF-8 Support Enabled
INFO - 2018-02-11 22:03:43 --> Utf8 Class Initialized
DEBUG - 2018-02-11 22:03:43 --> UTF-8 Support Enabled
INFO - 2018-02-11 22:03:43 --> URI Class Initialized
INFO - 2018-02-11 22:03:43 --> Utf8 Class Initialized
INFO - 2018-02-11 22:03:43 --> URI Class Initialized
INFO - 2018-02-11 22:03:43 --> Router Class Initialized
INFO - 2018-02-11 22:03:43 --> Router Class Initialized
INFO - 2018-02-11 22:03:43 --> Output Class Initialized
INFO - 2018-02-11 22:03:43 --> Output Class Initialized
INFO - 2018-02-11 22:03:43 --> Security Class Initialized
INFO - 2018-02-11 22:03:43 --> Security Class Initialized
DEBUG - 2018-02-11 22:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 22:03:43 --> Input Class Initialized
INFO - 2018-02-11 22:03:43 --> Language Class Initialized
DEBUG - 2018-02-11 22:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 22:03:43 --> Input Class Initialized
INFO - 2018-02-11 22:03:43 --> Language Class Initialized
INFO - 2018-02-11 22:03:43 --> Loader Class Initialized
INFO - 2018-02-11 22:03:43 --> Loader Class Initialized
INFO - 2018-02-11 22:03:43 --> Helper loaded: url_helper
INFO - 2018-02-11 22:03:43 --> Helper loaded: form_helper
INFO - 2018-02-11 22:03:43 --> Helper loaded: url_helper
INFO - 2018-02-11 22:03:43 --> Helper loaded: form_helper
INFO - 2018-02-11 22:03:43 --> Database Driver Class Initialized
INFO - 2018-02-11 22:03:43 --> Database Driver Class Initialized
DEBUG - 2018-02-11 22:03:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 22:03:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-02-11 22:03:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 22:03:43 --> Form Validation Class Initialized
INFO - 2018-02-11 22:03:43 --> Model Class Initialized
INFO - 2018-02-11 22:03:43 --> Controller Class Initialized
INFO - 2018-02-11 22:03:43 --> Model Class Initialized
INFO - 2018-02-11 22:03:43 --> Model Class Initialized
INFO - 2018-02-11 22:03:43 --> Model Class Initialized
INFO - 2018-02-11 22:03:43 --> Model Class Initialized
INFO - 2018-02-11 22:03:43 --> Model Class Initialized
DEBUG - 2018-02-11 22:03:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 22:03:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 22:03:43 --> Form Validation Class Initialized
INFO - 2018-02-11 22:03:43 --> Model Class Initialized
INFO - 2018-02-11 22:03:43 --> Controller Class Initialized
INFO - 2018-02-11 22:03:43 --> Model Class Initialized
INFO - 2018-02-11 22:03:43 --> Model Class Initialized
INFO - 2018-02-11 22:03:43 --> Model Class Initialized
INFO - 2018-02-11 22:03:43 --> Model Class Initialized
INFO - 2018-02-11 22:03:43 --> Model Class Initialized
DEBUG - 2018-02-11 22:03:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 22:04:07 --> Config Class Initialized
INFO - 2018-02-11 22:04:07 --> Hooks Class Initialized
DEBUG - 2018-02-11 22:04:07 --> UTF-8 Support Enabled
INFO - 2018-02-11 22:04:07 --> Utf8 Class Initialized
INFO - 2018-02-11 22:04:07 --> URI Class Initialized
INFO - 2018-02-11 22:04:07 --> Router Class Initialized
INFO - 2018-02-11 22:04:07 --> Output Class Initialized
INFO - 2018-02-11 22:04:07 --> Security Class Initialized
DEBUG - 2018-02-11 22:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 22:04:07 --> Input Class Initialized
INFO - 2018-02-11 22:04:07 --> Language Class Initialized
INFO - 2018-02-11 22:04:07 --> Loader Class Initialized
INFO - 2018-02-11 22:04:07 --> Helper loaded: url_helper
INFO - 2018-02-11 22:04:07 --> Helper loaded: form_helper
INFO - 2018-02-11 22:04:07 --> Database Driver Class Initialized
DEBUG - 2018-02-11 22:04:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 22:04:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 22:04:07 --> Form Validation Class Initialized
INFO - 2018-02-11 22:04:07 --> Model Class Initialized
INFO - 2018-02-11 22:04:07 --> Controller Class Initialized
INFO - 2018-02-11 22:04:07 --> Model Class Initialized
INFO - 2018-02-11 22:04:07 --> Model Class Initialized
INFO - 2018-02-11 22:04:07 --> Model Class Initialized
INFO - 2018-02-11 22:04:07 --> Model Class Initialized
INFO - 2018-02-11 22:04:07 --> Model Class Initialized
DEBUG - 2018-02-11 22:04:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 22:04:07 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-11 22:04:07 --> Final output sent to browser
DEBUG - 2018-02-11 22:04:07 --> Total execution time: 0.0646
INFO - 2018-02-11 22:04:07 --> Config Class Initialized
INFO - 2018-02-11 22:04:07 --> Config Class Initialized
INFO - 2018-02-11 22:04:07 --> Hooks Class Initialized
INFO - 2018-02-11 22:04:07 --> Hooks Class Initialized
INFO - 2018-02-11 22:04:07 --> Config Class Initialized
INFO - 2018-02-11 22:04:07 --> Hooks Class Initialized
INFO - 2018-02-11 22:04:07 --> Config Class Initialized
INFO - 2018-02-11 22:04:07 --> Hooks Class Initialized
DEBUG - 2018-02-11 22:04:07 --> UTF-8 Support Enabled
DEBUG - 2018-02-11 22:04:07 --> UTF-8 Support Enabled
INFO - 2018-02-11 22:04:07 --> Utf8 Class Initialized
DEBUG - 2018-02-11 22:04:07 --> UTF-8 Support Enabled
INFO - 2018-02-11 22:04:07 --> Utf8 Class Initialized
INFO - 2018-02-11 22:04:07 --> Utf8 Class Initialized
INFO - 2018-02-11 22:04:07 --> URI Class Initialized
INFO - 2018-02-11 22:04:07 --> URI Class Initialized
INFO - 2018-02-11 22:04:07 --> URI Class Initialized
DEBUG - 2018-02-11 22:04:07 --> UTF-8 Support Enabled
INFO - 2018-02-11 22:04:07 --> Utf8 Class Initialized
INFO - 2018-02-11 22:04:07 --> Router Class Initialized
INFO - 2018-02-11 22:04:07 --> Router Class Initialized
INFO - 2018-02-11 22:04:07 --> Router Class Initialized
INFO - 2018-02-11 22:04:07 --> URI Class Initialized
INFO - 2018-02-11 22:04:07 --> Output Class Initialized
INFO - 2018-02-11 22:04:07 --> Output Class Initialized
INFO - 2018-02-11 22:04:07 --> Output Class Initialized
INFO - 2018-02-11 22:04:07 --> Router Class Initialized
INFO - 2018-02-11 22:04:07 --> Security Class Initialized
INFO - 2018-02-11 22:04:07 --> Security Class Initialized
INFO - 2018-02-11 22:04:07 --> Security Class Initialized
DEBUG - 2018-02-11 22:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 22:04:07 --> Output Class Initialized
INFO - 2018-02-11 22:04:07 --> Input Class Initialized
DEBUG - 2018-02-11 22:04:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-11 22:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 22:04:07 --> Input Class Initialized
INFO - 2018-02-11 22:04:07 --> Input Class Initialized
INFO - 2018-02-11 22:04:07 --> Language Class Initialized
INFO - 2018-02-11 22:04:07 --> Language Class Initialized
INFO - 2018-02-11 22:04:07 --> Security Class Initialized
INFO - 2018-02-11 22:04:07 --> Language Class Initialized
ERROR - 2018-02-11 22:04:07 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-11 22:04:07 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-02-11 22:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 22:04:07 --> Input Class Initialized
ERROR - 2018-02-11 22:04:07 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-11 22:04:07 --> Language Class Initialized
ERROR - 2018-02-11 22:04:07 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-11 22:04:07 --> Config Class Initialized
INFO - 2018-02-11 22:04:07 --> Config Class Initialized
INFO - 2018-02-11 22:04:07 --> Hooks Class Initialized
INFO - 2018-02-11 22:04:07 --> Hooks Class Initialized
INFO - 2018-02-11 22:04:07 --> Config Class Initialized
INFO - 2018-02-11 22:04:07 --> Hooks Class Initialized
DEBUG - 2018-02-11 22:04:07 --> UTF-8 Support Enabled
DEBUG - 2018-02-11 22:04:07 --> UTF-8 Support Enabled
INFO - 2018-02-11 22:04:07 --> Utf8 Class Initialized
INFO - 2018-02-11 22:04:07 --> Utf8 Class Initialized
DEBUG - 2018-02-11 22:04:07 --> UTF-8 Support Enabled
INFO - 2018-02-11 22:04:07 --> Utf8 Class Initialized
INFO - 2018-02-11 22:04:07 --> URI Class Initialized
INFO - 2018-02-11 22:04:07 --> URI Class Initialized
INFO - 2018-02-11 22:04:07 --> URI Class Initialized
INFO - 2018-02-11 22:04:07 --> Router Class Initialized
INFO - 2018-02-11 22:04:07 --> Router Class Initialized
INFO - 2018-02-11 22:04:07 --> Router Class Initialized
INFO - 2018-02-11 22:04:07 --> Output Class Initialized
INFO - 2018-02-11 22:04:07 --> Output Class Initialized
INFO - 2018-02-11 22:04:07 --> Output Class Initialized
INFO - 2018-02-11 22:04:07 --> Security Class Initialized
INFO - 2018-02-11 22:04:07 --> Security Class Initialized
INFO - 2018-02-11 22:04:07 --> Security Class Initialized
DEBUG - 2018-02-11 22:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 22:04:07 --> Input Class Initialized
DEBUG - 2018-02-11 22:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 22:04:07 --> Input Class Initialized
DEBUG - 2018-02-11 22:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 22:04:07 --> Language Class Initialized
INFO - 2018-02-11 22:04:07 --> Input Class Initialized
INFO - 2018-02-11 22:04:07 --> Language Class Initialized
INFO - 2018-02-11 22:04:07 --> Language Class Initialized
ERROR - 2018-02-11 22:04:07 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-11 22:04:07 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-11 22:04:07 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-11 22:04:07 --> Config Class Initialized
INFO - 2018-02-11 22:04:07 --> Hooks Class Initialized
INFO - 2018-02-11 22:04:07 --> Config Class Initialized
INFO - 2018-02-11 22:04:07 --> Hooks Class Initialized
DEBUG - 2018-02-11 22:04:07 --> UTF-8 Support Enabled
INFO - 2018-02-11 22:04:07 --> Utf8 Class Initialized
DEBUG - 2018-02-11 22:04:07 --> UTF-8 Support Enabled
INFO - 2018-02-11 22:04:07 --> Utf8 Class Initialized
INFO - 2018-02-11 22:04:07 --> URI Class Initialized
INFO - 2018-02-11 22:04:07 --> URI Class Initialized
INFO - 2018-02-11 22:04:07 --> Router Class Initialized
INFO - 2018-02-11 22:04:07 --> Router Class Initialized
INFO - 2018-02-11 22:04:07 --> Output Class Initialized
INFO - 2018-02-11 22:04:07 --> Output Class Initialized
INFO - 2018-02-11 22:04:07 --> Security Class Initialized
INFO - 2018-02-11 22:04:07 --> Security Class Initialized
DEBUG - 2018-02-11 22:04:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-11 22:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 22:04:07 --> Input Class Initialized
INFO - 2018-02-11 22:04:07 --> Input Class Initialized
INFO - 2018-02-11 22:04:07 --> Language Class Initialized
INFO - 2018-02-11 22:04:07 --> Language Class Initialized
INFO - 2018-02-11 22:04:07 --> Loader Class Initialized
INFO - 2018-02-11 22:04:07 --> Loader Class Initialized
INFO - 2018-02-11 22:04:07 --> Helper loaded: url_helper
INFO - 2018-02-11 22:04:07 --> Helper loaded: url_helper
INFO - 2018-02-11 22:04:07 --> Helper loaded: form_helper
INFO - 2018-02-11 22:04:07 --> Helper loaded: form_helper
INFO - 2018-02-11 22:04:07 --> Database Driver Class Initialized
INFO - 2018-02-11 22:04:07 --> Database Driver Class Initialized
DEBUG - 2018-02-11 22:04:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 22:04:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 22:04:07 --> Form Validation Class Initialized
INFO - 2018-02-11 22:04:07 --> Model Class Initialized
INFO - 2018-02-11 22:04:07 --> Controller Class Initialized
INFO - 2018-02-11 22:04:07 --> Model Class Initialized
INFO - 2018-02-11 22:04:07 --> Model Class Initialized
INFO - 2018-02-11 22:04:07 --> Model Class Initialized
INFO - 2018-02-11 22:04:07 --> Model Class Initialized
DEBUG - 2018-02-11 22:04:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 22:04:07 --> Model Class Initialized
DEBUG - 2018-02-11 22:04:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 22:04:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 22:04:07 --> Form Validation Class Initialized
INFO - 2018-02-11 22:04:07 --> Model Class Initialized
INFO - 2018-02-11 22:04:07 --> Controller Class Initialized
INFO - 2018-02-11 22:04:07 --> Model Class Initialized
INFO - 2018-02-11 22:04:07 --> Model Class Initialized
INFO - 2018-02-11 22:04:07 --> Model Class Initialized
INFO - 2018-02-11 22:04:07 --> Model Class Initialized
INFO - 2018-02-11 22:04:07 --> Model Class Initialized
DEBUG - 2018-02-11 22:04:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 22:04:27 --> Config Class Initialized
INFO - 2018-02-11 22:04:27 --> Hooks Class Initialized
DEBUG - 2018-02-11 22:04:27 --> UTF-8 Support Enabled
INFO - 2018-02-11 22:04:27 --> Utf8 Class Initialized
INFO - 2018-02-11 22:04:27 --> URI Class Initialized
INFO - 2018-02-11 22:04:27 --> Router Class Initialized
INFO - 2018-02-11 22:04:27 --> Output Class Initialized
INFO - 2018-02-11 22:04:27 --> Security Class Initialized
DEBUG - 2018-02-11 22:04:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 22:04:27 --> Input Class Initialized
INFO - 2018-02-11 22:04:27 --> Language Class Initialized
INFO - 2018-02-11 22:04:27 --> Loader Class Initialized
INFO - 2018-02-11 22:04:27 --> Helper loaded: url_helper
INFO - 2018-02-11 22:04:27 --> Helper loaded: form_helper
INFO - 2018-02-11 22:04:27 --> Database Driver Class Initialized
DEBUG - 2018-02-11 22:04:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 22:04:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 22:04:27 --> Form Validation Class Initialized
INFO - 2018-02-11 22:04:27 --> Model Class Initialized
INFO - 2018-02-11 22:04:27 --> Controller Class Initialized
INFO - 2018-02-11 22:04:27 --> Model Class Initialized
INFO - 2018-02-11 22:04:27 --> Model Class Initialized
INFO - 2018-02-11 22:04:27 --> Model Class Initialized
INFO - 2018-02-11 22:04:27 --> Model Class Initialized
INFO - 2018-02-11 22:04:27 --> Model Class Initialized
DEBUG - 2018-02-11 22:04:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 22:04:27 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-11 22:04:27 --> Final output sent to browser
DEBUG - 2018-02-11 22:04:27 --> Total execution time: 0.0768
INFO - 2018-02-11 22:04:27 --> Config Class Initialized
INFO - 2018-02-11 22:04:27 --> Hooks Class Initialized
INFO - 2018-02-11 22:04:27 --> Config Class Initialized
INFO - 2018-02-11 22:04:27 --> Hooks Class Initialized
INFO - 2018-02-11 22:04:27 --> Config Class Initialized
INFO - 2018-02-11 22:04:27 --> Hooks Class Initialized
DEBUG - 2018-02-11 22:04:27 --> UTF-8 Support Enabled
INFO - 2018-02-11 22:04:27 --> Utf8 Class Initialized
INFO - 2018-02-11 22:04:27 --> URI Class Initialized
DEBUG - 2018-02-11 22:04:27 --> UTF-8 Support Enabled
INFO - 2018-02-11 22:04:27 --> Utf8 Class Initialized
DEBUG - 2018-02-11 22:04:27 --> UTF-8 Support Enabled
INFO - 2018-02-11 22:04:27 --> Utf8 Class Initialized
INFO - 2018-02-11 22:04:27 --> Router Class Initialized
INFO - 2018-02-11 22:04:27 --> URI Class Initialized
INFO - 2018-02-11 22:04:27 --> URI Class Initialized
INFO - 2018-02-11 22:04:27 --> Output Class Initialized
INFO - 2018-02-11 22:04:27 --> Router Class Initialized
INFO - 2018-02-11 22:04:27 --> Router Class Initialized
INFO - 2018-02-11 22:04:27 --> Security Class Initialized
INFO - 2018-02-11 22:04:27 --> Output Class Initialized
INFO - 2018-02-11 22:04:27 --> Output Class Initialized
DEBUG - 2018-02-11 22:04:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 22:04:27 --> Security Class Initialized
INFO - 2018-02-11 22:04:27 --> Security Class Initialized
INFO - 2018-02-11 22:04:27 --> Input Class Initialized
DEBUG - 2018-02-11 22:04:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 22:04:27 --> Language Class Initialized
INFO - 2018-02-11 22:04:27 --> Input Class Initialized
DEBUG - 2018-02-11 22:04:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 22:04:27 --> Input Class Initialized
INFO - 2018-02-11 22:04:27 --> Language Class Initialized
INFO - 2018-02-11 22:04:27 --> Language Class Initialized
ERROR - 2018-02-11 22:04:27 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-11 22:04:27 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-11 22:04:27 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-11 22:04:28 --> Config Class Initialized
INFO - 2018-02-11 22:04:28 --> Hooks Class Initialized
DEBUG - 2018-02-11 22:04:28 --> UTF-8 Support Enabled
INFO - 2018-02-11 22:04:28 --> Utf8 Class Initialized
INFO - 2018-02-11 22:04:28 --> URI Class Initialized
INFO - 2018-02-11 22:04:28 --> Router Class Initialized
INFO - 2018-02-11 22:04:28 --> Output Class Initialized
INFO - 2018-02-11 22:04:28 --> Security Class Initialized
DEBUG - 2018-02-11 22:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 22:04:28 --> Input Class Initialized
INFO - 2018-02-11 22:04:28 --> Language Class Initialized
ERROR - 2018-02-11 22:04:28 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-11 22:04:28 --> Config Class Initialized
INFO - 2018-02-11 22:04:28 --> Config Class Initialized
INFO - 2018-02-11 22:04:28 --> Hooks Class Initialized
INFO - 2018-02-11 22:04:28 --> Config Class Initialized
INFO - 2018-02-11 22:04:28 --> Hooks Class Initialized
INFO - 2018-02-11 22:04:28 --> Hooks Class Initialized
DEBUG - 2018-02-11 22:04:28 --> UTF-8 Support Enabled
INFO - 2018-02-11 22:04:28 --> Utf8 Class Initialized
DEBUG - 2018-02-11 22:04:28 --> UTF-8 Support Enabled
DEBUG - 2018-02-11 22:04:28 --> UTF-8 Support Enabled
INFO - 2018-02-11 22:04:28 --> Utf8 Class Initialized
INFO - 2018-02-11 22:04:28 --> Utf8 Class Initialized
INFO - 2018-02-11 22:04:28 --> URI Class Initialized
INFO - 2018-02-11 22:04:28 --> URI Class Initialized
INFO - 2018-02-11 22:04:28 --> URI Class Initialized
INFO - 2018-02-11 22:04:28 --> Router Class Initialized
INFO - 2018-02-11 22:04:28 --> Router Class Initialized
INFO - 2018-02-11 22:04:28 --> Router Class Initialized
INFO - 2018-02-11 22:04:28 --> Output Class Initialized
INFO - 2018-02-11 22:04:28 --> Output Class Initialized
INFO - 2018-02-11 22:04:28 --> Output Class Initialized
INFO - 2018-02-11 22:04:28 --> Security Class Initialized
INFO - 2018-02-11 22:04:28 --> Security Class Initialized
INFO - 2018-02-11 22:04:28 --> Security Class Initialized
DEBUG - 2018-02-11 22:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 22:04:28 --> Input Class Initialized
DEBUG - 2018-02-11 22:04:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-11 22:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 22:04:28 --> Input Class Initialized
INFO - 2018-02-11 22:04:28 --> Input Class Initialized
INFO - 2018-02-11 22:04:28 --> Language Class Initialized
INFO - 2018-02-11 22:04:28 --> Language Class Initialized
INFO - 2018-02-11 22:04:28 --> Language Class Initialized
ERROR - 2018-02-11 22:04:28 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-11 22:04:28 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-11 22:04:28 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-11 22:04:28 --> Config Class Initialized
INFO - 2018-02-11 22:04:28 --> Hooks Class Initialized
INFO - 2018-02-11 22:04:28 --> Config Class Initialized
INFO - 2018-02-11 22:04:28 --> Hooks Class Initialized
DEBUG - 2018-02-11 22:04:28 --> UTF-8 Support Enabled
INFO - 2018-02-11 22:04:28 --> Utf8 Class Initialized
DEBUG - 2018-02-11 22:04:28 --> UTF-8 Support Enabled
INFO - 2018-02-11 22:04:28 --> Utf8 Class Initialized
INFO - 2018-02-11 22:04:28 --> URI Class Initialized
INFO - 2018-02-11 22:04:28 --> URI Class Initialized
INFO - 2018-02-11 22:04:28 --> Router Class Initialized
INFO - 2018-02-11 22:04:28 --> Router Class Initialized
INFO - 2018-02-11 22:04:28 --> Output Class Initialized
INFO - 2018-02-11 22:04:28 --> Output Class Initialized
INFO - 2018-02-11 22:04:28 --> Security Class Initialized
INFO - 2018-02-11 22:04:28 --> Security Class Initialized
DEBUG - 2018-02-11 22:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 22:04:28 --> Input Class Initialized
INFO - 2018-02-11 22:04:28 --> Language Class Initialized
DEBUG - 2018-02-11 22:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 22:04:28 --> Input Class Initialized
INFO - 2018-02-11 22:04:28 --> Language Class Initialized
INFO - 2018-02-11 22:04:28 --> Loader Class Initialized
INFO - 2018-02-11 22:04:28 --> Loader Class Initialized
INFO - 2018-02-11 22:04:28 --> Helper loaded: url_helper
INFO - 2018-02-11 22:04:28 --> Helper loaded: url_helper
INFO - 2018-02-11 22:04:28 --> Helper loaded: form_helper
INFO - 2018-02-11 22:04:28 --> Helper loaded: form_helper
INFO - 2018-02-11 22:04:28 --> Database Driver Class Initialized
INFO - 2018-02-11 22:04:28 --> Database Driver Class Initialized
DEBUG - 2018-02-11 22:04:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 22:04:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 22:04:28 --> Form Validation Class Initialized
INFO - 2018-02-11 22:04:28 --> Model Class Initialized
INFO - 2018-02-11 22:04:28 --> Controller Class Initialized
INFO - 2018-02-11 22:04:28 --> Model Class Initialized
INFO - 2018-02-11 22:04:28 --> Model Class Initialized
INFO - 2018-02-11 22:04:28 --> Model Class Initialized
INFO - 2018-02-11 22:04:28 --> Model Class Initialized
INFO - 2018-02-11 22:04:28 --> Model Class Initialized
DEBUG - 2018-02-11 22:04:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-02-11 22:04:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 22:04:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 22:04:28 --> Form Validation Class Initialized
INFO - 2018-02-11 22:04:28 --> Model Class Initialized
INFO - 2018-02-11 22:04:28 --> Controller Class Initialized
INFO - 2018-02-11 22:04:28 --> Model Class Initialized
INFO - 2018-02-11 22:04:28 --> Model Class Initialized
INFO - 2018-02-11 22:04:28 --> Model Class Initialized
INFO - 2018-02-11 22:04:28 --> Model Class Initialized
INFO - 2018-02-11 22:04:28 --> Model Class Initialized
DEBUG - 2018-02-11 22:04:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 22:04:33 --> Config Class Initialized
INFO - 2018-02-11 22:04:33 --> Hooks Class Initialized
DEBUG - 2018-02-11 22:04:33 --> UTF-8 Support Enabled
INFO - 2018-02-11 22:04:33 --> Utf8 Class Initialized
INFO - 2018-02-11 22:04:33 --> URI Class Initialized
INFO - 2018-02-11 22:04:33 --> Router Class Initialized
INFO - 2018-02-11 22:04:33 --> Output Class Initialized
INFO - 2018-02-11 22:04:33 --> Security Class Initialized
DEBUG - 2018-02-11 22:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 22:04:33 --> Input Class Initialized
INFO - 2018-02-11 22:04:33 --> Language Class Initialized
INFO - 2018-02-11 22:04:33 --> Loader Class Initialized
INFO - 2018-02-11 22:04:33 --> Helper loaded: url_helper
INFO - 2018-02-11 22:04:33 --> Helper loaded: form_helper
INFO - 2018-02-11 22:04:33 --> Database Driver Class Initialized
DEBUG - 2018-02-11 22:04:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 22:04:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 22:04:33 --> Form Validation Class Initialized
INFO - 2018-02-11 22:04:33 --> Model Class Initialized
INFO - 2018-02-11 22:04:33 --> Controller Class Initialized
INFO - 2018-02-11 22:04:33 --> Model Class Initialized
INFO - 2018-02-11 22:04:33 --> Model Class Initialized
INFO - 2018-02-11 22:04:33 --> Model Class Initialized
INFO - 2018-02-11 22:04:33 --> Model Class Initialized
INFO - 2018-02-11 22:04:33 --> Model Class Initialized
DEBUG - 2018-02-11 22:04:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 22:04:33 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-11 22:04:33 --> Final output sent to browser
DEBUG - 2018-02-11 22:04:33 --> Total execution time: 0.0615
INFO - 2018-02-11 22:04:34 --> Config Class Initialized
INFO - 2018-02-11 22:04:34 --> Config Class Initialized
INFO - 2018-02-11 22:04:34 --> Config Class Initialized
INFO - 2018-02-11 22:04:34 --> Hooks Class Initialized
INFO - 2018-02-11 22:04:34 --> Hooks Class Initialized
INFO - 2018-02-11 22:04:34 --> Hooks Class Initialized
DEBUG - 2018-02-11 22:04:34 --> UTF-8 Support Enabled
DEBUG - 2018-02-11 22:04:34 --> UTF-8 Support Enabled
DEBUG - 2018-02-11 22:04:34 --> UTF-8 Support Enabled
INFO - 2018-02-11 22:04:34 --> Utf8 Class Initialized
INFO - 2018-02-11 22:04:34 --> Utf8 Class Initialized
INFO - 2018-02-11 22:04:34 --> Utf8 Class Initialized
INFO - 2018-02-11 22:04:34 --> URI Class Initialized
INFO - 2018-02-11 22:04:34 --> URI Class Initialized
INFO - 2018-02-11 22:04:34 --> URI Class Initialized
INFO - 2018-02-11 22:04:34 --> Router Class Initialized
INFO - 2018-02-11 22:04:34 --> Router Class Initialized
INFO - 2018-02-11 22:04:34 --> Router Class Initialized
INFO - 2018-02-11 22:04:34 --> Output Class Initialized
INFO - 2018-02-11 22:04:34 --> Output Class Initialized
INFO - 2018-02-11 22:04:34 --> Output Class Initialized
INFO - 2018-02-11 22:04:34 --> Security Class Initialized
INFO - 2018-02-11 22:04:34 --> Security Class Initialized
INFO - 2018-02-11 22:04:34 --> Security Class Initialized
DEBUG - 2018-02-11 22:04:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-11 22:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 22:04:34 --> Input Class Initialized
INFO - 2018-02-11 22:04:34 --> Input Class Initialized
DEBUG - 2018-02-11 22:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 22:04:34 --> Input Class Initialized
INFO - 2018-02-11 22:04:34 --> Language Class Initialized
INFO - 2018-02-11 22:04:34 --> Language Class Initialized
INFO - 2018-02-11 22:04:34 --> Language Class Initialized
ERROR - 2018-02-11 22:04:34 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-11 22:04:34 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-11 22:04:34 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-11 22:04:34 --> Config Class Initialized
INFO - 2018-02-11 22:04:34 --> Hooks Class Initialized
DEBUG - 2018-02-11 22:04:34 --> UTF-8 Support Enabled
INFO - 2018-02-11 22:04:34 --> Utf8 Class Initialized
INFO - 2018-02-11 22:04:34 --> URI Class Initialized
INFO - 2018-02-11 22:04:34 --> Router Class Initialized
INFO - 2018-02-11 22:04:34 --> Output Class Initialized
INFO - 2018-02-11 22:04:34 --> Security Class Initialized
DEBUG - 2018-02-11 22:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 22:04:34 --> Input Class Initialized
INFO - 2018-02-11 22:04:34 --> Language Class Initialized
ERROR - 2018-02-11 22:04:34 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-11 22:04:34 --> Config Class Initialized
INFO - 2018-02-11 22:04:34 --> Hooks Class Initialized
INFO - 2018-02-11 22:04:34 --> Config Class Initialized
INFO - 2018-02-11 22:04:34 --> Hooks Class Initialized
INFO - 2018-02-11 22:04:34 --> Config Class Initialized
DEBUG - 2018-02-11 22:04:34 --> UTF-8 Support Enabled
INFO - 2018-02-11 22:04:34 --> Hooks Class Initialized
INFO - 2018-02-11 22:04:34 --> Utf8 Class Initialized
DEBUG - 2018-02-11 22:04:34 --> UTF-8 Support Enabled
INFO - 2018-02-11 22:04:34 --> URI Class Initialized
INFO - 2018-02-11 22:04:34 --> Utf8 Class Initialized
DEBUG - 2018-02-11 22:04:34 --> UTF-8 Support Enabled
INFO - 2018-02-11 22:04:34 --> URI Class Initialized
INFO - 2018-02-11 22:04:34 --> Utf8 Class Initialized
INFO - 2018-02-11 22:04:34 --> Router Class Initialized
INFO - 2018-02-11 22:04:34 --> URI Class Initialized
INFO - 2018-02-11 22:04:34 --> Router Class Initialized
INFO - 2018-02-11 22:04:34 --> Output Class Initialized
INFO - 2018-02-11 22:04:34 --> Router Class Initialized
INFO - 2018-02-11 22:04:34 --> Output Class Initialized
INFO - 2018-02-11 22:04:34 --> Security Class Initialized
INFO - 2018-02-11 22:04:34 --> Security Class Initialized
DEBUG - 2018-02-11 22:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 22:04:34 --> Input Class Initialized
INFO - 2018-02-11 22:04:34 --> Output Class Initialized
INFO - 2018-02-11 22:04:34 --> Language Class Initialized
DEBUG - 2018-02-11 22:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 22:04:34 --> Input Class Initialized
INFO - 2018-02-11 22:04:34 --> Security Class Initialized
INFO - 2018-02-11 22:04:34 --> Language Class Initialized
ERROR - 2018-02-11 22:04:34 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-02-11 22:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 22:04:34 --> Input Class Initialized
ERROR - 2018-02-11 22:04:34 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-11 22:04:34 --> Language Class Initialized
ERROR - 2018-02-11 22:04:34 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-11 22:04:34 --> Config Class Initialized
INFO - 2018-02-11 22:04:34 --> Hooks Class Initialized
INFO - 2018-02-11 22:04:34 --> Config Class Initialized
INFO - 2018-02-11 22:04:34 --> Hooks Class Initialized
DEBUG - 2018-02-11 22:04:34 --> UTF-8 Support Enabled
INFO - 2018-02-11 22:04:34 --> Utf8 Class Initialized
DEBUG - 2018-02-11 22:04:34 --> UTF-8 Support Enabled
INFO - 2018-02-11 22:04:34 --> URI Class Initialized
INFO - 2018-02-11 22:04:34 --> Utf8 Class Initialized
INFO - 2018-02-11 22:04:34 --> URI Class Initialized
INFO - 2018-02-11 22:04:34 --> Router Class Initialized
INFO - 2018-02-11 22:04:34 --> Router Class Initialized
INFO - 2018-02-11 22:04:34 --> Output Class Initialized
INFO - 2018-02-11 22:04:34 --> Output Class Initialized
INFO - 2018-02-11 22:04:34 --> Security Class Initialized
INFO - 2018-02-11 22:04:34 --> Security Class Initialized
DEBUG - 2018-02-11 22:04:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-11 22:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 22:04:34 --> Input Class Initialized
INFO - 2018-02-11 22:04:34 --> Input Class Initialized
INFO - 2018-02-11 22:04:34 --> Language Class Initialized
INFO - 2018-02-11 22:04:34 --> Language Class Initialized
INFO - 2018-02-11 22:04:34 --> Loader Class Initialized
INFO - 2018-02-11 22:04:34 --> Loader Class Initialized
INFO - 2018-02-11 22:04:34 --> Helper loaded: url_helper
INFO - 2018-02-11 22:04:34 --> Helper loaded: url_helper
INFO - 2018-02-11 22:04:34 --> Helper loaded: form_helper
INFO - 2018-02-11 22:04:34 --> Helper loaded: form_helper
INFO - 2018-02-11 22:04:34 --> Database Driver Class Initialized
INFO - 2018-02-11 22:04:34 --> Database Driver Class Initialized
DEBUG - 2018-02-11 22:04:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 22:04:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 22:04:34 --> Form Validation Class Initialized
INFO - 2018-02-11 22:04:34 --> Model Class Initialized
INFO - 2018-02-11 22:04:34 --> Controller Class Initialized
INFO - 2018-02-11 22:04:34 --> Model Class Initialized
INFO - 2018-02-11 22:04:34 --> Model Class Initialized
INFO - 2018-02-11 22:04:34 --> Model Class Initialized
INFO - 2018-02-11 22:04:34 --> Model Class Initialized
INFO - 2018-02-11 22:04:34 --> Model Class Initialized
DEBUG - 2018-02-11 22:04:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2018-02-11 22:04:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 22:04:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 22:04:34 --> Form Validation Class Initialized
INFO - 2018-02-11 22:04:34 --> Model Class Initialized
INFO - 2018-02-11 22:04:34 --> Controller Class Initialized
INFO - 2018-02-11 22:04:34 --> Model Class Initialized
INFO - 2018-02-11 22:04:34 --> Model Class Initialized
INFO - 2018-02-11 22:04:34 --> Model Class Initialized
INFO - 2018-02-11 22:04:34 --> Model Class Initialized
INFO - 2018-02-11 22:04:34 --> Model Class Initialized
DEBUG - 2018-02-11 22:04:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 22:04:55 --> Config Class Initialized
INFO - 2018-02-11 22:04:55 --> Hooks Class Initialized
DEBUG - 2018-02-11 22:04:55 --> UTF-8 Support Enabled
INFO - 2018-02-11 22:04:55 --> Utf8 Class Initialized
INFO - 2018-02-11 22:04:55 --> URI Class Initialized
INFO - 2018-02-11 22:04:55 --> Router Class Initialized
INFO - 2018-02-11 22:04:55 --> Output Class Initialized
INFO - 2018-02-11 22:04:55 --> Security Class Initialized
DEBUG - 2018-02-11 22:04:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 22:04:55 --> Input Class Initialized
INFO - 2018-02-11 22:04:55 --> Language Class Initialized
INFO - 2018-02-11 22:04:55 --> Loader Class Initialized
INFO - 2018-02-11 22:04:55 --> Helper loaded: url_helper
INFO - 2018-02-11 22:04:55 --> Helper loaded: form_helper
INFO - 2018-02-11 22:04:55 --> Database Driver Class Initialized
DEBUG - 2018-02-11 22:04:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 22:04:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 22:04:55 --> Form Validation Class Initialized
INFO - 2018-02-11 22:04:55 --> Model Class Initialized
INFO - 2018-02-11 22:04:55 --> Controller Class Initialized
INFO - 2018-02-11 22:04:55 --> Model Class Initialized
INFO - 2018-02-11 22:04:55 --> Model Class Initialized
INFO - 2018-02-11 22:04:55 --> Model Class Initialized
INFO - 2018-02-11 22:04:55 --> Model Class Initialized
INFO - 2018-02-11 22:04:55 --> Model Class Initialized
DEBUG - 2018-02-11 22:04:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 22:04:55 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-11 22:04:55 --> Final output sent to browser
DEBUG - 2018-02-11 22:04:55 --> Total execution time: 0.0627
INFO - 2018-02-11 22:04:55 --> Config Class Initialized
INFO - 2018-02-11 22:04:55 --> Hooks Class Initialized
INFO - 2018-02-11 22:04:55 --> Config Class Initialized
INFO - 2018-02-11 22:04:55 --> Hooks Class Initialized
INFO - 2018-02-11 22:04:55 --> Config Class Initialized
INFO - 2018-02-11 22:04:55 --> Hooks Class Initialized
DEBUG - 2018-02-11 22:04:55 --> UTF-8 Support Enabled
DEBUG - 2018-02-11 22:04:55 --> UTF-8 Support Enabled
INFO - 2018-02-11 22:04:55 --> Utf8 Class Initialized
DEBUG - 2018-02-11 22:04:55 --> UTF-8 Support Enabled
INFO - 2018-02-11 22:04:55 --> Utf8 Class Initialized
INFO - 2018-02-11 22:04:55 --> Utf8 Class Initialized
INFO - 2018-02-11 22:04:55 --> URI Class Initialized
INFO - 2018-02-11 22:04:55 --> URI Class Initialized
INFO - 2018-02-11 22:04:55 --> URI Class Initialized
INFO - 2018-02-11 22:04:55 --> Router Class Initialized
INFO - 2018-02-11 22:04:55 --> Router Class Initialized
INFO - 2018-02-11 22:04:55 --> Router Class Initialized
INFO - 2018-02-11 22:04:55 --> Output Class Initialized
INFO - 2018-02-11 22:04:55 --> Output Class Initialized
INFO - 2018-02-11 22:04:55 --> Output Class Initialized
INFO - 2018-02-11 22:04:55 --> Security Class Initialized
INFO - 2018-02-11 22:04:55 --> Security Class Initialized
INFO - 2018-02-11 22:04:55 --> Security Class Initialized
DEBUG - 2018-02-11 22:04:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 22:04:55 --> Input Class Initialized
DEBUG - 2018-02-11 22:04:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 22:04:55 --> Language Class Initialized
DEBUG - 2018-02-11 22:04:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 22:04:55 --> Input Class Initialized
INFO - 2018-02-11 22:04:55 --> Input Class Initialized
ERROR - 2018-02-11 22:04:55 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-11 22:04:55 --> Language Class Initialized
INFO - 2018-02-11 22:04:55 --> Language Class Initialized
ERROR - 2018-02-11 22:04:55 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-02-11 22:04:55 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-11 22:04:55 --> Config Class Initialized
INFO - 2018-02-11 22:04:55 --> Hooks Class Initialized
DEBUG - 2018-02-11 22:04:55 --> UTF-8 Support Enabled
INFO - 2018-02-11 22:04:55 --> Utf8 Class Initialized
INFO - 2018-02-11 22:04:55 --> URI Class Initialized
INFO - 2018-02-11 22:04:55 --> Router Class Initialized
INFO - 2018-02-11 22:04:55 --> Output Class Initialized
INFO - 2018-02-11 22:04:55 --> Security Class Initialized
DEBUG - 2018-02-11 22:04:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 22:04:55 --> Input Class Initialized
INFO - 2018-02-11 22:04:55 --> Language Class Initialized
ERROR - 2018-02-11 22:04:55 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-02-11 22:04:55 --> Config Class Initialized
INFO - 2018-02-11 22:04:55 --> Config Class Initialized
INFO - 2018-02-11 22:04:55 --> Hooks Class Initialized
INFO - 2018-02-11 22:04:55 --> Hooks Class Initialized
INFO - 2018-02-11 22:04:55 --> Config Class Initialized
INFO - 2018-02-11 22:04:55 --> Hooks Class Initialized
DEBUG - 2018-02-11 22:04:55 --> UTF-8 Support Enabled
INFO - 2018-02-11 22:04:55 --> Utf8 Class Initialized
DEBUG - 2018-02-11 22:04:55 --> UTF-8 Support Enabled
DEBUG - 2018-02-11 22:04:55 --> UTF-8 Support Enabled
INFO - 2018-02-11 22:04:55 --> Utf8 Class Initialized
INFO - 2018-02-11 22:04:55 --> Utf8 Class Initialized
INFO - 2018-02-11 22:04:55 --> URI Class Initialized
INFO - 2018-02-11 22:04:55 --> URI Class Initialized
INFO - 2018-02-11 22:04:55 --> URI Class Initialized
INFO - 2018-02-11 22:04:55 --> Router Class Initialized
INFO - 2018-02-11 22:04:55 --> Router Class Initialized
INFO - 2018-02-11 22:04:55 --> Router Class Initialized
INFO - 2018-02-11 22:04:55 --> Output Class Initialized
INFO - 2018-02-11 22:04:55 --> Output Class Initialized
INFO - 2018-02-11 22:04:55 --> Output Class Initialized
INFO - 2018-02-11 22:04:55 --> Security Class Initialized
INFO - 2018-02-11 22:04:55 --> Security Class Initialized
INFO - 2018-02-11 22:04:55 --> Security Class Initialized
DEBUG - 2018-02-11 22:04:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 22:04:55 --> Input Class Initialized
DEBUG - 2018-02-11 22:04:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-11 22:04:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 22:04:55 --> Input Class Initialized
INFO - 2018-02-11 22:04:55 --> Input Class Initialized
INFO - 2018-02-11 22:04:55 --> Language Class Initialized
INFO - 2018-02-11 22:04:55 --> Language Class Initialized
INFO - 2018-02-11 22:04:55 --> Language Class Initialized
ERROR - 2018-02-11 22:04:55 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-11 22:04:55 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-02-11 22:04:55 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-02-11 22:04:55 --> Config Class Initialized
INFO - 2018-02-11 22:04:55 --> Hooks Class Initialized
INFO - 2018-02-11 22:04:55 --> Config Class Initialized
INFO - 2018-02-11 22:04:55 --> Hooks Class Initialized
DEBUG - 2018-02-11 22:04:55 --> UTF-8 Support Enabled
INFO - 2018-02-11 22:04:55 --> Utf8 Class Initialized
INFO - 2018-02-11 22:04:56 --> URI Class Initialized
DEBUG - 2018-02-11 22:04:56 --> UTF-8 Support Enabled
INFO - 2018-02-11 22:04:56 --> Utf8 Class Initialized
INFO - 2018-02-11 22:04:56 --> Router Class Initialized
INFO - 2018-02-11 22:04:56 --> URI Class Initialized
INFO - 2018-02-11 22:04:56 --> Output Class Initialized
INFO - 2018-02-11 22:04:56 --> Router Class Initialized
INFO - 2018-02-11 22:04:56 --> Security Class Initialized
DEBUG - 2018-02-11 22:04:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 22:04:56 --> Input Class Initialized
INFO - 2018-02-11 22:04:56 --> Output Class Initialized
INFO - 2018-02-11 22:04:56 --> Language Class Initialized
INFO - 2018-02-11 22:04:56 --> Security Class Initialized
DEBUG - 2018-02-11 22:04:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-11 22:04:56 --> Loader Class Initialized
INFO - 2018-02-11 22:04:56 --> Input Class Initialized
INFO - 2018-02-11 22:04:56 --> Language Class Initialized
INFO - 2018-02-11 22:04:56 --> Helper loaded: url_helper
INFO - 2018-02-11 22:04:56 --> Helper loaded: form_helper
INFO - 2018-02-11 22:04:56 --> Loader Class Initialized
INFO - 2018-02-11 22:04:56 --> Helper loaded: url_helper
INFO - 2018-02-11 22:04:56 --> Helper loaded: form_helper
INFO - 2018-02-11 22:04:56 --> Database Driver Class Initialized
DEBUG - 2018-02-11 22:04:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 22:04:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 22:04:56 --> Database Driver Class Initialized
INFO - 2018-02-11 22:04:56 --> Form Validation Class Initialized
INFO - 2018-02-11 22:04:56 --> Model Class Initialized
INFO - 2018-02-11 22:04:56 --> Controller Class Initialized
DEBUG - 2018-02-11 22:04:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-11 22:04:56 --> Model Class Initialized
INFO - 2018-02-11 22:04:56 --> Model Class Initialized
INFO - 2018-02-11 22:04:56 --> Model Class Initialized
INFO - 2018-02-11 22:04:56 --> Model Class Initialized
INFO - 2018-02-11 22:04:56 --> Model Class Initialized
DEBUG - 2018-02-11 22:04:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-11 22:04:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-11 22:04:56 --> Form Validation Class Initialized
INFO - 2018-02-11 22:04:56 --> Model Class Initialized
INFO - 2018-02-11 22:04:56 --> Controller Class Initialized
INFO - 2018-02-11 22:04:56 --> Model Class Initialized
INFO - 2018-02-11 22:04:56 --> Model Class Initialized
INFO - 2018-02-11 22:04:56 --> Model Class Initialized
INFO - 2018-02-11 22:04:56 --> Model Class Initialized
INFO - 2018-02-11 22:04:56 --> Model Class Initialized
DEBUG - 2018-02-11 22:04:56 --> Form_validation class already loaded. Second attempt ignored.
