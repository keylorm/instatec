<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-03-05 23:17:57 --> Config Class Initialized
INFO - 2018-03-05 23:17:57 --> Hooks Class Initialized
DEBUG - 2018-03-05 23:17:57 --> UTF-8 Support Enabled
INFO - 2018-03-05 23:17:57 --> Utf8 Class Initialized
INFO - 2018-03-05 23:17:57 --> URI Class Initialized
INFO - 2018-03-05 23:17:57 --> Router Class Initialized
INFO - 2018-03-05 23:17:57 --> Output Class Initialized
INFO - 2018-03-05 23:17:57 --> Security Class Initialized
DEBUG - 2018-03-05 23:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-05 23:17:57 --> Input Class Initialized
INFO - 2018-03-05 23:17:57 --> Language Class Initialized
INFO - 2018-03-05 23:17:57 --> Loader Class Initialized
INFO - 2018-03-05 23:17:57 --> Helper loaded: url_helper
INFO - 2018-03-05 23:17:57 --> Helper loaded: form_helper
INFO - 2018-03-05 23:17:57 --> Database Driver Class Initialized
DEBUG - 2018-03-05 23:17:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-05 23:17:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-05 23:17:57 --> Form Validation Class Initialized
INFO - 2018-03-05 23:17:57 --> Model Class Initialized
INFO - 2018-03-05 23:17:57 --> Controller Class Initialized
INFO - 2018-03-05 23:17:57 --> Model Class Initialized
INFO - 2018-03-05 23:17:57 --> Model Class Initialized
INFO - 2018-03-05 23:17:57 --> Model Class Initialized
INFO - 2018-03-05 23:17:57 --> Model Class Initialized
INFO - 2018-03-05 23:17:57 --> Model Class Initialized
DEBUG - 2018-03-05 23:17:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-05 23:17:57 --> Config Class Initialized
INFO - 2018-03-05 23:17:57 --> Hooks Class Initialized
DEBUG - 2018-03-05 23:17:57 --> UTF-8 Support Enabled
INFO - 2018-03-05 23:17:57 --> Utf8 Class Initialized
INFO - 2018-03-05 23:17:57 --> URI Class Initialized
INFO - 2018-03-05 23:17:57 --> Router Class Initialized
INFO - 2018-03-05 23:17:57 --> Output Class Initialized
INFO - 2018-03-05 23:17:57 --> Security Class Initialized
DEBUG - 2018-03-05 23:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-05 23:17:57 --> Input Class Initialized
INFO - 2018-03-05 23:17:57 --> Language Class Initialized
INFO - 2018-03-05 23:17:57 --> Loader Class Initialized
INFO - 2018-03-05 23:17:57 --> Helper loaded: url_helper
INFO - 2018-03-05 23:17:57 --> Helper loaded: form_helper
INFO - 2018-03-05 23:17:57 --> Database Driver Class Initialized
DEBUG - 2018-03-05 23:17:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-05 23:17:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-05 23:17:57 --> Form Validation Class Initialized
INFO - 2018-03-05 23:17:57 --> Model Class Initialized
INFO - 2018-03-05 23:17:57 --> Controller Class Initialized
INFO - 2018-03-05 23:17:57 --> Model Class Initialized
DEBUG - 2018-03-05 23:17:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-05 23:17:57 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-05 23:17:57 --> Final output sent to browser
DEBUG - 2018-03-05 23:17:57 --> Total execution time: 0.1401
INFO - 2018-03-05 23:18:00 --> Config Class Initialized
INFO - 2018-03-05 23:18:00 --> Hooks Class Initialized
DEBUG - 2018-03-05 23:18:00 --> UTF-8 Support Enabled
INFO - 2018-03-05 23:18:00 --> Utf8 Class Initialized
INFO - 2018-03-05 23:18:00 --> URI Class Initialized
INFO - 2018-03-05 23:18:00 --> Router Class Initialized
INFO - 2018-03-05 23:18:00 --> Output Class Initialized
INFO - 2018-03-05 23:18:00 --> Security Class Initialized
DEBUG - 2018-03-05 23:18:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-05 23:18:00 --> Input Class Initialized
INFO - 2018-03-05 23:18:00 --> Language Class Initialized
INFO - 2018-03-05 23:18:00 --> Loader Class Initialized
INFO - 2018-03-05 23:18:00 --> Helper loaded: url_helper
INFO - 2018-03-05 23:18:00 --> Helper loaded: form_helper
INFO - 2018-03-05 23:18:00 --> Database Driver Class Initialized
DEBUG - 2018-03-05 23:18:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-05 23:18:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-05 23:18:00 --> Form Validation Class Initialized
INFO - 2018-03-05 23:18:00 --> Model Class Initialized
INFO - 2018-03-05 23:18:00 --> Controller Class Initialized
INFO - 2018-03-05 23:18:00 --> Model Class Initialized
DEBUG - 2018-03-05 23:18:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-05 23:18:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-05 23:18:01 --> Config Class Initialized
INFO - 2018-03-05 23:18:01 --> Hooks Class Initialized
DEBUG - 2018-03-05 23:18:01 --> UTF-8 Support Enabled
INFO - 2018-03-05 23:18:01 --> Utf8 Class Initialized
INFO - 2018-03-05 23:18:01 --> URI Class Initialized
DEBUG - 2018-03-05 23:18:01 --> No URI present. Default controller set.
INFO - 2018-03-05 23:18:01 --> Router Class Initialized
INFO - 2018-03-05 23:18:01 --> Output Class Initialized
INFO - 2018-03-05 23:18:01 --> Security Class Initialized
DEBUG - 2018-03-05 23:18:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-05 23:18:01 --> Input Class Initialized
INFO - 2018-03-05 23:18:01 --> Language Class Initialized
INFO - 2018-03-05 23:18:01 --> Loader Class Initialized
INFO - 2018-03-05 23:18:01 --> Helper loaded: url_helper
INFO - 2018-03-05 23:18:01 --> Helper loaded: form_helper
INFO - 2018-03-05 23:18:01 --> Database Driver Class Initialized
DEBUG - 2018-03-05 23:18:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-05 23:18:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-05 23:18:01 --> Form Validation Class Initialized
INFO - 2018-03-05 23:18:01 --> Model Class Initialized
INFO - 2018-03-05 23:18:01 --> Controller Class Initialized
INFO - 2018-03-05 23:18:01 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-05 23:18:01 --> Final output sent to browser
DEBUG - 2018-03-05 23:18:01 --> Total execution time: 0.0660
INFO - 2018-03-05 23:18:01 --> Config Class Initialized
INFO - 2018-03-05 23:18:01 --> Hooks Class Initialized
DEBUG - 2018-03-05 23:18:01 --> UTF-8 Support Enabled
INFO - 2018-03-05 23:18:01 --> Utf8 Class Initialized
INFO - 2018-03-05 23:18:01 --> URI Class Initialized
INFO - 2018-03-05 23:18:01 --> Router Class Initialized
INFO - 2018-03-05 23:18:01 --> Output Class Initialized
INFO - 2018-03-05 23:18:01 --> Security Class Initialized
DEBUG - 2018-03-05 23:18:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-05 23:18:01 --> Input Class Initialized
INFO - 2018-03-05 23:18:01 --> Language Class Initialized
INFO - 2018-03-05 23:18:01 --> Loader Class Initialized
INFO - 2018-03-05 23:18:01 --> Helper loaded: url_helper
INFO - 2018-03-05 23:18:01 --> Helper loaded: form_helper
INFO - 2018-03-05 23:18:01 --> Database Driver Class Initialized
DEBUG - 2018-03-05 23:18:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-05 23:18:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-05 23:18:01 --> Form Validation Class Initialized
INFO - 2018-03-05 23:18:01 --> Model Class Initialized
INFO - 2018-03-05 23:18:01 --> Controller Class Initialized
INFO - 2018-03-05 23:18:01 --> Model Class Initialized
INFO - 2018-03-05 23:18:01 --> Model Class Initialized
INFO - 2018-03-05 23:18:01 --> Model Class Initialized
INFO - 2018-03-05 23:18:01 --> Model Class Initialized
INFO - 2018-03-05 23:18:01 --> Model Class Initialized
DEBUG - 2018-03-05 23:18:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-05 23:18:14 --> Config Class Initialized
INFO - 2018-03-05 23:18:14 --> Hooks Class Initialized
DEBUG - 2018-03-05 23:18:14 --> UTF-8 Support Enabled
INFO - 2018-03-05 23:18:14 --> Utf8 Class Initialized
INFO - 2018-03-05 23:18:14 --> URI Class Initialized
INFO - 2018-03-05 23:18:14 --> Router Class Initialized
INFO - 2018-03-05 23:18:14 --> Output Class Initialized
INFO - 2018-03-05 23:18:14 --> Security Class Initialized
DEBUG - 2018-03-05 23:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-05 23:18:14 --> Input Class Initialized
INFO - 2018-03-05 23:18:14 --> Language Class Initialized
INFO - 2018-03-05 23:18:14 --> Loader Class Initialized
INFO - 2018-03-05 23:18:14 --> Helper loaded: url_helper
INFO - 2018-03-05 23:18:14 --> Helper loaded: form_helper
INFO - 2018-03-05 23:18:14 --> Database Driver Class Initialized
DEBUG - 2018-03-05 23:18:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-05 23:18:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-05 23:18:14 --> Form Validation Class Initialized
INFO - 2018-03-05 23:18:14 --> Model Class Initialized
INFO - 2018-03-05 23:18:14 --> Controller Class Initialized
INFO - 2018-03-05 23:18:14 --> Model Class Initialized
INFO - 2018-03-05 23:18:14 --> Model Class Initialized
INFO - 2018-03-05 23:18:14 --> Model Class Initialized
INFO - 2018-03-05 23:18:14 --> Model Class Initialized
INFO - 2018-03-05 23:18:14 --> Model Class Initialized
DEBUG - 2018-03-05 23:18:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-05 23:18:15 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-05 23:18:15 --> Final output sent to browser
DEBUG - 2018-03-05 23:18:15 --> Total execution time: 0.1132
INFO - 2018-03-05 23:18:15 --> Config Class Initialized
INFO - 2018-03-05 23:18:15 --> Hooks Class Initialized
DEBUG - 2018-03-05 23:18:15 --> UTF-8 Support Enabled
INFO - 2018-03-05 23:18:15 --> Utf8 Class Initialized
INFO - 2018-03-05 23:18:15 --> URI Class Initialized
INFO - 2018-03-05 23:18:15 --> Router Class Initialized
INFO - 2018-03-05 23:18:15 --> Output Class Initialized
INFO - 2018-03-05 23:18:15 --> Security Class Initialized
DEBUG - 2018-03-05 23:18:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-05 23:18:15 --> Input Class Initialized
INFO - 2018-03-05 23:18:15 --> Language Class Initialized
INFO - 2018-03-05 23:18:15 --> Loader Class Initialized
INFO - 2018-03-05 23:18:15 --> Helper loaded: url_helper
INFO - 2018-03-05 23:18:15 --> Helper loaded: form_helper
INFO - 2018-03-05 23:18:15 --> Database Driver Class Initialized
DEBUG - 2018-03-05 23:18:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-05 23:18:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-05 23:18:15 --> Form Validation Class Initialized
INFO - 2018-03-05 23:18:15 --> Model Class Initialized
INFO - 2018-03-05 23:18:15 --> Controller Class Initialized
INFO - 2018-03-05 23:18:15 --> Model Class Initialized
INFO - 2018-03-05 23:18:15 --> Model Class Initialized
INFO - 2018-03-05 23:18:15 --> Model Class Initialized
INFO - 2018-03-05 23:18:15 --> Model Class Initialized
INFO - 2018-03-05 23:18:15 --> Model Class Initialized
DEBUG - 2018-03-05 23:18:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-05 23:18:21 --> Config Class Initialized
INFO - 2018-03-05 23:18:21 --> Hooks Class Initialized
DEBUG - 2018-03-05 23:18:21 --> UTF-8 Support Enabled
INFO - 2018-03-05 23:18:21 --> Utf8 Class Initialized
INFO - 2018-03-05 23:18:21 --> URI Class Initialized
INFO - 2018-03-05 23:18:21 --> Router Class Initialized
INFO - 2018-03-05 23:18:21 --> Output Class Initialized
INFO - 2018-03-05 23:18:21 --> Security Class Initialized
DEBUG - 2018-03-05 23:18:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-05 23:18:21 --> Input Class Initialized
INFO - 2018-03-05 23:18:21 --> Language Class Initialized
INFO - 2018-03-05 23:18:21 --> Loader Class Initialized
INFO - 2018-03-05 23:18:21 --> Helper loaded: url_helper
INFO - 2018-03-05 23:18:21 --> Helper loaded: form_helper
INFO - 2018-03-05 23:18:21 --> Database Driver Class Initialized
DEBUG - 2018-03-05 23:18:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-05 23:18:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-05 23:18:21 --> Form Validation Class Initialized
INFO - 2018-03-05 23:18:21 --> Model Class Initialized
INFO - 2018-03-05 23:18:21 --> Controller Class Initialized
INFO - 2018-03-05 23:18:21 --> Model Class Initialized
INFO - 2018-03-05 23:18:21 --> Model Class Initialized
INFO - 2018-03-05 23:18:21 --> Model Class Initialized
INFO - 2018-03-05 23:18:21 --> Model Class Initialized
INFO - 2018-03-05 23:18:21 --> Model Class Initialized
DEBUG - 2018-03-05 23:18:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-05 23:18:21 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-05 23:18:21 --> Final output sent to browser
DEBUG - 2018-03-05 23:18:21 --> Total execution time: 0.1592
INFO - 2018-03-05 23:18:21 --> Config Class Initialized
INFO - 2018-03-05 23:18:21 --> Hooks Class Initialized
DEBUG - 2018-03-05 23:18:21 --> UTF-8 Support Enabled
INFO - 2018-03-05 23:18:21 --> Utf8 Class Initialized
INFO - 2018-03-05 23:18:21 --> URI Class Initialized
INFO - 2018-03-05 23:18:21 --> Router Class Initialized
INFO - 2018-03-05 23:18:21 --> Output Class Initialized
INFO - 2018-03-05 23:18:21 --> Security Class Initialized
DEBUG - 2018-03-05 23:18:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-05 23:18:21 --> Input Class Initialized
INFO - 2018-03-05 23:18:21 --> Language Class Initialized
INFO - 2018-03-05 23:18:21 --> Loader Class Initialized
INFO - 2018-03-05 23:18:21 --> Helper loaded: url_helper
INFO - 2018-03-05 23:18:21 --> Helper loaded: form_helper
INFO - 2018-03-05 23:18:21 --> Database Driver Class Initialized
DEBUG - 2018-03-05 23:18:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-05 23:18:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-05 23:18:21 --> Form Validation Class Initialized
INFO - 2018-03-05 23:18:21 --> Model Class Initialized
INFO - 2018-03-05 23:18:21 --> Controller Class Initialized
INFO - 2018-03-05 23:18:21 --> Model Class Initialized
INFO - 2018-03-05 23:18:21 --> Model Class Initialized
INFO - 2018-03-05 23:18:21 --> Model Class Initialized
INFO - 2018-03-05 23:18:21 --> Model Class Initialized
INFO - 2018-03-05 23:18:21 --> Model Class Initialized
DEBUG - 2018-03-05 23:18:21 --> Form_validation class already loaded. Second attempt ignored.
