<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-02-02 04:22:36 --> Config Class Initialized
INFO - 2018-02-02 04:22:36 --> Hooks Class Initialized
DEBUG - 2018-02-02 04:22:36 --> UTF-8 Support Enabled
INFO - 2018-02-02 04:22:36 --> Utf8 Class Initialized
INFO - 2018-02-02 04:22:36 --> URI Class Initialized
DEBUG - 2018-02-02 04:22:36 --> No URI present. Default controller set.
INFO - 2018-02-02 04:22:36 --> Router Class Initialized
INFO - 2018-02-02 04:22:36 --> Output Class Initialized
INFO - 2018-02-02 04:22:36 --> Security Class Initialized
DEBUG - 2018-02-02 04:22:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 04:22:36 --> Input Class Initialized
INFO - 2018-02-02 04:22:36 --> Language Class Initialized
INFO - 2018-02-02 04:22:36 --> Loader Class Initialized
INFO - 2018-02-02 04:22:36 --> Helper loaded: url_helper
INFO - 2018-02-02 04:22:36 --> Helper loaded: form_helper
INFO - 2018-02-02 04:22:37 --> Database Driver Class Initialized
DEBUG - 2018-02-02 04:22:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 04:22:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 04:22:37 --> Form Validation Class Initialized
INFO - 2018-02-02 04:22:37 --> Model Class Initialized
INFO - 2018-02-02 04:22:37 --> Controller Class Initialized
INFO - 2018-02-02 04:22:37 --> Config Class Initialized
INFO - 2018-02-02 04:22:37 --> Hooks Class Initialized
DEBUG - 2018-02-02 04:22:37 --> UTF-8 Support Enabled
INFO - 2018-02-02 04:22:37 --> Utf8 Class Initialized
INFO - 2018-02-02 04:22:37 --> URI Class Initialized
INFO - 2018-02-02 04:22:37 --> Router Class Initialized
INFO - 2018-02-02 04:22:37 --> Output Class Initialized
INFO - 2018-02-02 04:22:37 --> Security Class Initialized
DEBUG - 2018-02-02 04:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 04:22:37 --> Input Class Initialized
INFO - 2018-02-02 04:22:37 --> Language Class Initialized
INFO - 2018-02-02 04:22:37 --> Loader Class Initialized
INFO - 2018-02-02 04:22:37 --> Helper loaded: url_helper
INFO - 2018-02-02 04:22:37 --> Helper loaded: form_helper
INFO - 2018-02-02 04:22:37 --> Database Driver Class Initialized
DEBUG - 2018-02-02 04:22:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 04:22:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 04:22:37 --> Form Validation Class Initialized
INFO - 2018-02-02 04:22:37 --> Model Class Initialized
INFO - 2018-02-02 04:22:37 --> Controller Class Initialized
INFO - 2018-02-02 04:22:37 --> Model Class Initialized
DEBUG - 2018-02-02 04:22:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 04:22:37 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-02 04:22:37 --> Final output sent to browser
DEBUG - 2018-02-02 04:22:37 --> Total execution time: 0.2321
INFO - 2018-02-02 04:22:42 --> Config Class Initialized
INFO - 2018-02-02 04:22:42 --> Hooks Class Initialized
DEBUG - 2018-02-02 04:22:42 --> UTF-8 Support Enabled
INFO - 2018-02-02 04:22:42 --> Utf8 Class Initialized
INFO - 2018-02-02 04:22:42 --> URI Class Initialized
INFO - 2018-02-02 04:22:42 --> Router Class Initialized
INFO - 2018-02-02 04:22:42 --> Output Class Initialized
INFO - 2018-02-02 04:22:42 --> Security Class Initialized
DEBUG - 2018-02-02 04:22:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 04:22:42 --> Input Class Initialized
INFO - 2018-02-02 04:22:42 --> Language Class Initialized
INFO - 2018-02-02 04:22:42 --> Loader Class Initialized
INFO - 2018-02-02 04:22:42 --> Helper loaded: url_helper
INFO - 2018-02-02 04:22:42 --> Helper loaded: form_helper
INFO - 2018-02-02 04:22:42 --> Database Driver Class Initialized
DEBUG - 2018-02-02 04:22:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 04:22:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 04:22:42 --> Form Validation Class Initialized
INFO - 2018-02-02 04:22:42 --> Model Class Initialized
INFO - 2018-02-02 04:22:42 --> Controller Class Initialized
INFO - 2018-02-02 04:22:42 --> Model Class Initialized
DEBUG - 2018-02-02 04:22:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 04:22:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-02 04:22:43 --> Config Class Initialized
INFO - 2018-02-02 04:22:43 --> Hooks Class Initialized
DEBUG - 2018-02-02 04:22:43 --> UTF-8 Support Enabled
INFO - 2018-02-02 04:22:43 --> Utf8 Class Initialized
INFO - 2018-02-02 04:22:43 --> URI Class Initialized
DEBUG - 2018-02-02 04:22:43 --> No URI present. Default controller set.
INFO - 2018-02-02 04:22:43 --> Router Class Initialized
INFO - 2018-02-02 04:22:43 --> Output Class Initialized
INFO - 2018-02-02 04:22:43 --> Security Class Initialized
DEBUG - 2018-02-02 04:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 04:22:43 --> Input Class Initialized
INFO - 2018-02-02 04:22:43 --> Language Class Initialized
INFO - 2018-02-02 04:22:43 --> Loader Class Initialized
INFO - 2018-02-02 04:22:43 --> Helper loaded: url_helper
INFO - 2018-02-02 04:22:43 --> Helper loaded: form_helper
INFO - 2018-02-02 04:22:43 --> Database Driver Class Initialized
DEBUG - 2018-02-02 04:22:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 04:22:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 04:22:43 --> Form Validation Class Initialized
INFO - 2018-02-02 04:22:43 --> Model Class Initialized
INFO - 2018-02-02 04:22:43 --> Controller Class Initialized
INFO - 2018-02-02 04:22:43 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-02 04:22:43 --> Final output sent to browser
DEBUG - 2018-02-02 04:22:43 --> Total execution time: 0.0974
INFO - 2018-02-02 04:22:43 --> Config Class Initialized
INFO - 2018-02-02 04:22:43 --> Hooks Class Initialized
DEBUG - 2018-02-02 04:22:43 --> UTF-8 Support Enabled
INFO - 2018-02-02 04:22:43 --> Utf8 Class Initialized
INFO - 2018-02-02 04:22:43 --> URI Class Initialized
INFO - 2018-02-02 04:22:43 --> Router Class Initialized
INFO - 2018-02-02 04:22:43 --> Output Class Initialized
INFO - 2018-02-02 04:22:43 --> Security Class Initialized
DEBUG - 2018-02-02 04:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 04:22:43 --> Input Class Initialized
INFO - 2018-02-02 04:22:43 --> Language Class Initialized
INFO - 2018-02-02 04:22:43 --> Loader Class Initialized
INFO - 2018-02-02 04:22:43 --> Helper loaded: url_helper
INFO - 2018-02-02 04:22:43 --> Helper loaded: form_helper
INFO - 2018-02-02 04:22:43 --> Database Driver Class Initialized
DEBUG - 2018-02-02 04:22:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 04:22:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 04:22:43 --> Form Validation Class Initialized
INFO - 2018-02-02 04:22:43 --> Model Class Initialized
INFO - 2018-02-02 04:22:43 --> Controller Class Initialized
INFO - 2018-02-02 04:22:43 --> Model Class Initialized
INFO - 2018-02-02 04:22:43 --> Model Class Initialized
INFO - 2018-02-02 04:22:43 --> Model Class Initialized
INFO - 2018-02-02 04:22:43 --> Model Class Initialized
DEBUG - 2018-02-02 04:22:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 04:25:31 --> Config Class Initialized
INFO - 2018-02-02 04:25:31 --> Hooks Class Initialized
DEBUG - 2018-02-02 04:25:31 --> UTF-8 Support Enabled
INFO - 2018-02-02 04:25:31 --> Utf8 Class Initialized
INFO - 2018-02-02 04:25:31 --> URI Class Initialized
INFO - 2018-02-02 04:25:31 --> Router Class Initialized
INFO - 2018-02-02 04:25:31 --> Output Class Initialized
INFO - 2018-02-02 04:25:31 --> Security Class Initialized
DEBUG - 2018-02-02 04:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 04:25:31 --> Input Class Initialized
INFO - 2018-02-02 04:25:31 --> Language Class Initialized
INFO - 2018-02-02 04:25:31 --> Loader Class Initialized
INFO - 2018-02-02 04:25:31 --> Helper loaded: url_helper
INFO - 2018-02-02 04:25:31 --> Helper loaded: form_helper
INFO - 2018-02-02 04:25:31 --> Database Driver Class Initialized
DEBUG - 2018-02-02 04:25:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 04:25:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 04:25:31 --> Form Validation Class Initialized
INFO - 2018-02-02 04:25:31 --> Model Class Initialized
INFO - 2018-02-02 04:25:31 --> Controller Class Initialized
INFO - 2018-02-02 04:25:31 --> Model Class Initialized
DEBUG - 2018-02-02 04:25:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 04:25:31 --> Config Class Initialized
INFO - 2018-02-02 04:25:31 --> Hooks Class Initialized
DEBUG - 2018-02-02 04:25:31 --> UTF-8 Support Enabled
INFO - 2018-02-02 04:25:31 --> Utf8 Class Initialized
INFO - 2018-02-02 04:25:31 --> URI Class Initialized
INFO - 2018-02-02 04:25:31 --> Router Class Initialized
INFO - 2018-02-02 04:25:31 --> Output Class Initialized
INFO - 2018-02-02 04:25:31 --> Security Class Initialized
DEBUG - 2018-02-02 04:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 04:25:31 --> Input Class Initialized
INFO - 2018-02-02 04:25:31 --> Language Class Initialized
INFO - 2018-02-02 04:25:31 --> Loader Class Initialized
INFO - 2018-02-02 04:25:31 --> Helper loaded: url_helper
INFO - 2018-02-02 04:25:31 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-02 04:25:31 --> Final output sent to browser
INFO - 2018-02-02 04:25:31 --> Helper loaded: form_helper
DEBUG - 2018-02-02 04:25:31 --> Total execution time: 0.1827
INFO - 2018-02-02 04:25:31 --> Database Driver Class Initialized
DEBUG - 2018-02-02 04:25:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 04:25:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 04:25:31 --> Form Validation Class Initialized
INFO - 2018-02-02 04:25:31 --> Model Class Initialized
INFO - 2018-02-02 04:25:31 --> Controller Class Initialized
INFO - 2018-02-02 04:25:31 --> Model Class Initialized
DEBUG - 2018-02-02 04:25:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 04:25:31 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-02 04:25:31 --> Final output sent to browser
DEBUG - 2018-02-02 04:25:31 --> Total execution time: 0.0648
INFO - 2018-02-02 04:25:31 --> Config Class Initialized
INFO - 2018-02-02 04:25:31 --> Hooks Class Initialized
DEBUG - 2018-02-02 04:25:31 --> UTF-8 Support Enabled
INFO - 2018-02-02 04:25:31 --> Utf8 Class Initialized
INFO - 2018-02-02 04:25:31 --> URI Class Initialized
INFO - 2018-02-02 04:25:31 --> Router Class Initialized
INFO - 2018-02-02 04:25:31 --> Output Class Initialized
INFO - 2018-02-02 04:25:31 --> Security Class Initialized
DEBUG - 2018-02-02 04:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 04:25:31 --> Input Class Initialized
INFO - 2018-02-02 04:25:31 --> Language Class Initialized
INFO - 2018-02-02 04:25:31 --> Loader Class Initialized
INFO - 2018-02-02 04:25:31 --> Helper loaded: url_helper
INFO - 2018-02-02 04:25:31 --> Helper loaded: form_helper
INFO - 2018-02-02 04:25:31 --> Database Driver Class Initialized
DEBUG - 2018-02-02 04:25:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 04:25:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 04:25:31 --> Form Validation Class Initialized
INFO - 2018-02-02 04:25:31 --> Model Class Initialized
INFO - 2018-02-02 04:25:31 --> Controller Class Initialized
INFO - 2018-02-02 04:25:31 --> Model Class Initialized
DEBUG - 2018-02-02 04:25:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 05:17:38 --> Config Class Initialized
INFO - 2018-02-02 05:17:38 --> Hooks Class Initialized
DEBUG - 2018-02-02 05:17:38 --> UTF-8 Support Enabled
INFO - 2018-02-02 05:17:38 --> Utf8 Class Initialized
INFO - 2018-02-02 05:17:38 --> URI Class Initialized
INFO - 2018-02-02 05:17:38 --> Router Class Initialized
INFO - 2018-02-02 05:17:38 --> Output Class Initialized
INFO - 2018-02-02 05:17:38 --> Security Class Initialized
DEBUG - 2018-02-02 05:17:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 05:17:38 --> Input Class Initialized
INFO - 2018-02-02 05:17:38 --> Language Class Initialized
INFO - 2018-02-02 05:17:38 --> Loader Class Initialized
INFO - 2018-02-02 05:17:38 --> Helper loaded: url_helper
INFO - 2018-02-02 05:17:38 --> Helper loaded: form_helper
INFO - 2018-02-02 05:17:38 --> Database Driver Class Initialized
DEBUG - 2018-02-02 05:17:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 05:17:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 05:17:38 --> Form Validation Class Initialized
INFO - 2018-02-02 05:17:38 --> Model Class Initialized
INFO - 2018-02-02 05:17:38 --> Controller Class Initialized
INFO - 2018-02-02 05:17:38 --> Model Class Initialized
DEBUG - 2018-02-02 05:17:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 05:17:38 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-02 05:17:38 --> Final output sent to browser
DEBUG - 2018-02-02 05:17:38 --> Total execution time: 0.3734
INFO - 2018-02-02 05:17:40 --> Config Class Initialized
INFO - 2018-02-02 05:17:40 --> Hooks Class Initialized
DEBUG - 2018-02-02 05:17:40 --> UTF-8 Support Enabled
INFO - 2018-02-02 05:17:40 --> Utf8 Class Initialized
INFO - 2018-02-02 05:17:40 --> URI Class Initialized
INFO - 2018-02-02 05:17:40 --> Router Class Initialized
INFO - 2018-02-02 05:17:40 --> Output Class Initialized
INFO - 2018-02-02 05:17:40 --> Security Class Initialized
DEBUG - 2018-02-02 05:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 05:17:40 --> Input Class Initialized
INFO - 2018-02-02 05:17:40 --> Language Class Initialized
INFO - 2018-02-02 05:17:40 --> Loader Class Initialized
INFO - 2018-02-02 05:17:40 --> Helper loaded: url_helper
INFO - 2018-02-02 05:17:40 --> Helper loaded: form_helper
INFO - 2018-02-02 05:17:40 --> Database Driver Class Initialized
DEBUG - 2018-02-02 05:17:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 05:17:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 05:17:40 --> Form Validation Class Initialized
INFO - 2018-02-02 05:17:40 --> Model Class Initialized
INFO - 2018-02-02 05:17:40 --> Controller Class Initialized
INFO - 2018-02-02 05:17:40 --> Model Class Initialized
DEBUG - 2018-02-02 05:17:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 05:17:49 --> Config Class Initialized
INFO - 2018-02-02 05:17:49 --> Hooks Class Initialized
DEBUG - 2018-02-02 05:17:49 --> UTF-8 Support Enabled
INFO - 2018-02-02 05:17:49 --> Utf8 Class Initialized
INFO - 2018-02-02 05:17:49 --> URI Class Initialized
INFO - 2018-02-02 05:17:49 --> Router Class Initialized
INFO - 2018-02-02 05:17:49 --> Output Class Initialized
INFO - 2018-02-02 05:17:49 --> Security Class Initialized
DEBUG - 2018-02-02 05:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 05:17:49 --> Input Class Initialized
INFO - 2018-02-02 05:17:49 --> Language Class Initialized
INFO - 2018-02-02 05:17:49 --> Loader Class Initialized
INFO - 2018-02-02 05:17:49 --> Helper loaded: url_helper
INFO - 2018-02-02 05:17:49 --> Helper loaded: form_helper
INFO - 2018-02-02 05:17:49 --> Database Driver Class Initialized
DEBUG - 2018-02-02 05:17:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 05:17:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 05:17:49 --> Form Validation Class Initialized
INFO - 2018-02-02 05:17:49 --> Model Class Initialized
INFO - 2018-02-02 05:17:49 --> Controller Class Initialized
INFO - 2018-02-02 05:17:49 --> Model Class Initialized
DEBUG - 2018-02-02 05:17:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 05:17:49 --> Config Class Initialized
INFO - 2018-02-02 05:17:49 --> Hooks Class Initialized
DEBUG - 2018-02-02 05:17:49 --> UTF-8 Support Enabled
INFO - 2018-02-02 05:17:49 --> Utf8 Class Initialized
INFO - 2018-02-02 05:17:49 --> URI Class Initialized
INFO - 2018-02-02 05:17:49 --> Router Class Initialized
INFO - 2018-02-02 05:17:49 --> Output Class Initialized
INFO - 2018-02-02 05:17:49 --> Security Class Initialized
DEBUG - 2018-02-02 05:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 05:17:49 --> Input Class Initialized
INFO - 2018-02-02 05:17:49 --> Language Class Initialized
INFO - 2018-02-02 05:17:49 --> Loader Class Initialized
INFO - 2018-02-02 05:17:49 --> Helper loaded: url_helper
INFO - 2018-02-02 05:17:49 --> Helper loaded: form_helper
INFO - 2018-02-02 05:17:49 --> Database Driver Class Initialized
DEBUG - 2018-02-02 05:17:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 05:17:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 05:17:49 --> Form Validation Class Initialized
INFO - 2018-02-02 05:17:49 --> Model Class Initialized
INFO - 2018-02-02 05:17:49 --> Controller Class Initialized
INFO - 2018-02-02 05:17:49 --> Model Class Initialized
DEBUG - 2018-02-02 05:17:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 05:17:49 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-02 05:17:49 --> Final output sent to browser
DEBUG - 2018-02-02 05:17:49 --> Total execution time: 0.0529
INFO - 2018-02-02 05:17:52 --> Config Class Initialized
INFO - 2018-02-02 05:17:52 --> Hooks Class Initialized
DEBUG - 2018-02-02 05:17:52 --> UTF-8 Support Enabled
INFO - 2018-02-02 05:17:52 --> Utf8 Class Initialized
INFO - 2018-02-02 05:17:52 --> URI Class Initialized
INFO - 2018-02-02 05:17:52 --> Router Class Initialized
INFO - 2018-02-02 05:17:52 --> Output Class Initialized
INFO - 2018-02-02 05:17:52 --> Security Class Initialized
DEBUG - 2018-02-02 05:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 05:17:52 --> Input Class Initialized
INFO - 2018-02-02 05:17:52 --> Language Class Initialized
INFO - 2018-02-02 05:17:52 --> Loader Class Initialized
INFO - 2018-02-02 05:17:52 --> Helper loaded: url_helper
INFO - 2018-02-02 05:17:52 --> Helper loaded: form_helper
INFO - 2018-02-02 05:17:52 --> Database Driver Class Initialized
DEBUG - 2018-02-02 05:17:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 05:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 05:17:52 --> Form Validation Class Initialized
INFO - 2018-02-02 05:17:52 --> Model Class Initialized
INFO - 2018-02-02 05:17:52 --> Controller Class Initialized
INFO - 2018-02-02 05:17:52 --> Model Class Initialized
DEBUG - 2018-02-02 05:17:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 05:17:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-02 05:17:52 --> Config Class Initialized
INFO - 2018-02-02 05:17:52 --> Hooks Class Initialized
DEBUG - 2018-02-02 05:17:52 --> UTF-8 Support Enabled
INFO - 2018-02-02 05:17:52 --> Utf8 Class Initialized
INFO - 2018-02-02 05:17:52 --> URI Class Initialized
DEBUG - 2018-02-02 05:17:52 --> No URI present. Default controller set.
INFO - 2018-02-02 05:17:52 --> Router Class Initialized
INFO - 2018-02-02 05:17:52 --> Output Class Initialized
INFO - 2018-02-02 05:17:52 --> Security Class Initialized
DEBUG - 2018-02-02 05:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 05:17:52 --> Input Class Initialized
INFO - 2018-02-02 05:17:52 --> Language Class Initialized
INFO - 2018-02-02 05:17:52 --> Loader Class Initialized
INFO - 2018-02-02 05:17:52 --> Helper loaded: url_helper
INFO - 2018-02-02 05:17:52 --> Helper loaded: form_helper
INFO - 2018-02-02 05:17:52 --> Database Driver Class Initialized
DEBUG - 2018-02-02 05:17:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 05:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 05:17:52 --> Form Validation Class Initialized
INFO - 2018-02-02 05:17:52 --> Model Class Initialized
INFO - 2018-02-02 05:17:52 --> Controller Class Initialized
INFO - 2018-02-02 05:17:52 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-02 05:17:52 --> Final output sent to browser
DEBUG - 2018-02-02 05:17:52 --> Total execution time: 0.0613
INFO - 2018-02-02 05:17:52 --> Config Class Initialized
INFO - 2018-02-02 05:17:52 --> Hooks Class Initialized
DEBUG - 2018-02-02 05:17:52 --> UTF-8 Support Enabled
INFO - 2018-02-02 05:17:52 --> Utf8 Class Initialized
INFO - 2018-02-02 05:17:52 --> URI Class Initialized
INFO - 2018-02-02 05:17:52 --> Router Class Initialized
INFO - 2018-02-02 05:17:52 --> Output Class Initialized
INFO - 2018-02-02 05:17:52 --> Security Class Initialized
DEBUG - 2018-02-02 05:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 05:17:52 --> Input Class Initialized
INFO - 2018-02-02 05:17:52 --> Language Class Initialized
INFO - 2018-02-02 05:17:52 --> Loader Class Initialized
INFO - 2018-02-02 05:17:52 --> Helper loaded: url_helper
INFO - 2018-02-02 05:17:52 --> Helper loaded: form_helper
INFO - 2018-02-02 05:17:52 --> Database Driver Class Initialized
DEBUG - 2018-02-02 05:17:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 05:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 05:17:52 --> Form Validation Class Initialized
INFO - 2018-02-02 05:17:52 --> Model Class Initialized
INFO - 2018-02-02 05:17:52 --> Controller Class Initialized
INFO - 2018-02-02 05:17:52 --> Model Class Initialized
INFO - 2018-02-02 05:17:52 --> Model Class Initialized
INFO - 2018-02-02 05:17:52 --> Model Class Initialized
INFO - 2018-02-02 05:17:52 --> Model Class Initialized
DEBUG - 2018-02-02 05:17:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 05:17:54 --> Config Class Initialized
INFO - 2018-02-02 05:17:54 --> Hooks Class Initialized
DEBUG - 2018-02-02 05:17:54 --> UTF-8 Support Enabled
INFO - 2018-02-02 05:17:54 --> Utf8 Class Initialized
INFO - 2018-02-02 05:17:54 --> URI Class Initialized
INFO - 2018-02-02 05:17:54 --> Router Class Initialized
INFO - 2018-02-02 05:17:54 --> Output Class Initialized
INFO - 2018-02-02 05:17:54 --> Security Class Initialized
DEBUG - 2018-02-02 05:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 05:17:54 --> Input Class Initialized
INFO - 2018-02-02 05:17:54 --> Language Class Initialized
INFO - 2018-02-02 05:17:54 --> Loader Class Initialized
INFO - 2018-02-02 05:17:54 --> Helper loaded: url_helper
INFO - 2018-02-02 05:17:54 --> Helper loaded: form_helper
INFO - 2018-02-02 05:17:54 --> Database Driver Class Initialized
DEBUG - 2018-02-02 05:17:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 05:17:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 05:17:54 --> Form Validation Class Initialized
INFO - 2018-02-02 05:17:54 --> Model Class Initialized
INFO - 2018-02-02 05:17:54 --> Controller Class Initialized
INFO - 2018-02-02 05:17:54 --> Model Class Initialized
DEBUG - 2018-02-02 05:17:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 05:17:54 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-02 05:17:54 --> Final output sent to browser
DEBUG - 2018-02-02 05:17:54 --> Total execution time: 0.0464
INFO - 2018-02-02 05:17:54 --> Config Class Initialized
INFO - 2018-02-02 05:17:54 --> Hooks Class Initialized
DEBUG - 2018-02-02 05:17:54 --> UTF-8 Support Enabled
INFO - 2018-02-02 05:17:54 --> Utf8 Class Initialized
INFO - 2018-02-02 05:17:54 --> URI Class Initialized
INFO - 2018-02-02 05:17:54 --> Router Class Initialized
INFO - 2018-02-02 05:17:54 --> Output Class Initialized
INFO - 2018-02-02 05:17:54 --> Security Class Initialized
DEBUG - 2018-02-02 05:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 05:17:54 --> Input Class Initialized
INFO - 2018-02-02 05:17:54 --> Language Class Initialized
INFO - 2018-02-02 05:17:54 --> Loader Class Initialized
INFO - 2018-02-02 05:17:54 --> Helper loaded: url_helper
INFO - 2018-02-02 05:17:54 --> Helper loaded: form_helper
INFO - 2018-02-02 05:17:54 --> Database Driver Class Initialized
DEBUG - 2018-02-02 05:17:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 05:17:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 05:17:54 --> Form Validation Class Initialized
INFO - 2018-02-02 05:17:54 --> Model Class Initialized
INFO - 2018-02-02 05:17:54 --> Controller Class Initialized
INFO - 2018-02-02 05:17:54 --> Model Class Initialized
DEBUG - 2018-02-02 05:17:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 05:18:03 --> Config Class Initialized
INFO - 2018-02-02 05:18:03 --> Hooks Class Initialized
DEBUG - 2018-02-02 05:18:03 --> UTF-8 Support Enabled
INFO - 2018-02-02 05:18:03 --> Utf8 Class Initialized
INFO - 2018-02-02 05:18:03 --> URI Class Initialized
INFO - 2018-02-02 05:18:03 --> Router Class Initialized
INFO - 2018-02-02 05:18:03 --> Output Class Initialized
INFO - 2018-02-02 05:18:03 --> Security Class Initialized
DEBUG - 2018-02-02 05:18:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 05:18:03 --> Input Class Initialized
INFO - 2018-02-02 05:18:03 --> Language Class Initialized
INFO - 2018-02-02 05:18:03 --> Loader Class Initialized
INFO - 2018-02-02 05:18:03 --> Helper loaded: url_helper
INFO - 2018-02-02 05:18:03 --> Helper loaded: form_helper
INFO - 2018-02-02 05:18:03 --> Database Driver Class Initialized
DEBUG - 2018-02-02 05:18:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 05:18:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 05:18:03 --> Form Validation Class Initialized
INFO - 2018-02-02 05:18:03 --> Model Class Initialized
INFO - 2018-02-02 05:18:03 --> Controller Class Initialized
INFO - 2018-02-02 05:18:03 --> Model Class Initialized
DEBUG - 2018-02-02 05:18:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 05:18:05 --> Config Class Initialized
INFO - 2018-02-02 05:18:05 --> Hooks Class Initialized
DEBUG - 2018-02-02 05:18:05 --> UTF-8 Support Enabled
INFO - 2018-02-02 05:18:05 --> Utf8 Class Initialized
INFO - 2018-02-02 05:18:05 --> URI Class Initialized
INFO - 2018-02-02 05:18:05 --> Router Class Initialized
INFO - 2018-02-02 05:18:05 --> Output Class Initialized
INFO - 2018-02-02 05:18:05 --> Security Class Initialized
DEBUG - 2018-02-02 05:18:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 05:18:05 --> Input Class Initialized
INFO - 2018-02-02 05:18:05 --> Language Class Initialized
INFO - 2018-02-02 05:18:05 --> Loader Class Initialized
INFO - 2018-02-02 05:18:05 --> Helper loaded: url_helper
INFO - 2018-02-02 05:18:05 --> Helper loaded: form_helper
INFO - 2018-02-02 05:18:05 --> Database Driver Class Initialized
DEBUG - 2018-02-02 05:18:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 05:18:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 05:18:05 --> Form Validation Class Initialized
INFO - 2018-02-02 05:18:05 --> Model Class Initialized
INFO - 2018-02-02 05:18:05 --> Controller Class Initialized
INFO - 2018-02-02 05:18:05 --> Model Class Initialized
DEBUG - 2018-02-02 05:18:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 05:18:10 --> Config Class Initialized
INFO - 2018-02-02 05:18:10 --> Hooks Class Initialized
DEBUG - 2018-02-02 05:18:10 --> UTF-8 Support Enabled
INFO - 2018-02-02 05:18:10 --> Utf8 Class Initialized
INFO - 2018-02-02 05:18:10 --> URI Class Initialized
INFO - 2018-02-02 05:18:10 --> Router Class Initialized
INFO - 2018-02-02 05:18:10 --> Output Class Initialized
INFO - 2018-02-02 05:18:10 --> Security Class Initialized
DEBUG - 2018-02-02 05:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 05:18:10 --> Input Class Initialized
INFO - 2018-02-02 05:18:10 --> Language Class Initialized
INFO - 2018-02-02 05:18:10 --> Loader Class Initialized
INFO - 2018-02-02 05:18:10 --> Helper loaded: url_helper
INFO - 2018-02-02 05:18:10 --> Helper loaded: form_helper
INFO - 2018-02-02 05:18:10 --> Database Driver Class Initialized
DEBUG - 2018-02-02 05:18:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 05:18:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 05:18:10 --> Form Validation Class Initialized
INFO - 2018-02-02 05:18:10 --> Model Class Initialized
INFO - 2018-02-02 05:18:10 --> Controller Class Initialized
INFO - 2018-02-02 05:18:10 --> Model Class Initialized
DEBUG - 2018-02-02 05:18:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 05:18:10 --> Config Class Initialized
INFO - 2018-02-02 05:18:10 --> Hooks Class Initialized
DEBUG - 2018-02-02 05:18:10 --> UTF-8 Support Enabled
INFO - 2018-02-02 05:18:10 --> Utf8 Class Initialized
INFO - 2018-02-02 05:18:10 --> URI Class Initialized
INFO - 2018-02-02 05:18:10 --> Router Class Initialized
INFO - 2018-02-02 05:18:10 --> Output Class Initialized
INFO - 2018-02-02 05:18:10 --> Security Class Initialized
DEBUG - 2018-02-02 05:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 05:18:10 --> Input Class Initialized
INFO - 2018-02-02 05:18:10 --> Language Class Initialized
INFO - 2018-02-02 05:18:10 --> Loader Class Initialized
INFO - 2018-02-02 05:18:10 --> Helper loaded: url_helper
INFO - 2018-02-02 05:18:10 --> Helper loaded: form_helper
INFO - 2018-02-02 05:18:10 --> Database Driver Class Initialized
DEBUG - 2018-02-02 05:18:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 05:18:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 05:18:10 --> Form Validation Class Initialized
INFO - 2018-02-02 05:18:10 --> Model Class Initialized
INFO - 2018-02-02 05:18:10 --> Controller Class Initialized
INFO - 2018-02-02 05:18:10 --> Model Class Initialized
DEBUG - 2018-02-02 05:18:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 05:18:10 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-02 05:18:10 --> Final output sent to browser
DEBUG - 2018-02-02 05:18:10 --> Total execution time: 0.0459
INFO - 2018-02-02 05:18:10 --> Config Class Initialized
INFO - 2018-02-02 05:18:10 --> Hooks Class Initialized
DEBUG - 2018-02-02 05:18:10 --> UTF-8 Support Enabled
INFO - 2018-02-02 05:18:10 --> Utf8 Class Initialized
INFO - 2018-02-02 05:18:10 --> URI Class Initialized
INFO - 2018-02-02 05:18:10 --> Router Class Initialized
INFO - 2018-02-02 05:18:10 --> Output Class Initialized
INFO - 2018-02-02 05:18:10 --> Security Class Initialized
DEBUG - 2018-02-02 05:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 05:18:10 --> Input Class Initialized
INFO - 2018-02-02 05:18:10 --> Language Class Initialized
INFO - 2018-02-02 05:18:10 --> Loader Class Initialized
INFO - 2018-02-02 05:18:10 --> Helper loaded: url_helper
INFO - 2018-02-02 05:18:10 --> Helper loaded: form_helper
INFO - 2018-02-02 05:18:10 --> Database Driver Class Initialized
DEBUG - 2018-02-02 05:18:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 05:18:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 05:18:10 --> Form Validation Class Initialized
INFO - 2018-02-02 05:18:10 --> Model Class Initialized
INFO - 2018-02-02 05:18:10 --> Controller Class Initialized
INFO - 2018-02-02 05:18:10 --> Model Class Initialized
DEBUG - 2018-02-02 05:18:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 05:18:16 --> Config Class Initialized
INFO - 2018-02-02 05:18:16 --> Hooks Class Initialized
DEBUG - 2018-02-02 05:18:16 --> UTF-8 Support Enabled
INFO - 2018-02-02 05:18:16 --> Utf8 Class Initialized
INFO - 2018-02-02 05:18:16 --> URI Class Initialized
INFO - 2018-02-02 05:18:16 --> Router Class Initialized
INFO - 2018-02-02 05:18:16 --> Output Class Initialized
INFO - 2018-02-02 05:18:16 --> Security Class Initialized
DEBUG - 2018-02-02 05:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 05:18:16 --> Input Class Initialized
INFO - 2018-02-02 05:18:16 --> Language Class Initialized
INFO - 2018-02-02 05:18:16 --> Loader Class Initialized
INFO - 2018-02-02 05:18:16 --> Helper loaded: url_helper
INFO - 2018-02-02 05:18:16 --> Helper loaded: form_helper
INFO - 2018-02-02 05:18:16 --> Database Driver Class Initialized
DEBUG - 2018-02-02 05:18:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 05:18:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 05:18:16 --> Form Validation Class Initialized
INFO - 2018-02-02 05:18:16 --> Model Class Initialized
INFO - 2018-02-02 05:18:16 --> Controller Class Initialized
INFO - 2018-02-02 05:18:16 --> Model Class Initialized
DEBUG - 2018-02-02 05:18:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 05:18:16 --> Config Class Initialized
INFO - 2018-02-02 05:18:16 --> Hooks Class Initialized
DEBUG - 2018-02-02 05:18:16 --> UTF-8 Support Enabled
INFO - 2018-02-02 05:18:16 --> Utf8 Class Initialized
INFO - 2018-02-02 05:18:16 --> URI Class Initialized
INFO - 2018-02-02 05:18:16 --> Router Class Initialized
INFO - 2018-02-02 05:18:16 --> Output Class Initialized
INFO - 2018-02-02 05:18:16 --> Security Class Initialized
DEBUG - 2018-02-02 05:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 05:18:16 --> Input Class Initialized
INFO - 2018-02-02 05:18:16 --> Language Class Initialized
INFO - 2018-02-02 05:18:16 --> Loader Class Initialized
INFO - 2018-02-02 05:18:16 --> Helper loaded: url_helper
INFO - 2018-02-02 05:18:16 --> Helper loaded: form_helper
INFO - 2018-02-02 05:18:16 --> Database Driver Class Initialized
DEBUG - 2018-02-02 05:18:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 05:18:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 05:18:16 --> Form Validation Class Initialized
INFO - 2018-02-02 05:18:16 --> Model Class Initialized
INFO - 2018-02-02 05:18:16 --> Controller Class Initialized
INFO - 2018-02-02 05:18:16 --> Model Class Initialized
DEBUG - 2018-02-02 05:18:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 05:18:16 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-02 05:18:16 --> Final output sent to browser
DEBUG - 2018-02-02 05:18:16 --> Total execution time: 0.0422
INFO - 2018-02-02 05:18:16 --> Config Class Initialized
INFO - 2018-02-02 05:18:16 --> Hooks Class Initialized
DEBUG - 2018-02-02 05:18:16 --> UTF-8 Support Enabled
INFO - 2018-02-02 05:18:16 --> Utf8 Class Initialized
INFO - 2018-02-02 05:18:16 --> URI Class Initialized
INFO - 2018-02-02 05:18:16 --> Router Class Initialized
INFO - 2018-02-02 05:18:16 --> Output Class Initialized
INFO - 2018-02-02 05:18:16 --> Security Class Initialized
DEBUG - 2018-02-02 05:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 05:18:17 --> Input Class Initialized
INFO - 2018-02-02 05:18:17 --> Language Class Initialized
INFO - 2018-02-02 05:18:17 --> Loader Class Initialized
INFO - 2018-02-02 05:18:17 --> Helper loaded: url_helper
INFO - 2018-02-02 05:18:17 --> Helper loaded: form_helper
INFO - 2018-02-02 05:18:17 --> Database Driver Class Initialized
DEBUG - 2018-02-02 05:18:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 05:18:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 05:18:17 --> Form Validation Class Initialized
INFO - 2018-02-02 05:18:17 --> Model Class Initialized
INFO - 2018-02-02 05:18:17 --> Controller Class Initialized
INFO - 2018-02-02 05:18:17 --> Model Class Initialized
DEBUG - 2018-02-02 05:18:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 05:18:18 --> Config Class Initialized
INFO - 2018-02-02 05:18:18 --> Hooks Class Initialized
DEBUG - 2018-02-02 05:18:18 --> UTF-8 Support Enabled
INFO - 2018-02-02 05:18:18 --> Utf8 Class Initialized
INFO - 2018-02-02 05:18:18 --> URI Class Initialized
INFO - 2018-02-02 05:18:18 --> Router Class Initialized
INFO - 2018-02-02 05:18:18 --> Output Class Initialized
INFO - 2018-02-02 05:18:18 --> Security Class Initialized
DEBUG - 2018-02-02 05:18:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 05:18:18 --> Input Class Initialized
INFO - 2018-02-02 05:18:18 --> Language Class Initialized
INFO - 2018-02-02 05:18:18 --> Loader Class Initialized
INFO - 2018-02-02 05:18:18 --> Helper loaded: url_helper
INFO - 2018-02-02 05:18:18 --> Helper loaded: form_helper
INFO - 2018-02-02 05:18:18 --> Database Driver Class Initialized
DEBUG - 2018-02-02 05:18:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 05:18:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 05:18:18 --> Form Validation Class Initialized
INFO - 2018-02-02 05:18:18 --> Model Class Initialized
INFO - 2018-02-02 05:18:18 --> Controller Class Initialized
INFO - 2018-02-02 05:18:18 --> Model Class Initialized
DEBUG - 2018-02-02 05:18:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 05:18:18 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-02 05:18:18 --> Final output sent to browser
DEBUG - 2018-02-02 05:18:18 --> Total execution time: 0.0976
INFO - 2018-02-02 05:18:24 --> Config Class Initialized
INFO - 2018-02-02 05:18:24 --> Hooks Class Initialized
DEBUG - 2018-02-02 05:18:24 --> UTF-8 Support Enabled
INFO - 2018-02-02 05:18:24 --> Utf8 Class Initialized
INFO - 2018-02-02 05:18:24 --> URI Class Initialized
INFO - 2018-02-02 05:18:24 --> Router Class Initialized
INFO - 2018-02-02 05:18:24 --> Output Class Initialized
INFO - 2018-02-02 05:18:24 --> Security Class Initialized
DEBUG - 2018-02-02 05:18:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 05:18:24 --> Input Class Initialized
INFO - 2018-02-02 05:18:24 --> Language Class Initialized
INFO - 2018-02-02 05:18:24 --> Loader Class Initialized
INFO - 2018-02-02 05:18:24 --> Helper loaded: url_helper
INFO - 2018-02-02 05:18:24 --> Helper loaded: form_helper
INFO - 2018-02-02 05:18:24 --> Database Driver Class Initialized
DEBUG - 2018-02-02 05:18:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 05:18:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 05:18:24 --> Form Validation Class Initialized
INFO - 2018-02-02 05:18:24 --> Model Class Initialized
INFO - 2018-02-02 05:18:24 --> Controller Class Initialized
INFO - 2018-02-02 05:18:24 --> Model Class Initialized
DEBUG - 2018-02-02 05:18:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 05:18:24 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-02 05:18:24 --> Final output sent to browser
DEBUG - 2018-02-02 05:18:24 --> Total execution time: 0.1951
INFO - 2018-02-02 05:18:28 --> Config Class Initialized
INFO - 2018-02-02 05:18:28 --> Hooks Class Initialized
DEBUG - 2018-02-02 05:18:28 --> UTF-8 Support Enabled
INFO - 2018-02-02 05:18:28 --> Utf8 Class Initialized
INFO - 2018-02-02 05:18:28 --> URI Class Initialized
INFO - 2018-02-02 05:18:28 --> Router Class Initialized
INFO - 2018-02-02 05:18:28 --> Output Class Initialized
INFO - 2018-02-02 05:18:28 --> Security Class Initialized
DEBUG - 2018-02-02 05:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 05:18:28 --> Input Class Initialized
INFO - 2018-02-02 05:18:28 --> Language Class Initialized
INFO - 2018-02-02 05:18:28 --> Loader Class Initialized
INFO - 2018-02-02 05:18:28 --> Helper loaded: url_helper
INFO - 2018-02-02 05:18:28 --> Helper loaded: form_helper
INFO - 2018-02-02 05:18:28 --> Database Driver Class Initialized
DEBUG - 2018-02-02 05:18:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 05:18:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 05:18:28 --> Form Validation Class Initialized
INFO - 2018-02-02 05:18:28 --> Model Class Initialized
INFO - 2018-02-02 05:18:28 --> Controller Class Initialized
INFO - 2018-02-02 05:18:28 --> Model Class Initialized
DEBUG - 2018-02-02 05:18:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 05:18:28 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-02 05:18:28 --> Final output sent to browser
DEBUG - 2018-02-02 05:18:28 --> Total execution time: 0.0424
INFO - 2018-02-02 05:18:28 --> Config Class Initialized
INFO - 2018-02-02 05:18:28 --> Hooks Class Initialized
DEBUG - 2018-02-02 05:18:28 --> UTF-8 Support Enabled
INFO - 2018-02-02 05:18:28 --> Utf8 Class Initialized
INFO - 2018-02-02 05:18:28 --> URI Class Initialized
INFO - 2018-02-02 05:18:28 --> Router Class Initialized
INFO - 2018-02-02 05:18:28 --> Output Class Initialized
INFO - 2018-02-02 05:18:28 --> Security Class Initialized
DEBUG - 2018-02-02 05:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 05:18:28 --> Input Class Initialized
INFO - 2018-02-02 05:18:28 --> Language Class Initialized
INFO - 2018-02-02 05:18:28 --> Loader Class Initialized
INFO - 2018-02-02 05:18:28 --> Helper loaded: url_helper
INFO - 2018-02-02 05:18:28 --> Helper loaded: form_helper
INFO - 2018-02-02 05:18:28 --> Database Driver Class Initialized
DEBUG - 2018-02-02 05:18:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 05:18:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 05:18:28 --> Form Validation Class Initialized
INFO - 2018-02-02 05:18:28 --> Model Class Initialized
INFO - 2018-02-02 05:18:28 --> Controller Class Initialized
INFO - 2018-02-02 05:18:28 --> Model Class Initialized
DEBUG - 2018-02-02 05:18:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 05:18:34 --> Config Class Initialized
INFO - 2018-02-02 05:18:34 --> Hooks Class Initialized
DEBUG - 2018-02-02 05:18:34 --> UTF-8 Support Enabled
INFO - 2018-02-02 05:18:34 --> Utf8 Class Initialized
INFO - 2018-02-02 05:18:34 --> URI Class Initialized
INFO - 2018-02-02 05:18:34 --> Router Class Initialized
INFO - 2018-02-02 05:18:34 --> Output Class Initialized
INFO - 2018-02-02 05:18:34 --> Security Class Initialized
DEBUG - 2018-02-02 05:18:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 05:18:34 --> Input Class Initialized
INFO - 2018-02-02 05:18:34 --> Language Class Initialized
INFO - 2018-02-02 05:18:34 --> Loader Class Initialized
INFO - 2018-02-02 05:18:34 --> Helper loaded: url_helper
INFO - 2018-02-02 05:18:34 --> Helper loaded: form_helper
INFO - 2018-02-02 05:18:34 --> Database Driver Class Initialized
DEBUG - 2018-02-02 05:18:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 05:18:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 05:18:34 --> Form Validation Class Initialized
INFO - 2018-02-02 05:18:34 --> Model Class Initialized
INFO - 2018-02-02 05:18:34 --> Controller Class Initialized
INFO - 2018-02-02 05:18:34 --> Model Class Initialized
DEBUG - 2018-02-02 05:18:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 05:18:34 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-02 05:18:34 --> Final output sent to browser
DEBUG - 2018-02-02 05:18:34 --> Total execution time: 0.0445
INFO - 2018-02-02 05:18:42 --> Config Class Initialized
INFO - 2018-02-02 05:18:42 --> Hooks Class Initialized
DEBUG - 2018-02-02 05:18:42 --> UTF-8 Support Enabled
INFO - 2018-02-02 05:18:42 --> Utf8 Class Initialized
INFO - 2018-02-02 05:18:42 --> URI Class Initialized
INFO - 2018-02-02 05:18:42 --> Router Class Initialized
INFO - 2018-02-02 05:18:42 --> Output Class Initialized
INFO - 2018-02-02 05:18:42 --> Security Class Initialized
DEBUG - 2018-02-02 05:18:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 05:18:42 --> Input Class Initialized
INFO - 2018-02-02 05:18:42 --> Language Class Initialized
INFO - 2018-02-02 05:18:42 --> Loader Class Initialized
INFO - 2018-02-02 05:18:42 --> Helper loaded: url_helper
INFO - 2018-02-02 05:18:42 --> Helper loaded: form_helper
INFO - 2018-02-02 05:18:42 --> Database Driver Class Initialized
DEBUG - 2018-02-02 05:18:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 05:18:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 05:18:42 --> Form Validation Class Initialized
INFO - 2018-02-02 05:18:42 --> Model Class Initialized
INFO - 2018-02-02 05:18:42 --> Controller Class Initialized
INFO - 2018-02-02 05:18:42 --> Model Class Initialized
DEBUG - 2018-02-02 05:18:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 05:18:42 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-02 05:18:42 --> Final output sent to browser
DEBUG - 2018-02-02 05:18:42 --> Total execution time: 0.2061
INFO - 2018-02-02 05:18:45 --> Config Class Initialized
INFO - 2018-02-02 05:18:45 --> Hooks Class Initialized
DEBUG - 2018-02-02 05:18:45 --> UTF-8 Support Enabled
INFO - 2018-02-02 05:18:45 --> Utf8 Class Initialized
INFO - 2018-02-02 05:18:45 --> URI Class Initialized
INFO - 2018-02-02 05:18:45 --> Router Class Initialized
INFO - 2018-02-02 05:18:45 --> Output Class Initialized
INFO - 2018-02-02 05:18:45 --> Security Class Initialized
DEBUG - 2018-02-02 05:18:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 05:18:45 --> Input Class Initialized
INFO - 2018-02-02 05:18:45 --> Language Class Initialized
INFO - 2018-02-02 05:18:45 --> Loader Class Initialized
INFO - 2018-02-02 05:18:45 --> Helper loaded: url_helper
INFO - 2018-02-02 05:18:45 --> Helper loaded: form_helper
INFO - 2018-02-02 05:18:45 --> Database Driver Class Initialized
DEBUG - 2018-02-02 05:18:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 05:18:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 05:18:45 --> Form Validation Class Initialized
INFO - 2018-02-02 05:18:45 --> Model Class Initialized
INFO - 2018-02-02 05:18:45 --> Controller Class Initialized
INFO - 2018-02-02 05:18:45 --> Model Class Initialized
DEBUG - 2018-02-02 05:18:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 05:18:46 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-02 05:18:46 --> Final output sent to browser
DEBUG - 2018-02-02 05:18:46 --> Total execution time: 0.0382
INFO - 2018-02-02 05:18:46 --> Config Class Initialized
INFO - 2018-02-02 05:18:46 --> Hooks Class Initialized
DEBUG - 2018-02-02 05:18:46 --> UTF-8 Support Enabled
INFO - 2018-02-02 05:18:46 --> Utf8 Class Initialized
INFO - 2018-02-02 05:18:46 --> URI Class Initialized
INFO - 2018-02-02 05:18:46 --> Router Class Initialized
INFO - 2018-02-02 05:18:46 --> Output Class Initialized
INFO - 2018-02-02 05:18:46 --> Security Class Initialized
DEBUG - 2018-02-02 05:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 05:18:46 --> Input Class Initialized
INFO - 2018-02-02 05:18:46 --> Language Class Initialized
INFO - 2018-02-02 05:18:46 --> Loader Class Initialized
INFO - 2018-02-02 05:18:46 --> Helper loaded: url_helper
INFO - 2018-02-02 05:18:46 --> Helper loaded: form_helper
INFO - 2018-02-02 05:18:46 --> Database Driver Class Initialized
DEBUG - 2018-02-02 05:18:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 05:18:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 05:18:46 --> Form Validation Class Initialized
INFO - 2018-02-02 05:18:46 --> Model Class Initialized
INFO - 2018-02-02 05:18:46 --> Controller Class Initialized
INFO - 2018-02-02 05:18:46 --> Model Class Initialized
DEBUG - 2018-02-02 05:18:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 05:18:49 --> Config Class Initialized
INFO - 2018-02-02 05:18:49 --> Hooks Class Initialized
DEBUG - 2018-02-02 05:18:49 --> UTF-8 Support Enabled
INFO - 2018-02-02 05:18:49 --> Utf8 Class Initialized
INFO - 2018-02-02 05:18:49 --> URI Class Initialized
INFO - 2018-02-02 05:18:49 --> Router Class Initialized
INFO - 2018-02-02 05:18:49 --> Output Class Initialized
INFO - 2018-02-02 05:18:49 --> Security Class Initialized
DEBUG - 2018-02-02 05:18:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 05:18:49 --> Input Class Initialized
INFO - 2018-02-02 05:18:49 --> Language Class Initialized
INFO - 2018-02-02 05:18:49 --> Loader Class Initialized
INFO - 2018-02-02 05:18:49 --> Helper loaded: url_helper
INFO - 2018-02-02 05:18:49 --> Helper loaded: form_helper
INFO - 2018-02-02 05:18:49 --> Database Driver Class Initialized
DEBUG - 2018-02-02 05:18:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 05:18:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 05:18:49 --> Form Validation Class Initialized
INFO - 2018-02-02 05:18:49 --> Model Class Initialized
INFO - 2018-02-02 05:18:49 --> Controller Class Initialized
INFO - 2018-02-02 05:18:49 --> Model Class Initialized
DEBUG - 2018-02-02 05:18:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 05:18:49 --> Config Class Initialized
INFO - 2018-02-02 05:18:49 --> Hooks Class Initialized
DEBUG - 2018-02-02 05:18:49 --> UTF-8 Support Enabled
INFO - 2018-02-02 05:18:49 --> Utf8 Class Initialized
INFO - 2018-02-02 05:18:49 --> URI Class Initialized
INFO - 2018-02-02 05:18:49 --> Router Class Initialized
INFO - 2018-02-02 05:18:49 --> Output Class Initialized
INFO - 2018-02-02 05:18:49 --> Security Class Initialized
DEBUG - 2018-02-02 05:18:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 05:18:49 --> Input Class Initialized
INFO - 2018-02-02 05:18:49 --> Language Class Initialized
INFO - 2018-02-02 05:18:49 --> Loader Class Initialized
INFO - 2018-02-02 05:18:49 --> Helper loaded: url_helper
INFO - 2018-02-02 05:18:49 --> Helper loaded: form_helper
INFO - 2018-02-02 05:18:49 --> Database Driver Class Initialized
DEBUG - 2018-02-02 05:18:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 05:18:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 05:18:49 --> Form Validation Class Initialized
INFO - 2018-02-02 05:18:49 --> Model Class Initialized
INFO - 2018-02-02 05:18:49 --> Controller Class Initialized
INFO - 2018-02-02 05:18:49 --> Model Class Initialized
DEBUG - 2018-02-02 05:18:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 05:18:49 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-02 05:18:49 --> Final output sent to browser
DEBUG - 2018-02-02 05:18:49 --> Total execution time: 0.0446
INFO - 2018-02-02 05:18:54 --> Config Class Initialized
INFO - 2018-02-02 05:18:54 --> Hooks Class Initialized
DEBUG - 2018-02-02 05:18:54 --> UTF-8 Support Enabled
INFO - 2018-02-02 05:18:54 --> Utf8 Class Initialized
INFO - 2018-02-02 05:18:54 --> URI Class Initialized
INFO - 2018-02-02 05:18:54 --> Router Class Initialized
INFO - 2018-02-02 05:18:54 --> Output Class Initialized
INFO - 2018-02-02 05:18:54 --> Security Class Initialized
DEBUG - 2018-02-02 05:18:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 05:18:54 --> Input Class Initialized
INFO - 2018-02-02 05:18:54 --> Language Class Initialized
INFO - 2018-02-02 05:18:54 --> Loader Class Initialized
INFO - 2018-02-02 05:18:54 --> Helper loaded: url_helper
INFO - 2018-02-02 05:18:54 --> Helper loaded: form_helper
INFO - 2018-02-02 05:18:54 --> Database Driver Class Initialized
DEBUG - 2018-02-02 05:18:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 05:18:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 05:18:54 --> Form Validation Class Initialized
INFO - 2018-02-02 05:18:54 --> Model Class Initialized
INFO - 2018-02-02 05:18:54 --> Controller Class Initialized
INFO - 2018-02-02 05:18:54 --> Model Class Initialized
DEBUG - 2018-02-02 05:18:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 05:18:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-02 05:18:54 --> Config Class Initialized
INFO - 2018-02-02 05:18:54 --> Hooks Class Initialized
DEBUG - 2018-02-02 05:18:54 --> UTF-8 Support Enabled
INFO - 2018-02-02 05:18:54 --> Utf8 Class Initialized
INFO - 2018-02-02 05:18:54 --> URI Class Initialized
DEBUG - 2018-02-02 05:18:54 --> No URI present. Default controller set.
INFO - 2018-02-02 05:18:54 --> Router Class Initialized
INFO - 2018-02-02 05:18:54 --> Output Class Initialized
INFO - 2018-02-02 05:18:54 --> Security Class Initialized
DEBUG - 2018-02-02 05:18:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 05:18:54 --> Input Class Initialized
INFO - 2018-02-02 05:18:54 --> Language Class Initialized
INFO - 2018-02-02 05:18:54 --> Loader Class Initialized
INFO - 2018-02-02 05:18:54 --> Helper loaded: url_helper
INFO - 2018-02-02 05:18:54 --> Helper loaded: form_helper
INFO - 2018-02-02 05:18:54 --> Database Driver Class Initialized
DEBUG - 2018-02-02 05:18:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 05:18:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 05:18:54 --> Form Validation Class Initialized
INFO - 2018-02-02 05:18:54 --> Model Class Initialized
INFO - 2018-02-02 05:18:54 --> Controller Class Initialized
INFO - 2018-02-02 05:18:54 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-02 05:18:54 --> Final output sent to browser
DEBUG - 2018-02-02 05:18:54 --> Total execution time: 0.0393
INFO - 2018-02-02 05:18:54 --> Config Class Initialized
INFO - 2018-02-02 05:18:54 --> Hooks Class Initialized
DEBUG - 2018-02-02 05:18:54 --> UTF-8 Support Enabled
INFO - 2018-02-02 05:18:54 --> Utf8 Class Initialized
INFO - 2018-02-02 05:18:54 --> URI Class Initialized
INFO - 2018-02-02 05:18:54 --> Router Class Initialized
INFO - 2018-02-02 05:18:54 --> Output Class Initialized
INFO - 2018-02-02 05:18:54 --> Security Class Initialized
DEBUG - 2018-02-02 05:18:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 05:18:54 --> Input Class Initialized
INFO - 2018-02-02 05:18:54 --> Language Class Initialized
INFO - 2018-02-02 05:18:54 --> Loader Class Initialized
INFO - 2018-02-02 05:18:54 --> Helper loaded: url_helper
INFO - 2018-02-02 05:18:54 --> Helper loaded: form_helper
INFO - 2018-02-02 05:18:54 --> Database Driver Class Initialized
DEBUG - 2018-02-02 05:18:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 05:18:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 05:18:54 --> Form Validation Class Initialized
INFO - 2018-02-02 05:18:54 --> Model Class Initialized
INFO - 2018-02-02 05:18:54 --> Controller Class Initialized
INFO - 2018-02-02 05:18:54 --> Model Class Initialized
INFO - 2018-02-02 05:18:54 --> Model Class Initialized
INFO - 2018-02-02 05:18:54 --> Model Class Initialized
INFO - 2018-02-02 05:18:54 --> Model Class Initialized
DEBUG - 2018-02-02 05:18:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 06:28:12 --> Config Class Initialized
INFO - 2018-02-02 06:28:12 --> Hooks Class Initialized
DEBUG - 2018-02-02 06:28:12 --> UTF-8 Support Enabled
INFO - 2018-02-02 06:28:12 --> Utf8 Class Initialized
INFO - 2018-02-02 06:28:12 --> URI Class Initialized
DEBUG - 2018-02-02 06:28:12 --> No URI present. Default controller set.
INFO - 2018-02-02 06:28:12 --> Router Class Initialized
INFO - 2018-02-02 06:28:12 --> Output Class Initialized
INFO - 2018-02-02 06:28:12 --> Security Class Initialized
DEBUG - 2018-02-02 06:28:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 06:28:12 --> Input Class Initialized
INFO - 2018-02-02 06:28:12 --> Language Class Initialized
INFO - 2018-02-02 06:28:12 --> Loader Class Initialized
INFO - 2018-02-02 06:28:12 --> Helper loaded: url_helper
INFO - 2018-02-02 06:28:12 --> Helper loaded: form_helper
INFO - 2018-02-02 06:28:12 --> Database Driver Class Initialized
DEBUG - 2018-02-02 06:28:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 06:28:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 06:28:12 --> Form Validation Class Initialized
INFO - 2018-02-02 06:28:12 --> Model Class Initialized
INFO - 2018-02-02 06:28:12 --> Controller Class Initialized
ERROR - 2018-02-02 06:28:12 --> Severity: Notice --> Undefined variable: rol_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_general.php 71
INFO - 2018-02-02 06:28:12 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-02 06:28:12 --> Final output sent to browser
DEBUG - 2018-02-02 06:28:12 --> Total execution time: 0.0580
INFO - 2018-02-02 06:28:14 --> Config Class Initialized
INFO - 2018-02-02 06:28:14 --> Hooks Class Initialized
DEBUG - 2018-02-02 06:28:14 --> UTF-8 Support Enabled
INFO - 2018-02-02 06:28:14 --> Utf8 Class Initialized
INFO - 2018-02-02 06:28:14 --> URI Class Initialized
INFO - 2018-02-02 06:28:14 --> Router Class Initialized
INFO - 2018-02-02 06:28:14 --> Output Class Initialized
INFO - 2018-02-02 06:28:14 --> Security Class Initialized
DEBUG - 2018-02-02 06:28:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 06:28:14 --> Input Class Initialized
INFO - 2018-02-02 06:28:14 --> Language Class Initialized
INFO - 2018-02-02 06:28:14 --> Loader Class Initialized
INFO - 2018-02-02 06:28:14 --> Helper loaded: url_helper
INFO - 2018-02-02 06:28:14 --> Helper loaded: form_helper
INFO - 2018-02-02 06:28:14 --> Database Driver Class Initialized
DEBUG - 2018-02-02 06:28:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 06:28:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 06:28:14 --> Form Validation Class Initialized
INFO - 2018-02-02 06:28:14 --> Model Class Initialized
INFO - 2018-02-02 06:28:14 --> Controller Class Initialized
INFO - 2018-02-02 06:28:14 --> Model Class Initialized
INFO - 2018-02-02 06:28:14 --> Model Class Initialized
INFO - 2018-02-02 06:28:14 --> Model Class Initialized
INFO - 2018-02-02 06:28:14 --> Model Class Initialized
DEBUG - 2018-02-02 06:28:14 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-02 06:28:14 --> Severity: Notice --> Undefined variable: rol_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_general.php 71
INFO - 2018-02-02 06:28:38 --> Config Class Initialized
INFO - 2018-02-02 06:28:38 --> Hooks Class Initialized
DEBUG - 2018-02-02 06:28:38 --> UTF-8 Support Enabled
INFO - 2018-02-02 06:28:38 --> Utf8 Class Initialized
INFO - 2018-02-02 06:28:38 --> URI Class Initialized
DEBUG - 2018-02-02 06:28:38 --> No URI present. Default controller set.
INFO - 2018-02-02 06:28:38 --> Router Class Initialized
INFO - 2018-02-02 06:28:38 --> Output Class Initialized
INFO - 2018-02-02 06:28:38 --> Security Class Initialized
DEBUG - 2018-02-02 06:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 06:28:38 --> Input Class Initialized
INFO - 2018-02-02 06:28:38 --> Language Class Initialized
INFO - 2018-02-02 06:28:38 --> Loader Class Initialized
INFO - 2018-02-02 06:28:38 --> Helper loaded: url_helper
INFO - 2018-02-02 06:28:38 --> Helper loaded: form_helper
INFO - 2018-02-02 06:28:38 --> Database Driver Class Initialized
DEBUG - 2018-02-02 06:28:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 06:28:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 06:28:38 --> Form Validation Class Initialized
INFO - 2018-02-02 06:28:38 --> Model Class Initialized
INFO - 2018-02-02 06:28:38 --> Controller Class Initialized
ERROR - 2018-02-02 06:28:38 --> Severity: Notice --> Undefined variable: rol_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_general.php 71
INFO - 2018-02-02 06:28:38 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-02 06:28:38 --> Final output sent to browser
DEBUG - 2018-02-02 06:28:38 --> Total execution time: 0.0662
INFO - 2018-02-02 06:28:38 --> Config Class Initialized
INFO - 2018-02-02 06:28:38 --> Hooks Class Initialized
DEBUG - 2018-02-02 06:28:38 --> UTF-8 Support Enabled
INFO - 2018-02-02 06:28:38 --> Utf8 Class Initialized
INFO - 2018-02-02 06:28:38 --> URI Class Initialized
INFO - 2018-02-02 06:28:38 --> Router Class Initialized
INFO - 2018-02-02 06:28:38 --> Output Class Initialized
INFO - 2018-02-02 06:28:38 --> Security Class Initialized
DEBUG - 2018-02-02 06:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 06:28:38 --> Input Class Initialized
INFO - 2018-02-02 06:28:38 --> Language Class Initialized
INFO - 2018-02-02 06:28:38 --> Loader Class Initialized
INFO - 2018-02-02 06:28:38 --> Helper loaded: url_helper
INFO - 2018-02-02 06:28:38 --> Helper loaded: form_helper
INFO - 2018-02-02 06:28:38 --> Database Driver Class Initialized
DEBUG - 2018-02-02 06:28:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 06:28:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 06:28:38 --> Form Validation Class Initialized
INFO - 2018-02-02 06:28:38 --> Model Class Initialized
INFO - 2018-02-02 06:28:38 --> Controller Class Initialized
INFO - 2018-02-02 06:28:38 --> Model Class Initialized
INFO - 2018-02-02 06:28:38 --> Model Class Initialized
INFO - 2018-02-02 06:28:38 --> Model Class Initialized
INFO - 2018-02-02 06:28:38 --> Model Class Initialized
DEBUG - 2018-02-02 06:28:38 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-02-02 06:28:38 --> Severity: Notice --> Undefined variable: rol_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_general.php 71
INFO - 2018-02-02 06:28:51 --> Config Class Initialized
INFO - 2018-02-02 06:28:51 --> Hooks Class Initialized
DEBUG - 2018-02-02 06:28:51 --> UTF-8 Support Enabled
INFO - 2018-02-02 06:28:51 --> Utf8 Class Initialized
INFO - 2018-02-02 06:28:51 --> URI Class Initialized
DEBUG - 2018-02-02 06:28:51 --> No URI present. Default controller set.
INFO - 2018-02-02 06:28:51 --> Router Class Initialized
INFO - 2018-02-02 06:28:51 --> Output Class Initialized
INFO - 2018-02-02 06:28:51 --> Security Class Initialized
DEBUG - 2018-02-02 06:28:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 06:28:51 --> Input Class Initialized
INFO - 2018-02-02 06:28:51 --> Language Class Initialized
INFO - 2018-02-02 06:28:51 --> Loader Class Initialized
INFO - 2018-02-02 06:28:51 --> Helper loaded: url_helper
INFO - 2018-02-02 06:28:51 --> Helper loaded: form_helper
INFO - 2018-02-02 06:28:51 --> Database Driver Class Initialized
DEBUG - 2018-02-02 06:28:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 06:28:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 06:28:51 --> Form Validation Class Initialized
INFO - 2018-02-02 06:28:51 --> Model Class Initialized
INFO - 2018-02-02 06:28:51 --> Controller Class Initialized
INFO - 2018-02-02 06:28:51 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-02 06:28:51 --> Final output sent to browser
DEBUG - 2018-02-02 06:28:51 --> Total execution time: 0.0503
INFO - 2018-02-02 06:28:51 --> Config Class Initialized
INFO - 2018-02-02 06:28:51 --> Hooks Class Initialized
DEBUG - 2018-02-02 06:28:51 --> UTF-8 Support Enabled
INFO - 2018-02-02 06:28:51 --> Utf8 Class Initialized
INFO - 2018-02-02 06:28:51 --> URI Class Initialized
INFO - 2018-02-02 06:28:51 --> Router Class Initialized
INFO - 2018-02-02 06:28:51 --> Output Class Initialized
INFO - 2018-02-02 06:28:51 --> Security Class Initialized
DEBUG - 2018-02-02 06:28:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 06:28:51 --> Input Class Initialized
INFO - 2018-02-02 06:28:51 --> Language Class Initialized
INFO - 2018-02-02 06:28:51 --> Loader Class Initialized
INFO - 2018-02-02 06:28:51 --> Helper loaded: url_helper
INFO - 2018-02-02 06:28:51 --> Helper loaded: form_helper
INFO - 2018-02-02 06:28:51 --> Database Driver Class Initialized
DEBUG - 2018-02-02 06:28:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 06:28:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 06:28:51 --> Form Validation Class Initialized
INFO - 2018-02-02 06:28:51 --> Model Class Initialized
INFO - 2018-02-02 06:28:51 --> Controller Class Initialized
INFO - 2018-02-02 06:28:51 --> Model Class Initialized
INFO - 2018-02-02 06:28:51 --> Model Class Initialized
INFO - 2018-02-02 06:28:51 --> Model Class Initialized
INFO - 2018-02-02 06:28:51 --> Model Class Initialized
DEBUG - 2018-02-02 06:28:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 06:28:54 --> Config Class Initialized
INFO - 2018-02-02 06:28:54 --> Hooks Class Initialized
DEBUG - 2018-02-02 06:28:54 --> UTF-8 Support Enabled
INFO - 2018-02-02 06:28:54 --> Utf8 Class Initialized
INFO - 2018-02-02 06:28:54 --> URI Class Initialized
DEBUG - 2018-02-02 06:28:54 --> No URI present. Default controller set.
INFO - 2018-02-02 06:28:54 --> Router Class Initialized
INFO - 2018-02-02 06:28:54 --> Output Class Initialized
INFO - 2018-02-02 06:28:54 --> Security Class Initialized
DEBUG - 2018-02-02 06:28:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 06:28:54 --> Input Class Initialized
INFO - 2018-02-02 06:28:54 --> Language Class Initialized
INFO - 2018-02-02 06:28:54 --> Loader Class Initialized
INFO - 2018-02-02 06:28:54 --> Helper loaded: url_helper
INFO - 2018-02-02 06:28:54 --> Helper loaded: form_helper
INFO - 2018-02-02 06:28:54 --> Database Driver Class Initialized
DEBUG - 2018-02-02 06:28:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 06:28:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 06:28:54 --> Form Validation Class Initialized
INFO - 2018-02-02 06:28:54 --> Model Class Initialized
INFO - 2018-02-02 06:28:54 --> Controller Class Initialized
INFO - 2018-02-02 06:28:54 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-02 06:28:54 --> Final output sent to browser
DEBUG - 2018-02-02 06:28:54 --> Total execution time: 0.0421
INFO - 2018-02-02 06:28:54 --> Config Class Initialized
INFO - 2018-02-02 06:28:54 --> Hooks Class Initialized
DEBUG - 2018-02-02 06:28:54 --> UTF-8 Support Enabled
INFO - 2018-02-02 06:28:54 --> Utf8 Class Initialized
INFO - 2018-02-02 06:28:54 --> URI Class Initialized
INFO - 2018-02-02 06:28:54 --> Router Class Initialized
INFO - 2018-02-02 06:28:54 --> Output Class Initialized
INFO - 2018-02-02 06:28:54 --> Security Class Initialized
DEBUG - 2018-02-02 06:28:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 06:28:54 --> Input Class Initialized
INFO - 2018-02-02 06:28:54 --> Language Class Initialized
INFO - 2018-02-02 06:28:54 --> Loader Class Initialized
INFO - 2018-02-02 06:28:54 --> Helper loaded: url_helper
INFO - 2018-02-02 06:28:54 --> Helper loaded: form_helper
INFO - 2018-02-02 06:28:54 --> Database Driver Class Initialized
DEBUG - 2018-02-02 06:28:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 06:28:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 06:28:54 --> Form Validation Class Initialized
INFO - 2018-02-02 06:28:54 --> Model Class Initialized
INFO - 2018-02-02 06:28:54 --> Controller Class Initialized
INFO - 2018-02-02 06:28:54 --> Model Class Initialized
INFO - 2018-02-02 06:28:54 --> Model Class Initialized
INFO - 2018-02-02 06:28:54 --> Model Class Initialized
INFO - 2018-02-02 06:28:54 --> Model Class Initialized
DEBUG - 2018-02-02 06:28:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 06:28:54 --> Config Class Initialized
INFO - 2018-02-02 06:28:54 --> Hooks Class Initialized
DEBUG - 2018-02-02 06:28:54 --> UTF-8 Support Enabled
INFO - 2018-02-02 06:28:54 --> Utf8 Class Initialized
INFO - 2018-02-02 06:28:54 --> URI Class Initialized
DEBUG - 2018-02-02 06:28:54 --> No URI present. Default controller set.
INFO - 2018-02-02 06:28:54 --> Router Class Initialized
INFO - 2018-02-02 06:28:54 --> Output Class Initialized
INFO - 2018-02-02 06:28:54 --> Security Class Initialized
DEBUG - 2018-02-02 06:28:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 06:28:54 --> Input Class Initialized
INFO - 2018-02-02 06:28:54 --> Language Class Initialized
INFO - 2018-02-02 06:28:54 --> Loader Class Initialized
INFO - 2018-02-02 06:28:54 --> Helper loaded: url_helper
INFO - 2018-02-02 06:28:54 --> Helper loaded: form_helper
INFO - 2018-02-02 06:28:54 --> Database Driver Class Initialized
DEBUG - 2018-02-02 06:28:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 06:28:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 06:28:54 --> Form Validation Class Initialized
INFO - 2018-02-02 06:28:54 --> Model Class Initialized
INFO - 2018-02-02 06:28:54 --> Controller Class Initialized
INFO - 2018-02-02 06:28:54 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-02 06:28:54 --> Final output sent to browser
DEBUG - 2018-02-02 06:28:54 --> Total execution time: 0.0495
INFO - 2018-02-02 06:28:54 --> Config Class Initialized
INFO - 2018-02-02 06:28:54 --> Hooks Class Initialized
DEBUG - 2018-02-02 06:28:54 --> UTF-8 Support Enabled
INFO - 2018-02-02 06:28:54 --> Utf8 Class Initialized
INFO - 2018-02-02 06:28:54 --> URI Class Initialized
INFO - 2018-02-02 06:28:54 --> Router Class Initialized
INFO - 2018-02-02 06:28:54 --> Output Class Initialized
INFO - 2018-02-02 06:28:54 --> Security Class Initialized
DEBUG - 2018-02-02 06:28:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 06:28:54 --> Input Class Initialized
INFO - 2018-02-02 06:28:54 --> Language Class Initialized
INFO - 2018-02-02 06:28:54 --> Loader Class Initialized
INFO - 2018-02-02 06:28:54 --> Helper loaded: url_helper
INFO - 2018-02-02 06:28:54 --> Helper loaded: form_helper
INFO - 2018-02-02 06:28:54 --> Database Driver Class Initialized
DEBUG - 2018-02-02 06:28:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 06:28:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 06:28:54 --> Form Validation Class Initialized
INFO - 2018-02-02 06:28:54 --> Model Class Initialized
INFO - 2018-02-02 06:28:54 --> Controller Class Initialized
INFO - 2018-02-02 06:28:54 --> Model Class Initialized
INFO - 2018-02-02 06:28:54 --> Model Class Initialized
INFO - 2018-02-02 06:28:54 --> Model Class Initialized
INFO - 2018-02-02 06:28:54 --> Model Class Initialized
DEBUG - 2018-02-02 06:28:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 06:30:19 --> Config Class Initialized
INFO - 2018-02-02 06:30:19 --> Hooks Class Initialized
DEBUG - 2018-02-02 06:30:19 --> UTF-8 Support Enabled
INFO - 2018-02-02 06:30:19 --> Utf8 Class Initialized
INFO - 2018-02-02 06:30:19 --> URI Class Initialized
DEBUG - 2018-02-02 06:30:19 --> No URI present. Default controller set.
INFO - 2018-02-02 06:30:19 --> Router Class Initialized
INFO - 2018-02-02 06:30:19 --> Output Class Initialized
INFO - 2018-02-02 06:30:19 --> Security Class Initialized
DEBUG - 2018-02-02 06:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 06:30:19 --> Input Class Initialized
INFO - 2018-02-02 06:30:19 --> Language Class Initialized
INFO - 2018-02-02 06:30:19 --> Loader Class Initialized
INFO - 2018-02-02 06:30:19 --> Helper loaded: url_helper
INFO - 2018-02-02 06:30:19 --> Helper loaded: form_helper
INFO - 2018-02-02 06:30:19 --> Database Driver Class Initialized
DEBUG - 2018-02-02 06:30:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 06:30:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 06:30:19 --> Form Validation Class Initialized
INFO - 2018-02-02 06:30:19 --> Model Class Initialized
INFO - 2018-02-02 06:30:19 --> Controller Class Initialized
INFO - 2018-02-02 06:30:20 --> Config Class Initialized
INFO - 2018-02-02 06:30:20 --> Hooks Class Initialized
DEBUG - 2018-02-02 06:30:20 --> UTF-8 Support Enabled
INFO - 2018-02-02 06:30:20 --> Utf8 Class Initialized
INFO - 2018-02-02 06:30:20 --> URI Class Initialized
DEBUG - 2018-02-02 06:30:20 --> No URI present. Default controller set.
INFO - 2018-02-02 06:30:20 --> Router Class Initialized
INFO - 2018-02-02 06:30:20 --> Output Class Initialized
INFO - 2018-02-02 06:30:20 --> Security Class Initialized
DEBUG - 2018-02-02 06:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 06:30:20 --> Input Class Initialized
INFO - 2018-02-02 06:30:20 --> Language Class Initialized
INFO - 2018-02-02 06:30:20 --> Loader Class Initialized
INFO - 2018-02-02 06:30:20 --> Helper loaded: url_helper
INFO - 2018-02-02 06:30:20 --> Helper loaded: form_helper
INFO - 2018-02-02 06:30:20 --> Database Driver Class Initialized
DEBUG - 2018-02-02 06:30:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 06:30:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 06:30:20 --> Form Validation Class Initialized
INFO - 2018-02-02 06:30:20 --> Model Class Initialized
INFO - 2018-02-02 06:30:20 --> Controller Class Initialized
INFO - 2018-02-02 06:30:54 --> Config Class Initialized
INFO - 2018-02-02 06:30:54 --> Hooks Class Initialized
DEBUG - 2018-02-02 06:30:54 --> UTF-8 Support Enabled
INFO - 2018-02-02 06:30:54 --> Utf8 Class Initialized
INFO - 2018-02-02 06:30:54 --> URI Class Initialized
DEBUG - 2018-02-02 06:30:54 --> No URI present. Default controller set.
INFO - 2018-02-02 06:30:54 --> Router Class Initialized
INFO - 2018-02-02 06:30:54 --> Output Class Initialized
INFO - 2018-02-02 06:30:54 --> Security Class Initialized
DEBUG - 2018-02-02 06:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 06:30:54 --> Input Class Initialized
INFO - 2018-02-02 06:30:54 --> Language Class Initialized
INFO - 2018-02-02 06:30:54 --> Loader Class Initialized
INFO - 2018-02-02 06:30:54 --> Helper loaded: url_helper
INFO - 2018-02-02 06:30:54 --> Helper loaded: form_helper
INFO - 2018-02-02 06:30:54 --> Database Driver Class Initialized
DEBUG - 2018-02-02 06:30:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 06:30:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 06:30:54 --> Form Validation Class Initialized
INFO - 2018-02-02 06:30:54 --> Model Class Initialized
INFO - 2018-02-02 06:30:54 --> Controller Class Initialized
INFO - 2018-02-02 06:31:03 --> Config Class Initialized
INFO - 2018-02-02 06:31:03 --> Hooks Class Initialized
DEBUG - 2018-02-02 06:31:03 --> UTF-8 Support Enabled
INFO - 2018-02-02 06:31:03 --> Utf8 Class Initialized
INFO - 2018-02-02 06:31:03 --> URI Class Initialized
DEBUG - 2018-02-02 06:31:03 --> No URI present. Default controller set.
INFO - 2018-02-02 06:31:03 --> Router Class Initialized
INFO - 2018-02-02 06:31:03 --> Output Class Initialized
INFO - 2018-02-02 06:31:03 --> Security Class Initialized
DEBUG - 2018-02-02 06:31:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 06:31:03 --> Input Class Initialized
INFO - 2018-02-02 06:31:03 --> Language Class Initialized
INFO - 2018-02-02 06:31:03 --> Loader Class Initialized
INFO - 2018-02-02 06:31:03 --> Helper loaded: url_helper
INFO - 2018-02-02 06:31:03 --> Helper loaded: form_helper
INFO - 2018-02-02 06:31:03 --> Database Driver Class Initialized
DEBUG - 2018-02-02 06:31:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 06:31:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 06:31:03 --> Form Validation Class Initialized
INFO - 2018-02-02 06:31:03 --> Model Class Initialized
INFO - 2018-02-02 06:31:03 --> Controller Class Initialized
INFO - 2018-02-02 06:31:03 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-02 06:31:03 --> Final output sent to browser
DEBUG - 2018-02-02 06:31:03 --> Total execution time: 0.0468
INFO - 2018-02-02 06:31:04 --> Config Class Initialized
INFO - 2018-02-02 06:31:04 --> Hooks Class Initialized
DEBUG - 2018-02-02 06:31:04 --> UTF-8 Support Enabled
INFO - 2018-02-02 06:31:04 --> Utf8 Class Initialized
INFO - 2018-02-02 06:31:04 --> URI Class Initialized
INFO - 2018-02-02 06:31:04 --> Router Class Initialized
INFO - 2018-02-02 06:31:04 --> Output Class Initialized
INFO - 2018-02-02 06:31:04 --> Security Class Initialized
DEBUG - 2018-02-02 06:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 06:31:04 --> Input Class Initialized
INFO - 2018-02-02 06:31:04 --> Language Class Initialized
INFO - 2018-02-02 06:31:04 --> Loader Class Initialized
INFO - 2018-02-02 06:31:04 --> Helper loaded: url_helper
INFO - 2018-02-02 06:31:04 --> Helper loaded: form_helper
INFO - 2018-02-02 06:31:04 --> Database Driver Class Initialized
DEBUG - 2018-02-02 06:31:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 06:31:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 06:31:04 --> Form Validation Class Initialized
INFO - 2018-02-02 06:31:04 --> Model Class Initialized
INFO - 2018-02-02 06:31:04 --> Controller Class Initialized
INFO - 2018-02-02 06:31:04 --> Model Class Initialized
INFO - 2018-02-02 06:31:04 --> Model Class Initialized
INFO - 2018-02-02 06:31:04 --> Model Class Initialized
INFO - 2018-02-02 06:31:04 --> Model Class Initialized
DEBUG - 2018-02-02 06:31:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 06:31:05 --> Config Class Initialized
INFO - 2018-02-02 06:31:05 --> Hooks Class Initialized
DEBUG - 2018-02-02 06:31:05 --> UTF-8 Support Enabled
INFO - 2018-02-02 06:31:05 --> Utf8 Class Initialized
INFO - 2018-02-02 06:31:05 --> URI Class Initialized
INFO - 2018-02-02 06:31:05 --> Router Class Initialized
INFO - 2018-02-02 06:31:05 --> Output Class Initialized
INFO - 2018-02-02 06:31:05 --> Security Class Initialized
DEBUG - 2018-02-02 06:31:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 06:31:05 --> Input Class Initialized
INFO - 2018-02-02 06:31:05 --> Language Class Initialized
INFO - 2018-02-02 06:31:05 --> Loader Class Initialized
INFO - 2018-02-02 06:31:05 --> Helper loaded: url_helper
INFO - 2018-02-02 06:31:05 --> Helper loaded: form_helper
INFO - 2018-02-02 06:31:05 --> Database Driver Class Initialized
DEBUG - 2018-02-02 06:31:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 06:31:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 06:31:05 --> Form Validation Class Initialized
INFO - 2018-02-02 06:31:05 --> Model Class Initialized
INFO - 2018-02-02 06:31:05 --> Controller Class Initialized
INFO - 2018-02-02 06:31:05 --> Model Class Initialized
INFO - 2018-02-02 06:31:05 --> Model Class Initialized
INFO - 2018-02-02 06:31:05 --> Model Class Initialized
INFO - 2018-02-02 06:31:05 --> Model Class Initialized
DEBUG - 2018-02-02 06:31:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 06:31:05 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-02 06:31:05 --> Final output sent to browser
DEBUG - 2018-02-02 06:31:05 --> Total execution time: 0.1390
INFO - 2018-02-02 06:31:06 --> Config Class Initialized
INFO - 2018-02-02 06:31:06 --> Hooks Class Initialized
DEBUG - 2018-02-02 06:31:06 --> UTF-8 Support Enabled
INFO - 2018-02-02 06:31:06 --> Utf8 Class Initialized
INFO - 2018-02-02 06:31:06 --> URI Class Initialized
INFO - 2018-02-02 06:31:06 --> Router Class Initialized
INFO - 2018-02-02 06:31:06 --> Output Class Initialized
INFO - 2018-02-02 06:31:06 --> Security Class Initialized
DEBUG - 2018-02-02 06:31:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 06:31:06 --> Input Class Initialized
INFO - 2018-02-02 06:31:06 --> Language Class Initialized
INFO - 2018-02-02 06:31:06 --> Loader Class Initialized
INFO - 2018-02-02 06:31:06 --> Helper loaded: url_helper
INFO - 2018-02-02 06:31:06 --> Helper loaded: form_helper
INFO - 2018-02-02 06:31:06 --> Database Driver Class Initialized
DEBUG - 2018-02-02 06:31:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 06:31:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 06:31:06 --> Form Validation Class Initialized
INFO - 2018-02-02 06:31:06 --> Model Class Initialized
INFO - 2018-02-02 06:31:06 --> Controller Class Initialized
INFO - 2018-02-02 06:31:06 --> Model Class Initialized
INFO - 2018-02-02 06:31:06 --> Model Class Initialized
DEBUG - 2018-02-02 06:31:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 06:31:06 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-02 06:31:06 --> Final output sent to browser
DEBUG - 2018-02-02 06:31:06 --> Total execution time: 0.0749
INFO - 2018-02-02 06:31:06 --> Config Class Initialized
INFO - 2018-02-02 06:31:06 --> Hooks Class Initialized
DEBUG - 2018-02-02 06:31:06 --> UTF-8 Support Enabled
INFO - 2018-02-02 06:31:06 --> Utf8 Class Initialized
INFO - 2018-02-02 06:31:06 --> URI Class Initialized
INFO - 2018-02-02 06:31:06 --> Router Class Initialized
INFO - 2018-02-02 06:31:06 --> Output Class Initialized
INFO - 2018-02-02 06:31:06 --> Security Class Initialized
DEBUG - 2018-02-02 06:31:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 06:31:06 --> Input Class Initialized
INFO - 2018-02-02 06:31:06 --> Language Class Initialized
INFO - 2018-02-02 06:31:06 --> Loader Class Initialized
INFO - 2018-02-02 06:31:06 --> Helper loaded: url_helper
INFO - 2018-02-02 06:31:06 --> Helper loaded: form_helper
INFO - 2018-02-02 06:31:06 --> Database Driver Class Initialized
DEBUG - 2018-02-02 06:31:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 06:31:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 06:31:06 --> Form Validation Class Initialized
INFO - 2018-02-02 06:31:06 --> Model Class Initialized
INFO - 2018-02-02 06:31:06 --> Controller Class Initialized
INFO - 2018-02-02 06:31:06 --> Model Class Initialized
INFO - 2018-02-02 06:31:06 --> Model Class Initialized
DEBUG - 2018-02-02 06:31:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 06:31:07 --> Config Class Initialized
INFO - 2018-02-02 06:31:07 --> Hooks Class Initialized
DEBUG - 2018-02-02 06:31:07 --> UTF-8 Support Enabled
INFO - 2018-02-02 06:31:07 --> Utf8 Class Initialized
INFO - 2018-02-02 06:31:07 --> URI Class Initialized
INFO - 2018-02-02 06:31:07 --> Router Class Initialized
INFO - 2018-02-02 06:31:07 --> Output Class Initialized
INFO - 2018-02-02 06:31:07 --> Security Class Initialized
DEBUG - 2018-02-02 06:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 06:31:07 --> Input Class Initialized
INFO - 2018-02-02 06:31:07 --> Language Class Initialized
INFO - 2018-02-02 06:31:07 --> Loader Class Initialized
INFO - 2018-02-02 06:31:07 --> Helper loaded: url_helper
INFO - 2018-02-02 06:31:07 --> Helper loaded: form_helper
INFO - 2018-02-02 06:31:07 --> Database Driver Class Initialized
DEBUG - 2018-02-02 06:31:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 06:31:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 06:31:07 --> Form Validation Class Initialized
INFO - 2018-02-02 06:31:07 --> Model Class Initialized
INFO - 2018-02-02 06:31:07 --> Controller Class Initialized
INFO - 2018-02-02 06:31:07 --> Model Class Initialized
INFO - 2018-02-02 06:31:07 --> Model Class Initialized
DEBUG - 2018-02-02 06:31:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 06:31:07 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-02 06:31:07 --> Final output sent to browser
DEBUG - 2018-02-02 06:31:07 --> Total execution time: 0.1035
INFO - 2018-02-02 06:31:07 --> Config Class Initialized
INFO - 2018-02-02 06:31:07 --> Hooks Class Initialized
DEBUG - 2018-02-02 06:31:07 --> UTF-8 Support Enabled
INFO - 2018-02-02 06:31:07 --> Utf8 Class Initialized
INFO - 2018-02-02 06:31:07 --> URI Class Initialized
INFO - 2018-02-02 06:31:07 --> Router Class Initialized
INFO - 2018-02-02 06:31:07 --> Output Class Initialized
INFO - 2018-02-02 06:31:07 --> Security Class Initialized
DEBUG - 2018-02-02 06:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 06:31:07 --> Input Class Initialized
INFO - 2018-02-02 06:31:07 --> Language Class Initialized
INFO - 2018-02-02 06:31:07 --> Loader Class Initialized
INFO - 2018-02-02 06:31:07 --> Helper loaded: url_helper
INFO - 2018-02-02 06:31:07 --> Helper loaded: form_helper
INFO - 2018-02-02 06:31:07 --> Database Driver Class Initialized
DEBUG - 2018-02-02 06:31:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 06:31:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 06:31:07 --> Form Validation Class Initialized
INFO - 2018-02-02 06:31:07 --> Model Class Initialized
INFO - 2018-02-02 06:31:07 --> Controller Class Initialized
INFO - 2018-02-02 06:31:07 --> Model Class Initialized
INFO - 2018-02-02 06:31:07 --> Model Class Initialized
DEBUG - 2018-02-02 06:31:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 06:31:08 --> Config Class Initialized
INFO - 2018-02-02 06:31:08 --> Hooks Class Initialized
DEBUG - 2018-02-02 06:31:08 --> UTF-8 Support Enabled
INFO - 2018-02-02 06:31:08 --> Utf8 Class Initialized
INFO - 2018-02-02 06:31:08 --> URI Class Initialized
INFO - 2018-02-02 06:31:08 --> Router Class Initialized
INFO - 2018-02-02 06:31:08 --> Output Class Initialized
INFO - 2018-02-02 06:31:08 --> Security Class Initialized
DEBUG - 2018-02-02 06:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 06:31:08 --> Input Class Initialized
INFO - 2018-02-02 06:31:08 --> Language Class Initialized
INFO - 2018-02-02 06:31:08 --> Loader Class Initialized
INFO - 2018-02-02 06:31:08 --> Helper loaded: url_helper
INFO - 2018-02-02 06:31:08 --> Helper loaded: form_helper
INFO - 2018-02-02 06:31:08 --> Database Driver Class Initialized
DEBUG - 2018-02-02 06:31:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 06:31:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 06:31:08 --> Form Validation Class Initialized
INFO - 2018-02-02 06:31:08 --> Model Class Initialized
INFO - 2018-02-02 06:31:08 --> Controller Class Initialized
INFO - 2018-02-02 06:31:08 --> Model Class Initialized
INFO - 2018-02-02 06:31:08 --> Model Class Initialized
INFO - 2018-02-02 06:31:08 --> Model Class Initialized
INFO - 2018-02-02 06:31:08 --> Model Class Initialized
DEBUG - 2018-02-02 06:31:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 06:31:08 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-02 06:31:08 --> Final output sent to browser
DEBUG - 2018-02-02 06:31:08 --> Total execution time: 0.0775
INFO - 2018-02-02 06:31:08 --> Config Class Initialized
INFO - 2018-02-02 06:31:08 --> Hooks Class Initialized
DEBUG - 2018-02-02 06:31:08 --> UTF-8 Support Enabled
INFO - 2018-02-02 06:31:08 --> Utf8 Class Initialized
INFO - 2018-02-02 06:31:08 --> URI Class Initialized
INFO - 2018-02-02 06:31:08 --> Router Class Initialized
INFO - 2018-02-02 06:31:08 --> Output Class Initialized
INFO - 2018-02-02 06:31:08 --> Security Class Initialized
DEBUG - 2018-02-02 06:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 06:31:08 --> Input Class Initialized
INFO - 2018-02-02 06:31:08 --> Language Class Initialized
INFO - 2018-02-02 06:31:08 --> Loader Class Initialized
INFO - 2018-02-02 06:31:08 --> Helper loaded: url_helper
INFO - 2018-02-02 06:31:08 --> Helper loaded: form_helper
INFO - 2018-02-02 06:31:08 --> Database Driver Class Initialized
DEBUG - 2018-02-02 06:31:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 06:31:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 06:31:08 --> Form Validation Class Initialized
INFO - 2018-02-02 06:31:08 --> Model Class Initialized
INFO - 2018-02-02 06:31:08 --> Controller Class Initialized
INFO - 2018-02-02 06:31:08 --> Model Class Initialized
INFO - 2018-02-02 06:31:08 --> Model Class Initialized
INFO - 2018-02-02 06:31:08 --> Model Class Initialized
INFO - 2018-02-02 06:31:08 --> Model Class Initialized
DEBUG - 2018-02-02 06:31:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 06:31:09 --> Config Class Initialized
INFO - 2018-02-02 06:31:09 --> Hooks Class Initialized
DEBUG - 2018-02-02 06:31:09 --> UTF-8 Support Enabled
INFO - 2018-02-02 06:31:09 --> Utf8 Class Initialized
INFO - 2018-02-02 06:31:09 --> URI Class Initialized
DEBUG - 2018-02-02 06:31:09 --> No URI present. Default controller set.
INFO - 2018-02-02 06:31:09 --> Router Class Initialized
INFO - 2018-02-02 06:31:09 --> Output Class Initialized
INFO - 2018-02-02 06:31:09 --> Security Class Initialized
DEBUG - 2018-02-02 06:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 06:31:09 --> Input Class Initialized
INFO - 2018-02-02 06:31:09 --> Language Class Initialized
INFO - 2018-02-02 06:31:09 --> Loader Class Initialized
INFO - 2018-02-02 06:31:09 --> Helper loaded: url_helper
INFO - 2018-02-02 06:31:09 --> Helper loaded: form_helper
INFO - 2018-02-02 06:31:09 --> Database Driver Class Initialized
DEBUG - 2018-02-02 06:31:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 06:31:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 06:31:09 --> Form Validation Class Initialized
INFO - 2018-02-02 06:31:09 --> Model Class Initialized
INFO - 2018-02-02 06:31:09 --> Controller Class Initialized
INFO - 2018-02-02 06:31:09 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-02 06:31:09 --> Final output sent to browser
DEBUG - 2018-02-02 06:31:09 --> Total execution time: 0.0349
INFO - 2018-02-02 06:31:09 --> Config Class Initialized
INFO - 2018-02-02 06:31:09 --> Hooks Class Initialized
DEBUG - 2018-02-02 06:31:09 --> UTF-8 Support Enabled
INFO - 2018-02-02 06:31:09 --> Utf8 Class Initialized
INFO - 2018-02-02 06:31:09 --> URI Class Initialized
INFO - 2018-02-02 06:31:09 --> Router Class Initialized
INFO - 2018-02-02 06:31:09 --> Output Class Initialized
INFO - 2018-02-02 06:31:09 --> Security Class Initialized
DEBUG - 2018-02-02 06:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 06:31:09 --> Input Class Initialized
INFO - 2018-02-02 06:31:09 --> Language Class Initialized
INFO - 2018-02-02 06:31:09 --> Loader Class Initialized
INFO - 2018-02-02 06:31:09 --> Helper loaded: url_helper
INFO - 2018-02-02 06:31:09 --> Helper loaded: form_helper
INFO - 2018-02-02 06:31:09 --> Database Driver Class Initialized
DEBUG - 2018-02-02 06:31:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 06:31:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 06:31:09 --> Form Validation Class Initialized
INFO - 2018-02-02 06:31:09 --> Model Class Initialized
INFO - 2018-02-02 06:31:09 --> Controller Class Initialized
INFO - 2018-02-02 06:31:09 --> Model Class Initialized
INFO - 2018-02-02 06:31:09 --> Model Class Initialized
INFO - 2018-02-02 06:31:09 --> Model Class Initialized
INFO - 2018-02-02 06:31:09 --> Model Class Initialized
DEBUG - 2018-02-02 06:31:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 06:31:10 --> Config Class Initialized
INFO - 2018-02-02 06:31:10 --> Hooks Class Initialized
DEBUG - 2018-02-02 06:31:10 --> UTF-8 Support Enabled
INFO - 2018-02-02 06:31:10 --> Utf8 Class Initialized
INFO - 2018-02-02 06:31:10 --> URI Class Initialized
INFO - 2018-02-02 06:31:10 --> Router Class Initialized
INFO - 2018-02-02 06:31:10 --> Output Class Initialized
INFO - 2018-02-02 06:31:10 --> Security Class Initialized
DEBUG - 2018-02-02 06:31:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 06:31:10 --> Input Class Initialized
INFO - 2018-02-02 06:31:10 --> Language Class Initialized
INFO - 2018-02-02 06:31:10 --> Loader Class Initialized
INFO - 2018-02-02 06:31:10 --> Helper loaded: url_helper
INFO - 2018-02-02 06:31:10 --> Helper loaded: form_helper
INFO - 2018-02-02 06:31:10 --> Database Driver Class Initialized
DEBUG - 2018-02-02 06:31:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 06:31:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 06:31:10 --> Form Validation Class Initialized
INFO - 2018-02-02 06:31:10 --> Model Class Initialized
INFO - 2018-02-02 06:31:10 --> Controller Class Initialized
INFO - 2018-02-02 06:31:10 --> Model Class Initialized
INFO - 2018-02-02 06:31:10 --> Model Class Initialized
INFO - 2018-02-02 06:31:10 --> Model Class Initialized
INFO - 2018-02-02 06:31:10 --> Model Class Initialized
DEBUG - 2018-02-02 06:31:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 06:31:10 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-02 06:31:10 --> Final output sent to browser
DEBUG - 2018-02-02 06:31:10 --> Total execution time: 0.0523
INFO - 2018-02-02 06:31:10 --> Config Class Initialized
INFO - 2018-02-02 06:31:10 --> Hooks Class Initialized
DEBUG - 2018-02-02 06:31:10 --> UTF-8 Support Enabled
INFO - 2018-02-02 06:31:10 --> Utf8 Class Initialized
INFO - 2018-02-02 06:31:10 --> URI Class Initialized
INFO - 2018-02-02 06:31:10 --> Router Class Initialized
INFO - 2018-02-02 06:31:10 --> Output Class Initialized
INFO - 2018-02-02 06:31:10 --> Security Class Initialized
DEBUG - 2018-02-02 06:31:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 06:31:10 --> Input Class Initialized
INFO - 2018-02-02 06:31:10 --> Language Class Initialized
INFO - 2018-02-02 06:31:10 --> Loader Class Initialized
INFO - 2018-02-02 06:31:10 --> Helper loaded: url_helper
INFO - 2018-02-02 06:31:10 --> Helper loaded: form_helper
INFO - 2018-02-02 06:31:10 --> Database Driver Class Initialized
DEBUG - 2018-02-02 06:31:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 06:31:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 06:31:10 --> Form Validation Class Initialized
INFO - 2018-02-02 06:31:10 --> Model Class Initialized
INFO - 2018-02-02 06:31:10 --> Controller Class Initialized
INFO - 2018-02-02 06:31:10 --> Model Class Initialized
INFO - 2018-02-02 06:31:10 --> Model Class Initialized
INFO - 2018-02-02 06:31:10 --> Model Class Initialized
INFO - 2018-02-02 06:31:10 --> Model Class Initialized
DEBUG - 2018-02-02 06:31:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 06:31:12 --> Config Class Initialized
INFO - 2018-02-02 06:31:12 --> Hooks Class Initialized
DEBUG - 2018-02-02 06:31:12 --> UTF-8 Support Enabled
INFO - 2018-02-02 06:31:12 --> Utf8 Class Initialized
INFO - 2018-02-02 06:31:12 --> URI Class Initialized
DEBUG - 2018-02-02 06:31:12 --> No URI present. Default controller set.
INFO - 2018-02-02 06:31:12 --> Router Class Initialized
INFO - 2018-02-02 06:31:12 --> Output Class Initialized
INFO - 2018-02-02 06:31:12 --> Security Class Initialized
DEBUG - 2018-02-02 06:31:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 06:31:12 --> Input Class Initialized
INFO - 2018-02-02 06:31:12 --> Language Class Initialized
INFO - 2018-02-02 06:31:12 --> Loader Class Initialized
INFO - 2018-02-02 06:31:12 --> Helper loaded: url_helper
INFO - 2018-02-02 06:31:12 --> Helper loaded: form_helper
INFO - 2018-02-02 06:31:12 --> Database Driver Class Initialized
DEBUG - 2018-02-02 06:31:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 06:31:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 06:31:12 --> Form Validation Class Initialized
INFO - 2018-02-02 06:31:12 --> Model Class Initialized
INFO - 2018-02-02 06:31:12 --> Controller Class Initialized
INFO - 2018-02-02 06:31:12 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-02 06:31:12 --> Final output sent to browser
DEBUG - 2018-02-02 06:31:12 --> Total execution time: 0.0446
INFO - 2018-02-02 06:31:12 --> Config Class Initialized
INFO - 2018-02-02 06:31:12 --> Hooks Class Initialized
DEBUG - 2018-02-02 06:31:12 --> UTF-8 Support Enabled
INFO - 2018-02-02 06:31:12 --> Utf8 Class Initialized
INFO - 2018-02-02 06:31:12 --> URI Class Initialized
INFO - 2018-02-02 06:31:12 --> Router Class Initialized
INFO - 2018-02-02 06:31:12 --> Output Class Initialized
INFO - 2018-02-02 06:31:12 --> Security Class Initialized
DEBUG - 2018-02-02 06:31:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 06:31:12 --> Input Class Initialized
INFO - 2018-02-02 06:31:12 --> Language Class Initialized
INFO - 2018-02-02 06:31:12 --> Loader Class Initialized
INFO - 2018-02-02 06:31:12 --> Helper loaded: url_helper
INFO - 2018-02-02 06:31:12 --> Helper loaded: form_helper
INFO - 2018-02-02 06:31:12 --> Database Driver Class Initialized
DEBUG - 2018-02-02 06:31:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 06:31:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 06:31:12 --> Form Validation Class Initialized
INFO - 2018-02-02 06:31:12 --> Model Class Initialized
INFO - 2018-02-02 06:31:12 --> Controller Class Initialized
INFO - 2018-02-02 06:31:12 --> Model Class Initialized
INFO - 2018-02-02 06:31:12 --> Model Class Initialized
INFO - 2018-02-02 06:31:12 --> Model Class Initialized
INFO - 2018-02-02 06:31:12 --> Model Class Initialized
DEBUG - 2018-02-02 06:31:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 06:34:53 --> Config Class Initialized
INFO - 2018-02-02 06:34:53 --> Hooks Class Initialized
DEBUG - 2018-02-02 06:34:53 --> UTF-8 Support Enabled
INFO - 2018-02-02 06:34:53 --> Utf8 Class Initialized
INFO - 2018-02-02 06:34:53 --> URI Class Initialized
DEBUG - 2018-02-02 06:34:53 --> No URI present. Default controller set.
INFO - 2018-02-02 06:34:53 --> Router Class Initialized
INFO - 2018-02-02 06:34:53 --> Output Class Initialized
INFO - 2018-02-02 06:34:53 --> Security Class Initialized
DEBUG - 2018-02-02 06:34:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 06:34:53 --> Input Class Initialized
INFO - 2018-02-02 06:34:53 --> Language Class Initialized
INFO - 2018-02-02 06:34:53 --> Loader Class Initialized
INFO - 2018-02-02 06:34:53 --> Helper loaded: url_helper
INFO - 2018-02-02 06:34:53 --> Helper loaded: form_helper
INFO - 2018-02-02 06:34:53 --> Database Driver Class Initialized
DEBUG - 2018-02-02 06:34:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 06:34:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 06:34:53 --> Form Validation Class Initialized
INFO - 2018-02-02 06:34:53 --> Model Class Initialized
INFO - 2018-02-02 06:34:53 --> Controller Class Initialized
INFO - 2018-02-02 06:34:53 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-02 06:34:53 --> Final output sent to browser
DEBUG - 2018-02-02 06:34:53 --> Total execution time: 0.0365
INFO - 2018-02-02 06:34:53 --> Config Class Initialized
INFO - 2018-02-02 06:34:53 --> Hooks Class Initialized
DEBUG - 2018-02-02 06:34:53 --> UTF-8 Support Enabled
INFO - 2018-02-02 06:34:53 --> Utf8 Class Initialized
INFO - 2018-02-02 06:34:53 --> URI Class Initialized
INFO - 2018-02-02 06:34:53 --> Router Class Initialized
INFO - 2018-02-02 06:34:53 --> Output Class Initialized
INFO - 2018-02-02 06:34:53 --> Security Class Initialized
DEBUG - 2018-02-02 06:34:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 06:34:53 --> Input Class Initialized
INFO - 2018-02-02 06:34:53 --> Language Class Initialized
INFO - 2018-02-02 06:34:53 --> Loader Class Initialized
INFO - 2018-02-02 06:34:53 --> Helper loaded: url_helper
INFO - 2018-02-02 06:34:53 --> Helper loaded: form_helper
INFO - 2018-02-02 06:34:53 --> Database Driver Class Initialized
DEBUG - 2018-02-02 06:34:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 06:34:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 06:34:53 --> Form Validation Class Initialized
INFO - 2018-02-02 06:34:53 --> Model Class Initialized
INFO - 2018-02-02 06:34:53 --> Controller Class Initialized
INFO - 2018-02-02 06:34:53 --> Model Class Initialized
INFO - 2018-02-02 06:34:53 --> Model Class Initialized
INFO - 2018-02-02 06:34:53 --> Model Class Initialized
INFO - 2018-02-02 06:34:53 --> Model Class Initialized
DEBUG - 2018-02-02 06:34:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 06:34:54 --> Config Class Initialized
INFO - 2018-02-02 06:34:54 --> Hooks Class Initialized
DEBUG - 2018-02-02 06:34:54 --> UTF-8 Support Enabled
INFO - 2018-02-02 06:34:54 --> Utf8 Class Initialized
INFO - 2018-02-02 06:34:54 --> URI Class Initialized
DEBUG - 2018-02-02 06:34:54 --> No URI present. Default controller set.
INFO - 2018-02-02 06:34:54 --> Router Class Initialized
INFO - 2018-02-02 06:34:54 --> Output Class Initialized
INFO - 2018-02-02 06:34:54 --> Security Class Initialized
DEBUG - 2018-02-02 06:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 06:34:54 --> Input Class Initialized
INFO - 2018-02-02 06:34:54 --> Language Class Initialized
INFO - 2018-02-02 06:34:54 --> Loader Class Initialized
INFO - 2018-02-02 06:34:54 --> Helper loaded: url_helper
INFO - 2018-02-02 06:34:54 --> Helper loaded: form_helper
INFO - 2018-02-02 06:34:54 --> Database Driver Class Initialized
DEBUG - 2018-02-02 06:34:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 06:34:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 06:34:54 --> Form Validation Class Initialized
INFO - 2018-02-02 06:34:54 --> Model Class Initialized
INFO - 2018-02-02 06:34:54 --> Controller Class Initialized
INFO - 2018-02-02 06:34:54 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-02 06:34:54 --> Final output sent to browser
DEBUG - 2018-02-02 06:34:54 --> Total execution time: 0.0414
INFO - 2018-02-02 06:34:54 --> Config Class Initialized
INFO - 2018-02-02 06:34:54 --> Hooks Class Initialized
DEBUG - 2018-02-02 06:34:54 --> UTF-8 Support Enabled
INFO - 2018-02-02 06:34:54 --> Utf8 Class Initialized
INFO - 2018-02-02 06:34:54 --> URI Class Initialized
INFO - 2018-02-02 06:34:54 --> Router Class Initialized
INFO - 2018-02-02 06:34:54 --> Output Class Initialized
INFO - 2018-02-02 06:34:54 --> Security Class Initialized
DEBUG - 2018-02-02 06:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 06:34:54 --> Input Class Initialized
INFO - 2018-02-02 06:34:54 --> Language Class Initialized
INFO - 2018-02-02 06:34:54 --> Loader Class Initialized
INFO - 2018-02-02 06:34:54 --> Helper loaded: url_helper
INFO - 2018-02-02 06:34:54 --> Helper loaded: form_helper
INFO - 2018-02-02 06:34:54 --> Database Driver Class Initialized
DEBUG - 2018-02-02 06:34:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 06:34:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 06:34:54 --> Form Validation Class Initialized
INFO - 2018-02-02 06:34:54 --> Model Class Initialized
INFO - 2018-02-02 06:34:54 --> Controller Class Initialized
INFO - 2018-02-02 06:34:54 --> Model Class Initialized
INFO - 2018-02-02 06:34:54 --> Model Class Initialized
INFO - 2018-02-02 06:34:54 --> Model Class Initialized
INFO - 2018-02-02 06:34:54 --> Model Class Initialized
DEBUG - 2018-02-02 06:34:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 06:34:58 --> Config Class Initialized
INFO - 2018-02-02 06:34:58 --> Hooks Class Initialized
DEBUG - 2018-02-02 06:34:58 --> UTF-8 Support Enabled
INFO - 2018-02-02 06:34:58 --> Utf8 Class Initialized
INFO - 2018-02-02 06:34:58 --> URI Class Initialized
INFO - 2018-02-02 06:34:58 --> Router Class Initialized
INFO - 2018-02-02 06:34:58 --> Output Class Initialized
INFO - 2018-02-02 06:34:58 --> Security Class Initialized
DEBUG - 2018-02-02 06:34:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 06:34:58 --> Input Class Initialized
INFO - 2018-02-02 06:34:58 --> Language Class Initialized
INFO - 2018-02-02 06:34:58 --> Loader Class Initialized
INFO - 2018-02-02 06:34:58 --> Helper loaded: url_helper
INFO - 2018-02-02 06:34:58 --> Helper loaded: form_helper
INFO - 2018-02-02 06:34:58 --> Database Driver Class Initialized
DEBUG - 2018-02-02 06:34:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 06:34:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 06:34:58 --> Form Validation Class Initialized
INFO - 2018-02-02 06:34:58 --> Model Class Initialized
INFO - 2018-02-02 06:34:58 --> Controller Class Initialized
INFO - 2018-02-02 06:34:58 --> Model Class Initialized
INFO - 2018-02-02 06:34:58 --> Model Class Initialized
DEBUG - 2018-02-02 06:34:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 06:34:58 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-02 06:34:58 --> Final output sent to browser
DEBUG - 2018-02-02 06:34:58 --> Total execution time: 0.0365
INFO - 2018-02-02 06:34:58 --> Config Class Initialized
INFO - 2018-02-02 06:34:58 --> Hooks Class Initialized
DEBUG - 2018-02-02 06:34:58 --> UTF-8 Support Enabled
INFO - 2018-02-02 06:34:58 --> Utf8 Class Initialized
INFO - 2018-02-02 06:34:58 --> URI Class Initialized
INFO - 2018-02-02 06:34:58 --> Router Class Initialized
INFO - 2018-02-02 06:34:58 --> Output Class Initialized
INFO - 2018-02-02 06:34:58 --> Security Class Initialized
DEBUG - 2018-02-02 06:34:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 06:34:58 --> Input Class Initialized
INFO - 2018-02-02 06:34:58 --> Language Class Initialized
INFO - 2018-02-02 06:34:58 --> Loader Class Initialized
INFO - 2018-02-02 06:34:58 --> Helper loaded: url_helper
INFO - 2018-02-02 06:34:58 --> Helper loaded: form_helper
INFO - 2018-02-02 06:34:58 --> Database Driver Class Initialized
DEBUG - 2018-02-02 06:34:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 06:34:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 06:34:58 --> Form Validation Class Initialized
INFO - 2018-02-02 06:34:58 --> Model Class Initialized
INFO - 2018-02-02 06:34:58 --> Controller Class Initialized
INFO - 2018-02-02 06:34:58 --> Model Class Initialized
INFO - 2018-02-02 06:34:58 --> Model Class Initialized
DEBUG - 2018-02-02 06:34:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 06:34:59 --> Config Class Initialized
INFO - 2018-02-02 06:34:59 --> Hooks Class Initialized
DEBUG - 2018-02-02 06:34:59 --> UTF-8 Support Enabled
INFO - 2018-02-02 06:34:59 --> Utf8 Class Initialized
INFO - 2018-02-02 06:34:59 --> URI Class Initialized
INFO - 2018-02-02 06:34:59 --> Router Class Initialized
INFO - 2018-02-02 06:34:59 --> Output Class Initialized
INFO - 2018-02-02 06:34:59 --> Security Class Initialized
DEBUG - 2018-02-02 06:34:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 06:34:59 --> Input Class Initialized
INFO - 2018-02-02 06:34:59 --> Language Class Initialized
INFO - 2018-02-02 06:34:59 --> Loader Class Initialized
INFO - 2018-02-02 06:34:59 --> Helper loaded: url_helper
INFO - 2018-02-02 06:34:59 --> Helper loaded: form_helper
INFO - 2018-02-02 06:34:59 --> Database Driver Class Initialized
DEBUG - 2018-02-02 06:34:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 06:34:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 06:34:59 --> Form Validation Class Initialized
INFO - 2018-02-02 06:34:59 --> Model Class Initialized
INFO - 2018-02-02 06:34:59 --> Controller Class Initialized
INFO - 2018-02-02 06:34:59 --> Model Class Initialized
INFO - 2018-02-02 06:34:59 --> Model Class Initialized
INFO - 2018-02-02 06:34:59 --> Model Class Initialized
INFO - 2018-02-02 06:34:59 --> Model Class Initialized
DEBUG - 2018-02-02 06:34:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 06:34:59 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-02 06:34:59 --> Final output sent to browser
DEBUG - 2018-02-02 06:34:59 --> Total execution time: 0.0422
INFO - 2018-02-02 06:34:59 --> Config Class Initialized
INFO - 2018-02-02 06:34:59 --> Hooks Class Initialized
DEBUG - 2018-02-02 06:34:59 --> UTF-8 Support Enabled
INFO - 2018-02-02 06:34:59 --> Utf8 Class Initialized
INFO - 2018-02-02 06:35:00 --> URI Class Initialized
INFO - 2018-02-02 06:35:00 --> Router Class Initialized
INFO - 2018-02-02 06:35:00 --> Output Class Initialized
INFO - 2018-02-02 06:35:00 --> Security Class Initialized
DEBUG - 2018-02-02 06:35:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 06:35:00 --> Input Class Initialized
INFO - 2018-02-02 06:35:00 --> Language Class Initialized
INFO - 2018-02-02 06:35:00 --> Loader Class Initialized
INFO - 2018-02-02 06:35:00 --> Helper loaded: url_helper
INFO - 2018-02-02 06:35:00 --> Helper loaded: form_helper
INFO - 2018-02-02 06:35:00 --> Database Driver Class Initialized
DEBUG - 2018-02-02 06:35:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 06:35:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 06:35:00 --> Form Validation Class Initialized
INFO - 2018-02-02 06:35:00 --> Model Class Initialized
INFO - 2018-02-02 06:35:00 --> Controller Class Initialized
INFO - 2018-02-02 06:35:00 --> Model Class Initialized
INFO - 2018-02-02 06:35:00 --> Model Class Initialized
INFO - 2018-02-02 06:35:00 --> Model Class Initialized
INFO - 2018-02-02 06:35:00 --> Model Class Initialized
DEBUG - 2018-02-02 06:35:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 06:35:00 --> Config Class Initialized
INFO - 2018-02-02 06:35:00 --> Hooks Class Initialized
DEBUG - 2018-02-02 06:35:00 --> UTF-8 Support Enabled
INFO - 2018-02-02 06:35:00 --> Utf8 Class Initialized
INFO - 2018-02-02 06:35:00 --> URI Class Initialized
INFO - 2018-02-02 06:35:00 --> Router Class Initialized
INFO - 2018-02-02 06:35:00 --> Output Class Initialized
INFO - 2018-02-02 06:35:00 --> Security Class Initialized
DEBUG - 2018-02-02 06:35:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 06:35:00 --> Input Class Initialized
INFO - 2018-02-02 06:35:00 --> Language Class Initialized
INFO - 2018-02-02 06:35:00 --> Loader Class Initialized
INFO - 2018-02-02 06:35:00 --> Helper loaded: url_helper
INFO - 2018-02-02 06:35:00 --> Helper loaded: form_helper
INFO - 2018-02-02 06:35:00 --> Database Driver Class Initialized
DEBUG - 2018-02-02 06:35:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 06:35:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 06:35:00 --> Form Validation Class Initialized
INFO - 2018-02-02 06:35:00 --> Model Class Initialized
INFO - 2018-02-02 06:35:00 --> Controller Class Initialized
INFO - 2018-02-02 06:35:00 --> Model Class Initialized
INFO - 2018-02-02 06:35:00 --> Model Class Initialized
DEBUG - 2018-02-02 06:35:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 06:35:00 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-02 06:35:00 --> Final output sent to browser
DEBUG - 2018-02-02 06:35:00 --> Total execution time: 0.0364
INFO - 2018-02-02 06:35:00 --> Config Class Initialized
INFO - 2018-02-02 06:35:00 --> Hooks Class Initialized
DEBUG - 2018-02-02 06:35:00 --> UTF-8 Support Enabled
INFO - 2018-02-02 06:35:00 --> Utf8 Class Initialized
INFO - 2018-02-02 06:35:00 --> URI Class Initialized
INFO - 2018-02-02 06:35:00 --> Router Class Initialized
INFO - 2018-02-02 06:35:00 --> Output Class Initialized
INFO - 2018-02-02 06:35:00 --> Security Class Initialized
DEBUG - 2018-02-02 06:35:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 06:35:00 --> Input Class Initialized
INFO - 2018-02-02 06:35:00 --> Language Class Initialized
INFO - 2018-02-02 06:35:00 --> Loader Class Initialized
INFO - 2018-02-02 06:35:00 --> Helper loaded: url_helper
INFO - 2018-02-02 06:35:00 --> Helper loaded: form_helper
INFO - 2018-02-02 06:35:00 --> Database Driver Class Initialized
DEBUG - 2018-02-02 06:35:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 06:35:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 06:35:00 --> Form Validation Class Initialized
INFO - 2018-02-02 06:35:00 --> Model Class Initialized
INFO - 2018-02-02 06:35:00 --> Controller Class Initialized
INFO - 2018-02-02 06:35:00 --> Model Class Initialized
INFO - 2018-02-02 06:35:00 --> Model Class Initialized
DEBUG - 2018-02-02 06:35:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 06:35:01 --> Config Class Initialized
INFO - 2018-02-02 06:35:01 --> Hooks Class Initialized
DEBUG - 2018-02-02 06:35:01 --> UTF-8 Support Enabled
INFO - 2018-02-02 06:35:01 --> Utf8 Class Initialized
INFO - 2018-02-02 06:35:01 --> URI Class Initialized
INFO - 2018-02-02 06:35:01 --> Router Class Initialized
INFO - 2018-02-02 06:35:01 --> Output Class Initialized
INFO - 2018-02-02 06:35:01 --> Security Class Initialized
DEBUG - 2018-02-02 06:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 06:35:01 --> Input Class Initialized
INFO - 2018-02-02 06:35:01 --> Language Class Initialized
INFO - 2018-02-02 06:35:01 --> Loader Class Initialized
INFO - 2018-02-02 06:35:01 --> Helper loaded: url_helper
INFO - 2018-02-02 06:35:01 --> Helper loaded: form_helper
INFO - 2018-02-02 06:35:01 --> Database Driver Class Initialized
DEBUG - 2018-02-02 06:35:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 06:35:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 06:35:01 --> Form Validation Class Initialized
INFO - 2018-02-02 06:35:01 --> Model Class Initialized
INFO - 2018-02-02 06:35:01 --> Controller Class Initialized
INFO - 2018-02-02 06:35:01 --> Model Class Initialized
INFO - 2018-02-02 06:35:01 --> Model Class Initialized
INFO - 2018-02-02 06:35:01 --> Model Class Initialized
INFO - 2018-02-02 06:35:01 --> Model Class Initialized
DEBUG - 2018-02-02 06:35:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 06:35:01 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-02 06:35:01 --> Final output sent to browser
DEBUG - 2018-02-02 06:35:01 --> Total execution time: 0.0413
INFO - 2018-02-02 06:35:01 --> Config Class Initialized
INFO - 2018-02-02 06:35:01 --> Hooks Class Initialized
DEBUG - 2018-02-02 06:35:01 --> UTF-8 Support Enabled
INFO - 2018-02-02 06:35:01 --> Utf8 Class Initialized
INFO - 2018-02-02 06:35:01 --> URI Class Initialized
INFO - 2018-02-02 06:35:01 --> Router Class Initialized
INFO - 2018-02-02 06:35:01 --> Output Class Initialized
INFO - 2018-02-02 06:35:01 --> Security Class Initialized
DEBUG - 2018-02-02 06:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 06:35:01 --> Input Class Initialized
INFO - 2018-02-02 06:35:01 --> Language Class Initialized
INFO - 2018-02-02 06:35:01 --> Loader Class Initialized
INFO - 2018-02-02 06:35:01 --> Helper loaded: url_helper
INFO - 2018-02-02 06:35:01 --> Helper loaded: form_helper
INFO - 2018-02-02 06:35:01 --> Database Driver Class Initialized
DEBUG - 2018-02-02 06:35:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 06:35:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 06:35:01 --> Form Validation Class Initialized
INFO - 2018-02-02 06:35:01 --> Model Class Initialized
INFO - 2018-02-02 06:35:01 --> Controller Class Initialized
INFO - 2018-02-02 06:35:01 --> Model Class Initialized
INFO - 2018-02-02 06:35:01 --> Model Class Initialized
INFO - 2018-02-02 06:35:01 --> Model Class Initialized
INFO - 2018-02-02 06:35:01 --> Model Class Initialized
DEBUG - 2018-02-02 06:35:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 06:35:02 --> Config Class Initialized
INFO - 2018-02-02 06:35:02 --> Hooks Class Initialized
DEBUG - 2018-02-02 06:35:02 --> UTF-8 Support Enabled
INFO - 2018-02-02 06:35:02 --> Utf8 Class Initialized
INFO - 2018-02-02 06:35:02 --> URI Class Initialized
DEBUG - 2018-02-02 06:35:02 --> No URI present. Default controller set.
INFO - 2018-02-02 06:35:02 --> Router Class Initialized
INFO - 2018-02-02 06:35:02 --> Output Class Initialized
INFO - 2018-02-02 06:35:02 --> Security Class Initialized
DEBUG - 2018-02-02 06:35:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 06:35:02 --> Input Class Initialized
INFO - 2018-02-02 06:35:02 --> Language Class Initialized
INFO - 2018-02-02 06:35:02 --> Loader Class Initialized
INFO - 2018-02-02 06:35:02 --> Helper loaded: url_helper
INFO - 2018-02-02 06:35:02 --> Helper loaded: form_helper
INFO - 2018-02-02 06:35:02 --> Database Driver Class Initialized
DEBUG - 2018-02-02 06:35:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 06:35:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 06:35:02 --> Form Validation Class Initialized
INFO - 2018-02-02 06:35:02 --> Model Class Initialized
INFO - 2018-02-02 06:35:02 --> Controller Class Initialized
INFO - 2018-02-02 06:35:02 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-02 06:35:02 --> Final output sent to browser
DEBUG - 2018-02-02 06:35:02 --> Total execution time: 0.0358
INFO - 2018-02-02 06:35:02 --> Config Class Initialized
INFO - 2018-02-02 06:35:02 --> Hooks Class Initialized
DEBUG - 2018-02-02 06:35:02 --> UTF-8 Support Enabled
INFO - 2018-02-02 06:35:02 --> Utf8 Class Initialized
INFO - 2018-02-02 06:35:02 --> URI Class Initialized
INFO - 2018-02-02 06:35:02 --> Router Class Initialized
INFO - 2018-02-02 06:35:02 --> Output Class Initialized
INFO - 2018-02-02 06:35:02 --> Security Class Initialized
DEBUG - 2018-02-02 06:35:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 06:35:02 --> Input Class Initialized
INFO - 2018-02-02 06:35:02 --> Language Class Initialized
INFO - 2018-02-02 06:35:02 --> Loader Class Initialized
INFO - 2018-02-02 06:35:02 --> Helper loaded: url_helper
INFO - 2018-02-02 06:35:02 --> Helper loaded: form_helper
INFO - 2018-02-02 06:35:02 --> Database Driver Class Initialized
DEBUG - 2018-02-02 06:35:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 06:35:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 06:35:02 --> Form Validation Class Initialized
INFO - 2018-02-02 06:35:02 --> Model Class Initialized
INFO - 2018-02-02 06:35:02 --> Controller Class Initialized
INFO - 2018-02-02 06:35:02 --> Model Class Initialized
INFO - 2018-02-02 06:35:02 --> Model Class Initialized
INFO - 2018-02-02 06:35:02 --> Model Class Initialized
INFO - 2018-02-02 06:35:02 --> Model Class Initialized
DEBUG - 2018-02-02 06:35:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 06:35:02 --> Config Class Initialized
INFO - 2018-02-02 06:35:02 --> Hooks Class Initialized
DEBUG - 2018-02-02 06:35:02 --> UTF-8 Support Enabled
INFO - 2018-02-02 06:35:02 --> Utf8 Class Initialized
INFO - 2018-02-02 06:35:02 --> URI Class Initialized
INFO - 2018-02-02 06:35:02 --> Router Class Initialized
INFO - 2018-02-02 06:35:02 --> Output Class Initialized
INFO - 2018-02-02 06:35:02 --> Security Class Initialized
DEBUG - 2018-02-02 06:35:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 06:35:02 --> Input Class Initialized
INFO - 2018-02-02 06:35:02 --> Language Class Initialized
INFO - 2018-02-02 06:35:02 --> Loader Class Initialized
INFO - 2018-02-02 06:35:02 --> Helper loaded: url_helper
INFO - 2018-02-02 06:35:02 --> Helper loaded: form_helper
INFO - 2018-02-02 06:35:02 --> Database Driver Class Initialized
DEBUG - 2018-02-02 06:35:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 06:35:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 06:35:02 --> Form Validation Class Initialized
INFO - 2018-02-02 06:35:02 --> Model Class Initialized
INFO - 2018-02-02 06:35:02 --> Controller Class Initialized
INFO - 2018-02-02 06:35:02 --> Model Class Initialized
INFO - 2018-02-02 06:35:02 --> Model Class Initialized
INFO - 2018-02-02 06:35:02 --> Model Class Initialized
INFO - 2018-02-02 06:35:02 --> Model Class Initialized
DEBUG - 2018-02-02 06:35:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 06:35:02 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-02 06:35:02 --> Final output sent to browser
DEBUG - 2018-02-02 06:35:02 --> Total execution time: 0.0495
INFO - 2018-02-02 06:35:02 --> Config Class Initialized
INFO - 2018-02-02 06:35:02 --> Hooks Class Initialized
DEBUG - 2018-02-02 06:35:02 --> UTF-8 Support Enabled
INFO - 2018-02-02 06:35:02 --> Utf8 Class Initialized
INFO - 2018-02-02 06:35:02 --> URI Class Initialized
INFO - 2018-02-02 06:35:02 --> Router Class Initialized
INFO - 2018-02-02 06:35:02 --> Output Class Initialized
INFO - 2018-02-02 06:35:02 --> Security Class Initialized
DEBUG - 2018-02-02 06:35:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 06:35:02 --> Input Class Initialized
INFO - 2018-02-02 06:35:02 --> Language Class Initialized
INFO - 2018-02-02 06:35:02 --> Loader Class Initialized
INFO - 2018-02-02 06:35:02 --> Helper loaded: url_helper
INFO - 2018-02-02 06:35:02 --> Helper loaded: form_helper
INFO - 2018-02-02 06:35:02 --> Database Driver Class Initialized
DEBUG - 2018-02-02 06:35:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 06:35:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 06:35:02 --> Form Validation Class Initialized
INFO - 2018-02-02 06:35:02 --> Model Class Initialized
INFO - 2018-02-02 06:35:02 --> Controller Class Initialized
INFO - 2018-02-02 06:35:02 --> Model Class Initialized
INFO - 2018-02-02 06:35:02 --> Model Class Initialized
INFO - 2018-02-02 06:35:02 --> Model Class Initialized
INFO - 2018-02-02 06:35:02 --> Model Class Initialized
DEBUG - 2018-02-02 06:35:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 06:35:03 --> Config Class Initialized
INFO - 2018-02-02 06:35:03 --> Hooks Class Initialized
DEBUG - 2018-02-02 06:35:03 --> UTF-8 Support Enabled
INFO - 2018-02-02 06:35:03 --> Utf8 Class Initialized
INFO - 2018-02-02 06:35:03 --> URI Class Initialized
INFO - 2018-02-02 06:35:03 --> Router Class Initialized
INFO - 2018-02-02 06:35:03 --> Output Class Initialized
INFO - 2018-02-02 06:35:03 --> Security Class Initialized
DEBUG - 2018-02-02 06:35:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 06:35:03 --> Input Class Initialized
INFO - 2018-02-02 06:35:03 --> Language Class Initialized
INFO - 2018-02-02 06:35:03 --> Loader Class Initialized
INFO - 2018-02-02 06:35:03 --> Helper loaded: url_helper
INFO - 2018-02-02 06:35:03 --> Helper loaded: form_helper
INFO - 2018-02-02 06:35:03 --> Database Driver Class Initialized
DEBUG - 2018-02-02 06:35:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 06:35:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 06:35:03 --> Form Validation Class Initialized
INFO - 2018-02-02 06:35:03 --> Model Class Initialized
INFO - 2018-02-02 06:35:03 --> Controller Class Initialized
INFO - 2018-02-02 06:35:03 --> Model Class Initialized
INFO - 2018-02-02 06:35:03 --> Model Class Initialized
DEBUG - 2018-02-02 06:35:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 06:35:03 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-02 06:35:03 --> Final output sent to browser
DEBUG - 2018-02-02 06:35:03 --> Total execution time: 0.0416
INFO - 2018-02-02 06:35:03 --> Config Class Initialized
INFO - 2018-02-02 06:35:03 --> Hooks Class Initialized
DEBUG - 2018-02-02 06:35:03 --> UTF-8 Support Enabled
INFO - 2018-02-02 06:35:03 --> Utf8 Class Initialized
INFO - 2018-02-02 06:35:03 --> URI Class Initialized
INFO - 2018-02-02 06:35:03 --> Router Class Initialized
INFO - 2018-02-02 06:35:03 --> Output Class Initialized
INFO - 2018-02-02 06:35:03 --> Security Class Initialized
DEBUG - 2018-02-02 06:35:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 06:35:03 --> Input Class Initialized
INFO - 2018-02-02 06:35:03 --> Language Class Initialized
INFO - 2018-02-02 06:35:03 --> Loader Class Initialized
INFO - 2018-02-02 06:35:03 --> Helper loaded: url_helper
INFO - 2018-02-02 06:35:03 --> Helper loaded: form_helper
INFO - 2018-02-02 06:35:03 --> Database Driver Class Initialized
DEBUG - 2018-02-02 06:35:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 06:35:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 06:35:03 --> Form Validation Class Initialized
INFO - 2018-02-02 06:35:03 --> Model Class Initialized
INFO - 2018-02-02 06:35:03 --> Controller Class Initialized
INFO - 2018-02-02 06:35:03 --> Model Class Initialized
INFO - 2018-02-02 06:35:03 --> Model Class Initialized
DEBUG - 2018-02-02 06:35:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 06:38:43 --> Config Class Initialized
INFO - 2018-02-02 06:38:43 --> Hooks Class Initialized
DEBUG - 2018-02-02 06:38:43 --> UTF-8 Support Enabled
INFO - 2018-02-02 06:38:43 --> Utf8 Class Initialized
INFO - 2018-02-02 06:38:43 --> URI Class Initialized
DEBUG - 2018-02-02 06:38:43 --> No URI present. Default controller set.
INFO - 2018-02-02 06:38:43 --> Router Class Initialized
INFO - 2018-02-02 06:38:43 --> Output Class Initialized
INFO - 2018-02-02 06:38:43 --> Security Class Initialized
DEBUG - 2018-02-02 06:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 06:38:43 --> Input Class Initialized
INFO - 2018-02-02 06:38:43 --> Language Class Initialized
INFO - 2018-02-02 06:38:43 --> Loader Class Initialized
INFO - 2018-02-02 06:38:43 --> Helper loaded: url_helper
INFO - 2018-02-02 06:38:43 --> Helper loaded: form_helper
INFO - 2018-02-02 06:38:43 --> Database Driver Class Initialized
DEBUG - 2018-02-02 06:38:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 06:38:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 06:38:43 --> Form Validation Class Initialized
INFO - 2018-02-02 06:38:43 --> Model Class Initialized
INFO - 2018-02-02 06:38:43 --> Controller Class Initialized
INFO - 2018-02-02 06:38:43 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-02 06:38:43 --> Final output sent to browser
DEBUG - 2018-02-02 06:38:43 --> Total execution time: 0.0389
INFO - 2018-02-02 06:38:43 --> Config Class Initialized
INFO - 2018-02-02 06:38:43 --> Hooks Class Initialized
DEBUG - 2018-02-02 06:38:43 --> UTF-8 Support Enabled
INFO - 2018-02-02 06:38:43 --> Utf8 Class Initialized
INFO - 2018-02-02 06:38:43 --> URI Class Initialized
INFO - 2018-02-02 06:38:43 --> Router Class Initialized
INFO - 2018-02-02 06:38:43 --> Output Class Initialized
INFO - 2018-02-02 06:38:43 --> Security Class Initialized
DEBUG - 2018-02-02 06:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 06:38:43 --> Input Class Initialized
INFO - 2018-02-02 06:38:43 --> Language Class Initialized
INFO - 2018-02-02 06:38:43 --> Loader Class Initialized
INFO - 2018-02-02 06:38:43 --> Helper loaded: url_helper
INFO - 2018-02-02 06:38:43 --> Helper loaded: form_helper
INFO - 2018-02-02 06:38:43 --> Database Driver Class Initialized
DEBUG - 2018-02-02 06:38:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 06:38:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 06:38:43 --> Form Validation Class Initialized
INFO - 2018-02-02 06:38:43 --> Model Class Initialized
INFO - 2018-02-02 06:38:43 --> Controller Class Initialized
INFO - 2018-02-02 06:38:43 --> Model Class Initialized
INFO - 2018-02-02 06:38:43 --> Model Class Initialized
INFO - 2018-02-02 06:38:43 --> Model Class Initialized
INFO - 2018-02-02 06:38:44 --> Model Class Initialized
DEBUG - 2018-02-02 06:38:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 06:38:51 --> Config Class Initialized
INFO - 2018-02-02 06:38:51 --> Hooks Class Initialized
DEBUG - 2018-02-02 06:38:51 --> UTF-8 Support Enabled
INFO - 2018-02-02 06:38:51 --> Utf8 Class Initialized
INFO - 2018-02-02 06:38:51 --> URI Class Initialized
INFO - 2018-02-02 06:38:51 --> Router Class Initialized
INFO - 2018-02-02 06:38:51 --> Output Class Initialized
INFO - 2018-02-02 06:38:51 --> Security Class Initialized
DEBUG - 2018-02-02 06:38:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 06:38:51 --> Input Class Initialized
INFO - 2018-02-02 06:38:51 --> Language Class Initialized
INFO - 2018-02-02 06:38:51 --> Loader Class Initialized
INFO - 2018-02-02 06:38:51 --> Helper loaded: url_helper
INFO - 2018-02-02 06:38:51 --> Helper loaded: form_helper
INFO - 2018-02-02 06:38:51 --> Database Driver Class Initialized
DEBUG - 2018-02-02 06:38:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 06:38:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 06:38:51 --> Form Validation Class Initialized
INFO - 2018-02-02 06:38:51 --> Model Class Initialized
INFO - 2018-02-02 06:38:51 --> Controller Class Initialized
INFO - 2018-02-02 06:38:51 --> Model Class Initialized
INFO - 2018-02-02 06:38:51 --> Model Class Initialized
INFO - 2018-02-02 06:38:51 --> Model Class Initialized
INFO - 2018-02-02 06:38:51 --> Model Class Initialized
DEBUG - 2018-02-02 06:38:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 06:38:51 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-02 06:38:51 --> Final output sent to browser
DEBUG - 2018-02-02 06:38:51 --> Total execution time: 0.0469
INFO - 2018-02-02 06:38:51 --> Config Class Initialized
INFO - 2018-02-02 06:38:51 --> Hooks Class Initialized
DEBUG - 2018-02-02 06:38:51 --> UTF-8 Support Enabled
INFO - 2018-02-02 06:38:51 --> Utf8 Class Initialized
INFO - 2018-02-02 06:38:51 --> URI Class Initialized
INFO - 2018-02-02 06:38:51 --> Router Class Initialized
INFO - 2018-02-02 06:38:51 --> Output Class Initialized
INFO - 2018-02-02 06:38:51 --> Security Class Initialized
DEBUG - 2018-02-02 06:38:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 06:38:51 --> Input Class Initialized
INFO - 2018-02-02 06:38:51 --> Language Class Initialized
INFO - 2018-02-02 06:38:51 --> Loader Class Initialized
INFO - 2018-02-02 06:38:51 --> Helper loaded: url_helper
INFO - 2018-02-02 06:38:51 --> Helper loaded: form_helper
INFO - 2018-02-02 06:38:51 --> Database Driver Class Initialized
DEBUG - 2018-02-02 06:38:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 06:38:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 06:38:51 --> Form Validation Class Initialized
INFO - 2018-02-02 06:38:51 --> Model Class Initialized
INFO - 2018-02-02 06:38:51 --> Controller Class Initialized
INFO - 2018-02-02 06:38:51 --> Model Class Initialized
INFO - 2018-02-02 06:38:51 --> Model Class Initialized
INFO - 2018-02-02 06:38:51 --> Model Class Initialized
INFO - 2018-02-02 06:38:51 --> Model Class Initialized
DEBUG - 2018-02-02 06:38:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 06:39:44 --> Config Class Initialized
INFO - 2018-02-02 06:39:44 --> Hooks Class Initialized
DEBUG - 2018-02-02 06:39:44 --> UTF-8 Support Enabled
INFO - 2018-02-02 06:39:44 --> Utf8 Class Initialized
INFO - 2018-02-02 06:39:44 --> URI Class Initialized
INFO - 2018-02-02 06:39:44 --> Router Class Initialized
INFO - 2018-02-02 06:39:44 --> Output Class Initialized
INFO - 2018-02-02 06:39:44 --> Security Class Initialized
DEBUG - 2018-02-02 06:39:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 06:39:44 --> Input Class Initialized
INFO - 2018-02-02 06:39:44 --> Language Class Initialized
INFO - 2018-02-02 06:39:44 --> Loader Class Initialized
INFO - 2018-02-02 06:39:44 --> Helper loaded: url_helper
INFO - 2018-02-02 06:39:44 --> Helper loaded: form_helper
INFO - 2018-02-02 06:39:44 --> Database Driver Class Initialized
DEBUG - 2018-02-02 06:39:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 06:39:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 06:39:44 --> Form Validation Class Initialized
INFO - 2018-02-02 06:39:44 --> Model Class Initialized
INFO - 2018-02-02 06:39:44 --> Controller Class Initialized
INFO - 2018-02-02 06:39:44 --> Model Class Initialized
INFO - 2018-02-02 06:39:44 --> Model Class Initialized
INFO - 2018-02-02 06:39:44 --> Model Class Initialized
INFO - 2018-02-02 06:39:44 --> Model Class Initialized
DEBUG - 2018-02-02 06:39:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 06:39:44 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-02 06:39:44 --> Final output sent to browser
DEBUG - 2018-02-02 06:39:44 --> Total execution time: 0.0460
INFO - 2018-02-02 06:39:44 --> Config Class Initialized
INFO - 2018-02-02 06:39:44 --> Hooks Class Initialized
DEBUG - 2018-02-02 06:39:44 --> UTF-8 Support Enabled
INFO - 2018-02-02 06:39:44 --> Utf8 Class Initialized
INFO - 2018-02-02 06:39:44 --> URI Class Initialized
INFO - 2018-02-02 06:39:44 --> Router Class Initialized
INFO - 2018-02-02 06:39:44 --> Output Class Initialized
INFO - 2018-02-02 06:39:44 --> Security Class Initialized
DEBUG - 2018-02-02 06:39:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 06:39:44 --> Input Class Initialized
INFO - 2018-02-02 06:39:44 --> Language Class Initialized
INFO - 2018-02-02 06:39:44 --> Loader Class Initialized
INFO - 2018-02-02 06:39:44 --> Helper loaded: url_helper
INFO - 2018-02-02 06:39:44 --> Helper loaded: form_helper
INFO - 2018-02-02 06:39:44 --> Database Driver Class Initialized
DEBUG - 2018-02-02 06:39:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 06:39:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 06:39:44 --> Form Validation Class Initialized
INFO - 2018-02-02 06:39:44 --> Model Class Initialized
INFO - 2018-02-02 06:39:44 --> Controller Class Initialized
INFO - 2018-02-02 06:39:44 --> Model Class Initialized
INFO - 2018-02-02 06:39:44 --> Model Class Initialized
INFO - 2018-02-02 06:39:44 --> Model Class Initialized
INFO - 2018-02-02 06:39:44 --> Model Class Initialized
DEBUG - 2018-02-02 06:39:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 06:39:45 --> Config Class Initialized
INFO - 2018-02-02 06:39:45 --> Hooks Class Initialized
DEBUG - 2018-02-02 06:39:45 --> UTF-8 Support Enabled
INFO - 2018-02-02 06:39:45 --> Utf8 Class Initialized
INFO - 2018-02-02 06:39:45 --> URI Class Initialized
INFO - 2018-02-02 06:39:45 --> Router Class Initialized
INFO - 2018-02-02 06:39:45 --> Output Class Initialized
INFO - 2018-02-02 06:39:45 --> Security Class Initialized
DEBUG - 2018-02-02 06:39:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 06:39:45 --> Input Class Initialized
INFO - 2018-02-02 06:39:45 --> Language Class Initialized
INFO - 2018-02-02 06:39:45 --> Loader Class Initialized
INFO - 2018-02-02 06:39:45 --> Helper loaded: url_helper
INFO - 2018-02-02 06:39:45 --> Helper loaded: form_helper
INFO - 2018-02-02 06:39:45 --> Database Driver Class Initialized
DEBUG - 2018-02-02 06:39:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 06:39:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 06:39:45 --> Form Validation Class Initialized
INFO - 2018-02-02 06:39:45 --> Model Class Initialized
INFO - 2018-02-02 06:39:45 --> Controller Class Initialized
INFO - 2018-02-02 06:39:45 --> Model Class Initialized
INFO - 2018-02-02 06:39:45 --> Model Class Initialized
INFO - 2018-02-02 06:39:45 --> Model Class Initialized
INFO - 2018-02-02 06:39:45 --> Model Class Initialized
DEBUG - 2018-02-02 06:39:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 06:39:45 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-02 06:39:45 --> Final output sent to browser
DEBUG - 2018-02-02 06:39:45 --> Total execution time: 0.0424
INFO - 2018-02-02 06:39:45 --> Config Class Initialized
INFO - 2018-02-02 06:39:45 --> Hooks Class Initialized
DEBUG - 2018-02-02 06:39:45 --> UTF-8 Support Enabled
INFO - 2018-02-02 06:39:45 --> Utf8 Class Initialized
INFO - 2018-02-02 06:39:45 --> URI Class Initialized
INFO - 2018-02-02 06:39:45 --> Router Class Initialized
INFO - 2018-02-02 06:39:45 --> Output Class Initialized
INFO - 2018-02-02 06:39:45 --> Security Class Initialized
DEBUG - 2018-02-02 06:39:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 06:39:45 --> Input Class Initialized
INFO - 2018-02-02 06:39:45 --> Language Class Initialized
INFO - 2018-02-02 06:39:45 --> Loader Class Initialized
INFO - 2018-02-02 06:39:45 --> Helper loaded: url_helper
INFO - 2018-02-02 06:39:45 --> Helper loaded: form_helper
INFO - 2018-02-02 06:39:45 --> Database Driver Class Initialized
DEBUG - 2018-02-02 06:39:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 06:39:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 06:39:45 --> Form Validation Class Initialized
INFO - 2018-02-02 06:39:45 --> Model Class Initialized
INFO - 2018-02-02 06:39:45 --> Controller Class Initialized
INFO - 2018-02-02 06:39:45 --> Model Class Initialized
INFO - 2018-02-02 06:39:45 --> Model Class Initialized
INFO - 2018-02-02 06:39:45 --> Model Class Initialized
INFO - 2018-02-02 06:39:45 --> Model Class Initialized
DEBUG - 2018-02-02 06:39:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 06:41:32 --> Config Class Initialized
INFO - 2018-02-02 06:41:32 --> Hooks Class Initialized
DEBUG - 2018-02-02 06:41:32 --> UTF-8 Support Enabled
INFO - 2018-02-02 06:41:32 --> Utf8 Class Initialized
INFO - 2018-02-02 06:41:32 --> URI Class Initialized
INFO - 2018-02-02 06:41:32 --> Router Class Initialized
INFO - 2018-02-02 06:41:32 --> Output Class Initialized
INFO - 2018-02-02 06:41:32 --> Security Class Initialized
DEBUG - 2018-02-02 06:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 06:41:32 --> Input Class Initialized
INFO - 2018-02-02 06:41:32 --> Language Class Initialized
INFO - 2018-02-02 06:41:32 --> Loader Class Initialized
INFO - 2018-02-02 06:41:32 --> Helper loaded: url_helper
INFO - 2018-02-02 06:41:32 --> Helper loaded: form_helper
INFO - 2018-02-02 06:41:32 --> Database Driver Class Initialized
DEBUG - 2018-02-02 06:41:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 06:41:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 06:41:32 --> Form Validation Class Initialized
INFO - 2018-02-02 06:41:32 --> Model Class Initialized
INFO - 2018-02-02 06:41:32 --> Controller Class Initialized
INFO - 2018-02-02 06:41:32 --> Model Class Initialized
INFO - 2018-02-02 06:41:32 --> Model Class Initialized
INFO - 2018-02-02 06:41:32 --> Model Class Initialized
INFO - 2018-02-02 06:41:32 --> Model Class Initialized
DEBUG - 2018-02-02 06:41:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 06:41:32 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-02 06:41:32 --> Final output sent to browser
DEBUG - 2018-02-02 06:41:32 --> Total execution time: 0.0522
INFO - 2018-02-02 06:41:33 --> Config Class Initialized
INFO - 2018-02-02 06:41:33 --> Hooks Class Initialized
DEBUG - 2018-02-02 06:41:33 --> UTF-8 Support Enabled
INFO - 2018-02-02 06:41:33 --> Utf8 Class Initialized
INFO - 2018-02-02 06:41:33 --> URI Class Initialized
INFO - 2018-02-02 06:41:33 --> Router Class Initialized
INFO - 2018-02-02 06:41:33 --> Output Class Initialized
INFO - 2018-02-02 06:41:33 --> Security Class Initialized
DEBUG - 2018-02-02 06:41:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 06:41:33 --> Input Class Initialized
INFO - 2018-02-02 06:41:33 --> Language Class Initialized
INFO - 2018-02-02 06:41:33 --> Loader Class Initialized
INFO - 2018-02-02 06:41:33 --> Helper loaded: url_helper
INFO - 2018-02-02 06:41:33 --> Helper loaded: form_helper
INFO - 2018-02-02 06:41:33 --> Database Driver Class Initialized
DEBUG - 2018-02-02 06:41:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 06:41:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 06:41:33 --> Form Validation Class Initialized
INFO - 2018-02-02 06:41:33 --> Model Class Initialized
INFO - 2018-02-02 06:41:33 --> Controller Class Initialized
INFO - 2018-02-02 06:41:33 --> Model Class Initialized
INFO - 2018-02-02 06:41:33 --> Model Class Initialized
INFO - 2018-02-02 06:41:33 --> Model Class Initialized
INFO - 2018-02-02 06:41:33 --> Model Class Initialized
DEBUG - 2018-02-02 06:41:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 06:43:49 --> Config Class Initialized
INFO - 2018-02-02 06:43:49 --> Hooks Class Initialized
DEBUG - 2018-02-02 06:43:49 --> UTF-8 Support Enabled
INFO - 2018-02-02 06:43:49 --> Utf8 Class Initialized
INFO - 2018-02-02 06:43:49 --> URI Class Initialized
INFO - 2018-02-02 06:43:49 --> Router Class Initialized
INFO - 2018-02-02 06:43:49 --> Output Class Initialized
INFO - 2018-02-02 06:43:49 --> Security Class Initialized
DEBUG - 2018-02-02 06:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 06:43:49 --> Input Class Initialized
INFO - 2018-02-02 06:43:49 --> Language Class Initialized
INFO - 2018-02-02 06:43:49 --> Loader Class Initialized
INFO - 2018-02-02 06:43:49 --> Helper loaded: url_helper
INFO - 2018-02-02 06:43:49 --> Helper loaded: form_helper
INFO - 2018-02-02 06:43:49 --> Database Driver Class Initialized
DEBUG - 2018-02-02 06:43:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 06:43:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 06:43:49 --> Form Validation Class Initialized
INFO - 2018-02-02 06:43:49 --> Model Class Initialized
INFO - 2018-02-02 06:43:49 --> Controller Class Initialized
INFO - 2018-02-02 06:43:49 --> Model Class Initialized
INFO - 2018-02-02 06:43:49 --> Model Class Initialized
INFO - 2018-02-02 06:43:49 --> Model Class Initialized
INFO - 2018-02-02 06:43:49 --> Model Class Initialized
DEBUG - 2018-02-02 06:43:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 06:43:49 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-02 06:43:49 --> Final output sent to browser
DEBUG - 2018-02-02 06:43:49 --> Total execution time: 0.0563
INFO - 2018-02-02 06:43:49 --> Config Class Initialized
INFO - 2018-02-02 06:43:49 --> Hooks Class Initialized
DEBUG - 2018-02-02 06:43:49 --> UTF-8 Support Enabled
INFO - 2018-02-02 06:43:49 --> Utf8 Class Initialized
INFO - 2018-02-02 06:43:49 --> URI Class Initialized
INFO - 2018-02-02 06:43:49 --> Router Class Initialized
INFO - 2018-02-02 06:43:49 --> Output Class Initialized
INFO - 2018-02-02 06:43:49 --> Security Class Initialized
DEBUG - 2018-02-02 06:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 06:43:49 --> Input Class Initialized
INFO - 2018-02-02 06:43:49 --> Language Class Initialized
INFO - 2018-02-02 06:43:49 --> Loader Class Initialized
INFO - 2018-02-02 06:43:49 --> Helper loaded: url_helper
INFO - 2018-02-02 06:43:49 --> Helper loaded: form_helper
INFO - 2018-02-02 06:43:49 --> Database Driver Class Initialized
DEBUG - 2018-02-02 06:43:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 06:43:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 06:43:49 --> Form Validation Class Initialized
INFO - 2018-02-02 06:43:49 --> Model Class Initialized
INFO - 2018-02-02 06:43:49 --> Controller Class Initialized
INFO - 2018-02-02 06:43:49 --> Model Class Initialized
INFO - 2018-02-02 06:43:49 --> Model Class Initialized
INFO - 2018-02-02 06:43:49 --> Model Class Initialized
INFO - 2018-02-02 06:43:49 --> Model Class Initialized
DEBUG - 2018-02-02 06:43:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 06:46:14 --> Config Class Initialized
INFO - 2018-02-02 06:46:14 --> Hooks Class Initialized
DEBUG - 2018-02-02 06:46:14 --> UTF-8 Support Enabled
INFO - 2018-02-02 06:46:14 --> Utf8 Class Initialized
INFO - 2018-02-02 06:46:14 --> URI Class Initialized
INFO - 2018-02-02 06:46:14 --> Router Class Initialized
INFO - 2018-02-02 06:46:14 --> Output Class Initialized
INFO - 2018-02-02 06:46:14 --> Security Class Initialized
DEBUG - 2018-02-02 06:46:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 06:46:14 --> Input Class Initialized
INFO - 2018-02-02 06:46:14 --> Language Class Initialized
INFO - 2018-02-02 06:46:14 --> Loader Class Initialized
INFO - 2018-02-02 06:46:14 --> Helper loaded: url_helper
INFO - 2018-02-02 06:46:14 --> Helper loaded: form_helper
INFO - 2018-02-02 06:46:14 --> Database Driver Class Initialized
DEBUG - 2018-02-02 06:46:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 06:46:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 06:46:14 --> Form Validation Class Initialized
INFO - 2018-02-02 06:46:14 --> Model Class Initialized
INFO - 2018-02-02 06:46:14 --> Controller Class Initialized
INFO - 2018-02-02 06:46:14 --> Model Class Initialized
INFO - 2018-02-02 06:46:14 --> Model Class Initialized
INFO - 2018-02-02 06:46:14 --> Model Class Initialized
INFO - 2018-02-02 06:46:14 --> Model Class Initialized
DEBUG - 2018-02-02 06:46:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 06:46:14 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-02 06:46:14 --> Final output sent to browser
DEBUG - 2018-02-02 06:46:14 --> Total execution time: 0.0444
INFO - 2018-02-02 06:46:15 --> Config Class Initialized
INFO - 2018-02-02 06:46:15 --> Hooks Class Initialized
DEBUG - 2018-02-02 06:46:15 --> UTF-8 Support Enabled
INFO - 2018-02-02 06:46:15 --> Utf8 Class Initialized
INFO - 2018-02-02 06:46:15 --> URI Class Initialized
INFO - 2018-02-02 06:46:15 --> Router Class Initialized
INFO - 2018-02-02 06:46:15 --> Output Class Initialized
INFO - 2018-02-02 06:46:15 --> Security Class Initialized
DEBUG - 2018-02-02 06:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 06:46:15 --> Input Class Initialized
INFO - 2018-02-02 06:46:15 --> Language Class Initialized
INFO - 2018-02-02 06:46:15 --> Loader Class Initialized
INFO - 2018-02-02 06:46:15 --> Helper loaded: url_helper
INFO - 2018-02-02 06:46:15 --> Helper loaded: form_helper
INFO - 2018-02-02 06:46:15 --> Database Driver Class Initialized
DEBUG - 2018-02-02 06:46:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 06:46:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 06:46:15 --> Form Validation Class Initialized
INFO - 2018-02-02 06:46:15 --> Model Class Initialized
INFO - 2018-02-02 06:46:15 --> Controller Class Initialized
INFO - 2018-02-02 06:46:15 --> Model Class Initialized
INFO - 2018-02-02 06:46:15 --> Model Class Initialized
INFO - 2018-02-02 06:46:15 --> Model Class Initialized
INFO - 2018-02-02 06:46:15 --> Model Class Initialized
DEBUG - 2018-02-02 06:46:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 06:47:24 --> Config Class Initialized
INFO - 2018-02-02 06:47:24 --> Hooks Class Initialized
DEBUG - 2018-02-02 06:47:24 --> UTF-8 Support Enabled
INFO - 2018-02-02 06:47:24 --> Utf8 Class Initialized
INFO - 2018-02-02 06:47:24 --> URI Class Initialized
INFO - 2018-02-02 06:47:24 --> Router Class Initialized
INFO - 2018-02-02 06:47:24 --> Output Class Initialized
INFO - 2018-02-02 06:47:24 --> Security Class Initialized
DEBUG - 2018-02-02 06:47:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 06:47:24 --> Input Class Initialized
INFO - 2018-02-02 06:47:24 --> Language Class Initialized
INFO - 2018-02-02 06:47:24 --> Loader Class Initialized
INFO - 2018-02-02 06:47:24 --> Helper loaded: url_helper
INFO - 2018-02-02 06:47:24 --> Helper loaded: form_helper
INFO - 2018-02-02 06:47:24 --> Database Driver Class Initialized
DEBUG - 2018-02-02 06:47:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 06:47:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 06:47:24 --> Form Validation Class Initialized
INFO - 2018-02-02 06:47:24 --> Model Class Initialized
INFO - 2018-02-02 06:47:24 --> Controller Class Initialized
INFO - 2018-02-02 06:47:24 --> Model Class Initialized
INFO - 2018-02-02 06:47:24 --> Model Class Initialized
DEBUG - 2018-02-02 06:47:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 06:47:24 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-02 06:47:24 --> Final output sent to browser
DEBUG - 2018-02-02 06:47:24 --> Total execution time: 0.0426
INFO - 2018-02-02 06:47:24 --> Config Class Initialized
INFO - 2018-02-02 06:47:24 --> Hooks Class Initialized
DEBUG - 2018-02-02 06:47:24 --> UTF-8 Support Enabled
INFO - 2018-02-02 06:47:24 --> Utf8 Class Initialized
INFO - 2018-02-02 06:47:24 --> URI Class Initialized
INFO - 2018-02-02 06:47:24 --> Router Class Initialized
INFO - 2018-02-02 06:47:24 --> Output Class Initialized
INFO - 2018-02-02 06:47:24 --> Security Class Initialized
DEBUG - 2018-02-02 06:47:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 06:47:24 --> Input Class Initialized
INFO - 2018-02-02 06:47:24 --> Language Class Initialized
INFO - 2018-02-02 06:47:24 --> Loader Class Initialized
INFO - 2018-02-02 06:47:24 --> Helper loaded: url_helper
INFO - 2018-02-02 06:47:24 --> Helper loaded: form_helper
INFO - 2018-02-02 06:47:24 --> Database Driver Class Initialized
DEBUG - 2018-02-02 06:47:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 06:47:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 06:47:24 --> Form Validation Class Initialized
INFO - 2018-02-02 06:47:24 --> Model Class Initialized
INFO - 2018-02-02 06:47:24 --> Controller Class Initialized
INFO - 2018-02-02 06:47:24 --> Model Class Initialized
INFO - 2018-02-02 06:47:24 --> Model Class Initialized
DEBUG - 2018-02-02 06:47:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 06:51:10 --> Config Class Initialized
INFO - 2018-02-02 06:51:10 --> Hooks Class Initialized
DEBUG - 2018-02-02 06:51:10 --> UTF-8 Support Enabled
INFO - 2018-02-02 06:51:10 --> Utf8 Class Initialized
INFO - 2018-02-02 06:51:10 --> URI Class Initialized
INFO - 2018-02-02 06:51:10 --> Router Class Initialized
INFO - 2018-02-02 06:51:10 --> Output Class Initialized
INFO - 2018-02-02 06:51:10 --> Security Class Initialized
DEBUG - 2018-02-02 06:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 06:51:10 --> Input Class Initialized
INFO - 2018-02-02 06:51:10 --> Language Class Initialized
INFO - 2018-02-02 06:51:10 --> Loader Class Initialized
INFO - 2018-02-02 06:51:10 --> Helper loaded: url_helper
INFO - 2018-02-02 06:51:10 --> Helper loaded: form_helper
INFO - 2018-02-02 06:51:10 --> Database Driver Class Initialized
DEBUG - 2018-02-02 06:51:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 06:51:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 06:51:10 --> Form Validation Class Initialized
INFO - 2018-02-02 06:51:10 --> Model Class Initialized
INFO - 2018-02-02 06:51:10 --> Controller Class Initialized
INFO - 2018-02-02 06:51:10 --> Model Class Initialized
INFO - 2018-02-02 06:51:10 --> Model Class Initialized
DEBUG - 2018-02-02 06:51:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 06:51:10 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-02 06:51:10 --> Final output sent to browser
DEBUG - 2018-02-02 06:51:10 --> Total execution time: 0.0493
INFO - 2018-02-02 06:51:10 --> Config Class Initialized
INFO - 2018-02-02 06:51:10 --> Hooks Class Initialized
DEBUG - 2018-02-02 06:51:10 --> UTF-8 Support Enabled
INFO - 2018-02-02 06:51:10 --> Utf8 Class Initialized
INFO - 2018-02-02 06:51:10 --> URI Class Initialized
INFO - 2018-02-02 06:51:10 --> Router Class Initialized
INFO - 2018-02-02 06:51:10 --> Output Class Initialized
INFO - 2018-02-02 06:51:10 --> Security Class Initialized
DEBUG - 2018-02-02 06:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 06:51:10 --> Input Class Initialized
INFO - 2018-02-02 06:51:10 --> Language Class Initialized
INFO - 2018-02-02 06:51:10 --> Loader Class Initialized
INFO - 2018-02-02 06:51:10 --> Helper loaded: url_helper
INFO - 2018-02-02 06:51:10 --> Helper loaded: form_helper
INFO - 2018-02-02 06:51:10 --> Database Driver Class Initialized
DEBUG - 2018-02-02 06:51:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 06:51:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 06:51:10 --> Form Validation Class Initialized
INFO - 2018-02-02 06:51:10 --> Model Class Initialized
INFO - 2018-02-02 06:51:10 --> Controller Class Initialized
INFO - 2018-02-02 06:51:10 --> Model Class Initialized
INFO - 2018-02-02 06:51:10 --> Model Class Initialized
DEBUG - 2018-02-02 06:51:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 06:51:14 --> Config Class Initialized
INFO - 2018-02-02 06:51:14 --> Hooks Class Initialized
DEBUG - 2018-02-02 06:51:14 --> UTF-8 Support Enabled
INFO - 2018-02-02 06:51:14 --> Utf8 Class Initialized
INFO - 2018-02-02 06:51:14 --> URI Class Initialized
INFO - 2018-02-02 06:51:14 --> Router Class Initialized
INFO - 2018-02-02 06:51:14 --> Output Class Initialized
INFO - 2018-02-02 06:51:14 --> Security Class Initialized
DEBUG - 2018-02-02 06:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 06:51:14 --> Input Class Initialized
INFO - 2018-02-02 06:51:14 --> Language Class Initialized
INFO - 2018-02-02 06:51:14 --> Loader Class Initialized
INFO - 2018-02-02 06:51:14 --> Helper loaded: url_helper
INFO - 2018-02-02 06:51:14 --> Helper loaded: form_helper
INFO - 2018-02-02 06:51:14 --> Database Driver Class Initialized
DEBUG - 2018-02-02 06:51:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 06:51:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 06:51:14 --> Form Validation Class Initialized
INFO - 2018-02-02 06:51:14 --> Model Class Initialized
INFO - 2018-02-02 06:51:14 --> Controller Class Initialized
INFO - 2018-02-02 06:51:14 --> Model Class Initialized
INFO - 2018-02-02 06:51:14 --> Model Class Initialized
INFO - 2018-02-02 06:51:14 --> Model Class Initialized
INFO - 2018-02-02 06:51:14 --> Model Class Initialized
DEBUG - 2018-02-02 06:51:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 06:51:14 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-02 06:51:14 --> Final output sent to browser
DEBUG - 2018-02-02 06:51:14 --> Total execution time: 0.0541
INFO - 2018-02-02 06:51:14 --> Config Class Initialized
INFO - 2018-02-02 06:51:14 --> Hooks Class Initialized
DEBUG - 2018-02-02 06:51:14 --> UTF-8 Support Enabled
INFO - 2018-02-02 06:51:14 --> Utf8 Class Initialized
INFO - 2018-02-02 06:51:14 --> URI Class Initialized
INFO - 2018-02-02 06:51:14 --> Router Class Initialized
INFO - 2018-02-02 06:51:14 --> Output Class Initialized
INFO - 2018-02-02 06:51:14 --> Security Class Initialized
DEBUG - 2018-02-02 06:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 06:51:14 --> Input Class Initialized
INFO - 2018-02-02 06:51:14 --> Language Class Initialized
INFO - 2018-02-02 06:51:14 --> Loader Class Initialized
INFO - 2018-02-02 06:51:14 --> Helper loaded: url_helper
INFO - 2018-02-02 06:51:14 --> Helper loaded: form_helper
INFO - 2018-02-02 06:51:14 --> Database Driver Class Initialized
DEBUG - 2018-02-02 06:51:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 06:51:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 06:51:14 --> Form Validation Class Initialized
INFO - 2018-02-02 06:51:14 --> Model Class Initialized
INFO - 2018-02-02 06:51:14 --> Controller Class Initialized
INFO - 2018-02-02 06:51:14 --> Model Class Initialized
INFO - 2018-02-02 06:51:14 --> Model Class Initialized
INFO - 2018-02-02 06:51:14 --> Model Class Initialized
INFO - 2018-02-02 06:51:14 --> Model Class Initialized
DEBUG - 2018-02-02 06:51:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 06:51:20 --> Config Class Initialized
INFO - 2018-02-02 06:51:20 --> Hooks Class Initialized
DEBUG - 2018-02-02 06:51:20 --> UTF-8 Support Enabled
INFO - 2018-02-02 06:51:20 --> Utf8 Class Initialized
INFO - 2018-02-02 06:51:20 --> URI Class Initialized
INFO - 2018-02-02 06:51:20 --> Router Class Initialized
INFO - 2018-02-02 06:51:20 --> Output Class Initialized
INFO - 2018-02-02 06:51:20 --> Security Class Initialized
DEBUG - 2018-02-02 06:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 06:51:20 --> Input Class Initialized
INFO - 2018-02-02 06:51:20 --> Language Class Initialized
INFO - 2018-02-02 06:51:20 --> Loader Class Initialized
INFO - 2018-02-02 06:51:20 --> Helper loaded: url_helper
INFO - 2018-02-02 06:51:20 --> Helper loaded: form_helper
INFO - 2018-02-02 06:51:20 --> Database Driver Class Initialized
DEBUG - 2018-02-02 06:51:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 06:51:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 06:51:20 --> Form Validation Class Initialized
INFO - 2018-02-02 06:51:20 --> Model Class Initialized
INFO - 2018-02-02 06:51:20 --> Controller Class Initialized
INFO - 2018-02-02 06:51:20 --> Model Class Initialized
INFO - 2018-02-02 06:51:20 --> Model Class Initialized
DEBUG - 2018-02-02 06:51:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 06:51:20 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-02 06:51:20 --> Final output sent to browser
DEBUG - 2018-02-02 06:51:20 --> Total execution time: 0.0371
INFO - 2018-02-02 06:51:20 --> Config Class Initialized
INFO - 2018-02-02 06:51:20 --> Hooks Class Initialized
DEBUG - 2018-02-02 06:51:20 --> UTF-8 Support Enabled
INFO - 2018-02-02 06:51:20 --> Utf8 Class Initialized
INFO - 2018-02-02 06:51:20 --> URI Class Initialized
INFO - 2018-02-02 06:51:20 --> Router Class Initialized
INFO - 2018-02-02 06:51:20 --> Output Class Initialized
INFO - 2018-02-02 06:51:20 --> Security Class Initialized
DEBUG - 2018-02-02 06:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 06:51:20 --> Input Class Initialized
INFO - 2018-02-02 06:51:20 --> Language Class Initialized
INFO - 2018-02-02 06:51:20 --> Loader Class Initialized
INFO - 2018-02-02 06:51:20 --> Helper loaded: url_helper
INFO - 2018-02-02 06:51:20 --> Helper loaded: form_helper
INFO - 2018-02-02 06:51:20 --> Database Driver Class Initialized
DEBUG - 2018-02-02 06:51:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 06:51:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 06:51:20 --> Form Validation Class Initialized
INFO - 2018-02-02 06:51:20 --> Model Class Initialized
INFO - 2018-02-02 06:51:20 --> Controller Class Initialized
INFO - 2018-02-02 06:51:20 --> Model Class Initialized
INFO - 2018-02-02 06:51:20 --> Model Class Initialized
DEBUG - 2018-02-02 06:51:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 06:52:03 --> Config Class Initialized
INFO - 2018-02-02 06:52:03 --> Hooks Class Initialized
DEBUG - 2018-02-02 06:52:03 --> UTF-8 Support Enabled
INFO - 2018-02-02 06:52:03 --> Utf8 Class Initialized
INFO - 2018-02-02 06:52:03 --> URI Class Initialized
INFO - 2018-02-02 06:52:03 --> Router Class Initialized
INFO - 2018-02-02 06:52:03 --> Output Class Initialized
INFO - 2018-02-02 06:52:03 --> Security Class Initialized
DEBUG - 2018-02-02 06:52:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 06:52:03 --> Input Class Initialized
INFO - 2018-02-02 06:52:03 --> Language Class Initialized
INFO - 2018-02-02 06:52:03 --> Loader Class Initialized
INFO - 2018-02-02 06:52:03 --> Helper loaded: url_helper
INFO - 2018-02-02 06:52:03 --> Helper loaded: form_helper
INFO - 2018-02-02 06:52:03 --> Database Driver Class Initialized
DEBUG - 2018-02-02 06:52:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 06:52:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 06:52:03 --> Form Validation Class Initialized
INFO - 2018-02-02 06:52:03 --> Model Class Initialized
INFO - 2018-02-02 06:52:03 --> Controller Class Initialized
INFO - 2018-02-02 06:52:03 --> Model Class Initialized
INFO - 2018-02-02 06:52:03 --> Model Class Initialized
DEBUG - 2018-02-02 06:52:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 06:52:03 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-02 06:52:03 --> Final output sent to browser
DEBUG - 2018-02-02 06:52:03 --> Total execution time: 0.0679
INFO - 2018-02-02 06:52:04 --> Config Class Initialized
INFO - 2018-02-02 06:52:04 --> Hooks Class Initialized
DEBUG - 2018-02-02 06:52:04 --> UTF-8 Support Enabled
INFO - 2018-02-02 06:52:04 --> Utf8 Class Initialized
INFO - 2018-02-02 06:52:04 --> URI Class Initialized
INFO - 2018-02-02 06:52:04 --> Router Class Initialized
INFO - 2018-02-02 06:52:04 --> Output Class Initialized
INFO - 2018-02-02 06:52:04 --> Security Class Initialized
DEBUG - 2018-02-02 06:52:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 06:52:04 --> Input Class Initialized
INFO - 2018-02-02 06:52:04 --> Language Class Initialized
INFO - 2018-02-02 06:52:04 --> Loader Class Initialized
INFO - 2018-02-02 06:52:04 --> Helper loaded: url_helper
INFO - 2018-02-02 06:52:04 --> Helper loaded: form_helper
INFO - 2018-02-02 06:52:04 --> Database Driver Class Initialized
DEBUG - 2018-02-02 06:52:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 06:52:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 06:52:04 --> Form Validation Class Initialized
INFO - 2018-02-02 06:52:04 --> Model Class Initialized
INFO - 2018-02-02 06:52:04 --> Controller Class Initialized
INFO - 2018-02-02 06:52:04 --> Model Class Initialized
INFO - 2018-02-02 06:52:04 --> Model Class Initialized
DEBUG - 2018-02-02 06:52:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 06:52:04 --> Config Class Initialized
INFO - 2018-02-02 06:52:04 --> Hooks Class Initialized
DEBUG - 2018-02-02 06:52:04 --> UTF-8 Support Enabled
INFO - 2018-02-02 06:52:04 --> Utf8 Class Initialized
INFO - 2018-02-02 06:52:04 --> URI Class Initialized
INFO - 2018-02-02 06:52:04 --> Router Class Initialized
INFO - 2018-02-02 06:52:04 --> Output Class Initialized
INFO - 2018-02-02 06:52:04 --> Security Class Initialized
DEBUG - 2018-02-02 06:52:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 06:52:04 --> Input Class Initialized
INFO - 2018-02-02 06:52:04 --> Language Class Initialized
INFO - 2018-02-02 06:52:04 --> Loader Class Initialized
INFO - 2018-02-02 06:52:04 --> Helper loaded: url_helper
INFO - 2018-02-02 06:52:04 --> Helper loaded: form_helper
INFO - 2018-02-02 06:52:04 --> Database Driver Class Initialized
DEBUG - 2018-02-02 06:52:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 06:52:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 06:52:04 --> Form Validation Class Initialized
INFO - 2018-02-02 06:52:04 --> Model Class Initialized
INFO - 2018-02-02 06:52:04 --> Controller Class Initialized
INFO - 2018-02-02 06:52:04 --> Model Class Initialized
INFO - 2018-02-02 06:52:04 --> Model Class Initialized
DEBUG - 2018-02-02 06:52:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 06:52:04 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-02 06:52:04 --> Final output sent to browser
DEBUG - 2018-02-02 06:52:04 --> Total execution time: 0.0454
INFO - 2018-02-02 06:52:04 --> Config Class Initialized
INFO - 2018-02-02 06:52:04 --> Hooks Class Initialized
DEBUG - 2018-02-02 06:52:04 --> UTF-8 Support Enabled
INFO - 2018-02-02 06:52:04 --> Utf8 Class Initialized
INFO - 2018-02-02 06:52:04 --> URI Class Initialized
INFO - 2018-02-02 06:52:04 --> Router Class Initialized
INFO - 2018-02-02 06:52:04 --> Output Class Initialized
INFO - 2018-02-02 06:52:04 --> Security Class Initialized
DEBUG - 2018-02-02 06:52:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 06:52:04 --> Input Class Initialized
INFO - 2018-02-02 06:52:04 --> Language Class Initialized
INFO - 2018-02-02 06:52:04 --> Loader Class Initialized
INFO - 2018-02-02 06:52:04 --> Helper loaded: url_helper
INFO - 2018-02-02 06:52:04 --> Helper loaded: form_helper
INFO - 2018-02-02 06:52:04 --> Database Driver Class Initialized
DEBUG - 2018-02-02 06:52:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 06:52:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 06:52:04 --> Form Validation Class Initialized
INFO - 2018-02-02 06:52:04 --> Model Class Initialized
INFO - 2018-02-02 06:52:04 --> Controller Class Initialized
INFO - 2018-02-02 06:52:04 --> Model Class Initialized
INFO - 2018-02-02 06:52:04 --> Model Class Initialized
DEBUG - 2018-02-02 06:52:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 06:52:05 --> Config Class Initialized
INFO - 2018-02-02 06:52:05 --> Hooks Class Initialized
DEBUG - 2018-02-02 06:52:05 --> UTF-8 Support Enabled
INFO - 2018-02-02 06:52:05 --> Utf8 Class Initialized
INFO - 2018-02-02 06:52:05 --> URI Class Initialized
INFO - 2018-02-02 06:52:05 --> Router Class Initialized
INFO - 2018-02-02 06:52:05 --> Output Class Initialized
INFO - 2018-02-02 06:52:05 --> Security Class Initialized
DEBUG - 2018-02-02 06:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 06:52:05 --> Input Class Initialized
INFO - 2018-02-02 06:52:05 --> Language Class Initialized
INFO - 2018-02-02 06:52:05 --> Loader Class Initialized
INFO - 2018-02-02 06:52:05 --> Helper loaded: url_helper
INFO - 2018-02-02 06:52:05 --> Helper loaded: form_helper
INFO - 2018-02-02 06:52:05 --> Database Driver Class Initialized
DEBUG - 2018-02-02 06:52:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 06:52:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 06:52:05 --> Form Validation Class Initialized
INFO - 2018-02-02 06:52:05 --> Model Class Initialized
INFO - 2018-02-02 06:52:05 --> Controller Class Initialized
INFO - 2018-02-02 06:52:05 --> Model Class Initialized
INFO - 2018-02-02 06:52:05 --> Model Class Initialized
DEBUG - 2018-02-02 06:52:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 06:52:05 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-02 06:52:05 --> Final output sent to browser
DEBUG - 2018-02-02 06:52:05 --> Total execution time: 0.0414
INFO - 2018-02-02 06:52:05 --> Config Class Initialized
INFO - 2018-02-02 06:52:05 --> Hooks Class Initialized
DEBUG - 2018-02-02 06:52:05 --> UTF-8 Support Enabled
INFO - 2018-02-02 06:52:05 --> Utf8 Class Initialized
INFO - 2018-02-02 06:52:05 --> URI Class Initialized
INFO - 2018-02-02 06:52:05 --> Router Class Initialized
INFO - 2018-02-02 06:52:05 --> Output Class Initialized
INFO - 2018-02-02 06:52:05 --> Security Class Initialized
DEBUG - 2018-02-02 06:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 06:52:05 --> Input Class Initialized
INFO - 2018-02-02 06:52:05 --> Language Class Initialized
INFO - 2018-02-02 06:52:05 --> Loader Class Initialized
INFO - 2018-02-02 06:52:05 --> Helper loaded: url_helper
INFO - 2018-02-02 06:52:05 --> Helper loaded: form_helper
INFO - 2018-02-02 06:52:05 --> Database Driver Class Initialized
DEBUG - 2018-02-02 06:52:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 06:52:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 06:52:05 --> Form Validation Class Initialized
INFO - 2018-02-02 06:52:05 --> Model Class Initialized
INFO - 2018-02-02 06:52:05 --> Controller Class Initialized
INFO - 2018-02-02 06:52:05 --> Model Class Initialized
INFO - 2018-02-02 06:52:05 --> Model Class Initialized
DEBUG - 2018-02-02 06:52:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 06:52:05 --> Config Class Initialized
INFO - 2018-02-02 06:52:05 --> Hooks Class Initialized
DEBUG - 2018-02-02 06:52:05 --> UTF-8 Support Enabled
INFO - 2018-02-02 06:52:05 --> Utf8 Class Initialized
INFO - 2018-02-02 06:52:05 --> URI Class Initialized
INFO - 2018-02-02 06:52:05 --> Router Class Initialized
INFO - 2018-02-02 06:52:05 --> Output Class Initialized
INFO - 2018-02-02 06:52:05 --> Security Class Initialized
DEBUG - 2018-02-02 06:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 06:52:05 --> Input Class Initialized
INFO - 2018-02-02 06:52:05 --> Language Class Initialized
INFO - 2018-02-02 06:52:05 --> Loader Class Initialized
INFO - 2018-02-02 06:52:05 --> Helper loaded: url_helper
INFO - 2018-02-02 06:52:05 --> Helper loaded: form_helper
INFO - 2018-02-02 06:52:05 --> Database Driver Class Initialized
DEBUG - 2018-02-02 06:52:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 06:52:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 06:52:05 --> Form Validation Class Initialized
INFO - 2018-02-02 06:52:05 --> Model Class Initialized
INFO - 2018-02-02 06:52:05 --> Controller Class Initialized
INFO - 2018-02-02 06:52:05 --> Model Class Initialized
INFO - 2018-02-02 06:52:05 --> Model Class Initialized
DEBUG - 2018-02-02 06:52:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 06:52:05 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-02 06:52:05 --> Final output sent to browser
DEBUG - 2018-02-02 06:52:05 --> Total execution time: 0.0405
INFO - 2018-02-02 06:52:05 --> Config Class Initialized
INFO - 2018-02-02 06:52:05 --> Hooks Class Initialized
DEBUG - 2018-02-02 06:52:05 --> UTF-8 Support Enabled
INFO - 2018-02-02 06:52:05 --> Utf8 Class Initialized
INFO - 2018-02-02 06:52:05 --> URI Class Initialized
INFO - 2018-02-02 06:52:05 --> Router Class Initialized
INFO - 2018-02-02 06:52:05 --> Output Class Initialized
INFO - 2018-02-02 06:52:05 --> Security Class Initialized
DEBUG - 2018-02-02 06:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 06:52:05 --> Input Class Initialized
INFO - 2018-02-02 06:52:05 --> Language Class Initialized
INFO - 2018-02-02 06:52:05 --> Loader Class Initialized
INFO - 2018-02-02 06:52:05 --> Helper loaded: url_helper
INFO - 2018-02-02 06:52:05 --> Helper loaded: form_helper
INFO - 2018-02-02 06:52:05 --> Database Driver Class Initialized
DEBUG - 2018-02-02 06:52:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 06:52:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 06:52:05 --> Form Validation Class Initialized
INFO - 2018-02-02 06:52:05 --> Model Class Initialized
INFO - 2018-02-02 06:52:05 --> Controller Class Initialized
INFO - 2018-02-02 06:52:05 --> Model Class Initialized
INFO - 2018-02-02 06:52:05 --> Model Class Initialized
DEBUG - 2018-02-02 06:52:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 06:52:05 --> Config Class Initialized
INFO - 2018-02-02 06:52:05 --> Hooks Class Initialized
DEBUG - 2018-02-02 06:52:05 --> UTF-8 Support Enabled
INFO - 2018-02-02 06:52:05 --> Utf8 Class Initialized
INFO - 2018-02-02 06:52:05 --> URI Class Initialized
INFO - 2018-02-02 06:52:05 --> Router Class Initialized
INFO - 2018-02-02 06:52:05 --> Output Class Initialized
INFO - 2018-02-02 06:52:05 --> Security Class Initialized
DEBUG - 2018-02-02 06:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 06:52:05 --> Input Class Initialized
INFO - 2018-02-02 06:52:05 --> Language Class Initialized
INFO - 2018-02-02 06:52:05 --> Loader Class Initialized
INFO - 2018-02-02 06:52:06 --> Helper loaded: url_helper
INFO - 2018-02-02 06:52:06 --> Helper loaded: form_helper
INFO - 2018-02-02 06:52:06 --> Database Driver Class Initialized
DEBUG - 2018-02-02 06:52:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 06:52:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 06:52:06 --> Form Validation Class Initialized
INFO - 2018-02-02 06:52:06 --> Model Class Initialized
INFO - 2018-02-02 06:52:06 --> Controller Class Initialized
INFO - 2018-02-02 06:52:06 --> Model Class Initialized
INFO - 2018-02-02 06:52:06 --> Model Class Initialized
DEBUG - 2018-02-02 06:52:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 06:52:06 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-02 06:52:06 --> Final output sent to browser
DEBUG - 2018-02-02 06:52:06 --> Total execution time: 0.0478
INFO - 2018-02-02 06:52:06 --> Config Class Initialized
INFO - 2018-02-02 06:52:06 --> Hooks Class Initialized
DEBUG - 2018-02-02 06:52:06 --> UTF-8 Support Enabled
INFO - 2018-02-02 06:52:06 --> Utf8 Class Initialized
INFO - 2018-02-02 06:52:06 --> URI Class Initialized
INFO - 2018-02-02 06:52:06 --> Router Class Initialized
INFO - 2018-02-02 06:52:06 --> Output Class Initialized
INFO - 2018-02-02 06:52:06 --> Security Class Initialized
DEBUG - 2018-02-02 06:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 06:52:06 --> Input Class Initialized
INFO - 2018-02-02 06:52:06 --> Language Class Initialized
INFO - 2018-02-02 06:52:06 --> Loader Class Initialized
INFO - 2018-02-02 06:52:06 --> Helper loaded: url_helper
INFO - 2018-02-02 06:52:06 --> Helper loaded: form_helper
INFO - 2018-02-02 06:52:06 --> Database Driver Class Initialized
DEBUG - 2018-02-02 06:52:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 06:52:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 06:52:06 --> Form Validation Class Initialized
INFO - 2018-02-02 06:52:06 --> Model Class Initialized
INFO - 2018-02-02 06:52:06 --> Controller Class Initialized
INFO - 2018-02-02 06:52:06 --> Model Class Initialized
INFO - 2018-02-02 06:52:06 --> Model Class Initialized
DEBUG - 2018-02-02 06:52:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 06:52:06 --> Config Class Initialized
INFO - 2018-02-02 06:52:06 --> Hooks Class Initialized
DEBUG - 2018-02-02 06:52:06 --> UTF-8 Support Enabled
INFO - 2018-02-02 06:52:06 --> Utf8 Class Initialized
INFO - 2018-02-02 06:52:06 --> URI Class Initialized
INFO - 2018-02-02 06:52:06 --> Router Class Initialized
INFO - 2018-02-02 06:52:06 --> Output Class Initialized
INFO - 2018-02-02 06:52:06 --> Security Class Initialized
DEBUG - 2018-02-02 06:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 06:52:06 --> Input Class Initialized
INFO - 2018-02-02 06:52:06 --> Language Class Initialized
INFO - 2018-02-02 06:52:06 --> Loader Class Initialized
INFO - 2018-02-02 06:52:06 --> Helper loaded: url_helper
INFO - 2018-02-02 06:52:06 --> Helper loaded: form_helper
INFO - 2018-02-02 06:52:06 --> Database Driver Class Initialized
DEBUG - 2018-02-02 06:52:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 06:52:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 06:52:06 --> Form Validation Class Initialized
INFO - 2018-02-02 06:52:06 --> Model Class Initialized
INFO - 2018-02-02 06:52:06 --> Controller Class Initialized
INFO - 2018-02-02 06:52:06 --> Model Class Initialized
INFO - 2018-02-02 06:52:06 --> Model Class Initialized
DEBUG - 2018-02-02 06:52:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 06:52:06 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-02 06:52:06 --> Final output sent to browser
DEBUG - 2018-02-02 06:52:06 --> Total execution time: 0.0511
INFO - 2018-02-02 06:52:06 --> Config Class Initialized
INFO - 2018-02-02 06:52:06 --> Hooks Class Initialized
DEBUG - 2018-02-02 06:52:06 --> UTF-8 Support Enabled
INFO - 2018-02-02 06:52:06 --> Utf8 Class Initialized
INFO - 2018-02-02 06:52:06 --> URI Class Initialized
INFO - 2018-02-02 06:52:06 --> Router Class Initialized
INFO - 2018-02-02 06:52:06 --> Output Class Initialized
INFO - 2018-02-02 06:52:06 --> Security Class Initialized
DEBUG - 2018-02-02 06:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 06:52:06 --> Input Class Initialized
INFO - 2018-02-02 06:52:06 --> Language Class Initialized
INFO - 2018-02-02 06:52:06 --> Loader Class Initialized
INFO - 2018-02-02 06:52:06 --> Helper loaded: url_helper
INFO - 2018-02-02 06:52:06 --> Helper loaded: form_helper
INFO - 2018-02-02 06:52:06 --> Database Driver Class Initialized
DEBUG - 2018-02-02 06:52:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 06:52:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 06:52:06 --> Form Validation Class Initialized
INFO - 2018-02-02 06:52:06 --> Model Class Initialized
INFO - 2018-02-02 06:52:06 --> Controller Class Initialized
INFO - 2018-02-02 06:52:06 --> Model Class Initialized
INFO - 2018-02-02 06:52:06 --> Model Class Initialized
DEBUG - 2018-02-02 06:52:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 06:52:07 --> Config Class Initialized
INFO - 2018-02-02 06:52:07 --> Hooks Class Initialized
DEBUG - 2018-02-02 06:52:07 --> UTF-8 Support Enabled
INFO - 2018-02-02 06:52:07 --> Utf8 Class Initialized
INFO - 2018-02-02 06:52:07 --> URI Class Initialized
INFO - 2018-02-02 06:52:07 --> Router Class Initialized
INFO - 2018-02-02 06:52:07 --> Output Class Initialized
INFO - 2018-02-02 06:52:07 --> Security Class Initialized
DEBUG - 2018-02-02 06:52:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 06:52:07 --> Input Class Initialized
INFO - 2018-02-02 06:52:07 --> Language Class Initialized
INFO - 2018-02-02 06:52:07 --> Loader Class Initialized
INFO - 2018-02-02 06:52:07 --> Helper loaded: url_helper
INFO - 2018-02-02 06:52:07 --> Helper loaded: form_helper
INFO - 2018-02-02 06:52:07 --> Database Driver Class Initialized
DEBUG - 2018-02-02 06:52:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 06:52:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 06:52:07 --> Form Validation Class Initialized
INFO - 2018-02-02 06:52:07 --> Model Class Initialized
INFO - 2018-02-02 06:52:07 --> Controller Class Initialized
INFO - 2018-02-02 06:52:07 --> Model Class Initialized
INFO - 2018-02-02 06:52:07 --> Model Class Initialized
DEBUG - 2018-02-02 06:52:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 06:52:07 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-02 06:52:07 --> Final output sent to browser
DEBUG - 2018-02-02 06:52:07 --> Total execution time: 0.0492
INFO - 2018-02-02 06:52:07 --> Config Class Initialized
INFO - 2018-02-02 06:52:07 --> Hooks Class Initialized
DEBUG - 2018-02-02 06:52:07 --> UTF-8 Support Enabled
INFO - 2018-02-02 06:52:07 --> Utf8 Class Initialized
INFO - 2018-02-02 06:52:07 --> URI Class Initialized
INFO - 2018-02-02 06:52:07 --> Router Class Initialized
INFO - 2018-02-02 06:52:07 --> Output Class Initialized
INFO - 2018-02-02 06:52:07 --> Security Class Initialized
DEBUG - 2018-02-02 06:52:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 06:52:07 --> Input Class Initialized
INFO - 2018-02-02 06:52:07 --> Language Class Initialized
INFO - 2018-02-02 06:52:07 --> Loader Class Initialized
INFO - 2018-02-02 06:52:07 --> Helper loaded: url_helper
INFO - 2018-02-02 06:52:07 --> Helper loaded: form_helper
INFO - 2018-02-02 06:52:07 --> Config Class Initialized
INFO - 2018-02-02 06:52:07 --> Hooks Class Initialized
INFO - 2018-02-02 06:52:07 --> Database Driver Class Initialized
DEBUG - 2018-02-02 06:52:07 --> UTF-8 Support Enabled
INFO - 2018-02-02 06:52:07 --> Utf8 Class Initialized
INFO - 2018-02-02 06:52:07 --> URI Class Initialized
INFO - 2018-02-02 06:52:07 --> Router Class Initialized
DEBUG - 2018-02-02 06:52:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 06:52:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 06:52:07 --> Output Class Initialized
INFO - 2018-02-02 06:52:07 --> Security Class Initialized
INFO - 2018-02-02 06:52:07 --> Form Validation Class Initialized
DEBUG - 2018-02-02 06:52:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 06:52:07 --> Input Class Initialized
INFO - 2018-02-02 06:52:07 --> Model Class Initialized
INFO - 2018-02-02 06:52:07 --> Controller Class Initialized
INFO - 2018-02-02 06:52:07 --> Language Class Initialized
INFO - 2018-02-02 06:52:07 --> Model Class Initialized
INFO - 2018-02-02 06:52:07 --> Model Class Initialized
DEBUG - 2018-02-02 06:52:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 06:52:07 --> Loader Class Initialized
INFO - 2018-02-02 06:52:07 --> Helper loaded: url_helper
INFO - 2018-02-02 06:52:07 --> Helper loaded: form_helper
INFO - 2018-02-02 06:52:07 --> Database Driver Class Initialized
DEBUG - 2018-02-02 06:52:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 06:52:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 06:52:07 --> Form Validation Class Initialized
INFO - 2018-02-02 06:52:07 --> Model Class Initialized
INFO - 2018-02-02 06:52:07 --> Controller Class Initialized
INFO - 2018-02-02 06:52:07 --> Model Class Initialized
INFO - 2018-02-02 06:52:07 --> Model Class Initialized
DEBUG - 2018-02-02 06:52:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 06:52:07 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-02 06:52:07 --> Final output sent to browser
DEBUG - 2018-02-02 06:52:07 --> Total execution time: 0.0436
INFO - 2018-02-02 06:52:07 --> Config Class Initialized
INFO - 2018-02-02 06:52:07 --> Hooks Class Initialized
DEBUG - 2018-02-02 06:52:07 --> UTF-8 Support Enabled
INFO - 2018-02-02 06:52:07 --> Utf8 Class Initialized
INFO - 2018-02-02 06:52:07 --> URI Class Initialized
INFO - 2018-02-02 06:52:07 --> Router Class Initialized
INFO - 2018-02-02 06:52:07 --> Output Class Initialized
INFO - 2018-02-02 06:52:07 --> Security Class Initialized
DEBUG - 2018-02-02 06:52:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 06:52:07 --> Input Class Initialized
INFO - 2018-02-02 06:52:07 --> Language Class Initialized
INFO - 2018-02-02 06:52:07 --> Loader Class Initialized
INFO - 2018-02-02 06:52:07 --> Helper loaded: url_helper
INFO - 2018-02-02 06:52:07 --> Helper loaded: form_helper
INFO - 2018-02-02 06:52:07 --> Database Driver Class Initialized
DEBUG - 2018-02-02 06:52:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 06:52:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 06:52:07 --> Form Validation Class Initialized
INFO - 2018-02-02 06:52:07 --> Model Class Initialized
INFO - 2018-02-02 06:52:07 --> Controller Class Initialized
INFO - 2018-02-02 06:52:07 --> Model Class Initialized
INFO - 2018-02-02 06:52:07 --> Model Class Initialized
DEBUG - 2018-02-02 06:52:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 06:52:07 --> Config Class Initialized
INFO - 2018-02-02 06:52:07 --> Hooks Class Initialized
DEBUG - 2018-02-02 06:52:07 --> UTF-8 Support Enabled
INFO - 2018-02-02 06:52:07 --> Utf8 Class Initialized
INFO - 2018-02-02 06:52:07 --> URI Class Initialized
INFO - 2018-02-02 06:52:07 --> Router Class Initialized
INFO - 2018-02-02 06:52:07 --> Output Class Initialized
INFO - 2018-02-02 06:52:07 --> Security Class Initialized
DEBUG - 2018-02-02 06:52:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 06:52:07 --> Input Class Initialized
INFO - 2018-02-02 06:52:07 --> Language Class Initialized
INFO - 2018-02-02 06:52:07 --> Loader Class Initialized
INFO - 2018-02-02 06:52:07 --> Helper loaded: url_helper
INFO - 2018-02-02 06:52:07 --> Helper loaded: form_helper
INFO - 2018-02-02 06:52:07 --> Database Driver Class Initialized
DEBUG - 2018-02-02 06:52:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 06:52:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 06:52:07 --> Form Validation Class Initialized
INFO - 2018-02-02 06:52:07 --> Model Class Initialized
INFO - 2018-02-02 06:52:07 --> Controller Class Initialized
INFO - 2018-02-02 06:52:07 --> Model Class Initialized
INFO - 2018-02-02 06:52:07 --> Model Class Initialized
DEBUG - 2018-02-02 06:52:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 06:52:07 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-02 06:52:07 --> Final output sent to browser
DEBUG - 2018-02-02 06:52:07 --> Total execution time: 0.0482
INFO - 2018-02-02 06:52:07 --> Config Class Initialized
INFO - 2018-02-02 06:52:07 --> Hooks Class Initialized
DEBUG - 2018-02-02 06:52:07 --> UTF-8 Support Enabled
INFO - 2018-02-02 06:52:07 --> Utf8 Class Initialized
INFO - 2018-02-02 06:52:07 --> URI Class Initialized
INFO - 2018-02-02 06:52:07 --> Router Class Initialized
INFO - 2018-02-02 06:52:07 --> Output Class Initialized
INFO - 2018-02-02 06:52:07 --> Security Class Initialized
DEBUG - 2018-02-02 06:52:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 06:52:07 --> Input Class Initialized
INFO - 2018-02-02 06:52:07 --> Language Class Initialized
INFO - 2018-02-02 06:52:07 --> Loader Class Initialized
INFO - 2018-02-02 06:52:07 --> Helper loaded: url_helper
INFO - 2018-02-02 06:52:07 --> Helper loaded: form_helper
INFO - 2018-02-02 06:52:07 --> Database Driver Class Initialized
DEBUG - 2018-02-02 06:52:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 06:52:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 06:52:07 --> Form Validation Class Initialized
INFO - 2018-02-02 06:52:07 --> Model Class Initialized
INFO - 2018-02-02 06:52:07 --> Controller Class Initialized
INFO - 2018-02-02 06:52:07 --> Model Class Initialized
INFO - 2018-02-02 06:52:07 --> Model Class Initialized
DEBUG - 2018-02-02 06:52:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 06:52:07 --> Config Class Initialized
INFO - 2018-02-02 06:52:07 --> Hooks Class Initialized
DEBUG - 2018-02-02 06:52:07 --> UTF-8 Support Enabled
INFO - 2018-02-02 06:52:07 --> Utf8 Class Initialized
INFO - 2018-02-02 06:52:07 --> URI Class Initialized
INFO - 2018-02-02 06:52:07 --> Router Class Initialized
INFO - 2018-02-02 06:52:07 --> Output Class Initialized
INFO - 2018-02-02 06:52:07 --> Security Class Initialized
DEBUG - 2018-02-02 06:52:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 06:52:07 --> Input Class Initialized
INFO - 2018-02-02 06:52:07 --> Language Class Initialized
INFO - 2018-02-02 06:52:07 --> Loader Class Initialized
INFO - 2018-02-02 06:52:07 --> Helper loaded: url_helper
INFO - 2018-02-02 06:52:07 --> Helper loaded: form_helper
INFO - 2018-02-02 06:52:07 --> Database Driver Class Initialized
DEBUG - 2018-02-02 06:52:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 06:52:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 06:52:07 --> Form Validation Class Initialized
INFO - 2018-02-02 06:52:07 --> Model Class Initialized
INFO - 2018-02-02 06:52:07 --> Controller Class Initialized
INFO - 2018-02-02 06:52:07 --> Model Class Initialized
INFO - 2018-02-02 06:52:07 --> Model Class Initialized
DEBUG - 2018-02-02 06:52:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 06:52:07 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-02 06:52:07 --> Final output sent to browser
DEBUG - 2018-02-02 06:52:07 --> Total execution time: 0.0502
INFO - 2018-02-02 06:52:07 --> Config Class Initialized
INFO - 2018-02-02 06:52:07 --> Hooks Class Initialized
DEBUG - 2018-02-02 06:52:07 --> UTF-8 Support Enabled
INFO - 2018-02-02 06:52:07 --> Utf8 Class Initialized
INFO - 2018-02-02 06:52:07 --> URI Class Initialized
INFO - 2018-02-02 06:52:07 --> Router Class Initialized
INFO - 2018-02-02 06:52:07 --> Output Class Initialized
INFO - 2018-02-02 06:52:07 --> Security Class Initialized
DEBUG - 2018-02-02 06:52:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 06:52:07 --> Input Class Initialized
INFO - 2018-02-02 06:52:07 --> Language Class Initialized
INFO - 2018-02-02 06:52:07 --> Loader Class Initialized
INFO - 2018-02-02 06:52:07 --> Helper loaded: url_helper
INFO - 2018-02-02 06:52:07 --> Helper loaded: form_helper
INFO - 2018-02-02 06:52:07 --> Database Driver Class Initialized
DEBUG - 2018-02-02 06:52:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 06:52:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 06:52:07 --> Form Validation Class Initialized
INFO - 2018-02-02 06:52:07 --> Model Class Initialized
INFO - 2018-02-02 06:52:07 --> Controller Class Initialized
INFO - 2018-02-02 06:52:07 --> Model Class Initialized
INFO - 2018-02-02 06:52:07 --> Model Class Initialized
DEBUG - 2018-02-02 06:52:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 06:55:02 --> Config Class Initialized
INFO - 2018-02-02 06:55:02 --> Hooks Class Initialized
DEBUG - 2018-02-02 06:55:02 --> UTF-8 Support Enabled
INFO - 2018-02-02 06:55:02 --> Utf8 Class Initialized
INFO - 2018-02-02 06:55:02 --> URI Class Initialized
INFO - 2018-02-02 06:55:02 --> Router Class Initialized
INFO - 2018-02-02 06:55:02 --> Output Class Initialized
INFO - 2018-02-02 06:55:02 --> Security Class Initialized
DEBUG - 2018-02-02 06:55:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 06:55:02 --> Input Class Initialized
INFO - 2018-02-02 06:55:02 --> Language Class Initialized
INFO - 2018-02-02 06:55:02 --> Loader Class Initialized
INFO - 2018-02-02 06:55:02 --> Helper loaded: url_helper
INFO - 2018-02-02 06:55:02 --> Helper loaded: form_helper
INFO - 2018-02-02 06:55:02 --> Database Driver Class Initialized
DEBUG - 2018-02-02 06:55:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 06:55:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 06:55:02 --> Form Validation Class Initialized
INFO - 2018-02-02 06:55:02 --> Model Class Initialized
INFO - 2018-02-02 06:55:02 --> Controller Class Initialized
INFO - 2018-02-02 06:55:02 --> Model Class Initialized
INFO - 2018-02-02 06:55:02 --> Model Class Initialized
DEBUG - 2018-02-02 06:55:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 06:55:02 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-02 06:55:02 --> Final output sent to browser
DEBUG - 2018-02-02 06:55:02 --> Total execution time: 0.0406
INFO - 2018-02-02 06:55:04 --> Config Class Initialized
INFO - 2018-02-02 06:55:04 --> Hooks Class Initialized
DEBUG - 2018-02-02 06:55:04 --> UTF-8 Support Enabled
INFO - 2018-02-02 06:55:04 --> Utf8 Class Initialized
INFO - 2018-02-02 06:55:04 --> URI Class Initialized
INFO - 2018-02-02 06:55:04 --> Router Class Initialized
INFO - 2018-02-02 06:55:04 --> Output Class Initialized
INFO - 2018-02-02 06:55:04 --> Security Class Initialized
DEBUG - 2018-02-02 06:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 06:55:04 --> Input Class Initialized
INFO - 2018-02-02 06:55:04 --> Language Class Initialized
INFO - 2018-02-02 06:55:04 --> Loader Class Initialized
INFO - 2018-02-02 06:55:04 --> Helper loaded: url_helper
INFO - 2018-02-02 06:55:04 --> Helper loaded: form_helper
INFO - 2018-02-02 06:55:04 --> Database Driver Class Initialized
DEBUG - 2018-02-02 06:55:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 06:55:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 06:55:04 --> Form Validation Class Initialized
INFO - 2018-02-02 06:55:04 --> Model Class Initialized
INFO - 2018-02-02 06:55:04 --> Controller Class Initialized
INFO - 2018-02-02 06:55:04 --> Model Class Initialized
INFO - 2018-02-02 06:55:04 --> Model Class Initialized
DEBUG - 2018-02-02 06:55:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 06:55:06 --> Config Class Initialized
INFO - 2018-02-02 06:55:06 --> Hooks Class Initialized
DEBUG - 2018-02-02 06:55:06 --> UTF-8 Support Enabled
INFO - 2018-02-02 06:55:06 --> Utf8 Class Initialized
INFO - 2018-02-02 06:55:06 --> URI Class Initialized
INFO - 2018-02-02 06:55:06 --> Router Class Initialized
INFO - 2018-02-02 06:55:06 --> Output Class Initialized
INFO - 2018-02-02 06:55:06 --> Security Class Initialized
DEBUG - 2018-02-02 06:55:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 06:55:06 --> Input Class Initialized
INFO - 2018-02-02 06:55:06 --> Language Class Initialized
INFO - 2018-02-02 06:55:06 --> Loader Class Initialized
INFO - 2018-02-02 06:55:06 --> Helper loaded: url_helper
INFO - 2018-02-02 06:55:06 --> Helper loaded: form_helper
INFO - 2018-02-02 06:55:06 --> Database Driver Class Initialized
DEBUG - 2018-02-02 06:55:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 06:55:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 06:55:06 --> Form Validation Class Initialized
INFO - 2018-02-02 06:55:06 --> Model Class Initialized
INFO - 2018-02-02 06:55:06 --> Controller Class Initialized
INFO - 2018-02-02 06:55:06 --> Model Class Initialized
INFO - 2018-02-02 06:55:06 --> Model Class Initialized
DEBUG - 2018-02-02 06:55:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 06:55:06 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-02 06:55:06 --> Final output sent to browser
DEBUG - 2018-02-02 06:55:06 --> Total execution time: 0.0393
INFO - 2018-02-02 06:55:06 --> Config Class Initialized
INFO - 2018-02-02 06:55:06 --> Hooks Class Initialized
DEBUG - 2018-02-02 06:55:06 --> UTF-8 Support Enabled
INFO - 2018-02-02 06:55:06 --> Utf8 Class Initialized
INFO - 2018-02-02 06:55:06 --> URI Class Initialized
INFO - 2018-02-02 06:55:06 --> Router Class Initialized
INFO - 2018-02-02 06:55:06 --> Output Class Initialized
INFO - 2018-02-02 06:55:06 --> Security Class Initialized
DEBUG - 2018-02-02 06:55:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 06:55:06 --> Input Class Initialized
INFO - 2018-02-02 06:55:06 --> Language Class Initialized
INFO - 2018-02-02 06:55:06 --> Loader Class Initialized
INFO - 2018-02-02 06:55:06 --> Helper loaded: url_helper
INFO - 2018-02-02 06:55:06 --> Helper loaded: form_helper
INFO - 2018-02-02 06:55:06 --> Database Driver Class Initialized
DEBUG - 2018-02-02 06:55:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 06:55:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 06:55:07 --> Form Validation Class Initialized
INFO - 2018-02-02 06:55:07 --> Model Class Initialized
INFO - 2018-02-02 06:55:07 --> Controller Class Initialized
INFO - 2018-02-02 06:55:07 --> Model Class Initialized
INFO - 2018-02-02 06:55:07 --> Model Class Initialized
DEBUG - 2018-02-02 06:55:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 06:56:40 --> Config Class Initialized
INFO - 2018-02-02 06:56:40 --> Hooks Class Initialized
DEBUG - 2018-02-02 06:56:40 --> UTF-8 Support Enabled
INFO - 2018-02-02 06:56:40 --> Utf8 Class Initialized
INFO - 2018-02-02 06:56:40 --> URI Class Initialized
INFO - 2018-02-02 06:56:40 --> Router Class Initialized
INFO - 2018-02-02 06:56:40 --> Output Class Initialized
INFO - 2018-02-02 06:56:40 --> Security Class Initialized
DEBUG - 2018-02-02 06:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 06:56:40 --> Input Class Initialized
INFO - 2018-02-02 06:56:40 --> Language Class Initialized
INFO - 2018-02-02 06:56:40 --> Loader Class Initialized
INFO - 2018-02-02 06:56:40 --> Helper loaded: url_helper
INFO - 2018-02-02 06:56:40 --> Helper loaded: form_helper
INFO - 2018-02-02 06:56:40 --> Database Driver Class Initialized
DEBUG - 2018-02-02 06:56:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 06:56:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 06:56:40 --> Form Validation Class Initialized
INFO - 2018-02-02 06:56:40 --> Model Class Initialized
INFO - 2018-02-02 06:56:40 --> Controller Class Initialized
INFO - 2018-02-02 06:56:40 --> Model Class Initialized
INFO - 2018-02-02 06:56:40 --> Model Class Initialized
DEBUG - 2018-02-02 06:56:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 06:56:40 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-02 06:56:40 --> Final output sent to browser
DEBUG - 2018-02-02 06:56:40 --> Total execution time: 0.0392
INFO - 2018-02-02 06:56:40 --> Config Class Initialized
INFO - 2018-02-02 06:56:40 --> Hooks Class Initialized
DEBUG - 2018-02-02 06:56:40 --> UTF-8 Support Enabled
INFO - 2018-02-02 06:56:40 --> Utf8 Class Initialized
INFO - 2018-02-02 06:56:40 --> URI Class Initialized
INFO - 2018-02-02 06:56:40 --> Router Class Initialized
INFO - 2018-02-02 06:56:40 --> Output Class Initialized
INFO - 2018-02-02 06:56:40 --> Security Class Initialized
DEBUG - 2018-02-02 06:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 06:56:40 --> Input Class Initialized
INFO - 2018-02-02 06:56:40 --> Language Class Initialized
INFO - 2018-02-02 06:56:40 --> Loader Class Initialized
INFO - 2018-02-02 06:56:40 --> Helper loaded: url_helper
INFO - 2018-02-02 06:56:40 --> Helper loaded: form_helper
INFO - 2018-02-02 06:56:40 --> Database Driver Class Initialized
DEBUG - 2018-02-02 06:56:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 06:56:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 06:56:40 --> Form Validation Class Initialized
INFO - 2018-02-02 06:56:40 --> Model Class Initialized
INFO - 2018-02-02 06:56:40 --> Controller Class Initialized
INFO - 2018-02-02 06:56:40 --> Model Class Initialized
INFO - 2018-02-02 06:56:40 --> Model Class Initialized
DEBUG - 2018-02-02 06:56:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 07:00:25 --> Config Class Initialized
INFO - 2018-02-02 07:00:25 --> Hooks Class Initialized
DEBUG - 2018-02-02 07:00:25 --> UTF-8 Support Enabled
INFO - 2018-02-02 07:00:25 --> Utf8 Class Initialized
INFO - 2018-02-02 07:00:25 --> URI Class Initialized
INFO - 2018-02-02 07:00:25 --> Router Class Initialized
INFO - 2018-02-02 07:00:25 --> Output Class Initialized
INFO - 2018-02-02 07:00:25 --> Security Class Initialized
DEBUG - 2018-02-02 07:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 07:00:25 --> Input Class Initialized
INFO - 2018-02-02 07:00:25 --> Language Class Initialized
INFO - 2018-02-02 07:00:25 --> Loader Class Initialized
INFO - 2018-02-02 07:00:25 --> Helper loaded: url_helper
INFO - 2018-02-02 07:00:25 --> Helper loaded: form_helper
INFO - 2018-02-02 07:00:25 --> Database Driver Class Initialized
DEBUG - 2018-02-02 07:00:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 07:00:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 07:00:25 --> Form Validation Class Initialized
INFO - 2018-02-02 07:00:25 --> Model Class Initialized
INFO - 2018-02-02 07:00:25 --> Controller Class Initialized
INFO - 2018-02-02 07:00:25 --> Model Class Initialized
INFO - 2018-02-02 07:00:25 --> Model Class Initialized
DEBUG - 2018-02-02 07:00:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 07:00:25 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-02 07:00:25 --> Final output sent to browser
DEBUG - 2018-02-02 07:00:25 --> Total execution time: 0.0480
INFO - 2018-02-02 07:00:26 --> Config Class Initialized
INFO - 2018-02-02 07:00:26 --> Hooks Class Initialized
DEBUG - 2018-02-02 07:00:26 --> UTF-8 Support Enabled
INFO - 2018-02-02 07:00:26 --> Utf8 Class Initialized
INFO - 2018-02-02 07:00:26 --> URI Class Initialized
INFO - 2018-02-02 07:00:26 --> Router Class Initialized
INFO - 2018-02-02 07:00:26 --> Output Class Initialized
INFO - 2018-02-02 07:00:26 --> Security Class Initialized
DEBUG - 2018-02-02 07:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 07:00:26 --> Input Class Initialized
INFO - 2018-02-02 07:00:26 --> Language Class Initialized
INFO - 2018-02-02 07:00:26 --> Loader Class Initialized
INFO - 2018-02-02 07:00:26 --> Helper loaded: url_helper
INFO - 2018-02-02 07:00:26 --> Helper loaded: form_helper
INFO - 2018-02-02 07:00:26 --> Database Driver Class Initialized
DEBUG - 2018-02-02 07:00:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 07:00:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 07:00:26 --> Form Validation Class Initialized
INFO - 2018-02-02 07:00:26 --> Model Class Initialized
INFO - 2018-02-02 07:00:26 --> Controller Class Initialized
INFO - 2018-02-02 07:00:26 --> Model Class Initialized
INFO - 2018-02-02 07:00:26 --> Model Class Initialized
DEBUG - 2018-02-02 07:00:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 07:00:31 --> Config Class Initialized
INFO - 2018-02-02 07:00:31 --> Hooks Class Initialized
DEBUG - 2018-02-02 07:00:31 --> UTF-8 Support Enabled
INFO - 2018-02-02 07:00:31 --> Utf8 Class Initialized
INFO - 2018-02-02 07:00:31 --> URI Class Initialized
INFO - 2018-02-02 07:00:31 --> Router Class Initialized
INFO - 2018-02-02 07:00:31 --> Output Class Initialized
INFO - 2018-02-02 07:00:31 --> Security Class Initialized
DEBUG - 2018-02-02 07:00:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 07:00:31 --> Input Class Initialized
INFO - 2018-02-02 07:00:31 --> Language Class Initialized
INFO - 2018-02-02 07:00:31 --> Loader Class Initialized
INFO - 2018-02-02 07:00:31 --> Helper loaded: url_helper
INFO - 2018-02-02 07:00:31 --> Helper loaded: form_helper
INFO - 2018-02-02 07:00:31 --> Database Driver Class Initialized
DEBUG - 2018-02-02 07:00:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 07:00:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 07:00:31 --> Form Validation Class Initialized
INFO - 2018-02-02 07:00:31 --> Model Class Initialized
INFO - 2018-02-02 07:00:31 --> Controller Class Initialized
INFO - 2018-02-02 07:00:31 --> Model Class Initialized
INFO - 2018-02-02 07:00:31 --> Model Class Initialized
INFO - 2018-02-02 07:00:31 --> Model Class Initialized
INFO - 2018-02-02 07:00:31 --> Model Class Initialized
DEBUG - 2018-02-02 07:00:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 07:00:31 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-02 07:00:31 --> Final output sent to browser
DEBUG - 2018-02-02 07:00:31 --> Total execution time: 0.0439
INFO - 2018-02-02 07:00:32 --> Config Class Initialized
INFO - 2018-02-02 07:00:32 --> Hooks Class Initialized
DEBUG - 2018-02-02 07:00:32 --> UTF-8 Support Enabled
INFO - 2018-02-02 07:00:32 --> Utf8 Class Initialized
INFO - 2018-02-02 07:00:32 --> URI Class Initialized
INFO - 2018-02-02 07:00:32 --> Router Class Initialized
INFO - 2018-02-02 07:00:32 --> Output Class Initialized
INFO - 2018-02-02 07:00:32 --> Security Class Initialized
DEBUG - 2018-02-02 07:00:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 07:00:32 --> Input Class Initialized
INFO - 2018-02-02 07:00:32 --> Language Class Initialized
INFO - 2018-02-02 07:00:32 --> Loader Class Initialized
INFO - 2018-02-02 07:00:32 --> Helper loaded: url_helper
INFO - 2018-02-02 07:00:32 --> Helper loaded: form_helper
INFO - 2018-02-02 07:00:32 --> Database Driver Class Initialized
DEBUG - 2018-02-02 07:00:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 07:00:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 07:00:32 --> Form Validation Class Initialized
INFO - 2018-02-02 07:00:32 --> Model Class Initialized
INFO - 2018-02-02 07:00:32 --> Controller Class Initialized
INFO - 2018-02-02 07:00:32 --> Model Class Initialized
INFO - 2018-02-02 07:00:32 --> Model Class Initialized
DEBUG - 2018-02-02 07:00:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 07:00:32 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-02 07:00:32 --> Final output sent to browser
DEBUG - 2018-02-02 07:00:32 --> Total execution time: 0.0472
INFO - 2018-02-02 07:00:32 --> Config Class Initialized
INFO - 2018-02-02 07:00:32 --> Hooks Class Initialized
DEBUG - 2018-02-02 07:00:32 --> UTF-8 Support Enabled
INFO - 2018-02-02 07:00:32 --> Utf8 Class Initialized
INFO - 2018-02-02 07:00:32 --> URI Class Initialized
INFO - 2018-02-02 07:00:32 --> Router Class Initialized
INFO - 2018-02-02 07:00:32 --> Output Class Initialized
INFO - 2018-02-02 07:00:32 --> Security Class Initialized
DEBUG - 2018-02-02 07:00:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 07:00:32 --> Input Class Initialized
INFO - 2018-02-02 07:00:32 --> Language Class Initialized
INFO - 2018-02-02 07:00:32 --> Loader Class Initialized
INFO - 2018-02-02 07:00:32 --> Helper loaded: url_helper
INFO - 2018-02-02 07:00:32 --> Helper loaded: form_helper
INFO - 2018-02-02 07:00:32 --> Database Driver Class Initialized
DEBUG - 2018-02-02 07:00:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 07:00:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 07:00:32 --> Form Validation Class Initialized
INFO - 2018-02-02 07:00:32 --> Model Class Initialized
INFO - 2018-02-02 07:00:32 --> Controller Class Initialized
INFO - 2018-02-02 07:00:32 --> Model Class Initialized
INFO - 2018-02-02 07:00:32 --> Model Class Initialized
DEBUG - 2018-02-02 07:00:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 07:00:32 --> Config Class Initialized
INFO - 2018-02-02 07:00:32 --> Hooks Class Initialized
DEBUG - 2018-02-02 07:00:32 --> UTF-8 Support Enabled
INFO - 2018-02-02 07:00:32 --> Utf8 Class Initialized
INFO - 2018-02-02 07:00:32 --> URI Class Initialized
INFO - 2018-02-02 07:00:32 --> Router Class Initialized
INFO - 2018-02-02 07:00:32 --> Output Class Initialized
INFO - 2018-02-02 07:00:32 --> Security Class Initialized
DEBUG - 2018-02-02 07:00:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 07:00:32 --> Input Class Initialized
INFO - 2018-02-02 07:00:32 --> Language Class Initialized
INFO - 2018-02-02 07:00:32 --> Loader Class Initialized
INFO - 2018-02-02 07:00:32 --> Helper loaded: url_helper
INFO - 2018-02-02 07:00:32 --> Helper loaded: form_helper
INFO - 2018-02-02 07:00:32 --> Database Driver Class Initialized
DEBUG - 2018-02-02 07:00:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 07:00:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 07:00:32 --> Form Validation Class Initialized
INFO - 2018-02-02 07:00:32 --> Model Class Initialized
INFO - 2018-02-02 07:00:32 --> Controller Class Initialized
INFO - 2018-02-02 07:00:32 --> Model Class Initialized
INFO - 2018-02-02 07:00:32 --> Model Class Initialized
DEBUG - 2018-02-02 07:00:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 07:00:32 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-02 07:00:32 --> Final output sent to browser
DEBUG - 2018-02-02 07:00:32 --> Total execution time: 0.0453
INFO - 2018-02-02 07:00:33 --> Config Class Initialized
INFO - 2018-02-02 07:00:33 --> Hooks Class Initialized
DEBUG - 2018-02-02 07:00:33 --> UTF-8 Support Enabled
INFO - 2018-02-02 07:00:33 --> Utf8 Class Initialized
INFO - 2018-02-02 07:00:33 --> URI Class Initialized
INFO - 2018-02-02 07:00:33 --> Router Class Initialized
INFO - 2018-02-02 07:00:33 --> Output Class Initialized
INFO - 2018-02-02 07:00:33 --> Security Class Initialized
DEBUG - 2018-02-02 07:00:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 07:00:33 --> Input Class Initialized
INFO - 2018-02-02 07:00:33 --> Language Class Initialized
INFO - 2018-02-02 07:00:33 --> Loader Class Initialized
INFO - 2018-02-02 07:00:33 --> Helper loaded: url_helper
INFO - 2018-02-02 07:00:33 --> Helper loaded: form_helper
INFO - 2018-02-02 07:00:33 --> Database Driver Class Initialized
DEBUG - 2018-02-02 07:00:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 07:00:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 07:00:33 --> Form Validation Class Initialized
INFO - 2018-02-02 07:00:33 --> Model Class Initialized
INFO - 2018-02-02 07:00:33 --> Controller Class Initialized
INFO - 2018-02-02 07:00:33 --> Model Class Initialized
INFO - 2018-02-02 07:00:33 --> Model Class Initialized
DEBUG - 2018-02-02 07:00:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 07:00:33 --> Config Class Initialized
INFO - 2018-02-02 07:00:33 --> Hooks Class Initialized
DEBUG - 2018-02-02 07:00:33 --> UTF-8 Support Enabled
INFO - 2018-02-02 07:00:33 --> Utf8 Class Initialized
INFO - 2018-02-02 07:00:33 --> URI Class Initialized
INFO - 2018-02-02 07:00:33 --> Router Class Initialized
INFO - 2018-02-02 07:00:33 --> Output Class Initialized
INFO - 2018-02-02 07:00:33 --> Security Class Initialized
DEBUG - 2018-02-02 07:00:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 07:00:33 --> Input Class Initialized
INFO - 2018-02-02 07:00:33 --> Language Class Initialized
INFO - 2018-02-02 07:00:33 --> Loader Class Initialized
INFO - 2018-02-02 07:00:33 --> Helper loaded: url_helper
INFO - 2018-02-02 07:00:33 --> Helper loaded: form_helper
INFO - 2018-02-02 07:00:33 --> Database Driver Class Initialized
DEBUG - 2018-02-02 07:00:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 07:00:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 07:00:33 --> Form Validation Class Initialized
INFO - 2018-02-02 07:00:33 --> Model Class Initialized
INFO - 2018-02-02 07:00:33 --> Controller Class Initialized
INFO - 2018-02-02 07:00:33 --> Model Class Initialized
INFO - 2018-02-02 07:00:33 --> Model Class Initialized
INFO - 2018-02-02 07:00:33 --> Model Class Initialized
INFO - 2018-02-02 07:00:33 --> Model Class Initialized
DEBUG - 2018-02-02 07:00:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 07:00:33 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-02 07:00:33 --> Final output sent to browser
DEBUG - 2018-02-02 07:00:33 --> Total execution time: 0.0539
INFO - 2018-02-02 07:00:33 --> Config Class Initialized
INFO - 2018-02-02 07:00:33 --> Hooks Class Initialized
DEBUG - 2018-02-02 07:00:33 --> UTF-8 Support Enabled
INFO - 2018-02-02 07:00:33 --> Utf8 Class Initialized
INFO - 2018-02-02 07:00:33 --> URI Class Initialized
INFO - 2018-02-02 07:00:33 --> Router Class Initialized
INFO - 2018-02-02 07:00:33 --> Output Class Initialized
INFO - 2018-02-02 07:00:33 --> Security Class Initialized
DEBUG - 2018-02-02 07:00:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 07:00:33 --> Input Class Initialized
INFO - 2018-02-02 07:00:33 --> Language Class Initialized
INFO - 2018-02-02 07:00:33 --> Loader Class Initialized
INFO - 2018-02-02 07:00:33 --> Helper loaded: url_helper
INFO - 2018-02-02 07:00:33 --> Helper loaded: form_helper
INFO - 2018-02-02 07:00:33 --> Database Driver Class Initialized
DEBUG - 2018-02-02 07:00:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 07:00:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 07:00:33 --> Form Validation Class Initialized
INFO - 2018-02-02 07:00:33 --> Model Class Initialized
INFO - 2018-02-02 07:00:33 --> Controller Class Initialized
INFO - 2018-02-02 07:00:33 --> Model Class Initialized
INFO - 2018-02-02 07:00:33 --> Model Class Initialized
INFO - 2018-02-02 07:00:33 --> Model Class Initialized
INFO - 2018-02-02 07:00:33 --> Model Class Initialized
DEBUG - 2018-02-02 07:00:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 07:00:34 --> Config Class Initialized
INFO - 2018-02-02 07:00:34 --> Hooks Class Initialized
DEBUG - 2018-02-02 07:00:34 --> UTF-8 Support Enabled
INFO - 2018-02-02 07:00:34 --> Utf8 Class Initialized
INFO - 2018-02-02 07:00:34 --> URI Class Initialized
DEBUG - 2018-02-02 07:00:34 --> No URI present. Default controller set.
INFO - 2018-02-02 07:00:34 --> Router Class Initialized
INFO - 2018-02-02 07:00:34 --> Output Class Initialized
INFO - 2018-02-02 07:00:34 --> Security Class Initialized
DEBUG - 2018-02-02 07:00:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 07:00:34 --> Input Class Initialized
INFO - 2018-02-02 07:00:34 --> Language Class Initialized
INFO - 2018-02-02 07:00:34 --> Loader Class Initialized
INFO - 2018-02-02 07:00:34 --> Helper loaded: url_helper
INFO - 2018-02-02 07:00:34 --> Helper loaded: form_helper
INFO - 2018-02-02 07:00:34 --> Database Driver Class Initialized
DEBUG - 2018-02-02 07:00:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 07:00:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 07:00:34 --> Form Validation Class Initialized
INFO - 2018-02-02 07:00:34 --> Model Class Initialized
INFO - 2018-02-02 07:00:34 --> Controller Class Initialized
INFO - 2018-02-02 07:00:34 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-02 07:00:34 --> Final output sent to browser
DEBUG - 2018-02-02 07:00:34 --> Total execution time: 0.0349
INFO - 2018-02-02 07:00:34 --> Config Class Initialized
INFO - 2018-02-02 07:00:34 --> Hooks Class Initialized
DEBUG - 2018-02-02 07:00:34 --> UTF-8 Support Enabled
INFO - 2018-02-02 07:00:34 --> Utf8 Class Initialized
INFO - 2018-02-02 07:00:34 --> URI Class Initialized
INFO - 2018-02-02 07:00:34 --> Router Class Initialized
INFO - 2018-02-02 07:00:34 --> Output Class Initialized
INFO - 2018-02-02 07:00:34 --> Security Class Initialized
DEBUG - 2018-02-02 07:00:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 07:00:34 --> Input Class Initialized
INFO - 2018-02-02 07:00:34 --> Language Class Initialized
INFO - 2018-02-02 07:00:34 --> Loader Class Initialized
INFO - 2018-02-02 07:00:34 --> Helper loaded: url_helper
INFO - 2018-02-02 07:00:34 --> Helper loaded: form_helper
INFO - 2018-02-02 07:00:34 --> Database Driver Class Initialized
DEBUG - 2018-02-02 07:00:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 07:00:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 07:00:34 --> Form Validation Class Initialized
INFO - 2018-02-02 07:00:34 --> Model Class Initialized
INFO - 2018-02-02 07:00:34 --> Controller Class Initialized
INFO - 2018-02-02 07:00:34 --> Model Class Initialized
INFO - 2018-02-02 07:00:34 --> Model Class Initialized
INFO - 2018-02-02 07:00:34 --> Model Class Initialized
INFO - 2018-02-02 07:00:34 --> Model Class Initialized
DEBUG - 2018-02-02 07:00:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 07:00:34 --> Config Class Initialized
INFO - 2018-02-02 07:00:34 --> Hooks Class Initialized
DEBUG - 2018-02-02 07:00:34 --> UTF-8 Support Enabled
INFO - 2018-02-02 07:00:34 --> Utf8 Class Initialized
INFO - 2018-02-02 07:00:34 --> URI Class Initialized
INFO - 2018-02-02 07:00:34 --> Router Class Initialized
INFO - 2018-02-02 07:00:34 --> Output Class Initialized
INFO - 2018-02-02 07:00:34 --> Security Class Initialized
DEBUG - 2018-02-02 07:00:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 07:00:34 --> Input Class Initialized
INFO - 2018-02-02 07:00:34 --> Language Class Initialized
INFO - 2018-02-02 07:00:34 --> Loader Class Initialized
INFO - 2018-02-02 07:00:34 --> Helper loaded: url_helper
INFO - 2018-02-02 07:00:34 --> Helper loaded: form_helper
INFO - 2018-02-02 07:00:34 --> Database Driver Class Initialized
DEBUG - 2018-02-02 07:00:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 07:00:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 07:00:34 --> Form Validation Class Initialized
INFO - 2018-02-02 07:00:34 --> Model Class Initialized
INFO - 2018-02-02 07:00:34 --> Controller Class Initialized
INFO - 2018-02-02 07:00:34 --> Model Class Initialized
INFO - 2018-02-02 07:00:34 --> Model Class Initialized
INFO - 2018-02-02 07:00:34 --> Model Class Initialized
INFO - 2018-02-02 07:00:34 --> Model Class Initialized
DEBUG - 2018-02-02 07:00:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 07:00:35 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-02 07:00:35 --> Final output sent to browser
DEBUG - 2018-02-02 07:00:35 --> Total execution time: 0.0520
INFO - 2018-02-02 07:00:35 --> Config Class Initialized
INFO - 2018-02-02 07:00:35 --> Hooks Class Initialized
DEBUG - 2018-02-02 07:00:35 --> UTF-8 Support Enabled
INFO - 2018-02-02 07:00:35 --> Utf8 Class Initialized
INFO - 2018-02-02 07:00:35 --> URI Class Initialized
INFO - 2018-02-02 07:00:35 --> Router Class Initialized
INFO - 2018-02-02 07:00:35 --> Output Class Initialized
INFO - 2018-02-02 07:00:35 --> Security Class Initialized
DEBUG - 2018-02-02 07:00:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 07:00:35 --> Input Class Initialized
INFO - 2018-02-02 07:00:35 --> Language Class Initialized
INFO - 2018-02-02 07:00:35 --> Loader Class Initialized
INFO - 2018-02-02 07:00:35 --> Helper loaded: url_helper
INFO - 2018-02-02 07:00:35 --> Helper loaded: form_helper
INFO - 2018-02-02 07:00:35 --> Database Driver Class Initialized
DEBUG - 2018-02-02 07:00:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 07:00:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 07:00:35 --> Form Validation Class Initialized
INFO - 2018-02-02 07:00:35 --> Model Class Initialized
INFO - 2018-02-02 07:00:35 --> Controller Class Initialized
INFO - 2018-02-02 07:00:35 --> Model Class Initialized
INFO - 2018-02-02 07:00:35 --> Model Class Initialized
INFO - 2018-02-02 07:00:35 --> Model Class Initialized
INFO - 2018-02-02 07:00:35 --> Model Class Initialized
DEBUG - 2018-02-02 07:00:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 07:00:35 --> Config Class Initialized
INFO - 2018-02-02 07:00:35 --> Hooks Class Initialized
DEBUG - 2018-02-02 07:00:35 --> UTF-8 Support Enabled
INFO - 2018-02-02 07:00:35 --> Utf8 Class Initialized
INFO - 2018-02-02 07:00:35 --> URI Class Initialized
INFO - 2018-02-02 07:00:35 --> Router Class Initialized
INFO - 2018-02-02 07:00:35 --> Output Class Initialized
INFO - 2018-02-02 07:00:35 --> Security Class Initialized
DEBUG - 2018-02-02 07:00:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 07:00:35 --> Input Class Initialized
INFO - 2018-02-02 07:00:35 --> Language Class Initialized
INFO - 2018-02-02 07:00:35 --> Loader Class Initialized
INFO - 2018-02-02 07:00:35 --> Helper loaded: url_helper
INFO - 2018-02-02 07:00:35 --> Helper loaded: form_helper
INFO - 2018-02-02 07:00:35 --> Database Driver Class Initialized
DEBUG - 2018-02-02 07:00:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 07:00:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 07:00:35 --> Form Validation Class Initialized
INFO - 2018-02-02 07:00:35 --> Model Class Initialized
INFO - 2018-02-02 07:00:35 --> Controller Class Initialized
INFO - 2018-02-02 07:00:35 --> Model Class Initialized
INFO - 2018-02-02 07:00:35 --> Model Class Initialized
DEBUG - 2018-02-02 07:00:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 07:00:35 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-02 07:00:35 --> Final output sent to browser
DEBUG - 2018-02-02 07:00:35 --> Total execution time: 0.0374
INFO - 2018-02-02 07:00:35 --> Config Class Initialized
INFO - 2018-02-02 07:00:35 --> Hooks Class Initialized
DEBUG - 2018-02-02 07:00:35 --> UTF-8 Support Enabled
INFO - 2018-02-02 07:00:35 --> Utf8 Class Initialized
INFO - 2018-02-02 07:00:35 --> URI Class Initialized
INFO - 2018-02-02 07:00:35 --> Router Class Initialized
INFO - 2018-02-02 07:00:35 --> Output Class Initialized
INFO - 2018-02-02 07:00:35 --> Security Class Initialized
DEBUG - 2018-02-02 07:00:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 07:00:35 --> Input Class Initialized
INFO - 2018-02-02 07:00:35 --> Language Class Initialized
INFO - 2018-02-02 07:00:35 --> Loader Class Initialized
INFO - 2018-02-02 07:00:35 --> Helper loaded: url_helper
INFO - 2018-02-02 07:00:35 --> Helper loaded: form_helper
INFO - 2018-02-02 07:00:35 --> Database Driver Class Initialized
DEBUG - 2018-02-02 07:00:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 07:00:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 07:00:35 --> Form Validation Class Initialized
INFO - 2018-02-02 07:00:35 --> Model Class Initialized
INFO - 2018-02-02 07:00:35 --> Controller Class Initialized
INFO - 2018-02-02 07:00:35 --> Model Class Initialized
INFO - 2018-02-02 07:00:35 --> Model Class Initialized
DEBUG - 2018-02-02 07:00:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 07:00:36 --> Config Class Initialized
INFO - 2018-02-02 07:00:36 --> Hooks Class Initialized
DEBUG - 2018-02-02 07:00:36 --> UTF-8 Support Enabled
INFO - 2018-02-02 07:00:36 --> Utf8 Class Initialized
INFO - 2018-02-02 07:00:36 --> URI Class Initialized
INFO - 2018-02-02 07:00:36 --> Router Class Initialized
INFO - 2018-02-02 07:00:36 --> Output Class Initialized
INFO - 2018-02-02 07:00:36 --> Security Class Initialized
DEBUG - 2018-02-02 07:00:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 07:00:36 --> Input Class Initialized
INFO - 2018-02-02 07:00:36 --> Language Class Initialized
INFO - 2018-02-02 07:00:36 --> Loader Class Initialized
INFO - 2018-02-02 07:00:36 --> Helper loaded: url_helper
INFO - 2018-02-02 07:00:36 --> Helper loaded: form_helper
INFO - 2018-02-02 07:00:36 --> Database Driver Class Initialized
DEBUG - 2018-02-02 07:00:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 07:00:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 07:00:36 --> Form Validation Class Initialized
INFO - 2018-02-02 07:00:36 --> Model Class Initialized
INFO - 2018-02-02 07:00:36 --> Controller Class Initialized
INFO - 2018-02-02 07:00:36 --> Model Class Initialized
INFO - 2018-02-02 07:00:36 --> Model Class Initialized
DEBUG - 2018-02-02 07:00:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 07:00:36 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-02 07:00:36 --> Final output sent to browser
DEBUG - 2018-02-02 07:00:36 --> Total execution time: 0.0476
INFO - 2018-02-02 07:00:37 --> Config Class Initialized
INFO - 2018-02-02 07:00:37 --> Hooks Class Initialized
DEBUG - 2018-02-02 07:00:37 --> UTF-8 Support Enabled
INFO - 2018-02-02 07:00:37 --> Utf8 Class Initialized
INFO - 2018-02-02 07:00:37 --> URI Class Initialized
INFO - 2018-02-02 07:00:37 --> Router Class Initialized
INFO - 2018-02-02 07:00:37 --> Output Class Initialized
INFO - 2018-02-02 07:00:37 --> Security Class Initialized
DEBUG - 2018-02-02 07:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 07:00:37 --> Input Class Initialized
INFO - 2018-02-02 07:00:37 --> Language Class Initialized
INFO - 2018-02-02 07:00:37 --> Loader Class Initialized
INFO - 2018-02-02 07:00:37 --> Helper loaded: url_helper
INFO - 2018-02-02 07:00:37 --> Helper loaded: form_helper
INFO - 2018-02-02 07:00:37 --> Database Driver Class Initialized
DEBUG - 2018-02-02 07:00:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 07:00:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 07:00:37 --> Form Validation Class Initialized
INFO - 2018-02-02 07:00:37 --> Model Class Initialized
INFO - 2018-02-02 07:00:37 --> Controller Class Initialized
INFO - 2018-02-02 07:00:37 --> Model Class Initialized
INFO - 2018-02-02 07:00:37 --> Model Class Initialized
DEBUG - 2018-02-02 07:00:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 07:00:37 --> Config Class Initialized
INFO - 2018-02-02 07:00:37 --> Hooks Class Initialized
DEBUG - 2018-02-02 07:00:37 --> UTF-8 Support Enabled
INFO - 2018-02-02 07:00:37 --> Utf8 Class Initialized
INFO - 2018-02-02 07:00:37 --> URI Class Initialized
INFO - 2018-02-02 07:00:37 --> Router Class Initialized
INFO - 2018-02-02 07:00:37 --> Output Class Initialized
INFO - 2018-02-02 07:00:37 --> Security Class Initialized
DEBUG - 2018-02-02 07:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 07:00:37 --> Input Class Initialized
INFO - 2018-02-02 07:00:37 --> Language Class Initialized
INFO - 2018-02-02 07:00:37 --> Loader Class Initialized
INFO - 2018-02-02 07:00:37 --> Helper loaded: url_helper
INFO - 2018-02-02 07:00:37 --> Helper loaded: form_helper
INFO - 2018-02-02 07:00:37 --> Database Driver Class Initialized
DEBUG - 2018-02-02 07:00:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 07:00:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 07:00:37 --> Form Validation Class Initialized
INFO - 2018-02-02 07:00:37 --> Model Class Initialized
INFO - 2018-02-02 07:00:37 --> Controller Class Initialized
INFO - 2018-02-02 07:00:37 --> Model Class Initialized
INFO - 2018-02-02 07:00:37 --> Model Class Initialized
INFO - 2018-02-02 07:00:37 --> Model Class Initialized
INFO - 2018-02-02 07:00:37 --> Model Class Initialized
DEBUG - 2018-02-02 07:00:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 07:00:37 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-02 07:00:37 --> Final output sent to browser
DEBUG - 2018-02-02 07:00:37 --> Total execution time: 0.0526
INFO - 2018-02-02 07:01:25 --> Config Class Initialized
INFO - 2018-02-02 07:01:25 --> Hooks Class Initialized
DEBUG - 2018-02-02 07:01:25 --> UTF-8 Support Enabled
INFO - 2018-02-02 07:01:25 --> Utf8 Class Initialized
INFO - 2018-02-02 07:01:25 --> URI Class Initialized
INFO - 2018-02-02 07:01:25 --> Router Class Initialized
INFO - 2018-02-02 07:01:25 --> Output Class Initialized
INFO - 2018-02-02 07:01:25 --> Security Class Initialized
DEBUG - 2018-02-02 07:01:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 07:01:25 --> Input Class Initialized
INFO - 2018-02-02 07:01:25 --> Language Class Initialized
INFO - 2018-02-02 07:01:25 --> Loader Class Initialized
INFO - 2018-02-02 07:01:25 --> Helper loaded: url_helper
INFO - 2018-02-02 07:01:25 --> Helper loaded: form_helper
INFO - 2018-02-02 07:01:25 --> Database Driver Class Initialized
DEBUG - 2018-02-02 07:01:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 07:01:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 07:01:25 --> Form Validation Class Initialized
INFO - 2018-02-02 07:01:25 --> Model Class Initialized
INFO - 2018-02-02 07:01:25 --> Controller Class Initialized
INFO - 2018-02-02 07:01:25 --> Model Class Initialized
INFO - 2018-02-02 07:01:25 --> Model Class Initialized
INFO - 2018-02-02 07:01:25 --> Model Class Initialized
INFO - 2018-02-02 07:01:25 --> Model Class Initialized
DEBUG - 2018-02-02 07:01:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 07:01:25 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-02 07:01:25 --> Final output sent to browser
DEBUG - 2018-02-02 07:01:25 --> Total execution time: 0.0533
INFO - 2018-02-02 07:01:26 --> Config Class Initialized
INFO - 2018-02-02 07:01:26 --> Hooks Class Initialized
DEBUG - 2018-02-02 07:01:26 --> UTF-8 Support Enabled
INFO - 2018-02-02 07:01:26 --> Utf8 Class Initialized
INFO - 2018-02-02 07:01:26 --> URI Class Initialized
INFO - 2018-02-02 07:01:26 --> Router Class Initialized
INFO - 2018-02-02 07:01:26 --> Output Class Initialized
INFO - 2018-02-02 07:01:26 --> Security Class Initialized
DEBUG - 2018-02-02 07:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 07:01:26 --> Input Class Initialized
INFO - 2018-02-02 07:01:26 --> Language Class Initialized
INFO - 2018-02-02 07:01:26 --> Loader Class Initialized
INFO - 2018-02-02 07:01:26 --> Helper loaded: url_helper
INFO - 2018-02-02 07:01:26 --> Helper loaded: form_helper
INFO - 2018-02-02 07:01:26 --> Database Driver Class Initialized
DEBUG - 2018-02-02 07:01:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 07:01:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 07:01:26 --> Form Validation Class Initialized
INFO - 2018-02-02 07:01:26 --> Model Class Initialized
INFO - 2018-02-02 07:01:26 --> Controller Class Initialized
INFO - 2018-02-02 07:01:26 --> Model Class Initialized
INFO - 2018-02-02 07:01:26 --> Model Class Initialized
INFO - 2018-02-02 07:01:26 --> Model Class Initialized
INFO - 2018-02-02 07:01:26 --> Model Class Initialized
DEBUG - 2018-02-02 07:01:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 07:01:26 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-02 07:01:26 --> Final output sent to browser
DEBUG - 2018-02-02 07:01:26 --> Total execution time: 0.0568
INFO - 2018-02-02 07:01:27 --> Config Class Initialized
INFO - 2018-02-02 07:01:27 --> Hooks Class Initialized
DEBUG - 2018-02-02 07:01:27 --> UTF-8 Support Enabled
INFO - 2018-02-02 07:01:27 --> Utf8 Class Initialized
INFO - 2018-02-02 07:01:27 --> URI Class Initialized
INFO - 2018-02-02 07:01:27 --> Router Class Initialized
INFO - 2018-02-02 07:01:27 --> Output Class Initialized
INFO - 2018-02-02 07:01:27 --> Security Class Initialized
DEBUG - 2018-02-02 07:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 07:01:27 --> Input Class Initialized
INFO - 2018-02-02 07:01:27 --> Language Class Initialized
INFO - 2018-02-02 07:01:27 --> Loader Class Initialized
INFO - 2018-02-02 07:01:27 --> Helper loaded: url_helper
INFO - 2018-02-02 07:01:27 --> Helper loaded: form_helper
INFO - 2018-02-02 07:01:27 --> Database Driver Class Initialized
DEBUG - 2018-02-02 07:01:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 07:01:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 07:01:27 --> Form Validation Class Initialized
INFO - 2018-02-02 07:01:27 --> Model Class Initialized
INFO - 2018-02-02 07:01:27 --> Controller Class Initialized
INFO - 2018-02-02 07:01:27 --> Model Class Initialized
INFO - 2018-02-02 07:01:27 --> Model Class Initialized
DEBUG - 2018-02-02 07:01:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 07:01:27 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-02 07:01:27 --> Final output sent to browser
DEBUG - 2018-02-02 07:01:27 --> Total execution time: 0.0379
INFO - 2018-02-02 07:01:27 --> Config Class Initialized
INFO - 2018-02-02 07:01:27 --> Hooks Class Initialized
DEBUG - 2018-02-02 07:01:27 --> UTF-8 Support Enabled
INFO - 2018-02-02 07:01:27 --> Utf8 Class Initialized
INFO - 2018-02-02 07:01:27 --> URI Class Initialized
INFO - 2018-02-02 07:01:27 --> Router Class Initialized
INFO - 2018-02-02 07:01:27 --> Output Class Initialized
INFO - 2018-02-02 07:01:27 --> Security Class Initialized
DEBUG - 2018-02-02 07:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 07:01:27 --> Input Class Initialized
INFO - 2018-02-02 07:01:27 --> Language Class Initialized
INFO - 2018-02-02 07:01:27 --> Loader Class Initialized
INFO - 2018-02-02 07:01:27 --> Helper loaded: url_helper
INFO - 2018-02-02 07:01:27 --> Helper loaded: form_helper
INFO - 2018-02-02 07:01:27 --> Database Driver Class Initialized
DEBUG - 2018-02-02 07:01:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 07:01:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 07:01:27 --> Form Validation Class Initialized
INFO - 2018-02-02 07:01:27 --> Model Class Initialized
INFO - 2018-02-02 07:01:27 --> Controller Class Initialized
INFO - 2018-02-02 07:01:27 --> Model Class Initialized
INFO - 2018-02-02 07:01:27 --> Model Class Initialized
DEBUG - 2018-02-02 07:01:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 07:01:28 --> Config Class Initialized
INFO - 2018-02-02 07:01:28 --> Hooks Class Initialized
DEBUG - 2018-02-02 07:01:28 --> UTF-8 Support Enabled
INFO - 2018-02-02 07:01:28 --> Utf8 Class Initialized
INFO - 2018-02-02 07:01:28 --> URI Class Initialized
INFO - 2018-02-02 07:01:28 --> Router Class Initialized
INFO - 2018-02-02 07:01:28 --> Output Class Initialized
INFO - 2018-02-02 07:01:28 --> Security Class Initialized
DEBUG - 2018-02-02 07:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 07:01:28 --> Input Class Initialized
INFO - 2018-02-02 07:01:28 --> Language Class Initialized
INFO - 2018-02-02 07:01:28 --> Loader Class Initialized
INFO - 2018-02-02 07:01:28 --> Helper loaded: url_helper
INFO - 2018-02-02 07:01:28 --> Helper loaded: form_helper
INFO - 2018-02-02 07:01:28 --> Database Driver Class Initialized
DEBUG - 2018-02-02 07:01:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 07:01:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 07:01:28 --> Form Validation Class Initialized
INFO - 2018-02-02 07:01:28 --> Model Class Initialized
INFO - 2018-02-02 07:01:28 --> Controller Class Initialized
INFO - 2018-02-02 07:01:28 --> Model Class Initialized
INFO - 2018-02-02 07:01:28 --> Model Class Initialized
DEBUG - 2018-02-02 07:01:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 07:01:28 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-02 07:01:28 --> Final output sent to browser
DEBUG - 2018-02-02 07:01:28 --> Total execution time: 0.0407
INFO - 2018-02-02 07:01:28 --> Config Class Initialized
INFO - 2018-02-02 07:01:28 --> Hooks Class Initialized
DEBUG - 2018-02-02 07:01:28 --> UTF-8 Support Enabled
INFO - 2018-02-02 07:01:28 --> Utf8 Class Initialized
INFO - 2018-02-02 07:01:28 --> URI Class Initialized
INFO - 2018-02-02 07:01:28 --> Router Class Initialized
INFO - 2018-02-02 07:01:28 --> Output Class Initialized
INFO - 2018-02-02 07:01:28 --> Security Class Initialized
DEBUG - 2018-02-02 07:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 07:01:28 --> Input Class Initialized
INFO - 2018-02-02 07:01:28 --> Language Class Initialized
INFO - 2018-02-02 07:01:28 --> Loader Class Initialized
INFO - 2018-02-02 07:01:28 --> Helper loaded: url_helper
INFO - 2018-02-02 07:01:28 --> Helper loaded: form_helper
INFO - 2018-02-02 07:01:28 --> Database Driver Class Initialized
DEBUG - 2018-02-02 07:01:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 07:01:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 07:01:28 --> Form Validation Class Initialized
INFO - 2018-02-02 07:01:28 --> Model Class Initialized
INFO - 2018-02-02 07:01:28 --> Controller Class Initialized
INFO - 2018-02-02 07:01:28 --> Model Class Initialized
INFO - 2018-02-02 07:01:28 --> Model Class Initialized
DEBUG - 2018-02-02 07:01:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 07:01:29 --> Config Class Initialized
INFO - 2018-02-02 07:01:29 --> Hooks Class Initialized
DEBUG - 2018-02-02 07:01:29 --> UTF-8 Support Enabled
INFO - 2018-02-02 07:01:29 --> Utf8 Class Initialized
INFO - 2018-02-02 07:01:29 --> URI Class Initialized
INFO - 2018-02-02 07:01:29 --> Router Class Initialized
INFO - 2018-02-02 07:01:29 --> Output Class Initialized
INFO - 2018-02-02 07:01:29 --> Security Class Initialized
DEBUG - 2018-02-02 07:01:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 07:01:29 --> Input Class Initialized
INFO - 2018-02-02 07:01:29 --> Language Class Initialized
INFO - 2018-02-02 07:01:29 --> Loader Class Initialized
INFO - 2018-02-02 07:01:29 --> Helper loaded: url_helper
INFO - 2018-02-02 07:01:29 --> Helper loaded: form_helper
INFO - 2018-02-02 07:01:29 --> Database Driver Class Initialized
DEBUG - 2018-02-02 07:01:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 07:01:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 07:01:29 --> Form Validation Class Initialized
INFO - 2018-02-02 07:01:29 --> Model Class Initialized
INFO - 2018-02-02 07:01:29 --> Controller Class Initialized
INFO - 2018-02-02 07:01:29 --> Model Class Initialized
INFO - 2018-02-02 07:01:29 --> Model Class Initialized
INFO - 2018-02-02 07:01:29 --> Model Class Initialized
INFO - 2018-02-02 07:01:29 --> Model Class Initialized
DEBUG - 2018-02-02 07:01:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 07:01:29 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-02 07:01:29 --> Final output sent to browser
DEBUG - 2018-02-02 07:01:29 --> Total execution time: 0.0533
INFO - 2018-02-02 07:01:29 --> Config Class Initialized
INFO - 2018-02-02 07:01:29 --> Hooks Class Initialized
DEBUG - 2018-02-02 07:01:29 --> UTF-8 Support Enabled
INFO - 2018-02-02 07:01:29 --> Utf8 Class Initialized
INFO - 2018-02-02 07:01:29 --> URI Class Initialized
INFO - 2018-02-02 07:01:29 --> Router Class Initialized
INFO - 2018-02-02 07:01:29 --> Output Class Initialized
INFO - 2018-02-02 07:01:29 --> Security Class Initialized
DEBUG - 2018-02-02 07:01:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 07:01:29 --> Input Class Initialized
INFO - 2018-02-02 07:01:29 --> Language Class Initialized
INFO - 2018-02-02 07:01:29 --> Loader Class Initialized
INFO - 2018-02-02 07:01:29 --> Helper loaded: url_helper
INFO - 2018-02-02 07:01:29 --> Helper loaded: form_helper
INFO - 2018-02-02 07:01:29 --> Database Driver Class Initialized
DEBUG - 2018-02-02 07:01:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 07:01:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 07:01:29 --> Form Validation Class Initialized
INFO - 2018-02-02 07:01:29 --> Model Class Initialized
INFO - 2018-02-02 07:01:29 --> Controller Class Initialized
INFO - 2018-02-02 07:01:29 --> Model Class Initialized
INFO - 2018-02-02 07:01:29 --> Model Class Initialized
INFO - 2018-02-02 07:01:29 --> Model Class Initialized
INFO - 2018-02-02 07:01:29 --> Model Class Initialized
DEBUG - 2018-02-02 07:01:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 07:01:29 --> Config Class Initialized
INFO - 2018-02-02 07:01:29 --> Hooks Class Initialized
DEBUG - 2018-02-02 07:01:29 --> UTF-8 Support Enabled
INFO - 2018-02-02 07:01:29 --> Utf8 Class Initialized
INFO - 2018-02-02 07:01:29 --> URI Class Initialized
DEBUG - 2018-02-02 07:01:29 --> No URI present. Default controller set.
INFO - 2018-02-02 07:01:29 --> Router Class Initialized
INFO - 2018-02-02 07:01:29 --> Output Class Initialized
INFO - 2018-02-02 07:01:29 --> Security Class Initialized
DEBUG - 2018-02-02 07:01:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 07:01:29 --> Input Class Initialized
INFO - 2018-02-02 07:01:29 --> Language Class Initialized
INFO - 2018-02-02 07:01:29 --> Loader Class Initialized
INFO - 2018-02-02 07:01:29 --> Helper loaded: url_helper
INFO - 2018-02-02 07:01:29 --> Helper loaded: form_helper
INFO - 2018-02-02 07:01:29 --> Database Driver Class Initialized
DEBUG - 2018-02-02 07:01:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 07:01:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 07:01:29 --> Form Validation Class Initialized
INFO - 2018-02-02 07:01:29 --> Model Class Initialized
INFO - 2018-02-02 07:01:29 --> Controller Class Initialized
INFO - 2018-02-02 07:01:29 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-02 07:01:29 --> Final output sent to browser
DEBUG - 2018-02-02 07:01:29 --> Total execution time: 0.0441
INFO - 2018-02-02 07:01:29 --> Config Class Initialized
INFO - 2018-02-02 07:01:29 --> Hooks Class Initialized
DEBUG - 2018-02-02 07:01:29 --> UTF-8 Support Enabled
INFO - 2018-02-02 07:01:29 --> Utf8 Class Initialized
INFO - 2018-02-02 07:01:29 --> URI Class Initialized
INFO - 2018-02-02 07:01:29 --> Router Class Initialized
INFO - 2018-02-02 07:01:29 --> Output Class Initialized
INFO - 2018-02-02 07:01:29 --> Security Class Initialized
DEBUG - 2018-02-02 07:01:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 07:01:29 --> Input Class Initialized
INFO - 2018-02-02 07:01:29 --> Language Class Initialized
INFO - 2018-02-02 07:01:29 --> Loader Class Initialized
INFO - 2018-02-02 07:01:29 --> Helper loaded: url_helper
INFO - 2018-02-02 07:01:29 --> Helper loaded: form_helper
INFO - 2018-02-02 07:01:29 --> Database Driver Class Initialized
DEBUG - 2018-02-02 07:01:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 07:01:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 07:01:29 --> Form Validation Class Initialized
INFO - 2018-02-02 07:01:29 --> Model Class Initialized
INFO - 2018-02-02 07:01:29 --> Controller Class Initialized
INFO - 2018-02-02 07:01:29 --> Model Class Initialized
INFO - 2018-02-02 07:01:29 --> Model Class Initialized
INFO - 2018-02-02 07:01:29 --> Model Class Initialized
INFO - 2018-02-02 07:01:29 --> Model Class Initialized
DEBUG - 2018-02-02 07:01:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 07:01:30 --> Config Class Initialized
INFO - 2018-02-02 07:01:30 --> Hooks Class Initialized
DEBUG - 2018-02-02 07:01:30 --> UTF-8 Support Enabled
INFO - 2018-02-02 07:01:30 --> Utf8 Class Initialized
INFO - 2018-02-02 07:01:30 --> URI Class Initialized
INFO - 2018-02-02 07:01:30 --> Router Class Initialized
INFO - 2018-02-02 07:01:30 --> Output Class Initialized
INFO - 2018-02-02 07:01:30 --> Security Class Initialized
DEBUG - 2018-02-02 07:01:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 07:01:30 --> Input Class Initialized
INFO - 2018-02-02 07:01:30 --> Language Class Initialized
INFO - 2018-02-02 07:01:30 --> Loader Class Initialized
INFO - 2018-02-02 07:01:30 --> Helper loaded: url_helper
INFO - 2018-02-02 07:01:30 --> Helper loaded: form_helper
INFO - 2018-02-02 07:01:30 --> Database Driver Class Initialized
DEBUG - 2018-02-02 07:01:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 07:01:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 07:01:30 --> Form Validation Class Initialized
INFO - 2018-02-02 07:01:30 --> Model Class Initialized
INFO - 2018-02-02 07:01:30 --> Controller Class Initialized
INFO - 2018-02-02 07:01:30 --> Model Class Initialized
DEBUG - 2018-02-02 07:01:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 07:01:30 --> Config Class Initialized
INFO - 2018-02-02 07:01:30 --> Hooks Class Initialized
DEBUG - 2018-02-02 07:01:30 --> UTF-8 Support Enabled
INFO - 2018-02-02 07:01:30 --> Utf8 Class Initialized
INFO - 2018-02-02 07:01:30 --> URI Class Initialized
INFO - 2018-02-02 07:01:30 --> Router Class Initialized
INFO - 2018-02-02 07:01:30 --> Output Class Initialized
INFO - 2018-02-02 07:01:30 --> Security Class Initialized
DEBUG - 2018-02-02 07:01:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 07:01:30 --> Input Class Initialized
INFO - 2018-02-02 07:01:30 --> Language Class Initialized
INFO - 2018-02-02 07:01:30 --> Loader Class Initialized
INFO - 2018-02-02 07:01:30 --> Helper loaded: url_helper
INFO - 2018-02-02 07:01:30 --> Helper loaded: form_helper
INFO - 2018-02-02 07:01:30 --> Database Driver Class Initialized
DEBUG - 2018-02-02 07:01:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 07:01:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 07:01:30 --> Form Validation Class Initialized
INFO - 2018-02-02 07:01:30 --> Model Class Initialized
INFO - 2018-02-02 07:01:30 --> Controller Class Initialized
INFO - 2018-02-02 07:01:30 --> Model Class Initialized
DEBUG - 2018-02-02 07:01:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 07:01:30 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-02 07:01:30 --> Final output sent to browser
DEBUG - 2018-02-02 07:01:30 --> Total execution time: 0.0458
INFO - 2018-02-02 07:01:35 --> Config Class Initialized
INFO - 2018-02-02 07:01:35 --> Hooks Class Initialized
DEBUG - 2018-02-02 07:01:35 --> UTF-8 Support Enabled
INFO - 2018-02-02 07:01:35 --> Utf8 Class Initialized
INFO - 2018-02-02 07:01:35 --> URI Class Initialized
INFO - 2018-02-02 07:01:35 --> Router Class Initialized
INFO - 2018-02-02 07:01:35 --> Output Class Initialized
INFO - 2018-02-02 07:01:35 --> Security Class Initialized
DEBUG - 2018-02-02 07:01:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 07:01:35 --> Input Class Initialized
INFO - 2018-02-02 07:01:35 --> Language Class Initialized
INFO - 2018-02-02 07:01:35 --> Loader Class Initialized
INFO - 2018-02-02 07:01:35 --> Helper loaded: url_helper
INFO - 2018-02-02 07:01:35 --> Helper loaded: form_helper
INFO - 2018-02-02 07:01:35 --> Database Driver Class Initialized
DEBUG - 2018-02-02 07:01:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 07:01:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 07:01:35 --> Form Validation Class Initialized
INFO - 2018-02-02 07:01:35 --> Model Class Initialized
INFO - 2018-02-02 07:01:35 --> Controller Class Initialized
INFO - 2018-02-02 07:01:35 --> Model Class Initialized
DEBUG - 2018-02-02 07:01:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 07:01:35 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-02 07:01:35 --> Config Class Initialized
INFO - 2018-02-02 07:01:35 --> Hooks Class Initialized
DEBUG - 2018-02-02 07:01:35 --> UTF-8 Support Enabled
INFO - 2018-02-02 07:01:35 --> Utf8 Class Initialized
INFO - 2018-02-02 07:01:35 --> URI Class Initialized
DEBUG - 2018-02-02 07:01:35 --> No URI present. Default controller set.
INFO - 2018-02-02 07:01:35 --> Router Class Initialized
INFO - 2018-02-02 07:01:35 --> Output Class Initialized
INFO - 2018-02-02 07:01:35 --> Security Class Initialized
DEBUG - 2018-02-02 07:01:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 07:01:35 --> Input Class Initialized
INFO - 2018-02-02 07:01:35 --> Language Class Initialized
INFO - 2018-02-02 07:01:35 --> Loader Class Initialized
INFO - 2018-02-02 07:01:35 --> Helper loaded: url_helper
INFO - 2018-02-02 07:01:35 --> Helper loaded: form_helper
INFO - 2018-02-02 07:01:35 --> Database Driver Class Initialized
DEBUG - 2018-02-02 07:01:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 07:01:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 07:01:35 --> Form Validation Class Initialized
INFO - 2018-02-02 07:01:35 --> Model Class Initialized
INFO - 2018-02-02 07:01:35 --> Controller Class Initialized
INFO - 2018-02-02 07:01:35 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-02 07:01:35 --> Final output sent to browser
DEBUG - 2018-02-02 07:01:35 --> Total execution time: 0.0496
INFO - 2018-02-02 07:01:35 --> Config Class Initialized
INFO - 2018-02-02 07:01:35 --> Hooks Class Initialized
DEBUG - 2018-02-02 07:01:35 --> UTF-8 Support Enabled
INFO - 2018-02-02 07:01:35 --> Utf8 Class Initialized
INFO - 2018-02-02 07:01:35 --> URI Class Initialized
INFO - 2018-02-02 07:01:35 --> Router Class Initialized
INFO - 2018-02-02 07:01:35 --> Output Class Initialized
INFO - 2018-02-02 07:01:35 --> Security Class Initialized
DEBUG - 2018-02-02 07:01:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 07:01:35 --> Input Class Initialized
INFO - 2018-02-02 07:01:35 --> Language Class Initialized
INFO - 2018-02-02 07:01:35 --> Loader Class Initialized
INFO - 2018-02-02 07:01:35 --> Helper loaded: url_helper
INFO - 2018-02-02 07:01:35 --> Helper loaded: form_helper
INFO - 2018-02-02 07:01:35 --> Database Driver Class Initialized
DEBUG - 2018-02-02 07:01:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 07:01:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 07:01:35 --> Form Validation Class Initialized
INFO - 2018-02-02 07:01:35 --> Model Class Initialized
INFO - 2018-02-02 07:01:35 --> Controller Class Initialized
INFO - 2018-02-02 07:01:35 --> Model Class Initialized
INFO - 2018-02-02 07:01:35 --> Model Class Initialized
INFO - 2018-02-02 07:01:35 --> Model Class Initialized
INFO - 2018-02-02 07:01:35 --> Model Class Initialized
DEBUG - 2018-02-02 07:01:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 07:01:47 --> Config Class Initialized
INFO - 2018-02-02 07:01:47 --> Hooks Class Initialized
DEBUG - 2018-02-02 07:01:47 --> UTF-8 Support Enabled
INFO - 2018-02-02 07:01:47 --> Utf8 Class Initialized
INFO - 2018-02-02 07:01:47 --> URI Class Initialized
INFO - 2018-02-02 07:01:47 --> Router Class Initialized
INFO - 2018-02-02 07:01:47 --> Output Class Initialized
INFO - 2018-02-02 07:01:47 --> Security Class Initialized
DEBUG - 2018-02-02 07:01:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 07:01:47 --> Input Class Initialized
INFO - 2018-02-02 07:01:47 --> Language Class Initialized
INFO - 2018-02-02 07:01:47 --> Loader Class Initialized
INFO - 2018-02-02 07:01:47 --> Helper loaded: url_helper
INFO - 2018-02-02 07:01:47 --> Helper loaded: form_helper
INFO - 2018-02-02 07:01:47 --> Database Driver Class Initialized
DEBUG - 2018-02-02 07:01:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 07:01:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 07:01:47 --> Form Validation Class Initialized
INFO - 2018-02-02 07:01:47 --> Model Class Initialized
INFO - 2018-02-02 07:01:47 --> Controller Class Initialized
INFO - 2018-02-02 07:01:47 --> Model Class Initialized
DEBUG - 2018-02-02 07:01:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 07:01:47 --> Config Class Initialized
INFO - 2018-02-02 07:01:47 --> Hooks Class Initialized
DEBUG - 2018-02-02 07:01:47 --> UTF-8 Support Enabled
INFO - 2018-02-02 07:01:47 --> Utf8 Class Initialized
INFO - 2018-02-02 07:01:47 --> URI Class Initialized
INFO - 2018-02-02 07:01:47 --> Router Class Initialized
INFO - 2018-02-02 07:01:47 --> Output Class Initialized
INFO - 2018-02-02 07:01:47 --> Security Class Initialized
DEBUG - 2018-02-02 07:01:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 07:01:47 --> Input Class Initialized
INFO - 2018-02-02 07:01:47 --> Language Class Initialized
INFO - 2018-02-02 07:01:47 --> Loader Class Initialized
INFO - 2018-02-02 07:01:47 --> Helper loaded: url_helper
INFO - 2018-02-02 07:01:47 --> Helper loaded: form_helper
INFO - 2018-02-02 07:01:47 --> Database Driver Class Initialized
DEBUG - 2018-02-02 07:01:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 07:01:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 07:01:47 --> Form Validation Class Initialized
INFO - 2018-02-02 07:01:47 --> Model Class Initialized
INFO - 2018-02-02 07:01:47 --> Controller Class Initialized
INFO - 2018-02-02 07:01:47 --> Model Class Initialized
DEBUG - 2018-02-02 07:01:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 07:01:47 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-02 07:01:47 --> Final output sent to browser
DEBUG - 2018-02-02 07:01:47 --> Total execution time: 0.0358
INFO - 2018-02-02 07:01:51 --> Config Class Initialized
INFO - 2018-02-02 07:01:51 --> Hooks Class Initialized
DEBUG - 2018-02-02 07:01:51 --> UTF-8 Support Enabled
INFO - 2018-02-02 07:01:51 --> Utf8 Class Initialized
INFO - 2018-02-02 07:01:51 --> URI Class Initialized
INFO - 2018-02-02 07:01:51 --> Router Class Initialized
INFO - 2018-02-02 07:01:51 --> Output Class Initialized
INFO - 2018-02-02 07:01:51 --> Security Class Initialized
DEBUG - 2018-02-02 07:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 07:01:51 --> Input Class Initialized
INFO - 2018-02-02 07:01:51 --> Language Class Initialized
INFO - 2018-02-02 07:01:51 --> Loader Class Initialized
INFO - 2018-02-02 07:01:51 --> Helper loaded: url_helper
INFO - 2018-02-02 07:01:51 --> Helper loaded: form_helper
INFO - 2018-02-02 07:01:51 --> Database Driver Class Initialized
DEBUG - 2018-02-02 07:01:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 07:01:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 07:01:51 --> Form Validation Class Initialized
INFO - 2018-02-02 07:01:51 --> Model Class Initialized
INFO - 2018-02-02 07:01:51 --> Controller Class Initialized
INFO - 2018-02-02 07:01:51 --> Model Class Initialized
DEBUG - 2018-02-02 07:01:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 07:01:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-02 07:01:51 --> Config Class Initialized
INFO - 2018-02-02 07:01:51 --> Hooks Class Initialized
DEBUG - 2018-02-02 07:01:51 --> UTF-8 Support Enabled
INFO - 2018-02-02 07:01:51 --> Utf8 Class Initialized
INFO - 2018-02-02 07:01:51 --> URI Class Initialized
DEBUG - 2018-02-02 07:01:51 --> No URI present. Default controller set.
INFO - 2018-02-02 07:01:51 --> Router Class Initialized
INFO - 2018-02-02 07:01:51 --> Output Class Initialized
INFO - 2018-02-02 07:01:51 --> Security Class Initialized
DEBUG - 2018-02-02 07:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 07:01:51 --> Input Class Initialized
INFO - 2018-02-02 07:01:51 --> Language Class Initialized
INFO - 2018-02-02 07:01:51 --> Loader Class Initialized
INFO - 2018-02-02 07:01:51 --> Helper loaded: url_helper
INFO - 2018-02-02 07:01:51 --> Helper loaded: form_helper
INFO - 2018-02-02 07:01:51 --> Database Driver Class Initialized
DEBUG - 2018-02-02 07:01:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 07:01:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 07:01:51 --> Form Validation Class Initialized
INFO - 2018-02-02 07:01:51 --> Model Class Initialized
INFO - 2018-02-02 07:01:51 --> Controller Class Initialized
INFO - 2018-02-02 07:01:51 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-02 07:01:51 --> Final output sent to browser
DEBUG - 2018-02-02 07:01:51 --> Total execution time: 0.0528
INFO - 2018-02-02 07:01:51 --> Config Class Initialized
INFO - 2018-02-02 07:01:51 --> Hooks Class Initialized
DEBUG - 2018-02-02 07:01:51 --> UTF-8 Support Enabled
INFO - 2018-02-02 07:01:51 --> Utf8 Class Initialized
INFO - 2018-02-02 07:01:51 --> URI Class Initialized
INFO - 2018-02-02 07:01:51 --> Router Class Initialized
INFO - 2018-02-02 07:01:51 --> Output Class Initialized
INFO - 2018-02-02 07:01:51 --> Security Class Initialized
DEBUG - 2018-02-02 07:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 07:01:51 --> Input Class Initialized
INFO - 2018-02-02 07:01:51 --> Language Class Initialized
INFO - 2018-02-02 07:01:51 --> Loader Class Initialized
INFO - 2018-02-02 07:01:51 --> Helper loaded: url_helper
INFO - 2018-02-02 07:01:51 --> Helper loaded: form_helper
INFO - 2018-02-02 07:01:51 --> Database Driver Class Initialized
DEBUG - 2018-02-02 07:01:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 07:01:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 07:01:51 --> Form Validation Class Initialized
INFO - 2018-02-02 07:01:51 --> Model Class Initialized
INFO - 2018-02-02 07:01:51 --> Controller Class Initialized
INFO - 2018-02-02 07:01:51 --> Model Class Initialized
INFO - 2018-02-02 07:01:51 --> Model Class Initialized
INFO - 2018-02-02 07:01:51 --> Model Class Initialized
INFO - 2018-02-02 07:01:51 --> Model Class Initialized
DEBUG - 2018-02-02 07:01:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 07:03:50 --> Config Class Initialized
INFO - 2018-02-02 07:03:50 --> Hooks Class Initialized
DEBUG - 2018-02-02 07:03:50 --> UTF-8 Support Enabled
INFO - 2018-02-02 07:03:50 --> Utf8 Class Initialized
INFO - 2018-02-02 07:03:50 --> URI Class Initialized
DEBUG - 2018-02-02 07:03:50 --> No URI present. Default controller set.
INFO - 2018-02-02 07:03:50 --> Router Class Initialized
INFO - 2018-02-02 07:03:50 --> Output Class Initialized
INFO - 2018-02-02 07:03:50 --> Security Class Initialized
DEBUG - 2018-02-02 07:03:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 07:03:50 --> Input Class Initialized
INFO - 2018-02-02 07:03:50 --> Language Class Initialized
INFO - 2018-02-02 07:03:50 --> Loader Class Initialized
INFO - 2018-02-02 07:03:50 --> Helper loaded: url_helper
INFO - 2018-02-02 07:03:50 --> Helper loaded: form_helper
INFO - 2018-02-02 07:03:50 --> Database Driver Class Initialized
DEBUG - 2018-02-02 07:03:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 07:03:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 07:03:50 --> Form Validation Class Initialized
INFO - 2018-02-02 07:03:50 --> Model Class Initialized
INFO - 2018-02-02 07:03:50 --> Controller Class Initialized
INFO - 2018-02-02 07:03:50 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-02 07:03:50 --> Final output sent to browser
DEBUG - 2018-02-02 07:03:50 --> Total execution time: 0.0539
INFO - 2018-02-02 07:03:50 --> Config Class Initialized
INFO - 2018-02-02 07:03:50 --> Hooks Class Initialized
DEBUG - 2018-02-02 07:03:50 --> UTF-8 Support Enabled
INFO - 2018-02-02 07:03:50 --> Utf8 Class Initialized
INFO - 2018-02-02 07:03:50 --> URI Class Initialized
INFO - 2018-02-02 07:03:50 --> Router Class Initialized
INFO - 2018-02-02 07:03:50 --> Output Class Initialized
INFO - 2018-02-02 07:03:50 --> Security Class Initialized
DEBUG - 2018-02-02 07:03:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 07:03:50 --> Input Class Initialized
INFO - 2018-02-02 07:03:50 --> Language Class Initialized
INFO - 2018-02-02 07:03:50 --> Loader Class Initialized
INFO - 2018-02-02 07:03:50 --> Helper loaded: url_helper
INFO - 2018-02-02 07:03:50 --> Helper loaded: form_helper
INFO - 2018-02-02 07:03:51 --> Database Driver Class Initialized
DEBUG - 2018-02-02 07:03:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 07:03:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 07:03:51 --> Form Validation Class Initialized
INFO - 2018-02-02 07:03:51 --> Model Class Initialized
INFO - 2018-02-02 07:03:51 --> Controller Class Initialized
INFO - 2018-02-02 07:03:51 --> Model Class Initialized
INFO - 2018-02-02 07:03:51 --> Model Class Initialized
INFO - 2018-02-02 07:03:51 --> Model Class Initialized
INFO - 2018-02-02 07:03:51 --> Model Class Initialized
DEBUG - 2018-02-02 07:03:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 07:06:48 --> Config Class Initialized
INFO - 2018-02-02 07:06:48 --> Hooks Class Initialized
DEBUG - 2018-02-02 07:06:48 --> UTF-8 Support Enabled
INFO - 2018-02-02 07:06:48 --> Utf8 Class Initialized
INFO - 2018-02-02 07:06:48 --> URI Class Initialized
DEBUG - 2018-02-02 07:06:48 --> No URI present. Default controller set.
INFO - 2018-02-02 07:06:48 --> Router Class Initialized
INFO - 2018-02-02 07:06:48 --> Output Class Initialized
INFO - 2018-02-02 07:06:48 --> Security Class Initialized
DEBUG - 2018-02-02 07:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 07:06:48 --> Input Class Initialized
INFO - 2018-02-02 07:06:48 --> Language Class Initialized
INFO - 2018-02-02 07:06:48 --> Loader Class Initialized
INFO - 2018-02-02 07:06:48 --> Helper loaded: url_helper
INFO - 2018-02-02 07:06:48 --> Helper loaded: form_helper
INFO - 2018-02-02 07:06:48 --> Database Driver Class Initialized
DEBUG - 2018-02-02 07:06:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 07:06:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 07:06:48 --> Form Validation Class Initialized
INFO - 2018-02-02 07:06:48 --> Model Class Initialized
INFO - 2018-02-02 07:06:48 --> Controller Class Initialized
INFO - 2018-02-02 07:06:48 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-02 07:06:48 --> Final output sent to browser
DEBUG - 2018-02-02 07:06:48 --> Total execution time: 0.0531
INFO - 2018-02-02 07:06:49 --> Config Class Initialized
INFO - 2018-02-02 07:06:49 --> Hooks Class Initialized
DEBUG - 2018-02-02 07:06:49 --> UTF-8 Support Enabled
INFO - 2018-02-02 07:06:49 --> Utf8 Class Initialized
INFO - 2018-02-02 07:06:49 --> URI Class Initialized
INFO - 2018-02-02 07:06:49 --> Router Class Initialized
INFO - 2018-02-02 07:06:49 --> Output Class Initialized
INFO - 2018-02-02 07:06:49 --> Security Class Initialized
DEBUG - 2018-02-02 07:06:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 07:06:49 --> Input Class Initialized
INFO - 2018-02-02 07:06:49 --> Language Class Initialized
INFO - 2018-02-02 07:06:49 --> Loader Class Initialized
INFO - 2018-02-02 07:06:49 --> Helper loaded: url_helper
INFO - 2018-02-02 07:06:49 --> Helper loaded: form_helper
INFO - 2018-02-02 07:06:49 --> Database Driver Class Initialized
DEBUG - 2018-02-02 07:06:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 07:06:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 07:06:49 --> Form Validation Class Initialized
INFO - 2018-02-02 07:06:49 --> Model Class Initialized
INFO - 2018-02-02 07:06:49 --> Controller Class Initialized
INFO - 2018-02-02 07:06:49 --> Model Class Initialized
INFO - 2018-02-02 07:06:49 --> Model Class Initialized
INFO - 2018-02-02 07:06:49 --> Model Class Initialized
INFO - 2018-02-02 07:06:49 --> Model Class Initialized
DEBUG - 2018-02-02 07:06:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 07:07:33 --> Config Class Initialized
INFO - 2018-02-02 07:07:33 --> Hooks Class Initialized
DEBUG - 2018-02-02 07:07:33 --> UTF-8 Support Enabled
INFO - 2018-02-02 07:07:33 --> Utf8 Class Initialized
INFO - 2018-02-02 07:07:33 --> URI Class Initialized
INFO - 2018-02-02 07:07:33 --> Router Class Initialized
INFO - 2018-02-02 07:07:33 --> Output Class Initialized
INFO - 2018-02-02 07:07:33 --> Security Class Initialized
DEBUG - 2018-02-02 07:07:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 07:07:33 --> Input Class Initialized
INFO - 2018-02-02 07:07:33 --> Language Class Initialized
INFO - 2018-02-02 07:07:33 --> Loader Class Initialized
INFO - 2018-02-02 07:07:33 --> Helper loaded: url_helper
INFO - 2018-02-02 07:07:33 --> Helper loaded: form_helper
INFO - 2018-02-02 07:07:33 --> Database Driver Class Initialized
DEBUG - 2018-02-02 07:07:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 07:07:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 07:07:33 --> Form Validation Class Initialized
INFO - 2018-02-02 07:07:33 --> Model Class Initialized
INFO - 2018-02-02 07:07:33 --> Controller Class Initialized
INFO - 2018-02-02 07:07:33 --> Model Class Initialized
INFO - 2018-02-02 07:07:33 --> Model Class Initialized
INFO - 2018-02-02 07:07:33 --> Model Class Initialized
INFO - 2018-02-02 07:07:33 --> Model Class Initialized
DEBUG - 2018-02-02 07:07:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 07:07:33 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-02 07:07:33 --> Final output sent to browser
DEBUG - 2018-02-02 07:07:33 --> Total execution time: 0.0398
INFO - 2018-02-02 07:07:33 --> Config Class Initialized
INFO - 2018-02-02 07:07:33 --> Hooks Class Initialized
DEBUG - 2018-02-02 07:07:33 --> UTF-8 Support Enabled
INFO - 2018-02-02 07:07:33 --> Utf8 Class Initialized
INFO - 2018-02-02 07:07:33 --> URI Class Initialized
INFO - 2018-02-02 07:07:33 --> Router Class Initialized
INFO - 2018-02-02 07:07:33 --> Output Class Initialized
INFO - 2018-02-02 07:07:33 --> Security Class Initialized
DEBUG - 2018-02-02 07:07:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 07:07:33 --> Input Class Initialized
INFO - 2018-02-02 07:07:33 --> Language Class Initialized
INFO - 2018-02-02 07:07:33 --> Loader Class Initialized
INFO - 2018-02-02 07:07:33 --> Helper loaded: url_helper
INFO - 2018-02-02 07:07:33 --> Helper loaded: form_helper
INFO - 2018-02-02 07:07:33 --> Database Driver Class Initialized
DEBUG - 2018-02-02 07:07:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 07:07:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 07:07:33 --> Form Validation Class Initialized
INFO - 2018-02-02 07:07:33 --> Model Class Initialized
INFO - 2018-02-02 07:07:33 --> Controller Class Initialized
INFO - 2018-02-02 07:07:33 --> Model Class Initialized
INFO - 2018-02-02 07:07:33 --> Model Class Initialized
INFO - 2018-02-02 07:07:33 --> Model Class Initialized
INFO - 2018-02-02 07:07:33 --> Model Class Initialized
DEBUG - 2018-02-02 07:07:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 07:07:34 --> Config Class Initialized
INFO - 2018-02-02 07:07:34 --> Hooks Class Initialized
DEBUG - 2018-02-02 07:07:34 --> UTF-8 Support Enabled
INFO - 2018-02-02 07:07:34 --> Utf8 Class Initialized
INFO - 2018-02-02 07:07:34 --> URI Class Initialized
INFO - 2018-02-02 07:07:34 --> Router Class Initialized
INFO - 2018-02-02 07:07:34 --> Output Class Initialized
INFO - 2018-02-02 07:07:34 --> Security Class Initialized
DEBUG - 2018-02-02 07:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 07:07:34 --> Input Class Initialized
INFO - 2018-02-02 07:07:34 --> Language Class Initialized
INFO - 2018-02-02 07:07:34 --> Loader Class Initialized
INFO - 2018-02-02 07:07:34 --> Helper loaded: url_helper
INFO - 2018-02-02 07:07:34 --> Helper loaded: form_helper
INFO - 2018-02-02 07:07:34 --> Database Driver Class Initialized
DEBUG - 2018-02-02 07:07:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 07:07:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 07:07:34 --> Form Validation Class Initialized
INFO - 2018-02-02 07:07:34 --> Model Class Initialized
INFO - 2018-02-02 07:07:34 --> Controller Class Initialized
INFO - 2018-02-02 07:07:34 --> Model Class Initialized
INFO - 2018-02-02 07:07:34 --> Model Class Initialized
DEBUG - 2018-02-02 07:07:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 07:07:34 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-02 07:07:34 --> Final output sent to browser
DEBUG - 2018-02-02 07:07:34 --> Total execution time: 0.0390
INFO - 2018-02-02 07:07:34 --> Config Class Initialized
INFO - 2018-02-02 07:07:34 --> Hooks Class Initialized
DEBUG - 2018-02-02 07:07:34 --> UTF-8 Support Enabled
INFO - 2018-02-02 07:07:34 --> Utf8 Class Initialized
INFO - 2018-02-02 07:07:34 --> URI Class Initialized
INFO - 2018-02-02 07:07:34 --> Router Class Initialized
INFO - 2018-02-02 07:07:34 --> Output Class Initialized
INFO - 2018-02-02 07:07:34 --> Security Class Initialized
DEBUG - 2018-02-02 07:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 07:07:34 --> Input Class Initialized
INFO - 2018-02-02 07:07:34 --> Language Class Initialized
INFO - 2018-02-02 07:07:34 --> Loader Class Initialized
INFO - 2018-02-02 07:07:34 --> Helper loaded: url_helper
INFO - 2018-02-02 07:07:34 --> Helper loaded: form_helper
INFO - 2018-02-02 07:07:34 --> Database Driver Class Initialized
DEBUG - 2018-02-02 07:07:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 07:07:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 07:07:34 --> Form Validation Class Initialized
INFO - 2018-02-02 07:07:34 --> Model Class Initialized
INFO - 2018-02-02 07:07:34 --> Controller Class Initialized
INFO - 2018-02-02 07:07:34 --> Model Class Initialized
INFO - 2018-02-02 07:07:34 --> Model Class Initialized
DEBUG - 2018-02-02 07:07:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 07:07:35 --> Config Class Initialized
INFO - 2018-02-02 07:07:35 --> Hooks Class Initialized
DEBUG - 2018-02-02 07:07:35 --> UTF-8 Support Enabled
INFO - 2018-02-02 07:07:35 --> Utf8 Class Initialized
INFO - 2018-02-02 07:07:35 --> URI Class Initialized
INFO - 2018-02-02 07:07:35 --> Router Class Initialized
INFO - 2018-02-02 07:07:35 --> Output Class Initialized
INFO - 2018-02-02 07:07:35 --> Security Class Initialized
DEBUG - 2018-02-02 07:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 07:07:35 --> Input Class Initialized
INFO - 2018-02-02 07:07:35 --> Language Class Initialized
INFO - 2018-02-02 07:07:35 --> Loader Class Initialized
INFO - 2018-02-02 07:07:35 --> Helper loaded: url_helper
INFO - 2018-02-02 07:07:35 --> Helper loaded: form_helper
INFO - 2018-02-02 07:07:35 --> Database Driver Class Initialized
DEBUG - 2018-02-02 07:07:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 07:07:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 07:07:35 --> Form Validation Class Initialized
INFO - 2018-02-02 07:07:35 --> Model Class Initialized
INFO - 2018-02-02 07:07:35 --> Controller Class Initialized
INFO - 2018-02-02 07:07:35 --> Model Class Initialized
INFO - 2018-02-02 07:07:35 --> Model Class Initialized
DEBUG - 2018-02-02 07:07:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 07:07:35 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-02 07:07:35 --> Final output sent to browser
DEBUG - 2018-02-02 07:07:35 --> Total execution time: 0.0458
INFO - 2018-02-02 07:07:35 --> Config Class Initialized
INFO - 2018-02-02 07:07:35 --> Hooks Class Initialized
DEBUG - 2018-02-02 07:07:35 --> UTF-8 Support Enabled
INFO - 2018-02-02 07:07:35 --> Utf8 Class Initialized
INFO - 2018-02-02 07:07:35 --> URI Class Initialized
INFO - 2018-02-02 07:07:35 --> Router Class Initialized
INFO - 2018-02-02 07:07:35 --> Output Class Initialized
INFO - 2018-02-02 07:07:35 --> Security Class Initialized
DEBUG - 2018-02-02 07:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 07:07:35 --> Input Class Initialized
INFO - 2018-02-02 07:07:35 --> Language Class Initialized
INFO - 2018-02-02 07:07:35 --> Loader Class Initialized
INFO - 2018-02-02 07:07:35 --> Helper loaded: url_helper
INFO - 2018-02-02 07:07:35 --> Helper loaded: form_helper
INFO - 2018-02-02 07:07:35 --> Database Driver Class Initialized
DEBUG - 2018-02-02 07:07:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 07:07:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 07:07:35 --> Form Validation Class Initialized
INFO - 2018-02-02 07:07:35 --> Model Class Initialized
INFO - 2018-02-02 07:07:35 --> Controller Class Initialized
INFO - 2018-02-02 07:07:35 --> Model Class Initialized
INFO - 2018-02-02 07:07:35 --> Model Class Initialized
DEBUG - 2018-02-02 07:07:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 07:07:35 --> Config Class Initialized
INFO - 2018-02-02 07:07:35 --> Hooks Class Initialized
DEBUG - 2018-02-02 07:07:35 --> UTF-8 Support Enabled
INFO - 2018-02-02 07:07:35 --> Utf8 Class Initialized
INFO - 2018-02-02 07:07:35 --> URI Class Initialized
INFO - 2018-02-02 07:07:35 --> Router Class Initialized
INFO - 2018-02-02 07:07:35 --> Output Class Initialized
INFO - 2018-02-02 07:07:35 --> Security Class Initialized
DEBUG - 2018-02-02 07:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 07:07:35 --> Input Class Initialized
INFO - 2018-02-02 07:07:35 --> Language Class Initialized
INFO - 2018-02-02 07:07:35 --> Loader Class Initialized
INFO - 2018-02-02 07:07:35 --> Helper loaded: url_helper
INFO - 2018-02-02 07:07:35 --> Helper loaded: form_helper
INFO - 2018-02-02 07:07:35 --> Database Driver Class Initialized
DEBUG - 2018-02-02 07:07:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 07:07:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 07:07:35 --> Form Validation Class Initialized
INFO - 2018-02-02 07:07:35 --> Model Class Initialized
INFO - 2018-02-02 07:07:35 --> Controller Class Initialized
INFO - 2018-02-02 07:07:35 --> Model Class Initialized
INFO - 2018-02-02 07:07:35 --> Model Class Initialized
INFO - 2018-02-02 07:07:35 --> Model Class Initialized
INFO - 2018-02-02 07:07:35 --> Model Class Initialized
DEBUG - 2018-02-02 07:07:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 07:07:35 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-02 07:07:36 --> Final output sent to browser
DEBUG - 2018-02-02 07:07:36 --> Total execution time: 0.0544
INFO - 2018-02-02 07:07:36 --> Config Class Initialized
INFO - 2018-02-02 07:07:36 --> Hooks Class Initialized
DEBUG - 2018-02-02 07:07:36 --> UTF-8 Support Enabled
INFO - 2018-02-02 07:07:36 --> Utf8 Class Initialized
INFO - 2018-02-02 07:07:36 --> URI Class Initialized
INFO - 2018-02-02 07:07:36 --> Router Class Initialized
INFO - 2018-02-02 07:07:36 --> Output Class Initialized
INFO - 2018-02-02 07:07:36 --> Security Class Initialized
DEBUG - 2018-02-02 07:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 07:07:36 --> Input Class Initialized
INFO - 2018-02-02 07:07:36 --> Language Class Initialized
INFO - 2018-02-02 07:07:36 --> Loader Class Initialized
INFO - 2018-02-02 07:07:36 --> Helper loaded: url_helper
INFO - 2018-02-02 07:07:36 --> Helper loaded: form_helper
INFO - 2018-02-02 07:07:36 --> Database Driver Class Initialized
DEBUG - 2018-02-02 07:07:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 07:07:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 07:07:36 --> Form Validation Class Initialized
INFO - 2018-02-02 07:07:36 --> Model Class Initialized
INFO - 2018-02-02 07:07:36 --> Controller Class Initialized
INFO - 2018-02-02 07:07:36 --> Model Class Initialized
INFO - 2018-02-02 07:07:36 --> Model Class Initialized
DEBUG - 2018-02-02 07:07:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 07:07:36 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-02 07:07:36 --> Final output sent to browser
DEBUG - 2018-02-02 07:07:36 --> Total execution time: 0.0475
INFO - 2018-02-02 07:07:36 --> Config Class Initialized
INFO - 2018-02-02 07:07:36 --> Hooks Class Initialized
DEBUG - 2018-02-02 07:07:36 --> UTF-8 Support Enabled
INFO - 2018-02-02 07:07:36 --> Utf8 Class Initialized
INFO - 2018-02-02 07:07:36 --> URI Class Initialized
INFO - 2018-02-02 07:07:36 --> Router Class Initialized
INFO - 2018-02-02 07:07:36 --> Output Class Initialized
INFO - 2018-02-02 07:07:36 --> Security Class Initialized
DEBUG - 2018-02-02 07:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 07:07:36 --> Input Class Initialized
INFO - 2018-02-02 07:07:36 --> Language Class Initialized
INFO - 2018-02-02 07:07:36 --> Loader Class Initialized
INFO - 2018-02-02 07:07:36 --> Helper loaded: url_helper
INFO - 2018-02-02 07:07:36 --> Helper loaded: form_helper
INFO - 2018-02-02 07:07:36 --> Database Driver Class Initialized
DEBUG - 2018-02-02 07:07:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 07:07:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 07:07:36 --> Form Validation Class Initialized
INFO - 2018-02-02 07:07:36 --> Model Class Initialized
INFO - 2018-02-02 07:07:36 --> Controller Class Initialized
INFO - 2018-02-02 07:07:36 --> Model Class Initialized
INFO - 2018-02-02 07:07:36 --> Model Class Initialized
DEBUG - 2018-02-02 07:07:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 07:07:38 --> Config Class Initialized
INFO - 2018-02-02 07:07:38 --> Hooks Class Initialized
DEBUG - 2018-02-02 07:07:38 --> UTF-8 Support Enabled
INFO - 2018-02-02 07:07:38 --> Utf8 Class Initialized
INFO - 2018-02-02 07:07:38 --> URI Class Initialized
INFO - 2018-02-02 07:07:38 --> Router Class Initialized
INFO - 2018-02-02 07:07:38 --> Output Class Initialized
INFO - 2018-02-02 07:07:38 --> Security Class Initialized
DEBUG - 2018-02-02 07:07:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 07:07:38 --> Input Class Initialized
INFO - 2018-02-02 07:07:38 --> Language Class Initialized
INFO - 2018-02-02 07:07:38 --> Loader Class Initialized
INFO - 2018-02-02 07:07:38 --> Helper loaded: url_helper
INFO - 2018-02-02 07:07:38 --> Helper loaded: form_helper
INFO - 2018-02-02 07:07:38 --> Database Driver Class Initialized
DEBUG - 2018-02-02 07:07:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 07:07:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 07:07:38 --> Form Validation Class Initialized
INFO - 2018-02-02 07:07:38 --> Model Class Initialized
INFO - 2018-02-02 07:07:38 --> Controller Class Initialized
INFO - 2018-02-02 07:07:38 --> Model Class Initialized
INFO - 2018-02-02 07:07:38 --> Model Class Initialized
DEBUG - 2018-02-02 07:07:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 07:07:38 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-02 07:07:38 --> Final output sent to browser
DEBUG - 2018-02-02 07:07:38 --> Total execution time: 0.0373
INFO - 2018-02-02 07:07:38 --> Config Class Initialized
INFO - 2018-02-02 07:07:38 --> Hooks Class Initialized
DEBUG - 2018-02-02 07:07:38 --> UTF-8 Support Enabled
INFO - 2018-02-02 07:07:38 --> Utf8 Class Initialized
INFO - 2018-02-02 07:07:38 --> URI Class Initialized
INFO - 2018-02-02 07:07:38 --> Router Class Initialized
INFO - 2018-02-02 07:07:38 --> Output Class Initialized
INFO - 2018-02-02 07:07:38 --> Security Class Initialized
DEBUG - 2018-02-02 07:07:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 07:07:38 --> Input Class Initialized
INFO - 2018-02-02 07:07:38 --> Language Class Initialized
INFO - 2018-02-02 07:07:38 --> Loader Class Initialized
INFO - 2018-02-02 07:07:38 --> Helper loaded: url_helper
INFO - 2018-02-02 07:07:38 --> Helper loaded: form_helper
INFO - 2018-02-02 07:07:38 --> Database Driver Class Initialized
DEBUG - 2018-02-02 07:07:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 07:07:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 07:07:38 --> Form Validation Class Initialized
INFO - 2018-02-02 07:07:38 --> Model Class Initialized
INFO - 2018-02-02 07:07:38 --> Controller Class Initialized
INFO - 2018-02-02 07:07:38 --> Model Class Initialized
INFO - 2018-02-02 07:07:38 --> Model Class Initialized
DEBUG - 2018-02-02 07:07:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 07:07:38 --> Config Class Initialized
INFO - 2018-02-02 07:07:38 --> Hooks Class Initialized
DEBUG - 2018-02-02 07:07:38 --> UTF-8 Support Enabled
INFO - 2018-02-02 07:07:38 --> Utf8 Class Initialized
INFO - 2018-02-02 07:07:38 --> URI Class Initialized
INFO - 2018-02-02 07:07:38 --> Router Class Initialized
INFO - 2018-02-02 07:07:38 --> Output Class Initialized
INFO - 2018-02-02 07:07:38 --> Security Class Initialized
DEBUG - 2018-02-02 07:07:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 07:07:38 --> Input Class Initialized
INFO - 2018-02-02 07:07:38 --> Language Class Initialized
INFO - 2018-02-02 07:07:38 --> Loader Class Initialized
INFO - 2018-02-02 07:07:38 --> Helper loaded: url_helper
INFO - 2018-02-02 07:07:38 --> Helper loaded: form_helper
INFO - 2018-02-02 07:07:39 --> Database Driver Class Initialized
DEBUG - 2018-02-02 07:07:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 07:07:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 07:07:39 --> Form Validation Class Initialized
INFO - 2018-02-02 07:07:39 --> Model Class Initialized
INFO - 2018-02-02 07:07:39 --> Controller Class Initialized
INFO - 2018-02-02 07:07:39 --> Model Class Initialized
INFO - 2018-02-02 07:07:39 --> Model Class Initialized
INFO - 2018-02-02 07:07:39 --> Model Class Initialized
INFO - 2018-02-02 07:07:39 --> Model Class Initialized
DEBUG - 2018-02-02 07:07:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 07:07:39 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-02 07:07:39 --> Final output sent to browser
DEBUG - 2018-02-02 07:07:39 --> Total execution time: 0.0461
INFO - 2018-02-02 07:07:39 --> Config Class Initialized
INFO - 2018-02-02 07:07:39 --> Hooks Class Initialized
DEBUG - 2018-02-02 07:07:39 --> UTF-8 Support Enabled
INFO - 2018-02-02 07:07:39 --> Utf8 Class Initialized
INFO - 2018-02-02 07:07:39 --> URI Class Initialized
INFO - 2018-02-02 07:07:39 --> Router Class Initialized
INFO - 2018-02-02 07:07:39 --> Output Class Initialized
INFO - 2018-02-02 07:07:39 --> Security Class Initialized
DEBUG - 2018-02-02 07:07:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 07:07:39 --> Input Class Initialized
INFO - 2018-02-02 07:07:39 --> Language Class Initialized
INFO - 2018-02-02 07:07:39 --> Loader Class Initialized
INFO - 2018-02-02 07:07:39 --> Helper loaded: url_helper
INFO - 2018-02-02 07:07:39 --> Helper loaded: form_helper
INFO - 2018-02-02 07:07:39 --> Database Driver Class Initialized
DEBUG - 2018-02-02 07:07:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 07:07:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 07:07:39 --> Form Validation Class Initialized
INFO - 2018-02-02 07:07:39 --> Model Class Initialized
INFO - 2018-02-02 07:07:39 --> Controller Class Initialized
INFO - 2018-02-02 07:07:39 --> Model Class Initialized
INFO - 2018-02-02 07:07:39 --> Model Class Initialized
INFO - 2018-02-02 07:07:39 --> Model Class Initialized
INFO - 2018-02-02 07:07:39 --> Model Class Initialized
DEBUG - 2018-02-02 07:07:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 07:07:40 --> Config Class Initialized
INFO - 2018-02-02 07:07:40 --> Hooks Class Initialized
DEBUG - 2018-02-02 07:07:40 --> UTF-8 Support Enabled
INFO - 2018-02-02 07:07:40 --> Utf8 Class Initialized
INFO - 2018-02-02 07:07:40 --> URI Class Initialized
INFO - 2018-02-02 07:07:40 --> Router Class Initialized
INFO - 2018-02-02 07:07:40 --> Output Class Initialized
INFO - 2018-02-02 07:07:40 --> Security Class Initialized
DEBUG - 2018-02-02 07:07:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 07:07:40 --> Input Class Initialized
INFO - 2018-02-02 07:07:40 --> Language Class Initialized
INFO - 2018-02-02 07:07:40 --> Loader Class Initialized
INFO - 2018-02-02 07:07:40 --> Helper loaded: url_helper
INFO - 2018-02-02 07:07:40 --> Helper loaded: form_helper
INFO - 2018-02-02 07:07:40 --> Database Driver Class Initialized
DEBUG - 2018-02-02 07:07:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 07:07:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 07:07:40 --> Form Validation Class Initialized
INFO - 2018-02-02 07:07:40 --> Model Class Initialized
INFO - 2018-02-02 07:07:40 --> Controller Class Initialized
INFO - 2018-02-02 07:07:40 --> Model Class Initialized
INFO - 2018-02-02 07:07:40 --> Model Class Initialized
DEBUG - 2018-02-02 07:07:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 07:07:40 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-02 07:07:40 --> Final output sent to browser
DEBUG - 2018-02-02 07:07:40 --> Total execution time: 0.0415
INFO - 2018-02-02 07:07:40 --> Config Class Initialized
INFO - 2018-02-02 07:07:40 --> Hooks Class Initialized
DEBUG - 2018-02-02 07:07:40 --> UTF-8 Support Enabled
INFO - 2018-02-02 07:07:40 --> Utf8 Class Initialized
INFO - 2018-02-02 07:07:40 --> URI Class Initialized
INFO - 2018-02-02 07:07:40 --> Router Class Initialized
INFO - 2018-02-02 07:07:40 --> Output Class Initialized
INFO - 2018-02-02 07:07:40 --> Security Class Initialized
DEBUG - 2018-02-02 07:07:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 07:07:40 --> Input Class Initialized
INFO - 2018-02-02 07:07:40 --> Language Class Initialized
INFO - 2018-02-02 07:07:40 --> Loader Class Initialized
INFO - 2018-02-02 07:07:40 --> Helper loaded: url_helper
INFO - 2018-02-02 07:07:40 --> Helper loaded: form_helper
INFO - 2018-02-02 07:07:40 --> Database Driver Class Initialized
DEBUG - 2018-02-02 07:07:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 07:07:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 07:07:40 --> Form Validation Class Initialized
INFO - 2018-02-02 07:07:40 --> Model Class Initialized
INFO - 2018-02-02 07:07:40 --> Controller Class Initialized
INFO - 2018-02-02 07:07:40 --> Model Class Initialized
INFO - 2018-02-02 07:07:40 --> Model Class Initialized
DEBUG - 2018-02-02 07:07:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 07:07:59 --> Config Class Initialized
INFO - 2018-02-02 07:07:59 --> Hooks Class Initialized
DEBUG - 2018-02-02 07:07:59 --> UTF-8 Support Enabled
INFO - 2018-02-02 07:07:59 --> Utf8 Class Initialized
INFO - 2018-02-02 07:07:59 --> URI Class Initialized
INFO - 2018-02-02 07:07:59 --> Router Class Initialized
INFO - 2018-02-02 07:07:59 --> Output Class Initialized
INFO - 2018-02-02 07:07:59 --> Security Class Initialized
DEBUG - 2018-02-02 07:07:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 07:07:59 --> Input Class Initialized
INFO - 2018-02-02 07:07:59 --> Language Class Initialized
INFO - 2018-02-02 07:07:59 --> Loader Class Initialized
INFO - 2018-02-02 07:07:59 --> Helper loaded: url_helper
INFO - 2018-02-02 07:07:59 --> Helper loaded: form_helper
INFO - 2018-02-02 07:07:59 --> Database Driver Class Initialized
DEBUG - 2018-02-02 07:07:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 07:07:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 07:07:59 --> Form Validation Class Initialized
INFO - 2018-02-02 07:07:59 --> Model Class Initialized
INFO - 2018-02-02 07:07:59 --> Controller Class Initialized
INFO - 2018-02-02 07:07:59 --> Model Class Initialized
DEBUG - 2018-02-02 07:07:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 07:07:59 --> Config Class Initialized
INFO - 2018-02-02 07:07:59 --> Hooks Class Initialized
DEBUG - 2018-02-02 07:07:59 --> UTF-8 Support Enabled
INFO - 2018-02-02 07:07:59 --> Utf8 Class Initialized
INFO - 2018-02-02 07:07:59 --> URI Class Initialized
INFO - 2018-02-02 07:07:59 --> Router Class Initialized
INFO - 2018-02-02 07:07:59 --> Output Class Initialized
INFO - 2018-02-02 07:07:59 --> Security Class Initialized
DEBUG - 2018-02-02 07:07:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 07:07:59 --> Input Class Initialized
INFO - 2018-02-02 07:07:59 --> Language Class Initialized
INFO - 2018-02-02 07:07:59 --> Loader Class Initialized
INFO - 2018-02-02 07:07:59 --> Helper loaded: url_helper
INFO - 2018-02-02 07:07:59 --> Helper loaded: form_helper
INFO - 2018-02-02 07:07:59 --> Database Driver Class Initialized
DEBUG - 2018-02-02 07:07:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 07:07:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 07:07:59 --> Form Validation Class Initialized
INFO - 2018-02-02 07:07:59 --> Model Class Initialized
INFO - 2018-02-02 07:07:59 --> Controller Class Initialized
INFO - 2018-02-02 07:07:59 --> Model Class Initialized
DEBUG - 2018-02-02 07:07:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 07:07:59 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-02 07:07:59 --> Final output sent to browser
DEBUG - 2018-02-02 07:07:59 --> Total execution time: 0.0501
INFO - 2018-02-02 07:08:01 --> Config Class Initialized
INFO - 2018-02-02 07:08:01 --> Hooks Class Initialized
DEBUG - 2018-02-02 07:08:01 --> UTF-8 Support Enabled
INFO - 2018-02-02 07:08:01 --> Utf8 Class Initialized
INFO - 2018-02-02 07:08:01 --> URI Class Initialized
INFO - 2018-02-02 07:08:01 --> Router Class Initialized
INFO - 2018-02-02 07:08:01 --> Output Class Initialized
INFO - 2018-02-02 07:08:01 --> Security Class Initialized
DEBUG - 2018-02-02 07:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 07:08:01 --> Input Class Initialized
INFO - 2018-02-02 07:08:01 --> Language Class Initialized
INFO - 2018-02-02 07:08:01 --> Loader Class Initialized
INFO - 2018-02-02 07:08:01 --> Helper loaded: url_helper
INFO - 2018-02-02 07:08:01 --> Helper loaded: form_helper
INFO - 2018-02-02 07:08:01 --> Database Driver Class Initialized
DEBUG - 2018-02-02 07:08:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 07:08:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 07:08:01 --> Form Validation Class Initialized
INFO - 2018-02-02 07:08:01 --> Model Class Initialized
INFO - 2018-02-02 07:08:01 --> Controller Class Initialized
INFO - 2018-02-02 07:08:01 --> Model Class Initialized
DEBUG - 2018-02-02 07:08:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-02-02 07:08:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-02 07:08:01 --> Config Class Initialized
INFO - 2018-02-02 07:08:01 --> Hooks Class Initialized
DEBUG - 2018-02-02 07:08:01 --> UTF-8 Support Enabled
INFO - 2018-02-02 07:08:01 --> Utf8 Class Initialized
INFO - 2018-02-02 07:08:01 --> URI Class Initialized
DEBUG - 2018-02-02 07:08:01 --> No URI present. Default controller set.
INFO - 2018-02-02 07:08:01 --> Router Class Initialized
INFO - 2018-02-02 07:08:01 --> Output Class Initialized
INFO - 2018-02-02 07:08:01 --> Security Class Initialized
DEBUG - 2018-02-02 07:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 07:08:01 --> Input Class Initialized
INFO - 2018-02-02 07:08:01 --> Language Class Initialized
INFO - 2018-02-02 07:08:01 --> Loader Class Initialized
INFO - 2018-02-02 07:08:01 --> Helper loaded: url_helper
INFO - 2018-02-02 07:08:01 --> Helper loaded: form_helper
INFO - 2018-02-02 07:08:01 --> Database Driver Class Initialized
DEBUG - 2018-02-02 07:08:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 07:08:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 07:08:01 --> Form Validation Class Initialized
INFO - 2018-02-02 07:08:01 --> Model Class Initialized
INFO - 2018-02-02 07:08:01 --> Controller Class Initialized
INFO - 2018-02-02 07:08:01 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-02-02 07:08:01 --> Final output sent to browser
DEBUG - 2018-02-02 07:08:01 --> Total execution time: 0.0525
INFO - 2018-02-02 07:08:01 --> Config Class Initialized
INFO - 2018-02-02 07:08:01 --> Hooks Class Initialized
DEBUG - 2018-02-02 07:08:01 --> UTF-8 Support Enabled
INFO - 2018-02-02 07:08:01 --> Utf8 Class Initialized
INFO - 2018-02-02 07:08:01 --> URI Class Initialized
INFO - 2018-02-02 07:08:01 --> Router Class Initialized
INFO - 2018-02-02 07:08:01 --> Output Class Initialized
INFO - 2018-02-02 07:08:01 --> Security Class Initialized
DEBUG - 2018-02-02 07:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-02 07:08:01 --> Input Class Initialized
INFO - 2018-02-02 07:08:01 --> Language Class Initialized
INFO - 2018-02-02 07:08:01 --> Loader Class Initialized
INFO - 2018-02-02 07:08:01 --> Helper loaded: url_helper
INFO - 2018-02-02 07:08:01 --> Helper loaded: form_helper
INFO - 2018-02-02 07:08:01 --> Database Driver Class Initialized
DEBUG - 2018-02-02 07:08:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-02 07:08:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-02 07:08:01 --> Form Validation Class Initialized
INFO - 2018-02-02 07:08:01 --> Model Class Initialized
INFO - 2018-02-02 07:08:01 --> Controller Class Initialized
INFO - 2018-02-02 07:08:01 --> Model Class Initialized
INFO - 2018-02-02 07:08:01 --> Model Class Initialized
INFO - 2018-02-02 07:08:01 --> Model Class Initialized
INFO - 2018-02-02 07:08:01 --> Model Class Initialized
DEBUG - 2018-02-02 07:08:01 --> Form_validation class already loaded. Second attempt ignored.
