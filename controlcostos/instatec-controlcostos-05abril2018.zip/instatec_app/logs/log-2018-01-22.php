<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-01-22 06:10:08 --> Config Class Initialized
INFO - 2018-01-22 06:10:08 --> Hooks Class Initialized
DEBUG - 2018-01-22 06:10:08 --> UTF-8 Support Enabled
INFO - 2018-01-22 06:10:08 --> Utf8 Class Initialized
INFO - 2018-01-22 06:10:08 --> URI Class Initialized
DEBUG - 2018-01-22 06:10:08 --> No URI present. Default controller set.
INFO - 2018-01-22 06:10:08 --> Router Class Initialized
INFO - 2018-01-22 06:10:08 --> Output Class Initialized
INFO - 2018-01-22 06:10:08 --> Security Class Initialized
DEBUG - 2018-01-22 06:10:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 06:10:08 --> Input Class Initialized
INFO - 2018-01-22 06:10:08 --> Language Class Initialized
INFO - 2018-01-22 06:10:08 --> Loader Class Initialized
INFO - 2018-01-22 06:10:08 --> Helper loaded: url_helper
INFO - 2018-01-22 06:10:08 --> Helper loaded: form_helper
INFO - 2018-01-22 06:10:08 --> Database Driver Class Initialized
ERROR - 2018-01-22 06:10:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'instatec_cc_user'@'localhost' (using password: YES) D:\xampp\htdocs\instateccr\controlcostos\instatec_sys\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2018-01-22 06:10:08 --> Unable to connect to the database
INFO - 2018-01-22 06:10:08 --> Language file loaded: language/english/db_lang.php
INFO - 2018-01-22 06:10:26 --> Config Class Initialized
INFO - 2018-01-22 06:10:26 --> Hooks Class Initialized
DEBUG - 2018-01-22 06:10:26 --> UTF-8 Support Enabled
INFO - 2018-01-22 06:10:26 --> Utf8 Class Initialized
INFO - 2018-01-22 06:10:26 --> URI Class Initialized
DEBUG - 2018-01-22 06:10:26 --> No URI present. Default controller set.
INFO - 2018-01-22 06:10:26 --> Router Class Initialized
INFO - 2018-01-22 06:10:26 --> Output Class Initialized
INFO - 2018-01-22 06:10:26 --> Security Class Initialized
DEBUG - 2018-01-22 06:10:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 06:10:26 --> Input Class Initialized
INFO - 2018-01-22 06:10:26 --> Language Class Initialized
INFO - 2018-01-22 06:10:26 --> Loader Class Initialized
INFO - 2018-01-22 06:10:26 --> Helper loaded: url_helper
INFO - 2018-01-22 06:10:26 --> Helper loaded: form_helper
INFO - 2018-01-22 06:10:26 --> Database Driver Class Initialized
ERROR - 2018-01-22 06:10:26 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'instatec' D:\xampp\htdocs\instateccr\controlcostos\instatec_sys\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2018-01-22 06:10:26 --> Unable to connect to the database
INFO - 2018-01-22 06:10:26 --> Language file loaded: language/english/db_lang.php
INFO - 2018-01-22 06:10:57 --> Config Class Initialized
INFO - 2018-01-22 06:10:57 --> Hooks Class Initialized
DEBUG - 2018-01-22 06:10:57 --> UTF-8 Support Enabled
INFO - 2018-01-22 06:10:57 --> Utf8 Class Initialized
INFO - 2018-01-22 06:10:57 --> URI Class Initialized
DEBUG - 2018-01-22 06:10:57 --> No URI present. Default controller set.
INFO - 2018-01-22 06:10:57 --> Router Class Initialized
INFO - 2018-01-22 06:10:57 --> Output Class Initialized
INFO - 2018-01-22 06:10:57 --> Security Class Initialized
DEBUG - 2018-01-22 06:10:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 06:10:57 --> Input Class Initialized
INFO - 2018-01-22 06:10:57 --> Language Class Initialized
INFO - 2018-01-22 06:10:57 --> Loader Class Initialized
INFO - 2018-01-22 06:10:57 --> Helper loaded: url_helper
INFO - 2018-01-22 06:10:57 --> Helper loaded: form_helper
INFO - 2018-01-22 06:10:57 --> Database Driver Class Initialized
DEBUG - 2018-01-22 06:10:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 06:10:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 06:10:57 --> Form Validation Class Initialized
INFO - 2018-01-22 06:10:57 --> Model Class Initialized
INFO - 2018-01-22 06:10:57 --> Controller Class Initialized
INFO - 2018-01-22 06:10:57 --> Config Class Initialized
INFO - 2018-01-22 06:10:57 --> Hooks Class Initialized
DEBUG - 2018-01-22 06:10:57 --> UTF-8 Support Enabled
INFO - 2018-01-22 06:10:57 --> Utf8 Class Initialized
INFO - 2018-01-22 06:10:57 --> URI Class Initialized
INFO - 2018-01-22 06:10:57 --> Router Class Initialized
INFO - 2018-01-22 06:10:57 --> Output Class Initialized
INFO - 2018-01-22 06:10:57 --> Security Class Initialized
DEBUG - 2018-01-22 06:10:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 06:10:57 --> Input Class Initialized
INFO - 2018-01-22 06:10:57 --> Language Class Initialized
INFO - 2018-01-22 06:10:57 --> Loader Class Initialized
INFO - 2018-01-22 06:10:57 --> Helper loaded: url_helper
INFO - 2018-01-22 06:10:57 --> Helper loaded: form_helper
INFO - 2018-01-22 06:10:57 --> Database Driver Class Initialized
DEBUG - 2018-01-22 06:10:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 06:10:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 06:10:57 --> Form Validation Class Initialized
INFO - 2018-01-22 06:10:57 --> Model Class Initialized
INFO - 2018-01-22 06:10:57 --> Controller Class Initialized
INFO - 2018-01-22 06:10:57 --> Model Class Initialized
DEBUG - 2018-01-22 06:10:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-22 06:10:57 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-22 06:10:57 --> Final output sent to browser
DEBUG - 2018-01-22 06:10:57 --> Total execution time: 0.0512
INFO - 2018-01-22 06:11:02 --> Config Class Initialized
INFO - 2018-01-22 06:11:02 --> Hooks Class Initialized
DEBUG - 2018-01-22 06:11:02 --> UTF-8 Support Enabled
INFO - 2018-01-22 06:11:02 --> Utf8 Class Initialized
INFO - 2018-01-22 06:11:02 --> URI Class Initialized
INFO - 2018-01-22 06:11:02 --> Router Class Initialized
INFO - 2018-01-22 06:11:02 --> Output Class Initialized
INFO - 2018-01-22 06:11:02 --> Security Class Initialized
DEBUG - 2018-01-22 06:11:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 06:11:02 --> Input Class Initialized
INFO - 2018-01-22 06:11:02 --> Language Class Initialized
INFO - 2018-01-22 06:11:02 --> Loader Class Initialized
INFO - 2018-01-22 06:11:02 --> Helper loaded: url_helper
INFO - 2018-01-22 06:11:02 --> Helper loaded: form_helper
INFO - 2018-01-22 06:11:02 --> Database Driver Class Initialized
DEBUG - 2018-01-22 06:11:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 06:11:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 06:11:02 --> Form Validation Class Initialized
INFO - 2018-01-22 06:11:02 --> Model Class Initialized
INFO - 2018-01-22 06:11:02 --> Controller Class Initialized
INFO - 2018-01-22 06:11:02 --> Model Class Initialized
DEBUG - 2018-01-22 06:11:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-22 06:11:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-01-22 06:11:02 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-22 06:11:02 --> Final output sent to browser
DEBUG - 2018-01-22 06:11:02 --> Total execution time: 0.0723
INFO - 2018-01-22 06:11:44 --> Config Class Initialized
INFO - 2018-01-22 06:11:44 --> Hooks Class Initialized
DEBUG - 2018-01-22 06:11:44 --> UTF-8 Support Enabled
INFO - 2018-01-22 06:11:44 --> Utf8 Class Initialized
INFO - 2018-01-22 06:11:44 --> URI Class Initialized
INFO - 2018-01-22 06:11:44 --> Router Class Initialized
INFO - 2018-01-22 06:11:44 --> Output Class Initialized
INFO - 2018-01-22 06:11:44 --> Security Class Initialized
DEBUG - 2018-01-22 06:11:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 06:11:44 --> Input Class Initialized
INFO - 2018-01-22 06:11:44 --> Language Class Initialized
INFO - 2018-01-22 06:11:44 --> Loader Class Initialized
INFO - 2018-01-22 06:11:44 --> Helper loaded: url_helper
INFO - 2018-01-22 06:11:44 --> Helper loaded: form_helper
INFO - 2018-01-22 06:11:44 --> Database Driver Class Initialized
DEBUG - 2018-01-22 06:11:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 06:11:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 06:11:44 --> Form Validation Class Initialized
INFO - 2018-01-22 06:11:44 --> Model Class Initialized
INFO - 2018-01-22 06:11:44 --> Controller Class Initialized
INFO - 2018-01-22 06:11:44 --> Model Class Initialized
DEBUG - 2018-01-22 06:11:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-22 06:11:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-01-22 06:11:44 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-22 06:11:44 --> Final output sent to browser
DEBUG - 2018-01-22 06:11:44 --> Total execution time: 0.1056
INFO - 2018-01-22 06:12:02 --> Config Class Initialized
INFO - 2018-01-22 06:12:02 --> Hooks Class Initialized
DEBUG - 2018-01-22 06:12:02 --> UTF-8 Support Enabled
INFO - 2018-01-22 06:12:02 --> Utf8 Class Initialized
INFO - 2018-01-22 06:12:02 --> URI Class Initialized
INFO - 2018-01-22 06:12:02 --> Router Class Initialized
INFO - 2018-01-22 06:12:02 --> Output Class Initialized
INFO - 2018-01-22 06:12:02 --> Security Class Initialized
DEBUG - 2018-01-22 06:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 06:12:02 --> Input Class Initialized
INFO - 2018-01-22 06:12:02 --> Language Class Initialized
INFO - 2018-01-22 06:12:02 --> Loader Class Initialized
INFO - 2018-01-22 06:12:02 --> Helper loaded: url_helper
INFO - 2018-01-22 06:12:02 --> Helper loaded: form_helper
INFO - 2018-01-22 06:12:02 --> Database Driver Class Initialized
DEBUG - 2018-01-22 06:12:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 06:12:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 06:12:02 --> Form Validation Class Initialized
INFO - 2018-01-22 06:12:02 --> Model Class Initialized
INFO - 2018-01-22 06:12:02 --> Controller Class Initialized
INFO - 2018-01-22 06:12:02 --> Model Class Initialized
DEBUG - 2018-01-22 06:12:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-22 06:12:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-01-22 06:12:02 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-22 06:12:02 --> Final output sent to browser
DEBUG - 2018-01-22 06:12:02 --> Total execution time: 0.1863
INFO - 2018-01-22 06:12:46 --> Config Class Initialized
INFO - 2018-01-22 06:12:46 --> Hooks Class Initialized
DEBUG - 2018-01-22 06:12:46 --> UTF-8 Support Enabled
INFO - 2018-01-22 06:12:46 --> Utf8 Class Initialized
INFO - 2018-01-22 06:12:46 --> URI Class Initialized
DEBUG - 2018-01-22 06:12:46 --> No URI present. Default controller set.
INFO - 2018-01-22 06:12:46 --> Router Class Initialized
INFO - 2018-01-22 06:12:46 --> Output Class Initialized
INFO - 2018-01-22 06:12:46 --> Security Class Initialized
DEBUG - 2018-01-22 06:12:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 06:12:46 --> Input Class Initialized
INFO - 2018-01-22 06:12:46 --> Language Class Initialized
INFO - 2018-01-22 06:12:46 --> Loader Class Initialized
INFO - 2018-01-22 06:12:46 --> Helper loaded: url_helper
INFO - 2018-01-22 06:12:46 --> Helper loaded: form_helper
INFO - 2018-01-22 06:12:46 --> Database Driver Class Initialized
DEBUG - 2018-01-22 06:12:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 06:12:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 06:12:46 --> Form Validation Class Initialized
INFO - 2018-01-22 06:12:46 --> Model Class Initialized
INFO - 2018-01-22 06:12:46 --> Controller Class Initialized
INFO - 2018-01-22 06:12:46 --> Config Class Initialized
INFO - 2018-01-22 06:12:46 --> Hooks Class Initialized
DEBUG - 2018-01-22 06:12:46 --> UTF-8 Support Enabled
INFO - 2018-01-22 06:12:46 --> Utf8 Class Initialized
INFO - 2018-01-22 06:12:46 --> URI Class Initialized
INFO - 2018-01-22 06:12:46 --> Router Class Initialized
INFO - 2018-01-22 06:12:46 --> Output Class Initialized
INFO - 2018-01-22 06:12:46 --> Security Class Initialized
DEBUG - 2018-01-22 06:12:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 06:12:46 --> Input Class Initialized
INFO - 2018-01-22 06:12:46 --> Language Class Initialized
INFO - 2018-01-22 06:12:46 --> Loader Class Initialized
INFO - 2018-01-22 06:12:46 --> Helper loaded: url_helper
INFO - 2018-01-22 06:12:46 --> Helper loaded: form_helper
INFO - 2018-01-22 06:12:46 --> Database Driver Class Initialized
DEBUG - 2018-01-22 06:12:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 06:12:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 06:12:46 --> Form Validation Class Initialized
INFO - 2018-01-22 06:12:46 --> Model Class Initialized
INFO - 2018-01-22 06:12:46 --> Controller Class Initialized
INFO - 2018-01-22 06:12:46 --> Model Class Initialized
DEBUG - 2018-01-22 06:12:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-22 06:12:46 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-22 06:12:46 --> Final output sent to browser
DEBUG - 2018-01-22 06:12:46 --> Total execution time: 0.0775
INFO - 2018-01-22 06:12:54 --> Config Class Initialized
INFO - 2018-01-22 06:12:54 --> Hooks Class Initialized
DEBUG - 2018-01-22 06:12:54 --> UTF-8 Support Enabled
INFO - 2018-01-22 06:12:54 --> Utf8 Class Initialized
INFO - 2018-01-22 06:12:54 --> URI Class Initialized
INFO - 2018-01-22 06:12:54 --> Router Class Initialized
INFO - 2018-01-22 06:12:54 --> Output Class Initialized
INFO - 2018-01-22 06:12:54 --> Security Class Initialized
DEBUG - 2018-01-22 06:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 06:12:54 --> Input Class Initialized
INFO - 2018-01-22 06:12:54 --> Language Class Initialized
ERROR - 2018-01-22 06:12:54 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-01-22 06:12:54 --> Config Class Initialized
INFO - 2018-01-22 06:12:54 --> Hooks Class Initialized
INFO - 2018-01-22 06:12:54 --> Config Class Initialized
INFO - 2018-01-22 06:12:54 --> Hooks Class Initialized
DEBUG - 2018-01-22 06:12:54 --> UTF-8 Support Enabled
INFO - 2018-01-22 06:12:54 --> Utf8 Class Initialized
INFO - 2018-01-22 06:12:54 --> URI Class Initialized
DEBUG - 2018-01-22 06:12:54 --> UTF-8 Support Enabled
INFO - 2018-01-22 06:12:54 --> Utf8 Class Initialized
INFO - 2018-01-22 06:12:54 --> Router Class Initialized
INFO - 2018-01-22 06:12:54 --> URI Class Initialized
INFO - 2018-01-22 06:12:54 --> Output Class Initialized
INFO - 2018-01-22 06:12:54 --> Security Class Initialized
INFO - 2018-01-22 06:12:54 --> Router Class Initialized
DEBUG - 2018-01-22 06:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 06:12:54 --> Input Class Initialized
INFO - 2018-01-22 06:12:54 --> Language Class Initialized
INFO - 2018-01-22 06:12:54 --> Output Class Initialized
ERROR - 2018-01-22 06:12:54 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-01-22 06:12:54 --> Security Class Initialized
DEBUG - 2018-01-22 06:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 06:12:54 --> Input Class Initialized
INFO - 2018-01-22 06:12:54 --> Language Class Initialized
ERROR - 2018-01-22 06:12:54 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-01-22 06:13:26 --> Config Class Initialized
INFO - 2018-01-22 06:13:26 --> Hooks Class Initialized
DEBUG - 2018-01-22 06:13:26 --> UTF-8 Support Enabled
INFO - 2018-01-22 06:13:26 --> Utf8 Class Initialized
INFO - 2018-01-22 06:13:26 --> URI Class Initialized
INFO - 2018-01-22 06:13:26 --> Router Class Initialized
INFO - 2018-01-22 06:13:26 --> Output Class Initialized
INFO - 2018-01-22 06:13:26 --> Security Class Initialized
DEBUG - 2018-01-22 06:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 06:13:26 --> Input Class Initialized
INFO - 2018-01-22 06:13:26 --> Language Class Initialized
INFO - 2018-01-22 06:13:26 --> Loader Class Initialized
INFO - 2018-01-22 06:13:26 --> Helper loaded: url_helper
INFO - 2018-01-22 06:13:26 --> Helper loaded: form_helper
INFO - 2018-01-22 06:13:26 --> Database Driver Class Initialized
DEBUG - 2018-01-22 06:13:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 06:13:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 06:13:26 --> Form Validation Class Initialized
INFO - 2018-01-22 06:13:26 --> Model Class Initialized
INFO - 2018-01-22 06:13:26 --> Controller Class Initialized
INFO - 2018-01-22 06:13:26 --> Model Class Initialized
DEBUG - 2018-01-22 06:13:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-22 06:13:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-01-22 06:13:26 --> Config Class Initialized
INFO - 2018-01-22 06:13:26 --> Hooks Class Initialized
DEBUG - 2018-01-22 06:13:26 --> UTF-8 Support Enabled
INFO - 2018-01-22 06:13:26 --> Utf8 Class Initialized
INFO - 2018-01-22 06:13:26 --> URI Class Initialized
DEBUG - 2018-01-22 06:13:26 --> No URI present. Default controller set.
INFO - 2018-01-22 06:13:26 --> Router Class Initialized
INFO - 2018-01-22 06:13:26 --> Output Class Initialized
INFO - 2018-01-22 06:13:26 --> Security Class Initialized
DEBUG - 2018-01-22 06:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 06:13:26 --> Input Class Initialized
INFO - 2018-01-22 06:13:26 --> Language Class Initialized
INFO - 2018-01-22 06:13:26 --> Loader Class Initialized
INFO - 2018-01-22 06:13:26 --> Helper loaded: url_helper
INFO - 2018-01-22 06:13:26 --> Helper loaded: form_helper
INFO - 2018-01-22 06:13:26 --> Database Driver Class Initialized
DEBUG - 2018-01-22 06:13:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 06:13:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 06:13:26 --> Form Validation Class Initialized
INFO - 2018-01-22 06:13:26 --> Model Class Initialized
INFO - 2018-01-22 06:13:26 --> Controller Class Initialized
INFO - 2018-01-22 06:13:26 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-22 06:13:26 --> Final output sent to browser
DEBUG - 2018-01-22 06:13:26 --> Total execution time: 0.0826
INFO - 2018-01-22 06:14:06 --> Config Class Initialized
INFO - 2018-01-22 06:14:06 --> Hooks Class Initialized
DEBUG - 2018-01-22 06:14:06 --> UTF-8 Support Enabled
INFO - 2018-01-22 06:14:06 --> Utf8 Class Initialized
INFO - 2018-01-22 06:14:06 --> URI Class Initialized
DEBUG - 2018-01-22 06:14:06 --> No URI present. Default controller set.
INFO - 2018-01-22 06:14:06 --> Router Class Initialized
INFO - 2018-01-22 06:14:06 --> Output Class Initialized
INFO - 2018-01-22 06:14:06 --> Security Class Initialized
DEBUG - 2018-01-22 06:14:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 06:14:06 --> Input Class Initialized
INFO - 2018-01-22 06:14:06 --> Language Class Initialized
INFO - 2018-01-22 06:14:06 --> Loader Class Initialized
INFO - 2018-01-22 06:14:06 --> Helper loaded: url_helper
INFO - 2018-01-22 06:14:06 --> Helper loaded: form_helper
INFO - 2018-01-22 06:14:06 --> Database Driver Class Initialized
DEBUG - 2018-01-22 06:14:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 06:14:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 06:14:06 --> Form Validation Class Initialized
INFO - 2018-01-22 06:14:06 --> Model Class Initialized
INFO - 2018-01-22 06:14:06 --> Controller Class Initialized
INFO - 2018-01-22 06:14:06 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-22 06:14:06 --> Final output sent to browser
DEBUG - 2018-01-22 06:14:06 --> Total execution time: 0.0576
INFO - 2018-01-22 06:15:15 --> Config Class Initialized
INFO - 2018-01-22 06:15:15 --> Hooks Class Initialized
DEBUG - 2018-01-22 06:15:15 --> UTF-8 Support Enabled
INFO - 2018-01-22 06:15:15 --> Utf8 Class Initialized
INFO - 2018-01-22 06:15:15 --> URI Class Initialized
DEBUG - 2018-01-22 06:15:15 --> No URI present. Default controller set.
INFO - 2018-01-22 06:15:15 --> Router Class Initialized
INFO - 2018-01-22 06:15:15 --> Output Class Initialized
INFO - 2018-01-22 06:15:15 --> Security Class Initialized
DEBUG - 2018-01-22 06:15:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 06:15:15 --> Input Class Initialized
INFO - 2018-01-22 06:15:15 --> Language Class Initialized
INFO - 2018-01-22 06:15:15 --> Loader Class Initialized
INFO - 2018-01-22 06:15:15 --> Helper loaded: url_helper
INFO - 2018-01-22 06:15:15 --> Helper loaded: form_helper
INFO - 2018-01-22 06:15:15 --> Database Driver Class Initialized
DEBUG - 2018-01-22 06:15:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 06:15:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 06:15:15 --> Form Validation Class Initialized
INFO - 2018-01-22 06:15:15 --> Model Class Initialized
INFO - 2018-01-22 06:15:15 --> Controller Class Initialized
INFO - 2018-01-22 06:15:15 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-22 06:15:15 --> Final output sent to browser
DEBUG - 2018-01-22 06:15:15 --> Total execution time: 0.0784
INFO - 2018-01-22 06:15:17 --> Config Class Initialized
INFO - 2018-01-22 06:15:17 --> Hooks Class Initialized
DEBUG - 2018-01-22 06:15:17 --> UTF-8 Support Enabled
INFO - 2018-01-22 06:15:17 --> Utf8 Class Initialized
INFO - 2018-01-22 06:15:17 --> URI Class Initialized
INFO - 2018-01-22 06:15:17 --> Router Class Initialized
INFO - 2018-01-22 06:15:17 --> Output Class Initialized
INFO - 2018-01-22 06:15:17 --> Security Class Initialized
DEBUG - 2018-01-22 06:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 06:15:17 --> Input Class Initialized
INFO - 2018-01-22 06:15:17 --> Language Class Initialized
INFO - 2018-01-22 06:15:17 --> Loader Class Initialized
INFO - 2018-01-22 06:15:17 --> Helper loaded: url_helper
INFO - 2018-01-22 06:15:17 --> Helper loaded: form_helper
INFO - 2018-01-22 06:15:17 --> Database Driver Class Initialized
DEBUG - 2018-01-22 06:15:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 06:15:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 06:15:17 --> Form Validation Class Initialized
INFO - 2018-01-22 06:15:17 --> Model Class Initialized
INFO - 2018-01-22 06:15:17 --> Controller Class Initialized
INFO - 2018-01-22 06:15:17 --> Model Class Initialized
INFO - 2018-01-22 06:15:17 --> Model Class Initialized
INFO - 2018-01-22 06:15:17 --> Model Class Initialized
INFO - 2018-01-22 06:15:17 --> Model Class Initialized
DEBUG - 2018-01-22 06:15:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-22 06:15:20 --> Config Class Initialized
INFO - 2018-01-22 06:15:20 --> Hooks Class Initialized
DEBUG - 2018-01-22 06:15:20 --> UTF-8 Support Enabled
INFO - 2018-01-22 06:15:20 --> Utf8 Class Initialized
INFO - 2018-01-22 06:15:20 --> URI Class Initialized
INFO - 2018-01-22 06:15:20 --> Router Class Initialized
INFO - 2018-01-22 06:15:20 --> Output Class Initialized
INFO - 2018-01-22 06:15:20 --> Security Class Initialized
DEBUG - 2018-01-22 06:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 06:15:20 --> Input Class Initialized
INFO - 2018-01-22 06:15:20 --> Language Class Initialized
INFO - 2018-01-22 06:15:20 --> Loader Class Initialized
INFO - 2018-01-22 06:15:20 --> Helper loaded: url_helper
INFO - 2018-01-22 06:15:20 --> Helper loaded: form_helper
INFO - 2018-01-22 06:15:20 --> Database Driver Class Initialized
DEBUG - 2018-01-22 06:15:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 06:15:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 06:15:20 --> Form Validation Class Initialized
INFO - 2018-01-22 06:15:20 --> Model Class Initialized
INFO - 2018-01-22 06:15:20 --> Controller Class Initialized
INFO - 2018-01-22 06:15:20 --> Model Class Initialized
INFO - 2018-01-22 06:15:20 --> Model Class Initialized
INFO - 2018-01-22 06:15:20 --> Model Class Initialized
INFO - 2018-01-22 06:15:20 --> Model Class Initialized
DEBUG - 2018-01-22 06:15:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-22 06:15:20 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-22 06:15:20 --> Final output sent to browser
DEBUG - 2018-01-22 06:15:20 --> Total execution time: 0.1077
INFO - 2018-01-22 06:15:21 --> Config Class Initialized
INFO - 2018-01-22 06:15:21 --> Hooks Class Initialized
DEBUG - 2018-01-22 06:15:21 --> UTF-8 Support Enabled
INFO - 2018-01-22 06:15:21 --> Utf8 Class Initialized
INFO - 2018-01-22 06:15:21 --> URI Class Initialized
INFO - 2018-01-22 06:15:21 --> Router Class Initialized
INFO - 2018-01-22 06:15:21 --> Output Class Initialized
INFO - 2018-01-22 06:15:21 --> Security Class Initialized
DEBUG - 2018-01-22 06:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 06:15:21 --> Input Class Initialized
INFO - 2018-01-22 06:15:21 --> Language Class Initialized
INFO - 2018-01-22 06:15:21 --> Loader Class Initialized
INFO - 2018-01-22 06:15:21 --> Helper loaded: url_helper
INFO - 2018-01-22 06:15:21 --> Helper loaded: form_helper
INFO - 2018-01-22 06:15:21 --> Database Driver Class Initialized
DEBUG - 2018-01-22 06:15:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 06:15:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 06:15:21 --> Form Validation Class Initialized
INFO - 2018-01-22 06:15:21 --> Model Class Initialized
INFO - 2018-01-22 06:15:21 --> Controller Class Initialized
INFO - 2018-01-22 06:15:21 --> Model Class Initialized
INFO - 2018-01-22 06:15:21 --> Model Class Initialized
INFO - 2018-01-22 06:15:21 --> Model Class Initialized
INFO - 2018-01-22 06:15:21 --> Model Class Initialized
DEBUG - 2018-01-22 06:15:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-22 06:15:25 --> Config Class Initialized
INFO - 2018-01-22 06:15:25 --> Hooks Class Initialized
DEBUG - 2018-01-22 06:15:25 --> UTF-8 Support Enabled
INFO - 2018-01-22 06:15:25 --> Utf8 Class Initialized
INFO - 2018-01-22 06:15:25 --> URI Class Initialized
INFO - 2018-01-22 06:15:25 --> Router Class Initialized
INFO - 2018-01-22 06:15:25 --> Output Class Initialized
INFO - 2018-01-22 06:15:25 --> Security Class Initialized
DEBUG - 2018-01-22 06:15:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 06:15:25 --> Input Class Initialized
INFO - 2018-01-22 06:15:25 --> Language Class Initialized
INFO - 2018-01-22 06:15:25 --> Loader Class Initialized
INFO - 2018-01-22 06:15:25 --> Helper loaded: url_helper
INFO - 2018-01-22 06:15:25 --> Helper loaded: form_helper
INFO - 2018-01-22 06:15:25 --> Database Driver Class Initialized
DEBUG - 2018-01-22 06:15:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 06:15:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 06:15:25 --> Form Validation Class Initialized
INFO - 2018-01-22 06:15:25 --> Model Class Initialized
INFO - 2018-01-22 06:15:25 --> Controller Class Initialized
INFO - 2018-01-22 06:15:25 --> Model Class Initialized
INFO - 2018-01-22 06:15:25 --> Model Class Initialized
DEBUG - 2018-01-22 06:15:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-22 06:15:25 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-22 06:15:25 --> Final output sent to browser
DEBUG - 2018-01-22 06:15:25 --> Total execution time: 0.3390
INFO - 2018-01-22 06:15:25 --> Config Class Initialized
INFO - 2018-01-22 06:15:25 --> Hooks Class Initialized
DEBUG - 2018-01-22 06:15:25 --> UTF-8 Support Enabled
INFO - 2018-01-22 06:15:25 --> Utf8 Class Initialized
INFO - 2018-01-22 06:15:25 --> URI Class Initialized
INFO - 2018-01-22 06:15:25 --> Router Class Initialized
INFO - 2018-01-22 06:15:25 --> Output Class Initialized
INFO - 2018-01-22 06:15:25 --> Security Class Initialized
DEBUG - 2018-01-22 06:15:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 06:15:25 --> Input Class Initialized
INFO - 2018-01-22 06:15:25 --> Language Class Initialized
INFO - 2018-01-22 06:15:25 --> Loader Class Initialized
INFO - 2018-01-22 06:15:25 --> Helper loaded: url_helper
INFO - 2018-01-22 06:15:25 --> Helper loaded: form_helper
INFO - 2018-01-22 06:15:25 --> Database Driver Class Initialized
DEBUG - 2018-01-22 06:15:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 06:15:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 06:15:25 --> Form Validation Class Initialized
INFO - 2018-01-22 06:15:25 --> Model Class Initialized
INFO - 2018-01-22 06:15:25 --> Controller Class Initialized
INFO - 2018-01-22 06:15:25 --> Model Class Initialized
INFO - 2018-01-22 06:15:25 --> Model Class Initialized
DEBUG - 2018-01-22 06:15:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-22 06:15:26 --> Config Class Initialized
INFO - 2018-01-22 06:15:26 --> Hooks Class Initialized
DEBUG - 2018-01-22 06:15:26 --> UTF-8 Support Enabled
INFO - 2018-01-22 06:15:26 --> Utf8 Class Initialized
INFO - 2018-01-22 06:15:26 --> URI Class Initialized
INFO - 2018-01-22 06:15:26 --> Router Class Initialized
INFO - 2018-01-22 06:15:26 --> Output Class Initialized
INFO - 2018-01-22 06:15:26 --> Security Class Initialized
DEBUG - 2018-01-22 06:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 06:15:26 --> Input Class Initialized
INFO - 2018-01-22 06:15:26 --> Language Class Initialized
INFO - 2018-01-22 06:15:26 --> Loader Class Initialized
INFO - 2018-01-22 06:15:26 --> Helper loaded: url_helper
INFO - 2018-01-22 06:15:26 --> Helper loaded: form_helper
INFO - 2018-01-22 06:15:26 --> Database Driver Class Initialized
DEBUG - 2018-01-22 06:15:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 06:15:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 06:15:26 --> Form Validation Class Initialized
INFO - 2018-01-22 06:15:26 --> Model Class Initialized
INFO - 2018-01-22 06:15:26 --> Controller Class Initialized
INFO - 2018-01-22 06:15:26 --> Model Class Initialized
INFO - 2018-01-22 06:15:26 --> Model Class Initialized
DEBUG - 2018-01-22 06:15:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-22 06:15:26 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-22 06:15:26 --> Final output sent to browser
DEBUG - 2018-01-22 06:15:26 --> Total execution time: 0.0820
INFO - 2018-01-22 06:15:27 --> Config Class Initialized
INFO - 2018-01-22 06:15:27 --> Hooks Class Initialized
DEBUG - 2018-01-22 06:15:27 --> UTF-8 Support Enabled
INFO - 2018-01-22 06:15:27 --> Utf8 Class Initialized
INFO - 2018-01-22 06:15:27 --> URI Class Initialized
INFO - 2018-01-22 06:15:27 --> Router Class Initialized
INFO - 2018-01-22 06:15:27 --> Output Class Initialized
INFO - 2018-01-22 06:15:27 --> Security Class Initialized
DEBUG - 2018-01-22 06:15:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 06:15:27 --> Input Class Initialized
INFO - 2018-01-22 06:15:27 --> Language Class Initialized
INFO - 2018-01-22 06:15:27 --> Loader Class Initialized
INFO - 2018-01-22 06:15:27 --> Helper loaded: url_helper
INFO - 2018-01-22 06:15:27 --> Helper loaded: form_helper
INFO - 2018-01-22 06:15:27 --> Database Driver Class Initialized
DEBUG - 2018-01-22 06:15:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 06:15:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 06:15:27 --> Form Validation Class Initialized
INFO - 2018-01-22 06:15:27 --> Model Class Initialized
INFO - 2018-01-22 06:15:27 --> Controller Class Initialized
INFO - 2018-01-22 06:15:27 --> Model Class Initialized
INFO - 2018-01-22 06:15:27 --> Model Class Initialized
DEBUG - 2018-01-22 06:15:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-22 06:15:27 --> Config Class Initialized
INFO - 2018-01-22 06:15:27 --> Hooks Class Initialized
DEBUG - 2018-01-22 06:15:27 --> UTF-8 Support Enabled
INFO - 2018-01-22 06:15:27 --> Utf8 Class Initialized
INFO - 2018-01-22 06:15:27 --> URI Class Initialized
INFO - 2018-01-22 06:15:27 --> Router Class Initialized
INFO - 2018-01-22 06:15:27 --> Output Class Initialized
INFO - 2018-01-22 06:15:27 --> Security Class Initialized
DEBUG - 2018-01-22 06:15:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 06:15:27 --> Input Class Initialized
INFO - 2018-01-22 06:15:27 --> Language Class Initialized
INFO - 2018-01-22 06:15:27 --> Loader Class Initialized
INFO - 2018-01-22 06:15:27 --> Helper loaded: url_helper
INFO - 2018-01-22 06:15:27 --> Helper loaded: form_helper
INFO - 2018-01-22 06:15:27 --> Database Driver Class Initialized
DEBUG - 2018-01-22 06:15:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 06:15:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 06:15:27 --> Form Validation Class Initialized
INFO - 2018-01-22 06:15:27 --> Model Class Initialized
INFO - 2018-01-22 06:15:27 --> Controller Class Initialized
INFO - 2018-01-22 06:15:27 --> Model Class Initialized
INFO - 2018-01-22 06:15:27 --> Model Class Initialized
DEBUG - 2018-01-22 06:15:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-22 06:15:27 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-22 06:15:27 --> Final output sent to browser
DEBUG - 2018-01-22 06:15:27 --> Total execution time: 0.0824
INFO - 2018-01-22 06:15:28 --> Config Class Initialized
INFO - 2018-01-22 06:15:28 --> Hooks Class Initialized
DEBUG - 2018-01-22 06:15:28 --> UTF-8 Support Enabled
INFO - 2018-01-22 06:15:28 --> Utf8 Class Initialized
INFO - 2018-01-22 06:15:28 --> URI Class Initialized
INFO - 2018-01-22 06:15:28 --> Router Class Initialized
INFO - 2018-01-22 06:15:28 --> Output Class Initialized
INFO - 2018-01-22 06:15:28 --> Security Class Initialized
DEBUG - 2018-01-22 06:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 06:15:28 --> Input Class Initialized
INFO - 2018-01-22 06:15:28 --> Language Class Initialized
INFO - 2018-01-22 06:15:28 --> Loader Class Initialized
INFO - 2018-01-22 06:15:28 --> Helper loaded: url_helper
INFO - 2018-01-22 06:15:28 --> Helper loaded: form_helper
INFO - 2018-01-22 06:15:28 --> Database Driver Class Initialized
DEBUG - 2018-01-22 06:15:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 06:15:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 06:15:28 --> Form Validation Class Initialized
INFO - 2018-01-22 06:15:28 --> Model Class Initialized
INFO - 2018-01-22 06:15:28 --> Controller Class Initialized
INFO - 2018-01-22 06:15:28 --> Model Class Initialized
INFO - 2018-01-22 06:15:28 --> Model Class Initialized
DEBUG - 2018-01-22 06:15:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-22 06:15:29 --> Config Class Initialized
INFO - 2018-01-22 06:15:29 --> Hooks Class Initialized
DEBUG - 2018-01-22 06:15:29 --> UTF-8 Support Enabled
INFO - 2018-01-22 06:15:29 --> Utf8 Class Initialized
INFO - 2018-01-22 06:15:29 --> URI Class Initialized
INFO - 2018-01-22 06:15:29 --> Router Class Initialized
INFO - 2018-01-22 06:15:29 --> Output Class Initialized
INFO - 2018-01-22 06:15:29 --> Security Class Initialized
DEBUG - 2018-01-22 06:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 06:15:29 --> Input Class Initialized
INFO - 2018-01-22 06:15:29 --> Language Class Initialized
INFO - 2018-01-22 06:15:29 --> Loader Class Initialized
INFO - 2018-01-22 06:15:29 --> Helper loaded: url_helper
INFO - 2018-01-22 06:15:29 --> Helper loaded: form_helper
INFO - 2018-01-22 06:15:29 --> Database Driver Class Initialized
DEBUG - 2018-01-22 06:15:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 06:15:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 06:15:29 --> Form Validation Class Initialized
INFO - 2018-01-22 06:15:29 --> Model Class Initialized
INFO - 2018-01-22 06:15:29 --> Controller Class Initialized
INFO - 2018-01-22 06:15:29 --> Model Class Initialized
INFO - 2018-01-22 06:15:29 --> Model Class Initialized
INFO - 2018-01-22 06:15:29 --> Model Class Initialized
INFO - 2018-01-22 06:15:29 --> Model Class Initialized
DEBUG - 2018-01-22 06:15:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-22 06:15:29 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-22 06:15:29 --> Final output sent to browser
DEBUG - 2018-01-22 06:15:29 --> Total execution time: 0.1104
INFO - 2018-01-22 06:15:30 --> Config Class Initialized
INFO - 2018-01-22 06:15:30 --> Hooks Class Initialized
DEBUG - 2018-01-22 06:15:30 --> UTF-8 Support Enabled
INFO - 2018-01-22 06:15:30 --> Utf8 Class Initialized
INFO - 2018-01-22 06:15:30 --> URI Class Initialized
INFO - 2018-01-22 06:15:30 --> Router Class Initialized
INFO - 2018-01-22 06:15:30 --> Output Class Initialized
INFO - 2018-01-22 06:15:30 --> Security Class Initialized
DEBUG - 2018-01-22 06:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 06:15:30 --> Input Class Initialized
INFO - 2018-01-22 06:15:30 --> Language Class Initialized
INFO - 2018-01-22 06:15:30 --> Loader Class Initialized
INFO - 2018-01-22 06:15:30 --> Helper loaded: url_helper
INFO - 2018-01-22 06:15:30 --> Helper loaded: form_helper
INFO - 2018-01-22 06:15:30 --> Database Driver Class Initialized
DEBUG - 2018-01-22 06:15:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 06:15:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 06:15:30 --> Form Validation Class Initialized
INFO - 2018-01-22 06:15:30 --> Model Class Initialized
INFO - 2018-01-22 06:15:30 --> Controller Class Initialized
INFO - 2018-01-22 06:15:30 --> Model Class Initialized
INFO - 2018-01-22 06:15:30 --> Model Class Initialized
DEBUG - 2018-01-22 06:15:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-22 06:15:30 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-22 06:15:30 --> Final output sent to browser
DEBUG - 2018-01-22 06:15:30 --> Total execution time: 0.0849
INFO - 2018-01-22 06:15:31 --> Config Class Initialized
INFO - 2018-01-22 06:15:31 --> Hooks Class Initialized
DEBUG - 2018-01-22 06:15:31 --> UTF-8 Support Enabled
INFO - 2018-01-22 06:15:31 --> Utf8 Class Initialized
INFO - 2018-01-22 06:15:31 --> URI Class Initialized
INFO - 2018-01-22 06:15:31 --> Router Class Initialized
INFO - 2018-01-22 06:15:31 --> Output Class Initialized
INFO - 2018-01-22 06:15:31 --> Security Class Initialized
DEBUG - 2018-01-22 06:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 06:15:31 --> Input Class Initialized
INFO - 2018-01-22 06:15:31 --> Language Class Initialized
INFO - 2018-01-22 06:15:31 --> Loader Class Initialized
INFO - 2018-01-22 06:15:31 --> Helper loaded: url_helper
INFO - 2018-01-22 06:15:31 --> Helper loaded: form_helper
INFO - 2018-01-22 06:15:31 --> Database Driver Class Initialized
DEBUG - 2018-01-22 06:15:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 06:15:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 06:15:31 --> Form Validation Class Initialized
INFO - 2018-01-22 06:15:31 --> Model Class Initialized
INFO - 2018-01-22 06:15:31 --> Controller Class Initialized
INFO - 2018-01-22 06:15:31 --> Model Class Initialized
INFO - 2018-01-22 06:15:31 --> Model Class Initialized
DEBUG - 2018-01-22 06:15:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-22 06:15:32 --> Config Class Initialized
INFO - 2018-01-22 06:15:32 --> Hooks Class Initialized
DEBUG - 2018-01-22 06:15:32 --> UTF-8 Support Enabled
INFO - 2018-01-22 06:15:32 --> Utf8 Class Initialized
INFO - 2018-01-22 06:15:32 --> URI Class Initialized
INFO - 2018-01-22 06:15:32 --> Router Class Initialized
INFO - 2018-01-22 06:15:32 --> Output Class Initialized
INFO - 2018-01-22 06:15:32 --> Security Class Initialized
DEBUG - 2018-01-22 06:15:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 06:15:32 --> Input Class Initialized
INFO - 2018-01-22 06:15:32 --> Language Class Initialized
INFO - 2018-01-22 06:15:32 --> Loader Class Initialized
INFO - 2018-01-22 06:15:32 --> Helper loaded: url_helper
INFO - 2018-01-22 06:15:32 --> Helper loaded: form_helper
INFO - 2018-01-22 06:15:32 --> Database Driver Class Initialized
DEBUG - 2018-01-22 06:15:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 06:15:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 06:15:32 --> Form Validation Class Initialized
INFO - 2018-01-22 06:15:32 --> Model Class Initialized
INFO - 2018-01-22 06:15:32 --> Controller Class Initialized
INFO - 2018-01-22 06:15:32 --> Model Class Initialized
INFO - 2018-01-22 06:15:32 --> Model Class Initialized
INFO - 2018-01-22 06:15:32 --> Model Class Initialized
INFO - 2018-01-22 06:15:32 --> Model Class Initialized
DEBUG - 2018-01-22 06:15:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-22 06:15:32 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-22 06:15:32 --> Final output sent to browser
DEBUG - 2018-01-22 06:15:32 --> Total execution time: 0.0895
INFO - 2018-01-22 06:15:32 --> Config Class Initialized
INFO - 2018-01-22 06:15:32 --> Hooks Class Initialized
DEBUG - 2018-01-22 06:15:32 --> UTF-8 Support Enabled
INFO - 2018-01-22 06:15:32 --> Utf8 Class Initialized
INFO - 2018-01-22 06:15:32 --> URI Class Initialized
INFO - 2018-01-22 06:15:32 --> Router Class Initialized
INFO - 2018-01-22 06:15:32 --> Output Class Initialized
INFO - 2018-01-22 06:15:32 --> Security Class Initialized
DEBUG - 2018-01-22 06:15:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 06:15:32 --> Input Class Initialized
INFO - 2018-01-22 06:15:32 --> Language Class Initialized
INFO - 2018-01-22 06:15:32 --> Loader Class Initialized
INFO - 2018-01-22 06:15:32 --> Helper loaded: url_helper
INFO - 2018-01-22 06:15:32 --> Helper loaded: form_helper
INFO - 2018-01-22 06:15:32 --> Database Driver Class Initialized
DEBUG - 2018-01-22 06:15:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 06:15:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 06:15:32 --> Form Validation Class Initialized
INFO - 2018-01-22 06:15:32 --> Model Class Initialized
INFO - 2018-01-22 06:15:32 --> Controller Class Initialized
INFO - 2018-01-22 06:15:32 --> Model Class Initialized
INFO - 2018-01-22 06:15:32 --> Model Class Initialized
INFO - 2018-01-22 06:15:32 --> Model Class Initialized
INFO - 2018-01-22 06:15:32 --> Model Class Initialized
DEBUG - 2018-01-22 06:15:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-22 06:15:34 --> Config Class Initialized
INFO - 2018-01-22 06:15:34 --> Hooks Class Initialized
DEBUG - 2018-01-22 06:15:34 --> UTF-8 Support Enabled
INFO - 2018-01-22 06:15:34 --> Utf8 Class Initialized
INFO - 2018-01-22 06:15:34 --> URI Class Initialized
DEBUG - 2018-01-22 06:15:34 --> No URI present. Default controller set.
INFO - 2018-01-22 06:15:34 --> Router Class Initialized
INFO - 2018-01-22 06:15:34 --> Output Class Initialized
INFO - 2018-01-22 06:15:34 --> Security Class Initialized
DEBUG - 2018-01-22 06:15:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 06:15:34 --> Input Class Initialized
INFO - 2018-01-22 06:15:34 --> Language Class Initialized
INFO - 2018-01-22 06:15:34 --> Loader Class Initialized
INFO - 2018-01-22 06:15:34 --> Helper loaded: url_helper
INFO - 2018-01-22 06:15:34 --> Helper loaded: form_helper
INFO - 2018-01-22 06:15:34 --> Database Driver Class Initialized
DEBUG - 2018-01-22 06:15:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 06:15:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 06:15:34 --> Form Validation Class Initialized
INFO - 2018-01-22 06:15:34 --> Model Class Initialized
INFO - 2018-01-22 06:15:34 --> Controller Class Initialized
INFO - 2018-01-22 06:15:34 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-22 06:15:34 --> Final output sent to browser
DEBUG - 2018-01-22 06:15:34 --> Total execution time: 0.0839
INFO - 2018-01-22 06:15:35 --> Config Class Initialized
INFO - 2018-01-22 06:15:35 --> Hooks Class Initialized
DEBUG - 2018-01-22 06:15:35 --> UTF-8 Support Enabled
INFO - 2018-01-22 06:15:35 --> Utf8 Class Initialized
INFO - 2018-01-22 06:15:35 --> URI Class Initialized
INFO - 2018-01-22 06:15:35 --> Router Class Initialized
INFO - 2018-01-22 06:15:35 --> Output Class Initialized
INFO - 2018-01-22 06:15:35 --> Security Class Initialized
DEBUG - 2018-01-22 06:15:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 06:15:35 --> Input Class Initialized
INFO - 2018-01-22 06:15:35 --> Language Class Initialized
INFO - 2018-01-22 06:15:35 --> Loader Class Initialized
INFO - 2018-01-22 06:15:35 --> Helper loaded: url_helper
INFO - 2018-01-22 06:15:35 --> Helper loaded: form_helper
INFO - 2018-01-22 06:15:35 --> Database Driver Class Initialized
DEBUG - 2018-01-22 06:15:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 06:15:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 06:15:35 --> Form Validation Class Initialized
INFO - 2018-01-22 06:15:35 --> Model Class Initialized
INFO - 2018-01-22 06:15:35 --> Controller Class Initialized
INFO - 2018-01-22 06:15:35 --> Model Class Initialized
INFO - 2018-01-22 06:15:35 --> Model Class Initialized
INFO - 2018-01-22 06:15:35 --> Model Class Initialized
INFO - 2018-01-22 06:15:35 --> Model Class Initialized
DEBUG - 2018-01-22 06:15:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-22 06:20:23 --> Config Class Initialized
INFO - 2018-01-22 06:20:23 --> Hooks Class Initialized
DEBUG - 2018-01-22 06:20:23 --> UTF-8 Support Enabled
INFO - 2018-01-22 06:20:23 --> Utf8 Class Initialized
INFO - 2018-01-22 06:20:23 --> URI Class Initialized
INFO - 2018-01-22 06:20:23 --> Router Class Initialized
INFO - 2018-01-22 06:20:23 --> Output Class Initialized
INFO - 2018-01-22 06:20:23 --> Security Class Initialized
DEBUG - 2018-01-22 06:20:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 06:20:23 --> Input Class Initialized
INFO - 2018-01-22 06:20:23 --> Language Class Initialized
INFO - 2018-01-22 06:20:23 --> Loader Class Initialized
INFO - 2018-01-22 06:20:23 --> Helper loaded: url_helper
INFO - 2018-01-22 06:20:23 --> Helper loaded: form_helper
INFO - 2018-01-22 06:20:23 --> Database Driver Class Initialized
DEBUG - 2018-01-22 06:20:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 06:20:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 06:20:23 --> Form Validation Class Initialized
INFO - 2018-01-22 06:20:23 --> Model Class Initialized
INFO - 2018-01-22 06:20:23 --> Controller Class Initialized
INFO - 2018-01-22 06:20:23 --> Model Class Initialized
INFO - 2018-01-22 06:20:23 --> Model Class Initialized
INFO - 2018-01-22 06:20:23 --> Model Class Initialized
INFO - 2018-01-22 06:20:23 --> Model Class Initialized
DEBUG - 2018-01-22 06:20:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-22 06:20:23 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-22 06:20:23 --> Final output sent to browser
DEBUG - 2018-01-22 06:20:23 --> Total execution time: 0.0919
INFO - 2018-01-22 06:20:24 --> Config Class Initialized
INFO - 2018-01-22 06:20:24 --> Hooks Class Initialized
DEBUG - 2018-01-22 06:20:24 --> UTF-8 Support Enabled
INFO - 2018-01-22 06:20:24 --> Utf8 Class Initialized
INFO - 2018-01-22 06:20:24 --> URI Class Initialized
INFO - 2018-01-22 06:20:24 --> Router Class Initialized
INFO - 2018-01-22 06:20:24 --> Output Class Initialized
INFO - 2018-01-22 06:20:24 --> Security Class Initialized
DEBUG - 2018-01-22 06:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 06:20:24 --> Input Class Initialized
INFO - 2018-01-22 06:20:24 --> Language Class Initialized
INFO - 2018-01-22 06:20:24 --> Loader Class Initialized
INFO - 2018-01-22 06:20:24 --> Helper loaded: url_helper
INFO - 2018-01-22 06:20:24 --> Helper loaded: form_helper
INFO - 2018-01-22 06:20:24 --> Database Driver Class Initialized
DEBUG - 2018-01-22 06:20:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 06:20:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 06:20:24 --> Form Validation Class Initialized
INFO - 2018-01-22 06:20:24 --> Model Class Initialized
INFO - 2018-01-22 06:20:24 --> Controller Class Initialized
INFO - 2018-01-22 06:20:24 --> Model Class Initialized
INFO - 2018-01-22 06:20:24 --> Model Class Initialized
INFO - 2018-01-22 06:20:24 --> Model Class Initialized
INFO - 2018-01-22 06:20:24 --> Model Class Initialized
DEBUG - 2018-01-22 06:20:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-22 07:04:51 --> Config Class Initialized
INFO - 2018-01-22 07:04:51 --> Hooks Class Initialized
DEBUG - 2018-01-22 07:04:51 --> UTF-8 Support Enabled
INFO - 2018-01-22 07:04:51 --> Utf8 Class Initialized
INFO - 2018-01-22 07:04:51 --> URI Class Initialized
INFO - 2018-01-22 07:04:51 --> Router Class Initialized
INFO - 2018-01-22 07:04:51 --> Output Class Initialized
INFO - 2018-01-22 07:04:51 --> Security Class Initialized
DEBUG - 2018-01-22 07:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 07:04:51 --> Input Class Initialized
INFO - 2018-01-22 07:04:51 --> Language Class Initialized
INFO - 2018-01-22 07:04:51 --> Loader Class Initialized
INFO - 2018-01-22 07:04:51 --> Helper loaded: url_helper
INFO - 2018-01-22 07:04:51 --> Helper loaded: form_helper
INFO - 2018-01-22 07:04:51 --> Database Driver Class Initialized
DEBUG - 2018-01-22 07:04:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 07:04:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 07:04:51 --> Form Validation Class Initialized
INFO - 2018-01-22 07:04:51 --> Model Class Initialized
INFO - 2018-01-22 07:04:51 --> Controller Class Initialized
INFO - 2018-01-22 07:04:51 --> Model Class Initialized
INFO - 2018-01-22 07:04:51 --> Model Class Initialized
INFO - 2018-01-22 07:04:51 --> Model Class Initialized
INFO - 2018-01-22 07:04:51 --> Model Class Initialized
DEBUG - 2018-01-22 07:04:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-22 07:04:51 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-22 07:04:51 --> Final output sent to browser
DEBUG - 2018-01-22 07:04:51 --> Total execution time: 0.0942
INFO - 2018-01-22 07:04:52 --> Config Class Initialized
INFO - 2018-01-22 07:04:52 --> Hooks Class Initialized
DEBUG - 2018-01-22 07:04:52 --> UTF-8 Support Enabled
INFO - 2018-01-22 07:04:52 --> Utf8 Class Initialized
INFO - 2018-01-22 07:04:52 --> URI Class Initialized
INFO - 2018-01-22 07:04:52 --> Router Class Initialized
INFO - 2018-01-22 07:04:52 --> Output Class Initialized
INFO - 2018-01-22 07:04:52 --> Security Class Initialized
DEBUG - 2018-01-22 07:04:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 07:04:52 --> Input Class Initialized
INFO - 2018-01-22 07:04:52 --> Language Class Initialized
INFO - 2018-01-22 07:04:52 --> Loader Class Initialized
INFO - 2018-01-22 07:04:52 --> Helper loaded: url_helper
INFO - 2018-01-22 07:04:52 --> Helper loaded: form_helper
INFO - 2018-01-22 07:04:52 --> Database Driver Class Initialized
DEBUG - 2018-01-22 07:04:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 07:04:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 07:04:52 --> Form Validation Class Initialized
INFO - 2018-01-22 07:04:52 --> Model Class Initialized
INFO - 2018-01-22 07:04:52 --> Controller Class Initialized
INFO - 2018-01-22 07:04:52 --> Model Class Initialized
INFO - 2018-01-22 07:04:52 --> Model Class Initialized
INFO - 2018-01-22 07:04:52 --> Model Class Initialized
INFO - 2018-01-22 07:04:52 --> Model Class Initialized
DEBUG - 2018-01-22 07:04:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-22 07:04:54 --> Config Class Initialized
INFO - 2018-01-22 07:04:54 --> Hooks Class Initialized
DEBUG - 2018-01-22 07:04:54 --> UTF-8 Support Enabled
INFO - 2018-01-22 07:04:54 --> Utf8 Class Initialized
INFO - 2018-01-22 07:04:54 --> URI Class Initialized
INFO - 2018-01-22 07:04:54 --> Router Class Initialized
INFO - 2018-01-22 07:04:54 --> Output Class Initialized
INFO - 2018-01-22 07:04:54 --> Security Class Initialized
DEBUG - 2018-01-22 07:04:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 07:04:54 --> Input Class Initialized
INFO - 2018-01-22 07:04:54 --> Language Class Initialized
INFO - 2018-01-22 07:04:54 --> Loader Class Initialized
INFO - 2018-01-22 07:04:54 --> Helper loaded: url_helper
INFO - 2018-01-22 07:04:54 --> Helper loaded: form_helper
INFO - 2018-01-22 07:04:54 --> Database Driver Class Initialized
DEBUG - 2018-01-22 07:04:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 07:04:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 07:04:54 --> Form Validation Class Initialized
INFO - 2018-01-22 07:04:54 --> Model Class Initialized
INFO - 2018-01-22 07:04:54 --> Controller Class Initialized
INFO - 2018-01-22 07:04:54 --> Model Class Initialized
DEBUG - 2018-01-22 07:04:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-22 07:04:54 --> Config Class Initialized
INFO - 2018-01-22 07:04:54 --> Hooks Class Initialized
DEBUG - 2018-01-22 07:04:54 --> UTF-8 Support Enabled
INFO - 2018-01-22 07:04:54 --> Utf8 Class Initialized
INFO - 2018-01-22 07:04:54 --> URI Class Initialized
INFO - 2018-01-22 07:04:54 --> Router Class Initialized
INFO - 2018-01-22 07:04:54 --> Output Class Initialized
INFO - 2018-01-22 07:04:54 --> Security Class Initialized
DEBUG - 2018-01-22 07:04:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 07:04:54 --> Input Class Initialized
INFO - 2018-01-22 07:04:54 --> Language Class Initialized
INFO - 2018-01-22 07:04:54 --> Loader Class Initialized
INFO - 2018-01-22 07:04:54 --> Helper loaded: url_helper
INFO - 2018-01-22 07:04:54 --> Helper loaded: form_helper
INFO - 2018-01-22 07:04:54 --> Database Driver Class Initialized
DEBUG - 2018-01-22 07:04:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 07:04:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 07:04:54 --> Form Validation Class Initialized
INFO - 2018-01-22 07:04:54 --> Model Class Initialized
INFO - 2018-01-22 07:04:54 --> Controller Class Initialized
INFO - 2018-01-22 07:04:54 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-22 07:04:54 --> Final output sent to browser
DEBUG - 2018-01-22 07:04:54 --> Total execution time: 0.0733
INFO - 2018-01-22 07:07:34 --> Config Class Initialized
INFO - 2018-01-22 07:07:34 --> Hooks Class Initialized
DEBUG - 2018-01-22 07:07:34 --> UTF-8 Support Enabled
INFO - 2018-01-22 07:07:34 --> Utf8 Class Initialized
INFO - 2018-01-22 07:07:34 --> URI Class Initialized
INFO - 2018-01-22 07:07:34 --> Router Class Initialized
INFO - 2018-01-22 07:07:34 --> Output Class Initialized
INFO - 2018-01-22 07:07:34 --> Security Class Initialized
DEBUG - 2018-01-22 07:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 07:07:34 --> Input Class Initialized
INFO - 2018-01-22 07:07:34 --> Language Class Initialized
INFO - 2018-01-22 07:07:34 --> Loader Class Initialized
INFO - 2018-01-22 07:07:34 --> Helper loaded: url_helper
INFO - 2018-01-22 07:07:34 --> Helper loaded: form_helper
INFO - 2018-01-22 07:07:34 --> Database Driver Class Initialized
DEBUG - 2018-01-22 07:07:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 07:07:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 07:07:34 --> Form Validation Class Initialized
INFO - 2018-01-22 07:07:34 --> Model Class Initialized
INFO - 2018-01-22 07:07:34 --> Controller Class Initialized
INFO - 2018-01-22 07:07:34 --> Model Class Initialized
DEBUG - 2018-01-22 07:07:34 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-01-22 07:07:34 --> Severity: Notice --> Undefined variable: loggedin D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\master\menu.php 1
ERROR - 2018-01-22 07:07:34 --> Severity: Notice --> Undefined variable: loggedin D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\master\header.php 60
ERROR - 2018-01-22 07:07:34 --> Severity: Notice --> Undefined variable: loggedin D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\master\footer.php 3
INFO - 2018-01-22 07:07:34 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-22 07:07:34 --> Final output sent to browser
DEBUG - 2018-01-22 07:07:34 --> Total execution time: 0.0851
INFO - 2018-01-22 07:08:40 --> Config Class Initialized
INFO - 2018-01-22 07:08:40 --> Hooks Class Initialized
DEBUG - 2018-01-22 07:08:40 --> UTF-8 Support Enabled
INFO - 2018-01-22 07:08:40 --> Utf8 Class Initialized
INFO - 2018-01-22 07:08:40 --> URI Class Initialized
INFO - 2018-01-22 07:08:40 --> Router Class Initialized
INFO - 2018-01-22 07:08:40 --> Output Class Initialized
INFO - 2018-01-22 07:08:40 --> Security Class Initialized
DEBUG - 2018-01-22 07:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 07:08:40 --> Input Class Initialized
INFO - 2018-01-22 07:08:40 --> Language Class Initialized
INFO - 2018-01-22 07:08:40 --> Loader Class Initialized
INFO - 2018-01-22 07:08:40 --> Helper loaded: url_helper
INFO - 2018-01-22 07:08:40 --> Helper loaded: form_helper
INFO - 2018-01-22 07:08:40 --> Database Driver Class Initialized
DEBUG - 2018-01-22 07:08:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 07:08:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 07:08:40 --> Form Validation Class Initialized
INFO - 2018-01-22 07:08:40 --> Model Class Initialized
INFO - 2018-01-22 07:08:40 --> Controller Class Initialized
INFO - 2018-01-22 07:08:40 --> Model Class Initialized
DEBUG - 2018-01-22 07:08:40 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-01-22 07:08:40 --> Severity: Notice --> Undefined variable: loggedin D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\master\menu.php 1
ERROR - 2018-01-22 07:08:40 --> Severity: Notice --> Undefined variable: loggedin D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\master\header.php 60
ERROR - 2018-01-22 07:08:40 --> Severity: Notice --> Undefined variable: loggedin D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\master\footer.php 3
INFO - 2018-01-22 07:08:40 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-22 07:08:40 --> Final output sent to browser
DEBUG - 2018-01-22 07:08:40 --> Total execution time: 0.0799
INFO - 2018-01-22 07:09:18 --> Config Class Initialized
INFO - 2018-01-22 07:09:18 --> Hooks Class Initialized
DEBUG - 2018-01-22 07:09:18 --> UTF-8 Support Enabled
INFO - 2018-01-22 07:09:18 --> Utf8 Class Initialized
INFO - 2018-01-22 07:09:18 --> URI Class Initialized
INFO - 2018-01-22 07:09:18 --> Router Class Initialized
INFO - 2018-01-22 07:09:18 --> Output Class Initialized
INFO - 2018-01-22 07:09:18 --> Security Class Initialized
DEBUG - 2018-01-22 07:09:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 07:09:18 --> Input Class Initialized
INFO - 2018-01-22 07:09:18 --> Language Class Initialized
INFO - 2018-01-22 07:09:18 --> Loader Class Initialized
INFO - 2018-01-22 07:09:18 --> Helper loaded: url_helper
INFO - 2018-01-22 07:09:18 --> Helper loaded: form_helper
INFO - 2018-01-22 07:09:18 --> Database Driver Class Initialized
DEBUG - 2018-01-22 07:09:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 07:09:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 07:09:18 --> Form Validation Class Initialized
INFO - 2018-01-22 07:09:18 --> Model Class Initialized
INFO - 2018-01-22 07:09:18 --> Controller Class Initialized
INFO - 2018-01-22 07:09:18 --> Model Class Initialized
DEBUG - 2018-01-22 07:09:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-22 07:09:19 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-22 07:09:19 --> Final output sent to browser
DEBUG - 2018-01-22 07:09:19 --> Total execution time: 0.0739
INFO - 2018-01-22 07:09:29 --> Config Class Initialized
INFO - 2018-01-22 07:09:29 --> Hooks Class Initialized
DEBUG - 2018-01-22 07:09:29 --> UTF-8 Support Enabled
INFO - 2018-01-22 07:09:29 --> Utf8 Class Initialized
INFO - 2018-01-22 07:09:29 --> URI Class Initialized
INFO - 2018-01-22 07:09:29 --> Router Class Initialized
INFO - 2018-01-22 07:09:29 --> Output Class Initialized
INFO - 2018-01-22 07:09:29 --> Security Class Initialized
DEBUG - 2018-01-22 07:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 07:09:29 --> Input Class Initialized
INFO - 2018-01-22 07:09:29 --> Language Class Initialized
INFO - 2018-01-22 07:09:29 --> Loader Class Initialized
INFO - 2018-01-22 07:09:29 --> Helper loaded: url_helper
INFO - 2018-01-22 07:09:29 --> Helper loaded: form_helper
INFO - 2018-01-22 07:09:29 --> Database Driver Class Initialized
DEBUG - 2018-01-22 07:09:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 07:09:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 07:09:29 --> Form Validation Class Initialized
INFO - 2018-01-22 07:09:29 --> Model Class Initialized
INFO - 2018-01-22 07:09:29 --> Controller Class Initialized
INFO - 2018-01-22 07:09:29 --> Model Class Initialized
INFO - 2018-01-22 07:09:29 --> Model Class Initialized
INFO - 2018-01-22 07:09:29 --> Model Class Initialized
INFO - 2018-01-22 07:09:29 --> Model Class Initialized
DEBUG - 2018-01-22 07:09:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-22 07:09:29 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-22 07:09:29 --> Final output sent to browser
DEBUG - 2018-01-22 07:09:29 --> Total execution time: 0.1004
INFO - 2018-01-22 07:09:29 --> Config Class Initialized
INFO - 2018-01-22 07:09:29 --> Hooks Class Initialized
DEBUG - 2018-01-22 07:09:29 --> UTF-8 Support Enabled
INFO - 2018-01-22 07:09:29 --> Utf8 Class Initialized
INFO - 2018-01-22 07:09:29 --> URI Class Initialized
INFO - 2018-01-22 07:09:29 --> Router Class Initialized
INFO - 2018-01-22 07:09:29 --> Output Class Initialized
INFO - 2018-01-22 07:09:29 --> Security Class Initialized
DEBUG - 2018-01-22 07:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 07:09:29 --> Input Class Initialized
INFO - 2018-01-22 07:09:29 --> Language Class Initialized
INFO - 2018-01-22 07:09:29 --> Loader Class Initialized
INFO - 2018-01-22 07:09:29 --> Helper loaded: url_helper
INFO - 2018-01-22 07:09:29 --> Helper loaded: form_helper
INFO - 2018-01-22 07:09:29 --> Database Driver Class Initialized
DEBUG - 2018-01-22 07:09:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 07:09:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 07:09:29 --> Form Validation Class Initialized
INFO - 2018-01-22 07:09:29 --> Model Class Initialized
INFO - 2018-01-22 07:09:29 --> Controller Class Initialized
INFO - 2018-01-22 07:09:29 --> Model Class Initialized
INFO - 2018-01-22 07:09:29 --> Model Class Initialized
INFO - 2018-01-22 07:09:29 --> Model Class Initialized
INFO - 2018-01-22 07:09:29 --> Model Class Initialized
DEBUG - 2018-01-22 07:09:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-22 07:09:30 --> Config Class Initialized
INFO - 2018-01-22 07:09:30 --> Hooks Class Initialized
DEBUG - 2018-01-22 07:09:30 --> UTF-8 Support Enabled
INFO - 2018-01-22 07:09:30 --> Utf8 Class Initialized
INFO - 2018-01-22 07:09:30 --> URI Class Initialized
INFO - 2018-01-22 07:09:30 --> Router Class Initialized
INFO - 2018-01-22 07:09:30 --> Output Class Initialized
INFO - 2018-01-22 07:09:30 --> Security Class Initialized
DEBUG - 2018-01-22 07:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 07:09:30 --> Input Class Initialized
INFO - 2018-01-22 07:09:30 --> Language Class Initialized
INFO - 2018-01-22 07:09:30 --> Loader Class Initialized
INFO - 2018-01-22 07:09:30 --> Helper loaded: url_helper
INFO - 2018-01-22 07:09:30 --> Helper loaded: form_helper
INFO - 2018-01-22 07:09:30 --> Database Driver Class Initialized
DEBUG - 2018-01-22 07:09:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 07:09:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 07:09:30 --> Form Validation Class Initialized
INFO - 2018-01-22 07:09:30 --> Model Class Initialized
INFO - 2018-01-22 07:09:30 --> Controller Class Initialized
INFO - 2018-01-22 07:09:30 --> Model Class Initialized
INFO - 2018-01-22 07:09:30 --> Model Class Initialized
DEBUG - 2018-01-22 07:09:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-22 07:09:30 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-22 07:09:30 --> Final output sent to browser
DEBUG - 2018-01-22 07:09:30 --> Total execution time: 0.0790
INFO - 2018-01-22 07:09:30 --> Config Class Initialized
INFO - 2018-01-22 07:09:30 --> Hooks Class Initialized
DEBUG - 2018-01-22 07:09:30 --> UTF-8 Support Enabled
INFO - 2018-01-22 07:09:30 --> Utf8 Class Initialized
INFO - 2018-01-22 07:09:30 --> URI Class Initialized
INFO - 2018-01-22 07:09:30 --> Router Class Initialized
INFO - 2018-01-22 07:09:30 --> Output Class Initialized
INFO - 2018-01-22 07:09:30 --> Security Class Initialized
DEBUG - 2018-01-22 07:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 07:09:30 --> Input Class Initialized
INFO - 2018-01-22 07:09:30 --> Language Class Initialized
INFO - 2018-01-22 07:09:30 --> Loader Class Initialized
INFO - 2018-01-22 07:09:30 --> Helper loaded: url_helper
INFO - 2018-01-22 07:09:30 --> Helper loaded: form_helper
INFO - 2018-01-22 07:09:30 --> Database Driver Class Initialized
DEBUG - 2018-01-22 07:09:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 07:09:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 07:09:30 --> Form Validation Class Initialized
INFO - 2018-01-22 07:09:30 --> Model Class Initialized
INFO - 2018-01-22 07:09:30 --> Controller Class Initialized
INFO - 2018-01-22 07:09:30 --> Model Class Initialized
INFO - 2018-01-22 07:09:30 --> Model Class Initialized
DEBUG - 2018-01-22 07:09:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-22 07:09:32 --> Config Class Initialized
INFO - 2018-01-22 07:09:32 --> Hooks Class Initialized
DEBUG - 2018-01-22 07:09:32 --> UTF-8 Support Enabled
INFO - 2018-01-22 07:09:32 --> Utf8 Class Initialized
INFO - 2018-01-22 07:09:32 --> URI Class Initialized
INFO - 2018-01-22 07:09:32 --> Router Class Initialized
INFO - 2018-01-22 07:09:32 --> Output Class Initialized
INFO - 2018-01-22 07:09:32 --> Security Class Initialized
DEBUG - 2018-01-22 07:09:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 07:09:32 --> Input Class Initialized
INFO - 2018-01-22 07:09:32 --> Language Class Initialized
INFO - 2018-01-22 07:09:32 --> Loader Class Initialized
INFO - 2018-01-22 07:09:32 --> Helper loaded: url_helper
INFO - 2018-01-22 07:09:32 --> Helper loaded: form_helper
INFO - 2018-01-22 07:09:32 --> Database Driver Class Initialized
DEBUG - 2018-01-22 07:09:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 07:09:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 07:09:32 --> Form Validation Class Initialized
INFO - 2018-01-22 07:09:32 --> Model Class Initialized
INFO - 2018-01-22 07:09:32 --> Controller Class Initialized
INFO - 2018-01-22 07:09:32 --> Model Class Initialized
DEBUG - 2018-01-22 07:09:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-22 07:09:32 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-22 07:09:32 --> Final output sent to browser
DEBUG - 2018-01-22 07:09:32 --> Total execution time: 0.0861
INFO - 2018-01-22 07:15:16 --> Config Class Initialized
INFO - 2018-01-22 07:15:16 --> Hooks Class Initialized
DEBUG - 2018-01-22 07:15:16 --> UTF-8 Support Enabled
INFO - 2018-01-22 07:15:16 --> Utf8 Class Initialized
INFO - 2018-01-22 07:15:16 --> URI Class Initialized
INFO - 2018-01-22 07:15:16 --> Router Class Initialized
INFO - 2018-01-22 07:15:16 --> Output Class Initialized
INFO - 2018-01-22 07:15:16 --> Security Class Initialized
DEBUG - 2018-01-22 07:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 07:15:16 --> Input Class Initialized
INFO - 2018-01-22 07:15:16 --> Language Class Initialized
ERROR - 2018-01-22 07:15:16 --> 404 Page Not Found: Login/logout
INFO - 2018-01-22 07:15:20 --> Config Class Initialized
INFO - 2018-01-22 07:15:20 --> Hooks Class Initialized
DEBUG - 2018-01-22 07:15:20 --> UTF-8 Support Enabled
INFO - 2018-01-22 07:15:20 --> Utf8 Class Initialized
INFO - 2018-01-22 07:15:20 --> URI Class Initialized
INFO - 2018-01-22 07:15:20 --> Router Class Initialized
INFO - 2018-01-22 07:15:20 --> Output Class Initialized
INFO - 2018-01-22 07:15:20 --> Security Class Initialized
DEBUG - 2018-01-22 07:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 07:15:20 --> Input Class Initialized
INFO - 2018-01-22 07:15:20 --> Language Class Initialized
ERROR - 2018-01-22 07:15:20 --> 404 Page Not Found: Login/logout
INFO - 2018-01-22 07:15:49 --> Config Class Initialized
INFO - 2018-01-22 07:15:49 --> Hooks Class Initialized
DEBUG - 2018-01-22 07:15:49 --> UTF-8 Support Enabled
INFO - 2018-01-22 07:15:49 --> Utf8 Class Initialized
INFO - 2018-01-22 07:15:49 --> URI Class Initialized
DEBUG - 2018-01-22 07:15:49 --> No URI present. Default controller set.
INFO - 2018-01-22 07:15:49 --> Router Class Initialized
INFO - 2018-01-22 07:15:49 --> Output Class Initialized
INFO - 2018-01-22 07:15:49 --> Security Class Initialized
DEBUG - 2018-01-22 07:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 07:15:49 --> Input Class Initialized
INFO - 2018-01-22 07:15:49 --> Language Class Initialized
INFO - 2018-01-22 07:15:49 --> Loader Class Initialized
INFO - 2018-01-22 07:15:49 --> Helper loaded: url_helper
INFO - 2018-01-22 07:15:49 --> Helper loaded: form_helper
INFO - 2018-01-22 07:15:49 --> Database Driver Class Initialized
DEBUG - 2018-01-22 07:15:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 07:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 07:15:49 --> Form Validation Class Initialized
INFO - 2018-01-22 07:15:49 --> Model Class Initialized
INFO - 2018-01-22 07:15:49 --> Controller Class Initialized
INFO - 2018-01-22 07:15:49 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-22 07:15:49 --> Final output sent to browser
DEBUG - 2018-01-22 07:15:49 --> Total execution time: 0.0362
INFO - 2018-01-22 07:15:49 --> Config Class Initialized
INFO - 2018-01-22 07:15:49 --> Hooks Class Initialized
DEBUG - 2018-01-22 07:15:49 --> UTF-8 Support Enabled
INFO - 2018-01-22 07:15:49 --> Utf8 Class Initialized
INFO - 2018-01-22 07:15:49 --> URI Class Initialized
INFO - 2018-01-22 07:15:49 --> Router Class Initialized
INFO - 2018-01-22 07:15:49 --> Output Class Initialized
INFO - 2018-01-22 07:15:49 --> Security Class Initialized
DEBUG - 2018-01-22 07:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 07:15:49 --> Input Class Initialized
INFO - 2018-01-22 07:15:49 --> Language Class Initialized
INFO - 2018-01-22 07:15:49 --> Loader Class Initialized
INFO - 2018-01-22 07:15:49 --> Helper loaded: url_helper
INFO - 2018-01-22 07:15:49 --> Helper loaded: form_helper
INFO - 2018-01-22 07:15:49 --> Database Driver Class Initialized
DEBUG - 2018-01-22 07:15:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 07:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 07:15:49 --> Form Validation Class Initialized
INFO - 2018-01-22 07:15:49 --> Model Class Initialized
INFO - 2018-01-22 07:15:49 --> Controller Class Initialized
INFO - 2018-01-22 07:15:49 --> Model Class Initialized
INFO - 2018-01-22 07:15:49 --> Model Class Initialized
INFO - 2018-01-22 07:15:49 --> Model Class Initialized
INFO - 2018-01-22 07:15:49 --> Model Class Initialized
DEBUG - 2018-01-22 07:15:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-22 07:15:51 --> Config Class Initialized
INFO - 2018-01-22 07:15:51 --> Hooks Class Initialized
DEBUG - 2018-01-22 07:15:51 --> UTF-8 Support Enabled
INFO - 2018-01-22 07:15:51 --> Utf8 Class Initialized
INFO - 2018-01-22 07:15:51 --> URI Class Initialized
DEBUG - 2018-01-22 07:15:51 --> No URI present. Default controller set.
INFO - 2018-01-22 07:15:51 --> Router Class Initialized
INFO - 2018-01-22 07:15:51 --> Output Class Initialized
INFO - 2018-01-22 07:15:51 --> Security Class Initialized
DEBUG - 2018-01-22 07:15:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 07:15:51 --> Input Class Initialized
INFO - 2018-01-22 07:15:51 --> Language Class Initialized
INFO - 2018-01-22 07:15:51 --> Loader Class Initialized
INFO - 2018-01-22 07:15:51 --> Helper loaded: url_helper
INFO - 2018-01-22 07:15:51 --> Helper loaded: form_helper
INFO - 2018-01-22 07:15:51 --> Database Driver Class Initialized
DEBUG - 2018-01-22 07:15:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 07:15:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 07:15:51 --> Form Validation Class Initialized
INFO - 2018-01-22 07:15:51 --> Model Class Initialized
INFO - 2018-01-22 07:15:51 --> Controller Class Initialized
INFO - 2018-01-22 07:15:51 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-22 07:15:51 --> Final output sent to browser
DEBUG - 2018-01-22 07:15:51 --> Total execution time: 0.0778
INFO - 2018-01-22 07:15:51 --> Config Class Initialized
INFO - 2018-01-22 07:15:51 --> Hooks Class Initialized
DEBUG - 2018-01-22 07:15:51 --> UTF-8 Support Enabled
INFO - 2018-01-22 07:15:51 --> Utf8 Class Initialized
INFO - 2018-01-22 07:15:51 --> URI Class Initialized
INFO - 2018-01-22 07:15:51 --> Router Class Initialized
INFO - 2018-01-22 07:15:51 --> Output Class Initialized
INFO - 2018-01-22 07:15:51 --> Security Class Initialized
DEBUG - 2018-01-22 07:15:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 07:15:51 --> Input Class Initialized
INFO - 2018-01-22 07:15:51 --> Language Class Initialized
INFO - 2018-01-22 07:15:51 --> Loader Class Initialized
INFO - 2018-01-22 07:15:51 --> Helper loaded: url_helper
INFO - 2018-01-22 07:15:51 --> Helper loaded: form_helper
INFO - 2018-01-22 07:15:51 --> Database Driver Class Initialized
DEBUG - 2018-01-22 07:15:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 07:15:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 07:15:51 --> Form Validation Class Initialized
INFO - 2018-01-22 07:15:51 --> Model Class Initialized
INFO - 2018-01-22 07:15:51 --> Controller Class Initialized
INFO - 2018-01-22 07:15:51 --> Model Class Initialized
INFO - 2018-01-22 07:15:51 --> Model Class Initialized
INFO - 2018-01-22 07:15:51 --> Model Class Initialized
INFO - 2018-01-22 07:15:51 --> Model Class Initialized
DEBUG - 2018-01-22 07:15:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-22 07:15:53 --> Config Class Initialized
INFO - 2018-01-22 07:15:53 --> Hooks Class Initialized
DEBUG - 2018-01-22 07:15:53 --> UTF-8 Support Enabled
INFO - 2018-01-22 07:15:53 --> Utf8 Class Initialized
INFO - 2018-01-22 07:15:53 --> URI Class Initialized
INFO - 2018-01-22 07:15:53 --> Router Class Initialized
INFO - 2018-01-22 07:15:53 --> Output Class Initialized
INFO - 2018-01-22 07:15:53 --> Security Class Initialized
DEBUG - 2018-01-22 07:15:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 07:15:53 --> Input Class Initialized
INFO - 2018-01-22 07:15:53 --> Language Class Initialized
ERROR - 2018-01-22 07:15:53 --> 404 Page Not Found: Login/logout
INFO - 2018-01-22 07:18:33 --> Config Class Initialized
INFO - 2018-01-22 07:18:33 --> Hooks Class Initialized
DEBUG - 2018-01-22 07:18:33 --> UTF-8 Support Enabled
INFO - 2018-01-22 07:18:33 --> Utf8 Class Initialized
INFO - 2018-01-22 07:18:33 --> URI Class Initialized
DEBUG - 2018-01-22 07:18:33 --> No URI present. Default controller set.
INFO - 2018-01-22 07:18:33 --> Router Class Initialized
INFO - 2018-01-22 07:18:33 --> Output Class Initialized
INFO - 2018-01-22 07:18:33 --> Security Class Initialized
DEBUG - 2018-01-22 07:18:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 07:18:33 --> Input Class Initialized
INFO - 2018-01-22 07:18:33 --> Language Class Initialized
INFO - 2018-01-22 07:18:33 --> Loader Class Initialized
INFO - 2018-01-22 07:18:33 --> Helper loaded: url_helper
INFO - 2018-01-22 07:18:33 --> Helper loaded: form_helper
INFO - 2018-01-22 07:18:33 --> Database Driver Class Initialized
DEBUG - 2018-01-22 07:18:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 07:18:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 07:18:33 --> Form Validation Class Initialized
INFO - 2018-01-22 07:18:33 --> Model Class Initialized
INFO - 2018-01-22 07:18:33 --> Controller Class Initialized
INFO - 2018-01-22 07:18:33 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-22 07:18:33 --> Final output sent to browser
DEBUG - 2018-01-22 07:18:33 --> Total execution time: 0.0608
INFO - 2018-01-22 07:18:33 --> Config Class Initialized
INFO - 2018-01-22 07:18:33 --> Hooks Class Initialized
DEBUG - 2018-01-22 07:18:33 --> UTF-8 Support Enabled
INFO - 2018-01-22 07:18:33 --> Utf8 Class Initialized
INFO - 2018-01-22 07:18:33 --> URI Class Initialized
INFO - 2018-01-22 07:18:33 --> Router Class Initialized
INFO - 2018-01-22 07:18:33 --> Output Class Initialized
INFO - 2018-01-22 07:18:33 --> Security Class Initialized
DEBUG - 2018-01-22 07:18:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 07:18:33 --> Input Class Initialized
INFO - 2018-01-22 07:18:33 --> Language Class Initialized
INFO - 2018-01-22 07:18:33 --> Loader Class Initialized
INFO - 2018-01-22 07:18:33 --> Helper loaded: url_helper
INFO - 2018-01-22 07:18:33 --> Helper loaded: form_helper
INFO - 2018-01-22 07:18:33 --> Database Driver Class Initialized
DEBUG - 2018-01-22 07:18:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 07:18:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 07:18:33 --> Form Validation Class Initialized
INFO - 2018-01-22 07:18:33 --> Model Class Initialized
INFO - 2018-01-22 07:18:33 --> Controller Class Initialized
INFO - 2018-01-22 07:18:33 --> Model Class Initialized
INFO - 2018-01-22 07:18:33 --> Model Class Initialized
INFO - 2018-01-22 07:18:33 --> Model Class Initialized
INFO - 2018-01-22 07:18:33 --> Model Class Initialized
DEBUG - 2018-01-22 07:18:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-22 07:18:40 --> Config Class Initialized
INFO - 2018-01-22 07:18:40 --> Hooks Class Initialized
DEBUG - 2018-01-22 07:18:40 --> UTF-8 Support Enabled
INFO - 2018-01-22 07:18:40 --> Utf8 Class Initialized
INFO - 2018-01-22 07:18:40 --> URI Class Initialized
INFO - 2018-01-22 07:18:40 --> Router Class Initialized
INFO - 2018-01-22 07:18:40 --> Output Class Initialized
INFO - 2018-01-22 07:18:40 --> Security Class Initialized
DEBUG - 2018-01-22 07:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 07:18:40 --> Input Class Initialized
INFO - 2018-01-22 07:18:40 --> Language Class Initialized
INFO - 2018-01-22 07:18:40 --> Loader Class Initialized
INFO - 2018-01-22 07:18:40 --> Helper loaded: url_helper
INFO - 2018-01-22 07:18:40 --> Helper loaded: form_helper
INFO - 2018-01-22 07:18:40 --> Database Driver Class Initialized
DEBUG - 2018-01-22 07:18:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 07:18:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 07:18:40 --> Form Validation Class Initialized
INFO - 2018-01-22 07:18:40 --> Model Class Initialized
INFO - 2018-01-22 07:18:40 --> Controller Class Initialized
INFO - 2018-01-22 07:18:40 --> Model Class Initialized
INFO - 2018-01-22 07:18:40 --> Model Class Initialized
DEBUG - 2018-01-22 07:18:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-22 07:18:40 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-22 07:18:40 --> Final output sent to browser
DEBUG - 2018-01-22 07:18:40 --> Total execution time: 0.0739
INFO - 2018-01-22 07:18:40 --> Config Class Initialized
INFO - 2018-01-22 07:18:40 --> Hooks Class Initialized
DEBUG - 2018-01-22 07:18:40 --> UTF-8 Support Enabled
INFO - 2018-01-22 07:18:40 --> Utf8 Class Initialized
INFO - 2018-01-22 07:18:40 --> URI Class Initialized
INFO - 2018-01-22 07:18:40 --> Router Class Initialized
INFO - 2018-01-22 07:18:40 --> Output Class Initialized
INFO - 2018-01-22 07:18:40 --> Security Class Initialized
DEBUG - 2018-01-22 07:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 07:18:40 --> Input Class Initialized
INFO - 2018-01-22 07:18:40 --> Language Class Initialized
INFO - 2018-01-22 07:18:40 --> Loader Class Initialized
INFO - 2018-01-22 07:18:40 --> Helper loaded: url_helper
INFO - 2018-01-22 07:18:40 --> Helper loaded: form_helper
INFO - 2018-01-22 07:18:40 --> Database Driver Class Initialized
DEBUG - 2018-01-22 07:18:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 07:18:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 07:18:40 --> Form Validation Class Initialized
INFO - 2018-01-22 07:18:40 --> Model Class Initialized
INFO - 2018-01-22 07:18:40 --> Controller Class Initialized
INFO - 2018-01-22 07:18:40 --> Model Class Initialized
INFO - 2018-01-22 07:18:40 --> Model Class Initialized
DEBUG - 2018-01-22 07:18:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-22 07:18:41 --> Config Class Initialized
INFO - 2018-01-22 07:18:41 --> Hooks Class Initialized
DEBUG - 2018-01-22 07:18:41 --> UTF-8 Support Enabled
INFO - 2018-01-22 07:18:41 --> Utf8 Class Initialized
INFO - 2018-01-22 07:18:41 --> URI Class Initialized
INFO - 2018-01-22 07:18:41 --> Router Class Initialized
INFO - 2018-01-22 07:18:41 --> Output Class Initialized
INFO - 2018-01-22 07:18:41 --> Security Class Initialized
DEBUG - 2018-01-22 07:18:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 07:18:41 --> Input Class Initialized
INFO - 2018-01-22 07:18:41 --> Language Class Initialized
INFO - 2018-01-22 07:18:41 --> Loader Class Initialized
INFO - 2018-01-22 07:18:41 --> Helper loaded: url_helper
INFO - 2018-01-22 07:18:41 --> Helper loaded: form_helper
INFO - 2018-01-22 07:18:41 --> Database Driver Class Initialized
DEBUG - 2018-01-22 07:18:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 07:18:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 07:18:41 --> Form Validation Class Initialized
INFO - 2018-01-22 07:18:41 --> Model Class Initialized
INFO - 2018-01-22 07:18:41 --> Controller Class Initialized
INFO - 2018-01-22 07:18:41 --> Model Class Initialized
DEBUG - 2018-01-22 07:18:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-22 07:18:41 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-22 07:18:41 --> Final output sent to browser
DEBUG - 2018-01-22 07:18:41 --> Total execution time: 0.0792
INFO - 2018-01-22 07:18:42 --> Config Class Initialized
INFO - 2018-01-22 07:18:42 --> Hooks Class Initialized
DEBUG - 2018-01-22 07:18:42 --> UTF-8 Support Enabled
INFO - 2018-01-22 07:18:42 --> Utf8 Class Initialized
INFO - 2018-01-22 07:18:42 --> URI Class Initialized
INFO - 2018-01-22 07:18:42 --> Router Class Initialized
INFO - 2018-01-22 07:18:42 --> Output Class Initialized
INFO - 2018-01-22 07:18:42 --> Security Class Initialized
DEBUG - 2018-01-22 07:18:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 07:18:42 --> Input Class Initialized
INFO - 2018-01-22 07:18:42 --> Language Class Initialized
INFO - 2018-01-22 07:18:42 --> Loader Class Initialized
INFO - 2018-01-22 07:18:42 --> Helper loaded: url_helper
INFO - 2018-01-22 07:18:42 --> Helper loaded: form_helper
INFO - 2018-01-22 07:18:42 --> Database Driver Class Initialized
DEBUG - 2018-01-22 07:18:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 07:18:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 07:18:42 --> Form Validation Class Initialized
INFO - 2018-01-22 07:18:42 --> Model Class Initialized
INFO - 2018-01-22 07:18:42 --> Controller Class Initialized
INFO - 2018-01-22 07:18:42 --> Model Class Initialized
DEBUG - 2018-01-22 07:18:42 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-01-22 07:18:42 --> Query error: Column 'estado_id' in where clause is ambiguous - Invalid query: SELECT *
FROM `usuario`
JOIN `usuario_estado` ON `usuario_estado`.`estado_id` = `usuario`.`estado_id`
JOIN `usuario_detalle` ON `usuario_detalle`.`usuario_id` = `usuario`.`usuario_id`
JOIN `usuario_rol` ON `usuario_rol`.`rol_id` = `usuario`.`rol_id`
WHERE `usuario` LIKE '%%' ESCAPE '!'
AND  `nombre` LIKE '%%' ESCAPE '!'
AND  `correo` LIKE '%%' ESCAPE '!'
AND `estado_id` = 1
INFO - 2018-01-22 07:18:42 --> Language file loaded: language/english/db_lang.php
INFO - 2018-01-22 07:18:45 --> Config Class Initialized
INFO - 2018-01-22 07:18:45 --> Hooks Class Initialized
DEBUG - 2018-01-22 07:18:45 --> UTF-8 Support Enabled
INFO - 2018-01-22 07:18:45 --> Utf8 Class Initialized
INFO - 2018-01-22 07:18:45 --> URI Class Initialized
INFO - 2018-01-22 07:18:45 --> Router Class Initialized
INFO - 2018-01-22 07:18:45 --> Output Class Initialized
INFO - 2018-01-22 07:18:45 --> Security Class Initialized
DEBUG - 2018-01-22 07:18:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 07:18:45 --> Input Class Initialized
INFO - 2018-01-22 07:18:45 --> Language Class Initialized
INFO - 2018-01-22 07:18:45 --> Loader Class Initialized
INFO - 2018-01-22 07:18:45 --> Helper loaded: url_helper
INFO - 2018-01-22 07:18:45 --> Helper loaded: form_helper
INFO - 2018-01-22 07:18:45 --> Database Driver Class Initialized
DEBUG - 2018-01-22 07:18:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 07:18:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 07:18:45 --> Form Validation Class Initialized
INFO - 2018-01-22 07:18:45 --> Model Class Initialized
INFO - 2018-01-22 07:18:45 --> Controller Class Initialized
INFO - 2018-01-22 07:18:45 --> Model Class Initialized
DEBUG - 2018-01-22 07:18:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-22 07:18:45 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-22 07:18:45 --> Final output sent to browser
DEBUG - 2018-01-22 07:18:45 --> Total execution time: 0.0924
INFO - 2018-01-22 07:18:46 --> Config Class Initialized
INFO - 2018-01-22 07:18:46 --> Hooks Class Initialized
DEBUG - 2018-01-22 07:18:46 --> UTF-8 Support Enabled
INFO - 2018-01-22 07:18:46 --> Utf8 Class Initialized
INFO - 2018-01-22 07:18:46 --> URI Class Initialized
INFO - 2018-01-22 07:18:46 --> Router Class Initialized
INFO - 2018-01-22 07:18:46 --> Output Class Initialized
INFO - 2018-01-22 07:18:46 --> Security Class Initialized
DEBUG - 2018-01-22 07:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 07:18:46 --> Input Class Initialized
INFO - 2018-01-22 07:18:46 --> Language Class Initialized
INFO - 2018-01-22 07:18:46 --> Loader Class Initialized
INFO - 2018-01-22 07:18:46 --> Helper loaded: url_helper
INFO - 2018-01-22 07:18:46 --> Helper loaded: form_helper
INFO - 2018-01-22 07:18:46 --> Database Driver Class Initialized
DEBUG - 2018-01-22 07:18:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 07:18:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 07:18:46 --> Form Validation Class Initialized
INFO - 2018-01-22 07:18:46 --> Model Class Initialized
INFO - 2018-01-22 07:18:46 --> Controller Class Initialized
INFO - 2018-01-22 07:18:46 --> Model Class Initialized
DEBUG - 2018-01-22 07:18:46 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-01-22 07:18:46 --> Query error: Column 'estado_id' in where clause is ambiguous - Invalid query: SELECT *
FROM `usuario`
JOIN `usuario_estado` ON `usuario_estado`.`estado_id` = `usuario`.`estado_id`
JOIN `usuario_detalle` ON `usuario_detalle`.`usuario_id` = `usuario`.`usuario_id`
JOIN `usuario_rol` ON `usuario_rol`.`rol_id` = `usuario`.`rol_id`
WHERE `usuario` LIKE '%%' ESCAPE '!'
AND  `nombre` LIKE '%%' ESCAPE '!'
AND  `correo` LIKE '%%' ESCAPE '!'
AND `estado_id` = 1
INFO - 2018-01-22 07:18:46 --> Language file loaded: language/english/db_lang.php
INFO - 2018-01-22 07:18:47 --> Config Class Initialized
INFO - 2018-01-22 07:18:47 --> Hooks Class Initialized
DEBUG - 2018-01-22 07:18:47 --> UTF-8 Support Enabled
INFO - 2018-01-22 07:18:47 --> Utf8 Class Initialized
INFO - 2018-01-22 07:18:47 --> URI Class Initialized
INFO - 2018-01-22 07:18:47 --> Router Class Initialized
INFO - 2018-01-22 07:18:47 --> Output Class Initialized
INFO - 2018-01-22 07:18:47 --> Security Class Initialized
DEBUG - 2018-01-22 07:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 07:18:47 --> Input Class Initialized
INFO - 2018-01-22 07:18:47 --> Language Class Initialized
INFO - 2018-01-22 07:18:47 --> Loader Class Initialized
INFO - 2018-01-22 07:18:47 --> Helper loaded: url_helper
INFO - 2018-01-22 07:18:47 --> Helper loaded: form_helper
INFO - 2018-01-22 07:18:47 --> Database Driver Class Initialized
DEBUG - 2018-01-22 07:18:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 07:18:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 07:18:47 --> Form Validation Class Initialized
INFO - 2018-01-22 07:18:47 --> Model Class Initialized
INFO - 2018-01-22 07:18:47 --> Controller Class Initialized
INFO - 2018-01-22 07:18:47 --> Model Class Initialized
INFO - 2018-01-22 07:18:47 --> Model Class Initialized
INFO - 2018-01-22 07:18:47 --> Model Class Initialized
INFO - 2018-01-22 07:18:47 --> Model Class Initialized
DEBUG - 2018-01-22 07:18:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-22 07:18:47 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-22 07:18:47 --> Final output sent to browser
DEBUG - 2018-01-22 07:18:47 --> Total execution time: 0.1045
INFO - 2018-01-22 07:18:48 --> Config Class Initialized
INFO - 2018-01-22 07:18:48 --> Hooks Class Initialized
DEBUG - 2018-01-22 07:18:48 --> UTF-8 Support Enabled
INFO - 2018-01-22 07:18:48 --> Utf8 Class Initialized
INFO - 2018-01-22 07:18:48 --> URI Class Initialized
INFO - 2018-01-22 07:18:48 --> Router Class Initialized
INFO - 2018-01-22 07:18:48 --> Output Class Initialized
INFO - 2018-01-22 07:18:48 --> Security Class Initialized
DEBUG - 2018-01-22 07:18:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 07:18:48 --> Input Class Initialized
INFO - 2018-01-22 07:18:48 --> Language Class Initialized
INFO - 2018-01-22 07:18:48 --> Loader Class Initialized
INFO - 2018-01-22 07:18:48 --> Helper loaded: url_helper
INFO - 2018-01-22 07:18:48 --> Helper loaded: form_helper
INFO - 2018-01-22 07:18:48 --> Database Driver Class Initialized
DEBUG - 2018-01-22 07:18:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 07:18:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 07:18:48 --> Form Validation Class Initialized
INFO - 2018-01-22 07:18:48 --> Model Class Initialized
INFO - 2018-01-22 07:18:48 --> Controller Class Initialized
INFO - 2018-01-22 07:18:48 --> Model Class Initialized
DEBUG - 2018-01-22 07:18:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-22 07:18:48 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-22 07:18:48 --> Final output sent to browser
DEBUG - 2018-01-22 07:18:48 --> Total execution time: 0.0618
INFO - 2018-01-22 07:18:48 --> Config Class Initialized
INFO - 2018-01-22 07:18:48 --> Hooks Class Initialized
DEBUG - 2018-01-22 07:18:48 --> UTF-8 Support Enabled
INFO - 2018-01-22 07:18:48 --> Utf8 Class Initialized
INFO - 2018-01-22 07:18:48 --> URI Class Initialized
INFO - 2018-01-22 07:18:48 --> Router Class Initialized
INFO - 2018-01-22 07:18:48 --> Output Class Initialized
INFO - 2018-01-22 07:18:48 --> Security Class Initialized
DEBUG - 2018-01-22 07:18:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 07:18:48 --> Input Class Initialized
INFO - 2018-01-22 07:18:48 --> Language Class Initialized
INFO - 2018-01-22 07:18:48 --> Loader Class Initialized
INFO - 2018-01-22 07:18:48 --> Helper loaded: url_helper
INFO - 2018-01-22 07:18:48 --> Helper loaded: form_helper
INFO - 2018-01-22 07:18:48 --> Database Driver Class Initialized
DEBUG - 2018-01-22 07:18:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 07:18:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 07:18:48 --> Form Validation Class Initialized
INFO - 2018-01-22 07:18:48 --> Model Class Initialized
INFO - 2018-01-22 07:18:48 --> Controller Class Initialized
INFO - 2018-01-22 07:18:48 --> Model Class Initialized
DEBUG - 2018-01-22 07:18:48 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-01-22 07:18:48 --> Query error: Column 'estado_id' in where clause is ambiguous - Invalid query: SELECT *
FROM `usuario`
JOIN `usuario_estado` ON `usuario_estado`.`estado_id` = `usuario`.`estado_id`
JOIN `usuario_detalle` ON `usuario_detalle`.`usuario_id` = `usuario`.`usuario_id`
JOIN `usuario_rol` ON `usuario_rol`.`rol_id` = `usuario`.`rol_id`
WHERE `usuario` LIKE '%%' ESCAPE '!'
AND  `nombre` LIKE '%%' ESCAPE '!'
AND  `correo` LIKE '%%' ESCAPE '!'
AND `estado_id` = 1
INFO - 2018-01-22 07:18:48 --> Language file loaded: language/english/db_lang.php
INFO - 2018-01-22 07:18:51 --> Config Class Initialized
INFO - 2018-01-22 07:18:51 --> Hooks Class Initialized
DEBUG - 2018-01-22 07:18:51 --> UTF-8 Support Enabled
INFO - 2018-01-22 07:18:51 --> Utf8 Class Initialized
INFO - 2018-01-22 07:18:51 --> URI Class Initialized
DEBUG - 2018-01-22 07:18:51 --> No URI present. Default controller set.
INFO - 2018-01-22 07:18:51 --> Router Class Initialized
INFO - 2018-01-22 07:18:51 --> Output Class Initialized
INFO - 2018-01-22 07:18:51 --> Security Class Initialized
DEBUG - 2018-01-22 07:18:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 07:18:51 --> Input Class Initialized
INFO - 2018-01-22 07:18:51 --> Language Class Initialized
INFO - 2018-01-22 07:18:51 --> Loader Class Initialized
INFO - 2018-01-22 07:18:51 --> Helper loaded: url_helper
INFO - 2018-01-22 07:18:51 --> Helper loaded: form_helper
INFO - 2018-01-22 07:18:51 --> Database Driver Class Initialized
DEBUG - 2018-01-22 07:18:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 07:18:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 07:18:52 --> Form Validation Class Initialized
INFO - 2018-01-22 07:18:52 --> Model Class Initialized
INFO - 2018-01-22 07:18:52 --> Controller Class Initialized
INFO - 2018-01-22 07:18:52 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-22 07:18:52 --> Final output sent to browser
DEBUG - 2018-01-22 07:18:52 --> Total execution time: 0.0697
INFO - 2018-01-22 07:18:52 --> Config Class Initialized
INFO - 2018-01-22 07:18:52 --> Hooks Class Initialized
DEBUG - 2018-01-22 07:18:52 --> UTF-8 Support Enabled
INFO - 2018-01-22 07:18:52 --> Utf8 Class Initialized
INFO - 2018-01-22 07:18:52 --> URI Class Initialized
INFO - 2018-01-22 07:18:52 --> Router Class Initialized
INFO - 2018-01-22 07:18:52 --> Output Class Initialized
INFO - 2018-01-22 07:18:52 --> Security Class Initialized
DEBUG - 2018-01-22 07:18:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 07:18:52 --> Input Class Initialized
INFO - 2018-01-22 07:18:52 --> Language Class Initialized
INFO - 2018-01-22 07:18:52 --> Loader Class Initialized
INFO - 2018-01-22 07:18:52 --> Helper loaded: url_helper
INFO - 2018-01-22 07:18:52 --> Helper loaded: form_helper
INFO - 2018-01-22 07:18:52 --> Database Driver Class Initialized
DEBUG - 2018-01-22 07:18:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 07:18:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 07:18:52 --> Form Validation Class Initialized
INFO - 2018-01-22 07:18:52 --> Model Class Initialized
INFO - 2018-01-22 07:18:52 --> Controller Class Initialized
INFO - 2018-01-22 07:18:52 --> Model Class Initialized
INFO - 2018-01-22 07:18:52 --> Model Class Initialized
INFO - 2018-01-22 07:18:52 --> Model Class Initialized
INFO - 2018-01-22 07:18:52 --> Model Class Initialized
DEBUG - 2018-01-22 07:18:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-22 07:18:54 --> Config Class Initialized
INFO - 2018-01-22 07:18:54 --> Hooks Class Initialized
DEBUG - 2018-01-22 07:18:54 --> UTF-8 Support Enabled
INFO - 2018-01-22 07:18:54 --> Utf8 Class Initialized
INFO - 2018-01-22 07:18:54 --> URI Class Initialized
INFO - 2018-01-22 07:18:54 --> Router Class Initialized
INFO - 2018-01-22 07:18:54 --> Output Class Initialized
INFO - 2018-01-22 07:18:54 --> Security Class Initialized
DEBUG - 2018-01-22 07:18:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 07:18:54 --> Input Class Initialized
INFO - 2018-01-22 07:18:54 --> Language Class Initialized
ERROR - 2018-01-22 07:18:54 --> 404 Page Not Found: Login/logout
INFO - 2018-01-22 07:20:44 --> Config Class Initialized
INFO - 2018-01-22 07:20:44 --> Hooks Class Initialized
DEBUG - 2018-01-22 07:20:44 --> UTF-8 Support Enabled
INFO - 2018-01-22 07:20:44 --> Utf8 Class Initialized
INFO - 2018-01-22 07:20:44 --> URI Class Initialized
INFO - 2018-01-22 07:20:44 --> Router Class Initialized
INFO - 2018-01-22 07:20:44 --> Output Class Initialized
INFO - 2018-01-22 07:20:44 --> Security Class Initialized
DEBUG - 2018-01-22 07:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 07:20:44 --> Input Class Initialized
INFO - 2018-01-22 07:20:44 --> Language Class Initialized
ERROR - 2018-01-22 07:20:44 --> 404 Page Not Found: Login/logout
INFO - 2018-01-22 07:20:48 --> Config Class Initialized
INFO - 2018-01-22 07:20:48 --> Hooks Class Initialized
DEBUG - 2018-01-22 07:20:48 --> UTF-8 Support Enabled
INFO - 2018-01-22 07:20:48 --> Utf8 Class Initialized
INFO - 2018-01-22 07:20:48 --> URI Class Initialized
DEBUG - 2018-01-22 07:20:48 --> No URI present. Default controller set.
INFO - 2018-01-22 07:20:48 --> Router Class Initialized
INFO - 2018-01-22 07:20:48 --> Output Class Initialized
INFO - 2018-01-22 07:20:48 --> Security Class Initialized
DEBUG - 2018-01-22 07:20:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 07:20:48 --> Input Class Initialized
INFO - 2018-01-22 07:20:48 --> Language Class Initialized
INFO - 2018-01-22 07:20:48 --> Loader Class Initialized
INFO - 2018-01-22 07:20:48 --> Helper loaded: url_helper
INFO - 2018-01-22 07:20:48 --> Helper loaded: form_helper
INFO - 2018-01-22 07:20:48 --> Database Driver Class Initialized
DEBUG - 2018-01-22 07:20:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 07:20:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 07:20:48 --> Form Validation Class Initialized
INFO - 2018-01-22 07:20:48 --> Model Class Initialized
INFO - 2018-01-22 07:20:48 --> Controller Class Initialized
INFO - 2018-01-22 07:20:48 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-22 07:20:48 --> Final output sent to browser
DEBUG - 2018-01-22 07:20:48 --> Total execution time: 0.0964
INFO - 2018-01-22 07:20:48 --> Config Class Initialized
INFO - 2018-01-22 07:20:48 --> Hooks Class Initialized
DEBUG - 2018-01-22 07:20:48 --> UTF-8 Support Enabled
INFO - 2018-01-22 07:20:48 --> Utf8 Class Initialized
INFO - 2018-01-22 07:20:48 --> URI Class Initialized
INFO - 2018-01-22 07:20:48 --> Router Class Initialized
INFO - 2018-01-22 07:20:48 --> Output Class Initialized
INFO - 2018-01-22 07:20:48 --> Security Class Initialized
DEBUG - 2018-01-22 07:20:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 07:20:48 --> Input Class Initialized
INFO - 2018-01-22 07:20:48 --> Language Class Initialized
INFO - 2018-01-22 07:20:48 --> Loader Class Initialized
INFO - 2018-01-22 07:20:48 --> Helper loaded: url_helper
INFO - 2018-01-22 07:20:48 --> Helper loaded: form_helper
INFO - 2018-01-22 07:20:48 --> Database Driver Class Initialized
DEBUG - 2018-01-22 07:20:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 07:20:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 07:20:48 --> Form Validation Class Initialized
INFO - 2018-01-22 07:20:48 --> Model Class Initialized
INFO - 2018-01-22 07:20:48 --> Controller Class Initialized
INFO - 2018-01-22 07:20:48 --> Model Class Initialized
INFO - 2018-01-22 07:20:48 --> Model Class Initialized
INFO - 2018-01-22 07:20:48 --> Model Class Initialized
INFO - 2018-01-22 07:20:48 --> Model Class Initialized
DEBUG - 2018-01-22 07:20:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-22 07:20:51 --> Config Class Initialized
INFO - 2018-01-22 07:20:51 --> Hooks Class Initialized
DEBUG - 2018-01-22 07:20:51 --> UTF-8 Support Enabled
INFO - 2018-01-22 07:20:51 --> Utf8 Class Initialized
INFO - 2018-01-22 07:20:51 --> URI Class Initialized
DEBUG - 2018-01-22 07:20:51 --> No URI present. Default controller set.
INFO - 2018-01-22 07:20:51 --> Router Class Initialized
INFO - 2018-01-22 07:20:51 --> Output Class Initialized
INFO - 2018-01-22 07:20:51 --> Security Class Initialized
DEBUG - 2018-01-22 07:20:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 07:20:51 --> Input Class Initialized
INFO - 2018-01-22 07:20:51 --> Language Class Initialized
INFO - 2018-01-22 07:20:51 --> Loader Class Initialized
INFO - 2018-01-22 07:20:51 --> Helper loaded: url_helper
INFO - 2018-01-22 07:20:51 --> Helper loaded: form_helper
INFO - 2018-01-22 07:20:51 --> Database Driver Class Initialized
DEBUG - 2018-01-22 07:20:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 07:20:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 07:20:51 --> Form Validation Class Initialized
INFO - 2018-01-22 07:20:51 --> Model Class Initialized
INFO - 2018-01-22 07:20:51 --> Controller Class Initialized
INFO - 2018-01-22 07:20:51 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-22 07:20:51 --> Final output sent to browser
DEBUG - 2018-01-22 07:20:51 --> Total execution time: 0.0731
INFO - 2018-01-22 07:20:51 --> Config Class Initialized
INFO - 2018-01-22 07:20:51 --> Hooks Class Initialized
DEBUG - 2018-01-22 07:20:51 --> UTF-8 Support Enabled
INFO - 2018-01-22 07:20:51 --> Utf8 Class Initialized
INFO - 2018-01-22 07:20:51 --> URI Class Initialized
INFO - 2018-01-22 07:20:51 --> Router Class Initialized
INFO - 2018-01-22 07:20:51 --> Output Class Initialized
INFO - 2018-01-22 07:20:51 --> Security Class Initialized
DEBUG - 2018-01-22 07:20:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 07:20:51 --> Input Class Initialized
INFO - 2018-01-22 07:20:51 --> Language Class Initialized
INFO - 2018-01-22 07:20:51 --> Loader Class Initialized
INFO - 2018-01-22 07:20:51 --> Helper loaded: url_helper
INFO - 2018-01-22 07:20:51 --> Helper loaded: form_helper
INFO - 2018-01-22 07:20:51 --> Database Driver Class Initialized
DEBUG - 2018-01-22 07:20:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 07:20:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 07:20:51 --> Form Validation Class Initialized
INFO - 2018-01-22 07:20:51 --> Model Class Initialized
INFO - 2018-01-22 07:20:51 --> Controller Class Initialized
INFO - 2018-01-22 07:20:51 --> Model Class Initialized
INFO - 2018-01-22 07:20:51 --> Model Class Initialized
INFO - 2018-01-22 07:20:51 --> Model Class Initialized
INFO - 2018-01-22 07:20:51 --> Model Class Initialized
DEBUG - 2018-01-22 07:20:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-22 07:21:25 --> Config Class Initialized
INFO - 2018-01-22 07:21:25 --> Hooks Class Initialized
DEBUG - 2018-01-22 07:21:25 --> UTF-8 Support Enabled
INFO - 2018-01-22 07:21:25 --> Utf8 Class Initialized
INFO - 2018-01-22 07:21:25 --> URI Class Initialized
INFO - 2018-01-22 07:21:25 --> Router Class Initialized
INFO - 2018-01-22 07:21:25 --> Output Class Initialized
INFO - 2018-01-22 07:21:25 --> Security Class Initialized
DEBUG - 2018-01-22 07:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 07:21:25 --> Input Class Initialized
INFO - 2018-01-22 07:21:25 --> Language Class Initialized
INFO - 2018-01-22 07:21:25 --> Loader Class Initialized
INFO - 2018-01-22 07:21:25 --> Helper loaded: url_helper
INFO - 2018-01-22 07:21:25 --> Helper loaded: form_helper
INFO - 2018-01-22 07:21:25 --> Database Driver Class Initialized
DEBUG - 2018-01-22 07:21:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 07:21:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 07:21:25 --> Form Validation Class Initialized
INFO - 2018-01-22 07:21:25 --> Model Class Initialized
INFO - 2018-01-22 07:21:25 --> Controller Class Initialized
INFO - 2018-01-22 07:21:25 --> Model Class Initialized
DEBUG - 2018-01-22 07:21:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-22 07:21:25 --> Config Class Initialized
INFO - 2018-01-22 07:21:25 --> Hooks Class Initialized
DEBUG - 2018-01-22 07:21:25 --> UTF-8 Support Enabled
INFO - 2018-01-22 07:21:25 --> Utf8 Class Initialized
INFO - 2018-01-22 07:21:25 --> URI Class Initialized
INFO - 2018-01-22 07:21:25 --> Router Class Initialized
INFO - 2018-01-22 07:21:25 --> Output Class Initialized
INFO - 2018-01-22 07:21:25 --> Security Class Initialized
DEBUG - 2018-01-22 07:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 07:21:25 --> Input Class Initialized
INFO - 2018-01-22 07:21:25 --> Language Class Initialized
INFO - 2018-01-22 07:21:25 --> Loader Class Initialized
INFO - 2018-01-22 07:21:25 --> Helper loaded: url_helper
INFO - 2018-01-22 07:21:25 --> Helper loaded: form_helper
INFO - 2018-01-22 07:21:25 --> Database Driver Class Initialized
DEBUG - 2018-01-22 07:21:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 07:21:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 07:21:25 --> Form Validation Class Initialized
INFO - 2018-01-22 07:21:25 --> Model Class Initialized
INFO - 2018-01-22 07:21:25 --> Controller Class Initialized
INFO - 2018-01-22 07:21:25 --> Model Class Initialized
DEBUG - 2018-01-22 07:21:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-22 07:21:25 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-22 07:21:25 --> Final output sent to browser
DEBUG - 2018-01-22 07:21:25 --> Total execution time: 0.0799
INFO - 2018-01-22 07:21:29 --> Config Class Initialized
INFO - 2018-01-22 07:21:29 --> Hooks Class Initialized
DEBUG - 2018-01-22 07:21:29 --> UTF-8 Support Enabled
INFO - 2018-01-22 07:21:29 --> Utf8 Class Initialized
INFO - 2018-01-22 07:21:29 --> URI Class Initialized
INFO - 2018-01-22 07:21:29 --> Router Class Initialized
INFO - 2018-01-22 07:21:29 --> Output Class Initialized
INFO - 2018-01-22 07:21:29 --> Security Class Initialized
DEBUG - 2018-01-22 07:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 07:21:29 --> Input Class Initialized
INFO - 2018-01-22 07:21:29 --> Language Class Initialized
INFO - 2018-01-22 07:21:29 --> Loader Class Initialized
INFO - 2018-01-22 07:21:30 --> Helper loaded: url_helper
INFO - 2018-01-22 07:21:30 --> Helper loaded: form_helper
INFO - 2018-01-22 07:21:30 --> Database Driver Class Initialized
DEBUG - 2018-01-22 07:21:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 07:21:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 07:21:30 --> Form Validation Class Initialized
INFO - 2018-01-22 07:21:30 --> Model Class Initialized
INFO - 2018-01-22 07:21:30 --> Controller Class Initialized
INFO - 2018-01-22 07:21:30 --> Model Class Initialized
DEBUG - 2018-01-22 07:21:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-22 07:21:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-01-22 07:21:30 --> Config Class Initialized
INFO - 2018-01-22 07:21:30 --> Hooks Class Initialized
DEBUG - 2018-01-22 07:21:30 --> UTF-8 Support Enabled
INFO - 2018-01-22 07:21:30 --> Utf8 Class Initialized
INFO - 2018-01-22 07:21:30 --> URI Class Initialized
DEBUG - 2018-01-22 07:21:30 --> No URI present. Default controller set.
INFO - 2018-01-22 07:21:30 --> Router Class Initialized
INFO - 2018-01-22 07:21:30 --> Output Class Initialized
INFO - 2018-01-22 07:21:30 --> Security Class Initialized
DEBUG - 2018-01-22 07:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 07:21:30 --> Input Class Initialized
INFO - 2018-01-22 07:21:30 --> Language Class Initialized
INFO - 2018-01-22 07:21:30 --> Loader Class Initialized
INFO - 2018-01-22 07:21:30 --> Helper loaded: url_helper
INFO - 2018-01-22 07:21:30 --> Helper loaded: form_helper
INFO - 2018-01-22 07:21:30 --> Database Driver Class Initialized
DEBUG - 2018-01-22 07:21:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 07:21:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 07:21:30 --> Form Validation Class Initialized
INFO - 2018-01-22 07:21:30 --> Model Class Initialized
INFO - 2018-01-22 07:21:30 --> Controller Class Initialized
INFO - 2018-01-22 07:21:30 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-22 07:21:30 --> Final output sent to browser
DEBUG - 2018-01-22 07:21:30 --> Total execution time: 0.0820
INFO - 2018-01-22 07:21:30 --> Config Class Initialized
INFO - 2018-01-22 07:21:30 --> Hooks Class Initialized
DEBUG - 2018-01-22 07:21:30 --> UTF-8 Support Enabled
INFO - 2018-01-22 07:21:30 --> Utf8 Class Initialized
INFO - 2018-01-22 07:21:30 --> URI Class Initialized
INFO - 2018-01-22 07:21:30 --> Router Class Initialized
INFO - 2018-01-22 07:21:30 --> Output Class Initialized
INFO - 2018-01-22 07:21:30 --> Security Class Initialized
DEBUG - 2018-01-22 07:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 07:21:30 --> Input Class Initialized
INFO - 2018-01-22 07:21:30 --> Language Class Initialized
INFO - 2018-01-22 07:21:30 --> Loader Class Initialized
INFO - 2018-01-22 07:21:30 --> Helper loaded: url_helper
INFO - 2018-01-22 07:21:30 --> Helper loaded: form_helper
INFO - 2018-01-22 07:21:30 --> Database Driver Class Initialized
DEBUG - 2018-01-22 07:21:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 07:21:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 07:21:30 --> Form Validation Class Initialized
INFO - 2018-01-22 07:21:30 --> Model Class Initialized
INFO - 2018-01-22 07:21:30 --> Controller Class Initialized
INFO - 2018-01-22 07:21:30 --> Model Class Initialized
INFO - 2018-01-22 07:21:30 --> Model Class Initialized
INFO - 2018-01-22 07:21:30 --> Model Class Initialized
INFO - 2018-01-22 07:21:30 --> Model Class Initialized
DEBUG - 2018-01-22 07:21:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-22 07:21:32 --> Config Class Initialized
INFO - 2018-01-22 07:21:32 --> Hooks Class Initialized
DEBUG - 2018-01-22 07:21:32 --> UTF-8 Support Enabled
INFO - 2018-01-22 07:21:32 --> Utf8 Class Initialized
INFO - 2018-01-22 07:21:32 --> URI Class Initialized
INFO - 2018-01-22 07:21:32 --> Router Class Initialized
INFO - 2018-01-22 07:21:32 --> Output Class Initialized
INFO - 2018-01-22 07:21:32 --> Security Class Initialized
DEBUG - 2018-01-22 07:21:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 07:21:32 --> Input Class Initialized
INFO - 2018-01-22 07:21:32 --> Language Class Initialized
INFO - 2018-01-22 07:21:32 --> Loader Class Initialized
INFO - 2018-01-22 07:21:32 --> Helper loaded: url_helper
INFO - 2018-01-22 07:21:32 --> Helper loaded: form_helper
INFO - 2018-01-22 07:21:32 --> Database Driver Class Initialized
DEBUG - 2018-01-22 07:21:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 07:21:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 07:21:32 --> Form Validation Class Initialized
INFO - 2018-01-22 07:21:32 --> Model Class Initialized
INFO - 2018-01-22 07:21:32 --> Controller Class Initialized
INFO - 2018-01-22 07:21:32 --> Model Class Initialized
DEBUG - 2018-01-22 07:21:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-22 07:21:32 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-22 07:21:32 --> Final output sent to browser
DEBUG - 2018-01-22 07:21:32 --> Total execution time: 0.0904
INFO - 2018-01-22 07:21:32 --> Config Class Initialized
INFO - 2018-01-22 07:21:32 --> Hooks Class Initialized
DEBUG - 2018-01-22 07:21:32 --> UTF-8 Support Enabled
INFO - 2018-01-22 07:21:32 --> Utf8 Class Initialized
INFO - 2018-01-22 07:21:32 --> URI Class Initialized
INFO - 2018-01-22 07:21:32 --> Router Class Initialized
INFO - 2018-01-22 07:21:32 --> Output Class Initialized
INFO - 2018-01-22 07:21:32 --> Security Class Initialized
DEBUG - 2018-01-22 07:21:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 07:21:32 --> Input Class Initialized
INFO - 2018-01-22 07:21:32 --> Language Class Initialized
INFO - 2018-01-22 07:21:32 --> Loader Class Initialized
INFO - 2018-01-22 07:21:32 --> Helper loaded: url_helper
INFO - 2018-01-22 07:21:32 --> Helper loaded: form_helper
INFO - 2018-01-22 07:21:32 --> Database Driver Class Initialized
DEBUG - 2018-01-22 07:21:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 07:21:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 07:21:32 --> Form Validation Class Initialized
INFO - 2018-01-22 07:21:32 --> Model Class Initialized
INFO - 2018-01-22 07:21:32 --> Controller Class Initialized
INFO - 2018-01-22 07:21:32 --> Model Class Initialized
DEBUG - 2018-01-22 07:21:32 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-01-22 07:21:32 --> Query error: Column 'estado_id' in where clause is ambiguous - Invalid query: SELECT *
FROM `usuario`
JOIN `usuario_estado` ON `usuario_estado`.`estado_id` = `usuario`.`estado_id`
JOIN `usuario_detalle` ON `usuario_detalle`.`usuario_id` = `usuario`.`usuario_id`
JOIN `usuario_rol` ON `usuario_rol`.`rol_id` = `usuario`.`rol_id`
WHERE `usuario` LIKE '%%' ESCAPE '!'
AND  `nombre` LIKE '%%' ESCAPE '!'
AND  `correo` LIKE '%%' ESCAPE '!'
AND `estado_id` = 1
INFO - 2018-01-22 07:21:32 --> Language file loaded: language/english/db_lang.php
INFO - 2018-01-22 07:22:10 --> Config Class Initialized
INFO - 2018-01-22 07:22:10 --> Hooks Class Initialized
DEBUG - 2018-01-22 07:22:10 --> UTF-8 Support Enabled
INFO - 2018-01-22 07:22:10 --> Utf8 Class Initialized
INFO - 2018-01-22 07:22:10 --> URI Class Initialized
INFO - 2018-01-22 07:22:10 --> Router Class Initialized
INFO - 2018-01-22 07:22:10 --> Output Class Initialized
INFO - 2018-01-22 07:22:10 --> Security Class Initialized
DEBUG - 2018-01-22 07:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 07:22:10 --> Input Class Initialized
INFO - 2018-01-22 07:22:10 --> Language Class Initialized
INFO - 2018-01-22 07:22:10 --> Loader Class Initialized
INFO - 2018-01-22 07:22:10 --> Helper loaded: url_helper
INFO - 2018-01-22 07:22:10 --> Helper loaded: form_helper
INFO - 2018-01-22 07:22:10 --> Database Driver Class Initialized
DEBUG - 2018-01-22 07:22:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 07:22:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 07:22:10 --> Form Validation Class Initialized
INFO - 2018-01-22 07:22:10 --> Model Class Initialized
INFO - 2018-01-22 07:22:10 --> Controller Class Initialized
INFO - 2018-01-22 07:22:10 --> Model Class Initialized
DEBUG - 2018-01-22 07:22:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-22 07:22:10 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-22 07:22:10 --> Final output sent to browser
DEBUG - 2018-01-22 07:22:10 --> Total execution time: 0.0617
INFO - 2018-01-22 07:22:12 --> Config Class Initialized
INFO - 2018-01-22 07:22:12 --> Hooks Class Initialized
DEBUG - 2018-01-22 07:22:12 --> UTF-8 Support Enabled
INFO - 2018-01-22 07:22:12 --> Utf8 Class Initialized
INFO - 2018-01-22 07:22:12 --> URI Class Initialized
INFO - 2018-01-22 07:22:12 --> Router Class Initialized
INFO - 2018-01-22 07:22:12 --> Output Class Initialized
INFO - 2018-01-22 07:22:12 --> Security Class Initialized
DEBUG - 2018-01-22 07:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 07:22:12 --> Input Class Initialized
INFO - 2018-01-22 07:22:12 --> Language Class Initialized
INFO - 2018-01-22 07:22:12 --> Loader Class Initialized
INFO - 2018-01-22 07:22:12 --> Helper loaded: url_helper
INFO - 2018-01-22 07:22:12 --> Helper loaded: form_helper
INFO - 2018-01-22 07:22:12 --> Database Driver Class Initialized
DEBUG - 2018-01-22 07:22:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 07:22:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 07:22:12 --> Form Validation Class Initialized
INFO - 2018-01-22 07:22:12 --> Model Class Initialized
INFO - 2018-01-22 07:22:12 --> Controller Class Initialized
INFO - 2018-01-22 07:22:12 --> Model Class Initialized
DEBUG - 2018-01-22 07:22:12 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-01-22 07:22:12 --> Query error: Column 'estado_id' in where clause is ambiguous - Invalid query: SELECT *
FROM `usuario`
JOIN `usuario_estado` ON `usuario_estado`.`estado_id` = `usuario`.`estado_id`
JOIN `usuario_detalle` ON `usuario_detalle`.`usuario_id` = `usuario`.`usuario_id`
JOIN `usuario_rol` ON `usuario_rol`.`rol_id` = `usuario`.`rol_id`
WHERE `usuario` LIKE '%%' ESCAPE '!'
AND  `nombre` LIKE '%%' ESCAPE '!'
AND  `correo` LIKE '%%' ESCAPE '!'
AND `estado_id` = 1
INFO - 2018-01-22 07:22:12 --> Language file loaded: language/english/db_lang.php
INFO - 2018-01-22 07:27:03 --> Config Class Initialized
INFO - 2018-01-22 07:27:03 --> Hooks Class Initialized
DEBUG - 2018-01-22 07:27:03 --> UTF-8 Support Enabled
INFO - 2018-01-22 07:27:03 --> Utf8 Class Initialized
INFO - 2018-01-22 07:27:03 --> URI Class Initialized
INFO - 2018-01-22 07:27:03 --> Router Class Initialized
INFO - 2018-01-22 07:27:03 --> Output Class Initialized
INFO - 2018-01-22 07:27:03 --> Security Class Initialized
DEBUG - 2018-01-22 07:27:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 07:27:03 --> Input Class Initialized
INFO - 2018-01-22 07:27:03 --> Language Class Initialized
INFO - 2018-01-22 07:27:03 --> Loader Class Initialized
INFO - 2018-01-22 07:27:03 --> Helper loaded: url_helper
INFO - 2018-01-22 07:27:03 --> Helper loaded: form_helper
INFO - 2018-01-22 07:27:03 --> Database Driver Class Initialized
DEBUG - 2018-01-22 07:27:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 07:27:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 07:27:03 --> Form Validation Class Initialized
INFO - 2018-01-22 07:27:03 --> Model Class Initialized
INFO - 2018-01-22 07:27:03 --> Controller Class Initialized
INFO - 2018-01-22 07:27:03 --> Model Class Initialized
DEBUG - 2018-01-22 07:27:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-22 07:27:03 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-22 07:27:03 --> Final output sent to browser
DEBUG - 2018-01-22 07:27:03 --> Total execution time: 0.0445
INFO - 2018-01-22 07:27:04 --> Config Class Initialized
INFO - 2018-01-22 07:27:04 --> Hooks Class Initialized
DEBUG - 2018-01-22 07:27:04 --> UTF-8 Support Enabled
INFO - 2018-01-22 07:27:04 --> Utf8 Class Initialized
INFO - 2018-01-22 07:27:04 --> URI Class Initialized
INFO - 2018-01-22 07:27:04 --> Router Class Initialized
INFO - 2018-01-22 07:27:04 --> Output Class Initialized
INFO - 2018-01-22 07:27:04 --> Security Class Initialized
DEBUG - 2018-01-22 07:27:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 07:27:04 --> Input Class Initialized
INFO - 2018-01-22 07:27:04 --> Language Class Initialized
INFO - 2018-01-22 07:27:04 --> Loader Class Initialized
INFO - 2018-01-22 07:27:04 --> Helper loaded: url_helper
INFO - 2018-01-22 07:27:04 --> Helper loaded: form_helper
INFO - 2018-01-22 07:27:04 --> Database Driver Class Initialized
DEBUG - 2018-01-22 07:27:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 07:27:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 07:27:04 --> Form Validation Class Initialized
INFO - 2018-01-22 07:27:04 --> Model Class Initialized
INFO - 2018-01-22 07:27:04 --> Controller Class Initialized
INFO - 2018-01-22 07:27:04 --> Model Class Initialized
DEBUG - 2018-01-22 07:27:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-22 07:29:59 --> Config Class Initialized
INFO - 2018-01-22 07:29:59 --> Hooks Class Initialized
DEBUG - 2018-01-22 07:29:59 --> UTF-8 Support Enabled
INFO - 2018-01-22 07:29:59 --> Utf8 Class Initialized
INFO - 2018-01-22 07:29:59 --> URI Class Initialized
INFO - 2018-01-22 07:29:59 --> Router Class Initialized
INFO - 2018-01-22 07:29:59 --> Output Class Initialized
INFO - 2018-01-22 07:29:59 --> Security Class Initialized
DEBUG - 2018-01-22 07:29:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 07:29:59 --> Input Class Initialized
INFO - 2018-01-22 07:29:59 --> Language Class Initialized
INFO - 2018-01-22 07:29:59 --> Loader Class Initialized
INFO - 2018-01-22 07:29:59 --> Helper loaded: url_helper
INFO - 2018-01-22 07:30:00 --> Helper loaded: form_helper
INFO - 2018-01-22 07:30:00 --> Database Driver Class Initialized
DEBUG - 2018-01-22 07:30:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 07:30:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 07:30:00 --> Form Validation Class Initialized
INFO - 2018-01-22 07:30:00 --> Model Class Initialized
INFO - 2018-01-22 07:30:00 --> Controller Class Initialized
INFO - 2018-01-22 07:30:00 --> Model Class Initialized
DEBUG - 2018-01-22 07:30:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-22 07:30:00 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-22 07:30:00 --> Final output sent to browser
DEBUG - 2018-01-22 07:30:00 --> Total execution time: 0.0834
INFO - 2018-01-22 07:30:01 --> Config Class Initialized
INFO - 2018-01-22 07:30:01 --> Hooks Class Initialized
DEBUG - 2018-01-22 07:30:01 --> UTF-8 Support Enabled
INFO - 2018-01-22 07:30:01 --> Utf8 Class Initialized
INFO - 2018-01-22 07:30:01 --> URI Class Initialized
INFO - 2018-01-22 07:30:01 --> Router Class Initialized
INFO - 2018-01-22 07:30:01 --> Output Class Initialized
INFO - 2018-01-22 07:30:01 --> Security Class Initialized
DEBUG - 2018-01-22 07:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 07:30:01 --> Input Class Initialized
INFO - 2018-01-22 07:30:01 --> Language Class Initialized
INFO - 2018-01-22 07:30:01 --> Loader Class Initialized
INFO - 2018-01-22 07:30:01 --> Helper loaded: url_helper
INFO - 2018-01-22 07:30:01 --> Helper loaded: form_helper
INFO - 2018-01-22 07:30:01 --> Database Driver Class Initialized
DEBUG - 2018-01-22 07:30:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 07:30:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 07:30:01 --> Form Validation Class Initialized
INFO - 2018-01-22 07:30:01 --> Model Class Initialized
INFO - 2018-01-22 07:30:01 --> Controller Class Initialized
INFO - 2018-01-22 07:30:01 --> Model Class Initialized
DEBUG - 2018-01-22 07:30:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-22 07:30:14 --> Config Class Initialized
INFO - 2018-01-22 07:30:14 --> Hooks Class Initialized
DEBUG - 2018-01-22 07:30:14 --> UTF-8 Support Enabled
INFO - 2018-01-22 07:30:14 --> Utf8 Class Initialized
INFO - 2018-01-22 07:30:14 --> URI Class Initialized
INFO - 2018-01-22 07:30:14 --> Router Class Initialized
INFO - 2018-01-22 07:30:14 --> Output Class Initialized
INFO - 2018-01-22 07:30:14 --> Security Class Initialized
DEBUG - 2018-01-22 07:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 07:30:14 --> Input Class Initialized
INFO - 2018-01-22 07:30:14 --> Language Class Initialized
INFO - 2018-01-22 07:30:14 --> Loader Class Initialized
INFO - 2018-01-22 07:30:14 --> Helper loaded: url_helper
INFO - 2018-01-22 07:30:14 --> Helper loaded: form_helper
INFO - 2018-01-22 07:30:14 --> Database Driver Class Initialized
DEBUG - 2018-01-22 07:30:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 07:30:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 07:30:14 --> Form Validation Class Initialized
INFO - 2018-01-22 07:30:14 --> Model Class Initialized
INFO - 2018-01-22 07:30:14 --> Controller Class Initialized
INFO - 2018-01-22 07:30:14 --> Model Class Initialized
DEBUG - 2018-01-22 07:30:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-22 07:30:19 --> Config Class Initialized
INFO - 2018-01-22 07:30:19 --> Hooks Class Initialized
DEBUG - 2018-01-22 07:30:19 --> UTF-8 Support Enabled
INFO - 2018-01-22 07:30:19 --> Utf8 Class Initialized
INFO - 2018-01-22 07:30:19 --> URI Class Initialized
INFO - 2018-01-22 07:30:19 --> Router Class Initialized
INFO - 2018-01-22 07:30:19 --> Output Class Initialized
INFO - 2018-01-22 07:30:19 --> Security Class Initialized
DEBUG - 2018-01-22 07:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 07:30:19 --> Input Class Initialized
INFO - 2018-01-22 07:30:19 --> Language Class Initialized
INFO - 2018-01-22 07:30:19 --> Loader Class Initialized
INFO - 2018-01-22 07:30:19 --> Helper loaded: url_helper
INFO - 2018-01-22 07:30:19 --> Helper loaded: form_helper
INFO - 2018-01-22 07:30:19 --> Database Driver Class Initialized
DEBUG - 2018-01-22 07:30:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 07:30:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 07:30:19 --> Form Validation Class Initialized
INFO - 2018-01-22 07:30:19 --> Model Class Initialized
INFO - 2018-01-22 07:30:19 --> Controller Class Initialized
INFO - 2018-01-22 07:30:19 --> Model Class Initialized
DEBUG - 2018-01-22 07:30:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-22 07:30:23 --> Config Class Initialized
INFO - 2018-01-22 07:30:23 --> Hooks Class Initialized
DEBUG - 2018-01-22 07:30:23 --> UTF-8 Support Enabled
INFO - 2018-01-22 07:30:23 --> Utf8 Class Initialized
INFO - 2018-01-22 07:30:23 --> URI Class Initialized
INFO - 2018-01-22 07:30:23 --> Router Class Initialized
INFO - 2018-01-22 07:30:23 --> Output Class Initialized
INFO - 2018-01-22 07:30:23 --> Security Class Initialized
DEBUG - 2018-01-22 07:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 07:30:23 --> Input Class Initialized
INFO - 2018-01-22 07:30:23 --> Language Class Initialized
INFO - 2018-01-22 07:30:23 --> Loader Class Initialized
INFO - 2018-01-22 07:30:23 --> Helper loaded: url_helper
INFO - 2018-01-22 07:30:23 --> Helper loaded: form_helper
INFO - 2018-01-22 07:30:23 --> Database Driver Class Initialized
DEBUG - 2018-01-22 07:30:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 07:30:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 07:30:23 --> Form Validation Class Initialized
INFO - 2018-01-22 07:30:23 --> Model Class Initialized
INFO - 2018-01-22 07:30:23 --> Controller Class Initialized
INFO - 2018-01-22 07:30:23 --> Model Class Initialized
DEBUG - 2018-01-22 07:30:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-22 07:30:25 --> Config Class Initialized
INFO - 2018-01-22 07:30:25 --> Hooks Class Initialized
DEBUG - 2018-01-22 07:30:25 --> UTF-8 Support Enabled
INFO - 2018-01-22 07:30:25 --> Utf8 Class Initialized
INFO - 2018-01-22 07:30:25 --> URI Class Initialized
INFO - 2018-01-22 07:30:25 --> Router Class Initialized
INFO - 2018-01-22 07:30:25 --> Output Class Initialized
INFO - 2018-01-22 07:30:25 --> Security Class Initialized
DEBUG - 2018-01-22 07:30:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 07:30:25 --> Input Class Initialized
INFO - 2018-01-22 07:30:25 --> Language Class Initialized
INFO - 2018-01-22 07:30:25 --> Loader Class Initialized
INFO - 2018-01-22 07:30:25 --> Helper loaded: url_helper
INFO - 2018-01-22 07:30:25 --> Helper loaded: form_helper
INFO - 2018-01-22 07:30:25 --> Database Driver Class Initialized
DEBUG - 2018-01-22 07:30:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 07:30:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 07:30:25 --> Form Validation Class Initialized
INFO - 2018-01-22 07:30:25 --> Model Class Initialized
INFO - 2018-01-22 07:30:25 --> Controller Class Initialized
INFO - 2018-01-22 07:30:25 --> Model Class Initialized
DEBUG - 2018-01-22 07:30:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-22 07:30:45 --> Config Class Initialized
INFO - 2018-01-22 07:30:45 --> Hooks Class Initialized
DEBUG - 2018-01-22 07:30:46 --> UTF-8 Support Enabled
INFO - 2018-01-22 07:30:46 --> Utf8 Class Initialized
INFO - 2018-01-22 07:30:46 --> URI Class Initialized
INFO - 2018-01-22 07:30:46 --> Router Class Initialized
INFO - 2018-01-22 07:30:46 --> Output Class Initialized
INFO - 2018-01-22 07:30:46 --> Security Class Initialized
DEBUG - 2018-01-22 07:30:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 07:30:46 --> Input Class Initialized
INFO - 2018-01-22 07:30:46 --> Language Class Initialized
INFO - 2018-01-22 07:30:46 --> Loader Class Initialized
INFO - 2018-01-22 07:30:46 --> Helper loaded: url_helper
INFO - 2018-01-22 07:30:46 --> Helper loaded: form_helper
INFO - 2018-01-22 07:30:46 --> Database Driver Class Initialized
DEBUG - 2018-01-22 07:30:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 07:30:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 07:30:46 --> Form Validation Class Initialized
INFO - 2018-01-22 07:30:46 --> Model Class Initialized
INFO - 2018-01-22 07:30:46 --> Controller Class Initialized
INFO - 2018-01-22 07:30:46 --> Model Class Initialized
DEBUG - 2018-01-22 07:30:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-22 07:30:46 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-22 07:30:46 --> Final output sent to browser
DEBUG - 2018-01-22 07:30:46 --> Total execution time: 0.0851
INFO - 2018-01-22 07:30:46 --> Config Class Initialized
INFO - 2018-01-22 07:30:46 --> Hooks Class Initialized
DEBUG - 2018-01-22 07:30:46 --> UTF-8 Support Enabled
INFO - 2018-01-22 07:30:46 --> Utf8 Class Initialized
INFO - 2018-01-22 07:30:46 --> URI Class Initialized
INFO - 2018-01-22 07:30:46 --> Router Class Initialized
INFO - 2018-01-22 07:30:46 --> Output Class Initialized
INFO - 2018-01-22 07:30:46 --> Security Class Initialized
DEBUG - 2018-01-22 07:30:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 07:30:46 --> Input Class Initialized
INFO - 2018-01-22 07:30:46 --> Language Class Initialized
INFO - 2018-01-22 07:30:46 --> Loader Class Initialized
INFO - 2018-01-22 07:30:46 --> Helper loaded: url_helper
INFO - 2018-01-22 07:30:46 --> Helper loaded: form_helper
INFO - 2018-01-22 07:30:46 --> Database Driver Class Initialized
DEBUG - 2018-01-22 07:30:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 07:30:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 07:30:46 --> Form Validation Class Initialized
INFO - 2018-01-22 07:30:46 --> Model Class Initialized
INFO - 2018-01-22 07:30:46 --> Controller Class Initialized
INFO - 2018-01-22 07:30:46 --> Model Class Initialized
DEBUG - 2018-01-22 07:30:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-22 07:31:03 --> Config Class Initialized
INFO - 2018-01-22 07:31:03 --> Hooks Class Initialized
DEBUG - 2018-01-22 07:31:03 --> UTF-8 Support Enabled
INFO - 2018-01-22 07:31:03 --> Utf8 Class Initialized
INFO - 2018-01-22 07:31:03 --> URI Class Initialized
INFO - 2018-01-22 07:31:03 --> Router Class Initialized
INFO - 2018-01-22 07:31:03 --> Output Class Initialized
INFO - 2018-01-22 07:31:03 --> Security Class Initialized
DEBUG - 2018-01-22 07:31:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 07:31:03 --> Input Class Initialized
INFO - 2018-01-22 07:31:03 --> Language Class Initialized
INFO - 2018-01-22 07:31:03 --> Loader Class Initialized
INFO - 2018-01-22 07:31:03 --> Helper loaded: url_helper
INFO - 2018-01-22 07:31:03 --> Helper loaded: form_helper
INFO - 2018-01-22 07:31:03 --> Database Driver Class Initialized
DEBUG - 2018-01-22 07:31:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 07:31:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 07:31:03 --> Form Validation Class Initialized
INFO - 2018-01-22 07:31:03 --> Model Class Initialized
INFO - 2018-01-22 07:31:03 --> Controller Class Initialized
INFO - 2018-01-22 07:31:03 --> Model Class Initialized
DEBUG - 2018-01-22 07:31:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-22 07:32:25 --> Config Class Initialized
INFO - 2018-01-22 07:32:25 --> Hooks Class Initialized
DEBUG - 2018-01-22 07:32:25 --> UTF-8 Support Enabled
INFO - 2018-01-22 07:32:25 --> Utf8 Class Initialized
INFO - 2018-01-22 07:32:25 --> URI Class Initialized
INFO - 2018-01-22 07:32:25 --> Router Class Initialized
INFO - 2018-01-22 07:32:25 --> Output Class Initialized
INFO - 2018-01-22 07:32:25 --> Security Class Initialized
DEBUG - 2018-01-22 07:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 07:32:25 --> Input Class Initialized
INFO - 2018-01-22 07:32:25 --> Language Class Initialized
INFO - 2018-01-22 07:32:25 --> Loader Class Initialized
INFO - 2018-01-22 07:32:25 --> Helper loaded: url_helper
INFO - 2018-01-22 07:32:25 --> Helper loaded: form_helper
INFO - 2018-01-22 07:32:25 --> Database Driver Class Initialized
DEBUG - 2018-01-22 07:32:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 07:32:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 07:32:25 --> Form Validation Class Initialized
INFO - 2018-01-22 07:32:25 --> Model Class Initialized
INFO - 2018-01-22 07:32:25 --> Controller Class Initialized
INFO - 2018-01-22 07:32:25 --> Model Class Initialized
DEBUG - 2018-01-22 07:32:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-22 07:32:25 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-22 07:32:25 --> Final output sent to browser
DEBUG - 2018-01-22 07:32:25 --> Total execution time: 0.0747
INFO - 2018-01-22 07:32:26 --> Config Class Initialized
INFO - 2018-01-22 07:32:26 --> Hooks Class Initialized
DEBUG - 2018-01-22 07:32:26 --> UTF-8 Support Enabled
INFO - 2018-01-22 07:32:26 --> Utf8 Class Initialized
INFO - 2018-01-22 07:32:26 --> URI Class Initialized
INFO - 2018-01-22 07:32:26 --> Router Class Initialized
INFO - 2018-01-22 07:32:26 --> Output Class Initialized
INFO - 2018-01-22 07:32:26 --> Security Class Initialized
DEBUG - 2018-01-22 07:32:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 07:32:26 --> Input Class Initialized
INFO - 2018-01-22 07:32:26 --> Language Class Initialized
INFO - 2018-01-22 07:32:26 --> Loader Class Initialized
INFO - 2018-01-22 07:32:26 --> Helper loaded: url_helper
INFO - 2018-01-22 07:32:26 --> Helper loaded: form_helper
INFO - 2018-01-22 07:32:26 --> Database Driver Class Initialized
DEBUG - 2018-01-22 07:32:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 07:32:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 07:32:26 --> Form Validation Class Initialized
INFO - 2018-01-22 07:32:26 --> Model Class Initialized
INFO - 2018-01-22 07:32:26 --> Controller Class Initialized
INFO - 2018-01-22 07:32:26 --> Model Class Initialized
DEBUG - 2018-01-22 07:32:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-22 07:32:30 --> Config Class Initialized
INFO - 2018-01-22 07:32:30 --> Hooks Class Initialized
DEBUG - 2018-01-22 07:32:30 --> UTF-8 Support Enabled
INFO - 2018-01-22 07:32:30 --> Utf8 Class Initialized
INFO - 2018-01-22 07:32:30 --> URI Class Initialized
INFO - 2018-01-22 07:32:30 --> Router Class Initialized
INFO - 2018-01-22 07:32:30 --> Output Class Initialized
INFO - 2018-01-22 07:32:30 --> Security Class Initialized
DEBUG - 2018-01-22 07:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 07:32:30 --> Input Class Initialized
INFO - 2018-01-22 07:32:30 --> Language Class Initialized
INFO - 2018-01-22 07:32:30 --> Loader Class Initialized
INFO - 2018-01-22 07:32:30 --> Helper loaded: url_helper
INFO - 2018-01-22 07:32:30 --> Helper loaded: form_helper
INFO - 2018-01-22 07:32:30 --> Database Driver Class Initialized
DEBUG - 2018-01-22 07:32:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 07:32:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 07:32:30 --> Form Validation Class Initialized
INFO - 2018-01-22 07:32:30 --> Model Class Initialized
INFO - 2018-01-22 07:32:30 --> Controller Class Initialized
INFO - 2018-01-22 07:32:30 --> Model Class Initialized
DEBUG - 2018-01-22 07:32:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-22 07:32:41 --> Config Class Initialized
INFO - 2018-01-22 07:32:41 --> Hooks Class Initialized
DEBUG - 2018-01-22 07:32:41 --> UTF-8 Support Enabled
INFO - 2018-01-22 07:32:41 --> Utf8 Class Initialized
INFO - 2018-01-22 07:32:41 --> URI Class Initialized
INFO - 2018-01-22 07:32:41 --> Router Class Initialized
INFO - 2018-01-22 07:32:41 --> Output Class Initialized
INFO - 2018-01-22 07:32:41 --> Security Class Initialized
DEBUG - 2018-01-22 07:32:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 07:32:41 --> Input Class Initialized
INFO - 2018-01-22 07:32:41 --> Language Class Initialized
INFO - 2018-01-22 07:32:41 --> Loader Class Initialized
INFO - 2018-01-22 07:32:41 --> Helper loaded: url_helper
INFO - 2018-01-22 07:32:41 --> Helper loaded: form_helper
INFO - 2018-01-22 07:32:41 --> Database Driver Class Initialized
DEBUG - 2018-01-22 07:32:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 07:32:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 07:32:41 --> Form Validation Class Initialized
INFO - 2018-01-22 07:32:41 --> Model Class Initialized
INFO - 2018-01-22 07:32:41 --> Controller Class Initialized
INFO - 2018-01-22 07:32:41 --> Model Class Initialized
DEBUG - 2018-01-22 07:32:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-22 07:44:34 --> Config Class Initialized
INFO - 2018-01-22 07:44:34 --> Hooks Class Initialized
DEBUG - 2018-01-22 07:44:34 --> UTF-8 Support Enabled
INFO - 2018-01-22 07:44:34 --> Utf8 Class Initialized
INFO - 2018-01-22 07:44:34 --> URI Class Initialized
INFO - 2018-01-22 07:44:34 --> Router Class Initialized
INFO - 2018-01-22 07:44:34 --> Output Class Initialized
INFO - 2018-01-22 07:44:34 --> Security Class Initialized
DEBUG - 2018-01-22 07:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 07:44:34 --> Input Class Initialized
INFO - 2018-01-22 07:44:34 --> Language Class Initialized
INFO - 2018-01-22 07:44:34 --> Loader Class Initialized
INFO - 2018-01-22 07:44:34 --> Helper loaded: url_helper
INFO - 2018-01-22 07:44:34 --> Helper loaded: form_helper
INFO - 2018-01-22 07:44:34 --> Database Driver Class Initialized
DEBUG - 2018-01-22 07:44:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 07:44:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 07:44:34 --> Form Validation Class Initialized
INFO - 2018-01-22 07:44:34 --> Model Class Initialized
INFO - 2018-01-22 07:44:34 --> Controller Class Initialized
INFO - 2018-01-22 07:44:34 --> Model Class Initialized
INFO - 2018-01-22 07:44:34 --> Model Class Initialized
INFO - 2018-01-22 07:44:34 --> Model Class Initialized
INFO - 2018-01-22 07:44:34 --> Model Class Initialized
DEBUG - 2018-01-22 07:44:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-22 07:44:34 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-22 07:44:34 --> Final output sent to browser
DEBUG - 2018-01-22 07:44:34 --> Total execution time: 0.1002
INFO - 2018-01-22 07:44:34 --> Config Class Initialized
INFO - 2018-01-22 07:44:34 --> Hooks Class Initialized
DEBUG - 2018-01-22 07:44:34 --> UTF-8 Support Enabled
INFO - 2018-01-22 07:44:34 --> Utf8 Class Initialized
INFO - 2018-01-22 07:44:34 --> URI Class Initialized
INFO - 2018-01-22 07:44:34 --> Router Class Initialized
INFO - 2018-01-22 07:44:34 --> Output Class Initialized
INFO - 2018-01-22 07:44:34 --> Security Class Initialized
DEBUG - 2018-01-22 07:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 07:44:34 --> Input Class Initialized
INFO - 2018-01-22 07:44:34 --> Language Class Initialized
INFO - 2018-01-22 07:44:34 --> Loader Class Initialized
INFO - 2018-01-22 07:44:34 --> Helper loaded: url_helper
INFO - 2018-01-22 07:44:34 --> Helper loaded: form_helper
INFO - 2018-01-22 07:44:34 --> Database Driver Class Initialized
DEBUG - 2018-01-22 07:44:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 07:44:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 07:44:35 --> Form Validation Class Initialized
INFO - 2018-01-22 07:44:35 --> Model Class Initialized
INFO - 2018-01-22 07:44:35 --> Controller Class Initialized
INFO - 2018-01-22 07:44:35 --> Model Class Initialized
INFO - 2018-01-22 07:44:35 --> Model Class Initialized
INFO - 2018-01-22 07:44:35 --> Model Class Initialized
INFO - 2018-01-22 07:44:35 --> Model Class Initialized
DEBUG - 2018-01-22 07:44:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-22 07:44:35 --> Config Class Initialized
INFO - 2018-01-22 07:44:35 --> Hooks Class Initialized
DEBUG - 2018-01-22 07:44:35 --> UTF-8 Support Enabled
INFO - 2018-01-22 07:44:35 --> Utf8 Class Initialized
INFO - 2018-01-22 07:44:35 --> URI Class Initialized
INFO - 2018-01-22 07:44:35 --> Router Class Initialized
INFO - 2018-01-22 07:44:35 --> Output Class Initialized
INFO - 2018-01-22 07:44:35 --> Security Class Initialized
DEBUG - 2018-01-22 07:44:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 07:44:35 --> Input Class Initialized
INFO - 2018-01-22 07:44:35 --> Language Class Initialized
INFO - 2018-01-22 07:44:35 --> Loader Class Initialized
INFO - 2018-01-22 07:44:35 --> Helper loaded: url_helper
INFO - 2018-01-22 07:44:35 --> Helper loaded: form_helper
INFO - 2018-01-22 07:44:35 --> Database Driver Class Initialized
DEBUG - 2018-01-22 07:44:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 07:44:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 07:44:35 --> Form Validation Class Initialized
INFO - 2018-01-22 07:44:35 --> Model Class Initialized
INFO - 2018-01-22 07:44:35 --> Controller Class Initialized
INFO - 2018-01-22 07:44:35 --> Model Class Initialized
INFO - 2018-01-22 07:44:35 --> Model Class Initialized
DEBUG - 2018-01-22 07:44:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-22 07:44:35 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-22 07:44:35 --> Final output sent to browser
DEBUG - 2018-01-22 07:44:35 --> Total execution time: 0.1182
INFO - 2018-01-22 07:44:35 --> Config Class Initialized
INFO - 2018-01-22 07:44:35 --> Hooks Class Initialized
DEBUG - 2018-01-22 07:44:35 --> UTF-8 Support Enabled
INFO - 2018-01-22 07:44:35 --> Utf8 Class Initialized
INFO - 2018-01-22 07:44:35 --> URI Class Initialized
INFO - 2018-01-22 07:44:35 --> Router Class Initialized
INFO - 2018-01-22 07:44:35 --> Output Class Initialized
INFO - 2018-01-22 07:44:35 --> Security Class Initialized
DEBUG - 2018-01-22 07:44:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 07:44:35 --> Input Class Initialized
INFO - 2018-01-22 07:44:35 --> Language Class Initialized
INFO - 2018-01-22 07:44:35 --> Loader Class Initialized
INFO - 2018-01-22 07:44:35 --> Helper loaded: url_helper
INFO - 2018-01-22 07:44:35 --> Helper loaded: form_helper
INFO - 2018-01-22 07:44:35 --> Database Driver Class Initialized
DEBUG - 2018-01-22 07:44:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 07:44:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 07:44:36 --> Form Validation Class Initialized
INFO - 2018-01-22 07:44:36 --> Model Class Initialized
INFO - 2018-01-22 07:44:36 --> Controller Class Initialized
INFO - 2018-01-22 07:44:36 --> Model Class Initialized
INFO - 2018-01-22 07:44:36 --> Model Class Initialized
DEBUG - 2018-01-22 07:44:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-22 07:44:37 --> Config Class Initialized
INFO - 2018-01-22 07:44:37 --> Hooks Class Initialized
DEBUG - 2018-01-22 07:44:37 --> UTF-8 Support Enabled
INFO - 2018-01-22 07:44:37 --> Utf8 Class Initialized
INFO - 2018-01-22 07:44:37 --> URI Class Initialized
INFO - 2018-01-22 07:44:37 --> Router Class Initialized
INFO - 2018-01-22 07:44:37 --> Output Class Initialized
INFO - 2018-01-22 07:44:37 --> Security Class Initialized
DEBUG - 2018-01-22 07:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 07:44:37 --> Input Class Initialized
INFO - 2018-01-22 07:44:37 --> Language Class Initialized
INFO - 2018-01-22 07:44:37 --> Loader Class Initialized
INFO - 2018-01-22 07:44:37 --> Helper loaded: url_helper
INFO - 2018-01-22 07:44:37 --> Helper loaded: form_helper
INFO - 2018-01-22 07:44:37 --> Database Driver Class Initialized
DEBUG - 2018-01-22 07:44:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 07:44:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 07:44:37 --> Form Validation Class Initialized
INFO - 2018-01-22 07:44:37 --> Model Class Initialized
INFO - 2018-01-22 07:44:37 --> Controller Class Initialized
INFO - 2018-01-22 07:44:37 --> Model Class Initialized
INFO - 2018-01-22 07:44:37 --> Model Class Initialized
DEBUG - 2018-01-22 07:44:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-22 07:44:37 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-22 07:44:37 --> Final output sent to browser
DEBUG - 2018-01-22 07:44:37 --> Total execution time: 0.1145
INFO - 2018-01-22 07:44:37 --> Config Class Initialized
INFO - 2018-01-22 07:44:37 --> Hooks Class Initialized
DEBUG - 2018-01-22 07:44:37 --> UTF-8 Support Enabled
INFO - 2018-01-22 07:44:37 --> Utf8 Class Initialized
INFO - 2018-01-22 07:44:37 --> URI Class Initialized
INFO - 2018-01-22 07:44:37 --> Router Class Initialized
INFO - 2018-01-22 07:44:37 --> Output Class Initialized
INFO - 2018-01-22 07:44:37 --> Security Class Initialized
DEBUG - 2018-01-22 07:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 07:44:37 --> Input Class Initialized
INFO - 2018-01-22 07:44:37 --> Language Class Initialized
INFO - 2018-01-22 07:44:37 --> Loader Class Initialized
INFO - 2018-01-22 07:44:37 --> Helper loaded: url_helper
INFO - 2018-01-22 07:44:37 --> Helper loaded: form_helper
INFO - 2018-01-22 07:44:37 --> Database Driver Class Initialized
DEBUG - 2018-01-22 07:44:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 07:44:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 07:44:37 --> Form Validation Class Initialized
INFO - 2018-01-22 07:44:37 --> Model Class Initialized
INFO - 2018-01-22 07:44:37 --> Controller Class Initialized
INFO - 2018-01-22 07:44:37 --> Model Class Initialized
INFO - 2018-01-22 07:44:37 --> Model Class Initialized
DEBUG - 2018-01-22 07:44:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-22 07:44:38 --> Config Class Initialized
INFO - 2018-01-22 07:44:38 --> Hooks Class Initialized
DEBUG - 2018-01-22 07:44:38 --> UTF-8 Support Enabled
INFO - 2018-01-22 07:44:38 --> Utf8 Class Initialized
INFO - 2018-01-22 07:44:38 --> URI Class Initialized
INFO - 2018-01-22 07:44:38 --> Router Class Initialized
INFO - 2018-01-22 07:44:38 --> Output Class Initialized
INFO - 2018-01-22 07:44:38 --> Security Class Initialized
DEBUG - 2018-01-22 07:44:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 07:44:38 --> Input Class Initialized
INFO - 2018-01-22 07:44:38 --> Language Class Initialized
INFO - 2018-01-22 07:44:38 --> Loader Class Initialized
INFO - 2018-01-22 07:44:38 --> Helper loaded: url_helper
INFO - 2018-01-22 07:44:38 --> Helper loaded: form_helper
INFO - 2018-01-22 07:44:38 --> Database Driver Class Initialized
DEBUG - 2018-01-22 07:44:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 07:44:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 07:44:38 --> Form Validation Class Initialized
INFO - 2018-01-22 07:44:38 --> Model Class Initialized
INFO - 2018-01-22 07:44:38 --> Controller Class Initialized
INFO - 2018-01-22 07:44:38 --> Model Class Initialized
INFO - 2018-01-22 07:44:38 --> Model Class Initialized
INFO - 2018-01-22 07:44:38 --> Model Class Initialized
INFO - 2018-01-22 07:44:38 --> Model Class Initialized
DEBUG - 2018-01-22 07:44:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-22 07:44:38 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-22 07:44:38 --> Final output sent to browser
DEBUG - 2018-01-22 07:44:38 --> Total execution time: 0.1054
INFO - 2018-01-22 07:44:39 --> Config Class Initialized
INFO - 2018-01-22 07:44:39 --> Hooks Class Initialized
DEBUG - 2018-01-22 07:44:39 --> UTF-8 Support Enabled
INFO - 2018-01-22 07:44:39 --> Utf8 Class Initialized
INFO - 2018-01-22 07:44:39 --> URI Class Initialized
INFO - 2018-01-22 07:44:39 --> Router Class Initialized
INFO - 2018-01-22 07:44:39 --> Output Class Initialized
INFO - 2018-01-22 07:44:39 --> Security Class Initialized
DEBUG - 2018-01-22 07:44:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 07:44:39 --> Input Class Initialized
INFO - 2018-01-22 07:44:39 --> Language Class Initialized
INFO - 2018-01-22 07:44:39 --> Loader Class Initialized
INFO - 2018-01-22 07:44:39 --> Helper loaded: url_helper
INFO - 2018-01-22 07:44:39 --> Helper loaded: form_helper
INFO - 2018-01-22 07:44:39 --> Database Driver Class Initialized
DEBUG - 2018-01-22 07:44:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 07:44:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 07:44:39 --> Form Validation Class Initialized
INFO - 2018-01-22 07:44:39 --> Model Class Initialized
INFO - 2018-01-22 07:44:39 --> Controller Class Initialized
INFO - 2018-01-22 07:44:39 --> Model Class Initialized
DEBUG - 2018-01-22 07:44:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-22 07:44:39 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-22 07:44:39 --> Final output sent to browser
DEBUG - 2018-01-22 07:44:39 --> Total execution time: 0.0911
INFO - 2018-01-22 07:44:40 --> Config Class Initialized
INFO - 2018-01-22 07:44:40 --> Hooks Class Initialized
DEBUG - 2018-01-22 07:44:40 --> UTF-8 Support Enabled
INFO - 2018-01-22 07:44:40 --> Utf8 Class Initialized
INFO - 2018-01-22 07:44:40 --> URI Class Initialized
INFO - 2018-01-22 07:44:40 --> Router Class Initialized
INFO - 2018-01-22 07:44:40 --> Output Class Initialized
INFO - 2018-01-22 07:44:40 --> Security Class Initialized
DEBUG - 2018-01-22 07:44:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 07:44:40 --> Input Class Initialized
INFO - 2018-01-22 07:44:40 --> Language Class Initialized
INFO - 2018-01-22 07:44:40 --> Loader Class Initialized
INFO - 2018-01-22 07:44:40 --> Helper loaded: url_helper
INFO - 2018-01-22 07:44:40 --> Helper loaded: form_helper
INFO - 2018-01-22 07:44:40 --> Database Driver Class Initialized
DEBUG - 2018-01-22 07:44:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 07:44:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 07:44:40 --> Form Validation Class Initialized
INFO - 2018-01-22 07:44:40 --> Model Class Initialized
INFO - 2018-01-22 07:44:40 --> Controller Class Initialized
INFO - 2018-01-22 07:44:40 --> Model Class Initialized
DEBUG - 2018-01-22 07:44:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-22 07:44:44 --> Config Class Initialized
INFO - 2018-01-22 07:44:44 --> Hooks Class Initialized
DEBUG - 2018-01-22 07:44:44 --> UTF-8 Support Enabled
INFO - 2018-01-22 07:44:44 --> Utf8 Class Initialized
INFO - 2018-01-22 07:44:44 --> URI Class Initialized
INFO - 2018-01-22 07:44:44 --> Router Class Initialized
INFO - 2018-01-22 07:44:44 --> Output Class Initialized
INFO - 2018-01-22 07:44:44 --> Security Class Initialized
DEBUG - 2018-01-22 07:44:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 07:44:44 --> Input Class Initialized
INFO - 2018-01-22 07:44:44 --> Language Class Initialized
INFO - 2018-01-22 07:44:44 --> Loader Class Initialized
INFO - 2018-01-22 07:44:44 --> Helper loaded: url_helper
INFO - 2018-01-22 07:44:44 --> Helper loaded: form_helper
INFO - 2018-01-22 07:44:44 --> Database Driver Class Initialized
DEBUG - 2018-01-22 07:44:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 07:44:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 07:44:44 --> Form Validation Class Initialized
INFO - 2018-01-22 07:44:44 --> Model Class Initialized
INFO - 2018-01-22 07:44:44 --> Controller Class Initialized
INFO - 2018-01-22 07:44:44 --> Model Class Initialized
INFO - 2018-01-22 07:44:44 --> Model Class Initialized
INFO - 2018-01-22 07:44:44 --> Model Class Initialized
INFO - 2018-01-22 07:44:44 --> Model Class Initialized
DEBUG - 2018-01-22 07:44:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-22 07:44:44 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-22 07:44:44 --> Final output sent to browser
DEBUG - 2018-01-22 07:44:44 --> Total execution time: 0.0897
INFO - 2018-01-22 07:44:44 --> Config Class Initialized
INFO - 2018-01-22 07:44:44 --> Hooks Class Initialized
DEBUG - 2018-01-22 07:44:45 --> UTF-8 Support Enabled
INFO - 2018-01-22 07:44:45 --> Utf8 Class Initialized
INFO - 2018-01-22 07:44:45 --> URI Class Initialized
INFO - 2018-01-22 07:44:45 --> Router Class Initialized
INFO - 2018-01-22 07:44:45 --> Output Class Initialized
INFO - 2018-01-22 07:44:45 --> Security Class Initialized
DEBUG - 2018-01-22 07:44:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 07:44:45 --> Input Class Initialized
INFO - 2018-01-22 07:44:45 --> Language Class Initialized
INFO - 2018-01-22 07:44:45 --> Loader Class Initialized
INFO - 2018-01-22 07:44:45 --> Helper loaded: url_helper
INFO - 2018-01-22 07:44:45 --> Helper loaded: form_helper
INFO - 2018-01-22 07:44:45 --> Database Driver Class Initialized
DEBUG - 2018-01-22 07:44:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 07:44:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 07:44:45 --> Form Validation Class Initialized
INFO - 2018-01-22 07:44:45 --> Model Class Initialized
INFO - 2018-01-22 07:44:45 --> Controller Class Initialized
INFO - 2018-01-22 07:44:45 --> Model Class Initialized
INFO - 2018-01-22 07:44:45 --> Model Class Initialized
INFO - 2018-01-22 07:44:45 --> Model Class Initialized
INFO - 2018-01-22 07:44:45 --> Model Class Initialized
DEBUG - 2018-01-22 07:44:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-22 07:44:47 --> Config Class Initialized
INFO - 2018-01-22 07:44:47 --> Hooks Class Initialized
DEBUG - 2018-01-22 07:44:47 --> UTF-8 Support Enabled
INFO - 2018-01-22 07:44:47 --> Utf8 Class Initialized
INFO - 2018-01-22 07:44:47 --> URI Class Initialized
INFO - 2018-01-22 07:44:47 --> Router Class Initialized
INFO - 2018-01-22 07:44:47 --> Output Class Initialized
INFO - 2018-01-22 07:44:47 --> Security Class Initialized
DEBUG - 2018-01-22 07:44:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 07:44:47 --> Input Class Initialized
INFO - 2018-01-22 07:44:47 --> Language Class Initialized
INFO - 2018-01-22 07:44:47 --> Loader Class Initialized
INFO - 2018-01-22 07:44:47 --> Helper loaded: url_helper
INFO - 2018-01-22 07:44:47 --> Helper loaded: form_helper
INFO - 2018-01-22 07:44:48 --> Database Driver Class Initialized
DEBUG - 2018-01-22 07:44:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 07:44:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 07:44:48 --> Form Validation Class Initialized
INFO - 2018-01-22 07:44:48 --> Model Class Initialized
INFO - 2018-01-22 07:44:48 --> Controller Class Initialized
INFO - 2018-01-22 07:44:48 --> Model Class Initialized
INFO - 2018-01-22 07:44:48 --> Model Class Initialized
INFO - 2018-01-22 07:44:48 --> Model Class Initialized
INFO - 2018-01-22 07:44:48 --> Model Class Initialized
DEBUG - 2018-01-22 07:44:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-22 07:44:54 --> Config Class Initialized
INFO - 2018-01-22 07:44:54 --> Hooks Class Initialized
DEBUG - 2018-01-22 07:44:54 --> UTF-8 Support Enabled
INFO - 2018-01-22 07:44:54 --> Utf8 Class Initialized
INFO - 2018-01-22 07:44:54 --> URI Class Initialized
INFO - 2018-01-22 07:44:54 --> Router Class Initialized
INFO - 2018-01-22 07:44:54 --> Output Class Initialized
INFO - 2018-01-22 07:44:54 --> Security Class Initialized
DEBUG - 2018-01-22 07:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 07:44:54 --> Input Class Initialized
INFO - 2018-01-22 07:44:54 --> Language Class Initialized
INFO - 2018-01-22 07:44:54 --> Loader Class Initialized
INFO - 2018-01-22 07:44:54 --> Helper loaded: url_helper
INFO - 2018-01-22 07:44:54 --> Helper loaded: form_helper
INFO - 2018-01-22 07:44:54 --> Database Driver Class Initialized
DEBUG - 2018-01-22 07:44:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 07:44:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 07:44:54 --> Form Validation Class Initialized
INFO - 2018-01-22 07:44:54 --> Model Class Initialized
INFO - 2018-01-22 07:44:54 --> Controller Class Initialized
INFO - 2018-01-22 07:44:54 --> Model Class Initialized
INFO - 2018-01-22 07:44:54 --> Model Class Initialized
INFO - 2018-01-22 07:44:54 --> Model Class Initialized
INFO - 2018-01-22 07:44:54 --> Model Class Initialized
DEBUG - 2018-01-22 07:44:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-22 07:44:58 --> Config Class Initialized
INFO - 2018-01-22 07:44:58 --> Hooks Class Initialized
DEBUG - 2018-01-22 07:44:58 --> UTF-8 Support Enabled
INFO - 2018-01-22 07:44:58 --> Utf8 Class Initialized
INFO - 2018-01-22 07:44:58 --> URI Class Initialized
INFO - 2018-01-22 07:44:59 --> Router Class Initialized
INFO - 2018-01-22 07:44:59 --> Output Class Initialized
INFO - 2018-01-22 07:44:59 --> Security Class Initialized
DEBUG - 2018-01-22 07:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 07:44:59 --> Input Class Initialized
INFO - 2018-01-22 07:44:59 --> Language Class Initialized
INFO - 2018-01-22 07:44:59 --> Loader Class Initialized
INFO - 2018-01-22 07:44:59 --> Helper loaded: url_helper
INFO - 2018-01-22 07:44:59 --> Helper loaded: form_helper
INFO - 2018-01-22 07:44:59 --> Database Driver Class Initialized
DEBUG - 2018-01-22 07:44:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 07:44:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 07:44:59 --> Form Validation Class Initialized
INFO - 2018-01-22 07:44:59 --> Model Class Initialized
INFO - 2018-01-22 07:44:59 --> Controller Class Initialized
INFO - 2018-01-22 07:44:59 --> Model Class Initialized
DEBUG - 2018-01-22 07:44:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-22 07:44:59 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-22 07:44:59 --> Final output sent to browser
DEBUG - 2018-01-22 07:44:59 --> Total execution time: 0.0814
INFO - 2018-01-22 07:44:59 --> Config Class Initialized
INFO - 2018-01-22 07:44:59 --> Hooks Class Initialized
DEBUG - 2018-01-22 07:44:59 --> UTF-8 Support Enabled
INFO - 2018-01-22 07:44:59 --> Utf8 Class Initialized
INFO - 2018-01-22 07:44:59 --> URI Class Initialized
INFO - 2018-01-22 07:44:59 --> Router Class Initialized
INFO - 2018-01-22 07:44:59 --> Output Class Initialized
INFO - 2018-01-22 07:44:59 --> Security Class Initialized
DEBUG - 2018-01-22 07:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 07:44:59 --> Input Class Initialized
INFO - 2018-01-22 07:44:59 --> Language Class Initialized
INFO - 2018-01-22 07:44:59 --> Loader Class Initialized
INFO - 2018-01-22 07:44:59 --> Helper loaded: url_helper
INFO - 2018-01-22 07:44:59 --> Helper loaded: form_helper
INFO - 2018-01-22 07:44:59 --> Database Driver Class Initialized
DEBUG - 2018-01-22 07:44:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 07:44:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 07:44:59 --> Form Validation Class Initialized
INFO - 2018-01-22 07:44:59 --> Model Class Initialized
INFO - 2018-01-22 07:44:59 --> Controller Class Initialized
INFO - 2018-01-22 07:44:59 --> Model Class Initialized
DEBUG - 2018-01-22 07:44:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-22 07:45:19 --> Config Class Initialized
INFO - 2018-01-22 07:45:19 --> Hooks Class Initialized
DEBUG - 2018-01-22 07:45:19 --> UTF-8 Support Enabled
INFO - 2018-01-22 07:45:19 --> Utf8 Class Initialized
INFO - 2018-01-22 07:45:19 --> URI Class Initialized
INFO - 2018-01-22 07:45:19 --> Router Class Initialized
INFO - 2018-01-22 07:45:19 --> Output Class Initialized
INFO - 2018-01-22 07:45:19 --> Security Class Initialized
DEBUG - 2018-01-22 07:45:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 07:45:19 --> Input Class Initialized
INFO - 2018-01-22 07:45:19 --> Language Class Initialized
ERROR - 2018-01-22 07:45:19 --> 404 Page Not Found: Usuario/agregarUsuario
INFO - 2018-01-22 07:50:43 --> Config Class Initialized
INFO - 2018-01-22 07:50:43 --> Hooks Class Initialized
DEBUG - 2018-01-22 07:50:43 --> UTF-8 Support Enabled
INFO - 2018-01-22 07:50:43 --> Utf8 Class Initialized
INFO - 2018-01-22 07:50:43 --> URI Class Initialized
INFO - 2018-01-22 07:50:43 --> Router Class Initialized
INFO - 2018-01-22 07:50:43 --> Output Class Initialized
INFO - 2018-01-22 07:50:43 --> Security Class Initialized
DEBUG - 2018-01-22 07:50:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 07:50:43 --> Input Class Initialized
INFO - 2018-01-22 07:50:43 --> Language Class Initialized
INFO - 2018-01-22 07:50:43 --> Loader Class Initialized
INFO - 2018-01-22 07:50:43 --> Helper loaded: url_helper
INFO - 2018-01-22 07:50:43 --> Helper loaded: form_helper
INFO - 2018-01-22 07:50:43 --> Database Driver Class Initialized
DEBUG - 2018-01-22 07:50:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 07:50:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 07:50:43 --> Form Validation Class Initialized
INFO - 2018-01-22 07:50:43 --> Model Class Initialized
INFO - 2018-01-22 07:50:43 --> Controller Class Initialized
INFO - 2018-01-22 07:50:43 --> Model Class Initialized
DEBUG - 2018-01-22 07:50:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-22 07:50:43 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-22 07:50:43 --> Final output sent to browser
DEBUG - 2018-01-22 07:50:43 --> Total execution time: 0.0953
INFO - 2018-01-22 07:50:43 --> Config Class Initialized
INFO - 2018-01-22 07:50:43 --> Hooks Class Initialized
DEBUG - 2018-01-22 07:50:43 --> UTF-8 Support Enabled
INFO - 2018-01-22 07:50:43 --> Utf8 Class Initialized
INFO - 2018-01-22 07:50:43 --> URI Class Initialized
INFO - 2018-01-22 07:50:43 --> Router Class Initialized
INFO - 2018-01-22 07:50:43 --> Output Class Initialized
INFO - 2018-01-22 07:50:43 --> Security Class Initialized
DEBUG - 2018-01-22 07:50:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 07:50:43 --> Input Class Initialized
INFO - 2018-01-22 07:50:43 --> Language Class Initialized
INFO - 2018-01-22 07:50:43 --> Loader Class Initialized
INFO - 2018-01-22 07:50:43 --> Helper loaded: url_helper
INFO - 2018-01-22 07:50:43 --> Helper loaded: form_helper
INFO - 2018-01-22 07:50:43 --> Database Driver Class Initialized
DEBUG - 2018-01-22 07:50:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 07:50:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 07:50:43 --> Form Validation Class Initialized
INFO - 2018-01-22 07:50:43 --> Model Class Initialized
INFO - 2018-01-22 07:50:43 --> Controller Class Initialized
INFO - 2018-01-22 07:50:43 --> Model Class Initialized
DEBUG - 2018-01-22 07:50:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-22 07:53:18 --> Config Class Initialized
INFO - 2018-01-22 07:53:18 --> Hooks Class Initialized
DEBUG - 2018-01-22 07:53:18 --> UTF-8 Support Enabled
INFO - 2018-01-22 07:53:18 --> Utf8 Class Initialized
INFO - 2018-01-22 07:53:18 --> URI Class Initialized
INFO - 2018-01-22 07:53:18 --> Router Class Initialized
INFO - 2018-01-22 07:53:18 --> Output Class Initialized
INFO - 2018-01-22 07:53:18 --> Security Class Initialized
DEBUG - 2018-01-22 07:53:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 07:53:18 --> Input Class Initialized
INFO - 2018-01-22 07:53:18 --> Language Class Initialized
INFO - 2018-01-22 07:53:18 --> Loader Class Initialized
INFO - 2018-01-22 07:53:18 --> Helper loaded: url_helper
INFO - 2018-01-22 07:53:18 --> Helper loaded: form_helper
INFO - 2018-01-22 07:53:18 --> Database Driver Class Initialized
DEBUG - 2018-01-22 07:53:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 07:53:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 07:53:18 --> Form Validation Class Initialized
INFO - 2018-01-22 07:53:18 --> Model Class Initialized
INFO - 2018-01-22 07:53:18 --> Controller Class Initialized
INFO - 2018-01-22 07:53:18 --> Model Class Initialized
INFO - 2018-01-22 07:53:18 --> Model Class Initialized
DEBUG - 2018-01-22 07:53:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-22 07:53:18 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-22 07:53:18 --> Final output sent to browser
DEBUG - 2018-01-22 07:53:18 --> Total execution time: 0.0987
INFO - 2018-01-22 07:53:18 --> Config Class Initialized
INFO - 2018-01-22 07:53:18 --> Hooks Class Initialized
DEBUG - 2018-01-22 07:53:18 --> UTF-8 Support Enabled
INFO - 2018-01-22 07:53:18 --> Utf8 Class Initialized
INFO - 2018-01-22 07:53:18 --> URI Class Initialized
INFO - 2018-01-22 07:53:18 --> Router Class Initialized
INFO - 2018-01-22 07:53:18 --> Output Class Initialized
INFO - 2018-01-22 07:53:18 --> Security Class Initialized
DEBUG - 2018-01-22 07:53:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 07:53:18 --> Input Class Initialized
INFO - 2018-01-22 07:53:18 --> Language Class Initialized
INFO - 2018-01-22 07:53:18 --> Loader Class Initialized
INFO - 2018-01-22 07:53:18 --> Helper loaded: url_helper
INFO - 2018-01-22 07:53:18 --> Helper loaded: form_helper
INFO - 2018-01-22 07:53:18 --> Database Driver Class Initialized
DEBUG - 2018-01-22 07:53:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 07:53:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 07:53:18 --> Form Validation Class Initialized
INFO - 2018-01-22 07:53:18 --> Model Class Initialized
INFO - 2018-01-22 07:53:18 --> Controller Class Initialized
INFO - 2018-01-22 07:53:18 --> Model Class Initialized
INFO - 2018-01-22 07:53:18 --> Model Class Initialized
DEBUG - 2018-01-22 07:53:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-22 07:53:19 --> Config Class Initialized
INFO - 2018-01-22 07:53:19 --> Hooks Class Initialized
DEBUG - 2018-01-22 07:53:19 --> UTF-8 Support Enabled
INFO - 2018-01-22 07:53:19 --> Utf8 Class Initialized
INFO - 2018-01-22 07:53:19 --> URI Class Initialized
INFO - 2018-01-22 07:53:19 --> Router Class Initialized
INFO - 2018-01-22 07:53:19 --> Output Class Initialized
INFO - 2018-01-22 07:53:19 --> Security Class Initialized
DEBUG - 2018-01-22 07:53:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 07:53:19 --> Input Class Initialized
INFO - 2018-01-22 07:53:19 --> Language Class Initialized
INFO - 2018-01-22 07:53:19 --> Loader Class Initialized
INFO - 2018-01-22 07:53:19 --> Helper loaded: url_helper
INFO - 2018-01-22 07:53:19 --> Helper loaded: form_helper
INFO - 2018-01-22 07:53:19 --> Database Driver Class Initialized
DEBUG - 2018-01-22 07:53:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 07:53:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 07:53:19 --> Form Validation Class Initialized
INFO - 2018-01-22 07:53:19 --> Model Class Initialized
INFO - 2018-01-22 07:53:19 --> Controller Class Initialized
INFO - 2018-01-22 07:53:19 --> Model Class Initialized
INFO - 2018-01-22 07:53:19 --> Model Class Initialized
DEBUG - 2018-01-22 07:53:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-22 07:53:19 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-22 07:53:19 --> Final output sent to browser
DEBUG - 2018-01-22 07:53:19 --> Total execution time: 0.1036
INFO - 2018-01-22 07:53:20 --> Config Class Initialized
INFO - 2018-01-22 07:53:20 --> Hooks Class Initialized
DEBUG - 2018-01-22 07:53:20 --> UTF-8 Support Enabled
INFO - 2018-01-22 07:53:20 --> Utf8 Class Initialized
INFO - 2018-01-22 07:53:20 --> URI Class Initialized
INFO - 2018-01-22 07:53:20 --> Router Class Initialized
INFO - 2018-01-22 07:53:20 --> Output Class Initialized
INFO - 2018-01-22 07:53:20 --> Security Class Initialized
DEBUG - 2018-01-22 07:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 07:53:20 --> Input Class Initialized
INFO - 2018-01-22 07:53:20 --> Language Class Initialized
INFO - 2018-01-22 07:53:20 --> Loader Class Initialized
INFO - 2018-01-22 07:53:20 --> Helper loaded: url_helper
INFO - 2018-01-22 07:53:20 --> Helper loaded: form_helper
INFO - 2018-01-22 07:53:20 --> Database Driver Class Initialized
DEBUG - 2018-01-22 07:53:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 07:53:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 07:53:20 --> Form Validation Class Initialized
INFO - 2018-01-22 07:53:20 --> Model Class Initialized
INFO - 2018-01-22 07:53:20 --> Controller Class Initialized
INFO - 2018-01-22 07:53:20 --> Model Class Initialized
INFO - 2018-01-22 07:53:20 --> Model Class Initialized
DEBUG - 2018-01-22 07:53:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-22 07:53:21 --> Config Class Initialized
INFO - 2018-01-22 07:53:21 --> Hooks Class Initialized
DEBUG - 2018-01-22 07:53:21 --> UTF-8 Support Enabled
INFO - 2018-01-22 07:53:21 --> Utf8 Class Initialized
INFO - 2018-01-22 07:53:21 --> URI Class Initialized
INFO - 2018-01-22 07:53:21 --> Router Class Initialized
INFO - 2018-01-22 07:53:21 --> Output Class Initialized
INFO - 2018-01-22 07:53:21 --> Security Class Initialized
DEBUG - 2018-01-22 07:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 07:53:21 --> Input Class Initialized
INFO - 2018-01-22 07:53:21 --> Language Class Initialized
INFO - 2018-01-22 07:53:21 --> Loader Class Initialized
INFO - 2018-01-22 07:53:21 --> Helper loaded: url_helper
INFO - 2018-01-22 07:53:21 --> Helper loaded: form_helper
INFO - 2018-01-22 07:53:21 --> Database Driver Class Initialized
DEBUG - 2018-01-22 07:53:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 07:53:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 07:53:21 --> Form Validation Class Initialized
INFO - 2018-01-22 07:53:21 --> Model Class Initialized
INFO - 2018-01-22 07:53:21 --> Controller Class Initialized
INFO - 2018-01-22 07:53:21 --> Model Class Initialized
INFO - 2018-01-22 07:53:21 --> Model Class Initialized
INFO - 2018-01-22 07:53:21 --> Model Class Initialized
INFO - 2018-01-22 07:53:21 --> Model Class Initialized
DEBUG - 2018-01-22 07:53:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-22 07:53:21 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-22 07:53:21 --> Final output sent to browser
DEBUG - 2018-01-22 07:53:21 --> Total execution time: 0.1050
INFO - 2018-01-22 07:53:23 --> Config Class Initialized
INFO - 2018-01-22 07:53:23 --> Hooks Class Initialized
DEBUG - 2018-01-22 07:53:23 --> UTF-8 Support Enabled
INFO - 2018-01-22 07:53:23 --> Utf8 Class Initialized
INFO - 2018-01-22 07:53:23 --> URI Class Initialized
INFO - 2018-01-22 07:53:23 --> Router Class Initialized
INFO - 2018-01-22 07:53:23 --> Output Class Initialized
INFO - 2018-01-22 07:53:23 --> Security Class Initialized
DEBUG - 2018-01-22 07:53:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 07:53:23 --> Input Class Initialized
INFO - 2018-01-22 07:53:23 --> Language Class Initialized
INFO - 2018-01-22 07:53:23 --> Loader Class Initialized
INFO - 2018-01-22 07:53:23 --> Helper loaded: url_helper
INFO - 2018-01-22 07:53:23 --> Helper loaded: form_helper
INFO - 2018-01-22 07:53:23 --> Database Driver Class Initialized
DEBUG - 2018-01-22 07:53:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 07:53:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 07:53:23 --> Form Validation Class Initialized
INFO - 2018-01-22 07:53:23 --> Model Class Initialized
INFO - 2018-01-22 07:53:23 --> Controller Class Initialized
INFO - 2018-01-22 07:53:23 --> Model Class Initialized
INFO - 2018-01-22 07:53:23 --> Model Class Initialized
DEBUG - 2018-01-22 07:53:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-22 07:53:23 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-22 07:53:23 --> Final output sent to browser
DEBUG - 2018-01-22 07:53:23 --> Total execution time: 0.1147
INFO - 2018-01-22 07:53:23 --> Config Class Initialized
INFO - 2018-01-22 07:53:23 --> Hooks Class Initialized
DEBUG - 2018-01-22 07:53:23 --> UTF-8 Support Enabled
INFO - 2018-01-22 07:53:23 --> Utf8 Class Initialized
INFO - 2018-01-22 07:53:23 --> URI Class Initialized
INFO - 2018-01-22 07:53:23 --> Router Class Initialized
INFO - 2018-01-22 07:53:23 --> Output Class Initialized
INFO - 2018-01-22 07:53:23 --> Security Class Initialized
DEBUG - 2018-01-22 07:53:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-22 07:53:23 --> Input Class Initialized
INFO - 2018-01-22 07:53:23 --> Language Class Initialized
INFO - 2018-01-22 07:53:23 --> Loader Class Initialized
INFO - 2018-01-22 07:53:23 --> Helper loaded: url_helper
INFO - 2018-01-22 07:53:23 --> Helper loaded: form_helper
INFO - 2018-01-22 07:53:23 --> Database Driver Class Initialized
DEBUG - 2018-01-22 07:53:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-22 07:53:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-22 07:53:23 --> Form Validation Class Initialized
INFO - 2018-01-22 07:53:23 --> Model Class Initialized
INFO - 2018-01-22 07:53:23 --> Controller Class Initialized
INFO - 2018-01-22 07:53:23 --> Model Class Initialized
INFO - 2018-01-22 07:53:23 --> Model Class Initialized
DEBUG - 2018-01-22 07:53:23 --> Form_validation class already loaded. Second attempt ignored.
