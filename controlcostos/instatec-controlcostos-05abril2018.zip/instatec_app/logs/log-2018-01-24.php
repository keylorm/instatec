<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-01-24 06:40:33 --> Config Class Initialized
INFO - 2018-01-24 06:40:33 --> Hooks Class Initialized
DEBUG - 2018-01-24 06:40:33 --> UTF-8 Support Enabled
INFO - 2018-01-24 06:40:33 --> Utf8 Class Initialized
INFO - 2018-01-24 06:40:33 --> URI Class Initialized
INFO - 2018-01-24 06:40:33 --> Router Class Initialized
INFO - 2018-01-24 06:40:33 --> Output Class Initialized
INFO - 2018-01-24 06:40:33 --> Security Class Initialized
DEBUG - 2018-01-24 06:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-24 06:40:33 --> Input Class Initialized
INFO - 2018-01-24 06:40:33 --> Language Class Initialized
INFO - 2018-01-24 06:40:33 --> Loader Class Initialized
INFO - 2018-01-24 06:40:33 --> Helper loaded: url_helper
INFO - 2018-01-24 06:40:33 --> Helper loaded: form_helper
INFO - 2018-01-24 06:40:33 --> Database Driver Class Initialized
DEBUG - 2018-01-24 06:40:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-24 06:40:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-24 06:40:33 --> Form Validation Class Initialized
INFO - 2018-01-24 06:40:33 --> Model Class Initialized
INFO - 2018-01-24 06:40:33 --> Controller Class Initialized
INFO - 2018-01-24 06:40:33 --> Model Class Initialized
DEBUG - 2018-01-24 06:40:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-24 06:40:33 --> Config Class Initialized
INFO - 2018-01-24 06:40:33 --> Hooks Class Initialized
DEBUG - 2018-01-24 06:40:33 --> UTF-8 Support Enabled
INFO - 2018-01-24 06:40:33 --> Utf8 Class Initialized
INFO - 2018-01-24 06:40:33 --> URI Class Initialized
INFO - 2018-01-24 06:40:33 --> Router Class Initialized
INFO - 2018-01-24 06:40:33 --> Output Class Initialized
INFO - 2018-01-24 06:40:33 --> Security Class Initialized
DEBUG - 2018-01-24 06:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-24 06:40:33 --> Input Class Initialized
INFO - 2018-01-24 06:40:33 --> Language Class Initialized
INFO - 2018-01-24 06:40:33 --> Loader Class Initialized
INFO - 2018-01-24 06:40:33 --> Helper loaded: url_helper
INFO - 2018-01-24 06:40:33 --> Helper loaded: form_helper
INFO - 2018-01-24 06:40:33 --> Database Driver Class Initialized
DEBUG - 2018-01-24 06:40:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-24 06:40:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-24 06:40:33 --> Form Validation Class Initialized
INFO - 2018-01-24 06:40:33 --> Model Class Initialized
INFO - 2018-01-24 06:40:33 --> Controller Class Initialized
INFO - 2018-01-24 06:40:33 --> Model Class Initialized
DEBUG - 2018-01-24 06:40:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-24 06:40:33 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-24 06:40:33 --> Final output sent to browser
DEBUG - 2018-01-24 06:40:33 --> Total execution time: 0.0615
INFO - 2018-01-24 06:40:37 --> Config Class Initialized
INFO - 2018-01-24 06:40:37 --> Hooks Class Initialized
DEBUG - 2018-01-24 06:40:37 --> UTF-8 Support Enabled
INFO - 2018-01-24 06:40:37 --> Utf8 Class Initialized
INFO - 2018-01-24 06:40:37 --> URI Class Initialized
INFO - 2018-01-24 06:40:37 --> Router Class Initialized
INFO - 2018-01-24 06:40:37 --> Output Class Initialized
INFO - 2018-01-24 06:40:37 --> Security Class Initialized
DEBUG - 2018-01-24 06:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-24 06:40:37 --> Input Class Initialized
INFO - 2018-01-24 06:40:37 --> Language Class Initialized
INFO - 2018-01-24 06:40:37 --> Loader Class Initialized
INFO - 2018-01-24 06:40:37 --> Helper loaded: url_helper
INFO - 2018-01-24 06:40:37 --> Helper loaded: form_helper
INFO - 2018-01-24 06:40:37 --> Database Driver Class Initialized
DEBUG - 2018-01-24 06:40:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-24 06:40:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-24 06:40:37 --> Form Validation Class Initialized
INFO - 2018-01-24 06:40:37 --> Model Class Initialized
INFO - 2018-01-24 06:40:37 --> Controller Class Initialized
INFO - 2018-01-24 06:40:37 --> Model Class Initialized
DEBUG - 2018-01-24 06:40:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-24 06:40:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-01-24 06:40:37 --> Config Class Initialized
INFO - 2018-01-24 06:40:37 --> Hooks Class Initialized
DEBUG - 2018-01-24 06:40:37 --> UTF-8 Support Enabled
INFO - 2018-01-24 06:40:37 --> Utf8 Class Initialized
INFO - 2018-01-24 06:40:37 --> URI Class Initialized
DEBUG - 2018-01-24 06:40:37 --> No URI present. Default controller set.
INFO - 2018-01-24 06:40:37 --> Router Class Initialized
INFO - 2018-01-24 06:40:37 --> Output Class Initialized
INFO - 2018-01-24 06:40:37 --> Security Class Initialized
DEBUG - 2018-01-24 06:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-24 06:40:37 --> Input Class Initialized
INFO - 2018-01-24 06:40:37 --> Language Class Initialized
INFO - 2018-01-24 06:40:37 --> Loader Class Initialized
INFO - 2018-01-24 06:40:37 --> Helper loaded: url_helper
INFO - 2018-01-24 06:40:37 --> Helper loaded: form_helper
INFO - 2018-01-24 06:40:37 --> Database Driver Class Initialized
DEBUG - 2018-01-24 06:40:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-24 06:40:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-24 06:40:37 --> Form Validation Class Initialized
INFO - 2018-01-24 06:40:37 --> Model Class Initialized
INFO - 2018-01-24 06:40:37 --> Controller Class Initialized
INFO - 2018-01-24 06:40:37 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-24 06:40:37 --> Final output sent to browser
DEBUG - 2018-01-24 06:40:37 --> Total execution time: 0.0512
INFO - 2018-01-24 06:40:37 --> Config Class Initialized
INFO - 2018-01-24 06:40:37 --> Hooks Class Initialized
DEBUG - 2018-01-24 06:40:37 --> UTF-8 Support Enabled
INFO - 2018-01-24 06:40:37 --> Utf8 Class Initialized
INFO - 2018-01-24 06:40:37 --> URI Class Initialized
INFO - 2018-01-24 06:40:37 --> Router Class Initialized
INFO - 2018-01-24 06:40:37 --> Output Class Initialized
INFO - 2018-01-24 06:40:37 --> Security Class Initialized
DEBUG - 2018-01-24 06:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-24 06:40:37 --> Input Class Initialized
INFO - 2018-01-24 06:40:37 --> Language Class Initialized
INFO - 2018-01-24 06:40:37 --> Loader Class Initialized
INFO - 2018-01-24 06:40:37 --> Helper loaded: url_helper
INFO - 2018-01-24 06:40:37 --> Helper loaded: form_helper
INFO - 2018-01-24 06:40:37 --> Database Driver Class Initialized
DEBUG - 2018-01-24 06:40:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-24 06:40:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-24 06:40:37 --> Form Validation Class Initialized
INFO - 2018-01-24 06:40:37 --> Model Class Initialized
INFO - 2018-01-24 06:40:37 --> Controller Class Initialized
INFO - 2018-01-24 06:40:37 --> Model Class Initialized
INFO - 2018-01-24 06:40:37 --> Model Class Initialized
INFO - 2018-01-24 06:40:37 --> Model Class Initialized
INFO - 2018-01-24 06:40:37 --> Model Class Initialized
DEBUG - 2018-01-24 06:40:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-24 06:40:40 --> Config Class Initialized
INFO - 2018-01-24 06:40:40 --> Hooks Class Initialized
DEBUG - 2018-01-24 06:40:40 --> UTF-8 Support Enabled
INFO - 2018-01-24 06:40:40 --> Utf8 Class Initialized
INFO - 2018-01-24 06:40:40 --> URI Class Initialized
INFO - 2018-01-24 06:40:40 --> Router Class Initialized
INFO - 2018-01-24 06:40:40 --> Output Class Initialized
INFO - 2018-01-24 06:40:40 --> Security Class Initialized
DEBUG - 2018-01-24 06:40:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-24 06:40:40 --> Input Class Initialized
INFO - 2018-01-24 06:40:40 --> Language Class Initialized
INFO - 2018-01-24 06:40:40 --> Loader Class Initialized
INFO - 2018-01-24 06:40:40 --> Helper loaded: url_helper
INFO - 2018-01-24 06:40:40 --> Helper loaded: form_helper
INFO - 2018-01-24 06:40:40 --> Database Driver Class Initialized
DEBUG - 2018-01-24 06:40:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-24 06:40:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-24 06:40:40 --> Form Validation Class Initialized
INFO - 2018-01-24 06:40:40 --> Model Class Initialized
INFO - 2018-01-24 06:40:40 --> Controller Class Initialized
INFO - 2018-01-24 06:40:40 --> Model Class Initialized
DEBUG - 2018-01-24 06:40:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-24 06:40:40 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-24 06:40:40 --> Final output sent to browser
DEBUG - 2018-01-24 06:40:40 --> Total execution time: 0.0478
INFO - 2018-01-24 06:40:40 --> Config Class Initialized
INFO - 2018-01-24 06:40:40 --> Hooks Class Initialized
DEBUG - 2018-01-24 06:40:40 --> UTF-8 Support Enabled
INFO - 2018-01-24 06:40:40 --> Utf8 Class Initialized
INFO - 2018-01-24 06:40:40 --> URI Class Initialized
INFO - 2018-01-24 06:40:40 --> Router Class Initialized
INFO - 2018-01-24 06:40:40 --> Output Class Initialized
INFO - 2018-01-24 06:40:40 --> Security Class Initialized
DEBUG - 2018-01-24 06:40:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-24 06:40:40 --> Input Class Initialized
INFO - 2018-01-24 06:40:40 --> Language Class Initialized
INFO - 2018-01-24 06:40:40 --> Loader Class Initialized
INFO - 2018-01-24 06:40:40 --> Helper loaded: url_helper
INFO - 2018-01-24 06:40:40 --> Helper loaded: form_helper
INFO - 2018-01-24 06:40:40 --> Database Driver Class Initialized
DEBUG - 2018-01-24 06:40:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-24 06:40:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-24 06:40:40 --> Form Validation Class Initialized
INFO - 2018-01-24 06:40:40 --> Model Class Initialized
INFO - 2018-01-24 06:40:40 --> Controller Class Initialized
INFO - 2018-01-24 06:40:40 --> Model Class Initialized
DEBUG - 2018-01-24 06:40:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-24 06:40:42 --> Config Class Initialized
INFO - 2018-01-24 06:40:42 --> Hooks Class Initialized
DEBUG - 2018-01-24 06:40:42 --> UTF-8 Support Enabled
INFO - 2018-01-24 06:40:42 --> Utf8 Class Initialized
INFO - 2018-01-24 06:40:42 --> URI Class Initialized
INFO - 2018-01-24 06:40:42 --> Router Class Initialized
INFO - 2018-01-24 06:40:42 --> Output Class Initialized
INFO - 2018-01-24 06:40:42 --> Security Class Initialized
DEBUG - 2018-01-24 06:40:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-24 06:40:42 --> Input Class Initialized
INFO - 2018-01-24 06:40:42 --> Language Class Initialized
INFO - 2018-01-24 06:40:42 --> Loader Class Initialized
INFO - 2018-01-24 06:40:42 --> Helper loaded: url_helper
INFO - 2018-01-24 06:40:42 --> Helper loaded: form_helper
INFO - 2018-01-24 06:40:42 --> Database Driver Class Initialized
DEBUG - 2018-01-24 06:40:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-24 06:40:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-24 06:40:42 --> Form Validation Class Initialized
INFO - 2018-01-24 06:40:42 --> Model Class Initialized
INFO - 2018-01-24 06:40:42 --> Controller Class Initialized
INFO - 2018-01-24 06:40:42 --> Model Class Initialized
DEBUG - 2018-01-24 06:40:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-24 06:40:42 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-24 06:40:42 --> Final output sent to browser
DEBUG - 2018-01-24 06:40:42 --> Total execution time: 0.0553
INFO - 2018-01-24 06:52:44 --> Config Class Initialized
INFO - 2018-01-24 06:52:44 --> Hooks Class Initialized
DEBUG - 2018-01-24 06:52:44 --> UTF-8 Support Enabled
INFO - 2018-01-24 06:52:44 --> Utf8 Class Initialized
INFO - 2018-01-24 06:52:44 --> URI Class Initialized
INFO - 2018-01-24 06:52:44 --> Router Class Initialized
INFO - 2018-01-24 06:52:44 --> Output Class Initialized
INFO - 2018-01-24 06:52:44 --> Security Class Initialized
DEBUG - 2018-01-24 06:52:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-24 06:52:44 --> Input Class Initialized
INFO - 2018-01-24 06:52:44 --> Language Class Initialized
INFO - 2018-01-24 06:52:44 --> Loader Class Initialized
INFO - 2018-01-24 06:52:44 --> Helper loaded: url_helper
INFO - 2018-01-24 06:52:44 --> Helper loaded: form_helper
INFO - 2018-01-24 06:52:44 --> Database Driver Class Initialized
DEBUG - 2018-01-24 06:52:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-24 06:52:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-24 06:52:44 --> Form Validation Class Initialized
INFO - 2018-01-24 06:52:44 --> Model Class Initialized
INFO - 2018-01-24 06:52:44 --> Controller Class Initialized
INFO - 2018-01-24 06:52:44 --> Model Class Initialized
DEBUG - 2018-01-24 06:52:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-24 06:52:44 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-24 06:52:44 --> Final output sent to browser
DEBUG - 2018-01-24 06:52:44 --> Total execution time: 0.3320
INFO - 2018-01-24 06:52:49 --> Config Class Initialized
INFO - 2018-01-24 06:52:49 --> Hooks Class Initialized
DEBUG - 2018-01-24 06:52:49 --> UTF-8 Support Enabled
INFO - 2018-01-24 06:52:49 --> Utf8 Class Initialized
INFO - 2018-01-24 06:52:49 --> URI Class Initialized
INFO - 2018-01-24 06:52:49 --> Router Class Initialized
INFO - 2018-01-24 06:52:49 --> Output Class Initialized
INFO - 2018-01-24 06:52:49 --> Security Class Initialized
DEBUG - 2018-01-24 06:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-24 06:52:49 --> Input Class Initialized
INFO - 2018-01-24 06:52:49 --> Language Class Initialized
INFO - 2018-01-24 06:52:49 --> Loader Class Initialized
INFO - 2018-01-24 06:52:49 --> Helper loaded: url_helper
INFO - 2018-01-24 06:52:49 --> Helper loaded: form_helper
INFO - 2018-01-24 06:52:49 --> Database Driver Class Initialized
DEBUG - 2018-01-24 06:52:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-24 06:52:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-24 06:52:49 --> Form Validation Class Initialized
INFO - 2018-01-24 06:52:49 --> Model Class Initialized
INFO - 2018-01-24 06:52:49 --> Controller Class Initialized
INFO - 2018-01-24 06:52:49 --> Model Class Initialized
DEBUG - 2018-01-24 06:52:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-24 06:52:49 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-24 06:52:49 --> Final output sent to browser
DEBUG - 2018-01-24 06:52:49 --> Total execution time: 0.0384
INFO - 2018-01-24 06:52:49 --> Config Class Initialized
INFO - 2018-01-24 06:52:49 --> Hooks Class Initialized
DEBUG - 2018-01-24 06:52:49 --> UTF-8 Support Enabled
INFO - 2018-01-24 06:52:49 --> Utf8 Class Initialized
INFO - 2018-01-24 06:52:49 --> URI Class Initialized
INFO - 2018-01-24 06:52:49 --> Router Class Initialized
INFO - 2018-01-24 06:52:49 --> Output Class Initialized
INFO - 2018-01-24 06:52:49 --> Security Class Initialized
DEBUG - 2018-01-24 06:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-24 06:52:49 --> Input Class Initialized
INFO - 2018-01-24 06:52:49 --> Language Class Initialized
INFO - 2018-01-24 06:52:49 --> Loader Class Initialized
INFO - 2018-01-24 06:52:49 --> Helper loaded: url_helper
INFO - 2018-01-24 06:52:49 --> Helper loaded: form_helper
INFO - 2018-01-24 06:52:49 --> Database Driver Class Initialized
DEBUG - 2018-01-24 06:52:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-24 06:52:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-24 06:52:49 --> Form Validation Class Initialized
INFO - 2018-01-24 06:52:49 --> Model Class Initialized
INFO - 2018-01-24 06:52:49 --> Controller Class Initialized
INFO - 2018-01-24 06:52:49 --> Model Class Initialized
DEBUG - 2018-01-24 06:52:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-24 06:52:56 --> Config Class Initialized
INFO - 2018-01-24 06:52:56 --> Hooks Class Initialized
DEBUG - 2018-01-24 06:52:56 --> UTF-8 Support Enabled
INFO - 2018-01-24 06:52:56 --> Utf8 Class Initialized
INFO - 2018-01-24 06:52:56 --> URI Class Initialized
INFO - 2018-01-24 06:52:56 --> Router Class Initialized
INFO - 2018-01-24 06:52:56 --> Output Class Initialized
INFO - 2018-01-24 06:52:56 --> Security Class Initialized
DEBUG - 2018-01-24 06:52:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-24 06:52:56 --> Input Class Initialized
INFO - 2018-01-24 06:52:56 --> Language Class Initialized
INFO - 2018-01-24 06:52:56 --> Loader Class Initialized
INFO - 2018-01-24 06:52:56 --> Helper loaded: url_helper
INFO - 2018-01-24 06:52:56 --> Helper loaded: form_helper
INFO - 2018-01-24 06:52:56 --> Database Driver Class Initialized
DEBUG - 2018-01-24 06:52:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-24 06:52:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-24 06:52:56 --> Form Validation Class Initialized
INFO - 2018-01-24 06:52:56 --> Model Class Initialized
INFO - 2018-01-24 06:52:56 --> Controller Class Initialized
INFO - 2018-01-24 06:52:56 --> Model Class Initialized
DEBUG - 2018-01-24 06:52:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-24 06:52:56 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-24 06:52:56 --> Final output sent to browser
DEBUG - 2018-01-24 06:52:56 --> Total execution time: 0.0407
INFO - 2018-01-24 06:52:56 --> Config Class Initialized
INFO - 2018-01-24 06:52:56 --> Hooks Class Initialized
DEBUG - 2018-01-24 06:52:56 --> UTF-8 Support Enabled
INFO - 2018-01-24 06:52:56 --> Utf8 Class Initialized
INFO - 2018-01-24 06:52:56 --> URI Class Initialized
INFO - 2018-01-24 06:52:56 --> Router Class Initialized
INFO - 2018-01-24 06:52:56 --> Output Class Initialized
INFO - 2018-01-24 06:52:56 --> Security Class Initialized
DEBUG - 2018-01-24 06:52:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-24 06:52:56 --> Input Class Initialized
INFO - 2018-01-24 06:52:56 --> Language Class Initialized
INFO - 2018-01-24 06:52:56 --> Loader Class Initialized
INFO - 2018-01-24 06:52:56 --> Helper loaded: url_helper
INFO - 2018-01-24 06:52:56 --> Helper loaded: form_helper
INFO - 2018-01-24 06:52:56 --> Database Driver Class Initialized
DEBUG - 2018-01-24 06:52:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-24 06:52:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-24 06:52:56 --> Form Validation Class Initialized
INFO - 2018-01-24 06:52:56 --> Model Class Initialized
INFO - 2018-01-24 06:52:56 --> Controller Class Initialized
INFO - 2018-01-24 06:52:56 --> Model Class Initialized
DEBUG - 2018-01-24 06:52:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-24 06:54:03 --> Config Class Initialized
INFO - 2018-01-24 06:54:03 --> Hooks Class Initialized
DEBUG - 2018-01-24 06:54:03 --> UTF-8 Support Enabled
INFO - 2018-01-24 06:54:03 --> Utf8 Class Initialized
INFO - 2018-01-24 06:54:03 --> URI Class Initialized
INFO - 2018-01-24 06:54:03 --> Router Class Initialized
INFO - 2018-01-24 06:54:03 --> Output Class Initialized
INFO - 2018-01-24 06:54:03 --> Security Class Initialized
DEBUG - 2018-01-24 06:54:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-24 06:54:03 --> Input Class Initialized
INFO - 2018-01-24 06:54:03 --> Language Class Initialized
INFO - 2018-01-24 06:54:03 --> Loader Class Initialized
INFO - 2018-01-24 06:54:03 --> Helper loaded: url_helper
INFO - 2018-01-24 06:54:03 --> Helper loaded: form_helper
INFO - 2018-01-24 06:54:03 --> Database Driver Class Initialized
DEBUG - 2018-01-24 06:54:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-24 06:54:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-24 06:54:03 --> Form Validation Class Initialized
INFO - 2018-01-24 06:54:03 --> Model Class Initialized
INFO - 2018-01-24 06:54:03 --> Controller Class Initialized
INFO - 2018-01-24 06:54:03 --> Model Class Initialized
DEBUG - 2018-01-24 06:54:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-24 06:54:03 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-24 06:54:03 --> Final output sent to browser
DEBUG - 2018-01-24 06:54:03 --> Total execution time: 0.0514
INFO - 2018-01-24 06:57:51 --> Config Class Initialized
INFO - 2018-01-24 06:57:51 --> Hooks Class Initialized
DEBUG - 2018-01-24 06:57:51 --> UTF-8 Support Enabled
INFO - 2018-01-24 06:57:51 --> Utf8 Class Initialized
INFO - 2018-01-24 06:57:51 --> URI Class Initialized
INFO - 2018-01-24 06:57:51 --> Router Class Initialized
INFO - 2018-01-24 06:57:51 --> Output Class Initialized
INFO - 2018-01-24 06:57:51 --> Security Class Initialized
DEBUG - 2018-01-24 06:57:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-24 06:57:51 --> Input Class Initialized
INFO - 2018-01-24 06:57:51 --> Language Class Initialized
INFO - 2018-01-24 06:57:51 --> Loader Class Initialized
INFO - 2018-01-24 06:57:51 --> Helper loaded: url_helper
INFO - 2018-01-24 06:57:51 --> Helper loaded: form_helper
INFO - 2018-01-24 06:57:51 --> Database Driver Class Initialized
DEBUG - 2018-01-24 06:57:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-24 06:57:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-24 06:57:51 --> Form Validation Class Initialized
INFO - 2018-01-24 06:57:51 --> Model Class Initialized
INFO - 2018-01-24 06:57:51 --> Controller Class Initialized
INFO - 2018-01-24 06:57:51 --> Model Class Initialized
DEBUG - 2018-01-24 06:57:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-24 07:19:12 --> Config Class Initialized
INFO - 2018-01-24 07:19:12 --> Hooks Class Initialized
DEBUG - 2018-01-24 07:19:12 --> UTF-8 Support Enabled
INFO - 2018-01-24 07:19:12 --> Utf8 Class Initialized
INFO - 2018-01-24 07:19:12 --> URI Class Initialized
INFO - 2018-01-24 07:19:12 --> Router Class Initialized
INFO - 2018-01-24 07:19:12 --> Output Class Initialized
INFO - 2018-01-24 07:19:12 --> Security Class Initialized
DEBUG - 2018-01-24 07:19:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-24 07:19:12 --> Input Class Initialized
INFO - 2018-01-24 07:19:12 --> Language Class Initialized
INFO - 2018-01-24 07:19:12 --> Loader Class Initialized
INFO - 2018-01-24 07:19:12 --> Helper loaded: url_helper
INFO - 2018-01-24 07:19:12 --> Helper loaded: form_helper
INFO - 2018-01-24 07:19:12 --> Database Driver Class Initialized
DEBUG - 2018-01-24 07:19:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-24 07:19:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-24 07:19:12 --> Form Validation Class Initialized
INFO - 2018-01-24 07:19:12 --> Model Class Initialized
INFO - 2018-01-24 07:19:12 --> Controller Class Initialized
INFO - 2018-01-24 07:19:12 --> Model Class Initialized
DEBUG - 2018-01-24 07:19:12 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-01-24 07:19:12 --> Query error: Unknown column 'usuario_rolrol_id' in 'where clause' - Invalid query: SELECT *
FROM `usuario_rol`
WHERE `usuario_rolrol_id` != 4
INFO - 2018-01-24 07:19:12 --> Language file loaded: language/english/db_lang.php
INFO - 2018-01-24 07:19:52 --> Config Class Initialized
INFO - 2018-01-24 07:19:52 --> Hooks Class Initialized
DEBUG - 2018-01-24 07:19:52 --> UTF-8 Support Enabled
INFO - 2018-01-24 07:19:52 --> Utf8 Class Initialized
INFO - 2018-01-24 07:19:52 --> URI Class Initialized
INFO - 2018-01-24 07:19:52 --> Router Class Initialized
INFO - 2018-01-24 07:19:52 --> Output Class Initialized
INFO - 2018-01-24 07:19:52 --> Security Class Initialized
DEBUG - 2018-01-24 07:19:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-24 07:19:52 --> Input Class Initialized
INFO - 2018-01-24 07:19:52 --> Language Class Initialized
INFO - 2018-01-24 07:19:52 --> Loader Class Initialized
INFO - 2018-01-24 07:19:52 --> Helper loaded: url_helper
INFO - 2018-01-24 07:19:52 --> Helper loaded: form_helper
INFO - 2018-01-24 07:19:52 --> Database Driver Class Initialized
DEBUG - 2018-01-24 07:19:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-24 07:19:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-24 07:19:52 --> Form Validation Class Initialized
INFO - 2018-01-24 07:19:52 --> Model Class Initialized
INFO - 2018-01-24 07:19:52 --> Controller Class Initialized
INFO - 2018-01-24 07:19:52 --> Model Class Initialized
DEBUG - 2018-01-24 07:19:52 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2018-01-24 07:19:52 --> Severity: Notice --> Undefined variable: usuario_id D:\xampp\htdocs\instateccr\controlcostos\instatec_app\models\M_usuario.php 59
INFO - 2018-01-24 07:19:53 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-24 07:19:53 --> Final output sent to browser
DEBUG - 2018-01-24 07:19:53 --> Total execution time: 0.0907
INFO - 2018-01-24 07:20:25 --> Config Class Initialized
INFO - 2018-01-24 07:20:25 --> Hooks Class Initialized
DEBUG - 2018-01-24 07:20:25 --> UTF-8 Support Enabled
INFO - 2018-01-24 07:20:25 --> Utf8 Class Initialized
INFO - 2018-01-24 07:20:25 --> URI Class Initialized
INFO - 2018-01-24 07:20:25 --> Router Class Initialized
INFO - 2018-01-24 07:20:25 --> Output Class Initialized
INFO - 2018-01-24 07:20:25 --> Security Class Initialized
DEBUG - 2018-01-24 07:20:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-24 07:20:25 --> Input Class Initialized
INFO - 2018-01-24 07:20:25 --> Language Class Initialized
INFO - 2018-01-24 07:20:25 --> Loader Class Initialized
INFO - 2018-01-24 07:20:25 --> Helper loaded: url_helper
INFO - 2018-01-24 07:20:25 --> Helper loaded: form_helper
INFO - 2018-01-24 07:20:25 --> Database Driver Class Initialized
DEBUG - 2018-01-24 07:20:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-24 07:20:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-24 07:20:25 --> Form Validation Class Initialized
INFO - 2018-01-24 07:20:25 --> Model Class Initialized
INFO - 2018-01-24 07:20:25 --> Controller Class Initialized
INFO - 2018-01-24 07:20:25 --> Model Class Initialized
DEBUG - 2018-01-24 07:20:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-24 07:20:25 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-24 07:20:25 --> Final output sent to browser
DEBUG - 2018-01-24 07:20:25 --> Total execution time: 0.0561
INFO - 2018-01-24 07:20:28 --> Config Class Initialized
INFO - 2018-01-24 07:20:28 --> Hooks Class Initialized
DEBUG - 2018-01-24 07:20:28 --> UTF-8 Support Enabled
INFO - 2018-01-24 07:20:28 --> Utf8 Class Initialized
INFO - 2018-01-24 07:20:28 --> URI Class Initialized
INFO - 2018-01-24 07:20:28 --> Router Class Initialized
INFO - 2018-01-24 07:20:28 --> Output Class Initialized
INFO - 2018-01-24 07:20:28 --> Security Class Initialized
DEBUG - 2018-01-24 07:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-24 07:20:28 --> Input Class Initialized
INFO - 2018-01-24 07:20:28 --> Language Class Initialized
INFO - 2018-01-24 07:20:28 --> Loader Class Initialized
INFO - 2018-01-24 07:20:28 --> Helper loaded: url_helper
INFO - 2018-01-24 07:20:28 --> Helper loaded: form_helper
INFO - 2018-01-24 07:20:28 --> Database Driver Class Initialized
DEBUG - 2018-01-24 07:20:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-24 07:20:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-24 07:20:28 --> Form Validation Class Initialized
INFO - 2018-01-24 07:20:28 --> Model Class Initialized
INFO - 2018-01-24 07:20:28 --> Controller Class Initialized
INFO - 2018-01-24 07:20:28 --> Model Class Initialized
DEBUG - 2018-01-24 07:20:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-24 07:20:28 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-24 07:20:28 --> Final output sent to browser
DEBUG - 2018-01-24 07:20:28 --> Total execution time: 0.0400
INFO - 2018-01-24 07:20:29 --> Config Class Initialized
INFO - 2018-01-24 07:20:29 --> Hooks Class Initialized
DEBUG - 2018-01-24 07:20:29 --> UTF-8 Support Enabled
INFO - 2018-01-24 07:20:29 --> Utf8 Class Initialized
INFO - 2018-01-24 07:20:29 --> URI Class Initialized
INFO - 2018-01-24 07:20:29 --> Router Class Initialized
INFO - 2018-01-24 07:20:29 --> Output Class Initialized
INFO - 2018-01-24 07:20:29 --> Security Class Initialized
DEBUG - 2018-01-24 07:20:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-24 07:20:29 --> Input Class Initialized
INFO - 2018-01-24 07:20:29 --> Language Class Initialized
INFO - 2018-01-24 07:20:29 --> Loader Class Initialized
INFO - 2018-01-24 07:20:29 --> Helper loaded: url_helper
INFO - 2018-01-24 07:20:29 --> Helper loaded: form_helper
INFO - 2018-01-24 07:20:29 --> Database Driver Class Initialized
DEBUG - 2018-01-24 07:20:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-24 07:20:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-24 07:20:29 --> Form Validation Class Initialized
INFO - 2018-01-24 07:20:29 --> Model Class Initialized
INFO - 2018-01-24 07:20:29 --> Controller Class Initialized
INFO - 2018-01-24 07:20:29 --> Model Class Initialized
DEBUG - 2018-01-24 07:20:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-24 07:20:34 --> Config Class Initialized
INFO - 2018-01-24 07:20:34 --> Hooks Class Initialized
DEBUG - 2018-01-24 07:20:34 --> UTF-8 Support Enabled
INFO - 2018-01-24 07:20:34 --> Utf8 Class Initialized
INFO - 2018-01-24 07:20:34 --> URI Class Initialized
INFO - 2018-01-24 07:20:34 --> Router Class Initialized
INFO - 2018-01-24 07:20:34 --> Output Class Initialized
INFO - 2018-01-24 07:20:34 --> Security Class Initialized
DEBUG - 2018-01-24 07:20:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-24 07:20:34 --> Input Class Initialized
INFO - 2018-01-24 07:20:34 --> Language Class Initialized
ERROR - 2018-01-24 07:20:34 --> 404 Page Not Found: Usuario/editarUsuario
INFO - 2018-01-24 07:20:35 --> Config Class Initialized
INFO - 2018-01-24 07:20:35 --> Hooks Class Initialized
DEBUG - 2018-01-24 07:20:35 --> UTF-8 Support Enabled
INFO - 2018-01-24 07:20:35 --> Utf8 Class Initialized
INFO - 2018-01-24 07:20:35 --> URI Class Initialized
INFO - 2018-01-24 07:20:35 --> Router Class Initialized
INFO - 2018-01-24 07:20:35 --> Output Class Initialized
INFO - 2018-01-24 07:20:35 --> Security Class Initialized
DEBUG - 2018-01-24 07:20:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-24 07:20:35 --> Input Class Initialized
INFO - 2018-01-24 07:20:35 --> Language Class Initialized
INFO - 2018-01-24 07:20:35 --> Loader Class Initialized
INFO - 2018-01-24 07:20:35 --> Helper loaded: url_helper
INFO - 2018-01-24 07:20:35 --> Helper loaded: form_helper
INFO - 2018-01-24 07:20:35 --> Database Driver Class Initialized
DEBUG - 2018-01-24 07:20:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-24 07:20:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-24 07:20:35 --> Form Validation Class Initialized
INFO - 2018-01-24 07:20:35 --> Model Class Initialized
INFO - 2018-01-24 07:20:35 --> Controller Class Initialized
INFO - 2018-01-24 07:20:35 --> Model Class Initialized
DEBUG - 2018-01-24 07:20:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-24 07:20:35 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-24 07:20:35 --> Final output sent to browser
DEBUG - 2018-01-24 07:20:35 --> Total execution time: 0.0511
INFO - 2018-01-24 07:20:35 --> Config Class Initialized
INFO - 2018-01-24 07:20:35 --> Hooks Class Initialized
DEBUG - 2018-01-24 07:20:35 --> UTF-8 Support Enabled
INFO - 2018-01-24 07:20:35 --> Utf8 Class Initialized
INFO - 2018-01-24 07:20:35 --> URI Class Initialized
INFO - 2018-01-24 07:20:35 --> Router Class Initialized
INFO - 2018-01-24 07:20:35 --> Output Class Initialized
INFO - 2018-01-24 07:20:35 --> Security Class Initialized
DEBUG - 2018-01-24 07:20:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-24 07:20:35 --> Input Class Initialized
INFO - 2018-01-24 07:20:35 --> Language Class Initialized
INFO - 2018-01-24 07:20:35 --> Loader Class Initialized
INFO - 2018-01-24 07:20:35 --> Helper loaded: url_helper
INFO - 2018-01-24 07:20:35 --> Helper loaded: form_helper
INFO - 2018-01-24 07:20:35 --> Database Driver Class Initialized
DEBUG - 2018-01-24 07:20:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-24 07:20:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-24 07:20:35 --> Form Validation Class Initialized
INFO - 2018-01-24 07:20:35 --> Model Class Initialized
INFO - 2018-01-24 07:20:35 --> Controller Class Initialized
INFO - 2018-01-24 07:20:35 --> Model Class Initialized
DEBUG - 2018-01-24 07:20:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-24 07:20:45 --> Config Class Initialized
INFO - 2018-01-24 07:20:45 --> Hooks Class Initialized
DEBUG - 2018-01-24 07:20:45 --> UTF-8 Support Enabled
INFO - 2018-01-24 07:20:45 --> Utf8 Class Initialized
INFO - 2018-01-24 07:20:45 --> URI Class Initialized
INFO - 2018-01-24 07:20:45 --> Router Class Initialized
INFO - 2018-01-24 07:20:45 --> Output Class Initialized
INFO - 2018-01-24 07:20:45 --> Security Class Initialized
DEBUG - 2018-01-24 07:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-24 07:20:45 --> Input Class Initialized
INFO - 2018-01-24 07:20:45 --> Language Class Initialized
INFO - 2018-01-24 07:20:45 --> Loader Class Initialized
INFO - 2018-01-24 07:20:45 --> Helper loaded: url_helper
INFO - 2018-01-24 07:20:45 --> Helper loaded: form_helper
INFO - 2018-01-24 07:20:45 --> Database Driver Class Initialized
DEBUG - 2018-01-24 07:20:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-24 07:20:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-24 07:20:45 --> Form Validation Class Initialized
INFO - 2018-01-24 07:20:45 --> Model Class Initialized
INFO - 2018-01-24 07:20:45 --> Controller Class Initialized
INFO - 2018-01-24 07:20:45 --> Model Class Initialized
DEBUG - 2018-01-24 07:20:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-24 07:20:48 --> Config Class Initialized
INFO - 2018-01-24 07:20:48 --> Hooks Class Initialized
DEBUG - 2018-01-24 07:20:48 --> UTF-8 Support Enabled
INFO - 2018-01-24 07:20:48 --> Utf8 Class Initialized
INFO - 2018-01-24 07:20:48 --> URI Class Initialized
INFO - 2018-01-24 07:20:48 --> Router Class Initialized
INFO - 2018-01-24 07:20:48 --> Output Class Initialized
INFO - 2018-01-24 07:20:48 --> Security Class Initialized
DEBUG - 2018-01-24 07:20:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-24 07:20:48 --> Input Class Initialized
INFO - 2018-01-24 07:20:48 --> Language Class Initialized
INFO - 2018-01-24 07:20:48 --> Loader Class Initialized
INFO - 2018-01-24 07:20:48 --> Helper loaded: url_helper
INFO - 2018-01-24 07:20:48 --> Helper loaded: form_helper
INFO - 2018-01-24 07:20:48 --> Database Driver Class Initialized
DEBUG - 2018-01-24 07:20:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-24 07:20:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-24 07:20:48 --> Form Validation Class Initialized
INFO - 2018-01-24 07:20:48 --> Model Class Initialized
INFO - 2018-01-24 07:20:48 --> Controller Class Initialized
INFO - 2018-01-24 07:20:48 --> Model Class Initialized
DEBUG - 2018-01-24 07:20:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-24 07:20:51 --> Config Class Initialized
INFO - 2018-01-24 07:20:51 --> Hooks Class Initialized
DEBUG - 2018-01-24 07:20:51 --> UTF-8 Support Enabled
INFO - 2018-01-24 07:20:51 --> Utf8 Class Initialized
INFO - 2018-01-24 07:20:51 --> URI Class Initialized
INFO - 2018-01-24 07:20:51 --> Router Class Initialized
INFO - 2018-01-24 07:20:51 --> Output Class Initialized
INFO - 2018-01-24 07:20:51 --> Security Class Initialized
DEBUG - 2018-01-24 07:20:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-24 07:20:51 --> Input Class Initialized
INFO - 2018-01-24 07:20:51 --> Language Class Initialized
INFO - 2018-01-24 07:20:51 --> Loader Class Initialized
INFO - 2018-01-24 07:20:51 --> Helper loaded: url_helper
INFO - 2018-01-24 07:20:51 --> Helper loaded: form_helper
INFO - 2018-01-24 07:20:51 --> Database Driver Class Initialized
DEBUG - 2018-01-24 07:20:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-24 07:20:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-24 07:20:51 --> Form Validation Class Initialized
INFO - 2018-01-24 07:20:51 --> Model Class Initialized
INFO - 2018-01-24 07:20:51 --> Controller Class Initialized
INFO - 2018-01-24 07:20:51 --> Model Class Initialized
DEBUG - 2018-01-24 07:20:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-24 07:40:09 --> Config Class Initialized
INFO - 2018-01-24 07:40:09 --> Hooks Class Initialized
DEBUG - 2018-01-24 07:40:09 --> UTF-8 Support Enabled
INFO - 2018-01-24 07:40:09 --> Utf8 Class Initialized
INFO - 2018-01-24 07:40:09 --> URI Class Initialized
INFO - 2018-01-24 07:40:09 --> Router Class Initialized
INFO - 2018-01-24 07:40:09 --> Output Class Initialized
INFO - 2018-01-24 07:40:09 --> Security Class Initialized
DEBUG - 2018-01-24 07:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-24 07:40:09 --> Input Class Initialized
INFO - 2018-01-24 07:40:09 --> Language Class Initialized
INFO - 2018-01-24 07:40:09 --> Loader Class Initialized
INFO - 2018-01-24 07:40:09 --> Helper loaded: url_helper
INFO - 2018-01-24 07:40:09 --> Helper loaded: form_helper
INFO - 2018-01-24 07:40:09 --> Database Driver Class Initialized
DEBUG - 2018-01-24 07:40:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-24 07:40:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-24 07:40:09 --> Form Validation Class Initialized
INFO - 2018-01-24 07:40:09 --> Model Class Initialized
INFO - 2018-01-24 07:40:09 --> Controller Class Initialized
INFO - 2018-01-24 07:40:09 --> Model Class Initialized
DEBUG - 2018-01-24 07:40:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-24 07:40:09 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-24 07:40:09 --> Final output sent to browser
DEBUG - 2018-01-24 07:40:09 --> Total execution time: 0.0368
INFO - 2018-01-24 07:40:10 --> Config Class Initialized
INFO - 2018-01-24 07:40:10 --> Hooks Class Initialized
DEBUG - 2018-01-24 07:40:10 --> UTF-8 Support Enabled
INFO - 2018-01-24 07:40:10 --> Utf8 Class Initialized
INFO - 2018-01-24 07:40:10 --> URI Class Initialized
INFO - 2018-01-24 07:40:10 --> Router Class Initialized
INFO - 2018-01-24 07:40:10 --> Output Class Initialized
INFO - 2018-01-24 07:40:10 --> Security Class Initialized
DEBUG - 2018-01-24 07:40:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-24 07:40:10 --> Input Class Initialized
INFO - 2018-01-24 07:40:10 --> Language Class Initialized
INFO - 2018-01-24 07:40:10 --> Loader Class Initialized
INFO - 2018-01-24 07:40:10 --> Helper loaded: url_helper
INFO - 2018-01-24 07:40:10 --> Helper loaded: form_helper
INFO - 2018-01-24 07:40:10 --> Database Driver Class Initialized
DEBUG - 2018-01-24 07:40:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-24 07:40:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-24 07:40:10 --> Form Validation Class Initialized
INFO - 2018-01-24 07:40:10 --> Model Class Initialized
INFO - 2018-01-24 07:40:10 --> Controller Class Initialized
INFO - 2018-01-24 07:40:10 --> Model Class Initialized
DEBUG - 2018-01-24 07:40:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-24 07:40:14 --> Config Class Initialized
INFO - 2018-01-24 07:40:14 --> Hooks Class Initialized
DEBUG - 2018-01-24 07:40:14 --> UTF-8 Support Enabled
INFO - 2018-01-24 07:40:14 --> Utf8 Class Initialized
INFO - 2018-01-24 07:40:14 --> URI Class Initialized
INFO - 2018-01-24 07:40:14 --> Router Class Initialized
INFO - 2018-01-24 07:40:14 --> Output Class Initialized
INFO - 2018-01-24 07:40:14 --> Security Class Initialized
DEBUG - 2018-01-24 07:40:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-24 07:40:14 --> Input Class Initialized
INFO - 2018-01-24 07:40:14 --> Language Class Initialized
INFO - 2018-01-24 07:40:14 --> Loader Class Initialized
INFO - 2018-01-24 07:40:14 --> Helper loaded: url_helper
INFO - 2018-01-24 07:40:14 --> Helper loaded: form_helper
INFO - 2018-01-24 07:40:14 --> Database Driver Class Initialized
DEBUG - 2018-01-24 07:40:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-24 07:40:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-24 07:40:14 --> Form Validation Class Initialized
INFO - 2018-01-24 07:40:14 --> Model Class Initialized
INFO - 2018-01-24 07:40:14 --> Controller Class Initialized
INFO - 2018-01-24 07:40:14 --> Model Class Initialized
DEBUG - 2018-01-24 07:40:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-24 07:40:14 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-24 07:40:14 --> Final output sent to browser
DEBUG - 2018-01-24 07:40:14 --> Total execution time: 0.0504
INFO - 2018-01-24 07:40:53 --> Config Class Initialized
INFO - 2018-01-24 07:40:53 --> Hooks Class Initialized
DEBUG - 2018-01-24 07:40:53 --> UTF-8 Support Enabled
INFO - 2018-01-24 07:40:53 --> Utf8 Class Initialized
INFO - 2018-01-24 07:40:53 --> URI Class Initialized
INFO - 2018-01-24 07:40:53 --> Router Class Initialized
INFO - 2018-01-24 07:40:53 --> Output Class Initialized
INFO - 2018-01-24 07:40:53 --> Security Class Initialized
DEBUG - 2018-01-24 07:40:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-24 07:40:53 --> Input Class Initialized
INFO - 2018-01-24 07:40:53 --> Language Class Initialized
INFO - 2018-01-24 07:40:53 --> Loader Class Initialized
INFO - 2018-01-24 07:40:53 --> Helper loaded: url_helper
INFO - 2018-01-24 07:40:53 --> Helper loaded: form_helper
INFO - 2018-01-24 07:40:53 --> Database Driver Class Initialized
DEBUG - 2018-01-24 07:40:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-24 07:40:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-24 07:40:53 --> Form Validation Class Initialized
INFO - 2018-01-24 07:40:53 --> Model Class Initialized
INFO - 2018-01-24 07:40:53 --> Controller Class Initialized
INFO - 2018-01-24 07:40:53 --> Model Class Initialized
DEBUG - 2018-01-24 07:40:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-24 07:40:54 --> Model Class Initialized
ERROR - 2018-01-24 07:40:54 --> Query error: Unknown column 'usuario' in 'field list' - Invalid query: INSERT INTO `colaborador` (`colaborador_puesto_id`, `nombre`, `apellidos`, `correo_electronico`, `usuario`, `password`, `repetir_contrasena`, `rol_id`, `estado_id`) VALUES (1, 'Fabiola', 'Chaves', 'fabiola@instateccr.com', 'fchaves', 'contrasena', 'contrasena', '3', '1')
INFO - 2018-01-24 07:40:54 --> Language file loaded: language/english/db_lang.php
INFO - 2018-01-24 07:42:18 --> Config Class Initialized
INFO - 2018-01-24 07:42:18 --> Hooks Class Initialized
DEBUG - 2018-01-24 07:42:18 --> UTF-8 Support Enabled
INFO - 2018-01-24 07:42:18 --> Utf8 Class Initialized
INFO - 2018-01-24 07:42:18 --> URI Class Initialized
INFO - 2018-01-24 07:42:18 --> Router Class Initialized
INFO - 2018-01-24 07:42:18 --> Output Class Initialized
INFO - 2018-01-24 07:42:18 --> Security Class Initialized
DEBUG - 2018-01-24 07:42:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-24 07:42:18 --> Input Class Initialized
INFO - 2018-01-24 07:42:18 --> Language Class Initialized
INFO - 2018-01-24 07:42:18 --> Loader Class Initialized
INFO - 2018-01-24 07:42:18 --> Helper loaded: url_helper
INFO - 2018-01-24 07:42:18 --> Helper loaded: form_helper
INFO - 2018-01-24 07:42:18 --> Database Driver Class Initialized
DEBUG - 2018-01-24 07:42:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-24 07:42:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-24 07:42:18 --> Form Validation Class Initialized
INFO - 2018-01-24 07:42:18 --> Model Class Initialized
INFO - 2018-01-24 07:42:18 --> Controller Class Initialized
INFO - 2018-01-24 07:42:18 --> Model Class Initialized
DEBUG - 2018-01-24 07:42:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-24 07:42:18 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-24 07:42:18 --> Final output sent to browser
DEBUG - 2018-01-24 07:42:18 --> Total execution time: 0.0452
INFO - 2018-01-24 07:42:53 --> Config Class Initialized
INFO - 2018-01-24 07:42:53 --> Hooks Class Initialized
DEBUG - 2018-01-24 07:42:53 --> UTF-8 Support Enabled
INFO - 2018-01-24 07:42:53 --> Utf8 Class Initialized
INFO - 2018-01-24 07:42:53 --> URI Class Initialized
INFO - 2018-01-24 07:42:53 --> Router Class Initialized
INFO - 2018-01-24 07:42:53 --> Output Class Initialized
INFO - 2018-01-24 07:42:53 --> Security Class Initialized
DEBUG - 2018-01-24 07:42:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-24 07:42:53 --> Input Class Initialized
INFO - 2018-01-24 07:42:53 --> Language Class Initialized
INFO - 2018-01-24 07:42:53 --> Loader Class Initialized
INFO - 2018-01-24 07:42:53 --> Helper loaded: url_helper
INFO - 2018-01-24 07:42:53 --> Helper loaded: form_helper
INFO - 2018-01-24 07:42:53 --> Database Driver Class Initialized
DEBUG - 2018-01-24 07:42:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-24 07:42:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-24 07:42:53 --> Form Validation Class Initialized
INFO - 2018-01-24 07:42:53 --> Model Class Initialized
INFO - 2018-01-24 07:42:53 --> Controller Class Initialized
INFO - 2018-01-24 07:42:53 --> Model Class Initialized
DEBUG - 2018-01-24 07:42:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-24 07:42:53 --> Model Class Initialized
INFO - 2018-01-24 07:42:53 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-24 07:42:53 --> Final output sent to browser
DEBUG - 2018-01-24 07:42:53 --> Total execution time: 0.3020
INFO - 2018-01-24 07:48:47 --> Config Class Initialized
INFO - 2018-01-24 07:48:47 --> Hooks Class Initialized
DEBUG - 2018-01-24 07:48:47 --> UTF-8 Support Enabled
INFO - 2018-01-24 07:48:47 --> Utf8 Class Initialized
INFO - 2018-01-24 07:48:47 --> URI Class Initialized
INFO - 2018-01-24 07:48:47 --> Router Class Initialized
INFO - 2018-01-24 07:48:47 --> Output Class Initialized
INFO - 2018-01-24 07:48:47 --> Security Class Initialized
DEBUG - 2018-01-24 07:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-24 07:48:47 --> Input Class Initialized
INFO - 2018-01-24 07:48:47 --> Language Class Initialized
INFO - 2018-01-24 07:48:47 --> Loader Class Initialized
INFO - 2018-01-24 07:48:47 --> Helper loaded: url_helper
INFO - 2018-01-24 07:48:47 --> Helper loaded: form_helper
INFO - 2018-01-24 07:48:47 --> Database Driver Class Initialized
DEBUG - 2018-01-24 07:48:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-24 07:48:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-24 07:48:47 --> Form Validation Class Initialized
INFO - 2018-01-24 07:48:47 --> Model Class Initialized
INFO - 2018-01-24 07:48:47 --> Controller Class Initialized
INFO - 2018-01-24 07:48:47 --> Model Class Initialized
DEBUG - 2018-01-24 07:48:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-24 07:48:47 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-24 07:48:47 --> Final output sent to browser
DEBUG - 2018-01-24 07:48:47 --> Total execution time: 0.0396
INFO - 2018-01-24 07:48:48 --> Config Class Initialized
INFO - 2018-01-24 07:48:48 --> Hooks Class Initialized
DEBUG - 2018-01-24 07:48:48 --> UTF-8 Support Enabled
INFO - 2018-01-24 07:48:48 --> Utf8 Class Initialized
INFO - 2018-01-24 07:48:48 --> URI Class Initialized
INFO - 2018-01-24 07:48:48 --> Router Class Initialized
INFO - 2018-01-24 07:48:48 --> Output Class Initialized
INFO - 2018-01-24 07:48:48 --> Security Class Initialized
DEBUG - 2018-01-24 07:48:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-24 07:48:48 --> Input Class Initialized
INFO - 2018-01-24 07:48:48 --> Language Class Initialized
INFO - 2018-01-24 07:48:48 --> Loader Class Initialized
INFO - 2018-01-24 07:48:48 --> Helper loaded: url_helper
INFO - 2018-01-24 07:48:48 --> Helper loaded: form_helper
INFO - 2018-01-24 07:48:48 --> Database Driver Class Initialized
DEBUG - 2018-01-24 07:48:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-24 07:48:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-24 07:48:48 --> Form Validation Class Initialized
INFO - 2018-01-24 07:48:48 --> Model Class Initialized
INFO - 2018-01-24 07:48:48 --> Controller Class Initialized
INFO - 2018-01-24 07:48:48 --> Model Class Initialized
DEBUG - 2018-01-24 07:48:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-24 07:48:49 --> Config Class Initialized
INFO - 2018-01-24 07:48:49 --> Hooks Class Initialized
DEBUG - 2018-01-24 07:48:49 --> UTF-8 Support Enabled
INFO - 2018-01-24 07:48:49 --> Utf8 Class Initialized
INFO - 2018-01-24 07:48:49 --> URI Class Initialized
INFO - 2018-01-24 07:48:49 --> Router Class Initialized
INFO - 2018-01-24 07:48:49 --> Output Class Initialized
INFO - 2018-01-24 07:48:49 --> Security Class Initialized
DEBUG - 2018-01-24 07:48:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-24 07:48:49 --> Input Class Initialized
INFO - 2018-01-24 07:48:49 --> Language Class Initialized
INFO - 2018-01-24 07:48:49 --> Loader Class Initialized
INFO - 2018-01-24 07:48:49 --> Helper loaded: url_helper
INFO - 2018-01-24 07:48:49 --> Helper loaded: form_helper
INFO - 2018-01-24 07:48:49 --> Database Driver Class Initialized
DEBUG - 2018-01-24 07:48:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-24 07:48:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-24 07:48:49 --> Form Validation Class Initialized
INFO - 2018-01-24 07:48:49 --> Model Class Initialized
INFO - 2018-01-24 07:48:49 --> Controller Class Initialized
INFO - 2018-01-24 07:48:49 --> Model Class Initialized
DEBUG - 2018-01-24 07:48:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-24 07:48:49 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-24 07:48:49 --> Final output sent to browser
DEBUG - 2018-01-24 07:48:49 --> Total execution time: 0.0512
INFO - 2018-01-24 07:49:20 --> Config Class Initialized
INFO - 2018-01-24 07:49:20 --> Hooks Class Initialized
DEBUG - 2018-01-24 07:49:20 --> UTF-8 Support Enabled
INFO - 2018-01-24 07:49:20 --> Utf8 Class Initialized
INFO - 2018-01-24 07:49:20 --> URI Class Initialized
INFO - 2018-01-24 07:49:20 --> Router Class Initialized
INFO - 2018-01-24 07:49:20 --> Output Class Initialized
INFO - 2018-01-24 07:49:20 --> Security Class Initialized
DEBUG - 2018-01-24 07:49:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-24 07:49:20 --> Input Class Initialized
INFO - 2018-01-24 07:49:20 --> Language Class Initialized
INFO - 2018-01-24 07:49:20 --> Loader Class Initialized
INFO - 2018-01-24 07:49:21 --> Helper loaded: url_helper
INFO - 2018-01-24 07:49:21 --> Helper loaded: form_helper
INFO - 2018-01-24 07:49:21 --> Database Driver Class Initialized
DEBUG - 2018-01-24 07:49:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-24 07:49:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-24 07:49:21 --> Form Validation Class Initialized
INFO - 2018-01-24 07:49:21 --> Model Class Initialized
INFO - 2018-01-24 07:49:21 --> Controller Class Initialized
INFO - 2018-01-24 07:49:21 --> Model Class Initialized
DEBUG - 2018-01-24 07:49:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-24 07:49:21 --> Model Class Initialized
INFO - 2018-01-24 07:49:21 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-24 07:49:21 --> Final output sent to browser
DEBUG - 2018-01-24 07:49:21 --> Total execution time: 0.5606
INFO - 2018-01-24 07:50:12 --> Config Class Initialized
INFO - 2018-01-24 07:50:12 --> Hooks Class Initialized
DEBUG - 2018-01-24 07:50:12 --> UTF-8 Support Enabled
INFO - 2018-01-24 07:50:12 --> Utf8 Class Initialized
INFO - 2018-01-24 07:50:12 --> URI Class Initialized
INFO - 2018-01-24 07:50:12 --> Router Class Initialized
INFO - 2018-01-24 07:50:12 --> Output Class Initialized
INFO - 2018-01-24 07:50:12 --> Security Class Initialized
DEBUG - 2018-01-24 07:50:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-24 07:50:12 --> Input Class Initialized
INFO - 2018-01-24 07:50:12 --> Language Class Initialized
INFO - 2018-01-24 07:50:12 --> Loader Class Initialized
INFO - 2018-01-24 07:50:12 --> Helper loaded: url_helper
INFO - 2018-01-24 07:50:12 --> Helper loaded: form_helper
INFO - 2018-01-24 07:50:12 --> Database Driver Class Initialized
DEBUG - 2018-01-24 07:50:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-24 07:50:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-24 07:50:12 --> Form Validation Class Initialized
INFO - 2018-01-24 07:50:12 --> Model Class Initialized
INFO - 2018-01-24 07:50:12 --> Controller Class Initialized
INFO - 2018-01-24 07:50:12 --> Model Class Initialized
DEBUG - 2018-01-24 07:50:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-24 07:50:12 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-24 07:50:12 --> Final output sent to browser
DEBUG - 2018-01-24 07:50:12 --> Total execution time: 0.0493
INFO - 2018-01-24 07:50:12 --> Config Class Initialized
INFO - 2018-01-24 07:50:12 --> Hooks Class Initialized
DEBUG - 2018-01-24 07:50:12 --> UTF-8 Support Enabled
INFO - 2018-01-24 07:50:12 --> Utf8 Class Initialized
INFO - 2018-01-24 07:50:12 --> URI Class Initialized
INFO - 2018-01-24 07:50:12 --> Router Class Initialized
INFO - 2018-01-24 07:50:12 --> Output Class Initialized
INFO - 2018-01-24 07:50:12 --> Security Class Initialized
DEBUG - 2018-01-24 07:50:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-24 07:50:12 --> Input Class Initialized
INFO - 2018-01-24 07:50:12 --> Language Class Initialized
INFO - 2018-01-24 07:50:12 --> Loader Class Initialized
INFO - 2018-01-24 07:50:12 --> Helper loaded: url_helper
INFO - 2018-01-24 07:50:12 --> Helper loaded: form_helper
INFO - 2018-01-24 07:50:12 --> Database Driver Class Initialized
DEBUG - 2018-01-24 07:50:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-24 07:50:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-24 07:50:13 --> Form Validation Class Initialized
INFO - 2018-01-24 07:50:13 --> Model Class Initialized
INFO - 2018-01-24 07:50:13 --> Controller Class Initialized
INFO - 2018-01-24 07:50:13 --> Model Class Initialized
DEBUG - 2018-01-24 07:50:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-24 07:50:16 --> Config Class Initialized
INFO - 2018-01-24 07:50:16 --> Hooks Class Initialized
DEBUG - 2018-01-24 07:50:16 --> UTF-8 Support Enabled
INFO - 2018-01-24 07:50:16 --> Utf8 Class Initialized
INFO - 2018-01-24 07:50:16 --> URI Class Initialized
INFO - 2018-01-24 07:50:16 --> Router Class Initialized
INFO - 2018-01-24 07:50:16 --> Output Class Initialized
INFO - 2018-01-24 07:50:16 --> Security Class Initialized
DEBUG - 2018-01-24 07:50:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-24 07:50:16 --> Input Class Initialized
INFO - 2018-01-24 07:50:16 --> Language Class Initialized
INFO - 2018-01-24 07:50:16 --> Loader Class Initialized
INFO - 2018-01-24 07:50:16 --> Helper loaded: url_helper
INFO - 2018-01-24 07:50:16 --> Helper loaded: form_helper
INFO - 2018-01-24 07:50:16 --> Database Driver Class Initialized
DEBUG - 2018-01-24 07:50:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-24 07:50:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-24 07:50:16 --> Form Validation Class Initialized
INFO - 2018-01-24 07:50:16 --> Model Class Initialized
INFO - 2018-01-24 07:50:16 --> Controller Class Initialized
INFO - 2018-01-24 07:50:16 --> Model Class Initialized
DEBUG - 2018-01-24 07:50:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-24 07:50:16 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-24 07:50:16 --> Final output sent to browser
DEBUG - 2018-01-24 07:50:16 --> Total execution time: 0.0399
INFO - 2018-01-24 07:50:50 --> Config Class Initialized
INFO - 2018-01-24 07:50:50 --> Hooks Class Initialized
DEBUG - 2018-01-24 07:50:50 --> UTF-8 Support Enabled
INFO - 2018-01-24 07:50:50 --> Utf8 Class Initialized
INFO - 2018-01-24 07:50:50 --> URI Class Initialized
INFO - 2018-01-24 07:50:50 --> Router Class Initialized
INFO - 2018-01-24 07:50:50 --> Output Class Initialized
INFO - 2018-01-24 07:50:50 --> Security Class Initialized
DEBUG - 2018-01-24 07:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-24 07:50:50 --> Input Class Initialized
INFO - 2018-01-24 07:50:50 --> Language Class Initialized
INFO - 2018-01-24 07:50:50 --> Loader Class Initialized
INFO - 2018-01-24 07:50:50 --> Helper loaded: url_helper
INFO - 2018-01-24 07:50:50 --> Helper loaded: form_helper
INFO - 2018-01-24 07:50:50 --> Database Driver Class Initialized
DEBUG - 2018-01-24 07:50:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-24 07:50:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-24 07:50:50 --> Form Validation Class Initialized
INFO - 2018-01-24 07:50:50 --> Model Class Initialized
INFO - 2018-01-24 07:50:50 --> Controller Class Initialized
INFO - 2018-01-24 07:50:50 --> Model Class Initialized
DEBUG - 2018-01-24 07:50:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-24 07:50:51 --> Model Class Initialized
INFO - 2018-01-24 07:51:50 --> Config Class Initialized
INFO - 2018-01-24 07:51:50 --> Hooks Class Initialized
DEBUG - 2018-01-24 07:51:50 --> UTF-8 Support Enabled
INFO - 2018-01-24 07:51:50 --> Utf8 Class Initialized
INFO - 2018-01-24 07:51:50 --> URI Class Initialized
INFO - 2018-01-24 07:51:50 --> Router Class Initialized
INFO - 2018-01-24 07:51:50 --> Output Class Initialized
INFO - 2018-01-24 07:51:50 --> Security Class Initialized
DEBUG - 2018-01-24 07:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-24 07:51:50 --> Input Class Initialized
INFO - 2018-01-24 07:51:50 --> Language Class Initialized
INFO - 2018-01-24 07:51:50 --> Loader Class Initialized
INFO - 2018-01-24 07:51:50 --> Helper loaded: url_helper
INFO - 2018-01-24 07:51:50 --> Helper loaded: form_helper
INFO - 2018-01-24 07:51:50 --> Database Driver Class Initialized
DEBUG - 2018-01-24 07:51:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-24 07:51:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-24 07:51:50 --> Form Validation Class Initialized
INFO - 2018-01-24 07:51:50 --> Model Class Initialized
INFO - 2018-01-24 07:51:50 --> Controller Class Initialized
INFO - 2018-01-24 07:51:50 --> Model Class Initialized
DEBUG - 2018-01-24 07:51:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-24 07:51:50 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-24 07:51:50 --> Final output sent to browser
DEBUG - 2018-01-24 07:51:50 --> Total execution time: 0.0472
INFO - 2018-01-24 07:53:20 --> Config Class Initialized
INFO - 2018-01-24 07:53:20 --> Hooks Class Initialized
DEBUG - 2018-01-24 07:53:20 --> UTF-8 Support Enabled
INFO - 2018-01-24 07:53:20 --> Utf8 Class Initialized
INFO - 2018-01-24 07:53:20 --> URI Class Initialized
INFO - 2018-01-24 07:53:20 --> Router Class Initialized
INFO - 2018-01-24 07:53:20 --> Output Class Initialized
INFO - 2018-01-24 07:53:20 --> Security Class Initialized
DEBUG - 2018-01-24 07:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-24 07:53:20 --> Input Class Initialized
INFO - 2018-01-24 07:53:20 --> Language Class Initialized
INFO - 2018-01-24 07:53:20 --> Loader Class Initialized
INFO - 2018-01-24 07:53:20 --> Helper loaded: url_helper
INFO - 2018-01-24 07:53:20 --> Helper loaded: form_helper
INFO - 2018-01-24 07:53:20 --> Database Driver Class Initialized
DEBUG - 2018-01-24 07:53:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-24 07:53:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-24 07:53:20 --> Form Validation Class Initialized
INFO - 2018-01-24 07:53:20 --> Model Class Initialized
INFO - 2018-01-24 07:53:20 --> Controller Class Initialized
INFO - 2018-01-24 07:53:20 --> Model Class Initialized
DEBUG - 2018-01-24 07:53:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-24 07:53:20 --> Model Class Initialized
INFO - 2018-01-24 07:53:20 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-24 07:53:20 --> Final output sent to browser
DEBUG - 2018-01-24 07:53:20 --> Total execution time: 0.5325
INFO - 2018-01-24 07:56:00 --> Config Class Initialized
INFO - 2018-01-24 07:56:00 --> Hooks Class Initialized
DEBUG - 2018-01-24 07:56:00 --> UTF-8 Support Enabled
INFO - 2018-01-24 07:56:00 --> Utf8 Class Initialized
INFO - 2018-01-24 07:56:00 --> URI Class Initialized
INFO - 2018-01-24 07:56:00 --> Router Class Initialized
INFO - 2018-01-24 07:56:00 --> Output Class Initialized
INFO - 2018-01-24 07:56:00 --> Security Class Initialized
DEBUG - 2018-01-24 07:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-24 07:56:00 --> Input Class Initialized
INFO - 2018-01-24 07:56:00 --> Language Class Initialized
INFO - 2018-01-24 07:56:00 --> Loader Class Initialized
INFO - 2018-01-24 07:56:00 --> Helper loaded: url_helper
INFO - 2018-01-24 07:56:00 --> Helper loaded: form_helper
INFO - 2018-01-24 07:56:00 --> Database Driver Class Initialized
DEBUG - 2018-01-24 07:56:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-24 07:56:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-24 07:56:00 --> Form Validation Class Initialized
INFO - 2018-01-24 07:56:00 --> Model Class Initialized
INFO - 2018-01-24 07:56:00 --> Controller Class Initialized
INFO - 2018-01-24 07:56:00 --> Model Class Initialized
DEBUG - 2018-01-24 07:56:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-24 07:56:00 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-24 07:56:00 --> Final output sent to browser
DEBUG - 2018-01-24 07:56:00 --> Total execution time: 0.0495
INFO - 2018-01-24 07:57:26 --> Config Class Initialized
INFO - 2018-01-24 07:57:26 --> Hooks Class Initialized
DEBUG - 2018-01-24 07:57:26 --> UTF-8 Support Enabled
INFO - 2018-01-24 07:57:26 --> Utf8 Class Initialized
INFO - 2018-01-24 07:57:26 --> URI Class Initialized
INFO - 2018-01-24 07:57:26 --> Router Class Initialized
INFO - 2018-01-24 07:57:26 --> Output Class Initialized
INFO - 2018-01-24 07:57:26 --> Security Class Initialized
DEBUG - 2018-01-24 07:57:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-24 07:57:26 --> Input Class Initialized
INFO - 2018-01-24 07:57:26 --> Language Class Initialized
INFO - 2018-01-24 07:57:26 --> Loader Class Initialized
INFO - 2018-01-24 07:57:26 --> Helper loaded: url_helper
INFO - 2018-01-24 07:57:26 --> Helper loaded: form_helper
INFO - 2018-01-24 07:57:26 --> Database Driver Class Initialized
DEBUG - 2018-01-24 07:57:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-24 07:57:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-24 07:57:26 --> Form Validation Class Initialized
INFO - 2018-01-24 07:57:26 --> Model Class Initialized
INFO - 2018-01-24 07:57:26 --> Controller Class Initialized
INFO - 2018-01-24 07:57:26 --> Model Class Initialized
DEBUG - 2018-01-24 07:57:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-24 07:57:26 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-24 07:57:26 --> Final output sent to browser
DEBUG - 2018-01-24 07:57:26 --> Total execution time: 0.0849
INFO - 2018-01-24 07:57:46 --> Config Class Initialized
INFO - 2018-01-24 07:57:46 --> Hooks Class Initialized
DEBUG - 2018-01-24 07:57:46 --> UTF-8 Support Enabled
INFO - 2018-01-24 07:57:46 --> Utf8 Class Initialized
INFO - 2018-01-24 07:57:46 --> URI Class Initialized
INFO - 2018-01-24 07:57:46 --> Router Class Initialized
INFO - 2018-01-24 07:57:46 --> Output Class Initialized
INFO - 2018-01-24 07:57:47 --> Security Class Initialized
DEBUG - 2018-01-24 07:57:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-24 07:57:47 --> Input Class Initialized
INFO - 2018-01-24 07:57:47 --> Language Class Initialized
INFO - 2018-01-24 07:57:47 --> Loader Class Initialized
INFO - 2018-01-24 07:57:47 --> Helper loaded: url_helper
INFO - 2018-01-24 07:57:47 --> Helper loaded: form_helper
INFO - 2018-01-24 07:57:47 --> Database Driver Class Initialized
DEBUG - 2018-01-24 07:57:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-24 07:57:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-24 07:57:47 --> Form Validation Class Initialized
INFO - 2018-01-24 07:57:47 --> Model Class Initialized
INFO - 2018-01-24 07:57:47 --> Controller Class Initialized
INFO - 2018-01-24 07:57:47 --> Model Class Initialized
DEBUG - 2018-01-24 07:57:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-24 07:57:47 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-24 07:57:47 --> Final output sent to browser
DEBUG - 2018-01-24 07:57:47 --> Total execution time: 0.0686
INFO - 2018-01-24 07:58:22 --> Config Class Initialized
INFO - 2018-01-24 07:58:22 --> Hooks Class Initialized
DEBUG - 2018-01-24 07:58:22 --> UTF-8 Support Enabled
INFO - 2018-01-24 07:58:22 --> Utf8 Class Initialized
INFO - 2018-01-24 07:58:22 --> URI Class Initialized
INFO - 2018-01-24 07:58:22 --> Router Class Initialized
INFO - 2018-01-24 07:58:22 --> Output Class Initialized
INFO - 2018-01-24 07:58:22 --> Security Class Initialized
DEBUG - 2018-01-24 07:58:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-24 07:58:22 --> Input Class Initialized
INFO - 2018-01-24 07:58:22 --> Language Class Initialized
INFO - 2018-01-24 07:58:22 --> Loader Class Initialized
INFO - 2018-01-24 07:58:22 --> Helper loaded: url_helper
INFO - 2018-01-24 07:58:22 --> Helper loaded: form_helper
INFO - 2018-01-24 07:58:22 --> Database Driver Class Initialized
DEBUG - 2018-01-24 07:58:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-24 07:58:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-24 07:58:22 --> Form Validation Class Initialized
INFO - 2018-01-24 07:58:22 --> Model Class Initialized
INFO - 2018-01-24 07:58:22 --> Controller Class Initialized
INFO - 2018-01-24 07:58:22 --> Model Class Initialized
DEBUG - 2018-01-24 07:58:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-24 07:58:22 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-24 07:58:22 --> Final output sent to browser
DEBUG - 2018-01-24 07:58:22 --> Total execution time: 0.0495
INFO - 2018-01-24 07:58:23 --> Config Class Initialized
INFO - 2018-01-24 07:58:23 --> Hooks Class Initialized
DEBUG - 2018-01-24 07:58:23 --> UTF-8 Support Enabled
INFO - 2018-01-24 07:58:23 --> Utf8 Class Initialized
INFO - 2018-01-24 07:58:23 --> URI Class Initialized
INFO - 2018-01-24 07:58:23 --> Router Class Initialized
INFO - 2018-01-24 07:58:23 --> Output Class Initialized
INFO - 2018-01-24 07:58:23 --> Security Class Initialized
DEBUG - 2018-01-24 07:58:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-24 07:58:23 --> Input Class Initialized
INFO - 2018-01-24 07:58:23 --> Language Class Initialized
INFO - 2018-01-24 07:58:23 --> Loader Class Initialized
INFO - 2018-01-24 07:58:23 --> Helper loaded: url_helper
INFO - 2018-01-24 07:58:23 --> Helper loaded: form_helper
INFO - 2018-01-24 07:58:23 --> Database Driver Class Initialized
DEBUG - 2018-01-24 07:58:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-24 07:58:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-24 07:58:23 --> Form Validation Class Initialized
INFO - 2018-01-24 07:58:23 --> Model Class Initialized
INFO - 2018-01-24 07:58:23 --> Controller Class Initialized
INFO - 2018-01-24 07:58:23 --> Model Class Initialized
DEBUG - 2018-01-24 07:58:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-24 07:59:26 --> Config Class Initialized
INFO - 2018-01-24 07:59:26 --> Hooks Class Initialized
DEBUG - 2018-01-24 07:59:26 --> UTF-8 Support Enabled
INFO - 2018-01-24 07:59:26 --> Utf8 Class Initialized
INFO - 2018-01-24 07:59:26 --> URI Class Initialized
INFO - 2018-01-24 07:59:26 --> Router Class Initialized
INFO - 2018-01-24 07:59:26 --> Output Class Initialized
INFO - 2018-01-24 07:59:26 --> Security Class Initialized
DEBUG - 2018-01-24 07:59:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-24 07:59:26 --> Input Class Initialized
INFO - 2018-01-24 07:59:26 --> Language Class Initialized
INFO - 2018-01-24 07:59:26 --> Loader Class Initialized
INFO - 2018-01-24 07:59:26 --> Helper loaded: url_helper
INFO - 2018-01-24 07:59:26 --> Helper loaded: form_helper
INFO - 2018-01-24 07:59:26 --> Database Driver Class Initialized
DEBUG - 2018-01-24 07:59:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-24 07:59:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-24 07:59:26 --> Form Validation Class Initialized
INFO - 2018-01-24 07:59:26 --> Model Class Initialized
INFO - 2018-01-24 07:59:26 --> Controller Class Initialized
INFO - 2018-01-24 07:59:26 --> Model Class Initialized
DEBUG - 2018-01-24 07:59:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-24 07:59:26 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-24 07:59:26 --> Final output sent to browser
DEBUG - 2018-01-24 07:59:26 --> Total execution time: 0.0525
INFO - 2018-01-24 07:59:27 --> Config Class Initialized
INFO - 2018-01-24 07:59:27 --> Hooks Class Initialized
DEBUG - 2018-01-24 07:59:27 --> UTF-8 Support Enabled
INFO - 2018-01-24 07:59:27 --> Utf8 Class Initialized
INFO - 2018-01-24 07:59:27 --> URI Class Initialized
INFO - 2018-01-24 07:59:27 --> Router Class Initialized
INFO - 2018-01-24 07:59:27 --> Output Class Initialized
INFO - 2018-01-24 07:59:27 --> Security Class Initialized
DEBUG - 2018-01-24 07:59:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-24 07:59:27 --> Input Class Initialized
INFO - 2018-01-24 07:59:27 --> Language Class Initialized
INFO - 2018-01-24 07:59:27 --> Loader Class Initialized
INFO - 2018-01-24 07:59:27 --> Helper loaded: url_helper
INFO - 2018-01-24 07:59:27 --> Helper loaded: form_helper
INFO - 2018-01-24 07:59:27 --> Database Driver Class Initialized
DEBUG - 2018-01-24 07:59:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-24 07:59:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-24 07:59:27 --> Form Validation Class Initialized
INFO - 2018-01-24 07:59:27 --> Model Class Initialized
INFO - 2018-01-24 07:59:27 --> Controller Class Initialized
INFO - 2018-01-24 07:59:27 --> Model Class Initialized
DEBUG - 2018-01-24 07:59:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-24 07:59:52 --> Config Class Initialized
INFO - 2018-01-24 07:59:52 --> Hooks Class Initialized
DEBUG - 2018-01-24 07:59:52 --> UTF-8 Support Enabled
INFO - 2018-01-24 07:59:52 --> Utf8 Class Initialized
INFO - 2018-01-24 07:59:52 --> URI Class Initialized
INFO - 2018-01-24 07:59:52 --> Router Class Initialized
INFO - 2018-01-24 07:59:52 --> Output Class Initialized
INFO - 2018-01-24 07:59:52 --> Security Class Initialized
DEBUG - 2018-01-24 07:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-24 07:59:52 --> Input Class Initialized
INFO - 2018-01-24 07:59:52 --> Language Class Initialized
INFO - 2018-01-24 07:59:52 --> Loader Class Initialized
INFO - 2018-01-24 07:59:52 --> Helper loaded: url_helper
INFO - 2018-01-24 07:59:52 --> Helper loaded: form_helper
INFO - 2018-01-24 07:59:52 --> Database Driver Class Initialized
DEBUG - 2018-01-24 07:59:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-24 07:59:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-24 07:59:52 --> Form Validation Class Initialized
INFO - 2018-01-24 07:59:52 --> Model Class Initialized
INFO - 2018-01-24 07:59:52 --> Controller Class Initialized
INFO - 2018-01-24 07:59:52 --> Model Class Initialized
DEBUG - 2018-01-24 07:59:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-24 07:59:52 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-24 07:59:52 --> Final output sent to browser
DEBUG - 2018-01-24 07:59:52 --> Total execution time: 0.0486
INFO - 2018-01-24 07:59:53 --> Config Class Initialized
INFO - 2018-01-24 07:59:53 --> Hooks Class Initialized
DEBUG - 2018-01-24 07:59:53 --> UTF-8 Support Enabled
INFO - 2018-01-24 07:59:53 --> Utf8 Class Initialized
INFO - 2018-01-24 07:59:53 --> URI Class Initialized
INFO - 2018-01-24 07:59:53 --> Router Class Initialized
INFO - 2018-01-24 07:59:53 --> Output Class Initialized
INFO - 2018-01-24 07:59:53 --> Security Class Initialized
DEBUG - 2018-01-24 07:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-24 07:59:53 --> Input Class Initialized
INFO - 2018-01-24 07:59:53 --> Language Class Initialized
INFO - 2018-01-24 07:59:53 --> Loader Class Initialized
INFO - 2018-01-24 07:59:53 --> Helper loaded: url_helper
INFO - 2018-01-24 07:59:53 --> Helper loaded: form_helper
INFO - 2018-01-24 07:59:53 --> Database Driver Class Initialized
DEBUG - 2018-01-24 07:59:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-24 07:59:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-24 07:59:53 --> Form Validation Class Initialized
INFO - 2018-01-24 07:59:53 --> Model Class Initialized
INFO - 2018-01-24 07:59:53 --> Controller Class Initialized
INFO - 2018-01-24 07:59:53 --> Model Class Initialized
DEBUG - 2018-01-24 07:59:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-24 07:59:53 --> Config Class Initialized
INFO - 2018-01-24 07:59:53 --> Hooks Class Initialized
DEBUG - 2018-01-24 07:59:53 --> UTF-8 Support Enabled
INFO - 2018-01-24 07:59:53 --> Utf8 Class Initialized
INFO - 2018-01-24 07:59:53 --> URI Class Initialized
INFO - 2018-01-24 07:59:53 --> Router Class Initialized
INFO - 2018-01-24 07:59:53 --> Output Class Initialized
INFO - 2018-01-24 07:59:53 --> Security Class Initialized
DEBUG - 2018-01-24 07:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-24 07:59:53 --> Input Class Initialized
INFO - 2018-01-24 07:59:53 --> Language Class Initialized
INFO - 2018-01-24 07:59:53 --> Loader Class Initialized
INFO - 2018-01-24 07:59:53 --> Helper loaded: url_helper
INFO - 2018-01-24 07:59:53 --> Helper loaded: form_helper
INFO - 2018-01-24 07:59:53 --> Database Driver Class Initialized
DEBUG - 2018-01-24 07:59:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-24 07:59:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-24 07:59:53 --> Form Validation Class Initialized
INFO - 2018-01-24 07:59:53 --> Model Class Initialized
INFO - 2018-01-24 07:59:53 --> Controller Class Initialized
INFO - 2018-01-24 07:59:53 --> Model Class Initialized
INFO - 2018-01-24 07:59:53 --> Model Class Initialized
INFO - 2018-01-24 07:59:53 --> Model Class Initialized
INFO - 2018-01-24 07:59:53 --> Model Class Initialized
DEBUG - 2018-01-24 07:59:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-24 07:59:53 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-24 07:59:53 --> Final output sent to browser
DEBUG - 2018-01-24 07:59:53 --> Total execution time: 0.2073
INFO - 2018-01-24 07:59:55 --> Config Class Initialized
INFO - 2018-01-24 07:59:55 --> Hooks Class Initialized
DEBUG - 2018-01-24 07:59:55 --> UTF-8 Support Enabled
INFO - 2018-01-24 07:59:55 --> Utf8 Class Initialized
INFO - 2018-01-24 07:59:55 --> URI Class Initialized
INFO - 2018-01-24 07:59:55 --> Router Class Initialized
INFO - 2018-01-24 07:59:55 --> Output Class Initialized
INFO - 2018-01-24 07:59:55 --> Security Class Initialized
DEBUG - 2018-01-24 07:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-24 07:59:55 --> Input Class Initialized
INFO - 2018-01-24 07:59:55 --> Language Class Initialized
INFO - 2018-01-24 07:59:55 --> Loader Class Initialized
INFO - 2018-01-24 07:59:55 --> Helper loaded: url_helper
INFO - 2018-01-24 07:59:55 --> Helper loaded: form_helper
INFO - 2018-01-24 07:59:55 --> Database Driver Class Initialized
DEBUG - 2018-01-24 07:59:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-24 07:59:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-24 07:59:55 --> Form Validation Class Initialized
INFO - 2018-01-24 07:59:55 --> Model Class Initialized
INFO - 2018-01-24 07:59:55 --> Controller Class Initialized
INFO - 2018-01-24 07:59:55 --> Model Class Initialized
DEBUG - 2018-01-24 07:59:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-24 07:59:55 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-01-24 07:59:55 --> Final output sent to browser
DEBUG - 2018-01-24 07:59:55 --> Total execution time: 0.0377
INFO - 2018-01-24 07:59:55 --> Config Class Initialized
INFO - 2018-01-24 07:59:55 --> Hooks Class Initialized
DEBUG - 2018-01-24 07:59:55 --> UTF-8 Support Enabled
INFO - 2018-01-24 07:59:55 --> Utf8 Class Initialized
INFO - 2018-01-24 07:59:55 --> URI Class Initialized
INFO - 2018-01-24 07:59:55 --> Router Class Initialized
INFO - 2018-01-24 07:59:55 --> Output Class Initialized
INFO - 2018-01-24 07:59:55 --> Security Class Initialized
DEBUG - 2018-01-24 07:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-24 07:59:55 --> Input Class Initialized
INFO - 2018-01-24 07:59:55 --> Language Class Initialized
INFO - 2018-01-24 07:59:55 --> Loader Class Initialized
INFO - 2018-01-24 07:59:55 --> Helper loaded: url_helper
INFO - 2018-01-24 07:59:55 --> Helper loaded: form_helper
INFO - 2018-01-24 07:59:55 --> Database Driver Class Initialized
DEBUG - 2018-01-24 07:59:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-24 07:59:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-24 07:59:55 --> Form Validation Class Initialized
INFO - 2018-01-24 07:59:55 --> Model Class Initialized
INFO - 2018-01-24 07:59:55 --> Controller Class Initialized
INFO - 2018-01-24 07:59:55 --> Model Class Initialized
DEBUG - 2018-01-24 07:59:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-24 08:00:07 --> Config Class Initialized
INFO - 2018-01-24 08:00:07 --> Hooks Class Initialized
DEBUG - 2018-01-24 08:00:07 --> UTF-8 Support Enabled
INFO - 2018-01-24 08:00:07 --> Utf8 Class Initialized
INFO - 2018-01-24 08:00:07 --> URI Class Initialized
INFO - 2018-01-24 08:00:07 --> Router Class Initialized
INFO - 2018-01-24 08:00:07 --> Output Class Initialized
INFO - 2018-01-24 08:00:07 --> Security Class Initialized
DEBUG - 2018-01-24 08:00:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-24 08:00:07 --> Input Class Initialized
INFO - 2018-01-24 08:00:07 --> Language Class Initialized
INFO - 2018-01-24 08:00:07 --> Loader Class Initialized
INFO - 2018-01-24 08:00:07 --> Helper loaded: url_helper
INFO - 2018-01-24 08:00:07 --> Helper loaded: form_helper
INFO - 2018-01-24 08:00:07 --> Database Driver Class Initialized
DEBUG - 2018-01-24 08:00:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-24 08:00:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-24 08:00:07 --> Form Validation Class Initialized
INFO - 2018-01-24 08:00:07 --> Model Class Initialized
INFO - 2018-01-24 08:00:07 --> Controller Class Initialized
INFO - 2018-01-24 08:00:07 --> Model Class Initialized
DEBUG - 2018-01-24 08:00:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-24 08:00:09 --> Config Class Initialized
INFO - 2018-01-24 08:00:09 --> Hooks Class Initialized
DEBUG - 2018-01-24 08:00:09 --> UTF-8 Support Enabled
INFO - 2018-01-24 08:00:09 --> Utf8 Class Initialized
INFO - 2018-01-24 08:00:09 --> URI Class Initialized
INFO - 2018-01-24 08:00:09 --> Router Class Initialized
INFO - 2018-01-24 08:00:09 --> Output Class Initialized
INFO - 2018-01-24 08:00:09 --> Security Class Initialized
DEBUG - 2018-01-24 08:00:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-24 08:00:09 --> Input Class Initialized
INFO - 2018-01-24 08:00:09 --> Language Class Initialized
INFO - 2018-01-24 08:00:09 --> Loader Class Initialized
INFO - 2018-01-24 08:00:09 --> Helper loaded: url_helper
INFO - 2018-01-24 08:00:09 --> Helper loaded: form_helper
INFO - 2018-01-24 08:00:09 --> Database Driver Class Initialized
DEBUG - 2018-01-24 08:00:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-24 08:00:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-24 08:00:09 --> Form Validation Class Initialized
INFO - 2018-01-24 08:00:09 --> Model Class Initialized
INFO - 2018-01-24 08:00:09 --> Controller Class Initialized
INFO - 2018-01-24 08:00:09 --> Model Class Initialized
DEBUG - 2018-01-24 08:00:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-24 08:00:12 --> Config Class Initialized
INFO - 2018-01-24 08:00:12 --> Hooks Class Initialized
DEBUG - 2018-01-24 08:00:12 --> UTF-8 Support Enabled
INFO - 2018-01-24 08:00:12 --> Utf8 Class Initialized
INFO - 2018-01-24 08:00:12 --> URI Class Initialized
INFO - 2018-01-24 08:00:12 --> Router Class Initialized
INFO - 2018-01-24 08:00:12 --> Output Class Initialized
INFO - 2018-01-24 08:00:12 --> Security Class Initialized
DEBUG - 2018-01-24 08:00:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-24 08:00:12 --> Input Class Initialized
INFO - 2018-01-24 08:00:12 --> Language Class Initialized
INFO - 2018-01-24 08:00:12 --> Loader Class Initialized
INFO - 2018-01-24 08:00:12 --> Helper loaded: url_helper
INFO - 2018-01-24 08:00:12 --> Helper loaded: form_helper
INFO - 2018-01-24 08:00:12 --> Database Driver Class Initialized
DEBUG - 2018-01-24 08:00:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-24 08:00:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-24 08:00:12 --> Form Validation Class Initialized
INFO - 2018-01-24 08:00:12 --> Model Class Initialized
INFO - 2018-01-24 08:00:12 --> Controller Class Initialized
INFO - 2018-01-24 08:00:12 --> Model Class Initialized
DEBUG - 2018-01-24 08:00:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-24 08:00:14 --> Config Class Initialized
INFO - 2018-01-24 08:00:14 --> Hooks Class Initialized
DEBUG - 2018-01-24 08:00:14 --> UTF-8 Support Enabled
INFO - 2018-01-24 08:00:14 --> Utf8 Class Initialized
INFO - 2018-01-24 08:00:14 --> URI Class Initialized
INFO - 2018-01-24 08:00:14 --> Router Class Initialized
INFO - 2018-01-24 08:00:14 --> Output Class Initialized
INFO - 2018-01-24 08:00:14 --> Security Class Initialized
DEBUG - 2018-01-24 08:00:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-24 08:00:14 --> Input Class Initialized
INFO - 2018-01-24 08:00:14 --> Language Class Initialized
INFO - 2018-01-24 08:00:14 --> Loader Class Initialized
INFO - 2018-01-24 08:00:14 --> Helper loaded: url_helper
INFO - 2018-01-24 08:00:14 --> Helper loaded: form_helper
INFO - 2018-01-24 08:00:14 --> Database Driver Class Initialized
DEBUG - 2018-01-24 08:00:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-24 08:00:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-24 08:00:14 --> Form Validation Class Initialized
INFO - 2018-01-24 08:00:14 --> Model Class Initialized
INFO - 2018-01-24 08:00:14 --> Controller Class Initialized
INFO - 2018-01-24 08:00:14 --> Model Class Initialized
DEBUG - 2018-01-24 08:00:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-24 08:00:17 --> Config Class Initialized
INFO - 2018-01-24 08:00:17 --> Hooks Class Initialized
DEBUG - 2018-01-24 08:00:17 --> UTF-8 Support Enabled
INFO - 2018-01-24 08:00:17 --> Utf8 Class Initialized
INFO - 2018-01-24 08:00:17 --> URI Class Initialized
INFO - 2018-01-24 08:00:17 --> Router Class Initialized
INFO - 2018-01-24 08:00:17 --> Output Class Initialized
INFO - 2018-01-24 08:00:17 --> Security Class Initialized
DEBUG - 2018-01-24 08:00:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-24 08:00:17 --> Input Class Initialized
INFO - 2018-01-24 08:00:17 --> Language Class Initialized
INFO - 2018-01-24 08:00:17 --> Loader Class Initialized
INFO - 2018-01-24 08:00:17 --> Helper loaded: url_helper
INFO - 2018-01-24 08:00:17 --> Helper loaded: form_helper
INFO - 2018-01-24 08:00:17 --> Database Driver Class Initialized
DEBUG - 2018-01-24 08:00:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-24 08:00:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-24 08:00:17 --> Form Validation Class Initialized
INFO - 2018-01-24 08:00:17 --> Model Class Initialized
INFO - 2018-01-24 08:00:17 --> Controller Class Initialized
INFO - 2018-01-24 08:00:17 --> Model Class Initialized
DEBUG - 2018-01-24 08:00:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-24 08:00:42 --> Config Class Initialized
INFO - 2018-01-24 08:00:42 --> Hooks Class Initialized
DEBUG - 2018-01-24 08:00:42 --> UTF-8 Support Enabled
INFO - 2018-01-24 08:00:42 --> Utf8 Class Initialized
INFO - 2018-01-24 08:00:42 --> URI Class Initialized
INFO - 2018-01-24 08:00:42 --> Router Class Initialized
INFO - 2018-01-24 08:00:42 --> Output Class Initialized
INFO - 2018-01-24 08:00:42 --> Security Class Initialized
DEBUG - 2018-01-24 08:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-24 08:00:42 --> Input Class Initialized
INFO - 2018-01-24 08:00:42 --> Language Class Initialized
INFO - 2018-01-24 08:00:42 --> Loader Class Initialized
INFO - 2018-01-24 08:00:42 --> Helper loaded: url_helper
INFO - 2018-01-24 08:00:42 --> Helper loaded: form_helper
INFO - 2018-01-24 08:00:42 --> Database Driver Class Initialized
DEBUG - 2018-01-24 08:00:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-24 08:00:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-24 08:00:42 --> Form Validation Class Initialized
INFO - 2018-01-24 08:00:42 --> Model Class Initialized
INFO - 2018-01-24 08:00:42 --> Controller Class Initialized
INFO - 2018-01-24 08:00:42 --> Model Class Initialized
DEBUG - 2018-01-24 08:00:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-24 08:00:46 --> Config Class Initialized
INFO - 2018-01-24 08:00:46 --> Hooks Class Initialized
DEBUG - 2018-01-24 08:00:46 --> UTF-8 Support Enabled
INFO - 2018-01-24 08:00:46 --> Utf8 Class Initialized
INFO - 2018-01-24 08:00:46 --> URI Class Initialized
INFO - 2018-01-24 08:00:46 --> Router Class Initialized
INFO - 2018-01-24 08:00:46 --> Output Class Initialized
INFO - 2018-01-24 08:00:46 --> Security Class Initialized
DEBUG - 2018-01-24 08:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-24 08:00:46 --> Input Class Initialized
INFO - 2018-01-24 08:00:46 --> Language Class Initialized
INFO - 2018-01-24 08:00:46 --> Loader Class Initialized
INFO - 2018-01-24 08:00:46 --> Helper loaded: url_helper
INFO - 2018-01-24 08:00:46 --> Helper loaded: form_helper
INFO - 2018-01-24 08:00:46 --> Database Driver Class Initialized
DEBUG - 2018-01-24 08:00:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-24 08:00:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-24 08:00:46 --> Form Validation Class Initialized
INFO - 2018-01-24 08:00:46 --> Model Class Initialized
INFO - 2018-01-24 08:00:46 --> Controller Class Initialized
INFO - 2018-01-24 08:00:46 --> Model Class Initialized
DEBUG - 2018-01-24 08:00:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-24 08:00:48 --> Config Class Initialized
INFO - 2018-01-24 08:00:48 --> Hooks Class Initialized
DEBUG - 2018-01-24 08:00:48 --> UTF-8 Support Enabled
INFO - 2018-01-24 08:00:48 --> Utf8 Class Initialized
INFO - 2018-01-24 08:00:48 --> URI Class Initialized
INFO - 2018-01-24 08:00:48 --> Router Class Initialized
INFO - 2018-01-24 08:00:48 --> Output Class Initialized
INFO - 2018-01-24 08:00:48 --> Security Class Initialized
DEBUG - 2018-01-24 08:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-24 08:00:48 --> Input Class Initialized
INFO - 2018-01-24 08:00:48 --> Language Class Initialized
INFO - 2018-01-24 08:00:48 --> Loader Class Initialized
INFO - 2018-01-24 08:00:48 --> Helper loaded: url_helper
INFO - 2018-01-24 08:00:48 --> Helper loaded: form_helper
INFO - 2018-01-24 08:00:48 --> Database Driver Class Initialized
DEBUG - 2018-01-24 08:00:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-24 08:00:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-24 08:00:48 --> Form Validation Class Initialized
INFO - 2018-01-24 08:00:48 --> Model Class Initialized
INFO - 2018-01-24 08:00:48 --> Controller Class Initialized
INFO - 2018-01-24 08:00:48 --> Model Class Initialized
DEBUG - 2018-01-24 08:00:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-01-24 08:00:50 --> Config Class Initialized
INFO - 2018-01-24 08:00:50 --> Hooks Class Initialized
DEBUG - 2018-01-24 08:00:50 --> UTF-8 Support Enabled
INFO - 2018-01-24 08:00:50 --> Utf8 Class Initialized
INFO - 2018-01-24 08:00:50 --> URI Class Initialized
INFO - 2018-01-24 08:00:50 --> Router Class Initialized
INFO - 2018-01-24 08:00:50 --> Output Class Initialized
INFO - 2018-01-24 08:00:50 --> Security Class Initialized
DEBUG - 2018-01-24 08:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-01-24 08:00:50 --> Input Class Initialized
INFO - 2018-01-24 08:00:50 --> Language Class Initialized
INFO - 2018-01-24 08:00:50 --> Loader Class Initialized
INFO - 2018-01-24 08:00:50 --> Helper loaded: url_helper
INFO - 2018-01-24 08:00:50 --> Helper loaded: form_helper
INFO - 2018-01-24 08:00:50 --> Database Driver Class Initialized
DEBUG - 2018-01-24 08:00:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-01-24 08:00:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-01-24 08:00:50 --> Form Validation Class Initialized
INFO - 2018-01-24 08:00:50 --> Model Class Initialized
INFO - 2018-01-24 08:00:50 --> Controller Class Initialized
INFO - 2018-01-24 08:00:50 --> Model Class Initialized
DEBUG - 2018-01-24 08:00:50 --> Form_validation class already loaded. Second attempt ignored.
