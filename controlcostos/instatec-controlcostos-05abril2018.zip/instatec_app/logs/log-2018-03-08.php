<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-03-08 00:00:59 --> Config Class Initialized
INFO - 2018-03-08 00:00:59 --> Hooks Class Initialized
DEBUG - 2018-03-08 00:00:59 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:00:59 --> Utf8 Class Initialized
INFO - 2018-03-08 00:00:59 --> URI Class Initialized
INFO - 2018-03-08 00:00:59 --> Router Class Initialized
INFO - 2018-03-08 00:00:59 --> Output Class Initialized
INFO - 2018-03-08 00:00:59 --> Security Class Initialized
DEBUG - 2018-03-08 00:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:00:59 --> Input Class Initialized
INFO - 2018-03-08 00:00:59 --> Language Class Initialized
INFO - 2018-03-08 00:00:59 --> Loader Class Initialized
INFO - 2018-03-08 00:00:59 --> Helper loaded: url_helper
INFO - 2018-03-08 00:00:59 --> Helper loaded: form_helper
INFO - 2018-03-08 00:00:59 --> Database Driver Class Initialized
DEBUG - 2018-03-08 00:00:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-08 00:00:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 00:00:59 --> Form Validation Class Initialized
INFO - 2018-03-08 00:00:59 --> Model Class Initialized
INFO - 2018-03-08 00:00:59 --> Controller Class Initialized
INFO - 2018-03-08 00:00:59 --> Model Class Initialized
INFO - 2018-03-08 00:00:59 --> Model Class Initialized
INFO - 2018-03-08 00:00:59 --> Model Class Initialized
INFO - 2018-03-08 00:00:59 --> Model Class Initialized
INFO - 2018-03-08 00:00:59 --> Model Class Initialized
DEBUG - 2018-03-08 00:00:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-08 00:00:59 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-08 00:00:59 --> Final output sent to browser
DEBUG - 2018-03-08 00:00:59 --> Total execution time: 0.0521
INFO - 2018-03-08 00:01:00 --> Config Class Initialized
INFO - 2018-03-08 00:01:00 --> Hooks Class Initialized
DEBUG - 2018-03-08 00:01:00 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:01:00 --> Utf8 Class Initialized
INFO - 2018-03-08 00:01:00 --> URI Class Initialized
INFO - 2018-03-08 00:01:00 --> Router Class Initialized
INFO - 2018-03-08 00:01:00 --> Output Class Initialized
INFO - 2018-03-08 00:01:00 --> Security Class Initialized
DEBUG - 2018-03-08 00:01:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:01:00 --> Input Class Initialized
INFO - 2018-03-08 00:01:00 --> Language Class Initialized
INFO - 2018-03-08 00:01:00 --> Loader Class Initialized
INFO - 2018-03-08 00:01:00 --> Helper loaded: url_helper
INFO - 2018-03-08 00:01:00 --> Helper loaded: form_helper
INFO - 2018-03-08 00:01:00 --> Database Driver Class Initialized
DEBUG - 2018-03-08 00:01:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-08 00:01:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 00:01:00 --> Form Validation Class Initialized
INFO - 2018-03-08 00:01:00 --> Model Class Initialized
INFO - 2018-03-08 00:01:00 --> Controller Class Initialized
INFO - 2018-03-08 00:01:00 --> Model Class Initialized
INFO - 2018-03-08 00:01:00 --> Model Class Initialized
INFO - 2018-03-08 00:01:00 --> Model Class Initialized
INFO - 2018-03-08 00:01:00 --> Model Class Initialized
INFO - 2018-03-08 00:01:00 --> Model Class Initialized
DEBUG - 2018-03-08 00:01:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-08 00:01:01 --> Config Class Initialized
INFO - 2018-03-08 00:01:01 --> Hooks Class Initialized
DEBUG - 2018-03-08 00:01:01 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:01:01 --> Utf8 Class Initialized
INFO - 2018-03-08 00:01:01 --> URI Class Initialized
INFO - 2018-03-08 00:01:01 --> Router Class Initialized
INFO - 2018-03-08 00:01:01 --> Output Class Initialized
INFO - 2018-03-08 00:01:01 --> Security Class Initialized
DEBUG - 2018-03-08 00:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:01:01 --> Input Class Initialized
INFO - 2018-03-08 00:01:01 --> Language Class Initialized
INFO - 2018-03-08 00:01:01 --> Loader Class Initialized
INFO - 2018-03-08 00:01:01 --> Helper loaded: url_helper
INFO - 2018-03-08 00:01:01 --> Helper loaded: form_helper
INFO - 2018-03-08 00:01:01 --> Database Driver Class Initialized
DEBUG - 2018-03-08 00:01:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-08 00:01:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 00:01:01 --> Form Validation Class Initialized
INFO - 2018-03-08 00:01:01 --> Model Class Initialized
INFO - 2018-03-08 00:01:01 --> Controller Class Initialized
INFO - 2018-03-08 00:01:01 --> Model Class Initialized
INFO - 2018-03-08 00:01:01 --> Model Class Initialized
INFO - 2018-03-08 00:01:01 --> Model Class Initialized
INFO - 2018-03-08 00:01:01 --> Model Class Initialized
INFO - 2018-03-08 00:01:01 --> Model Class Initialized
DEBUG - 2018-03-08 00:01:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-08 00:01:01 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-08 00:01:01 --> Final output sent to browser
DEBUG - 2018-03-08 00:01:01 --> Total execution time: 0.0816
INFO - 2018-03-08 00:01:01 --> Config Class Initialized
INFO - 2018-03-08 00:01:01 --> Hooks Class Initialized
DEBUG - 2018-03-08 00:01:01 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:01:01 --> Utf8 Class Initialized
INFO - 2018-03-08 00:01:01 --> URI Class Initialized
INFO - 2018-03-08 00:01:01 --> Router Class Initialized
INFO - 2018-03-08 00:01:01 --> Output Class Initialized
INFO - 2018-03-08 00:01:01 --> Security Class Initialized
DEBUG - 2018-03-08 00:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:01:01 --> Input Class Initialized
INFO - 2018-03-08 00:01:01 --> Language Class Initialized
INFO - 2018-03-08 00:01:01 --> Loader Class Initialized
INFO - 2018-03-08 00:01:01 --> Helper loaded: url_helper
INFO - 2018-03-08 00:01:01 --> Helper loaded: form_helper
INFO - 2018-03-08 00:01:01 --> Database Driver Class Initialized
DEBUG - 2018-03-08 00:01:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-08 00:01:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 00:01:01 --> Form Validation Class Initialized
INFO - 2018-03-08 00:01:01 --> Model Class Initialized
INFO - 2018-03-08 00:01:01 --> Controller Class Initialized
INFO - 2018-03-08 00:01:01 --> Model Class Initialized
INFO - 2018-03-08 00:01:01 --> Model Class Initialized
INFO - 2018-03-08 00:01:01 --> Model Class Initialized
INFO - 2018-03-08 00:01:01 --> Model Class Initialized
INFO - 2018-03-08 00:01:01 --> Model Class Initialized
DEBUG - 2018-03-08 00:01:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-08 00:01:01 --> Config Class Initialized
INFO - 2018-03-08 00:01:01 --> Hooks Class Initialized
DEBUG - 2018-03-08 00:01:01 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:01:01 --> Utf8 Class Initialized
INFO - 2018-03-08 00:01:01 --> URI Class Initialized
INFO - 2018-03-08 00:01:01 --> Router Class Initialized
INFO - 2018-03-08 00:01:01 --> Output Class Initialized
INFO - 2018-03-08 00:01:01 --> Security Class Initialized
DEBUG - 2018-03-08 00:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:01:01 --> Input Class Initialized
INFO - 2018-03-08 00:01:01 --> Language Class Initialized
INFO - 2018-03-08 00:01:01 --> Loader Class Initialized
INFO - 2018-03-08 00:01:01 --> Helper loaded: url_helper
INFO - 2018-03-08 00:01:01 --> Helper loaded: form_helper
INFO - 2018-03-08 00:01:01 --> Database Driver Class Initialized
DEBUG - 2018-03-08 00:01:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-08 00:01:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 00:01:01 --> Form Validation Class Initialized
INFO - 2018-03-08 00:01:01 --> Model Class Initialized
INFO - 2018-03-08 00:01:01 --> Controller Class Initialized
INFO - 2018-03-08 00:01:01 --> Model Class Initialized
INFO - 2018-03-08 00:01:01 --> Model Class Initialized
INFO - 2018-03-08 00:01:01 --> Model Class Initialized
INFO - 2018-03-08 00:01:01 --> Model Class Initialized
INFO - 2018-03-08 00:01:01 --> Model Class Initialized
DEBUG - 2018-03-08 00:01:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-08 00:01:01 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-08 00:01:01 --> Final output sent to browser
DEBUG - 2018-03-08 00:01:01 --> Total execution time: 0.0796
INFO - 2018-03-08 00:01:01 --> Config Class Initialized
INFO - 2018-03-08 00:01:01 --> Hooks Class Initialized
DEBUG - 2018-03-08 00:01:01 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:01:01 --> Utf8 Class Initialized
INFO - 2018-03-08 00:01:01 --> URI Class Initialized
INFO - 2018-03-08 00:01:01 --> Router Class Initialized
INFO - 2018-03-08 00:01:01 --> Output Class Initialized
INFO - 2018-03-08 00:01:01 --> Security Class Initialized
DEBUG - 2018-03-08 00:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:01:01 --> Input Class Initialized
INFO - 2018-03-08 00:01:01 --> Language Class Initialized
INFO - 2018-03-08 00:01:01 --> Loader Class Initialized
INFO - 2018-03-08 00:01:01 --> Helper loaded: url_helper
INFO - 2018-03-08 00:01:01 --> Helper loaded: form_helper
INFO - 2018-03-08 00:01:01 --> Database Driver Class Initialized
DEBUG - 2018-03-08 00:01:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-08 00:01:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 00:01:01 --> Form Validation Class Initialized
INFO - 2018-03-08 00:01:01 --> Model Class Initialized
INFO - 2018-03-08 00:01:01 --> Controller Class Initialized
INFO - 2018-03-08 00:01:01 --> Model Class Initialized
INFO - 2018-03-08 00:01:01 --> Model Class Initialized
INFO - 2018-03-08 00:01:01 --> Model Class Initialized
INFO - 2018-03-08 00:01:01 --> Model Class Initialized
INFO - 2018-03-08 00:01:01 --> Model Class Initialized
DEBUG - 2018-03-08 00:01:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-08 00:01:04 --> Config Class Initialized
INFO - 2018-03-08 00:01:04 --> Hooks Class Initialized
INFO - 2018-03-08 00:01:04 --> Config Class Initialized
INFO - 2018-03-08 00:01:05 --> Hooks Class Initialized
DEBUG - 2018-03-08 00:01:05 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:01:05 --> Utf8 Class Initialized
INFO - 2018-03-08 00:01:05 --> URI Class Initialized
DEBUG - 2018-03-08 00:01:05 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:01:05 --> Utf8 Class Initialized
INFO - 2018-03-08 00:01:05 --> Router Class Initialized
INFO - 2018-03-08 00:01:05 --> URI Class Initialized
INFO - 2018-03-08 00:01:05 --> Output Class Initialized
INFO - 2018-03-08 00:01:05 --> Security Class Initialized
INFO - 2018-03-08 00:01:05 --> Router Class Initialized
DEBUG - 2018-03-08 00:01:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:01:05 --> Input Class Initialized
INFO - 2018-03-08 00:01:05 --> Output Class Initialized
INFO - 2018-03-08 00:01:05 --> Language Class Initialized
INFO - 2018-03-08 00:01:05 --> Security Class Initialized
ERROR - 2018-03-08 00:01:05 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-03-08 00:01:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:01:05 --> Input Class Initialized
INFO - 2018-03-08 00:01:05 --> Language Class Initialized
ERROR - 2018-03-08 00:01:05 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-08 00:01:05 --> Config Class Initialized
INFO - 2018-03-08 00:01:05 --> Hooks Class Initialized
DEBUG - 2018-03-08 00:01:05 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:01:05 --> Utf8 Class Initialized
INFO - 2018-03-08 00:01:05 --> URI Class Initialized
INFO - 2018-03-08 00:01:05 --> Router Class Initialized
INFO - 2018-03-08 00:01:05 --> Output Class Initialized
INFO - 2018-03-08 00:01:05 --> Security Class Initialized
DEBUG - 2018-03-08 00:01:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:01:05 --> Input Class Initialized
INFO - 2018-03-08 00:01:05 --> Language Class Initialized
ERROR - 2018-03-08 00:01:05 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-08 00:01:49 --> Config Class Initialized
INFO - 2018-03-08 00:01:49 --> Hooks Class Initialized
DEBUG - 2018-03-08 00:01:49 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:01:49 --> Utf8 Class Initialized
INFO - 2018-03-08 00:01:49 --> URI Class Initialized
INFO - 2018-03-08 00:01:49 --> Router Class Initialized
INFO - 2018-03-08 00:01:49 --> Output Class Initialized
INFO - 2018-03-08 00:01:49 --> Security Class Initialized
DEBUG - 2018-03-08 00:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:01:49 --> Input Class Initialized
INFO - 2018-03-08 00:01:49 --> Language Class Initialized
INFO - 2018-03-08 00:01:49 --> Loader Class Initialized
INFO - 2018-03-08 00:01:49 --> Helper loaded: url_helper
INFO - 2018-03-08 00:01:49 --> Helper loaded: form_helper
INFO - 2018-03-08 00:01:49 --> Database Driver Class Initialized
DEBUG - 2018-03-08 00:01:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-08 00:01:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 00:01:49 --> Form Validation Class Initialized
INFO - 2018-03-08 00:01:49 --> Model Class Initialized
INFO - 2018-03-08 00:01:49 --> Controller Class Initialized
INFO - 2018-03-08 00:01:49 --> Model Class Initialized
INFO - 2018-03-08 00:01:49 --> Model Class Initialized
INFO - 2018-03-08 00:01:49 --> Model Class Initialized
INFO - 2018-03-08 00:01:49 --> Model Class Initialized
INFO - 2018-03-08 00:01:49 --> Model Class Initialized
DEBUG - 2018-03-08 00:01:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-08 00:01:49 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-08 00:01:49 --> Final output sent to browser
DEBUG - 2018-03-08 00:01:49 --> Total execution time: 0.0873
INFO - 2018-03-08 00:01:49 --> Config Class Initialized
INFO - 2018-03-08 00:01:49 --> Hooks Class Initialized
INFO - 2018-03-08 00:01:49 --> Config Class Initialized
INFO - 2018-03-08 00:01:49 --> Hooks Class Initialized
INFO - 2018-03-08 00:01:49 --> Config Class Initialized
INFO - 2018-03-08 00:01:49 --> Hooks Class Initialized
DEBUG - 2018-03-08 00:01:49 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:01:49 --> Utf8 Class Initialized
DEBUG - 2018-03-08 00:01:49 --> UTF-8 Support Enabled
DEBUG - 2018-03-08 00:01:49 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:01:49 --> Utf8 Class Initialized
INFO - 2018-03-08 00:01:49 --> Utf8 Class Initialized
INFO - 2018-03-08 00:01:49 --> URI Class Initialized
INFO - 2018-03-08 00:01:49 --> URI Class Initialized
INFO - 2018-03-08 00:01:49 --> URI Class Initialized
INFO - 2018-03-08 00:01:49 --> Router Class Initialized
INFO - 2018-03-08 00:01:49 --> Router Class Initialized
INFO - 2018-03-08 00:01:49 --> Router Class Initialized
INFO - 2018-03-08 00:01:49 --> Output Class Initialized
INFO - 2018-03-08 00:01:49 --> Output Class Initialized
INFO - 2018-03-08 00:01:49 --> Output Class Initialized
INFO - 2018-03-08 00:01:49 --> Config Class Initialized
INFO - 2018-03-08 00:01:49 --> Hooks Class Initialized
INFO - 2018-03-08 00:01:49 --> Security Class Initialized
INFO - 2018-03-08 00:01:49 --> Security Class Initialized
INFO - 2018-03-08 00:01:49 --> Security Class Initialized
DEBUG - 2018-03-08 00:01:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-08 00:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:01:49 --> Input Class Initialized
INFO - 2018-03-08 00:01:49 --> Input Class Initialized
DEBUG - 2018-03-08 00:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:01:49 --> Language Class Initialized
INFO - 2018-03-08 00:01:49 --> Input Class Initialized
INFO - 2018-03-08 00:01:49 --> Language Class Initialized
DEBUG - 2018-03-08 00:01:49 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:01:49 --> Utf8 Class Initialized
INFO - 2018-03-08 00:01:49 --> Language Class Initialized
ERROR - 2018-03-08 00:01:49 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-08 00:01:49 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-08 00:01:49 --> URI Class Initialized
ERROR - 2018-03-08 00:01:49 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-08 00:01:49 --> Router Class Initialized
INFO - 2018-03-08 00:01:49 --> Output Class Initialized
INFO - 2018-03-08 00:01:49 --> Security Class Initialized
DEBUG - 2018-03-08 00:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:01:49 --> Input Class Initialized
INFO - 2018-03-08 00:01:49 --> Language Class Initialized
ERROR - 2018-03-08 00:01:49 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-08 00:01:49 --> Config Class Initialized
INFO - 2018-03-08 00:01:49 --> Hooks Class Initialized
INFO - 2018-03-08 00:01:49 --> Config Class Initialized
INFO - 2018-03-08 00:01:49 --> Hooks Class Initialized
INFO - 2018-03-08 00:01:49 --> Config Class Initialized
INFO - 2018-03-08 00:01:49 --> Hooks Class Initialized
DEBUG - 2018-03-08 00:01:49 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:01:49 --> Utf8 Class Initialized
INFO - 2018-03-08 00:01:49 --> URI Class Initialized
DEBUG - 2018-03-08 00:01:49 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:01:49 --> Utf8 Class Initialized
DEBUG - 2018-03-08 00:01:49 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:01:49 --> Utf8 Class Initialized
INFO - 2018-03-08 00:01:49 --> Router Class Initialized
INFO - 2018-03-08 00:01:49 --> URI Class Initialized
INFO - 2018-03-08 00:01:49 --> URI Class Initialized
INFO - 2018-03-08 00:01:49 --> Router Class Initialized
INFO - 2018-03-08 00:01:49 --> Output Class Initialized
INFO - 2018-03-08 00:01:49 --> Router Class Initialized
INFO - 2018-03-08 00:01:49 --> Security Class Initialized
INFO - 2018-03-08 00:01:49 --> Output Class Initialized
INFO - 2018-03-08 00:01:49 --> Output Class Initialized
DEBUG - 2018-03-08 00:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:01:49 --> Input Class Initialized
INFO - 2018-03-08 00:01:49 --> Security Class Initialized
INFO - 2018-03-08 00:01:49 --> Security Class Initialized
INFO - 2018-03-08 00:01:49 --> Language Class Initialized
DEBUG - 2018-03-08 00:01:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-08 00:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:01:49 --> Input Class Initialized
INFO - 2018-03-08 00:01:49 --> Input Class Initialized
ERROR - 2018-03-08 00:01:49 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-08 00:01:49 --> Language Class Initialized
INFO - 2018-03-08 00:01:49 --> Language Class Initialized
ERROR - 2018-03-08 00:01:49 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-08 00:01:49 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-08 00:01:49 --> Config Class Initialized
INFO - 2018-03-08 00:01:49 --> Hooks Class Initialized
DEBUG - 2018-03-08 00:01:49 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:01:49 --> Utf8 Class Initialized
INFO - 2018-03-08 00:01:49 --> URI Class Initialized
INFO - 2018-03-08 00:01:49 --> Router Class Initialized
INFO - 2018-03-08 00:01:49 --> Output Class Initialized
INFO - 2018-03-08 00:01:49 --> Security Class Initialized
DEBUG - 2018-03-08 00:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:01:49 --> Input Class Initialized
INFO - 2018-03-08 00:01:49 --> Language Class Initialized
INFO - 2018-03-08 00:01:49 --> Loader Class Initialized
INFO - 2018-03-08 00:01:49 --> Helper loaded: url_helper
INFO - 2018-03-08 00:01:49 --> Helper loaded: form_helper
INFO - 2018-03-08 00:01:49 --> Database Driver Class Initialized
DEBUG - 2018-03-08 00:01:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-08 00:01:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 00:01:49 --> Form Validation Class Initialized
INFO - 2018-03-08 00:01:49 --> Model Class Initialized
INFO - 2018-03-08 00:01:49 --> Controller Class Initialized
INFO - 2018-03-08 00:01:49 --> Model Class Initialized
INFO - 2018-03-08 00:01:49 --> Model Class Initialized
INFO - 2018-03-08 00:01:49 --> Model Class Initialized
INFO - 2018-03-08 00:01:49 --> Model Class Initialized
INFO - 2018-03-08 00:01:49 --> Model Class Initialized
DEBUG - 2018-03-08 00:01:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-08 00:03:11 --> Config Class Initialized
INFO - 2018-03-08 00:03:11 --> Hooks Class Initialized
DEBUG - 2018-03-08 00:03:11 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:03:11 --> Utf8 Class Initialized
INFO - 2018-03-08 00:03:11 --> URI Class Initialized
INFO - 2018-03-08 00:03:11 --> Router Class Initialized
INFO - 2018-03-08 00:03:11 --> Output Class Initialized
INFO - 2018-03-08 00:03:11 --> Security Class Initialized
DEBUG - 2018-03-08 00:03:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:03:11 --> Input Class Initialized
INFO - 2018-03-08 00:03:11 --> Language Class Initialized
INFO - 2018-03-08 00:03:11 --> Loader Class Initialized
INFO - 2018-03-08 00:03:11 --> Helper loaded: url_helper
INFO - 2018-03-08 00:03:11 --> Helper loaded: form_helper
INFO - 2018-03-08 00:03:11 --> Database Driver Class Initialized
DEBUG - 2018-03-08 00:03:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-08 00:03:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 00:03:11 --> Form Validation Class Initialized
INFO - 2018-03-08 00:03:11 --> Model Class Initialized
INFO - 2018-03-08 00:03:11 --> Controller Class Initialized
INFO - 2018-03-08 00:03:11 --> Model Class Initialized
INFO - 2018-03-08 00:03:11 --> Model Class Initialized
INFO - 2018-03-08 00:03:11 --> Model Class Initialized
INFO - 2018-03-08 00:03:11 --> Model Class Initialized
INFO - 2018-03-08 00:03:11 --> Model Class Initialized
DEBUG - 2018-03-08 00:03:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-08 00:03:11 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-08 00:03:11 --> Final output sent to browser
DEBUG - 2018-03-08 00:03:11 --> Total execution time: 0.0597
INFO - 2018-03-08 00:03:11 --> Config Class Initialized
INFO - 2018-03-08 00:03:11 --> Hooks Class Initialized
INFO - 2018-03-08 00:03:11 --> Config Class Initialized
INFO - 2018-03-08 00:03:11 --> Hooks Class Initialized
INFO - 2018-03-08 00:03:11 --> Config Class Initialized
INFO - 2018-03-08 00:03:11 --> Hooks Class Initialized
DEBUG - 2018-03-08 00:03:11 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:03:11 --> Config Class Initialized
DEBUG - 2018-03-08 00:03:11 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:03:11 --> Utf8 Class Initialized
DEBUG - 2018-03-08 00:03:11 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:03:11 --> Hooks Class Initialized
INFO - 2018-03-08 00:03:11 --> Utf8 Class Initialized
INFO - 2018-03-08 00:03:11 --> Utf8 Class Initialized
INFO - 2018-03-08 00:03:11 --> URI Class Initialized
INFO - 2018-03-08 00:03:11 --> URI Class Initialized
INFO - 2018-03-08 00:03:11 --> URI Class Initialized
INFO - 2018-03-08 00:03:11 --> Router Class Initialized
DEBUG - 2018-03-08 00:03:11 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:03:11 --> Utf8 Class Initialized
INFO - 2018-03-08 00:03:11 --> Router Class Initialized
INFO - 2018-03-08 00:03:11 --> Router Class Initialized
INFO - 2018-03-08 00:03:11 --> URI Class Initialized
INFO - 2018-03-08 00:03:11 --> Output Class Initialized
INFO - 2018-03-08 00:03:11 --> Output Class Initialized
INFO - 2018-03-08 00:03:11 --> Security Class Initialized
INFO - 2018-03-08 00:03:11 --> Router Class Initialized
INFO - 2018-03-08 00:03:11 --> Output Class Initialized
INFO - 2018-03-08 00:03:11 --> Security Class Initialized
DEBUG - 2018-03-08 00:03:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:03:11 --> Input Class Initialized
INFO - 2018-03-08 00:03:11 --> Security Class Initialized
DEBUG - 2018-03-08 00:03:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:03:11 --> Output Class Initialized
INFO - 2018-03-08 00:03:11 --> Input Class Initialized
INFO - 2018-03-08 00:03:11 --> Language Class Initialized
DEBUG - 2018-03-08 00:03:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:03:11 --> Language Class Initialized
INFO - 2018-03-08 00:03:11 --> Security Class Initialized
INFO - 2018-03-08 00:03:11 --> Input Class Initialized
ERROR - 2018-03-08 00:03:11 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-08 00:03:11 --> Language Class Initialized
DEBUG - 2018-03-08 00:03:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-03-08 00:03:11 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-08 00:03:11 --> Input Class Initialized
INFO - 2018-03-08 00:03:11 --> Language Class Initialized
ERROR - 2018-03-08 00:03:11 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-08 00:03:11 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-08 00:03:11 --> Config Class Initialized
INFO - 2018-03-08 00:03:11 --> Hooks Class Initialized
INFO - 2018-03-08 00:03:11 --> Config Class Initialized
INFO - 2018-03-08 00:03:11 --> Hooks Class Initialized
INFO - 2018-03-08 00:03:11 --> Config Class Initialized
INFO - 2018-03-08 00:03:11 --> Hooks Class Initialized
DEBUG - 2018-03-08 00:03:11 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:03:11 --> Utf8 Class Initialized
INFO - 2018-03-08 00:03:11 --> URI Class Initialized
DEBUG - 2018-03-08 00:03:11 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:03:11 --> Utf8 Class Initialized
DEBUG - 2018-03-08 00:03:11 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:03:11 --> Utf8 Class Initialized
INFO - 2018-03-08 00:03:11 --> Router Class Initialized
INFO - 2018-03-08 00:03:11 --> URI Class Initialized
INFO - 2018-03-08 00:03:11 --> URI Class Initialized
INFO - 2018-03-08 00:03:11 --> Router Class Initialized
INFO - 2018-03-08 00:03:11 --> Router Class Initialized
INFO - 2018-03-08 00:03:11 --> Output Class Initialized
INFO - 2018-03-08 00:03:11 --> Security Class Initialized
INFO - 2018-03-08 00:03:11 --> Output Class Initialized
INFO - 2018-03-08 00:03:11 --> Output Class Initialized
DEBUG - 2018-03-08 00:03:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:03:11 --> Security Class Initialized
INFO - 2018-03-08 00:03:11 --> Security Class Initialized
INFO - 2018-03-08 00:03:11 --> Input Class Initialized
INFO - 2018-03-08 00:03:11 --> Language Class Initialized
DEBUG - 2018-03-08 00:03:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:03:11 --> Input Class Initialized
DEBUG - 2018-03-08 00:03:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:03:11 --> Input Class Initialized
ERROR - 2018-03-08 00:03:11 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-08 00:03:11 --> Language Class Initialized
INFO - 2018-03-08 00:03:11 --> Language Class Initialized
ERROR - 2018-03-08 00:03:11 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-08 00:03:11 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-08 00:03:11 --> Config Class Initialized
INFO - 2018-03-08 00:03:11 --> Hooks Class Initialized
DEBUG - 2018-03-08 00:03:11 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:03:11 --> Utf8 Class Initialized
INFO - 2018-03-08 00:03:11 --> URI Class Initialized
INFO - 2018-03-08 00:03:11 --> Router Class Initialized
INFO - 2018-03-08 00:03:11 --> Output Class Initialized
INFO - 2018-03-08 00:03:11 --> Security Class Initialized
DEBUG - 2018-03-08 00:03:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:03:11 --> Input Class Initialized
INFO - 2018-03-08 00:03:11 --> Language Class Initialized
INFO - 2018-03-08 00:03:11 --> Loader Class Initialized
INFO - 2018-03-08 00:03:11 --> Helper loaded: url_helper
INFO - 2018-03-08 00:03:11 --> Helper loaded: form_helper
INFO - 2018-03-08 00:03:11 --> Database Driver Class Initialized
DEBUG - 2018-03-08 00:03:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-08 00:03:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 00:03:11 --> Form Validation Class Initialized
INFO - 2018-03-08 00:03:11 --> Model Class Initialized
INFO - 2018-03-08 00:03:11 --> Controller Class Initialized
INFO - 2018-03-08 00:03:11 --> Model Class Initialized
INFO - 2018-03-08 00:03:11 --> Model Class Initialized
INFO - 2018-03-08 00:03:11 --> Model Class Initialized
INFO - 2018-03-08 00:03:11 --> Model Class Initialized
INFO - 2018-03-08 00:03:11 --> Model Class Initialized
DEBUG - 2018-03-08 00:03:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-08 00:07:13 --> Config Class Initialized
INFO - 2018-03-08 00:07:13 --> Hooks Class Initialized
DEBUG - 2018-03-08 00:07:13 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:07:13 --> Utf8 Class Initialized
INFO - 2018-03-08 00:07:13 --> URI Class Initialized
INFO - 2018-03-08 00:07:13 --> Router Class Initialized
INFO - 2018-03-08 00:07:13 --> Output Class Initialized
INFO - 2018-03-08 00:07:13 --> Security Class Initialized
DEBUG - 2018-03-08 00:07:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:07:13 --> Input Class Initialized
INFO - 2018-03-08 00:07:13 --> Language Class Initialized
INFO - 2018-03-08 00:07:13 --> Loader Class Initialized
INFO - 2018-03-08 00:07:13 --> Helper loaded: url_helper
INFO - 2018-03-08 00:07:13 --> Helper loaded: form_helper
INFO - 2018-03-08 00:07:13 --> Database Driver Class Initialized
DEBUG - 2018-03-08 00:07:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-08 00:07:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 00:07:13 --> Form Validation Class Initialized
INFO - 2018-03-08 00:07:13 --> Model Class Initialized
INFO - 2018-03-08 00:07:13 --> Controller Class Initialized
INFO - 2018-03-08 00:07:13 --> Model Class Initialized
INFO - 2018-03-08 00:07:13 --> Model Class Initialized
INFO - 2018-03-08 00:07:13 --> Model Class Initialized
INFO - 2018-03-08 00:07:13 --> Model Class Initialized
INFO - 2018-03-08 00:07:13 --> Model Class Initialized
DEBUG - 2018-03-08 00:07:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-08 00:07:13 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-08 00:07:13 --> Final output sent to browser
DEBUG - 2018-03-08 00:07:13 --> Total execution time: 0.0697
INFO - 2018-03-08 00:07:13 --> Config Class Initialized
INFO - 2018-03-08 00:07:13 --> Hooks Class Initialized
INFO - 2018-03-08 00:07:13 --> Config Class Initialized
INFO - 2018-03-08 00:07:13 --> Hooks Class Initialized
INFO - 2018-03-08 00:07:13 --> Config Class Initialized
INFO - 2018-03-08 00:07:13 --> Hooks Class Initialized
DEBUG - 2018-03-08 00:07:13 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:07:13 --> Utf8 Class Initialized
DEBUG - 2018-03-08 00:07:13 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:07:13 --> Utf8 Class Initialized
DEBUG - 2018-03-08 00:07:13 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:07:13 --> Utf8 Class Initialized
INFO - 2018-03-08 00:07:13 --> URI Class Initialized
INFO - 2018-03-08 00:07:13 --> URI Class Initialized
INFO - 2018-03-08 00:07:13 --> Config Class Initialized
INFO - 2018-03-08 00:07:13 --> Hooks Class Initialized
INFO - 2018-03-08 00:07:13 --> URI Class Initialized
INFO - 2018-03-08 00:07:13 --> Router Class Initialized
INFO - 2018-03-08 00:07:13 --> Router Class Initialized
INFO - 2018-03-08 00:07:13 --> Router Class Initialized
DEBUG - 2018-03-08 00:07:13 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:07:13 --> Utf8 Class Initialized
INFO - 2018-03-08 00:07:13 --> Output Class Initialized
INFO - 2018-03-08 00:07:13 --> Output Class Initialized
INFO - 2018-03-08 00:07:13 --> Output Class Initialized
INFO - 2018-03-08 00:07:13 --> URI Class Initialized
INFO - 2018-03-08 00:07:13 --> Security Class Initialized
INFO - 2018-03-08 00:07:13 --> Security Class Initialized
INFO - 2018-03-08 00:07:13 --> Security Class Initialized
DEBUG - 2018-03-08 00:07:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:07:13 --> Router Class Initialized
DEBUG - 2018-03-08 00:07:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:07:13 --> Input Class Initialized
INFO - 2018-03-08 00:07:13 --> Input Class Initialized
DEBUG - 2018-03-08 00:07:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:07:13 --> Input Class Initialized
INFO - 2018-03-08 00:07:13 --> Language Class Initialized
INFO - 2018-03-08 00:07:13 --> Language Class Initialized
INFO - 2018-03-08 00:07:13 --> Language Class Initialized
INFO - 2018-03-08 00:07:13 --> Output Class Initialized
ERROR - 2018-03-08 00:07:13 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-08 00:07:13 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-08 00:07:13 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-08 00:07:13 --> Security Class Initialized
DEBUG - 2018-03-08 00:07:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:07:13 --> Input Class Initialized
INFO - 2018-03-08 00:07:13 --> Language Class Initialized
ERROR - 2018-03-08 00:07:13 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-08 00:07:13 --> Config Class Initialized
INFO - 2018-03-08 00:07:13 --> Hooks Class Initialized
INFO - 2018-03-08 00:07:13 --> Config Class Initialized
INFO - 2018-03-08 00:07:13 --> Hooks Class Initialized
DEBUG - 2018-03-08 00:07:13 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:07:13 --> Config Class Initialized
INFO - 2018-03-08 00:07:13 --> Hooks Class Initialized
DEBUG - 2018-03-08 00:07:13 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:07:13 --> Utf8 Class Initialized
INFO - 2018-03-08 00:07:13 --> Utf8 Class Initialized
INFO - 2018-03-08 00:07:13 --> URI Class Initialized
INFO - 2018-03-08 00:07:13 --> URI Class Initialized
DEBUG - 2018-03-08 00:07:13 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:07:13 --> Utf8 Class Initialized
INFO - 2018-03-08 00:07:13 --> Router Class Initialized
INFO - 2018-03-08 00:07:13 --> Router Class Initialized
INFO - 2018-03-08 00:07:13 --> URI Class Initialized
INFO - 2018-03-08 00:07:13 --> Output Class Initialized
INFO - 2018-03-08 00:07:13 --> Router Class Initialized
INFO - 2018-03-08 00:07:13 --> Output Class Initialized
INFO - 2018-03-08 00:07:13 --> Security Class Initialized
INFO - 2018-03-08 00:07:13 --> Output Class Initialized
INFO - 2018-03-08 00:07:13 --> Security Class Initialized
INFO - 2018-03-08 00:07:13 --> Security Class Initialized
DEBUG - 2018-03-08 00:07:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-08 00:07:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:07:13 --> Input Class Initialized
INFO - 2018-03-08 00:07:13 --> Input Class Initialized
DEBUG - 2018-03-08 00:07:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:07:13 --> Language Class Initialized
INFO - 2018-03-08 00:07:13 --> Language Class Initialized
INFO - 2018-03-08 00:07:13 --> Input Class Initialized
INFO - 2018-03-08 00:07:13 --> Language Class Initialized
ERROR - 2018-03-08 00:07:13 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-08 00:07:13 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-08 00:07:13 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-08 00:07:13 --> Config Class Initialized
INFO - 2018-03-08 00:07:13 --> Hooks Class Initialized
DEBUG - 2018-03-08 00:07:13 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:07:13 --> Utf8 Class Initialized
INFO - 2018-03-08 00:07:13 --> URI Class Initialized
INFO - 2018-03-08 00:07:13 --> Router Class Initialized
INFO - 2018-03-08 00:07:13 --> Output Class Initialized
INFO - 2018-03-08 00:07:13 --> Security Class Initialized
DEBUG - 2018-03-08 00:07:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:07:13 --> Input Class Initialized
INFO - 2018-03-08 00:07:13 --> Language Class Initialized
INFO - 2018-03-08 00:07:13 --> Loader Class Initialized
INFO - 2018-03-08 00:07:13 --> Helper loaded: url_helper
INFO - 2018-03-08 00:07:13 --> Helper loaded: form_helper
INFO - 2018-03-08 00:07:13 --> Database Driver Class Initialized
DEBUG - 2018-03-08 00:07:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-08 00:07:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 00:07:13 --> Form Validation Class Initialized
INFO - 2018-03-08 00:07:13 --> Model Class Initialized
INFO - 2018-03-08 00:07:13 --> Controller Class Initialized
INFO - 2018-03-08 00:07:13 --> Model Class Initialized
INFO - 2018-03-08 00:07:13 --> Model Class Initialized
INFO - 2018-03-08 00:07:13 --> Model Class Initialized
INFO - 2018-03-08 00:07:13 --> Model Class Initialized
INFO - 2018-03-08 00:07:13 --> Model Class Initialized
DEBUG - 2018-03-08 00:07:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-08 00:13:26 --> Config Class Initialized
INFO - 2018-03-08 00:13:26 --> Hooks Class Initialized
DEBUG - 2018-03-08 00:13:26 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:13:26 --> Utf8 Class Initialized
INFO - 2018-03-08 00:13:26 --> URI Class Initialized
INFO - 2018-03-08 00:13:26 --> Router Class Initialized
INFO - 2018-03-08 00:13:26 --> Output Class Initialized
INFO - 2018-03-08 00:13:26 --> Security Class Initialized
DEBUG - 2018-03-08 00:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:13:26 --> Input Class Initialized
INFO - 2018-03-08 00:13:26 --> Language Class Initialized
INFO - 2018-03-08 00:13:26 --> Loader Class Initialized
INFO - 2018-03-08 00:13:26 --> Helper loaded: url_helper
INFO - 2018-03-08 00:13:26 --> Helper loaded: form_helper
INFO - 2018-03-08 00:13:26 --> Database Driver Class Initialized
DEBUG - 2018-03-08 00:13:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-08 00:13:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 00:13:26 --> Form Validation Class Initialized
INFO - 2018-03-08 00:13:26 --> Model Class Initialized
INFO - 2018-03-08 00:13:26 --> Controller Class Initialized
INFO - 2018-03-08 00:13:26 --> Model Class Initialized
INFO - 2018-03-08 00:13:26 --> Model Class Initialized
INFO - 2018-03-08 00:13:26 --> Model Class Initialized
INFO - 2018-03-08 00:13:26 --> Model Class Initialized
INFO - 2018-03-08 00:13:26 --> Model Class Initialized
DEBUG - 2018-03-08 00:13:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-08 00:13:26 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-08 00:13:26 --> Final output sent to browser
DEBUG - 2018-03-08 00:13:26 --> Total execution time: 0.0648
INFO - 2018-03-08 00:13:27 --> Config Class Initialized
INFO - 2018-03-08 00:13:27 --> Hooks Class Initialized
INFO - 2018-03-08 00:13:27 --> Config Class Initialized
INFO - 2018-03-08 00:13:27 --> Hooks Class Initialized
INFO - 2018-03-08 00:13:27 --> Config Class Initialized
INFO - 2018-03-08 00:13:27 --> Hooks Class Initialized
INFO - 2018-03-08 00:13:27 --> Config Class Initialized
INFO - 2018-03-08 00:13:27 --> Hooks Class Initialized
DEBUG - 2018-03-08 00:13:27 --> UTF-8 Support Enabled
DEBUG - 2018-03-08 00:13:27 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:13:27 --> Utf8 Class Initialized
INFO - 2018-03-08 00:13:27 --> Utf8 Class Initialized
DEBUG - 2018-03-08 00:13:27 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:13:27 --> Utf8 Class Initialized
INFO - 2018-03-08 00:13:27 --> URI Class Initialized
INFO - 2018-03-08 00:13:27 --> URI Class Initialized
INFO - 2018-03-08 00:13:27 --> URI Class Initialized
DEBUG - 2018-03-08 00:13:27 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:13:27 --> Utf8 Class Initialized
INFO - 2018-03-08 00:13:27 --> Router Class Initialized
INFO - 2018-03-08 00:13:27 --> Router Class Initialized
INFO - 2018-03-08 00:13:27 --> URI Class Initialized
INFO - 2018-03-08 00:13:27 --> Router Class Initialized
INFO - 2018-03-08 00:13:27 --> Output Class Initialized
INFO - 2018-03-08 00:13:27 --> Output Class Initialized
INFO - 2018-03-08 00:13:27 --> Router Class Initialized
INFO - 2018-03-08 00:13:27 --> Output Class Initialized
INFO - 2018-03-08 00:13:27 --> Security Class Initialized
INFO - 2018-03-08 00:13:27 --> Security Class Initialized
INFO - 2018-03-08 00:13:27 --> Security Class Initialized
INFO - 2018-03-08 00:13:27 --> Output Class Initialized
DEBUG - 2018-03-08 00:13:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:13:27 --> Input Class Initialized
DEBUG - 2018-03-08 00:13:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-08 00:13:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:13:27 --> Input Class Initialized
INFO - 2018-03-08 00:13:27 --> Language Class Initialized
INFO - 2018-03-08 00:13:27 --> Input Class Initialized
INFO - 2018-03-08 00:13:27 --> Security Class Initialized
INFO - 2018-03-08 00:13:27 --> Language Class Initialized
INFO - 2018-03-08 00:13:27 --> Language Class Initialized
ERROR - 2018-03-08 00:13:27 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-08 00:13:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-03-08 00:13:27 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-08 00:13:27 --> Input Class Initialized
ERROR - 2018-03-08 00:13:27 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-08 00:13:27 --> Language Class Initialized
ERROR - 2018-03-08 00:13:27 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-08 00:13:27 --> Config Class Initialized
INFO - 2018-03-08 00:13:27 --> Hooks Class Initialized
INFO - 2018-03-08 00:13:27 --> Config Class Initialized
INFO - 2018-03-08 00:13:27 --> Hooks Class Initialized
INFO - 2018-03-08 00:13:27 --> Config Class Initialized
INFO - 2018-03-08 00:13:27 --> Hooks Class Initialized
DEBUG - 2018-03-08 00:13:27 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:13:27 --> Utf8 Class Initialized
INFO - 2018-03-08 00:13:27 --> URI Class Initialized
DEBUG - 2018-03-08 00:13:27 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:13:27 --> Utf8 Class Initialized
DEBUG - 2018-03-08 00:13:27 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:13:27 --> Utf8 Class Initialized
INFO - 2018-03-08 00:13:27 --> URI Class Initialized
INFO - 2018-03-08 00:13:27 --> Router Class Initialized
INFO - 2018-03-08 00:13:27 --> URI Class Initialized
INFO - 2018-03-08 00:13:27 --> Router Class Initialized
INFO - 2018-03-08 00:13:27 --> Output Class Initialized
INFO - 2018-03-08 00:13:27 --> Router Class Initialized
INFO - 2018-03-08 00:13:27 --> Output Class Initialized
INFO - 2018-03-08 00:13:27 --> Security Class Initialized
INFO - 2018-03-08 00:13:27 --> Output Class Initialized
DEBUG - 2018-03-08 00:13:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:13:27 --> Security Class Initialized
INFO - 2018-03-08 00:13:27 --> Input Class Initialized
INFO - 2018-03-08 00:13:27 --> Security Class Initialized
INFO - 2018-03-08 00:13:27 --> Language Class Initialized
DEBUG - 2018-03-08 00:13:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-08 00:13:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:13:27 --> Input Class Initialized
INFO - 2018-03-08 00:13:27 --> Input Class Initialized
ERROR - 2018-03-08 00:13:27 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-08 00:13:27 --> Language Class Initialized
INFO - 2018-03-08 00:13:27 --> Language Class Initialized
ERROR - 2018-03-08 00:13:27 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-08 00:13:27 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-08 00:13:27 --> Config Class Initialized
INFO - 2018-03-08 00:13:27 --> Hooks Class Initialized
DEBUG - 2018-03-08 00:13:27 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:13:27 --> Utf8 Class Initialized
INFO - 2018-03-08 00:13:27 --> URI Class Initialized
INFO - 2018-03-08 00:13:27 --> Router Class Initialized
INFO - 2018-03-08 00:13:27 --> Output Class Initialized
INFO - 2018-03-08 00:13:27 --> Security Class Initialized
DEBUG - 2018-03-08 00:13:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:13:27 --> Input Class Initialized
INFO - 2018-03-08 00:13:27 --> Language Class Initialized
INFO - 2018-03-08 00:13:27 --> Loader Class Initialized
INFO - 2018-03-08 00:13:27 --> Helper loaded: url_helper
INFO - 2018-03-08 00:13:27 --> Helper loaded: form_helper
INFO - 2018-03-08 00:13:27 --> Database Driver Class Initialized
DEBUG - 2018-03-08 00:13:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-08 00:13:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 00:13:27 --> Form Validation Class Initialized
INFO - 2018-03-08 00:13:27 --> Model Class Initialized
INFO - 2018-03-08 00:13:27 --> Controller Class Initialized
INFO - 2018-03-08 00:13:27 --> Model Class Initialized
INFO - 2018-03-08 00:13:27 --> Model Class Initialized
INFO - 2018-03-08 00:13:27 --> Model Class Initialized
INFO - 2018-03-08 00:13:27 --> Model Class Initialized
INFO - 2018-03-08 00:13:27 --> Model Class Initialized
DEBUG - 2018-03-08 00:13:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-08 00:15:23 --> Config Class Initialized
INFO - 2018-03-08 00:15:23 --> Hooks Class Initialized
DEBUG - 2018-03-08 00:15:23 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:15:23 --> Utf8 Class Initialized
INFO - 2018-03-08 00:15:23 --> URI Class Initialized
INFO - 2018-03-08 00:15:23 --> Router Class Initialized
INFO - 2018-03-08 00:15:23 --> Output Class Initialized
INFO - 2018-03-08 00:15:23 --> Security Class Initialized
DEBUG - 2018-03-08 00:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:15:23 --> Input Class Initialized
INFO - 2018-03-08 00:15:23 --> Language Class Initialized
INFO - 2018-03-08 00:15:23 --> Loader Class Initialized
INFO - 2018-03-08 00:15:23 --> Helper loaded: url_helper
INFO - 2018-03-08 00:15:23 --> Helper loaded: form_helper
INFO - 2018-03-08 00:15:23 --> Database Driver Class Initialized
DEBUG - 2018-03-08 00:15:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-08 00:15:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 00:15:23 --> Form Validation Class Initialized
INFO - 2018-03-08 00:15:23 --> Model Class Initialized
INFO - 2018-03-08 00:15:23 --> Controller Class Initialized
INFO - 2018-03-08 00:15:23 --> Model Class Initialized
INFO - 2018-03-08 00:15:23 --> Model Class Initialized
INFO - 2018-03-08 00:15:23 --> Model Class Initialized
INFO - 2018-03-08 00:15:23 --> Model Class Initialized
INFO - 2018-03-08 00:15:23 --> Model Class Initialized
DEBUG - 2018-03-08 00:15:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-08 00:15:23 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-08 00:15:23 --> Final output sent to browser
DEBUG - 2018-03-08 00:15:23 --> Total execution time: 0.0611
INFO - 2018-03-08 00:15:24 --> Config Class Initialized
INFO - 2018-03-08 00:15:24 --> Config Class Initialized
INFO - 2018-03-08 00:15:24 --> Hooks Class Initialized
INFO - 2018-03-08 00:15:24 --> Hooks Class Initialized
INFO - 2018-03-08 00:15:24 --> Config Class Initialized
INFO - 2018-03-08 00:15:24 --> Hooks Class Initialized
DEBUG - 2018-03-08 00:15:24 --> UTF-8 Support Enabled
DEBUG - 2018-03-08 00:15:24 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:15:24 --> Utf8 Class Initialized
INFO - 2018-03-08 00:15:24 --> Utf8 Class Initialized
INFO - 2018-03-08 00:15:24 --> Config Class Initialized
INFO - 2018-03-08 00:15:24 --> Hooks Class Initialized
DEBUG - 2018-03-08 00:15:24 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:15:24 --> Utf8 Class Initialized
INFO - 2018-03-08 00:15:24 --> URI Class Initialized
INFO - 2018-03-08 00:15:24 --> URI Class Initialized
INFO - 2018-03-08 00:15:24 --> URI Class Initialized
INFO - 2018-03-08 00:15:24 --> Router Class Initialized
INFO - 2018-03-08 00:15:24 --> Router Class Initialized
DEBUG - 2018-03-08 00:15:24 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:15:24 --> Router Class Initialized
INFO - 2018-03-08 00:15:24 --> Utf8 Class Initialized
INFO - 2018-03-08 00:15:24 --> Output Class Initialized
INFO - 2018-03-08 00:15:24 --> Output Class Initialized
INFO - 2018-03-08 00:15:24 --> URI Class Initialized
INFO - 2018-03-08 00:15:24 --> Output Class Initialized
INFO - 2018-03-08 00:15:24 --> Security Class Initialized
INFO - 2018-03-08 00:15:24 --> Security Class Initialized
INFO - 2018-03-08 00:15:24 --> Router Class Initialized
INFO - 2018-03-08 00:15:24 --> Security Class Initialized
DEBUG - 2018-03-08 00:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:15:24 --> Input Class Initialized
DEBUG - 2018-03-08 00:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:15:24 --> Input Class Initialized
INFO - 2018-03-08 00:15:24 --> Output Class Initialized
DEBUG - 2018-03-08 00:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:15:24 --> Language Class Initialized
INFO - 2018-03-08 00:15:24 --> Input Class Initialized
INFO - 2018-03-08 00:15:24 --> Language Class Initialized
INFO - 2018-03-08 00:15:24 --> Language Class Initialized
INFO - 2018-03-08 00:15:24 --> Security Class Initialized
ERROR - 2018-03-08 00:15:24 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-08 00:15:24 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-08 00:15:24 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-08 00:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:15:24 --> Input Class Initialized
INFO - 2018-03-08 00:15:24 --> Language Class Initialized
ERROR - 2018-03-08 00:15:24 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-08 00:15:24 --> Config Class Initialized
INFO - 2018-03-08 00:15:24 --> Hooks Class Initialized
INFO - 2018-03-08 00:15:24 --> Config Class Initialized
INFO - 2018-03-08 00:15:24 --> Config Class Initialized
DEBUG - 2018-03-08 00:15:24 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:15:24 --> Hooks Class Initialized
INFO - 2018-03-08 00:15:24 --> Utf8 Class Initialized
INFO - 2018-03-08 00:15:24 --> Hooks Class Initialized
INFO - 2018-03-08 00:15:24 --> URI Class Initialized
DEBUG - 2018-03-08 00:15:24 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:15:24 --> Router Class Initialized
DEBUG - 2018-03-08 00:15:24 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:15:24 --> Utf8 Class Initialized
INFO - 2018-03-08 00:15:24 --> Utf8 Class Initialized
INFO - 2018-03-08 00:15:24 --> URI Class Initialized
INFO - 2018-03-08 00:15:24 --> URI Class Initialized
INFO - 2018-03-08 00:15:24 --> Output Class Initialized
INFO - 2018-03-08 00:15:24 --> Router Class Initialized
INFO - 2018-03-08 00:15:24 --> Router Class Initialized
INFO - 2018-03-08 00:15:24 --> Security Class Initialized
INFO - 2018-03-08 00:15:24 --> Output Class Initialized
DEBUG - 2018-03-08 00:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:15:24 --> Input Class Initialized
INFO - 2018-03-08 00:15:24 --> Output Class Initialized
INFO - 2018-03-08 00:15:24 --> Security Class Initialized
INFO - 2018-03-08 00:15:24 --> Language Class Initialized
INFO - 2018-03-08 00:15:24 --> Security Class Initialized
DEBUG - 2018-03-08 00:15:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-03-08 00:15:24 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-08 00:15:24 --> Input Class Initialized
DEBUG - 2018-03-08 00:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:15:24 --> Input Class Initialized
INFO - 2018-03-08 00:15:24 --> Language Class Initialized
INFO - 2018-03-08 00:15:24 --> Language Class Initialized
ERROR - 2018-03-08 00:15:24 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-08 00:15:24 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-08 00:15:24 --> Config Class Initialized
INFO - 2018-03-08 00:15:24 --> Hooks Class Initialized
DEBUG - 2018-03-08 00:15:24 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:15:24 --> Utf8 Class Initialized
INFO - 2018-03-08 00:15:24 --> URI Class Initialized
INFO - 2018-03-08 00:15:24 --> Router Class Initialized
INFO - 2018-03-08 00:15:24 --> Output Class Initialized
INFO - 2018-03-08 00:15:24 --> Security Class Initialized
DEBUG - 2018-03-08 00:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:15:24 --> Input Class Initialized
INFO - 2018-03-08 00:15:24 --> Language Class Initialized
INFO - 2018-03-08 00:15:24 --> Loader Class Initialized
INFO - 2018-03-08 00:15:24 --> Helper loaded: url_helper
INFO - 2018-03-08 00:15:24 --> Helper loaded: form_helper
INFO - 2018-03-08 00:15:24 --> Database Driver Class Initialized
DEBUG - 2018-03-08 00:15:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-08 00:15:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 00:15:24 --> Form Validation Class Initialized
INFO - 2018-03-08 00:15:24 --> Model Class Initialized
INFO - 2018-03-08 00:15:24 --> Controller Class Initialized
INFO - 2018-03-08 00:15:24 --> Model Class Initialized
INFO - 2018-03-08 00:15:24 --> Model Class Initialized
INFO - 2018-03-08 00:15:24 --> Model Class Initialized
INFO - 2018-03-08 00:15:24 --> Model Class Initialized
INFO - 2018-03-08 00:15:24 --> Model Class Initialized
DEBUG - 2018-03-08 00:15:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-08 00:16:04 --> Config Class Initialized
INFO - 2018-03-08 00:16:04 --> Hooks Class Initialized
DEBUG - 2018-03-08 00:16:04 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:16:04 --> Utf8 Class Initialized
INFO - 2018-03-08 00:16:04 --> URI Class Initialized
INFO - 2018-03-08 00:16:04 --> Router Class Initialized
INFO - 2018-03-08 00:16:04 --> Output Class Initialized
INFO - 2018-03-08 00:16:04 --> Security Class Initialized
DEBUG - 2018-03-08 00:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:16:04 --> Input Class Initialized
INFO - 2018-03-08 00:16:04 --> Language Class Initialized
INFO - 2018-03-08 00:16:04 --> Loader Class Initialized
INFO - 2018-03-08 00:16:04 --> Helper loaded: url_helper
INFO - 2018-03-08 00:16:04 --> Helper loaded: form_helper
INFO - 2018-03-08 00:16:04 --> Database Driver Class Initialized
DEBUG - 2018-03-08 00:16:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-08 00:16:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 00:16:04 --> Form Validation Class Initialized
INFO - 2018-03-08 00:16:04 --> Model Class Initialized
INFO - 2018-03-08 00:16:04 --> Controller Class Initialized
INFO - 2018-03-08 00:16:04 --> Model Class Initialized
INFO - 2018-03-08 00:16:04 --> Model Class Initialized
INFO - 2018-03-08 00:16:04 --> Model Class Initialized
INFO - 2018-03-08 00:16:04 --> Model Class Initialized
INFO - 2018-03-08 00:16:04 --> Model Class Initialized
DEBUG - 2018-03-08 00:16:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-08 00:16:04 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-08 00:16:04 --> Final output sent to browser
DEBUG - 2018-03-08 00:16:04 --> Total execution time: 0.0766
INFO - 2018-03-08 00:16:05 --> Config Class Initialized
INFO - 2018-03-08 00:16:05 --> Hooks Class Initialized
DEBUG - 2018-03-08 00:16:05 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:16:05 --> Utf8 Class Initialized
INFO - 2018-03-08 00:16:05 --> URI Class Initialized
INFO - 2018-03-08 00:16:05 --> Router Class Initialized
INFO - 2018-03-08 00:16:05 --> Output Class Initialized
INFO - 2018-03-08 00:16:05 --> Security Class Initialized
DEBUG - 2018-03-08 00:16:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:16:05 --> Input Class Initialized
INFO - 2018-03-08 00:16:05 --> Language Class Initialized
INFO - 2018-03-08 00:16:05 --> Loader Class Initialized
INFO - 2018-03-08 00:16:05 --> Helper loaded: url_helper
INFO - 2018-03-08 00:16:05 --> Helper loaded: form_helper
INFO - 2018-03-08 00:16:05 --> Database Driver Class Initialized
DEBUG - 2018-03-08 00:16:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-08 00:16:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 00:16:05 --> Form Validation Class Initialized
INFO - 2018-03-08 00:16:05 --> Model Class Initialized
INFO - 2018-03-08 00:16:05 --> Controller Class Initialized
INFO - 2018-03-08 00:16:05 --> Model Class Initialized
INFO - 2018-03-08 00:16:05 --> Model Class Initialized
INFO - 2018-03-08 00:16:05 --> Model Class Initialized
INFO - 2018-03-08 00:16:05 --> Model Class Initialized
INFO - 2018-03-08 00:16:05 --> Model Class Initialized
DEBUG - 2018-03-08 00:16:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-08 00:16:07 --> Config Class Initialized
INFO - 2018-03-08 00:16:07 --> Hooks Class Initialized
INFO - 2018-03-08 00:16:07 --> Config Class Initialized
INFO - 2018-03-08 00:16:07 --> Hooks Class Initialized
INFO - 2018-03-08 00:16:07 --> Config Class Initialized
DEBUG - 2018-03-08 00:16:07 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:16:07 --> Hooks Class Initialized
INFO - 2018-03-08 00:16:07 --> Utf8 Class Initialized
INFO - 2018-03-08 00:16:07 --> URI Class Initialized
DEBUG - 2018-03-08 00:16:07 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:16:07 --> Config Class Initialized
INFO - 2018-03-08 00:16:07 --> Utf8 Class Initialized
DEBUG - 2018-03-08 00:16:07 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:16:07 --> Hooks Class Initialized
INFO - 2018-03-08 00:16:07 --> Utf8 Class Initialized
INFO - 2018-03-08 00:16:07 --> Router Class Initialized
INFO - 2018-03-08 00:16:07 --> URI Class Initialized
INFO - 2018-03-08 00:16:07 --> URI Class Initialized
INFO - 2018-03-08 00:16:07 --> Output Class Initialized
INFO - 2018-03-08 00:16:07 --> Router Class Initialized
DEBUG - 2018-03-08 00:16:07 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:16:07 --> Router Class Initialized
INFO - 2018-03-08 00:16:07 --> Utf8 Class Initialized
INFO - 2018-03-08 00:16:07 --> Security Class Initialized
INFO - 2018-03-08 00:16:07 --> URI Class Initialized
INFO - 2018-03-08 00:16:07 --> Output Class Initialized
DEBUG - 2018-03-08 00:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:16:07 --> Output Class Initialized
INFO - 2018-03-08 00:16:07 --> Input Class Initialized
INFO - 2018-03-08 00:16:07 --> Security Class Initialized
INFO - 2018-03-08 00:16:07 --> Language Class Initialized
INFO - 2018-03-08 00:16:07 --> Security Class Initialized
INFO - 2018-03-08 00:16:07 --> Router Class Initialized
DEBUG - 2018-03-08 00:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:16:07 --> Input Class Initialized
ERROR - 2018-03-08 00:16:07 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-08 00:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:16:07 --> Input Class Initialized
INFO - 2018-03-08 00:16:07 --> Language Class Initialized
INFO - 2018-03-08 00:16:07 --> Output Class Initialized
INFO - 2018-03-08 00:16:07 --> Language Class Initialized
ERROR - 2018-03-08 00:16:07 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-08 00:16:07 --> Security Class Initialized
ERROR - 2018-03-08 00:16:07 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-08 00:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:16:07 --> Input Class Initialized
INFO - 2018-03-08 00:16:07 --> Language Class Initialized
ERROR - 2018-03-08 00:16:07 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-08 00:16:07 --> Config Class Initialized
INFO - 2018-03-08 00:16:07 --> Hooks Class Initialized
INFO - 2018-03-08 00:16:07 --> Config Class Initialized
INFO - 2018-03-08 00:16:07 --> Hooks Class Initialized
INFO - 2018-03-08 00:16:07 --> Config Class Initialized
INFO - 2018-03-08 00:16:07 --> Hooks Class Initialized
DEBUG - 2018-03-08 00:16:07 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:16:07 --> Utf8 Class Initialized
INFO - 2018-03-08 00:16:07 --> URI Class Initialized
DEBUG - 2018-03-08 00:16:07 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:16:07 --> Utf8 Class Initialized
DEBUG - 2018-03-08 00:16:07 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:16:07 --> Utf8 Class Initialized
INFO - 2018-03-08 00:16:07 --> Router Class Initialized
INFO - 2018-03-08 00:16:07 --> URI Class Initialized
INFO - 2018-03-08 00:16:07 --> URI Class Initialized
INFO - 2018-03-08 00:16:07 --> Router Class Initialized
INFO - 2018-03-08 00:16:07 --> Output Class Initialized
INFO - 2018-03-08 00:16:07 --> Router Class Initialized
INFO - 2018-03-08 00:16:07 --> Output Class Initialized
INFO - 2018-03-08 00:16:07 --> Security Class Initialized
INFO - 2018-03-08 00:16:07 --> Output Class Initialized
INFO - 2018-03-08 00:16:07 --> Security Class Initialized
DEBUG - 2018-03-08 00:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:16:07 --> Input Class Initialized
DEBUG - 2018-03-08 00:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:16:07 --> Security Class Initialized
INFO - 2018-03-08 00:16:07 --> Input Class Initialized
INFO - 2018-03-08 00:16:07 --> Language Class Initialized
INFO - 2018-03-08 00:16:07 --> Language Class Initialized
DEBUG - 2018-03-08 00:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:16:07 --> Input Class Initialized
ERROR - 2018-03-08 00:16:07 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-08 00:16:07 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-08 00:16:07 --> Language Class Initialized
ERROR - 2018-03-08 00:16:07 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-08 00:16:16 --> Config Class Initialized
INFO - 2018-03-08 00:16:16 --> Hooks Class Initialized
DEBUG - 2018-03-08 00:16:16 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:16:16 --> Utf8 Class Initialized
INFO - 2018-03-08 00:16:16 --> URI Class Initialized
INFO - 2018-03-08 00:16:16 --> Router Class Initialized
INFO - 2018-03-08 00:16:16 --> Output Class Initialized
INFO - 2018-03-08 00:16:16 --> Security Class Initialized
DEBUG - 2018-03-08 00:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:16:16 --> Input Class Initialized
INFO - 2018-03-08 00:16:16 --> Language Class Initialized
INFO - 2018-03-08 00:16:16 --> Loader Class Initialized
INFO - 2018-03-08 00:16:16 --> Helper loaded: url_helper
INFO - 2018-03-08 00:16:16 --> Helper loaded: form_helper
INFO - 2018-03-08 00:16:16 --> Database Driver Class Initialized
DEBUG - 2018-03-08 00:16:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-08 00:16:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 00:16:16 --> Form Validation Class Initialized
INFO - 2018-03-08 00:16:16 --> Model Class Initialized
INFO - 2018-03-08 00:16:16 --> Controller Class Initialized
INFO - 2018-03-08 00:16:16 --> Model Class Initialized
INFO - 2018-03-08 00:16:16 --> Model Class Initialized
INFO - 2018-03-08 00:16:16 --> Model Class Initialized
INFO - 2018-03-08 00:16:16 --> Model Class Initialized
INFO - 2018-03-08 00:16:16 --> Model Class Initialized
DEBUG - 2018-03-08 00:16:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-08 00:16:16 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-08 00:16:16 --> Final output sent to browser
DEBUG - 2018-03-08 00:16:16 --> Total execution time: 0.0702
INFO - 2018-03-08 00:16:48 --> Config Class Initialized
INFO - 2018-03-08 00:16:48 --> Hooks Class Initialized
DEBUG - 2018-03-08 00:16:48 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:16:48 --> Utf8 Class Initialized
INFO - 2018-03-08 00:16:48 --> URI Class Initialized
INFO - 2018-03-08 00:16:48 --> Router Class Initialized
INFO - 2018-03-08 00:16:48 --> Output Class Initialized
INFO - 2018-03-08 00:16:48 --> Security Class Initialized
DEBUG - 2018-03-08 00:16:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:16:48 --> Input Class Initialized
INFO - 2018-03-08 00:16:48 --> Language Class Initialized
INFO - 2018-03-08 00:16:48 --> Loader Class Initialized
INFO - 2018-03-08 00:16:48 --> Helper loaded: url_helper
INFO - 2018-03-08 00:16:48 --> Helper loaded: form_helper
INFO - 2018-03-08 00:16:48 --> Database Driver Class Initialized
DEBUG - 2018-03-08 00:16:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-08 00:16:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 00:16:48 --> Form Validation Class Initialized
INFO - 2018-03-08 00:16:48 --> Model Class Initialized
INFO - 2018-03-08 00:16:48 --> Controller Class Initialized
INFO - 2018-03-08 00:16:48 --> Model Class Initialized
INFO - 2018-03-08 00:16:48 --> Model Class Initialized
INFO - 2018-03-08 00:16:48 --> Model Class Initialized
INFO - 2018-03-08 00:16:48 --> Model Class Initialized
INFO - 2018-03-08 00:16:48 --> Model Class Initialized
DEBUG - 2018-03-08 00:16:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-08 00:16:48 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-08 00:16:48 --> Final output sent to browser
DEBUG - 2018-03-08 00:16:48 --> Total execution time: 0.0596
INFO - 2018-03-08 00:17:01 --> Config Class Initialized
INFO - 2018-03-08 00:17:01 --> Hooks Class Initialized
DEBUG - 2018-03-08 00:17:01 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:17:01 --> Utf8 Class Initialized
INFO - 2018-03-08 00:17:01 --> URI Class Initialized
INFO - 2018-03-08 00:17:01 --> Router Class Initialized
INFO - 2018-03-08 00:17:01 --> Output Class Initialized
INFO - 2018-03-08 00:17:01 --> Security Class Initialized
DEBUG - 2018-03-08 00:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:17:01 --> Input Class Initialized
INFO - 2018-03-08 00:17:01 --> Language Class Initialized
INFO - 2018-03-08 00:17:01 --> Loader Class Initialized
INFO - 2018-03-08 00:17:01 --> Helper loaded: url_helper
INFO - 2018-03-08 00:17:01 --> Helper loaded: form_helper
INFO - 2018-03-08 00:17:01 --> Database Driver Class Initialized
DEBUG - 2018-03-08 00:17:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-08 00:17:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 00:17:01 --> Form Validation Class Initialized
INFO - 2018-03-08 00:17:01 --> Model Class Initialized
INFO - 2018-03-08 00:17:01 --> Controller Class Initialized
INFO - 2018-03-08 00:17:01 --> Model Class Initialized
INFO - 2018-03-08 00:17:01 --> Model Class Initialized
INFO - 2018-03-08 00:17:01 --> Model Class Initialized
INFO - 2018-03-08 00:17:01 --> Model Class Initialized
INFO - 2018-03-08 00:17:01 --> Model Class Initialized
DEBUG - 2018-03-08 00:17:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-08 00:17:01 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-08 00:17:01 --> Final output sent to browser
DEBUG - 2018-03-08 00:17:01 --> Total execution time: 0.0767
INFO - 2018-03-08 00:17:01 --> Config Class Initialized
INFO - 2018-03-08 00:17:01 --> Config Class Initialized
INFO - 2018-03-08 00:17:01 --> Hooks Class Initialized
INFO - 2018-03-08 00:17:01 --> Hooks Class Initialized
INFO - 2018-03-08 00:17:01 --> Config Class Initialized
INFO - 2018-03-08 00:17:01 --> Hooks Class Initialized
DEBUG - 2018-03-08 00:17:01 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:17:01 --> Utf8 Class Initialized
DEBUG - 2018-03-08 00:17:01 --> UTF-8 Support Enabled
DEBUG - 2018-03-08 00:17:01 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:17:01 --> Utf8 Class Initialized
INFO - 2018-03-08 00:17:01 --> Utf8 Class Initialized
INFO - 2018-03-08 00:17:01 --> URI Class Initialized
INFO - 2018-03-08 00:17:01 --> URI Class Initialized
INFO - 2018-03-08 00:17:01 --> URI Class Initialized
INFO - 2018-03-08 00:17:01 --> Router Class Initialized
INFO - 2018-03-08 00:17:01 --> Router Class Initialized
INFO - 2018-03-08 00:17:01 --> Router Class Initialized
INFO - 2018-03-08 00:17:01 --> Output Class Initialized
INFO - 2018-03-08 00:17:01 --> Output Class Initialized
INFO - 2018-03-08 00:17:01 --> Output Class Initialized
INFO - 2018-03-08 00:17:01 --> Security Class Initialized
INFO - 2018-03-08 00:17:01 --> Security Class Initialized
INFO - 2018-03-08 00:17:01 --> Security Class Initialized
DEBUG - 2018-03-08 00:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:17:01 --> Input Class Initialized
DEBUG - 2018-03-08 00:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:17:01 --> Input Class Initialized
DEBUG - 2018-03-08 00:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:17:01 --> Language Class Initialized
INFO - 2018-03-08 00:17:01 --> Input Class Initialized
INFO - 2018-03-08 00:17:01 --> Language Class Initialized
INFO - 2018-03-08 00:17:01 --> Language Class Initialized
ERROR - 2018-03-08 00:17:01 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-08 00:17:01 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-08 00:17:01 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-08 00:17:01 --> Config Class Initialized
INFO - 2018-03-08 00:17:01 --> Hooks Class Initialized
DEBUG - 2018-03-08 00:17:01 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:17:01 --> Utf8 Class Initialized
INFO - 2018-03-08 00:17:01 --> URI Class Initialized
INFO - 2018-03-08 00:17:01 --> Router Class Initialized
INFO - 2018-03-08 00:17:01 --> Output Class Initialized
INFO - 2018-03-08 00:17:01 --> Security Class Initialized
DEBUG - 2018-03-08 00:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:17:01 --> Input Class Initialized
INFO - 2018-03-08 00:17:01 --> Language Class Initialized
ERROR - 2018-03-08 00:17:01 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-08 00:17:01 --> Config Class Initialized
INFO - 2018-03-08 00:17:01 --> Hooks Class Initialized
INFO - 2018-03-08 00:17:01 --> Config Class Initialized
INFO - 2018-03-08 00:17:01 --> Config Class Initialized
INFO - 2018-03-08 00:17:01 --> Hooks Class Initialized
INFO - 2018-03-08 00:17:01 --> Hooks Class Initialized
DEBUG - 2018-03-08 00:17:01 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:17:01 --> Utf8 Class Initialized
DEBUG - 2018-03-08 00:17:01 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:17:01 --> URI Class Initialized
DEBUG - 2018-03-08 00:17:01 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:17:01 --> Utf8 Class Initialized
INFO - 2018-03-08 00:17:01 --> Utf8 Class Initialized
INFO - 2018-03-08 00:17:01 --> URI Class Initialized
INFO - 2018-03-08 00:17:01 --> URI Class Initialized
INFO - 2018-03-08 00:17:01 --> Router Class Initialized
INFO - 2018-03-08 00:17:01 --> Router Class Initialized
INFO - 2018-03-08 00:17:01 --> Router Class Initialized
INFO - 2018-03-08 00:17:01 --> Output Class Initialized
INFO - 2018-03-08 00:17:01 --> Output Class Initialized
INFO - 2018-03-08 00:17:01 --> Security Class Initialized
INFO - 2018-03-08 00:17:01 --> Output Class Initialized
INFO - 2018-03-08 00:17:01 --> Security Class Initialized
DEBUG - 2018-03-08 00:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:17:01 --> Input Class Initialized
INFO - 2018-03-08 00:17:01 --> Security Class Initialized
INFO - 2018-03-08 00:17:01 --> Language Class Initialized
DEBUG - 2018-03-08 00:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:17:01 --> Input Class Initialized
DEBUG - 2018-03-08 00:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:17:01 --> Input Class Initialized
INFO - 2018-03-08 00:17:01 --> Language Class Initialized
ERROR - 2018-03-08 00:17:01 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-08 00:17:01 --> Language Class Initialized
ERROR - 2018-03-08 00:17:01 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-08 00:17:01 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-08 00:17:01 --> Config Class Initialized
INFO - 2018-03-08 00:17:01 --> Hooks Class Initialized
DEBUG - 2018-03-08 00:17:01 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:17:01 --> Utf8 Class Initialized
INFO - 2018-03-08 00:17:01 --> URI Class Initialized
INFO - 2018-03-08 00:17:01 --> Router Class Initialized
INFO - 2018-03-08 00:17:01 --> Output Class Initialized
INFO - 2018-03-08 00:17:01 --> Security Class Initialized
DEBUG - 2018-03-08 00:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:17:01 --> Input Class Initialized
INFO - 2018-03-08 00:17:01 --> Language Class Initialized
INFO - 2018-03-08 00:17:01 --> Loader Class Initialized
INFO - 2018-03-08 00:17:01 --> Helper loaded: url_helper
INFO - 2018-03-08 00:17:01 --> Helper loaded: form_helper
INFO - 2018-03-08 00:17:01 --> Database Driver Class Initialized
DEBUG - 2018-03-08 00:17:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-08 00:17:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 00:17:01 --> Form Validation Class Initialized
INFO - 2018-03-08 00:17:01 --> Model Class Initialized
INFO - 2018-03-08 00:17:01 --> Controller Class Initialized
INFO - 2018-03-08 00:17:01 --> Model Class Initialized
INFO - 2018-03-08 00:17:01 --> Model Class Initialized
INFO - 2018-03-08 00:17:01 --> Model Class Initialized
INFO - 2018-03-08 00:17:01 --> Model Class Initialized
INFO - 2018-03-08 00:17:01 --> Model Class Initialized
DEBUG - 2018-03-08 00:17:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-08 00:17:26 --> Config Class Initialized
INFO - 2018-03-08 00:17:26 --> Hooks Class Initialized
DEBUG - 2018-03-08 00:17:26 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:17:26 --> Utf8 Class Initialized
INFO - 2018-03-08 00:17:26 --> URI Class Initialized
INFO - 2018-03-08 00:17:26 --> Router Class Initialized
INFO - 2018-03-08 00:17:26 --> Output Class Initialized
INFO - 2018-03-08 00:17:26 --> Security Class Initialized
DEBUG - 2018-03-08 00:17:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:17:26 --> Input Class Initialized
INFO - 2018-03-08 00:17:26 --> Language Class Initialized
INFO - 2018-03-08 00:17:26 --> Loader Class Initialized
INFO - 2018-03-08 00:17:26 --> Helper loaded: url_helper
INFO - 2018-03-08 00:17:26 --> Helper loaded: form_helper
INFO - 2018-03-08 00:17:26 --> Database Driver Class Initialized
DEBUG - 2018-03-08 00:17:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-08 00:17:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 00:17:26 --> Form Validation Class Initialized
INFO - 2018-03-08 00:17:26 --> Model Class Initialized
INFO - 2018-03-08 00:17:26 --> Controller Class Initialized
INFO - 2018-03-08 00:17:26 --> Model Class Initialized
INFO - 2018-03-08 00:17:26 --> Model Class Initialized
INFO - 2018-03-08 00:17:26 --> Model Class Initialized
INFO - 2018-03-08 00:17:26 --> Model Class Initialized
INFO - 2018-03-08 00:17:26 --> Model Class Initialized
DEBUG - 2018-03-08 00:17:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-08 00:17:26 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-08 00:17:26 --> Final output sent to browser
DEBUG - 2018-03-08 00:17:26 --> Total execution time: 0.0780
INFO - 2018-03-08 00:17:27 --> Config Class Initialized
INFO - 2018-03-08 00:17:27 --> Config Class Initialized
INFO - 2018-03-08 00:17:27 --> Hooks Class Initialized
INFO - 2018-03-08 00:17:27 --> Hooks Class Initialized
INFO - 2018-03-08 00:17:27 --> Config Class Initialized
INFO - 2018-03-08 00:17:27 --> Hooks Class Initialized
DEBUG - 2018-03-08 00:17:27 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:17:27 --> Utf8 Class Initialized
DEBUG - 2018-03-08 00:17:27 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:17:27 --> Utf8 Class Initialized
INFO - 2018-03-08 00:17:27 --> URI Class Initialized
INFO - 2018-03-08 00:17:27 --> URI Class Initialized
DEBUG - 2018-03-08 00:17:27 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:17:27 --> Utf8 Class Initialized
INFO - 2018-03-08 00:17:27 --> Router Class Initialized
INFO - 2018-03-08 00:17:27 --> Router Class Initialized
INFO - 2018-03-08 00:17:27 --> URI Class Initialized
INFO - 2018-03-08 00:17:27 --> Output Class Initialized
INFO - 2018-03-08 00:17:27 --> Output Class Initialized
INFO - 2018-03-08 00:17:27 --> Router Class Initialized
INFO - 2018-03-08 00:17:27 --> Security Class Initialized
INFO - 2018-03-08 00:17:27 --> Security Class Initialized
INFO - 2018-03-08 00:17:27 --> Output Class Initialized
DEBUG - 2018-03-08 00:17:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-08 00:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:17:27 --> Input Class Initialized
INFO - 2018-03-08 00:17:27 --> Input Class Initialized
INFO - 2018-03-08 00:17:27 --> Security Class Initialized
INFO - 2018-03-08 00:17:27 --> Language Class Initialized
INFO - 2018-03-08 00:17:27 --> Language Class Initialized
DEBUG - 2018-03-08 00:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:17:27 --> Input Class Initialized
ERROR - 2018-03-08 00:17:27 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-08 00:17:27 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-08 00:17:27 --> Language Class Initialized
ERROR - 2018-03-08 00:17:27 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-08 00:17:27 --> Config Class Initialized
INFO - 2018-03-08 00:17:27 --> Hooks Class Initialized
DEBUG - 2018-03-08 00:17:27 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:17:27 --> Utf8 Class Initialized
INFO - 2018-03-08 00:17:27 --> URI Class Initialized
INFO - 2018-03-08 00:17:27 --> Router Class Initialized
INFO - 2018-03-08 00:17:27 --> Output Class Initialized
INFO - 2018-03-08 00:17:27 --> Security Class Initialized
DEBUG - 2018-03-08 00:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:17:27 --> Input Class Initialized
INFO - 2018-03-08 00:17:27 --> Language Class Initialized
ERROR - 2018-03-08 00:17:27 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-08 00:17:27 --> Config Class Initialized
INFO - 2018-03-08 00:17:27 --> Config Class Initialized
INFO - 2018-03-08 00:17:27 --> Hooks Class Initialized
INFO - 2018-03-08 00:17:27 --> Hooks Class Initialized
INFO - 2018-03-08 00:17:27 --> Config Class Initialized
INFO - 2018-03-08 00:17:27 --> Hooks Class Initialized
DEBUG - 2018-03-08 00:17:27 --> UTF-8 Support Enabled
DEBUG - 2018-03-08 00:17:27 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:17:27 --> Utf8 Class Initialized
INFO - 2018-03-08 00:17:27 --> Utf8 Class Initialized
DEBUG - 2018-03-08 00:17:27 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:17:27 --> Utf8 Class Initialized
INFO - 2018-03-08 00:17:27 --> URI Class Initialized
INFO - 2018-03-08 00:17:27 --> URI Class Initialized
INFO - 2018-03-08 00:17:27 --> URI Class Initialized
INFO - 2018-03-08 00:17:27 --> Router Class Initialized
INFO - 2018-03-08 00:17:27 --> Router Class Initialized
INFO - 2018-03-08 00:17:27 --> Router Class Initialized
INFO - 2018-03-08 00:17:27 --> Output Class Initialized
INFO - 2018-03-08 00:17:27 --> Output Class Initialized
INFO - 2018-03-08 00:17:27 --> Output Class Initialized
INFO - 2018-03-08 00:17:27 --> Security Class Initialized
INFO - 2018-03-08 00:17:27 --> Security Class Initialized
INFO - 2018-03-08 00:17:27 --> Security Class Initialized
DEBUG - 2018-03-08 00:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:17:27 --> Input Class Initialized
DEBUG - 2018-03-08 00:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:17:27 --> Input Class Initialized
INFO - 2018-03-08 00:17:27 --> Language Class Initialized
DEBUG - 2018-03-08 00:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:17:27 --> Input Class Initialized
INFO - 2018-03-08 00:17:27 --> Language Class Initialized
INFO - 2018-03-08 00:17:27 --> Language Class Initialized
ERROR - 2018-03-08 00:17:27 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-08 00:17:27 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-08 00:17:27 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-08 00:17:27 --> Config Class Initialized
INFO - 2018-03-08 00:17:27 --> Hooks Class Initialized
DEBUG - 2018-03-08 00:17:27 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:17:27 --> Utf8 Class Initialized
INFO - 2018-03-08 00:17:27 --> URI Class Initialized
INFO - 2018-03-08 00:17:27 --> Router Class Initialized
INFO - 2018-03-08 00:17:27 --> Output Class Initialized
INFO - 2018-03-08 00:17:27 --> Security Class Initialized
DEBUG - 2018-03-08 00:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:17:27 --> Input Class Initialized
INFO - 2018-03-08 00:17:27 --> Language Class Initialized
INFO - 2018-03-08 00:17:27 --> Loader Class Initialized
INFO - 2018-03-08 00:17:27 --> Helper loaded: url_helper
INFO - 2018-03-08 00:17:27 --> Helper loaded: form_helper
INFO - 2018-03-08 00:17:27 --> Database Driver Class Initialized
DEBUG - 2018-03-08 00:17:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-08 00:17:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 00:17:27 --> Form Validation Class Initialized
INFO - 2018-03-08 00:17:27 --> Model Class Initialized
INFO - 2018-03-08 00:17:27 --> Controller Class Initialized
INFO - 2018-03-08 00:17:27 --> Model Class Initialized
INFO - 2018-03-08 00:17:27 --> Model Class Initialized
INFO - 2018-03-08 00:17:27 --> Model Class Initialized
INFO - 2018-03-08 00:17:27 --> Model Class Initialized
INFO - 2018-03-08 00:17:27 --> Model Class Initialized
DEBUG - 2018-03-08 00:17:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-08 00:17:54 --> Config Class Initialized
INFO - 2018-03-08 00:17:54 --> Hooks Class Initialized
DEBUG - 2018-03-08 00:17:54 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:17:54 --> Utf8 Class Initialized
INFO - 2018-03-08 00:17:54 --> URI Class Initialized
INFO - 2018-03-08 00:17:54 --> Router Class Initialized
INFO - 2018-03-08 00:17:54 --> Output Class Initialized
INFO - 2018-03-08 00:17:54 --> Security Class Initialized
DEBUG - 2018-03-08 00:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:17:54 --> Input Class Initialized
INFO - 2018-03-08 00:17:54 --> Language Class Initialized
INFO - 2018-03-08 00:17:54 --> Loader Class Initialized
INFO - 2018-03-08 00:17:54 --> Helper loaded: url_helper
INFO - 2018-03-08 00:17:54 --> Helper loaded: form_helper
INFO - 2018-03-08 00:17:54 --> Database Driver Class Initialized
DEBUG - 2018-03-08 00:17:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-08 00:17:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 00:17:54 --> Form Validation Class Initialized
INFO - 2018-03-08 00:17:54 --> Model Class Initialized
INFO - 2018-03-08 00:17:54 --> Controller Class Initialized
INFO - 2018-03-08 00:17:54 --> Model Class Initialized
INFO - 2018-03-08 00:17:54 --> Model Class Initialized
INFO - 2018-03-08 00:17:54 --> Model Class Initialized
INFO - 2018-03-08 00:17:54 --> Model Class Initialized
INFO - 2018-03-08 00:17:54 --> Model Class Initialized
DEBUG - 2018-03-08 00:17:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-08 00:17:54 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-08 00:17:54 --> Final output sent to browser
DEBUG - 2018-03-08 00:17:54 --> Total execution time: 0.0732
INFO - 2018-03-08 00:17:54 --> Config Class Initialized
INFO - 2018-03-08 00:17:54 --> Hooks Class Initialized
INFO - 2018-03-08 00:17:54 --> Config Class Initialized
INFO - 2018-03-08 00:17:54 --> Hooks Class Initialized
INFO - 2018-03-08 00:17:54 --> Config Class Initialized
INFO - 2018-03-08 00:17:54 --> Hooks Class Initialized
DEBUG - 2018-03-08 00:17:54 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:17:54 --> Utf8 Class Initialized
DEBUG - 2018-03-08 00:17:54 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:17:54 --> Utf8 Class Initialized
INFO - 2018-03-08 00:17:54 --> URI Class Initialized
INFO - 2018-03-08 00:17:54 --> URI Class Initialized
DEBUG - 2018-03-08 00:17:54 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:17:54 --> Router Class Initialized
INFO - 2018-03-08 00:17:54 --> Utf8 Class Initialized
INFO - 2018-03-08 00:17:54 --> Router Class Initialized
INFO - 2018-03-08 00:17:54 --> URI Class Initialized
INFO - 2018-03-08 00:17:54 --> Output Class Initialized
INFO - 2018-03-08 00:17:54 --> Output Class Initialized
INFO - 2018-03-08 00:17:54 --> Security Class Initialized
INFO - 2018-03-08 00:17:54 --> Router Class Initialized
INFO - 2018-03-08 00:17:54 --> Security Class Initialized
DEBUG - 2018-03-08 00:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:17:54 --> Input Class Initialized
DEBUG - 2018-03-08 00:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:17:54 --> Language Class Initialized
INFO - 2018-03-08 00:17:54 --> Output Class Initialized
INFO - 2018-03-08 00:17:54 --> Input Class Initialized
INFO - 2018-03-08 00:17:54 --> Language Class Initialized
ERROR - 2018-03-08 00:17:54 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-08 00:17:54 --> Security Class Initialized
ERROR - 2018-03-08 00:17:54 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-08 00:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:17:54 --> Input Class Initialized
INFO - 2018-03-08 00:17:54 --> Language Class Initialized
ERROR - 2018-03-08 00:17:54 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-08 00:17:54 --> Config Class Initialized
INFO - 2018-03-08 00:17:54 --> Hooks Class Initialized
DEBUG - 2018-03-08 00:17:54 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:17:54 --> Utf8 Class Initialized
INFO - 2018-03-08 00:17:54 --> URI Class Initialized
INFO - 2018-03-08 00:17:54 --> Router Class Initialized
INFO - 2018-03-08 00:17:54 --> Output Class Initialized
INFO - 2018-03-08 00:17:54 --> Security Class Initialized
DEBUG - 2018-03-08 00:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:17:54 --> Input Class Initialized
INFO - 2018-03-08 00:17:54 --> Language Class Initialized
ERROR - 2018-03-08 00:17:54 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-08 00:17:54 --> Config Class Initialized
INFO - 2018-03-08 00:17:54 --> Hooks Class Initialized
INFO - 2018-03-08 00:17:54 --> Config Class Initialized
INFO - 2018-03-08 00:17:54 --> Hooks Class Initialized
INFO - 2018-03-08 00:17:54 --> Config Class Initialized
INFO - 2018-03-08 00:17:54 --> Hooks Class Initialized
DEBUG - 2018-03-08 00:17:54 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:17:54 --> Utf8 Class Initialized
DEBUG - 2018-03-08 00:17:54 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:17:54 --> Utf8 Class Initialized
INFO - 2018-03-08 00:17:54 --> URI Class Initialized
INFO - 2018-03-08 00:17:54 --> URI Class Initialized
DEBUG - 2018-03-08 00:17:54 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:17:54 --> Utf8 Class Initialized
INFO - 2018-03-08 00:17:54 --> Router Class Initialized
INFO - 2018-03-08 00:17:54 --> URI Class Initialized
INFO - 2018-03-08 00:17:54 --> Router Class Initialized
INFO - 2018-03-08 00:17:54 --> Output Class Initialized
INFO - 2018-03-08 00:17:54 --> Router Class Initialized
INFO - 2018-03-08 00:17:54 --> Output Class Initialized
INFO - 2018-03-08 00:17:54 --> Security Class Initialized
INFO - 2018-03-08 00:17:54 --> Security Class Initialized
INFO - 2018-03-08 00:17:54 --> Output Class Initialized
DEBUG - 2018-03-08 00:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:17:54 --> Security Class Initialized
DEBUG - 2018-03-08 00:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:17:54 --> Input Class Initialized
INFO - 2018-03-08 00:17:54 --> Input Class Initialized
INFO - 2018-03-08 00:17:54 --> Language Class Initialized
INFO - 2018-03-08 00:17:54 --> Language Class Initialized
DEBUG - 2018-03-08 00:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:17:54 --> Input Class Initialized
ERROR - 2018-03-08 00:17:54 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-08 00:17:54 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-08 00:17:54 --> Language Class Initialized
ERROR - 2018-03-08 00:17:54 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-08 00:17:54 --> Config Class Initialized
INFO - 2018-03-08 00:17:54 --> Hooks Class Initialized
DEBUG - 2018-03-08 00:17:54 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:17:54 --> Utf8 Class Initialized
INFO - 2018-03-08 00:17:54 --> URI Class Initialized
INFO - 2018-03-08 00:17:54 --> Router Class Initialized
INFO - 2018-03-08 00:17:54 --> Output Class Initialized
INFO - 2018-03-08 00:17:54 --> Security Class Initialized
DEBUG - 2018-03-08 00:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:17:54 --> Input Class Initialized
INFO - 2018-03-08 00:17:54 --> Language Class Initialized
INFO - 2018-03-08 00:17:54 --> Loader Class Initialized
INFO - 2018-03-08 00:17:54 --> Helper loaded: url_helper
INFO - 2018-03-08 00:17:54 --> Helper loaded: form_helper
INFO - 2018-03-08 00:17:54 --> Database Driver Class Initialized
DEBUG - 2018-03-08 00:17:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-08 00:17:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 00:17:54 --> Form Validation Class Initialized
INFO - 2018-03-08 00:17:54 --> Model Class Initialized
INFO - 2018-03-08 00:17:54 --> Controller Class Initialized
INFO - 2018-03-08 00:17:54 --> Model Class Initialized
INFO - 2018-03-08 00:17:54 --> Model Class Initialized
INFO - 2018-03-08 00:17:54 --> Model Class Initialized
INFO - 2018-03-08 00:17:54 --> Model Class Initialized
INFO - 2018-03-08 00:17:54 --> Model Class Initialized
DEBUG - 2018-03-08 00:17:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-08 00:18:29 --> Config Class Initialized
INFO - 2018-03-08 00:18:29 --> Hooks Class Initialized
DEBUG - 2018-03-08 00:18:29 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:18:29 --> Utf8 Class Initialized
INFO - 2018-03-08 00:18:29 --> URI Class Initialized
INFO - 2018-03-08 00:18:29 --> Router Class Initialized
INFO - 2018-03-08 00:18:29 --> Output Class Initialized
INFO - 2018-03-08 00:18:29 --> Security Class Initialized
DEBUG - 2018-03-08 00:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:18:29 --> Input Class Initialized
INFO - 2018-03-08 00:18:29 --> Language Class Initialized
INFO - 2018-03-08 00:18:29 --> Loader Class Initialized
INFO - 2018-03-08 00:18:29 --> Helper loaded: url_helper
INFO - 2018-03-08 00:18:29 --> Helper loaded: form_helper
INFO - 2018-03-08 00:18:29 --> Database Driver Class Initialized
DEBUG - 2018-03-08 00:18:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-08 00:18:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 00:18:29 --> Form Validation Class Initialized
INFO - 2018-03-08 00:18:29 --> Model Class Initialized
INFO - 2018-03-08 00:18:29 --> Controller Class Initialized
INFO - 2018-03-08 00:18:29 --> Model Class Initialized
INFO - 2018-03-08 00:18:29 --> Model Class Initialized
INFO - 2018-03-08 00:18:29 --> Model Class Initialized
INFO - 2018-03-08 00:18:29 --> Model Class Initialized
INFO - 2018-03-08 00:18:29 --> Model Class Initialized
DEBUG - 2018-03-08 00:18:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-08 00:18:29 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-08 00:18:29 --> Final output sent to browser
DEBUG - 2018-03-08 00:18:29 --> Total execution time: 0.0795
INFO - 2018-03-08 00:18:29 --> Config Class Initialized
INFO - 2018-03-08 00:18:29 --> Hooks Class Initialized
INFO - 2018-03-08 00:18:29 --> Config Class Initialized
INFO - 2018-03-08 00:18:29 --> Hooks Class Initialized
DEBUG - 2018-03-08 00:18:29 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:18:29 --> Utf8 Class Initialized
DEBUG - 2018-03-08 00:18:29 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:18:29 --> Utf8 Class Initialized
INFO - 2018-03-08 00:18:29 --> URI Class Initialized
INFO - 2018-03-08 00:18:29 --> URI Class Initialized
INFO - 2018-03-08 00:18:29 --> Router Class Initialized
INFO - 2018-03-08 00:18:29 --> Router Class Initialized
INFO - 2018-03-08 00:18:29 --> Output Class Initialized
INFO - 2018-03-08 00:18:29 --> Output Class Initialized
INFO - 2018-03-08 00:18:29 --> Security Class Initialized
INFO - 2018-03-08 00:18:29 --> Security Class Initialized
DEBUG - 2018-03-08 00:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:18:29 --> Input Class Initialized
DEBUG - 2018-03-08 00:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:18:29 --> Input Class Initialized
INFO - 2018-03-08 00:18:29 --> Language Class Initialized
INFO - 2018-03-08 00:18:29 --> Language Class Initialized
ERROR - 2018-03-08 00:18:29 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-08 00:18:29 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-08 00:18:29 --> Config Class Initialized
INFO - 2018-03-08 00:18:29 --> Hooks Class Initialized
DEBUG - 2018-03-08 00:18:29 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:18:29 --> Config Class Initialized
INFO - 2018-03-08 00:18:29 --> Utf8 Class Initialized
INFO - 2018-03-08 00:18:29 --> Hooks Class Initialized
INFO - 2018-03-08 00:18:29 --> URI Class Initialized
INFO - 2018-03-08 00:18:29 --> Router Class Initialized
DEBUG - 2018-03-08 00:18:29 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:18:29 --> Utf8 Class Initialized
INFO - 2018-03-08 00:18:29 --> Output Class Initialized
INFO - 2018-03-08 00:18:29 --> URI Class Initialized
INFO - 2018-03-08 00:18:29 --> Security Class Initialized
INFO - 2018-03-08 00:18:29 --> Router Class Initialized
DEBUG - 2018-03-08 00:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:18:29 --> Input Class Initialized
INFO - 2018-03-08 00:18:29 --> Language Class Initialized
INFO - 2018-03-08 00:18:29 --> Output Class Initialized
INFO - 2018-03-08 00:18:29 --> Security Class Initialized
ERROR - 2018-03-08 00:18:29 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-08 00:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:18:30 --> Input Class Initialized
INFO - 2018-03-08 00:18:30 --> Language Class Initialized
ERROR - 2018-03-08 00:18:30 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-08 00:18:30 --> Config Class Initialized
INFO - 2018-03-08 00:18:30 --> Config Class Initialized
INFO - 2018-03-08 00:18:30 --> Hooks Class Initialized
INFO - 2018-03-08 00:18:30 --> Hooks Class Initialized
INFO - 2018-03-08 00:18:30 --> Config Class Initialized
INFO - 2018-03-08 00:18:30 --> Hooks Class Initialized
DEBUG - 2018-03-08 00:18:30 --> UTF-8 Support Enabled
DEBUG - 2018-03-08 00:18:30 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:18:30 --> Utf8 Class Initialized
INFO - 2018-03-08 00:18:30 --> Utf8 Class Initialized
DEBUG - 2018-03-08 00:18:30 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:18:30 --> Utf8 Class Initialized
INFO - 2018-03-08 00:18:30 --> URI Class Initialized
INFO - 2018-03-08 00:18:30 --> URI Class Initialized
INFO - 2018-03-08 00:18:30 --> URI Class Initialized
INFO - 2018-03-08 00:18:30 --> Router Class Initialized
INFO - 2018-03-08 00:18:30 --> Router Class Initialized
INFO - 2018-03-08 00:18:30 --> Router Class Initialized
INFO - 2018-03-08 00:18:30 --> Output Class Initialized
INFO - 2018-03-08 00:18:30 --> Output Class Initialized
INFO - 2018-03-08 00:18:30 --> Output Class Initialized
INFO - 2018-03-08 00:18:30 --> Security Class Initialized
INFO - 2018-03-08 00:18:30 --> Security Class Initialized
INFO - 2018-03-08 00:18:30 --> Security Class Initialized
DEBUG - 2018-03-08 00:18:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-08 00:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:18:30 --> Input Class Initialized
INFO - 2018-03-08 00:18:30 --> Input Class Initialized
DEBUG - 2018-03-08 00:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:18:30 --> Language Class Initialized
INFO - 2018-03-08 00:18:30 --> Language Class Initialized
INFO - 2018-03-08 00:18:30 --> Input Class Initialized
INFO - 2018-03-08 00:18:30 --> Language Class Initialized
ERROR - 2018-03-08 00:18:30 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-08 00:18:30 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-08 00:18:30 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-08 00:18:30 --> Config Class Initialized
INFO - 2018-03-08 00:18:30 --> Hooks Class Initialized
DEBUG - 2018-03-08 00:18:30 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:18:30 --> Utf8 Class Initialized
INFO - 2018-03-08 00:18:30 --> URI Class Initialized
INFO - 2018-03-08 00:18:30 --> Router Class Initialized
INFO - 2018-03-08 00:18:30 --> Output Class Initialized
INFO - 2018-03-08 00:18:30 --> Security Class Initialized
DEBUG - 2018-03-08 00:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:18:30 --> Input Class Initialized
INFO - 2018-03-08 00:18:30 --> Language Class Initialized
INFO - 2018-03-08 00:18:30 --> Loader Class Initialized
INFO - 2018-03-08 00:18:30 --> Helper loaded: url_helper
INFO - 2018-03-08 00:18:30 --> Helper loaded: form_helper
INFO - 2018-03-08 00:18:30 --> Database Driver Class Initialized
DEBUG - 2018-03-08 00:18:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-08 00:18:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 00:18:30 --> Form Validation Class Initialized
INFO - 2018-03-08 00:18:30 --> Model Class Initialized
INFO - 2018-03-08 00:18:30 --> Controller Class Initialized
INFO - 2018-03-08 00:18:30 --> Model Class Initialized
INFO - 2018-03-08 00:18:30 --> Model Class Initialized
INFO - 2018-03-08 00:18:30 --> Model Class Initialized
INFO - 2018-03-08 00:18:30 --> Model Class Initialized
INFO - 2018-03-08 00:18:30 --> Model Class Initialized
DEBUG - 2018-03-08 00:18:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-08 00:18:39 --> Config Class Initialized
INFO - 2018-03-08 00:18:39 --> Hooks Class Initialized
DEBUG - 2018-03-08 00:18:39 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:18:39 --> Utf8 Class Initialized
INFO - 2018-03-08 00:18:39 --> URI Class Initialized
INFO - 2018-03-08 00:18:39 --> Router Class Initialized
INFO - 2018-03-08 00:18:39 --> Output Class Initialized
INFO - 2018-03-08 00:18:39 --> Security Class Initialized
DEBUG - 2018-03-08 00:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:18:39 --> Input Class Initialized
INFO - 2018-03-08 00:18:39 --> Language Class Initialized
INFO - 2018-03-08 00:18:39 --> Loader Class Initialized
INFO - 2018-03-08 00:18:39 --> Helper loaded: url_helper
INFO - 2018-03-08 00:18:39 --> Helper loaded: form_helper
INFO - 2018-03-08 00:18:39 --> Database Driver Class Initialized
DEBUG - 2018-03-08 00:18:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-08 00:18:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 00:18:39 --> Form Validation Class Initialized
INFO - 2018-03-08 00:18:39 --> Model Class Initialized
INFO - 2018-03-08 00:18:39 --> Controller Class Initialized
INFO - 2018-03-08 00:18:39 --> Model Class Initialized
INFO - 2018-03-08 00:18:39 --> Model Class Initialized
INFO - 2018-03-08 00:18:39 --> Model Class Initialized
INFO - 2018-03-08 00:18:39 --> Model Class Initialized
INFO - 2018-03-08 00:18:39 --> Model Class Initialized
DEBUG - 2018-03-08 00:18:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-08 00:18:39 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-08 00:18:39 --> Final output sent to browser
DEBUG - 2018-03-08 00:18:39 --> Total execution time: 0.0493
INFO - 2018-03-08 00:18:39 --> Config Class Initialized
INFO - 2018-03-08 00:18:39 --> Hooks Class Initialized
INFO - 2018-03-08 00:18:39 --> Config Class Initialized
INFO - 2018-03-08 00:18:39 --> Hooks Class Initialized
DEBUG - 2018-03-08 00:18:39 --> UTF-8 Support Enabled
DEBUG - 2018-03-08 00:18:39 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:18:39 --> Utf8 Class Initialized
INFO - 2018-03-08 00:18:39 --> Utf8 Class Initialized
INFO - 2018-03-08 00:18:39 --> Config Class Initialized
INFO - 2018-03-08 00:18:39 --> Hooks Class Initialized
INFO - 2018-03-08 00:18:39 --> URI Class Initialized
INFO - 2018-03-08 00:18:39 --> URI Class Initialized
INFO - 2018-03-08 00:18:39 --> Config Class Initialized
INFO - 2018-03-08 00:18:39 --> Hooks Class Initialized
INFO - 2018-03-08 00:18:39 --> Router Class Initialized
INFO - 2018-03-08 00:18:39 --> Router Class Initialized
DEBUG - 2018-03-08 00:18:39 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:18:39 --> Utf8 Class Initialized
DEBUG - 2018-03-08 00:18:39 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:18:39 --> Utf8 Class Initialized
INFO - 2018-03-08 00:18:39 --> URI Class Initialized
INFO - 2018-03-08 00:18:39 --> Output Class Initialized
INFO - 2018-03-08 00:18:39 --> Output Class Initialized
INFO - 2018-03-08 00:18:39 --> URI Class Initialized
INFO - 2018-03-08 00:18:39 --> Security Class Initialized
INFO - 2018-03-08 00:18:39 --> Router Class Initialized
INFO - 2018-03-08 00:18:39 --> Security Class Initialized
INFO - 2018-03-08 00:18:39 --> Router Class Initialized
DEBUG - 2018-03-08 00:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:18:39 --> Input Class Initialized
DEBUG - 2018-03-08 00:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:18:39 --> Input Class Initialized
INFO - 2018-03-08 00:18:39 --> Output Class Initialized
INFO - 2018-03-08 00:18:39 --> Language Class Initialized
INFO - 2018-03-08 00:18:39 --> Output Class Initialized
INFO - 2018-03-08 00:18:39 --> Language Class Initialized
INFO - 2018-03-08 00:18:39 --> Security Class Initialized
ERROR - 2018-03-08 00:18:39 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-08 00:18:39 --> Security Class Initialized
ERROR - 2018-03-08 00:18:39 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-08 00:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:18:39 --> Input Class Initialized
DEBUG - 2018-03-08 00:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:18:39 --> Input Class Initialized
INFO - 2018-03-08 00:18:39 --> Language Class Initialized
INFO - 2018-03-08 00:18:39 --> Language Class Initialized
ERROR - 2018-03-08 00:18:39 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-08 00:18:39 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-08 00:18:39 --> Config Class Initialized
INFO - 2018-03-08 00:18:39 --> Hooks Class Initialized
INFO - 2018-03-08 00:18:39 --> Config Class Initialized
INFO - 2018-03-08 00:18:39 --> Hooks Class Initialized
INFO - 2018-03-08 00:18:39 --> Config Class Initialized
INFO - 2018-03-08 00:18:39 --> Hooks Class Initialized
DEBUG - 2018-03-08 00:18:39 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:18:39 --> Utf8 Class Initialized
DEBUG - 2018-03-08 00:18:39 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:18:39 --> URI Class Initialized
INFO - 2018-03-08 00:18:39 --> Utf8 Class Initialized
DEBUG - 2018-03-08 00:18:39 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:18:39 --> Utf8 Class Initialized
INFO - 2018-03-08 00:18:39 --> URI Class Initialized
INFO - 2018-03-08 00:18:39 --> Router Class Initialized
INFO - 2018-03-08 00:18:39 --> URI Class Initialized
INFO - 2018-03-08 00:18:39 --> Router Class Initialized
INFO - 2018-03-08 00:18:39 --> Router Class Initialized
INFO - 2018-03-08 00:18:39 --> Output Class Initialized
INFO - 2018-03-08 00:18:39 --> Security Class Initialized
INFO - 2018-03-08 00:18:39 --> Output Class Initialized
INFO - 2018-03-08 00:18:39 --> Output Class Initialized
DEBUG - 2018-03-08 00:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:18:39 --> Input Class Initialized
INFO - 2018-03-08 00:18:39 --> Security Class Initialized
INFO - 2018-03-08 00:18:39 --> Security Class Initialized
INFO - 2018-03-08 00:18:39 --> Language Class Initialized
DEBUG - 2018-03-08 00:18:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-08 00:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:18:39 --> Input Class Initialized
INFO - 2018-03-08 00:18:39 --> Input Class Initialized
ERROR - 2018-03-08 00:18:39 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-08 00:18:39 --> Language Class Initialized
INFO - 2018-03-08 00:18:39 --> Language Class Initialized
ERROR - 2018-03-08 00:18:39 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-08 00:18:39 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-08 00:18:39 --> Config Class Initialized
INFO - 2018-03-08 00:18:39 --> Hooks Class Initialized
DEBUG - 2018-03-08 00:18:39 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:18:39 --> Utf8 Class Initialized
INFO - 2018-03-08 00:18:39 --> URI Class Initialized
INFO - 2018-03-08 00:18:39 --> Router Class Initialized
INFO - 2018-03-08 00:18:39 --> Output Class Initialized
INFO - 2018-03-08 00:18:39 --> Security Class Initialized
DEBUG - 2018-03-08 00:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:18:39 --> Input Class Initialized
INFO - 2018-03-08 00:18:39 --> Language Class Initialized
INFO - 2018-03-08 00:18:39 --> Loader Class Initialized
INFO - 2018-03-08 00:18:39 --> Helper loaded: url_helper
INFO - 2018-03-08 00:18:39 --> Helper loaded: form_helper
INFO - 2018-03-08 00:18:39 --> Database Driver Class Initialized
DEBUG - 2018-03-08 00:18:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-08 00:18:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 00:18:39 --> Form Validation Class Initialized
INFO - 2018-03-08 00:18:39 --> Model Class Initialized
INFO - 2018-03-08 00:18:39 --> Controller Class Initialized
INFO - 2018-03-08 00:18:39 --> Model Class Initialized
INFO - 2018-03-08 00:18:39 --> Model Class Initialized
INFO - 2018-03-08 00:18:39 --> Model Class Initialized
INFO - 2018-03-08 00:18:39 --> Model Class Initialized
INFO - 2018-03-08 00:18:39 --> Model Class Initialized
DEBUG - 2018-03-08 00:18:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-08 00:19:06 --> Config Class Initialized
INFO - 2018-03-08 00:19:06 --> Hooks Class Initialized
DEBUG - 2018-03-08 00:19:06 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:19:06 --> Utf8 Class Initialized
INFO - 2018-03-08 00:19:06 --> URI Class Initialized
INFO - 2018-03-08 00:19:06 --> Router Class Initialized
INFO - 2018-03-08 00:19:06 --> Output Class Initialized
INFO - 2018-03-08 00:19:06 --> Security Class Initialized
DEBUG - 2018-03-08 00:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:19:06 --> Input Class Initialized
INFO - 2018-03-08 00:19:06 --> Language Class Initialized
INFO - 2018-03-08 00:19:06 --> Loader Class Initialized
INFO - 2018-03-08 00:19:06 --> Helper loaded: url_helper
INFO - 2018-03-08 00:19:06 --> Helper loaded: form_helper
INFO - 2018-03-08 00:19:06 --> Database Driver Class Initialized
DEBUG - 2018-03-08 00:19:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-08 00:19:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 00:19:06 --> Form Validation Class Initialized
INFO - 2018-03-08 00:19:06 --> Model Class Initialized
INFO - 2018-03-08 00:19:06 --> Controller Class Initialized
INFO - 2018-03-08 00:19:06 --> Model Class Initialized
INFO - 2018-03-08 00:19:06 --> Model Class Initialized
INFO - 2018-03-08 00:19:06 --> Model Class Initialized
INFO - 2018-03-08 00:19:06 --> Model Class Initialized
INFO - 2018-03-08 00:19:06 --> Model Class Initialized
DEBUG - 2018-03-08 00:19:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-08 00:19:06 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-08 00:19:06 --> Final output sent to browser
DEBUG - 2018-03-08 00:19:06 --> Total execution time: 0.0572
INFO - 2018-03-08 00:19:06 --> Config Class Initialized
INFO - 2018-03-08 00:19:06 --> Config Class Initialized
INFO - 2018-03-08 00:19:06 --> Hooks Class Initialized
INFO - 2018-03-08 00:19:06 --> Hooks Class Initialized
INFO - 2018-03-08 00:19:06 --> Config Class Initialized
INFO - 2018-03-08 00:19:06 --> Hooks Class Initialized
DEBUG - 2018-03-08 00:19:06 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:19:06 --> Utf8 Class Initialized
DEBUG - 2018-03-08 00:19:06 --> UTF-8 Support Enabled
DEBUG - 2018-03-08 00:19:06 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:19:06 --> Utf8 Class Initialized
INFO - 2018-03-08 00:19:06 --> Utf8 Class Initialized
INFO - 2018-03-08 00:19:06 --> URI Class Initialized
INFO - 2018-03-08 00:19:06 --> URI Class Initialized
INFO - 2018-03-08 00:19:06 --> URI Class Initialized
INFO - 2018-03-08 00:19:06 --> Router Class Initialized
INFO - 2018-03-08 00:19:06 --> Router Class Initialized
INFO - 2018-03-08 00:19:06 --> Router Class Initialized
INFO - 2018-03-08 00:19:06 --> Output Class Initialized
INFO - 2018-03-08 00:19:06 --> Output Class Initialized
INFO - 2018-03-08 00:19:06 --> Output Class Initialized
INFO - 2018-03-08 00:19:06 --> Security Class Initialized
INFO - 2018-03-08 00:19:06 --> Security Class Initialized
INFO - 2018-03-08 00:19:06 --> Security Class Initialized
DEBUG - 2018-03-08 00:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:19:06 --> Input Class Initialized
DEBUG - 2018-03-08 00:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:19:06 --> Input Class Initialized
DEBUG - 2018-03-08 00:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:19:06 --> Language Class Initialized
INFO - 2018-03-08 00:19:06 --> Input Class Initialized
INFO - 2018-03-08 00:19:06 --> Language Class Initialized
INFO - 2018-03-08 00:19:06 --> Language Class Initialized
ERROR - 2018-03-08 00:19:06 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-08 00:19:06 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-08 00:19:06 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-08 00:19:06 --> Config Class Initialized
INFO - 2018-03-08 00:19:06 --> Hooks Class Initialized
DEBUG - 2018-03-08 00:19:06 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:19:06 --> Utf8 Class Initialized
INFO - 2018-03-08 00:19:06 --> URI Class Initialized
INFO - 2018-03-08 00:19:06 --> Router Class Initialized
INFO - 2018-03-08 00:19:06 --> Output Class Initialized
INFO - 2018-03-08 00:19:06 --> Security Class Initialized
DEBUG - 2018-03-08 00:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:19:06 --> Input Class Initialized
INFO - 2018-03-08 00:19:06 --> Language Class Initialized
ERROR - 2018-03-08 00:19:06 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-08 00:19:06 --> Config Class Initialized
INFO - 2018-03-08 00:19:06 --> Hooks Class Initialized
INFO - 2018-03-08 00:19:06 --> Config Class Initialized
INFO - 2018-03-08 00:19:06 --> Hooks Class Initialized
INFO - 2018-03-08 00:19:06 --> Config Class Initialized
INFO - 2018-03-08 00:19:06 --> Hooks Class Initialized
DEBUG - 2018-03-08 00:19:06 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:19:06 --> Utf8 Class Initialized
DEBUG - 2018-03-08 00:19:06 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:19:06 --> URI Class Initialized
INFO - 2018-03-08 00:19:06 --> Utf8 Class Initialized
DEBUG - 2018-03-08 00:19:06 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:19:06 --> Utf8 Class Initialized
INFO - 2018-03-08 00:19:06 --> URI Class Initialized
INFO - 2018-03-08 00:19:06 --> URI Class Initialized
INFO - 2018-03-08 00:19:06 --> Router Class Initialized
INFO - 2018-03-08 00:19:06 --> Router Class Initialized
INFO - 2018-03-08 00:19:06 --> Router Class Initialized
INFO - 2018-03-08 00:19:06 --> Output Class Initialized
INFO - 2018-03-08 00:19:06 --> Security Class Initialized
INFO - 2018-03-08 00:19:06 --> Output Class Initialized
INFO - 2018-03-08 00:19:06 --> Output Class Initialized
DEBUG - 2018-03-08 00:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:19:06 --> Input Class Initialized
INFO - 2018-03-08 00:19:06 --> Security Class Initialized
INFO - 2018-03-08 00:19:06 --> Security Class Initialized
INFO - 2018-03-08 00:19:06 --> Language Class Initialized
DEBUG - 2018-03-08 00:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:19:06 --> Input Class Initialized
ERROR - 2018-03-08 00:19:06 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-03-08 00:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:19:06 --> Input Class Initialized
INFO - 2018-03-08 00:19:06 --> Language Class Initialized
INFO - 2018-03-08 00:19:06 --> Language Class Initialized
ERROR - 2018-03-08 00:19:06 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-08 00:19:06 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-08 00:19:06 --> Config Class Initialized
INFO - 2018-03-08 00:19:06 --> Hooks Class Initialized
DEBUG - 2018-03-08 00:19:06 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:19:06 --> Utf8 Class Initialized
INFO - 2018-03-08 00:19:06 --> URI Class Initialized
INFO - 2018-03-08 00:19:06 --> Router Class Initialized
INFO - 2018-03-08 00:19:06 --> Output Class Initialized
INFO - 2018-03-08 00:19:06 --> Security Class Initialized
DEBUG - 2018-03-08 00:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:19:06 --> Input Class Initialized
INFO - 2018-03-08 00:19:06 --> Language Class Initialized
INFO - 2018-03-08 00:19:06 --> Loader Class Initialized
INFO - 2018-03-08 00:19:06 --> Helper loaded: url_helper
INFO - 2018-03-08 00:19:06 --> Helper loaded: form_helper
INFO - 2018-03-08 00:19:06 --> Database Driver Class Initialized
DEBUG - 2018-03-08 00:19:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-08 00:19:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 00:19:06 --> Form Validation Class Initialized
INFO - 2018-03-08 00:19:06 --> Model Class Initialized
INFO - 2018-03-08 00:19:06 --> Controller Class Initialized
INFO - 2018-03-08 00:19:06 --> Model Class Initialized
INFO - 2018-03-08 00:19:06 --> Model Class Initialized
INFO - 2018-03-08 00:19:06 --> Model Class Initialized
INFO - 2018-03-08 00:19:06 --> Model Class Initialized
INFO - 2018-03-08 00:19:06 --> Model Class Initialized
DEBUG - 2018-03-08 00:19:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-08 00:19:45 --> Config Class Initialized
INFO - 2018-03-08 00:19:45 --> Hooks Class Initialized
DEBUG - 2018-03-08 00:19:45 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:19:45 --> Utf8 Class Initialized
INFO - 2018-03-08 00:19:45 --> URI Class Initialized
INFO - 2018-03-08 00:19:45 --> Router Class Initialized
INFO - 2018-03-08 00:19:45 --> Output Class Initialized
INFO - 2018-03-08 00:19:45 --> Security Class Initialized
DEBUG - 2018-03-08 00:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:19:45 --> Input Class Initialized
INFO - 2018-03-08 00:19:45 --> Language Class Initialized
INFO - 2018-03-08 00:19:45 --> Loader Class Initialized
INFO - 2018-03-08 00:19:45 --> Helper loaded: url_helper
INFO - 2018-03-08 00:19:45 --> Helper loaded: form_helper
INFO - 2018-03-08 00:19:45 --> Database Driver Class Initialized
DEBUG - 2018-03-08 00:19:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-08 00:19:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 00:19:45 --> Form Validation Class Initialized
INFO - 2018-03-08 00:19:45 --> Model Class Initialized
INFO - 2018-03-08 00:19:45 --> Controller Class Initialized
INFO - 2018-03-08 00:19:45 --> Model Class Initialized
INFO - 2018-03-08 00:19:45 --> Model Class Initialized
INFO - 2018-03-08 00:19:45 --> Model Class Initialized
INFO - 2018-03-08 00:19:45 --> Model Class Initialized
INFO - 2018-03-08 00:19:45 --> Model Class Initialized
DEBUG - 2018-03-08 00:19:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-08 00:19:45 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-08 00:19:45 --> Final output sent to browser
DEBUG - 2018-03-08 00:19:45 --> Total execution time: 0.0679
INFO - 2018-03-08 00:19:45 --> Config Class Initialized
INFO - 2018-03-08 00:19:45 --> Hooks Class Initialized
INFO - 2018-03-08 00:19:45 --> Config Class Initialized
INFO - 2018-03-08 00:19:45 --> Hooks Class Initialized
INFO - 2018-03-08 00:19:45 --> Config Class Initialized
INFO - 2018-03-08 00:19:45 --> Hooks Class Initialized
DEBUG - 2018-03-08 00:19:45 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:19:45 --> Utf8 Class Initialized
DEBUG - 2018-03-08 00:19:45 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:19:45 --> Utf8 Class Initialized
DEBUG - 2018-03-08 00:19:45 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:19:45 --> URI Class Initialized
INFO - 2018-03-08 00:19:45 --> Utf8 Class Initialized
INFO - 2018-03-08 00:19:45 --> URI Class Initialized
INFO - 2018-03-08 00:19:45 --> Config Class Initialized
INFO - 2018-03-08 00:19:45 --> Hooks Class Initialized
INFO - 2018-03-08 00:19:45 --> URI Class Initialized
INFO - 2018-03-08 00:19:45 --> Router Class Initialized
INFO - 2018-03-08 00:19:45 --> Router Class Initialized
DEBUG - 2018-03-08 00:19:45 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:19:45 --> Router Class Initialized
INFO - 2018-03-08 00:19:45 --> Output Class Initialized
INFO - 2018-03-08 00:19:45 --> Utf8 Class Initialized
INFO - 2018-03-08 00:19:45 --> Output Class Initialized
INFO - 2018-03-08 00:19:45 --> Security Class Initialized
INFO - 2018-03-08 00:19:45 --> URI Class Initialized
INFO - 2018-03-08 00:19:45 --> Output Class Initialized
INFO - 2018-03-08 00:19:45 --> Security Class Initialized
DEBUG - 2018-03-08 00:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:19:45 --> Input Class Initialized
DEBUG - 2018-03-08 00:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:19:45 --> Security Class Initialized
INFO - 2018-03-08 00:19:45 --> Input Class Initialized
INFO - 2018-03-08 00:19:45 --> Router Class Initialized
INFO - 2018-03-08 00:19:45 --> Language Class Initialized
INFO - 2018-03-08 00:19:45 --> Language Class Initialized
DEBUG - 2018-03-08 00:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:19:45 --> Input Class Initialized
ERROR - 2018-03-08 00:19:45 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-08 00:19:45 --> Output Class Initialized
ERROR - 2018-03-08 00:19:45 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-08 00:19:45 --> Language Class Initialized
INFO - 2018-03-08 00:19:45 --> Security Class Initialized
ERROR - 2018-03-08 00:19:45 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-08 00:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:19:45 --> Input Class Initialized
INFO - 2018-03-08 00:19:45 --> Language Class Initialized
ERROR - 2018-03-08 00:19:45 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-08 00:19:45 --> Config Class Initialized
INFO - 2018-03-08 00:19:45 --> Hooks Class Initialized
INFO - 2018-03-08 00:19:45 --> Config Class Initialized
INFO - 2018-03-08 00:19:45 --> Config Class Initialized
INFO - 2018-03-08 00:19:45 --> Hooks Class Initialized
INFO - 2018-03-08 00:19:45 --> Hooks Class Initialized
DEBUG - 2018-03-08 00:19:45 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:19:45 --> Utf8 Class Initialized
DEBUG - 2018-03-08 00:19:45 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:19:45 --> URI Class Initialized
DEBUG - 2018-03-08 00:19:45 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:19:45 --> Utf8 Class Initialized
INFO - 2018-03-08 00:19:45 --> Utf8 Class Initialized
INFO - 2018-03-08 00:19:45 --> URI Class Initialized
INFO - 2018-03-08 00:19:45 --> URI Class Initialized
INFO - 2018-03-08 00:19:45 --> Router Class Initialized
INFO - 2018-03-08 00:19:45 --> Router Class Initialized
INFO - 2018-03-08 00:19:45 --> Router Class Initialized
INFO - 2018-03-08 00:19:45 --> Output Class Initialized
INFO - 2018-03-08 00:19:45 --> Security Class Initialized
INFO - 2018-03-08 00:19:45 --> Output Class Initialized
INFO - 2018-03-08 00:19:45 --> Output Class Initialized
DEBUG - 2018-03-08 00:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:19:45 --> Input Class Initialized
INFO - 2018-03-08 00:19:45 --> Security Class Initialized
INFO - 2018-03-08 00:19:45 --> Security Class Initialized
INFO - 2018-03-08 00:19:45 --> Language Class Initialized
DEBUG - 2018-03-08 00:19:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-08 00:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:19:45 --> Input Class Initialized
ERROR - 2018-03-08 00:19:45 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-08 00:19:45 --> Input Class Initialized
INFO - 2018-03-08 00:19:45 --> Language Class Initialized
INFO - 2018-03-08 00:19:45 --> Language Class Initialized
ERROR - 2018-03-08 00:19:45 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-08 00:19:45 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-08 00:19:45 --> Config Class Initialized
INFO - 2018-03-08 00:19:45 --> Hooks Class Initialized
DEBUG - 2018-03-08 00:19:45 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:19:45 --> Utf8 Class Initialized
INFO - 2018-03-08 00:19:45 --> URI Class Initialized
INFO - 2018-03-08 00:19:45 --> Router Class Initialized
INFO - 2018-03-08 00:19:45 --> Output Class Initialized
INFO - 2018-03-08 00:19:45 --> Security Class Initialized
DEBUG - 2018-03-08 00:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:19:45 --> Input Class Initialized
INFO - 2018-03-08 00:19:45 --> Language Class Initialized
INFO - 2018-03-08 00:19:45 --> Loader Class Initialized
INFO - 2018-03-08 00:19:45 --> Helper loaded: url_helper
INFO - 2018-03-08 00:19:45 --> Helper loaded: form_helper
INFO - 2018-03-08 00:19:45 --> Database Driver Class Initialized
DEBUG - 2018-03-08 00:19:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-08 00:19:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 00:19:45 --> Form Validation Class Initialized
INFO - 2018-03-08 00:19:45 --> Model Class Initialized
INFO - 2018-03-08 00:19:45 --> Controller Class Initialized
INFO - 2018-03-08 00:19:45 --> Model Class Initialized
INFO - 2018-03-08 00:19:45 --> Model Class Initialized
INFO - 2018-03-08 00:19:45 --> Model Class Initialized
INFO - 2018-03-08 00:19:45 --> Model Class Initialized
INFO - 2018-03-08 00:19:45 --> Model Class Initialized
DEBUG - 2018-03-08 00:19:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-08 00:19:46 --> Config Class Initialized
INFO - 2018-03-08 00:19:46 --> Hooks Class Initialized
DEBUG - 2018-03-08 00:19:46 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:19:46 --> Utf8 Class Initialized
INFO - 2018-03-08 00:19:46 --> URI Class Initialized
INFO - 2018-03-08 00:19:46 --> Router Class Initialized
INFO - 2018-03-08 00:19:46 --> Output Class Initialized
INFO - 2018-03-08 00:19:46 --> Security Class Initialized
DEBUG - 2018-03-08 00:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:19:46 --> Input Class Initialized
INFO - 2018-03-08 00:19:46 --> Language Class Initialized
INFO - 2018-03-08 00:19:46 --> Loader Class Initialized
INFO - 2018-03-08 00:19:46 --> Helper loaded: url_helper
INFO - 2018-03-08 00:19:46 --> Helper loaded: form_helper
INFO - 2018-03-08 00:19:46 --> Database Driver Class Initialized
DEBUG - 2018-03-08 00:19:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-08 00:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 00:19:46 --> Form Validation Class Initialized
INFO - 2018-03-08 00:19:46 --> Model Class Initialized
INFO - 2018-03-08 00:19:46 --> Controller Class Initialized
INFO - 2018-03-08 00:19:46 --> Model Class Initialized
INFO - 2018-03-08 00:19:46 --> Model Class Initialized
INFO - 2018-03-08 00:19:46 --> Model Class Initialized
INFO - 2018-03-08 00:19:46 --> Model Class Initialized
INFO - 2018-03-08 00:19:46 --> Model Class Initialized
DEBUG - 2018-03-08 00:19:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-08 00:19:46 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-08 00:19:46 --> Final output sent to browser
DEBUG - 2018-03-08 00:19:46 --> Total execution time: 0.0613
INFO - 2018-03-08 00:19:46 --> Config Class Initialized
INFO - 2018-03-08 00:19:46 --> Config Class Initialized
INFO - 2018-03-08 00:19:46 --> Hooks Class Initialized
INFO - 2018-03-08 00:19:46 --> Hooks Class Initialized
INFO - 2018-03-08 00:19:46 --> Config Class Initialized
INFO - 2018-03-08 00:19:46 --> Hooks Class Initialized
INFO - 2018-03-08 00:19:46 --> Config Class Initialized
INFO - 2018-03-08 00:19:46 --> Hooks Class Initialized
DEBUG - 2018-03-08 00:19:46 --> UTF-8 Support Enabled
DEBUG - 2018-03-08 00:19:46 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:19:46 --> Utf8 Class Initialized
DEBUG - 2018-03-08 00:19:46 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:19:46 --> Utf8 Class Initialized
INFO - 2018-03-08 00:19:46 --> Utf8 Class Initialized
INFO - 2018-03-08 00:19:46 --> URI Class Initialized
DEBUG - 2018-03-08 00:19:46 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:19:46 --> URI Class Initialized
INFO - 2018-03-08 00:19:46 --> URI Class Initialized
INFO - 2018-03-08 00:19:46 --> Utf8 Class Initialized
INFO - 2018-03-08 00:19:46 --> URI Class Initialized
INFO - 2018-03-08 00:19:46 --> Router Class Initialized
INFO - 2018-03-08 00:19:46 --> Router Class Initialized
INFO - 2018-03-08 00:19:46 --> Router Class Initialized
INFO - 2018-03-08 00:19:46 --> Router Class Initialized
INFO - 2018-03-08 00:19:46 --> Output Class Initialized
INFO - 2018-03-08 00:19:46 --> Output Class Initialized
INFO - 2018-03-08 00:19:46 --> Output Class Initialized
INFO - 2018-03-08 00:19:46 --> Output Class Initialized
INFO - 2018-03-08 00:19:46 --> Security Class Initialized
INFO - 2018-03-08 00:19:46 --> Security Class Initialized
INFO - 2018-03-08 00:19:46 --> Security Class Initialized
INFO - 2018-03-08 00:19:46 --> Security Class Initialized
DEBUG - 2018-03-08 00:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:19:46 --> Input Class Initialized
DEBUG - 2018-03-08 00:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:19:46 --> Input Class Initialized
DEBUG - 2018-03-08 00:19:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-08 00:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:19:46 --> Language Class Initialized
INFO - 2018-03-08 00:19:46 --> Input Class Initialized
INFO - 2018-03-08 00:19:46 --> Input Class Initialized
INFO - 2018-03-08 00:19:46 --> Language Class Initialized
INFO - 2018-03-08 00:19:46 --> Language Class Initialized
INFO - 2018-03-08 00:19:46 --> Language Class Initialized
ERROR - 2018-03-08 00:19:46 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-08 00:19:46 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-08 00:19:46 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-08 00:19:46 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-08 00:19:46 --> Config Class Initialized
INFO - 2018-03-08 00:19:46 --> Hooks Class Initialized
INFO - 2018-03-08 00:19:46 --> Config Class Initialized
INFO - 2018-03-08 00:19:46 --> Hooks Class Initialized
DEBUG - 2018-03-08 00:19:46 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:19:46 --> Config Class Initialized
INFO - 2018-03-08 00:19:46 --> Utf8 Class Initialized
INFO - 2018-03-08 00:19:46 --> Hooks Class Initialized
INFO - 2018-03-08 00:19:46 --> URI Class Initialized
DEBUG - 2018-03-08 00:19:46 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:19:46 --> Utf8 Class Initialized
INFO - 2018-03-08 00:19:46 --> Router Class Initialized
DEBUG - 2018-03-08 00:19:46 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:19:46 --> Utf8 Class Initialized
INFO - 2018-03-08 00:19:46 --> URI Class Initialized
INFO - 2018-03-08 00:19:46 --> URI Class Initialized
INFO - 2018-03-08 00:19:46 --> Output Class Initialized
INFO - 2018-03-08 00:19:46 --> Router Class Initialized
INFO - 2018-03-08 00:19:46 --> Router Class Initialized
INFO - 2018-03-08 00:19:46 --> Security Class Initialized
INFO - 2018-03-08 00:19:46 --> Output Class Initialized
DEBUG - 2018-03-08 00:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:19:46 --> Output Class Initialized
INFO - 2018-03-08 00:19:46 --> Input Class Initialized
INFO - 2018-03-08 00:19:46 --> Security Class Initialized
INFO - 2018-03-08 00:19:46 --> Language Class Initialized
INFO - 2018-03-08 00:19:46 --> Security Class Initialized
DEBUG - 2018-03-08 00:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:19:46 --> Input Class Initialized
ERROR - 2018-03-08 00:19:46 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-03-08 00:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:19:46 --> Language Class Initialized
INFO - 2018-03-08 00:19:46 --> Input Class Initialized
INFO - 2018-03-08 00:19:46 --> Language Class Initialized
ERROR - 2018-03-08 00:19:46 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-08 00:19:46 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-08 00:19:46 --> Config Class Initialized
INFO - 2018-03-08 00:19:46 --> Hooks Class Initialized
DEBUG - 2018-03-08 00:19:46 --> UTF-8 Support Enabled
INFO - 2018-03-08 00:19:46 --> Utf8 Class Initialized
INFO - 2018-03-08 00:19:46 --> URI Class Initialized
INFO - 2018-03-08 00:19:46 --> Router Class Initialized
INFO - 2018-03-08 00:19:46 --> Output Class Initialized
INFO - 2018-03-08 00:19:46 --> Security Class Initialized
DEBUG - 2018-03-08 00:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 00:19:46 --> Input Class Initialized
INFO - 2018-03-08 00:19:46 --> Language Class Initialized
INFO - 2018-03-08 00:19:46 --> Loader Class Initialized
INFO - 2018-03-08 00:19:46 --> Helper loaded: url_helper
INFO - 2018-03-08 00:19:46 --> Helper loaded: form_helper
INFO - 2018-03-08 00:19:46 --> Database Driver Class Initialized
DEBUG - 2018-03-08 00:19:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-08 00:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 00:19:46 --> Form Validation Class Initialized
INFO - 2018-03-08 00:19:46 --> Model Class Initialized
INFO - 2018-03-08 00:19:46 --> Controller Class Initialized
INFO - 2018-03-08 00:19:46 --> Model Class Initialized
INFO - 2018-03-08 00:19:46 --> Model Class Initialized
INFO - 2018-03-08 00:19:46 --> Model Class Initialized
INFO - 2018-03-08 00:19:46 --> Model Class Initialized
INFO - 2018-03-08 00:19:46 --> Model Class Initialized
DEBUG - 2018-03-08 00:19:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-08 23:41:15 --> Config Class Initialized
INFO - 2018-03-08 23:41:15 --> Hooks Class Initialized
DEBUG - 2018-03-08 23:41:15 --> UTF-8 Support Enabled
INFO - 2018-03-08 23:41:15 --> Utf8 Class Initialized
INFO - 2018-03-08 23:41:15 --> URI Class Initialized
INFO - 2018-03-08 23:41:15 --> Router Class Initialized
INFO - 2018-03-08 23:41:15 --> Output Class Initialized
INFO - 2018-03-08 23:41:15 --> Security Class Initialized
DEBUG - 2018-03-08 23:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 23:41:15 --> Input Class Initialized
INFO - 2018-03-08 23:41:15 --> Language Class Initialized
INFO - 2018-03-08 23:41:15 --> Loader Class Initialized
INFO - 2018-03-08 23:41:15 --> Helper loaded: url_helper
INFO - 2018-03-08 23:41:15 --> Helper loaded: form_helper
INFO - 2018-03-08 23:41:15 --> Database Driver Class Initialized
DEBUG - 2018-03-08 23:41:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-08 23:41:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 23:41:15 --> Form Validation Class Initialized
INFO - 2018-03-08 23:41:15 --> Model Class Initialized
INFO - 2018-03-08 23:41:15 --> Controller Class Initialized
INFO - 2018-03-08 23:41:15 --> Model Class Initialized
INFO - 2018-03-08 23:41:15 --> Model Class Initialized
INFO - 2018-03-08 23:41:15 --> Model Class Initialized
INFO - 2018-03-08 23:41:15 --> Model Class Initialized
INFO - 2018-03-08 23:41:15 --> Model Class Initialized
DEBUG - 2018-03-08 23:41:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-08 23:41:15 --> Config Class Initialized
INFO - 2018-03-08 23:41:15 --> Hooks Class Initialized
DEBUG - 2018-03-08 23:41:15 --> UTF-8 Support Enabled
INFO - 2018-03-08 23:41:15 --> Utf8 Class Initialized
INFO - 2018-03-08 23:41:15 --> URI Class Initialized
INFO - 2018-03-08 23:41:15 --> Router Class Initialized
INFO - 2018-03-08 23:41:15 --> Output Class Initialized
INFO - 2018-03-08 23:41:15 --> Security Class Initialized
DEBUG - 2018-03-08 23:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 23:41:15 --> Input Class Initialized
INFO - 2018-03-08 23:41:15 --> Language Class Initialized
INFO - 2018-03-08 23:41:15 --> Loader Class Initialized
INFO - 2018-03-08 23:41:15 --> Helper loaded: url_helper
INFO - 2018-03-08 23:41:15 --> Helper loaded: form_helper
INFO - 2018-03-08 23:41:15 --> Database Driver Class Initialized
DEBUG - 2018-03-08 23:41:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-08 23:41:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 23:41:15 --> Form Validation Class Initialized
INFO - 2018-03-08 23:41:15 --> Model Class Initialized
INFO - 2018-03-08 23:41:15 --> Controller Class Initialized
INFO - 2018-03-08 23:41:15 --> Model Class Initialized
DEBUG - 2018-03-08 23:41:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-08 23:41:15 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-08 23:41:15 --> Final output sent to browser
DEBUG - 2018-03-08 23:41:15 --> Total execution time: 0.0549
INFO - 2018-03-08 23:41:17 --> Config Class Initialized
INFO - 2018-03-08 23:41:17 --> Hooks Class Initialized
DEBUG - 2018-03-08 23:41:17 --> UTF-8 Support Enabled
INFO - 2018-03-08 23:41:17 --> Utf8 Class Initialized
INFO - 2018-03-08 23:41:17 --> URI Class Initialized
INFO - 2018-03-08 23:41:17 --> Router Class Initialized
INFO - 2018-03-08 23:41:17 --> Output Class Initialized
INFO - 2018-03-08 23:41:17 --> Security Class Initialized
DEBUG - 2018-03-08 23:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 23:41:17 --> Input Class Initialized
INFO - 2018-03-08 23:41:17 --> Language Class Initialized
INFO - 2018-03-08 23:41:17 --> Loader Class Initialized
INFO - 2018-03-08 23:41:17 --> Helper loaded: url_helper
INFO - 2018-03-08 23:41:17 --> Helper loaded: form_helper
INFO - 2018-03-08 23:41:17 --> Database Driver Class Initialized
DEBUG - 2018-03-08 23:41:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-08 23:41:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 23:41:17 --> Form Validation Class Initialized
INFO - 2018-03-08 23:41:17 --> Model Class Initialized
INFO - 2018-03-08 23:41:17 --> Controller Class Initialized
INFO - 2018-03-08 23:41:17 --> Model Class Initialized
DEBUG - 2018-03-08 23:41:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-08 23:41:17 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-08 23:41:17 --> Config Class Initialized
INFO - 2018-03-08 23:41:17 --> Hooks Class Initialized
DEBUG - 2018-03-08 23:41:17 --> UTF-8 Support Enabled
INFO - 2018-03-08 23:41:17 --> Utf8 Class Initialized
INFO - 2018-03-08 23:41:17 --> URI Class Initialized
DEBUG - 2018-03-08 23:41:17 --> No URI present. Default controller set.
INFO - 2018-03-08 23:41:17 --> Router Class Initialized
INFO - 2018-03-08 23:41:17 --> Output Class Initialized
INFO - 2018-03-08 23:41:17 --> Security Class Initialized
DEBUG - 2018-03-08 23:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 23:41:17 --> Input Class Initialized
INFO - 2018-03-08 23:41:17 --> Language Class Initialized
INFO - 2018-03-08 23:41:17 --> Loader Class Initialized
INFO - 2018-03-08 23:41:17 --> Helper loaded: url_helper
INFO - 2018-03-08 23:41:17 --> Helper loaded: form_helper
INFO - 2018-03-08 23:41:17 --> Database Driver Class Initialized
DEBUG - 2018-03-08 23:41:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-08 23:41:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 23:41:17 --> Form Validation Class Initialized
INFO - 2018-03-08 23:41:17 --> Model Class Initialized
INFO - 2018-03-08 23:41:17 --> Controller Class Initialized
INFO - 2018-03-08 23:41:17 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-08 23:41:17 --> Final output sent to browser
DEBUG - 2018-03-08 23:41:17 --> Total execution time: 0.0650
INFO - 2018-03-08 23:41:17 --> Config Class Initialized
INFO - 2018-03-08 23:41:17 --> Hooks Class Initialized
DEBUG - 2018-03-08 23:41:17 --> UTF-8 Support Enabled
INFO - 2018-03-08 23:41:17 --> Utf8 Class Initialized
INFO - 2018-03-08 23:41:17 --> URI Class Initialized
INFO - 2018-03-08 23:41:17 --> Router Class Initialized
INFO - 2018-03-08 23:41:17 --> Output Class Initialized
INFO - 2018-03-08 23:41:17 --> Security Class Initialized
DEBUG - 2018-03-08 23:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 23:41:17 --> Input Class Initialized
INFO - 2018-03-08 23:41:17 --> Language Class Initialized
INFO - 2018-03-08 23:41:17 --> Loader Class Initialized
INFO - 2018-03-08 23:41:17 --> Helper loaded: url_helper
INFO - 2018-03-08 23:41:17 --> Helper loaded: form_helper
INFO - 2018-03-08 23:41:17 --> Database Driver Class Initialized
DEBUG - 2018-03-08 23:41:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-08 23:41:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 23:41:17 --> Form Validation Class Initialized
INFO - 2018-03-08 23:41:17 --> Model Class Initialized
INFO - 2018-03-08 23:41:17 --> Controller Class Initialized
INFO - 2018-03-08 23:41:17 --> Model Class Initialized
INFO - 2018-03-08 23:41:17 --> Model Class Initialized
INFO - 2018-03-08 23:41:17 --> Model Class Initialized
INFO - 2018-03-08 23:41:17 --> Model Class Initialized
INFO - 2018-03-08 23:41:17 --> Model Class Initialized
DEBUG - 2018-03-08 23:41:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-08 23:41:21 --> Config Class Initialized
INFO - 2018-03-08 23:41:21 --> Hooks Class Initialized
DEBUG - 2018-03-08 23:41:21 --> UTF-8 Support Enabled
INFO - 2018-03-08 23:41:21 --> Utf8 Class Initialized
INFO - 2018-03-08 23:41:21 --> URI Class Initialized
INFO - 2018-03-08 23:41:21 --> Router Class Initialized
INFO - 2018-03-08 23:41:21 --> Output Class Initialized
INFO - 2018-03-08 23:41:21 --> Security Class Initialized
DEBUG - 2018-03-08 23:41:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 23:41:21 --> Input Class Initialized
INFO - 2018-03-08 23:41:21 --> Language Class Initialized
INFO - 2018-03-08 23:41:21 --> Loader Class Initialized
INFO - 2018-03-08 23:41:21 --> Helper loaded: url_helper
INFO - 2018-03-08 23:41:21 --> Helper loaded: form_helper
INFO - 2018-03-08 23:41:21 --> Database Driver Class Initialized
DEBUG - 2018-03-08 23:41:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-08 23:41:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 23:41:21 --> Form Validation Class Initialized
INFO - 2018-03-08 23:41:21 --> Model Class Initialized
INFO - 2018-03-08 23:41:21 --> Controller Class Initialized
INFO - 2018-03-08 23:41:21 --> Model Class Initialized
INFO - 2018-03-08 23:41:21 --> Model Class Initialized
INFO - 2018-03-08 23:41:21 --> Model Class Initialized
INFO - 2018-03-08 23:41:21 --> Model Class Initialized
INFO - 2018-03-08 23:41:21 --> Model Class Initialized
DEBUG - 2018-03-08 23:41:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-08 23:41:21 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-08 23:41:21 --> Final output sent to browser
DEBUG - 2018-03-08 23:41:21 --> Total execution time: 0.0644
INFO - 2018-03-08 23:41:21 --> Config Class Initialized
INFO - 2018-03-08 23:41:21 --> Hooks Class Initialized
DEBUG - 2018-03-08 23:41:21 --> UTF-8 Support Enabled
INFO - 2018-03-08 23:41:21 --> Utf8 Class Initialized
INFO - 2018-03-08 23:41:21 --> URI Class Initialized
INFO - 2018-03-08 23:41:21 --> Router Class Initialized
INFO - 2018-03-08 23:41:21 --> Output Class Initialized
INFO - 2018-03-08 23:41:21 --> Security Class Initialized
DEBUG - 2018-03-08 23:41:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 23:41:21 --> Input Class Initialized
INFO - 2018-03-08 23:41:21 --> Language Class Initialized
INFO - 2018-03-08 23:41:21 --> Loader Class Initialized
INFO - 2018-03-08 23:41:21 --> Helper loaded: url_helper
INFO - 2018-03-08 23:41:21 --> Helper loaded: form_helper
INFO - 2018-03-08 23:41:21 --> Database Driver Class Initialized
DEBUG - 2018-03-08 23:41:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-08 23:41:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 23:41:21 --> Form Validation Class Initialized
INFO - 2018-03-08 23:41:21 --> Model Class Initialized
INFO - 2018-03-08 23:41:21 --> Controller Class Initialized
INFO - 2018-03-08 23:41:21 --> Model Class Initialized
INFO - 2018-03-08 23:41:21 --> Model Class Initialized
INFO - 2018-03-08 23:41:21 --> Model Class Initialized
INFO - 2018-03-08 23:41:21 --> Model Class Initialized
INFO - 2018-03-08 23:41:21 --> Model Class Initialized
DEBUG - 2018-03-08 23:41:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-08 23:41:26 --> Config Class Initialized
INFO - 2018-03-08 23:41:26 --> Hooks Class Initialized
DEBUG - 2018-03-08 23:41:26 --> UTF-8 Support Enabled
INFO - 2018-03-08 23:41:26 --> Utf8 Class Initialized
INFO - 2018-03-08 23:41:26 --> URI Class Initialized
INFO - 2018-03-08 23:41:26 --> Router Class Initialized
INFO - 2018-03-08 23:41:26 --> Output Class Initialized
INFO - 2018-03-08 23:41:26 --> Security Class Initialized
DEBUG - 2018-03-08 23:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 23:41:26 --> Input Class Initialized
INFO - 2018-03-08 23:41:26 --> Language Class Initialized
INFO - 2018-03-08 23:41:26 --> Loader Class Initialized
INFO - 2018-03-08 23:41:26 --> Helper loaded: url_helper
INFO - 2018-03-08 23:41:26 --> Helper loaded: form_helper
INFO - 2018-03-08 23:41:26 --> Database Driver Class Initialized
DEBUG - 2018-03-08 23:41:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-08 23:41:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 23:41:26 --> Form Validation Class Initialized
INFO - 2018-03-08 23:41:26 --> Model Class Initialized
INFO - 2018-03-08 23:41:26 --> Controller Class Initialized
INFO - 2018-03-08 23:41:26 --> Model Class Initialized
INFO - 2018-03-08 23:41:26 --> Model Class Initialized
INFO - 2018-03-08 23:41:26 --> Model Class Initialized
INFO - 2018-03-08 23:41:26 --> Model Class Initialized
INFO - 2018-03-08 23:41:26 --> Model Class Initialized
DEBUG - 2018-03-08 23:41:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-08 23:41:26 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-08 23:41:26 --> Final output sent to browser
DEBUG - 2018-03-08 23:41:26 --> Total execution time: 0.0634
INFO - 2018-03-08 23:41:26 --> Config Class Initialized
INFO - 2018-03-08 23:41:26 --> Hooks Class Initialized
DEBUG - 2018-03-08 23:41:26 --> UTF-8 Support Enabled
INFO - 2018-03-08 23:41:26 --> Utf8 Class Initialized
INFO - 2018-03-08 23:41:26 --> URI Class Initialized
INFO - 2018-03-08 23:41:26 --> Router Class Initialized
INFO - 2018-03-08 23:41:26 --> Output Class Initialized
INFO - 2018-03-08 23:41:26 --> Security Class Initialized
DEBUG - 2018-03-08 23:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 23:41:26 --> Input Class Initialized
INFO - 2018-03-08 23:41:26 --> Language Class Initialized
INFO - 2018-03-08 23:41:26 --> Loader Class Initialized
INFO - 2018-03-08 23:41:26 --> Helper loaded: url_helper
INFO - 2018-03-08 23:41:26 --> Helper loaded: form_helper
INFO - 2018-03-08 23:41:26 --> Database Driver Class Initialized
DEBUG - 2018-03-08 23:41:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-08 23:41:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 23:41:26 --> Form Validation Class Initialized
INFO - 2018-03-08 23:41:26 --> Model Class Initialized
INFO - 2018-03-08 23:41:26 --> Controller Class Initialized
INFO - 2018-03-08 23:41:26 --> Model Class Initialized
INFO - 2018-03-08 23:41:26 --> Model Class Initialized
INFO - 2018-03-08 23:41:26 --> Model Class Initialized
INFO - 2018-03-08 23:41:26 --> Model Class Initialized
INFO - 2018-03-08 23:41:26 --> Model Class Initialized
DEBUG - 2018-03-08 23:41:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-08 23:41:29 --> Config Class Initialized
INFO - 2018-03-08 23:41:29 --> Hooks Class Initialized
DEBUG - 2018-03-08 23:41:29 --> UTF-8 Support Enabled
INFO - 2018-03-08 23:41:29 --> Utf8 Class Initialized
INFO - 2018-03-08 23:41:29 --> URI Class Initialized
INFO - 2018-03-08 23:41:29 --> Router Class Initialized
INFO - 2018-03-08 23:41:29 --> Output Class Initialized
INFO - 2018-03-08 23:41:29 --> Security Class Initialized
DEBUG - 2018-03-08 23:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 23:41:29 --> Input Class Initialized
INFO - 2018-03-08 23:41:29 --> Language Class Initialized
INFO - 2018-03-08 23:41:29 --> Loader Class Initialized
INFO - 2018-03-08 23:41:29 --> Helper loaded: url_helper
INFO - 2018-03-08 23:41:29 --> Helper loaded: form_helper
INFO - 2018-03-08 23:41:29 --> Database Driver Class Initialized
DEBUG - 2018-03-08 23:41:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-08 23:41:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 23:41:29 --> Form Validation Class Initialized
INFO - 2018-03-08 23:41:29 --> Model Class Initialized
INFO - 2018-03-08 23:41:29 --> Controller Class Initialized
INFO - 2018-03-08 23:41:29 --> Model Class Initialized
INFO - 2018-03-08 23:41:29 --> Model Class Initialized
INFO - 2018-03-08 23:41:29 --> Model Class Initialized
INFO - 2018-03-08 23:41:29 --> Model Class Initialized
INFO - 2018-03-08 23:41:29 --> Model Class Initialized
DEBUG - 2018-03-08 23:41:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-08 23:41:29 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-08 23:41:29 --> Final output sent to browser
DEBUG - 2018-03-08 23:41:29 --> Total execution time: 0.0612
INFO - 2018-03-08 23:41:29 --> Config Class Initialized
INFO - 2018-03-08 23:41:29 --> Hooks Class Initialized
DEBUG - 2018-03-08 23:41:29 --> UTF-8 Support Enabled
INFO - 2018-03-08 23:41:29 --> Utf8 Class Initialized
INFO - 2018-03-08 23:41:29 --> URI Class Initialized
INFO - 2018-03-08 23:41:29 --> Router Class Initialized
INFO - 2018-03-08 23:41:29 --> Output Class Initialized
INFO - 2018-03-08 23:41:29 --> Security Class Initialized
DEBUG - 2018-03-08 23:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 23:41:29 --> Input Class Initialized
INFO - 2018-03-08 23:41:29 --> Language Class Initialized
INFO - 2018-03-08 23:41:29 --> Loader Class Initialized
INFO - 2018-03-08 23:41:29 --> Helper loaded: url_helper
INFO - 2018-03-08 23:41:29 --> Helper loaded: form_helper
INFO - 2018-03-08 23:41:29 --> Database Driver Class Initialized
DEBUG - 2018-03-08 23:41:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-08 23:41:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 23:41:29 --> Form Validation Class Initialized
INFO - 2018-03-08 23:41:29 --> Model Class Initialized
INFO - 2018-03-08 23:41:29 --> Controller Class Initialized
INFO - 2018-03-08 23:41:29 --> Model Class Initialized
INFO - 2018-03-08 23:41:29 --> Model Class Initialized
INFO - 2018-03-08 23:41:29 --> Model Class Initialized
INFO - 2018-03-08 23:41:29 --> Model Class Initialized
INFO - 2018-03-08 23:41:29 --> Model Class Initialized
DEBUG - 2018-03-08 23:41:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-08 23:42:05 --> Config Class Initialized
INFO - 2018-03-08 23:42:05 --> Hooks Class Initialized
DEBUG - 2018-03-08 23:42:05 --> UTF-8 Support Enabled
INFO - 2018-03-08 23:42:05 --> Utf8 Class Initialized
INFO - 2018-03-08 23:42:05 --> URI Class Initialized
INFO - 2018-03-08 23:42:05 --> Router Class Initialized
INFO - 2018-03-08 23:42:05 --> Output Class Initialized
INFO - 2018-03-08 23:42:05 --> Security Class Initialized
DEBUG - 2018-03-08 23:42:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 23:42:05 --> Input Class Initialized
INFO - 2018-03-08 23:42:05 --> Language Class Initialized
INFO - 2018-03-08 23:42:05 --> Loader Class Initialized
INFO - 2018-03-08 23:42:05 --> Helper loaded: url_helper
INFO - 2018-03-08 23:42:05 --> Helper loaded: form_helper
INFO - 2018-03-08 23:42:05 --> Database Driver Class Initialized
DEBUG - 2018-03-08 23:42:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-08 23:42:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 23:42:05 --> Form Validation Class Initialized
INFO - 2018-03-08 23:42:05 --> Model Class Initialized
INFO - 2018-03-08 23:42:05 --> Controller Class Initialized
INFO - 2018-03-08 23:42:05 --> Model Class Initialized
INFO - 2018-03-08 23:42:05 --> Model Class Initialized
INFO - 2018-03-08 23:42:05 --> Model Class Initialized
INFO - 2018-03-08 23:42:05 --> Model Class Initialized
INFO - 2018-03-08 23:42:05 --> Model Class Initialized
DEBUG - 2018-03-08 23:42:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-08 23:42:05 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-08 23:42:05 --> Final output sent to browser
DEBUG - 2018-03-08 23:42:05 --> Total execution time: 0.1265
INFO - 2018-03-08 23:42:06 --> Config Class Initialized
INFO - 2018-03-08 23:42:06 --> Hooks Class Initialized
DEBUG - 2018-03-08 23:42:06 --> UTF-8 Support Enabled
INFO - 2018-03-08 23:42:06 --> Utf8 Class Initialized
INFO - 2018-03-08 23:42:06 --> URI Class Initialized
INFO - 2018-03-08 23:42:06 --> Router Class Initialized
INFO - 2018-03-08 23:42:06 --> Output Class Initialized
INFO - 2018-03-08 23:42:06 --> Security Class Initialized
DEBUG - 2018-03-08 23:42:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 23:42:06 --> Input Class Initialized
INFO - 2018-03-08 23:42:06 --> Language Class Initialized
INFO - 2018-03-08 23:42:06 --> Loader Class Initialized
INFO - 2018-03-08 23:42:06 --> Helper loaded: url_helper
INFO - 2018-03-08 23:42:06 --> Helper loaded: form_helper
INFO - 2018-03-08 23:42:06 --> Database Driver Class Initialized
DEBUG - 2018-03-08 23:42:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-08 23:42:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 23:42:06 --> Form Validation Class Initialized
INFO - 2018-03-08 23:42:06 --> Model Class Initialized
INFO - 2018-03-08 23:42:06 --> Controller Class Initialized
INFO - 2018-03-08 23:42:06 --> Model Class Initialized
INFO - 2018-03-08 23:42:06 --> Model Class Initialized
INFO - 2018-03-08 23:42:06 --> Model Class Initialized
INFO - 2018-03-08 23:42:06 --> Model Class Initialized
INFO - 2018-03-08 23:42:06 --> Model Class Initialized
DEBUG - 2018-03-08 23:42:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-08 23:42:09 --> Config Class Initialized
INFO - 2018-03-08 23:42:09 --> Hooks Class Initialized
INFO - 2018-03-08 23:42:09 --> Config Class Initialized
INFO - 2018-03-08 23:42:09 --> Hooks Class Initialized
INFO - 2018-03-08 23:42:09 --> Config Class Initialized
DEBUG - 2018-03-08 23:42:09 --> UTF-8 Support Enabled
INFO - 2018-03-08 23:42:09 --> Hooks Class Initialized
INFO - 2018-03-08 23:42:09 --> Utf8 Class Initialized
INFO - 2018-03-08 23:42:09 --> URI Class Initialized
DEBUG - 2018-03-08 23:42:09 --> UTF-8 Support Enabled
INFO - 2018-03-08 23:42:09 --> Utf8 Class Initialized
INFO - 2018-03-08 23:42:09 --> Config Class Initialized
DEBUG - 2018-03-08 23:42:09 --> UTF-8 Support Enabled
INFO - 2018-03-08 23:42:09 --> Hooks Class Initialized
INFO - 2018-03-08 23:42:09 --> Router Class Initialized
INFO - 2018-03-08 23:42:09 --> Utf8 Class Initialized
INFO - 2018-03-08 23:42:09 --> URI Class Initialized
INFO - 2018-03-08 23:42:09 --> URI Class Initialized
INFO - 2018-03-08 23:42:09 --> Output Class Initialized
DEBUG - 2018-03-08 23:42:09 --> UTF-8 Support Enabled
INFO - 2018-03-08 23:42:09 --> Router Class Initialized
INFO - 2018-03-08 23:42:09 --> Utf8 Class Initialized
INFO - 2018-03-08 23:42:09 --> Security Class Initialized
INFO - 2018-03-08 23:42:09 --> Router Class Initialized
INFO - 2018-03-08 23:42:09 --> URI Class Initialized
INFO - 2018-03-08 23:42:09 --> Output Class Initialized
DEBUG - 2018-03-08 23:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 23:42:09 --> Output Class Initialized
INFO - 2018-03-08 23:42:09 --> Router Class Initialized
INFO - 2018-03-08 23:42:09 --> Input Class Initialized
INFO - 2018-03-08 23:42:09 --> Security Class Initialized
INFO - 2018-03-08 23:42:09 --> Language Class Initialized
INFO - 2018-03-08 23:42:09 --> Security Class Initialized
DEBUG - 2018-03-08 23:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 23:42:09 --> Output Class Initialized
INFO - 2018-03-08 23:42:09 --> Input Class Initialized
ERROR - 2018-03-08 23:42:09 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-08 23:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 23:42:09 --> Language Class Initialized
INFO - 2018-03-08 23:42:09 --> Input Class Initialized
INFO - 2018-03-08 23:42:09 --> Security Class Initialized
INFO - 2018-03-08 23:42:09 --> Language Class Initialized
ERROR - 2018-03-08 23:42:09 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-08 23:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 23:42:09 --> Input Class Initialized
ERROR - 2018-03-08 23:42:09 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-08 23:42:09 --> Language Class Initialized
ERROR - 2018-03-08 23:42:09 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-08 23:42:09 --> Config Class Initialized
INFO - 2018-03-08 23:42:09 --> Hooks Class Initialized
INFO - 2018-03-08 23:42:09 --> Config Class Initialized
INFO - 2018-03-08 23:42:09 --> Config Class Initialized
DEBUG - 2018-03-08 23:42:09 --> UTF-8 Support Enabled
INFO - 2018-03-08 23:42:09 --> Hooks Class Initialized
INFO - 2018-03-08 23:42:09 --> Hooks Class Initialized
INFO - 2018-03-08 23:42:09 --> Utf8 Class Initialized
INFO - 2018-03-08 23:42:09 --> URI Class Initialized
DEBUG - 2018-03-08 23:42:09 --> UTF-8 Support Enabled
INFO - 2018-03-08 23:42:09 --> Utf8 Class Initialized
DEBUG - 2018-03-08 23:42:09 --> UTF-8 Support Enabled
INFO - 2018-03-08 23:42:09 --> Router Class Initialized
INFO - 2018-03-08 23:42:09 --> Utf8 Class Initialized
INFO - 2018-03-08 23:42:09 --> URI Class Initialized
INFO - 2018-03-08 23:42:09 --> URI Class Initialized
INFO - 2018-03-08 23:42:09 --> Output Class Initialized
INFO - 2018-03-08 23:42:09 --> Router Class Initialized
INFO - 2018-03-08 23:42:09 --> Router Class Initialized
INFO - 2018-03-08 23:42:09 --> Security Class Initialized
INFO - 2018-03-08 23:42:09 --> Output Class Initialized
INFO - 2018-03-08 23:42:09 --> Output Class Initialized
DEBUG - 2018-03-08 23:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 23:42:09 --> Input Class Initialized
INFO - 2018-03-08 23:42:09 --> Security Class Initialized
INFO - 2018-03-08 23:42:09 --> Language Class Initialized
INFO - 2018-03-08 23:42:09 --> Security Class Initialized
DEBUG - 2018-03-08 23:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 23:42:09 --> Input Class Initialized
ERROR - 2018-03-08 23:42:09 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-03-08 23:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 23:42:09 --> Input Class Initialized
INFO - 2018-03-08 23:42:09 --> Language Class Initialized
INFO - 2018-03-08 23:42:09 --> Language Class Initialized
ERROR - 2018-03-08 23:42:09 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-08 23:42:09 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-08 23:42:21 --> Config Class Initialized
INFO - 2018-03-08 23:42:21 --> Hooks Class Initialized
DEBUG - 2018-03-08 23:42:21 --> UTF-8 Support Enabled
INFO - 2018-03-08 23:42:21 --> Utf8 Class Initialized
INFO - 2018-03-08 23:42:21 --> URI Class Initialized
INFO - 2018-03-08 23:42:21 --> Router Class Initialized
INFO - 2018-03-08 23:42:21 --> Output Class Initialized
INFO - 2018-03-08 23:42:21 --> Security Class Initialized
DEBUG - 2018-03-08 23:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 23:42:21 --> Input Class Initialized
INFO - 2018-03-08 23:42:21 --> Language Class Initialized
INFO - 2018-03-08 23:42:21 --> Loader Class Initialized
INFO - 2018-03-08 23:42:21 --> Helper loaded: url_helper
INFO - 2018-03-08 23:42:21 --> Helper loaded: form_helper
INFO - 2018-03-08 23:42:21 --> Database Driver Class Initialized
DEBUG - 2018-03-08 23:42:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-08 23:42:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 23:42:21 --> Form Validation Class Initialized
INFO - 2018-03-08 23:42:21 --> Model Class Initialized
INFO - 2018-03-08 23:42:21 --> Controller Class Initialized
INFO - 2018-03-08 23:42:21 --> Model Class Initialized
INFO - 2018-03-08 23:42:21 --> Model Class Initialized
INFO - 2018-03-08 23:42:21 --> Model Class Initialized
INFO - 2018-03-08 23:42:21 --> Model Class Initialized
INFO - 2018-03-08 23:42:21 --> Model Class Initialized
DEBUG - 2018-03-08 23:42:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-08 23:42:21 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-08 23:42:21 --> Final output sent to browser
DEBUG - 2018-03-08 23:42:21 --> Total execution time: 0.1614
INFO - 2018-03-08 23:42:22 --> Config Class Initialized
INFO - 2018-03-08 23:42:22 --> Hooks Class Initialized
INFO - 2018-03-08 23:42:22 --> Config Class Initialized
INFO - 2018-03-08 23:42:22 --> Hooks Class Initialized
INFO - 2018-03-08 23:42:22 --> Config Class Initialized
INFO - 2018-03-08 23:42:22 --> Hooks Class Initialized
DEBUG - 2018-03-08 23:42:22 --> UTF-8 Support Enabled
INFO - 2018-03-08 23:42:22 --> Utf8 Class Initialized
DEBUG - 2018-03-08 23:42:22 --> UTF-8 Support Enabled
INFO - 2018-03-08 23:42:22 --> Utf8 Class Initialized
DEBUG - 2018-03-08 23:42:22 --> UTF-8 Support Enabled
INFO - 2018-03-08 23:42:22 --> URI Class Initialized
INFO - 2018-03-08 23:42:22 --> Utf8 Class Initialized
INFO - 2018-03-08 23:42:22 --> URI Class Initialized
INFO - 2018-03-08 23:42:22 --> URI Class Initialized
INFO - 2018-03-08 23:42:22 --> Router Class Initialized
INFO - 2018-03-08 23:42:22 --> Router Class Initialized
INFO - 2018-03-08 23:42:22 --> Router Class Initialized
INFO - 2018-03-08 23:42:22 --> Output Class Initialized
INFO - 2018-03-08 23:42:22 --> Output Class Initialized
INFO - 2018-03-08 23:42:22 --> Output Class Initialized
INFO - 2018-03-08 23:42:22 --> Security Class Initialized
INFO - 2018-03-08 23:42:22 --> Security Class Initialized
INFO - 2018-03-08 23:42:22 --> Security Class Initialized
DEBUG - 2018-03-08 23:42:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 23:42:22 --> Input Class Initialized
DEBUG - 2018-03-08 23:42:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-08 23:42:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 23:42:22 --> Input Class Initialized
INFO - 2018-03-08 23:42:22 --> Input Class Initialized
INFO - 2018-03-08 23:42:22 --> Language Class Initialized
INFO - 2018-03-08 23:42:22 --> Language Class Initialized
INFO - 2018-03-08 23:42:22 --> Language Class Initialized
ERROR - 2018-03-08 23:42:22 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-08 23:42:22 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-08 23:42:22 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-08 23:42:22 --> Config Class Initialized
INFO - 2018-03-08 23:42:22 --> Hooks Class Initialized
DEBUG - 2018-03-08 23:42:22 --> UTF-8 Support Enabled
INFO - 2018-03-08 23:42:22 --> Utf8 Class Initialized
INFO - 2018-03-08 23:42:22 --> URI Class Initialized
INFO - 2018-03-08 23:42:22 --> Router Class Initialized
INFO - 2018-03-08 23:42:22 --> Output Class Initialized
INFO - 2018-03-08 23:42:22 --> Security Class Initialized
DEBUG - 2018-03-08 23:42:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 23:42:22 --> Input Class Initialized
INFO - 2018-03-08 23:42:22 --> Language Class Initialized
ERROR - 2018-03-08 23:42:22 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-08 23:42:22 --> Config Class Initialized
INFO - 2018-03-08 23:42:22 --> Hooks Class Initialized
INFO - 2018-03-08 23:42:22 --> Config Class Initialized
INFO - 2018-03-08 23:42:22 --> Hooks Class Initialized
INFO - 2018-03-08 23:42:22 --> Config Class Initialized
DEBUG - 2018-03-08 23:42:22 --> UTF-8 Support Enabled
INFO - 2018-03-08 23:42:22 --> Hooks Class Initialized
INFO - 2018-03-08 23:42:22 --> Utf8 Class Initialized
INFO - 2018-03-08 23:42:22 --> URI Class Initialized
DEBUG - 2018-03-08 23:42:22 --> UTF-8 Support Enabled
INFO - 2018-03-08 23:42:22 --> Utf8 Class Initialized
DEBUG - 2018-03-08 23:42:22 --> UTF-8 Support Enabled
INFO - 2018-03-08 23:42:22 --> URI Class Initialized
INFO - 2018-03-08 23:42:22 --> Router Class Initialized
INFO - 2018-03-08 23:42:22 --> Utf8 Class Initialized
INFO - 2018-03-08 23:42:22 --> URI Class Initialized
INFO - 2018-03-08 23:42:22 --> Router Class Initialized
INFO - 2018-03-08 23:42:22 --> Output Class Initialized
INFO - 2018-03-08 23:42:22 --> Router Class Initialized
INFO - 2018-03-08 23:42:22 --> Security Class Initialized
INFO - 2018-03-08 23:42:22 --> Output Class Initialized
INFO - 2018-03-08 23:42:22 --> Output Class Initialized
DEBUG - 2018-03-08 23:42:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 23:42:22 --> Input Class Initialized
INFO - 2018-03-08 23:42:22 --> Security Class Initialized
INFO - 2018-03-08 23:42:22 --> Security Class Initialized
INFO - 2018-03-08 23:42:22 --> Language Class Initialized
DEBUG - 2018-03-08 23:42:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-08 23:42:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 23:42:22 --> Input Class Initialized
INFO - 2018-03-08 23:42:22 --> Input Class Initialized
ERROR - 2018-03-08 23:42:22 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-08 23:42:22 --> Language Class Initialized
INFO - 2018-03-08 23:42:22 --> Language Class Initialized
ERROR - 2018-03-08 23:42:22 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-08 23:42:22 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-08 23:42:22 --> Config Class Initialized
INFO - 2018-03-08 23:42:22 --> Hooks Class Initialized
DEBUG - 2018-03-08 23:42:22 --> UTF-8 Support Enabled
INFO - 2018-03-08 23:42:22 --> Utf8 Class Initialized
INFO - 2018-03-08 23:42:22 --> URI Class Initialized
INFO - 2018-03-08 23:42:22 --> Router Class Initialized
INFO - 2018-03-08 23:42:22 --> Output Class Initialized
INFO - 2018-03-08 23:42:22 --> Security Class Initialized
DEBUG - 2018-03-08 23:42:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 23:42:22 --> Input Class Initialized
INFO - 2018-03-08 23:42:22 --> Language Class Initialized
INFO - 2018-03-08 23:42:22 --> Loader Class Initialized
INFO - 2018-03-08 23:42:22 --> Helper loaded: url_helper
INFO - 2018-03-08 23:42:22 --> Helper loaded: form_helper
INFO - 2018-03-08 23:42:22 --> Database Driver Class Initialized
DEBUG - 2018-03-08 23:42:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-08 23:42:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 23:42:22 --> Form Validation Class Initialized
INFO - 2018-03-08 23:42:22 --> Model Class Initialized
INFO - 2018-03-08 23:42:22 --> Controller Class Initialized
INFO - 2018-03-08 23:42:22 --> Model Class Initialized
INFO - 2018-03-08 23:42:22 --> Model Class Initialized
INFO - 2018-03-08 23:42:22 --> Model Class Initialized
INFO - 2018-03-08 23:42:22 --> Model Class Initialized
INFO - 2018-03-08 23:42:22 --> Model Class Initialized
DEBUG - 2018-03-08 23:42:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-08 23:42:44 --> Config Class Initialized
INFO - 2018-03-08 23:42:44 --> Hooks Class Initialized
DEBUG - 2018-03-08 23:42:44 --> UTF-8 Support Enabled
INFO - 2018-03-08 23:42:44 --> Utf8 Class Initialized
INFO - 2018-03-08 23:42:44 --> URI Class Initialized
INFO - 2018-03-08 23:42:44 --> Router Class Initialized
INFO - 2018-03-08 23:42:44 --> Output Class Initialized
INFO - 2018-03-08 23:42:44 --> Security Class Initialized
DEBUG - 2018-03-08 23:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 23:42:44 --> Input Class Initialized
INFO - 2018-03-08 23:42:44 --> Language Class Initialized
INFO - 2018-03-08 23:42:44 --> Loader Class Initialized
INFO - 2018-03-08 23:42:44 --> Helper loaded: url_helper
INFO - 2018-03-08 23:42:44 --> Helper loaded: form_helper
INFO - 2018-03-08 23:42:44 --> Database Driver Class Initialized
DEBUG - 2018-03-08 23:42:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-08 23:42:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 23:42:44 --> Form Validation Class Initialized
INFO - 2018-03-08 23:42:44 --> Model Class Initialized
INFO - 2018-03-08 23:42:44 --> Controller Class Initialized
INFO - 2018-03-08 23:42:44 --> Model Class Initialized
INFO - 2018-03-08 23:42:44 --> Model Class Initialized
INFO - 2018-03-08 23:42:44 --> Model Class Initialized
INFO - 2018-03-08 23:42:44 --> Model Class Initialized
INFO - 2018-03-08 23:42:44 --> Model Class Initialized
DEBUG - 2018-03-08 23:42:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-08 23:42:44 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-08 23:42:44 --> Final output sent to browser
DEBUG - 2018-03-08 23:42:44 --> Total execution time: 0.0632
INFO - 2018-03-08 23:42:44 --> Config Class Initialized
INFO - 2018-03-08 23:42:44 --> Hooks Class Initialized
INFO - 2018-03-08 23:42:44 --> Config Class Initialized
INFO - 2018-03-08 23:42:44 --> Hooks Class Initialized
INFO - 2018-03-08 23:42:44 --> Config Class Initialized
INFO - 2018-03-08 23:42:44 --> Hooks Class Initialized
DEBUG - 2018-03-08 23:42:44 --> UTF-8 Support Enabled
INFO - 2018-03-08 23:42:44 --> Utf8 Class Initialized
DEBUG - 2018-03-08 23:42:44 --> UTF-8 Support Enabled
INFO - 2018-03-08 23:42:44 --> Utf8 Class Initialized
INFO - 2018-03-08 23:42:44 --> URI Class Initialized
DEBUG - 2018-03-08 23:42:44 --> UTF-8 Support Enabled
INFO - 2018-03-08 23:42:44 --> URI Class Initialized
INFO - 2018-03-08 23:42:44 --> Utf8 Class Initialized
INFO - 2018-03-08 23:42:44 --> Router Class Initialized
INFO - 2018-03-08 23:42:44 --> URI Class Initialized
INFO - 2018-03-08 23:42:44 --> Router Class Initialized
INFO - 2018-03-08 23:42:44 --> Output Class Initialized
INFO - 2018-03-08 23:42:44 --> Config Class Initialized
INFO - 2018-03-08 23:42:44 --> Hooks Class Initialized
INFO - 2018-03-08 23:42:44 --> Router Class Initialized
INFO - 2018-03-08 23:42:44 --> Output Class Initialized
INFO - 2018-03-08 23:42:44 --> Security Class Initialized
INFO - 2018-03-08 23:42:44 --> Security Class Initialized
DEBUG - 2018-03-08 23:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 23:42:44 --> Output Class Initialized
INFO - 2018-03-08 23:42:44 --> Input Class Initialized
INFO - 2018-03-08 23:42:44 --> Language Class Initialized
DEBUG - 2018-03-08 23:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 23:42:44 --> Input Class Initialized
DEBUG - 2018-03-08 23:42:44 --> UTF-8 Support Enabled
INFO - 2018-03-08 23:42:44 --> Security Class Initialized
INFO - 2018-03-08 23:42:44 --> Utf8 Class Initialized
INFO - 2018-03-08 23:42:44 --> Language Class Initialized
ERROR - 2018-03-08 23:42:44 --> 404 Page Not Found: Instatec_pub/js
DEBUG - 2018-03-08 23:42:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-03-08 23:42:44 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-08 23:42:44 --> Input Class Initialized
INFO - 2018-03-08 23:42:44 --> URI Class Initialized
INFO - 2018-03-08 23:42:44 --> Language Class Initialized
INFO - 2018-03-08 23:42:44 --> Router Class Initialized
ERROR - 2018-03-08 23:42:44 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-08 23:42:44 --> Output Class Initialized
INFO - 2018-03-08 23:42:44 --> Security Class Initialized
DEBUG - 2018-03-08 23:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 23:42:44 --> Input Class Initialized
INFO - 2018-03-08 23:42:44 --> Language Class Initialized
ERROR - 2018-03-08 23:42:44 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-08 23:42:44 --> Config Class Initialized
INFO - 2018-03-08 23:42:44 --> Hooks Class Initialized
INFO - 2018-03-08 23:42:44 --> Config Class Initialized
INFO - 2018-03-08 23:42:44 --> Hooks Class Initialized
INFO - 2018-03-08 23:42:44 --> Config Class Initialized
INFO - 2018-03-08 23:42:44 --> Hooks Class Initialized
DEBUG - 2018-03-08 23:42:44 --> UTF-8 Support Enabled
INFO - 2018-03-08 23:42:44 --> Utf8 Class Initialized
DEBUG - 2018-03-08 23:42:44 --> UTF-8 Support Enabled
INFO - 2018-03-08 23:42:44 --> Utf8 Class Initialized
INFO - 2018-03-08 23:42:44 --> URI Class Initialized
DEBUG - 2018-03-08 23:42:44 --> UTF-8 Support Enabled
INFO - 2018-03-08 23:42:44 --> URI Class Initialized
INFO - 2018-03-08 23:42:44 --> Utf8 Class Initialized
INFO - 2018-03-08 23:42:44 --> URI Class Initialized
INFO - 2018-03-08 23:42:44 --> Router Class Initialized
INFO - 2018-03-08 23:42:44 --> Router Class Initialized
INFO - 2018-03-08 23:42:44 --> Output Class Initialized
INFO - 2018-03-08 23:42:44 --> Router Class Initialized
INFO - 2018-03-08 23:42:44 --> Output Class Initialized
INFO - 2018-03-08 23:42:44 --> Security Class Initialized
INFO - 2018-03-08 23:42:44 --> Security Class Initialized
INFO - 2018-03-08 23:42:44 --> Output Class Initialized
DEBUG - 2018-03-08 23:42:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-08 23:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 23:42:44 --> Input Class Initialized
INFO - 2018-03-08 23:42:44 --> Input Class Initialized
INFO - 2018-03-08 23:42:44 --> Security Class Initialized
INFO - 2018-03-08 23:42:44 --> Language Class Initialized
INFO - 2018-03-08 23:42:44 --> Language Class Initialized
DEBUG - 2018-03-08 23:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 23:42:44 --> Input Class Initialized
ERROR - 2018-03-08 23:42:44 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-08 23:42:44 --> Language Class Initialized
ERROR - 2018-03-08 23:42:44 --> 404 Page Not Found: Instatec_pub/css
ERROR - 2018-03-08 23:42:44 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-08 23:42:44 --> Config Class Initialized
INFO - 2018-03-08 23:42:44 --> Hooks Class Initialized
DEBUG - 2018-03-08 23:42:44 --> UTF-8 Support Enabled
INFO - 2018-03-08 23:42:44 --> Utf8 Class Initialized
INFO - 2018-03-08 23:42:44 --> URI Class Initialized
INFO - 2018-03-08 23:42:44 --> Router Class Initialized
INFO - 2018-03-08 23:42:44 --> Output Class Initialized
INFO - 2018-03-08 23:42:44 --> Security Class Initialized
DEBUG - 2018-03-08 23:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 23:42:44 --> Input Class Initialized
INFO - 2018-03-08 23:42:44 --> Language Class Initialized
INFO - 2018-03-08 23:42:44 --> Loader Class Initialized
INFO - 2018-03-08 23:42:44 --> Helper loaded: url_helper
INFO - 2018-03-08 23:42:44 --> Helper loaded: form_helper
INFO - 2018-03-08 23:42:44 --> Database Driver Class Initialized
DEBUG - 2018-03-08 23:42:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-08 23:42:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 23:42:44 --> Form Validation Class Initialized
INFO - 2018-03-08 23:42:44 --> Model Class Initialized
INFO - 2018-03-08 23:42:44 --> Controller Class Initialized
INFO - 2018-03-08 23:42:45 --> Model Class Initialized
INFO - 2018-03-08 23:42:45 --> Model Class Initialized
INFO - 2018-03-08 23:42:45 --> Model Class Initialized
INFO - 2018-03-08 23:42:45 --> Model Class Initialized
INFO - 2018-03-08 23:42:45 --> Model Class Initialized
DEBUG - 2018-03-08 23:42:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-08 23:45:09 --> Config Class Initialized
INFO - 2018-03-08 23:45:09 --> Hooks Class Initialized
DEBUG - 2018-03-08 23:45:09 --> UTF-8 Support Enabled
INFO - 2018-03-08 23:45:09 --> Utf8 Class Initialized
INFO - 2018-03-08 23:45:09 --> URI Class Initialized
INFO - 2018-03-08 23:45:09 --> Router Class Initialized
INFO - 2018-03-08 23:45:09 --> Output Class Initialized
INFO - 2018-03-08 23:45:09 --> Security Class Initialized
DEBUG - 2018-03-08 23:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 23:45:09 --> Input Class Initialized
INFO - 2018-03-08 23:45:09 --> Language Class Initialized
INFO - 2018-03-08 23:45:09 --> Loader Class Initialized
INFO - 2018-03-08 23:45:09 --> Helper loaded: url_helper
INFO - 2018-03-08 23:45:09 --> Helper loaded: form_helper
INFO - 2018-03-08 23:45:09 --> Database Driver Class Initialized
DEBUG - 2018-03-08 23:45:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-08 23:45:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 23:45:09 --> Form Validation Class Initialized
INFO - 2018-03-08 23:45:09 --> Model Class Initialized
INFO - 2018-03-08 23:45:09 --> Controller Class Initialized
INFO - 2018-03-08 23:45:09 --> Model Class Initialized
INFO - 2018-03-08 23:45:09 --> Model Class Initialized
INFO - 2018-03-08 23:45:09 --> Model Class Initialized
INFO - 2018-03-08 23:45:09 --> Model Class Initialized
INFO - 2018-03-08 23:45:09 --> Model Class Initialized
DEBUG - 2018-03-08 23:45:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-08 23:45:09 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-08 23:45:09 --> Final output sent to browser
DEBUG - 2018-03-08 23:45:09 --> Total execution time: 0.1190
INFO - 2018-03-08 23:45:10 --> Config Class Initialized
INFO - 2018-03-08 23:45:10 --> Config Class Initialized
INFO - 2018-03-08 23:45:10 --> Hooks Class Initialized
INFO - 2018-03-08 23:45:10 --> Hooks Class Initialized
INFO - 2018-03-08 23:45:10 --> Config Class Initialized
INFO - 2018-03-08 23:45:10 --> Hooks Class Initialized
DEBUG - 2018-03-08 23:45:10 --> UTF-8 Support Enabled
DEBUG - 2018-03-08 23:45:10 --> UTF-8 Support Enabled
INFO - 2018-03-08 23:45:10 --> Utf8 Class Initialized
INFO - 2018-03-08 23:45:10 --> Utf8 Class Initialized
INFO - 2018-03-08 23:45:10 --> URI Class Initialized
INFO - 2018-03-08 23:45:10 --> URI Class Initialized
DEBUG - 2018-03-08 23:45:10 --> UTF-8 Support Enabled
INFO - 2018-03-08 23:45:10 --> Utf8 Class Initialized
INFO - 2018-03-08 23:45:10 --> Router Class Initialized
INFO - 2018-03-08 23:45:10 --> Router Class Initialized
INFO - 2018-03-08 23:45:10 --> URI Class Initialized
INFO - 2018-03-08 23:45:10 --> Output Class Initialized
INFO - 2018-03-08 23:45:10 --> Output Class Initialized
INFO - 2018-03-08 23:45:10 --> Router Class Initialized
INFO - 2018-03-08 23:45:10 --> Security Class Initialized
INFO - 2018-03-08 23:45:10 --> Security Class Initialized
INFO - 2018-03-08 23:45:10 --> Output Class Initialized
DEBUG - 2018-03-08 23:45:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-08 23:45:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 23:45:10 --> Input Class Initialized
INFO - 2018-03-08 23:45:10 --> Security Class Initialized
INFO - 2018-03-08 23:45:10 --> Input Class Initialized
INFO - 2018-03-08 23:45:10 --> Language Class Initialized
INFO - 2018-03-08 23:45:10 --> Language Class Initialized
DEBUG - 2018-03-08 23:45:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 23:45:10 --> Input Class Initialized
ERROR - 2018-03-08 23:45:10 --> 404 Page Not Found: Instatec_pub/js
ERROR - 2018-03-08 23:45:10 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-08 23:45:10 --> Language Class Initialized
ERROR - 2018-03-08 23:45:10 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-08 23:45:10 --> Config Class Initialized
INFO - 2018-03-08 23:45:10 --> Hooks Class Initialized
DEBUG - 2018-03-08 23:45:10 --> UTF-8 Support Enabled
INFO - 2018-03-08 23:45:10 --> Utf8 Class Initialized
INFO - 2018-03-08 23:45:10 --> URI Class Initialized
INFO - 2018-03-08 23:45:10 --> Router Class Initialized
INFO - 2018-03-08 23:45:10 --> Output Class Initialized
INFO - 2018-03-08 23:45:10 --> Security Class Initialized
DEBUG - 2018-03-08 23:45:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 23:45:10 --> Input Class Initialized
INFO - 2018-03-08 23:45:10 --> Language Class Initialized
ERROR - 2018-03-08 23:45:10 --> 404 Page Not Found: Instatec_pub/js
INFO - 2018-03-08 23:45:10 --> Config Class Initialized
INFO - 2018-03-08 23:45:10 --> Hooks Class Initialized
INFO - 2018-03-08 23:45:10 --> Config Class Initialized
INFO - 2018-03-08 23:45:10 --> Hooks Class Initialized
INFO - 2018-03-08 23:45:10 --> Config Class Initialized
INFO - 2018-03-08 23:45:10 --> Hooks Class Initialized
DEBUG - 2018-03-08 23:45:10 --> UTF-8 Support Enabled
DEBUG - 2018-03-08 23:45:10 --> UTF-8 Support Enabled
INFO - 2018-03-08 23:45:10 --> Utf8 Class Initialized
INFO - 2018-03-08 23:45:10 --> Utf8 Class Initialized
DEBUG - 2018-03-08 23:45:10 --> UTF-8 Support Enabled
INFO - 2018-03-08 23:45:10 --> URI Class Initialized
INFO - 2018-03-08 23:45:10 --> Utf8 Class Initialized
INFO - 2018-03-08 23:45:10 --> URI Class Initialized
INFO - 2018-03-08 23:45:10 --> URI Class Initialized
INFO - 2018-03-08 23:45:10 --> Router Class Initialized
INFO - 2018-03-08 23:45:10 --> Router Class Initialized
INFO - 2018-03-08 23:45:10 --> Router Class Initialized
INFO - 2018-03-08 23:45:10 --> Output Class Initialized
INFO - 2018-03-08 23:45:10 --> Output Class Initialized
INFO - 2018-03-08 23:45:10 --> Security Class Initialized
INFO - 2018-03-08 23:45:10 --> Output Class Initialized
INFO - 2018-03-08 23:45:10 --> Security Class Initialized
DEBUG - 2018-03-08 23:45:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 23:45:10 --> Input Class Initialized
INFO - 2018-03-08 23:45:10 --> Security Class Initialized
DEBUG - 2018-03-08 23:45:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 23:45:10 --> Language Class Initialized
INFO - 2018-03-08 23:45:10 --> Input Class Initialized
INFO - 2018-03-08 23:45:10 --> Language Class Initialized
ERROR - 2018-03-08 23:45:10 --> 404 Page Not Found: Instatec_pub/css
DEBUG - 2018-03-08 23:45:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 23:45:10 --> Input Class Initialized
ERROR - 2018-03-08 23:45:10 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-08 23:45:10 --> Language Class Initialized
ERROR - 2018-03-08 23:45:10 --> 404 Page Not Found: Instatec_pub/css
INFO - 2018-03-08 23:45:10 --> Config Class Initialized
INFO - 2018-03-08 23:45:10 --> Hooks Class Initialized
DEBUG - 2018-03-08 23:45:10 --> UTF-8 Support Enabled
INFO - 2018-03-08 23:45:10 --> Utf8 Class Initialized
INFO - 2018-03-08 23:45:10 --> URI Class Initialized
INFO - 2018-03-08 23:45:10 --> Router Class Initialized
INFO - 2018-03-08 23:45:10 --> Output Class Initialized
INFO - 2018-03-08 23:45:10 --> Security Class Initialized
DEBUG - 2018-03-08 23:45:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 23:45:10 --> Input Class Initialized
INFO - 2018-03-08 23:45:10 --> Language Class Initialized
INFO - 2018-03-08 23:45:10 --> Loader Class Initialized
INFO - 2018-03-08 23:45:10 --> Helper loaded: url_helper
INFO - 2018-03-08 23:45:10 --> Helper loaded: form_helper
INFO - 2018-03-08 23:45:10 --> Database Driver Class Initialized
DEBUG - 2018-03-08 23:45:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-08 23:45:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 23:45:10 --> Form Validation Class Initialized
INFO - 2018-03-08 23:45:10 --> Model Class Initialized
INFO - 2018-03-08 23:45:10 --> Controller Class Initialized
INFO - 2018-03-08 23:45:10 --> Model Class Initialized
INFO - 2018-03-08 23:45:10 --> Model Class Initialized
INFO - 2018-03-08 23:45:10 --> Model Class Initialized
INFO - 2018-03-08 23:45:10 --> Model Class Initialized
INFO - 2018-03-08 23:45:10 --> Model Class Initialized
DEBUG - 2018-03-08 23:45:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-08 23:45:36 --> Config Class Initialized
INFO - 2018-03-08 23:45:36 --> Hooks Class Initialized
DEBUG - 2018-03-08 23:45:36 --> UTF-8 Support Enabled
INFO - 2018-03-08 23:45:36 --> Utf8 Class Initialized
INFO - 2018-03-08 23:45:36 --> URI Class Initialized
INFO - 2018-03-08 23:45:36 --> Router Class Initialized
INFO - 2018-03-08 23:45:36 --> Output Class Initialized
INFO - 2018-03-08 23:45:36 --> Security Class Initialized
DEBUG - 2018-03-08 23:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 23:45:36 --> Input Class Initialized
INFO - 2018-03-08 23:45:36 --> Language Class Initialized
INFO - 2018-03-08 23:45:36 --> Loader Class Initialized
INFO - 2018-03-08 23:45:36 --> Helper loaded: url_helper
INFO - 2018-03-08 23:45:36 --> Helper loaded: form_helper
INFO - 2018-03-08 23:45:36 --> Database Driver Class Initialized
DEBUG - 2018-03-08 23:45:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-08 23:45:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 23:45:36 --> Form Validation Class Initialized
INFO - 2018-03-08 23:45:36 --> Model Class Initialized
INFO - 2018-03-08 23:45:36 --> Controller Class Initialized
INFO - 2018-03-08 23:45:36 --> Model Class Initialized
INFO - 2018-03-08 23:45:36 --> Model Class Initialized
DEBUG - 2018-03-08 23:45:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-08 23:45:36 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-08 23:45:36 --> Final output sent to browser
DEBUG - 2018-03-08 23:45:36 --> Total execution time: 0.0627
INFO - 2018-03-08 23:45:37 --> Config Class Initialized
INFO - 2018-03-08 23:45:37 --> Hooks Class Initialized
DEBUG - 2018-03-08 23:45:37 --> UTF-8 Support Enabled
INFO - 2018-03-08 23:45:37 --> Utf8 Class Initialized
INFO - 2018-03-08 23:45:37 --> URI Class Initialized
INFO - 2018-03-08 23:45:37 --> Router Class Initialized
INFO - 2018-03-08 23:45:37 --> Output Class Initialized
INFO - 2018-03-08 23:45:37 --> Security Class Initialized
DEBUG - 2018-03-08 23:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 23:45:37 --> Input Class Initialized
INFO - 2018-03-08 23:45:37 --> Language Class Initialized
INFO - 2018-03-08 23:45:37 --> Loader Class Initialized
INFO - 2018-03-08 23:45:37 --> Helper loaded: url_helper
INFO - 2018-03-08 23:45:37 --> Helper loaded: form_helper
INFO - 2018-03-08 23:45:37 --> Database Driver Class Initialized
DEBUG - 2018-03-08 23:45:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-08 23:45:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 23:45:37 --> Form Validation Class Initialized
INFO - 2018-03-08 23:45:37 --> Model Class Initialized
INFO - 2018-03-08 23:45:37 --> Controller Class Initialized
INFO - 2018-03-08 23:45:37 --> Model Class Initialized
INFO - 2018-03-08 23:45:37 --> Model Class Initialized
DEBUG - 2018-03-08 23:45:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-08 23:45:39 --> Config Class Initialized
INFO - 2018-03-08 23:45:39 --> Hooks Class Initialized
DEBUG - 2018-03-08 23:45:39 --> UTF-8 Support Enabled
INFO - 2018-03-08 23:45:39 --> Utf8 Class Initialized
INFO - 2018-03-08 23:45:39 --> URI Class Initialized
INFO - 2018-03-08 23:45:39 --> Router Class Initialized
INFO - 2018-03-08 23:45:39 --> Output Class Initialized
INFO - 2018-03-08 23:45:39 --> Security Class Initialized
DEBUG - 2018-03-08 23:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 23:45:39 --> Input Class Initialized
INFO - 2018-03-08 23:45:39 --> Language Class Initialized
INFO - 2018-03-08 23:45:39 --> Loader Class Initialized
INFO - 2018-03-08 23:45:39 --> Helper loaded: url_helper
INFO - 2018-03-08 23:45:39 --> Helper loaded: form_helper
INFO - 2018-03-08 23:45:39 --> Database Driver Class Initialized
DEBUG - 2018-03-08 23:45:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-08 23:45:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 23:45:39 --> Form Validation Class Initialized
INFO - 2018-03-08 23:45:39 --> Model Class Initialized
INFO - 2018-03-08 23:45:39 --> Controller Class Initialized
INFO - 2018-03-08 23:45:39 --> Model Class Initialized
INFO - 2018-03-08 23:45:39 --> Model Class Initialized
INFO - 2018-03-08 23:45:39 --> Model Class Initialized
INFO - 2018-03-08 23:45:39 --> Model Class Initialized
INFO - 2018-03-08 23:45:39 --> Model Class Initialized
DEBUG - 2018-03-08 23:45:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-08 23:45:39 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-08 23:45:39 --> Final output sent to browser
DEBUG - 2018-03-08 23:45:39 --> Total execution time: 0.0680
INFO - 2018-03-08 23:45:39 --> Config Class Initialized
INFO - 2018-03-08 23:45:39 --> Hooks Class Initialized
DEBUG - 2018-03-08 23:45:39 --> UTF-8 Support Enabled
INFO - 2018-03-08 23:45:39 --> Utf8 Class Initialized
INFO - 2018-03-08 23:45:39 --> URI Class Initialized
INFO - 2018-03-08 23:45:39 --> Router Class Initialized
INFO - 2018-03-08 23:45:39 --> Output Class Initialized
INFO - 2018-03-08 23:45:39 --> Security Class Initialized
DEBUG - 2018-03-08 23:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 23:45:39 --> Input Class Initialized
INFO - 2018-03-08 23:45:39 --> Language Class Initialized
INFO - 2018-03-08 23:45:39 --> Loader Class Initialized
INFO - 2018-03-08 23:45:39 --> Helper loaded: url_helper
INFO - 2018-03-08 23:45:39 --> Helper loaded: form_helper
INFO - 2018-03-08 23:45:39 --> Database Driver Class Initialized
DEBUG - 2018-03-08 23:45:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-08 23:45:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 23:45:39 --> Form Validation Class Initialized
INFO - 2018-03-08 23:45:39 --> Model Class Initialized
INFO - 2018-03-08 23:45:39 --> Controller Class Initialized
INFO - 2018-03-08 23:45:39 --> Model Class Initialized
INFO - 2018-03-08 23:45:39 --> Model Class Initialized
INFO - 2018-03-08 23:45:39 --> Model Class Initialized
INFO - 2018-03-08 23:45:39 --> Model Class Initialized
INFO - 2018-03-08 23:45:39 --> Model Class Initialized
DEBUG - 2018-03-08 23:45:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-08 23:45:59 --> Config Class Initialized
INFO - 2018-03-08 23:45:59 --> Hooks Class Initialized
DEBUG - 2018-03-08 23:45:59 --> UTF-8 Support Enabled
INFO - 2018-03-08 23:45:59 --> Utf8 Class Initialized
INFO - 2018-03-08 23:45:59 --> URI Class Initialized
INFO - 2018-03-08 23:45:59 --> Router Class Initialized
INFO - 2018-03-08 23:45:59 --> Output Class Initialized
INFO - 2018-03-08 23:45:59 --> Security Class Initialized
DEBUG - 2018-03-08 23:45:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 23:45:59 --> Input Class Initialized
INFO - 2018-03-08 23:45:59 --> Language Class Initialized
INFO - 2018-03-08 23:45:59 --> Loader Class Initialized
INFO - 2018-03-08 23:45:59 --> Helper loaded: url_helper
INFO - 2018-03-08 23:45:59 --> Helper loaded: form_helper
INFO - 2018-03-08 23:45:59 --> Database Driver Class Initialized
DEBUG - 2018-03-08 23:45:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-08 23:45:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 23:45:59 --> Form Validation Class Initialized
INFO - 2018-03-08 23:45:59 --> Model Class Initialized
INFO - 2018-03-08 23:45:59 --> Controller Class Initialized
INFO - 2018-03-08 23:45:59 --> Model Class Initialized
INFO - 2018-03-08 23:45:59 --> Model Class Initialized
INFO - 2018-03-08 23:45:59 --> Model Class Initialized
INFO - 2018-03-08 23:45:59 --> Model Class Initialized
INFO - 2018-03-08 23:45:59 --> Model Class Initialized
DEBUG - 2018-03-08 23:45:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-08 23:45:59 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-08 23:45:59 --> Final output sent to browser
DEBUG - 2018-03-08 23:45:59 --> Total execution time: 0.0538
INFO - 2018-03-08 23:46:00 --> Config Class Initialized
INFO - 2018-03-08 23:46:00 --> Hooks Class Initialized
DEBUG - 2018-03-08 23:46:00 --> UTF-8 Support Enabled
INFO - 2018-03-08 23:46:00 --> Utf8 Class Initialized
INFO - 2018-03-08 23:46:00 --> URI Class Initialized
INFO - 2018-03-08 23:46:00 --> Router Class Initialized
INFO - 2018-03-08 23:46:00 --> Output Class Initialized
INFO - 2018-03-08 23:46:00 --> Security Class Initialized
DEBUG - 2018-03-08 23:46:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 23:46:00 --> Input Class Initialized
INFO - 2018-03-08 23:46:00 --> Language Class Initialized
INFO - 2018-03-08 23:46:00 --> Loader Class Initialized
INFO - 2018-03-08 23:46:00 --> Helper loaded: url_helper
INFO - 2018-03-08 23:46:00 --> Helper loaded: form_helper
INFO - 2018-03-08 23:46:00 --> Database Driver Class Initialized
DEBUG - 2018-03-08 23:46:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-08 23:46:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 23:46:00 --> Form Validation Class Initialized
INFO - 2018-03-08 23:46:00 --> Model Class Initialized
INFO - 2018-03-08 23:46:00 --> Controller Class Initialized
INFO - 2018-03-08 23:46:00 --> Model Class Initialized
INFO - 2018-03-08 23:46:00 --> Model Class Initialized
INFO - 2018-03-08 23:46:00 --> Model Class Initialized
INFO - 2018-03-08 23:46:00 --> Model Class Initialized
INFO - 2018-03-08 23:46:00 --> Model Class Initialized
DEBUG - 2018-03-08 23:46:00 --> Form_validation class already loaded. Second attempt ignored.
