<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-03-20 23:36:26 --> Config Class Initialized
INFO - 2018-03-20 23:36:26 --> Hooks Class Initialized
DEBUG - 2018-03-20 23:36:26 --> UTF-8 Support Enabled
INFO - 2018-03-20 23:36:26 --> Utf8 Class Initialized
INFO - 2018-03-20 23:36:26 --> URI Class Initialized
INFO - 2018-03-20 23:36:26 --> Router Class Initialized
INFO - 2018-03-20 23:36:26 --> Output Class Initialized
INFO - 2018-03-20 23:36:26 --> Security Class Initialized
DEBUG - 2018-03-20 23:36:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 23:36:26 --> Input Class Initialized
INFO - 2018-03-20 23:36:26 --> Language Class Initialized
INFO - 2018-03-20 23:36:27 --> Loader Class Initialized
INFO - 2018-03-20 23:36:27 --> Helper loaded: url_helper
INFO - 2018-03-20 23:36:27 --> Helper loaded: form_helper
INFO - 2018-03-20 23:36:27 --> Database Driver Class Initialized
DEBUG - 2018-03-20 23:36:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 23:36:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 23:36:27 --> Form Validation Class Initialized
INFO - 2018-03-20 23:36:27 --> Model Class Initialized
INFO - 2018-03-20 23:36:27 --> Controller Class Initialized
INFO - 2018-03-20 23:36:27 --> Model Class Initialized
INFO - 2018-03-20 23:36:27 --> Model Class Initialized
INFO - 2018-03-20 23:36:27 --> Model Class Initialized
INFO - 2018-03-20 23:36:27 --> Model Class Initialized
DEBUG - 2018-03-20 23:36:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-20 23:36:27 --> Config Class Initialized
INFO - 2018-03-20 23:36:27 --> Hooks Class Initialized
DEBUG - 2018-03-20 23:36:27 --> UTF-8 Support Enabled
INFO - 2018-03-20 23:36:27 --> Utf8 Class Initialized
INFO - 2018-03-20 23:36:27 --> URI Class Initialized
INFO - 2018-03-20 23:36:27 --> Router Class Initialized
INFO - 2018-03-20 23:36:27 --> Output Class Initialized
INFO - 2018-03-20 23:36:27 --> Security Class Initialized
DEBUG - 2018-03-20 23:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 23:36:27 --> Input Class Initialized
INFO - 2018-03-20 23:36:27 --> Language Class Initialized
INFO - 2018-03-20 23:36:27 --> Loader Class Initialized
INFO - 2018-03-20 23:36:27 --> Helper loaded: url_helper
INFO - 2018-03-20 23:36:27 --> Helper loaded: form_helper
INFO - 2018-03-20 23:36:27 --> Database Driver Class Initialized
DEBUG - 2018-03-20 23:36:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 23:36:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 23:36:27 --> Form Validation Class Initialized
INFO - 2018-03-20 23:36:27 --> Model Class Initialized
INFO - 2018-03-20 23:36:27 --> Controller Class Initialized
INFO - 2018-03-20 23:36:27 --> Model Class Initialized
DEBUG - 2018-03-20 23:36:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-20 23:36:27 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-20 23:36:27 --> Final output sent to browser
DEBUG - 2018-03-20 23:36:27 --> Total execution time: 0.1413
INFO - 2018-03-20 23:36:29 --> Config Class Initialized
INFO - 2018-03-20 23:36:29 --> Hooks Class Initialized
DEBUG - 2018-03-20 23:36:29 --> UTF-8 Support Enabled
INFO - 2018-03-20 23:36:29 --> Utf8 Class Initialized
INFO - 2018-03-20 23:36:29 --> URI Class Initialized
INFO - 2018-03-20 23:36:29 --> Router Class Initialized
INFO - 2018-03-20 23:36:29 --> Output Class Initialized
INFO - 2018-03-20 23:36:29 --> Security Class Initialized
DEBUG - 2018-03-20 23:36:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 23:36:29 --> Input Class Initialized
INFO - 2018-03-20 23:36:29 --> Language Class Initialized
INFO - 2018-03-20 23:36:29 --> Loader Class Initialized
INFO - 2018-03-20 23:36:29 --> Helper loaded: url_helper
INFO - 2018-03-20 23:36:29 --> Helper loaded: form_helper
INFO - 2018-03-20 23:36:29 --> Database Driver Class Initialized
DEBUG - 2018-03-20 23:36:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 23:36:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 23:36:29 --> Form Validation Class Initialized
INFO - 2018-03-20 23:36:29 --> Model Class Initialized
INFO - 2018-03-20 23:36:29 --> Controller Class Initialized
INFO - 2018-03-20 23:36:29 --> Model Class Initialized
DEBUG - 2018-03-20 23:36:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-20 23:36:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-20 23:36:29 --> Config Class Initialized
INFO - 2018-03-20 23:36:29 --> Hooks Class Initialized
DEBUG - 2018-03-20 23:36:29 --> UTF-8 Support Enabled
INFO - 2018-03-20 23:36:29 --> Utf8 Class Initialized
INFO - 2018-03-20 23:36:29 --> URI Class Initialized
DEBUG - 2018-03-20 23:36:29 --> No URI present. Default controller set.
INFO - 2018-03-20 23:36:29 --> Router Class Initialized
INFO - 2018-03-20 23:36:29 --> Output Class Initialized
INFO - 2018-03-20 23:36:29 --> Security Class Initialized
DEBUG - 2018-03-20 23:36:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 23:36:29 --> Input Class Initialized
INFO - 2018-03-20 23:36:29 --> Language Class Initialized
INFO - 2018-03-20 23:36:29 --> Loader Class Initialized
INFO - 2018-03-20 23:36:29 --> Helper loaded: url_helper
INFO - 2018-03-20 23:36:29 --> Helper loaded: form_helper
INFO - 2018-03-20 23:36:29 --> Database Driver Class Initialized
DEBUG - 2018-03-20 23:36:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 23:36:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 23:36:29 --> Form Validation Class Initialized
INFO - 2018-03-20 23:36:29 --> Model Class Initialized
INFO - 2018-03-20 23:36:29 --> Controller Class Initialized
INFO - 2018-03-20 23:36:29 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-20 23:36:29 --> Final output sent to browser
DEBUG - 2018-03-20 23:36:29 --> Total execution time: 0.1188
INFO - 2018-03-20 23:36:30 --> Config Class Initialized
INFO - 2018-03-20 23:36:30 --> Hooks Class Initialized
DEBUG - 2018-03-20 23:36:30 --> UTF-8 Support Enabled
INFO - 2018-03-20 23:36:30 --> Utf8 Class Initialized
INFO - 2018-03-20 23:36:30 --> URI Class Initialized
INFO - 2018-03-20 23:36:30 --> Router Class Initialized
INFO - 2018-03-20 23:36:30 --> Output Class Initialized
INFO - 2018-03-20 23:36:30 --> Security Class Initialized
DEBUG - 2018-03-20 23:36:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 23:36:30 --> Input Class Initialized
INFO - 2018-03-20 23:36:30 --> Language Class Initialized
INFO - 2018-03-20 23:36:30 --> Loader Class Initialized
INFO - 2018-03-20 23:36:30 --> Helper loaded: url_helper
INFO - 2018-03-20 23:36:30 --> Helper loaded: form_helper
INFO - 2018-03-20 23:36:30 --> Database Driver Class Initialized
DEBUG - 2018-03-20 23:36:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 23:36:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 23:36:30 --> Form Validation Class Initialized
INFO - 2018-03-20 23:36:30 --> Model Class Initialized
INFO - 2018-03-20 23:36:30 --> Controller Class Initialized
INFO - 2018-03-20 23:36:30 --> Model Class Initialized
INFO - 2018-03-20 23:36:30 --> Model Class Initialized
INFO - 2018-03-20 23:36:30 --> Model Class Initialized
INFO - 2018-03-20 23:36:30 --> Model Class Initialized
INFO - 2018-03-20 23:36:30 --> Model Class Initialized
DEBUG - 2018-03-20 23:36:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-20 23:36:43 --> Config Class Initialized
INFO - 2018-03-20 23:36:43 --> Hooks Class Initialized
DEBUG - 2018-03-20 23:36:43 --> UTF-8 Support Enabled
INFO - 2018-03-20 23:36:43 --> Utf8 Class Initialized
INFO - 2018-03-20 23:36:43 --> URI Class Initialized
INFO - 2018-03-20 23:36:43 --> Router Class Initialized
INFO - 2018-03-20 23:36:43 --> Output Class Initialized
INFO - 2018-03-20 23:36:43 --> Security Class Initialized
DEBUG - 2018-03-20 23:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 23:36:43 --> Input Class Initialized
INFO - 2018-03-20 23:36:43 --> Language Class Initialized
INFO - 2018-03-20 23:36:43 --> Loader Class Initialized
INFO - 2018-03-20 23:36:43 --> Helper loaded: url_helper
INFO - 2018-03-20 23:36:43 --> Helper loaded: form_helper
INFO - 2018-03-20 23:36:43 --> Database Driver Class Initialized
DEBUG - 2018-03-20 23:36:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 23:36:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 23:36:43 --> Form Validation Class Initialized
INFO - 2018-03-20 23:36:43 --> Model Class Initialized
INFO - 2018-03-20 23:36:43 --> Controller Class Initialized
INFO - 2018-03-20 23:36:43 --> Model Class Initialized
INFO - 2018-03-20 23:36:43 --> Model Class Initialized
INFO - 2018-03-20 23:36:43 --> Model Class Initialized
INFO - 2018-03-20 23:36:43 --> Model Class Initialized
INFO - 2018-03-20 23:36:43 --> Model Class Initialized
DEBUG - 2018-03-20 23:36:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-20 23:36:43 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-20 23:36:43 --> Final output sent to browser
DEBUG - 2018-03-20 23:36:43 --> Total execution time: 0.1497
INFO - 2018-03-20 23:36:44 --> Config Class Initialized
INFO - 2018-03-20 23:36:44 --> Hooks Class Initialized
DEBUG - 2018-03-20 23:36:44 --> UTF-8 Support Enabled
INFO - 2018-03-20 23:36:44 --> Utf8 Class Initialized
INFO - 2018-03-20 23:36:44 --> URI Class Initialized
INFO - 2018-03-20 23:36:44 --> Router Class Initialized
INFO - 2018-03-20 23:36:44 --> Output Class Initialized
INFO - 2018-03-20 23:36:44 --> Security Class Initialized
DEBUG - 2018-03-20 23:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 23:36:44 --> Input Class Initialized
INFO - 2018-03-20 23:36:44 --> Language Class Initialized
INFO - 2018-03-20 23:36:44 --> Loader Class Initialized
INFO - 2018-03-20 23:36:44 --> Helper loaded: url_helper
INFO - 2018-03-20 23:36:44 --> Helper loaded: form_helper
INFO - 2018-03-20 23:36:44 --> Database Driver Class Initialized
DEBUG - 2018-03-20 23:36:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 23:36:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 23:36:44 --> Form Validation Class Initialized
INFO - 2018-03-20 23:36:44 --> Model Class Initialized
INFO - 2018-03-20 23:36:44 --> Controller Class Initialized
INFO - 2018-03-20 23:36:44 --> Model Class Initialized
INFO - 2018-03-20 23:36:44 --> Model Class Initialized
INFO - 2018-03-20 23:36:44 --> Model Class Initialized
INFO - 2018-03-20 23:36:44 --> Model Class Initialized
INFO - 2018-03-20 23:36:44 --> Model Class Initialized
DEBUG - 2018-03-20 23:36:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-20 23:40:07 --> Config Class Initialized
INFO - 2018-03-20 23:40:07 --> Hooks Class Initialized
DEBUG - 2018-03-20 23:40:07 --> UTF-8 Support Enabled
INFO - 2018-03-20 23:40:07 --> Utf8 Class Initialized
INFO - 2018-03-20 23:40:07 --> URI Class Initialized
INFO - 2018-03-20 23:40:07 --> Router Class Initialized
INFO - 2018-03-20 23:40:07 --> Output Class Initialized
INFO - 2018-03-20 23:40:07 --> Security Class Initialized
DEBUG - 2018-03-20 23:40:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 23:40:07 --> Input Class Initialized
INFO - 2018-03-20 23:40:07 --> Language Class Initialized
INFO - 2018-03-20 23:40:07 --> Loader Class Initialized
INFO - 2018-03-20 23:40:07 --> Helper loaded: url_helper
INFO - 2018-03-20 23:40:07 --> Helper loaded: form_helper
INFO - 2018-03-20 23:40:07 --> Database Driver Class Initialized
DEBUG - 2018-03-20 23:40:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 23:40:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 23:40:07 --> Form Validation Class Initialized
INFO - 2018-03-20 23:40:07 --> Model Class Initialized
INFO - 2018-03-20 23:40:07 --> Controller Class Initialized
INFO - 2018-03-20 23:40:07 --> Model Class Initialized
INFO - 2018-03-20 23:40:07 --> Model Class Initialized
DEBUG - 2018-03-20 23:40:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-20 23:40:07 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-20 23:40:07 --> Final output sent to browser
DEBUG - 2018-03-20 23:40:07 --> Total execution time: 0.3477
INFO - 2018-03-20 23:40:10 --> Config Class Initialized
INFO - 2018-03-20 23:40:10 --> Hooks Class Initialized
DEBUG - 2018-03-20 23:40:10 --> UTF-8 Support Enabled
INFO - 2018-03-20 23:40:10 --> Utf8 Class Initialized
INFO - 2018-03-20 23:40:10 --> URI Class Initialized
INFO - 2018-03-20 23:40:10 --> Router Class Initialized
INFO - 2018-03-20 23:40:10 --> Output Class Initialized
INFO - 2018-03-20 23:40:10 --> Security Class Initialized
DEBUG - 2018-03-20 23:40:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 23:40:10 --> Input Class Initialized
INFO - 2018-03-20 23:40:10 --> Language Class Initialized
INFO - 2018-03-20 23:40:10 --> Loader Class Initialized
INFO - 2018-03-20 23:40:10 --> Helper loaded: url_helper
INFO - 2018-03-20 23:40:10 --> Helper loaded: form_helper
INFO - 2018-03-20 23:40:10 --> Database Driver Class Initialized
DEBUG - 2018-03-20 23:40:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 23:40:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 23:40:10 --> Form Validation Class Initialized
INFO - 2018-03-20 23:40:10 --> Model Class Initialized
INFO - 2018-03-20 23:40:10 --> Controller Class Initialized
INFO - 2018-03-20 23:40:10 --> Model Class Initialized
INFO - 2018-03-20 23:40:10 --> Model Class Initialized
INFO - 2018-03-20 23:40:10 --> Model Class Initialized
INFO - 2018-03-20 23:40:10 --> Model Class Initialized
DEBUG - 2018-03-20 23:40:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-20 23:40:10 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-20 23:40:10 --> Final output sent to browser
DEBUG - 2018-03-20 23:40:10 --> Total execution time: 0.0691
INFO - 2018-03-20 23:40:12 --> Config Class Initialized
INFO - 2018-03-20 23:40:12 --> Hooks Class Initialized
DEBUG - 2018-03-20 23:40:12 --> UTF-8 Support Enabled
INFO - 2018-03-20 23:40:12 --> Utf8 Class Initialized
INFO - 2018-03-20 23:40:12 --> URI Class Initialized
INFO - 2018-03-20 23:40:12 --> Router Class Initialized
INFO - 2018-03-20 23:40:12 --> Output Class Initialized
INFO - 2018-03-20 23:40:12 --> Security Class Initialized
DEBUG - 2018-03-20 23:40:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 23:40:12 --> Input Class Initialized
INFO - 2018-03-20 23:40:12 --> Language Class Initialized
INFO - 2018-03-20 23:40:12 --> Loader Class Initialized
INFO - 2018-03-20 23:40:12 --> Helper loaded: url_helper
INFO - 2018-03-20 23:40:12 --> Helper loaded: form_helper
INFO - 2018-03-20 23:40:12 --> Database Driver Class Initialized
DEBUG - 2018-03-20 23:40:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 23:40:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 23:40:12 --> Form Validation Class Initialized
INFO - 2018-03-20 23:40:12 --> Model Class Initialized
INFO - 2018-03-20 23:40:12 --> Controller Class Initialized
INFO - 2018-03-20 23:40:12 --> Model Class Initialized
INFO - 2018-03-20 23:40:12 --> Model Class Initialized
INFO - 2018-03-20 23:40:12 --> Model Class Initialized
INFO - 2018-03-20 23:40:12 --> Model Class Initialized
DEBUG - 2018-03-20 23:40:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-20 23:40:12 --> Model Class Initialized
INFO - 2018-03-20 23:40:12 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-20 23:40:12 --> Final output sent to browser
DEBUG - 2018-03-20 23:40:12 --> Total execution time: 0.0976
INFO - 2018-03-20 23:40:12 --> Config Class Initialized
INFO - 2018-03-20 23:40:12 --> Hooks Class Initialized
DEBUG - 2018-03-20 23:40:12 --> UTF-8 Support Enabled
INFO - 2018-03-20 23:40:12 --> Utf8 Class Initialized
INFO - 2018-03-20 23:40:12 --> URI Class Initialized
INFO - 2018-03-20 23:40:12 --> Router Class Initialized
INFO - 2018-03-20 23:40:12 --> Output Class Initialized
INFO - 2018-03-20 23:40:12 --> Security Class Initialized
DEBUG - 2018-03-20 23:40:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 23:40:12 --> Input Class Initialized
INFO - 2018-03-20 23:40:12 --> Language Class Initialized
INFO - 2018-03-20 23:40:12 --> Loader Class Initialized
INFO - 2018-03-20 23:40:12 --> Helper loaded: url_helper
INFO - 2018-03-20 23:40:12 --> Helper loaded: form_helper
INFO - 2018-03-20 23:40:12 --> Database Driver Class Initialized
DEBUG - 2018-03-20 23:40:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 23:40:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 23:40:12 --> Form Validation Class Initialized
INFO - 2018-03-20 23:40:12 --> Model Class Initialized
INFO - 2018-03-20 23:40:12 --> Controller Class Initialized
INFO - 2018-03-20 23:40:12 --> Model Class Initialized
INFO - 2018-03-20 23:40:12 --> Model Class Initialized
DEBUG - 2018-03-20 23:40:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-20 23:40:18 --> Config Class Initialized
INFO - 2018-03-20 23:40:18 --> Hooks Class Initialized
DEBUG - 2018-03-20 23:40:18 --> UTF-8 Support Enabled
INFO - 2018-03-20 23:40:18 --> Utf8 Class Initialized
INFO - 2018-03-20 23:40:18 --> URI Class Initialized
INFO - 2018-03-20 23:40:18 --> Router Class Initialized
INFO - 2018-03-20 23:40:18 --> Output Class Initialized
INFO - 2018-03-20 23:40:18 --> Security Class Initialized
DEBUG - 2018-03-20 23:40:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 23:40:18 --> Input Class Initialized
INFO - 2018-03-20 23:40:18 --> Language Class Initialized
INFO - 2018-03-20 23:40:18 --> Loader Class Initialized
INFO - 2018-03-20 23:40:18 --> Helper loaded: url_helper
INFO - 2018-03-20 23:40:18 --> Helper loaded: form_helper
INFO - 2018-03-20 23:40:18 --> Database Driver Class Initialized
DEBUG - 2018-03-20 23:40:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 23:40:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 23:40:18 --> Form Validation Class Initialized
INFO - 2018-03-20 23:40:18 --> Model Class Initialized
INFO - 2018-03-20 23:40:18 --> Controller Class Initialized
INFO - 2018-03-20 23:40:18 --> Model Class Initialized
INFO - 2018-03-20 23:40:18 --> Model Class Initialized
DEBUG - 2018-03-20 23:40:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-20 23:40:22 --> Config Class Initialized
INFO - 2018-03-20 23:40:22 --> Hooks Class Initialized
DEBUG - 2018-03-20 23:40:22 --> UTF-8 Support Enabled
INFO - 2018-03-20 23:40:22 --> Utf8 Class Initialized
INFO - 2018-03-20 23:40:22 --> URI Class Initialized
INFO - 2018-03-20 23:40:22 --> Router Class Initialized
INFO - 2018-03-20 23:40:22 --> Output Class Initialized
INFO - 2018-03-20 23:40:22 --> Security Class Initialized
DEBUG - 2018-03-20 23:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 23:40:22 --> Input Class Initialized
INFO - 2018-03-20 23:40:22 --> Language Class Initialized
INFO - 2018-03-20 23:40:22 --> Loader Class Initialized
INFO - 2018-03-20 23:40:22 --> Helper loaded: url_helper
INFO - 2018-03-20 23:40:22 --> Helper loaded: form_helper
INFO - 2018-03-20 23:40:22 --> Database Driver Class Initialized
DEBUG - 2018-03-20 23:40:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 23:40:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 23:40:22 --> Form Validation Class Initialized
INFO - 2018-03-20 23:40:22 --> Model Class Initialized
INFO - 2018-03-20 23:40:22 --> Controller Class Initialized
INFO - 2018-03-20 23:40:22 --> Model Class Initialized
INFO - 2018-03-20 23:40:22 --> Model Class Initialized
INFO - 2018-03-20 23:40:22 --> Model Class Initialized
INFO - 2018-03-20 23:40:22 --> Model Class Initialized
DEBUG - 2018-03-20 23:40:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-20 23:40:22 --> Model Class Initialized
INFO - 2018-03-20 23:40:22 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-20 23:40:22 --> Final output sent to browser
DEBUG - 2018-03-20 23:40:22 --> Total execution time: 0.1150
INFO - 2018-03-20 23:40:22 --> Config Class Initialized
INFO - 2018-03-20 23:40:22 --> Hooks Class Initialized
DEBUG - 2018-03-20 23:40:22 --> UTF-8 Support Enabled
INFO - 2018-03-20 23:40:22 --> Utf8 Class Initialized
INFO - 2018-03-20 23:40:22 --> URI Class Initialized
INFO - 2018-03-20 23:40:22 --> Router Class Initialized
INFO - 2018-03-20 23:40:22 --> Output Class Initialized
INFO - 2018-03-20 23:40:22 --> Security Class Initialized
DEBUG - 2018-03-20 23:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 23:40:22 --> Input Class Initialized
INFO - 2018-03-20 23:40:22 --> Language Class Initialized
INFO - 2018-03-20 23:40:22 --> Loader Class Initialized
INFO - 2018-03-20 23:40:22 --> Helper loaded: url_helper
INFO - 2018-03-20 23:40:22 --> Helper loaded: form_helper
INFO - 2018-03-20 23:40:22 --> Database Driver Class Initialized
DEBUG - 2018-03-20 23:40:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 23:40:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 23:40:22 --> Form Validation Class Initialized
INFO - 2018-03-20 23:40:22 --> Model Class Initialized
INFO - 2018-03-20 23:40:22 --> Controller Class Initialized
INFO - 2018-03-20 23:40:22 --> Model Class Initialized
INFO - 2018-03-20 23:40:22 --> Model Class Initialized
INFO - 2018-03-20 23:40:22 --> Model Class Initialized
INFO - 2018-03-20 23:40:22 --> Model Class Initialized
DEBUG - 2018-03-20 23:40:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-20 23:52:16 --> Config Class Initialized
INFO - 2018-03-20 23:52:16 --> Hooks Class Initialized
DEBUG - 2018-03-20 23:52:16 --> UTF-8 Support Enabled
INFO - 2018-03-20 23:52:16 --> Utf8 Class Initialized
INFO - 2018-03-20 23:52:16 --> URI Class Initialized
INFO - 2018-03-20 23:52:16 --> Router Class Initialized
INFO - 2018-03-20 23:52:16 --> Output Class Initialized
INFO - 2018-03-20 23:52:16 --> Security Class Initialized
DEBUG - 2018-03-20 23:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 23:52:16 --> Input Class Initialized
INFO - 2018-03-20 23:52:16 --> Language Class Initialized
INFO - 2018-03-20 23:52:16 --> Loader Class Initialized
INFO - 2018-03-20 23:52:16 --> Helper loaded: url_helper
INFO - 2018-03-20 23:52:16 --> Helper loaded: form_helper
INFO - 2018-03-20 23:52:16 --> Database Driver Class Initialized
DEBUG - 2018-03-20 23:52:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 23:52:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 23:52:16 --> Form Validation Class Initialized
INFO - 2018-03-20 23:52:16 --> Model Class Initialized
INFO - 2018-03-20 23:52:16 --> Controller Class Initialized
INFO - 2018-03-20 23:52:16 --> Model Class Initialized
INFO - 2018-03-20 23:52:16 --> Model Class Initialized
INFO - 2018-03-20 23:52:16 --> Model Class Initialized
INFO - 2018-03-20 23:52:16 --> Model Class Initialized
DEBUG - 2018-03-20 23:52:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-20 23:52:16 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-20 23:52:16 --> Final output sent to browser
DEBUG - 2018-03-20 23:52:16 --> Total execution time: 0.0808
INFO - 2018-03-20 23:52:18 --> Config Class Initialized
INFO - 2018-03-20 23:52:18 --> Hooks Class Initialized
DEBUG - 2018-03-20 23:52:18 --> UTF-8 Support Enabled
INFO - 2018-03-20 23:52:18 --> Utf8 Class Initialized
INFO - 2018-03-20 23:52:18 --> URI Class Initialized
INFO - 2018-03-20 23:52:18 --> Router Class Initialized
INFO - 2018-03-20 23:52:18 --> Output Class Initialized
INFO - 2018-03-20 23:52:18 --> Security Class Initialized
DEBUG - 2018-03-20 23:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 23:52:18 --> Input Class Initialized
INFO - 2018-03-20 23:52:18 --> Language Class Initialized
INFO - 2018-03-20 23:52:18 --> Loader Class Initialized
INFO - 2018-03-20 23:52:18 --> Helper loaded: url_helper
INFO - 2018-03-20 23:52:18 --> Helper loaded: form_helper
INFO - 2018-03-20 23:52:18 --> Database Driver Class Initialized
DEBUG - 2018-03-20 23:52:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 23:52:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 23:52:18 --> Form Validation Class Initialized
INFO - 2018-03-20 23:52:18 --> Model Class Initialized
INFO - 2018-03-20 23:52:18 --> Controller Class Initialized
INFO - 2018-03-20 23:52:18 --> Model Class Initialized
INFO - 2018-03-20 23:52:18 --> Model Class Initialized
INFO - 2018-03-20 23:52:18 --> Model Class Initialized
INFO - 2018-03-20 23:52:18 --> Model Class Initialized
DEBUG - 2018-03-20 23:52:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-20 23:52:18 --> File loaded: D:\xampp\htdocs\instateccr\controlcostos\instatec_app\views\index.php
INFO - 2018-03-20 23:52:18 --> Final output sent to browser
DEBUG - 2018-03-20 23:52:18 --> Total execution time: 0.3494
INFO - 2018-03-20 23:52:18 --> Config Class Initialized
INFO - 2018-03-20 23:52:18 --> Hooks Class Initialized
DEBUG - 2018-03-20 23:52:18 --> UTF-8 Support Enabled
INFO - 2018-03-20 23:52:18 --> Utf8 Class Initialized
INFO - 2018-03-20 23:52:18 --> URI Class Initialized
INFO - 2018-03-20 23:52:18 --> Router Class Initialized
INFO - 2018-03-20 23:52:18 --> Output Class Initialized
INFO - 2018-03-20 23:52:18 --> Security Class Initialized
DEBUG - 2018-03-20 23:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 23:52:18 --> Input Class Initialized
INFO - 2018-03-20 23:52:18 --> Language Class Initialized
INFO - 2018-03-20 23:52:18 --> Loader Class Initialized
INFO - 2018-03-20 23:52:18 --> Helper loaded: url_helper
INFO - 2018-03-20 23:52:18 --> Helper loaded: form_helper
INFO - 2018-03-20 23:52:18 --> Database Driver Class Initialized
DEBUG - 2018-03-20 23:52:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 23:52:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 23:52:18 --> Form Validation Class Initialized
INFO - 2018-03-20 23:52:18 --> Model Class Initialized
INFO - 2018-03-20 23:52:18 --> Controller Class Initialized
INFO - 2018-03-20 23:52:18 --> Model Class Initialized
INFO - 2018-03-20 23:52:18 --> Model Class Initialized
INFO - 2018-03-20 23:52:18 --> Model Class Initialized
INFO - 2018-03-20 23:52:18 --> Model Class Initialized
INFO - 2018-03-20 23:52:18 --> Model Class Initialized
DEBUG - 2018-03-20 23:52:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-20 23:52:21 --> Config Class Initialized
INFO - 2018-03-20 23:52:21 --> Hooks Class Initialized
DEBUG - 2018-03-20 23:52:21 --> UTF-8 Support Enabled
INFO - 2018-03-20 23:52:21 --> Utf8 Class Initialized
INFO - 2018-03-20 23:52:21 --> URI Class Initialized
INFO - 2018-03-20 23:52:21 --> Router Class Initialized
INFO - 2018-03-20 23:52:21 --> Output Class Initialized
INFO - 2018-03-20 23:52:21 --> Security Class Initialized
DEBUG - 2018-03-20 23:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-20 23:52:21 --> Input Class Initialized
INFO - 2018-03-20 23:52:21 --> Language Class Initialized
INFO - 2018-03-20 23:52:21 --> Loader Class Initialized
INFO - 2018-03-20 23:52:21 --> Helper loaded: url_helper
INFO - 2018-03-20 23:52:21 --> Helper loaded: form_helper
INFO - 2018-03-20 23:52:21 --> Database Driver Class Initialized
DEBUG - 2018-03-20 23:52:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-20 23:52:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-20 23:52:21 --> Form Validation Class Initialized
INFO - 2018-03-20 23:52:21 --> Model Class Initialized
INFO - 2018-03-20 23:52:21 --> Controller Class Initialized
INFO - 2018-03-20 23:52:21 --> Model Class Initialized
INFO - 2018-03-20 23:52:21 --> Model Class Initialized
INFO - 2018-03-20 23:52:21 --> Model Class Initialized
INFO - 2018-03-20 23:52:21 --> Model Class Initialized
DEBUG - 2018-03-20 23:52:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-20 23:52:21 --> Final output sent to browser
DEBUG - 2018-03-20 23:52:21 --> Total execution time: 0.7063
